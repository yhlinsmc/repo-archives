/**
 * @openapi
 * /edge/app/capacity/scenarios/{scenarioId}/placement/apply:
 *   post:
 *     tags: [App - Capacity]
 *     summary: Apply a batch of staged placement moves in one transaction (owner+admin).
 *     description: >
 *       Phase-3 staged editing (spec §4.4): the Placement Edit canvas buffers
 *       drag moves locally and flushes them here on an explicit Save. Every move
 *       is a container reassignment — a KVM (`vm`) to a hypervisor, or a DB
 *       instance (`instance`) to a db_host KVM (`to: null` unplaces a VM). The
 *       whole set applies in ONE transaction and is REJECT-ALL: if any object's
 *       live container no longer matches the client's `from` (a concurrent edit)
 *       the request 409s and nothing is written; an invalid target reference
 *       400s and nothing is written.
 *     parameters:
 *       - { name: scenarioId, in: path, required: true, schema: { type: string } }
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [moves]
 *             properties:
 *               moves:
 *                 type: array
 *                 items:
 *                   type: object
 *                   required: [kind, id, from, to]
 *                   properties:
 *                     kind: { type: string, enum: [vm, instance] }
 *                     id: { type: string }
 *                     from: { type: [string, 'null'] }
 *                     to: { type: [string, 'null'] }
 *               hostOrders:
 *                 type: array
 *                 description: >
 *                   item 9 (H1 fix) — the EXPLICIT final ordered vm-id list for
 *                   each host whose within-host KVM order changed this Save
 *                   (mirrors the Grid tab's own /vms/reorder `orderedIds`
 *                   model, scoped to one host). `vmIds` must be EXACTLY that
 *                   host's post-move KVM set — a partial or foreign id list is
 *                   rejected 400 rather than silently reordering a subset.
 *                 items:
 *                   type: object
 *                   required: [hostId, vmIds]
 *                   properties:
 *                     hostId: { type: string }
 *                     vmIds: { type: array, items: { type: string } }
 *     responses:
 *       200: { description: Applied }
 *       400: { description: Malformed body, an object outside this scenario, or an invalid target reference }
 *       403: { description: Not the scenario owner (and not admin) }
 *       404: { description: Scenario not found }
 *       409: { description: A staged object's live container changed since (reject-all conflict) }
 */

/**
 * capacity/placement-apply.js — the batch staged-placement persist (spec §4.4):
 * `POST /scenarios/:scenarioId/placement/apply { moves }`.
 *
 * Registered on `router` in index.js BEFORE `mountChildren`'s generic
 * `/scenarios/:scenarioId/vms|db_instances` factory mounts — Express matches
 * middleware in registration order, and this three-segment `.../placement/apply`
 * path is bespoke (no `placement` child mount), so ordering only matters to keep
 * it ahead of the scenario factory's own `/:id` routes.
 *
 * REPLACES the old per-move autosave (usePlacementMutation's single-field PUT to
 * the generic child route). Those child routes stay intact for the Grid tab /
 * wizard / back-compat; this endpoint is the placement canvas's only write path.
 * Each move locks its target row FOR UPDATE, compares the live container to the
 * client-supplied `from` (reject-all on drift), then re-validates the NEW
 * container reference with the SAME §17.1a integrity check the child factory
 * uses (a moved KVM's hypervisor must be in-scenario; a moved instance's KVM
 * must be an in-scenario db_host) before the UPDATE — no dangling reference and
 * no cross-scenario smuggling.
 *
 * item 9 (spec §4.1.4 precise drop-position ordering) — H1 fix (Review Gate):
 * the wire carries an EXPLICIT final per-host ordered vm-id list (`hostOrders`),
 * not a per-move relative `position` replayed server-side. The original
 * design (a chronological per-move `position` + a server-side sequential
 * splice-replay) could diverge from the canvas preview whenever a batch
 * touched the same host more than once or re-touched an already-moved object
 * — the splice replay order and the FE's live-fold order are not guaranteed
 * to agree once a vm is repositioned twice in one staged session. Sending the
 * FINAL desired order directly (computed by the FE from its own
 * fully-replayed model — i.e. exactly what the canvas preview already shows)
 * removes the replay step entirely: there is nothing left to diverge from.
 * `hostOrders[].vmIds` must be the EXACT current KVM set for that host (own
 * `cap_vms.order_index` column, C2 — no new column, mirrors the Grid tab's
 * `/vms/reorder` — but scoped to ONE host's members rather than the whole
 * scenario, since only within-host order is meaningful here); a mismatch
 * 400s the whole batch (the same exact-set safety the Grid tab's reorder
 * endpoint uses) rather than silently reordering a stale/partial subset.
 */
const express = require('express');
const { pool, t } = require('../../../db');
const { requireAdminOrEditor, apiOk, apiError } = require('../../../../shared/helpers');
const { logger } = require('../../../../shared/lib/logger');
const { TABLES } = require('../../../../shared/constants');
const { resolveScenarioWriteAccess, safeRollback } = require('./_shared');
const { checkReferences, canonicalKey } = require('./reference-integrity');
const { resolveHypervisorSiteId } = require('../../../../shared/capacity/vm-site');

const router = express.Router();

// Defense-in-depth ceiling on the batch loop — a placement estate this large is
// implausible for one staged session, and an unbounded body should not fan out
// into an unbounded lock+update loop.
const MAX_MOVES = 500;

// The moved object's own table + the container column each move reassigns.
const MOVE_TABLE = { vm: TABLES.CAP_VMS, instance: TABLES.CAP_DB_INSTANCES };
const CONTAINER_COLUMN = { vm: 'hypervisor_id', instance: 'vm_id' };
// The §17.1a reference spec for validating a move's NEW (non-null) container.
const CONTAINER_REF = {
  vm: { column: 'hypervisor_id', table: TABLES.CAP_HYPERVISORS, mode: 'scenario' },
  instance: { column: 'vm_id', table: TABLES.CAP_VMS, mode: 'scenario', requireVmType: 'db_host' },
};

// Canonical lock order for the moved rows: by table then id, matching
// reference-integrity.js's own probe order so concurrent writers acquire row
// locks in one consistent sequence (deadlock-free).
function compareMove(a, b) {
  const ta = String(MOVE_TABLE[a.kind]);
  const tb = String(MOVE_TABLE[b.kind]);
  if (ta !== tb) return ta < tb ? -1 : 1;
  if (a.id !== b.id) return a.id < b.id ? -1 : 1;
  return 0;
}

const normContainer = (v) => (v == null ? null : String(v));

// item 9 (H1 fix) — bounds on the hostOrders payload. MAX_HOSTS mirrors a
// generous per-scenario hypervisor count (well above any realistic estate);
// MAX_VM_IDS mirrors reorder.js's own CAP_VMS bound (a single host's KVM count
// can never exceed the scenario's total).
const MAX_HOST_ORDERS = 500;
const MAX_HOST_ORDER_VM_IDS = 2000;

// Human-readable label for a moved object in a 409 message — never the raw id
// (same E8 class as fmb-1339's violation-label leak). Falls back to a kind
// noun when no display name is available (e.g. the row was already deleted,
// so there is nothing left to resolve a name from).
const KIND_LABEL = { vm: 'VM', instance: 'database instance' };
function describeMove(kind, name) {
  return name ? `"${name}"` : `This ${KIND_LABEL[kind]}`;
}

function validateBody(moves) {
  if (!Array.isArray(moves) || moves.length === 0) {
    return 'moves must be a non-empty array';
  }
  if (moves.length > MAX_MOVES) return `moves exceeds ${MAX_MOVES} limit`;
  const seen = new Set();
  for (const m of moves) {
    if (!m || typeof m !== 'object') return 'each move must be an object';
    if (m.kind !== 'vm' && m.kind !== 'instance') return "move.kind must be 'vm' or 'instance'";
    if (typeof m.id !== 'string' || m.id.length === 0) return 'move.id must be a non-empty string';
    // A container is a string id, or null (unplaced / place-into). undefined is
    // rejected so a caller cannot omit the field and skip the conflict check.
    for (const field of ['from', 'to']) {
      const v = m[field];
      if (v !== null && (typeof v !== 'string' || v.length === 0)) {
        return `move.${field} must be a non-empty string or null`;
      }
    }
    // A DB instance always lives on a db_host KVM — unplacing one is not a valid
    // operation, and `vm_id` is NOT NULL, so a null target would raise a DB
    // exception (500) instead of a clean rejection. Only a vm may unplace (to:null).
    if (m.kind === 'instance' && m.to === null) {
      return 'a database instance must move to a db_host — move.to cannot be null';
    }
    const key = `${m.kind}:${m.id}`;
    if (seen.has(key)) return `duplicate move for ${key} (send one net assignment per object)`;
    seen.add(key);
  }
  return null;
}

// item 9 (H1 fix): `hostOrders` is optional (a Save with no reorder omits it
// entirely) — validated separately from `moves` since it is a different axis
// (within-host order, not a container reassignment).
function validateHostOrders(hostOrders) {
  if (hostOrders === undefined) return null;
  if (!Array.isArray(hostOrders)) return 'hostOrders must be an array';
  if (hostOrders.length > MAX_HOST_ORDERS) return `hostOrders exceeds ${MAX_HOST_ORDERS} limit`;
  const seenHosts = new Set();
  for (const ho of hostOrders) {
    if (!ho || typeof ho !== 'object') return 'each hostOrders entry must be an object';
    if (typeof ho.hostId !== 'string' || ho.hostId.length === 0) return 'hostOrders[].hostId must be a non-empty string';
    if (seenHosts.has(ho.hostId)) return `duplicate hostOrders entry for host ${ho.hostId}`;
    seenHosts.add(ho.hostId);
    if (!Array.isArray(ho.vmIds) || ho.vmIds.length === 0) return 'hostOrders[].vmIds must be a non-empty array';
    if (ho.vmIds.length > MAX_HOST_ORDER_VM_IDS) return `hostOrders[].vmIds exceeds ${MAX_HOST_ORDER_VM_IDS} limit`;
    if (!ho.vmIds.every((id) => typeof id === 'string' && id.length > 0)) {
      return 'hostOrders[].vmIds must be non-empty strings';
    }
    if (new Set(ho.vmIds).size !== ho.vmIds.length) return `hostOrders[].vmIds contains a duplicate for host ${ho.hostId}`;
  }
  return null;
}

router.post('/scenarios/:scenarioId/placement/apply', async (req, res) => {
  if (!requireAdminOrEditor(req, res)) return;
  const scenarioId = req.params.scenarioId;
  const { moves, hostOrders } = req.body || {};

  const bodyError = validateBody(moves) || validateHostOrders(hostOrders);
  if (bodyError) {
    const e = apiError(bodyError, 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }

  let conn;
  try {
    conn = await pool.rw.getConnection();
    await conn.beginTransaction();

    const access = await resolveScenarioWriteAccess(conn, scenarioId, req.user);
    if (!access.found) {
      await safeRollback(conn);
      const e = apiError('Scenario not found', 'NOT_FOUND', 404);
      return res.status(e.status).json(e.body);
    }
    if (!access.allowed) {
      await safeRollback(conn);
      const e = apiError('Not the scenario owner', 'FORBIDDEN', 403);
      return res.status(e.status).json(e.body);
    }

    // INVARIANT: lock every hostOrders host's FULL current membership FOR
    // UPDATE (canonical ascending-hostId order) BEFORE locking any
    // individually-moved row below. Two concurrent Saves that each reorder
    // the SAME host used to lock their OWN moved VM row first (the
    // `compareMove` loop), and only contend for this host's membership
    // range-lock second, at the very end of the transaction. That let
    // request A hold VM1's row while blocking on VM2 (locked by B for B's
    // own move), and B symmetrically hold VM2 while blocking on VM1 — a
    // classic InnoDB lock-order-inversion deadlock. Acquiring each host's
    // membership lock FIRST — identically, for every request that touches
    // that host — means whichever request reaches a host's FOR UPDATE range
    // scan first simply blocks the other until commit; there is no later,
    // second contention point left that could form a cycle. The exact-set
    // validation below is computed from this pre-move snapshot + `moves`
    // rather than re-querying post-update, so this is the ONLY FOR UPDATE
    // acquisition against `cap_vms` membership in the whole transaction.
    //
    // THE HOST IDS ARE RESOLVED BEFORE THEY ARE SORTED OR USED AS KEYS. Every id
    // in this handler is `CHAR(36)` under a case-folding collation, so the
    // client's spelling of a host resolves the same row as the stored one — and
    // the whole block below is JavaScript `Map` keys and `Set` membership, which
    // fold nothing. Resolving first buys two things at one PK lookup per host:
    // the keys downstream are the spellings the rows carry, and the lock order
    // is canonical across clients rather than per-spelling (two Saves naming the
    // same pair of hosts in different cases would otherwise sort divergently —
    // the lock-order inversion this whole INVARIANT exists to prevent).
    //
    // A host id naming no row keeps the caller's spelling: whether that is a
    // refusal is the exact-set check's business further down, and rewriting it
    // here would only change which error it produces.
    const canonicalHostIds = new Map();
    if (Array.isArray(hostOrders) && hostOrders.length) {
      for (const ho of hostOrders) {
        const rows = await conn.query(
          `SELECT id FROM \`${t(TABLES.CAP_HYPERVISORS)}\` WHERE id = ? AND scenario_id = ?`,
          [ho.hostId, scenarioId],
        );
        canonicalHostIds.set(ho, rows.length === 1 ? rows[0].id : ho.hostId);
      }
    }

    const hostMembersPre = new Map();
    if (Array.isArray(hostOrders) && hostOrders.length) {
      const hostsByIdAsc = [...hostOrders].sort((a, b) => {
        const ka = canonicalHostIds.get(a);
        const kb = canonicalHostIds.get(b);
        return ka < kb ? -1 : ka > kb ? 1 : 0;
      });
      for (const ho of hostsByIdAsc) {
        const rows = await conn.query(
          `SELECT id, order_index FROM \`${t(TABLES.CAP_VMS)}\` WHERE scenario_id = ? AND hypervisor_id = ? FOR UPDATE`,
          [scenarioId, canonicalHostIds.get(ho)],
        );
        hostMembersPre.set(canonicalHostIds.get(ho), new Map(rows.map((r) => [r.id, r.order_index])));
      }
    }

    // Lock every moved row FOR UPDATE in canonical order, then conflict-check the
    // live container against the client's `from`. A missing row = concurrent
    // delete (409); a foreign scenario_id = smuggling (400). Reject-all: the
    // first failure rolls the whole batch back.
    const ordered = [...moves].sort(compareMove);
    // Index-aligned with `ordered`: the same batch, spelled the way the rows
    // spell themselves. Everything downstream — the UPDATE loop and the whole
    // hostOrders block — reads THIS rather than the body, so no JavaScript
    // comparison below is left holding one spelling against the other.
    const resolved = [];
    for (const m of ordered) {
      const column = CONTAINER_COLUMN[m.kind];
      // "Is this row in that scenario" and "is it still where the client last
      // saw it" both ride along as projected comparisons so the ENGINE answers
      // them, under the same collation as every statement that reads the row
      // later. Compared in JavaScript they were the narrowest opinions in the
      // module: the scenario one refused a move of a row the rest of the system
      // considers in scope, and the container one answered "Placement changed
      // since — reload and retry" to a caller whose `from` named the very host
      // the row is on, in the other case. `<=>` rather than `=` because an
      // unplaced row's container is NULL on both sides and that is a match, not
      // an unknown. The row still comes back either way, because the refusals
      // below are deliberately different answers.
      const rows = await conn.query(
        `SELECT id AS stored_id, scenario_id, (scenario_id = ?) AS same_scenario,
                \`${column}\` AS container, (\`${column}\` <=> ?) AS same_container, \`name\`
           FROM \`${t(MOVE_TABLE[m.kind])}\` WHERE id = ? FOR UPDATE`,
        [scenarioId, normContainer(m.from), m.id],
      );
      if (!rows.length) {
        await safeRollback(conn);
        // The row is gone, so there is no name left to resolve — fall back to
        // a kind noun rather than leaking the raw id (describeMove(_, null)).
        const e = apiError(`${describeMove(m.kind, null)} no longer exists — reload and retry`, 'CONFLICT', 409);
        return res.status(e.status).json(e.body);
      }
      if (Number(rows[0].same_scenario) !== 1) {
        await safeRollback(conn);
        // SECURITY: the locked row lives in a DIFFERENT scenario than the one the
        // caller has proven write access to (owner/admin-scoped). Resolving its
        // `name` here would echo a foreign scenario's object name back across the
        // authorization boundary — a cross-scenario name-disclosure channel. Use the
        // kind-noun fallback: NEITHER the raw id NOR any foreign name is disclosed.
        const e = apiError(`${describeMove(m.kind, null)} does not belong to this scenario`, 'BAD_REQUEST', 400);
        return res.status(e.status).json(e.body);
      }
      if (Number(rows[0].same_container) !== 1) {
        await safeRollback(conn);
        const e = apiError(
          `Placement of ${describeMove(m.kind, rows[0].name)} changed since — reload and retry`, 'CONFLICT', 409,
        );
        return res.status(e.status).json(e.body);
      }
      // The row's own id and the container it is actually on. `from` is taken
      // from the ROW rather than from the body precisely because the check above
      // has just established they are the same stored value — so this is the
      // same fact, in the spelling the rest of this handler can compare.
      resolved.push({
        kind: m.kind,
        id: typeof rows[0].stored_id === 'string' && rows[0].stored_id ? rows[0].stored_id : m.id,
        from: normContainer(rows[0].container),
        to: m.to,
      });
    }

    // Validate every NEW (non-null) container reference in one locked §17.1a
    // check (canonical probe order): a moved KVM's hypervisor and a moved
    // instance's KVM must exist IN THIS scenario (the instance's KVM must be a
    // db_host). A null target is an unplace and carries no reference.
    const refSpecs = resolved
      .filter((m) => m.to != null)
      .map((m) => ({ ...CONTAINER_REF[m.kind], value: m.to }));
    let canonicalContainers = new Map();
    if (refSpecs.length) {
      const refResult = await checkReferences(conn, scenarioId, refSpecs, { lock: true });
      if (!refResult.ok) {
        await safeRollback(conn);
        const e = apiError(refResult.message, refResult.code || 'BAD_REQUEST', 400);
        return res.status(e.status).json(e.body);
      }
      canonicalContainers = refResult.canonical;
    }

    // The container the check RESOLVED, not the spelling the move named it with.
    // `hypervisor_id` / `vm_id` are `CHAR(36)` under a case-folding collation, so
    // the check above admits any spelling of the target — and a stored one the
    // row does not hold makes the placement board's own grouping
    // (`vms.filter(v => v.hypervisor_id === host.id)`) drop the VM out of the
    // host it was just moved onto, while the scenario reads as healthy to every
    // statement.
    //
    // Folded back into `resolved` rather than computed at the UPDATE, because
    // the ordering block below asks "did this move arrive at that host" about
    // the same value and used to ask it of the BODY. Half of this handler being
    // canonical and half not is what let a Save's container half be accepted
    // while its ordering half was refused for the spelling the container half
    // had just resolved.
    for (const m of resolved) {
      if (m.to == null) continue;
      m.to = canonicalContainers.get(canonicalKey(CONTAINER_REF[m.kind].table, m.to)) ?? m.to;
    }

    // The data centre each moved KVM lands in. A placed VM's DC IS its host's,
    // and `cap_vms.site_id` is a cache of that — this handler moved the VM and
    // left the cache naming the DC it had just left, so the canvas and the
    // health panel said different things about the same row.
    //
    // A LOCKING READ THAT ACQUIRES NOTHING, and both halves of that matter.
    //
    // It acquires nothing because every host named here is the target of a move,
    // so `checkReferences({ lock: true })` above has already taken each of these
    // rows FOR UPDATE in ITS canonical order — by PRIMARY KEY, one row per
    // reference. This re-locks exactly that set, so the lock set and the order
    // it was acquired in are unchanged. The file's lock-order INVARIANT is that
    // `cap_vms` membership is claimed first and no SECOND contention point is
    // opened afterwards; a joined UPDATE deriving the site in SQL would have
    // opened one, which is why the value is resolved here and written into the
    // statement that was already going to run.
    //
    // WHICH IS WHY THE PLAN IS PINNED. `FOR UPDATE` claims the rows the chosen
    // PLAN VISITS, not the rows the WHERE clause finally admits — so what this
    // read locks is the optimizer's decision unless it is taken away from it.
    // Unpinned, this statement is free to reach the same rows by a scan, and a
    // scan under `FOR UPDATE` claims every hypervisor row it passes: hosts this
    // Save never names, in scenarios it does not touch. Measured on MariaDB
    // 10.11 against this schema with eight hosts in one scenario and two in
    // another, six of them named: `WHERE scenario_id = ? AND id IN (…)` planned
    // `ALL`, and the id list alone planned `index` over
    // `idx_cap_hypervisors_site` — both blocked an unlisted host AND a host in
    // the other scenario. `FORCE INDEX (PRIMARY)` planned `range` and blocked
    // only the six. Dropping the scenario predicate is therefore NOT the fix,
    // which is the whole reason the hint is here rather than a tidier WHERE
    // clause: on a small table any predicate can lose to a scan.
    //
    // WHAT THE WIDENING COST was the bound stated beside the KNOWN-OPEN lock
    // cycle in children.js — that this Save contends only for the host its
    // reference probe targets. A read that scans the table contends with every
    // host edit on the estate. Driven in capacity-lock-order-real-db.test.js on
    // the lock outcome (a writer in another scenario is granted its row) and on
    // the plan of the statement this handler actually issued.
    //
    // THE SCENARIO PREDICATE STAYS, and it costs nothing now that the access
    // path is fixed: the rows visited are the id list either way, so it decides
    // only which of them answer, exactly as before. It is redundant in fact —
    // every id here passed `checkReferences` in `mode: 'scenario'`, which admits
    // only a row whose `scenario_id` equals this one, and was rebound to the id
    // that probe read — but a redundant predicate in SQL is cheaper than a
    // branch in JavaScript that can never run.
    //
    // It has to be locking because HOLDING a row and SEEING its current version
    // are different guarantees, and only the first followed from the lock above.
    // Under REPEATABLE READ a consistent read answers from this transaction's
    // read view whatever locks it holds, and a Save carrying `hostOrders` opens
    // that view before it locks anything — the plain host lookup that resolves
    // each ordered host's stored id. A host Site edit committing in that window
    // was therefore invisible here, and the batch stored the data centre the
    // destination host had just left. Measured on MariaDB 10.11 and driven in
    // capacity-lock-order-real-db.test.js; a batch of bare moves takes only
    // locking reads before this point and so never had it, which is why the
    // ordering half of an ordinary canvas Save is what exposed it.
    const hostSiteById = new Map();
    const movedHostIds = [...new Set(
      resolved.filter((m) => m.kind === 'vm' && m.to != null).map((m) => m.to),
    )];
    if (movedHostIds.length) {
      const rows = await conn.query(
        `SELECT id, site_id FROM \`${t(TABLES.CAP_HYPERVISORS)}\` FORCE INDEX (PRIMARY)`
        + ` WHERE scenario_id = ? AND id IN (${movedHostIds.map(() => '?').join(', ')})`
        + ' FOR UPDATE',
        [scenarioId, ...movedHostIds],
      );
      for (const row of rows) hostSiteById.set(row.id, resolveHypervisorSiteId(row));
    }

    for (const m of resolved) {
      const column = CONTAINER_COLUMN[m.kind];
      // An UNPLACE (`to` is null) leaves `site_id` alone: there is no host left
      // to derive from, and the column then carries the operator's intended
      // site — the DC the VM was last in, which is the only statement of where
      // it is meant to go. Blanking it would throw that away.
      const site = m.kind === 'vm' && m.to != null ? hostSiteById.get(m.to) : undefined;
      if (site != null) {
        await conn.query(
          `UPDATE \`${t(MOVE_TABLE[m.kind])}\` SET \`${column}\` = ?, \`site_id\` = ?`
          + ' WHERE id = ? AND scenario_id = ?',
          [m.to, site, m.id, scenarioId],
        );
      } else {
        await conn.query(
          `UPDATE \`${t(MOVE_TABLE[m.kind])}\` SET \`${column}\` = ? WHERE id = ? AND scenario_id = ?`,
          [m.to, m.id, scenarioId],
        );
      }
    }

    // item 9 (H1 fix): write order_index directly from each hostOrders entry's
    // EXACT final vmIds list — no relative-position replay, so the persisted
    // order can never diverge from what the client computed (and the canvas
    // already showed). Exact-set safety (mirrors reorder.js): `vmIds` must be
    // the host's COMPLETE current KVM set post-move, or the whole batch 400s
    // rather than silently reordering a stale/partial subset.
    //
    // The "current KVM set post-move" is derived from the `hostMembersPre`
    // snapshot locked above + this batch's own moves (an arrival adds the id,
    // a departure removes it) — NOT a second `FOR UPDATE` query. The range
    // lock is already held from the pre-move acquisition; re-querying here
    // would reintroduce a second, later contention point on the same rows
    // and reopen the deadlock this restructuring removes.
    //
    // EVERY IDENTITY IN THIS BLOCK IS THE STORED ONE, and that is the whole of
    // the fix here. `live` is seeded from rows the database returned, so its
    // keys have always been stored ids — and the batch's own arrivals used to be
    // added under the BODY's spelling, the host was matched with `===` against
    // the body's `hostId`, and the exact-set check compared that mixture against
    // the body's `vmIds`. One Map, two spellings of the same VM.
    //
    // What a caller saw was not a wrong order, it was a refusal: the container
    // half of the same request resolves any spelling and had already been
    // accepted, then this half answered "hostOrders vmIds must match the host's
    // current KVM set exactly — reload and retry" about a set that did match,
    // and the reload produced the identical body. Where the mixture happened to
    // balance, the `live.get(id) !== i` test compared a client-spelled key
    // against a stored-keyed Map instead, and `order_index` was written for a
    // subset of the host.
    //
    // `moves` is not read here any more; `resolved` is. A vmId naming no row
    // this handler has seen keeps its spelling and fails the exact-set check —
    // which is the right answer for an id that names nothing in the host.
    if (Array.isArray(hostOrders) && hostOrders.length) {
      // Any spelling → the stored spelling, for every VM this request has
      // ALREADY RESOLVED: the membership snapshot's rows and the batch's own
      // moved rows. Both sides of that map came out of the database.
      //
      // THE FOLD IS A LOOKUP KEY, NOT A DECISION, and the distinction is what
      // makes it legitimate here. It resolves nothing and admits nobody: a value
      // that folds to no entry keeps the caller's spelling and goes on to fail
      // the exact-set check below, which is the right answer for an id naming
      // nothing in this host. What it does is let two spellings of a VM the
      // ENGINE already told us about meet in one `Map`.
      //
      // Exact for this domain rather than approximately right: these are
      // `CHAR(36)` ids under `utf8mb4_general_ci`, whose bytes are ASCII hex and
      // hyphens, and `toLowerCase()` is that collation on that alphabet.
      // Collision-free for the same reason `id` is a PRIMARY KEY — two stored
      // ids differing only in case cannot both exist under a folding collation,
      // so no two entries can claim the same key.
      const foldKey = (id) => String(id).toLowerCase();
      const storedVmIds = new Map();
      for (const members of hostMembersPre.values()) {
        for (const id of members.keys()) storedVmIds.set(foldKey(id), id);
      }
      for (const m of resolved) {
        if (m.kind === 'vm') storedVmIds.set(foldKey(m.id), m.id);
      }
      const canonicalVmId = (id) => storedVmIds.get(foldKey(id)) ?? id;

      for (const ho of hostOrders) {
        const hostId = canonicalHostIds.get(ho);
        const live = new Map(hostMembersPre.get(hostId) ?? []);
        for (const m of resolved) {
          if (m.kind !== 'vm') continue;
          if (m.from === hostId && m.to !== hostId) live.delete(m.id);
          else if (m.to === hostId && !live.has(m.id)) live.set(m.id, null);
        }
        const liveIds = new Set(live.keys());
        const wireIds = new Set(ho.vmIds.map(canonicalVmId));
        const sameSet = liveIds.size === wireIds.size && [...liveIds].every((id) => wireIds.has(id));
        if (!sameSet) {
          await safeRollback(conn);
          const e = apiError(
            "hostOrders vmIds must match the host's current KVM set exactly — reload and retry", 'BAD_REQUEST', 400,
          );
          return res.status(e.status).json(e.body);
        }
        for (let i = 0; i < ho.vmIds.length; i += 1) {
          const id = canonicalVmId(ho.vmIds[i]);
          if (live.get(id) !== i) {
            await conn.query(
              `UPDATE \`${t(TABLES.CAP_VMS)}\` SET order_index = ? WHERE id = ? AND scenario_id = ?`,
              [i, id, scenarioId],
            );
          }
        }
      }
    }

    await conn.commit();
    res.json(apiOk({ applied: moves.length }));
  } catch (err) {
    await safeRollback(conn);
    logger.error({ err, scenarioId }, `Failed to apply capacity placement batch for scenario id=${scenarioId}`);
    const e = apiError('Database operation failed', 'INTERNAL_ERROR', 500);
    res.status(e.status).json(e.body);
  } finally {
    if (conn) conn.release();
  }
});

module.exports = router;
