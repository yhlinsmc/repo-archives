/**
 * migration-sanitizer.test.js
 *
 * Pure-function tests for sanitizeMigrationError. Critical contract: output
 * must contain only structured fields ({ code, errno, sqlstate, step,
 * category }). Output must NEVER include raw err.message — that path goes to
 * the application logger only via the caller.
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');

const { sanitizeMigrationError } = require('../../src/shared/lib/migration-sanitizer');

describe('sanitizeMigrationError', () => {
  it('falls back to the generic errno map for an UNREGISTERED step (registry empty post-baseline): 1064 → PARSE_ERROR_OTHER', () => {
    // fmb-1329: the 42 legacy registry entries (incl. the step-specific
    // 1064→CTE_UPDATE_NOT_SUPPORTED mapping) were deleted. getMigration now
    // returns null for a legacy step name, so the sanitiser uses the generic
    // ERRNO_TO_GENERIC_CODE table — 1064 → PARSE_ERROR_OTHER.
    const err = Object.assign(new Error('You have an error in your SQL syntax near WITH RECURSIVE'), {
      errno: 1064,
      sqlState: '42000',
      code: 'ER_PARSE_ERROR',
    });
    const out = sanitizeMigrationError(err, 'hierarchy_node_type_backfill');
    assert.equal(out.code, 'PARSE_ERROR_OTHER');
    assert.equal(out.errno, 1064);
    assert.equal(out.sqlstate, '42000');
    assert.equal(out.step, 'hierarchy_node_type_backfill');
    assert.equal(out.category, 'parse_error');
  });

  it('maps errno 1064 in a different step to PARSE_ERROR_OTHER (not CTE_UPDATE_NOT_SUPPORTED)', () => {
    const err = Object.assign(new Error('parse error somewhere else'), {
      errno: 1064,
      sqlState: '42000',
    });
    const out = sanitizeMigrationError(err, 'hierarchy_depth_probe');
    assert.equal(out.code, 'PARSE_ERROR_OTHER');
    assert.equal(out.category, 'parse_error');
  });

  it('maps errno 1205 to LOCK_TIMEOUT for any step', () => {
    const err = Object.assign(new Error('Lock wait timeout exceeded'), { errno: 1205, sqlState: 'HY000' });
    const out = sanitizeMigrationError(err, 'hierarchy_node_type_backfill');
    assert.equal(out.code, 'LOCK_TIMEOUT');
    assert.equal(out.category, 'lock');
  });

  it('maps errno 1424 to RECURSION_LIMIT', () => {
    const err = Object.assign(new Error('Recursive query aborted'), { errno: 1424 });
    const out = sanitizeMigrationError(err, 'hierarchy_depth_probe');
    assert.equal(out.code, 'RECURSION_LIMIT');
    assert.equal(out.category, 'recursion');
  });

  it('preserves explicit PREFLIGHT_DEPTH_EXCEEDED code regardless of errno', () => {
    const err = new Error('depth 5 > 3');
    err.code = 'PREFLIGHT_DEPTH_EXCEEDED';
    const out = sanitizeMigrationError(err, 'hierarchy_node_type_backfill');
    assert.equal(out.code, 'PREFLIGHT_DEPTH_EXCEEDED');
    assert.equal(out.category, 'preflight');
  });

  it('maps ER_TABLEACCESS_DENIED_ERROR to DDL_PRIVILEGE_MISSING', () => {
    const err = Object.assign(new Error('access denied for ALTER'), { code: 'ER_TABLEACCESS_DENIED_ERROR' });
    const out = sanitizeMigrationError(err, 'hierarchy_node_type_backfill');
    assert.equal(out.code, 'DDL_PRIVILEGE_MISSING');
    assert.equal(out.category, 'privilege');
  });

  it('preserves explicit DATA_GUARD_SKIP code for a deliberate data-guard skip (v3.2.342)', () => {
    // The generation→category contract self-guard passes { code: 'DATA_GUARD_SKIP' }
    // (no errno) when it refuses the irreversible drop on dirty data. The output
    // must carry the distinct code/category, NOT fall through to UNKNOWN.
    const out = sanitizeMigrationError({ code: 'DATA_GUARD_SKIP' }, 'generation_to_category_contract');
    assert.equal(out.code, 'DATA_GUARD_SKIP');
    assert.equal(out.category, 'data_guard');
    assert.equal(out.errno, null);
    assert.equal(out.sqlstate, null);
    assert.equal(out.step, 'generation_to_category_contract');
    assert.deepEqual(Object.keys(out).sort(), ['category', 'code', 'errno', 'sqlstate', 'step']);
  });

  it('still maps a real errno on the contract step (DATA_GUARD_SKIP does not shadow errors)', () => {
    // A genuine error on the same step (e.g. lock timeout on the narrow ALTER)
    // must still resolve to its sanitized errno code, not DATA_GUARD_SKIP.
    const err = Object.assign(new Error('Lock wait timeout exceeded'), { errno: 1205, sqlState: 'HY000' });
    const out = sanitizeMigrationError(err, 'generation_to_category_contract');
    assert.equal(out.code, 'LOCK_TIMEOUT');
    assert.equal(out.category, 'lock');
    assert.equal(out.errno, 1205);
  });

  it('falls back to UNKNOWN when nothing matches', () => {
    const err = new Error('something weird');
    const out = sanitizeMigrationError(err, 'hierarchy_node_type_backfill');
    assert.equal(out.code, 'UNKNOWN');
    assert.equal(out.category, 'unknown');
    assert.equal(out.errno, null);
    assert.equal(out.sqlstate, null);
  });

  it('output never includes raw err.message in any field', () => {
    const err = Object.assign(
      new Error('connection refused at internal-host.local:3306; user=fmb-rw; password leak ahead'),
      { errno: 1064, sqlState: '42000' },
    );
    const out = sanitizeMigrationError(err, 'hierarchy_node_type_backfill');
    const serialised = JSON.stringify(out);
    assert.equal(serialised.includes('internal-host.local'), false, 'hostname must not leak into sanitiser output');
    assert.equal(serialised.includes('password'), false);
    assert.equal(serialised.includes('connection refused'), false);
    assert.equal(serialised.includes('fmb-rw'), false);
    // Output keys are exactly the closed-enum contract:
    assert.deepEqual(Object.keys(out).sort(), ['category', 'code', 'errno', 'sqlstate', 'step']);
  });

  it('handles non-Error inputs without crashing', () => {
    const out = sanitizeMigrationError(null, 'hierarchy_node_type_backfill');
    assert.equal(out.code, 'UNKNOWN');
    assert.equal(out.errno, null);
  });

  it('handles missing step parameter gracefully', () => {
    const err = Object.assign(new Error('x'), { errno: 1205 });
    const out = sanitizeMigrationError(err, undefined);
    assert.equal(out.step, 'unknown');
    // errno 1205 still maps to LOCK_TIMEOUT via the generic ERRNO_TO_GENERIC_CODE table.
    assert.equal(out.code, 'LOCK_TIMEOUT');
  });

  it('reads sqlstate from either sqlState (camelCase) or sqlstate (lowercase) on the error', () => {
    const errCamel = Object.assign(new Error('x'), { errno: 1205, sqlState: 'HY000' });
    const errLower = Object.assign(new Error('x'), { errno: 1205, sqlstate: 'HY000' });
    assert.equal(sanitizeMigrationError(errCamel, 'hierarchy_node_type_backfill').sqlstate, 'HY000');
    assert.equal(sanitizeMigrationError(errLower, 'hierarchy_node_type_backfill').sqlstate, 'HY000');
  });
});
