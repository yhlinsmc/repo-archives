/**
 * migration-audit-redact.test.js
 *
 * _redactAuditTableNames strips the physical table prefix from feature_audit
 * metadata so admin clients reading the audit log see logical table names only.
 * Step / column / count values (which never start with the prefix) pass through
 * untouched, and a metadata object with nothing to strip is returned by identity.
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');

const { _internalsForTest } = require('../../src/edge/db');
const { _redactAuditTableNames } = _internalsForTest;

const PREFIX = 'fmb_';

describe('_redactAuditTableNames', () => {
  it('strips the prefix from a `table` value', () => {
    const out = _redactAuditTableNames({ step: 's', table: 'fmb_variant_overrides', column: 'action' }, PREFIX);
    assert.equal(out.table, 'variant_overrides');
    assert.equal(out.step, 's');
    assert.equal(out.column, 'action');
  });

  it('strips the prefix from every prefixed string key (table, hierarchyTable, …)', () => {
    const out = _redactAuditTableNames(
      { hierarchyTable: 'fmb_hierarchy_nodes', templatesTable: 'fmb_user_templates' },
      PREFIX,
    );
    assert.equal(out.hierarchyTable, 'hierarchy_nodes');
    assert.equal(out.templatesTable, 'user_templates');
  });

  it('leaves non-prefixed values untouched (step names, columns, counts)', () => {
    const meta = { step: 'variant_overrides_action_not_null', column: 'action', deleted_count: 3 };
    const out = _redactAuditTableNames(meta, PREFIX);
    assert.deepEqual(out, meta);
  });

  it('returns the same object by identity when nothing was stripped', () => {
    const meta = { code: 'UNKNOWN', errno: null, step: 's' };
    assert.equal(_redactAuditTableNames(meta, PREFIX), meta);
  });

  it('honours a custom prefix', () => {
    const out = _redactAuditTableNames({ table: 'acme_app_users' }, 'acme_app_');
    assert.equal(out.table, 'users');
  });

  it('recurses into a nested table-name field (no leak survives nesting)', () => {
    const out = _redactAuditTableNames(
      { context: { table: 'fmb_variant_overrides' }, step: 's' },
      PREFIX,
    );
    assert.equal(out.context.table, 'variant_overrides');
    assert.equal(out.step, 's');
  });

  it('does NOT strip a data-payload value that merely starts with the prefix', () => {
    // A deleted invalid `action` value happening to start with the prefix must
    // stay intact — only `table`/`…Table` fields are redacted, not data.
    const meta = { step: 's', sample: [{ id: 'u1', action: 'fmb_lock' }], deleted_count: 1 };
    const out = _redactAuditTableNames(meta, PREFIX);
    assert.equal(out.sample[0].action, 'fmb_lock'); // preserved verbatim
    assert.equal(out, meta); // nothing stripped → identity
  });

  it('leaves a non-prefixed nested structure untouched by identity', () => {
    const meta = { context: { step: 's' }, ids: ['u1', 'u2'] };
    assert.equal(_redactAuditTableNames(meta, PREFIX), meta);
  });

  it('no-ops on null / empty-prefix; a bare string has no key so is never stripped', () => {
    assert.equal(_redactAuditTableNames(null, PREFIX), null);
    assert.equal(_redactAuditTableNames('plain', PREFIX), 'plain');
    assert.equal(_redactAuditTableNames('fmb_x', PREFIX), 'fmb_x'); // no key context → not a table field
    const meta = { table: 'fmb_x' };
    assert.equal(_redactAuditTableNames(meta, ''), meta); // empty prefix → no redaction
  });
});
