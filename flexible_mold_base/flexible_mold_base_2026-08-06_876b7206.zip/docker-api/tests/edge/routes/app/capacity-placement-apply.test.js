/**
 * capacity-placement-apply.test.js — POST /scenarios/:id/placement/apply (spec
 * §4.4): the batch staged-placement persist. One transaction, owner/admin gated,
 * reject-all on a `from` conflict or an invalid target reference, and it rewrites
 * hypervisor_id (vm) / vm_id (instance) for each move.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../../../src/edge/db');

let state;
function freshState() {
  return {
    queries: [],
    began: 0, committed: 0, rolledBack: 0, released: 0,
    scenarioOwner: null,
    scenarioExists: true,
    // id → { scenario_id, container, name } for the moved-row FOR UPDATE reads
    // (vms + db_instances share this map — ids are unique across the fixture).
    rows: {
      '3bfc2695-94ef-4492-88e9-a74bab00f042': { scenario_id: '4e29bb8e-c6cc-47cb-83e7-74379c641824', container: '33112ee1-4ee4-49c3-8b52-fe90322ec81d', name: 'web-vm-01' },
      'fb04dcb6-970e-4c3d-8873-de51fd5a50d7': { scenario_id: '4e29bb8e-c6cc-47cb-83e7-74379c641824', container: '33112ee1-4ee4-49c3-8b52-fe90322ec81d', name: 'web-vm-02' },
      '4cd9b767-2d7f-4ee8-8b51-fb1e049f6903': { scenario_id: '4e29bb8e-c6cc-47cb-83e7-74379c641824', container: '963936b9-7cdb-4775-8bc2-ca841126210f', name: 'orders-db' },
    },
    // Reference-integrity FOR UPDATE probes: referenced row id → row shape. A
    // hypervisor / db_host VM the moves may target. The same map answers the
    // host data-centre read, which is why a hypervisor here carries `site_id`.
    //
    // EVERY HYPERVISOR HAS ONE, because `cap_hypervisors.site_id` is NOT NULL:
    // a host standing in no data centre is a row the schema cannot hold, so a
    // fixture without it would make the one-column UPDATE — the branch a placed
    // KVM essentially never takes in the field — look like the ordinary case.
    refs: {
      'f998fe06-afa0-4fbe-83e0-449dc2b16983': { scenario_id: '4e29bb8e-c6cc-47cb-83e7-74379c641824', vm_type: null, site_id: '11111111-1111-4111-8111-111111111111' },
      '387e4d03-cea1-4d20-8e5d-48f271bf9a2d': { scenario_id: '4e29bb8e-c6cc-47cb-83e7-74379c641824', vm_type: 'db_host' },
      'd6072cd9-455d-4ce9-8622-efe63c461a63': { scenario_id: '4e29bb8e-c6cc-47cb-83e7-74379c641824', vm_type: 'ap_host' },
      '33112ee1-4ee4-49c3-8b52-fe90322ec81d': { scenario_id: '4e29bb8e-c6cc-47cb-83e7-74379c641824', vm_type: null, site_id: '22222222-2222-4222-8222-222222222222' },
    },
    // item 9 (H1 fix): hostId → that host's LIVE post-move KVM membership
    // ({id, order_index}[]) — what the hostOrders membership-match check reads.
    // Empty by default; tests exercising `hostOrders` set this explicitly.
    hostVms: {},
  };
}

const conn = {
  async beginTransaction() { state.began += 1; },
  async commit() { state.committed += 1; },
  async rollback() { state.rolledBack += 1; },
  release() { state.released += 1; },
  async query(sql, params = []) {
    state.queries.push({ sql, params });

    if (/SELECT id, owner_id FROM `fmb_cap_scenarios` WHERE id = \? FOR UPDATE/.test(sql)) {
      return state.scenarioExists ? [{ id: params[0], owner_id: state.scenarioOwner }] : [];
    }

    // A row is found the way `WHERE id = ?` finds it — under a case-folding
    // collation — and answers with the KEY it is stored under. Without the fold
    // this double could not represent the defect at the heart of this handler
    // (a caller naming a row in another spelling), because its own lookup would
    // simply miss and every case would read as "no such row".
    const findStored = (bag, id) => {
      if (id == null) return null;
      const key = Object.keys(bag).find((k) => k.toLowerCase() === String(id).toLowerCase());
      return key == null ? null : { key, value: bag[key] };
    };

    // Moved-row lock read: id + scenario + container + the two projected
    // comparisons, FROM <table> WHERE id = ? FOR UPDATE.
    const movedMatch = /SELECT id AS stored_id, scenario_id, \(scenario_id = \?\) AS same_scenario,\s*`(hypervisor_id|vm_id)` AS container, \(`\1` <=> \?\) AS same_container, `name`[\s\S]*FROM `fmb_(cap_vms|cap_db_instances)` WHERE id = \? FOR UPDATE/.exec(sql);
    if (movedMatch) {
      const table = movedMatch[2]; // 'cap_vms' | 'cap_db_instances'
      // (scenario, the client's `from`, id): the scope and the claimed container
      // are bound FIRST, for the two projected comparisons the engine answers.
      const [boundScenarioId, claimedContainer, id] = params;
      const found = findStored(state.rows, id);
      const row = found && found.value;
      // A row tagged with a specific `table` only answers that table's probe, so a
      // kind/id mismatch (an instance id queried under kind:'vm') misses → 409.
      if (!row || (row.table && row.table !== table)) return [];
      // Computed the way the column's collation answers it, not scripted.
      const folds = (a, b) => (a == null || b == null
        ? null
        : (String(a).toLowerCase() === String(b).toLowerCase() ? 1 : 0));
      // `<=>` is NULL-safe: two NULLs are a match, one NULL is not. An unplaced
      // row moving somewhere is exactly that case, so scripting it as `null`
      // would turn every place-into into a 409.
      const sameContainer = row.container == null && claimedContainer == null
        ? 1
        : (row.container == null || claimedContainer == null ? 0 : folds(row.container, claimedContainer));
      return [{
        stored_id: found.key,
        scenario_id: row.scenario_id,
        same_scenario: folds(row.scenario_id, boundScenarioId),
        container: row.container,
        same_container: sameContainer,
        name: row.name,
      }];
    }

    // hostOrders host resolution: which spelling does this hypervisor carry.
    const hostResolve = /^SELECT id FROM `fmb_cap_hypervisors` WHERE id = \? AND scenario_id = \?$/.exec(sql);
    if (hostResolve) {
      const found = findStored(state.refs, params[0]);
      if (!found) return [];
      const owner = found.value.scenario_id;
      const inScope = owner != null && params[1] != null
        && String(owner).toLowerCase() === String(params[1]).toLowerCase();
      return inScope ? [{ id: found.key }] : [];
    }

    // Reference-integrity locked probe (checkReferences lock:true). Selects
    // scenario_id (+ vm_type for a requireVmType spec) FROM the referenced table.
    if (/FROM `fmb_(cap_hypervisors|cap_vms)` WHERE id = \? (LIMIT 1 )?FOR UPDATE/.test(sql)) {
      // (referencing scenario, referenced id): the probe binds the scope FIRST
      // now, and the ENGINE answers whether the referenced row is in it.
      // `same_scenario` is computed here the way the column's collation answers
      // it — scripting a verdict would make the fixture assert on itself.
      const [referencingScenarioId, id] = params;
      // Found under the column's collation, and answering with the id the ROW
      // carries. Both were missing: the lookup was an exact key match, so a
      // reference named in another spelling read as "no such row"; and the probe
      // projects `id` precisely so `checkReferences` can hand its caller the
      // canonical value, which this double never returned — leaving the
      // container canonicalisation in placement-apply with no unit coverage at
      // all while its tests passed.
      const found = findStored(state.refs, id);
      if (!found) return [];
      const ref = found.value;
      const owner = ref.scenario_id;
      const same = owner == null || referencingScenarioId == null
        ? null
        : (String(owner).toLowerCase() === String(referencingScenarioId).toLowerCase() ? 1 : 0);
      return [{ id: found.key, scenario_id: owner, vm_type: ref.vm_type, same_scenario: same }];
    }

    // The data centre each moved KVM lands in: the handler resolves it from the
    // hosts it is moving onto, in one batched read scoped to the scenario.
    //
    // ANSWERED FROM `state.refs`, THE SAME MAP THE FK PROBE READS, on purpose. A
    // second fixture of hypervisors would let this read and the reference check
    // disagree about which data centre a host stands in, and the whole point of
    // the statement is that the two are one fact. Scoped and folded exactly as
    // the real `WHERE scenario_id = ? AND id IN (…)` resolves it, so a host in
    // another scenario answers nothing here just as it does there.
    //
    // MATCHED WITHOUT THE INDEX HINT IN THE PATTERN, deliberately: the hint
    // decides which rows the statement LOCKS, and a double cannot see a lock, so
    // anchoring on it here would only make this branch stop matching the day the
    // hint moves. What the hint is doing is asserted once, on the statement
    // itself, in the case that measures this read.
    const hostSites = /^SELECT id, site_id FROM `fmb_cap_hypervisors`.*WHERE scenario_id = \? AND id IN \(/.exec(sql);
    if (hostSites) {
      const [scenarioId, ...ids] = params;
      return ids
        .map((id) => findStored(state.refs, id))
        .filter((found) => found && found.value.scenario_id != null && scenarioId != null
          && String(found.value.scenario_id).toLowerCase() === String(scenarioId).toLowerCase())
        .map((found) => ({ id: found.key, site_id: found.value.site_id ?? null }));
    }

    // The container reassignment. TWO shapes, and both must be here: a KVM that
    // lands on a host writes the derived data centre in the SAME statement, and
    // an unplace (or a db_instance) writes the container alone. Matching only
    // the one-column form is what left the two-column branch unreached while
    // this suite read as fully green.
    if (/^UPDATE `fmb_(cap_vms|cap_db_instances)` SET `(hypervisor_id|vm_id)` = \?(, `site_id` = \?)? WHERE id = \? AND scenario_id = \?/.test(sql)) {
      return { affectedRows: 1 };
    }

    // item 9 (H1 fix): a hostOrders entry's membership-match read (id,
    // order_index for the LIVE post-move members of one host), and its
    // follow-up order_index rewrites (distinct from the container UPDATE
    // above — no backticked column name, matching reorder.js's own style).
    const hostOrderMatch = /^SELECT id, order_index FROM `fmb_cap_vms` WHERE scenario_id = \? AND hypervisor_id = \? FOR UPDATE/.exec(sql);
    if (hostOrderMatch) {
      // Found the way the column finds it — the handler now binds the host's
      // STORED id here, and a fixture keyed on either spelling must answer the
      // same membership, exactly as the range scan would.
      const found = findStored(state.hostVms, params[1]);
      return (found ? found.value : []).map((v) => ({ ...v }));
    }
    if (/^UPDATE `fmb_cap_vms` SET order_index = \? WHERE id = \? AND scenario_id = \?/.test(sql)) {
      return { affectedRows: 1 };
    }

    return [];
  },
};

const poolFacade = { getConnection: async () => conn, query: (sql, p) => conn.query(sql, p) };
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: { ro: poolFacade, rw: poolFacade }, t: (n) => `fmb_${n}` },
};

const router = require('../../../../src/edge/routes/app/capacity');

let currentUser; let server; let baseUrl;
before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { req.user = currentUser; next(); });
  app.use('/capacity', router);
  server = http.createServer(app);
  await new Promise((r) => server.listen(0, r));
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});
after(() => server && server.close());
beforeEach(() => {
  state = freshState();
  currentUser = { id: 'u-admin', role: 'admin' };
});

function request(method, path, body) {
  return new Promise((resolve, reject) => {
    const payload = body === undefined ? '' : JSON.stringify(body);
    const r = http.request(
      `${baseUrl}${path}`,
      { method, headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) } },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          const raw = Buffer.concat(chunks).toString('utf8');
          let json = null;
          try { json = JSON.parse(raw); } catch { /* noop */ }
          resolve({ status: res.statusCode, json, raw });
        });
      },
    );
    r.on('error', reject);
    if (payload) r.write(payload);
    r.end();
  });
}

// item 9 (H1 fix): `hostOrders` is an optional 3rd arg (kept after `scn` so
// every EXISTING call site above — which only ever passes `moves` or
// `moves, scn` — is untouched).
const apply = (moves, scn = '4e29bb8e-c6cc-47cb-83e7-74379c641824', hostOrders) => request(
  'POST',
  `/capacity/scenarios/${scn}/placement/apply`,
  hostOrders !== undefined ? { moves, hostOrders } : { moves },
);
const updatesOf = (table) => state.queries.filter((q) => new RegExp(`^UPDATE \`fmb_${table}\``).test(q.sql));
// item 9: the order_index rewrites specifically (distinct from the container
// UPDATE, which backticks its column — `updatesOf('cap_vms')` above would
// also match these, so this narrows to just the order writes).
const orderUpdatesOf = () => state.queries.filter((q) => /^UPDATE `fmb_cap_vms` SET order_index = \?/.test(q.sql));
// The container reassignment specifically — either shape.
const containerUpdatesOf = (table) => state.queries.filter(
  (q) => new RegExp(`^UPDATE \`fmb_${table}\` SET \`(hypervisor_id|vm_id)\` = \\?`).test(q.sql),
);

/**
 * What a statement bound, keyed by the COLUMN it bound it to, read off the
 * statement itself.
 *
 * READING PARAMETERS BY POSITION IS HOW AN ASSERTION CHANGES SUBJECT WITHOUT
 * FAILING. `params[1]` was this handler's row id; a placed KVM's move now binds
 * the derived data centre there and the id moved to `params[2]`. Every claim
 * about "the id" would have gone on being made about a site — and the one
 * assertion that exists because a respelled id once reached a statement is
 * exactly the one that must not be able to drift like that.
 */
const boundColumnsOf = (q) => Object.fromEntries(
  [...q.sql.matchAll(/`?([a-z_]+)`?\s*=\s*\?/g)].map((m, i) => [m[1], q.params[i]]),
);

describe('POST /capacity/scenarios/:id/placement/apply', () => {
  it('applies a mixed vm + instance batch in one transaction', async () => {
    const res = await apply([
      { kind: 'vm', id: '3bfc2695-94ef-4492-88e9-a74bab00f042', from: '33112ee1-4ee4-49c3-8b52-fe90322ec81d', to: 'f998fe06-afa0-4fbe-83e0-449dc2b16983' },
      { kind: 'instance', id: '4cd9b767-2d7f-4ee8-8b51-fb1e049f6903', from: '963936b9-7cdb-4775-8bc2-ca841126210f', to: '387e4d03-cea1-4d20-8e5d-48f271bf9a2d' },
    ]);
    assert.equal(res.status, 200, res.raw);
    assert.equal(res.json.data.applied, 2);
    assert.equal(state.began, 1);
    assert.equal(state.committed, 1);
    assert.equal(state.rolledBack, 0);
    assert.equal(updatesOf('cap_vms').length, 1);
    assert.equal(updatesOf('cap_db_instances').length, 1);
    // The KVM lands on a host, so its move writes the host's data centre in the
    // SAME statement — read by column name, never by position.
    assert.deepEqual(boundColumnsOf(updatesOf('cap_vms')[0]), {
      hypervisor_id: 'f998fe06-afa0-4fbe-83e0-449dc2b16983',
      site_id: '11111111-1111-4111-8111-111111111111',
      id: '3bfc2695-94ef-4492-88e9-a74bab00f042',
      scenario_id: '4e29bb8e-c6cc-47cb-83e7-74379c641824',
    });
    // A db_instance has no data centre of its own: one column, and the whole
    // set of them, so a site_id creeping into this statement would fail here.
    assert.deepEqual(boundColumnsOf(updatesOf('cap_db_instances')[0]), {
      vm_id: '387e4d03-cea1-4d20-8e5d-48f271bf9a2d',
      id: '4cd9b767-2d7f-4ee8-8b51-fb1e049f6903',
      scenario_id: '4e29bb8e-c6cc-47cb-83e7-74379c641824',
    });
    // AND THE READ THAT PRODUCED THAT DATA CENTRE IS A LOCKING ONE. Holding the
    // host row — which the reference check above already does — is not the same
    // as seeing its current version: a consistent read answers from this
    // transaction's read view, and a batch carrying hostOrders opens that view
    // before it locks anything. A stubbed driver has no read view, so the value
    // is identical either way and nothing else in this file can tell the two
    // apart; the real interleaving is driven in capacity-lock-order-real-db.
    const hostSiteReads = state.queries.filter(
      (q) => /^SELECT id, site_id/.test(q.sql) && /`fmb_cap_hypervisors`/.test(q.sql),
    );
    assert.equal(hostSiteReads.length, 1, 'the host-site read did not run exactly once');
    assert.match(
      hostSiteReads[0].sql, /FOR UPDATE$/,
      'the derive read the host without a lock — it can answer from a snapshot older than the host\'s move',
    );
    // AND ITS ACCESS PATH IS PINNED, because a locking read claims the rows its
    // PLAN visits rather than the rows its WHERE clause admits: unpinned, this
    // statement planned a scan on a small table and locked hosts the batch never
    // named, in other scenarios. A stubbed driver has no optimizer and no lock
    // manager, so the lock outcome is measured in
    // capacity-lock-order-real-db.test.js; what this file can answer for is
    // whether the statement still leaves the choice open.
    assert.match(
      hostSiteReads[0].sql, /FORCE INDEX \(PRIMARY\)/,
      'the derive left its access path to the optimizer — a scan under FOR UPDATE locks rows the '
      + 'reference check never claimed',
    );
  });

  it('unplaces a vm (to: null) writes NULL container and leaves the data centre alone', async () => {
    // There is no host left to derive from, and what the column still holds is
    // the DC the KVM was last in — the only statement of where it is meant to
    // go. The assertion is on the SET LIST, not the status: an unplace that
    // blanked the column would answer 200 all the same.
    const res = await apply([{ kind: 'vm', id: '3bfc2695-94ef-4492-88e9-a74bab00f042', from: '33112ee1-4ee4-49c3-8b52-fe90322ec81d', to: null }]);
    assert.equal(res.status, 200, res.raw);
    assert.deepEqual(boundColumnsOf(updatesOf('cap_vms')[0]), {
      hypervisor_id: null,
      id: '3bfc2695-94ef-4492-88e9-a74bab00f042',
      scenario_id: '4e29bb8e-c6cc-47cb-83e7-74379c641824',
    });
  });

  it('a move onto a host in another scenario derives nothing (and is refused)', async () => {
    // The host-site read is scenario-scoped, exactly as the reference check is.
    // If it were not, a foreign host's data centre would be written into this
    // scenario's row by a request the reference check refuses.
    state.refs['f998fe06-afa0-4fbe-83e0-449dc2b16983'].scenario_id = '99999999-9999-4999-8999-999999999999';
    const res = await apply([{
      kind: 'vm',
      id: '3bfc2695-94ef-4492-88e9-a74bab00f042',
      from: '33112ee1-4ee4-49c3-8b52-fe90322ec81d',
      to: 'f998fe06-afa0-4fbe-83e0-449dc2b16983',
    }]);
    assert.equal(res.status, 400, res.raw);
    assert.equal(containerUpdatesOf('cap_vms').length, 0);
  });

  it('409s reject-all when a moved object\'s live container drifted from `from`', async () => {
    state.rows['3bfc2695-94ef-4492-88e9-a74bab00f042'].container = 'a420671a-d3a2-4c14-8222-de9f3c9daad3'; // someone else moved it
    const res = await apply([
      { kind: 'vm', id: '3bfc2695-94ef-4492-88e9-a74bab00f042', from: '33112ee1-4ee4-49c3-8b52-fe90322ec81d', to: 'f998fe06-afa0-4fbe-83e0-449dc2b16983' },
      { kind: 'instance', id: '4cd9b767-2d7f-4ee8-8b51-fb1e049f6903', from: '963936b9-7cdb-4775-8bc2-ca841126210f', to: '387e4d03-cea1-4d20-8e5d-48f271bf9a2d' },
    ]);
    assert.equal(res.status, 409, res.raw);
    assert.equal(state.committed, 0);
    assert.equal(state.rolledBack, 1);
    assert.equal(updatesOf('cap_vms').length, 0);
    assert.equal(updatesOf('cap_db_instances').length, 0);
  });

  it('409 conflict message names the object, never the raw id (fmb-1342 #1)', async () => {
    state.rows['3bfc2695-94ef-4492-88e9-a74bab00f042'].container = 'a420671a-d3a2-4c14-8222-de9f3c9daad3'; // someone else moved it
    const res = await apply([{ kind: 'vm', id: '3bfc2695-94ef-4492-88e9-a74bab00f042', from: '33112ee1-4ee4-49c3-8b52-fe90322ec81d', to: 'f998fe06-afa0-4fbe-83e0-449dc2b16983' }]);
    assert.equal(res.status, 409, res.raw);
    assert.match(res.json.error.message, /"web-vm-01"/);
    assert.doesNotMatch(res.json.error.message, /\bv1\b/);
  });

  it('409s when a moved object no longer exists', async () => {
    delete state.rows['3bfc2695-94ef-4492-88e9-a74bab00f042'];
    const res = await apply([{ kind: 'vm', id: '3bfc2695-94ef-4492-88e9-a74bab00f042', from: '33112ee1-4ee4-49c3-8b52-fe90322ec81d', to: 'f998fe06-afa0-4fbe-83e0-449dc2b16983' }]);
    assert.equal(res.status, 409, res.raw);
    assert.equal(updatesOf('cap_vms').length, 0);
  });

  it('409 "no longer exists" message falls back to a kind noun, never the raw id (fmb-1342 #1)', async () => {
    delete state.rows['3bfc2695-94ef-4492-88e9-a74bab00f042'];
    const res = await apply([{ kind: 'vm', id: '3bfc2695-94ef-4492-88e9-a74bab00f042', from: '33112ee1-4ee4-49c3-8b52-fe90322ec81d', to: 'f998fe06-afa0-4fbe-83e0-449dc2b16983' }]);
    assert.equal(res.status, 409, res.raw);
    assert.match(res.json.error.message, /This VM no longer exists/);
    assert.doesNotMatch(res.json.error.message, /\bv1\b/);
  });

  it('400s reject-all when an instance targets an ap_host KVM (not db_host)', async () => {
    const res = await apply([{ kind: 'instance', id: '4cd9b767-2d7f-4ee8-8b51-fb1e049f6903', from: '963936b9-7cdb-4775-8bc2-ca841126210f', to: 'd6072cd9-455d-4ce9-8622-efe63c461a63' }]);
    assert.equal(res.status, 400, res.raw);
    assert.equal(state.committed, 0);
    assert.equal(updatesOf('cap_db_instances').length, 0);
  });

  it('400s when a target hypervisor is not in this scenario', async () => {
    state.refs['f998fe06-afa0-4fbe-83e0-449dc2b16983'].scenario_id = 'other-scn';
    const res = await apply([{ kind: 'vm', id: '3bfc2695-94ef-4492-88e9-a74bab00f042', from: '33112ee1-4ee4-49c3-8b52-fe90322ec81d', to: 'f998fe06-afa0-4fbe-83e0-449dc2b16983' }]);
    assert.equal(res.status, 400, res.raw);
    assert.equal(updatesOf('cap_vms').length, 0);
  });

  it('400s when a moved object belongs to a different scenario (smuggling)', async () => {
    state.rows['3bfc2695-94ef-4492-88e9-a74bab00f042'].scenario_id = 'other-scn';
    const res = await apply([{ kind: 'vm', id: '3bfc2695-94ef-4492-88e9-a74bab00f042', from: '33112ee1-4ee4-49c3-8b52-fe90322ec81d', to: 'f998fe06-afa0-4fbe-83e0-449dc2b16983' }]);
    assert.equal(res.status, 400, res.raw);
    assert.equal(updatesOf('cap_vms').length, 0);
  });

  it('400 smuggling message leaks NEITHER the raw id NOR the foreign scenario\'s object name (fmb-1342 #12; security HIGH)', async () => {
    // The row exists but in a scenario the caller cannot read (owner/admin-scoped
    // write access). Its real `name` must never be echoed — that would be a
    // cross-scenario name-disclosure channel. `web-vm-01` is a live name on the
    // foreign row, so this doubles as the revert probe: reintroducing name echo on
    // this branch (describeMove(kind, rows[0].name)) fails the doesNotMatch below.
    state.rows['3bfc2695-94ef-4492-88e9-a74bab00f042'].scenario_id = 'other-scn';
    const res = await apply([{ kind: 'vm', id: '3bfc2695-94ef-4492-88e9-a74bab00f042', from: '33112ee1-4ee4-49c3-8b52-fe90322ec81d', to: 'f998fe06-afa0-4fbe-83e0-449dc2b16983' }]);
    assert.equal(res.status, 400, res.raw);
    assert.match(res.json.error.message, /This VM does not belong/); // kind noun only
    assert.doesNotMatch(res.json.error.message, /web-vm-01/); // foreign name must NOT leak
    assert.doesNotMatch(res.json.error.message, /\bv1\b/); // raw id must NOT leak
  });

  it('400 smuggling stays distinct from the 409 not-found path (row exists → 400, never rerouted to 409)', async () => {
    // The distinct 400 semantics are preserved: a cross-scenario id is smuggling
    // (row present, scenario mismatch → 400), NOT a missing row (→ 409). The fix
    // closes the leak by dropping the name, not by adding scenario_id to the WHERE.
    state.rows['3bfc2695-94ef-4492-88e9-a74bab00f042'].scenario_id = 'other-scn';
    const res = await apply([{ kind: 'vm', id: '3bfc2695-94ef-4492-88e9-a74bab00f042', from: '33112ee1-4ee4-49c3-8b52-fe90322ec81d', to: 'f998fe06-afa0-4fbe-83e0-449dc2b16983' }]);
    assert.equal(res.status, 400, res.raw);
    assert.equal(state.rolledBack, 1);
    assert.equal(updatesOf('cap_vms').length, 0);
  });

  it('a plain user is refused 403, nothing written', async () => {
    currentUser = { id: 'u-user', role: 'user' };
    const res = await apply([{ kind: 'vm', id: '3bfc2695-94ef-4492-88e9-a74bab00f042', from: '33112ee1-4ee4-49c3-8b52-fe90322ec81d', to: 'f998fe06-afa0-4fbe-83e0-449dc2b16983' }]);
    assert.equal(res.status, 403, res.raw);
    assert.equal(updatesOf('cap_vms').length, 0);
  });

  it('an editor who does not own a private scenario is refused 403', async () => {
    currentUser = { id: 'u-other', role: 'editor' };
    state.scenarioOwner = 'u-owner';
    const res = await apply([{ kind: 'vm', id: '3bfc2695-94ef-4492-88e9-a74bab00f042', from: '33112ee1-4ee4-49c3-8b52-fe90322ec81d', to: 'f998fe06-afa0-4fbe-83e0-449dc2b16983' }]);
    assert.equal(res.status, 403, res.raw);
  });

  it('the owning editor may apply their own scenario', async () => {
    currentUser = { id: 'u-owner', role: 'editor' };
    state.scenarioOwner = 'u-owner';
    const res = await apply([{ kind: 'vm', id: '3bfc2695-94ef-4492-88e9-a74bab00f042', from: '33112ee1-4ee4-49c3-8b52-fe90322ec81d', to: 'f998fe06-afa0-4fbe-83e0-449dc2b16983' }]);
    assert.equal(res.status, 200, res.raw);
  });

  it('404s when the scenario does not exist', async () => {
    state.scenarioExists = false;
    const res = await apply([{ kind: 'vm', id: '3bfc2695-94ef-4492-88e9-a74bab00f042', from: '33112ee1-4ee4-49c3-8b52-fe90322ec81d', to: 'f998fe06-afa0-4fbe-83e0-449dc2b16983' }], 'nope');
    assert.equal(res.status, 404, res.raw);
  });

  it('rejects an empty / missing moves array (400)', async () => {
    assert.equal((await apply([])).status, 400);
    assert.equal((await request('POST', '/capacity/scenarios/scn-1/placement/apply', {})).status, 400);
  });

  it('rejects a duplicate object in the batch (400)', async () => {
    const res = await apply([
      { kind: 'vm', id: '3bfc2695-94ef-4492-88e9-a74bab00f042', from: '33112ee1-4ee4-49c3-8b52-fe90322ec81d', to: 'f998fe06-afa0-4fbe-83e0-449dc2b16983' },
      { kind: 'vm', id: '3bfc2695-94ef-4492-88e9-a74bab00f042', from: 'f998fe06-afa0-4fbe-83e0-449dc2b16983', to: '33112ee1-4ee4-49c3-8b52-fe90322ec81d' },
    ]);
    assert.equal(res.status, 400, res.raw);
    assert.equal(updatesOf('cap_vms').length, 0);
  });

  it('rejects a malformed move (missing from, bad kind)', async () => {
    assert.equal((await apply([{ kind: 'vm', id: '3bfc2695-94ef-4492-88e9-a74bab00f042', to: 'f998fe06-afa0-4fbe-83e0-449dc2b16983' }])).status, 400);
    assert.equal((await apply([{ kind: 'bogus', id: '3bfc2695-94ef-4492-88e9-a74bab00f042', from: '33112ee1-4ee4-49c3-8b52-fe90322ec81d', to: 'f998fe06-afa0-4fbe-83e0-449dc2b16983' }])).status, 400);
    assert.equal((await apply([{ kind: 'vm', id: '', from: '33112ee1-4ee4-49c3-8b52-fe90322ec81d', to: 'f998fe06-afa0-4fbe-83e0-449dc2b16983' }])).status, 400);
  });

  it('400s a database instance move with a null target (unplace not allowed), nothing written', async () => {
    // vm_id is NOT NULL; a null instance target must be rejected in validateBody,
    // not reach SET vm_id = NULL (which would 500). vm null-to (unplace) is fine.
    const res = await apply([{ kind: 'instance', id: '4cd9b767-2d7f-4ee8-8b51-fb1e049f6903', from: '963936b9-7cdb-4775-8bc2-ca841126210f', to: null }]);
    assert.equal(res.status, 400, res.raw);
    assert.equal(state.began, 0);
    assert.equal(updatesOf('cap_db_instances').length, 0);
  });

  it('400s a batch over the 500-move ceiling before opening a transaction', async () => {
    const moves = Array.from({ length: 501 }, (_, i) => ({ kind: 'vm', id: `x${i}`, from: '33112ee1-4ee4-49c3-8b52-fe90322ec81d', to: 'f998fe06-afa0-4fbe-83e0-449dc2b16983' }));
    const res = await apply(moves);
    assert.equal(res.status, 400, res.raw);
    // Rejected in validateBody, before pool.rw.getConnection — no transaction.
    assert.equal(state.began, 0);
    assert.equal(updatesOf('cap_vms').length, 0);
  });

  it('409s a kind/id mismatch (an instance id sent as kind:vm), nothing written', async () => {
    // Exists only in cap_db_instances; the vm-kind probe hits cap_vms → misses.
    state.rows['80db96fa-a793-4db7-88d2-7f96a2e7d5af'] = { scenario_id: '4e29bb8e-c6cc-47cb-83e7-74379c641824', container: '963936b9-7cdb-4775-8bc2-ca841126210f', table: 'cap_db_instances' };
    const res = await apply([{ kind: 'vm', id: '80db96fa-a793-4db7-88d2-7f96a2e7d5af', from: '963936b9-7cdb-4775-8bc2-ca841126210f', to: 'f998fe06-afa0-4fbe-83e0-449dc2b16983' }]);
    assert.equal(res.status, 409, res.raw);
    assert.equal(state.committed, 0);
    assert.equal(updatesOf('cap_vms').length, 0);
    assert.equal(updatesOf('cap_db_instances').length, 0);
  });

  describe('item 9 (H1 fix) — hostOrders (explicit final per-host order, no relative-position replay)', () => {
    it('a save with no hostOrders never touches order_index (legacy/back-compat path)', async () => {
      const res = await apply([{ kind: 'vm', id: '3bfc2695-94ef-4492-88e9-a74bab00f042', from: '33112ee1-4ee4-49c3-8b52-fe90322ec81d', to: 'f998fe06-afa0-4fbe-83e0-449dc2b16983' }]);
      assert.equal(res.status, 200, res.raw);
      assert.equal(orderUpdatesOf().length, 0);
    });

    it('writes order_index directly from the final vmIds list, rewriting only what changed', async () => {
      // Target host h2 post-move membership: v1 (just moved in), b1, b2. The
      // client sends the EXACT final desired order [b1, v1, b2] — no replay.
      state.rows['3bfc2695-94ef-4492-88e9-a74bab00f042'] = { scenario_id: '4e29bb8e-c6cc-47cb-83e7-74379c641824', container: '33112ee1-4ee4-49c3-8b52-fe90322ec81d', name: '3bfc2695-94ef-4492-88e9-a74bab00f042' };
      state.hostVms['f998fe06-afa0-4fbe-83e0-449dc2b16983'] = [
        { id: '7dc96f77-6c84-43e5-8a27-85489a3f9c43', order_index: 0 },
        { id: '4814d920-93ac-4a0f-8a21-63ab87dee509', order_index: 1 },
        { id: '3bfc2695-94ef-4492-88e9-a74bab00f042', order_index: 2 },
      ];
      const res = await apply(
        [{ kind: 'vm', id: '3bfc2695-94ef-4492-88e9-a74bab00f042', from: '33112ee1-4ee4-49c3-8b52-fe90322ec81d', to: 'f998fe06-afa0-4fbe-83e0-449dc2b16983' }],
        '4e29bb8e-c6cc-47cb-83e7-74379c641824',
        [{ hostId: 'f998fe06-afa0-4fbe-83e0-449dc2b16983', vmIds: ['7dc96f77-6c84-43e5-8a27-85489a3f9c43', '3bfc2695-94ef-4492-88e9-a74bab00f042', '4814d920-93ac-4a0f-8a21-63ab87dee509'] }],
      );
      assert.equal(res.status, 200, res.raw);
      const writes = orderUpdatesOf();
      // Desired: b1=0 (unchanged), v1=1 (was 2), b2=2 (was 1) — only v1/b2 write.
      assert.deepEqual(
        writes.map((w) => w.params).sort((x, y) => x[1].localeCompare(y[1])),
        // Ordered by id, matching the sort above: the fixture ids are
        // identifier-shaped now (the reference check refuses anything else
        // before it probes), so they no longer sort the way the old
        // one-letter tokens did.
        [[1, '3bfc2695-94ef-4492-88e9-a74bab00f042', '4e29bb8e-c6cc-47cb-83e7-74379c641824'], [2, '4814d920-93ac-4a0f-8a21-63ab87dee509', '4e29bb8e-c6cc-47cb-83e7-74379c641824']],
      );
    });

    it('a repeated multi-touch reorder (the H1 divergence repro) persists EXACTLY the final vmIds order', async () => {
      // A, B, C all land in an empty host, then A is re-dragged — the FE
      // replays its OWN model and sends the FINAL arrangement directly
      // ([A, C, B]); there is no server-side replay step left to diverge.
      state.rows.A = { scenario_id: '4e29bb8e-c6cc-47cb-83e7-74379c641824', container: null, name: 'A' };
      state.rows.B = { scenario_id: '4e29bb8e-c6cc-47cb-83e7-74379c641824', container: null, name: 'B' };
      state.rows.C = { scenario_id: '4e29bb8e-c6cc-47cb-83e7-74379c641824', container: null, name: 'C' };
      state.hostVms['f998fe06-afa0-4fbe-83e0-449dc2b16983'] = [
        { id: 'A', order_index: 0 },
        { id: 'B', order_index: 1 },
        { id: 'C', order_index: 2 },
      ];
      const res = await apply(
        [
          { kind: 'vm', id: 'A', from: null, to: 'f998fe06-afa0-4fbe-83e0-449dc2b16983' },
          { kind: 'vm', id: 'B', from: null, to: 'f998fe06-afa0-4fbe-83e0-449dc2b16983' },
          { kind: 'vm', id: 'C', from: null, to: 'f998fe06-afa0-4fbe-83e0-449dc2b16983' },
        ],
        '4e29bb8e-c6cc-47cb-83e7-74379c641824',
        [{ hostId: 'f998fe06-afa0-4fbe-83e0-449dc2b16983', vmIds: ['A', 'C', 'B'] }],
      );
      assert.equal(res.status, 200, res.raw);
      const writes = orderUpdatesOf();
      // A stays 0 (unchanged); C moves 2→1, B moves 1→2 — exactly [A,C,B].
      assert.deepEqual(
        writes.map((w) => w.params).sort((x, y) => x[1].localeCompare(y[1])),
        [[2, 'B', '4e29bb8e-c6cc-47cb-83e7-74379c641824'], [1, 'C', '4e29bb8e-c6cc-47cb-83e7-74379c641824']],
      );
    });

    it('400s when vmIds is missing a member of the host\'s live set (stale/partial list), nothing written', async () => {
      state.rows['3bfc2695-94ef-4492-88e9-a74bab00f042'] = { scenario_id: '4e29bb8e-c6cc-47cb-83e7-74379c641824', container: '33112ee1-4ee4-49c3-8b52-fe90322ec81d', name: '3bfc2695-94ef-4492-88e9-a74bab00f042' };
      state.hostVms['f998fe06-afa0-4fbe-83e0-449dc2b16983'] = [{ id: '7dc96f77-6c84-43e5-8a27-85489a3f9c43', order_index: 0 }, { id: '3bfc2695-94ef-4492-88e9-a74bab00f042', order_index: 1 }];
      const res = await apply(
        [{ kind: 'vm', id: '3bfc2695-94ef-4492-88e9-a74bab00f042', from: '33112ee1-4ee4-49c3-8b52-fe90322ec81d', to: 'f998fe06-afa0-4fbe-83e0-449dc2b16983' }],
        '4e29bb8e-c6cc-47cb-83e7-74379c641824',
        [{ hostId: 'f998fe06-afa0-4fbe-83e0-449dc2b16983', vmIds: ['3bfc2695-94ef-4492-88e9-a74bab00f042'] }], // missing b1
      );
      assert.equal(res.status, 400, res.raw);
      assert.equal(state.committed, 0);
      assert.equal(orderUpdatesOf().length, 0);
    });

    it('400s when vmIds names a foreign id not in the host\'s live set, nothing written', async () => {
      state.rows['3bfc2695-94ef-4492-88e9-a74bab00f042'] = { scenario_id: '4e29bb8e-c6cc-47cb-83e7-74379c641824', container: '33112ee1-4ee4-49c3-8b52-fe90322ec81d', name: '3bfc2695-94ef-4492-88e9-a74bab00f042' };
      state.hostVms['f998fe06-afa0-4fbe-83e0-449dc2b16983'] = [{ id: '3bfc2695-94ef-4492-88e9-a74bab00f042', order_index: 0 }];
      const res = await apply(
        [{ kind: 'vm', id: '3bfc2695-94ef-4492-88e9-a74bab00f042', from: '33112ee1-4ee4-49c3-8b52-fe90322ec81d', to: 'f998fe06-afa0-4fbe-83e0-449dc2b16983' }],
        '4e29bb8e-c6cc-47cb-83e7-74379c641824',
        [{ hostId: 'f998fe06-afa0-4fbe-83e0-449dc2b16983', vmIds: ['3bfc2695-94ef-4492-88e9-a74bab00f042', 'ghost'] }],
      );
      assert.equal(res.status, 400, res.raw);
      assert.equal(state.committed, 0);
    });

    it('locks the hostOrders membership set BEFORE the per-move row locks (deadlock-order invariant)', async () => {
      // Codex R2 P1: two concurrent Saves reordering the SAME host used to
      // lock their own moved VM row first and only contend for the host's
      // membership range-lock second — a lock-order inversion that could
      // deadlock. The fix moves the membership FOR UPDATE ahead of the
      // per-move row locks; assert that ordering directly off the query log.
      state.rows['3bfc2695-94ef-4492-88e9-a74bab00f042'] = { scenario_id: '4e29bb8e-c6cc-47cb-83e7-74379c641824', container: '33112ee1-4ee4-49c3-8b52-fe90322ec81d', name: '3bfc2695-94ef-4492-88e9-a74bab00f042' };
      state.hostVms['f998fe06-afa0-4fbe-83e0-449dc2b16983'] = [{ id: '7dc96f77-6c84-43e5-8a27-85489a3f9c43', order_index: 0 }, { id: '3bfc2695-94ef-4492-88e9-a74bab00f042', order_index: 1 }];
      const res = await apply(
        [{ kind: 'vm', id: '3bfc2695-94ef-4492-88e9-a74bab00f042', from: '33112ee1-4ee4-49c3-8b52-fe90322ec81d', to: 'f998fe06-afa0-4fbe-83e0-449dc2b16983' }],
        '4e29bb8e-c6cc-47cb-83e7-74379c641824',
        [{ hostId: 'f998fe06-afa0-4fbe-83e0-449dc2b16983', vmIds: ['7dc96f77-6c84-43e5-8a27-85489a3f9c43', '3bfc2695-94ef-4492-88e9-a74bab00f042'] }],
      );
      assert.equal(res.status, 200, res.raw);

      // Anchored on WHAT EACH STATEMENT LOCKS, not on its projection list. The
      // moved-row read is "cap_vms by id, FOR UPDATE" and the membership scan is
      // "cap_vms by (scenario, hypervisor), FOR UPDATE" — that is the whole of
      // what this assertion is about, and it is the part that cannot change
      // without the invariant itself changing. Pinned to the full SELECT list,
      // this regex stopped matching the moment a column was added to the
      // statement, and an ordering assertion that matches nothing is an
      // assertion about nothing.
      const membershipIdx = state.queries.findIndex((q) =>
        /FROM `fmb_cap_vms` WHERE scenario_id = \? AND hypervisor_id = \? FOR UPDATE/.test(q.sql));
      const movedRowIdx = state.queries.findIndex((q) =>
        /FROM `fmb_cap_vms` WHERE id = \? FOR UPDATE/.test(q.sql));
      assert.notEqual(membershipIdx, -1);
      assert.notEqual(movedRowIdx, -1);
      assert.ok(membershipIdx < movedRowIdx, `expected membership lock (idx ${membershipIdx}) before moved-row lock (idx ${movedRowIdx})`);
    });

    it('a Save that respells its ids reorders instead of 400ing', async () => {
      // F5. The container half of this handler resolves every id through the
      // §17.1a check, so a Save naming rows in another spelling is ACCEPTED
      // there. The ordering half compared the body's spelling against a Map
      // seeded from the database and a Set of stored ids, so the same request
      // was then refused with "hostOrders vmIds must match the host's current
      // KVM set exactly" about a set that did match — and reloading produced the
      // identical body, so the Save could not be completed at all.
      //
      // Every id below is spelled in upper case by the client and in lower case
      // by the fixture's rows, which is what the column calls one value.
      const HOST = 'f998fe06-afa0-4fbe-83e0-449dc2b16983';
      const MOVED = '3bfc2695-94ef-4492-88e9-a74bab00f042';
      const SITTING = '7dc96f77-6c84-43e5-8a27-85489a3f9c43';
      state.rows[MOVED] = { scenario_id: '4e29bb8e-c6cc-47cb-83e7-74379c641824', container: '33112ee1-4ee4-49c3-8b52-fe90322ec81d', name: 'web-vm-01' };
      state.hostVms[HOST] = [{ id: SITTING, order_index: 0 }];

      const res = await apply(
        [{ kind: 'vm', id: MOVED.toUpperCase(), from: '33112EE1-4EE4-49C3-8B52-FE90322EC81D', to: HOST.toUpperCase() }],
        '4e29bb8e-c6cc-47cb-83e7-74379c641824',
        [{ hostId: HOST.toUpperCase(), vmIds: [MOVED.toUpperCase(), SITTING.toUpperCase()] }],
      );
      assert.equal(res.status, 200, res.raw);

      // Both rows get their order written, and each UPDATE binds the STORED
      // spelling — the id every other statement and the placement board's own
      // grouping resolve. Asserting the bound parameter rather than the status
      // is the point: a 200 that wrote the caller's spelling looks identical.
      const orders = orderUpdatesOf();
      assert.deepEqual(
        orders.map((q) => [q.params[0], q.params[1]]),
        [[0, MOVED], [1, SITTING]],
      );
      // …and the container UPDATE resolved its target the same way. Every value
      // is claimed against the COLUMN it was bound to, and the whole SET list is
      // compared, so neither a new column shifting the id out from under
      // `params[1]` nor a column quietly leaving the statement can pass here.
      const container = containerUpdatesOf('cap_vms');
      assert.equal(container.length, 1);
      assert.deepEqual(boundColumnsOf(container[0]), {
        hypervisor_id: HOST,
        site_id: '11111111-1111-4111-8111-111111111111',
        id: MOVED,
        scenario_id: '4e29bb8e-c6cc-47cb-83e7-74379c641824',
      });
    });

    it('a respelled `from` is not a stale-placement conflict', async () => {
      // The other half of the same handler's identity question. `from` is what
      // the client last saw the row on, and it was compared to the stored
      // container in JavaScript — so a caller who spelled it differently was
      // told "Placement changed since — reload and retry" about a row that had
      // not moved at all.
      const res = await apply([{
        kind: 'vm',
        id: '3bfc2695-94ef-4492-88e9-a74bab00f042',
        from: '33112EE1-4EE4-49C3-8B52-FE90322EC81D',
        to: 'f998fe06-afa0-4fbe-83e0-449dc2b16983',
      }]);
      assert.equal(res.status, 200, res.raw);
    });

    it('and a genuinely stale `from` is still a conflict', async () => {
      // The direction that must not have moved: widening a check is only right
      // if what it refuses is unchanged.
      state.rows['3bfc2695-94ef-4492-88e9-a74bab00f042'].container = 'a420671a-d3a2-4c14-8222-de9f3c9daad3';
      const res = await apply([{
        kind: 'vm',
        id: '3bfc2695-94ef-4492-88e9-a74bab00f042',
        from: '33112ee1-4ee4-49c3-8b52-fe90322ec81d',
        to: 'f998fe06-afa0-4fbe-83e0-449dc2b16983',
      }]);
      assert.equal(res.status, 409, res.raw);
      assert.equal(state.rolledBack, 1);
    });

    it('a vmIds entry naming no VM of the host is still refused', async () => {
      // The fold resolves; it does not admit. An id that names nothing keeps the
      // caller's spelling and fails the exact-set check, exactly as before.
      const HOST = 'f998fe06-afa0-4fbe-83e0-449dc2b16983';
      state.hostVms[HOST] = [{ id: '7dc96f77-6c84-43e5-8a27-85489a3f9c43', order_index: 0 }];
      const res = await apply(
        [{ kind: 'vm', id: '3bfc2695-94ef-4492-88e9-a74bab00f042', from: '33112ee1-4ee4-49c3-8b52-fe90322ec81d', to: null }],
        '4e29bb8e-c6cc-47cb-83e7-74379c641824',
        [{ hostId: HOST, vmIds: ['7dc96f77-6c84-43e5-8a27-85489a3f9c43', 'c0ffee00-0000-4000-8000-000000000000'] }],
      );
      assert.equal(res.status, 400, res.raw);
      assert.match(res.json.error.message, /current KVM set exactly/);
      assert.equal(orderUpdatesOf().length, 0);
    });

    it('400s a hostOrders entry with an empty vmIds array', async () => {
      const res = await apply(
        [{ kind: 'vm', id: '3bfc2695-94ef-4492-88e9-a74bab00f042', from: '33112ee1-4ee4-49c3-8b52-fe90322ec81d', to: 'f998fe06-afa0-4fbe-83e0-449dc2b16983' }], '4e29bb8e-c6cc-47cb-83e7-74379c641824', [{ hostId: 'f998fe06-afa0-4fbe-83e0-449dc2b16983', vmIds: [] }],
      );
      assert.equal(res.status, 400, res.raw);
      assert.equal(state.began, 0);
    });

    it('400s a hostOrders entry with a duplicate vmId', async () => {
      const res = await apply(
        [{ kind: 'vm', id: '3bfc2695-94ef-4492-88e9-a74bab00f042', from: '33112ee1-4ee4-49c3-8b52-fe90322ec81d', to: 'f998fe06-afa0-4fbe-83e0-449dc2b16983' }], '4e29bb8e-c6cc-47cb-83e7-74379c641824', [{ hostId: 'f998fe06-afa0-4fbe-83e0-449dc2b16983', vmIds: ['3bfc2695-94ef-4492-88e9-a74bab00f042', '3bfc2695-94ef-4492-88e9-a74bab00f042'] }],
      );
      assert.equal(res.status, 400, res.raw);
      assert.equal(state.began, 0);
    });

    it('400s a duplicate host entry in hostOrders', async () => {
      const res = await apply(
        [{ kind: 'vm', id: '3bfc2695-94ef-4492-88e9-a74bab00f042', from: '33112ee1-4ee4-49c3-8b52-fe90322ec81d', to: 'f998fe06-afa0-4fbe-83e0-449dc2b16983' }],
        '4e29bb8e-c6cc-47cb-83e7-74379c641824',
        [{ hostId: 'f998fe06-afa0-4fbe-83e0-449dc2b16983', vmIds: ['3bfc2695-94ef-4492-88e9-a74bab00f042'] }, { hostId: 'f998fe06-afa0-4fbe-83e0-449dc2b16983', vmIds: ['3bfc2695-94ef-4492-88e9-a74bab00f042'] }],
      );
      assert.equal(res.status, 400, res.raw);
      assert.equal(state.began, 0);
    });

    it('400s when hostOrders is not an array', async () => {
      const res = await apply([{ kind: 'vm', id: '3bfc2695-94ef-4492-88e9-a74bab00f042', from: '33112ee1-4ee4-49c3-8b52-fe90322ec81d', to: 'f998fe06-afa0-4fbe-83e0-449dc2b16983' }], '4e29bb8e-c6cc-47cb-83e7-74379c641824', 'bogus');
      assert.equal(res.status, 400, res.raw);
      assert.equal(state.began, 0);
    });

    it('rejects an empty / non-string hostId or vmIds entry (400)', async () => {
      assert.equal(
        (await apply([{ kind: 'vm', id: '3bfc2695-94ef-4492-88e9-a74bab00f042', from: '33112ee1-4ee4-49c3-8b52-fe90322ec81d', to: 'f998fe06-afa0-4fbe-83e0-449dc2b16983' }], '4e29bb8e-c6cc-47cb-83e7-74379c641824', [{ hostId: '', vmIds: ['3bfc2695-94ef-4492-88e9-a74bab00f042'] }])).status,
        400,
      );
      assert.equal(
        (await apply([{ kind: 'vm', id: '3bfc2695-94ef-4492-88e9-a74bab00f042', from: '33112ee1-4ee4-49c3-8b52-fe90322ec81d', to: 'f998fe06-afa0-4fbe-83e0-449dc2b16983' }], '4e29bb8e-c6cc-47cb-83e7-74379c641824', [{ hostId: 'f998fe06-afa0-4fbe-83e0-449dc2b16983', vmIds: [''] }])).status,
        400,
      );
    });
  });
});
