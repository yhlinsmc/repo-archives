/**
 * capacity-renumber.test.js — the B5b Renumber routes: a read-only preview and a
 * transactional apply (spec B5 Q18/Q20). Drag reorder never renames; this action
 * is the only path that re-sequences hostnames. Same ownership contract as the
 * reorder routes (admin+editor, owner-or-shared), same FOR UPDATE lock discipline
 * on apply. Numbering is fork-2 wizard-consistent: group by resolved {dc} slug,
 * seq 1..k per group in order_index order, pad width grows with the group.
 *
 * The pool is mocked; the mock SIMULATES the DB's ORDER BY so preview order and
 * the apply's id-order FOR UPDATE scan (re-sorted in JS to display order) are both
 * exercised faithfully.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../../../src/edge/db');

let state;
function freshState() {
  return {
    queries: [],
    began: 0, committed: 0, rolledBack: 0, released: 0,
    scenarioExists: true,
    scenarioOwner: null,
    // cap_settings physical columns (the information_schema probe). Present state
    // carries name_patterns; the degraded case drops it to exercise the READ-side
    // fallback to built-in defaults.
    settingsColumns: ['id', 'scenario_id', 'name_patterns', 'mem_cpu_ratio'],
    // cap_hypervisors / cap_vms physical columns (the name_locked probe,
    // cap-renumber-lock). Present by default; degraded-schema absence is not
    // exercised by this file (see capacity-renumber-lock.test.js).
    entityColumns: ['id', 'name', 'order_index', 'site_id', 'vm_type', 'name_locked', 'function_name'],
    // cap_settings: a scenario override row (null = no row) + the global row's
    // name_patterns (null = built-in defaults).
    scenarioSettings: null,
    globalPatterns: null,
    sites: [{ id: 's1', name: 'DC-1' }, { id: 's2', name: 'DC-2' }],
    // Default fixture: 3 hypervisors (2 at s1, 1 at s2), 2 db_host KVMs, 2 unplaced
    // ap_host VMs — oldNames deliberately NON-sequential so every name changes.
    hypervisors: [
      { id: 'h1', name: 'old-h1', order_index: 0, site_id: 's1' },
      { id: 'h2', name: 'old-h2', order_index: 1, site_id: 's1' },
      { id: 'h3', name: 'old-h3', order_index: 2, site_id: 's2' },
    ],
    vms: [
      { id: 'k1', name: 'old-k1', order_index: 0, site_id: 's1', vm_type: 'db_host' },
      { id: 'k2', name: 'old-k2', order_index: 1, site_id: 's2', vm_type: 'db_host' },
      { id: 'a1', name: 'old-a1', order_index: 0, site_id: null, vm_type: 'ap_host' },
      { id: 'a2', name: 'old-a2', order_index: 1, site_id: null, vm_type: 'ap_host' },
    ],
    // cap_db_instances / cap_databases (PR-3 contents + role/function source).
    // Default empty — the base fixtures exercise the no-instances path; the
    // contents cases below populate them.
    dbInstances: [],
    databases: [],
  };
}

function sortForSql(rows, sql) {
  const out = [...rows];
  if (/ORDER BY order_index/.test(sql)) {
    out.sort((a, b) => (a.order_index - b.order_index) || (a.id < b.id ? -1 : 1));
  } else if (/ORDER BY id FOR UPDATE/.test(sql)) {
    out.sort((a, b) => (a.id < b.id ? -1 : a.id > b.id ? 1 : 0));
  }
  return out;
}

const conn = {
  async beginTransaction() { state.began += 1; },
  async commit() { state.committed += 1; },
  async rollback() { state.rolledBack += 1; },
  release() { state.released += 1; },
  async query(sql, params = []) {
    state.queries.push({ sql, params });

    if (/information_schema\.COLUMNS/.test(sql)) {
      // The degraded-schema column probe (tableColumnSet). Discriminate by the
      // physical table name bound as the query param: cap_settings's probe
      // (name_patterns) must not be handed cap_hypervisors/cap_vms's column
      // list (name_locked) and vice versa.
      if (params[0] === 'fmb_cap_settings') return state.settingsColumns.map((name) => ({ name }));
      return state.entityColumns.map((name) => ({ name }));
    }
    if (/SELECT id, owner_id FROM `fmb_cap_scenarios` WHERE id = \?/.test(sql)) {
      return state.scenarioExists ? [{ id: params[0], owner_id: state.scenarioOwner }] : [];
    }
    if (/SELECT scenario_id, name_patterns FROM `fmb_cap_settings` WHERE scenario_id = \?/.test(sql)) {
      return state.scenarioSettings
        ? [{ scenario_id: params[0], name_patterns: state.scenarioSettings.name_patterns }]
        : [];
    }
    if (/SELECT scenario_id, name_patterns FROM `fmb_cap_settings` WHERE scenario_id IS NULL/.test(sql)) {
      return [{ scenario_id: null, name_patterns: state.globalPatterns }];
    }
    if (/SELECT id, name FROM `fmb_cap_sites` WHERE scenario_id = \?/.test(sql)) {
      return state.sites.map((s) => ({ id: s.id, name: s.name }));
    }
    if (/FROM `fmb_cap_hypervisors` WHERE scenario_id = \?/.test(sql)) {
      return sortForSql(state.hypervisors, sql).map((r) => ({ ...r }));
    }
    if (/FROM `fmb_cap_vms` WHERE scenario_id = \?/.test(sql)) {
      // Unfiltered single pass — the route splits db_host / ap_host in JS.
      return sortForSql(state.vms, sql).map((r) => ({ ...r }));
    }
    // readHostFunctionRoles: cap_db_instances LEFT JOIN cap_databases. The route
    // ORDER BYs (order_index, id); the mock preserves fixture order (each test's
    // fixture is already in the order it asserts). instanceName carries the pill
    // name (PR-3 contents).
    if (/FROM `fmb_cap_db_instances` di/.test(sql) && /LEFT JOIN `fmb_cap_databases` d/.test(sql)) {
      return state.dbInstances.map((inst) => {
        const db = state.databases.find((d) => d.id === inst.database_id) || null;
        return {
          vmId: inst.vm_id,
          instanceName: inst.name,
          role: inst.role,
          functionName: db ? db.function_name : null,
          dbOrderIndex: db ? db.order_index : null,
          dbId: db ? db.id : null,
        };
      });
    }
    if (/^UPDATE `fmb_cap_\w+` SET name = \? WHERE id = \? AND scenario_id = \?/.test(sql)) {
      return { affectedRows: 1 };
    }
    return [];
  },
};

const poolFacade = {
  getConnection: async () => conn,
  query: (sql, params) => conn.query(sql, params),
};
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: { ro: poolFacade, rw: poolFacade }, t: (n) => `fmb_${n}` },
};

const router = require('../../../../src/edge/routes/app/capacity');
// The column-set probe caches per process; reset between cases that flip schema shape.
const { _resetColumnSetCache } = require('../../../../src/edge/routes/app/capacity/_shared');

let currentUser; let server; let baseUrl;
before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { req.user = currentUser; next(); });
  app.use('/capacity', router);
  server = http.createServer(app);
  await new Promise((r) => server.listen(0, r));
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});
after(() => server && server.close());
beforeEach(() => {
  state = freshState();
  currentUser = { id: 'u-admin', role: 'admin' };
  _resetColumnSetCache();
});

function request(method, path, body) {
  return new Promise((resolve, reject) => {
    const payload = body === undefined ? '' : JSON.stringify(body);
    const r = http.request(
      `${baseUrl}${path}`,
      { method, headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) } },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          const raw = Buffer.concat(chunks).toString('utf8');
          let json = null;
          try { json = JSON.parse(raw); } catch { /* noop */ }
          resolve({ status: res.statusCode, json, raw });
        });
      },
    );
    r.on('error', reject);
    if (payload) r.write(payload);
    r.end();
  });
}

const updates = () => state.queries.filter((q) => /^UPDATE `fmb_cap_\w+` SET name/.test(q.sql));
const PREVIEW = '/capacity/scenarios/scn-1/renumber-preview';
const APPLY = '/capacity/scenarios/scn-1/renumber';

describe('POST renumber-preview', () => {
  it('returns the full old→new plan per entity type in display order, no writes', async () => {
    const res = await request('POST', PREVIEW, {});
    assert.equal(res.status, 200, res.raw);
    const plan = res.json.data.rows;
    // 3 hypervisors + 2 db_host + 2 ap_host = 7 rows
    assert.equal(plan.length, 7);
    const byId = Object.fromEntries(plan.map((p) => [p.id, p]));
    assert.deepEqual(
      [byId.h1.newName, byId.h2.newName, byId.h3.newName],
      ['hv-dc1-01', 'hv-dc1-02', 'hv-dc2-01'],
    );
    assert.deepEqual([byId.k1.newName, byId.k2.newName], ['kvm-dc1-01', 'kvm-dc2-01']);
    assert.deepEqual([byId.a1.newName, byId.a2.newName], ['ap-01', 'ap-02']);
    assert.equal(byId.h1.entityType, 'hypervisor');
    assert.equal(byId.k1.entityType, 'kvm_host');
    assert.equal(byId.a1.entityType, 'ap_vm');
    assert.equal(byId.h1.oldName, 'old-h1');
    // read-only: never opened a transaction, never wrote
    assert.equal(state.began, 0);
    assert.equal(updates().length, 0);
  });

  it('a plain user is refused 403, nothing computed', async () => {
    currentUser = { id: 'u-user', role: 'user' };
    const res = await request('POST', PREVIEW, {});
    assert.equal(res.status, 403, res.raw);
  });

  it('404s when the scenario does not exist', async () => {
    state.scenarioExists = false;
    const res = await request('POST', PREVIEW, {});
    assert.equal(res.status, 404, res.raw);
  });
});

describe('preview contents + active patterns (PR-3)', () => {
  it('carries each db_host row its own instances (name + per-instance P/S role) in input order', async () => {
    state.vms = [{ id: 'k1', name: 'old-k1', order_index: 0, site_id: 's1', vm_type: 'db_host' }];
    state.databases = [{ id: 'db-erp', function_name: 'erp', order_index: 0 }];
    // Two instances on k1: a primary and a standby — order_index fixes pill order.
    state.dbInstances = [
      { vm_id: 'k1', name: 'erp1', role: 'primary', database_id: 'db-erp', order_index: 0 },
      { vm_id: 'k1', name: 'erp2', role: 'standby', database_id: 'db-erp', order_index: 1 },
    ];
    const res = await request('POST', PREVIEW, {});
    assert.equal(res.status, 200, res.raw);
    const byId = Object.fromEntries(res.json.data.rows.map((p) => [p.id, p]));
    assert.deepEqual(byId.k1.contents, [
      { name: 'erp1', role: 'primary' },
      { name: 'erp2', role: 'standby' },
    ]);
    // A hypervisor never carries contents.
    assert.deepEqual(byId.h1.contents, []);
  });

  it('an ap_vm carries functionName (Y-pattern "" when unset) and empty contents', async () => {
    state.vms = [
      { id: 'a1', name: 'old-a1', order_index: 0, site_id: null, vm_type: 'ap_host', function_name: 'billing' },
      { id: 'a2', name: 'old-a2', order_index: 1, site_id: null, vm_type: 'ap_host', function_name: null },
    ];
    const res = await request('POST', PREVIEW, {});
    const byId = Object.fromEntries(res.json.data.rows.map((p) => [p.id, p]));
    assert.equal(byId.a1.functionName, 'billing');
    assert.equal(byId.a2.functionName, ''); // null → '' (never null on the wire)
    assert.deepEqual(byId.a1.contents, []);
  });

  it('returns the active pattern string + source per entity key (global tier by default)', async () => {
    const res = await request('POST', PREVIEW, {});
    const { patterns } = res.json.data;
    assert.deepEqual(patterns.hypervisor, { pattern: 'hv-{dc}-{seq:2}', source: 'global' });
    assert.deepEqual(patterns.kvm_host_primary, { pattern: '{function}-{dc}-{seq:2}', source: 'global' });
    assert.deepEqual(patterns.kvm_host_standby, { pattern: 'kvm-{dc}-{seq:2}', source: 'global' });
    assert.deepEqual(patterns.ap_vm, { pattern: '{function}-{seq:2}', source: 'global' });
  });

  it('flags source: override when the scenario carries its own name_patterns', async () => {
    state.scenarioSettings = {
      name_patterns: {
        hypervisor: 'esx-{dc}-{seq:2}',
        kvm_host_primary: '{function}-{dc}-{seq:2}',
        kvm_host_standby: 'kvm-{dc}-{seq:2}',
        ap_vm: 'ap-{seq:2}',
      },
    };
    const res = await request('POST', PREVIEW, {});
    const { patterns } = res.json.data;
    assert.equal(patterns.hypervisor.source, 'override');
    assert.equal(patterns.hypervisor.pattern, 'esx-{dc}-{seq:2}');
    assert.equal(patterns.ap_vm.source, 'override');
  });
});

describe('POST renumber (apply)', () => {
  it('writes every CHANGED name in one transaction and returns the applied count', async () => {
    const res = await request('POST', APPLY, {});
    assert.equal(res.status, 200, res.raw);
    assert.equal(res.json.data.applied, 7);
    assert.equal(state.began, 1);
    assert.equal(state.committed, 1);
    assert.equal(state.rolledBack, 0);
    assert.equal(updates().length, 7);
    // recomputed server-side: the write carries the computed name, not any client input
    const h1Update = updates().find((q) => q.params[1] === 'h1');
    assert.equal(h1Update.params[0], 'hv-dc1-01');
  });

  it('skips rows whose name is already correct (no needless write / updated_at churn)', async () => {
    state.hypervisors[0].name = 'hv-dc1-01'; // already sequential
    const res = await request('POST', APPLY, {});
    assert.equal(res.status, 200, res.raw);
    assert.equal(updates().some((q) => q.params[1] === 'h1'), false);
    assert.equal(res.json.data.applied, 6);
  });

  it('locks cap_vms in ONE unfiltered ascending-id pass (deadlock-order invariant)', async () => {
    await request('POST', APPLY, {});
    // cap_hypervisors: a single id-order lock scan.
    const hvScans = state.queries.filter((q) => /FROM `fmb_cap_hypervisors` WHERE scenario_id = \? ORDER BY id FOR UPDATE$/.test(q.sql));
    assert.equal(hvScans.length, 1, 'expected exactly one cap_hypervisors id-order lock scan');
    // cap_vms carries BOTH vm_types — it MUST be locked once, UNFILTERED, so both
    // sets are taken in a single ascending-id pass (a per-vm_type filtered scan
    // would take locks in two interleaved passes, breaking id-order).
    const vmForUpdate = state.queries.filter((q) => /FROM `fmb_cap_vms`.*FOR UPDATE/.test(q.sql));
    assert.equal(vmForUpdate.length, 1, `expected exactly one cap_vms FOR UPDATE scan, got ${vmForUpdate.length}`);
    assert.match(vmForUpdate[0].sql, /FROM `fmb_cap_vms` WHERE scenario_id = \? ORDER BY id FOR UPDATE$/);
    // vm_type is read in the SELECT list (split in JS) but must NEVER be a WHERE
    // filter — a filtered scan is the two-pass regression this pins against.
    assert.doesNotMatch(vmForUpdate[0].sql, /AND vm_type/);
  });

  it('locks the global cap_settings row before reading name_patterns (fmb-1685)', async () => {
    // resolveEffectivePatterns reads the GLOBAL name_patterns row a no-override
    // scenario inherits from; the global config writers take lockGlobalConfig and
    // NO scenario lock, so apply must take the same lock or it renames from a
    // stale pattern a concurrent global edit committed mid-apply.
    await request('POST', APPLY, {});
    const lockIdx = state.queries.findIndex((q) => /^SELECT id FROM `fmb_cap_settings` FOR UPDATE$/.test(q.sql));
    const readIdx = state.queries.findIndex(
      (q) => /SELECT scenario_id, name_patterns FROM `fmb_cap_settings`/.test(q.sql),
    );
    assert.ok(lockIdx !== -1, 'apply must lock the global cap_settings row FOR UPDATE');
    assert.ok(readIdx !== -1, 'apply must read the effective name_patterns');
    assert.ok(lockIdx < readIdx, 'the global-settings lock must precede the pattern read');
    // ORDER: the scenario row is locked first (resolveScenarioWriteAccess), then
    // cap_settings — the consistent cap_scenarios → cap_settings order, no invert.
    const scenLockIdx = state.queries.findIndex((q) => /SELECT id, owner_id FROM `fmb_cap_scenarios` WHERE id = \? FOR UPDATE/.test(q.sql));
    assert.ok(scenLockIdx !== -1 && scenLockIdx < lockIdx, 'cap_scenarios is locked before cap_settings');
  });

  it('preview takes NO settings lock (read-only, RO connection)', async () => {
    await request('POST', PREVIEW, {});
    assert.equal(state.began, 0, 'preview never opens a transaction');
    assert.equal(
      state.queries.some((q) => /FOR UPDATE/.test(q.sql)), false,
      'a RO preview must not take any FOR UPDATE lock',
    );
  });

  it('rolls the WHOLE apply back on a duplicate name, nothing written (409)', async () => {
    // A scenario override sets a {seq}-less KVM pattern; with two db_host KVMs in
    // the SAME dc group both render "kvm-dc1" → a duplicate the apply must refuse.
    state.vms[1].site_id = 's1'; // both db_host now at s1 (dc1)
    state.scenarioSettings = {
      name_patterns: { hypervisor: 'hv-{dc}-{seq:2}', kvm_host: 'kvm-{dc}', ap_vm: 'ap-{seq:2}' },
    };
    const res = await request('POST', APPLY, {});
    assert.equal(res.status, 409, res.raw);
    assert.match(res.json.error.message, /duplicate/i);
    assert.equal(state.committed, 0);
    assert.equal(state.rolledBack, 1);
    assert.equal(updates().length, 0); // conflict caught in phase 1, before any write
  });

  it('a scenario override pattern wins over the global/default (recomputed server-side)', async () => {
    state.scenarioSettings = {
      name_patterns: { hypervisor: 'esx-{dc}-{seq:2}', kvm_host: 'kvm-{dc}-{seq:2}', ap_vm: 'ap-{seq:2}' },
    };
    const res = await request('POST', APPLY, {});
    assert.equal(res.status, 200, res.raw);
    const h1Update = updates().find((q) => q.params[1] === 'h1');
    assert.equal(h1Update.params[0], 'esx-dc1-01');
  });

  it('a plain user is refused 403, nothing written', async () => {
    currentUser = { id: 'u-user', role: 'user' };
    const res = await request('POST', APPLY, {});
    assert.equal(res.status, 403, res.raw);
    assert.equal(updates().length, 0);
  });

  it('an editor who does not own a private scenario is refused 403', async () => {
    currentUser = { id: 'u-other', role: 'editor' };
    state.scenarioOwner = 'u-owner';
    const res = await request('POST', APPLY, {});
    assert.equal(res.status, 403, res.raw);
    assert.equal(updates().length, 0);
  });

  it('the owning editor may renumber their own scenario', async () => {
    currentUser = { id: 'u-owner', role: 'editor' };
    state.scenarioOwner = 'u-owner';
    const res = await request('POST', APPLY, {});
    assert.equal(res.status, 200, res.raw);
  });

  it('404s when the scenario does not exist, nothing written', async () => {
    state.scenarioExists = false;
    const res = await request('POST', APPLY, {});
    assert.equal(res.status, 404, res.raw);
    assert.equal(updates().length, 0);
  });
});

describe('degraded schema (name_patterns column absent)', () => {
  it('preview + apply fall back to built-in defaults, ignoring any (unreadable) override', async () => {
    // Warn-skipped migration: the column is gone. A stored override cannot exist,
    // and even a phantom one must be ignored — the route short-circuits to defaults.
    state.settingsColumns = ['id', 'scenario_id', 'mem_cpu_ratio'];
    state.scenarioSettings = {
      name_patterns: { hypervisor: 'zzz-{dc}-{seq:2}', kvm_host: 'kvm-{dc}-{seq:2}', ap_vm: 'ap-{seq:2}' },
    };
    const prev = await request('POST', PREVIEW, {});
    assert.equal(prev.status, 200, prev.raw);
    const byId = Object.fromEntries(prev.json.data.rows.map((p) => [p.id, p]));
    assert.equal(byId.h1.newName, 'hv-dc1-01'); // built-in default, NOT the zzz override

    const res = await request('POST', APPLY, {});
    assert.equal(res.status, 200, res.raw);
    const h1Update = updates().find((q) => q.params[1] === 'h1');
    assert.equal(h1Update.params[0], 'hv-dc1-01');
  });
});

describe('preview duplicate flag (fmb-1649 — parity with apply firstDuplicateName)', () => {
  it('flags EVERY colliding row within one entity type, not just the second', async () => {
    // Same setup as the apply-side "rolls whole apply back" case: both db_host
    // KVMs land in the same {dc} group and a {seq}-less override renders them
    // identically — the preview must catch this BEFORE the user hits apply's
    // deterministic 409.
    state.vms[1].site_id = 's1'; // both db_host now at s1 (dc1)
    state.scenarioSettings = {
      name_patterns: { hypervisor: 'hv-{dc}-{seq:2}', kvm_host: 'kvm-{dc}', ap_vm: 'ap-{seq:2}' },
    };
    const res = await request('POST', PREVIEW, {});
    assert.equal(res.status, 200, res.raw);
    const byId = Object.fromEntries(res.json.data.rows.map((p) => [p.id, p]));
    assert.equal(byId.k1.newName, 'kvm-dc1');
    assert.equal(byId.k2.newName, 'kvm-dc1');
    assert.equal(byId.k1.duplicate, true, 'first colliding kvm_host row must be flagged');
    assert.equal(byId.k2.duplicate, true, 'second colliding kvm_host row must be flagged too');
    // Read-only: no writes, no transaction, regardless of the flagged collision.
    assert.equal(state.began, 0);
    assert.equal(updates().length, 0);
    // Untouched entity types are not flagged.
    assert.ok(!byId.h1.duplicate);
    assert.ok(!byId.a1.duplicate);
  });

  it('does NOT flag a collision across entity types (naming contract is per entity type)', async () => {
    // hypervisor and kvm_host share the SAME dc-free literal pattern, so their
    // first computed name is the identical string "shared-01" — but scope is
    // per entity type's own plan (apply's firstDuplicateName scope), so neither
    // is flagged.
    state.scenarioSettings = {
      name_patterns: { hypervisor: 'shared-{seq:2}', kvm_host: 'shared-{seq:2}', ap_vm: 'ap-{seq:2}' },
    };
    const res = await request('POST', PREVIEW, {});
    assert.equal(res.status, 200, res.raw);
    const byId = Object.fromEntries(res.json.data.rows.map((p) => [p.id, p]));
    assert.equal(byId.h1.newName, 'shared-01');
    assert.equal(byId.k1.newName, 'shared-01');
    assert.ok(!byId.h1.duplicate, 'cross-entity-type collision must be tolerated');
    assert.ok(!byId.k1.duplicate, 'cross-entity-type collision must be tolerated');
  });
});

describe('name length guard (VARCHAR(255))', () => {
  it('preview flags an over-limit computed name (tooLong) so the user learns before apply', async () => {
    state.sites = [{ id: 's1', name: 'd'.repeat(300) }];
    state.vms = [];
    const res = await request('POST', PREVIEW, {});
    assert.equal(res.status, 200, res.raw);
    const byId = Object.fromEntries(res.json.data.rows.map((p) => [p.id, p]));
    assert.equal(byId.h1.tooLong, true);
    assert.ok(byId.h1.newName.length > 255);
  });

  it('apply rolls the WHOLE thing back on an over-limit name (409), nothing written', async () => {
    state.sites = [{ id: 's1', name: 'd'.repeat(300) }];
    state.vms = [];
    const res = await request('POST', APPLY, {});
    assert.equal(res.status, 409, res.raw);
    assert.match(res.json.error.message, /longer than 255/i);
    assert.equal(state.committed, 0);
    assert.equal(state.rolledBack, 1);
    assert.equal(updates().length, 0);
  });

  it('accepts a name at the 255-character boundary (inclusive)', async () => {
    // 'hv-' + slug(249) + '-01' = 3 + 249 + 3 = 255 exactly. A single hypervisor
    // keeps the group pad at {seq:2}; no VMs so no other entity trips the guard.
    state.sites = [{ id: 's1', name: 'd'.repeat(249) }];
    state.hypervisors = [{ id: 'h1', name: 'old', order_index: 0, site_id: 's1' }];
    state.vms = [];
    const res = await request('POST', APPLY, {});
    assert.equal(res.status, 200, res.raw);
    const h1Update = updates().find((q) => q.params[1] === 'h1');
    assert.equal(h1Update.params[0].length, 255);
    assert.equal(h1Update.params[0], `hv-${'d'.repeat(249)}-01`);
  });
});
