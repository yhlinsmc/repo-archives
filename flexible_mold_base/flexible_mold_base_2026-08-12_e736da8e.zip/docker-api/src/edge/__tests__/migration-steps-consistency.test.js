/**
 * migration-steps-consistency.test.js — fmb-1329 Task 6.
 *
 * Mechanical DDL <-> registry agreement check (spec §4.4), the third
 * verification layer (spec §11 Q11-3) alongside the one-time deletion gate
 * (scripts/migration-baseline/deletion-gate.sh) and the docker e2e suite
 * (docker-api/tests/migration-e2e/). No real DB — pure comparison against
 * the manifest parsed from table-ddls.js.
 *
 * The first describe block runs against the REAL production registry
 * (MIGRATION_STEPS) on every CI run — an add-column entry whose ddl
 * fragment drifts from table-ddls.js, or a version bump forgotten, fails
 * here before it ever reaches a real DB. The second describe block proves
 * each check function actually detects the violation it claims to (not
 * just "passes because the current registry is empty").
 */
import { describe, it, expect } from 'vitest';

const { buildSchemaManifest, ddlFragmentFor } = require('../lib/schema-manifest');
const { MIGRATION_STEPS, PLATFORM_SCHEMA_VERSION, BASELINE_SCHEMA_VERSION } = require('../migration-steps');

const identityT = (base) => base;

function normalizeWhitespace(s) {
  return s.replace(/\s+/g, ' ').trim();
}

// Versions are dot-separated non-negative integers (project convention:
// 3.2.NNN) — numeric compare per segment, not lexicographic string compare
// (lexicographic would rank "3.2.9" above "3.2.10").
function compareVersions(a, b) {
  const pa = a.split('.').map(Number);
  const pb = b.split('.').map(Number);
  for (let i = 0; i < Math.max(pa.length, pb.length); i += 1) {
    const diff = (pa[i] || 0) - (pb[i] || 0);
    if (diff !== 0) return diff;
  }
  return 0;
}

function maxVersion(steps, baseline) {
  if (steps.length === 0) return baseline;
  return steps.reduce((max, s) => (compareVersions(s.version, max) > 0 ? s.version : max), steps[0].version);
}

function findAddColumnGaps(steps, manifest) {
  const gaps = [];
  for (const s of steps.filter((entry) => entry.kind === 'add-column')) {
    const table = manifest.get(s.table);
    if (!table || !table.columns.includes(s.column)) {
      gaps.push(`${s.step}: ${s.table}.${s.column} not present in the table-ddls.js manifest`);
      continue;
    }
    const fragment = ddlFragmentFor(s.table, s.column);
    if (!fragment || normalizeWhitespace(fragment) !== normalizeWhitespace(s.ddl)) {
      gaps.push(`${s.step}: registry ddl "${s.ddl}" does not match table-ddls.js fragment "${fragment}"`);
    }
  }
  return gaps;
}

function findDropColumnGaps(steps, manifest) {
  const gaps = [];
  for (const s of steps.filter((entry) => entry.kind === 'drop-column')) {
    const table = manifest.get(s.table);
    if (table && table.columns.includes(s.column)) {
      gaps.push(`${s.step}: ${s.table}.${s.column} is still present in table-ddls.js (drop-column entries must target absent columns)`);
    }
  }
  return gaps;
}

function findDuplicateStepNames(steps) {
  const seen = new Set();
  const dups = new Set();
  for (const s of steps) {
    if (seen.has(s.step)) dups.add(s.step);
    seen.add(s.step);
  }
  return [...dups];
}

describe('migration-steps-consistency — production registry (spec §4.4)', () => {
  const manifest = buildSchemaManifest(identityT);

  it('every add-column entry matches the manifest + byte-matching ddl fragment', () => {
    expect(findAddColumnGaps(MIGRATION_STEPS, manifest)).toEqual([]);
  });

  it('every drop-column entry targets a column absent from the manifest', () => {
    expect(findDropColumnGaps(MIGRATION_STEPS, manifest)).toEqual([]);
  });

  it('PLATFORM_SCHEMA_VERSION equals the max registry version (BASELINE when empty)', () => {
    expect(PLATFORM_SCHEMA_VERSION).toBe(maxVersion(MIGRATION_STEPS, BASELINE_SCHEMA_VERSION));
  });

  it('registry carries every shipped batch (count pin)', () => {
    // The version/gap checks above are the ones that actually matter going
    // forward; this just pins the count so a silently-dropped entry (not just a
    // bad one) fails here too. 3 drop-column + 2 created_at NOT NULL backfills
    // (destructive batch) + 2 add-column (cell targeting + blueprint policy —
    // the third, is_locked, was withdrawn when the column was dropped)
    // + 1 create-table (decision_tables) + 1 add-column (cleared_auto_fills)
    // + 2 add-column, 1 custom and 1 drop-column (one value source per field —
    // the custom entry carries the legacy is_locked/compute_rule state across
    // BEFORE the boolean is dropped, and is ordered between them for that
    // reason)
    // + 1 add-column (flow_recipe_runs.input_snapshot — what the operator
    // entered, recorded on the run)
    // + 2 create-table (delegated_grants + template_activity — who may work on
    // someone else's record, and the trail of who did)
    // + 1 custom (the unique (blueprint_id, field_key) index — an index is
    // neither a table nor a column, so the structural kinds cannot express it
    // and the missing-structure comparison cannot see it).
    // + 1 add-column (cap_settings.name_patterns — spec B5a hostname patterns).
    // + 1 custom (cap_vms.site_id backfill from host — a pure data repair with
    // no DDL, so the structural kinds cannot express it and the missing-structure
    // comparison cannot see it; a placed VM's stale data-centre cache is repinned
    // to the host it stands on).
    // + 2 add-column (cap_hypervisors.name_locked, cap_vms.name_locked —
    // renumber name-lock, spec D1/D5).
    // + 1 add-column (cap_vms.function_name — the AP VM renumber {function}
    // source, PR-2; nullable, no backfill per decision Q13).
    expect(MIGRATION_STEPS.length).toBe(22);
    expect(PLATFORM_SCHEMA_VERSION).not.toBe(BASELINE_SCHEMA_VERSION);
  });

  it('registry step names are unique', () => {
    expect(findDuplicateStepNames(MIGRATION_STEPS)).toEqual([]);
  });

  it('every custom entry defines a probe() and a remediationSql() (Codex R2 contract)', () => {
    const identityTableFn = (base) => base;
    for (const s of MIGRATION_STEPS.filter((entry) => entry.kind === 'custom')) {
      expect(typeof s.probe, `${s.step}: custom step must define probe()`).toBe('function');
      expect(typeof s.remediationSql, `${s.step}: custom step must define remediationSql()`).toBe('function');
      const sql = s.remediationSql(identityTableFn);
      expect(Array.isArray(sql), `${s.step}: remediationSql(tableFn) must return an array`).toBe(true);
      expect(sql.length, `${s.step}: remediationSql must be non-empty`).toBeGreaterThan(0);
      for (const stmt of sql) {
        expect(typeof stmt, `${s.step}: each remediation statement is a string`).toBe('string');
        expect(stmt.trim().length, `${s.step}: no empty remediation statement`).toBeGreaterThan(0);
      }
    }
  });
});

describe('migration-steps-consistency — synthetic violation detection', () => {
  const manifest = buildSchemaManifest(identityT);

  it('flags an add-column entry whose ddl fragment drifted from table-ddls.js', () => {
    const steps = [
      { version: '9.9.9', kind: 'add-column', table: 'user_templates', column: 'owner_id', ddl: '`owner_id` INT NULL', step: 'bad_owner_id' },
    ];
    expect(findAddColumnGaps(steps, manifest).length).toBe(1);
  });

  it('accepts an add-column entry whose ddl fragment matches modulo whitespace', () => {
    const realFragment = ddlFragmentFor('user_templates', 'owner_id');
    const steps = [
      { version: '9.9.9', kind: 'add-column', table: 'user_templates', column: 'owner_id', ddl: `  ${realFragment.replace(/\s+/g, '   ')}  `, step: 'ok_owner_id' },
    ];
    expect(findAddColumnGaps(steps, manifest)).toEqual([]);
  });

  it('flags an add-column entry whose (table, column) is not in the manifest at all', () => {
    const steps = [
      { version: '9.9.9', kind: 'add-column', table: 'user_templates', column: 'does_not_exist_column', ddl: '`does_not_exist_column` INT NULL', step: 'ghost_column' },
    ];
    expect(findAddColumnGaps(steps, manifest).length).toBe(1);
  });

  it('flags a drop-column entry whose column is still present', () => {
    const steps = [
      { version: '9.9.9', kind: 'drop-column', table: 'user_templates', column: 'owner_id', step: 'bad_drop' },
    ];
    expect(findDropColumnGaps(steps, manifest).length).toBe(1);
  });

  it('accepts a drop-column entry whose column is genuinely absent', () => {
    const steps = [
      { version: '9.9.9', kind: 'drop-column', table: 'user_templates', column: 'does_not_exist_column', step: 'ok_drop' },
    ];
    expect(findDropColumnGaps(steps, manifest)).toEqual([]);
  });

  it('computes max version across a populated registry (non-empty case)', () => {
    const steps = [
      { version: '3.2.521', step: 'a' },
      { version: '3.2.600', step: 'b' },
      { version: '3.2.550', step: 'c' },
    ];
    expect(maxVersion(steps, BASELINE_SCHEMA_VERSION)).toBe('3.2.600');
  });

  it('numeric version compare ranks 3.2.10 above 3.2.9 (not lexicographic)', () => {
    const steps = [
      { version: '3.2.9', step: 'a' },
      { version: '3.2.10', step: 'b' },
    ];
    expect(maxVersion(steps, BASELINE_SCHEMA_VERSION)).toBe('3.2.10');
  });

  it('falls back to BASELINE_SCHEMA_VERSION for an empty registry', () => {
    expect(maxVersion([], BASELINE_SCHEMA_VERSION)).toBe(BASELINE_SCHEMA_VERSION);
  });

  it('flags duplicate step names', () => {
    const steps = [{ step: 'dup' }, { step: 'dup' }, { step: 'unique' }];
    expect(findDuplicateStepNames(steps)).toEqual(['dup']);
  });

  it('accepts unique step names', () => {
    const steps = [{ step: 'a' }, { step: 'b' }];
    expect(findDuplicateStepNames(steps)).toEqual([]);
  });
});
