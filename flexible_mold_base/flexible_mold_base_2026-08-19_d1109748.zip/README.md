# flexible_mold_base

A modular monolith web application built with **Vite + React + Express + MariaDB**, designed to run in two deployment environments — on-premises and air-gapped private networks.

---

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React 18, TypeScript, Tailwind CSS, Shadcn/ui, Vite |
| Backend | Express.js (Node 22), Local JWT / Keycloak OIDC authentication |
| Database | MariaDB (ONPREM / AIRGAP) |
| Container | Docker multi-stage build, DevContainer (VS Code) |

---

## Environments

| | ONPREM | AIRGAP |
|---|---|---|
| Purpose | Daily development + verification | Air-gapped deployment |
| Auth | Local JWT / Keycloak OIDC | Local JWT / Keycloak OIDC |
| Database | MariaDB (container sidecar) | MariaDB (external, private network) |
| Internet | Available | None (Nexus proxy for apt/npm) |
| DevContainer | `.devcontainer/onprem/` | `.devcontainer/airgap/` |

---

## Documentation Navigation

Choose your starting point based on your role:

| Role | Start Here | Then Read |
|------|-----------|-----------|
| **New Developer** | [DOCKER-GUIDE.md](DOCKER-GUIDE.md) — Docker concepts for beginners | [ONPREM_SOP.md](infrastructure/docs/ONPREM_SOP.md) — Full dev setup |
| **Deployer** | [AIRGAP_SOP.md](infrastructure/docs/AIRGAP_SOP.md) — Air-gapped deployment | — |
| **Architect** | [LEARN.md](LEARN.md) — Technical decisions and rationale | [PLATFORM_GUIDE.md](src/platform/PLATFORM_GUIDE.md) — Platform/App separation |
| **Architect (system design)** | [SDD.md](SDD.md) — System Design Document (PDX-aligned, dual-state ONPREM/AIRGAP architecture) | [frontend-rules/frontend-rules.md](frontend-rules/frontend-rules.md) — Frontend rules (FMB canonical) |
| **SSO Admin** | [KEYCLOAK_GUIDE.md](infrastructure/docs/KEYCLOAK_GUIDE.md) — Keycloak OIDC integration | — |

### API Documentation (v3.0.0)

Interactive API docs powered by [Scalar](https://scalar.com) + OpenAPI 3.0:

| URL | Service | Content |
|-----|---------|---------|
| `https://localhost:3200/api/docs` | API-infra | Frontend-facing `/api/*` endpoints (35 paths) |
| `http://localhost:3201/edge/docs` | API-edge | DB-facing `/edge/*` endpoints (43 paths) |
| `https://localhost:3200/api/openapi.json` | API-infra | Raw OpenAPI spec (for SDK generation) |
| `http://localhost:3201/edge/openapi.json` | API-edge | Raw OpenAPI spec (for SDK generation) |

> API-edge docs require the edge service running (`S2S_API_KEY` configured, `API_ROLE=edge`).
> Scalar UI is self-hosted (no CDN dependency) and disabled in production (`NODE_ENV=production`).
> Raw OpenAPI JSON specs are always available regardless of environment.

### Other Documents

| Document | Purpose |
|----------|---------|
| [CLAUDE.md](CLAUDE.md) | AI collaboration instructions and project rules |
| [CHANGELOG.md](CHANGELOG.md) | Version history and breaking changes |
| [docker-api/README.md](docker-api/README.md) | Express API documentation |
| [TRANSFORMERS.md](src/fmb/lib/transformers/TRANSFORMERS.md) | Transformer development guide (file + DB) |
| [TRANSFORMER-ADMIN-GUIDE.md](src/fmb/lib/transformers/TRANSFORMER-ADMIN-GUIDE.md) | DB transformer admin UI guide |
| [capacity-planner-design.md](docs/superpowers/specs/2026-07-11-capacity-planner-design.md) | Capacity Planner module design spec, original PR-A…F rollout (data-center capacity/placement tool; see SDD §7.10) — **partially superseded**, see the row below |
| [capacity-config-rewrite-design.md](docs/superpowers/specs/2026-07-14-capacity-config-rewrite-design.md) | Capacity Planner config-rewrite spec (reference model, six-keeper rules, first-class Databases, team-color canvas amendment; §18 is the section-by-section supersession map against the 07-11 spec above) |

---

## Quick Start (ONPREM)

```bash
# 1. Clone
git clone <repository-url>
cd flexible_mold_base

# 2. Configure DevContainer environment
cp .devcontainer/onprem/.env.example .devcontainer/.env
# Edit .devcontainer/.env — set DB_RW_PASSWORD, DB_ROOT_PASSWORD.
# Canonical writer credentials are DB_RW_* (v3.2.32a+); the legacy
# DB_HOST / DB_PORT / DB_USER / DB_PASSWORD aliases were removed in v3.2.47.
# For the optional read-replica simulation also set DB_RO_HOST + DB_RO_PORT;
# omit to route reads through the writer. See
# infrastructure/docs/ENV_PLACEMENT.md.

# 3. Open in VS Code DevContainer
# Ctrl+Shift+P → "Dev Containers: Reopen in Container" → select ONPREM

# 4. Inside the container
npm run dev:local          # Frontend on http://localhost:3000
cd docker-api && npm run dev  # API on http://localhost:3200

# 5. First-time setup (6-step wizard with smart step-skipping)
# Open http://localhost:3000/setup and follow the wizard
# Steps: Env Detect → DB Connect → Schema Init → Seed Data → SSO → Admin

# 6. Run E2E tests (optional, requires Playwright)
npx playwright install --with-deps chromium
npx playwright test
```

For production verification, see [ONPREM_SOP.md](infrastructure/docs/ONPREM_SOP.md).

---

### K8s local simulation (Q3 cutover rehearsal)

One-shot: `cd infrastructure/k8s/cluster && bash setup.sh` brings up k3d cluster + Istio + Vault + ArgoCD + GitLab CE + 3 zones. Daily dev loop: `bash infrastructure/k8s/cluster/port-forwards.sh --zones=test` then open `http://localhost:8130/` (seed admin credentials printed by setup.sh).

Full recipe + Q3 translation table: [`infrastructure/docs/LOCAL_CICD_RECIPE.md`](infrastructure/docs/LOCAL_CICD_RECIPE.md).

---

## Admin — MariaDB Privileges UI (v3.2.32b+)

System → **Privileges** tab (admin-only, ONPREM / AIRGAP only). Lets a DBA session (one holding `GRANT OPTION`) grant or revoke DML privileges (`SELECT`, `INSERT`, `UPDATE`, `DELETE`, `REFERENCES`, `LOCK TABLES`, `EXECUTE`) on `fmb_*` tables to MariaDB service accounts such as `appuser_rw` / `appuser_ro`. Every attempt is audit-logged via a 2-phase pattern (pending → success / fail) in `feature_audit` with correlation IDs; the tab ships a CSV export.

Safety:
- **Self-guard** — refuses to operate on `CURRENT_USER()` (SUBSTRING_INDEX-stripped) or any username matching `DB_RW_USER` / `DB_RO_USER` (409 `SELF_GUARDED`). Client-side hints mirror the check.
- **Read-only mode** — if the MariaDB session lacks `GRANT OPTION`, the matrix is disabled with a remediation banner.
- **DDL blocked** — `CREATE`, `ALTER`, `DROP`, `GRANT OPTION`, `SUPER`, `FILE`, `PROCESS`, `CREATE USER`, etc. are rejected at the allowlist layer; DDL must be run by the DBA via the MariaDB CLI.
- **Identifier allowlist** — target username matches `/^[a-zA-Z_][a-zA-Z0-9_]{0,31}$/` both client and server.

Endpoints (admin-only, forwarded via `/api/admin/privileges/*` → `/edge/platform/privileges/*`): `GET /current-user`, `GET /users`, `GET /grants/:user`, `POST /grant`, `POST /revoke`, `GET /audit`, `GET /audit.csv`.

---

## Project Structure (post v2.1.0 cleanup)

```
src/
├── platform/                       # Reusable infrastructure
│   ├── components/
│   │   ├── connection-profiles/    # PR 4 — ConnectionProfilesTab decomposed
│   │   │   ├── ConnectionProfilesTab.tsx   (container)
│   │   │   ├── DatabaseServerSection.tsx   (server + schema + data sync)
│   │   │   ├── ProfileList.tsx             (list + details)
│   │   │   ├── ProfileFormDialog.tsx       (new / edit modal)
│   │   │   ├── ProfileTestButton.tsx       (PR 1.5 Lovable spike)
│   │   │   ├── api.ts                      (setupFetch / syncFetch)
│   │   │   └── types.ts                    (ServerConfig, ProfileFormState)
│   │   └── admin/                  (AuthSettingsTab, AccessRulesPanel, …)
│   ├── lib/
│   │   ├── http-client.ts          # PR 2 — platformFetch + ApiError (MF1-3, MF5)
│   │   ├── env.ts                  # PR 2 — identity + capability helpers (Q13)
│   │   ├── api-client.ts           (thin wrapper over platformFetch)
│   │   ├── schema-client.ts        (thin wrapper over platformFetch)
│   │   ├── auth-headers.ts / auth-mode.ts
│   │   └── adapters/auth/          (Supabase, SSO)
│   ├── hooks/
│   └── types/
├── fmb/                            # Business logic
│   ├── components/
│   │   └── admin/
│   │       └── transformer-editor/ # PR 4 — TransformerEditor decomposed
│   │           ├── TransformerEditor.tsx   (container)
│   │           ├── EditorToolbar.tsx       (toolbar + test cases popover)
│   │           ├── CodePanes.tsx           (3-panel CodeMirror layout)
│   │           ├── GuardScreens.tsx        (loading / error / mobile)
│   │           ├── SaveDialog.tsx
│   │           ├── ResizeHandle.tsx
│   │           └── helpers.ts              (types + DEFAULT_CODE + parser)
│   ├── pages/
│   └── lib/transformers/
└── components/ui/                  # shadcn/ui primitives

docker-api/
└── src/
    ├── shared/                     # Both processes
    ├── infra/                      # API-infra: auth middleware, remote-client
    └── edge/                       # API-edge: DB + route handlers
        ├── middleware/s2s-verify.js
        └── routes/
            ├── platform/
            │   └── setup/          # PR 3b — setup.js (1209) → 8 files
            └── app/
                └── transformers/   # PR 3b — transformers.js (1024) → 5 files

.devcontainer/
├── Dockerfile.dev                  (shared dev image)
├── docker-compose.yml              (base compose)
├── onprem/                         (ONPREM config)
└── airgap/                         (AIRGAP config + override)

infrastructure/
├── docs/                           (deployment SOPs)
└── scripts/docker-clean.sh         (force-stop + volume cleanup)

e2e/
├── fixtures/test-helpers.ts        (v2.1.0 self-heal + auth-mode detect)
├── setup-api.spec.ts               (PR 3a — 10 safety-net specs)
└── run-e2e.sh                      (SSO-admin recovery + lifecycle)
```

Every file above sits below the 800-line ceiling defined in CLAUDE.md.
See `src/platform/PLATFORM_GUIDE.md` for the client API reference
(`platformFetch`, `env` capability helpers, sonner toast, component split
rules from `docs/archive/LEARN_archive.md` §38) and
`docs/archive/CHANGELOG_v3.2.x.md` v2.1.0 for the full cleanup sprint summary.
