// Assembles a multi-entry favicon.ico from three already-rasterised PNGs and
// re-parses the result to prove the container round-trips.
//
// WHY THIS EXISTS INSTEAD OF AN IMAGE-TOOL ONE-LINER
// The three entries are NOT the same drawing at three sizes: the 16px entry is
// a separate, simplified drawing (see README.md). A tool that takes one source
// and downscales it would silently discard that. This script takes three
// independent PNGs and writes each one into its own ICONDIRENTRY untouched.
//
// Usage:
//   node build-ico.mjs <16.png> <32.png> <48.png> <out.ico>
// Exit: 0 written + verified, 1 bad input.

import fs from 'node:fs';

const [png16Path, png32Path, png48Path, outPath] = process.argv.slice(2);
if (!png16Path || !png32Path || !png48Path || !outPath) {
  console.error('Usage: node build-ico.mjs <16.png> <32.png> <48.png> <out.ico>');
  process.exit(1);
}

const ENTRIES = [
  { size: 16, file: png16Path },
  { size: 32, file: png32Path },
  { size: 48, file: png48Path },
];

/** Reads width/height/bitDepth/colorType straight out of the PNG IHDR chunk. */
function readPngDims(buf) {
  // PNG signature (8 bytes) then IHDR: length(4) type(4) width(4) height(4) ...
  if (buf.readUInt32BE(0) !== 0x89504e47 || buf.readUInt32BE(4) !== 0x0d0a1a0a) {
    throw new Error('not a valid PNG signature');
  }
  return {
    width: buf.readUInt32BE(16),
    height: buf.readUInt32BE(20),
    bitDepth: buf.readUInt8(24),
    colorType: buf.readUInt8(25),
  };
}

function buildIco(entries) {
  const pngBuffers = entries.map((e) => fs.readFileSync(e.file));
  const HEADER_SIZE = 6;
  const DIR_ENTRY_SIZE = 16;
  let offset = HEADER_SIZE + DIR_ENTRY_SIZE * entries.length;

  const header = Buffer.alloc(HEADER_SIZE);
  header.writeUInt16LE(0, 0); // reserved
  header.writeUInt16LE(1, 2); // type = 1 (icon)
  header.writeUInt16LE(entries.length, 4); // image count

  const dirBuffers = [];
  for (let i = 0; i < entries.length; i++) {
    const e = entries[i];
    const png = pngBuffers[i];
    const dims = readPngDims(png);
    if (dims.width !== e.size || dims.height !== e.size) {
      throw new Error(`${e.file}: PNG IHDR reports ${dims.width}x${dims.height}, expected ${e.size}x${e.size}`);
    }
    const entryBuf = Buffer.alloc(DIR_ENTRY_SIZE);
    // A width/height byte of 0 means 256 in the ICO spec; every size here is
    // below 256 so the literal value is written.
    entryBuf.writeUInt8(e.size >= 256 ? 0 : e.size, 0);
    entryBuf.writeUInt8(e.size >= 256 ? 0 : e.size, 1);
    entryBuf.writeUInt8(0, 2); // colour count (0 = no palette, true colour)
    entryBuf.writeUInt8(0, 3); // reserved
    entryBuf.writeUInt16LE(1, 4); // colour planes (1 by PNG-in-ICO convention)
    entryBuf.writeUInt16LE(32, 6); // bits per pixel (32 = RGBA)
    entryBuf.writeUInt32LE(png.length, 8);
    entryBuf.writeUInt32LE(offset, 12);
    dirBuffers.push(entryBuf);
    offset += png.length;
  }

  return Buffer.concat([header, ...dirBuffers, ...pngBuffers]);
}

function parseIco(buf) {
  const count = buf.readUInt16LE(4);
  const entries = [];
  for (let i = 0; i < count; i++) {
    const base = 6 + i * 16;
    const widthByte = buf.readUInt8(base + 0);
    const heightByte = buf.readUInt8(base + 1);
    const bytesInRes = buf.readUInt32LE(base + 8);
    const imageOffset = buf.readUInt32LE(base + 12);
    const payload = buf.subarray(imageOffset, imageOffset + bytesInRes);
    const dims = readPngDims(payload);
    entries.push({
      index: i,
      declaredWidth: widthByte === 0 ? 256 : widthByte,
      declaredHeight: heightByte === 0 ? 256 : heightByte,
      bytesInRes,
      imageOffset,
      payloadIsPng: payload[0] === 0x89 && payload[1] === 0x50,
      pngReportedWidth: dims.width,
      pngReportedHeight: dims.height,
    });
  }
  return { reserved: buf.readUInt16LE(0), type: buf.readUInt16LE(2), count, entries };
}

const buf = buildIco(ENTRIES);
fs.writeFileSync(outPath, buf);

// Re-read from disk rather than trusting the in-memory buffer: the point of the
// check is that what landed on disk parses back to three distinct PNG payloads.
const parsed = parseIco(fs.readFileSync(outPath));
console.log(JSON.stringify({ totalBytes: buf.length, ...parsed }, null, 2));
