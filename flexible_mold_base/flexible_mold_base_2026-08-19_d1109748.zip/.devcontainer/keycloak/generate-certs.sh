#!/usr/bin/env bash
# =============================================================================
# generate-certs.sh — Generate self-signed TLS certificates for dev HTTPS.
#
# Creates a local CA + server certificate for Keycloak and the Express API.
# Uses mkcert if available, otherwise falls back to openssl.
#
# Output directory: .devcontainer/keycloak/certs/
#   ca.pem          — CA certificate (trust in browser + NODE_EXTRA_CA_CERTS)
#   server.pem      — Server certificate
#   server-key.pem  — Server private key
#
# Usage:
#   chmod +x .devcontainer/keycloak/generate-certs.sh
#   ./.devcontainer/keycloak/generate-certs.sh
# =============================================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
CERT_DIR="${SCRIPT_DIR}/certs"
DOMAINS="localhost,keycloak,127.0.0.1,::1"

mkdir -p "${CERT_DIR}"

# Check if certs already exist
if [ -f "${CERT_DIR}/server.pem" ] && [ -f "${CERT_DIR}/server-key.pem" ]; then
  echo "[generate-certs] Certificates already exist in ${CERT_DIR}"
  echo "[generate-certs] Delete them first if you want to regenerate."
  exit 0
fi

echo "[generate-certs] Generating TLS certificates for: ${DOMAINS}"

if command -v mkcert &>/dev/null; then
  echo "[generate-certs] Using mkcert"

  # Install local CA if not already done
  mkcert -install 2>/dev/null || true

  # Generate cert
  mkcert -cert-file "${CERT_DIR}/server.pem" \
         -key-file "${CERT_DIR}/server-key.pem" \
         localhost keycloak 127.0.0.1 ::1

  # Copy the CA cert for NODE_EXTRA_CA_CERTS
  CAROOT=$(mkcert -CAROOT)
  cp "${CAROOT}/rootCA.pem" "${CERT_DIR}/ca.pem"

  echo "[generate-certs] mkcert certs generated successfully"
else
  echo "[generate-certs] mkcert not found — falling back to openssl"

  # Generate CA
  openssl req -x509 -new -nodes \
    -keyout "${CERT_DIR}/ca-key.pem" \
    -out "${CERT_DIR}/ca.pem" \
    -days 3650 \
    -subj "/CN=DevContainer Local CA"

  # Generate server key + CSR
  openssl req -new -nodes \
    -keyout "${CERT_DIR}/server-key.pem" \
    -out "${CERT_DIR}/server.csr" \
    -subj "/CN=localhost"

  # Create SAN extension file
  cat > "${CERT_DIR}/san.ext" <<EOF
authorityKeyIdentifier=keyid,issuer
basicConstraints=CA:FALSE
keyUsage=digitalSignature,nonRepudiation,keyEncipherment,dataEncipherment
subjectAltName=DNS:localhost,DNS:keycloak,IP:127.0.0.1,IP:::1
EOF

  # Sign with CA
  openssl x509 -req \
    -in "${CERT_DIR}/server.csr" \
    -CA "${CERT_DIR}/ca.pem" \
    -CAkey "${CERT_DIR}/ca-key.pem" \
    -CAcreateserial \
    -out "${CERT_DIR}/server.pem" \
    -days 825 \
    -extfile "${CERT_DIR}/san.ext"

  # Cleanup temp files
  rm -f "${CERT_DIR}/server.csr" "${CERT_DIR}/san.ext" "${CERT_DIR}/ca.srl"

  echo "[generate-certs] openssl self-signed certs generated successfully"
fi

echo ""
echo "=== Certificate files ==="
echo "  CA cert:     ${CERT_DIR}/ca.pem"
echo "  Server cert: ${CERT_DIR}/server.pem"
echo "  Server key:  ${CERT_DIR}/server-key.pem"
echo ""
echo "=== Next steps ==="
echo "  1. Set NODE_EXTRA_CA_CERTS=${CERT_DIR}/ca.pem in your .env"
echo "  2. Set KEYCLOAK_CA_CERT_PATH=${CERT_DIR}/ca.pem"
echo "  3. Trust the CA in your browser:"
echo "     - Windows: certutil -addstore Root ${CERT_DIR}/ca.pem"
echo "     - Linux:   sudo cp ${CERT_DIR}/ca.pem /usr/local/share/ca-certificates/devcontainer-ca.crt && sudo update-ca-certificates"
echo "     - WSL2:    Do BOTH host (Windows certutil) and container (update-ca-certificates)"
