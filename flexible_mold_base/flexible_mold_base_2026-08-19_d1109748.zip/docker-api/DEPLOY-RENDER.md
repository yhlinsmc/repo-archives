# Deploying to Render (Free Tier)

This document covers deploying the `docker-api` Express API to Render Free Tier.
The API handles MariaDB connections, user management, schema CRUD, and query proxy.

---

## About render.yaml

`docker-api/render.yaml` is a Render Blueprint reference file. **It is not auto-detected
by Render** — Render only scans the repo root for `render.yaml`. Use it as a reference
when configuring env vars manually in the Render Dashboard.

---

## Prerequisites

- Render account (free): https://render.com
- A MariaDB instance accessible from the internet (e.g. Aiven, your own VPS)
- This repository pushed to GitHub or GitLab

---

## Deployment Steps

### 1. Create a New Web Service

1. Go to Render Dashboard → **New** → **Web Service**
2. Connect your GitHub/GitLab repository
3. Set the following:
   - **Root Directory**: `docker-api`   ← **important**: must be set, not empty
   - **Runtime**: Docker
   - **Dockerfile Path**: `Dockerfile`  ← relative to Root Directory above
   - **Instance Type**: Free

   > Why: `docker-api/Dockerfile` uses `COPY . .` which copies the build context.
   > Setting Root Directory to `docker-api` ensures the context is the API directory,
   > not the repo root (which contains the React frontend `src/` instead).

### 2. Set Environment Variables

#### Required

| Key | Value | Notes |
|-----|-------|-------|
| `JWT_SECRET` | *(click "Generate" in Render)* | Backend-only secret for signing JWT tokens. The frontend never needs this value. |
| `CORS_ORIGINS` | `https://your-app.lovable.app` | Comma-separated list of allowed origins. |

#### Optional (safe defaults already in code)

| Key | Default | Notes |
|-----|---------|-------|
| `PORT` | `3200` | Render exposes the service port automatically. |
| `NODE_ENV` | — | Set to `production` for production builds. |
| `SERVE_STATIC` | `false` | Default is `false` — no need to set. Render hosts API only; the frontend runs on Lovable. Only set to `true` in single-container ONPREM mode. |
| `DB_TABLE_PREFIX` | `fmb_` | Required. Set explicitly for the schema/table prefix this deployment should use. |

#### DB Connection — choose one approach

**Option A — Env vars (recommended, survives restarts)**

| Key | Value | Notes |
|-----|-------|-------|
| `DB_RW_HOST` | *(your MariaDB writer host)* | |
| `DB_RW_PORT` | `3306` | |
| `DB_RW_USER` | *(your DB user)* | |
| `DB_RW_PASSWORD` | *(your DB password)* | Mark as **Secret** (or use `DB_RW_PASSWORD_ENCRYPTED`) |
| `DB_NAME` | *(your database name)* | |

**Option B — Frontend setup (testing only, lost on restart)**

Skip the DB_* vars. After deployment, go to:
UI → Settings → First Setup → Configure DB → enter credentials manually.

> ⚠️ Render Free Tier has no persistent disk. Config saved via the UI
> (`data/db-config.json`) is wiped on every restart. Use Option A for persistence.

### 3. Deploy

Click **Create Web Service**. Render will build the Docker image and deploy.
Initial build takes ~3-5 minutes.

### 4. Verify

```bash
# Health check
curl https://your-service.onrender.com/health

# With DB_* env vars set:    { "api": "ok", "db": "ok" }
# Without DB_* env vars:     { "api": "ok", "db": "not_configured" }
```

### 5. Configure Lovable UI

In your Lovable app → Settings → Connection Profiles:
1. Create a new **CUSTOM_API** profile
2. Set **Base URL**: `https://your-service.onrender.com`
3. Enable **Mock Auth** for development (bypasses JWT verification)
4. Activate the profile

---

## Free Tier Limitations

| Limitation | Details |
|-----------|---------|
| **Sleep after inactivity** | Service sleeps after ~15 minutes of no requests. First request after sleep takes 30-60s to wake up. |
| **No persistent disk** | `data/db-config.json` is ephemeral. Always set `DB_*` env vars for persistence across restarts. |
| **750 free hours/month** | Enough for a single always-on service. |
| **Shared CPU** | Suitable for low-traffic development use. |

## CORS_ORIGINS Format

```
# Single origin
https://your-app.lovable.app

# Multiple origins (comma-separated)
https://your-app.lovable.app,https://preview.lovable.app
```

Leave unset to allow all origins — acceptable for initial testing, not recommended for production.

---

## Troubleshooting

**`/health` returns `{ "db": "not_configured" }`** — Expected when DB_* env vars are not set. API is in setup-required mode. Configure via UI First Setup or set DB_* env vars.

**`/health` returns `{ "db": "error: ..." }`** — DB_* vars are set but the DB is unreachable. Check firewall rules on your DB host.

**"Database not configured" on non-health endpoints** — DB setup not yet complete. Run First Setup or set DB_* env vars.

**CORS errors in browser** — Add your Lovable app's exact origin (with `https://`) to `CORS_ORIGINS`.

**504 timeout on first request** — Free tier sleep. Wait ~60 seconds and retry.
