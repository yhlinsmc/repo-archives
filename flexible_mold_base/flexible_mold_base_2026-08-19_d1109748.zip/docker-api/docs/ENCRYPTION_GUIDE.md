# Encryption Guide

Canonical entry point for everything related to at-rest encryption in
flexible_mold_base. Whenever another doc mentions encryption, it should
link here rather than re-explaining.

> **Status**: canonical as of v3.2.53 (2026-04). Supersedes scattered
> comments in `.env.example` files and `infrastructure/docs/ENV_PLACEMENT.md`
> (those now point here).

---

## What gets encrypted

| Value | Variable | Where it lives | Decrypted by |
|---|---|---|---|
| Writer DB password | `DB_RW_PASSWORD_ENCRYPTED` | docker-api/.env, Vault, K8s Secret | api-edge boot (config-schema.js) |
| Reader DB password | `DB_RO_PASSWORD_ENCRYPTED` | docker-api/.env, Vault, K8s Secret | api-edge boot (config-schema.js) |
| `system_settings` sensitive values | stored in MariaDB | MariaDB `system_settings.value` rows | settings handlers (read path) |
| `db_connections.encrypted_password` | stored in MariaDB | MariaDB `db_connections` rows | setup flow + runtime pool reconfig (v3.2.53 PR-2 wires the UI → DB write path) |

All ciphertext uses the `enc:v1:<iv-hex>:<tag-hex>:<ct-hex>` format from
`docker-api/src/shared/lib/settings-crypto.js`. Algorithm: AES-256-GCM with
a 12-byte random IV and 16-byte authentication tag. Every field is
hex-encoded — **not base64**. Operators inspecting the blob with base64
decode tools will get garbage; use `xxd -r -p` or the `Buffer.from(..., 'hex')`
pattern if you need to debug bytes directly.

---

## The one thing operators get wrong

**Running `encrypt-env-value.js` twice on the same plaintext produces two
different ciphertexts.** This is expected. AES-GCM requires a unique IV per
encryption for the same key, so the IV is randomly generated every run.
Both outputs decrypt to the same plaintext under the same
`SETTINGS_ENCRYPTION_KEY`. The CLI prints an educational footer on TTY runs
to reinforce this.

If two runs produced identical ciphertext for the same plaintext, that
would be a security bug (IV reuse breaks GCM confidentiality and
authentication).

---

## Generating encrypted values

**Prefer pipe mode.** Passing the plaintext as an argv argument exposes it
briefly in `ps aux` / `/proc/<pid>/cmdline` output on Linux. On a
single-user laptop DevContainer the blast radius is small, but on any
shared host (CI runner, ops VM, bastion) another user can read the
plaintext during the ~50ms the script runs. Default to pipe mode:

```bash
# Inside the DevContainer workspace shell — preferred:
echo -n 'MyPlaintext' | SETTINGS_ENCRYPTION_KEY=<key> \
  node docker-api/scripts/encrypt-env-value.js
# → enc:v1:<iv-hex>:<tag-hex>:<ct-hex>
```

Argv mode (only on a single-user machine you trust):

```bash
SETTINGS_ENCRYPTION_KEY=<key> node docker-api/scripts/encrypt-env-value.js 'MyPlaintext'
```

Help:

```bash
node docker-api/scripts/encrypt-env-value.js --help
```

### UX guards (v3.2.53 Q2)

- `--help` / `-h` prints usage to stderr and exits 0.
- No argument + stdin is a TTY (interactive shell) → fast-fails with usage
  instead of hanging forever waiting for piped input.
- After a successful encrypt, stdout TTY → stderr gets an educational
  footer explaining paste destinations and the random-IV semantics.
  Non-TTY (pipe/redirect) runs stay clean so command substitution works:
  ```bash
  ENC=$(SETTINGS_ENCRYPTION_KEY=<key> node docker-api/scripts/encrypt-env-value.js 'pass')
  # $ENC contains only "enc:v1:..." — no footer.
  ```

---

## Env placement (v3.2.53 Q3)

The DevContainer `.devcontainer/docker-compose.yml` explicitly allowlists
these three variables into **both** `workspace` and `api-edge` services:

```yaml
environment:
  - SETTINGS_ENCRYPTION_KEY=${SETTINGS_ENCRYPTION_KEY:-}
  - DB_RW_PASSWORD_ENCRYPTED=${DB_RW_PASSWORD_ENCRYPTED:-}
  - DB_RO_PASSWORD_ENCRYPTED=${DB_RO_PASSWORD_ENCRYPTED:-}
```

Not `env_file: docker-api/.env`. That would leak unrelated secrets
(`JWT_SECRET`, `S2S_API_KEY`, Keycloak values) into the workspace
container. Those stay dotenv-only.

### Compose empty-string footgun

`${VAR:-}` in the compose `environment:` block resolves to an empty string
when `VAR` is unset in both `.devcontainer/.env` and the host shell. An
empty `DB_RW_PASSWORD_ENCRYPTED=""` is passed into the api-edge container,
where `config-schema.js`'s decrypt loop treats an empty string as "not
set" (falsy, `if (!encValue) continue`) and **silently skips decryption**.
The pool then falls back to whatever plaintext `DB_RW_PASSWORD` holds.

In practice this degrades to a boot failure (MariaDB rejects the empty
password) rather than a silent wrong-credential fallback — but the
failure mode is an opaque connection error, not "your encrypted env var
was ignored". Diagnostic recipe when boot fails:

```bash
docker compose -f .devcontainer/docker-compose.yml exec api-edge \
  printenv DB_RW_PASSWORD_ENCRYPTED
# If this prints an empty line, the host did not export the value.
```

### SETTINGS_ENCRYPTION_KEY scope per environment

| Environment | workspace | api-edge | Notes |
|---|---|---|---|
| DevContainer (ONPREM) | ✅ | ✅ | Operator convenience (run encrypt-env-value.js without manual export) |
| DevContainer (AIRGAP) | ✅ | ✅ | Same as ONPREM |
| K8s prod (all zones) | N/A (no workspace pod) | ✅ via `VaultStaticSecret` | Least-privilege — workspace doesn't exist in prod |

Do not log `process.env` inside workspace scripts. Vite doesn't expose
non-`VITE_*` env vars to the bundle, so this key cannot leak through the
frontend build.

---

## Key rotation

1. Generate the new key: `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"`
2. Re-encrypt **every** `_ENCRYPTED` env var currently in use with the new
   key (old ciphertext will not decrypt under the new key).
3. Replace `SETTINGS_ENCRYPTION_KEY` + all re-encrypted ciphertexts in the
   target store (docker-api/.env locally, Vault in K8s) atomically.
4. Restart the process. Boot aborts with `Failed to decrypt ...` if any
   ciphertext was missed.

Never stage "half-rotated" state in prod — partial rotation is a
boot-failure incident, not a graceful degradation.

---

## Related files

- `docker-api/src/shared/lib/settings-crypto.js` — the AES-GCM primitive
  (`encrypt` / `decrypt` / `enc:v1:` format).
- `docker-api/scripts/encrypt-env-value.js` — CLI wrapper.
- `docker-api/src/shared/config-schema.js` — boot-time decrypt-and-inject
  for `DB_RW_PASSWORD_ENCRYPTED` / `DB_RO_PASSWORD_ENCRYPTED`.
- `infrastructure/docs/ENV_PLACEMENT.md` §v3.2.42 + §v3.2.53 — where each
  env var belongs in the K8s deployment matrix.
- `docker-api/src/edge/routes/platform/setup/db-connect.js` — setup
  wizard handler (v3.2.53 PR-2 adds `passwordIsEncrypted` channel).
- `docker-api/src/edge/routes/platform/db_connections/` — CRUD handlers
  for stored connections.
