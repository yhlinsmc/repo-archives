#!/usr/bin/env node
/**
 * encrypt-env-value.js — CLI tool to encrypt a value for use as
 * DB_RW_PASSWORD_ENCRYPTED (canonical v3.2.44+), DB_RO_PASSWORD_ENCRYPTED
 * (v3.2.42+), or any env var that uses settings-crypto.
 *
 * v3.2.53 (Q2): TTY-aware UX hints. Interactive runs get an educational
 * footer on stderr explaining AES-256-GCM random-IV semantics (running
 * again yields different ciphertext for the same plaintext — both decrypt
 * to the same value). Pipe / non-TTY runs stay clean so the ciphertext
 * can be assigned or piped directly.
 *
 * v3.2.7.5: Encrypts a plaintext value using the same AES-256-GCM
 * algorithm as settings-crypto.js.
 *
 * Usage:
 *   SETTINGS_ENCRYPTION_KEY=<key> node scripts/encrypt-env-value.js <plaintext>
 *   echo <plaintext> | SETTINGS_ENCRYPTION_KEY=<key> node scripts/encrypt-env-value.js
 *   node scripts/encrypt-env-value.js --help
 *
 * The SETTINGS_ENCRYPTION_KEY must match what the running server uses.
 * Key rotation: re-encrypt all `_ENCRYPTED` env vars with the new key
 * before restart (old ciphertext won't decrypt under the new key).
 */

const USAGE = [
  'Usage (pipe mode — preferred; plaintext does not appear in `ps`):',
  '  echo -n <plaintext> | SETTINGS_ENCRYPTION_KEY=<key> node scripts/encrypt-env-value.js',
  '',
  'Argv mode (plaintext visible in `ps aux` briefly — prefer pipe):',
  '  SETTINGS_ENCRYPTION_KEY=<key> node scripts/encrypt-env-value.js <plaintext>',
  '',
  'Outputs enc:v1:<iv-hex>:<tag-hex>:<ct-hex> on stdout. Paste into',
  'docker-api/.env as one of:',
  '  DB_RW_PASSWORD_ENCRYPTED=enc:v1:...',
  '  DB_RO_PASSWORD_ENCRYPTED=enc:v1:...',
  '',
  'AES-256-GCM with a 12-byte random IV. Running this script twice on',
  'the same plaintext produces two different ciphertexts — both decrypt',
  'to the same value. This is expected; do not report as a bug.',
  '',
  'Full guide: docker-api/docs/ENCRYPTION_GUIDE.md',
].join('\n');

function isHelpFlag(arg) {
  return arg === '--help' || arg === '-h';
}

async function main() {
  const firstArg = process.argv[2];

  if (firstArg && isHelpFlag(firstArg)) {
    process.stderr.write(USAGE + '\n');
    process.exit(0);
  }

  const key = process.env.SETTINGS_ENCRYPTION_KEY;
  if (!key) {
    process.stderr.write('Error: SETTINGS_ENCRYPTION_KEY env var is required.\n\n');
    process.stderr.write(USAGE + '\n');
    process.exit(1);
  }

  const { encrypt, decrypt } = require('../src/shared/lib/settings-crypto');

  let plaintext = firstArg;

  // No argument: read from stdin. If stdin is a TTY (interactive with no
  // pipe), fail fast with usage instead of hanging waiting for input.
  if (!plaintext) {
    if (process.stdin.isTTY) {
      process.stderr.write('Error: no plaintext provided and stdin is a TTY.\n');
      process.stderr.write('Pass the value as an argument or pipe it via stdin.\n\n');
      process.stderr.write(USAGE + '\n');
      process.exit(1);
    }
    const chunks = [];
    for await (const chunk of process.stdin) chunks.push(chunk);
    plaintext = Buffer.concat(chunks).toString('utf8').trim();
  }

  if (!plaintext) {
    process.stderr.write('Error: no value provided.\n\n');
    process.stderr.write(USAGE + '\n');
    process.exit(1);
  }

  const encrypted = encrypt(plaintext);

  const roundTrip = decrypt(encrypted);
  if (roundTrip !== plaintext) {
    process.stderr.write('Error: round-trip verification failed.\n');
    process.exit(1);
  }

  process.stdout.write(encrypted + '\n');

  // Interactive footer: only when a human is watching stdout. Pipe runs
  // stay clean (`FOO=$(node encrypt-env-value.js "pass")` works without
  // capturing the hint).
  if (process.stdout.isTTY) {
    process.stderr.write('\n');
    process.stderr.write('Paste the line above into docker-api/.env as one of:\n');
    process.stderr.write('  DB_RW_PASSWORD_ENCRYPTED=<enc:v1:...>\n');
    process.stderr.write('  DB_RO_PASSWORD_ENCRYPTED=<enc:v1:...>\n');
    process.stderr.write('\n');
    process.stderr.write('AES-256-GCM random IV: re-running yields a different ciphertext\n');
    process.stderr.write('for the same plaintext. Both decrypt to the same value (expected).\n');
  }
}

main();
