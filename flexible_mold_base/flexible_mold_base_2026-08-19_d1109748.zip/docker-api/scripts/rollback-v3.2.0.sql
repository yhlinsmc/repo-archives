-- =============================================================================
-- rollback-v3.2.0.sql — Emergency rollback for the v3.2.0 schema changes.
-- =============================================================================
--
-- WHEN TO USE
-- ───────────
-- Only if a production deployment of v3.2.0 must be reverted to v3.1.1 and
-- the DTO_MAPPER_ENABLED=false feature flag is NOT acceptable as a
-- workaround. Prefer the feature flag — it disables the v3.2.0 DTO mapper
-- type conversions without touching the schema, and requires no downtime
-- or manual DBA action.
--
--   Workaround (preferred):
--     Set `DTO_MAPPER_ENABLED=false` in docker-api/.env and restart
--     API-edge + API-infra. The backend will go back to returning raw
--     0/1 booleans and MM-DD HH:mm:ss timestamps. The frontend handles
--     both shapes because it was already permissive before PR-B2.
--
--   When the workaround is NOT enough and you need this script:
--     - Downgrading the docker-api container image below v3.2.0 (the
--       older image doesn't know how to handle NULL values in the
--       optional number columns and the is_draft column).
--     - Schema tooling expects v3.1.1 DDL shape for offline backup /
--       restore parity.
--
-- WHAT THIS SCRIPT DOES
-- ─────────────────────
-- 1. Backfills NULL values in the 5 nullable-migrated columns back to 0
--    so the inverse ALTER TABLE can re-enforce NOT NULL. Without this
--    step, MariaDB rejects the ALTER with "Column cannot be null".
-- 2. Drops the v3.2.0 additions (user_templates.is_draft column + index).
-- 3. Clears the platform_schema_version marker so
--    runSchemaMigrations() will re-run on the next startup if v3.2.0
--    is re-deployed.
--
-- The inverse ALTER TABLE statements are provided as SQL comments at
-- the bottom. They are NOT executed by default — run them manually only
-- if the application layer actually needs NOT NULL semantics restored.
-- In almost all real rollback scenarios, leaving the columns as
-- NULLable is safe (the old code just never reads NULL).
--
-- USAGE
-- ─────
--   # Replace __PREFIX__ with your actual table prefix (e.g. fmb_,
--   # example_app_, or whatever DB_TABLE_PREFIX / DB_NAME was configured).
--   # The placeholder convention matches the Setup Wizard seed endpoint
--   # and the sync-schema export endpoint.
--   sed -i "s/__PREFIX__/your_prefix_/g" rollback-v3.2.0.sql
--
--   # Review the substituted file, then run inside a transaction:
--   mariadb -u root -p your_database < rollback-v3.2.0.sql
--
-- PRE-FLIGHT CHECKLIST
-- ────────────────────
--   [ ] Full database backup taken (mysqldump / Percona XtraBackup)
--   [ ] DTO_MAPPER_ENABLED=false workaround considered and ruled out
--   [ ] Downtime window scheduled (the ALTER TABLE statements take
--       metadata locks that can block active traffic)
--   [ ] platform_schema_version known: should be exactly "3.2.0"
--       before running this script
--   [ ] Application containers stopped (or at least drained) so the
--       backfill UPDATEs don't race with live writes
--
-- IDEMPOTENCE
-- ───────────
-- The data-backfill UPDATEs are idempotent (re-running sets already-zero
-- rows to 0, no-op). The DROP COLUMN is idempotent via IF EXISTS. The
-- inverse ALTER TABLE statements at the bottom are NOT idempotent —
-- running them against already-NOT-NULL columns errors. Inspect the
-- current IS_NULLABLE state first:
--
--   SELECT TABLE_NAME, COLUMN_NAME, IS_NULLABLE
--     FROM information_schema.COLUMNS
--    WHERE TABLE_SCHEMA = DATABASE()
--      AND (
--            (TABLE_NAME = '__PREFIX__hierarchy_nodes'        AND COLUMN_NAME = 'sort_order')
--         OR (TABLE_NAME = '__PREFIX__blueprint_fields'       AND COLUMN_NAME = 'order_index')
--         OR (TABLE_NAME = '__PREFIX__field_options'          AND COLUMN_NAME = 'sort_order')
--         OR (TABLE_NAME = '__PREFIX__blueprint_sections'     AND COLUMN_NAME = 'sort_order')
--         OR (TABLE_NAME = '__PREFIX__blueprint_output_order' AND COLUMN_NAME = 'sort_order')
--         OR (TABLE_NAME = '__PREFIX__user_templates'         AND COLUMN_NAME = 'is_draft')
--          );
--
-- =============================================================================

START TRANSACTION;

-- ── Step 1: Backfill NULL → 0 on the 5 Q7 nullable columns ──────────────────
-- These were the INT columns that v3.2.0 PR-B2 flipped from
-- NOT NULL DEFAULT 0 to NULL DEFAULT NULL. Any row that was updated via the
-- v3.2.0 UI after the migration may have left the column as NULL; the inverse
-- ALTER below needs every row to be non-null or MariaDB refuses the change.

UPDATE `__PREFIX__hierarchy_nodes`
   SET sort_order = 0
 WHERE sort_order IS NULL;

UPDATE `__PREFIX__blueprint_fields`
   SET order_index = 0
 WHERE order_index IS NULL;

UPDATE `__PREFIX__field_options`
   SET sort_order = 0
 WHERE sort_order IS NULL;

UPDATE `__PREFIX__blueprint_sections`
   SET sort_order = 0
 WHERE sort_order IS NULL;

UPDATE `__PREFIX__blueprint_output_order`
   SET sort_order = 0
 WHERE sort_order IS NULL;

-- ── Step 2: Drop the user_templates.is_draft column + index ─────────────────
-- PR-B2 added this column and index. Pre-v3.2.0 code has no knowledge of it,
-- so leaving it in place while running the old image is fine too — but a
-- strict downgrade to the v3.1.1 DDL shape requires dropping it.

ALTER TABLE `__PREFIX__user_templates` DROP INDEX IF EXISTS `idx_user_templates_user_draft`;
ALTER TABLE `__PREFIX__user_templates` DROP COLUMN IF EXISTS `is_draft`;

-- ── Step 3: Clear the platform_schema_version marker ────────────────────────
-- runSchemaMigrations() checks this value on startup and skips when
-- version >= PLATFORM_SCHEMA_VERSION. Removing the row lets the next startup
-- re-detect "initial" state and re-apply whatever migrations the current
-- image knows about (harmless because each v3.2.0 migration is guarded by an
-- IS_NULLABLE pre-flight check — they no-op on an already-migrated DB).

DELETE FROM `__PREFIX__system_settings`
 WHERE `key` = 'platform_schema_version';

COMMIT;

-- =============================================================================
-- OPTIONAL: Restore NOT NULL semantics (inverse ALTER TABLE)
-- =============================================================================
--
-- Only run these if the application layer genuinely needs the column to
-- reject NULL values at the database layer. In almost all cases the
-- NULLable shape is a strict superset — the old code path doesn't write
-- NULL, so leaving IS_NULLABLE='YES' is safe and saves the metadata-lock
-- downtime.
--
-- Uncomment and run manually, one at a time, after verifying the
-- corresponding UPDATE above completed with zero remaining NULLs:
--
--   SELECT COUNT(*) FROM `__PREFIX__hierarchy_nodes`        WHERE sort_order  IS NULL;  -- expect 0
--   SELECT COUNT(*) FROM `__PREFIX__blueprint_fields`       WHERE order_index IS NULL;  -- expect 0
--   SELECT COUNT(*) FROM `__PREFIX__field_options`          WHERE sort_order  IS NULL;  -- expect 0
--   SELECT COUNT(*) FROM `__PREFIX__blueprint_sections`     WHERE sort_order  IS NULL;  -- expect 0
--   SELECT COUNT(*) FROM `__PREFIX__blueprint_output_order` WHERE sort_order  IS NULL;  -- expect 0
--
-- ALTER TABLE `__PREFIX__hierarchy_nodes`
--       MODIFY COLUMN `sort_order` INT NOT NULL DEFAULT 0;
--
-- ALTER TABLE `__PREFIX__blueprint_fields`
--       MODIFY COLUMN `order_index` INT NOT NULL DEFAULT 0;
--
-- ALTER TABLE `__PREFIX__field_options`
--       MODIFY COLUMN `sort_order` INT NOT NULL DEFAULT 0;
--
-- ALTER TABLE `__PREFIX__blueprint_sections`
--       MODIFY COLUMN `sort_order` INT NOT NULL DEFAULT 0;
--
-- ALTER TABLE `__PREFIX__blueprint_output_order`
--       MODIFY COLUMN `sort_order` INT NOT NULL DEFAULT 0;
--
-- =============================================================================
