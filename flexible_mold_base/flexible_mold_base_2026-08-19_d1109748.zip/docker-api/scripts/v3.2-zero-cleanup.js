#!/usr/bin/env node
/**
 * v3.2-zero-cleanup.js — v3.2.0 PR-B2 — One-shot cleanup CLI for the
 * historical 0 values left in optional number columns.
 *
 * Background
 * ──────────
 * Before v3.2.0, optional number columns (sort_order, order_index) were
 * declared `INT NOT NULL DEFAULT 0`, so leaving the form input blank
 * recorded the value `0`. After PR-B2 those columns are NULLABLE — but
 * existing rows still hold the legacy `0`. We CANNOT auto-backfill them
 * to NULL because we cannot distinguish "user typed 0 deliberately" from
 * "user left the field blank and the DEFAULT 0 fired". This script gives
 * an admin a chance to inspect each affected row and convert 0 → NULL
 * row-by-row or in a single transaction-wrapped batch.
 *
 * Why a CLI instead of an admin endpoint
 * ──────────────────────────────────────
 * The original plan (Q WriteW6) called for `POST /api/admin/set-null`. The
 * /cso review (Sec Finding 3 CRITICAL) flagged that endpoint as a SQL
 * injection vector via the column-name parameter. Rather than build a
 * column-name whitelist + audit log + UI for a one-time migration, we
 * replaced the endpoint with this CLI. The CLI runs against the same
 * pool as the API, so it is bound by the same database credentials, and
 * because it never accepts column names from HTTP it cannot be probed.
 *
 * Usage
 * ─────
 *   # Dry run (no writes) — list every affected row across every column.
 *   node docker-api/scripts/v3.2-zero-cleanup.js --dry-run
 *
 *   # Single column, single table:
 *   node docker-api/scripts/v3.2-zero-cleanup.js --table blueprint_fields --column order_index --dry-run
 *
 *   # Apply (will prompt for confirmation):
 *   node docker-api/scripts/v3.2-zero-cleanup.js --apply
 *
 *   # Apply non-interactively (CI):
 *   node docker-api/scripts/v3.2-zero-cleanup.js --apply --yes
 *
 * Exit codes
 *   0  success
 *   1  user aborted at confirmation prompt
 *   2  configuration error (e.g. DB not configured)
 *   3  validation error (unknown table or column on the CLI)
 *   4  runtime error (DB query failed)
 */

const path = require('path');
const readline = require('readline');

// dotenv loads docker-api/.env when this script is run from the root.
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });

const { pool, t, isPoolReady, initializeFromConfig, shutdown } = require('../src/edge/db');
const { logger: rootLogger } = require('../src/shared/lib/logger');

const logger = rootLogger.child({ module: 'v3.2-zero-cleanup' });

// Hard-coded allowlist — never accept column names from CLI input directly.
// Each entry is { table, column } in the engine schema.
const TARGETS = Object.freeze([
  { table: 'hierarchy_nodes',        column: 'sort_order'  },
  { table: 'blueprint_fields',       column: 'order_index' },
  { table: 'field_options',          column: 'sort_order'  },
  { table: 'blueprint_sections',     column: 'sort_order'  },
  { table: 'blueprint_output_order', column: 'sort_order'  },
]);

function parseArgs(argv) {
  const args = { dryRun: false, apply: false, yes: false, table: null, column: null };
  for (let i = 2; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--dry-run') args.dryRun = true;
    else if (a === '--apply') args.apply = true;
    else if (a === '--yes') args.yes = true;
    else if (a === '--table') args.table = argv[++i];
    else if (a === '--column') args.column = argv[++i];
    else if (a === '--help' || a === '-h') args.help = true;
    else {
      console.error(`Unknown argument: ${a}`);
      process.exit(3);
    }
  }
  if (!args.dryRun && !args.apply && !args.help) {
    console.error('Specify either --dry-run or --apply');
    process.exit(3);
  }
  return args;
}

function selectTargets(args) {
  if (!args.table && !args.column) return TARGETS;
  return TARGETS.filter((t) =>
    (!args.table || t.table === args.table) &&
    (!args.column || t.column === args.column),
  );
}

function printHelp() {
  console.log(`v3.2.0 zero-cleanup CLI

Usage:
  node docker-api/scripts/v3.2-zero-cleanup.js [--dry-run|--apply] [--table NAME] [--column NAME] [--yes]

Options:
  --dry-run        List affected rows without writing
  --apply          Convert 0 → NULL inside a transaction (prompts for confirmation)
  --yes            Skip confirmation prompt (for CI)
  --table NAME     Limit to one table (default: all engine tables in scope)
  --column NAME    Limit to one column

Targets (allowlist):`);
  for (const { table, column } of TARGETS) {
    console.log(`  - ${table}.${column}`);
  }
}

async function countAffected(conn, table, column) {
  const physicalTable = t(table);
  const rows = await conn.query(
    `SELECT COUNT(*) AS cnt FROM \`${physicalTable}\` WHERE \`${column}\` = 0`,
  );
  return Number(rows[0].cnt) || 0;
}

async function listAffected(conn, table, column, limit = 10) {
  const physicalTable = t(table);
  const rows = await conn.query(
    `SELECT id, \`${column}\` AS value FROM \`${physicalTable}\` WHERE \`${column}\` = 0 LIMIT ?`,
    [limit],
  );
  return rows;
}

async function applyCleanup(conn, table, column) {
  const physicalTable = t(table);
  const result = await conn.query(
    `UPDATE \`${physicalTable}\` SET \`${column}\` = NULL WHERE \`${column}\` = 0`,
  );
  return Number(result.affectedRows) || 0;
}

async function confirm(prompt) {
  return new Promise((resolve) => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    rl.question(`${prompt} [y/N] `, (answer) => {
      rl.close();
      resolve(/^y(es)?$/i.test(answer.trim()));
    });
  });
}

async function main() {
  const args = parseArgs(process.argv);
  if (args.help) {
    printHelp();
    process.exit(0);
  }

  // Boot the pool the same way the server does so the script obeys the
  // same `data/db-config.json` / env-var precedence.
  await initializeFromConfig();
  if (!isPoolReady()) {
    console.error('ERROR: DB pool is not configured. Run the API server once to populate db-config.json or set DB_HOST/DB_USER/etc. in env.');
    process.exit(2);
  }

  const targets = selectTargets(args);
  if (!targets.length) {
    console.error('No targets selected after applying --table/--column filters. Aborting.');
    process.exit(3);
  }

  console.log('═══════════════════════════════════════════');
  console.log('v3.2.0 Zero Cleanup');
  console.log(`Mode: ${args.apply ? 'APPLY (will write)' : 'DRY-RUN (read only)'}`);
  console.log('═══════════════════════════════════════════');

  const conn = await pool.getConnection();
  let totalAffected = 0;
  const summary = [];
  try {
    for (const { table, column } of targets) {
      try {
        const count = await countAffected(conn, table, column);
        summary.push({ table, column, count });
        totalAffected += count;
        if (count === 0) {
          console.log(`  ✓ ${table}.${column}: 0 rows`);
          continue;
        }
        console.log(`  • ${table}.${column}: ${count} rows`);
        const sample = await listAffected(conn, table, column, 5);
        for (const row of sample) {
          console.log(`      └─ id=${row.id} value=${row.value}`);
        }
        if (count > 5) console.log(`      └─ ... ${count - 5} more`);
      } catch (err) {
        console.error(`  ✗ ${table}.${column}: ${err.message}`);
        if (process.env.DEBUG) console.error(err);
      }
    }
  } finally {
    conn.release();
  }

  console.log('───────────────────────────────────────────');
  console.log(`Total affected rows: ${totalAffected}`);
  console.log('───────────────────────────────────────────');

  if (totalAffected === 0) {
    console.log('Nothing to do. All targets clean.');
    await shutdown();
    process.exit(0);
  }

  if (args.dryRun) {
    console.log('Dry-run complete. Re-run with --apply to convert 0 → NULL.');
    await shutdown();
    process.exit(0);
  }

  // APPLY mode
  if (!args.yes) {
    const ok = await confirm(
      `About to convert ${totalAffected} rows from 0 → NULL across ${summary.filter((s) => s.count > 0).length} columns. Proceed?`,
    );
    if (!ok) {
      console.log('Aborted by user.');
      await shutdown();
      process.exit(1);
    }
  }

  const conn2 = await pool.getConnection();
  let applied = 0;
  try {
    await conn2.beginTransaction();
    for (const { table, column, count } of summary) {
      if (count === 0) continue;
      const n = await applyCleanup(conn2, table, column);
      applied += n;
      console.log(`  ✓ ${table}.${column}: cleared ${n} rows`);
    }
    await conn2.commit();
  } catch (err) {
    try { await conn2.rollback(); } catch {}
    console.error('ERROR: transaction rolled back:', err.message);
    if (process.env.DEBUG) console.error(err);
    await shutdown();
    process.exit(4);
  } finally {
    conn2.release();
  }

  console.log('═══════════════════════════════════════════');
  console.log(`Cleanup applied. Total rows cleared: ${applied}`);
  console.log('═══════════════════════════════════════════');
  // Audit-log this run via the new feature_audit table (best effort).
  try {
    const conn3 = await pool.getConnection();
    try {
      await conn3.query(
        `INSERT INTO \`${t('feature_audit')}\` (id, event_type, user_id, metadata)
         VALUES (UUID(), 'zero-cleanup.ran', NULL, ?)`,
        [JSON.stringify({ applied, summary })],
      );
    } finally {
      conn3.release();
    }
  } catch (err) {
    logger.warn({ err }, 'feature_audit log skipped (table missing or pool closing)');
  }

  await shutdown();
}

main().catch((err) => {
  console.error('FATAL:', err.message);
  if (process.env.DEBUG) console.error(err);
  process.exit(4);
});
