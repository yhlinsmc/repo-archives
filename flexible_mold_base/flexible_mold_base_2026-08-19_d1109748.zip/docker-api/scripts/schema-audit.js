#!/usr/bin/env node
/**
 * schema-audit.js — v3.2.3 Phase 2 — READ-ONLY schema drift detector.
 *
 * Purpose
 * ───────
 * Cross-reference the dto-mapper.js per-table registry (BOOLEAN_COLUMNS /
 * JSON_COLUMNS / TIMESTAMP_COLUMNS) against MariaDB's information_schema.
 * Surfaces columns whose physical type looks like it *should* be mapped
 * (JSON, TEXT variants, BLOB, large VARCHAR) but which the registry never
 * learned about — a common source of "why is this field a string on the
 * frontend" bugs.
 *
 * THIS TOOL IS READ-ONLY. It never writes to the database, never edits the
 * registry, never emits DDL. Drift is reported; fixing it is a code change
 * the developer makes by hand, deliberately, in dto-mapper.js.
 *
 * Why NOT auto-fix
 * ────────────────
 * dto-mapper.js's header comment explicitly warns against a TINYINT(1)
 * boolean heuristic — that earlier prototype silently miscoerced small INT
 * columns that happened to declare length 1. The same class of footgun
 * applies to any auto-detection rule. The registry stays manual so that
 * every add is a deliberate, reviewable decision. v3.2.4 may introduce a
 * schema-driven bootstrap layer that builds the registry at startup from
 * information_schema, with manual entries acting as overrides; that is
 * tracked as Deferred Items Registry §B in the v3.2.3 plan.
 *
 * Usage
 * ─────
 *   Usage: node docker-api/scripts/schema-audit.js [options]
 *
 *   Options:
 *     --help, -h            Print this help and exit
 *     --format=<json|table> Output format (default: table)
 *     --output=<path>       Write to file instead of stdout
 *     --table=<name>        Audit only one logical table (e.g. transformers)
 *
 *   Exit codes:
 *     0   No drift detected
 *     1   Drift detected (columns in DB lack a registry entry)
 *     2   CLI argument error OR DB connection failure (with actionable error message)
 *
 *   Examples:
 *     npm run schema:audit
 *     npm run schema:audit -- --format=json --output=/tmp/audit.json
 *     npm run schema:audit -- --table=transformers
 *
 * Connection resolution
 * ─────────────────────
 *   Order: (1) DB_* env vars, (2) .devcontainer/.env auto-detect with host
 *   probing on 127.0.0.1 / mariadb / localhost. Same pattern as the
 *   v3.2.2 B2-3 integration test runner.
 */
'use strict';

const fs = require('node:fs');
const path = require('node:path');
const net = require('node:net');
const mariadb = require('mariadb');

const { INFRA_TABLE_NAMES, ENGINE_TABLE_NAMES } = require('../src/table-ddls');
const { getRegistry } = require('../src/edge/lib/dto-mapper');

// ── CLI arg parsing ─────────────────────────────────────────────────────────
// Zero-dependency, explicit. Supports `--flag`, `--flag=value`, `-h`.

/**
 * Consume the next argv token as a value for `--<key>`. Validates that the
 * next token exists and does NOT itself start with `--` — catching the
 * v3.2.3 post-ship review finding (H3) where `--format --output=/tmp/x`
 * silently consumed `--output=...` as the format string.
 *
 * Exits 2 on misuse because parseArgs is called before any I/O — callers
 * should see a fast, unambiguous error before we attempt a DB connection.
 *
 * NOTE (v3.2.4 Phase 4 LOW#1): the "starts with `--`" guard only rejects
 * LONG flags. A single-dash short flag like `-o <value>` would currently
 * be accepted as the value of the preceding `--<key>`. This is safe today
 * because `schema-audit.js` declares zero short flags in its parser: `-h`
 * is handled by a dedicated short-circuit in `parseArgs` before this
 * function is ever reached, and no other `-x` form exists. If a future
 * change adds a real short flag (`-o`, `-f`, etc.), tighten this check
 * to reject any token matching `/^-/` or whitelist known short flags
 * explicitly — otherwise `--format -o` will silently eat `-o` as the
 * format string, reintroducing the H3 footgun under a new spelling.
 *
 * @param {string[]} argv
 * @param {number} i - Index of the `--<key>` flag
 * @param {string} key
 * @returns {{ value: string, nextIndex: number }}
 */
function consumeValue(argv, i, key) {
  const next = argv[i + 1];
  if (next === undefined || next.startsWith('--')) {
    console.error(`schema-audit: --${key} requires a value (got ${next === undefined ? '<end of args>' : `"${next}"`})`);
    console.error(`  use --${key}=<value> or --${key} <value>`);
    process.exit(2);
  }
  return { value: next, nextIndex: i + 1 };
}

// v3.2.4 NH3 fix — whitelist of recognised long-flag keys. Anything outside
// this set is an unknown option and exits 2 with a clear error. The pre-fix
// parser entered `consumeValue()` for ANY `--<key>` regex match, meaning an
// unknown flag like `--verbose json` would silently consume `json` as its
// value, skip the `key === 'format'|'output'|'table'` cases, and leave the
// user with no indication that their option was ignored. With the whitelist
// the error surfaces immediately and loudly.
//
// NOTE: `--help` / `-h` are intentionally ABSENT from this set — they are
// short-circuited earlier in parseArgs (raw === '-h' || raw === '--help')
// and never reach the whitelist check. The error message below still lists
// --help as a valid option because that is the user-facing truth; the
// implementation path for --help just happens to be different.
const KNOWN_FLAG_KEYS = new Set(['format', 'output', 'table']);

function parseArgs(argv) {
  const args = {
    help: false,
    format: 'table',
    output: null,
    table: null,
  };
  for (let i = 0; i < argv.length; i++) {
    const raw = argv[i];
    if (raw === '-h' || raw === '--help') {
      args.help = true;
      continue;
    }
    const m = raw.match(/^--([a-z][a-z-]*)(?:=(.*))?$/);
    if (!m) continue;
    const key = m[1];
    const inline = m[2];

    // NH3 — reject unknown flags BEFORE touching consumeValue, otherwise
    // `--verbose json` would eat `json` as the unknown flag's value and
    // fall through silently.
    if (!KNOWN_FLAG_KEYS.has(key)) {
      console.error(`schema-audit: unknown option --${key}`);
      console.error('  valid options: --format, --output, --table, --help');
      process.exit(2);
    }

    // `--key=value` form — inline is the captured value (may be '' for
    // `--key=`, which we treat as missing and error below).
    // `--key value` form — inline is undefined; we consume argv[i+1]
    // after verifying it is not another flag.
    let value;
    if (inline !== undefined && inline !== '') {
      value = inline;
    } else {
      const consumed = consumeValue(argv, i, key);
      value = consumed.value;
      i = consumed.nextIndex;
    }

    if (key === 'format') args.format = value;
    else if (key === 'output') args.output = value;
    else if (key === 'table') args.table = value;
  }
  if (!['table', 'json'].includes(args.format)) {
    console.error(`schema-audit: invalid --format "${args.format}" (expected table|json)`);
    process.exit(2);
  }
  return args;
}

function printHelp() {
  const help = `
schema-audit.js — Read-only schema drift detector for flexible_mold_base.

Usage:
  node docker-api/scripts/schema-audit.js [options]
  npm run schema:audit -- [options]

Options:
  -h, --help            Print this help and exit.
  --format=<fmt>        Output format: table (default) or json.
  --output=<path>       Write to file instead of stdout.
  --table=<name>        Audit only one logical table (e.g. transformers).

Exit codes:
  0   No drift detected.
  1   Drift detected — one or more columns look escapable but have no
      dto-mapper registry entry.
  2   CLI argument error or DB connection failure. Check the actionable
      error message.

Examples:
  npm run schema:audit
  npm run schema:audit -- --format=json --output=/tmp/audit.json
  npm run schema:audit -- --table=transformers

Connection:
  Reads DB_HOST / DB_PORT / DB_USER / DB_PASSWORD / DB_NAME /
  DB_TABLE_PREFIX from the environment. If those are unset, falls back to
  .devcontainer/.env and probes 127.0.0.1, mariadb, localhost for a
  reachable port. DB_TABLE_PREFIX is required from whichever source wins —
  the silent default was removed to prevent wrong-tenant audits.

This tool is READ-ONLY. It never writes to the database and never edits
the dto-mapper registry. Fix drift by hand, deliberately, in
docker-api/src/edge/lib/dto-mapper.js.
`.trimStart();
  process.stdout.write(help);
}

// ── Config resolution (same pattern as B2-3 integration test) ───────────────

function parseEnvFile(filePath) {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    const out = {};
    for (const line of content.split('\n')) {
      const m = line.match(/^\s*([A-Z_][A-Z0-9_]*)\s*=\s*(.*)\s*$/);
      if (!m) continue;
      let value = m[2];
      if ((value.startsWith('"') && value.endsWith('"')) ||
          (value.startsWith("'") && value.endsWith("'"))) {
        value = value.slice(1, -1);
      }
      out[m[1]] = value;
    }
    return out;
  } catch {
    return null;
  }
}

function probePort(host, port, timeoutMs = 2000) {
  return new Promise((resolve) => {
    const socket = new net.Socket();
    let done = false;
    const finish = (ok) => {
      if (done) return;
      done = true;
      socket.destroy();
      resolve(ok);
    };
    socket.setTimeout(timeoutMs);
    socket.once('connect', () => finish(true));
    socket.once('timeout', () => finish(false));
    socket.once('error', () => finish(false));
    socket.connect(port, host);
  });
}

// v3.2.58 PR-A: silent `|| 'fmb_'` fallback removed — RULE: identifier-via-tables.
// Both env-var and .devcontainer/.env paths require DB_TABLE_PREFIX to be set
// explicitly so a typo cannot audit a wrong-tenant schema and silently mask
// real drift. Returns null on missing prefix (treated as resolution failure).
function requireDbTablePrefix(value, source) {
  if (!value) {
    console.error(`ERROR: DB_TABLE_PREFIX is required (source: ${source}).`);
    console.error('CAUSE: silent `|| \'fmb_\'` fallback removed in v3.2.58.');
    console.error('FIX:   export DB_TABLE_PREFIX=<your_schema_prefix> or set it in .devcontainer/.env.');
    return null;
  }
  return value;
}

async function resolveDbConfig() {
  // Source 1: explicit env vars (CI, DevContainer, production runs)
  if (process.env.DB_HOST && process.env.DB_USER && process.env.DB_NAME) {
    const tablePrefix = requireDbTablePrefix(process.env.DB_TABLE_PREFIX, 'env vars');
    if (!tablePrefix) return null;
    return {
      host: process.env.DB_HOST,
      port: parseInt(process.env.DB_PORT || '3306', 10),
      user: process.env.DB_USER,
      password: process.env.DB_PASSWORD || '',
      database: process.env.DB_NAME,
      tablePrefix,
    };
  }

  // Source 2: .devcontainer/.env auto-detect (local dev fallback)
  const envPath = path.resolve(__dirname, '../../.devcontainer/.env');
  const env = parseEnvFile(envPath);
  if (!env) return null;

  const port = parseInt(env.DB_PORT || '3306', 10);
  const candidates = ['127.0.0.1', 'mariadb', 'localhost'];
  for (const host of candidates) {
    if (await probePort(host, port, 2000)) {
      const tablePrefix = requireDbTablePrefix(env.DB_TABLE_PREFIX, '.devcontainer/.env');
      if (!tablePrefix) return null;
      return {
        host,
        port,
        user: env.DB_USER || 'root',
        password: env.DB_PASSWORD || env.DB_ROOT_PASSWORD || '',
        database: env.DB_NAME || 'flexible_mold_base',
        tablePrefix,
      };
    }
  }
  return null;
}

// ── Audit logic ─────────────────────────────────────────────────────────────

// SQL data types that return a string (or non-primitive) from the MariaDB
// driver and therefore typically need an explicit dto-mapper entry. VARCHAR
// is always "escapable" too, but short VARCHARs are almost never JSON blobs
// or structured data; we narrow to "large" VARCHARs to reduce noise. The
// threshold is intentionally generous — a 255-char VARCHAR is usually a
// slug/name, not a JSON payload.
const ESCAPABLE_TYPES = new Set(['TEXT', 'MEDIUMTEXT', 'LONGTEXT', 'JSON', 'BLOB', 'LONGBLOB', 'MEDIUMBLOB']);
const VARCHAR_DRIFT_THRESHOLD = 512;

// v3.2.4 Phase 3 M4 — expected physical SQL types per registry rule.
// When a column is listed in the dto-mapper registry, the audit now
// cross-validates the physical type against the rule category: a column
// listed in `booleans` must actually be TINYINT, a column listed in
// `timestamps` must be DATETIME / TIMESTAMP / DATE, and a column listed
// in `json` must be JSON or a TEXT variant (some schemas still store JSON
// as TEXT historically). Mismatches surface as `status: 'type-mismatch'`.
//
// Before this fix, `classifyColumn` returned early on a registry hit
// without checking the physical type, meaning a column listed in
// `booleans` but actually declared as `VARCHAR(10)` would silently report
// "clean" — a false negative for drift detection.
//
// These sets are intentionally small and strict. Any future type that
// needs to be accepted must be added here explicitly, not through a
// "maybe" heuristic.
//
// NOTE on `boolean`: MariaDB's `BOOLEAN` keyword is a pure synonym for
// `TINYINT(1)`. The MariaDB driver normalises the DDL keyword to
// `TINYINT` in `information_schema.COLUMNS`, so a column declared as
// `BOOLEAN` surfaces here as `TINYINT` and matches this set correctly.
// Adding `'BOOLEAN'` to the set would be dead code — it is impossible
// for the audit to see it.
const EXPECTED_TYPES_FOR_RULE = {
  boolean: new Set(['TINYINT']),
  timestamp: new Set(['DATETIME', 'TIMESTAMP', 'DATE']),
  json: new Set(['JSON', 'TEXT', 'MEDIUMTEXT', 'LONGTEXT', 'VARCHAR']),
};

// Categorise a column against the dto-mapper registry.
// Returns:
//   { status: 'mapped', rule: 'boolean'|'timestamp'|'json' }
//   { status: 'type-mismatch', rule, expectedTypes, recommendation }
//   { status: 'unmapped', recommendation: string }
//   { status: 'passthrough' }  — not escapable, no mapping needed
function classifyColumn(logicalTable, columnName, sqlType, charMaxLen, registry) {
  const tableDef = registry[logicalTable];
  const upper = sqlType.toUpperCase();

  if (tableDef) {
    let matchedRule = null;
    if (tableDef.booleans?.includes(columnName)) matchedRule = 'boolean';
    else if (tableDef.timestamps?.includes(columnName)) matchedRule = 'timestamp';
    else if (tableDef.json?.includes(columnName)) matchedRule = 'json';

    if (matchedRule) {
      // v3.2.4 Phase 3 M4 — cross-validate physical type against the rule
      // category before returning 'mapped'. Mismatch means the registry
      // and the schema disagree, which usually points at a column that
      // was renamed, re-typed, or copy-pasted into the wrong bucket.
      const expected = EXPECTED_TYPES_FOR_RULE[matchedRule];
      if (!expected.has(upper)) {
        return {
          status: 'type-mismatch',
          rule: matchedRule,
          sqlType: upper,
          expectedTypes: Array.from(expected).sort(),
          recommendation:
            `${columnName} is listed in REGISTRY['${logicalTable}'].${matchedRule} ` +
            `but its physical type is ${upper}; expected one of ` +
            `${Array.from(expected).sort().join(' / ')}. ` +
            `Either re-type the column, move the entry to a different bucket, ` +
            `or remove the stale registry entry.`,
        };
      }
      return { status: 'mapped', rule: matchedRule };
    }
  }

  // Not in registry. Is it escapable?
  if (ESCAPABLE_TYPES.has(upper)) {
    // JSON type is the strongest signal — suggest adding to `json` bucket.
    if (upper === 'JSON') {
      return { status: 'unmapped', recommendation: `Add to REGISTRY['${logicalTable}'].json` };
    }
    // TEXT variants could hold JSON or could be plain prose — flag as inspection needed.
    return { status: 'unmapped', recommendation: `Inspect: ${upper} may hold JSON/structured data; add to .json if so` };
  }
  if (upper === 'VARCHAR' && charMaxLen && charMaxLen >= VARCHAR_DRIFT_THRESHOLD) {
    return {
      status: 'unmapped',
      recommendation: `Inspect: VARCHAR(${charMaxLen}) is large enough to hold a JSON blob`,
    };
  }
  // TINYINT(1) is a classic boolean-in-disguise, but the dto-mapper header
  // explicitly rejects the heuristic (see "Why not tackle auto-detection"
  // in schema-audit.js header). We DO NOT flag TINYINT here — forcing every
  // small INT to justify itself would create more noise than signal.
  return { status: 'passthrough' };
}

async function runAudit(conn, dbConfig, tablesToAudit, registry) {
  const drift = [];
  const mapped = [];

  for (const logicalTable of tablesToAudit) {
    const physicalTable = `${dbConfig.tablePrefix}${logicalTable}`;

    const columns = await conn.query(
      `SELECT COLUMN_NAME, DATA_TYPE, CHARACTER_MAXIMUM_LENGTH
       FROM information_schema.COLUMNS
       WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ?
       ORDER BY ORDINAL_POSITION`,
      [dbConfig.database, physicalTable]
    );

    if (!columns || columns.length === 0) {
      // Table missing — report once, not a per-column drift issue.
      drift.push({
        table: logicalTable,
        column: '(table not found)',
        sqlType: '-',
        status: 'missing',
        recommendation: `Physical table \`${physicalTable}\` does not exist in database \`${dbConfig.database}\``,
      });
      continue;
    }

    for (const col of columns) {
      const result = classifyColumn(
        logicalTable,
        col.COLUMN_NAME,
        col.DATA_TYPE,
        col.CHARACTER_MAXIMUM_LENGTH,
        registry
      );
      const entry = {
        table: logicalTable,
        column: col.COLUMN_NAME,
        sqlType: col.DATA_TYPE.toUpperCase() + (col.CHARACTER_MAXIMUM_LENGTH ? `(${col.CHARACTER_MAXIMUM_LENGTH})` : ''),
      };
      if (result.status === 'mapped') {
        mapped.push({ ...entry, registrySource: result.rule });
      } else if (result.status === 'unmapped') {
        drift.push({ ...entry, status: 'unmapped', recommendation: result.recommendation });
      } else if (result.status === 'type-mismatch') {
        // v3.2.4 Phase 3 M4 — physical type does not match registry rule.
        // Treat as drift so the exit code reflects the inconsistency
        // (exit 1) and the operator sees the column in the report.
        drift.push({
          ...entry,
          status: 'type-mismatch',
          rule: result.rule,
          expectedTypes: result.expectedTypes,
          recommendation: result.recommendation,
        });
      }
    }
  }

  return { drift, mapped };
}

// ── Output formatters ───────────────────────────────────────────────────────

function formatTable(report) {
  const lines = [];
  lines.push('');
  lines.push('═══════════════════════════════════════════════════════════════════');
  lines.push('  schema-audit report');
  lines.push('═══════════════════════════════════════════════════════════════════');
  lines.push('');
  lines.push(`  Tables audited: ${report.tablesAudited}`);
  lines.push(`  Registry hits : ${report.mapped.length}`);
  lines.push(`  Drift findings: ${report.drift.length}`);
  lines.push('');

  if (report.drift.length === 0) {
    lines.push('  ✓ No drift detected — every escapable column is in the registry.');
    lines.push('');
    return lines.join('\n');
  }

  lines.push('  ── Drift details ───────────────────────────────────────────────');
  lines.push('');
  // Group by table for readability.
  const byTable = new Map();
  for (const d of report.drift) {
    if (!byTable.has(d.table)) byTable.set(d.table, []);
    byTable.get(d.table).push(d);
  }
  for (const [table, entries] of byTable) {
    lines.push(`  ${table}`);
    for (const e of entries) {
      lines.push(`    • ${e.column.padEnd(32)} ${e.sqlType.padEnd(18)} ${e.recommendation}`);
    }
    lines.push('');
  }
  lines.push('  Fix drift by adding entries to REGISTRY in docker-api/src/edge/lib/dto-mapper.js.');
  lines.push('  This tool is read-only — no automatic changes are made.');
  lines.push('');
  return lines.join('\n');
}

function formatJson(report) {
  return JSON.stringify(report, null, 2) + '\n';
}

// ── Entry point ─────────────────────────────────────────────────────────────

async function main() {
  const args = parseArgs(process.argv.slice(2));
  if (args.help) {
    printHelp();
    process.exit(0);
  }

  // Pre-flight: resolve DB config with an actionable error if unreachable.
  const dbConfig = await resolveDbConfig();
  if (!dbConfig) {
    console.error('schema-audit: Cannot resolve a MariaDB connection.');
    console.error('');
    console.error('  Tried env vars DB_HOST/DB_PORT/DB_USER/DB_NAME and');
    console.error('  .devcontainer/.env auto-detect on 127.0.0.1 / mariadb / localhost.');
    console.error('');
    console.error('  Fix: start the dev stack and re-run:');
    console.error('    cd docker-api && npm run dev');
    console.error('  Or set DB_HOST, DB_PORT, DB_USER, DB_PASSWORD, DB_NAME explicitly.');
    process.exit(2);
  }

  let conn;
  try {
    conn = await mariadb.createConnection({
      host: dbConfig.host,
      port: dbConfig.port,
      user: dbConfig.user,
      password: dbConfig.password,
      database: dbConfig.database,
      connectTimeout: 5000,
      // Never hold a connection longer than the audit needs.
      acquireTimeout: 5000,
    });
  } catch (err) {
    console.error(`schema-audit: Cannot connect to MariaDB at ${dbConfig.host}:${dbConfig.port}.`);
    console.error(`  (${err.code || err.name}: ${err.message})`);
    console.error('');
    console.error('  Fix: ensure the database is running and the credentials are correct.');
    console.error('    cd docker-api && npm run dev');
    process.exit(2);
  }

  try {
    const registry = getRegistry();
    const allTables = [...INFRA_TABLE_NAMES, ...ENGINE_TABLE_NAMES];
    const tablesToAudit = args.table ? [args.table] : allTables;

    // Validate --table against the known set.
    if (args.table && !allTables.includes(args.table)) {
      console.error(`schema-audit: unknown table "${args.table}". Known tables:`);
      console.error('  ' + allTables.join(', '));
      process.exit(2);
    }

    const { drift, mapped } = await runAudit(conn, dbConfig, tablesToAudit, registry);

    const report = {
      schema: dbConfig.database,
      tablePrefix: dbConfig.tablePrefix,
      tablesAudited: tablesToAudit.length,
      drift,
      mapped,
      generatedAt: new Date().toISOString(),
    };

    const output = args.format === 'json' ? formatJson(report) : formatTable(report);

    if (args.output) {
      fs.writeFileSync(args.output, output, 'utf-8');
      console.error(`schema-audit: wrote ${args.output}`);
    } else {
      process.stdout.write(output);
    }

    process.exit(drift.length > 0 ? 1 : 0);
  } finally {
    try { await conn.end(); } catch { /* ignore */ }
  }
}

// v3.2.4 Phase 3 M4 — only auto-run main() when the file is invoked
// directly (via `node schema-audit.js` or npm run schema:audit). Requiring
// the file from a unit test for `classifyColumn` must NOT trigger a DB
// connection attempt. The `require.main === module` check is the standard
// node pattern for "script OR library".
if (require.main === module) {
  main().catch((err) => {
    console.error('schema-audit: unexpected error');
    console.error(err);
    process.exit(2);
  });
}

// Exposed for unit testing (v3.2.4 Phase 3 M4). Not part of the public
// CLI contract; treat as internal and expect signatures to change.
module.exports = {
  _classifyColumn: classifyColumn,
  _EXPECTED_TYPES_FOR_RULE: EXPECTED_TYPES_FOR_RULE,
};
