#!/usr/bin/env node
/**
 * cleanup-orphan-keys.js — v3.2.9 Phase 4 — one-time orphan payload cleanup.
 *
 * Purpose
 * ───────
 * Scan all user_templates and strip payload keys that do not exist in the
 * current blueprint_fields definition. These orphans are historical remnants
 * from pre-Schema-Builder era or from renamed/deleted fields.
 *
 * Modes
 * ─────
 *   --dry-run  (default)  Print a report of orphan keys per template. No writes.
 *   --apply               Actually UPDATE templates to strip orphan keys.
 *
 * Usage
 * ─────
 *   node docker-api/scripts/cleanup-orphan-keys.js
 *   node docker-api/scripts/cleanup-orphan-keys.js --apply
 *
 * Connection
 * ──────────
 *   Uses DB_HOST / DB_USER / DB_PASSWORD / DB_NAME / DB_PORT env vars.
 *   Falls back to .env auto-detect (same as schema-audit.js).
 *
 * Exit codes
 * ──────────
 *   0  No orphans found (or --apply completed successfully)
 *   1  Orphans detected (dry-run mode)
 *   2  CLI error or DB connection failure
 */
'use strict';

const fs = require('node:fs');
const path = require('node:path');
const mariadb = require('mariadb');

// ── CLI ─────────────────────────────────────────────────────────────────────
const args = process.argv.slice(2);
const applyMode = args.includes('--apply');
const showHelp = args.includes('--help') || args.includes('-h');

if (showHelp) {
  console.log(`Usage: node cleanup-orphan-keys.js [--apply] [--help]

  --apply   Strip orphan keys from templates (default: dry-run)
  --help    Show this help
`);
  process.exit(0);
}

// ── DB config ───────────────────────────────────────────────────────────────
function resolveDbConfig() {
  if (process.env.DB_HOST && process.env.DB_USER && process.env.DB_NAME) {
    return {
      host: process.env.DB_HOST,
      port: parseInt(process.env.DB_PORT || '3306', 10),
      user: process.env.DB_USER,
      password: process.env.DB_PASSWORD || '',
      database: process.env.DB_NAME,
    };
  }
  // Try loading from .env in docker-api/
  const envPath = path.resolve(__dirname, '..', '.env');
  if (fs.existsSync(envPath)) {
    const lines = fs.readFileSync(envPath, 'utf-8').split('\n');
    const env = {};
    for (const line of lines) {
      const m = line.match(/^([A-Z_]+)=(.*)$/);
      if (m) env[m[1]] = m[2].replace(/^["']|["']$/g, '');
    }
    if (env.DB_HOST && env.DB_USER && env.DB_NAME) {
      return {
        host: env.DB_HOST,
        port: parseInt(env.DB_PORT || '3306', 10),
        user: env.DB_USER,
        password: env.DB_PASSWORD || '',
        database: env.DB_NAME,
      };
    }
  }
  return null;
}

// ── Table prefix ────────────────────────────────────────────────────────────
// v3.2.58 PR-A: silent `|| 'fmb_'` fallback removed — RULE: identifier-via-tables.
// Operators must set TABLE_PREFIX explicitly so a typo cannot run a destructive
// cleanup against a wrong-tenant schema. No `--allow-default-prefix` escape.
const TABLE_PREFIX = process.env.TABLE_PREFIX;
if (!TABLE_PREFIX) {
  console.error('ERROR: TABLE_PREFIX env var is required.');
  console.error('CAUSE: silent `|| \'fmb_\'` fallback removed in v3.2.58.');
  console.error('FIX:   export TABLE_PREFIX=<your_schema_prefix> before running this script.');
  process.exit(2);
}
const t = (name) => `${TABLE_PREFIX}${name}`;

// ── Main ────────────────────────────────────────────────────────────────────
async function main() {
  const dbConfig = resolveDbConfig();
  if (!dbConfig) {
    console.error('ERROR: No DB config found. Set DB_HOST/DB_USER/DB_NAME env vars or create docker-api/.env');
    process.exit(2);
  }

  let conn;
  try {
    conn = await mariadb.createConnection({
      host: dbConfig.host,
      port: dbConfig.port,
      user: dbConfig.user,
      password: dbConfig.password,
      database: dbConfig.database,
    });
  } catch (err) {
    console.error(`ERROR: DB connection failed: ${err.message}`);
    process.exit(2);
  }

  try {
    // 1. Load all blueprint_fields grouped by blueprint_id
    const fields = await conn.query(`SELECT blueprint_id, field_key FROM \`${t('blueprint_fields')}\``);
    const fieldsByBlueprint = new Map();
    for (const f of fields) {
      if (!fieldsByBlueprint.has(f.blueprint_id)) {
        fieldsByBlueprint.set(f.blueprint_id, new Set());
      }
      fieldsByBlueprint.get(f.blueprint_id).add(f.field_key);
    }

    // 2. Load all templates with non-null payload
    const templates = await conn.query(
      `SELECT id, name, blueprint_id, payload FROM \`${t('user_templates')}\` WHERE payload IS NOT NULL`,
    );

    let totalOrphans = 0;
    let totalTemplates = 0;
    const changes = [];

    for (const tpl of templates) {
      let payload;
      try {
        payload = typeof tpl.payload === 'string' ? JSON.parse(tpl.payload) : tpl.payload;
      } catch {
        console.warn(`  WARN: Template ${tpl.id} has unparseable payload, skipping`);
        continue;
      }
      if (!payload || typeof payload !== 'object') continue;

      const validKeys = fieldsByBlueprint.get(tpl.blueprint_id) || new Set();
      const payloadKeys = Object.keys(payload);
      const orphanKeys = payloadKeys.filter(k => !validKeys.has(k));

      if (orphanKeys.length === 0) continue;

      totalOrphans += orphanKeys.length;
      totalTemplates++;

      const tplName = tpl.name || tpl.id;
      console.log(`  Template "${tplName}" (${tpl.id}): ${orphanKeys.length} orphan(s)`);
      for (const k of orphanKeys) {
        console.log(`    - ${k}`);
      }

      if (applyMode) {
        const cleanPayload = {};
        for (const k of payloadKeys) {
          if (validKeys.has(k)) cleanPayload[k] = payload[k];
        }
        changes.push({ id: tpl.id, cleanPayload });
      }
    }

    // 3. Apply changes if --apply
    if (applyMode && changes.length > 0) {
      console.log(`\nApplying ${changes.length} update(s)...`);
      for (const { id, cleanPayload } of changes) {
        await conn.query(
          `UPDATE \`${t('user_templates')}\` SET payload = ? WHERE id = ?`,
          [JSON.stringify(cleanPayload), id],
        );
      }
      console.log('Done.');
    }

    // 4. Summary
    console.log(`\n--- Summary ---`);
    console.log(`Templates scanned: ${templates.length}`);
    console.log(`Templates with orphans: ${totalTemplates}`);
    console.log(`Total orphan keys: ${totalOrphans}`);
    console.log(`Mode: ${applyMode ? 'APPLY (changes written)' : 'DRY-RUN (no changes)'}`);

    if (!applyMode && totalOrphans > 0) {
      console.log('\nRe-run with --apply to strip orphan keys.');
      process.exit(1);
    }
  } finally {
    await conn.end();
  }
}

main().catch(err => {
  console.error(`FATAL: ${err.message}`);
  process.exit(2);
});
