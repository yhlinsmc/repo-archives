/**
 * Unit tests for shared/config.js — auth mode resolution chain
 *
 * Run: node --test src/config.test.js
 */
const { describe, it, beforeEach, afterEach } = require('node:test');
const assert = require('node:assert/strict');

const configPath = require.resolve('./shared/config');

function clearConfigCache() {
  delete require.cache[configPath];
}

describe('resolveAuthMode (sync)', () => {
  const savedEnv = {};

  beforeEach(() => {
    savedEnv.AUTH_MODE_OVERRIDE = process.env.AUTH_MODE_OVERRIDE;
    savedEnv.KEYCLOAK_ISSUER_BASE_URL = process.env.KEYCLOAK_ISSUER_BASE_URL;
    savedEnv.JWT_SECRET = process.env.JWT_SECRET;
    // Ensure JWT_SECRET is set (>= 32 chars) so config.js doesn't exit
    process.env.JWT_SECRET = 'test-secret-for-config-tests-min32chars';
    delete process.env.AUTH_MODE_OVERRIDE;
    delete process.env.KEYCLOAK_ISSUER_BASE_URL;
    // Clear module cache for fresh config
    clearConfigCache();
  });

  afterEach(() => {
    // Restore env
    for (const [k, v] of Object.entries(savedEnv)) {
      if (v === undefined) delete process.env[k];
      else process.env[k] = v;
    }
    clearConfigCache();
  });

  it('returns "local" by default', () => {
    const { resolveAuthMode } = require('./shared/config');
    assert.strictEqual(resolveAuthMode(), 'local');
  });

  it('returns cached value (default local) before detectAuthMode runs', () => {
    clearConfigCache();
    const { resolveAuthMode } = require('./shared/config');
    // Before detectAuthMode(), resolveAuthMode() returns the initial cached value
    assert.strictEqual(resolveAuthMode(), 'local');
  });

  it('returns keycloak after detectAuthMode with override', async () => {
    process.env.AUTH_MODE_OVERRIDE = 'keycloak';
    clearConfigCache();
    const { resolveAuthMode, detectAuthMode } = require('./shared/config');
    await detectAuthMode(null, null);
    assert.strictEqual(resolveAuthMode(), 'keycloak');
  });

  it('AUTH_MODE_OVERRIDE=local overrides keycloak env vars', async () => {
    process.env.KEYCLOAK_ISSUER_BASE_URL = 'https://kc.test/realms/test';
    process.env.AUTH_MODE_OVERRIDE = 'local';
    clearConfigCache();
    const { resolveAuthMode, detectAuthMode } = require('./shared/config');
    await detectAuthMode(null, null);
    assert.strictEqual(resolveAuthMode(), 'local');
  });

  it('invalid AUTH_MODE_OVERRIDE is ignored, defaults to auto-detect', async () => {
    process.env.AUTH_MODE_OVERRIDE = 'invalid';
    clearConfigCache();
    const { resolveAuthMode, detectAuthMode } = require('./shared/config');
    await detectAuthMode(null, null);
    assert.strictEqual(resolveAuthMode(), 'local');
  });
});

describe('detectAuthMode', () => {
  const savedEnv = {};

  beforeEach(() => {
    savedEnv.AUTH_MODE_OVERRIDE = process.env.AUTH_MODE_OVERRIDE;
    savedEnv.KEYCLOAK_ISSUER_BASE_URL = process.env.KEYCLOAK_ISSUER_BASE_URL;
    savedEnv.JWT_SECRET = process.env.JWT_SECRET;
    process.env.JWT_SECRET = 'test-secret-for-detect-tests-min32chars';
    delete process.env.AUTH_MODE_OVERRIDE;
    delete process.env.KEYCLOAK_ISSUER_BASE_URL;
    clearConfigCache();
  });

  afterEach(() => {
    for (const [k, v] of Object.entries(savedEnv)) {
      if (v === undefined) delete process.env[k];
      else process.env[k] = v;
    }
    clearConfigCache();
  });

  it('sets mode to override when AUTH_MODE_OVERRIDE=keycloak', async () => {
    process.env.AUTH_MODE_OVERRIDE = 'keycloak';
    clearConfigCache();
    const { detectAuthMode, resolveAuthMode, getAuthModeSource } = require('./shared/config');
    await detectAuthMode(null, null);
    assert.strictEqual(resolveAuthMode(), 'keycloak');
    assert.strictEqual(getAuthModeSource(), 'override');
  });

  it('defaults to local when no Keycloak env vars and no DB', async () => {
    clearConfigCache();
    const { detectAuthMode, resolveAuthMode, getAuthModeSource } = require('./shared/config');
    await detectAuthMode(null, null);
    assert.strictEqual(resolveAuthMode(), 'local');
    assert.strictEqual(getAuthModeSource(), 'default');
  });

  it('falls back to local when Keycloak URL set but unreachable', async () => {
    process.env.KEYCLOAK_ISSUER_BASE_URL = 'http://127.0.0.1:1/realms/nonexistent';
    clearConfigCache();
    const { detectAuthMode, resolveAuthMode, getAuthModeSource } = require('./shared/config');
    await detectAuthMode(null, null);
    assert.strictEqual(resolveAuthMode(), 'local');
    assert.strictEqual(getAuthModeSource(), 'auto_detect');
  });
});

describe('JWT_SECRET validation', () => {
  it('exports JWT_SECRET when set', () => {
    process.env.JWT_SECRET = 'real-test-secret-value-min-32-characters';
    delete require.cache[configPath];
    const { JWT_SECRET } = require('./shared/config');
    assert.strictEqual(JWT_SECRET, 'real-test-secret-value-min-32-characters');
  });
});
