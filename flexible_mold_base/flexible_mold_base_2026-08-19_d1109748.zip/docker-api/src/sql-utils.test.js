/**
 * Unit tests for sql-utils.js — splitSqlStatements, escapeString, escapeSqlValue
 *
 * Run: node --test src/sql-utils.test.js
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const { splitSqlStatements, escapeString, escapeSqlValue } = require('./sql-utils');

// ─── splitSqlStatements ──────────────────────────────────

describe('splitSqlStatements', () => {
  it('splits basic statements on semicolons', () => {
    const result = splitSqlStatements("SELECT 1; SELECT 2;");
    assert.deepEqual(result, ['SELECT 1', 'SELECT 2']);
  });

  it('handles trailing text without semicolon', () => {
    const result = splitSqlStatements("SELECT 1; SELECT 2");
    assert.deepEqual(result, ['SELECT 1', 'SELECT 2']);
  });

  it('ignores empty statements', () => {
    const result = splitSqlStatements("SELECT 1;; ;SELECT 2;");
    assert.deepEqual(result, ['SELECT 1', 'SELECT 2']);
  });

  it('preserves semicolons inside single-quoted strings', () => {
    const result = splitSqlStatements(
      "INSERT INTO t (a) VALUES ('hello; world'); SELECT 1;"
    );
    assert.deepEqual(result, [
      "INSERT INTO t (a) VALUES ('hello; world')",
      'SELECT 1',
    ]);
  });

  it('handles backslash-escaped quotes inside strings', () => {
    const result = splitSqlStatements(
      "INSERT INTO t (a) VALUES ('it\\'s a; test'); SELECT 2;"
    );
    assert.deepEqual(result, [
      "INSERT INTO t (a) VALUES ('it\\'s a; test')",
      'SELECT 2',
    ]);
  });

  it('handles doubled single quotes (SQL standard escape)', () => {
    const result = splitSqlStatements(
      "INSERT INTO t (a) VALUES ('it''s a; test'); SELECT 3;"
    );
    assert.deepEqual(result, [
      "INSERT INTO t (a) VALUES ('it''s a; test')",
      'SELECT 3',
    ]);
  });

  it('handles JSON with semicolons in string values', () => {
    const json = '{"header": "Col; Name", "desc": "a;b;c"}';
    const sql = `INSERT INTO t (cfg) VALUES ('${json.replace(/'/g, "\\'")}'); SELECT 1;`;
    const result = splitSqlStatements(sql);
    assert.equal(result.length, 2);
    assert.ok(result[0].includes('Col; Name'));
  });

  it('ignores semicolons inside -- line comments', () => {
    const sql = "-- this has a ; semicolon\nSELECT 1; SELECT 2;";
    const result = splitSqlStatements(sql);
    // The comment is part of the first statement but does not cause a split
    assert.equal(result.length, 2);
  });

  it('handles apostrophes in -- line comments without breaking string tracking', () => {
    const sql = "-- it's a comment\nINSERT INTO t (a) VALUES ('hello'); SELECT 2;";
    const result = splitSqlStatements(sql);
    assert.equal(result.length, 2);
    assert.ok(result[0].includes("VALUES ('hello')"));
  });

  it('handles /* */ block comments', () => {
    const sql = "/* block comment */ SELECT 1; SELECT 2;";
    const result = splitSqlStatements(sql);
    assert.equal(result.length, 2);
  });

  it('handles apostrophes inside block comments', () => {
    const sql = "/* don't break */ INSERT INTO t (a) VALUES ('val'); SELECT 2;";
    const result = splitSqlStatements(sql);
    assert.equal(result.length, 2);
    assert.ok(result[0].includes("VALUES ('val')"));
  });

  it('handles semicolons inside block comments', () => {
    const sql = "/* has ; semicolon */ SELECT 1; SELECT 2;";
    const result = splitSqlStatements(sql);
    assert.equal(result.length, 2);
  });

  it('filters out START TRANSACTION and COMMIT', () => {
    const sql = "START TRANSACTION;\nINSERT INTO t VALUES (1);\nCOMMIT;";
    const result = splitSqlStatements(sql);
    assert.deepEqual(result, ['INSERT INTO t VALUES (1)']);
  });

  it('filters out SET NAMES', () => {
    const sql = "SET NAMES utf8mb4;\nINSERT INTO t VALUES (1);";
    const result = splitSqlStatements(sql);
    assert.deepEqual(result, ['INSERT INTO t VALUES (1)']);
  });

  it('filters out pure comment blocks', () => {
    const sql = "-- just a comment;\nINSERT INTO t VALUES (1);";
    const result = splitSqlStatements(sql);
    assert.equal(result.length, 1);
    assert.ok(result[0].includes('INSERT'));
  });

  it('handles a real-world export with DDL + INSERT', () => {
    const sql = [
      '-- Exported by flexible_mold_base',
      '-- Generated: 2026-03-26',
      '',
      'CREATE TABLE IF NOT EXISTS `test_table` (',
      '  `id` CHAR(36) PRIMARY KEY,',
      '  `config` JSON',
      ') ENGINE=InnoDB;',
      '',
      "INSERT INTO `test_table` (`id`, `config`) VALUES ('abc', '{\"key\": \"val; ue\"}');",
      '',
    ].join('\n');
    const result = splitSqlStatements(sql);
    assert.equal(result.length, 2);
    assert.ok(result[0].includes('CREATE TABLE'));
    assert.ok(result[1].includes('INSERT'));
    assert.ok(result[1].includes('val; ue'));
  });

  it('handles multiline INSERT with multiple value rows', () => {
    const sql = [
      "INSERT INTO `t` (`id`, `name`) VALUES",
      "('1', 'hello; world'),",
      "('2', 'foo; bar');",
      "SELECT 1;",
    ].join('\n');
    const result = splitSqlStatements(sql);
    assert.equal(result.length, 2);
    assert.ok(result[0].includes("hello; world"));
    assert.ok(result[0].includes("foo; bar"));
  });

  it('handles backslash at end of string value', () => {
    const sql = "INSERT INTO t (a) VALUES ('path\\\\'); SELECT 1;";
    const result = splitSqlStatements(sql);
    assert.equal(result.length, 2);
  });

  it('returns empty array for empty input', () => {
    assert.deepEqual(splitSqlStatements(''), []);
    assert.deepEqual(splitSqlStatements('   '), []);
    assert.deepEqual(splitSqlStatements('-- just comments'), []);
  });
});

// ─── escapeString ────────────────────────────────────────

describe('escapeString', () => {
  it('escapes single quotes', () => {
    assert.equal(escapeString("it's"), "it\\'s");
  });

  it('escapes backslashes', () => {
    assert.equal(escapeString('a\\b'), 'a\\\\b');
  });

  it('escapes newlines and tabs', () => {
    assert.equal(escapeString('a\nb\tc'), 'a\\nb\\tc');
  });

  it('escapes carriage returns and null bytes', () => {
    assert.equal(escapeString('a\rb\0c'), 'a\\rb\\0c');
  });

  it('handles combined special chars', () => {
    assert.equal(escapeString("it's a\nnew\\line"), "it\\'s a\\nnew\\\\line");
  });
});

// ─── escapeSqlValue ──────────────────────────────────────

describe('escapeSqlValue', () => {
  it('returns NULL for null/undefined', () => {
    assert.equal(escapeSqlValue(null), 'NULL');
    assert.equal(escapeSqlValue(undefined), 'NULL');
  });

  it('handles booleans', () => {
    assert.equal(escapeSqlValue(true), '1');
    assert.equal(escapeSqlValue(false), '0');
  });

  it('handles TINYINT numbers correctly (not just truthiness)', () => {
    assert.equal(escapeSqlValue(2, 'TINYINT'), '2');
    assert.equal(escapeSqlValue(0, 'TINYINT'), '0');
    assert.equal(escapeSqlValue(127, 'TINYINT'), '127');
  });

  it('handles regular numbers', () => {
    assert.equal(escapeSqlValue(42), '42');
    assert.equal(escapeSqlValue(3.14), '3.14');
    assert.equal(escapeSqlValue(NaN), 'NULL');
    assert.equal(escapeSqlValue(Infinity), 'NULL');
  });

  it('handles strings with escaping', () => {
    assert.equal(escapeSqlValue("hello"), "'hello'");
    assert.equal(escapeSqlValue("it's"), "'it\\'s'");
  });

  it('handles objects as JSON', () => {
    const result = escapeSqlValue({ key: "val" });
    assert.equal(result, "'{\"key\":\"val\"}'");
  });

  it('handles Date objects', () => {
    const d = new Date('2026-03-26T12:30:45.000Z');
    assert.equal(escapeSqlValue(d), "'2026-03-26 12:30:45'");
  });

  it('handles BigInt', () => {
    assert.equal(escapeSqlValue(9007199254740993n), '9007199254740993');
  });
});
