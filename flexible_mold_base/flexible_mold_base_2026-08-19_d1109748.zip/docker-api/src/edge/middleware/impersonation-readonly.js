const { apiError } = require('../../shared/helpers');

const READ_METHODS = new Set(['GET', 'HEAD', 'OPTIONS']);

// SAFETY: these are infra→edge S2S machinery calls (identity/access/auth-mode
// resolution), POST-shaped but read-only by nature, not user-driven data
// mutations. They must pass through even while impersonating; the data routes
// that actually mutate user content (/edge/app/*, /edge/platform/* CRUD) are
// the ones the read-only rule targets.
const READONLY_EXEMPT_PREFIXES = [
  '/edge/internal/',
  '/edge/platform/access-check',
];

// SAFETY: read-only data POSTs — SELECT-only batch reads that must use POST
// because the infra→edge proxy folds repeated GET query params into a single
// scalar, so a batched id-list read cannot travel as `?id=a&id=b`. They are
// equivalent to the GET reads impersonation already permits. Exact match only —
// sibling write POSTs under the same router (e.g. .../replace) stay blocked.
const READONLY_EXEMPT_EXACT = new Set([
  '/edge/app/schema/field_options/by-fields',
  '/edge/app/schema/blueprint_fields/by-blueprints',
  // SELECT-only orphan scan; POST-shaped because forwardToEdge drops the body
  // (and thus req.body.db) on GET. The sibling DELETE clear stays blocked.
  '/edge/app/schema/field-data-orphans',
]);

function isExempt(path) {
  return READONLY_EXEMPT_EXACT.has(path)
    || READONLY_EXEMPT_PREFIXES.some((p) => path === p || path.startsWith(p));
}

/**
 * Defense-in-depth: when a request carries an impersonated identity
 * (reconstructed by s2s-verify from the trusted x-forwarded-user-impersonated
 * header), reject every non-read method. Infra is the primary gate; this
 * ensures a write cannot reach the DB even if the infra gate is bypassed.
 */
function impersonationReadOnly(req, res, next) {
  if (req.user && req.user.impersonated && !READ_METHODS.has(req.method) && !isExempt(req.path)) {
    const e = apiError(
      'This action is not allowed while viewing as another user (read-only).',
      'IMPERSONATION_READ_ONLY',
      403,
    );
    return res.status(e.status).json(e.body);
  }
  return next();
}

module.exports = { impersonationReadOnly };
