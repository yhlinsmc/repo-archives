/**
 * x-database-validate.js — Edge-side X-Database header validation.
 *
 * NOTE: Moved from infra/index-infra.js — infra no longer has the pool
 * config to validate against, so the check belongs on edge (the boundary
 * that owns the credentials).
 *
 * What it does:
 *   - On schema-routable paths (audit / users / settings / etc on edge),
 *     if X-Database header is present, validates it matches the configured
 *     DB name. Mismatches return 403.
 *   - On match, injects `req.body.db = { host, port, user, password, database, tablePrefix }`
 *     so route handlers using getDynamicPool() route to the right schema.
 *   - Header absent → passthrough (default pool routing).
 *
 * SECURITY: Prevents an authenticated caller from redirecting their writes
 * to a sibling database on the same MariaDB instance by sending an
 * unexpected X-Database value.
 */
const { isPoolReady, getDbConfigFull } = require('../db');
const { apiError } = require('../../shared/helpers');
const { logger: rootLogger } = require('../../shared/lib/logger');
const { enforceClientDbBoundary } = require('../lib/client-db-guard');

const logger = rootLogger.child({ module: 'x-database-validate' });

// Edge mount points that accept per-request schema routing.
const SCHEMA_ROUTABLE_PREFIXES = [
  '/edge/platform/query',
  '/edge/app/schema',
  '/edge/app/sync-schema',
];

function isSchemaRoutable(path) {
  return SCHEMA_ROUTABLE_PREFIXES.some((p) => path.startsWith(p));
}

// Health namespace — must return 200 UNCONDITIONALLY (K8s liveness/readiness
// probe target, S2S-exempt) and NEVER reaches getDynamicPool (it only reports
// pool state, never opens a dynamic pool). The client-db guard would add no
// security here, only break the unconditional-200 contract for a monitor that
// sends a request body. Exact health namespace only — never a schema / data /
// query / reassign path.
function isHealthPath(path) {
  return path === '/edge/health' || path.startsWith('/edge/health/');
}

module.exports = function xDatabaseValidate(req, res, next) {
  // Exempt the health namespace BEFORE the guard (see isHealthPath rationale).
  if (isHealthPath(req.path)) return next();

  // SECURITY — getDynamicPool trust boundary (runs FIRST, on EVERY path).
  // This middleware is the sole injector of req.body.db and runs before all
  // route handlers, so any req.body.db present on ENTRY can only be
  // client-supplied. A client value must never reach getDynamicPool (SSRF /
  // credential relay / sibling-schema bypass). Enforced globally — before the
  // header / schema-routable / pool-ready gates below — because getDynamicPool
  // builds its own pool regardless of isPoolReady() and some call sites
  // (e.g. api-connectors/reassign) sit outside the schema-routable prefixes.
  // REJECT (default) returns 400; WARN discards the client value and continues.
  if (!enforceClientDbBoundary(req, res)) return;

  const targetDbName = req.headers['x-database'];
  if (!targetDbName) return next();
  if (!isSchemaRoutable(req.path)) return next();
  if (!isPoolReady()) return next();

  const cfg = getDbConfigFull();
  if (!cfg) return next();

  if (targetDbName !== cfg.database) {
    logger.warn({ targetDbName, configuredDb: cfg.database, path: req.path }, 'X-Database header rejected — does not match configured DB');
    const err = apiError(
      'X-Database header value is not an allowed database',
      'VALIDATION_ERROR',
      403,
    );
    return res.status(err.status).json(err.body);
  }

  req.body = req.body || {};
  if (!req.body.db) {
    req.body.db = {
      host: cfg.host,
      port: cfg.port,
      user: cfg.user,
      password: cfg.password,
      database: targetDbName,
      tablePrefix: cfg.tablePrefix,
    };
  }
  next();
};
