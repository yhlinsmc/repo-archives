/**
 * boot-guard.js — decide how a boot-time DB init rejection is handled.
 *
 * Kept as a standalone, side-effect-free module so the crash-vs-degrade
 * decision (the regression surface) is unit-testable without booting the
 * whole edge entry point.
 */

/**
 * SECURITY: initializeFromConfig() degrades every RECOVERABLE config problem to
 * a null pool internally (setup-required mode) and resolves. The ONLY rejection
 * it still emits is the intentional SKIP_DB_INIT + production fail-fast guard,
 * tagged err.fatalBoot. That MUST crash the pod (CrashLoopBackOff) so an
 * operator sees the misconfigured ConfigMap, instead of a health-probe-green
 * edge running with no DB pool. A blanket .catch() that swallowed it would
 * silently defeat the guard.
 *
 * @param {unknown} err  the boot init rejection
 * @param {{ logger: object, exit: (code: number) => void }} deps
 */
function handleBootInitError(err, { logger, exit }) {
  if (err && err.fatalBoot) {
    logger.fatal({ err }, 'fatal boot guard tripped — refusing to start edge');
    exit(1);
    return;
  }
  logger.error({ err }, 'DB init rejected at boot — continuing in setup-required mode');
}

module.exports = { handleBootInitError };
