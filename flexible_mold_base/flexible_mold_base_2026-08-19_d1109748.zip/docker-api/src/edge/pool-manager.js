/**
 * pool-manager.js — Multi-pool manager for infrastructure and dynamic connections.
 *
 * Priority hierarchy:
 *   Priority 1: Per-request DB config (body.db)  — handled at route level
 *   Priority 2: Activated connection pool         — user activated a stored connection
 *   Priority 3: Startup pool from db-config.json  — written by /api/setup/configure-db
 *   Priority 4: Startup pool from env vars        — Render Dashboard / .env
 *
 * NOTE: Infra and dynamic pools carry an optional read-endpoint. When an
 * RO pool is not configured, getInfraReadPool() falls back to the writer so
 * callers can use pool.ro unconditionally without juggling null checks. See
 * db.js docstring for the env-var contract (DB_RW_HOST / DB_RO_HOST etc).
 *
 * Note on memory: a dynamic connection profile with a separate read endpoint
 * caches TWO mariadb pools under one MAX_POOLS slot (writer + reader share
 * the slot's lifecycle). Evictions and shutdown close both.
 */
const mariadb = require('mariadb');
const { logger: rootLogger } = require('../shared/lib/logger');
const logger = rootLogger.child({ module: 'pool-manager' });

// ── Infrastructure pool ───────────────────────────────────────────────────────
let _infraPool = null;
let _infraReadPool = null;

function setInfraPool(pool) {
  _infraPool = pool;
}

function setInfraReadPool(pool) {
  _infraReadPool = pool;
}

function getInfraPool() {
  if (!_infraPool) {
    throw Object.assign(
      new Error('Database not configured. Please complete setup first.'),
      { code: 'DB_NOT_CONFIGURED' }
    );
  }
  return _infraPool;
}

/**
 * Returns the dedicated read pool when a separate read-endpoint is
 * configured, otherwise falls back to the writer pool. Callers should use
 * this for idempotent read queries without caring about topology.
 */
function getInfraReadPool() {
  const target = _infraReadPool || _infraPool;
  if (!target) {
    throw Object.assign(
      new Error('Database not configured. Please complete setup first.'),
      { code: 'DB_NOT_CONFIGURED' }
    );
  }
  return target;
}

// ── Dynamic pool cache ────────────────────────────────────────────────────────
const MAX_POOLS = 5;
const POOL_TTL_MS = 5 * 60 * 1000;

/**
 * @typedef {Object} DynamicPoolEntry
 * @property {import('mariadb').Pool} rw      Writer pool (always present)
 * @property {import('mariadb').Pool|null} ro Reader pool (null → fallback to rw)
 * @property {number} lastUsed                Monotonic ms since last access
 */

/** @type {Map<string, DynamicPoolEntry>} */
const _dynamicPools = new Map();

function _cacheKey(cfg) {
  // Include read-endpoint in the cache key so profiles with different RO
  // topology don't collide on the same writer credentials.
  const readPart = cfg.readHost
    ? `|ro=${cfg.readHost}:${cfg.readPort || 3306}`
    : '';
  return `${cfg.host}:${cfg.port || 3306}:${cfg.user}:${cfg.database}${readPart}`;
}

function _buildPool(host, port, user, password, database) {
  return mariadb.createPool({
    host,
    port: parseInt(String(port || '3306')),
    user,
    password: password || '',
    database,
    connectionLimit: 3,
    connectTimeout: 5000,
    acquireTimeout: 8000,
    idleTimeout: POOL_TTL_MS,
  });
}

/**
 * Resolve (or create) a dynamic pool pair for the given connection profile.
 * Returns a `{ rw, ro }` namespace matching the db.js `pool` facade shape.
 * Callers must pick `.rw.getConnection()` for writes / write-guard reads or
 * `.ro.getConnection()` for pure reads — the bare `.getConnection()` /
 * `.query()` convenience shims are intentionally absent.
 */
async function getDynamicPool(cfg) {
  const key = _cacheKey(cfg);
  const now = Date.now();

  const existing = _dynamicPools.get(key);
  if (existing) {
    existing.lastUsed = now;
    return _dynamicFacade(existing);
  }

  if (_dynamicPools.size >= MAX_POOLS) {
    let oldestKey = null;
    let oldestTime = Infinity;
    for (const [k, v] of _dynamicPools) {
      if (v.lastUsed < oldestTime) { oldestTime = v.lastUsed; oldestKey = k; }
    }
    if (oldestKey) {
      logger.debug({ key: oldestKey }, 'evicting pool at capacity');
      const entry = _dynamicPools.get(oldestKey);
      _dynamicPools.delete(oldestKey);
      try { await entry.rw.end(); } catch {}
      if (entry.ro) { try { await entry.ro.end(); } catch {} }
    }
  }

  const rwPool = _buildPool(cfg.host, cfg.port, cfg.user, cfg.password, cfg.database);

  let roPool = null;
  if (cfg.readHost && cfg.readPort) {
    roPool = _buildPool(
      cfg.readHost,
      cfg.readPort,
      cfg.readUser || cfg.user,
      cfg.readPassword != null ? cfg.readPassword : cfg.password,
      cfg.database,
    );
  }

  const entry = { rw: rwPool, ro: roPool, lastUsed: now };
  _dynamicPools.set(key, entry);
  return _dynamicFacade(entry);
}

function _dynamicFacade(entry) {
  // NOTE: The dynamic-pool facade matches the db.js `pool` shape —
  // explicit .rw / .ro namespaces only. The bare getConnection / query
  // convenience shims were removed alongside the db.js shim. Call sites
  // must pick dynPool.rw or dynPool.ro explicitly.
  return {
    rw: entry.rw,
    ro: entry.ro || entry.rw,
  };
}

async function cleanupIdlePools() {
  if (_dynamicPools.size === 0) return;
  const now = Date.now();
  for (const [key, entry] of _dynamicPools) {
    if (now - entry.lastUsed > POOL_TTL_MS) {
      _dynamicPools.delete(key);
      try { await entry.rw.end(); } catch {}
      if (entry.ro) { try { await entry.ro.end(); } catch {} }
      logger.debug({ key }, 'evicted idle dynamic pool');
    }
  }
}

async function shutdownDynamicPools() {
  for (const [, entry] of _dynamicPools) {
    try { await entry.rw.end(); } catch {}
    if (entry.ro) { try { await entry.ro.end(); } catch {} }
  }
  _dynamicPools.clear();
}

module.exports = {
  setInfraPool,
  setInfraReadPool,
  getInfraPool,
  getInfraReadPool,
  getDynamicPool,
  cleanupIdlePools,
  shutdownDynamicPools,
};
