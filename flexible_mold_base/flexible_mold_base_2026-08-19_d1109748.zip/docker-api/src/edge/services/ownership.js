/**
 * services/ownership.js
 *
 * Single entry point for all owner_id mutations across owner-bearing
 * tables (hierarchy_nodes, transformers, user_templates, api_connectors,
 * cap_scenarios).
 * Callers manage BEGIN/COMMIT;
 * this helper performs SELECT ... FOR UPDATE, the precondition check,
 * the UPDATE, and writes one feature_audit row.
 *
 * Three call sites:
 *   PATCH /:id/owner     - admin transfer to any user or null  (action='transfer'|'make_shared')
 *   POST  /:id/claim     - editor/admin claim a NULL row       (action='claim',   requireCondition='null')
 *   POST  /:id/release   - editor/admin release a self-owned   (action='release', requireCondition='self')
 *
 * NOTE: Audit invariant: event_type is preserved at the per-table value
 * already in use ('blueprint.owner.transfer' or 'transformer.owner.transfer');
 * the `action` discriminator lives inside the metadata payload so existing
 * audit consumers (filters keyed on event_type) keep working.
 *
 * Caller passes `t` (prefix resolver) and logical table names so the
 * helper is unit-testable without a configured pool.
 */

const { TABLES } = require('../../shared/constants');
const { uuidv4 } = require('../../shared/helpers');
const { sameStoredValue } = require('../routes/app/schema/write-value');

/**
 * @typedef {'null' | 'self' | 'any'} RequireCondition
 *   - 'null': caller is claiming, row must currently have owner_id IS NULL
 *   - 'self': caller is releasing, row must currently have owner_id = actor.id
 *   - 'any':  admin transfer, no precondition on current owner
 *
 * @typedef {'claim' | 'transfer' | 'release' | 'make_shared'} OwnerAction
 *
 * @typedef {Object} ApplyOwnerChangeOpts
 * @property {{id: string|null, role: string}} actor
 * @property {OwnerAction} action
 * @property {RequireCondition} requireCondition
 * @property {string} auditEventType
 * @property {(name: string) => string} t  prefix resolver; tests inject a mock
 *
 * @typedef {Object} ApplyOwnerChangeResult
 * @property {boolean} changed
 * @property {string|null} prior_owner
 * @property {string|null} new_owner
 * @property {'NOT_FOUND' | 'NOT_NULL' | 'NOT_SELF'} [conflict_reason]
 * @property {boolean} [idempotent_same_actor]   true when claim re-runs by the existing owner
 * @property {boolean} [unchanged_same_owner]    true when PATCH targets the current owner
 */

/**
 * @param {import('mariadb').Connection} conn  active conn inside caller-managed tx
 * @param {string} table  TABLES.HIERARCHY_NODES, TABLES.TRANSFORMERS, or
 *                         TABLES.USER_TEMPLATES (logical name)
 * @param {string} id     row primary key
 * @param {string|null} newOwnerId  desired owner_id value
 * @param {ApplyOwnerChangeOpts} opts
 * @returns {Promise<ApplyOwnerChangeResult>}
 */
async function applyOwnerChange(conn, table, id, newOwnerId, opts) {
  const { actor, action, requireCondition, auditEventType, t } = opts;

  if (typeof t !== 'function') {
    throw new Error('applyOwnerChange: opts.t (prefix resolver) required');
  }
  if (
    table !== TABLES.HIERARCHY_NODES
    && table !== TABLES.TRANSFORMERS
    && table !== TABLES.USER_TEMPLATES
    && table !== TABLES.API_CONNECTORS
    && table !== TABLES.CAP_SCENARIOS
  ) {
    throw new Error(`applyOwnerChange: unsupported table ${table}`);
  }
  if (!actor || typeof actor !== 'object') {
    throw new Error('applyOwnerChange: actor required');
  }
  if (action !== 'claim' && action !== 'transfer' && action !== 'release' && action !== 'make_shared') {
    throw new Error(`applyOwnerChange: unknown action ${action}`);
  }
  if (requireCondition !== 'null' && requireCondition !== 'self' && requireCondition !== 'any') {
    throw new Error(`applyOwnerChange: unknown requireCondition ${requireCondition}`);
  }
  if (typeof auditEventType !== 'string' || auditEventType.length === 0) {
    throw new Error('applyOwnerChange: auditEventType required');
  }

  const rows = await conn.query(
    `SELECT id, owner_id FROM \`${t(table)}\` WHERE id = ? FOR UPDATE`,
    [id],
  );
  if (!rows.length) {
    return { changed: false, conflict_reason: 'NOT_FOUND', prior_owner: null, new_owner: newOwnerId };
  }
  const priorOwner = rows[0].owner_id;

  // collation-compare, for both preconditions below: "is the caller the owner"
  // is a question about the COLUMN, because that is the authority every other
  // enforcement point on this row uses. The write scope in the CRUD factory is
  // `AND (owner_id IS NULL OR owner_id = ?)`, the delegated-grant predicate is a
  // SQL EXISTS, and both fold case under this column's collation. A JavaScript
  // `===` here answers a different question from all of them, and it answers it
  // in the direction that REFUSES THE GENUINE OWNER: a row whose `owner_id`
  // holds another spelling of the caller's id is theirs to every statement in
  // the system and nobody's to this check, so the owner is told they may not
  // release or re-claim their own record while a stranger's access is unchanged.
  const callerIsPriorOwner = await sameStoredValue(
    conn, t(table), 'owner_id', priorOwner, actor.id,
  );
  if (requireCondition === 'null' && priorOwner !== null) {
    if (callerIsPriorOwner) {
      // E-H3 idempotency: same actor re-clicks Claim -> 200 {claimed:false}, no audit.
      return {
        changed: false,
        idempotent_same_actor: true,
        prior_owner: priorOwner,
        new_owner: priorOwner,
      };
    }
    return { changed: false, conflict_reason: 'NOT_NULL', prior_owner: priorOwner, new_owner: newOwnerId };
  }
  if (requireCondition === 'self' && !callerIsPriorOwner) {
    return { changed: false, conflict_reason: 'NOT_SELF', prior_owner: priorOwner, new_owner: newOwnerId };
  }

  // byte-compare, and deliberately the OTHER kind from the two above, because it
  // is the other kind of question. This one is not "who owns the row" but "will
  // the statement move the stored bytes", and the statement binds `newOwnerId`
  // verbatim. Measured on 10.11: a case-only UPDATE on this column reports
  // `Changed: 1` and stores the NEW spelling — the engine does not absorb a
  // respelling. So asking the collation here would be asking a question the
  // statement does not answer: it would report "unchanged" for a write that
  // really does replace the value, skip the UPDATE, and leave a row whose
  // stored spelling no JavaScript reader can match — permanently, since this is
  // also the path by which such a row would be repaired.
  //
  // Callers resolve `newOwnerId` to the canonical stored id before this point
  // (`resolveCanonicalUserId`), so on a settled row the two are byte-identical
  // and the short-circuit fires exactly when nothing moves.
  if (priorOwner === newOwnerId) {
    // E-M1 PATCH same-owner short-circuit: 200 {changed:false}, no audit row.
    return {
      changed: false,
      unchanged_same_owner: true,
      prior_owner: priorOwner,
      new_owner: newOwnerId,
    };
  }

  await conn.query(
    `UPDATE \`${t(table)}\` SET owner_id = ? WHERE id = ?`,
    [newOwnerId, id],
  );

  // SECURITY: Allowlist actor.role so a spoofed JWT/middleware cannot land
  // an arbitrary string in audit.
  const safeRole = ['admin', 'editor', 'user'].includes(actor.role) ? actor.role : 'unknown';
  await conn.query(
    `INSERT INTO \`${t(TABLES.FEATURE_AUDIT)}\` (id, event_type, user_id, metadata)
     VALUES (?, ?, ?, ?)`,
    [
      uuidv4(),
      auditEventType,
      actor.id || null,
      JSON.stringify({
        row_id: id,
        action,
        old_owner_id: priorOwner,
        new_owner_id: newOwnerId,
        actor_role: safeRole,
      }),
    ],
  );

  return { changed: true, prior_owner: priorOwner, new_owner: newOwnerId };
}

module.exports = { applyOwnerChange };
