/**
 * migrations-registry — per-step metadata for the migration runner + the
 * schema-status visibility surface, DERIVED from the declarative registry
 * (migration-steps.js) after the fmb-1329 baseline reset.
 *
 * Before the reset this file hand-listed 42 legacy step entries (errno maps +
 * guard columns). Those steps and their runtime code are deleted (fmb-1329 T4);
 * their metadata went with them. The registry is now a thin view over
 * MIGRATION_STEPS so there is ONE source of truth: a step's severity /
 * failure_policy / errno metadata lives on its registry entry (spec §4.1).
 *
 * getMigration(step) returns the derived entry or null. UNREGISTERED steps
 * inherit the fail-safe defaults at the call sites — the migration-sanitizer's
 * generic errno path and the schema-status rollup's DEFAULT_SEVERITY — so an
 * unknown step is treated as terminate / critical.
 *
 * The registry shipped EMPTY through PR1 (MIGRATION_STEPS was empty
 * post-baseline). PR2 (fmb-1329 T8) added the first entries; each entry MAY
 * carry `failure_policy`, `severity`, and `known_errno_mapping` and this view
 * surfaces them unchanged.
 */
const { MIGRATION_STEPS } = require('./migration-steps');

/** Default policy when a step is absent from the registry — fail-safe terminate. */
const DEFAULT_FAILURE_POLICY = 'terminate';
const DEFAULT_SEVERITY = 'critical';

/**
 * @typedef {Object} MigrationEntry
 * @property {string} step
 * @property {'terminate'|'recover'} failure_policy
 * @property {'critical'|'warning'} severity
 * @property {Array<{errno: number, code: string}>} known_errno_mapping
 */

/** @type {Object.<string, MigrationEntry>} — derived view over MIGRATION_STEPS. */
const MIGRATIONS = Object.freeze(Object.fromEntries(
  MIGRATION_STEPS.map((entry) => [entry.step, Object.freeze({
    step: entry.step,
    failure_policy: entry.failure_policy || DEFAULT_FAILURE_POLICY,
    severity: entry.severity || DEFAULT_SEVERITY,
    known_errno_mapping: Object.freeze(entry.known_errno_mapping || []),
  })]),
));

/**
 * @param {string} step
 * @returns {MigrationEntry|null}
 */
function getMigration(step) {
  if (typeof step !== 'string') return null;
  return MIGRATIONS[step] || null;
}

module.exports = {
  MIGRATIONS,
  DEFAULT_FAILURE_POLICY,
  DEFAULT_SEVERITY,
  getMigration,
};
