/**
 * migration-steps-reconcile-default-template.test.js
 *
 * `cap_rules_reconcile_default_template` inserts any DEFAULT_RULE_TEMPLATE
 * (rule-types.js) global row a deployment is missing — the general repair for a
 * template row that shipped without a backfill migration — exactly once, gated
 * by a `system_settings` marker so an operator deletion after the step ran is
 * never resurrected. Mirrors migration-steps-standby-keep-in-one-site-seed.test.js's
 * idiom for exercising a custom step's run()/probe()/remediationSql() against a
 * mocked conn, no real DB (the real-DB matrix is scenario 11 of migration-e2e).
 */
import { describe, it, expect } from 'vitest';

const { MIGRATION_STEPS } = require('../migration-steps');
const { DEFAULT_RULE_TEMPLATE } = require('../../shared/capacity/rule-types');

const t = (table) => `fmb_${table}`;

const MARKER_KEY = 'migration_reconcile_default_rule_template';
const STANDBY_KEEP_APART = { type: 'keep-apart', group_by: 'each_standby_cluster' };
const STANDBY_KEEP_IN_ONE = { type: 'keep-in-one-site', group_by: 'each_standby_cluster' };
const isRow = (id) => (r) => r.type === id.type && r.group_by === id.group_by;

// Global rows as the probe's own SELECT reads them back — only type/group_by.
const templateAsRows = (rows) => rows.map((r) => ({ type: r.type, group_by: r.group_by }));
const ALL_ROWS = templateAsRows(DEFAULT_RULE_TEMPLATE);
const SEVEN_ROWS = ALL_ROWS.filter((r) => !isRow(STANDBY_KEEP_APART)(r)); // missing keep-apart standby
const SIX_ROWS = ALL_ROWS.filter((r) => !isRow(STANDBY_KEEP_APART)(r) && !isRow(STANDBY_KEEP_IN_ONE)(r));

function makeConn({ tableExists = true, rows = [], markerPresent = false }) {
  const queries = [];
  return {
    queries,
    async query(sql, params = []) {
      queries.push({ sql, params });
      if (/information_schema\.TABLES/i.test(sql)) return tableExists ? [{ 1: 1 }] : [];
      if (/FROM `fmb_system_settings`\s+WHERE `key` = \?/.test(sql)) {
        return markerPresent ? [{ value: '"1"' }] : [];
      }
      if (/^SELECT type, group_by\s+FROM/.test(sql)) return rows;
      return {}; // INSERT
    },
  };
}

const insertsIn = (conn, table) =>
  conn.queries.filter((q) => /^INSERT INTO/.test(q.sql) && (!table || q.sql.includes(`\`${table}\``)));
const capRuleInserts = (conn) => insertsIn(conn, 'fmb_cap_rules');
const markerInserts = (conn) => insertsIn(conn, 'fmb_system_settings').filter((q) => q.params.includes(MARKER_KEY));

describe('cap_rules_reconcile_default_template', () => {
  const step = MIGRATION_STEPS.find((s) => s.step === 'cap_rules_reconcile_default_template');

  it('registry entry carries a probe() and a remediationSql() at version 3.2.814', () => {
    expect(step).toBeTruthy();
    expect(typeof step.probe).toBe('function');
    expect(typeof step.remediationSql).toBe('function');
    expect(step.version).toBe('3.2.814');
  });

  it('table absent (fresh install) -> probe satisfied, run is a no-op (no insert, no marker)', async () => {
    const conn = makeConn({ tableExists: false });
    expect(await step.probe(conn, t)).toBe(true);
    await step.run({ conn, t });
    expect(capRuleInserts(conn).length).toBe(0);
    expect(markerInserts(conn).length).toBe(0);
  });

  it('marker present -> probe satisfied even with a row missing; run does NOT re-seed (durable deletion)', async () => {
    const conn = makeConn({ rows: SEVEN_ROWS, markerPresent: true });
    expect(await step.probe(conn, t)).toBe(true);
    await step.run({ conn, t });
    expect(capRuleInserts(conn).length).toBe(0);
  });

  it('marker absent + empty set -> seeds the FULL template in ONE insert + marker', async () => {
    const conn = makeConn({ rows: [] });
    expect(await step.probe(conn, t)).toBe(false);
    await step.run({ conn, t });
    const inserts = capRuleInserts(conn);
    expect(inserts.length).toBe(1); // single multi-row INSERT, per-statement atomic
    expect(inserts[0].params.length).toBe(DEFAULT_RULE_TEMPLATE.length * 7);
    expect(markerInserts(conn).length).toBe(1);
  });

  it('marker absent + 7-row post-.807 set -> inserts ONLY the missing keep-apart standby row + marker', async () => {
    const conn = makeConn({ rows: SEVEN_ROWS });
    expect(await step.probe(conn, t)).toBe(false);
    await step.run({ conn, t });
    const inserts = capRuleInserts(conn);
    expect(inserts.length).toBe(1);
    expect(inserts[0].params).toEqual([
      'keep-apart', 'Keep apart (standby)', 'db_instance', 'each_standby_cluster', '{}', 'hard', 1,
    ]);
    expect(markerInserts(conn).length).toBe(1);
  });

  it('marker absent + 6-row pre-3.2.536 set -> inserts BOTH missing standby rows + marker', async () => {
    const conn = makeConn({ rows: SIX_ROWS });
    await step.run({ conn, t });
    const inserts = capRuleInserts(conn);
    expect(inserts.length).toBe(1);
    expect(inserts[0].params.length).toBe(2 * 7); // two missing rows in one statement
    expect(markerInserts(conn).length).toBe(1);
  });

  it('marker absent + already-complete set -> inserts nothing but WRITES the marker (self-heals the resurrection window)', async () => {
    const conn = makeConn({ rows: ALL_ROWS });
    expect(await step.probe(conn, t)).toBe(false);
    await step.run({ conn, t });
    expect(capRuleInserts(conn).length).toBe(0);
    expect(markerInserts(conn).length).toBe(1);
  });

  it('remediationSql(): one own-identity-guarded INSERT per template row + a marker upsert last', () => {
    const sql = step.remediationSql(t);
    expect(Array.isArray(sql)).toBe(true);
    expect(sql.length).toBe(DEFAULT_RULE_TEMPLATE.length + 1);
    const rowInserts = sql.filter((s) => s.includes(`INSERT INTO \`${t('cap_rules')}\``));
    expect(rowInserts.length).toBe(DEFAULT_RULE_TEMPLATE.length);
    // Every insert is guarded by its OWN (type, group_by) identity (sequential-
    // safe: inserting one row never changes another row's guard). NO whole-set-
    // empty guard, and no row inserted unconditionally.
    for (const row of DEFAULT_RULE_TEMPLATE) {
      const stmt = rowInserts.find(
        (s) => s.includes(`type = '${row.type}' AND group_by = '${row.group_by}'`),
      );
      expect(stmt, `no guarded insert for ${row.type}/${row.group_by}`).toBeTruthy();
      expect(stmt).toContain('WHERE NOT EXISTS (SELECT 1 FROM');
      expect(stmt).toContain('scenario_id IS NULL AND type =');
      // Also gated on marker absence — a stale exported script applied AFTER
      // the marker exists (e.g. boot migration already ran) must NOT
      // resurrect an operator-deleted row (mirrors run()'s marker short-circuit).
      expect(stmt).toContain(
        `AND NOT EXISTS (SELECT 1 FROM \`${t('system_settings')}\` WHERE \`key\` = '${MARKER_KEY}')`,
      );
    }
    // Marker upsert runs last so a re-derivation after apply reports satisfied.
    const last = sql[sql.length - 1];
    expect(last).toContain(`INSERT INTO \`${t('system_settings')}\``);
    expect(last).toContain(MARKER_KEY);
    expect(last).toContain('ON DUPLICATE KEY UPDATE');
    for (const stmt of sql) expect(stmt.trim().endsWith(';')).toBe(true);
  });
});
