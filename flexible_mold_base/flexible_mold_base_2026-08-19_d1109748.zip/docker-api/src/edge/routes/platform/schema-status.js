/**
 * schema-status.js — Visibility surface admin endpoint.
 *
 * Implements RFC docs/RFC/visibility-surface.md §4. The endpoint is
 * admin-only and live-derives schema state from three sources at request
 * time (Path 3 — no new table). The /health endpoint stays untouched: a
 * public schema_status field would leak deployment health to unauthenticated
 * callers, in parity with the err.message stripping already done on
 * /health.db (see index-infra.js boot-banner).
 *
 * Routes:
 *   GET /edge/platform/schema-status   — admin only, live-derived state
 *
 * Response shape:
 *   {
 *     schema_status:    'aligned' | 'degraded' | 'failed' | 'unknown' | 'unsupported',
 *     skipped_steps:    [{ code, errno, sqlstate, step, category }, ...],
 *     app_version:      string  (program/release version, from package.json),
 *     target_version:   string,
 *     current_version:  string,
 *     baseline_version: string  (minimum supported schema stamp),
 *     missing_tables:   string[]                       (base table names),
 *     missing_columns:  [{ table, column }, ...]       (base names),
 *     column_drift:     [{ table, column, kind, expected, actual }, ...]
 *                       (ADVISORY type/nullability drift for columns present on
 *                        both sides — never affects schema_status),
 *     derived_at:       ISO-8601 string
 *   }
 *
 * SAFETY: derive failures must NOT propagate as 5xx. The endpoint wraps the
 * three derive queries in an overall try/catch and a hard timeout, returning
 * schema_status: 'unknown' instead. The raw err goes to the application
 * logger only — the endpoint output is sanitised already because the only
 * error fields it surfaces come from migration-sanitizer.
 */
const router = require('express').Router();
const { pool, t, PLATFORM_SCHEMA_VERSION } = require('../../db');
const { TABLES } = require('../../../shared/constants');
const { apiOk, apiError, requireAdmin, uuidv4 } = require('../../../shared/helpers');
const { getMigration, DEFAULT_SEVERITY } = require('../../migrations-registry');
const { sanitizeMigrationError } = require('../../../shared/lib/migration-sanitizer');
const { compareVersions } = require('../../lib/schema-version-derive');
const { readSchemaColumns, computeMissing, computeColumnDrift } = require('../../lib/schema-comparison');
const { derivePendingStepNames } = require('../../lib/pending-steps');
const { ENGINE_TABLE_NAMES } = require('../../../table-ddls');
const { BASELINE_SCHEMA_VERSION, MIGRATION_STEPS } = require('../../migration-steps');
// Program (release) version. docker-api/package.json is the single source —
// shipped in every topology (no leak, unlike CHANGELOG) and kept == CHANGELOG's
// top shipped entry by the Ship Gate version-sync lint. Guarded: the version
// display is non-critical, so a packaging gap (package.json absent from the
// runtime image) degrades to 'unknown' rather than crashing edge boot.
let APP_VERSION = 'unknown';
try {
  APP_VERSION = require('../../../../package.json').version || 'unknown';
} catch {
  // package.json not packaged into this image — surface 'unknown', don't throw.
}
const { logger: rootLogger } = require('../../../shared/lib/logger');
const logger = rootLogger.child({ module: 'schema-status' });

const DERIVE_TIMEOUT_MS = 3000;
const SKIP_LOOKBACK_LIMIT = 200;

/**
 * Race a promise against a timeout. Resolves with `{ ok: true, value }` on
 * success or `{ ok: false, reason }` on timeout/throw — never throws so the
 * outer route handler can keep running.
 */
function _withTimeout(promise, ms, label) {
  return new Promise((resolve) => {
    let settled = false;
    const timer = setTimeout(() => {
      if (settled) return;
      settled = true;
      resolve({ ok: false, reason: `${label} timed out after ${ms}ms` });
    }, ms);
    Promise.resolve(promise).then(
      (value) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        resolve({ ok: true, value });
      },
      (err) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        resolve({ ok: false, reason: (err && err.message) || 'derive failed' });
      },
    );
  });
}

/**
 * Read platform_schema_version from system_settings. Returns the stamp
 * string (e.g. "3.2.99") or `null` when the stamp row is missing/unparseable
 * so the caller can derive an honest version from the live schema shape
 * instead of inventing an initial-install marker.
 *
 * @param {object} conn - DB connection with `.query(sql)` method.
 * @param {function} [tableFn=t] - Table-prefix helper; defaults to the module-level
 *   `t()` from db.js. Tests pass their own no-op to avoid requiring a live pool.
 */
async function _readCurrentVersion(conn, tableFn = t) {
  const rows = await conn.query(
    `SELECT value FROM \`${tableFn(TABLES.SYSTEM_SETTINGS)}\` WHERE \`key\` = 'platform_schema_version' LIMIT 1`,
  );
  if (!rows.length || !rows[0].value) return null;
  // SAFETY: a MariaDB JSON column the driver already decoded comes back as a
  // bare string ('3.2.341'), not JSON text, so JSON.parse throws on it — fall
  // back to the raw value (mirrors the tolerant settings read in settings.js).
  let parsed;
  try {
    parsed = typeof rows[0].value === 'string' ? JSON.parse(rows[0].value) : rows[0].value;
  } catch {
    parsed = rows[0].value;
  }
  return typeof parsed === 'string' ? parsed : null;
}

/**
 * Pull recent skipped/alter_skipped events newer than the most recent
 * schema_migration.completed event (or all if no completed event exists).
 * Dedupes to one entry per step (most-recent wins). Returns sanitised
 * payloads suitable for direct inclusion in the response.
 */
async function _readRecentSkips(conn) {
  const completedRow = await conn.query(
    `SELECT created_at FROM \`${t(TABLES.FEATURE_AUDIT)}\`
      WHERE event_type = 'schema_migration.completed'
      ORDER BY created_at DESC
      LIMIT 1`,
  );
  const sinceCutoff = completedRow.length ? completedRow[0].created_at : null;

  const params = [];
  let cutoffClause = '';
  if (sinceCutoff) {
    cutoffClause = 'AND created_at > ?';
    params.push(sinceCutoff);
  }

  const rows = await conn.query(
    `SELECT event_type, metadata, created_at FROM \`${t(TABLES.FEATURE_AUDIT)}\`
      WHERE event_type IN ('schema_migration.skipped', 'schema_migration.alter_skipped')
      ${cutoffClause}
      ORDER BY created_at DESC
      LIMIT ?`,
    [...params, SKIP_LOOKBACK_LIMIT],
  );

  const seenSteps = new Map();
  for (const row of rows) {
    let payload;
    try {
      payload = typeof row.metadata === 'string' ? JSON.parse(row.metadata) : row.metadata;
    } catch {
      continue;
    }
    if (!payload || typeof payload !== 'object' || !payload.step) continue;
    if (seenSteps.has(payload.step)) continue;
    seenSteps.set(payload.step, { event_type: row.event_type, payload });
  }

  return Array.from(seenSteps.values()).map(({ event_type, payload }) => {
    if (event_type === 'schema_migration.alter_skipped') {
      // alter_skipped events store { step, table, column } only — re-shape
      // into the sanitiser's closed-enum contract so the consumer never
      // has to switch on event_type.
      return sanitizeMigrationError({ code: 'ER_TABLEACCESS_DENIED_ERROR' }, payload.step);
    }
    // schema_migration.skipped is already a sanitiser output — but we
    // re-validate the keys to keep the response shape consistent even if
    // the audit row was written by an earlier code version with extra
    // fields. The sanitiser is idempotent on a sanitised input shape.
    if (payload.code && payload.errno !== undefined && payload.category) {
      return {
        code: String(payload.code),
        errno: payload.errno === null ? null : Number(payload.errno),
        sqlstate: payload.sqlstate || null,
        step: payload.step,
        category: payload.category,
      };
    }
    return sanitizeMigrationError(payload, payload.step);
  });
}

/**
 * Severity rollup with the full-comparison precedence (spec §4.8):
 *   unsupported (baseline guard)          → 'unsupported' (overrides all)
 *   any critical audit skip               → 'failed'
 *   any warning skip OR any missing item  → 'degraded'
 *   zero skips + zero missing + stamp≥tgt → 'aligned'
 *   otherwise (stamp < target)            → 'degraded'
 * Steps absent from the registry inherit DEFAULT_SEVERITY ('critical') — fail-safe.
 */
function _rollupStatus(skippedSteps, missingCount, currentVersion, targetVersion, unsupported) {
  if (unsupported) return 'unsupported';
  for (const s of skippedSteps) {
    const entry = getMigration(s.step);
    const severity = entry ? entry.severity : DEFAULT_SEVERITY;
    if (severity === 'critical') return 'failed';
  }
  if (skippedSteps.length > 0) return 'degraded';
  if (missingCount > 0) return 'degraded';
  return compareVersions(currentVersion, targetVersion) >= 0 ? 'aligned' : 'degraded';
}

/**
 * Pure derive core (unit-testable without a live pool). Combines the three read
 * sources — stamp, audit skips, live columns — into the response verdict.
 *
 * `comparisonOk=false` means the live-column read failed (timeout / access
 * denied); the comparison is then unavailable, so an otherwise-'aligned' verdict
 * degrades to 'unknown' (we cannot prove alignment without the comparison).
 *
 * @param {{stampVersion: string|null, auditSkips: Array, liveByTable: Map|null, comparisonOk: boolean}} input
 * @param {(base: string) => string} [tableFn=t]
 */
function _deriveVerdict({ stampVersion, auditSkips, liveByTable, comparisonOk }, tableFn = t) {
  const hadStamp = stampVersion !== null;

  const { missing_tables, missing_columns } = comparisonOk && liveByTable
    ? computeMissing(liveByTable, tableFn)
    : { missing_tables: [], missing_columns: [] };
  const missingCount = missing_tables.length + missing_columns.length;

  // Mirror migrations.js _isUnsupportedBaseline read-only (never runs a
  // migration): a stamp below baseline is unsupported in every context; an
  // unstamped DB is unsupported only when it carries engine tables yet fails the
  // full-manifest completeness check (a fresh empty DB — zero engine tables — is
  // a normal install, and a complete unstamped schema is the just-set-up wizard
  // case). Comparison results are already computed above, so this reuses them.
  const engineTablesPresent = comparisonOk && liveByTable
    ? ENGINE_TABLE_NAMES.some((base) => liveByTable.has(tableFn(base)))
    : false;
  const unsupported = hadStamp
    ? compareVersions(stampVersion, BASELINE_SCHEMA_VERSION) < 0
    : (engineTablesPresent && missingCount > 0);

  // Audit skips are version-gated: once the stamp reaches target a successful
  // migration may have been masked by a dropped completion audit row, so stale
  // skip events would falsely report degraded forever. The comparison — never
  // suppressed — covers the "actually broken" case.
  const versionAtOrAheadOfTarget =
    hadStamp && compareVersions(stampVersion, PLATFORM_SCHEMA_VERSION) >= 0;
  const skipped_steps = versionAtOrAheadOfTarget ? [] : auditSkips;

  // DISPLAY value only. Absent stamp: a no-DDL DBA-migrated box is provably at
  // target only when the comparison shows zero missing AND no skip was recorded.
  const current_version = hadStamp
    ? stampVersion
    : (comparisonOk && missingCount === 0 && skipped_steps.length === 0 ? PLATFORM_SCHEMA_VERSION : '3.0.0');

  const rollupVersion = hadStamp ? stampVersion : '3.0.0';
  let schema_status = _rollupStatus(skipped_steps, missingCount, rollupVersion, PLATFORM_SCHEMA_VERSION, unsupported);
  if (!comparisonOk && schema_status === 'aligned') schema_status = 'unknown';

  return { schema_status, skipped_steps, missing_tables, missing_columns, current_version };
}

/**
 * @openapi
 * /edge/platform/schema-status:
 *   get:
 *     summary: Live-derive platform schema-migration health (admin only)
 *     tags: [Platform - Schema Status]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Derived schema status
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 schema_status: { type: string, enum: [aligned, degraded, failed, unknown] }
 *                 skipped_steps:
 *                   type: array
 *                   items:
 *                     type: object
 *                     properties:
 *                       code:     { type: string }
 *                       errno:    { type: integer, nullable: true }
 *                       sqlstate: { type: string,  nullable: true }
 *                       step:     { type: string }
 *                       category: { type: string }
 *                 app_version:     { type: string }
 *                 target_version:  { type: string }
 *                 current_version: { type: string }
 *                 derived_at:      { type: string, format: date-time }
 *       403: { description: Admin required }
 */
router.get('/', async (req, res) => {
  if (!requireAdmin(req, res)) return;

  let conn;
  // NOTE: Hoist out of the try block so the finally cleanup can read it.
  // Previously declared with let inside try, which is a different scope from
  // finally — the reference threw a ReferenceError that the outer catch
  // swallowed, and neither release() nor destroy() ran, leaking pool
  // connections until exhaustion.
  let connectionPoisoned = false;
  try {
    conn = await pool.ro.getConnection();

    // NOTE: _withTimeout resolves early on timeout but does NOT cancel the
    // underlying MariaDB query; the conn is still mid-protocol when we'd kick
    // the next query. Sequential queries on a poisoned conn would queue up to
    // 9 seconds (3×3s) of wall-clock for the supposed 3s hard timeout, AND
    // the post-finally release would hand a busy conn to the next request.
    // Short-circuit out of the derive on first timeout so this gets
    // fresh-socket'd.
    const currentRace = await _withTimeout(
      _readCurrentVersion(conn),
      DERIVE_TIMEOUT_MS,
      'platform_schema_version read',
    );
    if (!currentRace.ok) connectionPoisoned = true;

    const POISONED_RACE = { ok: false, reason: 'connection poisoned by prior timeout' };

    const skipsRace = connectionPoisoned
      ? POISONED_RACE
      : await _withTimeout(
          _readRecentSkips(conn),
          DERIVE_TIMEOUT_MS,
          'recent skips read',
        );
    if (!skipsRace.ok) connectionPoisoned = true;

    // Derive source #3 (fmb-1329 T5): full expected-vs-live schema comparison.
    // One bounded information_schema.COLUMNS dump; the manifest diff (existence
    // level) yields missing_tables/missing_columns and the engine-table probe
    // for the baseline-unsupported verdict. A read failure leaves the comparison
    // unavailable — _deriveVerdict degrades an otherwise-aligned result to
    // 'unknown' rather than false-greening off stamp + clean audit alone.
    const columnsRace = connectionPoisoned
      ? POISONED_RACE
      : await _withTimeout(
          readSchemaColumns(conn),
          DERIVE_TIMEOUT_MS,
          'schema columns read',
        );
    if (!columnsRace.ok) connectionPoisoned = true;

    if (!currentRace.ok || !skipsRace.ok) {
      // Single-source derive failure — surface unknown rather than a 5xx so
      // the dashboard / UI keeps working. Logger captures the raw reason
      // for ops follow-up.
      logger.warn(
        { current: currentRace, skips: skipsRace },
        'schema-status derive partial failure — returning unknown',
      );
      return res.json(apiOk({
        schema_status: 'unknown',
        skipped_steps: [],
        app_version: APP_VERSION,
        target_version: PLATFORM_SCHEMA_VERSION,
        current_version: null,
        baseline_version: BASELINE_SCHEMA_VERSION,
        missing_tables: [],
        missing_columns: [],
        column_drift: [],
        pending_steps: [],
        derived_at: new Date().toISOString(),
      }));
    }

    // Derive source #4 (Codex R2): names of destructive/custom registry steps
    // not yet satisfied — invisible to the missing-structure comparison. Only
    // meaningful while the stamp is behind target (no stamp = also behind); at
    // or ahead of target it is empty by definition. Read-only (SELECT probes).
    // Informational only: it never flips the rollup — a stamp behind target
    // already yields 'degraded' via the version-behind rule, so pending_steps
    // and that verdict move together (no double-count). A derive failure
    // degrades to [] and logs (never 5xx), consistent with the other sources.
    const stampVersion = currentRace.value;
    const behindTarget =
      stampVersion === null || compareVersions(stampVersion, PLATFORM_SCHEMA_VERSION) < 0;
    const pendingRace = connectionPoisoned || !behindTarget
      ? { ok: true, value: [] }
      : await _withTimeout(
          derivePendingStepNames(conn, t, MIGRATION_STEPS),
          DERIVE_TIMEOUT_MS,
          'pending steps derive',
        );
    if (!pendingRace.ok) {
      connectionPoisoned = true;
      logger.warn(
        { reason: pendingRace.reason },
        'schema-status: pending-steps derive failed — returning empty pending_steps',
      );
    }
    const pending_steps = pendingRace.ok ? pendingRace.value : [];

    const {
      schema_status,
      skipped_steps,
      missing_tables,
      missing_columns,
      current_version,
    } = _deriveVerdict({
      stampVersion: currentRace.value,
      auditSkips: skipsRace.value,
      liveByTable: columnsRace.ok ? columnsRace.value : null,
      comparisonOk: columnsRace.ok,
    });
    if (!columnsRace.ok) {
      logger.warn(
        { reason: columnsRace.reason },
        'schema-status: live-column read failed — comparison unavailable',
      );
    }

    // ADVISORY type/nullability drift (informational). Derived in-memory from
    // the already-fetched live-column dump — no extra query. Kept OUT of
    // _deriveVerdict on purpose so it can never move the verdict/severity, and
    // wrapped so a drift-compute error degrades to [] rather than 5xx.
    let column_drift = [];
    if (columnsRace.ok && columnsRace.value) {
      try {
        column_drift = computeColumnDrift(columnsRace.value, t);
      } catch (err) {
        logger.warn({ err: err && err.message }, 'schema-status: column-drift compute failed — returning []');
        column_drift = [];
      }
    }

    // Optional: log an interactive-read audit row when an admin hits the
    // endpoint via the UI (?source=ui). Automation polls (without ?source)
    // skip the audit row to keep growth bounded. RFC §6.
    //
    // NOTE: This is an INSERT, so the read-only conn (acquired from pool.ro
    // for the derive queries) cannot service it on RW/RO topologies — every
    // interactive read would silently lose its audit row. Acquire a separate
    // writer connection for the insert.
    if (req.query && req.query.source === 'ui') {
      let auditConn;
      try {
        auditConn = await pool.rw.getConnection();
        await auditConn.query(
          `INSERT INTO \`${t(TABLES.FEATURE_AUDIT)}\` (id, event_type, user_id, metadata)
           VALUES (?, 'schema_status.read', ?, ?)`,
          [
            uuidv4(),
            req.user?.id || null,
            JSON.stringify({ schema_status, skipped_count: skipped_steps.length }),
          ],
        );
      } catch (err) {
        logger.warn({ err: err && err.message }, 'schema_status.read audit row dropped');
      } finally {
        if (auditConn) {
          try { auditConn.release(); } catch { /* released */ }
        }
      }
    }

    res.json(apiOk({
      schema_status,
      skipped_steps,
      app_version: APP_VERSION,
      target_version: PLATFORM_SCHEMA_VERSION,
      current_version,
      baseline_version: BASELINE_SCHEMA_VERSION,
      missing_tables,
      missing_columns,
      column_drift,
      pending_steps,
      derived_at: new Date().toISOString(),
    }));
  } catch (err) {
    logger.error({ err }, 'schema-status derive failed unexpectedly');
    // SAFETY: still return 200/unknown rather than 5xx so the endpoint
    // never tears down a calling dashboard or UI. The hard error is in
    // the logger.
    res.json(apiOk({
      schema_status: 'unknown',
      skipped_steps: [],
      app_version: APP_VERSION,
      target_version: PLATFORM_SCHEMA_VERSION,
      current_version: null,
      baseline_version: BASELINE_SCHEMA_VERSION,
      missing_tables: [],
      missing_columns: [],
      column_drift: [],
      pending_steps: [],
      derived_at: new Date().toISOString(),
    }));
  } finally {
    if (conn) {
      // NOTE: A timed-out query may still be in flight on this connection
      // when we get here. Releasing it back to the pool would surface protocol
      // errors on the NEXT caller. Destroy instead. mariadb-node's destroy()
      // forces socket close so the pool re-creates a fresh connection;
      // release() returns the conn to the pool's idle queue — only safe when
      // we know all queries have settled.
      try {
        if (connectionPoisoned && typeof conn.destroy === 'function') {
          conn.destroy();
        } else {
          conn.release();
        }
      } catch {
        // Connection already gone — defensive try/catch keeps the
        // response from masking with a 5xx on cleanup error.
      }
    }
  }
});

/**
 * @openapi
 * /edge/platform/schema-status/proceed-anyway:
 *   post:
 *     summary: Admin override after a failed schema-status DB switch
 *     tags: [Platform - Schema Status]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [confirmation, connection_profile_id, schema_status, skipped_steps]
 *             properties:
 *               confirmation:           { type: string, enum: [OVERWRITE] }
 *               connection_profile_id:  { type: string }
 *               schema_status:          { type: string, enum: [failed, degraded, unsupported] }
 *               skipped_steps:          { type: array }
 *     responses:
 *       200: { description: Audit row written }
 *       400: { description: Validation error }
 *       403: { description: Admin required }
 */
router.post('/proceed-anyway', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  const body = req.body || {};
  if (body.confirmation !== 'OVERWRITE') {
    const e = apiError('confirmation must equal "OVERWRITE"', 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }
  if (typeof body.connection_profile_id !== 'string' || !body.connection_profile_id) {
    const e = apiError('connection_profile_id required', 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }
  // Closed union: the three statuses that actually route through the
  // blocking gate's Proceed-anyway override (SchemaStatusGate mode='failed'
  // covers failed AND unsupported; 'degraded' has its own non-blocking
  // details-only override path but still lands here via the same client
  // call shape). Any other value — including a future status this build
  // predates — is rejected, not silently accepted.
  if (!['failed', 'degraded', 'unsupported'].includes(body.schema_status)) {
    const e = apiError('schema_status must be failed, degraded, or unsupported', 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }
  // SECURITY: Client-supplied skipped_steps must be re-shaped to the closed
  // sanitiser contract before persistence — bypassing the sanitiser would let
  // raw err.message / SQL fragments / hostnames leak into feature_audit,
  // defeating RFC §6's no-leak invariant. We accept only the five sanitiser
  // keys, coerce types, and reject malformed entries silently (well-formed
  // entries pass through; malformed are dropped). The list is bounded so a
  // malicious admin cannot grow the audit row arbitrarily large.
  const MAX_SKIPS = 100;
  const rawSkips = Array.isArray(body.skipped_steps) ? body.skipped_steps.slice(0, MAX_SKIPS) : [];
  const skippedSteps = rawSkips
    .filter((s) => s && typeof s === 'object' && typeof s.step === 'string')
    .map((s) => ({
      code: typeof s.code === 'string' ? s.code : 'UNKNOWN',
      errno: typeof s.errno === 'number' ? s.errno : null,
      sqlstate: typeof s.sqlstate === 'string' ? s.sqlstate : null,
      step: s.step,
      category: typeof s.category === 'string' ? s.category : 'unknown',
    }));

  let conn;
  try {
    conn = await pool.rw.getConnection();
    await conn.query(
      `INSERT INTO \`${t(TABLES.FEATURE_AUDIT)}\` (id, event_type, user_id, metadata)
       VALUES (?, 'schema_status.proceed_anyway', ?, ?)`,
      [
        uuidv4(),
        req.user?.id || null,
        JSON.stringify({
          schema_status: body.schema_status,
          connection_profile_id: body.connection_profile_id,
          skipped_steps: skippedSteps,
          actor_role: req.user?.role || null,
        }),
      ],
    );
    res.json(apiOk({ recorded: true }));
  } catch (err) {
    logger.error({ err }, 'schema_status.proceed_anyway audit insert failed');
    const e = apiError('Database operation failed', 'INTERNAL_ERROR');
    res.status(e.status).json(e.body);
  } finally {
    if (conn) {
      try { conn.release(); } catch { /* released */ }
    }
  }
});

module.exports = router;
module.exports._internal = {
  _compareVersions: compareVersions,
  _rollupStatus,
  _withTimeout,
  _readCurrentVersion,
  _readSchemaColumns: readSchemaColumns,
  _computeComparison: computeMissing,
  _computeColumnDrift: computeColumnDrift,
  _deriveVerdict,
};
