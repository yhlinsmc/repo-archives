/**
 * Shared constants and helpers for the setup/* route modules.
 *
 * Extracted in PR 3b when setup.js (1209 lines) was split into feature-
 * scoped sub-files. Each sub-file exports a `register(router)` function
 * that attaches its handlers to the router assembled in setup/index.js.
 */

// System databases excluded from schema listing.
const SYSTEM_DBS = new Set(['information_schema', 'mysql', 'performance_schema', 'sys']);

/**
 * Resolve user identity for setup routes.
 *
 * On API-edge, req.user is set by s2s-verify middleware (trusted headers
 * from API-infra). During first setup, req.user is null (no one logged
 * in yet) — downstream handlers check this and allow anonymous access
 * for initial steps.
 *
 * The OIDC/JWT resolution that was here in v1.x is no longer needed
 * because edge never receives browser cookies or Bearer tokens directly —
 * all identity flows through the S2S trust chain.
 */
function resolveSetupUser(req) {
  return req.user || null;
}

module.exports = { SYSTEM_DBS, resolveSetupUser };
