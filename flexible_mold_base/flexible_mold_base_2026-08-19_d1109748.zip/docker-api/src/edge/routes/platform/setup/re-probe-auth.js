/**
 * POST /api/setup/re-probe-auth — admin-only.
 *
 * Re-runs detectAuthMode(pool, t) without requiring an edge restart.
 * Motivating scenario: edge booted while Keycloak was unreachable
 * and cached auth_mode='local' under source='auto_detect'. The asymmetric
 * keycloak-health watchdog (keycloak→local only) never transitions back
 * once Keycloak recovers, so the panel surfaces this as "stuck cache" and
 * offers a one-click Promote button that hits this endpoint.
 *
 * Invariants:
 *   - requireAdmin gate (role === 'admin'). Pre-admin-creation flow is
 *     explicitly out of scope — panel hides the button when no admin exists.
 *   - Writes a login_audit row (auth_provider='SYSTEM', reason tag) so the
 *     mode change is traceable.
 *   - Returns {old_mode, new_mode, live_reachable, source} for the UI.
 */
const { pool, t } = require('../../../db');
const { detectAuthMode, resolveAuthMode, getAuthModeSource, probeKeycloakDiscovery } = require('../../../../shared/config');
const { apiOk, apiError, requireAdmin } = require('../../../../shared/helpers');
const { logger: rootLogger } = require('../../../../shared/lib/logger');
const { TABLES } = require('../../../../shared/constants');

const logger = rootLogger.child({ module: 'setup:re-probe-auth' });

module.exports = function register(router) {
  router.post('/re-probe-auth', async (req, res) => {
    if (!requireAdmin(req, res)) return;

    const oldMode = resolveAuthMode();
    const liveReachable = await probeKeycloakDiscovery();

    try {
      await detectAuthMode(pool, t);
    } catch (err) {
      logger.error({ err }, 'detectAuthMode threw during re-probe');
      const e = apiError('Failed to re-probe auth mode', 'INTERNAL_ERROR', 500);
      return res.status(e.status).json(e.body);
    }

    const newMode = resolveAuthMode();
    const source = getAuthModeSource();

    // Best-effort audit entry — DB write failures here should not mask the
    // successful in-memory mode change.
    //
    // Note: login_audit.auth_provider is ENUM('LOCAL','KEYCLOAK','SUPABASE');
    // 'SYSTEM' is NOT a valid value (would silently truncate under strict mode).
    // Recording the *new* mode in upper-case keeps the column meaningful and
    // matches keycloak-health.js degradation events.
    try {
      const conn = await pool.rw.getConnection();
      try {
        const provider = newMode === 'keycloak' ? 'KEYCLOAK' : 'LOCAL';
        await conn.query(
          `INSERT INTO \`${t(TABLES.LOGIN_AUDIT)}\` (username, auth_provider, reason, success)
           VALUES (?, ?, ?, TRUE)`,
          [req.user.email || 'admin', provider, 'auth_mode_reprobe_by_admin'],
        );
      } finally {
        conn.release();
      }
    } catch (err) {
      logger.warn({ err }, 'login_audit insert failed during re-probe (mode change still effective)');
    }

    logger.info(
      { admin: req.user.email, old_mode: oldMode, new_mode: newMode, source, live_reachable: liveReachable },
      'auth mode re-probed by admin',
    );

    res.json(apiOk({
      old_mode: oldMode,
      new_mode: newMode,
      live_reachable: liveReachable,
      source,
    }));
  });
};
