/**
 * POST /api/setup — First-run endpoint that creates the initial admin user.
 * Only works when the users table has zero rows; subsequent calls return 409.
 */
const bcrypt = require('bcryptjs');
const { pool, t } = require('../../../db');
const { apiOk, apiError, uuidv4 } = require('../../../../shared/helpers');
const { logger: rootLogger } = require('../../../../shared/lib/logger');
const { TABLES } = require('../../../../shared/constants');

const logger = rootLogger.child({ module: 'setup:create-admin' });

module.exports = function register(router) {
  router.post('/', async (req, res) => {
    const { email, password, display_name } = req.body;

    if (!email || !password) {
      const e = apiError('email and password are required', 'BAD_REQUEST', 400);
      return res.status(e.status).json(e.body);
    }

    if (password.length < 8) {
      const e = apiError('password must be at least 8 characters', 'BAD_REQUEST', 400);
      return res.status(e.status).json(e.body);
    }

    let conn;
    try {
      // NOTE: Setup flows always use pool.rw — SELECT guard + INSERT on same
      // conn, and the operation is a one-shot volatile flow where replica lag
      // on the guard read would be actively harmful.
      conn = await pool.rw.getConnection();

      // Check if any user already exists
      const rows = await conn.query(`SELECT COUNT(*) AS cnt FROM \`${t(TABLES.USERS)}\``);
      const count = Number(rows[0].cnt);

      if (count > 0) {
        const e = apiError(
          'Setup already completed. An admin user exists. Use /api/auth/login instead.',
          'SETUP_DONE',
          409,
        );
        return res.status(e.status).json(e.body);
      }

      // Create the first admin user
      const id = uuidv4();
      const hash = await bcrypt.hash(password, 10);
      await conn.query(
        `INSERT INTO \`${t(TABLES.USERS)}\` (id, email, password_hash, display_name, role) VALUES (?, ?, ?, ?, ?)`,
        [id, email, hash, display_name || email.split('@')[0], 'admin'],
      );

      res.json(apiOk({
        message: 'Initial admin user created successfully',
        user: { id, email, role: 'admin' },
      }));
    } catch (err) {
      // Email in structured binding only — see users.js:197 note. pino
      // redact.paths does not currently cover 'email'; concatenating into the
      // message string would bypass a future redact path addition.
      logger.error({ err, email }, 'Failed to create initial admin user');
      const e = apiError('Database operation failed', 'INTERNAL_ERROR', 500);
      res.status(e.status).json(e.body);
    } finally {
      if (conn) conn.release();
    }
  });
};
