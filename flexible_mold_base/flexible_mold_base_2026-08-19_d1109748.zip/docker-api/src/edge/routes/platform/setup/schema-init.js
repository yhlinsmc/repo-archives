/**
 * SchemaInit wizard step — handlers for creating and introspecting
 * database schemas (= MariaDB databases) + the tables within them:
 *
 *   POST /api/setup/init-db       — idempotent table creation + migrations
 *   GET  /api/setup/schemas       — list visible databases
 *   POST /api/setup/create-schema — create a new database + its engine tables
 *
 * init-db is by far the heaviest handler: it creates all 11 infrastructure
 * tables on the infra pool (or just the 7 engine tables on a dynamic
 * pool) and then runs migrations for older deployments (column renames,
 * keycloak_sub type fix, access_rules rule_value rewrite).
 */
const mariadb = require('mariadb');
const { pool, t, isPoolReady, getDbConfig, getDbConfigFull, getDynamicPool, runSchemaMigrations } = require('../../../db');
const {
  buildAllTableDDLs,
  buildEngineTableDDLs,
  INFRA_TABLE_NAMES,
  ENGINE_TABLE_NAMES,
} = require('../../../../table-ddls');
const { apiOk, apiError, uuidv4, requireAdmin } = require('../../../../shared/helpers');
const { logger: rootLogger } = require('../../../../shared/lib/logger');
const { requirePrefix } = require('../../../../shared/lib/db-errors');
const {
  preflightDdlGrants,
  DdlPrivilegeError,
} = require('../../../../shared/lib/preflight-grants');
const { SYSTEM_DBS } = require('./_shared');

// NOTE: Required fields for one-shot DDL credentials supplied by the wizard's
// StepDbConnect bootstrap mode. tablePrefix is required because internal
// deployments differ in prefix per CLAUDE.md §3. port is required to keep the
// wizard explicit; sane default of 3306 is admin's responsibility.
const BOOTSTRAP_CREDS_REQUIRED = ['host', 'port', 'user', 'password', 'database', 'tablePrefix'];

function _validateBootstrapCreds(creds) {
  if (!creds || typeof creds !== 'object') {
    return { ok: false, missing: BOOTSTRAP_CREDS_REQUIRED };
  }
  const missing = BOOTSTRAP_CREDS_REQUIRED.filter((k) => !creds[k]);
  return { ok: missing.length === 0, missing };
}

const { TABLES } = require('../../../../shared/constants');

const logger = rootLogger.child({ module: 'setup:schema-init' });


function ddlPreflightErrorResponse(err) {
  const e = apiError(
    'DB service account lacks required DDL privileges. Use the GRANT hint and retry setup, or re-run with bootstrap_credentials.',
    'PREFLIGHT_MISSING_PRIVILEGES_FOR_DDL',
    400,
    {
      details: {
        missing_create: err.missingCreate,
        missing_alter: err.missingAlter,
        // NOTE: Surface the bootstrap retry option to the wizard frontend.
        // Two recovery paths exist: (a) ask DBA to run grantHint, then retry
        // without body, or (b) supply bootstrap_credentials in body and retry
        // one-shot.
        retry_with_bootstrap_credentials: true,
      },
    },
  );
  e.body.error.grantHint = err.safeGrantSqlHint || null;
  return e;
}

// SECURITY: Identifier allowlist for the bootstrap path. database and
// tablePrefix are concatenated into DDL identifiers via the dynamically-built
// prefixFn; a backtick or other shell metacharacter would otherwise break out
// of the quoted identifier.
const _BOOTSTRAP_IDENT_RE = /^[a-zA-Z0-9_]+$/;

/**
 * One-shot DDL with admin-supplied credentials.
 * Credentials NEVER persist (no saveConfig, no caching). Pool is ended
 * in finally. Errors propagate as structured apiError responses.
 */
async function _handleBootstrapInitDb(req, res, bootstrapCreds) {
  // NOTE: When pool.rw is already configured (deployment past first-run),
  // bootstrap_credentials must require admin auth. Otherwise an
  // unauthenticated caller could hit /api/setup/init-db with their own
  // credentials and run DDL on the target host. First-run (pool null) is
  // intentionally open — see the legacy path's users-count escape hatch
  // for the parallel rationale.
  if (isPoolReady()) {
    if (!req.user || req.user.role !== 'admin') {
      const e = apiError('Admin required', 'FORBIDDEN', 403);
      return res.status(e.status).json(e.body);
    }
  }

  const validation = _validateBootstrapCreds(bootstrapCreds);
  if (!validation.ok) {
    const e = apiError(
      `bootstrap_credentials missing required fields: ${validation.missing.join(', ')}`,
      'BAD_REQUEST',
      400,
      { details: { missing: validation.missing } },
    );
    return res.status(e.status).json(e.body);
  }

  const { host, port, user, password, database, tablePrefix } = bootstrapCreds;

  // SECURITY: Identifier injection guard. Without this, a tablePrefix
  // with a backtick or comment character would break out of buildAllTableDDLs'
  // backtick quoting and run arbitrary SQL with the bootstrap creds' privileges.
  if (!_BOOTSTRAP_IDENT_RE.test(database)) {
    const e = apiError(
      'bootstrap_credentials.database must match /^[a-zA-Z0-9_]+$/',
      'BAD_REQUEST',
      400,
      { details: { field: 'database' } },
    );
    return res.status(e.status).json(e.body);
  }
  if (!_BOOTSTRAP_IDENT_RE.test(tablePrefix)) {
    const e = apiError(
      'bootstrap_credentials.tablePrefix must match /^[a-zA-Z0-9_]+$/',
      'BAD_REQUEST',
      400,
      { details: { field: 'tablePrefix' } },
    );
    return res.status(e.status).json(e.body);
  }

  const prefixFn = (n) => `${tablePrefix}${n}`;

  let bootstrapPool = null;
  let conn = null;
  const tablesCreated = [];
  const errors = [];

  try {
    bootstrapPool = mariadb.createPool({
      host,
      port: Number(port),
      user,
      password,
      database,
      connectionLimit: 1,
      acquireTimeout: 8000,
      connectTimeout: 8000,
      // SECURITY: Short-lived pool — close as soon as init-db completes.
      // Do not let connections idle (this would keep privileged credentials
      // resident in pool memory).
      idleTimeout: 1,
    });
    conn = await bootstrapPool.getConnection();

    // BRANCH 1 invariant: bootstrap creds MUST have CREATE/ALTER. Probe
    // first so we fail with a structured error instead of a half-built
    // schema if the admin pasted the runtime account by mistake.
    const allNames = INFRA_TABLE_NAMES.concat(ENGINE_TABLE_NAMES);
    await preflightDdlGrants(conn, database, allNames, prefixFn, { user, tablePrefix });

    const ddls = buildAllTableDDLs(prefixFn);
    for (const ddl of ddls) {
      try {
        await conn.query(ddl);
        const match = ddl.match(/`([^`]+)`/);
        tablesCreated.push(match ? match[1] : '?');
      } catch (err) {
        if (!err.message.toLowerCase().includes('already exists')) {
          // NOTE: Do not echo back raw err.message in the response — it can
          // include the failing SQL on parse errors. Log the full err for
          // operators; return a code-only summary.
          logger.warn({ err }, 'bootstrap DDL row failed');
          errors.push((err.code || 'DDL_ERROR'));
        } else {
          const match = ddl.match(/`([^`]+)`/);
          tablesCreated.push(match ? match[1] : '?');
        }
      }
    }

    return res.json(apiOk({
      tables_created: tablesCreated,
      errors,
      target: database,
      table_type: 'all',
      via: 'bootstrap',
    }));
  } catch (err) {
    if (err instanceof DdlPrivilegeError) {
      const e = ddlPreflightErrorResponse(err);
      return res.status(e.status).json(e.body);
    }
    logger.error(
      {
        err,
        // Body fields kept opaque in the log. The redact paths in
        // logger.js redactConfig.paths catch bootstrap_credentials.*
        // before serialisation, but we ALSO never log the body shape here.
        target: { host, port, database, user, tablePrefix },
      },
      'bootstrap init-db failed',
    );
    const e = apiError('Database operation failed during bootstrap', err.code || 'INTERNAL_ERROR', 500);
    return res.status(e.status).json(e.body);
  } finally {
    if (conn) {
      try { conn.release(); } catch {}
    }
    if (bootstrapPool) {
      // SECURITY: End the ephemeral pool unconditionally so credentials
      // don't linger in pool memory after the request.
      try { await bootstrapPool.end(); } catch {}
    }
  }
}

function register(router) {
  router.post('/init-db', async (req, res) => {
    const bootstrapCreds = req.body?.bootstrap_credentials;
    const targetDatabase = req.body?.database || null;
    const infraConfig = getDbConfig();
    const useEngineOnly = !bootstrapCreds && targetDatabase && infraConfig && targetDatabase !== infraConfig.database;

    // NOTE: Bootstrap path — admin-supplied one-shot DDL credentials. Builds
    // an ephemeral mariadb pool, runs DDL, destroys the pool. Credentials
    // NEVER reach disk. Used when pool.rw is null (first-deploy) OR the
    // runtime account lacks DDL grants but admin has root/DBA credentials for
    // one-time table creation.
    if (bootstrapCreds) {
      return _handleBootstrapInitDb(req, res, bootstrapCreds);
    }

    // BRANCH 3 short-circuit: pool not configured AND no bootstrap_credentials
    // supplied → tell wizard to prompt for one-shot DDL credentials. This
    // replaces the previous "500 Database operation failed" when the precheck
    // tries pool.rw.getConnection() on a null pool. 412 = "Precondition
    // Failed; supply different inputs and retry."
    if (!isPoolReady()) {
      const e = apiError(
        'Database pool is not configured. Provide bootstrap_credentials to create tables one-shot, or complete the Setup Wizard.',
        'NEED_BOOTSTRAP_CREDENTIALS',
        412,
        { details: { hint_code: 'pool_not_configured' } },
      );
      return res.status(e.status).json(e.body);
    }

    // Allow unauthenticated access only on first run (no users exist yet)
    let conn;
    try {
      conn = await pool.rw.getConnection();
      try {
        const rows = await conn.query(`SELECT COUNT(*) AS cnt FROM \`${t(TABLES.USERS)}\``);
        const count = Number(rows[0].cnt);
        if (count > 0 && (!req.user || req.user.role !== 'admin')) {
          const e = apiError('Admin required', 'FORBIDDEN', 403);
          return res.status(e.status).json(e.body);
        }
      } catch {
        // Table doesn't exist yet — first-run scenario, allow it
      }
    } catch (err) {
      logger.error({ err }, 'Failed to acquire pool connection for init-db precheck');
      const e = apiError('Database operation failed', 'INTERNAL_ERROR', 500);
      return res.status(e.status).json(e.body);
    } finally {
      if (conn) conn.release();
    }

    const tablesCreated = [];
    const errors = [];

    conn = null;
    try {
      if (useEngineOnly) {
        // Use dynamic pool to target a different database (engine tables only)
        const full = getDbConfigFull();
        if (!full) throw new Error('Server config not available');
        const dynPool = await getDynamicPool({ ...full, database: targetDatabase });
        conn = await dynPool.rw.getConnection();
        const prefix = requirePrefix(full.tablePrefix, 'schema-init:full.tablePrefix');
        const prefixFn = (name) => `${prefix}${name}`;

        await preflightDdlGrants(conn, targetDatabase, ENGINE_TABLE_NAMES, prefixFn, {
          user: full.user,
          tablePrefix: prefix,
        });
        const ddls = buildEngineTableDDLs(prefixFn);
        for (const ddl of ddls) {
          try {
            await conn.query(ddl);
            // Extract table name from DDL for reporting
            const match = ddl.match(/`([^`]+)`/);
            tablesCreated.push(match ? match[1] : '?');
          } catch (err) {
            if (!err.message.toLowerCase().includes('already exists')) {
              errors.push(err.message.substring(0, 120));
            } else {
              const match = ddl.match(/`([^`]+)`/);
              tablesCreated.push(match ? match[1] : '?');
            }
          }
        }
      } else {
        // Use infra pool, create all 11 tables (DDL → pool.rw).
        conn = await pool.rw.getConnection();

        const infraSchema = infraConfig?.database;
        if (infraSchema) {
          const allNames = INFRA_TABLE_NAMES.concat(ENGINE_TABLE_NAMES);
          await preflightDdlGrants(conn, infraSchema, allNames, t, {
            user: infraConfig?.user,
            tablePrefix: infraConfig?.tablePrefix,
          });
        } else {
          // Review MED fix: log when we skip pre-flight due to missing
          // infraConfig so the DDL-error fallback is not silent.
          logger.warn(
            'init-db: infraConfig.database not set — skipping pre-flight; DDL errors will surface verbatim',
          );
        }

        const ddls = buildAllTableDDLs(t);
        for (const ddl of ddls) {
          try {
            await conn.query(ddl);
            const match = ddl.match(/`([^`]+)`/);
            tablesCreated.push(match ? match[1] : '?');
          } catch (err) {
            if (!err.message.toLowerCase().includes('already exists')) {
              errors.push(err.message.substring(0, 120));
            } else {
              const match = ddl.match(/`([^`]+)`/);
              tablesCreated.push(match ? match[1] : '?');
            }
          }
        }
      }

      // Schema migration: rename depid→deptid columns + update access_rules
      // enum for existing deployments.
      if (!useEngineOnly && conn) {
        const columnMigrations = [
          { table: 'users', from: 'depid', to: 'deptid' },
          { table: 'login_audit', from: 'depid', to: 'deptid' },
        ];
        for (const { table, from, to } of columnMigrations) {
          try {
            // Check if old column exists
            const cols = await conn.query(`SHOW COLUMNS FROM \`${t(table)}\` LIKE '${from}'`);
            if (cols.length > 0) {
              await conn.query(`ALTER TABLE \`${t(table)}\` RENAME COLUMN \`${from}\` TO \`${to}\``);
              logger.info({ from, to, table: t(table) }, 'migrated column');
            }
          } catch (migErr) {
            logger.warn({ from, to, table, err: migErr }, 'column migration skipped');
          }
        }
        // Migrate keycloak_sub CHAR(36) → VARCHAR(128) for existing deployments
        try {
          const cols = await conn.query(`SHOW COLUMNS FROM \`${t(TABLES.USERS)}\` LIKE 'keycloak_sub'`);
          if (cols.length > 0 && cols[0].Type && cols[0].Type.includes('char(36)')) {
            await conn.query(`ALTER TABLE \`${t(TABLES.USERS)}\` MODIFY COLUMN keycloak_sub VARCHAR(128) NULL`);
            logger.info('migrated keycloak_sub CHAR(36)→VARCHAR(128)');
          }
        } catch (migErr) {
          logger.warn({ err: migErr }, 'keycloak_sub type migration skipped');
        }
        // Migrate access_rules rule_type enum: depid → deptid
        try {
          await conn.query(`UPDATE \`${t(TABLES.ACCESS_RULES)}\` SET rule_type = 'deptid' WHERE rule_type = 'depid'`);
        } catch (migErr) {
          logger.warn({ err: migErr }, 'access_rules enum migration skipped');
        }
      }

      // Data migration: migrate access_rules rule_value from keycloak_sub
      // (UUID) to email for older Keycloak-provisioned deployments.
      if (!useEngineOnly && conn) {
        try {
          const migrated = await conn.query(
            `UPDATE \`${t(TABLES.ACCESS_RULES)}\` ar
             INNER JOIN \`${t(TABLES.USERS)}\` u ON u.keycloak_sub = ar.rule_value
             SET ar.rule_value = u.email
             WHERE ar.rule_type = 'user'
               AND ar.rule_value REGEXP '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'`,
          );
          if (migrated.affectedRows > 0) {
            logger.info({ count: migrated.affectedRows }, 'migrated access rules from keycloak_sub to email');
          }
        } catch (migErr) {
          // Non-blocking: migration is best-effort for existing deployments
          logger.warn({ err: migErr }, 'access rule migration skipped');
        }
      }

      // Seed default system_settings (INSERT IGNORE — safe to run multiple times)
      if (!useEngineOnly && conn) {
        try {
          await conn.query(
            `INSERT IGNORE INTO \`${t(TABLES.SYSTEM_SETTINGS)}\` (id, \`key\`, value, description) VALUES
             (?, 'app_name', ?, 'Application display name'),
             (?, 'session_timeout_minutes', '30', 'Session timeout in minutes')`,
            [
              uuidv4(),
              JSON.stringify(process.env.APP_NAME || 'Flexible Mold Base'),
              uuidv4(),
            ],
          );
        } catch (seedErr) {
          logger.warn({ err: seedErr }, 'system_settings seed skipped');
        }
      }

      // After a clean all-tables create, stamp platform_schema_version so the
      // admin schema-status re-check reports aligned. The runner is idempotent:
      // on a freshly-built schema every migration is a no-op (all columns
      // present) → 0 skipped → it stamps target through its own clean-run gate,
      // which suppresses the stale boot-time table_missing audit rows that were
      // written before the tables existed. Best-effort: a stamp hiccup must not
      // fail the table-creation response the operator just succeeded at.
      // Engine-only targets are excluded — they have no system_settings table.
      // INVARIANT: only stamp when EVERY table DDL succeeded. A table that
      // failed to create but has no additive-column migration guard would let
      // the runner stamp target anyway (its guarded tables all exist) — masking
      // an incomplete schema and short-circuiting boot-time repair. On any DDL
      // error, leave the box unstamped so a re-run / next boot can finish it.
      if (!useEngineOnly && conn && errors.length === 0) {
        try {
          await runSchemaMigrations(conn, { context: 'init-db' });
        } catch (stampErr) {
          logger.warn({ err: stampErr }, 'init-db: post-create schema-version stamp skipped — will self-heal on next boot');
        }
      }

      res.json(apiOk({
        tables_created: tablesCreated,
        errors,
        target: useEngineOnly ? targetDatabase : (infraConfig?.database || 'infra'),
        table_type: useEngineOnly ? 'engine' : 'all',
      }));
    } catch (err) {
      if (err instanceof DdlPrivilegeError) {
        // Keep the full banner for the admin-triggered HTTP path: the
        // operator actively asked for schema work and needs the GRANT hint.
        // Read-only probe failures are diagnostics, not privilege changes,
        // so they stay out of feature_audit.
        //
        // stderr (ArgoCD log) is server-side; admin pastes the real-user
        // grantSqlHint verbatim. The HTTP response below keeps
        // safeGrantSqlHint (placeholder user) so the real account name
        // never crosses the client boundary.
        process.stderr.write(
          `ERROR: ${err.message}\n` +
            `CAUSE: admin triggered /api/setup/init-db (target=${targetDatabase || '(infra)'}, type=${useEngineOnly ? 'engine' : 'all'}) but service account lacks DDL\n` +
            `FIX:   ask the DBA to run (paste verbatim):\n${err.grantSqlHint || '  (no hint — grants probe failed; check user@host ACL)'}\n`,
        );
        const e = ddlPreflightErrorResponse(err);
        return res.status(e.status).json(e.body);
      }
      logger.error({ err, targetDatabase, tableType: useEngineOnly ? 'engine' : 'all' }, 'Failed to initialise database schema target=' + (targetDatabase || '(infra)'));
      const e = apiError('Database operation failed', 'INTERNAL_ERROR', 500);
      res.status(e.status).json(e.body);
    } finally {
      if (conn) conn.release();
    }
  });

  router.get('/schemas', async (req, res) => {
    if (!requireAdmin(req, res)) return;
    if (!isPoolReady()) {
      const e = apiError('Database not configured', 'DB_NOT_CONFIGURED', 503);
      return res.status(e.status).json(e.body);
    }
    let conn;
    try {
      conn = await pool.rw.getConnection();
      const rows = await conn.query('SHOW DATABASES');
      const schemas = rows.map((r) => r.Database).filter((d) => !SYSTEM_DBS.has(d));
      const current = getDbConfig()?.database;
      res.json(apiOk({ schemas, current }));
    } catch (err) {
      logger.error({ err }, 'Failed to list database schemas');
      const e = apiError('Database operation failed', 'INTERNAL_ERROR', 500);
      res.status(e.status).json(e.body);
    } finally {
      if (conn) conn.release();
    }
  });

  router.post('/create-schema', async (req, res) => {
    if (!req.user || req.user.role !== 'admin') {
      const e = apiError('Admin required', 'FORBIDDEN', 403);
      return res.status(e.status).json(e.body);
    }
    const { name } = req.body;
    if (!name || !/^[a-zA-Z0-9_]+$/.test(name)) {
      const e = apiError('Invalid database name. Use letters, numbers, and underscores only.', 'BAD_REQUEST', 400);
      return res.status(e.status).json(e.body);
    }

    let conn;
    try {
      conn = await pool.rw.getConnection();
      await conn.query(`CREATE DATABASE IF NOT EXISTS \`${name}\``);
      conn.release();
      conn = null;

      // Create engine tables in the new database via dynamic pool
      const full = getDbConfigFull();
      if (!full) throw new Error('Server config not available');
      const dynPool = await getDynamicPool({ ...full, database: name });
      conn = await dynPool.rw.getConnection();

      const prefix = requirePrefix(full.tablePrefix, 'schema-init:full.tablePrefix');
      const prefixFn = (n) => `${prefix}${n}`;
      const tablesCreated = [];
      for (const ddl of buildEngineTableDDLs(prefixFn)) {
        await conn.query(ddl);
        const match = ddl.match(/`([^`]+)`/);
        tablesCreated.push(match ? match[1] : '?');
      }

      res.json(apiOk({ created: name, tables: tablesCreated }));
    } catch (err) {
      logger.error({ err, database: name }, 'Failed to create database schema name=' + name);
      const e = apiError('Database operation failed', 'INTERNAL_ERROR', 500);
      res.status(e.status).json(e.body);
    } finally {
      if (conn) conn.release();
    }
  });
}

module.exports = register;
