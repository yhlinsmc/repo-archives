const { TABLES } = require('../../../../shared/constants');

/**
 * @openapi
 * /edge/platform/setup:
 *   post:
 *     summary: Create the initial admin user (first-run only, no auth required)
 *     tags: [Platform - Setup]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [email, password]
 *             properties:
 *               email:
 *                 type: string
 *                 format: email
 *               password:
 *                 type: string
 *                 minLength: 8
 *               display_name:
 *                 type: string
 *     responses:
 *       200:
 *         description: Admin user created
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *       409:
 *         description: Setup already completed
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *
 * /edge/platform/setup/status:
 *   get:
 *     summary: Return comprehensive setup state for smart step-skipping
 *     tags: [Platform - Setup]
 *     responses:
 *       200:
 *         description: Setup status flags and recommended wizard step
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *
 * /edge/platform/setup/db-status:
 *   get:
 *     summary: Return whether the database pool is configured and ready
 *     tags: [Platform - Setup]
 *     responses:
 *       200:
 *         description: DB pool configuration summary
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *
 * /edge/platform/setup/schemas:
 *   get:
 *     summary: List visible MariaDB databases (system DBs excluded)
 *     tags: [Platform - Setup]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Array of database names and current DB
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *       503:
 *         description: Database not configured
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *
 * /edge/platform/setup/test-db:
 *   post:
 *     summary: Test a database connection using provided credentials
 *     tags: [Platform - Setup]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [host, user]
 *             properties:
 *               host:
 *                 type: string
 *               port:
 *                 type: integer
 *                 default: 3306
 *               user:
 *                 type: string
 *               password:
 *                 type: string
 *               database:
 *                 type: string
 *     responses:
 *       200:
 *         description: Connection test result (success or failure message)
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *
 * /edge/platform/setup/configure-db:
 *   post:
 *     summary: Save DB credentials, test connection, and initialise the pool
 *     tags: [Platform - Setup]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [host, user, database]
 *             properties:
 *               host:
 *                 type: string
 *               port:
 *                 type: integer
 *                 default: 3306
 *               user:
 *                 type: string
 *               password:
 *                 type: string
 *               database:
 *                 type: string
 *               tablePrefix:
 *                 type: string
 *                 default: fmb_
 *     responses:
 *       200:
 *         description: Database configured successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *       403:
 *         description: Admin required to reconfigure an existing pool
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *
 * /edge/platform/setup/init-db:
 *   post:
 *     summary: Create all infrastructure tables (idempotent; runs migrations)
 *     tags: [Platform - Setup]
 *     requestBody:
 *       required: false
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               database:
 *                 type: string
 *                 description: Target database; omit to initialise infra DB with all tables
 *     responses:
 *       200:
 *         description: Tables created with optional error list
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *       403:
 *         description: Admin required after first-run
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *
 * /edge/platform/setup/create-schema:
 *   post:
 *     summary: Create a new MariaDB database and initialise its engine tables (admin only)
 *     tags: [Platform - Setup]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [name]
 *             properties:
 *               name:
 *                 type: string
 *                 pattern: '^[a-zA-Z0-9_]+$'
 *     responses:
 *       200:
 *         description: Schema and engine tables created
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *       403:
 *         description: Admin role required
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *
 * /edge/platform/setup/seed:
 *   post:
 *     summary: Import seed data SQL (INSERT/REPLACE only; transactional)
 *     tags: [Platform - Setup]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               sql:
 *                 type: string
 *                 description: Raw SQL content (max 10 MB)
 *               path:
 *                 type: string
 *                 description: Server-side file path to read
 *               useServerPath:
 *                 type: boolean
 *                 description: Read from SEED_SQL_PATH env var
 *     responses:
 *       200:
 *         description: Seed executed with statement and row counts
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *       403:
 *         description: Disallowed SQL statements or admin required
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *
 * /edge/platform/setup/reset-config:
 *   post:
 *     summary: Delete saved DB config and reset the pool (admin or pre-admin only)
 *     tags: [Platform - Setup]
 *     responses:
 *       200:
 *         description: Configuration reset
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *       403:
 *         description: Admin required when an admin account exists
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *
 * /edge/platform/setup/table-status:
 *   get:
 *     summary: Return row counts for all infrastructure tables (admin only)
 *     tags: [Platform - Setup]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Map of table name to row count (-1 means table missing)
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *       403:
 *         description: Admin role required
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *
 * /edge/platform/setup/truncate-table:
 *   post:
 *     summary: Clear all rows from an infrastructure table (admin only)
 *     tags: [Platform - Setup]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [table]
 *             properties:
 *               table:
 *                 type: string
 *                 description: Logical table name (e.g. users, login_audit)
 *     responses:
 *       200:
 *         description: Table truncated
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *       403:
 *         description: Admin role required
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *
 * /edge/platform/setup/drop-table:
 *   post:
 *     summary: Drop an infrastructure table (admin only)
 *     tags: [Platform - Setup]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [table]
 *             properties:
 *               table:
 *                 type: string
 *                 description: Logical table name (e.g. login_audit)
 *     responses:
 *       200:
 *         description: Table dropped
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *       403:
 *         description: Admin role required
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 */

/**
 * setup/index.js — Router assembly + GET /status handler.
 *
 * setup.js was split into feature-scoped sub-files:
 *
 *   create-admin.js  POST /
 *   db-connect.js    POST /test-db, POST /configure-db, GET /db-status
 *   schema-init.js   POST /init-db, GET /schemas, POST /create-schema
 *   seed-data.js     POST /seed
 *   reset.js         POST /reset-config
 *   tables.js        GET /table-status, POST /truncate-table, POST /drop-table
 *   _shared.js       SYSTEM_DBS constant, resolveSetupUser helper
 *
 * Each sub-file exports a `register(router)` function that attaches its
 * handlers to the shared router assembled below. The aggregated router
 * is what index-edge.js mounts at /edge/platform/setup so the public
 * URL surface is identical to the pre-split version — every path, body
 * contract, status code, and envelope shape is preserved.
 */
const router = require('express').Router();
const { pool, t, isPoolReady, getDbConfig } = require('../../../db');
const { apiOk } = require('../../../../shared/helpers');
const { logger: rootLogger } = require('../../../../shared/lib/logger');
const { checkAdminPresence } = require('../../../../shared/lib/admin-presence-check');
const { deriveWizardNextStep } = require('../../../../shared/lib/wizard-next-step');
const logger = rootLogger.child({ module: 'setup:status' });

// GET /api/setup/status is tiny, read-only, and is the one handler every
// wizard step hits to figure out where it should start. Co-locating it
// with the router assembly keeps the "main" setup file self-contained
// without creating a dedicated file for a single route.
router.get('/status', async (_req, res) => {
  const result = {
    setup_required: true,
    db_configured: false,
    db_source: 'none',
    db_reachable: false,
    schema_initialized: false,
    engine_schema_initialized: false,
    admin_exists: false,
    recommended_step: 0,
    wizard_next_step: 'configure-db',
    seed_sql_configured: !!process.env.SEED_SQL_PATH,
    db_host: null,
    db_port: null,
    db_user: null,
    db_database: null,
    db_tablePrefix: null,
  };

  if (!isPoolReady()) {
    // No DB configured — start at step 1 (DB Connect)
    result.recommended_step = 1;
    result.wizard_next_step = 'configure-db';
    return res.json(apiOk(result));
  }

  const config = getDbConfig();
  result.db_configured = true;
  result.db_source = config?.source || 'file';
  result.db_host = config?.host || null;
  result.db_port = config?.port || null;
  result.db_user = config?.user || null;
  result.db_database = config?.database || null;
  result.db_tablePrefix = config?.tablePrefix || null;

  let conn;
  try {
    // Setup status probe — pool.rw keeps this consistent with writes that
    // immediately follow (schema init, admin create) in the same wizard flow.
    conn = await pool.rw.getConnection();
    result.db_reachable = true;

    // Check if schema tables exist
    try {
      await conn.query(`SELECT 1 FROM \`${t(TABLES.USERS)}\` LIMIT 0`);
      result.schema_initialized = true;
    } catch {
      // Infra table doesn't exist — schema not initialized
    }

    // Engine schema probe (independent of infra schema). Wrapped in try/catch
    // because a permission-denied error on hierarchy_nodes should not crash
    // the status endpoint — it just reports false with a warn log.
    try {
      await conn.query(`SELECT 1 FROM \`${t(TABLES.HIERARCHY_NODES)}\` LIMIT 0`);
      result.engine_schema_initialized = true;
    } catch (err) {
      logger.warn({ err }, 'engine schema probe failed');
    }
  } catch (err) {
    logger.warn({ err }, 'setup status probe — DB pool unreachable');
  } finally {
    if (conn) conn.release();
  }

  // Distinct admin-role check via shared helper. Done outside the conn-block
  // above because checkAdminPresence acquires its own pool.ro connection;
  // running it inside the conn try/catch above would block the rw conn during
  // the lookup unnecessarily.
  if (result.schema_initialized) {
    const adminCheck = await checkAdminPresence(pool, t, TABLES.USERS);
    if (adminCheck.admin_exists) {
      result.admin_exists = true;
      result.setup_required = false;
    }
  }

  // Calculate recommended step (0=Env, 1=DB, 2=Schema, 3=Seed, 4=Admin)
  if (!result.db_reachable) {
    result.recommended_step = 1;
  } else if (!result.schema_initialized) {
    result.recommended_step = 2;
  } else if (!result.admin_exists) {
    result.recommended_step = 4;
  } else {
    result.recommended_step = -1; // All done
  }

  result.wizard_next_step = deriveWizardNextStep({
    db_reachable: result.db_reachable,
    schema_initialized: result.schema_initialized,
    admin_exists: result.admin_exists,
  });

  res.json(apiOk(result));
});

// Register all other sub-routes. Order is deterministic to keep behaviour
// identical to the pre-split file.
require('./create-admin')(router);
require('./db-connect')(router);
require('./schema-init')(router);
require('./seed-data')(router);
require('./reset')(router);
require('./tables')(router);
require('./re-probe-auth')(router);
require('./recovery-status')(router);
require('./promote-first-admin')(router);

module.exports = router;
