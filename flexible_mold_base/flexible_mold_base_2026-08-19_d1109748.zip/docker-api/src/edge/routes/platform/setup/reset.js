/**
 * POST /api/setup/reset-config — Deletes data/db-config.json and resets
 * the pool. If env vars are available, the pool automatically reconnects
 * from them; otherwise the server enters setup-required mode.
 *
 * Admin gate has three layers:
 *   1. Pool-not-ready bypass: if the pool never initialised the admin
 *      lookup would deadlock, so reset is allowed to recover.
 *   2. Zero-admin escape hatch: if the pool IS ready but no admin row
 *      exists yet, the UI can still call reset (first-run recovery).
 *   3. Authenticated admin: once an admin exists, only admin-role
 *      requests may reset.
 *
 * Note: TOCTOU window exists between the admin-count query and
 * resetConfig() — another request could create the first admin in
 * between. The window is narrow and limited to initial-setup; once an
 * admin exists the gate is authoritative.
 */
const { pool, t, isPoolReady, resetConfig } = require('../../../db');
const { apiOk, apiError } = require('../../../../shared/helpers');
const { logger: rootLogger } = require('../../../../shared/lib/logger');
const { TABLES } = require('../../../../shared/constants');
const { invalidateDbStatusCache } = require('./db-connect');

const logger = rootLogger.child({ module: 'setup:reset' });

module.exports = function register(router) {
  router.post('/reset-config', async (req, res) => {
    if (isPoolReady()) {
      if (req.user?.role === 'admin') {
        // Authenticated admin — skip further checks, proceed to reset.
      } else {
        let adminExists = false;
        let queryFailed = false;
        try {
          // NOTE: Admin-existence guard for a write-destructive reset —
          // pool.rw to stay consistent with other setup flows and avoid a
          // replica-lag window where a just-created admin isn't visible.
          const conn = await pool.rw.getConnection();
          try {
            const rows = await conn.query(
              `SELECT COUNT(*) AS cnt FROM \`${t(TABLES.USERS)}\` WHERE role = 'admin'`,
            );
            adminExists = Number(rows[0].cnt) > 0;
          } finally {
            conn.release();
          }
        } catch (err) {
          // ER_NO_SUCH_TABLE / ER_BAD_DB_ERROR → infrastructure is broken,
          // allow reset. Other errors (pool exhausted, network) → fail safe
          // and deny.
          const code = err?.code || '';
          if (code === 'ER_NO_SUCH_TABLE' || code === 'ER_BAD_DB_ERROR') {
            adminExists = false;
          } else {
            queryFailed = true;
          }
        }

        if (queryFailed) {
          const e = apiError('Unable to verify admin status. Try again later.', 'DB_ERROR', 503);
          return res.status(e.status).json(e.body);
        }

        if (adminExists) {
          const e = apiError('Admin required to reset configuration', 'FORBIDDEN', 403);
          return res.status(e.status).json(e.body);
        }
      }
    }

    try {
      await resetConfig();
      // INVARIANT: any DB-state mutation invalidates the db-status cache.
      // Without this the next poll may report `configured: true` for up to
      // the cache TTL even though resetConfig() just tore the pool down.
      invalidateDbStatusCache();
      res.json(apiOk({ message: 'Configuration reset.' }));
    } catch (err) {
      logger.error({ err }, 'Failed to reset DB config (setup wizard reset handler)');
      const e = apiError('Database operation failed', 'INTERNAL_ERROR', 500);
      res.status(e.status).json(e.body);
    }
  });
};
