/**
 * service-accounts.js — Public Integration API admin register/rotate/deactivate
 * (Auth v2.1).
 *
 * The admin UI generates the app-issued API key client-side and sends it once;
 * this route hashes it immediately, and only the hash + a 6-char display
 * prefix are persisted. There is no server-side one-time-secret reveal — the
 * plaintext never round-trips back out of this API.
 *
 * SECURITY: no handler in this router ever returns `token_hash` or the
 * plaintext token — GET / and every mutation response carry `token_prefix`
 * only.
 */
const { TABLES } = require('../../../shared/constants');
const { isNonEmptyScope } = require('../../../shared/lib/machine-scope');
const { hashToken } = require('../../lib/machine-token-hash');

const router = require('express').Router();
const { pool, t } = require('../../db');
const { apiOk, apiError, requireAdmin, uuidv4 } = require('../../../shared/helpers');
const { logger: rootLogger } = require('../../../shared/lib/logger');
const logger = rootLogger.child({ module: 'service-accounts' });

const MAX_LABEL_LEN = 255;
const MIN_TOKEN_LEN = 8;
const MAX_TOKEN_LEN = 4096;
const TOKEN_PREFIX_LEN = 6;

/**
 * @param {unknown} raw driver-returned JSON column (object or JSON string)
 * @returns {{ roots?: string[], operations?: string[] }}
 */
function parseScope(raw) {
  return typeof raw === 'string' ? JSON.parse(raw) : (raw || {});
}

/**
 * Resolve a granted root id to its full ancestor path string (root-most first,
 * joined with " / "). Walks the parent_id chain in memory over an already-fetched
 * node map — no per-account query.
 *
 * @param {string} rootId granted hierarchy_node id
 * @param {Record<string, { id: string, name: string, parent_id: string|null }>} nodeById
 * @returns {string} e.g. "Offshore-7MW / Rev-A / Complete Site Deployment"
 */
function buildRootPath(rootId, nodeById) {
  const node = nodeById[rootId];
  // Dangling/unknown root id → same fallback as scope_root_names: echo the id
  // string rather than throw, so a stale grant never breaks the whole list.
  if (!node) return rootId;
  const parts = [];
  // INVARIANT: bad data could contain a parent cycle; the visited set bounds
  // the walk so a cycle can never spin the request handler.
  const seen = new Set();
  let cur = node;
  while (cur && !seen.has(cur.id)) {
    seen.add(cur.id);
    parts.push(cur.name);
    cur = cur.parent_id != null ? nodeById[cur.parent_id] : null;
  }
  return parts.reverse().join(' / ');
}

/**
 * @param {unknown} raw request body field
 * @returns {string} trimmed string, or '' if not a string
 */
function trimString(raw) {
  return typeof raw === 'string' ? raw.trim() : '';
}

/**
 * @param {string} trimmedToken already-trimmed candidate
 * @returns {boolean}
 */
function isValidTokenLength(trimmedToken) {
  return trimmedToken.length >= MIN_TOKEN_LEN && trimmedToken.length <= MAX_TOKEN_LEN;
}

/**
 * @openapi
 * /edge/platform/service-accounts:
 *   get:
 *     summary: List service accounts (never returns token_hash or the plaintext token)
 *     tags: [Platform - Service Accounts]
 *     responses:
 *       200: { description: Service account list }
 *       403: { description: Admin required }
 *   post:
 *     summary: Register a service account for an app-issued API key
 *     tags: [Platform - Service Accounts]
 *     responses:
 *       200: { description: Registered — returns token_prefix only, never the token }
 *       400: { description: Validation error }
 *       403: { description: Admin required }
 *       409: { description: Token already registered to another account }
 */
router.get('/', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  try {
    const conn = await pool.ro.getConnection();
    let rows;
    try {
      rows = await conn.query(
        `SELECT id, token_prefix, label, scope, is_active, created_at, last_used_at
         FROM \`${t(TABLES.SERVICE_ACCOUNTS)}\` ORDER BY created_at DESC`
      );
    } finally {
      conn.release();
    }

    const parsed = rows.map((r) => ({ ...r, scope: parseScope(r.scope) }));

    // One follow-up query loads the bounded node directory so both the display
    // names and the full ancestor paths can be resolved by an in-memory parent
    // walk — no per-account query. hierarchy_nodes is the same bounded picker
    // directory GET /hierarchy-roots already scans in full.
    const rootIds = Array.from(new Set(
      parsed.flatMap((r) => (Array.isArray(r.scope.roots) ? r.scope.roots : []))
    ));
    let nodeById = {};
    if (rootIds.length) {
      const conn2 = await pool.ro.getConnection();
      try {
        const nodeRows = await conn2.query(
          `SELECT id, name, parent_id FROM \`${t(TABLES.HIERARCHY_NODES)}\``
        );
        nodeById = Object.fromEntries(nodeRows.map((n) => [n.id, n]));
      } finally {
        conn2.release();
      }
    }

    const result = parsed.map((r) => {
      const roots = Array.isArray(r.scope.roots) ? r.scope.roots : [];
      return {
        ...r,
        // Both arrays stay 1:1 with scope.roots order; a missing root id falls
        // back to the id string in both (see buildRootPath / name fallback).
        scope_root_names: roots.map((id) => (nodeById[id] ? nodeById[id].name : id)),
        scope_root_paths: roots.map((id) => buildRootPath(id, nodeById)),
      };
    });
    res.json(apiOk(result));
  } catch (err) {
    logger.error({ err }, 'Failed to list service accounts');
    const e = apiError('Database operation failed', 'INTERNAL_ERROR');
    res.status(e.status).json(e.body);
  }
});

// GET /hierarchy-roots — bounded directory feeding the create-dialog
// hierarchy-root multi-select. Admin-only, same as the rest of this router.
router.get('/hierarchy-roots', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  try {
    const conn = await pool.ro.getConnection();
    try {
      const rows = await conn.query(
        `SELECT id, name, node_type, parent_id FROM \`${t(TABLES.HIERARCHY_NODES)}\` ORDER BY name`
      );
      res.json(apiOk(rows));
    } finally {
      conn.release();
    }
  } catch (err) {
    logger.error({ err }, 'Failed to list hierarchy roots for service-account picker');
    const e = apiError('Database operation failed', 'INTERNAL_ERROR');
    res.status(e.status).json(e.body);
  }
});

router.post('/', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  const { label, scope, token } = req.body || {};

  const trimmedLabel = trimString(label);
  if (!trimmedLabel || trimmedLabel.length > MAX_LABEL_LEN) {
    const e = apiError('label is required (max 255 chars)', 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }

  const trimmedToken = trimString(token);
  if (!trimmedToken || !isValidTokenLength(trimmedToken)) {
    const e = apiError(
      `token is required (${MIN_TOKEN_LEN}-${MAX_TOKEN_LEN} chars)`,
      'BAD_REQUEST',
      400
    );
    return res.status(e.status).json(e.body);
  }

  // Dedupe: duplicate ids would false-fail the existence check below
  // (existing.length !== roots.length) since the IN-lookup returns distinct rows.
  const roots = Array.isArray(scope?.roots)
    ? [...new Set(scope.roots.filter((v) => typeof v === 'string' && v.length > 0))]
    : [];
  // v1 operations are fixed to read-only regardless of what the client sends
  // — the create dialog shows this as a static note, not an editable field.
  const normalizedScope = { roots, operations: ['read'] };
  // An account whose scope has no roots can never pass the token-gate's
  // isNonEmptyScope check (docker-api/src/shared/lib/machine-scope.js), so
  // registering one is always a mistake — reject it at registration time.
  if (!isNonEmptyScope(normalizedScope)) {
    const e = apiError('At least one hierarchy root is required', 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }

  try {
    const conn = await pool.rw.getConnection();
    try {
      const placeholders = roots.map(() => '?').join(',');
      const existing = await conn.query(
        `SELECT id FROM \`${t(TABLES.HIERARCHY_NODES)}\` WHERE id IN (${placeholders})`,
        roots
      );
      if (existing.length !== roots.length) {
        const e = apiError('One or more hierarchy roots do not exist', 'BAD_REQUEST', 400);
        return res.status(e.status).json(e.body);
      }

      const id = uuidv4();
      // The token is hashed immediately and never persisted in plaintext;
      // token_prefix is display-only correlation, not a usable credential.
      const tokenHash = hashToken(trimmedToken);
      const tokenPrefix = trimmedToken.slice(0, TOKEN_PREFIX_LEN);

      await conn.query(
        `INSERT INTO \`${t(TABLES.SERVICE_ACCOUNTS)}\` (id, token_hash, token_prefix, scope, label, is_active, owner_id)
         VALUES (?, ?, ?, ?, ?, 1, ?)`,
        [id, tokenHash, tokenPrefix, JSON.stringify(normalizedScope), trimmedLabel, req.user.id]
      );

      // The response never echoes the token or its hash — only the prefix
      // (already visible to the admin from generating the key client-side)
      // round-trips.
      res.json(apiOk({
        id,
        token_prefix: tokenPrefix,
        label: trimmedLabel,
        scope: normalizedScope,
        is_active: true,
      }));
    } finally {
      conn.release();
    }
  } catch (err) {
    if (err && err.code === 'ER_DUP_ENTRY') {
      // SECURITY: message is identical regardless of which account already
      // holds this token — never disclose ownership of the existing row.
      const e = apiError('Token already registered', 'token_already_registered', 409);
      return res.status(e.status).json(e.body);
    }
    logger.error({ err }, 'Failed to register service account');
    const e = apiError('Database operation failed', 'INTERNAL_ERROR');
    res.status(e.status).json(e.body);
  }
});

/**
 * @openapi
 * /edge/platform/service-accounts/{id}/rotate:
 *   post:
 *     summary: Rotate a service account's token (re-hash + replace token_prefix)
 *     tags: [Platform - Service Accounts]
 *     parameters: [{ name: id, in: path, required: true, schema: { type: string } }]
 *     responses:
 *       200: { description: Rotated — returns the new token_prefix only }
 *       400: { description: Validation error }
 *       403: { description: Admin required }
 *       404: { description: Service account not found }
 *       409: { description: Token already registered to another account }
 */
router.post('/:id/rotate', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  const { token } = req.body || {};

  const trimmedToken = trimString(token);
  if (!trimmedToken || !isValidTokenLength(trimmedToken)) {
    const e = apiError(
      `token is required (${MIN_TOKEN_LEN}-${MAX_TOKEN_LEN} chars)`,
      'BAD_REQUEST',
      400
    );
    return res.status(e.status).json(e.body);
  }

  try {
    const conn = await pool.rw.getConnection();
    try {
      const existing = await conn.query(
        `SELECT id FROM \`${t(TABLES.SERVICE_ACCOUNTS)}\` WHERE id = ?`,
        [req.params.id]
      );
      if (!existing.length) {
        const e = apiError('Service account not found', 'NOT_FOUND', 404);
        return res.status(e.status).json(e.body);
      }

      const tokenHash = hashToken(trimmedToken);
      const tokenPrefix = trimmedToken.slice(0, TOKEN_PREFIX_LEN);
      await conn.query(
        `UPDATE \`${t(TABLES.SERVICE_ACCOUNTS)}\` SET token_hash = ?, token_prefix = ? WHERE id = ?`,
        [tokenHash, tokenPrefix, req.params.id]
      );

      res.json(apiOk({ id: req.params.id, token_prefix: tokenPrefix }));
    } finally {
      conn.release();
    }
  } catch (err) {
    if (err && err.code === 'ER_DUP_ENTRY') {
      const e = apiError('Token already registered', 'token_already_registered', 409);
      return res.status(e.status).json(e.body);
    }
    logger.error({ err, serviceAccountId: req.params.id }, 'Failed to rotate service account token');
    const e = apiError('Database operation failed', 'INTERNAL_ERROR');
    res.status(e.status).json(e.body);
  }
});

/**
 * @openapi
 * /edge/platform/service-accounts/{id}/deactivate:
 *   post:
 *     summary: Deactivate a service account (is_active=0); blocks resolves immediately
 *     tags: [Platform - Service Accounts]
 *     parameters: [{ name: id, in: path, required: true, schema: { type: string } }]
 *     responses:
 *       200: { description: Deactivated }
 *       403: { description: Admin required }
 *       404: { description: Service account not found }
 */
router.post('/:id/deactivate', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  try {
    const conn = await pool.rw.getConnection();
    try {
      // Existence is decided by the row, not by UPDATE affectedRows: MariaDB
      // counts CHANGED rows, so deactivating an already-inactive account would
      // report 0 and be misreported as 404. Fetch first → deactivate is
      // idempotent (unknown id → 404; existing account → 200 no-op even if
      // already inactive).
      const existing = await conn.query(
        `SELECT id FROM \`${t(TABLES.SERVICE_ACCOUNTS)}\` WHERE id = ?`,
        [req.params.id]
      );
      if (!existing.length) {
        const e = apiError('Service account not found', 'NOT_FOUND', 404);
        return res.status(e.status).json(e.body);
      }
      await conn.query(
        `UPDATE \`${t(TABLES.SERVICE_ACCOUNTS)}\` SET is_active = 0 WHERE id = ?`,
        [req.params.id]
      );
      res.json(apiOk(null));
    } finally {
      conn.release();
    }
  } catch (err) {
    logger.error({ err, serviceAccountId: req.params.id }, 'Failed to deactivate service account');
    const e = apiError('Database operation failed', 'INTERNAL_ERROR');
    res.status(e.status).json(e.body);
  }
});

/**
 * @openapi
 * /edge/platform/service-accounts/{id}:
 *   patch:
 *     summary: Edit a service account's label and/or scope (never returns token_hash)
 *     tags: [Platform - Service Accounts]
 *     parameters: [{ name: id, in: path, required: true, schema: { type: string } }]
 *     responses:
 *       200: { description: Updated — returns the row summary (token_prefix only) }
 *       400: { description: Validation error (empty body, bad label, empty/unknown scope) }
 *       403: { description: Admin required }
 *       404: { description: Service account not found }
 *   delete:
 *     summary: Hard-delete a service account (gated on is_active=0)
 *     tags: [Platform - Service Accounts]
 *     parameters: [{ name: id, in: path, required: true, schema: { type: string } }]
 *     responses:
 *       200: { description: Deleted }
 *       403: { description: Admin required }
 *       404: { description: Service account not found (unknown or already gone) }
 *       409: { description: Account is still active — deactivate it first }
 */
router.patch('/:id', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  const body = req.body || {};
  const hasLabel = Object.prototype.hasOwnProperty.call(body, 'label');
  const hasScope = Object.prototype.hasOwnProperty.call(body, 'scope');

  if (!hasLabel && !hasScope) {
    const e = apiError('Nothing to update: provide a label and/or scope', 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }

  let trimmedLabel;
  if (hasLabel) {
    trimmedLabel = trimString(body.label);
    if (!trimmedLabel || trimmedLabel.length > MAX_LABEL_LEN) {
      const e = apiError('label is required (max 255 chars)', 'BAD_REQUEST', 400);
      return res.status(e.status).json(e.body);
    }
  }

  let normalizedScope;
  let roots;
  if (hasScope) {
    // Dedupe (same reason as register): duplicate ids would false-fail the
    // existence check (found.length !== roots.length).
    roots = Array.isArray(body.scope?.roots)
      ? [...new Set(body.scope.roots.filter((v) => typeof v === 'string' && v.length > 0))]
      : [];
    // v1 operations are fixed to read-only, matching register.
    normalizedScope = { roots, operations: ['read'] };
    if (!isNonEmptyScope(normalizedScope)) {
      const e = apiError('At least one hierarchy root is required', 'BAD_REQUEST', 400);
      return res.status(e.status).json(e.body);
    }
  }

  try {
    const conn = await pool.rw.getConnection();
    try {
      // Fetch-first 404: edit is allowed on active AND inactive rows, so the
      // gate is existence only. The current row also supplies the fields the
      // response echoes back for whichever side of the update was omitted.
      const existingRows = await conn.query(
        `SELECT id, token_prefix, label, scope, is_active FROM \`${t(TABLES.SERVICE_ACCOUNTS)}\` WHERE id = ?`,
        [req.params.id]
      );
      if (!existingRows.length) {
        const e = apiError('Service account not found', 'NOT_FOUND', 404);
        return res.status(e.status).json(e.body);
      }
      const existing = existingRows[0];

      if (hasScope) {
        const placeholders = roots.map(() => '?').join(',');
        const found = await conn.query(
          `SELECT id FROM \`${t(TABLES.HIERARCHY_NODES)}\` WHERE id IN (${placeholders})`,
          roots
        );
        if (found.length !== roots.length) {
          const e = apiError('One or more hierarchy roots do not exist', 'BAD_REQUEST', 400);
          return res.status(e.status).json(e.body);
        }
      }

      // SECURITY: the SET fragments are fixed string literals chosen from a
      // closed set (label / scope); only the *values* are parameterized, so
      // this dynamic clause carries no injection surface.
      const sets = [];
      const params = [];
      if (hasLabel) { sets.push('label = ?'); params.push(trimmedLabel); }
      if (hasScope) { sets.push('scope = ?'); params.push(JSON.stringify(normalizedScope)); }
      params.push(req.params.id);
      // No cache to invalidate: the machine-token resolve path
      // (edge/routes/internal/machine-token.js) SELECTs `scope` from this row
      // on every request, so the next resolve sees the new grant immediately.
      await conn.query(
        `UPDATE \`${t(TABLES.SERVICE_ACCOUNTS)}\` SET ${sets.join(', ')} WHERE id = ?`,
        params
      );

      // Response never carries token_hash — only the display prefix + updated
      // summary fields (mirrors register / rotate).
      res.json(apiOk({
        id: existing.id,
        token_prefix: existing.token_prefix,
        label: hasLabel ? trimmedLabel : existing.label,
        scope: hasScope ? normalizedScope : parseScope(existing.scope),
        is_active: existing.is_active === 1 || existing.is_active === true,
      }));
    } finally {
      conn.release();
    }
  } catch (err) {
    logger.error({ err, serviceAccountId: req.params.id }, 'Failed to update service account');
    const e = apiError('Database operation failed', 'INTERNAL_ERROR');
    res.status(e.status).json(e.body);
  }
});

router.delete('/:id', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  try {
    const conn = await pool.rw.getConnection();
    try {
      // Fetch-first: DELETE affectedRows cannot distinguish "unknown id" from
      // "already gone", and is_active is needed to enforce the two-step gate.
      const rows = await conn.query(
        `SELECT id, is_active FROM \`${t(TABLES.SERVICE_ACCOUNTS)}\` WHERE id = ?`,
        [req.params.id]
      );
      if (!rows.length) {
        const e = apiError('Service account not found', 'NOT_FOUND', 404);
        return res.status(e.status).json(e.body);
      }
      const isActive = rows[0].is_active === 1 || rows[0].is_active === true;
      if (isActive) {
        // AWS two-step idiom: an active account must be deactivated first so an
        // in-use credential is never hard-deleted by accident.
        const e = apiError('Deactivate the account before deleting it', 'account_active', 409);
        return res.status(e.status).json(e.body);
      }
      // Delete the account and its idempotency reservations atomically. There is
      // no FK to cascade (this schema uses zero FKs), and once the account row is
      // gone its token can never authenticate again, so the opportunistic sweep
      // in public-write can never reclaim those rows — they would orphan forever.
      // The UNIQUE(service_account_id, idempotency_key) index serves the child
      // DELETE's WHERE via its leftmost prefix.
      await conn.beginTransaction();
      try {
        await conn.query(
          `DELETE FROM \`${t(TABLES.SERVICE_ACCOUNT_IDEMPOTENCY)}\` WHERE service_account_id = ?`,
          [req.params.id]
        );
        await conn.query(
          `DELETE FROM \`${t(TABLES.SERVICE_ACCOUNTS)}\` WHERE id = ?`,
          [req.params.id]
        );
        await conn.commit();
      } catch (txErr) {
        await conn.rollback().catch((rbErr) => logger.warn({ err: rbErr }, 'SA delete rollback failed'));
        throw txErr;
      }
      res.json(apiOk(null));
    } finally {
      conn.release();
    }
  } catch (err) {
    logger.error({ err, serviceAccountId: req.params.id }, 'Failed to delete service account');
    const e = apiError('Database operation failed', 'INTERNAL_ERROR');
    res.status(e.status).json(e.body);
  }
});

module.exports = router;
