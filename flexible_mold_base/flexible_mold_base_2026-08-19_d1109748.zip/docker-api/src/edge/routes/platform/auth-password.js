const { TABLES } = require('../../../shared/constants');

/**
 * auth-password.js — Password-based auth routes (edge-side, DB-facing).
 *
 * Handles: login, change-password, is-admin, mode switch, diagnostics/details.
 * These routes all require DB access, so they live on the edge service.
 * Session/identity routes (GET /me, GET /mode, GET /diagnostics) stay on infra.
 *
 * Mounted by index-edge.js at /edge/platform/auth-password.
 * Accessed from infra via S2S forwarding proxy.
 */

const router = require('express').Router();
const { SignJWT } = require('jose');
const bcrypt = require('bcryptjs');
const { pool, t, isPoolReady } = require('../../db');
const { apiOk, apiError, requireAuth, requireAdmin } = require('../../../shared/helpers');
const { JWT_SECRET, resolveAuthMode, resolveAuthModeAsync, getAuthModeSource, setResolvedAuthMode, probeKeycloakDiscovery } = require('../../../shared/config');
const { validatePassword } = require('../../../shared/password-validator');
const { isDegraded, clearDegradation } = require('../../../lib/keycloak-health');
const { logger: rootLogger } = require('../../../shared/lib/logger');
const logger = rootLogger.child({ module: 'auth-password' });

/**
 * Write a login audit record (fire-and-forget, non-critical).
 */
function _writeLoginAudit(conn, { username, success, reason, ip, userAgent }) {
  conn.query(
    `INSERT INTO \`${t(TABLES.LOGIN_AUDIT)}\` (username, auth_provider, reason, ip_address, user_agent, success)
     VALUES (?, 'LOCAL', ?, ?, ?, ?)`,
    [username, reason, ip || null, userAgent || null, success ? 1 : 0]
  ).catch(err => logger.warn({ err }, 'audit write failed (non-critical)'));
}

/**
 * @openapi
 * /edge/platform/auth-password/login:
 *   post:
 *     summary: Login with email + password (local mode only)
 *     tags: [Platform - Auth]
 */
router.post('/login', async (req, res) => {
  // Block local login when auth_mode is keycloak
  let currentMode;
  if (isPoolReady()) {
    currentMode = await resolveAuthModeAsync(pool, t);
  } else {
    currentMode = resolveAuthMode();
  }
  if (currentMode === 'keycloak') {
    const e = apiError('Local login is disabled. Use SSO login.', 'AUTH_MODE_KEYCLOAK', 403);
    return res.status(e.status).json(e.body);
  }

  const { email, password } = req.body;
  try {
    // SELECT + conditional _writeLoginAudit INSERT all on the same conn → pool.rw.
    const conn = await pool.rw.getConnection();
    try {
      const rows = await conn.query(`SELECT * FROM \`${t(TABLES.USERS)}\` WHERE email = ?`, [email]);
      if (!rows.length) {
        _writeLoginAudit(conn, { username: email, success: false, reason: 'user_not_found', ip: req.ip, userAgent: req.headers['user-agent'] });
        const e = apiError('Invalid credentials', 'AUTH_ERROR', 401);
        return res.status(e.status).json(e.body);
      }
      const user = rows[0];
      // NOTE: this route reads `user.banned` directly from the raw SELECT
      // result instead of routing the row through dto-mapper's
      // `mapRowFromDb('users', user)`. Intentional: the login hot-path
      // only needs one boolean field and a truthy check, which is
      // identical for raw TINYINT (0/1) and DTO-mapped booleans
      // (false/true). Bypassing the mapper avoids an extra function
      // call on every login. Consistent with auth.js middleware, which
      // also reads raw rows from the OIDC jit-provisioner and the JWT
      // path. Do NOT use the raw-read shortcut for any field that
      // needs decoded JSON, ISO timestamps, or nullable-number
      // semantics — route those through mapRowFromDb first.
      if (user.banned) {
        _writeLoginAudit(conn, { username: email, success: false, reason: 'account_banned', ip: req.ip, userAgent: req.headers['user-agent'] });
        const e = apiError('Account banned', 'AUTH_ERROR', 403);
        return res.status(e.status).json(e.body);
      }
      if (!user.password_hash) {
        _writeLoginAudit(conn, { username: email, success: false, reason: 'sso_only_account', ip: req.ip, userAgent: req.headers['user-agent'] });
        const e = apiError('This account uses SSO login only', 'AUTH_ERROR', 403);
        return res.status(e.status).json(e.body);
      }
      const valid = await bcrypt.compare(password, user.password_hash);
      if (!valid) {
        _writeLoginAudit(conn, { username: email, success: false, reason: 'invalid_password', ip: req.ip, userAgent: req.headers['user-agent'] });
        const e = apiError('Invalid credentials', 'AUTH_ERROR', 401);
        return res.status(e.status).json(e.body);
      }
      // Claim shape stays byte-compatible with the previous jsonwebtoken
      // output: { sub, email, iat, exp }, HS256 header. setExpirationTime('24h')
      // matches the old expiresIn: '24h' (exp = iat + 86400).
      const token = await new SignJWT({ sub: user.id, email: user.email })
        .setProtectedHeader({ alg: 'HS256' })
        .setIssuedAt()
        .setExpirationTime('24h')
        .sign(new TextEncoder().encode(JWT_SECRET));
      _writeLoginAudit(conn, { username: email, success: true, reason: null, ip: req.ip, userAgent: req.headers['user-agent'] });
      res.json(apiOk({ token, user: { id: user.id, email: user.email, role: user.role } }));
    } finally {
      conn.release();
    }
  } catch (err) {
    // Email in structured binding only — see users.js:197 note. pino
    // redact.paths does not currently cover 'email'.
    logger.error({ err, email }, 'Failed to process local login');
    const e = apiError('Database operation failed', 'INTERNAL_ERROR');
    res.status(e.status).json(e.body);
  }
});

/**
 * @openapi
 * /edge/platform/auth-password/{id}/is-admin:
 *   get:
 *     summary: Check if a user is admin
 *     tags: [Platform - Auth]
 */
router.get('/:id/is-admin', async (req, res) => {
  if (!requireAuth(req, res)) return;
  try {
    // NOTE: Authorization-gating read must come from the writer. A replica-lag
    // window could otherwise let a freshly-demoted admin keep is_admin=true on
    // direct API calls that bypass SPA caches.
    const conn = await pool.rw.getConnection();
    try {
      const rows = await conn.query(`SELECT role FROM \`${t(TABLES.USERS)}\` WHERE id = ?`, [req.params.id]);
      const isAdmin = rows.length > 0 && rows[0].role === 'admin';
      res.json(apiOk({ is_admin: isAdmin }));
    } finally {
      conn.release();
    }
  } catch (err) {
    logger.error({ err, userId: req.params.id }, 'Failed to check admin status userId=' + req.params.id);
    const e = apiError('Database operation failed', 'INTERNAL_ERROR');
    res.status(e.status).json(e.body);
  }
});

/**
 * @openapi
 * /edge/platform/auth-password/change-password:
 *   put:
 *     summary: Change own password
 *     tags: [Platform - Auth]
 */
router.put('/change-password', async (req, res) => {
  if (!requireAuth(req, res)) return;
  const { old_password, new_password } = req.body;
  if (!old_password || !new_password) {
    const e = apiError('old_password and new_password are required', 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }
  const pwError = validatePassword(new_password);
  if (pwError) {
    const e = apiError(pwError, 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }
  try {
    // SELECT + UPDATE password_hash + audit INSERT on same conn → pool.rw.
    const conn = await pool.rw.getConnection();
    try {
      const rows = await conn.query(
        `SELECT id, email, password_hash, keycloak_sub FROM \`${t(TABLES.USERS)}\` WHERE id = ?`,
        [req.user.id]
      );
      if (!rows.length) {
        const e = apiError('User not found', 'NOT_FOUND', 404);
        return res.status(e.status).json(e.body);
      }
      const user = rows[0];
      if (user.keycloak_sub && !user.password_hash) {
        const e = apiError('Password change is not available for Keycloak-only accounts. Change your password in Keycloak.', 'AUTH_ERROR', 403);
        return res.status(e.status).json(e.body);
      }
      if (!user.password_hash) {
        const e = apiError('No password set for this account', 'AUTH_ERROR', 403);
        return res.status(e.status).json(e.body);
      }
      const valid = await bcrypt.compare(old_password, user.password_hash);
      if (!valid) {
        const e = apiError('Current password is incorrect', 'AUTH_ERROR', 401);
        return res.status(e.status).json(e.body);
      }
      const hash = await bcrypt.hash(new_password, 10);
      await conn.query(
        `UPDATE \`${t(TABLES.USERS)}\` SET password_hash = ? WHERE id = ?`,
        [hash, req.user.id]
      );
      conn.query(
        `INSERT INTO \`${t(TABLES.LOGIN_AUDIT)}\` (username, auth_provider, reason, success)
         VALUES (?, 'LOCAL', 'password_change', TRUE)`,
        [user.email]
      ).catch(err => logger.warn({ err }, 'audit write failed (non-critical)'));
      res.json(apiOk({ message: 'Password changed successfully' }));
    } finally {
      conn.release();
    }
  } catch (err) {
    logger.error({ err, userId: req.user?.id }, 'Failed to change password userId=' + req.user?.id);
    const e = apiError('Database error', 'DB_ERROR');
    res.status(e.status).json(e.body);
  }
});

/**
 * @openapi
 * /edge/platform/auth-password/mode:
 *   put:
 *     summary: Switch auth mode (admin only)
 *     tags: [Platform - Auth]
 */
router.put('/mode', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  const { mode } = req.body;
  if (!mode || !['local', 'keycloak'].includes(mode)) {
    const e = apiError('mode must be "local" or "keycloak"', 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }

  try {
    if (mode === 'keycloak') {
      const reachable = await probeKeycloakDiscovery();
      if (!reachable) {
        const e = apiError('Keycloak is not reachable. Verify KEYCLOAK_ISSUER_BASE_URL and connectivity.', 'KEYCLOAK_UNREACHABLE', 503);
        return res.status(e.status).json(e.body);
      }
    }

    if (mode === 'local') {
      // NOTE: Guard read for an about-to-write operation must read from the
      // writer, not a replica. A replication-lag window between the preflight
      // and the system_settings INSERT would otherwise let a concurrent
      // /change-password write race the guard.
      const conn = await pool.rw.getConnection();
      try {
        const rows = await conn.query(
          `SELECT password_hash FROM \`${t(TABLES.USERS)}\` WHERE id = ?`,
          [req.user.id]
        );
        if (rows.length && !rows[0].password_hash) {
          const e = apiError('You must set a local password before switching to local mode. Use the password management feature first.', 'NO_LOCAL_PASSWORD', 400);
          return res.status(e.status).json(e.body);
        }
      } finally {
        conn.release();
      }
    }

    const conn = await pool.rw.getConnection();
    try {
      await conn.query(
        `INSERT INTO \`${t(TABLES.SYSTEM_SETTINGS)}\` (\`key\`, value, updated_by)
         VALUES ('auth_mode', ?, ?)
         ON DUPLICATE KEY UPDATE value = ?, updated_by = ?`,
        [JSON.stringify(mode), req.user.email, JSON.stringify(mode), req.user.email]
      );
    } finally {
      conn.release();
    }

    await setResolvedAuthMode(mode, 'admin_api');
    if (mode === 'keycloak') {
      clearDegradation();
    }

    pool.rw.getConnection().then(auditConn => {
      auditConn.query(
        `INSERT INTO \`${t(TABLES.LOGIN_AUDIT)}\` (username, auth_provider, reason, success)
         VALUES (?, 'LOCAL', ?, TRUE)`,
        [req.user.email, `auth_mode_switch_to_${mode}`]
      ).catch(err => logger.warn({ err }, 'audit write failed (non-critical)')).finally(() => auditConn.release());
    }).catch(err => logger.warn({ err }, 'audit connection failed (non-critical)'));

    res.json(apiOk({
      mode,
      source: getAuthModeSource(),
      message: `Auth mode switched to ${mode}`,
    }));
  } catch (err) {
    logger.error({ err, mode }, 'Failed to switch auth mode to=' + mode);
    const e = apiError('Database operation failed', 'INTERNAL_ERROR');
    res.status(e.status).json(e.body);
  }
});

/**
 * @openapi
 * /edge/platform/auth-password/diagnostics/details:
 *   get:
 *     summary: Full diagnostics (admin only)
 *     tags: [Platform - Auth]
 */
router.get('/diagnostics/details', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  try {
    const authMode = isPoolReady()
      ? await resolveAuthModeAsync(pool, t)
      : resolveAuthMode();

    const issuerUrl = process.env.KEYCLOAK_ISSUER_BASE_URL || null;
    const callbackUrl = process.env.BASE_URL
      ? `${process.env.BASE_URL}/api/auth/callback`
      : `http://localhost:${process.env.PORT || 3200}/api/auth/callback`;
    const caCertPath = process.env.KEYCLOAK_CA_CERT_PATH || null;

    const result = {
      auth_mode: authMode,
      issuer_url_configured: !!issuerUrl,
      issuer_url: issuerUrl,
      callback_url: callbackUrl,
      keycloak_reachable: false,
      keycloak_discovery: null,
      ca_cert_configured: !!caCertPath,
      ca_cert_path: caCertPath,
      ca_cert_valid: null,
      recent_failures: [],
    };

    if (issuerUrl) {
      try {
        const discoveryUrl = `${issuerUrl}/.well-known/openid-configuration`;
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 5000);
        const resp = await fetch(discoveryUrl, { signal: controller.signal });
        clearTimeout(timeout);
        result.keycloak_reachable = resp.ok;
        if (resp.ok) {
          const body = await resp.json();
          result.keycloak_discovery = {
            authorization_endpoint: body.authorization_endpoint || null,
            token_endpoint: body.token_endpoint || null,
            userinfo_endpoint: body.userinfo_endpoint || null,
            end_session_endpoint: body.end_session_endpoint || null,
          };
        } else {
          result.keycloak_discovery = { error: `HTTP ${resp.status}` };
        }
      } catch (err) {
        result.keycloak_reachable = false;
        result.keycloak_discovery = { error: err.message };
      }
    }

    if (caCertPath) {
      try {
        const fs = require('fs');
        fs.accessSync(caCertPath, fs.constants.R_OK);
        const content = fs.readFileSync(caCertPath, 'utf-8');
        result.ca_cert_valid = content.includes('-----BEGIN CERTIFICATE-----');
      } catch {
        result.ca_cert_valid = false;
      }
    }

    if (isPoolReady()) {
      try {
        // Pure diagnostic SELECT → pool.ro.
        const conn = await pool.ro.getConnection();
        try {
          const rows = await conn.query(
            `SELECT username, auth_provider, reason, ip_address, login_at
             FROM \`${t(TABLES.LOGIN_AUDIT)}\`
             WHERE success = FALSE
             ORDER BY login_at DESC
             LIMIT 5`
          );
          result.recent_failures = rows.map(r => ({
            username: r.username,
            auth_provider: r.auth_provider,
            reason: r.reason || null,
            ip_address: r.ip_address || null,
            login_at: r.login_at,
          }));
        } finally {
          conn.release();
        }
      } catch (err) {
        logger.warn({ err }, 'auth diagnostics — recent_failures query failed; returning empty list');
        result.recent_failures = [];
      }
    }

    res.json(apiOk(result));
  } catch (err) {
    logger.error({ err }, 'Failed to fetch auth diagnostics details');
    const e = apiError('Database operation failed', 'INTERNAL_ERROR');
    res.status(e.status).json(e.body);
  }
});

module.exports = router;
