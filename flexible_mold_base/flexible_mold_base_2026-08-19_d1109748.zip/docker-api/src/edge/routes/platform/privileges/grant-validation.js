const { INFRA_TABLE_NAMES, ENGINE_TABLE_NAMES } = require('../../../../table-ddls');

const PRIVILEGE_ALLOWLIST = Object.freeze([
  'SELECT',
  'INSERT',
  'UPDATE',
  'DELETE',
  'REFERENCES',
]);
const PRIVILEGE_ALLOWLIST_SET = new Set(PRIVILEGE_ALLOWLIST);

const FORBIDDEN_TOKENS = Object.freeze([
  'CREATE', 'DROP', 'ALTER', 'TRUNCATE', 'RENAME',
  'GRANT OPTION', 'SUPER', 'FILE', 'PROCESS', 'SHUTDOWN', 'RELOAD',
  'CREATE USER', 'DROP USER', 'CREATE ROLE', 'DROP ROLE',
]);

const MYSQL_USER_RE = /^[a-zA-Z_][a-zA-Z0-9_]{0,31}$/;

const ALLOWED_TABLE_BASE_NAMES = new Set([
  ...INFRA_TABLE_NAMES,
  ...ENGINE_TABLE_NAMES,
]);

const ISO8601_RE = /^\d{4}-\d{2}-\d{2}(?:[T ][0-9]{2}:[0-9]{2}(?::[0-9]{2}(?:\.\d+)?)?(?:Z|[+-][0-9]{2}:?[0-9]{2})?)?$/;

function evaluateSelfGuard(mysqlUser, currentUser, op) {
  const target = typeof mysqlUser === 'string' ? mysqlUser.toLowerCase() : mysqlUser;
  const cu = typeof currentUser === 'string' ? currentUser.toLowerCase() : currentUser;
  if (target && cu && target === cu) {
    return { self: true, reason: 'current_user' };
  }
  // The env-account self-guard protects against REVOKE locking the app out of
  // its own service account. GRANT to the service account is the legitimate
  // bootstrap path (additive, allowlist-limited to SELECT/INSERT/UPDATE/DELETE/
  // REFERENCES; GRANT OPTION / DROP / SUPER are already forbidden) and must be
  // allowed — otherwise an under-privileged service account can never be
  // provisioned from inside the product. Default to REVOKE semantics when op is
  // omitted so an un-updated caller stays on the safe (blocking) side.
  const isRevoke = String(op || 'REVOKE').toUpperCase() === 'REVOKE';
  if (isRevoke) {
    const envRwRaw = process.env.DB_RW_USER;
    const envRw = envRwRaw ? envRwRaw.toLowerCase() : null;
    if (envRw && target === envRw) {
      return { self: true, reason: 'env_rw' };
    }
    const envRoRaw = process.env.DB_RO_USER;
    const envRo = envRoRaw ? envRoRaw.toLowerCase() : null;
    if (envRo && target === envRo) {
      return { self: true, reason: 'env_ro' };
    }
  }
  return { self: false, reason: null };
}

function validateIsoDate(value) {
  if (value == null || value === '') return null;
  if (typeof value !== 'string') return 'date must be a string';
  if (!ISO8601_RE.test(value)) {
    return 'date must be ISO-8601 (YYYY-MM-DD or YYYY-MM-DDTHH:MM[:SS][Z|±HH:MM])';
  }
  const parsed = new Date(value);
  if (Number.isNaN(parsed.getTime())) {
    return 'date must be a real calendar date';
  }
  const head = value.slice(0, 10);
  if (/^\d{4}-\d{2}-\d{2}$/.test(head)) {
    const y = parsed.getUTCFullYear();
    const m = parsed.getUTCMonth() + 1;
    const d = parsed.getUTCDate();
    const iso = `${String(y).padStart(4, '0')}-${String(m).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
    if (iso !== head) {
      return 'date must be a real calendar date';
    }
  }
  return null;
}

function validateMysqlUser(name) {
  if (typeof name !== 'string' || !MYSQL_USER_RE.test(name)) {
    return 'mysqlUser must match /^[a-zA-Z_][a-zA-Z0-9_]{0,31}$/';
  }
  return null;
}

function validatePrivileges(list) {
  if (!Array.isArray(list) || list.length === 0) {
    return 'privileges must be a non-empty array';
  }
  for (const p of list) {
    if (typeof p !== 'string') return 'privileges[] must all be strings';
    if (!PRIVILEGE_ALLOWLIST_SET.has(p)) {
      return 'privilege not permitted';
    }
  }
  return null;
}

function validateTables(list) {
  if (!Array.isArray(list) || list.length === 0) {
    return 'tables must be a non-empty array';
  }
  for (const base of list) {
    if (typeof base !== 'string') return 'tables[] must all be strings';
    if (!ALLOWED_TABLE_BASE_NAMES.has(base)) {
      return `table '${base}' is not in infra/engine allowlist`;
    }
  }
  return null;
}

function containsForbiddenToken(sql) {
  const upper = sql.toUpperCase();
  for (const tok of FORBIDDEN_TOKENS) {
    if (tok.includes(' ')) {
      if (upper.includes(tok)) return tok;
    } else {
      const re = new RegExp(`\\b${tok}\\b`, 'i');
      if (re.test(upper)) return tok;
    }
  }
  return null;
}

module.exports = {
  evaluateSelfGuard,
  validateIsoDate,
  validateMysqlUser,
  validatePrivileges,
  validateTables,
  containsForbiddenToken,
  MYSQL_USER_RE,
  ISO8601_RE,
  PRIVILEGE_ALLOWLIST,
  ALLOWED_TABLE_BASE_NAMES,
  FORBIDDEN_TOKENS,
};
