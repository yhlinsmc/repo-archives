const AUDIT_EVENT_TYPES = Object.freeze({
  grantPending:   'db_privilege.grant.pending',
  grantSuccess:   'db_privilege.grant.success',
  grantFail:      'db_privilege.grant.fail',
  revokePending:  'db_privilege.revoke.pending',
  revokeSuccess:  'db_privilege.revoke.success',
  revokeFail:     'db_privilege.revoke.fail',
});

function _normaliseAuditRow(row) {
  return {
    id: row.id,
    event_type: row.event_type,
    user_id: row.user_id,
    metadata: _safeParseJson(row.metadata),
    created_at: row.created_at,
  };
}

function _safeParseJson(value) {
  if (value == null) return null;
  if (typeof value === 'object') return value;
  try { return JSON.parse(value); } catch { return null; }
}

// SECURITY: leading characters `=`, `+`, `-`, `@`, `\t`, `\r` are
// interpreted as formula prefixes by Excel / LibreOffice / Google
// Sheets when a CSV is imported (OWASP CSV-injection guidance lists
// all six). Even when the value is wrapped in quotes the spreadsheet
// strips the quotes and evaluates the formula, allowing CSV-injection
// attacks (`=cmd|'/c calc'!A0`, `=HYPERLINK(...)`, etc.). Prefix-escape
// with a single quote so the cell renders as text.
//
// Bypass-defense: spreadsheet apps silently strip leading whitespace
// from unquoted cells before formula evaluation, so we check the
// trimmed value to detect ` =cmd...` style smuggling. The emitted
// value retains the original whitespace so legitimate non-formula
// content is preserved verbatim.
//
// Order: prefix-escape BEFORE RFC-4180 quoting because the leading
// single-quote can change whether the value contains punctuation that
// triggers RFC quoting.
function _csvField(value) {
  if (value == null) return '';
  let s = String(value);
  // Strip leading SPACES only (not \t / \r — those are themselves
  // formula triggers and must remain visible to the prefix check).
  const trimmed = s.replace(/^ +/, '');
  if (trimmed.length > 0 && /^[=+\-@\t\r]/.test(trimmed)) {
    s = "'" + s;
  }
  if (/[",\n\r\t]/.test(s)) {
    return '"' + s.replace(/"/g, '""') + '"';
  }
  return s;
}

function _summariseAudit(meta) {
  if (!meta) return '';
  if (Array.isArray(meta.results)) {
    const ok = meta.results.filter((r) => r.ok).length;
    const total = meta.results.length;
    return `${ok}/${total} succeeded`;
  }
  if (Array.isArray(meta.tables)) {
    return `tables=${meta.tables.length} privileges=${(meta.privileges || []).length}`;
  }
  return '';
}

module.exports = {
  AUDIT_EVENT_TYPES,
  _normaliseAuditRow,
  _safeParseJson,
  _csvField,
  _summariseAudit,
};
