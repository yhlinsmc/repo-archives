const {
  validatePrivileges,
  validateTables,
  containsForbiddenToken,
} = require('./grant-validation');

async function performBatch(conn, op, { mysqlUser, grantSpecs }, tableNameForBase) {
  const results = [];
  const userEscaped = mysqlUser.replace(/'/g, "''");

  for (const spec of grantSpecs) {
    const fqTable = tableNameForBase(spec.table);
    const privCsv = spec.privileges.join(', ');
    const sql = op === 'GRANT'
      ? `GRANT ${privCsv} ON \`${fqTable}\` TO '${userEscaped}'@'%'`
      : `REVOKE ${privCsv} ON \`${fqTable}\` FROM '${userEscaped}'@'%'`;
    const forbidden = containsForbiddenToken(sql);
    if (forbidden) {
      results.push({ table: fqTable, privileges: spec.privileges, ok: false, error: `Forbidden token in emitted SQL: ${forbidden}` });
      continue;
    }
    try {
      await conn.query(sql);
      results.push({ table: fqTable, privileges: spec.privileges, ok: true });
    } catch (err) {
      results.push({ table: fqTable, privileges: spec.privileges, ok: false, error: err.message, sqlCode: err.code || null });
    }
  }
  try { await conn.query('FLUSH PRIVILEGES'); } catch { /* ignore */ }
  return results;
}

function normaliseGrantSpecs(body) {
  if (Array.isArray(body?.grants)) {
    if (body.grants.length === 0) {
      return { error: 'grants must be a non-empty array' };
    }
    const specs = [];
    for (const entry of body.grants) {
      if (!entry || typeof entry !== 'object') {
        return { error: 'each grants[] entry must be an object' };
      }
      const tErr = validateTables([entry.table]);
      if (tErr) return { error: tErr };
      const pErr = validatePrivileges(entry.privileges);
      if (pErr) return { error: pErr };
      specs.push({
        table: entry.table,
        privileges: [...new Set(entry.privileges)],
      });
    }
    return { specs };
  }
  const tErr = validateTables(body.tables);
  if (tErr) return { error: tErr };
  const pErr = validatePrivileges(body.privileges);
  if (pErr) return { error: pErr };
  const uniquePrivs = [...new Set(body.privileges)];
  const specs = body.tables.map((table) => ({ table, privileges: uniquePrivs }));
  return { specs };
}

module.exports = {
  performBatch,
  normaliseGrantSpecs,
};
