const router = require('./privileges/router');

module.exports = router;
module.exports._internal = router._internal;
