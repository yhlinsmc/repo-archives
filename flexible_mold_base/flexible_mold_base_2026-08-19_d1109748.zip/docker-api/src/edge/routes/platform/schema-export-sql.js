/**
 * schema-export-sql.js — DBA remediation SQL export (admin only).
 *
 * fmb-1329 spec §4.3/§4.8: when schema-status reports missing tables/columns
 * (operator-mode, or a manually-stamped DB that drifted), an admin can download
 * executable SQL that closes the gap: CREATE TABLE straight from the DDL
 * builders for missing tables, ALTER TABLE ... ADD COLUMN from the manifest DDL
 * fragment for missing columns. Applying it and rebooting converges — the
 * executor's probes then find everything present and the stamp advances.
 *
 * Emits statements only — no `USE`, no hardcoded table prefix (names via t() at
 * render time), plus a header comment naming stamp / target / baseline so the
 * DBA knows exactly what schema state the script targets.
 *
 * Route:
 *   GET /edge/platform/schema-export-sql   — admin only, text/plain
 */
const router = require('express').Router();
const { pool, t, PLATFORM_SCHEMA_VERSION } = require('../../db');
const { TABLES } = require('../../../shared/constants');
const { requireAdmin, uuidv4 } = require('../../../shared/helpers');
const { buildAllTableDDLs } = require('../../../table-ddls');
const { ddlFragmentFor } = require('../../lib/schema-manifest');
const { readSchemaColumns, computeMissing } = require('../../lib/schema-comparison');
const { compareVersions } = require('../../lib/schema-version-derive');
const { derivePendingStepsSql } = require('../../lib/pending-steps');
const { BASELINE_SCHEMA_VERSION, MIGRATION_STEPS } = require('../../migration-steps');
const { logger: rootLogger } = require('../../../shared/lib/logger');
const logger = rootLogger.child({ module: 'schema-export-sql' });

// Auth middleware (CLAUDE.md §6: every new route file mounts auth). requireAdmin
// writes the 403 itself, so a rejected request never reaches the handler.
router.use((req, res, next) => {
  if (!requireAdmin(req, res)) return;
  next();
});

/**
 * Read the current platform_schema_version stamp (display only). Tolerant of a
 * MariaDB JSON column the driver decoded to a bare string. Returns null when
 * absent/unreadable — the export still renders (header shows "none").
 */
async function _readStamp(conn) {
  try {
    const rows = await conn.query(
      `SELECT value FROM \`${t(TABLES.SYSTEM_SETTINGS)}\` WHERE \`key\` = 'platform_schema_version' LIMIT 1`,
    );
    if (!rows.length || !rows[0].value) return null;
    let parsed;
    try {
      parsed = typeof rows[0].value === 'string' ? JSON.parse(rows[0].value) : rows[0].value;
    } catch {
      parsed = rows[0].value;
    }
    return typeof parsed === 'string' ? parsed : null;
  } catch {
    return null;
  }
}

/**
 * Render the remediation SQL text (pure — no DB). Statements only: no `USE`, no
 * hardcoded prefix (physical names come from `tableFn` at render time), plus a
 * header comment naming stamp / target / baseline.
 *
 * `pending_sql` is the registry-derived remediation for pending destructive /
 * custom steps (drop-column DROP INDEX/COLUMN, custom backfill UPDATE + MODIFY),
 * precomputed READ-ONLY by the handler so this renderer stays pure. Those steps
 * are invisible to the missing-structure comparison (a drop leaves an EXTRA
 * column; a NULL→NOT NULL change alters nullability, not existence).
 *
 * @param {{stamp: string|null, missing_tables: string[], missing_columns: Array<{table:string,column:string}>, pending_sql?: string[], tableFn: (base:string)=>string}} input
 * @returns {string}
 */
function _buildExportSql({ stamp, missing_tables, missing_columns, pending_sql = [], tableFn }) {
  const lines = [
    '-- Schema remediation SQL — apply as a DDL-privileged account, then restart edge.',
    `-- current stamp: ${stamp || 'none'}`,
    `-- target:        ${PLATFORM_SCHEMA_VERSION}`,
    `-- baseline:      ${BASELINE_SCHEMA_VERSION}`,
    `-- generated:     ${new Date().toISOString()}`,
    '',
  ];

  const hasMissing = missing_tables.length > 0 || missing_columns.length > 0;
  const hasPending = pending_sql.length > 0;
  if (!hasMissing && !hasPending) {
    lines.push('-- No missing tables or columns and no pending migration steps — live schema matches the expected manifest.');
    return lines.join('\n');
  }

  if (missing_tables.length) {
    const allDdls = buildAllTableDDLs(tableFn);
    lines.push('-- Missing tables:');
    for (const base of missing_tables) {
      const physical = tableFn(base);
      const ddl = allDdls.find((s) => s.includes(`CREATE TABLE IF NOT EXISTS \`${physical}\``));
      if (!ddl) {
        lines.push(`-- (no CREATE TABLE found in builders for ${base} — investigate)`);
        continue;
      }
      lines.push(`${ddl.trim()};`);
      lines.push('');
    }
  }

  if (missing_columns.length) {
    lines.push('-- Missing columns:');
    for (const { table, column } of missing_columns) {
      const fragment = ddlFragmentFor(table, column);
      if (!fragment) {
        lines.push(`-- (no DDL fragment found for ${table}.${column} — investigate)`);
        continue;
      }
      lines.push(`ALTER TABLE \`${tableFn(table)}\` ADD COLUMN ${fragment};`);
    }
    lines.push('');
  }

  if (hasPending) {
    lines.push('-- Pending migration steps (destructive / custom — apply as a DDL-privileged account, then restart edge):');
    for (const stmt of pending_sql) lines.push(stmt);
    lines.push('');
  }

  return lines.join('\n');
}

/**
 * Best-effort audit-log write for a successful SQL export. Mirrors
 * schema-status.js's `?source=ui` interactive-read audit pattern: separate
 * writer connection (the route's main read uses `pool.ro`), never blocks or
 * fails the response on an audit-write error. Metadata carries counts only —
 * no table/column names, no rendered SQL text — the exported schema shape
 * itself is not a secret, but the audit row exists to record *who* exported
 * *when*, not to duplicate the export content.
 *
 * @param {{userId: string|null, missingTablesCount: number, missingColumnsCount: number}} input
 */
async function _writeExportAudit({ userId, missingTablesCount, missingColumnsCount }) {
  let auditConn;
  try {
    auditConn = await pool.rw.getConnection();
    await auditConn.query(
      `INSERT INTO \`${t(TABLES.FEATURE_AUDIT)}\` (id, event_type, user_id, metadata)
       VALUES (?, 'schema_export.sql', ?, ?)`,
      [
        uuidv4(),
        userId,
        JSON.stringify({ missing_tables_count: missingTablesCount, missing_columns_count: missingColumnsCount }),
      ],
    );
  } catch (err) {
    logger.warn({ err: err && err.message }, 'schema_export.sql audit row dropped');
  } finally {
    if (auditConn) {
      try { auditConn.release(); } catch { /* released */ }
    }
  }
}

/**
 * @openapi
 * /edge/platform/schema-export-sql:
 *   get:
 *     summary: Export DBA remediation SQL for missing schema structure (admin only)
 *     tags: [Platform - Schema Status]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200: { description: text/plain SQL script (empty statement body when aligned) }
 *       403: { description: Admin required }
 *       500: { description: Export failed }
 */
router.get('/', async (req, res) => {
  let conn;
  try {
    conn = await pool.ro.getConnection();
    const stamp = await _readStamp(conn);
    const liveByTable = await readSchemaColumns(conn);
    const { missing_tables, missing_columns } = computeMissing(liveByTable, t);
    // Pending destructive/custom steps are only meaningful while the stamp is
    // behind target (no stamp = not-yet-stamped, also behind). Derived READ-ONLY
    // from the registry (SELECT-only probes) so a CRUD-only operator can run it.
    let pending_sql = [];
    if (!stamp || compareVersions(stamp, PLATFORM_SCHEMA_VERSION) < 0) {
      pending_sql = await derivePendingStepsSql(conn, t, MIGRATION_STEPS);
    }
    await _writeExportAudit({
      userId: req.user?.id || null,
      missingTablesCount: missing_tables.length,
      missingColumnsCount: missing_columns.length,
    });
    res.type('text/plain').send(_buildExportSql({ stamp, missing_tables, missing_columns, pending_sql, tableFn: t }));
  } catch (err) {
    logger.error({ err }, 'schema-export-sql failed');
    res.status(500).type('text/plain').send('-- schema export failed; see server logs\n');
  } finally {
    if (conn) {
      try { conn.release(); } catch { /* released */ }
    }
  }
});

module.exports = router;
module.exports._internal = { _buildExportSql, _readStamp, _writeExportAudit };
