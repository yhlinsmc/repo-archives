/**
 * CRUD handlers for DB-backed transformers.
 *
 *   GET    /                    list all transformers (metadata only)
 *   GET    /active              list active transformers with code (runtime registry)
 *   GET    /:id                 single transformer with full detail
 *   POST   /                    create + initial version snapshot
 *   PUT    /:id                 update with auto-versioning + optimistic lock
 *   DELETE /:id                 soft-delete (default) or hard-delete (?hard=true)
 *   PUT    /:id/toggle-active   flip is_active flag
 *
 * Registration order in register(router) is identical to the pre-split
 * transformers.js: `/active` is declared before `/:id` so the literal
 * route wins the Express match. Any reordering risks shadowing /active
 * behind the :id param.
 */
const { pool, t } = require('../../../db');
const { apiOk, apiError, requireAuth, requireAdmin, requireAdminOrEditor, uuidv4 } = require('../../../../shared/helpers');
const { MAX_CODE_SIZE } = require('./_shared');
const { logger: rootLogger } = require('../../../../shared/lib/logger');
const { TABLES } = require('../../../../shared/constants');
const { applyOwnerChange } = require('../../../services/ownership');
const { resolveCanonicalUserId, ownerTargetRejection } = require('../schema/write-value');
const {
  attachOwnerNames, stripEmailColumns, AUTHOR_EMAIL_COLUMNS,
} = require('../../../lib/owner-name-enrichment');

// SECURITY: `created_by` / `updated_by` STORE `req.user.email`, and this mount
// returned them raw in the same response object as `owner_name`, which is
// deliberately reduced to its local part under this repository's
// never-return-email contract. One rule, applied at every surface that emits
// the columns — see stripEmailColumns for why the reduction is on read.
const withoutAuthorEmails = (rows) => stripEmailColumns(rows, AUTHOR_EMAIL_COLUMNS);

const logger = rootLogger.child({ module: 'transformers:crud' });

// NOTE: event_type is fixed at 'transformer.owner.transfer' for backward compat
// with audit consumers keyed on this string. Action discriminator
// (claim/transfer/release/make_shared) is in the metadata payload.
const TRANSFORMER_OWNER_AUDIT_EVENT = 'transformer.owner.transfer';

const DEFAULT_RETENTION_N = 50;
const RETENTION_KEY = 'transformer_retention_n_default';

/**
 * Read the configured per-transformer version retention. Defaults to 50
 * when the system_settings row is missing or unparseable. Bounded to a sane
 * range so a typo can't disable the prune (<5 would be too aggressive) or
 * balloon storage (>500 defeats the purpose). Reads from pool.ro because the
 * value is admin-managed and tolerates a few seconds of staleness.
 */
async function readRetentionN() {
  try {
    const conn = await pool.ro.getConnection();
    try {
      const rows = await conn.query(
        `SELECT value FROM \`${t(TABLES.SYSTEM_SETTINGS)}\` WHERE \`key\` = ? LIMIT 1`,
        [RETENTION_KEY],
      );
      if (!rows.length) return DEFAULT_RETENTION_N;
      const raw = rows[0].value;
      const parsed = typeof raw === 'string' ? JSON.parse(raw) : raw;
      const n = Number(parsed);
      if (!Number.isFinite(n)) return DEFAULT_RETENTION_N;
      return Math.max(5, Math.min(500, Math.floor(n)));
    } finally {
      conn.release();
    }
  } catch (err) {
    logger.warn({ err }, 'readRetentionN failed; using default');
    return DEFAULT_RETENTION_N;
  }
}

/**
 * Fire-and-forget prune of old `transformer_versions` rows for a single
 * transformer, executed AFTER the PUT transaction commits.
 *
 * Contract:
 *   - Acquires its own pool.rw connection (does not reuse caller's)
 *   - Deletes oldest rows beyond `retentionN`, but NEVER deletes the
 *     row matching `currentVersion` (the live version pointer)
 *   - Wraps the count + DELETE in a transaction so a concurrent rollback
 *     mid-prune doesn't leave orphan audit rows
 *   - Writes one audit row 'transformer.version.auto_prune' with
 *     metadata { retention_n, count_pruned, current_version }
 *   - Errors are caught by the caller's `.catch`; PUT response already
 *     went out, so the user never sees a prune failure
 */
async function pruneOldVersionsFireAndForget({ transformerId, currentVersion, userId }) {
  const retentionN = await readRetentionN();
  const conn = await pool.rw.getConnection();
  try {
    await conn.beginTransaction();
    const countRows = await conn.query(
      `SELECT COUNT(*) AS n FROM \`${t(TABLES.TRANSFORMER_VERSIONS)}\` WHERE transformer_id = ?`,
      [transformerId],
    );
    const total = Number(countRows[0]?.n ?? 0);
    if (total <= retentionN) {
      await conn.commit();
      return { pruned: 0, retention_n: retentionN, total };
    }
    const limit = total - retentionN;
    const result = await conn.query(
      `DELETE FROM \`${t(TABLES.TRANSFORMER_VERSIONS)}\`
        WHERE transformer_id = ?
          AND version <> ?
        ORDER BY version ASC
        LIMIT ?`,
      [transformerId, currentVersion, limit],
    );
    const pruned = Number(result?.affectedRows ?? 0);
    if (pruned > 0) {
      await conn.query(
        `INSERT INTO \`${t(TABLES.FEATURE_AUDIT)}\` (id, event_type, user_id, metadata)
         VALUES (?, 'transformer.version.auto_prune', ?, ?)`,
        [
          uuidv4(),
          userId || null,
          JSON.stringify({
            transformer_id: transformerId,
            retention_n: retentionN,
            count_pruned: pruned,
            current_version: currentVersion,
            total_before: total,
          }),
        ],
      );
    }
    await conn.commit();
    return { pruned, retention_n: retentionN, total };
  } catch (err) {
    try { await conn.rollback(); } catch (rbErr) {
      logger.warn({ err: rbErr }, 'auto-prune rollback failed');
    }
    throw err;
  } finally {
    conn.release();
  }
}

function register(router, opts = {}) {
  // Tests pass a stubbed prune fn so the post-commit hook is deterministic;
  // production omits opts and gets the real fire-and-forget runner.
  const pruneFn = opts.pruneOldVersionsFireAndForget || pruneOldVersionsFireAndForget;
  // GET / — list all transformers (no code body for list view)
  router.get('/', async (req, res) => {
    if (!requireAdminOrEditor(req, res)) return;
    let conn;
    try {
      conn = await pool.ro.getConnection();
      const rows = await conn.query(
        `SELECT id, name, description, is_active, version, code_size, input_schema, output_keys,
                owner_id, created_by, updated_by, created_at, updated_at
         FROM \`${t(TABLES.TRANSFORMERS)}\`
         ORDER BY name`,
      );
      // SECURITY: resolve owner_id → owner_name server-side; same bounded
      // contract as user_templates / hierarchy_nodes. Name only, never email.
      await attachOwnerNames(conn, rows, 'owner_id', `\`${t(TABLES.USERS)}\``);
      res.json(apiOk(withoutAuthorEmails(rows)));
    } catch (err) {
      logger.error({ err }, 'Failed to list transformers');
      const e = apiError('Database operation failed', 'INTERNAL_ERROR', 500);
      res.status(e.status).json(e.body);
    } finally {
      if (conn) conn.release();
    }
  });

  // GET /active — active transformers with code (for frontend runtime registry).
  // Uses requireAuth (not requireAdmin) so non-admin users can load DB
  // transformers on the Data Entry page. CRUD endpoints still require admin.
  // MUST be registered before GET /:id or Express will shadow it.
  router.get('/active', async (req, res) => {
    if (!requireAuth(req, res)) return;
    let conn;
    try {
      conn = await pool.ro.getConnection();
      const rows = await conn.query(
        `SELECT id, name, description, code, input_schema, output_keys, version
         FROM \`${t(TABLES.TRANSFORMERS)}\`
         WHERE is_active = TRUE
         ORDER BY name`,
      );
      res.json(apiOk(rows));
    } catch (err) {
      logger.error({ err }, 'Failed to list active transformers');
      const e = apiError('Database operation failed', 'INTERNAL_ERROR', 500);
      res.status(e.status).json(e.body);
    } finally {
      if (conn) conn.release();
    }
  });

  // GET /:id — single transformer with full details
  router.get('/:id', async (req, res) => {
    if (!requireAdminOrEditor(req, res)) return;
    let conn;
    try {
      conn = await pool.ro.getConnection();
      const rows = await conn.query(
        `SELECT * FROM \`${t(TABLES.TRANSFORMERS)}\` WHERE id = ?`,
        [req.params.id],
      );
      if (!rows.length) {
        const e = apiError('Transformer not found', 'NOT_FOUND', 404);
        return res.status(e.status).json(e.body);
      }
      await attachOwnerNames(conn, rows, 'owner_id', `\`${t(TABLES.USERS)}\``);
      res.json(apiOk(withoutAuthorEmails(rows)[0]));
    } catch (err) {
      logger.error({ err, transformerId: req.params.id }, 'Failed to fetch transformer id=' + req.params.id);
      const e = apiError('Database operation failed', 'INTERNAL_ERROR', 500);
      res.status(e.status).json(e.body);
    } finally {
      if (conn) conn.release();
    }
  });

  // ── ONE SET OF RULES FOR A COLUMN, ON BOTH VERBS ────────────────────────────
  //
  // The create path required a string `name` of at most 255 characters, a
  // `description` of at most 10000, and a non-empty `code`; the update path had
  // NONE of them. So `PUT {"name": 12345}` stored '12345', a 300-character name
  // was ERROR 1406 under the deployed strict sql_mode and reached the client as
  // a 500 with a driver stack where POST answers a clean 400, and `''` replaced
  // a name or a whole transformer body — because the guard beside it tested
  // TRUTHINESS while the back-fill tested NULLISH, and `''` is falsy but not
  // nullish. Two notions of "absent", three lines apart.
  //
  // PRESENT-ONLY, which is what lets one function serve both verbs: a partial
  // PUT that omits a column has said nothing about it and is not judged. The
  // create path adds its own required-ness on top.
  const MAX_NAME = 255;
  const MAX_DESCRIPTION = 10000;
  function columnRuleViolation(body) {
    if (Object.prototype.hasOwnProperty.call(body, 'name')) {
      const { name } = body;
      if (typeof name !== 'string' || name.trim().length === 0) {
        return { message: 'name must be a non-empty string', code: 'BAD_REQUEST' };
      }
      if (name.length > MAX_NAME) {
        return { message: `name exceeds ${MAX_NAME} characters`, code: 'BAD_REQUEST' };
      }
    }
    if (Object.prototype.hasOwnProperty.call(body, 'description')) {
      const { description } = body;
      if (description != null && typeof description !== 'string') {
        return { message: 'description must be a string', code: 'BAD_REQUEST' };
      }
      if (typeof description === 'string' && description.length > MAX_DESCRIPTION) {
        return {
          message: `description exceeds ${MAX_DESCRIPTION} characters`, code: 'BAD_REQUEST',
        };
      }
    }
    if (Object.prototype.hasOwnProperty.call(body, 'code')) {
      const { code } = body;
      // Judged on PRESENCE, not truthiness: `''` is a value the column accepts
      // and the back-fill would have written, and a transformer with no body is
      // served to every data-entry client by GET /active.
      if (typeof code !== 'string' || code.length === 0) {
        return { message: 'code must be a non-empty string', code: 'BAD_REQUEST' };
      }
      if (Buffer.byteLength(code, 'utf8') > MAX_CODE_SIZE) {
        // The same stable code the create path has always answered with, so the
        // two verbs are one rule in the error shape too, not only in the rule.
        return { message: `Code exceeds ${MAX_CODE_SIZE / 1024}KB limit`, code: 'CODE_TOO_LARGE' };
      }
    }
    return null;
  }

  // POST / — create new transformer
  router.post('/', async (req, res) => {
    if (!requireAdminOrEditor(req, res)) return;
    const { name, description, code, input_schema, output_keys, test_cases } = req.body;

    if (!name || typeof name !== 'string') {
      const e = apiError('name is required', 'BAD_REQUEST', 400);
      return res.status(e.status).json(e.body);
    }
    if (!code || typeof code !== 'string') {
      const e = apiError('code is required', 'BAD_REQUEST', 400);
      return res.status(e.status).json(e.body);
    }
    const shapeError = columnRuleViolation(req.body);
    if (shapeError) {
      const e = apiError(shapeError.message, shapeError.code, 400);
      return res.status(e.status).json(e.body);
    }

    const id = uuidv4();
    const user = req.user?.email || req.user?.id || 'system';
    let conn;
    try {
      conn = await pool.rw.getConnection();
      await conn.beginTransaction();

      // Every authenticated POST stamps owner_id = req.user.id regardless of
      // role. Admin can still hand a transformer to another user (or NULL =
      // shared) via PATCH /:id/owner. Explicit owner_id in the request body
      // is ignored on create — the server is the sole authority.
      const ownerId = req.user?.id || null;
      await conn.query(
        `INSERT INTO \`${t(TABLES.TRANSFORMERS)}\`
         (id, name, description, code, input_schema, output_keys, test_cases, is_active, version, code_size, created_by, updated_by, owner_id)
         VALUES (?, ?, ?, ?, ?, ?, ?, TRUE, 1, ?, ?, ?, ?)`,
        [
          id, name, description || null, code,
          input_schema ? JSON.stringify(input_schema) : null,
          output_keys ? JSON.stringify(output_keys) : null,
          test_cases ? JSON.stringify(test_cases) : null,
          Buffer.byteLength(code, 'utf8'),
          user, user,
          ownerId,
        ],
      );

      // Initial version snapshot
      await conn.query(
        `INSERT INTO \`${t(TABLES.TRANSFORMER_VERSIONS)}\`
         (id, transformer_id, version, code, input_schema, output_keys, test_cases, change_note, action, created_by)
         VALUES (?, ?, 1, ?, ?, ?, ?, 'Initial version', 'create', ?)`,
        [
          uuidv4(), id, code,
          input_schema ? JSON.stringify(input_schema) : null,
          output_keys ? JSON.stringify(output_keys) : null,
          test_cases ? JSON.stringify(test_cases) : null,
          user,
        ],
      );

      await conn.commit();

      const rows = await conn.query(
        `SELECT * FROM \`${t(TABLES.TRANSFORMERS)}\` WHERE id = ?`, [id],
      );
      res.status(201).json(apiOk(withoutAuthorEmails(rows)[0]));
    } catch (err) {
      if (conn) await conn.rollback();
      logger.error({ err, transformerId: id, name }, 'Failed to create transformer id=' + id + ' name=' + name);
      const e = apiError('Database operation failed', 'INTERNAL_ERROR', 500);
      res.status(e.status).json(e.body);
    } finally {
      if (conn) conn.release();
    }
  });

  // PUT /:id — update transformer (auto-version with optimistic locking)
  router.put('/:id', async (req, res) => {
    if (!requireAdminOrEditor(req, res)) return;
    const { name, description, code, input_schema, output_keys, test_cases, change_note, expected_version } = req.body;

    // THE SAME RULES THE CREATE PATH APPLIES, present-only. The guard this
    // replaced tested `code &&` — truthiness — while the back-fill below tested
    // `code ?? existing.code` — nullish — so `''` was "nothing supplied" to the
    // check and a value to the write, and it landed on a NOT NULL TEXT column
    // that accepts it. `GET /active`, which every data-entry client reads, then
    // served a transformer with no body.
    const shapeError = columnRuleViolation(req.body);
    if (shapeError) {
      const e = apiError(shapeError.message, shapeError.code, 400);
      return res.status(e.status).json(e.body);
    }

    // THE OPTIMISTIC LOCK IS THE SERVER'S, NOT THE CALLER'S. It used to run only
    // when the client chose to send `expected_version`, which is the caller
    // deciding whether the server enforces — so two authors saving the same
    // transformer both answered 200 and the second silently overwrote the
    // first's code, with no conflict and no signal. The row lock below
    // serialises them, so the counter and the version history stay consistent;
    // the CODE is what was lost, and nothing recorded that it had been.
    //
    // Verified before requiring it: both clients of this endpoint already send
    // the field, so closing it costs no client change.
    if (!Number.isInteger(expected_version)) {
      const e = apiError(
        'expected_version is required and must be the version you loaded; reload and retry',
        'BAD_REQUEST', 400,
      );
      return res.status(e.status).json(e.body);
    }

    const user = req.user?.email || req.user?.id || 'system';
    let conn;
    try {
      conn = await pool.rw.getConnection();
      await conn.beginTransaction();

      // NOTE: FOR UPDATE locks the row for the duration of the transaction so
      // an admin transfer between the ownership pre-check and the UPDATE WHERE
      // id=? statement cannot sneak through. The pre-check fail-closes on
      // owner_id changes observed inside the same transaction.
      const current = await conn.query(
        `SELECT * FROM \`${t(TABLES.TRANSFORMERS)}\` WHERE id = ? FOR UPDATE`, [req.params.id],
      );
      if (!current.length) {
        await conn.rollback();
        const e = apiError('Transformer not found', 'NOT_FOUND', 404);
        return res.status(e.status).json(e.body);
      }

      const existing = current[0];

      // Enforce ownership on editor mutations. Admin bypasses; editor may only
      // PUT rows they own or that are shared (owner_id IS NULL). Without this
      // check, owner stamping on create would silently allow any editor to
      // overwrite an admin- or other-editor-owned transformer.
      if (req.user?.role === 'editor'
          && existing.owner_id != null
          && existing.owner_id !== req.user?.id) {
        await conn.rollback();
        // 404-on-not-yours stays consistent with the hierarchy_nodes guard
        // — leaking the row's existence to a non-owner via 403 was never
        // the contract.
        const e = apiError('Transformer not found', 'NOT_FOUND', 404);
        return res.status(e.status).json(e.body);
      }

      // Optimistic locking, now unconditional — the request has already been
      // refused above if it stated no expectation.
      if (existing.version !== expected_version) {
        await conn.rollback();
        const e = apiError(
          `Version conflict: expected ${expected_version}, current is ${existing.version}. Refresh and retry.`,
          'VERSION_CONFLICT', 409,
        );
        return res.status(e.status).json(e.body);
      }

      const newVersion = existing.version + 1;
      const newCode = code ?? existing.code;
      const newInputSchema = input_schema !== undefined ? input_schema : (typeof existing.input_schema === 'string' ? JSON.parse(existing.input_schema) : existing.input_schema);
      const newOutputKeys = output_keys !== undefined ? output_keys : (typeof existing.output_keys === 'string' ? JSON.parse(existing.output_keys) : existing.output_keys);
      const newTestCases = test_cases !== undefined ? test_cases : (typeof existing.test_cases === 'string' ? JSON.parse(existing.test_cases) : existing.test_cases);

      await conn.query(
        `UPDATE \`${t(TABLES.TRANSFORMERS)}\`
         SET name = ?, description = ?, code = ?, input_schema = ?, output_keys = ?,
             test_cases = ?, version = ?, code_size = ?, updated_by = ?
         WHERE id = ?`,
        [
          name ?? existing.name,
          description !== undefined ? description : existing.description,
          newCode,
          newInputSchema != null ? JSON.stringify(newInputSchema) : null,
          newOutputKeys != null ? JSON.stringify(newOutputKeys) : null,
          newTestCases != null ? JSON.stringify(newTestCases) : null,
          newVersion,
          Buffer.byteLength(newCode, 'utf8'),
          user,
          req.params.id,
        ],
      );

      // Version snapshot (full metadata)
      await conn.query(
        `INSERT INTO \`${t(TABLES.TRANSFORMER_VERSIONS)}\`
         (id, transformer_id, version, code, input_schema, output_keys, test_cases, change_note, action, created_by)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'update', ?)`,
        [
          uuidv4(), req.params.id, newVersion, newCode,
          newInputSchema != null ? JSON.stringify(newInputSchema) : null,
          newOutputKeys != null ? JSON.stringify(newOutputKeys) : null,
          newTestCases != null ? JSON.stringify(newTestCases) : null,
          change_note || null,
          user,
        ],
      );

      await conn.commit();

      const rows = await conn.query(
        `SELECT * FROM \`${t(TABLES.TRANSFORMERS)}\` WHERE id = ?`, [req.params.id],
      );

      // Prune old versions post-commit as fire-and-forget. PUT correctness
      // must NOT depend on prune outcome; deadlocks under concurrent saves
      // are tolerated by simply skipping that prune cycle. Run on a separate
      // connection so it doesn't reuse the just-released request connection.
      pruneFn({ transformerId: req.params.id, currentVersion: newVersion, userId: user })
        .catch((e) => logger.warn({ err: e, transformerId: req.params.id }, 'auto-prune fire-and-forget failed'));

      res.json(apiOk(withoutAuthorEmails(rows)[0]));
    } catch (err) {
      if (conn) await conn.rollback();
      logger.error({ err, transformerId: req.params.id }, 'Failed to update transformer id=' + req.params.id);
      const e = apiError('Database operation failed', 'INTERNAL_ERROR', 500);
      res.status(e.status).json(e.body);
    } finally {
      if (conn) conn.release();
    }
  });

  // DELETE /:id — soft-delete (default) or hard-delete (?hard=true)
  router.delete('/:id', async (req, res) => {
    if (!requireAdminOrEditor(req, res)) return;
    const hard = req.query.hard === 'true';
    const user = req.user?.email || req.user?.id || 'system';
    let conn;
    try {
      // SELECT guard → optional tx + FOR UPDATE + DELETEs (hard) OR UPDATE (soft) → pool.rw.
      // NOTE: open the transaction up front and use FOR UPDATE on the existence
      // + ownership probe so an admin transfer racing the editor delete cannot
      // sneak through between the SELECT and the DELETE/UPDATE.
      conn = await pool.rw.getConnection();
      await conn.beginTransaction();

      const current = await conn.query(
        `SELECT id, name, owner_id FROM \`${t(TABLES.TRANSFORMERS)}\` WHERE id = ? FOR UPDATE`, [req.params.id],
      );
      if (!current.length) {
        await conn.rollback();
        const e = apiError('Transformer not found', 'NOT_FOUND', 404);
        return res.status(e.status).json(e.body);
      }

      // Editor may only delete rows they own or that are shared. Admin bypasses.
      if (req.user?.role === 'editor'
          && current[0].owner_id != null
          && current[0].owner_id !== req.user?.id) {
        await conn.rollback();
        const e = apiError('Transformer not found', 'NOT_FOUND', 404);
        return res.status(e.status).json(e.body);
      }

      if (hard) {
        // "REFERENCED" MEANS EVERY TABLE THAT REFERENCES IT. This guard knew one
        // referrer — `hierarchy_nodes.transformer_id` — while connectors bind a
        // transformer too, through `response_config.transformer_id`. So
        // `?hard=true` deleted it out from under them, and each such connector's
        // declared output keys degraded to null while its badge layer silently
        // reverted to "no declared outputs": a delete that misses a referrer
        // answers 200 exactly as a legitimate one does, so nothing said.
        //
        // The connector reference lives inside a JSON column and there is no FK,
        // so it is read the same way every consumer of it reads it — through the
        // JSON accessor, inside this transaction, on the connection holding the
        // row lock.
        const refs = await conn.query(
          `SELECT id, name FROM \`${t(TABLES.HIERARCHY_NODES)}\` WHERE transformer_id = ? LIMIT 5`,
          [req.params.id],
        );
        if (refs.length) {
          await conn.rollback();
          const names = refs.map((r) => r.name).join(', ');
          const e = apiError(
            `Cannot delete: transformer is referenced by ${refs.length} blueprint(s): ${names}`,
            'REFERENCE_CONFLICT', 409,
          );
          return res.status(e.status).json(e.body);
        }
        let connectorRefs = [];
        try {
          connectorRefs = await conn.query(
            `SELECT id, name FROM \`${t(TABLES.API_CONNECTORS)}\`
              WHERE JSON_UNQUOTE(JSON_EXTRACT(response_config, '$.transformer_id')) = ? LIMIT 5`,
            [req.params.id],
          );
        } catch (refErr) {
          // A deployment without the connectors table has nothing to protect.
          // Anything else is a real failure and must not read as "no referrers".
          if (!(refErr && refErr.errno === 1146)) throw refErr;
        }
        if (connectorRefs.length) {
          await conn.rollback();
          const names = connectorRefs.map((r) => r.name).join(', ');
          const e = apiError(
            `Cannot delete: transformer is referenced by ${connectorRefs.length} connector(s): ${names}`,
            'REFERENCE_CONFLICT', 409,
          );
          return res.status(e.status).json(e.body);
        }

        await conn.query(
          `DELETE FROM \`${t(TABLES.TRANSFORMER_VERSIONS)}\` WHERE transformer_id = ?`,
          [req.params.id],
        );
        await conn.query(
          `DELETE FROM \`${t(TABLES.TRANSFORMERS)}\` WHERE id = ?`,
          [req.params.id],
        );
        await conn.commit();
      } else {
        // Soft-delete: deactivate
        await conn.query(
          `UPDATE \`${t(TABLES.TRANSFORMERS)}\` SET is_active = FALSE, updated_by = ? WHERE id = ?`,
          [user, req.params.id],
        );
        await conn.commit();
      }

      res.json(apiOk({ deleted: hard, id: req.params.id }));
    } catch (err) {
      if (conn) {
        try { await conn.rollback(); } catch { /* noop */ }
      }
      logger.error({ err, transformerId: req.params.id, hard }, 'Failed to delete transformer id=' + req.params.id + ' hard=' + hard);
      const e = apiError('Database operation failed', 'INTERNAL_ERROR', 500);
      res.status(e.status).json(e.body);
    } finally {
      if (conn) conn.release();
    }
  });

  // PATCH /:id/owner — admin transfer to any user (or null = shared).
  // Admin-only gate preserved.
  router.patch('/:id/owner', async (req, res) => {
    if (!requireAdmin(req, res)) return;
    const { new_owner_id } = req.body || {};
    if (new_owner_id !== null && (typeof new_owner_id !== 'string' || new_owner_id.length === 0)) {
      const e = apiError('new_owner_id must be a string id or null', 'BAD_REQUEST', 400);
      return res.status(e.status).json(e.body);
    }
    let conn;
    try {
      conn = await pool.rw.getConnection();
      await conn.beginTransaction();

      // collation-compare: the column decides which user row this spelling
      // names. `ownerId` is the STORED spelling and is what the UPDATE binds —
      // the resolution alone would still leave a transformer whose owner no
      // JavaScript reader can match against the signed-in user.
      let ownerId = new_owner_id;
      if (new_owner_id !== null) {
        const target = await resolveCanonicalUserId(conn, t(TABLES.USERS), new_owner_id);
        if (!target.ok) {
          await conn.rollback();
          // One mapping for every route that asks the shared resolver, so an
          // administrator gets the same sentence whichever record they transfer —
          // including the banned-account refusal, which is not "no such user".
          const rejection = ownerTargetRejection(target.reason);
          const e = apiError(rejection.message, rejection.code, rejection.status);
          return res.status(e.status).json(e.body);
        }
        if (target.role !== 'admin' && target.role !== 'editor') {
          await conn.rollback();
          const e = apiError('Owner must be admin or editor', 'BAD_REQUEST', 400);
          return res.status(e.status).json(e.body);
        }
        ownerId = target.id;
      }

      const result = await applyOwnerChange(conn, TABLES.TRANSFORMERS, req.params.id, ownerId, {
        actor: req.user,
        action: new_owner_id === null ? 'make_shared' : 'transfer',
        requireCondition: 'any',
        auditEventType: TRANSFORMER_OWNER_AUDIT_EVENT,
        t,
      });

      if (result.conflict_reason === 'NOT_FOUND') {
        await conn.rollback();
        const e = apiError('Not found', 'NOT_FOUND', 404);
        return res.status(e.status).json(e.body);
      }
      if (result.unchanged_same_owner) {
        await conn.commit();
        return res.json(apiOk({ owner_id: result.new_owner, changed: false }));
      }
      await conn.commit();
      res.json(apiOk({ owner_id: result.new_owner, old_owner_id: result.prior_owner, changed: true }));
    } catch (err) {
      if (conn) {
        try { await conn.rollback(); } catch (rbErr) {
          logger.warn({ err: rbErr }, 'rollback after transformer owner transfer failed');
        }
      }
      logger.error({ err, transformerId: req.params.id }, 'Failed to transfer transformer owner');
      const e = apiError('Database operation failed', 'INTERNAL_ERROR');
      res.status(e.status).json(e.body);
    } finally {
      if (conn) conn.release();
    }
  });

  // POST /:id/claim — editor or admin claims a NULL-owned transformer.
  router.post('/:id/claim', async (req, res) => {
    if (!requireAdminOrEditor(req, res)) return;
    if (!req.user || !req.user.id) {
      const e = apiError('Authenticated user required', 'UNAUTHORIZED', 401);
      return res.status(e.status).json(e.body);
    }
    let conn;
    try {
      conn = await pool.rw.getConnection();
      await conn.beginTransaction();
      const result = await applyOwnerChange(conn, TABLES.TRANSFORMERS, req.params.id, req.user.id, {
        actor: req.user,
        action: 'claim',
        requireCondition: 'null',
        auditEventType: TRANSFORMER_OWNER_AUDIT_EVENT,
        t,
      });
      if (result.conflict_reason === 'NOT_FOUND') {
        await conn.rollback();
        const e = apiError('Not found', 'NOT_FOUND', 404);
        return res.status(e.status).json(e.body);
      }
      if (result.conflict_reason === 'NOT_NULL') {
        // SECURITY: do not leak the current owner UUID to a non-owner caller.
        await conn.rollback();
        const e = apiError('Already owned by another user', 'ALREADY_OWNED', 409);
        e.body.already_owned = true;
        return res.status(e.status).json(e.body);
      }
      if (result.idempotent_same_actor) {
        await conn.commit();
        return res.json(apiOk({ owner_id: result.new_owner, claimed: false }));
      }
      await conn.commit();
      res.json(apiOk({ owner_id: result.new_owner, claimed: true }));
    } catch (err) {
      if (conn) {
        try { await conn.rollback(); } catch (rbErr) {
          logger.warn({ err: rbErr }, 'rollback after transformer claim failed');
        }
      }
      logger.error({ err, transformerId: req.params.id }, 'Failed to claim transformer');
      const e = apiError('Database operation failed', 'INTERNAL_ERROR');
      res.status(e.status).json(e.body);
    } finally {
      if (conn) conn.release();
    }
  });

  // POST /:id/release — editor or admin releases a self-owned transformer.
  router.post('/:id/release', async (req, res) => {
    if (!requireAdminOrEditor(req, res)) return;
    if (!req.user || !req.user.id) {
      const e = apiError('Authenticated user required', 'UNAUTHORIZED', 401);
      return res.status(e.status).json(e.body);
    }
    let conn;
    try {
      conn = await pool.rw.getConnection();
      await conn.beginTransaction();
      const result = await applyOwnerChange(conn, TABLES.TRANSFORMERS, req.params.id, null, {
        actor: req.user,
        action: 'release',
        requireCondition: 'self',
        auditEventType: TRANSFORMER_OWNER_AUDIT_EVENT,
        t,
      });
      if (result.conflict_reason === 'NOT_FOUND') {
        await conn.rollback();
        const e = apiError('Not found', 'NOT_FOUND', 404);
        return res.status(e.status).json(e.body);
      }
      if (result.conflict_reason === 'NOT_SELF') {
        // SECURITY: same as claim 409 — do not leak owner UUID.
        await conn.rollback();
        const e = apiError('Only the current owner may release', 'NOT_OWNER', 403);
        return res.status(e.status).json(e.body);
      }
      await conn.commit();
      res.json(apiOk({ owner_id: null, released: true }));
    } catch (err) {
      if (conn) {
        try { await conn.rollback(); } catch (rbErr) {
          logger.warn({ err: rbErr }, 'rollback after transformer release failed');
        }
      }
      logger.error({ err, transformerId: req.params.id }, 'Failed to release transformer');
      const e = apiError('Database operation failed', 'INTERNAL_ERROR');
      res.status(e.status).json(e.body);
    } finally {
      if (conn) conn.release();
    }
  });

  // PUT /:id/toggle-active — toggle is_active flag
  router.put('/:id/toggle-active', async (req, res) => {
    if (!requireAdminOrEditor(req, res)) return;
    const user = req.user?.email || req.user?.id || 'system';
    let conn;
    try {
      conn = await pool.rw.getConnection();
      // NOTE: lock + commit so an admin transfer racing the editor toggle
      // cannot sneak through between SELECT and UPDATE. Editor may only
      // toggle rows they own or that are shared.
      await conn.beginTransaction();
      const guard = await conn.query(
        `SELECT id, owner_id FROM \`${t(TABLES.TRANSFORMERS)}\` WHERE id = ? FOR UPDATE`, [req.params.id],
      );
      if (!guard.length) {
        await conn.rollback();
        const e = apiError('Transformer not found', 'NOT_FOUND', 404);
        return res.status(e.status).json(e.body);
      }
      if (req.user?.role === 'editor'
          && guard[0].owner_id != null
          && guard[0].owner_id !== req.user?.id) {
        await conn.rollback();
        const e = apiError('Transformer not found', 'NOT_FOUND', 404);
        return res.status(e.status).json(e.body);
      }
      await conn.query(
        `UPDATE \`${t(TABLES.TRANSFORMERS)}\` SET is_active = NOT is_active, updated_by = ? WHERE id = ?`,
        [user, req.params.id],
      );
      const rows = await conn.query(
        `SELECT id, is_active FROM \`${t(TABLES.TRANSFORMERS)}\` WHERE id = ?`, [req.params.id],
      );
      await conn.commit();
      // The earlier guard SELECT proved the row exists; this re-read is
      // purely to surface the post-toggle is_active value to the client.
      // Defensive empty check kept for crash hardening.
      if (!rows.length) {
        const e = apiError('Transformer not found', 'NOT_FOUND', 404);
        return res.status(e.status).json(e.body);
      }
      res.json(apiOk(rows[0]));
    } catch (err) {
      if (conn) {
        try { await conn.rollback(); } catch { /* noop */ }
      }
      logger.error({ err, transformerId: req.params.id }, 'Failed to toggle transformer active state id=' + req.params.id);
      const e = apiError('Database operation failed', 'INTERNAL_ERROR', 500);
      res.status(e.status).json(e.body);
    } finally {
      if (conn) conn.release();
    }
  });
}

module.exports = register;
module.exports.pruneOldVersionsFireAndForget = pruneOldVersionsFireAndForget;
module.exports.readRetentionN = readRetentionN;
module.exports.DEFAULT_RETENTION_N = DEFAULT_RETENTION_N;
module.exports.RETENTION_KEY = RETENTION_KEY;
