/**
 * Shared constants for the transformers/* route modules.
 *
 * Extracted in PR 3b when transformers.js (1024 lines) was split into
 * feature-scoped sub-files. Each sub-file exports a `register(router)`
 * function that attaches its handlers to the router assembled in
 * transformers/index.js.
 */

// Max size of a single transformer code body. Applies to both POST /
// (create) and POST /import. The PUT /:id handler enforces the same
// limit on updates.
const MAX_CODE_SIZE = 500 * 1024; // 500 KB

module.exports = { MAX_CODE_SIZE };
