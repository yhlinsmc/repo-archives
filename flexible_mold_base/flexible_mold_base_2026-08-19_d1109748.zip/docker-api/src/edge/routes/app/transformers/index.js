/**
 * @openapi
 *
 * /edge/app/transformers:
 *   get:
 *     tags: [App - Transformers]
 *     summary: List all transformers (metadata only, no code body).
 *     responses:
 *       200:
 *         description: Array of transformer records.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *   post:
 *     tags: [App - Transformers]
 *     summary: Create a new transformer and record its initial version snapshot.
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [name, code]
 *             properties:
 *               name:
 *                 type: string
 *               description:
 *                 type: string
 *               code:
 *                 type: string
 *               input_schema:
 *                 type: object
 *               output_keys:
 *                 type: array
 *                 items:
 *                   type: string
 *               test_cases:
 *                 type: array
 *     responses:
 *       201:
 *         description: Created transformer.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *       400:
 *         description: Validation error.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *
 * /edge/app/transformers/active:
 *   get:
 *     tags: [App - Transformers]
 *     summary: List active transformers with code (for frontend runtime registry).
 *     responses:
 *       200:
 *         description: Array of active transformers including code field.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *
 * /edge/app/transformers/import:
 *   post:
 *     tags: [App - Transformers]
 *     summary: Import a transformer from a JSON export payload.
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [transformer]
 *             properties:
 *               transformer:
 *                 type: object
 *                 required: [name, code]
 *                 properties:
 *                   name:
 *                     type: string
 *                   description:
 *                     type: string
 *                   code:
 *                     type: string
 *                   input_schema:
 *                     type: object
 *                   output_keys:
 *                     type: array
 *                     items:
 *                       type: string
 *                   test_cases:
 *                     type: array
 *     responses:
 *       201:
 *         description: Imported transformer.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *       400:
 *         description: Invalid import payload.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *
 * /edge/app/transformers/{id}:
 *   get:
 *     tags: [App - Transformers]
 *     summary: Get a single transformer with full details.
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Transformer record.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *       404:
 *         description: Not found.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *   put:
 *     tags: [App - Transformers]
 *     summary: Update a transformer with auto-versioning and optional optimistic locking.
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     requestBody:
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *               description:
 *                 type: string
 *               code:
 *                 type: string
 *               input_schema:
 *                 type: object
 *               output_keys:
 *                 type: array
 *                 items:
 *                   type: string
 *               test_cases:
 *                 type: array
 *               change_note:
 *                 type: string
 *               expected_version:
 *                 type: integer
 *                 description: Optimistic-lock guard; omit to skip version check.
 *     responses:
 *       200:
 *         description: Updated transformer.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *       404:
 *         description: Not found.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *       409:
 *         description: Version conflict.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *   delete:
 *     tags: [App - Transformers]
 *     summary: Soft-delete (default) or hard-delete (?hard=true) a transformer.
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *       - in: query
 *         name: hard
 *         schema:
 *           type: boolean
 *         description: Set to true for permanent deletion (blocked if referenced by blueprints).
 *     responses:
 *       200:
 *         description: Deletion result.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *       404:
 *         description: Not found.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *       409:
 *         description: Referenced by one or more blueprints.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *
 * /edge/app/transformers/{id}/toggle-active:
 *   put:
 *     tags: [App - Transformers]
 *     summary: Toggle the is_active flag of a transformer.
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Updated id and is_active state.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *       404:
 *         description: Not found.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *
 * /edge/app/transformers/{id}/versions:
 *   get:
 *     tags: [App - Transformers]
 *     summary: List version history for a transformer (newest first).
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Array of version records.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *
 * /edge/app/transformers/{id}/versions/{versionId}:
 *   get:
 *     tags: [App - Transformers]
 *     summary: Get a specific version snapshot by its UUID.
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *       - in: path
 *         name: versionId
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Full version snapshot.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *       404:
 *         description: Version not found.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *
 * /edge/app/transformers/{id}/rollback/{ver}:
 *   put:
 *     tags: [App - Transformers]
 *     summary: Rollback a transformer to a specific version number (creates a new version entry).
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *       - in: path
 *         name: ver
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: Transformer after rollback.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *       404:
 *         description: Transformer or target version not found.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *
 * /edge/app/transformers/{id}/export:
 *   get:
 *     tags: [App - Transformers]
 *     summary: Export a transformer as a JSON payload for cross-environment migration.
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Exportable transformer JSON.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *       404:
 *         description: Not found.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *
 * /edge/app/transformers/{id}/clone:
 *   post:
 *     tags: [App - Transformers]
 *     summary: Clone a transformer, creating a new copy with "(Copy)" appended to the name.
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       201:
 *         description: Cloned transformer.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *       404:
 *         description: Source transformer not found.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 */

/**
 * transformers/index.js — Router assembly.
 *
 * PR 3b split the old 1024-line transformers.js into four feature files:
 *
 *   crud.js       — list / get / create / update / delete / toggle-active
 *   versions.js   — list versions, get specific version, rollback
 *   io.js         — import, export, clone
 *   _shared.js    — MAX_CODE_SIZE constant
 *
 * Each file exports `register(router)` and mutates the shared router
 * passed in. Registration order matches the pre-split file so Express
 * route matching behaves identically:
 *
 *   1. crud.js     (GET /, GET /active, GET /:id, POST /, PUT /:id,
 *                   DELETE /:id, PUT /:id/toggle-active)
 *   2. versions.js (GET /:id/versions, GET /:id/versions/:versionId,
 *                   PUT /:id/rollback/:ver)
 *   3. io.js       (POST /import, GET /:id/export, POST /:id/clone)
 *
 * CRITICAL: `/active` must be registered before `/:id` or Express will
 * shadow it behind the :id param. crud.js maintains that order internally.
 */
const router = require('express').Router();

require('./crud')(router);
require('./versions')(router);
require('./io')(router);

module.exports = router;
