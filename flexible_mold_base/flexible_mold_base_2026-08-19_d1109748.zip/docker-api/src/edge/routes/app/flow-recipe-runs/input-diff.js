'use strict';

/**
 * input-diff.js — whether a run was dispatched with different answers from the
 * run before it, and the three ways that question can have no answer.
 *
 * THE ONE THING THIS MODULE EXISTS TO PREVENT is a run whose values were never
 * recorded being presented as a run whose values did not change. They are
 * opposite claims: "nothing changed" says the previous answers were compared and
 * found equal, and a run recorded before the capture column existed has no
 * answers to compare at all. Every path below that cannot compare returns
 * {@link DIFF_UNAVAILABLE} carrying the REASON it could not, and the surface
 * renders that as its own state rather than folding it into "unchanged".
 *
 * WHAT "THE RUN BEFORE IT" MEANS. The previous run of the same template THAT
 * THIS CALLER CAN SEE. A comparison against a run outside the caller's
 * visibility would report that the answers changed relative to something they
 * are not allowed to know exists, which leaks the fact of the run and,
 * indirectly, something about its content.
 *
 * WHAT IS COMPARED. The two answer maps, `entered` and `computed`. The captured
 * document also carries identifiers — the blueprint, the variant, and each key's
 * field id — and those are deliberately NOT compared: a field deleted and
 * recreated, or a blueprint edited between runs, changes the identifiers while
 * the operator typed the same thing. Reporting that as a changed answer would
 * make schema maintenance look like data entry. `computed` IS compared, because
 * a computed value is part of what produced the payload: identical typing
 * through changed compute rules is a real difference in what was dispatched, and
 * calling it "no changes" would hide exactly the drift this page is read for.
 */

const DIFF_CHANGED = 'changed';
const DIFF_UNCHANGED = 'unchanged';
const DIFF_UNAVAILABLE = 'unavailable';

/**
 * Why a comparison could not be made. The surface turns each into a sentence;
 * they are separate values because they call for different sentences — one is
 * about the run, one about the run before it, and one about there being no run
 * before it at all.
 */
const REASON_FIRST_RUN = 'first_run';
const REASON_NOT_RECORDED = 'not_recorded';
const REASON_CAPTURE_DROPPED = 'capture_dropped';
const REASON_PREVIOUS_NOT_RECORDED = 'previous_not_recorded';

const DIFF_REASONS = Object.freeze([
  REASON_FIRST_RUN, REASON_NOT_RECORDED, REASON_CAPTURE_DROPPED, REASON_PREVIOUS_NOT_RECORDED,
]);

/** The keys of the captured document this module reads. */
const ANSWER_KEYS = Object.freeze(['entered', 'computed']);

function isPlainObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

/**
 * Read a stored `input_snapshot` into one of the three states a reader has to
 * tell apart, without trusting the writer's shape.
 *
 * The write boundary refuses anything that is not the declared document, so a
 * value that does not parse here is either a row written before that boundary
 * existed or a row written by something else entirely. Either way it is read as
 * "nothing was recorded" rather than as a comparable document — being unable to
 * read a document is not evidence about what it said.
 *
 * THE IDENTITY HALF RIDES ALONG AND IS NEVER COMPARED. `fields`, `blueprint_id`
 * and `variant_id` are returned because a reader that renders the answers needs
 * them — a stored key is joined to a field by its id, and the form the answers
 * were entered into is what a replay resolves against. The comparison above
 * still reads only the two answer maps, for the reason in the module header.
 * They are defaulted rather than required: a row written before the identity
 * half existed is still a readable set of answers.
 *
 * @param {unknown} value the column's stored value, or null/undefined when the
 *   column is absent from this database
 * @returns {{state: 'captured', entered: object, computed: object, fields: object,
 *            blueprintId: string|null, variantId: string|null}
 *          | {state: 'dropped'}
 *          | {state: 'absent'}}
 */
function readSnapshot(value) {
  if (value == null || value === '') return { state: 'absent' };
  let parsed;
  if (typeof value === 'string') {
    try { parsed = JSON.parse(value); } catch { return { state: 'absent' }; }
  } else {
    parsed = value;
  }
  if (!isPlainObject(parsed)) return { state: 'absent' };
  if (Object.prototype.hasOwnProperty.call(parsed, 'not_captured')) return { state: 'dropped' };
  if (!isPlainObject(parsed.entered) || !isPlainObject(parsed.computed)) return { state: 'absent' };
  return {
    state: 'captured',
    entered: parsed.entered,
    computed: parsed.computed,
    fields: isPlainObject(parsed.fields) ? parsed.fields : {},
    blueprintId: typeof parsed.blueprint_id === 'string' ? parsed.blueprint_id : null,
    variantId: typeof parsed.variant_id === 'string' ? parsed.variant_id : null,
  };
}

/**
 * Which FIELDS differ between two captured documents, and how.
 *
 * ONE ENTRY PER FIELD, over the union of every key either document holds in
 * either half. The two halves are NOT disjoint key spaces and treating them as
 * such is a defect with a number attached: the form's value map holds a computed
 * field's value like any other, so `buildFlowInputSnapshot` writes that field
 * into `entered` AND into `computed` under the same key. Comparing the halves
 * separately therefore reported every derived field twice — one operator edit to
 * a field feeding one rule counted as three changes, and one of the two copies
 * printed with no qualifier on a surface where an unqualified line means "the
 * operator typed this".
 *
 * WHICH VALUE STANDS FOR A FIELD: the ENTERED one, falling back to the computed
 * one only where the key is absent from `entered` altogether.
 *
 * The two halves are equal for a rule nobody can override, so this only decides
 * anything in one case — and in that case it decides the whole surface.
 * `compute_rules.overridable` lets an operator unlock a derived field and type
 * over it; `reconcileComputedField` then returns `protect`, which keeps THEIR
 * number in the form's value map while `computedValue` goes on holding the
 * formula's. `entered` is built from that value map, the outputs are generated
 * from it, and the payload is rendered from the outputs — so the entered half is
 * what actually leaves the building and the computed half is the formula's
 * opinion about what should have.
 *
 * Preferring the formula's opinion made this surface report NO CHANGE for a
 * pending dispatch whose outgoing value moved 5 → 6 under an override, on the
 * one screen whose entire purpose is that a dispatch cannot be taken back.
 *
 * KNOWN RESIDUAL, stated rather than discovered later. The shipped run-to-run
 * indicator (`compareRunInput`) compares the two maps independently, so it and
 * this function disagree in the narrow case where ONLY the formula's opinion
 * moved — an overridden field whose rule was edited between two dispatches. That
 * one is the right answer here: nothing different was sent, and this surface
 * exists to say whether anything different is about to be. Reconciling the two
 * is a change to a shipped surface and belongs to its own piece of work.
 *
 * WHICH HALF A FIELD IS REPORTED IN — a question about the LINE, not about the
 * number above: `computed` if EITHER document derived it, `entered` otherwise. A
 * field that was derived on one side and typed on the other is qualified rather
 * than left bare, because an unqualified line is a claim that a person typed the
 * value and that is the claim worth failing safe on.
 *
 * Reported key by key rather than collapsed to a verdict: a surface that has to
 * NAME what changed cannot recover the names from a boolean, and running the
 * comparison twice — once for the verdict and once for the list — is two rules
 * that can disagree. The verdict is derived from this list instead.
 *
 * Sorted, so the same two documents always produce the same list.
 *
 * @param {{entered: object, computed: object}} before the earlier document
 * @param {{entered: object, computed: object}} after  the later one
 */
function answerDocumentChanges(before, after) {
  const has = (map, key) => Object.prototype.hasOwnProperty.call(map, key);
  const derived = (doc, key) => has(doc.computed, key);
  // The one value that stands for a field in one document, or undefined when
  // that document does not hold the field at all. Entered first — see the header
  // for why the formula's opinion is not the value that was sent.
  const valueOf = (doc, key) => {
    if (has(doc.entered, key)) return doc.entered[key];
    if (has(doc.computed, key)) return doc.computed[key];
    return undefined;
  };

  const keys = [...new Set([
    ...Object.keys(before.entered), ...Object.keys(before.computed),
    ...Object.keys(after.entered), ...Object.keys(after.computed),
  ])].sort();

  const out = [];
  for (const key of keys) {
    const half = derived(before, key) || derived(after, key) ? 'computed' : 'entered';
    const from = valueOf(before, key);
    const to = valueOf(after, key);
    if (from === undefined && to === undefined) continue;
    // `before` is the earlier document, so a field only the later one holds was
    // added by it.
    if (to === undefined) out.push({ key, change: 'removed', half });
    else if (from === undefined) out.push({ key, change: 'added', half });
    else if (from !== to) out.push({ key, change: 'changed', half });
  }
  return out;
}

/**
 * Whether two answer maps say the same thing.
 *
 * Compared key by key over the union of both key sets, so a key present in one
 * and absent in the other is a difference rather than something the shorter loop
 * never reached. Key ORDER is not a difference: two documents holding the same
 * answers are the same answers whichever order the form serialised them in.
 */
function sameAnswerMap(a, b) {
  const keys = new Set([...Object.keys(a), ...Object.keys(b)]);
  for (const k of keys) {
    const inA = Object.prototype.hasOwnProperty.call(a, k);
    const inB = Object.prototype.hasOwnProperty.call(b, k);
    if (inA !== inB) return false;
    if (a[k] !== b[k]) return false;
  }
  return true;
}

/**
 * Compare one run's recorded answers with the previous visible run's.
 *
 * @param {unknown} current  this run's stored `input_snapshot`
 * @param {unknown} previous the previous visible run's, or undefined when there
 *   is no previous visible run
 * @returns {{diff: string, reason: string|null}}
 */
function compareRunInput(current, previous) {
  const here = readSnapshot(current);
  if (here.state === 'dropped') {
    return { diff: DIFF_UNAVAILABLE, reason: REASON_CAPTURE_DROPPED };
  }
  if (here.state !== 'captured') {
    return { diff: DIFF_UNAVAILABLE, reason: REASON_NOT_RECORDED };
  }
  if (previous === undefined) {
    return { diff: DIFF_UNAVAILABLE, reason: REASON_FIRST_RUN };
  }
  const before = readSnapshot(previous);
  if (before.state !== 'captured') {
    return { diff: DIFF_UNAVAILABLE, reason: REASON_PREVIOUS_NOT_RECORDED };
  }
  const same = ANSWER_KEYS.every((k) => sameAnswerMap(here[k], before[k]));
  return { diff: same ? DIFF_UNCHANGED : DIFF_CHANGED, reason: null };
}

/**
 * Attach the indicator to a page of runs, newest first.
 *
 * `lookahead` is the next older visible run, read one past the page so the
 * OLDEST row on the page is compared against something rather than reported as
 * the first run of the template. It is a comparison partner only and is never
 * returned: it belongs to the next page.
 *
 * `hasSnapshotColumn` false means this database never stored the column, so no
 * row on it can be compared — stated once here rather than inferred per row from
 * an absent value that would otherwise read as "recorded nothing".
 */
function attachInputDiff(rows, lookahead, { hasSnapshotColumn }) {
  return rows.map((row, i) => {
    const rest = Object.fromEntries(
      Object.entries(row).filter(([k]) => k !== 'input_snapshot'),
    );
    if (!hasSnapshotColumn) {
      return { ...rest, input_diff: DIFF_UNAVAILABLE, input_diff_reason: REASON_NOT_RECORDED };
    }
    const nextOlder = i + 1 < rows.length ? rows[i + 1] : lookahead;
    const { diff, reason } = compareRunInput(
      row.input_snapshot,
      nextOlder === undefined || nextOlder === null ? undefined : nextOlder.input_snapshot,
    );
    return { ...rest, input_diff: diff, input_diff_reason: reason };
  });
}

module.exports = {
  DIFF_CHANGED,
  DIFF_UNCHANGED,
  DIFF_UNAVAILABLE,
  DIFF_REASONS,
  REASON_FIRST_RUN,
  REASON_NOT_RECORDED,
  REASON_CAPTURE_DROPPED,
  REASON_PREVIOUS_NOT_RECORDED,
  ANSWER_KEYS,
  readSnapshot,
  compareRunInput,
  answerDocumentChanges,
  attachInputDiff,
};
