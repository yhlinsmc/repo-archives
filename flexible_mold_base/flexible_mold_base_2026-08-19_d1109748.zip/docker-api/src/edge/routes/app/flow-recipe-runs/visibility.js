'use strict';

/**
 * visibility.js — who may read which run, expressed as one SQL predicate.
 *
 * THE RULE, as of this release. Every authenticated caller reads every run.
 * There is no per-user scope, no owner widening and no role distinction: being
 * signed in is the whole of it. This replaced a three-tier rule (an
 * administrator saw everything, a blueprint's owner saw everything under that
 * blueprint, everyone else saw their own) because reading a run was decided to
 * be the wrong thing to guard — what is guarded is DISPATCHING one, and that is
 * enforced where a run is created, not where one is read.
 *
 * WHAT THIS EXPOSES, stated rather than buried. A run row records the answers
 * that produced it. Making every run readable makes those answers readable, and
 * the only thing withheld from them is the value of a field whose name marks it
 * sensitive. That was known when the rule was chosen. It is written here so that
 * narrowing it again is one decision in one place rather than a rediscovery.
 *
 * WHY THIS MODULE STILL EXISTS, rather than the callers dropping it. Six read
 * statements are built from it, and it is the only place the rule is stated. Put
 * a predicate back here and every one of them narrows together, counts included;
 * delete it and the next narrowing has to find all six and get all six right.
 * The empty string is a rule — "no restriction" — not an absence of one.
 *
 * WHY A PREDICATE AND NOT A FILTER APPLIED AFTER THE READ, which is what would
 * matter again the moment the rule narrows. Both surfaces this serves report a
 * COUNT beside the rows — the number of runs in a group, and the total behind a
 * page. A count computed over a wider set than the rows tells the reader how
 * many runs exist that they may not see, which is the leak a post-read filter
 * cannot close. One predicate, bound once, is used by the row query and the
 * count query alike.
 *
 * AUTHENTICATION IS STILL THE GATE. Every router that reads runs mounts its
 * `requireAuth` check ahead of these statements. "Everyone" means every signed-in
 * caller, and an anonymous request never reaches a statement at all.
 */

/**
 * The read predicate for one caller.
 *
 * @param {{id: string, role: string}} _user the authenticated caller. Unread:
 *   no property of the caller changes what they may read. It stays in the
 *   signature because it is what a narrowed rule would need, and because every
 *   call site already passes it.
 * @param {string} _runsAlias the alias the run table is selected under. Same
 *   reason: a predicate that names a column needs it.
 * @returns {{sql: string, params: unknown[]}} `sql` is always '', meaning "no
 *   restriction"; callers must treat the empty string as TRUE rather than as an
 *   empty WHERE clause.
 */
function buildRunVisibility(_user, _runsAlias) {
  return { sql: '', params: [] };
}

/** ` WHERE <predicate>` or '' — so a caller never assembles the keyword twice. */
function whereClause(predicateSql) {
  return predicateSql ? ` WHERE ${predicateSql}` : '';
}

module.exports = { buildRunVisibility, whereClause };
