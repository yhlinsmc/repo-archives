'use strict';

/**
 * run-answers.js — the two reads that put a run's RECORDED ANSWERS on a surface,
 * and the one rule they both turn on.
 *
 *   GET  /runs/compare?ids=…            two to four runs of one template, read
 *                                       side by side
 *   POST /groups/:groupId/pending-diff  what a dispatch about to be made would
 *                                       change against the last one
 *
 * WHY THESE ARE NOT ON THE ROW DETAIL. The detail route deliberately withholds
 * the captured document and reports only WHETHER a run recorded one; it renders
 * none of it, and it is the largest bounded column on the row. These two routes
 * exist because two surfaces do render it, and both bound how much they can ask
 * for: the comparison at four runs, the confirmation at one.
 *
 * WHY THE PRE-DISPATCH DIFFERENCE IS A POST AND STILL ONLY READS. The answers
 * about to be dispatched have to travel to the comparison, and they are a
 * document rather than an identifier — a GET body is dropped by parts of this
 * stack, which is why the schema routes on this boundary already POST for a
 * read. Nothing here writes.
 *
 * WHY THE COMPARISON IS MADE HERE AND NOT IN THE BROWSER, which is the whole
 * reason this route exists at all. A stored answer was MASKED by key name before
 * it was stored, and the answers on the operator's screen are not. Comparing one
 * against the other in the browser would report every secret-named field as
 * changed on every dispatch, for ever. The pending answers are therefore masked
 * through the SAME `maskDeep` the write path uses — one masking implementation,
 * so both sides of the comparison have had the same thing done to them.
 *
 * The consequence is stated rather than discovered: a secret-named value that
 * genuinely changed reads as unchanged, because both sides are `****`. That is
 * the same limitation the shipped run-to-run indicator carries, for the same
 * reason, and it is the safe direction — the alternative is a masked value
 * leaving the row.
 */
const express = require('express');
const { pool } = require('../../../db');
const {
  requireAuth, apiOk, apiError, UUID_RE,
} = require('../../../../shared/helpers');
const { mapRowsFromDb, normalizeTimestamp } = require('../../../lib/dto-mapper');
const { normalizeRows } = require('../../../../shared/serializers/normalize-nullable');
const { logger: rootLogger } = require('../../../../shared/lib/logger');
const { decodeGroupId } = require('./group-id');
const {
  readSnapshot, answerDocumentChanges,
  REASON_FIRST_RUN, REASON_PREVIOUS_NOT_RECORDED,
} = require('./input-diff');
const { maskDeep, MAX_RUN_INPUT_SNAPSHOT_BYTES } = require('./serializer');
const {
  parseInputSnapshot, INVALID_IDENTITY_CODE,
} = require('../../../lib/flow-run-input-snapshot');
const { buildRunVisibility } = require('./visibility');
const { buildRunsByIdSql, buildLatestGroupRunSql, groupPredicate } = require('./run-queries');
const { attachActorNames } = require('./aggregate');

const logger = rootLogger.child({ module: 'edge-flow-run-answers' });

const router = express.Router();

// SECURITY: authentication for the whole router. Both reads below return what an
// operator typed into a form, which is the most sensitive thing this table
// holds; the gate is on the router so a route added later inherits it.
router.use((req, res, next) => { if (requireAuth(req, res)) next(); });

/**
 * The comparison's bounds, matching the capacity version history this surface
 * mirrors: below two there is nothing to compare against, and above four there
 * is nowhere legible to put the panels. The browser enforces the same two
 * numbers on the selection; these are what make them a rule rather than a
 * client-side convention.
 */
const MIN_COMPARE_RUNS = 2;
const MAX_COMPARE_RUNS = 4;

/** Why a pending dispatch has nothing to be compared against. Two of the four
 *  are the run-to-run indicator's own reasons, reused rather than restated
 *  because they describe the same facts about the previous run. */
const REASON_PENDING_NOT_CAPTURED = 'pending_not_captured';
const REASON_PENDING_TOO_LARGE = 'pending_too_large';
/** The dispatch path drops the capture on this rather than refusing the run, so
 *  the confirmation reports it rather than failing on a build that would go. */
const REASON_PENDING_UNREADABLE_IDENTITY = 'pending_unreadable_identity';
const REASON_PREVIOUS_CAPTURE_DROPPED = 'previous_capture_dropped';

const dbError = (res) => {
  const e = apiError('Database operation failed', 'INTERNAL_ERROR', 500);
  res.status(e.status).json(e.body);
};

const badRequest = (res, message, code = 'VALIDATION_ERROR') => {
  const e = apiError(message, code, 400);
  res.status(e.status).json(e.body);
};

/** Read with the additive snapshot column, falling back to the column set a
 *  database that warn-skipped the ALTER actually has. Same tiering as the list
 *  and detail reads; a database without the column reports every answer as not
 *  recorded, which is the truth there. */
async function readWithSnapshotFallback(conn, build, params) {
  try {
    return { rows: await conn.query(build(true), params), hasSnapshotColumn: true };
  } catch (err) {
    if (!(err && (err.errno === 1054 || err.code === 'ER_BAD_FIELD_ERROR'))) throw err;
    return { rows: await conn.query(build(false), params), hasSnapshotColumn: false };
  }
}

/**
 * The ids a comparison names, or a refusal.
 *
 * Duplicates are refused rather than de-duplicated: a request naming one run
 * twice is a caller that thinks it selected two, and answering it with one panel
 * would confirm a selection that was never made.
 */
function parseCompareIds(raw) {
  if (typeof raw !== 'string' || raw.trim() === '') {
    return { error: 'Name the runs to compare.' };
  }
  const ids = raw.split(',').map((s) => s.trim()).filter(Boolean);
  if (ids.length < MIN_COMPARE_RUNS || ids.length > MAX_COMPARE_RUNS) {
    return {
      error: `Select ${MIN_COMPARE_RUNS} to ${MAX_COMPARE_RUNS} runs to compare.`,
    };
  }
  if (new Set(ids).size !== ids.length) return { error: 'A run may only be named once.' };
  if (!ids.every((id) => UUID_RE.test(id))) return { error: 'One of the runs is not a run.' };
  return { ids };
}

/** The outputs a run produced, read from the column that holds them.
 *
 *  Null covers every way there is nothing to show — never recorded, or recorded
 *  in a shape this build cannot read — because they are one state to a reader:
 *  no outputs to compare. A run whose outputs genuinely held nothing is an empty
 *  map, which is a different answer and stays one.
 *
 *  Values are coerced to text because that is what the comparison prints. The
 *  column is written from a map of strings, but masking can replace a value and
 *  a row this build did not write can hold anything. */
function readOutputs(value) {
  if (value == null || value === '') return null;
  let parsed;
  try { parsed = typeof value === 'string' ? JSON.parse(value) : value; } catch { return null; }
  if (parsed === null || typeof parsed !== 'object' || Array.isArray(parsed)) return null;
  const out = {};
  for (const [k, v] of Object.entries(parsed)) {
    if (k === '__proto__' || k === 'constructor' || k === 'prototype') continue;
    out[k] = typeof v === 'string' ? v : JSON.stringify(v);
  }
  return out;
}

/**
 * One run's row, shaped for a surface that renders what it recorded.
 *
 * WRITTEN ONCE for both readers below. The comparison and the replay show the
 * same document to the same rule; two shaping functions would be two chances for
 * one of them to start reporting a missing capture as an empty one.
 */
function shapeRunAnswers(row, hasSnapshotColumn) {
  const snapshot = hasSnapshotColumn ? readSnapshot(row.input_snapshot) : { state: 'absent' };
  const captured = snapshot.state === 'captured';
  return {
    id: row.id,
    created_at: normalizeTimestamp(row.created_at),
    status: row.status,
    actor_id: row.actor_id,
    // Y-pattern carve-out (SDD §8.3), same as FlowRunGroup.template_id: null is
    // its own state — a run recorded with no template — not an empty string.
    // The single-run read (`/runs/:runId/input`) needs this alongside the
    // blueprint/variant pair below so a caller can tell two templates that
    // share a blueprint and variant apart (fmb-1782 P2 #1); the comparison
    // read already had the column for its own cross-template refusal.
    template_id: row.template_id == null ? null : row.template_id,
    input_capture: snapshot.state,
    // Present only for a captured run. A reader tells "recorded nothing" from
    // "recorded an empty form" by the capture state, never by an empty map —
    // which is why these are null rather than {} otherwise.
    entered: captured ? snapshot.entered : null,
    computed: captured ? snapshot.computed : null,
    fields: captured ? snapshot.fields : null,
    // The form the answers were entered into, for a reader that renders them
    // against today's schema.
    snapshot_blueprint_id: captured ? snapshot.blueprintId : null,
    snapshot_variant_id: captured ? snapshot.variantId : null,
    outputs: readOutputs(row.output_snapshot),
  };
}

/** The fields every shaped run crosses the boundary with as '' rather than null.
 *  The two answer maps, `template_id`, and the snapshot identity are NOT among
 *  them: null is a state of its own for each. */
const SHAPED_NULLABLE_FIELDS = Object.freeze([
  'created_at', 'snapshot_blueprint_id', 'snapshot_variant_id',
]);

router.get('/runs/compare', async (req, res) => {
  const parsed = parseCompareIds(req.query && req.query.ids);
  if (parsed.error) return badRequest(res, parsed.error);

  const visibility = buildRunVisibility(req.user, 'r');
  try {
    const conn = await pool.ro.getConnection();
    try {
      const { rows, hasSnapshotColumn } = await readWithSnapshotFallback(
        conn,
        (withSnapshot) => buildRunsByIdSql(visibility.sql, parsed.ids.length, { withSnapshot }),
        [...parsed.ids, ...visibility.params],
      );
      // A run the caller may not read is reported the same way as one that does
      // not exist, and the whole comparison is refused rather than quietly drawn
      // from a smaller set: a panel silently missing from a side-by-side reads
      // as a run that recorded nothing.
      if (rows.length !== parsed.ids.length) {
        const e = apiError('One or more of those runs could not be read', 'NOT_FOUND', 404);
        return res.status(e.status).json(e.body);
      }

      const mapped = mapRowsFromDb('flow_recipe_runs', rows);
      // D19: a comparison is offered within ONE template's history, so the
      // restriction is structural. It is enforced on the rows rather than on the
      // request because the request carries run ids and only the rows say what
      // template each belongs to. NULL is one template's worth of runs here, the
      // same partition the grouped read treats it as.
      const templates = new Set(mapped.map((r) => (r.template_id == null ? null : r.template_id)));
      if (templates.size > 1) {
        return badRequest(
          res,
          'Runs of different templates cannot be compared.',
          'CROSS_TEMPLATE_COMPARE',
        );
      }

      const shaped = mapped.map((row) => shapeRunAnswers(row, hasSnapshotColumn));
      await attachActorNames(conn, shaped, 'actor_id', 'actor');

      return res.json(apiOk({
        // Oldest first, which the statement already orders by: the first panel
        // is the baseline the rest are marked against.
        runs: normalizeRows(shaped, SHAPED_NULLABLE_FIELDS),
      }));
    } finally {
      conn.release();
    }
  } catch (err) {
    logger.error({ err }, 'Failed to read runs for comparison');
    return dbError(res);
  }
});

/**
 * One run's recorded answers, for reading them back inside the form.
 *
 * A route of its own rather than a selection of one, because the comparison's
 * bounds are part of what it means: below two runs there is nothing to compare,
 * and letting that path answer for one would make the bounds a presentation
 * choice instead of a rule.
 */
router.get('/runs/:runId/input', async (req, res) => {
  const notFound = () => {
    const e = apiError('Run not found', 'NOT_FOUND', 404);
    return res.status(e.status).json(e.body);
  };
  if (!UUID_RE.test(String(req.params.runId))) return notFound();

  const visibility = buildRunVisibility(req.user, 'r');
  try {
    const conn = await pool.ro.getConnection();
    try {
      const { rows, hasSnapshotColumn } = await readWithSnapshotFallback(
        conn,
        (withSnapshot) => buildRunsByIdSql(visibility.sql, 1, { withSnapshot }),
        [req.params.runId, ...visibility.params],
      );
      // A run the caller may not read is reported as absent rather than as
      // refused: answering "not yours" over an id confirms the run exists.
      if (!rows.length) return notFound();

      const [row] = mapRowsFromDb('flow_recipe_runs', rows);
      const shaped = shapeRunAnswers(row, hasSnapshotColumn);
      await attachActorNames(conn, [shaped], 'actor_id', 'actor');
      return res.json(apiOk(normalizeRows([shaped], SHAPED_NULLABLE_FIELDS)[0]));
    } finally {
      conn.release();
    }
  } catch (err) {
    logger.error({ err, runId: req.params.runId }, 'Failed to read the recorded answers of a run');
    return dbError(res);
  }
});

/** A pending difference that could not be made, said the same way every time. */
const unavailable = (reason, previous = null) => ({
  state: 'unavailable', reason, previous, changes: [],
});

/**
 * The answers a dispatch is about to record, masked exactly as they will be
 * stored, or a statement of why they cannot be compared.
 *
 * The size bound is measured AFTER masking for the same reason the write path
 * measures it there: that is the document that reaches the column, so the two
 * agree about which dispatches will carry a capture.
 *
 * WHAT IT REFUSES IS BOUNDED BY WHAT THE DISPATCH REFUSES. A confirmation that
 * fails on a document the dispatch behind it would have accepted tells the
 * operator their build is broken when it is not. Two of `parseInputSnapshot`'s
 * outcomes are degrades on the dispatch path rather than refusals — an
 * oversized capture, and an identity value that is not identifier-shaped — and
 * both are degrades here too, each with its own reason. The dispatch path's
 * argument for the second is in `flow-run-input-snapshot.js`: the id shape is a
 * convention nothing enforces, so blocking on it asserts more than it knows,
 * and the operator is left no lever. Everything else — a document this server
 * cannot read at all — is still a refusal.
 */
function maskPending(raw) {
  let parsed;
  try {
    parsed = parseInputSnapshot(raw);
  } catch (err) {
    if (err && err.code === INVALID_IDENTITY_CODE) {
      return { reason: REASON_PENDING_UNREADABLE_IDENTITY };
    }
    return { error: err };
  }
  if (parsed.kind !== 'captured') return { reason: REASON_PENDING_NOT_CAPTURED };
  const document = {
    entered: maskDeep(parsed.document.entered),
    computed: maskDeep(parsed.document.computed),
  };
  const size = Buffer.byteLength(JSON.stringify({ ...parsed.document, ...document }), 'utf8');
  if (size > MAX_RUN_INPUT_SNAPSHOT_BYTES) return { reason: REASON_PENDING_TOO_LARGE };
  return { document };
}

router.post('/groups/:groupId/pending-diff', async (req, res) => {
  const parsedGroup = decodeGroupId(req.params.groupId);
  if (!parsedGroup.ok) {
    const e = apiError('Unknown run group', 'NOT_FOUND', 404);
    return res.status(e.status).json(e.body);
  }

  const pending = maskPending(req.body && req.body.input_snapshot);
  if (pending.error) {
    const err = pending.error;
    const e = apiError(err.message, err.code || 'VALIDATION_ERROR', err.status || 400);
    return res.status(e.status).json(e.body);
  }
  if (pending.reason) return res.json(apiOk(unavailable(pending.reason)));

  const visibility = buildRunVisibility(req.user, 'r');
  const group = groupPredicate(parsedGroup.templateId);
  try {
    const conn = await pool.ro.getConnection();
    try {
      const { rows, hasSnapshotColumn } = await readWithSnapshotFallback(
        conn,
        (withSnapshot) => buildLatestGroupRunSql(visibility.sql, group.sql, { withSnapshot }),
        [...group.params, ...visibility.params],
      );
      if (!rows.length) return res.json(apiOk(unavailable(REASON_FIRST_RUN)));

      const [previousRow] = mapRowsFromDb('flow_recipe_runs', rows);
      const previous = {
        id: previousRow.id,
        created_at: normalizeTimestamp(previousRow.created_at),
        actor_id: previousRow.actor_id,
      };
      await attachActorNames(conn, [previous], 'actor_id', 'actor');

      const before = hasSnapshotColumn
        ? readSnapshot(previousRow.input_snapshot)
        : { state: 'absent' };
      if (before.state !== 'captured') {
        return res.json(apiOk(unavailable(
          before.state === 'dropped' ? REASON_PREVIOUS_CAPTURE_DROPPED : REASON_PREVIOUS_NOT_RECORDED,
          previous,
        )));
      }

      // ONE ENTRY PER FIELD across both halves, not one per half. The halves
      // share keys — the form's value map holds a computed field's value like
      // any other — so a per-half comparison counted every derived field twice.
      // See `answerDocumentChanges`.
      const changes = answerDocumentChanges(before, pending.document);

      return res.json(apiOk({
        // Derived from the list rather than computed a second time, so the
        // verdict and the names behind it cannot disagree.
        state: changes.length === 0 ? 'unchanged' : 'changed',
        reason: '',
        previous,
        changes,
      }));
    } finally {
      conn.release();
    }
  } catch (err) {
    logger.error({ err, groupId: req.params.groupId }, 'Failed to read the previous run of a group');
    return dbError(res);
  }
});

module.exports = {
  router,
  MIN_COMPARE_RUNS,
  MAX_COMPARE_RUNS,
  REASON_PENDING_NOT_CAPTURED,
  REASON_PENDING_TOO_LARGE,
  REASON_PENDING_UNREADABLE_IDENTITY,
  REASON_PREVIOUS_CAPTURE_DROPPED,
  parseCompareIds,
  readOutputs,
};
