'use strict';

/**
 * group-id.js — the identifier one run group is addressed by, and the only place
 * it is read.
 *
 * WHY A GROUP IS NOT ADDRESSED BY ITS TEMPLATE ID. Two KINDS of group are
 * addressable: one template's runs, and the runs recorded with no template at
 * all. `flow_recipe_runs.template_id` is nullable, carries no foreign key, and
 * the generic write route that inserts a run applies no shape check to it, so
 * its value is arbitrary text. Addressing the first kind by that text and the
 * second by a reserved word puts both kinds in ONE namespace, and the two
 * failures that follow are reachable through ordinary authenticated use: a run
 * whose `template_id` literally held the reserved word opened the OTHER group's
 * rows under this group's heading, and a value that was not UUID-shaped was
 * listed by the first level and refused by the second.
 *
 * So the identifier carries its own KIND, and the kind is READ rather than
 * inferred from the value's shape:
 *
 *   none        the runs recorded with no template — one fixed word, no payload
 *   t.<text>    one template's runs, `<text>` being its id percent-encoded
 *
 * COLLISION-FREE BY CONSTRUCTION, not by convention. Every template identifier
 * begins with `t.`; the no-template identifier is exactly `none`, which does
 * not; so the two sets are disjoint whatever a `template_id` holds — including
 * the word `none` itself, which encodes to `t.none`. Within the template kind
 * the encoding is injective, because percent-encoding is, so `t.` + encode(x)
 * names x and nothing else. The one fact this argument rests on — that the fixed
 * word does not itself begin with the prefix — is a relation between two
 * constants in this file and is asserted in `flow-run-group-id.test.js` rather
 * than left to a reader to re-derive.
 *
 * WHY THE PAYLOAD IS PERCENT-ENCODED INSIDE THE IDENTIFIER, on top of whatever
 * the transport does to the path segment it travels in. Every leg of the trip
 * DECODES the segment it is handed — the browser router while matching a route,
 * Express while filling `req.params` — so a payload that is not already the
 * image of that decoding is interpreted rather than carried: a template id of
 * `a%2Fb` arrives here as `a/b` and opens a group that is not the one that was
 * clicked, and a `/` ends the segment outright. Encoding the payload is part of
 * the identifier's DEFINITION, which makes decoding it the identity for every
 * value. A UUID contains nothing the encoding touches, so the ordinary
 * identifier is still the readable one.
 *
 * THE OTHER HALF OF THIS CONTRACT IS IN THE FRONTEND (`src/fmb/hooks/useFlowRuns.ts`,
 * `groupRouteId`), which cannot import this file — the application bundle does
 * not reach docker-api. The duplication is therefore structural and is GUARDED
 * instead: `src/fmb/hooks/__tests__/flow-run-group-id.parity.test.ts` drives the
 * frontend's encoder and this decoder over {@link GROUP_ID_PARITY_TEMPLATE_IDS}
 * and requires the round trip, so neither half can move alone.
 */

/** The identifier of the group of runs recorded with no template. A reserved
 *  word rather than an empty segment, which a proxy is free to fold away. */
const NO_TEMPLATE_GROUP = 'none';

/** The kind tag every template group's identifier begins with. */
const TEMPLATE_GROUP_PREFIX = 't.';

/**
 * The longest identifier this decoder will look at — an input-size guard, NOT a
 * shape check, and deliberately past anything the column can produce: a
 * `CHAR(36)` in utf8mb4 holds at most 36 characters of up to 4 bytes each, and
 * percent-encoding spends 3 characters per byte, so the widest storable value
 * encodes to 36 × 4 × 3 = 432 characters plus the two-character tag. The cap
 * therefore cannot refuse a value the column could hold, which is the whole
 * failure this module exists to end.
 */
const MAX_GROUP_ID_CHARS = 512;

/**
 * The values both halves of the codec are driven over, published here so the
 * frontend's encoder and this decoder cannot each be tested against a different
 * set. Every entry is a value the column can hold and the write path can accept:
 * the reserved word itself, a string already shaped like a template identifier,
 * text that is not identifier-shaped, and the characters a URL path segment
 * treats as structure rather than as data.
 */
const GROUP_ID_PARITY_TEMPLATE_IDS = Object.freeze([
  '11111111-1111-1111-1111-111111111111',
  'AAAAAAAA-1111-1111-1111-111111111111',
  NO_TEMPLATE_GROUP,
  `${TEMPLATE_GROUP_PREFIX}${NO_TEMPLATE_GROUP}`,
  TEMPLATE_GROUP_PREFIX,
  '',
  'legacy-7',
  'a/b',
  'a%2Fb',
  '%',
  'a?b#c',
  'a b',
  '..',
  'zß水🙂',
]);

/**
 * The group a path segment names, or nothing.
 *
 * `{ ok: false }` means the segment names NO group — never "the group with no
 * template". That distinction is the point: falling through to another group is
 * how a page came to show the wrong rows with confidence.
 */
function decodeGroupId(segment) {
  if (typeof segment !== 'string' || segment.length > MAX_GROUP_ID_CHARS) return { ok: false };
  if (segment === NO_TEMPLATE_GROUP) return { ok: true, templateId: null };
  if (!segment.startsWith(TEMPLATE_GROUP_PREFIX)) return { ok: false };
  const payload = segment.slice(TEMPLATE_GROUP_PREFIX.length);
  try {
    // An empty payload is a real answer: a run may carry the empty string as its
    // template id, and that group is listed by the first level like any other.
    return { ok: true, templateId: decodeURIComponent(payload) };
  } catch {
    // Not valid percent-encoding, so no link this application draws produced it.
    return { ok: false };
  }
}

module.exports = {
  NO_TEMPLATE_GROUP,
  TEMPLATE_GROUP_PREFIX,
  MAX_GROUP_ID_CHARS,
  GROUP_ID_PARITY_TEMPLATE_IDS,
  decodeGroupId,
};
