/**
 * blueprint-export — JSON export + import for a single blueprint and its
 * dependent rows.
 *
 * Export shape (import_version: 1):
 *   {
 *     import_version: 1,
 *     hierarchy_node:    {...},                 // the blueprint node only
 *     blueprint_fields:  [{...}, ...],
 *     field_options:     [{...}, ...],
 *     blueprint_sections:[{...}, ...],
 *     blueprint_output_order: [{...}, ...],
 *     _extensions:       {}                     // future-safe, ignored
 *   }
 *
 * Import always generates new UUIDs — never UPSERT, never overwrite.
 * Two requests of the same JSON create two independent copies.
 *
 * `?dry_run=true` validates semantics (unique keys, ref existence) and
 * returns a summary without inserting; `?dry_run=false` (or omitted)
 * applies the inserts in a single transaction.
 *
 * Mounted under /edge/app/schema (so the existing /api/schema proxy in
 * forwarding.js covers /api/schema/export/* and /api/schema/import/*).
 */
const express = require('express');
const router = express.Router();

const { TABLES } = require('../../../shared/constants');
const { pool, t, getDynamicPool } = require('../../db');
const { buildPortableInsert } = require('../../lib/portable-insert');
const { BLUEPRINT_FIELDS_JSON_COLUMNS } = require('../../lib/blueprint-fields-json-columns');
const { tableExistsInCurrentSchema } = require('../../lib/table-exists');
const { buildExportFilename, contentDispositionAttachment } = require('../../../shared/lib/export-filename');
const { apiOk, apiError, requireAdmin, requireAdminOrEditor, uuidv4 } = require('../../../shared/helpers');
const { logger: rootLogger } = require('../../../shared/lib/logger');
const {
  serializeYaml,
  parseYaml,
  computeRevision,
  computeDiff,
  summariseDiff,
  findIdentityMatches,
  loadRawExport,
  selectBlueprintGroups,
  insertAuditRow,
  overwriteBlueprint,
  validateBlueprintParent,
  MAX_YAML_BYTES,
} = require('../../lib/blueprint-serialization');
const { checkImportedBlueprintFields } = require('../../lib/blueprint-field-import-guard');
const { duplicateFieldKeyRefusal } = require('./schema/field-key');
const logger = rootLogger.child({ module: 'blueprint-export' });

const IMPORT_VERSION = 1;

// Coerce an untrusted free-form value to a bound-safe string-or-null. Section
// icon/description arrive verbatim from a JSON payload, so a crafted object or
// number must not bind as-is (would persist [object Object] / wrong type). The
// YAML path applies the same coercion inline in parseYaml.
const asStringOrNull = (v) => (typeof v === 'string' ? v : null);

const yamlBodyParser = express.text({
  type: ['text/yaml', 'application/x-yaml', 'text/plain', 'application/yaml'],
  limit: `${MAX_YAML_BYTES}b`,
});

function currentUserId(req) {
  // lint-allow: write-path-shapes this helper's value reaches an audit line
  // and a log field. Folding the three sources into one derivation is the same change as
  // the other ten sites and is deferred with them.
  return req.user?.id || req.user?.sub || req.session?.user?.id || null;
}

router.get('/blueprint-export/:id', async (req, res) => {
  if (!requireAdminOrEditor(req, res)) return;
  const dynamicDb = req.body && req.body.db;
  let conn;
  try {
    if (dynamicDb) {
      const dynamicPool = await getDynamicPool(dynamicDb);
      conn = await dynamicPool.ro.getConnection();
    } else {
      conn = await pool.ro.getConnection();
    }

    const [node] = await conn.query(
      `SELECT * FROM \`${t(TABLES.HIERARCHY_NODES)}\` WHERE id = ? AND node_type = 'blueprint'`,
      [req.params.id],
    );
    if (!node) {
      const e = apiError('Blueprint not found', 'NOT_FOUND', 404);
      return res.status(e.status).json(e.body);
    }

    const fields = await conn.query(
      `SELECT * FROM \`${t(TABLES.BLUEPRINT_FIELDS)}\` WHERE blueprint_id = ?`,
      [req.params.id],
    );
    const fieldIds = fields.map((f) => f.id);
    const options = fieldIds.length
      ? await conn.query(
          `SELECT * FROM \`${t(TABLES.FIELD_OPTIONS)}\`
           WHERE field_id IN (${fieldIds.map(() => '?').join(', ')})`,
          fieldIds,
        )
      : [];
    const sections = await conn.query(
      `SELECT * FROM \`${t(TABLES.BLUEPRINT_SECTIONS)}\` WHERE blueprint_id = ?`,
      [req.params.id],
    );
    // Tolerant of a pre-migration target lacking the additive blueprint_groups
    // table (returns [] on ER_NO_SUCH_TABLE); mirrors the YAML export path.
    const groups = await selectBlueprintGroups({ conn, t, TABLES, blueprintId: req.params.id });
    const outputOrder = await conn.query(
      `SELECT * FROM \`${t(TABLES.BLUEPRINT_OUTPUT_ORDER)}\` WHERE blueprint_id = ?`,
      [req.params.id],
    );

    res.json(apiOk({
      import_version: IMPORT_VERSION,
      hierarchy_node: node,
      blueprint_fields: fields,
      field_options: options,
      blueprint_sections: sections,
      blueprint_groups: groups,
      blueprint_output_order: outputOrder,
      _extensions: {},
    }));
  } catch (err) {
    logger.error({ err, blueprintId: req.params.id }, 'Failed to export blueprint');
    const e = apiError('Database operation failed', 'INTERNAL_ERROR');
    res.status(e.status).json(e.body);
  } finally {
    if (conn) conn.release();
  }
});

function invalidParentMessage(check) {
  switch (check.code) {
    case 'PARENT_REQUIRED':
      return 'target_parent_id query parameter is required (must be a Release node id)';
    case 'PARENT_NOT_FOUND':
      return 'target_parent_id does not match any hierarchy node';
    case 'PARENT_NOT_RELEASE':
      return `target_parent_id must point to a Release; got node_type='${check.actual_type}'`;
    default:
      return 'target_parent_id is invalid';
  }
}

/**
 * Run a validator that is expected to RETURN its rejections, from a position
 * where a throw would not be caught.
 *
 * WHY: both import routes validate before they open their transaction, which
 * puts that call outside the route's own try/catch. Express does not catch a
 * rejection from an async handler, so a validator that throws does not become a
 * 500 — the rejection goes unhandled and the process exits, turning one small
 * authenticated request into an outage while the client waits for a response
 * that never comes. The validators are guarded against today's malformed
 * payloads; this makes the route survive the ones nobody has thought of yet.
 *
 * @returns {{ ok: true, value: T } | { ok: false }} when ok is false the
 *   response has already been sent and the caller must return.
 * @template T
 */
function runValidation(res, logMessage, validate) {
  try {
    return { ok: true, value: validate() };
  } catch (err) {
    logger.error({ err }, logMessage);
    const e = apiError('Import failed', 'INTERNAL_ERROR');
    res.status(e.status).json(e.body);
    return { ok: false };
  }
}

function validatePayload(payload) {
  const errors = [];
  if (!payload || typeof payload !== 'object') {
    return ['Body must be an object'];
  }
  if (typeof payload.import_version !== 'number') {
    errors.push('Missing or non-numeric import_version');
  } else if (payload.import_version > IMPORT_VERSION) {
    errors.push(`import_version ${payload.import_version} is newer than this server (${IMPORT_VERSION})`);
  }
  if (!payload.hierarchy_node || typeof payload.hierarchy_node !== 'object') {
    errors.push('hierarchy_node missing');
  }
  for (const key of ['blueprint_fields', 'field_options', 'blueprint_sections', 'blueprint_output_order']) {
    if (!Array.isArray(payload[key])) errors.push(`${key} must be an array`);
  }
  // blueprint_groups is additive (color-group feature). A pre-feature export
  // lacks the key, so tolerate its absence; a present-but-non-array is a hard
  // error (mirrors the YAML strict-collection contract) so a typo can't
  // silently drop every group on a round-trip.
  if (payload.blueprint_groups !== undefined && !Array.isArray(payload.blueprint_groups)) {
    errors.push('blueprint_groups must be an array');
  }
  if (errors.length) return errors;

  // Row shape before row content: every check below reads properties off the
  // rows, and an uploaded collection can hold null or a scalar where a row
  // belongs. Reading through one is a throw, not the error list the caller
  // expects, so the shape is settled first and separately.
  for (const key of ['blueprint_fields', 'field_options', 'blueprint_sections', 'blueprint_output_order', 'blueprint_groups']) {
    const rows = payload[key];
    if (!Array.isArray(rows)) continue; // blueprint_groups is optional; the rest are checked above
    rows.forEach((row, i) => {
      if (!row || typeof row !== 'object' || Array.isArray(row)) errors.push(`${key}[${i}] must be an object`);
    });
  }
  if (errors.length) return errors;

  // Semantic validation (autoplan A8) — unique keys + ref existence.
  const fieldIdSet = new Set(payload.blueprint_fields.map((f) => f.id));
  const fieldKeys = new Set();
  for (const f of payload.blueprint_fields) {
    if (fieldKeys.has(f.field_key)) errors.push(`Duplicate field_key: ${f.field_key}`);
    fieldKeys.add(f.field_key);
  }
  const sectionKeys = new Set();
  for (const s of payload.blueprint_sections) {
    if (sectionKeys.has(s.section_key)) errors.push(`Duplicate section_key: ${s.section_key}`);
    sectionKeys.add(s.section_key);
  }
  const orderKeys = new Set();
  for (const o of payload.blueprint_output_order) {
    if (orderKeys.has(o.output_key)) errors.push(`Duplicate output_key: ${o.output_key}`);
    orderKeys.add(o.output_key);
  }
  const groupKeys = new Set();
  for (const g of payload.blueprint_groups || []) {
    if (groupKeys.has(g.group_key)) errors.push(`Duplicate group_key: ${g.group_key}`);
    groupKeys.add(g.group_key);
  }
  for (const o of payload.field_options) {
    if (!fieldIdSet.has(o.field_id)) {
      errors.push(`field_options entry references missing field_id ${o.field_id}`);
    }
  }
  // Business rules on the field columns themselves. The INSERT is built from the
  // payload's own keys, so a column with rules behind it — a compute rule, a
  // lock flag — is written verbatim unless it is judged here.
  errors.push(...checkImportedBlueprintFields(payload.blueprint_fields).errors);
  return errors;
}

router.post('/blueprint-import', async (req, res) => {
  if (!requireAdminOrEditor(req, res)) return;
  const payload = req.body || {};
  const dryRun = req.query.dry_run === 'true' || req.query.dry_run === '1';
  // NOTE: file payload's parent_id is a HINT only. The authoritative target
  // parent comes from ?target_parent_id=, validated server-side as a real
  // Release node. This prevents orphan blueprints when the imported file
  // references a non-existent or wrong-type parent (eg cross-environment import).
  const targetParentId = req.query.target_parent_id || null;

  const validated = runValidation(res, 'Failed to validate blueprint import payload', () => validatePayload(payload));
  if (!validated.ok) return;
  const errors = validated.value;
  if (errors.length) {
    const e = apiError('Validation failed', 'BAD_REQUEST', 400);
    return res.status(e.status).json({ ...e.body, validation_errors: errors });
  }

  // Additive + backward-compatible: a pre-feature export omits blueprint_groups.
  const importGroups = Array.isArray(payload.blueprint_groups) ? payload.blueprint_groups : [];

  const summary = {
    hierarchy_node: 1,
    blueprint_fields: payload.blueprint_fields.length,
    field_options: payload.field_options.length,
    blueprint_sections: payload.blueprint_sections.length,
    blueprint_groups: importGroups.length,
    blueprint_output_order: payload.blueprint_output_order.length,
  };

  // Apply: generate new UUIDs everywhere; map old→new for foreign-key refs.
  const dynamicDb = req.body && req.body.db;
  let conn;
  try {
    if (dynamicDb) {
      const dynamicPool = await getDynamicPool(dynamicDb);
      conn = await dynamicPool.rw.getConnection();
    } else {
      conn = await pool.rw.getConnection();
    }

    if (dryRun) {
      // Dry-run validates payload shape only. target_parent_id is enforced
      // on the actual create branch — frontend picks parent then submits.
      return res.json(apiOk({
        ok: true,
        dry_run: true,
        summary,
        validation_errors: [],
      }));
    }

    const parentCheck = await validateBlueprintParent({ conn, t, TABLES, parentId: targetParentId });
    if (!parentCheck.ok) {
      const e = apiError(invalidParentMessage(parentCheck), 'INVALID_TARGET_PARENT', 400);
      return res.status(e.status).json({ ...e.body, parent_check: parentCheck });
    }
    await conn.beginTransaction();

    const newBlueprintId = uuidv4();
    const fieldIdMap = new Map();
    for (const f of payload.blueprint_fields) {
      fieldIdMap.set(f.id, uuidv4());
    }

    // hierarchy_node — copy with new id, force parent_id=targetParentId,
    // force node_type='blueprint' (ignore file's stale/wrong parent).
    const node = payload.hierarchy_node;
    // B4: a linked_blueprint_id is a UUID into the SOURCE environment; it is
    // meaningless here and would dangle. Drop it on import and warn the
    // operator to re-set the link manually.
    const droppedLink = node.linked_blueprint_id ?? null;
    await conn.query(
      `INSERT INTO \`${t(TABLES.HIERARCHY_NODES)}\`
       (id, parent_id, name, description, node_type, sort_order, is_active,
        transformer_id, transformer_version, linked_blueprint_id)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        newBlueprintId,
        targetParentId,
        `${node.name ?? ''} (imported)`,
        node.description ?? null,
        'blueprint',
        node.sort_order ?? 0,
        node.is_active === false ? 0 : 1,
        node.transformer_id ?? null,
        node.transformer_version ?? null,
        null,
      ],
    );

    for (const f of payload.blueprint_fields) {
      const ins = await buildPortableInsert(conn, t(TABLES.BLUEPRINT_FIELDS), f, {
        remap: { id: fieldIdMap.get(f.id), blueprint_id: newBlueprintId },
        exclude: ['created_at'],
        jsonColumns: BLUEPRINT_FIELDS_JSON_COLUMNS,
        defaults: { section: 'general', default_value: '', placeholder: '', tooltip: '', is_required: 0, order_index: null },
      });
      if (ins) {
        await conn.query(ins.sql, ins.params);
      } else {
        // Fallback: schema probe unavailable — keep the prior explicit INSERT so
        // an import never silently no-ops a row. choice_config is DELIBERATELY
        // omitted here: it is an additive column and this branch cannot verify
        // it exists, so naming it would risk ER_BAD_FIELD_ERROR on a
        // pre-migration DB. A checkbox imported through this rare fallback loses
        // its limits (a NULL choice_config) rather than crashing the import; the
        // gated buildPortableInsert path above carries it whenever the probe works.
        await conn.query(
          `INSERT INTO \`${t(TABLES.BLUEPRINT_FIELDS)}\`
           (id, blueprint_id, field_key, field_label, field_type, is_required,
            default_value, placeholder, tooltip, section, order_index,
            table_config, visibility_rule)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            fieldIdMap.get(f.id),
            newBlueprintId,
            f.field_key,
            f.field_label,
            f.field_type,
            f.is_required ? 1 : 0,
            f.default_value ?? '',
            f.placeholder ?? '',
            f.tooltip ?? '',
            f.section ?? 'general',
            f.order_index ?? null,
            typeof f.table_config === 'string' ? f.table_config : JSON.stringify(f.table_config ?? null),
            typeof f.visibility_rule === 'string' ? f.visibility_rule : JSON.stringify(f.visibility_rule ?? null),
          ],
        );
      }
    }

    for (const o of payload.field_options) {
      const ins = await buildPortableInsert(conn, t(TABLES.FIELD_OPTIONS), o, {
        remap: { id: uuidv4(), field_id: fieldIdMap.get(o.field_id) },
        exclude: ['created_at'],
        jsonColumns: ['valid_parent_values'],
      });
      if (ins) {
        await conn.query(ins.sql, ins.params);
      } else {
        // Fallback: schema probe unavailable — keep the prior explicit INSERT so
        // an import never silently no-ops a row.
        await conn.query(
          `INSERT INTO \`${t(TABLES.FIELD_OPTIONS)}\`
           (id, field_id, option_label, option_value, sort_order)
           VALUES (?, ?, ?, ?, ?)`,
          [
            uuidv4(),
            fieldIdMap.get(o.field_id),
            o.option_label,
            o.option_value,
            o.sort_order ?? null,
          ],
        );
      }
    }

    for (const s of payload.blueprint_sections) {
      // JSON payloads are untrusted free-form: coerce icon/description/layout_mode/
      // matrix_copy to string-or-null so a crafted object/number never binds verbatim.
      const sectionRow = { ...s, icon: asStringOrNull(s.icon), description: asStringOrNull(s.description), layout_mode: asStringOrNull(s.layout_mode), matrix_copy: asStringOrNull(s.matrix_copy) };
      const ins = await buildPortableInsert(conn, t(TABLES.BLUEPRINT_SECTIONS), sectionRow, {
        remap: { id: uuidv4(), blueprint_id: newBlueprintId },
        exclude: ['created_at'],
        defaults: { display_label: s.display_label ?? '', sort_order: s.sort_order ?? null },
      });
      if (ins) {
        await conn.query(ins.sql, ins.params);
      } else {
        // Fallback: schema probe unavailable — keep the prior explicit INSERT so
        // an import never silently no-ops a row. icon/description are absent here
        // because an un-probable schema may pre-date those columns anyway.
        await conn.query(
          `INSERT INTO \`${t(TABLES.BLUEPRINT_SECTIONS)}\`
           (id, blueprint_id, section_key, display_label, sort_order)
           VALUES (?, ?, ?, ?, ?)`,
          [
            uuidv4(),
            newBlueprintId,
            s.section_key,
            s.display_label,
            s.sort_order ?? null,
          ],
        );
      }
    }

    // Groups: additive engine table. Only probe/insert when the payload carries
    // groups, and skip entirely if the target predates the table (tolerant, like
    // the fallback branches that drop unverifiable columns rather than 1146).
    if (importGroups.length && await tableExistsInCurrentSchema(conn, t(TABLES.BLUEPRINT_GROUPS))) {
      for (const g of importGroups) {
        // Untrusted free-form: coerce display_label/color_key to string-or-null so
        // a crafted object/number never binds verbatim (mirrors section handling).
        const groupRow = { ...g, display_label: asStringOrNull(g.display_label), color_key: asStringOrNull(g.color_key) };
        const ins = await buildPortableInsert(conn, t(TABLES.BLUEPRINT_GROUPS), groupRow, {
          remap: { id: uuidv4(), blueprint_id: newBlueprintId },
          exclude: ['created_at'],
          defaults: { display_label: '', color_key: null, sort_order: g.sort_order ?? null },
        });
        if (ins) {
          await conn.query(ins.sql, ins.params);
        } else {
          // Fallback: schema probe unavailable — explicit INSERT so an import
          // never silently no-ops a row. group_key is plain VARCHAR (no jsonColumns).
          await conn.query(
            `INSERT INTO \`${t(TABLES.BLUEPRINT_GROUPS)}\`
             (id, blueprint_id, group_key, display_label, color_key, sort_order)
             VALUES (?, ?, ?, ?, ?, ?)`,
            [
              uuidv4(),
              newBlueprintId,
              g.group_key,
              asStringOrNull(g.display_label),
              asStringOrNull(g.color_key),
              g.sort_order ?? null,
            ],
          );
        }
      }
    }

    for (const o of payload.blueprint_output_order) {
      // fmb-1723: format is a warn-severity add-column (degraded-schema
      // family, fmb-1645) — buildPortableInsert probes and drops it when the
      // target predates the migration, instead of a raw INSERT that would
      // fail on a database that has not migrated yet.
      // probe-exempt: buildPortableInsert (portable-insert.js) probes
      // information_schema for the table's actual columns and omits `format`
      // from the fallback branch's literal INSERT text when it is absent —
      // this file has no OTHER call naming a recognised probe token itself.
      const outputRow = { output_key: o.output_key, sort_order: o.sort_order ?? 0, format: o.format === 'table' ? 'table' : 'json' };
      const ins = await buildPortableInsert(conn, t(TABLES.BLUEPRINT_OUTPUT_ORDER), outputRow, {
        remap: { id: uuidv4(), blueprint_id: newBlueprintId },
        exclude: ['created_at'],
      });
      if (ins) {
        await conn.query(ins.sql, ins.params);
      } else {
        // Fallback: schema probe unavailable — explicit INSERT so an import
        // never silently no-ops a row. `format` stays out of this literal:
        // the probe already failed, so we cannot tell whether the target has
        // the column, and the DDL default ('json') covers the pre-migration
        // shape either way.
        await conn.query(
          `INSERT INTO \`${t(TABLES.BLUEPRINT_OUTPUT_ORDER)}\`
           (id, blueprint_id, output_key, sort_order)
           VALUES (?, ?, ?, ?)`,
          [uuidv4(), newBlueprintId, outputRow.output_key, outputRow.sort_order],
        );
      }
    }

    await conn.commit();
    const warnings = droppedLink
      ? ['This blueprint was linked to another blueprint on export; the link was cleared on import. Re-set it manually in the Hierarchy Manager.']
      : [];
    res.json(apiOk({
      ok: true,
      dry_run: false,
      summary,
      new_blueprint_id: newBlueprintId,
      warnings,
    }));
  } catch (err) {
    if (conn) {
      try { await conn.rollback(); } catch (rbErr) {
        logger.warn({ err: rbErr }, 'rollback after import failed');
      }
    }
    // A duplicate the field-key index refused is a statement about the PAYLOAD,
    // and both endpoints that write this key already answer 409 for it. Reported
    // as a server fault, the operator is told to retry something that can never
    // succeed.
    const duplicate = duplicateFieldKeyRefusal(err);
    if (duplicate) {
      const dup = apiError(duplicate.message, duplicate.code, duplicate.status);
      return res.status(dup.status).json(dup.body);
    }
    logger.error({ err }, 'Failed to import blueprint');
    const e = apiError('Import failed', 'INTERNAL_ERROR');
    res.status(e.status).json(e.body);
  } finally {
    if (conn) conn.release();
  }
});

// ── YAML round-trip ────────────────────────────────────────────────────

router.get('/blueprint-export-yaml/:id', async (req, res) => {
  if (!requireAdminOrEditor(req, res)) return;
  const dynamicDb = req.body && req.body.db;
  let conn;
  try {
    if (dynamicDb) {
      const dynamicPool = await getDynamicPool(dynamicDb);
      conn = await dynamicPool.ro.getConnection();
    } else {
      conn = await pool.ro.getConnection();
    }
    const raw = await loadRawExport({ conn, t, TABLES, blueprintId: req.params.id });
    if (!raw) {
      const e = apiError('Blueprint not found', 'NOT_FOUND', 404);
      return res.status(e.status).json(e.body);
    }
    const yamlBody = serializeYaml(raw);
    res.setHeader('Content-Type', 'text/yaml; charset=utf-8');
    // INVARIANT: HTTP header values are ASCII only. Blueprint names like
    // "桃園廠 base mold" would crash Node with "Invalid character in header
    // content" if embedded raw. contentDispositionAttachment emits an ASCII
    // fallback plus RFC 5987 filename* for the original.
    const rawName = String(raw.hierarchy_node.name || raw.hierarchy_node.id || 'export');
    const canonical = buildExportFilename({ kind: 'blueprint', entity: rawName, ext: 'yaml' });
    res.setHeader('Content-Disposition', contentDispositionAttachment(canonical));
    res.send(yamlBody);
  } catch (err) {
    logger.error({ err, blueprintId: req.params.id }, 'Failed to export blueprint YAML');
    const e = apiError('Database operation failed', 'INTERNAL_ERROR');
    res.status(e.status).json(e.body);
  } finally {
    if (conn) conn.release();
  }
});

router.post('/blueprint-import-yaml', yamlBodyParser, async (req, res) => {
  if (!requireAdminOrEditor(req, res)) return;
  const dryRun = req.query.dry_run === 'true' || req.query.dry_run === '1';
  const mode = req.query.mode || 'ask';
  const targetId = req.query.target_id || null;
  const expectedRevision = req.query.expected_revision || null;
  // NOTE: only mode=new uses target_parent_id (overwrite path uses target_id
  // which already locates the existing parent). UI always sends it for
  // symmetry; server only enforces it on the new path.
  const targetParentId = req.query.target_parent_id || null;
  const userId = currentUserId(req);

  if (typeof req.body !== 'string') {
    const e = apiError('YAML body must be sent as text/yaml', 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }

  let payload;
  try {
    payload = parseYaml(req.body);
  } catch (err) {
    const status = err.status || 400;
    const code = err.code || 'BAD_REQUEST';
    return res.status(status).json({
      ok: false,
      error: { message: err.message, code },
      validation_errors: [err.message],
    });
  }

  // Same field-column business rules the JSON path applies, before either branch
  // (mode=new or mode=overwrite) can write. Judged on the parsed payload, so a
  // future release that carries policy columns through the YAML shape is covered
  // by construction rather than by remembering to add a check here.
  const checked = runValidation(
    res,
    'Failed to validate blueprint YAML import fields',
    () => checkImportedBlueprintFields(payload.blueprint_fields).errors,
  );
  if (!checked.ok) return;
  const fieldErrors = checked.value;
  if (fieldErrors.length) {
    const e = apiError('Validation failed', 'BAD_REQUEST', 400);
    return res.status(e.status).json({ ...e.body, validation_errors: fieldErrors });
  }

  let conn;
  try {
    // Use a RW connection even for dry_run so identity match + diff
    // hit the same snapshot the eventual overwrite will use.
    conn = await pool.rw.getConnection();

    const candidates = await findIdentityMatches({ conn, t, TABLES, payload });
    let summary = null;
    let revision = null;
    if (candidates.length && (mode === 'ask' || mode === 'overwrite')) {
      const candidateId = mode === 'overwrite' && targetId ? targetId : candidates[0].id;
      const currentRaw = await loadRawExport({ conn, t, TABLES, blueprintId: candidateId });
      if (currentRaw) {
        summary = summariseDiff(computeDiff(currentRaw, payload));
        revision = computeRevision(currentRaw);
      }
    }

    if (dryRun) {
      return res.json(apiOk({
        ok: true,
        dry_run: true,
        mode,
        candidates,
        summary,
        revision,
        validation_errors: [],
      }));
    }

    // Live import — branch by mode.
    if (mode === 'overwrite') {
      if (!targetId) {
        const e = apiError('mode=overwrite requires target_id', 'BAD_REQUEST', 400);
        return res.status(e.status).json(e.body);
      }
      await conn.beginTransaction();
      try {
        const result = await overwriteBlueprint({
          conn, t, TABLES, uuidv4,
          existingId: targetId,
          payload,
          userId,
          userRole: req.user?.role,
          expectedRevision,
        });
        await conn.commit();
        return res.json(apiOk({ ok: true, dry_run: false, mode, ...result }));
      } catch (err) {
        try { await conn.rollback(); } catch (rbErr) {
          logger.warn({ err: rbErr }, 'rollback after overwrite failed');
        }
        if (err.code === 'REVISION_REQUIRED') {
          return res.status(400).json({
            ok: false,
            error: { message: err.message, code: 'REVISION_REQUIRED' },
            details: err.details,
          });
        }
        if (err.code === 'STALE_REVISION') {
          // Audit the failure outside the rolled-back TX.
          try {
            await insertAuditRow({
              conn, t, TABLES,
              eventType: 'blueprint.overwrite.fail',
              userId,
              metadata: { blueprint_id: targetId, reason: 'stale_revision' },
            });
          } catch (aerr) {
            logger.warn({ err: aerr }, 'failed to write stale-revision audit');
          }
          return res.status(409).json({
            ok: false,
            error: { message: 'Blueprint changed since dry-run', code: 'STALE_REVISION' },
            details: err.details,
          });
        }
        if (err.code === 'NOT_FOUND') {
          return res.status(404).json(apiError(err.message, 'NOT_FOUND', 404).body);
        }
        if (err.code === 'FORBIDDEN') {
          return res.status(403).json(apiError(err.message, 'FORBIDDEN', 403).body);
        }
        if (err.code === 'LINKED_BLUEPRINT_READONLY') {
          return res.status(409).json(apiError(err.message, 'LINKED_BLUEPRINT_READONLY', 409).body);
        }
        if (err.code === 'INVALID_COMPUTE_RULE') {
          const e = apiError(err.message, 'BAD_REQUEST', 400);
          return res.status(e.status).json({
            ...e.body,
            validation_errors: (err.details && err.details.errors) || [err.message],
          });
        }
        try {
          await insertAuditRow({
            conn, t, TABLES,
            eventType: 'blueprint.overwrite.fail',
            userId,
            metadata: { blueprint_id: targetId, reason: err.code || 'unknown' },
          });
        } catch (aerr) {
          logger.warn({ err: aerr }, 'failed to write fail audit');
        }
        throw err;
      }
    }

    // mode=new (or default): always-create path (same contract as JSON import).
    // Validate target_parent_id before opening the TX so failure surfaces as
    // 400 without a rollback churn.
    const parentCheck = await validateBlueprintParent({ conn, t, TABLES, parentId: targetParentId });
    if (!parentCheck.ok) {
      const e = apiError(invalidParentMessage(parentCheck), 'INVALID_TARGET_PARENT', 400);
      return res.status(e.status).json({ ...e.body, parent_check: parentCheck });
    }
    await conn.beginTransaction();
    try {
      const newBlueprintId = uuidv4();
      const fieldIdMap = new Map();
      for (const f of payload.blueprint_fields) {
        fieldIdMap.set(f.id, uuidv4());
      }
      const node = payload.hierarchy_node;
      // B4: drop the cross-env link (source UUID is meaningless here); warn below.
      const droppedLink = node.linked_blueprint_id ?? null;
      await conn.query(
        `INSERT INTO \`${t(TABLES.HIERARCHY_NODES)}\`
         (id, parent_id, name, description, node_type, sort_order, is_active,
          transformer_id, transformer_version, linked_blueprint_id)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          newBlueprintId,
          targetParentId,
          node.name,
          node.description ?? null,
          'blueprint',
          null,
          node.is_active === false ? 0 : 1,
          node.transformer_id ?? null,
          node.transformer_version ?? null,
          null,
        ],
      );
      for (const f of payload.blueprint_fields) {
        const ins = await buildPortableInsert(conn, t(TABLES.BLUEPRINT_FIELDS), f, {
          remap: { id: fieldIdMap.get(f.id), blueprint_id: newBlueprintId },
          exclude: ['created_at'],
          jsonColumns: BLUEPRINT_FIELDS_JSON_COLUMNS,
          defaults: { section: 'general', default_value: '', placeholder: '', tooltip: '', is_required: 0, order_index: null },
        });
        if (ins) {
          await conn.query(ins.sql, ins.params);
        } else {
          // Fallback: schema probe unavailable — keep the prior explicit INSERT
          // so an import never silently no-ops a row. choice_config is omitted
          // (additive column, unverifiable in this branch → avoid 1054).
          await conn.query(
            `INSERT INTO \`${t(TABLES.BLUEPRINT_FIELDS)}\`
             (id, blueprint_id, field_key, field_label, field_type, is_required,
              default_value, placeholder, tooltip, section, order_index,
              table_config, visibility_rule)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [
              fieldIdMap.get(f.id),
              newBlueprintId,
              f.field_key,
              f.field_label,
              f.field_type,
              f.is_required ? 1 : 0,
              f.default_value ?? '',
              f.placeholder ?? '',
              f.tooltip ?? '',
              f.section ?? 'general',
              f.order_index ?? null,
              typeof f.table_config === 'string' ? f.table_config : (f.table_config != null ? JSON.stringify(f.table_config) : null),
              typeof f.visibility_rule === 'string' ? f.visibility_rule : (f.visibility_rule != null ? JSON.stringify(f.visibility_rule) : null),
            ],
          );
        }
      }
      for (const o of payload.field_options) {
        const ins = await buildPortableInsert(conn, t(TABLES.FIELD_OPTIONS), o, {
          remap: { id: uuidv4(), field_id: fieldIdMap.get(o.field_id) },
          exclude: ['created_at'],
          jsonColumns: ['valid_parent_values'],
        });
        if (ins) {
          await conn.query(ins.sql, ins.params);
        } else {
          // Fallback: schema probe unavailable — keep the prior explicit INSERT
          // so an import never silently no-ops a row.
          await conn.query(
            `INSERT INTO \`${t(TABLES.FIELD_OPTIONS)}\`
             (id, field_id, option_label, option_value, sort_order)
             VALUES (?, ?, ?, ?, ?)`,
            [uuidv4(), fieldIdMap.get(o.field_id), o.option_label, o.option_value, o.sort_order ?? null],
          );
        }
      }
      for (const s of payload.blueprint_sections) {
        // parseYaml already coerces icon/description/layout_mode/matrix_copy; apply
        // the same normalizer here so both import paths share one bound-safe contract.
        const sectionRow = { ...s, icon: asStringOrNull(s.icon), description: asStringOrNull(s.description), layout_mode: asStringOrNull(s.layout_mode), matrix_copy: asStringOrNull(s.matrix_copy) };
        const ins = await buildPortableInsert(conn, t(TABLES.BLUEPRINT_SECTIONS), sectionRow, {
          remap: { id: uuidv4(), blueprint_id: newBlueprintId },
          exclude: ['created_at'],
          defaults: { display_label: s.display_label ?? '', sort_order: s.sort_order ?? null },
        });
        if (ins) {
          await conn.query(ins.sql, ins.params);
        } else {
          // Fallback: schema probe unavailable — keep the prior explicit INSERT
          // so an import never silently no-ops a row.
          await conn.query(
            `INSERT INTO \`${t(TABLES.BLUEPRINT_SECTIONS)}\`
             (id, blueprint_id, section_key, display_label, sort_order)
             VALUES (?, ?, ?, ?, ?)`,
            [uuidv4(), newBlueprintId, s.section_key, s.display_label, s.sort_order ?? null],
          );
        }
      }
      // Groups: additive engine table, gated on payload presence + table probe
      // (tolerant of a pre-migration target). payload rows come from parseYaml
      // (already coerced); apply the same normalizer for a shared bound-safe
      // contract with the JSON path.
      const yamlGroups = payload.blueprint_groups || [];
      if (yamlGroups.length && await tableExistsInCurrentSchema(conn, t(TABLES.BLUEPRINT_GROUPS))) {
        for (const g of yamlGroups) {
          const groupRow = { ...g, display_label: asStringOrNull(g.display_label), color_key: asStringOrNull(g.color_key) };
          const ins = await buildPortableInsert(conn, t(TABLES.BLUEPRINT_GROUPS), groupRow, {
            remap: { id: uuidv4(), blueprint_id: newBlueprintId },
            exclude: ['created_at'],
            defaults: { display_label: '', color_key: null, sort_order: g.sort_order ?? null },
          });
          if (ins) {
            await conn.query(ins.sql, ins.params);
          } else {
            // Fallback: schema probe unavailable — explicit INSERT so an import
            // never silently no-ops a row. group_key is plain VARCHAR (no jsonColumns).
            await conn.query(
              `INSERT INTO \`${t(TABLES.BLUEPRINT_GROUPS)}\`
               (id, blueprint_id, group_key, display_label, color_key, sort_order)
               VALUES (?, ?, ?, ?, ?, ?)`,
              [uuidv4(), newBlueprintId, g.group_key, asStringOrNull(g.display_label), asStringOrNull(g.color_key), g.sort_order ?? null],
            );
          }
        }
      }
      for (const o of payload.blueprint_output_order) {
        // fmb-1723: see the JSON-import site's comment above (same
        // degraded-schema-family probe, mirrored for the YAML path).
        const outputRow = { output_key: o.output_key, sort_order: o.sort_order ?? 0, format: o.format === 'table' ? 'table' : 'json' };
        const ins = await buildPortableInsert(conn, t(TABLES.BLUEPRINT_OUTPUT_ORDER), outputRow, {
          remap: { id: uuidv4(), blueprint_id: newBlueprintId },
          exclude: ['created_at'],
        });
        if (ins) {
          await conn.query(ins.sql, ins.params);
        } else {
          // Fallback: see the JSON-import site's comment above — `format`
          // stays out of the probe-unavailable literal for the same reason.
          await conn.query(
            `INSERT INTO \`${t(TABLES.BLUEPRINT_OUTPUT_ORDER)}\`
             (id, blueprint_id, output_key, sort_order)
             VALUES (?, ?, ?, ?)`,
            [uuidv4(), newBlueprintId, outputRow.output_key, outputRow.sort_order],
          );
        }
      }
      await insertAuditRow({
        conn, t, TABLES,
        eventType: 'blueprint.import_new',
        userId,
        metadata: {
          new_blueprint_id: newBlueprintId,
          source_name: node.name,
          linked_blueprint_cleared: !!droppedLink,
          counts: {
            fields: payload.blueprint_fields.length,
            options: payload.field_options.length,
            sections: payload.blueprint_sections.length,
            groups: yamlGroups.length,
            output_order: payload.blueprint_output_order.length,
          },
        },
      });
      await conn.commit();
      return res.json(apiOk({
        ok: true,
        dry_run: false,
        mode: 'new',
        new_blueprint_id: newBlueprintId,
        warnings: droppedLink
          ? ['This blueprint was linked to another blueprint on export; the link was cleared on import. Re-set it manually in the Hierarchy Manager.']
          : [],
        summary: {
          fields: payload.blueprint_fields.length,
          options: payload.field_options.length,
          sections: payload.blueprint_sections.length,
          groups: yamlGroups.length,
          output_order: payload.blueprint_output_order.length,
        },
      }));
    } catch (err) {
      try { await conn.rollback(); } catch (rbErr) {
        logger.warn({ err: rbErr }, 'rollback after import-new failed');
      }
      throw err;
    }
  } catch (err) {
    // Same mapping as the JSON import above, from the same module: this verb
    // reaches the same INSERTs through the same serializer.
    const duplicate = duplicateFieldKeyRefusal(err);
    if (duplicate) {
      const dup = apiError(duplicate.message, duplicate.code, duplicate.status);
      return res.status(dup.status).json(dup.body);
    }
    logger.error({ err }, 'Failed to import blueprint YAML');
    const e = apiError('Import failed', 'INTERNAL_ERROR');
    res.status(e.status).json(e.body);
  } finally {
    if (conn) conn.release();
  }
});

module.exports = router;
