'use strict';

/**
 * delegated-grants.js — granting and revoking delegated access.
 *
 *   GET    /?scope_type=&scope_id=  who currently holds access to one subject
 *   GET    /mine                    the subjects the CALLER may work on — the
 *                                   ones granted to them, and the blueprints
 *                                   they own, which reach every record under
 *                                   them without any grant existing
 *   GET    /people?q=               a bounded directory for the person picker
 *   POST   /                        grant one person access to one subject
 *   DELETE /:id                     revoke one grant
 *
 * WHO MAY GRANT: the subject's owner, and an administrator. Nobody else, and in
 * particular not a grantee — a grant conveys working on the record, never
 * handing that on. The check is ownership of the SUBJECT, so it is the same
 * check for a blueprint and for a single template, which is why one route
 * serves both.
 *
 * WHY A FOREIGN SUBJECT ANSWERS 404 RATHER THAN 403. The same reason the write
 * path does: "not yours" over an identifier confirms the subject exists. A
 * caller who owns nothing learns nothing here.
 *
 * THE PERSON PICKER IS ITS OWN ENDPOINT, and deliberately not the existing
 * assignable-users directory. That one is open to administrators and editors and
 * returns each person's ROLE, because it feeds ownership transfer. A grant can
 * be made by anyone who owns a record, including a plain user, so the picker
 * has to be readable by one — and a plain user has no business enumerating who
 * is an administrator. This returns identity and display name only, bounded,
 * and never an email address: the never-return-email rule applies here as
 * everywhere.
 */
const router = require('express').Router();
const { pool, t } = require('../../db');
const {
  apiOk, apiError, requireAuth, uuidv4, UUID_RE,
} = require('../../../shared/helpers');
const { TABLES } = require('../../../shared/constants');
const { mapRowsFromDb } = require('../../lib/dto-mapper');
const { attachOwnerNames, stripEmailDomain } = require('../../lib/owner-name-enrichment');
const { normalizeRows } = require('../../../shared/serializers/normalize-nullable');
const { escapeLikePattern } = require('../../lib/sql-like');
const { GRANT_SCOPES, grantsTableAvailable } = require('../../lib/delegated-grants');
const { resolveCanonicalUserId, sameStoredValue } = require('./schema/write-value');
const { logger: rootLogger } = require('../../../shared/lib/logger');

const logger = rootLogger.child({ module: 'delegated-grants' });

// SECURITY: authentication for the whole router rather than per handler, so a
// route added later inherits it instead of having to remember it.
router.use((req, res, next) => { if (requireAuth(req, res)) next(); });

/** How many people the picker returns at most. A directory read has to be
 *  bounded by something, and an unbounded one is the same defect as an unbounded
 *  list anywhere else. */
const MAX_PEOPLE = 200;

/** How many grants one subject may carry in a single response. Far above any
 *  plausible number of delegates; present so the response has a ceiling. */
const MAX_GRANTS = 500;

const dbError = (res) => {
  const e = apiError('Database operation failed', 'INTERNAL_ERROR', 500);
  res.status(e.status).json(e.body);
};

const notFound = (res) => {
  const e = apiError('Not found', 'NOT_FOUND', 404);
  res.status(e.status).json(e.body);
};

const badRequest = (res, message, code = 'BAD_REQUEST') => {
  const e = apiError(message, code, 400);
  res.status(e.status).json(e.body);
};

/**
 * A database whose operator account could not create the table has no grants.
 * Every read here answers empty and every write is refused with a cause the
 * operator can act on, rather than a 500 naming a missing table.
 */
async function requireGrantsTable(conn, res) {
  if (await grantsTableAvailable(conn)) return true;
  const e = apiError(
    'Delegated access is unavailable on this database: the grants table has not been created. '
    + 'An administrator can see the outstanding schema steps under schema status.',
    'GRANTS_UNAVAILABLE', 503,
  );
  res.status(e.status).json(e.body);
  return false;
}

// Which table holds the owner of each subject tier. One map rather than a
// branch per reader, so the ownership question and the ownership READ can never
// end up asking about different tables.
const SUBJECT_OWNER_TABLE = Object.freeze({
  blueprint: TABLES.HIERARCHY_NODES,
  template: TABLES.USER_TEMPLATES,
});

/**
 * Who owns the subject a request names.
 *
 * @returns {Promise<string|null|undefined>} the owner's id, `null` for a subject
 *   nobody owns, and `undefined` for one that does not exist or is the wrong
 *   tier. Three answers rather than two because the callers below need to tell
 *   "nobody owns it" from "there is no such thing", and they say different
 *   things about them.
 */
async function subjectOwnerId(conn, scopeType, scopeId) {
  if (scopeType === 'blueprint') {
    const rows = await conn.query(
      `SELECT owner_id FROM \`${t(SUBJECT_OWNER_TABLE.blueprint)}\`
        WHERE id = ? AND node_type = 'blueprint'`,
      [scopeId],
    );
    return rows.length > 0 ? rows[0].owner_id ?? null : undefined;
  }
  const rows = await conn.query(
    `SELECT owner_id FROM \`${t(SUBJECT_OWNER_TABLE.template)}\` WHERE id = ?`,
    [scopeId],
  );
  return rows.length > 0 ? rows[0].owner_id ?? null : undefined;
}

/**
 * May this caller grant and revoke over that subject?
 *
 * An administrator does not own it and does not need to — but the subject still
 * has to exist, or the grant would be a row over nothing that nobody could ever
 * see or revoke. For everyone else it is ownership, and a subject nobody owns
 * answers false: nobody can delegate a record nobody owns.
 *
 * OWNERSHIP IS ASKED OF THE COLUMN. `owner_id` is `CHAR(36)` under a
 * case-folding collation, so the enforcement side of delegated access — the
 * EXISTS predicate that decides whether a grant lets somebody work on a record —
 * resolves the owner for any spelling of their id. Compared byte-wise here, a
 * record whose column holds another spelling of the caller's id was theirs
 * everywhere except at the one gate that decides whether they may delegate it,
 * and they were answered 404 over their own record. This PR does not rewrite
 * such rows, so the reader answers for them.
 *
 * FAIL-CLOSED, in three places: a scope tier this route does not know has no
 * table to ask about and is refused; `sameStoredValue` answers `false` for an
 * operand it cannot ask the engine about; and a probe that throws leaves the
 * caller's own catch to refuse. None of the three admits a stranger.
 */
async function callerOwnsSubject(conn, scopeType, user, ownerId) {
  if (!user) return false;
  if (ownerId === undefined) return false;
  if (user.role === 'admin') return true;
  if (ownerId == null) return false;
  const table = SUBJECT_OWNER_TABLE[scopeType];
  if (!table) return false;
  // collation-compare: this is the same "does this column name the caller"
  // the grant-enforcement EXISTS asks, and it must not answer differently.
  return sameStoredValue(conn, t(table), 'owner_id', ownerId, user.id);
}

/** The subject a request names, or null when it is not one this route knows. */
function readSubject(source) {
  const scopeType = source && source.scope_type;
  const scopeId = source && source.scope_id;
  if (!GRANT_SCOPES.includes(scopeType)) return null;
  if (typeof scopeId !== 'string' || !UUID_RE.test(scopeId)) return null;
  return { scopeType, scopeId };
}

/**
 * @openapi
 * /api/delegated-grants:
 *   get:
 *     summary: Who holds delegated access to one subject
 *     tags: [App - Delegated Grants]
 *     parameters:
 *       - { name: scope_type, in: query, required: true, schema: { type: string, enum: [blueprint, template] } }
 *       - { name: scope_id, in: query, required: true, schema: { type: string } }
 *     responses:
 *       200: { description: Grant list }
 *       404: { description: Not the caller's subject, or no such subject }
 *   post:
 *     summary: Grant one person access to one subject
 *     tags: [App - Delegated Grants]
 *     responses:
 *       201: { description: Granted }
 *       404: { description: Not the caller's subject }
 */

// ── The caller's own access ─────────────────────────────────────────────────

/**
 * Which subjects the caller may work on, as two lists of identifiers.
 *
 * WHAT THIS IS FOR, and what it is emphatically not. The browser uses it to
 * decide whether to OFFER editing — a screen that hides its controls from
 * someone who may in fact write is as wrong as one that shows controls that
 * will fail. It is not a permission: every write is decided again in SQL at the
 * point of writing, and a caller who forged this response would gain nothing.
 */
router.get('/mine', async (req, res) => {
  let conn;
  try {
    conn = await pool.ro.getConnection();
    // The blueprints the caller OWNS come first and unconditionally: they reach
    // every record under them without any grant existing, and the hierarchy is
    // on every database, so this answer must not be lost on one whose operator
    // account could not create the grants table.
    const ownedRows = await conn.query(
      `SELECT id FROM \`${t(TABLES.HIERARCHY_NODES)}\`
        WHERE node_type = 'blueprint' AND owner_id = ?
        ORDER BY id LIMIT ?`,
      [req.user.id, MAX_GRANTS],
    );
    const ownedBlueprintIds = ownedRows.map((r) => r.id);
    if (!(await grantsTableAvailable(conn))) {
      return res.json(apiOk({
        blueprint_ids: [], template_ids: [], owned_blueprint_ids: ownedBlueprintIds,
      }));
    }
    const rows = await conn.query(
      `SELECT scope_type, scope_id FROM \`${t(TABLES.DELEGATED_GRANTS)}\`
        WHERE grantee_id = ? ORDER BY created_at DESC LIMIT ?`,
      [req.user.id, MAX_GRANTS],
    );
    return res.json(apiOk({
      blueprint_ids: rows.filter((r) => r.scope_type === 'blueprint').map((r) => r.scope_id),
      template_ids: rows.filter((r) => r.scope_type === 'template').map((r) => r.scope_id),
      // Kept apart from the granted list rather than merged into it: they are
      // different facts about the reader, and a screen that wants to say WHY a
      // control is offered cannot recover the difference once they are one list.
      owned_blueprint_ids: ownedBlueprintIds,
    }));
  } catch (err) {
    logger.error({ err }, 'Failed to read the caller\'s delegated grants');
    return dbError(res);
  } finally {
    if (conn) conn.release();
  }
});

// ── The person picker ───────────────────────────────────────────────────────

router.get('/people', async (req, res) => {
  const q = typeof req.query.q === 'string' ? req.query.q.trim().slice(0, 100) : '';
  let conn;
  try {
    conn = await pool.ro.getConnection();
    const params = [];
    let where = 'WHERE banned = 0';
    if (q) {
      // MATCHED ON WHAT IS SHOWN, which is the whole rule and the only one that
      // does not surprise somebody: the caller reads a name in the list, types
      // it, and finds that person. Both sides are the domain-stripped form, so
      // typing an address matches nothing and cannot be used to confirm one —
      // the never-return-email rule holds on the way in as well as out.
      where += ' AND (SUBSTRING_INDEX(display_name, \'@\', 1) LIKE ? ESCAPE \'|\''
        + ' OR SUBSTRING_INDEX(kc_username, \'@\', 1) LIKE ? ESCAPE \'|\')';
      const like = `%${escapeLikePattern(q)}%`;
      params.push(like, like);
    }
    // One row over the ceiling, so "there are more than these" is a fact rather
    // than a guess. A directory read has to be bounded by something, and a list
    // that silently stops is how a picker comes to say "no matching person"
    // about somebody who is standing right there.
    const rows = await conn.query(
      `SELECT id, display_name, kc_username FROM \`${t(TABLES.USERS)}\`
       ${where}
       ORDER BY COALESCE(NULLIF(display_name, ''), kc_username) IS NULL,
                COALESCE(NULLIF(display_name, ''), kc_username)
       LIMIT ?`,
      [...params, MAX_PEOPLE + 1],
    );
    const truncated = rows.length > MAX_PEOPLE;
    return res.json(apiOk({
      // SECURITY: resolved through the same helper every other surface uses, so
      // a display name that IS an address — which is exactly what the token
      // mapper leaves when no display name is mapped — arrives as its local
      // part and never as an address. Resolving it the same way is also what
      // stops one person being named one thing in the picker and another thing
      // in the row they end up in.
      people: rows.slice(0, MAX_PEOPLE).map((r) => ({
        id: r.id,
        display_name: stripEmailDomain(r.display_name || r.kc_username || '') || '',
      })),
      limit: MAX_PEOPLE,
      /** True when the directory has more people than were returned. The picker
       *  says so rather than letting the absent ones read as non-existent. */
      truncated,
    }));
  } catch (err) {
    logger.error({ err }, 'Failed to read the delegation person directory');
    return dbError(res);
  } finally {
    if (conn) conn.release();
  }
});

// ── One subject's grants ────────────────────────────────────────────────────

router.get('/', async (req, res) => {
  const subject = readSubject(req.query);
  if (!subject) return badRequest(res, 'A subject is required: scope_type and scope_id');

  let conn;
  try {
    conn = await pool.ro.getConnection();
    if (!(await requireGrantsTable(conn, res))) return undefined;
    const ownerId = await subjectOwnerId(conn, subject.scopeType, subject.scopeId);
    if (!(await callerOwnsSubject(conn, subject.scopeType, req.user, ownerId))) {
      return notFound(res);
    }
    const rows = await conn.query(
      `SELECT id, scope_type, scope_id, grantee_id, granted_by, created_at
         FROM \`${t(TABLES.DELEGATED_GRANTS)}\`
        WHERE scope_type = ? AND scope_id = ?
        ORDER BY created_at DESC
        LIMIT ?`,
      [subject.scopeType, subject.scopeId, MAX_GRANTS],
    );
    const mapped = mapRowsFromDb(TABLES.DELEGATED_GRANTS, rows);
    // Two people per row, resolved through the shared enrichment so neither can
    // arrive as an email address.
    await attachActorNames(conn, mapped, 'grantee_id', 'grantee');
    await attachActorNames(conn, mapped, 'granted_by', 'granter');
    return res.json(apiOk({
      grants: normalizeRows(mapped, ['granted_by']),
      total: mapped.length,
      limit: MAX_GRANTS,
    }));
  } catch (err) {
    logger.error({ err }, 'Failed to list the grants on a subject');
    return dbError(res);
  } finally {
    if (conn) conn.release();
  }
});

/** Rename the shared owner enrichment's output to the person it was run for. A
 *  grantee is not an owner, and leaving the field called `owner_name` on a row
 *  with no owner column invites a reader to act on it as one.
 *
 *  A `<prefix>_removed` flag rides along, because an account that has been
 *  deleted is a FACT the server knows and the screen cannot recover: the name
 *  it would otherwise get is a word, and a row that renders it as an ordinary
 *  person says something false about who has access. */
async function attachActorNames(conn, rows, column, prefix) {
  await attachOwnerNames(conn, rows, column, `\`${t(TABLES.USERS)}\``, { unresolved: null });
  for (const row of rows) {
    if (!row) continue;
    row[`${prefix}_removed`] = row[column] != null && row.owner_name == null;
    row[`${prefix}_name`] = row.owner_name ?? '';
    row[`${prefix}_username`] = row.owner_username ?? '';
    delete row.owner_name;
    delete row.owner_username;
  }
  return rows;
}

// ── Granting ────────────────────────────────────────────────────────────────

router.post('/', async (req, res) => {
  const subject = readSubject(req.body);
  if (!subject) return badRequest(res, 'A subject is required: scope_type and scope_id');
  const granteeId = req.body && req.body.grantee_id;
  if (typeof granteeId !== 'string' || !UUID_RE.test(granteeId)) {
    return badRequest(res, 'A person is required: grantee_id');
  }

  let conn;
  try {
    conn = await pool.rw.getConnection();
    if (!(await requireGrantsTable(conn, res))) return undefined;
    const ownerId = await subjectOwnerId(conn, subject.scopeType, subject.scopeId);
    if (!(await callerOwnsSubject(conn, subject.scopeType, req.user, ownerId))) {
      return notFound(res);
    }
    // A record nobody owns cannot be delegated, and that holds for an
    // administrator too — not as a restriction on them, but because no
    // enforcement point would honour the grant. Every arm of delegated access
    // requires the record to have an owner (see `lib/delegated-grants.js`), so
    // storing this would be storing a promise the screen would go on displaying
    // and nothing would ever keep. Said here, where it is being made, rather
    // than discovered later as a permission that does nothing.
    if (subject.scopeType === 'template' && ownerId == null) {
      return badRequest(
        res,
        'That record has no owner, so there is no access to delegate. Claim it first.',
        'UNOWNED_SUBJECT',
      );
    }
    // The person has to exist and be able to sign in. A grant to an account that
    // cannot is not harmful — nothing will ever match it — but it is a promise
    // the screen would go on displaying, so it is refused where it is made.
    //
    // collation-compare: which person a spelling names is the column's
    // question, and `users.id` folds case. `person.id` is the STORED spelling
    // and it is what the INSERT binds — the enforcement path reads this value
    // back through `WHERE grantee_id = ?` (which folds) while the screen and
    // the revoke list read it in JavaScript (which does not), so storing the
    // caller's spelling produces a grant that enforces for somebody the UI
    // cannot name.
    // EVERY REASON GETS ONE SENTENCE HERE, and that is this route's own choice
    // rather than an oversight — unlike an ownership transfer, a grant is made
    // TO somebody the caller names, so distinguishing "no such person" from
    // "that person is banned" would answer questions about accounts the caller
    // may know nothing about. The shared `ownerTargetRejection` map deliberately
    // does the opposite for the transfer routes, where the target is a user the
    // administrator is already looking at.
    //
    // Signing in is no longer asked separately. `resolveCanonicalUserId` refuses
    // a banned account itself, so the follow-up `WHERE id = ? AND banned = 0`
    // that used to sit here could only ever match — a guard whose refusal has
    // become unreachable, reading to the next person as if it were still the
    // thing keeping a banned grantee out.
    const person = await resolveCanonicalUserId(conn, t(TABLES.USERS), granteeId);
    if (!person.ok) {
      return person.reason === 'ambiguous'
        ? badRequest(res, 'That person cannot be granted access', 'AMBIGUOUS_GRANTEE')
        : badRequest(res, 'That person cannot be granted access', 'UNKNOWN_GRANTEE');
    }
    // Granting to yourself is refused rather than silently stored: it would
    // appear in the list as an access somebody could revoke, and revoking it
    // would take nothing away.
    //
    // collation-compare, and this one is a security boundary rather than a
    // tidiness rule. The invariant is the UNIQUE index `uq_delegated_grant`,
    // which folds case, so a refusal that compares any other way admits a row
    // the index considers the same grant. A self-grant that gets stored
    // OUTLIVES the ownership it was made under: hand the record on, and the
    // former owner still holds write and dispatch over a record they no longer
    // own. So the refusal is asked of the column the index is built on, not of
    // JavaScript — even though both operands are canonical by the line above,
    // because a guard that is only correct while its inputs happen to be
    // normalised is one refactor from being no guard.
    if (await sameStoredValue(conn, t(TABLES.DELEGATED_GRANTS), 'grantee_id', person.id, req.user.id)) {
      return badRequest(res, 'That person already has access', 'ALREADY_HAS_ACCESS');
    }
    const id = uuidv4();
    try {
      await conn.query(
        `INSERT INTO \`${t(TABLES.DELEGATED_GRANTS)}\`
           (id, scope_type, scope_id, grantee_id, granted_by) VALUES (?, ?, ?, ?, ?)`,
        [id, subject.scopeType, subject.scopeId, person.id, req.user.id],
      );
    } catch (err) {
      // The same person granted the same subject twice is one grant. A second
      // submission is answered as the success it effectively is rather than as
      // a fault, so a double-click does not produce an error the operator has to
      // interpret.
      if (err && (err.errno === 1062 || err.code === 'ER_DUP_ENTRY')) {
        return res.status(200).json(apiOk({ id: null, already_granted: true }));
      }
      throw err;
    }
    return res.status(201).json(apiOk({ id, already_granted: false }));
  } catch (err) {
    logger.error({ err }, 'Failed to grant delegated access');
    return dbError(res);
  } finally {
    if (conn) conn.release();
  }
});

// ── Revoking ────────────────────────────────────────────────────────────────

router.delete('/:id', async (req, res) => {
  if (!UUID_RE.test(String(req.params.id))) return notFound(res);
  let conn;
  try {
    conn = await pool.rw.getConnection();
    if (!(await requireGrantsTable(conn, res))) return undefined;
    // Read the grant to learn its subject, then ask the same ownership question
    // granting asked. Revoking is not a weaker act than granting and is not
    // gated more loosely: only the subject's owner and an administrator may do
    // either.
    const rows = await conn.query(
      `SELECT scope_type, scope_id FROM \`${t(TABLES.DELEGATED_GRANTS)}\` WHERE id = ?`,
      [req.params.id],
    );
    if (!rows.length) return notFound(res);
    const ownerId = await subjectOwnerId(conn, rows[0].scope_type, rows[0].scope_id);
    if (!(await callerOwnsSubject(conn, rows[0].scope_type, req.user, ownerId))) {
      return notFound(res);
    }
    const result = await conn.query(
      `DELETE FROM \`${t(TABLES.DELEGATED_GRANTS)}\` WHERE id = ?`,
      [req.params.id],
    );
    // A grant that was revoked by somebody else between the read and the delete
    // is reported as revoked: the caller asked for it to be gone, and it is.
    return res.json(apiOk({ revoked: Number(result.affectedRows || 0) > 0 }));
  } catch (err) {
    logger.error({ err }, 'Failed to revoke delegated access');
    return dbError(res);
  } finally {
    if (conn) conn.release();
  }
});

module.exports = router;
module.exports.__test__ = {
  callerOwnsSubject, subjectOwnerId, readSubject, MAX_PEOPLE, MAX_GRANTS,
};
