/**
 * flow-recipe-steps/index.js — router assembly for Flow Recipe Steps.
 *
 * Steps are child records of a flow_recipe; ownership resolves via the parent
 * recipe's owner_id. Steps have no ownerColumn of their own — ownership is
 * inherited from the parent recipe through the parentOwnership chain.
 *
 * Middleware order:
 *   1. requireAdminOrEditor gate
 *   2. URL guard (POST/PUT: stored url must be absolute http(s))
 *   3. HTTP-method allowlist (POST/PUT: stored method must be a valid verb)
 *   4. read-scope gate (GET non-admin: list requires ?recipe_id ownership check;
 *      GET /:id resolves ownership via the step's own recipe_id in DB)
 *   5. createCrudRoutes factory (CRUD + parentOwnership via recipe_id +
 *      parentRepend — the parent recipe re-pend now runs atomically inside the
 *      factory write transaction, FOR UPDATE on the parent row)
 */
const express = require('express');
const { createCrudRoutes } = require('../schema');
const { enumColumnsFor } = require('../../../lib/schema-manifest');
const { requireAdminOrEditor } = require('../../../../shared/helpers');
const { TABLES } = require('../../../../shared/constants');
const { pool, t } = require('../../../db');
const { logger } = require('../../../../shared/lib/logger');
const { serializeWrite, serializeRead } = require('./serializer');
const { sameStoredValue } = require('../schema/write-value');
const { PARENT_REPEND_FROM } = require('../../../lib/review-status');
// Shared url guard: absolute http(s) with NO embedded credentials. The compute
// sentinel (https://compute.invalid/) carries no userinfo, so it still passes.
const { isStorableHttpUrl } = require('../../../../shared/lib/portable-url-redaction');

const router = express.Router();

// Admin/editor gate — steps are not accessible to plain data-entry users.
router.use((req, res, next) => {
  if (!requireAdminOrEditor(req, res)) return;
  next();
});

// SECURITY: pin the stored url to an absolute http(s) URL (no userinfo) at the
// write boundary (the step url is executed at dispatch time). Mirrors the
// api-connectors url guard; no /import path to skip here.
router.use((req, res, next) => {
  if ((req.method === 'POST' || req.method === 'PUT')
      && req.body && Object.prototype.hasOwnProperty.call(req.body, 'url')) {
    if (!isStorableHttpUrl(req.body.url)) {
      return res.status(400).json({ ok: false, error: { code: 'BAD_REQUEST', message: 'url must be an absolute http(s) URL' } });
    }
  }
  next();
});

// HTTP-method allowlist: enforce a valid HTTP verb on the step's target
// endpoint. Case-insensitive input; normalised to uppercase before storage.
const ALLOWED_METHODS = new Set(['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'HEAD', 'OPTIONS']);
router.use((req, res, next) => {
  if ((req.method === 'POST' || req.method === 'PUT')
      && req.body && Object.prototype.hasOwnProperty.call(req.body, 'method')) {
    const m = String(req.body.method).toUpperCase();
    if (!ALLOWED_METHODS.has(m)) {
      return res.status(400).json({ ok: false, error: 'INVALID_METHOD' });
    }
    req.body.method = m;
  }
  next();
});

// step_type + before_code/after_code write guard. step_type pins the closed enum;
// the JS slots run in the browser sandbox at dispatch, so the only write-boundary
// concern is a bounded, string-typed payload. 32 KB mirrors the recipe-level
// payload_transform_code ceiling (real authored code is a few hundred bytes).
const MAX_CODE_BYTES = 32 * 1024;
const ALLOWED_STEP_TYPES = new Set(['api', 'compute']);
const CODE_FIELDS = ['before_code', 'after_code'];
router.use((req, res, next) => {
  if (req.method !== 'POST' && req.method !== 'PUT') return next();
  const body = req.body;
  if (!body || typeof body !== 'object') return next();

  if (Object.prototype.hasOwnProperty.call(body, 'step_type')) {
    if (!ALLOWED_STEP_TYPES.has(body.step_type)) {
      return res.status(400).json({ ok: false, error: { code: 'BAD_REQUEST', message: "step_type must be 'api' or 'compute'" } });
    }
  }

  for (const field of CODE_FIELDS) {
    if (!Object.prototype.hasOwnProperty.call(body, field)) continue;
    const v = body[field];
    if (v === null || v === '') continue; // clearing the slot is valid
    if (typeof v !== 'string') {
      return res.status(400).json({ ok: false, error: { code: 'BAD_REQUEST', message: `${field} must be a string` } });
    }
    if (Buffer.byteLength(v, 'utf8') > MAX_CODE_BYTES) {
      return res.status(413).json({ ok: false, error: { code: 'PAYLOAD_TOO_LARGE', message: `${field} exceeds ${MAX_CODE_BYTES} bytes` } });
    }
  }
  next();
});

// "Is this recipe the caller's" — ONE answer, shared by both read shapes below
// and giving the SAME verdict the write path gives.
//
// ASKED OF THE COLUMN, not of JavaScript. `flow_recipes.owner_id` is CHAR(36)
// under a case-folding collation, and every write-side gate on this mount asks
// SQL: the `parentOwnership` chain SELECT the POST runs, and the chain EXISTS
// appended to the editor's UPDATE and DELETE. All three admit an editor whose
// stored `owner_id` differs from the id in their token only in spelling. A `===`
// here then refused that same editor the very steps they had just been permitted
// to create — one question, answered one way by the half that writes and another
// by the half that reads. Measured before this changed: POST 200 with the step
// inserted, and GET on both shapes 403.
//
// FAIL-CLOSED, and here that is the same direction as `sameStoredValue`'s own
// default rather than an exception to it: an operand the column cannot be asked
// about is answered "not the same value", and for a READ gate refusing is the
// safe end — the alternative hands somebody another owner's steps.
const RECIPE_NOT_YOURS = {
  ok: false,
  error: { code: 'FORBIDDEN', message: 'Not allowed: recipe is not owned by you and is not shared' },
};

async function callerMayReadRecipe(ownerId, req) {
  if (ownerId == null) return true; // shared (owner_id IS NULL) — any editor may read
  return sameStoredValue(pool.ro, t(TABLES.FLOW_RECIPES), 'owner_id', ownerId, req.user?.id);
}

// SECURITY: non-admin editors may only read steps scoped to a recipe they can
// access. The enforcement path differs by route shape so a caller cannot supply
// a recipe_id they own to bypass the gate and read a step from a foreign recipe:
//   GET /        — list; caller must supply ?recipe_id and the middleware verifies
//                  ownership before the CRUD factory's recipe_id filter applies.
//   GET /:id     — single step; middleware resolves the owning recipe via the step
//                  row itself, ignoring any caller-supplied ?recipe_id entirely.
router.use(async (req, res, next) => {
  if (req.method !== 'GET' || req.user?.role === 'admin') return next();

  // Detect a single-id path (e.g. /abc-123 or /abc-123/).
  // router.use middleware does not populate req.params, so parse from req.path.
  const singleIdMatch = req.path.match(/^\/([^/]+)\/?$/);
  const stepId = singleIdMatch ? singleIdMatch[1] : null;

  if (stepId) {
    // Single-step path: resolve ownership from the step's own recipe — a spoofed
    // ?recipe_id in the query string cannot influence this path.
    try {
      const stepRows = await pool.ro.query(
        `SELECT recipe_id FROM \`${t(TABLES.FLOW_RECIPE_STEPS)}\` WHERE id = ?`,
        [stepId],
      );
      if (!stepRows.length) return next(); // step absent → CRUD returns 404
      const recipeId = stepRows[0].recipe_id;
      const recipeRows = await pool.ro.query(
        `SELECT owner_id FROM \`${t(TABLES.FLOW_RECIPES)}\` WHERE id = ?`,
        [recipeId],
      );
      if (recipeRows.length
        && !(await callerMayReadRecipe(recipeRows[0].owner_id, req))) {
        return res.status(403).json(RECIPE_NOT_YOURS);
      }
      // recipe not found or accessible → fall through to CRUD
    } catch (err) {
      // SECURITY: fail-closed. If the recipes table is absent we cannot verify
      // the caller owns/shares the parent recipe, so denying is the safe default
      // — a partially-migrated DB (steps present, recipes dropped) must not let a
      // caller read another owner's steps unscoped.
      if (err && err.errno === 1146) {
        return res.status(403).json({ ok: false, error: { code: 'FORBIDDEN', message: 'Not allowed: recipe scope cannot be verified' } });
      }
      logger.warn({ err }, 'flow-recipe-steps read-scope probe failed');
      return res.status(500).json({ ok: false, error: { code: 'INTERNAL_ERROR' } });
    }
    return next();
  }

  // List path: require an explicit recipe_id to keep reads parent-scoped.
  const recipeId = req.query?.recipe_id;
  if (!recipeId || typeof recipeId !== 'string') {
    return res.status(400).json({ ok: false, error: { code: 'RECIPE_ID_REQUIRED', message: 'recipe_id query is required' } });
  }
  try {
    const rows = await pool.ro.query(
      `SELECT owner_id FROM \`${t(TABLES.FLOW_RECIPES)}\` WHERE id = ?`,
      [recipeId],
    );
    if (rows.length && !(await callerMayReadRecipe(rows[0].owner_id, req))) {
      return res.status(403).json(RECIPE_NOT_YOURS);
    }
    // recipe not found → fall through; the CRUD list simply returns no rows.
  } catch (err) {
    // SECURITY: fail-closed (see the /:id branch above) — an absent recipes
    // table means scope cannot be established, so deny rather than list every
    // step unscoped.
    if (err && err.errno === 1146) {
      return res.status(403).json({ ok: false, error: { code: 'FORBIDDEN', message: 'Not allowed: recipe scope cannot be verified' } });
    }
    logger.warn({ err }, 'flow-recipe-steps read-scope probe failed');
    return res.status(500).json({ ok: false, error: { code: 'INTERNAL_ERROR' } });
  }
  next();
});

router.use('/', createCrudRoutes('flow_recipe_steps', {
  allowedRoles: ['admin', 'editor'],
  // Ownership resolves via the parent recipe. Steps have no owner_id of
  // their own — ownerColumn is intentionally omitted.
  parentOwnership: {
    via: 'recipe_id',
    chain: [{ table: TABLES.FLOW_RECIPES, match: 'id', readOwner: 'owner_id' }],
  },
  // SECURITY: editing a step of an approved/rejected recipe must force re-review.
  // The factory re-pends the parent recipe to 'pending' (clearing approval) in
  // the SAME transaction as the step write, with the parent row locked FOR
  // UPDATE — atomic, so a concurrent admin approve cannot leave an approved
  // recipe carrying a swapped step. Non-admin callers only re-pend a recipe they
  // own or that is shared (owner_id NULL); admins re-pend unconditionally.
  parentRepend: {
    table: TABLES.FLOW_RECIPES,
    via: 'recipe_id',
    statusCol: 'status',
    // ownerCol names the parent table's owner column for the non-admin re-pend
    // owner-gate. flow_recipes owns rows under `owner_id`; declared explicitly so
    // a future adopter whose parent uses a different name can't silently inherit
    // a wrong default and have the owner-gate SELECT swallow an errno-1054.
    ownerCol: 'owner_id',
    clearCols: ['approved_by', 'approved_at'],
    // NULL is on this list. Editing a step IS a change to what the parent
    // recipe dispatches, and a grandfathered parent DOES dispatch — so leaving
    // NULL off meant a step could be swapped under a recipe that went on
    // dispatching the new step unreviewed. The list is review-status.js's.
    repandFrom: PARENT_REPEND_FROM,
  },
  filterableColumns: ['recipe_id'],
  // The same DDL-derived domain the connector mount declares, and for the same
  // reason — see that mount for why the whole table is asked rather than a list
  // of columns kept here. This mount carries the additional shape: a PUT naming
  // only `auth_type` reaches a serializer branch that cleans the STORED config
  // against the new type, so an unresolved spelling destroys a credential
  // through a request that carries no credential at all.
  enumColumns: enumColumnsFor(TABLES.FLOW_RECIPE_STEPS),
  serializeWrite,
  // Same mask-preserve read as the connector mount, and the same move onto the
  // write connection under the row's own lock. This mount already ran its write
  // inside a transaction (parentRepend), but the serializer ran BEFORE that
  // transaction opened, so the read was outside it either way.
  serializeWriteInTx: true,
  serializeRead,
}));

module.exports = router;
