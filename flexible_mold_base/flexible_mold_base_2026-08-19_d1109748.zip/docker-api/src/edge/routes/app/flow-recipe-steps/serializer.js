/**
 * serializer.js — field-level secret handling for flow_recipe_steps.
 *
 * flow_recipe_steps stores secrets in the same auth_config JSON column shape
 * as api_connectors (bearer token / api_key value / basic password). The
 * generic DTO mapper only parses/stringifies JSON; it has no notion of
 * "encrypt this leaf". This module supplies the three boundary transforms the
 * CRUD factory calls through its serializeWrite / serializeRead hooks:
 *
 *   write  → encrypt the sensitive leaf of auth_config (AES-256-GCM, reusing
 *            settings-crypto), and preserve an unchanged `****`-masked secret
 *            by reading the stored ciphertext back instead of overwriting it.
 *   read   → mask the sensitive leaf with `****` so the API never returns a
 *            secret (plaintext or ciphertext) to a client.
 *   decrypt→ recover the plaintext leaf for server-side dispatch. Not on
 *            any P1 request path; exported for the round-trip test and P2.
 *
 * Canonical auth_config shapes (auth_type drives which leaf is sensitive):
 *   none    → {}                      (no secret)
 *   bearer  → { token }               (token is secret)
 *   api_key → { header, value }       (value is secret; header name is not)
 *   basic   → { username, password }  (password is secret; username is not)
 *
 * Approval bookkeeping (approved_by / approved_at) lives on the parent recipe,
 * not on individual steps — serializeRead does NOT strip those fields here.
 */
const db = require('../../../db');
const { t } = db;
const { encrypt } = require('../../../../shared/lib/settings-crypto');
const { decryptLeafOrThrow } = require('../../../../shared/lib/decrypt-error');
const { TABLES } = require('../../../../shared/constants');
const { logger: rootLogger } = require('../../../../shared/lib/logger');
// The leaf map, the leaf union and the member list all live in one place, read
// from the DDL — see that module for why a copy per serializer is two answers
// to "is this row's credential a secret", not one answer written twice.
const {
  ALL_SECRET_LEAVES,
  pathsFor,
  readMaskPaths,
  refuseUndeclaredAuthType,
  refuseUnreadableStoredAuthType,
} = require('../../../lib/auth-config-secrets');
// The credential-header vocabulary and the url sanitiser the export path already
// uses — one definition, so a value this repository calls a secret on one
// surface cannot be an ordinary value on another.
const {
  maskRequestConfigHeaders,
  resolveMaskedRequestConfigHeaders,
  sanitizeUrlForExport,
} = require('../../../../shared/lib/portable-url-redaction');

const logger = rootLogger.child({ module: 'flow-recipe-steps:serializer' });

// OPERATIONS: this is the only runtime-secret path that depends on the
// encryption key. Without it, settings-crypto is fail-closed and a step
// carrying a secret is REJECTED at save (422); warn once at load so an
// operator fixes the deployment before a save fails. Secret-free steps
// still save.
if (!process.env.SETTINGS_ENCRYPTION_KEY) {
  logger.warn('SETTINGS_ENCRYPTION_KEY is not set — saving a flow recipe step with a secret will be rejected (422) until it is configured');
}

const MASK = '****';
// The answer for "there is no stored row to read" — a create, or an update
// whose id names nothing. See the connector serializer for why `found` is
// carried rather than inferred from a null type.
const NO_STORED_ROW = Object.freeze({
  found: false, authConfig: null, authType: null, requestConfig: null,
});
// settings-crypto stamps every ciphertext with this prefix; a leaf already
// carrying it is encrypted, so re-encrypting must be skipped (idempotence).
const ENC_PREFIX = 'enc:v1:';

function isNonEmptyString(v) {
  return typeof v === 'string' && v.length > 0;
}

/** A JSON column as an object, whether the driver handed it back parsed or raw.
 *  An unparseable value reads as absent — a caller must not treat a string it
 *  cannot interpret as a structure it can. */
function parseJsonColumn(value) {
  if (value == null) return null;
  if (typeof value === 'object') return value;
  if (typeof value !== 'string') return null;
  try { return JSON.parse(value); } catch { return null; }
}

function getAt(obj, path) {
  let cur = obj;
  for (const key of path) {
    if (cur == null || typeof cur !== 'object') return undefined;
    cur = cur[key];
  }
  return cur;
}

/** Clone along `path` and apply `fn(leaf)` at the leaf. `fn` returning
 *  `undefined` deletes the leaf key. Missing intermediate nodes are skipped. */
function updateAt(obj, path, fn) {
  if (!obj || typeof obj !== 'object') return obj;
  const out = { ...obj };
  let cursor = out;
  for (let i = 0; i < path.length - 1; i += 1) {
    const key = path[i];
    if (cursor[key] == null || typeof cursor[key] !== 'object') return out;
    cursor[key] = { ...cursor[key] };
    cursor = cursor[key];
  }
  const leafKey = path[path.length - 1];
  if (!(leafKey in cursor)) return out;
  const next = fn(cursor[leafKey]);
  if (next === undefined) delete cursor[leafKey];
  else cursor[leafKey] = next;
  return out;
}

function mapLeaves(authConfig, authType, fn) {
  let out = authConfig;
  for (const path of pathsFor(authType)) out = updateAt(out, path, fn);
  return out;
}

/**
 * Remove every ALL_SECRET_LEAVES leaf that is not the sanctioned sensitive
 * leaf for `authType`. This enforces the invariant that auth_config never
 * carries a secret from an old/different type (e.g., a bearer `token` leaf
 * when auth_type is 'none' or 'basic').
 *
 * SECURITY: run before encryptAuthConfig so no mismatched plaintext or
 * ciphertext is ever persisted. Non-secret leaves (e.g., `header`, `username`)
 * are untouched.
 */
function stripStraySecretLeaves(authConfig, authType) {
  if (!authConfig || typeof authConfig !== 'object') return authConfig;
  const allowed = new Set(pathsFor(authType).map((p) => p[p.length - 1]));
  const out = { ...authConfig };
  for (const leaf of ALL_SECRET_LEAVES) {
    if (!allowed.has(leaf) && leaf in out) delete out[leaf];
  }
  return out;
}

/** Encrypt each sensitive leaf. Skips empties, the mask sentinel, and values
 *  already encrypted (idempotent re-save). */
function encryptAuthConfig(authConfig, authType) {
  return mapLeaves(authConfig, authType, (v) => {
    if (!isNonEmptyString(v)) return v;
    if (v === MASK) return v; // caller resolves MASK before encrypting
    if (v.startsWith(ENC_PREFIX)) return v;
    return encrypt(v);
  });
}

/**
 * Replace every non-empty secret-NAMED leaf with the mask sentinel — masked by
 * leaf name rather than by the row's current type, exactly as the connector
 * serializer does. See that module for why: a row carrying a previous type's
 * ciphertext is masked by nothing when the question is what the CURRENT type
 * sanctions, and such rows already exist. `authType` is deliberately unused.
 */
function maskAuthConfig(authConfig, _authType) {
  return readMaskPaths().reduce(
    (acc, path) => updateAt(acc, path, (v) => (isNonEmptyString(v) ? MASK : v)),
    authConfig,
  );
}

/** Decrypt each sensitive leaf (server-side use only). Throws DecryptError when
 *  a leaf cannot be decrypted (wrong key / missing key). */
function decryptAuthConfig(authConfig, authType) {
  return mapLeaves(authConfig, authType, (v) => (isNonEmptyString(v) ? decryptLeafOrThrow(v) : v));
}

/** True when every sensitive leaf decrypts under the current key (or there is
 *  no secret). SECURITY: returns only a boolean — never the decrypted value. */
function probeDecryptable(authConfig, authType) {
  for (const path of pathsFor(authType)) {
    const v = getAt(authConfig, path);
    if (!isNonEmptyString(v)) continue;
    try { decryptLeafOrThrow(v); } catch { return false; }
  }
  return true;
}

/** Drop every sensitive leaf entirely so a portable recipe step never carries a
 *  secret (the operator re-enters it after import). */
function stripAuthConfigSecrets(authConfig, authType) {
  return mapLeaves(authConfig, authType, () => undefined);
}

/**
 * Read the stored auth_config + auth_type for a step id, used for
 * mask-preserve on update. Returns { found, authConfig (parsed or null),
 * authType (VERBATIM), requestConfig } — see the connector serializer's copy for
 * why "no such row" and "a row whose stored type resolves nothing" must not both
 * arrive here as a null type.
 *
 * ASKED OF THE ROW THE STATEMENT WILL UPDATE — see the connector serializer's
 * copy of this function for the full reasoning. `conn` is the write connection
 * the CRUD factory holds a transaction on, and the row is taken `FOR UPDATE`, so
 * the value bound as "what is stored" is the value the UPDATE lands on top of.
 */
async function readStored(id, conn) {
  // Lazy pool access: the pool is null at module load under the cold-boot
  // contract and configured later, so reference it at call time.
  const cols = 'auth_config, auth_type, request_config';
  const rows = conn
    ? await conn.query(
      `SELECT ${cols} FROM \`${t(TABLES.FLOW_RECIPE_STEPS)}\` WHERE id = ? FOR UPDATE`,
      [id],
    )
    : await db.pool.ro.query(
      `SELECT ${cols} FROM \`${t(TABLES.FLOW_RECIPE_STEPS)}\` WHERE id = ?`,
      [id],
    );
  if (!rows.length) return NO_STORED_ROW;
  return {
    found: true,
    authConfig: parseJsonColumn(rows[0].auth_config),
    authType: rows[0].auth_type,
    requestConfig: parseJsonColumn(rows[0].request_config),
  };
}

/** Replace every `****`-masked sensitive leaf with the stored ciphertext for
 *  the same path; drop the leaf when there is no stored secret (so the literal
 *  mask is never persisted as a value).
 *
 *  THE STORED VALUE CAN ITSELF BE THE SENTINEL, and that is the case the
 *  emptiness test alone lets through: `'****'` is a non-empty string, so a row
 *  already holding it kept it on every save, and `decryptLeafOrThrow` returns
 *  any value without the `enc:v1:` prefix verbatim — so the request went out
 *  carrying `Bearer ****` for as long as the row existed. Measured: a row whose
 *  stored `auth_config.token` was `'****'`, PUT with the same body, answered 200
 *  with the column unchanged. Such rows exist because the create path used to
 *  persist the sentinel; refusing to carry it forward is the repair half of that
 *  fix, and it costs nothing else — dropping the leaf is what "there is no stored
 *  secret" already meant. */
function resolveMaskedLeaves(authConfig, authType, storedAuthConfig) {
  return pathsFor(authType).reduce((acc, path) => {
    if (getAt(acc, path) !== MASK) return acc;
    const prior = getAt(storedAuthConfig || {}, path);
    const usable = isNonEmptyString(prior) && prior !== MASK;
    return updateAt(acc, path, () => (usable ? prior : undefined));
  }, authConfig);
}

/**
 * serializeWrite hook. Encrypts the secret leaf of data.auth_config before it
 * is persisted. On update, a leaf left as the `****` mask means "unchanged" —
 * it is replaced with the stored ciphertext rather than overwriting the real
 * secret. Returns a new data object; leaves data untouched when it carries no
 * auth_config and no auth_type (a partial update of other fields).
 *
 * SECURITY — auth_config/auth_type consistency invariants enforced here:
 *   1. Stray secret leaves: any leaf in ALL_SECRET_LEAVES that is not the
 *      sanctioned leaf for the effective auth_type is stripped BEFORE encrypt,
 *      so auth_type='none' with {token:'x'} never stores the token unencrypted.
 *   2. Type-change-only PUT: when auth_type changes but auth_config is absent,
 *      the stored auth_config is loaded, stray leaves for the new type are
 *      stripped, and the cleaned config is re-persisted — preventing the old
 *      ciphertext from leaking unmasked through serializeRead under the new type.
 */
async function serializeWrite(data, ctx = {}) {
  if (!data || typeof data !== 'object') return data;

  const hasAuthConfig = data.auth_config !== undefined;
  const hasAuthType = data.auth_type !== undefined;
  const hasRequestConfig = data.request_config !== undefined;

  // None of the three in the body — partial update of other fields.
  if (!hasAuthConfig && !hasAuthType && !hasRequestConfig) return data;

  // ONE READ OF THE STORED ROW, SHARED BY BOTH MASK RESOLUTIONS — see the
  // connector serializer for why the two do not each take their own.
  let storedRow;
  const stored = async () => {
    if (storedRow === undefined) {
      storedRow = (ctx.isUpdate && ctx.id)
        ? await readStored(ctx.id, ctx.conn)
        : NO_STORED_ROW;
    }
    return storedRow;
  };

  // A credential header still reading `****` means "unchanged", exactly as a
  // masked auth_config leaf does. Resolved on create too, where the safe arm
  // drops the key rather than persisting the sentinel as a dispatched value.
  if (hasRequestConfig) {
    const incoming = typeof data.request_config === 'string'
      ? parseJsonColumn(data.request_config)
      : data.request_config;
    if (incoming && typeof incoming === 'object') {
      data = {
        ...data,
        request_config: resolveMaskedRequestConfigHeaders(incoming, (await stored()).requestConfig),
      };
    }
  }
  if (!hasAuthConfig && !hasAuthType) return data;

  // THE VALUE THAT DECIDES WHICH LEAF IS A SECRET IS THE VALUE THE COLUMN WILL
  // HOLD. Refused before the first `pathsFor` — and on this mount that matters
  // on a request shape api_connectors does not have: the type-change-only branch
  // below reads the STORED config and cleans it against the new type, so an
  // undeclared spelling there sanctions nothing, strips the stored token and
  // re-persists `{}` for a PUT carrying no auth_config at all.
  if (hasAuthType) refuseUndeclaredAuthType(TABLES.FLOW_RECIPE_STEPS, data.auth_type);

  // Type-change-only PUT: auth_type changes but no new auth_config in body.
  // Load stored auth_config, strip leaves belonging to the old type, persist
  // the cleaned config so stale ciphertext cannot leak via serializeRead.
  if (!hasAuthConfig && hasAuthType && ctx.isUpdate && ctx.id) {
    const prior = await stored();
    if (prior.authConfig == null) return data;
    const cleaned = stripStraySecretLeaves(prior.authConfig, data.auth_type);
    return { ...data, auth_config: encryptAuthConfig(cleaned, data.auth_type) };
  }

  // auth_type change without auth_config and not an update-with-id — nothing stored to clean.
  if (!hasAuthConfig) return data;

  let authConfig = data.auth_config;
  // A client may send the JSON column as a string; normalise to an object so
  // the leaf transform can run, then mapRowToDb re-stringifies downstream.
  if (typeof authConfig === 'string') {
    try { authConfig = JSON.parse(authConfig); } catch { return data; }
  }
  if (authConfig === null) return data;

  let authType = data.auth_type;

  // Resolve masked leaves against the stored row (and recover auth_type when
  // the update body omits it).
  //
  // RESOLVED ON CREATE TOO — the mirror of the connector serializer's branch,
  // and the same failure: with the resolution gated on `isUpdate`, a create
  // carrying `{"token":"****"}` persisted the sentinel UNENCRYPTED as the
  // credential, which dispatch then reads as legacy plaintext and sends. There
  // is nothing stored to preserve on a create, so the leaf is dropped.
  {
    const needsType = authType === undefined && !!(ctx.isUpdate && ctx.id);
    const hasMask = needsType
      || pathsFor(authType).some((p) => getAt(authConfig, p) === MASK);
    if (hasMask) {
      const prior = await stored();
      if (needsType) {
        // THE EFFECTIVE TYPE IS NOW THE STORED ONE, SO IT IS JUDGED HERE — the
        // mirror of the connector serializer's guard, and the same defect: the
        // gate above judges the body's `auth_type` and this branch is the one
        // the body does not carry it on. `found` distinguishes an out-of-domain
        // stored type from an id that names no row (already a 404).
        if (prior.found) refuseUnreadableStoredAuthType(TABLES.FLOW_RECIPE_STEPS, prior.authType);
        authType = prior.authType;
      }
      authConfig = resolveMaskedLeaves(authConfig, authType, prior.authConfig);
    }
  }

  // Strip secret leaves that don't belong to the effective auth_type.
  // Must run before encrypt so no mismatched plaintext is ever persisted.
  authConfig = stripStraySecretLeaves(authConfig, authType);

  return { ...data, auth_config: encryptAuthConfig(authConfig, authType) };
}

/**
 * serializeRead hook. Masks the secret leaf of a parsed row's auth_config so
 * the API response never returns a secret to a client. Returns a new row object.
 *
 * SECURITY: approval bookkeeping (approved_by / approved_at) lives on the
 * parent flow_recipe row, not on steps — this serializer intentionally does
 * NOT strip those fields (steps have no such columns).
 */
function serializeRead(row) {
  if (!row || typeof row !== 'object') return row;
  const masked = { ...row };
  // THE SAME THREE SURFACES THE CONNECTOR MOUNT HIDES — a step holds the same
  // credential-valued headers and the same executable url, so a rule present on
  // one lane and absent on its mirror is the whole shape this closes.
  if (typeof masked.url === 'string') masked.url = sanitizeUrlForExport(masked.url);
  if (masked.request_config != null && typeof masked.request_config === 'object') {
    masked.request_config = maskRequestConfigHeaders(masked.request_config);
  }
  row = masked;
  if (row.auth_config == null) return { ...row };
  // SECURITY: a non-object auth_config means the JSON column failed to parse
  // (corrupt row / driver edge). mapLeaves would pass the raw string through
  // unmasked — possibly leaking ciphertext — so blank it rather than echo it.
  const rest = { ...row };
  if (typeof rest.auth_config !== 'object') return { ...rest, auth_config: {} };
  return { ...rest, auth_config: maskAuthConfig(rest.auth_config, rest.auth_type) };
}

// SECURITY: returns the PLAINTEXT secret. Used only by the P2 dispatch path
// (assemble the outbound auth header) and the round-trip test — NEVER pass the
// result to apiOk()/a client response.
function decryptRow(row) {
  if (!row || typeof row !== 'object' || row.auth_config == null) return row;
  return { ...row, auth_config: decryptAuthConfig(row.auth_config, row.auth_type) };
}

module.exports = {
  serializeWrite,
  serializeRead,
  decryptRow,
  encryptAuthConfig,
  maskAuthConfig,
  decryptAuthConfig,
  probeDecryptable,
  stripAuthConfigSecrets,
  stripStraySecretLeaves,
  MASK,
};
