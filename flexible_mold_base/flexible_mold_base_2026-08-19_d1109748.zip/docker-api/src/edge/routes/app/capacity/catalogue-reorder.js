/**
 * @openapi
 * /edge/app/capacity/config/{group}/reorder:
 *   put:
 *     tags: [App - Capacity]
 *     summary: Persist a drag-reorder for a GLOBAL config catalogue (admin+editor).
 *     description: >
 *       Phase-6 spec §D3. Rewrites `order_index` for every GLOBAL row
 *       (scenario_id IS NULL) of the catalogue to its position in `orderedIds`,
 *       in one transaction. `orderedIds` MUST be exactly the catalogue's current
 *       GLOBAL row-id set — a partial or foreign-id list is rejected 400 rather
 *       than silently reordering a subset. Scenario-LOCAL rows (scenario_id X)
 *       are never in the set, so a local row id in the body fails the exact-match
 *       check (the scenario-scoped reorder route owns local-row ordering).
 *     parameters:
 *       - { name: group, in: path, required: true, schema: { type: string, enum: [hardware_specs, disk_combos, teams, vm_profiles] } }
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [orderedIds]
 *             properties:
 *               orderedIds: { type: array, items: { type: string } }
 *     responses:
 *       200: { description: Reordered }
 *       400: { description: Malformed body, unknown group, or orderedIds does not match the catalogue's global row set }
 *       403: { description: Admin or editor required }
 */

/**
 * capacity/catalogue-reorder.js — bulk drag-reorder persist for the GLOBAL config
 * catalogue tables (phase-6 spec §D3): Hardware Specs / Disk Combos / Teams / VM
 * Profiles rendered on the CapacityConfig one-pager. It is the global-scope
 * analogue of reorder.js: reorder.js scopes every read/write to
 * `scenario_id = :scenarioId` (so a catalogue's LOCAL rows), while this module
 * scopes to `scenario_id IS NULL` (the shared global rows the config page edits).
 * The scenario-scoped route 400s a global row by design (reorder.js FOR UPDATE
 * read is scenario-scoped), so a dedicated global route is required.
 *
 * Mounted at /config BEFORE config.js's generic `PUT /:group/:id` in index.js so
 * a `/config/<group>/reorder` path is served here, not treated as a row id by the
 * config factory. Write = admin+editor (the same tier that edits the catalogue,
 * config.js). `order_index` is not one of these tables' writable config columns
 * (CONFIG_MOUNTS.cols omits it), so this bespoke bulk rewrite is the only path
 * that sets it — mirroring reorder.js's bypass of the generic per-row CRUD.
 */
const express = require('express');
const { pool, t } = require('../../../db');
const { requireAdminOrEditor, apiOk, apiError } = require('../../../../shared/helpers');
const { logger } = require('../../../../shared/lib/logger');
const { TABLES } = require('../../../../shared/constants');
const { lockGlobalConfig, safeRollback } = require('./_shared');

// The reorderable GLOBAL catalogue groups → their logical table. Only these four
// render as drag-sortable dual-mode grids on the config page (spec §D3). A group
// outside this map falls through to config.js's own /:group/:id handler (404).
// Bundles keep their own `serial` display-order column + card rail, so they are
// intentionally not here (no order_index rewrite path).
const CATALOGUE_TABLES = Object.freeze({
  hardware_specs: TABLES.CAP_HARDWARE_SPECS,
  disk_combos: TABLES.CAP_DISK_COMBOS,
  teams: TABLES.CAP_TEAMS,
  vm_profiles: TABLES.CAP_VM_PROFILES,
});

// Generous upper bound on a global-catalogue reorder body. The endpoint requires
// the COMPLETE current global id set, so this MUST exceed any realistic catalogue
// size or a legal full reorder could never succeed.
const MAX_CATALOGUE_REORDER_ROWS = 5000;

const router = express.Router();

router.put('/:group/reorder', async (req, res) => {
  if (!requireAdminOrEditor(req, res)) return;
  const group = req.params.group;
  const table = CATALOGUE_TABLES[group];
  if (!table) {
    const e = apiError(`${group} is not a reorderable catalogue`, 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }
  const { orderedIds } = req.body || {};

  if (
    !Array.isArray(orderedIds)
    || orderedIds.length === 0
    || !orderedIds.every((id) => typeof id === 'string' && id.length > 0)
  ) {
    const e = apiError(`orderedIds must be a non-empty array of ${group} ids`, 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }
  if (orderedIds.length > MAX_CATALOGUE_REORDER_ROWS) {
    const e = apiError(`orderedIds exceeds ${MAX_CATALOGUE_REORDER_ROWS} limit`, 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }
  if (new Set(orderedIds).size !== orderedIds.length) {
    const e = apiError('orderedIds contains a duplicate id', 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }

  let conn;
  try {
    conn = await pool.rw.getConnection();
    await conn.beginTransaction();
    // Serialize against the first-instance config import's clear-then-insert (P1),
    // like every other global-config writer (config.js / bundles.js).
    await lockGlobalConfig(conn);

    // Lock every GLOBAL row of the catalogue FOR UPDATE, then require the body's
    // id set to match EXACTLY — closes a stale-tab drag (a row deleted elsewhere
    // mid-drag) and rejects an attempt to smuggle a scenario-LOCAL row id into the
    // global rewrite (local rows are ordered by the scenario-scoped route).
    const existing = await conn.query(
      `SELECT id FROM \`${t(table)}\` WHERE scenario_id IS NULL FOR UPDATE`,
    );
    const existingIds = new Set(existing.map((r) => r.id));
    const bodyIds = new Set(orderedIds);
    const sameSet = existingIds.size === bodyIds.size && [...existingIds].every((id) => bodyIds.has(id));
    if (!sameSet) {
      await safeRollback(conn);
      const e = apiError(`orderedIds must match the global ${group} set exactly`, 'BAD_REQUEST', 400);
      return res.status(e.status).json(e.body);
    }

    for (let i = 0; i < orderedIds.length; i += 1) {
      await conn.query(
        `UPDATE \`${t(table)}\` SET order_index = ? WHERE id = ? AND scenario_id IS NULL`,
        [i, orderedIds[i]],
      );
    }

    await conn.commit();
    res.json(apiOk({ reordered: orderedIds.length }));
  } catch (err) {
    await safeRollback(conn);
    logger.error({ err, group }, `Failed to reorder global capacity catalogue ${group}`);
    const e = apiError('Database operation failed', 'INTERNAL_ERROR', 500);
    res.status(e.status).json(e.body);
  } finally {
    if (conn) conn.release();
  }
});

module.exports = router;
