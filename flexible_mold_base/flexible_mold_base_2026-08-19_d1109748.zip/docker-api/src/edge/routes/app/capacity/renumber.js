/**
 * @openapi
 * /edge/app/capacity/scenarios/{scenarioId}/renumber-preview:
 *   post:
 *     tags: [App - Capacity]
 *     summary: Preview the old→new hostname renumber for a scenario (admin+editor).
 *     description: >
 *       Spec B5 Q18/Q20. Read-only. Recomputes every hypervisor / KVM-host /
 *       AP-VM name from the scenario's EFFECTIVE naming patterns (scenario
 *       override → global → built-in defaults) in current `order_index` display
 *       order, PLUS every DB instance name from its owning database's topology
 *       rule (spec §7 E2 — not a pattern), and returns the full old→new list.
 *       No writes.
 *     parameters:
 *       - { name: scenarioId, in: path, required: true, schema: { type: string } }
 *     responses:
 *       200: { description: "The old→new plan: [{ id, entityType, oldName, newName, tooLong, duplicate }]" }
 *       403: { description: Not the scenario owner (and not admin), or a plain user }
 *       404: { description: Scenario not found }
 * /edge/app/capacity/scenarios/{scenarioId}/renumber:
 *   post:
 *     tags: [App - Capacity]
 *     summary: Apply the hostname renumber for a scenario in one transaction (admin+editor).
 *     description: >
 *       Spec B5 Q18. Recomputes names server-side (never trusts a client-sent
 *       name), enforces scenario-wide per-entity-type uniqueness (DB instance
 *       names are exempt — spec §7 E2, a primary/standby pair intentionally
 *       shares one name), and writes every changed name in ONE transaction —
 *       any duplicate rolls the whole apply back (409), nothing is written.
 *       Drag reorder never renames; this explicit action is the only path
 *       that re-sequences names.
 *     parameters:
 *       - { name: scenarioId, in: path, required: true, schema: { type: string } }
 *     responses:
 *       200: { description: "Applied: { applied, renamed: [{ id, entityType, oldName, newName }] }" }
 *       403: { description: Not the scenario owner (and not admin), or a plain user }
 *       404: { description: Scenario not found }
 *       409: { description: The computed names collide within an entity type — nothing applied }
 */

/**
 * capacity/renumber.js — the explicit Renumber toolbar action (spec B5b). Two
 * POST routes on the scenario: a read-only preview and a transactional apply.
 *
 * Numbering (fork-2, wizard-consistent, computeRenumberPlan in
 * shared/capacity/name-patterns.js): group each entity type by its resolved {dc}
 * slug (a {dc}-free pattern = one scenario-wide group), seq 1..k in order_index
 * order, pad width = max(declared, digits(groupCount)). Hand-edited names are
 * renumbered like any other — that is the point of the action.
 *
 * CONCURRENCY. The PRIMARY protection is scenario-row serialization: apply locks
 * cap_scenarios FOR UPDATE first (resolveScenarioWriteAccess), and every other
 * same-scenario writer takes the same lock first — placement-apply, reorder and
 * the child DELETE always did, and the child CREATE/UPDATE now does too for the
 * mounts apply reads unlocked (db_instances / databases / sites, via
 * makeScenarioRowLock; fmb-1685). Before that, a role-only db_instance UPDATE
 * took NO scenario lock, so it could commit between apply's unlocked
 * readHostFunctionRoles snapshot and its writes and leave apply renaming from
 * stale role/function. The GLOBAL name_patterns row (cap_settings scenario_id IS
 * NULL) has no scenario to lock on, so apply takes lockGlobalConfig — the same
 * lock its writers take — before resolveEffectivePatterns (fmb-1685). The
 * SECONDARY, defence-in-depth guard is per-row lock order: each entity
 * table is locked in ONE unfiltered `ORDER BY id FOR UPDATE` pass per scenario —
 * ascending primary-key order, the same order placement-apply's compareMove
 * takes on the shared cap_vms rows — so even absent the scenario-row lock the
 * per-row acquisition order could not invert. cap_vms carries BOTH kvm_host
 * (db_host) and ap_vm (ap_host) rows; it is locked ONCE unfiltered and split by
 * vm_type in JS AFTER the lock — a per-vm_type filtered scan would take its
 * locks in two id-monotonic-but-interleaved passes, breaking that single
 * ascending order. The display-order sort (order_index, id) that drives seq is
 * applied in JS after the locks are taken in id order.
 *
 * cap_databases is DELIBERATELY NEVER LOCKED by this route (spec §7 E2's
 * `readDbInstanceRows`, below), even though apply's `cap_db_instances` lock
 * scan JOINs it for function_name/topology: it is a read-only INPUT here (this
 * route never writes a `cap_databases` row), so the lock scan is split — the
 * driving table (`cap_db_instances`) alone takes `FOR UPDATE`, and
 * `cap_databases` is a separate PLAIN (non-locking) read. A single `FOR UPDATE`
 * join across both would lock cap_databases too, and children.js's SGA cascade
 * (children.js ~276) locks the SAME pair in the OPPOSITE order — parent
 * `cap_databases` UPDATE first, then `cap_db_instances ... FOR UPDATE` — an
 * edge this route's own per-row lock-order invariant did not account for. The
 * PRIMARY protection above (the scenario-row `FOR UPDATE`, held by both apply
 * and the SGA cascade before either touches a child row) already serializes
 * the two paths; not locking cap_databases here removes the SECOND,
 * unaccounted-for edge rather than resting on the primary protection alone.
 */
const express = require('express');
const { pool, t } = require('../../../db');
const { requireAdminOrEditor, apiOk, apiError } = require('../../../../shared/helpers');
const { logger } = require('../../../../shared/lib/logger');
const { TABLES } = require('../../../../shared/constants');
const {
  siteSlug, computeRenumberPlan, firstDuplicateName, duplicateNameFlags, duplicateAllLockedFlags,
  firstOverlengthName, resolveEffectiveNamePatterns, resolveFunctionToken,
  computeDbInstanceRenumberPlan,
} = require('../../../../shared/capacity/name-patterns');
const { resolveScenarioWriteAccess, safeRollback, tableColumnSet, lockGlobalConfig } = require('./_shared');

// The name column is VARCHAR(255) on BOTH cap_hypervisors and cap_vms
// (table-ddls.js). A computed hostname must fit the SMALLER limit (they are equal
// at 255); pinned against a DDL change by the renumber schema-parity test.
const MAX_HOSTNAME_LENGTH = 255;

// The renumberable entity types (spec B5), grouped by TABLE so each table is
// read/locked exactly ONCE (cap_vms carries two entity types, split by vm_type
// after the single lock pass). `vmType` NULL = the whole table is one entity
// type; otherwise it filters that table's rows in JS. `label` is used only in
// the 409 message; `patternKey` selects the entity's pattern from the resolved
// effective set. `roleAware: true` (kvm_host only, cap-pattern-function D2/D7)
// means the pattern key is NOT static — it is resolved PER ROW from that
// host's role (primary/standby) instead.
const RENUMBER_TABLES = [
  {
    table: TABLES.CAP_HYPERVISORS,
    hasVmType: false,
    entities: [{ entityType: 'hypervisor', vmType: null, patternKey: 'hypervisor', label: 'hypervisor' }],
  },
  {
    table: TABLES.CAP_VMS,
    hasVmType: true,
    entities: [
      { entityType: 'kvm_host', vmType: 'db_host', roleAware: true, label: 'KVM host' },
      { entityType: 'ap_vm', vmType: 'ap_host', patternKey: 'ap_vm', label: 'AP VM' },
    ],
  },
];

// L3: an entity with neither `roleAware: true` nor a string `patternKey` would
// index `patterns[undefined]` in plansForTable and silently render the literal
// name "undefined-dc-01" for every row of that type instead of failing loudly
// — cheap enough to check once at module load rather than per request. A pure
// function so the invariant itself (not just today's fixed RENUMBER_TABLES
// value) is directly testable.
function assertRenumberEntitiesShape(tableSpecs) {
  for (const tableSpec of tableSpecs) {
    for (const entity of tableSpec.entities) {
      const hasRoleAware = entity.roleAware === true;
      const hasPatternKey = typeof entity.patternKey === 'string' && entity.patternKey.length > 0;
      if (hasRoleAware === hasPatternKey) {
        throw new Error(
          `RENUMBER_TABLES entity "${entity.entityType}" must have exactly one of roleAware:true or a string patternKey`,
        );
      }
    }
  }
}
assertRenumberEntitiesShape(RENUMBER_TABLES);

/** Parse a name_patterns JSON column value: the driver may hand back a parsed
 *  object or the raw JSON string (C3). null/blank/`null` → null (inherited). */
function parseNamePatterns(raw) {
  if (raw === null || raw === undefined) return null;
  if (typeof raw === 'string') {
    const trimmed = raw.trim();
    if (trimmed === '' || trimmed === 'null') return null;
    try { return JSON.parse(trimmed); } catch { return null; }
  }
  if (typeof raw === 'object' && !Array.isArray(raw)) return raw;
  return null;
}

/**
 * Resolve the scenario's EFFECTIVE naming patterns from cap_settings: its own
 * override row (scenario_id = the scenario) wins, else the global row
 * (scenario_id IS NULL), else the built-in defaults — the SAME tier chain the FE
 * placement prefill resolves, via the shared resolveEffectiveNamePatterns.
 */
async function resolveEffectivePatterns(dbHandle, scenarioId) {
  // Degraded-schema guard (C1, READ side): a warn-skipped name_patterns migration
  // (no DDL privilege) leaves the column ABSENT — a direct SELECT of it would 500
  // both preview and apply. Probe on `dbHandle` — the SAME connection the SELECT
  // below runs on (replica-DDL-lag family, mirrors readTableRows' fix below:
  // probing via the writer pool while the SELECT itself runs on a lagging RO
  // replica in preview lets the probe see the column present and the SELECT
  // 500 on it — probe and SELECT must observe the identical schema, which only
  // the same connection guarantees) — and, when the column is missing, resolve
  // to the built-in defaults: with no column there are no stored overrides
  // anywhere to read. An empty/odd probe (no `id`) is treated as "unknown,
  // assume present" and falls through, mirroring dropAbsentColumns' fail-safe.
  const settingsCols = await tableColumnSet(dbHandle, TABLES.CAP_SETTINGS, { cache: false });
  if (settingsCols.has('id') && !settingsCols.has('name_patterns')) {
    // No column → no stored override anywhere; built-in defaults are the global tier.
    return { patterns: resolveEffectiveNamePatterns(null, null), source: 'global' };
  }
  const scenRows = await dbHandle.query(
    `SELECT scenario_id, name_patterns FROM \`${t(TABLES.CAP_SETTINGS)}\` WHERE scenario_id = ?`,
    [scenarioId],
  );
  const globalRows = await dbHandle.query(
    `SELECT scenario_id, name_patterns FROM \`${t(TABLES.CAP_SETTINGS)}\` WHERE scenario_id IS NULL LIMIT 1`,
  );
  const scenarioRow = scenRows.length
    ? { scenario_id: scenRows[0].scenario_id, name_patterns: parseNamePatterns(scenRows[0].name_patterns) }
    : null;
  const globalRow = globalRows.length
    ? { scenario_id: globalRows[0].scenario_id, name_patterns: parseNamePatterns(globalRows[0].name_patterns) }
    : null;
  // The effective set is whole-set per tier (resolveEffectiveNamePatterns): the
  // scenario's OWN non-null override wins the whole set, else the global row/
  // defaults. So `source` is one tier flag shared by all four entity keys — a
  // scenario override in force makes every key 'override', otherwise 'global'.
  const source = scenarioRow && scenarioRow.name_patterns ? 'override' : 'global';
  return { patterns: resolveEffectiveNamePatterns(scenarioRow, globalRow), source };
}

/** scenario site-id → site name (for the {dc} slug). One read, no lock — a
 *  concurrent site rename cannot commit mid-apply because the sites mount's
 *  CREATE/UPDATE takes the scenario row FOR UPDATE, which apply holds (fmb-1685). */
async function readSiteNames(dbHandle, scenarioId) {
  const rows = await dbHandle.query(
    `SELECT id, name FROM \`${t(TABLES.CAP_SITES)}\` WHERE scenario_id = ?`,
    [scenarioId],
  );
  const byId = new Map();
  for (const r of rows) byId.set(r.id, r.name);
  return byId;
}

/**
 * db_host VM id → { role, function } (cap-pattern-function spec D7): role is
 * 'primary' iff ≥1 instance placed on that host has the primary role, else
 * 'standby'; function is the function_name of the FIRST database (min
 * cap_databases.order_index, the on-screen display order) among the databases
 * that have ≥1 instance on that host — ties broken by database id for a
 * deterministic result. LEFT JOIN so an instance whose database_id is NULL or
 * dangling (an orphaned instance) still counts toward role, just not toward
 * function. Unlocked read (same tier as readSiteNames — this is generation
 * CONTEXT, not a row being renamed; the entity tables carry the actual lock).
 * Freshness against a concurrent placement/role/function edit does NOT come from
 * a lock here — locking cap_db_instances inside apply would invert against the
 * child writes' cap_vms lock order (deadlock; makeScenarioRowLock note). It comes
 * from those child writes taking the scenario row FOR UPDATE, which apply already
 * holds, so none can commit between this snapshot and apply's writes (fmb-1685).
 * A host absent from the returned map has NO instances at all — D7's "empty
 * host" case, resolved by the caller (role defaults to primary, function
 * falls back via resolveFunctionToken).
 */
async function readHostFunctionRoles(dbHandle, scenarioId) {
  // di.name / di.order_index are added (over the earlier role/function-only read)
  // so the PREVIEW can render each db_host's own instances as `contents` pills
  // (PR-3) — the apply path ignores them. ORDER BY (order_index, id) fixes a
  // deterministic per-host instance display order. di.order_index is an
  // fmb-1329 auto-column (table-ddls cap_db_instances) — NOT NULL DEFAULT 0,
  // never behind a degraded-schema probe — so it is read unguarded here, same
  // posture as cap_vms.order_index below (also unprobed on this same route).
  const rows = await dbHandle.query(
    `SELECT di.vm_id AS vmId, di.name AS instanceName, di.role AS role, d.function_name AS functionName, d.order_index AS dbOrderIndex, d.id AS dbId
     FROM \`${t(TABLES.CAP_DB_INSTANCES)}\` di
     LEFT JOIN \`${t(TABLES.CAP_DATABASES)}\` d ON di.database_id = d.id
     WHERE di.scenario_id = ?
     ORDER BY di.order_index, di.id`,
    [scenarioId],
  );
  const byVm = new Map();
  for (const r of rows) {
    let entry = byVm.get(r.vmId);
    if (!entry) {
      entry = {
        hasPrimary: false, bestOrderIndex: null, bestDbId: null, functionName: null, instances: [],
      };
      byVm.set(r.vmId, entry);
    }
    // Per-instance role (P/S), NOT the host's aggregate role — the pill shows the
    // instance's own placement (mock Section 2 `name · P` / `name · S`).
    entry.instances.push({ name: r.instanceName, role: r.role === 'primary' ? 'primary' : 'standby' });
    if (r.role === 'primary') entry.hasPrimary = true;
    if (r.dbOrderIndex !== null && r.dbOrderIndex !== undefined) {
      const orderIndex = Number(r.dbOrderIndex);
      const dbId = String(r.dbId);
      const better = entry.bestOrderIndex === null
        || orderIndex < entry.bestOrderIndex
        || (orderIndex === entry.bestOrderIndex && dbId < entry.bestDbId);
      if (better) {
        entry.bestOrderIndex = orderIndex;
        entry.bestDbId = dbId;
        entry.functionName = r.functionName;
      }
    }
  }
  const byVmResolved = new Map();
  for (const [vmId, entry] of byVm) {
    byVmResolved.set(vmId, {
      role: entry.hasPrimary ? 'primary' : 'standby',
      function: entry.functionName,
      instances: entry.instances,
    });
  }
  return byVmResolved;
}

/**
 * Read one TABLE's rows (unfiltered — one pass), shaped for computeRenumberPlan.
 * For the APPLY path (`lock`) the scan is a single `ORDER BY id FOR UPDATE`
 * (canonical lock order); display order (order_index, id) is imposed in JS
 * afterward. For PREVIEW the DB orders by (order_index, id) directly (no lock).
 * `vm_type` is carried when the table has it so the caller can split entity types
 * in JS without a second scan.
 */
async function readTableRows(dbHandle, scenarioId, table, hasVmType, siteNames, { lock }) {
  // Degraded-schema guard (READ side, mirrors resolveEffectivePatterns above): a
  // warn-skipped name_locked migration (no DDL privilege) leaves the column
  // ABSENT — naming it in the SELECT unconditionally would 500 every renumber
  // call. Probe on `dbHandle` — the SAME connection the SELECT below runs on
  // (Codex R2: probing via the writer pool while this SELECT runs on a lagging
  // RO replica in preview lets the probe see the column and the SELECT 500 on
  // it — probe and SELECT must observe the identical schema, which only the
  // same connection guarantees) — and drop the column from the SELECT when
  // missing: with no column every host reads as unlocked, degrading to today's
  // unconditional-rename behaviour instead of failing. An empty/odd probe (no
  // `id`) is treated as "unknown, assume present" (dropAbsentColumns' fail-safe).
  // cache:false — the shared cache keys by table name and would serve a set an
  // RW probe populated to this RO SELECT (the exact cross-connection leak the
  // same-connection threading exists to prevent); bypass keeps probe and SELECT
  // on one schema.
  const physicalCols = await tableColumnSet(dbHandle, table, { cache: false });
  const hasLockColumn = !physicalCols.has('id') || physicalCols.has('name_locked');
  const lockCol = hasLockColumn ? ', name_locked' : '';
  // ap-vm-function (PR-2): cap_vms.function_name is the ap_vm {function} source.
  // Same degraded-schema guard as name_locked — a warn-skipped add-column
  // migration (no DDL privilege) leaves it ABSENT, so naming it unconditionally
  // would 500 every renumber call. Only cap_vms (the vm_type-bearing table)
  // carries it; when absent, ap_vm reads null → 'ap' fallback (today's behaviour).
  const hasFunctionColumn = hasVmType && (!physicalCols.has('id') || physicalCols.has('function_name'));
  const functionCol = hasFunctionColumn ? ', function_name' : '';
  const cols = hasVmType
    ? `id, name, order_index, site_id, vm_type${lockCol}${functionCol}`
    : `id, name, order_index, site_id${lockCol}`;
  const order = lock ? 'ORDER BY id FOR UPDATE' : 'ORDER BY order_index, id';
  const raw = await dbHandle.query(
    `SELECT ${cols} FROM \`${t(table)}\` WHERE scenario_id = ? ${order}`,
    [scenarioId],
  );
  const rows = raw.map((r) => ({
    id: r.id,
    name: r.name,
    order_index: Number(r.order_index) || 0,
    vm_type: hasVmType ? r.vm_type : null,
    // Unplaced (site_id NULL, or a dangling id not in the scenario's sites) → ''
    // slug → the {dc}-free group (computeRenumberPlan strips {dc} there).
    dcSlug: r.site_id && siteNames.has(r.site_id) ? siteSlug(siteNames.get(r.site_id)) : '',
    // cap-renumber-lock (spec D1/D3): a locked host is excluded from renaming
    // and consumes no seq. Re-read fresh on every call (preview AND apply) so
    // apply never trusts a stale preview's lock state.
    locked: hasLockColumn && (r.name_locked === 1 || r.name_locked === true),
    // ap-vm-function (PR-2): the ap_vm {function} source. Absent column
    // (degraded), or a db_host row that never selected it, → null → 'ap' fallback.
    function_name: hasFunctionColumn ? (r.function_name ?? null) : null,
  }));
  if (lock) {
    // Locks were taken in id order above; now impose display order for seq.
    rows.sort((a, b) => (a.order_index - b.order_index) || (a.id < b.id ? -1 : a.id > b.id ? 1 : 0));
  }
  return rows;
}

/**
 * Read every DB instance row for the scenario (spec §7 E2 renumber extension),
 * joined to its owning database's function_name/topology — the two inputs
 * `computeDbInstanceRenumberPlan` needs. An orphaned instance (database_id
 * NULL, or a dangling id — the join then carries null function/topology) is
 * still read; the plan function treats a null function/topology as a
 * passthrough (unchanged) — there is no topology to derive a name from
 * (name-patterns.js's own doc on `computeDbInstanceRenumberPlan`). Both
 * columns are core `cap_databases` fields present since the table's creation
 * (not an fmb-1329 add-column migration), so unlike `resolveEffectivePatterns`
 * / `readTableRows` above this needs no degraded-schema probe.
 *
 * PREVIEW==APPLY INVARIANT (both paths return through this ONE function — a
 * fix here covers both call sites, not one at a time):
 *
 *  - CASE-FOLDED `databaseId` (X1): `cap_databases.id` is `CHAR(36)` under a
 *    case-folding collation (the same fact `vm-site.js`'s `sameSiteId` and
 *    `dc-refs.js`'s rewrite-to-canonical-spelling both document) — the LOCK
 *    path's SQL `= ?`-free join here is done in JS, not SQL, so a raw
 *    `Map.get(r.databaseId)` would MISS a same-row id that merely differs in
 *    case, while the PREVIEW path's SQL join (`ON di.database_id = d.id`)
 *    resolves it. Both branches below now resolve `databaseId` to the
 *    OWNING DATABASE'S OWN canonical spelling (`d.id`/`COALESCE(d.id, …)`)
 *    when the join succeeds, so `computeDbInstanceRenumberPlan`'s
 *    `${databaseId}::${role}` grouping key is byte-identical for two
 *    differently-cased references to the SAME database, in EITHER path —
 *    the lock path's Map lookup folds to lowercase to find the match (ASCII
 *    hex + hyphens, on which `toLowerCase()` IS that collation, same
 *    reasoning as `vm-site.js`'s own case-fold), then reports the match's
 *    OWN `id`, never the raw (possibly differently-cased) instance-row value.
 *  - SCENARIO-SCOPED join (X2): the join condition constrains `cap_databases`
 *    to THIS scenario on both paths — the lock path's own `WHERE scenario_id
 *    = ?` on its `cap_databases` read already does this; the preview path's
 *    SQL join gains an explicit `AND d.scenario_id = di.scenario_id` so a
 *    legacy/imported instance whose `database_id` happens to name ANOTHER
 *    scenario's database resolves to nothing in EITHER path (passthrough),
 *    not a foreign function/topology preview would propose and apply would
 *    never perform.
 *
 * `{ lock }` mirrors `readTableRows`'s OWN id-order `FOR UPDATE` convention,
 * but — unlike a single joined query — locks ONLY `cap_db_instances`
 * (`ORDER BY id FOR UPDATE`, no join, canonical ascending-id lock order — the
 * file header's lock-ordering INVARIANT, and the call site's own note on
 * WHERE this sits relative to cap_hypervisors/cap_vms). `cap_databases` is
 * read SEPARATELY with a plain (non-locking) query — see the file header's
 * "cap_databases is DELIBERATELY NEVER LOCKED" note for why a single locking
 * JOIN across both would be wrong here. PREVIEW takes no lock on either table
 * (the original single joined query is fine there — no FOR UPDATE means no
 * lock-order question), ordered for display.
 */
async function readDbInstanceRows(dbHandle, scenarioId, { lock }) {
  if (lock) {
    const instanceRows = await dbHandle.query(
      `SELECT id, name, database_id AS databaseId, role, order_index AS orderIndex
       FROM \`${t(TABLES.CAP_DB_INSTANCES)}\`
       WHERE scenario_id = ? ORDER BY id FOR UPDATE`,
      [scenarioId],
    );
    // Plain read (no FOR UPDATE): cap_databases is a read-only INPUT to this
    // route, never written by it — this cannot contribute a lock edge.
    // Scenario-scoped (X2): a foreign-scenario database_id cannot resolve here.
    const databaseRows = await dbHandle.query(
      `SELECT id, function_name AS functionName, topology
       FROM \`${t(TABLES.CAP_DATABASES)}\`
       WHERE scenario_id = ?`,
      [scenarioId],
    );
    // X1: fold to lowercase for the lookup KEY only — ASCII hex + hyphens, on
    // which toLowerCase() IS the CHAR(36) case-folding collation SQL's `=`
    // uses (vm-site.js's sameSiteId carries the same reasoning). The VALUE
    // returned still carries the database's own canonical `id` spelling.
    const databaseByFoldedId = new Map(databaseRows.map((d) => [String(d.id).toLowerCase(), d]));
    return instanceRows.map((r) => {
      const db = r.databaseId ? databaseByFoldedId.get(String(r.databaseId).toLowerCase()) : undefined;
      return {
        id: r.id,
        name: r.name,
        // The RESOLVED database's OWN id spelling when matched — must agree
        // with the preview path's COALESCE(d.id, …) below, or the two paths
        // group differently-cased-but-equal references into different
        // (databaseId, role) groups (X1).
        databaseId: db ? db.id : r.databaseId,
        role: r.role,
        order_index: Number(r.orderIndex) || 0,
        functionName: db ? db.functionName : null,
        topology: db ? db.topology : null,
      };
    });
  }
  const rows = await dbHandle.query(
    `SELECT di.id AS id, di.name AS name,
            COALESCE(d.id, di.database_id) AS databaseId,
            di.role AS role, di.order_index AS orderIndex,
            d.function_name AS functionName, d.topology AS topology
     FROM \`${t(TABLES.CAP_DB_INSTANCES)}\` di
     LEFT JOIN \`${t(TABLES.CAP_DATABASES)}\` d
       ON di.database_id = d.id AND d.scenario_id = di.scenario_id
     WHERE di.scenario_id = ? ORDER BY di.order_index, di.id`,
    [scenarioId],
  );
  return rows.map((r) => ({
    id: r.id,
    name: r.name,
    databaseId: r.databaseId,
    role: r.role,
    order_index: Number(r.orderIndex) || 0,
    functionName: r.functionName,
    topology: r.topology,
  }));
}

/**
 * Split a table's rows into its entity types (by vm_type) and compute each
 * type's plan, tagging every plan item with its entityType.
 *
 * `roleAware` entities (kvm_host, cap-pattern-function D2/D7) resolve their
 * pattern PER ROW from `hostFunctionRoles` instead of a single static
 * patternKey: primary and standby hosts form independent renumber groups
 * (independent seq streams, independent patterns), computed separately and
 * then reassembled into the ORIGINAL row order (not primary-then-standby) so
 * the preview/apply response order is unaffected by the split — the same
 * order-preservation computeRenumberPlan itself already guarantees for
 * locked-vs-renumerable rows.
 *
 * H1: the primary group is computed FIRST, then its full plan (locked names
 * unchanged + every generated name) is passed as the standby call's
 * `reservedSeed` — so a same-dc empty primary host (`kvm-{dc}-01` fallback) and
 * a same-dc standby-only host (also `kvm-{dc}-01` under D8 defaults) share ONE
 * collision set instead of each independently claiming seq 1. Deterministic:
 * the primary group is always resolved before the standby group regardless of
 * row order, so the same input always produces the same names.
 *
 * P1b (Codex r1 on H1): the primary call runs FIRST with no seed of its own,
 * so a LOCKED row on the STANDBY side was invisible to it — a locked standby
 * host named `kvm-{dc}-01` and an empty primary host would both resolve to
 * that name and collide. Locked names are now collected from BOTH role groups
 * up front (before either plan runs) and passed as `reservedSeed` to the
 * PRIMARY call too, so every plan call sees every name it must avoid.
 */
function plansForTable(tableSpec, rows, patterns, hostFunctionRoles) {
  return tableSpec.entities.map((entity) => {
    const entityRows = entity.vmType ? rows.filter((r) => r.vm_type === entity.vmType) : rows;
    if (entity.roleAware) {
      const primaryRows = [];
      const standbyRows = [];
      for (const row of entityRows) {
        const info = hostFunctionRoles.get(row.id);
        // D7 "empty host" (no instances at all → absent from the map) uses the
        // primary pattern; a resolved host uses its actual computed role.
        const role = info && info.role === 'standby' ? 'standby' : 'primary';
        const patternKey = role === 'primary' ? 'kvm_host_primary' : 'kvm_host_standby';
        const withFn = { ...row, function: resolveFunctionToken(patternKey, info ? info.function : null) };
        (role === 'primary' ? primaryRows : standbyRows).push(withFn);
      }
      // P1b: locked names from BOTH role groups, collected BEFORE either plan
      // runs — the primary call has no other seed, so without this a locked
      // standby host is invisible to it.
      const lockedNamesBothGroups = entityRows.filter((row) => row.locked).map((row) => row.name);
      const primaryPlan = computeRenumberPlan(primaryRows, patterns.kvm_host_primary, lockedNamesBothGroups);
      // Standby seed = (a) locked names from BOTH groups (redundant with
      // primaryPlan's own locked-primary names, harmless — the set dedups) +
      // (b) the primary plan's generated names.
      const reservedSeed = [
        ...lockedNamesBothGroups,
        ...primaryPlan.map((item) => item.newName),
      ];
      const standbyPlan = computeRenumberPlan(standbyRows, patterns.kvm_host_standby, reservedSeed);
      const planById = new Map([...primaryPlan, ...standbyPlan].map((item) => [item.id, item]));
      const plan = entityRows.map((row) => planById.get(row.id));
      return { entity, table: tableSpec.table, plan };
    }
    // ap_vm (PR-2): resolves {function} PER ROW from its own
    // cap_vms.function_name (an AP VM never owns a db instance, so it carries its
    // function directly rather than deriving one from a database) — empty/NULL
    // falls back to 'ap' via resolveFunctionToken. hypervisor stays fallback-only:
    // a hypervisor's hosted-VM function chain is out of scope, so a custom pattern
    // using {function} gets the entity fallback rather than rendering empty.
    const withFn = entityRows.map((row) => ({
      ...row,
      function: resolveFunctionToken(
        entity.patternKey,
        entity.entityType === 'ap_vm' ? row.function_name : null,
      ),
    }));
    const plan = computeRenumberPlan(withFn, patterns[entity.patternKey]);
    return { entity, table: tableSpec.table, plan };
  });
}

const router = express.Router();

// POST preview — read-only. Admin+editor (the toolbar action is canWrite-gated),
// but takes NO lock (a RO handle must not FOR UPDATE).
//
// M1: ONE pool.ro connection is acquired up front and threaded through every
// read below (access check, pattern-resolution probe, site/role reads, row
// SELECTs) — a pool FACADE's `.query()` may hand each call a different
// physical replica, so probing schema on one call and reading rows on another
// (both nominally "pool.ro") could still observe two different replicas, the
// exact replica-DDL-lag shape the dbHandle threading was introduced to close.
// Same invariant apply already holds via its RW transaction connection.
router.post('/scenarios/:scenarioId/renumber-preview', async (req, res) => {
  if (!requireAdminOrEditor(req, res)) return;
  const scenarioId = req.params.scenarioId;
  let conn;
  try {
    conn = await pool.ro.getConnection();
    const access = await resolveScenarioWriteAccess(conn, scenarioId, req.user, { lock: false });
    if (!access.found) {
      const e = apiError('Scenario not found', 'NOT_FOUND', 404);
      return res.status(e.status).json(e.body);
    }
    if (!access.allowed) {
      const e = apiError('Not the scenario owner', 'FORBIDDEN', 403);
      return res.status(e.status).json(e.body);
    }
    const { patterns, source } = await resolveEffectivePatterns(conn, scenarioId);
    const siteNames = await readSiteNames(conn, scenarioId);
    const hostFunctionRoles = await readHostFunctionRoles(conn, scenarioId);
    const preview = [];
    for (const tableSpec of RENUMBER_TABLES) {
      const rows = await readTableRows(conn, scenarioId, tableSpec.table, tableSpec.hasVmType, siteNames, { lock: false });
      // ap_vm {function} display source, keyed by row id (Y-pattern: '' when the
      // stored function_name is null/absent). db_host contents come from the
      // instance list readHostFunctionRoles now carries.
      const functionNameById = new Map(rows.map((r) => [r.id, r.function_name ?? '']));
      for (const { entity, plan } of plansForTable(tableSpec, rows, patterns, hostFunctionRoles)) {
        // Same fold, same scope as apply's firstDuplicateName gate (the full
        // per-entity-type newNames list, ALL rows incl. unchanged ones) — every
        // colliding row is flagged (fmb-1649), not just the second occurrence,
        // so the dialog can block Confirm before the user reaches apply's
        // deterministic 409 (same input → same collision, no retry escapes it).
        const dupFlags = duplicateNameFlags(plan.map((p) => p.newName));
        // cap-renumber-lock: a collision where EVERY colliding row is locked
        // cannot be fixed by editing the naming pattern (a locked name never
        // changes, spec D1) — the dialog needs to tell those two remedies apart.
        const lockedDupFlags = duplicateAllLockedFlags(plan.map((p) => ({ name: p.newName, locked: p.locked })));
        plan.forEach((item, idx) => {
          preview.push({
            id: item.id,
            entityType: entity.entityType,
            oldName: item.oldName,
            newName: item.newName,
            // Surface an over-limit name BEFORE apply (Codex R2 P2-2): the dialog
            // flags the row and blocks confirm, so the user shortens the pattern
            // rather than hitting the apply-time 409.
            tooLong: item.newName.length > MAX_HOSTNAME_LENGTH,
            duplicate: dupFlags[idx],
            lockedDuplicate: lockedDupFlags[idx],
            // cap-renumber-lock (spec D1/D6): locked rows render greyed with no
            // rename arrow; newName === oldName always holds for them.
            locked: item.locked,
            // PR-3 Contents column. A db_host carries its own instances (name +
            // per-instance P/S role, input order preserved); an ap_vm/hypervisor
            // carries none (ap_vm shows its function via functionName instead).
            contents: entity.entityType === 'kvm_host'
              ? ((hostFunctionRoles.get(item.id) || {}).instances || [])
              : [],
            // ap_vm only — the {function} token for its function pill ('' when
            // unset → the dialog renders an em dash). Y-pattern non-nullable.
            functionName: entity.entityType === 'ap_vm' ? (functionNameById.get(item.id) || '') : '',
          });
        });
      }
    }
    // DB instance names (spec §7 E2): topology-derived, never a pattern, never
    // locked, never SCENARIO-WIDE-unique (see computeDbInstanceRenumberPlan's
    // own doc for why no cross-database duplicate check runs here) — so no
    // lockedDup wiring beyond the plain length check every renumbered name
    // gets. `duplicate` here is the narrower oversized-single-group flag the
    // plan function itself computes (F4) — surfaced the same way tooLong is.
    const dbInstanceRows = await readDbInstanceRows(conn, scenarioId, { lock: false });
    const dbInstanceFunctionById = new Map(dbInstanceRows.map((r) => [r.id, r.functionName || '']));
    for (const item of computeDbInstanceRenumberPlan(dbInstanceRows)) {
      preview.push({
        id: item.id,
        entityType: 'db_instance',
        oldName: item.oldName,
        newName: item.newName,
        tooLong: item.newName.length > MAX_HOSTNAME_LENGTH,
        duplicate: item.duplicate,
        lockedDuplicate: false,
        locked: false,
        contents: [],
        // The owning database's function name (Y-pattern '' when the instance
        // is orphaned) — the dialog's Contents cell shows it the same way an
        // ap_vm row shows its own {function} pill.
        functionName: dbInstanceFunctionById.get(item.id) || '',
      });
    }
    // Response-level active patterns (mock Section 2 info block): the effective
    // pattern string per entity key + which tier is in force (global | override).
    const patternsInfo = {
      hypervisor: { pattern: patterns.hypervisor, source },
      kvm_host_primary: { pattern: patterns.kvm_host_primary, source },
      kvm_host_standby: { pattern: patterns.kvm_host_standby, source },
      ap_vm: { pattern: patterns.ap_vm, source },
    };
    res.json(apiOk({ rows: preview, patterns: patternsInfo }));
  } catch (err) {
    logger.error({ err, scenarioId }, `Failed to preview capacity renumber for scenario id=${scenarioId}`);
    const e = apiError('Database operation failed', 'INTERNAL_ERROR', 500);
    res.status(e.status).json(e.body);
  } finally {
    if (conn) conn.release();
  }
});

// POST apply — one transaction. Recompute server-side, enforce per-entity-type
// uniqueness, write every CHANGED name, whole rollback on any duplicate.
router.post('/scenarios/:scenarioId/renumber', async (req, res) => {
  if (!requireAdminOrEditor(req, res)) return;
  const scenarioId = req.params.scenarioId;

  let conn;
  try {
    conn = await pool.rw.getConnection();
    await conn.beginTransaction();

    const access = await resolveScenarioWriteAccess(conn, scenarioId, req.user);
    if (!access.found) {
      await safeRollback(conn);
      const e = apiError('Scenario not found', 'NOT_FOUND', 404);
      return res.status(e.status).json(e.body);
    }
    if (!access.allowed) {
      await safeRollback(conn);
      const e = apiError('Not the scenario owner', 'FORBIDDEN', 403);
      return res.status(e.status).json(e.body);
    }

    // fmb-1685: resolveEffectivePatterns reads the GLOBAL cap_settings row
    // (scenario_id IS NULL) that a scenario with no override inherits its
    // name_patterns from. That row is written by the global config writers under
    // lockGlobalConfig, and those writers take NO scenario lock — so unlike the
    // per-scenario override (whose PUT takes cap_scenarios FOR UPDATE, which apply
    // already holds), a concurrent GLOBAL name_patterns edit could commit between
    // this read and apply's writes and leave apply renaming from a stale pattern.
    // Take the SAME lock the global writers take, so the two cannot interleave.
    // Lock ORDER: cap_scenarios (already held) → cap_settings, and no cap_settings
    // writer acquires cap_scenarios after cap_settings (the per-scenario PUT takes
    // cap_scenarios FIRST; the global writer takes neither cap_scenarios nor the
    // entity tables), so this adds no inverting edge.
    await lockGlobalConfig(conn);

    const { patterns } = await resolveEffectivePatterns(conn, scenarioId);
    const siteNames = await readSiteNames(conn, scenarioId);
    const hostFunctionRoles = await readHostFunctionRoles(conn, scenarioId);

    // Phase 1: lock each TABLE once (ascending id) and compute every entity
    // type's plan. No write yet — the uniqueness gate must clear for ALL types
    // first so a conflict in a later type still rolls the earlier types back.
    const allPlans = [];
    // cap_db_instances plan (spec §7 E2) — hoisted out of the RENUMBER_TABLES
    // loop below (populated inside it, right after cap_hypervisors; see the
    // lock-ordering comment there) so Phase 2 can write it after allPlans.
    let dbInstancePlan = [];
    for (const tableSpec of RENUMBER_TABLES) {
      const rows = await readTableRows(conn, scenarioId, tableSpec.table, tableSpec.hasVmType, siteNames, { lock: true });
      for (const planned of plansForTable(tableSpec, rows, patterns, hostFunctionRoles)) {
        const newNames = planned.plan.map((p) => p.newName);
        const dup = firstDuplicateName(newNames);
        if (dup !== null) {
          await safeRollback(conn);
          // cap-renumber-lock: when EVERY row colliding on `dup` is locked, the
          // pattern is not the problem — a locked name never changes (spec D1),
          // so re-running with a different pattern would hit the identical 409.
          // The only remedy is unlocking one of the colliding hosts.
          const lockedDupFlags = duplicateAllLockedFlags(
            planned.plan.map((p) => ({ name: p.newName, locked: p.locked })),
          );
          const dupIdx = newNames.findIndex((n) => String(n).trim().toLowerCase() === String(dup).trim().toLowerCase());
          const message = dupIdx !== -1 && lockedDupFlags[dupIdx]
            ? `Renumber would collide on "${dup}" — every ${planned.entity.label} host with that name is locked, so no naming pattern can change it. Unlock one of the colliding ${planned.entity.label} hosts and retry.`
            : `Renumber would create a duplicate ${planned.entity.label} name "${dup}" — no changes applied. Adjust the ${planned.entity.label} naming pattern and retry.`;
          const e = apiError(message, 'CONFLICT', 409);
          return res.status(e.status).json(e.body);
        }
        // Over-limit guard (Codex R2 P2-2): a long site slug + pattern prefix can
        // compute a name past the VARCHAR(255) column — reject the whole apply
        // (a strict INSERT would 500, a lax one would truncate) on the same
        // rollback-before-any-write path as the duplicate guard.
        const tooLong = firstOverlengthName(newNames, MAX_HOSTNAME_LENGTH);
        if (tooLong !== null) {
          await safeRollback(conn);
          const e = apiError(
            `Renumber would create a ${planned.entity.label} name longer than ${MAX_HOSTNAME_LENGTH} characters ("${tooLong.slice(0, 40)}…") — no changes applied. Shorten the ${planned.entity.label} naming pattern or the site name and retry.`,
            'CONFLICT', 409,
          );
          return res.status(e.status).json(e.body);
        }
        allPlans.push(planned);
      }
      // Lock-order INVARIANT (matches placement-apply.js's own compareMove,
      // which sorts moved rows by TABLE NAME then id: 'cap_db_instances' sorts
      // alphabetically BEFORE 'cap_vms' but this route's cap_hypervisors lock
      // (RENUMBER_TABLES[0], taken above) already precedes both — same order
      // placement-apply takes: hypervisors first, then db_instances, then
      // vms). Locking db_instances HERE — right after hypervisors, before the
      // loop reaches cap_vms — keeps this route's per-table lock order
      // identical to placement-apply's, so the two writers can never invert
      // and deadlock on the shared rows.
      //
      // `readDbInstanceRows({lock:true})` locks ONLY cap_db_instances rows,
      // not cap_databases — see the file header's "cap_databases is
      // DELIBERATELY NEVER LOCKED" note. cap_databases is read there via a
      // separate plain query, so it never becomes a lock-order participant
      // this comment (or placement-apply's compareMove) would need to
      // account for.
      if (tableSpec.table === TABLES.CAP_HYPERVISORS) {
        const dbInstanceRows = await readDbInstanceRows(conn, scenarioId, { lock: true });
        dbInstancePlan = computeDbInstanceRenumberPlan(dbInstanceRows);
        // Within-database name-collision guard (F4, generalized class-closing
        // by Y1): computeDbInstanceRenumberPlan flags every row whose computed
        // name repeats within one database — an oversized single-role group
        // (F4's original shape), OR a topology illegally carrying both a
        // primary and a standby row (generic CRUD enforces neither cardinality
        // — Y1) — UNLESS that topology intentionally shares one name across
        // roles (primary_standby today, the function's own doc). No
        // SCENARIO-WIDE duplicate check runs here otherwise.
        const duplicateRow = dbInstancePlan.find((p) => p.duplicate);
        if (duplicateRow) {
          await safeRollback(conn);
          const e = apiError(
            `Renumber would collide on "${duplicateRow.newName}" — more than one DB instance in the same database would compute this identical name, and this database's topology does not intentionally share names across roles. Split them into separate databases, fix the role/topology mismatch, or use a topology that shares names (e.g. Primary+Standby) and retry.`,
            'CONFLICT', 409,
          );
          return res.status(e.status).json(e.body);
        }
        // Same VARCHAR(255) length guard every other renumbered name gets.
        const tooLong = firstOverlengthName(dbInstancePlan.map((p) => p.newName), MAX_HOSTNAME_LENGTH);
        if (tooLong !== null) {
          await safeRollback(conn);
          const e = apiError(
            `Renumber would create a DB instance name longer than ${MAX_HOSTNAME_LENGTH} characters ("${tooLong.slice(0, 40)}…") — no changes applied. Shorten the database's function name and retry.`,
            'CONFLICT', 409,
          );
          return res.status(e.status).json(e.body);
        }
      }
    }

    // Phase 2: write only the CHANGED rows (case-sensitive compare so a case-only
    // rename is still applied). Uniqueness already cleared for every type. A
    // locked row's newName === oldName always holds (computeRenumberPlan), but
    // it still gets an EXPLICIT `item.locked` branch below (not just the
    // unchanged-name check that would happen to skip it anyway) so it can be
    // counted into skippedLocked for the response summary (spec D1: apply
    // re-checks lock state fresh, so a row locked between preview and apply is
    // skipped here even if preview showed it as renamed).
    const renamed = [];
    let skippedLocked = 0;
    for (const { entity, table, plan } of allPlans) {
      for (const item of plan) {
        if (item.locked) { skippedLocked += 1; continue; }
        if (item.newName === item.oldName) continue;
        await conn.query(
          `UPDATE \`${t(table)}\` SET name = ? WHERE id = ? AND scenario_id = ?`,
          [item.newName, item.id, scenarioId],
        );
        renamed.push({
          id: item.id, entityType: entity.entityType, oldName: item.oldName, newName: item.newName,
        });
      }
    }

    // DB instance names (spec §7 E2) — no lock concept for this entity, so no
    // skippedLocked contribution; only unchanged rows (already-correct names)
    // are skipped.
    for (const item of dbInstancePlan) {
      if (item.newName === item.oldName) continue;
      await conn.query(
        `UPDATE \`${t(TABLES.CAP_DB_INSTANCES)}\` SET name = ? WHERE id = ? AND scenario_id = ?`,
        [item.newName, item.id, scenarioId],
      );
      renamed.push({
        id: item.id, entityType: 'db_instance', oldName: item.oldName, newName: item.newName,
      });
    }

    await conn.commit();
    res.json(apiOk({ applied: renamed.length, renamed, skippedLocked }));
  } catch (err) {
    await safeRollback(conn);
    logger.error({ err, scenarioId }, `Failed to apply capacity renumber for scenario id=${scenarioId}`);
    const e = apiError('Database operation failed', 'INTERNAL_ERROR', 500);
    res.status(e.status).json(e.body);
  } finally {
    if (conn) conn.release();
  }
});

// Test-only (L3): the express Router is a function, so it can carry a named
// property alongside its mount behaviour — mirrors _shared.js's
// _resetColumnSetCache test-hook pattern. Lets a test drive the shape
// assertion against synthetic input without mutating the real RENUMBER_TABLES.
router._assertRenumberEntitiesShape = assertRenumberEntitiesShape;

module.exports = router;
