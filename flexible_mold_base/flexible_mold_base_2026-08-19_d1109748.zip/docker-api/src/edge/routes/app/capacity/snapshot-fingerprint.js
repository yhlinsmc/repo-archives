/**
 * snapshot-fingerprint.js — a canonical fingerprint of ONE scenario's own rows.
 *
 * Why this exists: an in-place restore deletes every scenario-scoped row and
 * replays a frozen version over the top. The caller is asked to save the state
 * it is about to replace first, and passes that version's id along. Nothing
 * previously checked that the id actually described the state being destroyed —
 * so a write that landed between the save and the switch (a second tab, another
 * admin on the same scenario) was deleted with no copy in any version, while the
 * audit row recorded `prior_state_saved: true`.
 *
 * Comparing fingerprints turns that claim into something derived: the restore
 * proceeds only when the rows it is about to delete are the rows the named
 * version froze.
 */
const { createHash } = require('node:crypto');

/**
 * The rows a restore would actually DELETE: the scenario's own.
 *
 * A frozen snapshot deliberately carries the GLOBAL layer alongside them — the
 * referenced global catalogue rows (`addCatalogueClosure`) plus every global
 * rule and the global settings singleton (`addGlobalConfigLayer`), all with
 * `scenario_id: null`. `deleteScenarioScopedRows` never touches those, so an
 * edit to the global rule template must not read as "this scenario moved".
 */
function scenarioOwnedRows(rows) {
  if (!Array.isArray(rows)) return [];
  return rows.filter(
    (row) => row && typeof row === 'object' && !Array.isArray(row) && row.scenario_id != null,
  );
}

/** Deterministic JSON: object keys sorted at every depth, so two documents that
 *  differ only in key order fingerprint the same. */
function canonicalJson(value) {
  if (value === null || typeof value !== 'object') return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(canonicalJson).join(',')}]`;
  return `{${Object.keys(value).sort()
    .map((k) => `${JSON.stringify(k)}:${canonicalJson(value[k])}`)
    .join(',')}}`;
}

/**
 * SHA-256 over one scenario's own rows for `keys`, in a form two differently
 * sourced documents can be compared in.
 *
 * The input goes through a JSON round-trip first, because the two sides reach
 * this function by different routes: one is live driver output (Date objects,
 * driver-typed scalars), the other was `JSON.stringify`d into the snapshot
 * column at freeze time and parsed back out. The round-trip puts the live side
 * in exactly the representation the stored side already has. That direction of
 * the guarantee is the one that matters: a fingerprint that drifted on
 * representation alone would refuse every switch, not just a stale one.
 *
 * Row ORDER is deliberately not part of the fingerprint — the snapshot reads
 * carry no ORDER BY, so a difference in order is not evidence of anything. A
 * missing key and an empty table are the same answer for the same reason.
 */
function fingerprintScenarioRows(tables, keys) {
  const source = tables && typeof tables === 'object' && !Array.isArray(tables) ? tables : {};
  const normalized = JSON.parse(JSON.stringify(source));
  const doc = keys
    .map((key) => {
      const rows = scenarioOwnedRows(normalized[key]).map(canonicalJson).sort();
      return `${JSON.stringify(key)}:[${rows.join(',')}]`;
    })
    .join(',');
  return createHash('sha256').update(doc).digest('hex');
}

module.exports = { fingerprintScenarioRows, scenarioOwnedRows, canonicalJson };
