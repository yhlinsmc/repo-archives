/**
 * @openapi
 * /edge/app/capacity/config/{group}:
 *   get:
 *     tags: [App - Capacity]
 *     summary: List global-template rows (scenario_id IS NULL) for a config group.
 *     parameters:
 *       - { name: group, in: path, required: true, schema: { type: string, enum: [hardware_specs, disk_combos, teams, vm_profiles, field_defs, settings, rules] } }
 *     responses:
 *       200: { description: Template rows }
 *   post:
 *     tags: [App - Capacity]
 *     summary: Create a global-template row (admin+editor).
 *     parameters:
 *       - { name: group, in: path, required: true, schema: { type: string } }
 *     responses:
 *       201: { description: Created }
 *       403: { description: Admin or editor required }
 * /edge/app/capacity/config/{group}/{id}:
 *   put:
 *     tags: [App - Capacity]
 *     summary: Update a global-template row (admin+editor).
 *   delete:
 *     tags: [App - Capacity]
 *     summary: Delete a global-template row (admin+editor).
 */

/**
 * capacity/config.js — CRUD for the global catalogue / template config tables
 * (hardware_specs / disk_combos / teams / vm_profiles / field_defs / settings /
 * rules), scoped to `scenario_id IS NULL`. In the REFERENCE MODEL (spec §2)
 * scenarios REFERENCE these global rows by FK — nothing is deep-copied at
 * scenario create; a version freeze is the only copy mechanism (§2.1). Read =
 * all authenticated; write = admin+editor (spec §7).
 *
 * Bespoke (not the generic createCrudRoutes factory) because the factory cannot
 * express the `scenario_id IS NULL` template scope on both read and write. The
 * scope predicate is the guard that keeps this route off scenario-owned rows.
 */
const express = require('express');
const { pool, t } = require('../../../db');
const { requireAuth, requireAdminOrEditor, apiOk, apiError, uuidv4 } = require('../../../../shared/helpers');
const { mapRowsFromDb } = require('../../../lib/dto-mapper');
const { logger } = require('../../../../shared/lib/logger');
const {
  CONFIG_MOUNTS, validateRuleWritePayload, validateGlobalRuleWritePayload, validateRulePutMerge,
  validateColumnTypes, enumDomainViolation, missingRequiredColumnOnCreate, validateFieldDefPutMerge, rejectIfFieldDefDuplicate, buildConfigTemplateDoc,
  makeAllowedDiskCombosCanonicalizer,
  CONFIG_DELETE_GUARDS, findCatalogueReferenceBlocker, safeRollback, reservedMetadataKeyError,
  lockGlobalConfig, dropAbsentColumns,
} = require('./_shared');

// (scenario_id, entity_type, field_key) uniqueness probe scoped to the
// global template layer (scenario_id IS NULL) — excludes `excludeId` (the
// row's own id) on a PUT so a no-op re-save of the same row never
// self-collides.
function fetchFieldDefDuplicate(table, excludeId) {
  return async (entityType, fieldKey) => {
    const rows = await pool.rw.query(
      `SELECT 1 FROM \`${t(table)}\` WHERE scenario_id IS NULL AND entity_type = ? AND field_key = ?`
      + (excludeId ? ' AND id != ?' : '') + ' LIMIT 1',
      excludeId ? [entityType, fieldKey, excludeId] : [entityType, fieldKey],
    );
    return rows.length > 0;
  };
}

const router = express.Router();

// Config groups whose GLOBAL rows carry an `order_index` (phase-6 spec §D3): the
// catalogue tables rendered as drag-sortable dual-mode grids on the config page.
// Their list read sorts by that persisted order first (NULLs / ties fall back to
// created_at). field_defs / settings / rules have no order_index, so they keep
// the plain created_at order — ordering by a missing column would SQL-error.
const ORDERABLE_CONFIG_GROUPS = new Set(['hardware_specs', 'disk_combos', 'teams', 'vm_profiles']);

const dbError = (res) => {
  const e = apiError('Database operation failed', 'INTERNAL_ERROR', 500);
  res.status(e.status).json(e.body);
};

// Map a cap_field_defs DB duplicate-key error (the UNIQUE
// (scenario_id, entity_type, field_key) index) to the SAME 400 the app-layer
// uniqueness pre-check produces, so the response is byte-identical whichever
// layer wins the race. Returns the apiError shape, or null when `err` is not a
// duplicate-key error. `err.errno === 1062` / `err.code === 'ER_DUP_ENTRY'` is
// the MariaDB duplicate-entry signal.
function fieldDefDuplicateError(err, body) {
  if (!err || (err.errno !== 1062 && err.code !== 'ER_DUP_ENTRY')) return null;
  return apiError(
    `a field_key "${body && body.field_key}" already exists for entity_type "${body && body.entity_type}"`,
    'BAD_REQUEST', 400,
  );
}

// Runs a group's optional `types` (per-column type guard) and `validate`
// (whole-body cross-column check, e.g. field_defs' reserved-key rule)
// against the RAW request body — BEFORE collectWrite's JSON stringification,
// so `typeof` sees the value shape the client actually sent, not a
// stringified stand-in. Returns an error message, or null.
function validateGroupWrite(def, body) {
  // THE COLUMN'S OWN DOMAIN COMES FIRST, and the order is the whole point. The
  // `validate` hook below is a set of JavaScript identity lookups on the raw
  // body — `body.entity_type === 'scenario'`, `ENTITY_NATIVE_FIELD_KEYS[
  // body.entity_type]`, `body.data_type === 'enum'` — and the columns those
  // values land in fold case and read an INTEGER as a 1-based member index. So
  // `'Scenario'` and `1` both ARE the one value the first of those refuses, and
  // `'Vm'` makes the second look up `undefined` and SKIP the collision check
  // rather than fail it. Refusing a value the column would fold before any of
  // them compares means each is looking at the value the row will hold, instead
  // of each having to learn the column's equality for itself.
  const domainErr = enumDomainViolation(def.table, body);
  if (domainErr) return domainErr;
  if (def.types) {
    const typeErr = validateColumnTypes(body, def.types);
    if (typeErr) return typeErr;
  }
  if (def.validate) {
    const err = def.validate(body);
    if (err) return err;
  }
  return null;
}

// Build the INSERT/UPDATE column set from the request body, restricted to the
// group's writable columns. JSON columns are stringified; scenario_id is never
// taken from the body (forced NULL on insert, never rewritten on update).
function collectWrite(def, body) {
  const cols = [];
  const values = [];
  for (const col of def.cols) {
    if (!Object.prototype.hasOwnProperty.call(body, col)) continue;
    let v = body[col];
    if (def.json.includes(col) && v !== null && typeof v === 'object') v = JSON.stringify(v);
    cols.push(col);
    values.push(v);
  }
  return { cols, values };
}

// GET /config/export — the global template layer as a snapshot-shaped
// { schema_rev, tables } document (read = all authenticated, mirroring scenario
// export). Only the config tables that carry a template layer appear. Global
// config IMPORT is intentionally not offered here (export only). Declared before
// the per-group loop; 'export' is not a group name so there is no path clash.
router.get('/export', async (req, res) => {
  if (!requireAuth(req, res)) return;
  try {
    const doc = await buildConfigTemplateDoc(pool.ro);
    res.json(apiOk(doc));
  } catch (err) {
    logger.error({ err }, 'Failed to export capacity global config');
    dbError(res);
  }
});

for (const [group, def] of Object.entries(CONFIG_MOUNTS)) {
  const table = def.table;

  // GET /config/:group — list template rows (all authenticated).
  router.get(`/${group}`, async (req, res) => {
    if (!requireAuth(req, res)) return;
    try {
      // Reorderable catalogues sort by their persisted drag order first (spec §D3);
      // a NULL/tie order_index falls back to created_at so a pre-reorder row set is
      // still deterministic. Non-orderable groups keep the plain created_at order.
      const orderBy = ORDERABLE_CONFIG_GROUPS.has(group)
        ? 'ORDER BY order_index ASC, created_at ASC'
        : 'ORDER BY created_at ASC';
      const rows = await pool.ro.query(
        `SELECT * FROM \`${t(table)}\` WHERE scenario_id IS NULL ${orderBy}`,
      );
      res.json(apiOk(mapRowsFromDb(table, rows)));
    } catch (err) {
      logger.error({ err, table }, `Failed to list capacity config ${group}`);
      dbError(res);
    }
  });

  // GET /config/:group/:id — one template row.
  router.get(`/${group}/:id`, async (req, res) => {
    if (!requireAuth(req, res)) return;
    try {
      const rows = await pool.ro.query(
        `SELECT * FROM \`${t(table)}\` WHERE id = ? AND scenario_id IS NULL`,
        [req.params.id],
      );
      if (!rows.length) {
        const e = apiError('Not found', 'NOT_FOUND', 404);
        return res.status(e.status).json(e.body);
      }
      res.json(apiOk(mapRowsFromDb(table, rows)[0]));
    } catch (err) {
      logger.error({ err, table }, `Failed to fetch capacity config ${group}`);
      dbError(res);
    }
  });

  // POST /config/:group — create a template row (admin+editor).
  router.post(`/${group}`, async (req, res) => {
    if (!requireAdminOrEditor(req, res)) return;
    const validationErr = validateGroupWrite(def, req.body || {});
    if (validationErr) {
      const e = apiError(validationErr, 'BAD_REQUEST', 400);
      return res.status(e.status).json(e.body);
    }
    // Reject a reserved prototype key in the metadata payload (local catalogues
    // hardware_specs/vm_profiles carry a metadata column) — the raw-API half of the
    // reject-at-the-source invariant io.js enforces for bulk import.
    {
      const metaErr = reservedMetadataKeyError(req.body && req.body.metadata);
      if (metaErr) {
        const e = apiError(metaErr.message, metaErr.code, 400);
        return res.status(e.status).json(e.body);
      }
    }
    // Rule scope/params carry extra DoS bounds (condition count + JSON size)
    // and a per-type scope.level check on top of the generic type guard above.
    if (group === 'rules') {
      // A global template row may not be an override (overrides_rule_id) nor
      // reference a custom group (custom groups are scenario-level) — spec §17.1.
      const badGlobal = validateGlobalRuleWritePayload(req.body || {});
      if (badGlobal) {
        const e = apiError(badGlobal.message, badGlobal.code, 400);
        return res.status(e.status).json(e.body);
      }
      const bad = validateRuleWritePayload(req.body || {}, { strictType: true });
      if (bad) {
        const e = apiError(bad.message, bad.code, 400);
        return res.status(e.status).json(e.body);
      }
    }
    // (scenario_id, entity_type, field_key) uniqueness guard (Codex r2) —
    // two global-template field_defs rows for the same entity_type/field_key
    // would both own the identical metadata JSON key.
    if (group === 'field_defs') {
      try {
        const dupErr = await rejectIfFieldDefDuplicate(
          fetchFieldDefDuplicate(table, null), req.body && req.body.entity_type, req.body && req.body.field_key,
        );
        if (dupErr) {
          const e = apiError(dupErr, 'BAD_REQUEST', 400);
          return res.status(e.status).json(e.body);
        }
      } catch (err) {
        logger.error({ err, table }, `Failed to validate capacity config ${group} uniqueness`);
        return dbError(res);
      }
    }
    // Degraded-mode guard (C1): drop write columns a warn-skipped add-column
    // migration left absent (e.g. settings.name_patterns) so an old-schema DB
    // keeps saving the columns it has instead of 500-ing the whole write.
    // Probe on the WRITER pool, not an RO replica (codex r2): DDL can replicate
    // late, so a replica-derived probe may report the column absent and — since
    // the column-set cache never expires — cache that false absence for the
    // process lifetime, silently dropping the field on every write even after
    // the replica catches up. The writer always carries the current schema and
    // is where the INSERT below lands.
    const collected = collectWrite(def, req.body || {});
    const { cols, values } = await dropAbsentColumns(pool.rw, def.table, collected.cols, collected.values);
    // An empty/mismatched body would INSERT only (id, scenario_id) and 500 on the
    // NOT NULL columns (e.g. cap_rules.type/name). Reject cheaply, mirroring PUT.
    if (!cols.length) {
      const e = apiError('No writable fields supplied', 'BAD_REQUEST', 400);
      return res.status(e.status).json(e.body);
    }
    // A CREATE MUST NAME EVERY NOT-NULL-NO-DEFAULT COLUMN THE ENGINE WOULD
    // OTHERWISE HAVE TO SUPPLY ITSELF. There was no required-field check on any
    // config mount at all. On an ENUM that is not merely a missing value:
    // measured, an INSERT omitting a NOT NULL ENUM with no declared DEFAULT
    // stores the FIRST DECLARED MEMBER, silently. The sharpest instance is this
    // very route — `POST /config/field_defs {"field_key":"x","data_type":"text"}`
    // omits `entity_type`, whose first member is 'scenario', which is the one
    // value `validateFieldDefWrite` exists to refuse. The forbidden row is
    // created by not mentioning the column. A non-ENUM NOT NULL column (e.g.
    // `name`) omitted the same way fails loudly at the database instead, but
    // that failure reaches the caller as a 500 naming no column — fmb-1549's
    // same gap on a different type, closed here in the same call rather than
    // left for a second, type-filtered check to miss again.
    const missing = missingRequiredColumnOnCreate(def.table, cols, req.body || {});
    if (missing) {
      const e = apiError(missing, 'BAD_REQUEST', 400);
      return res.status(e.status).json(e.body);
    }
    const id = uuidv4();
    let conn;
    try {
      // Write + confirming read on the SAME primary connection: a pool.rw write
      // followed by a pool.ro read can hit a stale replica under an RO-replica
      // topology and return `data: undefined` (read-after-write race). The write
      // runs in a transaction that FIRST locks the global-config sentinel so it is
      // serialized against the first-instance config import's clear-then-insert
      // (P1: an ordinary create must not land a global row the import then wipes).
      conn = await pool.rw.getConnection();
      await conn.beginTransaction();
      await lockGlobalConfig(conn);
      // Reorderable catalogues (phase-6 spec §D3, Codex P2): a global create
      // appends at the END of the persisted drag order — order_index =
      // MAX(order_index)+1 within scenario_id IS NULL, read under the sentinel
      // lock so a create racing a reorder can't collide. Mirrors the append
      // pattern in makeAppendOrderIndexOnCreate (children.js) / the bundles
      // create (bundles.js). order_index is never in def.cols, so a client
      // cannot supply its own value here.
      if (ORDERABLE_CONFIG_GROUPS.has(group)) {
        const orderRows = await conn.query(
          `SELECT COALESCE(MAX(order_index), -1) + 1 AS next FROM \`${t(table)}\` WHERE scenario_id IS NULL`,
        );
        cols.push('order_index');
        values.push(Number(orderRows[0] ? orderRows[0].next : 0));
      }
      // vm_profiles: canonicalise a written allow-list to the referenced combos'
      // own spelling (fmb-1566 item 4a) — this mount builds cols/values as
      // parallel arrays, not the object the shared hook takes, so a small
      // wrapper round-trips the one column through it. `scenarioScopeOf(req)`
      // reads undefined here (no scenarioId URL param on the global mount),
      // which the hook treats as "global only" — the global write's own scope.
      if (group === 'vm_profiles') {
        const comboIdx = cols.indexOf('allowed_disk_combos');
        if (comboIdx !== -1) {
          const wrapper = { allowed_disk_combos: values[comboIdx] };
          // The hook can refuse (D5 review finding 1: an over-cap entry count) —
          // this bespoke handler does not go through createCrudRoutes' own
          // preWriteInTx dispatch, so it has to check the return itself, the same
          // way the factory does for local-catalogues.js's identical hook.
          const comboErr = await makeAllowedDiskCombosCanonicalizer()(conn, req, wrapper);
          if (comboErr) {
            await safeRollback(conn);
            const e = apiError(comboErr.message, comboErr.code, comboErr.status);
            return res.status(e.status).json(e.body);
          }
          values[comboIdx] = wrapper.allowed_disk_combos;
        }
      }
      const allCols = ['id', 'scenario_id', ...cols];
      const quoted = allCols.map((c) => `\`${c}\``).join(', ');
      if (def.singleton) {
        // Cardinality: at most one global-default row (cap_settings). Enforced
        // race-safely as a SINGLE atomic statement — INSERT ... SELECT ... WHERE
        // NOT EXISTS — so two concurrent POSTs cannot both pass a separate
        // read-then-insert check. affectedRows === 0 ⇒ a row already exists ⇒ 409.
        const placeholders = allCols.map(() => '?');
        const result = await conn.query(
          `INSERT INTO \`${t(table)}\` (${quoted}) `
          + `SELECT ${placeholders.join(', ')} FROM DUAL `
          + `WHERE NOT EXISTS (SELECT 1 FROM \`${t(table)}\` WHERE scenario_id IS NULL)`,
          [id, null, ...values],
        );
        if (!result.affectedRows) {
          await safeRollback(conn);
          const e = apiError(
            `A global ${group} row already exists; update it instead of creating another`,
            'CONFLICT', 409,
          );
          return res.status(e.status).json(e.body);
        }
      } else {
        const placeholders = allCols.map(() => '?');
        await conn.query(
          `INSERT INTO \`${t(table)}\` (${quoted}) VALUES (${placeholders.join(', ')})`,
          [id, null, ...values],
        );
      }
      const rows = await conn.query(
        `SELECT * FROM \`${t(table)}\` WHERE id = ?`, [id],
      );
      await conn.commit();
      res.status(201).json(apiOk(mapRowsFromDb(table, rows)[0]));
    } catch (err) {
      await safeRollback(conn);
      if (group === 'field_defs') {
        const dup = fieldDefDuplicateError(err, req.body || {});
        if (dup) return res.status(dup.status).json(dup.body);
      }
      logger.error({ err, table }, `Failed to create capacity config ${group}`);
      dbError(res);
    } finally {
      if (conn) conn.release();
    }
  });

  // PUT /config/:group/:id — update a template row (admin+editor). The
  // scenario_id IS NULL predicate keeps the write off scenario-owned rows.
  router.put(`/${group}/:id`, async (req, res) => {
    if (!requireAdminOrEditor(req, res)) return;
    const validationErr = validateGroupWrite(def, req.body || {});
    if (validationErr) {
      const e = apiError(validationErr, 'BAD_REQUEST', 400);
      return res.status(e.status).json(e.body);
    }
    // Reject a reserved prototype key in the metadata payload (local catalogues
    // hardware_specs/vm_profiles carry a metadata column) — the raw-API half of the
    // reject-at-the-source invariant io.js enforces for bulk import.
    {
      const metaErr = reservedMetadataKeyError(req.body && req.body.metadata);
      if (metaErr) {
        const e = apiError(metaErr.message, metaErr.code, 400);
        return res.status(e.status).json(e.body);
      }
    }
    // Rule scope/params carry extra DoS bounds (condition count + JSON size)
    // and a per-type scope.level check on top of the generic type guard above.
    if (group === 'rules') {
      // A global template row may not be an override (overrides_rule_id) nor
      // reference a custom group (custom groups are scenario-level) — spec §17.1.
      const badGlobal = validateGlobalRuleWritePayload(req.body || {});
      if (badGlobal) {
        const e = apiError(badGlobal.message, badGlobal.code, 400);
        return res.status(e.status).json(e.body);
      }
      const bad = validateRuleWritePayload(req.body || {}, { strictType: true });
      if (bad) {
        const e = apiError(bad.message, bad.code, 400);
        return res.status(e.status).json(e.body);
      }
      // Merged-state check: a partial PUT that moves `level`/`group_by` without
      // resending `type` skips validateRuleWritePayload's per-type checks (they
      // only fire on a present `type`). Read the stored row (global scope) and
      // re-validate the true final state.
      try {
        const mergeErr = await validateRulePutMerge(
          async () => {
            const existing = await pool.rw.query(
              `SELECT type, level, group_by FROM \`${t(table)}\` WHERE id = ? AND scenario_id IS NULL`,
              [req.params.id],
            );
            return existing[0] || null;
          },
          req.body || {},
          { strictType: true },
        );
        if (mergeErr) {
          const e = apiError(mergeErr.message, mergeErr.code, 400);
          return res.status(e.status).json(e.body);
        }
      } catch (err) {
        logger.error({ err, table }, `Failed to validate capacity config ${group} merge state`);
        return dbError(res);
      }
    }
    // field_defs' enum/options sentinel check AND native-column key-collision
    // check are body-only in validateGroupWrite (both columns of the RELEVANT
    // pair present in the SAME request) — a PUT touching only ONE of
    // data_type/options, or only ONE of entity_type/field_key, relies on the
    // row's already-stored value for the other, so the TRUE final state can
    // only be checked by reading the current row first (partial-update gap
    // fix, Review Gate finding, Codex r1 + r2 — r2 also re-runs the
    // (scenario_id, entity_type, field_key) uniqueness guard here whenever
    // the key tuple could have moved).
    if (group === 'field_defs') {
      try {
        const mergeErr = await validateFieldDefPutMerge(
          async () => {
            const rows = await pool.rw.query(
              `SELECT entity_type, field_key, data_type, options FROM \`${t(table)}\` WHERE id = ? AND scenario_id IS NULL`,
              [req.params.id],
            );
            return rows[0] || null;
          },
          fetchFieldDefDuplicate(table, req.params.id),
          req.body || {},
        );
        if (mergeErr) {
          const e = apiError(mergeErr, 'BAD_REQUEST', 400);
          return res.status(e.status).json(e.body);
        }
      } catch (err) {
        logger.error({ err, table }, `Failed to validate capacity config ${group} merge state`);
        return dbError(res);
      }
    }
    // Degraded-mode guard (C1): drop columns a warn-skipped add-column migration
    // left absent so an old-schema DB keeps updating the columns it has. Probe on
    // the WRITER pool, not an RO replica (codex r2): a lagging replica can report
    // the column absent and the never-expiring column-set cache would then drop
    // the field on every write for the process lifetime — see the create path.
    const collectedPut = collectWrite(def, req.body || {});
    const { cols, values } = await dropAbsentColumns(pool.rw, def.table, collectedPut.cols, collectedPut.values);
    if (!cols.length) {
      const e = apiError('No writable fields supplied', 'BAD_REQUEST', 400);
      return res.status(e.status).json(e.body);
    }
    let conn;
    try {
      // Same primary connection for UPDATE + confirming SELECT — a pool.ro
      // read-back can lag the write on an RO-replica topology (read-after-write).
      // The write is serialized against the config import via the global-config
      // sentinel lock (P1), taken first inside the transaction.
      conn = await pool.rw.getConnection();
      await conn.beginTransaction();
      await lockGlobalConfig(conn);
      // vm_profiles: canonicalise a written allow-list the same way the create
      // path does above (fmb-1566 item 4a) — a partial PUT that does not touch
      // allowed_disk_combos is unaffected (comboIdx stays -1).
      if (group === 'vm_profiles') {
        const comboIdx = cols.indexOf('allowed_disk_combos');
        if (comboIdx !== -1) {
          const wrapper = { allowed_disk_combos: values[comboIdx] };
          // See the create path's identical check above (D5 review finding 1).
          const comboErr = await makeAllowedDiskCombosCanonicalizer()(conn, req, wrapper);
          if (comboErr) {
            await safeRollback(conn);
            const e = apiError(comboErr.message, comboErr.code, comboErr.status);
            return res.status(e.status).json(e.body);
          }
          values[comboIdx] = wrapper.allowed_disk_combos;
        }
      }
      const sets = cols.map((c) => `\`${c}\` = ?`).join(', ');
      const result = await conn.query(
        `UPDATE \`${t(table)}\` SET ${sets} WHERE id = ? AND scenario_id IS NULL`,
        [...values, req.params.id],
      );
      if (!result.affectedRows) {
        await safeRollback(conn);
        const e = apiError('Not found', 'NOT_FOUND', 404);
        return res.status(e.status).json(e.body);
      }
      const rows = await conn.query(
        `SELECT * FROM \`${t(table)}\` WHERE id = ?`, [req.params.id],
      );
      await conn.commit();
      res.json(apiOk(mapRowsFromDb(table, rows)[0]));
    } catch (err) {
      await safeRollback(conn);
      if (group === 'field_defs') {
        const dup = fieldDefDuplicateError(err, req.body || {});
        if (dup) return res.status(dup.status).json(dup.body);
      }
      logger.error({ err, table }, `Failed to update capacity config ${group}`);
      dbError(res);
    } finally {
      if (conn) conn.release();
    }
  });

  // DELETE /config/:group/:id — delete a template row (admin+editor). A guarded
  // catalogue group (hardware_specs / vm_profiles / disk_combos / teams) refuses
  // 409 while any live row still references it (config-rewrite obligation 3);
  // frozen version snapshots never block (they embed their own resolved closure).
  const deleteGuard = CONFIG_DELETE_GUARDS[group];
  router.delete(`/${group}/:id`, async (req, res) => {
    if (!requireAdminOrEditor(req, res)) return;
    if (!deleteGuard) {
      // Unguarded groups (field_defs / settings): delete under the global-config
      // sentinel lock (P1) so a delete concurrent with the config import serializes.
      let conn;
      try {
        conn = await pool.rw.getConnection();
        await conn.beginTransaction();
        await lockGlobalConfig(conn);
        const result = await conn.query(
          `DELETE FROM \`${t(table)}\` WHERE id = ? AND scenario_id IS NULL`,
          [req.params.id],
        );
        if (!result.affectedRows) {
          await safeRollback(conn);
          const e = apiError('Not found', 'NOT_FOUND', 404);
          return res.status(e.status).json(e.body);
        }
        await conn.commit();
        res.json(apiOk({ id: req.params.id, deleted: true }));
      } catch (err) {
        await safeRollback(conn);
        logger.error({ err, table }, `Failed to delete capacity config ${group}`);
        dbError(res);
      } finally {
        if (conn) conn.release();
      }
      return;
    }
    // Guarded catalogue: lock the global row, probe references, delete — one tx
    // so a reference committed after the probe cannot slip past the guard.
    // INVARIANT: the child-write vs catalogue-delete race is now closed on BOTH
    // sides. A scenario CHILD write that references a catalogue row runs its §17.1a
    // FK check FOR UPDATE on the same catalogue row inside its own write tx
    // (children.js preWriteInTx → makeScenarioFkLockValidator). So this DELETE and a
    // concurrent child INSERT contend on the same FOR UPDATE lock: either this
    // commits first (the child's locked probe then finds the row gone → 400) or the
    // child commits first (this blocker probe then sees the new reference → 409).
    // Neither can dangle the FK.
    let conn;
    try {
      conn = await pool.rw.getConnection();
      await conn.beginTransaction();
      // Serialize against the config import (P1) — sentinel lock first, then the
      // target row, keeping cap_settings the first lock in every global-config path.
      await lockGlobalConfig(conn);
      const rows = await conn.query(
        `SELECT id FROM \`${t(table)}\` WHERE id = ? AND scenario_id IS NULL FOR UPDATE`,
        [req.params.id],
      );
      if (!rows.length) {
        await safeRollback(conn);
        const e = apiError('Not found', 'NOT_FOUND', 404);
        return res.status(e.status).json(e.body);
      }
      // Bind the STORED id, not the request's. The row above was resolved under
      // the column's case-folding collation, so `rows[0].id` is the spelling the
      // database holds; `findCatalogueReferenceBlocker`'s allow-list probe is a
      // byte-exact `JSON_CONTAINS`, and fed a respelled request id it would miss a
      // live reference and delete a still-referenced row.
      const blocker = await findCatalogueReferenceBlocker(conn, group, rows[0].id);
      if (blocker) {
        await safeRollback(conn);
        const e = apiError(
          `Cannot delete this ${deleteGuard.label} while ${blocker} references it`,
          'CONFLICT', 409,
        );
        return res.status(e.status).json(e.body);
      }
      await conn.query(
        `DELETE FROM \`${t(table)}\` WHERE id = ? AND scenario_id IS NULL`, [req.params.id],
      );
      await conn.commit();
      res.json(apiOk({ id: req.params.id, deleted: true }));
    } catch (err) {
      await safeRollback(conn);
      logger.error({ err, table }, `Failed to delete capacity config ${group}`);
      dbError(res);
    } finally {
      if (conn) conn.release();
    }
  });
}

module.exports = router;
