/**
 * @openapi
 * /edge/app/capacity/scenarios/{scenarioId}/databases/bulk-create:
 *   post:
 *     tags: [App - Capacity]
 *     summary: Create one database + its instances (+ optional new db_host VMs) in one transaction (owner+admin).
 *     description: >
 *       The Add-Database wizard's persist endpoint (placement-hub spec §3/§11). One
 *       request materializes a single database, its topology-correct db_instances,
 *       and any new db_host VMs the placement step asked for — all in ONE
 *       transaction into an EXISTING scenario, referencing the global catalogues by
 *       FK (reference model). Any invalid row rejects the whole request and nothing
 *       is written.
 *     responses:
 *       201: { description: Created database id + instance ids + new VM ids }
 *       400: { description: Validation failed — nothing written (per-row details) }
 *       403: { description: Not the scenario owner (and not admin) }
 *       404: { description: Scenario not found }
 *       413: { description: Payload too large }
 */

/**
 * capacity/database-bulk-create.js — the Add-Database wizard's transactional
 * persist endpoint (placement-hub spec §3 step 3, §11).
 *
 * ONE DATABASE, EXISTING SCENARIO. Unlike wizard.js (which mints a whole
 * scenario), this writes into a scenario the caller already owns: one database,
 * its instances, and the new db_host VMs the placement step created. It reuses
 * the SAME single-source invariants the per-row child creates and the setup
 * wizard use, never a forked copy:
 *   - topology cardinality              → wizard.js `expectedInstanceCounts`
 *   - catalogue + scenario reference-integrity, under a FOR UPDATE lock, with the
 *     canonical-spelling rebind → reference-integrity.js `checkReferences`, driven
 *     off the SAME `CHILD_FK_VALIDATIONS` specs the child mounts run
 *   - per-role instance SGA derivation  → sga-defaults.js `deriveInstanceSga`
 *   - VM sizing + disk-combo allow-list → _shared.js `resolveProfileSizing` /
 *     `sumDiskComboSizes` / `diskComboAllowed`
 *   - scenario write authz              → _shared.js `resolveScenarioWriteAccess`
 *     (admin always; an editor only for a shared or self-owned scenario — the
 *     SAME gate the databases child POST resolves via parentOwnership)
 *
 * SGA IS SERVER-DERIVED, NOT CLIENT-WRITTEN (children.js:150 immutable rule /
 * spec §6.3). An instance's `sga_gb` is derived by role from the DATABASE's
 * primary_sga_gb / standby_sga_gb seeds + the scenario-effective standby default
 * + (primary) the database profile's SGA cap. A per-instance `sga_gb` in the
 * payload is IGNORED, exactly as the generic db_instances POST and the setup
 * wizard ignore it — the wizard's step-2 "sga tweak" is a write of the two
 * DATABASE-level seeds, never a raw instance value.
 *
 * AN INSTANCE ALWAYS HAS A db_host VM (cap_db_instances.vm_id is NOT NULL). So
 * "leave unplaced (tray)" is NOT a VM-less instance — it is a new db_host VM with
 * `hypervisor_id: null` (an unplaced tray VM, cap_vms.hypervisor_id NULL) that
 * still carries the instance. The three step-3 choices therefore reduce to two
 * placement shapes: attach to an existing db_host VM, or create a new one (placed
 * when a hypervisor is named, trayed when it is not).
 */
'use strict';

const express = require('express');
const { pool, t } = require('../../../db');
const {
  requireAdminOrEditor, apiOk, apiError, uuidv4,
} = require('../../../../shared/helpers');
const { TABLES } = require('../../../../shared/constants');
const { logger } = require('../../../../shared/lib/logger');
const { checkReferences, canonicalKey } = require('./reference-integrity');
const {
  safeRollback, resolveScenarioWriteAccess, reservedMetadataKeyError,
  readFormulaConstants, resolveProfileSizing, sumDiskComboSizes, diskComboAllowed,
  CHILD_FK_VALIDATIONS, VM_FUNCTION_NAME_RE, DATABASE_FUNCTION_NAME_CHARSET_MSG,
  tableColumnSet, isRenamedTopologySchemaSupported, TOPOLOGY_SCHEMA_UNSUPPORTED_MSG,
} = require('./_shared');
const { deriveInstanceSga } = require('../../../../shared/capacity/sga-defaults');
const { TOPOLOGY, TOPOLOGY_VALUES } = require('../../../../shared/capacity/topology');
const { expectedInstanceCounts, RAC_MIN_NODES, RAC_MAX_NODES } = require('./wizard');
const { writeConflictError } = require('../schema/crud-factory');

const router = express.Router();

const MAX_NAME = 255;
const MAX_DESCRIPTION = 120; // Matches the setup wizard's per-database description cap (§15.5).
// RAC_MIN_NODES/RAC_MAX_NODES: TOPO-R1 — imported from wizard.js (above)
// instead of a 2nd hand-declared `2`/`100`; wizard.js's own copies derive from
// the topology.js mirror's `TOPOLOGY_NODE_DEFS.rac_multinode.primary` bounds.
// DoS bound: each accepted instance is one awaited INSERT (plus at most one VM
// INSERT) inside a single held transaction, so an unbounded array from an
// authenticated editor is a write-pool exhaustion vector. Sits comfortably above
// a plain RAC's 100-node ceiling (N primary, no standby side) and short-circuits
// (413) BEFORE any per-row work.
//
// F5 note: rac_standby's total is N + S (up to 2×100=200 when S defaults to N
// via the Add-Database dialog, which has no S-override field — S always = N
// there), so this bound is REACHABLE past N=64 (2×64=128) for that topology —
// not raised. The dialog pre-checks 2N <= MAX_INSTANCES client-side
// (add-database-wizard-model.ts isValidTotalInstances) so a legal-by-node-count-
// clamp N never surfaces this as an opaque 413; a direct caller of this
// endpoint that skips the client check still gets a clean 413 here.
const MAX_INSTANCES = 128;
const MAX_METADATA_BYTES = 8192; // Mirrors wizard.js / _shared.js MAX_RULE_JSON_BYTES.

const TOPOLOGIES = new Set(TOPOLOGY_VALUES);
const INSTANCE_ROLES = new Set(['primary', 'standby']);

// Columns each INSERT writes — the SINGLE source shared by the insert builder and
// the schema-parity test, so a column the statement writes cannot drift from the
// column the test proves exists (mocked runners paint a wrong identifier green).
// dc_refs is intentionally absent: the Add-Database wizard step 1 collects no DC
// restriction, so the column keeps its NULL default (= all DCs), inheritance-
// semantic — never coalesced.
const INSERT_COLUMNS = Object.freeze({
  [TABLES.CAP_DATABASES]: ['id', 'scenario_id', 'function_name', 'topology', 'node_count',
    'standby_node_count',
    'profile_id', 'disk_combo_id', 'team_id', 'primary_sga_gb', 'standby_sga_gb',
    'description', 'order_index', 'metadata'],
  [TABLES.CAP_VMS]: ['id', 'scenario_id', 'vm_type', 'hypervisor_id', 'site_id',
    'cpu', 'mem_gb', 'disk_gb', 'sizing_profile_id', 'disk_combo_id', 'team_id',
    'database_id', 'name', 'order_index', 'metadata'],
  [TABLES.CAP_DB_INSTANCES]: ['id', 'scenario_id', 'vm_id', 'database_id', 'name',
    'role', 'sga_gb', 'order_index', 'metadata'],
});

// Columns each SELECT reads — the schema-parity companion to INSERT_COLUMNS for
// the read-only hydration statements (a wrong identifier here 500s a path no
// mocked runner reaches).
const READ_COLUMNS = Object.freeze({
  [TABLES.CAP_SETTINGS]: ['mem_cpu_ratio', 'sga_factor', 'sga_divisor', 'sga_subtract', 'standby_sga_default_gb'],
  [TABLES.CAP_VM_PROFILES]: ['id', 'class', 'mode', 'cpu', 'mem_gb', 'sga_cap_gb', 'allowed_disk_combos'],
  [TABLES.CAP_DISK_COMBOS]: ['id', 'sizes'],
  [TABLES.CAP_HYPERVISORS]: ['site_id'],
});

const isNonEmptyString = (v) => typeof v === 'string' && v.trim() !== '';
const isPositiveInt = (v) => Number.isInteger(v) && v > 0;
const isNonNegNumber = (v) => typeof v === 'number' && Number.isFinite(v) && v >= 0;
const isNullableString = (v) => v == null || typeof v === 'string';
// A JSON column value: an object/array is re-stringified for storage; null/absent
// stays absent (DB default). A non-object is rejected by the caller's field check.
const jsonForStore = (v) => (v !== null && typeof v === 'object' ? JSON.stringify(v) : v);

// True when a metadata value serializes past the byte cap (or cannot serialize).
function metadataTooLarge(meta) {
  if (meta == null || typeof meta !== 'object') return false;
  let serialized;
  try { serialized = JSON.stringify(meta); } catch { return true; }
  return typeof serialized === 'string' && Buffer.byteLength(serialized, 'utf8') > MAX_METADATA_BYTES;
}

// metadata field check: an object (or absent) within the byte cap and with no
// reserved prototype key — the raw-API half of the reject-at-the-source invariant
// shared with the import / child-CRUD / wizard paths.
function metaError(label, meta) {
  if (meta != null && typeof meta !== 'object') return `${label}: metadata must be an object`;
  if (metadataTooLarge(meta)) return `${label}: metadata exceeds ${MAX_METADATA_BYTES} bytes`;
  const rk = reservedMetadataKeyError(meta);
  if (rk) return `${label}: ${rk.message}`;
  return null;
}

/**
 * Validate the whole payload PURELY (no I/O) and, on success, return the resolved
 * build plan (minted ids + placement resolution). Returns
 * `{ ok:false, errors:[string] }`, `{ ok:false, tooLarge:true, errors }`, or
 * `{ ok:true, plan }`. Structural coherence + topology cardinality are checked
 * here; the catalogue/scenario reference-integrity check runs later against the
 * DB (it needs the FOR UPDATE lock).
 */
function buildDatabaseBulkPlan(body) {
  const errors = [];
  // Set only when database.profile_id itself is the violation, so the route can
  // answer 400 COLUMN_REQUIRED (a cheap, nameable refusal) instead of the
  // catch-all BAD_REQUEST every other structural mistake gets.
  let columnRequiredMessage = null;
  const b = body && typeof body === 'object' ? body : {};

  // ── database basics ────────────────────────────────────────────────────────
  const d = b.database && typeof b.database === 'object' ? b.database : null;
  if (!d) errors.push('database is required');

  const database = { id: uuidv4() };
  if (d) {
    if (!isNonEmptyString(d.function_name)) errors.push('database: function_name is required');
    else if (d.function_name.length > MAX_NAME) errors.push(`database: function_name exceeds ${MAX_NAME} characters`);
    database.function_name = d.function_name;

    if (!TOPOLOGIES.has(d.topology)) errors.push(`database: topology must be one of ${TOPOLOGY_VALUES.join(', ')}`);
    database.topology = d.topology;

    let nodeCount = null;
    if (d.topology === TOPOLOGY.RAC_MULTINODE || d.topology === TOPOLOGY.RAC_MULTINODE_STANDBY) {
      if (!isPositiveInt(d.node_count) || d.node_count < RAC_MIN_NODES || d.node_count > RAC_MAX_NODES) {
        errors.push(`database: RAC node_count must be an integer >= ${RAC_MIN_NODES} and <= ${RAC_MAX_NODES}`);
      } else {
        nodeCount = d.node_count;
      }
    }
    database.node_count = nodeCount;

    // rac_standby's standby side (S, spec §7 E1 / Q11): independently
    // overridable, no clustering floor (S=1 is legal) — same [1, RAC_MAX_NODES]
    // window RAC's own cap uses.
    //
    // F1 fix (mirrors wizard.js's own copy of this rule): an OMITTED
    // standby_node_count defaults to N (nodeCount), not an error — "S defaults
    // to N" (Q11) must hold for ANY caller of this endpoint, not just the
    // Add-Database dialog (which always sends a concrete N today, since it has
    // no S-override field — see add-database-wizard-model.ts). A PRESENT but
    // malformed value (string, negative, oversized) still 400s.
    let standbyNodeCount = null;
    if (d.topology === TOPOLOGY.RAC_MULTINODE_STANDBY) {
      if (d.standby_node_count == null) {
        standbyNodeCount = nodeCount;
      } else if (!isPositiveInt(d.standby_node_count) || d.standby_node_count > RAC_MAX_NODES) {
        errors.push(`database: RAC + Standby standby_node_count must be an integer >= 1 and <= ${RAC_MAX_NODES}`);
      } else {
        standbyNodeCount = d.standby_node_count;
      }
    }
    database.standby_node_count = standbyNodeCount;

    // profile_id is REQUIRED, not merely nullable-string. The Add-Database
    // wizard's client-side step gates submission on a chosen profile, but that
    // gate is UI-only — a direct POST to this endpoint (or a future caller that
    // forgets the gate) could otherwise persist a database with no profile, and
    // by extension a zero-sized ("Custom") primary instance/VM chain, breaking
    // the no-zero-row invariant the wizard exists to guarantee. Enforcing it
    // here, not just in the FE model, is the fix for that gap (this finding).
    if (!isNonEmptyString(d.profile_id)) {
      const msg = 'database: profile_id is required';
      errors.push(msg);
      columnRequiredMessage = msg;
    }
    database.profile_id = d.profile_id ?? null;

    for (const col of ['disk_combo_id', 'team_id']) {
      if (!isNullableString(d[col])) errors.push(`database: ${col} must be a string`);
      database[col] = d[col] ?? null;
    }

    // Row-level SGA seeds (spec §6.1): inheritance-semantic nullable — absent/null
    // means "derive". A present value must be a non-negative WHOLE number (fmb-1433).
    for (const col of ['primary_sga_gb', 'standby_sga_gb']) {
      if (d[col] == null) { database[col] = null; continue; }
      if (!isNonNegNumber(d[col])) errors.push(`database: ${col} must be a non-negative number`);
      else if (!Number.isInteger(d[col])) errors.push(`database: ${col} must be a whole number`);
      database[col] = d[col];
    }

    if (d.description != null && typeof d.description !== 'string') errors.push('database: description must be a string');
    else if (typeof d.description === 'string' && d.description.length > MAX_DESCRIPTION) {
      errors.push(`database: description exceeds ${MAX_DESCRIPTION} characters`);
    }
    database.description = d.description ?? null;

    const dbMeta = metaError('database', d.metadata); if (dbMeta) errors.push(dbMeta);
    database.metadata = d.metadata ?? null;
  }

  // ── instances + placement ──────────────────────────────────────────────────
  let instancesRaw = b.instances;
  if (instancesRaw == null) instancesRaw = [];
  if (!Array.isArray(instancesRaw)) { errors.push('instances must be an array'); instancesRaw = []; }
  if (instancesRaw.length > MAX_INSTANCES) {
    return { ok: false, tooLarge: true, errors: [`instances exceeds the maximum of ${MAX_INSTANCES} rows`] };
  }

  const instances = [];
  const newVms = [];
  const counts = { primary: 0, standby: 0 };
  instancesRaw.forEach((row, i) => {
    const r = row && typeof row === 'object' ? row : {};
    const label = `instances[${i}]`;
    if (!isNonEmptyString(r.name)) errors.push(`${label}: name is required`);
    else if (r.name.length > MAX_NAME) errors.push(`${label}: name exceeds ${MAX_NAME} characters`);
    if (!INSTANCE_ROLES.has(r.role)) errors.push(`${label}: role must be primary or standby`);
    else counts[r.role] += 1;
    // A standby instance is legal only under a database whose topology has a
    // standby side (§10.1; rac_multinode_standby joins primary_standby, spec
    // §7 E1 / Q11).
    if (r.role === 'standby' && database.topology !== TOPOLOGY.PRIMARY_STANDBY
      && database.topology !== TOPOLOGY.RAC_MULTINODE_STANDBY) {
      errors.push(`${label}: a standby instance is only allowed under a primary_standby or rac_multinode_standby database`);
    }
    const instMeta = metaError(label, r.metadata); if (instMeta) errors.push(instMeta);

    // Placement: EXACTLY ONE of { vm_id } | { new_vm } (an instance always has a
    // db_host VM — cap_db_instances.vm_id NOT NULL). `sga_gb` on the instance is
    // NOT read: it is server-derived by role.
    const p = r.placement && typeof r.placement === 'object' ? r.placement : null;
    let placement = null;
    if (!p) {
      errors.push(`${label}: placement is required (an instance must attach to a db_host VM)`);
    } else {
      const hasExisting = p.vm_id != null;
      const hasNew = p.new_vm != null;
      if (hasExisting === hasNew) {
        errors.push(`${label}: placement must name exactly one of vm_id or new_vm`);
      } else if (hasExisting) {
        if (!isNonEmptyString(p.vm_id)) errors.push(`${label}: placement.vm_id must be a string`);
        placement = { existingVmId: p.vm_id };
      } else {
        const nv = p.new_vm && typeof p.new_vm === 'object' ? p.new_vm : {};
        const vmLabel = `${label}.new_vm`;
        const vm = { id: uuidv4() };
        if (!isNonEmptyString(nv.name)) errors.push(`${vmLabel}: name is required`);
        else if (nv.name.length > MAX_NAME) errors.push(`${vmLabel}: name exceeds ${MAX_NAME} characters`);
        vm.name = nv.name;
        // hypervisor_id null/absent = unplaced (tray).
        if (!isNullableString(nv.hypervisor_id)) errors.push(`${vmLabel}: hypervisor_id must be a string`);
        vm.hypervisor_id = nv.hypervisor_id ?? null;
        for (const col of ['disk_combo_id', 'team_id']) {
          if (!isNullableString(nv[col])) errors.push(`${vmLabel}: ${col} must be a string`);
          vm[col] = nv[col] ?? null;
        }
        // sizing_profile_id: an explicit value still validates as any other
        // nullable-string catalogue FK. null/absent INHERITS database.profile_id
        // — the SAME default the wizard's own FE model already applies
        // (add-database-wizard-model.ts `buildDatabaseBulkPayload`, `new_vm:
        // { sizing_profile_id: basics.profileId }`), so a client that omits it
        // does not silently land an unsized ("Custom") db_host VM now that the
        // database's own profile is mandatory.
        if (!isNullableString(nv.sizing_profile_id)) errors.push(`${vmLabel}: sizing_profile_id must be a string`);
        vm.sizing_profile_id = nv.sizing_profile_id != null ? nv.sizing_profile_id : database.profile_id;
        for (const col of ['cpu', 'mem_gb', 'disk_gb']) {
          if (nv[col] != null && !isNonNegNumber(nv[col])) errors.push(`${vmLabel}: ${col} must be a non-negative number`);
          vm[col] = nv[col] ?? null;
        }
        const vmMeta = metaError(vmLabel, nv.metadata); if (vmMeta) errors.push(vmMeta);
        vm.metadata = nv.metadata ?? null;
        newVms.push(vm);
        placement = { newVm: vm };
      }
    }

    instances.push({
      id: uuidv4(), name: r.name, role: r.role, metadata: r.metadata ?? null, placement,
    });
  });

  // Topology cardinality: the per-role instance count must match the topology
  // (spec §10.1). Reuses the setup wizard's single-source count rule.
  if (database.topology != null && TOPOLOGIES.has(database.topology)) {
    const expected = expectedInstanceCounts(database.topology, database.node_count, database.standby_node_count);
    if (expected && (counts.primary !== expected.primary || counts.standby !== expected.standby)) {
      errors.push(
        `${database.topology}: expected ${expected.primary} primary + ${expected.standby} standby `
        + `instance(s), got ${counts.primary} + ${counts.standby}`,
      );
    }
  }

  if (errors.length) return { ok: false, errors, columnRequiredMessage };
  return { ok: true, plan: { database, instances, newVms } };
}

// Build the reference-integrity specs the payload carries, driven off the SAME
// CHILD_FK_VALIDATIONS the child mounts run so this endpoint and the per-row
// creates can never disagree on what a legal reference is. Catalogue FKs
// (database + new-VM profile/disk/team) ride the databases/vms specs; the
// scenario-internal placement FKs (existing vm_id → db_host, new-VM
// hypervisor_id) ride the db_instances/vms specs.
function collectReferenceSpecs(plan) {
  const specs = [];
  const specFor = (segment, column) => CHILD_FK_VALIDATIONS[segment].find((s) => s.column === column);
  const add = (template, value) => {
    if (value == null) return;
    specs.push({ ...template, value });
  };

  for (const s of CHILD_FK_VALIDATIONS.databases) add(s, plan.database[s.column]);
  const vmInstSpec = specFor('db_instances', 'vm_id'); // scenario + requireVmType db_host
  for (const inst of plan.instances) {
    if (inst.placement && inst.placement.existingVmId != null) add(vmInstSpec, inst.placement.existingVmId);
  }
  const hvSpec = specFor('vms', 'hypervisor_id');
  const vmCatalogueSpecs = ['sizing_profile_id', 'disk_combo_id', 'team_id'].map((c) => specFor('vms', c));
  for (const vm of plan.newVms) {
    add(hvSpec, vm.hypervisor_id);
    for (const s of vmCatalogueSpecs) add(s, vm[s.column]);
  }
  return specs;
}

// Rewrite every FK the reference check resolved to the STORED spelling of the row
// it names (rule 1: bind the stored value, not the caller's, or SQL resolves the
// row and every JavaScript reader — the sizing Map two calls down, the FE
// `.find` — misses it). Walks the same FK sites collectReferenceSpecs read.
function applyCanonicalIds(plan, canonical) {
  if (!canonical) return;
  const rebind = (row, column, table) => {
    const value = row[column];
    if (value == null) return;
    const stored = canonical.get(canonicalKey(table, value));
    if (stored != null) row[column] = stored;
  };
  for (const s of CHILD_FK_VALIDATIONS.databases) rebind(plan.database, s.column, s.table);
  for (const inst of plan.instances) {
    if (inst.placement && inst.placement.existingVmId != null) {
      const stored = canonical.get(canonicalKey(TABLES.CAP_VMS, inst.placement.existingVmId));
      if (stored != null) inst.placement.existingVmId = stored;
    }
  }
  for (const vm of plan.newVms) {
    rebind(vm, 'hypervisor_id', TABLES.CAP_HYPERVISORS);
    rebind(vm, 'sizing_profile_id', TABLES.CAP_VM_PROFILES);
    rebind(vm, 'disk_combo_id', TABLES.CAP_DISK_COMBOS);
    rebind(vm, 'team_id', TABLES.CAP_TEAMS);
  }
}

// Hydrate the catalogue rows the class check, disk-combo allow-list and sizing
// derivation need, read on the IN-TX (already FOR UPDATE locked) connection.
// Keyed on the REBOUND (== stored) id: applyCanonicalIds ran first, so `WHERE id
// IN (...)` and the Map key are the same spelling and no case-fold miss occurs.
async function loadSizingContext(conn, plan) {
  const profileIds = new Set();
  const comboIds = new Set();
  if (plan.database.profile_id != null) profileIds.add(plan.database.profile_id);
  if (plan.database.disk_combo_id != null) comboIds.add(plan.database.disk_combo_id);
  for (const vm of plan.newVms) {
    if (vm.sizing_profile_id != null) profileIds.add(vm.sizing_profile_id);
    if (vm.disk_combo_id != null) comboIds.add(vm.disk_combo_id);
  }

  const profileById = new Map();
  if (profileIds.size) {
    const ids = [...profileIds];
    const rows = await conn.query(
      `SELECT ${READ_COLUMNS[TABLES.CAP_VM_PROFILES].join(', ')} FROM \`${t(TABLES.CAP_VM_PROFILES)}\``
      + ` WHERE id IN (${ids.map(() => '?').join(', ')})`,
      ids,
    );
    for (const r of rows) profileById.set(r.id, r);
  }

  const comboGbById = new Map();
  if (comboIds.size) {
    const ids = [...comboIds];
    const rows = await conn.query(
      `SELECT ${READ_COLUMNS[TABLES.CAP_DISK_COMBOS].join(', ')} FROM \`${t(TABLES.CAP_DISK_COMBOS)}\``
      + ` WHERE id IN (${ids.map(() => '?').join(', ')})`,
      ids,
    );
    for (const r of rows) comboGbById.set(r.id, sumDiskComboSizes(r.sizes));
  }

  // Scenario-effective settings (the scenario's own row wins, else the global
  // default): `scenario_id IS NULL` sorts LAST. Same single-source semantics as
  // children.js loadScenarioEffectiveSettings / violations.js loadSnapshot.
  const srows = await conn.query(
    `SELECT ${READ_COLUMNS[TABLES.CAP_SETTINGS].join(', ')} FROM \`${t(TABLES.CAP_SETTINGS)}\``
    + ` WHERE scenario_id = ? OR scenario_id IS NULL ORDER BY scenario_id IS NULL LIMIT 1`,
    [plan.scenarioId],
  );
  const settingsRow = srows[0] || null;
  return { profileById, comboGbById, settingsRow, formula: readFormulaConstants(settingsRow) };
}

// A db_host VM and the database must reference a DB-class profile (the §17.1a
// check confirms only that a profile FK RESOLVES, never its class — bundles.js /
// wizard.js parity). Runs inside the caller's tx against the profiles already
// locked by checkReferences. Returns a message on the FIRST mismatch, else null.
//
// WHY this is stricter than children.js's per-row database/vm POST (which
// accepts any profile class): this mount is the wizard's ONE-SHOT persist, so
// it also derives sizing off the profile it accepts (deriveVmSizing,
// databaseSgaCap) — a wrong-class profile here would silently size a database
// off an AP-class profile's numbers. Deliberate wizard-parity divergence, not
// an oversight; the looser per-row mount is unaffected.
function checkProfileClasses(plan, profileById) {
  const wants = [];
  if (plan.database.profile_id != null) wants.push({ label: 'database profile_id', id: plan.database.profile_id });
  for (const vm of plan.newVms) {
    if (vm.sizing_profile_id != null) wants.push({ label: `new VM "${vm.name}" sizing_profile_id`, id: vm.sizing_profile_id });
  }
  for (const w of wants) {
    const profile = profileById.get(w.id);
    if (profile && profile.class != null && String(profile.class) !== 'DB') {
      return `${w.label} must reference a DB-class profile (referenced profile is ${profile.class}-class)`;
    }
  }
  return null;
}

// Enforce the disk-combo allow-list (spec §5.3) on the database + each new VM. A
// missing profile is left to the §17.1a check; a null/empty allow-list is
// unrestricted. Returns a message on the FIRST violation, else null.
function checkDiskCombos(plan, profileById) {
  const check = (label, profileId, comboId) => {
    if (profileId == null || comboId == null) return null;
    const profile = profileById.get(profileId);
    if (!profile) return null; // §17.1a owns a missing/foreign profile
    if (diskComboAllowed(profile.allowed_disk_combos, comboId)) return null;
    return `${label}: disk_combo_id is not in the chosen profile's allowed disk combos`;
  };
  const dbErr = check('database', plan.database.profile_id, plan.database.disk_combo_id);
  if (dbErr) return dbErr;
  for (const vm of plan.newVms) {
    const err = check(`new VM "${vm.name}"`, vm.sizing_profile_id, vm.disk_combo_id);
    if (err) return err;
  }
  return null;
}

// database.function_name charset, grandfathered per-scenario (fmb-1705) — the
// SAME contract makeDatabaseFunctionNameGuard (_shared.js) enforces on the
// generic child mount, re-stated here because this endpoint bypasses that
// mount's createCrudRoutes guards entirely (its own transactional INSERT, not
// a PUT/POST through children.js). Judges the EXACT value insertRow ends up
// writing (plan.database.function_name), never a copy — see that guard's
// doc-block for why the write value and the validated value must be the same
// object. Returns an error message on rejection, else null.
async function checkDatabaseFunctionNameCharset(conn, scenarioId, functionName) {
  if (functionName === '' || VM_FUNCTION_NAME_RE.test(functionName)) return null;
  // probe-exempt: this `function_name` is cap_databases.function_name — VARCHAR(255)
  // NOT NULL on the ORIGINAL table-ddls.js CREATE TABLE, never an add-column
  // migration, so it can never be the physically-absent column the degraded-schema
  // family probes for (that risk belongs to cap_vms.function_name, fmb-1329, which
  // this file never queries).
  const rows = await conn.query(
    `SELECT 1 FROM \`${t(TABLES.CAP_DATABASES)}\` WHERE scenario_id = ? AND function_name = ? LIMIT 1`,
    [scenarioId, functionName],
  );
  return rows.length ? null : DATABASE_FUNCTION_NAME_CHARSET_MSG;
}

// Derive a new db_host VM's persisted { cpu, mem_gb, disk_gb } (wizard.js
// deriveVmSizing parity): a profiled row's cpu/mem come from the profile, disk
// from the combo; a no-profile ("Custom") row keeps the client values.
function deriveVmSizing(vm, ctx) {
  const sizing = vm.sizing_profile_id != null
    ? resolveProfileSizing(ctx.profileById.get(vm.sizing_profile_id), ctx.formula)
    : null;
  const cpu = sizing ? sizing.cpu : (vm.cpu ?? 0);
  const memGb = sizing ? sizing.memGb : (vm.mem_gb ?? 0);
  const diskGb = vm.disk_combo_id != null && ctx.comboGbById.has(vm.disk_combo_id)
    ? ctx.comboGbById.get(vm.disk_combo_id)
    : (vm.disk_gb ?? 0);
  return { cpu, mem_gb: memGb, disk_gb: diskGb };
}

// The database profile's SGA cap for a primary instance (DB-class), else 0.
function databaseSgaCap(plan, ctx) {
  const sizing = plan.database.profile_id != null
    ? resolveProfileSizing(ctx.profileById.get(plan.database.profile_id), ctx.formula)
    : null;
  return sizing && sizing.sgaCapGb != null ? sizing.sgaCapGb : 0;
}

// Next append order_index (MAX+1) for a table within the scenario. Lock-free,
// mirroring _shared.js makeAppendOrderIndexOnCreate: layering a cap_scenarios
// FOR UPDATE here would add a lock-ordering edge; a rare tie self-heals on the
// next drag-reorder.
async function nextOrderIndex(conn, table, scenarioId) {
  const rows = await conn.query(
    `SELECT COALESCE(MAX(order_index), -1) + 1 AS next FROM \`${t(table)}\` WHERE scenario_id = ?`,
    [scenarioId],
  );
  return Number(rows[0] ? rows[0].next : 0);
}

// Insert one row; column NAMES come from INSERT_COLUMNS (the parity-checked
// single source), values from `valueByColumn`. A null value is written verbatim
// (an explicit null on a nullable FK is intentional). `omitCols` (F2) drops a
// column this CALL should not name — a degraded-schema guard, NOT a change to
// INSERT_COLUMNS itself: the schema-parity test still checks the FULL maximal
// set against the DDL, so a call site cannot quietly omit a column that
// genuinely doesn't exist on the table (that would defeat the parity check).
async function insertRow(conn, table, valueByColumn, omitCols = []) {
  const cols = omitCols.length ? INSERT_COLUMNS[table].filter((c) => !omitCols.includes(c)) : INSERT_COLUMNS[table];
  const names = cols.map((c) => `\`${c}\``).join(', ');
  const placeholders = cols.map(() => '?').join(', ');
  const values = cols.map((c) => valueByColumn[c]);
  await conn.query(`INSERT INTO \`${t(table)}\` (${names}) VALUES (${placeholders})`, values);
}

// POST /scenarios/:scenarioId/databases/bulk-create — the Add-Database wizard's
// transactional persist. Registered ahead of the generic children mount so the
// three-segment .../databases/bulk-create path is not shadowed by the databases
// child factory's POST /databases (its /bulk-create suffix shadows no real
// endpoint, mirroring delete-preview.js).
router.post('/scenarios/:scenarioId/databases/bulk-create', async (req, res) => {
  if (!requireAdminOrEditor(req, res)) return;

  const built = buildDatabaseBulkPlan(req.body || {});
  if (!built.ok) {
    const e = built.tooLarge
      ? apiError('Bulk-create payload is too large', 'PAYLOAD_TOO_LARGE', 413, { details: built.errors })
      : built.columnRequiredMessage
        ? apiError(built.columnRequiredMessage, 'COLUMN_REQUIRED', 400, { details: built.errors })
        : apiError('Bulk-create payload is invalid', 'BAD_REQUEST', 400, { details: built.errors });
    return res.status(e.status).json(e.body);
  }
  const plan = built.plan;
  const { scenarioId } = req.params;

  let conn;
  try {
    conn = await pool.rw.getConnection();
    await conn.beginTransaction();

    // Scenario write authz, mirroring the databases child POST (admin always; an
    // editor only for a shared or self-owned scenario) — locked FOR UPDATE so the
    // scenario cannot be deleted between this gate and the INSERTs. `scenarioId`
    // below binds the STORED spelling the gate resolved (rule 1), not req.params.
    const access = await resolveScenarioWriteAccess(conn, scenarioId, req.user, { lock: true });
    if (!access.found) {
      await safeRollback(conn);
      const e = apiError('Not found', 'NOT_FOUND', 404);
      return res.status(e.status).json(e.body);
    }
    if (!access.allowed) {
      await safeRollback(conn);
      const e = apiError('Not allowed: you do not own this scenario', 'FORBIDDEN', 403);
      return res.status(e.status).json(e.body);
    }
    plan.scenarioId = access.scenarioId;

    // X3 fix (degraded-schema family, F2 was member 1): F2's per-column INSERT
    // omission alone does not stop a renamed-RAC-member row from reaching
    // the INSERT on a schema whose `topology` ENUM is still narrow (a
    // SEPARATE migration step from the standby_node_count column add) —
    // MariaDB rejects the ENUM value itself, an opaque 500. Gate at
    // VALIDATION time, before any other check below. H1 (fmb-1767 round 1):
    // checks BOTH renamed members — the base `rac_multinode` value is
    // exposed to this same gap, not only `rac_multinode_standby`.
    if ((plan.database.topology === TOPOLOGY.RAC_MULTINODE
      || plan.database.topology === TOPOLOGY.RAC_MULTINODE_STANDBY)
      && !(await isRenamedTopologySchemaSupported(conn, plan.database.topology, { cache: false }))) {
      await safeRollback(conn);
      const e = apiError(TOPOLOGY_SCHEMA_UNSUPPORTED_MSG, 'TOPOLOGY_SCHEMA_UNSUPPORTED', 409);
      return res.status(e.status).json(e.body);
    }

    // function_name charset, grandfathered per-scenario (fmb-1705) — cheap and
    // lock-free ITSELF, so it runs before the §17.1a FOR UPDATE-heavy checks
    // below without adding a lock-ordering edge of its own. TOCTOU (Codex r1):
    // unlike the generic child mount (children.js wires this check's twin,
    // makeDatabaseFunctionNameGuard, AFTER the scenario lock — see that mount's
    // note), this endpoint mints its OWN transaction and already took the
    // scenario row FOR UPDATE two statements up (resolveScenarioWriteAccess,
    // `lock: true`) BEFORE reaching here — so this lookup already runs inside
    // that lock, not ahead of it, and the same window-closing argument applies:
    // a concurrent tx deleting/renaming the legacy row this lookup finds must
    // wait on the same cap_scenarios row, so nothing can commit between this
    // lookup and this transaction's INSERT below.
    const charsetError = await checkDatabaseFunctionNameCharset(
      conn, plan.scenarioId, plan.database.function_name,
    );
    if (charsetError) {
      await safeRollback(conn);
      const e = apiError(charsetError, 'BAD_REQUEST', 400);
      return res.status(e.status).json(e.body);
    }

    // §17.1a reference-integrity under a FOR UPDATE lock (catalogue + scenario
    // placement FKs), then rebind every resolved FK to its stored spelling.
    const specs = collectReferenceSpecs(plan);
    if (specs.length) {
      const result = await checkReferences(conn, plan.scenarioId, specs, { lock: true });
      if (!result.ok) {
        await safeRollback(conn);
        const e = apiError(result.message, result.code, 400);
        return res.status(e.status).json(e.body);
      }
      applyCanonicalIds(plan, result.canonical);
    }

    // Hydrate catalogue rows (under the lock the §17.1a check took), then the
    // class + disk-combo checks — all BEFORE any INSERT so a violation writes
    // nothing.
    const ctx = await loadSizingContext(conn, plan);
    const classError = checkProfileClasses(plan, ctx.profileById);
    if (classError) {
      await safeRollback(conn);
      const e = apiError(classError, 'INVALID_REFERENCE', 400);
      return res.status(e.status).json(e.body);
    }
    const diskComboError = checkDiskCombos(plan, ctx.profileById);
    if (diskComboError) {
      await safeRollback(conn);
      const e = apiError(diskComboError, 'DISK_COMBO_NOT_ALLOWED', 400);
      return res.status(e.status).json(e.body);
    }

    // ── database ───────────────────────────────────────────────────────────
    // standby_node_count (F2) degraded-schema guard, mirroring wizard.js's own
    // cap_databases probe: a warn-skipped add-column migration leaves the
    // column PHYSICALLY ABSENT, and naming it unconditionally in the INSERT
    // (as this endpoint used to) would 500 EVERY database create, not just a
    // rac_standby one — this is one INSERT statement per row. `{cache:false}`
    // for the same reason as every other write-side probe in this family: it
    // must observe the SAME connection the INSERT below runs on.
    const dbPhysicalCols = await tableColumnSet(conn, TABLES.CAP_DATABASES, { cache: false });
    const dbHasStandbyNodeCountColumn = !dbPhysicalCols.has('id') || dbPhysicalCols.has('standby_node_count');

    const dbOrder = await nextOrderIndex(conn, TABLES.CAP_DATABASES, plan.scenarioId);
    await insertRow(conn, TABLES.CAP_DATABASES, {
      id: plan.database.id,
      scenario_id: plan.scenarioId,
      function_name: plan.database.function_name,
      topology: plan.database.topology,
      node_count: plan.database.node_count,
      standby_node_count: plan.database.standby_node_count,
      profile_id: plan.database.profile_id,
      disk_combo_id: plan.database.disk_combo_id,
      team_id: plan.database.team_id,
      primary_sga_gb: plan.database.primary_sga_gb,
      standby_sga_gb: plan.database.standby_sga_gb,
      description: plan.database.description,
      order_index: dbOrder,
      metadata: jsonForStore(plan.database.metadata),
    }, dbHasStandbyNodeCountColumn ? [] : ['standby_node_count']);

    // ── new db_host VMs ──────────────────────────────────────────────────────
    // A placed VM's site IS its host's (spec §5.3, deriveVmSiteFromHost parity),
    // read under the lock checkReferences already took on that host; an unplaced
    // (tray) VM has no host, so its site_id stays NULL.
    let vmOrder = plan.newVms.length ? await nextOrderIndex(conn, TABLES.CAP_VMS, plan.scenarioId) : 0;
    const createdVms = [];
    for (const vm of plan.newVms) {
      let siteId = null;
      if (vm.hypervisor_id != null) {
        const rows = await conn.query(
          `SELECT site_id FROM \`${t(TABLES.CAP_HYPERVISORS)}\` WHERE id = ? LIMIT 1 FOR UPDATE`,
          [vm.hypervisor_id],
        );
        siteId = rows.length ? rows[0].site_id : null;
      }
      const sizing = deriveVmSizing(vm, ctx);
      await insertRow(conn, TABLES.CAP_VMS, {
        id: vm.id,
        scenario_id: plan.scenarioId,
        vm_type: 'db_host',
        hypervisor_id: vm.hypervisor_id,
        site_id: siteId,
        cpu: sizing.cpu,
        mem_gb: sizing.mem_gb,
        disk_gb: sizing.disk_gb,
        sizing_profile_id: vm.sizing_profile_id,
        disk_combo_id: vm.disk_combo_id,
        team_id: vm.team_id,
        database_id: plan.database.id, // the db_host-only non-normative hint (§10.3)
        name: vm.name,
        order_index: vmOrder,
        metadata: jsonForStore(vm.metadata),
      });
      vmOrder += 1;
      createdVms.push({ id: vm.id, name: vm.name, hypervisor_id: vm.hypervisor_id });
    }

    // ── instances ────────────────────────────────────────────────────────────
    // sga_gb is server-derived by role from the database seeds + scenario-
    // effective standby default + (primary) the database profile's SGA cap.
    const sgaCap = databaseSgaCap(plan, ctx);
    const databaseSeeds = {
      primary_sga_gb: plan.database.primary_sga_gb,
      standby_sga_gb: plan.database.standby_sga_gb,
    };
    let instOrder = await nextOrderIndex(conn, TABLES.CAP_DB_INSTANCES, plan.scenarioId);
    const createdInstances = [];
    for (const inst of plan.instances) {
      const vmId = inst.placement.existingVmId != null
        ? inst.placement.existingVmId
        : inst.placement.newVm.id;
      const sgaGb = deriveInstanceSga(inst.role, databaseSeeds, ctx.settingsRow, { sgaCapGb: sgaCap });
      await insertRow(conn, TABLES.CAP_DB_INSTANCES, {
        id: inst.id,
        scenario_id: plan.scenarioId,
        vm_id: vmId,
        database_id: plan.database.id,
        name: inst.name,
        role: inst.role,
        sga_gb: sgaGb,
        order_index: instOrder,
        metadata: jsonForStore(inst.metadata),
      });
      instOrder += 1;
      createdInstances.push({ id: inst.id, role: inst.role, vm_id: vmId });
    }

    await conn.commit();
    return res.status(201).json(apiOk({
      database: { id: plan.database.id },
      instances: createdInstances,
      vms: createdVms,
    }));
  } catch (err) {
    await safeRollback(conn);
    // A write the engine gave up on, not one the server got wrong — same
    // placement-apply.js reasoning: crud-factory's writeConflictError is the
    // single statement of "which errno means retry" (1213 deadlock victim,
    // 1205 lock-wait timeout) so a bulk-create chosen as the lock-race victim
    // surfaces as a retryable 409 rather than an indistinguishable-from-broken 500.
    const conflict = writeConflictError(err);
    if (conflict) {
      logger.warn({ err, scenarioId }, `Database bulk-create lost a lock race for scenario id=${scenarioId}`);
      return res.status(conflict.status).json(conflict.body);
    }
    logger.error({ err, scenarioId }, `Failed to bulk-create database in scenario ${scenarioId}`);
    const e = apiError('Database operation failed', 'INTERNAL_ERROR', 500);
    return res.status(e.status).json(e.body);
  } finally {
    if (conn) conn.release();
  }
});

module.exports = router;
module.exports.buildDatabaseBulkPlan = buildDatabaseBulkPlan;
module.exports.INSERT_COLUMNS = INSERT_COLUMNS;
module.exports.READ_COLUMNS = READ_COLUMNS;
