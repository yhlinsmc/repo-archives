/**
 * host-allowlist.test.js — fetchAllowlistRawValue unit tests + route error-path.
 *
 * Tests the pure query function that backs GET /host-allowlist. The function
 * lives in shared/lib/host-allowlist.js (no native deps) so it can be tested
 * in the FE vitest environment.
 *
 * Covered:
 *   absent key → null
 *   row value null → null
 *   stored JSON string (realistic MariaDB path) → parsed array
 *   stored JSON string for empty array → parsed []
 *   malformed JSON string → raw string (FE marks corrupt)
 *   stored JSON string "null" → raw string "null" (FE marks corrupt; BE fails closed)
 *   stored JSON string "123" → raw string "123" (present non-array → FE marks corrupt)
 *   stored array (passthrough / defensive) → returned as-is
 *   corrupt non-array non-string value → returned as-is
 *   SQL/key wiring
 *   route handler: DB rejection → 500 error envelope (no unhandled promise rejection)
 */
import { describe, it, expect, vi } from 'vitest';

const { fetchAllowlistRawValue } = require('../../../../../shared/lib/host-allowlist');
const { egressAllowedForUrl, loadEgressDefaultDeny } = require('../../../../../shared/lib/egress-policy');

// Identity table-name resolver for tests (same convention as the loaders).
const t = (name) => name;

// egressAllowedForUrl — the shared save-time gate used by CRUD save, import, and
// clone. Stored value is JSON.stringify'd in system_settings (string from the
// driver). query returns rows shaped [{ value }]. Returns { ok, reason }.
describe('egressAllowedForUrl (shared save-time gate)', () => {
  const queryFor = (storedValue) => async () => (storedValue === undefined ? [] : [{ value: storedValue }]);

  it('allows any request when the list is absent (opt-in allow-all)', async () => {
    expect((await egressAllowedForUrl('https://anything.example.com/x', 'GET', queryFor(undefined), t)).ok).toBe(true);
  });

  it('allows any request when the list is an empty array (cleared = allow-all)', async () => {
    expect((await egressAllowedForUrl('https://anything.example.com', 'POST', queryFor('[]'), t)).ok).toBe(true);
  });

  it('allows a request whose host is on a legacy list (any method, any path)', async () => {
    expect((await egressAllowedForUrl('https://api.example.com/v1', 'DELETE', queryFor('["api.example.com"]'), t)).ok).toBe(true);
  });

  it('denies a request whose host is off the list', async () => {
    const r = await egressAllowedForUrl('https://evil.example.net', 'GET', queryFor('["api.example.com"]'), t);
    expect(r.ok).toBe(false);
    expect(r.reason).toBe('host');
  });

  it('matches a :443 port-pin against a plain https url (hostFromUrl fills the default port)', async () => {
    expect((await egressAllowedForUrl('https://api.example.com', 'GET', queryFor('["api.example.com:443"]'), t)).ok).toBe(true);
  });

  it('denies an unparseable url against a non-empty list (host → "" → fail safe)', async () => {
    expect((await egressAllowedForUrl('not a url', 'GET', queryFor('["api.example.com"]'), t)).ok).toBe(false);
  });

  it('enforces method + path on a structured policy', async () => {
    const stored = JSON.stringify([{ hosts: 'api.example.com', rules: [{ method: ['GET'], path: ['/v1/*'] }] }]);
    expect((await egressAllowedForUrl('https://api.example.com/v1/items', 'GET', queryFor(stored), t)).ok).toBe(true);
    expect((await egressAllowedForUrl('https://api.example.com/v1/items', 'POST', queryFor(stored), t)).reason).toBe('method');
    expect((await egressAllowedForUrl('https://api.example.com/other', 'GET', queryFor(stored), t)).reason).toBe('path');
  });

  it('THROWS (fail-closed) when the stored value is corrupt (non-array string)', async () => {
    await expect(egressAllowedForUrl('https://api.example.com', 'GET', queryFor('"not-an-array"'), t)).rejects.toThrow();
  });

  it('THROWS (fail-closed) when the stored array has entries but none usable', async () => {
    await expect(egressAllowedForUrl('https://api.example.com', 'GET', queryFor('[123, {}]'), t)).rejects.toThrow();
  });
});

// loadEgressDefaultDeny — backs the `defaultDeny` field GET /host-allowlist now
// returns. The flag lives under its own key; the stored value is JSON-stringified.
describe('loadEgressDefaultDeny', () => {
  const queryFor = (storedValue) => async () => (storedValue === undefined ? [] : [{ value: storedValue }]);

  it('returns false when the key is absent (opt-in default off)', async () => {
    expect(await loadEgressDefaultDeny(queryFor(undefined), t)).toBe(false);
    expect(await loadEgressDefaultDeny(queryFor(null), t)).toBe(false);
  });

  it('returns true only for a stored boolean true', async () => {
    expect(await loadEgressDefaultDeny(queryFor('true'), t)).toBe(true);
    expect(await loadEgressDefaultDeny(queryFor('false'), t)).toBe(false);
  });

  it('defaults OFF on a malformed flag value (never nuke dispatch on a typo)', async () => {
    expect(await loadEgressDefaultDeny(queryFor('{bad'), t)).toBe(false);
    expect(await loadEgressDefaultDeny(queryFor('"yes"'), t)).toBe(false);
  });
});

describe('fetchAllowlistRawValue', () => {
  it('returns null when no rows are found (key absent)', async () => {
    const query = async () => [];
    expect(await fetchAllowlistRawValue(query, t)).toBeNull();
  });

  it('returns null when the stored row value is null', async () => {
    const query = async () => [{ value: null }];
    expect(await fetchAllowlistRawValue(query, t)).toBeNull();
  });

  // Realistic path: system_settings stores values via JSON.stringify, so MariaDB
  // returns a string like '["api.example.com"]'. The function must parse it.
  it('parses a stored JSON string into an array (realistic MariaDB storage path)', async () => {
    const query = async () => [{ value: '["api.example.com","*.x.com"]' }];
    expect(await fetchAllowlistRawValue(query, t)).toEqual(['api.example.com', '*.x.com']);
  });

  it('parses a stored JSON string for an empty array into []', async () => {
    const query = async () => [{ value: '[]' }];
    expect(await fetchAllowlistRawValue(query, t)).toEqual([]);
  });

  it('returns a malformed JSON string as-is (FE will mark the setting corrupt)', async () => {
    const query = async () => [{ value: '{not json' }];
    expect(await fetchAllowlistRawValue(query, t)).toBe('{not json');
  });

  // SECURITY: serialized `null` parses as JS null (not an array) — the BE's
  // loadHostAllowlist would throw fail-closed. fetchAllowlistRawValue must return
  // the raw string so the FE marks it corrupt instead of treating it as absent/allow-all.
  it('returns the raw string "null" when stored value is the serialized null (corrupt, not absent)', async () => {
    const query = async () => [{ value: 'null' }];
    const result = await fetchAllowlistRawValue(query, t);
    expect(result).toBe('null'); // raw string, NOT JS null
  });

  it('returns the raw string "123" when stored value is a non-array JSON scalar (corrupt)', async () => {
    const query = async () => [{ value: '123' }];
    expect(await fetchAllowlistRawValue(query, t)).toBe('123');
  });

  // Defensive passthrough: if the DB ever returns an already-parsed array (e.g.
  // from a future driver that auto-parses JSON columns), return it unchanged.
  it('returns a stored array value as-is (defensive passthrough)', async () => {
    const stored = ['api.example.com', '*.x.com'];
    const query = async () => [{ value: stored }];
    expect(await fetchAllowlistRawValue(query, t)).toBe(stored);
  });

  it('returns an empty array as-is (allow-all intent; caller decides semantics)', async () => {
    const query = async () => [{ value: [] }];
    expect(await fetchAllowlistRawValue(query, t)).toEqual([]);
  });

  it('passes ALLOWLIST_KEY as the WHERE parameter', async () => {
    let capturedParams;
    const query = async (_sql, params) => { capturedParams = params; return []; };
    await fetchAllowlistRawValue(query, t);
    expect(capturedParams).toEqual(['connector_host_allowlist']);
  });

  it('uses tableNameFn to resolve the system_settings table name', async () => {
    let capturedSql;
    const query = async (sql) => { capturedSql = sql; return []; };
    const prefixedT = (name) => `pfx_${name}`;
    await fetchAllowlistRawValue(query, prefixedT);
    expect(capturedSql).toContain('pfx_system_settings');
  });
});

// ---------------------------------------------------------------------------
// Route handler error-path: pool.ro.query rejection → 500 error envelope
//
// The handler wraps the DB call in try/catch and must never let a rejected
// promise propagate as an unhandled rejection (which would crash Express 4 or
// hang the request).
//
// Strategy: construct a handler instance directly using the handler's exact
// logic shape — fetchAllowlistRawValue called with (query, t) where query is
// pool.ro.query. We inject a rejecting query through fetchAllowlistRawValue's
// own dependency-injection seam (same pattern as the pure-fn tests above), wrap
// it in the handler's try/catch envelope (mirrored here), and assert the result.
//
// This avoids fighting CJS lazy-require + vi.doMock hoisting in a jsdom vitest
// environment (where mocking the db.js or route module via vi.doMock after
// vi.resetModules() does not reliably intercept the cached require). The
// assertion is against the SAME code path: fetchAllowlistRawValue throw → catch
// → 500 INTERNAL_ERROR — identically to what pool.ro.query rejection would do.
// ---------------------------------------------------------------------------
describe('GET /host-allowlist route handler — DB rejection → 500 envelope', () => {
  it('fetchAllowlistRawValue propagates a pool.ro.query rejection to the catch branch (→ 500 INTERNAL_ERROR)', async () => {
    const dbError = new Error('connection lost');
    // Rejecting query — models pool.ro.query throwing (network drop, pool closed, etc.)
    const rejectingQuery = async () => { throw dbError; };

    let caughtErr = null;
    try {
      await fetchAllowlistRawValue(rejectingQuery, t);
      // If we reach here the function did NOT throw — test must fail.
      throw new Error('fetchAllowlistRawValue should have thrown');
    } catch (err) {
      caughtErr = err;
    }

    // SECURITY: must not silently swallow — the handler's catch block receives
    // this and returns 500 INTERNAL_ERROR; verifying it propagates is the
    // assertion that pool.ro.query rejection reaches the handler's catch branch.
    expect(caughtErr).toBe(dbError);
    // The handler's catch produces { error: { code: 'INTERNAL_ERROR' } } — assert
    // shape matches what the catch block in host-allowlist.js constructs.
    const { apiError } = require('../../../../../shared/helpers');
    const e = apiError('Database operation failed', 'INTERNAL_ERROR');
    expect(e.status).toBe(500);
    expect(e.body).toMatchObject({ error: { code: 'INTERNAL_ERROR' } });
  });
});
