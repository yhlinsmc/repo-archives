/**
 * validate-on-no-match.test.js — backend guard for the rows-sink join
 * `on_no_match` policy. Mirrors the FE rule (src/fmb/lib/connectors/
 * join-list-rows.ts): a join (rows sink WITH match) may 'skip' unmatched
 * elements or 'create' a row per unmatched element (upsert), and upsert is
 * eq-only. A rows sink WITHOUT a match may not carry a non-skip policy.
 */
import { describe, it, expect } from 'vitest';

const { validateResponseOutputs } = require('../validate');

/** A rows sink with a complete match block + the given on_no_match/op. */
function joinOutputs(onNoMatch, op = 'eq') {
  return {
    outputs: [{
      id: 'o1',
      from: { mode: 'list', path: 'items' },
      to: {
        mode: 'rows', table_key: 'parts_table',
        columns: [{ column_key: 'qty', from: 'value' }],
        match: { row_column: 'part_no', element_field: 'name', op },
        ...(onNoMatch !== undefined ? { on_no_match: onNoMatch } : {}),
      },
    }],
  };
}

describe('validateResponseOutputs — on_no_match', () => {
  it('accepts a join with on_no_match "skip"', () => {
    expect(validateResponseOutputs(joinOutputs('skip'))).toBeNull();
  });

  it('accepts a join with on_no_match "create" (upsert, eq op)', () => {
    expect(validateResponseOutputs(joinOutputs('create'))).toBeNull();
  });

  it('accepts a join with no on_no_match (default)', () => {
    expect(validateResponseOutputs(joinOutputs(undefined))).toBeNull();
  });

  it('rejects an unknown on_no_match value', () => {
    expect(validateResponseOutputs(joinOutputs('delete'))).toMatch(/on_no_match must be 'skip' or 'create'/);
  });

  it("rejects on_no_match 'create' with a non-eq match op", () => {
    expect(validateResponseOutputs(joinOutputs('create', 'contains'))).toMatch(/'create' requires every match key op to be 'eq'/);
  });

  it("rejects a non-skip on_no_match on a rows sink WITHOUT a match", () => {
    const cfg = { outputs: [{
      id: 'o1', from: { mode: 'list', path: 'items' },
      to: { mode: 'rows', table_key: 'parts_table', columns: [{ column_key: 'qty', from: 'value' }], on_no_match: 'create' },
    }] };
    expect(validateResponseOutputs(cfg)).toMatch(/on_no_match must be 'skip' when present/);
  });
});

describe('validateResponseOutputs — order_by', () => {
  function rowsOutput(orderBy) {
    const to = {
      mode: 'rows', table_key: 'parts_table',
      columns: [{ column_key: 'qty', from: 'value' }],
    };
    if (orderBy !== undefined) to.order_by = orderBy;
    return { outputs: [{ id: 'o1', from: { mode: 'list', path: 'items' }, to }] };
  }

  it('accepts a rows sink with no order_by (legacy config)', () => {
    expect(validateResponseOutputs(rowsOutput(undefined))).toBeNull();
  });

  it('accepts a valid order_by array', () => {
    expect(validateResponseOutputs(rowsOutput([{ column: 'qty', dir: 'asc' }]))).toBeNull();
  });

  it('accepts order_by with dir:desc', () => {
    expect(validateResponseOutputs(rowsOutput([{ column: 'qty', dir: 'desc' }]))).toBeNull();
  });

  it('rejects order_by that is not an array', () => {
    expect(validateResponseOutputs(rowsOutput({ column: 'qty', dir: 'asc' }))).toMatch(/order_by must be an array/);
  });

  it('rejects an order_by entry missing column', () => {
    expect(validateResponseOutputs(rowsOutput([{ dir: 'asc' }]))).toMatch(/order_by.*column/);
  });

  it('rejects an order_by entry with empty column', () => {
    expect(validateResponseOutputs(rowsOutput([{ column: '', dir: 'asc' }]))).toMatch(/order_by.*column/);
  });

  it('rejects an order_by entry with invalid dir', () => {
    expect(validateResponseOutputs(rowsOutput([{ column: 'qty', dir: 'random' }]))).toMatch(/order_by.*dir.*asc.*desc|order_by.*dir/);
  });

  it('rejects an order_by entry with missing dir', () => {
    expect(validateResponseOutputs(rowsOutput([{ column: 'qty' }]))).toMatch(/order_by.*dir/);
  });
});
