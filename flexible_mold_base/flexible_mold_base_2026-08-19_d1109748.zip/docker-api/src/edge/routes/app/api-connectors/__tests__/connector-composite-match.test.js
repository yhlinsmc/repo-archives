/**
 * connector-composite-match.test.js — backend parity for the composite (multi-
 * column) rows-sink join key (G3). validate.js accepts both the legacy
 * single-pair match and the keys[] shape; usable.js projects either to keys[].
 * Mirrors the FE row-match.ts / join-list-rows.ts semantics: a row matches an
 * element iff EVERY key matches, and upsert (create) is eq-only on every key.
 */
import { describe, it, expect } from 'vitest';

const { validateResponseOutputs, normalizeRowMatch } = require('../validate');
const { buildUsableProjection } = require('../usable');

const rowsOutput = (match, onNoMatch) => ({
  outputs: [{
    id: 'o1',
    from: { mode: 'list', path: 'items' },
    to: {
      mode: 'rows', table_key: 'parts',
      columns: [{ column_key: 'qty', from: 'qty' }],
      match,
      ...(onNoMatch !== undefined ? { on_no_match: onNoMatch } : {}),
    },
  }],
});
const twoKeys = {
  keys: [
    { row_column: 'part_no', element_field: 'name', op: 'eq' },
    { row_column: 'revision', element_field: 'rev', op: 'eq' },
  ],
};

describe('validateResponseOutputs — composite match key', () => {
  it('accepts a two-key match (both eq)', () => {
    expect(validateResponseOutputs(rowsOutput(twoKeys))).toBeNull();
  });

  it('accepts a two-key match with create when both keys are eq', () => {
    expect(validateResponseOutputs(rowsOutput(twoKeys, 'create'))).toBeNull();
  });

  it('still accepts the legacy single-pair shape (back-compat)', () => {
    expect(validateResponseOutputs(rowsOutput({ row_column: 'part_no', element_field: 'name', op: 'eq' }))).toBeNull();
  });

  it('rejects a key with neither element_field nor source_cell', () => {
    const bad = { keys: [{ row_column: 'part_no', element_field: 'name' }, { row_column: 'revision', element_field: '' }] };
    expect(validateResponseOutputs(rowsOutput(bad))).toMatch(/element_field or source_cell/);
  });

  it('accepts a source-cell-only key (Q19 provenance, blank element_field) — X1', () => {
    const ok = { keys: [
      { row_column: 'part_no', element_field: 'name' },
      { row_column: 'region', element_field: '', source_cell: 'zone' },
    ] };
    expect(validateResponseOutputs(rowsOutput(ok))).toBeNull();
  });

  it('rejects an empty keys[]', () => {
    expect(validateResponseOutputs(rowsOutput({ keys: [] }))).toMatch(/at least one key/);
  });

  it("rejects create when any key is non-eq", () => {
    const mixed = { keys: [
      { row_column: 'part_no', element_field: 'name', op: 'eq' },
      { row_column: 'revision', element_field: 'rev', op: 'contains' },
    ] };
    expect(validateResponseOutputs(rowsOutput(mixed, 'create'))).toMatch(/every match key op to be 'eq'/);
  });

  it('accepts an enrich (no create) under a mixed-op composite key', () => {
    const mixed = { keys: [
      { row_column: 'part_no', element_field: 'name', op: 'eq' },
      { row_column: 'revision', element_field: 'rev', op: 'contains' },
    ] };
    expect(validateResponseOutputs(rowsOutput(mixed))).toBeNull();
  });

  // X2: an explicit merge with no match key at all can never converge.
  it('rejects write_mode:merge with no match block (X2)', () => {
    const cfg = { outputs: [{
      id: 'o1', from: { mode: 'list', path: 'items' },
      to: { mode: 'rows', table_key: 'parts', write_mode: 'merge', columns: [{ column_key: 'qty', from: 'qty' }] },
    }] };
    expect(validateResponseOutputs(cfg)).toMatch(/at least one usable match key/);
  });

  it('accepts write_mode:append with no match block (create-rows fan-out is fine)', () => {
    const cfg = { outputs: [{
      id: 'o1', from: { mode: 'list', path: 'items' },
      to: { mode: 'rows', table_key: 'parts', write_mode: 'append', columns: [{ column_key: 'qty', from: 'qty' }] },
    }] };
    expect(validateResponseOutputs(cfg)).toBeNull();
  });

  it('accepts write_mode:merge when a source-cell-only key is present (X1+X2)', () => {
    const cfg = { outputs: [{
      id: 'o1', from: { mode: 'list', path: 'items' },
      to: {
        mode: 'rows', table_key: 'parts', write_mode: 'merge',
        columns: [{ column_key: 'qty', from: 'qty' }],
        match: { keys: [{ row_column: 'region', element_field: '', source_cell: 'zone' }] },
      },
    }] };
    expect(validateResponseOutputs(cfg)).toBeNull();
  });
});

describe('normalizeRowMatch (BE)', () => {
  it('wraps a legacy single-pair to keys[]', () => {
    expect(normalizeRowMatch({ row_column: 'a', element_field: 'x', op: 'eq' }))
      .toEqual({ keys: [{ row_column: 'a', element_field: 'x', op: 'eq' }] });
  });
  it('passes a keys[] through, dropping a fully-blank key', () => {
    expect(normalizeRowMatch({ keys: [{ row_column: '', element_field: '' }, { row_column: 'a', element_field: 'x' }] }))
      .toEqual({ keys: [{ row_column: 'a', element_field: 'x' }] });
  });
  it('returns undefined for non-object / empty', () => {
    expect(normalizeRowMatch(null)).toBeUndefined();
    expect(normalizeRowMatch({ keys: [] })).toBeUndefined();
  });
});

describe('buildUsableProjection — composite match projection', () => {
  const project = (match, onNoMatch) => {
    const connector = {
      id: 'c1', name: 'C', description: null,
      response_config: rowsOutput(match, onNoMatch),
    };
    return buildUsableProjection(connector, new Map()).response_config.outputs[0].to;
  };

  it('projects a two-key match to keys[] (both keys, eq)', () => {
    const to = project(twoKeys);
    expect(to.match.keys).toHaveLength(2);
    expect(to.match.keys[0]).toEqual({ row_column: 'part_no', element_field: 'name', op: 'eq' });
    expect(to.match.keys[1]).toEqual({ row_column: 'revision', element_field: 'rev', op: 'eq' });
  });

  it('projects a legacy single-pair to a one-key keys[]', () => {
    const to = project({ row_column: 'part_no', element_field: 'name', op: 'eq' });
    expect(to.match.keys).toEqual([{ row_column: 'part_no', element_field: 'name', op: 'eq' }]);
  });

  it('forwards create only when every projected key is eq', () => {
    expect(project(twoKeys, 'create').on_no_match).toBe('create');
    const mixed = { keys: [
      { row_column: 'part_no', element_field: 'name', op: 'eq' },
      { row_column: 'revision', element_field: 'rev', op: 'contains' },
    ] };
    expect(project(mixed, 'create').on_no_match).toBeUndefined();
  });
});
