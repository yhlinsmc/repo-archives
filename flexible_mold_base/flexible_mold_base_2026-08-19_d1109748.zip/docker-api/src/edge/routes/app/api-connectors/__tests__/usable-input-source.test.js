/**
 * usable-input-source.test.js — deriveInputSpec tags a manual per-row cell with
 * source:'manual' and leaves a column cell's source_cell untagged (absence ⇒
 * column), so the FE can distinguish manual per-row vars from column-bound ones.
 * Also covers rows-sink order_by projection.
 */
import { describe, it, expect } from 'vitest';

const { deriveInputSpec, buildUsableProjection } = require('../usable');

/** Build a minimal connector with a rows sink and optional order_by. */
function makeConnector(orderBy) {
  const to = {
    mode: 'rows', table_key: 'tbl',
    columns: [{ column_key: 'ip', from: 'addr' }],
  };
  if (orderBy !== undefined) to.order_by = orderBy;
  return {
    id: 'c1', name: 'test', description: null, group_id: null, group_label: null,
    group_mode: null, sequence: null,
    url: 'https://x', method: 'GET', request_config: null,
    response_config: {
      outputs: [{ id: 'o1', from: { mode: 'list', path: 'items' }, to }],
    },
  };
}

describe('buildUsableProjection — rows sink order_by projection', () => {
  it('projects a valid order_by through to the usable output', () => {
    const usable = buildUsableProjection(makeConnector([{ column: 'ip', dir: 'asc' }]));
    const to = usable.response_config.outputs[0]?.to;
    expect(to?.order_by).toEqual([{ column: 'ip', dir: 'asc' }]);
  });

  it('drops invalid order_by keys (empty column) during projection', () => {
    const usable = buildUsableProjection(makeConnector([
      { column: 'ip', dir: 'asc' },
      { column: '', dir: 'desc' },
    ]));
    const to = usable.response_config.outputs[0]?.to;
    expect(to?.order_by).toEqual([{ column: 'ip', dir: 'asc' }]);
  });

  it('drops invalid order_by keys (bad dir) during projection', () => {
    const usable = buildUsableProjection(makeConnector([
      { column: 'ip', dir: 'asc' },
      { column: 'name', dir: 'random' },
    ]));
    const to = usable.response_config.outputs[0]?.to;
    expect(to?.order_by).toEqual([{ column: 'ip', dir: 'asc' }]);
  });

  it('omits order_by from projected output when no valid keys survive', () => {
    const usable = buildUsableProjection(makeConnector([{ column: '', dir: 'asc' }]));
    const to = usable.response_config.outputs[0]?.to;
    expect('order_by' in to).toBe(false);
  });

  it('omits order_by from projected output when source has none', () => {
    const usable = buildUsableProjection(makeConnector(undefined));
    const to = usable.response_config.outputs[0]?.to;
    expect('order_by' in to).toBe(false);
  });
});

describe('deriveInputSpec — manual input source discrimination', () => {
  it('manual input cell derives source:manual with empty column_key', () => {
    const spec = deriveInputSpec({
      url: 'https://x/{{host}}/{{token}}',
      request_config: {
        input_cells: [
          { table_key: 't1', column_key: 'h', var: 'host' },
          { table_key: 't1', var: 'token', source: 'manual' },
        ],
      },
    });
    const byVar = Object.fromEntries(spec.map((s) => [s.var, s]));
    // Column cell: byte-identical to prior shape (no source field).
    // Absence of source means column for the FE (which only checks === 'manual').
    expect(byVar.host.source_cell).toEqual({ table_key: 't1', column_key: 'h' });
    // Manual cell: source: 'manual' for explicit FE discrimination.
    expect(byVar.token.source_cell).toEqual({ table_key: 't1', column_key: '', source: 'manual' });
  });
});
