/**
 * io.js — cross-environment export / import for api_connectors.
 *
 *   GET  /:id/export   export a connector as portable JSON, WITHOUT secrets
 *   POST /import       import a connector from such a payload
 *
 * Secrets never travel: export strips the sensitive auth_config leaves so the
 * operator re-enters them on the target. Import binds to a local blueprint
 * only when the payload's blueprint resolves here; an admin may store an
 * "unbound" connector (blueprint_id NULL) to re-bind later, but an editor is
 * rejected (403) when no own/shared blueprint resolves — an unbound connector
 * is unmanageable through the editor CRUD ownership chain, so it would be an
 * orphan only an admin could fix. Gated to admin/editor, matching the CRUD
 * surface; export carries no secrets, so an editor may export any connector.
 */
const { pool, t } = require('../../../db');
const { apiOk, apiError, requireAdminOrEditor, uuidv4 } = require('../../../../shared/helpers');
const { TABLES } = require('../../../../shared/constants');
const { logger: rootLogger } = require('../../../../shared/lib/logger');
const { mapRowsFromDb } = require('../../../lib/dto-mapper');
const { buildHierarchyPath, findBlueprintIdsByPath } = require('../../../lib/hierarchy-path');
const { stripAuthConfigSecrets, stripStraySecretLeaves, serializeRead } = require('./serializer');
const { declaredAuthTypeOr } = require('../../../lib/auth-config-secrets');
const {
  validateInputFromStep, validateResponseOutputs, validateInputCells, validateConnectorCoherence,
  loadFollowerColumnKeys, validateNoFollowerColumnTarget,
} = require('./validate');
const { egressAllowedForUrl } = require('../../../../shared/lib/egress-policy');
// SECURITY: a connector url is dispatched outbound in P2; the shared guard pins it
// to an absolute http(s) URL with NO embedded credentials at the storage boundary,
// and sanitizes any pre-existing userinfo out of the exported bundle. One
// definition shared with the flow io + the CRUD url guards.
const {
  isStorableHttpUrl, sanitizeUrlForExport, redactRequestConfigHeaders,
  resolveMaskedRequestConfigHeaders,
} = require('../../../../shared/lib/portable-url-redaction');

const logger = rootLogger.child({ module: 'api-connectors:io' });

const MAX_NAME = 255;

function parseJsonColumn(value) {
  if (value == null) return null;
  if (typeof value === 'object') return value;
  if (typeof value === 'string') {
    try { return JSON.parse(value); } catch { return null; }
  }
  return null;
}

module.exports = function register(router) {
  // GET /:id/export — portable JSON, secrets stripped.
  router.get('/:id/export', async (req, res) => {
    if (!requireAdminOrEditor(req, res)) return;
    let conn;
    try {
      conn = await pool.ro.getConnection();
      const rows = await conn.query(
        `SELECT name, description, is_active, blueprint_id, method, url,
                auth_type, auth_config, request_config, response_config,
                dispatch_origin,
                group_id, group_label, group_mode, \`sequence\`
         FROM \`${t(TABLES.API_CONNECTORS)}\` WHERE id = ?`,
        [req.params.id],
      );
      if (!rows.length) {
        const e = apiError('Connector not found', 'NOT_FOUND', 404);
        return res.status(e.status).json(e.body);
      }
      const row = rows[0];
      // Tolerant per-connector timeout probe: a separate query so the main export
      // SELECT never names timeout_ms (a no-ALTER source lacking the column would
      // 500). Absent column → omit (null) and the import keeps the default.
      let timeoutMs = null;
      try {
        const tr = await conn.query(
          `SELECT timeout_ms FROM \`${t(TABLES.API_CONNECTORS)}\` WHERE id = ?`,
          [req.params.id],
        );
        timeoutMs = tr[0]?.timeout_ms ?? null;
      } catch (probeErr) {
        timeoutMs = null;
        // Unknown column on a no-ALTER source is expected; anything else (pool
        // drop, transient) is worth a breadcrumb since the export silently omits.
        if (!(probeErr?.code === 'ER_BAD_FIELD_ERROR' || probeErr?.errno === 1054)) {
          logger.warn({ err: probeErr, connectorId: req.params.id }, 'timeout_ms export probe failed');
        }
      }
      // Carry the blueprint's root→self lineage as a natural key. blueprint_id
      // is environment-local (fresh UUIDs on import), so import re-binds by
      // this name path; blueprint_id stays only as a legacy fallback.
      let blueprintPath = null;
      if (row.blueprint_id) {
        const nodes = await conn.query(
          `SELECT id, parent_id, name FROM \`${t(TABLES.HIERARCHY_NODES)}\``,
        );
        const p = buildHierarchyPath(nodes, row.blueprint_id);
        if (p.length) blueprintPath = p;
      }
      const exported = {
        name: row.name,
        description: row.description,
        is_active: row.is_active === 1 || row.is_active === true,
        blueprint_id: row.blueprint_id,
        blueprint_path: blueprintPath,
        method: row.method,
        // SECURITY: strip any URL-embedded credentials a legacy row may carry.
        url: sanitizeUrlForExport(row.url),
        auth_type: row.auth_type,
        // SECURITY: stray-leaf strip (a stale secret from a since-changed auth_type)
        // before the sanctioned-leaf strip, so no secret survives even on a row that
        // predates the write-path stray-leaf cleanup.
        auth_config: stripAuthConfigSecrets(
          stripStraySecretLeaves(parseJsonColumn(row.auth_config) || {}, row.auth_type),
          row.auth_type,
        ),
        // SECURITY: blank credential-valued headers (Authorization / api-key) typed
        // literally into request_config.headers — export must carry no secret.
        request_config: redactRequestConfigHeaders(parseJsonColumn(row.request_config)),
        response_config: parseJsonColumn(row.response_config),
        group_id: row.group_id ?? null,
        group_label: row.group_label ?? null,
        group_mode: row.group_mode ?? null,
        sequence: row.sequence ?? null,
        timeout_ms: timeoutMs,
        exported_at: new Date().toISOString(),
      };
      res.json(apiOk(exported));
    } catch (err) {
      logger.error({ err, connectorId: req.params.id }, 'Failed to export connector id=' + req.params.id);
      const e = apiError('Database operation failed', 'INTERNAL_ERROR', 500);
      res.status(e.status).json(e.body);
    } finally {
      if (conn) conn.release();
    }
  });

  // POST /import — create a connector from a portable payload.
  router.post('/import', async (req, res) => {
    if (!requireAdminOrEditor(req, res)) return;
    const { connector } = req.body || {};
    if (!connector || !connector.name || !connector.url) {
      const e = apiError('Invalid import data: name and url are required', 'BAD_REQUEST', 400);
      return res.status(e.status).json(e.body);
    }
    if (typeof connector.name !== 'string' || connector.name.length > MAX_NAME) {
      const e = apiError(`name must be a string ≤ ${MAX_NAME} characters`, 'BAD_REQUEST', 400);
      return res.status(e.status).json(e.body);
    }
    if (!isStorableHttpUrl(connector.url)) {
      const e = apiError('url must be an absolute http(s) URL', 'BAD_REQUEST', 400);
      return res.status(e.status).json(e.body);
    }

    const id = uuidv4();
    const ownerId = req.user?.id || null;
    let conn;
    try {
      conn = await pool.rw.getConnection();

      // SECURITY: save-time mirror of the dispatch-time egress allow-list gate.
      // The blanket CRUD save guard skips /import (it validates its own payload),
      // so enforce the egress gate here too — an off-list import gets a fast 422 at
      // save instead of a silent EGRESS_BLOCKED only when later dispatched.
      // Empty/absent list = allow-all; a corrupt list THROWS → outer catch → 500
      // (fail-closed, never allow-all). Dispatch-time gate remains the backstop.
      const egress = await egressAllowedForUrl(connector.url, connector.method || 'GET', (sql, params) => pool.ro.query(sql, params), t);
      if (!egress.ok) {
        const e = apiError('Connector request is not on the admin egress allow-list', 'EGRESS_BLOCKED', 422);
        return res.status(e.status).json(e.body);
      }

      // Re-bind by the blueprint's lineage (name path), which survives the
      // fresh-UUID import that breaks a raw id match across environments. A
      // unique path match binds; 0 or >1 matches stay unbound for the operator
      // to bind manually. A payload without a path (legacy export) falls back
      // to the old id-existence check.
      // Validate the payload-supplied path: non-empty array of strings, depth
      // capped well above the 4-tier hierarchy so a crafted huge array can't
      // drive an O(nodes × len) scan.
      const blueprintPath = Array.isArray(connector.blueprint_path)
        && connector.blueprint_path.length > 0
        && connector.blueprint_path.length <= 32
        && connector.blueprint_path.every((s) => typeof s === 'string')
        ? connector.blueprint_path : null;
      const wantedBinding = !!blueprintPath || !!connector.blueprint_id;
      let blueprintId = null;
      if (blueprintPath) {
        const nodes = await conn.query(
          `SELECT id, parent_id, name, node_type FROM \`${t(TABLES.HIERARCHY_NODES)}\``,
        );
        const matches = findBlueprintIdsByPath(nodes, blueprintPath);
        if (matches.length === 1) blueprintId = matches[0];
      } else if (connector.blueprint_id) {
        const bp = await conn.query(
          `SELECT 1 FROM \`${t(TABLES.HIERARCHY_NODES)}\` WHERE id = ? LIMIT 1`,
          [connector.blueprint_id],
        );
        if (bp.length) blueprintId = connector.blueprint_id;
      }

      // An editor must never create a connector they cannot later manage. CRUD
      // create rejects an editor's null/foreign blueprint (checkParentOwnership),
      // and an unbound connector fails the editor PUT/DELETE ownership-chain
      // EXISTS predicate — so an unbound import would be an orphan only an admin
      // could fix. Reject for editors; admins may keep an unbound connector.
      if (req.user?.role !== 'admin') {
        let ownOrShared = false;
        if (blueprintId) {
          const own = await conn.query(
            `SELECT owner_id FROM \`${t(TABLES.HIERARCHY_NODES)}\` WHERE id = ?`,
            [blueprintId],
          );
          const bpOwner = own.length ? own[0].owner_id : undefined;
          ownOrShared = bpOwner === null || bpOwner === (req.user?.id || null);
        }
        if (!ownOrShared) {
          const e = apiError('An editor can only import a connector bound to a blueprint they own or that is shared', 'FORBIDDEN', 403);
          return res.status(e.status).json(e.body);
        }
      }

      // The member list is the COLUMN's, asked of the DDL — the literal array
      // this replaced was a third copy of it, and a copy is what stops being
      // updated. The degrade-to-'none' posture is kept on purpose: a hand-edited
      // bundle should import rather than fail, and an import stores no secret
      // leaf under any type.
      const authType = declaredAuthTypeOr(TABLES.API_CONNECTORS, connector.auth_type);
      // The payload carries no secrets (export stripped them); a hand-edited bundle
      // could still inject a stray-type leaf, so strip stray leaves AND the sanctioned
      // leaf before storing — no secret is ever persisted from import.
      const authConfig = stripAuthConfigSecrets(
        stripStraySecretLeaves(parseJsonColumn(connector.auth_config) || {}, authType),
        authType,
      );

      const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
      // Import degrades malformed bundle metadata to ungrouped instead of 400ing:
      // a hand-edited payload should not fail the whole import, and orphan
      // label/mode/sequence must never be stored without their group_id.
      const groupValid = typeof connector.group_id === 'string' && UUID_RE.test(connector.group_id)
        && (connector.group_mode === 'aggregation' || connector.group_mode === 'chain')
        && Number.isInteger(connector.sequence) && connector.sequence >= 1;
      const groupFields = groupValid
        ? {
            group_id: connector.group_id,
            group_label: typeof connector.group_label === 'string' ? connector.group_label.slice(0, 255) : null,
            group_mode: connector.group_mode,
            sequence: connector.sequence,
          }
        : { group_id: null, group_label: null, group_mode: null, sequence: null };

      // A hand-edited import payload is held to the same chain-wiring shape as a
      // CRUD write. Validate against the effective stored sequence, not the raw
      // payload value: when malformed group metadata degrades to ungrouped the
      // stored sequence becomes null, so chain wiring that referenced a numeric
      // payload sequence must be rejected — otherwise input_from_step survives
      // with a null sequence and surfaces as a confusing runtime chain break.
      const parsedRequestConfig = parseJsonColumn(connector.request_config);
      const parsedResponseConfig = parseJsonColumn(connector.response_config);
      // Q9 (D2 amendment A4): held to the same follower-column guard as a CRUD
      // write. `blueprintId` is null for an unbound import (0/>1 path matches,
      // or no path/id at all) — nothing to judge outputs against, so the guard
      // is a no-op exactly like the CRUD twin's own unbound-connector branch.
      const followerColumnKeys = await loadFollowerColumnKeys(conn, t, blueprintId);
      const shapeError = validateInputFromStep(parsedRequestConfig, groupFields.sequence)
        || validateInputCells(parsedRequestConfig)
        || validateResponseOutputs(parsedResponseConfig)
        || validateConnectorCoherence(parsedRequestConfig, parsedResponseConfig)
        || validateNoFollowerColumnTarget(parsedResponseConfig, followerColumnKeys);
      if (shapeError) {
        const e = apiError(shapeError, 'BAD_REQUEST', 400);
        return res.status(e.status).json(e.body);
      }

      // Task 8 back-compat: an incoming payload from an older export that still
      // carries `allowed_hosts` is ignored silently (dropped on read) — the column
      // is gone, and a hand-edited/legacy bundle must still import cleanly.
      await conn.query(
        `INSERT INTO \`${t(TABLES.API_CONNECTORS)}\`
         (id, name, description, is_active, owner_id, blueprint_id,
          method, url, auth_type, auth_config, request_config, response_config,
          dispatch_origin,
          group_id, group_label, group_mode, \`sequence\`)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          id,
          connector.name,
          connector.description || null,
          connector.is_active === false ? 0 : 1,
          ownerId,
          blueprintId,
          ['GET', 'POST', 'PUT', 'PATCH', 'DELETE'].includes(connector.method) ? connector.method : 'GET',
          connector.url,
          authType,
          JSON.stringify(authConfig),
          // THE SENTINEL IS NEVER A CREDENTIAL, ON THIS VERB EITHER. An import is
          // a create, and a bundle carrying `"Authorization":"****"` stored the
          // four literal characters as the header a request is dispatched with —
          // the same shape the create path had for `auth_config`. There is no
          // stored row behind an import, so the resolution takes its safe arm and
          // drops the key. A genuine export/re-import round trip never carries
          // the sentinel (export blanks these to `''`), so this only bites a
          // hand-built bundle — which is exactly the input this path accepts.
          connector.request_config
            ? JSON.stringify(resolveMaskedRequestConfigHeaders(
              parseJsonColumn(connector.request_config), null,
            ))
            : null,
          connector.response_config ? JSON.stringify(parseJsonColumn(connector.response_config)) : null,
          ['infra', 'edge'].includes(connector.dispatch_origin) ? connector.dispatch_origin : 'infra',
          groupFields.group_id,
          groupFields.group_label,
          groupFields.group_mode,
          groupFields.sequence,
        ],
      );

      // SECURITY: an import is a create path, so it must obey the approval
      // lifecycle — without this an editor could import a connector that lands
      // with NULL status (= grandfathered = dispatches immediately), bypassing
      // review. Stamped as a separate best-effort UPDATE (not folded into the
      // core INSERT) so a no-ALTER DB lacking the column degrades to NULL =
      // approved rather than failing the whole import. admin → approved; editor
      // → pending. The dispatch gate is the backstop regardless.
      try {
        if (req.user?.role === 'admin') {
          await conn.query(
            `UPDATE \`${t(TABLES.API_CONNECTORS)}\` SET status='approved', approved_by=?, approved_at=NOW() WHERE id = ?`,
            [ownerId, id],
          );
        } else {
          await conn.query(
            `UPDATE \`${t(TABLES.API_CONNECTORS)}\` SET status='pending' WHERE id = ?`,
            [id],
          );
        }
      } catch (stampErr) {
        if (!(stampErr?.code === 'ER_BAD_FIELD_ERROR' || stampErr?.errno === 1054)) throw stampErr;
      }

      // Best-effort timeout_ms carry: apply the exported per-connector timeout
      // when present and in range (1000–120000ms). Separate best-effort UPDATE so
      // a no-ALTER target lacking the column degrades to the default; an absent or
      // out-of-range value is ignored so the INSERT default stands.
      const importTimeout = connector.timeout_ms;
      if (Number.isInteger(importTimeout) && importTimeout >= 1000 && importTimeout <= 120000) {
        try {
          await conn.query(
            `UPDATE \`${t(TABLES.API_CONNECTORS)}\` SET timeout_ms = ? WHERE id = ?`,
            [importTimeout, id],
          );
        } catch (toErr) {
          if (!(toErr?.code === 'ER_BAD_FIELD_ERROR' || toErr?.errno === 1054)) throw toErr;
        }
      }

      const rows = await conn.query(
        `SELECT * FROM \`${t(TABLES.API_CONNECTORS)}\` WHERE id = ?`, [id],
      );
      // Shape the row like the CRUD read path (parse JSON columns, coerce
      // booleans) and mask any secret leaf before returning.
      const shaped = serializeRead(mapRowsFromDb('api_connectors', rows)[0]);
      res.status(201).json(apiOk({ ...shaped, unbound: blueprintId === null && wantedBinding }));
    } catch (err) {
      logger.error({ err, name: connector.name }, 'Failed to import connector name=' + connector.name);
      const e = apiError('Database operation failed', 'INTERNAL_ERROR', 500);
      res.status(e.status).json(e.body);
    } finally {
      if (conn) conn.release();
    }
  });
};
