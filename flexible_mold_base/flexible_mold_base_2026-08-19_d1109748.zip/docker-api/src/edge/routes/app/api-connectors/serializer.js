/**
 * serializer.js — field-level secret handling for api_connectors.
 *
 * api_connectors is the only engine table that stores secrets (an auth token,
 * an API-key value, a basic-auth password) inside a JSON column. The generic
 * DTO mapper only parses/stringifies JSON; it has no notion of "encrypt this
 * leaf". This module supplies the three boundary transforms the CRUD factory
 * calls through its serializeWrite / serializeRead hooks:
 *
 *   write  → encrypt the sensitive leaf of auth_config (AES-256-GCM, reusing
 *            settings-crypto), and preserve an unchanged `****`-masked secret
 *            by reading the stored ciphertext back instead of overwriting it.
 *   read   → mask the sensitive leaf with `****` so the API never returns a
 *            secret (plaintext or ciphertext) to a client.
 *   decrypt→ recover the plaintext leaf for server-side dispatch (P2). Not on
 *            any P1 request path; exported for the round-trip test and P2.
 *
 * Canonical auth_config shapes (auth_type drives which leaf is sensitive):
 *   none    → {}                      (no secret)
 *   bearer  → { token }               (token is secret)
 *   api_key → { header, value }       (value is secret; header name is not)
 *   basic   → { username, password }  (password is secret; username is not)
 */
const db = require('../../../db');
const { t } = db;
const { encrypt } = require('../../../../shared/lib/settings-crypto');
const { decryptLeafOrThrow } = require('../../../../shared/lib/decrypt-error');
const { TABLES } = require('../../../../shared/constants');
const { logger: rootLogger } = require('../../../../shared/lib/logger');
// The leaf map, the leaf union and the member list all live in one place, read
// from the DDL — see that module for why a copy per serializer is two answers
// to "is this row's credential a secret", not one answer written twice.
const {
  ALL_SECRET_LEAVES,
  pathsFor,
  readMaskPaths,
  refuseUndeclaredAuthType,
  refuseUnreadableStoredAuthType,
} = require('../../../lib/auth-config-secrets');
// The credential-header vocabulary and the url sanitiser the export path already
// uses — one definition, so a value this repository calls a secret on one
// surface cannot be an ordinary value on another.
const {
  maskRequestConfigHeaders,
  resolveMaskedRequestConfigHeaders,
  sanitizeUrlForExport,
} = require('../../../../shared/lib/portable-url-redaction');

const logger = rootLogger.child({ module: 'api-connectors:serializer' });

// OPERATIONS: this is the only runtime-secret path that depends on the
// encryption key. Without it, settings-crypto is fail-closed and a connector
// carrying a secret is REJECTED at save (422); warn once at load so an operator
// fixes the deployment before a save fails. Secret-free connectors still save.
if (!process.env.SETTINGS_ENCRYPTION_KEY) {
  logger.warn('SETTINGS_ENCRYPTION_KEY is not set — saving an API connector with a secret will be rejected (422) until it is configured');
}

const MASK = '****';
// The answer for "there is no stored row to read" — a create, or an update
// whose id names nothing. Frozen and shared so the create path and the
// row-absent path cannot come to differ.
const NO_STORED_ROW = Object.freeze({
  found: false, authConfig: null, authType: null, requestConfig: null,
});
// settings-crypto stamps every ciphertext with this prefix; a leaf already
// carrying it is encrypted, so re-encrypting must be skipped (idempotence).
const ENC_PREFIX = 'enc:v1:';

function isNonEmptyString(v) {
  return typeof v === 'string' && v.length > 0;
}

/** A JSON column as an object, whether the driver handed it back parsed or raw.
 *  An unparseable value reads as absent — a caller must not treat a string it
 *  cannot interpret as a structure it can. */
function parseJsonColumn(value) {
  if (value == null) return null;
  if (typeof value === 'object') return value;
  if (typeof value !== 'string') return null;
  try { return JSON.parse(value); } catch { return null; }
}

function getAt(obj, path) {
  let cur = obj;
  for (const key of path) {
    if (cur == null || typeof cur !== 'object') return undefined;
    cur = cur[key];
  }
  return cur;
}

/** Clone along `path` and apply `fn(leaf)` at the leaf. `fn` returning
 *  `undefined` deletes the leaf key. Missing intermediate nodes are skipped. */
function updateAt(obj, path, fn) {
  if (!obj || typeof obj !== 'object') return obj;
  const out = { ...obj };
  let cursor = out;
  for (let i = 0; i < path.length - 1; i += 1) {
    const key = path[i];
    if (cursor[key] == null || typeof cursor[key] !== 'object') return out;
    cursor[key] = { ...cursor[key] };
    cursor = cursor[key];
  }
  const leafKey = path[path.length - 1];
  if (!(leafKey in cursor)) return out;
  const next = fn(cursor[leafKey]);
  if (next === undefined) delete cursor[leafKey];
  else cursor[leafKey] = next;
  return out;
}

function mapLeaves(authConfig, authType, fn) {
  let out = authConfig;
  for (const path of pathsFor(authType)) out = updateAt(out, path, fn);
  return out;
}

/** Encrypt each sensitive leaf. Skips empties, the mask sentinel, and values
 *  already encrypted (idempotent re-save). */
function encryptAuthConfig(authConfig, authType) {
  return mapLeaves(authConfig, authType, (v) => {
    if (!isNonEmptyString(v)) return v;
    if (v === MASK) return v; // caller resolves MASK before encrypting
    if (v.startsWith(ENC_PREFIX)) return v;
    return encrypt(v);
  });
}

/**
 * Replace every non-empty secret-NAMED leaf with the mask sentinel.
 *
 * MASKED BY LEAF NAME, NOT BY THE ROW'S CURRENT TYPE, and that is the half a
 * write-path fix cannot reach. Rows produced before the type-change cleanup are
 * already in deployed databases carrying the previous type's ciphertext, and
 * asking what the CURRENT type sanctions masks nothing for them — 'none'
 * sanctions no leaf, so the stray ciphertext went out verbatim to every reader
 * of a view-all mount. A read has no reason to make the distinction: a leaf
 * whose NAME is a credential name is one this API must not emit, whatever the
 * row's type says. `authType` is kept in the signature so every transform here
 * reads the same, and is deliberately not consulted.
 */
function maskAuthConfig(authConfig, _authType) {
  return readMaskPaths().reduce(
    (acc, path) => updateAt(acc, path, (v) => (isNonEmptyString(v) ? MASK : v)),
    authConfig,
  );
}

/** Decrypt each sensitive leaf (server-side use only). Throws DecryptError when
 *  a leaf cannot be decrypted (wrong key / missing key). */
function decryptAuthConfig(authConfig, authType) {
  return mapLeaves(authConfig, authType, (v) => (isNonEmptyString(v) ? decryptLeafOrThrow(v) : v));
}

/** True when every sensitive leaf decrypts under the current key (or there is
 *  no secret). SECURITY: returns only a boolean — never the decrypted value. */
function probeDecryptable(authConfig, authType) {
  for (const path of pathsFor(authType)) {
    const v = getAt(authConfig, path);
    if (!isNonEmptyString(v)) continue;
    try { decryptLeafOrThrow(v); } catch { return false; }
  }
  return true;
}

/** Drop every sensitive leaf entirely so a portable connector never carries a
 *  secret (the operator re-enters it after import). */
function stripAuthConfigSecrets(authConfig, authType) {
  return mapLeaves(authConfig, authType, () => undefined);
}

/**
 * Remove every ALL_SECRET_LEAVES leaf that is NOT the sanctioned sensitive leaf
 * for `authType`. Closes the stray-leaf gap: a connector saved as 'bearer'
 * (storing `token`) then changed to 'none' keeps a stale `token` ciphertext that
 * stripAuthConfigSecrets (which only touches the current type's leaf) would miss —
 * so it would leak verbatim on export. Run BEFORE stripAuthConfigSecrets so no
 * mismatched plaintext or ciphertext survives. Mirrors flow-recipe-steps/serializer.
 */
function stripStraySecretLeaves(authConfig, authType) {
  if (!authConfig || typeof authConfig !== 'object') return authConfig;
  const allowed = new Set(pathsFor(authType).map((p) => p[p.length - 1]));
  const out = { ...authConfig };
  for (const leaf of ALL_SECRET_LEAVES) {
    if (!allowed.has(leaf) && leaf in out) delete out[leaf];
  }
  return out;
}

/**
 * Read the stored auth_config + auth_type for a connector id, used for
 * mask-preserve on update. Returns { found, authConfig (parsed or null),
 * authType (VERBATIM), requestConfig }.
 *
 * `found` IS NOT DERIVABLE FROM THE OTHER THREE, which is why it is returned.
 * "No such row" and "a row whose stored type this module cannot resolve" need
 * opposite answers — the first is a 404 the UPDATE's own zero-match produces,
 * the second is a refusal — and both used to arrive here as `authType: null`.
 *
 * AND THE TYPE IS RETURNED AS THE COLUMN HOLDS IT. The `|| null` this line used
 * to carry folded the invalid-enum member `''` into the same `null`, which
 * `pathsFor` then read as "this row sanctions no leaf" — the exact answer that
 * makes the strip delete a credential. A caller that must decide whether the
 * stored value is storable has to be shown the stored value.
 *
 * ASKED OF THE ROW THE STATEMENT WILL UPDATE. `conn` is the write connection the
 * CRUD factory is inside a transaction on, and the row is taken `FOR UPDATE`, so
 * the value bound as "what is stored" is the value the UPDATE lands on top of
 * and no concurrent commit can slip between the two. Without it this read was on
 * `pool.ro` — a different pool that may address a replica — and the resolver's
 * "no stored secret" arm DROPS the leaf, so a read that merely missed deleted
 * the credential the mask exists to preserve.
 *
 * The connectionless form is kept for the paths that call this outside a factory
 * write (none today), and is the read it always was.
 */
async function readStored(id, conn) {
  // Lazy pool access: the pool is null at module load under the cold-boot
  // contract and configured later, so reference it at call time.
  const cols = 'auth_config, auth_type, request_config';
  const rows = conn
    ? await conn.query(
      `SELECT ${cols} FROM \`${t(TABLES.API_CONNECTORS)}\` WHERE id = ? FOR UPDATE`,
      [id],
    )
    : await db.pool.ro.query(
      `SELECT ${cols} FROM \`${t(TABLES.API_CONNECTORS)}\` WHERE id = ?`,
      [id],
    );
  if (!rows.length) return NO_STORED_ROW;
  return {
    found: true,
    authConfig: parseJsonColumn(rows[0].auth_config),
    authType: rows[0].auth_type,
    requestConfig: parseJsonColumn(rows[0].request_config),
  };
}

/** Replace every `****`-masked sensitive leaf with the stored ciphertext for
 *  the same path; drop the leaf when there is no stored secret (so the literal
 *  mask is never persisted as a value).
 *
 *  THE STORED VALUE CAN ITSELF BE THE SENTINEL, and that is the case the
 *  emptiness test alone lets through: `'****'` is a non-empty string, so a row
 *  already holding it kept it on every save, and `decryptLeafOrThrow` returns
 *  any value without the `enc:v1:` prefix verbatim — so the request went out
 *  carrying `Bearer ****` for as long as the row existed. Measured: a row whose
 *  stored `auth_config.token` was `'****'`, PUT with the same body, answered 200
 *  with the column unchanged. Such rows exist because the create path used to
 *  persist the sentinel; refusing to carry it forward is the repair half of that
 *  fix, and it costs nothing else — dropping the leaf is what "there is no stored
 *  secret" already meant. */
function resolveMaskedLeaves(authConfig, authType, storedAuthConfig) {
  return pathsFor(authType).reduce((acc, path) => {
    if (getAt(acc, path) !== MASK) return acc;
    const prior = getAt(storedAuthConfig || {}, path);
    const usable = isNonEmptyString(prior) && prior !== MASK;
    return updateAt(acc, path, () => (usable ? prior : undefined));
  }, authConfig);
}

/**
 * serializeWrite hook. Encrypts the secret leaf of data.auth_config before it
 * is persisted. On update, a leaf left as the `****` mask means "unchanged" —
 * it is replaced with the stored ciphertext rather than overwriting the real
 * secret. Returns a new data object; leaves data untouched when it carries
 * neither auth_config nor auth_type (a partial update of other fields).
 *
 * SECURITY — the two auth_config/auth_type consistency invariants enforced here,
 * mirroring flow-recipe-steps/serializer.js:
 *   1. Stray secret leaves: a leaf that is not the sanctioned one for the
 *      effective type is stripped BEFORE encrypt, so `auth_type='none'` with
 *      `{token:'x'}` never stores the token unencrypted.
 *   2. Type-change-only PUT: when the type changes and the body carries no
 *      auth_config, the stored config is loaded, cleaned against the new type
 *      and re-persisted — otherwise the previous type's ciphertext stays in the
 *      column while the row claims to have no credential.
 */
async function serializeWrite(data, ctx = {}) {
  if (!data || typeof data !== 'object') return data;

  const hasAuthConfig = data.auth_config !== undefined;
  const hasAuthType = data.auth_type !== undefined;
  const hasRequestConfig = data.request_config !== undefined;

  // None of the three in the body — a partial update of other fields, untouched.
  if (!hasAuthConfig && !hasAuthType && !hasRequestConfig) return data;

  // ONE READ OF THE STORED ROW, SHARED BY BOTH MASK RESOLUTIONS. Two reads would
  // be two answers under the lock they are supposed to be taking together, and
  // the second would be a second FOR UPDATE on a row this transaction already
  // holds — harmless, and still two statements where the decision is one.
  let storedRow;
  const stored = async () => {
    if (storedRow === undefined) {
      storedRow = (ctx.isUpdate && ctx.id)
        ? await readStored(ctx.id, ctx.conn)
        : NO_STORED_ROW;
    }
    return storedRow;
  };

  // A credential header still reading `****` means "unchanged", exactly as a
  // masked auth_config leaf does. The editor renders what the read gave it and
  // saves the whole config back, so an unresolved mask would overwrite the
  // stored credential with the literal sentinel. Resolved for CREATE too: there
  // the stored side is empty, and the safe arm drops the key rather than
  // persisting `****` as the value a request is dispatched with.
  let out = data;
  if (hasRequestConfig) {
    const incoming = typeof data.request_config === 'string'
      ? parseJsonColumn(data.request_config)
      : data.request_config;
    if (incoming && typeof incoming === 'object') {
      out = {
        ...out,
        request_config: resolveMaskedRequestConfigHeaders(incoming, (await stored()).requestConfig),
      };
    }
  }
  data = out;
  if (!hasAuthConfig && !hasAuthType) return data;

  // THE VALUE THAT DECIDES WHICH LEAF IS A SECRET IS THE VALUE THE COLUMN WILL
  // HOLD, and this is where that is enforced for every path — including the ones
  // that do not pass the mount's own domain gate. Refused BEFORE the first
  // `pathsFor`, because an undeclared spelling sanctions no leaf, and every
  // transform below reads "no sanctioned leaf" as "this row has no secret":
  // the mask is never resolved, the stray strip deletes the token because
  // nothing is allowed, the encryptor iterates nothing, and `{}` lands over the
  // stored ciphertext with a 200.
  if (hasAuthType) refuseUndeclaredAuthType(TABLES.API_CONNECTORS, data.auth_type);

  // TYPE-CHANGE-ONLY PUT. `PUT {"auth_type":"none"}` on a bearer connector is
  // canonical and needs no trick: the serializer used to opt out because the
  // body carried no `auth_config`, leaving the bearer ciphertext physically in
  // the column while the row said it had no credential. Load the stored config,
  // strip what the new type does not sanction, and re-persist it.
  if (!hasAuthConfig && ctx.isUpdate && ctx.id) {
    const prior = await stored();
    if (prior.authConfig == null) return data;
    const cleaned = stripStraySecretLeaves(prior.authConfig, data.auth_type);
    return { ...data, auth_config: encryptAuthConfig(cleaned, data.auth_type) };
  }
  // A type change outside an update-with-id has nothing stored to clean.
  if (!hasAuthConfig) return data;

  let authConfig = data.auth_config;
  // A client may send the JSON column as a string; normalise to an object so
  // the leaf transform can run, then mapRowToDb re-stringifies downstream.
  if (typeof authConfig === 'string') {
    try { authConfig = JSON.parse(authConfig); } catch { return data; }
  }
  if (authConfig === null) return data;

  let authType = data.auth_type;

  // Resolve masked leaves against the stored row (and recover auth_type when
  // the update body omits it).
  //
  // RESOLVED ON CREATE TOO, and the safe arm is the whole reason. `POST
  // {"auth_type":"bearer","auth_config":{"token":"****"}}` is what the editor
  // sends after a masked read of one connector is carried into a new one, and
  // this branch used to run only for an update: the sentinel survived the stray
  // strip (`token` IS sanctioned for bearer), `encryptAuthConfig` returns MASK
  // untouched by its own contract, and the four literal characters were
  // persisted UNENCRYPTED as the credential — which `decryptLeafOrThrow` then
  // reads as legacy plaintext and sends upstream. There is no stored ciphertext
  // to preserve on a create, so `resolveMaskedLeaves` drops the leaf instead,
  // exactly as `resolveMaskedRequestConfigHeaders` already does for a masked
  // credential header on the same verb.
  {
    const needsType = authType === undefined && !!(ctx.isUpdate && ctx.id);
    const hasMask = needsType
      || pathsFor(authType).some((p) => getAt(authConfig, p) === MASK);
    if (hasMask) {
      const prior = await stored();
      if (needsType) {
        // THE EFFECTIVE TYPE IS NOW THE STORED ONE, SO IT IS JUDGED HERE. The
        // gate above judges the body's `auth_type` and runs only when the body
        // carries one; on this branch it does not, and every transform below
        // resolves its leaf from the value this row happens to hold. An
        // unreadable stored type sanctions no leaf, which reads as "no secret
        // to preserve" — measured: `{}` bound over the ciphertext, and the
        // operator's replacement secret dropped with it.
        //
        // `found` is what keeps this from answering the wrong question about a
        // PUT to an id that names nothing: there the UPDATE matches no row and
        // the path already answers 404, so the write is left exactly as it was.
        if (prior.found) refuseUnreadableStoredAuthType(TABLES.API_CONNECTORS, prior.authType);
        authType = prior.authType;
      }
      authConfig = resolveMaskedLeaves(authConfig, authType, prior.authConfig);
    }
  }

  // SECURITY: strip any secret leaf that doesn't belong to the effective auth_type
  // BEFORE encrypt — otherwise auth_type='none' with {token:'x'} stores the token
  // unencrypted (encryptAuthConfig iterates zero paths for 'none') and serializeRead
  // returns it unmasked. Mirrors flow-recipe-steps/serializer.serializeWrite.
  authConfig = stripStraySecretLeaves(authConfig, authType);

  return { ...data, auth_config: encryptAuthConfig(authConfig, authType) };
}

/**
 * serializeRead hook. Hides everything on this row that the repository has
 * already classified as a secret, and drops internal approval bookkeeping.
 * Returns a new row object.
 *
 * THREE SURFACES, ONE CLASSIFICATION. `auth_config` was the only one this hook
 * touched, while two other columns on the same row carry the same kinds of
 * secret and were already treated as secrets everywhere else:
 *
 *   - `request_config.headers` — export blanks credential-valued headers under
 *     a comment saying an export must carry no secret, and the ordinary read
 *     returned the identical value in full to every admin and every editor;
 *   - `url` — new writes REFUSE embedded userinfo, export sanitises it, clone
 *     sanitises it, and the read handed a legacy row's plaintext Basic-auth
 *     credential straight back.
 *
 * The url is SANITISED rather than masked, and the difference is deliberate: a
 * masked url is not a url, the write boundary refuses userinfo anyway, and
 * handing the editor the credential-free form means the next ordinary save
 * heals the row instead of round-tripping the secret. Dispatch reads the stored
 * column directly and is unaffected.
 */
function serializeRead(row) {
  if (!row || typeof row !== 'object') return row;
  // SECURITY: approved_by (the approving admin's user id) and approved_at are
  // internal bookkeeping the client never renders — only `status` and
  // `review_note` (the rejection reason) are surfaced. Strip them from every
  // read so an editor can't learn which admin approved a connector, or when.
  const rest = { ...row };
  delete rest.approved_by;
  delete rest.approved_at;
  if (typeof rest.url === 'string') rest.url = sanitizeUrlForExport(rest.url);
  if (rest.request_config != null && typeof rest.request_config === 'object') {
    rest.request_config = maskRequestConfigHeaders(rest.request_config);
  }
  if (rest.auth_config == null) return rest;
  // SECURITY: a non-object auth_config means the JSON column failed to parse
  // (corrupt row / driver edge). mapLeaves would pass the raw string through
  // unmasked — possibly leaking ciphertext — so blank it rather than echo it.
  if (typeof rest.auth_config !== 'object') return { ...rest, auth_config: {} };
  return { ...rest, auth_config: maskAuthConfig(rest.auth_config, rest.auth_type) };
}

// SECURITY: returns the PLAINTEXT secret. Used only by the P2 dispatch path
// (assemble the outbound auth header) and the round-trip test — NEVER pass the
// result to apiOk()/a client response.
function decryptRow(row) {
  if (!row || typeof row !== 'object' || row.auth_config == null) return row;
  return { ...row, auth_config: decryptAuthConfig(row.auth_config, row.auth_type) };
}

module.exports = {
  serializeWrite,
  serializeRead,
  decryptRow,
  encryptAuthConfig,
  maskAuthConfig,
  decryptAuthConfig,
  probeDecryptable,
  stripAuthConfigSecrets,
  stripStraySecretLeaves,
  MASK,
};
