/**
 * health.js — GET /health — admin/editor, live-derived health of every
 * connector for the connectors-list status column. Cross-blueprint: one IN
 * query for the bound blueprints' field keys and one for the bound
 * transformers' declared output keys, then the shared derivation per connector.
 *
 * Mirrors the schema-status visibility-surface contract: admin/editor, not
 * cached, hard per-query timeout, and a derive failure degrades to an empty
 * statuses map (HTTP 200) rather than a 5xx — the calling list UI keeps working
 * and renders an "unknown" icon for any connector absent from the map.
 */
const { pool, t } = require('../../../db');
const { apiOk, requireAdminOrEditor } = require('../../../../shared/helpers');
const { TABLES } = require('../../../../shared/constants');
const { mapRowsFromDb } = require('../../../lib/dto-mapper');
const { parseOutputKeys } = require('./usable');
const { computeConnectorHealth } = require('../../../lib/connector-health');
const { probeDecryptable } = require('./serializer');
const { logger: rootLogger } = require('../../../../shared/lib/logger');

const logger = rootLogger.child({ module: 'api-connectors:health' });

const DERIVE_TIMEOUT_MS = 3000;

// Race a promise against a timeout. Never throws: resolves { ok, value } or
// { ok: false }. A timed-out query may still be mid-protocol on the connection,
// so the caller destroys (not releases) the connection on any non-ok result.
function withTimeout(promise, ms) {
  return new Promise((resolve) => {
    let settled = false;
    const timer = setTimeout(() => {
      if (settled) return;
      settled = true;
      resolve({ ok: false });
    }, ms);
    Promise.resolve(promise).then(
      (value) => { if (!settled) { settled = true; clearTimeout(timer); resolve({ ok: true, value }); } },
      () => { if (!settled) { settled = true; clearTimeout(timer); resolve({ ok: false }); } },
    );
  });
}

function register(router) {
  router.get('/health', async (req, res) => {
    if (!requireAdminOrEditor(req, res)) return;

    let conn;
    let poisoned = false;
    try {
      conn = await pool.ro.getConnection();

      const connectorsRace = await withTimeout(
        conn.query(
          `SELECT id, blueprint_id, request_config, response_config, auth_type, auth_config
             FROM \`${t(TABLES.API_CONNECTORS)}\``,
        ),
        DERIVE_TIMEOUT_MS,
      );
      if (!connectorsRace.ok) { poisoned = true; throw new Error('connectors read failed'); }
      const connectors = mapRowsFromDb('api_connectors', connectorsRace.value);

      const blueprintIds = [...new Set(connectors.map((c) => c.blueprint_id).filter(Boolean))];
      const transformerIds = [
        ...new Set(connectors.map((c) => (c.response_config || {}).transformer_id).filter(Boolean)),
      ];

      // field_key set per blueprint (scalar field_keys and table table_keys both
      // live in blueprint_fields; every field_key is a valid output target).
      const fieldsByBlueprint = new Map();
      if (blueprintIds.length > 0) {
        const fieldRace = await withTimeout(
          conn.query(
            `SELECT blueprint_id, field_key FROM \`${t(TABLES.BLUEPRINT_FIELDS)}\`
              WHERE blueprint_id IN (${blueprintIds.map(() => '?').join(', ')})`,
            blueprintIds,
          ),
          DERIVE_TIMEOUT_MS,
        );
        if (!fieldRace.ok) { poisoned = true; throw new Error('blueprint_fields read failed'); }
        for (const row of fieldRace.value) {
          let set = fieldsByBlueprint.get(row.blueprint_id);
          if (!set) { set = new Set(); fieldsByBlueprint.set(row.blueprint_id, set); }
          if (row.field_key) set.add(row.field_key);
        }
      }

      const outputKeysById = new Map();
      if (transformerIds.length > 0) {
        const tRace = await withTimeout(
          conn.query(
            `SELECT id, output_keys FROM \`${t(TABLES.TRANSFORMERS)}\`
              WHERE id IN (${transformerIds.map(() => '?').join(', ')})`,
            transformerIds,
          ),
          DERIVE_TIMEOUT_MS,
        );
        if (!tRace.ok) { poisoned = true; throw new Error('transformers read failed'); }
        for (const row of tRace.value) outputKeysById.set(row.id, parseOutputKeys(row.output_keys));
      }

      const statuses = {};
      for (const c of connectors) {
        // SECURITY: probeDecryptable returns only a boolean; the secret is never
        // read into the response.
        let secretDecryptable = true;
        try {
          secretDecryptable = probeDecryptable(c.auth_config || {}, c.auth_type);
        } catch { secretDecryptable = false; }

        if (!c.blueprint_id) {
          statuses[c.id] = { status: 'unbound', resolved_count: 0, missing_count: 0, missing_keys: [], secret_decryptable: secretDecryptable };
          continue;
        }
        const known = fieldsByBlueprint.get(c.blueprint_id) || new Set();
        const transformerId = (c.response_config || {}).transformer_id || null;
        const projected = {
          request_config: c.request_config || {},
          response_config: {
            ...(c.response_config || {}),
            transformer_output_keys: transformerId ? (outputKeysById.get(transformerId) ?? null) : null,
          },
        };
        const h = computeConnectorHealth(projected, known);
        statuses[c.id] = {
          status: h.status,
          resolved_count: h.resolvedKeys.length,
          missing_count: h.missingKeys.length,
          missing_keys: h.missingKeys,
          secret_decryptable: secretDecryptable,
        };
      }

      return res.json(apiOk({ statuses, derived_at: new Date().toISOString() }));
    } catch (err) {
      // SAFETY: never 5xx — degrade to an empty map so the list UI keeps
      // working and renders "unknown" for every connector. Raw error to logs.
      logger.warn({ err }, 'connector-health derive failed — returning empty map');
      return res.json(apiOk({ statuses: {}, derived_at: new Date().toISOString() }));
    } finally {
      if (conn) {
        try {
          if (poisoned && typeof conn.destroy === 'function') conn.destroy();
          else conn.release();
        } catch { /* connection already gone */ }
      }
    }
  });
}

module.exports = register;
