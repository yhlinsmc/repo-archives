/**
 * api-connectors/clone.js — POST /:id/clone
 *
 * Duplicate an existing connector. Unlike export→import (which strips secrets
 * for cross-environment transfer), an in-place clone COPIES the encrypted
 * auth_config ciphertext verbatim so the duplicate is immediately usable
 * without re-entering credentials. The ciphertext is self-contained
 * (AES-256-GCM, IV embedded, key from SETTINGS_ENCRYPTION_KEY, no row-id AAD),
 * so copying it to a new id decrypts correctly; plaintext never leaves the DB.
 *
 * Ownership mirrors create/import: owner_id is stamped to the caller, and an
 * editor may only clone a connector bound to a blueprint they own or that is
 * shared (an unbound/foreign clone would be an orphan only an admin could fix).
 * The clone never inherits bundle membership (group_id NULL) — joining the
 * source's bundle would collide on its sequence and is rarely intended.
 *
 * Registered BEFORE the generic CRUD `/:id` so `/:id/clone` is not shadowed.
 */
const { pool, t } = require('../../../db');
const { apiOk, apiError, requireAdminOrEditor, uuidv4 } = require('../../../../shared/helpers');
const { TABLES } = require('../../../../shared/constants');
const { logger: rootLogger } = require('../../../../shared/lib/logger');
const { mapRowsFromDb } = require('../../../lib/dto-mapper');
const { serializeRead, stripStraySecretLeaves } = require('./serializer');
const { loadFollowerColumnKeys, validateNoFollowerColumnTarget, parseResponseConfigForGuard } = require('./validate');
const { egressAllowedForUrl } = require('../../../../shared/lib/egress-policy');
// SECURITY: clone reads the source url server-side (it never passes through the
// CRUD write-boundary url guard), so sanitize any embedded credentials here too —
// otherwise a legacy userinfo url would be copied verbatim into every clone.
const { sanitizeUrlForExport } = require('../../../../shared/lib/portable-url-redaction');

const logger = rootLogger.child({ module: 'api-connectors:clone' });
const MAX_NAME = 255;

// mariadb returns a JSON column as a parsed object or a raw string depending on
// driver config; re-stringify an object, pass a string through unchanged. The
// encrypted auth_config leaf survives untouched either way (we never decrypt or
// re-mask here), so the secret is copied, not exposed.
function jsonCol(value) {
  if (value == null) return null;
  return typeof value === 'string' ? value : JSON.stringify(value);
}

// The clone always drops bundle membership (group_id/sequence NULL below), so
// any chain wiring (request_config.input_from_step) the source carried as a
// later step is now meaningless: it has no sequence to anchor it, would fail the
// validateInputFromStep guard the write paths enforce, and /usable would still
// project the stale step refs. Strip input_from_step so the clone is a clean
// standalone connector. An unparseable config is copied verbatim (no wiring to
// remove); a non-object config (array/scalar) is left as-is.
// The auth_config the clone stores: the SANCTIONED leaf copied verbatim (that is
// the point of a clone — the duplicate is usable without re-entering the
// credential), with any leaf the source's own type does not sanction removed.
//
// SECURITY: clone is the one secret-carrying path in this feature that did not
// strip stray leaves, and it is the path whose purpose is to copy the
// ciphertext — so a source row left carrying a previous type's secret was
// duplicated into a second row, and the leak followed the copy. Export and
// import both strip first; this is the third.
//
// An unparseable column is copied verbatim: there is no object to clean, and
// blanking it would lose a credential over a driver edge.
function cloneAuthConfig(value, authType) {
  if (value == null) return null;
  let parsed;
  try {
    parsed = typeof value === 'string' ? JSON.parse(value) : value;
  } catch {
    return jsonCol(value);
  }
  if (!parsed || typeof parsed !== 'object') return jsonCol(value);
  return JSON.stringify(stripStraySecretLeaves(parsed, authType));
}

function cloneRequestConfig(value) {
  if (value == null) return null;
  let cfg;
  try {
    cfg = typeof value === 'string' ? JSON.parse(value) : value;
  } catch {
    return jsonCol(value);
  }
  if (cfg && typeof cfg === 'object' && !Array.isArray(cfg) && 'input_from_step' in cfg) {
    const { input_from_step: _dropped, ...rest } = cfg;
    return JSON.stringify(rest);
  }
  return jsonCol(value);
}

module.exports = function registerClone(router) {
  router.post('/:id/clone', async (req, res) => {
    if (!requireAdminOrEditor(req, res)) return;
    const sourceId = req.params.id;
    const ownerId = req.user?.id || null;

    const rawName = req.body && typeof req.body.name === 'string' ? req.body.name.trim() : '';
    if (rawName.length > MAX_NAME) {
      const e = apiError(`name must be ≤ ${MAX_NAME} characters`, 'BAD_REQUEST', 400);
      return res.status(e.status).json(e.body);
    }

    let conn;
    try {
      conn = await pool.rw.getConnection();
      // Read the SOURCE row raw — auth_config keeps its encrypted ciphertext so
      // the clone copies it verbatim (no serializer mask round-trip).
      const rows = await conn.query(
        `SELECT name, description, is_active, owner_id, blueprint_id, section_key, method, url,
                auth_type, auth_config, request_config, response_config,
                dispatch_origin
         FROM \`${t(TABLES.API_CONNECTORS)}\` WHERE id = ?`,
        [sourceId],
      );
      if (!rows.length) {
        const e = apiError('Connector not found', 'NOT_FOUND', 404);
        return res.status(e.status).json(e.body);
      }
      const src = rows[0];

      // SECURITY: an editor clone is gated on TWO conditions; admin bypasses both.
      const isAdmin = req.user?.role === 'admin';
      if (!isAdmin) {
        // (1) Credential gate: cloning copies the source's working credential
        // into a row the caller will own and can re-point/dispatch, so the editor
        // must already OWN the source — owning only its blueprint is not enough,
        // or they could mint a usable copy of a credential they never created
        // (raised by both reviewers). A NULL-owned (degraded) source is admin-only.
        if (src.owner_id == null || src.owner_id !== ownerId) {
          const e = apiError('An editor can only clone a connector they own', 'FORBIDDEN', 403);
          return res.status(e.status).json(e.body);
        }
        // (2) Parent-ownership gate: the clone copies the source blueprint_id.
        // If that blueprint is no longer owned/shared by the editor (e.g. a shared
        // blueprint was later claimed by another user), the clone would land
        // active on a blueprint the editor cannot create under — bypassing the
        // create/import parentOwnership rule and surfacing in /usable. Mirror that
        // rule here: own or shared (NULL owner), else reject before inserting.
        let bpOwnOrShared = false;
        if (src.blueprint_id) {
          const own = await conn.query(
            `SELECT owner_id FROM \`${t(TABLES.HIERARCHY_NODES)}\` WHERE id = ?`,
            [src.blueprint_id],
          );
          const bpOwner = own.length ? own[0].owner_id : undefined;
          bpOwnOrShared = bpOwner === null || bpOwner === ownerId;
        }
        if (!bpOwnOrShared) {
          const e = apiError('An editor can only clone a connector bound to a blueprint they own or that is shared', 'FORBIDDEN', 403);
          return res.status(e.status).json(e.body);
        }
      }

      // SECURITY: save-time mirror of the dispatch-time egress allow-list gate.
      // The clone url is read server-side from the source row (never in req.body),
      // so the blanket CRUD save guard — which only fires when `url` is in the
      // request body — does not cover it. Re-check here so cloning a now-off-list
      // connector gets a fast 422 instead of a silent block only at dispatch.
      // Corrupt list THROWS → outer catch → 500 (fail-closed). Dispatch gate is
      // the backstop regardless of how the row was created.
      const egress = await egressAllowedForUrl(src.url, src.method || 'GET', (sql, params) => pool.ro.query(sql, params), t);
      if (!egress.ok) {
        const e = apiError('Connector request is not on the admin egress allow-list', 'EGRESS_BLOCKED', 422);
        return res.status(e.status).json(e.body);
      }

      // F4 (Q9/D2 amendment A4, held to the same rule the CRUD write-path
      // middleware in index.js enforces): the INSERT below copies
      // `src.response_config` VERBATIM. A source connector whose target
      // column later became a follower would otherwise let a clone re-create
      // exactly the state that middleware forbids on every OTHER write path.
      // Reads the guard against the CLONE's own blueprint_id (same value the
      // INSERT stores) on this same connection; a probe error falls through
      // to the outer catch, the same fail-closed 500 posture the CRUD
      // middleware's own try/catch documents.
      const followerColumnKeys = await loadFollowerColumnKeys(conn, t, src.blueprint_id);
      const followerMsg = validateNoFollowerColumnTarget(
        parseResponseConfigForGuard(src.response_config), followerColumnKeys,
      );
      if (followerMsg) {
        const e = apiError(followerMsg, 'BAD_REQUEST', 400);
        return res.status(e.status).json(e.body);
      }

      const newId = uuidv4();
      const cloneName = (rawName || `${src.name} (copy)`).slice(0, MAX_NAME);

      await conn.query(
        `INSERT INTO \`${t(TABLES.API_CONNECTORS)}\`
         (id, name, description, is_active, owner_id, blueprint_id, section_key,
          method, url, auth_type, auth_config, request_config, response_config,
          dispatch_origin,
          group_id, group_label, group_mode, \`sequence\`)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NULL, NULL, NULL, NULL)`,
        [
          newId,
          cloneName,
          src.description ?? null,
          src.is_active === 1 || src.is_active === true ? 1 : 0,
          ownerId,
          src.blueprint_id ?? null,
          src.section_key ?? null,
          src.method || 'GET',
          sanitizeUrlForExport(src.url),
          src.auth_type || 'none',
          cloneAuthConfig(src.auth_config, src.auth_type || 'none'),
          cloneRequestConfig(src.request_config),
          jsonCol(src.response_config),
          src.dispatch_origin || 'infra',
        ],
      );

      // SECURITY: a clone is a create path, so it must obey the approval
      // lifecycle — a clone must not inherit the source's approved state and must
      // not land NULL (= grandfathered = dispatches immediately), or an editor
      // could clone-to-auto-approve. Stamped as a best-effort UPDATE so a
      // no-ALTER DB lacking the column degrades to NULL = approved rather than
      // failing the clone. admin → approved; editor → pending.
      try {
        if (req.user?.role === 'admin') {
          await conn.query(
            `UPDATE \`${t(TABLES.API_CONNECTORS)}\` SET status='approved', approved_by=?, approved_at=NOW() WHERE id = ?`,
            [ownerId, newId],
          );
        } else {
          await conn.query(
            `UPDATE \`${t(TABLES.API_CONNECTORS)}\` SET status='pending' WHERE id = ?`,
            [newId],
          );
        }
      } catch (stampErr) {
        if (!(stampErr?.code === 'ER_BAD_FIELD_ERROR' || stampErr?.errno === 1054)) throw stampErr;
      }

      // Best-effort timeout_ms carry: copy the source's per-connector timeout to
      // the clone (read straight from the source row so no column-enumerating
      // SELECT is added). Tolerant — a no-ALTER DB lacking the column swallows the
      // Unknown-column error and the clone keeps the default timeout.
      try {
        await conn.query(
          `UPDATE \`${t(TABLES.API_CONNECTORS)}\` dst
             JOIN \`${t(TABLES.API_CONNECTORS)}\` src ON src.id = ?
             SET dst.timeout_ms = src.timeout_ms
           WHERE dst.id = ?`,
          [sourceId, newId],
        );
      } catch (timeoutErr) {
        if (!(timeoutErr?.code === 'ER_BAD_FIELD_ERROR' || timeoutErr?.errno === 1054)) throw timeoutErr;
      }

      // SECURITY: audit records identity only (who cloned what into what) —
      // never any auth_config / secret content.
      //
      // Best-effort: the clone INSERT already committed (autocommit), so a failed
      // audit write must NOT 500 — that would make the UI retry and mint a
      // duplicate clone. Log the gap instead and still return the created row.
      try {
        await conn.query(
          `INSERT INTO \`${t(TABLES.FEATURE_AUDIT)}\` (id, event_type, user_id, metadata)
           VALUES (?, 'api_connector.clone', ?, ?)`,
          [uuidv4(), ownerId, JSON.stringify({ source_id: sourceId, new_id: newId })],
        );
      } catch (auditErr) {
        logger.warn({ err: auditErr, sourceId, newId }, 'clone audit write failed (clone already committed)');
      }

      const created = await conn.query(
        `SELECT * FROM \`${t(TABLES.API_CONNECTORS)}\` WHERE id = ?`, [newId],
      );
      const shaped = serializeRead(mapRowsFromDb('api_connectors', created)[0]);
      res.status(201).json(apiOk(shaped));
    } catch (err) {
      logger.error({ err, sourceId }, 'Failed to clone connector id=' + sourceId);
      const e = apiError('Database operation failed', 'INTERNAL_ERROR', 500);
      res.status(e.status).json(e.body);
    } finally {
      if (conn) conn.release();
    }
  });
};
