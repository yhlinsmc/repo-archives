/**
 * connector-coherence.test.js — backend parity for the editor's save-time
 * shape guards. Mirrors the FE module
 * (src/fmb/components/admin/api-connectors/connector-save-guards.ts) so a
 * hand-edited import or a raw API write is held to the same coherence contract
 * the editor enforces, instead of degrading silently at runtime.
 *
 * Trigger for the table-coherence block is the presence of a valid table INPUT
 * cell (mirrors the FE requestMode==='table' on already-normalized stored data:
 * a scalar save drops its input_cells, so has-input-cell ⟺ saved-in-table-mode).
 * A scalar connector that writes a fixed cell output but has no table input must
 * NOT be flagged.
 */
import { describe, it, expect } from 'vitest';

const { validateConnectorCoherence } = require('../validate');

const req = (cells) => (cells === undefined ? {} : { input_cells: cells });
const res = (outputs) => (outputs === undefined ? {} : { outputs });

const perRowCell = (table_key, column_key, v) => ({ table_key, column_key, var: v });
const fixedCell = (table_key, column_key, v, row = 1) => ({ table_key, column_key, var: v, row });
const fieldOut = (id) => ({ id, from: { mode: 'value', path: 'data' }, to: { mode: 'field', field_key: 'f' } });
const cellOut = (id, table_key) => ({ id, from: { mode: 'value', path: 'data' }, to: { mode: 'cell', table_key, column_key: 'c', row: 1 } });
const rowsOut = (id, table_key, withMatch) => ({
  id,
  from: { mode: 'list', path: 'data' },
  to: {
    mode: 'rows', table_key, columns: [{ column_key: 'c', from: '@' }],
    ...(withMatch ? { match: { row_column: 'c', element_field: 'name' } } : {}),
  },
});

describe('validateConnectorCoherence', () => {
  // --- output-shape guards (apply regardless of input binding) ---
  it('rejects a fan-out connector mixing a rows output with a field output', () => {
    const err = validateConnectorCoherence(req(), res([rowsOut('o1', 't', false), fieldOut('o2')]));
    expect(err).toMatch(/can only have Table rows/i);
  });

  it('rejects more than one rows output', () => {
    const err = validateConnectorCoherence(req(), res([rowsOut('o1', 't', false), rowsOut('o2', 't', false)]));
    expect(err).toMatch(/only one Table rows/i);
  });

  it('rejects an OR (match:any) list filter', () => {
    const out = {
      id: 'o1',
      from: { mode: 'list', path: 'data', where: { match: 'any', conditions: [{ field: 'x', op: 'eq', value: { kind: 'literal', value: '1' } }] } },
      to: { mode: 'field', field_key: 'f' },
    };
    const err = validateConnectorCoherence(req(), res([out]));
    expect(err).toMatch(/match must be "all"/i);
  });

  it('rejects a cell-sourced filter value inside a multi-condition filter', () => {
    const out = {
      id: 'o1',
      from: {
        mode: 'list', path: 'data',
        where: {
          match: 'all',
          conditions: [
            { field: 'x', op: 'eq', value: { kind: 'literal', value: '1' } },
            { field: 'y', op: 'eq', value: { kind: 'cell', cell: { table_key: 't', column_key: 'c', row: 1 } } },
          ],
        },
      },
      to: { mode: 'field', field_key: 'f' },
    };
    const err = validateConnectorCoherence(req(), res([out]));
    expect(err).toMatch(/single-condition/i);
  });

  // --- input/output coupling guards ---
  it('rejects a per-row table cell paired with a create-rows (unmatched) fan-out output', () => {
    const err = validateConnectorCoherence(req([perRowCell('t', 'c', 'q')]), res([rowsOut('o1', 't', false)]));
    expect(err).toMatch(/must use scalar inputs/i);
  });

  it('rejects more than one referenced table field (input cell + cell output)', () => {
    const err = validateConnectorCoherence(req([perRowCell('t1', 'c', 'q')]), res([cellOut('o1', 't2')]));
    expect(err).toMatch(/one table field/i);
  });

  it('rejects more than one table input cell', () => {
    const err = validateConnectorCoherence(req([perRowCell('t', 'c1', 'q1'), perRowCell('t', 'c2', 'q2')]), res([cellOut('o1', 't')]));
    expect(err).toMatch(/only one table input column/i);
  });

  // --- false-positive safety: valid configs must pass ---
  it('passes a scalar connector that writes a fixed cell output but has no table input cell', () => {
    const err = validateConnectorCoherence(req(), res([cellOut('o1', 't')]));
    expect(err).toBeNull();
  });

  it('passes a valid fixed-cell join (rows output WITH match)', () => {
    const err = validateConnectorCoherence(req([fixedCell('t', 'c', 'q')]), res([rowsOut('o1', 't', true)]));
    expect(err).toBeNull();
  });

  it('passes a per-row cell paired with a matched (JOIN) rows output', () => {
    const err = validateConnectorCoherence(req([perRowCell('t', 'c', 'q')]), res([rowsOut('o1', 't', true)]));
    expect(err).toBeNull();
  });

  it('passes a valid per-row table connector (one input cell + cell output to the same table)', () => {
    const err = validateConnectorCoherence(req([perRowCell('t', 'c', 'q')]), res([cellOut('o1', 't')]));
    expect(err).toBeNull();
  });

  // --- cross-table rows (items 2/3): a rows sink may target a DIFFERENT table ---
  it('passes a per-row cell paired with a cross-table APPEND rows output (different target table)', () => {
    // The scalar-input fan-out guard is exempt cross-table: the per-row input is
    // exactly what drives the aggregation into the other table.
    const err = validateConnectorCoherence(req([perRowCell('t1', 'c', 'q')]), res([rowsOut('o1', 't2', false)]));
    expect(err).toBeNull();
  });

  it('passes a per-row cell paired with a cross-table MERGE rows output (different target table)', () => {
    const err = validateConnectorCoherence(req([perRowCell('t1', 'c', 'q')]), res([rowsOut('o1', 't2', true)]));
    expect(err).toBeNull();
  });

  it('still rejects a SAME-table create-rows (append) fan-out bound to a per-row cell', () => {
    const err = validateConnectorCoherence(req([perRowCell('t1', 'c', 'q')]), res([rowsOut('o1', 't1', false)]));
    expect(err).toMatch(/must use scalar inputs/i);
  });

  it('rejects a rows output with a blank target table (raw-import shape the editor never produces)', () => {
    const err = validateConnectorCoherence(req([perRowCell('t1', 'c', 'q')]), res([rowsOut('o1', '', false)]));
    expect(err).toMatch(/must target a table field/i);
  });

  it('passes null / empty / partial configs', () => {
    expect(validateConnectorCoherence(null, null)).toBeNull();
    expect(validateConnectorCoherence({}, {})).toBeNull();
    expect(validateConnectorCoherence(req([]), res([]))).toBeNull();
    expect(validateConnectorCoherence(req([perRowCell('t', 'c', 'q')]), null)).toBeNull();
  });

  // --- manual per-row cells (table_key + var, no column_key) ---
  it('a manual per-row cell is valid (table_key + var, no column_key)', () => {
    const err = validateConnectorCoherence(
      { input_cells: [{ table_key: 't1', var: 'token', source: 'manual' }] },
      {},
    );
    expect(err).toBeNull();
  });

  it('a manual cell and a column cell on the same table stay single-table valid', () => {
    const err = validateConnectorCoherence(
      { input_cells: [
        { table_key: 't1', column_key: 'host', var: 'host' },
        { table_key: 't1', var: 'token', source: 'manual' },
      ] },
      {},
    );
    expect(err).toBeNull();
  });

  it('a manual cell on a different table trips single-table rule', () => {
    const err = validateConnectorCoherence(
      { input_cells: [
        { table_key: 't1', column_key: 'host', var: 'host' },
        { table_key: 't2', var: 'token', source: 'manual' },
      ] },
      {},
    );
    expect(err).toMatch(/All table cells must reference one table field/);
  });
});
