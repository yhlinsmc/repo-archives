/**
 * flow-recipes/serializer.js — field-level read normalization for flow_recipes.
 *
 * serializeRead strips approved_by and approved_at from the row before the API
 * response is sent; only status and review_note (if any) are visible to clients.
 * No secret handling — flow_recipes carries no auth_config.
 */

/**
 * Drop internal approval bookkeeping so the API response never carries who
 * approved a recipe, or when. Only status and review_note are surfaced.
 * Returns a new row object; leaves non-object input unchanged.
 */
function serializeRead(row) {
  if (!row || typeof row !== 'object') return row;
  // SECURITY: approved_by (the approving admin's user id) and approved_at are
  // internal bookkeeping the client never renders — strip them from every read
  // so an editor cannot learn which admin approved a recipe or when.
  const rest = { ...row };
  delete rest.approved_by;
  delete rest.approved_at;
  return rest;
}

module.exports = { serializeRead };
