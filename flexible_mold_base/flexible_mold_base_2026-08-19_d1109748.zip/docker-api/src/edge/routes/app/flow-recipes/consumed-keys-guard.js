/**
 * consumed-keys-guard.js — reserved-key guard for flow_recipes.consumed_output_keys.
 *
 * Data-vocabulary unification (v2): the dispatch fill bag renames every client
 * input key `k` → `payload.<k>`, and `{{payload}}` is the whole stage-② message
 * token. A consumed output key equal to `payload` or starting with `payload.`
 * would therefore either collide with the whole-message token or double-prefix to
 * `payload.payload.<k>` at dispatch — never resolvable. Reject such keys at write
 * time (create / update / import). Read paths and already-stored rows are
 * untouched; this is a forward-only write guard.
 */
'use strict';

const RESERVED_KEY = 'payload';
const RESERVED_PREFIX = 'payload.';

// Returns the first reserved key found, or null when none. Non-array / non-string
// entries are ignored here — the write path validates shape separately.
function findReservedConsumedKey(keys) {
  if (!Array.isArray(keys)) return null;
  for (const k of keys) {
    if (typeof k !== 'string') continue;
    if (k === RESERVED_KEY || k.startsWith(RESERVED_PREFIX)) return k;
  }
  return null;
}

module.exports = { findReservedConsumedKey, RESERVED_KEY, RESERVED_PREFIX };
