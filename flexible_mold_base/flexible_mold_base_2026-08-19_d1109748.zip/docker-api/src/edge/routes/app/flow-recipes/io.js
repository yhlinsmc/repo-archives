/**
 * io.js — cross-environment export / import for flow_recipes (+ their steps).
 *
 *   GET  /:id/export   export a recipe and all its steps as portable JSON,
 *                      WITHOUT secrets
 *   POST /import       import a recipe + steps from such a payload
 *
 * Mirrors api-connectors/io.js. Secrets never travel: export strips the
 * sensitive step auth_config leaves so the operator re-enters them on the
 * target. The bundle is self-contained — recipe meta + the inline
 * payload_transform_code + every step — so there is no separate transformer
 * entity to also export and UUID-remap. Import binds to a local blueprint only
 * when the payload's blueprint lineage path resolves here; an admin may store
 * an "unbound" recipe (blueprint_id NULL) to re-bind later, but an editor is
 * rejected (403) when no own/shared blueprint resolves — an unbound recipe is
 * unmanageable through the editor CRUD ownership chain.
 *
 * Code-version history (flow_recipe_code_versions) is environment-local audit.
 * The export is version-ignorant: it carries ONLY the current code, never the
 * history chain and never a version id. The import starts a FRESH version chain
 * — the created recipe keeps code_version=1 (the DDL default) and gets a single
 * v1 history row (action 'import'); it never carries the source environment's
 * history and never depends on a version id or a run→version snapshot. The
 * history append is best-effort (mirrors the payload_transform_code write): a
 * no-ALTER DB lacking the table/columns imports without it.
 *
 * No-ALTER tolerance: the export SELECT and the import INSERT name only the
 * columns guaranteed present once the flow feature exists; the additive
 * columns (recipe payload_transform_code + runs_on; step step_type/before_code/
 * after_code) are read via selectFirstOk tier fallback and written via per-group
 * best-effort UPDATEs that tolerate ER_BAD_FIELD_ERROR — the same degrade-don't-fail
 * split flow-recipes-run.js uses.
 */
const { pool, t } = require('../../../db');
const { apiOk, apiError, requireAdminOrEditor, uuidv4 } = require('../../../../shared/helpers');
const { TABLES } = require('../../../../shared/constants');
const { logger: rootLogger } = require('../../../../shared/lib/logger');
const { buildHierarchyPath, findBlueprintIdsByPath } = require('../../../lib/hierarchy-path');
const { mapRowsFromDb } = require('../../../lib/dto-mapper');
const { serializeRead } = require('./serializer');
const { stripAuthConfigSecrets, stripStraySecretLeaves } = require('../flow-recipe-steps/serializer');
const { declaredAuthTypeOr } = require('../../../lib/auth-config-secrets');
const { egressAllowedForUrl } = require('../../../../shared/lib/egress-policy');
const {
  isStorableHttpUrl, sanitizeUrlForExport, redactRequestConfigHeaders,
  resolveMaskedRequestConfigHeaders,
} = require('../../../../shared/lib/portable-url-redaction');
const { findReservedConsumedKey, RESERVED_KEY } = require('./consumed-keys-guard');

const logger = rootLogger.child({ module: 'flow-recipes:io' });

const EXPORT_VERSION = 1;
const MAX_NAME = 255;
// A recipe is a handful of steps; cap import so a hand-edited bundle cannot drive
// one egress probe (a system_settings SELECT) per step into the thousands.
const MAX_STEPS = 100;
// Mirrors the flow-recipe-steps write-boundary cap (real authored code is a few
// hundred bytes); 32 KB also matches payload_transform_code's ceiling.
const MAX_CODE_BYTES = 32 * 1024;
// A compute step performs no dispatch; the schema stores a non-routable sentinel
// url that is never sent. It must skip the egress allow-list check (the sentinel
// host would otherwise falsely fail an enforced list) — same sentinel the editor
// stores (StepEditorWorkbench.COMPUTE_URL).
const COMPUTE_URL = 'https://compute.invalid/';

const CONTENT_TYPES = new Set(['application/json', 'application/yaml']);
const RUNS_ON = new Set(['create', 'update', 'both']);
const STEP_TYPES = new Set(['api', 'compute']);
const STEP_METHODS = new Set(['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'HEAD', 'OPTIONS']);

function isBadField(err) {
  return err && (err.errno === 1054 || err.code === 'ER_BAD_FIELD_ERROR');
}

// Try each SQL tier in turn; on a no-ALTER DB missing an additive column (errno
// 1054) fall through to the next, narrower tier. Tiers MUST be ordered widest →
// narrowest (newest migration columns dropped first), so each stuck-at-migration-N
// DB lands on the first tier whose columns it actually has. Generalises the
// single-fallback pattern in flow-recipes-run.js to the two independent additive
// groups on flow_recipes (inline payload_transform_code, then chaining runs_on).
async function selectFirstOk(conn, params, ...tiers) {
  for (let i = 0; i < tiers.length; i += 1) {
    try {
      return await conn.query(tiers[i], params);
    } catch (err) {
      if (isBadField(err) && i < tiers.length - 1) continue;
      throw err;
    }
  }
  return [];
}

// Coerce an untrusted extract spec to the only two shapes the run path (specToPath)
// and the builder (extractPath) accept: a bare JSONPath string, or { path: string }.
// Anything else (array, object without a string path, number) → null, so a
// hand-edited bundle cannot persist a shape that throws when the builder edits it.
function normalizeExtractSpec(v) {
  if (typeof v === 'string') return v;
  if (v && typeof v === 'object' && !Array.isArray(v) && typeof v.path === 'string') return { path: v.path };
  return null;
}

function parseJsonColumn(value) {
  if (value == null) return null;
  if (typeof value === 'object') return value;
  if (typeof value === 'string') {
    try { return JSON.parse(value); } catch { return null; }
  }
  return null;
}


module.exports = function register(router) {
  // GET /:id/export — portable JSON (recipe + steps), secrets stripped.
  router.get('/:id/export', async (req, res) => {
    if (!requireAdminOrEditor(req, res)) return;
    let conn;
    try {
      conn = await pool.ro.getConnection();

      // Two independent additive groups, newest-first: runs_on (chaining) and
      // payload_transform_code (inline-transform). A no-ALTER DB stuck before either
      // migration lacks that column, so peel them in separate tiers — a DB created
      // before the inline-transform migration (which used payload_transformer_id) has
      // neither, and must still export (those fields default to null on import).
      // content_type / consumed_output_keys / link_extract / external_id_extract are
      // in the original create, so they stay in every tier.
      const RECIPE_BASE_COLS = 'name, description, is_active, blueprint_id, content_type, consumed_output_keys, link_extract, external_id_extract';
      const recipeRows = await selectFirstOk(
        conn,
        [req.params.id],
        `SELECT ${RECIPE_BASE_COLS}, payload_transform_code, runs_on FROM \`${t(TABLES.FLOW_RECIPES)}\` WHERE id = ?`,
        `SELECT ${RECIPE_BASE_COLS}, payload_transform_code FROM \`${t(TABLES.FLOW_RECIPES)}\` WHERE id = ?`,
        `SELECT ${RECIPE_BASE_COLS} FROM \`${t(TABLES.FLOW_RECIPES)}\` WHERE id = ?`,
      );
      if (!recipeRows.length) {
        const e = apiError('Recipe not found', 'NOT_FOUND', 404);
        return res.status(e.status).json(e.body);
      }
      const row = recipeRows[0];

      // Carry the blueprint's root→self lineage as a natural key. blueprint_id is
      // environment-local (fresh UUIDs on import), so import re-binds by this name
      // path; blueprint_id stays only as a legacy fallback.
      let blueprintPath = null;
      if (row.blueprint_id) {
        const nodes = await conn.query(
          `SELECT id, parent_id, name FROM \`${t(TABLES.HIERARCHY_NODES)}\``,
        );
        const p = buildHierarchyPath(nodes, row.blueprint_id);
        if (p.length) blueprintPath = p;
      }

      // step_type / before_code / after_code are additive; legacy fallback drops
      // them (import defaults step_type='api', no code). auth_config selected so
      // its secret leaf can be stripped; it is the only secret column.
      const stepRows = await selectFirstOk(
        conn,
        [req.params.id],
        `SELECT \`sequence\`, name, method, url, auth_type, auth_config,
                request_config, response_config, input_from_step,
                dispatch_origin, timeout_ms,
                step_type, before_code, after_code
         FROM \`${t(TABLES.FLOW_RECIPE_STEPS)}\` WHERE recipe_id = ? ORDER BY \`sequence\``,
        `SELECT \`sequence\`, name, method, url, auth_type, auth_config,
                request_config, response_config, input_from_step,
                dispatch_origin, timeout_ms
         FROM \`${t(TABLES.FLOW_RECIPE_STEPS)}\` WHERE recipe_id = ? ORDER BY \`sequence\``,
      );

      const steps = stepRows.map((s) => ({
        sequence: s.sequence,
        name: s.name,
        method: s.method,
        url: sanitizeUrlForExport(s.url),
        auth_type: s.auth_type,
        // SECURITY: drop every sensitive auth_config leaf so a portable recipe
        // step never carries a secret (plaintext OR ciphertext). stripStraySecretLeaves
        // first removes any leaf that does not belong to the current auth_type (e.g. a
        // stale `token` ciphertext left after the type changed to 'none'), then
        // stripAuthConfigSecrets removes the sanctioned leaf — together they guarantee
        // no secret survives even for a row that predates the write-path strip.
        auth_config: stripAuthConfigSecrets(
          stripStraySecretLeaves(parseJsonColumn(s.auth_config) || {}, s.auth_type),
          s.auth_type,
        ),
        // SECURITY: blank credential-valued headers (Authorization / api-key) typed
        // literally into request_config.headers — export must carry no secret.
        request_config: redactRequestConfigHeaders(parseJsonColumn(s.request_config)),
        response_config: parseJsonColumn(s.response_config),
        input_from_step: parseJsonColumn(s.input_from_step),
        dispatch_origin: s.dispatch_origin,
        timeout_ms: s.timeout_ms ?? null,
        step_type: s.step_type ?? 'api',
        before_code: s.before_code ?? null,
        after_code: s.after_code ?? null,
      }));

      const exported = {
        export_version: EXPORT_VERSION,
        recipe: {
          name: row.name,
          description: row.description,
          is_active: row.is_active === 1 || row.is_active === true,
          blueprint_id: row.blueprint_id,
          blueprint_path: blueprintPath,
          content_type: row.content_type,
          runs_on: row.runs_on ?? null,
          payload_transform_code: row.payload_transform_code ?? null,
          consumed_output_keys: parseJsonColumn(row.consumed_output_keys),
          link_extract: parseJsonColumn(row.link_extract),
          external_id_extract: parseJsonColumn(row.external_id_extract),
        },
        steps,
        exported_at: new Date().toISOString(),
      };
      res.json(apiOk(exported));
    } catch (err) {
      logger.error({ err, recipeId: req.params.id }, 'Failed to export recipe id=' + req.params.id);
      const e = apiError('Database operation failed', 'INTERNAL_ERROR', 500);
      res.status(e.status).json(e.body);
    } finally {
      if (conn) conn.release();
    }
  });

  // POST /import — create a recipe (+ steps) from a portable payload.
  router.post('/import', async (req, res) => {
    if (!requireAdminOrEditor(req, res)) return;
    const { recipe, steps: rawSteps } = req.body || {};
    if (!recipe || typeof recipe !== 'object' || !recipe.name) {
      const e = apiError('Invalid import data: recipe with a name is required', 'BAD_REQUEST', 400);
      return res.status(e.status).json(e.body);
    }
    if (typeof recipe.name !== 'string' || recipe.name.length > MAX_NAME) {
      const e = apiError(`recipe.name must be a string ≤ ${MAX_NAME} characters`, 'BAD_REQUEST', 400);
      return res.status(e.status).json(e.body);
    }
    // Reserved-key guard: an imported consumed_output_keys entry equal to
    // "payload" or starting "payload." would collide/double-prefix under the
    // dispatch rename — reject the whole import rather than store an unusable key.
    const reservedConsumedKey = findReservedConsumedKey(recipe.consumed_output_keys);
    if (reservedConsumedKey) {
      const e = apiError(
        `consumed_output_keys entry "${reservedConsumedKey}" is reserved: keys equal to "${RESERVED_KEY}" or starting with "${RESERVED_KEY}." collide with the dispatch data vocabulary`,
        'RESERVED_OUTPUT_KEY',
        400,
      );
      return res.status(e.status).json(e.body);
    }
    const stepsIn = Array.isArray(rawSteps) ? rawSteps : [];
    if (stepsIn.length > MAX_STEPS) {
      const e = apiError(`A recipe import cannot exceed ${MAX_STEPS} steps`, 'BAD_REQUEST', 400);
      return res.status(e.status).json(e.body);
    }
    if (typeof recipe.payload_transform_code === 'string'
        && Buffer.byteLength(recipe.payload_transform_code, 'utf8') > MAX_CODE_BYTES) {
      const e = apiError(`payload_transform_code exceeds ${MAX_CODE_BYTES} bytes`, 'PAYLOAD_TOO_LARGE', 413);
      return res.status(e.status).json(e.body);
    }

    // ── Normalize + validate each step to the same bar a CRUD step write meets.
    // Enum-ish fields degrade to their default (a hand-edited bundle should not
    // fail wholesale); url is a hard security pin (cannot degrade). The effective
    // step_type drives whether the egress check applies.
    const cleanSteps = [];
    for (let i = 0; i < stepsIn.length; i += 1) {
      const s = stepsIn[i] || {};
      const stepType = STEP_TYPES.has(s.step_type) ? s.step_type : 'api';
      let url = typeof s.url === 'string' ? s.url : '';
      if (stepType === 'compute') {
        // A compute step is never dispatched; pin the non-routable sentinel so the
        // NOT-NULL url column is satisfied regardless of the payload.
        url = COMPUTE_URL;
      } else if (!isStorableHttpUrl(url)) {
        const e = apiError(`Step ${i + 1} "${typeof s.name === 'string' ? s.name : ''}": url must be an absolute http(s) URL`, 'BAD_REQUEST', 400);
        return res.status(e.status).json(e.body);
      }
      const method = STEP_METHODS.has(String(s.method).toUpperCase())
        ? String(s.method).toUpperCase() : 'POST';
      // The member list is the step COLUMN's, asked of the DDL — the literal set
      // this replaced was a copy of it. Degrade-to-'none' is kept: a hand-edited
      // bundle imports rather than fails, and an import stores no secret leaf.
      const authType = declaredAuthTypeOr(TABLES.FLOW_RECIPE_STEPS, s.auth_type);
      for (const field of ['before_code', 'after_code']) {
        const v = s[field];
        if (v == null || v === '') continue;
        if (typeof v !== 'string') {
          const e = apiError(`Step ${i + 1}: ${field} must be a string`, 'BAD_REQUEST', 400);
          return res.status(e.status).json(e.body);
        }
        if (Buffer.byteLength(v, 'utf8') > MAX_CODE_BYTES) {
          const e = apiError(`Step ${i + 1}: ${field} exceeds ${MAX_CODE_BYTES} bytes`, 'PAYLOAD_TOO_LARGE', 413);
          return res.status(e.status).json(e.body);
        }
      }
      cleanSteps.push({
        sequence: Number.isInteger(s.sequence) ? s.sequence : i,
        name: typeof s.name === 'string' && s.name.length ? s.name.slice(0, MAX_NAME) : `Step ${i + 1}`,
        method,
        url,
        auth_type: authType,
        // The payload carries no secrets (export stripped them); a hand-edited
        // bundle could still inject a stray leaf, so strip stray-type leaves AND the
        // sanctioned leaf before storing — no secret is ever persisted from import.
        auth_config: stripAuthConfigSecrets(
          stripStraySecretLeaves(parseJsonColumn(s.auth_config) || {}, authType),
          authType,
        ),
        request_config: parseJsonColumn(s.request_config),
        response_config: parseJsonColumn(s.response_config),
        input_from_step: parseJsonColumn(s.input_from_step),
        // Task 8 back-compat: a legacy export step carrying `allowed_hosts` is
        // ignored silently (dropped on read) — the column is gone.
        dispatch_origin: ['infra', 'edge'].includes(s.dispatch_origin) ? s.dispatch_origin : 'infra',
        timeout_ms: Number.isInteger(s.timeout_ms) && s.timeout_ms >= 1000 && s.timeout_ms <= 120000 ? s.timeout_ms : null,
        step_type: stepType,
        before_code: typeof s.before_code === 'string' && s.before_code !== '' ? s.before_code : null,
        after_code: typeof s.after_code === 'string' && s.after_code !== '' ? s.after_code : null,
      });
    }

    // ── Save-time egress allow-list gate, mirroring the dispatch-time check.
    // An off-list api step fails the WHOLE import (a half-imported recipe is
    // broken); compute steps are skipped (sentinel url, never dispatched).
    // Empty/absent list = allow-all; a corrupt list THROWS → 500 fail-closed.
    try {
      for (let i = 0; i < cleanSteps.length; i += 1) {
        const s = cleanSteps[i];
        if (s.step_type === 'compute') continue;
        const egress = await egressAllowedForUrl(s.url, s.method, (sql, params) => pool.ro.query(sql, params), t);
        if (!egress.ok) {
          const e = apiError(`Step ${i + 1} "${s.name}" targets a URL that is not on the admin egress allow-list; nothing was imported`, 'EGRESS_BLOCKED', 422);
          return res.status(e.status).json(e.body);
        }
      }
    } catch (err) {
      logger.error({ err, name: recipe.name }, 'recipe import egress allow-list check failed');
      const e = apiError('Database operation failed', 'INTERNAL_ERROR', 500);
      return res.status(e.status).json(e.body);
    }

    const recipeId = uuidv4();
    const ownerId = req.user?.id || null;
    let conn;
    try {
      conn = await pool.rw.getConnection();

      // Re-bind by the blueprint's lineage (name path), which survives the
      // fresh-UUID import that breaks a raw id match across environments. A unique
      // path match binds; 0 or >1 matches stay unbound. A payload without a path
      // (legacy export) falls back to the old id-existence check. Validate the
      // payload-supplied path: non-empty array of strings, depth capped well above
      // the 4-tier hierarchy so a crafted huge array can't drive an O(nodes × len) scan.
      const blueprintPath = Array.isArray(recipe.blueprint_path)
        && recipe.blueprint_path.length > 0
        && recipe.blueprint_path.length <= 32
        && recipe.blueprint_path.every((s) => typeof s === 'string')
        ? recipe.blueprint_path : null;
      const wantedBinding = !!blueprintPath || !!recipe.blueprint_id;
      let blueprintId = null;
      if (blueprintPath) {
        const nodes = await conn.query(
          `SELECT id, parent_id, name, node_type FROM \`${t(TABLES.HIERARCHY_NODES)}\``,
        );
        const matches = findBlueprintIdsByPath(nodes, blueprintPath);
        if (matches.length === 1) blueprintId = matches[0];
      } else if (recipe.blueprint_id) {
        const bp = await conn.query(
          `SELECT 1 FROM \`${t(TABLES.HIERARCHY_NODES)}\` WHERE id = ? LIMIT 1`,
          [recipe.blueprint_id],
        );
        if (bp.length) blueprintId = recipe.blueprint_id;
      }

      // An editor must never create a recipe they cannot later manage. CRUD create
      // rejects an editor's null/foreign blueprint (parentOwnership), and an unbound
      // recipe fails the editor PUT/DELETE ownership-chain — so an unbound import
      // would be an orphan only an admin could fix. Reject for editors; admins may
      // keep an unbound recipe.
      if (req.user?.role !== 'admin') {
        let ownOrShared = false;
        if (blueprintId) {
          const own = await conn.query(
            `SELECT owner_id FROM \`${t(TABLES.HIERARCHY_NODES)}\` WHERE id = ?`,
            [blueprintId],
          );
          const bpOwner = own.length ? own[0].owner_id : undefined;
          ownOrShared = bpOwner === null || bpOwner === (req.user?.id || null);
        }
        if (!ownOrShared) {
          const e = apiError('An editor can only import a recipe bound to a blueprint they own or that is shared', 'FORBIDDEN', 403);
          return res.status(e.status).json(e.body);
        }
      }

      // Degrade malformed recipe metadata to defaults rather than 400 the import.
      const contentType = CONTENT_TYPES.has(recipe.content_type) ? recipe.content_type : 'application/json';
      const runsOn = RUNS_ON.has(recipe.runs_on) ? recipe.runs_on : 'both';
      // Bundle values are already parsed JS (the request body was JSON-decoded), so
      // they are used as-is — NOT re-run through parseJsonColumn, which would JSON.parse
      // a legitimate bare-string extract spec ("$.data.id") and silently null it.
      const consumedKeys = Array.isArray(recipe.consumed_output_keys) ? recipe.consumed_output_keys : null;
      // link/external_id extract may legitimately be a bare string OR a {path} object
      // (run-path specToPath + builder extractPath accept exactly those two); coerce
      // anything else to null so a hand-edited array/garbage cannot break the editor.
      const linkExtract = normalizeExtractSpec(recipe.link_extract);
      const externalIdExtract = normalizeExtractSpec(recipe.external_id_extract);
      const payloadCode = typeof recipe.payload_transform_code === 'string' && recipe.payload_transform_code !== ''
        ? recipe.payload_transform_code : null;

      await conn.beginTransaction();

      // Core recipe INSERT names only columns present in the ORIGINAL flow_recipes
      // create; payload_transform_code (inline migration) and runs_on (chaining
      // migration) are each stamped via a separate best-effort UPDATE so a no-ALTER
      // DB stuck before either migration still imports (those fields degrade to null
      // / the DDL default).
      await conn.query(
        `INSERT INTO \`${t(TABLES.FLOW_RECIPES)}\`
         (id, name, description, is_active, owner_id, blueprint_id,
          content_type, consumed_output_keys, link_extract, external_id_extract)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          recipeId,
          recipe.name,
          recipe.description || null,
          recipe.is_active === false ? 0 : 1,
          ownerId,
          blueprintId,
          contentType,
          consumedKeys != null ? JSON.stringify(consumedKeys) : null,
          linkExtract != null ? JSON.stringify(linkExtract) : null,
          externalIdExtract != null ? JSON.stringify(externalIdExtract) : null,
        ],
      );

      // payload_transform_code best-effort (inline-transform additive): a no-ALTER DB
      // created before that migration lacks the column → degrade to null (recipe not
      // runnable until authored) rather than failing the whole import.
      // COHERENCE: track whether the code actually landed. A null code needs no
      // UPDATE (the row's DDL default is null, which the history seed will record as
      // null); a non-null code only counts as stored if its UPDATE did not 1054.
      let codeStored = payloadCode == null;
      if (payloadCode != null) {
        try {
          await conn.query(
            `UPDATE \`${t(TABLES.FLOW_RECIPES)}\` SET payload_transform_code = ? WHERE id = ?`,
            [payloadCode, recipeId],
          );
          codeStored = true;
        } catch (pcErr) {
          if (!isBadField(pcErr)) throw pcErr;
          // Column absent → the code was NOT stored; leave codeStored false so no
          // history row claims a code the recipe row does not hold.
        }
      }

      // runs_on best-effort (chaining additive): a no-ALTER DB lacking it degrades to
      // the DDL default 'both' (guard inert) rather than failing the import.
      if (runsOn !== 'both') {
        try {
          await conn.query(
            `UPDATE \`${t(TABLES.FLOW_RECIPES)}\` SET runs_on = ? WHERE id = ?`,
            [runsOn, recipeId],
          );
        } catch (roErr) {
          if (!isBadField(roErr)) throw roErr;
        }
      }

      // SECURITY: an import is a create path, so it must obey the approval
      // lifecycle — without this an editor could import a recipe that lands with
      // NULL status (= grandfathered = runnable), bypassing review. Best-effort so
      // a no-ALTER DB lacking the column degrades to NULL=approved. admin →
      // approved; editor → pending. The run gate is the backstop regardless.
      try {
        if (req.user?.role === 'admin') {
          await conn.query(
            `UPDATE \`${t(TABLES.FLOW_RECIPES)}\` SET status='approved', approved_by=?, approved_at=NOW() WHERE id = ?`,
            [ownerId, recipeId],
          );
        } else {
          await conn.query(
            `UPDATE \`${t(TABLES.FLOW_RECIPES)}\` SET status='pending' WHERE id = ?`,
            [recipeId],
          );
        }
      } catch (stampErr) {
        if (!isBadField(stampErr)) throw stampErr;
      }

      // Start a FRESH code-version chain for the imported recipe: seed a single
      // v1 history row (action 'import') recording the imported code. The recipe
      // row keeps code_version=1 (DDL default). COHERENCE: seed only when the FULL
      // versioning surface is live — the code was actually stored (codeStored) AND
      // the counter column exists on flow_recipes. On a partial-migration target
      // (code stored but counter column absent) later CRUD PUTs degrade unversioned,
      // so a v1 row here would be a stale chain start. Best-effort on the history
      // table itself: a target missing it (1146) imports without version history.
      let counterColumnPresent = false;
      try {
        const cvCol = await conn.query(
          `SELECT 1 FROM information_schema.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?`,
          [t(TABLES.FLOW_RECIPES), 'code_version'],
        );
        counterColumnPresent = Array.isArray(cvCol) && cvCol.length > 0;
      } catch { counterColumnPresent = false; }
      if (codeStored && counterColumnPresent) {
        try {
          await conn.query(
            `INSERT INTO \`${t(TABLES.FLOW_RECIPE_CODE_VERSIONS)}\`
             (id, recipe_id, version, code, action, created_by)
             VALUES (?, ?, 1, ?, 'import', ?)`,
            [uuidv4(), recipeId, payloadCode, ownerId],
          );
        } catch (cvErr) {
          if (!isBadField(cvErr) && cvErr.errno !== 1146 && cvErr.code !== 'ER_NO_SUCH_TABLE') throw cvErr;
        }
      }

      // Steps: new id + new recipe_id, sequence preserved (so input_from_step
      // sequence refs stay valid — no id remap needed). step_type/before_code/
      // after_code stamped via a per-step best-effort UPDATE (additive group).
      for (const s of cleanSteps) {
        const stepId = uuidv4();
        await conn.query(
          `INSERT INTO \`${t(TABLES.FLOW_RECIPE_STEPS)}\`
           (id, recipe_id, \`sequence\`, name, method, url, auth_type, auth_config,
            request_config, response_config, input_from_step,
            dispatch_origin, timeout_ms)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            stepId,
            recipeId,
            s.sequence,
            s.name,
            s.method,
            s.url,
            s.auth_type,
            JSON.stringify(s.auth_config || {}),
            // The mirror lane: a hand-built recipe bundle carries step headers
            // through the same import, so the sentinel is dropped here too
            // rather than becoming the credential the step dispatches with.
            s.request_config != null
              ? JSON.stringify(resolveMaskedRequestConfigHeaders(s.request_config, null))
              : null,
            s.response_config != null ? JSON.stringify(s.response_config) : null,
            s.input_from_step != null ? JSON.stringify(s.input_from_step) : null,
            s.dispatch_origin,
            s.timeout_ms,
          ],
        );
        if (s.step_type !== 'api' || s.before_code != null || s.after_code != null) {
          try {
            await conn.query(
              `UPDATE \`${t(TABLES.FLOW_RECIPE_STEPS)}\`
               SET step_type = ?, before_code = ?, after_code = ? WHERE id = ?`,
              [s.step_type, s.before_code, s.after_code, stepId],
            );
          } catch (codeErr) {
            // A no-ALTER DB lacking the chaining columns cannot store JS/compute
            // steps; the chain is then meaningless, so fail the import rather than
            // silently drop the code (an api-only legacy bundle never enters here).
            if (!isBadField(codeErr)) throw codeErr;
            throw Object.assign(
              new Error('CHAINING_UNSUPPORTED'),
              apiError('This recipe uses per-step code or compute steps, which the target database does not support', 'CHAINING_UNSUPPORTED', 422),
            );
          }
        }
      }

      // Read back the row BEFORE committing. If the read-back or response shaping
      // throws, the catch rolls back a still-open transaction — committing first
      // would leave the import permanent while returning 500, so a client retry
      // would create a duplicate. Read-back inside the txn sees its own writes.
      const rows = await conn.query(
        `SELECT * FROM \`${t(TABLES.FLOW_RECIPES)}\` WHERE id = ?`, [recipeId],
      );
      // Shape the row like the CRUD read path (mapRowsFromDb JSON-decodes the JSON
      // columns + coerces is_active → boolean) so the response honours the FlowRecipe
      // contract the frontend hook promises; then strip approval bookkeeping.
      const shaped = serializeRead(mapRowsFromDb('flow_recipes', rows)[0]);

      await conn.commit();

      res.status(201).json(apiOk({
        ...shaped,
        steps_imported: cleanSteps.length,
        unbound: blueprintId === null && wantedBinding,
      }));
    } catch (err) {
      if (conn) {
        try { await conn.rollback(); } catch (rbErr) {
          logger.warn({ err: rbErr }, 'rollback after recipe import failed');
        }
      }
      // A thrown apiError envelope (e.g. CHAINING_UNSUPPORTED) carries its own
      // status/body; relay it instead of masking as a generic 500.
      if (err && err.status && err.body) {
        return res.status(err.status).json(err.body);
      }
      logger.error({ err, name: recipe.name }, 'Failed to import recipe name=' + recipe.name);
      const e = apiError('Database operation failed', 'INTERNAL_ERROR', 500);
      res.status(e.status).json(e.body);
    } finally {
      if (conn) conn.release();
    }
  });
};
