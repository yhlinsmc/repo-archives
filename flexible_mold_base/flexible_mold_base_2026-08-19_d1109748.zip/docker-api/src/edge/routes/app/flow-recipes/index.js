/**
 * flow-recipes/index.js — router assembly for the Flow Recipes feature.
 *
 * Route registration order matters — all named sub-routes must be registered
 * BEFORE the generic CRUD catch-all so paths like /serialize, /approve, and
 * /reject are not swallowed by the /:id handler.
 *
 *   POST /serialize       — YAML conversion (admin/editor only, gated)
 *   PATCH /:id/approve    — admin approval (registered by approval.js)
 *   PATCH /:id/reject     — admin rejection (registered by approval.js)
 *   GET|POST|PUT|DELETE / — CRUD factory (owner-scoped, editor + admin)
 *
 * serializeRead strips approved_by/approved_at from every read response so
 * clients never learn who approved a recipe or when.
 */
const express = require('express');
// This file imports neither the pool nor the prefix helper any more: the "recipe
// still has steps" probe moved into the factory's own transaction, so the mount
// names its child table through TABLES and the factory resolves the prefix and
// picks the connection.
const { createCrudRoutes } = require('../schema');
const { enumColumnsFor } = require('../../../lib/schema-manifest');
const { requireAdminOrEditor, apiError } = require('../../../../shared/helpers');
const { TABLES } = require('../../../../shared/constants');
const { serializeRead } = require('./serializer');
const { findReservedConsumedKey, RESERVED_KEY } = require('./consumed-keys-guard');

const router = express.Router();

// Usable projection for data-entry users (requireAuth only, narrow projection)
// — mounted BEFORE the admin/editor gate so plain users can discover runnable
// recipes for a blueprint without seeing owner/status/config/secrets.
// Mirrors api-connectors/usable.js.
require('./usable')(router);

// Everything below is admin-or-editor only.
router.use((req, res, next) => {
  if (!requireAdminOrEditor(req, res)) return;
  next();
});

// THE "RECIPE STILL HAS STEPS" GATE IS NOT HERE ANY MORE.
//
// It is a `refuseDeleteWhenReferenced` declaration on the mount, so the probe
// runs inside the transaction the DELETE already opens, on the write connection
// and FOR UPDATE. Here it was an unlocked `SELECT 1 … LIMIT 1` on `pool.ro`
// taken before that transaction existed, so a step inserted in the window
// between the probe and the DELETE was orphaned — and an orphan step row
// carries an encrypted credential and is unreachable to editors thereafter,
// because the ownership chain needs the parent that no longer exists.

// /serialize must be registered before the CRUD /:id catch-all so the path
// resolves correctly. It is gated by the requireAdminOrEditor above.
require('./serialize-endpoint')(router);

// Approval lifecycle (PATCH /:id/approve, /:id/reject + status stamp on
// create/edit) — registered before the CRUD /:id so PATCH routes are not
// shadowed by the factory's generic /:id handler.
require('./approval')(router);
// The columns whose change re-pends this recipe are declared beside the
// approval lifecycle they belong to, and read here — one list, not two.
const { SENSITIVE_SCALAR, JSON_SENSITIVE } = require('./approval');

// Cross-environment export (no secrets) / import (+ steps, lineage re-bind),
// registered before the CRUD catch-all so /import and /:id/export match ahead
// of the generic /:id handler (same ordering rule as /serialize, /approve).
require('./io')(router);

// Reserved-key guard for consumed_output_keys on the generic CRUD create/update
// path. Registered AFTER the named sub-routes (io/approve/serialize) so it only
// gates POST / and PUT /:id; the import path validates its own nested payload in
// io.js. Absent key = no-op; a reserved key = 400 before the factory writes.
router.use((req, res, next) => {
  if (req.method !== 'POST' && req.method !== 'PUT') return next();
  const keys = req.body && req.body.consumed_output_keys;
  if (keys == null) return next();
  const bad = findReservedConsumedKey(keys);
  if (bad) {
    const e = apiError(
      `consumed_output_keys entry "${bad}" is reserved: keys equal to "${RESERVED_KEY}" or starting with "${RESERVED_KEY}." collide with the dispatch data vocabulary`,
      'RESERVED_OUTPUT_KEY',
      400,
    );
    return res.status(e.status).json(e.body);
  }
  next();
});

router.use('/', createCrudRoutes('flow_recipes', {
  // owner_id is stamped to the creator on POST.
  ownerColumn: 'owner_id',
  // Editors may author recipes; plain users cannot (gate above).
  allowedRoles: ['admin', 'editor'],
  // Editor create/edit must bind to a blueprint they own or that is shared
  // (NULL owner). Admin bypasses; a null blueprint_id from an editor is
  // rejected (recipes are blueprint-bound). Mirrors the connector mount.
  parentOwnership: {
    via: 'blueprint_id',
    chain: [{ table: TABLES.HIERARCHY_NODES, match: 'id', readOwner: 'owner_id' }],
  },
  filterableColumns: ['blueprint_id', 'is_active'],
  resolveOwnerName: 'owner_id',
  // THE DOMAIN IS THE TABLE'S, ASKED OF THE DDL — the same declaration the two
  // sibling mounts carry, and the same reason for asking the whole table rather
  // than listing columns here. This mount had none at all, while two of the three
  // scalars its re-pend watches (`content_type`, `runs_on`) are ENUMs: the
  // re-pend's own comment says the byte compare is sound because a domain gate
  // has already proved the written value is identically a member, and on this
  // mount nothing had. `PUT {"content_type":"application/JSON"}` reached the
  // statement with the caller's spelling; the engine folded it and the compare
  // called it a change.
  //
  // CLIENT-VISIBLE, and stated rather than described as a tidy-up: a case variant
  // that used to store correctly (the engine folds ENUM case on write) is now a
  // stable 400. The browser sends the member; scripts and integrations may not.
  enumColumns: enumColumnsFor(TABLES.FLOW_RECIPES),
  serializeRead,
  // Belt-and-braces: code_version is server-computed. The factory strips it from
  // every codeVersioning write, and this PUT-path immutable guard is a second
  // layer documenting the invariant at the mount.
  immutableColumns: ['code_version'],
  // Append an immutable history row + bump code_version whenever the inline
  // payload_transform_code changes on create/update, all in the write's own
  // transaction. Import (io.js) writes its own v1 'import' row; export stays
  // version-ignorant.
  // SECURITY: a recipe with steps cannot be deleted, and that is decided inside
  // the delete's own transaction — there is no FK cascade, so the rows this
  // protects would otherwise become orphans carrying encrypted credentials that
  // no editor can reach.
  refuseDeleteWhenReferenced: [{
    table: TABLES.FLOW_RECIPE_STEPS,
    fk: 'recipe_id',
    code: 'RECIPE_HAS_STEPS',
    message: 'This recipe still has steps; delete them first',
  }],
  codeVersioning: {
    watchColumn: 'payload_transform_code',
    versionColumn: 'code_version',
    historyTable: TABLES.FLOW_RECIPE_CODE_VERSIONS,
    historyFkColumn: 'recipe_id',
  },
  // SECURITY: the mirror of the connector mount's declaration. A change to what
  // this recipe sends, or to the shape it sends it in, clears its approval —
  // inside the same transaction and the same statement as the change. NULL is
  // among the states this fires from: a grandfathered recipe's steps DO
  // dispatch, so an unreviewed edit to one must stop that. Which states re-pend
  // is review-status.js's answer.
  repandOnSensitiveChange: {
    statusCol: 'status',
    clearCols: ['approved_by', 'approved_at'],
    columns: SENSITIVE_SCALAR,
    jsonColumns: JSON_SENSITIVE,
  },
}));

module.exports = router;
