'use strict';

/**
 * request-pool.js — which database this request is about.
 *
 * A request may carry `db` in its body, naming a Custom API connection instead
 * of the configured one. Every statement that decides something about a row —
 * and every statement that writes one — has to be aimed at the SAME database, or
 * the decision is taken about a different row than the one the write lands on.
 *
 * ONE DEFINITION, because the failure a second copy produces is silent. Three
 * copies of this resolver existed: the CRUD factory's per-mount closures, the
 * ownership routes' module-level one in `helpers.js`, and — the case that made
 * this a module — a guard added beside a mount that read the static `pool.rw`
 * directly. On a request carrying `db` that guard asked the DEFAULT database
 * about an id living in another: no row, so the branch it guards fell through
 * unvalidated; or a same-id row in the default database, so the decision was
 * taken about a different record entirely. Both answers are 200s.
 *
 * THE DESTRUCTURE BELOW BINDS AT MODULE LOAD, and that is safe for a reason this
 * file does not own. Under the cold-boot contract there is no database yet when
 * this module is first required, so a resolver that captured a live connection
 * pool here would hand out a dead one forever. It does not: `pool.rw` / `pool.ro`
 * are the stable facades declared at `db.js:110-125`, which re-read the
 * module-level `_rwPool` / `_roPool` bindings on every call, and `configurePool`
 * swaps those rather than replacing the facades — so an object bound once still
 * reaches whatever pool is configured now.
 *
 * What would break is capturing the UNDERLYING pool, and `db.js` deliberately
 * never hands one out. That, not the moment of this destructure, is the property
 * to preserve: if a future `db.js` ever returned a real pool object from `pool.rw`,
 * every module that imported it once — including this one — would be pinned to the
 * pool that existed at its first require.
 */
const { pool, getDynamicPool } = require('../../../db');

/** The write pool this request is about. */
async function resolveRwPool(req) {
  const db = req && req.body ? req.body.db : undefined;
  return db ? (await getDynamicPool(db)).rw : pool.rw;
}

/** The read pool this request is about. */
async function resolveRoPool(req) {
  const db = req && req.body ? req.body.db : undefined;
  return db ? (await getDynamicPool(db)).ro : pool.ro;
}

module.exports = { resolveRwPool, resolveRoPool };
