const {
  TABLES,
  VARIANT_OVERRIDE_ACTIONS,
  pool,
  t,
  getDynamicPool,
  apiOk,
  apiError,
  requireAuth,
  requireAdmin,
  requireAdminOrEditor,
  isOwnerOrAdmin,
  uuidv4,
  UUID_RE,
  mapRowFromDb,
  mapRowsFromDb,
  mapRowToDb,
  previewCascade,
  cascadeDeleteNode,
  collectDescendantIds,
  tableExistsInCurrentSchema,
  buildVariantOverrideUpdateExistsClause,
  buildVariantOverrideInsertExistsClause,
  buildDuplicateActionTripleNotExistsClause,
  applyOwnerChange,
  enrichOwnerNames,
  validateComputeRule,
  detectCycle,
  invalidChoiceConfigShape,
  resolveAncestors,
  restampTemplates,
  countAffectedTemplates,
  isValidBlueprintParent,
  logger,
  HIERARCHY_OWNER_AUDIT_EVENT,
  USER_TEMPLATE_OWNER_AUDIT_EVENT,
  resolveOwnershipRwPool,
  cascadeBlueprintOwnerToVariants,
  SAFE_COL_RE,
  isSafeColumnName,
  SLUG_KEY_PATTERN,
  isValidSlugKey,
  isBlueprintLinked,
  isBlueprintLinkedLocked,
  isLinkedParentLocked,
  auditSchemaClearFailed,
  validateLinkConstraints,
  resolveLinkCheckBlueprintId,
  _columnSetCache,
  getConnDatabaseName,
  getActualColumnSet,
  _historyTableCache,
  isCodeVersionHistoryAvailable,
  gateKeysByColumnSet,
  TABLE_VALUES,
  validateCodeVersioning,
  isMissingTableOrColumn,
  _codeVersioningDegraded,
  warnCodeVersioningDegradedOnce,
  validateAndPrepareParentOwnership,
  validateAndPrepareParentRepend,
  buildChainSelectSql,
  buildChainExistsForRow,
  ENCRYPTION_GATE_422,
  runSerializeWrite,
  editorMayWriteBlueprint,
  MAX_BATCH_FIELD_IDS,
  MAX_BATCH_BLUEPRINT_IDS,
} = require('./helpers');
const { metadataKeySitesPresentIn } = require('../../../lib/user-template-metadata');
// The shape rule and the clash probe live beside each other in one module
// because they are one rule about one column, and the endpoint that WRITES a
// key must apply exactly what the endpoint below applies to migrate it.
const { isValidFieldKey, fieldKeyTaken, FIELD_KEY_TAKEN } = require('./field-key');


// ---------------------------------------------------------------------------
// Schema Impact Detection + Field Rename Migration
// ---------------------------------------------------------------------------

/**
 * The answers document. Not part of the shared metadata declaration — it is the
 * values themselves rather than metadata about them — but it is a field-key-
 * indexed document on the same row, so the rename treats it as one more site and
 * builds its statement the same way. Always present (it predates every additive
 * column), so it needs no column probe.
 */
const PAYLOAD_KEY_SITE = Object.freeze({ column: 'payload', container: '$' });

/**
 * One statement per key site: copy the value from the old key to the new one and
 * drop the old, scoped to the blueprint.
 *
 * The `IS NOT NULL` on the extracted old key is load-bearing, not a filter for
 * speed: JSON_EXTRACT of an absent path returns NULL, and JSON_SET would then
 * write a null-valued NEW key into every row of the blueprint. It also makes a
 * column holding unparseable text a no-op instead of a wipe, because MariaDB
 * answers NULL there too.
 */
function buildKeyRenameUpdate(site, oldKey, newKey, blueprintId) {
  if (!isSafeColumnName(site.column)) {
    throw new Error(`[rename]: ${site.column} fails column whitelist`);
  }
  const path = (key) => `${site.container}."${key}"`;
  const col = `\`${site.column}\``;
  return {
    sql: `UPDATE \`${t(TABLES.USER_TEMPLATES)}\`
         SET ${col} = JSON_SET(
           JSON_REMOVE(${col}, ?),
           ?, JSON_EXTRACT(${col}, ?)
         )
         WHERE blueprint_id = ?
           AND ${col} IS NOT NULL
           AND JSON_EXTRACT(${col}, ?) IS NOT NULL`,
    params: [path(oldKey), path(newKey), path(oldKey), blueprintId, path(oldKey)],
  };
}

function register(router) {

/**
 * GET /impact/:fieldId — count templates affected by a field (delete warning).
 * Returns { template_count, template_names }.
 */
router.get('/impact/:fieldId', async (req, res) => {
  // NOTE: editors can reach Schema Builder and pre-check impact counts
  // before renaming. Admin-only would silently break the rename UX for
  // editors; allow read of the impact count for both roles.
  if (!requireAdminOrEditor(req, res)) return;
  try {
    // Two pure SELECTs — impact preview → pool.ro.
    const conn = await pool.ro.getConnection();
    try {
      // Look up the field to get blueprint_id + field_key
      const fields = await conn.query(
        `SELECT blueprint_id, field_key FROM \`${t(TABLES.BLUEPRINT_FIELDS)}\` WHERE id = ?`,
        [req.params.fieldId],
      );
      if (!fields.length) {
        const e = apiError('Field not found', 'NOT_FOUND', 404);
        return res.status(e.status).json(e.body);
      }
      const { blueprint_id, field_key } = fields[0];

      // Defensive: reject malformed field_key from DB to prevent JSON path issues
      if (!isValidFieldKey(field_key)) {
        const e = apiError('Field has invalid key format in database', 'INTERNAL_ERROR', 500);
        return res.status(e.status).json(e.body);
      }

      // Find templates whose payload contains this field key
      const templates = await conn.query(
        `SELECT id, name FROM \`${t(TABLES.USER_TEMPLATES)}\`
         WHERE blueprint_id = ?
           AND payload IS NOT NULL
           AND JSON_EXTRACT(payload, ?) IS NOT NULL`,
        [blueprint_id, `$."${field_key}"`],
      );

      res.json(apiOk({
        template_count: templates.length,
        template_names: templates.map(tpl => tpl.name || tpl.id),
      }));
    } finally {
      conn.release();
    }
  } catch (err) {
    logger.error({ err, fieldId: req.params.fieldId }, 'Failed to check field impact');
    const e = apiError('Database operation failed', 'INTERNAL_ERROR');
    res.status(e.status).json(e.body);
  }
});


/**
 * POST /rename/:fieldId — rename a field key across all template payloads.
 * Body: { old_key: string, new_key: string }
 *
 * Both keys are validated against the field key format regex before any SQL
 * execution to prevent JSON path injection.
 */
router.post('/rename/:fieldId', async (req, res) => {
  // NOTE: editors need this endpoint to migrate template payloads when
  // renaming a field, so the role gate admits them. Ownership of the blueprint
  // the field belongs to is checked separately, below, inside the write
  // transaction — it used to be left to the PUT this call accompanies, which
  // made it a property of how the client sequenced two requests.
  if (!requireAdminOrEditor(req, res)) return;
  const { old_key, new_key } = req.body || {};

  // Input validation
  if (!old_key || !new_key) {
    const e = apiError('old_key and new_key are required', 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }
  if (!isValidFieldKey(old_key)) {
    const e = apiError('old_key has invalid format', 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }
  if (!isValidFieldKey(new_key)) {
    const e = apiError('new_key has invalid format', 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }
  if (old_key === new_key) {
    const e = apiError('old_key and new_key must be different', 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }

  try {
    // SELECT guard + UPDATE of user_templates payloads on same conn → pool.rw.
    const conn = await pool.rw.getConnection();
    try {
      // Look up the field to get blueprint_id and verify it exists
      const fields = await conn.query(
        `SELECT blueprint_id, field_key FROM \`${t(TABLES.BLUEPRINT_FIELDS)}\` WHERE id = ?`,
        [req.params.fieldId],
      );
      if (!fields.length) {
        const e = apiError('Field not found', 'NOT_FOUND', 404);
        return res.status(e.status).json(e.body);
      }
      const { blueprint_id, field_key: dbFieldKey } = fields[0];

      // Security: verify old_key matches the actual DB field key to prevent
      // an admin from using an arbitrary fieldId as a blueprint-scope anchor
      // to rename unrelated keys across all templates.
      // byte-compare: the stored key is resolved by a JAVASCRIPT reader here and
      // in every statement below, which builds a JSON path out of the caller's
      // spelling — folding two spellings into one would migrate the answers of a
      // path no record holds.
      if (dbFieldKey !== old_key) {
        const e = apiError('old_key does not match the current field key', 'BAD_REQUEST', 400);
        return res.status(e.status).json(e.body);
      }

      // A column absent from this DB (a target that warn-skipped an additive
      // ALTER) is skipped rather than named in a statement that would 1054 the
      // whole rename — the same tolerance the CRUD write path and the
      // cross-environment sync already apply to these columns. A null probe
      // result means "could not tell", which keeps every site.
      const colSet = await getActualColumnSet(conn, t(TABLES.USER_TEMPLATES));
      const sites = [PAYLOAD_KEY_SITE, ...metadataKeySitesPresentIn(colSet)];

      // One transaction over all of them: a rename that moved the values but not
      // the metadata leaves the row describing choices about keys that no longer
      // exist, which is the state this endpoint is supposed to be repairing.
      const migrated = {};
      await conn.beginTransaction();
      try {
        // The role gate at the top of this handler is not an authorization check.
        // The endpoint takes a fieldId and rewrites every template under whatever
        // blueprint that field belongs to, so an editor can name a field under a
        // blueprint they do not own. The route's own comment called the ownership
        // check implicit in the PUT the rename is issued alongside — an assumption
        // about how a client sequences two calls, not an invariant of this one.
        // Same helper, same message and same in-transaction placement the sibling
        // structural endpoints use.
        if (!(await editorMayWriteBlueprint(conn, req, blueprint_id))) {
          await conn.rollback();
          const e = apiError('Not allowed: blueprint is not owned by you and is not shared', 'FORBIDDEN', 403);
          return res.status(e.status).json(e.body);
        }
        // A destination a SIBLING field already owns is not a rename, it is a
        // merge: the statements below copy this field's answer onto the
        // destination path in every record of the blueprint, and the value that
        // was there is stored nowhere else. Asked in the same transaction as the
        // statements, and asked the way the column compares.
        if (await fieldKeyTaken(conn, blueprint_id, new_key, req.params.fieldId)) {
          await conn.rollback();
          const e = apiError(FIELD_KEY_TAKEN.message, FIELD_KEY_TAKEN.code, FIELD_KEY_TAKEN.status);
          return res.status(e.status).json(e.body);
        }
        for (const site of sites) {
          const { sql, params } = buildKeyRenameUpdate(site, old_key, new_key, blueprint_id);
          const result = await conn.query(sql, params);
          migrated[site.column] = (migrated[site.column] || 0) + (result.affectedRows || 0);
        }
        await conn.commit();
      } catch (txErr) {
        // Best-effort, so a rollback that fails cannot replace the error that
        // actually explains the failure.
        try { await conn.rollback(); } catch { /* best effort */ }
        throw txErr;
      }

      logger.info(
        { fieldId: req.params.fieldId, old_key, new_key, migrated },
        'Renamed field key in template payloads',
      );

      res.json(apiOk({
        // Unchanged meaning: the number of records whose ANSWERS moved. The
        // metadata counts are logged rather than returned because a record can
        // carry a marker for a field it holds no value for, and reporting a
        // larger number here would read as more records edited.
        migrated_count: migrated.payload || 0,
      }));
    } finally {
      conn.release();
    }
  } catch (err) {
    logger.error({ err, fieldId: req.params.fieldId, old_key, new_key }, 'Failed to rename field key');
    const e = apiError('Database operation failed', 'INTERNAL_ERROR');
    res.status(e.status).json(e.body);
  }
});
}

module.exports = { register };
