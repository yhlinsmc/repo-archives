const {
  TABLES,
  VARIANT_OVERRIDE_ACTIONS,
  pool,
  t,
  getDynamicPool,
  apiOk,
  apiError,
  requireAuth,
  requireAdmin,
  requireAdminOrEditor,
  isOwnerOrAdmin,
  uuidv4,
  UUID_RE,
  mapRowFromDb,
  mapRowsFromDb,
  mapRowToDb,
  previewCascade,
  cascadeDeleteNode,
  collectDescendantIds,
  tableExistsInCurrentSchema,
  buildVariantOverrideUpdateExistsClause,
  buildVariantOverrideInsertExistsClause,
  buildDuplicateActionTripleNotExistsClause,
  applyOwnerChange,
  enrichOwnerNames,
  validateComputeRule,
  detectCycle,
  invalidChoiceConfigShape,
  resolveAncestors,
  restampTemplates,
  countAffectedTemplates,
  isValidBlueprintParent,
  logger,
  HIERARCHY_OWNER_AUDIT_EVENT,
  USER_TEMPLATE_OWNER_AUDIT_EVENT,
  resolveOwnershipRwPool,
  cascadeBlueprintOwnerToVariants,
  SAFE_COL_RE,
  isSafeColumnName,
  SLUG_KEY_PATTERN,
  isValidSlugKey,
  isBlueprintLinked,
  isBlueprintLinkedLocked,
  isLinkedParentLocked,
  auditSchemaClearFailed,
  validateLinkConstraints,
  resolveLinkCheckBlueprintId,
  _columnSetCache,
  getConnDatabaseName,
  getActualColumnSet,
  _historyTableCache,
  isCodeVersionHistoryAvailable,
  gateKeysByColumnSet,
  TABLE_VALUES,
  validateCodeVersioning,
  isMissingTableOrColumn,
  _codeVersioningDegraded,
  warnCodeVersioningDegradedOnce,
  validateAndPrepareParentOwnership,
  validateAndPrepareParentRepend,
  buildChainSelectSql,
  buildChainExistsForRow,
  ENCRYPTION_GATE_422,
  runSerializeWrite,
  editorMayWriteBlueprint,
  MAX_BATCH_FIELD_IDS,
  MAX_BATCH_BLUEPRINT_IDS,
} = require('./helpers');
const { sameStoredValue } = require('./write-value');

function register(router) {

// Atomic field delete + order_index renormalize. Closes the lost-update
// window in FmbSchemaBuilder.handleDeleteField (delete options → delete field
// → renumber survivors, no transaction — a partial failure orphaned options
// or broke the order_index invariant). Body: { blueprint_id, field_id, db? }.
// One transaction: DELETE the field's options, DELETE the field, renumber the
// remaining fields' order_index to 0..N-1.
//
// Registered BEFORE the `/blueprint_fields` CRUD mount.
router.post('/blueprint_fields/delete-renormalize', async (req, res) => {
  if (!requireAdminOrEditor(req, res)) return;
  const { blueprint_id, field_id } = req.body || {};

  if (typeof blueprint_id !== 'string' || !blueprint_id) {
    const e = apiError('blueprint_id required', 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }
  if (typeof field_id !== 'string' || !field_id) {
    const e = apiError('field_id required', 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }

  const fieldsTable = t(TABLES.BLUEPRINT_FIELDS);
  const optionsTable = t(TABLES.FIELD_OPTIONS);
  let conn;
  try {
    const dynamicDb = req.body && req.body.db;
    conn = dynamicDb
      ? await (await getDynamicPool(dynamicDb)).rw.getConnection()
      : await pool.rw.getConnection();
    await conn.beginTransaction();

    // Locked probe (FOR UPDATE) so a concurrent link-transition PUT — which
    // locks the blueprint before setting linked_blueprint_id — serializes
    // with this delete instead of racing it.
    if (await isBlueprintLinkedLocked(conn, blueprint_id)) {
      await conn.rollback();
      const e = apiError(
        'Cannot edit the schema of a linked blueprint; edit the source blueprint instead',
        'LINKED_BLUEPRINT_READONLY', 409,
      );
      return res.status(e.status).json(e.body);
    }
    if (!(await editorMayWriteBlueprint(conn, req, blueprint_id))) {
      await conn.rollback();
      const e = apiError('Not allowed: blueprint is not owned by you and is not shared', 'FORBIDDEN', 403);
      return res.status(e.status).json(e.body);
    }

    // The field must belong to the named blueprint (so a stray field_id can't
    // delete a row under a blueprint the caller never proved ownership of).
    const fieldRows = await conn.query(
      `SELECT id FROM \`${fieldsTable}\` WHERE id = ? AND blueprint_id = ? FOR UPDATE`,
      [field_id, blueprint_id],
    );
    if (fieldRows.length === 0) {
      await conn.rollback();
      const e = apiError('Field not found for this blueprint', 'NOT_FOUND', 404);
      return res.status(e.status).json(e.body);
    }

    const delOpts = await conn.query(
      `DELETE FROM \`${optionsTable}\` WHERE field_id = ?`,
      [field_id],
    );
    // Zero-FK cascade substitute: any variant override on this field would
    // otherwise be stranded — its field_id points at the row about to be
    // deleted while its variant_id stays valid (the variant lives on), so no
    // variant-scoped cleanup catches it. Same transaction as the field delete.
    const delOverrides = await conn.query(
      `DELETE FROM \`${t(TABLES.VARIANT_OVERRIDES)}\` WHERE field_id = ?`,
      [field_id],
    );
    await conn.query(
      `DELETE FROM \`${fieldsTable}\` WHERE id = ? AND blueprint_id = ?`,
      [field_id, blueprint_id],
    );

    // order_index is INT NULL; `order_index IS NULL` (0 for set, 1 for null)
    // sorts the unset rows LAST — matching the generic list path — instead of
    // MariaDB's default NULL-first, so a delete can't hoist null-ordered
    // fields to the top while renumbering.
    const remaining = await conn.query(
      `SELECT id FROM \`${fieldsTable}\` WHERE blueprint_id = ?
       ORDER BY order_index IS NULL ASC, order_index ASC, id ASC FOR UPDATE`,
      [blueprint_id],
    );
    let renumbered = 0;
    for (let i = 0; i < remaining.length; i += 1) {
      await conn.query(
        `UPDATE \`${fieldsTable}\` SET order_index = ? WHERE id = ?`,
        [i, remaining[i].id],
      );
      renumbered += 1;
    }

    await conn.commit();
    res.json(apiOk({
      ok: true,
      deleted_options: delOpts && delOpts.affectedRows != null ? delOpts.affectedRows : 0,
      deleted_overrides: delOverrides && delOverrides.affectedRows != null ? delOverrides.affectedRows : 0,
      renumbered,
    }));
  } catch (err) {
    if (conn) {
      try { await conn.rollback(); } catch (rbErr) {
        logger.warn({ err: rbErr }, 'rollback after blueprint_fields delete-renormalize failed');
      }
    }
    logger.error({ err, blueprint_id, field_id }, 'Failed to delete + renormalize blueprint_fields');
    const e = apiError('Database operation failed', 'INTERNAL_ERROR');
    res.status(e.status).json(e.body);
  } finally {
    if (conn) conn.release();
  }
});


// Atomic group delete + field reassign/clear. Replaces the client-orchestrated
// reassign-then-delete in GroupsManagerPanel.confirmDeleteGroup, which read the
// affected fields from a stale snapshot, PUT each field's group_key, then
// deleted the group in a separate round-trip — a concurrent field-assign
// between snapshot and delete could leave a field's group_key dangling
// (accepted Codex P1, why-comment at that call site). One transaction:
// reassign (move → target_group_key) or clear (→ '') every field whose
// group_key === the deleted key, then delete the group row. A tx either commits
// or rolls back, so a partial state is impossible.
//
// Body: { blueprint_id, group_key, action: 'move'|'clear', target_group_key?, db? }.
// Registered BEFORE the `/blueprint_groups` CRUD mount.
router.post('/blueprint_groups/delete-with-reassign', async (req, res) => {
  if (!requireAdminOrEditor(req, res)) return;
  const { blueprint_id, group_key, action, target_group_key } = req.body || {};

  if (typeof blueprint_id !== 'string' || !blueprint_id) {
    const e = apiError('blueprint_id required', 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }
  if (typeof group_key !== 'string' || !group_key) {
    const e = apiError('group_key required', 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }
  if (action !== 'move' && action !== 'clear') {
    const e = apiError("action must be 'move' or 'clear'", 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }
  if (action === 'move') {
    if (typeof target_group_key !== 'string' || !target_group_key) {
      const e = apiError('target_group_key required when action is move', 'BAD_REQUEST', 400);
      return res.status(e.status).json(e.body);
    }
    // "Is the destination the row being deleted" is NOT decided here — see the
    // engine-resolved gate inside the transaction below. A JavaScript `!==` on
    // this pair is the defect, not a cheap first pass at it, so there is no
    // second answer to the same question in this handler.
  }

  const groupsTable = t(TABLES.BLUEPRINT_GROUPS);
  const fieldsTable = t(TABLES.BLUEPRINT_FIELDS);
  let conn;
  try {
    const dynamicDb = req.body && req.body.db;
    conn = dynamicDb
      ? await (await getDynamicPool(dynamicDb)).rw.getConnection()
      : await pool.rw.getConnection();
    await conn.beginTransaction();

    if (await isBlueprintLinkedLocked(conn, blueprint_id)) {
      await conn.rollback();
      const e = apiError(
        'Cannot edit the schema of a linked blueprint; edit the source blueprint instead',
        'LINKED_BLUEPRINT_READONLY', 409,
      );
      return res.status(e.status).json(e.body);
    }
    if (!(await editorMayWriteBlueprint(conn, req, blueprint_id))) {
      await conn.rollback();
      const e = apiError('Not allowed: blueprint is not owned by you and is not shared', 'FORBIDDEN', 403);
      return res.status(e.status).json(e.body);
    }

    // collation-compare: "is the destination the row being deleted" is a
    // question about a COLUMN. The two lock SELECTs below resolve `WHERE
    // group_key = ?` under the column's own collation, so a target spelt in
    // another case finds the SAME ROW and both "does it exist" checks pass. The
    // UPDATE then relabels every field to the target spelling — measured
    // (db-semantics §Q1), the engine stores a respelling rather than absorbing
    // it — and the DELETE removes the only group row there ever was: 200
    // `{ok:true}` with every field naming a lane that no longer exists.
    //
    // Asked after the authorization gates above so a caller who may not write
    // this blueprint learns nothing about its lanes from the shape of the
    // refusal.
    if (action === 'move' && await sameStoredValue(
      conn, groupsTable, 'group_key', target_group_key, group_key,
    )) {
      await conn.rollback();
      const e = apiError(
        'target_group_key must differ from the deleted group; capitalisation is ignored',
        'BAD_REQUEST', 400,
      );
      return res.status(e.status).json(e.body);
    }

    // Lock BOTH the deleted group and (on move) the target group FOR UPDATE, in
    // a deterministic key order so two concurrent swap-deletes (A: delete X→Y,
    // B: delete Y→X) can never acquire the two row locks in opposite order and
    // deadlock (ABBA). Canonicalise the order by lowercase key — mirrors
    // isLinkedParentLocked's sorted-lock pattern (VARCHAR keys match
    // case-insensitively under the default collation, but JS sort is
    // case-sensitive). The `found` set is keyed on the original strings, which
    // the gate above has already established the COLUMN calls two different
    // values, so case-only aliasing cannot cause a false miss.
    const lockKeys = action === 'move' ? [group_key, target_group_key] : [group_key];
    const orderedKeys = [...lockKeys].sort((a, b) => {
      const la = String(a).toLowerCase(); const lb = String(b).toLowerCase();
      return la < lb ? -1 : la > lb ? 1 : 0;
    });
    const found = new Set();
    for (const k of orderedKeys) {
      const rows = await conn.query(
        `SELECT id FROM \`${groupsTable}\` WHERE blueprint_id = ? AND group_key = ? FOR UPDATE`,
        [blueprint_id, k],
      );
      if (rows.length > 0) found.add(k);
    }
    // Deleted group absent → honest 404 (already gone).
    if (!found.has(group_key)) {
      await conn.rollback();
      const e = apiError('Group not found for this blueprint', 'NOT_FOUND', 404);
      return res.status(e.status).json(e.body);
    }
    if (action === 'move' && !found.has(target_group_key)) {
      await conn.rollback();
      const e = apiError('Target group not found for this blueprint', 'BAD_REQUEST', 400);
      return res.status(e.status).json(e.body);
    }

    // Reassign the affected fields. On a no-ALTER operator DB the group_key
    // column may be absent (the additive ALTER was skipped) — probe and skip
    // the UPDATE so the delete still succeeds instead of throwing 1054. clear →
    // '' (ungrouped; mirrors the client's prior behavior and the DTO mapper's
    // NULL→'' read coalescing); move → the target key.
    let reassigned = 0;
    const fieldColSet = await getActualColumnSet(conn, fieldsTable);
    if (!fieldColSet || fieldColSet.has('group_key')) {
      const newVal = action === 'move' ? target_group_key : '';
      const upd = await conn.query(
        `UPDATE \`${fieldsTable}\` SET group_key = ? WHERE blueprint_id = ? AND group_key = ?`,
        [newVal, blueprint_id, group_key],
      );
      reassigned = upd && upd.affectedRows != null ? upd.affectedRows : 0;
    }

    await conn.query(
      `DELETE FROM \`${groupsTable}\` WHERE blueprint_id = ? AND group_key = ?`,
      [blueprint_id, group_key],
    );

    await conn.commit();
    res.json(apiOk({ ok: true, action, reassigned }));
  } catch (err) {
    if (conn) {
      try { await conn.rollback(); } catch (rbErr) {
        logger.warn({ err: rbErr }, 'rollback after blueprint_groups delete-with-reassign failed');
      }
    }
    logger.error({ err, blueprint_id, group_key }, 'Failed to delete blueprint_group with reassign');
    const e = apiError('Database operation failed', 'INTERNAL_ERROR');
    res.status(e.status).json(e.body);
  } finally {
    if (conn) conn.release();
  }
});


// Atomic group-key rename with cascade to every referencing column. The group
// key was historically frozen after creation; it is now renamable through this
// endpoint. A bare UPDATE of blueprint_groups.group_key would orphan the
// blueprint_fields rows that reference the old key BY STRING — both
// blueprint_fields.group_key (lane membership) and blueprint_fields.matrix_row_key
// (matrix lane) — leaving fields stranded in a lane whose key no longer exists
// (the "no longer exists" dot in data entry). Mirrors delete-with-reassign: ONE
// transaction updates the group row and both referencing columns, all scoped to
// the single blueprint, so a partial rename is impossible.
//
// INVARIANT: user_templates.payload never references group_key (blueprint_groups
// DDL comment) — saved data is untouched, so there is no template walk here.
//
// Body: { blueprint_id, group_key, new_group_key, db? }.
// Registered BEFORE the `/blueprint_groups` CRUD mount so Express matches this
// exact path first; the generic CRUD PUT rejects a group_key change (immutable).
router.post('/blueprint_groups/rename-with-cascade', async (req, res) => {
  if (!requireAdminOrEditor(req, res)) return;
  const { blueprint_id, group_key, new_group_key } = req.body || {};

  if (typeof blueprint_id !== 'string' || !blueprint_id) {
    const e = apiError('blueprint_id required', 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }
  if (typeof group_key !== 'string' || !group_key) {
    const e = apiError('group_key required', 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }
  if (typeof new_group_key !== 'string' || !new_group_key) {
    const e = apiError('new_group_key required', 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }
  // The NEW key must satisfy the same slug shape the Schema Builder enforces
  // client-side and the generic CRUD create enforces on new keys. The OLD key
  // is matched as-stored (a legacy non-slug key can be renamed to a valid one).
  if (!isValidSlugKey(new_group_key)) {
    const e = apiError('group_key must be a valid slug', 'INVALID_KEY_FORMAT', 400);
    return res.status(e.status).json(e.body);
  }
  // byte-compare, and DELIBERATELY so — the one place in this family where the
  // engine's answer would be the wrong one. A rename that changes only
  // capitalisation IS a rename: measured (db-semantics §Q1) the column stores
  // the new spelling rather than absorbing it, and normalising a legacy `Lane_A`
  // to `lane_a` is exactly what an operator uses this endpoint for. Only a
  // request that asks for the bytes already stored asks for nothing, and the
  // duplicate probe below excludes the row being renamed so this stays legal.
  if (new_group_key === group_key) {
    const e = apiError('new_group_key must differ from the current key', 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }

  const groupsTable = t(TABLES.BLUEPRINT_GROUPS);
  const fieldsTable = t(TABLES.BLUEPRINT_FIELDS);
  let conn;
  try {
    const dynamicDb = req.body && req.body.db;
    conn = dynamicDb
      ? await (await getDynamicPool(dynamicDb)).rw.getConnection()
      : await pool.rw.getConnection();
    await conn.beginTransaction();

    if (await isBlueprintLinkedLocked(conn, blueprint_id)) {
      await conn.rollback();
      const e = apiError(
        'Cannot edit the schema of a linked blueprint; edit the source blueprint instead',
        'LINKED_BLUEPRINT_READONLY', 409,
      );
      return res.status(e.status).json(e.body);
    }
    if (!(await editorMayWriteBlueprint(conn, req, blueprint_id))) {
      await conn.rollback();
      const e = apiError('Not allowed: blueprint is not owned by you and is not shared', 'FORBIDDEN', 403);
      return res.status(e.status).json(e.body);
    }

    // Lock the group row being renamed FOR UPDATE so a concurrent rename/delete
    // of the same group serialises behind this transaction.
    const targetRows = await conn.query(
      `SELECT id FROM \`${groupsTable}\` WHERE blueprint_id = ? AND group_key = ? FOR UPDATE`,
      [blueprint_id, group_key],
    );
    if (!targetRows.length) {
      await conn.rollback();
      const e = apiError('Group not found for this blueprint', 'NOT_FOUND', 404);
      return res.status(e.status).json(e.body);
    }
    const targetId = targetRows[0].id;

    // collation-compare: uniqueness of the NEW key within the blueprint is a
    // question about a COLUMN, and about the index built on it. The equality
    // predicate uses the column's own collation — the SAME collation the UNIQUE
    // index uq_blueprint_group_key enforces — so a case-variant of an existing
    // key (e.g. renaming to `lane_a` when `Lane_A` already exists) is caught
    // here exactly as the index would catch it. `id <> ?` excludes the row being
    // renamed so a legacy case-only normalisation of the same row is allowed.
    const dupRows = await conn.query(
      `SELECT id FROM \`${groupsTable}\` WHERE blueprint_id = ? AND group_key = ? AND id <> ? LIMIT 1`,
      [blueprint_id, new_group_key, targetId],
    );
    if (dupRows.length) {
      await conn.rollback();
      const e = apiError('A row with this key already exists for this blueprint', 'DUPLICATE_GROUP_KEY', 409);
      return res.status(e.status).json(e.body);
    }

    // Rename the group row itself — THE ROW THE GATE APPROVED, named by its own
    // id, and no other. Keyed on `group_key` this statement was resolved by the
    // engine under the column's collation while the gate above had locked and
    // approved exactly ONE row (`targetRows[0]`), so on a database whose
    // `uq_blueprint_group_key` was never created — the same class of database
    // the column probes below exist for — a blueprint holding both `lane_a` and
    // `Lane_A` had BOTH rows rewritten to the new key by a rename that named
    // one. Two lanes, each with its own label and colour, came out sharing a
    // key, and nothing afterwards can tell them apart or undo it.
    //
    // Bounded by `id`, the statement's own predicate names the locked row, so
    // the set it acts on and the set the gate judged are the same set by
    // construction rather than by the collation happening to agree.
    await conn.query(
      `UPDATE \`${groupsTable}\` SET group_key = ? WHERE id = ?`,
      [new_group_key, targetId],
    );

    // Cascade to blueprint_fields. collation-compare, and here that is the
    // point rather than a hazard: a field names its lane BY STRING and the
    // engine resolves that reference under the column's collation, so a field
    // holding a legacy `Lane_A` is in the lane this rename is moving and must
    // move with it. The set is deliberately wider than one row — unlike the
    // group row above, which is a row the gate approved. On a no-ALTER operator
    // DB either referencing column may be absent (its additive ALTER was
    // skipped) — probe and skip the UPDATE so the rename still succeeds instead
    // of throwing 1054, mirroring delete-with-reassign's column-set gate.
    const fieldColSet = await getActualColumnSet(conn, fieldsTable);
    let fieldsUpdated = 0;
    let matrixUpdated = 0;
    if (!fieldColSet || fieldColSet.has('group_key')) {
      const upd = await conn.query(
        `UPDATE \`${fieldsTable}\` SET group_key = ? WHERE blueprint_id = ? AND group_key = ?`,
        [new_group_key, blueprint_id, group_key],
      );
      fieldsUpdated = upd && upd.affectedRows != null ? upd.affectedRows : 0;
    }
    if (!fieldColSet || fieldColSet.has('matrix_row_key')) {
      const updM = await conn.query(
        `UPDATE \`${fieldsTable}\` SET matrix_row_key = ? WHERE blueprint_id = ? AND matrix_row_key = ?`,
        [new_group_key, blueprint_id, group_key],
      );
      matrixUpdated = updM && updM.affectedRows != null ? updM.affectedRows : 0;
    }

    // Audit row — same in-transaction pattern as blueprint.field.type_changed
    // above: a write failure here rolls back the whole rename (via the catch
    // block below) rather than silently skipping the audit trail. Logical
    // key names only — no physical table names, no secrets/PII.
    await conn.query(
      `INSERT INTO \`${t(TABLES.FEATURE_AUDIT)}\` (id, event_type, user_id, metadata)
       VALUES (?, 'blueprint_group.rename', ?, ?)`,
      [
        uuidv4(),
        // lint-allow: write-path-shapes the feature_audit user_id column: a
        // row written from the provider's subject claim names an actor no reader of
        // users.id resolves. Deferred with the rest of the audit-line family.
        req.user?.id || req.user?.sub || null,
        JSON.stringify({
          blueprint_id,
          old_key: group_key,
          new_key: new_group_key,
          fields_updated: fieldsUpdated,
          matrix_updated: matrixUpdated,
        }),
      ],
    );

    await conn.commit();
    res.json(apiOk({ ok: true, fields_updated: fieldsUpdated, matrix_updated: matrixUpdated }));
  } catch (err) {
    if (conn) {
      try { await conn.rollback(); } catch (rbErr) {
        logger.warn({ err: rbErr }, 'rollback after blueprint_groups rename-with-cascade failed');
      }
    }
    // The UNIQUE index is the backstop if the app-layer pre-check raced a
    // concurrent insert of the same key.
    if (err && err.errno === 1062) {
      const e = apiError('A row with this key already exists for this blueprint', 'DUPLICATE_GROUP_KEY', 409);
      return res.status(e.status).json(e.body);
    }
    logger.error({ err, blueprint_id, group_key }, 'Failed to rename blueprint_group with cascade');
    const e = apiError('Database operation failed', 'INTERNAL_ERROR');
    res.status(e.status).json(e.body);
  } finally {
    if (conn) conn.release();
  }
});


// Read-only preview for rename-with-cascade above — lets the FE show the
// live "N field(s), M matrix reference(s) will move" count in the rename
// dialog BEFORE the destructive commit. POST (not GET): X-Database-routed
// schema endpoints must accept a body (`db` override) — GET strips the body
// via forwardToEdge, per the project's identifiers-via-tables/routing rule.
// Body: { blueprint_id, group_key, db? }.
router.post('/blueprint_groups/rename-impact', async (req, res) => {
  if (!requireAdminOrEditor(req, res)) return;
  const { blueprint_id, group_key } = req.body || {};

  if (typeof blueprint_id !== 'string' || !blueprint_id) {
    const e = apiError('blueprint_id required', 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }
  if (typeof group_key !== 'string' || !group_key) {
    const e = apiError('group_key required', 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }

  const groupsTable = t(TABLES.BLUEPRINT_GROUPS);
  const fieldsTable = t(TABLES.BLUEPRINT_FIELDS);
  let conn;
  try {
    const dynamicDb = req.body && req.body.db;
    conn = dynamicDb
      ? await (await getDynamicPool(dynamicDb)).ro.getConnection()
      : await pool.ro.getConnection();

    // SECURITY: same ownership scope as the mutating endpoint — an editor
    // must not learn impact counts for a blueprint they cannot write to.
    if (!(await editorMayWriteBlueprint(conn, req, blueprint_id))) {
      const e = apiError('Not allowed: blueprint is not owned by you and is not shared', 'FORBIDDEN', 403);
      return res.status(e.status).json(e.body);
    }

    const targetRows = await conn.query(
      `SELECT id FROM \`${groupsTable}\` WHERE blueprint_id = ? AND group_key = ?`,
      [blueprint_id, group_key],
    );
    if (!targetRows.length) {
      const e = apiError('Group not found for this blueprint', 'NOT_FOUND', 404);
      return res.status(e.status).json(e.body);
    }

    // Mirror the rename-with-cascade column-probe skip: a no-ALTER operator
    // DB may be missing either referencing column, in which case that count
    // is reported as 0 rather than throwing 1054.
    const fieldColSet = await getActualColumnSet(conn, fieldsTable);
    let fieldsAffected = 0;
    let matrixAffected = 0;
    if (!fieldColSet || fieldColSet.has('group_key')) {
      const fieldRows = await conn.query(
        `SELECT COUNT(*) AS cnt FROM \`${fieldsTable}\` WHERE blueprint_id = ? AND group_key = ?`,
        [blueprint_id, group_key],
      );
      fieldsAffected = Number(fieldRows[0]?.cnt || 0);
    }
    if (!fieldColSet || fieldColSet.has('matrix_row_key')) {
      const matrixRows = await conn.query(
        `SELECT COUNT(*) AS cnt FROM \`${fieldsTable}\` WHERE blueprint_id = ? AND matrix_row_key = ?`,
        [blueprint_id, group_key],
      );
      matrixAffected = Number(matrixRows[0]?.cnt || 0);
    }

    res.json(apiOk({ fields_affected: fieldsAffected, matrix_affected: matrixAffected }));
  } catch (err) {
    logger.error({ err, blueprint_id, group_key }, 'Failed to compute blueprint_group rename impact');
    const e = apiError('Database operation failed', 'INTERNAL_ERROR');
    res.status(e.status).json(e.body);
  } finally {
    if (conn) conn.release();
  }
});


// Atomic section delete + field reassign/delete. Replaces the client-
// orchestrated flow in FmbSchemaBuilder.confirmDeleteSection, which had the
// identical stale-snapshot-then-delete shape as the group flow above (move
// fields OR delete fields+options, then delete the section meta, across
// several separate round-trips). One transaction mirrors that flow's exact
// semantics:
//   move   → reassign every field whose section === the deleted key to
//            target_section, then delete the section row.
//   delete → delete those fields' options, delete the fields, then delete the
//            section row.
// A tx either commits or rolls back — the old partial-failure toast is obsolete.
//
// Body: { blueprint_id, section_key, action: 'move'|'delete', target_section?, db? }.
// Registered BEFORE the `/blueprint_sections` CRUD mount.
router.post('/blueprint_sections/delete-with-reassign', async (req, res) => {
  if (!requireAdminOrEditor(req, res)) return;
  const { blueprint_id, section_key, action, target_section } = req.body || {};

  if (typeof blueprint_id !== 'string' || !blueprint_id) {
    const e = apiError('blueprint_id required', 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }
  if (typeof section_key !== 'string' || !section_key) {
    const e = apiError('section_key required', 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }
  if (action !== 'move' && action !== 'delete') {
    const e = apiError("action must be 'move' or 'delete'", 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }
  if (action === 'move') {
    if (typeof target_section !== 'string' || !target_section) {
      const e = apiError('target_section required when action is move', 'BAD_REQUEST', 400);
      return res.status(e.status).json(e.body);
    }
    // Decided by the engine inside the transaction below, for the reason its
    // mirror in the groups lane states.
  }

  const sectionsTable = t(TABLES.BLUEPRINT_SECTIONS);
  const fieldsTable = t(TABLES.BLUEPRINT_FIELDS);
  const optionsTable = t(TABLES.FIELD_OPTIONS);
  let conn;
  try {
    const dynamicDb = req.body && req.body.db;
    conn = dynamicDb
      ? await (await getDynamicPool(dynamicDb)).rw.getConnection()
      : await pool.rw.getConnection();
    await conn.beginTransaction();

    if (await isBlueprintLinkedLocked(conn, blueprint_id)) {
      await conn.rollback();
      const e = apiError(
        'Cannot edit the schema of a linked blueprint; edit the source blueprint instead',
        'LINKED_BLUEPRINT_READONLY', 409,
      );
      return res.status(e.status).json(e.body);
    }
    if (!(await editorMayWriteBlueprint(conn, req, blueprint_id))) {
      await conn.rollback();
      const e = apiError('Not allowed: blueprint is not owned by you and is not shared', 'FORBIDDEN', 403);
      return res.status(e.status).json(e.body);
    }

    // collation-compare: the mirror of the groups gate above, and the same
    // question about the same kind of column — every predicate this handler
    // issues about a section resolves under `section_key`'s / `section`'s own
    // collation, so a target spelt in another case IS the section being
    // deleted. The move then relabels the fields onto that spelling and the
    // DELETE removes the metadata row — its label, icon, description and order —
    // that the fields were just pointed at.
    if (action === 'move' && await sameStoredValue(
      conn, sectionsTable, 'section_key', target_section, section_key,
    )) {
      await conn.rollback();
      const e = apiError(
        'target_section must differ from the deleted section; capitalisation is ignored',
        'BAD_REQUEST', 400,
      );
      return res.status(e.status).json(e.body);
    }

    // The blueprint_sections metadata row is OPTIONAL: legacy/imported
    // blueprints can have fields whose `section` key has no blueprint_sections
    // row, and SectionTree still renders (and the old handler could delete)
    // those metadata-less sections. So a section "exists" if it has a metadata
    // row OR any field references its key. Lock the metadata rows that DO exist
    // (the deleted one and, on move, the target) FOR UPDATE in deterministic
    // lowercase-canonical order so two concurrent swap-deletes cannot deadlock
    // (ABBA); a metadata-less section has no row to lock.
    const lockKeys = action === 'move' ? [section_key, target_section] : [section_key];
    const orderedKeys = [...lockKeys].sort((a, b) => {
      const la = String(a).toLowerCase(); const lb = String(b).toLowerCase();
      return la < lb ? -1 : la > lb ? 1 : 0;
    });
    const metaFound = new Set();
    for (const k of orderedKeys) {
      const rows = await conn.query(
        `SELECT id FROM \`${sectionsTable}\` WHERE blueprint_id = ? AND section_key = ? FOR UPDATE`,
        [blueprint_id, k],
      );
      if (rows.length > 0) metaFound.add(k);
    }
    const sectionHasFields = async (key) => {
      const r = await conn.query(
        `SELECT 1 FROM \`${fieldsTable}\` WHERE blueprint_id = ? AND section = ? LIMIT 1`,
        [blueprint_id, key],
      );
      return r.length > 0;
    };
    // 404 only when the deleted section is truly absent — no metadata row AND no
    // referencing field.
    if (!metaFound.has(section_key) && !(await sectionHasFields(section_key))) {
      await conn.rollback();
      const e = apiError('Section not found for this blueprint', 'NOT_FOUND', 404);
      return res.status(e.status).json(e.body);
    }
    if (action === 'move'
      && !metaFound.has(target_section)
      && !(await sectionHasFields(target_section))) {
      await conn.rollback();
      const e = apiError('Target section not found for this blueprint', 'BAD_REQUEST', 400);
      return res.status(e.status).json(e.body);
    }

    let moved = 0; let deletedFields = 0; let deletedOptions = 0; let deletedOverrides = 0;
    if (action === 'move') {
      const upd = await conn.query(
        `UPDATE \`${fieldsTable}\` SET section = ? WHERE blueprint_id = ? AND section = ?`,
        [target_section, blueprint_id, section_key],
      );
      moved = upd && upd.affectedRows != null ? upd.affectedRows : 0;
    } else {
      // Field ids in this section drive the option delete (options FK to
      // field_id, not blueprint_id/section). Blueprint-scoped so a stray
      // section_key cannot delete another blueprint's fields.
      //
      // FOR UPDATE, AND THAT IS THE WHOLE OF THIS BLOCK'S CORRECTNESS. This is a
      // hand-rolled cascade standing in for foreign keys the schema does not
      // have, so the rows it is about to cascade OVER must be the rows the
      // parent statement will act ON. Read without the lock, this was a
      // consistent-read snapshot: a field could leave the section — or arrive in
      // it — between here and the DELETE below, which re-evaluates its own
      // predicate against the latest committed rows. The losing interleaving
      // deleted a surviving field's options and variant overrides and left the
      // field itself in place, its choices destroyed and stored nowhere else.
      // The sibling cascade in `blueprint_fields/delete-renormalize` has locked
      // its rows since it shipped; this is the same rule.
      const fieldRows = await conn.query(
        `SELECT id FROM \`${fieldsTable}\` WHERE blueprint_id = ? AND section = ? FOR UPDATE`,
        [blueprint_id, section_key],
      );
      if (fieldRows.length > 0) {
        const ids = fieldRows.map((r) => r.id);
        const ph = ids.map(() => '?').join(', ');
        const delOpts = await conn.query(
          `DELETE FROM \`${optionsTable}\` WHERE field_id IN (${ph})`,
          ids,
        );
        deletedOptions = delOpts && delOpts.affectedRows != null ? delOpts.affectedRows : 0;
        // Zero-FK cascade substitute: variant overrides on these fields would
        // dangle (field_id → deleted row) while their variant_id stays valid.
        // Delete by field_id in the same transaction, before the field rows go.
        const delOverrides = await conn.query(
          `DELETE FROM \`${t(TABLES.VARIANT_OVERRIDES)}\` WHERE field_id IN (${ph})`,
          ids,
        );
        deletedOverrides = delOverrides && delOverrides.affectedRows != null ? delOverrides.affectedRows : 0;
        // The parent statement names the LOCKED IDS, not the predicate that
        // selected them. Re-stating the predicate would re-open the same gap
        // from the other side: a field that arrived in the section after the
        // lock would be deleted with its options and overrides left behind. And
        // the count reported is the one the statement produced, not the length
        // of the list that fed it — the two were the same number only while
        // nothing could come between them.
        const delFields = await conn.query(
          `DELETE FROM \`${fieldsTable}\` WHERE id IN (${ph})`,
          ids,
        );
        deletedFields = delFields && delFields.affectedRows != null ? delFields.affectedRows : 0;
      }
    }

    await conn.query(
      `DELETE FROM \`${sectionsTable}\` WHERE blueprint_id = ? AND section_key = ?`,
      [blueprint_id, section_key],
    );

    await conn.commit();
    res.json(apiOk({
      ok: true, action, moved, deleted_fields: deletedFields, deleted_options: deletedOptions,
      deleted_overrides: deletedOverrides,
    }));
  } catch (err) {
    if (conn) {
      try { await conn.rollback(); } catch (rbErr) {
        logger.warn({ err: rbErr }, 'rollback after blueprint_sections delete-with-reassign failed');
      }
    }
    logger.error({ err, blueprint_id, section_key }, 'Failed to delete blueprint_section with reassign');
    const e = apiError('Database operation failed', 'INTERNAL_ERROR');
    res.status(e.status).json(e.body);
  } finally {
    if (conn) conn.release();
  }
});


// Batch read of blueprint_fields for many blueprint ids. Replaces the per-
// blueprint GET fan-out on the templates list (one request per unique
// blueprint). Body: { blueprint_ids: string[], db? }. The id list rides in the
// POST body because the infra→edge proxy folds repeated GET params to a scalar.
// Read-only (requireAuth, RO pool) — same access contract as the generic
// `/blueprint_fields` list. Rows are grouped by blueprint_id with within-
// blueprint order_index ordering identical to the single-blueprint list path
// (NULL order_index sorts last, line ~857) so the shared per-blueprint cache the
// caller backfills stays byte-for-byte consistent with useBlueprintFields.
//
// Registered BEFORE the `/blueprint_fields` CRUD mount so `by-blueprints` is not
// parsed as `/blueprint_fields/:id`.
router.post('/blueprint_fields/by-blueprints', async (req, res) => {
  if (!requireAuth(req, res)) return;
  const { blueprint_ids } = req.body || {};
  if (!Array.isArray(blueprint_ids)) {
    const e = apiError('blueprint_ids must be an array', 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }
  if (blueprint_ids.length === 0) return res.json(apiOk([]));
  if (blueprint_ids.length > MAX_BATCH_BLUEPRINT_IDS) {
    const e = apiError(`blueprint_ids exceeds ${MAX_BATCH_BLUEPRINT_IDS} limit`, 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }
  if (!blueprint_ids.every((id) => typeof id === 'string' && id.length > 0)) {
    const e = apiError('blueprint_ids must be non-empty strings', 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }

  const tableName = t(TABLES.BLUEPRINT_FIELDS);
  const dynamicDb = req.body && req.body.db;
  let conn;
  try {
    conn = dynamicDb
      ? await (await getDynamicPool(dynamicDb)).ro.getConnection()
      : await pool.ro.getConnection();
    const placeholders = blueprint_ids.map(() => '?').join(', ');
    const rows = await conn.query(
      `SELECT * FROM \`${tableName}\`
         WHERE blueprint_id IN (${placeholders})
         ORDER BY blueprint_id, order_index IS NULL, order_index`,
      blueprint_ids,
    );
    res.json(apiOk(mapRowsFromDb(TABLES.BLUEPRINT_FIELDS, rows)));
  } catch (err) {
    logger.error({ err }, 'Failed to batch-read blueprint_fields by blueprint ids');
    const e = apiError('Database operation failed', 'INTERNAL_ERROR');
    res.status(e.status).json(e.body);
  } finally {
    if (conn) conn.release();
  }
});
}

module.exports = { register };
