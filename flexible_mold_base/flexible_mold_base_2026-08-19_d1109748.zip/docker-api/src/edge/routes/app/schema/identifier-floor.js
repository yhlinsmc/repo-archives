'use strict';

/**
 * identifier-floor.js — a value bound to an identifier column is a string of the
 * identifier shape, refused before any query if it is not.
 *
 * SECURITY: A BODY VALUE THAT RESOLVES A ROW IS NOT A STRING BECAUSE THE CALLER
 * SAID SO. MariaDB compares a CHAR column against a NUMBER in numeric context:
 * the column side is converted with leading-digit semantics, so `'0abc…'`,
 * `'af3e…'` and `'ffff…'` all convert to 0 and `WHERE id = 0` matches every one
 * of them. Measured through the driver this deployment uses
 * (db-experiments-1500-round2.md D1): `conn.query('… WHERE id = ?', [0])` really
 * does send a numeric bind and really does return a large share of a uuid table.
 * So a body carrying `{"blueprint_id": 0}` hands every guard an ARBITRARY row to
 * be decided about, while the statement stores the caller's literal.
 *
 * The rule lives here rather than inside the CRUD factory because the factory is
 * not the only writer: the hand-written handlers that shadow a factory verb
 * build their own statements and would otherwise each need their own copy of it.
 * The domain — which columns are identifiers — is read from the DDL by the
 * caller (`charColumnsFor`), never listed per mount.
 */

const { UUID_RE } = require('../../../../shared/helpers');

/** The identifier width every table in this schema uses. */
const UUID_CHAR_LENGTH = 36;

/**
 * The first identifier column this write names with a value that is not one.
 *
 * WHAT IT DOES NOT JUDGE, each for a stated reason:
 *   - an ABSENT column: there is no value to shape-check.
 *   - a NULL: `{"fk": null}` clears a nullable reference, which is a legitimate
 *     act; on a NOT NULL column it is an unstorable value, and turning that 500
 *     into a 400 is a separate change with its own row.
 *   - CANONICAL SPELLING: `UUID_RE` is deliberately case-insensitive. This is a
 *     SHAPE check; whether a differently-capitalised id is the same id is a
 *     question about the column's collation and belongs to the helper that asks
 *     the engine.
 *
 * Presence is `hasOwnProperty`, and a key present with `undefined` reads as the
 * `null` the statement would store — the same reading `deriveWritten` and the
 * factory's own gates take, so the three cannot disagree about what a write
 * names.
 *
 * @param {string[]} identifierColumns the columns to judge (DDL-derived)
 * @param {object} write the columns this statement will name, and their values
 * @returns {{status: number, code: string, column: string, message: string}|null}
 */
function identifierFloorViolation(identifierColumns, write) {
  if (!write || typeof write !== 'object') return null;
  for (const col of identifierColumns || []) {
    if (!Object.prototype.hasOwnProperty.call(write, col)) continue;
    const value = write[col];
    if (value === undefined || value === null) continue;
    if (typeof value === 'string' && UUID_RE.test(value)) continue;
    return {
      status: 400,
      code: 'INVALID_ID_FORMAT',
      column: col,
      message: `${col} must be an identifier in the canonical ${UUID_CHAR_LENGTH}-character form`,
    };
  }
  return null;
}

module.exports = { UUID_CHAR_LENGTH, identifierFloorViolation };
