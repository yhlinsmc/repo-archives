const {
  TABLES,
  VARIANT_OVERRIDE_ACTIONS,
  pool,
  t,
  getDynamicPool,
  apiOk,
  apiError,
  requireAuth,
  requireAdmin,
  requireAdminOrEditor,
  isOwnerOrAdmin,
  uuidv4,
  UUID_RE,
  mapRowFromDb,
  mapRowsFromDb,
  mapRowToDb,
  previewCascade,
  cascadeDeleteNode,
  collectDescendantIds,
  tableExistsInCurrentSchema,
  buildVariantOverrideUpdateExistsClause,
  buildVariantOverrideInsertExistsClause,
  buildDuplicateActionTripleNotExistsClause,
  applyOwnerChange,
  enrichOwnerNames,
  validateComputeRule,
  detectCycle,
  invalidChoiceConfigShape,
  resolveAncestors,
  restampTemplates,
  countAffectedTemplates,
  isValidBlueprintParent,
  logger,
  HIERARCHY_OWNER_AUDIT_EVENT,
  USER_TEMPLATE_OWNER_AUDIT_EVENT,
  resolveOwnershipRwPool,
  cascadeBlueprintOwnerToVariants,
  SAFE_COL_RE,
  isSafeColumnName,
  SLUG_KEY_PATTERN,
  isValidSlugKey,
  isBlueprintLinked,
  isBlueprintLinkedLocked,
  isLinkedParentLocked,
  auditSchemaClearFailed,
  validateLinkConstraints,
  resolveLinkCheckBlueprintId,
  _columnSetCache,
  getConnDatabaseName,
  getActualColumnSet,
  _historyTableCache,
  isCodeVersionHistoryAvailable,
  gateKeysByColumnSet,
  TABLE_VALUES,
  validateCodeVersioning,
  isMissingTableOrColumn,
  _codeVersioningDegraded,
  warnCodeVersioningDegradedOnce,
  validateAndPrepareParentOwnership,
  validateAndPrepareParentRepend,
  buildChainSelectSql,
  buildChainExistsForRow,
  ENCRYPTION_GATE_422,
  runSerializeWrite,
  editorMayWriteBlueprint,
  MAX_BATCH_FIELD_IDS,
  MAX_BATCH_BLUEPRINT_IDS,
  effectiveBlueprintIdSql,
} = require('./helpers');
const { metadataKeySitesPresentIn } = require('../../../lib/user-template-metadata');
const { exceedsCharacterLimit } = require('../../../lib/db-character-length');

/**
 * How long an orphan key may be before this endpoint refuses to look for it.
 *
 * NOT the capacity of a column: an orphan key is a JSON object key inside
 * `user_templates.payload`, which no write path bounds.
 *
 * AND NOT A LIMIT THE ENGINE HAS. Measured: `JSON_CONTAINS_PATH` and
 * `JSON_REMOVE` both succeed on a path built from 300 ASCII characters, from 256
 * astral characters (1024 bytes) and from 256 CJK — every one returned 1 and
 * removed the key. MariaDB needs no protection at this size, so this is a sanity
 * bound on request input and nothing more. Saying otherwise would put a
 * justification here that the next reader could check and find false.
 *
 * COUNTED IN CHARACTERS, the unit MariaDB counts, via the shared rule — see
 * db-character-length.js. That part is not cosmetic: a bound counted in UTF-16
 * code units refused a 130-character astral key at 260, and this endpoint is the
 * ONLY way a residual leaves the interface, so that row could never be cleared
 * at all.
 *
 * Deliberately NOT lowered to the metadata columns' 255: those two bounds answer
 * different questions, and narrowing this one would strand every key between
 * them the same way. Nothing bounds a payload key on the way IN — the write
 * guard covers the three metadata sites only — so a longer key can still be
 * stored and then refused here forever. That is the same defect one size up,
 * and it is tracked rather than fixed by moving this number.
 */
const MAX_ORPHAN_KEY_LENGTH = 256;


// Field-data orphan scanner: surfaces template payload keys that no
// longer match any blueprint_fields.field_key for the template's
// EFFECTIVE blueprint. Which blueprint that is — and what a stored link
// value has to look like before it names one — is decided ONCE, by
// `effectiveBlueprintIdSql` in helpers.js beside the JavaScript reader of the
// same column. Every query below asks it rather than spelling the resolution
// out; a hand-written COALESCE here is what made this endpoint delete valid
// answers off a blueprint whose link column held an empty string.
// Without resolving the link at all, valid linked-field keys would be flagged
// as orphans and stripped on cleanup.
// Structural shape check mirroring src/fmb/lib/payload-transform.ts
// isValueShapeValidForType (separate build roots cannot share the module).
// Template payload values are persisted as STRINGS: a checkbox is a JSON
// string-array ('["a","b"]'), a table is a JSON string of rows, and scalars
// are plain strings. Parse the string to derive the real shape; a plain
// non-JSON string is a scalar. null/absent/empty never mismatches. Detection is
// ONE-DIRECTIONAL: only a composite field (checkbox/table) holding a value that
// cannot be its shape is flagged. Scalar fields are never flagged — the payload
// carries no type tag and a JSON-parseable string can be legitimate input, so
// parsing scalar content to infer a stranded composite would risk data loss.
function effectiveValueShape(value) {
  if (value === null || value === undefined || value === '') return 'blank';
  let v = value;
  if (typeof value === 'string') {
    try {
      v = JSON.parse(value);
    } catch {
      return 'scalar';
    }
  }
  if (Array.isArray(v)) return 'array';
  if (typeof v === 'object' && v !== null) return 'object';
  return 'scalar';
}


function valueShapeValidForType(fieldType, value) {
  const shape = effectiveValueShape(value);
  if (shape === 'blank') return true;
  switch (fieldType) {
    case 'checkbox':
      return shape === 'array';
    case 'table':
      return shape === 'array' || shape === 'object';
    case 'text':
    case 'textarea':
    case 'number':
    case 'select':
      // Scalar fields are never flagged: payload stores no type tag, the value is
      // a string regardless, and a string that parses as JSON can be legitimate
      // input, so parsing scalar content to infer a stranded composite would risk
      // deleting valid data. Composite→scalar residuals are therefore not detected.
      return true;
    default:
      return true;
  }
}


/**
 * The `SET` clauses that remove one field key from every field-key-indexed
 * METADATA document on a template row, for appending after the `payload` clause.
 *
 * Clearing a field's residue means all of it. Deleting a `blueprint_field` does
 * not purge template data, so this endpoint is the designated repair; repairing
 * `payload` alone leaves a marker behind that says the operator emptied a field
 * on purpose, or overrode a computed one, and re-creating a field under the same
 * key re-applies it. The paths come from the shared declaration, so the channels
 * of the one channelled column are addressed at the depth its keys actually sit.
 *
 * ONE ASSIGNMENT PER COLUMN, WHICH IS THE POINT OF GROUPING. The channelled
 * column has two key sites, and a clause per site would assign the same column
 * twice in one statement — leaving whether both removals survive to the order the
 * engine evaluates a SET list in. MariaDB 10.11.16 happens to evaluate left to
 * right in both the single- and multi-table forms (measured), but that is a
 * property of this engine and this version rather than of the statement, and it
 * is invisible to any test that asserts SQL text against a mock. Grouping by
 * column removes the question: every path for a column goes into that column's
 * single JSON_REMOVE, so there is no order to depend on.
 *
 * The guard is `JSON_VALID` rather than a per-path test, because the hazard it
 * covers is the document being unparseable: JSON_REMOVE against text MariaDB
 * cannot parse answers NULL, which would replace a corrupt document with no
 * document at all. A path that is simply not present is already a no-op
 * (verified against 10.11.16, including an absent channel, an array and a
 * scalar), and `JSON_VALID(NULL)` is NULL, so a NULL column stays NULL.
 *
 * @param {{column: string, container: string}[]} sites
 * @param {string} key       already validated by the caller for JSON-path safety
 * @param {string} [alias]   table alias, for the multi-table UPDATE form
 */
function buildMetadataClearClauses(sites, key, alias) {
  const prefix = alias ? `${alias}.` : '';
  const pathsByColumn = new Map();
  for (const site of sites) {
    if (!isSafeColumnName(site.column)) {
      throw new Error(`[orphan-clear]: ${site.column} fails column whitelist`);
    }
    if (!pathsByColumn.has(site.column)) pathsByColumn.set(site.column, []);
    pathsByColumn.get(site.column).push(`${site.container}."${key}"`);
  }

  const clauses = [];
  const params = [];
  for (const [column, paths] of pathsByColumn) {
    const col = `${prefix}\`${column}\``;
    const placeholders = paths.map(() => '?').join(', ');
    clauses.push(
      `${col} = CASE WHEN JSON_VALID(${col})`
      + ` THEN JSON_REMOVE(${col}, ${placeholders}) ELSE ${col} END`,
    );
    params.push(...paths);
  }
  return { sql: clauses.length ? `, ${clauses.join(', ')}` : '', params };
}


async function scanFieldDataOrphans(conn) {
  // fieldsByBlueprint: Map<blueprint_id, Map<field_key, field_type[]>>
  //
  // EVERY row that holds the key, not the last one seen. `(blueprint_id,
  // field_key)` is unique on a database that took the index, but the migration
  // that creates it SKIPS — visibly, rather than failing boot — on a database
  // that already holds duplicates, so a key with two field rows is a state the
  // deployed schema is still allowed to be in. Keyed by a Map that kept the last
  // writer, this scanner judged a payload value against whichever row the engine
  // returned last and reported it as a mismatch even when the other row accepts
  // it — and the repair endpoint then REMOVED it. Ordered by id so the type this
  // reports for display is the same one on every run.
  const fields = await conn.query(
    `SELECT blueprint_id, field_key, field_type FROM \`${t(TABLES.BLUEPRINT_FIELDS)}\`
      ORDER BY id`,
  );
  const fieldsByBlueprint = new Map();
  for (const f of fields) {
    if (!fieldsByBlueprint.has(f.blueprint_id)) fieldsByBlueprint.set(f.blueprint_id, new Map());
    const byKey = fieldsByBlueprint.get(f.blueprint_id);
    // byte-compare: a payload key is a JSON document path and a stored
    // `field_key` is what a JavaScript reader looks it up by, so two spellings
    // the column folds into one are two different keys here — and the delete
    // endpoint matches the same pair with `BINARY ?` for the same reason.
    if (!byKey.has(f.field_key)) byKey.set(f.field_key, []);
    byKey.get(f.field_key).push(f.field_type);
  }
  const templates = await conn.query(
    `SELECT ut.id, ut.name, ut.blueprint_id,
            ${effectiveBlueprintIdSql('hn', 'ut')} AS effective_blueprint_id,
            ehn.id AS effective_bp_row_id,
            ehn.owner_id AS blueprint_owner_id, ut.payload
       FROM \`${t(TABLES.USER_TEMPLATES)}\` ut
       LEFT JOIN \`${t(TABLES.HIERARCHY_NODES)}\` hn ON hn.id = ut.blueprint_id
       LEFT JOIN \`${t(TABLES.HIERARCHY_NODES)}\` ehn ON ehn.id = ${effectiveBlueprintIdSql('hn', 'ut')}
      WHERE ut.payload IS NOT NULL`,
  );
  const orphans = [];
  for (const tpl of templates) {
    let payload;
    try {
      payload = typeof tpl.payload === 'string' ? JSON.parse(tpl.payload) : tpl.payload;
    } catch {
      continue;
    }
    if (!payload || typeof payload !== 'object') continue;
    const fieldMap = fieldsByBlueprint.get(tpl.effective_blueprint_id) || new Map();
    for (const key of Object.keys(payload)) {
      const value = payload[key];
      const valuePreview = typeof value === 'string'
        ? value.slice(0, 80)
        : JSON.stringify(value).slice(0, 80);
      if (!fieldMap.has(key)) {
        orphans.push({
          kind: 'orphan',
          template_id: tpl.id, template_name: tpl.name || tpl.id,
          blueprint_id: tpl.blueprint_id, orphan_key: key, value_preview: valuePreview,
          blueprint_owner_id: tpl.blueprint_owner_id,
          effective_bp_row_id: tpl.effective_bp_row_id,
        });
      } else if (!fieldMap.get(key).some((ft) => valueShapeValidForType(ft, value))) {
        // A value ANY field holding this key accepts is that field's data, and
        // this list is what a repair endpoint deletes from. Reported only when
        // no declared type accepts it.
        orphans.push({
          kind: 'type_mismatch',
          template_id: tpl.id, template_name: tpl.name || tpl.id,
          blueprint_id: tpl.blueprint_id, orphan_key: key, value_preview: valuePreview,
          field_type: fieldMap.get(key)[0],
          blueprint_owner_id: tpl.blueprint_owner_id,
          effective_bp_row_id: tpl.effective_bp_row_id,
        });
      }
    }
  }
  return orphans;
}


// Both endpoints honour the X-Database middleware contract: when the
// active connection profile injects req.body.db, the dynamic pool for
// that schema must be used so admin-selected schema is respected.
async function resolveOrphanRwPool(req) {
  return req.body?.db ? (await getDynamicPool(req.body.db)).rw : pool.rw;
}

async function resolveOrphanRoPool(req) {
  return req.body?.db ? (await getDynamicPool(req.body.db)).ro : pool.ro;
}


// An editor may only clear a residual under a template whose blueprint they
// own or that is shared (owner_id NULL); admin bypasses. Re-checks ownership
// server-side on the SAME connection as the mutation so a client cannot claim
// a template they do not own. For an editor, a missing template row and a
// missing effective-blueprint row both return false (caller 404s it), so a
// non-owner editor cannot distinguish "not mine" from "does not exist". Admin
// still reaches the downstream staleness re-check (409 on a genuinely stale row).
// INVARIANT: callers MUST run this inside an open transaction — the SELECT takes
// a FOR UPDATE lock on the effective-blueprint owner row so a concurrent
// owner-transfer cannot slip between this check and the payload mutation
// (a former owner deleting another owner's data). Admin short-circuits before
// the query and therefore takes no lock, which is correct.
async function editorOwnsTemplateBlueprint(conn, req, templateId) {
  // Fail-closed allow-list: only admin bypasses; anything that is not a
  // recognised editor is denied so a future caller that forgets an upstream
  // role gate cannot inherit a silent pass (defense-in-depth).
  if (req.user?.role === 'admin') return true;
  if (req.user?.role !== 'editor') return false;
  const rows = await conn.query(
    `SELECT ehn.id AS ebp_id, ehn.owner_id AS owner_id
       FROM \`${t(TABLES.USER_TEMPLATES)}\` ut
       LEFT JOIN \`${t(TABLES.HIERARCHY_NODES)}\` hn ON hn.id = ut.blueprint_id
       LEFT JOIN \`${t(TABLES.HIERARCHY_NODES)}\` ehn ON ehn.id = ${effectiveBlueprintIdSql('hn', 'ut')}
      WHERE ut.id = ?
        FOR UPDATE`,
    [templateId],
  );
  const row = rows[0];
  if (!row) return false; // template gone
  // A dangling effective blueprint (linked blueprint deleted, or blueprint
  // gone) makes the LEFT JOIN return NULL owner_id — that looks like "shared"
  // but is really "no owner row at all". Fail closed for editors; only admin
  // may act on such rows.
  if (row.ebp_id == null) return false;
  const owner = row.owner_id ?? null;
  return owner == null || owner === req.user.id;
}

function register(router) {

// Scan is POST not GET because forwardToEdge drops body on GET (by design),
// which would strip the req.body.db that infra X-Database middleware sets
// (or that a direct dynamic-pool caller passes in body). POST keeps body
// intact so multi-schema deploys see orphans from the selected schema.
// Body shape: {} or { db: { host, port, user, password, database } }.
router.post('/field-data-orphans', async (req, res) => {
  if (!requireAdminOrEditor(req, res)) return;
  try {
    const conn = await (await resolveOrphanRoPool(req)).getConnection();
    try {
      let orphans = await scanFieldDataOrphans(conn);
      if (req.user.role === 'editor') {
        // Editor sees only residuals under a blueprint they own or that is
        // shared (owner_id NULL). Keep the shared case — dropping it would
        // hide legitimately clearable rows. A dangling effective blueprint
        // (effective_bp_row_id NULL — linked blueprint deleted, or blueprint
        // gone) has a NULL owner that only LOOKS shared; fail closed so only
        // admin may clean those.
        orphans = orphans.filter(
          (o) => o.effective_bp_row_id != null
            && (o.blueprint_owner_id == null || o.blueprint_owner_id === req.user.id),
        );
      }
      // blueprint_owner_id and effective_bp_row_id are internal scoping fields —
      // strip them so they never reach the client, for admin and editor alike.
      const view = orphans.map(
        ({ blueprint_owner_id, effective_bp_row_id, ...rest }) => rest,
      );
      res.json(apiOk({ orphans: view, total: view.length }));
    } finally {
      conn.release();
    }
  } catch (err) {
    logger.error({ err }, 'Failed to scan field-data orphans');
    const e = apiError('Database operation failed', 'INTERNAL_ERROR');
    res.status(e.status).json(e.body);
  }
});


router.delete('/field-data-orphans/:templateId/:key', async (req, res) => {
  if (!requireAdminOrEditor(req, res)) return;
  const { templateId, key } = req.params;
  // Orphan keys can be ANY historical / imported / legacy-formatted key,
  // not just current-spec field_keys. Permit a broad printable character
  // set; reject only the chars that would break the JSON path string
  // wrapper (`"` and `\`), null bytes, empty, and anything past
  // MAX_ORPHAN_KEY_LENGTH characters. MariaDB returns a malformed-path error
  // for anything genuinely unparseable.
  // eslint-disable-next-line no-control-regex -- SAFETY: \x00 (null byte) is intentionally rejected, not a stray leak.
  if (!key || exceedsCharacterLimit(key, MAX_ORPHAN_KEY_LENGTH) || /["\x00\\]/.test(key)) {
    const e = apiError('Invalid orphan key', 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }
  const kind = req.query.kind === 'type_mismatch' ? 'type_mismatch' : 'orphan';
  if (kind === 'type_mismatch') {
    // Re-derive the mismatch server-side inside ONE transaction. The
    // re-validation SELECT takes a FOR UPDATE row lock on the template
    // (and joined field) row, so a concurrent transaction that reverts
    // `blueprint_fields.field_type` back to a shape-valid type blocks until
    // we commit/rollback — it cannot slip its revert between our read and
    // the JSON_REMOVE. That lock is the TOCTOU fence (a plain snapshot read
    // under REPEATABLE READ would NOT serialize the concurrent revert).
    // NEVER trust a client claim that the value is a mismatch: a value that
    // became shape-valid again (e.g. the field type was reverted) MUST be
    // preserved, not stripped.
    const conn = await (await resolveOrphanRwPool(req)).getConnection();
    try {
      await conn.beginTransaction();
      // Re-verify blueprint ownership on this same transaction before touching
      // the payload. A non-owner editor is 404'd (not 403) so the endpoint does
      // not disclose that the template exists.
      if (!(await editorOwnsTemplateBlueprint(conn, req, templateId))) {
        await conn.rollback();
        const e = apiError('Not found', 'NOT_FOUND', 404);
        return res.status(e.status).json(e.body);
      }
      // NO `LIMIT`, AND EVERY ROW IS JUDGED. `(blueprint_id, field_key)` carries
      // a UNIQUE index only on databases that could take it, so this join can
      // return more than one field row — and reading `rows[0].ft` meant the
      // re-check judged whichever row the engine returned FIRST while the
      // scanner had reported the LAST. Nothing makes those the same row. A value
      // the other field accepts was therefore removed from the payload, and it
      // is stored nowhere else. The value is a residual only when NO field
      // holding the key accepts it, which is the same rule the scanner applies.
      //
      // byte-compare on `field_key` (`BINARY ?`): the key is a JSON document
      // path in the statement below and a JavaScript Map key in the scanner, so
      // a field spelt `City` does not hold the payload key `city` for either of
      // them. Folding here would let this endpoint clear a residual the scanner
      // never flagged.
      //
      // THE VALUE IS TAKEN FROM THE DOCUMENT, THE WAY THE SCANNER TAKES IT.
      // `JSON_EXTRACT` returns JSON text, but this driver hydrates it, so a
      // stored string `"plain"` arrived as the JavaScript string `plain` —
      // indistinguishable from unparsed JSON text — and the `JSON.parse` in
      // front of the shape check threw on it. That is a 500 for the commonest
      // residual there is, a scalar under a checkbox field, on the endpoint whose
      // job is to remove exactly that. Reading the payload and indexing it is
      // what the scanner does, so the two now judge the identical value, and
      // `effectiveValueShape` does its own parsing of a scalar anyway.
      const rows = await conn.query(
        `SELECT bf.field_type AS ft, ut.payload AS payload
           FROM \`${t(TABLES.USER_TEMPLATES)}\` ut
           LEFT JOIN \`${t(TABLES.HIERARCHY_NODES)}\` hn ON hn.id = ut.blueprint_id
           LEFT JOIN \`${t(TABLES.BLUEPRINT_FIELDS)}\` bf
             ON bf.blueprint_id = ${effectiveBlueprintIdSql('hn', 'ut')}
            AND bf.field_key = BINARY ?
          WHERE ut.id = ? AND ut.payload IS NOT NULL
            AND JSON_CONTAINS_PATH(ut.payload, 'one', ?) = 1
          FOR UPDATE`,
        [key, templateId, `$."${key}"`],
      );
      let payload = rows.length ? rows[0].payload : null;
      if (typeof payload === 'string') {
        try { payload = JSON.parse(payload); } catch { payload = null; }
      }
      const declaredTypes = rows.map((r) => r.ft).filter((ft) => ft != null);
      const value = payload && typeof payload === 'object' ? payload[key] : undefined;
      if (!declaredTypes.length
        || declaredTypes.some((ft) => valueShapeValidForType(ft, value))) {
        await conn.rollback();
        const e = apiError('Mismatch check stale (field changed, key gone, or value now valid)', 'STALE_MISMATCH', 409);
        return res.status(e.status).json(e.body);
      }
      const mismatchMeta = buildMetadataClearClauses(
        metadataKeySitesPresentIn(await getActualColumnSet(conn, t(TABLES.USER_TEMPLATES))),
        key,
      );
      await conn.query(
        `UPDATE \`${t(TABLES.USER_TEMPLATES)}\` SET payload = JSON_REMOVE(payload, ?)`
        + `${mismatchMeta.sql} WHERE id = ?`,
        [`$."${key}"`, ...mismatchMeta.params, templateId],
      );
      await conn.commit();
      logger.info({ templateId, key }, 'Cleared type-mismatch value from template payload');
      return res.json(apiOk({ template_id: templateId, removed_key: key }));
    } catch (err) {
      try { await conn.rollback(); } catch { /* best effort */ }
      logger.error({ err, templateId, key }, 'Failed to clear type-mismatch value');
      const e = apiError('Database operation failed', 'INTERNAL_ERROR');
      return res.status(e.status).json(e.body);
    } finally {
      conn.release();
    }
  }
  try {
    const conn = await (await resolveOrphanRwPool(req)).getConnection();
    try {
      await conn.beginTransaction();
      // Re-verify blueprint ownership on this same transaction before the
      // JSON_REMOVE. A non-owner editor is 404'd (not 403) so the endpoint does
      // not disclose that the template exists. The ownership SELECT takes a
      // FOR UPDATE lock on the effective-blueprint owner row, so a concurrent
      // owner-transfer cannot slip between this check and the mutation — the
      // clear is transactionally fenced, not a best-effort pre-check.
      if (!(await editorOwnsTemplateBlueprint(conn, req, templateId))) {
        await conn.rollback();
        const e = apiError('Not found', 'NOT_FOUND', 404);
        return res.status(e.status).json(e.body);
      }
      // Re-validate that the key is still orphaned at delete time. Closes
      // the scan-then-delete race: if the field was re-created or renamed
      // back between scanner reporting and admin clicking Delete, the
      // payload data is now valid user data and must NOT be stripped.
      // Subquery: NOT EXISTS (any blueprint_field with field_key = ? in
      // the template's EFFECTIVE blueprint — resolved by the shared
      // expression so a schema-shared template's payload keys are looked up
      // against the linked blueprint's fields, and so this re-check cannot
      // disagree with the scanner that produced the key it is re-checking).
      const orphanMeta = buildMetadataClearClauses(
        metadataKeySitesPresentIn(await getActualColumnSet(conn, t(TABLES.USER_TEMPLATES))),
        key,
        'ut',
      );
      const result = await conn.query(
        `UPDATE \`${t(TABLES.USER_TEMPLATES)}\` ut
            LEFT JOIN \`${t(TABLES.HIERARCHY_NODES)}\` hn ON hn.id = ut.blueprint_id
            SET ut.payload = JSON_REMOVE(ut.payload, ?)${orphanMeta.sql}
          WHERE ut.id = ?
            AND ut.payload IS NOT NULL
            AND JSON_CONTAINS_PATH(ut.payload, 'one', ?) = 1
            AND NOT EXISTS (
              SELECT 1 FROM \`${t(TABLES.BLUEPRINT_FIELDS)}\` bf
               WHERE bf.blueprint_id = ${effectiveBlueprintIdSql('hn', 'ut')}
                 AND bf.field_key = BINARY ?
            )`,
        [`$."${key}"`, ...orphanMeta.params, templateId, `$."${key}"`, key],
      );
      if (result.affectedRows === 0) {
        // Could be: template missing, key already cleaned, OR key is no
        // longer an orphan (re-created since scan). All map to 409 to
        // signal "your scan is stale" rather than 404 "doesn't exist".
        await conn.rollback();
        const e = apiError('Orphan check stale (already cleaned, missing template, or key re-created)', 'STALE_ORPHAN', 409);
        return res.status(e.status).json(e.body);
      }
      await conn.commit();
      logger.info({ templateId, key }, 'Cleaned orphan key from template payload');
      res.json(apiOk({ template_id: templateId, removed_key: key }));
    } catch (err) {
      try { await conn.rollback(); } catch { /* best effort */ }
      throw err;
    } finally {
      conn.release();
    }
  } catch (err) {
    logger.error({ err, templateId, key }, 'Failed to remove orphan key');
    const e = apiError('Database operation failed', 'INTERNAL_ERROR');
    res.status(e.status).json(e.body);
  }
});
}

module.exports = { register, scanFieldDataOrphans, valueShapeValidForType };
