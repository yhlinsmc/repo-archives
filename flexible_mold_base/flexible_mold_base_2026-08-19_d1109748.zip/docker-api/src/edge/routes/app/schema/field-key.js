'use strict';

/**
 * field-key.js — the one shape rule for `blueprint_fields.field_key`, and the
 * one clash probe that keeps two fields of a blueprint from claiming it.
 *
 * WHY THE SHAPE IS A RULE AND NOT A CONVENTION. A field key is not a label: it
 * is the JSON path every record's answers are stored under
 * (`$."<field_key>"`), the identifier the compute-rule graph resolves by exact
 * string, and the token the migration endpoint builds statements from. That
 * endpoint has refused a key outside this shape since it shipped — while the
 * endpoint that WRITES the key had no rule at all, so a key the migration
 * refuses could be stored by the save beside it, and the field's answers could
 * then never be migrated again.
 *
 * WHY THE CLASH PROBE COMPARES THE WAY THE INDEX DOES. Two fields of one
 * blueprint holding the same key are an ambiguous duplicate: the reader
 * resolving an answer finds two fields for one path, and the migration endpoint
 * — aimed at a key a sibling already owns — copies its own field's answer over
 * the sibling's in every record of the blueprint, destroying a value stored
 * nowhere else. The column's collation folds case, so `'ZONE'` and `'zone'` are
 * one key to the index that will enforce this and to any `WHERE field_key = ?`
 * lookup; the probe therefore asks with a plain `=` (the column's own
 * comparison) rather than folding in JavaScript.
 *
 * The probe is the guard on EVERY database. The UNIQUE index is the backstop
 * that closes the window between the probe and the write, and a database whose
 * operator could not create it is exactly the database the probe carries.
 */

const { TABLES, FIELD_KEY_INDEX } = require('../../../../shared/constants');
const { t } = require('../../../db');

/**
 * Mirrors the front end's FIELD_KEY_PATTERN: starts with a lowercase letter,
 * then lowercase letters, digits and underscores only.
 */
const FIELD_KEY_RE = /^[a-z][a-z0-9_]*$/;
const FIELD_KEY_MAX_LEN = 64;

function isValidFieldKey(key) {
  return typeof key === 'string' && key.length <= FIELD_KEY_MAX_LEN && FIELD_KEY_RE.test(key);
}

/**
 * Is the `field_key` this write names outside the shape every reader of it
 * assumes?
 *
 * PRESENCE IS THE ONLY EXEMPTION. A write that does not name the column asks
 * nothing of it, which is what keeps a partial update working. A `null` is NOT
 * exempt: the column is NOT NULL, so a null names the column and asks for a
 * value it cannot hold — refused here as the same stable 400 every other
 * unstorable spelling gets, rather than as the driver error it used to become.
 *
 * @param {object} write the columns this statement will name, and their values
 * @returns {{status: number, code: string, column: string, message: string}|null}
 */
function fieldKeyViolation(write) {
  if (!write || !Object.prototype.hasOwnProperty.call(write, 'field_key')) return null;
  if (isValidFieldKey(write.field_key)) return null;
  return {
    status: 400,
    code: 'INVALID_KEY_FORMAT',
    column: 'field_key',
    message: 'field_key must start with a lowercase letter, contain only lowercase letters, '
      + `digits and underscores, and be at most ${FIELD_KEY_MAX_LEN} characters`,
  };
}

/**
 * Does another field of this blueprint already hold this key?
 *
 * Runs on the CALLER'S connection so it is inside the caller's write
 * transaction: a probe on another connection answers about a state the write
 * does not share. `excludeFieldId` is the row being written, which of course
 * holds its own key.
 *
 * NO ROW TO EXCLUDE IS SPELT BY OMITTING THE CLAUSE, NOT BY BINDING NULL. `id
 * <> NULL` evaluates to UNKNOWN for every row, so a WHERE carrying it matches
 * nothing whatever the table holds — the probe's own default therefore answered
 * "this key is free" about every key in existence, which is the exact opposite
 * of what a fail-closed guard may do. Both callers today pass a real id, so it
 * is dormant; this is the module whose whole purpose is to be the ONE place the
 * rule lives, and a create-path caller taking the default would have got a guard
 * that had already stopped working.
 *
 * @param {object} conn open connection, inside the write transaction
 * @param {string} blueprintId the blueprint the key will live under — the one
 *   the write PRODUCES, not necessarily the one the row currently sits in
 * @param {string} fieldKey
 * @param {string|null} [excludeFieldId] the row being written, when there is
 *   one; `null`/omitted means EXCLUDE NOTHING (a create has no row yet)
 * @returns {Promise<boolean>}
 */
async function fieldKeyTaken(conn, blueprintId, fieldKey, excludeFieldId = null) {
  if (blueprintId == null || fieldKey == null) return false;
  // collation-compare: this is the index's question, asked the index's way. A
  // JavaScript fold here would be a second opinion about what the column calls
  // one key, and the two would disagree the first time the collation changed.
  const excludesARow = excludeFieldId != null;
  const rows = await conn.query(
    `SELECT id FROM \`${t(TABLES.BLUEPRINT_FIELDS)}\`
      WHERE blueprint_id = ? AND field_key = ?${excludesARow ? ' AND id <> ?' : ''} LIMIT 1`,
    excludesARow ? [blueprintId, fieldKey, excludeFieldId] : [blueprintId, fieldKey],
  );
  return rows.length > 0;
}

/** The refusal both endpoints answer with, so an operator reads one sentence. */
const FIELD_KEY_TAKEN = Object.freeze({
  status: 409,
  code: 'DUPLICATE_FIELD_KEY',
  // Says that capitalisation is ignored because an operator looking at a
  // blueprint where no field holds `City` cannot otherwise act on the refusal.
  message: 'Another field in this blueprint already uses this key '
    + '(keys are compared ignoring capitalisation)',
});

/**
 * The refusal for a driver error the FIELD-KEY index raised, or null for
 * anything else.
 *
 * WHY A CALLER NEEDS THIS AND NOT A BARE `errno === 1062` TEST. The two
 * endpoints that WRITE a field key answer 409 for a duplicate the index caught;
 * the IMPORT paths, which insert the same rows from a payload, let it reach
 * their catch-all and report "Import failed" — a 500, which tells an operator
 * their file caused a server fault and invites them to retry something that can
 * never succeed. Refusing is right; the sentence is not.
 *
 * The index is NAMED because this schema carries several unique indexes the same
 * import can violate (section keys, group keys, decision-table names, the
 * variant-override triple), and answering "another field already uses this key"
 * for a duplicate SECTION key is a worse answer than the one it replaces.
 *
 * @param {*} err an error from the driver
 * @returns {{status: number, code: string, message: string}|null}
 */
function duplicateFieldKeyRefusal(err) {
  if (!err || err.errno !== 1062) return null;
  const detail = String((err && (err.sqlMessage || err.message)) || '');
  return detail.includes(FIELD_KEY_INDEX) ? FIELD_KEY_TAKEN : null;
}

module.exports = {
  FIELD_KEY_RE,
  FIELD_KEY_MAX_LEN,
  isValidFieldKey,
  fieldKeyViolation,
  fieldKeyTaken,
  FIELD_KEY_TAKEN,
  duplicateFieldKeyRefusal,
};
