/**
 * decision-doc.js — validation + normalisation for `decision_tables.doc`.
 *
 * Shape (single JSON document per authored table):
 *   {
 *     conditions: [{ field_key }],   // fields whose values select a row
 *     outputs:    [{ field_key }],   // fields the matched row fills in
 *     rows:       [{ when: { field_key: value }, then: { field_key: value } }]
 *   }
 *
 * Values are stored as option VALUES (ids); labels are resolved at render time,
 * so a renamed option label never invalidates a stored row.
 *
 * Why validate here at all: the column is MariaDB `JSON`, which is LONGTEXT
 * with a json_valid() check — it accepts any syntactically valid JSON of up to
 * 4 GB. Every structural guarantee the evaluator relies on (arrays are arrays,
 * a row's `when` only names declared conditions, values are scalars) therefore
 * has to be established at the write boundary or not at all.
 *
 * Deliberately STRICT (unknown keys rejected rather than ignored): a document
 * this small is written exclusively by an authoring UI that knows the shape, so
 * an unexpected key is a bug or an injection attempt, never a forward-compat
 * signal. Extending the shape is a deliberate contract change here.
 */

// The whole document is read and written atomically, so the only thing that
// bounds a decision table's size is this cap. Sized for the authoring reality
// (hundreds of rows x a handful of columns is a few tens of KB) with two orders
// of magnitude of headroom, and far below the 10 MB global JSON body limit so
// the rejection is a deterministic 413 rather than a body-parser error.
const MAX_DECISION_DOC_BYTES = 1024 * 1024;

const DOC_KEYS = ['conditions', 'outputs', 'rows'];
const ROW_KEYS = ['when', 'then'];

function isPlainObject(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value);
}

/** A cell value is a scalar; v1 conditions are scalar select fields only. */
function isScalarCellValue(value) {
  return value === null
    || typeof value === 'string'
    || typeof value === 'number'
    || typeof value === 'boolean';
}

function unknownKeys(obj, allowed) {
  return Object.keys(obj).filter((k) => !allowed.includes(k));
}

/** A fresh empty document. Never share one instance — callers mutate the result. */
function emptyDecisionDoc() {
  return { conditions: [], outputs: [], rows: [] };
}

function invalid(message) {
  return { ok: false, code: 'INVALID_DECISION_DOC', status: 400, message };
}

/**
 * Validate the `field_key` list shared by `conditions` and `outputs`.
 *
 * THE KEY IT JUDGED IS THE KEY IT HANDS BACK. Emptiness was decided on
 * `key.trim()` and the untrimmed spelling was stored, so `' city'` saved, the
 * table reported healthy, and it silently never fired: nothing resolves a
 * blueprint field by that spelling, and this document's keys are matched against
 * `blueprint_fields.field_key` by exact string. Trimming the key the rule already
 * read is what makes the stored document the one that was validated.
 *
 * @returns {{ok: true, keys: string[]}|{ok: false, code: string, status: number, message: string}}
 */
function validateKeyList(list, label) {
  if (!Array.isArray(list)) return invalid(`doc.${label} must be an array`);
  const keys = [];
  const seen = new Set();
  for (let i = 0; i < list.length; i += 1) {
    const entry = list[i];
    if (!isPlainObject(entry)) return invalid(`doc.${label}[${i}] must be an object`);
    const extra = unknownKeys(entry, ['field_key']);
    if (extra.length) {
      return invalid(`doc.${label}[${i}] has unsupported key(s): ${extra.join(', ')}`);
    }
    const raw = entry.field_key;
    if (typeof raw !== 'string' || raw.trim() === '') {
      return invalid(`doc.${label}[${i}].field_key must be a non-empty string`);
    }
    const key = raw.trim();
    // Duplicates are judged on the normalised key, because that is the key the
    // document will hold: 'city' and ' city' are one column after this.
    if (seen.has(key)) return invalid(`doc.${label} lists '${key}' more than once`);
    seen.add(key);
    keys.push(key);
  }
  return { ok: true, keys };
}

/**
 * Validate one side of a row, returning the side with its keys normalised the
 * same way the declaration list normalises them — otherwise a row would name a
 * key the trimmed declaration no longer contains.
 */
function validateRowSide(side, sideName, rowIndex, declared) {
  if (!isPlainObject(side)) {
    return invalid(`doc.rows[${rowIndex}].${sideName} must be an object`);
  }
  // `seen` (not a plain-object accumulator) tracks duplicates: a row is free
  // to name a deleted field (the no-FK philosophy documented on
  // validateDecisionDoc below), so `key` here is caller-supplied and
  // unconstrained, and a Set's key comparison has no special-cased key names.
  const seen = new Set();
  const entries = [];
  for (const [rawKey, value] of Object.entries(side)) {
    const key = typeof rawKey === 'string' ? rawKey.trim() : rawKey;
    if (!declared.has(key)) {
      return invalid(
        `doc.rows[${rowIndex}].${sideName} references '${key}', which this table does not declare`,
      );
    }
    // Two spellings of one key would silently become one cell, and which of the
    // two values survived would depend on iteration order.
    if (seen.has(key)) {
      return invalid(
        `doc.rows[${rowIndex}].${sideName} names '${key}' more than once`,
      );
    }
    seen.add(key);
    if (!isScalarCellValue(value)) {
      return invalid(
        `doc.rows[${rowIndex}].${sideName}.${key} must be a string, number, boolean, or null`,
      );
    }
    entries.push([key, value]);
  }
  // Object.fromEntries defines each pair as an own data property
  // (CreateDataPropertyOrThrow — the same mechanism object-literal spread
  // uses), unlike `out[key] = value` on a plain `{}`, which would route a key
  // of `__proto__` through Object.prototype's legacy setter instead of
  // creating an own property, silently dropping that cell from the document
  // this function reports as valid.
  return { ok: true, side: Object.fromEntries(entries) };
}

/**
 * Validate a decision-table document.
 *
 * INVARIANT (relied on by the evaluation engine): a row only ever names
 * declared condition/output field_keys, and every cell value is a scalar. A
 * field_key may not be BOTH a condition and an output of the same table — that
 * is a self-referential rule whose fill would immediately re-trigger its own
 * match test.
 *
 * NOTE: keys are NOT checked against the blueprint's live field list. A field
 * deleted after authoring is a repair-style flag in the UI, not a write
 * rejection — matching the no-FK philosophy of variant_overrides.
 *
 * RETURNS THE DOCUMENT IT JUDGED. Every `field_key` is trimmed — in the two
 * declaration lists and in every row that names one — and the caller stores what
 * this returns, so the document on disk is the one that was validated rather
 * than a neighbouring spelling of it.
 *
 * @param {unknown} doc
 * @returns {{ok: true, doc: object}|{ok: false, code: string, status: number, message: string}}
 */
function validateDecisionDoc(doc) {
  // A JSON string would sail past every structural check below and land in the
  // column verbatim (mapRowToDb only stringifies non-strings), so it is
  // rejected rather than re-parsed: the client sends an object or nothing.
  if (!isPlainObject(doc)) return invalid('doc must be an object');

  const size = Buffer.byteLength(JSON.stringify(doc), 'utf8');
  if (size > MAX_DECISION_DOC_BYTES) {
    return {
      ok: false,
      code: 'DECISION_DOC_TOO_LARGE',
      status: 413,
      message: `doc is ${size} bytes; the limit is ${MAX_DECISION_DOC_BYTES} bytes`,
    };
  }

  const extra = unknownKeys(doc, DOC_KEYS);
  if (extra.length) return invalid(`doc has unsupported key(s): ${extra.join(', ')}`);

  const conditions = validateKeyList(doc.conditions, 'conditions');
  if (!conditions.ok) return conditions;
  const outputs = validateKeyList(doc.outputs, 'outputs');
  if (!outputs.ok) return outputs;

  const conditionKeys = new Set(conditions.keys);
  for (const key of outputs.keys) {
    if (conditionKeys.has(key)) {
      return invalid(`'${key}' is both a condition and an output; a table cannot feed itself`);
    }
  }
  const outputKeys = new Set(outputs.keys);

  if (!Array.isArray(doc.rows)) return invalid('doc.rows must be an array');
  const rows = [];
  for (let i = 0; i < doc.rows.length; i += 1) {
    const row = doc.rows[i];
    if (!isPlainObject(row)) return invalid(`doc.rows[${i}] must be an object`);
    const rowExtra = unknownKeys(row, ROW_KEYS);
    if (rowExtra.length) {
      return invalid(`doc.rows[${i}] has unsupported key(s): ${rowExtra.join(', ')}`);
    }
    const when = validateRowSide(row.when, 'when', i, conditionKeys);
    if (!when.ok) return when;
    const then = validateRowSide(row.then, 'then', i, outputKeys);
    if (!then.ok) return then;
    rows.push({ when: when.side, then: then.side });
  }

  return {
    ok: true,
    doc: {
      conditions: conditions.keys.map((field_key) => ({ field_key })),
      outputs: outputs.keys.map((field_key) => ({ field_key })),
      rows,
    },
  };
}

/**
 * Read-path coalescing: a row whose `doc` is NULL (created before this route
 * owned the table, or by a write path that skipped it) or whose JSON failed to
 * parse must still reach the client as a well-formed document. NULL carries no
 * meaning for this table — "no rules yet" IS the empty document — so the API
 * boundary never exposes null (SDD §8.3 Y-pattern).
 */
function normalizeDecisionRow(row) {
  if (!row || typeof row !== 'object') return row;
  if (isPlainObject(row.doc)) return row;
  return { ...row, doc: emptyDecisionDoc() };
}

module.exports = {
  MAX_DECISION_DOC_BYTES,
  validateDecisionDoc,
  normalizeDecisionRow,
  emptyDecisionDoc,
};
