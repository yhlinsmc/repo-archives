'use strict';

/**
 * write-value.js — the one derivation of what a statement will write, and the
 * one place that asks whether two spellings are the same STORED value.
 *
 * WHY THIS IS ONE MODULE AND NOT A HABIT PER HANDLER. The defect this path has
 * produced seven times is always the same sentence: a gate read one value while
 * the statement wrote another. Four separate habits produce that divergence —
 * back-fill (`x != null ? x : stored`), falsy fold (`x || null`), body-presence
 * (`hasOwnProperty(body, …)`), and post-gate mutation — and each one lets a
 * gate, a diff, an audit line or a cascade read a different version than the SET
 * clause. There is exactly one answer to "what will this statement write", it is
 * taken from the GATED key list and the body verbatim including `null`, and
 * every consumer reads only it.
 *
 * And the second half, which is a different question wearing the same clothes:
 * "is this the same value" is a question about a COLUMN, and a column answers it
 * under a collation that folds case and pads trailing spaces. Measured
 * (db-semantics-1500.md §Q1): a case-only UPDATE on a `_ci` column reports
 * `Changed: 1` and stores the NEW spelling — the engine does not absorb a
 * respelling. So both directions are live: a JavaScript `!==` can say "changed"
 * when nothing moved, and a JavaScript `===` can say "unchanged" when the write
 * really moves the row.
 */

// The two comparisons a caller can mean. Every call site names one, because
// which is correct is a property of who resolves the value afterwards and no
// mechanical rule can infer it (merged report §3, RC-1: "which way a mismatch
// fails" is the thing no source-level check can see).
//
//   collation — the question is about a COLUMN: an index, a WHERE clause, or
//     "does this name the same row". Ask the engine.
//   byte      — the question is about a value a JAVASCRIPT reader resolves by
//     exact string lookup (a stored `field_key` looked up in a Map, a JSON
//     document path). A fold here would call two different keys one key.
const COMPARISON = Object.freeze({ COLLATION: 'collation', BYTE: 'byte' });

/**
 * What the statement will write, for every column either side names.
 *
 * `gatedKeys` is the list the statement's own SET/INSERT clause is built from
 * (`gateKeysByColumnSet`), NOT the body: a column the operator-mode probe found
 * absent is dropped from the statement, so a body naming it changes nothing and
 * must move no gate. A column the gate kept takes the body's value VERBATIM —
 * including `null`, which names the column and asks for NULL to be written, and
 * is a different act from leaving the column out.
 *
 * A KEY THE GATE KEPT WHOSE VALUE IS `undefined` IS REPORTED AS `null`, because
 * that is what the statement writes: measured against MariaDB 10.11 through the
 * `mariadb` driver, a bound `undefined` stores SQL NULL. The two halves of the
 * write path ask "is this column present" in two different ways — the gates by
 * `data[col] === undefined`, the statement builder by `Object.keys` — so a hook
 * returning `{...data, col: undefined}` is invisible to every gate and still
 * writes the column. This function answers for the statement, not for the gate.
 *
 * @param {string[]} gatedKeys columns the statement will actually name
 * @param {object} data the write body as it stands after the last mutation
 * @param {object} [stored] the row as it stands now (absent on a create)
 * @returns {object} plain object: column → the value the row will hold
 */
function deriveWritten(gatedKeys, data, stored = {}) {
  const gated = new Set(Array.isArray(gatedKeys) ? gatedKeys : []);
  const written = {};
  for (const col of Object.keys(stored || {})) {
    written[col] = stored[col];
  }
  for (const col of gated) {
    const value = data ? data[col] : undefined;
    written[col] = value === undefined ? null : value;
  }
  return written;
}

// Cache the (charset, collation) a column is declared with, keyed by
// schema.table.column. Column metadata is DDL, not data: it changes only when
// an ALTER runs, which this process does not do inside a request. Cold, the
// probe costs two round trips (which database this connection is on, then the
// column's declaration); warm, it costs none.
const columnCollationCache = new Map();

// Which database a connection is on. Keyed by the connection object, because
// this server talks to more than one: `getDynamicPool` builds a pool per
// database, and a cached name shared across them would answer for the wrong
// schema. A pooled connection belongs to one pool for its life, so the answer
// is stable per key. A WeakMap so a released connection is still collectable.
const connectionDatabaseCache = new WeakMap();

async function readDatabaseName(conn) {
  if (connectionDatabaseCache.has(conn)) return connectionDatabaseCache.get(conn);
  const dbRows = await conn.query('SELECT DATABASE() AS db');
  const db = dbRows.length ? dbRows[0].db : null;
  connectionDatabaseCache.set(conn, db);
  return db;
}

async function readColumnCollation(conn, table, column) {
  const db = await readDatabaseName(conn);
  const cacheKey = `${db}.${table}.${column}`;
  if (columnCollationCache.has(cacheKey)) return columnCollationCache.get(cacheKey);
  const rows = await conn.query(
    `SELECT CHARACTER_SET_NAME AS cs, COLLATION_NAME AS co
       FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?`,
    [table, column],
  );
  const row = rows.length ? rows[0] : null;
  // A charset/collation name is interpolated (neither can be a bound
  // parameter), so it is pinned to the identifier shape rather than trusted
  // because it came from information_schema — the same rule every other
  // interpolated identifier in this codebase follows.
  const safe = (v) => (typeof v === 'string' && /^[A-Za-z0-9_]+$/.test(v) ? v : null);
  const answer = row && safe(row.cs) && safe(row.co)
    ? { charset: safe(row.cs), collation: safe(row.co) }
    : null;
  columnCollationCache.set(cacheKey, answer);
  return answer;
}

/**
 * Does the column call these two spellings the same stored value?
 *
 * ASKED OF THE ENGINE, AND ONLY WHEN IT HAS TO BE. Byte-identical values are
 * answered without a query, so the ordinary save adds no round trip; a `null` on
 * one side alone is a move under every collation, so that needs no query either.
 * What is left — two different non-null spellings — is the only case a column's
 * collation can answer differently from JavaScript, and that case asks the
 * database.
 *
 * THE PROBE ASKS THE COLUMN, not a hard-coded `utf8mb4_general_ci`. The server
 * default, the database default and the table's own collation are three
 * different facts that have already disagreed in this deployment's history, and
 * a helper that names one of them is a fourth source of truth. The column's
 * declared charset + collation are read from `information_schema` and the two
 * values are compared inside them.
 *
 * FAIL-SAFE ON A NON-STRING. A number reaching a `CHAR(36)` comparison is the
 * whole of RC-2 — MariaDB compares `char_col = 0` in NUMERIC context and matches
 * an arbitrary set of rows — so a non-string operand is answered `false` (they
 * are NOT the same stored value) rather than handed to the engine. `false` is
 * the safe direction: the callers of this helper use it to decide whether a
 * write MOVES a record, and "it moved" is the answer that keeps a guard running.
 * The write gate refuses such a value before it gets here; this is the second
 * lock on the same door.
 *
 * @param {object} conn open connection (the write connection, so the answer
 *   belongs to the same transaction as the check that uses it)
 * @param {string} table physical table name (already prefixed by `t()`)
 * @param {string} column
 * @param {*} a
 * @param {*} b
 * @returns {Promise<boolean>}
 */
async function sameStoredValue(conn, table, column, a, b) {
  // THE FAIL-SAFE RUNS FIRST, AND THAT ORDER IS THE POINT. An identity check in
  // front of it answers `true` for the one input class the fail-safe exists for:
  // `sameStoredValue(conn, t, 'blueprint_id', 0, 0)` is two numbers reaching a
  // CHAR(36) comparison — the whole of RC-2 — and `true` is the answer that
  // turns a guard OFF. Two equal numbers, two equal booleans and the same object
  // twice all took that route.
  //
  // Both nulls are the exception, and are answered before it: a column holding
  // NULL on both sides has not moved, and every caller means that.
  //
  // LOOSE, AND THAT IS THIS MODULE'S OWN DEFINITION rather than a convenience.
  // `deriveWritten` above answers `null` for a gated key carrying `undefined`,
  // because `undefined` IS the NULL the statement writes. A strict test here
  // would let the module's two halves disagree about the one value they were
  // written to give a single answer for: `undefined` on one side and the NULL it
  // becomes on the other would read as "it moved". Same direction as the
  // fail-safe below for every other input — a non-null against a null is still
  // "it moved" on the very next line.
  if (a == null && b == null) return true;
  if (a == null || b == null) return false;
  if (typeof a !== 'string' || typeof b !== 'string') return false;
  // Only now is byte-identity a safe shortcut: two identical strings are the
  // same stored value under every collation, so the ordinary save issues no
  // query.
  if (a === b) return true;
  const declared = await readColumnCollation(conn, table, column);
  // A column information_schema cannot describe (a lagging physical schema, a
  // probe the account may not read) still gets an ENGINE answer — on the
  // connection's own default rather than the column's. Falling back to a
  // JavaScript comparison here would be the defect this helper exists to end.
  const cast = declared
    ? `CAST(? AS CHAR CHARACTER SET \`${declared.charset}\`) COLLATE \`${declared.collation}\``
    : '?';
  const rows = await conn.query(`SELECT (${cast} <=> ${cast}) AS same`, [a, b]);
  return Number(rows[0] && rows[0].same) === 1;
}

/**
 * The first value in `values` that the column calls the same stored value as an
 * earlier one.
 *
 * THE ANSWER IS A VERDICT, NOT A VALUE, and that is this function's whole
 * contract rather than a style choice. It used to return the offending operand
 * and `null` for "every one of them is distinct" — so a list containing a bare
 * `null` or `undefined` returned exactly the sentinel that means NOTHING IS
 * WRONG, and the caller's `duplicate != null` waved through the one input class
 * the fail-closed loop below was written for. A guard whose refusal and whose
 * all-clear are the same value is not a guard; the two answers are now different
 * shapes and no reader can conflate them.
 *
 * @returns {Promise<{ok: true}|{ok: false, reason: 'duplicate'|'unusable', value: *}>}
 *
 * WHY THIS IS NOT A LOOP OVER `sameStoredValue`. "Are these N values pairwise
 * distinct" asked one pair at a time is O(N²) round trips on the only input that
 * needs asking at all — N spellings that differ byte-for-byte — which turns a
 * guard on an ordinary option list into a stall. The engine can answer the whole
 * question once: cast every candidate into the column's own charset and
 * collation and let it GROUP them. Same authority, same collation, one trip.
 *
 * The byte-identical pass runs first and needs no query, exactly as its
 * single-pair sibling does, so the ordinary save that repeats a value is refused
 * without touching the database.
 *
 * FAIL-CLOSED ON A NON-STRING, and note the direction is the OPPOSITE of
 * `sameStoredValue`'s for the same reason: there, `false` ("it moved") is what
 * keeps a guard running; here the caller refuses a write when this reports a
 * problem, so an operand the column cannot be asked about is itself a refusal.
 * It is reported as `unusable` rather than as a duplicate, because the caller
 * names the value in the sentence it answers with and "this appears twice" is
 * not true of it. Callers validate the list before this point; this is the
 * second lock on the same door.
 *
 * @param {object} conn open connection, so the answer belongs to the same
 *   transaction as the check that uses it
 * @param {string} table physical table name (already prefixed by `t()`)
 * @param {string} column
 * @param {*[]} values
 */
const EVERY_VALUE_DISTINCT = Object.freeze({ ok: true });
const refuseValue = (reason, value) => Object.freeze({ ok: false, reason, value });

async function firstDuplicateStoredValue(conn, table, column, values) {
  const list = Array.isArray(values) ? values : [];
  if (list.length < 2) return EVERY_VALUE_DISTINCT;
  for (const value of list) {
    if (typeof value !== 'string') return refuseValue('unusable', value);
  }
  const seen = new Set();
  for (const value of list) {
    if (seen.has(value)) return refuseValue('duplicate', value);
    seen.add(value);
  }
  const distinct = [...seen];
  if (distinct.length < 2) return EVERY_VALUE_DISTINCT;
  const declared = await readColumnCollation(conn, table, column);
  // A column information_schema cannot describe still gets an ENGINE answer, on
  // the connection's own default rather than the column's — the same fallback
  // and the same reasoning as the single-pair probe above.
  const cast = declared
    ? `CAST(? AS CHAR CHARACTER SET \`${declared.charset}\`) COLLATE \`${declared.collation}\``
    : 'CAST(? AS CHAR)';
  const branches = distinct.map(() => `SELECT ${cast} AS v`).join(' UNION ALL ');
  const dupes = await conn.query(
    `SELECT v FROM (${branches}) candidates GROUP BY v HAVING COUNT(*) > 1 LIMIT 1`,
    distinct,
  );
  return dupes.length ? refuseValue('duplicate', dupes[0].v) : EVERY_VALUE_DISTINCT;
}

/**
 * The canonical `users.id` for a spelling of it — the value a statement may bind.
 *
 * THE HALF THAT IS NOT ABOUT COMPARING. `sameStoredValue` above answers whether
 * a column calls two spellings one value. That is only ever half of an identity
 * fix, and it is the half that hides the other: once the engine has agreed the
 * two spellings name the same row, a statement that goes on to bind the
 * CLIENT's spelling stores the alias. `users.id` is `CHAR(36)` under a
 * case-folding collation, so `WHERE id = ?` resolves the row for any casing,
 * and the guard that proves the user exists therefore proves nothing about the
 * value the UPDATE is about to write.
 *
 * What that produces is not a cosmetic difference. It splits authorization in
 * two, permanently, in one statement:
 *
 *   SQL readers   — `WHERE owner_id = ?`, an EXISTS predicate, a UNIQUE index —
 *                   go on resolving the true owner, because the collation folds
 *                   the difference away;
 *   JS readers    — `row.owner_id === req.user.id`, `ownerId === user.id`, a
 *                   Map lookup, `.find(n => n.id === parentId)` in the front
 *                   end, the `value` of a Select — resolve NOBODY.
 *
 * So the guard passes, the screen says the transfer worked, and the new owner
 * cannot act on their own record while the old ACL still admits them. A helper
 * that only asked the engine "are these the same" would leave every one of
 * those readers exactly as broken. Hence this returns the STORED spelling and
 * the callers bind THAT.
 *
 * THE AMBIGUITY REFUSAL IS DEFENSIVE, AND SAYING SO IS THE POINT. `users.id` is
 * a PRIMARY KEY on a case-folding collation, so two rows differing only in case
 * cannot both exist and this branch is unreachable through that column today.
 * It is here because the reference implementation this is modelled on
 * (`internal/public-write.js`, resolving an owner by `kc_username`) resolves
 * through a column with no such key, where the branch is live — and because the
 * failure it prevents is picking `rows[0]` out of a set nobody ordered. A
 * refusal costs an administrator one error message; guessing costs the wrong
 * person a record.
 *
 * FAIL-CLOSED ON A NON-STRING, and before the query rather than after it: a
 * number bound to a `CHAR(36)` comparison is evaluated in NUMERIC context and
 * matches an arbitrary set of rows, so `resolveCanonicalUserId(conn, u, 0)`
 * asked of the engine could return a real user. The shape floor is the caller's
 * job and every caller has one; this is the second lock on that door.
 *
 * A BANNED ACCOUNT IS NOT A VALID TARGET, and that belongs here rather than at
 * the five routes that ask. Every caller of this function is about to make
 * somebody the OWNER of a record, and every one of them wants the same answer:
 * an account that cannot authenticate cannot act on what it owns, so handing it
 * a record makes that record unreachable to everyone — the ban's own audit path
 * (`identity-resolve`) refuses the login, and no route lets the ex-owner take it
 * back. Blast radius was limited before this only because a banned account
 * cannot sign in; the record still ends up stranded.
 *
 * It is reported as its own reason rather than as `not_found`, because the two
 * are different facts and a caller telling an administrator "no such user"
 * about an account they can see in the user list is the kind of answer that
 * costs an afternoon.
 *
 * @param {object} conn open connection — the WRITE connection, so the id
 *   belongs to the same transaction as the statement that binds it
 * @param {string} usersTable physical table name (already prefixed by `t()`)
 * @param {*} id the spelling the client asked for
 * @returns {Promise<{ok: true, id: string, role: string|null}
 *   |{ok: false, reason: 'unusable'|'not_found'|'ambiguous'|'banned'}>}
 */
const refuseUser = (reason) => Object.freeze({ ok: false, reason });

async function resolveCanonicalUserId(conn, usersTable, id) {
  if (typeof id !== 'string' || id.length === 0) return refuseUser('unusable');
  const rows = await conn.query(
    `SELECT id, role, banned FROM \`${usersTable}\` WHERE id = ?`,
    [id],
  );
  if (rows.length === 0) return refuseUser('not_found');
  if (rows.length > 1) return refuseUser('ambiguous');
  // The driver hands a BOOLEAN back as 1/0, and a column an older schema does
  // not carry as undefined — so the test is for a TRUTHY ban rather than for a
  // literal `true`, and an unknown answer is "not banned" (the column is in the
  // base `users` DDL, not an additive one, so unknown means a schema this code
  // does not run against).
  if (rows[0].banned) return refuseUser('banned');
  return Object.freeze({ ok: true, id: rows[0].id, role: rows[0].role ?? null });
}

/**
 * The rejection a route answers a failed `resolveCanonicalUserId` with — one
 * mapping, because five routes ask the same question and an administrator
 * should not get a different sentence depending on which record they are
 * transferring.
 *
 * @param {'unusable'|'not_found'|'ambiguous'|'banned'} reason
 * @returns {{message: string, code: string, status: number}}
 */
function ownerTargetRejection(reason) {
  if (reason === 'ambiguous') {
    return { message: 'Target user is ambiguous', code: 'CONFLICT', status: 409 };
  }
  if (reason === 'banned') {
    return {
      message: 'Target user is banned and cannot own a record',
      code: 'BAD_REQUEST',
      status: 400,
    };
  }
  return { message: 'Target user not found', code: 'BAD_REQUEST', status: 400 };
}

// Exported for tests only: a cached collation must not survive a fixture that
// rebuilds the schema under the same database name.
function _clearColumnCollationCache() {
  columnCollationCache.clear();
}

module.exports = {
  COMPARISON,
  deriveWritten,
  sameStoredValue,
  firstDuplicateStoredValue,
  resolveCanonicalUserId,
  ownerTargetRejection,
  _clearColumnCollationCache,
};
