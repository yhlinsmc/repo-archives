const express = require('express');
const router = express.Router();

const { createCrudRoutes } = require('./crud-factory');
const {
  TABLES,
  validateAndPrepareParentOwnership,
  validateAndPrepareParentRepend,
  buildChainSelectSql,
  buildChainExistsForRow,
  validateLinkConstraints,
  isBlueprintLinked,
  isBlueprintLinkedLocked,
  isLinkedParentLocked,
  resolveLinkCheckBlueprintId,
  HIERARCHY_NON_UUID_CHAR_COLUMNS,
  _columnSetCache,
} = require('./helpers');
const fieldOps = require('./routes-field-ops');
const replace = require('./routes-replace');
const fieldOptions = require('./routes-field-options');
const groupSectionMaint = require('./routes-group-section-maint');
const hierarchy = require('./routes-hierarchy');
const blueprintFields = require('./routes-blueprint-fields');
const { isPayloadInconsistent, validateComputeRuleBeforeWrite } = blueprintFields;
const { FIELD_TYPES } = require('./field-type-domain');
const { fieldKeyViolation } = require('./field-key');
const variantOverrides = require('./routes-variant-overrides');
const { extractComputeSources } = variantOverrides;
const hiddenFieldDisclosure = require('./routes-hidden-field-disclosure');
const orphans = require('./routes-orphans');
const { scanFieldDataOrphans, valueShapeValidForType } = orphans;
const { enumMembersFor } = require('../../../lib/schema-manifest');
const { validateDecisionDoc, normalizeDecisionRow, emptyDecisionDoc } = require('./decision-doc');
const { refuseDuplicateDecisionOutput } = require('./decision-output-claims');
const {
  validateUserTemplateMetadata,
  normalizeUserTemplateMetadataRow,
} = require('../../../lib/user-template-metadata');

// Route registration order is behavior: Express matches in registration order,
// so the exact-path custom routes below are registered BEFORE the generic CRUD
// mounts on the same base path. Preserving this order keeps the route table
// byte-identical to the pre-split flat module.
fieldOps.register(router);
replace.register(router);
fieldOptions.register(router);
groupSectionMaint.register(router);
hierarchy.register(router);
blueprintFields.register(router);
// Exact path, registered with the other custom routes so it is matched before
// the generic CRUD mounts below.
hiddenFieldDisclosure.register(router);


router.use('/hierarchy_nodes', createCrudRoutes('hierarchy_nodes', {
  filterableColumns: ['parent_id', 'node_type', 'is_active', 'owner_id'],
  allowedRoles: ['admin', 'editor'],
  valueGuards: {
    // 'generation' is the legacy top-tier literal; it is retained in the
    // blocklist so an editor cannot create a top-tier node on a DB still in the
    // transition (un-narrowed ENUM) state via generic CRUD. Inert once the
    // CONTRACT migration narrows the ENUM (the value is then never submitted).
    node_type: { rejectFor: { editor: ['generation', 'category', 'release'] } },
  },
  // The domain the blocklist above is judged against — REQUIRED by the factory
  // for any rejectFor column, because a blocklist compared in JavaScript cannot
  // see a value this column folds into one of its entries ('Category', 1, and
  // the rest of that family).
  //
  // READ FROM table-ddls.js RATHER THAN LISTED HERE. The four members restated
  // at this mount would be a second source of truth for the column's shape, and
  // the first narrowing or widening of the ENUM would leave it wrong in silence
  // — refusing a member the column accepts, or admitting one it no longer has.
  // The DDL is the schema's single source of truth, so the gate asks it.
  enumColumns: { node_type: enumMembersFor(TABLES.HIERARCHY_NODES, 'node_type') },
  // A DECLARED EXCEPTION TO THE REQUIRED-ON-CREATE RULE, because this column
  // already has an owner. The factory otherwise requires a create to name any
  // NOT NULL ENUM the engine would fill from declaration order — here 'category',
  // the top tier. The value guard on this mount already refuses an EDITOR that
  // tier whether they name it, spell it differently, or leave the column out
  // (hierarchy-node-type-omission-real-db.test.js), and an administrator
  // creating a top-tier node by omission is the ordinary way the Hierarchy
  // Manager seeds one. Stated here rather than inferred, so the asymmetry is a
  // decision on the page instead of a rule that quietly does not apply.
  enumOptionalOnCreate: ['node_type'],
  // parent_id is mutable only through POST /hierarchy_nodes/:id/reparent, which
  // runs the cycle guard + user_templates ancestor re-stamp + audit. The generic
  // PUT must never rewrite it (would leave denormalized template columns stale).
  // owner_id joins it for the reason stated at the connectors mount: an
  // administrator's generic PUT was a second door to a transfer, with no target
  // check, no cascade to the variants that inherit the owner, and no audit line.
  // PATCH /hierarchy_nodes/:id/owner does all three and is now the only route.
  immutableColumns: ['parent_id', 'owner_id'],
  // Blueprint-level rows owned by creator (editor) or NULL = shared
  // (admin-prebuilt). Only admin may PATCH owner_id (transfer endpoint).
  ownerColumn: 'owner_id',
  // NOTE: variants inherit owner_id from their parent blueprint so an
  // admin-created variant under a shared blueprint stays shared.
  inheritOwnerFromParent: { whenNodeType: 'variant', via: 'parent_id', parentNodeType: 'blueprint' },
  // SECURITY: resolve owner_id → owner_name server-side so the Hierarchy
  // Manager tooltip shows a human name instead of a UUID slice. requireAuth
  // (not requireAdmin) — the value exposed is the display name of an owner
  // whose row the caller can already see. Bounded to ids in the result set;
  // never reads email.
  resolveOwnerName: 'owner_id',
  // transformer_id NAMES A TRANSFORMER, AND ONLY ONE KIND OF TRANSFORMER IS A ROW.
  // The registry this column selects from has two halves (transformer-db-registry.ts
  // `mergeRegistries`): a DB transformer is a `transformers` row and its entry
  // carries that row's uuid, but a FILE transformer is code compiled into the
  // bundle and its entry is the key its module passed to `registerTransformer()`
  // — an author-chosen short string that doubles as the display name
  // (`TRANSFORMERS.md`: "ID: Must match the transformer_id configured on the
  // hierarchy node"). The picker offers both, labelled [File] and [DB], and
  // sends the key verbatim.
  //
  // So the identifier floor's premise does not hold for this column: the value
  // is not a row id, nothing in this factory resolves a row with it (the only
  // readers — the XOR guard in routes-blueprint-fields.js and the front-end
  // registry lookup — compare it as a value), and enforcing the uuid shape here
  // refuses the whole file-transformer feature. It refuses more than the create:
  // the hierarchy dialog seeds its form from the stored row and sends the field
  // on every save, so a node already bound to a file transformer could not be
  // renamed either.
  //
  // The file half of the registry lives partly in a gitignored directory, which
  // is why no grep of tracked server code found this writer; the declared
  // inventory in tests/unit/char36-identifier-inventory.test.js is where that
  // question is now asked per column rather than per search.
  //
  // Declared in helpers.js and read here, because the link routes registered
  // ahead of this mount apply the same floor to the same columns and the two
  // must not be able to disagree about which of them is exempt.
  nonUuidCharColumns: HIERARCHY_NON_UUID_CHAR_COLUMNS,
}));


// Child tables with a direct FK to a Blueprint hierarchy_node carry
// `parentOwnership` so editor's POST/PUT/DELETE must target a parent they
// own (or that's shared). The custom PUT for blueprint_fields/:id does this
// check itself; the factory's POST + DELETE pick up the same contract here.
router.use('/blueprint_fields', createCrudRoutes('blueprint_fields', {
  // The custom PUT /:id handler validates edits; this guards the generic CREATE
  // path (factory PUT is shadowed by the custom handler) so a direct POST can't
  // persist a type-inconsistent or malformed-choice_config field.
  serializeWrite: (data) => {
    const consistency = isPayloadInconsistent(data.field_type, data);
    if (!consistency.ok) {
      throw Object.assign(new Error(consistency.detail), { code: consistency.code });
    }
    // The same shape rule the custom PUT and the key-migration endpoint apply,
    // from the same module: a key outside it cannot be migrated afterwards,
    // because every statement that moves a record's answers builds a JSON path
    // out of it. `slugColumns` is the factory's own spelling of a rule like this
    // one, but it bounds a key at 255 characters while a field key is bounded at
    // 64 — one column, one rule, so it is this one.
    const keyIssue = fieldKeyViolation(data);
    if (keyIssue) {
      throw Object.assign(new Error(keyIssue.message), {
        code: keyIssue.code, status: keyIssue.status,
      });
    }
    return data;
  },
  // Two fields of one blueprint holding one key are the ambiguous duplicate the
  // migration endpoint turns into a merge. Guarded at write time in the write
  // transaction, exactly as the sibling design-time child tables guard theirs —
  // the complement to the DB UNIQUE index, which only exists on databases where
  // the ALTER could run.
  uniqueWithin: { scope: 'blueprint_id', key: 'field_key', code: 'DUPLICATE_FIELD_KEY' },
  filterableColumns: ['blueprint_id'],
  allowedRoles: ['admin', 'editor'],
  // The declared domain of the column three destructive statements compare
  // against a literal (the custom PUT's type-change block). Declared in
  // field-type-domain.js rather than restated here, and rather than read from
  // the DDL like the sibling mounts' enumColumns — the column is a VARCHAR, not
  // an ENUM, and converting it is a destructive change on a live column that the
  // app-layer domain closes without. The custom PUT reads the same module, so
  // the two verbs cannot come to different conclusions about what a field type
  // is.
  enumColumns: { field_type: FIELD_TYPES },
  // The semantic half of compute_rule validation (op / operands / sources /
  // dependency cycles) needs the blueprint's other fields to judge, so it runs
  // on a connection inside the write transaction — serializeWrite above has
  // neither. Without it the generic create is a way past every rule guard the
  // custom PUT applies.
  preWriteInTx: validateComputeRuleBeforeWrite,
  parentOwnership: {
    via: 'blueprint_id',
    chain: [{ table: TABLES.HIERARCHY_NODES, match: 'id', readOwner: 'owner_id' }],
  },
  // S1/S2: factory POST/DELETE rejected on a linked blueprint (custom PUT
  // above does its own check).
  rejectIfParentLinked: { column: 'blueprint_id' },
  // Zero-FK cascade substitute for the generic DELETE /:id path (the sanctioned
  // UI delete is POST /delete-renormalize, but the factory DELETE is still
  // exposed): removing a field also removes its options + any variant overrides
  // on it, in one transaction, so neither is orphaned.
  dependentCleanup: [
    { table: TABLES.FIELD_OPTIONS, fk: 'field_id' },
    { table: TABLES.VARIANT_OVERRIDES, fk: 'field_id' },
  ],
}));


// field_options + variant_overrides are open to editor via two-hop chain.
// field_options walks field_id → blueprint_fields →
// hierarchy_nodes(blueprint).owner_id. variant_overrides walks
// variant_id → hierarchy_nodes(variant) → parent_id →
// hierarchy_nodes(blueprint).owner_id (self-join, positional aliases).
router.use('/field_options', createCrudRoutes('field_options', {
  filterableColumns: ['field_id'],
  allowedRoles: ['admin', 'editor'],
  // option_label/option_value can never persist empty/whitespace from the
  // generic CRUD write path (present-only gate; partial PUTs unaffected).
  trimmedNonEmptyColumns: ['option_label', 'option_value'],
  parentOwnership: {
    via: 'field_id',
    chain: [
      { table: TABLES.BLUEPRINT_FIELDS, match: 'id' },
      { table: TABLES.HIERARCHY_NODES, from: 'blueprint_id', match: 'id', readOwner: 'owner_id' },
    ],
  },
  // S1/S2: one-hop lookup field_id → blueprint_fields.blueprint_id.
  rejectIfParentLinked: {
    fk: 'field_id', lookupTable: TABLES.BLUEPRINT_FIELDS,
    lookupIdCol: 'id', blueprintCol: 'blueprint_id',
  },
}));

variantOverrides.register(router);


router.use('/variant_overrides', createCrudRoutes('variant_overrides', {
  filterableColumns: ['variant_id'],
  allowedRoles: ['admin', 'editor'],
  // DELETE walks variant_id → hierarchy_nodes(variant) → parent_id →
  // hierarchy_nodes(blueprint).owner_id (2-hop self-join). Admin bypasses
  // automatically inside the factory. POST + PUT are intercepted above.
  parentOwnership: {
    via: 'variant_id',
    chain: [
      { table: TABLES.HIERARCHY_NODES, match: 'id' },
      { table: TABLES.HIERARCHY_NODES, from: 'parent_id', match: 'id', readOwner: 'owner_id' },
    ],
  },
}));


router.use('/blueprint_sections', createCrudRoutes('blueprint_sections', {
  filterableColumns: ['blueprint_id'],
  allowedRoles: ['admin', 'editor'],
  parentOwnership: {
    via: 'blueprint_id',
    chain: [{ table: TABLES.HIERARCHY_NODES, match: 'id', readOwner: 'owner_id' }],
  },
  rejectIfParentLinked: { column: 'blueprint_id' },
  // section_key must match the identity-key slug shape the Schema Builder
  // enforces client-side. matrix_copy is a free-form VARCHAR read fail-open at
  // render time ('disabled' hides copy; anything else shows it) — gate it at
  // write time to the known set so a typo cannot silently persist. NULL is
  // accepted (unset = default-on). Read semantics are unchanged.
  slugColumns: ['section_key'],
  enumColumns: { matrix_copy: ['', 'enabled', 'disabled'] },
  // Uniqueness within a blueprint is guarded at write time (the complement to
  // the DB UNIQUE index uq_blueprint_section_key, which is absent on no-ALTER
  // DBs) so the generic CRUD create can no longer insert a second row with a
  // section_key that already exists for the blueprint (only
  // /blueprint_sections/replace deduped before).
  uniqueWithin: { scope: 'blueprint_id', key: 'section_key', code: 'DUPLICATE_SECTION_KEY' },
}));


router.use('/blueprint_groups', createCrudRoutes('blueprint_groups', {
  filterableColumns: ['blueprint_id'],
  allowedRoles: ['admin', 'editor'],
  parentOwnership: {
    via: 'blueprint_id',
    chain: [{ table: TABLES.HIERARCHY_NODES, match: 'id', readOwner: 'owner_id' }],
  },
  rejectIfParentLinked: { column: 'blueprint_id' },
  // blueprint_groups is an additive engine table; on an operator install whose
  // boot migration warn-skipped the create, opening Schema Builder must degrade
  // to "no groups" rather than 500 on the list SELECT.
  tolerateMissingTableOnList: true,
  // group_key must match the identity-key slug shape the Schema Builder enforces
  // client-side. Uniqueness within a blueprint is guarded at write time (the
  // complement to the DB UNIQUE index, which is absent on no-ALTER DBs) so the
  // generic CRUD create can no longer insert a second row with a group_key that
  // already exists for the blueprint (only /blueprint_groups/replace deduped
  // before).
  slugColumns: ['group_key'],
  uniqueWithin: { scope: 'blueprint_id', key: 'group_key', code: 'DUPLICATE_GROUP_KEY' },
  // group_key is renamable only through the rename-with-cascade endpoint above,
  // which atomically fixes up the blueprint_fields rows that reference it by
  // string (group_key + matrix_row_key). The generic PUT has no such cascade, so
  // a key change through it would silently orphan those fields — strip group_key
  // from every generic PUT body so the key can ONLY move via the cascade path.
  immutableColumns: ['group_key'],
}));


router.use('/blueprint_output_order', createCrudRoutes('blueprint_output_order', {
  filterableColumns: ['blueprint_id'],
  allowedRoles: ['admin', 'editor'],
  parentOwnership: {
    via: 'blueprint_id',
    chain: [{ table: TABLES.HIERARCHY_NODES, match: 'id', readOwner: 'owner_id' }],
  },
  // S1/S2: factory row-level POST/PUT/DELETE rejected on a linked blueprint
  // (the custom /replace endpoint above does its own check).
  rejectIfParentLinked: { column: 'blueprint_id' },
  // fmb-1723 (spec §5 C2 / Q7): the per-output table-format declaration.
  // Written through this generic PUT (the optimistic-lock /replace endpoint
  // above only ever touches sort_order); enumColumns rejects anything but
  // the two legal values with a stable 400 instead of storing a typo.
  enumColumns: { format: ['json', 'table'] },
}));


// Shared multi-condition lookup tables, authored per blueprint. Same
// blueprint-scoped ownership + linked-blueprint contract as the other
// design-time child tables above (sections / groups / output_order): an editor
// may write only under a blueprint they own or that is shared, and a blueprint
// whose schema is borrowed from a source is read-only here.
router.use('/decision_tables', createCrudRoutes('decision_tables', {
  filterableColumns: ['blueprint_id'],
  allowedRoles: ['admin', 'editor'],
  // A nameless table is unidentifiable in the authoring list, and the DDL
  // column is NOT NULL — reject the empty write instead of surfacing a driver
  // error. Required on create, validated when present on update.
  trimmedNonEmptyColumns: ['name'],
  // The name is the only handle a human has on a table — the authoring
  // chooser, and the field editor's link affordance, identify one by nothing
  // else. The authoring UI refuses a duplicate, but a second tab, a retry after
  // a timeout, or any non-UI client would otherwise create one; the same guard
  // the sibling design-time child tables use closes that. Blueprint-scoped, in
  // the write transaction, so the check and the insert cannot be interleaved.
  uniqueWithin: { scope: 'blueprint_id', key: 'name', code: 'DUPLICATE_DECISION_TABLE_NAME' },
  parentOwnership: {
    via: 'blueprint_id',
    chain: [{ table: TABLES.HIERARCHY_NODES, match: 'id', readOwner: 'owner_id' }],
  },
  rejectIfParentLinked: { column: 'blueprint_id' },
  // Additive engine table: on an install whose boot migration warn-skipped the
  // CREATE (no DDL privilege), listing must degrade to "none authored" rather
  // than 500 the authoring panel.
  tolerateMissingTableOnList: true,
  // SECURITY/INTEGRITY: the column type (MariaDB JSON == LONGTEXT) enforces
  // nothing but json_valid(), so this is the only bound on document size and
  // the only guarantee of the shape the evaluator reads. Runs after the write
  // gate and before any DB work.
  serializeWrite: (data, ctx) => {
    if (data.doc === undefined) {
      // A create with no document starts as a well-formed empty one, so every
      // row this route produces satisfies the read contract; a partial update
      // that omits `doc` leaves the stored document untouched.
      if (!ctx.isUpdate) return { ...data, doc: emptyDecisionDoc() };
      return data;
    }
    const verdict = validateDecisionDoc(data.doc);
    if (!verdict.ok) {
      throw Object.assign(new Error(verdict.message), {
        code: verdict.code,
        status: verdict.status,
      });
    }
    // The document that gets stored is the one that was judged: the validator
    // trims every field_key it reads, and a key it trimmed to decide but did not
    // hand back would leave a document whose keys resolve to no field anywhere.
    return { ...data, doc: verdict.doc };
  },
  serializeRead: normalizeDecisionRow,
  // fmb-1386: the UI has always refused a second table claiming an output field
  // and the API never did. In the write transaction, under FOR UPDATE on the
  // blueprint's other tables, so a concurrent claim cannot slip between the
  // check and the insert. Both carve-outs live in the hook.
  preWriteInTx: refuseDuplicateDecisionOutput,
}));


router.use('/user_templates', createCrudRoutes('user_templates', {
  // `is_draft` is filterable so the frontend can request `?is_draft=1`
  // for Drafts and `?is_draft=0` for Saved templates. `blueprint_id` is
  // filterable so a caller (e.g. the flow Recipe Builder's preview-sample
  // picker) can scope templates to one blueprint instead of listing all.
  filterableColumns: ['id', 'owner_id', 'is_draft', 'blueprint_id'],
  // No userScopeColumn: every authenticated role lists all templates so
  // users can find and clone each other's work. requireAuth on GET still
  // applies; row contents stay read-only for non-owners via the frontend
  // and the writeScopeColumn guard below.
  // writeScopeColumn: non-admin writes are scoped to owner_id, and the
  // owner_id on the write body is ignored for non-admins and overridden
  // to req.user.id server-side, so a user cannot create or modify a row
  // owned by someone else (PUT/DELETE of a foreign row returns 404).
  writeScopeColumn: 'owner_id',
  // The fourth ownership-transfer door, and the one the sweep that closed the
  // other three walked past. `writeScopeColumn` is stripped from a PUT body only
  // for a NON-admin role, so an administrator's generic PUT carrying `owner_id`
  // wrote it straight into the column — with none of what PATCH
  // /user_templates/:id/owner does: no check that the target user exists, no
  // canonical id (so a non-canonical spelling was bound verbatim), and no
  // `feature_audit` row. It accepted a value that was not a user id at all.
  // That PATCH is open to the administrator AND to the record's own owner, so
  // making the column immutable here removes a second door rather than a
  // capability.
  immutableColumns: ['owner_id'],
  // Delegated access widens the UPDATE above from "the owner" to "the owner,
  // someone they delegated to, or the owner of the blueprint the record belongs
  // to". The rule, and everything it deliberately does NOT convey — including
  // that no arm of it reaches a record nobody owns — is in
  // `edge/lib/delegated-grants.js`. Three properties this line does not change,
  // stated because each was a decision:
  //   - a foreign row with no grant still answers 404, not 403. The 404 is what
  //     keeps an id from confirming a record exists, and delegation is not a
  //     reason to start leaking that.
  //   - DELETE is untouched. A grant conveys changing the answers and
  //     dispatching them; removing the record is neither.
  //   - owner_id is still stripped from every non-admin PUT body, so a grantee
  //     editing a record cannot become its owner.
  delegatedTemplateWrite: true,
  // The record's flow cache — what the last dispatch produced, and the marker
  // that says the record has been pushed at all — is written by the run
  // lifecycle and cleared by its own endpoint, which carries the boundary and
  // writes the audit row. Through the generic PUT it was writable by anyone the
  // update let through, with no audit and no boundary of its own: clearing the
  // run marker turns the OWNER's next dispatch into a create, and a dispatch
  // cannot be taken back.
  //
  // SERVER-OWNED, NOT MERELY IMMUTABLE. "Immutable" is an update-only rule, and
  // this option's own comment used to claim "immutable for every role" while the
  // CREATE path had no strip at all — measured live, a plain user POSTed a
  // record already carrying a `flow_last_run_id` and a `flow_link` of their
  // choosing, and only the PUT of the same two values was stripped. A run marker
  // a caller chose is the same lie about the same record, arrived at through the
  // verb nobody guarded.
  serverOnlyColumns: ['flow_external_id', 'flow_link', 'flow_last_run_id'],
  // A successful edit records who made it on the record's own trail. Separate
  // from the line above because they are separate decisions: one is who may
  // write, the other is what is remembered about a write that happened.
  templateActivityTrail: true,
  // SECURITY: resolve owner_id → owner_name server-side under requireAuth so
  // non-admin (editor/user) see the owner's display name, not a raw UUID.
  // Bounded to the result set; name only (no email).
  resolveOwnerName: 'owner_id',
  // The three field-key-indexed metadata documents are assembled in the browser
  // and, until this guard, bounded only by the 10 MB body limit — while the
  // columns that hold them are TEXT (65,535 bytes). Crossing that either
  // truncates the document or raises 1406 depending on sql_mode, and the
  // operator is told neither. Refused here rather than dropped silently: these
  // documents are the record of choices the operator made ON PURPOSE, so a
  // write that cannot keep them must not report success. Runs before
  // mapRowToDb, on the still-parsed objects.
  serializeWrite: (data) => {
    const verdict = validateUserTemplateMetadata(data);
    if (!verdict.ok) {
      throw Object.assign(new Error(verdict.message), {
        code: verdict.code,
        status: verdict.status,
      });
    }
    return data;
  },
  // The read half of the same contract: a document stored before the guard
  // existed can be truncated, which the DTO mapper hands back as raw text. The
  // clone path echoes what it was given, so without this the boundary would
  // feed a document back that the boundary itself refuses.
  serializeRead: normalizeUserTemplateMetadataRow,
}));

orphans.register(router);

module.exports = router;
// Exported so a separate mount (api_connectors, under its own /edge/app path)
// can build a CRUD router with the same battle-tested owner/role/filter/
// operator-gating logic instead of duplicating it.
module.exports.createCrudRoutes = createCrudRoutes;
// Exported for unit tests only. Not part of the public route API.
module.exports.__test__ = {
  validateAndPrepareParentOwnership,
  validateAndPrepareParentRepend,
  buildChainSelectSql,
  buildChainExistsForRow,
  scanFieldDataOrphans,
  valueShapeValidForType,
  __clearColumnSetCache: () => _columnSetCache.clear(),
  extractComputeSources,
  validateLinkConstraints,
  isBlueprintLinked,
  isBlueprintLinkedLocked,
  isLinkedParentLocked,
  resolveLinkCheckBlueprintId,
};
