/**
 * list-query.js — the shared CRUD list read (GET /) and its opt-in pagination.
 *
 * Lifted out of crud-factory.js rather than added to it: that file already
 * carries a file-size pragma, so the pagination work is an extraction, not an
 * append. The handler body below is the list handler as it stood before
 * pagination existed, with the filter/scope/sort construction untouched.
 *
 * Pagination contract
 * -------------------
 * `?offset=` is the switch. Without it the statement, the bind parameters and
 * the response envelope are exactly what they were before this module existed:
 * one SELECT, no bound page, `data` a bare array. With it:
 *
 *   - `limit` is required (MariaDB has no OFFSET without LIMIT) and is bounded
 *     by MAX_PAGE_SIZE. A page size above the ceiling is refused rather than
 *     quietly clamped: a caller that asked for 5000 and silently received 500
 *     would read a short page as "the end of the data".
 *   - `offset` must be a non-negative integer; it is validated before it can
 *     reach the driver.
 *   - the ORDER BY gains the primary key as a tiebreaker, because a page is a
 *     window over an ordering and none of the sortable columns is unique. See
 *     the comment at the paginated branch.
 *   - the response becomes `{ rows, total, limit, offset }`, matching the shape
 *     the platform's other paged reads already return (feature-audit,
 *     privileges audit).
 *
 * SECURITY: the total is counted with the SAME WHERE clause and the SAME bind
 * parameters as the row query — including the non-admin user-scope predicate —
 * so a count can never report rows the caller is not allowed to read. The two
 * statements are built from one `whereSql`/`whereParams` pair for that reason;
 * a second, independently-assembled predicate would be a leak waiting to
 * happen.
 */
const {
  t,
  apiOk,
  apiError,
  requireAuth,
  isSafeColumnName,
  logger,
} = require('./helpers');

// The largest page a caller may request. 500 matches the ceiling the platform's
// existing paged reads use (privileges audit, feature audit).
const MAX_PAGE_SIZE = 500;

// A non-negative decimal integer in canonical form: no sign, no fraction, no
// whitespace, and no leading zero except the single digit `0`.
//
// Number() alone would accept ' 1 ', '1e3', '0x10' and '1.0'. `^\d+$` closes
// those but still admits '01' and '000', which are the same page spelled two
// ways — and the rest of this validator already refuses '1.0' and '1e3' for
// exactly that reason, so admitting '01' would be arbitrary. One spelling per
// page also keeps anything that keys off the query string (a cache, a log
// aggregation, a test fixture) from seeing two.
const NON_NEGATIVE_INT = /^(?:0|[1-9]\d*)$/;

/**
 * Read the pagination parameters off a query string.
 *
 * @returns {{paginated: false}}
 *        | {{paginated: true, limit: number, offset: number}}
 *        | {{error: {message: string, code: string}}}
 */
function parsePageRequest(query) {
  const rawOffset = query ? query.offset : undefined;
  if (rawOffset === undefined) return { paginated: false };

  const invalid = (message) => ({ error: { message, code: 'INVALID_PAGINATION' } });

  // Express's query parser yields an array for a repeated key and an object for
  // a bracketed one; neither is a page position.
  if (typeof rawOffset !== 'string' || !NON_NEGATIVE_INT.test(rawOffset)) {
    return invalid('offset must be a non-negative integer');
  }
  const offset = Number(rawOffset);
  if (!Number.isSafeInteger(offset)) return invalid('offset is out of range');

  const rawLimit = query.limit;
  if (rawLimit === undefined) {
    return invalid('limit is required when offset is supplied');
  }
  if (typeof rawLimit !== 'string' || !NON_NEGATIVE_INT.test(rawLimit)) {
    return invalid('limit must be a positive integer');
  }
  const limit = Number(rawLimit);
  if (limit < 1) return invalid('limit must be a positive integer');
  if (limit > MAX_PAGE_SIZE) {
    return invalid(`limit must not exceed ${MAX_PAGE_SIZE}`);
  }

  return { paginated: true, limit, offset };
}

/**
 * Build the GET / list handler for one CRUD mount.
 *
 * @param {object} ctx
 * @param {string} ctx.logicalName        logical table name (never a literal prefix)
 * @param {Set<string>|null} ctx.filterCols
 * @param {string|null} ctx.userScopeColumn
 * @param {boolean} ctx.tolerateMissingTableOnList
 * @param {(req: object) => Promise<object>} ctx.resolveRoPool
 * @param {(rows: object[]) => object[]} ctx.parseRows
 * @param {(conn: object, rows: object[]) => Promise<unknown>} ctx.attachOwnerNames
 * @param {(rows: object[]) => object[]} ctx.applyReadSerializer
 */
function buildListHandler(ctx) {
  const {
    logicalName,
    filterCols,
    userScopeColumn,
    tolerateMissingTableOnList,
    resolveRoPool,
    parseRows,
    attachOwnerNames,
    applyReadSerializer,
  } = ctx;

  return async function listHandler(req, res) {
    if (!requireAuth(req, res)) return;

    // Parsed before a connection is taken: a malformed page is a client error
    // and must not cost a pool slot.
    const page = parsePageRequest(req.query);
    if (page.error) {
      const e = apiError(page.error.message, page.error.code, 400);
      return res.status(e.status).json(e.body);
    }

    try {
      const conn = await (await resolveRoPool(req)).getConnection();
      try {
        const table = `\`${t(logicalName)}\``;
        let sql = `SELECT * FROM ${table}`;
        const params = [];
        const filters = [];

        // Support common query-string filters.
        // Array values (e.g. ?id=a&id=b) → IN (?, ?) clause.
        // Single values → = ? clause.
        for (const [key, val] of Object.entries(req.query)) {
          if (['sort', 'order', 'limit', 'offset'].includes(key)) continue;
          // Only allow explicitly declared filterable columns.
          // If no filterableColumns provided, reject all query filters (CSO Finding #2).
          if (!filterCols || !filterCols.has(key)) continue;
          if (!isSafeColumnName(key)) continue;
          if (Array.isArray(val)) {
            filters.push(`\`${key}\` IN (${val.map(() => '?').join(', ')})`);
            params.push(...val);
          } else {
            filters.push(`\`${key}\` = ?`);
            params.push(val);
          }
        }
        // SECURITY: enforce user-scope restriction on non-admin GETs.
        // Always wins over any client-supplied filter on the same column.
        if (userScopeColumn && req.user && req.user.role !== 'admin') {
          const enforcedKey = String(userScopeColumn);
          if (!isSafeColumnName(enforcedKey)) {
            const e = apiError('Internal misconfiguration', 'INTERNAL_ERROR', 500);
            return res.status(e.status).json(e.body);
          }
          filters.push(`\`${enforcedKey}\` = ?`);
          params.push(req.user.id);
        }

        const whereSql = filters.length ? ' WHERE ' + filters.join(' AND ') : '';
        // Snapshotted before the page bounds are appended, so the count below
        // cannot drift from the predicate the rows were read under.
        const whereParams = params.slice();
        sql += whereSql;

        // Sorting — whitelist column names to prevent probing non-existent columns.
        // Default to 'created_at' (present on all schema tables) rather than 'sort_order'
        // which does not exist on variant_overrides, user_templates, etc.
        const ALLOWED_SORT_COLS = new Set([
          'id', 'created_at', 'updated_at', 'sort_order', 'order_index',
          'name', 'display_name', 'field_key', 'section_key', 'output_key',
        ]);
        const sortCol = ALLOWED_SORT_COLS.has(req.query.sort) ? req.query.sort : 'created_at';
        const sortDir = req.query.order === 'desc' ? 'DESC' : 'ASC';
        // NOTE: NULLs always sort to the end regardless of ASC/DESC.
        // Required because optional number columns (sort_order, order_index)
        // are nullable — without `IS NULL` first, NULL rows would land at the
        // top of an ASC sort and confuse the user.
        sql += ` ORDER BY \`${sortCol}\` IS NULL, \`${sortCol}\` ${sortDir}`;

        if (page.paginated) {
          // CORRECTNESS: a page is a window over an ordering, so the ordering
          // has to be total or the window is not well defined. None of the
          // sortable columns is unique, and the default one — `created_at` — is
          // a TIMESTAMP with no fractional-seconds spec, i.e. one-second
          // resolution on an append-only table. Rows sharing a value are a tie
          // group, two pages are two independent statements, and nothing
          // obliges the engine to break that tie the same way twice: the
          // leading `IS NULL` expression forces a filesort, and the sort
          // algorithm itself changes with how LIMIT+OFFSET fits. The result is
          // a row served on two pages while another is unreachable at any
          // offset, on an idle database. `id` is the primary key on every table
          // this factory serves, so appending it makes the order total.
          // Paginated branch only: the unpaged statement stays byte-identical.
          // The tiebreaker follows the requested direction so the sequence is
          // monotone across pages, and is omitted when `id` IS the sort column
          // — that ordering is already total.
          if (sortCol !== 'id') sql += `, \`id\` ${sortDir}`;
          sql += ` LIMIT ? OFFSET ?`;
          params.push(page.limit, page.offset);
        } else if (req.query.limit) {
          sql += ` LIMIT ?`;
          params.push(Number(req.query.limit));
        }

        const rows = await conn.query(sql, params);
        const parsed = parseRows(rows);
        await attachOwnerNames(conn, parsed);
        const body = applyReadSerializer(parsed);
        if (!page.paginated) return res.json(apiOk(body));

        const totalRows = await conn.query(
          `SELECT COUNT(*) AS cnt FROM ${table}${whereSql}`,
          whereParams,
        );
        return res.json(apiOk({
          rows: body,
          total: Number(totalRows[0].cnt) || 0,
          limit: page.limit,
          offset: page.offset,
        }));
      } finally {
        conn.release();
      }
    } catch (err) {
      if (tolerateMissingTableOnList && err && err.errno === 1146) {
        // Additive table absent on this target → "no rows", not a server error.
        return res.json(page.paginated
          ? apiOk({ rows: [], total: 0, limit: page.limit, offset: page.offset })
          : apiOk([]));
      }
      logger.error({ err, table: logicalName }, 'Failed to list rows from ' + logicalName);
      const e = apiError('Database operation failed', 'INTERNAL_ERROR');
      return res.status(e.status).json(e.body);
    }
  };
}

module.exports = { buildListHandler, parsePageRequest, MAX_PAGE_SIZE };
