'use strict';

/**
 * field-type-domain.js — the declared members of `blueprint_fields.field_type`,
 * and the one gate that refuses a value that is not identically one of them.
 *
 * WHY A DECLARED DOMAIN RATHER THAN A FOLD AT EACH COMPARISON. Three statements
 * in the custom PUT decide what to DESTROY by comparing this column against a
 * literal — `'select'` and `'checkbox'` own the field's options rows,
 * `'checkbox'` owns its choice_config, `'table'` owns its table_config and its
 * cell scope. A blocklist or a switch compared in JavaScript can only be trusted
 * on a value already known to be IDENTICALLY a member: the column is
 * `VARCHAR(100)` under a case-folding collation, so `'Select'` is the same
 * stored value to the database and matches nothing in JavaScript. Sent to the
 * PUT, it read as a type CHANGE (so the destructive block ran) whose old type
 * matched no branch — and on the way back the same request stored a spelling no
 * reader of this column recognises.
 *
 * The answer the codebase already argues for (see the `enumColumns` /
 * `valueGuards.rejectFor` contract in crud-factory.js) is to make identity a
 * PRECONDITION rather than to teach each comparison to fold: refuse the write
 * unless the value is identically a member, and the literal comparisons after it
 * are correct exactly as they are written.
 *
 * WHY THE LIST IS HERE AND NOT IN table-ddls.js. The sibling gates read their
 * domain from the DDL (`enumMembersFor`), which only works for a column declared
 * as an ENUM. This one is not: it is a plain `VARCHAR(100)`, and converting it is
 * a destructive DDL change on a live column that the app-layer domain closes
 * without. So this module is the single declaration, consumed by the mount and
 * by the custom PUT; the DDL points at it.
 */

/**
 * The field types this application renders, in the order the type chooser shows
 * them. Byte-identical to the front end's `FieldType` union and
 * `FIELD_TYPE_ORDER` — a member added on one side and not the other is a type
 * the server accepts and no form can draw, or one the chooser offers and the
 * server refuses.
 */
const { sameStoredValue } = require('./write-value');

const FIELD_TYPES = Object.freeze(['text', 'select', 'number', 'textarea', 'checkbox', 'table']);

/**
 * Is the `field_type` this write names outside the declared domain?
 *
 * PRESENCE AND NULL ARE NOT VIOLATIONS, and both for the same reason the
 * factory's enumerated-column gate gives:
 *   - a write that does not NAME the column asks for nothing and is judged on
 *     nothing;
 *   - `null` names it and asks for NULL, which the DDL permits (the column is
 *     nullable) — refusing it here would be this gate deciding a nullability
 *     question the schema already answers.
 *
 * @param {object} write the columns this statement will name, and their values
 * @returns {{status: number, code: string, column: string, message: string}|null}
 */
function fieldTypeViolation(write) {
  if (!write || !Object.prototype.hasOwnProperty.call(write, 'field_type')) return null;
  const value = write.field_type;
  // A key carrying `undefined` is the `null` the statement would store.
  if (value === undefined || value === null) return null;
  if (FIELD_TYPES.includes(value)) return null;
  return {
    status: 400,
    code: 'INVALID_COLUMN_VALUE',
    column: 'field_type',
    message: `field_type must be one of: ${FIELD_TYPES.join(', ')}`,
  };
}

/**
 * Which member of the declared domain the STORED value of this column IS.
 *
 * WHY THE STORED SIDE NEEDS THIS AND THE WRITTEN SIDE DOES NOT. `fieldTypeViolation`
 * above makes identity a precondition of the value being WRITTEN, which is what
 * lets the destructive comparisons after it be plain literals. It says nothing
 * about a value already in the table, and those comparisons judge the OLD row:
 * `oldRow.field_type === 'table'` is `false` for a stored `'Table'`, so the type
 * change is detected (the engine calls the two the same value) while the cleanup
 * that belongs to it does not run. `table_config` and the field's `value_scope`
 * survive on a field that is no longer a table — which, as the comment at that
 * clear states, silently narrows a whole-field setting to cells nobody picked the
 * moment the field becomes a table again — and the same miss leaves orphaned
 * `field_options` and an uncleared `choice_config`.
 *
 * Such rows are reachable and this PR does not close them: rows that predate the
 * write-time gate, and the IMPORT paths, which build their INSERTs from the
 * payload's own columns and validate compute-rule/value-source only. Gating the
 * import is a separate change with its own row; until then — and afterwards, for
 * the rows already stored — the cleanup has to be correct in their presence,
 * which is what this resolves.
 *
 * ASKED OF THE COLUMN, not folded in JavaScript. Whether a stored spelling IS a
 * member is the same question the engine answers for `WHERE field_type = ?`, and
 * a `toLowerCase()` here would be a second opinion about it — right for ASCII
 * case today, wrong for whatever else the column's collation folds. The
 * byte-identical pass costs no query, so every ordinary row is resolved without
 * touching the database; only a spelling that is already anomalous pays for the
 * probes, and only inside the type-change branch.
 *
 * @param {object} conn open connection, inside the caller's write transaction
 * @param {string} table physical table name (already prefixed by `t()`)
 * @param {*} storedValue the value the column currently holds
 * @returns {Promise<string|null>} the declared member, or null for none
 */
async function resolveStoredFieldType(conn, table, storedValue) {
  if (storedValue == null) return null;
  if (FIELD_TYPES.includes(storedValue)) return storedValue;
  for (const member of FIELD_TYPES) {
    if (await sameStoredValue(conn, table, 'field_type', member, storedValue)) return member;
  }
  return null;
}

module.exports = { FIELD_TYPES, fieldTypeViolation, resolveStoredFieldType };
