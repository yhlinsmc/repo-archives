'use strict';

/**
 * row-references.js — for every table the CRUD factory serves, which of its
 * columns hold ANOTHER ROW'S ID, and which table each one names.
 *
 * WHY THIS IS KEYED ON THE TABLE AND NOT ON THE MOUNT. The factory used to
 * derive this list from the options that declare a PARENT — `inheritOwnerFromParent`,
 * `parentOwnership`, `parentRepend` — with the reasoning that a mount which gains
 * a parent gains the rule with it. That reasoning is sound and answers a
 * different question. "Which mounts have a parent" is about AUTHORISATION: which
 * row decides whether this caller may write. "Which columns hold a row id" is
 * about STORAGE: which values must be written as the spelling the referenced row
 * carries. A column can be the second without being the first, and `user_templates`
 * is five of them — `category_id`, `release_id`, `blueprint_id`, `variant_id`
 * and `parent_id` are all client-supplied and none of them gates anything, so the
 * mount declares none of the three options and got no binding at all.
 *
 * What that produces is the defect `storedRowId` exists for. These columns are
 * `CHAR(36)` under a case-folding collation, so every guard that proves the
 * referenced row exists passes for ANY spelling of its id, and the INSERT then
 * stores the caller's. Every SQL reader goes on resolving it. The readers that do
 * not are in the browser: `FmbInput.tsx` builds a create with `parent_id` taken
 * straight from a URL search param, the clone path does the same, and the live
 * preview reads the mount back with `.filter(r => r.blueprint_id === blueprintId)`.
 * A record stored under a respelled blueprint is invisible to that filter while
 * every list query still returns it.
 *
 * THE SET IS THE DDL'S TO DECIDE, NOT THIS FILE'S. The columns below are checked
 * against `table-ddls.js` by `tests/unit/row-reference-coverage.test.js`: every
 * `CHAR(36)` column whose name ends in `_id` on a table this factory serves must
 * appear either here or in `NOT_A_ROW_REFERENCE` with a reason. A hand-written
 * list is the thing that produced this finding — the previous one was derived
 * from a real property, just not the property that decides the answer — so this
 * one states only the TARGET, which no schema can tell us, and lets the schema
 * decide the membership.
 */
const { TABLES } = require('../../../../shared/constants');

/**
 * table → { column: the table whose `id` that column names }.
 *
 * The four hierarchy references on `user_templates` all name `hierarchy_nodes`
 * rows; they differ by the referenced row's `node_type`, which is not this
 * question — `storedRowId` asks the primary key, and a value naming no row is
 * left exactly as it was for the FK guards to judge.
 */
const ROW_REFERENCES = Object.freeze({
  [TABLES.HIERARCHY_NODES]: Object.freeze({
    parent_id: TABLES.HIERARCHY_NODES,
    transformer_id: TABLES.TRANSFORMERS,
    linked_blueprint_id: TABLES.HIERARCHY_NODES,
  }),
  [TABLES.BLUEPRINT_FIELDS]: Object.freeze({ blueprint_id: TABLES.HIERARCHY_NODES }),
  [TABLES.FIELD_OPTIONS]: Object.freeze({ field_id: TABLES.BLUEPRINT_FIELDS }),
  [TABLES.BLUEPRINT_SECTIONS]: Object.freeze({ blueprint_id: TABLES.HIERARCHY_NODES }),
  [TABLES.BLUEPRINT_GROUPS]: Object.freeze({ blueprint_id: TABLES.HIERARCHY_NODES }),
  [TABLES.BLUEPRINT_OUTPUT_ORDER]: Object.freeze({ blueprint_id: TABLES.HIERARCHY_NODES }),
  [TABLES.DECISION_TABLES]: Object.freeze({ blueprint_id: TABLES.HIERARCHY_NODES }),
  [TABLES.VARIANT_OVERRIDES]: Object.freeze({
    variant_id: TABLES.HIERARCHY_NODES,
    field_id: TABLES.BLUEPRINT_FIELDS,
  }),
  [TABLES.USER_TEMPLATES]: Object.freeze({
    category_id: TABLES.HIERARCHY_NODES,
    release_id: TABLES.HIERARCHY_NODES,
    blueprint_id: TABLES.HIERARCHY_NODES,
    variant_id: TABLES.HIERARCHY_NODES,
    parent_id: TABLES.USER_TEMPLATES,
  }),
  [TABLES.API_CONNECTORS]: Object.freeze({ blueprint_id: TABLES.HIERARCHY_NODES }),
  [TABLES.FLOW_RECIPES]: Object.freeze({ blueprint_id: TABLES.HIERARCHY_NODES }),
  [TABLES.FLOW_RECIPE_STEPS]: Object.freeze({ recipe_id: TABLES.FLOW_RECIPES }),
  [TABLES.FLOW_RECIPE_RUNS]: Object.freeze({
    recipe_id: TABLES.FLOW_RECIPES,
    template_id: TABLES.USER_TEMPLATES,
    blueprint_id: TABLES.HIERARCHY_NODES,
  }),
});

/**
 * The columns the schema offers that are deliberately NOT bound, each with the
 * reason — because "this one does not need it" is a claim, and a list that can
 * only express inclusion makes that claim by saying nothing.
 *
 * `table.column` → reason.
 */
const NOT_A_ROW_REFERENCE = Object.freeze({
  // ── users.id, not a row reference in this sense ────────────────────────────
  // These name a USER, and the write path binds them through
  // `bindStoredOwnerId` / `resolveCanonicalUserId`, which does more than resolve
  // a spelling: it refuses a target that does not exist and one that is banned.
  // Binding them here as well would resolve the id a second, weaker way.
  'hierarchy_nodes.owner_id': 'a user id — bound by bindStoredOwnerId (ownerIdentityColumns)',
  'user_templates.owner_id': 'a user id — bound by bindStoredOwnerId (writeScopeColumn)',
  'api_connectors.owner_id': 'a user id — bound by bindStoredOwnerId (ownerColumn)',
  'flow_recipes.owner_id': 'a user id — bound by bindStoredOwnerId (ownerColumn)',
  'cap_scenarios.owner_id': 'a user id — bound by bindStoredOwnerId (ownerColumn)',
  'flow_recipe_runs.actor_id':
    'a user id, and server-stamped from the token rather than taken from the body',

  // ── never reaches the column from a request ───────────────────────────────
  'user_templates.flow_last_run_id':
    'declared in the mount\'s `serverOnlyColumns`, so it is stripped from every '
    + 'client write on BOTH verbs; the run lifecycle is the only writer',

  // ── not a reference at all ────────────────────────────────────────────────
  'api_connectors.group_id':
    'a correlation key the client mints to group connectors into one aggregation '
    + 'or chain; it names no row in any table, so there is no id to resolve it '
    + 'against. Its shape is pinned as a UUID at the mount and its companions are '
    + 'forced NULL when it is absent',
});

/**
 * Tables whose every reference column is bound by a DIFFERENT binder, named.
 *
 * The capacity child mounts declare their references as
 * `CHILD_FK_VALIDATIONS` and bind them in `makeScenarioFkLockValidator`, which
 * resolves each one under a FOR UPDATE lock and writes the resolved id back into
 * the object the statement is built from — the same job as `bindStoredParentIds`
 * plus the lock, on both verbs. Their `scenario_id` is bound earlier still, by
 * `makeScenarioExistsGuard` on create and `makeRowScenarioBinding` on update.
 * Binding them a second time here would issue a second, unlocked resolution of a
 * value already resolved under a lock.
 */
const BOUND_BY_ANOTHER_BINDER = 'capacity mount — bound under lock by makeScenarioFkLockValidator '
  + '(CHILD_FK_VALIDATIONS), with scenario_id bound by makeScenarioExistsGuard / makeRowScenarioBinding';

const referencesFor = (table) => ROW_REFERENCES[table] || null;

module.exports = {
  ROW_REFERENCES,
  NOT_A_ROW_REFERENCE,
  BOUND_BY_ANOTHER_BINDER,
  referencesFor,
};
