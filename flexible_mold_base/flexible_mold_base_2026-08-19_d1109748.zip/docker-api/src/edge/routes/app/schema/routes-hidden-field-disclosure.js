/**
 * routes-hidden-field-disclosure.js — WHY a field is not on the form, for the
 * people who can change it.
 *
 * A hidden field is absent for the people who cannot act on it. For the two who
 * can — an administrator, and the editor who owns that blueprint — one line
 * stands in the field's place saying what is hidden and why.
 *
 * THE DECISION IS TAKEN HERE, NOT IN THE BROWSER, and that is the whole reason
 * this endpoint exists rather than a `role === 'admin'` branch in the renderer.
 * A branch that declines to PAINT a line has already been handed the line: the
 * reason, and the name of the field that caused it, are in the response the
 * ordinary user's tab holds. So the reason and the causing field's name are
 * produced by this handler and by nothing else, and this handler answers 403 to
 * everyone else — there is no shape of the response that carries them past the
 * gate.
 *
 * WHAT THIS DOES NOT CLAIM. `blueprint_fields` is readable by any authenticated
 * caller, because the data-entry form cannot hide a field without the rule that
 * hides it — the evaluation is against form values, which exist only in the
 * browser. So the EXISTENCE of a field, and its `visibility_rule`, are already
 * within reach of an ordinary user's session today; that is a pre-existing
 * property of the form, not something this endpoint grants. What this endpoint
 * refuses to hand out is the derived, design-time reading: which fields are
 * hidden and by what, resolved and named.
 *
 * THE GATE IS TWO CHECKS AND BOTH ARE LOAD-BEARING. `editorMayWriteBlueprint`
 * answers `true` for every role that is not `editor` — it is the ownership half
 * of a gate whose role half is `requireAdminOrEditor`, and on its own it admits
 * a plain user outright (see its comment in ./helpers.js). Calling it without
 * the role gate in front is the mistake this comment exists to stop.
 */
const {
  TABLES,
  t,
  apiOk,
  apiError,
  requireAdminOrEditor,
  editorMayWriteBlueprint,
  getActualColumnSet,
  isMissingTableOrColumn,
  UUID_RE,
  logger,
} = require('./helpers');
const { resolveRoPool } = require('./request-pool');
// The same reading of "narrowed to individual cells" the resolver applies
// (src/fmb/lib/cell-targets.ts normalizeCellScope), so the two layers cannot
// disagree about whether an override speaks for the whole field.
const { scopeNarrows } = require('../../../../shared/cell-targets-validate');

/** Why a field is not on the form. Exactly two causes exist — a variant policy
 *  that hides it outright, and a visibility rule whose condition is not met. */
const REASON_VARIANT_POLICY = 'variant_policy';
const REASON_VISIBILITY_RULE = 'visibility_rule';

/**
 * Every field of one blueprint that CAN be hidden, and by what.
 *
 * Which of them is hidden right now is not a question this handler can answer:
 * a visibility rule is evaluated against the values in the form, and those live
 * in the browser. So the catalogue is served whole to a caller who is allowed
 * it, and the renderer draws a line only for a field it has itself resolved as
 * hidden. That also keeps this a single request per blueprint rather than one
 * per keystroke.
 */
function register(router) {

router.get('/hidden-field-disclosure/:blueprintId', async (req, res) => {
  // Role first — see the module comment. Nothing below is reachable by a user.
  if (!requireAdminOrEditor(req, res)) return;
  const blueprintId = req.params.blueprintId;
  if (!UUID_RE.test(blueprintId)) {
    const e = apiError('blueprintId has invalid format', 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }
  const rawVariant = req.query.variant_id;
  const variantId = typeof rawVariant === 'string' && rawVariant.length > 0 ? rawVariant : null;
  if (variantId !== null && !UUID_RE.test(variantId)) {
    const e = apiError('variant_id has invalid format', 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }

  try {
    const conn = await (await resolveRoPool(req)).getConnection();
    try {
      // Ownership half of the gate. An editor who does not own this blueprint —
      // and does not have it shared to them — is told nothing about it, in the
      // same terms every schema write route tells them.
      if (!(await editorMayWriteBlueprint(conn, req, blueprintId))) {
        const e = apiError('Forbidden', 'FORBIDDEN', 403);
        return res.status(e.status).json(e.body);
      }

      // The rule's SUBJECT — the field whose answer decides this one's fate — is
      // read by the engine rather than parsed here: the driver returns a JSON
      // column as an object on one path and as a string on another, and a reader
      // that guessed would be a second opinion about the column's shape.
      //
      // The join carries `action = 'hide'` rather than filtering afterwards
      // because a field may hold one override per action (the UNIQUE is
      // (variant_id, field_id, action)); asking for any override and then
      // reading its action answers about whichever row came back first.
      //
      // cell_targets is an additive column whose migration entry is severity
      // 'warning' (migration-steps.js), so a DB whose account could not run the
      // ALTER keeps working with the column absent — the write paths in
      // routes-variant-overrides.js already degrade to whole-field scope on
      // exactly this DB shape. Naming an absent column in a SELECT list throws
      // ER_BAD_FIELD_ERROR (1054), so this reuses that same probe
      // (getActualColumnSet/gateKeysByColumnSet's sibling check) rather than a
      // new style, and the 1054 catch below covers the compound case a probe
      // alone cannot: probe-blind (colSet === null, so hasCellTargetsCol is kept
      // true) AND the column really absent.
      const voColSet = await getActualColumnSet(conn, t(TABLES.VARIANT_OVERRIDES));
      let hasCellTargetsCol = voColSet === null || voColSet.has('cell_targets');

      const selectSql = (withCellTargets) =>
        `SELECT f.field_key, f.field_label, f.section, f.order_index, f.field_type,
                (f.visibility_rule IS NOT NULL) AS has_rule,
                JSON_UNQUOTE(JSON_EXTRACT(f.visibility_rule, '$.field_key')) AS rule_subject_key,
                o.action AS override_action${withCellTargets ? ',\n                o.cell_targets AS override_cell_targets' : ''}
           FROM \`${t(TABLES.BLUEPRINT_FIELDS)}\` f
           LEFT JOIN \`${t(TABLES.VARIANT_OVERRIDES)}\` o
                  ON o.field_id = f.id AND o.action = 'hide' AND o.variant_id = ?
          WHERE f.blueprint_id = ?
          ORDER BY f.order_index IS NULL, f.order_index, f.field_key`;

      let rows;
      try {
        rows = await conn.query(selectSql(hasCellTargetsCol), [variantId, blueprintId]);
      } catch (readErr) {
        if (!hasCellTargetsCol || !isMissingTableOrColumn(readErr)) throw readErr;
        // The column really is absent despite a blind probe: re-read without
        // it. `r.override_cell_targets` then comes back `undefined`, which
        // `scopeNarrows` (readScopeDocument's `value == null` check) already
        // treats the same as a stored NULL — whole-field override — matching
        // the writers' degrade.
        hasCellTargetsCol = false;
        rows = await conn.query(selectSql(false), [variantId, blueprintId]);
      }

      const labelByKey = new Map();
      for (const r of rows) labelByKey.set(r.field_key, r.field_label || r.field_key);

      const entries = [];
      for (const r of rows) {
        // A `hide` narrowed to individual cells of a table governs those cells
        // and says nothing about the field, so it does not hide it.
        const hiddenByPolicy = r.override_action === 'hide'
          && !(r.field_type === 'table' && scopeNarrows(r.override_cell_targets));
        const hasRule = Number(r.has_rule) === 1;
        if (!hiddenByPolicy && !hasRule) continue;
        // Precedence: a policy that hides the field does so under every value
        // the form can hold, so it is the stable answer whenever both are
        // present. A rule can only ever be the reason while its condition is
        // unmet, which is a state the operator's next keystroke can end.
        const reason = hiddenByPolicy ? REASON_VARIANT_POLICY : REASON_VISIBILITY_RULE;
        const entry = {
          field_key: r.field_key,
          field_label: r.field_label || r.field_key,
          section: r.section || null,
          order_index: r.order_index == null ? null : Number(r.order_index),
          reason,
        };
        // The causing field is named only when the rule is the reason AND the
        // field it names is still in this blueprint. A rule pointing at a
        // deleted field is a stale reference the resolver already ignores;
        // naming it here would offer a link to nothing.
        if (reason === REASON_VISIBILITY_RULE
          && typeof r.rule_subject_key === 'string'
          && labelByKey.has(r.rule_subject_key)) {
          entry.cause_field_key = r.rule_subject_key;
          entry.cause_field_label = labelByKey.get(r.rule_subject_key);
        }
        entries.push(entry);
      }

      res.json(apiOk({ entries }));
    } finally {
      conn.release();
    }
  } catch (err) {
    logger.error({ err, blueprintId }, 'Failed to read hidden field disclosure');
    const e = apiError('Database operation failed', 'INTERNAL_ERROR');
    res.status(e.status).json(e.body);
  }
});

}

module.exports = { register, REASON_VARIANT_POLICY, REASON_VISIBILITY_RULE };
