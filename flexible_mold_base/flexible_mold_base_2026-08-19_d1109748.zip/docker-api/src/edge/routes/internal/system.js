/**
 * system.js — Edge-side system info (S2S-only).
 *
 * GET /edge/internal/system/auth-mode
 *   Returns the canonical auth_mode (DB-backed when pool ready, env fallback
 *   otherwise) plus the source string for diagnostics.
 *
 * This replaces direct DB access from infra/routes/auth-session.js
 * (/api/auth/diagnostics) and infra/middleware/access-check.js, both of which
 * imported the edge pool to call resolveAuthModeAsync.
 */
const router = require('express').Router();
const { pool, t, isPoolReady, getConfiguredPoolStrictWrites } = require('../../db');
const { apiOk } = require('../../../shared/helpers');
const { resolveAuthMode, resolveAuthModeAsync, getAuthModeSource, probeKeycloakDiscovery } = require('../../../shared/config');
const { isEncryptionKeyConfigured } = require('../../../shared/lib/settings-crypto');
const { logger: rootLogger } = require('../../../shared/lib/logger');
const { RATE_LIMIT_SETTINGS, TABLES } = require('../../../shared/constants');
const { coerceRateLimitInt } = require('../../../shared/lib/rate-limit-validate');

const logger = rootLogger.child({ module: 'edge-system' });

// SAFETY: when pool isn't ready, the in-memory `_resolvedAuthMode` may
// still be the module default 'local' (edge boot has not finished
// detectAuthMode). Fall back to env-aware detection so infra's boot probe
// doesn't mount the wrong middleware in Keycloak-configured cold boots.
async function envBasedFallback() {
  const override = process.env.AUTH_MODE_OVERRIDE;
  if (override === 'local' || override === 'keycloak') return { mode: override, source: 'override' };
  if (process.env.KEYCLOAK_ISSUER_BASE_URL) {
    const reachable = await probeKeycloakDiscovery(2000);
    return { mode: reachable ? 'keycloak' : 'local', source: reachable ? 'env_discovery' : 'env_unreachable' };
  }
  return { mode: 'local', source: 'env_default' };
}

router.get('/auth-mode', async (_req, res) => {
  let auth_mode;
  let source = getAuthModeSource();
  if (isPoolReady()) {
    try {
      auth_mode = await resolveAuthModeAsync(pool, t);
    } catch (err) {
      logger.warn({ err }, 'auth_mode DB lookup failed; falling back to env');
      const fb = await envBasedFallback();
      auth_mode = fb.mode;
      source = fb.source;
    }
  } else {
    const fb = await envBasedFallback();
    auth_mode = fb.mode;
    source = fb.source;
  }

  res.json(apiOk({
    auth_mode,
    source,
    pool_ready: isPoolReady(),
    settings_encryption_key_configured: isEncryptionKeyConfigured(),
    // Whether the engine behind the configured pool refuses a value it cannot
    // store. Carried HERE rather than on a health body because this route is
    // S2S-only and its one caller publishes it to admins alone: an
    // unauthenticated caller learning that a truncating or clamping write is
    // worth attempting against this host is an exploitability signal, which is
    // not what a health check is for. See edge/db.getConfiguredPoolStrictWrites.
    configured_pool_strict_writes: getConfiguredPoolStrictWrites(),
  }));
});

// GET /rate-limits — S2S read of the 4 UI-adjustable limiter maxima. Infra's
// stale-while-revalidate cache polls this; pool-not-ready / read failure → all
// null so infra falls back to env/default (fail-safe). Keys + parse coercion
// are single-sourced from RATE_LIMIT_SETTINGS.
router.get('/rate-limits', async (_req, res) => {
  const out = {};
  for (const s of RATE_LIMIT_SETTINGS) out[s.snapshotKey] = null;
  if (!isPoolReady()) return res.json(apiOk(out));
  try {
    const keys = RATE_LIMIT_SETTINGS.map((s) => s.settingKey);
    const placeholders = keys.map(() => '?').join(',');
    const rows = await pool.ro.query(
      `SELECT \`key\`, value FROM \`${t(TABLES.SYSTEM_SETTINGS)}\` WHERE \`key\` IN (${placeholders})`,
      keys,
    );
    const byKey = new Map((rows || []).map((r) => [r.key, r.value]));
    for (const s of RATE_LIMIT_SETTINGS) {
      out[s.snapshotKey] = coerceRateLimitInt(byKey.get(s.settingKey));
    }
  } catch (err) {
    logger.warn({ err }, 'rate-limits read failed; returning nulls');
  }
  res.json(apiOk(out));
});

module.exports = router;
