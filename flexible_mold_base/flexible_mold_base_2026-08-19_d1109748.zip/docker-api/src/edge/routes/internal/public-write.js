/**
 * public-write.js — Public Integration API template shell-create (edge-only,
 * S2S). Namespace mount: /edge/internal/public-write (infra forwards here on the
 * machine-principal S2S contract; never publicly routed). Spec §6, plan
 * 2026-07-11.
 *
 * POST /templates creates an empty template SHELL linked to a resolved
 * hierarchy name-path (blueprint OR variant leaf), owned by the resolved
 * owner_username user or, absent that, the service account itself. The whole
 * request is idempotent AND transactional: a caller-supplied Idempotency-Key
 * reserves a row in `service_account_idempotency` BEFORE the template is
 * created, and the reserve → INSERT → finalize sequence runs inside a single
 * transaction, so a crash/error anywhere in that window rolls back BOTH the
 * template and the reservation — a retry never mints a second template.
 *
 * SECURITY:
 *   - fail-closed on a non-machine principal / empty scope (defense-in-depth
 *     past the already-gated infra hop)
 *   - the name-path resolver runs over the in-scope node set only, so an
 *     out-of-scope path is indistinguishable from a nonexistent one (404 —
 *     anti-enumeration), never a 403
 *   - `owner_username` is a username-existence probe; failed owner lookups are
 *     rate-limited at infra AND audited here (sa id + attempted username, no email)
 *   - the response is the shared public projection built by
 *     shared/serializers/public-template.js — the SAME key set GET /templates/{id}
 *     returns, minus the payload blobs. It names the owner by username only
 *     (email-stripped); never an email, never owner_id or any other owner
 *     column, never internal meta
 */
const router = require('express').Router();
const crypto = require('crypto');
const { pool, t } = require('../../db');
const { TABLES } = require('../../../shared/constants');
const { isNonEmptyScope } = require('../../../shared/lib/machine-scope');
const { sendPublicError } = require('../../../shared/lib/public-errors');
const { computeInScopeNodeIds } = require('../../lib/public-scope');
const {
  splitNamePath,
  resolveBlueprintByNamePath,
  deriveHierarchyChain,
} = require('../../lib/name-path-resolve');
const { bodyFingerprint, classifyExisting, RESERVED_STATUS } = require('../../lib/idempotency');
const {
  buildPublicTemplatePath,
  serializePublicTemplate,
} = require('../../../shared/serializers/public-template');
const { stripEmailDomain } = require('../../lib/owner-name-enrichment');
const { logger: rootLogger } = require('../../../shared/lib/logger');

const logger = rootLogger.child({ module: 'public-write' });

// Idempotency-Key charset + length (spec: 1–128 chars, [A-Za-z0-9._-]).
const IDEM_KEY_RE = /^[A-Za-z0-9._-]{1,128}$/;
// Strict body allowlist. A `payload` key is intentionally NOT allowed — v1 is
// shell-only, so a request carrying payload is a validation error (plan
// decision 1), caught by the same unknown-key check.
const ALLOWED_BODY_KEYS = new Set(['path', 'name', 'owner_username']);
const NAME_MAX = 255;
const PATH_MAX = 512;
const OWNER_USERNAME_MAX = 255;
const DEFAULT_NAME = '(unnamed)';
// Both leaf types are addressable for create (customers usually pick a variant
// before saving); ambiguity is counted across both together in the resolver.
const CREATE_LEAF_TYPES = ['blueprint', 'variant'];
const AUDIT_EVENT = 'public.template.create';
const OWNER_FAIL_EVENT = 'public.template.owner_lookup_failed';

function isDupKeyError(err) {
  return !!err && (err.code === 'ER_DUP_ENTRY' || err.errno === 1062);
}

// SECURITY [Codex-P2a]: the attempted owner_username is recorded in the internal
// audit for forensics, but it may be an email address. Redact an email-form value
// (contains '@') to a fixed marker so no address is persisted; keep a plain
// username raw (it carries the forensic signal without being PII).
function redactAttemptedUsername(value) {
  return typeof value === 'string' && value.includes('@') ? '[email-form redacted]' : value;
}

async function insertReservation(conn, saId, idemKey, fingerprint) {
  await conn.query(
    `INSERT INTO \`${t(TABLES.SERVICE_ACCOUNT_IDEMPOTENCY)}\`
       (id, service_account_id, idempotency_key, body_fingerprint, response_status, response_body, expires_at)
     VALUES (?, ?, ?, ?, ?, NULL, DATE_ADD(NOW(), INTERVAL 24 HOUR))`,
    [crypto.randomUUID(), saId, idemKey, fingerprint, RESERVED_STATUS],
  );
}

/**
 * Reserve the idempotency key BEFORE creating the template (spec §6 M2), inside
 * the caller's open transaction. The UNIQUE(service_account_id, idempotency_key)
 * constraint makes the reservation atomic; a duplicate collides and is resolved
 * against the stored fingerprint:
 *   - proceed   : reservation now held (fresh, or a stale one was replaced)
 *   - replay    : a finalized same-body row exists → return its stored response
 *   - conflict  : same key + different body (`reason: 'fingerprint'`), OR a
 *                 same-body create still in flight (`reason: 'reserved'`)
 * @returns {Promise<{ kind: 'proceed' } | { kind: 'replay', status: number, body: unknown } | { kind: 'conflict', reason: 'reserved'|'fingerprint' }>}
 */
async function reserve(conn, saId, idemKey, fingerprint) {
  try {
    await insertReservation(conn, saId, idemKey, fingerprint);
    return { kind: 'proceed' };
  } catch (err) {
    if (!isDupKeyError(err)) throw err;
    const rows = await conn.query(
      `SELECT body_fingerprint, response_status, response_body, expires_at
       FROM \`${t(TABLES.SERVICE_ACCOUNT_IDEMPOTENCY)}\`
       WHERE service_account_id = ? AND idempotency_key = ?`,
      [saId, idemKey],
    );
    const existing = rows[0];
    // A row vanished between the dup error and this read (another writer expired
    // + replaced it): treat as an in-flight conflict — safe, never a silent
    // second create; the client may retry.
    if (!existing) return { kind: 'conflict', reason: 'reserved' };

    const cls = classifyExisting(existing, fingerprint, Date.now());
    if (cls.kind === 'replay') return { kind: 'replay', status: cls.status, body: cls.body };
    if (cls.kind === 'conflict_fingerprint') return { kind: 'conflict', reason: 'fingerprint' };
    if (cls.kind === 'conflict_reserved') return { kind: 'conflict', reason: 'reserved' };

    // Expired: replace the stale reservation and proceed. If another writer grabs
    // it in the gap, the re-INSERT collides again → in-flight conflict.
    await conn.query(
      `DELETE FROM \`${t(TABLES.SERVICE_ACCOUNT_IDEMPOTENCY)}\`
       WHERE service_account_id = ? AND idempotency_key = ?`,
      [saId, idemKey],
    );
    try {
      await insertReservation(conn, saId, idemKey, fingerprint);
      return { kind: 'proceed' };
    } catch (err2) {
      if (isDupKeyError(err2)) return { kind: 'conflict', reason: 'reserved' };
      throw err2;
    }
  }
}

async function finalizeReservation(conn, saId, idemKey, status, body) {
  await conn.query(
    `UPDATE \`${t(TABLES.SERVICE_ACCOUNT_IDEMPOTENCY)}\`
     SET response_status = ?, response_body = ?, expires_at = DATE_ADD(NOW(), INTERVAL 24 HOUR)
     WHERE service_account_id = ? AND idempotency_key = ?`,
    [status, JSON.stringify(body), saId, idemKey],
  );
}

// Best-effort feature audit. SECURITY: metadata carries only non-secret,
// internal-surface fields — never an email. A failed audit write must never
// change the create outcome.
async function writeAudit(conn, eventType, saId, metadata) {
  try {
    await conn.query(
      `INSERT INTO \`${t(TABLES.FEATURE_AUDIT)}\` (id, event_type, user_id, metadata) VALUES (?, ?, ?, ?)`,
      [crypto.randomUUID(), eventType, saId, JSON.stringify(metadata)],
    );
  } catch (err) {
    logger.warn({ err }, 'public template create audit write failed (non-critical)');
  }
}

router.post('/templates', async (req, res) => {
  // Fail-closed: defense-in-depth past the already-gated infra hop.
  const user = req.user;
  if (!user || user.type !== 'service_account' || !isNonEmptyScope(user.scope)) {
    return sendPublicError(res, 401, 'invalid_token');
  }
  const saId = user.id;

  // Idempotency-Key header — REQUIRED, bounded charset/length.
  const idemKey = req.headers['idempotency-key'];
  if (typeof idemKey !== 'string' || !IDEM_KEY_RE.test(idemKey)) {
    return sendPublicError(res, 400, 'validation_failed');
  }

  // Strict body: only { path, name?, owner_username? }. Unknown keys (incl.
  // `payload`) → 400. Length caps guard against oversized inputs.
  const body = req.body && typeof req.body === 'object' && !Array.isArray(req.body) ? req.body : null;
  if (!body) return sendPublicError(res, 400, 'validation_failed');
  for (const key of Object.keys(body)) {
    if (!ALLOWED_BODY_KEYS.has(key)) return sendPublicError(res, 400, 'validation_failed');
  }
  if (typeof body.path !== 'string' || body.path.trim() === '' || body.path.length > PATH_MAX) {
    return sendPublicError(res, 400, 'validation_failed');
  }
  if (body.name !== undefined && typeof body.name !== 'string') return sendPublicError(res, 400, 'validation_failed');
  if (body.owner_username !== undefined
    && (typeof body.owner_username !== 'string' || body.owner_username.length > OWNER_USERNAME_MAX)) {
    return sendPublicError(res, 400, 'validation_failed');
  }

  const name = ((body.name !== undefined ? body.name.trim() : '') || DEFAULT_NAME).slice(0, NAME_MAX);
  const ownerUsername = body.owner_username !== undefined ? body.owner_username.trim() : '';
  const roots = Array.isArray(user.scope.roots) ? user.scope.roots : [];

  let conn;
  let inTx = false;
  try {
    conn = await pool.rw.getConnection();

    // Scope context (fresh — writes are low-volume; no node cache needed). Reads
    // stay OUTSIDE the transaction to keep the tx window minimal.
    const nodes = await conn.query(
      `SELECT id, parent_id, name, node_type FROM \`${t(TABLES.HIERARCHY_NODES)}\``,
    );
    const byId = new Map(nodes.map((n) => [n.id, n]));
    const inScope = computeInScopeNodeIds(nodes, roots);

    // Resolve the name-path BEFORE reserving — a path error is re-resolved on
    // every retry (never cached against the key), so a create retried after the
    // hierarchy is fixed can succeed with the same key.
    const segments = splitNamePath(body.path);
    const resolved = resolveBlueprintByNamePath(nodes, segments, inScope, CREATE_LEAF_TYPES);
    if (resolved.status === 'not_found') return sendPublicError(res, 404, 'path_not_found');
    if (resolved.status === 'ambiguous') return sendPublicError(res, 409, 'path_ambiguous');
    const chain = deriveHierarchyChain(byId, resolved.id);
    // A variant leaf with no blueprint ancestor is a malformed hierarchy — fail
    // closed as not_found (blueprint_id is required for the shell).
    if (!chain.blueprint_id) return sendPublicError(res, 404, 'path_not_found');

    // Resolve the owner BEFORE reserving so the idempotency fingerprint can be
    // built from the RESOLVED identity [Codex-R2]. Owner lookup is a read (outside
    // the tx); a 4xx here is re-evaluated on every retry (never cached), the same
    // as a path error — so a create retried after the target user first signs in
    // can succeed with the same key.
    let ownerId = saId;
    let fingerprintOwnerId = null; // null = no owner_username (owner defaults to the SA)
    let ownerKcUsername = null; // the DB-canonical username, echoed back (never the client string)
    if (ownerUsername) {
      const ownerRows = await conn.query(
        `SELECT id, kc_username FROM \`${t(TABLES.USERS)}\` WHERE kc_username = ?`,
        [ownerUsername],
      );
      if (ownerRows.length === 0) {
        await writeAudit(conn, OWNER_FAIL_EVENT, saId, { reason: 'owner_not_found', attempted_username: redactAttemptedUsername(ownerUsername) });
        return sendPublicError(res, 400, 'owner_not_found');
      }
      if (ownerRows.length > 1) {
        await writeAudit(conn, OWNER_FAIL_EVENT, saId, { reason: 'owner_ambiguous', attempted_username: redactAttemptedUsername(ownerUsername) });
        return sendPublicError(res, 409, 'owner_ambiguous');
      }
      ownerId = ownerRows[0].id;
      ownerKcUsername = ownerRows[0].kc_username;
      fingerprintOwnerId = ownerId;
    }

    // Idempotency fingerprint = the RESOLVED identity (canonical node ids + the
    // NFC-normalized label + resolved owner id), NOT the raw path/owner_username
    // strings [Codex-R2]. Path resolution is case/accent/whitespace-insensitive,
    // so every equivalent spelling of the same node collapses to one fingerprint —
    // a retry differing only in spelling correctly REPLAYS instead of 409ing. A
    // genuinely different resolved blueprint/variant, a different label, or a
    // different owner is a different intent → still conflicts.
    const fingerprint = bodyFingerprint({
      blueprint_id: chain.blueprint_id,
      variant_id: chain.variant_id ?? null,
      name,
      owner_id: fingerprintOwnerId,
    });

    // Opportunistic scoped sweep of this account's expired reservations (uses the
    // UNIQUE index's service_account_id prefix). Best-effort, autocommit, before
    // the transaction — keeps the store from growing without a cron.
    try {
      await conn.query(
        `DELETE FROM \`${t(TABLES.SERVICE_ACCOUNT_IDEMPOTENCY)}\`
         WHERE service_account_id = ? AND expires_at < NOW()`,
        [saId],
      );
    } catch (sweepErr) {
      logger.warn({ err: sweepErr }, 'idempotency expired-row sweep failed (non-critical)');
    }

    // ── Transactional window: reserve → create → finalize ────────────────────
    // A failure anywhere here rolls back BOTH the reservation and the template,
    // so a retry with the same key never leaves a committed template behind a
    // deleted reservation (the second-template bug).
    await conn.beginTransaction();
    inTx = true;

    const r = await reserve(conn, saId, idemKey, fingerprint);
    if (r.kind === 'replay') {
      await conn.commit();
      inTx = false;
      // NOTE: a replay returns the body EXACTLY as it was stored, which is the
      // contract — a retry must see the original result, not a re-derived one.
      // The consequence at a shape change: a key first used before the response
      // shape changed replays the OLD shape for the remainder of its 24-hour
      // window. Rewriting stored bodies at deploy time was considered and
      // rejected — it would mean reinterpreting a durable record of what was
      // actually returned, to remove a field for at most 24 hours, on a table
      // whose whole purpose is byte-stable replay. The window is documented on
      // the Idempotency-Key parameter so an integrator can tell a replay from a
      // regression.
      return res.status(r.status).json(r.body);
    }
    if (r.kind === 'conflict') {
      await conn.rollback();
      inTx = false;
      // A still-in-flight duplicate (reserved) is transiently retryable → hint
      // the client with Retry-After; a different-body conflict is not.
      if (r.reason === 'reserved') res.set('Retry-After', '1');
      return sendPublicError(res, 409, 'idempotency_conflict');
    }

    // Create the shell (server-generated id; is_draft; resolved FK chain).
    const templateId = crypto.randomUUID();
    await conn.query(
      `INSERT INTO \`${t(TABLES.USER_TEMPLATES)}\`
         (id, name, category_id, release_id, blueprint_id, variant_id, owner_id, is_draft)
       VALUES (?, ?, ?, ?, ?, ?, ?, TRUE)`,
      [templateId, name, chain.category_id, chain.release_id, chain.blueprint_id, chain.variant_id, ownerId],
    );
    const createdRows = await conn.query(
      `SELECT created_at, updated_at, schema_version FROM \`${t(TABLES.USER_TEMPLATES)}\` WHERE id = ?`,
      [templateId],
    );

    const resolvedPath = buildPublicTemplatePath(byId, inScope, chain);
    // The shared public shape — identical to what GET /templates/{id} returns,
    // minus the payload blobs. owner_id is deliberately not part of it.
    // SECURITY: owner_username echoes the DB-canonical Keycloak username from
    // the resolved users row — NOT the client-supplied string —
    // email-domain-stripped so the never-return-email contract holds even if a
    // realm is configured with email-as-username; null when the shell is owned
    // by the service account (no users row to name).
    const responseBody = serializePublicTemplate({
      id: templateId,
      name,
      is_draft: true,
      owner_username: ownerKcUsername ? stripEmailDomain(ownerKcUsername) : null,
      schema_version: createdRows[0] && createdRows[0].schema_version,
      created_at: createdRows[0] && createdRows[0].created_at,
      updated_at: createdRows[0] && createdRows[0].updated_at,
    }, resolvedPath);

    await finalizeReservation(conn, saId, idemKey, 201, responseBody);
    await conn.commit();
    inTx = false;
    // Audit AFTER commit — best-effort; an audit failure must not roll back the
    // committed template.
    await writeAudit(conn, AUDIT_EVENT, saId, { template_id: templateId, path: resolvedPath, owner_id: ownerId });
    return res.status(201).json(responseBody);
  } catch (err) {
    // Roll back the whole reserve→create→finalize window: the template AND the
    // reservation are undone together, so a transient failure is safely retryable
    // (no blind deleteReservation needed — nothing is created outside the tx).
    if (inTx) {
      try { await conn.rollback(); }
      catch (rbErr) { logger.warn({ err: rbErr }, 'public template create rollback failed (non-critical)'); }
    }
    logger.error({ err }, 'public template create failed');
    return sendPublicError(res, 503, 'edge_unreachable');
  } finally {
    if (conn) conn.release();
  }
});

// Any unmatched path under this S2S namespace is a public 404 (never the default
// Express HTML body).
router.use((_req, res) => sendPublicError(res, 404, 'not_found'));

module.exports = router;
