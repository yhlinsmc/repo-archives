/**
 * docs-page.js — the dev-only /edge/docs reference page.
 *
 * WHY IT IS NOT IN index-edge.js ANY MORE: the entry point demands S2S_API_KEY,
 * opens a pool and calls app.listen() on require, so nothing could mount this
 * page on a bare app. The suite's answer was to assert the font override for the
 * edge MOUNT PATH and serve the files from an app it built itself, which proves
 * the CSS builder and proves nothing about this page. Mounting lives here so the
 * page a reader actually gets is the one under test.
 *
 * Behaviour is unchanged from the inline block: dev-only, spec embedded in the
 * bootstrap configuration, docs-scoped helmet, and a JSON message in production.
 */
const { createDocsHelmet, getScalarCdnUrl, buildDocsFontOptions } = require('../shared/security');
const { getEdgeSpec, escapeForInlineScript } = require('../shared/openapi');
const { DOCS_DISABLED_MESSAGE } = require('../shared/docs-disabled');
const { logger: rootLogger } = require('../shared/lib/logger');

const logger = rootLogger.child({ module: 'edge-docs' });

const EDGE_DOCS_MOUNT = '/edge/docs';

/**
 * Mount /edge/docs. The static bundle router for `scalarMount` is the caller's
 * job — it is ungated and shared with the raw asset paths.
 * @param {import('express').Express} app
 * @param {string} scalarMount - the mount createScalarStaticRouter() was given
 */
function mountEdgeDocs(app, scalarMount) {
  if (process.env.NODE_ENV === 'production') {
    app.get(EDGE_DOCS_MOUNT, (_req, res) => res.status(200).json({
      message: DOCS_DISABLED_MESSAGE,
    }));
    return;
  }

  let apiReference;
  try {
    ({ apiReference } = require('@scalar/express-api-reference'));
  } catch (err) {
    logger.warn({ err: err.message }, 'Scalar not available — /edge/docs disabled');
    return;
  }

  const docsHelmet = createDocsHelmet();
  // Escaped for the same reason the public portal is: Scalar serialises this
  // object into an inline <script> under a CSP relaxed to 'unsafe-inline', so
  // a `</script` or `<!--` in any annotation would break the page out of its
  // own script tag. Dev-only surface, same sink — and unlike the public portal
  // this one still EMBEDS its document, so the escape is live here.
  app.use(EDGE_DOCS_MOUNT, docsHelmet, apiReference(escapeForInlineScript({
    cdn: getScalarCdnUrl(scalarMount),
    // Same override the public portal gets: createDocsHelmet() pins
    // `font-src 'self'` on every docs page, so a page without it asks for a
    // font it is then not allowed to fetch, and falls back to a system one —
    // and without the paired switch it keeps asking for the external faces.
    ...buildDocsFontOptions(scalarMount),
    spec: { content: getEdgeSpec() },
  })));
}

module.exports = { mountEdgeDocs, EDGE_DOCS_MOUNT };
