/**
 * openapi-spec.js — the internal (edge) OpenAPI document, gated to a logged-in
 * human.
 *
 * SECURITY — the edge spec describes the DB-facing service and is an operator
 * surface. Edge has no human auth chain of its own: req.user is reconstructed by
 * s2sVerify from the forwarded, S2S-verified identity headers. A caller with no
 * resolved identity (req.user null — e.g. a direct hit with no S2S key, which
 * s2sVerify already rejects) or a machine principal (req.user.role
 * 'service_account') receives 401. Only a forwarded human identity is served.
 *
 * MOUNT ORDER — must be mounted AFTER s2sVerify so req.user is populated.
 */
const { getEdgeSpec } = require('../shared/openapi');
const { apiError } = require('../shared/helpers');

/**
 * Mount the gated internal (edge) OpenAPI JSON route onto the edge app.
 * @param {import('express').Express} app
 */
function mountEdgeInternalSpec(app) {
  app.get('/edge/openapi.json', (req, res) => {
    if (!req.user || req.user.role === 'service_account') {
      const err = apiError('Unauthorized', 'UNAUTHORIZED', 401);
      return res.status(err.status).json(err.body);
    }
    return res.json(getEdgeSpec());
  });
}

module.exports = { mountEdgeInternalSpec };
