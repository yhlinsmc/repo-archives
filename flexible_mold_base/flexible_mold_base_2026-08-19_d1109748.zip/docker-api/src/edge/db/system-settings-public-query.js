'use strict';

/**
 * system-settings-public-query.js
 *
 * Reads the small, hardcoded set of `system_settings` rows that are safe to
 * expose to unauthenticated clients (login page brand, etc.). The allowlist
 * lives in code (not env, not prefix-match, not config-table) so adding a
 * new public key always requires a code edit + security review.
 *
 * SECURITY: defense-in-depth via two filters at row-read time:
 *   1. `isSensitiveKey()` — exact match against the project's
 *      settings-crypto sensitive-key registry.
 *   2. `looksSensitive()` — heuristic regex catching common sensitive-key
 *      shapes: secret, password, passwd, token, credential, private_key,
 *      encryption_key, api_key, access_key, ^pwd$, ^pw$. Note: a bare
 *      "key" as a substring is NOT matched — only the prefixed forms above.
 *      A standalone key named `signing_key` would NOT be filtered by this
 *      heuristic (rely on the allowlist boundary for those).
 * The allowlist itself stays the primary boundary; these are belt + braces.
 */

const { isSensitiveKey } = require('../../shared/lib/settings-crypto');

// Frozen so a mistaken `.push()` blows up at write site rather than silently
// expanding the public surface.
//
// Each entry is a deliberate decision:
//   - `app_name`              login-page brand display
//   - `session_timeout_minutes` auto-logout watcher needs this value pre-login
//                             so the session timer is correct on first
//                             authenticated request. Numeric, non-sensitive.
const PUBLIC_KEYS_ALLOWLIST = Object.freeze([
  'app_name',
  'session_timeout_minutes',
]);

// SECURITY: heuristic deny pattern — covers common sensitive-shape names
// (clientSecret, db_password, api_token, oauth_credential, encryption_key, …).
// Substring match by design — false positives are acceptable; false negatives
// are not. The pattern intentionally requires a known prefix before "key"
// (private_key, api_key, …) so innocuous names like "lockout_minutes" don't
// trip — but that means a standalone "signing_key" would also pass; rely on
// the allowlist for those.
const SENSITIVE_KEY_PATTERN = /(secret|password|passwd|token|credential|private[_-]?key|encryption[_-]?key|api[_-]?key|access[_-]?key|^pwd$|^pw$)/i;

function looksSensitive(key) {
  if (typeof key !== 'string') return true; // refuse non-string keys outright
  return SENSITIVE_KEY_PATTERN.test(key);
}

/**
 * Read the allowlisted public system_settings rows.
 *
 * @param {object} pool - DB pool with `.ro` namespace
 * @param {(name: string) => string} t - table-name resolver (handles prefix)
 * @param {string} systemSettingsTable - logical table name (TABLES.SYSTEM_SETTINGS)
 * @param {object} [opts]
 * @param {(msg: string, meta?: object) => void} [opts.onSensitiveLeak] -
 *   called once per filtered row when a sensitive key sneaks into the
 *   allowlist. Default: structured logger warn.
 * @returns {Promise<{ values: Record<string, unknown>, maxUpdatedAt: string|null }>}
 */
async function readPublicSystemSettings(pool, t, systemSettingsTable, opts = {}) {
  if (!Array.isArray(PUBLIC_KEYS_ALLOWLIST) || PUBLIC_KEYS_ALLOWLIST.length === 0) {
    return { values: {}, maxUpdatedAt: null };
  }
  const placeholders = PUBLIC_KEYS_ALLOWLIST.map(() => '?').join(',');
  const sql =
    'SELECT `key`, value, updated_at FROM `' + t(systemSettingsTable) + '`' +
    ' WHERE `key` IN (' + placeholders + ')';
  const rows = await pool.ro.query(sql, [...PUBLIC_KEYS_ALLOWLIST]);

  const values = {};
  let maxUpdatedAt = null;
  const onLeak = opts.onSensitiveLeak;
  for (const row of rows) {
    if (isSensitiveKey(row.key) || looksSensitive(row.key)) {
      // SECURITY: allowlist should never include sensitive keys. If either
      // double-gate fires, the allowlist is broken — surface it but never
      // leak the value.
      if (onLeak) onLeak(row.key);
      continue;
    }
    let parsed = row.value;
    if (typeof parsed === 'string') {
      try { parsed = JSON.parse(parsed); } catch { /* keep raw string */ }
    }
    values[row.key] = parsed;
    if (row.updated_at && (!maxUpdatedAt || row.updated_at > maxUpdatedAt)) {
      maxUpdatedAt = row.updated_at;
    }
  }
  return { values, maxUpdatedAt };
}

module.exports = { readPublicSystemSettings, PUBLIC_KEYS_ALLOWLIST, looksSensitive };
