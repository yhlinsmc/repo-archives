/**
 * dev-https.js — Dev HTTPS server with self-signed certs.
 *
 * Extracted from index-infra.js for single-responsibility.
 * Loads localhost certs from .devcontainer/certs/ when available,
 * otherwise falls back to plain HTTP.
 */
const path = require('path');
const fs = require('fs');
const https = require('https');

const DEV_CERT_DIR = path.join(__dirname, '..', '..', '..', '.devcontainer', 'certs');
const CERT_PATH = path.join(DEV_CERT_DIR, 'dev.cert');
const KEY_PATH = path.join(DEV_CERT_DIR, 'dev.key');

/**
 * Create an HTTP or HTTPS server depending on cert availability.
 *
 * @param {import('express').Express} app
 * @returns {{ server: import('http').Server | import('https').Server, useHttps: boolean }}
 */
function createServer(app) {
  const useHttps = fs.existsSync(CERT_PATH) && fs.existsSync(KEY_PATH);

  const server = useHttps
    ? https.createServer({ key: fs.readFileSync(KEY_PATH), cert: fs.readFileSync(CERT_PATH) }, app)
    : app;

  return { server, useHttps };
}

module.exports = { createServer };
