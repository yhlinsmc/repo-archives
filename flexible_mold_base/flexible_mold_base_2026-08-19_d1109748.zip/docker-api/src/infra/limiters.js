/**
 * limiters.js — Rate limiter factory + all limiter definitions.
 *
 * Extracted from index-infra.js for single-responsibility.
 * Centralises all rate-limit declarations so the main entry stays thin.
 */
const rawRateLimit = require('express-rate-limit');
const { ipKeyGenerator } = require('express-rate-limit');
const { apiError } = require('../shared/helpers');
const { logger: rootLogger } = require('../shared/lib/logger');
const { getRateLimitSnapshot, maybeRefresh } = require('./lib/rate-limit-config-cache');
const logger = rootLogger.child({ module: 'limiters' });

/**
 * createLimiter — rate-limit factory that honours the DISABLE_RATE_LIMIT
 * env var. When DISABLE_RATE_LIMIT=true the returned middleware is a
 * pass-through, which is the ergonomic setting for E2E runs and local
 * development. Production deployments must leave the flag unset.
 */
const RATE_LIMIT_DISABLED = process.env.DISABLE_RATE_LIMIT === 'true';

function rateLimit(options) {
  if (RATE_LIMIT_DISABLED) {
    return (_req, _res, next) => next();
  }
  return rawRateLimit(options);
}

if (RATE_LIMIT_DISABLED) {
  logger.warn('DISABLE_RATE_LIMIT=true — all rate limiters are pass-through. Do not use in production.');
}

function bypassWhenAuthenticated(req) {
  return Boolean(req.user || req.session?.user);
}

// `Number(env) || default` would treat `0` as falsy, silently restoring the
// default and ignoring an operator who set the limit to 0 to lock down a
// path. Parse + finite-check + non-negative guard so 0 means "block all".
function readLimit(envName, defaultMax) {
  const raw = process.env[envName];
  if (raw === undefined || raw === '') return defaultMax;
  const n = Number(raw);
  return Number.isFinite(n) && n >= 0 ? n : defaultMax;
}

// Like readLimit but STRICTLY POSITIVE. For a rate-limit windowMs, 0 is invalid:
// express-rate-limit v8 throws ERR_ERL_WINDOW_MS on windowMs < 1, and a near-zero
// window makes the MemoryStore reset almost every ms — silently defeating
// throttling. The AUTHORITATIVE guard is boot-rejection: config-schema.js marks
// RATE_LIMIT_SETUP_WINDOW_MS as `.positive()`, so validateConfig() fails fast at
// startup (JWT_SECRET-style) before this ever runs on a validated deployment.
// This helper is a defense-in-depth backstop for NON-validated code paths only
// (SKIP_CONFIG_VALIDATION=1 dev boots, direct unit construction): 0 / negative /
// NaN coerce to the default so the limiter can never be built with an illegal
// window. The zero-means-block-all semantic belongs to `max` (readLimit) only.
function readPositive(envName, defaultValue) {
  const raw = process.env[envName];
  if (raw === undefined || raw === '') return defaultValue;
  const n = Number(raw);
  return Number.isFinite(n) && n > 0 ? n : defaultValue;
}

// resolveRateLimit — DB > env > default. `fallback` already encodes env>default
// (it is a readLimit(envName, default) result). The DB value comes from the
// infra stale-while-revalidate snapshot; reading it is a pure sync property
// access — safe to call from a per-request limiter `max` function.
function resolveRateLimit(snapshotKey, fallback) {
  const v = getRateLimitSnapshot()[snapshotKey];
  return (typeof v === 'number' && v >= 0) ? v : fallback;
}

// One-line non-blocking refresh tick mounted before the editable limiters.
function rateLimitRefreshTick(_req, _res, next) { maybeRefresh(); next(); }

function bypassGeneralLimiter(req) {
  return bypassWhenAuthenticated(req) ||
    req.path === '/setup/db-status' ||
    req.originalUrl === '/api/setup/db-status';
}

// Classify a request to the /api/api-connectors surface for rate-limiting.
// `path` is mount-relative (e.g. "/:id/fetch", "/import", "/<uuid>"). Dispatch
// (POST .../fetch) has its own per-user budget; every other MUTATING method is a
// write (create / update / delete / clone / import / reassign) — these bypass
// generalLimiter's authenticated-skip, so without a budget an authed token could
// drive unbounded id-enumeration / row-minting. Reads (GET) stay unlimited.
// Pure + exported so the routing decision is unit-tested without an HTTP harness.
function connectorLimiterKind(method, path) {
  // `\/?$` so a trailing-slash dispatch (POST .../fetch/, which Express's
  // non-strict router still routes to the fetch handler) is counted against the
  // fetch budget, not misclassified as a write — otherwise it could evade a
  // fetch limit set tighter than the write limit.
  if (method === 'POST' && /\/fetch\/?$/.test(path)) return 'fetch';
  if (method === 'POST' || method === 'PUT' || method === 'PATCH' || method === 'DELETE') return 'write';
  return null;
}

// Classify a request to the /api/flow-recipes family for rate-limiting.
// `path` is mount-relative. Dispatch (POST .../dispatch) has its own per-user
// budget because a single "Build flow" click can trigger an outbound call; every
// other mutating method (create / update / delete / approve) gets a separate
// write budget. Reads (GET) stay unlimited so the generalLimiter's
// authenticated-skip remains the correct policy for them.
// Pure + exported so the routing decision is unit-tested without an HTTP harness.
function flowRecipeLimiterKind(method, path) {
  // `\/?$` mirrors connectorLimiterKind's trailing-slash guard so a POST
  // to `.../dispatch/` counts against the dispatch budget, not the write budget.
  if (method === 'POST' && /\/dispatch\/?$/.test(path)) return 'dispatch';
  // Server-run triggers outbound step dispatches — budget it the same as dispatch,
  // not as a plain write, so one "Run flow" click cannot exhaust the write quota.
  if (method === 'POST' && /\/run\/?$/.test(path)) return 'dispatch';
  if (method === 'POST' || method === 'PUT' || method === 'PATCH' || method === 'DELETE') return 'write';
  return null;
}

// Classify a request as an ownership claim/release. `path` is mount-relative
// (e.g. "/<uuid>/claim", "/<uuid>/release"). These POSTs each open a row-locking
// transaction and are authed (editor/admin), so they bypass generalLimiter's
// authenticated-skip — without a dedicated budget an authed token could spam
// them to drive lock-wait pressure. Pure + exported so the routing decision is
// unit-tested without an HTTP harness.
function isClaimReleaseRequest(method, path) {
  return method === 'POST' && /\/(claim|release)\/?$/.test(path);
}

const STANDARD_RATE_LIMIT_MESSAGE = apiError(
  'Too many requests. Please try again later.',
  'RATE_LIMITED',
  429,
).body;

// ── Limiter definitions ─────────────────────────────────────────────────────

// max uses readLimit (not `Number(env) || default`) so an explicit
// `RATE_LIMIT_SETUP_MAX=0` is honored fail-closed (express-rate-limit v8 treats
// max:0 as block-all — 429 on the first /api/setup/* call, NOT "no limiter"),
// matching the DIAG/STATUS/etc. limiters. windowMs uses readPositive as a
// backstop — a 0/invalid window is authoritatively REJECTED at startup by the
// `.positive()` Zod guard on RATE_LIMIT_SETUP_WINDOW_MS (fail-fast boot, before
// this runs); the backstop only covers SKIP_CONFIG_VALIDATION dev paths. Default
// stays 10/5min — the conservative AIRGAP no-override value; per-environment
// overlays raise it via ConfigMap.
const setupLimiter = rateLimit({
  windowMs: readPositive('RATE_LIMIT_SETUP_WINDOW_MS', 5 * 60 * 1000),
  max: readLimit('RATE_LIMIT_SETUP_MAX', 10),
  standardHeaders: true,
  legacyHeaders: false,
  message: STANDARD_RATE_LIMIT_MESSAGE,
});

/**
 * Mount security-sensitive rate limiters on the app.
 * Must be called BEFORE auth middleware so unauthenticated attack traffic is
 * rejected before it can reach forwarded edge routes.
 *
 * @param {import('express').Express} app
 */
function mountPreAuthLimiters(app) {
  const authLoginLimiter = rateLimit({
    windowMs: Number(process.env.RATE_LIMIT_AUTH_WINDOW_MS) || 15 * 60 * 1000,
    max: Number(process.env.RATE_LIMIT_AUTH_MAX) || 20,
    standardHeaders: true,
    legacyHeaders: false,
    message: apiError('Too many login attempts. Please try again later.', 'RATE_LIMITED', 429).body,
  });
  app.use('/api/auth/login', authLoginLimiter);
  app.use('/api/auth/sso-login', authLoginLimiter);

  const passwordLimiter = rateLimit({
    windowMs: Number(process.env.RATE_LIMIT_PASSWORD_WINDOW_MS) || 15 * 60 * 1000,
    max: Number(process.env.RATE_LIMIT_PASSWORD_MAX) || 5,
    standardHeaders: true,
    legacyHeaders: false,
    message: apiError('Too many password attempts. Please try again later.', 'RATE_LIMITED', 429).body,
  });
  app.use('/api/auth/change-password', passwordLimiter);
  app.use('/api/users/:id/reset-password', passwordLimiter);

  // SECURITY: admin-recovery endpoints get a DEDICATED bucket (NOT shared
  // with passwordLimiter). Sharing with /api/auth/login creates two asymmetric
  // DoS vectors:
  //   (a) operator arriving at recovery card already exhausted their budget
  //       from failed login attempts on the wrong auth mode, now blocked
  //       from the recovery path for 15 minutes mid-incident
  //   (b) attacker hammers /api/auth/login to exhaust the shared bucket,
  //       preventing a legitimate recovery attempt
  // Dedicated bucket + same 5/15min budget keeps the same attack-budget
  // profile without the cross-contamination.
  const recoveryLimiter = rateLimit({
    windowMs: Number(process.env.RATE_LIMIT_RECOVERY_WINDOW_MS) || 15 * 60 * 1000,
    max: Number(process.env.RATE_LIMIT_RECOVERY_MAX) || 5,
    standardHeaders: true,
    legacyHeaders: false,
    message: apiError('Too many recovery attempts. Please try again later.', 'RATE_LIMITED', 429).body,
  });
  // Mount on both recovery endpoints. Mounted on infra dispatcher so the
  // limiter fires BEFORE the request is forwarded to edge — prevents
  // direct-edge-reach bypass regardless of network posture.
  // recovery-status also gets rate-limited (security review HIGH-1):
  // an authenticated attacker could otherwise poll it indefinitely to
  // DoS the connection pool or confirm lockout state via information leak.
  app.use('/api/setup/promote-first-admin', recoveryLimiter);
  app.use('/api/setup/recovery-status', recoveryLimiter);

  app.use('/api/setup', (req, res, next) => {
    if (req.method === 'POST' && req.path === '/') {
      return setupLimiter(req, res, next);
    }
    return next();
  });
  app.use('/api/setup/test-db', setupLimiter);
  app.use('/api/setup/configure-db', setupLimiter);
  app.use('/api/setup/init-db', setupLimiter);
  app.use('/api/setup/create-schema', setupLimiter);
  app.use('/api/setup/seed', setupLimiter);
  app.use('/api/setup/create-admin', setupLimiter);
  app.use('/api/setup/re-probe-auth', setupLimiter);
  app.use('/api/setup/reset-config', setupLimiter);
  app.use('/api/setup/truncate-table', setupLimiter);
  app.use('/api/setup/drop-table', setupLimiter);

  // SECURITY: Public Integration API brute-force guard (spec §4.6). Every path
  // under /api/public/v1 is Bearer-gated; a wrong/unknown token is a 401. This
  // pre-auth IP limiter caps repeated FAILED requests from one source IP so an
  // attacker cannot grind the token space. `skipSuccessfulRequests` means ANY
  // response ≥400 under /api/public/v1 burns budget (an invalid token is the
  // dominant case; scoped 404s / validation_failed also count) — intentionally
  // broad, since the namespace is machine-only and a 4xx-heavy caller is abusive
  // regardless of the specific code. A legitimate high-volume reader (200s) is
  // never throttled here (its post-auth per-sub ceiling is createPublicApiLimiter).
  // NO `bypassWhenAuthenticated`: this tier is machine-only and must never inherit
  // the human-session skip. The 429 body speaks the public error model
  // ({ error: 'rate_limited' }), never the internal apiError envelope (which
  // carries meta.db_type/provider). standardHeaders still emits RateLimit-*/Retry-After.
  const failedResolveIpLimiter = rateLimit({
    windowMs: Number(process.env.RATE_LIMIT_PUBLIC_RESOLVE_FAIL_WINDOW_MS) || 15 * 60 * 1000,
    max: readLimit('RATE_LIMIT_PUBLIC_RESOLVE_FAIL_MAX', 100),
    standardHeaders: true,
    legacyHeaders: false,
    skipSuccessfulRequests: true,
    keyGenerator: (req) => `pub-resolve-fail:${ipKeyGenerator(req.ip)}`,
    handler: (_req, res, _next, options) => res.status(options.statusCode).json({ error: 'rate_limited' }),
  });
  // Mounted on the whole namespace, BEFORE the public routers (public-gate →
  // public-read), so the budget is enforced ahead of the gate's resolve call.
  app.use('/api/public/v1', failedResolveIpLimiter);
}

/**
 * createPublicApiLimiter — post-auth machine-tier limiter for the whole
 * /api/public/v1 surface (reads AND writes) [H3][H4]. Mounted once at the
 * namespace so reads and writes share a single per-account budget.
 *
 * SECURITY: this limiter has NO `skip` / NO `bypassWhenAuthenticated`. The app's
 * human limiters skip authenticated sessions, but machine traffic must NEVER
 * inherit that bypass — an authenticated integration token would otherwise call
 * unbounded. Keyed per service account (`req.machinePrincipal.sub`, set by the
 * upstream machine-tier gate); falls back to an IP bucket only for the
 * theoretically-unauthenticated case (which the gate already 401s). The 429 body
 * speaks the public error model (`{ error: 'rate_limited' }`), never the internal
 * apiError envelope (which would leak meta.db_type/provider). standardHeaders
 * still emits the RateLimit and Retry-After budget headers.
 *
 * @returns {import('express').RequestHandler}
 */
function createPublicApiLimiter() {
  return rateLimit({
    windowMs: Number(process.env.RATE_LIMIT_PUBLIC_READ_WINDOW_MS) || 60 * 1000,
    max: readLimit('RATE_LIMIT_PUBLIC_READ_MAX', 120),
    standardHeaders: true,
    legacyHeaders: false,
    // NOTE: the `pub-read:` key prefix is kept verbatim for bucket continuity —
    // reads existed first and now share this budget with writes; renaming the key
    // would silently reset every in-flight per-account counter on deploy.
    keyGenerator: (req) => {
      const sub = req.machinePrincipal?.sub;
      return sub ? `pub-read:${sub}` : `pub-read-ip:${ipKeyGenerator(req.ip)}`;
    },
    handler: (_req, res, _next, options) => res.status(options.statusCode).json({ error: 'rate_limited' }),
  });
}

/**
 * createOwnerLookupFailLimiter — anti-enumeration guard for the P3 create path's
 * optional `owner_username` lookup [P3-HIGH].
 *
 * SECURITY: `owner_username` is a username-existence probe (a valid owner → 201
 * vs an unknown owner → 400 owner_not_found distinguishes existence). This
 * limiter caps FAILED owner lookups per service account so the shared 120/min
 * budget cannot be spent probing the username space. `skipSuccessfulRequests`
 * means only a >=400 response burns budget, so a legitimate batch of creates
 * against a VALID owner (all 201) is never throttled here. The router mounts it
 * ONLY for requests that actually carry `owner_username`, so plain creates are
 * untouched. Keyed per service account; 429 speaks the public error model.
 *
 * @returns {import('express').RequestHandler}
 */
function createOwnerLookupFailLimiter() {
  return rateLimit({
    windowMs: Number(process.env.RATE_LIMIT_PUBLIC_OWNER_FAIL_WINDOW_MS) || 15 * 60 * 1000,
    max: readLimit('RATE_LIMIT_PUBLIC_OWNER_FAIL_MAX', 10),
    standardHeaders: true,
    legacyHeaders: false,
    skipSuccessfulRequests: true,
    keyGenerator: (req) => {
      const sub = req.machinePrincipal?.sub;
      return sub ? `pub-owner-fail:${sub}` : `pub-owner-fail-ip:${ipKeyGenerator(req.ip)}`;
    },
    handler: (_req, res, _next, options) => res.status(options.statusCode).json({ error: 'rate_limited' }),
  });
}

/**
 * createPublicDocsLimiter — authenticated-tier limiter for the customer-facing
 * documentation portal (/api/public-docs*, mounted in public-docs.js). Every
 * request that reaches this route already carries a resolved req.user (the
 * portal is mounted after the human auth middleware — see public-docs.js's
 * own mount-order contract), unlike diagnosticsLimiter/authModeLimiter (which
 * are reachable pre-login and SKIP already-authenticated sessions because
 * their purpose is to cap anonymous probing). This route has no anonymous
 * caller to protect against, so it deliberately does NOT set
 * `skip: bypassWhenAuthenticated` — that would exempt every request the
 * route actually serves. The cost being capped is serialising the public
 * document: the reference UI fetches it rather than receiving it inline, so a
 * page view spends TWO requests from this shared budget (the HTML shell, then
 * the document), and an authenticated low-trust account could otherwise force
 * that at unlimited rate — cheaper for the caller than for the server.
 * Generous 60/min budget — enough for a human reading docs (30 page views a
 * minute), not for scripted abuse. Per-user keying (falls back to IP) so one
 * busy reader cannot exhaust the budget for other users.
 *
 * WHAT "TWO REQUESTS PER VIEW" DOES NOT ACCOUNT FOR: every view spends them,
 * including a reload, a back-navigation and a restored tab, and the document's
 * 304 does not refund one — this limiter counts before the handler runs, so
 * revalidation saves bytes and not budget. That is a deliberate trade, argued
 * where the header is set (public-docs.js): a freshness window would remove the
 * requests but would also let a browser answer from cache after the session
 * that earned the response has ended. The 60 was not raised to pay for the
 * second request, because 30 views a minute is still far above a reading rate
 * and no measurement says otherwise.
 *
 * @returns {import('express').RequestHandler}
 */
function createPublicDocsLimiter() {
  return rateLimit({
    windowMs: Number(process.env.RATE_LIMIT_PUBLIC_DOCS_WINDOW_MS) || 60 * 1000,
    max: readLimit('RATE_LIMIT_PUBLIC_DOCS_MAX', 60),
    standardHeaders: true,
    legacyHeaders: false,
    keyGenerator: (req) => {
      // lint-allow: write-path-shapes a rate-limit bucket key, not a
      // column. Two spellings of one caller split their allowance across two
      // buckets, which loosens a limit rather than corrupting a row; the single
      // derivation this wants is deferred with the sites that do write a column.
      const userId = req.user?.id || req.user?.sub || req.session?.user?.id;
      return userId ? `user:${userId}` : `ip:${ipKeyGenerator(req.ip)}`;
    },
    message: STANDARD_RATE_LIMIT_MESSAGE,
  });
}

/**
 * createInternalSpecLimiter — authenticated-tier limiter for the internal
 * (infra) OpenAPI JSON route (/api/openapi.json, mounted in internal-spec.js).
 * Sibling of createPublicDocsLimiter, same shape and same "no anonymous
 * caller to protect" rationale (requirePortalAuth runs after this — every
 * request that reaches it already carries a resolved req.user), but its own
 * env knobs and bucket so an operator can tune the two surfaces
 * independently. getInfraSpec() is module-level memoized (shared/openapi.js),
 * so the per-request cost here is a cheap res.json() of a cached object, not
 * the "re-renders full spec, no caching" CPU concern that sized
 * createPublicDocsLimiter's 60/min — still given a dedicated budget rather
 * than left unlimited (security review MEDIUM, v3.2.484): the route
 * terminates the response directly, so it is unreachable by
 * mountAuthenticatedLimiters' generalLimiter regardless of mount order, and
 * generalLimiter's authenticated-skip would provide zero effective budget
 * for it anyway. Per-user keying (falls back to IP) so one busy caller
 * cannot exhaust the budget for other users.
 *
 * @returns {import('express').RequestHandler}
 */
function createInternalSpecLimiter() {
  return rateLimit({
    windowMs: Number(process.env.RATE_LIMIT_INTERNAL_SPEC_WINDOW_MS) || 60 * 1000,
    max: readLimit('RATE_LIMIT_INTERNAL_SPEC_MAX', 60),
    standardHeaders: true,
    legacyHeaders: false,
    keyGenerator: (req) => {
      // lint-allow: write-path-shapes a rate-limit bucket key, not a
      // column. Two spellings of one caller split their allowance across two
      // buckets, which loosens a limit rather than corrupting a row; the single
      // derivation this wants is deferred with the sites that do write a column.
      const userId = req.user?.id || req.user?.sub || req.session?.user?.id;
      return userId ? `user:${userId}` : `ip:${ipKeyGenerator(req.ip)}`;
    },
    message: STANDARD_RATE_LIMIT_MESSAGE,
  });
}

/**
 * Mount operator-traffic rate limiters after auth middleware.
 *
 * @param {import('express').Express} app
 */
function mountAuthenticatedLimiters(app) {
  app.use('/api/', rateLimitRefreshTick);

  const diagnosticsLimiter = rateLimit({
    windowMs: Number(process.env.RATE_LIMIT_DIAG_WINDOW_MS) || 60 * 1000,
    max: readLimit('RATE_LIMIT_DIAG_MAX', 150),
    standardHeaders: true,
    legacyHeaders: false,
    skip: bypassWhenAuthenticated,
    message: STANDARD_RATE_LIMIT_MESSAGE,
  });
  app.use('/api/auth/diagnostics', diagnosticsLimiter);

  const authModeLimiter = rateLimit({
    windowMs: 60 * 1000,
    max: readLimit('RATE_LIMIT_MODE_MAX', 100),
    standardHeaders: true,
    legacyHeaders: false,
    skip: bypassWhenAuthenticated,
    message: STANDARD_RATE_LIMIT_MESSAGE,
  });
  app.use('/api/auth/mode', authModeLimiter);

  const statusLimiter = rateLimit({
    windowMs: 60 * 1000,
    max: readLimit('RATE_LIMIT_STATUS_MAX', 600),
    standardHeaders: true,
    legacyHeaders: false,
    skip: bypassWhenAuthenticated,
    message: STANDARD_RATE_LIMIT_MESSAGE,
  });
  app.use('/api/setup/db-status', statusLimiter);

  // SECURITY: destructive engine endpoints (clear-table, truncate-table,
  // drop-table on /api/sync-schema/) must NOT inherit generalLimiter's
  // `bypassGeneralLimiter` (which skips authenticated requests). A stolen
  // admin token would otherwise allow unbounded XSS-chained destructive calls.
  // Mount BEFORE the general /api/ middleware so the budget is enforced
  // even when generalLimiter would have skipped. Per-user-id keying so
  // one compromised admin can't deny service to other admins.
  const destructiveOpsLimiter = rateLimit({
    windowMs: Number(process.env.RATE_LIMIT_DESTRUCTIVE_WINDOW_MS) || 15 * 60 * 1000,
    max: readLimit('RATE_LIMIT_DESTRUCTIVE_MAX', 5),
    standardHeaders: true,
    legacyHeaders: false,
    keyGenerator: (req) => {
      // lint-allow: write-path-shapes a rate-limit bucket key, not a
      // column. Two spellings of one caller split their allowance across two
      // buckets, which loosens a limit rather than corrupting a row; the single
      // derivation this wants is deferred with the sites that do write a column.
      const userId = req.user?.id || req.user?.sub || req.session?.user?.id;
      // SECURITY: when no user-id is available (unauthenticated probe),
      // delegate to express-rate-limit's `ipKeyGenerator` rather than raw
      // `req.ip`. v8 of express-rate-limit normalises IPv6 to a /64 subnet
      // so a client can't rotate within their address block to evade the
      // limiter, and avoids `ERR_ERL_KEY_GEN_IPV6` on raw IPv6 input.
      return userId ? `user:${userId}` : `ip:${ipKeyGenerator(req.ip)}`;
    },
    message: STANDARD_RATE_LIMIT_MESSAGE,
  });
  app.use('/api/sync-schema/clear-table', destructiveOpsLimiter);
  app.use('/api/sync-schema/truncate-table', destructiveOpsLimiter);
  app.use('/api/sync-schema/drop-table', destructiveOpsLimiter);
  // Orphan cleanup mutates user_templates payloads; cap admin throughput
  // so a compromised token cannot mass-strip keys before alarms fire.
  app.use('/api/schema/field-data-orphans', (req, res, next) => {
    if (req.method === 'DELETE') return destructiveOpsLimiter(req, res, next);
    return next();
  });
  // SECURITY: YAML overwrite is destructive (cascade-delete + re-insert 5 child
  // tables). Apply the same per-user budget. Skip dry-run probes and create-new
  // mode so users can iterate on the import dialog without burning the budget;
  // only mode=overwrite without dry_run consumes a slot.
  app.use('/api/schema/blueprint-import-yaml', (req, res, next) => {
    const isOverwrite = req.method === 'POST'
      && req.query?.mode === 'overwrite'
      && req.query?.dry_run !== 'true'
      && req.query?.dry_run !== '1';
    if (isOverwrite) return destructiveOpsLimiter(req, res, next);
    return next();
  });

  // SECURITY: POST /:id/fetch is non-admin (any authed data-entry user), so it
  // bypasses generalLimiter's authenticated-skip. A single "Fetch from API"
  // click on a table field fires one dispatch per selected row — without a
  // dedicated budget, a token could drive unbounded outbound calls. Mount
  // BEFORE the general /api/ middleware so the budget is enforced regardless
  // of generalLimiter's skip logic. Per-user-id keying so one compromised
  // credential can't exhaust the budget for other users. GET /usable is a
  // read-only projection and must stay unlimited.
  const perUserKey = (req) => {
    // lint-allow: write-path-shapes the same rate-limit bucket key as
    // the three above, and deferred with them.
    const userId = req.user?.id || req.user?.sub || req.session?.user?.id;
    return userId ? `user:${userId}` : `ip:${ipKeyGenerator(req.ip)}`;
  };
  const connectorFetchLimiter = rateLimit({
    windowMs: Number(process.env.RATE_LIMIT_CONNECTOR_FETCH_WINDOW_MS) || 60 * 1000,
    max: () => resolveRateLimit('connectorFetch', readLimit('RATE_LIMIT_CONNECTOR_FETCH_MAX', 60)),
    standardHeaders: true,
    legacyHeaders: false,
    keyGenerator: perUserKey,
    message: STANDARD_RATE_LIMIT_MESSAGE,
  });
  // SECURITY: connector WRITES (create / update / delete / clone / import /
  // reassign) are authed-only, so generalLimiter's authenticated-skip lets them
  // through unbounded — a compromised owner/admin session could enumerate ids and
  // mint many clones. Give the mutation surface its own per-user budget. Mounted
  // BEFORE the general /api/ middleware so the budget is enforced regardless of
  // generalLimiter's skip. Dispatch (POST .../fetch) keeps its separate budget.
  const connectorWriteLimiter = rateLimit({
    windowMs: Number(process.env.RATE_LIMIT_CONNECTOR_WRITE_WINDOW_MS) || 60 * 1000,
    max: () => resolveRateLimit('connectorWrite', readLimit('RATE_LIMIT_CONNECTOR_WRITE_MAX', 60)),
    standardHeaders: true,
    legacyHeaders: false,
    keyGenerator: perUserKey,
    message: STANDARD_RATE_LIMIT_MESSAGE,
  });
  app.use('/api/api-connectors', (req, res, next) => {
    const kind = connectorLimiterKind(req.method, req.path);
    if (kind === 'fetch') return connectorFetchLimiter(req, res, next);
    if (kind === 'write') return connectorWriteLimiter(req, res, next);
    return next();
  });

  // SECURITY: the admin feature-audit list/search surface (+ /event-types) runs
  // a LIKE %q% full-scan and is admin-only, so generalLimiter's
  // authenticated-skip leaves it uncapped — a stolen admin token could hammer
  // the scan. Give the whole mount its own per-user budget, enforced BEFORE the
  // general /api/ middleware. Per-user-id keying so one compromised admin can't
  // deny service to other admins.
  const auditSearchLimiter = rateLimit({
    windowMs: Number(process.env.RATE_LIMIT_AUDIT_SEARCH_WINDOW_MS) || 60 * 1000,
    max: () => resolveRateLimit('auditSearch', readLimit('RATE_LIMIT_AUDIT_SEARCH_MAX', 60)),
    standardHeaders: true,
    legacyHeaders: false,
    keyGenerator: perUserKey,
    message: STANDARD_RATE_LIMIT_MESSAGE,
  });
  app.use('/api/admin/feature-audit', auditSearchLimiter);

  // SECURITY: /api/query-proxy executes arbitrary admin SQL (SELECT / DML /
  // DDL) and /api/admin/privileges manages MariaDB grants. Both are admin-only,
  // so generalLimiter's authenticated-skip leaves them uncapped — a stolen
  // admin token could drive raw SQL or privilege mutations unbounded. One shared per-user budget across both
  // mounts, enforced BEFORE the general /api/ middleware. No skip: the
  // authenticated bypass is exactly the hole being closed. Per-user keying so
  // one compromised admin cannot deny service to other admins. query-proxy is an
  // interactive console (needs throughput), so this is an abuse ceiling, not the
  // tight destructiveOps budget.
  const adminOpsLimiter = rateLimit({
    windowMs: Number(process.env.RATE_LIMIT_ADMIN_OPS_WINDOW_MS) || 60 * 1000,
    max: readLimit('RATE_LIMIT_ADMIN_OPS_MAX', 240),
    standardHeaders: true,
    legacyHeaders: false,
    keyGenerator: perUserKey,
    message: STANDARD_RATE_LIMIT_MESSAGE,
  });
  app.use('/api/query-proxy', adminOpsLimiter);
  app.use('/api/admin/privileges', adminOpsLimiter);

  // SECURITY: prepare-wipe builds a full engine-data SQL dump on every call —
  // expensive. Give it a dedicated lenient per-user budget so it cannot be
  // hammered, without the 5/15min destructiveOpsLimiter blocking a normal
  // backup-then-wipe cycle. execute-wipe is intentionally NOT mounted under any
  // limiter: the X-Wipe-Token (one per fresh backup) + type-to-confirm are its
  // throttle.
  const wipePrepareLimiter = rateLimit({
    windowMs: Number(process.env.RATE_LIMIT_WIPE_PREPARE_WINDOW_MS) || 15 * 60 * 1000,
    max: readLimit('RATE_LIMIT_WIPE_PREPARE_MAX', 10),
    standardHeaders: true,
    legacyHeaders: false,
    keyGenerator: perUserKey,
    message: STANDARD_RATE_LIMIT_MESSAGE,
  });
  app.use('/api/sync-schema/prepare-wipe', wipePrepareLimiter);

  // SECURITY: execute-wipe is intentionally outside destructiveOpsLimiter (the
  // single-use token + type-to-confirm are the primary gate), but it must not
  // be fully uncapped — generalLimiter skips authenticated requests, so without
  // a dedicated fence an authed admin could loop the deletion path (and its
  // INFORMATION_SCHEMA scan) unbounded. Give it a tight per-user budget. No
  // authenticated-skip.
  const wipeExecuteLimiter = rateLimit({
    windowMs: Number(process.env.RATE_LIMIT_WIPE_EXECUTE_WINDOW_MS) || 15 * 60 * 1000,
    max: readLimit('RATE_LIMIT_WIPE_EXECUTE_MAX', 3),
    standardHeaders: true,
    legacyHeaders: false,
    keyGenerator: perUserKey,
    message: STANDARD_RATE_LIMIT_MESSAGE,
  });
  app.use('/api/sync-schema/execute-wipe', wipeExecuteLimiter);

  // SECURITY: ownership claim/release (hierarchy_nodes + transformers) each open
  // a row-locking transaction and are authed-only, so generalLimiter's
  // authenticated-skip leaves them uncapped — an authed editor could spam them
  // to drive lock-wait pressure on the ownership rows. Give the claim/release
  // surface its own per-user budget, enforced BEFORE the general /api/
  // middleware. Per-user-id keying so one credential can't deny service to
  // others. Reads and every other method on these mounts stay unaffected.
  // SECURITY: flow-recipe dispatch (POST .../dispatch) is reachable by any authed
  // data-entry user, so generalLimiter's authenticated-skip leaves it uncapped —
  // a single Build-flow click could drive unbounded outbound calls. Mirror the
  // connector fetch/write split: a tight per-user dispatch budget and a separate
  // per-user write budget (create/update/delete/approve on recipes/steps/runs).
  const flowDispatchLimiter = rateLimit({
    windowMs: Number(process.env.RATE_LIMIT_FLOW_DISPATCH_WINDOW_MS) || 60 * 1000,
    max: () => resolveRateLimit('flowDispatch', readLimit('RATE_LIMIT_FLOW_DISPATCH_MAX', 60)),
    standardHeaders: true, legacyHeaders: false, keyGenerator: perUserKey, message: STANDARD_RATE_LIMIT_MESSAGE,
  });
  const flowRecipeWriteLimiter = rateLimit({
    windowMs: Number(process.env.RATE_LIMIT_FLOW_WRITE_WINDOW_MS) || 60 * 1000,
    max: () => resolveRateLimit('flowWrite', readLimit('RATE_LIMIT_FLOW_WRITE_MAX', 60)),
    standardHeaders: true, legacyHeaders: false, keyGenerator: perUserKey, message: STANDARD_RATE_LIMIT_MESSAGE,
  });
  const flowGate = (req, res, next) => {
    const kind = flowRecipeLimiterKind(req.method, req.path);
    if (kind === 'dispatch') return flowDispatchLimiter(req, res, next);
    if (kind === 'write') return flowRecipeWriteLimiter(req, res, next);
    return next();
  };
  app.use('/api/flow-recipes', flowGate);
  app.use('/api/flow-recipe-steps', flowGate);
  app.use('/api/flow-recipe-runs', flowGate);
  // /api/flow-templates carries the reset-flow-link mutation — a POST → 'write'
  // kind, so it must share the flow write budget (the general limiter skips authed
  // callers, leaving it otherwise unbounded).
  app.use('/api/flow-templates', flowGate);

  // SECURITY: granting and revoking are authed-only writes on a permission
  // table, so generalLimiter's authenticated-skip leaves them uncapped. Each
  // write takes a connection and each grant is a row nobody else asked for;
  // the person directory is a bounded read but still a directory read. Per-user
  // keying so one credential cannot deny the surface to everyone else. Reads of
  // a subject's own grant list ride the same budget — they are the same mount
  // and the budget is generous.
  const grantWriteLimiter = rateLimit({
    windowMs: Number(process.env.RATE_LIMIT_GRANT_WINDOW_MS) || 60 * 1000,
    max: readLimit('RATE_LIMIT_GRANT_MAX', 60),
    standardHeaders: true,
    legacyHeaders: false,
    keyGenerator: perUserKey,
    message: STANDARD_RATE_LIMIT_MESSAGE,
  });
  app.use('/api/delegated-grants', grantWriteLimiter);
  // The trail's own write is a browser-driven append (producing output is a
  // client-side action), so it needs the same fence for the same reason. Its
  // reads ride the same budget — it is one mount and the budget is generous.
  app.use('/api/template-activity', grantWriteLimiter);

  const claimReleaseLimiter = rateLimit({
    windowMs: Number(process.env.RATE_LIMIT_CLAIM_RELEASE_WINDOW_MS) || 60 * 1000,
    max: readLimit('RATE_LIMIT_CLAIM_RELEASE_MAX', 60),
    standardHeaders: true,
    legacyHeaders: false,
    keyGenerator: perUserKey,
    message: STANDARD_RATE_LIMIT_MESSAGE,
  });
  const claimReleaseGate = (req, res, next) =>
    isClaimReleaseRequest(req.method, req.path) ? claimReleaseLimiter(req, res, next) : next();
  app.use('/api/schema/hierarchy_nodes', claimReleaseGate);
  app.use('/api/transformers', claimReleaseGate);

  const generalLimiter = rateLimit({
    windowMs: Number(process.env.RATE_LIMIT_GENERAL_WINDOW_MS) || 60 * 1000,
    max: () => resolveRateLimit('general', readLimit('RATE_LIMIT_GENERAL_MAX', 2000)),
    standardHeaders: true,
    legacyHeaders: false,
    skip: bypassGeneralLimiter,
    message: STANDARD_RATE_LIMIT_MESSAGE,
  });
  app.use('/api/', generalLimiter);
}

function mountLimiters(app) {
  mountPreAuthLimiters(app);
}

module.exports = {
  rateLimit,
  setupLimiter,
  bypassWhenAuthenticated,
  bypassGeneralLimiter,
  connectorLimiterKind,
  flowRecipeLimiterKind,
  isClaimReleaseRequest,
  resolveRateLimit,
  mountLimiters,
  mountPreAuthLimiters,
  mountAuthenticatedLimiters,
  createPublicApiLimiter,
  createOwnerLookupFailLimiter,
  createPublicDocsLimiter,
  createInternalSpecLimiter,
};
