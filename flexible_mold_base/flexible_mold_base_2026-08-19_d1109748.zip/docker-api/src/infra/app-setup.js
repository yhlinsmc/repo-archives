/**
 * app-setup.js — Express app bootstrap (helmet, cors, json, CSRF guard).
 *
 * Creates and configures the Express app instance for API-infra.
 */
// dotenv.config() is called in index-infra.js before any require —
// it must run before shared/config validates JWT_SECRET.
const path = require('path');
const express = require('express');
const cors = require('cors');
const {
  createStrictHelmet, createDocsHelmet, createScalarStaticRouter, getScalarCdnUrl, buildDocsFontOptions,
} = require('../shared/security');
const { getInfraSpec, escapeForInlineScript } = require('../shared/openapi');
const { DOCS_DISABLED_MESSAGE } = require('../shared/docs-disabled');
const { logger: rootLogger } = require('../shared/lib/logger');
const { createRequestId } = require('../shared/middleware/request-id');
const { createRequestLog } = require('../shared/middleware/request-log');
const { isPublicApiPath } = require('../shared/lib/public-api-path');
const logger = rootLogger.child({ module: 'api-infra' });

// ── Module-level constants ──────────────────────────────────────────────────
const SERVE_STATIC = process.env.SERVE_STATIC === 'true';
const DIST_PATH = SERVE_STATIC ? path.join(__dirname, '..', '..', 'dist') : null;
const PER_REQUEST_PATHS = ['/api/query-proxy', '/api/schema'];
const SCHEMA_ROUTABLE = ['/api/query-proxy', '/api/schema', '/api/sync-schema'];
// Infra-side self-hosted Scalar bundle mount. Module-scoped (not inline in
// createApp) so the public-docs portal can reuse the exact same asset URL —
// one source of truth avoids a drifting magic string across the two routes.
const SCALAR_MOUNT = '/api/scalar-assets';

// NOTE: dev-only CORS escape hatch for k3d local simulation. The flag is
// intentionally long + scary because if it ever lands in an AIRGAP overlay it
// would silently widen CORS to localhost. Module-load guard below makes that
// fail fast: production processes will refuse to boot rather than degrade.
const DEV_LOCALHOST_CORS_FLAG = 'DEV_LOCALHOST_CORS_ONLY_DO_NOT_SET_IN_PROD';
const DEV_LOCALHOST_CORS_ENABLED = process.env[DEV_LOCALHOST_CORS_FLAG] === 'true';
const DEV_LOCALHOST_CORS_ORIGINS = ['http://localhost:8130', 'http://localhost:8230'];

if (DEV_LOCALHOST_CORS_ENABLED && process.env.NODE_ENV === 'production') {
  throw new Error(
    `${DEV_LOCALHOST_CORS_FLAG} must not be 'true' in production. ` +
      'This flag exists only for local k3d simulation (port-forwards.sh) ' +
      'and would widen CORS to localhost:8130/8230 if it leaked into a prod ' +
      'manifest. Unset the env var or change NODE_ENV.',
  );
}

/**
 * Create and configure the Express app with security middleware.
 *
 * @returns {import('express').Express}
 */
function createApp() {
  const app = express();

  app.set('trust proxy', Number(process.env.TRUST_PROXY ?? 1));

  // Mint the correlation id first so every response — including ones a later
  // guard rejects — carries X-Request-Id.
  app.use(createRequestId());

  app.use(createStrictHelmet());

  // One access-log line per request, read at finish (after auth populates
  // req.user). Skip /health (k8s probe spam), favicon, and non-/api static.
  app.use(createRequestLog({
    skip: (path) => path === '/health' || path === '/favicon.ico' || !path.startsWith('/api'),
  }));

  // CORS origin resolution:
  //   1. CORS_ORIGINS (CSV) — explicit override, wins when set
  //   2. FRONTEND_URL       — single browser-origin allowlist for the
  //                           two-VirtualService k8s deploy (frontend host
  //                           differs from API host; infra serves API only)
  //   3. production default  — same-origin only (deny cross-origin). Warns.
  //   4. dev default         — reflect request origin (`true`).
  // Then, *additively*, DEV_LOCALHOST_CORS_ONLY_DO_NOT_SET_IN_PROD=true
  // appends localhost:8130 / 8230. The dev flag is additive on purpose: real
  // k3d zones already set FRONTEND_URL=https://zone*-fmb-web.localhost, so
  // making the dev flag a fallback branch would silently no-op. Module-load
  // guard above blocks the additive path from firing in NODE_ENV=production.
  let corsOrigin;
  if (process.env.CORS_ORIGINS) {
    corsOrigin = process.env.CORS_ORIGINS.split(',').map(s => s.trim());
  } else if (process.env.FRONTEND_URL) {
    corsOrigin = [process.env.FRONTEND_URL.replace(/\/$/, '')];
  } else if (process.env.NODE_ENV === 'production') {
    logger.warn('CORS_ORIGINS / FRONTEND_URL not set in production — same-origin only');
    corsOrigin = false;
  } else {
    corsOrigin = true;
  }

  if (DEV_LOCALHOST_CORS_ENABLED) {
    if (Array.isArray(corsOrigin)) {
      corsOrigin = [...corsOrigin, ...DEV_LOCALHOST_CORS_ORIGINS];
    } else {
      // corsOrigin was true (dev default) or false (prod same-origin, blocked
      // by module-load guard above). Either way coerce to the explicit
      // localhost-only allowlist so the dev flag actually narrows from the
      // open dev default. The whole reason to set the flag is to confine
      // CORS to the k3d port-forward origins.
      corsOrigin = [...DEV_LOCALHOST_CORS_ORIGINS];
    }
  }

  if (process.env.NODE_ENV !== 'production') {
    // NOTE: this log only emits when NODE_ENV != production
    // AND DEV_LOCALHOST_CORS_ONLY_DO_NOT_SET_IN_PROD=true. The internal
    // production cluster has NODE_ENV=production in configmap-shared.yaml
    // so this log never appears there — it is expected behaviour in LOCAL
    // k3d dev only.
    logger.info(
      { enabled: DEV_LOCALHOST_CORS_ENABLED, origins: DEV_LOCALHOST_CORS_ORIGINS },
      `[cors] DEV localhost origins ${DEV_LOCALHOST_CORS_ENABLED ? 'ENABLED (additive)' : 'disabled'}`,
    );
  }

  app.use(cors({
    origin: corsOrigin,
    credentials: true,
    maxAge: 600,
    // Cross-origin browsers can only read whitelisted response headers; expose
    // X-Request-Id so the frontend can surface the trace code on errors,
    // Content-Disposition so header-driven export filenames (blueprint YAML)
    // survive a cross-origin fetch, and X-Wipe-Token so prepare-wipe can hand
    // the browser the token that gates execute-wipe.
    exposedHeaders: ['X-Request-Id', 'Content-Disposition', 'X-Wipe-Token'],
  }));
  // SECURITY [P2b]: the Public Integration API parses its own body AFTER the
  // Bearer gate (mountPublicNamespace) so an unauthenticated caller can never
  // distinguish states via a pre-auth body-parse error. Skip it here — req.path
  // at the app level is the full path, so the segment-bounded isPublicApiPath
  // applies directly.
  const jsonParser = express.json({ limit: '10mb' });
  app.use((req, res, next) => {
    if (isPublicApiPath(req.path)) return next();
    return jsonParser(req, res, next);
  });

  // CSRF guard
  app.use('/api', (req, res, next) => {
    if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();
    // SECURITY [P2b]: the Public Integration API enforces content-type AFTER the
    // Bearer gate (mountPublicNamespace) so a pre-auth non-JSON POST cannot leak a
    // distinguishing 415. This guard is mounted at '/api', so req.path here is
    // mount-relative ('/public/v1/...'); match that, segment-bounded.
    if (req.path === '/public/v1' || req.path.startsWith('/public/v1/')) return next();
    if (req.path === '/auth/callback') return next();
    const contentLength = parseInt(req.headers['content-length'] || '0', 10);
    if (contentLength === 0 && !req.headers['content-type']) return next();
    const ct = (req.headers['content-type'] || '').toLowerCase();
    if (ct.startsWith('application/json')) return next();
    // NOTE: YAML round-trip blueprint import accepts text/yaml bodies.
    // The CSRF concern (browser <form> only emits 3 enctypes —
    // application/x-www-form-urlencoded, multipart/form-data, text/plain)
    // is not loosened here: text/yaml requires a custom XHR/fetch with
    // explicit Content-Type, which CORS preflights, so a malicious
    // cross-origin form cannot forge it.
    if (
      req.path === '/schema/blueprint-import-yaml'
      && (ct.startsWith('text/yaml') || ct.startsWith('application/yaml') || ct.startsWith('application/x-yaml'))
    ) {
      return next();
    }
    return res.status(415).json({
      success: false,
      error: 'Unsupported Media Type: Content-Type must be application/json',
    });
  });

  // ── API Documentation ─────────────────────────────────────────────────────
  // Self-hosted Scalar: serve bundle from node_modules, route-scoped relaxed CSP.
  // The dev-only /api/docs UI is disabled in production. The raw /api/openapi.json
  // route is NOT mounted here — it is a login-gated operator surface mounted in
  // index-infra after the human auth middleware (see mountInternalSpec).
  app.use(createScalarStaticRouter(SCALAR_MOUNT));
  if (process.env.NODE_ENV !== 'production') {
    try {
      const { apiReference } = require('@scalar/express-api-reference');
      const docsHelmet = createDocsHelmet();
      // Escaped for the same reason the public portal is: Scalar serialises this
      // object into an inline <script> under a CSP relaxed to 'unsafe-inline',
      // so a `</script` or `<!--` in any annotation would break the page out of
      // its own script tag. Dev-only surface, same sink.
      app.use('/api/docs', docsHelmet, apiReference(escapeForInlineScript({
        cdn: getScalarCdnUrl(SCALAR_MOUNT),
        // Same override the public portal gets: createDocsHelmet() pins
        // `font-src 'self'` on every docs page, so a page without it asks for a
        // font it is then not allowed to fetch, and falls back to a system one —
        // and without the paired switch it keeps asking for the external faces.
        ...buildDocsFontOptions(SCALAR_MOUNT),
        spec: { content: getInfraSpec() },
      })));
    } catch (err) {
      logger.warn({ err: err.message }, 'Scalar not available — /api/docs disabled');
    }
  } else {
    app.get('/api/docs', (_req, res) => res.status(200).json({
      message: DOCS_DISABLED_MESSAGE,
    }));
  }

  return app;
}

module.exports = {
  createApp,
  SERVE_STATIC,
  DIST_PATH,
  PER_REQUEST_PATHS,
  SCHEMA_ROUTABLE,
  SCALAR_MOUNT,
};
