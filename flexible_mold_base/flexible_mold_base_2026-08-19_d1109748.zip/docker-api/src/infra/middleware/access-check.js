/**
 * access-check.js — Infra-side access check middleware (S2S to edge).
 *
 * Enforces default-deny + allowlist via a POST to /edge/platform/access-check.
 * Active only when auth_mode=keycloak and the user is not admin.
 *
 * NOTE: auth_mode is fetched from edge via /edge/internal/system/auth-mode
 * rather than importing the pool (infra-talks-to-edge-only rule). When edge
 * is unreachable on the mode probe, we fail closed (treat as denied) — same
 * posture as the access-check S2S failure mode.
 *
 * Exemptions (handled by the caller in index-infra.js, not here):
 *   /health, /api/setup, /api/auth/mode, /api/auth/sso-login,
 *   /api/auth/callback, /api/auth/logout, /api/auth/me, /api/auth/diagnostics
 */

const { logger: rootLogger } = require('../../shared/lib/logger');
const { apiError } = require('../../shared/helpers');
const { resolveAuthMode } = require('../../shared/config');
const { buildS2sHeaders } = require('../../shared/middleware/s2s-auth');
const { fetchAuthMode, EdgeUnreachable, EdgeTimeout, EdgeAuthFailed, getEdgeBaseUrl } = require('../lib/edge-state-client');

const logger = rootLogger.child({ module: 'access-check-middleware' });

function isEdgeUnreachable(err) {
  return err instanceof EdgeUnreachable || err instanceof EdgeTimeout || err instanceof EdgeAuthFailed;
}

async function accessCheckMiddleware(req, res, next) {
  let mode;
  try {
    const result = await fetchAuthMode(req.user || null, { reqId: req.id });
    mode = result.auth_mode || resolveAuthMode();
  } catch (err) {
    if (isEdgeUnreachable(err)) {
      // Edge unreachable on auth_mode probe — fail closed if route was
      // reaching access-check (would only happen for protected routes
      // that bypassed the pool-gate). 503 preserves k8s observability.
      logger.error({ err: err.message, code: err.code }, 'edge unreachable during access-check auth-mode probe');
      const e = apiError('Edge unreachable', 'EDGE_UNREACHABLE', 503, {
        details: { hint_code: 'edge_unreachable' },
      });
      return res.status(e.status).json(e.body);
    }
    logger.warn({ err }, 'access-check auth-mode fallback to env');
    mode = resolveAuthMode();
  }
  if (mode !== 'keycloak') return next();

  if (!req.user) return next();
  if (req.user.role === 'admin') return next();

  try {
    const s2sHeaders = buildS2sHeaders(req.user);
    const resp = await fetch(`${getEdgeBaseUrl()}/edge/platform/access-check`, {
      method: 'POST',
      headers: {
        ...s2sHeaders,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        email: req.user.email || null,
        deptid: req.user.deptid || null,
        role: req.user.role || null,
      }),
      signal: AbortSignal.timeout(5000),
    });

    if (!resp.ok) {
      logger.error({ status: resp.status }, 'Failed to invoke access-check S2S call status=' + resp.status);
      const e = apiError('Access check failed', 'ACCESS_CHECK_ERROR', 500);
      return res.status(e.status).json(e.body);
    }

    const body = await resp.json();
    if (body.data?.allowed) {
      return next();
    }

    const e = apiError('Access denied. Contact your administrator for access.', 'ACCESS_DENIED', 403);
    return res.status(e.status).json(e.body);
  } catch (err) {
    logger.error({ err }, 'Failed to invoke access-check S2S call (exception)');
    const e = apiError('Access check failed', 'ACCESS_CHECK_ERROR', 500);
    res.status(e.status).json(e.body);
  }
}

module.exports = { accessCheckMiddleware };
