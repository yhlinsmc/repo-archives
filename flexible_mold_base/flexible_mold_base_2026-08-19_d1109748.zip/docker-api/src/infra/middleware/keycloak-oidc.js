/**
 * keycloak-oidc.js — express-openid-connect middleware with auth_mode gate.
 *
 * This middleware is mounted conditionally in index.js. When auth_mode is
 * 'keycloak', it initialises the OIDC session layer (express-openid-connect)
 * as a stateless encrypted-cookie session. When auth_mode is 'local',
 * this middleware is a no-op pass-through.
 *
 * SESSION STORAGE (why stateless cookies, not a server-side store):
 * The infra pod is single-replica and ArgoCD auto-syncs on every merge, so any
 * in-process store (the former MemoryStore) was wiped on every deploy and every
 * user was forced to re-login. express-openid-connect's default session is a
 * stateless encrypted cookie: the token set (id_token/access_token/refresh_token)
 * is encrypted (dir / A256GCM JWE, key derived from KEYCLOAK_SECRET) and stored
 * client-side, auto-chunked across cookies when it exceeds the 4KB per-cookie
 * limit. Because the encryption key is a stable env var, the session survives
 * pod restarts by construction — no server-side store, no new dependency, and
 * `infra-talks-to-edge-only` is respected (infra reaches no store/DB). Server-side
 * revocation still holds: access tokens are short-lived and every refresh is
 * validated against Keycloak; idpLogout clears the Keycloak session on logout.
 *
 * Middleware ordering (enforced in index.js):
 *   keycloak-oidc.js → auth.js → access-check → routes
 *
 * IMPORTANT: authRequired is set to false (passive mode) so unauthenticated
 * requests pass through to auth.js for JWT handling. Only /api/auth/login
 * triggers the OIDC redirect.
 */

const { auth } = require('express-openid-connect');
const { resolveAuthMode } = require('../../shared/config');
const { logger: rootLogger } = require('../../shared/lib/logger');
const { notifyFreshLogin } = require('../lib/oidc-fresh-login');
const logger = rootLogger.child({ module: 'keycloak-oidc' });

/**
 * Validate Keycloak connectivity and CA cert at startup.
 * Runs asynchronously — logs results but does not block startup.
 *
 * @param {string} issuerBaseURL
 */
function validateKeycloakOnInit(issuerBaseURL) {
  const caCertPath = process.env.KEYCLOAK_CA_CERT_PATH;

  // Check CA cert validity (synchronous)
  if (caCertPath) {
    try {
      const fs = require('fs');
      fs.accessSync(caCertPath, fs.constants.R_OK);
      const content = fs.readFileSync(caCertPath, 'utf-8');
      if (content.includes('-----BEGIN CERTIFICATE-----')) {
        // NOTE: `caCertPath` binding (not bare `path`) keeps the operator-known
        // env var visible for TLS/CA debug; intentionally not redacted.
        logger.info({ caCertPath }, 'CA cert is valid and readable');
      } else {
        // NOTE: `caCertPath` binding; intentionally not redacted (operator-known env var).
        logger.error({ caCertPath }, 'Failed to validate Keycloak CA cert (file does not contain a PEM certificate)');
        logger.error('Hint: Ensure the file contains a PEM-encoded certificate starting with -----BEGIN CERTIFICATE-----');
      }
    } catch (err) {
      // NOTE: `caCertPath` binding; intentionally not redacted (operator-known env var).
      logger.error({ caCertPath, err }, 'Failed to read Keycloak CA cert');
      logger.error('Hint: Check that KEYCLOAK_CA_CERT_PATH points to an existing, readable file.');
    }
  }

  // Check issuer URL reachability (async, non-blocking)
  const discoveryUrl = `${issuerBaseURL}/.well-known/openid-configuration`;
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 5000);

  fetch(discoveryUrl, { signal: controller.signal })
    .then(resp => {
      clearTimeout(timeout);
      if (resp.ok) {
        logger.info({ issuerBaseURL }, 'Keycloak issuer is reachable');
      } else {
        logger.error({ status: resp.status, discoveryUrl }, 'Failed to reach Keycloak issuer discoveryUrl=' + discoveryUrl + ' status=' + resp.status);
        logger.error('Hint: Verify KEYCLOAK_ISSUER_BASE_URL is correct and the Keycloak server is running.');
      }
    })
    .catch(err => {
      clearTimeout(timeout);
      const isTimeout = err.name === 'AbortError';
      if (isTimeout) {
        logger.error({ discoveryUrl }, 'Failed to reach Keycloak issuer discoveryUrl=' + discoveryUrl + ' (timeout after 5s)');
        logger.error('Hint: Check network connectivity to the Keycloak server. In AIRGAP environments, verify the internal DNS/IP is correct.');
      } else {
        logger.error({ err, discoveryUrl }, 'Failed to reach Keycloak issuer discoveryUrl=' + discoveryUrl);
        if (err.code === 'UNABLE_TO_VERIFY_LEAF_SIGNATURE' || err.code === 'CERT_HAS_EXPIRED') {
          logger.error('Hint: TLS certificate issue. Set NODE_EXTRA_CA_CERTS to your CA cert path, or check KEYCLOAK_CA_CERT_PATH.');
        } else if (err.code === 'ECONNREFUSED') {
          logger.error('Hint: Connection refused. Ensure Keycloak is running and the port is correct in KEYCLOAK_ISSUER_BASE_URL.');
        } else if (err.code === 'ENOTFOUND') {
          logger.error('Hint: Hostname not found. Check the domain in KEYCLOAK_ISSUER_BASE_URL and DNS configuration.');
        } else {
          logger.error('Hint: Check KEYCLOAK_ISSUER_BASE_URL, network connectivity, and firewall rules.');
        }
      }
    });
}

/**
 * HIGH-1: Validate a redirect URL to prevent open redirect attacks.
 * Only allows relative paths or URLs whose origin matches FRONTEND_URL/BASE_URL.
 *
 * @param {string|undefined} url
 * @returns {boolean}
 */
function _isSafeRedirectUrl(url) {
  if (!url) return false;
  // Relative paths are always safe
  if (url.startsWith('/') && !url.startsWith('//')) return true;
  try {
    const parsed = new URL(url);
    // Only allow http/https protocols
    if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') return false;
    // Validate against known origins
    const origins = [
      process.env.FRONTEND_URL,
      process.env.BASE_URL,
    ];
    // Only allow localhost origins in non-production (dev/test)
    if (process.env.NODE_ENV !== 'production') {
      const port = process.env.PORT || 3200;
      origins.push(`http://localhost:${port}`, `https://localhost:${port}`);
      origins.push('http://localhost:3000', 'https://localhost:3000');
    }
    const allowedOrigins = origins
      .filter(Boolean)
      .map(u => { try { return new URL(u).origin; } catch { return null; } })
      .filter(Boolean);
    return allowedOrigins.includes(parsed.origin);
  } catch {
    return false;
  }
}

/**
 * Build the post-logout redirect URL.
 * Returns FRONTEND_URL + '/login' if safe, otherwise '/login'.
 */
function _buildPostLogoutUrl() {
  const frontendUrl = process.env.FRONTEND_URL;
  if (frontendUrl && _isSafeRedirectUrl(frontendUrl)) {
    return `${frontendUrl.replace(/\/$/, '')}/login`;
  }
  return '/login';
}

/**
 * Build the OIDC middleware stack (session + auth).
 * Returns an array of middleware functions to mount via app.use().
 *
 * @returns {import('express').RequestHandler[]}
 */
function buildKeycloakMiddleware() {
  const issuerBaseURL = process.env.KEYCLOAK_ISSUER_BASE_URL;
  const clientID = process.env.KEYCLOAK_CLIENT_ID;
  const clientSecret = process.env.KEYCLOAK_CLIENT_SECRET;
  const secret = process.env.KEYCLOAK_SECRET;

  const isProduction = process.env.NODE_ENV === 'production';

  // KEYCLOAK_SECRET is now the sole protector of the cookie-borne encrypted
  // token set, so validate it strictly. Both failure branches fail CLOSED
  // (return [] → no OIDC middleware → no session cookies issued → nobody can
  // log in), so a bad/absent secret can never produce an insecurely-keyed
  // session. In production the log is escalated to error so a misconfigured
  // deploy is loud; in dev it stays a warn (login is simply disabled until the
  // secret is provided — the only dev fallback, and it issues no sessions).
  if (!issuerBaseURL || !clientID || !clientSecret || !secret) {
    const log = isProduction ? logger.error.bind(logger) : logger.warn.bind(logger);
    log('missing KEYCLOAK_* env vars — OIDC middleware not initialised (SSO login disabled)');
    return [];
  }

  // Reject placeholder secrets (same pattern as JWT_SECRET in config.js).
  // Reject any value that looks like a placeholder (case-insensitive, trimmed).
  const lowerSecret = secret.toLowerCase().trim();
  if (lowerSecret.startsWith('change') || lowerSecret === 'secret' || lowerSecret === 'test') {
    logger.error('Failed to initialise OIDC middleware: KEYCLOAK_SECRET is set to a known placeholder. Use a real 32+ char random string. (SSO login disabled)');
    return [];
  }

  // express-openid-connect config
  const oidcConfig = {
    authRequired: false, // passive mode — let auth.js handle unauthenticated
    auth0Logout: false,  // not Auth0 — use standard OIDC logout
    idpLogout: true,     // redirect to Keycloak end_session_endpoint on logout
    issuerBaseURL,
    baseURL: process.env.BASE_URL || `http://localhost:${process.env.PORT || 3200}`,
    clientID,
    clientSecret,
    secret,
    authorizationParams: {
      response_type: 'code',
      scope: 'openid profile email',
    },
    routes: {
      // Custom login path to avoid conflict with POST /api/auth/login (local bcrypt)
      login: '/api/auth/sso-login',
      logout: '/api/auth/logout',
      callback: '/api/auth/callback',
      // Post-logout redirect: FRONTEND_URL/login with open redirect guard
      postLogoutRedirect: _buildPostLogoutUrl(),
    },
    // After OIDC callback, redirect to frontend app (not the API server).
    // In dev, frontend runs on :3000 while API is on :3200.
    // In production (SERVE_STATIC=true), they're the same origin.
    // HIGH-1: validate returnTo against FRONTEND_URL to prevent open redirect
    getLoginState: () => ({
      returnTo: _isSafeRedirectUrl(process.env.FRONTEND_URL) ? process.env.FRONTEND_URL : '/',
    }),
    session: {
      // No `store` — stateless encrypted-cookie session (see file header).
      // The token set lives in the client cookie, encrypted with KEYCLOAK_SECRET,
      // so it survives infra pod restarts. express-openid-connect auto-chunks the
      // cookie when the encrypted payload exceeds the 4KB per-cookie limit
      // (measured: ~4.3KB for a typical session → 2 chunks; well within limits).
      rolling: true, // extend session on activity
      absoluteDuration: 8 * 60 * 60, // 8 hours absolute max
      cookie: {
        httpOnly: true,
        // Cookie policy: adapt to baseURL protocol.
        //   HTTPS (prod, or dev with self-signed certs):
        //     SameSite=None + Secure — supports cross-site redirects from
        //     Keycloak when issuer is on a different site (e.g. two Istio
        //     VirtualServices).
        //   HTTP (dev via port-forward, localhost:8143 ↔ localhost:8180):
        //     SameSite=Lax — localhost ports are same-site, Lax survives
        //     top-level GET redirects (which is exactly the Keycloak
        //     callback shape). `SameSite=None; Secure=false` is rejected
        //     outright by browsers — the session cookie would never be
        //     stored, producing an infinite login loop.
        // express-openid-connect validates Secure against baseURL protocol (config.js:108).
        // CSRF surface mitigated by Content-Type enforcement on mutation endpoints.
        sameSite: (process.env.BASE_URL || '').startsWith('https://') ? 'None' : 'Lax',
        secure: (process.env.BASE_URL || '').startsWith('https://'),
      },
    },
    afterCallback: async (req, _res, session) => {
      logger.info('OIDC callback completed');
      // Genuine interactive login — record it so Recent Logins tracks the
      // real last login for already-bound users. Fire-and-forget; never let
      // an audit write delay or fail the post-login redirect.
      notifyFreshLogin({ req, session });
      return session;
    },
  };

  // Log cookie security status
  if ((process.env.BASE_URL || '').startsWith('https://')) {
    logger.info('Session cookie: SameSite=None; Secure=true (HTTPS baseURL)');
  } else {
    logger.warn('Session cookie: SameSite=Lax (HTTP baseURL). Works for same-site localhost; cross-site Keycloak deployments still need HTTPS + SameSite=None.');
  }

  // CA cert trust for AIRGAP — configure via Node.js native env var
  // NODE_EXTRA_CA_CERTS is the supported way; httpOptions is not a valid
  // express-openid-connect config key. The CA cert path is still used
  // for display in the admin UI (KEYCLOAK_CA_CERT_PATH).
  if (process.env.KEYCLOAK_CA_CERT_PATH) {
    // NOTE: `caCertPath` binding keeps the operator-known env var visible for setup verification.
    logger.info({ caCertPath: process.env.KEYCLOAK_CA_CERT_PATH }, 'CA cert configured — ensure NODE_EXTRA_CA_CERTS is set to the same path');
  }

  // ── Startup health check — validate Keycloak reachability & CA cert ──────
  validateKeycloakOnInit(issuerBaseURL);

  try {
    const oidcMiddleware = auth(oidcConfig);
    return [oidcMiddleware];
  } catch (err) {
    logger.error({ err }, 'Failed to initialise OIDC middleware');
    logger.error('Hint: Verify KEYCLOAK_ISSUER_BASE_URL, KEYCLOAK_CLIENT_ID, KEYCLOAK_CLIENT_SECRET, and KEYCLOAK_SECRET env vars are correct.');
    return [];
  }
}


/**
 * Conditional middleware — returns OIDC stack when auth_mode is 'keycloak',
 * otherwise returns an empty array (no-op).
 *
 * Called at startup time in index.js.
 *
 * @returns {import('express').RequestHandler[]}
 */
function getKeycloakMiddleware() {
  const mode = resolveAuthMode();
  if (mode !== 'keycloak') {
    logger.info({ mode }, 'OIDC middleware skipped');
    return [];
  }
  logger.info('auth_mode=keycloak — initialising OIDC middleware');
  return buildKeycloakMiddleware();
}

module.exports = { getKeycloakMiddleware, buildKeycloakMiddleware };
