/**
 * static-spa.js — Static file serving + SPA fallback.
 *
 * Extracted from index-infra.js for single-responsibility.
 * When SERVE_STATIC=true (production), serves the built frontend from dist/
 * and falls back to index.html for client-side routing.
 */
const express = require('express');
const { SANDBOX_HTML } = require('../shared/sandbox-document.cjs');

const SANDBOX_CSP =
  "default-src 'none'; script-src 'unsafe-inline' 'unsafe-eval'; worker-src blob:; connect-src 'none'; frame-ancestors 'self'; base-uri 'none'; form-action 'none'";

/**
 * Mount the transformer sandbox document route.
 * Must be registered BEFORE mountStatic + mountSpaFallback so the route-scoped
 * relaxed CSP wins and the SPA fallback never shadows it. The document is a
 * string baked into JS (shared/sandbox-document.cjs), so it works in this
 * single-origin SERVE_STATIC topology even though dist/ no longer ships a
 * static sandbox.html. Mirrors the dedicated frontend role
 * (index-frontend.js): same CSP, same Sec-Fetch document guard.
 *
 * @param {import('express').Express} app
 * @param {string|null} distPath
 */
function mountSandboxDocument(app, distPath) {
  if (!distPath) return;
  app.get('/sandbox.html', (req, res) => {
    // The eval-relaxed CSP is only safe inside a sandboxed iframe (opaque
    // origin). Refuse a top-level document navigation.
    if (req.headers['sec-fetch-dest'] === 'document') {
      return res.status(403).type('text/plain').send('sandbox.html is only loadable in a sandboxed iframe');
    }
    res.setHeader('Content-Security-Policy', SANDBOX_CSP);
    res.setHeader('X-Frame-Options', 'SAMEORIGIN');
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Cache-Control', 'no-store');
    res.type('html').send(SANDBOX_HTML);
  });
}

/**
 * Mount express.static for the dist directory.
 * Called AFTER auth middleware so static files are behind authentication.
 *
 * @param {import('express').Express} app
 * @param {string|null} distPath
 */
function mountStatic(app, distPath) {
  if (distPath) {
    app.use(express.static(distPath));
  }
}

/**
 * Mount the SPA fallback route.
 * Must be the LAST route registered — catches all unmatched GET requests
 * and returns index.html so the client-side router can handle them.
 *
 * @param {import('express').Express} app
 * @param {string|null} distPath
 */
function mountSpaFallback(app, distPath) {
  if (distPath) {
    const path = require('path');
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }
}

module.exports = { mountSandboxDocument, mountStatic, mountSpaFallback };
