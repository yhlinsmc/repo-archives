/**
 * flow-step-dispatch.js — infra-side handler for POST /api/flow-recipe-steps/:id/dispatch.
 *
 * Delegates to dispatchOneStep (infra/lib/flow-dispatch-step) for the core
 * prepare→socket→result logic. This file owns only HTTP request parsing,
 * auth checking, and HTTP response serialisation.
 *
 * BOUNDARY: imports only from shared/lib + infra/lib — never edge/, no DB.
 * SECURITY: prepared.headers carries the injected auth secret; it is used to
 * build the outbound request and is never logged.
 */
const { passthroughResponse } = require('../lib/remote-client');
const { dispatchOneStep } = require('../lib/flow-dispatch-step');
const { apiOk, apiError, requireAuth } = require('../../shared/helpers');
const { logger: rootLogger } = require('../../shared/lib/logger');

const logger = rootLogger.child({ module: 'infra-flow-step-dispatch' });

function mountFlowStepDispatch(app) {
  app.post('/api/flow-recipe-steps/:id/dispatch', async (req, res) => {
    if (!requireAuth(req, res)) return;
    // Step-level authorization is enforced by edge /prepare (it loads and
    // validates the step and recipe); this tier only requires an authenticated caller.
    const inputs = (req.body && req.body.inputs) || {};
    const runId = (req.body && req.body.run_id) || null;
    const test = (req.body && req.body.test) === true;
    try {
      const r = await dispatchOneStep({
        stepId: req.params.id, inputs, runId, test,
        user: req.user, reqId: req.id, reqPath: req.originalUrl,
      });
      if (r.prep) return passthroughResponse(res, r.prep);
      if (r.ok) return res.json(apiOk(r.envelope));
      const e = apiError(r.message || 'Step request failed', r.errorCode || 'INTERNAL_ERROR', r.status);
      return res.status(e.status).json(e.body);
    } catch (err) {
      logger.error({ err, stepId: req.params.id }, 'infra flow step dispatch failed id=' + req.params.id);
      const e = apiError('Dispatch failed', 'INTERNAL_ERROR', 500);
      res.status(e.status).json(e.body);
    }
  });
}

module.exports = mountFlowStepDispatch;
