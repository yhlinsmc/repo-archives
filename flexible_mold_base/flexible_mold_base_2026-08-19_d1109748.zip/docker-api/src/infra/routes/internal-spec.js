/**
 * internal-spec.js — the internal (infra) OpenAPI document, gated to a
 * logged-in human.
 *
 * SECURITY — the internal spec describes the browser-facing API and is an
 * operator surface, not a customer one. It trusts req.user ONLY (the exact
 * model of the public docs portal, requirePortalAuth) and grants NOTHING off a
 * raw Bearer token: a machine principal never populates req.user on the human
 * auth path, so an opaque machine token receives the same 401 as an anonymous
 * caller.
 *
 * MOUNT ORDER — must be mounted AFTER the human auth middleware (so req.user is
 * set) but BEFORE the pool-readiness gate, mirroring mountPublicDocs, so the raw
 * spec stays reachable without a configured pool.
 *
 * SECURITY: rate limiter runs BEFORE requirePortalAuth, mirroring
 * mountPublicDocs (security review MEDIUM, v3.2.484) — the route fully
 * terminates the response (res.json, no next()), so it is unreachable by
 * mountAuthenticatedLimiters' later general limiter regardless of mount
 * order, and that limiter's authenticated-skip would provide zero effective
 * budget for it anyway.
 */
const { getInfraSpec } = require('../../shared/openapi');
const { requirePortalAuth } = require('./public-docs');
const { createInternalSpecLimiter } = require('../limiters');

/**
 * Mount the gated internal OpenAPI JSON route onto the infra app.
 * @param {import('express').Express} app
 */
function mountInternalSpec(app) {
  const internalSpecLimiter = createInternalSpecLimiter();
  app.get('/api/openapi.json', internalSpecLimiter, requirePortalAuth, (_req, res) => res.json(getInfraSpec()));
}

module.exports = { mountInternalSpec };
