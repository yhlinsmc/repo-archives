/**
 * public-docs-boot.js — the answer the portal page gives when its document does
 * not arrive, and the placeholder it shows while it has not arrived yet.
 *
 * WHY THIS EXISTS. Before fmb-1423 the document was in the first paint and could
 * not fail to arrive. Fetching it buys a second request that can fail on its
 * own: a session that expired between the shell and the fetch, a rate-limit
 * refusal on the second request of the pair, a gateway error during a rolling
 * deploy, a blocked request. What the renderer does with any non-2xx is
 * substitute `info.title` with "Document 'api-1' could not be loaded" — an
 * internal slug the reader has never seen — and serve that inside a 200 page,
 * with no cause, no retry and no prompt to sign in again. It also mounts
 * immediately, so between the shell and the assembled reference the page is
 * simply empty.
 *
 * WHY IT IS A SCRIPT AND NOT A SERVER RENDER. The failure is per-reader and
 * happens after the page is delivered; the server has already answered 200 by
 * then. The renderer's own HTML is produced by a third-party function that takes
 * no slot for extra markup, so the script is injected into the <head> of what it
 * produced — before the bundle's own <script src>, which is in the body, so the
 * wrapper is installed before anything can fetch. The docs-scoped CSP already
 * carries 'unsafe-inline' for script and style because the renderer's own
 * bootstrap is an inline script; this adds no relaxation.
 *
 * NO SECOND REQUEST. The outcome is observed by wrapping fetch, not by asking
 * for the document again — a probe of its own would spend a third hit from the
 * per-reader budget on every page view.
 *
 * The client function below is serialised with toString(), so it may close over
 * NOTHING from this module: everything it needs arrives as an argument. It is
 * also asserted to contain no sequence that would end its own script element,
 * which is the same failure mode escapeForInlineScript() guards for the config.
 */

/**
 * Runs in the reader's browser. Shows a placeholder until the document arrives
 * and replaces it with a stated cause if it does not.
 *
 * Written as a self-contained function on purpose — see the file header.
 * @param {string} specPath - root-relative path of the document being fetched
 * @param {Window} win
 */
function docsBootstrap(specPath, win) {
  const doc = win.document;
  const STATUS_ID = 'public-docs-status';
  let settled = false;

  // <body> only, never documentElement: this script is in the <head>, so the
  // body does not exist yet on the first pass and attaching to <html> would put
  // the placeholder outside the document flow the parser is still building.
  function host() {
    return doc.body;
  }

  function box(isError) {
    let el = doc.getElementById(STATUS_ID);
    if (!el) {
      const parent = host();
      if (!parent) return null;
      el = doc.createElement('div');
      el.id = STATUS_ID;
      el.setAttribute('role', 'status');
      el.setAttribute('aria-live', 'polite');
      parent.appendChild(el);
    }
    while (el.firstChild) el.removeChild(el.firstChild);
    el.setAttribute('data-state', isError ? 'error' : 'loading');
    el.style.cssText = 'position:fixed;z-index:2147483647;left:50%;transform:translateX(-50%);'
      + 'max-width:34rem;padding:0.75rem 1rem;border-radius:0.5rem;'
      + 'font:14px/1.5 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;'
      + (isError
        ? 'top:1rem;color:#7f1d1d;background:#fef2f2;border:1px solid #fca5a5;box-shadow:0 2px 8px rgba(0,0,0,0.15);'
        : 'bottom:1rem;color:#334155;background:#f8fafc;border:1px solid #cbd5e1;');
    return el;
  }

  function write(isError, heading, detail, withRetry) {
    const el = box(isError);
    if (!el) return;
    const title = doc.createElement('strong');
    title.textContent = heading;
    title.style.cssText = 'display:block;margin-bottom:0.25rem;';
    el.appendChild(title);
    const text = doc.createElement('span');
    text.textContent = detail;
    el.appendChild(text);
    if (!withRetry) return;
    const retry = doc.createElement('button');
    retry.type = 'button';
    retry.textContent = 'Reload this page';
    retry.style.cssText = 'display:block;margin-top:0.5rem;padding:0.25rem 0.75rem;cursor:pointer;'
      + 'border-radius:0.25rem;border:1px solid currentColor;background:transparent;color:inherit;font:inherit;';
    retry.addEventListener('click', function () { win.location.reload(); });
    el.appendChild(retry);
  }

  function clear() {
    settled = true;
    const el = doc.getElementById(STATUS_ID);
    if (el && el.parentNode) el.parentNode.removeChild(el);
  }

  function waiting() {
    if (settled) return;
    write(false, 'Loading the API reference', 'The specification is being fetched from this server.', false);
  }

  function failed(status, err) {
    settled = true;
    let detail;
    if (status === 401) {
      detail = 'This page is signed in but the request for the specification was not — the session most '
        + 'likely expired. Reload to sign in again.';
    } else if (status === 403) {
      detail = 'This account is not permitted to read the specification.';
    } else if (status === 429) {
      detail = 'Too many requests from this account in a short time. Wait a moment, then reload.';
    } else if (status >= 500) {
      detail = 'The server did not return the specification (status ' + status + '). '
        + 'A deployment may be in progress.';
    } else if (status > 0) {
      detail = 'The server refused the request for the specification (status ' + status + ').';
    } else {
      detail = 'The request for the specification did not complete'
        + (err && err.message ? ': ' + err.message : '.');
    }
    write(true, 'The API specification did not load', detail + ' Nothing on this page below is complete.', true);
  }

  function isSpecRequest(input) {
    let raw = '';
    if (typeof input === 'string') raw = input;
    else if (input && typeof input.url === 'string') raw = input.url;
    else raw = String(input || '');
    raw = raw.split('#')[0].split('?')[0];
    return raw === specPath || raw.slice(-specPath.length) === specPath;
  }

  const nativeFetch = win.fetch;
  if (typeof nativeFetch === 'function') {
    win.fetch = function (input, init) {
      if (!isSpecRequest(input)) return nativeFetch.call(win, input, init);
      let pending;
      try {
        pending = nativeFetch.call(win, input, init);
      } catch (err) {
        failed(0, err);
        throw err;
      }
      return Promise.resolve(pending).then(function (res) {
        if (res && res.ok) clear(); else failed(res ? res.status : 0, null);
        return res;
      }, function (err) {
        failed(0, err);
        throw err;
      });
    };
  }

  if (host()) waiting();
  else if (typeof doc.addEventListener === 'function') doc.addEventListener('DOMContentLoaded', waiting);
}

/**
 * The <script> element to put in the page, with the client function inlined.
 *
 * The refusal is deliberate rather than an escape: this is our own source, so a
 * sequence that would end the element early is a bug to fix here, not a string
 * to rewrite at serve time.
 * @param {string} specPath
 * @returns {string}
 */
function buildDocsBootScript(specPath) {
  const call = `(${docsBootstrap.toString()})(${JSON.stringify(specPath)}, window);`;
  if (/<\/script/i.test(call) || call.indexOf('<!--') !== -1) {
    throw new Error(
      'the public-docs boot script contains a sequence that would end or comment out its own '
      + '<script> element — rewrite docsBootstrap() so it does not',
    );
  }
  return `<script type="text/javascript">\n${call}\n</script>`;
}

/**
 * Put the boot script in the <head> of the renderer's HTML, before its own
 * bundle <script src> in the body, so the wrapper is installed first.
 *
 * Returns the input unchanged when there is no head to inject into: a page that
 * does not look like the renderer's output is not one this should rewrite.
 * @param {unknown} html
 * @param {string} specPath
 * @returns {unknown}
 */
function injectDocsBoot(html, specPath) {
  if (typeof html !== 'string' || html.indexOf('</head>') === -1) return html;
  const script = buildDocsBootScript(specPath);
  // Function replacer: the script body is not a replacement pattern, and `$&`
  // inside it would otherwise be substituted.
  return html.replace('</head>', () => `${script}\n</head>`);
}

module.exports = { docsBootstrap, buildDocsBootScript, injectDocsBoot };
