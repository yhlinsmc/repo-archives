/**
 * auth-session.js — Session/identity auth routes (infra-side, cookie-facing).
 *
 * Handles: /me, /mode (GET), /access-check, /diagnostics (public).
 * These routes depend on session context (cookies, req.user) and stay on infra.
 * DB-touching routes (login, change-password, mode switch) are on edge.
 *
 * Mounted by index-infra.js at /api/auth.
 */

const router = require('express').Router();
const { apiOk, apiError } = require('../../shared/helpers');
const { resolveAuthMode, getAuthModeSource } = require('../../shared/config');
const { isDegraded, isProbeRunning } = require('../../lib/keycloak-health');
const { fetchAuthMode, EdgeUnreachable, EdgeTimeout, EdgeAuthFailed } = require('../lib/edge-state-client');
const { normalizeSqlModeState } = require('../../shared/lib/sql-mode');
const { logger: rootLogger } = require('../../shared/lib/logger');
const logger = rootLogger.child({ module: 'auth-diagnostics' });

// Admin-tier presence booleans — never echo values, only !!process.env.X
function collectAdminEnvPresence() {
  const jwtSecret = process.env.JWT_SECRET || '';
  const jwtPlaceholders = ['change-me', 'change-me-in-production'];
  const jwtPresent = !!jwtSecret && !jwtPlaceholders.includes(jwtSecret.toLowerCase());
  return {
    client_id_configured: !!process.env.KEYCLOAK_CLIENT_ID,
    client_secret_configured: !!process.env.KEYCLOAK_CLIENT_SECRET,
    cookie_secret_configured: !!process.env.KEYCLOAK_SECRET,
    ca_cert_configured: !!process.env.NODE_EXTRA_CA_CERTS,
    jwt_secret_configured: jwtPresent,
    settings_encryption_key_configured: !!process.env.SETTINGS_ENCRYPTION_KEY,
    s2s_api_key_configured: !!process.env.S2S_API_KEY,
    base_url_configured: !!process.env.BASE_URL,
    frontend_url_configured: !!process.env.FRONTEND_URL,
  };
}

// GET /api/auth/me — returns current user info (works with both JWT and OIDC sessions)
router.get('/me', (req, res) => {
  if (!req.user) return res.status(401).json(apiError('Unauthorized', 'UNAUTHORIZED', 401).body);
  res.json(apiOk({
    id: req.user.id,
    email: req.user.email,
    role: req.user.role,
    deptid: req.user.deptid || null,
    kc_username: req.user.kc_username || null,
    user_id: req.user.user_id || null,
  }));
});

// GET /api/auth/mode — returns current auth mode
// Tiered response: unauthenticated gets {mode} only, authenticated gets full details
router.get('/mode', async (req, res) => {
  try {
    const mode = resolveAuthMode();

    if (!req.user) {
      return res.json(apiOk({ mode }));
    }

    res.json(apiOk({
      mode,
      source: getAuthModeSource(),
      degraded: isDegraded(),
    }));
  } catch (err) {
    const e = apiError(err.message, 'INTERNAL_ERROR');
    res.status(e.status).json(e.body);
  }
});

// GET /api/auth/access-check — check if current user passes access rules
router.get('/access-check', (req, res) => {
  if (!req.user) return res.status(401).json(apiError('Unauthorized', 'UNAUTHORIZED', 401).body);
  res.json(apiOk({ allowed: true, role: req.user.role }));
});

// GET /api/auth/diagnostics — tiered response.
// Public tier (no auth): auth_mode, issuer_url_configured, keycloak_reachable.
// Admin tier (req.user.role === 'admin'): + 9 env-var presence booleans, auth
// mode source, health probe running, a stuck-cache advisory flag so the
// SystemDiagnostics panel can render the Promote button without leaking
// secret *values* to unauthenticated callers, and whether edge's configured
// pool refuses a value it cannot store (this is the authenticated home of a
// reading that must not be on either /health body).
router.get('/diagnostics', async (req, res) => {
  try {
    // NOTE: fetch canonical auth_mode from edge S2S. On edge-unreachable, fall
    // back to env-resolved mode so /diagnostics still renders (it's a
    // setup/troubleshooting surface that must stay reachable).
    let authMode;
    let edgeEncKeyConfigured = null; // null = edge value unknown (unreachable)
    // Whether edge's configured pool refuses a value it cannot store. Admin
    // tier only — see the closed-set note where it is assigned below.
    let edgeStrictWrites = 'unknown';
    try {
      const result = await fetchAuthMode(req.user || null, { reqId: req.id });
      authMode = result.auth_mode || resolveAuthMode();
      if (typeof result.settings_encryption_key_configured === 'boolean') {
        edgeEncKeyConfigured = result.settings_encryption_key_configured;
      }
      // Coerced through the shared normaliser rather than echoed: a value from
      // outside the closed set must read as 'unknown' here for the same reason
      // it does at the probe — an unmeasured deployment must never render as a
      // safe one. No separate 'source' caveat is needed the way the encryption
      // key needs one, because infra has no local reading to fall back to and
      // 'unknown' already means exactly "this could not be read".
      edgeStrictWrites = normalizeSqlModeState(result.configured_pool_strict_writes);
    } catch (modeErr) {
      if (modeErr instanceof EdgeUnreachable || modeErr instanceof EdgeTimeout || modeErr instanceof EdgeAuthFailed) {
        logger.warn({ err: modeErr.message, code: modeErr.code }, 'edge unreachable for diagnostics auth_mode — env fallback');
      } else {
        logger.warn({ err: modeErr }, 'diagnostics auth_mode fetch failed — env fallback');
      }
      authMode = resolveAuthMode();
    }

    const issuerUrl = process.env.KEYCLOAK_ISSUER_BASE_URL || null;

    const result = {
      auth_mode: authMode,
      issuer_url_configured: !!issuerUrl,
      keycloak_reachable: false,
    };

    if (issuerUrl) {
      try {
        const discoveryUrl = `${issuerUrl}/.well-known/openid-configuration`;
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 5000);
        const resp = await fetch(discoveryUrl, { signal: controller.signal });
        clearTimeout(timeout);
        result.keycloak_reachable = resp.ok;
      } catch {
        result.keycloak_reachable = false;
      }
    }

    // Admin tier — extended presence booleans + diagnostic metadata.
    if (req.user && req.user.role === 'admin') {
      Object.assign(result, collectAdminEnvPresence());
      // The encryption key lives on edge (in split-role prod it is edge-only,
      // by Vault design). collectAdminEnvPresence read infra's own env, which
      // is blind to the edge key — prefer edge's authoritative answer and flag
      // when we had to fall back to the local reading.
      if (edgeEncKeyConfigured !== null) {
        result.settings_encryption_key_configured = edgeEncKeyConfigured;
        result.settings_encryption_key_source = 'edge';
      } else {
        result.settings_encryption_key_source = 'infra-fallback';
      }
      // SECURITY: admin tier only, and this is the reason the field is not on
      // either /health body. It answers whether a write this engine cannot store
      // is refused or silently substituted — which tells a caller whether an
      // over-long string, an out-of-range integer or a non-member ENUM value is
      // worth writing at this host. An operator needs it; a stranger must not
      // have it.
      result.configured_pool_strict_writes = edgeStrictWrites;
      const source = getAuthModeSource();
      const probeRunning = typeof isProbeRunning === 'function' ? isProbeRunning() : false;
      result.auth_mode_source = source;
      result.health_probe_running = probeRunning;

      // Stuck-cache advisory: cached=local, live=reachable, probe not running.
      // The keycloak-health watchdog is asymmetric (keycloak→local only), so a
      // boot-time fall-through to local stays cached until an admin acts.
      const stuck = authMode === 'local' && result.keycloak_reachable && !probeRunning;
      result.auth_stuck_cache = stuck;
      if (stuck) {
        logger.warn(
          { cached: 'local', live_reachable: true, probe_running: false },
          'keycloak stuck-cache detected',
        );
      }
    }

    res.json(apiOk(result));
  } catch (err) {
    // Reviewer 2026-04-13: do not surface internal err.message via API. The
    // diagnostics endpoint now has more code paths that can throw (admin tier
    // env presence + isProbeRunning import). Generic error to client; full
    // details to pino for ops.
    logger.error({ err }, 'diagnostics handler failed');
    const e = apiError('Internal server error', 'INTERNAL_ERROR', 500);
    res.status(e.status).json(e.body);
  }
});

module.exports = router;
