/**
 * request-log.js — one structured line per HTTP request, emitted at finish.
 *
 * Reads the user at finish-time (after auth middleware has populated req.user)
 * so even a rejected request carries its actor. Logs the pathname ONLY — never
 * the query string (it can hold tokens / ids) and never the body or headers.
 *
 * Level: 5xx → error (also trips the logger's src injection), 4xx → warn, and
 * an optional caller-supplied `debug` predicate downgrades chatty internal
 * routes to debug for 2xx/3xx (a failure on those still warns/errors).
 *
 * The actor is logged as `user_id` (+ role) — NEVER the email, which is PII.
 */
const { logger: rootLogger } = require('../lib/logger');

/**
 * @param {object} [opts]
 * @param {(path: string) => boolean} [opts.skip] - return true to log nothing
 * @param {(path: string) => boolean} [opts.debug] - return true to downgrade a
 *   successful request to debug level (health-of-the-machine S2S chatter)
 * @param {import('pino').Logger} [opts.logger] - injectable for tests
 */
function createRequestLog({ skip, debug, logger = rootLogger } = {}) {
  return function requestLog(req, res, next) {
    // pathname only — strip any query string defensively even though req.path
    // already excludes it.
    const path = (req.path || req.url || '').split('?')[0];

    if (typeof skip === 'function' && skip(path)) return next();

    const startNs = process.hrtime.bigint();
    res.on('finish', () => {
      const ms = Math.round(Number(process.hrtime.bigint() - startNs) / 1e6);
      const status = res.statusCode;

      let level;
      if (status >= 500) level = 'error';
      else if (status >= 400) level = 'warn';
      else if (typeof debug === 'function' && debug(path)) level = 'debug';
      else level = 'info';

      logger[level](
        {
          module: 'http',
          req_id: req.id,
          method: req.method,
          path,
          status,
          ms,
          user_id: req.user?.id ?? null,
          role: req.user?.role ?? null,
          ip: req.ip,
        },
        `${req.method} ${path} ${status} ${ms}ms`,
      );
    });

    next();
  };
}

module.exports = { createRequestLog };
