/**
 * s2s-auth.js — Service-to-service authentication helpers.
 *
 * Attaches the S2S key header when API-infra forwards requests to API-edge.
 *
 * The shared secret is read from S2S_API_KEY env var.
 * Both API-infra and API-edge must share the same value.
 */
const { logger: rootLogger } = require('../lib/logger');
const logger = rootLogger.child({ module: 's2s-auth' });

const S2S_HEADER = 'x-s2s-key';
const IMPERSONATED_HEADER = 'x-forwarded-user-impersonated';

/**
 * Get the configured S2S API key.
 * @returns {string|null}
 */
function getS2sKey() {
  return process.env.S2S_API_KEY || null;
}

const PRINCIPAL_TYPE_HEADER = 'x-forwarded-principal-type';
const SCOPE_HEADER = 'x-forwarded-scope';

/**
 * Build S2S auth headers for outgoing requests from API-infra to API-edge.
 *
 * @param {object} user - The authenticated user from req.user (set by auth.js)
 * @param {object} [options]
 * @param {'service_account'} [options.principalType] - Machine principal marker.
 *   When set, edge pins req.user.role to a value admin/editor gates can never
 *   accept. Absent/other → human (backward compatible).
 * @param {unknown} [options.scope] - Machine grant (JSON-encoded into the scope
 *   header); only emitted for a service_account principal.
 * @returns {object} Headers object to merge into the outgoing request
 */
function buildS2sHeaders(user, options = {}) {
  const key = getS2sKey();
  if (!key) {
    logger.warn('S2S_API_KEY not configured — requests to API-edge will fail');
  }

  const headers = {};
  if (key) {
    headers[S2S_HEADER] = key;
  }

  // Forward user identity as X-Forwarded-User-* headers.
  // API-edge strips ALL X-Forwarded-User-* from external requests
  // and only trusts these when S2S key is verified.
  if (user) {
    headers['x-forwarded-user-id'] = user.id || '';
    headers['x-forwarded-user-email'] = user.email || '';
    headers['x-forwarded-user-role'] = user.role || 'user';
    if (user.deptid) headers['x-forwarded-user-deptid'] = user.deptid;
    if (user.keycloak_sub) headers['x-forwarded-user-kc-sub'] = user.keycloak_sub;
    if (user.kc_username) headers['x-forwarded-user-kc-username'] = user.kc_username;
    // Signal to edge that this request carries impersonated identity so the
    // read-only gate can enforce reduced permissions for the target user.
    if (user.impersonated) headers[IMPERSONATED_HEADER] = '1';
  }

  // Extended S2S contract (Public Integration API). A service_account principal
  // carries a dedicated type + its granted scope; edge reconstructs both and
  // fails closed on an empty scope. Edge treats an absent principal-type header
  // as human, so existing callers stay backward compatible.
  if (options.principalType === 'service_account') {
    headers[PRINCIPAL_TYPE_HEADER] = 'service_account';
    if (options.scope !== undefined && options.scope !== null) {
      headers[SCOPE_HEADER] = JSON.stringify(options.scope);
    }
  } else if (user) {
    headers[PRINCIPAL_TYPE_HEADER] = 'human';
  }

  return headers;
}

module.exports = {
  S2S_HEADER,
  IMPERSONATED_HEADER,
  PRINCIPAL_TYPE_HEADER,
  SCOPE_HEADER,
  getS2sKey,
  buildS2sHeaders,
};
