'use strict';

// INVARIANT: mirror of src/fmb/lib/hierarchy-tiers.ts. The backend only ever
// reparents blueprints, so the rule is narrowed to "a blueprint's parent must
// be a release". Keep in sync with the frontend module.
const BLUEPRINT_PARENT_TYPES = ['release'];

function isValidBlueprintParent(parentType) {
  return BLUEPRINT_PARENT_TYPES.includes(parentType);
}

module.exports = { BLUEPRINT_PARENT_TYPES, isValidBlueprintParent };
