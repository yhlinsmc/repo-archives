/**
 * quantity.js — the ONE rule for turning a derived capacity quantity into the
 * number a human is shown.
 *
 * MIRROR: this is the CJS half of `src/fmb/capacity/lib/capacity-quantity.ts`.
 * The Vite bundle may not import docker-api/**, so the rule exists twice; the
 * two copies MUST stay behaviourally identical, and `evaluator.lockstep.test.ts`
 * holds them together through the violation text they both produce.
 *
 * WHAT THIS IS NOT: a display-precision policy. It does not decide how many
 * decimals a column shows. A column that wants fixed decimals declares its own
 * precision, and this module is not consulted for it.
 */
'use strict';

/**
 * How many decimals a derived quantity is canonicalised at — both to COMPARE two
 * of them and to PRINT one.
 *
 * Its only job is to absorb float summation noise, and nothing more. Two sums of
 * the same numbers in a different order differ in the last bits, and a host
 * carrying 24.1 + 24.1 + 29.1 GB of VM memory rolls up to `77.30000000000001`.
 * Six decimals is far finer than any quantity these surfaces carry, so nothing
 * an operator entered is rounded away: what disappears is residue of the
 * arithmetic, not information. A memory size someone really typed as `3.5` still
 * reads `3.5`, and one typed as `100.456789` still reads `100.456789`.
 */
const CANONICAL_DECIMALS = 6;

/**
 * Round to a stated number of decimals, with -0 normalised — it is not
 * `Object.is`-equal to 0, `String` prints it with its sign, and either would
 * report a change that did not happen.
 *
 * @param {number} value
 * @param {number} precision
 * @returns {number}
 */
function roundTo(value, precision) {
  const factor = 10 ** precision;
  const rounded = Math.round(value * factor) / factor;
  return rounded === 0 ? 0 : rounded;
}

/**
 * A derived quantity as it stands, with the summation residue removed.
 *
 * Non-finite input is returned unchanged: `Math.round(NaN * 1e6)` is `NaN`
 * anyway, and a caller that produced an Infinity has a problem this function
 * must not disguise as a figure.
 *
 * @param {number} value
 * @returns {number}
 */
function canonicalQuantity(value) {
  return Number.isFinite(value) ? roundTo(value, CANONICAL_DECIMALS) : value;
}

/**
 * What a derived quantity PRINTS.
 *
 * `String` of the canonical number, so the digits are exactly the ones the
 * number has and no more: `77.3`, not `77.30000000000001` and not a padded
 * `77.300000`.
 *
 * Use it wherever a derived figure reaches a person. A STORED figure — a VM's
 * own `mem_gb`, an instance's own `sga_gb`, a host's hardware spec — is data
 * rather than arithmetic and is printed as it is.
 *
 * @param {number} value
 * @returns {string}
 */
function formatQuantity(value) {
  return String(canonicalQuantity(value));
}

module.exports = {
  CANONICAL_DECIMALS, roundTo, canonicalQuantity, formatQuantity,
};
