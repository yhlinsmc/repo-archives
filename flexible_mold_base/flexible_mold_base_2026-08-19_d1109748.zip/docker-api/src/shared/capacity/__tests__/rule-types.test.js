/**
 * rule-types.test.js — the config-rewrite rule-type registry seam (rule-types.js).
 * Guards the six keeper types, their legal levels/group-bys, and the §13.1a
 * default template that the seed migration + route validation both depend on.
 *
 * Runner: vitest (root suite picks up docker-api/src/**\/__tests__).
 */
import { describe, it, expect } from 'vitest';
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
const {
  RULE_TYPES, RULE_LEGAL_LEVELS, RULE_LEGAL_GROUP_BYS, DEFAULT_RULE_TEMPLATE,
} = require('../rule-types');

describe('rule-types registry', () => {
  it('declares exactly the six keeper types (spec §13.1)', () => {
    expect(RULE_TYPES).toEqual([
      'no-oversell', 'max-vms-per-host', 'max-instances-per-vm',
      'keep-apart', 'spread-across-sites', 'keep-in-one-site',
    ]);
  });

  it('every type has legal levels + group-bys', () => {
    for (const type of RULE_TYPES) {
      expect(RULE_LEGAL_LEVELS[type].length).toBeGreaterThan(0);
      expect(RULE_LEGAL_GROUP_BYS[type].length).toBeGreaterThan(0);
    }
  });

  it('built-ins + density are hypervisor/vm level; relational rules are db_instance level', () => {
    expect(RULE_LEGAL_LEVELS['no-oversell']).toEqual(['hypervisor']);
    expect(RULE_LEGAL_LEVELS['max-vms-per-host']).toEqual(['hypervisor']);
    expect(RULE_LEGAL_LEVELS['max-instances-per-vm']).toEqual(['vm']);
    expect(RULE_LEGAL_LEVELS['keep-apart']).toEqual(['db_instance']);
    expect(RULE_LEGAL_LEVELS['spread-across-sites']).toEqual(['db_instance']);
    expect(RULE_LEGAL_LEVELS['keep-in-one-site']).toEqual(['db_instance']);
  });

  it('built-ins/density only target all_of_type; relational rules accept structural groups', () => {
    expect(RULE_LEGAL_GROUP_BYS['no-oversell']).toEqual(['all_of_type']);
    expect(RULE_LEGAL_GROUP_BYS['max-instances-per-vm']).toEqual(['all_of_type']);
    expect(RULE_LEGAL_GROUP_BYS['keep-apart']).toContain('each_primary_cluster');
    expect(RULE_LEGAL_GROUP_BYS['spread-across-sites']).toContain('each_database');
    expect(RULE_LEGAL_GROUP_BYS['keep-in-one-site']).toContain('custom_group');
  });

  it('the §13.1a default template is eight all-hard rows with the non-conflicting targets', () => {
    expect(DEFAULT_RULE_TEMPLATE).toHaveLength(8);
    for (const row of DEFAULT_RULE_TEMPLATE) {
      expect(row.severity).toBe('hard');
      expect(RULE_TYPES).toContain(row.type);
      // Each seed row's level + group_by must be legal for its type.
      expect(RULE_LEGAL_LEVELS[row.type]).toContain(row.level);
      expect(RULE_LEGAL_GROUP_BYS[row.type]).toContain(row.group_by);
    }
    // The two potentially-conflicting relational defaults have DIFFERENT group_by
    // (spec §13.1a: keep-in-one-site = primary cluster, spread = database) so they
    // are not a same-level clash.
    const keepInOne = DEFAULT_RULE_TEMPLATE.find((r) => r.type === 'keep-in-one-site');
    const spread = DEFAULT_RULE_TEMPLATE.find((r) => r.type === 'spread-across-sites');
    expect(keepInOne.group_by).toBe('each_primary_cluster');
    expect(spread.group_by).toBe('each_database');
    expect(keepInOne.group_by).not.toBe(spread.group_by);
    expect(spread.params.min_sites).toBe(2);
  });

  it('phase-2 spec §6.2: seeds an each_standby_cluster keep-apart row alongside the existing primary one', () => {
    const primaryKeepApart = DEFAULT_RULE_TEMPLATE.find(
      (r) => r.type === 'keep-apart' && r.group_by === 'each_primary_cluster',
    );
    const standbyKeepApart = DEFAULT_RULE_TEMPLATE.find(
      (r) => r.type === 'keep-apart' && r.group_by === 'each_standby_cluster',
    );
    expect(primaryKeepApart).toBeTruthy();
    expect(standbyKeepApart).toBeTruthy();
    expect(standbyKeepApart.level).toBe('db_instance');
    expect(standbyKeepApart.severity).toBe('hard');
    // A fresh scenario references the global template (no per-scenario copy) —
    // so both keep-apart rows are present in every fresh scenario's rule set.
    expect(standbyKeepApart.severity).toBe(primaryKeepApart.severity);
  });

  it('AR2-Q11 (spec §7 E1): seeds an each_standby_cluster keep-in-one-site row alongside the existing primary one', () => {
    const primaryKeepInOne = DEFAULT_RULE_TEMPLATE.find(
      (r) => r.type === 'keep-in-one-site' && r.group_by === 'each_primary_cluster',
    );
    const standbyKeepInOne = DEFAULT_RULE_TEMPLATE.find(
      (r) => r.type === 'keep-in-one-site' && r.group_by === 'each_standby_cluster',
    );
    expect(primaryKeepInOne).toBeTruthy();
    expect(standbyKeepInOne).toBeTruthy();
    expect(standbyKeepInOne.level).toBe('db_instance');
    expect(standbyKeepInOne.severity).toBe('hard');
    expect(standbyKeepInOne.enabled).toBe(true);
    // Disable-able like every other default row (spec wants it editable, not a
    // built-in) — nothing in the row itself marks it as non-editable.
    expect(standbyKeepInOne.name).toBe('Keep in one site (standby)');
  });
});
