/**
 * evaluator.test.js — conformance suite for the pure Capacity Planner rule
 * evaluator (config-rewrite, spec §13 + §3.4 + §11–12). This is the correctness
 * core: the six keeper rule types × pass/fail × filtered/unfiltered, structural
 * grouping (each database / primary cluster / standby cluster / all-of-type /
 * custom group), arity-skip, default+exception precedence, same-level clash,
 * override-row resolution, the SGA-cap capacity check, Exception re-match +
 * staleness, and the byte-stable object_set_key.
 *
 * Runner: vitest (root suite picks up docker-api/src/**\/__tests__).
 */
import { describe, it, expect } from 'vitest';
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
const {
  evaluate, summarize, objectSetKey, detectRuleClashes, computeSgaCap,
  compareValues, normalizeOp, getField, matchConditions, normalizeFilters,
  usableForSpec, computeRollups, SGA_CAP_RULE_ID,
} = require('../evaluator.js');

// ── Snapshot builder — deterministic, minimal, composable ─────────────────────
function base(overrides = {}) {
  return {
    scenarios: [], sites: [], specs: [], hypervisors: [], vms: [], db_instances: [],
    databases: [], custom_groups: [], custom_group_members: [],
    rules: [], waivers: [], settings: {}, vm_profiles: [],
    ...overrides,
  };
}
function rule(type, over = {}) {
  return {
    id: over.id || `rule-${type}`,
    scenario_id: over.scenario_id !== undefined ? over.scenario_id : 'scn-1',
    type,
    name: over.name || type,
    level: over.level,
    group_by: over.group_by,
    custom_group_id: over.custom_group_id === undefined ? null : over.custom_group_id,
    filters: over.filters === undefined ? [] : over.filters,
    params: over.params === undefined ? {} : over.params,
    severity: over.severity || 'soft',
    enabled: over.enabled === undefined ? true : over.enabled,
    overrides_rule_id: over.overrides_rule_id === undefined ? null : over.overrides_rule_id,
  };
}
function spec(id, over = {}) {
  return {
    id, scenario_id: 'scn-1', name: id,
    cpu_total: 64, mem_total_gb: 1280, disk_total_gb: 4000,
    cpu_reserved: 0, mem_reserved_pct: 0, disk_reserved_gb: 0, metadata: null, ...over,
  };
}
function hv(id, site_id, spec_id = 'spec-a', over = {}) {
  return { id, scenario_id: 'scn-1', site_id, spec_id, name: id, metadata: null, ...over };
}
function vm(id, hypervisor_id, over = {}) {
  return {
    id, scenario_id: 'scn-1', vm_type: 'db_host', hypervisor_id,
    cpu: 8, mem_gb: 160, disk_gb: 200, sizing_profile_id: null, database_id: null, name: id, metadata: null, ...over,
  };
}
function inst(id, vm_id, over = {}) {
  return { id, scenario_id: 'scn-1', vm_id, database_id: null, name: id, role: 'primary', sga_gb: 64, metadata: null, ...over };
}
function database(id, over = {}) {
  return { id, scenario_id: 'scn-1', function_name: id, topology: 'primary', profile_id: null, disk_combo_id: null, team_id: null, description: null, metadata: null, ...over };
}
function profile(id, over = {}) {
  return { id, scenario_id: null, class: 'DB', name: id, mode: 'formula', cpu: 16, mem_gb: null, sga_cap_gb: null, allowed_disk_combos: null, metadata: null, ...over };
}

// ── Pure helper units ─────────────────────────────────────────────────────────
describe('operator + comparison helpers', () => {
  it('normalises operator synonyms', () => {
    expect(normalizeOp('=')).toBe('eq');
    expect(normalizeOp('≠')).toBe('ne');
    expect(normalizeOp('≤')).toBe('lte');
    expect(normalizeOp('≥')).toBe('gte');
    expect(normalizeOp('>')).toBe('gt');
    expect(normalizeOp('garbage')).toBe('eq');
  });
  it('numeric vs string comparison', () => {
    expect(compareValues(10, '>=', 5)).toBe(true);
    expect(compareValues('10', '>=', '5')).toBe(true);
    expect(compareValues('abc', '=', 'abc')).toBe(true);
    expect(compareValues('abc', '<', 'abd')).toBe(true);
    expect(compareValues(3, '≠', 4)).toBe(true);
  });
  it('in + contains', () => {
    expect(compareValues('b', 'in', ['a', 'b', 'c'])).toBe(true);
    expect(compareValues('b', 'in', 'a,b,c')).toBe(true);
    expect(compareValues('x', 'in', 'a,b,c')).toBe(false);
    expect(compareValues('hello world', 'contains', 'world')).toBe(true);
    expect(compareValues(['p', 'q'], 'contains', 'q')).toBe(true);
  });
  it('getField reads built-in then metadata custom field', () => {
    const e = { id: '1', role: 'primary', metadata: { zone: 'east' } };
    expect(getField(e, 'role')).toBe('primary');
    expect(getField(e, 'zone')).toBe('east');
    expect(getField(e, 'missing')).toBeUndefined();
  });
  it('getField parses metadata JSON string', () => {
    const e = { id: '1', metadata: '{"zone":"west"}' };
    expect(getField(e, 'zone')).toBe('west');
  });
  it('matchConditions ANDs all conditions', () => {
    const e = { role: 'primary', metadata: { tag: 'RAC' } };
    expect(matchConditions(e, [{ field: 'role', op: '=', value: 'primary' }, { field: 'tag', op: '=', value: 'RAC' }])).toBe(true);
    expect(matchConditions(e, [{ field: 'role', op: '=', value: 'standby' }])).toBe(false);
    expect(matchConditions(e, [])).toBe(true);
    expect(matchConditions(e, undefined)).toBe(true);
  });
  it('normalizeFilters accepts a bare array, a {conditions} wrap, or nothing', () => {
    const arr = [{ field: 'function', op: '=', value: 'erp' }];
    expect(normalizeFilters(arr)).toBe(arr);
    expect(normalizeFilters({ conditions: arr })).toBe(arr);
    expect(normalizeFilters(null)).toEqual([]);
    expect(normalizeFilters(undefined)).toEqual([]);
  });
});

describe('object_set_key (Exception re-match key) — BYTE-STABLE FOREVER', () => {
  it('is order-independent and pipe-joined', () => {
    expect(objectSetKey(['b', 'a', 'c'])).toBe('a|b|c');
    expect(objectSetKey(['a', 'b', 'c'])).toBe('a|b|c');
  });
  it('single + empty sets', () => {
    expect(objectSetKey(['x'])).toBe('x');
    expect(objectSetKey([])).toBe('');
  });
  it('coerces non-string ids (string sort, documented)', () => {
    expect(objectSetKey([2, 1, 10])).toBe('1|10|2');
  });
});

// ── Capacity math (spec §8 / §3.4) ────────────────────────────────────────────
describe('usable + rollups (spec §8)', () => {
  it('usable = raw − reserved (absolute + percent)', () => {
    const u = usableForSpec(spec('s', { cpu_total: 64, cpu_reserved: 1, mem_total_gb: 1000, mem_reserved_pct: 10, disk_total_gb: 500, disk_reserved_gb: 50 }));
    expect(u.cpu).toBe(63);
    expect(u.mem).toBe(900);
    expect(u.disk).toBe(450);
  });
  it('used = Σ placed VMs; unplaced excluded', () => {
    const state = base({
      specs: [spec('spec-a', { cpu_total: 64 })],
      hypervisors: [hv('h1', 'site-1', 'spec-a')],
      vms: [vm('v1', 'h1', { cpu: 8, mem_gb: 100, disk_gb: 50 }), vm('v2', 'h1', { cpu: 4, mem_gb: 50, disk_gb: 25 }), vm('v3', null, { cpu: 99 })],
    });
    const { hypervisors } = computeRollups(state);
    expect(hypervisors.h1.used).toEqual({ cpu: 12, mem: 150, disk: 75 });
    expect(hypervisors.h1.vmCount).toBe(2);
    expect(hypervisors.h1.effectiveUsable).toEqual(hypervisors.h1.usable);
  });
  it('db_host VM SGA rollup = Σ instance sga_gb', () => {
    const state = base({
      specs: [spec('spec-a')], hypervisors: [hv('h1', 'site-1')],
      vms: [vm('v1', 'h1', { vm_type: 'db_host' }), vm('v2', 'h1', { vm_type: 'ap_host' })],
      db_instances: [inst('i1', 'v1', { sga_gb: 32 }), inst('i2', 'v1', { sga_gb: 16 })],
    });
    const { vms } = computeRollups(state);
    expect(vms.v1.used_sga).toBe(48);
    expect(vms.v2).toBeUndefined();
  });
});

// ── Type 1: no-oversell ───────────────────────────────────────────────────────
describe('no-oversell', () => {
  const oversold = base({
    specs: [spec('spec-a', { cpu_total: 16, mem_total_gb: 100, disk_total_gb: 100 })],
    hypervisors: [hv('h1', 'site-1', 'spec-a')],
    vms: [vm('v1', 'h1', { cpu: 20, mem_gb: 50, disk_gb: 50 })],
    rules: [rule('no-oversell', { id: 'r-cap', level: 'hypervisor', group_by: 'all_of_type', severity: 'hard' })],
  });
  it('fails when used > usable on a resource', () => {
    const v = evaluate(oversold).violations;
    expect(v).toHaveLength(1);
    expect(v[0].subject_ids).toEqual(['h1']);
    expect(v[0].message).toContain('CPU');
    expect(v[0].message).not.toContain('MEM');
  });
  it('passes when used ≤ usable', () => {
    const ok = base({
      specs: [spec('spec-a', { cpu_total: 64 })], hypervisors: [hv('h1', 'site-1')],
      vms: [vm('v1', 'h1', { cpu: 8, mem_gb: 100, disk_gb: 100 })],
      rules: [rule('no-oversell', { level: 'hypervisor', group_by: 'all_of_type' })],
    });
    expect(evaluate(ok).violations).toHaveLength(0);
  });
  it('resources param narrows which resources are checked', () => {
    const s = { ...oversold, rules: [rule('no-oversell', { level: 'hypervisor', group_by: 'all_of_type', params: { resources: ['mem'] }, severity: 'hard' })] };
    // Only MEM checked; MEM 50 ≤ usable 100 ⇒ no violation despite CPU oversell.
    expect(evaluate(s).violations).toHaveLength(0);
  });
  it('filters restrict which hypervisors are checked', () => {
    const s = {
      ...oversold,
      sites: [{ id: 'site-1' }, { id: 'site-2' }],
      rules: [rule('no-oversell', { level: 'hypervisor', group_by: 'all_of_type', filters: [{ field: 'site_id', op: '=', value: 'site-2' }], severity: 'hard' })],
    };
    expect(evaluate(s).violations).toHaveLength(0); // the oversold host sits in site-1
  });
});

// ── Type 2: max-vms-per-host ──────────────────────────────────────────────────
describe('max-vms-per-host', () => {
  const state = (n) => base({
    specs: [spec('spec-a')], hypervisors: [hv('h1', 'site-1')],
    vms: Array.from({ length: n }, (_, i) => vm(`v${i}`, 'h1')),
    rules: [rule('max-vms-per-host', { level: 'hypervisor', group_by: 'all_of_type', params: { max: 8 }, severity: 'hard' })],
  });
  it('passes at the limit (=8, boundary)', () => {
    expect(evaluate(state(8)).violations).toHaveLength(0);
  });
  it('fails above the limit (9)', () => {
    const v = evaluate(state(9)).violations;
    expect(v).toHaveLength(1);
    expect(v[0].severity).toBe('hard');
    expect(v[0].subject_ids).toEqual(['h1']);
  });
});

// ── Type 3: max-instances-per-vm ──────────────────────────────────────────────
describe('max-instances-per-vm', () => {
  const state = (n, max) => base({
    specs: [spec('spec-a')], hypervisors: [hv('h1', 'site-1')],
    vms: [vm('v1', 'h1', { vm_type: 'db_host' })],
    db_instances: Array.from({ length: n }, (_, i) => inst(`i${i}`, 'v1')),
    rules: [rule('max-instances-per-vm', { level: 'vm', group_by: 'all_of_type', params: { max } })],
  });
  it('passes at the limit (=4)', () => {
    expect(evaluate(state(4, 4)).violations).toHaveLength(0);
  });
  it('fails above the limit', () => {
    const v = evaluate(state(5, 4)).violations;
    expect(v).toHaveLength(1);
    expect(v[0].subject_ids).toEqual(['v1']);
  });
});

// ── Type 4: keep-apart (anti-affinity) ────────────────────────────────────────
describe('keep-apart', () => {
  const twoInst = (h1, h2) => base({
    specs: [spec('spec-a')], hypervisors: [hv('h1', 'site-1'), hv('h2', 'site-1')],
    vms: [vm('v1', h1, { vm_type: 'db_host' }), vm('v2', h2, { vm_type: 'db_host' })],
    databases: [database('db-1')],
    db_instances: [inst('i1', 'v1', { database_id: 'db-1', role: 'primary' }), inst('i2', 'v2', { database_id: 'db-1', role: 'primary' })],
    rules: [rule('keep-apart', { level: 'db_instance', group_by: 'each_primary_cluster', severity: 'hard' })],
  });
  it('fails when ≥2 members of the primary cluster share a host', () => {
    const v = evaluate(twoInst('h1', 'h1')).violations;
    expect(v).toHaveLength(1);
    expect(v[0].subject_ids.sort()).toEqual(['i1', 'i2']);
  });
  it('passes when members are on different hosts', () => {
    expect(evaluate(twoInst('h1', 'h2')).violations).toHaveLength(0);
  });
  it('arity-skip: a 1-member group is never flagged (single-node database)', () => {
    const s = base({
      specs: [spec('spec-a')], hypervisors: [hv('h1', 'site-1')],
      vms: [vm('v1', 'h1', { vm_type: 'db_host' })],
      databases: [database('db-1', { topology: 'single' })],
      db_instances: [inst('i1', 'v1', { database_id: 'db-1', role: 'primary' })],
      rules: [rule('keep-apart', { level: 'db_instance', group_by: 'each_primary_cluster' })],
    });
    expect(evaluate(s).violations).toHaveLength(0);
  });
  it('all_of_type groups every db instance (host sharing across databases flags)', () => {
    const s = base({
      specs: [spec('spec-a')], hypervisors: [hv('h1', 'site-1')],
      vms: [vm('v1', 'h1', { vm_type: 'db_host' })],
      databases: [database('db-a'), database('db-b')],
      db_instances: [inst('i1', 'v1', { database_id: 'db-a' }), inst('i2', 'v1', { database_id: 'db-b' })],
      rules: [rule('keep-apart', { level: 'db_instance', group_by: 'all_of_type', severity: 'hard' })],
    });
    const v = evaluate(s).violations;
    expect(v).toHaveLength(1);
    expect(v[0].subject_ids.sort()).toEqual(['i1', 'i2']);
  });
  it('custom_group targets an explicit member list', () => {
    const s = base({
      specs: [spec('spec-a')], hypervisors: [hv('h1', 'site-1')],
      vms: [vm('v1', 'h1', { vm_type: 'db_host' })],
      databases: [database('db-a')],
      db_instances: [inst('i1', 'v1', { database_id: 'db-a' }), inst('i2', 'v1', { database_id: 'db-a' }), inst('i3', 'v1', { database_id: 'db-a' })],
      custom_groups: [{ id: 'cg-1', scenario_id: 'scn-1', name: 'pair', team_id: null }],
      custom_group_members: [
        { id: 'm1', scenario_id: 'scn-1', group_id: 'cg-1', member_instance_id: 'i1', member_vm_id: null },
        { id: 'm2', scenario_id: 'scn-1', group_id: 'cg-1', member_instance_id: 'i2', member_vm_id: null },
      ],
      rules: [rule('keep-apart', { level: 'db_instance', group_by: 'custom_group', custom_group_id: 'cg-1', severity: 'hard' })],
    });
    const v = evaluate(s).violations;
    expect(v).toHaveLength(1);
    // i3 is not a member — only i1+i2 flagged though all three share the host.
    expect(v[0].subject_ids.sort()).toEqual(['i1', 'i2']);
  });
  it('an instance with no database_id is standalone (never grouped)', () => {
    const s = base({
      specs: [spec('spec-a')], hypervisors: [hv('h1', 'site-1')],
      vms: [vm('v1', 'h1', { vm_type: 'db_host' })],
      db_instances: [inst('i1', 'v1', { database_id: null }), inst('i2', 'v1', { database_id: null })],
      rules: [rule('keep-apart', { level: 'db_instance', group_by: 'each_database' })],
    });
    expect(evaluate(s).violations).toHaveLength(0);
  });
});

// ── custom_group placeable units: VM members AND instance members (R1.14 #2) ────
// A custom group's members resolve to PLACEABLE UNITS — an instance (placed via
// its db_host VM) OR a VM (placed on its own hypervisor). AP VMs (no instances)
// are reachable ONLY this way (spec §12). The three relational rules evaluate the
// unit set; each unit's placement uses its own kind.
describe('custom_group placeable units (VM + instance members)', () => {
  const member = (id, over) => ({ id, scenario_id: 'scn-1', group_id: 'cg-1', member_vm_id: null, member_instance_id: null, ...over });

  it('keep-apart compares an instance unit and a VM unit on the same host', () => {
    const s = base({
      sites: [{ id: 'site-1', name: 'DC-1' }],
      specs: [spec('spec-a')], hypervisors: [hv('h1', 'site-1')],
      vms: [vm('v1', 'h1', { vm_type: 'db_host' }), vm('a1', 'h1', { vm_type: 'ap_host' })],
      databases: [database('db-a')],
      db_instances: [inst('i1', 'v1', { database_id: 'db-a' })],
      custom_groups: [{ id: 'cg-1', scenario_id: 'scn-1', name: 'mix', team_id: null }],
      custom_group_members: [member('m1', { member_instance_id: 'i1' }), member('m2', { member_vm_id: 'a1' })],
      rules: [rule('keep-apart', { level: 'db_instance', group_by: 'custom_group', custom_group_id: 'cg-1', severity: 'hard' })],
    });
    const v = evaluate(s).violations;
    expect(v).toHaveLength(1);
    // The VM unit id (a1) and the instance unit id (i1) are both flagged.
    expect(v[0].subject_ids.sort()).toEqual(['a1', 'i1']);
    expect(v[0].object_set_key).toBe('a1|i1');
  });

  it('spread-across-sites: a mixed group on ONE site fails min_sites=2', () => {
    const s = base({
      sites: [{ id: 'site-1', name: 'DC-1' }, { id: 'site-2', name: 'DC-2' }],
      specs: [spec('spec-a')], hypervisors: [hv('h1', 'site-1')],
      vms: [vm('v1', 'h1', { vm_type: 'db_host' }), vm('a1', 'h1', { vm_type: 'ap_host' })],
      databases: [database('db-a')],
      db_instances: [inst('i1', 'v1', { database_id: 'db-a' })],
      custom_groups: [{ id: 'cg-1', scenario_id: 'scn-1', name: 'mix', team_id: null }],
      custom_group_members: [member('m1', { member_instance_id: 'i1' }), member('m2', { member_vm_id: 'a1' })],
      rules: [rule('spread-across-sites', { level: 'db_instance', group_by: 'custom_group', custom_group_id: 'cg-1', params: { min_sites: 2 }, severity: 'hard' })],
    });
    const v = evaluate(s).violations;
    expect(v).toHaveLength(1);
    expect(v[0].subject_ids.sort()).toEqual(['a1', 'i1']);
  });

  it('keep-in-one-site: an AP-VM-only group spanning two sites is flagged', () => {
    const s = base({
      sites: [{ id: 'site-1', name: 'DC-1' }, { id: 'site-2', name: 'DC-2' }],
      specs: [spec('spec-a')], hypervisors: [hv('h1', 'site-1'), hv('h2', 'site-2')],
      vms: [vm('a1', 'h1', { vm_type: 'ap_host' }), vm('a2', 'h2', { vm_type: 'ap_host' })],
      custom_groups: [{ id: 'cg-1', scenario_id: 'scn-1', name: 'ap-only', team_id: null }],
      custom_group_members: [member('m1', { member_vm_id: 'a1' }), member('m2', { member_vm_id: 'a2' })],
      // apply_scope 'all': a custom_group has no single database, so default
      // (RAC-multi-node) scope would skip it — widen to test the VM-unit geometry.
      rules: [rule('keep-in-one-site', { level: 'db_instance', group_by: 'custom_group', custom_group_id: 'cg-1', params: { apply_scope: 'all' }, severity: 'hard' })],
    });
    const v = evaluate(s).violations;
    expect(v).toHaveLength(1);
    expect(v[0].subject_ids.sort()).toEqual(['a1', 'a2']);
  });

  it('an unplaced VM member is handled gracefully (no host → not co-located, no crash)', () => {
    const s = base({
      sites: [{ id: 'site-1', name: 'DC-1' }],
      specs: [spec('spec-a')], hypervisors: [hv('h1', 'site-1')],
      // a1 is placed on h1; a2 is UNPLACED (hypervisor_id null).
      vms: [vm('a1', 'h1', { vm_type: 'ap_host' }), vm('a2', null, { vm_type: 'ap_host' })],
      custom_groups: [{ id: 'cg-1', scenario_id: 'scn-1', name: 'ap', team_id: null }],
      custom_group_members: [member('m1', { member_vm_id: 'a1' }), member('m2', { member_vm_id: 'a2' })],
      rules: [rule('keep-apart', { level: 'db_instance', group_by: 'custom_group', custom_group_id: 'cg-1', severity: 'hard' })],
    });
    // a1 alone on h1, a2 has no host → no two units share a host → no violation.
    expect(evaluate(s).violations).toHaveLength(0);
  });

  it('a VM member that does not exist is skipped (defensive)', () => {
    const s = base({
      sites: [{ id: 'site-1', name: 'DC-1' }],
      specs: [spec('spec-a')], hypervisors: [hv('h1', 'site-1')],
      vms: [vm('a1', 'h1', { vm_type: 'ap_host' })],
      custom_groups: [{ id: 'cg-1', scenario_id: 'scn-1', name: 'ap', team_id: null }],
      custom_group_members: [member('m1', { member_vm_id: 'a1' }), member('m2', { member_vm_id: 'ghost' })],
      rules: [rule('keep-apart', { level: 'db_instance', group_by: 'custom_group', custom_group_id: 'cg-1', severity: 'hard' })],
    });
    expect(evaluate(s).violations).toHaveLength(0);
  });
});

// ── Type 5: spread-across-sites ───────────────────────────────────────────────
describe('spread-across-sites', () => {
  // A Primary+Standby database: primary cluster on `pSite`, standby on `sSite`.
  const primaryStandby = (pSite, sSite) => base({
    sites: [{ id: 'site-1', name: 'DC-1' }, { id: 'site-2', name: 'DC-2' }],
    specs: [spec('spec-a')],
    hypervisors: [hv('h1', pSite), hv('h2', sSite)],
    vms: [vm('v1', 'h1', { vm_type: 'db_host' }), vm('v2', 'h2', { vm_type: 'db_host' })],
    databases: [database('db-1', { topology: 'primary_standby' })],
    db_instances: [
      inst('i1', 'v1', { database_id: 'db-1', role: 'primary' }),
      inst('i2', 'v2', { database_id: 'db-1', role: 'standby' }),
    ],
    rules: [rule('spread-across-sites', { level: 'db_instance', group_by: 'each_database', params: { min_sites: 2 }, severity: 'hard' })],
  });
  it('fails when a Primary+Standby database sits in one site', () => {
    const v = evaluate(primaryStandby('site-1', 'site-1')).violations;
    expect(v).toHaveLength(1);
    expect(v[0].subject_ids.sort()).toEqual(['i1', 'i2']);
  });
  it('passes when the two clusters land in different sites', () => {
    expect(evaluate(primaryStandby('site-1', 'site-2')).violations).toHaveLength(0);
  });
  it('arity-skip: a single-cluster database (one placement cluster) is never flagged', () => {
    // A Primary (2-node, no standby) database: one cluster. group_by each_database
    // with min_sites 2 has only ONE independently-placeable cluster ⇒ skipped.
    const s = base({
      sites: [{ id: 'site-1' }, { id: 'site-2' }], specs: [spec('spec-a')],
      hypervisors: [hv('h1', 'site-1'), hv('h2', 'site-1')],
      vms: [vm('v1', 'h1', { vm_type: 'db_host' }), vm('v2', 'h2', { vm_type: 'db_host' })],
      databases: [database('db-1', { topology: 'primary' })],
      db_instances: [
        inst('i1', 'v1', { database_id: 'db-1', role: 'primary' }),
        inst('i2', 'v2', { database_id: 'db-1', role: 'primary' }),
      ],
      rules: [rule('spread-across-sites', { level: 'db_instance', group_by: 'each_database', params: { min_sites: 2 } })],
    });
    expect(evaluate(s).violations).toHaveLength(0);
  });
  it('each_primary_cluster uses member-count arity (a cluster spreads its own nodes)', () => {
    // Two primary nodes in one site ⇒ spans 1 < 2 ⇒ violation.
    const s = base({
      sites: [{ id: 'site-1' }, { id: 'site-2' }], specs: [spec('spec-a')],
      hypervisors: [hv('h1', 'site-1'), hv('h2', 'site-1')],
      vms: [vm('v1', 'h1', { vm_type: 'db_host' }), vm('v2', 'h2', { vm_type: 'db_host' })],
      databases: [database('db-1', { topology: 'primary' })],
      db_instances: [
        inst('i1', 'v1', { database_id: 'db-1', role: 'primary' }),
        inst('i2', 'v2', { database_id: 'db-1', role: 'primary' }),
      ],
      rules: [rule('spread-across-sites', { level: 'db_instance', group_by: 'each_primary_cluster', params: { min_sites: 2 }, severity: 'hard' })],
    });
    expect(evaluate(s).violations).toHaveLength(1);
  });
});

// ── Type 6: keep-in-one-site ──────────────────────────────────────────────────
describe('keep-in-one-site', () => {
  // Default scope (R1) flags ONLY RAC multi-node databases, so the geometry
  // fixture is a RAC multi-node cluster.
  const cluster = (s1, s2) => base({
    sites: [{ id: 'site-1' }, { id: 'site-2' }], specs: [spec('spec-a')],
    hypervisors: [hv('h1', s1), hv('h2', s2)],
    vms: [vm('v1', 'h1', { vm_type: 'db_host' }), vm('v2', 'h2', { vm_type: 'db_host' })],
    databases: [database('db-1', { topology: 'rac_multinode', node_count: 2 })],
    db_instances: [
      inst('i1', 'v1', { database_id: 'db-1', role: 'primary' }),
      inst('i2', 'v2', { database_id: 'db-1', role: 'primary' }),
    ],
    rules: [rule('keep-in-one-site', { level: 'db_instance', group_by: 'each_primary_cluster', severity: 'hard' })],
  });
  it('fails when a group spans two sites', () => {
    expect(evaluate(cluster('site-1', 'site-2')).violations).toHaveLength(1);
  });
  it('passes when a group shares one site', () => {
    expect(evaluate(cluster('site-1', 'site-1')).violations).toHaveLength(0);
  });
  it('optional site pin: fails when the group is off the pinned DC', () => {
    const s = { ...cluster('site-1', 'site-1'), rules: [rule('keep-in-one-site', { level: 'db_instance', group_by: 'each_primary_cluster', params: { site_id: 'site-2' }, severity: 'hard' })] };
    expect(evaluate(s).violations).toHaveLength(1);
  });
  it('optional site pin: passes when the group is on the pinned DC', () => {
    const s = { ...cluster('site-1', 'site-1'), rules: [rule('keep-in-one-site', { level: 'db_instance', group_by: 'each_primary_cluster', params: { site_id: 'site-1' } })] };
    expect(evaluate(s).violations).toHaveLength(0);
  });

  // ── apply_scope (R1, engine-level default) ──────────────────────────────────
  // Default scope narrows keep-in-one-site to RAC multi-node databases; 'all'
  // widens it back to every targeted database.
  const spanning = (topo, over = {}) => base({
    sites: [{ id: 'site-1' }, { id: 'site-2' }], specs: [spec('spec-a')],
    hypervisors: [hv('h1', 'site-1'), hv('h2', 'site-2')],
    vms: [vm('v1', 'h1', { vm_type: 'db_host' }), vm('v2', 'h2', { vm_type: 'db_host' })],
    databases: [database('db-1', { topology: topo, ...over })],
    db_instances: [
      inst('i1', 'v1', { database_id: 'db-1', role: 'primary' }),
      inst('i2', 'v2', { database_id: 'db-1', role: 'primary' }),
    ],
    rules: [rule('keep-in-one-site', { level: 'db_instance', group_by: 'each_primary_cluster', severity: 'hard' })],
  });
  it('default scope flags a RAC multi-node database spanning two sites', () => {
    expect(evaluate(spanning('rac_multinode', { node_count: 2 })).violations).toHaveLength(1);
  });
  it('default scope skips a RAC database with node_count < 2 (not multi-node)', () => {
    expect(evaluate(spanning('rac_multinode', { node_count: 1 })).violations).toHaveLength(0);
  });
  it('default scope skips a single-topology database', () => {
    expect(evaluate(spanning('single')).violations).toHaveLength(0);
  });
  it('default scope skips a primary_standby database', () => {
    expect(evaluate(spanning('primary_standby')).violations).toHaveLength(0);
  });
  // AR2-Q11 (spec §7 E1): isRacMultiNodeDatabase widens to match BOTH RAC
  // variants — a rac_multinode_standby database's PRIMARY cluster (this
  // fixture's each_primary_cluster group) is now pulled into default scope
  // exactly like plain rac_multinode. Its STANDBY cluster is untouched by
  // this predicate — a disjoint group_by (each_standby_cluster) scoped by the
  // separate default row rule-types.js gained for AR2-Q11, not this rule.
  it('default scope now flags a rac_multinode_standby database spanning two sites (AR2-Q11)', () => {
    expect(evaluate(spanning('rac_multinode_standby', { node_count: 2, standby_node_count: 2 })).violations).toHaveLength(1);
  });
  it('default scope skips a rac_multinode_standby database with node_count < 2 (not multi-node)', () => {
    expect(evaluate(spanning('rac_multinode_standby', { node_count: 1, standby_node_count: 2 })).violations).toHaveLength(0);
  });
  it("apply_scope='all' flags a single-topology database spanning two sites", () => {
    const s = spanning('single');
    s.rules = [rule('keep-in-one-site', { level: 'db_instance', group_by: 'each_primary_cluster', params: { apply_scope: 'all' }, severity: 'hard' })];
    expect(evaluate(s).violations).toHaveLength(1);
  });
  it("apply_scope='all' flags a primary_standby database spanning two sites", () => {
    const s = spanning('primary_standby');
    s.rules = [rule('keep-in-one-site', { level: 'db_instance', group_by: 'each_primary_cluster', params: { apply_scope: 'all' }, severity: 'hard' })];
    expect(evaluate(s).violations).toHaveLength(1);
  });
  it("apply_scope='all' flags a rac_multinode_standby database spanning two sites (widened scope agrees with the now-widened default)", () => {
    const s = spanning('rac_multinode_standby', { node_count: 2, standby_node_count: 2 });
    s.rules = [rule('keep-in-one-site', { level: 'db_instance', group_by: 'each_primary_cluster', params: { apply_scope: 'all' }, severity: 'hard' })];
    expect(evaluate(s).violations).toHaveLength(1);
  });
});

// ── AR2-Q11 (spec §7 E1): the each_standby_cluster keep-in-one-site default row ──
describe('keep-in-one-site each_standby_cluster (AR2-Q11)', () => {
  const standbyCluster = (topo, s1, s2, over = {}) => base({
    sites: [{ id: 'site-1' }, { id: 'site-2' }], specs: [spec('spec-a')],
    hypervisors: [hv('h1', 'site-1'), hv('h2', 'site-1'), hv('h3', s1), hv('h4', s2)],
    vms: [
      vm('v1', 'h1', { vm_type: 'db_host' }), vm('v2', 'h2', { vm_type: 'db_host' }),
      vm('v3', 'h3', { vm_type: 'db_host' }), vm('v4', 'h4', { vm_type: 'db_host' }),
    ],
    databases: [database('db-1', { topology: topo, node_count: 2, standby_node_count: 2, ...over })],
    db_instances: [
      inst('i1', 'v1', { database_id: 'db-1', role: 'primary' }),
      inst('i2', 'v2', { database_id: 'db-1', role: 'primary' }),
      inst('i3', 'v3', { database_id: 'db-1', role: 'standby' }),
      inst('i4', 'v4', { database_id: 'db-1', role: 'standby' }),
    ],
    rules: [rule('keep-in-one-site', { level: 'db_instance', group_by: 'each_standby_cluster', severity: 'hard' })],
  });
  it('default scope flags a rac_multinode_standby standby cluster spanning two sites', () => {
    expect(evaluate(standbyCluster('rac_multinode_standby', 'site-1', 'site-2')).violations).toHaveLength(1);
  });
  it('default scope passes a rac_multinode_standby standby cluster sharing one site', () => {
    expect(evaluate(standbyCluster('rac_multinode_standby', 'site-1', 'site-1')).violations).toHaveLength(0);
  });
  it('default scope skips a rac_multinode standby cluster (no standby role -> empty group)', () => {
    // rac_multinode has no standby instances at all — each_standby_cluster
    // yields an empty group for this database, so there is nothing to flag
    // regardless of the two "standby" hosts' sites.
    const s = standbyCluster('rac_multinode', 'site-1', 'site-2');
    s.db_instances = s.db_instances.filter((i) => i.role === 'primary');
    expect(evaluate(s).violations).toHaveLength(0);
  });
  it('default scope skips a primary_standby standby cluster (not RAC — RAC gate skips it)', () => {
    expect(evaluate(standbyCluster('primary_standby', 'site-1', 'site-2')).violations).toHaveLength(0);
  });
});

// ── labelGroup — violation messages never leak a raw id (spec §7, E8, fmb-1339) ─
describe('labelGroup: violation messages use names, not raw ids', () => {
  const UUID_RE = /[0-9a-f]{8}-/i;
  const dbId = '11111111-2222-3333-4444-555555555555';

  it('spread-across-sites: each_primary_cluster label uses the database name', () => {
    const s = base({
      sites: [{ id: 'site-1' }, { id: 'site-2' }], specs: [spec('spec-a')],
      hypervisors: [hv('h1', 'site-1'), hv('h2', 'site-1')],
      vms: [vm('v1', 'h1', { vm_type: 'db_host' }), vm('v2', 'h2', { vm_type: 'db_host' })],
      databases: [database(dbId, { function_name: 'erp' })],
      db_instances: [
        inst('i1', 'v1', { database_id: dbId, role: 'primary' }),
        inst('i2', 'v2', { database_id: dbId, role: 'primary' }),
      ],
      rules: [rule('spread-across-sites', { level: 'db_instance', group_by: 'each_primary_cluster', params: { min_sites: 2 }, severity: 'hard' })],
    });
    const v = evaluate(s).violations;
    expect(v).toHaveLength(1);
    expect(v[0].message).toContain('erp primary cluster');
    expect(v[0].message).not.toMatch(UUID_RE);
  });

  it('keep-in-one-site: each_standby_cluster label uses the database name', () => {
    const s = base({
      sites: [{ id: 'site-1' }, { id: 'site-2' }], specs: [spec('spec-a')],
      hypervisors: [hv('h1', 'site-1'), hv('h2', 'site-2')],
      vms: [vm('v1', 'h1', { vm_type: 'db_host' }), vm('v2', 'h2', { vm_type: 'db_host' })],
      databases: [database(dbId, { function_name: 'erp', topology: 'primary_standby' })],
      db_instances: [
        inst('i1', 'v1', { database_id: dbId, role: 'standby' }),
        inst('i2', 'v2', { database_id: dbId, role: 'standby' }),
      ],
      // apply_scope 'all': a primary_standby standby cluster is not RAC
      // multi-node, so widen scope to exercise the label path.
      rules: [rule('keep-in-one-site', { level: 'db_instance', group_by: 'each_standby_cluster', params: { apply_scope: 'all' }, severity: 'hard' })],
    });
    const v = evaluate(s).violations;
    expect(v).toHaveLength(1);
    expect(v[0].message).toContain('erp standby cluster');
    expect(v[0].message).not.toMatch(UUID_RE);
  });

  it('custom_group label uses the custom group name, not its id', () => {
    const groupId = '99999999-8888-7777-6666-555555555555';
    const s = base({
      sites: [{ id: 'site-1' }, { id: 'site-2' }], specs: [spec('spec-a')],
      hypervisors: [hv('h1', 'site-1'), hv('h2', 'site-2')],
      vms: [vm('a1', 'h1', { vm_type: 'ap_host' }), vm('a2', 'h2', { vm_type: 'ap_host' })],
      custom_groups: [{ id: groupId, scenario_id: 'scn-1', name: 'AP tier', team_id: null }],
      custom_group_members: [
        { id: 'm1', scenario_id: 'scn-1', group_id: groupId, member_instance_id: null, member_vm_id: 'a1' },
        { id: 'm2', scenario_id: 'scn-1', group_id: groupId, member_instance_id: null, member_vm_id: 'a2' },
      ],
      // apply_scope 'all': a custom_group has no single database (default scope
      // would skip it) — widen to exercise the custom-group label path.
      rules: [rule('keep-in-one-site', { level: 'db_instance', group_by: 'custom_group', custom_group_id: groupId, params: { apply_scope: 'all' }, severity: 'hard' })],
    });
    const v = evaluate(s).violations;
    expect(v).toHaveLength(1);
    expect(v[0].message).toContain('AP tier');
    expect(v[0].message).not.toMatch(UUID_RE);
  });
});

// ── SGA-cap capacity check (spec §3.4) — a built-in, NOT a rule type ───────────
describe('SGA-cap check', () => {
  const withProfile = (prof, sgaTotal, settings = {}) => base({
    settings,
    specs: [spec('spec-a')], hypervisors: [hv('h1', 'site-1')],
    vms: [vm('v1', 'h1', { vm_type: 'db_host', sizing_profile_id: prof.id })],
    vm_profiles: [prof],
    db_instances: [inst('i1', 'v1', { sga_gb: sgaTotal })],
  });
  it('computeSgaCap formula DB-16C → 155, DB-8C → 76 (floored, spec §3.4)', () => {
    expect(computeSgaCap(profile('p', { cpu: 16 }), {})).toBe(155);
    expect(computeSgaCap(profile('p', { cpu: 8 }), {})).toBe(76);
  });
  it('computeSgaCap custom mode uses the hand-set cap; AP-class has none', () => {
    expect(computeSgaCap(profile('p', { mode: 'custom', sga_cap_gb: 100 }), {})).toBe(100);
    expect(computeSgaCap(profile('p', { class: 'AP' }), {})).toBeNull();
  });
  it('fails when Σ instance SGA exceeds the formula cap', () => {
    const v = evaluate(withProfile(profile('p16', { cpu: 16 }), 156)).violations;
    expect(v).toHaveLength(1);
    expect(v[0].rule_id).toBe(SGA_CAP_RULE_ID);
    expect(v[0].rule_type).toBe('sga-cap');
    expect(v[0].severity).toBe('hard');
    expect(v[0].subject_ids).toEqual(['v1']);
  });
  it('passes at the cap boundary (=155, not over)', () => {
    expect(evaluate(withProfile(profile('p16', { cpu: 16 }), 155)).violations).toHaveLength(0);
  });
  it('custom-mode cap is enforced', () => {
    expect(evaluate(withProfile(profile('pc', { mode: 'custom', sga_cap_gb: 100 }), 120)).violations).toHaveLength(1);
  });
  it('a db_host VM with no profile has no cap (skipped)', () => {
    const s = base({
      specs: [spec('spec-a')], hypervisors: [hv('h1', 'site-1')],
      vms: [vm('v1', 'h1', { vm_type: 'db_host', sizing_profile_id: null })],
      db_instances: [inst('i1', 'v1', { sga_gb: 9999 })],
    });
    expect(evaluate(s).violations).toHaveLength(0);
  });
  it('editable constants shift the cap', () => {
    // ratio 10 ⇒ mem 160, cap floor(160×0.982/2−2)=76; 100 > 76 ⇒ violation.
    const v = evaluate(withProfile(profile('p16', { cpu: 16 }), 100, { mem_cpu_ratio: 10 })).violations;
    expect(v).toHaveLength(1);
  });
});

// ── Override-row resolution (spec §13.4 / §17.1) ──────────────────────────────
describe('override-row resolution', () => {
  const density = (n) => ({
    specs: [spec('spec-a')], hypervisors: [hv('h1', 'site-1')],
    vms: Array.from({ length: n }, (_, i) => vm(`v${i}`, 'h1')),
  });
  it('an override row disables its global template rule in-scenario', () => {
    const s = base({
      ...density(9),
      rules: [
        rule('max-vms-per-host', { id: 'g1', scenario_id: null, level: 'hypervisor', group_by: 'all_of_type', params: { max: 8 }, severity: 'hard' }),
        rule('max-vms-per-host', { id: 'o1', scenario_id: 'scn-1', overrides_rule_id: 'g1', enabled: false }),
      ],
    });
    expect(evaluate(s).violations).toHaveLength(0);
  });
  it('an override row re-parameterises (max) + re-severities the global rule', () => {
    const s = base({
      ...density(4),
      rules: [
        rule('max-vms-per-host', { id: 'g1', scenario_id: null, level: 'hypervisor', group_by: 'all_of_type', params: { max: 8 }, severity: 'soft' }),
        rule('max-vms-per-host', { id: 'o1', scenario_id: 'scn-1', overrides_rule_id: 'g1', enabled: true, params: { max: 3 }, severity: 'hard' }),
      ],
    });
    const v = evaluate(s).violations;
    expect(v).toHaveLength(1);
    expect(v[0].rule_id).toBe('g1'); // the effective rule keeps the global identity
    expect(v[0].severity).toBe('hard');
  });
});

// ── Default + exception precedence + clash (spec §13.3) ───────────────────────
describe('precedence + clash', () => {
  // erp + rpt primary clusters, both placed entirely in site-1.
  const worked = () => base({
    sites: [{ id: 'site-1' }, { id: 'site-2' }], specs: [spec('spec-a')],
    hypervisors: [hv('h1', 'site-1')],
    vms: [vm('v-erp', 'h1', { vm_type: 'db_host' }), vm('v-rpt', 'h1', { vm_type: 'db_host' })],
    databases: [database('db-erp', { function_name: 'erp' }), database('db-rpt', { function_name: 'rpt' })],
    db_instances: [
      inst('e1', 'v-erp', { database_id: 'db-erp', role: 'primary' }),
      inst('e2', 'v-erp', { database_id: 'db-erp', role: 'primary' }),
      inst('r1', 'v-rpt', { database_id: 'db-rpt', role: 'primary' }),
      inst('r2', 'v-rpt', { database_id: 'db-rpt', role: 'primary' }),
    ],
    rules: [
      rule('spread-across-sites', { id: 'r-spread', level: 'db_instance', group_by: 'each_primary_cluster', params: { min_sites: 2 }, severity: 'hard' }),
      // apply_scope 'all': the pin is an authored exception on 'primary'-topology
      // erp — widen scope so the precedence example still fires the pin.
      rule('keep-in-one-site', { id: 'r-pin', level: 'db_instance', group_by: 'each_primary_cluster', filters: [{ field: 'function', op: '=', value: 'erp' }], params: { site_id: 'site-2', apply_scope: 'all' }, severity: 'hard' }),
    ],
  });
  it('specific exception wins: erp pinned (spread suppressed), rest spread (§13.3 worked example)', () => {
    const v = evaluate(worked()).violations;
    // spread suppressed on erp; spread fires on rpt; pin fires on erp.
    const byRule = (id) => v.filter((x) => x.rule_id === id);
    expect(byRule('r-spread')).toHaveLength(1);
    expect(byRule('r-spread')[0].subject_ids.sort()).toEqual(['r1', 'r2']); // rpt, not erp
    expect(byRule('r-pin')).toHaveLength(1);
    expect(byRule('r-pin')[0].subject_ids.sort()).toEqual(['e1', 'e2']); // erp pinned
    expect(v).toHaveLength(2);
  });
  it('a default/exception pair is NOT a clash (precedence resolves it)', () => {
    expect(evaluate(worked()).clashes).toHaveLength(0);
  });
  it('two same-target contradictory rules clash — both flagged, not a violation', () => {
    const s = base({
      databases: [database('db-1')],
      rules: [
        rule('spread-across-sites', { id: 'r-a', level: 'db_instance', group_by: 'each_primary_cluster', params: { min_sites: 2 } }),
        rule('keep-in-one-site', { id: 'r-b', level: 'db_instance', group_by: 'each_primary_cluster' }),
      ],
    });
    const { clashes } = evaluate(s);
    expect(clashes).toHaveLength(1);
    expect(clashes[0].rule_ids).toEqual(['r-a', 'r-b']);
  });
  it('different group_by is NOT a clash (default template: pin=primary cluster, spread=database)', () => {
    const rules = [
      rule('keep-in-one-site', { id: 'r-a', level: 'db_instance', group_by: 'each_primary_cluster' }),
      rule('spread-across-sites', { id: 'r-b', level: 'db_instance', group_by: 'each_database', params: { min_sites: 2 } }),
    ];
    expect(detectRuleClashes(rules)).toHaveLength(0);
  });
});

// ── Default template smoke (all 6 on, conflict-free on day one, §13.1a) ───────
describe('default template is conflict-free on a well-placed scenario (§13.1a)', () => {
  const defaultRules = () => [
    rule('no-oversell', { id: 'd1', level: 'hypervisor', group_by: 'all_of_type', params: { resources: ['cpu', 'mem', 'disk'] }, severity: 'hard' }),
    rule('max-vms-per-host', { id: 'd2', level: 'hypervisor', group_by: 'all_of_type', params: { max: 8 }, severity: 'hard' }),
    rule('max-instances-per-vm', { id: 'd3', level: 'vm', group_by: 'all_of_type', params: { max: 4 }, severity: 'hard' }),
    rule('keep-apart', { id: 'd4', level: 'db_instance', group_by: 'each_primary_cluster', severity: 'hard' }),
    rule('keep-in-one-site', { id: 'd5', level: 'db_instance', group_by: 'each_primary_cluster', severity: 'hard' }),
    rule('spread-across-sites', { id: 'd6', level: 'db_instance', group_by: 'each_database', params: { min_sites: 2 }, severity: 'hard' }),
  ];
  it('a correctly-placed Primary+Standby database raises zero violations + zero clashes', () => {
    const s = base({
      sites: [{ id: 'site-1' }, { id: 'site-2' }],
      specs: [spec('spec-a', { cpu_total: 64 })],
      // primary cluster nodes on distinct hosts in site-1; standby on site-2.
      hypervisors: [hv('h1', 'site-1'), hv('h2', 'site-1'), hv('h3', 'site-2'), hv('h4', 'site-2')],
      vms: [
        vm('v1', 'h1', { vm_type: 'db_host' }), vm('v2', 'h2', { vm_type: 'db_host' }),
        vm('v3', 'h3', { vm_type: 'db_host' }), vm('v4', 'h4', { vm_type: 'db_host' }),
      ],
      databases: [database('db-1', { topology: 'primary_standby' })],
      db_instances: [
        inst('i1', 'v1', { database_id: 'db-1', role: 'primary', sga_gb: 10 }),
        inst('i2', 'v2', { database_id: 'db-1', role: 'primary', sga_gb: 10 }),
        inst('i3', 'v3', { database_id: 'db-1', role: 'standby', sga_gb: 10 }),
        inst('i4', 'v4', { database_id: 'db-1', role: 'standby', sga_gb: 10 }),
      ],
      rules: defaultRules(),
    });
    const { violations, clashes } = evaluate(s);
    expect(violations).toHaveLength(0);
    expect(clashes).toHaveLength(0);
  });
  it('a Single-topology database raises zero violations (keep-apart + spread both arity-skip)', () => {
    const s = base({
      sites: [{ id: 'site-1' }], specs: [spec('spec-a', { cpu_total: 64 })],
      hypervisors: [hv('h1', 'site-1')],
      vms: [vm('v1', 'h1', { vm_type: 'db_host' })],
      databases: [database('db-1', { topology: 'single' })],
      db_instances: [inst('i1', 'v1', { database_id: 'db-1', role: 'primary', sga_gb: 10 })],
      rules: defaultRules(),
    });
    expect(evaluate(s).violations).toHaveLength(0);
  });
});

// ── Exceptions (spec §3.3) ────────────────────────────────────────────────────
describe('exceptions (waivers)', () => {
  const oversold = () => base({
    specs: [spec('spec-a', { cpu_total: 16, mem_total_gb: 100, disk_total_gb: 100 })],
    hypervisors: [hv('h1', 'site-1')],
    vms: [vm('v1', 'h1', { cpu: 20, mem_gb: 50, disk_gb: 50 })],
    rules: [rule('no-oversell', { id: 'r-cap', level: 'hypervisor', group_by: 'all_of_type', severity: 'hard' })],
  });
  it('a matching Exception marks the violation waived (not hidden)', () => {
    const s = oversold();
    s.waivers = [{ id: 'w1', rule_id: 'r-cap', object_set_key: objectSetKey(['h1']) }];
    const { violations } = evaluate(s);
    expect(violations).toHaveLength(1);
    expect(violations[0].waived).toBe(true);
    expect(summarize(violations)).toEqual({ hard: 0, soft: 0, waived: 1, total: 1 });
  });
  it('an Exception for a different rule_id does NOT match', () => {
    const s = oversold();
    s.waivers = [{ id: 'w1', rule_id: 'other-rule', object_set_key: objectSetKey(['h1']) }];
    expect(evaluate(s).violations[0].waived).toBe(false);
  });
  it('an SGA-cap Exception matches the synthetic rule id', () => {
    const s = base({
      specs: [spec('spec-a')], hypervisors: [hv('h1', 'site-1')],
      vms: [vm('v1', 'h1', { vm_type: 'db_host', sizing_profile_id: 'p16' })],
      vm_profiles: [profile('p16', { cpu: 16 })],
      db_instances: [inst('i1', 'v1', { sga_gb: 200 })],
      waivers: [{ id: 'w', rule_id: SGA_CAP_RULE_ID, object_set_key: objectSetKey(['v1']) }],
    });
    const v = evaluate(s).violations;
    expect(v).toHaveLength(1);
    expect(v[0].waived).toBe(true);
  });
  it('a stale Exception (subject set changed) resurfaces the violation', () => {
    const build = (sharedHost) => base({
      specs: [spec('spec-a')], hypervisors: [hv('h1', 'site-1'), hv('h2', 'site-1')],
      vms: [vm('v1', 'h1', { vm_type: 'db_host' }), vm('v2', sharedHost, { vm_type: 'db_host' })],
      databases: [database('db-1')],
      db_instances: [inst('i1', 'v1', { database_id: 'db-1' }), inst('i2', 'v2', { database_id: 'db-1' })],
      rules: [rule('keep-apart', { id: 'r-anti', level: 'db_instance', group_by: 'each_primary_cluster' })],
    });
    const colocated = build('h1');
    const key = objectSetKey(['i1', 'i2']);
    colocated.waivers = [{ id: 'w', rule_id: 'r-anti', object_set_key: key }];
    expect(evaluate(colocated).violations[0].waived).toBe(true);
    const separated = build('h2');
    separated.waivers = [{ id: 'w', rule_id: 'r-anti', object_set_key: key }];
    expect(evaluate(separated).violations).toHaveLength(0);
  });
});

// ── Cross-cutting invariants ──────────────────────────────────────────────────
describe('cross-cutting', () => {
  it('disabled rules are skipped', () => {
    const s = base({
      specs: [spec('spec-a', { cpu_total: 1 })], hypervisors: [hv('h1', 'site-1')],
      vms: [vm('v1', 'h1', { cpu: 99 })],
      rules: [rule('no-oversell', { level: 'hypervisor', group_by: 'all_of_type', enabled: false })],
    });
    expect(evaluate(s).violations).toHaveLength(0);
  });
  it('unknown rule type yields no marker (forward-compatible)', () => {
    const s = base({ rules: [rule('some-future-type', {})] });
    expect(evaluate(s).violations).toHaveLength(0);
  });
  it('severity defaults to soft; hard is honoured; summarize splits them', () => {
    const s = base({
      specs: [spec('spec-a', { cpu_total: 1 })],
      hypervisors: [hv('h1', 'site-1'), hv('h2', 'site-1')],
      vms: [vm('v1', 'h1', { cpu: 99 }), vm('v2', 'h2', { cpu: 99 })],
      rules: [
        rule('no-oversell', { id: 'hardR', level: 'hypervisor', group_by: 'all_of_type', severity: 'hard' }),
        rule('max-vms-per-host', { id: 'softR', level: 'hypervisor', group_by: 'all_of_type', params: { max: 0 }, severity: 'soft' }),
      ],
    });
    const sum = summarize(evaluate(s).violations);
    expect(sum.hard).toBeGreaterThan(0);
    expect(sum.soft).toBeGreaterThan(0);
  });
  it('empty state is inert', () => {
    expect(evaluate({}).violations).toEqual([]);
    expect(evaluate(undefined).violations).toEqual([]);
    expect(evaluate({}).clashes).toEqual([]);
  });
});

// ── Malformed JSON filters/params → visible config-error marker ───────────────
describe('config-error surfacing', () => {
  it('a rule with unparseable filters emits a visible marker and is skipped', () => {
    const s = base({
      specs: [spec('spec-a', { cpu_total: 1 })], hypervisors: [hv('h1', 'site-1')],
      vms: [vm('v1', 'h1', { cpu: 99 })],
      rules: [{ id: 'r-bad', scenario_id: 'scn', type: 'no-oversell', name: 'Bad', level: 'hypervisor', group_by: 'all_of_type', filters: '{oops', params: null, severity: 'hard', enabled: true }],
    });
    const v = evaluate(s).violations;
    expect(v).toHaveLength(1);
    expect(v[0].config_error).toBe(true);
    expect(v[0].message).toMatch(/invalid filters/);
  });
  it('a valid JSON string filters/params is parsed and evaluated normally', () => {
    const s = base({
      specs: [spec('spec-a', { cpu_total: 1 })], hypervisors: [hv('h1', 'site-1')],
      vms: [vm('v1', 'h1', { cpu: 99 })],
      rules: [{ id: 'r-ok', scenario_id: 'scn', type: 'no-oversell', name: 'Ok', level: 'hypervisor', group_by: 'all_of_type', filters: '[]', params: '{}', severity: 'hard', enabled: true }],
    });
    const v = evaluate(s).violations;
    expect(v).toHaveLength(1);
    expect(v[0].config_error).toBeUndefined();
  });

  // Empty-vs-NULL blind spot: NULL, '{}', '[]' and '' must all read as "no
  // config" — before the fix an empty-string params/filters was the one
  // representation that raised a false config-error and skipped the rule, while
  // NULL and '{}' evaluated fine. Pin every empty representation as equivalent.
  const emptyRepr = [
    ['NULL', null, null],
    ["empty object/array '{}'/'[]'", '[]', '{}'],
    ["empty string ''", '', ''],
    ['whitespace-only string', '   ', '  '],
  ];
  for (const [label, filters, params] of emptyRepr) {
    it(`${label} filters/params reads as no-config — evaluated, no config-error`, () => {
      const s = base({
        specs: [spec('spec-a', { cpu_total: 1 })], hypervisors: [hv('h1', 'site-1')],
        vms: [vm('v1', 'h1', { cpu: 99 })],
        rules: [{ id: 'r-empty', scenario_id: 'scn', type: 'no-oversell', name: 'Empty', level: 'hypervisor', group_by: 'all_of_type', filters, params, severity: 'hard', enabled: true }],
      });
      const v = evaluate(s).violations;
      expect(v).toHaveLength(1);
      expect(v[0].config_error).toBeUndefined();
    });
  }

  it('a genuinely malformed (non-empty) params still surfaces a config-error', () => {
    const s = base({
      specs: [spec('spec-a', { cpu_total: 1 })], hypervisors: [hv('h1', 'site-1')],
      vms: [vm('v1', 'h1', { cpu: 99 })],
      rules: [{ id: 'r-bad2', scenario_id: 'scn', type: 'no-oversell', name: 'Bad', level: 'hypervisor', group_by: 'all_of_type', filters: null, params: '{oops', severity: 'hard', enabled: true }],
    });
    const v = evaluate(s).violations;
    expect(v).toHaveLength(1);
    expect(v[0].config_error).toBe(true);
    expect(v[0].message).toMatch(/invalid params/);
  });
});

// ── Iteration budget (DoS back-pressure) ──────────────────────────────────────
describe('iteration budget', () => {
  const s = () => base({
    specs: [spec('spec-a', { cpu_total: 1 })], hypervisors: [hv('h1', 'site-1')],
    vms: [vm('v1', 'h1', { cpu: 99 })],
    rules: [rule('no-oversell', { level: 'hypervisor', group_by: 'all_of_type', severity: 'hard' })],
  });
  it('budget_exceeded=false under the default budget', () => {
    expect(evaluate(s()).budget_exceeded).toBe(false);
  });
  it('bails with partial results + flag when the budget is exhausted', () => {
    const res = evaluate(s(), { budget: 0 });
    expect(res.budget_exceeded).toBe(true);
    expect(res.violations).toHaveLength(0); // no SGA breach in this fixture, and the rule loop bailed
  });
});

// ── Division-by-zero guard (usable = 0 ⇒ utilization 0, not NaN) ──────────────
describe('div-by-zero', () => {
  it('utilization is 0 (never NaN) when usable is 0', () => {
    const s = base({
      specs: [spec('spec-a', { cpu_total: 0, mem_total_gb: 0, disk_total_gb: 0 })],
      hypervisors: [hv('h1', 'site-1')],
      vms: [vm('v1', 'h1', { cpu: 0, mem_gb: 0, disk_gb: 0 })],
    });
    const u = evaluate(s).rollups.hypervisors.h1.utilization;
    expect(u.cpu).toBe(0);
    expect(Number.isNaN(u.mem)).toBe(false);
    expect(u.disk).toBe(0);
  });
});

// ── Site-level rollups (spec §8) ──────────────────────────────────────────────
describe('site rollups', () => {
  it('aggregates used/usable + utilization per site', () => {
    const s = base({
      sites: [{ id: 'site-1', name: 'DC-1' }],
      specs: [spec('spec-a', { cpu_total: 64, mem_total_gb: 1000, disk_total_gb: 500 })],
      hypervisors: [hv('h1', 'site-1', 'spec-a'), hv('h2', 'site-1', 'spec-a')],
      vms: [vm('v1', 'h1', { cpu: 8, mem_gb: 100, disk_gb: 50 }), vm('v2', 'h2', { cpu: 16, mem_gb: 200, disk_gb: 100 })],
    });
    const site = evaluate(s).rollups.sites['site-1'];
    expect(site.used).toEqual({ cpu: 24, mem: 300, disk: 150 });
    expect(site.usable).toEqual({ cpu: 128, mem: 2000, disk: 1000 });
    expect(site.utilization.cpu).toBeCloseTo(24 / 128);
  });
});
