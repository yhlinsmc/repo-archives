'use strict';

/**
 * dc-refs.js — what an entry of `cap_databases.dc_refs` IS, and what it means
 * for one to resolve. The reference statement of a rule that exists in three
 * places, because it has to: this module, its frontend mirror
 * (`src/fmb/capacity/lib/placement-dc-candidates.ts`, which the Vite bundle
 * cannot import from here), and the SQL aggregate that answers the scenario
 * list badge without loading the rows.
 *
 * THE RULE, ONCE:
 *
 *   The ENTRIES of a `dc_refs` value are the elements of its JSON array, taken
 *   as strings, with the empty string dropped and duplicates removed. An element
 *   that is not a scalar — an object, a nested array — IS STILL AN ENTRY: one
 *   the code cannot read as an identifier, and therefore one that resolves to
 *   nothing. No entries at all — null, `[]`, `[""]` — means UNRESTRICTED: every
 *   data centre, which is why a dangling entry can never simply be deleted from
 *   the list.
 *
 *   An entry RESOLVES when a site in the same scenario has an `id` EXACTLY equal
 *   to it. Exactly means what JavaScript's `===` means: no case folding, no
 *   trailing-space padding, no truncation. That is not a preference — it is the
 *   comparison `dcRefsAdmitsSite` makes when it decides where a database's VMs
 *   may be placed, so an entry that fails it admits nothing and restricts
 *   nothing, wherever it is being judged.
 *
 * Each of the three copies was wrong about a different part of that sentence,
 * and each disagreed with the other two about a different input — so the answer
 * is not three fixes but one statement plus a mechanical comparison of every
 * copy against it. `DC_REFS_PARITY_CASES` below is that comparison's corpus: the
 * frontend mirror is driven over it by a vitest parity suite, and the SQL is
 * driven over it against a real database by an integration test. A copy that
 * drifts fails on the case it drifted on rather than on nobody noticing.
 */

/**
 * The entries of a stored `dc_refs` value: distinct, non-empty, in first-seen
 * order. Accepts an already-parsed array or the raw JSON string, because the
 * column arrives as either depending on which route served the row.
 *
 * A value that is not an array at all — a JSON scalar, an object, unparseable
 * text — has NO entries and is therefore unrestricted, which is the same answer
 * the column's own absence gives. THIS IS DELIBERATE, NOT AN OMISSION, and it is
 * the one place this rule does NOT follow "an unintelligible restriction must
 * never read as no restriction" (the paragraph below): the SQL copy's
 * `JSON_TABLE(..., '$[*]' ...)` structurally cannot produce a row for a value
 * that is not a JSON array at all — there is nothing to iterate — so it has
 * always answered zero broken references for this shape, by construction, not
 * by choice. Changing the JS answer here to "one unreadable entry" would put
 * the three-way parity this module states in its module doc out of sync with
 * no SQL change able to restore it inside a `JSON_TABLE` expansion. `isDcRefsCorrupt`
 * below answers the question "is this legible at all" WITHOUT moving the
 * entries/dangling/unrestricted verdict every layer already agrees on — a
 * caller that wants to say "unreadable" instead of "unrestricted" (as C11 did
 * for `allowed_disk_combos`, a column with no SQL-side JSON_TABLE parity
 * contract) reaches for that, not for a changed `dcRefEntries`.
 *
 * AN ELEMENT THIS CANNOT READ IS AN ENTRY, NOT A GAP, and an earlier version of
 * this function skipping those was a real widening rather than a tidy-up: a
 * restriction of `[{}]` became "every data centre" instead of "no data centre
 * this can name", so a database whose restriction nobody could understand became
 * placeable anywhere, silently, on every layer at once. An unintelligible
 * restriction must never read as no restriction. Its entry is the element's JSON
 * text, which is also what the SQL copy keys on, so two identical objects are
 * one entry and two different ones are two. It can never RESOLVE: a site id is
 * always a server-assigned uuid (a client-supplied `id` on POST /sites is
 * ignored — measured), so no site id is ever `{}` or `["x"]`.
 */
function dcRefEntries(raw) {
  let arr = raw;
  if (typeof raw === 'string') {
    const trimmed = raw.trim();
    if (!trimmed) return [];
    try { arr = JSON.parse(trimmed); } catch { return []; }
  }
  if (!Array.isArray(arr)) return [];
  const seen = new Set();
  const out = [];
  for (const value of arr) {
    let entry;
    if (value !== null && typeof value === 'object') {
      // JSON text, matching the key the SQL copy builds from the same element.
      // A structure JSON.stringify cannot render (only a JS caller can supply
      // one) still has to restrict rather than vanish.
      try { entry = JSON.stringify(value); } catch { entry = '[unreadable]'; }
      if (typeof entry !== 'string') entry = '[unreadable]';
    } else {
      entry = value === null || value === undefined ? '' : String(value);
    }
    if (!entry) continue;
    if (seen.has(entry)) continue;
    seen.add(entry);
    out.push(entry);
  }
  return out;
}

/**
 * Whether a stored `dc_refs` value is present but ILLEGIBLE — a non-null value
 * that is neither a JSON array nor JSON text that parses to one. Distinct from
 * `dcRefEntries([]).length === 0`, which is also true for this shape (see the
 * SQL-parity note on `dcRefEntries` above for why that stays unchanged): this
 * answers "can a person or the placement logic make any sense of this at all",
 * for a caller that needs to say "unreadable" rather than "unrestricted" (the
 * disk-combo family's fmb-1300/C11 UI treatment) without moving the
 * entries/dangling verdict every layer already agrees on.
 *
 * `null`/`undefined`/an empty or blank string are the column's genuine "no
 * restriction" absence, not corruption — not corrupt. A present array is
 * always legible at this level (an unreadable ELEMENT inside it is still an
 * entry, per `dcRefEntries` above, not a reason to call the whole value corrupt).
 *
 * @param {unknown} raw
 * @returns {boolean}
 */
function isDcRefsCorrupt(raw) {
  if (raw == null) return false;
  let arr = raw;
  if (typeof raw === 'string') {
    const trimmed = raw.trim();
    if (!trimmed) return false;
    try { arr = JSON.parse(trimmed); } catch { return true; }
  }
  return !Array.isArray(arr);
}

/** No entries = every data centre. The reason a dangling entry cannot be
 *  scrubbed: removing the last one WIDENS the restriction to everything. */
function dcRefsUnrestricted(raw) {
  return dcRefEntries(raw).length === 0;
}

/**
 * Rewrite each RESOLVABLE scalar entry of a stored `dc_refs` value to the exact
 * spelling of the site it names, leaving every other element — a non-resolving
 * id, a number, an object, a null, an empty string — byte-for-byte as it was.
 *
 * WHY ONLY THE SPELLING, AND WHY NOT A REFUSAL. A `dc_refs` entry resolves in
 * SQL under the `CHAR(36)` case-folding collation (`= ?` folds case and PADs
 * trailing space), but every reader compares bytes — `dcRefsAdmitsSite`'s
 * `.includes`, `filterDcCandidates`, the delete's `JSON_CONTAINS`/`JSON_QUOTE`
 * probe. So a case- or pad-variant of a REAL site id resolves for SQL and admits
 * nothing for the readers: it restricts the database to no data centre and blocks
 * nothing on a site delete. Storing the site's OWN spelling is what makes the two
 * layers agree — the fix is here on the write, not by loosening the readers
 * (`site-references.js` top note). An entry that names no site is left EXACTLY as
 * it was: declaring `dc_refs` a validated reference (refusing or dropping such an
 * entry) changes what the column may store and the write-vs-site-delete race, and
 * is deliberately out of scope.
 *
 * `resolve(entry)` returns the site's stored id for an entry that names a site in
 * the scenario (under the DB's own comparison) or null. The caller supplies it so
 * this module holds no database import — the same reason its frontend mirror can
 * carry a copy of the entry rule.
 *
 * SHAPE-PRESERVING: array length and element order are unchanged, only the VALUE
 * of a resolving string element changes. Deliberately NOT deduplicated — two
 * variants of one id both become that id and `dcRefEntries` collapses them on
 * read; the storage stays a faithful rewrite, not a normalisation (which would be
 * a storage-shape change). Returns a NEW array when at least one entry changed,
 * else null (a value that is not a parseable array, or one already canonical, has
 * nothing to write back).
 */
// NOTE: `null` is overloaded — it means both "nothing resolved to a different
// spelling" and "raw was not a parseable array at all". Both readings are safe
// for the one caller (`makeDcRefsCanonicalizer` in capacity/_shared.js): either
// way there is no rewritten value to write back, so the caller leaves the
// column exactly as the request body already has it (or as it was already
// stored, on a partial PUT). A caller that needed to tell the two apart would
// need a distinct sentinel; none currently does.
async function canonicalizeDcRefs(raw, resolve) {
  let arr = raw;
  if (typeof raw === 'string') {
    const trimmed = raw.trim();
    if (!trimmed) return null;
    try { arr = JSON.parse(trimmed); } catch { return null; }
  }
  if (!Array.isArray(arr)) return null;
  const cache = new Map();
  const out = [];
  let changed = false;
  for (const el of arr) {
    if (typeof el === 'string' && el) {
      let canon = cache.get(el);
      if (canon === undefined) { canon = await resolve(el); cache.set(el, canon); }
      if (canon != null && canon !== el) {
        out.push(canon);
        changed = true;
        continue;
      }
    }
    out.push(el);
  }
  return changed ? out : null;
}

/**
 * The entries that name no site in the scenario. `siteIds` is anything with a
 * `.has` (a Set) or an array — membership is exact, never folded.
 */
function danglingDcRefs(raw, siteIds) {
  const has = typeof siteIds?.has === 'function'
    ? (v) => siteIds.has(v)
    : (v) => Array.isArray(siteIds) && siteIds.indexOf(v) !== -1;
  return dcRefEntries(raw).filter((entry) => !has(entry));
}

// One site id, and the shapes that have to be judged against it. `SITE` is a
// real 36-character uuid on purpose: at 36 characters an entry of `id + suffix`
// is exactly what a fixed-width extraction truncates back onto the id, which is
// the input a shorter fixture cannot reach.
const SITE = 'aaaabbbb-cccc-4ddd-8eee-ffffff111abc';
// Letters on purpose: an id of digits alone is unchanged by upper-casing, so
// the two-respellings cases below would collapse to one entry and prove nothing.
const OTHER = '00000000-0000-4000-8000-0000000000ab';

/**
 * The corpus every copy of the rule is driven over. `entries` is what
 * `dcRefEntries` must answer; `dangling` is what `danglingDcRefs` must answer
 * against a scenario whose only site is SITE.
 *
 * Published from the reference implementation so the mirrors cannot each carry
 * their own idea of the input set — two suites of hand-written expectations can
 * both be right about different functions, which is how these three copies got
 * out of step in the first place.
 */
const DC_REFS_PARITY_CASES = Object.freeze([
  { name: 'unset', raw: null, entries: [], dangling: [] },
  { name: 'empty list', raw: [], entries: [], dangling: [] },
  { name: 'the site itself', raw: [SITE], entries: [SITE], dangling: [] },
  { name: 'a site that is not there', raw: [OTHER], entries: [OTHER], dangling: [OTHER] },
  { name: 'both, resolvable first', raw: [SITE, OTHER], entries: [SITE, OTHER], dangling: [OTHER] },
  { name: 'both, dangling first', raw: [OTHER, SITE], entries: [OTHER, SITE], dangling: [OTHER] },
  // A spelling no reader can follow. It admits nothing, so it is dangling —
  // never "the site, respelled".
  { name: 'upper-cased', raw: [SITE.toUpperCase()], entries: [SITE.toUpperCase()], dangling: [SITE.toUpperCase()] },
  { name: 'upper then exact', raw: [SITE.toUpperCase(), SITE], entries: [SITE.toUpperCase(), SITE], dangling: [SITE.toUpperCase()] },
  // PAD SPACE makes `'x ' = 'x'` true under every collation MariaDB offers,
  // including utf8mb4_bin — so a comparison built on `=` calls this resolvable
  // while `includes` does not.
  { name: 'trailing space', raw: [`${SITE} `], entries: [`${SITE} `], dangling: [`${SITE} `] },
  { name: 'leading space', raw: [` ${SITE}`], entries: [` ${SITE}`], dangling: [` ${SITE}`] },
  // Longer than a site id. A fixed-width extraction cuts it back onto the id
  // and calls it resolvable; nothing that reads the column can follow it.
  { name: 'the site plus a suffix', raw: [`${SITE}ZZZZ`], entries: [`${SITE}ZZZZ`], dangling: [`${SITE}ZZZZ`] },
  // Not an entry: dropped, so a list of only these is unrestricted.
  { name: 'empty string entry', raw: [''], entries: [], dangling: [] },
  { name: 'empty string beside a real one', raw: ['', SITE], entries: [SITE], dangling: [] },
  { name: 'a null element', raw: [null], entries: [], dangling: [] },
  // Whitespace IS an entry — it is not the empty string, and no site id equals
  // it. The SQL's temptation here is `<> ''`, which PAD SPACE makes false.
  { name: 'a whitespace entry', raw: [' '], entries: [' '], dangling: [' '] },
  // One broken reference written twice is one broken reference.
  { name: 'a repeated dangling entry', raw: [OTHER, OTHER], entries: [OTHER], dangling: [OTHER] },
  { name: 'a repeated resolvable entry', raw: [SITE, SITE], entries: [SITE], dangling: [] },
  { name: 'several distinct dangling entries', raw: [SITE, OTHER, `${OTHER}9`], entries: [SITE, OTHER, `${OTHER}9`], dangling: [OTHER, `${OTHER}9`] },
  // Non-strings that do have an honest string form.
  { name: 'a numeric element', raw: [12345], entries: ['12345'], dangling: ['12345'] },
  // No entries at all: unrestricted, exactly like an absent column (the
  // SQL-parity note on `dcRefEntries` explains why this stays `[]` rather than
  // an unreadable entry) — but `isDcRefsCorrupt` must still tell it apart from
  // a genuinely empty/absent value, hence `corrupt: true` here alone.
  { name: 'a JSON scalar, not a list', raw: '"not-a-list"', entries: [], dangling: [], corrupt: true },
  // Text that never round-trips through JSON.parse at all — reachable only on
  // a row written before the column's json_valid CHECK existed, or a raw body
  // that skipped validation; storeCase() below skips it for the SQL side (the
  // engine itself refuses it), so this only drives the JS/TS mirrors.
  { name: 'unparseable JSON text', raw: '{not valid json', entries: [], dangling: [], corrupt: true },
  // Two NON-RESOLVING variants of one id in a single list. Both are dangling and
  // they are two entries, not one: the SQL's DISTINCT ran on the connection
  // collation, which folds case AND pads, and answered 1 for every shape below
  // while the rule said 2. No case here reached that, which is why the
  // differential did not catch it.
  { name: 'two respellings of the site', raw: [SITE.toUpperCase(), `${SITE} `], entries: [SITE.toUpperCase(), `${SITE} `], dangling: [SITE.toUpperCase(), `${SITE} `] },
  { name: 'the site and two respellings of it', raw: [SITE, SITE.toUpperCase(), `${SITE} `], entries: [SITE, SITE.toUpperCase(), `${SITE} `], dangling: [SITE.toUpperCase(), `${SITE} `] },
  { name: 'two cases of one absent id', raw: [OTHER, OTHER.toUpperCase()], entries: [OTHER, OTHER.toUpperCase()], dangling: [OTHER, OTHER.toUpperCase()] },
  { name: 'an absent id padded and not', raw: [OTHER, `${OTHER} `], entries: [OTHER, `${OTHER} `], dangling: [OTHER, `${OTHER} `] },
  // An element no reader can take for an identifier. It restricts — to nothing —
  // and is reported; it must NOT read as "no restriction at all".
  { name: 'a nested list element', raw: [[SITE]], entries: [`[${JSON.stringify(SITE)}]`], dangling: [`[${JSON.stringify(SITE)}]`] },
  { name: 'an object element', raw: [{}], entries: ['{}'], dangling: ['{}'] },
  { name: 'the same object twice', raw: [{}, {}], entries: ['{}'], dangling: ['{}'] },
  { name: 'two different object elements', raw: [{ a: 1 }, { b: 2 }], entries: ['{"a":1}', '{"b":2}'], dangling: ['{"a":1}', '{"b":2}'] },
  { name: 'an unreadable element beside a resolvable one', raw: [SITE, {}], entries: [SITE, '{}'], dangling: ['{}'] },
  // Scalars that are not strings: one entry, because both render the same way on
  // every layer.
  { name: 'a number and its string form', raw: [12345, '12345'], entries: ['12345'], dangling: ['12345'] },
  { name: 'a boolean and its string form', raw: [true, 'true'], entries: ['true'], dangling: ['true'] },
  { name: 'the raw JSON string form', raw: JSON.stringify([OTHER]), entries: [OTHER], dangling: [OTHER] },
]);

module.exports = {
  dcRefEntries,
  isDcRefsCorrupt,
  dcRefsUnrestricted,
  danglingDcRefs,
  canonicalizeDcRefs,
  DC_REFS_PARITY_CASES,
  DC_REFS_PARITY_SITE_ID: SITE,
};
