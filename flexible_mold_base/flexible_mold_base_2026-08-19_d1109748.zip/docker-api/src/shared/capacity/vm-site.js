/**
 * capacity/vm-site.js — the ONE answer to "which data centre is this VM in".
 *
 * There were four. The rules engine, the site rollups and the placement canvas
 * each asked the hypervisor; the scenario health check read `cap_vms.site_id`
 * and validated it as though it were the answer. Nothing kept the column in
 * step with the placement, so a VM moved to a host in another DC left the
 * canvas and the health panel saying different things about the same row.
 *
 * THE RULE. A placed VM is in its HOST's data centre — the host is the thing
 * that physically stands somewhere, and `cap_vms.site_id` is a cache of that
 * fact. An unplaced VM has no host to ask, and the column then carries the
 * operator's INTENDED site: it is the only statement of where the VM is meant
 * to go, which is why unplacing must never blank it.
 *
 * `source` is part of the answer, not decoration. Two consumers need to know
 * WHY they got a site id: the rules engine counts OCCUPANCY (an intended site
 * is not an occupied one) and the health check compares the cache against the
 * host (only meaningful when there is a host to compare with). Returning the
 * provenance keeps one function answering one question instead of growing a
 * second function per caller — which is the shape this module exists to end.
 *
 * ISOMORPHIC OBLIGATION: mirrored at `src/fmb/capacity/lib/vm-site.ts` because
 * the src/** Vite bundle may not import docker-api/**. This file is the
 * reference; `VM_SITE_PARITY_CASES` below is the shared case set both copies
 * are driven over by `src/fmb/capacity/lib/__tests__/vm-site.parity.test.ts`.
 */
'use strict';

/**
 * @typedef {'host'|'intended'|'none'} VmSiteSource
 * @typedef {{ siteId: unknown, source: VmSiteSource }} VmSite
 */

const NO_SITE = Object.freeze({ siteId: null, source: 'none' });

/** A hypervisor's data centre is its own column, and that is the whole rule. */
function resolveHypervisorSiteId(hypervisor) {
  if (!hypervisor) return null;
  return hypervisor.site_id != null ? hypervisor.site_id : null;
}

/** A VM is placed when it names a host. */
function isVmPlaced(vm) {
  return !!vm && vm.hypervisor_id != null;
}

/**
 * Which data centre is this VM in.
 *
 * @param {object|null|undefined} vm a `cap_vms` row (or a row-shaped object)
 * @param {(hypervisorId: unknown) => unknown} hypervisorSiteOf resolves a host
 *   id to its site id — the caller owns the index because each consumer already
 *   keys its hypervisors its own way
 * @returns {VmSite}
 */
function resolveVmSite(vm, hypervisorSiteOf) {
  if (!vm) return NO_SITE;
  if (!isVmPlaced(vm)) {
    // No host to ask: the column is the intended site, or there is no answer.
    return vm.site_id != null ? { siteId: vm.site_id, source: 'intended' } : NO_SITE;
  }
  const hostSite = typeof hypervisorSiteOf === 'function' ? hypervisorSiteOf(vm.hypervisor_id) : null;
  // A host that resolves to nothing — a dangling `hypervisor_id`, or a partial
  // state that does not carry it — is NOT a reason to fall back to the cache.
  // The VM claims to stand somewhere and the estate cannot say where, and
  // answering with a stale cache would hide exactly that.
  return hostSite != null ? { siteId: hostSite, source: 'host' } : NO_SITE;
}

/** The answer alone, for the callers that do not branch on provenance. */
function resolveVmSiteId(vm, hypervisorSiteOf) {
  return resolveVmSite(vm, hypervisorSiteOf).siteId;
}

/**
 * Two id spellings naming one stored row.
 *
 * These are `CHAR(36)` columns under a case-folding collation, so the DATABASE
 * considers two spellings of one uuid the same value and `<>` in SQL answers
 * accordingly. A `!==` here would report a contradiction the engine does not
 * see — and this predicate decides whether the operator is shown a broken
 * scenario. The fold is exact for this domain rather than approximately right:
 * the bytes are ASCII hex and hyphens, on which `toLowerCase()` IS that
 * collation.
 */
function sameSiteId(a, b) {
  if (a == null || b == null) return a == null && b == null;
  return String(a).toLowerCase() === String(b).toLowerCase();
}

/**
 * Does this VM's cached `site_id` contradict the host it stands on?
 *
 * Only a PLACED VM whose host resolves can contradict anything. A cache that is
 * simply unset is not a contradiction (nothing was claimed), and a dangling
 * `hypervisor_id` is the dangling-reference finding's business, not this one.
 */
function vmSiteCacheDisagrees(vm, hypervisorSiteOf) {
  const site = resolveVmSite(vm, hypervisorSiteOf);
  if (site.source !== 'host') return false;
  if (vm.site_id == null) return false;
  return !sameSiteId(vm.site_id, site.siteId);
}

/**
 * The canonical case set, published beside the reference implementation so the
 * two halves of the codebase cannot each quietly test a different one. Each
 * case is `{ name, vm, hypervisors, expect: { siteId, source, disagrees } }`;
 * `hypervisors` is a plain list the parity test turns into whatever index the
 * copy under test wants.
 */
const VM_SITE_PARITY_CASES = Object.freeze([
  {
    name: 'placed on a host that stands in a data centre',
    vm: { id: 'v1', hypervisor_id: 'h1', site_id: 'site-a' },
    hypervisors: [{ id: 'h1', site_id: 'site-a' }],
    expect: { siteId: 'site-a', source: 'host', disagrees: false },
  },
  {
    name: 'placed, with a cache naming another data centre',
    vm: { id: 'v1', hypervisor_id: 'h1', site_id: 'site-b' },
    hypervisors: [{ id: 'h1', site_id: 'site-a' }],
    expect: { siteId: 'site-a', source: 'host', disagrees: true },
  },
  {
    name: 'placed, with the cache spelled in another case',
    vm: { id: 'v1', hypervisor_id: 'h1', site_id: 'SITE-A' },
    hypervisors: [{ id: 'h1', site_id: 'site-a' }],
    expect: { siteId: 'site-a', source: 'host', disagrees: false },
  },
  {
    name: 'placed, with no cache written yet',
    vm: { id: 'v1', hypervisor_id: 'h1', site_id: null },
    hypervisors: [{ id: 'h1', site_id: 'site-a' }],
    expect: { siteId: 'site-a', source: 'host', disagrees: false },
  },
  {
    name: 'placed on a host nothing knows about',
    vm: { id: 'v1', hypervisor_id: 'ghost', site_id: 'site-b' },
    hypervisors: [{ id: 'h1', site_id: 'site-a' }],
    expect: { siteId: null, source: 'none', disagrees: false },
  },
  {
    name: 'placed on a host with no data centre of its own',
    vm: { id: 'v1', hypervisor_id: 'h1', site_id: 'site-b' },
    hypervisors: [{ id: 'h1', site_id: null }],
    expect: { siteId: null, source: 'none', disagrees: false },
  },
  {
    name: 'unplaced, pinned to an intended data centre',
    vm: { id: 'v1', hypervisor_id: null, site_id: 'site-b' },
    hypervisors: [{ id: 'h1', site_id: 'site-a' }],
    expect: { siteId: 'site-b', source: 'intended', disagrees: false },
  },
  {
    name: 'unplaced, with no intended data centre',
    vm: { id: 'v1', hypervisor_id: null, site_id: null },
    hypervisors: [{ id: 'h1', site_id: 'site-a' }],
    expect: { siteId: null, source: 'none', disagrees: false },
  },
  {
    name: 'a row that carries neither column',
    vm: { id: 'v1' },
    hypervisors: [{ id: 'h1', site_id: 'site-a' }],
    expect: { siteId: null, source: 'none', disagrees: false },
  },
  {
    name: 'non-string ids',
    vm: { id: 1, hypervisor_id: 7, site_id: 9 },
    hypervisors: [{ id: 7, site_id: 9 }],
    expect: { siteId: 9, source: 'host', disagrees: false },
  },
  // NO ROW AT ALL — the one input on which the two copies' SOURCE TEXT actually
  // differs. The mirror's cache check reads `!vm || vm.site_id == null`; this
  // one reads `vm.site_id == null` and would throw on a null row if it ever got
  // there. It cannot: `resolveVmSite` answers 'none' first and the source test
  // above returns before the row is touched. Both copies therefore agree, which
  // is precisely why the case has to be in the published set — an agreement
  // nothing drives is an agreement nobody will notice breaking, and the
  // difference is one refactor away from being reachable.
  {
    name: 'no row at all (null)',
    vm: null,
    hypervisors: [{ id: 'h1', site_id: 'site-a' }],
    expect: { siteId: null, source: 'none', disagrees: false },
  },
  {
    name: 'no row at all (undefined)',
    vm: undefined,
    hypervisors: [{ id: 'h1', site_id: 'site-a' }],
    expect: { siteId: null, source: 'none', disagrees: false },
  },
]);

module.exports = {
  resolveVmSite,
  resolveVmSiteId,
  resolveHypervisorSiteId,
  isVmPlaced,
  sameSiteId,
  vmSiteCacheDisagrees,
  VM_SITE_PARITY_CASES,
};
