/**
 * Shared password strength validator for infra-side auth and edge-side user
 * management. Returns an error message string or null if valid.
 *
 * Bcrypt has a 72-byte max input length — warn/reject longer passwords.
 */
function validatePassword(password) {
  if (!password || typeof password !== 'string') return 'Password is required';
  if (password.length < 8) return 'Password must be at least 8 characters';
  if (Buffer.byteLength(password, 'utf-8') > 72) return 'Password exceeds maximum length (72 bytes)';
  return null;
}

module.exports = { validatePassword };
