/**
 * config-schema.js — Zod-based env var validation for docker-api.
 *
 * Validates process.env at startup so misconfigured deployments fail with
 * a human-readable error instead of crashing mid-request.
 *
 * Three schemas:
 *   - sharedSchema: vars shared by infra + edge roles
 *   - infraSchema: vars used only by infra (frontend-facing, port 3200)
 *   - edgeSchema: vars used only by edge (DB-facing, port 3201)
 *
 * Escape hatch: set SKIP_CONFIG_VALIDATION=1 to bypass validation.
 * This is intended for local dev only — never set in production.
 *
 * DB_RW_PASSWORD_ENCRYPTED: if set, the encrypted value is decrypted at
 * validation time using SETTINGS_ENCRYPTION_KEY (same AES-256-GCM as
 * settings-crypto.js). The decrypted value replaces DB_RW_PASSWORD in
 * process.env so downstream code reads it transparently.
 *
 * DB_RO_PASSWORD_ENCRYPTED: read-endpoint parity with DB_RW_PASSWORD_ENCRYPTED.
 * Decrypted value replaces DB_RO_PASSWORD.
 *
 * Legacy DB_HOST / DB_PORT / DB_USER / DB_PASSWORD and DB_PASSWORD_ENCRYPTED
 * have been removed. Operators must use DB_RW_* names; schema-validation
 * rejects legacy-only deployments at boot.
 */

const { z } = require('zod');

// ── Helpers ──────────────────────────────────────────────────────────

const optStr = z.string().optional();

/**
 * Zod refinement: absolute http(s) URL, or empty/undefined.
 *
 * Used to enforce URL shape on fields like FRONTEND_URL / BASE_URL / API_BASE
 * where a typo (missing scheme, trailing slash artefact, reversed `//`) would
 * otherwise propagate silently into CORS headers or /config.js payloads and
 * surface as a confusing downstream browser-level error instead of a
 * human-readable startup failure.
 *
 * Scope: shape-only. These values are operator-controlled env vars (trusted
 * source), not user input. SSRF-style blocklisting (loopback, link-local,
 * metadata endpoints) is intentionally NOT enforced here — `http://localhost:*`
 * is a documented legitimate value for DevContainer / local dev flows
 * (see docker-api/.env.example). Scheme and host-presence are the only
 * invariants asserted.
 *
 * Rejects: missing scheme, `javascript:`, `file://`, `data:`, protocol-relative
 * (`//host`), triple-slash (`http:///path` — empty host).
 * Accepts: `http://` and `https://` (case-insensitive) with at least one
 * non-slash character after `://`.
 *
 * @param {z.ZodOptional<z.ZodString>} base
 * @param {string} fieldName
 */
const absHttpUrlRefine = (base, fieldName) =>
  base.refine(
    (v) => {
      if (v === undefined || v === '') return true;
      if (!/^https?:\/\/[^\s/][^\s]*$/i.test(v)) return false;
      // SECURITY: reject userinfo in URL. A `https://user:pass@host` that
      // passes the regex would survive into process.env.<field> and could
      // leak into logs or the /config.js window global. Internal service
      // URLs never need userinfo; failing fast at validation time is cheap
      // insurance.
      try {
        if (new URL(v).username !== '') return false;
      } catch {
        return false;
      }
      return true;
    },
    {
      message: `${fieldName} must be an absolute http(s) URL without userinfo, or empty.`,
    },
  );
const optNum = (fallback) =>
  z
    .string()
    .optional()
    .transform((v) => (v ? Number(v) : fallback))
    .pipe(z.number().int().nonnegative());
// Strictly-positive variant for values where 0 is invalid — e.g. a rate-limit
// windowMs (express-rate-limit v8 throws ERR_ERL_WINDOW_MS on windowMs < 1).
const optPosNum = (fallback) =>
  z
    .string()
    .optional()
    .transform((v) => (v ? Number(v) : fallback))
    .pipe(z.number().int().positive());
const optBool = (fallback) =>
  z
    .string()
    .optional()
    .transform((v) => {
      if (v === undefined || v === '') return fallback;
      return v === '1' || v === 'true';
    });
/** Case-insensitive enum: lowercases before validating. */
const ciEnum = (values) =>
  z
    .string()
    .transform((v) => v.toLowerCase())
    .pipe(z.enum(values));

// ── Shared schema (both roles) ──────────────────────────────────────

const sharedSchema = z.object({
  API_ROLE: ciEnum(['infra', 'edge', 'frontend'])
    .optional()
    .default('infra')
    .describe('Process role: infra (API, 3200), edge (DB-facing, 3201), frontend (static + /config.js, 3000)'),
  NODE_ENV: ciEnum(['production', 'development', 'test'])
    .optional()
    .default('development')
    .describe('Runtime environment — controls log level and CORS'),
  JWT_SECRET: optStr
    .refine((v) => v === undefined || v === '' || v.length >= 32, {
      message:
        'JWT_SECRET must be at least 32 characters when set (generate with: openssl rand -base64 48)',
    })
    .describe(
      'JWT signing key for local auth mode (32+ chars). Required when auth mode is local.',
    ),
  AUTH_MODE_OVERRIDE: ciEnum(['local', 'keycloak'])
    .optional()
    .describe('Force auth mode, bypassing auto-detection'),
  KEYCLOAK_ISSUER_BASE_URL: optStr.describe(
    'Keycloak OIDC discovery URL. Triggers keycloak auto-detection if set and reachable.',
  ),
  SETTINGS_ENCRYPTION_KEY: optStr.describe(
    'AES-256-GCM key for encrypting sensitive system_settings and DB_RW_PASSWORD_ENCRYPTED / DB_RO_PASSWORD_ENCRYPTED',
  ),
  LOGGER_CAPTURE_BUDGET: optNum(500).describe(
    'Rate limit for error stack-trace captures/sec (max 100000)',
  ),
  LOG_LEVEL: ciEnum(['trace', 'debug', 'info', 'warn', 'error', 'fatal', 'silent'])
    .optional()
    .describe('Pino log level override (default: info in production, debug otherwise)'),

  // Database — dual-read pool, DB_RW_* / DB_RO_* canonical names.
  // Legacy DB_HOST / DB_PORT / DB_USER / DB_PASSWORD / DB_PASSWORD_ENCRYPTED
  // have been removed; schema-validation rejects those names at boot.
  DB_RW_HOST: optStr.describe('Writer hostname (required)'),
  DB_RW_PORT: optNum(3306).describe('Writer port'),
  DB_RW_USER: z.string().optional().default('root').describe('Writer user (default "root"; required when DB_RW_HOST is set)'),
  DB_RW_PASSWORD: optStr.describe('Writer password (plaintext). Prefer DB_RW_PASSWORD_ENCRYPTED (v3.2.44 canonical).'),
  DB_RO_HOST: optStr.describe('Read-endpoint hostname (optional; must be set together with DB_RO_PORT)'),
  DB_RO_PORT: optStr.describe('Read-endpoint port (optional; must be set together with DB_RO_HOST)'),
  DB_RO_USER: optStr.describe('Read-endpoint user (optional; falls back to DB_RW_USER)'),
  DB_RO_PASSWORD: optStr.describe('Read-endpoint password (plaintext; optional; falls back to DB_RW_PASSWORD). Prefer DB_RO_PASSWORD_ENCRYPTED.'),
  DB_RW_PASSWORD_ENCRYPTED: optStr.describe(
    'AES-256-GCM encrypted DB writer password (enc:v1:iv:tag:ct). Decrypted at boot using SETTINGS_ENCRYPTION_KEY. Canonical name (v3.2.44+).',
  ),
  DB_RO_PASSWORD_ENCRYPTED: optStr.describe(
    'AES-256-GCM encrypted DB read-endpoint password (enc:v1:iv:tag:ct). ' +
      'Decrypted at boot using SETTINGS_ENCRYPTION_KEY; parity with DB_RW_PASSWORD_ENCRYPTED for the RO pool (v3.2.42).',
  ),
  DB_NAME: optStr.describe('Database name'),
  DB_TABLE_PREFIX: optStr.describe('Required table name prefix'),

  // Setup / seed
  SEED_SQL_PATH: optStr.describe('Path to SQL seed file for setup endpoint'),
  // NOTE: boot-banner.js also reads APP_NAME and throws ERROR/CAUSE/FIX on
  // absence (enforced at listen time, not schema time, so the Zod check stays
  // optional for test-harness backward compatibility). K8s deployments receive
  // it from components/shared/configmap-shared.yaml. Local dev (docker-compose /
  // npm run dev) must set it in docker-api/.env per the .env.example.
  APP_NAME: optStr.describe('Application name for boot-banner + system_settings init (required at listen time)'),
});

// ── Infra-only schema ────────────────────────────────────────────────

const infraSchemaShape = sharedSchema.extend({
  PORT: optNum(3200).describe('HTTP server port'),
  SERVE_STATIC: optBool(false).describe('Serve frontend dist from /dist'),
  TRUST_PROXY: optNum(1).describe('Express trust-proxy setting'),
  CORS_ORIGINS: optStr.describe('Allowed CORS origins (CSV or "true")'),
  DEBUG_API: optBool(false).describe('Include debug info in API responses'),

  // Rate limiting
  RATE_LIMIT_AUTH_WINDOW_MS: optNum(900000).describe('Login rate-limit window (ms)'),
  RATE_LIMIT_AUTH_MAX: optNum(20).describe('Max login attempts per window'),
  RATE_LIMIT_PASSWORD_WINDOW_MS: optNum(900000).describe('Password rate-limit window (ms)'),
  RATE_LIMIT_PASSWORD_MAX: optNum(5).describe('Max password attempts per window'),
  RATE_LIMIT_DIAG_WINDOW_MS: optNum(60000).describe('Diagnostics rate-limit window (ms)'),
  RATE_LIMIT_DIAG_MAX: optNum(30).describe('Max diagnostic requests per window'),
  RATE_LIMIT_GENERAL_WINDOW_MS: optNum(60000).describe('General rate-limit window (ms)'),
  RATE_LIMIT_GENERAL_MAX: optNum(200).describe('Max general API requests per window'),
  RATE_LIMIT_SETUP_WINDOW_MS: optPosNum(300000).describe('Setup/seed rate-limit window (ms; must be > 0)'),
  RATE_LIMIT_SETUP_MAX: optNum(10).describe('Max /api/setup/* requests per window (0 blocks all setup traffic — fail-closed)'),
  DISABLE_RATE_LIMIT: optBool(false).describe('Bypass all rate limiters (DEV ONLY)'),

  // S2S + edge
  EDGE_API_URL: z
    .string()
    .optional()
    .default('http://api-edge:3201')
    .describe('URL of the API-edge service'),
  S2S_API_KEY: z
    .string()
    .min(1)
    .describe('Shared secret between infra and edge (REQUIRED)'),

  // Keycloak OIDC
  KEYCLOAK_CLIENT_ID: optStr.describe('Keycloak OIDC client ID'),
  KEYCLOAK_CLIENT_SECRET: optStr.describe('Keycloak OIDC client secret'),
  KEYCLOAK_SECRET: optStr.describe('Session encryption secret for Keycloak mode'),
  KEYCLOAK_CA_CERT_PATH: optStr.describe('CA cert PEM path for HTTPS Keycloak'),
  KEYCLOAK_DEGRADE_POLICY: ciEnum(['auto', 'manual'])
    .optional()
    .default('manual')
    .describe('Auto-degradation policy if Keycloak unreachable'),
  BASE_URL: absHttpUrlRefine(optStr, 'BASE_URL').describe(
    'Express self-URL for session/OIDC callbacks (absolute http(s) or empty)',
  ),
  FRONTEND_URL: absHttpUrlRefine(optStr, 'FRONTEND_URL').describe(
    'Frontend URL for post-logout redirect + CORS origin (absolute http(s) or empty)',
  ),
  KEYCLOAK_CLAIM_USERNAME: z
    .string()
    .optional()
    .default('preferred_username')
    .describe('JWT claim → username'),
  KEYCLOAK_CLAIM_DEPTID: z
    .string()
    .optional()
    .default('deptid')
    .describe('JWT claim → department ID'),
  KEYCLOAK_CLAIM_DESCRIPTION: z
    .string()
    .optional()
    .default('description')
    .describe('JWT claim → user description'),
  // NOTE: CSV of emails auto-promoted to admin on JIT provisioning or first-time
  // Keycloak binding. Without this, the first SSO user becomes admin and every
  // subsequent user is stuck as 'user' until an existing admin grants them via
  // UI / scripts/promote-admin.sh.
  KEYCLOAK_ADMIN_EMAILS: optStr.describe(
    'CSV of email addresses auto-promoted to admin role on Keycloak JIT provisioning',
  ),
});

// INVARIANT: when Keycloak is configured (issuer URL set), BASE_URL must also
// be set to a real URL. Otherwise keycloak-oidc.js silently falls back to
// `http://localhost:${PORT}` for the OIDC callback, producing redirects that
// point at the pod loopback instead of the zone ingress.
//
// Why a refine instead of `BASE_URL: z.string().min(1)` unconditionally:
// local-mode (no Keycloak) deploys legitimately leave BASE_URL empty —
// the platform UI runs same-origin and OIDC isn't mounted. Keying off
// KEYCLOAK_ISSUER_BASE_URL keeps both modes valid.
// INVARIANT: DB_RO_HOST and DB_RO_PORT are both-or-neither. Applied to every
// role schema so a misconfigured read endpoint fails at boot rather than
// silently discarding one half of the pair inside db.js. Mirrors the
// assertReadConfig() runtime check in docker-api/src/edge/db.js.
const refineReadEndpoint = (schema) =>
  schema.refine(
    (data) => {
      const hasHost = typeof data.DB_RO_HOST === 'string' && data.DB_RO_HOST.length > 0;
      const hasPort = data.DB_RO_PORT != null && String(data.DB_RO_PORT).length > 0;
      return hasHost === hasPort;
    },
    {
      message:
        'DB_RO_HOST and DB_RO_PORT must be set together (both-or-neither). ' +
        'Unset both to route reads through the writer pool, or set both to ' +
        'use a dedicated read endpoint.',
      path: ['DB_RO_HOST'],
    },
  );

// NOTE: env DB configs must carry an explicit table prefix. Runtime
// buildEnvConfig() also hard-fails, but validation catches a misconfigured
// deployment before the app can degrade into setup-required mode.
const refineRequiredTablePrefix = (schema) =>
  schema.superRefine((data, ctx) => {
    if (data.DB_RW_HOST && !data.DB_TABLE_PREFIX) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ['DB_TABLE_PREFIX'],
        message:
          'DB_TABLE_PREFIX is required when DB_RW_HOST is set. ' +
          'Set DB_TABLE_PREFIX explicitly; silent fallback to DB_NAME_ was removed in v3.2.61.',
      });
    }
  });

// INVARIANT: hard-fail when any of the removed legacy DB env names are still
// present in process.env. Zod silently strips unknown keys, so without this
// guard an operator who leaves the old names in Vault/ConfigMap only sees a
// downstream MariaDB auth failure instead of a clear boot-time configuration
// error.
// `superRefine` peeks at process.env directly because the removed names were
// never parsed into `data` — there is nothing to refine on the parsed object.
const REMOVED_LEGACY_DB_ENV = [
  { legacy: 'DB_HOST', canonical: 'DB_RW_HOST' },
  { legacy: 'DB_PORT', canonical: 'DB_RW_PORT' },
  { legacy: 'DB_USER', canonical: 'DB_RW_USER' },
  { legacy: 'DB_PASSWORD', canonical: 'DB_RW_PASSWORD' },
  { legacy: 'DB_PASSWORD_ENCRYPTED', canonical: 'DB_RW_PASSWORD_ENCRYPTED' },
];
const refineRemovedLegacyEnv = (schema) =>
  schema.superRefine((_, ctx) => {
    for (const { legacy, canonical } of REMOVED_LEGACY_DB_ENV) {
      const v = process.env[legacy];
      if (v !== undefined && v !== '') {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          path: [legacy],
          message:
            `${legacy} was removed in v3.2.47. Use ${canonical} instead. ` +
            'See CHANGELOG v3.2.47 for the migration note.',
        });
      }
    }
  });

const infraSchema = refineRemovedLegacyEnv(
  refineRequiredTablePrefix(
    refineReadEndpoint(
      infraSchemaShape.refine(
        (data) => !data.KEYCLOAK_ISSUER_BASE_URL || !!data.BASE_URL,
        {
          message:
            'BASE_URL must be set when KEYCLOAK_ISSUER_BASE_URL is configured. ' +
            'Otherwise OIDC callbacks silently fall back to http://localhost:${PORT}, ' +
            'breaking auth from any non-loopback origin. Set BASE_URL to your zone\'s ' +
            'API ingress URL (see overlays/<zone>/config.env).',
          path: ['BASE_URL'],
        },
      ),
    ),
  ),
);

// ── Edge-only schema ─────────────────────────────────────────────────

const edgeSchema = refineRemovedLegacyEnv(
  refineRequiredTablePrefix(
    refineReadEndpoint(sharedSchema.extend({
      PORT: optNum(3201).describe('HTTP server port'),
      S2S_API_KEY: z
        .string()
        .min(1)
        .describe('Shared secret between infra and edge (REQUIRED)'),
      DEBUG_DTO_MAPPER: optBool(false).describe('Enable DTO mapper debug output'),
      DTO_MAPPER_ENABLED: optBool(true).describe('Enable/disable DTO mapping layer'),
    })),
  ),
);

// ── Frontend-only schema ─────────────────────────────────────────────
//
// The frontend role serves static assets on port 3000 plus a GET /config.js
// endpoint that injects `window.__API_BASE__` so the SPA can discover the
// API origin at runtime (k8s two-VirtualService deployment). It does NOT
// forward to edge and it does NOT require S2S_API_KEY, DB creds, OIDC
// client secret, or any platform middleware — only the static dist.

// NOTE: `API_BASE` env is rejected outright; `API_BASE_ALLOWLIST` replaces it.
// See parse-allowlist.js + shared ConfigMap + ENV_PLACEMENT.md. A dedicated
// superRefine emits a precise ERROR/CAUSE/FIX message so operators see exactly
// what to change.
// NOTE: frontend role is static-only (index-frontend.js) and never opens a DB
// pool. The shared ConfigMap carries DB_RW_HOST for edge/infra, which would
// otherwise trigger refineRequiredTablePrefix and crash-loop frontend pods that
// have no reason to envFrom fmb-secrets.
const frontendSchema = refineRemovedLegacyEnv(
    sharedSchema.extend({
      PORT: optNum(3000).describe('HTTP server port'),
      // NOTE: `API_BASE` is retained in the schema ONLY so superRefine can see
      // it and reject with an actionable message. The field itself has no
      // semantic — any non-empty value fails validation. Operators use
      // API_BASE_ALLOWLIST instead.
      API_BASE: z
        .string()
        .optional()
        .describe(
          'REMOVED in v3.2.51 — any non-empty value is rejected at validation ' +
            'time. Use API_BASE_ALLOWLIST (multi-line env) instead.',
        ),
      API_BASE_ALLOWLIST: z
        .string()
        .optional()
        .describe(
          'Multi-line env: `host = url` per line + optional `defaultApiBase = <url>`. ' +
            'Replaces the single-value `API_BASE` env retired in v3.2.51.',
        ),
      TRUST_PROXY: optNum(1).describe('Express trust-proxy setting'),
    }).superRefine((env, ctx) => {
      if (env.API_BASE !== undefined && env.API_BASE !== '') {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          path: ['API_BASE'],
          message:
            "API_BASE env is removed in v3.2.51; use API_BASE_ALLOWLIST instead. " +
            "See infrastructure/docs/ENV_PLACEMENT.md + CHANGELOG v3.2.50 for the " +
            "migration path. v3.2.50 accepted it with a deprecation warning; " +
            "v3.2.51 rejects it outright at config-validation time.",
        });
      }
    }),
);

// ── Validation + DB password decryption ──────────────────────────────

/**
 * Validate process.env against the role-appropriate schema.
 * If DB_RW_PASSWORD_ENCRYPTED is set, decrypt it and inject into
 * process.env.DB_RW_PASSWORD. DB_RO_PASSWORD_ENCRYPTED → DB_RO_PASSWORD
 * (read-endpoint parity). The legacy DB_PASSWORD_ENCRYPTED fallback has been
 * removed; use DB_RW_PASSWORD_ENCRYPTED.
 *
 * @param {'infra'|'edge'|'frontend'} role
 * @returns {{ ok: boolean, config?: object, error?: string }}
 */
function validateConfig(role) {
  if (process.env.SKIP_CONFIG_VALIDATION === '1') {
    if (process.env.NODE_ENV === 'production') {
      return {
        ok: false,
        error: 'SKIP_CONFIG_VALIDATION=1 is not allowed in production.',
      };
    }
    process.stderr.write('[WARN] Config validation is SKIPPED. Do not use in production.\n');
    return { ok: true, config: {}, skipped: true };
  }

  const schema =
    role === 'edge' ? edgeSchema : role === 'frontend' ? frontendSchema : infraSchema;

  const result = schema.safeParse(process.env);
  if (!result.success) {
    const issues = result.error.issues
      .map((i) => `  - ${i.path.join('.')}: ${i.message}`)
      .join('\n');
    return {
      ok: false,
      error: [
        '╔══════════════════════════════════════════════════╗',
        '║  CONFIG VALIDATION FAILED                       ║',
        '╚══════════════════════════════════════════════════╝',
        '',
        `Role: ${role}`,
        '',
        'Issues:',
        issues,
        '',
        'Fix: set the missing/invalid env vars listed above.',
        'Escape hatch: set SKIP_CONFIG_VALIDATION=1 (dev only).',
        '',
      ].join('\n'),
    };
  }

  // Decrypt DB_*_PASSWORD_ENCRYPTED env pairs (canonical RW + RO names only;
  // the legacy DB_PASSWORD_ENCRYPTED fallback has been removed).
  const encryptedPairs = [
    { encVar: 'DB_RW_PASSWORD_ENCRYPTED', plainVar: 'DB_RW_PASSWORD', label: 'DB writer password' },
    { encVar: 'DB_RO_PASSWORD_ENCRYPTED', plainVar: 'DB_RO_PASSWORD', label: 'DB read-endpoint password' },
  ];
  for (const { encVar, plainVar, label } of encryptedPairs) {
    const encValue = process.env[encVar];
    if (!encValue) continue;
    try {
      const { decrypt } = require('./lib/settings-crypto');
      const decrypted = decrypt(encValue);
      if (decrypted === encValue) {
        // decrypt returned the same value — either not encrypted, no key,
        // or malformed ciphertext (wrong colon segment count — settings-crypto
        // logs a warn and returns the raw string in that path).
        if (encValue.startsWith('enc:v1:')) {
          if (!process.env.SETTINGS_ENCRYPTION_KEY) {
            return {
              ok: false,
              error: [
                `${encVar} is set but SETTINGS_ENCRYPTION_KEY is missing.`,
                `Cannot decrypt ${label} without the encryption key.`,
              ].join('\n'),
            };
          }
          // INVARIANT: key is present but decrypt() fell through → value is
          // malformed. Without this guard the raw `enc:v1:...` literal would
          // be injected as the DB password and fail at pool-build time with a
          // cryptic mariadb auth error.
          return {
            ok: false,
            error: [
              `${encVar} looks encrypted (enc:v1: prefix) but could not be parsed.`,
              `Regenerate the value with: SETTINGS_ENCRYPTION_KEY=<key> node scripts/encrypt-env-value.js <plaintext>`,
            ].join('\n'),
          };
        }
      }
      process.env[plainVar] = decrypted;
    } catch {
      return {
        ok: false,
        error: `Failed to decrypt ${encVar}. Check that SETTINGS_ENCRYPTION_KEY matches the key used to encrypt.`,
      };
    }
  }

  return { ok: true, config: result.data };
}

module.exports = {
  validateConfig,
  sharedSchema,
  infraSchema,
  edgeSchema,
  frontendSchema,
};
