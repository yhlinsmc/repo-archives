/**
 * config.js — Centralized environment validation.
 *
 * Import this module early (in index.js) to ensure the server
 * fails fast at startup if required secrets are missing.
 *
 * Auth mode resolution chain:
 *   1. AUTH_MODE_OVERRIDE env var (emergency rollback without DB access)
 *   2. system_settings table key 'auth_mode' (set by Setup Wizard)
 *   3. KEYCLOAK_ISSUER_BASE_URL env var exists → probe → 'keycloak' or 'local'
 *   4. Default → 'local'
 */
const { logger: rootLogger } = require('./lib/logger');
const { TABLES } = require('./constants');

const logger = rootLogger.child({ module: 'config' });

// ── Module-level resolved auth mode state ────────────────────────────────────
let _resolvedAuthMode = 'local';
let _authModeSource = 'default'; // 'override' | 'system_settings' | 'auto_detect' | 'default'
let _modeLock = null; // Promise-based lock for serialized mode changes

/**
 * Resolve auth_mode synchronously. Returns the current cached value.
 * Call detectAuthMode() once at startup to populate this.
 *
 * @returns {'keycloak' | 'local'}
 */
function resolveAuthMode() {
  return _resolvedAuthMode;
}

/** Get the source of the current auth mode decision */
function getAuthModeSource() {
  return _authModeSource;
}

/**
 * Serialized auth mode setter — all mode changes go through this function.
 * Uses a promise-based lock to prevent race conditions between concurrent
 * writers (startup detect, admin API, health probe).
 *
 * @param {'keycloak' | 'local'} mode
 * @param {string} source - 'override' | 'system_settings' | 'auto_detect' | 'default' | 'admin_api' | 'degradation'
 */
async function setResolvedAuthMode(mode, source) {
  // Wait for any pending mode change to complete
  while (_modeLock) {
    await _modeLock;
  }

  let resolve;
  _modeLock = new Promise(r => { resolve = r; });

  try {
    const prev = _resolvedAuthMode;
    _resolvedAuthMode = mode;
    _authModeSource = source;
    if (prev !== mode) {
      logger.info({ mode, source, prev }, 'auth mode changed');
    }
  } finally {
    _modeLock = null;
    resolve();
  }
}

/**
 * Shared Keycloak OIDC discovery probe for auth-mode and health checks.
 *
 * @param {number} [timeoutMs=5000] - Request timeout in milliseconds
 * @returns {Promise<boolean>} true if Keycloak discovery endpoint is reachable
 */
async function probeKeycloakDiscovery(timeoutMs = 5000) {
  const issuerUrl = process.env.KEYCLOAK_ISSUER_BASE_URL;
  if (!issuerUrl) return false;

  try {
    const discoveryUrl = `${issuerUrl}/.well-known/openid-configuration`;
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), timeoutMs);
    const resp = await fetch(discoveryUrl, { signal: controller.signal });
    clearTimeout(timeout);
    return resp.ok;
  } catch {
    return false;
  }
}

/**
 * Detect auth mode at startup. Full resolution chain:
 *   1. AUTH_MODE_OVERRIDE env var
 *   2. system_settings table (if pool ready)
 *   3. Keycloak OIDC discovery (auto-detect) — result written to DB
 *   4. Default → 'local'
 *
 * @param {object|null} pool - DB pool wrapper (may be null if not configured)
 * @param {function|null} t - Table prefix function
 */
async function detectAuthMode(pool, t) {
  // Priority 1: Emergency override
  const override = process.env.AUTH_MODE_OVERRIDE;
  if (override === 'local' || override === 'keycloak') {
    await setResolvedAuthMode(override, 'override');
    logger.info({ mode: override }, 'AUTH_MODE_OVERRIDE active');
    return;
  }

  // Priority 2: DB system_settings
  if (pool && t) {
    try {
      // INVARIANT: boot-time read uses pool.rw for authoritative
      // initialization. A stale pool.ro read against a lagged replica at
      // boot would persist until manual re-probe, allowing the wrong
      // auth_mode to gate logins. The per-request resolveAuthModeAsync
      // below stays on pool.ro (the cache is the primary enforcement
      // source at runtime).
      const conn = await pool.rw.getConnection();
      try {
        const rows = await conn.query(
          `SELECT \`value\` FROM \`${t(TABLES.SYSTEM_SETTINGS)}\` WHERE \`key\` = ?`,
          ['auth_mode']
        );
        if (rows.length > 0) {
          try {
            const { decrypt } = require('./lib/settings-crypto');
            let raw = rows[0].value;
            if (typeof raw === 'string') raw = decrypt(raw);
            // Handle both JSON-wrapped ("keycloak") and raw string (keycloak) values
            let val = raw;
            if (typeof val === 'string') {
              try { val = JSON.parse(val); } catch { /* raw string, use as-is */ }
            }
            if (val === 'keycloak' || val === 'local') {
              await setResolvedAuthMode(val, 'system_settings');
              logger.info({ mode: val, source: 'system_settings' }, 'auth mode resolved from DB');
              return;
            }
          } catch (parseErr) {
            logger.warn({ err: parseErr }, 'failed to parse auth_mode from system_settings');
          }
        }
      } finally {
        conn.release();
      }
    } catch (err) {
      logger.warn({ err }, 'DB auth_mode lookup failed (falling through to auto-detect)');
    }
  }

  // Priority 3: Auto-detect via Keycloak OIDC discovery
  if (process.env.KEYCLOAK_ISSUER_BASE_URL) {
    const reachable = await probeKeycloakDiscovery();
    const detectedMode = reachable ? 'keycloak' : 'local';
    await setResolvedAuthMode(detectedMode, 'auto_detect');

    if (reachable) {
      logger.info('Keycloak reachable — auth mode set to keycloak');
      // Auto-seed to DB if pool available
      if (pool && t) {
        try {
          const conn = await pool.rw.getConnection();
          try {
            await conn.query(
              `INSERT INTO \`${t(TABLES.SYSTEM_SETTINGS)}\` (\`key\`, value) VALUES (?, ?)
               ON DUPLICATE KEY UPDATE value = ?`,
              ['auth_mode', JSON.stringify('keycloak'), JSON.stringify('keycloak')]
            );
          } finally {
            conn.release();
          }
        } catch (err) {
          logger.warn({ err }, 'auth_mode best-effort DB seed failed — keycloak mode resolved in-memory only');
        }
      }
    } else {
      logger.warn('Keycloak not reachable — defaulting to local mode');
    }
    return;
  }

  // Priority 4: Default
  await setResolvedAuthMode('local', 'default');
  logger.info('no Keycloak env vars — auth mode is local');
}

/**
 * Resolve auth_mode with DB lookup (async).
 * Resolve auth mode fresh after mutable system_settings changes.
 */
async function resolveAuthModeAsync(pool, t) {
  const override = process.env.AUTH_MODE_OVERRIDE;
  if (override === 'local' || override === 'keycloak') return override;

  try {
    const conn = await pool.ro.getConnection();
    try {
      const rows = await conn.query(
        `SELECT \`value\` FROM \`${t(TABLES.SYSTEM_SETTINGS)}\` WHERE \`key\` = ?`,
        ['auth_mode']
      );
      if (rows.length > 0) {
        try {
          const { decrypt } = require('./lib/settings-crypto');
          let raw = rows[0].value;
          if (typeof raw === 'string') raw = decrypt(raw);
          let val = raw;
          if (typeof val === 'string') {
            try { val = JSON.parse(val); } catch { /* raw string, use as-is */ }
          }
          if (val === 'keycloak' || val === 'local') return val;
        } catch (parseErr) {
          logger.warn({ err: parseErr }, 'failed to parse auth_mode from system_settings');
        }
      }
    } finally {
      conn.release();
    }
  } catch (err) {
    logger.warn({ err }, 'DB auth_mode resolution failed (falling through to env)');
  }

  if (process.env.KEYCLOAK_ISSUER_BASE_URL) return 'keycloak';
  return 'local';
}

// ── JWT_SECRET validation ──────────────────────────────────────────────────
// Only required when auth_mode is NOT 'keycloak' (local bcrypt login needs JWT).
//
// SECURITY: jose does NOT enforce a minimum HS256 key length (verified against
// jose v6 — sign+verify succeed with a 1-char secret), unlike RFC 7518's
// recommendation of a key at least as long as the HMAC output. We enforce a
// 32-char floor ourselves so a weak, brute-forceable JWT_SECRET fails fast at
// boot instead of silently signing forgeable local-auth tokens. This mirrors
// the Zod check in config-schema.js (the primary boot gate via index.js); the
// check here is defense-in-depth for any path that loads config.js without
// going through validateConfig (tooling, SKIP_CONFIG_VALIDATION=1 dev runs).
const MIN_JWT_SECRET_LENGTH = 32;
const KNOWN_PLACEHOLDERS = ['change-me', 'change-me-in-production'];

/**
 * Validate JWT_SECRET for the resolved auth mode. Pure — returns a result
 * instead of exiting, so the branches are unit-testable. The module-load
 * caller below turns a failure into logger.fatal + process.exit(1).
 *
 * Messages never include the secret value.
 *
 * @param {string|undefined} secret
 * @param {'local'|'keycloak'} mode
 * @returns {{ ok: boolean, message?: string }}
 */
function validateJwtSecret(secret, mode) {
  if (mode === 'keycloak') {
    // JWT_SECRET is optional in keycloak-only mode (no local bcrypt login).
    return { ok: true };
  }
  if (!secret) {
    return { ok: false, message: 'JWT_SECRET environment variable is required but not set.' };
  }
  if (KNOWN_PLACEHOLDERS.includes(secret.toLowerCase())) {
    return { ok: false, message: 'JWT_SECRET is set to a known placeholder. Use a real secret.' };
  }
  if (secret.length < MIN_JWT_SECRET_LENGTH) {
    return {
      ok: false,
      message: `JWT_SECRET must be at least ${MIN_JWT_SECRET_LENGTH} characters ` +
        '(generate with: openssl rand -base64 48).',
    };
  }
  return { ok: true };
}

const authMode = resolveAuthMode();
const JWT_SECRET = process.env.JWT_SECRET;

const _jwtSecretCheck = validateJwtSecret(JWT_SECRET, authMode);
if (!_jwtSecretCheck.ok) {
  logger.fatal(_jwtSecretCheck.message + ' Exiting.');
  process.exit(1);
} else if (authMode === 'keycloak' && !JWT_SECRET) {
  logger.info('JWT_SECRET not set — OK for keycloak-only mode');
}

module.exports = {
  JWT_SECRET,
  MIN_JWT_SECRET_LENGTH,
  validateJwtSecret,
  resolveAuthMode,
  resolveAuthModeAsync,
  detectAuthMode,
  setResolvedAuthMode,
  probeKeycloakDiscovery,
  getAuthModeSource,
};
