/**
 * Shape validation for a cell-scope document — the JSON shape that narrows a
 * setting to individual cells of a table-type field instead of the whole field.
 *
 * TWO COLUMNS NOW HOLD THIS SHAPE. `variant_overrides.cell_targets` narrows one
 * variant's override; `blueprint_fields.value_scope` narrows the field's own
 * mode in every variant. They are the same document with the same rules, so
 * they are checked by the same function — hence this module living in `shared/`
 * rather than beside the override routes: `shared/field-value-source.js` is the
 * write boundary for the second column and must be able to reach it.
 *
 * Contract: `{ rows?: number[] | null, columns?: string[] | null }`, where rows
 * are 0-based row indices and columns are table-column keys. `null` / absent /
 * `{}` all mean whole-field (today's semantics), so an existing row needs no
 * migration.
 *
 * SECURITY: the write routes build their SET/INSERT column list from the request
 * body, so without this guard an arbitrary client-supplied JSON document would
 * be persisted verbatim into the column and later fed to the resolver. Unknown
 * keys are rejected rather than ignored so a typo (`column` for `columns`)
 * surfaces at write time instead of silently degrading to whole-field scope.
 *
 * Row indices are NOT checked against a real row count on purpose: table rows
 * are added by the end user at fill-in time, so an index that points past the
 * current end is inert, never an error.
 */

// Bounds exist only to keep an unbounded document out of the column; they are
// far above any authorable table (the picker's column list comes from
// table_config, and row indices address rows a human types).
const MAX_TARGET_ROWS = 1000;
const MAX_TARGET_COLUMNS = 200;
const MAX_COLUMN_KEY_LENGTH = 255;

const ALLOWED_KEYS = new Set(['rows', 'columns']);

function invalidRowIndices(rows, label) {
  if (rows == null) return null;
  if (!Array.isArray(rows)) return `${label}.rows must be an array of row indices or null`;
  if (rows.length > MAX_TARGET_ROWS) return `${label}.rows may not exceed ${MAX_TARGET_ROWS} entries`;
  for (const r of rows) {
    if (typeof r !== 'number' || !Number.isSafeInteger(r) || r < 0) {
      return `${label}.rows must contain non-negative integer row indices`;
    }
  }
  return null;
}

function invalidColumnKeys(columns, label) {
  if (columns == null) return null;
  if (!Array.isArray(columns)) return `${label}.columns must be an array of column keys or null`;
  if (columns.length > MAX_TARGET_COLUMNS) return `${label}.columns may not exceed ${MAX_TARGET_COLUMNS} entries`;
  for (const c of columns) {
    if (typeof c !== 'string' || c.length === 0 || c.length > MAX_COLUMN_KEY_LENGTH) {
      return `${label}.columns must contain non-empty column keys`;
    }
  }
  return null;
}

/**
 * @param {*} value raw cell_targets / value_scope from a request body (object or
 *   its serialized form — the DTO mapper stringifies JSON columns, and some
 *   write paths validate after that mapping, mirroring invalidChoiceConfigShape).
 * @param {object} [opts]
 * @param {string} [opts.label] the column being judged, so the reason names the
 *   key the caller actually sent. Defaults to the column this guard was written
 *   for.
 * @returns {string|null} human-readable reason, or null when the value is
 *   acceptable (including null/undefined = whole-field).
 */
function invalidCellTargetsShape(value, opts) {
  const label = (opts && opts.label) || 'cell_targets';
  if (value == null) return null;
  let cfg = value;
  if (typeof cfg === 'string') {
    try { cfg = JSON.parse(cfg); } catch { return `${label} must be valid JSON`; }
    if (cfg == null) return null;
  }
  if (typeof cfg !== 'object' || Array.isArray(cfg)) {
    return `${label} must be an object of the form { rows, columns }`;
  }
  for (const key of Object.keys(cfg)) {
    if (!ALLOWED_KEYS.has(key)) {
      // The offending key is echoed so the caller can find their typo, but
      // truncated: it is client-supplied and the response must not become an
      // amplifier for an arbitrarily long input.
      const shown = key.length > 40 ? `${key.slice(0, 40)}…` : key;
      return `${label} contains an unknown key '${shown}'; allowed keys: ${[...ALLOWED_KEYS].join(', ')}`;
    }
  }
  return invalidRowIndices(cfg.rows, label) || invalidColumnKeys(cfg.columns, label);
}

/** The document, whatever form the caller holds it in, or null. */
function readScopeDocument(value) {
  if (value == null) return null;
  let cfg = value;
  if (typeof cfg === 'string') {
    try { cfg = JSON.parse(cfg); } catch { return null; }
  }
  if (!cfg || typeof cfg !== 'object' || Array.isArray(cfg)) return null;
  return cfg;
}

/**
 * Does this document actually narrow the override to specific cells?
 *
 * null / absent / `{}` / all-null members mean whole-field, which is legal on
 * every field type and carries today's semantics. Only a document that names
 * rows or columns needs a table field underneath it to mean anything.
 *
 * THE LOOSER OF THE TWO READINGS, deliberately: `{rows: []}` counts here and
 * does NOT count for `scopeNarrows` below. Callers that use this as a
 * cheap pre-filter before a read want the loose answer — it can cost a read
 * that turns out unnecessary, and it can never skip one.
 *
 * @param {*} value raw or serialized cell_targets
 * @returns {boolean}
 */
function hasCellScope(value) {
  const cfg = readScopeDocument(value);
  if (cfg === null) return false;
  return cfg.rows != null || cfg.columns != null;
}

/**
 * Does this document narrow the setting to cells the RESOLVER will honour?
 *
 * The strict reading, and the one that decides meaning rather than cost: an
 * EMPTY array narrows nothing, because the authoring surface produces an empty
 * list whenever the author narrows only the other axis. `normalizeCellScope`
 * (src/fmb/lib/cell-targets.ts) and `readScope`
 * (edge/lib/blueprint-cell-lock.js) both read it that way, so a guard that read
 * `{rows: []}` as "targets no rows" would judge a document the runtime reads
 * differently.
 *
 * Accepts the serialized form: several write paths validate AFTER the DTO
 * mapper has stringified the JSON columns, and the YAML import path stores the
 * column as a string before the import guard ever sees it. An object-only
 * reading silently passed both of those.
 *
 * @param {*} value raw or serialized cell_targets / value_scope
 * @returns {boolean}
 */
function scopeNarrows(value) {
  const cfg = readScopeDocument(value);
  if (cfg === null) return false;
  return (Array.isArray(cfg.rows) && cfg.rows.length > 0)
    || (Array.isArray(cfg.columns) && cfg.columns.length > 0);
}

module.exports = {
  invalidCellTargetsShape,
  hasCellScope,
  scopeNarrows,
  MAX_TARGET_ROWS,
  MAX_TARGET_COLUMNS,
  MAX_COLUMN_KEY_LENGTH,
};
