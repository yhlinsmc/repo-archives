/**
 * docs-disabled.js — the production "docs UI disabled" stub message, shared by
 * the infra (/api/docs) and edge (/edge/docs) prod stubs.
 *
 * SECURITY — the message MUST NOT advertise the raw OpenAPI spec URL. The
 * /api/openapi.json and /edge/openapi.json endpoints are login-gated operator
 * surfaces (mountInternalSpec / mountEdgeInternalSpec); pointing anonymous prod
 * callers at them would misrepresent them as open.
 */
const DOCS_DISABLED_MESSAGE = 'API documentation is disabled in production.';

module.exports = { DOCS_DISABLED_MESSAGE };
