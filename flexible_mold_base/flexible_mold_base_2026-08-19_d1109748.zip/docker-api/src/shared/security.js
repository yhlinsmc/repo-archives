/**
 * security.js — Shared security configuration for API-infra and API-edge.
 *
 * Provides consistent helmet CSP configuration across both services.
 * API docs paths get a relaxed CSP (unsafe-inline + unsafe-eval for Scalar).
 * All other paths use strict default CSP.
 */
const helmet = require('helmet');
const path = require('path');
const express = require('express');

// ── Scalar self-hosted bundle ────────────────────────────────────────────────
// Serve @scalar/api-reference browser bundle from node_modules.
// This avoids CDN dependency (required for AIRGAP) and allows CSP 'self'.
const SCALAR_BUNDLE_DIR = path.join(
  __dirname, '..', '..', 'node_modules', '@scalar', 'api-reference', 'dist', 'browser'
);

// The Scalar bundle's own stylesheet declares @font-face rules pointing at an
// external font host, and that request succeeds on a deployment with outbound
// access — a documentation page that depends on a third party at read time.
// These are the same woff2 files the app vendors, copied into this tree because
// the API image is built from docker-api/ alone and the portal is served from
// the API origin, not the web one. Redistributed under the SIL OFL; the licence
// and provenance sit beside them in LICENSE.txt.
const DOCS_FONT_DIR = path.join(__dirname, 'assets', 'fonts');

// Sub-path of the Scalar asset mount. One mount, so a deployment cannot end up
// serving the bundle but not the fonts it now points at.
const DOCS_FONT_SUBPATH = 'fonts';

/**
 * Create a static file server for the Scalar browser bundle and the vendored
 * documentation fonts.
 * Mount at a known path (e.g., /scalar-assets) so the cdn option can point to it.
 *
 * @param {string} mountPath - URL path prefix (e.g., '/scalar-assets')
 * @returns {import('express').Router}
 */
function createScalarStaticRouter(mountPath) {
  const router = express.Router();
  router.use(`${mountPath}/${DOCS_FONT_SUBPATH}`, express.static(DOCS_FONT_DIR, {
    maxAge: '1d',
    immutable: true,
  }));
  router.use(mountPath, express.static(SCALAR_BUNDLE_DIR, {
    maxAge: '1d',
    immutable: true,
  }));
  return router;
}

/**
 * Get the self-hosted CDN URL for Scalar API reference.
 * @param {string} mountPath - Must match the mount path used in createScalarStaticRouter
 * @returns {string}
 */
function getScalarCdnUrl(mountPath) {
  return `${mountPath}/standalone.js`;
}

/**
 * Same-origin URL prefix for the vendored documentation fonts.
 * @param {string} mountPath - Must match the mount path used in createScalarStaticRouter
 * @returns {string}
 */
function getDocsFontBaseUrl(mountPath) {
  return `${mountPath}/${DOCS_FONT_SUBPATH}`;
}

/**
 * CSS handed to Scalar for a docs page. Two jobs, both about not reaching an
 * external host for a font.
 *
 * The bundle's stylesheet declares `@font-face` for "Inter" / "JetBrains Mono"
 * against an external font host, and that request returns 200 on a deployment
 * with outbound access. The `font-src 'self'` in createDocsHelmet() stops the
 * fetch, but a blocked fetch renders the page in a fallback system font, so the
 * faces are also redeclared here against same-origin copies.
 *
 * Redeclaring under the SAME family names is the override the CSP is paired
 * with, but it only wins if this stylesheet is the later one, and Scalar injects
 * its own styles at runtime — after this server-rendered <style>. So the family
 * the page actually asks for is a PRIVATE name the bundle cannot redeclare, put
 * first in the font stack. The browser resolves it from this origin and never
 * needs "Inter" at all, which is the difference between "the external request
 * was blocked" and "the external request was never made".
 *
 * Latin subset only, matching what the app vendors: text outside that range
 * falls through to the system stack rather than to the bundle's external faces,
 * which is why "Inter" is not left in the stack behind the private name.
 *
 * NOT ENOUGH ON ITS OWN. Measured on the deployment: fourteen requests to the
 * external font host, each with zero bytes transferred and no protocol — the
 * policy refused them, but the browser still asked. Nothing here can prevent
 * that, because the declarations being resolved are the bundle's own and it
 * injects them AFTER this stylesheet: for a family declared on both sides, the
 * later declaration is the one that wins. The requests stop only if the
 * declarations are never made, which is what buildDocsFontOptions() arranges.
 *
 * WHY IT LIVES BESIDE createDocsHelmet(): the two are one decision. The helmet
 * pins `font-src 'self'` for every docs page — /api/public-docs, /api/docs and
 * /edge/docs — and a page that gets the tightened policy without this override
 * has no font left to load at all. Same module, same argument, so a mount
 * cannot pick up one half and miss the other.
 * @param {string} mountPath - Must match the mount path used in createScalarStaticRouter
 * @returns {string}
 */
function buildDocsFontCss(mountPath) {
  const base = getDocsFontBaseUrl(mountPath);
  const LATIN = 'U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, '
    + 'U+0308, U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD';

  const face = (family, weight, file) => [
    '@font-face {',
    `  font-family: ${family};`,
    '  font-style: normal;',
    `  font-weight: ${weight};`,
    '  font-display: swap;',
    `  src: url('${base}/${file}') format('woff2');`,
    `  unicode-range: ${LATIN};`,
    '}',
  ].join('\n');

  // The heaviest vendored weight carries the range up to 900, so the bundle's
  // bold (700) resolves to a real face instead of a synthesised one.
  const VENDORED = [
    { families: ["'Docs Sans'", "'Inter'"], weight: '400', file: 'inter-latin-400-normal.woff2' },
    { families: ["'Docs Sans'", "'Inter'"], weight: '500', file: 'inter-latin-500-normal.woff2' },
    { families: ["'Docs Sans'", "'Inter'"], weight: '600 900', file: 'inter-latin-600-normal.woff2' },
    { families: ["'Docs Mono'", "'JetBrains Mono'"], weight: '400', file: 'jetbrains-mono-latin-400-normal.woff2' },
    { families: ["'Docs Mono'", "'JetBrains Mono'"], weight: '500 900', file: 'jetbrains-mono-latin-500-normal.woff2' },
  ];

  const blocks = [];
  for (const { families, weight, file } of VENDORED) {
    for (const family of families) blocks.push(face(family, weight, file));
  }

  blocks.push([
    ':root, .scalar-app {',
    "  --scalar-font: 'Docs Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;",
    "  --scalar-font-code: 'Docs Mono', ui-monospace, Menlo, Monaco, 'Courier New', monospace;",
    '}',
  ].join('\n'));

  return blocks.join('\n');
}

/**
 * The font half of a docs page's Scalar configuration: the same-origin faces to
 * use, and the instruction not to declare the external ones.
 *
 * `withDefaultFonts: false` is the bundle's own switch — its theme stylesheet is
 * assembled as `[…theme, fonts ? EXTERNAL_FONT_FACES : '']`, so turning it off
 * means the fourteen `@font-face` rules pointing at the external host are never
 * put in the document. That is the difference the acceptance wording asks for:
 * not a request that fails, no request at all.
 *
 * The two travel together for the same reason the CSS travels with the helmet:
 * a page that switches the bundle's fonts off and does not declare replacements
 * has no font left to load, and a page that declares replacements without
 * switching the bundle's off keeps asking for the external ones. Returned as one
 * object so a mount cannot take one and miss the other.
 * @param {string} mountPath - Must match the mount path used in createScalarStaticRouter
 * @returns {{ customCss: string, withDefaultFonts: false }}
 */
function buildDocsFontOptions(mountPath) {
  return { customCss: buildDocsFontCss(mountPath), withDefaultFonts: false };
}

// ── Helmet configurations ────────────────────────────────────────────────────

// Origin-Agent-Cluster is disabled on every helmet instance below. The header
// asks the browser to origin-key the agent cluster, a signal that is
// browser-session-sticky: once a browser has recorded an origin as site-keyed,
// a later `?1` response conflicts with that record and the console warns until
// the browser session resets. This deployment has no ingress layer to set the
// header uniformly and gains negligible isolation from it, so no response
// requests origin-keying.
const ORIGIN_AGENT_CLUSTER_DISABLED = { originAgentCluster: false };

/**
 * Strict helmet config for normal routes (no unsafe-eval, no unsafe-inline).
 */
function createStrictHelmet() {
  return helmet({ ...ORIGIN_AGENT_CLUSTER_DISABLED });
}

/**
 * Relaxed helmet config for API docs routes (Scalar needs unsafe-inline + unsafe-eval).
 * Only applied to specific paths via route-scoped middleware.
 */
function createDocsHelmet() {
  return helmet({
    ...ORIGIN_AGENT_CLUSTER_DISABLED,
    contentSecurityPolicy: {
      directives: {
        ...helmet.contentSecurityPolicy.getDefaultDirectives(),
        'script-src': ["'self'", "'unsafe-inline'", "'unsafe-eval'"],
        'worker-src': ["'self'", 'blob:'],
        'style-src': ["'self'", "'unsafe-inline'"],
        // helmet's default is `font-src 'self' https: data:`; the inherited
        // `https:` is what let the bundle's @font-face reach an external host
        // and get a 200 back. The fonts are vendored and served from this
        // origin, so nothing legitimate needs the wildcard.
        'font-src': ["'self'"],
        // Written down rather than inherited: with no connect-src, this falls
        // back to default-src, so a future helmet default that widens
        // default-src would quietly widen the docs page's outbound calls too.
        // The public portal fetches its OpenAPI document from this origin
        // (public-docs.js), which is the whole of what 'self' has to cover —
        // anything the page reaches for beyond that is a regression, not a
        // feature waiting for a wider policy.
        'connect-src': ["'self'"],
        // Deliberately identical to the effective policy today, recorded so a
        // default change cannot move it silently. The consequence is accepted:
        // the bundle's example avatars come from an external host and simply do
        // not render.
        'img-src': ["'self'", 'data:'],
      },
    },
  });
}

module.exports = {
  createStrictHelmet,
  createDocsHelmet,
  createScalarStaticRouter,
  getScalarCdnUrl,
  getDocsFontBaseUrl,
  buildDocsFontCss,
  buildDocsFontOptions,
  SCALAR_BUNDLE_DIR,
  DOCS_FONT_DIR,
};
