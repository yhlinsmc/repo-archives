'use strict';

/**
 * sandbox-document.cjs — the null-origin transformer sandbox document, as a
 * string baked into JS (NOT a static .html asset).
 *
 * WHY a string and not public/sandbox.html:
 *   Some downstream environments run an HTML-file sanitiser on ingest that
 *   strips <script> from any .html file. That silently removed the sandbox's
 *   worker bootstrap, leaving an iframe that never posts `ready` (the parent
 *   bridge then times out with "sandbox unavailable"). A .js/.cjs module is not
 *   an .html file, so it survives that sanitiser intact. The frontend route
 *   (index-frontend.js) and the Vite dev middleware both serve THIS string, so
 *   there is one source of truth and no on-disk .html to mangle.
 *
 * SECURITY: this string contains the only `new Function` in the app. It runs
 * exclusively inside the <iframe sandbox="allow-scripts"> null-origin document
 * under the route-scoped relaxed CSP — never on the app origin. The
 * forbid-eval-helpers lint exempts this file by path (it is the intentional,
 * reviewed eval site, mirroring the public/sandbox.html exemption it replaces).
 *
 * String.raw is used so the doubled escapes in the worker bootstrap (e.g.
 * `\\n` inside a JS string that the worker itself re-parses) are preserved
 * byte-for-byte; the content has no backtick or ${ sequence.
 */
const SANDBOX_HTML = String.raw`<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <title>fmb transformer sandbox</title>
</head>
<body>
  <!--
    Null-origin transformer sandbox.

    This document is loaded by the app ONLY inside an
    <iframe sandbox="allow-scripts"> (no allow-same-origin) → it runs in an
    opaque/null origin with no access to the app's DOM, cookies, localStorage,
    or API session. It is served with a route-scoped CSP that allows
    'unsafe-eval' (for new Function) here and ONLY here; the main app document
    CSP forbids eval. connect-src 'none' + the worker scope lockdown below mean
    even arbitrary code in this context cannot reach the network.

    SECURITY INVARIANT: the security of this design depends on the parent
    loading this page with sandbox="allow-scripts" and WITHOUT
    allow-same-origin. Adding allow-same-origin re-couples eval to the app
    origin and defeats the isolation.
  -->
  <script>
    'use strict';

    // Worker bootstrap string — locks down the worker scope (remove network +
    // ambient APIs, freeze prototypes) and runs the transformer via
    // new Function. This is the ONLY new Function / eval in the whole app, and
    // it executes inside this null-origin iframe's blob: Worker.
    var WORKER_BOOTSTRAP = [
      "'use strict';",
      "var _nullify=function(n){try{self[n]=undefined;}catch(e){try{Object.defineProperty(self,n,{value:undefined,writable:false,configurable:false});}catch(e2){}}};",
      "['fetch','importScripts','XMLHttpRequest','WebSocket','EventSource','indexedDB','caches','BroadcastChannel','navigator','location'].forEach(_nullify);",
      "Object.freeze(Object.prototype);Object.freeze(Array.prototype);",
      "self.onmessage=function(e){var code=e.data.code,payload=e.data.payload,context=e.data.context,start=performance.now();try{var fn=new Function('payload','context','\"use strict\";\\n'+code);var result=fn(payload,context);self.postMessage({success:true,result:result,duration:Math.round(performance.now()-start)});}catch(err){self.postMessage({success:false,error:err instanceof Error?err.message:String(err),duration:Math.round(performance.now()-start)});}};"
    ].join('\n');

    var DEFAULT_TIMEOUT_MS = 5000;

    // Run one transformer in a fresh blob: Worker. The worker is a real
    // separate thread, so terminate() reliably kills a synchronous infinite
    // loop — the reason the worker (not just the iframe) carries the timeout.
    function runInWorker(msg, reply) {
      var start = performance.now();
      var url = null, worker = null, settled = false, timer = null;
      function finish(res) {
        if (settled) return;
        settled = true;
        if (timer) clearTimeout(timer);
        try { if (worker) worker.terminate(); } catch (e) { /* best effort */ }
        try { if (url) URL.revokeObjectURL(url); } catch (e) { /* best effort */ }
        reply(res);
      }
      try {
        var blob = new Blob([WORKER_BOOTSTRAP], { type: 'application/javascript' });
        url = URL.createObjectURL(blob);
        worker = new Worker(url);
        var timeoutMs = (typeof msg.timeoutMs === 'number' && msg.timeoutMs > 0) ? msg.timeoutMs : DEFAULT_TIMEOUT_MS;
        timer = setTimeout(function () {
          finish({ success: false, error: 'Execution timed out after ' + timeoutMs + 'ms', duration: timeoutMs });
        }, timeoutMs);
        worker.onmessage = function (e) { finish(e.data); };
        worker.onerror = function (e) {
          finish({ success: false, error: (e && e.message) || 'Worker execution error', duration: Math.round(performance.now() - start) });
        };
        worker.postMessage({ code: msg.code, payload: msg.payload, context: msg.context });
      } catch (err) {
        // No main-thread fallback — refuse rather than run unsandboxed.
        finish({ success: false, error: 'Web Worker unavailable in sandbox iframe.', duration: Math.round(performance.now() - start) });
      }
    }

    window.addEventListener('message', function (ev) {
      var data = ev.data;
      if (!data || data.__fmbSandbox !== 'request' || typeof data.id === 'undefined') return;
      var source = ev.source;
      runInWorker(data, function (result) {
        // Opaque origin → targetOrigin cannot be pinned; reply only to the
        // exact source window that sent the request.
        if (source) source.postMessage({ __fmbSandbox: 'response', id: data.id, result: result }, '*');
      });
    });

    // Tell the parent the bridge is live so it can flush any queued requests.
    if (window.parent) window.parent.postMessage({ __fmbSandbox: 'ready' }, '*');
  </script>
</body>
</html>
`;

module.exports = { SANDBOX_HTML };
