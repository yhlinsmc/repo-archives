/**
 * Unit tests for docker-api/src/shared/helpers.js — apiOk / apiError /
 * mapSqlErrorCode behaviour after PR 2 Q14 / MF4 hardening.
 *
 * Covers:
 *   - apiOk envelope shape + optional extraMeta
 *   - apiError envelope shape with and without a cause
 *   - MF4: DEBUG_API=true gating (stack + sql_* fields)
 *   - MF4: SQL code whitelist mapping (ER_DUP_ENTRY → DUPLICATE_KEY, etc.)
 *   - SQL code promotion when caller uses the default 'ERROR' code
 *   - SQL code preservation when caller passes an explicit override code
 */

import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import { createRequire } from 'module';
const require = createRequire(import.meta.url);
const { apiOk, apiError, mapSqlErrorCode } = require('../helpers');

describe('apiOk', () => {
  it('returns canonical success envelope shape', () => {
    const res = apiOk({ id: 1, name: 'ada' });
    expect(res.data).toEqual({ id: 1, name: 'ada' });
    expect(res.error).toBeNull();
    expect(res.meta).toMatchObject({
      db_type: 'MARIADB',
      provider: 'CUSTOM_API',
    });
    expect(typeof res.meta.timestamp).toBe('string');
  });

  it('merges optional extraMeta over defaults', () => {
    const res = apiOk([1, 2, 3], { total: 3, page: 1 });
    expect(res.meta).toMatchObject({ total: 3, page: 1, db_type: 'MARIADB' });
  });

  it('accepts null data', () => {
    const res = apiOk(null);
    expect(res.data).toBeNull();
    expect(res.error).toBeNull();
  });
});

describe('mapSqlErrorCode', () => {
  it('maps common driver codes to semantic codes', () => {
    expect(mapSqlErrorCode('ER_DUP_ENTRY')).toBe('DUPLICATE_KEY');
    expect(mapSqlErrorCode('ER_NO_REFERENCED_ROW_2')).toBe('FOREIGN_KEY_MISSING');
    expect(mapSqlErrorCode('ER_ROW_IS_REFERENCED_2')).toBe('FOREIGN_KEY_IN_USE');
    expect(mapSqlErrorCode('ER_BAD_FIELD_ERROR')).toBe('UNKNOWN_COLUMN');
    expect(mapSqlErrorCode('ER_NO_SUCH_TABLE')).toBe('UNKNOWN_TABLE');
    expect(mapSqlErrorCode('ER_LOCK_DEADLOCK')).toBe('DB_DEADLOCK');
    expect(mapSqlErrorCode('ECONNREFUSED')).toBe('DB_UNAVAILABLE');
  });

  it('maps unknown ER_* codes to generic SQL_ERROR', () => {
    expect(mapSqlErrorCode('ER_SOMETHING_NEW')).toBe('SQL_ERROR');
  });

  it('returns null for non-SQL codes', () => {
    expect(mapSqlErrorCode('VALIDATION_ERROR')).toBeNull();
    expect(mapSqlErrorCode(undefined)).toBeNull();
    expect(mapSqlErrorCode(null)).toBeNull();
    expect(mapSqlErrorCode('')).toBeNull();
  });
});

describe('apiError', () => {
  const origDebug = process.env.DEBUG_API;
  const origNodeEnv = process.env.NODE_ENV;

  beforeEach(() => {
    delete process.env.DEBUG_API;
    delete process.env.NODE_ENV;
  });

  afterEach(() => {
    if (origDebug === undefined) delete process.env.DEBUG_API;
    else process.env.DEBUG_API = origDebug;
    if (origNodeEnv === undefined) delete process.env.NODE_ENV;
    else process.env.NODE_ENV = origNodeEnv;
  });

  it('returns structured error envelope with default code and status', () => {
    const res = apiError('Something broke');
    expect(res.status).toBe(500);
    expect(res.body.data).toBeNull();
    expect(res.body.error.message).toBe('Something broke');
    expect(res.body.error.code).toBe('ERROR');
    expect(res.body.meta).toMatchObject({ db_type: 'MARIADB' });
  });

  it('accepts explicit code and status', () => {
    const res = apiError('Not found', 'NOT_FOUND', 404);
    expect(res.status).toBe(404);
    expect(res.body.error.code).toBe('NOT_FOUND');
  });

  it('includes optional source and hint fields', () => {
    const res = apiError('X', 'Y', 500, { source: '/api/x', hint: 'Try turning it off and on' });
    expect(res.body.error.source).toBe('/api/x');
    expect(res.body.error.hint).toBe('Try turning it off and on');
  });

  it('MF4: omits debug field when DEBUG_API is not set, even in development', () => {
    process.env.NODE_ENV = 'development';
    const cause = new Error('boom');
    cause.code = 'ER_DUP_ENTRY';
    const res = apiError('dup', 'DB_ERROR', 500, { cause });
    expect(res.body.error.debug).toBeUndefined();
  });

  it('MF4: includes debug field only when DEBUG_API === "true"', () => {
    process.env.DEBUG_API = 'true';
    const cause = new Error('boom');
    cause.code = 'ER_DUP_ENTRY';
    cause.errno = 1062;
    cause.sqlState = '23000';
    const res = apiError('dup', 'DB_ERROR', 500, { cause });
    expect(res.body.error.debug).toBeDefined();
    expect(res.body.error.debug.sql_code).toBe('ER_DUP_ENTRY');
    expect(res.body.error.debug.sql_errno).toBe(1062);
    expect(res.body.error.debug.sql_state).toBe('23000');
    expect(typeof res.body.error.debug.stack).toBe('string');
  });

  it('MF4: DEBUG_API=1 (not "true") does NOT enable debug payload', () => {
    process.env.DEBUG_API = '1';
    const cause = new Error('boom');
    const res = apiError('x', 'Y', 500, { cause });
    expect(res.body.error.debug).toBeUndefined();
  });

  it('MF4: promotes mapped SQL code when caller uses default ERROR code', () => {
    const cause = new Error('dup'); cause.code = 'ER_DUP_ENTRY';
    const res = apiError('dup', 'ERROR', 500, { cause });
    expect(res.body.error.code).toBe('DUPLICATE_KEY');
  });

  it('MF4: promotes mapped SQL code when caller uses DB_ERROR sentinel', () => {
    const cause = new Error('deadlock'); cause.code = 'ER_LOCK_DEADLOCK';
    const res = apiError('deadlock', 'DB_ERROR', 500, { cause });
    expect(res.body.error.code).toBe('DB_DEADLOCK');
  });

  it('MF4: preserves explicit caller code over SQL mapping', () => {
    const cause = new Error('dup'); cause.code = 'ER_DUP_ENTRY';
    const res = apiError('dup', 'USER_EMAIL_EXISTS', 409, { cause });
    expect(res.body.error.code).toBe('USER_EMAIL_EXISTS');
  });

  it('MF4: leaves non-SQL errors alone', () => {
    const cause = new Error('fs blew up'); cause.code = 'ENOENT';
    const res = apiError('missing', 'ERROR', 500, { cause });
    expect(res.body.error.code).toBe('ERROR');
  });
});
