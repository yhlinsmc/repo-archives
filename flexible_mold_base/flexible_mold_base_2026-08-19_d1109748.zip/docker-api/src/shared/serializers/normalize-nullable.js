'use strict';

function normalizeNullableStrings(row, fieldList) {
  if (row == null) return row;
  const out = { ...row };
  for (const f of fieldList) {
    if (out[f] == null) out[f] = '';
  }
  return out;
}

function normalizeNullableNumbers(row, fieldList, defaultVal = 0) {
  if (row == null) return row;
  const out = { ...row };
  for (const f of fieldList) {
    if (out[f] == null) out[f] = defaultVal;
  }
  return out;
}

function normalizeRows(rows, stringFields = [], numberFieldsWithDefaults = {}) {
  if (!Array.isArray(rows)) return rows;
  return rows.map((row) => {
    let r = normalizeNullableStrings(row, stringFields);
    for (const [field, defaultVal] of Object.entries(numberFieldsWithDefaults)) {
      r = normalizeNullableNumbers(r, [field], defaultVal);
    }
    return r;
  });
}

module.exports = {
  normalizeNullableStrings,
  normalizeNullableNumbers,
  normalizeRows,
};
