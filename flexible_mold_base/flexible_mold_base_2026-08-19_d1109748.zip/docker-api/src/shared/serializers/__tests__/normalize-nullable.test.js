/**
 * Unit tests for docker-api/src/shared/serializers/normalize-nullable.js —
 * Y-pattern API boundary normalization helpers.
 *
 * Lives under __tests__/ so vitest collects it (per vitest.config.ts include
 * pattern). CommonJS module under test is loaded via createRequire.
 */

import { describe, it, expect } from 'vitest';
import { createRequire } from 'module';

const require = createRequire(import.meta.url);
const {
  normalizeNullableStrings,
  normalizeNullableNumbers,
  normalizeRows,
} = require('../normalize-nullable');

describe('normalize-nullable', () => {
  describe('normalizeNullableStrings', () => {
    it('null → ""', () => {
      expect(normalizeNullableStrings({ a: null, b: 'foo' }, ['a', 'b']))
        .toEqual({ a: '', b: 'foo' });
    });

    it('undefined → ""', () => {
      expect(normalizeNullableStrings({ a: undefined, b: 'foo' }, ['a', 'b']))
        .toEqual({ a: '', b: 'foo' });
    });

    it('"" stays "" (no-op)', () => {
      expect(normalizeNullableStrings({ a: '' }, ['a'])).toEqual({ a: '' });
    });

    it('field not in list stays unchanged (null preserved)', () => {
      expect(normalizeNullableStrings({ a: null, b: null }, ['a']))
        .toEqual({ a: '', b: null });
    });

    it('non-string defensive: numeric value not coerced', () => {
      expect(normalizeNullableStrings({ a: 123 }, ['a'])).toEqual({ a: 123 });
    });

    it('input row is not mutated (shallow-copy invariant)', () => {
      const input = { a: null };
      normalizeNullableStrings(input, ['a']);
      expect(input.a).toBe(null);
    });

    it('returns null when input row is null', () => {
      expect(normalizeNullableStrings(null, ['a'])).toBe(null);
    });

    it('returns undefined when input row is undefined', () => {
      expect(normalizeNullableStrings(undefined, ['a'])).toBe(undefined);
    });
  });

  describe('normalizeNullableNumbers', () => {
    it('null → 0 default', () => {
      expect(normalizeNullableNumbers({ x: null, y: 5 }, ['x', 'y'], 0))
        .toEqual({ x: 0, y: 5 });
    });

    it('null → custom default', () => {
      expect(normalizeNullableNumbers({ x: null }, ['x'], 999))
        .toEqual({ x: 999 });
    });
  });

  describe('normalizeRows (composition)', () => {
    it('applies string + number normalization across rows', () => {
      const rows = [
        { default_value: null, placeholder: 'x', sort_order: null },
        { default_value: 'y', placeholder: null, sort_order: 5 },
      ];
      expect(normalizeRows(rows, ['default_value', 'placeholder'], { sort_order: 0 }))
        .toEqual([
          { default_value: '', placeholder: 'x', sort_order: 0 },
          { default_value: 'y', placeholder: '', sort_order: 5 },
        ]);
    });
  });
});
