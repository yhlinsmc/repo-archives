'use strict';

/**
 * public-template.js — the single response shape for a template on the Public
 * Integration API.
 *
 * Create and get used to shape their responses inline, in two files, and had
 * drifted: create returned `path` but no `schema_version`, get returned
 * `schema_version` but no `path`, and both returned an `owner_id` that is not an
 * input to any public endpoint. Two call sites cannot drift when the shape is
 * built in one place, and PUBLIC_TEMPLATE_FIELDS is what both are tested
 * against — adding a field to one endpoint without adding it here fails.
 *
 * Timestamp normalisation and payload masking live behind the serializer for
 * the same reason: at the call sites they were two more things to remember.
 *
 * Only the edge tier consumes this (infra forwards, it does not shape), which
 * is why requiring the edge-side masking + timestamp helpers here is safe:
 * neither of them touches a DB module, so nothing here can pull a pool into
 * infra by transitive import.
 */
const { normalizeTimestamp } = require('../../edge/lib/dto-mapper');
const { maskDeep } = require('../../edge/routes/app/flow-recipe-runs/serializer');

/**
 * The key set returned by BOTH create and get (and by the list projection).
 * `id` stays because it is the handle for every subsequent call. `owner_id` and
 * `blueprint_id` are absent from the TEMPLATE projection specifically: neither
 * is an input to any template endpoint, and the resolved name-path already
 * addresses the row, so returning them only invited an integrator to depend on
 * an internal identifier instead. This is not an API-wide policy — the run
 * projection still returns `blueprint_id`, because a run has no name-path and
 * that id is its only link back to a blueprint.
 */
const PUBLIC_TEMPLATE_FIELDS = Object.freeze([
  'id',
  'name',
  'is_draft',
  'path',
  'owner_username',
  'schema_version',
  'created_at',
  'updated_at',
]);

/** The detail projection: the shared shape plus the two payload blobs. */
const PUBLIC_TEMPLATE_DETAIL_FIELDS = Object.freeze([
  ...PUBLIC_TEMPLATE_FIELDS,
  'payload',
  'generated_outputs',
]);

// Hierarchy tiers in root→leaf order, paired with the row/chain column that
// carries each tier's node id.
const PATH_TIERS = Object.freeze([
  ['category', 'category_id'],
  ['release', 'release_id'],
  ['blueprint', 'blueprint_id'],
  ['variant', 'variant_id'],
]);

/**
 * CORRECTNESS: driver timestamps are naive UTC strings (dateStrings:true, UTC
 * session) — normalizeTimestamp appends the `Z` so `new Date` parses them as
 * UTC rather than the deployed process TZ. Without it every emitted timestamp
 * is wrong by the container's offset.
 * @param {unknown} value
 * @returns {string|null}
 */
function isoTimestamp(value) {
  if (value == null) return null;
  const d = value instanceof Date ? value : new Date(normalizeTimestamp(value));
  return Number.isNaN(d.getTime()) ? null : d.toISOString();
}

/**
 * MariaDB JSON is LONGTEXT — the driver may hand back a parsed object or a raw
 * string. A corrupt row degrades to null rather than throwing inside a handler.
 * @param {unknown} value
 */
function parseJsonColumn(value) {
  if (value == null) return null;
  if (typeof value === 'object') return value;
  try { return JSON.parse(value); } catch { return null; }
}

/**
 * The resolved hierarchy names for a template, TRUNCATED at the scope boundary:
 * a tier whose node is not in the caller's granted set is omitted entirely.
 *
 * SECURITY: this is the same truncation the blueprint read path applies. When a
 * grant starts below a category/release, those ancestor NAMES must never reach
 * the response — an out-of-scope name is as disclosing as an out-of-scope row.
 *
 * @param {Map<string, {name?: string}>} byId hierarchy nodes by id
 * @param {Set<string>} inScope the caller's visible node ids
 * @param {Record<string, string|null|undefined>} chain row or chain carrying the four tier ids
 * @returns {Record<string, string>}
 */
function buildPublicTemplatePath(byId, inScope, chain) {
  const out = {};
  if (!chain) return out;
  for (const [tier, column] of PATH_TIERS) {
    const id = chain[column];
    if (!id || !inScope.has(id)) continue;
    const node = byId.get(id);
    if (node && typeof node.name === 'string') out[tier] = node.name;
  }
  return out;
}

/**
 * The shared shape. `owner_username` is null in two cases the docs must state:
 * a template owned by the service account (no users row to name), and one owned
 * by a locally-authenticated user (their `kc_username` is NULL).
 *
 * @param {Record<string, unknown>} row a DB row, or the values just inserted
 * @param {Record<string, string>} path from buildPublicTemplatePath
 */
function serializePublicTemplate(row, path) {
  return {
    id: row.id,
    name: row.name,
    is_draft: row.is_draft === 1 || row.is_draft === true,
    path: path || {},
    owner_username: row.owner_username ?? null,
    schema_version: row.schema_version || null,
    created_at: isoTimestamp(row.created_at),
    updated_at: isoTimestamp(row.updated_at),
  };
}

/**
 * The shared shape plus the payload blobs.
 *
 * SECURITY: a template payload can carry secret-named leaves (a customer may
 * paste a token into a text field), so both blobs are deep-masked before they
 * reach a public client.
 *
 * @param {Record<string, unknown>} row
 * @param {Record<string, string>} path
 */
function serializePublicTemplateDetail(row, path) {
  return {
    ...serializePublicTemplate(row, path),
    payload: maskDeep(parseJsonColumn(row.payload)),
    generated_outputs: maskDeep(parseJsonColumn(row.generated_outputs)),
  };
}

module.exports = {
  PUBLIC_TEMPLATE_FIELDS,
  PUBLIC_TEMPLATE_DETAIL_FIELDS,
  buildPublicTemplatePath,
  serializePublicTemplate,
  serializePublicTemplateDetail,
  isoTimestamp,
};
