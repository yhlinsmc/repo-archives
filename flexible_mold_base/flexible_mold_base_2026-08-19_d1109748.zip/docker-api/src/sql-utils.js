/**
 * sql-utils.js — Shared SQL utilities for export/import operations.
 *
 * Provides:
 *   escapeString(str)         — escape special chars in SQL string literals
 *   escapeSqlValue(value, columnType) — escape a JS value for SQL INSERT
 *   splitSqlStatements(sql)   — split SQL text into statements respecting string literals
 */

/**
 * Escape special characters in a SQL string literal.
 * Handles backslashes, single quotes, newlines, carriage returns, tabs, and null bytes.
 */
function escapeString(str) {
  return str
    .replace(/\\/g, '\\\\')
    .replace(/'/g, "\\'")
    .replace(/\n/g, '\\n')
    .replace(/\r/g, '\\r')
    .replace(/\t/g, '\\t')
    .replace(/\0/g, '\\0');
}

/**
 * Escape a JavaScript value for use in a SQL INSERT statement.
 * Returns the SQL literal representation (e.g. 'hello', NULL, 42).
 *
 * @param {*} value - The value to escape
 * @param {string} [columnType] - Optional MariaDB DATA_TYPE (e.g. 'TINYINT', 'JSON')
 * @returns {string} SQL literal
 */
function escapeSqlValue(value, columnType) {
  if (value === null || value === undefined) return 'NULL';

  // Boolean fields
  if (typeof value === 'boolean') return value ? '1' : '0';
  // MariaDB TINYINT: preserve numeric value (not just truthiness)
  if (columnType === 'TINYINT' && typeof value === 'number') return String(Math.trunc(value));

  // Numbers
  if (typeof value === 'number') {
    if (Number.isNaN(value) || !Number.isFinite(value)) return 'NULL';
    return String(value);
  }

  // BigInt
  if (typeof value === 'bigint') return String(value);

  // Date objects
  if (value instanceof Date) {
    return `'${value.toISOString().slice(0, 19).replace('T', ' ')}'`;
  }

  // JSON/object — serialize to string
  if (typeof value === 'object') {
    const json = JSON.stringify(value);
    return `'${escapeString(json)}'`;
  }

  // String values
  return `'${escapeString(String(value))}'`;
}

/**
 * Split a SQL text into individual statements, correctly handling string literals.
 *
 * Unlike naive `.split(';')`, this parser tracks whether the cursor is inside
 * a single-quoted string and only splits on semicolons outside of strings.
 * Handles both `\'` (backslash escape) and `''` (SQL standard doubled quote).
 * Also correctly handles -- line comments and block comments so that
 * apostrophes inside comments (e.g. -- don't remove) do not corrupt parsing.
 *
 * Filters out:
 *   - Empty statements
 *   - Pure comment blocks
 *   - Transaction wrappers (`START TRANSACTION`, `COMMIT`)
 *   - `SET NAMES` statements (caller manages encoding)
 *
 * @param {string} sql - Raw SQL text (may contain multiple statements)
 * @returns {string[]} Array of individual SQL statements (trimmed, no trailing semicolons)
 */
function splitSqlStatements(sql) {
  const statements = [];
  let current = '';
  let inString = false;
  let inLineComment = false;
  let inBlockComment = false;
  let i = 0;

  while (i < sql.length) {
    const ch = sql[i];
    const next = i + 1 < sql.length ? sql[i + 1] : '';

    // ── Inside line comment (-- ... \n) ──
    if (inLineComment) {
      if (ch === '\n') {
        inLineComment = false;
      }
      current += ch;
      i++;
      continue;
    }

    // ── Inside block comment (/* ... */) ──
    if (inBlockComment) {
      if (ch === '*' && next === '/') {
        inBlockComment = false;
        current += '*/';
        i += 2;
        continue;
      }
      current += ch;
      i++;
      continue;
    }

    // ── Inside string literal ──
    if (inString) {
      if (ch === '\\') {
        // Backslash escape inside string — consume next char
        current += ch;
        i++;
        if (i < sql.length) {
          current += sql[i];
        }
        i++;
        continue;
      }
      if (ch === "'") {
        // Check for doubled single quote (SQL standard escape)
        if (next === "'") {
          current += "''";
          i += 2;
          continue;
        }
        // End of string
        inString = false;
        current += ch;
        i++;
        continue;
      }
      current += ch;
      i++;
      continue;
    }

    // ── Outside string / comment ──

    // Detect line comment start: --
    if (ch === '-' && next === '-') {
      inLineComment = true;
      current += '--';
      i += 2;
      continue;
    }

    // Detect block comment start: /*
    if (ch === '/' && next === '*') {
      inBlockComment = true;
      current += '/*';
      i += 2;
      continue;
    }

    if (ch === "'") {
      inString = true;
      current += ch;
      i++;
      continue;
    }

    if (ch === ';') {
      const trimmed = current.trim();
      if (trimmed) {
        statements.push(trimmed);
      }
      current = '';
      i++;
      continue;
    }

    current += ch;
    i++;
  }

  // Remaining text after last semicolon
  const trimmed = current.trim();
  if (trimmed) {
    statements.push(trimmed);
  }

  // Filter out comments, transaction wrappers, and SET NAMES
  return statements.filter(s => {
    // Strip block comments and line comments, then check if any SQL remains
    const stripped = s
      .replace(/\/\*[\s\S]*?\*\//g, '')   // remove /* ... */
      .replace(/--[^\n]*/g, '')            // remove -- ...
      .trim();
    if (!stripped) return false;

    // Skip transaction wrappers and SET NAMES (caller handles these)
    if (/^(START\s+TRANSACTION|COMMIT|SET\s+NAMES)\b/i.test(stripped)) return false;

    return true;
  });
}

module.exports = { escapeString, escapeSqlValue, splitSqlStatements };
