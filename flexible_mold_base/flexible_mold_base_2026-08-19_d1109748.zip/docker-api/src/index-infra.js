/**
 * index-infra.js — API-infra entry point (frontend-facing service).
 *
 * Architecture:
 *   Browser → Vite → API-infra (:3200) → API-edge (:3201) → MariaDB
 *
 * This file is used when API_ROLE=infra (or unset, for backward compat).
 *
 * NOTE: infra-talks-to-edge-only is enforced here — the pool import is gone.
 * app.listen() runs immediately at boot; edge readiness is NOT a precondition.
 * /health, pool-gate, and access-check fetch state from edge via S2S (with a
 * 5s pool-state cache). When edge is unreachable: /health returns 200 with
 * edge_unreachable:true; protected routes return 503 with hint=edge_unreachable;
 * setup routes stay 200 (wizard must remain reachable in setup-mode cold boot).
 *
 * Middleware ordering (load-bearing — do not reorder):
 *   helmet → cors → json → CSRF → pre-auth-limiters → keycloak-oidc → auth
 *   → public-docs → auth-limiters → setup-forwarding → static → X-Database
 *   → pool-gate → access-check → routes → error-handler → SPA-fallback
 */
require('dotenv').config();

const { apiError } = require('./shared/helpers');
const { resolveAuthMode, detectAuthMode, probeKeycloakDiscovery, setResolvedAuthMode } = require('./shared/config');
const { getKeycloakMiddleware } = require('./infra/middleware/keycloak-oidc');
const { logger: rootLogger } = require('./shared/lib/logger');
const { printBootBanner } = require('./shared/lib/boot-banner');
const logger = rootLogger.child({ module: 'api-infra' });
const { startKeycloakHealthProbe, stopKeycloakHealthProbe } = require('./lib/keycloak-health');
const { createForwardingProxy } = require('./infra/lib/remote-client');
const { getCachedPoolState, invalidatePoolStateCache } = require('./infra/lib/pool-state-cache');
const { fetchAuthMode, EdgeUnreachable, EdgeTimeout, EdgeAuthFailed } = require('./infra/lib/edge-state-client');
const { isPublicApiPath } = require('./shared/lib/public-api-path');
const { seedAtBoot: seedRateLimitCache } = require('./infra/lib/rate-limit-config-cache');

// ── Extracted modules ───────────────────────────────────────────────────────
const { createApp, SERVE_STATIC, DIST_PATH, PER_REQUEST_PATHS, SCHEMA_ROUTABLE } = require('./infra/app-setup');
const { mountPreAuthLimiters, mountAuthenticatedLimiters } = require('./infra/limiters');
const { mountAuthForwarding, mountRemainingRoutes } = require('./infra/forwarding');
const { mountSandboxDocument, mountStatic, mountSpaFallback } = require('./infra/static-spa');
const { createServer } = require('./infra/dev-https');

// ── Platform routes (shared infrastructure) ─────────────────────────────────
const authSessionRoutes = require('./infra/routes/auth-session');
const { accessCheckMiddleware } = require('./infra/middleware/access-check');

const app = createApp();

// ── Pool-state cache extracted to infra/lib/pool-state-cache.js ─────────────
// 5s positive / 1s negative TTL. See module header for rationale.

// ── Health endpoint (includes edge health) ───────────────────────────────────
// INVARIANT: /health MUST return HTTP 200 unconditionally. The body may degrade
// (db=error, pool_state=setup-required), but the status code is the K8s
// readiness probe target — gating it on pool/schema state would make the setup
// wizard unreachable when the pool is null. Pool diagnostic comes from edge via
// S2S (fetchEdgeHealth). Edge unreachable surfaces as edge_unreachable:true +
// db='unknown', still HTTP 200.
app.get('/health', async (_req, res) => {
  const poolState = await getCachedPoolState();
  const status = {
    api: 'ok',
    role: 'infra',
    db: poolState.edge_unreachable ? 'unknown' : poolState.db,
    auth_mode: resolveAuthMode(),
    pool: poolState.pool,
  };
  if (poolState.edge_unreachable) {
    status.edge_unreachable = true;
    status.hint = 'edge_unreachable';
  }

  if (status.auth_mode === 'keycloak' && process.env.KEYCLOAK_ISSUER_BASE_URL) {
    const reachable = await probeKeycloakDiscovery();
    status.keycloak = reachable ? 'ok' : 'unreachable';
  }

  // NOTE: derive edge field from the cached pool-state rather than issuing a
  // second uncached probe. A second probe per /health request would double the
  // latency when edge is slow/down, potentially tripping k8s readiness
  // timeouts even though the body is fail-open.
  status.edge = poolState.edge_unreachable ? 'unreachable' : 'ok';

  res.json(status);
});

/**
 * @openapi
 * /api/setup:
 *   post:
 *     summary: First-run setup (create admin)
 *     tags: [Setup]
 *     responses: { 200: { description: Setup complete } }
 * /api/setup/status:
 *   get:
 *     summary: Get setup status
 *     tags: [Setup]
 *     responses: { 200: { description: Setup state, content: { application/json: { schema: { $ref: '#/components/schemas/ApiResponse' } } } } }
 * /api/setup/configure-db:
 *   post:
 *     summary: Configure database connection
 *     tags: [Setup]
 *     responses: { 200: { description: DB configured } }
 * /api/setup/init-db:
 *   post:
 *     summary: Initialize database schema
 *     tags: [Setup]
 *     responses: { 200: { description: Schema initialized } }
 * /api/setup/seed:
 *   post:
 *     summary: Import seed data (SQL)
 *     tags: [Setup]
 *     requestBody:
 *       content: { application/json: { schema: { type: object, properties: { sql: { type: string } } } } }
 *     responses: { 200: { description: Seed imported } }
 * /api/setup/create-admin:
 *   post:
 *     summary: Create admin user
 *     tags: [Setup]
 *     responses: { 200: { description: Admin created } }
 * /api/setup/reset-config:
 *   post:
 *     summary: Reset DB configuration
 *     tags: [Setup]
 *     responses: { 200: { description: Config reset } }
 */

// ── Graceful shutdown ────────────────────────────────────────────────────────
const PORT = process.env.PORT || 3200;

async function gracefulShutdown(signal) {
  logger.info({ signal }, 'shutdown signal received');
  stopKeycloakHealthProbe();
  process.exit(0);
}

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

// ── Boot async sequence ─────────────────────────────────────────────────────
// NOTE: no `initializeFromConfig().then(...)` wrap. infra `app.listen()` runs
// immediately at boot; edge readiness is NOT a precondition. We DO try
// `fetchAuthMode()` from edge first so the DB-backed `system_settings.auth_mode`
// (admin's persisted choice) wins over the env-discovery fallback before
// keycloak-oidc middleware mounts. Falling back to `detectAuthMode(null, null)`
// when edge is unreachable keeps the cold-boot scenario working.
let keycloakMiddleware = [];
const BOOT_EDGE_AUTH_MODE_TIMEOUT_MS = 1500;

async function resolveBootAuthMode() {
  try {
    const edgeMode = await fetchAuthMode(null, { timeoutMs: BOOT_EDGE_AUTH_MODE_TIMEOUT_MS });
    if (edgeMode && (edgeMode.auth_mode === 'keycloak' || edgeMode.auth_mode === 'local')) {
      await setResolvedAuthMode(edgeMode.auth_mode, edgeMode.source || 'edge_boot');
      logger.info({ mode: edgeMode.auth_mode, source: edgeMode.source }, 'auth_mode resolved from edge at boot');
      return;
    }
  } catch (err) {
    if (err instanceof EdgeUnreachable || err instanceof EdgeTimeout || err instanceof EdgeAuthFailed) {
      logger.warn({ err: err.message, code: err.code }, 'edge unreachable for auth_mode at boot — falling back to env detect');
    } else {
      logger.warn({ err }, 'edge auth_mode fetch failed at boot — falling back to env detect');
    }
  }
  // Fallback: env / KC-discovery (no DB).
  try {
    await detectAuthMode(null, null);
  } catch (err) {
    logger.warn({ err }, 'detectAuthMode at boot fallback failed — staying on default local');
  }
}

async function bootstrap() {
  await resolveBootAuthMode();

  // Seed the rate-limit snapshot once so the first requests use DB values when
  // edge is up. Non-fatal: on failure limiters fall back to env/default and the
  // per-request refresh tick retries (infra never blocks on edge at boot).
  await seedRateLimitCache();

  startKeycloakHealthProbe();

  // ── Security rate limiting (before auth) ─────────────────────────────────
  mountPreAuthLimiters(app);

  // ── Middleware ordering: keycloak-oidc → auth → access-check → routes ─────
  keycloakMiddleware = getKeycloakMiddleware();
  keycloakMiddleware.forEach(mw => app.use(mw));

  app.use(require('./infra/middleware/auth'));

  // Must run immediately after auth so req.impersonator is already set.
  // Blocks every non-read /api/* request when the session is in impersonation
  // mode — before the request can reach setup-forwarding or the pool gate.
  const { impersonationReadOnly } = require('./infra/middleware/impersonation-readonly');
  app.use(impersonationReadOnly);

  // Public Integration API documentation portal (/api/public-docs). Mounted
  // HERE — after auth (so req.user is populated) but BEFORE the pool-gate and
  // the Keycloak RBAC access-check below — so the docs are reachable by any
  // logged-in human without a ready pool or an allowlist entry. Machine
  // principals never populate req.user, so they get the same 401 as anonymous
  // callers. The Scalar bundle assets are already served (ungated) from
  // app-setup's createScalarStaticRouter mount.
  require('./infra/routes/public-docs').mountPublicDocs(app);

  // Internal (infra) OpenAPI spec — an operator surface, gated to a logged-in
  // human with the same req.user-only model as the portal (a machine principal
  // gets 401). Mounted here for the identical after-auth / before-pool-gate
  // order so the raw spec stays reachable without a ready pool.
  require('./infra/routes/internal-spec').mountInternalSpec(app);

  // ── Auth-aware rate limiting (after auth) ────────────────────────────────
  mountAuthenticatedLimiters(app);

  // Setup forwarding — after auth middleware so req.user is populated from
  // Keycloak OIDC session (needed for S2S headers). Must be before pool
  // readiness gate since setup routes work without DB.
  app.use('/api/setup', createForwardingProxy('/edge/platform/setup'));

  mountSandboxDocument(app, DIST_PATH);
  mountStatic(app, DIST_PATH);

  // NOTE: X-Database middleware — pool-state and DB config are no longer
  // locally accessible in infra; edge gates the X-Database header at
  // /edge/platform/* boundary. Infra forwards the header; edge enforces the
  // match. The defense-in-depth check lives on edge.

  // Pool readiness gate
  app.use(async (req, res, next) => {
  if (!req.path.startsWith('/api/')) return next();
  // Public Integration API is gated by machine token + scope, NOT the human
  // pool/RBAC gates. Edge remains authoritative for its own pool readiness on
  // the S2S hop (surfaced to the client as edge_unreachable). [H1]
  // isPublicApiPath is segment-bounded so /api/public/v1xyz cannot inherit it.
  if (isPublicApiPath(req.path)) return next();
  if (req.path.startsWith('/api/setup') || req.path === '/health') return next();
  if (req.path === '/api/auth/mode' || req.path === '/api/auth/sso-login' ||
      req.path === '/api/auth/callback' || req.path === '/api/auth/logout' ||
      req.path === '/api/auth/me' || req.path === '/api/auth/diagnostics') return next();
  if (req.path === '/api/system-settings/public') return next();
  if (req.method === 'POST' && req.path === '/api/db-connections/test') return next();
  if (PER_REQUEST_PATHS.some(p => req.path.startsWith(p)) && req.body?.db) return next();

  let poolState;
  try {
    poolState = await getCachedPoolState();
  } catch (err) {
    logger.error({ err }, 'pool-state fetch failed unexpectedly');
    const e = apiError('Edge unreachable', 'EDGE_UNREACHABLE', 503, {
      details: { hint_code: 'edge_unreachable' },
    });
    return res.status(e.status).json(e.body);
  }
  if (poolState.edge_unreachable) {
    const e = apiError('Edge unreachable. Try again shortly.', 'EDGE_UNREACHABLE', 503, {
      details: { hint_code: 'edge_unreachable' },
    });
    return res.status(e.status).json(e.body);
  }
  if (!poolState.ready) {
    const e = apiError(
      'Database not configured. Please complete setup first.',
      'DB_NOT_CONFIGURED',
      503,
      { details: { hint_code: poolState.pool?.hint_code || null, pool_state: poolState.pool?.pool_state || null } }
    );
    return res.status(e.status).json(e.body);
  }
  next();
});

  // Access check middleware
  app.use(async (req, res, next) => {
    if (!req.path.startsWith('/api/') || req.path === '/health') return next();
    // Public Integration API is exempt from the human Keycloak RBAC allowlist —
    // gated solely by machine token + scope. [H1] isPublicApiPath is
    // segment-bounded so /api/public/v1xyz cannot inherit the exemption.
    if (isPublicApiPath(req.path)) return next();
    if (req.path.startsWith('/api/setup') || req.path === '/api/auth/mode' ||
        req.path === '/api/auth/sso-login' || req.path === '/api/auth/callback' ||
        req.path === '/api/auth/logout' || req.path === '/api/auth/me' ||
        req.path === '/api/auth/diagnostics' ||
        req.path === '/api/system-settings/public') return next();
    // Pool readiness was already enforced upstream. If we got here, edge is
    // reachable and pool is ready.
    return accessCheckMiddleware(req, res, next);
  });

  // ── Routes ────────────────────────────────────────────────────────────────
  // Ordering contract (load-bearing — do not reorder):
  //   1. mountAuthForwarding   — specific auth paths forwarded to edge
  //   2. authSessionRoutes     — infra-local auth (/me, GET /mode, /diagnostics)
  //   3. mountRemainingRoutes  — audit catch-all + all non-auth forwarding
  //
  // Public Integration API namespace — the Bearer gate runs BEFORE body parsing +
  // the content-type check (P2b): the global express.json + CSRF guard SKIP this
  // namespace (app-setup), so an unauthenticated caller can never distinguish
  // states via a pre-auth parse/415 error — the gate 401s first. Full pipeline
  // (gate → limiter → content-type → json → write → read → error) lives in
  // mountPublicNamespace so its load-bearing ordering is a single source of truth.
  require('./infra/routes/public-namespace').mountPublicNamespace(app);

  mountAuthForwarding(app);
  app.use('/api/auth', authSessionRoutes);
  mountRemainingRoutes(app);

  // ── Centralized error handler ─────────────────────────────────────────────
  app.use((err, _req, res, _next) => {
    const status = err.status || err.statusCode || 500;
    const code = err.code || 'INTERNAL_ERROR';
    const message = status === 500 ? 'Internal server error' : (err.message || 'Unknown error');

    logger.error({ err, code }, err.message);

    const errResp = apiError(message, code, status, { cause: err });
    res.status(errResp.status).json(errResp.body);
  });

  // SPA fallback (must be last)
  mountSpaFallback(app, DIST_PATH);

  // ── Start server ──────────────────────────────────────────────────────────
  const { server, useHttps } = createServer(app);

  server.listen(PORT, async () => {
    const authMode = resolveAuthMode();
    const { getAuthModeSource } = require('./shared/config');
    const kcOidcActive = keycloakMiddleware.length > 0;

    const middlewareList = ['helmet', 'cors', 'json',
      kcOidcActive ? 'keycloak-oidc=ACTIVE' : 'keycloak-oidc=OFF',
      'auth', 'pool-gate', 'access-check'].join(', ');
    const routeList = ['/api/auth', '/api/setup', '/api/users', '/api/system-settings',
      '/api/db-connections', '/api/query-proxy', '/api/schema', '/api/sync-schema',
      '/api/export', '/api/transformers', '/api/access-rules'].join(', ');

    // NOTE: DB summary line omitted from boot banner — infra no longer has
    // direct visibility into pool config. Operators can hit /health (which calls
    // edge S2S) for the live snapshot, or check edge's own boot banner.
    const kcReachable =
      authMode === 'keycloak' ? await probeKeycloakDiscovery() : null;
    try {
      printBootBanner({
        role: 'INFRA',
        port: PORT,
        logger,
        depsSummary: [
          `Auth: ${authMode} (source=${getAuthModeSource()})`,
          ...(authMode === 'keycloak'
            ? [`Keycloak: ${kcReachable ? 'reachable' : 'UNREACHABLE'} (${process.env.KEYCLOAK_ISSUER_BASE_URL || 'not set'})`]
            : []),
          `JWT: ${process.env.JWT_SECRET ? 'configured' : 'not set'}`,
          `Edge: ${process.env.EDGE_API_URL || 'http://api-edge:3201'}`,
          `TLS: ${useHttps ? 'https' : 'http'}`,
        ],
      });
    } catch (err) {
      logger.error(
        { err: err.message },
        'boot banner failed — check APP_NAME / BASE_URL / FRONTEND_URL env',
      );
      throw err;
    }
    logger.info(`Middleware: ${middlewareList}`);
    logger.info(`Routes: ${routeList}`);
    logger.info({ port: PORT, protocol: useHttps ? 'https' : 'http', auth: authMode }, 'API-infra listening');
  });
}

// Only run bootstrap when this file is the entry point (not during test require).
// Production paths: (a) `node src/index-infra.js` direct, (b) dispatched by
// index.js for API_ROLE=infra or unset. Tests load the file via require with
// API_ROLE=test or unset+process.argv pointing elsewhere — handled by the
// require.main check or the explicit SUPPRESS_BOOT env var.
const role = (process.env.API_ROLE || '').toLowerCase();
const isDispatched = role === 'infra' || (role === '' && require.main && require.main.filename && require.main.filename.endsWith('index.js'));
if (process.env.SUPPRESS_INFRA_BOOT !== '1' && (require.main === module || isDispatched)) {
  bootstrap().catch((err) => {
    logger.fatal({ err }, 'API-infra boot failed');
    process.exit(1);
  });
}

// Test hooks
module.exports = {
  _invalidatePoolStateCache: invalidatePoolStateCache,
  getCachedPoolState,
  bootstrap,
};
