/**
 * index.js — Entry point dispatcher.
 *
 * Routes to the correct entry point based on API_ROLE env var:
 *   - API_ROLE=edge     → index-edge.js (DB-facing, port 3201)
 *   - API_ROLE=infra    → index-infra.js (API, port 3200)
 *   - API_ROLE=frontend → index-frontend.js (static + /config.js, port 3000)
 *   - (unset)           → index-infra.js (backward compatible default)
 *
 * This file replaces the monolithic server with role-based dispatch.
 * Zod config validation runs before role dispatch. Fails with a
 *   human-readable error and exit(1) on misconfiguration, preventing
 *   CrashLoopBackOff in k8s. Set SKIP_CONFIG_VALIDATION=1 to bypass.
 */
// Load .env BEFORE validation — dotenv must populate process.env before
// Zod checks required vars like S2S_API_KEY. index-edge.js / index-infra.js
// also call dotenv.config() but that is idempotent (dotenv skips already-set vars).
require('dotenv').config();

const role = (process.env.API_ROLE || 'infra').toLowerCase();

// ── Config validation ───────────────────────────────────────────────
const { validateConfig } = require('./shared/config-schema');
const result = validateConfig(role);

if (!result.ok) {
  // Print to stderr so k8s logs capture it; exit 1 so the pod doesn't
  // restart in an infinite CrashLoopBackOff.
  process.stderr.write(result.error + '\n');
  // NOTE: emit the env snapshot on the fail path so operators can
  // distinguish between a schema bug and a stale ConfigMap without
  // shelling into the pod. `fail` phase includes redacted values;
  // sensitive keys are fully masked inside env-snapshot.
  try {
    const { printEnvSnapshot } = require('./shared/lib/env-snapshot');
    printEnvSnapshot(
      { info: (m) => process.stderr.write(m + '\n'), warn: () => {}, error: () => {} },
      { phase: 'fail' },
    );
  } catch (err) {
    process.stderr.write(`[env-snapshot] failed to emit: ${err.message}\n`);
  }
  process.exit(1);
}
// ─────────────────────────────────────────────────────────────────────

if (role === 'edge') {
  require('./index-edge');
} else if (role === 'frontend') {
  require('./index-frontend');
} else {
  require('./index-infra');
}
