# MariaDB Custom API Backend

Node.js/Express REST API used by ONPREM and AIRGAP deployments. Since v2.0.0
the service runs in a dual-process layout: **API-infra** (frontend-facing,
port 3200) handles authentication and forwards DB-dependent requests to
**API-edge** (DB-facing, port 3201). A single image with the `API_ROLE`
env var selects the entry point.

## Quick Start

```bash
# Start MariaDB + API with Docker Compose
docker compose up -d

# Or run locally
cp .env.example .env
npm install
npm run dev
```

For E2E debug loops, set `DISABLE_RATE_LIMIT=true` in `.env` to turn every
rate limiter in `index-infra.js` into a pass-through. Production deployments
must leave the flag unset — the server logs a startup warning when the
bypass is active.

## Directory Layout (post v2.1.0 cleanup)

```
src/
├── index.js              dispatcher — reads API_ROLE, delegates to infra or edge
├── index-infra.js        API-infra entry (auth, forwarding, static SPA)
├── index-edge.js         API-edge entry (S2S verify + direct DB)
├── shared/               both sides: config, helpers, logger, crypto,
│                         password-validator, platform-tables.json
│                         security, sql-utils, error-hints
├── infra/
│   ├── middleware/auth.js       JWT / OIDC identity resolution (real impl)
│   └── lib/remote-client.js     circuit-breaker-backed edge forwarder
│   ├── middleware/
│   │   ├── keycloak-oidc.js     OIDC middleware (canonical location since v3.0.0)
│   │   ├── auth.js              JWT / cookie identity resolution
│   │   └── access-check.js      S2S access check to edge
└── edge/
    ├── db.js                    pool + dynamic-pool + config persistence
    ├── table-ddls.js            CREATE TABLE IF NOT EXISTS DDL builders
    ├── sql-utils.js             splitSqlStatements for seed allowlist
    ├── middleware/s2s-verify.js strip→verify→reconstruct X-Forwarded-User
    └── routes/
        ├── platform/
        │   ├── audit.js         login audit tail
        │   ├── auth-sessions.js Recent Logins pagination
        │   ├── connections.js   stored DB connection profiles
        │   ├── export.js        GET /mariadb-sql — engine table export
        │   ├── query.js         admin query-proxy
        │   ├── settings.js      system_settings CRUD
        │   ├── users.js         user management + validatePassword
        │   ├── access-rules.js  RBAC rules
        │   └── setup/           ← PR 3b split from 1209-line setup.js
        │       ├── _shared.js       SYSTEM_DBS + resolveSetupUser helper
        │       ├── index.js         router assembly + /status + OpenAPI block
        │       ├── create-admin.js  POST /
        │       ├── db-connect.js    POST /test-db, /configure-db, GET /db-status
        │       ├── schema-init.js   POST /init-db, /create-schema, GET /schemas
        │       │                    + the depid→deptid / keycloak_sub migrations
        │       ├── seed-data.js     POST /seed — INSERT/REPLACE allowlist,
        │       │                    /*! */ conditional-comment smuggling block
        │       ├── reset.js         POST /reset-config (zero-admin escape hatch)
        │       └── tables.js        /table-status, /truncate-table, /drop-table
        └── app/
            ├── schema.js        generic engine-table CRUD
            ├── sync-schema.js   cloud→mariadb data sync + SQL export/import
            └── transformers/    ← PR 3b split from 1024-line transformers.js
                ├── _shared.js     MAX_CODE_SIZE constant
                ├── index.js       router assembly + OpenAPI block
                ├── crud.js        list, active, get, create, update, delete,
                │                  toggle-active (GET /active MUST stay before
                │                  GET /:id in registration order — Express)
                ├── versions.js    /versions, /versions/:versionId, /rollback/:ver
                └── io.js          /import, /export, /clone
```

Each `setup/*.js` and `transformers/*.js` sub-file exports
`module.exports = function register(router)` and mutates the shared Router
passed in by its `index.js`. No nested `Router.use()` mounts — the public
URL surface is byte-for-byte identical to the pre-split files, so existing
clients and the PR 3a safety net (`e2e/setup-api.spec.ts`) see no change.

Legacy `docker-api/src/routes/platform/` still holds Q3-deferred `auth.js`
and `access-rules.js`. These move to edge in PR-C1 (T1 auth dual-live split).
`db-connections.js`, `query-proxy.js`, `system-settings.js` were deleted in
v3.0.0-alpha.2 — their edge equivalents handle all traffic via S2S forwarding.

## Endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/auth/me` | Current user info |
| GET | `/api/auth/:id/is-admin` | Check admin status |
| POST | `/api/auth/login` | Login (JWT) |
| GET | `/api/system-settings` | List all settings |
| PUT | `/api/system-settings` | Upsert settings (admin) |
| GET | `/api/db-connections` | List connections (admin) |
| GET | `/api/db-connections/:id` | Get connection (admin) |
| POST | `/api/db-connections` | Create connection (admin) |
| PUT | `/api/db-connections/:id` | Update connection (admin) |
| DELETE | `/api/db-connections/:id` | Delete connection (admin) |
| POST | `/api/db-connections/:id/activate` | Activate (admin) |
| POST | `/api/db-connections/deactivate-all` | Deactivate all (admin) |
| GET | `/api/users` | List users (admin) |
| POST | `/api/users` | Create user (admin) |
| POST | `/api/users/:id/ban` | Ban/unban (admin) |
| PUT | `/api/users/:id/role` | Update role (admin) |
| GET | `/api/transformers` | List transformers (admin) |
| GET | `/api/transformers/active` | Active transformers with code (auth) |
| GET | `/api/transformers/:id` | Get transformer (admin) |
| POST | `/api/transformers` | Create transformer (admin) |
| PUT | `/api/transformers/:id` | Update + auto-version (admin) |
| DELETE | `/api/transformers/:id` | Soft/hard delete (admin) |
| PUT | `/api/transformers/:id/toggle-active` | Toggle active (admin) |
| GET | `/api/transformers/:id/versions` | Version history (admin) |
| PUT | `/api/transformers/:id/rollback/:ver` | Rollback to version (admin) |
| POST | `/api/transformers/import` | Import from JSON (admin) |
| GET | `/api/transformers/:id/export` | Export as JSON (admin) |
| POST | `/api/transformers/:id/clone` | Clone transformer (admin) |

## Auth Modes

1. **Local JWT** — `POST /api/auth/login` returns a Bearer token.
2. **Keycloak OIDC** — Session-based auth via express-openid-connect.

`AUTH_MODE_OVERRIDE=local|keycloak` in `.env` pins the mode for emergencies;
otherwise the server auto-detects based on whether `KEYCLOAK_ISSUER_BASE_URL`
is reachable at boot.

## Response Envelope (v2.1.0 Q14 MF4)

Every handler returns through `apiOk(data, meta?)` or `apiError(message, code,
status, { cause? })` from `shared/helpers.js`:

```json
{ "data": ..., "error": null, "meta": { "timestamp": "...", "db_type": "MARIADB", "provider": "CUSTOM_API" } }
{ "data": null, "error": { "message": "...", "code": "DUPLICATE_KEY", "status": 409 }, "meta": {...} }
```

- **Debug payload gating** — Stack traces and raw SQL driver codes are
  included only when `DEBUG_API=true`, regardless of `NODE_ENV`. Staging /
  preview deployments with `NODE_ENV=development` are safe by default.
- **SQL code whitelist** — Raw MariaDB driver codes never reach the wire.
  `mapSqlErrorCode()` translates them: `ER_DUP_ENTRY → DUPLICATE_KEY`,
  `ER_LOCK_DEADLOCK → DB_DEADLOCK`, `ER_NO_REFERENCED_ROW_2 →
  FOREIGN_KEY_MISSING`, plus a dozen more. When a handler uses the default
  `ERROR` / `DB_ERROR` sentinel and passes `options.cause`, the mapped
  semantic code is promoted automatically. Override by passing an explicit
  code (e.g. `apiError('email taken', 'USER_EMAIL_EXISTS', 409, { cause })`).

## Usage with Frontend

In the app, create a **Custom API** connection profile pointing to
`https://localhost:3200`. Every Express call from the frontend goes through
`platformFetch` in `src/platform/lib/http-client.ts`, which centralises
cookie credentials, header injection, and envelope unwrap. See
`src/platform/PLATFORM_GUIDE.md` for the client API reference.
