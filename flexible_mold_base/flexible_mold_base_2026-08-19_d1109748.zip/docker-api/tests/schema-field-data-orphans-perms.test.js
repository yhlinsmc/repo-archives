/**
 * schema-field-data-orphans-perms.test.js
 *
 * Permission widening for the field-data-orphans endpoints:
 *   POST /field-data-orphans (scan) and
 *   DELETE /field-data-orphans/:templateId/:key (clear, both kinds)
 * are widened from admin-only to admin + blueprint owner (editor), scoped
 * by blueprint ownership.
 *
 *   - SCAN: admin sees every residual; an editor sees ONLY rows whose
 *     template blueprint owner_id is theirs (req.user.id) OR NULL (shared).
 *     The internal scoping field blueprint_owner_id MUST NOT leak to the
 *     client response.
 *   - CLEAR (both branches): before mutating, an editor's ownership of the
 *     target template's blueprint is re-verified in the same connection /
 *     transaction; a non-owner editor gets 404 NOT_FOUND (existence is not
 *     disclosed) and the value is preserved (no UPDATE runs).
 *   - Admin is unaffected: sees all, clears any.
 *
 * Harness: mirrors tests/schema-field-data-orphans-delete.test.js — a real
 * express app + node http client, with the edge `db` module replaced in
 * require.cache by a scripted mock connection. A mutable `currentUser` lets
 * each test drive the auth middleware as admin or a specific editor.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../src/edge/db');

let conn;
let currentUser;

function makeConn(scripts) {
  let inTx = false;
  let rolledBack = false;
  let committed = false;
  const queries = [];
  return {
    queries,
    rolledBack: () => rolledBack,
    committed: () => committed,
    inTx: () => inTx,
    async beginTransaction() { inTx = true; },
    async commit() { committed = true; inTx = false; },
    async rollback() { rolledBack = true; inTx = false; },
    async query(sql, params) {
      queries.push({ sql, params });
      for (const [matcher, response] of scripts) {
        if (matcher.test(sql)) {
          if (response instanceof Error) throw response;
          return typeof response === 'function' ? response(sql, params) : response;
        }
      }
      throw new Error(`Unmatched query: ${sql.slice(0, 80)}`);
    },
    release() { /* noop */ },
  };
}

const poolSpy = {
  rw: { async getConnection() { return conn; } },
  ro: { async getConnection() { return conn; } },
};

require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: {
    pool: poolSpy,
    t: (name) => `fmb_${name}`,
    getDynamicPool: async () => poolSpy,
  },
};

const schemaRouter = require('../src/edge/routes/app/schema');

let server;
let port;

before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { req.user = currentUser; next(); });
  app.use('/edge/app/schema', schemaRouter);
  await new Promise((resolve) => {
    server = app.listen(0, '127.0.0.1', () => {
      port = server.address().port;
      resolve();
    });
  });
});

after(async () => {
  await new Promise((resolve) => server.close(resolve));
  delete require.cache[dbKey];
});

beforeEach(() => { conn = null; currentUser = { id: 'admin-1', role: 'admin' }; });

function request(method, path, body) {
  return new Promise((resolve, reject) => {
    const payload = body === undefined ? undefined : JSON.stringify(body);
    const req = http.request({
      method,
      host: '127.0.0.1',
      port,
      path,
      headers: payload ? { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) } : {},
    }, (res) => {
      let raw = '';
      res.on('data', (chunk) => { raw += chunk; });
      res.on('end', () => resolve({ status: res.statusCode, body: raw ? JSON.parse(raw) : null }));
    });
    req.on('error', reject);
    if (payload) req.write(payload);
    req.end();
  });
}
const post = (path, body) => request('POST', path, body);
const del = (path) => request('DELETE', path);

// Scan: fields query (empty → every payload key is an orphan) + templates query.
const RX_FIELDS = /SELECT blueprint_id, field_key, field_type/i;
// Pin the EFFECTIVE-blueprint owner column (ehn.*): a revert to the direct
// hn.owner_id would silently pass a looser match and reintroduce the linked
// cross-owner leak, so match the exact effective-join column.
const RX_SCAN_TEMPLATES = /ehn\.owner_id AS blueprint_owner_id/i;
// Ownership pre-check helper (editorOwnsTemplateBlueprint). Now also selects
// ehn.id AS ebp_id to distinguish "dangling effective blueprint" (fail closed)
// from a genuinely shared (owner NULL) blueprint.
const RX_OWNER = /ehn\.owner_id AS owner_id/i;
// Mismatch re-validation SELECT + its JSON_REMOVE UPDATE.
// The re-check reads the payload DOCUMENT and indexes it in JavaScript, the way
// the scanner does, so these fixtures state what the ROW HOLDS rather than what
// an extraction returned. `payload` is a hydrated object because that is what
// this driver hands back for a JSON column — and stating it as pre-extracted
// JSON text is precisely what let the double answer for an extraction the
// deployed driver never performs: a stored string arrived as a JavaScript
// string, the `JSON.parse` in front of the shape check threw on it, and this
// suite was green throughout. The instrument that settles it is
// tests/integration/destructive-gates-real-db.test.js.
const RX_REVAL = /SELECT bf\.field_type AS ft/i;
const RX_UPDATE_MISMATCH = /UPDATE `fmb_user_templates` SET payload = JSON_REMOVE\(payload/i;
// Legacy orphan single-statement path.
const RX_ORPHAN = /NOT EXISTS/i;

// effective_bp_row_id is the ehn.id from the effective-blueprint join — non-null
// here (blueprint row present). A NULL would mean a dangling effective blueprint
// (fail closed for editors), covered by a dedicated case below.
const SCAN_TEMPLATES = [
  { id: 'tMine', name: 'Mine', blueprint_id: 'bpMine', effective_blueprint_id: 'bpMine', effective_bp_row_id: 'bpMine', blueprint_owner_id: 'ed1', payload: JSON.stringify({ colors: 'x' }) },
  { id: 'tShared', name: 'Shared', blueprint_id: 'bpShared', effective_blueprint_id: 'bpShared', effective_bp_row_id: 'bpShared', blueprint_owner_id: null, payload: JSON.stringify({ colors: 'x' }) },
  { id: 'tOther', name: 'Other', blueprint_id: 'bpOther', effective_blueprint_id: 'bpOther', effective_bp_row_id: 'bpOther', blueprint_owner_id: 'ed2', payload: JSON.stringify({ colors: 'x' }) },
];

function scanScripts() {
  return [
    [RX_FIELDS, []],
    [RX_SCAN_TEMPLATES, SCAN_TEMPLATES],
  ];
}

describe('POST /field-data-orphans (scan) — ownership scoping', () => {
  it('editor scan returns only owned + shared blueprint rows, excludes other-owner', async () => {
    conn = makeConn(scanScripts());
    currentUser = { id: 'ed1', role: 'editor' };
    const res = await post('/edge/app/schema/field-data-orphans', {});
    assert.equal(res.status, 200);
    const bps = new Set(res.body.data.orphans.map((o) => o.blueprint_id));
    assert.ok(bps.has('bpMine'), 'owned blueprint row present');
    assert.ok(bps.has('bpShared'), 'shared (owner NULL) blueprint row present');
    assert.ok(!bps.has('bpOther'), 'other-owner blueprint row excluded');
    assert.equal(res.body.data.total, 2);
  });

  it('admin scan returns every row (unaffected)', async () => {
    conn = makeConn(scanScripts());
    currentUser = { id: 'admin-1', role: 'admin' };
    const res = await post('/edge/app/schema/field-data-orphans', {});
    assert.equal(res.status, 200);
    const bps = new Set(res.body.data.orphans.map((o) => o.blueprint_id));
    assert.ok(bps.has('bpMine') && bps.has('bpShared') && bps.has('bpOther'));
    assert.equal(res.body.data.total, 3);
  });

  it('editor scan excludes a dangling effective blueprint (ebp_id NULL) but admin sees it', async () => {
    const dangling = [
      { id: 'tGone', name: 'Gone', blueprint_id: 'bpGone', effective_blueprint_id: 'bpGone', effective_bp_row_id: null, blueprint_owner_id: null, payload: JSON.stringify({ colors: 'x' }) },
    ];
    conn = makeConn([[RX_FIELDS, []], [RX_SCAN_TEMPLATES, dangling]]);
    currentUser = { id: 'ed1', role: 'editor' };
    const editorRes = await post('/edge/app/schema/field-data-orphans', {});
    assert.equal(editorRes.status, 200);
    assert.equal(editorRes.body.data.total, 0, 'editor must not see a dangling-blueprint row');

    conn = makeConn([[RX_FIELDS, []], [RX_SCAN_TEMPLATES, dangling]]);
    currentUser = { id: 'admin-1', role: 'admin' };
    const adminRes = await post('/edge/app/schema/field-data-orphans', {});
    assert.equal(adminRes.status, 200);
    assert.equal(adminRes.body.data.total, 1, 'admin still sees the dangling-blueprint row');
    assert.ok(!JSON.stringify(adminRes.body).includes('effective_bp_row_id'), 'internal scoping field must not leak');
  });

  it('never leaks blueprint_owner_id in the scan response', async () => {
    conn = makeConn(scanScripts());
    currentUser = { id: 'admin-1', role: 'admin' };
    const res = await post('/edge/app/schema/field-data-orphans', {});
    assert.equal(res.status, 200);
    for (const o of res.body.data.orphans) {
      assert.ok(!('blueprint_owner_id' in o), 'blueprint_owner_id must be stripped from response rows');
    }
    // Also assert it is not present anywhere in the raw serialized payload.
    assert.ok(!JSON.stringify(res.body).includes('blueprint_owner_id'), 'owner id must not appear in the response at all');
  });

  it('plain user is still forbidden from scanning', async () => {
    conn = makeConn(scanScripts());
    currentUser = { id: 'u1', role: 'user' };
    const res = await post('/edge/app/schema/field-data-orphans', {});
    assert.equal(res.status, 403);
  });
});

describe('DELETE /field-data-orphans — ownership scoping (clear)', () => {
  it('editor cannot clear a type_mismatch under a blueprint they do not own → 404, value preserved', async () => {
    conn = makeConn([
      [RX_OWNER, [{ ebp_id: 'bpOther', owner_id: 'ed2' }]],
      [RX_REVAL, [{ ft: 'text', payload: { colors: '["a","b"]' } }]],
      [RX_UPDATE_MISMATCH, { affectedRows: 1 }],
    ]);
    currentUser = { id: 'ed1', role: 'editor' };
    const res = await del('/edge/app/schema/field-data-orphans/tOther/colors?kind=type_mismatch');
    assert.equal(res.status, 404);
    assert.equal(res.body.error.code, 'NOT_FOUND');
    assert.equal(conn.rolledBack(), true, 'transaction rolled back');
    assert.equal(conn.committed(), false);
    assert.ok(!conn.queries.some((q) => RX_UPDATE_MISMATCH.test(q.sql)), 'JSON_REMOVE must NOT run — value preserved');
  });

  it('editor cannot clear under a dangling effective blueprint (ebp_id NULL) → 404, value preserved', async () => {
    // A NULL owner from a MISSING effective-blueprint row only LOOKS shared;
    // fail closed for the editor.
    conn = makeConn([
      [RX_OWNER, [{ ebp_id: null, owner_id: null }]],
      [RX_REVAL, [{ ft: 'text', payload: { colors: '["a","b"]' } }]],
      [RX_UPDATE_MISMATCH, { affectedRows: 1 }],
    ]);
    currentUser = { id: 'ed1', role: 'editor' };
    const res = await del('/edge/app/schema/field-data-orphans/tGone/colors?kind=type_mismatch');
    assert.equal(res.status, 404);
    assert.equal(res.body.error.code, 'NOT_FOUND');
    assert.ok(!conn.queries.some((q) => RX_UPDATE_MISMATCH.test(q.sql)), 'JSON_REMOVE must NOT run — value preserved');
  });

  it('editor cannot clear an orphan under a blueprint they do not own → 404, value preserved', async () => {
    conn = makeConn([
      [RX_OWNER, [{ ebp_id: 'bpOther', owner_id: 'ed2' }]],
      [RX_ORPHAN, { affectedRows: 1 }],
    ]);
    currentUser = { id: 'ed1', role: 'editor' };
    const res = await del('/edge/app/schema/field-data-orphans/tOther/legacyKey');
    assert.equal(res.status, 404);
    assert.equal(res.body.error.code, 'NOT_FOUND');
    assert.ok(!conn.queries.some((q) => RX_ORPHAN.test(q.sql)), 'orphan UPDATE must NOT run — value preserved');
  });

  it('editor CAN clear a type_mismatch under a blueprint they own', async () => {
    conn = makeConn([
      [RX_OWNER, [{ ebp_id: 'bpMine', owner_id: 'ed1' }]],
      // composite field (checkbox) holding a non-array scalar = real residual
      [RX_REVAL, [{ ft: 'checkbox', payload: { colors: 'a' } }]],
      [RX_UPDATE_MISMATCH, { affectedRows: 1 }],
    ]);
    currentUser = { id: 'ed1', role: 'editor' };
    const res = await del('/edge/app/schema/field-data-orphans/tMine/colors?kind=type_mismatch');
    assert.equal(res.status, 200);
    assert.equal(res.body.data.removed_key, 'colors');
    assert.equal(conn.committed(), true);
  });

  it('editor CAN clear a type_mismatch under a shared (owner NULL, ebp row present) blueprint', async () => {
    conn = makeConn([
      [RX_OWNER, [{ ebp_id: 'bpShared', owner_id: null }]],
      [RX_REVAL, [{ ft: 'checkbox', payload: { colors: 'a' } }]],
      [RX_UPDATE_MISMATCH, { affectedRows: 1 }],
    ]);
    currentUser = { id: 'ed1', role: 'editor' };
    const res = await del('/edge/app/schema/field-data-orphans/tShared/colors?kind=type_mismatch');
    assert.equal(res.status, 200);
    assert.equal(conn.committed(), true);
  });

  it('admin can clear a type_mismatch under any blueprint (unaffected)', async () => {
    conn = makeConn([
      // Admin short-circuits ownership (no RX_OWNER script needed); if it ran
      // the mock would still allow it, but it must not gate on ownership.
      [RX_REVAL, [{ ft: 'checkbox', payload: { colors: 'a' } }]],
      [RX_UPDATE_MISMATCH, { affectedRows: 1 }],
    ]);
    currentUser = { id: 'admin-1', role: 'admin' };
    const res = await del('/edge/app/schema/field-data-orphans/tOther/colors?kind=type_mismatch');
    assert.equal(res.status, 200);
    assert.equal(conn.committed(), true);
    assert.ok(!conn.queries.some((q) => RX_OWNER.test(q.sql)), 'admin must not run the editor ownership pre-check');
  });

  it('admin can clear an orphan under any blueprint (unaffected)', async () => {
    conn = makeConn([
      [RX_ORPHAN, { affectedRows: 1 }],
    ]);
    currentUser = { id: 'admin-1', role: 'admin' };
    const res = await del('/edge/app/schema/field-data-orphans/tOther/legacyKey');
    assert.equal(res.status, 200);
    assert.equal(res.body.data.removed_key, 'legacyKey');
    assert.ok(!conn.queries.some((q) => RX_OWNER.test(q.sql)), 'admin must not run the editor ownership pre-check');
  });

  it('plain user is still forbidden from clearing', async () => {
    conn = makeConn([[RX_ORPHAN, { affectedRows: 1 }]]);
    currentUser = { id: 'u1', role: 'user' };
    const res = await del('/edge/app/schema/field-data-orphans/tOther/legacyKey');
    assert.equal(res.status, 403);
  });
});

// ─────────────────────────────────────────────────────────────────────
// Atomic ownership fence (Codex R4 P1).
//
// The editor ownership pre-check must be transactionally fenced with a
// FOR UPDATE row lock on the effective-blueprint owner row, so a concurrent
// owner-transfer between the ownership check and the payload mutation cannot
// let a former owner delete another owner's data. This holds for BOTH branches.
// ─────────────────────────────────────────────────────────────────────
describe('DELETE /field-data-orphans — atomic ownership fence (FOR UPDATE)', () => {
  it('orphan branch: editor clear runs inside a transaction with a FOR UPDATE ownership lock', async () => {
    conn = makeConn([
      [RX_OWNER, [{ ebp_id: 'bpMine', owner_id: 'ed1' }]],
      [RX_ORPHAN, { affectedRows: 1 }],
    ]);
    currentUser = { id: 'ed1', role: 'editor' };
    const res = await del('/edge/app/schema/field-data-orphans/tMine/legacyKey');
    assert.equal(res.status, 200);
    assert.equal(conn.committed(), true, 'orphan clear commits inside a transaction');
    assert.equal(conn.rolledBack(), false);
    const ownerQ = conn.queries.find((q) => RX_OWNER.test(q.sql));
    assert.ok(ownerQ, 'ownership SELECT should run for an editor');
    assert.match(ownerQ.sql, /FOR UPDATE/i, 'ownership SELECT must take a FOR UPDATE row lock');
  });

  it('type_mismatch branch: editor ownership SELECT takes a FOR UPDATE row lock', async () => {
    conn = makeConn([
      [RX_OWNER, [{ ebp_id: 'bpMine', owner_id: 'ed1' }]],
      [RX_REVAL, [{ ft: 'checkbox', payload: { colors: 'a' } }]],
      [RX_UPDATE_MISMATCH, { affectedRows: 1 }],
    ]);
    currentUser = { id: 'ed1', role: 'editor' };
    const res = await del('/edge/app/schema/field-data-orphans/tMine/colors?kind=type_mismatch');
    assert.equal(res.status, 200);
    assert.equal(conn.committed(), true);
    const ownerQ = conn.queries.find((q) => RX_OWNER.test(q.sql));
    assert.ok(ownerQ, 'ownership SELECT should run for an editor');
    assert.match(ownerQ.sql, /FOR UPDATE/i, 'ownership SELECT must take a FOR UPDATE row lock');
  });
});

// ─────────────────────────────────────────────────────────────────────
// Linked-blueprint cross-owner scoping (Codex P1).
//
// A blueprint may be an ALIAS whose linked_blueprint_id points at a SOURCE
// blueprint owned by a DIFFERENT editor (schema-sharing). Ownership MUST be
// resolved by the EFFECTIVE blueprint's owner — the same COALESCE(linked,
// blueprint) resolution the field scanner already uses — otherwise the
// editor who owns the alias could view previews of, and clear, payload
// values governed by the source blueprint they do not own.
//
// The mock conn scripts SQL by regex and never runs the real join, so we
// model the alias→source link by the row the join WOULD produce: the
// server SELECT reads `ehn.owner_id` (effective/source owner), so the
// scripted row's owner value IS the source owner. Template tLinked has
// blueprint_id 'bpAliasA' (an alias owned by 'edA') but its effective
// blueprint is source 'bpSourceB' owned by 'edB', so the effective owner
// the join resolves is 'edB'.
// ─────────────────────────────────────────────────────────────────────
const LINKED_TEMPLATES = [
  {
    id: 'tLinked', name: 'Linked', blueprint_id: 'bpAliasA',
    effective_blueprint_id: 'bpSourceB', effective_bp_row_id: 'bpSourceB', blueprint_owner_id: 'edB',
    payload: JSON.stringify({ colors: 'x' }),
  },
];
function linkedScanScripts() {
  return [
    [RX_FIELDS, []],
    [RX_SCAN_TEMPLATES, LINKED_TEMPLATES],
  ];
}

describe('Linked-blueprint cross-owner scoping (alias → source)', () => {
  it('alias owner (edA) does NOT see a template governed by the linked source (edB)', async () => {
    conn = makeConn(linkedScanScripts());
    currentUser = { id: 'edA', role: 'editor' };
    const res = await post('/edge/app/schema/field-data-orphans', {});
    assert.equal(res.status, 200);
    const bps = new Set(res.body.data.orphans.map((o) => o.blueprint_id));
    assert.ok(!bps.has('bpAliasA'), 'alias owner must NOT see the linked-source template');
    assert.equal(res.body.data.total, 0);
  });

  it('effective source owner (edB) DOES see the linked template', async () => {
    conn = makeConn(linkedScanScripts());
    currentUser = { id: 'edB', role: 'editor' };
    const res = await post('/edge/app/schema/field-data-orphans', {});
    assert.equal(res.status, 200);
    const bps = new Set(res.body.data.orphans.map((o) => o.blueprint_id));
    assert.ok(bps.has('bpAliasA'), 'source owner must see the linked template');
    assert.equal(res.body.data.total, 1);
  });

  it('alias owner (edA) cannot clear a residual governed by the linked source → 404, value preserved', async () => {
    conn = makeConn([
      [RX_OWNER, [{ ebp_id: 'bpSourceB', owner_id: 'edB' }]],
      [RX_ORPHAN, { affectedRows: 1 }],
    ]);
    currentUser = { id: 'edA', role: 'editor' };
    const res = await del('/edge/app/schema/field-data-orphans/tLinked/colors');
    assert.equal(res.status, 404);
    assert.equal(res.body.error.code, 'NOT_FOUND');
    assert.ok(!conn.queries.some((q) => RX_ORPHAN.test(q.sql)), 'clear must NOT run — value preserved');
  });

  it('effective source owner (edB) CAN clear a residual governed by the linked source', async () => {
    conn = makeConn([
      [RX_OWNER, [{ ebp_id: 'bpSourceB', owner_id: 'edB' }]],
      [RX_ORPHAN, { affectedRows: 1 }],
    ]);
    currentUser = { id: 'edB', role: 'editor' };
    const res = await del('/edge/app/schema/field-data-orphans/tLinked/colors');
    assert.equal(res.status, 200);
    assert.equal(res.body.data.removed_key, 'colors');
  });
});
