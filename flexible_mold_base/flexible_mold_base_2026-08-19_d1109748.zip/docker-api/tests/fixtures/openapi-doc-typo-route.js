/**
 * Fixture route file for public-docs-typo-does-not-empty-spec.test.js.
 *
 * NOT mounted anywhere and never listed in PUBLIC_ROUTE_FILES. It exists so the
 * "a documentation typo must not empty the published contract" proof can build
 * the REAL public document from annotations carrying the offending text,
 * instead of hand-writing a spec-shaped object that skips the parser.
 *
 * `<!--` is the ordinary markdown idiom for a note hidden from rendered output
 * and `</script>` turns up in any description that talks about HTML — both are
 * plausible things for an author to type, which is the whole point.
 */

/**
 * @openapi
 * /api/public/v1/fixture-widgets:
 *   get:
 *     summary: List widgets
 *     description: >
 *       Returns the widgets your token may see.
 *       <!-- reviewer note: rewrite this paragraph before launch -->
 *     tags: [Fixture]
 *     responses:
 *       200:
 *         description: OK
 */

/**
 * @openapi
 * /api/public/v1/fixture-gadgets:
 *   post:
 *     summary: Create a gadget
 *     description: >
 *       Embed the returned snippet with
 *       `<script src="...">...</script>` on your own page.
 *     tags: [Fixture]
 *     responses:
 *       201:
 *         description: Created
 */

module.exports = {};
