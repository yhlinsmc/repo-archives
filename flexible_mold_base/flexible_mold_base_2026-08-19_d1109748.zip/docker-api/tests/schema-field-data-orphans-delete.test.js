/**
 * schema-field-data-orphans-delete.test.js
 *
 * DELETE /field-data-orphans/:templateId/:key
 *   - kind=type_mismatch: removes the key only when the mismatch STILL holds
 *     (field exists AND value is still shape-invalid); runs in a transaction.
 *   - kind=type_mismatch: 409 STALE_MISMATCH when the value became shape-valid
 *     again (e.g. field type reverted) — the value is preserved (rollback).
 *   - kind=type_mismatch: 409 STALE_MISMATCH when the field is gone.
 *   - default / kind=orphan: existing single-statement NOT EXISTS path,
 *     unchanged, back-compatible.
 *
 * Harness: mirrors tests/unit/transformer-version-delete.test.js — a real
 * express app + node http client, with the edge `db` module replaced in
 * require.cache by a scripted mock connection. Chosen because the repo has no
 * real-DB fixture for these route tests and this is the established pattern
 * for exercising transaction (begin/commit/rollback) route handlers.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../src/edge/db');
const {
  USER_TEMPLATE_METADATA_COLUMN_NAMES,
  userTemplateMetadataKeySites,
} = require('../src/edge/lib/user-template-metadata');

// Columns the mocked DB reports for fmb_user_templates. Swapped per test to
// simulate a migrated vs a legacy (no-ALTER) database.
let templateColumns;

let conn;

function makeConn(scripts) {
  let inTx = false;
  let rolledBack = false;
  let committed = false;
  const queries = [];
  return {
    queries,
    rolledBack: () => rolledBack,
    committed: () => committed,
    inTx: () => inTx,
    async beginTransaction() { inTx = true; },
    async commit() { committed = true; inTx = false; },
    async rollback() { rolledBack = true; inTx = false; },
    async query(sql, params) {
      // The physical-column probe is infrastructure, not one of the statements a
      // test asserts about, so it is answered before `queries` is recorded.
      if (/^SELECT DATABASE\(\)/i.test(sql)) return [{ db: 'db_default' }];
      if (/information_schema\.COLUMNS/i.test(sql)) {
        return templateColumns.map((c) => ({ COLUMN_NAME: c }));
      }
      queries.push({ sql, params });
      for (const [matcher, response] of scripts) {
        if (matcher.test(sql)) {
          if (response instanceof Error) throw response;
          return typeof response === 'function' ? response(sql, params) : response;
        }
      }
      throw new Error(`Unmatched query: ${sql.slice(0, 80)}`);
    },
    release() { /* noop */ },
  };
}

const poolSpy = {
  rw: { async getConnection() { return conn; } },
  ro: { async getConnection() { return conn; } },
};

require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: {
    pool: poolSpy,
    t: (name) => `fmb_${name}`,
    getDynamicPool: async () => poolSpy,
  },
};

const schemaRouter = require('../src/edge/routes/app/schema');
const { __clearColumnSetCache } = schemaRouter.__test__;

let server;
let port;

before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { req.user = { id: 'admin-1', role: 'admin' }; next(); });
  app.use('/edge/app/schema', schemaRouter);
  await new Promise((resolve) => {
    server = app.listen(0, '127.0.0.1', () => {
      port = server.address().port;
      resolve();
    });
  });
});

after(async () => {
  await new Promise((resolve) => server.close(resolve));
  delete require.cache[dbKey];
});

const BASE_TEMPLATE_COLUMNS = ['id', 'blueprint_id', 'payload', 'generated_outputs'];

beforeEach(() => {
  conn = null;
  templateColumns = [...BASE_TEMPLATE_COLUMNS, ...USER_TEMPLATE_METADATA_COLUMN_NAMES];
  __clearColumnSetCache();
});

function del(path) {
  return new Promise((resolve, reject) => {
    const req = http.request({
      method: 'DELETE',
      host: '127.0.0.1',
      port,
      path,
    }, (res) => {
      let raw = '';
      res.on('data', (chunk) => { raw += chunk; });
      res.on('end', () => resolve({ status: res.statusCode, body: raw ? JSON.parse(raw) : null }));
    });
    req.on('error', reject);
    req.end();
  });
}

// The type_mismatch re-validation SELECT (field_type + JSON_EXTRACT'd value).
// The re-check reads the payload DOCUMENT and indexes it in JavaScript, the way
// the scanner does, so these fixtures state what the ROW HOLDS rather than what
// an extraction returned. `payload` is a hydrated object because that is what
// this driver hands back for a JSON column — and stating it as pre-extracted
// JSON text is precisely what let the double answer for an extraction the
// deployed driver never performs: a stored string arrived as a JavaScript
// string, the `JSON.parse` in front of the shape check threw on it, and this
// suite was green throughout. The instrument that settles it is
// tests/integration/destructive-gates-real-db.test.js.
const RX_SELECT = /SELECT bf\.field_type AS ft/i;
// The type_mismatch removal UPDATE (plain single-table JSON_REMOVE).
const RX_UPDATE = /UPDATE `fmb_user_templates` SET payload = JSON_REMOVE\(payload/i;
// The legacy orphan path (JOIN + NOT EXISTS).
const RX_ORPHAN = /NOT EXISTS/i;

describe('DELETE /field-data-orphans/:templateId/:key?kind=type_mismatch', () => {
  it('a scalar (text) field value can NEVER be cleared as type_mismatch → 409 STALE_MISMATCH, nothing removed', async () => {
    // Detection is one-directional: a scalar field is never flagged, so the
    // re-validation predicate always says valid → the claimed mismatch is stale
    // → the value is preserved. This proves a scalar value can't be deleted via
    // this path, even a JSON array-string that looks like a stranded composite.
    conn = makeConn([
      [RX_SELECT, [{ ft: 'text', payload: { colors: '["a","b"]' } }]],
      [RX_UPDATE, { affectedRows: 1 }], // must NOT be reached
    ]);
    const res = await del('/edge/app/schema/field-data-orphans/t1/colors?kind=type_mismatch');
    assert.equal(res.status, 409);
    assert.equal(res.body.error.code, 'STALE_MISMATCH');
    assert.equal(conn.rolledBack(), true);
    assert.equal(conn.committed(), false);
    assert.ok(!conn.queries.some((q) => RX_UPDATE.test(q.sql)), 'JSON_REMOVE must NOT run');
  });

  it('removes a scalar value under a checkbox field (composite field, stranded value) + commits', async () => {
    // Other direction: a checkbox field expects an array; a stored scalar
    // "a" is shape-invalid → must be removed.
    conn = makeConn([
      [RX_SELECT, [{ ft: 'checkbox', payload: { colors: 'a' } }]],
      [RX_UPDATE, { affectedRows: 1 }],
    ]);
    const res = await del('/edge/app/schema/field-data-orphans/t1/colors?kind=type_mismatch');
    assert.equal(res.status, 200);
    assert.equal(res.body.data.removed_key, 'colors');
    assert.equal(conn.committed(), true);
    assert.equal(conn.rolledBack(), false);
    assert.ok(conn.queries.some((q) => RX_UPDATE.test(q.sql)), 'JSON_REMOVE UPDATE should run');
  });

  it('preserves a value one of TWO rows holding the key accepts (409, no removal)', async () => {
    // The join carries no LIMIT because `(blueprint_id, field_key)` is unique
    // only on a database that could take the index. Reading `rows[0].ft` judged
    // whichever row the engine returned first, which is not the row the scanner
    // reported, and removed a value the other field accepts — stored nowhere
    // else. Both orders are stated, because the row order is not a contract.
    for (const order of [['checkbox', 'text'], ['text', 'checkbox']]) {
      conn = makeConn([
        [RX_SELECT, order.map((ft) => ({ ft, payload: { colors: 'plain string' } }))],
        [RX_UPDATE, { affectedRows: 1 }], // must NOT be reached
      ]);
      const res = await del('/edge/app/schema/field-data-orphans/t1/colors?kind=type_mismatch');
      assert.equal(res.status, 409, `removed with the rows in the order ${order.join(', ')}`);
      assert.equal(res.body.error.code, 'STALE_MISMATCH');
      assert.ok(!conn.queries.some((q) => RX_UPDATE.test(q.sql)), 'JSON_REMOVE must NOT run');
    }
  });

  it('clears a value NEITHER of two rows holding the key accepts (200)', async () => {
    // The control: judging every row must not become "never a mismatch".
    conn = makeConn([
      [RX_SELECT, ['checkbox', 'table'].map((ft) => ({ ft, payload: { colors: 'plain string' } }))],
      [RX_UPDATE, { affectedRows: 1 }],
    ]);
    const res = await del('/edge/app/schema/field-data-orphans/t1/colors?kind=type_mismatch');
    assert.equal(res.status, 200);
    assert.ok(conn.queries.some((q) => RX_UPDATE.test(q.sql)), 'JSON_REMOVE UPDATE should run');
  });

  it('preserves a VALID checkbox value stored as "[\\"a\\"]" (409 STALE_MISMATCH, no removal) — anti-data-loss', async () => {
    // CRITICAL anti-data-loss guarantee: a valid checkbox value is the STORED
    // STRING '["a"]'. JSON_EXTRACT returns its JSON text; the DELETE branch
    // un-wraps once to the raw string '["a"]', the predicate parses it → array
    // → VALID under checkbox → the claimed mismatch is stale → value preserved.
    // (The pre-fix predicate did Array.isArray('["a"]') === false and would
    // have WRONGLY removed this valid data.)
    conn = makeConn([
      [RX_SELECT, [{ ft: 'checkbox', payload: { colors: '["a"]' } }]],
      [RX_UPDATE, { affectedRows: 1 }], // must NOT be reached
    ]);
    const res = await del('/edge/app/schema/field-data-orphans/t1/colors?kind=type_mismatch');
    assert.equal(res.status, 409);
    assert.equal(res.body.error.code, 'STALE_MISMATCH');
    assert.equal(conn.rolledBack(), true);
    assert.equal(conn.committed(), false);
    assert.ok(!conn.queries.some((q) => RX_UPDATE.test(q.sql)), 'JSON_REMOVE must NOT run');
  });

  it('clears a real residual: a scalar value under a table field → 200', async () => {
    // A table field expects an array/object; a stored plain scalar 'x' is a
    // genuine residual under a composite field and must be cleared.
    conn = makeConn([
      [RX_SELECT, [{ ft: 'table', payload: { colors: 'x' } }]],
      [RX_UPDATE, { affectedRows: 1 }],
    ]);
    const res = await del('/edge/app/schema/field-data-orphans/t1/colors?kind=type_mismatch');
    assert.equal(res.status, 200);
    assert.equal(res.body.data.removed_key, 'colors');
    assert.equal(conn.committed(), true);
    assert.ok(conn.queries.some((q) => RX_UPDATE.test(q.sql)), 'JSON_REMOVE UPDATE should run');
  });

  it('is rejected with 409 STALE_MISMATCH when value is now shape-valid (field reverted)', async () => {
    // Field reverted to checkbox; stored string '["a","b"]' is now shape-valid → preserve.
    conn = makeConn([
      [RX_SELECT, [{ ft: 'checkbox', payload: { colors: '["a","b"]' } }]],
      [RX_UPDATE, { affectedRows: 1 }], // must NOT be reached
    ]);
    const res = await del('/edge/app/schema/field-data-orphans/t1/colors?kind=type_mismatch');
    assert.equal(res.status, 409);
    assert.equal(res.body.error.code, 'STALE_MISMATCH');
    assert.equal(conn.rolledBack(), true);
    assert.equal(conn.committed(), false);
    assert.ok(!conn.queries.some((q) => RX_UPDATE.test(q.sql)), 'JSON_REMOVE must NOT run');
  });

  it('is rejected with 409 STALE_MISMATCH when the field is gone (ft null)', async () => {
    conn = makeConn([
      [RX_SELECT, [{ ft: null, payload: { colors: '["a","b"]' } }]],
      [RX_UPDATE, { affectedRows: 1 }],
    ]);
    const res = await del('/edge/app/schema/field-data-orphans/t1/colors?kind=type_mismatch');
    assert.equal(res.status, 409);
    assert.equal(res.body.error.code, 'STALE_MISMATCH');
    assert.equal(conn.rolledBack(), true);
    assert.ok(!conn.queries.some((q) => RX_UPDATE.test(q.sql)), 'JSON_REMOVE must NOT run');
  });

  it('is rejected with 409 STALE_MISMATCH when the template/key row is gone', async () => {
    conn = makeConn([
      [RX_SELECT, []],
    ]);
    const res = await del('/edge/app/schema/field-data-orphans/t1/colors?kind=type_mismatch');
    assert.equal(res.status, 409);
    assert.equal(res.body.error.code, 'STALE_MISMATCH');
    assert.equal(conn.rolledBack(), true);
  });

  it('locks the re-validation SELECT with FOR UPDATE (TOCTOU fence)', async () => {
    conn = makeConn([
      [RX_SELECT, [{ ft: 'checkbox', payload: { colors: 'a' } }]],
      [RX_UPDATE, { affectedRows: 1 }],
    ]);
    const res = await del('/edge/app/schema/field-data-orphans/t1/colors?kind=type_mismatch');
    assert.equal(res.status, 200);
    const selectQ = conn.queries.find((q) => RX_SELECT.test(q.sql));
    assert.ok(selectQ, 're-validation SELECT should run');
    assert.match(selectQ.sql, /FOR UPDATE/i, 'SELECT must take a FOR UPDATE row lock');
  });

  it('rolls back + 500 when the UPDATE throws', async () => {
    conn = makeConn([
      [RX_SELECT, [{ ft: 'checkbox', payload: { colors: 'a' } }]],
      [RX_UPDATE, new Error('connection lost')],
    ]);
    const res = await del('/edge/app/schema/field-data-orphans/t1/colors?kind=type_mismatch');
    assert.equal(res.status, 500);
    assert.equal(conn.rolledBack(), true);
  });
});

describe('DELETE /field-data-orphans/:templateId/:key (orphan path)', () => {
  it('default (no kind) uses the NOT EXISTS re-validation path inside a transaction', async () => {
    conn = makeConn([
      [RX_ORPHAN, { affectedRows: 1 }],
    ]);
    const res = await del('/edge/app/schema/field-data-orphans/t1/legacyKey');
    assert.equal(res.status, 200);
    assert.equal(res.body.data.removed_key, 'legacyKey');
    // Orphan branch is now transactionally fenced (begin → ownership FOR UPDATE
    // → NOT EXISTS UPDATE → commit) so a concurrent owner-transfer cannot race
    // the ownership check.
    assert.equal(conn.committed(), true, 'orphan clear commits');
    assert.equal(conn.rolledBack(), false);
    assert.ok(conn.queries.some((q) => RX_ORPHAN.test(q.sql)), 'orphan NOT EXISTS query should run');
  });

  it('kind=orphan is treated the same as default (orphan path)', async () => {
    conn = makeConn([
      [RX_ORPHAN, { affectedRows: 1 }],
    ]);
    const res = await del('/edge/app/schema/field-data-orphans/t1/legacyKey?kind=orphan');
    assert.equal(res.status, 200);
    assert.equal(conn.committed(), true);
    assert.ok(conn.queries.some((q) => RX_ORPHAN.test(q.sql)));
  });

  it('orphan path returns 409 STALE_ORPHAN when nothing removed + rolls back', async () => {
    conn = makeConn([
      [RX_ORPHAN, { affectedRows: 0 }],
    ]);
    const res = await del('/edge/app/schema/field-data-orphans/t1/legacyKey');
    assert.equal(res.status, 409);
    assert.equal(res.body.error.code, 'STALE_ORPHAN');
    assert.equal(conn.rolledBack(), true, 'stale orphan rolls back');
    assert.equal(conn.committed(), false);
  });

  it('orphan path rolls back + 500 when the UPDATE throws', async () => {
    conn = makeConn([
      [RX_ORPHAN, new Error('connection lost')],
    ]);
    const res = await del('/edge/app/schema/field-data-orphans/t1/legacyKey');
    assert.equal(res.status, 500);
    assert.equal(conn.rolledBack(), true);
  });
});

describe('DELETE /field-data-orphans — the repair reaches every field-key-indexed document', () => {
  // Deleting a blueprint_field does not purge template data, so this endpoint is
  // the designated repair for a deleted field's residue. Repairing `payload`
  // alone leaves all three metadata documents pointing at the deleted key: the
  // health report then says clean, and re-creating a field under the same key
  // silently re-applies a marker the operator never set — a deliberate blank
  // restored, or a computed field marked overridden by nobody.
  const metadataPaths = (sql) => userTemplateMetadataKeySites()
    .filter((site) => sql.includes(`\`${site.column}\``))
    .map((site) => `${site.container}."legacyKey"`);

  it('clears the orphan key from every metadata document, in the same statement', async () => {
    conn = makeConn([[RX_ORPHAN, { affectedRows: 1 }]]);
    const res = await del('/edge/app/schema/field-data-orphans/t1/legacyKey');
    assert.equal(res.status, 200);

    const update = conn.queries.find((q) => RX_ORPHAN.test(q.sql));
    assert.ok(update, 'orphan UPDATE should run');
    for (const site of userTemplateMetadataKeySites()) {
      assert.ok(
        update.sql.includes(`\`${site.column}\``),
        `${site.column} must be cleared alongside payload`,
      );
    }
    // Every declared site's path is bound, channels included — a root-only path
    // would match nothing in the channelled column and clear nothing.
    for (const path of metadataPaths(update.sql)) {
      assert.ok(update.params.includes(path), `no bound parameter for ${path}`);
    }
    assert.ok(
      update.params.includes('$."legacyKey"'),
      'the payload path must still be bound',
    );
  });

  it('leaves a document MariaDB cannot parse untouched', async () => {
    conn = makeConn([[RX_ORPHAN, { affectedRows: 1 }]]);
    await del('/edge/app/schema/field-data-orphans/t1/legacyKey');
    const update = conn.queries.find((q) => RX_ORPHAN.test(q.sql));
    // Guarded per column: JSON_REMOVE against text MariaDB cannot parse answers
    // NULL, which would replace a corrupt document with nothing at all.
    for (const column of USER_TEMPLATE_METADATA_COLUMN_NAMES) {
      assert.match(
        update.sql,
        new RegExp(`CASE WHEN JSON_VALID\\(ut\\.\`${column}\`\\)`),
        `${column} must be cleared only when its document parses`,
      );
    }
  });

  it('assigns each column exactly once, whatever its channels', async () => {
    // The channelled column has two key sites. A clause per site would assign the
    // same column twice in one statement and leave both removals surviving up to
    // the order the engine evaluates a SET list in — which no mocked test can
    // see, because the SQL string would be exactly what was intended. Asserted
    // structurally instead, so the property holds without a database.
    conn = makeConn([[RX_ORPHAN, { affectedRows: 1 }]]);
    await del('/edge/app/schema/field-data-orphans/t1/legacyKey');
    const update = conn.queries.find((q) => RX_ORPHAN.test(q.sql));

    for (const column of ['payload', ...USER_TEMPLATE_METADATA_COLUMN_NAMES]) {
      // An assignment target is the only place the column name is followed by
      // `=`; every other mention is inside a function argument.
      const assignments = update.sql.match(
        new RegExp(`(?:ut\\.)?\`?${column}\`?\\s*=`, 'g'),
      ) || [];
      assert.equal(
        assignments.length, 1,
        `${column} is assigned ${assignments.length} times in one statement`,
      );
    }
    // The channelled column's two paths travel together in one removal.
    const clearedPaths = userTemplateMetadataKeySites()
      .filter((site) => site.column === 'cleared_auto_fills')
      .map((site) => `${site.container}."legacyKey"`);
    assert.equal(clearedPaths.length, 2, 'expected the channelled column to have two sites');
    for (const path of clearedPaths) {
      assert.ok(update.params.includes(path), `no bound parameter for ${path}`);
    }
  });

  it('skips the metadata columns on a database that predates them, without failing', async () => {
    templateColumns = BASE_TEMPLATE_COLUMNS;
    conn = makeConn([[RX_ORPHAN, { affectedRows: 1 }]]);
    const res = await del('/edge/app/schema/field-data-orphans/t1/legacyKey');
    assert.equal(res.status, 200);

    const update = conn.queries.find((q) => RX_ORPHAN.test(q.sql));
    for (const column of USER_TEMPLATE_METADATA_COLUMN_NAMES) {
      assert.ok(!update.sql.includes(`\`${column}\``), `${column} must be dropped`);
    }
    assert.match(update.sql, /payload = JSON_REMOVE\(ut\.payload/i);
  });

  it('clears the metadata documents on the type_mismatch path too', async () => {
    // The field still exists here, but its stored answer is being removed — so
    // the per-field metadata about that answer is equally stale.
    conn = makeConn([
      [RX_SELECT, [{ ft: 'checkbox', payload: { colors: 'a' } }]],
      [RX_UPDATE, { affectedRows: 1 }],
    ]);
    const res = await del('/edge/app/schema/field-data-orphans/t1/colors?kind=type_mismatch');
    assert.equal(res.status, 200);

    const update = conn.queries.find((q) => RX_UPDATE.test(q.sql));
    assert.ok(update, 'type_mismatch UPDATE should run');
    for (const site of userTemplateMetadataKeySites()) {
      assert.ok(
        update.params.includes(`${site.container}."colors"`),
        `no bound parameter for ${site.column} at ${site.container}`,
      );
    }
  });
});

describe('DELETE /field-data-orphans — how long a key is, in the unit the database counts', () => {
  // This endpoint is the ONLY way a residual leaves the interface, and its own
  // comment says an orphan key may be any historical or imported key. A bound
  // counted in JavaScript's UTF-16 code units therefore does not merely refuse a
  // request — it makes a stored row permanently unclearable, because there is no
  // second route to it. utf8mb4 counts CHARACTERS, so the bound must too.
  //
  // The keys below are built from a character that costs TWO UTF-16 code units
  // and four bytes. A Latin-only key cannot fail on this defect at any length:
  // for Latin text all three counts agree, which is why the original bound
  // looked correct for as long as it did.
  const ASTRAL = '\u{1F600}';
  const astralKey = (characters) => ASTRAL.repeat(characters);
  const latinKey = (characters) => 'k'.repeat(characters);

  const clearOrphan = (key) => del(
    `/edge/app/schema/field-data-orphans/t1/${encodeURIComponent(key)}`,
  );

  it('clears a 130-character astral key, which counts 260 as UTF-16 code units', async () => {
    const key = astralKey(130);
    assert.equal([...key].length, 130, 'the fixture key is not 130 characters');
    assert.equal(key.length, 260, 'the fixture key does not exceed the bound in code units');

    conn = makeConn([[RX_ORPHAN, { affectedRows: 1 }]]);
    const res = await clearOrphan(key);

    // The repair STATEMENT first, and the status after it: a refusal and a
    // refusal that already wrote half the repair carry the same status code,
    // and it is the statement reaching the engine that decides whether the row
    // can ever be cleared.
    assert.ok(
      conn.queries.some((q) => RX_ORPHAN.test(q.sql)),
      'no repair statement was issued for a key MariaDB stores as 130 characters, so '
      + 'the row has no way out — this endpoint is the only one that clears it',
    );
    assert.equal(res.status, 200, res.body && JSON.stringify(res.body));
    assert.equal(res.body.data.removed_key, key);
  });

  it('clears a 130-character astral key on the type_mismatch branch too', async () => {
    // One guard serves both branches; a fix applied to the branch the report
    // happened to name would leave the other one refusing the same key.
    const key = astralKey(130);
    conn = makeConn([
      [RX_SELECT, [{ ft: 'checkbox', payload: { [key]: 'a' } }]],
      [RX_UPDATE, { affectedRows: 1 }],
    ]);
    const res = await del(
      `/edge/app/schema/field-data-orphans/t1/${encodeURIComponent(key)}?kind=type_mismatch`,
    );

    assert.ok(
      conn.queries.some((q) => RX_UPDATE.test(q.sql)),
      'the type_mismatch branch issued no removal for a 130-character key, so it still '
      + 'counts code units',
    );
    assert.equal(res.status, 200, res.body && JSON.stringify(res.body));
    assert.equal(res.body.data.removed_key, key);
  });

  it('still accepts a key of exactly the bound, so the fix widens nothing away', async () => {
    // Guards the opposite mistake: aligning this bound down to the metadata
    // column's 255 would newly strand every 256-character key — the same
    // unclearable-row failure, arrived at from the other side.
    conn = makeConn([[RX_ORPHAN, { affectedRows: 1 }]]);
    assert.equal((await clearOrphan(latinKey(256))).status, 200);
  });

  it('still refuses a key past the bound, counted in characters', async () => {
    conn = makeConn([[RX_ORPHAN, { affectedRows: 1 }]]);
    const res = await clearOrphan(latinKey(257));
    assert.equal(res.status, 400);
    assert.equal(res.body.error.code, 'BAD_REQUEST');
    assert.deepEqual(conn.queries, [], 'nothing may be issued for a refused key');
  });

  it('still refuses an astral key past the bound in characters', async () => {
    // The bound must still bound: deleting the length check outright would pass
    // every test above and this is what catches it.
    conn = makeConn([[RX_ORPHAN, { affectedRows: 1 }]]);
    const res = await clearOrphan(astralKey(257));
    assert.equal(res.status, 400);
    assert.deepEqual(conn.queries, [], 'nothing may be issued for a refused key');
  });
});
