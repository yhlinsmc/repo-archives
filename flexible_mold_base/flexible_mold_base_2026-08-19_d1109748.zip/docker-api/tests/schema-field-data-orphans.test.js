const { test } = require('node:test');
const assert = require('node:assert');
const { __test__ } = require('../src/edge/routes/app/schema');
const { valueShapeValidForType } = __test__;

// Payload values are stored as STRINGS (checkbox/table as JSON-strings, scalars
// as plain strings). The predicate parses the string to derive shape. Detection
// is ONE-DIRECTIONAL: only a composite field (checkbox/table) holding a value
// that isn't its shape is flagged; a scalar field is NEVER flagged. This must
// stay in lockstep with the frontend isValueShapeValidForType.
test('valueShapeValidForType mirrors the frontend table (string storage form)', () => {
  // a scalar field is NEVER flagged — even a JSON array/object-string is valid
  // (could be legitimate JSON-in-text; the payload carries no type tag)
  assert.strictEqual(valueShapeValidForType('text', '["a"]'), true);
  assert.strictEqual(valueShapeValidForType('text', '{"a":1}'), true);
  // a plain string under a scalar field = valid
  assert.strictEqual(valueShapeValidForType('text', 'a'), true);
  // a plain scalar string is NOT a valid checkbox value (unambiguous residual)
  assert.strictEqual(valueShapeValidForType('checkbox', 'a'), false);
  // a stored checkbox value is the JSON array-string '["a"]' → valid (anti-data-loss)
  assert.strictEqual(valueShapeValidForType('checkbox', '["a"]'), true);
  // a stored table value is a JSON string of rows
  assert.strictEqual(valueShapeValidForType('table', 'x'), false);
  assert.strictEqual(valueShapeValidForType('table', '[{"c":1}]'), true);
  assert.strictEqual(valueShapeValidForType('table', '{"r":1}'), true);
  // blank values are never a mismatch
  assert.strictEqual(valueShapeValidForType('select', null), true);
  assert.strictEqual(valueShapeValidForType('select', ''), true);
});
