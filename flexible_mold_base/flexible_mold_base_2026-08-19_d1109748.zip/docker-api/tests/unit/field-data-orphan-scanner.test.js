/**
 * field-data-orphan-scanner.test.js
 *
 * Verifies POST /api/schema/field-data-orphans (scan) and
 * DELETE /api/schema/field-data-orphans/:templateId/:key (single-key
 * cleanup). Both are admin + blueprint-owner (editor) scoped: admin sees /
 * clears everything; an editor is limited to residuals under a blueprint
 * they own or that is shared (owner_id NULL). Non-owner editors are 404'd
 * (existence not disclosed); plain users are rejected before any DB query.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../src/edge/db');
const { userTemplateMetadataKeySites } = require('../../src/edge/lib/user-template-metadata');

// The clear statement repairs every field-key-indexed document on the row, one
// assignment per COLUMN carrying all of that column's paths, between the payload
// path and the row/guard parameters.
const metadataClearParams = (key) => {
  const byColumn = new Map();
  for (const site of userTemplateMetadataKeySites()) {
    if (!byColumn.has(site.column)) byColumn.set(site.column, []);
    byColumn.get(site.column).push(`${site.container}."${key}"`);
  }
  return [...byColumn.values()].flat();
};

let conn;
function makeConn(scripts) {
  const queries = [];
  let committed = false;
  let rolledBack = false;
  return {
    queries,
    committed: () => committed,
    rolledBack: () => rolledBack,
    async beginTransaction() {},
    async commit() { committed = true; },
    async rollback() { rolledBack = true; },
    async query(sql, params) {
      // Infrastructure probes, not statements a test asserts about: answered
      // before `queries` is recorded so the existing assertions still see only
      // the route's own SQL. Every metadata column is reported present.
      if (/^SELECT DATABASE\(\)/i.test(sql)) return [{ db: 'db_probe' }];
      if (/information_schema\.COLUMNS/i.test(sql)) {
        return ['id', 'blueprint_id', 'payload']
          .concat(userTemplateMetadataKeySites().map((site) => site.column))
          .map((c) => ({ COLUMN_NAME: c }));
      }
      queries.push({ sql, params });
      for (const [matcher, response] of scripts) {
        if (matcher.test(sql)) {
          return typeof response === 'function' ? response(sql, params) : response;
        }
      }
      throw new Error(`Unmatched query: ${sql.slice(0, 120)}`);
    },
    release() {},
  };
}

const poolSpy = {
  rw: { async getConnection() { return conn; } },
  ro: { async getConnection() { return conn; } },
};

let dynamicConn = null;
const dynamicPoolSpy = {
  rw: { async getConnection() { return dynamicConn; } },
  ro: { async getConnection() { return dynamicConn; } },
};
let dynamicPoolRequestedFor = null;

// Server-side DB config the x-database-validate middleware injects on a valid
// X-Database header. Set per test to the schema being routed to.
let serverDbConfig = null;

require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: {
    pool: poolSpy,
    t: (name) => `fmb_${name}`,
    getDynamicPool: async (cfg) => {
      dynamicPoolRequestedFor = cfg;
      return dynamicPoolSpy;
    },
    // Consumed by the x-database-validate middleware (now mounted in makeApp).
    isPoolReady: () => true,
    getDbConfigFull: () => serverDbConfig,
  },
};

const router = require('../../src/edge/routes/app/schema');
const { scanFieldDataOrphans } = router.__test__;
// The effective-blueprint expression is ASKED FOR BELOW, not restated. Written
// out as a literal, this file held a second copy of a rule that lives in
// helpers.js — and when the rule changed (a stored blank link must resolve to
// the template's own blueprint, or the orphan endpoints delete valid answers)
// the copy went on asserting the broken form, so the route could not be repaired
// without the test calling the repair a regression. A test that spells a rule
// out is a reader of that rule too.
//
// Required HERE and not at the top of the file: helpers.js pulls in the db
// module, and above the stub installed just above this line that would be the
// REAL one — every case in this file then talks to a pool that is not the spy.
const { effectiveBlueprintIdSql } = require('../../src/edge/routes/app/schema/helpers');

let adminServer, adminPort, editorServer, editorPort;

function makeApp(role) {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => {
    req.user = { id: `${role}-1`, role };
    next();
  });
  // Mount the real X-Database middleware so schema routing is driven by the
  // header (server-injected db config) exactly as in production — a client
  // body.db is rejected at this boundary, never trusted.
  app.use(require('../../src/edge/middleware/x-database-validate'));
  app.use('/edge/app/schema', router);
  return app;
}

before(async () => {
  await new Promise((resolve) => {
    adminServer = makeApp('admin').listen(0, '127.0.0.1', () => {
      adminPort = adminServer.address().port;
      resolve();
    });
  });
  await new Promise((resolve) => {
    editorServer = makeApp('editor').listen(0, '127.0.0.1', () => {
      editorPort = editorServer.address().port;
      resolve();
    });
  });
});

after(async () => {
  await new Promise((resolve) => adminServer.close(resolve));
  await new Promise((resolve) => editorServer.close(resolve));
  delete require.cache[dbKey];
});

beforeEach(() => {
  conn = null; dynamicConn = null; dynamicPoolRequestedFor = null; serverDbConfig = null;
  router.__test__.__clearColumnSetCache();
});

function req(port, method, path, body, extraHeaders) {
  return new Promise((resolve, reject) => {
    const data = body !== undefined ? JSON.stringify(body) : '';
    const headers = { ...(extraHeaders || {}) };
    if (data) { headers['Content-Type'] = 'application/json'; headers['Content-Length'] = Buffer.byteLength(data); }
    const r = http.request({ method, host: '127.0.0.1', port, path, headers }, (res) => {
      let raw = '';
      res.on('data', (chunk) => { raw += chunk; });
      res.on('end', () => resolve({ status: res.statusCode, body: raw ? JSON.parse(raw) : null }));
    });
    r.on('error', reject);
    if (data) r.write(data);
    r.end();
  });
}

// ─────────────────────────────────────────────────────────────────────
// scanFieldDataOrphans — pure function unit tests
// ─────────────────────────────────────────────────────────────────────

describe('scanFieldDataOrphans — orphan detection logic', () => {
  it('returns empty when no templates have payloads', async () => {
    const c = makeConn([
      [/blueprint_fields/i, [{ blueprint_id: 'bp-1', field_key: 'a' }]],
      [/user_templates/i, []],
    ]);
    const orphans = await scanFieldDataOrphans(c);
    assert.deepEqual(orphans, []);
  });

  it('flags payload keys not in blueprint_fields for that blueprint', async () => {
    const c = makeConn([
      [/blueprint_fields/i, [
        { blueprint_id: 'bp-1', field_key: 'name' },
        { blueprint_id: 'bp-1', field_key: 'size' },
      ]],
      [/user_templates/i, [
        { id: 't-1', name: 'T1', blueprint_id: 'bp-1', effective_blueprint_id: 'bp-1', payload: { name: 'a', size: 10, deleted_field: 'rot' } },
      ]],
    ]);
    const orphans = await scanFieldDataOrphans(c);
    assert.equal(orphans.length, 1);
    assert.equal(orphans[0].template_id, 't-1');
    assert.equal(orphans[0].orphan_key, 'deleted_field');
    assert.equal(orphans[0].value_preview, 'rot');
  });

  it('treats string payloads as JSON', async () => {
    const c = makeConn([
      [/blueprint_fields/i, [{ blueprint_id: 'bp-1', field_key: 'name' }]],
      [/user_templates/i, [
        { id: 't-1', name: 'T1', blueprint_id: 'bp-1', effective_blueprint_id: 'bp-1', payload: '{"name":"a","stale":42}' },
      ]],
    ]);
    const orphans = await scanFieldDataOrphans(c);
    assert.equal(orphans.length, 1);
    assert.equal(orphans[0].orphan_key, 'stale');
  });

  it('skips templates with unparseable payload', async () => {
    const c = makeConn([
      [/blueprint_fields/i, [{ blueprint_id: 'bp-1', field_key: 'name' }]],
      [/user_templates/i, [
        { id: 't-1', name: 'T1', blueprint_id: 'bp-1', effective_blueprint_id: 'bp-1', payload: 'not json' },
        { id: 't-2', name: 'T2', blueprint_id: 'bp-1', effective_blueprint_id: 'bp-1', payload: { name: 'a', stale: 1 } },
      ]],
    ]);
    const orphans = await scanFieldDataOrphans(c);
    assert.equal(orphans.length, 1);
    assert.equal(orphans[0].template_id, 't-2');
  });

  it('truncates value_preview to 80 chars', async () => {
    const long = 'x'.repeat(200);
    const c = makeConn([
      [/blueprint_fields/i, []],
      [/user_templates/i, [
        { id: 't-1', name: 'T1', blueprint_id: 'bp-1', effective_blueprint_id: 'bp-1', payload: { stale: long } },
      ]],
    ]);
    const orphans = await scanFieldDataOrphans(c);
    assert.equal(orphans[0].value_preview.length, 80);
  });

  it('linked_blueprint_id resolves the effective blueprint for field-key lookup', async () => {
    // Template under blueprint A with linked_blueprint_id = B uses B's
    // fields. The COALESCE in the SELECT projects effective_blueprint_id
    // to bp-B so we look up B's field_keys.
    const c = makeConn([
      [/blueprint_fields/i, [
        { blueprint_id: 'bp-A', field_key: 'a_only' },
        { blueprint_id: 'bp-B', field_key: 'shared_field' },
      ]],
      [/user_templates/i, [
        // Template under A but linked to B — payload uses B's "shared_field"
        { id: 't-1', name: 'T1', blueprint_id: 'bp-A', effective_blueprint_id: 'bp-B',
          payload: { shared_field: 'valid', a_only: 'wrong-fields-from-A' } },
      ]],
    ]);
    const orphans = await scanFieldDataOrphans(c);
    // shared_field is valid (it's in bp-B); a_only is orphan (not in bp-B)
    assert.equal(orphans.length, 1);
    assert.equal(orphans[0].orphan_key, 'a_only');
  });

  it('issued SELECT joins hierarchy_nodes to project effective_blueprint_id', async () => {
    let templatesSelect = null;
    const c = makeConn([
      [/blueprint_fields/i, []],
      [/user_templates/i, (sql) => { templatesSelect = sql; return []; }],
    ]);
    await scanFieldDataOrphans(c);
    assert.ok(
      templatesSelect.includes(`${effectiveBlueprintIdSql('hn', 'ut')} AS effective_blueprint_id`),
      `the scanner projects an effective blueprint the shared helper did not build:\n${templatesSelect}`,
    );
    assert.match(templatesSelect, /LEFT JOIN `fmb_hierarchy_nodes` hn ON hn\.id = ut\.blueprint_id/);
  });

  it('scanFieldDataOrphans: type_mismatch flagged, healthy skipped, orphan kept', async () => {
    // Detection is one-directional: only a COMPOSITE field (checkbox/table)
    // holding a value that isn't its shape is flagged. A non-array value ('oops')
    // stranded under a checkbox field is unambiguously a residual. A scalar field
    // is NEVER flagged.
    const c = makeConn([
      [/blueprint_fields/i, [
        { blueprint_id: 'bp1', field_key: 'colors', field_type: 'checkbox' },
        { blueprint_id: 'bp1', field_key: 'name', field_type: 'text' },
      ]],
      [/user_templates/i, [
        { id: 't1', name: 'T1', blueprint_id: 'bp1', effective_blueprint_id: 'bp1',
          payload: JSON.stringify({ colors: 'oops', name: 'ok', gone: 'x' }) },
      ]],
    ]);
    const rows = await scanFieldDataOrphans(c);
    const byKey = Object.fromEntries(rows.map((r) => [r.orphan_key, r.kind]));
    assert.strictEqual(byKey.colors, 'type_mismatch'); // non-array value under checkbox field
    assert.strictEqual(byKey.gone, 'orphan'); // key not in fields
    assert.strictEqual(byKey.name, undefined); // healthy
  });

  it('scanFieldDataOrphans: a key held by two field rows is judged against BOTH', async () => {
    // `(blueprint_id, field_key)` is unique only on a database that could take
    // the index; where duplicates already exist the migration skips, visibly,
    // so two rows sharing a key is a state the deployed schema is still allowed
    // to be in. Keyed by a Map that kept the last writer, the scanner judged the
    // value against whichever row came last and reported a mismatch the other
    // row's type accepts — and the repair endpoint then removed it. Both orders
    // are stated, because which row the engine returns last is not a contract.
    for (const order of [['checkbox', 'text'], ['text', 'checkbox']]) {
      const c = makeConn([
        [/blueprint_fields/i, order.map((field_type) => (
          { blueprint_id: 'bp1', field_key: 'colors', field_type }
        ))],
        [/user_templates/i, [
          { id: 't1', name: 'T1', blueprint_id: 'bp1', effective_blueprint_id: 'bp1',
            payload: JSON.stringify({ colors: 'plain string' }) },
        ]],
      ]);
      assert.deepEqual(
        await scanFieldDataOrphans(c), [],
        `flagged with the rows in the order ${order.join(', ')}`,
      );
    }
  });

  it('scanFieldDataOrphans: a value NEITHER of two rows accepts is still flagged', async () => {
    // The control: judging every row must not become "never a mismatch".
    const c = makeConn([
      [/blueprint_fields/i, [
        { blueprint_id: 'bp1', field_key: 'colors', field_type: 'checkbox' },
        { blueprint_id: 'bp1', field_key: 'colors', field_type: 'table' },
      ]],
      [/user_templates/i, [
        { id: 't1', name: 'T1', blueprint_id: 'bp1', effective_blueprint_id: 'bp1',
          payload: JSON.stringify({ colors: 'plain string' }) },
      ]],
    ]);
    const rows = await scanFieldDataOrphans(c);
    assert.strictEqual(rows.length, 1);
    assert.strictEqual(rows[0].kind, 'type_mismatch');
    assert.strictEqual(rows[0].field_type, 'checkbox');
  });

  it('scanFieldDataOrphans: a scalar field is NEVER flagged (no data-loss path)', async () => {
    // KEY flip: a JSON array-string stranded under a text field (checkbox→text
    // residual) is NOT detected — the value could be legitimate JSON-in-text and
    // the payload carries no type tag. Accepted one-directional miss.
    const c = makeConn([
      [/blueprint_fields/i, [
        { blueprint_id: 'bp1', field_key: 'colors', field_type: 'text' },
      ]],
      [/user_templates/i, [
        { id: 't1', name: 'T1', blueprint_id: 'bp1', effective_blueprint_id: 'bp1',
          payload: JSON.stringify({ colors: '["a","b"]' }) },
      ]],
    ]);
    const rows = await scanFieldDataOrphans(c);
    assert.deepEqual(rows, []);
  });

  it('scanFieldDataOrphans: a VALID checkbox value is NOT flagged (anti-data-loss)', async () => {
    // A checkbox field whose stored value is the JSON string '["a"]' is VALID —
    // the scanner must NOT flag it, else the health tool would offer to DELETE
    // legitimate data.
    const c = makeConn([
      [/blueprint_fields/i, [
        { blueprint_id: 'bp1', field_key: 'colors', field_type: 'checkbox' },
      ]],
      [/user_templates/i, [
        { id: 't1', name: 'T1', blueprint_id: 'bp1', effective_blueprint_id: 'bp1',
          payload: JSON.stringify({ colors: '["a"]' }) },
      ]],
    ]);
    const rows = await scanFieldDataOrphans(c);
    assert.deepEqual(rows, []);
  });
});

// ─────────────────────────────────────────────────────────────────────
// GET /field-data-orphans — admin-only
// ─────────────────────────────────────────────────────────────────────

describe('POST /field-data-orphans — auth gate', () => {
  it('admin → 200 with orphan list', async () => {
    conn = makeConn([
      [/blueprint_fields/i, [{ blueprint_id: 'bp-1', field_key: 'a' }]],
      [/user_templates/i, [{ id: 't-1', name: 'T1', blueprint_id: 'bp-1', effective_blueprint_id: 'bp-1', payload: { a: 1, gone: 2 } }]],
    ]);
    const res = await req(adminPort, 'POST', '/edge/app/schema/field-data-orphans', {});
    assert.equal(res.status, 200);
    assert.equal(res.body.data.total, 1);
    assert.equal(res.body.data.orphans[0].orphan_key, 'gone');
  });

  it('editor → 200 with results scoped to owned/shared blueprints (owner_id stripped)', async () => {
    conn = makeConn([
      [/blueprint_fields/i, []],
      [/user_templates/i, [
        { id: 't-mine', name: 'Mine', blueprint_id: 'bp-mine', effective_blueprint_id: 'bp-mine', effective_bp_row_id: 'bp-mine', blueprint_owner_id: 'editor-1', payload: { gone: 1 } },
        { id: 't-shared', name: 'Shared', blueprint_id: 'bp-shared', effective_blueprint_id: 'bp-shared', effective_bp_row_id: 'bp-shared', blueprint_owner_id: null, payload: { gone: 1 } },
        { id: 't-other', name: 'Other', blueprint_id: 'bp-other', effective_blueprint_id: 'bp-other', effective_bp_row_id: 'bp-other', blueprint_owner_id: 'someone-else', payload: { gone: 1 } },
        // dangling: effective blueprint row missing (linked bp deleted) — NULL
        // owner only LOOKS shared. Editor must NOT see it (fail closed).
        { id: 't-dangling', name: 'Dangling', blueprint_id: 'bp-gone', effective_blueprint_id: 'bp-gone', effective_bp_row_id: null, blueprint_owner_id: null, payload: { gone: 1 } },
      ]],
    ]);
    const res = await req(editorPort, 'POST', '/edge/app/schema/field-data-orphans', {});
    assert.equal(res.status, 200);
    const bps = new Set(res.body.data.orphans.map((o) => o.blueprint_id));
    assert.ok(bps.has('bp-mine') && bps.has('bp-shared') && !bps.has('bp-other') && !bps.has('bp-gone'));
    assert.equal(res.body.data.total, 2);
    assert.ok(!JSON.stringify(res.body).includes('blueprint_owner_id'), 'owner id must not leak');
    assert.ok(!JSON.stringify(res.body).includes('effective_bp_row_id'), 'internal scoping field must not leak');
  });

  it('admin → 200 sees dangling-blueprint rows too (only editors fail closed)', async () => {
    conn = makeConn([
      [/blueprint_fields/i, []],
      [/user_templates/i, [
        { id: 't-dangling', name: 'Dangling', blueprint_id: 'bp-gone', effective_blueprint_id: 'bp-gone', effective_bp_row_id: null, blueprint_owner_id: null, payload: { gone: 1 } },
      ]],
    ]);
    const res = await req(adminPort, 'POST', '/edge/app/schema/field-data-orphans', {});
    assert.equal(res.status, 200);
    assert.equal(res.body.data.total, 1);
    assert.ok(!JSON.stringify(res.body).includes('effective_bp_row_id'), 'internal scoping field must not leak');
  });

  it('plain user → 403, no DB query issued', async () => {
    conn = makeConn([]); // no scripts — any DB call would throw
    const app = express();
    app.use(express.json());
    app.use((r, _res, next) => { r.user = { id: 'u-1', role: 'user' }; next(); });
    app.use('/edge/app/schema', router);
    const userServer = app.listen(0, '127.0.0.1');
    await new Promise((resolve) => userServer.on('listening', resolve));
    const userPort = userServer.address().port;
    const res = await req(userPort, 'POST', '/edge/app/schema/field-data-orphans', {});
    await new Promise((resolve) => userServer.close(resolve));
    assert.equal(res.status, 403);
    assert.equal(conn.queries.length, 0);
  });
});

// ─────────────────────────────────────────────────────────────────────
// DELETE /field-data-orphans/:templateId/:key — admin + blueprint owner
// ─────────────────────────────────────────────────────────────────────

describe('DELETE /field-data-orphans/:templateId/:key', () => {
  it('admin + valid key → 200 with stale-orphan-guarded JSON_REMOVE', async () => {
    let updateCaptured = null;
    conn = makeConn([
      [/UPDATE `fmb_user_templates`/i, (sql, params) => {
        updateCaptured = { sql, params };
        return { affectedRows: 1 };
      }],
    ]);
    const res = await req(adminPort, 'DELETE', '/edge/app/schema/field-data-orphans/t-1/stale_field');
    assert.equal(res.status, 200);
    assert.equal(res.body.data.removed_key, 'stale_field');
    assert.match(updateCaptured.sql, /JSON_REMOVE\(ut\.payload, \?\)/);
    // Path-existence (JSON_CONTAINS_PATH) instead of value-non-null
    // because JSON null values otherwise look "absent" to JSON_EXTRACT.
    assert.match(updateCaptured.sql, /JSON_CONTAINS_PATH\(ut\.payload, 'one', \?\) = 1/);
    // Stale-orphan guard with linked_blueprint_id resolution: subquery
    // bound against the EFFECTIVE blueprint so a re-created or linked
    // field protects valid user data from delete.
    assert.match(updateCaptured.sql, /LEFT JOIN `fmb_hierarchy_nodes` hn ON hn\.id = ut\.blueprint_id/);
    assert.match(updateCaptured.sql, /NOT EXISTS \(\s*SELECT 1 FROM `fmb_blueprint_fields` bf/);
    // BINARY comparison: JS scan is case-sensitive; SQL guard must match
    // so a key like "Name" (orphan vs only field "name") is cleanable.
    assert.match(
      updateCaptured.sql,
      new RegExp(`WHERE bf\\.blueprint_id = ${
        effectiveBlueprintIdSql('hn', 'ut').replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
      }\\s*AND bf\\.field_key = BINARY \\?`),
      'the delete re-check resolves the effective blueprint by some other expression than '
      + 'the scanner does, which is how it came to delete keys the scanner reported',
    );
    assert.deepEqual(updateCaptured.params, [
      '$."stale_field"',
      ...metadataClearParams('stale_field'),
      't-1', '$."stale_field"', 'stale_field',
    ]);
  });

  it('admin + key already cleaned OR field re-created (affectedRows=0) → 409 STALE_ORPHAN', async () => {
    conn = makeConn([
      [/UPDATE `fmb_user_templates`/i, { affectedRows: 0 }],
    ]);
    const res = await req(adminPort, 'DELETE', '/edge/app/schema/field-data-orphans/t-1/recently_re_added');
    assert.equal(res.status, 409);
    assert.equal(res.body.error.code, 'STALE_ORPHAN');
  });

  it('admin + legacy-format key (mixed case + dash) → cleanup succeeds with stale guard', async () => {
    let updateCaptured = null;
    conn = makeConn([
      [/UPDATE `fmb_user_templates`/i, (sql, params) => {
        updateCaptured = { sql, params };
        return { affectedRows: 1 };
      }],
    ]);
    const res = await req(adminPort, 'DELETE', '/edge/app/schema/field-data-orphans/t-1/OldName-v1');
    assert.equal(res.status, 200);
    assert.deepEqual(updateCaptured.params, [
      '$."OldName-v1"',
      ...metadataClearParams('OldName-v1'),
      't-1', '$."OldName-v1"', 'OldName-v1',
    ]);
  });

  it('admin + path-injection attempt (embedded double-quote) → 400, no DB query', async () => {
    conn = makeConn([]);
    const res = await req(adminPort, 'DELETE', '/edge/app/schema/field-data-orphans/t-1/' + encodeURIComponent('foo";1=1'));
    assert.equal(res.status, 400);
    assert.equal(conn.queries.length, 0);
  });

  it('admin + key longer than 256 chars → 400, no DB query', async () => {
    conn = makeConn([]);
    const longKey = 'x'.repeat(300);
    const res = await req(adminPort, 'DELETE', '/edge/app/schema/field-data-orphans/t-1/' + longKey);
    assert.equal(res.status, 400);
    assert.equal(conn.queries.length, 0);
  });

  it('editor non-owner → 404, JSON_REMOVE not run (existence not disclosed)', async () => {
    conn = makeConn([
      [/ehn\.owner_id AS owner_id/i, [{ ebp_id: 'bp-1', owner_id: 'someone-else' }]],
      [/UPDATE `fmb_user_templates`/i, { affectedRows: 1 }],
    ]);
    const res = await req(editorPort, 'DELETE', '/edge/app/schema/field-data-orphans/t-1/anything');
    assert.equal(res.status, 404);
    assert.equal(res.body.error.code, 'NOT_FOUND');
    assert.ok(!conn.queries.some((q) => /JSON_REMOVE/i.test(q.sql)), 'value must be preserved');
  });

  it('editor + dangling effective blueprint (ebp_id NULL) → 404, fail closed', async () => {
    // A NULL owner that comes from a MISSING effective-blueprint row only looks
    // shared. An editor must not be able to clear under it.
    conn = makeConn([
      [/ehn\.owner_id AS owner_id/i, [{ ebp_id: null, owner_id: null }]],
      [/UPDATE `fmb_user_templates`/i, { affectedRows: 1 }],
    ]);
    const res = await req(editorPort, 'DELETE', '/edge/app/schema/field-data-orphans/t-1/anything');
    assert.equal(res.status, 404);
    assert.equal(res.body.error.code, 'NOT_FOUND');
    assert.ok(!conn.queries.some((q) => /JSON_REMOVE/i.test(q.sql)), 'value must be preserved');
  });

  it('editor owner → 200, orphan cleanup proceeds', async () => {
    conn = makeConn([
      [/ehn\.owner_id AS owner_id/i, [{ ebp_id: 'bp-1', owner_id: 'editor-1' }]],
      [/UPDATE `fmb_user_templates`/i, { affectedRows: 1 }],
    ]);
    const res = await req(editorPort, 'DELETE', '/edge/app/schema/field-data-orphans/t-1/anything');
    assert.equal(res.status, 200);
    assert.equal(res.body.data.removed_key, 'anything');
  });

  it('editor shared blueprint (owner NULL, ebp row present) → 200, orphan cleanup proceeds', async () => {
    conn = makeConn([
      [/ehn\.owner_id AS owner_id/i, [{ ebp_id: 'bp-1', owner_id: null }]],
      [/UPDATE `fmb_user_templates`/i, { affectedRows: 1 }],
    ]);
    const res = await req(editorPort, 'DELETE', '/edge/app/schema/field-data-orphans/t-1/anything');
    assert.equal(res.status, 200);
  });

  it('plain user → 403, no DB query', async () => {
    conn = makeConn([]);
    const app = express();
    app.use(express.json());
    app.use((r, _res, next) => { r.user = { id: 'u-1', role: 'user' }; next(); });
    app.use('/edge/app/schema', router);
    const userServer = app.listen(0, '127.0.0.1');
    await new Promise((resolve) => userServer.on('listening', resolve));
    const userPort = userServer.address().port;
    const res = await req(userPort, 'DELETE', '/edge/app/schema/field-data-orphans/t-1/anything');
    await new Promise((resolve) => userServer.close(resolve));
    assert.equal(res.status, 403);
    assert.equal(conn.queries.length, 0);
  });
});

// ─────────────────────────────────────────────────────────────────────
// X-Database routing — the server injects req.body.db from the validated
// X-Database header (a schema NAME). A client body.db is never trusted; the
// x-database-validate middleware rejects it (see client-db-guard tests). These
// tests drive the real header-based contract: header in → server config out.
// ─────────────────────────────────────────────────────────────────────

describe('orphan endpoints — dynamic pool routing via X-Database header', () => {
  it('POST scan resolves to dynamic pool with the server-injected config', async () => {
    serverDbConfig = { host: 'h', port: 3306, user: 'u', password: 'p', database: 'tenant_b', tablePrefix: 'fmb_' };
    dynamicConn = makeConn([
      [/blueprint_fields/i, []],
      [/user_templates/i, []],
    ]);
    conn = makeConn([]); // default pool must NOT be touched
    const r2 = await req(adminPort, 'POST', '/edge/app/schema/field-data-orphans',
      {}, { 'X-Database': 'tenant_b' });
    assert.equal(r2.status, 200);
    // Pool opened with the SERVER config (middleware-injected), not a client value.
    assert.deepEqual(dynamicPoolRequestedFor,
      { host: 'h', port: 3306, user: 'u', password: 'p', database: 'tenant_b', tablePrefix: 'fmb_' });
    // Default pool's conn should be untouched
    assert.equal(conn.queries.length, 0);
  });

  it('DELETE resolves to dynamic pool with the server-injected config', async () => {
    serverDbConfig = { host: 'h2', port: 3307, user: 'u2', password: 'p2', database: 'tenant_c', tablePrefix: 'fmb_' };
    dynamicConn = makeConn([
      [/UPDATE `fmb_user_templates`/i, { affectedRows: 1 }],
    ]);
    conn = makeConn([]);
    const r2 = await req(adminPort, 'DELETE', '/edge/app/schema/field-data-orphans/t-1/some_key',
      {}, { 'X-Database': 'tenant_c' });
    assert.equal(r2.status, 200);
    assert.deepEqual(dynamicPoolRequestedFor,
      { host: 'h2', port: 3307, user: 'u2', password: 'p2', database: 'tenant_c', tablePrefix: 'fmb_' });
    assert.equal(conn.queries.length, 0);
    assert.equal(dynamicConn.queries.length, 1);
  });

  it('a client-supplied body.db is rejected at the boundary (400), pool untouched', async () => {
    serverDbConfig = { host: 'h', port: 3306, user: 'u', password: 'p', database: 'tenant_b', tablePrefix: 'fmb_' };
    conn = makeConn([]);
    const r2 = await req(adminPort, 'POST', '/edge/app/schema/field-data-orphans',
      { db: { host: '10.0.0.5', port: 6379, user: 'attacker', password: 'evil', database: 'sibling' } },
      { 'X-Database': 'tenant_b' });
    assert.equal(r2.status, 400);
    assert.equal(r2.body.error.code, 'CLIENT_DB_CONFIG_REJECTED');
    assert.equal(dynamicPoolRequestedFor, null); // no pool opened
    assert.equal(conn.queries.length, 0);
  });
});
