/**
 * compute-rule-graph-schema-parity.test.js — mechanical DDL agreement for the
 * SQL the two-level compute-cycle guard issues, WITHOUT a live DB.
 *
 * WHY: the route tests around this guard stub their query results, so a column
 * that exists only in code stays green in both runners and only fails against a
 * real database. Every query the guard runs is built by an exported builder, so
 * this test can read the SQL text back, pull the columns it references out of
 * it, and check each one against table-ddls.js — the single hand-authored
 * source of schema shape.
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');

const { TABLES } = require('../../src/shared/constants');
const { buildSchemaManifest } = require('../../src/edge/lib/schema-manifest');
const {
  buildBlueprintComputeSql,
  buildBlueprintFieldsComputeContextSql,
  buildVariantComputeRulesSql,
  buildBlueprintFieldComputeRuleSql,
  buildBlueprintFieldModeSql,
  buildBlueprintFieldColumnSql,
  MODE_READ_COLUMNS,
} = require('../../src/edge/lib/compute-rule-graph');
const { buildVariantOverrideContextSql } = require('../../src/edge/lib/variant-override-helpers');

// Identity `t` → logical (unprefixed) table names, matching the manifest keys.
const identity = (base) => base;
const manifest = buildSchemaManifest(identity);
const deps = { t: identity, TABLES };

const SQL_KEYWORDS = new Set([
  'select', 'from', 'join', 'left', 'right', 'inner', 'outer', 'on', 'where',
  'and', 'or', 'is', 'not', 'null', 'as', 'order', 'by', 'group', 'having',
  'limit', 'distinct', 'in', 'exists', 'case', 'when', 'then', 'else', 'end',
]);

// Table aliases declared by the query, e.g. FROM `variant_overrides` vo.
function aliasMap(sql) {
  const aliases = new Map();
  const re = /(?:FROM|JOIN)\s+`([^`]+)`(?:\s+(?:AS\s+)?([A-Za-z_][A-Za-z0-9_]*))?/gi;
  let m;
  while ((m = re.exec(sql)) !== null) {
    const alias = m[2] && !SQL_KEYWORDS.has(m[2].toLowerCase()) ? m[2] : null;
    if (alias) aliases.set(alias, m[1]);
  }
  return aliases;
}

function tablesIn(sql) {
  return [...sql.matchAll(/(?:FROM|JOIN)\s+`([^`]+)`/gi)].map((m) => m[1]);
}

/**
 * Every (table, column) pair the SQL reads. Qualified references resolve
 * through the alias map; a single-table query with no alias attributes its bare
 * identifiers to that table. An aliased query in this codebase qualifies every
 * column, so bare identifiers there are output aliases and are skipped.
 */
function referencedColumns(sql) {
  const aliases = aliasMap(sql);
  const refs = [];
  for (const m of sql.matchAll(/\b([A-Za-z_][A-Za-z0-9_]*)\.([A-Za-z_][A-Za-z0-9_]*)\b/g)) {
    const table = aliases.get(m[1]);
    if (table) refs.push([table, m[2]]);
  }
  if (aliases.size === 0) {
    const tables = tablesIn(sql);
    assert.equal(tables.length, 1, `cannot attribute bare columns in: ${sql}`);
    // Drop quoted literals and backtick-quoted table names first, so neither
    // contributes a phantom column name.
    const bare = sql.replace(/'[^']*'/g, ' ').replace(/`[^`]*`/g, ' ');
    for (const m of bare.matchAll(/(?<![.\w])([A-Za-z_][A-Za-z0-9_]*)/g)) {
      if (SQL_KEYWORDS.has(m[1].toLowerCase())) continue;
      refs.push([tables[0], m[1]]);
    }
  }
  return refs;
}

function assertColumnsExist(label, sql) {
  const refs = referencedColumns(sql);
  assert.ok(refs.length > 0, `${label}: no column references parsed — the extractor lost sight of the SQL`);
  for (const [table, column] of refs) {
    const entry = manifest.get(table);
    assert.ok(entry, `${label}: table-ddls.js declares no table '${table}'`);
    assert.ok(
      entry.columns.includes(column),
      `${label}: ${table} has no column '${column}' in table-ddls.js`,
    );
  }
}

describe('compute-cycle guard SQL references only declared columns', () => {
  it('blueprint compute scan (context + rules in one)', () => {
    assertColumnsExist('blueprint compute scan', buildBlueprintComputeSql(deps));
  });

  it('blueprint field context query (the no-compute_rule-column fallback)', () => {
    assertColumnsExist('blueprint field context', buildBlueprintFieldsComputeContextSql(deps));
  });

  it('variant-level compute rules query', () => {
    assertColumnsExist('variant compute rules', buildVariantComputeRulesSql(deps));
  });

  it('variant override context query', () => {
    assertColumnsExist('variant override context', buildVariantOverrideContextSql(deps));
  });

  it('single-field blueprint rule query', () => {
    assertColumnsExist('single-field blueprint rule', buildBlueprintFieldComputeRuleSql(deps));
  });

  it('single-field mode query (all three columns)', () => {
    assertColumnsExist('single-field mode', buildBlueprintFieldModeSql(deps));
  });

  it('single-field mode query (each column of the per-column fallback)', () => {
    for (const column of MODE_READ_COLUMNS) {
      assertColumnsExist(`single-field mode: ${column}`, buildBlueprintFieldColumnSql(column, deps));
    }
  });
});

describe('the mode read degrades over columns that are really independent', () => {
  it('reads each column in isolation, so one absent column cannot hide a present one', () => {
    const combined = buildBlueprintFieldModeSql(deps);
    for (const column of MODE_READ_COLUMNS) {
      assert.match(combined, new RegExp(`\\b${column}\\b`),
        'the combined read must name every column the fallback re-reads');
      const single = buildBlueprintFieldColumnSql(column, deps);
      assert.match(single, new RegExp(`^SELECT ${column} FROM`));
      assert.match(single, /WHERE id = \?/);
      for (const other of MODE_READ_COLUMNS.filter((c) => c !== column)) {
        assert.ok(
          !new RegExp(`\\b${other}\\b`).test(single),
          `the ${column} read must not name ${other} — 1054 would take both down`,
        );
      }
    }
  });

  it('both mode columns are separate registry steps, so neither implies the other', () => {
    const { MIGRATION_STEPS } = require('../../src/edge/migration-steps');
    const modeColumns = MIGRATION_STEPS
      .filter((s) => s.table === TABLES.BLUEPRINT_FIELDS
        && ['value_source', 'value_scope'].includes(s.column))
      .map((s) => s.column);
    assert.deepEqual(
      [...new Set(modeColumns)].sort(), ['value_scope', 'value_source'],
      'one step per column is what makes the half-migrated DB reachable',
    );
  });
});

describe('the columns the guard depends on by name', () => {
  it('reads the blueprint-level rule from blueprint_fields.compute_rule', () => {
    const sql = buildBlueprintComputeSql(deps);
    assert.match(sql, /compute_rule/);
    assert.ok(manifest.get('blueprint_fields').columns.includes('compute_rule'));
  });

  it('takes the field context from that same scan, so the two cannot drift apart', () => {
    const sql = buildBlueprintComputeSql(deps);
    for (const column of ['field_key', 'field_type', 'table_config', 'compute_rule']) {
      assert.match(sql, new RegExp(`\\b${column}\\b`));
      assert.ok(manifest.get('blueprint_fields').columns.includes(column));
    }
  });

  it('joins variant overrides to their field to recover field_key', () => {
    const sql = buildVariantComputeRulesSql(deps);
    assert.match(sql, /bf\.field_key/);
    assert.match(sql, /bf\.id = vo\.field_id/);
    assert.match(sql, /vo\.action = 'compute'/);
  });

  it('addresses the single-field rule read by id, so it cannot pick up a sibling field', () => {
    const sql = buildBlueprintFieldComputeRuleSql(deps);
    assert.match(sql, /WHERE id = \?/);
    assert.match(sql, /compute_rule/);
    assert.ok(manifest.get('blueprint_fields').columns.includes('compute_rule'));
  });

  it('carries the field type into the override context, so cell targets can be gated on it', () => {
    assert.match(buildVariantOverrideContextSql(deps), /f\.field_type/);
    assert.ok(manifest.get('blueprint_fields').columns.includes('field_type'));
  });
});
