/**
 * factory-linked-toctou.test.js — 2a.
 *
 * The factory write-path linked-blueprint guard now runs inside the write
 * transaction with a FOR UPDATE row lock (guarded mounts only). Asserts:
 *   - guarded POST/PUT issue beginTransaction + FOR UPDATE + commit/rollback;
 *   - a linked target → 409 LINKED_BLUEPRINT_READONLY (rolled back);
 *   - an unlinked target commits the write;
 *   - a NON-guarded table issues NO beginTransaction and NO FOR UPDATE (no-impact);
 *   - the custom blueprint_fields PUT lock-checks with FOR UPDATE.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const { answerParentIdProbe } = require('../helpers/parent-id-probe');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../src/edge/db');
const { answerCanonicalUserProbe } = require('../helpers/canonical-user-probe');

// The owner ids these bodies name. A body that carries `owner_id` now has it
// resolved against the users table before the statement binds it, so a double
// with no users would refuse the write rather than exercise the path under test.
const FIXTURE_USERS = [
  { id: '5b729f1e-5c0b-447c-8144-3210469bc62c', role: 'admin' },
];

let conn;
function makeConn(scripts) {
  const queries = [];
  const c = {
    queries, beginCount: 0, commitCount: 0, rollbackCount: 0,
    async query(sql, params) {
      queries.push({ sql, params });
      for (const [m, r] of scripts) if (m.test(sql)) return typeof r === 'function' ? r(sql, params) : r;
      // The factory asks which spelling the parent row really carries before it
      // binds one, and — for an owner the BODY named — which user row that
      // spelling names. Both answered rather than thrown on; see tests/helpers.
      const parentId = answerParentIdProbe(sql, params);
      if (parentId) return parentId;
      const ownerRow = answerCanonicalUserProbe(sql, params, FIXTURE_USERS);
      if (ownerRow) return ownerRow;
      throw new Error(`Unmatched query: ${sql.slice(0, 140)}`);
    },
    release() {},
    async beginTransaction() { c.beginCount++; },
    async commit() { c.commitCount++; },
    async rollback() { c.rollbackCount++; },
  };
  return c;
}
function sqls(c) { return c.queries.map((q) => q.sql).join('\n'); }

const poolSpy = {
  rw: { async getConnection() { return conn; } },
  ro: { async getConnection() { return conn; } },
};

require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: {
    pool: poolSpy,
    t: (name) => `fmb_${name}`,
    getDynamicPool: async () => poolSpy,
    PLATFORM_SCHEMA_VERSION: '0.0.0-test',
  },
};

const router = require('../../src/edge/routes/app/schema');
const { __clearColumnSetCache } = router.__test__;

function makeApp(role) {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { req.user = { id: `${role}-1`, role }; next(); });
  app.use('/edge/app/schema', router);
  return app;
}

let server; let port;
before(async () => {
  const app = makeApp('admin');
  await new Promise((resolve) => { server = app.listen(0, '127.0.0.1', () => { port = server.address().port; resolve(); }); });
});
after(async () => { await new Promise((resolve) => server.close(resolve)); delete require.cache[dbKey]; });
beforeEach(() => { conn = null; __clearColumnSetCache(); });

function request(method, path, body) {
  return new Promise((resolve, reject) => {
    const data = body !== undefined ? JSON.stringify(body) : '';
    const headers = data ? { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(data) } : {};
    const req = http.request({ method, host: '127.0.0.1', port, path: `/edge/app/schema${path}`, headers }, (res) => {
      let raw = '';
      res.on('data', (c) => { raw += c; });
      res.on('end', () => resolve({ status: res.statusCode, body: raw ? JSON.parse(raw) : null }));
    });
    req.on('error', reject);
    if (data) req.write(data);
    req.end();
  });
}

const COLSET = [/information_schema|DATABASE\(\)/i, []];

describe('factory write-path TOCTOU (FOR UPDATE)', () => {
  it('guarded POST: beginTransaction + FOR UPDATE + 409 (rolled back) on a linked target', async () => {
    conn = makeConn([
      COLSET,
      [/SELECT linked_blueprint_id FROM `fmb_hierarchy_nodes`.*FOR UPDATE/s, [{ linked_blueprint_id: '0f1b876a-61af-4a1a-8e36-ae28dca1db1f' }]],
    ]);
    const res = await request('POST', '/blueprint_sections', { id: '0e06856e-f316-4505-8a20-d5cbdc42bd73', blueprint_id: 'd9919285-2e62-4fe9-879f-96dff5e2acf4', name: 'S' });
    assert.equal(res.status, 409);
    assert.equal(res.body.error.code, 'LINKED_BLUEPRINT_READONLY');
    assert.equal(conn.beginCount, 1);
    assert.equal(conn.rollbackCount, 1);
    assert.match(sqls(conn), /FOR UPDATE/);
  });

  it('guarded POST: commits the INSERT when the target is not linked', async () => {
    conn = makeConn([
      [/SELECT linked_blueprint_id FROM `fmb_hierarchy_nodes`.*FOR UPDATE/s, [{ linked_blueprint_id: null }]],
      COLSET,
      [/INSERT INTO `fmb_blueprint_sections`/, { affectedRows: 1 }],
      [/SELECT \* FROM `fmb_blueprint_sections` WHERE id = \?/, [{ id: '0e06856e-f316-4505-8a20-d5cbdc42bd73', blueprint_id: 'd9919285-2e62-4fe9-879f-96dff5e2acf4', name: 'S' }]],
    ]);
    const res = await request('POST', '/blueprint_sections', { id: '0e06856e-f316-4505-8a20-d5cbdc42bd73', blueprint_id: 'd9919285-2e62-4fe9-879f-96dff5e2acf4', name: 'S' });
    assert.equal(res.status, 200);
    assert.equal(conn.commitCount, 1);
    assert.equal(conn.rollbackCount, 0);
  });

  it('NON-guarded POST: NO beginTransaction and NO FOR UPDATE (no-impact)', async () => {
    conn = makeConn([
      COLSET,
      [/INSERT INTO `fmb_user_templates`/, { affectedRows: 1 }],
      [/SELECT \* FROM `fmb_user_templates` WHERE id = \?/, [{ id: '938601ed-783a-4beb-8fad-af1f11ab0f63', owner_id: '5b729f1e-5c0b-447c-8144-3210469bc62c' }]],
    ]);
    const res = await request('POST', '/user_templates', { id: '938601ed-783a-4beb-8fad-af1f11ab0f63', owner_id: '5b729f1e-5c0b-447c-8144-3210469bc62c', payload: {} });
    assert.equal(res.status, 200);
    assert.equal(conn.beginCount, 0);
    assert.doesNotMatch(sqls(conn), /FOR UPDATE/);
  });

  it('guarded PUT: 409 + rollback on a linked target', async () => {
    conn = makeConn([
      COLSET,
      [/SELECT `blueprint_id` AS bid FROM `fmb_blueprint_sections` WHERE id = \?/, [{ bid: 'd9919285-2e62-4fe9-879f-96dff5e2acf4' }]],
      [/SELECT linked_blueprint_id FROM `fmb_hierarchy_nodes`.*FOR UPDATE/s, [{ linked_blueprint_id: '0f1b876a-61af-4a1a-8e36-ae28dca1db1f' }]],
    ]);
    const res = await request('PUT', '/blueprint_sections/s1', { name: 'S2' });
    assert.equal(res.status, 409);
    assert.equal(conn.beginCount, 1);
    assert.equal(conn.rollbackCount, 1);
  });

  it('custom blueprint_fields PUT: lock-checks with FOR UPDATE', async () => {
    conn = makeConn([
      COLSET,
      [/FROM `fmb_blueprint_fields` WHERE id = \?/, [{ id: 'b630a50b-4ef8-45c6-80b9-3eca727bd015', blueprint_id: 'd9919285-2e62-4fe9-879f-96dff5e2acf4', field_type: 'text' }]],
      [/SELECT linked_blueprint_id FROM `fmb_hierarchy_nodes`.*FOR UPDATE/s, [{ linked_blueprint_id: '0f1b876a-61af-4a1a-8e36-ae28dca1db1f' }]],
    ]);
    const res = await request('PUT', '/blueprint_fields/f1', { field_label: 'X' });
    assert.equal(res.status, 409);
    assert.equal(res.body.error.code, 'LINKED_BLUEPRINT_READONLY');
    assert.match(sqls(conn), /FOR UPDATE/);
    assert.equal(conn.beginCount, 1);
    assert.equal(conn.rollbackCount, 1);
  });
});
