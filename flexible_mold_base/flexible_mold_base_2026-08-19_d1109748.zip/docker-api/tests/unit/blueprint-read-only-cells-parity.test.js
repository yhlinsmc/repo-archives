/**
 * The SERVER half of the shared case list for "which cells does this field's own
 * setting hold read-only".
 *
 * The FE twin is src/fmb/lib/blueprint-read-only-cells.parity.test.ts, and it
 * reads the same JSON. Edit cases in the JSON only: a change to one
 * implementation that the other does not make fails the other side's run.
 *
 * The two functions cannot be one module — one is CommonJS inside the API image,
 * the other is bundled into the SPA — so this list is what keeps them honest,
 * and it states the cases where they deliberately differ rather than omitting
 * them. See the `_doc` block in the JSON.
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');

const fixture = require('../../../src/fmb/lib/__fixtures__/blueprint-read-only-cells.cases.json');
const {
  __test__, refuseCellWriteOverBlueprintLock,
} = require('../../src/edge/lib/blueprint-cell-lock');

const { blueprintReadOnlyCells } = __test__;

/** Sets → the fixture's shape, so the comparison is about the answer. */
function canon(answer) {
  if (answer === null) return null;
  const scope = answer.scope;
  if (scope === null) return { by: answer.by, scope: null };
  return {
    by: answer.by,
    scope: {
      rows: scope.rows === null ? null : [...scope.rows],
      columns: scope.columns === null ? null : [...scope.columns],
    },
  };
}

describe('blueprintReadOnlyCells — shared case list with the resolver', () => {
  it('covers every case in the fixture', () => {
    assert.ok(fixture.cases.length > 0);
  });

  for (const c of fixture.cases) {
    it(c.name, () => {
      const actual = canon(blueprintReadOnlyCells({
        valueSource: c.field.value_source,
        valueScope: c.field.value_scope,
        computeRule: c.field.compute_rule,
      }));
      assert.deepEqual(actual, c.server);
    });
  }
});

// The second level, matching the client suite: what the write boundary DOES
// with the answer. Pinning answers alone let an enforcement gap sit behind a
// comment claiming this list covered it.
describe('the write boundary enforces the answer', () => {
  for (const c of fixture.cases) {
    it(`${c.enforcement.server} a cell-scoped autofill on the probed cell — ${c.name}`, () => {
      const refusal = refuseCellWriteOverBlueprintLock(
        'autofill',
        { rows: [c.probeCell.row], columns: [c.probeCell.column] },
        {
          valueSource: c.field.value_source,
          valueScope: c.field.value_scope,
          computeRule: c.field.compute_rule,
        },
      );
      if (c.enforcement.server === 'refuses') {
        assert.ok(refusal, 'the guard must refuse this override');
        assert.equal(refusal.status, 422);
      } else {
        assert.equal(refusal, null, 'the guard must allow this override');
      }
    });
  }

  it('the two sides disagree on exactly the rows the fixture says they do', () => {
    // Read off the data rather than restated here, so the count cannot drift
    // from the cases: wherever the boundary refuses and the runtime writes, the
    // guard is stopping something the resolver would not have withheld.
    const diverging = fixture.cases.filter(
      (c) => c.enforcement.server === 'refuses' && c.enforcement.client === 'writes',
    );
    assert.deepEqual(diverging.map((c) => c.name), [
      "a non-overridable rule under a compute-backed mode is the rule's lock",
      'a copied field is its non-overridable mirror rule',
      'DIVERGENCE — no value_source column at all, with a non-overridable rule',
    ]);
  });
});
