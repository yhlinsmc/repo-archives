/**
 * field-options-by-fields.test.js
 *
 * HTTP integration (spy pool) for POST /field_options/by-fields — the batch
 * read that replaces the per-field-id GET fan-out. Verifies: a single SELECT
 * with a parameterised `field_id IN (...)` over the RO pool; valid_parent_values
 * is parsed to an array (mapRowsFromDb ran); empty list short-circuits without a
 * query; malformed bodies 400; unauthenticated 401.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../src/edge/db');

let options; // seeded rows: { id, field_id, option_label, option_value, sort_order, valid_parent_values(JSON string|null) }
let queries; // every SQL the handler emitted
let usedRoPool; // true once the RO pool handed out a connection
let currentUser;

function makeSpyConn() {
  return {
    query: async (sql, params = []) => {
      queries.push({ sql, params });
      if (/SELECT \* FROM `fmb_field_options`[\s\S]*WHERE field_id IN/i.test(sql)) {
        return options.filter((o) => params.includes(o.field_id)).map((o) => ({ ...o }));
      }
      return [];
    },
    release: () => {},
  };
}

const poolSpy = {
  rw: { getConnection: async () => makeSpyConn() },
  ro: { getConnection: async () => { usedRoPool = true; return makeSpyConn(); } },
};

require.cache[dbKey] = {
  id: dbKey,
  filename: dbKey,
  loaded: true,
  exports: {
    pool: poolSpy,
    t: (name) => `fmb_${name}`,
    getDynamicPool: async () => poolSpy,
  },
};

const router = require('../../src/edge/routes/app/schema');

let server;
let port;

before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { req.user = currentUser; next(); });
  app.use('/edge/app/schema', router);
  await new Promise((resolve) => {
    server = app.listen(0, '127.0.0.1', () => { port = server.address().port; resolve(); });
  });
});

after(async () => {
  await new Promise((resolve) => server.close(resolve));
  delete require.cache[dbKey];
});

beforeEach(() => {
  queries = [];
  usedRoPool = false;
  currentUser = { id: 'u-1', email: 'u@test', role: 'user' };
  options = [
    { id: 'o1', field_id: 'f1', option_label: 'Alpha', option_value: 'a', sort_order: 0, valid_parent_values: '["cat_x"]' },
    { id: 'o2', field_id: 'f1', option_label: 'Beta', option_value: 'b', sort_order: 1, valid_parent_values: null },
    { id: 'o3', field_id: 'f2', option_label: 'Gamma', option_value: 'g', sort_order: 0, valid_parent_values: '["cat_y"]' },
  ];
});

function postJson(path_, body) {
  return new Promise((resolve, reject) => {
    const data = Buffer.from(JSON.stringify(body), 'utf-8');
    const req = http.request(
      { host: '127.0.0.1', port, path: path_, method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Content-Length': data.length } },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          const raw = Buffer.concat(chunks).toString('utf-8');
          let json = null;
          try { json = raw ? JSON.parse(raw) : null; } catch { /* */ }
          resolve({ status: res.statusCode, raw, json });
        });
      },
    );
    req.on('error', reject);
    req.write(data);
    req.end();
  });
}

const PATH = '/edge/app/schema/field_options/by-fields';

describe('POST /field_options/by-fields', () => {
  it('returns the rows for all field ids in one parameterised IN query', async () => {
    const res = await postJson(PATH, { field_ids: ['f1', 'f2'] });
    assert.equal(res.status, 200);
    const rows = res.json.data;
    assert.equal(rows.length, 3);
    assert.deepEqual(rows.map((r) => r.id).sort(), ['o1', 'o2', 'o3']);

    // Exactly one SELECT, RO pool, parameterised IN with the ids (no fan-out).
    const selects = queries.filter((q) => /SELECT \* FROM `fmb_field_options`[\s\S]*WHERE field_id IN/i.test(q.sql));
    assert.equal(selects.length, 1);
    assert.match(selects[0].sql, /field_id IN \(\?, \?\)/);
    assert.deepEqual(selects[0].params, ['f1', 'f2']);
    assert.equal(usedRoPool, true);
  });

  it('parses valid_parent_values to an array (cascade contract preserved)', async () => {
    const res = await postJson(PATH, { field_ids: ['f1'] });
    assert.equal(res.status, 200);
    const o1 = res.json.data.find((r) => r.id === 'o1');
    assert.deepEqual(o1.valid_parent_values, ['cat_x']); // JSON string → array
    const o2 = res.json.data.find((r) => r.id === 'o2');
    assert.equal(o2.valid_parent_values, null); // null stays null
  });

  it('short-circuits an empty id list with no query', async () => {
    const res = await postJson(PATH, { field_ids: [] });
    assert.equal(res.status, 200);
    assert.deepEqual(res.json.data, []);
    assert.equal(queries.length, 0);
  });

  it('rejects a non-array field_ids', async () => {
    const res = await postJson(PATH, { field_ids: 'f1' });
    assert.equal(res.status, 400);
    assert.equal(queries.length, 0);
  });

  it('rejects an over-cap id list', async () => {
    const res = await postJson(PATH, { field_ids: Array.from({ length: 1001 }, (_, i) => `f${i}`) });
    assert.equal(res.status, 400);
    assert.equal(queries.length, 0);
  });

  it('rejects a non-string id element', async () => {
    const res = await postJson(PATH, { field_ids: ['f1', 123] });
    assert.equal(res.status, 400);
    assert.equal(queries.length, 0);
  });

  it('rejects an empty-string id element', async () => {
    const res = await postJson(PATH, { field_ids: ['f1', ''] });
    assert.equal(res.status, 400);
    assert.equal(queries.length, 0);
  });

  it('401s an unauthenticated request', async () => {
    currentUser = null;
    const res = await postJson(PATH, { field_ids: ['f1'] });
    assert.equal(res.status, 401);
    assert.equal(queries.length, 0);
  });
});
