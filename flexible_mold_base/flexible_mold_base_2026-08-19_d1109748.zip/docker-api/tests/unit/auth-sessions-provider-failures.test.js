/**
 * auth-sessions-provider-failures.test.js
 *
 * Recent Logins freshness work: the sessions endpoint stopped filtering to
 * KEYCLOAK-only successes (so LOCAL logins show too), surfaces the provider
 * per row, and gains an opt-in `include_failures=1` branch that returns the
 * most recent failed attempts with their reason.
 *
 * Run: node --test docker-api/tests/unit/auth-sessions-provider-failures.test.js
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../src/edge/db');
const routeKey = require.resolve('../../src/edge/routes/platform/auth-sessions');

let calls;

function makeSpy() {
  calls = { ro: 0, roQueries: [] };
  return {
    rw: {
      async getConnection() {
        throw new Error('auth-sessions must use pool.ro');
      },
    },
    ro: {
      async getConnection() {
        calls.ro++;
        return {
          async query(sql, params) {
            calls.roQueries.push({ sql, params });
            const norm = sql.replace(/\s+/g, ' ');
            if (/COUNT\(DISTINCT/.test(norm)) return [{ total: 1 }];
            if (/today_count/.test(norm)) return [{ today_count: 2 }];
            if (/success = FALSE/.test(norm)) {
              return [{
                username: 'bob', deptid: 'qa', auth_provider: 'LOCAL',
                reason: 'invalid_password', login_at: '2026-01-02T00:00:00Z',
              }];
            }
            // data (dedup) query
            return [{
              username: 'alice', deptid: 'eng', auth_provider: 'KEYCLOAK',
              last_login: '2026-01-01T00:00:00Z', login_count: 3,
            }];
          },
          release() { /* noop */ },
        };
      },
    },
  };
}

const poolSpy = {};

require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: poolSpy, t: (name) => `fmb_${name}` },
};

const router = require('../../src/edge/routes/platform/auth-sessions');

let server;
let port;

before(async () => {
  Object.assign(poolSpy, makeSpy());
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { req.user = { id: 't', role: 'admin' }; next(); });
  app.use('/edge/platform/auth', router);
  await new Promise((resolve) => {
    server = app.listen(0, '127.0.0.1', () => { port = server.address().port; resolve(); });
  });
});

after(async () => {
  await new Promise((resolve) => server.close(resolve));
  delete require.cache[dbKey];
  delete require.cache[routeKey];
});

beforeEach(() => { Object.assign(poolSpy, makeSpy()); });

function getJson(path_) {
  return new Promise((resolve, reject) => {
    const req = http.request(
      { host: '127.0.0.1', port, path: path_, method: 'GET' },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          const raw = Buffer.concat(chunks).toString('utf-8');
          let json = null;
          try { json = JSON.parse(raw); } catch { /* noop */ }
          resolve({ status: res.statusCode, raw, json });
        });
      },
    );
    req.on('error', reject);
    req.end();
  });
}

describe('GET /sessions — provider surface + all-provider successes', () => {
  it('data query no longer filters to KEYCLOAK and selects/groups auth_provider', async () => {
    const res = await getJson('/edge/platform/auth/sessions');
    assert.equal(res.status, 200, res.raw);
    const dataQ = calls.roQueries.find((q) => /GROUP BY/.test(q.sql)).sql.replace(/\s+/g, ' ');
    assert.ok(!/auth_provider = 'KEYCLOAK'/.test(dataQ), 'KEYCLOAK-only filter must be gone');
    assert.ok(/success = TRUE/.test(dataQ), 'still success-only');
    assert.ok(/auth_provider/.test(dataQ.split('GROUP BY')[1]), 'auth_provider in GROUP BY');
  });

  it('each row carries its provider', async () => {
    const res = await getJson('/edge/platform/auth/sessions');
    assert.equal(res.json.data.items[0].provider, 'KEYCLOAK');
  });

  it('default response omits failures and runs only 3 aggregates', async () => {
    const res = await getJson('/edge/platform/auth/sessions');
    assert.equal(res.json.data.failures, undefined);
    assert.equal(calls.roQueries.length, 3);
  });
});

describe('GET /sessions?include_failures=1', () => {
  it('runs a 4th query for failures and returns them with reason + provider', async () => {
    const res = await getJson('/edge/platform/auth/sessions?include_failures=1');
    assert.equal(res.status, 200, res.raw);
    assert.equal(calls.roQueries.length, 4);
    const failQ = calls.roQueries.find((q) => /success = FALSE/.test(q.sql));
    assert.ok(failQ, 'a success=FALSE query must run');
    assert.equal(res.json.data.failures.length, 1);
    assert.equal(res.json.data.failures[0].username, 'bob');
    assert.equal(res.json.data.failures[0].provider, 'LOCAL');
    assert.equal(res.json.data.failures[0].reason, 'invalid_password');
  });
});
