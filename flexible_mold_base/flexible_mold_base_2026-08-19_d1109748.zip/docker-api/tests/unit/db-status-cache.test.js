const { test, beforeEach, afterEach } = require('node:test');
const assert = require('node:assert/strict');

const dbPath = require.resolve('../../src/edge/db');
const dbConnectPath = require.resolve('../../src/edge/routes/platform/setup/db-connect');

function clearCache() {
  delete require.cache[dbPath];
  delete require.cache[dbConnectPath];
}

function loadHandlers(stubImpl) {
  clearCache();
  const dbModule = require('../../src/edge/db');
  Object.assign(dbModule, stubImpl);
  const register = require('../../src/edge/routes/platform/setup/db-connect');

  let getStatus = null;
  let postConfigure = null;
  register({
    get(path, h) {
      if (path === '/db-status') getStatus = h;
    },
    post(path, h) {
      if (path === '/configure-db') postConfigure = h;
    },
  });
  return { getStatus, postConfigure, mod: require('../../src/edge/routes/platform/setup/db-connect') };
}

function makeRes() {
  return {
    statusCode: 200,
    body: null,
    status(code) { this.statusCode = code; return this; },
    json(body) { this.body = body; return this; },
  };
}

const ORIGINAL_TTL = process.env.DB_STATUS_CACHE_TTL_MS;

beforeEach(() => {
  delete process.env.DB_STATUS_CACHE_TTL_MS;
});

afterEach(() => {
  if (ORIGINAL_TTL === undefined) delete process.env.DB_STATUS_CACHE_TTL_MS;
  else process.env.DB_STATUS_CACHE_TTL_MS = ORIGINAL_TTL;
  clearCache();
});

test('db-status cache: hit within TTL avoids recompute', () => {
  let getDbConfigCalls = 0;
  const { getStatus } = loadHandlers({
    isPoolReady: () => true,
    getDbConfig: () => {
      getDbConfigCalls += 1;
      return { source: 'file', host: 'h', port: 3306, user: 'u', database: 'd', tablePrefix: 'p_' };
    },
    getDbConfigFull: () => null,
    configurePool: async () => {},
    saveConfig: () => {},
    t: (n) => `t_${n}`,
    pool: { rw: { async getConnection() { return { query: async () => {}, release() {} }; } } },
  });

  const res1 = makeRes();
  getStatus({}, res1);
  const res2 = makeRes();
  getStatus({}, res2);

  assert.equal(res1.statusCode, 200);
  assert.equal(res2.statusCode, 200);
  assert.equal(getDbConfigCalls, 1, 'second call within TTL must hit cache');
  assert.deepEqual(res1.body, res2.body);
});

test('db-status cache: TTL expiry forces recompute', async () => {
  process.env.DB_STATUS_CACHE_TTL_MS = '20';
  let getDbConfigCalls = 0;
  const { getStatus } = loadHandlers({
    isPoolReady: () => true,
    getDbConfig: () => {
      getDbConfigCalls += 1;
      return { source: 'file', host: 'h', port: 3306, user: 'u', database: 'd', tablePrefix: 'p_' };
    },
    getDbConfigFull: () => null,
    configurePool: async () => {},
    saveConfig: () => {},
    t: (n) => `t_${n}`,
    pool: { rw: { async getConnection() { return { query: async () => {}, release() {} }; } } },
  });

  const res1 = makeRes();
  getStatus({}, res1);
  await new Promise((r) => setTimeout(r, 40));
  const res2 = makeRes();
  getStatus({}, res2);

  assert.equal(getDbConfigCalls, 2, 'TTL expiry must trigger recompute');
});

test('db-status cache: TTL=0 disables cache entirely (every call recomputes)', () => {
  process.env.DB_STATUS_CACHE_TTL_MS = '0';
  let getDbConfigCalls = 0;
  const { getStatus } = loadHandlers({
    isPoolReady: () => true,
    getDbConfig: () => {
      getDbConfigCalls += 1;
      return { source: 'file', host: 'h', port: 3306, user: 'u', database: 'd', tablePrefix: 'p_' };
    },
    getDbConfigFull: () => null,
    configurePool: async () => {},
    saveConfig: () => {},
    t: (n) => `t_${n}`,
    pool: { rw: { async getConnection() { return { query: async () => {}, release() {} }; } } },
  });

  const res1 = makeRes();
  getStatus({}, res1);
  const res2 = makeRes();
  getStatus({}, res2);
  const res3 = makeRes();
  getStatus({}, res3);

  assert.equal(getDbConfigCalls, 3, 'TTL=0 must mean no cache, every call recomputes');
});

test('db-status cache: configurePool success invalidates cache', async () => {
  let getDbConfigCalls = 0;
  let database = 'old_db';
  const { getStatus, postConfigure } = loadHandlers({
    isPoolReady: () => true,
    getDbConfig: () => {
      getDbConfigCalls += 1;
      return { source: 'file', host: 'h', port: 3306, user: 'u', database, tablePrefix: 'p_' };
    },
    getDbConfigFull: () => null,
    configurePool: async () => {
      database = 'new_db';
    },
    saveConfig: () => {},
    t: (n) => `t_${n}`,
    pool: { rw: { async getConnection() { return { query: async () => {}, release() {} }; } } },
  });

  const res1 = makeRes();
  getStatus({}, res1);
  assert.equal(res1.body.data.database, 'old_db');

  const cfgRes = makeRes();
  await postConfigure({
    body: {
      host: 'h', port: 3306, user: 'u', password: 's', database: 'new_db', tablePrefix: 'p_',
    },
    user: { id: 'admin', role: 'admin' },
  }, cfgRes);
  assert.equal(cfgRes.statusCode, 200);

  const res2 = makeRes();
  getStatus({}, res2);
  assert.equal(res2.body.data.database, 'new_db', 'after configurePool the next status must be fresh');
  assert.ok(getDbConfigCalls >= 2);
});

test('db-status cache: configurePool failure also invalidates cache', async () => {
  let getDbConfigCalls = 0;
  const { getStatus, postConfigure } = loadHandlers({
    isPoolReady: () => true,
    getDbConfig: () => {
      getDbConfigCalls += 1;
      return { source: 'file', host: 'h', port: 3306, user: 'u', database: 'd', tablePrefix: 'p_' };
    },
    getDbConfigFull: () => null,
    configurePool: async () => {
      const err = new Error('connection refused');
      err.code = 'ECONNREFUSED';
      throw err;
    },
    saveConfig: () => {},
    t: (n) => `t_${n}`,
    pool: { rw: { async getConnection() { return { query: async () => {}, release() {} }; } } },
  });

  const res1 = makeRes();
  getStatus({}, res1);
  const callsAfterPrime = getDbConfigCalls;

  const cfgRes = makeRes();
  await postConfigure({
    body: { host: 'h', port: 3306, user: 'u', password: 's', database: 'd', tablePrefix: 'p_' },
    user: { id: 'admin', role: 'admin' },
  }, cfgRes);
  assert.notEqual(cfgRes.statusCode, 200);

  const res2 = makeRes();
  getStatus({}, res2);
  assert.ok(
    getDbConfigCalls > callsAfterPrime,
    'configurePool failure must still invalidate so a stale entry cannot mask the bad attempt',
  );
});

test('db-status cache: reset-config invalidates cache (configured=true must not survive a teardown)', async () => {
  let getDbConfigCalls = 0;
  let poolReady = true;

  // Reset.js needs admin OR no admin in DB. Stub the admin probe to return
  // 0 admins so the route proceeds without auth.
  clearCache();
  const dbModule = require('../../src/edge/db');
  Object.assign(dbModule, {
    isPoolReady: () => poolReady,
    getDbConfig: () => {
      getDbConfigCalls += 1;
      return { source: 'file', host: 'h', port: 3306, user: 'u', database: 'd', tablePrefix: 'p_' };
    },
    getDbConfigFull: () => null,
    configurePool: async () => {},
    saveConfig: () => {},
    resetConfig: async () => { poolReady = false; },
    t: (n) => `t_${n}`,
    pool: {
      rw: {
        async getConnection() {
          return {
            query: async () => [{ cnt: 0 }],
            release() {},
          };
        },
      },
    },
  });

  // Register both handlers so they share the same cache module-state.
  let getStatus = null;
  let postReset = null;
  require('../../src/edge/routes/platform/setup/db-connect')({
    get(path, h) { if (path === '/db-status') getStatus = h; },
    post() {},
  });
  require('../../src/edge/routes/platform/setup/reset')({
    post(path, h) { if (path === '/reset-config') postReset = h; },
  });

  const res1 = makeRes();
  getStatus({}, res1);
  assert.equal(res1.body.data.configured, true);
  const callsAfterPrime = getDbConfigCalls;

  const resetRes = makeRes();
  await postReset({ user: { id: 'admin', role: 'admin' } }, resetRes);
  assert.equal(resetRes.statusCode, 200);

  const res2 = makeRes();
  getStatus({}, res2);
  assert.equal(res2.body.data.configured, false, 'after resetConfig the cache must not return configured=true');
  assert.ok(getDbConfigCalls === callsAfterPrime, 'pool no longer ready, getDbConfig should not be called');
});

test('readDbStatusCacheTtlMs: defaults / overrides / non-numeric guard', () => {
  clearCache();
  delete process.env.DB_STATUS_CACHE_TTL_MS;
  const { readDbStatusCacheTtlMs } = require('../../src/edge/routes/platform/setup/db-connect');
  assert.equal(readDbStatusCacheTtlMs(), 300);

  process.env.DB_STATUS_CACHE_TTL_MS = '0';
  assert.equal(readDbStatusCacheTtlMs(), 0);

  process.env.DB_STATUS_CACHE_TTL_MS = '750';
  assert.equal(readDbStatusCacheTtlMs(), 750);

  process.env.DB_STATUS_CACHE_TTL_MS = 'oops';
  assert.equal(readDbStatusCacheTtlMs(), 300);

  process.env.DB_STATUS_CACHE_TTL_MS = '-50';
  assert.equal(readDbStatusCacheTtlMs(), 300);
});
