/**
 * blueprint-import-drops-link.test.js — B4 + S1/S2 import-path guard.
 *
 * overwriteBlueprint must NOT persist a payload's linked_blueprint_id (it is a
 * UUID into the source environment and would dangle) — it drops the link to
 * null and returns a warning + audit flag. It must also REFUSE to overwrite a
 * target that is *currently* linked (that would silently un-link it, bypassing
 * the read-only guard).
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');

const lib = require('../../src/edge/lib/blueprint-serialization');

const FAKE_TABLES = {
  HIERARCHY_NODES: 'hierarchy_nodes',
  BLUEPRINT_FIELDS: 'blueprint_fields',
  FIELD_OPTIONS: 'field_options',
  BLUEPRINT_SECTIONS: 'blueprint_sections',
  BLUEPRINT_OUTPUT_ORDER: 'blueprint_output_order',
  FEATURE_AUDIT: 'feature_audit',
};
const fakeT = (name) => `fmb_${name}`;
let counter = 0;
const fakeUuid = () => `fake-uuid-${counter++}`;

function rawFixture(linkedId) {
  return {
    import_version: 1,
    hierarchy_node: {
      id: 'bp-uuid-1', parent_id: 'release-uuid-1', name: 'BP',
      description: '', node_type: 'blueprint', sort_order: 0, is_active: 1,
      transformer_id: null, transformer_version: null,
      linked_blueprint_id: linkedId ?? null,
    },
    blueprint_fields: [],
    field_options: [],
    blueprint_sections: [],
    blueprint_output_order: [],
  };
}

// `currentFixture` is what loadRawExport reads back (the existing target).
function makeFakeConn(currentFixture) {
  const queries = [];
  return {
    queries,
    async query(sql, params) {
      queries.push({ sql, params });
      if (/^SELECT \* FROM .*hierarchy_nodes/.test(sql)) return [currentFixture.hierarchy_node];
      if (/^SELECT \* FROM .*blueprint_fields/.test(sql)) return currentFixture.blueprint_fields;
      if (/^SELECT \* FROM .*field_options/.test(sql)) return currentFixture.field_options;
      if (/^SELECT \* FROM .*blueprint_sections/.test(sql)) return currentFixture.blueprint_sections;
      if (/^SELECT \* FROM .*blueprint_output_order/.test(sql)) return currentFixture.blueprint_output_order;
      if (/^SELECT id FROM .*blueprint_fields/.test(sql)) return [];
      return [];
    },
  };
}

describe('overwriteBlueprint drops a cross-env link from the payload (B4)', () => {
  it('binds null for linked_blueprint_id and returns a warning', async () => {
    const current = rawFixture(null); // existing target is NOT linked
    const payload = lib.parseYaml(lib.serializeYaml(rawFixture('src-from-other-env'))); // payload carries a link
    const conn = makeFakeConn(current);
    const result = await lib.overwriteBlueprint({
      conn, t: fakeT, TABLES: FAKE_TABLES, uuidv4: fakeUuid,
      existingId: 'bp-uuid-1', payload, userId: 'admin-1',
      expectedRevision: lib.computeRevision(current),
    });
    assert.equal(result.ok, true);
    assert.ok(Array.isArray(result.warnings) && result.warnings.length === 1);

    const upd = conn.queries.find((q) => /UPDATE .*hierarchy_nodes/.test(q.sql));
    assert.ok(upd, 'expected a metadata UPDATE');
    // param order: name, description, is_active, transformer_id, transformer_version, linked_blueprint_id, id
    assert.equal(upd.params[5], null, 'linked_blueprint_id must be written as null');

    const success = conn.queries.find(
      (q) => /feature_audit/.test(q.sql) && Array.isArray(q.params) && q.params.includes('blueprint.overwrite.success'),
    );
    assert.ok(success, 'expected overwrite.success audit row');
    assert.equal(JSON.parse(success.params[3]).linked_blueprint_cleared, true);
  });

  it('no warning when the payload was not linked', async () => {
    const current = rawFixture(null);
    const payload = lib.parseYaml(lib.serializeYaml(rawFixture(null)));
    const conn = makeFakeConn(current);
    const result = await lib.overwriteBlueprint({
      conn, t: fakeT, TABLES: FAKE_TABLES, uuidv4: fakeUuid,
      existingId: 'bp-uuid-1', payload, userId: 'admin-1',
      expectedRevision: lib.computeRevision(current),
    });
    assert.equal(result.ok, true);
    assert.deepEqual(result.warnings, []);
  });
});

describe('overwriteBlueprint refuses a target that is currently linked (S1/S2, P2)', () => {
  it('throws LINKED_BLUEPRINT_READONLY before any destructive write', async () => {
    const current = rawFixture('some-source'); // existing target IS linked
    const conn = makeFakeConn(current);
    await assert.rejects(
      lib.overwriteBlueprint({
        conn, t: fakeT, TABLES: FAKE_TABLES, uuidv4: fakeUuid,
        existingId: 'bp-uuid-1',
        payload: lib.parseYaml(lib.serializeYaml(rawFixture(null))),
        userId: 'admin-1',
        expectedRevision: 'any',
      }),
      (e) => e.code === 'LINKED_BLUEPRINT_READONLY',
    );
    // No DELETE was issued (rejected before the cascade).
    assert.ok(!conn.queries.some((q) => /DELETE FROM/.test(q.sql)));
  });
});
