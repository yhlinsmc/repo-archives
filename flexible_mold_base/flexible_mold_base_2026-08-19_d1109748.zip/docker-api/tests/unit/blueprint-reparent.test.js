const { test } = require('node:test');
const assert = require('node:assert');
const { resolveAncestors, restampTemplates, countAffectedTemplates } = require('../../src/edge/lib/blueprint-reparent');

const t = (n) => n;
function makeConn(handlers) {
  return { calls: [], async query(sql, params) { this.calls.push({ sql, params }); return handlers(sql, params, this) ?? { affectedRows: 0 }; } };
}

test('resolveAncestors walks parent chain to top + release', async () => {
  const conn = makeConn((sql, params) => {
    if (/WHERE id = \?/i.test(sql)) {
      const id = params[0];
      const row = {
        'rel-1': { id: 'rel-1', node_type: 'release', parent_id: 'cat-1' },
        'cat-1': { id: 'cat-1', node_type: 'category', parent_id: null },
      }[id];
      return row ? [row] : [];
    }
    return [];
  });
  const out = await resolveAncestors(conn, t, 'rel-1');
  assert.deepEqual(out, { topId: 'cat-1', releaseId: 'rel-1' });
});

test('resolveAncestors with a category-direct target has null release', async () => {
  const conn = makeConn((sql, params) => {
    if (/WHERE id = \?/i.test(sql)) {
      return params[0] === 'cat-9' ? [{ id: 'cat-9', node_type: 'category', parent_id: null }] : [];
    }
    return [];
  });
  assert.deepEqual(await resolveAncestors(conn, t, 'cat-9'), { topId: 'cat-9', releaseId: null });
});

test('restampTemplates sets release + top-tier category_id, returns count (fmb-1329 T9: generation_id dropped)', async () => {
  const conn = makeConn((sql) => {
    if (/UPDATE `[^`]*user_templates`/i.test(sql)) return { affectedRows: 4 };
    return { affectedRows: 0 };
  });
  const n = await restampTemplates(conn, t, 'bp-1', { topId: 'cat-1', releaseId: 'rel-1' });
  assert.equal(n, 4);
  const upd = conn.calls.find((c) => /UPDATE `[^`]*user_templates`/i.test(c.sql));
  assert.match(upd.sql, /release_id = \?/i);
  assert.match(upd.sql, /category_id = \?/i);
  assert.doesNotMatch(upd.sql, /generation_id/i);
  assert.match(upd.sql, /blueprint_id = \?/i);
  assert.match(upd.sql, /variant_id IN \(SELECT/i);
});

test('countAffectedTemplates returns { count, templates } for a small result set', async () => {
  const rows = [
    { id: 'tpl-1', name: 'Alpha' },
    { id: 'tpl-2', name: 'Beta' },
    { id: 'tpl-3', name: 'Gamma' },
  ];
  const conn = makeConn((sql) => {
    if (/SELECT id, name FROM/i.test(sql)) return rows;
    return { affectedRows: 0 };
  });
  const result = await countAffectedTemplates(conn, t, 'bp-1');
  assert.equal(result.count, 3);
  assert.deepEqual(result.templates.map((r) => r.name), ['Alpha', 'Beta', 'Gamma']);
});

test('countAffectedTemplates issues a COUNT query when list overflows the cap', async () => {
  // Build CAP+1 rows to trigger the overflow path.
  const CAP = 500;
  const overflowRows = Array.from({ length: CAP + 1 }, (_, i) => ({ id: `tpl-${i}`, name: `T${i}` }));
  const conn = makeConn((sql) => {
    if (/SELECT id, name FROM/i.test(sql)) return overflowRows;
    if (/SELECT COUNT\(\*\) AS n/i.test(sql)) return [{ n: 9999 }];
    return { affectedRows: 0 };
  });
  const result = await countAffectedTemplates(conn, t, 'bp-1');
  // count comes from COUNT(*), not rows.length
  assert.equal(result.count, 9999);
  // templates list is capped at 500
  assert.equal(result.templates.length, CAP);
});
