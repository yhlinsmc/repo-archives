'use strict';

/**
 * edge-health-status-shape.test.js — pins the KEY SET of the object literal
 * the `/edge/health` handler responds with, not merely the pool block inside
 * it.
 *
 * Nothing under tests/ ever hits the real handler (every `edge/health` call
 * site is a stub, a mock, or a comment) — index-edge.js calls `app.listen`
 * at require time and exports nothing, so there is no app object to bind to
 * an ephemeral port for a socket test, and extracting the handler to get one
 * is a runtime-path change this repo's Ship Gate treats as needing a real
 * image boot, not a unit test. So this is a SOURCE-SHAPE assertion instead:
 * it reads index-edge.js, finds the `const status = {` literal inside the
 * `/edge/health` route, and asserts its top-level keys are exactly the four
 * that were reviewed for this surface.
 *
 * What this guards against: a future edit that adds a derived key — e.g.
 * `sql_mode: reading.mode` — directly on the `status` literal at the same
 * level as `pool`, rather than inside the pool block the whitelist already
 * projects. Every existing assertion in this family targets the pool block;
 * none of them would notice a new top-level sibling of `pool`, and that is
 * exactly the shape the last leak took.
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const SRC_PATH = path.join(__dirname, '..', '..', 'src', 'index-edge.js');

/**
 * Extract the top-level keys of the FIRST brace-delimited object literal
 * found after `const status = {` inside the `/edge/health` route handler.
 *
 * Bracket-depth tracked (not line-anchored), so reformatting the literal
 * onto one line, or a future value itself becoming an object/array/call
 * with its own braces, does not change which keys are read as top-level.
 *
 * @param {string} source
 * @returns {string[]}
 */
function extractEdgeHealthStatusKeys(source) {
  const routeAnchor = source.indexOf("app.get('/edge/health'");
  assert.ok(
    routeAnchor !== -1,
    "anchor \"app.get('/edge/health'\" not found in index-edge.js — the route "
      + 'moved or was renamed; update this test\'s anchor rather than deleting the check',
  );

  const afterRoute = source.slice(routeAnchor);
  const literalAnchor = afterRoute.indexOf('const status = {');
  assert.ok(
    literalAnchor !== -1,
    "anchor 'const status = {' not found after the /edge/health route — the "
      + 'handler no longer builds a `status` object literal there; update this test',
  );

  const braceOpen = afterRoute.indexOf('{', literalAnchor);
  let depth = 0;
  let i = braceOpen;
  for (; i < afterRoute.length; i++) {
    const ch = afterRoute[i];
    if (ch === '{') depth++;
    else if (ch === '}') {
      depth--;
      if (depth === 0) break;
    }
  }
  assert.ok(
    depth === 0,
    'brace-depth scan of the status literal never closed — malformed source or a '
      + 'scan bug; update this test rather than trust a partial read',
  );

  const body = afterRoute.slice(braceOpen + 1, i);

  // Depth-tracked key scan over the literal BODY: only an identifier
  // immediately followed by ':' at depth 0 counts as a top-level key, so a
  // future value that is itself an object/array/call (its own braces) never
  // contributes its inner keys to this list.
  const keys = [];
  let innerDepth = 0;
  let cursor = 0;
  while (cursor < body.length) {
    const ch = body[cursor];
    if (ch === '{' || ch === '(' || ch === '[') { innerDepth++; cursor++; continue; }
    if (ch === '}' || ch === ')' || ch === ']') { innerDepth--; cursor++; continue; }
    if (innerDepth === 0) {
      const identMatch = /^[A-Za-z_$][\w$]*/.exec(body.slice(cursor));
      if (identMatch) {
        const ident = identMatch[0];
        const rest = body.slice(cursor + ident.length);
        const colonMatch = /^\s*:/.exec(rest);
        if (colonMatch) {
          keys.push(ident);
          cursor += ident.length + colonMatch[0].length;
          continue;
        }
        cursor += ident.length;
        continue;
      }
    }
    cursor++;
  }

  assert.ok(
    keys.length > 0,
    'found the status object literal but the key scan extracted zero keys — '
      + 'the scan regressed; update this test rather than let it pass on nothing found',
  );
  return keys;
}

describe('the shape of the object /edge/health answers unauthenticated callers with', () => {
  const source = fs.readFileSync(SRC_PATH, 'utf-8');

  it('carries exactly api / role / db / pool and no sibling of pool', () => {
    const keys = extractEdgeHealthStatusKeys(source);
    // A future key added here — sql_mode, a raw error, anything not already
    // reviewed for this unauthenticated surface — must fail this assertion
    // and force the same review the pool block already gets via
    // PUBLISHED_POOL_FIELDS, rather than riding out next to `pool` unseen.
    assert.deepEqual(
      keys.sort(),
      ['api', 'db', 'pool', 'role'].sort(),
      'the /edge/health status literal gained or lost a top-level key — every '
        + 'key on this literal is served to a caller with no credentials',
    );
  });

  it('projects the pool value through the shared whitelist rather than the raw builder', () => {
    // Belt-and-suspenders on the specific defect this file exists for: the
    // `pool` VALUE (not just its key) must route through `publishablePool`,
    // not through `getPoolDiagnostic()` directly. A regression here would
    // pass the key-set check above (still called `pool`) while un-doing the
    // whitelist projection this endpoint applies to it.
    const routeAnchor = source.indexOf("app.get('/edge/health'");
    assert.ok(routeAnchor !== -1, 'anchor drifted — see the previous test');
    const handlerSlice = source.slice(routeAnchor, routeAnchor + 600);
    assert.match(
      handlerSlice,
      /pool:\s*publishablePool\(getPoolDiagnostic\(\)\)/,
      'expected `pool: publishablePool(getPoolDiagnostic())`; a bare '
        + '`pool: getPoolDiagnostic()` republishes the builder verbatim, unfiltered',
    );
  });
});
