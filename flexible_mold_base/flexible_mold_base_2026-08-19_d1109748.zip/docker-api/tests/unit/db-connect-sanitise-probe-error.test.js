/**
 * db-connect-sanitise-probe-error.test.js
 *
 * v3.2.32c carry-forward (security LOW): POST /api/setup/test-db probe errors
 * used to surface raw MariaDB messages ("Access denied for user 'x'@'y'"),
 * echoing the caller-supplied username and source host back to the admin UI.
 * The sanitiser maps known MariaDB / libuv codes to generic strings and
 * redacts the message for unknown codes while preserving the code itself for
 * troubleshooting. This test pins the behaviour so a future refactor of the
 * probe handler can't accidentally reintroduce the leak.
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');

const { sanitiseProbeError, PROBE_ERROR_MAP } = require(
  '../../src/edge/routes/platform/setup/db-connect'
);

describe('sanitiseProbeError', () => {
  it('maps ER_ACCESS_DENIED_ERROR → generic message (no user/host echo)', () => {
    const raw = Object.assign(new Error("Access denied for user 'appuser_rw'@'10.0.1.14' (using password: YES)"), {
      code: 'ER_ACCESS_DENIED_ERROR',
    });
    const out = sanitiseProbeError(raw);
    assert.equal(out.message, PROBE_ERROR_MAP.ER_ACCESS_DENIED_ERROR);
    assert.equal(out.code, 'ER_ACCESS_DENIED_ERROR');
    assert.doesNotMatch(out.message, /appuser_rw/);
    assert.doesNotMatch(out.message, /10\.0\.1\.14/);
  });

  it('maps ECONNREFUSED → refused-nothing-listening message', () => {
    const raw = Object.assign(new Error('connect ECONNREFUSED 10.0.1.14:3306'), {
      code: 'ECONNREFUSED',
    });
    const out = sanitiseProbeError(raw);
    assert.equal(out.message, PROBE_ERROR_MAP.ECONNREFUSED);
    assert.match(out.message, /nothing listening/i);
    assert.equal(out.code, 'ECONNREFUSED');
    assert.doesNotMatch(out.message, /10\.0\.1\.14/);
  });

  it('maps EHOSTUNREACH → distinct routing/firewall message', () => {
    const raw = Object.assign(new Error('connect EHOSTUNREACH 10.0.1.14:3306'), {
      code: 'EHOSTUNREACH',
    });
    const out = sanitiseProbeError(raw);
    assert.equal(out.message, PROBE_ERROR_MAP.EHOSTUNREACH);
    // Must NOT be the same wording as ECONNREFUSED — admin needs the hint to
    // look at routes/firewall, not at whether the DB service is up.
    assert.notEqual(out.message, PROBE_ERROR_MAP.ECONNREFUSED);
  });

  it('maps ER_HOST_IS_BLOCKED → max_connect_errors hint', () => {
    const raw = Object.assign(
      new Error("Host '10.0.1.14' is blocked because of many connection errors"),
      { code: 'ER_HOST_IS_BLOCKED' }
    );
    const out = sanitiseProbeError(raw);
    assert.equal(out.message, PROBE_ERROR_MAP.ER_HOST_IS_BLOCKED);
    assert.match(out.message, /FLUSH HOSTS/);
    assert.doesNotMatch(out.message, /10\.0\.1\.14/);
  });

  it('maps ER_BAD_DB_ERROR → database-not-found message', () => {
    const raw = Object.assign(new Error("Unknown database 'internal_secrets_db'"), {
      code: 'ER_BAD_DB_ERROR',
    });
    const out = sanitiseProbeError(raw);
    assert.equal(out.message, PROBE_ERROR_MAP.ER_BAD_DB_ERROR);
    assert.doesNotMatch(out.message, /internal_secrets_db/);
  });

  it('unknown MariaDB code → opaque message + preserves the code', () => {
    const raw = Object.assign(new Error("some secret host internal.example.com was stolen"), {
      code: 'ER_SOME_UNKNOWN_CODE',
    });
    const out = sanitiseProbeError(raw);
    assert.equal(out.message, 'Connection failed');
    assert.equal(out.code, 'ER_SOME_UNKNOWN_CODE');
    assert.doesNotMatch(out.message, /internal\.example\.com/);
  });

  it('falls back to errno when code is absent', () => {
    const raw = Object.assign(new Error('original leaky text'), {
      errno: 'ETIMEDOUT',
    });
    const out = sanitiseProbeError(raw);
    assert.equal(out.message, PROBE_ERROR_MAP.ETIMEDOUT);
    assert.equal(out.code, 'ETIMEDOUT');
  });

  it('no code / errno → UNKNOWN code + opaque message', () => {
    const raw = new Error('bare error with secret: super-secret-pw');
    const out = sanitiseProbeError(raw);
    assert.equal(out.message, 'Connection failed');
    assert.equal(out.code, 'UNKNOWN');
    assert.doesNotMatch(out.message, /super-secret-pw/);
  });

  it('null / undefined input → UNKNOWN code + opaque message', () => {
    for (const input of [null, undefined]) {
      const out = sanitiseProbeError(input);
      assert.equal(out.message, 'Connection failed');
      assert.equal(out.code, 'UNKNOWN');
    }
  });

  it('PROBE_ERROR_MAP is frozen (no runtime mutation)', () => {
    assert.ok(Object.isFrozen(PROBE_ERROR_MAP));
  });
});
