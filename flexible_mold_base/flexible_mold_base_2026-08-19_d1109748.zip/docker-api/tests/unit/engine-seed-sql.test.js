const { test } = require('node:test');
const assert = require('node:assert');
const { buildEngineSeedSql } = require('../../src/edge/lib/engine-seed-sql');

function fakeConn(tableRows) {
  return {
    async query(sql, params) {
      const m = sql.match(/SELECT \* FROM `([^`]+)`/);
      if (m) {
        const physical = m[1];
        if (tableRows[physical] === undefined) {
          const e = new Error('no such table'); e.errno = 1146; throw e;
        }
        return tableRows[physical];
      }
      if (/information_schema\.COLUMNS/i.test(sql)) {
        const physical = params[1];
        const sample = (tableRows[physical] || [])[0] || {};
        return Object.keys(sample).map((COLUMN_NAME) => ({ COLUMN_NAME, DATA_TYPE: 'varchar' }));
      }
      return [];
    },
  };
}

test('builds INSERTs for non-empty engine tables with __PREFIX__ placeholder', async () => {
  const conn = fakeConn({ 'p_api_connectors': [{ id: 'c1', name: 'X' }] });
  const sql = await buildEngineSeedSql(conn, { database: 'testdb', tablePrefix: 'p_' });
  assert.match(sql, /INSERT INTO `__PREFIX__api_connectors`/);
  assert.match(sql, /COMMIT;/);
});

test('empty / missing tables emit a comment, not an INSERT', async () => {
  const conn = fakeConn({});
  const sql = await buildEngineSeedSql(conn, { database: 'testdb', tablePrefix: 'p_' });
  assert.ok(!/INSERT INTO/.test(sql), 'no INSERT for missing tables');
  assert.match(sql, /not found or empty/);
});
