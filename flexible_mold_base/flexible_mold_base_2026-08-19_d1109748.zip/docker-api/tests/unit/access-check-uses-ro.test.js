/**
 * access-check-uses-ro.test.js
 *
 * v3.2.40 PR-1 — pin the hot-path routing decision.
 *
 * `POST /edge/platform/access-check` fires on every authenticated non-admin
 * request (via infra accessCheckMiddleware). Pure SELECT against access_rules
 * → must run on pool.ro. This test fails if a future refactor accidentally
 * routes it back to pool.rw.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../src/edge/db');
const routeKey = require.resolve('../../src/edge/routes/platform/access-check');

let calls;

function makeSpy() {
  calls = { rw: 0, ro: 0, roQueries: [] };
  return {
    rw: {
      async getConnection() {
        calls.rw++;
        throw new Error('wrong facade: access-check must use pool.ro, not pool.rw');
      },
    },
    ro: {
      async getConnection() {
        calls.ro++;
        return {
          async query(sql, params) {
            calls.roQueries.push({ sql, params });
            return []; // no matching rule → default deny
          },
          release() { /* noop */ },
        };
      },
    },
  };
}

const poolSpy = {};

require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: {
    pool: poolSpy,
    t: (name) => `fmb_${name}`,
  },
};

const router = require('../../src/edge/routes/platform/access-check');

let server;
let port;

before(async () => {
  Object.assign(poolSpy, makeSpy());
  const app = express();
  app.use(express.json());
  app.use('/edge/platform/access-check', router);
  await new Promise((resolve) => {
    server = app.listen(0, '127.0.0.1', () => {
      port = server.address().port;
      resolve();
    });
  });
});

after(async () => {
  await new Promise((resolve) => server.close(resolve));
  delete require.cache[dbKey];
  delete require.cache[routeKey];
});

beforeEach(() => {
  Object.assign(poolSpy, makeSpy());
});

function postJson(port_, path_, body) {
  return new Promise((resolve, reject) => {
    const payload = JSON.stringify(body);
    const req = http.request(
      {
        host: '127.0.0.1', port: port_, path: path_, method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) },
      },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          const raw = Buffer.concat(chunks).toString('utf-8');
          let json = null;
          try { json = JSON.parse(raw); } catch { /* noop */ }
          resolve({ status: res.statusCode, raw, json });
        });
      },
    );
    req.on('error', reject);
    req.write(payload);
    req.end();
  });
}

describe('POST /edge/platform/access-check — v3.2.40 pool.ro pin', () => {
  it('user+deptid lookup hits pool.ro (not pool.rw)', async () => {
    const res = await postJson(port, '/edge/platform/access-check', {
      email: 'alice@test', deptid: 'D42', role: 'user',
    });

    assert.equal(res.status, 200);
    assert.equal(res.json?.data?.allowed, false, 'no rule → default deny');
    assert.equal(calls.rw, 0, 'pool.rw.getConnection MUST NOT be called (would throw)');
    assert.equal(calls.ro, 1, 'pool.ro.getConnection should be called exactly once');
    // Both lookups (user + deptid) happen on the same ro conn
    assert.equal(calls.roQueries.length, 2);
    assert.match(calls.roQueries[0].sql, /FROM `fmb_access_rules`/);
    assert.match(calls.roQueries[0].sql, /rule_type = 'user'/);
    assert.match(calls.roQueries[1].sql, /rule_type = 'deptid'/);
  });

  it('admin role bypasses DB entirely', async () => {
    const res = await postJson(port, '/edge/platform/access-check', {
      email: 'admin@test', role: 'admin',
    });

    assert.equal(res.status, 200);
    assert.equal(res.json?.data?.allowed, true);
    assert.equal(res.json?.data?.reason, 'admin_bypass');
    assert.equal(calls.ro, 0, 'admin bypass must skip DB');
    assert.equal(calls.rw, 0);
  });

  it('matching user rule short-circuits before the deptid query', async () => {
    // Swap the ro facade to return a matching user-level rule on the first
    // query so the route returns at line 47 (user_rule) without ever hitting
    // the deptid branch. Pins the early-return invariant so a refactor that
    // re-ordered the checks would fail here.
    poolSpy.ro = {
      async getConnection() {
        calls.ro++;
        return {
          async query(sql, params) {
            calls.roQueries.push({ sql, params });
            if (/rule_type = 'user'/.test(sql)) return [{ role: 'user' }];
            return [];
          },
          release() { /* noop */ },
        };
      },
    };

    const res = await postJson(port, '/edge/platform/access-check', {
      email: 'alice@test', deptid: 'D42', role: 'user',
    });

    assert.equal(res.status, 200);
    assert.equal(res.json?.data?.allowed, true);
    assert.equal(res.json?.data?.reason, 'user_rule');
    assert.equal(calls.rw, 0);
    assert.equal(calls.ro, 1);
    assert.equal(calls.roQueries.length, 1, 'deptid query must not fire after user rule matches');
  });
});
