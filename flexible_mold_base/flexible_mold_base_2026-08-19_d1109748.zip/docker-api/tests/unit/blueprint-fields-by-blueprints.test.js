/**
 * blueprint-fields-by-blueprints.test.js
 *
 * HTTP integration (spy pool) for POST /blueprint_fields/by-blueprints — the
 * batch read that replaces the per-blueprint GET fan-out on the templates list.
 * Verifies: a single SELECT with a parameterised `blueprint_id IN (...)` over
 * the RO pool; rows come back mapped (mapRowsFromDb ran); empty list short-
 * circuits without a query; malformed bodies 400; unauthenticated 401.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../src/edge/db');

let fields; // seeded rows: { id, blueprint_id, field_key, order_index, table_config(JSON string|null) }
let queries; // every SQL the handler emitted
let usedRoPool; // true once the RO pool handed out a connection
let currentUser;

function makeSpyConn() {
  return {
    query: async (sql, params = []) => {
      queries.push({ sql, params });
      if (/SELECT \* FROM `fmb_blueprint_fields`[\s\S]*WHERE blueprint_id IN/i.test(sql)) {
        return fields.filter((f) => params.includes(f.blueprint_id)).map((f) => ({ ...f }));
      }
      return [];
    },
    release: () => {},
  };
}

const poolSpy = {
  rw: { getConnection: async () => makeSpyConn() },
  ro: { getConnection: async () => { usedRoPool = true; return makeSpyConn(); } },
};

require.cache[dbKey] = {
  id: dbKey,
  filename: dbKey,
  loaded: true,
  exports: {
    pool: poolSpy,
    t: (name) => `fmb_${name}`,
    getDynamicPool: async () => poolSpy,
  },
};

const router = require('../../src/edge/routes/app/schema');

let server;
let port;

before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { req.user = currentUser; next(); });
  app.use('/edge/app/schema', router);
  await new Promise((resolve) => {
    server = app.listen(0, '127.0.0.1', () => { port = server.address().port; resolve(); });
  });
});

after(async () => {
  await new Promise((resolve) => server.close(resolve));
  delete require.cache[dbKey];
});

beforeEach(() => {
  queries = [];
  usedRoPool = false;
  currentUser = { id: 'u-1', email: 'u@test', role: 'user' };
  fields = [
    { id: 'bf1', blueprint_id: 'b1', field_key: 'k1', order_index: 0, table_config: null, visibility_rule: null },
    { id: 'bf2', blueprint_id: 'b1', field_key: 'k2', order_index: 1, table_config: '{"cols":3}', visibility_rule: null },
    { id: 'bf3', blueprint_id: 'b2', field_key: 'k3', order_index: 0, table_config: null, visibility_rule: null },
  ];
});

function postJson(path_, body) {
  return new Promise((resolve, reject) => {
    const data = Buffer.from(JSON.stringify(body), 'utf-8');
    const req = http.request(
      { host: '127.0.0.1', port, path: path_, method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Content-Length': data.length } },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          const raw = Buffer.concat(chunks).toString('utf-8');
          let json = null;
          try { json = raw ? JSON.parse(raw) : null; } catch { /* */ }
          resolve({ status: res.statusCode, raw, json });
        });
      },
    );
    req.on('error', reject);
    req.write(data);
    req.end();
  });
}

const PATH = '/edge/app/schema/blueprint_fields/by-blueprints';

describe('POST /blueprint_fields/by-blueprints', () => {
  it('returns the rows for all blueprint ids in one parameterised IN query', async () => {
    const res = await postJson(PATH, { blueprint_ids: ['b1', 'b2'] });
    assert.equal(res.status, 200);
    const rows = res.json.data;
    assert.equal(rows.length, 3);
    assert.deepEqual(rows.map((r) => r.id).sort(), ['bf1', 'bf2', 'bf3']);

    // Exactly one SELECT, RO pool, parameterised IN with the ids (no fan-out).
    const selects = queries.filter((q) => /SELECT \* FROM `fmb_blueprint_fields`[\s\S]*WHERE blueprint_id IN/i.test(q.sql));
    assert.equal(selects.length, 1);
    assert.match(selects[0].sql, /blueprint_id IN \(\?, \?\)/);
    assert.match(selects[0].sql, /ORDER BY blueprint_id, order_index IS NULL, order_index/);
    assert.deepEqual(selects[0].params, ['b1', 'b2']);
    assert.equal(usedRoPool, true);
  });

  it('maps JSON columns via mapRowsFromDb (parity with the list path)', async () => {
    const res = await postJson(PATH, { blueprint_ids: ['b1'] });
    assert.equal(res.status, 200);
    const bf2 = res.json.data.find((r) => r.id === 'bf2');
    assert.deepEqual(bf2.table_config, { cols: 3 }); // JSON string → object
    const bf1 = res.json.data.find((r) => r.id === 'bf1');
    assert.equal(bf1.table_config, null); // null stays null
  });

  it('short-circuits an empty id list with no query', async () => {
    const res = await postJson(PATH, { blueprint_ids: [] });
    assert.equal(res.status, 200);
    assert.deepEqual(res.json.data, []);
    assert.equal(queries.length, 0);
  });

  it('rejects a non-array blueprint_ids', async () => {
    const res = await postJson(PATH, { blueprint_ids: 'b1' });
    assert.equal(res.status, 400);
    assert.equal(queries.length, 0);
  });

  it('rejects an over-cap id list', async () => {
    const res = await postJson(PATH, { blueprint_ids: Array.from({ length: 1001 }, (_, i) => `b${i}`) });
    assert.equal(res.status, 400);
    assert.equal(queries.length, 0);
  });

  it('rejects a non-string id element', async () => {
    const res = await postJson(PATH, { blueprint_ids: ['b1', 123] });
    assert.equal(res.status, 400);
    assert.equal(queries.length, 0);
  });

  it('rejects an empty-string id element', async () => {
    const res = await postJson(PATH, { blueprint_ids: ['b1', ''] });
    assert.equal(res.status, 400);
    assert.equal(queries.length, 0);
  });

  it('401s an unauthenticated request', async () => {
    currentUser = null;
    const res = await postJson(PATH, { blueprint_ids: ['b1'] });
    assert.equal(res.status, 401);
    assert.equal(queries.length, 0);
  });
});
