/**
 * blueprint-revision-fingerprint.test.js
 *
 * computeRevision() is the optimistic lock for the YAML overwrite-import
 * path. It must fingerprint EVERY persisted data column of each field /
 * option row — otherwise a concurrent edit that touches only an
 * un-hashed column slips past the staleness check and the overwrite
 * silently clobbers it.
 *
 * Regression guard for the cascade columns added this sprint
 * (depends_on_field_key on fields, valid_parent_values on options) plus a
 * drift guard: any future data column on these rows is hashed automatically
 * because the fingerprint derives its key set from the row's own keys.
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');

const { computeRevision } = require('../../src/edge/lib/blueprint-serialization');

// A minimal but realistic rawExport as produced by loadRawExport (SELECT *):
// rows carry every DB column, including the cascade columns.
function baseRaw() {
  return {
    import_version: 1,
    hierarchy_node: {
      id: 'bp-1',
      node_type: 'blueprint',
      name: 'BP',
      parent_id: 'rel-1',
      description: '',
      is_active: 1,
      transformer_id: null,
      transformer_version: null,
      linked_blueprint_id: null,
      created_at: '2026-01-01T00:00:00Z',
    },
    blueprint_fields: [
      {
        id: 'fld-1',
        blueprint_id: 'bp-1',
        field_key: 'country',
        field_label: 'Country',
        field_type: 'select',
        is_required: 1,
        default_value: '',
        placeholder: '',
        tooltip: '',
        section: 'general',
        order_index: 0,
        table_config: null,
        visibility_rule: null,
        depends_on_field_key: null,
        created_at: '2026-01-01T00:00:00Z',
      },
    ],
    field_options: [
      {
        id: 'opt-1',
        field_id: 'fld-1',
        option_value: 'us',
        option_label: 'United States',
        sort_order: 0,
        valid_parent_values: null,
        created_at: '2026-01-01T00:00:00Z',
      },
    ],
    blueprint_sections: [],
    blueprint_output_order: [],
    _extensions: {},
  };
}

describe('computeRevision — cascade columns covered', () => {
  it('changes when a field depends_on_field_key differs', () => {
    const a = baseRaw();
    const b = baseRaw();
    b.blueprint_fields[0].depends_on_field_key = 'region';
    assert.notEqual(
      computeRevision(a),
      computeRevision(b),
      'depends_on_field_key must affect the revision fingerprint',
    );
  });

  it('changes when an option valid_parent_values differs', () => {
    const a = baseRaw();
    const b = baseRaw();
    b.field_options[0].valid_parent_values = ['na'];
    assert.notEqual(
      computeRevision(a),
      computeRevision(b),
      'valid_parent_values must affect the revision fingerprint',
    );
  });

  it('is stable across volatile-only differences (id / created_at)', () => {
    const a = baseRaw();
    const b = baseRaw();
    b.blueprint_fields[0].id = 'fld-other';
    b.blueprint_fields[0].created_at = '2099-12-31T23:59:59Z';
    b.field_options[0].id = 'opt-other';
    b.field_options[0].created_at = '2099-12-31T23:59:59Z';
    assert.equal(
      computeRevision(a),
      computeRevision(b),
      'volatile columns (id / created_at) must not affect the revision',
    );
  });

  it('is stable regardless of row column ordering', () => {
    const a = baseRaw();
    const b = baseRaw();
    // Re-create the field row with keys in a different insertion order.
    const f = b.blueprint_fields[0];
    b.blueprint_fields[0] = {
      depends_on_field_key: f.depends_on_field_key,
      field_type: f.field_type,
      field_key: f.field_key,
      created_at: f.created_at,
      id: f.id,
      field_label: f.field_label,
      is_required: f.is_required,
      default_value: f.default_value,
      placeholder: f.placeholder,
      tooltip: f.tooltip,
      section: f.section,
      order_index: f.order_index,
      table_config: f.table_config,
      visibility_rule: f.visibility_rule,
      blueprint_id: f.blueprint_id,
    };
    assert.equal(
      computeRevision(a),
      computeRevision(b),
      'key ordering inside a row must not affect the revision',
    );
  });

  it('changes when a real data column differs (sanity: field_label)', () => {
    const a = baseRaw();
    const b = baseRaw();
    b.blueprint_fields[0].field_label = 'Nation';
    assert.notEqual(computeRevision(a), computeRevision(b));
  });
});
