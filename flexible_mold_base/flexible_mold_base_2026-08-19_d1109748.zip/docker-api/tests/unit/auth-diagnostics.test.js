/**
 * auth-diagnostics.test.js — /api/auth/diagnostics encryption-key override tests.
 *
 * Verifies that the /diagnostics handler uses edge's authoritative
 * settings_encryption_key_configured value (when available) and falls
 * back to infra's own env reading with source='infra-fallback' on edge outage.
 */
const { describe, it, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

process.env.JWT_SECRET = process.env.JWT_SECRET || 'a'.repeat(48);

// ── Stub keycloak-health (imports pool from edge/db at load time) ─────────────
const kcHealthKey = require.resolve('../../src/lib/keycloak-health');
require.cache[kcHealthKey] = {
  id: kcHealthKey, filename: kcHealthKey, loaded: true,
  exports: {
    isDegraded: () => false,
    isProbeRunning: () => false,
  },
};

// ── Stub shared/config (resolveAuthMode, getAuthModeSource) ──────────────────
const configKey = require.resolve('../../src/shared/config');
require.cache[configKey] = {
  id: configKey, filename: configKey, loaded: true,
  exports: {
    resolveAuthMode: () => 'local',
    getAuthModeSource: () => 'default',
  },
};

// ── Mock edge-state-client BEFORE requiring the router ───────────────────────
const edgeClientKey = require.resolve('../../src/infra/lib/edge-state-client');
let fetchAuthModeImpl;
const { EdgeUnreachable } = require('../../src/infra/lib/edge-state-client');
require.cache[edgeClientKey] = {
  id: edgeClientKey, filename: edgeClientKey, loaded: true,
  exports: {
    fetchAuthMode: (...a) => fetchAuthModeImpl(...a),
    EdgeUnreachable,
    EdgeTimeout: class EdgeTimeout extends Error {},
    EdgeAuthFailed: class EdgeAuthFailed extends Error {},
  },
};

const authRouter = require('../../src/infra/routes/auth-session');

function startServer(user = { role: 'admin' }) {
  const app = express();
  app.use((req, _res, next) => { req.user = user; req.id = 't'; next(); });
  app.use('/api/auth', authRouter);
  return app;
}

async function getDiag(app) {
  const server = http.createServer(app);
  await new Promise((r) => server.listen(0, r));
  try {
    const { port } = server.address();
    const resp = await fetch(`http://localhost:${port}/api/auth/diagnostics`);
    const body = await resp.json();
    return body.data || body;
  } finally {
    // Closed on the throwing path too. With the close reachable only where
    // nothing threw, a failed assertion leaks this handle, the runner never
    // exits, and the job reports a timeout instead of the assertion that failed.
    await new Promise((r) => server.close(r));
  }
}

describe('/api/auth/diagnostics — encryption key presence', () => {
  beforeEach(() => { delete process.env.SETTINGS_ENCRYPTION_KEY; });

  it('uses the edge-reported value (edge true, infra blind) → true + source edge', async () => {
    delete process.env.SETTINGS_ENCRYPTION_KEY; // infra has no key (k8s edge-only)
    fetchAuthModeImpl = async () => ({ auth_mode: 'local', settings_encryption_key_configured: true });
    const data = await getDiag(startServer());
    assert.equal(data.settings_encryption_key_configured, true);
    assert.equal(data.settings_encryption_key_source, 'edge');
  });

  it('falls back to infra env + caveat when edge is unreachable', async () => {
    process.env.SETTINGS_ENCRYPTION_KEY = 'infra-local-key';
    fetchAuthModeImpl = async () => { throw new EdgeUnreachable('down'); };
    const data = await getDiag(startServer());
    assert.equal(data.settings_encryption_key_configured, true); // infra's own reading
    assert.equal(data.settings_encryption_key_source, 'infra-fallback');
  });
});

describe('/api/auth/diagnostics — whether the engine refuses a value it cannot store', () => {
  // This endpoint is the authenticated home of a reading that is deliberately
  // on neither /health body: it tells the reader whether an over-long string,
  // an out-of-range integer or a non-member ENUM value is worth writing at this
  // host. An operator needs it; a stranger must not have it. The tier boundary
  // is therefore the assertion, and it is made on the emitted body.
  beforeEach(() => { fetchAuthModeImpl = async () => ({ auth_mode: 'local' }); });

  it('reaches an admin', async () => {
    fetchAuthModeImpl = async () => ({ auth_mode: 'local', configured_pool_strict_writes: 'lax' });
    const data = await getDiag(startServer({ role: 'admin' }));
    assert.equal(data.configured_pool_strict_writes, 'lax');
  });

  it('and nobody else', async () => {
    fetchAuthModeImpl = async () => ({ auth_mode: 'local', configured_pool_strict_writes: 'lax' });
    for (const user of [null, { role: 'editor' }, { role: 'user' }]) {
      const data = await getDiag(startServer(user));
      assert.equal(
        Object.prototype.hasOwnProperty.call(data, 'configured_pool_strict_writes'), false,
        `the public tier answered a ${user ? user.role : 'signed-out'} caller`,
      );
    }
  });

  it('reads an unmeasured deployment as unmeasured, not as a safe one', async () => {
    // Edge that did not answer, edge that answered without the field, and edge
    // that answered with something outside the closed set. None of the three
    // has measured anything, and 'strict' is the one word that would tell an
    // admin their rows are safe when nobody knows that.
    fetchAuthModeImpl = async () => { throw new EdgeUnreachable('down'); };
    assert.equal((await getDiag(startServer())).configured_pool_strict_writes, 'unknown');
    fetchAuthModeImpl = async () => ({ auth_mode: 'local' });
    assert.equal((await getDiag(startServer())).configured_pool_strict_writes, 'unknown');
    fetchAuthModeImpl = async () => ({ auth_mode: 'local', configured_pool_strict_writes: 'STRICT' });
    assert.equal((await getDiag(startServer())).configured_pool_strict_writes, 'unknown');
  });
});
