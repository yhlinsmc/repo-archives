'use strict';

/**
 * crud-write-conflict.test.js — a write the engine gave up on is not a server
 * fault.
 *
 * The CRUD factory reported every driver error the same way: 500 INTERNAL_ERROR,
 * 'Database operation failed'. Two of them are not faults at all — errno 1213
 * (this transaction was chosen as the deadlock victim and rolled back) and 1205
 * (lock wait timeout) say the work did not get its turn, and repeating the
 * request is the correct response. A client told 500 has no way to know that.
 */
const { test, describe } = require('node:test');
const assert = require('node:assert/strict');

const { writeConflictError } = require('../../src/edge/routes/app/schema/crud-factory');

describe('a lock the engine gave up on answers retryable, not server fault', () => {
  for (const errno of [1213, 1205]) {
    test(`errno ${errno} maps to a 409 the caller can act on`, () => {
      const e = writeConflictError({ errno });
      assert.ok(e, `errno ${errno} was left as a 500`);
      assert.equal(e.status, 409);
      assert.equal(e.body.error.code, 'WRITE_CONFLICT');
      assert.match(e.body.error.message, /retry/i, 'the answer does not say what to do');
    });
  }

  test('every other error is left to the mapping that already existed', () => {
    // The guard on reach: 1062 has a mount-declared 409 of its own, 1146/1054
    // are the degraded-schema arms, and anything else is a genuine fault the
    // catch-all must still report as one.
    for (const errno of [1062, 1146, 1054, 1364, undefined]) {
      assert.equal(
        writeConflictError({ errno }), null,
        `errno ${errno} was swallowed as a write conflict`,
      );
    }
    assert.equal(writeConflictError(null), null);
    assert.equal(writeConflictError(new Error('not a driver error')), null);
  });
});
