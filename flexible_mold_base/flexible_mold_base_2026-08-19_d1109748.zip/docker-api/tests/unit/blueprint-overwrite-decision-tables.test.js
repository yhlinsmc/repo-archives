/**
 * blueprint-overwrite-decision-tables.test.js
 *
 * The export payload carries no decision tables, so an overwrite replaces the
 * whole schema underneath any rules the TARGET already had. Those rules address
 * fields by key: a surviving table would silently re-bind every key the incoming
 * schema happens to reuse (same key, different meaning) and flag only the keys
 * that vanished. So an overwrite deletes them, probe-gated on the additive
 * table, and reports the count instead of losing them silently.
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');

const lib = require('../../src/edge/lib/blueprint-serialization');

const FAKE_TABLES = {
  HIERARCHY_NODES: 'hierarchy_nodes',
  BLUEPRINT_FIELDS: 'blueprint_fields',
  FIELD_OPTIONS: 'field_options',
  BLUEPRINT_SECTIONS: 'blueprint_sections',
  BLUEPRINT_OUTPUT_ORDER: 'blueprint_output_order',
  BLUEPRINT_GROUPS: 'blueprint_groups',
  VARIANT_OVERRIDES: 'variant_overrides',
  DECISION_TABLES: 'decision_tables',
  FEATURE_AUDIT: 'feature_audit',
};
const fakeT = (name) => `fmb_${name}`;
let counter = 0;
const fakeUuid = () => `fake-uuid-${counter++}`;

function rawFixture() {
  return {
    import_version: 1,
    hierarchy_node: {
      id: 'bp-1', parent_id: 'release-1', name: 'BP', description: '',
      node_type: 'blueprint', sort_order: 0, is_active: 1,
      transformer_id: null, transformer_version: null, linked_blueprint_id: null,
      owner_id: null,
    },
    blueprint_fields: [],
    field_options: [],
    blueprint_sections: [],
    blueprint_groups: [],
    blueprint_output_order: [],
  };
}

// `presentTables` answers the additive-table probe PER physical name, so one
// table's presence can never stand in for another's.
function makeFakeConn(current, { presentTables = [], deletedDecisionTables = 0 } = {}) {
  const present = new Set(presentTables);
  const queries = [];
  return {
    queries,
    async query(sql, params) {
      queries.push({ sql, params });
      if (/information_schema\.TABLES/i.test(sql)) {
        return present.has(params && params[0]) ? [{ 1: 1 }] : [];
      }
      if (/^DELETE FROM `fmb_decision_tables`/i.test(sql)) {
        return { affectedRows: deletedDecisionTables };
      }
      if (/^SELECT \* FROM .*hierarchy_nodes/i.test(sql)) return [current.hierarchy_node];
      if (/^SELECT \* FROM .*blueprint_fields/i.test(sql)) return current.blueprint_fields;
      if (/^SELECT \* FROM .*field_options/i.test(sql)) return current.field_options;
      if (/^SELECT \* FROM .*blueprint_sections/i.test(sql)) return current.blueprint_sections;
      if (/^SELECT \* FROM .*blueprint_output_order/i.test(sql)) return current.blueprint_output_order;
      if (/^SELECT id, field_key FROM .*blueprint_fields/i.test(sql)) return [];
      if (/^SELECT id FROM .*blueprint_fields/i.test(sql)) return [];
      return [];
    },
  };
}

function run(conn, current) {
  return lib.overwriteBlueprint({
    conn, t: fakeT, TABLES: FAKE_TABLES, uuidv4: fakeUuid,
    existingId: 'bp-1', payload: rawFixture(), userId: 'admin-1', userRole: 'admin',
    expectedRevision: lib.computeRevision(current),
  });
}

describe('overwriteBlueprint clears the target blueprint decision tables', () => {
  it('deletes them, warns with the count, and records it in the success audit', async () => {
    const current = rawFixture();
    const conn = makeFakeConn(current, {
      presentTables: ['fmb_decision_tables'],
      deletedDecisionTables: 2,
    });
    const result = await run(conn, current);
    assert.equal(result.ok, true);

    const del = conn.queries.find((q) => /^DELETE FROM `fmb_decision_tables`/i.test(q.sql));
    assert.ok(del, 'expected the decision_tables DELETE');
    assert.deepEqual(del.params, ['bp-1'], 'must delete only the target blueprint rows');
    // Before the root metadata UPDATE, i.e. within the destructive cascade the
    // caller wraps in one transaction — not after the row has been rewritten.
    const updateAt = conn.queries.findIndex((q) => /^UPDATE `fmb_hierarchy_nodes`/i.test(q.sql));
    assert.ok(conn.queries.indexOf(del) < updateAt, 'DELETE must precede the metadata UPDATE');

    assert.equal(result.deletedDecisionTables, 2);
    assert.ok(
      result.warnings.some((w) => /2 decision table\(s\)/.test(w)),
      `expected a decision-table warning; got ${JSON.stringify(result.warnings)}`,
    );
    const success = conn.queries.find(
      (q) => /feature_audit/.test(q.sql)
        && Array.isArray(q.params) && q.params.includes('blueprint.overwrite.success'),
    );
    assert.equal(JSON.parse(success.params[3]).deleted_decision_tables, 2);
  });

  it('skips the DELETE, and warns about nothing, on a target lacking the table', async () => {
    const current = rawFixture();
    const conn = makeFakeConn(current, { presentTables: ['fmb_blueprint_groups'] });
    const result = await run(conn, current);
    assert.equal(result.ok, true);
    assert.ok(
      !conn.queries.some((q) => /DELETE FROM `fmb_decision_tables`/i.test(q.sql)),
      'must not DELETE a table that does not exist',
    );
    assert.equal(result.deletedDecisionTables, 0);
    assert.deepEqual(result.warnings, []);
  });
});
