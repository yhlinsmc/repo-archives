/**
 * edge-internal-system.test.js — GET /edge/internal/system/auth-mode coverage.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

process.env.JWT_SECRET = process.env.JWT_SECRET || 'a'.repeat(48);

const dbKey = require.resolve('../../src/edge/db');
const configKey = require.resolve('../../src/shared/config');

let poolReady = true;
let asyncModeResult = 'keycloak';
let asyncModeShouldThrow = false;
let strictWrites = 'unknown';

require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: {
    pool: {},
    t: (n) => `fmb_${n}`,
    isPoolReady: () => poolReady,
    getConfiguredPoolStrictWrites: () => strictWrites,
  },
};

require.cache[configKey] = {
  id: configKey, filename: configKey, loaded: true,
  exports: {
    resolveAuthMode: () => 'local',
    resolveAuthModeAsync: async () => {
      if (asyncModeShouldThrow) throw new Error('DB read failed');
      return asyncModeResult;
    },
    getAuthModeSource: () => 'system_settings',
    JWT_SECRET: process.env.JWT_SECRET,
  },
};

let server;
let port;

before(async () => {
  const router = require('../../src/edge/routes/internal/system');
  const app = express();
  app.use('/edge/internal/system', router);
  await new Promise((resolve) => {
    server = app.listen(0, '127.0.0.1', () => { port = server.address().port; resolve(); });
  });
});

after(async () => {
  await new Promise((resolve) => server.close(resolve));
  delete require.cache[dbKey];
  delete require.cache[configKey];
});

beforeEach(() => {
  poolReady = true;
  asyncModeResult = 'keycloak';
  asyncModeShouldThrow = false;
  strictWrites = 'unknown';
});

function getJson(path_) {
  return new Promise((resolve, reject) => {
    const req = http.request({ host: '127.0.0.1', port, path: path_, method: 'GET' }, (res) => {
      const chunks = [];
      res.on('data', (c) => chunks.push(c));
      res.on('end', () => {
        const raw = Buffer.concat(chunks).toString('utf-8');
        let json = null;
        try { json = JSON.parse(raw); } catch { /* noop */ }
        resolve({ status: res.statusCode, raw, json });
      });
    });
    req.on('error', reject);
    req.end();
  });
}

describe('edge /edge/internal/system/auth-mode', () => {
  it('returns DB-resolved auth_mode when pool ready', async () => {
    asyncModeResult = 'keycloak';
    const res = await getJson('/edge/internal/system/auth-mode');
    assert.equal(res.status, 200);
    assert.equal(res.json.data.auth_mode, 'keycloak');
    assert.equal(res.json.data.pool_ready, true);
  });

  it('falls back to env resolveAuthMode when pool not ready', async () => {
    poolReady = false;
    const res = await getJson('/edge/internal/system/auth-mode');
    assert.equal(res.status, 200);
    assert.equal(res.json.data.auth_mode, 'local');
    assert.equal(res.json.data.pool_ready, false);
  });

  it('falls back to env when DB read throws', async () => {
    asyncModeShouldThrow = true;
    const res = await getJson('/edge/internal/system/auth-mode');
    assert.equal(res.status, 200);
    assert.equal(res.json.data.auth_mode, 'local');
  });

  it('carries the strict-writes reading, which the health bodies do not', async () => {
    // This route is S2S-only and its one caller publishes the reading to admins
    // alone, so this is where an operator can still learn that their engine
    // substitutes a value it cannot store. Asserted on the wire body: the point
    // of moving the reading was that it keeps being ANSWERED, just not to
    // strangers, and a fix that quietly dropped it would also pass a test that
    // only checked the health bodies no longer carry it.
    strictWrites = 'lax';
    const res = await getJson('/edge/internal/system/auth-mode');
    assert.equal(res.status, 200);
    assert.equal(res.json.data.configured_pool_strict_writes, 'lax');
  });

  it('reports settings_encryption_key_configured in the auth-mode payload', async () => {
    process.env.SETTINGS_ENCRYPTION_KEY = 'present-for-this-test';
    const res = await getJson('/edge/internal/system/auth-mode');
    assert.equal(res.json.data.settings_encryption_key_configured, true);
    delete process.env.SETTINGS_ENCRYPTION_KEY;
    const res2 = await getJson('/edge/internal/system/auth-mode');
    assert.equal(res2.json.data.settings_encryption_key_configured, false);
  });
});
