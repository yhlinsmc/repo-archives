/**
 * auth-bearer-uses-ro.test.js
 *
 * v3.2.118 — DB ops moved to edge via S2S identity-resolve. This test now
 * pins the infra-side contract for the JWT Bearer path:
 *   - happy path: exactly one resolveIdentity call (source='jwt-bearer', userId='<sub>')
 *   - banned user: req.user stays null after edge replies banned=true
 *   - no Bearer / invalid token: no edge call (verify-then-DB ordering preserved)
 *   - edge unreachable (EdgeUnreachable): req.user stays null, downstream sees null
 *
 * Edge-side RW/RO split coverage moved to identity-resolve.test.js.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');
const { signHs256 } = require('../helpers/jwt-hs256');

process.env.JWT_SECRET = process.env.JWT_SECRET || 'a'.repeat(48);

const edgeClientKey = require.resolve('../../src/infra/lib/edge-state-client');
const authKey = require.resolve('../../src/infra/middleware/auth');

class FakeEdgeUnreachable extends Error {
  constructor(msg) { super(msg); this.name = 'EdgeUnreachable'; this.code = 'EDGE_UNREACHABLE'; }
}
class FakeEdgeTimeout extends Error {
  constructor(msg) { super(msg); this.name = 'EdgeTimeout'; this.code = 'EDGE_TIMEOUT'; }
}
class FakeEdgeAuthFailed extends Error {
  constructor(msg) { super(msg); this.name = 'EdgeAuthFailed'; this.code = 'EDGE_AUTH_FAILED'; }
}

let identityCalls;
let identityImpl;

function installEdgeStub() {
  require.cache[edgeClientKey] = {
    id: edgeClientKey, filename: edgeClientKey, loaded: true,
    exports: {
      resolveIdentity: async (opts) => {
        identityCalls.push(opts);
        return identityImpl(opts);
      },
      fetchAuthMode: async () => ({ auth_mode: 'local', source: 'env', pool_ready: true }),
      fetchEdgeHealth: async () => ({ reachable: true, db: 'ok', pool: { pool_state: 'configured' } }),
      getEdgeBaseUrl: () => 'http://api-edge:3201',
      EdgeUnreachable: FakeEdgeUnreachable,
      EdgeTimeout: FakeEdgeTimeout,
      EdgeAuthFailed: FakeEdgeAuthFailed,
      EdgeBadResponse: class extends Error {},
    },
  };
  delete require.cache[authKey];
}

const auth = (() => { installEdgeStub(); return require('../../src/infra/middleware/auth'); })();

let server;
let port;

before(async () => {
  const app = express();
  app.use(auth);
  app.get('/whoami', (req, res) => {
    res.json({ user: req.user });
  });
  await new Promise((resolve) => {
    server = app.listen(0, '127.0.0.1', () => {
      port = server.address().port;
      resolve();
    });
  });
});

after(async () => {
  await new Promise((resolve) => server.close(resolve));
  delete require.cache[edgeClientKey];
  delete require.cache[authKey];
});

beforeEach(() => {
  identityCalls = [];
  identityImpl = async () => ({
    user: null,
    jit_provisioned: false,
    auth_mode: 'local',
    banned: false,
    pool_ready: true,
  });
  auth._resetCacheForTests?.();
});

function getJson(port_, path_, headers = {}) {
  return new Promise((resolve, reject) => {
    const req = http.request(
      { host: '127.0.0.1', port: port_, path: path_, method: 'GET', headers },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          const raw = Buffer.concat(chunks).toString('utf-8');
          let json = null;
          try { json = JSON.parse(raw); } catch { /* noop */ }
          resolve({ status: res.statusCode, raw, json });
        });
      },
    );
    req.on('error', reject);
    req.end();
  });
}

describe('auth Bearer path — v3.2.118 S2S identity-resolve', () => {
  it('happy path: one identity-resolve call with jwt-bearer source', async () => {
    identityImpl = async () => ({
      user: { id: 'u1', email: 'alice@test', role: 'user', banned: 0 },
      jit_provisioned: false,
      auth_mode: 'local',
      banned: false,
      pool_ready: true,
    });
    const token = await signHs256({ sub: 'u1' }, process.env.JWT_SECRET);

    const res = await getJson(port, '/whoami', { Authorization: `Bearer ${token}` });

    assert.equal(res.status, 200);
    assert.equal(res.json.user?.id, 'u1', 'downstream should see req.user populated');
    assert.equal(identityCalls.length, 1);
    assert.equal(identityCalls[0].source, 'jwt-bearer');
    assert.equal(identityCalls[0].userId, 'u1');
  });

  it('banned user: req.user stays null', async () => {
    identityImpl = async () => ({
      user: null,
      jit_provisioned: false,
      auth_mode: 'local',
      banned: true,
      pool_ready: true,
    });
    const token = await signHs256({ sub: 'u2' }, process.env.JWT_SECRET);

    const res = await getJson(port, '/whoami', { Authorization: `Bearer ${token}` });

    assert.equal(res.status, 200);
    assert.equal(res.json.user, null, 'banned user must NOT populate req.user');
    assert.equal(identityCalls.length, 1);
  });

  it('no Bearer header: no edge call', async () => {
    const res = await getJson(port, '/whoami');
    assert.equal(res.status, 200);
    assert.equal(res.json.user, null);
    assert.equal(identityCalls.length, 0);
  });

  it('invalid token: no edge call (verify-then-DB)', async () => {
    const res = await getJson(port, '/whoami', { Authorization: 'Bearer not-a-real-token' });
    assert.equal(res.status, 200);
    assert.equal(res.json.user, null);
    assert.equal(identityCalls.length, 0);
  });

  it('edge unreachable: req.user stays null (fail-closed for protected routes)', async () => {
    identityImpl = async () => { throw new FakeEdgeUnreachable('edge dead'); };
    const token = await signHs256({ sub: 'u3' }, process.env.JWT_SECRET);

    const res = await getJson(port, '/whoami', { Authorization: `Bearer ${token}` });

    assert.equal(res.status, 200);
    assert.equal(res.json.user, null);
    assert.equal(identityCalls.length, 1);
  });

  it('pool not ready: falls back to JWT-payload identity with hardcoded role=user (security-reviewer HIGH-2)', async () => {
    identityImpl = async () => ({
      user: null,
      jit_provisioned: false,
      auth_mode: 'local',
      banned: false,
      pool_ready: false,
    });
    // Token claims role=admin, but the setup-mode fallback MUST ignore the
    // decoded role and hardcode 'user' — DB is not available to validate,
    // and trusting the token-claimed role lets a forged/old admin JWT read
    // /api/auth/diagnostics admin-tier output during setup mode.
    const token = await signHs256({ sub: 'u4', email: 'wizard@test', role: 'admin' }, process.env.JWT_SECRET);

    const res = await getJson(port, '/whoami', { Authorization: `Bearer ${token}` });

    assert.equal(res.status, 200);
    assert.equal(res.json.user?.id, 'u4');
    assert.equal(res.json.user?.email, 'wizard@test');
    assert.equal(res.json.user?.role, 'user', 'setup-mode fallback must hardcode role=user, never trust decoded.role');
  });
});
