/**
 * db-config-source.test.js — edge boot config-source resolution (item 21).
 *
 * Two coupled boot defects are covered:
 *   1. Resilience — a half-set DB_RO_* pair must degrade to setup-required (null)
 *      on the boot path, NOT throw (which crash-looped the edge pod). The
 *      Setup-Wizard write path keeps assertReadConfig strict (proved separately).
 *   2. Diagnosability — loadConfig emits ONE structured "source resolved" boot
 *      line stating the outcome (source=file|env|none), instead of the old
 *      contradictory "config loaded from env vars" logged before validation.
 *
 * No live DB — these are pure config-derivation functions.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const db = require('../../src/edge/db');
const { buildEnvConfig, assertReadConfig, _internalsForTest } = db;
const { _loadConfigFromPath } = _internalsForTest;

// Snapshot + restore every DB_* env var this suite mutates.
const KEYS = [
  'DB_NAME', 'DB_TABLE_PREFIX', 'DB_RW_HOST', 'DB_RW_PORT', 'DB_RW_USER', 'DB_RW_PASSWORD',
  'DB_RO_HOST', 'DB_RO_PORT', 'DB_RO_USER', 'DB_RO_PASSWORD',
];
let saved;
before(() => { saved = Object.fromEntries(KEYS.map((k) => [k, process.env[k]])); });
after(() => { for (const k of KEYS) { if (saved[k] === undefined) delete process.env[k]; else process.env[k] = saved[k]; } });
beforeEach(() => { for (const k of KEYS) delete process.env[k]; });

function setComplete() {
  process.env.DB_NAME = 'appdb';
  process.env.DB_TABLE_PREFIX = 'app_';
  process.env.DB_RW_HOST = 'db-writer';
}

// A non-existent path forces the env branch (no file present).
function noFile() {
  return path.join(os.tmpdir(), `no-such-cfg-${process.pid}-${Math.random().toString(36).slice(2)}.json`);
}

describe('buildEnvConfig — degrade, never throw, on the boot path', () => {
  it('half-set DB_RO_* pair → null (setup-required), NOT a throw', () => {
    setComplete();
    process.env.DB_RO_HOST = 'db-reader'; // DB_RO_PORT deliberately unset
    let cfg;
    assert.doesNotThrow(() => { cfg = buildEnvConfig(); });
    assert.equal(cfg, null);
  });

  it('missing DB_NAME → null (setup-required)', () => {
    process.env.DB_TABLE_PREFIX = 'app_';
    process.env.DB_RW_HOST = 'db-writer';
    assert.equal(buildEnvConfig(), null);
  });

  it('missing DB_TABLE_PREFIX → null (setup-required)', () => {
    process.env.DB_NAME = 'appdb';
    process.env.DB_RW_HOST = 'db-writer';
    assert.equal(buildEnvConfig(), null);
  });

  it('complete env (no RO endpoint) → a pool config is built', () => {
    setComplete();
    const cfg = buildEnvConfig();
    assert.ok(cfg, 'expected a config object');
    assert.equal(cfg.host, 'db-writer');
    assert.equal(cfg.database, 'appdb');
    assert.equal(cfg.tablePrefix, 'app_');
    assert.equal(cfg._source, 'env');
    assert.equal('readHost' in cfg, false);
  });

  it('complete env WITH a valid RO pair → readHost/readPort carried', () => {
    setComplete();
    process.env.DB_RO_HOST = 'db-reader';
    process.env.DB_RO_PORT = '3306';
    const cfg = buildEnvConfig();
    assert.ok(cfg);
    assert.equal(cfg.readHost, 'db-reader');
    assert.equal(cfg.readPort, 3306);
  });
});

describe('assertReadConfig — strict for the non-boot (Setup-Wizard) path', () => {
  it('still throws INVALID_READ_CONFIG on a half-set pair', () => {
    assert.throws(
      () => assertReadConfig({ readHost: 'db-reader', readPort: null }),
      (err) => err && err.code === 'INVALID_READ_CONFIG',
    );
  });
});

describe('loadConfig — source resolution (env branch, no file)', () => {
  it('env used → returns the env config (source=env)', () => {
    setComplete();
    const cfg = _loadConfigFromPath(noFile());
    assert.ok(cfg, 'expected env config');
    assert.equal(cfg._source, 'env');
    assert.equal(cfg.host, 'db-writer');
  });

  it('DB_RW_HOST unset, no file → null (setup-required)', () => {
    assert.equal(_loadConfigFromPath(noFile()), null);
  });

  it('DB_RW_HOST set but config incomplete (half-set RO) → null (setup-required, no throw)', () => {
    process.env.DB_RW_HOST = 'db-writer';
    process.env.DB_RO_HOST = 'db-reader'; // no DB_NAME / prefix / RO_PORT → incomplete
    let cfg = 'sentinel';
    assert.doesNotThrow(() => { cfg = _loadConfigFromPath(noFile()); });
    assert.equal(cfg, null);
  });
});

// Diagnosability contract (item 21): loadConfig emits ONE structured "source
// resolved" boot line per source outcome, and the pre-validation
// "config loaded from env vars" log is gone. Asserted against the source text so
// it is deterministic (pino stdout is async and not reliably capturable here).
describe('boot log — structured source line present, pre-validation log removed', () => {
  const src = fs.readFileSync(path.resolve(__dirname, '../../src/edge/db.js'), 'utf8');
  it('emits a structured source= line for file / env / none', () => {
    assert.match(src, /source=file/);
    assert.match(src, /source=env/);
    assert.match(src, /source=none → setup-required/);
  });
  it('no longer LOGS "config loaded from env vars" before validation (a comment may still reference it)', () => {
    assert.equal(/logger\.info\(\s*['"]config loaded from env vars['"]/.test(src), false);
  });
});
