/**
 * Parity test: backend extractComputeSources must produce the same source-key
 * sets as the frontend extractSources for every fixture case.
 *
 * Both sides read the single fixture file at
 * src/fmb/lib/compute/__fixtures__/compute-sources.fixtures.json so any
 * divergence between the TS and JS implementations is caught here rather than
 * silently drifting in production (cycle-detection + dependency ordering rely
 * on both extractors returning the same set of field keys).
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const path = require('path');

const { extractComputeSources } = require('../../src/edge/routes/app/schema').__test__;
const fixtures = require(
  path.resolve(__dirname, '../../../src/fmb/lib/compute/__fixtures__/compute-sources.fixtures.json'),
);

function sortedSources(rule) {
  return extractComputeSources(rule).slice().sort();
}

describe('extractComputeSources parity — backend JS vs shared fixture', () => {
  for (const { description, rule, expectedSources } of fixtures) {
    it(description, () => {
      assert.deepEqual(
        sortedSources(rule),
        [...expectedSources].sort(),
      );
    });
  }
});
