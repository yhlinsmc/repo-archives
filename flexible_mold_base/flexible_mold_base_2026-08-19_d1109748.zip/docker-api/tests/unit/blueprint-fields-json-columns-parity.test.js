/**
 * blueprint-fields-json-columns-parity.test.js — the shared "these columns hold
 * JSON" list, checked against the DDL that declares them, with no live DB.
 *
 * WHY a test rather than a derived list: see the module note on
 * src/edge/lib/blueprint-fields-json-columns.js. The short version is that
 * MariaDB cannot report the distinction at runtime, so the list is written down
 * and this test is what keeps it from going stale — a column declared JSON in
 * table-ddls.js and absent from the list is handed to the driver as an object,
 * which no mocked route test can see.
 */
const { describe, it, before } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const { buildSchemaManifest, ddlFragmentFor } = require('../../src/edge/lib/schema-manifest');
const { BLUEPRINT_FIELDS_JSON_COLUMNS } = require('../../src/edge/lib/blueprint-fields-json-columns');
const { getRegistry } = require('../../src/edge/lib/dto-mapper');

const TABLE = 'blueprint_fields';

// Every path that builds a blueprint_fields INSERT or maps one at the API
// boundary. A literal list in any of them is a second answer to this question.
const CALL_SITES = [
  'src/edge/routes/app/blueprint-export.js',
  'src/edge/lib/blueprint-serialization.js',
  'src/edge/lib/dto-mapper.js',
];

let columns;

before(() => {
  const entry = buildSchemaManifest((base) => base).get(TABLE);
  assert.ok(entry, `table-ddls.js declares no table '${TABLE}'`);
  columns = entry.columns;
});

/** Columns whose DDL type token is literally JSON. */
function declaredJsonColumns() {
  return columns.filter((column) => {
    const fragment = ddlFragmentFor(TABLE, column);
    return typeof fragment === 'string' && /^`?[A-Za-z_][A-Za-z0-9_]*`?\s+JSON\b/i.test(fragment);
  });
}

describe('blueprint_fields JSON columns <-> table-ddls parity', () => {
  it('the DDL really declares JSON columns (the extractor still sees them)', () => {
    assert.ok(declaredJsonColumns().length > 0,
      'no JSON column parsed — every assertion below would pass vacuously');
  });

  it('every column the DDL declares JSON is in the shared list', () => {
    const missing = declaredJsonColumns().filter((c) => !BLUEPRINT_FIELDS_JSON_COLUMNS.includes(c));
    assert.deepEqual(missing, [],
      `declared JSON in table-ddls.js but not serialized on the write paths: ${missing.join(', ')}`);
  });

  it('every entry of the shared list is a real column', () => {
    const unknown = BLUEPRINT_FIELDS_JSON_COLUMNS.filter((c) => !columns.includes(c));
    assert.deepEqual(unknown, [], `named as JSON but absent from the DDL: ${unknown.join(', ')}`);
  });

  it('the DTO mapper reads the same list it is written with', () => {
    assert.equal(getRegistry()[TABLE].json, BLUEPRINT_FIELDS_JSON_COLUMNS,
      'the read boundary must parse exactly the columns the write boundary stringifies');
  });
});

describe('the generic CRUD mounts have no answer of their own to reintroduce', () => {
  // The mount-side `jsonColumns` option was dead — `createCrudRoutes` never read
  // it — but it sat in three mounts looking authoritative, and the
  // blueprint_fields copy was two columns out of date. A dead literal no test
  // can reach is how the defect this file guards got written in the first place.
  const read = (relative) => fs.readFileSync(path.join(__dirname, '../..', relative), 'utf8');

  it('no mount declares JSON columns', () => {
    assert.ok(
      !/jsonColumns\s*:/.test(read('src/edge/routes/app/schema/index.js')),
      'JSON columns come from the DTO registry, keyed by table; a mount-side list is a second answer',
    );
  });

  it('and the factory reads no such option, so one could not take effect anyway', () => {
    assert.ok(
      !/opts\.jsonColumns/.test(read('src/edge/routes/app/schema/crud-factory.js')),
      'reinstating the read would make every stale mount-side list live',
    );
  });
});

describe('no call site keeps a private copy of the list', () => {
  // Matched on both `table_config` and `compute_rule` so a legitimate literal
  // for a DIFFERENT table (variant_overrides names compute_rule too) is not
  // mistaken for a stale copy of this one.
  it('every blueprint_fields JSON list is the shared constant', () => {
    const offenders = [];
    for (const relative of CALL_SITES) {
      const source = fs.readFileSync(path.join(__dirname, '../..', relative), 'utf8');
      for (const line of source.split('\n')) {
        if (!/\b(?:jsonColumns|json)\s*:\s*\[/.test(line)) continue;
        if (/'table_config'/.test(line) && /'compute_rule'/.test(line)) {
          offenders.push(`${relative}: ${line.trim()}`);
        }
      }
    }
    assert.deepEqual(offenders, [],
      `these lists drift silently; use BLUEPRINT_FIELDS_JSON_COLUMNS instead:\n${offenders.join('\n')}`);
  });
});
