/**
 * decision-output-claims-schema-parity.test.js — the one-table-per-output
 * guard's hand-written SQL, checked against the ACTUAL table DDL, no live DB.
 *
 * Every test around this guard stubs its query results, so a column that exists
 * only in this file's SQL stays green in both runners and 500s against a real
 * database — which for a guard means it FAIL-OPENS on a real database while
 * every test says it holds. The column names are taken out of the source text
 * and checked against table-ddls.js.
 */
const { describe, it, before } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');

const { buildSchemaManifest } = require('../../src/edge/lib/schema-manifest');

const SOURCE = require.resolve('../../src/edge/routes/app/schema/decision-output-claims.js');
// Whole identifiers only, so a template expression cannot decompose into
// fragments that happen to look like column names.
const IDENTIFIER = /(?<![A-Za-z0-9_])[a-z][a-z0-9_]*(?![A-Za-z0-9_])/g;

let columns;
let source;

before(() => {
  columns = buildSchemaManifest((base) => base).get('decision_tables').columns;
  source = fs.readFileSync(SOURCE, 'utf8');
});

/** Column tokens inside every statement matching `re`, with its capture groups. */
function referenced(re) {
  const found = new Set();
  let m = re.exec(source);
  assert.ok(m, `no statement matched ${re} — this check would pass vacuously`);
  while (m) {
    for (const clause of m.slice(1)) {
      for (const token of String(clause).match(IDENTIFIER) || []) found.add(token);
    }
    m = re.exec(source);
  }
  return found;
}

describe('one-table-per-output guard — SQL names only real columns', () => {
  it('the claim scan selects and filters on real columns', () => {
    // The table identifier is backtick-quoted INSIDE a template literal, so the
    // source carries escaped backticks; the statement ends at the first
    // unescaped one.
    const tokens = referenced(
      /SELECT (name, doc) FROM \\`\$\{table\}\\` WHERE ([^`]*?)`/g,
    );
    for (const column of tokens) {
      assert.ok(columns.includes(column),
        `decision_tables has no column '${column}' in table-ddls.js`);
    }
    for (const required of ['name', 'doc', 'blueprint_id', 'id']) {
      assert.ok(tokens.has(required), `the scan must reference ${required}`);
    }
  });

  it('the post-state lookup selects and filters on real columns', () => {
    // Reads `doc` as well as `blueprint_id`: a PUT that moves the row carries
    // the STORED document into a new set of siblings, so the guard has to judge
    // the document the row will have, not only the one the body states.
    const tokens = referenced(
      /SELECT (blueprint_id, doc) FROM \\`\$\{table\}\\` WHERE ([^`]*?)`/g,
    );
    for (const column of tokens) {
      assert.ok(columns.includes(column),
        `decision_tables has no column '${column}' in table-ddls.js`);
    }
    for (const required of ['blueprint_id', 'doc', 'id']) {
      assert.ok(tokens.has(required), `the post-state lookup must reference ${required}`);
    }
  });

  it('every read holds its rows to commit', () => {
    // A check-then-write guard without the lock is a suggestion: two clients
    // claiming the same output both read "nobody owns it" and both write.
    const selects = source.match(/SELECT [^`]*FROM \\`\$\{table\}\\`[^`]*`/g) || [];
    assert.ok(selects.length >= 2, 'expected the blueprint lookup and the claim scan');
    for (const statement of selects) {
      assert.match(statement, /FOR UPDATE/i, `missing FOR UPDATE: ${statement}`);
    }
  });

  it('the physical table name is resolved through TABLES, never spelled out', () => {
    assert.match(source, /t\(TABLES\.DECISION_TABLES\)/);
    assert.doesNotMatch(source, /fmb_decision_tables/);
  });
});
