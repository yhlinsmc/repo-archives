/**
 * api-connectors-write-follower-guard.test.js — CRUD write-path follower-
 * column guard (Q9/D2 amendment A4), Codex round-1 P2 fix.
 *
 * The guard in index.js used to fire only when the BODY named
 * `response_config`. A PUT that changes ONLY `blueprint_id` (a rebind) never
 * named it, so it skipped the guard entirely — and the row's STORED
 * response_config could go on targeting a follower column of the NEW
 * blueprint with no check at all. The fix validates the EFFECTIVE post-write
 * pair (blueprint_id, response_config), loading whichever half the body
 * omits from the existing row.
 *
 * Boots the real api-connectors router against a mocked pool (same
 * transaction-capable shape api-connectors-crud-mask.test.js uses), and
 * exercises three angles on ONE stored connector (blueprint_id=BP_A,
 * response_config targets servers::site):
 *   - rebind-only PUT to a blueprint whose OWN servers::site is a follower
 *     column → 400 (the bug this fix closes)
 *   - rebind-only PUT to a blueprint with no follower columns → 200
 *     (the guard must not over-block an ordinary rebind)
 *   - response_config-only PUT (no blueprint_id) still validated against the
 *     STORED blueprint_id → 400 (regression: the pre-existing single-
 *     condition path must keep working)
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../src/edge/db');

// The CRUD factory's own id-format guard requires a canonical UUID for
// blueprint_id (and the row id), independent of the follower guard under
// test — these have to look real or every scenario 400s before reaching it.
const CONNECTOR_ID = '11111111-1111-1111-1111-111111111111';
const BP_A = 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa'; // stored blueprint
const BP_B = 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb'; // rebind target: servers::site IS a follower
const BP_C = 'cccccccc-cccc-cccc-cccc-cccccccccccc'; // rebind target: servers::site is ordinary

const STORED_BLUEPRINT_ID = BP_A;
// Targets servers::site — a follower column on BP_B (the "bad" rebind
// target) but an ordinary column on BP_C (the "compatible" rebind target).
const STORED_RESPONSE_CONFIG = JSON.stringify({
  outputs: [{ to: { mode: 'cell', table_key: 'servers', column_key: 'site' } }],
});

// blueprint_id -> blueprint_fields rows `loadFollowerColumnKeys` reads.
const BLUEPRINT_FIELDS = {
  [BP_A]: [{ field_key: 'servers', table_config: JSON.stringify({ columns: [{ key: 'site', linked_source: { field_key: 'sites', column_key: 'name' } }] }) }],
  [BP_B]: [{ field_key: 'servers', table_config: JSON.stringify({ columns: [{ key: 'site', linked_source: { field_key: 'sites', column_key: 'name' } }] }) }],
  [BP_C]: [{ field_key: 'servers', table_config: JSON.stringify({ columns: [{ key: 'site' }] }) }], // ordinary column, no linked_source
};

let captured;
function makeConn() {
  return {
    async beginTransaction() {},
    async commit() {},
    async rollback() {},
    async query(sql, params) {
      if (/SELECT DATABASE\(\)/.test(sql)) return [{ db: 'testdb' }];
      if (/information_schema\.COLUMNS/i.test(sql)) return []; // colSet null → keep all keys
      if (/FROM `fmb_users`/.test(sql)) return []; // owner-name enrichment → none
      // The guard's own effective-pair load — distinct column list from the
      // CRUD factory's `SELECT *` below, so the two never collide. Matches
      // both the fixed query (`blueprint_id, response_config`) and the
      // pre-fix one (`blueprint_id` alone) so a revert probe exercises the
      // real defect (the trigger condition) rather than an unrelated mock
      // mismatch on the query shape.
      if (/SELECT blueprint_id(?:, response_config)? FROM `fmb_api_connectors` WHERE id = \?/.test(sql)) {
        return params[0] === CONNECTOR_ID
          ? [{ blueprint_id: STORED_BLUEPRINT_ID, response_config: STORED_RESPONSE_CONFIG }]
          : [];
      }
      if (/SELECT field_key, table_config FROM `fmb_blueprint_fields` WHERE blueprint_id = \? AND field_type = 'table'/.test(sql)) {
        return BLUEPRINT_FIELDS[params[0]] ?? [];
      }
      if (/^UPDATE `fmb_api_connectors`/.test(sql.trim())) {
        captured.update = { sql, params };
        return { affectedRows: 1 };
      }
      if (/SELECT \* FROM `fmb_api_connectors` WHERE id = \?/.test(sql)) {
        return [{
          id: params[0], name: 'c1', is_active: 1,
          auth_type: 'none', auth_config: JSON.stringify({}),
          request_config: null, response_config: STORED_RESPONSE_CONFIG,
          owner_id: 'admin', blueprint_id: BP_C,
          method: 'GET', url: 'http://svc/x', dispatch_origin: 'infra',
          created_at: '2026-01-01 00:00:00', updated_at: '2026-01-01 00:00:00',
        }];
      }
      return [];
    },
    release() {},
  };
}
const poolSpy = {
  ro: { async getConnection() { return makeConn(); }, async query(sql, params) { return makeConn().query(sql, params); } },
  rw: { async getConnection() { return makeConn(); }, async query(sql, params) { return makeConn().query(sql, params); } },
};
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: poolSpy, t: (name) => `fmb_${name}` },
};

const router = require('../../src/edge/routes/app/api-connectors');

let server; let base;
before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { req.user = { id: 'admin', role: 'admin' }; next(); });
  app.use('/c', router);
  server = http.createServer(app);
  await new Promise((r) => server.listen(0, r));
  base = `http://127.0.0.1:${server.address().port}`;
});
after(() => server && server.close());
beforeEach(() => { captured = {}; });

async function put(id, body) {
  const res = await fetch(`${base}/c/${id}`, {
    method: 'PUT', headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
  });
  return { status: res.status, json: await res.json() };
}

describe('api-connectors CRUD PUT — follower-column guard validates the EFFECTIVE pair', () => {
  it('rebind-only PUT to a blueprint whose target column is now a follower → 400', async () => {
    const { status, json } = await put(CONNECTOR_ID, { blueprint_id: BP_B });
    assert.equal(status, 400);
    assert.equal(json.error.code, 'BAD_REQUEST');
    assert.match(json.error.message, /mirrors another table/);
    assert.equal(captured.update, undefined, 'must not have written past the guard');
  });

  it('rebind-only PUT to a blueprint with no follower columns → 200 (not over-blocked)', async () => {
    const { status } = await put(CONNECTOR_ID, { blueprint_id: BP_C });
    assert.equal(status, 200);
    assert.ok(captured.update, 'the compatible rebind must reach the UPDATE');
  });

  it('response_config-only PUT (no blueprint_id) is still validated against the STORED blueprint — regression', async () => {
    const { status, json } = await put(CONNECTOR_ID, {
      response_config: { outputs: [{ to: { mode: 'cell', table_key: 'servers', column_key: 'site' } }] },
    });
    assert.equal(status, 400);
    assert.equal(json.error.code, 'BAD_REQUEST');
    assert.equal(captured.update, undefined);
  });
});
