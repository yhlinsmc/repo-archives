/**
 * edge-boot-guard.test.js — PR 1-C review HIGH (F1) fix pin.
 *
 * index-edge.js used to wrap initializeFromConfig() in a blanket .catch() that
 * swallowed EVERY rejection — including the SKIP_DB_INIT + production fail-fast
 * guard — then mounted routes and listened, so a misconfigured production pod
 * came up health-probe-green with no DB pool instead of crash-looping to force
 * operator attention. This pins the crash-vs-degrade decision:
 *   - fatalBoot error  → process.exit(1) (crash)
 *   - recoverable error → no exit, degrade to setup-required
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const { handleBootInitError } = require('../../src/edge/boot-guard');

function fakeLogger() {
  const calls = { fatal: [], error: [] };
  return {
    fatal: (...a) => { calls.fatal.push(a); },
    error: (...a) => { calls.error.push(a); },
    calls,
  };
}

describe('edge boot init error handling', () => {
  it('crashes (exit 1) on the fatalBoot guard error', () => {
    const logger = fakeLogger();
    let exitCode = null;
    const err = Object.assign(
      new Error('SKIP_DB_INIT=1 is not allowed in NODE_ENV=production'),
      { fatalBoot: true },
    );
    handleBootInitError(err, { logger, exit: (c) => { exitCode = c; } });
    assert.equal(exitCode, 1, 'must crash on the production fail-fast guard');
    assert.equal(logger.calls.fatal.length, 1);
    assert.equal(logger.calls.error.length, 0);
  });

  it('degrades (no exit) on a recoverable boot error', () => {
    const logger = fakeLogger();
    let exited = false;
    handleBootInitError(new Error('some recoverable config problem'), {
      logger,
      exit: () => { exited = true; },
    });
    assert.equal(exited, false, 'a recoverable error must not crash the pod');
    assert.equal(logger.calls.error.length, 1);
    assert.equal(logger.calls.fatal.length, 0);
  });

  it('degrades when the rejection is null/undefined', () => {
    const logger = fakeLogger();
    let exited = false;
    handleBootInitError(undefined, { logger, exit: () => { exited = true; } });
    assert.equal(exited, false);
    assert.equal(logger.calls.error.length, 1);
  });
});
