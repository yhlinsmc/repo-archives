const { test, afterEach } = require('node:test');
const assert = require('node:assert/strict');

const dbPath = require.resolve('../../src/edge/db');
const dbConnectPath = require.resolve('../../src/edge/routes/platform/setup/db-connect');

function clearCache() {
  delete require.cache[dbPath];
  delete require.cache[dbConnectPath];
}

function loadConfigureDbHandler(stubImpl) {
  clearCache();
  const dbModule = require('../../src/edge/db');
  Object.assign(dbModule, stubImpl);
  const register = require('../../src/edge/routes/platform/setup/db-connect');

  let handler = null;
  register({
    get: () => {},
    post(path, h) {
      if (path === '/configure-db') handler = h;
    },
  });
  return handler;
}

function makeReq(body) {
  return { body, user: { id: 'admin-1', role: 'admin' } };
}

function makeRes() {
  return {
    statusCode: 200,
    body: null,
    status(code) {
      this.statusCode = code;
      return this;
    },
    json(body) {
      this.body = body;
      return this;
    },
  };
}

afterEach(() => clearCache());

test('db.config_swap audit persists only scrubbed success metadata', async () => {
  const auditRows = [];
  const handler = loadConfigureDbHandler({
    isPoolReady: () => false,
    getDbConfig: () => null,
    getDbConfigFull: () => null,
    configurePool: async () => {},
    saveConfig: () => {},
    t: (name) => `app_${name}`,
    pool: {
      rw: {
        async getConnection() {
          return {
            async query(sql, params) {
              auditRows.push({ sql, metadata: JSON.parse(params[2]) });
              return { affectedRows: 1 };
            },
            release() {},
          };
        },
      },
    },
  });

  const res = makeRes();
  await handler(makeReq({
    host: 'db.internal',
    port: 3306,
    user: 'app_rw',
    password: 'secret',
    database: 'tenant',
    tablePrefix: 'tenant_',
  }), res);

  assert.equal(res.statusCode, 200);
  assert.equal(auditRows.length, 1);
  assert.match(auditRows[0].sql, /INSERT INTO `app_feature_audit`/);
  assert.deepEqual(auditRows[0].metadata, {
    connectionName: 'tenant',
    status: 'success',
    diskPersisted: false,
    errorCode: null,
  });
});

test('db.config_swap audit metadata contract excludes connection secrets and endpoints', () => {
  clearCache();
  const { buildConfigSwapAuditMetadata } = require('../../src/edge/routes/platform/setup/db-connect');
  const metadata = buildConfigSwapAuditMetadata({
    status: 'fail',
    connectionName: 'tenant',
    diskPersisted: false,
    errorCode: 'EROFS',
    host: 'db.internal',
    username: 'app_rw',
    user: 'app_rw',
    password: 'secret',
    dsn: 'mariadb://app_rw:secret@db.internal/tenant',
    url: 'mariadb://app_rw:secret@db.internal/tenant',
  });

  assert.deepEqual(Object.keys(metadata).sort(), [
    'connectionName',
    'diskPersisted',
    'errorCode',
    'status',
  ]);
  assert.doesNotMatch(JSON.stringify(metadata), /db\.internal|app_rw|secret|mariadb:\/\//);
});
