const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const { checkAdminPresence } = require('../../src/shared/lib/admin-presence-check');

function makePool({ rows, throws }) {
  return {
    rw: {
      async getConnection() {
        return {
          async query(sql, _params) {
            if (throws) throw throws;
            assert.match(sql, /WHERE role = 'admin'/);
            return rows;
          },
          release() {},
        };
      },
    },
  };
}

const t = (logical) => `prefix_${logical}`;

describe('checkAdminPresence', () => {
  it('returns admin_exists: true when count > 0', async () => {
    const pool = makePool({ rows: [{ cnt: 1 }] });
    const out = await checkAdminPresence(pool, t, 'users');
    assert.deepEqual(out, { admin_exists: true });
  });

  it('returns admin_exists: false when count is 0', async () => {
    const pool = makePool({ rows: [{ cnt: 0 }] });
    const out = await checkAdminPresence(pool, t, 'users');
    assert.deepEqual(out, { admin_exists: false });
  });

  it('returns admin_exists: false + error code on DB failure', async () => {
    const err = Object.assign(new Error('table missing'), { code: 'ER_NO_SUCH_TABLE' });
    const pool = makePool({ throws: err });
    const out = await checkAdminPresence(pool, t, 'users');
    assert.equal(out.admin_exists, false);
    assert.equal(out.error, 'ER_NO_SUCH_TABLE');
  });

  it('handles bigint counts (mariadb default)', async () => {
    const pool = makePool({ rows: [{ cnt: 5n }] });
    const out = await checkAdminPresence(pool, t, 'users');
    assert.equal(out.admin_exists, true);
  });
});
