/**
 * blueprint-import-cell-scope-retype.test.js
 *
 * An overwrite import DELETEs the target's fields and re-INSERTs them with fresh
 * ids, then repoints every variant override by field_key. The repoint never
 * consulted the NEW field's type, so an import that redeclares a previously-
 * table field as text left a cell-scoped override sitting on a non-table field:
 * the resolver finds no cells to address and hands the override to the
 * whole-field path, so a scope written to NARROW an override silently WIDENS it
 * — and a widened `hide` strips the field's whole value out of the saved
 * payload.
 *
 * The type change through the field editor already clears the scope for exactly
 * this reason; these tests pin the same outcome for the import, plus the
 * visibility the editor path gets from its audit row: a count on the response
 * and an operator-facing warning, so nothing the operator authored disappears
 * silently.
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');

const lib = require('../../src/edge/lib/blueprint-serialization');

const FAKE_TABLES = {
  HIERARCHY_NODES: 'hierarchy_nodes',
  BLUEPRINT_FIELDS: 'blueprint_fields',
  FIELD_OPTIONS: 'field_options',
  BLUEPRINT_SECTIONS: 'blueprint_sections',
  BLUEPRINT_OUTPUT_ORDER: 'blueprint_output_order',
  BLUEPRINT_GROUPS: 'blueprint_groups',
  VARIANT_OVERRIDES: 'variant_overrides',
  FEATURE_AUDIT: 'feature_audit',
};
const fakeT = (name) => `fmb_${name}`;
let counter = 0;
const fakeUuid = () => `fake-uuid-${counter++}`;

const fld = (id, key, type) => ({
  id, blueprint_id: 'bp-1', field_key: key, field_label: key, field_type: type,
  is_required: 0, default_value: '', placeholder: '', tooltip: '', section: 'general',
  order_index: 0, table_config: null, visibility_rule: null,
});

// Target blueprint as stored: two table fields and a scalar.
function currentFixture() {
  return {
    import_version: 1,
    hierarchy_node: {
      id: 'bp-1', parent_id: 'release-1', name: 'BP', description: '',
      node_type: 'blueprint', sort_order: 0, is_active: 1,
      transformer_id: null, transformer_version: null, linked_blueprint_id: null,
    },
    blueprint_fields: [
      fld('old-notes', 'notes', 'table'),
      fld('old-grid', 'grid', 'table'),
    ],
    field_options: [],
    blueprint_sections: [],
    blueprint_groups: [],
    blueprint_output_order: [],
  };
}

// The imported payload redeclares `notes` as text; `grid` stays a table.
function payloadFixture() {
  return {
    import_version: 1,
    hierarchy_node: { name: 'BP', description: '', is_active: 1, transformer_id: null, transformer_version: null },
    blueprint_fields: [
      { ...fld('pay-notes', 'notes', 'text'), blueprint_id: 'src' },
      { ...fld('pay-grid', 'grid', 'table'), blueprint_id: 'src' },
    ],
    field_options: [],
    blueprint_sections: [],
    blueprint_groups: [],
    blueprint_output_order: [],
  };
}

function makeFakeConn(current, overrides, { cellTargetsColumn = true, clearedRows = 1 } = {}) {
  const queries = [];
  return {
    queries,
    async query(sql, params) {
      queries.push({ sql, params });
      if (/information_schema\.TABLES/i.test(sql)) {
        if (params && params[0] === 'fmb_variant_overrides') return [{ n: 1 }];
        return [];
      }
      if (/SELECT DATABASE\(\) AS db/i.test(sql)) return [{ db: '' }];
      if (/information_schema\.COLUMNS/i.test(sql)) return [];
      if (/^SELECT id, field_key FROM .*blueprint_fields/i.test(sql)) {
        return current.blueprint_fields.map((f) => ({ id: f.id, field_key: f.field_key }));
      }
      if (/^SELECT id, field_id FROM .*variant_overrides/i.test(sql)) return overrides;
      if (/SET cell_targets = NULL/i.test(sql)) {
        if (!cellTargetsColumn) {
          const err = new Error("Unknown column 'cell_targets' in 'field list'");
          err.errno = 1054;
          err.code = 'ER_BAD_FIELD_ERROR';
          throw err;
        }
        return { affectedRows: clearedRows };
      }
      if (/^SELECT \* FROM .*hierarchy_nodes/i.test(sql)) return [current.hierarchy_node];
      if (/^SELECT \* FROM .*blueprint_fields/i.test(sql)) return current.blueprint_fields;
      if (/^SELECT \* FROM .*field_options/i.test(sql)) return current.field_options;
      if (/^SELECT \* FROM .*blueprint_sections/i.test(sql)) return current.blueprint_sections;
      if (/^SELECT \* FROM .*blueprint_output_order/i.test(sql)) return current.blueprint_output_order;
      if (/^SELECT id FROM .*hierarchy_nodes/i.test(sql)) return [{ id: current.hierarchy_node.id }];
      return [];
    },
  };
}

function runImport(conn, current) {
  return lib.overwriteBlueprint({
    conn, t: fakeT, TABLES: FAKE_TABLES, uuidv4: fakeUuid,
    existingId: 'bp-1', payload: payloadFixture(), userId: 'admin-1',
    expectedRevision: lib.computeRevision(current),
  });
}

const clearStatements = (conn) =>
  conn.queries.filter((q) => /SET cell_targets = NULL/i.test(q.sql));

describe('overwriteBlueprint — an override repointed onto a non-table field loses its cell scope', () => {
  it('clears the scope, counts it, and warns the operator', async () => {
    const current = currentFixture();
    const conn = makeFakeConn(current, [
      { id: 'ov-notes', field_id: 'old-notes' }, // notes becomes text → scope cleared
      { id: 'ov-grid', field_id: 'old-grid' },   // grid stays a table → untouched
    ]);
    const result = await runImport(conn, current);

    assert.equal(result.ok, true);
    assert.equal(result.clearedCellScopes, 1);
    assert.ok(
      result.warnings.some((w) => /cell/i.test(w) && /whole field/i.test(w)),
      `expected a cell-scope warning, got ${JSON.stringify(result.warnings)}`,
    );

    const clears = clearStatements(conn);
    assert.equal(clears.length, 1, 'one batched clear');
    assert.deepEqual(clears[0].params, ['ov-notes'], 'only the override on the retyped field');
    assert.match(
      clears[0].sql,
      /cell_targets IS NOT NULL/i,
      'the count must reflect rows that really carried a scope',
    );
  });

  it('leaves overrides alone when every repointed field is still a table', async () => {
    const current = currentFixture();
    const conn = makeFakeConn(current, [{ id: 'ov-grid', field_id: 'old-grid' }]);
    const result = await runImport(conn, current);
    assert.equal(result.clearedCellScopes, 0);
    assert.equal(clearStatements(conn).length, 0);
    assert.ok(!result.warnings.some((w) => /cell/i.test(w)));
  });

  it('records the clear in the overwrite audit row', async () => {
    const current = currentFixture();
    const conn = makeFakeConn(current, [{ id: 'ov-notes', field_id: 'old-notes' }]);
    await runImport(conn, current);
    const success = conn.queries.find((q) =>
      /INSERT INTO .*feature_audit/i.test(q.sql)
      && q.params.some((p) => typeof p === 'string' && /blueprint\.overwrite\.success/.test(p + '')));
    const metadata = conn.queries
      .filter((q) => /INSERT INTO .*feature_audit/i.test(q.sql))
      .map((q) => q.params.find((p) => typeof p === 'string' && p.startsWith('{')))
      .filter(Boolean)
      .map((p) => JSON.parse(p));
    assert.ok(success || metadata.length, 'an audit row is written');
    assert.ok(
      metadata.some((m) => m.cleared_cell_scopes === 1),
      `expected cleared_cell_scopes in audit metadata, got ${JSON.stringify(metadata)}`,
    );
  });

  it('degrades instead of failing the import where the cell_targets column is absent', async () => {
    const current = currentFixture();
    const conn = makeFakeConn(
      current,
      [{ id: 'ov-notes', field_id: 'old-notes' }],
      { cellTargetsColumn: false },
    );
    const result = await runImport(conn, current);
    assert.equal(result.ok, true);
    assert.equal(result.clearedCellScopes, 0, 'a DB without the column holds no scope to clear');
    assert.ok(!result.warnings.some((w) => /cell/i.test(w)));
  });

  it('an override on a removed field is dropped, not cleared', async () => {
    const current = currentFixture();
    current.blueprint_fields.push(fld('old-gone', 'gone', 'table'));
    const conn = makeFakeConn(current, [{ id: 'ov-gone', field_id: 'old-gone' }]);
    const result = await runImport(conn, current);
    assert.equal(result.droppedOverrides, 1);
    assert.equal(result.clearedCellScopes, 0);
    assert.equal(clearStatements(conn).length, 0);
  });
});

describe('planVariantOverrideRemap — the scope-clear plan', () => {
  const oldIdToFieldKey = new Map([['old-n', 'notes'], ['old-g', 'grid']]);
  const newFieldKeyToId = new Map([['notes', 'new-n'], ['grid', 'new-g']]);

  it('selects exactly the repoints whose new field is not a table', () => {
    const plan = lib.planVariantOverrideRemap(
      [{ id: 'ov-n', field_id: 'old-n' }, { id: 'ov-g', field_id: 'old-g' }],
      oldIdToFieldKey,
      newFieldKeyToId,
      new Map([['notes', 'text'], ['grid', 'table']]),
    );
    assert.deepEqual(plan.repoints.map((r) => r.id), ['ov-n', 'ov-g'], 'both still repoint');
    assert.deepEqual(plan.scopeClears, ['ov-n']);
  });

  it('plans no clear at all when the caller supplies no field types', () => {
    const plan = lib.planVariantOverrideRemap(
      [{ id: 'ov-n', field_id: 'old-n' }], oldIdToFieldKey, newFieldKeyToId,
    );
    assert.deepEqual(plan.scopeClears, []);
  });
});
