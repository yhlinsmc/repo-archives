'use strict';

/**
 * auth-jwt-error-classification.test.js
 *
 * Pins the jsonwebtoken → jose error-class mapping in the infra auth
 * middleware. classifyJwtVerifyError must keep discriminating expired vs
 * not-yet-valid (nbf) vs invalid (bad signature / malformed / disallowed alg),
 * and flag any genuinely unexpected error as 'unexpected' so it warn-logs
 * instead of being silently swallowed as an auth failure.
 *
 * Each case feeds a REAL jose error instance produced by jwtVerify, not a
 * hand-rolled stub — so the test breaks if a future jose upgrade renames or
 * restructures its error classes.
 */
const { describe, it, before } = require('node:test');
const assert = require('node:assert/strict');
const { SignJWT, jwtVerify } = require('jose');

// >= 32 chars: config.js (required transitively by the auth middleware) hard
// -fails a shorter JWT_SECRET at load in local mode.
process.env.JWT_SECRET = process.env.JWT_SECRET || 'a'.repeat(48);

const { _classifyJwtVerifyError } = require('../../src/infra/middleware/auth');

const KEY = new TextEncoder().encode('a'.repeat(48));
const OTHER_KEY = new TextEncoder().encode('b'.repeat(48));
const nowSec = () => Math.floor(Date.now() / 1000);

/** Run jwtVerify and return the thrown error (asserts it did throw). */
async function verifyAndCatch(token, key = KEY, opts = { algorithms: ['HS256'] }) {
  try {
    await jwtVerify(token, key, opts);
    throw new Error('expected jwtVerify to reject but it resolved');
  } catch (err) {
    return err;
  }
}

describe('auth classifyJwtVerifyError — jose error-class mapping', () => {
  let expiredErr, nbfErr, badSigErr, malformedErr, algErr;

  before(async () => {
    const expiredTok = await new SignJWT({ sub: 'u1' })
      .setProtectedHeader({ alg: 'HS256' })
      .setIssuedAt(nowSec() - 7200)
      .setExpirationTime(nowSec() - 3600)
      .sign(KEY);
    expiredErr = await verifyAndCatch(expiredTok);

    const nbfTok = await new SignJWT({ sub: 'u1' })
      .setProtectedHeader({ alg: 'HS256' })
      .setIssuedAt()
      .setNotBefore(nowSec() + 3600)
      .setExpirationTime('4h')
      .sign(KEY);
    nbfErr = await verifyAndCatch(nbfTok);

    const goodTok = await new SignJWT({ sub: 'u1' })
      .setProtectedHeader({ alg: 'HS256' })
      .setIssuedAt()
      .setExpirationTime('1h')
      .sign(KEY);
    badSigErr = await verifyAndCatch(goodTok, OTHER_KEY);

    malformedErr = await verifyAndCatch('not.a.jwt');

    // Signed HS256 but the verifier only allows RS256 → alg-confusion guard.
    algErr = await verifyAndCatch(goodTok, KEY, { algorithms: ['RS256'] });
  });

  it('expired token → "expired"', () => {
    assert.equal(_classifyJwtVerifyError(expiredErr), 'expired');
  });

  it('not-yet-valid (nbf) → "not_before"', () => {
    assert.equal(_classifyJwtVerifyError(nbfErr), 'not_before');
  });

  it('bad signature → "invalid"', () => {
    assert.equal(_classifyJwtVerifyError(badSigErr), 'invalid');
  });

  it('malformed token → "invalid"', () => {
    assert.equal(_classifyJwtVerifyError(malformedErr), 'invalid');
  });

  it('disallowed algorithm (alg confusion) → "invalid"', () => {
    assert.equal(_classifyJwtVerifyError(algErr), 'invalid');
  });

  it('genuinely unexpected error (e.g. edge/DB fault) → "unexpected"', () => {
    assert.equal(_classifyJwtVerifyError(new Error('connection reset')), 'unexpected');
    assert.equal(_classifyJwtVerifyError(new TypeError('boom')), 'unexpected');
  });

  it('categories are distinct — never collapses expired/nbf/invalid into one', () => {
    const kinds = new Set([
      _classifyJwtVerifyError(expiredErr),
      _classifyJwtVerifyError(nbfErr),
      _classifyJwtVerifyError(badSigErr),
    ]);
    assert.equal(kinds.size, 3, 'expired, not_before, invalid must be three distinct kinds');
  });
});
