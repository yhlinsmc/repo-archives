/**
 * cell-targets-validate.test.js — shape guard for the variant-override
 * cell_targets JSON column.
 *
 * The write routes build their column list from the request body, so this
 * validator is the only thing between an operator-supplied document and the
 * column. Pure function: no DB, no network.
 */
const { test, describe } = require('node:test');
const assert = require('node:assert/strict');

const {
  invalidCellTargetsShape,
  MAX_TARGET_ROWS,
  MAX_TARGET_COLUMNS,
  MAX_COLUMN_KEY_LENGTH,
} = require('../../src/shared/cell-targets-validate');

const accepted = (v) => assert.equal(invalidCellTargetsShape(v), null,
  `expected ${JSON.stringify(v)} to be accepted, got: ${invalidCellTargetsShape(v)}`);
const rejected = (v) => assert.ok(typeof invalidCellTargetsShape(v) === 'string' && invalidCellTargetsShape(v).length > 0,
  `expected ${JSON.stringify(v)} to be rejected`);

describe('whole-field scope', () => {
  test('null, undefined and {} all mean whole-field and are accepted', () => {
    accepted(null);
    accepted(undefined);
    accepted({});
  });

  test('explicit null on either side is accepted', () => {
    accepted({ rows: null, columns: null });
    accepted({ rows: [0], columns: null });
    accepted({ rows: null, columns: ['a'] });
  });
});

describe('valid targets', () => {
  test('0-based row indices and non-empty column keys', () => {
    accepted({ rows: [0, 1, 7] });
    accepted({ columns: ['qty', 'unit'] });
    accepted({ rows: [0], columns: ['qty'] });
  });

  test('empty arrays are a legal (inert) target set', () => {
    accepted({ rows: [], columns: [] });
  });

  test('a row index past the end of the table is inert, not an error', () => {
    // Rows are added by the end user at fill-in time, so no row count exists to
    // validate against at write time.
    accepted({ rows: [999] });
  });

  test('the serialized form is accepted (some write paths validate post-mapping)', () => {
    accepted(JSON.stringify({ rows: [1], columns: ['qty'] }));
    accepted('null');
  });
});

describe('rejected shapes', () => {
  test('unknown keys are rejected rather than ignored', () => {
    rejected({ column: ['qty'] });
    rejected({ rows: [0], cells: [] });
  });

  test('non-object documents', () => {
    rejected([]);
    rejected([{ rows: [0] }]);
    rejected(42);
    rejected(true);
    rejected('not json');
  });

  test('row indices must be non-negative integers', () => {
    rejected({ rows: [-1] });
    rejected({ rows: [1.5] });
    rejected({ rows: ['0'] });
    rejected({ rows: [null] });
    rejected({ rows: [Number.MAX_SAFE_INTEGER + 2] });
    rejected({ rows: {} });
  });

  test('column keys must be non-empty strings', () => {
    rejected({ columns: [''] });
    rejected({ columns: [1] });
    rejected({ columns: [null] });
    rejected({ columns: 'qty' });
    rejected({ columns: ['x'.repeat(MAX_COLUMN_KEY_LENGTH + 1)] });
  });

  test('oversized target sets are bounded', () => {
    accepted({ rows: Array.from({ length: MAX_TARGET_ROWS }, (_, i) => i) });
    rejected({ rows: Array.from({ length: MAX_TARGET_ROWS + 1 }, (_, i) => i) });
    accepted({ columns: Array.from({ length: MAX_TARGET_COLUMNS }, (_, i) => `c${i}`) });
    rejected({ columns: Array.from({ length: MAX_TARGET_COLUMNS + 1 }, (_, i) => `c${i}`) });
  });

  test('a rejection always carries a reason string', () => {
    assert.match(invalidCellTargetsShape({ nope: 1 }), /unknown key/);
    assert.match(invalidCellTargetsShape({ rows: [-1] }), /rows/);
    assert.match(invalidCellTargetsShape({ columns: [''] }), /columns/);
  });
});
