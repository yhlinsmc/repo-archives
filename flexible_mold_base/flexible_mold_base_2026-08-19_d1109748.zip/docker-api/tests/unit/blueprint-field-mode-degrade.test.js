/**
 * blueprint-field-mode-degrade.test.js — what the field-mode read still
 * enforces on a database that carries only SOME of the additive mode columns.
 *
 * `value_source` and `value_scope` are added by two independent registry steps,
 * both severity 'warning', so a target can sit between them indefinitely. The
 * read is a single SELECT and 1054 kills all of it, which makes the in-between
 * shape correct only if the fallback re-reads the columns that ARE present.
 * Falling straight to the rule-only read loses a mode that is sitting in the
 * row: `'locked'` carries no compute rule by construction, so a locked field
 * read that way answers "nothing is locked here" and a cell-scoped override
 * that must be refused is allowed instead.
 *
 * The refusal is asserted through refuseCellWriteOverBlueprintLock rather than
 * on the returned shape alone, because the shape is only interesting for what
 * the guard does with it.
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');

const {
  loadBlueprintFieldMode,
  buildBlueprintFieldModeSql,
  buildBlueprintFieldColumnSql,
  MODE_READ_COLUMNS,
} = require('../../src/edge/lib/compute-rule-graph');
const { refuseCellWriteOverBlueprintLock } = require('../../src/edge/lib/blueprint-cell-lock');

const TABLES = { BLUEPRINT_FIELDS: 'blueprint_fields' };
const t = (name) => `fmb_${name}`;
const deps = { t, TABLES };

const MODE_COLUMNS = ['compute_rule', 'value_source', 'value_scope'];

const names = (sql, column) => new RegExp(`\\b${column}\\b`).test(sql);

// The statements the per-column fallback issues, in order, after the combined
// read raises 1054.
const perColumnReads = () => MODE_READ_COLUMNS.map((c) => buildBlueprintFieldColumnSql(c, deps));
const afterCombinedRead = () => [buildBlueprintFieldModeSql(deps), ...perColumnReads()];

const LOCKING_RULE = { op: 'concat', overridable: false, config: { parts: [{ type: 'field', key: 'a' }] } };

/**
 * A connection whose blueprint_fields really lacks `missing`: any statement
 * naming one of those columns raises 1054, and a statement that survives
 * returns only the columns it actually selected — so a level that never reads a
 * column cannot accidentally receive it.
 */
function makeConn({ missing = [], stored = {}, failWith = null } = {}) {
  const statements = [];
  return {
    statements,
    async query(sql) {
      statements.push(sql);
      const absent = missing.find((column) => names(sql, column));
      if (absent) {
        const err = new Error(`Unknown column '${absent}' in 'field list'`);
        err.errno = 1054;
        err.code = 'ER_BAD_FIELD_ERROR';
        throw err;
      }
      if (failWith && failWith.when(sql)) throw failWith.err;
      if (stored === null) return [];
      const row = {};
      for (const column of MODE_COLUMNS) if (names(sql, column)) row[column] = stored[column] ?? null;
      return [row];
    },
  };
}

describe('loadBlueprintFieldMode — every column present', () => {
  it('reads the mode, its cell scope and the rule from the one statement', async () => {
    const conn = makeConn({
      stored: { value_source: 'locked', value_scope: '{"rows":[2]}', compute_rule: null },
    });
    const mode = await loadBlueprintFieldMode(conn, 'f1', deps);

    assert.deepEqual(mode, { computeRule: null, valueSource: 'locked', valueScope: '{"rows":[2]}' });
    assert.equal(conn.statements.length, 1, 'no fallback is issued when nothing is missing');
    assert.equal(conn.statements[0], buildBlueprintFieldModeSql(deps));
  });

  it('a cell-scoped write outside the locked cells is still allowed', async () => {
    const conn = makeConn({
      stored: { value_source: 'locked', value_scope: '{"rows":[2]}', compute_rule: null },
    });
    const mode = await loadBlueprintFieldMode(conn, 'f1', deps);
    assert.equal(refuseCellWriteOverBlueprintLock('compute', { rows: [5] }, mode), null);
  });
});

describe('loadBlueprintFieldMode — value_source present, value_scope not yet added', () => {
  it('re-reads each column on its own instead of dropping to the rule alone', async () => {
    const conn = makeConn({
      missing: ['value_scope'],
      stored: { value_source: 'locked', compute_rule: null },
    });
    const mode = await loadBlueprintFieldMode(conn, 'f1', deps);

    assert.equal(mode.valueSource, 'locked', 'the mode is in the row and must be read');
    assert.equal(mode.valueScope, null, 'no column to store a scope in — the mode is whole-field');
    assert.equal(mode.computeRule, null);
    assert.deepEqual(conn.statements, afterCombinedRead());
  });

  it('still refuses a cell-scoped override over a locked field', async () => {
    const conn = makeConn({
      missing: ['value_scope'],
      stored: { value_source: 'locked', compute_rule: null },
    });
    const mode = await loadBlueprintFieldMode(conn, 'f1', deps);

    const refusal = refuseCellWriteOverBlueprintLock('compute', { rows: [0] }, mode);
    assert.ok(refusal, 'a locked field must refuse a cell-scoped compute override');
    assert.equal(refusal.status, 422);
    assert.match(refusal.error, /'locked'/);
  });

  it('reads a non-overridable rule under a compute-backed mode as whole-field', async () => {
    const conn = makeConn({
      missing: ['value_scope'],
      stored: { value_source: 'calculated', compute_rule: JSON.stringify(LOCKING_RULE) },
    });
    const mode = await loadBlueprintFieldMode(conn, 'f1', deps);

    assert.equal(mode.valueSource, 'calculated');
    assert.ok(mode.computeRule, 'the rule is read at this level too');
    const refusal = refuseCellWriteOverBlueprintLock('compute', { rows: [0] }, mode);
    assert.ok(refusal, 'a non-overridable rule covers every cell here');
    assert.equal(refusal.status, 422);
  });

  it('leaves an entered field writable', async () => {
    const conn = makeConn({
      missing: ['value_scope'],
      stored: { value_source: 'entered', compute_rule: null },
    });
    const mode = await loadBlueprintFieldMode(conn, 'f1', deps);
    assert.equal(refuseCellWriteOverBlueprintLock('compute', { rows: [0] }, mode), null);
  });
});

describe('loadBlueprintFieldMode — neither mode column added', () => {
  it('keeps the rule, with the mode reported as unknown', async () => {
    const conn = makeConn({
      missing: ['value_scope', 'value_source'],
      stored: { compute_rule: JSON.stringify(LOCKING_RULE) },
    });
    const mode = await loadBlueprintFieldMode(conn, 'f1', deps);

    assert.equal(mode.valueSource, null, 'no column, so no mode to report');
    assert.equal(mode.valueScope, null);
    assert.deepEqual(mode.computeRule, LOCKING_RULE, 'the rule must not be lost with the mode');
    assert.deepEqual(conn.statements, afterCombinedRead(),
      'each column is asked for separately, so a present one is never skipped');
  });

  it('reads that rule as covering the whole field, which is all this level can say', async () => {
    const conn = makeConn({
      missing: ['value_scope', 'value_source'],
      stored: { compute_rule: JSON.stringify(LOCKING_RULE) },
    });
    const mode = await loadBlueprintFieldMode(conn, 'f1', deps);

    const refusal = refuseCellWriteOverBlueprintLock('compute', { rows: [0] }, mode);
    assert.ok(refusal, 'the rule alone is whole-field on a DB with no mode column');
    assert.equal(refusal.status, 422);
  });
});

describe('loadBlueprintFieldMode — compute_rule missing while the mode is present', () => {
  // The mirror of the case above, and the one a per-combination fallback misses:
  // compute_rule is an additive step of its own, so it can be the column that is
  // absent while both mode columns are there to read. Every read here must still
  // find the mode.
  it('reads the mode and its scope when only the rule column is absent', async () => {
    const conn = makeConn({
      missing: ['compute_rule'],
      stored: { value_source: 'locked', value_scope: '{"rows":[0]}' },
    });
    const mode = await loadBlueprintFieldMode(conn, 'f1', deps);

    assert.equal(mode.valueSource, 'locked');
    assert.equal(mode.valueScope, '{"rows":[0]}', 'the scope column is readable and must be read');
    assert.equal(mode.computeRule, null, 'no rule column means no rule, which is exact');
  });

  it('refuses a cell-scoped override over that lock', async () => {
    const conn = makeConn({
      missing: ['compute_rule'],
      stored: { value_source: 'locked', value_scope: '{"rows":[0]}' },
    });
    const mode = await loadBlueprintFieldMode(conn, 'f1', deps);

    const refusal = refuseCellWriteOverBlueprintLock('compute', { rows: [0] }, mode);
    assert.ok(refusal, 'a locked field must refuse a write into the cells it holds');
    assert.equal(refusal.status, 422);
  });

  it('still allows a write into cells that scope does not name', async () => {
    // The scope was readable, so the lock is judged at the granularity it was
    // stored — not widened to the whole field.
    const conn = makeConn({
      missing: ['compute_rule'],
      stored: { value_source: 'locked', value_scope: '{"rows":[0]}' },
    });
    const mode = await loadBlueprintFieldMode(conn, 'f1', deps);
    assert.equal(refuseCellWriteOverBlueprintLock('compute', { rows: [7] }, mode), null);
  });

  it('reads the mode when the rule AND the scope columns are both absent', async () => {
    const conn = makeConn({
      missing: ['compute_rule', 'value_scope'],
      stored: { value_source: 'locked' },
    });
    const mode = await loadBlueprintFieldMode(conn, 'f1', deps);

    assert.equal(mode.valueSource, 'locked');
    assert.equal(mode.valueScope, null);
    const refusal = refuseCellWriteOverBlueprintLock('compute', { rows: [0] }, mode);
    assert.ok(refusal, 'with no scope column the lock reaches every cell');
    assert.equal(refusal.status, 422);
  });

  it('reads the rule when the mode column is the absent one', async () => {
    const conn = makeConn({
      missing: ['value_source'],
      stored: { compute_rule: JSON.stringify(LOCKING_RULE), value_scope: '{"rows":[0]}' },
    });
    const mode = await loadBlueprintFieldMode(conn, 'f1', deps);

    assert.equal(mode.valueSource, null, 'no mode column, so no mode');
    assert.deepEqual(mode.computeRule, LOCKING_RULE);
    const refusal = refuseCellWriteOverBlueprintLock('compute', { rows: [0] }, mode);
    assert.ok(refusal, 'a rule with no mode beside it is whole-field');
  });

  it('locks nothing when neither a rule nor a mode can be read', async () => {
    // value_scope alone stores no setting: a scope narrows a mode, and there is
    // no column here to hold one.
    const conn = makeConn({
      missing: ['compute_rule', 'value_source'],
      stored: { value_scope: '{"rows":[0]}' },
    });
    const mode = await loadBlueprintFieldMode(conn, 'f1', deps);

    assert.equal(mode.valueSource, null);
    assert.equal(mode.computeRule, null);
    assert.equal(refuseCellWriteOverBlueprintLock('compute', { rows: [0] }, mode), null);
  });
});

describe('loadBlueprintFieldMode — the shapes that are not a missing column', () => {
  it('reports nothing at all when the row is gone', async () => {
    const conn = makeConn({ stored: null });
    assert.deepEqual(
      await loadBlueprintFieldMode(conn, 'gone', deps),
      { computeRule: null, valueSource: null, valueScope: null },
    );
  });

  it('propagates a real failure from the first read', async () => {
    const boom = new Error('connection lost');
    boom.errno = 2013;
    const conn = makeConn({ failWith: { when: () => true, err: boom } });
    await assert.rejects(() => loadBlueprintFieldMode(conn, 'f1', deps), /connection lost/);
  });

  it('propagates a real failure from a per-column read rather than degrading past it', async () => {
    const boom = new Error('connection lost');
    boom.errno = 2013;
    const conn = makeConn({
      missing: ['value_scope'],
      stored: { value_source: 'locked' },
      failWith: { when: (sql) => /^SELECT value_source\b/.test(sql), err: boom },
    });
    await assert.rejects(() => loadBlueprintFieldMode(conn, 'f1', deps), /connection lost/);
    assert.ok(
      !conn.statements.includes(buildBlueprintFieldColumnSql('value_scope', deps)),
      'a broken connection must not be read as an absent column and carried past',
    );
  });
});
