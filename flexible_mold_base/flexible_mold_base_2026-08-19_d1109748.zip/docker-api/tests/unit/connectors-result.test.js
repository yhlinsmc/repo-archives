const { it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const cdKey = require.resolve('../../src/edge/lib/connector-dispatch');
const cd = require('../../src/edge/lib/connector-dispatch');
let execBehavior = () => ({ upstream_status: 200, headers: { 'content-type': 'application/json' }, body: '{"v":1}', truncated: false, duration_ms: 5 });
let pinBehavior = async () => ({ address: '10.0.0.9', family: 4 });
cd.executeRequest = (...a) => Promise.resolve().then(() => execBehavior(...a));
cd.resolveAndPin = (...a) => Promise.resolve().then(() => pinBehavior(...a));
require.cache[cdKey].exports = cd;

const guardKey = require.resolve('../../src/shared/lib/ssrf-guard');
const guard = require('../../src/shared/lib/ssrf-guard');
guard.resolveAndPin = (...a) => Promise.resolve().then(() => pinBehavior(...a));
require.cache[guardKey].exports = guard;

const dbKey = require.resolve('../../src/edge/db');
let auditEvents; let connectorRow;
const conn = {
  async query(sql, params) {
    if (/FROM `fmb_api_connectors` WHERE id = \?/.test(sql)) return params[0] === 'live' && connectorRow ? [connectorRow] : [];
    if (/INSERT INTO `fmb_feature_audit`/.test(sql)) { auditEvents.push({ event: params[1], meta: JSON.parse(params[3]) }); return { affectedRows: 1 }; }
    if (/information_schema\.COLUMNS/i.test(sql)) return [];
    if (/SELECT DATABASE\(\)/.test(sql)) return [{ db: 'testdb' }];
    return [];
  },
  release() {},
};
require.cache[dbKey] = { id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: { ro: { getConnection: async () => conn }, rw: { getConnection: async () => conn } }, t: (n) => `fmb_${n}` } };

const router = require('../../src/edge/routes/internal/connectors');

let server; let baseUrl;
before(async () => {
  const app = express(); app.use(express.json());
  app.use((req, _res, next) => { req.user = { id: 'u1', role: 'user' }; next(); });
  app.use('/edge/internal/connectors', router);
  server = http.createServer(app); await new Promise((r) => server.listen(0, r));
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});
after(() => server && server.close());
beforeEach(() => {
  auditEvents = []; cd.breaker._reset('live');
  connectorRow = { id: 'live', name: 'm', is_active: 1, auth_type: 'bearer', auth_config: JSON.stringify({ token: 'SEKRET' }),
    request_config: JSON.stringify({ headers: {} }), response_config: JSON.stringify({}), dispatch_origin: 'infra', method: 'GET', url: 'http://svc.internal/echo' };
});

async function post(path, body) {
  const res = await fetch(`${baseUrl}${path}`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) });
  return { status: res.status, body: await res.json() };
}

it('result success writes a success audit and records breaker success', async () => {
  cd.breaker.recordFailure('live'); cd.breaker.recordFailure('live');
  const r = await post('/edge/internal/connectors/result', { dispatch_id: 'd1', connector_id: 'live', success: true, upstream_status: 200, duration_ms: 7, host: 'svc.internal', method: 'GET' });
  assert.equal(r.status, 200);
  assert.deepEqual(auditEvents.map((e) => e.event), ['connector.fetch.success']);
  assert.equal(cd.breaker.canDispatch('live'), true);
});

it('result failure writes a failed audit and records breaker failure', async () => {
  const r = await post('/edge/internal/connectors/result', { dispatch_id: 'd2', connector_id: 'live', success: false, error_code: 'CONNECTOR_TIMEOUT', host: 'svc.internal', method: 'GET' });
  assert.equal(r.status, 200);
  assert.deepEqual(auditEvents.map((e) => e.event), ['connector.fetch.failed']);
  assert.equal(auditEvents[0].meta.error_code, 'CONNECTOR_TIMEOUT');
});

it('result is idempotent on a repeated dispatch_id', async () => {
  await post('/edge/internal/connectors/result', { dispatch_id: 'dup', connector_id: 'live', success: true, host: 'svc.internal', method: 'GET' });
  await post('/edge/internal/connectors/result', { dispatch_id: 'dup', connector_id: 'live', success: true, host: 'svc.internal', method: 'GET' });
  assert.equal(auditEvents.filter((e) => e.event === 'connector.fetch.success').length, 1);
});

it('result requires connector_id (400)', async () => {
  const r = await post('/edge/internal/connectors/result', { dispatch_id: 'x', success: true });
  assert.equal(r.status, 400);
});

it('result never folds an extra body field (e.g. a secret) into the audit row', async () => {
  await post('/edge/internal/connectors/result', { dispatch_id: 's1', connector_id: 'live', success: true, host: 'svc.internal', method: 'GET', auth_config: { token: 'SEKRET' }, headers: { Authorization: 'Bearer SEKRET' } });
  assert.equal(JSON.stringify(auditEvents[0].meta).includes('SEKRET'), false);
});

it('result ignores a non-string dispatch_id for idempotency', async () => {
  const r = await post('/edge/internal/connectors/result', { dispatch_id: 123, connector_id: 'live', success: true, host: 'svc.internal', method: 'GET' });
  assert.equal(r.status, 200);
  assert.deepEqual(auditEvents.map((e) => e.event), ['connector.fetch.success']);
});
