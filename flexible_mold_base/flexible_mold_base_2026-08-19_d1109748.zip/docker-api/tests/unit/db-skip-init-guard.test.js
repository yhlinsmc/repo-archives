/**
 * db-skip-init-guard.test.js — v3.2.51a PR1-review HIGH fix pin.
 *
 * SKIP_DB_INIT=1 is a test-only escape that bypasses MariaDB pool init
 * so Ship Gate boot-smoke can run without a reachable DB. It MUST throw
 * if ever set with NODE_ENV=production — a misconfigured ConfigMap that
 * leaks this from a smoke template would otherwise boot an edge pod
 * with no DB pool and fail silently at first request.
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');

function withEnv(vars, fn) {
  const prev = {};
  for (const k of Object.keys(vars)) {
    prev[k] = process.env[k];
    if (vars[k] === undefined) delete process.env[k];
    else process.env[k] = vars[k];
  }
  return Promise.resolve()
    .then(fn)
    .finally(() => {
      for (const k of Object.keys(prev)) {
        if (prev[k] === undefined) delete process.env[k];
        else process.env[k] = prev[k];
      }
    });
}

describe('SKIP_DB_INIT=1 production guard', () => {
  it('throws when NODE_ENV=production', async () => {
    // Load fresh so no module-level cache pollutes state.
    delete require.cache[require.resolve('../../src/edge/db')];
    const { initializeFromConfig } = require('../../src/edge/db');
    await withEnv(
      { SKIP_DB_INIT: '1', NODE_ENV: 'production' },
      async () => {
        await assert.rejects(
          () => initializeFromConfig(),
          (err) => {
            assert.match(err.message, /SKIP_DB_INIT=1 is not allowed in NODE_ENV=production/);
            // The rejection MUST carry the fatalBoot marker so the edge boot
            // guard crashes the pod on it instead of degrading to setup-required.
            assert.equal(err.fatalBoot, true);
            return true;
          },
        );
      },
    );
  });

  it('throws when NODE_ENV=PRODUCTION (case-insensitive)', async () => {
    delete require.cache[require.resolve('../../src/edge/db')];
    const { initializeFromConfig } = require('../../src/edge/db');
    await withEnv(
      { SKIP_DB_INIT: '1', NODE_ENV: 'PRODUCTION' },
      async () => {
        await assert.rejects(
          () => initializeFromConfig(),
          /SKIP_DB_INIT=1 is not allowed in NODE_ENV=production/,
        );
      },
    );
  });

  it('warn-and-returns when NODE_ENV=development', async () => {
    delete require.cache[require.resolve('../../src/edge/db')];
    const { initializeFromConfig } = require('../../src/edge/db');
    await withEnv(
      { SKIP_DB_INIT: '1', NODE_ENV: 'development' },
      async () => {
        // Should resolve without throwing.
        await assert.doesNotReject(() => initializeFromConfig());
      },
    );
  });

  it('warn-and-returns when NODE_ENV unset', async () => {
    delete require.cache[require.resolve('../../src/edge/db')];
    const { initializeFromConfig } = require('../../src/edge/db');
    await withEnv(
      { SKIP_DB_INIT: '1', NODE_ENV: undefined },
      async () => {
        await assert.doesNotReject(() => initializeFromConfig());
      },
    );
  });
});
