/**
 * api-connectors-write-url-guard.test.js — CRUD write-path url guard.
 *
 * Exercises the url-validation middleware in src/edge/routes/app/api-connectors/index.js:
 * POST and PUT with a non-http(s) url must be rejected 400 BAD_REQUEST before the
 * CRUD factory handles the request.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

// Stub executeRequest BEFORE the router requires connector-dispatch so the
// CRUD factory's internal paths don't attempt real network calls.
const cdKey = require.resolve('../../src/edge/lib/connector-dispatch');
const cd = require('../../src/edge/lib/connector-dispatch');
cd.executeRequest = () => Promise.resolve({ upstream_status: 200, headers: {}, body: '', truncated: false, duration_ms: 0 });
require.cache[cdKey].exports = cd;

const dbKey = require.resolve('../../src/edge/db');
let connectorRow; let allowlistValue;
const conn = {
  async query(sql, params) {
    if (/FROM `fmb_api_connectors` WHERE id = \?/.test(sql)) {
      return params[0] === 'live' && connectorRow ? [connectorRow] : [];
    }
    if (/FROM `fmb_system_settings` WHERE `key` = \?/.test(sql)) return allowlistValue == null ? [] : [{ value: allowlistValue }];
    if (/INSERT INTO `fmb_feature_audit`/.test(sql)) return { affectedRows: 1 };
    if (/information_schema\.COLUMNS/i.test(sql)) return [];
    if (/SELECT DATABASE\(\)/.test(sql)) return [{ db: 'testdb' }];
    return [];
  },
  release() {},
};
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: { ro: { getConnection: async () => conn, query: conn.query }, rw: { getConnection: async () => conn } }, t: (n) => `fmb_${n}` },
};

const router = require('../../src/edge/routes/app/api-connectors');
const { breaker } = cd;

let server; let baseUrl;
before(async () => {
  const app = express(); app.use(express.json());
  app.use((req, _res, next) => { req.user = { id: 'admin', role: 'admin' }; next(); });
  app.use('/c', router);
  server = http.createServer(app); await new Promise((r) => server.listen(0, r));
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});
after(() => server && server.close());

beforeEach(() => {
  connectorRow = {
    id: 'live', name: 'm', is_active: 1, auth_type: 'none', auth_config: JSON.stringify({}),
    request_config: JSON.stringify({ headers: {} }), response_config: JSON.stringify({}),
    dispatch_origin: 'edge', method: 'GET', url: 'http://svc.internal/echo',
  };
  allowlistValue = null; // empty allow-list → allow-all (existing tests unaffected)
  breaker._reset('live');
});

describe('CRUD url validation (write boundary)', () => {
  it('rejects a non-http(s) url on POST', async () => {
    const res = await fetch(`${baseUrl}/c`, {
      method: 'POST', headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ name: 'x', url: 'file:///etc/passwd', method: 'GET', auth_type: 'none' }),
    });
    assert.equal(res.status, 400);
    assert.equal((await res.json()).error.code, 'BAD_REQUEST');
  });

  it('rejects a url with embedded credentials on POST', async () => {
    const res = await fetch(`${baseUrl}/c`, {
      method: 'POST', headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ name: 'x', url: 'https://user:pass@svc/x', method: 'GET', auth_type: 'none' }),
    });
    assert.equal(res.status, 400, 'userinfo in a url is rejected at the write boundary');
    assert.equal((await res.json()).error.code, 'BAD_REQUEST');
  });
});

describe('CRUD global host allow-list (save boundary)', () => {
  it('rejects a create whose host is off the global allow-list (422)', async () => {
    allowlistValue = JSON.stringify(['api.allowed.com']);
    const res = await fetch(`${baseUrl}/c`, {
      method: 'POST', headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ name: 'x', url: 'https://evil.com/x', method: 'GET', auth_type: 'none' }),
    });
    assert.equal(res.status, 422);
    assert.equal((await res.json()).error.code, 'EGRESS_BLOCKED');
  });

  it('lets an on-list host pass the allow-list gate (not 422)', async () => {
    allowlistValue = JSON.stringify(['*.allowed.com', 'api.allowed.com']);
    const res = await fetch(`${baseUrl}/c`, {
      method: 'POST', headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ name: 'x', url: 'https://api.allowed.com/x', method: 'GET', auth_type: 'none' }),
    });
    assert.notEqual(res.status, 422, 'on-list host must not be blocked by the allow-list gate');
  });

  it('allows any host when the allow-list is empty (opt-in)', async () => {
    allowlistValue = null;
    const res = await fetch(`${baseUrl}/c`, {
      method: 'POST', headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ name: 'x', url: 'https://anything.example/x', method: 'GET', auth_type: 'none' }),
    });
    assert.notEqual(res.status, 422, 'empty allow-list must allow all hosts');
  });
});
