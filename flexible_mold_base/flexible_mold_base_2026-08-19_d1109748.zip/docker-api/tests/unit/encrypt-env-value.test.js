/**
 * encrypt-env-value.test.js — v3.2.53 Q2
 *
 * Black-box tests that spawn the CLI with controlled env + tty settings
 * via a pty-like stdin/stdout pair and assert:
 *   - `--help` exits 0 with usage on stderr, no stdout
 *   - Missing SETTINGS_ENCRYPTION_KEY exits 1 with usage hint
 *   - Argument-mode encrypt succeeds, stdout = one enc:v1: line
 *   - Pipe-mode encrypt works via stdin
 *   - No-arg + TTY stdin fast-fails instead of hanging
 *   - TTY stdout emits educational footer on stderr
 *   - Non-TTY stdout is clean (no footer) — safe for command substitution
 *   - Two runs produce DIFFERENT ciphertexts (random IV) — both decrypt
 *     to the same plaintext
 */

const { test } = require('node:test');
const assert = require('node:assert/strict');
const { spawnSync } = require('node:child_process');
const path = require('node:path');

const SCRIPT = path.join(__dirname, '..', '..', 'scripts', 'encrypt-env-value.js');
const TEST_KEY = 'a'.repeat(64); // 32 bytes hex — matches settings-crypto expectations

function run({ args = [], input = null, env = {}, stdoutTTY = false, stdinTTY = false } = {}) {
  // node -e sets process.argv = [node, ...args] (NO [eval] placeholder).
  // Splice in a dummy at index 1 so the script under test sees argv[2] as
  // its first real argument, matching a normal `node script.js arg` invocation.
  // The '--' after runnerCode is node's end-of-flags marker, so user args
  // starting with '-' (like '--help') reach argv instead of being consumed
  // by node itself.
  const runnerCode = `
    process.stdout.isTTY = ${stdoutTTY ? 'true' : 'false'};
    process.stdin.isTTY = ${stdinTTY ? 'true' : 'false'};
    process.argv.splice(1, 0, 'encrypt-env-value.js');
    require(${JSON.stringify(SCRIPT)});
  `;
  // Strip NODE_TEST_CONTEXT from child env — it's auto-injected by
  // `node --test` and triggers a one-line logger warning from
  // docker-api/src/shared/lib/logger that pollutes stderr in these tests.
  const childEnv = { ...process.env, ...env };
  delete childEnv.NODE_TEST_CONTEXT;
  return spawnSync(process.execPath, ['-e', runnerCode, '--', ...args], {
    input: input === null ? undefined : input,
    env: childEnv,
    encoding: 'utf8',
  });
}

test('--help exits 0 with usage on stderr, no stdout', () => {
  const r = run({ args: ['--help'] });
  assert.equal(r.status, 0);
  assert.equal(r.stdout, '');
  assert.match(r.stderr, /Usage /);
  assert.match(r.stderr, /encrypt-env-value\.js/);
});

test('-h short form also prints help', () => {
  const r = run({ args: ['-h'] });
  assert.equal(r.status, 0);
  assert.match(r.stderr, /Usage /);
});

test('missing SETTINGS_ENCRYPTION_KEY exits 1 with usage hint', () => {
  const r = run({ args: ['somepass'], env: { SETTINGS_ENCRYPTION_KEY: '' } });
  assert.equal(r.status, 1);
  assert.match(r.stderr, /SETTINGS_ENCRYPTION_KEY env var is required/);
  assert.match(r.stderr, /Usage /);
});

test('argument-mode encrypt succeeds, stdout = single enc:v1: line', () => {
  const r = run({ args: ['hello-world'], env: { SETTINGS_ENCRYPTION_KEY: TEST_KEY } });
  assert.equal(r.status, 0);
  const lines = r.stdout.trim().split('\n');
  assert.equal(lines.length, 1, 'stdout should be exactly one line');
  assert.match(lines[0], /^enc:v1:/);
});

test('pipe-mode encrypt reads stdin when no argument given', () => {
  const r = run({
    input: 'from-stdin\n',
    env: { SETTINGS_ENCRYPTION_KEY: TEST_KEY },
    stdinTTY: false, // pipe
  });
  assert.equal(r.status, 0);
  assert.match(r.stdout, /^enc:v1:/);
});

test('no argument + TTY stdin fast-fails (does not hang)', () => {
  const r = run({
    args: [],
    env: { SETTINGS_ENCRYPTION_KEY: TEST_KEY },
    stdinTTY: true,
  });
  assert.equal(r.status, 1);
  assert.match(r.stderr, /stdin is a TTY/);
  assert.match(r.stderr, /Usage /);
});

test('TTY stdout emits educational footer on stderr', () => {
  const r = run({
    args: ['pass'],
    env: { SETTINGS_ENCRYPTION_KEY: TEST_KEY },
    stdoutTTY: true,
  });
  assert.equal(r.status, 0);
  assert.match(r.stdout, /^enc:v1:/); // ciphertext on stdout (clean)
  assert.match(r.stderr, /DB_RW_PASSWORD_ENCRYPTED/);
  assert.match(r.stderr, /random IV/);
});

test('non-TTY stdout is clean (no footer) — safe for $(...) capture', () => {
  const r = run({
    args: ['pass'],
    env: { SETTINGS_ENCRYPTION_KEY: TEST_KEY },
    stdoutTTY: false,
  });
  assert.equal(r.status, 0);
  assert.equal(r.stderr, '', 'stderr should be empty in non-TTY mode');
  assert.match(r.stdout, /^enc:v1:/);
});

test('random IV: two runs produce different ciphertext, both decrypt same', async () => {
  const r1 = run({ args: ['same-plaintext'], env: { SETTINGS_ENCRYPTION_KEY: TEST_KEY } });
  const r2 = run({ args: ['same-plaintext'], env: { SETTINGS_ENCRYPTION_KEY: TEST_KEY } });
  assert.equal(r1.status, 0);
  assert.equal(r2.status, 0);
  const ct1 = r1.stdout.trim();
  const ct2 = r2.stdout.trim();
  assert.notEqual(ct1, ct2, 'two runs must produce different ciphertext (random IV)');

  // Both decrypt to the same plaintext under the same key.
  // Snapshot + restore process.env so the in-process require() + mutation
  // does not leak into any subsequent test file that shares the runner.
  const savedKey = process.env.SETTINGS_ENCRYPTION_KEY;
  try {
    process.env.SETTINGS_ENCRYPTION_KEY = TEST_KEY;
    const { decrypt } = require('../../src/shared/lib/settings-crypto');
    assert.equal(decrypt(ct1), 'same-plaintext');
    assert.equal(decrypt(ct2), 'same-plaintext');
  } finally {
    if (savedKey === undefined) delete process.env.SETTINGS_ENCRYPTION_KEY;
    else process.env.SETTINGS_ENCRYPTION_KEY = savedKey;
  }
});
