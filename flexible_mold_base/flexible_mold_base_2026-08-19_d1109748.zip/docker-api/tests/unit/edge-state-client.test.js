/**
 * edge-state-client.test.js — typed-error behavior of the infra S2S client.
 *
 * Stubs global fetch to exercise the success / 401 / 503 / timeout / non-JSON
 * paths and asserts the right error class is thrown.
 */
const { describe, it, beforeEach, afterEach } = require('node:test');
const assert = require('node:assert/strict');

process.env.S2S_API_KEY = process.env.S2S_API_KEY || 's2s-test-key';
process.env.EDGE_API_URL = process.env.EDGE_API_URL || 'http://edge-test:3201';

const mod = require('../../src/infra/lib/edge-state-client');
const {
  resolveIdentity,
  fetchAuthMode,
  fetchEdgeHealth,
  EdgeUnreachable,
  EdgeAuthFailed,
  EdgeTimeout,
  EdgeBadResponse,
} = mod;

const originalFetch = globalThis.fetch;

beforeEach(() => {
  globalThis.fetch = async () => { throw new Error('fetch not stubbed'); };
});

afterEach(() => {
  globalThis.fetch = originalFetch;
});

function jsonResp(status, body) {
  return {
    ok: status >= 200 && status < 300,
    status,
    json: async () => body,
    text: async () => JSON.stringify(body),
  };
}
function textResp(status, body) {
  return {
    ok: status >= 200 && status < 300,
    status,
    json: async () => { throw new Error('not json'); },
    text: async () => body,
  };
}

describe('edge-state-client — resolveIdentity', () => {
  it('returns data on 200 + apiOk envelope', async () => {
    globalThis.fetch = async () => jsonResp(200, {
      ok: true,
      data: { user: { id: 'u1' }, jit_provisioned: false, auth_mode: 'local', banned: false, pool_ready: true },
    });
    const result = await resolveIdentity({ source: 'jwt-bearer', userId: 'u1' });
    assert.equal(result.user.id, 'u1');
    assert.equal(result.pool_ready, true);
  });

  it('throws EdgeAuthFailed on 401', async () => {
    globalThis.fetch = async () => jsonResp(401, { error: { code: 'S2S_MISSING_HEADER' } });
    await assert.rejects(
      () => resolveIdentity({ source: 'jwt-bearer', userId: 'u1' }),
      (err) => err instanceof EdgeAuthFailed && err.code === 'EDGE_AUTH_FAILED'
    );
  });

  it('throws EdgeAuthFailed on 500 + S2S_NOT_CONFIGURED body', async () => {
    globalThis.fetch = async () => textResp(500, JSON.stringify({ error: { code: 'S2S_NOT_CONFIGURED' } }));
    await assert.rejects(
      () => resolveIdentity({ source: 'jwt-bearer', userId: 'u1' }),
      (err) => err instanceof EdgeAuthFailed
    );
  });

  it('throws EdgeUnreachable on generic 500', async () => {
    globalThis.fetch = async () => textResp(500, 'broken');
    await assert.rejects(
      () => resolveIdentity({ source: 'jwt-bearer', userId: 'u1' }),
      (err) => err instanceof EdgeUnreachable
    );
  });

  it('throws EdgeTimeout on AbortError', async () => {
    globalThis.fetch = async () => {
      const err = new Error('aborted');
      err.name = 'AbortError';
      throw err;
    };
    await assert.rejects(
      () => resolveIdentity({ source: 'jwt-bearer', userId: 'u1' }),
      (err) => err instanceof EdgeTimeout
    );
  });

  it('throws EdgeUnreachable on network error', async () => {
    globalThis.fetch = async () => { throw new Error('ECONNREFUSED'); };
    await assert.rejects(
      () => resolveIdentity({ source: 'jwt-bearer', userId: 'u1' }),
      (err) => err instanceof EdgeUnreachable
    );
  });

  it('throws EdgeBadResponse on non-JSON 200', async () => {
    globalThis.fetch = async () => textResp(200, 'not json');
    await assert.rejects(
      () => resolveIdentity({ source: 'jwt-bearer', userId: 'u1' }),
      (err) => err instanceof EdgeBadResponse
    );
  });
});

describe('edge-state-client — fetchAuthMode', () => {
  it('returns data on 200', async () => {
    globalThis.fetch = async () => jsonResp(200, {
      ok: true,
      data: { auth_mode: 'keycloak', source: 'system_settings', pool_ready: true },
    });
    const out = await fetchAuthMode(null);
    assert.equal(out.auth_mode, 'keycloak');
    assert.equal(out.source, 'system_settings');
  });

  it('uses GET method', async () => {
    let captured;
    globalThis.fetch = async (url, opts) => {
      captured = { url, method: opts.method };
      return jsonResp(200, { ok: true, data: { auth_mode: 'local' } });
    };
    await fetchAuthMode(null);
    assert.equal(captured.method, 'GET');
    assert.match(captured.url, /\/edge\/internal\/system\/auth-mode$/);
  });
});

describe('edge-state-client — fetchEdgeHealth', () => {
  it('returns reachable=true with pool block on 200', async () => {
    globalThis.fetch = async () => jsonResp(200, {
      api: 'ok',
      role: 'edge',
      db: 'ok',
      pool: { pool_state: 'configured', hint_code: null },
    });
    const out = await fetchEdgeHealth();
    assert.equal(out.reachable, true);
    assert.equal(out.db, 'ok');
    assert.equal(out.pool.pool_state, 'configured');
  });

  it('returns reachable=false on network error', async () => {
    globalThis.fetch = async () => { throw new Error('ECONNREFUSED'); };
    const out = await fetchEdgeHealth();
    assert.equal(out.reachable, false);
    assert.equal(out.db, 'unknown');
    assert.equal(out.pool, null);
  });

  it('returns reachable=false on 500', async () => {
    globalThis.fetch = async () => jsonResp(500, { error: 'broken' });
    const out = await fetchEdgeHealth();
    assert.equal(out.reachable, false);
  });
});
