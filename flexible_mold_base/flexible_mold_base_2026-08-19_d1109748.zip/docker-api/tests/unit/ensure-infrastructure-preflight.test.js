/**
 * ensure-infrastructure-preflight.test.js — v3.2.53 PR-4 (Q6)
 *
 * Integration pin: `ensureInfrastructure({context})` runs preflight-grants
 * before DDL and:
 *   - boot context: writes ERROR/CAUSE/FIX banner to stderr + rethrows
 *   - reconfigure context: stays silent + rethrows (caller renders 400)
 *
 * Stubs `mariadb` so the test doesn't need a live database. The stubbed
 * conn returns controllable SHOW GRANTS results so we can exercise both
 * the privilege-rejection and grants-probe-failure branches.
 *
 * Sequential-only (require.cache hijack of `mariadb` would race other
 * suites that need the real driver). node:test default is sequential.
 */
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

// ── Stub mariadb BEFORE requiring db.js ──────────────────────────────────
const mariadbKey = require.resolve('mariadb');

let grantRows = [];
let grantsThrows = null;
let existingRows = [];
let auditInsertCount = 0;

const stubConn = {
  async query(sql /*, params */) {
    if (/SHOW GRANTS/i.test(sql)) {
      if (grantsThrows) throw grantsThrows;
      return grantRows;
    }
    if (/information_schema\.TABLES/i.test(sql)) {
      return existingRows;
    }
    if (/SELECT @@session\.sql_mode|SELECT 1/i.test(sql)) {
      return [{ 'SELECT 1': 1 }];
    }
    if (/INSERT INTO `fmb_feature_audit`/i.test(sql)) {
      auditInsertCount += 1;
      return { affectedRows: 1 };
    }
    // DDL queries (CREATE / ALTER) — succeed silently. We never reach
    // them in tests that throw on preflight.
    return [];
  },
  release: () => {},
};

const stubPool = {
  async getConnection() { return stubConn; },
  async end() {},
  async query(sql) { return stubConn.query(sql); },
};

const mariadbStub = {
  createPool() { return stubPool; },
};
require.cache[mariadbKey] = { id: mariadbKey, filename: mariadbKey, loaded: true, exports: mariadbStub };

// Isolate the config-file path so tests never touch the real one
const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'preflight-'));
process.env.DB_CONFIG_PATH = path.join(tmpDir, 'db-config.json');

const { configurePool, ensureInfrastructure, PreflightError } = require('../../src/edge/db');

// ── Helper: reconfigure the stub then bring the pool up ──────────────────
async function bringUpPool() {
  // Reset state between tests — grant the pool up, then flip SHOW GRANTS
  // to simulate a post-swap privilege revocation for the reconfigure
  // context tests.
  grantRows = [{ 'Grants for u@%': "GRANT ALL PRIVILEGES ON `fmb`.* TO 'u'@'%'" }];
  grantsThrows = null;
  existingRows = [];
  await configurePool({
    host: 'stub', port: 3306, user: 'u', password: 'p', database: 'fmb', tablePrefix: 'fmb_',
  });
}

// ── Capture stderr from ensureInfrastructure ─────────────────────────────
function captureStderr(fn) {
  const chunks = [];
  const orig = process.stderr.write.bind(process.stderr);
  process.stderr.write = (s) => { chunks.push(s); return true; };
  return Promise.resolve(fn()).finally(() => { process.stderr.write = orig; }).then(
    () => chunks.join(''),
    (err) => { const out = chunks.join(''); err.__capturedStderr = out; throw err; },
  );
}

before(async () => { await bringUpPool(); });
after(async () => { fs.rmSync(tmpDir, { recursive: true, force: true }); });

// ── Happy path (sanity) ──────────────────────────────────────────────────

test('ensureInfrastructure boot: full privileges → no banner, no throw', async () => {
  grantRows = [{ 'Grants for u@%': "GRANT ALL PRIVILEGES ON `fmb`.* TO 'u'@'%'" }];
  let threw = null;
  let captured = '';
  try {
    captured = await captureStderr(() => ensureInfrastructure({ context: 'boot' }));
  } catch (err) { threw = err; }
  assert.equal(threw, null, 'should not throw when privileges OK');
  // No preflight banner emitted
  assert.doesNotMatch(captured, /ERROR: Missing privileges/);
});

// ── Boot context: stderr banner + rethrow ────────────────────────────────

test('ensureInfrastructure boot: missing CRUD → stderr ERROR/CAUSE/FIX + PreflightError rethrow', async () => {
  grantRows = [{ 'Grants for u@%': "GRANT SELECT ON `fmb`.* TO 'u'@'%'" }];
  let threw = null;
  let captured = '';
  try {
    captured = await captureStderr(() => ensureInfrastructure({ context: 'boot' }));
  } catch (err) {
    threw = err;
    captured = err.__capturedStderr || '';
  }
  assert.ok(threw, 'should have thrown PreflightError');
  assert.ok(threw instanceof PreflightError);
  assert.equal(threw.code, 'PREFLIGHT_MISSING_PRIVILEGES');
  // Banner shape
  assert.match(captured, /^ERROR: Missing privileges on schema 'fmb'/m);
  assert.match(captured, /^CAUSE: fmb_\* infrastructure tables cannot be read or written/m);
  assert.match(captured, /^FIX:/m);
  assert.match(captured, /GRANT INSERT, UPDATE, DELETE ON `fmb`\.\*/);
});

test('ensureInfrastructure boot: CRUD-only account logs INFO and continues without audit', async () => {
  grantRows = [{ 'Grants for u@%': "GRANT SELECT, INSERT, UPDATE, DELETE ON `fmb`.* TO 'u'@'%'" }];
  auditInsertCount = 0;
  existingRows = [
    { TABLE_NAME: 'fmb_users' },
    { TABLE_NAME: 'fmb_login_audit' },
    { TABLE_NAME: 'fmb_system_settings' },
    { TABLE_NAME: 'fmb_db_connections' },
    { TABLE_NAME: 'fmb_access_rules' },
    { TABLE_NAME: 'fmb_feature_audit' },
    { TABLE_NAME: 'fmb_hierarchy_nodes' },
    { TABLE_NAME: 'fmb_blueprint_fields' },
    { TABLE_NAME: 'fmb_field_options' },
    { TABLE_NAME: 'fmb_blueprint_sections' },
    { TABLE_NAME: 'fmb_blueprint_output_order' },
    { TABLE_NAME: 'fmb_variant_overrides' },
    { TABLE_NAME: 'fmb_user_templates' },
    { TABLE_NAME: 'fmb_transformers' },
    { TABLE_NAME: 'fmb_transformer_versions' },
  ];
  let threw = null;
  let captured = '';
  try {
    captured = await captureStderr(() => ensureInfrastructure({ context: 'boot' }));
  } catch (err) {
    threw = err;
    captured = err.__capturedStderr || '';
  } finally {
    existingRows = [];
  }
  assert.equal(threw, null, 'boot should continue when only DDL privileges are missing');
  assert.doesNotMatch(captured, /^ERROR:/m);
  assert.equal(auditInsertCount, 0, 'read-only DDL preflight failure must not write feature_audit');
});

test('ensureInfrastructure boot: SHOW GRANTS rejected → banner + rethrow', async () => {
  grantsThrows = new Error('Access denied for user u@host');
  let threw = null;
  let captured = '';
  try {
    captured = await captureStderr(() => ensureInfrastructure({ context: 'boot' }));
  } catch (err) {
    threw = err;
    captured = err.__capturedStderr || '';
  }
  assert.ok(threw instanceof PreflightError);
  assert.equal(threw.code, 'PREFLIGHT_GRANTS_UNAVAILABLE');
  assert.match(captured, /^ERROR: Unable to read SHOW GRANTS/m);
  grantsThrows = null;
});

// ── Reconfigure context: silent rethrow ──────────────────────────────────

test('ensureInfrastructure reconfigure: missing CREATE → NO banner, still rethrows', async () => {
  grantRows = [{ 'Grants for u@%': "GRANT SELECT ON `fmb`.* TO 'u'@'%'" }];
  let threw = null;
  let captured = '';
  try {
    captured = await captureStderr(() => ensureInfrastructure({ context: 'reconfigure' }));
  } catch (err) {
    threw = err;
    captured = err.__capturedStderr || '';
  }
  assert.ok(threw instanceof PreflightError, 'should still throw for caller to handle');
  // Reconfigure context stays silent — caller is responsible for HTTP 400.
  assert.doesNotMatch(captured, /^ERROR:/m);
  assert.doesNotMatch(captured, /^CAUSE:/m);
});
