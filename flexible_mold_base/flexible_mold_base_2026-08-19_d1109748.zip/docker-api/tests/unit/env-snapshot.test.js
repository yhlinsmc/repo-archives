/**
 * env-snapshot.test.js — v3.2.51a coverage for the boot-time env
 * observability helper. The helper must:
 *   - Parse FMB_ENV_SOURCES into a list of `<type>/<name>` tokens,
 *     rejecting malformed entries silently.
 *   - Emit keys (sorted) without values in the default `boot` phase.
 *   - Emit values (truncated + redacted) in `fail` phase so a
 *     validateConfig failure leaves a diagnostic breadcrumb.
 *   - Never emit the value of a key matching SENSITIVE_KEY_RE, in
 *     either phase.
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const {
  printEnvSnapshot,
  parseSources,
  parseSourcesDiag,
  SENSITIVE_KEY_RE,
} = require('../../src/shared/lib/env-snapshot');

function makeCollectingLogger() {
  const records = [];
  const warnings = [];
  return {
    records,
    warnings,
    info: (msg) => records.push(msg),
    warn: (msg) => warnings.push(msg),
    error: () => {},
    fatal: () => {},
    child: () => makeCollectingLogger(),
  };
}

describe('parseSources — FMB_ENV_SOURCES parsing', () => {
  it('returns [] for undefined', () => {
    assert.deepEqual(parseSources(undefined), []);
  });

  it('returns [] for empty string', () => {
    assert.deepEqual(parseSources(''), []);
  });

  it('parses a single cm token', () => {
    assert.deepEqual(parseSources('cm/fmb-config-shared'), [
      'cm/fmb-config-shared',
    ]);
  });

  it('parses comma-separated tokens and trims whitespace', () => {
    assert.deepEqual(
      parseSources('cm/fmb-config-shared, cm/fmb-config-edge , secret/fmb-secrets'),
      ['cm/fmb-config-shared', 'cm/fmb-config-edge', 'secret/fmb-secrets'],
    );
  });

  it('drops malformed entries but keeps good ones', () => {
    assert.deepEqual(
      parseSources('cm/fmb-config-shared,not-a-token,configmap/bad-type,cm/ok2'),
      ['cm/fmb-config-shared', 'cm/ok2'],
    );
  });

  it('rejects type outside {cm, secret}', () => {
    assert.deepEqual(parseSources('volume/some-mount'), []);
  });
});

describe('parseSourcesDiag — v3.2.54 PR-2 diagnostic surface for rejected tokens', () => {
  it('returns empty arrays for undefined', () => {
    assert.deepEqual(parseSourcesDiag(undefined), { accepted: [], rejected: [] });
  });

  it('returns empty arrays for empty string', () => {
    assert.deepEqual(parseSourcesDiag(''), { accepted: [], rejected: [] });
  });

  it('splits accepted vs rejected tokens', () => {
    const { accepted, rejected } = parseSourcesDiag(
      'cm/fmb-config-shared,not-a-token,configmap/bad-type,cm/ok2',
    );
    assert.deepEqual(accepted, ['cm/fmb-config-shared', 'cm/ok2']);
    assert.deepEqual(rejected, ['not-a-token', 'configmap/bad-type']);
  });

  it('skips purely whitespace entries', () => {
    const { accepted, rejected } = parseSourcesDiag(
      ' , cm/fmb-config-shared ,  ',
    );
    assert.deepEqual(accepted, ['cm/fmb-config-shared']);
    assert.deepEqual(rejected, []);
  });
});

describe('SENSITIVE_KEY_RE — redaction surface', () => {
  it('matches canonical password + secret + token names', () => {
    for (const k of [
      'DB_RW_PASSWORD',
      'DB_RO_PASSWORD',
      'DB_RW_PASSWORD_ENCRYPTED',
      'JWT_SECRET',
      'S2S_API_KEY',
      'SETTINGS_ENCRYPTION_KEY',
      'OIDC_COOKIE_SECRET',
      'AUTH_PASSWORD',
      'AUTH_SECRET',
      'AUTH_TOKEN',
      'DB_CREDENTIAL',
      'KEYCLOAK_CREDENTIALS',
    ]) {
      assert.ok(SENSITIVE_KEY_RE.test(k), `expected ${k} to be sensitive`);
    }
  });

  it('does NOT match innocuous names (v3.2.51a PR1-review MED: AUTH over-match fix)', () => {
    for (const k of [
      'NODE_ENV',
      'API_BASE_ALLOWLIST',
      'PORT',
      'HOSTNAME',
      // Previously over-matched by bare `AUTH` token:
      'AUTH_MODE',
      'AUTH_MODE_OVERRIDE',
      'KEYCLOAK_AUTH_TYPE',
      'KEYCLOAK_ISSUER_BASE_URL',
    ]) {
      assert.ok(!SENSITIVE_KEY_RE.test(k), `expected ${k} to NOT be sensitive`);
    }
  });
});

describe('printEnvSnapshot — v3.2.54 PR-2 malformed-token warn', () => {
  it('emits logger.warn with rejected token list when FMB_ENV_SOURCES has bad entries', () => {
    const logger = makeCollectingLogger();
    printEnvSnapshot(logger, {
      phase: 'boot',
      env: {
        FMB_ENV_SOURCES: 'cm/fmb-config-shared,garbage,configmap/bad-type,cm/ok2',
        NODE_ENV: 'production',
      },
    });
    assert.equal(logger.warnings.length, 1);
    const w = logger.warnings[0];
    assert.match(w, /\[boot-env\] FMB_ENV_SOURCES: 2 token\(s\) rejected/);
    assert.match(w, /garbage/);
    assert.match(w, /configmap\/bad-type/);
  });

  it('does not emit logger.warn when all tokens valid', () => {
    const logger = makeCollectingLogger();
    printEnvSnapshot(logger, {
      phase: 'boot',
      env: {
        FMB_ENV_SOURCES: 'cm/fmb-config-shared,cm/fmb-config-edge',
        NODE_ENV: 'production',
      },
    });
    assert.equal(logger.warnings.length, 0);
  });

  it('does not emit logger.warn when FMB_ENV_SOURCES is unset', () => {
    const logger = makeCollectingLogger();
    printEnvSnapshot(logger, { phase: 'boot', env: { NODE_ENV: 'production' } });
    assert.equal(logger.warnings.length, 0);
  });
});

describe('printEnvSnapshot — boot phase', () => {
  it('emits sources line when FMB_ENV_SOURCES is set', () => {
    const logger = makeCollectingLogger();
    printEnvSnapshot(logger, {
      phase: 'boot',
      env: {
        FMB_ENV_SOURCES: 'cm/fmb-config-shared,cm/fmb-config-edge',
        NODE_ENV: 'production',
      },
    });
    const joined = logger.records.join('\n');
    assert.match(joined, /\[boot-env\] sources: cm\/fmb-config-shared,cm\/fmb-config-edge/);
  });

  it('emits fallback sources line when FMB_ENV_SOURCES is unset', () => {
    const logger = makeCollectingLogger();
    printEnvSnapshot(logger, { phase: 'boot', env: { NODE_ENV: 'production' } });
    const joined = logger.records.join('\n');
    assert.match(joined, /\[boot-env\] sources: \(FMB_ENV_SOURCES unset/);
  });

  it('emits keys line in sorted order, no values', () => {
    const logger = makeCollectingLogger();
    printEnvSnapshot(logger, {
      phase: 'boot',
      env: {
        NODE_ENV: 'production',
        API_BASE_ALLOWLIST: 'zonea=https://x',
        PORT: '3000',
      },
    });
    const keysLine = logger.records.find((r) => r.startsWith('[boot-env] keys:'));
    assert.ok(keysLine);
    assert.match(keysLine, /API_BASE_ALLOWLIST/);
    assert.match(keysLine, /NODE_ENV/);
    assert.match(keysLine, /PORT/);
    // sorted order
    const idxA = keysLine.indexOf('API_BASE_ALLOWLIST');
    const idxN = keysLine.indexOf('NODE_ENV');
    const idxP = keysLine.indexOf('PORT');
    assert.ok(idxA < idxN && idxN < idxP, 'keys must be sorted');
  });

  it('does NOT emit any values in boot phase', () => {
    const logger = makeCollectingLogger();
    printEnvSnapshot(logger, {
      phase: 'boot',
      env: {
        JWT_SECRET: 'should-never-leak',
        API_BASE_ALLOWLIST: 'zonea=https://x',
      },
    });
    const joined = logger.records.join('\n');
    assert.ok(!joined.includes('should-never-leak'));
    assert.ok(!joined.includes('https://x'));
    assert.ok(!/\[boot-env\] values/.test(joined));
  });
});

describe('printEnvSnapshot — fail phase', () => {
  it('emits values line with sensitive keys fully masked', () => {
    const logger = makeCollectingLogger();
    printEnvSnapshot(logger, {
      phase: 'fail',
      env: {
        JWT_SECRET: 'super-secret-dont-leak',
        DB_RW_PASSWORD_ENCRYPTED: 'encrypted-blob',
        NODE_ENV: 'production',
        API_BASE_ALLOWLIST: 'zonea=https://x.example',
      },
    });
    const values = logger.records.find((r) => r.startsWith('[boot-env] values'));
    assert.ok(values);
    assert.match(values, /JWT_SECRET="\*\*\*"/);
    assert.match(values, /DB_RW_PASSWORD_ENCRYPTED="\*\*\*"/);
    assert.match(values, /NODE_ENV="production"/);
    assert.match(values, /API_BASE_ALLOWLIST="zonea=https:\/\/x\.example"/);
    assert.ok(!values.includes('super-secret-dont-leak'));
    assert.ok(!values.includes('encrypted-blob'));
  });

  it('truncates long values to keep log lines bounded', () => {
    const logger = makeCollectingLogger();
    const longVal = 'a'.repeat(200);
    printEnvSnapshot(logger, {
      phase: 'fail',
      env: { SOME_BIG_ENV: longVal },
    });
    const values = logger.records.find((r) => r.startsWith('[boot-env] values'));
    assert.ok(values);
    assert.match(values, /SOME_BIG_ENV="a{77}\.\.\."/);
  });
});

describe('printEnvSnapshot — invalid input fallback', () => {
  it('treats unknown phase as boot (no values emitted)', () => {
    const logger = makeCollectingLogger();
    printEnvSnapshot(logger, {
      phase: 'garbage',
      env: { JWT_SECRET: 'leak-check' },
    });
    const joined = logger.records.join('\n');
    assert.ok(!joined.includes('leak-check'));
    assert.ok(!/\[boot-env\] values/.test(joined));
  });

  it('survives empty env object', () => {
    const logger = makeCollectingLogger();
    assert.doesNotThrow(() => printEnvSnapshot(logger, { env: {} }));
    const joined = logger.records.join('\n');
    assert.match(joined, /\[boot-env\] keys:/);
  });

  it('survives no opts argument', () => {
    const logger = makeCollectingLogger();
    assert.doesNotThrow(() => printEnvSnapshot(logger));
    // We read real process.env — just assert keys line exists.
    assert.ok(logger.records.some((r) => r.startsWith('[boot-env] keys:')));
  });
});
