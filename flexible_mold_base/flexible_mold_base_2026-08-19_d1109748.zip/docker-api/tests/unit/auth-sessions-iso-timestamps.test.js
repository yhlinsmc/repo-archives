/**
 * auth-sessions-iso-timestamps.test.js
 *
 * The sessions endpoint must hand back UTC timestamps in ISO-8601 with an
 * explicit Z, not the bare MariaDB "YYYY-MM-DD HH:mm:ss" shape. Without the Z
 * the browser parses the string in local time and the "last login" drifts by
 * the viewer's UTC offset. Both the deduped success rows (lastLogin) and the
 * opt-in failure rows (loginAt) run through normalizeTimestamp.
 *
 * Run: node --test docker-api/tests/unit/auth-sessions-iso-timestamps.test.js
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../src/edge/db');
const routeKey = require.resolve('../../src/edge/routes/platform/auth-sessions');

let calls;

function makeSpy() {
  calls = { ro: 0, roQueries: [] };
  return {
    rw: {
      async getConnection() {
        throw new Error('auth-sessions must use pool.ro');
      },
    },
    ro: {
      async getConnection() {
        calls.ro++;
        return {
          async query(sql) {
            calls.roQueries.push({ sql });
            const norm = sql.replace(/\s+/g, ' ');
            if (/COUNT\(DISTINCT/.test(norm)) return [{ total: 1 }];
            if (/today_count/.test(norm)) return [{ today_count: 2 }];
            if (/success = FALSE/.test(norm)) {
              // MariaDB dateStrings: true returns a bare space-separated UTC string.
              return [{
                username: 'bob', deptid: 'qa', auth_provider: 'LOCAL',
                reason: 'invalid_password', login_at: '2026-06-13 01:02:03',
              }];
            }
            return [{
              username: 'alice', deptid: 'eng', auth_provider: 'KEYCLOAK',
              last_login: '2026-06-13 01:02:03', login_count: 3,
            }];
          },
          release() { /* noop */ },
        };
      },
    },
  };
}

const poolSpy = {};

require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: poolSpy, t: (name) => `fmb_${name}` },
};

require('../../src/edge/routes/platform/auth-sessions');

let server;
let port;

before(async () => {
  Object.assign(poolSpy, makeSpy());
  const router = require('../../src/edge/routes/platform/auth-sessions');
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { req.user = { id: 't', role: 'admin' }; next(); });
  app.use('/edge/platform/auth', router);
  await new Promise((resolve) => {
    server = app.listen(0, '127.0.0.1', () => { port = server.address().port; resolve(); });
  });
});

after(async () => {
  await new Promise((resolve) => server.close(resolve));
  delete require.cache[dbKey];
  delete require.cache[routeKey];
});

beforeEach(() => { Object.assign(poolSpy, makeSpy()); });

function getJson(path_) {
  return new Promise((resolve, reject) => {
    const req = http.request(
      { host: '127.0.0.1', port, path: path_, method: 'GET' },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          const raw = Buffer.concat(chunks).toString('utf-8');
          let json = null;
          try { json = JSON.parse(raw); } catch { /* noop */ }
          resolve({ status: res.statusCode, raw, json });
        });
      },
    );
    req.on('error', reject);
    req.end();
  });
}

describe('GET /sessions — UTC ISO-8601 timestamps', () => {
  it('lastLogin is normalized to ISO-8601 with a Z suffix', async () => {
    const res = await getJson('/edge/platform/auth/sessions');
    assert.equal(res.status, 200, res.raw);
    assert.equal(res.json.data.items[0].lastLogin, '2026-06-13T01:02:03Z');
  });

  it('failure loginAt is normalized to ISO-8601 with a Z suffix', async () => {
    const res = await getJson('/edge/platform/auth/sessions?include_failures=1');
    assert.equal(res.status, 200, res.raw);
    assert.equal(res.json.data.failures[0].loginAt, '2026-06-13T01:02:03Z');
  });
});
