// Shared FE/BE parity case set — the single source of truth is the JSON
// fixture under src/fmb/lib/connectors/__fixtures__/ (the FE vitest consumes
// the same file). Edit cases there only; a one-sided behavior change fails
// the other side. The adapter below maps the shape-neutral connector onto the
// raw-row shape this server-side port reads (request_config.input_cells),
// where the FE adapter maps it onto the /usable input_spec shape.
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const { computeConnectorHealth, collectTargetKeys } = require('../../src/edge/lib/connector-health');
const fixture = require('../../../src/fmb/lib/connectors/__fixtures__/connector-health-cases.json');

const known = new Set(fixture.knownKeys);

const toConnector = (c) => ({
  request_config: c.input_cells ? { input_cells: c.input_cells } : {},
  response_config: c.response_config,
});

describe('computeConnectorHealth (shared fixture)', () => {
  // Guards the loop below against a fixture emptied by a bad merge — zero
  // registered cases would otherwise pass vacuously.
  it('fixture case set is non-empty', () => {
    assert.ok(fixture.cases.length > 0);
  });
  for (const tc of fixture.cases) {
    it(tc.name, () => {
      const h = computeConnectorHealth(toConnector(tc.connector), known);
      assert.equal(h.status, tc.expected.status);
      if (tc.expected.resolvedKeys) assert.deepEqual(h.resolvedKeys, tc.expected.resolvedKeys);
      if (tc.expected.missingKeys) assert.deepEqual(h.missingKeys, tc.expected.missingKeys);
    });
  }
});

// A connector row stored before the outputs[] unification carries legacy
// {mappings,lookups}; collectTargetKeys must convert it (not read empty) so the
// admin health column doesn't false-flag it as broken-no-op.
describe('connector-health legacy-config conversion', () => {
  it('collectTargetKeys reads keys from a legacy {mappings,lookups} config', () => {
    const c = {
      request_config: {},
      response_config: {
        mappings: [{ path: 'a', field_key: 'full_part_code' }],
        lookups: [{
          list_path: 'items', filter_column: 'name',
          filter_value: { kind: 'literal', value: 'X' },
          extract_column: 'value', target: { kind: 'field', field_key: 'notes' },
        }],
      },
    };
    const keys = collectTargetKeys(c);
    assert.deepEqual([...new Set(keys)].sort(), ['full_part_code', 'notes']);
  });

  it('a legacy-only connector resolves to healthy, not broken-no-op', () => {
    const c = {
      request_config: {},
      response_config: { mappings: [{ path: 'a', field_key: 'notes' }] },
    };
    const h = computeConnectorHealth(c, new Set(fixture.knownKeys));
    assert.equal(h.status, 'healthy');
    assert.deepEqual(h.resolvedKeys, ['notes']);
  });
});
