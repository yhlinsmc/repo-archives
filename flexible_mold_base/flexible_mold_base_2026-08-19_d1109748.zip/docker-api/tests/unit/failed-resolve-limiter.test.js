/**
 * failed-resolve-limiter.test.js — /api/public/v1 brute-force IP limiter
 * against the REAL express-rate-limit middleware (spec §4.6). Auth v2 has no
 * token endpoint; the pre-auth guard now caps repeated FAILED resolves (4xx)
 * per source IP, while never throttling successful (200) reads
 * (skipSuccessfulRequests). The 429 speaks the public error model.
 *
 * Distinct source IPs are simulated via X-Forwarded-For + `trust proxy` = 1.
 */
const { describe, it, before, after } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

// Force real limiters regardless of ambient DISABLE_RATE_LIMIT.
delete process.env.DISABLE_RATE_LIMIT;
const limiters = require('../../src/infra/limiters');

// Build a fresh app with the given budget env. readLimit reads process.env at
// mount time, so per-scenario budgets are applied by setting env before mount.
// The terminal returns 401 (simulated invalid token) unless the caller sends
// `X-Sim: ok`, which returns 200 (simulated successful read).
function buildServer(env) {
  for (const [k, v] of Object.entries(env)) process.env[k] = String(v);
  const app = express();
  app.set('trust proxy', 1);
  limiters.mountPreAuthLimiters(app);
  app.use('/api/public/v1', (req, res) => {
    if (req.headers['x-sim'] === 'ok') return res.status(200).json({ ok: true });
    return res.status(401).json({ error: 'invalid_token' });
  });
  const server = app.listen(0, '127.0.0.1');
  return new Promise((resolve) => server.on('listening', () => resolve(server)));
}

function get(port, { xff, sim } = {}) {
  return new Promise((resolve, reject) => {
    const headers = { 'X-Forwarded-For': xff, Connection: 'close' };
    if (sim) headers['X-Sim'] = sim;
    const req = http.request(
      { host: '127.0.0.1', port, path: '/api/public/v1/blueprints', method: 'GET', agent: false, headers },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          let json = null;
          try { json = JSON.parse(Buffer.concat(chunks).toString('utf-8')); } catch { /* noop */ }
          resolve({ status: res.statusCode, json, headers: res.headers });
        });
      },
    );
    req.on('error', reject);
    req.end();
  });
}

const ENV_KEYS = ['RATE_LIMIT_PUBLIC_RESOLVE_FAIL_MAX', 'RATE_LIMIT_PUBLIC_RESOLVE_FAIL_WINDOW_MS'];
const savedEnv = {};
before(() => { for (const k of ENV_KEYS) savedEnv[k] = process.env[k]; });
after(() => {
  for (const k of ENV_KEYS) {
    if (savedEnv[k] === undefined) delete process.env[k];
    else process.env[k] = savedEnv[k];
  }
});

describe('failed-resolve IP limiter (real express-rate-limit)', () => {
  it('throttles repeated invalid tokens from one source IP with the public 429 model', async () => {
    const server = await buildServer({
      RATE_LIMIT_PUBLIC_RESOLVE_FAIL_MAX: '2',
      RATE_LIMIT_PUBLIC_RESOLVE_FAIL_WINDOW_MS: '900000',
    });
    const { port } = server.address();
    try {
      const one = await get(port, { xff: '9.9.9.9' });
      const two = await get(port, { xff: '9.9.9.9' });
      const three = await get(port, { xff: '9.9.9.9' });
      assert.equal(one.status, 401);
      assert.equal(two.status, 401);
      assert.equal(three.status, 429, 'repeated invalid tokens must be throttled per IP');
      // Public error model only — no internal apiError envelope / meta leak.
      assert.deepEqual(three.json, { error: 'rate_limited' });
      assert.equal('meta' in (three.json || {}), false);
      assert.equal('code' in (three.json || {}), false);
      assert.ok(three.headers['retry-after'] !== undefined, 'Retry-After must be present on 429');
      assert.ok(three.headers['ratelimit-limit'] !== undefined, 'RateLimit-* headers must be present');
    } finally {
      await new Promise((r) => server.close(r));
    }
  });

  it('does NOT throttle successful reads — only 4xx burns budget (skipSuccessfulRequests)', async () => {
    const server = await buildServer({
      RATE_LIMIT_PUBLIC_RESOLVE_FAIL_MAX: '2',
      RATE_LIMIT_PUBLIC_RESOLVE_FAIL_WINDOW_MS: '900000',
    });
    const { port } = server.address();
    try {
      // Five successful reads from one IP: none should count toward the budget.
      for (let i = 0; i < 5; i++) {
        const ok = await get(port, { xff: '7.7.7.7', sim: 'ok' });
        assert.equal(ok.status, 200, `successful read #${i + 1} must not be throttled`);
      }
      // The failure budget is still intact: two 401s allowed, the third trips.
      assert.equal((await get(port, { xff: '7.7.7.7' })).status, 401);
      assert.equal((await get(port, { xff: '7.7.7.7' })).status, 401);
      assert.equal((await get(port, { xff: '7.7.7.7' })).status, 429,
        'successful reads must not have consumed the failed-resolve budget');
    } finally {
      await new Promise((r) => server.close(r));
    }
  });

  it('budgets are per source IP — a second IP is unaffected by the first IP failures', async () => {
    const server = await buildServer({
      RATE_LIMIT_PUBLIC_RESOLVE_FAIL_MAX: '1',
      RATE_LIMIT_PUBLIC_RESOLVE_FAIL_WINDOW_MS: '900000',
    });
    const { port } = server.address();
    try {
      assert.equal((await get(port, { xff: '1.1.1.1' })).status, 401);
      assert.equal((await get(port, { xff: '1.1.1.1' })).status, 429, 'first IP is throttled after its budget');
      // A different IP still has its full budget.
      assert.equal((await get(port, { xff: '2.2.2.2' })).status, 401);
    } finally {
      await new Promise((r) => server.close(r));
    }
  });
});
