/**
 * api-connectors-crud-mask.test.js
 *
 * Pins the two leak paths the review flagged: the CRUD factory's POST/PUT
 * write-response must NOT return the stored ciphertext, and the write path
 * must encrypt the secret before INSERT. Boots the real api-connectors router
 * (which mounts createCrudRoutes with the connector serializer hooks) against a
 * mocked pool. Also asserts the admin-only read gate.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

process.env.SETTINGS_ENCRYPTION_KEY = 'crud-mask-test-key';

const dbKey = require.resolve('../../src/edge/db');
const { encrypt } = require('../../src/shared/lib/settings-crypto');

// Precompute the stored ciphertext ONCE while the key is set, so the mock can
// fabricate a "secret already encrypted in the DB" row without re-encrypting at
// response time — otherwise a test that unsets the key would make the mock
// itself throw before the production write path is even reached.
const STORED_TOKEN_CT = encrypt('stored-secret');

let captured;
function makeConn() {
  return {
    async beginTransaction() {},
    async commit() {},
    async rollback() {},
    async query(sql, params) {
      if (/SELECT DATABASE\(\)/.test(sql)) return [{ db: 'testdb' }];
      if (/information_schema\.COLUMNS/i.test(sql)) return []; // colSet null → keep all keys
      if (/FROM `fmb_users`/.test(sql)) return []; // owner-name enrichment → none
      if (/^INSERT INTO `fmb_api_connectors`/.test(sql.trim())) {
        captured.insert = { sql, params };
        return { affectedRows: 1 };
      }
      if (/^UPDATE `fmb_api_connectors`/.test(sql.trim())) {
        captured.update = { sql, params };
        return { affectedRows: 1 };
      }
      // The mask-preserve read. It runs on THIS connection now, inside the write
      // transaction and FOR UPDATE — matched on the table and the columns it
      // needs rather than on the statement's exact text, because an arm pinned
      // to the full string stops matching the moment a column is added to the
      // query and the double then answers "no such row" by falling through,
      // which reads to the serializer as "there is no stored secret".
      if (/SELECT .*auth_config.*FROM `fmb_api_connectors` WHERE id = \? FOR UPDATE/.test(sql)) {
        return [{
          auth_config: JSON.stringify({ token: STORED_TOKEN_CT }),
          auth_type: 'bearer',
          request_config: null,
        }];
      }
      if (/SELECT \* FROM `fmb_api_connectors` WHERE id = \?/.test(sql)) {
        // Simulate the stored row: secret already encrypted in the DB.
        return [{
          id: params[0], name: 'c', is_active: 1,
          auth_type: 'bearer',
          auth_config: JSON.stringify({ token: STORED_TOKEN_CT }),
          request_config: null, response_config: null,
          owner_id: '5b729f1e-5c0b-447c-8144-3210469bc62c', blueprint_id: null,
          method: 'GET', url: 'http://svc/x', dispatch_origin: 'infra',
          created_at: '2026-01-01 00:00:00', updated_at: '2026-01-01 00:00:00',
        }];
      }
      return [];
    },
    release() {},
  };
}
const poolSpy = {
  ro: {
    async getConnection() { return makeConn(); },
    // The mask-preserve read moved onto the WRITE connection (see makeConn). An
    // unconditional answer here would resolve every read this route makes to a
    // connector row, which is how a double stops being able to tell a query it
    // models from one it does not.
    async query() { return []; },
  },
  rw: { async getConnection() { return makeConn(); } },
};
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: poolSpy, t: (name) => `fmb_${name}` },
};

const router = require('../../src/edge/routes/app/api-connectors');

let server; let base; let role;
before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { req.user = { id: '5b729f1e-5c0b-447c-8144-3210469bc62c', role, email: 'a@x' }; next(); });
  app.use('/c', router);
  server = http.createServer(app);
  await new Promise((r) => server.listen(0, r));
  base = `http://127.0.0.1:${server.address().port}`;
});
after(() => server && server.close());
beforeEach(() => { captured = {}; role = 'admin'; });

async function req(method, path, body) {
  const res = await fetch(`${base}${path}`, {
    method, headers: { 'content-type': 'application/json' },
    body: body ? JSON.stringify(body) : undefined,
  });
  return { status: res.status, json: await res.json() };
}

describe('api-connectors CRUD — secret never leaks on write response', () => {
  it('POST encrypts the secret before INSERT and returns it masked', async () => {
    const { status, json } = await req('POST', '/c', {
      name: 'c', url: 'http://svc/x', method: 'GET',
      auth_type: 'bearer', auth_config: { token: 'plain-secret' },
      dispatch_origin: 'infra',
    });
    assert.equal(status, 200);
    // INSERT received ciphertext, not plaintext.
    const authParam = captured.insert.params.find(
      (p) => typeof p === 'string' && p.includes('token'),
    );
    const stored = JSON.parse(authParam);
    assert.ok(stored.token.startsWith('enc:v1:'), 'INSERT must store ciphertext');
    assert.notEqual(stored.token, 'plain-secret');
    // Response is masked.
    assert.equal(json.data.auth_config.token, '****', 'response must mask the secret');
  });

  it('PUT returns the secret masked (never the stored ciphertext)', async () => {
    const { status, json } = await req('PUT', '/c/abc', {
      name: 'c', url: 'http://svc/x', method: 'GET',
      auth_type: 'bearer', auth_config: { token: '****' },
      dispatch_origin: 'infra',
    });
    assert.equal(status, 200);
    assert.equal(json.data.auth_config.token, '****', 'PUT response must mask');
    // AND THE STATEMENT, because the response cannot tell the two outcomes
    // apart: a connector whose token was preserved and one whose token was just
    // dropped both come back masked. The UPDATE has to bind the stored
    // ciphertext.
    const written = captured.update.params.find(
      (p) => typeof p === 'string' && p.includes('token'),
    );
    assert.ok(written, 'the UPDATE bound no auth_config at all');
    assert.equal(
      JSON.parse(written).token, STORED_TOKEN_CT,
      'the masked save did not bind the stored ciphertext',
    );
  });
});

describe('api-connectors CRUD — secret write is fail-closed when SETTINGS_ENCRYPTION_KEY is unset', () => {
  // encrypt() reads process.env live, so toggling the key per-test flips the
  // fail-closed behaviour without re-requiring the cached modules.
  let savedKey;
  beforeEach(() => { savedKey = process.env.SETTINGS_ENCRYPTION_KEY; });
  after(() => { if (savedKey !== undefined) process.env.SETTINGS_ENCRYPTION_KEY = savedKey; });

  it('POST with a secret + no key → 422 ENCRYPTION_KEY_MISSING, no INSERT', async () => {
    delete process.env.SETTINGS_ENCRYPTION_KEY;
    const { status, json } = await req('POST', '/c', {
      name: 'c', url: 'http://svc/x', method: 'GET',
      auth_type: 'bearer', auth_config: { token: 'plain-secret' },
      dispatch_origin: 'infra',
    });
    process.env.SETTINGS_ENCRYPTION_KEY = savedKey;
    assert.equal(status, 422);
    assert.equal(json.error.code, 'ENCRYPTION_KEY_MISSING');
    assert.equal(captured.insert, undefined, 'must not INSERT plaintext secret');
  });

  it('PUT with a fresh secret + no key → 422, no UPDATE', async () => {
    delete process.env.SETTINGS_ENCRYPTION_KEY;
    const { status, json } = await req('PUT', '/c/abc', {
      name: 'c', url: 'http://svc/x', method: 'GET',
      auth_type: 'bearer', auth_config: { token: 'new-plain-secret' },
      dispatch_origin: 'infra',
    });
    process.env.SETTINGS_ENCRYPTION_KEY = savedKey;
    assert.equal(status, 422);
    assert.equal(json.error.code, 'ENCRYPTION_KEY_MISSING');
    assert.equal(captured.update, undefined, 'must not UPDATE plaintext secret');
  });

  it('POST with auth_type none + no key → 200 (no secret to protect)', async () => {
    delete process.env.SETTINGS_ENCRYPTION_KEY;
    const { status } = await req('POST', '/c', {
      name: 'c', url: 'http://svc/x', method: 'GET',
      auth_type: 'none', auth_config: {},
      dispatch_origin: 'infra',
    });
    process.env.SETTINGS_ENCRYPTION_KEY = savedKey;
    assert.equal(status, 200);
  });
});

describe('api-connectors — admin/editor reads, user blocked', () => {
  it('an editor may list connectors (view-all, secrets masked)', async () => {
    role = 'editor';
    const { status } = await req('GET', '/c');
    assert.equal(status, 200);
  });

  it('a plain user is forbidden from listing', async () => {
    role = 'user';
    const { status } = await req('GET', '/c');
    assert.equal(status, 403);
  });
});
