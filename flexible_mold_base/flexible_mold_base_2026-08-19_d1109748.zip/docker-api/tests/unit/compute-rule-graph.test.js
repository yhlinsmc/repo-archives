/**
 * compute-rule-graph.test.js — the precedence arithmetic that the two-level
 * cycle guard rests on, with no DB and no HTTP.
 *
 * A compute rule can live on `blueprint_fields.compute_rule` (every variant) or
 * on a variant_overrides row with action='compute' (one variant). The graph the
 * guard checks is therefore per variant, and the only interesting question is
 * which of the two levels supplies the edges for a given field. Getting that
 * wrong is silent in both directions: keeping a shadowed blueprint rule rejects
 * writes that are safe, dropping an unshadowed one persists a cycle.
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');

const {
  parseStoredRule,
  extractComputeSources,
  buildEffectiveRules,
  buildFieldContext,
  hasCycle,
  makeSourceCache,
  distinctVariantRuleSets,
} = require('../../src/edge/lib/compute-rule-graph');

const concat = (...keys) => ({
  op: 'concat',
  overridable: false,
  output_type: 'string',
  config: { parts: keys.map((key) => ({ type: 'field', key })) },
});

describe('parseStoredRule', () => {
  it('accepts a parsed object and a serialized one alike', () => {
    const rule = concat('a');
    assert.deepEqual(parseStoredRule(rule), rule);
    assert.deepEqual(parseStoredRule(JSON.stringify(rule)), rule);
  });

  it('returns null for anything that is not a rule object', () => {
    for (const bad of [null, undefined, 'not json', '[]', '"str"', '42', [1, 2], 7]) {
      assert.equal(parseStoredRule(bad), null, `expected ${JSON.stringify(bad)} to parse to null`);
    }
  });
});

describe('buildEffectiveRules — variant level replaces blueprint level', () => {
  it('keeps a blueprint rule on a field the variant does not override', () => {
    const blueprint = new Map([['a', concat('b')]]);
    const effective = buildEffectiveRules(blueprint, new Map());
    assert.deepEqual(effective.get('a'), concat('b'));
  });

  it('replaces (never merges) the blueprint rule when the variant overrides the field', () => {
    const blueprint = new Map([['a', concat('b')]]);
    const variant = new Map([['a', concat('c')]]);
    const effective = buildEffectiveRules(blueprint, variant);
    assert.deepEqual(effective.get('a'), concat('c'));
    assert.equal(effective.size, 1);
  });

  it('does not mutate the blueprint map it was given', () => {
    const blueprint = new Map([['a', concat('b')]]);
    buildEffectiveRules(blueprint, new Map([['z', concat('a')]]));
    assert.deepEqual([...blueprint.keys()], ['a']);
  });
});

describe('hasCycle over the effective graph', () => {
  it('sees a cycle that spans one blueprint rule and one variant rule', () => {
    const blueprint = new Map([['a', concat('b')]]);
    const variant = new Map([['b', concat('a')]]);
    assert.equal(hasCycle(buildEffectiveRules(blueprint, variant)), true);
  });

  it('does not see a cycle when the variant SHADOWS the blueprint rule that closed it', () => {
    // Blueprint: a <- b. Variant: b <- a would close the loop, but the variant
    // also replaces a with a rule that references nothing, so the blueprint's
    // a <- b edge never evaluates here.
    const blueprint = new Map([['a', concat('b')]]);
    const variant = new Map([['b', concat('a')], ['a', concat('standalone')]]);
    assert.equal(hasCycle(buildEffectiveRules(blueprint, variant)), false);
  });

  it('sees a self-referencing rule as a cycle', () => {
    assert.equal(hasCycle(new Map([['a', concat('a')]])), true);
  });

  it('accepts a chain that never closes', () => {
    const rules = new Map([['a', concat('b')], ['b', concat('c')]]);
    assert.equal(hasCycle(rules), false);
  });
});

describe('extractComputeSources', () => {
  it('reads field keys out of every op the validator accepts', () => {
    assert.deepEqual(extractComputeSources(concat('a', 'b')), ['a', 'b']);
    assert.deepEqual(
      extractComputeSources({ op: 'transform', config: { source: 'a', transform: 'upper' } }),
      ['a'],
    );
    assert.deepEqual(
      extractComputeSources({
        op: 'arith',
        config: { operator: 'add', operands: [{ type: 'field', key: 'a' }, { type: 'literal', value: 1 }] },
      }),
      ['a'],
    );
    assert.deepEqual(extractComputeSources({ op: 'lookup', config: { source: 'a', table: [] } }), ['a']);
  });

  it('yields nothing for a rule shape it cannot read', () => {
    for (const bad of [null, {}, { op: 'nope', config: {} }]) {
      assert.deepEqual(extractComputeSources(bad), []);
    }
  });
});

describe('buildFieldContext', () => {
  it('collects every field key and the column allowlist of each table field', () => {
    const { fieldKeys, tableColumns } = buildFieldContext([
      { field_key: 'pn', field_type: 'text', table_config: null },
      { field_key: 'items', field_type: 'table', table_config: JSON.stringify({ columns: [{ key: 'part' }] }) },
    ]);
    assert.deepEqual([...fieldKeys].sort(), ['items', 'pn']);
    assert.deepEqual([...tableColumns.get('items')], ['part']);
    assert.equal(tableColumns.has('pn'), false);
  });

  it("falls back to the implicit 'value' column for a table with no columns config", () => {
    const { tableColumns } = buildFieldContext([
      { field_key: 'items', field_type: 'table', table_config: JSON.stringify({}) },
    ]);
    assert.deepEqual([...tableColumns.get('items')], ['value']);
  });
});

// ── Per-request reuse ───────────────────────────────────────────────────────
// The guard runs one topological sort per variant carrying compute overrides,
// and every sort re-reads the sources of every blueprint-level rule. Both the
// per-rule source walk and the whole sort are pure functions of their input, so
// neither has to be repeated.

describe('makeSourceCache', () => {
  it('walks a given rule object once, however often it is asked', () => {
    let reads = 0;
    const rule = new Proxy(concat('a'), {
      get(target, prop) { if (prop === 'config') reads += 1; return target[prop]; },
    });
    const extract = makeSourceCache();
    assert.deepEqual(extract(rule), ['a']);
    const afterFirstWalk = reads;
    assert.ok(afterFirstWalk > 0, 'the first call must actually walk the rule');
    assert.deepEqual(extract(rule), ['a']);
    assert.deepEqual(extract(rule), ['a']);
    assert.equal(reads, afterFirstWalk, 'later calls must not touch the rule again');
  });

  it('is per-cache, so two caches do not share state', () => {
    const rule = concat('a');
    assert.deepEqual(makeSourceCache()(rule), makeSourceCache()(rule));
  });

  it('feeds hasCycle without changing its verdict', () => {
    const rules = new Map([['a', concat('b')], ['b', concat('a')]]);
    assert.equal(hasCycle(rules, makeSourceCache()), true);
    assert.equal(hasCycle(new Map([['a', concat('b')]]), makeSourceCache()), false);
  });
});

describe('distinctVariantRuleSets', () => {
  it('collapses variants whose override sets carry the same edges', () => {
    // Two variants configured identically are two DB rows, so their rule objects
    // are never identical — only their content is. Laid over the same blueprint
    // rules they produce the same graph, so one sort answers for both.
    const byVariant = new Map([
      ['v-1', new Map([['a', concat('b')]])],
      ['v-2', new Map([['a', concat('b')]])],
      ['v-3', new Map([['a', concat('c')]])],
    ]);
    const sets = distinctVariantRuleSets(byVariant, makeSourceCache());
    assert.equal(sets.length, 2);
  });

  it('keeps variants apart when the same field carries different sources', () => {
    const byVariant = new Map([
      ['v-1', new Map([['a', concat('b')], ['x', concat('y')]])],
      ['v-2', new Map([['a', concat('b')]])],
    ]);
    assert.equal(distinctVariantRuleSets(byVariant, makeSourceCache()).length, 2);
  });

  it('ignores the order the fields arrive in', () => {
    const byVariant = new Map([
      ['v-1', new Map([['a', concat('b')], ['x', concat('y')]])],
      ['v-2', new Map([['x', concat('y')], ['a', concat('b')]])],
    ]);
    assert.equal(distinctVariantRuleSets(byVariant, makeSourceCache()).length, 1);
  });
});
