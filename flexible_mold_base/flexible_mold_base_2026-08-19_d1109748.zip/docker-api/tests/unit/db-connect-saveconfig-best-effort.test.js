/**
 * db-connect-saveconfig-best-effort.test.js — configure-db persistence contract.
 *
 * Persistence is opt-in (persist:true in the body). When opted in and the
 * in-memory pool swap succeeds but disk persist fails (EROFS in K8s deploys
 * with readOnlyRootFilesystem), the handler returns 200 OK with
 * `diskPersisted:false` — UI must not see a 500 for the disk side-effect alone.
 * Without persist, saveConfig is never called and diskPersisted stays false.
 */

const { test, describe, beforeEach, afterEach } = require('node:test');
const assert = require('node:assert/strict');

const dbPath = require.resolve('../../src/edge/db');
const dbConnectPath = require.resolve('../../src/edge/routes/platform/setup/db-connect');

function freshHandlerWithStubs(stubImpl) {
  // 1. Clear caches so destructured imports re-resolve
  delete require.cache[dbPath];
  delete require.cache[dbConnectPath];
  // 2. Pre-load db.js, mutate exports object so the destructure inside
  //    db-connect picks up the stubbed callables
  const dbModule = require('../../src/edge/db');
  Object.assign(dbModule, stubImpl);
  // 3. Now require db-connect — its destructure pulls from mutated dbModule
  const register = require('../../src/edge/routes/platform/setup/db-connect');
  // 4. Spy on a fake router to capture the POST /configure-db handler
  let handler = null;
  const fakeRouter = {
    get: () => {},
    post: (path, h) => { if (path === '/configure-db') handler = h; },
    put: () => {},
    delete: () => {},
    use: () => {},
  };
  register(fakeRouter);
  return handler;
}

function clearCache() {
  delete require.cache[dbPath];
  delete require.cache[dbConnectPath];
}

function makeReq(body) {
  return { body, user: null };
}

function makeRes() {
  let statusCode = 200;
  let payload = null;
  return {
    statusCode: () => statusCode,
    body: () => payload,
    status(code) { statusCode = code; return this; },
    json(p) { payload = p; return this; },
  };
}

describe('configure-db — saveConfig best-effort (v3.2.53c B6)', () => {
  afterEach(() => clearCache());

  test('saveConfig EROFS → response 200 with diskPersisted=false', async () => {
    let saveCalled = false;
    let configureCalled = false;
    const handler = freshHandlerWithStubs({
      isPoolReady: () => false,
      getDbConfig: () => ({ host: 'h', port: 3306, user: 'u', database: 'd', tablePrefix: 'fmb_', source: 'file', configured: true }),
      getDbConfigFull: () => null,
      configurePool: async () => { configureCalled = true; },
      saveConfig: () => {
        saveCalled = true;
        const e = new Error("EROFS: read-only file system, mkdir '/app/data'");
        e.code = 'EROFS';
        throw e;
      },
    });

    assert.ok(handler, 'POST /configure-db handler should have been registered');
    const req = makeReq({ host: '127.0.0.1', port: 3306, user: 'root', password: 'p', database: 'fmb', tablePrefix: 'fmb_', persist: true });
    const res = makeRes();
    await handler(req, res);

    assert.equal(configureCalled, true, 'configurePool was called');
    assert.equal(saveCalled, true, 'saveConfig was called');
    assert.equal(res.statusCode(), 200, `expected 200 OK; got ${res.statusCode()} body=${JSON.stringify(res.body())}`);
    assert.equal(res.body().error, null, 'apiOk envelope: error must be null');
    assert.equal(res.body().data.diskPersisted, false, 'diskPersisted=false on EROFS');
    assert.equal(res.body().data.host, '127.0.0.1');
    assert.equal(res.body().data.database, 'fmb');
  });

  test('saveConfig success → response 200 with diskPersisted=true', async () => {
    let saveCalled = false;
    const handler = freshHandlerWithStubs({
      isPoolReady: () => false,
      getDbConfig: () => ({ host: 'h', port: 3306, user: 'u', database: 'd', tablePrefix: 'fmb_', source: 'file', configured: true }),
      getDbConfigFull: () => null,
      configurePool: async () => {},
      saveConfig: () => { saveCalled = true; },
    });

    const req = makeReq({ host: '127.0.0.1', port: 3306, user: 'root', password: 'p', database: 'fmb', tablePrefix: 'fmb_', persist: true });
    const res = makeRes();
    await handler(req, res);

    assert.equal(saveCalled, true);
    assert.equal(res.statusCode(), 200);
    assert.equal(res.body().data.diskPersisted, true);
  });

  test('default (no persist) → saveConfig NOT called, diskPersisted=false', async () => {
    let saveCalled = false;
    const handler = freshHandlerWithStubs({
      isPoolReady: () => false,
      getDbConfig: () => ({ host: 'h', port: 3306, user: 'u', database: 'd', tablePrefix: 'fmb_', source: 'file', configured: true }),
      getDbConfigFull: () => null,
      configurePool: async () => {},
      saveConfig: () => { saveCalled = true; },
    });

    const req = makeReq({ host: '127.0.0.1', port: 3306, user: 'root', password: 'p', database: 'fmb', tablePrefix: 'fmb_' });
    const res = makeRes();
    await handler(req, res);

    assert.equal(saveCalled, false, 'saveConfig not called without persist');
    assert.equal(res.statusCode(), 200);
    assert.equal(res.body().data.diskPersisted, false);
  });

  test('non-boolean persist (string "false") does NOT persist', async () => {
    let saveCalled = false;
    const handler = freshHandlerWithStubs({
      isPoolReady: () => false,
      getDbConfig: () => ({ host: 'h', port: 3306, user: 'u', database: 'd', tablePrefix: 'fmb_', source: 'file', configured: true }),
      getDbConfigFull: () => null,
      configurePool: async () => {},
      saveConfig: () => { saveCalled = true; },
    });

    const req = makeReq({ host: '127.0.0.1', port: 3306, user: 'root', password: 'p', database: 'fmb', tablePrefix: 'fmb_', persist: 'false' });
    const res = makeRes();
    await handler(req, res);

    assert.equal(saveCalled, false, 'truthy non-boolean persist must not trigger a write');
    assert.equal(res.body().data.diskPersisted, false);
  });

  test('configurePool throw → response 500 (unchanged behaviour)', async () => {
    const handler = freshHandlerWithStubs({
      isPoolReady: () => false,
      getDbConfig: () => null,
      getDbConfigFull: () => null,
      configurePool: async () => { const e = new Error('Access denied for user'); e.code = 'ER_ACCESS_DENIED_ERROR'; throw e; },
      saveConfig: () => { throw new Error('should not be called'); },
    });

    const req = makeReq({ host: '127.0.0.1', port: 3306, user: 'baduser', password: 'p', database: 'fmb', tablePrefix: 'fmb_' });
    const res = makeRes();
    await handler(req, res);

    assert.equal(res.statusCode(), 500, 'configurePool failure still returns 500');
    assert.equal(res.body().error.code, 'DB_CONFIG_ERROR');
  });
});

describe("configure-db — source state ('memory' vs 'file')", () => {
  afterEach(() => clearCache());

  const baseBody = { host: 'h', port: 3306, user: 'u', password: 'p', database: 'd', tablePrefix: 'fmb_' };

  test('ephemeral swap (no persist) sets source to memory', async () => {
    let sourceArg = null;
    const handler = freshHandlerWithStubs({
      isPoolReady: () => false,
      getDbConfig: () => ({ host: 'h', port: 3306, user: 'u', database: 'd', tablePrefix: 'fmb_', source: 'memory', configured: true }),
      getDbConfigFull: () => null,
      configurePool: async () => {},
      saveConfig: () => { throw new Error('saveConfig must not be called when persist is falsy'); },
      setConfigSource: (src) => { sourceArg = src; },
    });
    const res = makeRes();
    await handler(makeReq({ ...baseBody }), res);
    assert.equal(res.statusCode(), 200);
    assert.equal(sourceArg, 'memory', 'a non-persisted swap must mark the source memory');
  });

  test('persisted swap (persist:true, saveConfig ok) sets source to file', async () => {
    let sourceArg = null;
    const handler = freshHandlerWithStubs({
      isPoolReady: () => false,
      getDbConfig: () => ({ host: 'h', port: 3306, user: 'u', database: 'd', tablePrefix: 'fmb_', source: 'file', configured: true }),
      getDbConfigFull: () => null,
      configurePool: async () => {},
      saveConfig: () => {},
      setConfigSource: (src) => { sourceArg = src; },
    });
    const res = makeRes();
    await handler(makeReq({ ...baseBody, persist: true }), res);
    assert.equal(res.statusCode(), 200);
    assert.equal(sourceArg, 'file', 'a persisted swap must mark the source file');
  });

  test('persist requested but saveConfig fails → source memory (persist-fail collapses)', async () => {
    let sourceArg = null;
    const handler = freshHandlerWithStubs({
      isPoolReady: () => false,
      getDbConfig: () => ({ host: 'h', port: 3306, user: 'u', database: 'd', tablePrefix: 'fmb_', source: 'memory', configured: true }),
      getDbConfigFull: () => null,
      configurePool: async () => {},
      saveConfig: () => { const e = new Error('EROFS'); e.code = 'EROFS'; throw e; },
      setConfigSource: (src) => { sourceArg = src; },
    });
    const res = makeRes();
    await handler(makeReq({ ...baseBody, persist: true }), res);
    assert.equal(res.statusCode(), 200);
    assert.equal(res.body().data.diskPersisted, false, 'disk persist failed → diskPersisted false');
    assert.equal(sourceArg, 'memory', 'persist-fail must collapse the source to memory, not file');
  });
});
