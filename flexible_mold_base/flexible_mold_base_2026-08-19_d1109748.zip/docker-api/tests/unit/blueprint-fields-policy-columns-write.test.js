/**
 * blueprint-fields-policy-columns-write.test.js
 *
 * Blueprint-level field policy (value_source + its payload columns) is written
 * through the existing custom PUT, which builds its SET list from the request
 * body. These tests pin that the columns are accepted, coerced by the DTO
 * mapper, and still written as partial PATCHes — plus the structural floor that
 * stops a non-object compute_rule from reaching the column, the agreement rules
 * that stop a mode and its payload from drifting apart, and the operator-mode
 * gate that degrades instead of 500ing on a DB where the ALTER was skipped.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../src/edge/db');

const DATABASE_PROBE = /^SELECT DATABASE\(\)/i;
const COLUMN_PROBE = /SELECT COLUMN_NAME FROM information_schema\.COLUMNS/i;

const BF_COLUMNS_WITH_POLICY = [
  'id', 'blueprint_id', 'field_type', 'field_key', 'field_label',
  'table_config', 'depends_on_field_key', 'value_source', 'value_scope', 'compute_rule',
];
const BF_COLUMNS_PRE_MIGRATION = [
  'id', 'blueprint_id', 'field_type', 'field_key', 'field_label',
  'table_config', 'depends_on_field_key',
];

let conn;

// The column-set probe is memoised per (database, table), so each fixture
// reports its own database name — otherwise the first probe's answer would be
// reused and the operator-mode case could never be exercised.
let dbSeq = 0;

function makeConn({ columns = BF_COLUMNS_WITH_POLICY, scripts = [] } = {}) {
  const dbName = `db_${dbSeq += 1}`;
  const queries = [];
  let committed = false;
  let rolledBack = false;
  return {
    queries,
    committed: () => committed,
    rolledBack: () => rolledBack,
    async beginTransaction() {},
    async commit() { committed = true; },
    async rollback() { rolledBack = true; },
    async query(sql, params) {
      queries.push({ sql, params });
      for (const [matcher, response] of scripts) {
        if (matcher.test(sql)) return typeof response === 'function' ? response(sql, params) : response;
      }
      if (DATABASE_PROBE.test(sql)) return [{ db: dbName }];
      if (COLUMN_PROBE.test(sql)) {
        const table = Array.isArray(params) ? params[0] : undefined;
        if (table === 'fmb_field_options') {
          return ['id', 'field_id', 'option_value', 'valid_parent_values'].map((c) => ({ COLUMN_NAME: c }));
        }
        return columns.map((c) => ({ COLUMN_NAME: c }));
      }
      if (/SELECT id, blueprint_id, field_type/.test(sql)) {
        return [{
          id: 'f-1', blueprint_id: 'bp-1', field_type: 'text',
          field_key: 'pn', depends_on_field_key: null,
        }];
      }
      // Blueprint-level compute validation reads the blueprint's fields and
      // their rules in one scan, then the variant-level rules. No rule is
      // stored in these fixtures.
      if (/SELECT field_key, field_type, table_config(, compute_rule)? FROM `fmb_blueprint_fields`/i.test(sql)) {
        return [
          { field_key: 'pn', field_type: 'text', table_config: null, compute_rule: null },
          { field_key: 'sku', field_type: 'text', table_config: null, compute_rule: null },
        ];
      }
      if (/SELECT vo\.variant_id, bf\.field_key, vo\.compute_rule/i.test(sql)) return [];
      if (/^UPDATE `fmb_blueprint_fields`/i.test(sql)) return { affectedRows: 1 };
      if (/^SELECT \* FROM `fmb_blueprint_fields`/i.test(sql)) {
        return [{ id: 'f-1', blueprint_id: 'bp-1', field_key: 'pn', field_type: 'text', value_source: 'locked' }];
      }
      // Linked-blueprint guard probes: not linked in these fixtures.
      if (/SELECT linked_blueprint_id FROM/.test(sql)) return [];
      if (/ AS bid FROM/.test(sql) || / AS fk FROM/.test(sql)) return [];
      throw new Error(`Unmatched query in test: ${sql.slice(0, 100)}`);
    },
    release() {},
  };
}

const poolSpy = {
  rw: { async getConnection() { return conn; } },
  ro: { async getConnection() { throw new Error('test error: PUT should use pool.rw'); } },
};

require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: poolSpy, t: (name) => `fmb_${name}`, getDynamicPool: async () => poolSpy },
};

const router = require('../../src/edge/routes/app/schema');

let server;
let port;

before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { req.user = { id: 'admin-1', role: 'admin' }; next(); });
  app.use('/edge/app/schema', router);
  await new Promise((resolve) => {
    server = app.listen(0, '127.0.0.1', () => { port = server.address().port; resolve(); });
  });
});

after(async () => {
  await new Promise((resolve) => server.close(resolve));
  delete require.cache[dbKey];
});

beforeEach(() => { conn = null; });

function put(path, body) {
  return new Promise((resolve, reject) => {
    const data = JSON.stringify(body);
    const r = http.request({
      method: 'PUT', host: '127.0.0.1', port, path,
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(data) },
    }, (res) => {
      let raw = '';
      res.on('data', (c) => { raw += c; });
      res.on('end', () => resolve({ status: res.statusCode, body: raw ? JSON.parse(raw) : null }));
    });
    r.on('error', reject);
    r.write(data);
    r.end();
  });
}

const fieldUpdate = (queries) => queries.find((q) => /^UPDATE `fmb_blueprint_fields` SET/i.test(q.sql.trim()));

// A complete rule: a blueprint-level compute_rule clears the same validator a
// variant-level one does, so a shape the validator rejects would never reach the
// column and could not exercise the write path this file is about.
const RULE = {
  op: 'concat',
  overridable: false,
  output_type: 'string',
  config: { parts: [{ type: 'field', key: 'sku' }] },
};

describe('PUT /blueprint_fields/:id — a column named in another case is not written', () => {
  // This handler builds its own SET list rather than going through the CRUD
  // factory, so it is a second reader of the shared column gate — which is
  // where the rule lives precisely so that a handler written later inherits it
  // instead of having to remember it. A MariaDB column identifier resolves
  // case-insensitively, so a key spelled `Value_Source` would otherwise reach
  // `value_source` while the mode/payload agreement checks above — which read
  // the canonical name — never saw a mode change at all.
  it('drops the cased key and still writes the rest of the body', async () => {
    conn = makeConn();
    const res = await put('/edge/app/schema/blueprint_fields/f-1', {
      field_label: 'a label', Value_Source: 'calculated',
    });
    assert.equal(res.status, 200);
    const update = fieldUpdate(conn.queries);
    assert.ok(/`field_label` = \?/.test(update.sql), 'the legitimate column must still be written');
    assert.ok(!/value_source/i.test(update.sql), 'a mode reached the column without the agreement checks');
    assert.equal(update.params.includes('calculated'), false);
  });

  it('a body that is nothing but a cased key writes nothing at all', async () => {
    conn = makeConn();
    const res = await put('/edge/app/schema/blueprint_fields/f-1', { Value_Source: 'calculated' });
    assert.equal(res.status, 400, `expected a refusal, got ${JSON.stringify(res.body)}`);
    assert.equal(fieldUpdate(conn.queries), undefined, 'a refused write still issued an UPDATE');
  });
});

describe('PUT /blueprint_fields/:id — blueprint-level policy columns', () => {
  it('writes value_source verbatim and compute_rule as serialized JSON', async () => {
    conn = makeConn();
    const res = await put('/edge/app/schema/blueprint_fields/f-1', {
      value_source: 'calculated', compute_rule: RULE,
    });
    assert.equal(res.status, 200);
    const update = fieldUpdate(conn.queries);
    assert.ok(/`value_source` = \?/.test(update.sql));
    assert.ok(/`compute_rule` = \?/.test(update.sql));
    assert.ok(update.params.includes('calculated'));
    assert.ok(update.params.includes(JSON.stringify(RULE)));
  });

  it('writes the mode alone when the mode has no payload', async () => {
    conn = makeConn();
    const res = await put('/edge/app/schema/blueprint_fields/f-1', { value_source: 'locked' });
    assert.equal(res.status, 200);
    const update = fieldUpdate(conn.queries);
    const setClause = update.sql.slice(update.sql.indexOf('SET '), update.sql.lastIndexOf('WHERE'));
    assert.equal(setClause.match(/=\s*\?/g).length, 1, 'only the sent column may be written');
    assert.ok(/`value_source` = \?/.test(setClause));
    assert.equal(update.params[0], 'locked');
  });

  it('refuses a mode whose payload says something else', async () => {
    const incoherent = [
      { value_source: 'calculated' },
      { value_source: 'locked', compute_rule: RULE },
      { value_source: 'nonsense' },
      { compute_rule: RULE },
    ];
    for (const body of incoherent) {
      conn = makeConn();
      const res = await put('/edge/app/schema/blueprint_fields/f-1', body);
      assert.equal(res.status, 400, `expected ${JSON.stringify(body)} to be refused`);
      assert.equal(res.body.error.code, 'INCONSISTENT_VALUE_SOURCE');
      assert.equal(fieldUpdate(conn.queries), undefined);
      assert.equal(conn.committed(), false);
    }
  });

  it('refuses a cell scope on a field that has no cells', async () => {
    conn = makeConn();
    const res = await put('/edge/app/schema/blueprint_fields/f-1', {
      value_source: 'locked', value_scope: { columns: ['qty'] },
    });
    assert.equal(res.status, 400);
    assert.equal(res.body.error.code, 'INCONSISTENT_VALUE_SOURCE');
    assert.equal(fieldUpdate(conn.queries), undefined);
  });

  it('refuses to clear the rule on an explicit null with no mode beside it', async () => {
    // A bare `{compute_rule: null}` is a mode change wearing a clear's clothes:
    // the rule is what a stored 'copied'/'calculated' field IS, so stripping it
    // alone leaves the mode label describing an arrangement that is gone, and
    // the field's read-only guarantee with it.
    conn = makeConn();
    const res = await put('/edge/app/schema/blueprint_fields/f-1', { compute_rule: null });
    assert.equal(res.status, 400);
    assert.equal(res.body.error.code, 'INCONSISTENT_VALUE_SOURCE');
    assert.equal(fieldUpdate(conn.queries), undefined);
  });

  it('clears the rule when the mode comes with it, without touching other columns', async () => {
    conn = makeConn();
    const res = await put('/edge/app/schema/blueprint_fields/f-1', {
      value_source: 'entered', compute_rule: null,
    });
    assert.equal(res.status, 200);
    const update = fieldUpdate(conn.queries);
    assert.ok(/`compute_rule` = \?/.test(update.sql));
    assert.ok(/`value_source` = \?/.test(update.sql));
    assert.ok(!/`value_scope`/.test(update.sql), 'a column the body never named stays untouched');
  });

  it('rejects a non-object compute_rule before any write', async () => {
    for (const bad of [['a'], 42, 'not json']) {
      conn = makeConn();
      const res = await put('/edge/app/schema/blueprint_fields/f-1', { compute_rule: bad });
      assert.equal(res.status, 400, `expected ${JSON.stringify(bad)} to be rejected`);
      assert.equal(res.body.error.code, 'INCONSISTENT_FIELD_PAYLOAD');
      assert.equal(fieldUpdate(conn.queries), undefined);
      assert.equal(conn.committed(), false);
    }
  });

  it('degrades instead of failing on a DB that never got the new columns', async () => {
    conn = makeConn({ columns: BF_COLUMNS_PRE_MIGRATION });
    const res = await put('/edge/app/schema/blueprint_fields/f-1', { field_label: 'PN', value_source: 'locked' });
    assert.equal(res.status, 200);
    const update = fieldUpdate(conn.queries);
    assert.ok(!/value_source/.test(update.sql), 'an absent column must be gated out, not named in the UPDATE');
    assert.ok(/`field_label` = \?/.test(update.sql));
  });
});
