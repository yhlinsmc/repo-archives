/**
 * connector-template-reassign.test.js — connector-UI PR-4
 *
 * Route-level tri-state matrix for owner reassign on BOTH api_connectors
 * (new PATCH /:id/owner) and user_templates (relaxed from admin-only to
 * owner-or-admin). DB is mocked via require.cache injection (no live DB).
 *
 * Matrix (per connector + template):
 *   admin → any row → real user B          : 200 transfer
 *   admin → make_shared (null)             : 400 (no shared semantic)
 *   owner(editor) → own row → real user B   : 200 transfer (requireCondition=self)
 *   owner(editor) → another owner's row     : 403 (NOT_SELF)
 *   any → nonexistent target user           : 400
 *   plain user → reassign                   : 403 (blanket gate / requireAdminOrEditor)
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../src/edge/db');

// IDENTIFIER-SHAPED, and that is now load-bearing rather than tidy. The
// connector reassign gained the shape floor its siblings already had, because
// `users.id` is `CHAR(36)` and a CHAR comparison pads the shorter operand — so
// `WHERE id = '<uuid> '` resolved a row and a string that is not an identifier
// went on to move the row's owner. A fixture spelling a user `'user-b'`
// therefore exercises a request the deployed system cannot receive, and after
// the floor it exercises nothing but the floor (see tests/helpers/fixture-ids.js
// for the same reasoning applied schema-wide).
const ADMIN_1 = '1a2b3c4d-0000-4000-8000-00000000ad01';
const EDITOR_1 = '1a2b3c4d-0000-4000-8000-0000000ed101';
const USER_B = '1a2b3c4d-0000-4000-8000-000000000b0b';
const SOMEONE_ELSE = '1a2b3c4d-0000-4000-8000-00000000e15e';
const OTHER_OWNER = '1a2b3c4d-0000-4000-8000-000000001e55';
const GHOST = '1a2b3c4d-0000-4000-8000-00000000dead';

let conn;
let role = 'admin';
let actorId = ADMIN_1;

function makeConn(scripts) {
  const queries = [];
  return {
    queries,
    async beginTransaction() {},
    async commit() {},
    async rollback() {},
    async query(sql, params) {
      queries.push({ sql, params });
      for (const [matcher, response] of scripts) {
        if (matcher.test(sql)) {
          if (response instanceof Error) throw response;
          return typeof response === 'function' ? response(sql, params) : response;
        }
      }
      // The owner precondition is asked of the COLUMN, because `owner_id` folds
      // case and every SQL enforcement point on these rows folds with it.
      // Answered the way `utf8mb4_general_ci` answers rather than with a
      // constant: a fixed `same` would decide the 200/403 branch under test.
      if (/SELECT DATABASE\(\)/.test(sql)) return [{ db: 'reassign_test_db' }];
      if (/information_schema\.COLUMNS/.test(sql)) {
        return [{ cs: 'utf8mb4', co: 'utf8mb4_general_ci' }];
      }
      if (/<=>/.test(sql)) {
        const [a, b] = params;
        return [{ same: String(a).toLowerCase() === String(b).toLowerCase() ? 1 : 0 }];
      }
      throw new Error(`Unmatched query: ${sql.slice(0, 80)}`);
    },
    release() {},
  };
}

// The connector null-owner guard and the bundle-state probe both read the row
// this request is about to write, on the pool that request resolves — which is
// the WRITE pool, and the per-request one when the body names `db`. Both facades
// answer the same rows here so the double cannot be the thing that decides which
// pool the guard is allowed to use; tests set `roOwnerRows` to the SELECT
// owner_id result for that probe.
let roOwnerRows = [];
const poolFacade = () => ({
  async getConnection() { return conn; },
  async query() { return roOwnerRows; },
});
const poolSpy = { rw: poolFacade(), ro: poolFacade() };

require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: {
    pool: poolSpy,
    t: (name) => `fmb_${name}`,
    getDynamicPool: async () => poolSpy,
  },
};

const schemaRouter = require('../../src/edge/routes/app/schema');
const connectorRouter = require('../../src/edge/routes/app/api-connectors');
const { _clearColumnCollationCache } = require('../../src/edge/routes/app/schema/write-value');

let server;
let port;

before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => {
    req.user = { id: actorId, role };
    next();
  });
  app.use('/edge/app/schema', schemaRouter);
  app.use('/edge/app/api-connectors', connectorRouter);
  await new Promise((resolve) => {
    server = app.listen(0, '127.0.0.1', () => { port = server.address().port; resolve(); });
  });
});

after(async () => {
  await new Promise((resolve) => server.close(resolve));
  delete require.cache[dbKey];
});

// The collation probe memoises per schema.table.column, so a cached entry would
// make the query script a test sees depend on which test ran before it.
beforeEach(() => { conn = null; roOwnerRows = []; _clearColumnCollationCache(); });

function call(method, path, body) {
  return new Promise((resolve, reject) => {
    const data = body ? JSON.stringify(body) : '';
    const req = http.request({
      method, host: '127.0.0.1', port, path,
      headers: data
        ? { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(data) }
        : {},
    }, (res) => {
      let raw = '';
      res.on('data', (c) => { raw += c; });
      res.on('end', () => resolve({ status: res.statusCode, body: raw ? JSON.parse(raw) : null }));
    });
    req.on('error', reject);
    if (data) req.write(data);
    req.end();
  });
}

// target-exists probe — connector reads `id, role`, template reads `id`.
const USER_PROBE = /SELECT id(, role, banned)? FROM `fmb_users` WHERE id/i;
const USER_EXISTS = [USER_PROBE, [{ id: USER_B, role: 'editor' }]];
const USER_PLAIN = [USER_PROBE, [{ id: USER_B, role: 'user' }]];
const USER_MISSING = [USER_PROBE, []];
// SELECT id, owner_id ... FOR UPDATE — the row being transferred
const rowOwned = (owner) => [/SELECT id, owner_id FROM .* FOR UPDATE/i, [{ id: 'row-1', owner_id: owner }]];
const UPDATE_OK = [/^UPDATE `fmb_/i, { affectedRows: 1 }];
const AUDIT_OK = [/INSERT INTO `fmb_feature_audit`/i, { affectedRows: 1 }];
// Connector editor-target manageability guard (connector route only; template
// never queries these, so they sit unused in the template cases).
const CONN_BP = [/SELECT blueprint_id FROM `fmb_api_connectors`/i, [{ blueprint_id: 'bp-1' }]];
const BP_SHARED = [/SELECT owner_id FROM `fmb_hierarchy_nodes`/i, [{ owner_id: null }]];

const CASES = [
  { name: 'connector', path: '/edge/app/api-connectors/row-1/owner' },
  { name: 'template', path: '/edge/app/schema/user_templates/row-1/owner' },
];

for (const c of CASES) {
  describe(`reassign tri-state — ${c.name}`, () => {
    it('admin transfers any row to a real user → 200', async () => {
      role = 'admin'; actorId = ADMIN_1;
      conn = makeConn([USER_EXISTS, CONN_BP, BP_SHARED, rowOwned(SOMEONE_ELSE), UPDATE_OK, AUDIT_OK]);
      const res = await call('PATCH', c.path, { new_owner_id: USER_B });
      assert.equal(res.status, 200);
      assert.equal(res.body.data.changed, true);
      assert.equal(res.body.data.owner_id, USER_B);
    });

    it('admin make_shared (null new_owner_id) → 400', async () => {
      role = 'admin'; actorId = ADMIN_1;
      conn = makeConn([]); // never reaches DB — body validation rejects first
      const res = await call('PATCH', c.path, { new_owner_id: null });
      assert.equal(res.status, 400);
    });

    it('owner (editor) transfers their OWN row → 200', async () => {
      role = 'editor'; actorId = EDITOR_1;
      conn = makeConn([USER_EXISTS, CONN_BP, BP_SHARED, rowOwned(EDITOR_1), UPDATE_OK, AUDIT_OK]);
      const res = await call('PATCH', c.path, { new_owner_id: USER_B });
      assert.equal(res.status, 200);
      assert.equal(res.body.data.changed, true);
    });

    it("editor transferring ANOTHER owner's row → 403 (NOT_SELF)", async () => {
      role = 'editor'; actorId = EDITOR_1;
      conn = makeConn([USER_EXISTS, CONN_BP, BP_SHARED, rowOwned(SOMEONE_ELSE)]);
      const res = await call('PATCH', c.path, { new_owner_id: USER_B });
      assert.equal(res.status, 403);
    });

    it('target user does not exist → 400', async () => {
      role = 'admin'; actorId = ADMIN_1;
      conn = makeConn([USER_MISSING]);
      const res = await call('PATCH', c.path, { new_owner_id: GHOST });
      assert.equal(res.status, 400);
    });

    it('plain user is rejected by the role gate → 403', async () => {
      role = 'user'; actorId = 'user-9';
      conn = makeConn([]);
      const res = await call('PATCH', c.path, { new_owner_id: USER_B });
      assert.equal(res.status, 403);
    });
  });
}

// getDynamicPool trust boundary — route-level defense in depth. This test app
// does NOT mount the x-database-validate middleware, so this asserts the guard
// baked into the reassign route itself (reject-client-db before any DB work).
describe('connector reassign — client-supplied db config rejected (defense in depth)', () => {
  it('PATCH with a body.db → 400 CLIENT_DB_CONFIG_REJECTED, no DB touched', async () => {
    role = 'admin'; actorId = ADMIN_1;
    conn = makeConn([]); // must never be queried
    const res = await call('PATCH', '/edge/app/api-connectors/row-1/owner', {
      new_owner_id: USER_B,
      db: { host: '10.0.0.5', port: 6379, user: 'attacker', password: 'evil', database: 'sibling' },
    });
    assert.equal(res.status, 400);
    assert.equal(res.body.error.code, 'CLIENT_DB_CONFIG_REJECTED');
  });
});

// Connector-only server-side guards (codex re-review P2).
describe('connector reassign — target must be admin/editor', () => {
  it('rejects a transfer to a plain user role → 400', async () => {
    role = 'admin'; actorId = ADMIN_1;
    conn = makeConn([USER_PLAIN]); // probe returns role:'user'
    const res = await call('PATCH', '/edge/app/api-connectors/row-1/owner', { new_owner_id: USER_B });
    assert.equal(res.status, 400);
  });
});

describe('connector reassign — editor target must be able to manage the row', () => {
  it("rejects transfer to an editor who doesn't own the bound blueprint → 400", async () => {
    role = 'admin'; actorId = ADMIN_1;
    // blueprint owned by someone else, not shared → editor target can't manage.
    const BP_FOREIGN = [/SELECT owner_id FROM `fmb_hierarchy_nodes`/i, [{ owner_id: OTHER_OWNER }]];
    conn = makeConn([USER_EXISTS, CONN_BP, BP_FOREIGN]);
    const res = await call('PATCH', '/edge/app/api-connectors/row-1/owner', { new_owner_id: USER_B });
    assert.equal(res.status, 400);
  });

  it('rejects transfer of an unbound connector to an editor → 400', async () => {
    role = 'admin'; actorId = ADMIN_1;
    const CONN_UNBOUND = [/SELECT blueprint_id FROM `fmb_api_connectors`/i, [{ blueprint_id: null }]];
    conn = makeConn([USER_EXISTS, CONN_UNBOUND]);
    const res = await call('PATCH', '/edge/app/api-connectors/row-1/owner', { new_owner_id: USER_B });
    assert.equal(res.status, 400);
  });

  it('allows transfer to an admin target regardless of blueprint ownership', async () => {
    role = 'admin'; actorId = ADMIN_1;
    const USER_ADMIN = [USER_PROBE, [{ id: USER_B, role: 'admin' }]];
    // admin target skips the blueprint guard entirely.
    conn = makeConn([USER_ADMIN, rowOwned(SOMEONE_ELSE), UPDATE_OK, AUDIT_OK]);
    const res = await call('PATCH', '/edge/app/api-connectors/row-1/owner', { new_owner_id: USER_B });
    assert.equal(res.status, 200);
  });
});

describe('connector null-owner write guard', () => {
  it('blocks a non-admin PUT on a NULL-owned connector → 403', async () => {
    role = 'editor'; actorId = EDITOR_1;
    roOwnerRows = [{ owner_id: null }];
    conn = makeConn([]); // guard rejects before the CRUD factory runs
    const res = await call('PUT', '/edge/app/api-connectors/row-1', {
      name: 'c', url: 'http://svc/x', method: 'GET', dispatch_origin: 'infra',
    });
    assert.equal(res.status, 403);
  });

  it('lets an admin PUT proceed past the guard on a NULL-owned connector', async () => {
    role = 'admin'; actorId = ADMIN_1;
    roOwnerRows = [{ owner_id: null }];
    // admin bypasses the guard; CRUD factory then runs — accept any non-403
    // (the factory needs deeper mocks; we only assert the guard didn't block).
    conn = makeConn([[/.*/, []]]);
    const res = await call('PUT', '/edge/app/api-connectors/row-1', {
      name: 'c', url: 'http://svc/x', method: 'GET', dispatch_origin: 'infra',
    });
    assert.notEqual(res.status, 403);
  });
});
