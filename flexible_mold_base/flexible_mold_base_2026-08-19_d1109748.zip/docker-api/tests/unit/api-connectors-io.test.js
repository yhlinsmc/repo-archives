/**
 * api-connectors-io.test.js — export/import route behaviour.
 *
 * Boots the real api-connectors router against a mocked db pool (require.cache
 * seed, same pattern as transformers-active-uses-ro.test.js) and asserts:
 *   - GET /:id/export strips secrets from auth_config
 *   - GET /:id/export 404s a missing connector
 *   - POST /import with a local blueprint binds it
 *   - POST /import with an unknown blueprint stores it unbound (NULL)
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../src/edge/db');

let state;
function makeConn() {
  return {
    async query(sql, params) {
      state.queries.push({ sql, params });
      if (/SELECT id, parent_id, name(?:, node_type)? FROM `fmb_hierarchy_nodes`/.test(sql)) {
        return state.nodes || [];
      }
      if (/SELECT owner_id FROM `fmb_hierarchy_nodes` WHERE id = \?/.test(sql)) {
        return state.blueprintOwner === undefined ? [] : [{ owner_id: state.blueprintOwner }];
      }
      if (/SELECT 1 FROM `fmb_hierarchy_nodes`/.test(sql)) {
        return state.blueprintExists ? [{ 1: 1 }] : [];
      }
      if (/FROM `fmb_api_connectors` WHERE id = \?/.test(sql) && /SELECT name, description/.test(sql)) {
        return state.exportRow ? [state.exportRow] : [];
      }
      // Tolerant per-connector timeout probe (export).
      if (/SELECT timeout_ms FROM `fmb_api_connectors` WHERE id = \?/.test(sql)) {
        if (state.failTimeoutProbe) {
          const e = new Error("Unknown column 'timeout_ms'");
          e.code = 'ER_BAD_FIELD_ERROR'; e.errno = 1054;
          throw e;
        }
        return state.timeoutRow === undefined ? [] : [{ timeout_ms: state.timeoutRow }];
      }
      // Best-effort timeout_ms carry (import).
      if (/UPDATE `fmb_api_connectors` SET timeout_ms = \?/.test(sql)) {
        if (state.failTimeoutImport) {
          const e = new Error("Unknown column 'timeout_ms'");
          e.code = 'ER_BAD_FIELD_ERROR'; e.errno = 1054;
          throw e;
        }
        return { affectedRows: 1 };
      }
      if (/^INSERT INTO `fmb_api_connectors`/.test(sql.trim())) {
        state.insertParams = params;
        return { affectedRows: 1 };
      }
      if (/SELECT \* FROM `fmb_api_connectors` WHERE id = \?/.test(sql)) {
        return [{ id: params[0], name: 'imported' }];
      }
      // Save-time egress allow-list read (hostAllowedForUrl). Absent state →
      // [] rows → loadHostAllowlist returns [] → allow-all, so existing tests
      // are unaffected; set state.allowlistRow to enforce.
      if (/SELECT `value` FROM `fmb_system_settings` WHERE `key` = \?/.test(sql)) {
        return state.allowlistRow === undefined ? [] : [{ value: state.allowlistRow }];
      }
      return [];
    },
    release() {},
  };
}

// The real pool facade (edge/db.js) exposes BOTH .getConnection() and .query();
// the allow-list gate calls pool.ro.query() directly, so the mock must too.
const poolSpy = {
  ro: { async getConnection() { return makeConn(); }, async query(sql, params) { return makeConn().query(sql, params); } },
  rw: { async getConnection() { return makeConn(); }, async query(sql, params) { return makeConn().query(sql, params); } },
};

require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: poolSpy, t: (name) => `fmb_${name}` },
};

const router = require('../../src/edge/routes/app/api-connectors');

let server;
let base;
let currentUser;

before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { req.user = currentUser; next(); });
  app.use('/c', router);
  server = http.createServer(app);
  await new Promise((r) => server.listen(0, r));
  base = `http://127.0.0.1:${server.address().port}`;
});

after(() => server && server.close());

beforeEach(() => {
  state = { queries: [], blueprintExists: false, exportRow: null, insertParams: null, nodes: [] };
  currentUser = { id: 'admin-1', role: 'admin', email: 'a@x' };
});

async function req(method, path, body) {
  const res = await fetch(`${base}${path}`, {
    method,
    headers: { 'content-type': 'application/json' },
    body: body ? JSON.stringify(body) : undefined,
  });
  return { status: res.status, json: await res.json() };
}

describe('GET /:id/export', () => {
  it('strips the secret leaf from auth_config', async () => {
    state.exportRow = {
      name: 'weather', description: null, is_active: 1,
      blueprint_id: 'bp-1', method: 'GET', url: 'http://svc/x',
      auth_type: 'bearer',
      auth_config: JSON.stringify({ token: 'enc:v1:secret' }),
      request_config: null, response_config: null,
    };
    const { status, json } = await req('GET', '/c/abc/export');
    assert.equal(status, 200);
    assert.equal(json.data.name, 'weather');
    assert.equal('token' in json.data.auth_config, false, 'export must not carry the token');
    assert.ok(json.data.exported_at);
  });

  it('404s when the connector is missing', async () => {
    state.exportRow = null;
    const { status, json } = await req('GET', '/c/none/export');
    assert.equal(status, 404);
    assert.equal(json.error.code, 'NOT_FOUND');
  });

  it('carries the blueprint lineage as blueprint_path', async () => {
    state.exportRow = {
      name: 'w', description: null, is_active: 1,
      blueprint_id: 'b1', method: 'GET', url: 'http://svc/x',
      auth_type: 'none', auth_config: null,
      request_config: null, response_config: null,
    };
    state.nodes = [
      { id: 'g', parent_id: null, name: 'Gen A' },
      { id: 'r', parent_id: 'g', name: 'Release 1' },
      { id: 'b1', parent_id: 'r', name: 'Mold' },
    ];
    const { status, json } = await req('GET', '/c/abc/export');
    assert.equal(status, 200);
    assert.deepEqual(json.data.blueprint_path, ['Gen A', 'Release 1', 'Mold']);
  });
});

describe('export redaction (url creds / headers / stray secret leaf)', () => {
  it('strips url credentials, blanks sensitive headers, drops a stray ciphertext leaf', async () => {
    state.exportRow = {
      name: 'leaky', description: null, is_active: 1,
      blueprint_id: null, method: 'POST', url: 'https://user:s3cr3t@svc/x',
      // auth_type 'none' but a stale bearer token ciphertext lingers (stray leaf).
      auth_type: 'none', auth_config: JSON.stringify({ token: 'enc:v1:STALE' }),
      request_config: JSON.stringify({ headers: { Authorization: 'Bearer SECRET', 'X-Trace': 'ok' } }),
      response_config: null,
    };
    const { status, json } = await req('GET', '/c/abc/export');
    assert.equal(status, 200);
    assert.equal(json.data.url, 'https://svc/x', 'url userinfo stripped');
    assert.equal('token' in json.data.auth_config, false, 'stray ciphertext leaf dropped');
    assert.equal(json.data.request_config.headers.Authorization, '', 'sensitive header blanked');
    assert.equal(json.data.request_config.headers['X-Trace'], 'ok', 'ordinary header kept');
  });
});

describe('export role gate', () => {
  it('lets an editor export any connector', async () => {
    currentUser = { id: 'ed-1', role: 'editor', email: 'e@x' };
    state.exportRow = {
      name: 'editor-export', description: null, is_active: 1,
      blueprint_id: null, method: 'GET', url: 'http://svc/x',
      auth_type: 'none', auth_config: null,
      request_config: null, response_config: null,
    };
    const { status, json } = await req('GET', '/c/abc/export');
    assert.equal(status, 200);
    assert.equal(json.data.name, 'editor-export');
  });
});

describe('POST /import', () => {
  it('binds to a local blueprint when it exists', async () => {
    state.blueprintExists = true;
    const { status } = await req('POST', '/c/import', {
      connector: { name: 'w', url: 'http://svc', blueprint_id: 'bp-1', auth_type: 'none' },
    });
    assert.equal(status, 201);
    // INSERT param index 5 = blueprint_id (id,name,desc,is_active,owner,blueprint_id,...)
    assert.equal(state.insertParams[5], 'bp-1');
  });

  it('stores unbound (NULL blueprint) when the blueprint is unknown', async () => {
    state.blueprintExists = false;
    const { status, json } = await req('POST', '/c/import', {
      connector: { name: 'w', url: 'http://svc', blueprint_id: 'ghost', auth_type: 'none' },
    });
    assert.equal(status, 201);
    assert.equal(state.insertParams[5], null, 'unknown blueprint must land NULL');
    assert.equal(json.data.unbound, true);
  });

  it('does not persist a masked credential header as the header itself', async () => {
    // THE SENTINEL, ON THE VERB THAT CREATES THE ROW. An import is a create, and
    // a hand-built bundle carrying `"Authorization":"****"` stored the four
    // literal characters as the header the request is dispatched with — the same
    // shape the CRUD create path had for `auth_config`. A genuine export/reimport
    // round trip blanks these to `''` and never reaches it, which is why only a
    // hand-edited bundle finds it — and a hand-edited bundle is what this path
    // accepts by design.
    state.blueprintExists = true;
    const { status } = await req('POST', '/c/import', {
      connector: {
        name: 'w',
        url: 'http://svc',
        blueprint_id: 'bp-1',
        auth_type: 'none',
        request_config: { headers: { Authorization: '****', Accept: 'application/json' } },
      },
    });
    assert.equal(status, 201);
    // INSERT param index 10 = request_config.
    const stored = JSON.parse(state.insertParams[10]);
    assert.equal(
      stored.headers.Authorization, undefined,
      'the mask sentinel was stored as the credential header',
    );
    assert.equal(
      stored.headers.Accept, 'application/json',
      'an ordinary header was dropped with it',
    );
  });

  it('rejects a payload missing name or url', async () => {
    const { status, json } = await req('POST', '/c/import', { connector: { name: 'x' } });
    assert.equal(status, 400);
    assert.equal(json.error.code, 'BAD_REQUEST');
  });

  it('rejects an import whose url embeds credentials (400, no insert)', async () => {
    state.blueprintExists = true;
    const { status, json } = await req('POST', '/c/import', {
      connector: { name: 'w', url: 'https://user:pass@svc/x', blueprint_id: 'bp-1', auth_type: 'none' },
    });
    assert.equal(status, 400);
    assert.equal(json.error.code, 'BAD_REQUEST');
    assert.equal(state.insertParams, null, 'a credential-bearing url must not INSERT');
  });

  it('rejects an import whose url host is off the egress allow-list (422, no insert)', async () => {
    state.blueprintExists = true;
    state.allowlistRow = JSON.stringify(['allowed.example.com']);
    const { status, json } = await req('POST', '/c/import', {
      connector: { name: 'w', url: 'http://blocked.example.net/x', blueprint_id: 'bp-1', auth_type: 'none' },
    });
    assert.equal(status, 422);
    assert.equal(json.error.code, 'EGRESS_BLOCKED');
    assert.equal(state.insertParams, null, 'an off-list import must not INSERT');
  });

  it('allows an import whose url host is on the egress allow-list (201)', async () => {
    state.blueprintExists = true;
    state.allowlistRow = JSON.stringify(['allowed.example.com']);
    const { status } = await req('POST', '/c/import', {
      connector: { name: 'w', url: 'http://allowed.example.com/x', blueprint_id: 'bp-1', auth_type: 'none' },
    });
    assert.equal(status, 201);
  });

  it('stamps status=approved on an admin import (approval lifecycle)', async () => {
    state.blueprintExists = true;
    const { status } = await req('POST', '/c/import', {
      connector: { name: 'w', url: 'http://svc', blueprint_id: 'bp-1', auth_type: 'none' },
    });
    assert.equal(status, 201);
    const upd = state.queries.find((q) => /UPDATE `fmb_api_connectors`/.test(q.sql) && /status='approved'/.test(q.sql));
    assert.ok(upd, 'an admin import must stamp status=approved');
  });

  it('stamps status=pending on an editor import (no auto-approve via import)', async () => {
    currentUser = { id: 'ed-1', role: 'editor', email: 'e@x' };
    state.blueprintExists = true;
    state.blueprintOwner = 'ed-1'; // editor owns the blueprint → import allowed
    const { status } = await req('POST', '/c/import', {
      connector: { name: 'w', url: 'http://svc', blueprint_id: 'bp-1', auth_type: 'none' },
    });
    assert.equal(status, 201);
    const upd = state.queries.find((q) => /UPDATE `fmb_api_connectors`/.test(q.sql) && /status='pending'/.test(q.sql));
    assert.ok(upd, 'an editor import must stamp status=pending, never NULL (= grandfathered approved)');
  });

  it('binds by a unique blueprint_path even when blueprint_id is foreign', async () => {
    state.nodes = [
      { id: 'g', parent_id: null, name: 'Gen A', node_type: 'generation' },
      { id: 'local-b1', parent_id: 'g', name: 'Mold', node_type: 'blueprint' },
    ];
    const { status } = await req('POST', '/c/import', {
      connector: {
        name: 'w', url: 'http://svc', auth_type: 'none',
        blueprint_id: 'foreign-uuid', blueprint_path: ['Gen A', 'Mold'],
      },
    });
    assert.equal(status, 201);
    assert.equal(state.insertParams[5], 'local-b1', 'path match must bind the LOCAL blueprint id');
  });

  it('stays unbound when blueprint_path matches more than one blueprint (ambiguous)', async () => {
    state.nodes = [
      { id: 'b1', parent_id: null, name: 'Mold', node_type: 'blueprint' },
      { id: 'b2', parent_id: null, name: 'Mold', node_type: 'blueprint' },
    ];
    const { status, json } = await req('POST', '/c/import', {
      connector: {
        name: 'w', url: 'http://svc', auth_type: 'none',
        blueprint_path: ['Mold'],
      },
    });
    assert.equal(status, 201);
    assert.equal(state.insertParams[5], null, 'ambiguous path must stay unbound');
    assert.equal(json.data.unbound, true);
  });

  it('stays unbound when no blueprint_path matches', async () => {
    state.nodes = [{ id: 'b1', parent_id: null, name: 'Other', node_type: 'blueprint' }];
    const { status, json } = await req('POST', '/c/import', {
      connector: { name: 'w', url: 'http://svc', auth_type: 'none', blueprint_path: ['Gone'] },
    });
    assert.equal(status, 201);
    assert.equal(state.insertParams[5], null);
    assert.equal(json.data.unbound, true);
  });

  it('falls back to the legacy id check when no blueprint_path is present', async () => {
    state.blueprintExists = true;
    const { status } = await req('POST', '/c/import', {
      connector: { name: 'w', url: 'http://svc', blueprint_id: 'bp-1', auth_type: 'none' },
    });
    assert.equal(status, 201);
    assert.equal(state.insertParams[5], 'bp-1', 'legacy id path still binds');
  });

  it('stores valid group fields verbatim on import', async () => {
    const { status } = await req('POST', '/c/import', {
      connector: {
        name: 'w', url: 'http://svc', auth_type: 'none',
        group_id: 'aabbccdd-0001-0002-0003-000400050006',
        group_label: 'Device Full Profile',
        group_mode: 'aggregation',
        sequence: 3,
      },
    });
    assert.equal(status, 201);
    // INSERT params: id,name,desc,is_active,owner,blueprint_id,method,url,
    //   auth_type,auth_config,request_config,response_config,dispatch_origin,
    //   group_id,group_label,group_mode,sequence
    const p = state.insertParams;
    assert.equal(p[13], 'aabbccdd-0001-0002-0003-000400050006', 'group_id preserved');
    assert.equal(p[14], 'Device Full Profile', 'group_label preserved');
    assert.equal(p[15], 'aggregation', 'group_mode preserved');
    assert.equal(p[16], 3, 'sequence preserved');
  });

  it('degrades to null group fields when group_id is not a valid UUID', async () => {
    const { status } = await req('POST', '/c/import', {
      connector: {
        name: 'w', url: 'http://svc', auth_type: 'none',
        group_id: 'not-a-uuid',
        group_label: 'Some Group',
        group_mode: 'aggregation',
        sequence: 1,
      },
    });
    assert.equal(status, 201);
    const p = state.insertParams;
    assert.strictEqual(p[13], null, 'group_id NULL on invalid uuid');
    assert.strictEqual(p[14], null, 'group_label NULL when group_id invalid');
    assert.strictEqual(p[15], null, 'group_mode NULL when group_id invalid');
    assert.strictEqual(p[16], null, 'sequence NULL when group_id invalid');
  });

  it('degrades to null group fields when group_mode is bogus', async () => {
    const { status } = await req('POST', '/c/import', {
      connector: {
        name: 'w', url: 'http://svc', auth_type: 'none',
        group_id: 'aabbccdd-0001-0002-0003-000400050006',
        group_label: 'Some Group',
        group_mode: 'bogus',
        sequence: 1,
      },
    });
    assert.equal(status, 201);
    const p = state.insertParams;
    assert.strictEqual(p[13], null);
    assert.strictEqual(p[14], null);
    assert.strictEqual(p[15], null);
    assert.strictEqual(p[16], null);
  });

  it('degrades to null group fields when sequence is negative', async () => {
    const { status } = await req('POST', '/c/import', {
      connector: {
        name: 'w', url: 'http://svc', auth_type: 'none',
        group_id: 'aabbccdd-0001-0002-0003-000400050006',
        group_label: 'Some Group',
        group_mode: 'chain',
        sequence: -3,
      },
    });
    assert.equal(status, 201);
    const p = state.insertParams;
    assert.strictEqual(p[13], null);
    assert.strictEqual(p[14], null);
    assert.strictEqual(p[15], null);
    assert.strictEqual(p[16], null);
  });

  it('truncates group_label to 255 chars but keeps other valid group fields', async () => {
    const longLabel = 'x'.repeat(300);
    const { status } = await req('POST', '/c/import', {
      connector: {
        name: 'w', url: 'http://svc', auth_type: 'none',
        group_id: 'aabbccdd-0001-0002-0003-000400050006',
        group_label: longLabel,
        group_mode: 'chain',
        sequence: 2,
      },
    });
    assert.equal(status, 201);
    const p = state.insertParams;
    assert.equal(p[13], 'aabbccdd-0001-0002-0003-000400050006', 'group_id preserved');
    assert.equal(p[14].length, 255, 'group_label truncated to 255');
    assert.equal(p[15], 'chain', 'group_mode preserved');
    assert.equal(p[16], 2, 'sequence preserved');
  });
});

describe('import blueprint-ownership guard', () => {
  beforeEach(() => { state.blueprintExists = true; });

  it('keeps the binding when an editor owns the resolved blueprint', async () => {
    currentUser = { id: 'ed-1', role: 'editor', email: 'e@x' };
    state.blueprintOwner = 'ed-1';
    const { status, json } = await req('POST', '/c/import', {
      connector: { name: 'x', url: 'http://svc/x', blueprint_id: 'bp-1' },
    });
    assert.equal(status, 201);
    assert.equal(json.data.unbound, false);
    assert.equal(state.insertParams[4], 'ed-1', 'owner_id stamped to importer');
    assert.equal(state.insertParams[5], 'bp-1', 'own blueprint binding kept');
  });

  it('keeps the binding when the resolved blueprint is shared (owner NULL)', async () => {
    currentUser = { id: 'ed-1', role: 'editor', email: 'e@x' };
    state.blueprintOwner = null;
    const { status, json } = await req('POST', '/c/import', {
      connector: { name: 'x', url: 'http://svc/x', blueprint_id: 'bp-1' },
    });
    assert.equal(status, 201);
    assert.equal(json.data.unbound, false);
    assert.equal(state.insertParams[5], 'bp-1', 'shared blueprint binding kept');
  });

  it('rejects an editor import bound to a foreign blueprint (403, no insert)', async () => {
    currentUser = { id: 'ed-1', role: 'editor', email: 'e@x' };
    state.blueprintOwner = 'someone-else';
    const { status, json } = await req('POST', '/c/import', {
      connector: { name: 'x', url: 'http://svc/x', blueprint_id: 'bp-1' },
    });
    assert.equal(status, 403);
    assert.equal(json.error.code, 'FORBIDDEN');
    assert.equal(state.insertParams, null, 'no INSERT may run for a foreign-blueprint editor import');
  });

  it('rejects an editor import with no blueprint in the payload (403, no insert)', async () => {
    currentUser = { id: 'ed-1', role: 'editor', email: 'e@x' };
    state.blueprintExists = false;
    const { status, json } = await req('POST', '/c/import', {
      connector: { name: 'x', url: 'http://svc/x' },
    });
    assert.equal(status, 403);
    assert.equal(json.error.code, 'FORBIDDEN');
    assert.equal(state.insertParams, null, 'editor cannot create an unbound connector');
  });

  it('rejects an editor import with an unknown blueprint_id (403, no insert)', async () => {
    currentUser = { id: 'ed-1', role: 'editor', email: 'e@x' };
    state.blueprintExists = false;
    const { status, json } = await req('POST', '/c/import', {
      connector: { name: 'x', url: 'http://svc/x', blueprint_id: 'bp-x' },
    });
    assert.equal(status, 403);
    assert.equal(json.error.code, 'FORBIDDEN');
    assert.equal(state.insertParams, null, 'unknown blueprint id resolves null → editor rejected');
  });

  it('lets an admin keep a foreign blueprint binding', async () => {
    state.blueprintOwner = 'someone-else';
    const { status } = await req('POST', '/c/import', {
      connector: { name: 'x', url: 'http://svc/x', blueprint_id: 'bp-1' },
    });
    assert.equal(status, 201);
    assert.equal(state.insertParams[5], 'bp-1', 'admin keeps any resolved binding');
  });

  it('lets an admin import with no blueprint as unbound (201)', async () => {
    state.blueprintExists = false;
    const { status, json } = await req('POST', '/c/import', {
      connector: { name: 'x', url: 'http://svc/x' },
    });
    assert.equal(status, 201);
    assert.strictEqual(state.insertParams[5], null, 'admin unbound import lands NULL blueprint');
    assert.equal(json.data.unbound, false, 'no binding wanted → not flagged unbound');
  });
});

describe('import chain validation', () => {
  it('rejects an editor import whose from_sequence is not earlier than its own sequence (400, no insert)', async () => {
    currentUser = { id: 'ed-1', role: 'editor', email: 'e@x' };
    state.blueprintExists = true;
    state.blueprintOwner = 'ed-1';
    const { status, json } = await req('POST', '/c/import', {
      connector: {
        name: 'w', url: 'http://svc', auth_type: 'none',
        blueprint_id: 'bp-1',
        sequence: 2,
        request_config: { input_from_step: [{ var: 'x', from_sequence: 2, path: 'a' }] },
      },
    });
    assert.equal(status, 400);
    assert.equal(json.error.code, 'BAD_REQUEST');
    assert.equal(state.insertParams, null, 'malformed chain must not insert');
  });

  it('accepts a valid earlier-step chain on import (201)', async () => {
    currentUser = { id: 'ed-1', role: 'editor', email: 'e@x' };
    state.blueprintExists = true;
    state.blueprintOwner = 'ed-1';
    // Chain wiring needs an effective stored sequence, which only persists with
    // a valid group; otherwise the group degrades to null and the wiring is
    // rejected for having no step position to reference from.
    const { status } = await req('POST', '/c/import', {
      connector: {
        name: 'w', url: 'http://svc', auth_type: 'none',
        blueprint_id: 'bp-1',
        group_id: 'aabbccdd-0001-0002-0003-000400050006',
        group_mode: 'chain',
        sequence: 2,
        request_config: { input_from_step: [{ var: 'x', from_sequence: 1, path: 'a' }] },
      },
    });
    assert.equal(status, 201);
  });

  it('rejects a non-array input_from_step on import (400, no insert)', async () => {
    currentUser = { id: 'ed-1', role: 'editor', email: 'e@x' };
    state.blueprintExists = true;
    state.blueprintOwner = 'ed-1';
    const { status, json } = await req('POST', '/c/import', {
      connector: {
        name: 'w', url: 'http://svc', auth_type: 'none',
        blueprint_id: 'bp-1',
        request_config: { input_from_step: 'garbage' },
      },
    });
    assert.equal(status, 400);
    assert.equal(json.error.code, 'BAD_REQUEST');
    assert.equal(state.insertParams, null);
  });

  it('rejects an admin import with the same malformed chain (400, not just editors)', async () => {
    const { status, json } = await req('POST', '/c/import', {
      connector: {
        name: 'w', url: 'http://svc', auth_type: 'none',
        blueprint_id: 'bp-1',
        sequence: 2,
        request_config: { input_from_step: [{ var: 'x', from_sequence: 2, path: 'a' }] },
      },
    });
    assert.equal(status, 400);
    assert.equal(json.error.code, 'BAD_REQUEST');
    assert.equal(state.insertParams, null);
  });

  it('rejects chain wiring when the group degrades so the stored sequence is null (400, no insert)', async () => {
    // Raw sequence is a valid number (2) and from_sequence (1) < it, so the
    // pre-degrade check would have passed; but the malformed group_id degrades
    // group fields to null, making the stored sequence null while chain wiring
    // stays — exactly the shape the invariant must reject.
    const { status, json } = await req('POST', '/c/import', {
      connector: {
        name: 'w', url: 'http://svc', auth_type: 'none',
        blueprint_id: 'bp-1',
        group_id: 'not-a-uuid',
        group_mode: 'chain',
        sequence: 2,
        request_config: { input_from_step: [{ var: 'x', from_sequence: 1, path: 'a' }] },
      },
    });
    assert.equal(status, 400);
    assert.equal(json.error.code, 'BAD_REQUEST');
    assert.equal(state.insertParams, null, 'degraded-sequence chain must not insert');
  });

  it('accepts chain wiring when the group is valid so the stored sequence holds (201)', async () => {
    const { status } = await req('POST', '/c/import', {
      connector: {
        name: 'w', url: 'http://svc', auth_type: 'none',
        blueprint_id: 'bp-1',
        group_id: 'aabbccdd-0001-0002-0003-000400050006',
        group_mode: 'chain',
        sequence: 2,
        request_config: { input_from_step: [{ var: 'x', from_sequence: 1, path: 'a' }] },
      },
    });
    assert.equal(status, 201);
    assert.ok(state.insertParams, 'valid group + chain must insert');
  });
});

describe('import role gate (plain user)', () => {
  it('rejects a plain user GET export with 403', async () => {
    currentUser = { id: 'u-1', role: 'user', email: 'u@x' };
    state.exportRow = {
      name: 'x', description: null, is_active: 1,
      blueprint_id: null, method: 'GET', url: 'http://svc/x',
      auth_type: 'none', auth_config: null,
      request_config: null, response_config: null,
    };
    const { status, json } = await req('GET', '/c/abc/export');
    assert.equal(status, 403);
    assert.equal(json.error.code, 'FORBIDDEN');
  });

  it('rejects a plain user POST import with 403', async () => {
    currentUser = { id: 'u-1', role: 'user', email: 'u@x' };
    const { status, json } = await req('POST', '/c/import', {
      connector: { name: 'x', url: 'http://svc/x', blueprint_id: 'bp-1' },
    });
    assert.equal(status, 403);
    assert.equal(json.error.code, 'FORBIDDEN');
    assert.equal(state.insertParams, null, 'plain user import must not insert');
  });
});

describe('GET /:id/export (group fields)', () => {
  it('includes group fields in the export payload', async () => {
    state.exportRow = {
      name: 'grouped-conn', description: null, is_active: 1,
      blueprint_id: null, method: 'GET', url: 'http://svc/x',
      auth_type: 'none', auth_config: null,
      request_config: null, response_config: null,
      group_id: 'aabbccdd-0001-0002-0003-000400050006',
      group_label: 'Device Full Profile',
      group_mode: 'aggregation',
      sequence: 2,
    };
    const { status, json } = await req('GET', '/c/abc/export');
    assert.equal(status, 200);
    assert.equal(json.data.group_id, 'aabbccdd-0001-0002-0003-000400050006');
    assert.equal(json.data.group_label, 'Device Full Profile');
    assert.equal(json.data.group_mode, 'aggregation');
    assert.equal(json.data.sequence, 2);
  });

  it('exports group fields as null for an ungrouped connector', async () => {
    state.exportRow = {
      name: 'ungrouped', description: null, is_active: 1,
      blueprint_id: null, method: 'GET', url: 'http://svc/x',
      auth_type: 'none', auth_config: null,
      request_config: null, response_config: null,
      group_id: null, group_label: null, group_mode: null, sequence: null,
    };
    const { status, json } = await req('GET', '/c/abc/export');
    assert.equal(status, 200);
    assert.strictEqual(json.data.group_id, null);
    assert.strictEqual(json.data.group_label, null);
    assert.strictEqual(json.data.group_mode, null);
    assert.strictEqual(json.data.sequence, null);
  });
});

describe('timeout_ms cross-env carry', () => {
  const exportRow = () => ({
    name: 'w', description: null, is_active: 1, blueprint_id: null,
    method: 'GET', url: 'http://svc/x', auth_type: 'none', auth_config: null,
    request_config: null, response_config: null,
    group_id: null, group_label: null, group_mode: null, sequence: null,
  });

  it('export carries the source timeout_ms when present', async () => {
    state.exportRow = exportRow();
    state.timeoutRow = 30000;
    const { status, json } = await req('GET', '/c/abc/export');
    assert.equal(status, 200);
    assert.equal(json.data.timeout_ms, 30000);
  });

  it('export degrades to timeout_ms=null when the source lacks the column (no-ALTER)', async () => {
    state.exportRow = exportRow();
    state.failTimeoutProbe = true;
    const { status, json } = await req('GET', '/c/abc/export');
    assert.equal(status, 200, 'a missing timeout_ms column must not fail the export');
    assert.strictEqual(json.data.timeout_ms, null);
  });

  it('import applies an in-range timeout_ms via a best-effort UPDATE', async () => {
    state.blueprintExists = true;
    const { status } = await req('POST', '/c/import', {
      connector: { name: 'w', url: 'http://svc', blueprint_id: 'bp-1', auth_type: 'none', timeout_ms: 30000 },
    });
    assert.equal(status, 201);
    const upd = state.queries.find((q) => /UPDATE `fmb_api_connectors` SET timeout_ms = \?/.test(q.sql));
    assert.ok(upd, 'import must issue the timeout carry UPDATE');
    assert.equal(upd.params[0], 30000);
  });

  it('import ignores an out-of-range timeout_ms (no UPDATE)', async () => {
    state.blueprintExists = true;
    const { status } = await req('POST', '/c/import', {
      connector: { name: 'w', url: 'http://svc', blueprint_id: 'bp-1', auth_type: 'none', timeout_ms: 999999 },
    });
    assert.equal(status, 201);
    const upd = state.queries.find((q) => /UPDATE `fmb_api_connectors` SET timeout_ms = \?/.test(q.sql));
    assert.equal(upd, undefined, 'an out-of-range timeout must not be written');
  });

  it('import still succeeds when the target lacks timeout_ms (no-ALTER DB)', async () => {
    state.blueprintExists = true;
    state.failTimeoutImport = true;
    const { status } = await req('POST', '/c/import', {
      connector: { name: 'w', url: 'http://svc', blueprint_id: 'bp-1', auth_type: 'none', timeout_ms: 30000 },
    });
    assert.equal(status, 201, 'a missing timeout_ms column must not fail the import');
  });
});
