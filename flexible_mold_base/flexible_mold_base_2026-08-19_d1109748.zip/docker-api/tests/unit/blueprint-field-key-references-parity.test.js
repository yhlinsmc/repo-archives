/**
 * blueprint-field-key-references-parity.test.js — the declaration of where a
 * `blueprint_fields` row names another field by key, checked against the ACTUAL
 * DDL without a live DB.
 *
 * The rename builds its cascade from this declaration and every other test on
 * that path runs against a stubbed connection, which answers a column that does
 * not exist exactly as happily as one that does. So the names are pinned to
 * table-ddls.js here.
 *
 * The assertion that matters most is the CLOSED-WORLD one at the bottom. Asking
 * "is what the declaration claims true?" is answered vacuously by a reference
 * that is MISSING from the declaration — which is the miss that actually
 * happens, and the miss that produced this work: the list of references was
 * written from a review comment, named a path that has never existed, and would
 * have passed every check that starts from the list. This one starts from the
 * schema instead.
 */
const { describe, it, before } = require('node:test');
const assert = require('node:assert/strict');

const { buildSchemaManifest } = require('../../src/edge/lib/schema-manifest');
const {
  BLUEPRINT_FIELD_KEY_REFERENCES,
  BLUEPRINT_FIELD_KEY_REFERENCE_COLUMNS,
  UNREWRITABLE_KEY_REFERENCE_SITES,
  SAFE_JSON_PATH_RE,
  fieldKeyReferencesPresentIn,
} = require('../../src/edge/lib/blueprint-field-key-references');

// A field key is a string, so only a column that can hold a string can hold a
// reference to one. Numeric, boolean and time columns are outside the closed
// world below because no spelling of a field key fits in them.
const KEY_CAPABLE_TYPES = new Set([
  'char', 'varchar', 'tinytext', 'text', 'mediumtext', 'longtext', 'json', 'enum',
]);

// The other side of the classification: string-capable `blueprint_fields`
// columns that do NOT hold a rewritable reference to another field's key, each
// with the reason. An explicit list rather than an exclusion rule, so a NEW
// column cannot land in it by accident — the test below requires every
// string-capable column to appear in exactly one of the two sets.
const NOT_A_REWRITABLE_REFERENCE = new Map([
  ['id', 'a row id, not a key'],
  ['blueprint_id', 'a hierarchy_nodes id, not a field key'],
  [
    'field_key',
    'the field\'s OWN key, which the write this cascade rides along with already '
    + 'sets. Declaring it here would rename the field twice — and the second '
    + 'statement matches on the OLD key, which by then is gone.',
  ],
  ['field_label', 'display text an operator types; never resolved against the field list'],
  ['field_type', 'a type name from a closed vocabulary'],
  ['default_value', 'a value for THIS field, not the name of another'],
  ['placeholder', 'display text'],
  ['tooltip', 'display text'],
  ['section', 'a blueprint_sections.section_key — a different namespace'],
  ['group_key', 'a blueprint_groups.group_key — a different namespace, cascaded by its own rename'],
  ['matrix_row_key', 'a blueprint_groups.group_key — same namespace as group_key, same cascade'],
  [
    'table_config',
    'the COLUMN keys of this field\'s own table, which are scoped to the field and '
    + 'are not field keys',
  ],
  ['choice_config', 'selection counts ({minSelected, maxSelected}); holds no key at all'],
  ['value_source', 'a mode name from a closed vocabulary'],
  [
    'value_scope',
    'row indices and table-column keys of THIS field ({rows, columns}), the same '
    + 'document variant_overrides.cell_targets holds',
  ],
  [
    'compute_rule',
    'NAMES OTHER FIELDS, but not at one fixed path: the keys sit at config.source, '
    + 'config.parts[].key, config.operands[].key and cell.table_key depending on the '
    + 'rule\'s op, several of them inside arrays. Rewriting them needs a '
    + 'read-modify-write per row that understands each variant, not a JSON_SET — a '
    + 'separate piece of work, deliberately not smuggled into this declaration.',
  ],
]);

let entry;

before(() => {
  const manifest = buildSchemaManifest((base) => base);
  entry = manifest.get('blueprint_fields');
  assert.ok(entry, 'table-ddls.js does not create blueprint_fields');
});

describe('blueprint_fields key references <-> table-ddls parity', () => {
  it('every declared reference column is a real column', () => {
    const columns = new Set(entry.columns);
    const missing = BLUEPRINT_FIELD_KEY_REFERENCE_COLUMNS.filter((c) => !columns.has(c));
    assert.deepEqual(missing, [], `declared reference columns absent from the DDL: ${missing.join(', ')}`);
  });

  it('a column-shaped reference is declared on a column that can hold a key', () => {
    // A reference stored AS the column has to fit a whole field key, or the
    // rename writes a value the column truncates — a reference silently
    // repointed at a key nobody has.
    const fieldKeyType = entry.columnMeta.get('field_key').type;
    const declaredWidth = Number(/\((\d+)\)/.exec(fieldKeyType)[1]);
    for (const site of BLUEPRINT_FIELD_KEY_REFERENCES) {
      if (site.path !== null) continue;
      const type = entry.columnMeta.get(site.column).type;
      const width = /\((\d+)\)/.exec(type);
      assert.ok(width, `cannot read a width from ${site.column} (${type})`);
      assert.ok(
        Number(width[1]) >= declaredWidth,
        `${site.column} is ${type} but a field key may be ${declaredWidth} characters`,
      );
    }
  });

  it('a document-shaped reference is declared on a column that can hold a document', () => {
    for (const site of BLUEPRINT_FIELD_KEY_REFERENCES) {
      if (site.path === null) continue;
      const type = String(entry.columnMeta.get(site.column).type).replace(/\(.*/, '');
      assert.ok(
        ['text', 'mediumtext', 'longtext', 'json'].includes(type),
        `${site.column} is declared ${type}, which cannot hold a JSON document`,
      );
    }
  });

  it('every declared JSON path names a shape MariaDB will accept', () => {
    // STATED HERE RATHER THAN IMPORTED, and that is the point of the assertion.
    // Checking the declared paths against the module's own regex compares a
    // value with the rule that value is written to satisfy: the pair can be
    // edited together forever and this test cannot notice. An independent
    // second reader is what makes it mean anything — measured, not argued: with
    // the imported regex, loosening the builder to `/^\$.*$/` and declaring
    // `$."field_key"[0]` leaves this green; with the literal below it goes red.
    const ACCEPTED_PATH_SHAPE = /^\$(\."[a-z][a-z0-9_]*")+$/;
    for (const site of BLUEPRINT_FIELD_KEY_REFERENCES) {
      if (site.path === null) continue;
      assert.match(site.path, ACCEPTED_PATH_SHAPE, `bad JSON path: ${site.path}`);
    }
  });

  it('the builder refuses the shapes that rule refuses', () => {
    // The other half of the same drift, from the builder's side: the declaration
    // could stay conservative while the check that guards it is widened to
    // accept anything. Each of these is a path MariaDB would read as something
    // other than a plain object member — an array subscript, a wildcard, a
    // quote-terminated expression — and the builder must keep refusing them
    // whatever the current declaration happens to contain.
    for (const path of [
      '$."field_key"[0]',
      '$.*',
      '$**."field_key"',
      '$."field_key"."a"[*]',
      '$."field key"',
      '$."field_key" OR 1=1',
      '$."Field_Key"',
      '$',
      '',
    ]) {
      assert.doesNotMatch(path, SAFE_JSON_PATH_RE, `the builder would accept ${JSON.stringify(path)}`);
    }
    for (const site of BLUEPRINT_FIELD_KEY_REFERENCES) {
      if (site.path === null) continue;
      assert.match(site.path, SAFE_JSON_PATH_RE, `the builder refuses its own declaration: ${site.path}`);
    }
  });

  it('a site is either a column or a path, never both and never neither', () => {
    for (const site of BLUEPRINT_FIELD_KEY_REFERENCES) {
      assert.equal(typeof site.column, 'string');
      assert.ok(site.path === null || typeof site.path === 'string');
    }
    assert.deepEqual(
      BLUEPRINT_FIELD_KEY_REFERENCE_COLUMNS,
      BLUEPRINT_FIELD_KEY_REFERENCES.map((s) => s.column),
    );
  });

  it('the column-set gate keeps every site when the probe could not tell', () => {
    // A null probe means "could not read information_schema", not "the columns
    // are absent" — dropping the sites there would turn an unreadable schema
    // into a rename that silently repairs nothing.
    assert.deepEqual(fieldKeyReferencesPresentIn(null), [...BLUEPRINT_FIELD_KEY_REFERENCES]);
    assert.deepEqual(fieldKeyReferencesPresentIn(undefined), [...BLUEPRINT_FIELD_KEY_REFERENCES]);
    assert.deepEqual(fieldKeyReferencesPresentIn(new Set()), []);
    assert.deepEqual(
      fieldKeyReferencesPresentIn(new Set(['visibility_rule'])).map((s) => s.column),
      ['visibility_rule'],
    );
  });
});

describe('blueprint_fields string columns are all classified', () => {
  // Bound worth stating: this covers columns of THIS table. A reference to a
  // field key stored on another table is outside what it can see — and there
  // are such references (variant_overrides.compute_rule, decision_tables.doc,
  // api_connectors.request_config/response_config), every one of them in the
  // non-rewritable shape compute_rule is excluded for above.
  it('every string-capable column is either a declared reference or explicitly not one', () => {
    const declared = new Set(BLUEPRINT_FIELD_KEY_REFERENCE_COLUMNS);
    const unclassified = [];
    const doubleClassified = [];

    for (const column of entry.columns) {
      const meta = entry.columnMeta.get(column);
      const bareType = String(meta?.type || '').replace(/\(.*/, '').trim();
      if (!KEY_CAPABLE_TYPES.has(bareType)) continue;
      const isReference = declared.has(column);
      const isExcluded = NOT_A_REWRITABLE_REFERENCE.has(column);
      if (isReference && isExcluded) doubleClassified.push(column);
      if (!isReference && !isExcluded) unclassified.push(`${column} (${bareType})`);
    }

    assert.deepEqual(
      unclassified, [],
      `unclassified string column(s) on blueprint_fields: ${unclassified.join(', ')}. `
      + 'If the column holds another field\'s key at a fixed place, add it to '
      + 'BLUEPRINT_FIELD_KEY_REFERENCES so the field rename follows it. If it does not, '
      + 'add it to NOT_A_REWRITABLE_REFERENCE in this test with the reason.',
    );
    assert.deepEqual(doubleClassified, [], `classified both ways: ${doubleClassified.join(', ')}`);
  });

  it('the not-a-reference list names only columns that exist', () => {
    const columns = new Set(entry.columns);
    const stale = [...NOT_A_REWRITABLE_REFERENCE.keys()].filter((c) => !columns.has(c));
    assert.deepEqual(stale, [], `listed as not-a-reference but gone from the DDL: ${stale.join(', ')}`);
  });

  it('the operator-facing exclusion list still names the one this table can see', () => {
    // The rename's log line carries UNREWRITABLE_KEY_REFERENCE_SITES so an
    // operator is not told the references were repointed when some were not.
    // A list nothing checks is a list that goes empty in a tidy-up and takes the
    // caveat with it, silently. This test can only vouch for the entry that is a
    // column of THIS table — `compute_rule`, excluded above for exactly the
    // reason the list exists — and that is the one it pins.
    assert.ok(
      UNREWRITABLE_KEY_REFERENCE_SITES.includes('blueprint_fields.compute_rule'),
      'compute_rule is excluded from the cascade but no longer declared to the operator',
    );
    assert.ok(
      NOT_A_REWRITABLE_REFERENCE.has('compute_rule'),
      'compute_rule left the not-a-reference list, so the line above pins nothing',
    );
  });
});
