const { test, afterEach } = require('node:test');
const assert = require('node:assert/strict');

const dbPath = require.resolve('../../src/edge/db');
const routePath = require.resolve('../../src/edge/routes/platform/feature-audit');

function clearCache() {
  delete require.cache[dbPath];
  delete require.cache[routePath];
}

afterEach(clearCache);

// Load the feature-audit router with a stubbed db module (pool.ro + t). The
// query stub receives (sql, params) for every conn.query call and returns
// whatever the test wants; calls are recorded for assertions.
function loadRouter(queryStub) {
  clearCache();
  const dbModule = require('../../src/edge/db');
  Object.assign(dbModule, {
    t: (name) => `app_${name}`,
    pool: {
      ro: {
        async getConnection() {
          return {
            async query(sql, params) { return queryStub(sql, params); },
            release() {},
          };
        },
      },
    },
  });
  return require('../../src/edge/routes/platform/feature-audit');
}

function getHandler(router, method, routePathStr) {
  for (const layer of router.stack) {
    if (layer.route
        && layer.route.path === routePathStr
        && layer.route.methods[method]) {
      const stack = layer.route.stack;
      return stack[stack.length - 1].handle;
    }
  }
  throw new Error(`handler not found: ${method} ${routePathStr}`);
}

function makeReq(query) {
  return { query: query || {}, user: { id: 'admin-1', role: 'admin' } };
}

function makePostReq(body) {
  return { body: body || {}, user: { id: 'admin-1', role: 'admin' } };
}

function makeRes() {
  return {
    statusCode: 200,
    body: null,
    status(code) { this.statusCode = code; return this; },
    json(body) { this.body = body; return this; },
  };
}

test('GET /event-types returns distinct present types and queries only readable ones', async () => {
  const calls = [];
  const router = loadRouter((sql, params) => {
    calls.push({ sql, params });
    return [
      { event_type: 'schema_migration.variant_override_invalid_action_cleanup' },
      { event_type: 'transformer.execute.fail' },
      { event_type: 'data_clear.blocked_by_fk' },
    ];
  });
  const handler = getHandler(router, 'get', '/event-types');

  const res = makeRes();
  await handler(makeReq(), res);

  assert.equal(res.statusCode, 200);
  // Each present type carries a backend-authored severity (single source) so
  // the dashboard renders colour without guessing from the type string.
  assert.deepEqual(res.body.data.event_types, [
    { type: 'schema_migration.variant_override_invalid_action_cleanup', severity: 'info' },
    { type: 'transformer.execute.fail', severity: 'error' },
    { type: 'data_clear.blocked_by_fk', severity: 'warning' },
  ]);

  assert.equal(calls.length, 1);
  assert.match(calls[0].sql, /SELECT DISTINCT event_type/i);
  assert.match(calls[0].sql, /WHERE event_type IN \(/i);
  // Placeholder count must equal the bound-param count (no interpolation).
  const placeholders = (calls[0].sql.match(/\?/g) || []).length;
  assert.equal(placeholders, calls[0].params.length);
  // The variant_override cleanup events must be in the readable allowlist now
  // (SYSTEM_EVENT_TYPES addition) — otherwise they could never be filtered.
  assert.ok(
    calls[0].params.includes('schema_migration.variant_override_invalid_action_cleanup'),
    'invalid_action_cleanup must be a readable (filterable) event type',
  );
  assert.ok(
    calls[0].params.includes('schema_migration.variant_override_null_action_cleanup'),
    'null_action_cleanup must be a readable (filterable) event type',
  );
  assert.ok(
    calls[0].params.includes('schema_migration.blueprint_groups_dedup'),
    'blueprint_groups_dedup must be a readable (filterable) event type',
  );
  assert.ok(
    calls[0].params.includes('schema_migration.blueprint_sections_dedup'),
    'blueprint_sections_dedup must be a readable (filterable) event type',
  );
});

test('GET / combines event_type filter and q search with ANDed parameterized clauses', async () => {
  const calls = [];
  const router = loadRouter((sql, params) => {
    calls.push({ sql, params });
    // First call = SELECT events, second = COUNT.
    if (/COUNT\(/i.test(sql)) return [{ cnt: 0 }];
    return [];
  });
  const handler = getHandler(router, 'get', '/');

  const res = makeRes();
  await handler(makeReq({ event_type: 'draft.saved', q: 'widget' }), res);

  assert.equal(res.statusCode, 200);
  assert.equal(calls.length, 2);

  const select = calls[0];
  // Pin call order explicitly: the row SELECT must run first, the COUNT second.
  // The stub discriminates on /COUNT\(/, so without this a flipped impl order
  // could otherwise slip past (the shared WHERE matches both queries).
  assert.ok(!/COUNT\(/i.test(select.sql), 'first query must be the row SELECT, not COUNT');
  assert.match(select.sql, /WHERE event_type = \? AND \(event_type LIKE \? ESCAPE '\|' OR metadata LIKE \? ESCAPE '\|' OR user_id LIKE \? ESCAPE '\|'\)/i);
  // params: event_type, like x3, then limit + offset.
  assert.deepEqual(select.params.slice(0, 4), [
    'draft.saved', '%widget%', '%widget%', '%widget%',
  ]);

  // COUNT shares the same WHERE + the four filter params, no limit/offset.
  const count = calls[1];
  assert.match(count.sql, /SELECT COUNT\(/i);
  assert.deepEqual(count.params, ['draft.saved', '%widget%', '%widget%', '%widget%']);
});

test('GET / escapes LIKE metacharacters in q so % and _ match literally', async () => {
  const calls = [];
  const router = loadRouter((sql, params) => {
    calls.push({ sql, params });
    if (/COUNT\(/i.test(sql)) return [{ cnt: 0 }];
    return [];
  });
  const handler = getHandler(router, 'get', '/');

  const res = makeRes();
  await handler(makeReq({ q: '50%_|x' }), res);

  assert.equal(res.statusCode, 200);
  // % _ and the escape char | itself are escaped with a leading | inside the
  // %…% wrap; the SQL pairs this with an explicit ESCAPE '|' clause so it is
  // correct under the NO_BACKSLASH_ESCAPES sql_mode too.
  assert.equal(calls[0].params[0], '%50|%|_||x%');
  assert.match(calls[0].sql, /LIKE \? ESCAPE '\|'/);
});

test('GET / rejects an unknown event_type with 400 before searching', async () => {
  let queried = false;
  const router = loadRouter(() => { queried = true; return []; });
  const handler = getHandler(router, 'get', '/');

  const res = makeRes();
  await handler(makeReq({ event_type: 'not.a.real.event' }), res);

  assert.equal(res.statusCode, 400);
  assert.equal(queried, false, 'must reject before opening a connection / querying');
});

// Codex P2: blueprint_group.rename is server-authored only (a direct in-tx
// INSERT from schema.js rename-with-cascade, never through this router) — it
// must stay OUT of the client-writable set so an admin cannot POST a forged
// rename row with arbitrary metadata, while remaining readable/filterable
// via GET (it lives in SYSTEM_EVENT_TYPES, same trust tier as schema_migration.*).
test('POST / rejects blueprint_group.rename (server-only event) with 400 before writing', async () => {
  let queried = false;
  const router = loadRouter(() => { queried = true; return []; });
  const handler = getHandler(router, 'post', '/');

  const res = makeRes();
  await handler(makePostReq({ event_type: 'blueprint_group.rename', metadata: { forged: true } }), res);

  assert.equal(res.statusCode, 400);
  assert.equal(res.body.error.code, 'BAD_REQUEST');
  assert.equal(queried, false, 'must reject before opening a connection / writing');
});

// blueprint.field.compute_rule_cleared is written in the same transaction as
// the schema edit that dropped the rule, never through this router. It must be
// filterable (otherwise the record of a value the operator did not ask to lose
// is unreachable in the dashboard) but never client-writable.
test('blueprint.field.compute_rule_cleared is readable/filterable but not POSTable', async () => {
  const listRouter = loadRouter(() => [{ event_type: 'blueprint.field.compute_rule_cleared' }]);
  const typesRes = makeRes();
  await getHandler(listRouter, 'get', '/event-types')(makeReq(), typesRes);
  assert.deepEqual(typesRes.body.data.event_types, [
    { type: 'blueprint.field.compute_rule_cleared', severity: 'warning' },
  ]);

  const filterRes = makeRes();
  await getHandler(listRouter, 'get', '/')(
    makeReq({ event_type: 'blueprint.field.compute_rule_cleared' }), filterRes,
  );
  assert.equal(filterRes.statusCode, 200);

  let queried = false;
  const postRouter = loadRouter(() => { queried = true; return []; });
  const postRes = makeRes();
  await getHandler(postRouter, 'post', '/')(
    makePostReq({ event_type: 'blueprint.field.compute_rule_cleared', metadata: { forged: true } }),
    postRes,
  );
  assert.equal(postRes.statusCode, 400);
  assert.equal(queried, false, 'must reject before opening a connection / writing');
});
