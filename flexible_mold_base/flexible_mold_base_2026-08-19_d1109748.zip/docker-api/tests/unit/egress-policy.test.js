'use strict';

const { test } = require('node:test');
const assert = require('node:assert');
const {
  normalizePathForMatch,
  resolveDotSegments,
  normalizePolicy,
  egressAllowed,
  loadEgressPolicy,
  loadEgressDefaultDeny,
  egressAllowedForUrl,
  EGRESS_DEFAULT_DENY_KEY,
} = require('../../src/shared/lib/egress-policy');
const { ALLOWLIST_KEY } = require('../../src/shared/lib/host-allowlist');

// ---------------------------------------------------------------------------
// resolveDotSegments — canonical form + escape detection (defence in depth;
// WHATWG URL already clamps `..` at root, this is the raw-string guard).
// ---------------------------------------------------------------------------
test('resolveDotSegments canonicalises and detects root escape', () => {
  assert.equal(resolveDotSegments('/a/b/../c'), '/a/c');
  assert.equal(resolveDotSegments('/a/./b'), '/a/b');
  assert.equal(resolveDotSegments('/a//b///c'), '/a/b/c'); // collapse duplicate slashes
  assert.equal(resolveDotSegments('/a/b/'), '/a/b'); // strip trailing slash
  assert.equal(resolveDotSegments('/'), '/');
  assert.equal(resolveDotSegments('/..'), null); // escapes root
  assert.equal(resolveDotSegments('/a/../..'), null);
});

// ---------------------------------------------------------------------------
// normalizePathForMatch — URL-sourced, with traversal hardening.
// ---------------------------------------------------------------------------
test('normalizePathForMatch blocks encoded slash/backslash', () => {
  assert.equal(normalizePathForMatch('https://h/a%2f..%2fb'), null);
  assert.equal(normalizePathForMatch('https://h/a%2Fb'), null);
  assert.equal(normalizePathForMatch('https://h/a%5cb'), null);
});

test('normalizePathForMatch blocks an unparseable URL', () => {
  assert.equal(normalizePathForMatch('not a url'), null);
});

test('normalizePathForMatch clamps dot-segments at root (no escape past /)', () => {
  // WHATWG URL resolves+clamps `..`, so a traversal can only land at-or-below root.
  assert.equal(normalizePathForMatch('https://h/a/../../etc'), '/etc');
  assert.equal(normalizePathForMatch('https://h/%2e%2e/x'), '/x');
  assert.equal(normalizePathForMatch('https://h/public/../admin'), '/admin');
});

test('normalizePathForMatch canonicalises trailing/duplicate slashes; query ignored', () => {
  assert.equal(normalizePathForMatch('https://h/a/./b//c/'), '/a/b/c');
  assert.equal(normalizePathForMatch('https://h/api/v1?x=1#frag'), '/api/v1');
  assert.equal(normalizePathForMatch('https://h'), '/');
});

// ---------------------------------------------------------------------------
// normalizePolicy — legacy upgrade, new shape, fail-closed on corrupt.
// ---------------------------------------------------------------------------
test('normalizePolicy: absent/empty → allow-all ([])', () => {
  assert.deepEqual(normalizePolicy(null), []);
  assert.deepEqual(normalizePolicy([]), []);
});

test('normalizePolicy: legacy host strings → any method, any path', () => {
  assert.deepEqual(normalizePolicy(['api.x.com', '*.y.com']), [
    { hosts: ['api.x.com'], rules: [{ method: ['*'], path: ['/**'] }] },
    { hosts: ['*.y.com'], rules: [{ method: ['*'], path: ['/**'] }] },
  ]);
});

test('normalizePolicy: new shape normalises hosts string→array and uppercases methods', () => {
  const out = normalizePolicy([
    { hosts: 'api.x.com', rules: [{ method: ['get', 'post'], path: ['/api/v1/*'] }] },
  ]);
  assert.deepEqual(out, [
    { hosts: ['api.x.com'], protocols: null, rules: [{ method: ['GET', 'POST'], path: ['/api/v1/*'] }] },
  ]);
});

test('normalizePolicy: protocols normalised (lowercased, deduped, garbage→null)', () => {
  const out = normalizePolicy([
    { hosts: 'a.com', protocols: ['HTTPS', 'https'], rules: [{ method: ['*'], path: ['/**'] }] },
    { hosts: 'b.com', protocols: ['ftp', 123], rules: [{ method: ['*'], path: ['/**'] }] },
    { hosts: 'c.com', rules: [{ method: ['*'], path: ['/**'] }] },
  ]);
  assert.deepEqual(out[0].protocols, ['https']); // lowercased + deduped
  assert.equal(out[1].protocols, null);          // all-garbage → null (any)
  assert.equal(out[2].protocols, null);          // absent → null (grandfathered)
});

// scheme gate — http/https enforcement, with grandfathering.
const schemePolicy = normalizePolicy([
  { hosts: 'secure.example.com', protocols: ['https'], rules: [{ method: ['*'], path: ['/**'] }] },
  { hosts: 'both.example.com', protocols: ['http', 'https'], rules: [{ method: ['*'], path: ['/**'] }] },
  { hosts: 'plain.example.com', protocols: ['http'], rules: [{ method: ['*'], path: ['/**'] }] },
  { hosts: 'legacy.example.com', rules: [{ method: ['*'], path: ['/**'] }] },
]);

test('egressAllowed scheme: https-only entry blocks http with reason protocol', () => {
  assert.equal(egressAllowed('https://secure.example.com/x', 'GET', schemePolicy).ok, true);
  assert.deepEqual(egressAllowed('http://secure.example.com/x', 'GET', schemePolicy), { ok: false, reason: 'protocol' });
});

test('egressAllowed scheme: http+https entry admits both', () => {
  assert.equal(egressAllowed('https://both.example.com/x', 'GET', schemePolicy).ok, true);
  assert.equal(egressAllowed('http://both.example.com/x', 'GET', schemePolicy).ok, true);
});

test('egressAllowed scheme: http-only entry blocks https', () => {
  assert.equal(egressAllowed('http://plain.example.com/x', 'GET', schemePolicy).ok, true);
  assert.deepEqual(egressAllowed('https://plain.example.com/x', 'GET', schemePolicy), { ok: false, reason: 'protocol' });
});

test('egressAllowed scheme: legacy entry without protocols is grandfathered (any scheme)', () => {
  assert.equal(egressAllowed('https://legacy.example.com/x', 'GET', schemePolicy).ok, true);
  assert.equal(egressAllowed('http://legacy.example.com/x', 'GET', schemePolicy).ok, true);
});

test('egressAllowed scheme: an exotic scheme on a restricted host is blocked, not slipped through', () => {
  // gopher:// parses a hostname but the scheme is not in the entry's allow-list.
  assert.deepEqual(egressAllowed('gopher://secure.example.com/x', 'GET', schemePolicy), { ok: false, reason: 'protocol' });
});

test('normalizePolicy: fail-closed on corrupt values', () => {
  assert.throws(() => normalizePolicy('nope'), /not a JSON array/);
  assert.throws(() => normalizePolicy({ hosts: 'x' }), /not a JSON array/);
  assert.throws(() => normalizePolicy([123]), /mixes host strings and rule objects/); // neither all-string nor all-object
  assert.throws(() => normalizePolicy(['', '  ']), /none are usable host strings/);
  assert.throws(() => normalizePolicy([{}]), /none are usable/); // object with no hosts
  assert.throws(() => normalizePolicy(['ok.com', { hosts: 'x' }]), /mixes host strings and rule objects/);
});

// ---------------------------------------------------------------------------
// egressAllowed — the decision.
// ---------------------------------------------------------------------------
const policy = normalizePolicy([
  { hosts: 'api.example.com', rules: [
    { method: ['GET'], path: ['/api/v1/*', '/api/status'] },
    { method: ['GET', 'POST'], path: ['/api/v1/data'] },
  ] },
  { hosts: '*.internal.example.com', rules: [
    { method: ['*'], path: ['/public/**'] },
  ] },
]);

test('egressAllowed: empty policy = allow-all', () => {
  assert.deepEqual(egressAllowed('https://anything.com/x', 'DELETE', []), { ok: true });
});

test('egressAllowed: host + method + path all match', () => {
  assert.deepEqual(egressAllowed('https://api.example.com/api/v1/foo', 'GET', policy), { ok: true });
  assert.deepEqual(egressAllowed('https://api.example.com/api/status', 'GET', policy), { ok: true });
  assert.deepEqual(egressAllowed('https://api.example.com/api/v1/data', 'POST', policy), { ok: true });
});

test('egressAllowed: single * does not cross a slash', () => {
  // /api/v1/* matches /api/v1/foo but not /api/v1/foo/bar
  assert.equal(egressAllowed('https://api.example.com/api/v1/foo/bar', 'GET', policy).ok, false);
});

test('egressAllowed: ** matches any depth incl. the base', () => {
  assert.deepEqual(egressAllowed('https://a.internal.example.com/public', 'PUT', policy), { ok: true });
  assert.deepEqual(egressAllowed('https://a.internal.example.com/public/a/b/c', 'DELETE', policy), { ok: true });
});

test('egressAllowed: method wildcard * admits any method', () => {
  assert.equal(egressAllowed('https://a.internal.example.com/public/x', 'PATCH', policy).ok, true);
});

test('egressAllowed: reasons — host / method / path / normalize', () => {
  assert.deepEqual(egressAllowed('https://other.com/x', 'GET', policy), { ok: false, reason: 'host' });
  // host+path match but method does not (POST on a GET-only /api/status)
  assert.deepEqual(egressAllowed('https://api.example.com/api/status', 'POST', policy), { ok: false, reason: 'method' });
  // host matches, path matches nothing
  assert.deepEqual(egressAllowed('https://api.example.com/nope', 'GET', policy), { ok: false, reason: 'path' });
  // encoded slash → normalize block
  assert.deepEqual(egressAllowed('https://api.example.com/api%2fv1', 'GET', policy), { ok: false, reason: 'normalize' });
});

test('egressAllowed: method match is case-insensitive on input', () => {
  assert.equal(egressAllowed('https://api.example.com/api/status', 'get', policy).ok, true);
});

// ---------------------------------------------------------------------------
// loadEgressPolicy / egressAllowedForUrl — DB-injected.
// ---------------------------------------------------------------------------
const t = (name) => name;
function fakeQuery(storedValue) {
  return async () => (storedValue === undefined ? [] : [{ value: storedValue }]);
}

test('loadEgressPolicy: absent row → allow-all', async () => {
  assert.deepEqual(await loadEgressPolicy(fakeQuery(undefined), t), []);
  assert.deepEqual(await loadEgressPolicy(fakeQuery(null), t), []);
});

test('loadEgressPolicy: parses JSON string value', async () => {
  const stored = JSON.stringify([{ hosts: 'api.x.com', rules: [{ method: ['GET'], path: ['/a'] }] }]);
  assert.deepEqual(await loadEgressPolicy(fakeQuery(stored), t), [
    { hosts: ['api.x.com'], protocols: null, rules: [{ method: ['GET'], path: ['/a'] }] },
  ]);
});

test('loadEgressPolicy: throws (fail-closed) on invalid JSON', async () => {
  await assert.rejects(() => loadEgressPolicy(fakeQuery('{bad'), t), /not valid JSON/);
});

test('egressAllowedForUrl: end to end through the loader', async () => {
  const stored = [{ hosts: 'api.x.com', rules: [{ method: ['GET'], path: ['/ok/*'] }] }];
  assert.deepEqual(await egressAllowedForUrl('https://api.x.com/ok/1', 'GET', fakeQuery(stored), t), { ok: true });
  assert.deepEqual(
    (await egressAllowedForUrl('https://api.x.com/no', 'GET', fakeQuery(stored), t)),
    { ok: false, reason: 'path' },
  );
});

// ---------------------------------------------------------------------------
// deny-by-default — the empty-list branch only; opt-in admin hardening.
// ---------------------------------------------------------------------------
test('egressAllowed: empty policy + defaultDeny=true → block (reason default-deny)', () => {
  assert.deepEqual(egressAllowed('https://any/x', 'GET', [], true), { ok: false, reason: 'default-deny' });
  assert.deepEqual(egressAllowed('https://any/x', 'GET', null, true), { ok: false, reason: 'default-deny' });
});

test('egressAllowed: empty policy + defaultDeny=false (default) → allow-all', () => {
  assert.deepEqual(egressAllowed('https://any/x', 'GET', [], false), { ok: true });
  assert.deepEqual(egressAllowed('https://any/x', 'GET', []), { ok: true });
});

test('egressAllowed: a non-empty policy is unaffected by defaultDeny', () => {
  const policy = [{ hosts: ['api.x.com'], rules: [{ method: ['GET'], path: ['/ok'] }] }];
  // deny flag set, but a real rule still gates normally (match passes, miss denies by path)
  assert.deepEqual(egressAllowed('https://api.x.com/ok', 'GET', policy, true), { ok: true });
  assert.deepEqual(egressAllowed('https://api.x.com/no', 'GET', policy, true), { ok: false, reason: 'path' });
});

// A key-aware fake: the policy and the deny flag live under different keys, so the
// fake must return per-key values (the flat fakeQuery returns the same row for any key).
function fakeQueryByKey(map) {
  return async (_sql, params) => {
    const key = params && params[0];
    return key in map && map[key] !== undefined ? [{ value: map[key] }] : [];
  };
}

test('loadEgressDefaultDeny: absent → false, "true" → true, "false" → false, corrupt → false', async () => {
  assert.equal(await loadEgressDefaultDeny(fakeQueryByKey({}), t), false);
  assert.equal(await loadEgressDefaultDeny(fakeQueryByKey({ [EGRESS_DEFAULT_DENY_KEY]: 'true' }), t), true);
  assert.equal(await loadEgressDefaultDeny(fakeQueryByKey({ [EGRESS_DEFAULT_DENY_KEY]: 'false' }), t), false);
  // SECURITY: a malformed enhancement flag must NOT nuke all dispatch — default off.
  assert.equal(await loadEgressDefaultDeny(fakeQueryByKey({ [EGRESS_DEFAULT_DENY_KEY]: '{bad' }), t), false);
});

test('egressAllowedForUrl: applyDefaultDeny only blocks an EMPTY list, never reads the flag otherwise', async () => {
  // empty list + flag on + applyDefaultDeny → blocked
  assert.deepEqual(
    await egressAllowedForUrl('https://any/x', 'GET', fakeQueryByKey({ [EGRESS_DEFAULT_DENY_KEY]: 'true' }), t, { applyDefaultDeny: true }),
    { ok: false, reason: 'default-deny' },
  );
  // empty list + flag on but applyDefaultDeny NOT set (save/import/clone) → allow-all
  assert.deepEqual(
    await egressAllowedForUrl('https://any/x', 'GET', fakeQueryByKey({ [EGRESS_DEFAULT_DENY_KEY]: 'true' }), t),
    { ok: true },
  );
  // empty list + flag off + applyDefaultDeny → allow-all
  assert.deepEqual(
    await egressAllowedForUrl('https://any/x', 'GET', fakeQueryByKey({}), t, { applyDefaultDeny: true }),
    { ok: true },
  );
  // non-empty list + applyDefaultDeny → the flag is irrelevant, the list gates
  const stored = { [ALLOWLIST_KEY]: JSON.stringify([{ hosts: 'api.x.com', rules: [{ method: ['GET'], path: ['/ok'] }] }]), [EGRESS_DEFAULT_DENY_KEY]: 'true' };
  assert.deepEqual(await egressAllowedForUrl('https://api.x.com/ok', 'GET', fakeQueryByKey(stored), t, { applyDefaultDeny: true }), { ok: true });
});
