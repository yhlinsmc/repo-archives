/**
 * db-connect-reconfigure-password-preserve.test.js — v3.2.53a
 *
 * Regression tests for the Change Server edit-mode contract added in
 * v3.2.53a (DatabaseServerSection.tsx). Two invariants:
 *
 *   1. When `isPoolReady()` is true and `/configure-db` is called with
 *      a blank password, the backend MUST preserve the in-memory live
 *      password (from getDbConfigFull) rather than overwrite the file
 *      with '' — the UI advertises "leave password blank to keep the
 *      existing one" and must honour it.
 *
 *   2. `tablePrefix` MUST be rejected at the HTTP boundary if it
 *      contains characters outside [a-zA-Z0-9_]+, so a malicious
 *      admin-authored prefix cannot inject newlines / ANSI escapes
 *      into the preflight stderr ERROR/CAUSE/FIX banner.
 *
 * Uses the same `require.cache` stub pattern as
 * db-connect-handler-shape.test.js so the test exercises the real
 * Express handler end-to-end without the native mariadb binding.
 */
const { describe, it, before, after } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const mariadbKey = require.resolve('mariadb');
const dbKey = require.resolve('../../src/edge/db');
const dbConnectKey = require.resolve('../../src/edge/routes/platform/setup/db-connect');

// Capture every saveConfig call so tests can assert on the persisted shape.
let savedConfigs = [];
let liveConfigFull = {
  host: 'original-host',
  port: 3306,
  user: 'original-user',
  password: 'ORIGINAL_PASSWORD',
  database: 'fmb',
  tablePrefix: 'fmb_',
};

require.cache[mariadbKey] = {
  id: mariadbKey,
  filename: mariadbKey,
  loaded: true,
  exports: {
    createPool() {
      return {
        async getConnection() {
          return {
            async query() { return [{ ok: 1 }]; },
            release() {},
          };
        },
        async end() {},
      };
    },
  },
};

require.cache[dbKey] = {
  id: dbKey,
  filename: dbKey,
  loaded: true,
  exports: {
    isPoolReady: () => true, // reconfigure path
    getDbConfig: () => ({
      host: liveConfigFull.host,
      port: liveConfigFull.port,
      user: liveConfigFull.user,
      database: liveConfigFull.database,
      tablePrefix: liveConfigFull.tablePrefix,
      configured: true,
    }),
    getDbConfigFull: () => liveConfigFull,
    configurePool: async (cfg) => {
      // Simulate successful reconfigure; mirror the new config into live.
      liveConfigFull = { ...liveConfigFull, ...cfg };
    },
    saveConfig: (cfg) => {
      savedConfigs.push(cfg);
    },
    setConfigSource: () => {},
  },
};

const register = require('../../src/edge/routes/platform/setup/db-connect');

function postJson(port, path_, body, headers = {}) {
  return new Promise((resolve, reject) => {
    const payload = JSON.stringify(body);
    const req = http.request(
      {
        host: '127.0.0.1',
        port,
        path: path_,
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(payload),
          ...headers,
        },
      },
      (res) => {
        let chunks = '';
        res.on('data', (c) => (chunks += c));
        res.on('end', () => {
          try {
            resolve({ status: res.statusCode, body: JSON.parse(chunks) });
          } catch (err) {
            reject(err);
          }
        });
      },
    );
    req.on('error', reject);
    req.write(payload);
    req.end();
  });
}

describe('/configure-db reconfigure — password preserve + tablePrefix allowlist (v3.2.53a)', () => {
  let server;
  let port;

  before(async () => {
    const app = express();
    app.use(express.json());
    // Mock an admin session so the admin-auth gate at line 232 passes.
    app.use((req, _res, next) => {
      req.user = { role: 'admin', email: 'admin@x', id: 'admin-1' };
      next();
    });
    const router = express.Router();
    register(router);
    app.use('/api/setup', router);
    server = app.listen(0);
    port = server.address().port;
  });

  after(async () => {
    await new Promise((r) => server.close(r));
  });

  it('blank password + isPoolReady preserves in-memory live password', async () => {
    savedConfigs = [];
    const res = await postJson(port, '/api/setup/configure-db', {
      host: 'new-host',
      port: 3306,
      user: 'new-user',
      password: '', // UI submits blank to keep the existing password
      database: 'fmb',
      tablePrefix: 'fmb_',
      persist: true,
    });
    assert.equal(res.status, 200, JSON.stringify(res.body));
    assert.equal(savedConfigs.length, 1);
    // The saved config must carry the ORIGINAL password, not ''.
    assert.equal(savedConfigs[0].password, 'ORIGINAL_PASSWORD');
    assert.equal(savedConfigs[0].host, 'new-host'); // other fields honour submission
    assert.equal(savedConfigs[0].user, 'new-user');
  });

  it('explicit new password overrides the preserved one', async () => {
    savedConfigs = [];
    const res = await postJson(port, '/api/setup/configure-db', {
      host: 'new-host',
      port: 3306,
      user: 'new-user',
      password: 'EXPLICIT_NEW_PASSWORD',
      database: 'fmb',
      tablePrefix: 'fmb_',
      persist: true,
    });
    assert.equal(res.status, 200, JSON.stringify(res.body));
    assert.equal(savedConfigs.length, 1);
    assert.equal(savedConfigs[0].password, 'EXPLICIT_NEW_PASSWORD');
  });

  it('tablePrefix with newline is rejected 400', async () => {
    savedConfigs = [];
    const res = await postJson(port, '/api/setup/configure-db', {
      host: 'h',
      port: 3306,
      user: 'u',
      password: 'p',
      database: 'fmb',
      tablePrefix: 'bad\nprefix_',
    });
    assert.equal(res.status, 400);
    assert.equal(res.body?.error?.code, 'BAD_REQUEST');
    assert.match(res.body?.error?.message || '', /tablePrefix/);
    assert.equal(savedConfigs.length, 0); // never persisted
  });

  it('tablePrefix with ANSI escape is rejected 400', async () => {
    savedConfigs = [];
    const res = await postJson(port, '/api/setup/configure-db', {
      host: 'h',
      port: 3306,
      user: 'u',
      password: 'p',
      database: 'fmb',
      tablePrefix: 'bad\x1b[31m_',
    });
    assert.equal(res.status, 400);
    assert.equal(res.body?.error?.code, 'BAD_REQUEST');
    assert.equal(savedConfigs.length, 0);
  });

  it('tablePrefix with only alnum + underscore is accepted', async () => {
    savedConfigs = [];
    const res = await postJson(port, '/api/setup/configure-db', {
      host: 'h',
      port: 3306,
      user: 'u',
      password: 'p',
      database: 'fmb',
      tablePrefix: 'example_app_',
      persist: true,
    });
    assert.equal(res.status, 200, JSON.stringify(res.body));
    assert.equal(savedConfigs.length, 1);
    assert.equal(savedConfigs[0].tablePrefix, 'example_app_');
  });

  // v3.2.55 Q3 E1+: tablePrefix is required end-to-end; the silent
  // `'fmb_'` fallback is gone. The handler now returns BAD_REQUEST when
  // the field is missing or empty (mirrors the new server validation in
  // setup/db-connect.js).
  it('tablePrefix omitted entirely is rejected with BAD_REQUEST', async () => {
    savedConfigs = [];
    const res = await postJson(port, '/api/setup/configure-db', {
      host: 'h',
      port: 3306,
      user: 'u',
      password: 'p',
      database: 'fmb',
    });
    assert.equal(res.status, 400, JSON.stringify(res.body));
    assert.equal(savedConfigs.length, 0, 'no save should occur when validation fails');
    const body = res.body?.error || res.body;
    assert.match(JSON.stringify(body), /tablePrefix is required/i);
  });
});
