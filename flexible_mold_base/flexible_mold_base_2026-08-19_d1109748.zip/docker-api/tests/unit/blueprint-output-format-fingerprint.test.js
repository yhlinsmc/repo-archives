/**
 * blueprint-output-format-fingerprint.test.js — X5 (fmb-1723 codex round 2).
 *
 * On a degraded DB (format column absent), an existing output-order row
 * carries no `format` property. parseYaml separately normalizes an omitted
 * format to the string 'json'. Comparing those two representations directly
 * ('' vs 'json') reports a phantom modified output on an otherwise untouched
 * export. computeDiff's output fingerprint must canonicalize with the SAME
 * clamp used at every insert site in blueprint-serialization.js
 * (`o.format === 'table' ? 'table' : 'json'`) so absent/''/anything-else all
 * fold to 'json' before comparison.
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');

const { computeDiff } = require('../../src/edge/lib/blueprint-serialization');

function rawFixture(outputRows) {
  return {
    blueprint_fields: [],
    field_options: [],
    blueprint_sections: [],
    blueprint_groups: [],
    blueprint_output_order: outputRows,
  };
}

describe('computeDiff — output format fingerprint canonicalization', () => {
  it('does not flag an existing row with format absent (degraded schema) vs parsed YAML "json" as modified', () => {
    const oldRaw = rawFixture([
      // Degraded-schema row: no `format` property at all (column absent).
      { output_key: 'material', sort_order: 1 },
    ]);
    const newRaw = rawFixture([
      // parseYaml's own default for an omitted format.
      { output_key: 'material', sort_order: 1, format: 'json' },
    ]);
    const diff = computeDiff(oldRaw, newRaw);
    assert.deepEqual(diff.output.modifiedNames, [], 'absent-format row must canonicalize to the same fingerprint as an explicit json row');
    assert.equal(diff.output.modified, 0);
  });

  it('still flags a real table vs absent-format change as modified', () => {
    const oldRaw = rawFixture([
      { output_key: 'material', sort_order: 1 },
    ]);
    const newRaw = rawFixture([
      { output_key: 'material', sort_order: 1, format: 'table' },
    ]);
    const diff = computeDiff(oldRaw, newRaw);
    assert.deepEqual(diff.output.modifiedNames, ['material']);
    assert.equal(diff.output.modified, 1);
  });

  it('canonicalizes any non-"table" stored value (not just "" or "json") to json', () => {
    const oldRaw = rawFixture([
      // Anything-else-canonicalizes-to-json per the same clamp as the insert sites.
      { output_key: 'material', sort_order: 1, format: 'bogus' },
    ]);
    const newRaw = rawFixture([
      { output_key: 'material', sort_order: 1, format: 'json' },
    ]);
    const diff = computeDiff(oldRaw, newRaw);
    assert.deepEqual(diff.output.modifiedNames, []);
    assert.equal(diff.output.modified, 0);
  });
});
