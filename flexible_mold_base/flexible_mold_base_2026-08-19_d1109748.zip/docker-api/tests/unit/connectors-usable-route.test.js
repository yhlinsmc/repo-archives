// Route-level coverage for GET /usable (the non-admin data-entry projection).
// The pure projection/derive helpers are covered in
// integration/api-connectors-usable.test.js; this exercises the Express handler
// itself — requireAuth (401), the missing-blueprint_id 400, the happy-path
// secret-free projection, and the 500 catch path.
const { it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

// Stub the edge db before the router requires it (same pattern as
// connectors-prepare.test.js). The /usable route only reads via pool.ro.
const dbKey = require.resolve('../../src/edge/db');
let queryImpl;
const conn = {
  async query(sql, params) { return queryImpl(sql, params); },
  release() {},
};
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: { ro: { getConnection: async () => conn }, rw: { getConnection: async () => conn } }, t: (n) => `fmb_${n}` },
};

const register = require('../../src/edge/routes/app/api-connectors/usable');

let currentUser;
let server; let baseUrl;
before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { if (currentUser) req.user = currentUser; next(); });
  const router = express.Router();
  register(router);
  app.use('/edge/app/api-connectors', router);
  server = http.createServer(app);
  await new Promise((r) => server.listen(0, r));
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});
after(() => server && server.close());

beforeEach(() => {
  currentUser = { id: 'u1', role: 'user' };
  queryImpl = () => [];
});

async function get(path) {
  const res = await fetch(`${baseUrl}${path}`);
  return { status: res.status, body: await res.json() };
}

it('401 when unauthenticated (requireAuth gate)', async () => {
  currentUser = null;
  const r = await get('/edge/app/api-connectors/usable?blueprint_id=bp1');
  assert.equal(r.status, 401);
  assert.equal(r.body.error.code, 'UNAUTHORIZED');
});

it('400 when blueprint_id is missing', async () => {
  const r = await get('/edge/app/api-connectors/usable');
  assert.equal(r.status, 400);
  assert.equal(r.body.error.code, 'BAD_REQUEST');
});

it('200 projects a secret-free, data-entry-safe shape for an authed non-admin', async () => {
  queryImpl = (sql) => {
    if (/FROM `fmb_api_connectors` WHERE blueprint_id = \? AND is_active = 1/.test(sql)) {
      return [{
        id: 'c1', name: 'Mock', description: null,
        url: 'http://svc.internal/echo?id={{id}}',
        request_config: JSON.stringify({ headers: { Authorization: 'Bearer {{tok}}' }, input_mapping: { field_id: 'id' } }),
        response_config: JSON.stringify({ outputs: [{ id: 'o1', from: { mode: 'value', path: 'data.name' }, to: { mode: 'field', field_key: 'notes' } }], transformer_id: null }),
      }];
    }
    return [];
  };
  const r = await get('/edge/app/api-connectors/usable?blueprint_id=bp1');
  assert.equal(r.status, 200);
  const c = r.body.data[0];
  assert.equal(c.id, 'c1');
  // input_spec is derived from {{vars}}; the field-bound one carries its source.
  assert.deepEqual(c.input_spec.find((s) => s.var === 'id'), { var: 'id', source_field_key: 'field_id' });
  assert.equal(c.response_config.outputs[0].to.field_key, 'notes');
  // The projection must NEVER carry url/auth/headers/body templates.
  const serialized = JSON.stringify(c);
  assert.equal('url' in c, false);
  assert.equal('auth_type' in c || 'auth_config' in c, false);
  assert.equal(serialized.includes('svc.internal'), false);
  assert.equal(serialized.includes('Authorization'), false);
});

it('converts a legacy {mappings,lookups} config to outputs[] (no stored outputs)', async () => {
  queryImpl = (sql) => {
    if (/FROM `fmb_api_connectors` WHERE blueprint_id = \? AND is_active = 1/.test(sql)) {
      return [{
        id: 'c-legacy', name: 'Legacy', description: null,
        url: 'http://svc/legacy',
        request_config: JSON.stringify({}),
        response_config: JSON.stringify({
          mappings: [{ path: 'main.temp', field_key: 'f' }],
          lookups: [{
            list_path: 'd', filter_column: 'k',
            filter_value: { kind: 'literal', value: 'v' },
            extract_column: 'ip', target: { kind: 'field', field_key: 'g' },
          }],
        }),
      }];
    }
    return [];
  };
  const r = await get('/edge/app/api-connectors/usable?blueprint_id=bp-legacy');
  assert.equal(r.status, 200);
  const c = r.body.data[0];
  const outs = c.response_config.outputs;
  assert.equal(outs.length, 2);
  // value mapping → value→field
  const valueOut = outs.find((o) => o.from.mode === 'value');
  assert.deepEqual(valueOut.from, { mode: 'value', path: 'main.temp' });
  assert.deepEqual(valueOut.to, { mode: 'field', field_key: 'f' });
  // lookup → list→field with reduce:'pick'
  const listOut = outs.find((o) => o.from.mode === 'list');
  assert.equal(listOut.from.path, 'd');
  assert.deepEqual(listOut.from.where, { match: 'all', conditions: [{ field: 'k', op: 'eq', value: { kind: 'literal', value: 'v' } }] });
  assert.equal(listOut.to.field_key, 'g');
  assert.equal(listOut.to.extract, 'ip');
  assert.equal(listOut.to.reduce, 'pick');
  // secrets still absent
  assert.equal('url' in c, false);
  assert.equal(JSON.stringify(c).includes('svc/legacy'), false);
});

it('500 when the DB query throws (catch path), without leaking the error', async () => {
  queryImpl = () => { throw new Error('connection reset by peer'); };
  const r = await get('/edge/app/api-connectors/usable?blueprint_id=bp1');
  assert.equal(r.status, 500);
  assert.equal(r.body.error.code, 'INTERNAL_ERROR');
  assert.equal(JSON.stringify(r.body).includes('connection reset'), false);
});

it('projects all four bundle fields verbatim when set', async () => {
  queryImpl = (sql) => {
    if (/FROM `fmb_api_connectors` WHERE blueprint_id = \? AND is_active = 1/.test(sql)) {
      return [{
        id: 'c-grp', name: 'Grouped', description: null,
        url: 'http://svc/data',
        request_config: JSON.stringify({}),
        response_config: JSON.stringify({ outputs: [], transformer_id: null }),
        group_id: '7b2e1f00-1111-2222-3333-444455556666',
        group_label: 'Device Full Profile',
        group_mode: 'aggregation',
        sequence: 2,
      }];
    }
    return [];
  };
  const r = await get('/edge/app/api-connectors/usable?blueprint_id=bp-grp');
  assert.equal(r.status, 200);
  const c = r.body.data[0];
  assert.equal(c.group_id, '7b2e1f00-1111-2222-3333-444455556666');
  assert.equal(c.group_label, 'Device Full Profile');
  assert.equal(c.group_mode, 'aggregation');
  assert.equal(c.sequence, 2);
});

it('projects all four bundle fields as null when DB row has them NULL', async () => {
  queryImpl = (sql) => {
    if (/FROM `fmb_api_connectors` WHERE blueprint_id = \? AND is_active = 1/.test(sql)) {
      return [{
        id: 'c-ngrp', name: 'Ungrouped', description: null,
        url: 'http://svc/data',
        request_config: JSON.stringify({}),
        response_config: JSON.stringify({ outputs: [], transformer_id: null }),
        group_id: null,
        group_label: null,
        group_mode: null,
        sequence: null,
      }];
    }
    return [];
  };
  const r = await get('/edge/app/api-connectors/usable?blueprint_id=bp-ngrp');
  assert.equal(r.status, 200);
  const c = r.body.data[0];
  assert.strictEqual(c.group_id, null);
  assert.strictEqual(c.group_label, null);
  assert.strictEqual(c.group_mode, null);
  assert.strictEqual(c.sequence, null);
});

it('secret-free shape includes bundle fields but never url/auth', async () => {
  queryImpl = (sql) => {
    if (/FROM `fmb_api_connectors` WHERE blueprint_id = \? AND is_active = 1/.test(sql)) {
      return [{
        id: 'c-sec', name: 'SecCheck', description: null,
        url: 'http://secret.internal/api',
        request_config: JSON.stringify({ input_mapping: {} }),
        response_config: JSON.stringify({ outputs: [], transformer_id: null }),
        group_id: 'aaaabbbb-1111-2222-3333-ccccdddd0000',
        group_label: 'Profile Bundle',
        group_mode: 'chain',
        sequence: 1,
      }];
    }
    return [];
  };
  const r = await get('/edge/app/api-connectors/usable?blueprint_id=bp-sec');
  assert.equal(r.status, 200);
  const c = r.body.data[0];
  // Bundle fields present in projection
  assert.equal(c.group_id, 'aaaabbbb-1111-2222-3333-ccccdddd0000');
  assert.equal(c.group_label, 'Profile Bundle');
  assert.equal(c.group_mode, 'chain');
  assert.equal(c.sequence, 1);
  // url and auth still absent
  assert.equal('url' in c, false);
  assert.equal('auth_type' in c || 'auth_config' in c, false);
  assert.equal(JSON.stringify(c).includes('secret.internal'), false);
});

it('projects input_from_step entries with exactly var/from_sequence/path', async () => {
  queryImpl = (sql) => {
    if (/FROM `fmb_api_connectors` WHERE blueprint_id = \? AND is_active = 1/.test(sql)) {
      return [{
        id: 'c-chain', name: 'ChainStep2', description: null,
        url: 'http://svc/lookup?id={{id}}',
        request_config: JSON.stringify({
          input_from_step: [
            { var: 'id', from_sequence: 1, path: 'data.id', extra_key: 'must-not-leak' },
          ],
        }),
        response_config: JSON.stringify({ outputs: [], transformer_id: null }),
        group_id: 'aaaabbbb-1111-2222-3333-ccccdddd0001',
        group_label: 'Chain Bundle',
        group_mode: 'chain',
        sequence: 2,
      }];
    }
    return [];
  };
  const r = await get('/edge/app/api-connectors/usable?blueprint_id=bp-chain');
  assert.equal(r.status, 200);
  const c = r.body.data[0];
  // Exactly the three contract keys per entry — unknown keys stripped.
  assert.deepEqual(c.input_from_step, [{ var: 'id', from_sequence: 1, path: 'data.id' }]);
  assert.deepEqual(Object.keys(c.input_from_step[0]).sort(), ['from_sequence', 'path', 'var']);
  assert.equal(JSON.stringify(c).includes('must-not-leak'), false);
});

it('drops malformed input_from_step entries and nulls when none survive or field absent', async () => {
  queryImpl = (sql) => {
    if (/FROM `fmb_api_connectors` WHERE blueprint_id = \? AND is_active = 1/.test(sql)) {
      return [
        {
          id: 'c-mixed', name: 'Mixed', description: null,
          url: 'http://svc/a',
          request_config: JSON.stringify({
            input_from_step: [
              { var: '', from_sequence: 0, path: '' },
              'not-an-object',
              null,
              { var: 'ok', from_sequence: 1, path: 'data.v' },
              { var: 'frac', from_sequence: 1.5, path: 'data.x' },
              { var: 'missing-path', from_sequence: 1 },
            ],
          }),
          response_config: JSON.stringify({ outputs: [], transformer_id: null }),
        },
        {
          id: 'c-all-bad', name: 'AllBad', description: null,
          url: 'http://svc/b',
          request_config: JSON.stringify({
            input_from_step: [{ var: '', from_sequence: 0, path: '' }, 42],
          }),
          response_config: JSON.stringify({ outputs: [], transformer_id: null }),
        },
        {
          id: 'c-not-array', name: 'NotArray', description: null,
          url: 'http://svc/c',
          request_config: JSON.stringify({ input_from_step: { var: 'x' } }),
          response_config: JSON.stringify({ outputs: [], transformer_id: null }),
        },
        {
          id: 'c-absent', name: 'Absent', description: null,
          url: 'http://svc/d',
          request_config: JSON.stringify({}),
          response_config: JSON.stringify({ outputs: [], transformer_id: null }),
        },
      ];
    }
    return [];
  };
  const r = await get('/edge/app/api-connectors/usable?blueprint_id=bp-malformed');
  assert.equal(r.status, 200);
  const byId = Object.fromEntries(r.body.data.map((c) => [c.id, c]));
  // Only the well-formed entry survives.
  assert.deepEqual(byId['c-mixed'].input_from_step, [{ var: 'ok', from_sequence: 1, path: 'data.v' }]);
  // All entries malformed → null, not [].
  assert.strictEqual(byId['c-all-bad'].input_from_step, null);
  // Non-array value → null.
  assert.strictEqual(byId['c-not-array'].input_from_step, null);
  // Field absent → null.
  assert.strictEqual(byId['c-absent'].input_from_step, null);
});

it('secret-free shape holds with input_from_step present (no url/auth/headers/body)', async () => {
  queryImpl = (sql) => {
    if (/FROM `fmb_api_connectors` WHERE blueprint_id = \? AND is_active = 1/.test(sql)) {
      return [{
        id: 'c-chain-sec', name: 'ChainSec', description: null,
        url: 'http://secret.internal/chain?id={{id}}',
        request_config: JSON.stringify({
          headers: { Authorization: 'Bearer {{tok}}' },
          body: '{"token":"{{tok}}"}',
          input_from_step: [{ var: 'id', from_sequence: 1, path: 'data.id' }],
        }),
        response_config: JSON.stringify({ outputs: [], transformer_id: null }),
        group_id: 'aaaabbbb-1111-2222-3333-ccccdddd0002',
        group_label: 'Chain Bundle',
        group_mode: 'chain',
        sequence: 2,
      }];
    }
    return [];
  };
  const r = await get('/edge/app/api-connectors/usable?blueprint_id=bp-chain-sec');
  assert.equal(r.status, 200);
  const c = r.body.data[0];
  assert.deepEqual(c.input_from_step, [{ var: 'id', from_sequence: 1, path: 'data.id' }]);
  const serialized = JSON.stringify(c);
  assert.equal('url' in c, false);
  assert.equal('auth_type' in c || 'auth_config' in c, false);
  assert.equal(serialized.includes('secret.internal'), false);
  assert.equal(serialized.includes('Authorization'), false);
  assert.equal(serialized.includes('Bearer'), false);
  assert.equal(serialized.includes('{{tok}}'), false);
  assert.equal(serialized.includes('"token":"'), false);
});
