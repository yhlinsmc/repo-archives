/**
 * blueprint-import-variant-overrides-remap.test.js — Bug 2.
 *
 * overwriteBlueprint DELETEs then re-INSERTs blueprint_fields with fresh UUIDs.
 * variant_overrides.field_id has no FK, so those references would dangle
 * silently ("Unknown field" in the Variant Policy UI). This test asserts the
 * targeted remap: each override under the blueprint's variants is repointed by
 * field_key to the new field id; an override whose field_key was removed in the
 * new schema is dropped and counted (non-silent).
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');

const lib = require('../../src/edge/lib/blueprint-serialization');

const FAKE_TABLES = {
  HIERARCHY_NODES: 'hierarchy_nodes',
  BLUEPRINT_FIELDS: 'blueprint_fields',
  FIELD_OPTIONS: 'field_options',
  BLUEPRINT_SECTIONS: 'blueprint_sections',
  BLUEPRINT_OUTPUT_ORDER: 'blueprint_output_order',
  BLUEPRINT_GROUPS: 'blueprint_groups',
  VARIANT_OVERRIDES: 'variant_overrides',
  FEATURE_AUDIT: 'feature_audit',
};
const fakeT = (name) => `fmb_${name}`;
let counter = 0;
const fakeUuid = () => `fake-uuid-${counter++}`;

// The existing target blueprint (loadRawExport reads this via SELECT *).
function currentFixture() {
  const fld = (id, key) => ({
    id, blueprint_id: 'bp-1', field_key: key, field_label: key, field_type: 'number',
    is_required: 0, default_value: '', placeholder: '', tooltip: '', section: 'general',
    order_index: 0, table_config: null, visibility_rule: null,
  });
  return {
    import_version: 1,
    hierarchy_node: {
      id: 'bp-1', parent_id: 'release-1', name: 'BP', description: '',
      node_type: 'blueprint', sort_order: 0, is_active: 1,
      transformer_id: null, transformer_version: null, linked_blueprint_id: null,
    },
    blueprint_fields: [fld('old-w', 'width'), fld('old-h', 'height'), fld('old-d', 'depth')],
    field_options: [],
    blueprint_sections: [],
    blueprint_groups: [],
    blueprint_output_order: [],
  };
}

// The imported payload: `depth` is removed; width + height survive.
function payloadFixture() {
  const fld = (id, key) => ({
    id, blueprint_id: 'src', field_key: key, field_label: key, field_type: 'number',
    is_required: 0, default_value: '', placeholder: '', tooltip: '', section: 'general',
    order_index: 0, table_config: null, visibility_rule: null,
  });
  return {
    import_version: 1,
    hierarchy_node: { name: 'BP', description: '', is_active: 1, transformer_id: null, transformer_version: null },
    blueprint_fields: [fld('pay-w', 'width'), fld('pay-h', 'height')],
    field_options: [],
    blueprint_sections: [],
    blueprint_groups: [],
    blueprint_output_order: [],
  };
}

// overrides = [{ id, field_id }] captured for the blueprint's variants.
// variantOverridesExists = whether the additive table probe reports it present.
function makeFakeConn(current, overrides, { variantOverridesExists = true } = {}) {
  const queries = [];
  return {
    queries,
    async query(sql, params) {
      queries.push({ sql, params });
      // information_schema probes — differentiate by the table-name param.
      if (/information_schema\.TABLES/i.test(sql)) {
        if (params && params[0] === 'fmb_variant_overrides') return variantOverridesExists ? [{ n: 1 }] : [];
        return []; // blueprint_groups (and anything else) treated as absent.
      }
      if (/SELECT DATABASE\(\) AS db/i.test(sql)) return [{ db: '' }];
      if (/information_schema\.COLUMNS/i.test(sql)) return []; // → portable insert falls back
      if (/^SELECT id, field_key FROM .*blueprint_fields/i.test(sql)) {
        return current.blueprint_fields.map((f) => ({ id: f.id, field_key: f.field_key }));
      }
      if (/^SELECT id, field_id FROM .*variant_overrides/i.test(sql)) return overrides;
      if (/^SELECT \* FROM .*hierarchy_nodes/i.test(sql)) return [current.hierarchy_node];
      if (/^SELECT \* FROM .*blueprint_fields/i.test(sql)) return current.blueprint_fields;
      if (/^SELECT \* FROM .*field_options/i.test(sql)) return current.field_options;
      if (/^SELECT \* FROM .*blueprint_sections/i.test(sql)) return current.blueprint_sections;
      if (/^SELECT \* FROM .*blueprint_output_order/i.test(sql)) return current.blueprint_output_order;
      if (/^SELECT id FROM .*hierarchy_nodes/i.test(sql)) return [{ id: current.hierarchy_node.id }];
      return []; // INSERT / UPDATE / DELETE / everything else
    },
  };
}

describe('overwriteBlueprint remaps variant_overrides by field_key (Bug 2)', () => {
  it('repoints a surviving override to the new field id and drops one for a removed field', async () => {
    const current = currentFixture();
    const overrides = [
      { id: 'ov-width', field_id: 'old-w' }, // survives → repointed
      { id: 'ov-depth', field_id: 'old-d' }, // depth removed → dropped
    ];
    const conn = makeFakeConn(current, overrides);
    const result = await lib.overwriteBlueprint({
      conn, t: fakeT, TABLES: FAKE_TABLES, uuidv4: fakeUuid,
      existingId: 'bp-1', payload: payloadFixture(), userId: 'admin-1',
      expectedRevision: lib.computeRevision(current),
    });

    assert.equal(result.ok, true);
    assert.equal(result.droppedOverrides, 1);
    assert.ok(result.warnings.some((w) => /variant policy override/i.test(w)));

    const updates = conn.queries.filter((q) => /^UPDATE .*variant_overrides.*SET field_id/i.test(q.sql));
    const deletes = conn.queries.filter((q) => /^DELETE FROM .*variant_overrides/i.test(q.sql));
    // Exactly one batched CASE-UPDATE covering the single repoint (ov-width) and
    // one batched IN-DELETE covering the single drop (ov-depth). The batched
    // UPDATE binds `CASE id WHEN <id> THEN <newFieldId>` — id first, new id
    // second (the reverse of the old per-row `SET field_id = ? WHERE id = ?`).
    assert.equal(updates.length, 1);
    assert.equal(updates[0].params[0], 'ov-width');
    assert.ok(/^fake-uuid-/.test(updates[0].params[1]), 'repointed to a freshly-inserted field id');
    assert.equal(deletes.length, 1);
    assert.equal(deletes[0].params[0], 'ov-depth');
  });

  it('drops (and counts) an override whose stored field_id was already dangling', async () => {
    const current = currentFixture();
    const overrides = [{ id: 'ov-orphan', field_id: 'ghost-id' }]; // not in the old field set
    const conn = makeFakeConn(current, overrides);
    const result = await lib.overwriteBlueprint({
      conn, t: fakeT, TABLES: FAKE_TABLES, uuidv4: fakeUuid,
      existingId: 'bp-1', payload: payloadFixture(), userId: 'admin-1',
      expectedRevision: lib.computeRevision(current),
    });
    assert.equal(result.droppedOverrides, 1);
    const deletes = conn.queries.filter((q) => /^DELETE FROM .*variant_overrides/i.test(q.sql));
    assert.equal(deletes.length, 1);
    assert.equal(deletes[0].params[0], 'ov-orphan');
  });

  it('no overrides → droppedOverrides 0 and no override writes', async () => {
    const current = currentFixture();
    const conn = makeFakeConn(current, []);
    const result = await lib.overwriteBlueprint({
      conn, t: fakeT, TABLES: FAKE_TABLES, uuidv4: fakeUuid,
      existingId: 'bp-1', payload: payloadFixture(), userId: 'admin-1',
      expectedRevision: lib.computeRevision(current),
    });
    assert.equal(result.droppedOverrides, 0);
    assert.ok(!conn.queries.some((q) => /variant_overrides SET field_id|DELETE FROM .*variant_overrides/i.test(q.sql)));
  });

  it('batched CASE-UPDATE + IN-DELETE match a per-row loop on the same fixture (equivalence)', async () => {
    // Mixed set: two survivors (repoint), one removed field (drop), one already
    // dangling stored id (drop). Order intentionally interleaved.
    const oldIdToFieldKey = new Map([
      ['old-w', 'width'], ['old-h', 'height'], ['old-d', 'depth'],
    ]);
    const newFieldKeyToId = new Map([
      ['width', 'new-w'], ['height', 'new-h'], // depth removed
    ]);
    const captured = [
      { id: 'ov-w', field_id: 'old-w' },   // → repoint new-w
      { id: 'ov-d', field_id: 'old-d' },   // depth removed → drop
      { id: 'ov-ghost', field_id: 'gone' }, // dangling → drop
      { id: 'ov-h', field_id: 'old-h' },   // → repoint new-h
    ];

    // Reference per-row loop (the pre-batch behaviour).
    const refRepoints = [];
    const refDrops = [];
    for (const ov of captured) {
      const key = oldIdToFieldKey.get(ov.field_id);
      const newId = key != null ? newFieldKeyToId.get(key) : undefined;
      if (newId) refRepoints.push({ id: ov.id, field_id: newId });
      else refDrops.push(ov.id);
    }

    const plan = lib.planVariantOverrideRemap(captured, oldIdToFieldKey, newFieldKeyToId);
    assert.deepEqual(plan.repoints, refRepoints, 'repoint list matches the per-row loop (order preserved)');
    assert.deepEqual(plan.drops, refDrops, 'drop list matches the per-row loop');
    assert.equal(plan.drops.length, 2, 'droppedOverrides count is identical');

    // Executor issues exactly one UPDATE + one DELETE for a sub-chunk set, and
    // the CASE covers every repoint id with its new field id.
    const calls = [];
    const fakeConn = { async query(sql, params) { calls.push({ sql, params }); return []; } };
    await lib.applyVariantOverrideRemap(fakeConn, 'fmb_variant_overrides', plan.repoints, plan.drops);
    const upd = calls.filter((c) => /^UPDATE /i.test(c.sql));
    const del = calls.filter((c) => /^DELETE /i.test(c.sql));
    assert.equal(upd.length, 1, 'one batched UPDATE');
    assert.equal(del.length, 1, 'one batched DELETE');
    // CASE params interleave (id, newId) per repoint, then the WHERE id list.
    assert.deepEqual(upd[0].params, ['ov-w', 'new-w', 'ov-h', 'new-h', 'ov-w', 'ov-h']);
    assert.deepEqual(del[0].params, ['ov-d', 'ov-ghost']);
  });

  it('applyVariantOverrideRemap chunks repoints + drops at the 500 boundary, equivalent to a per-row loop', async () => {
    // 501 of each → spans exactly one chunk boundary (500 + 1). Guards the
    // slice/`i += CHUNK` arithmetic and the per-chunk param interleaving.
    const repoints = Array.from({ length: 501 }, (_, i) => ({ id: `r${i}`, field_id: `f${i}` }));
    const drops = Array.from({ length: 501 }, (_, i) => `d${i}`);

    const calls = [];
    const fakeConn = { async query(sql, params) { calls.push({ sql, params }); return { affectedRows: params ? params.length : 0 }; } };
    await lib.applyVariantOverrideRemap(fakeConn, 'fmb_variant_overrides', repoints, drops);

    const upd = calls.filter((c) => /^UPDATE /i.test(c.sql));
    const del = calls.filter((c) => /^DELETE /i.test(c.sql));
    assert.equal(upd.length, 2, '501 repoints → 2 UPDATE chunks (500 + 1)');
    assert.equal(del.length, 2, '501 drops → 2 DELETE chunks (500 + 1)');

    // Per-chunk param shape: 2 params per CASE pair + 1 per WHERE id = 3N.
    assert.equal(upd[0].params.length, 1500, 'first UPDATE chunk = 500×(id,fid) + 500 where-ids');
    assert.equal(upd[1].params.length, 3, 'second UPDATE chunk = 1×(id,fid) + 1 where-id');
    assert.equal(del[0].params.length, 500);
    assert.equal(del[1].params.length, 1);

    // Ordering within a chunk: (id, field_id) pairs first, then the WHERE id list.
    assert.equal(upd[0].params[0], 'r0');
    assert.equal(upd[0].params[1], 'f0');
    assert.equal(upd[0].params[998], 'r499');
    assert.equal(upd[0].params[999], 'f499');
    assert.equal(upd[0].params[1000], 'r0', 'WHERE id list starts after the 1000 CASE params');
    assert.equal(upd[0].params[1499], 'r499');
    assert.deepEqual(upd[1].params, ['r500', 'f500', 'r500'], 'remainder chunk carries the 501st repoint');
    assert.deepEqual(del[1].params, ['d500'], 'remainder chunk carries the 501st drop');

    // Behavioural equivalence to a per-row loop: every repoint id/value is
    // applied exactly once in order, every drop id deleted exactly once in order.
    const appliedPairs = [];
    for (const u of upd) {
      const n = u.params.length / 3;
      for (let k = 0; k < n; k += 1) appliedPairs.push({ id: u.params[k * 2], field_id: u.params[k * 2 + 1] });
    }
    assert.deepEqual(appliedPairs, repoints, 'union of CASE pairs across chunks == the full repoint plan, in order');
    const deletedIds = del.flatMap((d) => d.params);
    assert.deepEqual(deletedIds, drops, 'union of IN-DELETE ids across chunks == the full drop plan, in order');
  });

  it('applyVariantOverrideRemap emits a single statement at exactly the chunk size (no empty trailing chunk)', async () => {
    const repoints = Array.from({ length: 500 }, (_, i) => ({ id: `r${i}`, field_id: `f${i}` }));
    const drops = Array.from({ length: 500 }, (_, i) => `d${i}`);
    const calls = [];
    const fakeConn = { async query(sql, params) { calls.push({ sql }); return { affectedRows: 0 }; } };
    await lib.applyVariantOverrideRemap(fakeConn, 'fmb_variant_overrides', repoints, drops);
    assert.equal(calls.filter((c) => /^UPDATE /i.test(c.sql)).length, 1, 'exactly 500 repoints → one UPDATE, no empty second chunk');
    assert.equal(calls.filter((c) => /^DELETE /i.test(c.sql)).length, 1, 'exactly 500 drops → one DELETE, no empty second chunk');
  });

  it('skips the remap entirely when the variant_overrides table is absent (operator DB)', async () => {
    const current = currentFixture();
    const overrides = [{ id: 'ov-width', field_id: 'old-w' }];
    const conn = makeFakeConn(current, overrides, { variantOverridesExists: false });
    const result = await lib.overwriteBlueprint({
      conn, t: fakeT, TABLES: FAKE_TABLES, uuidv4: fakeUuid,
      existingId: 'bp-1', payload: payloadFixture(), userId: 'admin-1',
      expectedRevision: lib.computeRevision(current),
    });
    assert.equal(result.droppedOverrides, 0);
    // Never even reads the overrides, never writes them.
    assert.ok(!conn.queries.some((q) => /FROM .*variant_overrides/i.test(q.sql)));
  });
});
