/**
 * connectors-group-validation.test.js — bundle-field all-or-nothing validation.
 *
 * Exercises the group-field consistency middleware in
 * src/edge/routes/app/api-connectors/index.js.
 *
 * Rules enforced:
 *   - group_id null/absent → force all four bundle fields to null, pass through
 *   - group_id present → must be a UUID; group_mode and sequence required + typed
 *   - group_label optional but must be string ≤ 255 chars when supplied
 *   - Middleware skips GET / DELETE entirely
 *   - Middleware skips the /import path (import owns its own sanitizer)
 *   - request_config.input_from_step is shape-validated at the write boundary
 *     (malformed → friendly 400) and stored without stripping
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const { fixtureUserId } = require('../helpers/fixture-ids');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

// Stub connector-dispatch so the CRUD factory never attempts network I/O.
const cdKey = require.resolve('../../src/edge/lib/connector-dispatch');
const cd = require('../../src/edge/lib/connector-dispatch');
cd.executeRequest = () => Promise.resolve({ upstream_status: 200, headers: {}, body: '', truncated: false, duration_ms: 0 });
require.cache[cdKey].exports = cd;

// Stub the edge DB. The INSERT path needs:
//   INFORMATION_SCHEMA.COLUMNS → columns list (returns bundle cols so they flow through)
//   SELECT DATABASE() → 'testdb'
//   INSERT INTO fmb_api_connectors → {insertId: '36b7e1f1-d110-4dff-85fd-bb3ad351cab1', affectedRows: 1}
//   SELECT after insert (CRUD factory re-reads the row) → the inserted row
//   INSERT INTO fmb_feature_audit → {affectedRows: 1}
const dbKey = require.resolve('../../src/edge/db');
const VALID_UUID = '7b2e1f00-1111-2222-3333-444455556666';

// lastInsert tracks INSERT col→value so the SELECT-after-insert can echo them
// back verbatim, enabling the input_from_step round-trip assertion.
let lastInsert = {};
const conn = {
  async query(sql, params) {
    if (/information_schema\.COLUMNS/i.test(sql)) {
      // Return the four bundle columns so createCrudRoutes includes them.
      return [
        { COLUMN_NAME: 'id' },
        { COLUMN_NAME: 'name' },
        { COLUMN_NAME: 'url' },
        { COLUMN_NAME: 'method' },
        { COLUMN_NAME: 'auth_type' },
        { COLUMN_NAME: 'auth_config' },
        { COLUMN_NAME: 'request_config' },
        { COLUMN_NAME: 'response_config' },
        { COLUMN_NAME: 'is_active' },
        { COLUMN_NAME: 'blueprint_id' },
        { COLUMN_NAME: 'section_key' },
        { COLUMN_NAME: 'dispatch_origin' },
        { COLUMN_NAME: 'owner_id' },
        { COLUMN_NAME: 'group_id' },
        { COLUMN_NAME: 'group_label' },
        { COLUMN_NAME: 'group_mode' },
        { COLUMN_NAME: 'sequence' },
      ];
    }
    if (/SELECT DATABASE\(\)/.test(sql)) return [{ db: 'testdb' }];
    if (/INSERT INTO `fmb_api_connectors`/.test(sql)) {
      // Parse INSERT col list to capture request_config verbatim so the
      // SELECT-after-insert can echo it back for the round-trip assertion.
      const colMatch = sql.match(/INSERT INTO `fmb_api_connectors` \(([^)]+)\)/);
      if (colMatch) {
        const cols = colMatch[1].split(',').map((c) => c.trim().replace(/`/g, ''));
        lastInsert = Object.fromEntries(cols.map((c, i) => [c, params[i]]));
      }
      return { insertId: '36b7e1f1-d110-4dff-85fd-bb3ad351cab1', affectedRows: 1 };
    }
    if (/SELECT .* FROM `fmb_api_connectors` WHERE id = \?/.test(sql)) {
      // Echo back the inserted values so the CRUD factory returns a 201 with
      // the actual stored shape (request_config carries input_from_step).
      return [{
        id: '36b7e1f1-d110-4dff-85fd-bb3ad351cab1', name: 'x', url: 'http://svc.internal/echo', method: 'GET',
        auth_type: 'none', auth_config: '{}',
        request_config: lastInsert.request_config ?? '{}',
        response_config: '{}', is_active: 1, blueprint_id: null,
        section_key: null, dispatch_origin: 'edge', owner_id: null,
        group_id: lastInsert.group_id ?? null,
        group_label: lastInsert.group_label ?? null,
        group_mode: lastInsert.group_mode ?? null,
        sequence: lastInsert.sequence ?? null,
      }];
    }
    if (/INSERT INTO `fmb_feature_audit`/.test(sql)) return { affectedRows: 1 };
    if (/FROM `fmb_users`/.test(sql)) return [];
    return [];
  },
  release() {},
};
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: {
    pool: {
      ro: { getConnection: async () => conn, query: conn.query.bind(conn) },
      rw: { getConnection: async () => conn },
    },
    t: (n) => `fmb_${n}`,
  },
};

const router = require('../../src/edge/routes/app/api-connectors');
const { breaker } = cd;

let server; let baseUrl;
before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { req.user = { id: fixtureUserId('admin'), role: 'admin' }; next(); });
  app.use('/c', router);
  server = http.createServer(app);
  await new Promise((r) => server.listen(0, r));
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});
after(() => server && server.close());

beforeEach(() => {
  lastInsert = {};
  breaker._reset(VALID_UUID);
  breaker._reset('36b7e1f1-d110-4dff-85fd-bb3ad351cab1');
});

// Minimal valid connector fields (url is required by the url-guard middleware).
const BASE = {
  name: 'x', url: 'http://svc.internal/echo', method: 'GET',
  auth_type: 'none', auth_config: {}, request_config: {}, response_config: {},
};

async function post(body) {
  const res = await fetch(`${baseUrl}/c`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
  });
  return { status: res.status, body: await res.json() };
}

async function put(id, body) {
  const res = await fetch(`${baseUrl}/c/${id}`, {
    method: 'PUT',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
  });
  return { status: res.status, body: await res.json() };
}

async function del(id, body) {
  const res = await fetch(`${baseUrl}/c/${id}`, {
    method: 'DELETE',
    headers: { 'content-type': 'application/json' },
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });
  // DELETE may return 204 (no body) or a JSON body depending on the CRUD factory.
  let parsed;
  try { parsed = await res.json(); } catch { parsed = null; }
  return { status: res.status, body: parsed };
}

describe('group-field validation middleware', () => {

  // ── invalid group_id ────────────────────────────────────────────────────────

  it('400 when group_id is not a UUID', async () => {
    const r = await post({ ...BASE, group_id: 'not-a-uuid', group_mode: 'aggregation', sequence: 1 });
    assert.equal(r.status, 400);
    assert.equal(r.body.ok, false);
    assert.equal(r.body.error.code, 'BAD_REQUEST');
  });

  it('400 when group_mode is not a valid enum value', async () => {
    const r = await post({ ...BASE, group_id: VALID_UUID, group_mode: 'bogus', sequence: 1 });
    assert.equal(r.status, 400);
    assert.equal(r.body.ok, false);
    assert.equal(r.body.error.code, 'BAD_REQUEST');
  });

  it('400 when sequence is 0 (must be >= 1)', async () => {
    const r = await post({ ...BASE, group_id: VALID_UUID, group_mode: 'aggregation', sequence: 0 });
    assert.equal(r.status, 400);
    assert.equal(r.body.ok, false);
    assert.equal(r.body.error.code, 'BAD_REQUEST');
  });

  it('400 when sequence is absent but group_id is set', async () => {
    const r = await post({ ...BASE, group_id: VALID_UUID, group_mode: 'aggregation' });
    assert.equal(r.status, 400);
    assert.equal(r.body.ok, false);
    assert.equal(r.body.error.code, 'BAD_REQUEST');
  });

  it('400 when group_label exceeds 255 characters', async () => {
    const r = await post({
      ...BASE, group_id: VALID_UUID, group_mode: 'aggregation', sequence: 2,
      group_label: 'x'.repeat(256),
    });
    assert.equal(r.status, 400);
    assert.equal(r.body.ok, false);
    assert.equal(r.body.error.code, 'BAD_REQUEST');
  });

  // ── null group_id strips the whole bundle ───────────────────────────────────

  it('passes through and nulls all four when group_id is null (orphan guard)', async () => {
    // group_label and sequence are present but group_id is null → middleware must
    // zero them all out before the CRUD factory touches the row.
    const r = await post({ ...BASE, group_id: null, group_label: 'orphan', sequence: 5 });
    // The middleware should NOT return 400; it should let the request continue.
    // The CRUD factory may succeed (2xx) or fail for unrelated reasons, but it
    // must not be blocked by the group-field middleware itself.
    assert.notEqual(r.status, 400);
    // All four bundle fields must arrive at the DB layer as null (not the
    // caller-supplied orphan values), confirming the middleware stripped them.
    assert.equal(lastInsert.group_id, null, 'group_id must be null at DB layer');
    assert.equal(lastInsert.group_label, null, 'group_label must be null at DB layer');
    assert.equal(lastInsert.group_mode, null, 'group_mode must be null at DB layer');
    assert.equal(lastInsert.sequence, null, 'sequence must be null at DB layer');
  });

  // ── body has no group keys → middleware is a no-op ────────────────────────

  it('passes through without touching the body when no group key is present', async () => {
    // POST without any group_ key must not be blocked.
    const r = await post({ ...BASE });
    assert.notEqual(r.status, 400);
  });

  // ── valid full bundle passes through ────────────────────────────────────────

  it('passes through for a well-formed group bundle (POST)', async () => {
    const r = await post({
      ...BASE, group_id: VALID_UUID, group_mode: 'chain', sequence: 1, group_label: 'My group',
    });
    assert.notEqual(r.status, 400);
  });

  // ── PUT is also validated ────────────────────────────────────────────────────

  it('400 on PUT when group_mode is invalid', async () => {
    const r = await put('live', { group_id: VALID_UUID, group_mode: 'wrong', sequence: 1 });
    assert.equal(r.status, 400);
    assert.equal(r.body.error.code, 'BAD_REQUEST');
  });

  it('does not block PUT with a valid bundle shape', async () => {
    const r = await put('live', { group_id: VALID_UUID, group_mode: 'aggregation', sequence: 3 });
    // Not a 400 from the middleware; CRUD may 404 for missing row which is fine.
    assert.notEqual(r.status, 400);
  });

  // ── DELETE is skipped by this middleware ─────────────────────────────────

  it('does NOT intercept DELETE with garbage group fields (middleware skips DELETE)', async () => {
    // Sending garbage group fields in a DELETE body must not trigger the
    // group-field middleware's 400 — it only runs on POST / PUT / PATCH.
    // The CRUD factory stub may 404 (unknown id) or similar; any status is
    // acceptable as long as it is not a middleware-originated 400 BAD_REQUEST
    // with the group_id error message.
    const r = await del('some-id', { group_id: 'not-a-uuid', group_mode: 'bogus', sequence: -1 });
    const isGroupMiddleware400 =
      r.status === 400 && r.body?.error?.message === 'group_id must be a UUID';
    assert.equal(isGroupMiddleware400, false,
      'middleware must not intercept DELETE — got unexpected 400 from group-field guard');
  });

  // ── /import is exempt from this middleware ────────────────────────────────

  it('does NOT produce a 400 from this middleware on POST /import with bad group fields', async () => {
    // /import has its own payload handling; the group-field middleware must not
    // intercept it. We send deliberately bad group fields and assert we do NOT
    // get the middleware's 400 BAD_REQUEST response (import may return any other
    // status for its own reasons).
    const res = await fetch(`${baseUrl}/c/import`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ group_id: 'not-a-uuid', group_mode: 'bogus', sequence: -99 }),
    });
    const body = await res.json();
    // The middleware would return {ok:false, error:{code:'BAD_REQUEST', message:'group_id must be a UUID'}}
    // Import returns something else entirely.
    const isGroupMiddleware400 = res.status === 400 && body?.error?.message === 'group_id must be a UUID';
    assert.equal(isGroupMiddleware400, false);
  });

  // ── input_from_step opaque round-trip ────────────────────────────────────

  it('stores request_config.input_from_step verbatim (opaque JSON contract)', async () => {
    const inputFromStep = [{ var: 'id', from_sequence: 1, path: 'data.id' }];
    const r = await post({
      ...BASE,
      group_id: VALID_UUID, group_mode: 'aggregation', sequence: 2,
      request_config: { input_from_step: inputFromStep },
    });
    // Whether the CRUD factory succeeded or not, the middleware must not strip
    // request_config. A 2xx confirms end-to-end pass-through; any non-400
    // confirms the middleware didn't block it.
    assert.notEqual(r.status, 400);
    // If the CRUD factory returned a row, verify the field is present.
    if (r.status >= 200 && r.status < 300 && r.body.data) {
      const rc = typeof r.body.data.request_config === 'string'
        ? JSON.parse(r.body.data.request_config)
        : r.body.data.request_config;
      assert.deepEqual(rc.input_from_step, inputFromStep);
    }
  });

});

describe('input_from_step shape validation middleware', () => {

  // Valid group bundle so the connector's own `sequence` survives the
  // group-field middleware (group_id absent would force sequence to null).
  const GROUP = { group_id: VALID_UUID, group_mode: 'chain', sequence: 2 };

  function withIfs(inputFromStep, extra = {}) {
    return { ...BASE, ...extra, request_config: { input_from_step: inputFromStep } };
  }

  // ── not an array ──────────────────────────────────────────────────────────

  it('400 when input_from_step is not an array', async () => {
    const r = await post(withIfs({ var: 'id', from_sequence: 1, path: 'data.id' }));
    assert.equal(r.status, 400);
    assert.equal(r.body.ok, false);
    assert.equal(r.body.error.code, 'BAD_REQUEST');
    assert.match(r.body.error.message, /must be an array/);
  });

  // ── entry shape ───────────────────────────────────────────────────────────

  it('400 when an entry is missing var', async () => {
    const r = await post(withIfs([{ from_sequence: 1, path: 'data.id' }]));
    assert.equal(r.status, 400);
    assert.equal(r.body.error.code, 'BAD_REQUEST');
  });

  it('400 when var is an empty string', async () => {
    const r = await post(withIfs([{ var: '  ', from_sequence: 1, path: 'data.id' }]));
    assert.equal(r.status, 400);
    assert.equal(r.body.error.code, 'BAD_REQUEST');
  });

  it('400 when from_sequence is 0', async () => {
    const r = await post(withIfs([{ var: 'id', from_sequence: 0, path: 'data.id' }]));
    assert.equal(r.status, 400);
    assert.equal(r.body.error.code, 'BAD_REQUEST');
  });

  it('400 when from_sequence is not an integer', async () => {
    const r = await post(withIfs([{ var: 'id', from_sequence: '1', path: 'data.id' }]));
    assert.equal(r.status, 400);
    assert.equal(r.body.error.code, 'BAD_REQUEST');
  });

  it('400 when path is missing', async () => {
    const r = await post(withIfs([{ var: 'id', from_sequence: 1 }]));
    assert.equal(r.status, 400);
    assert.equal(r.body.error.code, 'BAD_REQUEST');
  });

  it('400 when path is an empty string', async () => {
    const r = await post(withIfs([{ var: 'id', from_sequence: 1, path: '' }]));
    assert.equal(r.status, 400);
    assert.equal(r.body.error.code, 'BAD_REQUEST');
  });

  // ── must reference an EARLIER step ───────────────────────────────────────

  it('400 when from_sequence equals this connector sequence', async () => {
    const r = await post(withIfs([{ var: 'id', from_sequence: 2, path: 'data.id' }], GROUP));
    assert.equal(r.status, 400);
    assert.equal(r.body.error.code, 'BAD_REQUEST');
    assert.match(r.body.error.message, /earlier step/);
  });

  it('400 when from_sequence is greater than this connector sequence', async () => {
    const r = await post(withIfs([{ var: 'id', from_sequence: 3, path: 'data.id' }], GROUP));
    assert.equal(r.status, 400);
    assert.equal(r.body.error.code, 'BAD_REQUEST');
    assert.match(r.body.error.message, /earlier step/);
  });

  // ── valid shapes pass through ────────────────────────────────────────────

  it('passes through a valid entry referencing an earlier step', async () => {
    const r = await post(withIfs([{ var: 'id', from_sequence: 1, path: 'data.id' }], GROUP));
    assert.notEqual(r.status, 400);
  });

  it('treats input_from_step null as absent (passes through)', async () => {
    const r = await post({ ...BASE, request_config: { input_from_step: null } });
    assert.notEqual(r.status, 400);
  });

  // ── partial PUT must still declare its own step position ─────────────────

  it('400 on a partial PUT declaring input_from_step entries without sequence', async () => {
    // CRUD supports partial bodies: a PUT carrying only request_config used to
    // skip the earlier-step check entirely (it keyed off req.body.sequence),
    // letting a self/future from_sequence through to a runtime chain failure.
    const r = await put('live', {
      request_config: { input_from_step: [{ var: 'id', from_sequence: 1, path: 'data.id' }] },
    });
    assert.equal(r.status, 400);
    assert.equal(r.body.error.code, 'BAD_REQUEST');
    assert.match(r.body.error.message, /sequence is required/);
  });

  it('partial PUT with input_from_step [] and no sequence passes through (clearing wiring)', async () => {
    const r = await put('live', { request_config: { input_from_step: [] } });
    assert.notEqual(r.status, 400);
  });

  it('partial PUT with input_from_step null and no sequence passes through', async () => {
    const r = await put('live', { request_config: { input_from_step: null } });
    assert.notEqual(r.status, 400);
  });

  // ── /import is exempt from this middleware ──────────────────────────────

  it('does NOT produce a 400 from this middleware on POST /import with bad input_from_step', async () => {
    // /import has its own payload handling; this middleware must not intercept
    // it. We send a deliberately non-array input_from_step and assert we do
    // NOT get this middleware's 400 response (import may return any other
    // status for its own reasons).
    const res = await fetch(`${baseUrl}/c/import`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ request_config: { input_from_step: 'garbage' } }),
    });
    const body = await res.json();
    const isIfsMiddleware400 =
      res.status === 400 && /input_from_step must be an array/.test(body?.error?.message ?? '');
    assert.equal(isIfsMiddleware400, false);
  });

});
