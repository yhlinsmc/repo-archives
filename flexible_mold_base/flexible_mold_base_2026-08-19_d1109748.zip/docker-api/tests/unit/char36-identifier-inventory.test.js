/**
 * char36-identifier-inventory.test.js — every CHAR(36) column the identifier
 * floor can reach has a WRITTEN-DOWN answer to "what does this column hold, and
 * who writes it".
 *
 * WHY THIS FILE EXISTS. The floor reads its domain from the DDL: on a mounted
 * table, every column declared CHAR(36) is refused unless it is a canonical
 * uuid. That is only correct while every one of those columns really holds a row
 * id. `hierarchy_nodes.transformer_id` does not — for a file-based transformer
 * it holds the key the module passed to `registerTransformer()`, an author-chosen
 * short string — and turning the floor on made every node bound to one
 * uneditable, including renaming it.
 *
 * The sub-step that was supposed to catch that enumerated the columns and then
 * looked for their WRITERS by searching this repository's server code. It could
 * not have found this one: the writer is the browser, seeded from a registry
 * whose file half lives partly in a gitignored directory. So the mechanism here
 * is deliberately not another search. Each column carries a written classification
 * and a named source, the mounts are BUILT (not grepped) to discover which tables
 * and columns the floor actually reaches, and the two are compared. A new CHAR(36)
 * column, or a newly mounted table, turns this red until somebody answers the
 * question for it — which is the step that was skipped, made unskippable.
 *
 * The classification is a claim about the COLUMN, and the note is the evidence
 * for it. "It is an id because it ends in _id" is exactly the reasoning that
 * produced the defect, so an entry names where the value comes from instead.
 *
 * WHAT THIS FILE CANNOT PROVE, said plainly so nobody reads more into a green
 * run than it carries:
 *   - It sees the mounts that exist in THIS TREE. A column added to a mount by a
 *     deployment's own code, or a table reached by a hand-written route rather
 *     than by this factory, is outside it entirely.
 *   - Its idea of which columns are CHAR(36) comes from `table-ddls.js`, the
 *     same source the floor reads. If a physical database disagrees with the
 *     DDL file, both are wrong together and this file says nothing.
 *   - A classification is PROSE. Nothing here checks that the sentence is true —
 *     only that somebody had to write one, and that it agrees with the mount
 *     about whether the column holds a row id. The sentence is evidence for a
 *     reviewer, not an assertion.
 *   - It says nothing about VALUES. Whether a given deployment's `users.id` is
 *     a uuid is a question about that deployment's data, answered on a real
 *     database, not here.
 */
const { describe, it, before } = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const fs = require('node:fs');

// The db module is stubbed before any route module is required: building the
// mounts must not need a database, and this file never issues a query.
const dbKey = require.resolve('../../src/edge/db');
const stubConn = {
  async query() { return []; },
  release() {},
  async beginTransaction() {}, async commit() {}, async rollback() {},
};
const stubPool = {
  rw: { async getConnection() { return stubConn; }, async query() { return []; } },
  ro: { async getConnection() { return stubConn; }, async query() { return []; } },
};
require.cache[dbKey] = {
  id: dbKey,
  filename: dbKey,
  loaded: true,
  exports: { pool: stubPool, t: (name) => `fmb_${name}`, getDynamicPool: async () => stubPool },
};

// Marks a column whose value is NOT an identifier of a row. Such a column must
// carry a `nonUuidCharColumns` escape on its mount, and the assertions below
// check that in both directions.
const NOT_AN_IDENTIFIER = Symbol('not-an-identifier');
const notAnIdentifier = (why) => ({ [NOT_AN_IDENTIFIER]: true, why });

/**
 * table → column → where the value comes from.
 *
 * A plain string means "this column holds a row identifier"; the string says
 * whose row and who supplies it. `notAnIdentifier('…')` means it does not, and
 * the mount must say so.
 */
const INVENTORY = Object.freeze({
  hierarchy_nodes: {
    id: 'this row — uuidv4() stamped by the factory, or the DDL DEFAULT (UUID())',
    parent_id: 'hierarchy_nodes.id — the node picked in the tree',
    transformer_id: notAnIdentifier(
      'the transformer REGISTRY key. transformer-db-registry.ts mergeRegistries() '
      + 'offers two kinds: a [DB] entry carries a transformers.id, but a [File] entry '
      + "carries the key its module passed to registerTransformer() — 'example' and the "
      + 'like. The picker sends either verbatim and the hierarchy dialog echoes the '
      + 'stored one back on every save.',
    ),
    linked_blueprint_id: 'hierarchy_nodes.id — the source blueprint chosen in the link dialog',
    owner_id: 'users.id — stamped server-side from req.user, never accepted from a body',
  },
  blueprint_fields: {
    id: 'this row — uuidv4() stamped by the factory, or the DDL DEFAULT (UUID())',
    blueprint_id: 'hierarchy_nodes.id — the blueprint being edited',
  },
  field_options: {
    id: 'this row — uuidv4() stamped by the factory, or the DDL DEFAULT (UUID())',
    field_id: 'blueprint_fields.id — the field the option belongs to',
  },
  variant_overrides: {
    id: 'this row — uuidv4() stamped by the factory, or the DDL DEFAULT (UUID())',
    variant_id: 'hierarchy_nodes.id — the variant carrying the override',
    field_id: 'blueprint_fields.id — the field being overridden',
  },
  blueprint_sections: {
    id: 'this row — uuidv4() stamped by the factory, or the DDL DEFAULT (UUID())',
    blueprint_id: 'hierarchy_nodes.id — the blueprint this row belongs to',
  },
  blueprint_groups: {
    id: 'this row — uuidv4() stamped by the factory, or the DDL DEFAULT (UUID())',
    blueprint_id: 'hierarchy_nodes.id — the blueprint this row belongs to',
  },
  blueprint_output_order: {
    id: 'this row — uuidv4() stamped by the factory, or the DDL DEFAULT (UUID())',
    blueprint_id: 'hierarchy_nodes.id — the blueprint this row belongs to',
  },
  decision_tables: {
    id: 'this row — uuidv4() stamped by the factory, or the DDL DEFAULT (UUID())',
    blueprint_id: 'hierarchy_nodes.id — the blueprint this row belongs to',
  },
  user_templates: {
    id: 'this row — uuidv4() stamped by the factory, or the DDL DEFAULT (UUID())',
    category_id: 'hierarchy_nodes.id — denormalised ancestor, re-stamped on reparent',
    release_id: 'hierarchy_nodes.id — denormalised ancestor',
    blueprint_id: 'hierarchy_nodes.id — the blueprint the record was filled against',
    variant_id: 'hierarchy_nodes.id — the variant chosen for the record',
    parent_id: 'user_templates.id — the parent record in the record tree',
    owner_id: 'users.id — stamped server-side',
    flow_last_run_id: 'flow_recipe_runs.id — server-only (serverOnlyColumns), never from a body',
  },
  flow_recipes: {
    id: 'this row — uuidv4() stamped by the factory, or the DDL DEFAULT (UUID())',
    owner_id: 'users.id — stamped server-side',
    blueprint_id: 'hierarchy_nodes.id — the blueprint this row belongs to',
    approved_by: 'users.id — written by the approval endpoint, not by a body',
  },
  flow_recipe_steps: {
    id: 'this row — uuidv4() stamped by the factory, or the DDL DEFAULT (UUID())',
    recipe_id: 'flow_recipes.id — the recipe the step belongs to',
  },
  flow_recipe_runs: {
    id: 'this row — uuidv4() stamped by the factory, or the DDL DEFAULT (UUID())',
    recipe_id: 'flow_recipes.id — the recipe this run belongs to',
    template_id: 'user_templates.id — the record the run was dispatched for',
    blueprint_id: 'hierarchy_nodes.id — the blueprint this row belongs to',
    actor_id: 'users.id — stamped by the run serializer on create',
  },
  api_connectors: {
    id: 'this row — uuidv4() stamped by the factory, or the DDL DEFAULT (UUID())',
    owner_id: 'users.id — stamped server-side',
    blueprint_id: 'hierarchy_nodes.id — the blueprint this row belongs to',
    group_id: 'a bundle key. NOT a row in another table — the client generates it, and '
      + 'the mount already pins it to the uuid shape itself (api-connectors/index.js '
      + "'group_id must be a UUID'), so the floor is agreeing with a rule that is "
      + 'already enforced rather than imposing a new one.',
    approved_by: 'users.id — written by the approval endpoint',
  },
  cap_scenarios: {
    id: 'this row — uuidv4() stamped by the factory, or the DDL DEFAULT (UUID())',
    owner_id: 'users.id — stamped server-side',
  },
  cap_sites: {
    id: 'this row — uuidv4() stamped by the factory, or the DDL DEFAULT (UUID())',
    scenario_id: 'cap_scenarios.id — forced from the URL by bindScenarioScope' },
  cap_teams: {
    id: 'this row — uuidv4() stamped by the factory, or the DDL DEFAULT (UUID())',
    scenario_id: 'cap_scenarios.id — forced from the URL' },
  cap_disk_combos: {
    id: 'this row — uuidv4() stamped by the factory, or the DDL DEFAULT (UUID())',
    scenario_id: 'cap_scenarios.id — forced from the URL' },
  cap_hardware_specs: {
    id: 'this row — uuidv4() stamped by the factory, or the DDL DEFAULT (UUID())',
    scenario_id: 'cap_scenarios.id — forced from the URL' },
  cap_vm_profiles: {
    id: 'this row — uuidv4() stamped by the factory, or the DDL DEFAULT (UUID())',
    scenario_id: 'cap_scenarios.id — forced from the URL' },
  cap_hypervisors: {
    id: 'this row — uuidv4() stamped by the factory, or the DDL DEFAULT (UUID())',
    scenario_id: 'cap_scenarios.id — forced from the URL',
    site_id: 'cap_sites.id — checked and locked by the §17.1a reference validator',
    spec_id: 'cap_hardware_specs.id — checked and locked by the same validator',
  },
  cap_databases: {
    id: 'this row — uuidv4() stamped by the factory, or the DDL DEFAULT (UUID())',
    scenario_id: 'cap_scenarios.id — forced from the URL',
    profile_id: 'cap_vm_profiles.id — the sizing profile chosen for this database',
    disk_combo_id: 'cap_disk_combos.id — the disk combination chosen for this database',
    team_id: 'cap_teams.id — the owning team chosen for this database',
  },
  cap_vms: {
    id: 'this row — uuidv4() stamped by the factory, or the DDL DEFAULT (UUID())',
    scenario_id: 'cap_scenarios.id — forced from the URL',
    hypervisor_id: 'cap_hypervisors.id — the host this VM is placed on',
    site_id: 'cap_sites.id — the site this VM is placed at',
    sizing_profile_id: 'cap_vm_profiles.id — the sizing profile chosen for this VM',
    disk_combo_id: 'cap_disk_combos.id — the disk combination chosen for this VM',
    team_id: 'cap_teams.id — the owning team chosen for this VM',
    database_id: 'cap_databases.id — the database this VM serves',
  },
  cap_db_instances: {
    id: 'this row — uuidv4() stamped by the factory, or the DDL DEFAULT (UUID())',
    scenario_id: 'cap_scenarios.id — forced from the URL',
    vm_id: 'cap_vms.id — must be a db_host, re-read under the FK lock',
    database_id: 'cap_databases.id — the database this instance belongs to',
  },
  cap_custom_groups: {
    id: 'this row — uuidv4() stamped by the factory, or the DDL DEFAULT (UUID())',
    scenario_id: 'cap_scenarios.id — forced from the URL',
    team_id: 'cap_teams.id — the owning team chosen for this group',
  },
  cap_custom_group_members: {
    id: 'this row — uuidv4() stamped by the factory, or the DDL DEFAULT (UUID())',
    scenario_id: 'cap_scenarios.id — forced from the URL',
    group_id: 'cap_custom_groups.id — the custom group this membership row joins',
    member_vm_id: 'cap_vms.id — the VM this membership row names',
    member_instance_id: 'cap_db_instances.id — the instance this membership row names',
  },
  cap_rules: {
    id: 'this row — uuidv4() stamped by the factory, or the DDL DEFAULT (UUID())',
    scenario_id: 'cap_scenarios.id — forced from the URL',
    custom_group_id: 'cap_custom_groups.id — a group in THIS scenario',
    overrides_rule_id: 'cap_rules.id — the GLOBAL template rule this row re-parameterises',
  },
  cap_waivers: {
    id: 'this row — uuidv4() stamped by the factory, or the DDL DEFAULT (UUID())',
    scenario_id: 'cap_scenarios.id — forced from the URL',
    rule_id: 'cap_rules.id — a global template rule or a scenario-local one',
    created_by: 'users.id — stamped by the audit-column middleware',
  },
});

const APP_ROUTES = fs.realpathSync(path.join(__dirname, '../../src/edge/routes/app'));

/**
 * The modules the server mounts under `/edge/app` — DERIVED, not listed.
 *
 * A hand-kept list of six module names sat here, and it was the same shape as
 * the defect this whole file exists to end: every assertion below is "for every
 * table the factory recorded", so a SEVENTH route module's mounts are not
 * merely unchecked, they are invisible — nothing records them, no entry is
 * demanded, and the file stays green while a table's CHAR(36) columns are
 * floored with nobody having answered what they hold. Removal was caught,
 * addition was not, which is the direction that matters.
 *
 * So the corpus is generated: the shape `index-edge.js` mounts is a directory
 * with an `index.js`, or a `.js` file sitting directly in `app/`. Requiring one
 * builds its routers, and the factory records each mount as it is built.
 */
function everyEntryModule() {
  const found = [];
  for (const entry of fs.readdirSync(APP_ROUTES, { withFileTypes: true })) {
    if (entry.isDirectory()) {
      const index = path.join(APP_ROUTES, entry.name, 'index.js');
      if (fs.existsSync(index)) found.push(index);
    } else if (entry.isFile() && entry.name.endsWith('.js')) {
      found.push(path.join(APP_ROUTES, entry.name));
    }
  }
  return found.sort();
}

/** Every non-test `.js` file under `app/`, at any depth. */
function everyRouteFile(dir = APP_ROUTES, out = []) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      if (entry.name !== '__tests__' && entry.name !== 'node_modules') everyRouteFile(full, out);
    } else if (entry.isFile() && entry.name.endsWith('.js') && !entry.name.endsWith('.test.js')) {
      out.push(full);
    }
  }
  return out.sort();
}

/**
 * Does this file CALL the factory? The line that defines it is not a call site,
 * and a file matching only that would demand an explanation nobody can give.
 */
function callsTheFactory(file) {
  return fs.readFileSync(file, 'utf8').split('\n').some(
    (line) => /createCrudRoutes\s*\(/.test(line) && !/function\s+createCrudRoutes\s*\(/.test(line),
  );
}

let escapes = null;

before(() => {
  // Requiring these builds every factory mount this server exposes; the factory
  // records each mount's declared CHAR(36) columns and its escapes as it does.
  for (const mod of everyEntryModule()) {
    require(mod);
  }
  ({ declaredCharColumnEscapes: escapes } = require('../../src/edge/routes/app/schema/crud-factory'));
});

const sorted = (a) => [...a].sort();

describe('the CHAR(36) columns the identifier floor reaches', () => {
  it('are all classified — a new column, or a newly mounted table, has to be answered for', () => {
    const byTable = new Map();
    for (const entry of escapes) {
      const prev = byTable.get(entry.table);
      if (prev) {
        assert.deepEqual(
          sorted(prev.exempt), sorted(entry.exempt),
          `${entry.table} is mounted twice with different nonUuidCharColumns — one column, two answers`,
        );
        continue;
      }
      byTable.set(entry.table, entry);
    }
    assert.ok(byTable.size > 0, 'no mount was built — the sweep above found no route module');

    for (const [table, entry] of byTable) {
      const classified = INVENTORY[table];
      assert.ok(
        classified,
        `${table} is mounted on the CRUD factory but has no entry here. Every CHAR(36) `
        + 'column of a mounted table is refused unless it is a canonical uuid, so say what '
        + `each of ${JSON.stringify(entry.declared)} holds and who writes it.`,
      );
      assert.deepEqual(
        sorted(Object.keys(classified)), sorted(entry.declared),
        `${table}: the classification and the DDL disagree about which columns are CHAR(36)`,
      );
      for (const [column, note] of Object.entries(classified)) {
        const source = note && note[NOT_AN_IDENTIFIER] ? note.why : note;
        assert.equal(
          typeof source === 'string' && source.trim().length > 20, true,
          `${table}.${column}: name where the value comes from, not just that it exists`,
        );
      }
    }

    for (const table of Object.keys(INVENTORY)) {
      assert.ok(
        byTable.has(table),
        `${table} is classified here but no longer mounted — delete the entry rather than `
        + 'leaving a claim nobody checks',
      );
    }
  });

  it('are floored exactly where the classification says they hold a row id', () => {
    for (const entry of escapes) {
      const classified = INVENTORY[entry.table] || {};
      const shouldBeExempt = Object.entries(classified)
        .filter(([, note]) => note && note[NOT_AN_IDENTIFIER])
        .map(([column]) => column);
      assert.deepEqual(
        sorted(entry.exempt), sorted(shouldBeExempt),
        `${entry.table}: nonUuidCharColumns and the classification disagree. Either the `
        + 'column holds a row id (then the floor judges it and there is no escape) or it '
        + 'does not (then the mount declares it) — the two cannot say different things.',
      );
    }
  });

  it('were discovered by sweeping the route tree, so a seventh module cannot hide', () => {
    // The completeness claim, made mechanical. The sweep above loads entry
    // modules; a file that CALLS the factory from somewhere no entry module
    // reaches would build mounts this file never sees — which is exactly the
    // invisibility the hand-kept list had. So: every factory call site in the
    // tree must live in a file the sweep ended up loading.
    const callSites = everyRouteFile().filter(callsTheFactory);
    assert.ok(
      callSites.length > 0,
      'no file under src/edge/routes/app calls createCrudRoutes — the scan is looking in the wrong place',
    );
    const missed = callSites.filter((file) => !require.cache[file]);
    assert.deepEqual(
      missed.map((f) => path.relative(APP_ROUTES, f)), [],
      'these files mount the CRUD factory but nothing the sweep loads reaches them, so their '
      + 'tables never reach the classification above. Mount them from a module under app/, or '
      + 'say here why a factory mount that no route tree reaches exists at all.',
    );
  });

  it('include the column this inventory was rebuilt for', () => {
    // Named rather than left implicit: this file exists because a column that
    // holds a registry key was floored as though it held a row id, and the case
    // that proves the exemption still works is in the real-DB file.
    const entry = escapes.find((e) => e.table === 'hierarchy_nodes');
    assert.ok(entry, 'hierarchy_nodes is not mounted');
    assert.deepEqual(entry.exempt, ['transformer_id']);
  });
});
