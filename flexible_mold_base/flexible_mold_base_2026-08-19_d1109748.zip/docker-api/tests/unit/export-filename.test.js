/**
 * Parity tests for the backend buildExportFilename impl. Asserted against the
 * SAME fixture as the frontend test (src/platform/lib/__tests__/export-filename
 * .test.ts), so the two-runtime impls cannot drift.
 */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { buildExportFilename, contentDispositionAttachment } = require('../../src/shared/lib/export-filename');

const fixture = JSON.parse(
  fs.readFileSync(path.join(__dirname, '../../src/shared/lib/export-filename.fixture.json'), 'utf8'),
);

test('buildExportFilename (BE) matches the shared parity fixture', () => {
  for (const c of fixture.cases) {
    const date = new Date(
      c.date[0], c.date[1], c.date[2], c.date[3], c.date[4], c.date[5], c.date[6] ?? 0,
    );
    assert.equal(
      buildExportFilename({ kind: c.kind, entity: c.entity, ext: c.ext, date }),
      c.expected,
      `${c.kind}/${c.entity}`,
    );
  }
});

test('buildExportFilename (BE) defaults the date to now', () => {
  assert.match(
    buildExportFilename({ kind: 'output', entity: 'x', ext: 'json' }),
    /^output_x_\d{8}-\d{6}-\d{3}\.json$/,
  );
});

test('buildExportFilename (BE) separates two exports of the same entity inside one second', () => {
  // The reason the stamp carries milliseconds at all: a second export handed the
  // first one's filename is saved by the browser under a suffixed name.
  const parts = { kind: 'seed', entity: 'fmbdb', ext: 'sql' };
  assert.notEqual(
    buildExportFilename({ ...parts, date: new Date(2026, 5, 6, 14, 30, 22, 480) }),
    buildExportFilename({ ...parts, date: new Date(2026, 5, 6, 14, 30, 22, 120) }),
  );
});

test('contentDispositionAttachment keeps ASCII names verbatim', () => {
  assert.equal(
    contentDispositionAttachment('seed_fmbdb_20260606-143022.sql'),
    "attachment; filename=\"seed_fmbdb_20260606-143022.sql\"; filename*=UTF-8''seed_fmbdb_20260606-143022.sql",
  );
});

test('contentDispositionAttachment ASCII-folds non-ASCII + adds RFC 5987 filename*', () => {
  // A CJK db/schema or blueprint name must not reach the raw header (Node would
  // throw ERR_INVALID_CHAR). ASCII fallback uses underscores; filename* carries
  // the percent-encoded original.
  const header = contentDispositionAttachment('blueprint_網路_20260606-143022.yaml');
  assert.match(header, /^attachment; filename="blueprint_[_]+20260606-143022\.yaml"; filename\*=UTF-8''/);
  assert.ok(/^[\x20-\x7e]+$/.test(header), 'entire header must be ASCII-only');
  assert.ok(header.includes(encodeURIComponent('blueprint_網路_20260606-143022.yaml')));
});
