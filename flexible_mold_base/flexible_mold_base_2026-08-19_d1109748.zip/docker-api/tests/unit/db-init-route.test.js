const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');

const dbKey = require.resolve('../../src/edge/db');
const schemaInitKey = require.resolve('../../src/edge/routes/platform/setup/schema-init');

let grantRows = [];
let existingRows = [];
let ddlCount = 0;
let auditRows = [];
let ddlShouldAlreadyExist = false;
let ddlShouldError = false;
let migrationsRunCount = 0;
let migrationsRunWithConn = false;
let migrationsShouldThrow = false;

function makeConn(kind = 'infra') {
  return {
    async query(sql, params) {
      if (/SELECT COUNT\(\*\) AS cnt/i.test(sql)) return [{ cnt: 0 }];
      if (/SHOW GRANTS/i.test(sql)) return grantRows;
      if (/information_schema\.TABLES/i.test(sql)) return existingRows;
      if (/INSERT INTO `app_feature_audit`/i.test(sql)) {
        if (kind !== 'infra') throw new Error('dynamic schema has no infra audit table');
        auditRows.push({ kind, metadata: JSON.parse(params[2] || params[1]) });
        return { affectedRows: 1 };
      }
      if (/^CREATE TABLE/i.test(sql.trim())) {
        if (ddlShouldAlreadyExist) {
          throw new Error("Table 'app_users' already exists");
        }
        if (ddlShouldError) {
          const err = new Error('Access denied for user');
          err.code = 'ER_ACCESS_DENIED';
          throw err;
        }
        ddlCount += 1;
        return { affectedRows: 0 };
      }
      if (/UPDATE `app_access_rules`/i.test(sql)) return { affectedRows: 0 };
      return [];
    },
    release() {},
  };
}

require.cache[dbKey] = {
  id: dbKey,
  filename: dbKey,
  loaded: true,
  exports: {
    pool: {
      rw: {
        async getConnection() {
          return makeConn('infra');
        },
      },
    },
    t: (name) => `app_${name}`,
    isPoolReady: () => true,
    PLATFORM_SCHEMA_VERSION: '3.2.0',
    getDbConfig: () => ({
      database: 'app',
      user: 'real_service_user',
      tablePrefix: 'app_',
    }),
    getDbConfigFull: () => ({
      database: 'app',
      user: 'real_service_user',
      tablePrefix: 'app_',
    }),
    getDynamicPool: async () => ({
      rw: {
        async getConnection() {
          return makeConn('dynamic');
        },
      },
    }),
    runSchemaMigrations: async (conn) => {
      migrationsRunCount += 1;
      migrationsRunWithConn = conn != null && typeof conn.query === 'function';
      if (migrationsShouldThrow) throw new Error('stamp-fail');
      return undefined;
    },
  },
};

const routes = {};
const router = {
  post(path, handler) { routes[`POST ${path}`] = handler; },
  get(path, handler) { routes[`GET ${path}`] = handler; },
};

before(() => {
  require('../../src/edge/routes/platform/setup/schema-init')(router);
});

after(() => {
  delete require.cache[dbKey];
  delete require.cache[schemaInitKey];
});

function makeReq(body = {}) {
  return { body, user: { id: 'admin-1', role: 'admin', email: 'admin@example.test' } };
}

function makeRes() {
  return {
    statusCode: 200,
    body: null,
    status(code) {
      this.statusCode = code;
      return this;
    },
    json(body) {
      this.body = body;
      return this;
    },
  };
}

test('/api/setup/init-db: operator missing ALTER on existing tables → 400 with DDL code', async () => {
  grantRows = [
    { G: "GRANT SELECT, INSERT, UPDATE, DELETE, CREATE ON `app`.* TO 'real_service_user'@'%'" },
  ];
  existingRows = [{ TABLE_NAME: 'app_users' }];
  ddlCount = 0;
  auditRows = [];

  const res = makeRes();
  await routes['POST /init-db'](makeReq(), res);

  assert.equal(res.statusCode, 400);
  assert.equal(res.body.error.code, 'PREFLIGHT_MISSING_PRIVILEGES_FOR_DDL');
  assert.match(res.body.error.grantHint, /GRANT ALTER ON `app`\.\* TO 'app_user'@'%'/);
  assert.doesNotMatch(JSON.stringify(res.body), /real_service_user/);
  assert.equal(ddlCount, 0);
  assert.equal(auditRows.length, 0, 'read-only DDL preflight failure must not write feature_audit');
});

test('/api/setup/init-db: engine-only DDL preflight failure → 400 with engine context, no audit', async () => {
  grantRows = [
    { G: "GRANT ALTER ON `tenant`.* TO 'real_service_user'@'%'" },
  ];
  existingRows = [];
  ddlCount = 0;
  auditRows = [];

  const res = makeRes();
  await routes['POST /init-db'](makeReq({ database: 'tenant' }), res);

  assert.equal(res.statusCode, 400);
  assert.equal(res.body.error.code, 'PREFLIGHT_MISSING_PRIVILEGES_FOR_DDL');
  assert.equal(ddlCount, 0);
  assert.equal(auditRows.length, 0, 'no audit row for read-only probe failure');
});

test('/api/setup/init-db: DBA user with DDL grants → success', async () => {
  grantRows = [
    { G: "GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, ALTER ON `app`.* TO 'real_service_user'@'%'" },
  ];
  existingRows = [];
  ddlCount = 0;
  auditRows = [];
  ddlShouldAlreadyExist = false;
  ddlShouldError = false;

  const res = makeRes();
  await routes['POST /init-db'](makeReq(), res);

  assert.equal(res.statusCode, 200);
  assert.equal(res.body.error, null);
  assert.equal(res.body.data.target, 'app');
  assert.ok(ddlCount > 0, 'expected DDL statements to run');
});

test('/api/setup/init-db: all-tables success stamps version via runSchemaMigrations', async () => {
  grantRows = [
    { G: "GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, ALTER ON `app`.* TO 'real_service_user'@'%'" },
  ];
  existingRows = [];
  ddlCount = 0;
  auditRows = [];
  ddlShouldAlreadyExist = false;
  ddlShouldError = false;
  migrationsRunCount = 0;
  migrationsRunWithConn = false;

  const res = makeRes();
  await routes['POST /init-db'](makeReq(), res);

  assert.equal(res.statusCode, 200);
  assert.equal(migrationsRunCount, 1, 'init-db must run migrations once to stamp the version');
  assert.equal(migrationsRunWithConn, true, 'runSchemaMigrations must receive the infra writer connection');
});

test('/api/setup/init-db: engine-only target does NOT run migrations', async () => {
  grantRows = [
    { G: "GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, ALTER ON `tenant`.* TO 'real_service_user'@'%'" },
  ];
  existingRows = [];
  ddlCount = 0;
  auditRows = [];
  ddlShouldAlreadyExist = false;
  ddlShouldError = false;
  migrationsRunCount = 0;
  migrationsRunWithConn = false;

  const res = makeRes();
  await routes['POST /init-db'](makeReq({ database: 'tenant' }), res);

  assert.equal(res.statusCode, 200);
  assert.equal(migrationsRunCount, 0, 'engine-only DBs have no system_settings — must not stamp');
});

test('/api/setup/init-db: partial DDL failure does NOT stamp (incomplete schema must not look aligned)', async () => {
  grantRows = [
    { G: "GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, ALTER ON `app`.* TO 'real_service_user'@'%'" },
  ];
  existingRows = [];
  ddlCount = 0;
  auditRows = [];
  ddlShouldAlreadyExist = false;
  ddlShouldError = true; // every CREATE TABLE throws → recorded in errors[], loop continues
  migrationsRunCount = 0;
  migrationsRunWithConn = false;

  try {
    const res = makeRes();
    await routes['POST /init-db'](makeReq(), res);

    assert.equal(res.statusCode, 200);
    assert.ok(res.body.data.errors.length > 0, 'DDL errors must be reported');
    assert.equal(migrationsRunCount, 0, 'a partial create must not stamp the schema version');
  } finally {
    ddlShouldError = false;
  }
});

test('/api/setup/init-db: stamp failure is best-effort — table creation still returns 200', async () => {
  grantRows = [
    { G: "GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, ALTER ON `app`.* TO 'real_service_user'@'%'" },
  ];
  existingRows = [];
  ddlCount = 0;
  auditRows = [];
  ddlShouldAlreadyExist = false;
  ddlShouldError = false;
  migrationsRunCount = 0;
  migrationsRunWithConn = false;
  migrationsShouldThrow = true;

  try {
    const res = makeRes();
    await routes['POST /init-db'](makeReq(), res);

    assert.equal(res.statusCode, 200, 'a stamp hiccup must not fail the table-creation response');
    assert.equal(res.body.error, null);
    assert.equal(migrationsRunCount, 1, 'the runner was invoked (and threw) on the all-tables path');
  } finally {
    migrationsShouldThrow = false;
  }
});
