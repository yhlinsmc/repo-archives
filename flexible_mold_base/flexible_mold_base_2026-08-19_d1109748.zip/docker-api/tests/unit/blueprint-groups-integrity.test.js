/**
 * blueprint-groups-integrity.test.js
 *
 * PR-A color-groups integrity batch, blueprint_groups surface:
 *   - Item 1: generic CRUD POST uniqueness guard on (blueprint_id, group_key)
 *     — app-layer pre-check 409 DUPLICATE_GROUP_KEY AND errno-1062 mapping.
 *   - Item 5: generic CRUD POST + /replace group_key slug validation
 *     (INVALID_KEY_FORMAT), enforced only on genuinely new keys in /replace.
 *   - Item 2: POST /blueprint_groups/delete-with-reassign transactional
 *     delete + field reassign/clear (atomicity, authz, validation).
 *
 * Spy-pool HTTP harness mirrors blueprint-output-order-replace.test.js.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const { answerParentIdProbe } = require('../helpers/parent-id-probe');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../src/edge/db');

let conn;

// Flexible spy connection. `scripts` is an array of [regex, responseOrFn].
// Falls back to safe defaults: DATABASE() → a name, information_schema.COLUMNS
// → [] (so getActualColumnSet caches null = "unknown, keep all keys"), the
// linked-blueprint probe → [] (not linked). Anything else unmatched throws so a
// test surfaces an unexpected query.
function makeConn(scripts = []) {
  const queries = [];
  const events = [];
  return {
    queries,
    events,
    async query(sql, params) {
      queries.push({ sql, params });
      for (const [matcher, response] of scripts) {
        if (matcher.test(sql)) {
          return typeof response === 'function' ? response(sql, params) : response;
        }
      }
      if (/SELECT DATABASE\(\)/i.test(sql)) return [{ db: 'testdb' }];
      // The identity question the destructive gates now ask the ENGINE
      // (write-value.js `sameStoredValue`): are these two spellings one stored
      // value? Answered here the way the column's collation answers it — case
      // folded, trailing space padded — so this double cannot disagree with the
      // database about whether a target names the row being deleted. The
      // instrument that settles it for real is
      // tests/integration/destructive-gates-real-db.test.js.
      if (/CHARACTER_SET_NAME AS cs/.test(sql)) {
        return [{ cs: 'utf8mb4', co: 'utf8mb4_general_ci' }];
      }
      if (/<=>/.test(sql) && / AS same/.test(sql)) {
        const fold = (v) => String(v).toLowerCase().replace(/\s+$/, '');
        return [{ same: fold((params || [])[0]) === fold((params || [])[1]) ? 1 : 0 }];
      }
      if (/information_schema\.COLUMNS/i.test(sql)) return [];
      if (/SELECT linked_blueprint_id FROM/i.test(sql)) return [];
      // The factory asks which spelling the parent row really carries before it
      // binds one. Answered rather than thrown on — see tests/helpers.
      const parentId = answerParentIdProbe(sql, params);
      if (parentId) return parentId;
      throw new Error(`Unmatched query: ${sql.slice(0, 90)}`);
    },
    async beginTransaction() { events.push('begin'); },
    async commit() { events.push('commit'); },
    async rollback() { events.push('rollback'); },
    release() { events.push('release'); },
  };
}

const poolSpy = {
  rw: { async getConnection() { return conn; } },
  ro: { async getConnection() { return conn; } },
};

require.cache[dbKey] = {
  id: dbKey,
  filename: dbKey,
  loaded: true,
  exports: {
    pool: poolSpy,
    t: (name) => `fmb_${name}`,
    getDynamicPool: async () => poolSpy,
  },
};

const router = require('../../src/edge/routes/app/schema');
// Clear the (db,table) column-set cache between tests so a null probe result
// from one test does not leak into the next.
const { __clearColumnSetCache } = router.__test__;

let server;
let port;

// Mutable per-request identity so a test can act as admin, a specific editor,
// or a plain user.
let authUser = { id: '5b729f1e-5c0b-447c-8144-3210469bc62c', email: 'admin@test', role: 'admin' };

before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => {
    req.user = authUser;
    next();
  });
  app.use('/edge/app/schema', router);
  await new Promise((resolve) => {
    server = app.listen(0, '127.0.0.1', () => {
      port = server.address().port;
      resolve();
    });
  });
});

after(async () => {
  await new Promise((resolve) => server.close(resolve));
  delete require.cache[dbKey];
});

beforeEach(() => {
  conn = null;
  __clearColumnSetCache();
  authUser = { id: '5b729f1e-5c0b-447c-8144-3210469bc62c', email: 'admin@test', role: 'admin' };
});

function send(method, path, body) {
  return new Promise((resolve, reject) => {
    const data = Buffer.from(JSON.stringify(body), 'utf-8');
    const req = http.request({
      method, host: '127.0.0.1', port, path,
      headers: { 'Content-Type': 'application/json', 'Content-Length': data.length },
    }, (res) => {
      const chunks = [];
      res.on('data', (c) => chunks.push(c));
      res.on('end', () => {
        const raw = Buffer.concat(chunks).toString('utf-8');
        let json = null;
        try { json = raw ? JSON.parse(raw) : null; } catch { /* */ }
        resolve({ status: res.statusCode, json });
      });
    });
    req.on('error', reject);
    req.write(data);
    req.end();
  });
}
const post = (p, b) => send('POST', p, b);
const put = (p, b) => send('PUT', p, b);

describe('blueprint_groups CRUD POST — slug + uniqueness (items 1 & 5)', () => {
  it('rejects a non-slug group_key with 400 INVALID_KEY_FORMAT', async () => {
    conn = makeConn();
    const res = await post('/edge/app/schema/blueprint_groups', {
      blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', group_key: 'Bad Key', display_label: 'X', color_key: 'blue', sort_order: 1,
    });
    assert.equal(res.status, 400);
    assert.equal(res.json.error.code, 'INVALID_KEY_FORMAT');
  });

  it('rejects a duplicate (blueprint_id, group_key) with 409 DUPLICATE_GROUP_KEY (app-layer)', async () => {
    conn = makeConn([
      [/SELECT id FROM `fmb_blueprint_groups` WHERE `blueprint_id` = \? AND `group_key` = \? LIMIT 1/i, [{ id: '11242ba8-40c3-43d1-8137-9d4c3d0636bf' }]],
    ]);
    const res = await post('/edge/app/schema/blueprint_groups', {
      blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', group_key: 'lane_a', display_label: 'A', color_key: 'blue', sort_order: 1,
    });
    assert.equal(res.status, 409);
    assert.equal(res.json.error.code, 'DUPLICATE_GROUP_KEY');
    assert.ok(conn.events.includes('rollback'));
  });

  it('inserts a valid, unique group_key (200)', async () => {
    conn = makeConn([
      [/SELECT id FROM `fmb_blueprint_groups` WHERE `blueprint_id` = \? AND `group_key` = \? LIMIT 1/i, []],
      [/^INSERT INTO `fmb_blueprint_groups`/i, { affectedRows: 1 }],
      [/^SELECT \* FROM `fmb_blueprint_groups`/i, [{ id: 'c30b82f6-daee-4dc1-803b-3832d41ed110', blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', group_key: 'lane_a' }]],
    ]);
    const res = await post('/edge/app/schema/blueprint_groups', {
      blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', group_key: 'lane_a', display_label: 'A', color_key: 'blue', sort_order: 1,
    });
    assert.equal(res.status, 200);
    assert.ok(conn.events.includes('commit'));
  });

  it('maps errno 1062 from the UNIQUE index to 409 DUPLICATE_GROUP_KEY', async () => {
    conn = makeConn([
      [/SELECT id FROM `fmb_blueprint_groups` WHERE `blueprint_id` = \? AND `group_key` = \? LIMIT 1/i, []],
      [/^INSERT INTO `fmb_blueprint_groups`/i, () => { const e = new Error('dup'); e.errno = 1062; throw e; }],
    ]);
    const res = await post('/edge/app/schema/blueprint_groups', {
      blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', group_key: 'lane_a', display_label: 'A', color_key: 'blue', sort_order: 1,
    });
    assert.equal(res.status, 409);
    assert.equal(res.json.error.code, 'DUPLICATE_GROUP_KEY');
  });
});

describe('blueprint_groups CRUD PUT — reparent uniqueness (item 1, Codex P2)', () => {
  // The stored row is (blueprint_id='a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', group_key='lane_a'). `collisions`
  // maps a "scope|key" pair to a boolean "a conflicting row exists". The dup
  // check must be run against the EFFECTIVE destination pair; `dupParams`
  // captures what the endpoint actually queried so tests can assert it.
  function putScript(collisions, dupParams) {
    return [
      // link-check: stored blueprint_id lookup (isLinkedParentLocked, rowId form)
      [/SELECT `blueprint_id` AS bid FROM `fmb_blueprint_groups` WHERE id/i, [{ bid: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26' }]],
      // uniqueWithin: stored scope + key
      [/AS scope, `group_key` AS keyval FROM `fmb_blueprint_groups`/i, [{ scope: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', keyval: 'lane_a' }]],
      // uniqueWithin dup check against the effective pair
      [/SELECT id FROM `fmb_blueprint_groups`\s+WHERE `blueprint_id` = \? AND `group_key` = \? AND id <> \?/i,
        (sql, params) => {
          dupParams.push({ scope: params[0], key: params[1] });
          return collisions.has(`${params[0]}|${params[1]}`) ? [{ id: '3ffc5e4c-7590-40b9-8e30-078408c03488' }] : [];
        }],
      [/^UPDATE `fmb_blueprint_groups`/i, { affectedRows: 1 }],
      [/^SELECT \* FROM `fmb_blueprint_groups`/i, [{ id: 'a92dd756-2cb0-40e0-885d-07dd24332c67', blueprint_id: '07cbb7a8-0535-464f-80c7-81559ef886e3', group_key: 'lane_a' }]],
    ];
  }

  it('rejects a key-omitted reparent that collides in the destination blueprint (409)', async () => {
    const dupParams = [];
    conn = makeConn(putScript(new Set(['07cbb7a8-0535-464f-80c7-81559ef886e3|lane_a']), dupParams));
    const res = await put('/edge/app/schema/blueprint_groups/g1', { blueprint_id: '07cbb7a8-0535-464f-80c7-81559ef886e3' });
    assert.equal(res.status, 409);
    assert.equal(res.json.error.code, 'DUPLICATE_GROUP_KEY');
    // Effective pair = destination scope + STORED key (key omitted).
    assert.deepEqual(dupParams[0], { scope: '07cbb7a8-0535-464f-80c7-81559ef886e3', key: 'lane_a' });
    assert.ok(conn.events.includes('rollback'));
  });

  it('allows a reparent with no collision in the destination (200)', async () => {
    const dupParams = [];
    conn = makeConn(putScript(new Set(), dupParams)); // no collisions
    const res = await put('/edge/app/schema/blueprint_groups/g1', { blueprint_id: '07cbb7a8-0535-464f-80c7-81559ef886e3' });
    assert.equal(res.status, 200);
    assert.deepEqual(dupParams[0], { scope: '07cbb7a8-0535-464f-80c7-81559ef886e3', key: 'lane_a' });
    assert.ok(conn.events.includes('commit'));
  });

  it('ignores a group_key body on reparent (immutable): checks the stored key, not the requested one', async () => {
    // group_key is immutable via the generic PUT (immutableColumns) — it can only
    // change through rename-with-cascade. A reparent that also tries to rename is
    // treated as a plain reparent: the requested 'lane_b' is stripped, so the
    // uniqueness check runs against the STORED key 'lane_a' in the destination.
    const dupParams = [];
    conn = makeConn(putScript(new Set(['07cbb7a8-0535-464f-80c7-81559ef886e3|lane_b']), dupParams));
    const res = await put('/edge/app/schema/blueprint_groups/g1', { blueprint_id: '07cbb7a8-0535-464f-80c7-81559ef886e3', group_key: 'lane_b' });
    // No collision on the STORED key in bp-2 → 200 (the requested rename to
    // lane_b was ignored, so the bp-2|lane_b collision never applies).
    assert.equal(res.status, 200);
    assert.deepEqual(dupParams[0], { scope: '07cbb7a8-0535-464f-80c7-81559ef886e3', key: 'lane_a' });
  });

  it('rejects a group_key-only PUT as no-op (immutable: nothing left to update)', async () => {
    // group_key stripped → the update body is empty → 400. The key can only be
    // changed through the rename-with-cascade endpoint.
    conn = makeConn([
      [/SELECT `blueprint_id` AS bid FROM `fmb_blueprint_groups` WHERE id/i, [{ bid: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26' }]],
    ]);
    const res = await put('/edge/app/schema/blueprint_groups/g1', { group_key: 'lane_c' });
    assert.equal(res.status, 400);
    assert.ok(conn.events.includes('rollback'));
  });
});

describe('POST /blueprint_groups/rename-with-cascade (Bug 1)', () => {
  it('400 on missing blueprint_id', async () => {
    conn = makeConn();
    const res = await post('/edge/app/schema/blueprint_groups/rename-with-cascade', { group_key: 'a', new_group_key: 'b' });
    assert.equal(res.status, 400);
  });

  it('400 on missing new_group_key', async () => {
    conn = makeConn();
    const res = await post('/edge/app/schema/blueprint_groups/rename-with-cascade', { blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', group_key: 'a' });
    assert.equal(res.status, 400);
  });

  it('400 INVALID_KEY_FORMAT on a non-slug new key', async () => {
    conn = makeConn();
    const res = await post('/edge/app/schema/blueprint_groups/rename-with-cascade', {
      blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', group_key: 'lane_a', new_group_key: 'Bad Key',
    });
    assert.equal(res.status, 400);
    assert.equal(res.json.error.code, 'INVALID_KEY_FORMAT');
  });

  it('400 when the new key equals the current key', async () => {
    conn = makeConn();
    const res = await post('/edge/app/schema/blueprint_groups/rename-with-cascade', {
      blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', group_key: 'lane_a', new_group_key: 'lane_a',
    });
    assert.equal(res.status, 400);
  });

  it('404 when the group does not exist for the blueprint', async () => {
    conn = makeConn([
      [/SELECT id FROM `fmb_blueprint_groups` WHERE blueprint_id = \? AND group_key = \? FOR UPDATE/i, []],
    ]);
    const res = await post('/edge/app/schema/blueprint_groups/rename-with-cascade', {
      blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', group_key: 'gone', new_group_key: 'lane_z',
    });
    assert.equal(res.status, 404);
    assert.ok(conn.events.includes('rollback'));
  });

  it('409 DUPLICATE_GROUP_KEY when the new key already exists in the blueprint', async () => {
    conn = makeConn([
      [/SELECT id FROM `fmb_blueprint_groups` WHERE blueprint_id = \? AND group_key = \? FOR UPDATE/i, [{ id: 'c30b82f6-daee-4dc1-803b-3832d41ed110' }]],
      [/SELECT id FROM `fmb_blueprint_groups` WHERE blueprint_id = \? AND group_key = \? AND id <> \? LIMIT 1/i, [{ id: 'c423dd87-f06d-4d8c-8ae9-67158ada29b4' }]],
    ]);
    const res = await post('/edge/app/schema/blueprint_groups/rename-with-cascade', {
      blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', group_key: 'lane_a', new_group_key: 'lane_b',
    });
    assert.equal(res.status, 409);
    assert.equal(res.json.error.code, 'DUPLICATE_GROUP_KEY');
    assert.ok(conn.events.includes('rollback'));
  });

  it('403 FORBIDDEN for a plain user role (requireAdminOrEditor)', async () => {
    authUser = { id: 'adeb723a-494c-4e33-8cdf-2374d0c68779', role: 'user' };
    conn = makeConn();
    const res = await post('/edge/app/schema/blueprint_groups/rename-with-cascade', {
      blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', group_key: 'lane_a', new_group_key: 'lane_b',
    });
    assert.equal(res.status, 403);
    assert.equal(res.json.error.code, 'FORBIDDEN');
  });

  it('403 FORBIDDEN for a non-owner editor (blueprint owned by someone else)', async () => {
    authUser = { id: '405279b5-48c7-4bd5-8427-69d6ff5556a7', role: 'editor' };
    conn = makeConn([
      // editorMayWriteBlueprint owner lookup → a different owner.
      [/SELECT owner_id FROM `fmb_hierarchy_nodes`/i, [{ owner_id: 'f75a361c-c2a3-4883-8932-cd30adb090bd' }]],
    ]);
    const res = await post('/edge/app/schema/blueprint_groups/rename-with-cascade', {
      blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', group_key: 'lane_a', new_group_key: 'lane_b',
    });
    assert.equal(res.status, 403);
    assert.equal(res.json.error.code, 'FORBIDDEN');
    assert.ok(conn.events.includes('rollback'));
  });

  it('409 LINKED_BLUEPRINT_READONLY when the blueprint borrows another schema', async () => {
    conn = makeConn([
      [/SELECT linked_blueprint_id FROM `fmb_hierarchy_nodes`.*FOR UPDATE/is, [{ linked_blueprint_id: '905685fc-3b3f-4983-86d6-3b5e38df81c7' }]],
    ]);
    const res = await post('/edge/app/schema/blueprint_groups/rename-with-cascade', {
      blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', group_key: 'lane_a', new_group_key: 'lane_b',
    });
    assert.equal(res.status, 409);
    assert.equal(res.json.error.code, 'LINKED_BLUEPRINT_READONLY');
    assert.ok(conn.events.includes('rollback'));
  });

  it('renames the group and cascades to blueprint_fields group_key + matrix_row_key, scoped, committed', async () => {
    const updates = [];
    let auditParams = null;
    let auditSql = null;
    conn = makeConn([
      [/SELECT id FROM `fmb_blueprint_groups` WHERE blueprint_id = \? AND group_key = \? FOR UPDATE/i, [{ id: 'c30b82f6-daee-4dc1-803b-3832d41ed110' }]],
      [/SELECT id FROM `fmb_blueprint_groups` WHERE blueprint_id = \? AND group_key = \? AND id <> \? LIMIT 1/i, []],
      [/^UPDATE `fmb_blueprint_groups` SET group_key = \?/i, (sql, params) => { updates.push(['group', params]); return { affectedRows: 1 }; }],
      [/^UPDATE `fmb_blueprint_fields` SET group_key = \?/i, (sql, params) => { updates.push(['fields', params]); return { affectedRows: 4 }; }],
      [/^UPDATE `fmb_blueprint_fields` SET matrix_row_key = \?/i, (sql, params) => { updates.push(['matrix', params]); return { affectedRows: 2 }; }],
      [/^INSERT INTO `fmb_feature_audit`/i, (sql, params) => { auditSql = sql; auditParams = params; return { affectedRows: 1 }; }],
    ]);
    const res = await post('/edge/app/schema/blueprint_groups/rename-with-cascade', {
      blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', group_key: 'lane_a', new_group_key: 'lane_b',
    });
    assert.equal(res.status, 200);
    assert.equal(res.json.data.fields_updated, 4);
    assert.equal(res.json.data.matrix_updated, 2);
    assert.ok(conn.events.includes('commit'));
    // The group row's own rename binds the id the gate LOCKED AND APPROVED, not
    // the key — keyed on the key, the statement is resolved by the engine under
    // a collation that folds case and would rewrite every row the column calls
    // `lane_a` on a database whose UNIQUE index was never created.
    const groupUpdate = updates.find(([label]) => label === 'group');
    assert.deepEqual(groupUpdate[1], ['lane_b', 'c30b82f6-daee-4dc1-803b-3832d41ed110']);
    // The cascades stay keyed on the key and bind [new_key, blueprint_id,
    // old_key] — a field names its lane BY STRING, so every field naming the old
    // key in any spelling is in the lane being renamed and moves with it.
    for (const [label, params] of updates) {
      if (label === 'group') continue;
      assert.deepEqual(params, ['lane_b', 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', 'lane_a']);
    }
    assert.deepEqual(updates.map((u) => u[0]), ['group', 'fields', 'matrix']);
    // T2: audit row emitted with the rename metadata inside the same tx.
    // (event_type is inlined in the SQL text, not a bound param — only
    // [id, user_id, metadata] are bound.)
    assert.match(auditSql, /blueprint_group\.rename/);
    assert.equal(auditParams[1], '5b729f1e-5c0b-447c-8144-3210469bc62c');
    const metadata = JSON.parse(auditParams[2]);
    assert.deepEqual(metadata, {
      blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26',
      old_key: 'lane_a',
      new_key: 'lane_b',
      fields_updated: 4,
      matrix_updated: 2,
    });
  });

  it('case-only rename normalizing a legacy uppercase key (Lane_A -> lane_a) succeeds', async () => {
    // Per schema.js:3096-3101: the NEW key must be a valid (lowercase) slug,
    // but the OLD key is matched as-stored — so the supported "case-only
    // rename" direction is normalizing a legacy case-variant key DOWN to a
    // valid slug, not the reverse (an uppercase new_group_key would fail
    // isValidSlugKey like any other malformed key).
    const updates = [];
    conn = makeConn([
      [/SELECT id FROM `fmb_blueprint_groups` WHERE blueprint_id = \? AND group_key = \? FOR UPDATE/i, [{ id: 'c30b82f6-daee-4dc1-803b-3832d41ed110' }]],
      // id <> ? excludes the row being renamed, so its own case-variant match
      // (same underlying collation) never counts as a collision.
      [/SELECT id FROM `fmb_blueprint_groups` WHERE blueprint_id = \? AND group_key = \? AND id <> \? LIMIT 1/i, []],
      [/^UPDATE `fmb_blueprint_groups` SET group_key = \?/i, (sql, params) => { updates.push(['group', params]); return { affectedRows: 1 }; }],
      [/^UPDATE `fmb_blueprint_fields` SET group_key = \?/i, (sql, params) => { updates.push(['fields', params]); return { affectedRows: 1 }; }],
      [/^UPDATE `fmb_blueprint_fields` SET matrix_row_key = \?/i, (sql, params) => { updates.push(['matrix', params]); return { affectedRows: 0 }; }],
      [/^INSERT INTO `fmb_feature_audit`/i, { affectedRows: 1 }],
    ]);
    const res = await post('/edge/app/schema/blueprint_groups/rename-with-cascade', {
      blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', group_key: 'Lane_A', new_group_key: 'lane_a',
    });
    assert.equal(res.status, 200);
    assert.equal(res.json.data.fields_updated, 1);
    assert.ok(conn.events.includes('commit'));
  });

  it('409 DUPLICATE_GROUP_KEY on a DB-level 1062 race (backstop)', async () => {
    conn = makeConn([
      [/SELECT id FROM `fmb_blueprint_groups` WHERE blueprint_id = \? AND group_key = \? FOR UPDATE/i, [{ id: 'c30b82f6-daee-4dc1-803b-3832d41ed110' }]],
      [/SELECT id FROM `fmb_blueprint_groups` WHERE blueprint_id = \? AND group_key = \? AND id <> \? LIMIT 1/i, []],
      [/^UPDATE `fmb_blueprint_groups` SET group_key = \?/i, () => { const e = new Error('dup'); e.errno = 1062; throw e; }],
    ]);
    const res = await post('/edge/app/schema/blueprint_groups/rename-with-cascade', {
      blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', group_key: 'lane_a', new_group_key: 'lane_b',
    });
    assert.equal(res.status, 409);
    assert.equal(res.json.error.code, 'DUPLICATE_GROUP_KEY');
    assert.ok(conn.events.includes('rollback'));
  });

  it('skips the matrix_row_key cascade when the column is absent (operator-mode DB), no error', async () => {
    const updates = [];
    conn = makeConn([
      [/SELECT id FROM `fmb_blueprint_groups` WHERE blueprint_id = \? AND group_key = \? FOR UPDATE/i, [{ id: 'c30b82f6-daee-4dc1-803b-3832d41ed110' }]],
      [/SELECT id FROM `fmb_blueprint_groups` WHERE blueprint_id = \? AND group_key = \? AND id <> \? LIMIT 1/i, []],
      // Column probe reports only group_key present — matrix_row_key absent.
      [/information_schema\.COLUMNS/i, [{ COLUMN_NAME: 'group_key' }]],
      [/^UPDATE `fmb_blueprint_groups` SET group_key = \?/i, (sql, params) => { updates.push(['group', params]); return { affectedRows: 1 }; }],
      [/^UPDATE `fmb_blueprint_fields` SET group_key = \?/i, (sql, params) => { updates.push(['fields', params]); return { affectedRows: 3 }; }],
      [/^INSERT INTO `fmb_feature_audit`/i, { affectedRows: 1 }],
    ]);
    const res = await post('/edge/app/schema/blueprint_groups/rename-with-cascade', {
      blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', group_key: 'lane_a', new_group_key: 'lane_b',
    });
    assert.equal(res.status, 200);
    assert.equal(res.json.data.fields_updated, 3);
    assert.equal(res.json.data.matrix_updated, 0);
    assert.ok(conn.events.includes('commit'));
    // No matrix_row_key UPDATE was issued — the column-probe skip fired.
    assert.ok(!conn.queries.some((q) => /^UPDATE `fmb_blueprint_fields` SET matrix_row_key/i.test(q.sql)));
    assert.deepEqual(updates.map((u) => u[0]), ['group', 'fields']);
  });
});

describe('POST /blueprint_groups/rename-impact (T1)', () => {
  it('400 on missing blueprint_id', async () => {
    conn = makeConn();
    const res = await post('/edge/app/schema/blueprint_groups/rename-impact', { group_key: 'lane_a' });
    assert.equal(res.status, 400);
  });

  it('400 on missing group_key', async () => {
    conn = makeConn();
    const res = await post('/edge/app/schema/blueprint_groups/rename-impact', { blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26' });
    assert.equal(res.status, 400);
  });

  it('403 FORBIDDEN for a plain user role (requireAdminOrEditor)', async () => {
    authUser = { id: 'adeb723a-494c-4e33-8cdf-2374d0c68779', role: 'user' };
    conn = makeConn();
    const res = await post('/edge/app/schema/blueprint_groups/rename-impact', {
      blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', group_key: 'lane_a',
    });
    assert.equal(res.status, 403);
    assert.equal(res.json.error.code, 'FORBIDDEN');
  });

  it('403 FORBIDDEN for a non-owner editor (does not leak scope)', async () => {
    authUser = { id: '405279b5-48c7-4bd5-8427-69d6ff5556a7', role: 'editor' };
    conn = makeConn([
      [/SELECT owner_id FROM `fmb_hierarchy_nodes`/i, [{ owner_id: 'f75a361c-c2a3-4883-8932-cd30adb090bd' }]],
    ]);
    const res = await post('/edge/app/schema/blueprint_groups/rename-impact', {
      blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', group_key: 'lane_a',
    });
    assert.equal(res.status, 403);
    assert.equal(res.json.error.code, 'FORBIDDEN');
    // Read-only endpoint: no group lookup happened before the ownership gate.
    assert.ok(!conn.queries.some((q) => /FROM `fmb_blueprint_groups`/i.test(q.sql)));
  });

  it('404 when the group does not exist for the blueprint', async () => {
    conn = makeConn([
      [/SELECT id FROM `fmb_blueprint_groups` WHERE blueprint_id = \? AND group_key = \?/i, []],
    ]);
    const res = await post('/edge/app/schema/blueprint_groups/rename-impact', {
      blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', group_key: 'gone',
    });
    assert.equal(res.status, 404);
    assert.equal(res.json.error.code, 'NOT_FOUND');
  });

  it('returns fields_affected and matrix_affected counts, scoped to the blueprint', async () => {
    const counted = [];
    conn = makeConn([
      [/SELECT id FROM `fmb_blueprint_groups` WHERE blueprint_id = \? AND group_key = \?/i, [{ id: 'c30b82f6-daee-4dc1-803b-3832d41ed110' }]],
      [/SELECT COUNT\(\*\) AS cnt FROM `fmb_blueprint_fields` WHERE blueprint_id = \? AND group_key = \?/i,
        (sql, params) => { counted.push(['group_key', params]); return [{ cnt: 5 }]; }],
      [/SELECT COUNT\(\*\) AS cnt FROM `fmb_blueprint_fields` WHERE blueprint_id = \? AND matrix_row_key = \?/i,
        (sql, params) => { counted.push(['matrix_row_key', params]); return [{ cnt: 2 }]; }],
    ]);
    const res = await post('/edge/app/schema/blueprint_groups/rename-impact', {
      blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', group_key: 'lane_a',
    });
    assert.equal(res.status, 200);
    assert.equal(res.json.data.fields_affected, 5);
    assert.equal(res.json.data.matrix_affected, 2);
    assert.deepEqual(counted, [
      ['group_key', ['a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', 'lane_a']],
      ['matrix_row_key', ['a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', 'lane_a']],
    ]);
  });

  it('honours a db-routing param (dynamic pool) without changing gating', async () => {
    conn = makeConn([
      [/SELECT id FROM `fmb_blueprint_groups` WHERE blueprint_id = \? AND group_key = \?/i, [{ id: 'c30b82f6-daee-4dc1-803b-3832d41ed110' }]],
      [/SELECT COUNT\(\*\) AS cnt FROM `fmb_blueprint_fields` WHERE blueprint_id = \? AND group_key = \?/i, [{ cnt: 0 }]],
      [/SELECT COUNT\(\*\) AS cnt FROM `fmb_blueprint_fields` WHERE blueprint_id = \? AND matrix_row_key = \?/i, [{ cnt: 0 }]],
    ]);
    const res = await post('/edge/app/schema/blueprint_groups/rename-impact', {
      blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', group_key: 'lane_a', db: 'other-db',
    });
    assert.equal(res.status, 200);
    assert.equal(res.json.data.fields_affected, 0);
    assert.equal(res.json.data.matrix_affected, 0);
  });
});

describe('POST /blueprint_groups/replace — slug enforced on new keys only (item 5)', () => {
  it('rejects a NEW non-slug group_key in next with 400', async () => {
    conn = makeConn([
      [/SELECT id, group_key, display_label, color_key, sort_order FROM/i, []],
    ]);
    const res = await post('/edge/app/schema/blueprint_groups/replace', {
      blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26',
      expected: [],
      next: [{ group_key: 'Bad Key', display_label: 'X', color_key: 'blue', sort_order: 1 }],
    });
    assert.equal(res.status, 400);
    assert.equal(res.json.error.code, 'INVALID_KEY_FORMAT');
    assert.ok(conn.events.includes('rollback'));
  });

  it('grandfathers a legacy non-slug key that is preserved (present in current + next)', async () => {
    // Current has a legacy 'Bad Key' row; next keeps it (only reorders/relabels).
    // Because it is not a NEW key, slug validation does not fire.
    conn = makeConn([
      [/SELECT id, group_key, display_label, color_key, sort_order FROM/i,
        [{ id: 'dbe90bc2-67dd-40e3-84bb-78c7e6baa281', group_key: 'Bad Key', display_label: 'Legacy', color_key: 'blue', sort_order: 1 }]],
      [/^UPDATE `fmb_blueprint_groups`/i, { affectedRows: 1 }],
    ]);
    const res = await post('/edge/app/schema/blueprint_groups/replace', {
      blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26',
      expected: [{ group_key: 'Bad Key', display_label: 'Legacy', color_key: 'blue', sort_order: 1 }],
      next: [{ group_key: 'Bad Key', display_label: 'Renamed', color_key: 'blue', sort_order: 1 }],
    });
    assert.equal(res.status, 200);
    assert.ok(conn.events.includes('commit'));
  });

  // Bug 1 / Codex P2: replace must not become a back-door key change. A rename
  // surfaces here as "old key dropped from next + new key inserted"; if the old
  // key still has referencing fields, that would orphan them exactly like a bare
  // key change, so it is rejected — renames go through rename-with-cascade.
  it('rejects a rename-via-replace when the dropped key still has referencing fields (409 GROUP_KEY_IN_USE)', async () => {
    conn = makeConn([
      [/SELECT id, group_key, display_label, color_key, sort_order FROM/i,
        [{ id: '76c8a346-1032-4f3c-8352-6c1eb4e85cc6', group_key: 'lane_a', display_label: 'A', color_key: 'blue', sort_order: 1 }]],
      [/SELECT DISTINCT `group_key` AS k FROM `fmb_blueprint_fields`/i, [{ k: 'lane_a' }]],
      [/SELECT DISTINCT `matrix_row_key` AS k FROM `fmb_blueprint_fields`/i, []],
    ]);
    const res = await post('/edge/app/schema/blueprint_groups/replace', {
      blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26',
      expected: [{ group_key: 'lane_a', display_label: 'A', color_key: 'blue', sort_order: 1 }],
      next: [{ group_key: 'lane_b', display_label: 'A', color_key: 'blue', sort_order: 1 }],
    });
    assert.equal(res.status, 409);
    assert.equal(res.json.error.code, 'GROUP_KEY_IN_USE');
    assert.ok(conn.events.includes('rollback'));
    // No DELETE was issued — rejected before the destructive step.
    assert.ok(!conn.queries.some((q) => /^DELETE FROM `fmb_blueprint_groups`/i.test(q.sql)));
  });

  it('allows a label-only replace (no key dropped → guard skipped)', async () => {
    conn = makeConn([
      [/SELECT id, group_key, display_label, color_key, sort_order FROM/i,
        [{ id: '76c8a346-1032-4f3c-8352-6c1eb4e85cc6', group_key: 'lane_a', display_label: 'A', color_key: 'blue', sort_order: 1 }]],
      [/^UPDATE `fmb_blueprint_groups`/i, { affectedRows: 1 }],
    ]);
    const res = await post('/edge/app/schema/blueprint_groups/replace', {
      blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26',
      expected: [{ group_key: 'lane_a', display_label: 'A', color_key: 'blue', sort_order: 1 }],
      next: [{ group_key: 'lane_a', display_label: 'B', color_key: 'blue', sort_order: 1 }],
    });
    assert.equal(res.status, 200);
    assert.ok(conn.events.includes('commit'));
    // Guard never queried blueprint_fields (nothing was dropped).
    assert.ok(!conn.queries.some((q) => /FROM `fmb_blueprint_fields`/i.test(q.sql)));
  });

  it('allows an add (new key inserted, nothing dropped)', async () => {
    conn = makeConn([
      [/SELECT id, group_key, display_label, color_key, sort_order FROM/i, []],
      [/^INSERT INTO `fmb_blueprint_groups`/i, { affectedRows: 1 }],
    ]);
    const res = await post('/edge/app/schema/blueprint_groups/replace', {
      blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26',
      expected: [],
      next: [{ group_key: 'lane_a', display_label: 'A', color_key: 'blue', sort_order: 1 }],
    });
    assert.equal(res.status, 200);
    assert.ok(conn.events.includes('commit'));
  });

  it('allows removing an EMPTY group (dropped key has no referencing fields)', async () => {
    conn = makeConn([
      [/SELECT id, group_key, display_label, color_key, sort_order FROM/i,
        [{ id: '76c8a346-1032-4f3c-8352-6c1eb4e85cc6', group_key: 'lane_a', display_label: 'A', color_key: 'blue', sort_order: 1 }]],
      [/SELECT DISTINCT `group_key` AS k FROM `fmb_blueprint_fields`/i, []],
      [/SELECT DISTINCT `matrix_row_key` AS k FROM `fmb_blueprint_fields`/i, []],
      [/^DELETE FROM `fmb_blueprint_groups`/i, { affectedRows: 1 }],
    ]);
    const res = await post('/edge/app/schema/blueprint_groups/replace', {
      blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26',
      expected: [{ group_key: 'lane_a', display_label: 'A', color_key: 'blue', sort_order: 1 }],
      next: [],
    });
    assert.equal(res.status, 200);
    assert.ok(conn.events.includes('commit'));
  });
});

describe('POST /blueprint_groups/delete-with-reassign (item 2)', () => {
  it('400 on missing blueprint_id', async () => {
    conn = makeConn();
    const res = await post('/edge/app/schema/blueprint_groups/delete-with-reassign', { group_key: 'g', action: 'clear' });
    assert.equal(res.status, 400);
  });

  it('400 on invalid action', async () => {
    conn = makeConn();
    const res = await post('/edge/app/schema/blueprint_groups/delete-with-reassign', { blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', group_key: 'g', action: 'bogus' });
    assert.equal(res.status, 400);
  });

  it('400 when move is missing target_group_key', async () => {
    conn = makeConn();
    const res = await post('/edge/app/schema/blueprint_groups/delete-with-reassign', { blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', group_key: 'g', action: 'move' });
    assert.equal(res.status, 400);
  });

  // Existence + row-lock probe. The endpoint locks the deleted group AND (on
  // move) the target group FOR UPDATE, one query per key. `present` is the set
  // of group_keys that exist. Also records that each lock query carried FOR
  // UPDATE so the concurrency contract is asserted.
  function groupLockScript(present, forUpdateSeen) {
    return [/SELECT id FROM `fmb_blueprint_groups` WHERE blueprint_id = \? AND group_key = \?/i,
      (sql, params) => {
        if (/FOR UPDATE/i.test(sql)) forUpdateSeen.push(params[1]);
        return present.has(params[1]) ? [{ id: `id-${params[1]}` }] : [];
      }];
  }

  it('404 when the group does not exist for the blueprint', async () => {
    conn = makeConn([groupLockScript(new Set(), [])]);
    const res = await post('/edge/app/schema/blueprint_groups/delete-with-reassign', { blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', group_key: 'gone', action: 'clear' });
    assert.equal(res.status, 404);
    assert.ok(conn.events.includes('rollback'));
  });

  it('clear: reassigns matching fields to ungrouped and deletes the group in one committed tx', async () => {
    let updateParams = null;
    const forUpdate = [];
    conn = makeConn([
      groupLockScript(new Set(['lane_a']), forUpdate),
      [/^UPDATE `fmb_blueprint_fields` SET group_key = \?/i, (sql, params) => { updateParams = params; return { affectedRows: 3 }; }],
      [/^DELETE FROM `fmb_blueprint_groups`/i, { affectedRows: 1 }],
    ]);
    const res = await post('/edge/app/schema/blueprint_groups/delete-with-reassign', { blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', group_key: 'lane_a', action: 'clear' });
    assert.equal(res.status, 200);
    assert.equal(res.json.data.reassigned, 3);
    assert.equal(updateParams[0], ''); // cleared to ungrouped
    assert.deepEqual(forUpdate, ['lane_a']); // deleted group locked FOR UPDATE
    assert.deepEqual(conn.events, ['begin', 'commit', 'release']);
  });

  it('move: locks both keys FOR UPDATE in sorted order and reassigns to target', async () => {
    let updateParams = null;
    const forUpdate = [];
    conn = makeConn([
      groupLockScript(new Set(['lane_a', 'lane_b']), forUpdate),
      [/^UPDATE `fmb_blueprint_fields` SET group_key = \?/i, (sql, params) => { updateParams = params; return { affectedRows: 2 }; }],
      [/^DELETE FROM `fmb_blueprint_groups`/i, { affectedRows: 1 }],
    ]);
    const res = await post('/edge/app/schema/blueprint_groups/delete-with-reassign', {
      blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', group_key: 'lane_a', action: 'move', target_group_key: 'lane_b',
    });
    assert.equal(res.status, 200);
    assert.equal(res.json.data.reassigned, 2);
    assert.equal(updateParams[0], 'lane_b');
    // Both rows locked FOR UPDATE, in deterministic sorted order (deadlock-safe).
    assert.deepEqual(forUpdate, ['lane_a', 'lane_b']);
    assert.ok(conn.events.includes('commit'));
  });

  it('move: locks in sorted order even when the target sorts before the deleted key', async () => {
    const forUpdate = [];
    conn = makeConn([
      groupLockScript(new Set(['lane_z', 'lane_a']), forUpdate),
      [/^UPDATE `fmb_blueprint_fields` SET group_key = \?/i, { affectedRows: 1 }],
      [/^DELETE FROM `fmb_blueprint_groups`/i, { affectedRows: 1 }],
    ]);
    const res = await post('/edge/app/schema/blueprint_groups/delete-with-reassign', {
      blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', group_key: 'lane_z', action: 'move', target_group_key: 'lane_a',
    });
    assert.equal(res.status, 200);
    assert.deepEqual(forUpdate, ['lane_a', 'lane_z']); // sorted, not request order
  });

  it('400 when move target group does not exist', async () => {
    conn = makeConn([groupLockScript(new Set(['lane_a']), [])]);
    const res = await post('/edge/app/schema/blueprint_groups/delete-with-reassign', {
      blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', group_key: 'lane_a', action: 'move', target_group_key: 'nope',
    });
    assert.equal(res.status, 400);
    assert.ok(conn.events.includes('rollback'));
  });
});
