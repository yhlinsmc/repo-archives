// docker-api/tests/unit/edge-state-client-rate-limits.test.js
const { describe, it, before, after } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');

let server, base;
before(async () => {
  server = http.createServer((req, res) => {
    if (req.url === '/edge/internal/system/rate-limits') {
      res.setHeader('Content-Type', 'application/json');
      return res.end(JSON.stringify({ data: { general: 1500, connectorFetch: null, connectorWrite: 60, auditSearch: null } }));
    }
    res.statusCode = 404; res.end('{}');
  });
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  base = `http://127.0.0.1:${server.address().port}`;
  process.env.EDGE_API_URL = base;
});
after(async () => { await new Promise((r) => server.close(r)); delete process.env.EDGE_API_URL; });

describe('fetchRateLimits', () => {
  it('returns the parsed snapshot object', async () => {
    const { fetchRateLimits } = require('../../src/infra/lib/edge-state-client');
    const r = await fetchRateLimits({ timeoutMs: 2000 });
    assert.deepEqual(r, { general: 1500, connectorFetch: null, connectorWrite: 60, auditSearch: null });
  });
});
