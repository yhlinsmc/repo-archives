/**
 * db-prefix-config.test.js — v3.2.55 Q3 E1 + Q6 coverage.
 *
 * Verifies the new fail-fast behaviour around `_tablePrefix`:
 *   1. Fresh module load: t() throws PoolNotConfiguredError before
 *      configurePool runs (no silent `'fmb_'` default).
 *   2. After configurePool succeeds: t() returns the configured prefix.
 *   3. resetConfig nulls _tablePrefix so the next t() throws again.
 *   4. Q6 regression: `bob_ro_` survives configurePool round-trip; the
 *      live `example_app_` repro from the real deployment also passes.
 *   5. configurePool rejects empty/missing tablePrefix with code
 *      `TABLE_PREFIX_REQUIRED` before any pool work happens.
 *
 * The mariadb stub here is a pared-down version of the one in
 * pre-swap-probe.test.js — only what these tests need.
 */

const { test, describe, beforeEach, afterEach } = require('node:test');
const assert = require('node:assert/strict');
const Module = require('node:module');

const originalRequire = Module.prototype.require;

function makeStub() {
  return {
    createPool: () => ({
      getConnection: async () => ({
        query: async (sql, params) => {
          if (/SHOW GRANTS/i.test(sql)) {
            return [{ G: "GRANT ALL PRIVILEGES ON *.* TO 'u'@'%' WITH GRANT OPTION" }];
          }
          // Preflight TABLES probe: params=[schema, [table,...]] — return all
          // pre-existing so preflight passes without ALTER paths.
          if (/information_schema/i.test(sql) && Array.isArray(params?.[1])) {
            return params[1].map((TABLE_NAME) => ({ TABLE_NAME, TABLE_SCHEMA: params[0] }));
          }
          // Migration probes (IS_NULLABLE / column existence): pretend the
          // column already matches the desired shape so each migration step
          // is a no-op. Avoids the noisy "migration step skipped" warns.
          if (/information_schema/i.test(sql)) {
            return [{ IS_NULLABLE: 'YES' }, { dummy: 1 }];
          }
          return [];
        },
        release: async () => {},
      }),
      query: async () => [],
      end: async () => {},
    }),
    createConnection: async () => ({ query: async () => [], end: async () => {} }),
  };
}

function stubMariadb(stubImpl) {
  Module.prototype.require = function (id) {
    if (id === 'mariadb') return stubImpl;
    return originalRequire.apply(this, arguments);
  };
}

function restoreMariadb() {
  Module.prototype.require = originalRequire;
}

function freshDb() {
  const dbPath = require.resolve('../../src/edge/db');
  const pmPath = require.resolve('../../src/edge/pool-manager');
  delete require.cache[dbPath];
  delete require.cache[pmPath];
  return require('../../src/edge/db');
}

describe('t() — Q3 E1: fail-fast when _tablePrefix is null', () => {
  beforeEach(() => stubMariadb(makeStub()));
  afterEach(restoreMariadb);

  test('throws PoolNotConfiguredError on a fresh module before configurePool', () => {
    const db = freshDb();
    let thrown = null;
    try {
      db.t('users');
    } catch (err) {
      thrown = err;
    }
    assert.ok(thrown, 't() must throw before configurePool');
    assert.equal(thrown.name, 'PoolNotConfiguredError');
    assert.equal(thrown.code, 'POOL_NOT_CONFIGURED');
    assert.equal(thrown.docsRef, 'LEARN.md#64');
    assert.match(
      thrown.message,
      /pool is not configured/i,
      'message must hint at the missing setup',
    );
  });

  test('after configurePool: t() returns the configured prefix + table name', async () => {
    const db = freshDb();
    await db.configurePool({
      host: 'h', port: 3306, user: 'u', password: 'p',
      database: 'example_app', tablePrefix: 'example_app_',
    });
    assert.equal(db.t('users'), 'example_app_users');
    assert.equal(db.t('login_audit'), 'example_app_login_audit');
  });

  test('after resetConfig: t() throws again (no stale prefix carry-over)', async () => {
    // Force a clean reset path: no env vars, no config file. Otherwise
    // resetConfig's "reconnect from env" branch tries to call configurePool
    // again and we'd be testing a different path than the one we care about
    // (pure reset → next t() must surface the gap).
    const prevHost = process.env.DB_RW_HOST;
    delete process.env.DB_RW_HOST;
    try {
      const db = freshDb();
      await db.configurePool({
        host: 'h', port: 3306, user: 'u', password: 'p',
        database: 'fmb', tablePrefix: 'fmb_',
      });
      assert.equal(db.t('users'), 'fmb_users', 'sanity: prefix is set');
      await db.resetConfig();
      let thrown = null;
      try { db.t('users'); } catch (err) { thrown = err; }
      assert.ok(thrown, 'resetConfig must clear _tablePrefix');
      assert.equal(thrown.code, 'POOL_NOT_CONFIGURED');
    } finally {
      if (prevHost != null) process.env.DB_RW_HOST = prevHost;
    }
  });
});

describe('t() — Q6 underscore preservation regression', () => {
  beforeEach(() => stubMariadb(makeStub()));
  afterEach(restoreMariadb);

  // The user's live walkthrough showed `bob_rousers` instead of
  // `bob_ro_users` in the audit log. The 5-min sweep didn't pin a
  // root-cause callsite, so this test is the long-running tripwire:
  // any future code change that strips a trailing `_` will trip here.
  test("preserves trailing underscore in tablePrefix='bob_ro_'", async () => {
    const db = freshDb();
    await db.configurePool({
      host: 'h', port: 3306, user: 'u', password: 'p',
      database: 'bob', tablePrefix: 'bob_ro_',
    });
    assert.equal(db.t('users'), 'bob_ro_users', 'underscore must survive intact');
    assert.equal(db.t('audit'), 'bob_ro_audit');
    const cfg = db.getDbConfig();
    assert.equal(cfg.tablePrefix, 'bob_ro_', 'getDbConfig must report verbatim prefix');
  });

  test("real repro: tablePrefix='example_app_' yields example_app_users", async () => {
    const db = freshDb();
    await db.configurePool({
      host: 'h', port: 3306, user: 'u', password: 'p',
      database: 'example_app', tablePrefix: 'example_app_',
    });
    assert.equal(db.t('users'), 'example_app_users');
    assert.equal(db.t('feature_audit'), 'example_app_feature_audit');
  });
});

describe('configurePool — Q3 E1: tablePrefix is required', () => {
  beforeEach(() => stubMariadb(makeStub()));
  afterEach(restoreMariadb);

  test('rejects undefined tablePrefix with TABLE_PREFIX_REQUIRED', async () => {
    const db = freshDb();
    let thrown = null;
    try {
      await db.configurePool({
        host: 'h', port: 3306, user: 'u', password: 'p',
        database: 'example_app',
      });
    } catch (err) {
      thrown = err;
    }
    assert.ok(thrown, 'must throw when tablePrefix is missing');
    assert.equal(thrown.code, 'TABLE_PREFIX_REQUIRED');
  });

  test('rejects empty string tablePrefix', async () => {
    const db = freshDb();
    let thrown = null;
    try {
      await db.configurePool({
        host: 'h', port: 3306, user: 'u', password: 'p',
        database: 'example_app', tablePrefix: '',
      });
    } catch (err) {
      thrown = err;
    }
    assert.ok(thrown, 'must throw when tablePrefix is empty');
    assert.equal(thrown.code, 'TABLE_PREFIX_REQUIRED');
  });

  test('rejects non-string tablePrefix (defensive: number)', async () => {
    const db = freshDb();
    let thrown = null;
    try {
      await db.configurePool({
        host: 'h', port: 3306, user: 'u', password: 'p',
        database: 'example_app', tablePrefix: 42,
      });
    } catch (err) {
      thrown = err;
    }
    assert.ok(thrown, 'must throw when tablePrefix is not a string');
    assert.equal(thrown.code, 'TABLE_PREFIX_REQUIRED');
  });
});

describe('PoolNotConfiguredError + MigrationError shape (TD3)', () => {
  // v3.2.55 review-gate LOW fold: stub install moved to beforeEach so the
  // contract is consistent with the other three describe blocks. The
  // earlier inline-stub-with-finally pattern worked but made future test
  // additions to this block error-prone.
  beforeEach(() => stubMariadb(makeStub()));
  afterEach(restoreMariadb);

  test('error classes are re-exported from db.js for HTTP error mapping', () => {
    const db = freshDb();
    assert.equal(typeof db.PoolNotConfiguredError, 'function');
    assert.equal(typeof db.MigrationError, 'function');
    const e = new db.PoolNotConfiguredError('t("users")');
    assert.equal(e.code, 'POOL_NOT_CONFIGURED');
    assert.equal(e.callsite, 't("users")');
    // v3.2.55 review-gate MED fold: HTTP layer maps `err.status` to
    // the response code; this assertion pins the 503 contract.
    assert.equal(e.status, 503);
    const m = new db.MigrationError({ version: '3.2.55', step: 'fictional', cause: new Error('boom') });
    assert.equal(m.code, 'MIGRATION_FAILED');
    assert.equal(m.version, '3.2.55');
    assert.equal(m.step, 'fictional');
  });
});
