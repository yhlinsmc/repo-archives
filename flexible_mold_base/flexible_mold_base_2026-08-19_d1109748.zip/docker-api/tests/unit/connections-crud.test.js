/**
 * connections-crud.test.js — v3.2.32b Unit tests for the
 * validateReadEndpointPair guard used by routes/platform/connections.js
 * POST and PUT handlers.
 *
 * The PUT handler uses SELECT ... FOR UPDATE to close the TOCTOU race
 * against concurrent PUTs on the same row (v3.2.32a MED-3 fold). The
 * fold itself is exercised by the integration test; this file covers
 * the pure validator behaviour.
 */

const { test, describe } = require('node:test');
const assert = require('node:assert/strict');

const connections = require('../../src/edge/routes/platform/connections');
const { validateReadEndpointPair } = connections._internal;

describe('validateReadEndpointPair — both-or-neither invariant', () => {
  test('both missing → null', () => {
    assert.equal(validateReadEndpointPair({}), null);
    assert.equal(validateReadEndpointPair({ read_host: null, read_port: null }), null);
    assert.equal(validateReadEndpointPair({ read_host: '', read_port: '' }), null);
  });

  test('both set → null', () => {
    assert.equal(validateReadEndpointPair({ read_host: 'reader', read_port: 3306 }), null);
    assert.equal(validateReadEndpointPair({ read_host: 'reader', read_port: '3306' }), null);
  });

  test('only read_host → error', () => {
    const err = validateReadEndpointPair({ read_host: 'reader' });
    assert.match(err, /both-or-neither/);
  });

  test('only read_port → error', () => {
    const err = validateReadEndpointPair({ read_port: 3306 });
    assert.match(err, /both-or-neither/);
  });

  test('empty-string host but real port → error', () => {
    const err = validateReadEndpointPair({ read_host: '', read_port: 3306 });
    assert.match(err, /both-or-neither/);
  });

  test('real host but empty-string port → error', () => {
    const err = validateReadEndpointPair({ read_host: 'reader', read_port: '' });
    assert.match(err, /both-or-neither/);
  });

  test('both null explicitly → null', () => {
    // A client resetting a dual-endpoint profile back to writer-only
    // hits this path: the body includes both keys with null values.
    assert.equal(validateReadEndpointPair({ read_host: null, read_port: null }), null);
  });

  test('zero port is treated as a value, not unset', () => {
    // Zero is semantically invalid for a port but it IS a number, so
    // the both-or-neither rule treats it as "present". A follow-up
    // schema-level check would reject 0 explicitly; this test just
    // asserts the current contract.
    assert.equal(validateReadEndpointPair({ read_host: 'reader', read_port: 0 }), null);
  });
});
