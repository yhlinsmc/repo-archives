/**
 * field-key-validation.test.js — v3.2.9 Phase 4 backend validation suite.
 *
 * Tests the isValidFieldKey function used by the rename and impact APIs
 * to prevent SQL/JSON path injection via field key parameters.
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');

// Extract the validation logic — mirrors the inline implementation in schema.js
const FIELD_KEY_RE = /^[a-z][a-z0-9_]*$/;
const FIELD_KEY_MAX_LEN = 64;

function isValidFieldKey(key) {
  return typeof key === 'string' && key.length <= FIELD_KEY_MAX_LEN && FIELD_KEY_RE.test(key);
}

describe('isValidFieldKey — format', () => {
  it('accepts valid lowercase keys', () => {
    assert.ok(isValidFieldKey('hostname'));
    assert.ok(isValidFieldKey('os_version'));
    assert.ok(isValidFieldKey('a1b2c3'));
    assert.ok(isValidFieldKey('x'));
  });

  it('rejects keys starting with digit', () => {
    assert.ok(!isValidFieldKey('1host'));
  });

  it('rejects keys starting with underscore', () => {
    assert.ok(!isValidFieldKey('_host'));
  });

  it('rejects uppercase letters', () => {
    assert.ok(!isValidFieldKey('hostName'));
    assert.ok(!isValidFieldKey('HOST'));
  });

  it('rejects special characters', () => {
    assert.ok(!isValidFieldKey('host-name'));
    assert.ok(!isValidFieldKey('host.name'));
    assert.ok(!isValidFieldKey('host name'));
    assert.ok(!isValidFieldKey('host@name'));
  });

  it('rejects empty string', () => {
    assert.ok(!isValidFieldKey(''));
  });

  it('rejects non-string inputs', () => {
    assert.ok(!isValidFieldKey(null));
    assert.ok(!isValidFieldKey(undefined));
    assert.ok(!isValidFieldKey(123));
    assert.ok(!isValidFieldKey({}));
  });

  it('rejects keys exceeding max length', () => {
    const longKey = 'a' + '_'.repeat(FIELD_KEY_MAX_LEN);
    assert.ok(longKey.length > FIELD_KEY_MAX_LEN);
    assert.ok(!isValidFieldKey(longKey));
  });

  it('accepts keys at exactly max length', () => {
    const key = 'a'.repeat(FIELD_KEY_MAX_LEN);
    assert.ok(isValidFieldKey(key));
  });
});

describe('isValidFieldKey — SQL/JSON injection prevention', () => {
  it('rejects JSON path injection attempts', () => {
    assert.ok(!isValidFieldKey('$.admin'));
    assert.ok(!isValidFieldKey('")); DROP TABLE'));
    assert.ok(!isValidFieldKey('key"'));
    assert.ok(!isValidFieldKey("key'"));
  });

  it('rejects backtick injection', () => {
    assert.ok(!isValidFieldKey('key`; --'));
  });

  it('rejects null bytes', () => {
    assert.ok(!isValidFieldKey('key\x00'));
  });
});
