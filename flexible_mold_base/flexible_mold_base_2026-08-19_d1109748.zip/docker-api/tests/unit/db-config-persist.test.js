const { test } = require('node:test');
const assert = require('node:assert');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

// The configPath seam lives in _internalsForTest, off the public
// saveConfig/loadConfig signatures — production callers are CONFIG_PATH-bound.
const { _internalsForTest } = require('../../src/edge/db');
const { _saveConfigToPath, _loadConfigFromPath } = _internalsForTest;

function tmpPath() {
  return path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'dbcfg-')), 'db-config.json');
}

const KEY = 'unit-test-key';
function withKey(fn) {
  const prev = process.env.SETTINGS_ENCRYPTION_KEY;
  process.env.SETTINGS_ENCRYPTION_KEY = KEY;
  try { return fn(); } finally {
    if (prev === undefined) delete process.env.SETTINGS_ENCRYPTION_KEY;
    else process.env.SETTINGS_ENCRYPTION_KEY = prev;
  }
}

// --- Task 2: persist gate + path seam ---

test('saveConfig with persist:false writes nothing and returns false', () => {
  const p = tmpPath();
  const wrote = _saveConfigToPath({ host: 'h', password: 'pw' }, p, { persist: false });
  assert.strictEqual(wrote, false);
  assert.strictEqual(fs.existsSync(p), false, 'no file written');
});

test('saveConfig with persist omitted defaults to no-write', () => {
  const p = tmpPath();
  const wrote = _saveConfigToPath({ host: 'h', password: 'pw' }, p, {});
  assert.strictEqual(wrote, false);
  assert.strictEqual(fs.existsSync(p), false);
});

test('saveConfig with persist:true writes a file and returns true', () => {
  withKey(() => {
    const p = tmpPath();
    const wrote = _saveConfigToPath(
      { host: 'h', port: 3306, user: 'u', password: 'pw', database: 'd', tablePrefix: 'p_' },
      p,
      { persist: true },
    );
    assert.strictEqual(wrote, true);
    assert.strictEqual(fs.existsSync(p), true);
  });
});

test('loadConfig reads back from a custom path', () => {
  withKey(() => {
    const p = tmpPath();
    _saveConfigToPath(
      { host: 'h', port: 3306, user: 'u', password: 'pw', database: 'd', tablePrefix: 'p_' },
      p,
      { persist: true },
    );
    const cfg = _loadConfigFromPath(p);
    assert.strictEqual(cfg.host, 'h');
    assert.strictEqual(cfg._source, 'file');
  });
});

// --- Task 3: at-rest encryption (encrypt-on-write / decrypt-on-read) ---

test('persisted file stores password as enc:v1, never plaintext', () => {
  withKey(() => {
    const p = tmpPath();
    _saveConfigToPath(
      { host: 'h', port: 3306, user: 'u', password: 'topsecret', database: 'd', tablePrefix: 'p_' },
      p,
      { persist: true },
    );
    const raw = fs.readFileSync(p, 'utf8');
    assert.ok(!raw.includes('topsecret'), 'plaintext password absent from file');
    assert.ok(JSON.parse(raw).password.startsWith('enc:v1:'), 'password stored encrypted');
  });
});

test('loadConfig decrypts the password back to plaintext', () => {
  withKey(() => {
    const p = tmpPath();
    _saveConfigToPath(
      { host: 'h', port: 3306, user: 'u', password: 'topsecret', database: 'd', tablePrefix: 'p_' },
      p,
      { persist: true },
    );
    const cfg = _loadConfigFromPath(p);
    assert.strictEqual(cfg.password, 'topsecret');
  });
});

test('loadConfig still reads a legacy plaintext file', () => {
  const p = tmpPath();
  fs.writeFileSync(p, JSON.stringify({ host: 'h', user: 'u', password: 'legacy', database: 'd', tablePrefix: 'p_' }));
  const cfg = _loadConfigFromPath(p);
  assert.strictEqual(cfg.password, 'legacy');
});

test('loadConfig fail-closed: enc:v1 file but no key -> null', () => {
  const p = tmpPath();
  withKey(() => {
    _saveConfigToPath({ host: 'h', user: 'u', password: 'pw', database: 'd', tablePrefix: 'p_' },
      p, { persist: true });
  });
  const prevKey = process.env.SETTINGS_ENCRYPTION_KEY;
  const prevHost = process.env.DB_RW_HOST;
  delete process.env.SETTINGS_ENCRYPTION_KEY;
  delete process.env.DB_RW_HOST;
  try {
    const cfg = _loadConfigFromPath(p);
    assert.strictEqual(cfg, null, 'encrypted file with no key resolves to unconfigured');
  } finally {
    if (prevKey !== undefined) process.env.SETTINGS_ENCRYPTION_KEY = prevKey;
    if (prevHost !== undefined) process.env.DB_RW_HOST = prevHost;
  }
});
