/**
 * decision-doc-validation.test.js — the `decision_tables.doc` write contract.
 *
 * The column is MariaDB JSON (i.e. LONGTEXT + json_valid), so nothing about the
 * document's shape or size is enforced by the database. Every guarantee the
 * evaluation engine reads — arrays are arrays, a row only names declared
 * columns, cell values are scalars, the whole document fits in 1 MB — exists
 * only because this validator rejects the write. These tests pin each one.
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');

const {
  MAX_DECISION_DOC_BYTES,
  validateDecisionDoc,
  normalizeDecisionRow,
  emptyDecisionDoc,
} = require('../../src/edge/routes/app/schema/decision-doc');

function docWith(overrides = {}) {
  return {
    conditions: [{ field_key: 'material' }, { field_key: 'size' }],
    outputs: [{ field_key: 'part_no' }],
    rows: [
      { when: { material: 'steel', size: 'M' }, then: { part_no: 'P-1' } },
      { when: { material: 'steel', size: 'L' }, then: { part_no: 'P-2' } },
    ],
    ...overrides,
  };
}

describe('validateDecisionDoc — accepted documents', () => {
  it('accepts a well-formed multi-condition document', () => {
    assert.equal(validateDecisionDoc(docWith()).ok, true);
  });

  it('accepts the empty document a fresh table starts with', () => {
    assert.equal(validateDecisionDoc(emptyDecisionDoc()).ok, true);
  });

  it('accepts scalar cell values of every supported type', () => {
    const doc = {
      conditions: [{ field_key: 'a' }],
      outputs: [{ field_key: 'b' }],
      rows: [
        { when: { a: 1 }, then: { b: true } },
        { when: { a: 'x' }, then: { b: null } },
      ],
    };
    assert.equal(validateDecisionDoc(doc).ok, true);
  });

  it('accepts a partially-filled row (sparse when/then are allowed)', () => {
    const doc = docWith({ rows: [{ when: { material: 'steel' }, then: {} }] });
    assert.equal(validateDecisionDoc(doc).ok, true);
  });
});

describe('validateDecisionDoc — the document it judged is the document it returns', () => {
  it('hands back the trimmed key, in the declarations and in every row that names it', () => {
    // Emptiness was decided on `key.trim()` and the untrimmed spelling was
    // stored, so a table with a ' material' condition saved, reported healthy,
    // and silently never fired: these keys are matched against
    // blueprint_fields.field_key by exact string, and nothing holds that one.
    const verdict = validateDecisionDoc({
      conditions: [{ field_key: ' material ' }],
      outputs: [{ field_key: 'part_no ' }],
      rows: [{ when: { ' material ': 'steel' }, then: { 'part_no ': 'P-1' } }],
    });
    assert.equal(verdict.ok, true);
    assert.deepEqual(verdict.doc.conditions, [{ field_key: 'material' }]);
    assert.deepEqual(verdict.doc.outputs, [{ field_key: 'part_no' }]);
    assert.deepEqual(verdict.doc.rows, [{ when: { material: 'steel' }, then: { part_no: 'P-1' } }]);
  });

  it('refuses two declarations that are one key after trimming', () => {
    const verdict = validateDecisionDoc({
      conditions: [{ field_key: 'material' }, { field_key: ' material' }],
      outputs: [{ field_key: 'part_no' }],
      rows: [],
    });
    assert.equal(verdict.ok, false);
    assert.match(verdict.message, /more than once/);
  });

  it('refuses a row side that names one key twice after trimming', () => {
    // Left to normalise silently, one of the two cells would survive and which
    // one would depend on iteration order.
    const verdict = validateDecisionDoc({
      conditions: [{ field_key: 'material' }],
      outputs: [{ field_key: 'part_no' }],
      rows: [{ when: { material: 'steel', ' material': 'brass' }, then: {} }],
    });
    assert.equal(verdict.ok, false);
    assert.match(verdict.message, /more than once/);
  });
});

describe('validateDecisionDoc — prototype-shaped row keys', () => {
  it('a row cell keyed `__proto__` (a deleted field\'s row key) is an own key of the normalised row, not a rewrite of Object.prototype', () => {
    // Built the way an HTTP JSON body actually arrives: JSON.parse gives
    // `__proto__` as a genuine own property (never the object-literal
    // prototype-setting shorthand), exactly as any other row key would be a
    // caller-controlled field_key naming a field that was later deleted —
    // which this document is explicitly allowed to reference.
    const thenSide = JSON.parse('{"part_no":"P-1","__proto__":"X"}');
    const verdict = validateDecisionDoc(docWith({
      outputs: [{ field_key: 'part_no' }, { field_key: '__proto__' }],
      rows: [{ when: { material: 'steel', size: 'M' }, then: thenSide }],
    }));
    assert.equal(verdict.ok, true);
    const persisted = verdict.doc.rows[0].then;
    // A plain `{}` accumulator would route `out['__proto__'] = 'X'` through
    // Object.prototype's legacy setter instead of creating an own property —
    // the assignment silently no-ops and the cell vanishes from the document
    // this function reports as valid. getOwnPropertyDescriptor is the direct
    // check: it is undefined when the cell was dropped, present when it was
    // stored as an ordinary key.
    const descriptor = Object.getOwnPropertyDescriptor(persisted, '__proto__');
    assert.ok(descriptor, 'the __proto__ cell must survive as an own property, not be silently dropped');
    assert.equal(descriptor.value, 'X');
  });
});

describe('validateDecisionDoc — structural rejections', () => {
  const cases = [
    ['null', null],
    ['an array', []],
    ['a number', 7],
    // A pre-serialised document would otherwise pass straight through
    // mapRowToDb (which only stringifies non-strings) and land unvalidated.
    ['a JSON string', JSON.stringify(docWith())],
  ];
  for (const [label, value] of cases) {
    it(`rejects ${label}`, () => {
      const verdict = validateDecisionDoc(value);
      assert.equal(verdict.ok, false);
      assert.equal(verdict.status, 400);
      assert.equal(verdict.code, 'INVALID_DECISION_DOC');
      // The MESSAGE, not just the code: only the is-it-an-object guard produces
      // this one. Asserting the code alone passes for the wrong reason — delete
      // the guard and a string still fails, three lines later, because
      // Object.keys('…') yields index keys that trip the unknown-key check, and
      // an array fails on its own missing conditions. A test named for a guard
      // must fail when that guard is removed.
      assert.match(verdict.message, /doc must be an object/);
    });
  }

  it('rejects an unsupported top-level key', () => {
    const verdict = validateDecisionDoc(docWith({ evil: 1 }));
    assert.equal(verdict.ok, false);
    assert.match(verdict.message, /unsupported key/);
  });

  it('rejects a non-array conditions/outputs/rows', () => {
    for (const key of ['conditions', 'outputs', 'rows']) {
      const verdict = validateDecisionDoc(docWith({ [key]: {} }));
      assert.equal(verdict.ok, false, `${key} must be array-checked`);
      assert.match(verdict.message, new RegExp(`doc\\.${key} must be an array`));
    }
  });

  it('rejects a column entry with an unsupported key', () => {
    const verdict = validateDecisionDoc(
      docWith({ outputs: [{ field_key: 'part_no', label: 'Part' }] }),
    );
    assert.equal(verdict.ok, false);
    assert.match(verdict.message, /unsupported key/);
  });

  it('rejects an empty or non-string field_key', () => {
    for (const bad of ['', '   ', 42, null]) {
      const verdict = validateDecisionDoc(docWith({ outputs: [{ field_key: bad }] }));
      assert.equal(verdict.ok, false, `field_key ${JSON.stringify(bad)} must be rejected`);
    }
  });

  it('rejects a duplicate field_key within one list', () => {
    const verdict = validateDecisionDoc(
      docWith({ conditions: [{ field_key: 'material' }, { field_key: 'material' }] }),
    );
    assert.equal(verdict.ok, false);
    assert.match(verdict.message, /more than once/);
  });
});

describe('validateDecisionDoc — semantic invariants', () => {
  it('rejects a field that is both a condition and an output (self-feeding table)', () => {
    const verdict = validateDecisionDoc(
      docWith({ outputs: [{ field_key: 'material' }], rows: [] }),
    );
    assert.equal(verdict.ok, false);
    assert.match(verdict.message, /cannot feed itself/);
  });

  it('rejects a row whose `when` names an undeclared condition', () => {
    const verdict = validateDecisionDoc(
      docWith({ rows: [{ when: { colour: 'red' }, then: { part_no: 'P-1' } }] }),
    );
    assert.equal(verdict.ok, false);
    assert.match(verdict.message, /does not declare/);
  });

  it('rejects a row whose `then` names an output that is not declared', () => {
    const verdict = validateDecisionDoc(
      docWith({ rows: [{ when: { material: 'steel' }, then: { weight: '3' } }] }),
    );
    assert.equal(verdict.ok, false);
    assert.match(verdict.message, /does not declare/);
  });

  it('rejects a row whose `then` names a CONDITION key (outputs only)', () => {
    const verdict = validateDecisionDoc(
      docWith({ rows: [{ when: { material: 'steel' }, then: { size: 'M' } }] }),
    );
    assert.equal(verdict.ok, false);
    assert.match(verdict.message, /does not declare/);
  });

  it('rejects a non-scalar cell value', () => {
    for (const bad of [{ nested: 1 }, ['a'], undefined]) {
      const verdict = validateDecisionDoc(
        docWith({ rows: [{ when: { material: bad }, then: {} }] }),
      );
      assert.equal(verdict.ok, false, `cell value ${JSON.stringify(bad)} must be rejected`);
    }
  });

  it('rejects a row missing `when`/`then` or carrying an extra key', () => {
    assert.equal(validateDecisionDoc(docWith({ rows: [{ then: {} }] })).ok, false);
    assert.equal(validateDecisionDoc(docWith({ rows: [{ when: {} }] })).ok, false);
    assert.equal(
      validateDecisionDoc(docWith({ rows: [{ when: {}, then: {}, note: 'x' }] })).ok,
      false,
    );
  });
});

describe('validateDecisionDoc — size bound', () => {
  it('rejects a document over the byte cap with 413', () => {
    // One oversized cell value is enough: the cap is on the serialised
    // document, not on the row count.
    const doc = {
      conditions: [{ field_key: 'a' }],
      outputs: [],
      rows: [{ when: { a: 'x'.repeat(MAX_DECISION_DOC_BYTES + 1) }, then: {} }],
    };
    const verdict = validateDecisionDoc(doc);
    assert.equal(verdict.ok, false);
    assert.equal(verdict.status, 413);
    assert.equal(verdict.code, 'DECISION_DOC_TOO_LARGE');
  });

  it('accepts a document just under the byte cap', () => {
    const filler = 'x'.repeat(MAX_DECISION_DOC_BYTES - 200);
    const doc = {
      conditions: [{ field_key: 'a' }],
      outputs: [],
      rows: [{ when: { a: filler }, then: {} }],
    };
    assert.ok(Buffer.byteLength(JSON.stringify(doc), 'utf8') < MAX_DECISION_DOC_BYTES);
    assert.equal(validateDecisionDoc(doc).ok, true);
  });

  it('measures BYTES, not characters (multi-byte content counts fully)', () => {
    // '€' is 3 UTF-8 bytes; a string of length cap/2 is under the cap by
    // character count but far over it by bytes.
    const doc = {
      conditions: [{ field_key: 'a' }],
      outputs: [],
      rows: [{ when: { a: '€'.repeat(Math.floor(MAX_DECISION_DOC_BYTES / 2)) }, then: {} }],
    };
    const verdict = validateDecisionDoc(doc);
    assert.equal(verdict.ok, false);
    assert.equal(verdict.code, 'DECISION_DOC_TOO_LARGE');
  });
});

describe('normalizeDecisionRow — read contract', () => {
  it('replaces a NULL doc with an empty document', () => {
    const row = normalizeDecisionRow({ id: 'd1', doc: null });
    assert.deepEqual(row.doc, { conditions: [], outputs: [], rows: [] });
  });

  it('replaces an unparsable (still-string) doc with an empty document', () => {
    const row = normalizeDecisionRow({ id: 'd1', doc: 'not json' });
    assert.deepEqual(row.doc, { conditions: [], outputs: [], rows: [] });
  });

  it('passes a parsed document through by identity', () => {
    const input = { id: 'd1', doc: docWith() };
    assert.equal(normalizeDecisionRow(input), input);
  });

  it('hands out a fresh empty document each time (no shared mutable default)', () => {
    const a = normalizeDecisionRow({ id: 'a', doc: null }).doc;
    const b = normalizeDecisionRow({ id: 'b', doc: null }).doc;
    a.rows.push({ when: {}, then: {} });
    assert.deepEqual(b.rows, []);
  });
});
