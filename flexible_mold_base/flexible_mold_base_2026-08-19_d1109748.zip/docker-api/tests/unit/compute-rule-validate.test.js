const test = require('node:test');
const assert = require('node:assert/strict');
const {
  validateComputeRule,
  MAX_CONCAT_PARTS,
  MAX_ARITH_OPERANDS,
  MAX_LOOKUP_ROWS,
} = require('../../src/edge/lib/compute-rule-validate');

const fieldKeys = new Set(['model', 'qty', 'price', 'part_no']);

test('accepts a valid concat rule', () => {
  const rule = { op: 'concat', overridable: true, output_type: 'string',
    config: { parts: [{ type: 'field', key: 'model' }, { type: 'literal', text: '-US' }] } };
  assert.deepEqual(validateComputeRule(rule, { fieldKeys, targetType: 'string' }), { ok: true });
});

test('rejects unknown op', () => {
  const r = validateComputeRule({ op: 'danger', overridable: true, output_type: 'string', config: {} },
    { fieldKeys, targetType: 'string' });
  assert.equal(r.ok, false);
  assert.equal(r.code, 'unknown_op');
});

test('rejects output_type mismatch with target field', () => {
  const rule = { op: 'concat', overridable: true, output_type: 'string', config: { parts: [] } };
  const r = validateComputeRule(rule, { fieldKeys, targetType: 'number' });
  assert.equal(r.ok, false);
  assert.equal(r.code, 'output_type_mismatch');
});

test('rejects a source field that does not exist', () => {
  const rule = { op: 'transform', overridable: true, output_type: 'string',
    config: { source: 'ghost', transform: 'upper' } };
  const r = validateComputeRule(rule, { fieldKeys, targetType: 'string' });
  assert.equal(r.ok, false);
  assert.equal(r.code, 'missing_source');
});

test('rejects unknown transform kind', () => {
  const rule = { op: 'transform', overridable: true, output_type: 'string',
    config: { source: 'model', transform: 'explode' } };
  const r = validateComputeRule(rule, { fieldKeys, targetType: 'string' });
  assert.equal(r.ok, false);
  assert.equal(r.code, 'unknown_transform');
});

test('rejects non-boolean overridable', () => {
  const rule = { op: 'concat', overridable: 'yes', output_type: 'string', config: { parts: [] } };
  const r = validateComputeRule(rule, { fieldKeys, targetType: 'string' });
  assert.equal(r.ok, false);
  assert.equal(r.code, 'bad_overridable');
});

const cellCtx = {
  fieldKeys: new Set(['prefix', 'items', 'pn']),
  targetType: 'string',
  tableColumns: new Map([['items', new Set(['part', 'qty'])]]),
};
const cellRule = (cell) => ({
  op: 'concat', overridable: true, output_type: 'string',
  config: { parts: [{ type: 'table_cell', cell }] },
});

test('accepts a valid table_cell', () => {
  const r = validateComputeRule(cellRule({ table_key: 'items', column_key: 'part', row: 'first' }), cellCtx);
  assert.equal(r.ok, true);
});

test('rejects an unknown table_key', () => {
  const r = validateComputeRule(cellRule({ table_key: 'nope', column_key: 'part', row: 'first' }), cellCtx);
  assert.equal(r.code, 'bad_table_cell');
});

test('rejects an unknown column_key', () => {
  const r = validateComputeRule(cellRule({ table_key: 'items', column_key: 'nope', row: 'first' }), cellCtx);
  assert.equal(r.code, 'bad_table_cell');
});

test('rejects a bad row selector', () => {
  const r = validateComputeRule(cellRule({ table_key: 'items', column_key: 'part', row: 'third' }), cellCtx);
  assert.equal(r.code, 'bad_table_cell');
});

test('rejects a non-table field used as table_key', () => {
  const r = validateComputeRule(cellRule({ table_key: 'prefix', column_key: 'part', row: 'first' }), cellCtx);
  assert.equal(r.code, 'bad_table_cell');
});

test("accepts a 'value' column_key for a simple (no-columns) table", () => {
  // A table field with no explicit columns resolves to a single 'value'
  // column; loadComputeValidationContext seeds tableColumns with that key.
  const ctx = {
    fieldKeys: new Set(['simple', 'pn']),
    targetType: 'string',
    tableColumns: new Map([['simple', new Set(['value'])]]),
  };
  const r = validateComputeRule(
    cellRule({ table_key: 'simple', column_key: 'value', row: 'first' }),
    ctx,
  );
  assert.equal(r.ok, true);
});

test('accepts a valid arith table_cell operand', () => {
  const r = { op: 'arith', overridable: true, output_type: 'number',
    config: { operator: 'add', operands: [
      { type: 'literal', value: 1 },
      { type: 'table_cell', cell: { table_key: 'items', column_key: 'qty', row: 'last' } },
    ] } };
  assert.equal(validateComputeRule(r, { ...cellCtx, targetType: 'number' }).ok, true);
});

// ── Size bounds ─────────────────────────────────────────────────────────────
// Every one of these arrays is walked once per validation and again once per
// cycle-guard pass, and the guard runs one pass per variant carrying a compute
// override. Unbounded, a single accepted rule sets the CPU cost of an
// authenticated write. The rejection has to name the limit — the author needs
// to know what to trim to.

const parts = (n) => ({
  op: 'concat', overridable: true, output_type: 'string',
  config: { parts: Array.from({ length: n }, () => ({ type: 'literal', text: 'x' })) },
});
const operands = (n) => ({
  op: 'arith', overridable: true, output_type: 'number',
  config: { operator: 'add', operands: Array.from({ length: n }, () => ({ type: 'literal', value: 1 })) },
});
const lookupRows = (n) => ({
  op: 'lookup', overridable: true, output_type: 'string',
  config: { source: 'model', table: Array.from({ length: n }, (_, i) => ({ in: `i${i}`, out: 'o' })) },
});

test('accepts concat.parts at the limit and rejects one past it', () => {
  assert.equal(validateComputeRule(parts(MAX_CONCAT_PARTS), { fieldKeys, targetType: 'string' }).ok, true);
  const r = validateComputeRule(parts(MAX_CONCAT_PARTS + 1), { fieldKeys, targetType: 'string' });
  assert.equal(r.ok, false);
  assert.equal(r.code, 'too_many_parts');
  assert.match(r.detail, new RegExp(String(MAX_CONCAT_PARTS)));
});

test('accepts arith.operands at the limit and rejects one past it', () => {
  assert.equal(validateComputeRule(operands(MAX_ARITH_OPERANDS), { fieldKeys, targetType: 'number' }).ok, true);
  const r = validateComputeRule(operands(MAX_ARITH_OPERANDS + 1), { fieldKeys, targetType: 'number' });
  assert.equal(r.ok, false);
  assert.equal(r.code, 'too_many_operands');
  assert.match(r.detail, new RegExp(String(MAX_ARITH_OPERANDS)));
});

test('accepts lookup.table at the limit and rejects one past it', () => {
  assert.equal(validateComputeRule(lookupRows(MAX_LOOKUP_ROWS), { fieldKeys, targetType: 'string' }).ok, true);
  const r = validateComputeRule(lookupRows(MAX_LOOKUP_ROWS + 1), { fieldKeys, targetType: 'string' });
  assert.equal(r.ok, false);
  assert.equal(r.code, 'too_many_lookup_rows');
  assert.match(r.detail, new RegExp(String(MAX_LOOKUP_ROWS)));
});

// ── Malformed entries ───────────────────────────────────────────────────────
// Every caller is written against the {ok:false, code} contract and several of
// them run before their route opens a transaction, outside its try/catch. A
// throw from here is therefore not a 500 — it escapes an async handler as an
// unhandled rejection and takes the process down. The entries arrive straight
// from an uploaded payload, so anything JSON can express has to land on a
// rejection instead of a property read.
const MALFORMED_ENTRIES = [
  ['null', null],
  ['a number', 42],
  ['a string', 'x'],
  ['an array', []],
  ['a boolean', true],
];

for (const [label, entry] of MALFORMED_ENTRIES) {
  test(`rejects ${label} in concat.parts without throwing`, () => {
    const rule = { op: 'concat', overridable: true, output_type: 'string',
      config: { parts: [{ type: 'field', key: 'model' }, entry] } };
    const r = validateComputeRule(rule, { fieldKeys, targetType: 'string' });
    assert.equal(r.ok, false);
    assert.equal(r.code, 'bad_config');
  });

  test(`rejects ${label} in arith.operands without throwing`, () => {
    const rule = { op: 'arith', overridable: true, output_type: 'number',
      config: { operator: 'add', operands: [{ type: 'literal', value: 1 }, entry] } };
    const r = validateComputeRule(rule, { fieldKeys, targetType: 'number' });
    assert.equal(r.ok, false);
    assert.equal(r.code, 'bad_config');
  });

  test(`rejects ${label} in lookup.table without throwing`, () => {
    const rule = { op: 'lookup', overridable: true, output_type: 'string',
      config: { source: 'model', table: [{ in: 'a', out: 'b' }, entry] } };
    const r = validateComputeRule(rule, { fieldKeys, targetType: 'string' });
    assert.equal(r.ok, false);
    assert.equal(r.code, 'bad_config');
  });
}

test('a malformed entry is rejected wherever it sits in the array', () => {
  const rule = { op: 'concat', overridable: true, output_type: 'string',
    config: { parts: [null, { type: 'field', key: 'model' }] } };
  assert.equal(validateComputeRule(rule, { fieldKeys, targetType: 'string' }).code, 'bad_config');
});

test('the oversize check runs before the per-entry walk', () => {
  // An oversize array must be rejected on its length alone; walking it first
  // would pay exactly the cost the bound exists to prevent.
  const rule = parts(MAX_CONCAT_PARTS + 1);
  let touched = 0;
  const counted = rule.config.parts.map((p) => new Proxy(p, {
    get(target, prop) { touched += 1; return target[prop]; },
  }));
  const r = validateComputeRule(
    { ...rule, config: { parts: counted } },
    { fieldKeys, targetType: 'string' },
  );
  assert.equal(r.code, 'too_many_parts');
  assert.equal(touched, 0);
});
