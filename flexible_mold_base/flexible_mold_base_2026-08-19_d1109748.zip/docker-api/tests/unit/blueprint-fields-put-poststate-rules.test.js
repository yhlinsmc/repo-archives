/**
 * blueprint-fields-put-poststate-rules.test.js
 *
 * PUT /blueprint_fields/:id is a PARTIAL write, so the pre-write compute-rule
 * guard only fires when the request itself carries a rule. A request that
 * changes what the rule is judged against — the field's type, its key, the
 * blueprint it belongs to, or a table's column set — could therefore leave a
 * rule behind that the same API would refuse to accept today.
 *
 * These tests pin the post-write judgement:
 *   - a stale rule on the field the operator is changing is CLEARED and audited
 *     (the change was asked for; the rule is collateral);
 *   - a rule on ANOTHER field that this change would break REJECTS the write
 *     (that row is not the subject of the request, and clearing it would delete
 *     authored logic nobody asked to touch);
 *   - a rule the request itself authors is REJECTED rather than cleared;
 *   - a rule that was already invalid before the write never blocks an
 *     unrelated change (otherwise a broken DB could not be repaired).
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const { checkValueSourcePayload } = require('../../src/shared/field-value-source');
const { parseStoredRule } = require('../../src/edge/lib/compute-rule-graph');

const dbKey = require.resolve('../../src/edge/db');

const DATABASE_PROBE = /^SELECT DATABASE\(\)/i;
const COLUMN_PROBE = /SELECT COLUMN_NAME FROM information_schema\.COLUMNS/i;
const COMPUTE_STATE = /SELECT field_key, field_type, table_config, compute_rule FROM `fmb_blueprint_fields`/i;
const FIELD_UPDATE = /^UPDATE `fmb_blueprint_fields` SET/i;

const BF_COLUMNS = [
  'id', 'blueprint_id', 'field_type', 'field_key', 'field_label',
  'table_config', 'depends_on_field_key', 'value_source', 'value_scope', 'compute_rule',
];

// arith over a field source → a number-output rule, valid only on a number field.
const TOTAL_RULE = {
  op: 'arith',
  overridable: false,
  output_type: 'number',
  config: { operator: 'add', operands: [{ type: 'field', key: 'qty' }, { type: 'literal', value: 1 }] },
};

// A number-output rule reading one cell of the `tbl` table field.
const CELL_RULE = {
  op: 'arith',
  overridable: false,
  output_type: 'number',
  config: {
    operator: 'add',
    operands: [
      { type: 'table_cell', cell: { table_key: 'tbl', column_key: 'a', row: 'first' } },
      { type: 'literal', value: 0 },
    ],
  },
};

let conn;
let dbSeq = 0;

/**
 * Fold one `UPDATE … SET` into the row it addresses.
 *
 * The post-state row is DERIVED from the statements the handler issued rather
 * than declared by the fixture. A hardcoded refreshed row is how the
 * mode/payload disagreement this suite now pins stayed invisible: the row the
 * test read back was coherent because the test said so, while the statements
 * left the real row saying 'calculated' over a NULL rule.
 */
function applySets(row, sql, params) {
  const set = /SET\s+([\s\S]*?)\s+WHERE\s/i.exec(sql);
  if (!set) return row;
  const next = { ...row };
  let i = 0;
  for (const clause of set[1].split(',')) {
    const m = /^\s*`?([a-z_]+)`?\s*=\s*(\?|NULL)\s*$/i.exec(clause);
    if (!m) continue;
    next[m[1]] = m[2] === '?' ? params[i += 1, i - 1] : null;
  }
  return next;
}

/**
 * @param {object} opts
 * @param {object} opts.oldRow            the row the PUT addresses
 * @param {object[]} opts.preRows         blueprint field rows before the write
 * @param {object[]} opts.postRows        blueprint field rows after the write
 */
function makeConn({ oldRow, preRows, postRows, columns = BF_COLUMNS }) {
  const dbName = `db_${dbSeq += 1}`;
  const queries = [];
  let committed = false;
  let rolledBack = false;
  let written = false;
  // The stored row, as the handler's own statements leave it.
  let row = Object.fromEntries(Object.entries(
    { value_source: 'entered', value_scope: null, compute_rule: null, ...oldRow },
  ).filter(([k]) => !['value_source', 'value_scope', 'compute_rule'].includes(k)
    || columns.includes(k)));
  return {
    queries,
    committed: () => committed,
    rolledBack: () => rolledBack,
    storedRow: () => row,
    async beginTransaction() {},
    async commit() { committed = true; },
    async rollback() { rolledBack = true; },
    async query(sql, params) {
      queries.push({ sql, params });
      if (DATABASE_PROBE.test(sql)) return [{ db: dbName }];
      if (COLUMN_PROBE.test(sql)) {
        const table = Array.isArray(params) ? params[0] : undefined;
        if (table === 'fmb_field_options') {
          return ['id', 'field_id', 'option_value', 'valid_parent_values'].map((c) => ({ COLUMN_NAME: c }));
        }
        if (table === 'fmb_variant_overrides') {
          return ['id', 'variant_id', 'field_id', 'action', 'cell_targets'].map((c) => ({ COLUMN_NAME: c }));
        }
        return columns.map((c) => ({ COLUMN_NAME: c }));
      }
      if (/SELECT id, blueprint_id, field_type/.test(sql)) return [oldRow];
      // The blueprint-wide scan answers with the state that matches the phase of
      // the request: the row set the write has not touched yet, then the row set
      // it produced.
      if (COMPUTE_STATE.test(sql)) return written ? postRows : preRows;
      if (/SELECT vo\.variant_id, bf\.field_key, vo\.compute_rule/i.test(sql)) return [];
      // The reference cascade that rides along with a key move: it repoints
      // OTHER rows in the blueprint, matched by the old key's VALUE, so it must
      // NOT be folded into the row this stub is tracking.
      if (/^UPDATE `fmb_blueprint_fields`[\s\S]*BINARY \?/i.test(sql)) return { affectedRows: 0 };
      if (FIELD_UPDATE.test(sql.trim())) {
        written = true;
        row = applySets(row, sql, params);
        return { affectedRows: 1 };
      }
      if (/^UPDATE `fmb_variant_overrides`/i.test(sql)) return { affectedRows: 0 };
      if (/^DELETE FROM `fmb_field_options`/i.test(sql)) return { affectedRows: 0 };
      if (/^INSERT INTO `fmb_feature_audit`/i.test(sql)) return { affectedRows: 1 };
      if (/^SELECT \* FROM `fmb_blueprint_fields`/i.test(sql)) return [row];
      if (/SELECT linked_blueprint_id FROM/.test(sql)) return [];
      if (/ AS bid FROM/.test(sql) || / AS fk FROM/.test(sql)) return [];
      // The identity question the write path now asks the ENGINE (write-value.js
      // `sameStoredValue`): are these two spellings one stored value? Answered
      // here the way the column's collation answers it — case-folded, trailing
      // space padded — so this double cannot disagree with the database about
      // whether a write moved a value. The instrument that settles it for real
      // is tests/integration/blueprint-field-write-real-db.test.js.
      if (/CHARACTER_SET_NAME AS cs/.test(sql)) return [{ cs: 'utf8mb4', co: 'utf8mb4_general_ci' }];
      if (/<=>/.test(sql) && / AS same/.test(sql)) {
        const fold = (v) => String(v).toLowerCase().replace(/\s+$/, '');
        return [{ same: fold((params || [])[0]) === fold((params || [])[1]) ? 1 : 0 }];
      }
      // The (blueprint, key) clash probe both write paths now run before they can
      // create the duplicate the migration endpoint would turn into a merge.
      // Nothing collides in these fixtures; the case that does is settled on a
      // real database (tests/integration/blueprint-field-write-real-db.test.js).
      if (/FROM `fmb_blueprint_fields`/i.test(sql) && /`?field_key`? = \?/i.test(sql)
          && /LIMIT 1/i.test(sql)) {
        return [];
      }
      throw new Error(`Unmatched query in test: ${sql.slice(0, 110)}`);
    },
    release() {},
  };
}

const poolSpy = {
  rw: { async getConnection() { return conn; } },
  ro: { async getConnection() { throw new Error('test error: PUT should use pool.rw'); } },
};

require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: poolSpy, t: (name) => `fmb_${name}`, getDynamicPool: async () => poolSpy },
};

const router = require('../../src/edge/routes/app/schema');

let server;
let port;

before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { req.user = { id: 'admin-1', role: 'admin' }; next(); });
  app.use('/edge/app/schema', router);
  await new Promise((resolve) => {
    server = app.listen(0, '127.0.0.1', () => { port = server.address().port; resolve(); });
  });
});

after(async () => {
  await new Promise((resolve) => server.close(resolve));
  delete require.cache[dbKey];
});

beforeEach(() => { conn = null; });

function put(path, body) {
  return new Promise((resolve, reject) => {
    const data = JSON.stringify(body);
    const r = http.request({
      method: 'PUT', host: '127.0.0.1', port, path,
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(data) },
    }, (res) => {
      let raw = '';
      res.on('data', (c) => { raw += c; });
      res.on('end', () => resolve({ status: res.statusCode, body: raw ? JSON.parse(raw) : null }));
    });
    r.on('error', reject);
    r.write(data);
    r.end();
  });
}

const ruleClear = (queries) => queries.find(
  (q) => FIELD_UPDATE.test(q.sql.trim()) && /compute_rule = NULL/i.test(q.sql),
);
const clearAudit = (queries) => queries.find(
  (q) => /INSERT INTO `fmb_feature_audit`/i.test(q.sql)
    && /blueprint\.field\.compute_rule_cleared/.test(q.sql),
);

const TOTAL_NUMBER = { field_key: 'total', field_type: 'number', table_config: null, compute_rule: JSON.stringify(TOTAL_RULE) };
const TOTAL_TEXT = { ...TOTAL_NUMBER, field_type: 'text' };
const QTY = { field_key: 'qty', field_type: 'number', table_config: null, compute_rule: null };
const QTY_RENAMED = { ...QTY, field_key: 'quantity' };

describe('PUT /blueprint_fields/:id — the rule set after the write', () => {
  it('clears a stale rule the type change invalidated, and audits the clear', async () => {
    conn = makeConn({
      oldRow: { id: 'f-total', blueprint_id: 'bp-1', field_type: 'number', field_key: 'total', depends_on_field_key: null },
      preRows: [QTY, TOTAL_NUMBER],
      postRows: [QTY, TOTAL_TEXT],
    });
    const res = await put('/edge/app/schema/blueprint_fields/f-total', { field_type: 'text' });
    assert.equal(res.status, 200, JSON.stringify(res.body));
    assert.ok(ruleClear(conn.queries), 'the now-invalid rule must be cleared, not left on the row');
    assert.ok(clearAudit(conn.queries), 'the clear must leave an audit trail');
    assert.equal(conn.committed(), true);
  });

  it('clears it just the same when the editor spreads the unchanged rule into the body', async () => {
    // The field editor always sends the whole form, so the stale rule rides
    // along with the type change. That is not an authored rule write and must
    // not turn an explicitly requested type change into a 400.
    conn = makeConn({
      oldRow: { id: 'f-total', blueprint_id: 'bp-1', field_type: 'number', field_key: 'total', depends_on_field_key: null, value_source: 'calculated' },
      preRows: [QTY, TOTAL_NUMBER],
      postRows: [QTY, TOTAL_TEXT],
    });
    const res = await put('/edge/app/schema/blueprint_fields/f-total', {
      field_type: 'text', value_source: 'calculated', compute_rule: TOTAL_RULE,
    });
    assert.equal(res.status, 200, JSON.stringify(res.body));
    assert.ok(ruleClear(conn.queries), 'the passenger rule must be cleared with the type change');
    assert.equal(conn.committed(), true);
  });

  // ── the mode moves with its payload ──────────────────────────────────
  //
  // This clear is the one write in the codebase that changes a MODE_OWNED
  // column, and it used to change only that column. The resulting row said
  // value_source='calculated' over compute_rule=NULL — the exact combination
  // the write boundary refuses on every request path, 490 lines above this
  // statement in the same handler. Nothing surfaced it, because the assertions
  // here stopped at "the rule is gone".

  it('drops the mode with the rule, so the row it writes is one the boundary accepts', async () => {
    conn = makeConn({
      oldRow: { id: 'f-total', blueprint_id: 'bp-1', field_type: 'number', field_key: 'total', depends_on_field_key: null, value_source: 'calculated' },
      preRows: [QTY, TOTAL_NUMBER],
      postRows: [QTY, TOTAL_TEXT],
    });
    const res = await put('/edge/app/schema/blueprint_fields/f-total', {
      field_type: 'text', value_source: 'calculated', compute_rule: TOTAL_RULE,
    });
    assert.equal(res.status, 200, JSON.stringify(res.body));
    const row = conn.storedRow();
    assert.equal(row.compute_rule, null);
    assert.equal(row.value_source, 'entered', 'a mode naming a payload that is gone is not a row');
    // The property, asked of the boundary itself rather than restated here.
    assert.equal(
      checkValueSourcePayload(row, { fieldType: 'text', parseRule: parseStoredRule }),
      null,
    );
  });

  it('says in the audit which mode the field stopped being', async () => {
    conn = makeConn({
      oldRow: { id: 'f-total', blueprint_id: 'bp-1', field_type: 'number', field_key: 'total', depends_on_field_key: null, value_source: 'calculated' },
      preRows: [QTY, TOTAL_NUMBER],
      postRows: [QTY, TOTAL_TEXT],
    });
    await put('/edge/app/schema/blueprint_fields/f-total', { field_type: 'text' });
    const audit = clearAudit(conn.queries);
    assert.ok(audit);
    const meta = JSON.parse(audit.params[audit.params.length - 1]);
    assert.equal(meta.cleared_value_source, 'calculated');
  });

  it('lets the SAME form be saved a second time — the row is not bricked', async () => {
    // The failure this catches, end to end: after the type change the editor
    // reloads the row and spreads it back on the next save (a label edit is
    // enough). With the mode left behind, that second save was refused 400 for
    // a state the server itself had written, and for 'calculated' the editor
    // renders no rule builder, so there was nothing on screen to repair.
    const first = makeConn({
      oldRow: { id: 'f-total', blueprint_id: 'bp-1', field_type: 'number', field_key: 'total', depends_on_field_key: null, value_source: 'calculated' },
      preRows: [QTY, TOTAL_NUMBER],
      postRows: [QTY, TOTAL_TEXT],
    });
    conn = first;
    assert.equal(
      (await put('/edge/app/schema/blueprint_fields/f-total', {
        field_type: 'text', value_source: 'calculated', compute_rule: TOTAL_RULE,
      })).status,
      200,
    );
    const after = first.storedRow();

    // Second save: the whole form as the editor would reload and resend it.
    conn = makeConn({
      oldRow: { id: 'f-total', blueprint_id: 'bp-1', field_type: 'text', field_key: 'total', depends_on_field_key: null, value_source: after.value_source },
      preRows: [QTY, { ...TOTAL_TEXT, compute_rule: null }],
      postRows: [QTY, { ...TOTAL_TEXT, compute_rule: null }],
    });
    const res = await put('/edge/app/schema/blueprint_fields/f-total', {
      field_type: 'text',
      field_label: 'Total (renamed)',
      value_source: after.value_source,
      compute_rule: after.compute_rule,
    });
    assert.equal(res.status, 200, JSON.stringify(res.body));
  });

  // ── the row is what is validated, not the body ───────────────────────
  //
  // The third shape of one defect on this branch. The request boundary refuses
  // a payload written without its mode; the type-change clear now moves the
  // mode with its payload; and a PARTIAL PUT could still name a mode and say
  // nothing about the payload, so the body-level check read the absent column
  // as null and passed while the UPDATE left the stored rule in place. Checking
  // the resulting row is the answer to the class rather than to the shape.

  it('refuses a mode-only patch that would strand the stored rule', async () => {
    conn = makeConn({
      oldRow: {
        id: 'f-total', blueprint_id: 'bp-1', field_type: 'number', field_key: 'total',
        depends_on_field_key: null, value_source: 'calculated',
        compute_rule: JSON.stringify(TOTAL_RULE),
      },
      preRows: [QTY, TOTAL_NUMBER],
      postRows: [QTY, TOTAL_NUMBER],
    });
    const res = await put('/edge/app/schema/blueprint_fields/f-total', { value_source: 'entered' });
    assert.equal(res.status, 400, JSON.stringify(res.body));
    assert.equal(res.body.error.code, 'INCONSISTENT_VALUE_SOURCE');
    assert.match(res.body.error.message, /must not carry a compute_rule/);
    assert.equal(conn.committed(), false, 'the write must be rolled back');
  });

  it('refuses a mode-only patch that would strand the stored cell scope', async () => {
    conn = makeConn({
      oldRow: {
        id: 'f-tbl', blueprint_id: 'bp-1', field_type: 'table', field_key: 'nodes',
        depends_on_field_key: null, value_source: 'locked',
        value_scope: JSON.stringify({ columns: ['tier'] }),
      },
      preRows: [QTY],
      postRows: [QTY],
    });
    const res = await put('/edge/app/schema/blueprint_fields/f-tbl', { value_source: 'entered' });
    assert.equal(res.status, 400, JSON.stringify(res.body));
    assert.match(res.body.error.message, /'entered' must not carry a value_scope/);
    assert.equal(conn.committed(), false);
  });

  it('lets the same patch through when it clears the payload with the mode', async () => {
    conn = makeConn({
      oldRow: {
        id: 'f-total', blueprint_id: 'bp-1', field_type: 'number', field_key: 'total',
        depends_on_field_key: null, value_source: 'calculated',
        compute_rule: JSON.stringify(TOTAL_RULE),
      },
      preRows: [QTY, TOTAL_NUMBER],
      postRows: [QTY, { ...TOTAL_NUMBER, compute_rule: null }],
    });
    const res = await put('/edge/app/schema/blueprint_fields/f-total', {
      value_source: 'entered', compute_rule: null, value_scope: null,
    });
    assert.equal(res.status, 200, JSON.stringify(res.body));
    assert.equal(conn.storedRow().value_source, 'entered');
    assert.equal(conn.storedRow().compute_rule, null);
  });

  it('says nothing on a DB missing a mode-owned column, rather than bricking it', async () => {
    // The row cannot carry the payload the mode names, because the column was
    // never added. Refusing here would make every save of that field fail on
    // exactly the DB that can least afford it.
    conn = makeConn({
      oldRow: {
        id: 'f-total', blueprint_id: 'bp-1', field_type: 'number', field_key: 'total',
        depends_on_field_key: null, value_source: 'calculated',
      },
      preRows: [QTY],
      postRows: [QTY],
      columns: BF_COLUMNS.filter((c) => c !== 'compute_rule'),
    });
    const res = await put('/edge/app/schema/blueprint_fields/f-total', { field_label: 'Renamed' });
    assert.equal(res.status, 200, JSON.stringify(res.body));
  });

  it('leaves a mode that does not read the rule alone', async () => {
    // 'locked' and 'entered' do not run a stored rule, so a rule cleared out
    // from under them changes nothing they claim — and rewriting the mode would
    // silently unlock a field nobody asked to unlock.
    conn = makeConn({
      oldRow: { id: 'f-total', blueprint_id: 'bp-1', field_type: 'number', field_key: 'total', depends_on_field_key: null, value_source: 'locked' },
      preRows: [QTY, TOTAL_NUMBER],
      postRows: [QTY, TOTAL_TEXT],
    });
    const res = await put('/edge/app/schema/blueprint_fields/f-total', { field_type: 'text' });
    assert.equal(res.status, 200, JSON.stringify(res.body));
    assert.ok(ruleClear(conn.queries));
    assert.equal(conn.storedRow().value_source, 'locked');
  });

  it('still rejects a rule the request itself authors against the post-write type', async () => {
    conn = makeConn({
      oldRow: { id: 'f-total', blueprint_id: 'bp-1', field_type: 'number', field_key: 'total', depends_on_field_key: null },
      preRows: [QTY, TOTAL_NUMBER],
      postRows: [QTY, TOTAL_TEXT],
    });
    const authored = { ...TOTAL_RULE, config: { operator: 'mul', operands: [{ type: 'field', key: 'qty' }, { type: 'literal', value: 2 }] } };
    const res = await put('/edge/app/schema/blueprint_fields/f-total', {
      field_type: 'text', value_source: 'calculated', compute_rule: authored,
    });
    assert.equal(res.status, 400, JSON.stringify(res.body));
    assert.equal(res.body.error.code, 'output_type_mismatch');
    assert.equal(conn.committed(), false);
  });

  it('rejects a rename that would strand another field rule on a missing source', async () => {
    conn = makeConn({
      oldRow: { id: 'f-qty', blueprint_id: 'bp-1', field_type: 'number', field_key: 'qty', depends_on_field_key: null },
      preRows: [QTY, TOTAL_NUMBER],
      postRows: [QTY_RENAMED, TOTAL_NUMBER],
    });
    const res = await put('/edge/app/schema/blueprint_fields/f-qty', { field_key: 'quantity' });
    assert.equal(res.status, 409, JSON.stringify(res.body));
    assert.equal(res.body.error.code, 'COMPUTE_RULE_DEPENDENTS');
    assert.match(res.body.error.message, /total/);
    assert.equal(conn.rolledBack(), true);
    assert.equal(conn.committed(), false);
  });

  it('rejects dropping a table column another field rule reads', async () => {
    const tblBefore = { field_key: 'tbl', field_type: 'table', table_config: JSON.stringify({ columns: [{ key: 'a' }, { key: 'b' }] }), compute_rule: null };
    const tblAfter = { ...tblBefore, table_config: JSON.stringify({ columns: [{ key: 'b' }] }) };
    const cellReader = { field_key: 'total', field_type: 'number', table_config: null, compute_rule: JSON.stringify(CELL_RULE) };
    conn = makeConn({
      oldRow: { id: 'f-tbl', blueprint_id: 'bp-1', field_type: 'table', field_key: 'tbl', depends_on_field_key: null },
      preRows: [tblBefore, cellReader],
      postRows: [tblAfter, cellReader],
    });
    const res = await put('/edge/app/schema/blueprint_fields/f-tbl', {
      table_config: { columns: [{ key: 'b' }] },
    });
    assert.equal(res.status, 409, JSON.stringify(res.body));
    assert.equal(res.body.error.code, 'COMPUTE_RULE_DEPENDENTS');
    assert.equal(conn.committed(), false);
  });

  it('rejects a type change that makes another field cell rule unaddressable', async () => {
    const tblBefore = { field_key: 'tbl', field_type: 'table', table_config: JSON.stringify({ columns: [{ key: 'a' }] }), compute_rule: null };
    const tblAfter = { ...tblBefore, field_type: 'text', table_config: null };
    const cellReader = { field_key: 'total', field_type: 'number', table_config: null, compute_rule: JSON.stringify(CELL_RULE) };
    conn = makeConn({
      oldRow: { id: 'f-tbl', blueprint_id: 'bp-1', field_type: 'table', field_key: 'tbl', depends_on_field_key: null },
      preRows: [tblBefore, cellReader],
      postRows: [tblAfter, cellReader],
    });
    const res = await put('/edge/app/schema/blueprint_fields/f-tbl', { field_type: 'text' });
    assert.equal(res.status, 409, JSON.stringify(res.body));
    assert.equal(conn.committed(), false);
  });

  it('lets a rule that was already invalid before the write stay out of the way', async () => {
    // A rule stored by an older release (or by hand) must not turn every later
    // schema edit into a rejection — that would leave the blueprint unfixable.
    const legacy = { field_key: 'legacy', field_type: 'text', table_config: null, compute_rule: JSON.stringify({ op: 'nonsense', overridable: false, output_type: 'string', config: {} }) };
    conn = makeConn({
      oldRow: { id: 'f-note', blueprint_id: 'bp-1', field_type: 'number', field_key: 'note', depends_on_field_key: null },
      preRows: [legacy, { field_key: 'note', field_type: 'number', table_config: null, compute_rule: null }],
      postRows: [legacy, { field_key: 'note', field_type: 'text', table_config: null, compute_rule: null }],
    });
    const res = await put('/edge/app/schema/blueprint_fields/f-note', { field_type: 'text' });
    assert.equal(res.status, 200, JSON.stringify(res.body));
    assert.equal(conn.committed(), true);
  });

  it('does not scan the blueprint at all for a write that cannot affect the graph', async () => {
    conn = makeConn({
      oldRow: { id: 'f-total', blueprint_id: 'bp-1', field_type: 'number', field_key: 'total', depends_on_field_key: null },
      preRows: [QTY, TOTAL_NUMBER],
      postRows: [QTY, TOTAL_NUMBER],
    });
    const res = await put('/edge/app/schema/blueprint_fields/f-total', { field_label: 'Total (mm)' });
    assert.equal(res.status, 200, JSON.stringify(res.body));
    assert.equal(conn.queries.filter((q) => COMPUTE_STATE.test(q.sql)).length, 0,
      'a label edit must not pay for the post-write judgement');
  });
});
