/**
 * api-connectors-approval.test.js — the admin approval lifecycle.
 *
 * Covers the status-stamping write middleware (create + sensitive-edit re-pend +
 * client-supplied-status stripping) and the PATCH /:id/approve / /:id/reject
 * routes (admin gate, note requirement, audit, 404, no-ALTER tolerance).
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const cdKey = require.resolve('../../src/edge/lib/connector-dispatch');
const cd = require('../../src/edge/lib/connector-dispatch');
cd.executeRequest = () => Promise.resolve({ upstream_status: 200, headers: {}, body: '', truncated: false, duration_ms: 0 });
require.cache[cdKey].exports = cd;

const COLUMNS = [
  'id', 'name', 'description', 'is_active', 'owner_id', 'blueprint_id', 'method', 'url',
  'auth_type', 'auth_config', 'request_config', 'response_config', 'dispatch_origin',
  'group_id', 'group_label', 'group_mode', 'sequence', 'timeout_ms',
  'status', 'approved_by', 'approved_at', 'review_note', 'created_at', 'updated_at',
].map((c) => ({ COLUMN_NAME: c }));

const dbKey = require.resolve('../../src/edge/db');
let existingRow; let inserted; let updated; let audited; let columnsErr;
const conn = {
  async query(sql, params) {
    if (/information_schema\.COLUMNS/i.test(sql)) {
      if (columnsErr) { const e = new Error("Unknown column 'status'"); e.code = 'ER_BAD_FIELD_ERROR'; e.errno = 1054; throw e; }
      return COLUMNS;
    }
    if (/SELECT status, url, method, auth_type, dispatch_origin FROM/.test(sql)) {
      return existingRow ? [existingRow] : [];
    }
    if (/SELECT owner_id FROM `fmb_api_connectors`/.test(sql)) return existingRow ? [{ owner_id: existingRow.owner_id ?? 'admin' }] : [];
    if (/FROM `fmb_hierarchy_nodes`/.test(sql)) return [{ owner_id: '35001ba8-1475-47d7-8cc5-95adf919682b' }]; // blueprint owned by the test user → editor may bind
    if (/INSERT INTO `fmb_api_connectors`/.test(sql)) { inserted.push({ sql, params }); return { affectedRows: 1, insertId: 1 }; }
    if (/UPDATE `fmb_api_connectors`/.test(sql)) { updated.push({ sql, params }); return { affectedRows: existingRow ? 1 : 0 }; }
    if (/FROM `fmb_api_connectors` WHERE id = \?/.test(sql)) return existingRow ? [{ ...existingRow, id: params[params.length - 1] }] : [];
    if (/FROM `fmb_system_settings`/.test(sql)) return [];
    if (/INSERT INTO `fmb_feature_audit`/.test(sql)) { audited.push({ event: params[1], meta: JSON.parse(params[3]) }); return { affectedRows: 1 }; }
    if (/SELECT DATABASE\(\)/.test(sql)) return [{ db: 'testdb' }];
    return [];
  },
  // The mount resolves its `****` mask on the write connection now, so the PUT
  // runs inside a transaction. A double that answers only `query` reports the
  // missing method as a 500 and this suite's subject — the status the UPDATE
  // carries — simply never happens. No-ops here because the transaction is the
  // real-DB test's subject, not this one's.
  async beginTransaction() {},
  async commit() {},
  async rollback() {},
  release() {},
};
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: { ro: { getConnection: async () => conn, query: conn.query }, rw: { getConnection: async () => conn, query: conn.query } }, t: (n) => `fmb_${n}` },
};

const schema = require('../../src/edge/routes/app/schema');
const router = require('../../src/edge/routes/app/api-connectors');

let role; let server; let baseUrl;
before(async () => {
  const app = express(); app.use(express.json());
  app.use((req, _res, next) => { req.user = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role }; next(); });
  app.use('/c', router);
  server = http.createServer(app); await new Promise((r) => server.listen(0, r));
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});
after(() => server && server.close());
beforeEach(() => {
  inserted = []; updated = []; audited = []; existingRow = null; columnsErr = false; role = 'admin';
  schema.__clearColumnSetCache && schema.__clearColumnSetCache();
});

const req = (method, path, body) =>
  fetch(`${baseUrl}${path}`, { method, headers: { 'content-type': 'application/json' }, body: body ? JSON.stringify(body) : undefined })
    .then(async (r) => ({ status: r.status, json: await r.json().catch(() => ({})) }));

function insertedStatus() {
  const ins = inserted[0];
  if (!ins) return undefined;
  const cols = ins.sql.match(/\(([^)]*)\)\s*VALUES/i)[1].split(',').map((s) => s.trim().replace(/`/g, ''));
  const idx = cols.indexOf('status');
  return idx === -1 ? undefined : ins.params[idx];
}

describe('status stamping on create', () => {
  const body = { name: 'c', url: 'https://api.example.com/x', method: 'GET', auth_type: 'none', blueprint_id: null };

  it('editor create → pending', async () => {
    role = 'editor';
    const r = await req('POST', '/c', { ...body, blueprint_id: '94c48513-16f5-4501-8487-35b73dc27d69' });
    assert.equal(r.status, 200);
    assert.equal(insertedStatus(), 'pending');
  });

  it('admin create → approved', async () => {
    role = 'admin';
    const r = await req('POST', '/c', body);
    assert.equal(r.status, 200);
    assert.equal(insertedStatus(), 'approved');
  });

  it('a client-supplied status is stripped (editor cannot self-approve)', async () => {
    role = 'editor';
    await req('POST', '/c', { ...body, blueprint_id: '94c48513-16f5-4501-8487-35b73dc27d69', status: 'approved', approved_by: '35001ba8-1475-47d7-8cc5-95adf919682b' });
    assert.equal(insertedStatus(), 'pending');
  });
});

describe('sensitive-edit re-pend on PUT', () => {
  const base = { id: 'a3fe8617-ef98-49ca-8a07-5626f88e6d19', owner_id: '35001ba8-1475-47d7-8cc5-95adf919682b', status: 'approved', url: 'https://api.example.com/x', method: 'GET', auth_type: 'none', dispatch_origin: 'infra', request_config: JSON.stringify({ headers: {} }) };
  function updatedStatus() {
    const up = updated.find((u) => /status\s*=/.test(u.sql)) || updated[0];
    if (!up) return undefined;
    // The factory builds SET col=? pairs; find the status value among params.
    return up.sql.includes('status') ? 'pending-ish' : undefined; // see direct param assert below
  }

  it('approved + sensitive (url) change → re-pent to pending', async () => {
    existingRow = { ...base };
    await req('PUT', '/c/c1', { url: 'https://evil.example.com/x' });
    const setStatus = updated.some((u) => u.params.includes('pending'));
    assert.equal(setStatus, true, 'a sensitive change must set status=pending in the UPDATE');
  });

  it('approved + cosmetic (name) change → stays approved (no status in update)', async () => {
    existingRow = { ...base };
    await req('PUT', '/c/c1', { name: 'renamed' });
    const setPending = updated.some((u) => u.params.includes('pending'));
    assert.equal(setPending, false, 'a cosmetic change must NOT re-pend');
  });

  // item 20: the re-pend trigger is exactly the 4 connection-shape scalars.
  for (const [field, value] of [
    ['method', 'POST'],
    ['auth_type', 'bearer'],
    ['dispatch_origin', 'edge'],
  ]) {
    it(`approved + sensitive (${field}) change → re-pend to pending`, async () => {
      existingRow = { ...base };
      await req('PUT', '/c/c1', { [field]: value });
      const setPending = updated.some((u) => u.params.includes('pending'));
      assert.equal(setPending, true, `a ${field} change must re-pend`);
    });
  }

  it('approved + request_config (header/body) change → stays approved (item 20: NOT a trigger)', async () => {
    existingRow = { ...base };
    await req('PUT', '/c/c1', { request_config: { headers: { 'X-Added': '1' }, body: '{"k":"v"}' } });
    const setPending = updated.some((u) => u.params.includes('pending'));
    assert.equal(setPending, false, 'editing request headers/body must NOT re-pend an approved connector');
  });

  it('rejected + any edit → pending (resubmit)', async () => {
    existingRow = { ...base, status: 'rejected' };
    await req('PUT', '/c/c1', { name: 'renamed' });
    const setPending = updated.some((u) => u.params.includes('pending'));
    assert.equal(setPending, true);
  });

  // THIS PAIR USED TO BE ONE CASE ASSERTING THE DEFECT. A NULL status is
  // grandfathered, which the dispatch gate reads as APPROVED — so a
  // grandfathered connector DOES dispatch, and the re-pend that read the same
  // NULL as "not approved, nothing to re-pend" was the one rule reading it the
  // other way. Between the two readings, an editor could re-point a
  // grandfathered connector at a new endpoint and it went on dispatching there
  // with no review at all. The old case pinned that as correct.
  it('grandfathered (NULL status) + sensitive change → pended, because it still dispatches', async () => {
    existingRow = { ...base, status: null };
    await req('PUT', '/c/c1', { url: 'https://api.example.com/y' });
    const setPending = updated.some((u) => u.params.includes('pending'));
    assert.equal(setPending, true, 'a grandfathered connector kept dispatching to a new endpoint unreviewed');
  });

  it('grandfathered (NULL status) + cosmetic change → left alone', async () => {
    // The other half, and what keeps the fix from being "re-pend everything":
    // a grandfathered row is not pending, and renaming it must not make it so.
    existingRow = { ...base, status: null };
    await req('PUT', '/c/c1', { name: 'renamed' });
    const setPending = updated.some((u) => u.params.includes('pending'));
    assert.equal(setPending, false, 'a rename pended a connector nobody had asked to review');
  });
  void updatedStatus;
});

// Valid-UUID fixtures: the routes now reject a malformed id with a 400 before
// touching the DB, so the path ids must be canonical UUIDs.
const CID = '11111111-1111-4111-8111-111111111111';
const MISSING_ID = '22222222-2222-4222-8222-222222222222';

describe('PATCH /:id/approve', () => {
  it('editor → 403', async () => {
    role = 'editor'; existingRow = { id: CID };
    const r = await req('PATCH', `/c/${CID}/approve`);
    assert.equal(r.status, 403);
  });

  it('admin → approved + audit', async () => {
    existingRow = { id: CID };
    const r = await req('PATCH', `/c/${CID}/approve`);
    assert.equal(r.status, 200);
    assert.equal(updated.some((u) => /status='approved'/.test(u.sql)), true);
    assert.deepEqual(audited.map((a) => a.event), ['connector.approval.granted']);
  });

  it('malformed id → 400 (before any DB access)', async () => {
    existingRow = { id: CID };
    const r = await req('PATCH', '/c/not-a-uuid/approve');
    assert.equal(r.status, 400);
    assert.equal(r.json.error.code, 'BAD_REQUEST');
    assert.equal(updated.length, 0); // never reached the UPDATE
  });

  it('missing connector → 404', async () => {
    existingRow = null;
    const r = await req('PATCH', `/c/${MISSING_ID}/approve`);
    assert.equal(r.status, 404);
  });

  it('no approval columns (no-ALTER DB) → 409 APPROVAL_UNAVAILABLE', async () => {
    existingRow = { id: CID };
    // Make the UPDATE itself raise the missing-column error.
    const orig = conn.query;
    conn.query = async (sql, params) => {
      if (/UPDATE `fmb_api_connectors`/.test(sql)) { const e = new Error("Unknown column 'status'"); e.code = 'ER_BAD_FIELD_ERROR'; e.errno = 1054; throw e; }
      return orig(sql, params);
    };
    try {
      const r = await req('PATCH', `/c/${CID}/approve`);
      assert.equal(r.status, 409);
      assert.equal(r.json.error.code, 'APPROVAL_UNAVAILABLE');
    } finally { conn.query = orig; }
  });
});

describe('PATCH /:id/reject', () => {
  it('admin without a note → 400', async () => {
    existingRow = { id: CID };
    const r = await req('PATCH', `/c/${CID}/reject`, {});
    assert.equal(r.status, 400);
  });

  it('malformed id → 400 (before the note check and DB)', async () => {
    existingRow = { id: CID };
    const r = await req('PATCH', '/c/not-a-uuid/reject', { review_note: 'x' });
    assert.equal(r.status, 400);
    assert.equal(r.json.error.code, 'BAD_REQUEST');
    assert.equal(updated.length, 0);
  });

  it('admin with a note → rejected + audit', async () => {
    existingRow = { id: CID };
    const r = await req('PATCH', `/c/${CID}/reject`, { review_note: 'host not allowed' });
    assert.equal(r.status, 200);
    assert.equal(updated.some((u) => /status='rejected'/.test(u.sql) && u.params.includes('host not allowed')), true);
    assert.deepEqual(audited.map((a) => a.event), ['connector.approval.rejected']);
  });

  it('editor → 403', async () => {
    role = 'editor'; existingRow = { id: CID };
    const r = await req('PATCH', `/c/${CID}/reject`, { review_note: 'x' });
    assert.equal(r.status, 403);
  });
});
