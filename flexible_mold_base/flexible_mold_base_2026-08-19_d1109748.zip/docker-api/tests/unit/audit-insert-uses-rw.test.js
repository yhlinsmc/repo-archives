/**
 * audit-insert-uses-rw.test.js
 *
 * v3.2.40 PR-1 — pin the write routing decision.
 *
 * `POST /edge/platform/audit/audit-log` does a single INSERT into login_audit.
 * v3.2.40 makes the pool.rw choice explicit. A future refactor that drops
 * back to `pool.getConnection()` (which still exists as a deprecated shim
 * until PR-5) would silently work but skip the RW/RO intent — this test
 * asserts the explicit facade.
 *
 * The test throws on pool.ro.getConnection so any regression fails loud,
 * which is the correct failure mode: an INSERT on a read-only replica
 * would raise in production (ER_READ_ONLY_TRANSACTION) rather than silently
 * succeed.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../src/edge/db');
const routeKey = require.resolve('../../src/edge/routes/platform/audit');

let calls;

function makeSpy() {
  calls = { rw: 0, ro: 0, rwQueries: [] };
  return {
    rw: {
      async getConnection() {
        calls.rw++;
        return {
          async query(sql, params) {
            calls.rwQueries.push({ sql, params });
            return { affectedRows: 1 };
          },
          release() { /* noop */ },
        };
      },
    },
    ro: {
      async getConnection() {
        calls.ro++;
        throw new Error('wrong facade: audit-log INSERT must use pool.rw, not pool.ro');
      },
    },
  };
}

const poolSpy = {};

require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: {
    pool: poolSpy,
    t: (name) => `fmb_${name}`,
  },
};

const router = require('../../src/edge/routes/platform/audit');

let server;
let port;

before(async () => {
  Object.assign(poolSpy, makeSpy());
  const app = express();
  app.use(express.json());
  // audit route requires req.user (populated by s2s middleware in prod)
  app.use((req, _res, next) => { req.user = { id: 'test', role: 'user' }; next(); });
  app.use('/edge/platform/audit', router);
  await new Promise((resolve) => {
    server = app.listen(0, '127.0.0.1', () => {
      port = server.address().port;
      resolve();
    });
  });
});

after(async () => {
  await new Promise((resolve) => server.close(resolve));
  delete require.cache[dbKey];
  delete require.cache[routeKey];
});

beforeEach(() => {
  Object.assign(poolSpy, makeSpy());
});

function postJson(port_, path_, body) {
  return new Promise((resolve, reject) => {
    const payload = JSON.stringify(body);
    const req = http.request(
      {
        host: '127.0.0.1', port: port_, path: path_, method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) },
      },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          const raw = Buffer.concat(chunks).toString('utf-8');
          let json = null;
          try { json = JSON.parse(raw); } catch { /* noop */ }
          resolve({ status: res.statusCode, raw, json });
        });
      },
    );
    req.on('error', reject);
    req.write(payload);
    req.end();
  });
}

describe('POST /edge/platform/audit/audit-log — v3.2.40 pool.rw pin', () => {
  it('INSERT login_audit hits pool.rw (not pool.ro)', async () => {
    const res = await postJson(port, '/edge/platform/audit/audit-log', {
      username: 'alice@test',
      success: true,
      reason: 'login',
      ip_address: '10.0.0.1',
      user_agent: 'test-agent',
    });

    assert.equal(res.status, 200);
    assert.equal(calls.ro, 0, 'pool.ro.getConnection MUST NOT be called (would throw)');
    assert.equal(calls.rw, 1, 'pool.rw.getConnection should be called exactly once');
    assert.match(calls.rwQueries[0].sql, /INSERT INTO `fmb_login_audit`/);
    assert.equal(calls.rwQueries[0].params[0], 'alice@test');
  });
});
