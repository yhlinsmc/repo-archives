/**
 * blueprint-overwrite-ownership.test.js — security C1.
 *
 * overwriteBlueprint runs a destructive cascade (DELETE + re-INSERT of every
 * child row). It must be owner-gated exactly like the schema write routes: an
 * editor may overwrite only a blueprint they own or one that is shared
 * (owner_id NULL); a non-owner editor is rejected FORBIDDEN before any write;
 * admin bypasses the check.
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');

const lib = require('../../src/edge/lib/blueprint-serialization');

const FAKE_TABLES = {
  HIERARCHY_NODES: 'hierarchy_nodes',
  BLUEPRINT_FIELDS: 'blueprint_fields',
  FIELD_OPTIONS: 'field_options',
  BLUEPRINT_SECTIONS: 'blueprint_sections',
  BLUEPRINT_OUTPUT_ORDER: 'blueprint_output_order',
  BLUEPRINT_GROUPS: 'blueprint_groups',
  VARIANT_OVERRIDES: 'variant_overrides',
  FEATURE_AUDIT: 'feature_audit',
};
const fakeT = (name) => `fmb_${name}`;
let counter = 0;
const fakeUuid = () => `fake-uuid-${counter++}`;

function rawFixture(ownerId) {
  return {
    import_version: 1,
    hierarchy_node: {
      id: 'bp-1', parent_id: 'release-1', name: 'BP', description: '',
      node_type: 'blueprint', sort_order: 0, is_active: 1,
      transformer_id: null, transformer_version: null, linked_blueprint_id: null,
      owner_id: ownerId ?? null,
    },
    blueprint_fields: [],
    field_options: [],
    blueprint_sections: [],
    blueprint_groups: [],
    blueprint_output_order: [],
  };
}

function makeFakeConn(current) {
  const queries = [];
  return {
    queries,
    async query(sql, params) {
      queries.push({ sql, params });
      if (/information_schema\.TABLES/i.test(sql)) return []; // additive tables absent
      if (/^SELECT \* FROM .*hierarchy_nodes/i.test(sql)) return [current.hierarchy_node];
      if (/^SELECT \* FROM .*blueprint_fields/i.test(sql)) return current.blueprint_fields;
      if (/^SELECT \* FROM .*field_options/i.test(sql)) return current.field_options;
      if (/^SELECT \* FROM .*blueprint_sections/i.test(sql)) return current.blueprint_sections;
      if (/^SELECT \* FROM .*blueprint_output_order/i.test(sql)) return current.blueprint_output_order;
      if (/^SELECT id, field_key FROM .*blueprint_fields/i.test(sql)) return [];
      if (/^SELECT id FROM .*blueprint_fields/i.test(sql)) return [];
      return [];
    },
  };
}

function run(current, { userRole, userId }) {
  return lib.overwriteBlueprint({
    conn: makeFakeConn(current), t: fakeT, TABLES: FAKE_TABLES, uuidv4: fakeUuid,
    existingId: 'bp-1', payload: rawFixture(null), userId, userRole,
    expectedRevision: lib.computeRevision(current),
  });
}

// Same as run() but exposes the conn so the test can assert no destructive
// write was issued on the rejection path.
function runCapturing(current, opts) {
  const conn = makeFakeConn(current);
  const p = lib.overwriteBlueprint({
    conn, t: fakeT, TABLES: FAKE_TABLES, uuidv4: fakeUuid,
    existingId: 'bp-1', payload: rawFixture(null), userId: opts.userId, userRole: opts.userRole,
    expectedRevision: lib.computeRevision(current),
  });
  return { conn, p };
}

describe('overwriteBlueprint ownership gate (security C1)', () => {
  it('rejects a non-owner editor with FORBIDDEN before any destructive write', async () => {
    const current = rawFixture('owner-9');
    const { conn, p } = runCapturing(current, { userRole: 'editor', userId: 'editor-1' });
    await assert.rejects(p, (e) => e.code === 'FORBIDDEN');
    assert.ok(!conn.queries.some((q) => /^DELETE FROM/i.test(q.sql)), 'no DELETE was issued');
    assert.ok(!conn.queries.some((q) => /overwrite\.attempt/.test(JSON.stringify(q.params || []))), 'no attempt-audit was written');
  });

  it('allows an editor to overwrite a blueprint they own', async () => {
    const current = rawFixture('editor-1');
    const result = await run(current, { userRole: 'editor', userId: 'editor-1' });
    assert.equal(result.ok, true);
  });

  it('allows an editor to overwrite a SHARED blueprint (owner_id NULL)', async () => {
    const current = rawFixture(null);
    const result = await run(current, { userRole: 'editor', userId: 'editor-2' });
    assert.equal(result.ok, true);
  });

  it('admin bypasses the owner check (overwrites a blueprint owned by someone else)', async () => {
    const current = rawFixture('owner-9');
    const result = await run(current, { userRole: 'admin', userId: 'admin-1' });
    assert.equal(result.ok, true);
  });
});
