/**
 * claim-release-classifier.test.js — isClaimReleaseRequest routing predicate.
 *
 * The pure classifier decides whether a request gets the dedicated
 * claim/release rate-limit bucket. Only a POST to a path ending /claim or
 * /release qualifies; everything else (other methods, other paths) must fall
 * through so it is not double-counted against the claim/release budget.
 */
const { test } = require('node:test');
const assert = require('node:assert/strict');

const { isClaimReleaseRequest } = require('../../src/infra/limiters');

test('POST .../claim and .../release (with or without trailing slash) → true', () => {
  assert.equal(isClaimReleaseRequest('POST', '/abc/claim'), true);
  assert.equal(isClaimReleaseRequest('POST', '/abc/release'), true);
  assert.equal(isClaimReleaseRequest('POST', '/abc/claim/'), true);
  assert.equal(isClaimReleaseRequest('POST', '/abc/release/'), true);
});

test('non-POST methods on a claim/release path → false', () => {
  for (const m of ['GET', 'PUT', 'DELETE', 'PATCH', 'OPTIONS']) {
    assert.equal(isClaimReleaseRequest(m, '/abc/claim'), false, `${m} must not match`);
    assert.equal(isClaimReleaseRequest(m, '/abc/release'), false, `${m} must not match`);
  }
});

test('POST to a non-claim/release path → false', () => {
  assert.equal(isClaimReleaseRequest('POST', '/abc'), false);
  assert.equal(isClaimReleaseRequest('POST', '/abc/claimed'), false); // substring, not segment
  assert.equal(isClaimReleaseRequest('POST', '/claim/abc'), false); // claim not at the end
  assert.equal(isClaimReleaseRequest('POST', '/abc/release/extra'), false);
});
