/**
 * app-setup-cors-guard.test.js — v3.2.28
 *
 * Verifies the DEV_LOCALHOST_CORS_ONLY_DO_NOT_SET_IN_PROD env-var contract
 * added in v3.2.28 to support k3d local simulation:
 *
 *   - Module-load throw when flag === 'true' AND NODE_ENV === 'production'.
 *   - Dev + flag set → CORS allows http://localhost:8130 / 8230 (and ONLY those).
 *   - Prod + flag unset → same-origin only (no Access-Control-Allow-Origin).
 *   - CORS_ORIGINS set → wins regardless of dev flag.
 *
 * The test boots the express app in-process (no listen) and inspects the
 * Access-Control-Allow-Origin header on a fake preflight to prove behaviour.
 */
const { describe, it, beforeEach, afterEach } = require('node:test');
const assert = require('node:assert/strict');

const APP_SETUP_PATH = require.resolve('../../src/infra/app-setup');

const DEV_FLAG = 'DEV_LOCALHOST_CORS_ONLY_DO_NOT_SET_IN_PROD';
const ENV_KEYS = [DEV_FLAG, 'NODE_ENV', 'CORS_ORIGINS', 'FRONTEND_URL'];

const originalEnv = {};
function snapshotEnv() {
  for (const k of ENV_KEYS) originalEnv[k] = process.env[k];
}
function restoreEnv() {
  for (const k of ENV_KEYS) {
    if (originalEnv[k] === undefined) delete process.env[k];
    else process.env[k] = originalEnv[k];
  }
}
function clearEnv() {
  for (const k of ENV_KEYS) delete process.env[k];
}

function freshRequire() {
  delete require.cache[APP_SETUP_PATH];
  return require(APP_SETUP_PATH);
}

/**
 * Send a CORS preflight (OPTIONS with Origin header) into the app and resolve
 * with the response headers. Uses node http roundtrip on an ephemeral port so
 * we exercise the real cors() middleware behaviour, not a mock.
 */
async function preflight(app, origin) {
  const http = require('node:http');
  return await new Promise((resolve, reject) => {
    const server = app.listen(0, '127.0.0.1', () => {
      const { port } = server.address();
      const req = http.request(
        {
          host: '127.0.0.1',
          port,
          method: 'OPTIONS',
          path: '/api/anything',
          headers: {
            Origin: origin,
            'Access-Control-Request-Method': 'GET',
          },
        },
        (res) => {
          res.resume();
          res.on('end', () => {
            server.close();
            resolve(res.headers);
          });
        },
      );
      req.on('error', (err) => {
        server.close();
        reject(err);
      });
      req.end();
    });
  });
}

/**
 * Send an ACTUAL request (GET with Origin) so the cors() middleware emits
 * Access-Control-Expose-Headers (preflight/OPTIONS does not carry it).
 */
async function actualGet(app, origin) {
  const http = require('node:http');
  return await new Promise((resolve, reject) => {
    const server = app.listen(0, '127.0.0.1', () => {
      const { port } = server.address();
      const req = http.request(
        {
          host: '127.0.0.1',
          port,
          method: 'GET',
          path: '/api/anything',
          headers: { Origin: origin },
        },
        (res) => {
          res.resume();
          res.on('end', () => {
            server.close();
            resolve(res.headers);
          });
        },
      );
      req.on('error', (err) => {
        server.close();
        reject(err);
      });
      req.end();
    });
  });
}

snapshotEnv();

describe('CORS expose-headers — Content-Disposition readable cross-origin', () => {
  beforeEach(() => clearEnv());
  afterEach(() => restoreEnv());

  it('exposes Content-Disposition (and X-Request-Id) so export filenames survive cross-origin fetch', async () => {
    process.env[DEV_FLAG] = 'true';
    process.env.NODE_ENV = 'development';
    const { createApp } = freshRequire();
    const app = createApp();

    const h = await actualGet(app, 'http://localhost:8130');
    const expose = (h['access-control-expose-headers'] || '').toLowerCase();
    assert.ok(expose.includes('content-disposition'), `expected Content-Disposition in expose list, got: ${h['access-control-expose-headers']}`);
    assert.ok(expose.includes('x-wipe-token'), `expected X-Wipe-Token in expose list, got: ${h['access-control-expose-headers']}`);
    assert.ok(expose.includes('x-request-id'), 'X-Request-Id stays exposed');
  });
});

describe('CORS guard — DEV_LOCALHOST_CORS_ONLY_DO_NOT_SET_IN_PROD', () => {
  beforeEach(() => {
    clearEnv();
  });
  // Always restore from snapshot so a thrown assertion in any test body cannot
  // leave the env dirty for subsequent tests.
  afterEach(() => {
    restoreEnv();
  });

  it('1. flag=true + NODE_ENV=production → module load THROWS', () => {
    process.env[DEV_FLAG] = 'true';
    process.env.NODE_ENV = 'production';
    delete require.cache[APP_SETUP_PATH];
    assert.throws(() => require(APP_SETUP_PATH), /must not be 'true' in production/);
  });

  it('2. flag=true + NODE_ENV=development → boots, CORS allows localhost:8130 & 8230', async () => {
    process.env[DEV_FLAG] = 'true';
    process.env.NODE_ENV = 'development';
    const { createApp } = freshRequire();
    const app = createApp();

    const h1 = await preflight(app, 'http://localhost:8130');
    assert.equal(h1['access-control-allow-origin'], 'http://localhost:8130');

    const h2 = await preflight(app, 'http://localhost:8230');
    assert.equal(h2['access-control-allow-origin'], 'http://localhost:8230');

    // Negative: a non-allowlisted origin should NOT receive ACAO mirror.
    const h3 = await preflight(app, 'http://evil.example.com');
    assert.notEqual(h3['access-control-allow-origin'], 'http://evil.example.com');

  });

  it('3. flag UNSET + NODE_ENV=production → same-origin only (no ACAO header)', async () => {
    process.env.NODE_ENV = 'production';
    const { createApp } = freshRequire();
    const app = createApp();

    const h = await preflight(app, 'http://localhost:8130');
    assert.equal(h['access-control-allow-origin'], undefined);

  });

  it('4. CORS_ORIGINS + dev flag → both origins are allowed (dev flag is additive)', async () => {
    // v3.2.28 review fold: dev flag must NOT be subordinate to CORS_ORIGINS /
    // FRONTEND_URL because zone-test/zone-a configmaps already set
    // FRONTEND_URL — a fallback-style flag would silently no-op there. The
    // flag is additive: explicit env wins for its own value, dev flag
    // appends localhost:8130 / 8230 on top.
    process.env[DEV_FLAG] = 'true';
    process.env.NODE_ENV = 'development';
    process.env.CORS_ORIGINS = 'https://approved.example.com';
    const { createApp } = freshRequire();
    const app = createApp();

    const h1 = await preflight(app, 'https://approved.example.com');
    assert.equal(h1['access-control-allow-origin'], 'https://approved.example.com');

    const h2 = await preflight(app, 'http://localhost:8130');
    assert.equal(h2['access-control-allow-origin'], 'http://localhost:8130');

    const h3 = await preflight(app, 'http://evil.example.com');
    assert.notEqual(h3['access-control-allow-origin'], 'http://evil.example.com');

  });

  it('5. FRONTEND_URL + dev flag → both origins are allowed (real k3d shape)', async () => {
    // The actual k3d configmap-infra ships FRONTEND_URL=https://zoneN-fmb-web.localhost.
    // This test pins the real-cluster combination so the bug surfaced during
    // v3.2.28 code review (FRONTEND_URL silently bypassing the dev flag) cannot
    // regress.
    process.env[DEV_FLAG] = 'true';
    process.env.NODE_ENV = 'development';
    process.env.FRONTEND_URL = 'https://zonetest-fmb-web.localhost';
    const { createApp } = freshRequire();
    const app = createApp();

    const h1 = await preflight(app, 'https://zonetest-fmb-web.localhost');
    assert.equal(h1['access-control-allow-origin'], 'https://zonetest-fmb-web.localhost');

    const h2 = await preflight(app, 'http://localhost:8130');
    assert.equal(h2['access-control-allow-origin'], 'http://localhost:8130');

  });
});
