/**
 * dto-mapper-schema-parity.test.js — every column the API boundary claims to
 * map must actually exist in table-ddls.js, WITHOUT a live DB.
 *
 * The mapper's registry is the only place that says "this column is JSON /
 * boolean / a timestamp / a coalesced nullable". A name that drifts from the
 * DDL is invisible to every mocked test: the read simply never parses the
 * column, the write simply never stringifies it, and the value reaching the
 * client is a raw string that the frontend then reads as an empty document.
 * Nothing throws. This is the same class of gap the capacity delete-preview
 * parity test closes for hand-written SQL, applied to the mapping registry.
 */
const { describe, it, before } = require('node:test');
const assert = require('node:assert/strict');

const { buildSchemaManifest } = require('../../src/edge/lib/schema-manifest');
const { getRegistry } = require('../../src/edge/lib/dto-mapper');
// The sparse per-field metadata channels the data-entry page writes alongside
// the flat payload. Each is a document the frontend builds and restores, so
// each must be JSON-mapped at the boundary AND exist as a column — a channel
// that is only one of the two is silently dropped or silently unparsed. Read
// from the shared declaration rather than relisted: a list kept here would go on
// passing for a fourth column that no path actually carries.
const {
  USER_TEMPLATE_METADATA_COLUMN_NAMES: USER_TEMPLATE_METADATA_COLUMNS,
} = require('../../src/edge/lib/user-template-metadata');

let manifest;

before(() => {
  manifest = buildSchemaManifest((base) => base);
});

function columnsOf(table) {
  const entry = manifest.get(table);
  assert.ok(entry, `dto-mapper registers table '${table}', which table-ddls.js does not create`);
  return new Set(entry.columns);
}

describe('dto-mapper registry <-> table-ddls parity', () => {
  it('every mapped column of every registered table exists in the DDL', () => {
    const gaps = [];
    for (const [table, def] of Object.entries(getRegistry())) {
      const columns = columnsOf(table);
      const mapped = [
        ...(def.booleans || []),
        ...(def.timestamps || []),
        ...(def.json || []),
        ...(def.nullableStrings || []),
        ...Object.keys(def.nullableNumbers || {}),
      ];
      for (const column of mapped) {
        if (!columns.has(column)) gaps.push(`${table}.${column}`);
      }
    }
    assert.deepEqual(gaps, [], `mapped columns absent from table-ddls.js: ${gaps.join(', ')}`);
  });

  it('every user_templates metadata channel is a real column and is JSON-mapped', () => {
    const columns = columnsOf('user_templates');
    const mappedJson = new Set(getRegistry().user_templates.json || []);
    for (const column of USER_TEMPLATE_METADATA_COLUMNS) {
      assert.ok(columns.has(column), `user_templates has no column '${column}'`);
      assert.ok(mappedJson.has(column), `user_templates.${column} is not JSON-mapped at the boundary`);
    }
  });
});
