/**
 * capacity-config-import-degraded.test.js — codex r2 R2-1. A warn-skipped
 * name_patterns migration leaves cap_settings.name_patterns ABSENT, but an export
 * from an UPGRADED instance still carries a name_patterns value that
 * buildConfigImportPlan lands in dbRow. Naming an absent column in the INSERT would
 * 500 and roll back the WHOLE import, so writeConfigPlan applies the same
 * dropAbsentColumns filter the direct write paths use, on the same writer
 * connection the INSERT runs on.
 *
 * Stubs the edge db with an identity table-name resolver so writeConfigPlan's
 * `t(spec.table)` needs no configured pool.
 */
const { describe, it, beforeEach } = require('node:test');
const assert = require('node:assert/strict');

const dbKey = require.resolve('../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: {}, t: (n) => n },
};

const { writeConfigPlan } = require('../../src/edge/routes/app/capacity/config-import');
const { _resetColumnSetCache } = require('../../src/edge/routes/app/capacity/_shared');

// A fake writer connection: answers the degraded-mode column probe from a
// configurable physical column set and records the columns each INSERT names.
function makeConn(physicalColumns) {
  const insertedCols = [];
  return {
    insertedCols,
    query: async (sql) => {
      if (/information_schema/i.test(sql)) return physicalColumns.map((name) => ({ name }));
      if (/^\s*INSERT INTO/i.test(sql)) {
        const m = /\(([^)]*)\)\s*VALUES/i.exec(sql);
        if (m) insertedCols.push(m[1].split(',').map((c) => c.replace(/[`\s]/g, '')));
      }
      return {};
    },
  };
}

const NAME_PATTERNS_JSON = '{"hypervisor":"hv-{seq:2}","kvm_host":"kvm-{seq:2}","ap_vm":"ap-{seq:2}"}';
const plan = { settings: [{ id: 'set-1', dbRow: { mem_cpu_ratio: 20, name_patterns: NAME_PATTERNS_JSON } }] };

describe('writeConfigPlan — degraded-mode column filter (codex r2 R2-1)', () => {
  beforeEach(() => _resetColumnSetCache());

  it('drops name_patterns from the INSERT when the physical column is absent, and still writes the rest', async () => {
    const conn = makeConn(['id', 'scenario_id', 'mem_cpu_ratio']);
    const inserted = await writeConfigPlan(conn, plan);
    assert.equal(inserted.settings, 1);
    const cols = conn.insertedCols[0];
    assert.equal(cols.includes('name_patterns'), false, JSON.stringify(cols));
    assert.equal(cols.includes('mem_cpu_ratio'), true);
    assert.equal(cols.includes('id'), true);
    assert.equal(cols.includes('scenario_id'), true);
  });

  it('retains name_patterns when the physical column exists (migrated DB)', async () => {
    const conn = makeConn(['id', 'scenario_id', 'mem_cpu_ratio', 'name_patterns']);
    await writeConfigPlan(conn, plan);
    const cols = conn.insertedCols[0];
    assert.equal(cols.includes('name_patterns'), true, JSON.stringify(cols));
    assert.equal(cols.includes('mem_cpu_ratio'), true);
  });
});
