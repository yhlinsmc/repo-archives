/**
 * configure-pool-retry.test.js — v3.2.114 Phase 2.
 *
 * Pins the retry policy for configurePool's initial connection probe:
 *  - Transient err.code (allowlisted) → retry up to N times with backoff.
 *  - Non-transient err.code → fail-fast (no retry, no sleep).
 *  - Eventual success on attempt 2/3 → returns without throw.
 *
 * Allowlist is hard-coded in db.js _TRANSIENT_CONNECT_CODES. Test asserts
 * the contract by reaching into the exported _connectWithRetry helper.
 */
const { test } = require('node:test');
const assert = require('node:assert/strict');
const { _connectWithRetry } = require('../../src/edge/db');

function fakePool(scriptedErrors) {
  // scriptedErrors is an array; each invocation pops one. If the popped
  // entry is null, getConnection succeeds. If it's an Error, throw it.
  let i = 0;
  const calls = [];
  return {
    calls,
    async getConnection() {
      calls.push(i);
      const entry = scriptedErrors[i++];
      if (entry === null || entry === undefined) {
        return { release() {} };
      }
      throw entry;
    },
  };
}

test('succeeds on first try when getConnection works', async () => {
  const pool = fakePool([null]);
  await _connectWithRetry(pool, { maxAttempts: 3, baseDelayMs: 1 });
  assert.equal(pool.calls.length, 1);
});

test('retries on ECONNREFUSED and succeeds on second try', async () => {
  const pool = fakePool([
    Object.assign(new Error('refused'), { code: 'ECONNREFUSED' }),
    null,
  ]);
  await _connectWithRetry(pool, { maxAttempts: 3, baseDelayMs: 1 });
  assert.equal(pool.calls.length, 2);
});

test('retries on ETIMEDOUT and succeeds on third try', async () => {
  const pool = fakePool([
    Object.assign(new Error('to'), { code: 'ETIMEDOUT' }),
    Object.assign(new Error('to'), { code: 'ETIMEDOUT' }),
    null,
  ]);
  await _connectWithRetry(pool, { maxAttempts: 3, baseDelayMs: 1 });
  assert.equal(pool.calls.length, 3);
});

test('retries on EAI_AGAIN (DNS warming up)', async () => {
  const pool = fakePool([
    Object.assign(new Error('dns'), { code: 'EAI_AGAIN' }),
    null,
  ]);
  await _connectWithRetry(pool, { maxAttempts: 3, baseDelayMs: 1 });
  assert.equal(pool.calls.length, 2);
});

test('retries on ENOTFOUND (DNS not yet propagated)', async () => {
  const pool = fakePool([
    Object.assign(new Error('dns'), { code: 'ENOTFOUND' }),
    null,
  ]);
  await _connectWithRetry(pool, { maxAttempts: 3, baseDelayMs: 1 });
  assert.equal(pool.calls.length, 2);
});

test('fails fast on ER_ACCESS_DENIED_ERROR (no retry)', async () => {
  const err = Object.assign(new Error('denied'), { code: 'ER_ACCESS_DENIED_ERROR' });
  const pool = fakePool([err, null, null]);
  await assert.rejects(
    () => _connectWithRetry(pool, { maxAttempts: 3, baseDelayMs: 1 }),
    { code: 'ER_ACCESS_DENIED_ERROR' },
  );
  assert.equal(pool.calls.length, 1, 'must not retry on credential errors');
});

test('fails fast on ER_DBACCESS_DENIED_ERROR (no retry)', async () => {
  const err = Object.assign(new Error('db denied'), { code: 'ER_DBACCESS_DENIED_ERROR' });
  const pool = fakePool([err]);
  await assert.rejects(
    () => _connectWithRetry(pool, { maxAttempts: 3, baseDelayMs: 1 }),
    { code: 'ER_DBACCESS_DENIED_ERROR' },
  );
  assert.equal(pool.calls.length, 1);
});

test('fails fast on unknown / unrecognised codes (no retry)', async () => {
  const err = Object.assign(new Error('weird'), { code: 'ER_SOMETHING_UNKNOWN' });
  const pool = fakePool([err]);
  await assert.rejects(
    () => _connectWithRetry(pool, { maxAttempts: 3, baseDelayMs: 1 }),
    { code: 'ER_SOMETHING_UNKNOWN' },
  );
  assert.equal(pool.calls.length, 1);
});

test('exhausts retry budget and throws the last error', async () => {
  const err1 = Object.assign(new Error('a'), { code: 'ECONNREFUSED' });
  const err2 = Object.assign(new Error('b'), { code: 'ECONNREFUSED' });
  const err3 = Object.assign(new Error('c'), { code: 'ECONNREFUSED' });
  const pool = fakePool([err1, err2, err3]);
  await assert.rejects(
    () => _connectWithRetry(pool, { maxAttempts: 3, baseDelayMs: 1 }),
    (e) => e.code === 'ECONNREFUSED',
  );
  assert.equal(pool.calls.length, 3);
});

test('honours maxAttempts override', async () => {
  const pool = fakePool([
    Object.assign(new Error(), { code: 'ECONNREFUSED' }),
    Object.assign(new Error(), { code: 'ECONNREFUSED' }),
    Object.assign(new Error(), { code: 'ECONNREFUSED' }),
    Object.assign(new Error(), { code: 'ECONNREFUSED' }),
    Object.assign(new Error(), { code: 'ECONNREFUSED' }),
  ]);
  await assert.rejects(
    () => _connectWithRetry(pool, { maxAttempts: 5, baseDelayMs: 1 }),
  );
  assert.equal(pool.calls.length, 5);
});

test('substring-of-message NEVER triggers retry (allowlist is by err.code only)', async () => {
  // Defence: a future driver release that puts "ECONNREFUSED" in message
  // but with a different err.code must NOT cause unwanted retries.
  const err = Object.assign(
    new Error('ECONNREFUSED appearing in message text'),
    { code: 'ER_BAD_DB_ERROR' },
  );
  const pool = fakePool([err]);
  await assert.rejects(
    () => _connectWithRetry(pool, { maxAttempts: 3, baseDelayMs: 1 }),
    { code: 'ER_BAD_DB_ERROR' },
  );
  assert.equal(pool.calls.length, 1, 'message substring must not trigger retry');
});
