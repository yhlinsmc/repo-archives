/**
 * Two pre-existing backend behaviours that new client code now DEPENDS on, pinned
 * here so a change to either surfaces as a failure next to the thing it breaks.
 *
 * Nothing here asserts new dispatch behaviour, and that is deliberate: the two
 * connector value sources are resolved client-side into the flat inputs map the
 * dispatch API already takes, so `resolveRequest` is unchanged. The backend work
 * that DID land alongside them is the batch read, which has its own route and
 * schema-parity coverage in
 * tests/edge/routes/app/variant-overrides-by-variants.test.js.
 *
 * 1. `stripEmailDomain` is the only thing standing between an email-shaped
 *    account name and a third-party host. The owner value a connector may
 *    reference is a display name that has already been through it, and nothing
 *    downstream repeats the check.
 * 2. `resolveRequest` treats a present empty string as SUPPLIED. That is why the
 *    client omits an unsupplied ask-at-fetch variable rather than sending ''. If
 *    this ever changed, the omission strategy would need revisiting — so the
 *    contract is asserted, not assumed.
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const { resolveRequest } = require('../../src/edge/lib/connector-dispatch');
const { stripEmailDomain } = require('../../src/edge/lib/owner-name-enrichment');

const connector = {
  method: 'GET',
  url: 'http://svc/v1/ticket/{{ticket}}?owner={{owner}}',
  request_config: { headers: {}, body: '' },
  auth_type: 'none',
  auth_config: {},
};

describe('the owner value a connector can send', () => {
  it('is reduced to its local part when the source value is email-shaped', () => {
    assert.equal(stripEmailDomain('alex@corp.example'), 'alex');
  });

  it('passes a non-email value through unchanged', () => {
    assert.equal(stripEmailDomain('testadmin'), 'testadmin');
  });

  it('so a full address can never reach an outbound request through this path', () => {
    const ownerName = stripEmailDomain('alex@corp.example');
    const r = resolveRequest({ ...connector }, { ticket: 'INC-1', owner: ownerName });
    assert.ok(!r.url.includes('@'));
    assert.ok(!r.url.includes('corp.example'));
  });
});

describe('the boundary contract the client omission strategy rests on', () => {
  it('a present-but-empty value is treated as supplied, not as missing', () => {
    // Hence: a skipped ask-at-fetch variable has to be ABSENT from the map, not
    // blank in it, or the MISSING_INPUT rejection never fires.
    const r = resolveRequest({ ...connector }, { ticket: '', owner: 'alex' });
    assert.equal(r.url, 'http://svc/v1/ticket/?owner=alex');
  });
});
