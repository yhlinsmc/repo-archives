/**
 * auth-password-login-uses-rw.test.js
 *
 * v3.2.40 PR-2 pin — POST /edge/platform/auth-password/login does SELECT
 * users + conditional login_audit INSERTs on the SAME conn (r→w pattern
 * flagged by Phase 0 pre-scan). Must stay on pool.rw; routing to pool.ro
 * would silently fail the audit writes on a read-only replica.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

process.env.JWT_SECRET = process.env.JWT_SECRET || 'a'.repeat(48);

const bcrypt = require('bcryptjs');

const dbKey = require.resolve('../../src/edge/db');
const routeKey = require.resolve('../../src/edge/routes/platform/auth-password');

let calls;
// When set, the users SELECT returns this row (successful-login path); default
// null keeps the existing user_not_found behaviour.
let loginUserRow = null;

function makeSpy() {
  calls = { rw: 0, ro: 0, rwQueries: [] };
  return {
    rw: {
      async getConnection() {
        calls.rw++;
        return {
          async query(sql, params) {
            calls.rwQueries.push({ sql, params });
            if (/FROM `fmb_users`/.test(sql)) return loginUserRow ? [loginUserRow] : []; // else user_not_found branch triggers audit INSERT
            return { affectedRows: 1 };
          },
          release() { /* noop */ },
        };
      },
    },
    ro: {
      async getConnection() {
        calls.ro++;
        throw new Error('wrong facade: /login does SELECT + audit INSERT on same conn → must be pool.rw');
      },
    },
  };
}

const poolSpy = {};

require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: {
    pool: poolSpy,
    t: (name) => `fmb_${name}`,
    isPoolReady: () => false, // skip resolveAuthModeAsync path → env-only resolveAuthMode
  },
};

const router = require('../../src/edge/routes/platform/auth-password');

let server;
let port;

before(async () => {
  Object.assign(poolSpy, makeSpy());
  const app = express();
  app.use(express.json());
  app.use('/edge/platform/auth-password', router);
  await new Promise((resolve) => {
    server = app.listen(0, '127.0.0.1', () => {
      port = server.address().port;
      resolve();
    });
  });
});

after(async () => {
  await new Promise((resolve) => server.close(resolve));
  delete require.cache[dbKey];
  delete require.cache[routeKey];
});

beforeEach(() => {
  Object.assign(poolSpy, makeSpy());
  loginUserRow = null;
});

function postJson(port_, path_, body) {
  return new Promise((resolve, reject) => {
    const payload = JSON.stringify(body);
    const req = http.request(
      {
        host: '127.0.0.1', port: port_, path: path_, method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) },
      },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          const raw = Buffer.concat(chunks).toString('utf-8');
          let json = null;
          try { json = JSON.parse(raw); } catch { /* noop */ }
          resolve({ status: res.statusCode, raw, json });
        });
      },
    );
    req.on('error', reject);
    req.write(payload);
    req.end();
  });
}

describe('POST /edge/platform/auth-password/login — v3.2.40 pool.rw pin', () => {
  it('SELECT + fire-and-forget audit INSERT both on pool.rw', async () => {
    const res = await postJson(port, '/edge/platform/auth-password/login', {
      email: 'ghost@test', password: 'wrong',
    });

    // Empty SELECT → user_not_found branch → 401 + fire-and-forget audit INSERT.
    assert.equal(res.status, 401);
    assert.equal(calls.ro, 0, 'pool.ro MUST NOT be called (would throw)');
    assert.equal(calls.rw, 1, 'single rw conn serves both the SELECT and audit INSERT');
    // First query is the SELECT; the fire-and-forget INSERT may land before
    // or after the response — wait a tick then assert the audit ran too.
    await new Promise((r) => setImmediate(r));
    assert.ok(calls.rwQueries.some((q) => /FROM `fmb_users`/.test(q.sql)));
    assert.ok(calls.rwQueries.some((q) => /INSERT INTO `fmb_login_audit`/.test(q.sql)));
  });

  it('successful local login issues NO KC profile re-sync UPDATE (re-sync is OIDC-only)', async () => {
    loginUserRow = {
      id: 'local-1', email: 'local@test', role: 'user', banned: 0,
      password_hash: bcrypt.hashSync('secret', 4),
      deptid: 'eng', kc_username: null, display_name: 'Local User', keycloak_sub: null,
    };
    const res = await postJson(port, '/edge/platform/auth-password/login', {
      email: 'local@test', password: 'secret',
    });

    assert.equal(res.status, 200);
    assert.equal(res.json.data.user.id, 'local-1');
    await new Promise((r) => setImmediate(r));
    // Local login never re-syncs profile columns — only SELECT + audit INSERT.
    assert.ok(!calls.rwQueries.some((q) => /^\s*UPDATE `fmb_users`/.test(q.sql)),
      'local login must not UPDATE the users row');
  });
});
