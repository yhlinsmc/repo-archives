/**
 * api-connector-serializer.test.js
 *
 * Pins the field-level secret handling for api_connectors: encrypt-on-write,
 * mask-on-read, decrypt round-trip, and the mask-preserve-on-update behaviour
 * (an unchanged `****` secret must keep the stored ciphertext, never overwrite
 * it with the mask). The db module is mocked via require.cache so the stored
 * read-back can be exercised without a live database (same pattern as
 * transformers-active-uses-ro.test.js).
 */
const { describe, it, before, beforeEach } = require('node:test');
const assert = require('node:assert/strict');

// settings-crypto reads SETTINGS_ENCRYPTION_KEY per call; set it before the
// serializer (and the crypto module) are first required.
process.env.SETTINGS_ENCRYPTION_KEY = 'unit-test-key-do-not-use-in-prod';

const dbKey = require.resolve('../../src/edge/db');
let storedRows = [];
const poolSpy = {
  ro: {
    async query() { return storedRows; },
  },
};
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: poolSpy, t: (name) => `fmb_${name}` },
};

const ser = require('../../src/edge/routes/app/api-connectors/serializer');
const { encrypt } = require('../../src/shared/lib/settings-crypto');

const ENC = 'enc:v1:';

describe('api-connector serializer — pure transforms', () => {
  it('encrypts the bearer token leaf, decrypt round-trips, mask hides it', () => {
    const enc = ser.encryptAuthConfig({ token: 'sk-secret' }, 'bearer');
    assert.ok(enc.token.startsWith(ENC), 'token must be encrypted');
    assert.equal(ser.decryptAuthConfig(enc, 'bearer').token, 'sk-secret');
    assert.equal(ser.maskAuthConfig(enc, 'bearer').token, '****');
  });

  it('encrypts only the api_key value, never the header name', () => {
    const enc = ser.encryptAuthConfig({ header: 'X-API-Key', value: 'abc123' }, 'api_key');
    assert.equal(enc.header, 'X-API-Key');
    assert.ok(enc.value.startsWith(ENC));
    assert.equal(ser.maskAuthConfig(enc, 'api_key').value, '****');
    assert.equal(ser.maskAuthConfig(enc, 'api_key').header, 'X-API-Key');
  });

  it('encrypts only the basic password, never the username', () => {
    const enc = ser.encryptAuthConfig({ username: 'bob', password: 'hunter2' }, 'basic');
    assert.equal(enc.username, 'bob');
    assert.ok(enc.password.startsWith(ENC));
    assert.equal(ser.decryptAuthConfig(enc, 'basic').password, 'hunter2');
  });

  it('auth_type none has no sensitive leaf', () => {
    assert.deepEqual(ser.encryptAuthConfig({}, 'none'), {});
  });

  it('encrypt is idempotent (an already-encrypted leaf is not double-wrapped)', () => {
    const once = ser.encryptAuthConfig({ token: 'x' }, 'bearer');
    const twice = ser.encryptAuthConfig(once, 'bearer');
    assert.equal(twice.token, once.token);
  });
});

describe('api-connector serializer — hooks', () => {
  it('serializeWrite (create) encrypts and never reads the pool', async () => {
    const out = await ser.serializeWrite(
      { auth_type: 'bearer', auth_config: { token: 'plain' } },
      { isUpdate: false, id: 'new' },
    );
    assert.ok(out.auth_config.token.startsWith(ENC));
  });

  it('serializeWrite strips a stray secret leaf that does not belong to the auth_type', async () => {
    // auth_type none with a bearer token → the token must NOT be persisted (it
    // would store + read back unencrypted/unmasked since none has no secret path).
    const out = await ser.serializeWrite(
      { auth_type: 'none', auth_config: { token: 'plain' } },
      { isUpdate: false, id: 'new' },
    );
    assert.equal('token' in out.auth_config, false, 'stray token leaf stripped on write');
  });

  it('serializeRead masks the stored ciphertext for the API response', () => {
    const stored = { auth_type: 'bearer', auth_config: { token: encrypt('zzz') }, name: 'c1' };
    const out = ser.serializeRead(stored);
    assert.equal(out.auth_config.token, '****');
    assert.equal(out.name, 'c1');
  });

  it('serializeRead strips approved_by/approved_at but keeps status + review_note', () => {
    const stored = {
      auth_type: 'none', auth_config: null, name: 'c1',
      status: 'rejected', review_note: 'host not allowed',
      approved_by: 'admin-user-id', approved_at: '2026-06-24T00:00:00Z',
    };
    const out = ser.serializeRead(stored);
    assert.equal('approved_by' in out, false); // internal: which admin approved
    assert.equal('approved_at' in out, false); // internal: when
    assert.equal(out.status, 'rejected'); // surfaced
    assert.equal(out.review_note, 'host not allowed'); // editor needs the reason
    assert.equal(out.name, 'c1');
  });

  it('serializeRead strips approval fields even when auth_config is absent', () => {
    // The pre-fix early return on a null auth_config skipped the strip entirely.
    const out = ser.serializeRead({ name: 'c1', approved_by: 'a', approved_at: 't' });
    assert.equal('approved_by' in out, false);
    assert.equal('approved_at' in out, false);
  });

  it('full round-trip: write → stored ciphertext → decryptRow recovers plaintext', async () => {
    const written = await ser.serializeWrite(
      { auth_type: 'basic', auth_config: { username: 'u', password: 'p@ss' } },
      { isUpdate: false },
    );
    const recovered = ser.decryptRow({ auth_type: 'basic', auth_config: written.auth_config });
    assert.equal(recovered.auth_config.password, 'p@ss');
    assert.equal(recovered.auth_config.username, 'u');
  });

  it('serializeWrite passes through a body that carries no auth_config', async () => {
    const body = { name: 'rename only', is_active: false };
    const out = await ser.serializeWrite(body, { isUpdate: true, id: 'x' });
    assert.deepEqual(out, body);
  });
});

describe('api-connector serializer — mask-preserve on update', () => {
  beforeEach(() => { storedRows = []; });

  it('a `****` token is replaced by the stored ciphertext, not re-stored as the mask', async () => {
    const stored = encrypt('original-secret');
    storedRows = [{ auth_config: JSON.stringify({ token: stored }), auth_type: 'bearer' }];
    const out = await ser.serializeWrite(
      { auth_type: 'bearer', auth_config: { token: '****' } },
      { isUpdate: true, id: 'c1' },
    );
    assert.equal(out.auth_config.token, stored, 'must keep the stored ciphertext');
    assert.equal(ser.decryptRow({ auth_type: 'bearer', auth_config: out.auth_config }).auth_config.token, 'original-secret');
  });

  it('a real new secret on update overwrites the stored one (encrypted)', async () => {
    storedRows = [{ auth_config: JSON.stringify({ token: encrypt('old') }), auth_type: 'bearer' }];
    const out = await ser.serializeWrite(
      { auth_type: 'bearer', auth_config: { token: 'brand-new' } },
      { isUpdate: true, id: 'c1' },
    );
    assert.ok(out.auth_config.token.startsWith(ENC));
    assert.equal(ser.decryptRow({ auth_type: 'bearer', auth_config: out.auth_config }).auth_config.token, 'brand-new');
  });

  it('a `****` token with no stored secret drops the leaf (mask never persisted)', async () => {
    storedRows = [{ auth_config: JSON.stringify({}), auth_type: 'bearer' }];
    const out = await ser.serializeWrite(
      { auth_type: 'bearer', auth_config: { token: '****' } },
      { isUpdate: true, id: 'c1' },
    );
    assert.equal('token' in out.auth_config, false, 'masked-with-no-prior must not persist "****"');
  });

  it('recovers auth_type from the stored row when the update body omits it', async () => {
    const stored = encrypt('kept');
    storedRows = [{ auth_config: JSON.stringify({ value: stored, header: 'X-Key' }), auth_type: 'api_key' }];
    const out = await ser.serializeWrite(
      { auth_config: { value: '****', header: 'X-Key' } },
      { isUpdate: true, id: 'c1' },
    );
    assert.equal(out.auth_config.value, stored);
  });
});

describe('api-connector serializer — no encryption key', () => {
  let saved;
  before(() => { saved = process.env.SETTINGS_ENCRYPTION_KEY; });

  it('encryptAuthConfig is fail-closed: throws ENCRYPTION_KEY_MISSING rather than storing plaintext', () => {
    delete process.env.SETTINGS_ENCRYPTION_KEY;
    try {
      assert.throws(
        () => ser.encryptAuthConfig({ token: 'plain' }, 'bearer'),
        (err) => err && err.code === 'ENCRYPTION_KEY_MISSING',
        'a secret must never be persisted unencrypted',
      );
    } finally {
      process.env.SETTINGS_ENCRYPTION_KEY = saved;
    }
  });

  it('encryptAuthConfig with no sensitive leaf (auth_type none) does not require a key', () => {
    delete process.env.SETTINGS_ENCRYPTION_KEY;
    try {
      const out = ser.encryptAuthConfig({}, 'none');
      assert.deepEqual(out, {}, 'no secret leaf → nothing to encrypt → no throw');
    } finally {
      process.env.SETTINGS_ENCRYPTION_KEY = saved;
    }
  });
});

// ---------------------------------------------------------------------------
// probeDecryptable + typed decrypt helpers
// ---------------------------------------------------------------------------

const KEY_A = '0'.repeat(64);
const KEY_B = '1'.repeat(64);

function withKey(key, fn) {
  const prev = process.env.SETTINGS_ENCRYPTION_KEY;
  process.env.SETTINGS_ENCRYPTION_KEY = key;
  try { return fn(); } finally { process.env.SETTINGS_ENCRYPTION_KEY = prev; }
}

function freshSerializer() {
  delete require.cache[require.resolve('../../src/shared/lib/settings-crypto')];
  delete require.cache[require.resolve('../../src/shared/lib/decrypt-error')];
  delete require.cache[require.resolve('../../src/edge/routes/app/api-connectors/serializer')];
  return require('../../src/edge/routes/app/api-connectors/serializer');
}

const { test } = require('node:test');

test('probeDecryptable returns true when the secret decrypts under the current key', () => {
  withKey(KEY_A, () => {
    const { encryptAuthConfig, probeDecryptable } = freshSerializer();
    const enc = encryptAuthConfig({ token: 'hunter2' }, 'bearer');
    assert.strictEqual(probeDecryptable(enc, 'bearer'), true);
  });
});

test('probeDecryptable returns false when the secret was encrypted with another key', () => {
  const enc = withKey(KEY_A, () => freshSerializer().encryptAuthConfig({ token: 'hunter2' }, 'bearer'));
  withKey(KEY_B, () => {
    const { probeDecryptable } = freshSerializer();
    assert.strictEqual(probeDecryptable(enc, 'bearer'), false);
  });
});

test('probeDecryptable returns true for an auth_type with no secret leaf', () => {
  withKey(KEY_A, () => {
    const { probeDecryptable } = freshSerializer();
    assert.strictEqual(probeDecryptable({}, 'none'), true);
  });
});

test('decryptRow throws DecryptError when the secret key differs', () => {
  const enc = withKey(KEY_A, () => freshSerializer().encryptAuthConfig({ value: 's', header: 'X-Key' }, 'api_key'));
  withKey(KEY_B, () => {
    const { decryptRow } = freshSerializer();
    const { DecryptError } = require('../../src/shared/lib/decrypt-error');
    assert.throws(
      () => decryptRow({ auth_config: enc, auth_type: 'api_key' }),
      (e) => e instanceof DecryptError && e.code === 'DECRYPT_AUTH_FAIL',
    );
  });
});
