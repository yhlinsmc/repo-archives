/**
 * effective-blueprint-sql-single-source.test.js
 *
 * ONE RULE, ONE SPELLING — mechanically.
 *
 * `linked_blueprint_id` has two kinds of reader. JavaScript reads it through
 * `linkTargetOf`, which calls a stored `''` absent (that reading is what makes a
 * row bricked by an empty link repairable). SQL reads it inside whatever
 * expression the query author wrote, and the one they wrote was
 * `COALESCE(hn.linked_blueprint_id, ut.blueprint_id)` — which replaces only
 * NULL. A stored `''` survived it as the effective blueprint id, matched no
 * field row, and the orphan scanner reported every payload key on that template
 * as a residual while the delete re-check, asking the identical expression,
 * agreed and removed them.
 *
 * The repair was to move the resolution into `effectiveBlueprintIdSql`. Nothing
 * about that stops the next query from spelling the old form out again, and the
 * defect is invisible in review precisely because the old form reads correct.
 * So this test forbids the spelling rather than trusting the convention: any
 * COALESCE over the link column anywhere in `docker-api/src` outside the one
 * declaration is a failure, by file and line.
 *
 * No database: this is a property of the SOURCE, and a database would only tell
 * us about the queries that happen to run in a test.
 */
const { test, describe } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const SRC_ROOT = path.resolve(__dirname, '../../src');
const DECLARATION = path.join('edge', 'routes', 'app', 'schema', 'helpers.js');

const {
  linkTargetSql,
  effectiveBlueprintIdSql,
} = require('../../src/edge/routes/app/schema/helpers');

/** @param {string} dir @param {string[]} [out] @returns {string[]} */
function walk(dir, out = []) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      if (entry.name === 'node_modules' || entry.name === '__tests__') continue;
      walk(full, out);
    } else if (entry.name.endsWith('.js')) out.push(full);
  }
  return out;
}

/**
 * The source with COMMENT characters blanked and string contents left alone.
 *
 * Both halves matter here. Comments must go, because the block explaining this
 * defect quotes the broken expression verbatim and a scanner that counted it
 * would fail on the explanation. Strings must NOT go, because every SQL
 * statement in this tree lives inside a template literal — masking strings, the
 * way the sibling call-site scanners do, would blank the only place the hunted
 * expression can appear. Strings are still traversed, so a `//` inside one does
 * not open a comment. Blanking (rather than deleting) keeps every offset and
 * line number equal to the file's own.
 *
 * @param {string} src @returns {string}
 */
function withoutComments(src) {
  const out = src.split('');
  let i = 0;
  while (i < src.length) {
    const c = src[i];
    const next = src[i + 1];
    if (c === '/' && next === '/') {
      while (i < src.length && src[i] !== '\n') { out[i] = ' '; i += 1; }
    } else if (c === '/' && next === '*') {
      while (i < src.length && !(src[i] === '*' && src[i + 1] === '/')) {
        if (src[i] !== '\n') out[i] = ' ';
        i += 1;
      }
      out[i] = ' '; out[i + 1] = ' ';
      i += 2;
    } else if (c === '"' || c === "'" || c === '`') {
      const quote = c;
      i += 1;
      while (i < src.length) {
        if (src[i] === '\\') { i += 2; continue; }
        if (src[i] === quote) { i += 1; break; }
        i += 1;
      }
    } else {
      i += 1;
    }
  }
  return out.join('');
}

/**
 * Every `COALESCE(` in the tree whose argument list mentions the link column,
 * with the file and line it sits on.
 *
 * Paren-counted rather than regex-matched across the whole call: the expression
 * spans a template literal with `${}` interpolation, so a pattern that stopped
 * at the first `)` would miss exactly the shape being hunted.
 */
function coalesceSitesOverLinkColumn() {
  const sites = [];
  for (const file of walk(SRC_ROOT)) {
    const src = withoutComments(fs.readFileSync(file, 'utf8'));
    const rel = path.relative(SRC_ROOT, file);
    const re = /COALESCE\s*\(/gi;
    let m;
    while ((m = re.exec(src)) !== null) {
      let depth = 1;
      let i = m.index + m[0].length;
      while (i < src.length && depth > 0) {
        if (src[i] === '(') depth += 1;
        else if (src[i] === ')') depth -= 1;
        i += 1;
      }
      const args = src.slice(m.index + m[0].length, i - 1);
      if (!/linked_blueprint_id/.test(args)) continue;
      sites.push({
        rel,
        line: src.slice(0, m.index).split('\n').length,
        text: `COALESCE(${args.replace(/\s+/g, ' ').trim()})`,
      });
    }
  }
  return sites;
}

describe('effective-blueprint resolution has exactly one spelling', () => {
  test('no query outside the declaration builds its own COALESCE over the link column', () => {
    const strays = coalesceSitesOverLinkColumn().filter((s) => s.rel !== DECLARATION);
    assert.deepEqual(
      strays, [],
      'These sites resolve the effective blueprint themselves. COALESCE replaces only '
      + 'NULL, so a stored empty link survives as the effective blueprint id, matches no '
      + 'field row, and the orphan endpoints then delete valid template answers. Call '
      + 'effectiveBlueprintIdSql(nodeAlias, templateAlias) from helpers.js instead:\n'
      + strays.map((s) => `  ${s.rel}:${s.line}  ${s.text}`).join('\n'),
    );
  });

  test('the declaration is still there, so the guard above is not guarding nothing', () => {
    // A guard whose subject has been renamed away passes silently and for the
    // wrong reason. Assert the one site exists and folds through the shared
    // helper rather than restating the fold itself.
    const sites = coalesceSitesOverLinkColumn();
    assert.equal(sites.length, 1, `expected exactly the declaration, found:\n${
      sites.map((s) => `  ${s.rel}:${s.line}  ${s.text}`).join('\n')}`);
    assert.equal(sites[0].rel, DECLARATION);
    assert.match(
      sites[0].text, /linkTargetSql\s*\(/,
      'the declaration resolves the link without going through linkTargetSql, '
      + 'so the SQL and JavaScript readers no longer share one definition of absent',
    );
  });

  test('the emitted SQL folds NULL and blank the same way', () => {
    assert.equal(linkTargetSql('hn.linked_blueprint_id'), "NULLIF(hn.linked_blueprint_id, '')");
    assert.equal(
      effectiveBlueprintIdSql('hn', 'ut'),
      "COALESCE(NULLIF(hn.linked_blueprint_id, ''), ut.blueprint_id)",
    );
  });

  test('the SQL and JavaScript readers agree on what names no row', () => {
    // The pair this whole change is about: one rule, asked of both readers.
    // `linkTargetOf` is the JavaScript half; the SQL half is asserted against a
    // real engine in tests/integration/orphan-blank-link-real-db.test.js,
    // because whether NULLIF folds a value is the engine's answer, not ours.
    const { linkTargetOf } = require('../../src/edge/routes/app/schema/helpers');
    assert.equal(linkTargetOf(null), null);
    assert.equal(linkTargetOf(''), null);
    assert.equal(linkTargetOf('bp-1'), 'bp-1');
  });
});
