/**
 * db-character-length.test.js — the shared bound counts CHARACTERS, which is
 * what a utf8mb4 column counts, and neither of the two other things a string
 * length could plausibly mean.
 *
 * The expectations are not typed out. They come from an independent
 * code-point reference evaluated over a corpus, at every bound the corpus can
 * straddle — a written table of answers would have to be re-derived by hand
 * for each new case, which is how a bound comes to be asserted against the
 * same wrong unit that produced it. The two counts this must NOT be are
 * asserted directly as well, because a corpus proves agreement with the
 * reference and not that the reference is the right one to have picked.
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');

const { exceedsCharacterLimit } = require('../../src/edge/lib/db-character-length');

const ASTRAL = '\u{1F600}';        // 1 character, 2 UTF-16 code units, 4 bytes
const CJK = '文';              // 1 character, 1 code unit,        3 bytes
const REGIONAL_PAIR = '\u{1F1F9}\u{1F1FC}'; // 2 characters rendered as one flag
const COMBINING = 'é';       // 2 characters rendered as one accented e

const CORPUS = [
  '',
  'k',
  'kkkkk',
  CJK.repeat(4),
  ASTRAL,
  ASTRAL.repeat(3),
  `${ASTRAL}k${CJK}`,
  REGIONAL_PAIR,
  COMBINING,
  `${'k'.repeat(10)}${ASTRAL.repeat(10)}`,
];

describe('exceedsCharacterLimit counts what MariaDB counts', () => {
  it('agrees with an independent code-point reference across the corpus at every bound it straddles', () => {
    const widest = Math.max(...CORPUS.map((s) => s.length));
    for (const value of CORPUS) {
      // Up to the widest CODE-UNIT count so every bound that separates the two
      // readings of this string is exercised, not only the ones a character
      // count would reach.
      for (let max = 0; max <= widest + 1; max += 1) {
        const expected = [...value].length > max;
        assert.equal(
          exceedsCharacterLimit(value, max), expected,
          `${JSON.stringify(value)} at max=${max}: `
          + `${[...value].length} characters, ${value.length} code units, `
          + `${Buffer.byteLength(value, 'utf8')} bytes`,
        );
      }
    }
  });

  it('is not counting UTF-16 code units', () => {
    // The defect this module exists to end, in both the shapes it took: a key
    // MariaDB stores untouched, refused because JavaScript measured it twice.
    const key = ASTRAL.repeat(130);
    assert.equal([...key].length, 130);
    assert.equal(key.length, 260);
    assert.equal(
      exceedsCharacterLimit(key, 255), false,
      '130 characters must fit a 255-character bound',
    );
    assert.equal(
      exceedsCharacterLimit(key, 256), false,
      '130 characters must fit a 256-character bound',
    );
  });

  it('is not counting bytes', () => {
    // A byte count would be the other tempting correction, and it is wrong in
    // the same direction: utf8mb4 charges up to four bytes for one character it
    // still counts as one.
    const key = ASTRAL.repeat(100);
    assert.equal(Buffer.byteLength(key, 'utf8'), 400);
    assert.equal(exceedsCharacterLimit(key, 255), false);

    const cjk = CJK.repeat(200);
    assert.equal(Buffer.byteLength(cjk, 'utf8'), 600);
    assert.equal(exceedsCharacterLimit(cjk, 255), false);
  });

  it('still refuses a string genuinely past the bound', () => {
    assert.equal(exceedsCharacterLimit(ASTRAL.repeat(256), 255), true);
    assert.equal(exceedsCharacterLimit('k'.repeat(256), 255), true);
    assert.equal(exceedsCharacterLimit(CJK.repeat(256), 255), true);
  });

  it('counts a multi-code-point grapheme as the several characters it is stored as', () => {
    // Deliberate, not an oversight: the question is how much of the column the
    // string occupies, never how many marks a reader sees.
    assert.equal(exceedsCharacterLimit(COMBINING, 1), true);
    assert.equal(exceedsCharacterLimit(REGIONAL_PAIR, 1), true);
  });
});
