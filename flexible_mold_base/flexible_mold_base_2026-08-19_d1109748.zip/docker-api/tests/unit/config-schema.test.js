/**
 * config-schema.js unit tests — v3.2.7.5.
 *
 * Tests the Zod-based env var validation, DB_RW_PASSWORD_ENCRYPTED /
 * DB_RO_PASSWORD_ENCRYPTED decryption, and SKIP_CONFIG_VALIDATION escape hatch.
 */
const { describe, it, beforeEach, afterEach } = require('node:test');
const assert = require('node:assert/strict');

// Snapshot original env so we can restore after each test
const originalEnv = { ...process.env };

function resetEnv() {
  // Remove all keys we might have set
  const testKeys = [
    'API_ROLE', 'NODE_ENV', 'S2S_API_KEY', 'SKIP_CONFIG_VALIDATION',
    'SETTINGS_ENCRYPTION_KEY',
    // v3.2.42 — RO encrypted pair; leakage caused unrelated tests to fail
    // with "DB_RO_PASSWORD_ENCRYPTED is set but SETTINGS_ENCRYPTION_KEY missing".
    'DB_RO_PASSWORD', 'DB_RO_PASSWORD_ENCRYPTED',
    // v3.2.44 — canonical writer encrypted variant.
    'DB_RW_PASSWORD', 'DB_RW_PASSWORD_ENCRYPTED',
    'JWT_SECRET', 'PORT', 'EDGE_API_URL',
    // v3.2.14 — URL-shaped vars that tests may set to invalid values
    // and must scrub between cases so a leaked bad value does not flip
    // an otherwise-valid assertion in the next test.
    'API_BASE', 'BASE_URL', 'FRONTEND_URL',
    // v3.2.24 — Keycloak↔BASE_URL cross-field refine tests set this
    'KEYCLOAK_ISSUER_BASE_URL',
    // v3.2.48 — removed-legacy-env refine tests set these to assert rejection.
    'DB_HOST', 'DB_PORT', 'DB_USER', 'DB_PASSWORD', 'DB_PASSWORD_ENCRYPTED',
    // v3.2.61 — DB_TABLE_PREFIX is required when env DB config is present.
    'DB_RW_HOST', 'DB_NAME', 'DB_TABLE_PREFIX',
    // setup rate-limit knobs — scrub so a window=0 reject case does not leak
    // into a later infra-validation test and flip it to a false failure.
    'RATE_LIMIT_SETUP_WINDOW_MS', 'RATE_LIMIT_SETUP_MAX',
  ];
  for (const k of testKeys) {
    delete process.env[k];
  }
  // Restore originals
  Object.assign(process.env, originalEnv);
}

// Must re-require to pick up fresh process.env each time
function freshValidate(role) {
  // Clear require cache for config-schema so it re-reads process.env
  delete require.cache[require.resolve('../../src/shared/config-schema')];
  const { validateConfig } = require('../../src/shared/config-schema');
  return validateConfig(role);
}

describe('config-schema — validateConfig', () => {
  beforeEach(() => resetEnv());
  afterEach(() => resetEnv());

  it('passes with valid infra env', () => {
    process.env.S2S_API_KEY = 'test-secret';
    process.env.JWT_SECRET = 'a'.repeat(32);
    const result = freshValidate('infra');
    assert.equal(result.ok, true);
  });

  it('passes with valid edge env', () => {
    process.env.S2S_API_KEY = 'test-secret';
    const result = freshValidate('edge');
    assert.equal(result.ok, true);
  });

  // Rate-limit window must be strictly positive: express-rate-limit v8 throws
  // ERR_ERL_WINDOW_MS on windowMs < 1. The authoritative guard is boot-rejection
  // (fail-fast, JWT_SECRET-style) — validateConfig runs before the limiter is
  // built, so a 0 window never reaches express-rate-limit.
  it('rejects infra env when RATE_LIMIT_SETUP_WINDOW_MS=0 (window must be > 0)', () => {
    process.env.S2S_API_KEY = 'test-secret';
    process.env.JWT_SECRET = 'a'.repeat(32);
    process.env.RATE_LIMIT_SETUP_WINDOW_MS = '0';
    const result = freshValidate('infra');
    assert.equal(result.ok, false);
    assert.match(result.error, /RATE_LIMIT_SETUP_WINDOW_MS/);
  });

  // MAX is asymmetric to the window: 0 is a VALID, meaningful value (block-all,
  // fail-closed), so the schema accepts it (nonnegative, not positive).
  it('accepts infra env with RATE_LIMIT_SETUP_MAX=0 (0 = block-all, valid)', () => {
    process.env.S2S_API_KEY = 'test-secret';
    process.env.JWT_SECRET = 'a'.repeat(32);
    process.env.RATE_LIMIT_SETUP_MAX = '0';
    const result = freshValidate('infra');
    assert.equal(result.ok, true);
  });

  // v3.2.14 — frontend role (carry-forward: tests that were intended for
  // PR #52 but missed the commit; landed here in v3.2.14a).
  // v3.2.51 T4 completion — API_BASE is REJECTED outright now. The
  // historical absolute-URL / scheme-guard cases below are rewritten
  // to assert the new reject behaviour; the replacement allowlist
  // (API_BASE_ALLOWLIST) has its own coverage in parse-allowlist.test.js.
  it('passes frontend role with no API_BASE set (post-v3.2.51 default)', () => {
    const result = freshValidate('frontend');
    assert.equal(result.ok, true);
    // v3.2.51: API_BASE is no longer a schema field, only rejected if set.
    assert.equal(result.config.API_BASE, undefined);
    assert.equal(result.config.PORT, 3000);
  });

  it('rejects frontend role when legacy API_BASE env is still set (v3.2.51 T4)', () => {
    process.env.API_BASE = 'https://zonea-fmb-api.localhost';
    const result = freshValidate('frontend');
    assert.equal(result.ok, false);
    assert.match(result.error, /API_BASE/);
    assert.match(result.error, /API_BASE_ALLOWLIST/);
  });

  it('rejects frontend role with any non-empty legacy API_BASE including bad schemes (v3.2.51 T4 supersedes v3.2.14a URL guard)', () => {
    process.env.API_BASE = 'javascript:alert(1)';
    const result = freshValidate('frontend');
    assert.equal(result.ok, false);
    assert.match(result.error, /API_BASE/);
  });

  it('rejects frontend role with relative path in API_BASE (still rejected under v3.2.51)', () => {
    process.env.API_BASE = '/api';
    const result = freshValidate('frontend');
    assert.equal(result.ok, false);
  });

  it('frontend role does NOT require S2S_API_KEY', () => {
    delete process.env.S2S_API_KEY;
    const result = freshValidate('frontend');
    assert.equal(result.ok, true);
  });

  it('rejects env DB config without DB_TABLE_PREFIX', () => {
    process.env.S2S_API_KEY = 'test-secret';
    process.env.JWT_SECRET = 'a'.repeat(32);
    process.env.DB_RW_HOST = 'writer.example';
    process.env.DB_NAME = 'app';

    const result = freshValidate('infra');
    assert.equal(result.ok, false);
    assert.match(result.error, /DB_TABLE_PREFIX/);
    assert.match(result.error, /required when DB_RW_HOST is set/);
  });

  it('accepts env DB config with explicit DB_TABLE_PREFIX', () => {
    process.env.S2S_API_KEY = 'test-secret';
    process.env.JWT_SECRET = 'a'.repeat(32);
    process.env.DB_RW_HOST = 'writer.example';
    process.env.DB_NAME = 'app';
    process.env.DB_TABLE_PREFIX = 'app_';

    const result = freshValidate('infra');
    assert.equal(result.ok, true);
  });

  // v3.2.61a — frontend role is static-only and never opens a DB pool. The
  // shared ConfigMap carries DB_RW_HOST for edge/infra; refineRequiredTablePrefix
  // must not crash-loop frontend pods that have no reason to envFrom fmb-secrets.
  it('accepts frontend role when DB_RW_HOST is set without DB_TABLE_PREFIX', () => {
    process.env.JWT_SECRET = 'a'.repeat(32);
    process.env.DB_RW_HOST = 'writer.example';
    delete process.env.DB_TABLE_PREFIX;

    const result = freshValidate('frontend');
    assert.equal(result.ok, true, result.error);
  });

  // v3.2.14a — FRONTEND_URL + BASE_URL Zod URL refine (parity with API_BASE).
  it('rejects infra FRONTEND_URL without scheme (typo guard)', () => {
    process.env.S2S_API_KEY = 'test-secret';
    process.env.JWT_SECRET = 'a'.repeat(32);
    process.env.FRONTEND_URL = 'zonea-fmb-web.localhost';
    const result = freshValidate('infra');
    assert.equal(result.ok, false);
    assert.match(result.error, /FRONTEND_URL/);
  });

  it('rejects infra BASE_URL javascript: scheme', () => {
    process.env.S2S_API_KEY = 'test-secret';
    process.env.JWT_SECRET = 'a'.repeat(32);
    process.env.BASE_URL = 'javascript:alert(1)';
    const result = freshValidate('infra');
    assert.equal(result.ok, false);
    assert.match(result.error, /BASE_URL/);
  });

  it('accepts infra FRONTEND_URL + BASE_URL as absolute https', () => {
    process.env.S2S_API_KEY = 'test-secret';
    process.env.JWT_SECRET = 'a'.repeat(32);
    process.env.FRONTEND_URL = 'https://zonea-fmb-web.localhost';
    process.env.BASE_URL = 'https://zonea-fmb-api.localhost';
    const result = freshValidate('infra');
    assert.equal(result.ok, true);
  });

  it('rejects triple-slash URL (empty host)', () => {
    process.env.S2S_API_KEY = 'test-secret';
    process.env.JWT_SECRET = 'a'.repeat(32);
    process.env.FRONTEND_URL = 'http:///path';
    const result = freshValidate('infra');
    assert.equal(result.ok, false);
    assert.match(result.error, /FRONTEND_URL/);
  });

  it('accepts uppercase HTTPS scheme (case-insensitive)', () => {
    process.env.S2S_API_KEY = 'test-secret';
    process.env.JWT_SECRET = 'a'.repeat(32);
    process.env.FRONTEND_URL = 'HTTPS://zonea-fmb-web.localhost';
    const result = freshValidate('infra');
    assert.equal(result.ok, true);
  });

  it('accepts infra FRONTEND_URL / BASE_URL empty (backward compat)', () => {
    process.env.S2S_API_KEY = 'test-secret';
    process.env.JWT_SECRET = 'a'.repeat(32);
    process.env.FRONTEND_URL = '';
    process.env.BASE_URL = '';
    const result = freshValidate('infra');
    assert.equal(result.ok, true);
  });

  it('fails when S2S_API_KEY is missing (infra)', () => {
    delete process.env.S2S_API_KEY;
    const result = freshValidate('infra');
    assert.equal(result.ok, false);
    assert.ok(result.error.includes('S2S_API_KEY'));
  });

  it('fails when S2S_API_KEY is missing (edge)', () => {
    delete process.env.S2S_API_KEY;
    const result = freshValidate('edge');
    assert.equal(result.ok, false);
    assert.ok(result.error.includes('S2S_API_KEY'));
  });

  it('respects SKIP_CONFIG_VALIDATION=1 escape hatch', () => {
    delete process.env.S2S_API_KEY;
    process.env.SKIP_CONFIG_VALIDATION = '1';
    const result = freshValidate('infra');
    assert.equal(result.ok, true);
    assert.equal(result.skipped, true);
  });

  it('defaults API_ROLE to infra', () => {
    process.env.S2S_API_KEY = 'test-secret';
    const result = freshValidate('infra');
    assert.equal(result.ok, true);
  });

  it('defaults NODE_ENV to development', () => {
    process.env.S2S_API_KEY = 'test-secret';
    delete process.env.NODE_ENV;
    const result = freshValidate('infra');
    assert.equal(result.ok, true);
  });

  it('rejects invalid NODE_ENV', () => {
    process.env.S2S_API_KEY = 'test-secret';
    process.env.NODE_ENV = 'staging';
    const result = freshValidate('infra');
    assert.equal(result.ok, false);
    assert.ok(result.error.includes('NODE_ENV'));
  });

  it('accepts uppercase API_ROLE (case-insensitive)', () => {
    process.env.S2S_API_KEY = 'test-secret';
    process.env.API_ROLE = 'EDGE';
    const result = freshValidate('edge');
    assert.equal(result.ok, true);
  });

  it('accepts uppercase NODE_ENV (case-insensitive)', () => {
    process.env.S2S_API_KEY = 'test-secret';
    process.env.NODE_ENV = 'PRODUCTION';
    const result = freshValidate('infra');
    assert.equal(result.ok, true);
  });

  it('blocks SKIP_CONFIG_VALIDATION in production', () => {
    process.env.NODE_ENV = 'production';
    process.env.SKIP_CONFIG_VALIDATION = '1';
    const result = freshValidate('infra');
    assert.equal(result.ok, false);
    assert.ok(result.error.includes('not allowed in production'));
  });

  it('rejects JWT_SECRET shorter than 32 characters', () => {
    process.env.S2S_API_KEY = 'test-secret';
    process.env.JWT_SECRET = 'abc123';
    const result = freshValidate('infra');
    assert.equal(result.ok, false);
    assert.ok(result.error.includes('JWT_SECRET'));
    assert.ok(result.error.includes('32 characters'));
  });

  it('accepts JWT_SECRET of exactly 32 characters', () => {
    process.env.S2S_API_KEY = 'test-secret';
    process.env.JWT_SECRET = 'a'.repeat(32);
    const result = freshValidate('infra');
    assert.equal(result.ok, true);
  });

  it('accepts unset JWT_SECRET (keycloak-only mode)', () => {
    process.env.S2S_API_KEY = 'test-secret';
    delete process.env.JWT_SECRET;
    const result = freshValidate('infra');
    assert.equal(result.ok, true);
  });

  it('passes with numeric PORT as string', () => {
    process.env.S2S_API_KEY = 'test-secret';
    process.env.PORT = '8080';
    const result = freshValidate('infra');
    assert.equal(result.ok, true);
  });
});

describe('config-schema — DB_RW_PASSWORD_ENCRYPTED (v3.2.44 canonical rename)', () => {
  beforeEach(() => resetEnv());
  afterEach(() => resetEnv());

  // Capture stderr writes during a validate call so we can assert on
  // deprecation warning emission.
  function captureStderr(fn) {
    const chunks = [];
    const origWrite = process.stderr.write.bind(process.stderr);
    process.stderr.write = (chunk) => {
      chunks.push(typeof chunk === 'string' ? chunk : chunk.toString('utf8'));
      return true;
    };
    try { return { result: fn(), stderr: chunks.join('') }; }
    finally { process.stderr.write = origWrite; }
  }

  it('decrypts DB_RW_PASSWORD_ENCRYPTED and sets DB_RW_PASSWORD (canonical)', () => {
    process.env.S2S_API_KEY = 'test-secret';
    process.env.SETTINGS_ENCRYPTION_KEY = 'test-encryption-key-32chars!!!!!';

    delete require.cache[require.resolve('../../src/shared/lib/settings-crypto')];
    const { encrypt } = require('../../src/shared/lib/settings-crypto');
    process.env.DB_RW_PASSWORD_ENCRYPTED = encrypt('canonical-pw');
    delete process.env.DB_RW_PASSWORD;

    const { result, stderr } = captureStderr(() => freshValidate('infra'));
    assert.equal(result.ok, true);
    assert.equal(process.env.DB_RW_PASSWORD, 'canonical-pw');
    // No deprecation warn when only canonical is set.
    assert.ok(!stderr.includes('deprecated'), `unexpected deprecation warn: ${stderr}`);
  });

});

describe('config-schema — DB_RO_PASSWORD_ENCRYPTED (v3.2.42 parity)', () => {
  beforeEach(() => resetEnv());
  afterEach(() => resetEnv());

  it('decrypts DB_RO_PASSWORD_ENCRYPTED and sets DB_RO_PASSWORD', () => {
    process.env.S2S_API_KEY = 'test-secret';
    process.env.SETTINGS_ENCRYPTION_KEY = 'test-encryption-key-32chars!!!!!';

    delete require.cache[require.resolve('../../src/shared/lib/settings-crypto')];
    const { encrypt } = require('../../src/shared/lib/settings-crypto');
    const encrypted = encrypt('ro-secret-password');

    process.env.DB_RO_PASSWORD_ENCRYPTED = encrypted;
    delete process.env.DB_RO_PASSWORD;

    const result = freshValidate('infra');
    assert.equal(result.ok, true);
    assert.equal(process.env.DB_RO_PASSWORD, 'ro-secret-password');
  });

  it('fails when DB_RO_PASSWORD_ENCRYPTED is set but SETTINGS_ENCRYPTION_KEY is missing', () => {
    process.env.S2S_API_KEY = 'test-secret';
    delete process.env.SETTINGS_ENCRYPTION_KEY;
    process.env.DB_RO_PASSWORD_ENCRYPTED = 'enc:v1:aabbcc:ddeeff:112233';

    const result = freshValidate('infra');
    assert.equal(result.ok, false);
    assert.ok(result.error.includes('SETTINGS_ENCRYPTION_KEY'));
    assert.ok(result.error.includes('DB_RO_PASSWORD_ENCRYPTED'));
  });

  it('skips RO decryption when DB_RO_PASSWORD_ENCRYPTED is not set', () => {
    process.env.S2S_API_KEY = 'test-secret';
    process.env.DB_RO_PASSWORD = 'plain-ro-password';
    delete process.env.DB_RO_PASSWORD_ENCRYPTED;

    const result = freshValidate('infra');
    assert.equal(result.ok, true);
    assert.equal(process.env.DB_RO_PASSWORD, 'plain-ro-password');
  });

  it('decrypts both RW and RO encrypted passwords independently', () => {
    process.env.S2S_API_KEY = 'test-secret';
    process.env.SETTINGS_ENCRYPTION_KEY = 'test-encryption-key-32chars!!!!!';

    delete require.cache[require.resolve('../../src/shared/lib/settings-crypto')];
    const { encrypt } = require('../../src/shared/lib/settings-crypto');
    process.env.DB_RW_PASSWORD_ENCRYPTED = encrypt('writer-pw');
    process.env.DB_RO_PASSWORD_ENCRYPTED = encrypt('reader-pw');
    delete process.env.DB_RW_PASSWORD;
    delete process.env.DB_RO_PASSWORD;

    const result = freshValidate('infra');
    assert.equal(result.ok, true);
    assert.equal(process.env.DB_RW_PASSWORD, 'writer-pw');
    assert.equal(process.env.DB_RO_PASSWORD, 'reader-pw');
  });

  it('fails on malformed RO encrypted value without clobbering RW', () => {
    process.env.S2S_API_KEY = 'test-secret';
    process.env.SETTINGS_ENCRYPTION_KEY = 'test-encryption-key-32chars!!!!!';

    delete require.cache[require.resolve('../../src/shared/lib/settings-crypto')];
    const { encrypt } = require('../../src/shared/lib/settings-crypto');
    process.env.DB_RW_PASSWORD_ENCRYPTED = encrypt('good-writer');
    // Well-formed enc:v1: prefix but corrupted ciphertext triggers the
    // decrypt() catch path → structured error mentioning RO.
    process.env.DB_RO_PASSWORD_ENCRYPTED = 'enc:v1:' +
      'a'.repeat(24) + ':' + 'b'.repeat(32) + ':' + 'c'.repeat(40);

    const result = freshValidate('infra');
    assert.equal(result.ok, false);
    assert.ok(result.error.includes('DB_RO_PASSWORD_ENCRYPTED'));
    assert.ok(!result.error.includes('DB_RW_PASSWORD_ENCRYPTED '),
      'error should pinpoint RO variant, not RW');
  });

  it('fails with actionable error when enc:v1: prefix but wrong segment count (not silent passthrough)', () => {
    // Review-MED round-2 regression: a malformed `enc:v1:` value with only
    // two colon-segments used to silently be injected as-is (settings-crypto
    // logs a warn and returns the raw string). Pool then failed at build
    // time with a cryptic mariadb auth error. With the fix, boot fails up-front.
    process.env.S2S_API_KEY = 'test-secret';
    process.env.SETTINGS_ENCRYPTION_KEY = 'test-encryption-key-32chars!!!!!';
    // enc:v1: prefix but only 2 segments (should be 3 — iv:tag:ct)
    process.env.DB_RO_PASSWORD_ENCRYPTED = 'enc:v1:abcdef:112233';

    const result = freshValidate('infra');
    assert.equal(result.ok, false);
    assert.ok(result.error.includes('could not be parsed'));
    assert.ok(result.error.includes('DB_RO_PASSWORD_ENCRYPTED'));
    assert.ok(result.error.includes('encrypt-env-value.js'),
      'error should point operator to the regen CLI');
  });
});

describe('config-schema — edge-specific', () => {
  beforeEach(() => resetEnv());
  afterEach(() => resetEnv());

  it('defaults PORT to 3201 for edge', () => {
    process.env.S2S_API_KEY = 'test-secret';
    delete process.env.PORT;
    const result = freshValidate('edge');
    assert.equal(result.ok, true);
    assert.equal(result.config.PORT, 3201);
  });

  it('defaults PORT to 3200 for infra', () => {
    process.env.S2S_API_KEY = 'test-secret';
    delete process.env.PORT;
    const result = freshValidate('infra');
    assert.equal(result.ok, true);
    assert.equal(result.config.PORT, 3200);
  });
});

describe('config-schema — v3.2.24 KEYCLOAK_ISSUER_BASE_URL ↔ BASE_URL refine', () => {
  beforeEach(() => resetEnv());
  afterEach(() => resetEnv());

  it('infra passes when Keycloak unset and BASE_URL empty (local-mode default)', () => {
    process.env.S2S_API_KEY = 'test-secret';
    delete process.env.KEYCLOAK_ISSUER_BASE_URL;
    delete process.env.BASE_URL;
    const result = freshValidate('infra');
    assert.equal(result.ok, true, result.error);
  });

  it('infra passes when Keycloak set AND BASE_URL set', () => {
    process.env.S2S_API_KEY = 'test-secret';
    process.env.KEYCLOAK_ISSUER_BASE_URL = 'https://keycloak.example.com/realms/dev';
    process.env.BASE_URL = 'https://zonea-fmb-api.localhost';
    const result = freshValidate('infra');
    assert.equal(result.ok, true, result.error);
  });

  it('infra FAILS when Keycloak set but BASE_URL empty (the v3.2.23 silent-fallback footgun)', () => {
    process.env.S2S_API_KEY = 'test-secret';
    process.env.KEYCLOAK_ISSUER_BASE_URL = 'https://keycloak.example.com/realms/dev';
    process.env.BASE_URL = '';
    const result = freshValidate('infra');
    assert.equal(result.ok, false);
    assert.match(
      result.error,
      /BASE_URL must be set when KEYCLOAK_ISSUER_BASE_URL is configured/,
    );
  });

  it('infra FAILS when Keycloak set but BASE_URL unset entirely', () => {
    process.env.S2S_API_KEY = 'test-secret';
    process.env.KEYCLOAK_ISSUER_BASE_URL = 'https://keycloak.example.com/realms/dev';
    delete process.env.BASE_URL;
    const result = freshValidate('infra');
    assert.equal(result.ok, false);
    assert.match(result.error, /BASE_URL must be set when KEYCLOAK_ISSUER_BASE_URL/);
  });

  it('refine does not affect edge or frontend roles', () => {
    process.env.S2S_API_KEY = 'test-secret';
    process.env.KEYCLOAK_ISSUER_BASE_URL = 'https://keycloak.example.com/realms/dev';
    process.env.BASE_URL = '';

    const edgeResult = freshValidate('edge');
    assert.equal(edgeResult.ok, true, edgeResult.error);

    const frontendResult = freshValidate('frontend');
    assert.equal(frontendResult.ok, true, frontendResult.error);
  });
});

describe('config-schema — v3.2.48 removed-legacy-env hard-fail', () => {
  beforeEach(() => resetEnv());
  afterEach(() => resetEnv());

  const removed = [
    { legacy: 'DB_HOST', canonical: 'DB_RW_HOST' },
    { legacy: 'DB_PORT', canonical: 'DB_RW_PORT' },
    { legacy: 'DB_USER', canonical: 'DB_RW_USER' },
    { legacy: 'DB_PASSWORD', canonical: 'DB_RW_PASSWORD' },
    { legacy: 'DB_PASSWORD_ENCRYPTED', canonical: 'DB_RW_PASSWORD_ENCRYPTED' },
  ];

  for (const { legacy, canonical } of removed) {
    it(`infra FAILS when stray ${legacy} is set (points to ${canonical})`, () => {
      process.env.S2S_API_KEY = 'test-secret';
      process.env[legacy] = 'stale-value';
      const result = freshValidate('infra');
      assert.equal(result.ok, false);
      assert.match(result.error, new RegExp(`${legacy} was removed in v3\\.2\\.47`));
      assert.match(result.error, new RegExp(`Use ${canonical}`));
    });

    it(`edge FAILS when stray ${legacy} is set`, () => {
      process.env.S2S_API_KEY = 'test-secret';
      process.env[legacy] = 'stale-value';
      const result = freshValidate('edge');
      assert.equal(result.ok, false);
      assert.match(result.error, new RegExp(`${legacy} was removed`));
    });

    it(`frontend FAILS when stray ${legacy} is set`, () => {
      process.env[legacy] = 'stale-value';
      const result = freshValidate('frontend');
      assert.equal(result.ok, false);
      assert.match(result.error, new RegExp(`${legacy} was removed`));
    });
  }

  it('empty-string legacy env is treated as unset (no boot failure)', () => {
    process.env.S2S_API_KEY = 'test-secret';
    process.env.DB_HOST = '';
    const result = freshValidate('infra');
    assert.equal(result.ok, true, result.error);
  });

  it('multiple stray legacy names produce a single combined error', () => {
    process.env.S2S_API_KEY = 'test-secret';
    process.env.DB_HOST = 'stale';
    process.env.DB_USER = 'stale';
    const result = freshValidate('infra');
    assert.equal(result.ok, false);
    assert.match(result.error, /DB_HOST was removed/);
    assert.match(result.error, /DB_USER was removed/);
  });
});
