const { test } = require('node:test');
const assert = require('node:assert');

const KEY = 'unit-test-key-do-not-use-in-prod';

function withKey(fn) {
  const prev = process.env.SETTINGS_ENCRYPTION_KEY;
  process.env.SETTINGS_ENCRYPTION_KEY = KEY;
  try { return fn(); } finally {
    if (prev === undefined) delete process.env.SETTINGS_ENCRYPTION_KEY;
    else process.env.SETTINGS_ENCRYPTION_KEY = prev;
  }
}
function withoutKey(fn) {
  const prev = process.env.SETTINGS_ENCRYPTION_KEY;
  delete process.env.SETTINGS_ENCRYPTION_KEY;
  try { return fn(); } finally {
    if (prev !== undefined) process.env.SETTINGS_ENCRYPTION_KEY = prev;
  }
}

const {
  encryptConfigSecrets,
  decryptConfigSecrets,
  SECRET_FIELDS,
} = require('../../src/shared/lib/db-config-crypto');

test('encryptConfigSecrets encrypts password and readPassword to enc:v1', () => {
  withKey(() => {
    const out = encryptConfigSecrets({ host: 'h', password: 'pw', readPassword: 'ro' });
    assert.ok(out.password.startsWith('enc:v1:'), 'password encrypted');
    assert.ok(out.readPassword.startsWith('enc:v1:'), 'readPassword encrypted');
    assert.strictEqual(out.host, 'h', 'non-secret fields untouched');
  });
});

test('round-trip: decrypt(encrypt(x)) === x', () => {
  withKey(() => {
    const enc = encryptConfigSecrets({ password: 'pw', readPassword: 'ro' });
    const dec = decryptConfigSecrets(enc);
    assert.strictEqual(dec.password, 'pw');
    assert.strictEqual(dec.readPassword, 'ro');
  });
});

test('encryptConfigSecrets leaves empty/absent secret fields alone', () => {
  withKey(() => {
    const out = encryptConfigSecrets({ host: 'h', password: '' });
    assert.strictEqual(out.password, '', 'empty password not encrypted');
    assert.ok(!('readPassword' in out) || out.readPassword === undefined);
  });
});

test('encryptConfigSecrets throws ENCRYPTION_KEY_MISSING with no key', () => {
  withoutKey(() => {
    assert.throws(
      () => encryptConfigSecrets({ password: 'pw' }),
      (err) => err.code === 'ENCRYPTION_KEY_MISSING',
    );
  });
});

test('decryptConfigSecrets passes legacy plaintext through unchanged', () => {
  withoutKey(() => {
    const out = decryptConfigSecrets({ host: 'h', password: 'legacy-plain' });
    assert.strictEqual(out.password, 'legacy-plain');
  });
});

test('decryptConfigSecrets fail-closed on enc:v1 field with no key', () => {
  withoutKey(() => {
    assert.throws(
      () => decryptConfigSecrets({ password: 'enc:v1:aa:bb:cc' }),
      (err) => err.code === 'ENCRYPTION_KEY_MISSING',
    );
  });
});

test('decryptConfigSecrets fail-closed on malformed enc:v1 (bad segment count)', () => {
  withKey(() => {
    assert.throws(
      () => decryptConfigSecrets({ password: 'enc:v1:onlytwo:parts' }),
      (err) => err.code === 'DECRYPT_MALFORMED',
    );
  });
});

test('SECRET_FIELDS is the password pair', () => {
  assert.deepStrictEqual([...SECRET_FIELDS].sort(), ['password', 'readPassword']);
});
