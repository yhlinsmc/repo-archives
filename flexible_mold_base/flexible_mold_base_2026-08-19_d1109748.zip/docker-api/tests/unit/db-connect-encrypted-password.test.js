/**
 * db-connect-encrypted-password.test.js — v3.2.53 PR-2 (Q4)
 *
 * Integration-level pin: the /test-db handler must short-circuit to a
 * 400 with the mapped UI copy when resolvePassword throws, BEFORE
 * touching mariadb. Complements the pure-unit tests on the decrypt
 * helper by exercising the actual Express handler's error-shaping and
 * read-endpoint independence.
 *
 * Covers:
 *   - Q4 happy path: isEncrypted=true + valid ciphertext → probe sees plaintext
 *   - M1 error codes → 400 + UI copy from DECRYPT_UI_COPY
 *   - M8-(a) negative: isEncrypted=false + enc:v1: prefix → DECRYPT_LOOKS_ENCRYPTED
 *   - Read endpoint independence: reader failure is prefixed "Read endpoint: ..."
 */
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

// ── Stub mariadb before requiring db-connect (same pattern as existing
// db-connect-handler-shape.test.js) ────────────────────────────────────────
const mariadbKey = require.resolve('mariadb');
const dbKey = require.resolve('../../src/edge/db');

let lastProbePassword; // captured on each probe; null if not reached
const mariadbStub = {
  createPool(opts) {
    lastProbePassword = opts.password;
    return {
      async getConnection() {
        return { release: () => {} };
      },
      async end() {},
    };
  },
};
require.cache[mariadbKey] = { id: mariadbKey, filename: mariadbKey, loaded: true, exports: mariadbStub };
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: {
    isPoolReady: () => false,
    getDbConfig: () => null,
    configurePool: async () => {},
    saveConfig: () => {},
  },
};

const register = require('../../src/edge/routes/platform/setup/db-connect');
const {
  DECRYPT_UI_COPY,
  DECRYPT_FAILED_GENERIC,
  shapeDecryptError,
} = require('../../src/edge/routes/platform/setup/db-connect');
const { DecryptError } = require('../../src/shared/lib/decrypt-password');
const { encrypt } = require('../../src/shared/lib/settings-crypto');

function postJson(port, path_, body) {
  return new Promise((resolve, reject) => {
    const payload = JSON.stringify(body);
    const req = http.request(
      { host: '127.0.0.1', port, path: path_, method: 'POST',
        headers: { 'content-type': 'application/json', 'content-length': Buffer.byteLength(payload) } },
      (res) => {
        let buf = '';
        res.on('data', (c) => { buf += c; });
        res.on('end', () => resolve({ status: res.statusCode, body: buf ? JSON.parse(buf) : null }));
      },
    );
    req.on('error', reject);
    req.write(payload);
    req.end();
  });
}

const TEST_KEY = 'a'.repeat(64);
let server, port, savedKey;

before(async () => {
  savedKey = process.env.SETTINGS_ENCRYPTION_KEY;
  process.env.SETTINGS_ENCRYPTION_KEY = TEST_KEY;

  const app = express();
  app.use(express.json());
  const router = express.Router();
  register(router);
  app.use('/api/setup', router);
  await new Promise((r) => { server = app.listen(0, '127.0.0.1', r); });
  port = server.address().port;
});

after(async () => {
  await new Promise((r) => server.close(r));
  if (savedKey === undefined) delete process.env.SETTINGS_ENCRYPTION_KEY;
  else process.env.SETTINGS_ENCRYPTION_KEY = savedKey;
});

// ─── Happy path ─────────────────────────────────────────────────────────────

test('Q4 happy: isEncrypted=true + valid ct → mariadb sees plaintext', async () => {
  const ct = encrypt('realpassword');
  lastProbePassword = null;
  const r = await postJson(port, '/api/setup/test-db', {
    host: 'stub', user: 'u', password: ct, passwordIsEncrypted: true,
  });
  assert.equal(r.status, 200);
  assert.equal(r.body.data.success, true);
  assert.equal(lastProbePassword, 'realpassword', 'mariadb probe must receive decrypted plaintext');
});

test('Q4 happy: isEncrypted=false + plain → mariadb sees plain', async () => {
  lastProbePassword = null;
  const r = await postJson(port, '/api/setup/test-db', {
    host: 'stub', user: 'u', password: 'myplain', passwordIsEncrypted: false,
  });
  assert.equal(r.status, 200);
  assert.equal(lastProbePassword, 'myplain');
});

// ─── M1 error codes ────────────────────────────────────────────────────────

test('M1 DECRYPT_MALFORMED: isEncrypted=true + no prefix → 400 + UI copy', async () => {
  lastProbePassword = null;
  const r = await postJson(port, '/api/setup/test-db', {
    host: 'stub', user: 'u', password: 'not-a-ct', passwordIsEncrypted: true,
  });
  assert.equal(r.status, 400);
  assert.equal(r.body.error.code, 'DECRYPT_MALFORMED');
  assert.equal(r.body.error.message, DECRYPT_UI_COPY.DECRYPT_MALFORMED);
  assert.equal(lastProbePassword, null, 'mariadb must not be called when decrypt fails');
});

test('M1 DECRYPT_KEY_MISSING: isEncrypted=true + valid shape + no key → 400', async () => {
  delete process.env.SETTINGS_ENCRYPTION_KEY;
  try {
    const r = await postJson(port, '/api/setup/test-db', {
      host: 'stub', user: 'u', password: 'enc:v1:aa:bb:cc', passwordIsEncrypted: true,
    });
    assert.equal(r.status, 400);
    assert.equal(r.body.error.code, 'DECRYPT_KEY_MISSING');
    assert.equal(r.body.error.message, DECRYPT_UI_COPY.DECRYPT_KEY_MISSING);
  } finally {
    process.env.SETTINGS_ENCRYPTION_KEY = TEST_KEY;
  }
});

test('M1 DECRYPT_AUTH_FAIL: isEncrypted=true + wrong-key ct → 400', async () => {
  // Encrypt under a key, then switch server key to a different value
  const ct = encrypt('whatever');
  process.env.SETTINGS_ENCRYPTION_KEY = 'b'.repeat(64);
  try {
    const r = await postJson(port, '/api/setup/test-db', {
      host: 'stub', user: 'u', password: ct, passwordIsEncrypted: true,
    });
    assert.equal(r.status, 400);
    assert.equal(r.body.error.code, 'DECRYPT_AUTH_FAIL');
    assert.equal(r.body.error.message, DECRYPT_UI_COPY.DECRYPT_AUTH_FAIL);
  } finally {
    process.env.SETTINGS_ENCRYPTION_KEY = TEST_KEY;
  }
});

// ─── M8 negative: OFF + enc:v1: prefix (operator footgun) ──────────────────

test('M8-(a) negative: isEncrypted=false + enc:v1: prefix → DECRYPT_LOOKS_ENCRYPTED', async () => {
  lastProbePassword = null;
  const r = await postJson(port, '/api/setup/test-db', {
    host: 'stub', user: 'u', password: 'enc:v1:aa:bb:cc', passwordIsEncrypted: false,
  });
  assert.equal(r.status, 400);
  assert.equal(r.body.error.code, 'DECRYPT_LOOKS_ENCRYPTED');
  assert.equal(r.body.error.message, DECRYPT_UI_COPY.DECRYPT_LOOKS_ENCRYPTED);
  assert.equal(lastProbePassword, null);
});

// ─── Read endpoint ─────────────────────────────────────────────────────────

test('Read endpoint: malformed ct on read side → prefixed "Read endpoint:"', async () => {
  const ct = encrypt('realpass');
  const r = await postJson(port, '/api/setup/test-db', {
    host: 'stub', user: 'u', password: ct, passwordIsEncrypted: true,
    readConfig: { host: 'replica', password: 'no-prefix-ct', passwordIsEncrypted: true },
  });
  assert.equal(r.status, 400);
  assert.equal(r.body.error.code, 'DECRYPT_MALFORMED');
  assert.match(r.body.error.message, /^Read endpoint:/);
});

// ─── HIGH review-gate: side-channel collapse for unauth + pool-ready ─────────────

test('Leak guard: pool-ready + non-admin caller → DecryptError codes collapse to DECRYPT_FAILED', () => {
  // Pure-function test — poolReady=true + req.user={} (not admin) should
  // collapse KEY_MISSING / AUTH_FAIL / MALFORMED into generic DECRYPT_FAILED
  // so an unauthenticated attacker cannot use error-code differentiation
  // as a SETTINGS_ENCRYPTION_KEY presence side-channel.
  const req = { user: null };
  const err = new DecryptError('DECRYPT_KEY_MISSING', 'should not surface');
  const shaped = shapeDecryptError(err, req, /* poolReady */ true);
  assert.equal(shaped.code, DECRYPT_FAILED_GENERIC.code);
  assert.equal(shaped.message, DECRYPT_FAILED_GENERIC.message);
});

test('Leak guard: pool-ready + admin caller → granular codes retained', () => {
  const req = { user: { role: 'admin' } };
  const err = new DecryptError('DECRYPT_KEY_MISSING', 'x');
  const shaped = shapeDecryptError(err, req, /* poolReady */ true);
  assert.equal(shaped.code, 'DECRYPT_KEY_MISSING');
  assert.equal(shaped.message, DECRYPT_UI_COPY.DECRYPT_KEY_MISSING);
});

test('Leak guard: first-run (no pool) → granular codes retained even without auth', () => {
  // When the pool is not ready, the server is in first-run state. The
  // admin running the wizard needs the granular error to act on; there is
  // no secret to protect at this point.
  const req = { user: null };
  const err = new DecryptError('DECRYPT_AUTH_FAIL', 'x');
  const shaped = shapeDecryptError(err, req, /* poolReady */ false);
  assert.equal(shaped.code, 'DECRYPT_AUTH_FAIL');
  assert.equal(shaped.message, DECRYPT_UI_COPY.DECRYPT_AUTH_FAIL);
});

test('Leak guard: read-endpoint prefix threads through collapsed response', () => {
  const req = { user: null };
  const err = new DecryptError('DECRYPT_AUTH_FAIL', 'x');
  const shaped = shapeDecryptError(err, req, true, 'Read endpoint: ');
  assert.equal(shaped.code, DECRYPT_FAILED_GENERIC.code);
  assert.match(shaped.message, /^Read endpoint: /);
});

test('Read endpoint: omits passwordIsEncrypted → inherits writer flag', async () => {
  const ct = encrypt('realpass');
  lastProbePassword = null;
  const r = await postJson(port, '/api/setup/test-db', {
    host: 'stub', user: 'u', password: ct, passwordIsEncrypted: true,
    // readConfig omits passwordIsEncrypted AND password → inherits writer's flag + ciphertext
    readConfig: { host: 'replica' },
  });
  assert.equal(r.status, 200);
  // Read endpoint should also see decrypted plaintext
  assert.equal(lastProbePassword, 'realpass');
});
