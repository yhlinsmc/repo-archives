// Route-level coverage for GET /health (connectors-list health column).
// The pure derivation is covered in connector-health-lib.test.js; this exercises
// the Express handler: the requireAdminOrEditor gate (admin/editor 200, plain
// user 403), the cross-blueprint happy path (per-connector status incl.
// unbound), and the derive-failure degrade to an empty map (200, never 5xx).
const { it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../src/edge/db');
let queryImpl;
const conn = {
  async query(sql, params) { return queryImpl(sql, params); },
  release() {},
  destroy() {},
};
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: { ro: { getConnection: async () => conn }, rw: { getConnection: async () => conn } }, t: (n) => `fmb_${n}` },
};

const register = require('../../src/edge/routes/app/api-connectors/health');

let currentUser;
let server; let baseUrl;
before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { if (currentUser) req.user = currentUser; next(); });
  const router = express.Router();
  register(router);
  app.use('/edge/app/api-connectors', router);
  server = http.createServer(app);
  await new Promise((r) => server.listen(0, r));
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});
after(() => server && server.close());

beforeEach(() => {
  currentUser = { id: 'admin1', role: 'admin' };
  queryImpl = () => [];
});

async function get() {
  const res = await fetch(`${baseUrl}/edge/app/api-connectors/health`);
  return { status: res.status, body: await res.json() };
}

it('401 when the caller is unauthenticated', async () => {
  currentUser = null;
  const r = await get();
  assert.equal(r.status, 401);
});

it('403 when the caller is a plain user', async () => {
  currentUser = { id: 'u1', role: 'user' };
  const r = await get();
  assert.equal(r.status, 403);
});

it('200 when the caller is an editor (counts-only, no secrets)', async () => {
  currentUser = { id: 'e1', role: 'editor' };
  const r = await get();
  assert.equal(r.status, 200);
  assert.equal(typeof r.body.data.statuses, 'object');
});

it('200 derives per-connector status across blueprints incl. unbound', async () => {
  queryImpl = (sql) => {
    if (/FROM `fmb_api_connectors`/.test(sql)) {
      return [
        // healthy: scalar output to a real field of bp1
        { id: 'c-healthy', blueprint_id: 'bp1', request_config: '{}',
          response_config: JSON.stringify({ outputs: [{ id: 'o1', from: { mode: 'value', path: 'a' }, to: { mode: 'field', field_key: 'notes' } }] }) },
        // broken-no-op: output targets a field bp1 does not have
        { id: 'c-broken', blueprint_id: 'bp1', request_config: '{}',
          response_config: JSON.stringify({ outputs: [{ id: 'o1', from: { mode: 'value', path: 'a' }, to: { mode: 'field', field_key: 'ghost' } }] }) },
        // unverified: scalar transformer, undeclared output_keys
        { id: 'c-unverified', blueprint_id: 'bp1', request_config: '{}',
          response_config: JSON.stringify({ outputs: [], transformer_id: 'tf1' }) },
        // partial: one output resolves (notes), one does not (ghost)
        { id: 'c-partial', blueprint_id: 'bp1', request_config: '{}',
          response_config: JSON.stringify({ outputs: [{ id: 'o1', from: { mode: 'value', path: 'a' }, to: { mode: 'field', field_key: 'notes' } }, { id: 'o2', from: { mode: 'value', path: 'b' }, to: { mode: 'field', field_key: 'ghost' } }] }) },
        // unbound: no blueprint
        { id: 'c-unbound', blueprint_id: null, request_config: '{}',
          response_config: JSON.stringify({ outputs: [{ id: 'o1', from: { mode: 'value', path: 'a' }, to: { mode: 'field', field_key: 'notes' } }] }) },
      ];
    }
    if (/FROM `fmb_blueprint_fields`/.test(sql)) {
      return [
        { blueprint_id: 'bp1', field_key: 'notes' },
        { blueprint_id: 'bp1', field_key: 'parts_table' },
      ];
    }
    if (/FROM `fmb_transformers`/.test(sql)) {
      // tf1 has no declared output_keys → stays unverified
      return [{ id: 'tf1', output_keys: null }];
    }
    return [];
  };
  const r = await get();
  assert.equal(r.status, 200);
  const s = r.body.data.statuses;
  assert.equal(s['c-healthy'].status, 'healthy');
  assert.equal(s['c-healthy'].resolved_count, 1);
  assert.equal(s['c-broken'].status, 'broken-no-op');
  assert.equal(s['c-unverified'].status, 'unverified');
  assert.equal(s['c-unbound'].status, 'unbound');

  assert.equal(s['c-partial'].status, 'partial');
  assert.deepEqual(s['c-partial'].missing_keys, ['ghost']);

  // missing_keys carries the names the count summarises (field names only).
  assert.deepEqual(s['c-broken'].missing_keys, ['ghost']);
  assert.deepEqual(s['c-healthy'].missing_keys, []);
  assert.deepEqual(s['c-unbound'].missing_keys, []);
});

it('200 with an empty map when the derive throws (degrade, never 5xx)', async () => {
  queryImpl = () => { throw new Error('connection reset by peer'); };
  const r = await get();
  assert.equal(r.status, 200);
  assert.deepEqual(r.body.data.statuses, {});
  assert.equal(JSON.stringify(r.body).includes('connection reset'), false);
});

// Swap the process key between encrypt (KEY_A) and decrypt (KEY_B) — settings-crypto
// reads process.env at each call, so no module-cache flush is needed.
const KEY_A = '0'.repeat(64);
const KEY_B = '1'.repeat(64);
function withKey(key, fn) {
  const prev = process.env.SETTINGS_ENCRYPTION_KEY;
  process.env.SETTINGS_ENCRYPTION_KEY = key;
  try { return fn(); } finally {
    if (prev === undefined) delete process.env.SETTINGS_ENCRYPTION_KEY;
    else process.env.SETTINGS_ENCRYPTION_KEY = prev;
  }
}

// Seed a connector row with an encrypted auth_config so both secret_decryptable
// tests share the same query mock shape.
function makeSecretQueryImpl(encResult) {
  return (sql) => {
    if (/FROM `fmb_api_connectors`/.test(sql)) {
      return [
        {
          id: 'c1',
          blueprint_id: null, // unbound is fine — probe is independent of binding
          request_config: '{}',
          response_config: '{}',
          auth_type: 'bearer',
          auth_config: JSON.stringify(encResult),
        },
      ];
    }
    return [];
  };
}

it('/health reports secret_decryptable=false for a wrong-key connector', async () => {
  const enc = withKey(KEY_A, () =>
    require('../../src/edge/routes/app/api-connectors/serializer').encryptAuthConfig({ token: 't' }, 'bearer'));
  queryImpl = makeSecretQueryImpl(enc);
  // Set KEY_B so the route's probeDecryptable call finds the wrong key.
  process.env.SETTINGS_ENCRYPTION_KEY = KEY_B;
  let out;
  try { out = await get(); } finally { delete process.env.SETTINGS_ENCRYPTION_KEY; }
  assert.strictEqual(out.body.data.statuses.c1.secret_decryptable, false);
});

it('/health reports secret_decryptable=true for a same-key connector', async () => {
  const enc = withKey(KEY_A, () =>
    require('../../src/edge/routes/app/api-connectors/serializer').encryptAuthConfig({ token: 't' }, 'bearer'));
  queryImpl = makeSecretQueryImpl(enc);
  // Set KEY_A so the route's probeDecryptable call succeeds with the same key.
  process.env.SETTINGS_ENCRYPTION_KEY = KEY_A;
  let out;
  try { out = await get(); } finally { delete process.env.SETTINGS_ENCRYPTION_KEY; }
  assert.strictEqual(out.body.data.statuses.c1.secret_decryptable, true);
});
