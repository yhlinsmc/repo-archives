/**
 * capacity-snapshot-closure.test.js — the version-freeze / export catalogue
 * closure (spec §2.1 / §17.4). A frozen version (and a scenario export) must be
 * self-contained: it carries not just the scenario's own rows but the GLOBAL
 * catalogue rows the scenario REFERENCES, resolved by id, so the freeze is immune
 * to later global edits. addCatalogueClosure pulls those referenced global rows
 * (scenario_id IS NULL) into the snapshot's catalogue keys.
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');

// Mock edge/db BEFORE requiring _shared so its module-level `{ pool, t }` binds
// to the stub (addCatalogueClosure only uses `t` + the passed-in conn).
const dbKey = require.resolve('../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: { ro: {}, rw: {} }, t: (n) => `fmb_${n}` },
};

const { addCatalogueClosure, addGlobalConfigLayer } = require('../../src/edge/routes/app/capacity/_shared');

// A conn whose SELECT emulates `WHERE scenario_id IS NULL AND id IN (…)` by
// filtering the seeded global rows to the requested ids.
function makeConn(globalRows) {
  return {
    async query(sql, params) {
      const m = sql.match(/FROM `fmb_(cap_[a-z_]+)`/);
      const table = m && m[1];
      const rows = (table && globalRows[table]) || [];
      const wanted = new Set((params || []).map(String));
      return rows.filter((r) => wanted.has(String(r.id)));
    },
  };
}

// A conn whose SELECT emulates the unconditional `WHERE scenario_id IS NULL`
// global-layer read (addGlobalConfigLayer): returns every seeded global row for
// the queried table.
function makeGlobalLayerConn(globalRows) {
  return {
    async query(sql) {
      const m = sql.match(/FROM `fmb_(cap_[a-z_]+)`/);
      const table = m && m[1];
      return (table && globalRows[table]) || [];
    },
  };
}

describe('addCatalogueClosure (version-freeze / export self-containment)', () => {
  it('pulls the GLOBAL catalogue rows a scenario references into the snapshot', async () => {
    const tables = {
      hypervisors: [{ id: 'h1', scenario_id: 's', spec_id: 'gspec' }],
      vms: [{ id: 'v1', scenario_id: 's', sizing_profile_id: 'gprof', disk_combo_id: 'gdisk', team_id: 'gteam' }],
      databases: [{ id: 'db1', scenario_id: 's', profile_id: 'gprof', disk_combo_id: 'gdisk', team_id: 'gteam' }],
      custom_groups: [],
      hardware_specs: [], // the scenario has no LOCAL spec — the referenced one is global
      vm_profiles: [],
      disk_combos: [],
      teams: [],
    };
    const conn = makeConn({
      cap_hardware_specs: [{ id: 'gspec', scenario_id: null, name: 'G-Spec' }],
      cap_vm_profiles: [{ id: 'gprof', scenario_id: null, name: 'DB-16C' }],
      cap_disk_combos: [{ id: 'gdisk', scenario_id: null, name: 'OS only' }],
      cap_teams: [{ id: 'gteam', scenario_id: null, name: 'Payments' }],
    });

    await addCatalogueClosure(conn, tables);

    assert.deepEqual(tables.hardware_specs.map((r) => r.id), ['gspec']);
    assert.deepEqual(tables.vm_profiles.map((r) => r.id), ['gprof']);
    assert.deepEqual(tables.disk_combos.map((r) => r.id), ['gdisk']);
    assert.deepEqual(tables.teams.map((r) => r.id), ['gteam']);
  });

  it('does not duplicate a referenced row already present as a scenario-local row', async () => {
    const tables = {
      hypervisors: [{ id: 'h1', scenario_id: 's', spec_id: 'lspec' }],
      vms: [], databases: [], custom_groups: [],
      hardware_specs: [{ id: 'lspec', scenario_id: 's', name: 'Local' }], // already present
      vm_profiles: [], disk_combos: [], teams: [],
    };
    // The global table has no row with this id — a local reference must NOT be
    // treated as an unresolved global one.
    const conn = makeConn({ cap_hardware_specs: [] });

    await addCatalogueClosure(conn, tables);

    assert.deepEqual(tables.hardware_specs.map((r) => r.id), ['lspec']);
  });

  it('pulls a GLOBAL disk combo referenced ONLY via a VM profile allow-list (jsonListRefs, P2)', async () => {
    // No VM/database chooses gdisk-allow — it is only PERMITTED by a profile's
    // allowed_disk_combos JSON list. Without jsonListRefs reachability it would be
    // absent from the closure and break the allow-list on re-import.
    const tables = {
      hypervisors: [], databases: [], custom_groups: [], hardware_specs: [], teams: [],
      vms: [{ id: 'v1', scenario_id: 's', sizing_profile_id: 'gprof' }],
      vm_profiles: [], // gprof is a referenced global profile, pulled by the vm_profiles step first
      disk_combos: [],
    };
    const conn = makeConn({
      cap_vm_profiles: [{ id: 'gprof', scenario_id: null, name: 'DB-16C', allowed_disk_combos: '["gdisk-allow"]' }],
      cap_disk_combos: [{ id: 'gdisk-allow', scenario_id: null, name: 'Permitted-only' }],
    });

    await addCatalogueClosure(conn, tables);

    assert.deepEqual(tables.vm_profiles.map((r) => r.id), ['gprof']);
    assert.deepEqual(tables.disk_combos.map((r) => r.id), ['gdisk-allow'], 'the allow-list-only combo travels in the closure');
  });
});

describe('addGlobalConfigLayer (frozen version captures the effective global rules + settings)', () => {
  it('pulls ALL global rules + the global settings row into the snapshot', async () => {
    const tables = {
      rules: [{ id: 'local-rule', scenario_id: 's', type: 'keep-apart' }], // a scenario-local rule
      settings: [], // no scenario-local settings override
    };
    const conn = makeGlobalLayerConn({
      cap_rules: [
        { id: 'g-rule-b', scenario_id: null, type: 'no-oversell' },
        { id: 'g-rule-a', scenario_id: null, type: 'max-vms-per-host' },
      ],
      cap_settings: [{ id: 'g-set', scenario_id: null, mem_cpu_ratio: 20 }],
    });

    await addGlobalConfigLayer(conn, tables);

    // The scenario-local rule stays; both global template rules are appended,
    // deterministically sorted by id.
    assert.deepEqual(tables.rules.map((r) => r.id), ['local-rule', 'g-rule-a', 'g-rule-b']);
    // The global settings singleton is the scenario's fallback — captured so the
    // freeze is self-contained even without a local override.
    assert.deepEqual(tables.settings.map((r) => r.id), ['g-set']);
  });

  it('de-duplicates by id — a global row already present in the snapshot is never doubled', async () => {
    const tables = {
      rules: [{ id: 'g-rule-a', scenario_id: null }], // already present (defensive: distinct ids in practice)
      settings: [{ id: 'g-set', scenario_id: null }],
    };
    const conn = makeGlobalLayerConn({
      cap_rules: [{ id: 'g-rule-a', scenario_id: null }],
      cap_settings: [{ id: 'g-set', scenario_id: null }],
    });

    await addGlobalConfigLayer(conn, tables);

    assert.deepEqual(tables.rules.map((r) => r.id), ['g-rule-a']);
    assert.deepEqual(tables.settings.map((r) => r.id), ['g-set']);
  });

  it('a scenario-local settings override coexists with the captured global fallback row', async () => {
    const tables = {
      rules: [],
      settings: [{ id: 'local-set', scenario_id: 's' }], // the scenario's own override
    };
    const conn = makeGlobalLayerConn({
      cap_rules: [],
      cap_settings: [{ id: 'g-set', scenario_id: null }], // the global fallback singleton
    });

    await addGlobalConfigLayer(conn, tables);

    // Both are kept (distinct ids): the local override is the effective row at eval
    // time (violations.js `ORDER BY scenario_id IS NULL LIMIT 1`); the global row
    // rides along so the freeze stays self-contained.
    assert.deepEqual(tables.settings.map((r) => r.id), ['local-set', 'g-set']);
  });
});
