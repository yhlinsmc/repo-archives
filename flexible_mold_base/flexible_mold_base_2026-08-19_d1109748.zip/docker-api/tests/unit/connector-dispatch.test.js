const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const cd = require('../../src/edge/lib/connector-dispatch');
const { resolveRequest, breaker, VAR_RE } = cd;

const base = {
  method: 'GET', url: 'http://svc/v1/item/{{id}}',
  request_config: { headers: { 'X-Trace': '{{trace}}' }, body: '' },
  auth_type: 'none', auth_config: {},
};

describe('resolveRequest', () => {
  it('fills {{var}} in url + headers from inputs', () => {
    const r = resolveRequest({ ...base }, { id: '42', trace: 'abc' });
    assert.equal(r.url, 'http://svc/v1/item/42');
    assert.equal(r.headers['X-Trace'], 'abc');
  });
  it('throws MISSING_INPUT (named) on an unfilled var', () => {
    assert.throws(() => resolveRequest({ ...base }, { id: '42' }), /MISSING_INPUT: trace/);
  });
  it('injects bearer auth header from decrypted token', () => {
    const r = resolveRequest({ ...base, auth_type: 'bearer', auth_config: { token: 'sek' } }, { id: '1', trace: 't' });
    assert.equal(r.headers.Authorization, 'Bearer sek');
  });
  it('injects api_key header (custom name) and basic base64', () => {
    const k = resolveRequest({ ...base, auth_type: 'api_key', auth_config: { header: 'X-Key', value: 'v' } }, { id: '1', trace: 't' });
    assert.equal(k.headers['X-Key'], 'v');
    const b = resolveRequest({ ...base, auth_type: 'basic', auth_config: { username: 'u', password: 'p' } }, { id: '1', trace: 't' });
    assert.equal(b.headers.Authorization, 'Basic ' + Buffer.from('u:p').toString('base64'));
  });
  it('sends a body for non-GET methods', () => {
    const r = resolveRequest({ ...base, method: 'POST', request_config: { headers: {}, body: '{"q":"{{id}}"}' } }, { id: '9' });
    assert.equal(r.body, '{"q":"9"}');
  });

  it('wraps the filled body as multipart when body_type=multipart', () => {
    const r = resolveRequest({
      ...base, method: 'POST',
      request_config: {
        headers: {}, body: '{"q":"{{id}}"}',
        body_type: 'multipart', file_field: 'upload', file_name: 'q.json',
        file_content_type: 'application/json',
      },
    }, { id: '9' });
    assert.match(r.headers['Content-Type'], /^multipart\/form-data; boundary=----FlowMultipart[0-9a-f]{32}$/);
    assert.match(r.body, /name="upload"; filename="q.json"/);
    assert.match(r.body, /\{"q":"9"\}/); // {{id}} filled inside the part
  });

  it('multipart overrides a user-set content-type header (case-insensitive)', () => {
    const r = resolveRequest({
      ...base, method: 'POST',
      request_config: {
        headers: { 'content-type': 'text/plain' }, body: 'hi',
        body_type: 'multipart',
      },
    }, { id: '1', trace: 't' });
    // exactly one content-type header, and it is the multipart one
    const keys = Object.keys(r.headers).filter((k) => k.toLowerCase() === 'content-type');
    assert.equal(keys.length, 1);
    assert.match(r.headers[keys[0]], /^multipart\/form-data;/);
  });

  it('still throws MISSING_INPUT before assembling multipart', () => {
    assert.throws(() => resolveRequest({
      ...base, method: 'POST',
      request_config: { headers: {}, body: '{{id}}', body_type: 'multipart' },
    }, {}), /MISSING_INPUT: id/);
  });

  it('multipart drops a stored Content-Length header', () => {
    const r = resolveRequest({
      ...base, method: 'POST',
      request_config: {
        headers: { 'Content-Length': '7' }, body: 'hi',
        body_type: 'multipart',
      },
    }, { id: '1' }); // id fills the base URL; no other templates in this request_config
    // No content-length key (any case) — stale length must not reach the upstream
    const clKeys = Object.keys(r.headers).filter((k) => k.toLowerCase() === 'content-length');
    assert.equal(clKeys.length, 0);
    // Exactly one content-type: the generated multipart one
    const ctKeys = Object.keys(r.headers).filter((k) => k.toLowerCase() === 'content-type');
    assert.equal(ctKeys.length, 1);
    assert.match(r.headers[ctKeys[0]], /^multipart\/form-data;/);
  });

  it('multipart with a templated content-type does NOT throw MISSING_INPUT', () => {
    // If content-type is filled before being discarded, {{b}} would land in
    // sink.missing and cause a spurious MISSING_INPUT throw. Skipping it
    // before fill prevents that.
    const r = resolveRequest({
      ...base, method: 'POST',
      request_config: {
        headers: { 'Content-Type': 'x/y; boundary={{b}}' }, body: 'hi',
        body_type: 'multipart',
      },
    }, { id: '1' }); // id fills the base URL; 'b' is intentionally absent
    // Must NOT throw; Content-Type must be the multipart boundary
    assert.match(r.headers['Content-Type'], /^multipart\/form-data;/);
  });

  it('GET ignores body_type=multipart (no body, no multipart content-type)', () => {
    const r = resolveRequest({
      ...base, method: 'GET',
      request_config: { headers: {}, body: 'x', body_type: 'multipart' },
    }, { id: '1', trace: 't' });
    assert.equal(r.body, undefined);
    assert.ok(!('Content-Type' in r.headers));
  });
});

describe('per-connector circuit breaker', () => {
  it('opens after 3 failures, blocks, then half-opens after the window', () => {
    breaker._reset('c1');
    const now = 1_000_000;
    assert.equal(breaker.canDispatch('c1', now), true);
    breaker.recordFailure('c1', now); breaker.recordFailure('c1', now); breaker.recordFailure('c1', now);
    assert.equal(breaker.canDispatch('c1', now + 1000), false);   // open
    assert.equal(breaker.canDispatch('c1', now + 31_000), true);  // half-open probe allowed
  });
  it('a success closes the breaker', () => {
    breaker._reset('c2');
    const now = 2_000_000;
    breaker.recordFailure('c2', now); breaker.recordFailure('c2', now); breaker.recordFailure('c2', now);
    breaker.recordSuccess('c2');
    assert.equal(breaker.canDispatch('c2', now + 1000), true);
  });
  it('half-open admits a single probe; a concurrent second caller is turned away', () => {
    breaker._reset('cp1');
    const now = 3_000_000;
    breaker.recordFailure('cp1', now); breaker.recordFailure('cp1', now); breaker.recordFailure('cp1', now);
    const t = now + 31_000;
    assert.equal(breaker.canDispatch('cp1', t), true);   // first caller probes
    assert.equal(breaker.canDispatch('cp1', t), false);  // concurrent caller blocked
    assert.equal(breaker.canDispatch('cp1', t + 100), false); // still in flight
  });
  it('a probe slot self-heals after PROBE_TIMEOUT so a never-recorded probe cannot wedge', () => {
    breaker._reset('cp2');
    const now = 4_000_000;
    breaker.recordFailure('cp2', now); breaker.recordFailure('cp2', now); breaker.recordFailure('cp2', now);
    const t = now + 31_000;
    assert.equal(breaker.canDispatch('cp2', t), true);          // probe admitted, never records
    assert.equal(breaker.canDispatch('cp2', t + 14_999), false); // slot still held
    assert.equal(breaker.canDispatch('cp2', t + 15_000), true);  // slot expired → fresh probe
  });
  it('a probe failure re-opens the breaker (next probe waits another window)', () => {
    breaker._reset('cp3');
    const now = 5_000_000;
    breaker.recordFailure('cp3', now); breaker.recordFailure('cp3', now); breaker.recordFailure('cp3', now);
    const t = now + 31_000;
    assert.equal(breaker.canDispatch('cp3', t), true);   // probe admitted
    breaker.recordFailure('cp3', t);                     // probe fails → re-open at t
    assert.equal(breaker.canDispatch('cp3', t + 1000), false);   // open again
    assert.equal(breaker.canDispatch('cp3', t + 31_000), true);  // half-open after a fresh window
  });
});

describe('runEdgeExecute', () => {
  const resolved = { method: 'GET', url: 'http://svc.internal/x', headers: {}, body: null };

  it('records breaker success by default', async () => {
    breaker._reset('c3');
    cd.executeRequest = async () => ({ upstream_status: 200, headers: {}, body: '{}', truncated: false, duration_ms: 1 });
    const audited = [];
    await cd.runEdgeExecute({ id: 'c3' }, resolved, 'svc.internal', (k) => audited.push(k));
    assert.equal(breaker.canDispatch('c3'), true);
    assert.deepEqual(audited, ['success']);
  });

  it('with skipBreaker records no failure (breaker stays closed)', async () => {
    breaker._reset('c4');
    cd.executeRequest = async () => { const e = new Error('boom'); e.code = 'CONNECTOR_UNREACHABLE'; throw e; };
    for (let i = 0; i < 5; i++) {
      await assert.rejects(() => cd.runEdgeExecute({ id: 'c4' }, resolved, 'svc.internal', () => {}, { skipBreaker: true }));
    }
    assert.equal(breaker.canDispatch('c4'), true);
  });
});

it('VAR_RE grammar is pinned to the shared FE/BE literal', () => {
  // Must stay byte-identical to src/fmb/lib/connectors/connector-vars.ts
  // (which pins the same literal) — one grammar, two engines.
  assert.equal(VAR_RE.source, '\\{\\{\\s*([\\w.-]+)\\s*\\}\\}');
  assert.equal(VAR_RE.flags, 'g');
});
