/**
 * client-db-guard.test.js — Unit tests for the getDynamicPool trust-boundary
 * guard (docker-api/src/edge/lib/client-db-guard.js).
 *
 * Covers: mode resolution (fail-closed), the pure decision function, the
 * reject path (400 CLIENT_DB_CONFIG_REJECTED, no pool, nothing logged), and
 * the warn path (exactly one warn, client value discarded, NO secret values in
 * the log payload).
 */
const { describe, it, beforeEach, afterEach } = require('node:test');
const assert = require('node:assert/strict');

// Mock the shared logger BEFORE requiring the guard so we can capture warn
// calls and assert their payload never carries secret values.
const loggerKey = require.resolve('../../src/shared/lib/logger');
const warnCalls = [];
require.cache[loggerKey] = {
  id: loggerKey, filename: loggerKey, loaded: true,
  exports: {
    logger: {
      child() {
        return {
          warn: (obj, msg) => warnCalls.push({ obj, msg }),
          info() {}, debug() {}, error() {}, fatal() {}, trace() {},
        };
      },
    },
  },
};

const guard = require('../../src/edge/lib/client-db-guard');

function makeRes() {
  return {
    _status: undefined,
    _body: undefined,
    status(s) { this._status = s; return this; },
    json(b) { this._body = b; return this; },
  };
}

const SECRET_HOST = '10.0.0.5';
const SECRET_USER = 'attacker';
const SECRET_PW = 'SUPER_SECRET_PW_zzz';

function clientDbReq() {
  return {
    path: '/edge/app/schema/field-data-orphans',
    body: {
      some_field: 'x',
      db: { host: SECRET_HOST, port: 6379, user: SECRET_USER, password: SECRET_PW, database: 'sibling' },
    },
  };
}

beforeEach(() => {
  warnCalls.length = 0;
  delete process.env.DYNAMIC_DB_CLIENT_CONFIG;
});

afterEach(() => {
  delete process.env.DYNAMIC_DB_CLIENT_CONFIG;
});

describe('resolveClientDbMode — fail-closed', () => {
  it('defaults to reject when unset', () => {
    assert.equal(guard.resolveClientDbMode(), 'reject');
  });
  it('reject for any non-warn value (typo of warn stays safe)', () => {
    for (const v of ['reject', 'Reject', 'REJECT', 'warnn', 'wran', 'off', 'true', '1', '']) {
      process.env.DYNAMIC_DB_CLIENT_CONFIG = v;
      assert.equal(guard.resolveClientDbMode(), 'reject', `value ${JSON.stringify(v)}`);
    }
  });
  it('warn only for explicit warn (case-insensitive, trimmed)', () => {
    for (const v of ['warn', 'WARN', ' Warn ']) {
      process.env.DYNAMIC_DB_CLIENT_CONFIG = v;
      assert.equal(guard.resolveClientDbMode(), 'warn', `value ${JSON.stringify(v)}`);
    }
  });
});

describe('decideClientDb', () => {
  it('proceed when no db present', () => {
    assert.equal(guard.decideClientDb({ body: { a: 1 } }), 'proceed');
    assert.equal(guard.decideClientDb({ body: {} }), 'proceed');
    assert.equal(guard.decideClientDb({}), 'proceed');
    assert.equal(guard.decideClientDb({ body: { db: null } }), 'proceed');
  });
  it('reject (default) when db present', () => {
    assert.equal(guard.decideClientDb(clientDbReq()), 'reject');
  });
  it('discard when warn mode and db present', () => {
    process.env.DYNAMIC_DB_CLIENT_CONFIG = 'warn';
    assert.equal(guard.decideClientDb(clientDbReq()), 'discard');
  });
});

describe('enforceClientDbBoundary — reject mode (default)', () => {
  it('returns false, sends 400 CLIENT_DB_CONFIG_REJECTED, logs nothing', () => {
    const req = clientDbReq();
    const res = makeRes();
    const ok = guard.enforceClientDbBoundary(req, res);
    assert.equal(ok, false);
    assert.equal(res._status, 400);
    assert.equal(res._body.error.code, 'CLIENT_DB_CONFIG_REJECTED');
    // Generic message — must NOT echo any supplied config value.
    const serialized = JSON.stringify(res._body);
    assert.ok(!serialized.includes(SECRET_HOST));
    assert.ok(!serialized.includes(SECRET_USER));
    assert.ok(!serialized.includes(SECRET_PW));
    // Client db left in place (route never runs — 400 already sent).
    assert.equal(warnCalls.length, 0);
  });
  it('proceeds (true) with no response when no client db present', () => {
    const req = { path: '/x', body: { field: 1 } };
    const res = makeRes();
    assert.equal(guard.enforceClientDbBoundary(req, res), true);
    assert.equal(res._status, undefined);
    assert.equal(warnCalls.length, 0);
  });
});

describe('enforceClientDbBoundary — warn mode', () => {
  beforeEach(() => { process.env.DYNAMIC_DB_CLIENT_CONFIG = 'warn'; });

  it('returns true, discards client db, emits exactly one warn with NO secret values', () => {
    const req = clientDbReq();
    const res = makeRes();
    const ok = guard.enforceClientDbBoundary(req, res, '/edge/app/schema/field-data-orphans');
    assert.equal(ok, true);
    assert.equal(res._status, undefined); // no response sent — request proceeds
    // Client value discarded so downstream server-side resolution runs.
    assert.equal(req.body.db, undefined);
    // Exactly one warn.
    assert.equal(warnCalls.length, 1);
    const { obj, msg } = warnCalls[0];
    assert.equal(obj.mode, 'warn');
    assert.equal(obj.route, '/edge/app/schema/field-data-orphans');
    // SECURITY: the log payload must never carry host/user/password.
    const logged = JSON.stringify({ obj, msg });
    assert.ok(!logged.includes(SECRET_HOST), 'host leaked in warn log');
    assert.ok(!logged.includes(SECRET_USER), 'user leaked in warn log');
    assert.ok(!logged.includes(SECRET_PW), 'password leaked in warn log');
  });
});
