// docker-api/tests/unit/decrypt-error.test.js
const test = require('node:test');
const assert = require('node:assert');

const KEY_A = '0'.repeat(64); // 32 bytes hex
const KEY_B = '1'.repeat(64);

function withKey(key, fn) {
  const prev = process.env.SETTINGS_ENCRYPTION_KEY;
  process.env.SETTINGS_ENCRYPTION_KEY = key;
  // settings-crypto caches nothing across calls (reads env each call); re-require fresh anyway.
  delete require.cache[require.resolve('../../src/shared/lib/settings-crypto')];
  delete require.cache[require.resolve('../../src/shared/lib/decrypt-error')];
  try { return fn(); } finally {
    if (prev === undefined) delete process.env.SETTINGS_ENCRYPTION_KEY;
    else process.env.SETTINGS_ENCRYPTION_KEY = prev;
    delete require.cache[require.resolve('../../src/shared/lib/settings-crypto')];
    delete require.cache[require.resolve('../../src/shared/lib/decrypt-error')];
  }
}

test('decryptLeafOrThrow returns plaintext for a leaf encrypted with the same key', () => {
  withKey(KEY_A, () => {
    const { encrypt } = require('../../src/shared/lib/settings-crypto');
    const { decryptLeafOrThrow } = require('../../src/shared/lib/decrypt-error');
    const ct = encrypt('hunter2');
    assert.strictEqual(decryptLeafOrThrow(ct), 'hunter2');
  });
});

test('decryptLeafOrThrow returns a non-encrypted value unchanged', () => {
  withKey(KEY_A, () => {
    const { decryptLeafOrThrow } = require('../../src/shared/lib/decrypt-error');
    assert.strictEqual(decryptLeafOrThrow('plain-token'), 'plain-token');
  });
});

test('decryptLeafOrThrow throws DECRYPT_AUTH_FAIL when the key differs', () => {
  const ct = withKey(KEY_A, () => require('../../src/shared/lib/settings-crypto').encrypt('hunter2'));
  withKey(KEY_B, () => {
    const { decryptLeafOrThrow, DecryptError } = require('../../src/shared/lib/decrypt-error');
    assert.throws(() => decryptLeafOrThrow(ct), (e) => e instanceof DecryptError && e.code === 'DECRYPT_AUTH_FAIL');
  });
});

test('decryptLeafOrThrow throws DECRYPT_KEY_MISSING when no key is set', () => {
  const ct = withKey(KEY_A, () => require('../../src/shared/lib/settings-crypto').encrypt('hunter2'));
  withKey('', () => { // empty == treated as unset for this probe
    const { decryptLeafOrThrow, DecryptError } = require('../../src/shared/lib/decrypt-error');
    assert.throws(() => decryptLeafOrThrow(ct), (e) => e instanceof DecryptError && e.code === 'DECRYPT_KEY_MISSING');
  });
});
