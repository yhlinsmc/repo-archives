/**
 * decrypt-password.test.js — v3.2.53 PR-2 (Q4) shared helper
 *
 * Covers M1 (3 error codes) + M8 (2 negative tests: OFF+enc:v1: footgun,
 * ONPREM override-transform skip is covered in PR-3). Plus happy paths.
 */
const { test, beforeEach, afterEach } = require('node:test');
const assert = require('node:assert/strict');

const { resolvePassword, DecryptError, ENC_PREFIX } =
  require('../../src/shared/lib/decrypt-password');

const TEST_KEY = 'a'.repeat(64);
let savedKey;

beforeEach(() => {
  savedKey = process.env.SETTINGS_ENCRYPTION_KEY;
  process.env.SETTINGS_ENCRYPTION_KEY = TEST_KEY;
});

afterEach(() => {
  if (savedKey === undefined) delete process.env.SETTINGS_ENCRYPTION_KEY;
  else process.env.SETTINGS_ENCRYPTION_KEY = savedKey;
});

// ─── Happy paths ────────────────────────────────────────────────────────────

test('isEncrypted=false, plain value → returned unchanged', () => {
  assert.equal(resolvePassword('myplainpass', false), 'myplainpass');
});

test('isEncrypted=false, empty → empty', () => {
  assert.equal(resolvePassword('', false), '');
  assert.equal(resolvePassword(null, false), '');
  assert.equal(resolvePassword(undefined, false), '');
});

test('isEncrypted=true, valid ciphertext → returns plaintext', () => {
  const { encrypt } = require('../../src/shared/lib/settings-crypto');
  const ct = encrypt('mysecret');
  assert.match(ct, new RegExp(`^${ENC_PREFIX}`));
  assert.equal(resolvePassword(ct, true), 'mysecret');
});

// ─── DECRYPT_MALFORMED (M1-b) ───────────────────────────────────────────────

test('isEncrypted=true, missing enc:v1: prefix → DECRYPT_MALFORMED', () => {
  assert.throws(
    () => resolvePassword('not-a-ciphertext', true),
    (err) => err instanceof DecryptError && err.code === 'DECRYPT_MALFORMED',
  );
});

test('isEncrypted=true, enc:v1: but too few parts → DECRYPT_MALFORMED', () => {
  assert.throws(
    () => resolvePassword('enc:v1:onlyonepart', true),
    (err) => err instanceof DecryptError && err.code === 'DECRYPT_MALFORMED',
  );
});

test('isEncrypted=true, enc:v1: with empty part → DECRYPT_MALFORMED', () => {
  assert.throws(
    () => resolvePassword('enc:v1:ab::cd', true),
    (err) => err instanceof DecryptError && err.code === 'DECRYPT_MALFORMED',
  );
});

// ─── DECRYPT_KEY_MISSING (M1-a) ─────────────────────────────────────────────

test('isEncrypted=true, valid shape but no SETTINGS_ENCRYPTION_KEY → DECRYPT_KEY_MISSING', () => {
  delete process.env.SETTINGS_ENCRYPTION_KEY;
  assert.throws(
    () => resolvePassword('enc:v1:aa:bb:cc', true),
    (err) => err instanceof DecryptError && err.code === 'DECRYPT_KEY_MISSING',
  );
});

// ─── DECRYPT_AUTH_FAIL (M1-c) ───────────────────────────────────────────────

test('isEncrypted=true, wrong key → DECRYPT_AUTH_FAIL', () => {
  const { encrypt } = require('../../src/shared/lib/settings-crypto');
  const ct = encrypt('mysecret');
  // Swap to a DIFFERENT key, then try to decrypt — auth tag won't verify
  process.env.SETTINGS_ENCRYPTION_KEY = 'b'.repeat(64);
  assert.throws(
    () => resolvePassword(ct, true),
    (err) => err instanceof DecryptError && err.code === 'DECRYPT_AUTH_FAIL',
  );
});

test('isEncrypted=true, tampered ciphertext → DECRYPT_AUTH_FAIL', () => {
  const { encrypt } = require('../../src/shared/lib/settings-crypto');
  const ct = encrypt('mysecret');
  // Flip a character in the ciphertext body (last segment) to trigger auth-tag fail
  const tampered = ct.replace(/.$/, (c) => (c === 'a' ? 'b' : 'a'));
  assert.throws(
    () => resolvePassword(tampered, true),
    (err) => err instanceof DecryptError && err.code === 'DECRYPT_AUTH_FAIL',
  );
});

// ─── M8 negative: DECRYPT_LOOKS_ENCRYPTED ───────────────────────────────────

test('isEncrypted=false but value starts with enc:v1: → DECRYPT_LOOKS_ENCRYPTED', () => {
  assert.throws(
    () => resolvePassword('enc:v1:aa:bb:cc', false),
    (err) => err instanceof DecryptError && err.code === 'DECRYPT_LOOKS_ENCRYPTED',
  );
});

test('isEncrypted=false, value just contains "enc:v1:" substring (not prefix) → not rejected', () => {
  // Unlikely plaintext but must not false-positive on substring match
  assert.equal(resolvePassword('my-enc:v1:password', false), 'my-enc:v1:password');
});
