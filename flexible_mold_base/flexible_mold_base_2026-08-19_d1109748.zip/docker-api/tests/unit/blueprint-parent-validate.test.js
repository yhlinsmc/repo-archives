/**
 * blueprint-parent-validate.test.js — v3.2.99 PR-1 Bug-1
 *
 * Unit tests for validateBlueprintParent helper. Stub-based (mocks the
 * connection's query method) so we exercise the contract without booting
 * a real MariaDB.
 *
 * Verifies:
 *   - parentId null/empty → PARENT_REQUIRED (no DB hit)
 *   - row not found → PARENT_NOT_FOUND
 *   - row.node_type !== 'release' → PARENT_NOT_RELEASE with actual_type
 *   - valid Release → ok:true with parentRow
 *   - error response includes structured code (no message-string sniffing)
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');

const { validateBlueprintParent } = require('../../src/edge/lib/blueprint-serialization');

const t = (name) => `fmb_${name}`;
const TABLES = { HIERARCHY_NODES: 'hierarchy_nodes' };

function makeConn(rows = []) {
  return {
    queries: [],
    query: async function(sql, params) {
      this.queries.push({ sql, params });
      if (/SELECT id, node_type, parent_id FROM `fmb_hierarchy_nodes`/i.test(sql)) {
        return rows;
      }
      throw new Error(`Unexpected query: ${sql}`);
    },
  };
}

describe('validateBlueprintParent', () => {
  it('returns PARENT_REQUIRED when parentId is null', async () => {
    const conn = makeConn();
    const result = await validateBlueprintParent({ conn, t, TABLES, parentId: null });
    assert.equal(result.ok, false);
    assert.equal(result.code, 'PARENT_REQUIRED');
    assert.equal(conn.queries.length, 0, 'should not hit DB when parentId missing');
  });

  it('returns PARENT_REQUIRED when parentId is empty string', async () => {
    const conn = makeConn();
    const result = await validateBlueprintParent({ conn, t, TABLES, parentId: '' });
    assert.equal(result.ok, false);
    assert.equal(result.code, 'PARENT_REQUIRED');
    assert.equal(conn.queries.length, 0);
  });

  it('returns PARENT_REQUIRED when parentId is undefined', async () => {
    const conn = makeConn();
    const result = await validateBlueprintParent({ conn, t, TABLES, parentId: undefined });
    assert.equal(result.ok, false);
    assert.equal(result.code, 'PARENT_REQUIRED');
  });

  it('returns PARENT_NOT_FOUND when no row matches', async () => {
    const conn = makeConn([]);
    const result = await validateBlueprintParent({
      conn, t, TABLES, parentId: 'no-such-id',
    });
    assert.equal(result.ok, false);
    assert.equal(result.code, 'PARENT_NOT_FOUND');
    assert.equal(conn.queries.length, 1);
    assert.deepEqual(conn.queries[0].params, ['no-such-id']);
  });

  it('returns PARENT_NOT_RELEASE when node_type is generation', async () => {
    const conn = makeConn([
      { id: 'gen-1', node_type: 'generation', parent_id: null },
    ]);
    const result = await validateBlueprintParent({
      conn, t, TABLES, parentId: 'gen-1',
    });
    assert.equal(result.ok, false);
    assert.equal(result.code, 'PARENT_NOT_RELEASE');
    assert.equal(result.actual_type, 'generation');
  });

  it('returns PARENT_NOT_RELEASE when node_type is blueprint', async () => {
    const conn = makeConn([
      { id: 'bp-1', node_type: 'blueprint', parent_id: 'rel-1' },
    ]);
    const result = await validateBlueprintParent({
      conn, t, TABLES, parentId: 'bp-1',
    });
    assert.equal(result.ok, false);
    assert.equal(result.code, 'PARENT_NOT_RELEASE');
    assert.equal(result.actual_type, 'blueprint');
  });

  it('returns ok:true when node_type is release', async () => {
    const conn = makeConn([
      { id: 'rel-42', node_type: 'release', parent_id: 'gen-7' },
    ]);
    const result = await validateBlueprintParent({
      conn, t, TABLES, parentId: 'rel-42',
    });
    assert.equal(result.ok, true);
    assert.equal(result.parentRow.id, 'rel-42');
    assert.equal(result.parentRow.node_type, 'release');
    assert.equal(result.parentRow.parent_id, 'gen-7');
  });

  it('uses TABLES.HIERARCHY_NODES via t() helper', async () => {
    const conn = makeConn([{ id: 'rel-1', node_type: 'release', parent_id: null }]);
    await validateBlueprintParent({ conn, t, TABLES, parentId: 'rel-1' });
    assert.match(conn.queries[0].sql, /`fmb_hierarchy_nodes`/);
  });

  it('does not leak conn beyond a single SELECT', async () => {
    const conn = makeConn([{ id: 'rel-1', node_type: 'release', parent_id: null }]);
    await validateBlueprintParent({ conn, t, TABLES, parentId: 'rel-1' });
    assert.equal(conn.queries.length, 1, 'helper must not perform extra queries');
  });
});
