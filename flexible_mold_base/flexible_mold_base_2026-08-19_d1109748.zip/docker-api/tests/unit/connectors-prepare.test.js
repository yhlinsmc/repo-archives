const { it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const cdKey = require.resolve('../../src/edge/lib/connector-dispatch');
const cd = require('../../src/edge/lib/connector-dispatch');
let execBehavior = () => ({ upstream_status: 200, headers: { 'content-type': 'application/json' }, body: '{"v":1}', truncated: false, duration_ms: 5 });
let pinBehavior = async () => ({ address: '10.0.0.9', family: 4 });
cd.executeRequest = (...a) => Promise.resolve().then(() => execBehavior(...a));
cd.resolveAndPin = (...a) => Promise.resolve().then(() => pinBehavior(...a));
require.cache[cdKey].exports = cd;

const guardKey = require.resolve('../../src/shared/lib/ssrf-guard');
const guard = require('../../src/shared/lib/ssrf-guard');
guard.resolveAndPin = (...a) => Promise.resolve().then(() => pinBehavior(...a));
require.cache[guardKey].exports = guard;

const dbKey = require.resolve('../../src/edge/db');
let auditEvents; let connectorRow; let allowlistValue; let defaultDenyValue; let simulateMissingTimeoutCol = false;
let blueprintRow; // for callerCanManageConnector blueprint-owner tests
const conn = {
  async query(sql, params) {
    if (/FROM `fmb_hierarchy_nodes` WHERE id = \?/.test(sql)) {
      return blueprintRow ? [blueprintRow] : [];
    }
    if (/FROM `fmb_api_connectors` WHERE id = \?/.test(sql)) {
      // Simulate a no-ALTER operator DB where the timeout_ms migration was
      // skipped: a SELECT naming the column errors; the fallback (no timeout_ms)
      // succeeds. Mirrors mariadb ER_BAD_FIELD_ERROR (errno 1054).
      if (simulateMissingTimeoutCol && /timeout_ms/.test(sql)) {
        const e = new Error("Unknown column 'timeout_ms'"); e.code = 'ER_BAD_FIELD_ERROR'; e.errno = 1054; throw e;
      }
      if (!(params[0] === 'live' && connectorRow)) return [];
      // Reflect the projection: the fallback SELECT omits timeout_ms / status, so
      // the row the dispatch sees lacks them (timeout → default, status → approved).
      const row = { ...connectorRow };
      if (!/timeout_ms/.test(sql)) delete row.timeout_ms;
      if (!/`status`/.test(sql)) delete row.status;
      return [row];
    }
    if (/FROM `fmb_system_settings` WHERE `key` = \?/.test(sql)) {
      if (params[0] === 'connector_egress_default_deny') return defaultDenyValue == null ? [] : [{ value: defaultDenyValue }];
      return allowlistValue == null ? [] : [{ value: allowlistValue }];
    }
    if (/INSERT INTO `fmb_feature_audit`/.test(sql)) { auditEvents.push({ event: params[1], meta: JSON.parse(params[3]) }); return { affectedRows: 1 }; }
    if (/information_schema\.COLUMNS/i.test(sql)) return [];
    if (/SELECT DATABASE\(\)/.test(sql)) return [{ db: 'testdb' }];
    return [];
  },
  release() {},
};
require.cache[dbKey] = { id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: { ro: { getConnection: async () => conn }, rw: { getConnection: async () => conn } }, t: (n) => `fmb_${n}` } };

const router = require('../../src/edge/routes/internal/connectors');

let currentRole = 'user';
let server; let baseUrl;
before(async () => {
  const app = express(); app.use(express.json());
  app.use((req, _res, next) => { req.user = { id: 'u1', role: currentRole }; next(); });
  app.use('/edge/internal/connectors', router);
  server = http.createServer(app); await new Promise((r) => server.listen(0, r));
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});
after(() => server && server.close());
beforeEach(() => {
  auditEvents = []; cd.breaker._reset('live');
  simulateMissingTimeoutCol = false;
  router.__resetAdditiveColsLatch(); // module-level latch must not leak across tests
  connectorRow = { id: 'live', name: 'm', is_active: 1, auth_type: 'bearer', auth_config: JSON.stringify({ token: 'SEKRET' }),
    request_config: JSON.stringify({ headers: {} }), response_config: JSON.stringify({}), dispatch_origin: 'infra', method: 'GET', url: 'http://svc.internal/echo' };
  currentRole = 'user';
  allowlistValue = null; // empty global allow-list → allow-all (existing tests unaffected)
  defaultDenyValue = null; // deny-by-default off → empty list stays allow-all
  blueprintRow = null;
  execBehavior = () => ({ upstream_status: 200, headers: { 'content-type': 'application/json' }, body: '{"v":1}', truncated: false, duration_ms: 5 });
  pinBehavior = async () => ({ address: '10.0.0.9', family: 4 });
});

async function post(path, body) {
  const res = await fetch(`${baseUrl}${path}`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) });
  return { status: res.status, body: await res.json() };
}

it('infra-origin returns mode:infra + prepared (with pinned ip) and writes pending', async () => {
  const r = await post('/edge/internal/connectors/prepare', { connector_id: 'live', inputs: {} });
  assert.equal(r.status, 200);
  assert.equal(r.body.data.mode, 'infra');
  assert.equal(r.body.data.prepared.pinned_ip, '10.0.0.9');
  assert.equal(r.body.data.prepared.headers.Authorization, 'Bearer SEKRET');
  assert.ok(r.body.data.dispatch_id);
  assert.deepEqual(auditEvents.map((e) => e.event), ['connector.fetch.pending']);
  assert.equal(JSON.stringify(auditEvents[0].meta).includes('SEKRET'), false);
});

it('edge-origin executes inline and returns mode:edge envelope + full audit', async () => {
  connectorRow.dispatch_origin = 'edge';
  const r = await post('/edge/internal/connectors/prepare', { connector_id: 'live', inputs: {} });
  assert.equal(r.status, 200);
  assert.equal(r.body.data.mode, 'edge');
  assert.equal(r.body.data.envelope.upstream_status, 200);
  assert.deepEqual(auditEvents.map((e) => e.event), ['connector.fetch.pending', 'connector.fetch.success']);
});

it('infra-origin returns the connector timeout_ms in prepared, defaulting to 10s', async () => {
  // default (no per-connector value) → system default 10s
  let r = await post('/edge/internal/connectors/prepare', { connector_id: 'live', inputs: {} });
  assert.equal(r.body.data.prepared.timeout_ms, 10000);
  // explicit per-connector value flows through verbatim
  connectorRow.timeout_ms = 30000;
  r = await post('/edge/internal/connectors/prepare', { connector_id: 'live', inputs: {} });
  assert.equal(r.body.data.prepared.timeout_ms, 30000);
});

it('self-heals the additive columns after a live migration (no pod restart)', async () => {
  connectorRow.timeout_ms = 30000;

  // 1. no-ALTER DB: the full SELECT (naming timeout_ms) errors → fallback drops
  //    the column and the latch degrades to the default timeout.
  simulateMissingTimeoutCol = true;
  router.__setClock(() => 1_000_000);
  let r = await post('/edge/internal/connectors/prepare', { connector_id: 'live', inputs: {} });
  assert.equal(r.body.data.prepared.timeout_ms, 10000, 'degraded → default while the column is absent');

  // 2. operator runs the migration on the live pod (column present again). Within
  //    the re-probe TTL the latch is still degraded, so still the default.
  simulateMissingTimeoutCol = false;
  router.__setClock(() => 1_000_000 + router.__additiveReprobeTtlMs - 1);
  r = await post('/edge/internal/connectors/prepare', { connector_id: 'live', inputs: {} });
  assert.equal(r.body.data.prepared.timeout_ms, 10000, 'still degraded before the TTL elapses');

  // 3. after the TTL the full SELECT is retried, succeeds, and the per-connector
  //    timeout is restored — no restart needed.
  router.__setClock(() => 1_000_000 + router.__additiveReprobeTtlMs);
  r = await post('/edge/internal/connectors/prepare', { connector_id: 'live', inputs: {} });
  assert.equal(r.body.data.prepared.timeout_ms, 30000, 'self-healed after the re-probe TTL');
});

it('edge-origin passes the connector timeout_ms to executeRequest', async () => {
  connectorRow.dispatch_origin = 'edge';
  connectorRow.timeout_ms = 45000;
  let seenOpts = null;
  execBehavior = (_resolved, opts) => {
    seenOpts = opts;
    return { upstream_status: 200, headers: {}, body: '{}', truncated: false, duration_ms: 1 };
  };
  const r = await post('/edge/internal/connectors/prepare', { connector_id: 'live', inputs: {} });
  assert.equal(r.status, 200);
  assert.equal(seenOpts.timeoutMs, 45000);
});

it('404 when connector missing, 409 when inactive', async () => {
  let r = await post('/edge/internal/connectors/prepare', { connector_id: 'nope', inputs: {} });
  assert.equal(r.status, 404);
  connectorRow.is_active = 0;
  r = await post('/edge/internal/connectors/prepare', { connector_id: 'live', inputs: {} });
  assert.equal(r.status, 409);
});

it('infra-origin maps a blocked pin to 422 SSRF_BLOCKED + failed audit', async () => {
  pinBehavior = async () => { const e = new Error('destination blocked'); e.code = 'SSRF_BLOCKED'; throw e; };
  const r = await post('/edge/internal/connectors/prepare', { connector_id: 'live', inputs: {} });
  assert.equal(r.status, 422);
  assert.equal(r.body.error.code, 'SSRF_BLOCKED');
  assert.deepEqual(auditEvents.map((e) => e.event), ['connector.fetch.pending', 'connector.fetch.failed']);
  pinBehavior = async () => ({ address: '10.0.0.9', family: 4 });
});

// Fix A: unknown dispatch_origin must be rejected before the pending audit row
// is written — a corrupt enum value must never yield a prepared-headers response.
it('501 when dispatch_origin is an unknown value', async () => {
  connectorRow.dispatch_origin = 'weird';
  const r = await post('/edge/internal/connectors/prepare', { connector_id: 'live', inputs: {} });
  assert.equal(r.status, 501);
  assert.equal(auditEvents.length, 0);
});

// Global egress allow-list (v3.2.261): /prepare is the sole dispatch gate.
it('422 EGRESS_BLOCKED when the global allow-list excludes the host (failed audit, no pending)', async () => {
  allowlistValue = JSON.stringify(['api.allowed.com']); // connectorRow host = svc.internal → off-list
  const r = await post('/edge/internal/connectors/prepare', { connector_id: 'live', inputs: {} });
  assert.equal(r.status, 422);
  assert.equal(r.body.error.code, 'EGRESS_BLOCKED');
  assert.deepEqual(auditEvents.map((e) => e.event), ['connector.fetch.failed']);
});

it('dispatches normally when the host is on the global allow-list', async () => {
  allowlistValue = JSON.stringify(['svc.internal']);
  const r = await post('/edge/internal/connectors/prepare', { connector_id: 'live', inputs: {} });
  assert.equal(r.status, 200);
  assert.equal(r.body.data.mode, 'infra');
});

it('a wildcard entry on the global allow-list permits a subdomain dispatch', async () => {
  connectorRow.url = 'http://api.svc.internal/echo';
  allowlistValue = JSON.stringify(['*.svc.internal']);
  const r = await post('/edge/internal/connectors/prepare', { connector_id: 'live', inputs: {} });
  assert.equal(r.status, 200);
});

it('fails CLOSED (500) when the global allow-list value is malformed — never silent allow-all', async () => {
  allowlistValue = 'not-json'; // present but corrupt → loadHostAllowlist throws
  const r = await post('/edge/internal/connectors/prepare', { connector_id: 'live', inputs: {} });
  assert.equal(r.status, 500);
});

// Deny-by-default (Q6 alt): an EMPTY allow-list blocks dispatch only when the
// admin flag is on. The flag affects the dispatch gate alone (save/import/clone
// keep allow-all so editors can still author).
it('422 EGRESS_BLOCKED when deny-by-default is on and the allow-list is empty', async () => {
  allowlistValue = null; // empty
  defaultDenyValue = JSON.stringify(true);
  const r = await post('/edge/internal/connectors/prepare', { connector_id: 'live', inputs: {} });
  assert.equal(r.status, 422);
  assert.equal(r.body.error.code, 'EGRESS_BLOCKED');
  assert.deepEqual(auditEvents.map((e) => e.event), ['connector.fetch.failed']);
  assert.equal(auditEvents[0].meta.reason, 'default-deny'); // the deny branch, not a host/path miss
});

it('an empty allow-list still allows dispatch when deny-by-default is off', async () => {
  allowlistValue = null;
  defaultDenyValue = JSON.stringify(false);
  const r = await post('/edge/internal/connectors/prepare', { connector_id: 'live', inputs: {} });
  assert.equal(r.status, 200);
});

// Fix C: missing connector_id must be caught before opening a DB connection.
it('400 when connector_id missing', async () => {
  const r = await post('/edge/internal/connectors/prepare', { inputs: {} });
  assert.equal(r.status, 400);
  assert.equal(r.body.error.code, 'BAD_REQUEST');
});

// Edge-origin proxy cases migrated from the deleted dispatch.js route tests.
// dispatch_origin='edge' exercises the inline-execute path in /prepare.

it('edge-origin proxies an upstream 404 as a 200 envelope (edge is a proxy)', async () => {
  connectorRow.dispatch_origin = 'edge';
  execBehavior = () => ({ upstream_status: 404, headers: { 'content-type': 'application/json' }, body: '{}', truncated: false, duration_ms: 3 });
  const r = await post('/edge/internal/connectors/prepare', { connector_id: 'live', inputs: {} });
  assert.equal(r.status, 200);
  assert.equal(r.body.data.envelope.upstream_status, 404);
  assert.deepEqual(auditEvents.map((e) => e.event), ['connector.fetch.pending', 'connector.fetch.success']);
});

it('edge-origin proxies an upstream 500 as a 200 envelope', async () => {
  connectorRow.dispatch_origin = 'edge';
  execBehavior = () => ({ upstream_status: 500, headers: {}, body: 'err', truncated: false, duration_ms: 3 });
  const r = await post('/edge/internal/connectors/prepare', { connector_id: 'live', inputs: {} });
  assert.equal(r.status, 200);
  assert.equal(r.body.data.envelope.upstream_status, 500);
});

it('edge-origin maps a guard/transport failure to its status + failed audit', async () => {
  connectorRow.dispatch_origin = 'edge';
  execBehavior = () => { const e = new Error('timeout'); e.code = 'CONNECTOR_TIMEOUT'; throw e; };
  const r = await post('/edge/internal/connectors/prepare', { connector_id: 'live', inputs: {} });
  assert.equal(r.status, 504);
  assert.equal(r.body.error.code, 'CONNECTOR_TIMEOUT');
  assert.deepEqual(auditEvents.map((e) => e.event), ['connector.fetch.pending', 'connector.fetch.failed']);
});

it('400s a missing template input', async () => {
  connectorRow.url = 'http://svc.internal/item/{{id}}';
  const r = await post('/edge/internal/connectors/prepare', { connector_id: 'live', inputs: {} });
  assert.equal(r.status, 400);
  assert.equal(r.body.error.code, 'MISSING_INPUT');
});

it('opens the breaker after repeated failures → 503', async () => {
  connectorRow.dispatch_origin = 'edge';
  execBehavior = () => { const e = new Error('boom'); e.code = 'CONNECTOR_UNREACHABLE'; throw e; };
  await post('/edge/internal/connectors/prepare', { connector_id: 'live', inputs: {} });
  await post('/edge/internal/connectors/prepare', { connector_id: 'live', inputs: {} });
  await post('/edge/internal/connectors/prepare', { connector_id: 'live', inputs: {} });
  const r = await post('/edge/internal/connectors/prepare', { connector_id: 'live', inputs: {} });
  assert.equal(r.status, 503);
  assert.equal(r.body.error.code, 'CONNECTOR_CIRCUIT_OPEN');
});

it('admin test=true dispatches an inactive connector (no 409) and tags connector.test.*', async () => {
  currentRole = 'admin';
  connectorRow.is_active = 0;
  connectorRow.dispatch_origin = 'edge';
  const r = await post('/edge/internal/connectors/prepare', { connector_id: 'live', inputs: {}, test: true });
  assert.equal(r.status, 200);
  assert.equal(r.body.data.mode, 'edge');
  assert.deepEqual(auditEvents.map((e) => e.event), ['connector.test.pending', 'connector.test.success']);
});

it('admin test=true bypasses an open breaker', async () => {
  currentRole = 'admin';
  connectorRow.dispatch_origin = 'edge';
  execBehavior = () => { const e = new Error('boom'); e.code = 'CONNECTOR_UNREACHABLE'; throw e; };
  for (let i = 0; i < 3; i++) await post('/edge/internal/connectors/prepare', { connector_id: 'live', inputs: {} });
  let r = await post('/edge/internal/connectors/prepare', { connector_id: 'live', inputs: {} });
  assert.equal(r.status, 503);
  execBehavior = () => ({ upstream_status: 200, headers: {}, body: '{}', truncated: false, duration_ms: 2 });
  r = await post('/edge/internal/connectors/prepare', { connector_id: 'live', inputs: {}, test: true });
  assert.equal(r.status, 200);
  assert.equal(r.body.data.envelope.upstream_status, 200);
});

it('admin test=true infra-origin echoes test:true in the response', async () => {
  currentRole = 'admin';
  const r = await post('/edge/internal/connectors/prepare', { connector_id: 'live', inputs: {}, test: true });
  assert.equal(r.status, 200);
  assert.equal(r.body.data.mode, 'infra');
  assert.equal(r.body.data.test, true);
  assert.deepEqual(auditEvents.map((e) => e.event), ['connector.test.pending']);
});

it('non-admin test=true is IGNORED — inactive still 409', async () => {
  currentRole = 'user';
  connectorRow.is_active = 0;
  const r = await post('/edge/internal/connectors/prepare', { connector_id: 'live', inputs: {}, test: true });
  assert.equal(r.status, 409);
});

it('/result with test=true writes connector.test.* and skips the breaker', async () => {
  currentRole = 'admin';
  cd.breaker._reset('live');
  const r = await post('/edge/internal/connectors/result', { dispatch_id: 'd-test-1', connector_id: 'live', success: false, error_code: 'CONNECTOR_TIMEOUT', host: 'svc.internal', method: 'GET', test: true });
  assert.equal(r.status, 200);
  assert.deepEqual(auditEvents.map((e) => e.event), ['connector.test.failed']);
  assert.equal(cd.breaker.canDispatch('live'), true);
});

// Swap the process key between encrypt (KEY_A) and decrypt (KEY_B) so the
// stored ciphertext is unreadable at dispatch time without touching module
// caches — settings-crypto reads process.env at each call site.
const KEY_A = '0'.repeat(64);
const KEY_B = '1'.repeat(64);
function withKey(key, fn) {
  const prev = process.env.SETTINGS_ENCRYPTION_KEY;
  process.env.SETTINGS_ENCRYPTION_KEY = key;
  try { return fn(); } finally {
    if (prev === undefined) delete process.env.SETTINGS_ENCRYPTION_KEY;
    else process.env.SETTINGS_ENCRYPTION_KEY = prev;
  }
}

it('/prepare returns 422 DECRYPT_AUTH_FAIL when the secret was encrypted with another key', async () => {
  // Arrange: encrypt with KEY_A so the stored ciphertext is unreadable under KEY_B.
  const enc = withKey(KEY_A, () =>
    require('../../src/edge/routes/app/api-connectors/serializer').encryptAuthConfig({ token: 't' }, 'bearer'));
  connectorRow.auth_type = 'bearer';
  connectorRow.auth_config = JSON.stringify(enc);
  connectorRow.is_active = 1;
  connectorRow.dispatch_origin = 'edge';

  // Set KEY_B so decryptRow at dispatch time fails with DECRYPT_AUTH_FAIL.
  process.env.SETTINGS_ENCRYPTION_KEY = KEY_B;
  let r;
  try {
    r = await post('/edge/internal/connectors/prepare', { connector_id: 'live', inputs: {} });
  } finally {
    delete process.env.SETTINGS_ENCRYPTION_KEY;
  }

  assert.strictEqual(r.status, 422);
  assert.strictEqual(r.body.error.code, 'DECRYPT_AUTH_FAIL');
  assert.match(r.body.error.message, /different SETTINGS_ENCRYPTION_KEY/);
});

// SECURITY: gates must run before decryptRow so an inactive or circuit-open
// connector whose secret was encrypted with a mismatched key returns the
// gate status (409/503), not a decrypt error (422), and credentials are
// never inspected for a connector that should be rejected outright.
it('inactive connector with a bad-key secret returns 409, not 422 (gate wins over decrypt)', async () => {
  // Arrange: encrypt with KEY_A, set KEY_B at dispatch time → decryptRow would
  // throw DECRYPT_AUTH_FAIL if it ran. But is_active=0 must gate first → 409.
  const enc = withKey(KEY_A, () =>
    require('../../src/edge/routes/app/api-connectors/serializer').encryptAuthConfig({ token: 't' }, 'bearer'));
  connectorRow.auth_type = 'bearer';
  connectorRow.auth_config = JSON.stringify(enc);
  connectorRow.is_active = 0; // inactive — gate must fire before decrypt
  connectorRow.dispatch_origin = 'edge';

  process.env.SETTINGS_ENCRYPTION_KEY = KEY_B;
  let r;
  try {
    r = await post('/edge/internal/connectors/prepare', { connector_id: 'live', inputs: {} });
  } finally {
    delete process.env.SETTINGS_ENCRYPTION_KEY;
  }

  // Gate (409) must win — decryptRow must not have run.
  assert.strictEqual(r.status, 409);
  assert.strictEqual(r.body.error.code, 'CONNECTOR_INACTIVE');
});
// Note: driving the breaker to OPEN and combining it with a bad-key secret is
// omitted because the breaker-open path (503) requires 3 prior failures in the
// same test run — the existing 'opens the breaker after repeated failures → 503'
// test already covers the 503 path. The inactive-409 test above is sufficient to
// pin that gates run before decryptRow.

// P2-2 (Codex): on a no-ALTER operator DB where the timeout_ms migration was
// skipped, dispatch must degrade to the default instead of 500'ing with
// ER_BAD_FIELD_ERROR. Placed LAST: the tolerant loader caches the
// column-missing state per process, so running this before the timeout
// assertions above would make them read the default.
it('degrades to the default when the timeout_ms column is absent (recover-policy migration skipped)', async () => {
  simulateMissingTimeoutCol = true;
  try {
    const r = await post('/edge/internal/connectors/prepare', { connector_id: 'live', inputs: {} });
    assert.equal(r.status, 200, 'dispatch still succeeds without the column');
    assert.equal(r.body.data.prepared.timeout_ms, 10000, 'falls back to the system default');
  } finally {
    simulateMissingTimeoutCol = false;
  }
});

// ── approval gate (status) ──────────────────────────────────────────
it('422 CONNECTOR_NOT_APPROVED when status is pending (no pending audit)', async () => {
  connectorRow.status = 'pending';
  const r = await post('/edge/internal/connectors/prepare', { connector_id: 'live', inputs: {} });
  assert.equal(r.status, 422);
  assert.equal(r.body.error.code, 'CONNECTOR_NOT_APPROVED');
  assert.deepEqual(auditEvents.map((e) => e.event), [], 'an unapproved connector writes no audit row');
});

it('422 CONNECTOR_NOT_APPROVED when status is rejected', async () => {
  connectorRow.status = 'rejected';
  const r = await post('/edge/internal/connectors/prepare', { connector_id: 'live', inputs: {} });
  assert.equal(r.status, 422);
  assert.equal(r.body.error.code, 'CONNECTOR_NOT_APPROVED');
});

it('dispatches when status is approved', async () => {
  connectorRow.status = 'approved';
  const r = await post('/edge/internal/connectors/prepare', { connector_id: 'live', inputs: {} });
  assert.equal(r.status, 200);
  assert.equal(r.body.data.mode, 'infra');
});

it('dispatches when status is NULL (grandfathered = approved)', async () => {
  connectorRow.status = null;
  const r = await post('/edge/internal/connectors/prepare', { connector_id: 'live', inputs: {} });
  assert.equal(r.status, 200);
});

it('re-arms the approval gate after the status column reappears (self-heal)', async () => {
  connectorRow.status = 'pending';
  // Degraded: the full SELECT errors on the missing column → fallback drops
  // status → undefined → treated as approved → gate OFF, the pending connector
  // dispatches. This is the degraded-blast-radius the self-heal bounds in time.
  simulateMissingTimeoutCol = true;
  router.__setClock(() => 2_000_000);
  let r = await post('/edge/internal/connectors/prepare', { connector_id: 'live', inputs: {} });
  assert.equal(r.status, 200, 'degraded → approval gate off, a pending connector dispatches');
  // Migration applied on the live pod; after the TTL the gate re-arms and blocks
  // the pending connector again — no restart.
  simulateMissingTimeoutCol = false;
  router.__setClock(() => 2_000_000 + router.__additiveReprobeTtlMs);
  r = await post('/edge/internal/connectors/prepare', { connector_id: 'live', inputs: {} });
  assert.equal(r.status, 422);
  assert.equal(r.body.error.code, 'CONNECTOR_NOT_APPROVED', 'self-healed → gate blocks pending again');
});

it('admin test-dispatch bypasses the approval gate (verify before approving)', async () => {
  connectorRow.status = 'pending';
  currentRole = 'admin';
  const r = await post('/edge/internal/connectors/prepare', { connector_id: 'live', inputs: {}, test: true });
  assert.equal(r.status, 200);
});

// ── author-test deadlock fix (connectors) ────────────────────────────────────
// An editor who authored a pending connector was blocked: they could not test it
// until an admin approved it, but admins would not approve an untested connector.
// Fix: effectiveTest = test===true && callerCanManageConnector, where
//   callerCanManageConnector = isAdmin
//     || connector.owner_id === caller
//     || blueprintOwner ∈ {null, caller}
// Egress + SSRF still fire regardless of effectiveTest (invariant 2).

// (a) Editor owns the pending connector → approval gate passes, reaches execute.
// RED before fix: non-admin effectiveTest=false → approval gate fires → 422.
it('editor with test:true on own pending connector bypasses the approval gate', async () => {
  connectorRow.status = 'pending';
  connectorRow.owner_id = 'u1'; // caller's id
  connectorRow.blueprint_id = null;
  connectorRow.dispatch_origin = 'edge';
  currentRole = 'editor';
  const r = await post('/edge/internal/connectors/prepare', { connector_id: 'live', inputs: {}, test: true });
  assert.notEqual(r.body.error?.code, 'CONNECTOR_NOT_APPROVED', `approval gate must pass for connector owner; got: ${JSON.stringify(r.body)}`);
  assert.equal(r.status, 200, `expected 200 got ${r.status}: ${JSON.stringify(r.body)}`);
  assert.equal(r.body.data.test, true);
});

// (b) SECURITY: Editor owns the bound blueprint but does NOT own the connector →
// 422 CONNECTOR_NOT_APPROVED. Blueprint-ownership alone is insufficient — the CRUD
// edit-gate requires BOTH: own the row AND own/share the blueprint (conjunction).
// RED against old OR predicate: u1 owns bp1 → old code granted authority → 200.
// Correct conjunction: ownerOk=false (connector owned by other-editor) → denied.
// This is the Codex P1 over-grant case.
it('editor owning bound blueprint but NOT the connector → 422 (blueprint ownership alone insufficient)', async () => {
  connectorRow.status = 'pending';
  connectorRow.owner_id = 'other-editor'; // NOT the caller
  connectorRow.blueprint_id = 'bp1';
  connectorRow.dispatch_origin = 'edge';
  blueprintRow = { owner_id: 'u1' }; // caller owns the blueprint (but NOT the connector row)
  currentRole = 'editor';
  const r = await post('/edge/internal/connectors/prepare', { connector_id: 'live', inputs: {}, test: true });
  assert.equal(r.status, 422, `expected 422 got ${r.status}: ${JSON.stringify(r.body)}`);
  assert.equal(r.body.error.code, 'CONNECTOR_NOT_APPROVED');
});

// (c) Foreign pending connector (neither connector nor blueprint owned by caller) → 422.
it('editor with test:true on foreign pending connector → 422 CONNECTOR_NOT_APPROVED', async () => {
  connectorRow.status = 'pending';
  connectorRow.owner_id = 'other-editor'; // NOT caller
  connectorRow.blueprint_id = 'bp2';
  blueprintRow = { owner_id: 'other-editor' }; // also NOT caller
  currentRole = 'editor';
  const r = await post('/edge/internal/connectors/prepare', { connector_id: 'live', inputs: {}, test: true });
  assert.equal(r.status, 422);
  assert.equal(r.body.error.code, 'CONNECTOR_NOT_APPROVED');
});

// (d) user-role with test:true, owns neither connector nor blueprint → flag inert.
it('user-role with test:true on pending connector → 422 CONNECTOR_NOT_APPROVED (flag inert)', async () => {
  connectorRow.status = 'pending';
  connectorRow.owner_id = 'other';
  connectorRow.blueprint_id = 'bp3';
  blueprintRow = { owner_id: 'other' };
  currentRole = 'user';
  const r = await post('/edge/internal/connectors/prepare', { connector_id: 'live', inputs: {}, test: true });
  assert.equal(r.status, 422);
  assert.equal(r.body.error.code, 'CONNECTOR_NOT_APPROVED');
});

// (b2) Correct positive: editor owns connector AND blueprint is shared (null owner) → passes.
// Matrix case: self | null(shared bp). ownerOk=true (u1), bpOwnerOk=true (null=shared).
it('editor owning connector with shared (null-owner) blueprint → bypasses approval gate', async () => {
  connectorRow.status = 'pending';
  connectorRow.owner_id = 'u1'; // caller owns the connector
  connectorRow.blueprint_id = 'bp-shared';
  connectorRow.dispatch_origin = 'edge';
  blueprintRow = { owner_id: null }; // shared blueprint — both conditions met
  currentRole = 'editor';
  const r = await post('/edge/internal/connectors/prepare', { connector_id: 'live', inputs: {}, test: true });
  assert.notEqual(r.body.error?.code, 'CONNECTOR_NOT_APPROVED', `must pass; got: ${JSON.stringify(r.body)}`);
  assert.equal(r.status, 200, `expected 200 got ${r.status}: ${JSON.stringify(r.body)}`);
  assert.equal(r.body.data.test, true);
});

// (b3) Correct positive: admin-created connector (null owner_id) + editor owns blueprint → passes.
// Matrix case: null(admin-created) | self. ownerOk=true (null), bpOwnerOk=true (u1=caller).
it('admin-created connector (null owner_id) and editor owns blueprint → bypasses approval gate', async () => {
  connectorRow.status = 'pending';
  connectorRow.owner_id = null; // admin-created, no row owner
  connectorRow.blueprint_id = 'bp-admin-created';
  connectorRow.dispatch_origin = 'edge';
  blueprintRow = { owner_id: 'u1' }; // editor owns the blueprint
  currentRole = 'editor';
  const r = await post('/edge/internal/connectors/prepare', { connector_id: 'live', inputs: {}, test: true });
  assert.notEqual(r.body.error?.code, 'CONNECTOR_NOT_APPROVED', `must pass; got: ${JSON.stringify(r.body)}`);
  assert.equal(r.status, 200, `expected 200 got ${r.status}: ${JSON.stringify(r.body)}`);
  assert.equal(r.body.data.test, true);
});

// (b4) Editor owns connector but blueprint is owned by another editor → 422.
// Matrix case: self | otherEditor. ownerOk=true but bpOwnerOk=false → denied.
it('editor owns connector but blueprint owned by another editor → 422 CONNECTOR_NOT_APPROVED', async () => {
  connectorRow.status = 'pending';
  connectorRow.owner_id = 'u1'; // caller owns the connector
  connectorRow.blueprint_id = 'bp-other';
  connectorRow.dispatch_origin = 'edge';
  blueprintRow = { owner_id: 'other-editor' }; // blueprint owned by someone else
  currentRole = 'editor';
  const r = await post('/edge/internal/connectors/prepare', { connector_id: 'live', inputs: {}, test: true });
  assert.equal(r.status, 422, `expected 422 got ${r.status}: ${JSON.stringify(r.body)}`);
  assert.equal(r.body.error.code, 'CONNECTOR_NOT_APPROVED');
});

// Invariant 2: egress allow-list still blocks even when the editor owns the
// pending connector (effectiveTest=true does not bypass the egress gate).
it('egress BLOCKS even when editor owns pending connector (effectiveTest does not bypass egress)', async () => {
  connectorRow.status = 'pending';
  connectorRow.owner_id = 'u1';
  connectorRow.dispatch_origin = 'infra';
  currentRole = 'editor';
  allowlistValue = JSON.stringify(['api.allowed.com']); // host=svc.internal → off-list
  const r = await post('/edge/internal/connectors/prepare', { connector_id: 'live', inputs: {}, test: true });
  assert.equal(r.status, 422);
  assert.equal(r.body.error.code, 'EGRESS_BLOCKED');
});

// Role floor (defense-in-depth): a user-role caller who somehow OWNS the pending
// connector must still be denied — the ownership branches are gated to role 'editor'
// (admin short-circuits). RED without the role floor: owner_id match would flip
// effectiveTest true → 200; with the floor it stays false → 422.
it('user-role OWNER on pending connector → still 422 (role floor denies the should-never-exist owner)', async () => {
  connectorRow.status = 'pending';
  connectorRow.owner_id = 'u1'; // caller's own id
  connectorRow.blueprint_id = null;
  currentRole = 'user';
  const r = await post('/edge/internal/connectors/prepare', { connector_id: 'live', inputs: {}, test: true });
  assert.equal(r.status, 422);
  assert.equal(r.body.error.code, 'CONNECTOR_NOT_APPROVED');
});
