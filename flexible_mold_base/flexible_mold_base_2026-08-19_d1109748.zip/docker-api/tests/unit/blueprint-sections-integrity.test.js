/**
 * blueprint-sections-integrity.test.js
 *
 * PR-A color-groups integrity batch, blueprint_sections surface:
 *   - Item 3: generic CRUD POST/PUT matrix_copy enum validation
 *     (INVALID_COLUMN_VALUE) — accepts {'', 'enabled', 'disabled', null}.
 *   - Item 5: generic CRUD POST section_key slug validation, and /replace
 *     slug validation enforced only on genuinely new keys.
 *   - Item 2: POST /blueprint_sections/delete-with-reassign transactional
 *     delete + field reassign (move) / field+option delete (delete).
 *
 * Spy-pool HTTP harness mirrors blueprint-output-order-replace.test.js.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const { answerParentIdProbe } = require('../helpers/parent-id-probe');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../src/edge/db');

let conn;

function makeConn(scripts = []) {
  const queries = [];
  const events = [];
  return {
    queries,
    events,
    async query(sql, params) {
      queries.push({ sql, params });
      for (const [matcher, response] of scripts) {
        if (matcher.test(sql)) {
          return typeof response === 'function' ? response(sql, params) : response;
        }
      }
      if (/SELECT DATABASE\(\)/i.test(sql)) return [{ db: 'testdb' }];
      // The identity question the destructive gates now ask the ENGINE
      // (write-value.js `sameStoredValue`): are these two spellings one stored
      // value? Answered here the way the column's collation answers it — case
      // folded, trailing space padded — so this double cannot disagree with the
      // database about whether a target names the row being deleted. The
      // instrument that settles it for real is
      // tests/integration/destructive-gates-real-db.test.js.
      if (/CHARACTER_SET_NAME AS cs/.test(sql)) {
        return [{ cs: 'utf8mb4', co: 'utf8mb4_general_ci' }];
      }
      if (/<=>/.test(sql) && / AS same/.test(sql)) {
        const fold = (v) => String(v).toLowerCase().replace(/\s+$/, '');
        return [{ same: fold((params || [])[0]) === fold((params || [])[1]) ? 1 : 0 }];
      }
      if (/information_schema\.COLUMNS/i.test(sql)) return [];
      if (/SELECT linked_blueprint_id FROM/i.test(sql)) return [];
      // The factory asks which spelling the parent row really carries before it
      // binds one. Answered rather than thrown on — see tests/helpers.
      const parentId = answerParentIdProbe(sql, params);
      if (parentId) return parentId;
      throw new Error(`Unmatched query: ${sql.slice(0, 90)}`);
    },
    async beginTransaction() { events.push('begin'); },
    async commit() { events.push('commit'); },
    async rollback() { events.push('rollback'); },
    release() { events.push('release'); },
  };
}

const poolSpy = {
  rw: { async getConnection() { return conn; } },
  ro: { async getConnection() { return conn; } },
};

require.cache[dbKey] = {
  id: dbKey,
  filename: dbKey,
  loaded: true,
  exports: {
    pool: poolSpy,
    t: (name) => `fmb_${name}`,
    getDynamicPool: async () => poolSpy,
  },
};

const router = require('../../src/edge/routes/app/schema');
const { __clearColumnSetCache } = router.__test__;

let server;
let port;

before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => {
    req.user = { id: '5b729f1e-5c0b-447c-8144-3210469bc62c', email: 'admin@test', role: 'admin' };
    next();
  });
  app.use('/edge/app/schema', router);
  await new Promise((resolve) => {
    server = app.listen(0, '127.0.0.1', () => {
      port = server.address().port;
      resolve();
    });
  });
});

after(async () => {
  await new Promise((resolve) => server.close(resolve));
  delete require.cache[dbKey];
});

beforeEach(() => { conn = null; __clearColumnSetCache(); });

function send(method, path, body) {
  return new Promise((resolve, reject) => {
    const data = Buffer.from(JSON.stringify(body), 'utf-8');
    const req = http.request({
      method, host: '127.0.0.1', port, path,
      headers: { 'Content-Type': 'application/json', 'Content-Length': data.length },
    }, (res) => {
      const chunks = [];
      res.on('data', (c) => chunks.push(c));
      res.on('end', () => {
        const raw = Buffer.concat(chunks).toString('utf-8');
        let json = null;
        try { json = raw ? JSON.parse(raw) : null; } catch { /* */ }
        resolve({ status: res.statusCode, json });
      });
    });
    req.on('error', reject);
    req.write(data);
    req.end();
  });
}
const post = (p, b) => send('POST', p, b);
const put = (p, b) => send('PUT', p, b);

describe('blueprint_sections CRUD — matrix_copy enum (item 3)', () => {
  it('rejects a typo matrix_copy value with 400 INVALID_COLUMN_VALUE (POST)', async () => {
    conn = makeConn();
    const res = await post('/edge/app/schema/blueprint_sections', {
      blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', section_key: 'sec_a', display_label: 'A', matrix_copy: 'enabledd',
    });
    assert.equal(res.status, 400);
    assert.equal(res.json.error.code, 'INVALID_COLUMN_VALUE');
  });

  it('rejects a typo matrix_copy value with 400 (PUT)', async () => {
    conn = makeConn();
    const res = await put('/edge/app/schema/blueprint_sections/de258c2d-aa6a-44eb-849e-540dbfe824ae', { matrix_copy: 'disable' });
    assert.equal(res.status, 400);
    assert.equal(res.json.error.code, 'INVALID_COLUMN_VALUE');
  });

  for (const val of ['', 'enabled', 'disabled']) {
    it(`accepts matrix_copy='${val}' (POST)`, async () => {
      conn = makeConn([
        [/SELECT id FROM `fmb_blueprint_sections` WHERE `blueprint_id` = \? AND `section_key` = \? LIMIT 1/i, []],
        [/^INSERT INTO `fmb_blueprint_sections`/i, { affectedRows: 1 }],
        [/^SELECT \* FROM `fmb_blueprint_sections`/i, [{ id: '5f800e93-38b1-4a03-8bac-066a757a359b', section_key: 'sec_a' }]],
      ]);
      const res = await post('/edge/app/schema/blueprint_sections', {
        blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', section_key: 'sec_a', display_label: 'A', matrix_copy: val,
      });
      assert.equal(res.status, 200);
    });
  }

  // NULL, WHICH THE HEADER ABOVE HAS ALWAYS CLAIMED AND NOTHING EVER DROVE.
  //
  // It matters more than the other three. A null written to a declared-domain
  // column is a violation exactly when the column is NOT NULL, and the gate now
  // reads that from the DDL rather than admitting every null — because admitting
  // them handed a NOT NULL ENUM a value it cannot store, which came back as a
  // 500 with a driver stack instead of a 400. `matrix_copy` is the one declared
  // domain in the codebase on a NULLABLE column ('VARCHAR(255) NULL DEFAULT
  // NULL'), so it is the only place that can show the rule is the column's own
  // and not a blanket refusal. If a later edit makes null a violation
  // everywhere, these two go red and this mount's "NULL is accepted (unset =
  // default-on)" contract is what they are protecting.
  it('accepts matrix_copy=null — the column is nullable, so an unset value is a real one (POST)', async () => {
    conn = makeConn([
      [/SELECT id FROM `fmb_blueprint_sections` WHERE `blueprint_id` = \? AND `section_key` = \? LIMIT 1/i, []],
      [/^INSERT INTO `fmb_blueprint_sections`/i, { affectedRows: 1 }],
      [/^SELECT \* FROM `fmb_blueprint_sections`/i, [{ id: '5f800e93-38b1-4a03-8bac-066a757a359b', section_key: 'sec_a' }]],
    ]);
    const res = await post('/edge/app/schema/blueprint_sections', {
      blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', section_key: 'sec_a', display_label: 'A', matrix_copy: null,
    });
    assert.equal(res.status, 200, `a nullable column refused a null: ${JSON.stringify(res.json)}`);
  });

  it('accepts matrix_copy=null (PUT)', async () => {
    conn = makeConn([
      [/SELECT `blueprint_id` AS bid FROM `fmb_blueprint_sections`/i, [{ bid: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26' }]],
      [/^UPDATE `fmb_blueprint_sections`/i, { affectedRows: 1 }],
      [/^SELECT \* FROM `fmb_blueprint_sections`/i, [{ id: 'de258c2d-aa6a-44eb-849e-540dbfe824ae', section_key: 'sec_a' }]],
    ]);
    const res = await put('/edge/app/schema/blueprint_sections/de258c2d-aa6a-44eb-849e-540dbfe824ae', { matrix_copy: null });
    assert.equal(res.status, 200, `a nullable column refused a null: ${JSON.stringify(res.json)}`);
  });
});

describe('blueprint_sections CRUD POST — section_key slug (item 5)', () => {
  it('rejects a non-slug section_key with 400 INVALID_KEY_FORMAT', async () => {
    conn = makeConn();
    const res = await post('/edge/app/schema/blueprint_sections', {
      blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', section_key: 'Bad Section', display_label: 'A',
    });
    assert.equal(res.status, 400);
    assert.equal(res.json.error.code, 'INVALID_KEY_FORMAT');
  });

  it('accepts a valid slug section_key (200)', async () => {
    conn = makeConn([
      [/SELECT id FROM `fmb_blueprint_sections` WHERE `blueprint_id` = \? AND `section_key` = \? LIMIT 1/i, []],
      [/^INSERT INTO `fmb_blueprint_sections`/i, { affectedRows: 1 }],
      [/^SELECT \* FROM `fmb_blueprint_sections`/i, [{ id: '5f800e93-38b1-4a03-8bac-066a757a359b', section_key: 'good_section' }]],
    ]);
    const res = await post('/edge/app/schema/blueprint_sections', {
      blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', section_key: 'good_section', display_label: 'A',
    });
    assert.equal(res.status, 200);
  });
});

describe('blueprint_sections CRUD POST — uniqueness within a blueprint (uq_blueprint_section_key)', () => {
  it('rejects a duplicate (blueprint_id, section_key) with 409 DUPLICATE_SECTION_KEY (app-layer)', async () => {
    conn = makeConn([
      [/SELECT id FROM `fmb_blueprint_sections` WHERE `blueprint_id` = \? AND `section_key` = \? LIMIT 1/i, [{ id: '8cc0d612-8691-4009-8963-e7bd8db658f9' }]],
    ]);
    const res = await post('/edge/app/schema/blueprint_sections', {
      blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', section_key: 'sec_a', display_label: 'A',
    });
    assert.equal(res.status, 409);
    assert.equal(res.json.error.code, 'DUPLICATE_SECTION_KEY');
    assert.ok(conn.events.includes('rollback'));
  });

  it('maps errno 1062 from the UNIQUE index to 409 DUPLICATE_SECTION_KEY (race backstop)', async () => {
    conn = makeConn([
      [/SELECT id FROM `fmb_blueprint_sections` WHERE `blueprint_id` = \? AND `section_key` = \? LIMIT 1/i, []],
      [/^INSERT INTO `fmb_blueprint_sections`/i, () => { const e = new Error('dup'); e.errno = 1062; throw e; }],
    ]);
    const res = await post('/edge/app/schema/blueprint_sections', {
      blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', section_key: 'sec_a', display_label: 'A',
    });
    assert.equal(res.status, 409);
    assert.equal(res.json.error.code, 'DUPLICATE_SECTION_KEY');
  });
});

describe('POST /blueprint_sections/replace — slug on new keys only (item 5)', () => {
  it('rejects a NEW non-slug section_key in next with 400', async () => {
    conn = makeConn([
      [/SELECT id, section_key, display_label, sort_order FROM/i, []],
    ]);
    const res = await post('/edge/app/schema/blueprint_sections/replace', {
      blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26',
      expected: [],
      next: [{ section_key: 'Bad Section', display_label: 'A', sort_order: 1 }],
    });
    assert.equal(res.status, 400);
    assert.equal(res.json.error.code, 'INVALID_KEY_FORMAT');
    assert.ok(conn.events.includes('rollback'));
  });

  it('grandfathers a legacy non-slug key preserved across the reorder', async () => {
    conn = makeConn([
      [/SELECT id, section_key, display_label, sort_order FROM/i,
        [{ id: 'da5ab730-83fb-408a-8d00-86570559cdad', section_key: 'Bad Section', display_label: 'Legacy', sort_order: 1 }]],
      [/^UPDATE `fmb_blueprint_sections`/i, { affectedRows: 1 }],
    ]);
    const res = await post('/edge/app/schema/blueprint_sections/replace', {
      blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26',
      expected: [{ section_key: 'Bad Section', display_label: 'Legacy', sort_order: 1 }],
      next: [{ section_key: 'Bad Section', display_label: 'Renamed', sort_order: 2 }],
    });
    assert.equal(res.status, 200);
    assert.ok(conn.events.includes('commit'));
  });

  // The check adopted from the groups lane: a replace must not become a
  // back-door section removal. A field names its section BY STRING, so dropping
  // a key a field still holds destroys that section's metadata and leaves the
  // field naming a section that has none — which still renders, so nothing says
  // the label is gone. The instrument that settles it on stored rows is
  // tests/integration/destructive-gates-real-db.test.js.
  it('rejects dropping a section_key that still has referencing fields (409 SECTION_KEY_IN_USE)', async () => {
    conn = makeConn([
      [/SELECT id, section_key, display_label, sort_order FROM/i,
        [{ id: 'da5ab730-83fb-408a-8d00-86570559cdad', section_key: 'overview', display_label: 'Overview', sort_order: 1 }]],
      [/SELECT DISTINCT `section` AS k FROM `fmb_blueprint_fields`/i, [{ k: 'overview' }]],
    ]);
    const res = await post('/edge/app/schema/blueprint_sections/replace', {
      blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26',
      expected: [{ section_key: 'overview', display_label: 'Overview', sort_order: 1 }],
      next: [{ section_key: 'summary', display_label: 'Overview', sort_order: 1 }],
    });
    assert.equal(res.status, 409);
    assert.equal(res.json.error.code, 'SECTION_KEY_IN_USE');
    assert.ok(conn.events.includes('rollback'));
    // No DELETE was issued — refused before the destructive step.
    assert.ok(!conn.queries.some((q) => /^DELETE FROM `fmb_blueprint_sections`/i.test(q.sql)));
  });

  it('allows dropping a section_key nothing references', async () => {
    conn = makeConn([
      [/SELECT id, section_key, display_label, sort_order FROM/i,
        [{ id: 'da5ab730-83fb-408a-8d00-86570559cdad', section_key: 'overview', display_label: 'Overview', sort_order: 1 }]],
      [/SELECT DISTINCT `section` AS k FROM `fmb_blueprint_fields`/i, []],
      [/^DELETE FROM `fmb_blueprint_sections`/i, { affectedRows: 1 }],
    ]);
    const res = await post('/edge/app/schema/blueprint_sections/replace', {
      blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26',
      expected: [{ section_key: 'overview', display_label: 'Overview', sort_order: 1 }],
      next: [],
    });
    assert.equal(res.status, 200);
    assert.equal(res.json.data.applied.deleted, 1);
    assert.ok(conn.events.includes('commit'));
  });
});

describe('POST /blueprint_sections/delete-with-reassign (item 2)', () => {
  it('400 on invalid action', async () => {
    conn = makeConn();
    const res = await post('/edge/app/schema/blueprint_sections/delete-with-reassign', { blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', section_key: 's', action: 'nope' });
    assert.equal(res.status, 400);
  });

  // Existence + row-lock probes. `metaPresent` = section_keys with a
  // blueprint_sections metadata row (locked FOR UPDATE). `fieldSections` =
  // section_keys that have at least one referencing field (the metadata-less
  // existence fallback: `SELECT 1 FROM blueprint_fields ... LIMIT 1`). Returns
  // an ARRAY of matchers → spread into makeConn.
  function sectionLockScript(metaPresent, forUpdateSeen, fieldSections = new Set()) {
    return [
      [/SELECT id FROM `fmb_blueprint_sections` WHERE blueprint_id = \? AND section_key = \?/i,
        (sql, params) => {
          if (/FOR UPDATE/i.test(sql)) forUpdateSeen.push(params[1]);
          return metaPresent.has(params[1]) ? [{ id: `id-${params[1]}` }] : [];
        }],
      [/SELECT 1 FROM `fmb_blueprint_fields` WHERE blueprint_id = \? AND section = \? LIMIT 1/i,
        (sql, params) => (fieldSections.has(params[1]) ? [{ 1: 1 }] : [])],
    ];
  }

  it('404 only when NEITHER a metadata row NOR any referencing field exists', async () => {
    conn = makeConn([...sectionLockScript(new Set(), [], new Set())]);
    const res = await post('/edge/app/schema/blueprint_sections/delete-with-reassign', { blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', section_key: 'gone', action: 'delete' });
    assert.equal(res.status, 404);
    assert.ok(conn.events.includes('rollback'));
  });

  it('metadata-less section (fields but no blueprint_sections row): DELETE works', async () => {
    const order = [];
    conn = makeConn([
      // No metadata row for sec_meta_less, but it has referencing fields.
      ...sectionLockScript(new Set(), [], new Set(['sec_meta_less'])),
      [/SELECT id FROM `fmb_blueprint_fields` WHERE blueprint_id = \? AND section = \?/i, [{ id: '2ce8ba8e-83f5-41ee-8246-a2265095b549' }]],
      [/^DELETE FROM `fmb_field_options`/i, () => { order.push('opts'); return { affectedRows: 2 }; }],
      [/^DELETE FROM `fmb_variant_overrides`/i, () => { order.push('overrides'); return { affectedRows: 0 }; }],
      [/^DELETE FROM `fmb_blueprint_fields`/i, () => { order.push('fields'); return { affectedRows: 1 }; }],
      [/^DELETE FROM `fmb_blueprint_sections`/i, () => { order.push('section'); return { affectedRows: 0 }; }],
    ]);
    const res = await post('/edge/app/schema/blueprint_sections/delete-with-reassign', {
      blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', section_key: 'sec_meta_less', action: 'delete',
    });
    assert.equal(res.status, 200);
    assert.equal(res.json.data.deleted_fields, 1);
    // Overrides cleaned by field_id before the fields go; then the (no-op)
    // metadata DELETE still runs, harmlessly.
    assert.deepEqual(order, ['opts', 'overrides', 'fields', 'section']);
    assert.ok(conn.events.includes('commit'));
  });

  it('locks the cascade snapshot, deletes the fields BY ID, and reports what the statement did', async () => {
    // The three halves of the same rule: the rows this hand-rolled cascade is
    // about to act over are LOCKED, the parent statement names those locked ids
    // rather than restating the predicate that found them, and the count in the
    // response comes from the statement rather than from the list that fed it.
    // The two numbers differ here on purpose — a report taken from `ids.length`
    // reads 2 while the statement removed 1. The instrument that reproduces the
    // interleaving that makes them differ for real is
    // tests/integration/destructive-gates-real-db.test.js.
    let snapshotSql = null;
    let deleteParams = null;
    conn = makeConn([
      ...sectionLockScript(new Set(['sec_a']), [], new Set(['sec_a'])),
      [/SELECT id FROM `fmb_blueprint_fields` WHERE blueprint_id = \? AND section = \?/i,
        (sql) => {
          snapshotSql = sql;
          return [{ id: '2ce8ba8e-83f5-41ee-8246-a2265095b549' },
            { id: 'ac0e0a49-2a51-4a17-9a7e-6b9b2f6a1f22' }];
        }],
      [/^DELETE FROM `fmb_field_options`/i, { affectedRows: 3 }],
      [/^DELETE FROM `fmb_variant_overrides`/i, { affectedRows: 1 }],
      [/^DELETE FROM `fmb_blueprint_fields`/i,
        (sql, params) => { deleteParams = params; return { affectedRows: 1 }; }],
      [/^DELETE FROM `fmb_blueprint_sections`/i, { affectedRows: 1 }],
    ]);
    const res = await post('/edge/app/schema/blueprint_sections/delete-with-reassign', {
      blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', section_key: 'sec_a', action: 'delete',
    });
    assert.equal(res.status, 200);
    assert.match(snapshotSql, /FOR UPDATE/i);
    assert.deepEqual(deleteParams, ['2ce8ba8e-83f5-41ee-8246-a2265095b549',
      'ac0e0a49-2a51-4a17-9a7e-6b9b2f6a1f22']);
    assert.equal(res.json.data.deleted_fields, 1);
    assert.ok(conn.events.includes('commit'));
  });

  it('metadata-less section: MOVE works when target exists via referencing fields', async () => {
    let updateParams = null;
    conn = makeConn([
      // Neither key has a metadata row; both exist only via referencing fields.
      ...sectionLockScript(new Set(), [], new Set(['sec_meta_less', 'target_meta_less'])),
      [/^UPDATE `fmb_blueprint_fields` SET section = \?/i, (sql, params) => { updateParams = params; return { affectedRows: 3 }; }],
      [/^DELETE FROM `fmb_blueprint_sections`/i, { affectedRows: 0 }],
    ]);
    const res = await post('/edge/app/schema/blueprint_sections/delete-with-reassign', {
      blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', section_key: 'sec_meta_less', action: 'move', target_section: 'target_meta_less',
    });
    assert.equal(res.status, 200);
    assert.equal(res.json.data.moved, 3);
    assert.equal(updateParams[0], 'target_meta_less');
    assert.ok(conn.events.includes('commit'));
  });

  it('move: locks both keys FOR UPDATE in sorted order, reassigns then deletes the section', async () => {
    let updateParams = null;
    const forUpdate = [];
    conn = makeConn([
      ...sectionLockScript(new Set(['sec_a', 'sec_b']), forUpdate),
      [/^UPDATE `fmb_blueprint_fields` SET section = \?/i, (sql, params) => { updateParams = params; return { affectedRows: 4 }; }],
      [/^DELETE FROM `fmb_blueprint_sections`/i, { affectedRows: 1 }],
    ]);
    const res = await post('/edge/app/schema/blueprint_sections/delete-with-reassign', {
      blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', section_key: 'sec_a', action: 'move', target_section: 'sec_b',
    });
    assert.equal(res.status, 200);
    assert.equal(res.json.data.moved, 4);
    assert.equal(updateParams[0], 'sec_b');
    assert.deepEqual(forUpdate, ['sec_a', 'sec_b']); // both locked, sorted order
    assert.deepEqual(conn.events, ['begin', 'commit', 'release']);
  });

  it('400 when move target section does not exist (no metadata, no fields)', async () => {
    conn = makeConn([...sectionLockScript(new Set(['sec_a']), [], new Set())]);
    const res = await post('/edge/app/schema/blueprint_sections/delete-with-reassign', {
      blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', section_key: 'sec_a', action: 'move', target_section: 'nope',
    });
    assert.equal(res.status, 400);
    assert.ok(conn.events.includes('rollback'));
  });

  it('delete: removes the section fields options + overrides + fields, then the section (committed)', async () => {
    const order = [];
    let overrideParams = null;
    conn = makeConn([
      ...sectionLockScript(new Set(['sec_a']), []),
      [/SELECT id FROM `fmb_blueprint_fields` WHERE blueprint_id = \? AND section = \?/i, [{ id: '2ce8ba8e-83f5-41ee-8246-a2265095b549' }, { id: '3fc92258-d5bb-458d-8d64-6ac02f44cd85' }]],
      [/^DELETE FROM `fmb_field_options`/i, () => { order.push('opts'); return { affectedRows: 5 }; }],
      [/^DELETE FROM `fmb_variant_overrides` WHERE field_id IN/i, (sql, params) => { order.push('overrides'); overrideParams = params; return { affectedRows: 3 }; }],
      [/^DELETE FROM `fmb_blueprint_fields`/i, () => { order.push('fields'); return { affectedRows: 2 }; }],
      [/^DELETE FROM `fmb_blueprint_sections`/i, () => { order.push('section'); return { affectedRows: 1 }; }],
    ]);
    const res = await post('/edge/app/schema/blueprint_sections/delete-with-reassign', {
      blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', section_key: 'sec_a', action: 'delete',
    });
    assert.equal(res.status, 200);
    assert.equal(res.json.data.deleted_fields, 2);
    assert.equal(res.json.data.deleted_options, 5);
    assert.equal(res.json.data.deleted_overrides, 3, 'variant overrides on the section fields are cleaned');
    // Overrides are deleted by the same field_id set as the options.
    assert.deepEqual(overrideParams, ['2ce8ba8e-83f5-41ee-8246-a2265095b549', '3fc92258-d5bb-458d-8d64-6ac02f44cd85']);
    assert.deepEqual(order, ['opts', 'overrides', 'fields', 'section']);
    assert.deepEqual(conn.events, ['begin', 'commit', 'release']);
  });

  it('rolls back when a mid-transaction delete fails (atomicity)', async () => {
    conn = makeConn([
      ...sectionLockScript(new Set(['sec_a']), []),
      [/SELECT id FROM `fmb_blueprint_fields` WHERE blueprint_id = \? AND section = \?/i, [{ id: '2ce8ba8e-83f5-41ee-8246-a2265095b549' }]],
      [/^DELETE FROM `fmb_field_options`/i, { affectedRows: 1 }],
      [/^DELETE FROM `fmb_variant_overrides`/i, { affectedRows: 0 }],
      [/^DELETE FROM `fmb_blueprint_fields`/i, () => { throw new Error('boom mid-tx'); }],
    ]);
    const res = await post('/edge/app/schema/blueprint_sections/delete-with-reassign', {
      blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', section_key: 'sec_a', action: 'delete',
    });
    assert.equal(res.status, 500);
    assert.ok(conn.events.includes('rollback'));
    assert.ok(!conn.events.includes('commit'));
  });
});
