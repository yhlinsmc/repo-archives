/**
 * docs-font-options-call-sites.test.js — every place that mounts the Scalar
 * reference must hand it the paired font options, and this file finds those
 * places by walking the source rather than by listing them.
 *
 * WHY NOT A LIST. fmb-1424 turns the bundle's own `withDefaultFonts` switch off
 * so the fourteen external @font-face declarations are never put in the
 * document. What kept that true was three call sites written by hand and tests
 * naming the same three by hand: a FOURTH mount reintroduces all fourteen with
 * every gate green. The shipped-artefact scan cannot close it either — it looks
 * for URL strings, and the switch is a runtime value that never appears as one.
 *
 * So the enumeration is generated: walk docker-api/src for calls to the
 * renderer's mount function, and require each one to spread the shared helper.
 * A hand-written completeness claim is the thing that fails in this repository;
 * this file is allowed to claim only what it just derived from the filesystem.
 *
 * The scan is deliberately shallow-but-honest about indirection: an argument
 * that is a bare call to a function defined in the SAME file is followed one
 * level (that is how the public portal builds its config). Anything else must
 * carry the spread literally, or fail here and be made to.
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const SRC_ROOT = path.join(__dirname, '..', '..', 'src');
const MOUNT_CALL = 'apiReference';
const RENDERER_PACKAGE = '@scalar/express-api-reference';
const REQUIRED_SPREAD = /\.\.\.\s*buildDocsFontOptions\s*\(/;

/**
 * Positions in `src` that are real code — not inside a string, a template
 * literal, a line comment or a block comment. Returned as a same-length mask so
 * every later scan can share one pass.
 * @param {string} src
 * @returns {boolean[]}
 */
function codeMask(src) {
  const mask = new Array(src.length).fill(false);
  let i = 0;
  while (i < src.length) {
    const c = src[i];
    const next = src[i + 1];
    if (c === '/' && next === '/') {
      while (i < src.length && src[i] !== '\n') i += 1;
    } else if (c === '/' && next === '*') {
      i += 2;
      while (i < src.length && !(src[i] === '*' && src[i + 1] === '/')) i += 1;
      i += 2;
    } else if (c === '"' || c === "'" || c === '`') {
      const quote = c;
      i += 1;
      while (i < src.length) {
        if (src[i] === '\\') { i += 2; continue; }
        if (src[i] === quote) { i += 1; break; }
        i += 1;
      }
    } else {
      mask[i] = true;
      i += 1;
    }
  }
  return mask;
}

/**
 * @param {string} src
 * @param {boolean[]} mask
 * @param {number} openIndex index of the opening parenthesis
 * @returns {{ end: number, text: string }} the argument list, parentheses excluded
 */
function balancedArgs(src, mask, openIndex) {
  let depth = 0;
  for (let i = openIndex; i < src.length; i += 1) {
    if (!mask[i]) continue;
    if (src[i] === '(') depth += 1;
    else if (src[i] === ')') {
      depth -= 1;
      if (depth === 0) return { end: i, text: src.slice(openIndex + 1, i) };
    }
  }
  throw new Error(`unbalanced call starting at offset ${openIndex}`);
}

/**
 * @param {string} src
 * @param {boolean[]} mask
 * @param {string} name
 * @returns {string|null} the body of `function name(...)`, braces excluded
 */
function functionBody(src, mask, name) {
  const re = new RegExp(`\\bfunction\\s+${name}\\s*\\(`, 'g');
  let match;
  while ((match = re.exec(src)) !== null) {
    const open = src.indexOf('(', match.index);
    if (!mask[open]) continue;
    const params = balancedArgs(src, mask, open);
    const braceAt = src.indexOf('{', params.end);
    if (braceAt === -1) continue;
    let depth = 0;
    for (let i = braceAt; i < src.length; i += 1) {
      if (!mask[i]) continue;
      if (src[i] === '{') depth += 1;
      else if (src[i] === '}') {
        depth -= 1;
        if (depth === 0) return src.slice(braceAt + 1, i);
      }
    }
  }
  return null;
}

/**
 * The value of `const <name> = …;` in this file, source text as written.
 * @param {string} src
 * @param {boolean[]} mask
 * @param {string} name
 * @returns {string|null}
 */
function constInitialiser(src, mask, name) {
  const re = new RegExp(`\\b(?:const|let|var)\\s+${name}\\s*=`, 'g');
  let match;
  while ((match = re.exec(src)) !== null) {
    if (!mask[match.index]) continue;
    let depth = 0;
    for (let i = re.lastIndex; i < src.length; i += 1) {
      if (!mask[i]) continue;
      const c = src[i];
      if (c === '(' || c === '{' || c === '[') depth += 1;
      else if (c === ')' || c === '}' || c === ']') depth -= 1;
      else if ((c === ';' || c === '\n') && depth <= 0) {
        const text = src.slice(re.lastIndex, i).trim();
        if (text) return text;
      }
    }
  }
  return null;
}

/**
 * Does the shared helper reach this argument expression? Follows a bounded
 * chain of same-file indirection — a local binding, or a function defined here —
 * because that is how the configuration is actually assembled. Anything the
 * chain cannot follow counts as NOT reaching, which is the safe direction.
 * @param {string} src
 * @param {boolean[]} mask
 * @param {string} expr
 * @param {number} [hops]
 * @returns {{ ok: boolean, via: string }}
 */
function spreadReaches(src, mask, expr, hops = 0) {
  const text = expr.trim();
  if (REQUIRED_SPREAD.test(text)) return { ok: true, via: 'literal argument' };
  if (hops >= 3) return { ok: false, via: 'gave up following indirection' };

  const call = text.match(/^([A-Za-z_$][\w$]*)\s*\(/);
  if (call) {
    const body = functionBody(src, mask, call[1]);
    if (body && REQUIRED_SPREAD.test(body)) return { ok: true, via: `${call[1]}() in the same file` };
  }

  const bare = text.match(/^[A-Za-z_$][\w$]*$/);
  if (bare) {
    const init = constInitialiser(src, mask, text);
    if (init) {
      const deeper = spreadReaches(src, mask, init, hops + 1);
      if (deeper.ok) return { ok: true, via: `${text} = ${init.split('\n')[0]}` };
    }
  }
  return { ok: false, via: 'not followed' };
}

/** @param {string} dir @param {string[]} [out] @returns {string[]} */
function walk(dir, out = []) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      if (entry.name === 'node_modules' || entry.name === '__tests__') continue;
      walk(full, out);
    } else if (entry.name.endsWith('.js')) out.push(full);
  }
  return out;
}

/**
 * Every mount call found under docker-api/src, with the source of its argument
 * and whether the shared font options reach it.
 * @returns {{ files: string[], sites: Array<{ rel: string, line: number, spreads: boolean, via: string }>, importers: string[] }}
 */
function scanSource() {
  const files = walk(SRC_ROOT);
  const sites = [];
  const importers = [];

  for (const file of files) {
    const src = fs.readFileSync(file, 'utf8');
    const rel = path.relative(SRC_ROOT, file);
    const mask = codeMask(src);
    if (src.includes(RENDERER_PACKAGE)) importers.push(rel);

    const re = new RegExp(`\\b${MOUNT_CALL}\\s*\\(`, 'g');
    let match;
    while ((match = re.exec(src)) !== null) {
      const open = src.indexOf('(', match.index);
      if (!mask[match.index] || !mask[open]) continue;

      const args = balancedArgs(src, mask, open);
      const line = src.slice(0, match.index).split('\n').length;
      const { ok, via } = spreadReaches(src, mask, args.text);
      sites.push({ rel, line, spreads: ok, via });
    }
  }
  return { files, sites, importers };
}

describe('every Scalar mount spreads the shared font options (fmb-1424)', () => {
  const { files, sites, importers } = scanSource();

  it('the walk actually reached the API source', () => {
    // A scan that silently finds nothing reports a pass, which is worse than no
    // scan. Anchored on a file that must exist for this suite to mean anything.
    assert.ok(files.length > 0, 'no .js files were scanned under docker-api/src');
    const anchor = path.join('infra', 'routes', 'public-docs.js');
    assert.ok(
      files.some((f) => path.relative(SRC_ROOT, f) === anchor),
      `the scan root is wrong — ${anchor} was not among the ${files.length} files walked`,
    );
  });

  it('at least one mount call was found, so the pattern still matches the code', () => {
    assert.ok(
      sites.length > 0,
      `no call to ${MOUNT_CALL}() was found under docker-api/src — either the renderer is no longer `
      + 'mounted anywhere (delete this file) or it is mounted under another name (fix the pattern), '
      + 'but a green run on zero call sites proves nothing',
    );
  });

  it('every file that imports the renderer also calls it, so none is invisible here', () => {
    const called = new Set(sites.map((s) => s.rel));
    const blind = importers.filter((rel) => !called.has(rel));
    assert.deepEqual(
      blind,
      [],
      `these files import ${RENDERER_PACKAGE} but no ${MOUNT_CALL}() call was found in them, so the `
      + `check above cannot see what they mount: ${blind.join(', ')}`,
    );
  });

  it('every mount call receives ...buildDocsFontOptions()', () => {
    const missing = sites.filter((s) => !s.spreads).map((s) => `src/${s.rel}:${s.line}`);
    assert.deepEqual(
      missing,
      [],
      'a documentation page is mounted without the shared font options, so the bundle declares its '
      + 'fourteen external @font-face rules there and the browser asks for every one of them. '
      + `Spread ...buildDocsFontOptions(<scalar mount>) into the configuration at: ${missing.join(', ')}`,
    );
  });

  it('reports the call sites it derived, so a reader can see the scan working', () => {
    // Not an assertion about how many there are — that would be the hand-written
    // claim this file exists to replace. It prints what the walk found.
    for (const site of sites) {
      assert.equal(typeof site.via, 'string');
      process.stdout.write(`    mount: src/${site.rel}:${site.line} (${site.via})\n`);
    }
  });
});
