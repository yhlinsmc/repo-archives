/**
 * connector-validate.test.js — unit coverage for validateInputFromStep, the
 * shared chain-wiring shape validator reused by CRUD writes and import.
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');

const {
  validateInputFromStep,
  validateResponseOutputs,
  validateInputCells,
  validateConnectorCoherence,
  validateNoFollowerColumnTarget,
  loadFollowerColumnKeys,
} = require('../../src/edge/routes/app/api-connectors/validate');

describe('validateInputFromStep — valid / absent cases pass (null)', () => {
  it('null request_config → null', () => {
    assert.equal(validateInputFromStep(null, undefined), null);
  });

  it('non-object request_config → null', () => {
    assert.equal(validateInputFromStep('garbage', undefined), null);
  });

  it('request_config without input_from_step → null', () => {
    assert.equal(validateInputFromStep({ url: 'x' }, undefined), null);
  });

  it('input_from_step null → null', () => {
    assert.equal(validateInputFromStep({ input_from_step: null }, undefined), null);
  });

  it('empty array with no sequence → null (clearing wiring)', () => {
    assert.equal(validateInputFromStep({ input_from_step: [] }, undefined), null);
  });

  it('valid entry referencing an earlier step → null', () => {
    assert.equal(
      validateInputFromStep({ input_from_step: [{ var: 'id', from_sequence: 1, path: 'data.id' }] }, 2),
      null,
    );
  });
});

describe('validateInputFromStep — invalid cases return a message', () => {
  it('non-array input_from_step', () => {
    assert.match(
      validateInputFromStep({ input_from_step: { var: 'x' } }, 2),
      /must be an array/,
    );
  });

  it('entry not an object', () => {
    assert.match(validateInputFromStep({ input_from_step: ['nope'] }, 2), /must be objects/);
  });

  it('missing var', () => {
    assert.match(
      validateInputFromStep({ input_from_step: [{ from_sequence: 1, path: 'a' }] }, 2),
      /var must be a non-empty string/,
    );
  });

  it('empty var', () => {
    assert.match(
      validateInputFromStep({ input_from_step: [{ var: '  ', from_sequence: 1, path: 'a' }] }, 2),
      /var must be a non-empty string/,
    );
  });

  it('from_sequence not an integer', () => {
    assert.match(
      validateInputFromStep({ input_from_step: [{ var: 'x', from_sequence: '1', path: 'a' }] }, 2),
      /from_sequence must be a positive integer/,
    );
  });

  it('from_sequence below 1', () => {
    assert.match(
      validateInputFromStep({ input_from_step: [{ var: 'x', from_sequence: 0, path: 'a' }] }, 2),
      /from_sequence must be a positive integer/,
    );
  });

  it('missing path', () => {
    assert.match(
      validateInputFromStep({ input_from_step: [{ var: 'x', from_sequence: 1 }] }, 2),
      /path must be a non-empty string/,
    );
  });

  it('empty path', () => {
    assert.match(
      validateInputFromStep({ input_from_step: [{ var: 'x', from_sequence: 1, path: '' }] }, 2),
      /path must be a non-empty string/,
    );
  });

  it('from_sequence equals own sequence', () => {
    assert.match(
      validateInputFromStep({ input_from_step: [{ var: 'x', from_sequence: 2, path: 'a' }] }, 2),
      /earlier step/,
    );
  });

  it('from_sequence greater than own sequence', () => {
    assert.match(
      validateInputFromStep({ input_from_step: [{ var: 'x', from_sequence: 3, path: 'a' }] }, 2),
      /earlier step/,
    );
  });

  it('entries present but no own sequence declared', () => {
    assert.match(
      validateInputFromStep({ input_from_step: [{ var: 'x', from_sequence: 1, path: 'a' }] }, undefined),
      /sequence is required/,
    );
  });
});

const rowsOutput = (to) => ({
  outputs: [{ id: 'o1', from: { mode: 'list', path: 'data.rows' }, to: { mode: 'rows', table_key: 'nodes', columns: [{ column_key: 'ip', from: 'ip' }], ...to } }],
});

describe('validateResponseOutputs — rows-sink match (optional, enrich-by-key)', () => {
  it('null / non-object response_config → null', () => {
    assert.equal(validateResponseOutputs(null), null);
    assert.equal(validateResponseOutputs('garbage'), null);
  });

  it('response_config without outputs → null', () => {
    assert.equal(validateResponseOutputs({ transformer_id: 't' }), null);
  });

  it('rows sink with no match → null', () => {
    assert.equal(validateResponseOutputs(rowsOutput({})), null);
  });

  it('valid match (default op) → null', () => {
    assert.equal(validateResponseOutputs(rowsOutput({ match: { row_column: 'hostname', element_field: 'host' } })), null);
  });

  it('valid match with explicit op + on_no_match skip → null', () => {
    for (const op of ['eq', 'neq', 'contains', 'gt', 'lt', 'gte', 'lte', 'in']) {
      assert.equal(
        validateResponseOutputs(rowsOutput({ match: { row_column: 'hostname', element_field: 'host', op }, on_no_match: 'skip' })),
        null,
        `op=${op} must pass`,
      );
    }
  });

  it('partial match (missing element_field AND source_cell) rejected', () => {
    assert.match(
      validateResponseOutputs(rowsOutput({ match: { row_column: 'hostname' } })),
      /element_field or source_cell/,
    );
  });

  it('source-cell-only key accepted (Q19 provenance, blank element_field) — X1', () => {
    assert.equal(
      validateResponseOutputs(rowsOutput({ match: { keys: [{ row_column: 'region', element_field: '', source_cell: 'zone' }] } })),
      null,
    );
  });

  it('partial match (missing row_column) rejected', () => {
    assert.match(
      validateResponseOutputs(rowsOutput({ match: { element_field: 'host' } })),
      /match\.row_column must be a non-empty string/,
    );
  });

  it('empty row_column rejected', () => {
    assert.match(
      validateResponseOutputs(rowsOutput({ match: { row_column: '  ', element_field: 'host' } })),
      /match\.row_column must be a non-empty string/,
    );
  });

  it('bad op rejected', () => {
    assert.match(
      validateResponseOutputs(rowsOutput({ match: { row_column: 'hostname', element_field: 'host', op: 'startsWith' } })),
      /match\.op must be one of/,
    );
  });

  it('non-object match rejected', () => {
    assert.match(
      validateResponseOutputs(rowsOutput({ match: 'nope' })),
      /match must be an object/,
    );
  });

  it('on_no_match create accepted on an eq join (upsert)', () => {
    assert.equal(
      validateResponseOutputs(rowsOutput({ match: { row_column: 'hostname', element_field: 'host' }, on_no_match: 'create' })),
      null,
    );
  });

  it('on_no_match create rejected with a non-eq match op', () => {
    assert.match(
      validateResponseOutputs(rowsOutput({ match: { row_column: 'hostname', element_field: 'host', op: 'contains' }, on_no_match: 'create' })),
      /'create' requires every match key op to be 'eq'/,
    );
  });

  it('unknown on_no_match value rejected', () => {
    assert.match(
      validateResponseOutputs(rowsOutput({ match: { row_column: 'hostname', element_field: 'host' }, on_no_match: 'delete' })),
      /on_no_match must be 'skip' or 'create'/,
    );
  });
});

describe('validateResponseOutputs — rows-sink order_by (Fix 1 & Fix 3 defense-in-depth)', () => {
  // Fix 1: order_by alone (no match) is valid.
  it('rows sink with valid order_by and no match → null', () => {
    assert.equal(
      validateResponseOutputs(rowsOutput({ order_by: [{ column: 'ip', dir: 'asc' }] })),
      null,
    );
  });

  it('order_by with multiple valid keys → null', () => {
    assert.equal(
      validateResponseOutputs(rowsOutput({ order_by: [{ column: 'ip', dir: 'asc' }, { column: 'name', dir: 'desc' }] })),
      null,
    );
  });

  it('order_by non-array rejected', () => {
    assert.match(
      validateResponseOutputs(rowsOutput({ order_by: 'ip asc' })),
      /order_by must be an array/,
    );
  });

  it('order_by entry with empty column rejected', () => {
    assert.match(
      validateResponseOutputs(rowsOutput({ order_by: [{ column: '', dir: 'asc' }] })),
      /non-empty string column/,
    );
  });

  it('order_by entry with invalid dir rejected', () => {
    assert.match(
      validateResponseOutputs(rowsOutput({ order_by: [{ column: 'ip', dir: 'random' }] })),
      /dir must be 'asc' or 'desc'/,
    );
  });

  // Fix 3 defense-in-depth: order_by combined with match (join) is rejected.
  it('order_by combined with match rejected (Fix 3)', () => {
    assert.match(
      validateResponseOutputs(rowsOutput({
        order_by: [{ column: 'ip', dir: 'asc' }],
        match: { row_column: 'ip', element_field: 'host' },
      })),
      /order_by cannot be combined with match/,
    );
  });
});

describe('validateInputCells — optional positive-integer row', () => {
  it('null / non-object request_config → null', () => {
    assert.equal(validateInputCells(null), null);
    assert.equal(validateInputCells('garbage'), null);
  });

  it('request_config without input_cells → null', () => {
    assert.equal(validateInputCells({ url: 'x' }), null);
  });

  it('non-array input_cells rejected', () => {
    assert.match(validateInputCells({ input_cells: { var: 'x' } }), /input_cells must be an array/);
  });

  it('input cell without row → null (per-row binding)', () => {
    assert.equal(validateInputCells({ input_cells: [{ table_key: 'nodes', column_key: 'hostname', var: 'host' }] }), null);
  });

  it('input cell with positive-integer row → null', () => {
    assert.equal(validateInputCells({ input_cells: [{ table_key: 'nodes', column_key: 'hostname', var: 'host', row: 1 }] }), null);
  });

  it('zero row rejected', () => {
    assert.match(
      validateInputCells({ input_cells: [{ table_key: 'nodes', column_key: 'hostname', var: 'host', row: 0 }] }),
      /row must be a positive integer/,
    );
  });

  it('non-integer row rejected', () => {
    assert.match(
      validateInputCells({ input_cells: [{ table_key: 'nodes', column_key: 'hostname', var: 'host', row: 1.5 }] }),
      /row must be a positive integer/,
    );
    assert.match(
      validateInputCells({ input_cells: [{ table_key: 'nodes', column_key: 'hostname', var: 'host', row: '1' }] }),
      /row must be a positive integer/,
    );
  });
});

describe('validateConnectorCoherence — cross-table provenance / op boundary (F1 twin)', () => {
  // Per-row source cell on table A; a rows sink names its own target table.
  const perRowOnA = { input_cells: [{ table_key: 'A', column_key: 'host', var: 'h' }] };
  const rowsSink = (to) => ({ outputs: [{ id: 'o1', from: { mode: 'list', path: 'items' }, to: { mode: 'rows', ...to } }] });

  it('accepts provenance (source_cell / from_source_cell) on a CROSS-table sink', () => {
    const err = validateConnectorCoherence(perRowOnA, rowsSink({
      table_key: 'B', write_mode: 'merge',
      columns: [{ column_key: 'origin', from: '', from_source_cell: 'host' }],
      match: { keys: [{ row_column: 'region', element_field: '', source_cell: 'zone' }] },
    }));
    assert.equal(err, null);
  });

  it('rejects a source_cell key on a SAME-table sink (target === bound source)', () => {
    const err = validateConnectorCoherence(perRowOnA, rowsSink({
      table_key: 'A',
      columns: [{ column_key: 'c', from: '@' }],
      match: { keys: [{ row_column: 'region', element_field: '', source_cell: 'zone' }] },
    }));
    assert.match(err, /Source-row values require a cross-table target table\./);
  });

  it('rejects a from_source_cell column on a SAME-table sink', () => {
    const err = validateConnectorCoherence(perRowOnA, rowsSink({
      table_key: 'A', write_mode: 'append',
      columns: [{ column_key: 'origin', from: '', from_source_cell: 'host' }],
    }));
    assert.match(err, /Source-row values require a cross-table target table\./);
  });

  it('rejects a non-eq op on a CROSS-table merge key', () => {
    const err = validateConnectorCoherence(perRowOnA, rowsSink({
      table_key: 'B', write_mode: 'merge',
      columns: [{ column_key: 'c', from: 'v' }],
      match: { keys: [{ row_column: 'code', element_field: 'sku', op: 'contains' }] },
    }));
    assert.match(err, /A cross-table merge key must use the "equals" operator\./);
  });

  it('accepts an eq op on a CROSS-table merge key', () => {
    const err = validateConnectorCoherence(perRowOnA, rowsSink({
      table_key: 'B', write_mode: 'merge',
      columns: [{ column_key: 'c', from: 'v' }],
      match: { keys: [{ row_column: 'code', element_field: 'sku', op: 'eq' }] },
    }));
    assert.equal(err, null);
  });

  it('still allows a non-eq op on a SAME-table merge key (same-table engine supports ops)', () => {
    const err = validateConnectorCoherence(perRowOnA, rowsSink({
      table_key: 'A',
      columns: [{ column_key: 'c', from: 'v' }],
      match: { keys: [{ row_column: 'code', element_field: 'sku', op: 'contains' }] },
    }));
    assert.equal(err, null);
  });

  // X1: an append IGNORES match at runtime, so a stale non-eq match on a CROSS-table
  // append is inert and must not block import/update.
  it('accepts a cross-table APPEND carrying a stale non-eq match block', () => {
    const err = validateConnectorCoherence(perRowOnA, rowsSink({
      table_key: 'B', write_mode: 'append',
      columns: [{ column_key: 'c', from: 'v' }],
      match: { keys: [{ row_column: 'code', element_field: 'sku', op: 'contains' }] },
    }));
    assert.equal(err, null);
  });

  it('still rejects a non-eq op on a cross-table MERGE key', () => {
    const err = validateConnectorCoherence(perRowOnA, rowsSink({
      table_key: 'B', write_mode: 'merge',
      columns: [{ column_key: 'c', from: 'v' }],
      match: { keys: [{ row_column: 'code', element_field: 'sku', op: 'contains' }] },
    }));
    assert.match(err, /A cross-table merge key must use the "equals" operator\./);
  });
});

describe('validateNoFollowerColumnTarget (Q9 item 3, D2 amendment A4) — BE twin', () => {
  const followerKeys = new Set(['sites::site_name']);

  it('null / absent followerColumnKeys → null (no-op)', () => {
    assert.equal(validateNoFollowerColumnTarget({ outputs: [{ to: { mode: 'cell', table_key: 'sites', column_key: 'site_name' } }] }, new Set()), null);
    assert.equal(validateNoFollowerColumnTarget({ outputs: [{ to: { mode: 'cell', table_key: 'sites', column_key: 'site_name' } }] }, null), null);
  });

  it('blocks a cell sink targeting a follower column — byte-identical message to the FE twin', () => {
    const err = validateNoFollowerColumnTarget(
      { outputs: [{ to: { mode: 'cell', table_key: 'sites', column_key: 'site_name' } }] }, followerKeys,
    );
    assert.equal(err, 'This output targets a column that mirrors another table and cannot be a connector target.');
  });

  it('allows a cell sink targeting a different column of the same table', () => {
    const err = validateNoFollowerColumnTarget(
      { outputs: [{ to: { mode: 'cell', table_key: 'sites', column_key: 'region' } }] }, followerKeys,
    );
    assert.equal(err, null);
  });

  it('blocks a rows sink whose column list includes the follower column', () => {
    const err = validateNoFollowerColumnTarget(
      { outputs: [{ to: { mode: 'rows', table_key: 'sites', columns: [{ column_key: 'region' }, { column_key: 'site_name' }] } }] },
      followerKeys,
    );
    assert.equal(err, 'Column "site_name" mirrors another table and cannot be a connector target.');
  });

  it('tolerates malformed outputs (non-object entries, missing to) without throwing', () => {
    assert.doesNotThrow(() => validateNoFollowerColumnTarget({ outputs: [null, {}, { to: null }] }, followerKeys));
  });
});

describe('loadFollowerColumnKeys — BE follower-column read', () => {
  const t = (n) => `fmb_${n}`;

  it('empty set when blueprintId is falsy — no query issued', async () => {
    const queryable = { query: async () => { throw new Error('should not be called'); } };
    const keys = await loadFollowerColumnKeys(queryable, t, null);
    assert.equal(keys.size, 0);
  });

  it('collects `${field_key}::${column_key}` for every column carrying linked_source', async () => {
    const queryable = {
      query: async () => [
        { field_key: 'servers', table_config: JSON.stringify({ columns: [{ key: 'host' }, { key: 'site', linked_source: { field_key: 'sites', column_key: 'site_name' } }] }) },
        { field_key: 'other', table_config: { columns: [{ key: 'plain' }] } },
      ],
    };
    const keys = await loadFollowerColumnKeys(queryable, t, 'bp1');
    assert.deepEqual([...keys], ['servers::site']);
  });

  it('tolerates a malformed columns entry (null) and a non-JSON-parseable string without throwing', async () => {
    const queryable = {
      query: async () => [
        { field_key: 'servers', table_config: JSON.stringify({ columns: [null, { key: 'ok', linked_source: { field_key: 'x', column_key: 'y' } }] }) },
        { field_key: 'broken', table_config: 'not json{{{' },
      ],
    };
    const keys = await loadFollowerColumnKeys(queryable, t, 'bp1');
    assert.deepEqual([...keys], ['servers::ok']);
  });

  it('Codex round-1 P2: coerces a numeric column key like the FE parse layer (F12) — a numeric-keyed follower is not guard-invisible', async () => {
    const queryable = {
      query: async () => [
        // key: 5 (number, not "5") — the shape a stored table_config can carry
        // when an authoring round-trip never stringified it. The FE's own
        // single parse layer (table-column-options.ts parseTableFieldColumns,
        // F12) normalizes this to "5" before the mirror sync reads it, so a
        // `typeof c.key === 'string'` check here left this guard blind to
        // exactly the column the runtime sync still overwrites.
        { field_key: 'servers', table_config: JSON.stringify({ columns: [{ key: 5, linked_source: { field_key: 'sites', column_key: 'site_name' } }] }) },
      ],
    };
    const keys = await loadFollowerColumnKeys(queryable, t, 'bp1');
    assert.deepEqual([...keys], ['servers::5']);
  });
});
