/**
 * blueprint-output-order-replace.test.js
 *
 * HTTP integration of POST /edge/app/schema/blueprint_output_order/replace
 * via spy pool. Closes the lost-update race in OutputOrderPanel.tsx by
 * adding optimistic-revision check (expected vs current) inside a
 * transaction.
 *
 * Verifies:
 *   - happy path: empty current + populated next → all inserted
 *   - reorder: current 2 rows + next swapped sort_order → 2 updates
 *   - delete: current 2 + next 1 → 1 deleted
 *   - mixed: insert + update + delete in one call → counts match
 *   - stale revision (expected != current) → 409 with current payload
 *     and rollback (no INSERT/UPDATE/DELETE issued)
 *   - bad input: missing blueprint_id → 400
 *   - bad input: malformed item (missing sort_order) → 400
 *   - bad input: duplicate output_key in next → 400
 *   - transaction lifecycle: beginTransaction → commit on success;
 *     beginTransaction → rollback on stale
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../src/edge/db');

let currentRows;
let queries;
let connEvents;

function makeSpyConn() {
  return {
    query: async (sql, params) => {
      queries.push({ sql, params });
      if (/^SELECT id, output_key, sort_order/i.test(sql)) {
        return currentRows.map((r) => ({ ...r }));
      }
      if (/^INSERT INTO/i.test(sql)) {
        const [id, blueprintId, key, order] = params;
        currentRows.push({
          id,
          blueprint_id: blueprintId,
          output_key: key,
          sort_order: order,
        });
        return { affectedRows: 1 };
      }
      if (/^UPDATE/i.test(sql)) {
        const [order, id] = params;
        const row = currentRows.find((r) => r.id === id);
        if (row) row.sort_order = order;
        return { affectedRows: row ? 1 : 0 };
      }
      if (/^DELETE FROM/i.test(sql)) {
        const ids = new Set(params);
        const before = currentRows.length;
        currentRows = currentRows.filter((r) => !ids.has(r.id));
        return { affectedRows: before - currentRows.length };
      }
      return { affectedRows: 0 };
    },
    beginTransaction: async () => { connEvents.push('begin'); },
    commit: async () => { connEvents.push('commit'); },
    rollback: async () => { connEvents.push('rollback'); },
    release: () => { connEvents.push('release'); },
  };
}

function spyPool() {
  currentRows = [];
  queries = [];
  connEvents = [];
  return {
    rw: { getConnection: async () => makeSpyConn() },
    ro: { getConnection: async () => makeSpyConn() },
  };
}

const poolSpy = spyPool();

require.cache[dbKey] = {
  id: dbKey,
  filename: dbKey,
  loaded: true,
  exports: {
    pool: poolSpy,
    t: (name) => `fmb_${name}`,
    getDynamicPool: async () => poolSpy,
  },
};

const router = require('../../src/edge/routes/app/schema');

let server;
let port;

before(async () => {
  const app = express();
  app.use(express.json());
  // Stub admin user — endpoint requires admin.
  app.use((req, _res, next) => {
    req.user = { id: 'admin-1', email: 'admin@test', role: 'admin' };
    next();
  });
  app.use('/edge/app/schema', router);
  await new Promise((resolve) => {
    server = app.listen(0, '127.0.0.1', () => {
      port = server.address().port;
      resolve();
    });
  });
});

after(async () => {
  await new Promise((resolve) => server.close(resolve));
  delete require.cache[dbKey];
});

beforeEach(() => {
  Object.assign(poolSpy, spyPool());
});

function postJson(path_, body) {
  return new Promise((resolve, reject) => {
    const data = Buffer.from(JSON.stringify(body), 'utf-8');
    const req = http.request(
      {
        host: '127.0.0.1',
        port,
        path: path_,
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Content-Length': data.length,
        },
      },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          const raw = Buffer.concat(chunks).toString('utf-8');
          let json = null;
          try { json = raw ? JSON.parse(raw) : null; } catch { /* */ }
          resolve({ status: res.statusCode, raw, json });
        });
      },
    );
    req.on('error', reject);
    req.write(data);
    req.end();
  });
}

describe('POST /edge/app/schema/blueprint_output_order/replace', () => {
  it('inserts all when current is empty', async () => {
    currentRows = [];
    const res = await postJson('/edge/app/schema/blueprint_output_order/replace', {
      blueprint_id: 'bp-1',
      expected: [],
      next: [
        { output_key: 'foo', sort_order: 1 },
        { output_key: 'bar', sort_order: 2 },
      ],
    });
    assert.equal(res.status, 200);
    assert.equal(res.json.data.applied.inserted, 2);
    assert.equal(res.json.data.applied.updated, 0);
    assert.equal(res.json.data.applied.deleted, 0);
    assert.deepEqual(connEvents, ['begin', 'commit', 'release']);
  });

  it('updates sort_order when next reorders existing keys', async () => {
    currentRows = [
      { id: 'r1', blueprint_id: 'bp-1', output_key: 'foo', sort_order: 1 },
      { id: 'r2', blueprint_id: 'bp-1', output_key: 'bar', sort_order: 2 },
    ];
    const res = await postJson('/edge/app/schema/blueprint_output_order/replace', {
      blueprint_id: 'bp-1',
      expected: [
        { output_key: 'foo', sort_order: 1 },
        { output_key: 'bar', sort_order: 2 },
      ],
      next: [
        { output_key: 'bar', sort_order: 1 },
        { output_key: 'foo', sort_order: 2 },
      ],
    });
    assert.equal(res.status, 200);
    assert.equal(res.json.data.applied.inserted, 0);
    assert.equal(res.json.data.applied.updated, 2);
    assert.equal(res.json.data.applied.deleted, 0);
    assert.deepEqual(connEvents, ['begin', 'commit', 'release']);
  });

  it('deletes rows missing from next', async () => {
    currentRows = [
      { id: 'r1', blueprint_id: 'bp-1', output_key: 'foo', sort_order: 1 },
      { id: 'r2', blueprint_id: 'bp-1', output_key: 'bar', sort_order: 2 },
    ];
    const res = await postJson('/edge/app/schema/blueprint_output_order/replace', {
      blueprint_id: 'bp-1',
      expected: [
        { output_key: 'foo', sort_order: 1 },
        { output_key: 'bar', sort_order: 2 },
      ],
      next: [{ output_key: 'foo', sort_order: 1 }],
    });
    assert.equal(res.status, 200);
    assert.equal(res.json.data.applied.deleted, 1);
    assert.deepEqual(connEvents, ['begin', 'commit', 'release']);
  });

  it('mixed insert + update + delete in one call', async () => {
    currentRows = [
      { id: 'r1', blueprint_id: 'bp-1', output_key: 'foo', sort_order: 1 },
      { id: 'r2', blueprint_id: 'bp-1', output_key: 'bar', sort_order: 2 },
    ];
    const res = await postJson('/edge/app/schema/blueprint_output_order/replace', {
      blueprint_id: 'bp-1',
      expected: [
        { output_key: 'foo', sort_order: 1 },
        { output_key: 'bar', sort_order: 2 },
      ],
      next: [
        { output_key: 'bar', sort_order: 1 },
        { output_key: 'baz', sort_order: 2 },
      ],
    });
    assert.equal(res.status, 200);
    assert.equal(res.json.data.applied.inserted, 1);
    assert.equal(res.json.data.applied.updated, 1);
    assert.equal(res.json.data.applied.deleted, 1);
  });

  it('returns 409 STALE_REVISION when expected does not match current', async () => {
    currentRows = [
      { id: 'r1', blueprint_id: 'bp-1', output_key: 'foo', sort_order: 5 },
    ];
    const res = await postJson('/edge/app/schema/blueprint_output_order/replace', {
      blueprint_id: 'bp-1',
      expected: [{ output_key: 'foo', sort_order: 1 }],
      next: [{ output_key: 'foo', sort_order: 99 }],
    });
    assert.equal(res.status, 409);
    assert.equal(res.json.error.code, 'STALE_REVISION');
    assert.deepEqual(res.json.current, [{ output_key: 'foo', sort_order: 5 }]);
    // Rollback fired, no INSERT/UPDATE/DELETE issued.
    assert.deepEqual(connEvents, ['begin', 'rollback', 'release']);
    const writeQs = queries.filter((q) =>
      /^(INSERT|UPDATE|DELETE)/i.test(q.sql),
    );
    assert.equal(writeQs.length, 0);
  });

  it('returns 400 when blueprint_id missing', async () => {
    const res = await postJson('/edge/app/schema/blueprint_output_order/replace', {
      expected: [],
      next: [],
    });
    assert.equal(res.status, 400);
    assert.equal(res.json.error.code, 'BAD_REQUEST');
  });

  it('returns 400 when item is malformed (missing sort_order)', async () => {
    const res = await postJson('/edge/app/schema/blueprint_output_order/replace', {
      blueprint_id: 'bp-1',
      expected: [],
      next: [{ output_key: 'foo' }],
    });
    assert.equal(res.status, 400);
  });

  it('returns 400 when next contains duplicate output_key', async () => {
    const res = await postJson('/edge/app/schema/blueprint_output_order/replace', {
      blueprint_id: 'bp-1',
      expected: [],
      next: [
        { output_key: 'foo', sort_order: 1 },
        { output_key: 'foo', sort_order: 2 },
      ],
    });
    assert.equal(res.status, 400);
  });

  it('accepts legacy keys with hyphen / leading digit (within VARCHAR 255)', async () => {
    // Codex PR-1a P2-2: legacy rows may have keys the panel-level addKey
    // regex would reject today. Server-side replace must not lock them out.
    const res = await postJson('/edge/app/schema/blueprint_output_order/replace', {
      blueprint_id: 'bp-1',
      expected: [],
      next: [{ output_key: '1legacy-key_with-hyphen', sort_order: 1 }],
    });
    assert.equal(res.status, 200);
  });

  it('returns 400 when output_key exceeds VARCHAR(255)', async () => {
    const res = await postJson('/edge/app/schema/blueprint_output_order/replace', {
      blueprint_id: 'bp-1',
      expected: [],
      next: [{ output_key: 'x'.repeat(256), sort_order: 1 }],
    });
    assert.equal(res.status, 400);
  });

  it('returns 400 when output_key is empty', async () => {
    const res = await postJson('/edge/app/schema/blueprint_output_order/replace', {
      blueprint_id: 'bp-1',
      expected: [],
      next: [{ output_key: '', sort_order: 1 }],
    });
    assert.equal(res.status, 400);
  });
});
