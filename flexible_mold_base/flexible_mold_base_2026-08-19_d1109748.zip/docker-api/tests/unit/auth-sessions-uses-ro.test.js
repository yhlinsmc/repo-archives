/**
 * auth-sessions-uses-ro.test.js
 *
 * v3.2.40 PR-1 review-gate follow-up — the auth-sessions route runs three
 * SELECTs (data / count / today) over login_audit via Promise.all on a single
 * connection. Routing to pool.rw would silently work today but defeats the
 * RW/RO split intent. This test pins the pool.ro routing so a future refactor
 * that flips it back to rw (or to the deprecated shim) fails loud.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../src/edge/db');
const routeKey = require.resolve('../../src/edge/routes/platform/auth-sessions');

let calls;

function makeSpy() {
  calls = { rw: 0, ro: 0, roQueries: [] };
  return {
    rw: {
      async getConnection() {
        calls.rw++;
        throw new Error('wrong facade: auth-sessions must use pool.ro, not pool.rw');
      },
    },
    ro: {
      async getConnection() {
        calls.ro++;
        return {
          async query(sql, params) {
            calls.roQueries.push({ sql, params });
            if (/COUNT\(DISTINCT/.test(sql)) return [{ total: 0 }];
            if (/today_count/.test(sql)) return [{ today_count: 0 }];
            return []; // data query
          },
          release() { /* noop */ },
        };
      },
    },
  };
}

const poolSpy = {};

require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: {
    pool: poolSpy,
    t: (name) => `fmb_${name}`,
  },
};

const router = require('../../src/edge/routes/platform/auth-sessions');

let server;
let port;

before(async () => {
  Object.assign(poolSpy, makeSpy());
  const app = express();
  app.use(express.json());
  // requireAdmin reads req.user.role — stub an admin user so the route runs.
  app.use((req, _res, next) => { req.user = { id: 't', role: 'admin' }; next(); });
  app.use('/edge/platform/auth', router);
  await new Promise((resolve) => {
    server = app.listen(0, '127.0.0.1', () => {
      port = server.address().port;
      resolve();
    });
  });
});

after(async () => {
  await new Promise((resolve) => server.close(resolve));
  delete require.cache[dbKey];
  delete require.cache[routeKey];
});

beforeEach(() => {
  Object.assign(poolSpy, makeSpy());
});

function getJson(port_, path_) {
  return new Promise((resolve, reject) => {
    const req = http.request(
      { host: '127.0.0.1', port: port_, path: path_, method: 'GET' },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          const raw = Buffer.concat(chunks).toString('utf-8');
          let json = null;
          try { json = JSON.parse(raw); } catch { /* noop */ }
          resolve({ status: res.statusCode, raw, json });
        });
      },
    );
    req.on('error', reject);
    req.end();
  });
}

describe('GET /edge/platform/auth/sessions — v3.2.40 pool.ro pin', () => {
  it('all three aggregates hit pool.ro (not pool.rw)', async () => {
    const res = await getJson(port, '/edge/platform/auth/sessions');

    assert.equal(res.status, 200, `expected 200, got ${res.status}: ${res.raw}`);
    assert.equal(calls.rw, 0, 'pool.rw.getConnection MUST NOT be called (would throw)');
    assert.equal(calls.ro, 1, 'pool.ro.getConnection called exactly once');
    assert.equal(calls.roQueries.length, 3, 'data + count + today queries all on same ro conn');
    assert.ok(calls.roQueries.some((q) => /FROM `fmb_login_audit`/.test(q.sql)));
  });
});
