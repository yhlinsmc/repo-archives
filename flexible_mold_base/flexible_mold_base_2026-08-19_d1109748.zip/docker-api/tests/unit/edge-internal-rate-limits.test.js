// docker-api/tests/unit/edge-internal-rate-limits.test.js
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../src/edge/db');
let poolReady = true;
let roRows = [];
let roShouldThrow = false;

require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: {
    pool: { ro: { query: async () => { if (roShouldThrow) throw new Error('ro fail'); return roRows; } } },
    t: (n) => `fmb_${n}`,
    isPoolReady: () => poolReady,
  },
};
// config is imported by system.js for auth-mode; stub the bits it reads.
const configKey = require.resolve('../../src/shared/config');
require.cache[configKey] = {
  id: configKey, filename: configKey, loaded: true,
  exports: {
    resolveAuthMode: () => 'local', resolveAuthModeAsync: async () => 'local',
    getAuthModeSource: () => 'env_default', probeKeycloakDiscovery: async () => false,
  },
};

let server, port;
before(async () => {
  const router = require('../../src/edge/routes/internal/system');
  const app = express();
  app.use('/edge/internal/system', router);
  await new Promise((r) => { server = app.listen(0, '127.0.0.1', () => { port = server.address().port; r(); }); });
});
after(async () => { await new Promise((r) => server.close(r)); delete require.cache[dbKey]; delete require.cache[configKey]; });
beforeEach(() => { poolReady = true; roRows = []; roShouldThrow = false; });

function getJson(path_) {
  return new Promise((resolve, reject) => {
    const req = http.request({ host: '127.0.0.1', port, path: path_, method: 'GET' }, (res) => {
      const chunks = [];
      res.on('data', (c) => chunks.push(c));
      res.on('end', () => { let j = null; try { j = JSON.parse(Buffer.concat(chunks)); } catch {} resolve({ status: res.statusCode, json: j }); });
    });
    req.on('error', reject); req.end();
  });
}

describe('GET /edge/internal/system/rate-limits', () => {
  it('returns parsed ints for set keys, null for unset', async () => {
    roRows = [
      { key: 'rate_limit_general_max', value: '1500' },
      { key: 'rate_limit_connector_fetch_max', value: '40' },
    ];
    const res = await getJson('/edge/internal/system/rate-limits');
    assert.equal(res.status, 200);
    assert.deepEqual(res.json.data, { general: 1500, connectorFetch: 40, connectorWrite: null, auditSearch: null });
  });
  it('returns all-null when pool not ready', async () => {
    poolReady = false;
    const res = await getJson('/edge/internal/system/rate-limits');
    assert.deepEqual(res.json.data, { general: null, connectorFetch: null, connectorWrite: null, auditSearch: null });
  });
  it('returns all-null (no 500) when the read throws', async () => {
    roShouldThrow = true;
    const res = await getJson('/edge/internal/system/rate-limits');
    assert.equal(res.status, 200);
    assert.deepEqual(res.json.data, { general: null, connectorFetch: null, connectorWrite: null, auditSearch: null });
  });
  it('coerces a non-numeric stored value to null', async () => {
    roRows = [{ key: 'rate_limit_general_max', value: '"oops"' }];
    const res = await getJson('/edge/internal/system/rate-limits');
    assert.equal(res.json.data.general, null);
  });
});
