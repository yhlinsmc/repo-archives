/**
 * clear-table-helper.test.js — v3.2.84
 *
 * Unit tests for the extracted `truncateOrDeleteWithFallback` helper.
 * Stubs the db module so the helper can be exercised in isolation
 * without booting any route or pool.
 */
const { describe, it, beforeEach } = require('node:test');
const assert = require('node:assert/strict');

const dbKey = require.resolve('../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey,
  filename: dbKey,
  loaded: true,
  exports: {
    t: (name) => `fmb_${name}`,
  },
};

const {
  truncateOrDeleteWithFallback,
  ENGINE_FALLBACK_ERRNOS,
  INFRA_FALLBACK_ERRNOS,
  insertClearAudit,
  safeInsertAudit,
  failAuditMeta,
} = require('../../src/edge/lib/clear-table');

function makeError(errno, message = 'mock-error') {
  const e = new Error(message);
  e.errno = errno;
  e.code = `ER_CODE_${errno}`;
  return e;
}

function makeConn(opts = {}) {
  const queries = [];
  return {
    queries,
    query: async (sql, params) => {
      queries.push({ sql, params });
      if (/TRUNCATE TABLE/.test(sql)) {
        if (opts.truncateError) throw opts.truncateError;
        return { affectedRows: 0 };
      }
      if (/^DELETE FROM/.test(sql)) {
        if (opts.deleteError) throw opts.deleteError;
        return { affectedRows: 0 };
      }
      if (/INSERT INTO/.test(sql)) {
        if (opts.auditError) throw opts.auditError;
        return { affectedRows: 1 };
      }
      return [];
    },
  };
}

const noopLogger = { warn: () => {}, error: () => {}, info: () => {} };

function auditMetas(conn) {
  return conn.queries
    .filter((q) => /INSERT INTO `fmb_feature_audit`/.test(q.sql))
    .map((q) => ({ eventType: q.params[1], metadata: JSON.parse(q.params[3]) }));
}

describe('truncateOrDeleteWithFallback', () => {
  it('TRUNCATE success path returns method=TRUNCATE + writes success audit', async () => {
    const conn = makeConn();
    const result = await truncateOrDeleteWithFallback(conn, {
      physicalTable: 'fmb_user_templates',
      logicalTable: 'user_templates',
      tableClass: 'engine',
      errnoSet: ENGINE_FALLBACK_ERRNOS,
      userId: 'admin-1',
      logger: noopLogger,
    });
    assert.deepEqual(result, { method: 'TRUNCATE' });
    const events = auditMetas(conn);
    assert.equal(events.length, 1);
    assert.equal(events[0].eventType, 'data_clear.success');
    assert.equal(events[0].metadata.table_class, 'engine');
    assert.equal(events[0].metadata.method, 'TRUNCATE');
  });

  it('errno 1142 → DELETE fallback returns method=DELETE + writes fallback_to_delete audit', async () => {
    const conn = makeConn({ truncateError: makeError(1142, 'denied') });
    const result = await truncateOrDeleteWithFallback(conn, {
      physicalTable: 'fmb_login_audit',
      logicalTable: 'login_audit',
      tableClass: 'infra',
      errnoSet: INFRA_FALLBACK_ERRNOS,
      userId: 'admin-1',
      logger: noopLogger,
    });
    assert.deepEqual(result, { method: 'DELETE', reasonErrno: 1142 });

    const deleteCall = conn.queries.find((q) => /^DELETE FROM `fmb_login_audit`/.test(q.sql));
    assert.ok(deleteCall);

    const events = auditMetas(conn);
    assert.equal(events.length, 1);
    assert.equal(events[0].eventType, 'data_clear.fallback_to_delete');
    assert.equal(events[0].metadata.table_class, 'infra');
    assert.equal(events[0].metadata.reason_errno, 1142);
  });

  it('errno 1227 → DELETE fallback (older MariaDB SUPER required)', async () => {
    const conn = makeConn({ truncateError: makeError(1227, 'SUPER required') });
    const result = await truncateOrDeleteWithFallback(conn, {
      physicalTable: 'fmb_users',
      logicalTable: 'users',
      tableClass: 'infra',
      errnoSet: INFRA_FALLBACK_ERRNOS,
      userId: null,
      logger: noopLogger,
    });
    assert.equal(result.reasonErrno, 1227);
  });

  it('engine errno 1701 → DELETE fallback (FK-referenced parent)', async () => {
    const conn = makeConn({ truncateError: makeError(1701, 'FK reference') });
    const result = await truncateOrDeleteWithFallback(conn, {
      physicalTable: 'fmb_blueprint_fields',
      logicalTable: 'blueprint_fields',
      tableClass: 'engine',
      errnoSet: ENGINE_FALLBACK_ERRNOS,
      userId: 'admin-1',
      logger: noopLogger,
    });
    assert.equal(result.reasonErrno, 1701);
    const events = auditMetas(conn);
    assert.equal(events[0].eventType, 'data_clear.fallback_to_delete');
  });

  it('infra errnoSet does NOT include 1701 — TRUNCATE 1701 propagates without DELETE attempt', async () => {
    // SAFETY: infra tables have no FKs so 1701 is impossible in production,
    // but if a DBA accidentally adds a FK to an infra table, the helper
    // must NOT silently DELETE — it should surface the error.
    const conn = makeConn({ truncateError: makeError(1701, 'FK reference') });
    await assert.rejects(
      () => truncateOrDeleteWithFallback(conn, {
        physicalTable: 'fmb_users',
        logicalTable: 'users',
        tableClass: 'infra',
        errnoSet: INFRA_FALLBACK_ERRNOS,
        userId: 'admin-1',
        logger: noopLogger,
      }),
      (err) => err.errno === 1701,
    );
    const deleteCall = conn.queries.find((q) => /^DELETE FROM/.test(q.sql));
    assert.equal(deleteCall, undefined, 'DELETE must NOT run when errno is outside errnoSet');
  });

  it('non-fallback errno (1146 ER_NO_SUCH_TABLE) propagates without DELETE attempt or audit', async () => {
    const conn = makeConn({ truncateError: makeError(1146, 'no such table') });
    await assert.rejects(
      () => truncateOrDeleteWithFallback(conn, {
        physicalTable: 'fmb_user_templates',
        logicalTable: 'user_templates',
        tableClass: 'engine',
        errnoSet: ENGINE_FALLBACK_ERRNOS,
        userId: 'admin-1',
        logger: noopLogger,
      }),
      (err) => err.errno === 1146,
    );
    const events = auditMetas(conn);
    // Helper does NOT write `data_clear.fail` itself — caller does.
    assert.equal(events.length, 0, 'helper must not write any audit on non-fallback errno');
  });

  it('DELETE failure after TRUNCATE 1142 throws the DELETE error and writes no success audit', async () => {
    const conn = makeConn({
      truncateError: makeError(1142, 'denied'),
      deleteError: makeError(1045, 'access denied for DELETE'),
    });
    await assert.rejects(
      () => truncateOrDeleteWithFallback(conn, {
        physicalTable: 'fmb_login_audit',
        logicalTable: 'login_audit',
        tableClass: 'infra',
        errnoSet: INFRA_FALLBACK_ERRNOS,
        userId: 'admin-1',
        logger: noopLogger,
      }),
      (err) => err.errno === 1045,
    );
    const events = auditMetas(conn);
    assert.equal(events.length, 0, 'no terminal audit on DELETE-fallback failure (caller writes fail)');
  });

  it('extraMeta is merged into audit metadata and survives both success and fallback paths', async () => {
    const conn = makeConn();
    await truncateOrDeleteWithFallback(conn, {
      physicalTable: 'fmb_user_templates',
      logicalTable: 'user_templates',
      tableClass: 'engine',
      errnoSet: ENGINE_FALLBACK_ERRNOS,
      userId: 'admin-1',
      extraMeta: { physicalTable: 'fmb_user_templates', requestedBy: 'unit-test' },
      logger: noopLogger,
    });
    const events = auditMetas(conn);
    assert.equal(events[0].metadata.physicalTable, 'fmb_user_templates');
    assert.equal(events[0].metadata.requestedBy, 'unit-test');
  });

  it('audit insert failure is swallowed via safeInsertAudit (logger.warn) without aborting', async () => {
    let warnCalled = false;
    const noisyLogger = {
      warn: () => { warnCalled = true; },
      error: () => {},
      info: () => {},
    };
    const conn = makeConn({ auditError: new Error('audit write failed') });
    const result = await truncateOrDeleteWithFallback(conn, {
      physicalTable: 'fmb_user_templates',
      logicalTable: 'user_templates',
      tableClass: 'engine',
      errnoSet: ENGINE_FALLBACK_ERRNOS,
      userId: 'admin-1',
      logger: noisyLogger,
    });
    // Helper should still return the success result even when audit failed.
    assert.deepEqual(result, { method: 'TRUNCATE' });
    assert.equal(warnCalled, true, 'logger.warn must fire when audit insert fails');
  });
});

describe('safeInsertAudit', () => {
  it('swallows insert errors and calls logger.warn', async () => {
    let warned = null;
    const logger = {
      warn: (obj, msg) => { warned = { obj, msg }; },
    };
    const conn = makeConn({ auditError: new Error('boom') });
    await safeInsertAudit(conn, {
      eventType: 'data_clear.attempt',
      userId: 'u',
      metadata: { table: 'x', table_class: 'infra' },
    }, logger);
    assert.ok(warned, 'logger.warn must fire');
    assert.match(warned.msg, /data_clear\.attempt audit insert failed/);
  });

  it('passes through to insertClearAudit on success path', async () => {
    const conn = makeConn();
    await safeInsertAudit(conn, {
      eventType: 'data_clear.success',
      userId: 'u',
      metadata: { table: 'x', table_class: 'engine' },
    }, noopLogger);
    const inserts = conn.queries.filter((q) => /INSERT INTO/.test(q.sql));
    assert.equal(inserts.length, 1);
    assert.equal(inserts[0].params[1], 'data_clear.success');
  });
});

describe('insertClearAudit', () => {
  it('parameterizes user_id null and serializes metadata as JSON', async () => {
    const conn = makeConn();
    await insertClearAudit(conn, {
      eventType: 'data_clear.fail',
      userId: null,
      metadata: { table_class: 'infra', errno: 1146 },
    });
    const insert = conn.queries.find((q) => /INSERT INTO `fmb_feature_audit`/.test(q.sql));
    assert.ok(insert);
    assert.equal(insert.params[1], 'data_clear.fail');
    assert.equal(insert.params[2], null);
    assert.deepEqual(JSON.parse(insert.params[3]), { table_class: 'infra', errno: 1146 });
  });

  it('serializes null metadata as null SQL value', async () => {
    const conn = makeConn();
    await insertClearAudit(conn, {
      eventType: 'data_clear.attempt',
      userId: 'admin-1',
      metadata: null,
    });
    const insert = conn.queries.find((q) => /INSERT INTO/.test(q.sql));
    assert.equal(insert.params[3], null);
  });
});

describe('errno-set constants', () => {
  it('engine includes 1142, 1227, 1701', () => {
    assert.equal(ENGINE_FALLBACK_ERRNOS.includes(1142), true);
    assert.equal(ENGINE_FALLBACK_ERRNOS.includes(1227), true);
    assert.equal(ENGINE_FALLBACK_ERRNOS.includes(1701), true);
  });

  it('infra includes 1142, 1227 but NOT 1701 (no FKs on infra)', () => {
    assert.equal(INFRA_FALLBACK_ERRNOS.includes(1142), true);
    assert.equal(INFRA_FALLBACK_ERRNOS.includes(1227), true);
    assert.equal(INFRA_FALLBACK_ERRNOS.includes(1701), false);
  });

  it('errno arrays are truly frozen — push throws in strict mode', () => {
    assert.equal(Object.isFrozen(ENGINE_FALLBACK_ERRNOS), true);
    assert.equal(Object.isFrozen(INFRA_FALLBACK_ERRNOS), true);
    assert.throws(() => ENGINE_FALLBACK_ERRNOS.push(9999), /not extensible|read only/i);
    assert.throws(() => INFRA_FALLBACK_ERRNOS.push(9999), /not extensible|read only/i);
  });
});

describe('failAuditMeta', () => {
  it('extracts errno + sqlState + message from canonical MariaDB error', () => {
    const err = Object.assign(new Error('TRUNCATE command denied'), {
      errno: 1142, sqlState: '42000', code: 'ER_TABLEACCESS_DENIED_ERROR',
    });
    assert.deepEqual(failAuditMeta(err), {
      errno: 1142,
      sqlState: '42000',
      message: 'ER_TABLEACCESS_DENIED_ERROR',
    });
  });

  it('falls back to null + Error.message when errno is missing (network reset / driver error)', () => {
    const err = new Error('socket hang up');
    assert.deepEqual(failAuditMeta(err), {
      errno: null,
      sqlState: null,
      message: 'socket hang up',
    });
  });

  it('returns CLEAR_FAILED placeholder when err is null/undefined', () => {
    assert.deepEqual(failAuditMeta(null), {
      errno: null,
      sqlState: null,
      message: 'CLEAR_FAILED',
    });
  });
});

describe('safeInsertAudit (logger guard)', () => {
  it('does not throw when logger is undefined (degrades to NOOP_LOGGER)', async () => {
    const conn = makeConn({ auditError: new Error('audit fail') });
    // Pass undefined as logger — must not raise TypeError.
    await safeInsertAudit(conn, {
      eventType: 'data_clear.attempt',
      userId: 'u',
      metadata: { table: 'x', table_class: 'infra' },
    }, undefined);
    // success means we got here without throwing
    assert.ok(true);
  });
});
