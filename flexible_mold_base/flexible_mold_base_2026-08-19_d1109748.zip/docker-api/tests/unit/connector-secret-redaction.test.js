const { test } = require('node:test');
const assert = require('node:assert/strict');
const { Writable } = require('node:stream');
const pino = require('pino');
const { redactConfig } = require('../../src/shared/lib/logger');

test('prepared.headers is redacted in logs', () => {
  let out = '';
  const sink = new Writable({ write(c, _e, cb) { out += c.toString(); cb(); } });
  const log = pino({ redact: redactConfig }, sink);
  log.info({ prepared: { headers: { Authorization: 'Bearer SEKRET', 'X-Api-Key': 'KKK' } } }, 'prep');
  assert.equal(out.includes('SEKRET'), false);
  assert.equal(out.includes('KKK'), false);
});

test('resolved.headers is redacted in logs', () => {
  let out = '';
  const sink = new Writable({ write(c, _e, cb) { out += c.toString(); cb(); } });
  const log = pino({ redact: redactConfig }, sink);
  log.info({ resolved: { headers: { Authorization: 'Bearer SEKRET2' } } }, 'res');
  assert.equal(out.includes('SEKRET2'), false);
});
