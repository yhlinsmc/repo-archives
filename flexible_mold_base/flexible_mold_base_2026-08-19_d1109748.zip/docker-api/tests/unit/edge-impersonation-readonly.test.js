const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const { impersonationReadOnly } = require('../../src/edge/middleware/impersonation-readonly');

function mockRes() {
  return {
    statusCode: 200,
    body: null,
    status(c) { this.statusCode = c; return this; },
    json(b) { this.body = b; return this; },
  };
}

describe('impersonationReadOnly (edge)', () => {
  it('blocks a non-GET request when impersonated', () => {
    const req = { method: 'POST', path: '/edge/app/schema/user_templates', user: { id: 'u1', impersonated: true } };
    const res = mockRes();
    let nextCalled = false;
    impersonationReadOnly(req, res, () => { nextCalled = true; });
    assert.equal(nextCalled, false);
    assert.equal(res.statusCode, 403);
    assert.equal(res.body.error.code, 'IMPERSONATION_READ_ONLY');
  });

  it('allows a GET request when impersonated', () => {
    const req = { method: 'GET', path: '/edge/app/schema/user_templates', user: { id: 'u1', impersonated: true } };
    const res = mockRes();
    let nextCalled = false;
    impersonationReadOnly(req, res, () => { nextCalled = true; });
    assert.equal(nextCalled, true);
  });

  it('allows a HEAD request when impersonated', () => {
    const req = { method: 'HEAD', path: '/edge/app/schema/x', user: { id: 'u1', impersonated: true } };
    const res = mockRes();
    let nextCalled = false;
    impersonationReadOnly(req, res, () => { nextCalled = true; });
    assert.equal(nextCalled, true);
  });

  it('does not touch a normal (non-impersonated) write', () => {
    const req = { method: 'POST', path: '/edge/app/schema/x', user: { id: 'admin', impersonated: false } };
    const res = mockRes();
    let nextCalled = false;
    impersonationReadOnly(req, res, () => { nextCalled = true; });
    assert.equal(nextCalled, true);
  });

  it('does not touch a request with no user', () => {
    const req = { method: 'POST', path: '/edge/health', user: null };
    const res = mockRes();
    let nextCalled = false;
    impersonationReadOnly(req, res, () => { nextCalled = true; });
    assert.equal(nextCalled, true);
  });

  for (const method of ['PUT', 'PATCH', 'DELETE']) {
    it(`blocks a ${method} request when impersonated`, () => {
      const req = { method, path: '/edge/app/schema/user_templates', user: { id: 'u1', impersonated: true } };
      const res = mockRes();
      let nextCalled = false;
      impersonationReadOnly(req, res, () => { nextCalled = true; });
      assert.equal(nextCalled, false);
      assert.equal(res.statusCode, 403);
      assert.equal(res.body.error.code, 'IMPERSONATION_READ_ONLY');
    });
  }

  it('allows an exempt S2S machinery POST (/edge/internal/*) even when impersonated', () => {
    const req = { method: 'POST', path: '/edge/internal/auth/identity-resolve', user: { id: 'u1', impersonated: true } };
    const res = mockRes();
    let nextCalled = false;
    impersonationReadOnly(req, res, () => { nextCalled = true; });
    assert.equal(nextCalled, true);
  });

  it('allows an exempt S2S machinery POST (/edge/platform/access-check) even when impersonated', () => {
    const req = { method: 'POST', path: '/edge/platform/access-check', user: { id: 'u1', impersonated: true } };
    const res = mockRes();
    let nextCalled = false;
    impersonationReadOnly(req, res, () => { nextCalled = true; });
    assert.equal(nextCalled, true);
  });

  it('allows the read-only field_options/by-fields POST even when impersonated', () => {
    const req = { method: 'POST', path: '/edge/app/schema/field_options/by-fields', user: { id: 'u1', impersonated: true } };
    const res = mockRes();
    let nextCalled = false;
    impersonationReadOnly(req, res, () => { nextCalled = true; });
    assert.equal(nextCalled, true);
  });

  it('still blocks a sibling write POST (field_options/replace) when impersonated', () => {
    const req = { method: 'POST', path: '/edge/app/schema/field_options/replace', user: { id: 'u1', impersonated: true } };
    const res = mockRes();
    let nextCalled = false;
    impersonationReadOnly(req, res, () => { nextCalled = true; });
    assert.equal(nextCalled, false);
    assert.equal(res.statusCode, 403);
  });

  it('allows the read-only blueprint_fields/by-blueprints POST even when impersonated', () => {
    const req = { method: 'POST', path: '/edge/app/schema/blueprint_fields/by-blueprints', user: { id: 'u1', impersonated: true } };
    const res = mockRes();
    let nextCalled = false;
    impersonationReadOnly(req, res, () => { nextCalled = true; });
    assert.equal(nextCalled, true);
  });

  it('still blocks a sibling write POST (blueprint_fields/delete-renormalize) when impersonated', () => {
    const req = { method: 'POST', path: '/edge/app/schema/blueprint_fields/delete-renormalize', user: { id: 'u1', impersonated: true } };
    const res = mockRes();
    let nextCalled = false;
    impersonationReadOnly(req, res, () => { nextCalled = true; });
    assert.equal(nextCalled, false);
    assert.equal(res.statusCode, 403);
  });

  it('allows the read-only orphan scan POST (field-data-orphans) even when impersonated', () => {
    const req = { method: 'POST', path: '/edge/app/schema/field-data-orphans', user: { id: 'u1', impersonated: true } };
    const res = mockRes();
    let nextCalled = false;
    impersonationReadOnly(req, res, () => { nextCalled = true; });
    assert.equal(nextCalled, true);
  });

  it('still blocks the orphan clear DELETE (field-data-orphans/:t/:k) when impersonated', () => {
    const req = { method: 'DELETE', path: '/edge/app/schema/field-data-orphans/t1/colors', user: { id: 'u1', impersonated: true } };
    const res = mockRes();
    let nextCalled = false;
    impersonationReadOnly(req, res, () => { nextCalled = true; });
    assert.equal(nextCalled, false);
    assert.equal(res.statusCode, 403);
  });
});
