/**
 * editor-role-value-guards.test.js — v3.2.99 PR-A Bug-4
 *
 * Verifies the new role gate + value guard plumbing in createCrudRoutes:
 *   - Editor can POST blueprint_fields (allowedRoles: admin+editor)
 *   - Editor cannot POST hierarchy_nodes with node_type='category' (F3)
 *   - Editor cannot POST hierarchy_nodes with node_type='release' (F3)
 *   - Editor CAN POST hierarchy_nodes with node_type='blueprint'
 *   - Editor cannot reach the same top tier by OMITTING node_type (the database
 *     supplies the first ENUM member, 'category', for a column the guard never
 *     judged because the key was absent)
 *   - Admin still bypasses value guards
 *   - Plain user still 403'd from any of the above
 *   - A null NAMING a NOT NULL guarded column is an unstorable value, refused
 *     with the same stable 400 on both verbs and for the role the blocklist does
 *     not name (the editor's create keeps its own 403 — for them a null is the
 *     omission the guard exists to catch, judged before the column is)
 *
 * EVERY DRIVER HERE IS A DOUBLE. Nothing in this file observes what a column
 * actually does with a value; the first case pins the two schema facts the rest
 * of it assumes, and the real answers live in
 * tests/integration/hierarchy-node-type-omission-real-db.test.js.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const { fixtureUserId } = require('../helpers/fixture-ids');
const assert = require('node:assert/strict');
const { answerCollationProbe } = require('../helpers/collation-probe');
const { answerParentIdProbe } = require('../helpers/parent-id-probe');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../src/edge/db');
const { buildEngineTableDDLs } = require('../../src/table-ddls');
const { TABLES } = require('../../src/shared/constants');
const { enumMembersFor, columnNullabilityFor } = require('../../src/edge/lib/schema-manifest');

// The column set the PUT path probes, DERIVED from the DDL rather than listed
// here: a hand-written double drops a column silently, and the gate it feeds
// drops any body key the double forgot — which is a green test reporting a
// write that never happened.
function columnsFromDdl(table) {
  const ddl = buildEngineTableDDLs((n) => n)
    .find((sql) => new RegExp(`CREATE TABLE IF NOT EXISTS \`${table}\``).test(sql));
  if (!ddl) throw new Error(`no DDL for ${table}`);
  const body = ddl.slice(ddl.indexOf('(') + 1);
  const out = [];
  for (let line of body.split('\n')) {
    line = line.replace(/--.*$/, '').trim();
    if (!line || /^(PRIMARY|UNIQUE|KEY|INDEX|CONSTRAINT|FOREIGN|CHECK|\))/i.test(line)) continue;
    const m = line.match(/^`?([a-z_][a-z0-9_]*)`?\s+[A-Za-z]/);
    if (m) out.push({ COLUMN_NAME: m[1] });
  }
  if (!out.length) throw new Error(`parsed no columns for ${table}`);
  return out;
}

let conn;
function makeConn(scripts) {
  const queries = [];
  return {
    queries,
    async query(sql, params) {
      queries.push({ sql, params });
      for (const [matcher, response] of scripts) {
        if (matcher.test(sql)) {
          return typeof response === 'function' ? response(sql, params) : response;
        }
      }
      // Linked-blueprint write guard (S1/S2) probes; default to "not linked"
      // so these pre-existing write tests are unaffected.
      if (/SELECT linked_blueprint_id FROM/.test(sql)) return [];
      if (/ AS bid FROM/.test(sql) || / AS fk FROM/.test(sql)) return [];
      // The (blueprint, key) clash probe both write paths now run before they can
      // create the duplicate the migration endpoint would turn into a merge.
      // Nothing collides in these fixtures; the case that does is settled on a
      // real database (tests/integration/blueprint-field-write-real-db.test.js).
      if (/FROM `fmb_blueprint_fields`/i.test(sql) && /`?field_key`? = \?/i.test(sql)
          && /LIMIT 1/i.test(sql)) {
        return [];
      }
      // The factory asks which spelling the parent row really carries before it
      // binds one. Answered rather than thrown on — see tests/helpers.
      const parentId = answerParentIdProbe(sql, params);
      if (parentId) return parentId;
      // "Does this column name the caller" is asked of the engine now, so the
      // double sees the three probe statements — answered the way the column's
      // collation answers them, never waved through.
      const probed = answerCollationProbe(sql, params);
      if (probed) return probed;
      throw new Error(`Unmatched query: ${sql.slice(0, 80)}`);
    },
    release() { /* noop */ },
    async beginTransaction() {},
    async commit() {},
    async rollback() {},
  };
}

const poolSpy = {
  rw: { async getConnection() { return conn; } },
  ro: { async getConnection() { return conn; } },
};

require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: {
    pool: poolSpy,
    t: (name) => `fmb_${name}`,
    getDynamicPool: async () => poolSpy,
  },
};

const router = require('../../src/edge/routes/app/schema');

let server;
let port;

function makeApp(role) {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => {
    req.user = { id: fixtureUserId(role), role };
    next();
  });
  app.use('/edge/app/schema', router);
  return app;
}

let activeApp;
// A second server on the administrator identity. The guard is keyed by role, so
// "an editor is refused" is only half a claim — the other half is that the role
// the list does not name is untouched, and that cannot be seen from one server.
let adminServer;
let adminPort;
before(async () => {
  activeApp = makeApp('editor');
  await new Promise((resolve) => {
    server = activeApp.listen(0, '127.0.0.1', () => {
      port = server.address().port;
      resolve();
    });
  });
  await new Promise((resolve) => {
    adminServer = makeApp('admin').listen(0, '127.0.0.1', () => {
      adminPort = adminServer.address().port;
      resolve();
    });
  });
});

after(async () => {
  await new Promise((resolve) => server.close(resolve));
  await new Promise((resolve) => adminServer.close(resolve));
  delete require.cache[dbKey];
});

beforeEach(() => { conn = null; });

function send(method, targetPort, path, body) {
  return new Promise((resolve, reject) => {
    const data = JSON.stringify(body);
    const req = http.request({
      method, host: '127.0.0.1', port: targetPort, path,
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(data) },
    }, (res) => {
      let raw = '';
      res.on('data', (chunk) => { raw += chunk; });
      res.on('end', () => resolve({ status: res.statusCode, body: raw ? JSON.parse(raw) : null }));
    });
    req.on('error', reject);
    req.write(data);
    req.end();
  });
}

const post = (path, body) => send('POST', port, path, body);
const postAsAdmin = (path, body) => send('POST', adminPort, path, body);
const put = (path, body) => send('PUT', port, path, body);
const putAsAdmin = (path, body) => send('PUT', adminPort, path, body);

const insertsIn = (c) => c.queries.filter((q) => /^\s*INSERT INTO/i.test(q.sql));
const updatesIn = (c) => c.queries.filter((q) => /^\s*UPDATE `fmb_hierarchy_nodes`/i.test(q.sql));

// The scripts a hierarchy_nodes PUT needs to reach its UPDATE. Scripted to
// SUCCEED so a case that gets past the guard reports "the write was allowed"
// rather than an unscripted query surfacing as a 500 — a refusal that happens
// for the wrong reason is not the property under test.
const putScripts = () => [
  [/SELECT node_type, owner_id, linked_blueprint_id/i, [{
    node_type: 'blueprint', owner_id: '405279b5-48c7-4bd5-8427-69d6ff5556a7', linked_blueprint_id: null,
    transformer_id: null, transformer_version: null,
  }]],
  [/SELECT DATABASE\(\) AS db/i, [{ db: 'test' }]],
  [/SELECT COLUMN_NAME FROM information_schema/i, columnsFromDdl('hierarchy_nodes')],
  [/^UPDATE `fmb_hierarchy_nodes`/i, { affectedRows: 1 }],
  [/SELECT \* FROM `fmb_hierarchy_nodes`/i, [{ id: '09d70428-63f6-4a1b-8061-e0d9682679c3', node_type: 'category', parent_id: null, name: 'x' }]],
];

// Every spelling of the forbidden tiers that this database reads as the tier
// itself. A MariaDB ENUM comparison is case-insensitive under the column's
// collation, ignores a trailing space, and additionally accepts an INTEGER as a
// 1-based member index — so `1` IS 'category', the first member. None of these
// is identical to any entry in the mount's blocklist, so a guard that decides
// with a JavaScript comparison passes every one of them straight to a statement
// that stores the very value the list denies.
const FOLDING_SPELLINGS = [
  ["'Category'", 'Category'],
  ["'CATEGORY'", 'CATEGORY'],
  ["'cAtEgOrY'", 'cAtEgOrY'],
  ["'category ' (trailing space)", 'category '],
  ['1 (the ENUM member index of category)', 1],
  ["'1'", '1'],
  ['true', true],
  ["['category']", ['category']],
  ["'Release' (the other forbidden tier)", 'Release'],
];

describe('editor role gate + valueGuards (v3.2.99 PR-A)', () => {
  it('the column every case below is written about still has the shape they assume', () => {
    // EVERY DRIVER IN THIS FILE IS A DOUBLE, so nothing here can notice that the
    // column moved. The cases below name four tiers as literals and assert a
    // refusal that only a NOT NULL column earns; if either fact changes, the
    // mock keeps answering exactly as scripted and every case keeps passing
    // while describing a column that no longer exists in that shape. So the two
    // premises are read from the DDL and stated here, once, where they fail
    // loudly instead of quietly.
    assert.deepEqual(
      enumMembersFor(TABLES.HIERARCHY_NODES, 'node_type'),
      ['category', 'release', 'blueprint', 'variant'],
      'the tiers this file names are no longer the members the column declares',
    );
    assert.equal(
      columnNullabilityFor(TABLES.HIERARCHY_NODES, 'node_type'), 'NO',
      'node_type is no longer NOT NULL — the null cases below assert a refusal that '
      + 'only a NOT NULL column earns, and a nullable column must keep accepting null',
    );
  });

  it('editor can POST blueprint_fields when parent blueprint is shared', async () => {
    conn = makeConn([
      // PR-B Codex P1 follow-up: editor POST first checks parent blueprint owner
      [/SELECT j0\.`owner_id` AS owner_id\s+FROM `fmb_hierarchy_nodes` j0/i, [{ owner_id: null }]],
      [/^INSERT INTO `fmb_blueprint_fields`/i, { affectedRows: 1 }],
      [/SELECT \* FROM `fmb_blueprint_fields`/i, [{ id: '2ce8ba8e-83f5-41ee-8246-a2265095b549', field_type: 'text', blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26' }]],
    ]);
    const res = await post('/edge/app/schema/blueprint_fields', { blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', field_type: 'text', field_key: 'k', field_label: 'L' });
    assert.equal(res.status, 200);
  });

  it('editor cannot POST blueprint_fields when parent blueprint owned by other editor', async () => {
    conn = makeConn([
      // Parent is owned by editor-2, not editor-1 (test caller). Pre-check returns 403.
      [/SELECT j0\.`owner_id` AS owner_id\s+FROM `fmb_hierarchy_nodes` j0/i, [{ owner_id: '2af146d0-081f-4869-8a8f-3bf248676df8' }]],
    ]);
    const res = await post('/edge/app/schema/blueprint_fields', { blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', field_type: 'text', field_key: 'k', field_label: 'L' });
    assert.equal(res.status, 403);
    assert.match(res.body.error.message, /parent row is not owned/i);
  });

  it('editor cannot POST hierarchy_nodes with node_type=category', async () => {
    conn = makeConn([]);
    const res = await post('/edge/app/schema/hierarchy_nodes', { parent_id: null, node_type: 'category', name: 'evil' });
    assert.equal(res.status, 403);
    assert.equal(res.body.error.code, 'VALUE_GUARD');
    assert.match(res.body.error.message, /node_type='category'/);
  });

  it('editor cannot POST hierarchy_nodes with legacy node_type=generation (transition guard)', async () => {
    conn = makeConn([]);
    const res = await post('/edge/app/schema/hierarchy_nodes', { parent_id: null, node_type: 'generation', name: 'evil' });
    assert.equal(res.status, 403);
    assert.equal(res.body.error.code, 'VALUE_GUARD');
    assert.match(res.body.error.message, /node_type='generation'/);
  });

  it('editor cannot POST hierarchy_nodes with node_type=release', async () => {
    conn = makeConn([]);
    const res = await post('/edge/app/schema/hierarchy_nodes', { parent_id: '352e336b-7b60-49a0-88b7-27f72982c793', node_type: 'release', name: 'evil' });
    assert.equal(res.status, 403);
    assert.equal(res.body.error.code, 'VALUE_GUARD');
  });

  it('editor cannot POST hierarchy_nodes by leaving node_type out of the body', async () => {
    // THE SAME ESCALATION, WITH NO SPELLING AT ALL. The guard decides on
    // `data[col] === undefined`, so an absent key means it does not run — while
    // the INSERT that follows simply omits the column and the database fills it
    // with the first member of the ENUM, 'category'. That is the top tier this
    // list exists to deny. Scripted so the INSERT would SUCCEED if it were
    // reached: the failure this test reports must be "the create was allowed",
    // not an unscripted query surfacing as a 500.
    conn = makeConn([
      [/^INSERT INTO `fmb_hierarchy_nodes`/i, { affectedRows: 1 }],
      [/SELECT \* FROM `fmb_hierarchy_nodes`/i, [{ id: '4f4b2d83-7b9c-4de9-88c2-4c990ab7931e', node_type: 'category', parent_id: null, name: 'omitted' }]],
    ]);
    const res = await post('/edge/app/schema/hierarchy_nodes', { name: 'omitted' });
    assert.equal(res.status, 403, `an editor created a node without naming its type: ${JSON.stringify(res.body)}`);
    assert.equal(res.body.error.code, 'VALUE_GUARD');
    assert.match(res.body.error.message, /node_type/);
    assert.deepEqual(insertsIn(conn), [], 'the refused create still reached the INSERT');
  });

  it('admin CAN still POST hierarchy_nodes without node_type — the requirement is the guard, not a new column rule', async () => {
    // The list names editor and nobody else, so an administrator must reach the
    // database exactly as before and let it supply 'category'. A create-time
    // requirement written as a column rule rather than a guard rule would break
    // this, and nothing else in the suite would notice.
    conn = makeConn([
      [/^INSERT INTO `fmb_hierarchy_nodes`/i, { affectedRows: 1 }],
      [/SELECT \* FROM `fmb_hierarchy_nodes`/i, [{ id: '86bc1468-ab91-41d9-8103-0faea13b33ea', node_type: 'category', parent_id: null, name: 'admin node' }]],
    ]);
    const res = await postAsAdmin('/edge/app/schema/hierarchy_nodes', { name: 'admin node' });
    assert.equal(res.status, 200, `an administrator was refused: ${JSON.stringify(res.body)}`);
    assert.equal(insertsIn(conn).length, 1, 'the administrator create did not reach the INSERT');
  });

  it('editor PUT that omits node_type still lands — absence is only judged on create', async () => {
    // An update names the columns it changes; a column it omits is not written,
    // so nothing forbidden can land by omission there. Requiring the column on
    // both verbs would break every partial edit the Hierarchy Manager makes.
    conn = makeConn([
      [/SELECT node_type, owner_id, linked_blueprint_id/i, [{
        node_type: 'blueprint', owner_id: '405279b5-48c7-4bd5-8427-69d6ff5556a7', linked_blueprint_id: null,
        transformer_id: null, transformer_version: null,
      }]],
      [/SELECT DATABASE\(\) AS db/i, [{ db: 'test' }]],
      [/SELECT COLUMN_NAME FROM information_schema/i, columnsFromDdl('hierarchy_nodes')],
      [/^UPDATE `fmb_hierarchy_nodes`/i, { affectedRows: 1 }],
      [/SELECT \* FROM `fmb_hierarchy_nodes`/i, [{ id: 'a02e1bcd-9500-47f0-8fd5-196a1c6a5e16', node_type: 'blueprint', parent_id: '48f859ab-1dfc-4639-8875-06cc2270da1b', name: 'renamed' }]],
    ]);
    const res = await put('/edge/app/schema/hierarchy_nodes/a02e1bcd-9500-47f0-8fd5-196a1c6a5e16', { name: 'renamed' });
    assert.equal(res.status, 200, `a partial update was refused: ${JSON.stringify(res.body)}`);
  });

  it('editor CAN POST hierarchy_nodes with node_type=blueprint', async () => {
    conn = makeConn([
      [/^INSERT INTO `fmb_hierarchy_nodes`/i, { affectedRows: 1 }],
      [/SELECT \* FROM `fmb_hierarchy_nodes`/i, [{ id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', node_type: 'blueprint', parent_id: '48f859ab-1dfc-4639-8875-06cc2270da1b', name: 'BP' }]],
    ]);
    const res = await post('/edge/app/schema/hierarchy_nodes', { parent_id: '48f859ab-1dfc-4639-8875-06cc2270da1b', node_type: 'blueprint', name: 'BP' });
    assert.equal(res.status, 200);
  });

  // THE SAME ESCALATION, SPELLED SO THE COMPARISON MISSES IT. The two routes
  // already closed here are "the value, named" and "the value, not named at
  // all". This is the third: the value named in a spelling the blocklist does
  // not contain and the column does not distinguish. The guard's decision is a
  // JavaScript comparison against a list of four lower-case strings; the column
  // it defends is a database ENUM, whose notion of equality is neither
  // case-sensitive nor confined to strings.
  for (const [label, value] of FOLDING_SPELLINGS) {
    it(`editor cannot POST hierarchy_nodes with node_type spelled ${label}`, async () => {
      conn = makeConn([
        [/^INSERT INTO `fmb_hierarchy_nodes`/i, { affectedRows: 1 }],
        [/SELECT \* FROM `fmb_hierarchy_nodes`/i, [{ id: '4f4b2d83-7b9c-4de9-88c2-4c990ab7931e', node_type: 'category', parent_id: null, name: 'evil' }]],
      ]);
      const res = await post('/edge/app/schema/hierarchy_nodes', { parent_id: null, node_type: value, name: 'evil' });
      assert.notEqual(
        res.status, 200,
        `an editor created a top-tier node by spelling the value ${label}: ${JSON.stringify(res.body)}`,
      );
      assert.deepEqual(insertsIn(conn), [], 'the refused create still reached the INSERT');
    });

    it(`editor cannot PUT hierarchy_nodes to node_type spelled ${label}`, async () => {
      // The update path reaches the same row from the other side: create the
      // tier the editor is allowed to hold, then move it to the tier they are
      // not. The guard runs on both verbs and must judge the value on both.
      conn = makeConn(putScripts());
      const res = await put('/edge/app/schema/hierarchy_nodes/09d70428-63f6-4a1b-8061-e0d9682679c3', { node_type: value });
      assert.notEqual(
        res.status, 200,
        `an editor moved a node to a top tier by spelling the value ${label}: ${JSON.stringify(res.body)}`,
      );
      assert.deepEqual(updatesIn(conn), [], 'the refused update still reached the UPDATE');
    });
  }

  it('editor cannot POST hierarchy_nodes with node_type set to null', async () => {
    // THE OMISSION ROUTE, WRITTEN OUT. `null` on a create is the same statement
    // as leaving the key out — "I am not choosing; let the column decide" — and
    // the create-time requirement above judges only `undefined`. That the row
    // does not land today is a fact about THIS column being NOT NULL, not about
    // the guard: the same body against a nullable guarded column with a default
    // would take the default the guard exists to deny, having been asked and
    // having said nothing.
    conn = makeConn([
      [/^INSERT INTO `fmb_hierarchy_nodes`/i, { affectedRows: 1 }],
      [/SELECT \* FROM `fmb_hierarchy_nodes`/i, [{ id: '352df09b-11d0-4f26-80b5-81ddb433edae', node_type: 'category', parent_id: null, name: 'nulled' }]],
    ]);
    const res = await post('/edge/app/schema/hierarchy_nodes', { name: 'nulled', node_type: null });
    assert.equal(res.status, 403, `an editor created a node while naming no type: ${JSON.stringify(res.body)}`);
    assert.equal(res.body.error.code, 'VALUE_GUARD');
    assert.deepEqual(insertsIn(conn), [], 'the refused create still reached the INSERT');
  });

  it('admin POSTing node_type null gets the same stable 400, not the database error', async () => {
    // WHAT THIS CASE USED TO SAY, AND WHY IT WAS WRONG. It asserted 200 and that
    // the INSERT was reached — a status only a scripted driver ever produced.
    // Against a real column the same body is `ER_BAD_NULL_ERROR`, which reached
    // the caller as a 500 with an eleven-frame driver stack logged per request.
    // A mocked case certifying a status the database never returns is worse than
    // no case: it reads as the administrator's contract, so closing the 500
    // looks like breaking the administrator.
    //
    // The role split is real and still asserted: the editor's null is a 403
    // VALUE_GUARD (the guard runs first and the list names them), the
    // administrator's is a 400 from the column's own domain. Both refuse; they
    // refuse for different reasons, and neither reaches the statement.
    conn = makeConn([
      [/^INSERT INTO `fmb_hierarchy_nodes`/i, { affectedRows: 1 }],
      [/SELECT \* FROM `fmb_hierarchy_nodes`/i, [{ id: '352df09b-11d0-4f26-80b5-81ddb433edae', node_type: 'category', parent_id: null, name: 'nulled' }]],
    ]);
    const res = await postAsAdmin('/edge/app/schema/hierarchy_nodes', { name: 'nulled', node_type: null });
    assert.equal(res.status, 400, `expected a stable 400, got ${JSON.stringify(res.body)}`);
    assert.equal(res.body.error.code, 'INVALID_COLUMN_VALUE');
    assert.deepEqual(insertsIn(conn), [], 'the refused create still reached the INSERT');
  });

  it('editor PUT that sets node_type to null is refused by the column, not by the create-time requirement', async () => {
    // Two claims, and the second is the one this case used to be missing. The
    // create-time requirement must NOT leak onto the update path (its subject is
    // absence, and an update that omits a column changes nothing) — that is the
    // original claim, kept. But the original stopped there, asserting only "not
    // a 403 VALUE_GUARD", which a 500 satisfies just as readily as a 200; and a
    // 500 is exactly what the real column gave, per request, with a stack.
    // Naming a NOT NULL column with a null is an unstorable value like any
    // other, so it earns the same stable 400.
    conn = makeConn(putScripts());
    const res = await put('/edge/app/schema/hierarchy_nodes/09d70428-63f6-4a1b-8061-e0d9682679c3', { node_type: null });
    assert.notEqual(res.body?.error?.code === 'VALUE_GUARD' && res.status === 403, true,
      `the create-time requirement fired on an update: ${JSON.stringify(res.body)}`);
    assert.equal(res.status, 400, `expected a stable 400, got ${JSON.stringify(res.body)}`);
    assert.equal(res.body.error.code, 'INVALID_COLUMN_VALUE');
    assert.deepEqual(updatesIn(conn), [], 'the refused update still reached the UPDATE');
  });

  it('admin PUT that sets node_type to null gets the same 400 as the editor', async () => {
    // The role control for the case above. The guard is keyed by role and the
    // administrator is not in its list, so their null was never judged by it —
    // it went to the statement and came back a 500. The column's domain is
    // role-agnostic, which is what makes the answer the same for both.
    conn = makeConn(putScripts());
    const res = await putAsAdmin('/edge/app/schema/hierarchy_nodes/09d70428-63f6-4a1b-8061-e0d9682679c3', { node_type: null });
    assert.equal(res.status, 400, `expected a stable 400, got ${JSON.stringify(res.body)}`);
    assert.equal(res.body.error.code, 'INVALID_COLUMN_VALUE');
    assert.deepEqual(updatesIn(conn), [], 'the refused update still reached the UPDATE');
  });

  it('editor CAN still PUT hierarchy_nodes to a tier they may hold', async () => {
    // The other half of the refusal above: an update naming an allowed member,
    // spelled as the column declares it, must still land. A guard that refused
    // every value would satisfy every case above and remove the feature.
    conn = makeConn(putScripts());
    const res = await put('/edge/app/schema/hierarchy_nodes/09d70428-63f6-4a1b-8061-e0d9682679c3', { node_type: 'variant' });
    assert.equal(res.status, 200, `a legitimate update was refused: ${JSON.stringify(res.body)}`);
    assert.equal(updatesIn(conn).length, 1, 'the legitimate update did not reach the UPDATE');
  });
});
