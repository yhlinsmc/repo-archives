/**
 * entity-native-field-keys-ddl-parity.test.js — ENTITY_NATIVE_FIELD_KEYS
 * (docker-api/src/shared/capacity/entity-native-field-keys.js) is the ONE
 * reference list of native columns per capacity `entity_type`, and its own
 * header comment claims every entry equals "every column table-ddls.js
 * declares for that entity's table" (one documented exception: `vm`'s
 * synthetic `sga_ref`). Nothing had machine-checked that claim — the FE/BE
 * parity test (entity-native-field-keys.parity.test.ts) only proves the two
 * COPIES agree with each other, so both could be identically wrong and stay
 * green (fmb-1582 review wave: `database` was missing `primary_sga_gb`,
 * `standby_sga_gb`, `dc_refs` — three real `cap_databases` columns — and
 * nothing here would have caught it).
 *
 * This test derives the expected column set FROM table-ddls.js (parsed, not
 * transcribed — same technique as capacity-delete-preview-schema-parity.test.js)
 * and compares the authoritative module against it, so a column added to a
 * table's DDL without a matching ENTITY_NATIVE_FIELD_KEYS update goes red
 * here instead of only showing up as a grid rendering two columns under one
 * key. Deviations are an explicit, commented exception list — not a weakened
 * comparison — so a NEW deviation must be named here to pass, not merely
 * tolerated by a looser assertion.
 */
const { describe, it, before } = require('node:test');
const assert = require('node:assert/strict');

const { buildEngineTableDDLs } = require('../../src/table-ddls');
const { ENTITY_NATIVE_FIELD_KEYS } = require('../../src/shared/capacity/entity-native-field-keys');

// entity_type -> the cap_* table it is backed by (capacity/_shared.js
// validateFieldDefWrite rejects entity_type 'scenario' outright — cap_scenarios
// carries no metadata column at all, so 'scenario' has no entry on either side).
const ENTITY_TABLE = {
  site: 'cap_sites',
  hardware_spec: 'cap_hardware_specs',
  hypervisor: 'cap_hypervisors',
  vm: 'cap_vms',
  db_instance: 'cap_db_instances',
  database: 'cap_databases',
};

// The ONLY documented deviations between a native-key list and its table's own
// DDL columns. Extending this (rather than loosening the comparison below) is
// the correct way to add a genuine deviation — see the module's own header
// comment for `vm`'s reasoning.
const DOCUMENTED_EXTRA_KEYS = {
  // Not a `cap_vms` column — the KVMs grid's synthetic, client-rendered SGA
  // reference column (capacity-sga-ref.ts, vmFields() in capacity-field-defs.ts).
  vm: ['sga_ref'],
};

const SQL_TYPES = /^`?([a-z_]+)`?\s+(?:CHAR|VARCHAR|INT|DOUBLE|TIMESTAMP|JSON|TEXT|ENUM|BOOLEAN|TINYINT|BIGINT|DATETIME|DECIMAL|FLOAT|BLOB)\b/i;
let columnsByTable;

before(() => {
  columnsByTable = new Map();
  for (const ddl of buildEngineTableDDLs((n) => n)) {
    const m = ddl.match(/CREATE TABLE IF NOT EXISTS `([^`]+)`/);
    if (!m) continue;
    const table = m[1];
    const cols = new Set();
    for (const rawLine of ddl.split('\n')) {
      const line = rawLine.trim();
      if (!line || line.startsWith('--') || line.startsWith('/*')) continue;
      const cm = line.match(SQL_TYPES);
      if (cm) cols.add(cm[1]);
    }
    columnsByTable.set(table, cols);
  }
});

describe('ENTITY_NATIVE_FIELD_KEYS — DDL parity (fmb-1582 review wave)', () => {
  it('parses a non-empty column set for every entity table this module lists', () => {
    for (const table of Object.values(ENTITY_TABLE)) {
      const cols = columnsByTable.get(table);
      assert.ok(cols && cols.size > 0, `no columns parsed for ${table} — the DDL parse has stopped working`);
    }
  });

  it('ENTITY_NATIVE_FIELD_KEYS names an entity_type for every table this test knows, and vice versa', () => {
    // 'scenario' is deliberately absent from BOTH sides (see comment above) —
    // filtered out here so its absence is not read as a coverage gap.
    const moduleTypes = Object.keys(ENTITY_NATIVE_FIELD_KEYS).filter((k) => k !== 'scenario').sort();
    assert.deepEqual(moduleTypes, Object.keys(ENTITY_TABLE).sort());
  });

  for (const [entityType, table] of Object.entries(ENTITY_TABLE)) {
    it(`entity_type "${entityType}": ENTITY_NATIVE_FIELD_KEYS is EXACTLY ${table}'s DDL columns, plus only the documented exceptions`, () => {
      const ddlColumns = columnsByTable.get(table);
      assert.ok(ddlColumns, `no DDL parsed for ${table}`);
      const extra = new Set(DOCUMENTED_EXTRA_KEYS[entityType] || []);
      const expected = new Set([...ddlColumns, ...extra]);
      const actual = new Set(ENTITY_NATIVE_FIELD_KEYS[entityType]);

      const missing = [...expected].filter((c) => !actual.has(c));
      const unexpected = [...actual].filter((c) => !expected.has(c));
      assert.deepEqual(missing, [], `ENTITY_NATIVE_FIELD_KEYS.${entityType} is missing real ${table} column(s): ${missing.join(', ')}`);
      assert.deepEqual(unexpected, [], `ENTITY_NATIVE_FIELD_KEYS.${entityType} lists key(s) that are neither a ${table} DDL column nor a documented exception: ${unexpected.join(', ')}`);
    });
  }
});

describe('ENTITY_NATIVE_FIELD_KEYS — immutability (fmb-1582 review wave)', () => {
  it('freezes the outer map AND every per-entity array — a caller cannot .push() a key into one list', () => {
    assert.ok(Object.isFrozen(ENTITY_NATIVE_FIELD_KEYS), 'the outer object is not frozen');
    for (const [entityType, table] of Object.entries(ENTITY_TABLE)) {
      assert.ok(Object.isFrozen(ENTITY_NATIVE_FIELD_KEYS[entityType]), `ENTITY_NATIVE_FIELD_KEYS.${entityType} (${table}) is not frozen`);
      assert.throws(() => { ENTITY_NATIVE_FIELD_KEYS[entityType].push('injected'); }, TypeError,
        `ENTITY_NATIVE_FIELD_KEYS.${entityType} accepted a push — a shared reference could mutate every reader`);
    }
  });
});
