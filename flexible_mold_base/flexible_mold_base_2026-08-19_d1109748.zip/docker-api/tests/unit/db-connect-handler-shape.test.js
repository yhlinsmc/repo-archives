/**
 * db-connect-handler-shape.test.js
 *
 * Integration-level pin: /api/setup/test-db (and /configure-db on failure)
 * MUST carry the sanitised probe message + code end-to-end, not just at the
 * helper boundary. Complements the pure-unit test on `sanitiseProbeError` by
 * exercising the actual Express handler with a stubbed `mariadb` module so
 * a future refactor that forgets to thread the sanitised result through
 * `probe()`'s return would fail here instead of silently regressing.
 *
 * Closes the v3.2.32c security-reviewer LOW-4 follow-up gap from PR #115
 * Review Gate ("no integration-level test pins the handler response shape").
 */
const { describe, it, before, after } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

// ── Stub `mariadb` BEFORE requiring db-connect ──────────────────────────────
// The module-level `const mariadb = require('mariadb')` happens on first
// require of db-connect.js. Inject a fake into the cache under the same key
// so that require resolves to it without touching the real native bindings.
//
// Sequential-only: the test runner runs node:test serially by default, so
// the require.cache hijack is safe. If a future adopter switches to the
// parallel / isolated-process flags (`--concurrently`, or isolation=none
// with workers), this file needs to move to a dedicated worker or use a
// proper mocking library — the stub would otherwise race with other suites
// that legitimately need the real `mariadb` binding.
//
// This file's explicit scope:
//   - /test-db writer + reader failure path (3 cases)
//   - /configure-db configurePool-throws path (1 case)
// /db-status is NOT exercised here — the db stub pins isPoolReady=false for
// the whole file, which would make /db-status tests meaningless. Add
// status tests in a separate file with an independent db stub.
const mariadbKey = require.resolve('mariadb');
const dbConnectKey = require.resolve('../../src/edge/routes/platform/setup/db-connect');
const dbKey = require.resolve('../../src/edge/db');

let stubbedError; // set by each test before hitting the handler

const mariadbStub = {
  createPool(_opts) {
    return {
      async getConnection() {
        // Throw whatever the test set up. Preserves the real driver's shape:
        // `code` is the primary discriminator; `message` may echo user@host.
        throw stubbedError;
      },
      async end() { /* noop */ },
    };
  },
};
require.cache[mariadbKey] = { id: mariadbKey, filename: mariadbKey, loaded: true, exports: mariadbStub };

require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: {
    isPoolReady: () => false,
    getDbConfig: () => null,
    configurePool: async () => { throw stubbedError; },
    saveConfig: () => { /* noop */ },
  },
};

const dbConnect = require('../../src/edge/routes/platform/setup/db-connect');
const register = dbConnect;
// Import the production constant rather than re-typing the string so that
// a wording change in `PROBE_ERROR_MAP` is caught as a deliberate test
// update, not an accidental drift.
const { PROBE_ERROR_MAP } = dbConnect;

// ── HTTP helper ──────────────────────────────────────────────────────────────
function postJson(port, path_, body) {
  return new Promise((resolve, reject) => {
    const payload = JSON.stringify(body);
    const req = http.request(
      {
        host: '127.0.0.1',
        port,
        path: path_,
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) },
      },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          const raw = Buffer.concat(chunks).toString('utf-8');
          let json = null;
          try { json = JSON.parse(raw); } catch { /* leave null */ }
          resolve({ status: res.statusCode, raw, json });
        });
      },
    );
    req.on('error', reject);
    req.write(payload);
    req.end();
  });
}

// ── Fixture app ──────────────────────────────────────────────────────────────
let server;
let port;

before(async () => {
  const app = express();
  app.use(express.json());
  const router = express.Router();
  register(router);
  app.use('/api/setup', router);
  await new Promise((resolve) => {
    server = app.listen(0, '127.0.0.1', () => {
      port = server.address().port;
      resolve();
    });
  });
});

after(async () => {
  await new Promise((resolve) => server.close(resolve));
  // Clear every cache entry we mutated so a subsequent test file that needs
  // the real `mariadb` / `db` / `db-connect` modules sees fresh state.
  delete require.cache[mariadbKey];
  delete require.cache[dbKey];
  delete require.cache[dbConnectKey];
});

// ── Tests ────────────────────────────────────────────────────────────────────
describe('/api/setup/test-db — end-to-end sanitised error shape', () => {
  it('ER_ACCESS_DENIED_ERROR → handler returns sanitised message + code at every level', async () => {
    stubbedError = Object.assign(
      new Error("Access denied for user 'appuser_rw'@'10.0.1.14' (using password: YES)"),
      { code: 'ER_ACCESS_DENIED_ERROR' }
    );
    const res = await postJson(port, '/api/setup/test-db', {
      host: '10.0.1.14', port: 3306, user: 'appuser_rw', password: 'wrong',
    });

    assert.equal(res.status, 200);
    assert.ok(res.json, `expected JSON body, got: ${res.raw}`);
    const data = res.json.data;
    assert.ok(data, `expected apiOk envelope with .data, got: ${res.raw}`);

    // writer path — sanitised
    assert.equal(data.writer.success, false);
    assert.equal(data.writer.code, 'ER_ACCESS_DENIED_ERROR');
    assert.equal(data.writer.message, PROBE_ERROR_MAP.ER_ACCESS_DENIED_ERROR);
    // top-level mirrors writer (back-compat contract)
    assert.equal(data.success, false);
    assert.equal(data.message, data.writer.message);

    // Negative assertions — the raw leak must NOT appear anywhere in the body
    assert.doesNotMatch(res.raw, /appuser_rw/);
    assert.doesNotMatch(res.raw, /10\.0\.1\.14/);
    assert.doesNotMatch(res.raw, /using password/i);
  });

  it('reader probe (readConfig provided) also sanitised', async () => {
    stubbedError = Object.assign(
      new Error("Access denied for user 'appuser_ro'@'10.0.1.15'"),
      { code: 'ER_ACCESS_DENIED_ERROR' }
    );
    const res = await postJson(port, '/api/setup/test-db', {
      host: '10.0.1.14', user: 'appuser_rw', password: 'wrong',
      readConfig: { host: '10.0.1.15', user: 'appuser_ro', password: 'wrong' },
    });

    assert.equal(res.status, 200);
    const data = res.json.data;
    assert.equal(data.reader.success, false);
    assert.equal(data.reader.code, 'ER_ACCESS_DENIED_ERROR');
    assert.doesNotMatch(res.raw, /appuser_ro/);
    assert.doesNotMatch(res.raw, /10\.0\.1\.15/);
  });

  it('unknown code → opaque message + code echo, no user leak', async () => {
    stubbedError = Object.assign(
      new Error("Unknown internal error: host=secret-db.internal user=svc_svc"),
      { code: 'ER_TOTALLY_NEW' }
    );
    const res = await postJson(port, '/api/setup/test-db', {
      host: 'secret-db.internal', user: 'svc_svc',
    });

    assert.equal(res.status, 200);
    const data = res.json.data;
    assert.equal(data.writer.code, 'ER_TOTALLY_NEW');
    assert.equal(data.writer.message, 'Connection failed');
    assert.doesNotMatch(res.raw, /secret-db\.internal/);
    assert.doesNotMatch(res.raw, /svc_svc/);
  });
});

describe('/api/setup/configure-db — sanitised error shape', () => {
  it('configurePool throws → apiError message uses sanitiser, no raw echo', async () => {
    stubbedError = Object.assign(
      new Error("Access denied for user 'dbaas_root'@'internal-k8s-node-42'"),
      { code: 'ER_ACCESS_DENIED_ERROR' }
    );
    const res = await postJson(port, '/api/setup/configure-db', {
      host: 'internal-k8s-node-42', port: 3306, user: 'dbaas_root',
      password: 'wrong', database: 'app_db', tablePrefix: 'app_db_',
    });

    assert.equal(res.status, 500);
    assert.ok(res.json, `expected JSON body, got: ${res.raw}`);
    // apiError envelope: { error: { code, message, ... } }
    const err = res.json.error || res.json;
    // apiError envelope: `Failed to configure database: <sanitised>`
    const expectedTail = PROBE_ERROR_MAP.ER_ACCESS_DENIED_ERROR;
    assert.ok(
      (err.message || '').endsWith(expectedTail),
      `expected apiError message to end with "${expectedTail}", got: ${err.message}`
    );
    assert.doesNotMatch(res.raw, /dbaas_root/);
    assert.doesNotMatch(res.raw, /internal-k8s-node-42/);
  });
});
