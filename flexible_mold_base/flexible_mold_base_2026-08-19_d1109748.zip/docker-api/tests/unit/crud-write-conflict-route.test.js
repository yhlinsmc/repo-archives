'use strict';

/**
 * crud-write-conflict-route.test.js — the three places `writeConflictError` is
 * wired, asserted through the routes that use it.
 *
 * `crud-write-conflict.test.js` beside this one tests the mapper: given
 * `{errno: 1213}` it returns a 409. That is the half that was already true. The
 * half nothing asserted is that each verb's catch actually CALLS it, with the
 * error the driver raised, before the catch-all turns everything into a 500 —
 * a check written against `err.code` instead of `err.errno`, or placed after the
 * generic arm, would pass the mapper's tests and change nothing a client sees.
 * The same gap on the same feature was reported and closed one batch ago; this
 * is it reintroduced on the wiring rather than the mapping.
 *
 * So the assertions here are on the RESPONSE, with the driver error raised by
 * the statement each verb's transaction actually issues.
 */
const { test, describe, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const express = require('express');
const http = require('node:http');

process.env.SETTINGS_ENCRYPTION_KEY = process.env.SETTINGS_ENCRYPTION_KEY
  || 'crud-write-conflict-route-test-key';

const TABLE = 'flow_recipe_steps';
const ROW_ID = 'a6106eb9-46f9-491a-8027-c4a21a20204e';
const RECIPE_ID = 'd0edcb09-2c66-4d79-8114-5c3e787de042';
const COLUMNS = ['id', 'recipe_id', 'name', 'method', 'url', 'created_at', 'updated_at'];

// What the fake driver raises, and on which statement. Set per test.
let failOn = null;
let failWith = null;

// ONLY `errno` IS TRUSTWORTHY HERE, and the fake says so by lying about the rest:
// 1205 really is ER_LOCK_WAIT_TIMEOUT, and this one carries a `code` that names
// nothing. A wiring that recognised a conflict by `err.code` would still pass the
// 1213 case and fail the 1205 one, which is precisely the discrimination the
// mapper's own tests cannot make from outside a route.
const driverError = (errno) => Object.assign(new Error(`fake driver error ${errno}`), {
  errno,
  code: errno === 1213 ? 'ER_LOCK_DEADLOCK' : 'ER_SOMETHING_ELSE',
  sqlState: errno === 1213 ? '40001' : 'HY000',
});

const makeRow = () => ({
  id: ROW_ID, recipe_id: RECIPE_ID, name: 'step', method: 'POST',
  url: 'https://upstream.test/v1/step',
  created_at: '2026-01-01 00:00:00', updated_at: '2026-01-01 00:00:00',
});

function makeConn() {
  return {
    async beginTransaction() {},
    async commit() {},
    async rollback() {},
    release() {},
    async query(sql, params) {
      if (failOn && failOn.test(sql)) throw driverError(failWith);
      if (/SELECT DATABASE\(\)/i.test(sql)) return [{ db: 'testdb' }];
      if (/information_schema\.COLUMNS/i.test(sql)) return COLUMNS.map((c) => ({ COLUMN_NAME: c }));
      if (/FROM `fmb_users`/.test(sql)) return [];
      if (/^INSERT INTO/i.test(sql.trim())) return { affectedRows: 1 };
      if (/^UPDATE /i.test(sql.trim())) return { affectedRows: 1 };
      if (/^DELETE FROM/i.test(sql.trim())) return { affectedRows: 1 };
      if (/^SELECT/i.test(sql.trim())) return [makeRow({ id: params && params[0] })];
      return [];
    },
  };
}

// The stand-in is DERIVED from the real module — see request-pool.test.js for
// why a hand-listed one is a fixture that ages into a silent hole.
const dbKey = require.resolve('../../src/edge/db');
const realDb = require('../../src/edge/db');
const realDbEntry = require.cache[dbKey];
const poolFacade = {
  getConnection: async () => makeConn(),
  query: async (sql, params) => makeConn().query(sql, params),
};
require.cache[dbKey] = {
  ...realDbEntry,
  exports: {
    ...realDb,
    pool: { ro: poolFacade, rw: poolFacade },
    t: (name) => `fmb_${name}`,
    getDynamicPool: async () => ({ ro: poolFacade, rw: poolFacade }),
  },
};

const { createCrudRoutes } = require('../../src/edge/routes/app/schema');

let server = null;
let baseUrl = null;

before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => {
    req.user = { id: '5b729f1e-5c0b-447c-8144-3210469bc62c', role: 'admin' };
    next();
  });
  app.use('/rows', createCrudRoutes(TABLE, { allowedRoles: ['admin'] }));
  server = http.createServer(app);
  await new Promise((r) => server.listen(0, r));
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});

after(() => {
  if (server) server.close();
  require.cache[dbKey] = realDbEntry;
});

beforeEach(() => { failOn = null; failWith = null; });

async function call(method, path, body) {
  const res = await fetch(`${baseUrl}${path}`, {
    method,
    headers: { 'content-type': 'application/json' },
    ...(body === undefined ? {} : { body: JSON.stringify(body) }),
  });
  const text = await res.text();
  let parsed = null;
  try { parsed = JSON.parse(text); } catch { parsed = { raw: text }; }
  return { status: res.status, body: parsed };
}

const CREATE_BODY = { id: ROW_ID, recipe_id: RECIPE_ID, name: 'step', method: 'POST', url: 'https://upstream.test/v1/step' };

// Each verb, the statement its handler issues, and the request that reaches it.
const VERBS = [
  { verb: 'create', statement: /^INSERT INTO/i, fire: () => call('POST', '/rows', CREATE_BODY) },
  { verb: 'update', statement: /^UPDATE /i, fire: () => call('PUT', `/rows/${ROW_ID}`, { name: 'renamed' }) },
  { verb: 'delete', statement: /^DELETE FROM/i, fire: () => call('DELETE', `/rows/${ROW_ID}`) },
];

describe('a lock the engine gave up on is answered retryably by every verb', () => {
  for (const { verb, statement, fire } of VERBS) {
    test(`${verb}: errno 1213 answers 409 WRITE_CONFLICT`, async () => {
      failOn = statement;
      failWith = 1213;
      const res = await fire();
      assert.equal(res.status, 409, `${verb} reported a retryable engine decision as ${res.status}`);
      assert.equal(res.body.error.code, 'WRITE_CONFLICT');
      assert.match(res.body.error.message, /retry/i, 'the answer does not say what to do');
    });

    test(`${verb}: errno 1205 answers 409 WRITE_CONFLICT`, async () => {
      failOn = statement;
      failWith = 1205;
      const res = await fire();
      assert.equal(res.status, 409, `${verb} reported a lock wait timeout as ${res.status}`);
      assert.equal(res.body.error.code, 'WRITE_CONFLICT');
    });

    test(`${verb}: a genuine fault is still a 500`, async () => {
      // The control. Without it, a catch that answered 409 for EVERY error would
      // pass the two cases above while hiding real faults from operators.
      failOn = statement;
      failWith = 1364;
      const res = await fire();
      assert.equal(res.status, 500, `${verb} dressed a genuine fault as ${res.status}`);
      assert.equal(res.body.error.code, 'INTERNAL_ERROR');
    });

    test(`${verb}: succeeds when the statement does not raise`, async () => {
      // The reach guard: a request that could never get as far as the statement
      // would make all three cases above pass without exercising the wiring.
      const res = await fire();
      assert.equal(res.status, 200, `${verb} never reached its statement: ${JSON.stringify(res.body)}`);
    });
  }
});
