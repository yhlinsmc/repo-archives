// docker-api/tests/edge/routes/app/flow-run-visibility.test.js
//
// Who may read which run. The rule is now "every authenticated caller reads
// every run", so this file's job changed shape: it used to hold a predicate to
// the form the rule required, and it now holds the statements to carrying NO
// predicate — and holds the authentication gate to still being there, because
// with the scope gone that gate is the only thing left between the history and
// an anonymous caller.
//
// WHY THE ABSENCE IS ASSERTED STATEMENT BY STATEMENT rather than once on the
// builder. There are nine statements built from the predicate, and a scope that
// came back on some of them and not others would be the same class of defect as
// the count/row disagreement the predicate exists to prevent — a page whose
// total is computed over a different set than its rows.
//
// WHAT THIS FILE DOES NOT ESTABLISH: that another operator's run really is
// returned. No statement here is executed. The outcome is a live check.
const { test } = require('node:test');
const assert = require('node:assert');
const express = require('express');

let issued = [];
let responder = () => [];

require.cache[require.resolve('../../../../src/edge/db')] = {
  exports: {
    pool: {
      ro: {
        getConnection: async () => ({
          query: async (sql, params) => {
            issued.push({ sql, params });
            const out = responder(sql, params);
            if (out instanceof Error) throw out;
            return out;
          },
          release: () => {},
        }),
      },
      rw: { getConnection: async () => ({ query: async () => [], release: () => {} }) },
    },
    t: (x) => x,
  },
};

const { router } = require('../../../../src/edge/routes/app/flow-recipe-runs/aggregate');
const {
  buildRunVisibility, whereClause,
} = require('../../../../src/edge/routes/app/flow-recipe-runs/visibility');
const {
  buildGroupsSql, buildGroupCountSql, buildGroupRunsSql, buildGroupRunsCountSql,
  buildLatestGroupRunSql, buildRunsByIdSql, buildRunDetailSql, groupPredicate,
  SQL_ALIASES,
} = require('../../../../src/edge/routes/app/flow-recipe-runs/run-queries');
const {
  TEMPLATE_GROUP_PREFIX,
} = require('../../../../src/edge/routes/app/flow-recipe-runs/group-id');

const ADMIN = { id: 'aaaaaaaa-0000-0000-0000-000000000001', role: 'admin' };
const PLAIN = { id: 'bbbbbbbb-0000-0000-0000-000000000002', role: 'user' };
const EDITOR = { id: 'cccccccc-0000-0000-0000-000000000003', role: 'editor' };
const TEMPLATE = '11111111-1111-1111-1111-111111111111';

/** How a template group is addressed: a tagged identifier, not the id itself. */
const GROUP = `${TEMPLATE_GROUP_PREFIX}${encodeURIComponent(TEMPLATE)}`;

function app(user) {
  const a = express();
  a.use(express.json());
  a.use((req, _res, next) => { if (user) req.user = user; next(); });
  a.use('/', router);
  return a;
}

async function get(a, path) {
  const server = a.listen(0);
  try {
    const { port } = server.address();
    const res = await fetch(`http://127.0.0.1:${port}${path}`);
    const json = await res.json().catch(() => ({}));
    return { status: res.status, json };
  } finally {
    // Closed on the throwing path too. With the close reachable only where
    // nothing threw, a failed assertion leaks this handle, the runner never
    // exits, and the job reports a timeout instead of the assertion that failed.
    server.close();
  }
}

const emptyStub = (sql) => (sql.includes('COUNT(*) AS cnt') ? [{ cnt: 0 }] : []);

test.beforeEach(() => { issued = []; responder = emptyStub; });

// ── the rule itself ─────────────────────────────────────────────────────────

test('every caller reads with no restriction, whatever their role', () => {
  for (const user of [ADMIN, EDITOR, PLAIN]) {
    const vis = buildRunVisibility(user, 'r');
    assert.strictEqual(vis.sql, '', `${user.role} was given a predicate`);
    assert.deepStrictEqual(vis.params, []);
  }
});

test('an empty rule produces no WHERE keyword, rather than a dangling one', () => {
  assert.strictEqual(whereClause(buildRunVisibility(PLAIN, 'r').sql), '');
});

test('no statement that reads runs carries an identity or an ownership join', () => {
  const vis = buildRunVisibility(PLAIN, 'r').sql;
  const group = groupPredicate(null).sql;
  const statements = [
    ['groups', buildGroupsSql(vis)],
    ['groups count', buildGroupCountSql(vis)],
    ['group runs', buildGroupRunsSql(vis, group, { withSnapshot: true })],
    ['group runs (degraded)', buildGroupRunsSql(vis, group, { withSnapshot: false })],
    ['group runs count', buildGroupRunsCountSql(vis, group)],
    ['latest group run', buildLatestGroupRunSql(vis, group, { withSnapshot: true })],
    ['latest group run (degraded)', buildLatestGroupRunSql(vis, group, { withSnapshot: false })],
    ['runs by id', buildRunsByIdSql(vis, 2, { withSnapshot: true })],
    ['run detail', buildRunDetailSql(vis, { withAdditive: true })],
  ];
  for (const [label, sql] of statements) {
    assert.ok(!/r\.`actor_id` = \?/.test(sql), `${label} still scopes to the caller: ${sql}`);
    assert.ok(!/hierarchy_nodes/.test(sql), `${label} still joins the hierarchy: ${sql}`);
  }
});

test('the hierarchy alias is gone from the alias table with the join that used it', () => {
  // A narrowing that brings the join back has to declare its alias again, and
  // the parity test names it if it does not. Pinned so the pair cannot drift
  // apart silently.
  assert.ok(!Object.prototype.hasOwnProperty.call(SQL_ALIASES, 'hn'));
});

// ── through the routes ──────────────────────────────────────────────────────

/** Every statement a request issued, with its bindings counted against the
 *  placeholders it names — a mismatch is a silent misbinding. */
function assertBindingsMatchPlaceholders() {
  for (const { sql, params } of issued) {
    const placeholders = (sql.match(/\?/g) || []).length;
    assert.strictEqual(
      placeholders, params.length,
      `statement names ${placeholders} placeholders but binds ${params.length}: ${sql}`,
    );
  }
}

for (const [label, user] of [['a plain user', PLAIN], ['an editor', EDITOR], ['an administrator', ADMIN]]) {
  test(`${label}'s grouped read binds no identity, counts included`, async () => {
    await get(app(user), '/groups');
    const runStatements = issued.filter((q) => q.sql.includes('flow_recipe_runs'));
    // A request the router refused issues no statement, and a loop over nothing
    // asserts nothing — the count is what stops that from reading as a pass.
    assert.ok(runStatements.length >= 2);
    for (const { sql, params } of runStatements) {
      assert.ok(!sql.includes('actor_id` = ?'), `${label} was scoped: ${sql}`);
      assert.ok(!params.includes(user.id), `${label}'s identity was bound: ${sql}`);
    }
    assertBindingsMatchPlaceholders();
  });

  test(`${label}'s second-level read binds only the group`, async () => {
    await get(app(user), `/groups/${GROUP}/runs`);
    const runStatements = issued.filter((q) => q.sql.includes('flow_recipe_runs'));
    assert.ok(runStatements.length >= 2);
    for (const { sql, params } of runStatements) {
      assert.ok(!sql.includes('actor_id` = ?'), `${label} was scoped: ${sql}`);
      assert.strictEqual(params[0], TEMPLATE);
      assert.ok(!params.includes(user.id));
    }
    assertBindingsMatchPlaceholders();
  });
}

test('an anonymous caller is still refused — the gate is what is left of the rule', async () => {
  const res = await get(app(null), '/groups');
  assert.strictEqual(res.status, 401);
  assert.strictEqual(issued.length, 0, 'an unauthenticated request reached the database');
});
