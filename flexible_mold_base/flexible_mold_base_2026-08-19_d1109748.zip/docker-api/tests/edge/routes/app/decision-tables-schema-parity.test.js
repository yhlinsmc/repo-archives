/**
 * decision-tables-schema-parity.test.js — every column name the decision-table
 * code paths reference, checked against the ACTUAL DDL without a live DB.
 *
 * The CRUD tests above stub the connection, so a column that does not exist
 * (or a registry entry naming a column that was renamed) stays green in both
 * runners and only 500s against a real database. This file closes that gap for
 * the three places that name decision_tables columns as literals: the DTO
 * registry, the CRUD mount's filter/sort/validation options, and the cascade
 * delete service.
 *
 * It also checks the migration side: the executor resolves a `create-table`
 * step by SEARCHING the DDL list for the physical table name, and throws at
 * boot if it finds nothing — a registry entry for a table that was never added
 * to table-ddls.js would otherwise only surface on a real migration run.
 */
const { describe, it, before } = require('node:test');
const assert = require('node:assert/strict');

const { buildEngineTableDDLs, buildAllTableDDLs, ENGINE_TABLE_NAMES } = require('../../../../src/table-ddls');
const { TABLES } = require('../../../../src/shared/constants');
const { getRegistry } = require('../../../../src/edge/lib/dto-mapper');
const { MIGRATION_STEPS } = require('../../../../src/edge/migration-steps');

const SQL_TYPES = /^`?([a-z_]+)`?\s+(?:CHAR|VARCHAR|INT|DOUBLE|TIMESTAMP|JSON|TEXT|ENUM|BOOLEAN|TINYINT|BIGINT|DATETIME|DECIMAL|FLOAT|BLOB)\b/i;

let columnsByTable;

before(() => {
  columnsByTable = new Map();
  for (const ddl of buildEngineTableDDLs((n) => n)) {
    const m = ddl.match(/CREATE TABLE IF NOT EXISTS `([^`]+)`/);
    if (!m) continue;
    const cols = new Set();
    for (const rawLine of ddl.split('\n')) {
      const line = rawLine.trim();
      if (!line || line.startsWith('--') || line.startsWith('/*')) continue;
      const cm = line.match(SQL_TYPES);
      if (cm) cols.add(cm[1]);
    }
    columnsByTable.set(m[1], cols);
  }
});

describe('decision_tables — DDL shape', () => {
  it('is registered as an engine table', () => {
    assert.ok(ENGINE_TABLE_NAMES.includes(TABLES.DECISION_TABLES));
  });

  it('declares exactly the documented column set', () => {
    const cols = columnsByTable.get(TABLES.DECISION_TABLES);
    assert.ok(cols, 'no DDL parsed for decision_tables');
    assert.deepEqual(
      [...cols].sort(),
      ['blueprint_id', 'created_at', 'doc', 'id', 'name', 'updated_at'],
    );
  });

  it('indexes blueprint_id (every read and the cascade delete filter on it)', () => {
    const ddl = buildEngineTableDDLs((n) => n)
      .find((s) => s.includes(`\`${TABLES.DECISION_TABLES}\``));
    assert.match(ddl, /INDEX idx_decision_tables_blueprint \(blueprint_id\)/);
  });

  it('carries no FOREIGN KEY (engine tables are FK-by-convention)', () => {
    const ddl = buildEngineTableDDLs((n) => n)
      .find((s) => s.includes(`\`${TABLES.DECISION_TABLES}\``));
    assert.doesNotMatch(ddl, /FOREIGN KEY/i);
  });
});

describe('decision_tables — column references', () => {
  it('every DTO-registry column exists on the table', () => {
    const cols = columnsByTable.get(TABLES.DECISION_TABLES);
    const def = getRegistry()[TABLES.DECISION_TABLES];
    assert.ok(def, 'decision_tables is missing from the DTO registry');
    for (const group of ['booleans', 'timestamps', 'json', 'nullableStrings']) {
      for (const col of def[group] || []) {
        assert.ok(cols.has(col), `dto-mapper names ${col}, which the DDL does not declare`);
      }
    }
    // The document column must be in the json group or it reaches the client as
    // a raw string and the write path stores "[object Object]".
    assert.ok((def.json || []).includes('doc'));
  });

  it('every column the CRUD mount names as a literal exists on the table', () => {
    const cols = columnsByTable.get(TABLES.DECISION_TABLES);
    // Mirrors schema/index.js: filterableColumns, trimmedNonEmptyColumns,
    // parentOwnership.via, rejectIfParentLinked.column, and the factory's
    // default sort column.
    for (const col of ['blueprint_id', 'name', 'created_at']) {
      assert.ok(cols.has(col), `the CRUD mount references ${col}, which the DDL does not declare`);
    }
  });

  it('the cascade-delete service can resolve rows by blueprint_id', () => {
    assert.ok(columnsByTable.get(TABLES.DECISION_TABLES).has('blueprint_id'));
    // The cascade walks hierarchy_nodes ids into that column, so the target of
    // the join has to exist too.
    assert.ok(columnsByTable.get(TABLES.HIERARCHY_NODES).has('id'));
  });
});

describe('migration registry — create-table steps resolve to real DDL', () => {
  it('every create-table step finds exactly one CREATE statement', () => {
    const ddls = buildAllTableDDLs((n) => n);
    const createSteps = MIGRATION_STEPS.filter((s) => s.kind === 'create-table');
    assert.ok(createSteps.length > 0, 'expected at least the decision_tables step');
    for (const step of createSteps) {
      const matches = ddls.filter((s) => s.includes(`\`${step.table}\``));
      assert.equal(
        matches.length >= 1, true,
        `${step.step}: no DDL defines ${step.table} — the executor throws at boot`,
      );
      assert.match(matches[0], new RegExp(`CREATE TABLE IF NOT EXISTS \`${step.table}\``));
    }
  });

  it('registers decision_tables as a create-table step', () => {
    const step = MIGRATION_STEPS.find((s) => s.table === TABLES.DECISION_TABLES);
    assert.ok(step, 'decision_tables has no migration-steps entry');
    assert.equal(step.kind, 'create-table');
    // A DB that cannot run the CREATE must degrade, not fail the boot: every
    // consumer of this table tolerates its absence.
    assert.equal(step.severity, 'warning');
  });
});
