// docker-api/tests/edge/routes/app/flow-run-group-runs.test.js
//
// One group's runs: the page, the group it is headed by, and the difference
// indicator the rows carry.
const { test } = require('node:test');
const assert = require('node:assert');
const express = require('express');

let issued = [];
let responder = () => [];

require.cache[require.resolve('../../../../src/edge/db')] = {
  exports: {
    pool: {
      ro: {
        getConnection: async () => ({
          query: async (sql, params) => {
            issued.push({ sql, params });
            const out = responder(sql, params);
            if (out instanceof Error) throw out;
            return out;
          },
          release: () => {},
        }),
      },
      rw: { getConnection: async () => ({ query: async () => [], release: () => {} }) },
    },
    t: (x) => x,
  },
};

const { router } = require('../../../../src/edge/routes/app/flow-recipe-runs/aggregate');
const {
  TEMPLATE_GROUP_PREFIX,
} = require('../../../../src/edge/routes/app/flow-recipe-runs/group-id');

function app(user) {
  const a = express();
  a.use(express.json());
  a.use((req, _res, next) => { if (user) req.user = user; next(); });
  a.use('/', router);
  return a;
}

async function get(a, path) {
  const server = a.listen(0);
  try {
    const { port } = server.address();
    const res = await fetch(`http://127.0.0.1:${port}${path}`);
    const json = await res.json().catch(() => ({}));
    return { status: res.status, json };
  } finally {
    // Closed on the throwing path too. With the close reachable only where
    // nothing threw, a failed assertion leaks this handle, the runner never
    // exits, and the job reports a timeout instead of the assertion that failed.
    server.close();
  }
}

const ADMIN = { id: 'aaaaaaaa-0000-0000-0000-000000000001', role: 'admin' };
const TEMPLATE = '11111111-1111-1111-1111-111111111111';
const ACTOR = 'bbbbbbbb-0000-0000-0000-000000000002';

/** How a template group is addressed. The frontend's encoder is the real one
 *  (`groupRouteId`); the two are compared in the parity test named in
 *  `group-id.js`, which this runner cannot load. */
const segment = (templateId) => `${TEMPLATE_GROUP_PREFIX}${encodeURIComponent(templateId)}`;
const GROUP = segment(TEMPLATE);

function captured(entered) {
  return JSON.stringify({
    entered, computed: {}, fields: {}, blueprint_id: null, variant_id: null,
  });
}

function runRow(over) {
  return {
    id: 'cccccccc-0000-0000-0000-000000000003',
    created_at: '2026-07-20 09:30:00',
    started_at: '2026-07-20 09:30:00',
    finished_at: '2026-07-20 09:30:02',
    status: 'success',
    actor_id: ACTOR,
    result_link: 'https://example.invalid/run/1',
    external_flow_id: 'X-1',
    error_summary: null,
    blueprint_id: null,
    input_snapshot: null,
    ...over,
  };
}

function stub({ runs = [], total = 0, templates = [], users = [], failSnapshot = false } = {}) {
  return (sql) => {
    if (sql.includes('input_snapshot')) {
      if (failSnapshot) {
        const e = new Error("Unknown column 'input_snapshot'");
        e.errno = 1054;
        return e;
      }
      return runs;
    }
    if (sql.includes('COUNT(*) AS cnt')) return [{ cnt: total }];
    if (sql.includes('user_templates')) return templates;
    if (sql.includes('kc_username')) return users;
    // The legacy tier — the same page read without the additive column.
    if (sql.includes('FROM `flow_recipe_runs`')) {
      return runs.map(({ input_snapshot: _drop, ...rest }) => rest);
    }
    return [];
  };
}

test.beforeEach(() => { issued = []; responder = stub(); });

test('a group\'s runs come back newest first, with the total behind them', async () => {
  responder = stub({
    runs: [runRow()],
    total: 7,
    templates: [{ id: TEMPLATE, name: 'Nightly build', blueprint_id: 'bp', variant_id: null }],
    users: [{ id: ACTOR, display_name: 'Ada', kc_username: 'ada' }],
  });
  const { status, json } = await get(app(ADMIN), `/groups/${GROUP}/runs`);
  assert.strictEqual(status, 200);
  assert.strictEqual(json.data.total, 7);
  assert.strictEqual(json.data.rows[0].actor_name, 'Ada');
  assert.strictEqual(json.data.group.template_name, 'Nightly build');
  assert.strictEqual(json.data.group.template_exists, true);
  assert.match(issued[0].sql, /ORDER BY r\.`created_at` DESC, r\.`id` DESC/);
});

test('the page reads one row past its end so the oldest row has a partner', async () => {
  responder = stub({ runs: [], total: 0 });
  await get(app(ADMIN), `/groups/${GROUP}/runs?limit=10&offset=20`);
  assert.deepStrictEqual(issued[0].params.slice(-2), [11, 20]);
});

test('the extra row is not returned', async () => {
  responder = stub({
    runs: [
      runRow({ id: 'r3', input_snapshot: captured({ size: '12' }) }),
      runRow({ id: 'r2', input_snapshot: captured({ size: '12' }) }),
      runRow({ id: 'r1', input_snapshot: captured({ size: '10' }) }),
    ],
    total: 3,
  });
  const { json } = await get(app(ADMIN), `/groups/${GROUP}/runs?limit=2&offset=0`);
  assert.strictEqual(json.data.rows.length, 2);
  assert.deepStrictEqual(json.data.rows.map((r) => r.id), ['r3', 'r2']);
  // The oldest row ON THE PAGE is compared against the row past it, so it is
  // not reported as the first run of the template.
  assert.strictEqual(json.data.rows[1].input_diff, 'changed');
});

test('a run with nothing recorded reads as unavailable, never as unchanged', async () => {
  responder = stub({
    runs: [runRow({ id: 'r2', input_snapshot: null }), runRow({ id: 'r1', input_snapshot: captured({ size: '10' }) })],
    total: 2,
  });
  const { json } = await get(app(ADMIN), `/groups/${GROUP}/runs`);
  const [row] = json.data.rows;
  assert.strictEqual(row.input_diff, 'unavailable');
  assert.strictEqual(row.input_diff_reason, 'not_recorded');
});

test('the stored answers never leave the server', async () => {
  responder = stub({
    runs: [runRow({ input_snapshot: captured({ size: '10' }) })],
    total: 1,
  });
  const { json } = await get(app(ADMIN), `/groups/${GROUP}/runs`);
  assert.ok(!('input_snapshot' in json.data.rows[0]));
});

test('a database without the capture column still serves the page', async () => {
  responder = stub({
    runs: [runRow({ input_snapshot: captured({ size: '10' }) })],
    total: 1,
    failSnapshot: true,
  });
  const { status, json } = await get(app(ADMIN), `/groups/${GROUP}/runs`);
  assert.strictEqual(status, 200);
  assert.strictEqual(json.data.rows.length, 1);
  assert.strictEqual(json.data.rows[0].input_diff, 'unavailable');
  assert.strictEqual(json.data.rows[0].input_diff_reason, 'not_recorded');
});

test('the group with no template is addressed by name and matched on IS NULL', async () => {
  responder = stub({ runs: [runRow()], total: 1 });
  const { status, json } = await get(app(ADMIN), '/groups/none/runs');
  assert.strictEqual(status, 200);
  assert.strictEqual(json.data.group.template_id, null);
  assert.strictEqual(json.data.group.template_exists, false);
  assert.match(issued[0].sql, /r\.`template_id` IS NULL/);
  // No template row exists to be looked up for a group that has no id.
  assert.ok(!issued.some((q) => q.sql.includes('user_templates')));
});

test('a deleted template still lists its runs, and the header says it is gone', async () => {
  responder = stub({ runs: [runRow()], total: 1, templates: [] });
  const { json } = await get(app(ADMIN), `/groups/${GROUP}/runs`);
  assert.strictEqual(json.data.rows.length, 1);
  assert.strictEqual(json.data.group.template_exists, false);
  assert.strictEqual(json.data.group.template_name, '');
  assert.strictEqual(json.data.group.template_id, TEMPLATE);
});

test('a template whose id spells the reserved word opens ITS OWN runs', async () => {
  // The worse of the two failures this identifier scheme ends: the page showed
  // the runs that named no template at all, under the heading of a template that
  // does exist, and said nothing about it. The predicate is what proves which
  // group was read — an equality on the value, never the IS NULL branch.
  responder = stub({
    runs: [runRow()],
    total: 1,
    templates: [{ id: 'none', name: 'Named like the reserved word', blueprint_id: null, variant_id: null }],
  });
  const { status, json } = await get(app(ADMIN), `/groups/${segment('none')}/runs`);
  assert.strictEqual(status, 200);
  assert.match(issued[0].sql, /r\.`template_id` = \?/);
  assert.doesNotMatch(issued[0].sql, /r\.`template_id` IS NULL/);
  assert.strictEqual(issued[0].params[0], 'none');
  assert.strictEqual(json.data.group.template_id, 'none');
  assert.strictEqual(json.data.group.template_exists, true);
});

test('a template id that is not identifier-shaped still opens its runs', async () => {
  // The other failure: the first level lists every value the column holds, so a
  // second level that accepted only UUID-shaped ones listed groups it refused to
  // open. The column has no foreign key and the write path checks no shape.
  responder = stub({ runs: [runRow()], total: 1, templates: [] });
  const { status, json } = await get(app(ADMIN), `/groups/${segment('legacy-7')}/runs`);
  assert.strictEqual(status, 200);
  assert.strictEqual(issued[0].params[0], 'legacy-7');
  assert.strictEqual(json.data.rows.length, 1);
  // No template row resolves it, which is the state a deleted template is in —
  // not a reason to refuse the page.
  assert.strictEqual(json.data.group.template_exists, false);
  assert.strictEqual(json.data.group.template_id, 'legacy-7');
});

test('a segment carrying no kind is refused, and never read as another group', async () => {
  // A bare template id is not an identifier any more: refusing it is what keeps
  // exactly one spelling per group. None of these may fall through to the group
  // with no template, which is why the absence of a query is asserted too.
  for (const bad of ['not-an-id', TEMPLATE, 'None', 'nonet.']) {
    issued = [];
    const { status } = await get(app(ADMIN), `/groups/${encodeURIComponent(bad)}/runs`);
    assert.strictEqual(status, 404, `accepted ${bad}`);
    assert.strictEqual(issued.length, 0);
  }
});

test('timestamps reach the client pinned to UTC', async () => {
  responder = stub({ runs: [runRow()], total: 1 });
  const { json } = await get(app(ADMIN), `/groups/${GROUP}/runs`);
  assert.strictEqual(json.data.rows[0].created_at, '2026-07-20T09:30:00Z');
});

test('an unauthenticated caller is refused', async () => {
  const { status } = await get(app(null), `/groups/${GROUP}/runs`);
  assert.strictEqual(status, 401);
  assert.strictEqual(issued.length, 0);
});
