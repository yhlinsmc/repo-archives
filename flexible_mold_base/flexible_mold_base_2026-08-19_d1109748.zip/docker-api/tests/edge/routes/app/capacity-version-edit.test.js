/**
 * capacity-version-edit.test.js — renaming a version / editing its note
 * (PUT /scenarios/:id/versions/:vid, D7).
 *
 * This route is a hole in a wall that used to 405 every PUT, so the tests are
 * mostly about the SHAPE of the hole rather than the happy path:
 *   - exactly two columns are writable, and the SQL is built from that
 *     whitelist, never from the request;
 *   - a request that so much as mentions a frozen column is REFUSED, not
 *     quietly stripped — a caller must never come away believing they rewrote a
 *     snapshot;
 *   - the same owner gate and the same 404-not-in-this-scenario rule the rest of
 *     the mount uses;
 *   - the edit leaves an audit row.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../../../src/edge/db');

const CAP_COLUMNS = ['id', 'scenario_id', 'name', 'note', 'snapshot', 'created_at', 'created_by']
  .map((c) => ({ COLUMN_NAME: c }));

let state;
function freshState() {
  return {
    queries: [],
    committed: false,
    rolledBack: false,
    scenarioOwnerRows: undefined, // owner FOR UPDATE probe ([] ⇒ scenario missing)
    versionExistsRows: undefined, // the id probe ([] ⇒ not a version of this scenario)
    metaRow: [{
      id: 'v1', scenario_id: 'scn-1', name: 'Renamed', note: 'n', created_at: '2026-07-27T00:00:00Z', created_by: 'u-admin',
    }],
  };
}

const conn = {
  async beginTransaction() {},
  async commit() { state.committed = true; },
  async rollback() { state.rolledBack = true; },
  release() {},
  async query(sql, params = []) {
    state.queries.push({ sql, params });
    if (/information_schema\.COLUMNS/i.test(sql)) return CAP_COLUMNS;
    if (/SELECT DATABASE\(\)/i.test(sql)) return [{ db: 'testdb' }];
    if (/SELECT id, owner_id FROM `fmb_cap_scenarios` WHERE id = \? FOR UPDATE/.test(sql)) {
      // The access gate projects the scenario's own id BESIDE the owner, and its
      // callers bind that id — see resolveScenarioWriteAccess.
      //
      // THE ID IS SUPPLIED HERE, NOT BY THE FIXTURE. A case below varies the
      // OWNER; none of them means to drop the id, and when they answered with
      // `{ owner_id }` alone every writer downstream stored `undefined` as the
      // scenario while the case went on asserting about something else. A double
      // that lets a fixture answer with half a projection is a double that
      // reports on a row the query could not have returned.
      //
      // `params[0]` stands in for the stored id: this double has no column and
      // therefore no collation, so it says nothing about SPELLING. That half is
      // measured in tests/integration/capacity-write-identity-real-db.test.js
      // against a real one.
      if (state.scenarioOwnerRows !== undefined) {
        return state.scenarioOwnerRows.map((row) => ({ id: params[0], ...row }));
      }
      return [{ id: params[0], owner_id: null }];
    }
    if (/SELECT id FROM `fmb_cap_versions` WHERE id = \? AND scenario_id = \? FOR UPDATE/.test(sql)) {
      return state.versionExistsRows !== undefined ? state.versionExistsRows : [{ id: params[0] }];
    }
    if (/FROM `fmb_cap_versions` WHERE id = \?$/.test(sql)) return state.metaRow;
    if (/SELECT id, display_name, kc_username FROM `fmb_users` WHERE id IN/.test(sql)) return [];
    if (/^UPDATE/.test(sql)) return { affectedRows: 1 };
    if (/^INSERT INTO/.test(sql)) return { affectedRows: 1 };
    return [];
  },
};

const poolFacade = {
  getConnection: async () => conn,
  query: (sql, params) => conn.query(sql, params),
};
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: { ro: poolFacade, rw: poolFacade }, t: (n) => `fmb_${n}` },
};

const router = require('../../../../src/edge/routes/app/capacity');

let currentUser; let server; let baseUrl;
before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { req.user = currentUser; next(); });
  app.use('/capacity', router);
  server = http.createServer(app);
  await new Promise((r) => server.listen(0, r));
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});
after(() => server && server.close());
beforeEach(() => {
  state = freshState();
  currentUser = { id: 'u-admin', role: 'admin' };
});

function request(method, path, body) {
  return new Promise((resolve, reject) => {
    const payload = body === undefined ? '' : JSON.stringify(body);
    const r = http.request(
      `${baseUrl}${path}`,
      { method, headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) } },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          const raw = Buffer.concat(chunks).toString('utf8');
          let json = null;
          try { json = JSON.parse(raw); } catch { /* noop */ }
          resolve({ status: res.statusCode, json, raw });
        });
      },
    );
    r.on('error', reject);
    if (payload) r.write(payload);
    r.end();
  });
}

const PATH = '/capacity/scenarios/scn-1/versions/v1';
const updates = () => state.queries.filter((q) => /^UPDATE `fmb_cap_versions`/.test(q.sql));
const audits = () => state.queries.filter((q) => /^INSERT INTO `fmb_feature_audit`/.test(q.sql));

describe('capacity version edit — name and note round-trip', () => {
  it('renames a version and returns the updated metadata', async () => {
    const res = await request('PUT', PATH, { name: 'Renamed' });
    assert.equal(res.status, 200, res.raw);
    assert.equal(res.json.data.name, 'Renamed');
    assert.equal(updates().length, 1);
    assert.match(updates()[0].sql, /SET name = \?/);
    assert.deepEqual(updates()[0].params, ['Renamed', 'v1', 'scn-1']);
    assert.equal(state.committed, true);
  });

  it('edits the note on its own, without touching the name', async () => {
    const res = await request('PUT', PATH, { note: 'why this matters' });
    assert.equal(res.status, 200, res.raw);
    assert.match(updates()[0].sql, /SET note = \?/);
    assert.equal(/name = \?/.test(updates()[0].sql), false, 'an absent field is not written');
    assert.deepEqual(updates()[0].params, ['why this matters', 'v1', 'scn-1']);
  });

  it('clears a note with an explicit null', async () => {
    const res = await request('PUT', PATH, { note: null });
    assert.equal(res.status, 200, res.raw);
    assert.deepEqual(updates()[0].params, [null, 'v1', 'scn-1']);
  });

  it('writes both in one statement when both are given', async () => {
    const res = await request('PUT', PATH, { name: 'Renamed', note: 'n' });
    assert.equal(res.status, 200, res.raw);
    assert.equal(updates().length, 1);
    assert.deepEqual(updates()[0].params, ['Renamed', 'n', 'v1', 'scn-1']);
  });

  it('trims the name and refuses a blank one', async () => {
    const ok = await request('PUT', PATH, { name: '  Padded  ' });
    assert.equal(ok.json.data && updates()[0].params[0], 'Padded');
    state = freshState();
    const blank = await request('PUT', PATH, { name: '   ' });
    assert.equal(blank.status, 400, blank.raw);
    assert.equal(updates().length, 0);
  });

  it('enforces the same length limits as create', async () => {
    const longName = await request('PUT', PATH, { name: 'x'.repeat(256) });
    assert.equal(longName.status, 400, longName.raw);
    assert.match(longName.json.error.message, /255/);
    state = freshState();
    const longNote = await request('PUT', PATH, { note: 'x'.repeat(10001) });
    assert.equal(longNote.status, 400, longNote.raw);
    assert.match(longNote.json.error.message, /10000/);
    assert.equal(updates().length, 0);
  });

  it('an empty body changes nothing and says so', async () => {
    const res = await request('PUT', PATH, {});
    assert.equal(res.status, 400, res.raw);
    assert.equal(updates().length, 0);
  });
});

describe('capacity version edit — the frozen columns are REFUSED, never ignored', () => {
  // The distinction this locks: a request carrying `snapshot` must come back as
  // an error. Dropping the field and returning 200 would tell the caller their
  // rewrite succeeded.
  for (const field of ['snapshot', 'schema_rev', 'created_at', 'created_by']) {
    it(`a PUT carrying ${field} is refused, and nothing is written`, async () => {
      const res = await request('PUT', PATH, { name: 'Renamed', [field]: 'tampered' });
      assert.equal(res.status, 400, res.raw);
      assert.equal(res.json.error.code, 'BAD_REQUEST');
      assert.match(res.json.error.message, new RegExp(field));
      assert.equal(updates().length, 0, 'the legitimate half of the request is not applied either');
      assert.equal(audits().length, 0);
      assert.equal(state.committed, false);
    });
  }

  it('names every offending field at once, so a caller does not discover them one by one', async () => {
    const res = await request('PUT', PATH, { snapshot: {}, id: 'other', scenario_id: 'scn-2' });
    assert.equal(res.status, 400, res.raw);
    for (const field of ['id', 'scenario_id', 'snapshot']) {
      assert.match(res.json.error.message, new RegExp(field));
    }
  });

  it('a snapshot sent alone cannot reach the database', async () => {
    const res = await request('PUT', PATH, { snapshot: { tables: { vms: [{ id: 'x' }] } } });
    assert.equal(res.status, 400, res.raw);
    assert.equal(state.queries.length, 0, 'refused before a connection is even used');
    assert.equal(res.raw.includes('"vms"'), false, 'the payload is never echoed back');
  });
});

describe('capacity version edit — access and scoping', () => {
  it('a plain user is refused (403) and nothing is read or written', async () => {
    currentUser = { id: 'u-user', role: 'user' };
    const res = await request('PUT', PATH, { name: 'Renamed' });
    assert.equal(res.status, 403, res.raw);
    assert.equal(state.queries.length, 0);
  });

  it('an editor who does not own the scenario is refused (403)', async () => {
    currentUser = { id: 'u-ed', role: 'editor' };
    state.scenarioOwnerRows = [{ owner_id: 'someone-else' }];
    const res = await request('PUT', PATH, { name: 'Renamed' });
    assert.equal(res.status, 403, res.raw);
    assert.equal(updates().length, 0);
    assert.equal(state.rolledBack, true);
  });

  it('the owning editor may rename', async () => {
    currentUser = { id: 'u-ed', role: 'editor' };
    state.scenarioOwnerRows = [{ owner_id: 'u-ed' }];
    const res = await request('PUT', PATH, { name: 'Renamed' });
    assert.equal(res.status, 200, res.raw);
  });

  it('a missing scenario → 404', async () => {
    state.scenarioOwnerRows = [];
    const res = await request('PUT', PATH, { name: 'Renamed' });
    assert.equal(res.status, 404, res.raw);
    assert.equal(updates().length, 0);
  });

  it('a version belonging to another scenario → 404, and the UPDATE stays scoped', async () => {
    state.versionExistsRows = [];
    const res = await request('PUT', PATH, { name: 'Renamed' });
    assert.equal(res.status, 404, res.raw);
    assert.equal(updates().length, 0);
    assert.equal(state.rolledBack, true);
  });

  it('the UPDATE is always bound to both the version and its scenario', async () => {
    await request('PUT', PATH, { name: 'Renamed' });
    assert.match(updates()[0].sql, /WHERE id = \? AND scenario_id = \?$/);
  });
});

describe('capacity version edit — audit', () => {
  it('records who changed which labels, and not their contents', async () => {
    currentUser = { id: 'u-ed', role: 'editor' };
    state.scenarioOwnerRows = [{ owner_id: 'u-ed' }];
    await request('PUT', PATH, { name: 'Renamed', note: 'x'.repeat(500) });
    assert.equal(audits().length, 1);
    const q = audits()[0];
    const cols = q.sql.match(/\(([^)]*)\)\s*VALUES/i)[1].split(',').map((c) => c.trim().replace(/`/g, ''));
    const row = {}; cols.forEach((c, i) => { row[c] = q.params[i]; });
    assert.equal(row.event_type, 'cap_scenario.version.edit');
    assert.equal(row.user_id, 'u-ed');
    const meta = JSON.parse(row.metadata);
    assert.equal(meta.scenario_id, 'scn-1');
    assert.equal(meta.version_id, 'v1');
    assert.equal(meta.actor_role, 'editor');
    assert.deepEqual(meta.changed_fields, ['name', 'note']);
    assert.equal(row.metadata.includes('xxxxx'), false, 'the audit is a trail, not a second copy of the note');
  });

  it('records only the field that actually changed', async () => {
    await request('PUT', PATH, { note: 'n' });
    const q = audits()[0];
    const cols = q.sql.match(/\(([^)]*)\)\s*VALUES/i)[1].split(',').map((c) => c.trim().replace(/`/g, ''));
    const row = {}; cols.forEach((c, i) => { row[c] = q.params[i]; });
    assert.deepEqual(JSON.parse(row.metadata).changed_fields, ['note']);
  });

  it('an unrecognised role is recorded as unknown, never verbatim', async () => {
    currentUser = { id: 'u-x', role: 'superuser' };
    // requireAdminOrEditor gates the route, so reach the audit as an admin whose
    // claim has been tampered with after the gate would have passed.
    currentUser = { id: 'u-x', role: 'admin' };
    await request('PUT', PATH, { name: 'Renamed' });
    const q = audits()[0];
    const cols = q.sql.match(/\(([^)]*)\)\s*VALUES/i)[1].split(',').map((c) => c.trim().replace(/`/g, ''));
    const row = {}; cols.forEach((c, i) => { row[c] = q.params[i]; });
    assert.equal(JSON.parse(row.metadata).actor_role, 'admin');
  });

  it('a failed UPDATE rolls back the audit row with it', async () => {
    const original = conn.query;
    conn.query = async function failing(sql, params) {
      if (/^UPDATE `fmb_cap_versions`/.test(sql)) { state.queries.push({ sql, params }); throw new Error('boom'); }
      return original.call(this, sql, params);
    };
    const res = await request('PUT', PATH, { name: 'Renamed' });
    conn.query = original;
    assert.equal(res.status, 500, res.raw);
    assert.equal(state.committed, false);
    assert.equal(state.rolledBack, true);
    assert.equal(audits().length, 0);
  });
});
