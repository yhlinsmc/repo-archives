/**
 * capacity-bundle-items-schema-parity.test.js — validates every column the
 * bundle-item write/read paths (bundles.js) name against the ACTUAL
 * cap_bundle_items DDL, WITHOUT a live DB. The node:test mocks stub query
 * results, so a mistyped column name (e.g. the AR2-Q8 standby_node_count add)
 * stays green in both runners yet 500s in production. This test closes that gap
 * by parsing docker-api/src/table-ddls and asserting the referenced columns
 * exist — read out of the source, never a hand-copied list (a restated list is a
 * second statement that can agree with the DDL while the first does not).
 */
const { describe, it, before } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

// _shared.js destructures { t } from ../../../db at load; stub so the require is
// side-effect-free (no pool).
const dbKey = require.resolve('../../../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: {}, t: (n) => n },
};

const { buildEngineTableDDLs } = require('../../../../src/table-ddls');
const { BUNDLE_ITEM_COLUMNS } = require('../../../../src/edge/routes/app/capacity/_shared');

const SQL_TYPES = /^`?([a-z_]+)`?\s+(?:CHAR|VARCHAR|INT|DOUBLE|TIMESTAMP|JSON|TEXT|ENUM|BOOLEAN|TINYINT|BIGINT|DATETIME|DECIMAL|FLOAT|BLOB)\b/i;
let bundleItemCols;

before(() => {
  for (const ddl of buildEngineTableDDLs((n) => n)) {
    if (!ddl.includes('CREATE TABLE IF NOT EXISTS `cap_bundle_items`')) continue;
    const cols = new Set();
    for (const rawLine of ddl.split('\n')) {
      const line = rawLine.trim();
      if (!line || line.startsWith('--') || line.startsWith('/*') || line.startsWith('*')) continue;
      const cm = line.match(SQL_TYPES);
      if (cm) cols.add(cm[1]);
    }
    bundleItemCols = cols;
  }
  assert.ok(bundleItemCols && bundleItemCols.size > 0, 'no columns parsed for cap_bundle_items');
});

const BUNDLES_SRC = fs.readFileSync(
  path.resolve(__dirname, '../../../../src/edge/routes/app/capacity/bundles.js'), 'utf8',
);

describe('cap_bundle_items write/read column parity (AR2-Q8)', () => {
  it('every BUNDLE_ITEM_COLUMNS writable column exists in the DDL (INSERT/UPDATE parity)', () => {
    for (const col of BUNDLE_ITEM_COLUMNS) {
      assert.ok(bundleItemCols.has(col), `cap_bundle_items has no writable column '${col}'`);
    }
    // Guard the guard: the new column is actually under test.
    assert.ok(BUNDLE_ITEM_COLUMNS.includes('standby_node_count'), 'standby_node_count missing from the writable set');
  });

  it('every column the belongs-to PUT SELECT names exists in the DDL (read parity)', () => {
    // Lift the explicit column list from the source rather than restating it, so a
    // future column added to the SELECT is checked automatically. The list spans
    // `SELECT <cols> FROM `${t(TABLES.CAP_BUNDLE_ITEMS)}``; the `${...}`
    // conditional standby_node_count is stripped down to its bare column name.
    const m = BUNDLES_SRC.match(/SELECT\s+(id, type, profile_id.*?)\s+FROM\s+\\?`\$\{t\(TABLES\.CAP_BUNDLE_ITEMS\)\}/);
    assert.ok(m, 'the bundle-item belongs-to SELECT is gone or reshaped — update this parser');
    const named = m[1]
      .replace(/\$\{[^}]*\?\s*'([a-z_]+),\s*'\s*:\s*''\}/g, '$1,') // conditional `standby_node_count, ` interpolation
      .split(',')
      .map((s) => s.trim())
      .filter((s) => s.length > 0);
    assert.ok(named.length >= 8, `only ${named.length} SELECT columns parsed — the parse has stopped working`);
    assert.ok(named.includes('standby_node_count'), 'standby_node_count is not covered by the SELECT parse');
    for (const col of named) {
      assert.ok(bundleItemCols.has(col), `PUT SELECT names '${col}', absent from cap_bundle_items DDL — a 500 every mocked runner paints green`);
    }
  });
});
