/**
 * capacity-child-scenario-lock.test.js — fmb-1685.
 *
 * makeScenarioRowLock is the preWriteInTx hook that serialises a capacity child
 * CREATE/UPDATE on its scenario row (cap_scenarios FOR UPDATE), so the renumber
 * apply — which holds that lock while reading role/{function}/site data UNLOCKED
 * — can never rename from a placement/role/function/site change that commits
 * mid-apply. Here we pin the MECHANISM (the exact locking read, the no-op when no
 * scope, never rejects) and the SCHEMA PARITY of its one column. The WIRING/ORDER
 * on the real mounts is proven in capacity-routes.test.js (fmb-1685 block).
 */
const { describe, it, before, beforeEach } = require('node:test');
const assert = require('node:assert/strict');

// _shared.js destructures { t } from ../../../db at load (never calls it then);
// stub the db module so the require is side-effect-free (no pool).
const dbKey = require.resolve('../../../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: {}, t: (n) => `fmb_${n}` },
};

const { makeScenarioRowLock } = require('../../../../src/edge/routes/app/capacity/_shared');
const { buildEngineTableDDLs } = require('../../../../src/table-ddls');

let recorded;
const conn = {
  async query(sql, params = []) {
    recorded.push({ sql, params });
    return [];
  },
};

beforeEach(() => { recorded = []; });

describe('makeScenarioRowLock — mechanism', () => {
  it('locks the write\'s scenario row FOR UPDATE (scope off the bound URL scenario)', async () => {
    const hook = makeScenarioRowLock();
    const rejection = await hook(conn, { capacityScenarioId: 'scn-1' });
    assert.equal(rejection, null, 'a lock hook never rejects — ownership/FK checks do');
    assert.equal(recorded.length, 1, 'exactly one locking read');
    assert.match(recorded[0].sql, /SELECT id FROM `fmb_cap_scenarios` WHERE id = \? FOR UPDATE/);
    assert.deepEqual(recorded[0].params, ['scn-1']);
  });

  it('falls back to req.params.scenarioId when capacityScenarioId is absent', async () => {
    const hook = makeScenarioRowLock();
    await hook(conn, { params: { scenarioId: 'scn-2' } });
    assert.deepEqual(recorded[0].params, ['scn-2']);
  });

  it('is a no-op (no query, no rejection) when no scenario scope is resolvable', async () => {
    const hook = makeScenarioRowLock();
    const rejection = await hook(conn, { params: {} });
    assert.equal(rejection, null);
    assert.equal(recorded.length, 0, 'nothing to lock ⇒ the ownership chain reports the 404/403');
  });
});

describe('makeScenarioRowLock — schema parity (no live DB)', () => {
  let columnsByTable;
  before(() => {
    const SQL_TYPES = /^`?([a-z_]+)`?\s+(?:CHAR|VARCHAR|INT|DOUBLE|TIMESTAMP|JSON|TEXT|ENUM|BOOLEAN|TINYINT|BIGINT|DATETIME|DECIMAL|FLOAT|BLOB)\b/i;
    columnsByTable = new Map();
    for (const ddl of buildEngineTableDDLs((n) => n)) {
      const m = ddl.match(/CREATE TABLE IF NOT EXISTS `([^`]+)`/);
      if (!m) continue;
      const cols = new Set();
      for (const rawLine of ddl.split('\n')) {
        const line = rawLine.trim();
        if (!line || line.startsWith('--') || line.startsWith('/*')) continue;
        const cm = line.match(SQL_TYPES);
        if (cm) cols.add(cm[1]);
      }
      columnsByTable.set(m[1], cols);
    }
  });

  it('cap_scenarios.id (the only column the hook names) exists in the DDL', () => {
    const cols = columnsByTable.get('cap_scenarios');
    assert.ok(cols, 'cap_scenarios must be declared in table-ddls.js');
    assert.ok(cols.has('id'), 'cap_scenarios.id must exist — the hook locks on it');
  });
});
