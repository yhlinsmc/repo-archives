// docker-api/tests/edge/routes/app/flow-run-answers.test.js
//
// The two reads that return a run's RECORDED ANSWERS, and the boundaries they
// are the only routes on this mount to cross.
//
// Three of those boundaries decide whether the surfaces above can lie:
//   - a run that recorded NOTHING must arrive as null, never as an empty map;
//   - a comparison must not span templates, and the refusal has to be decided
//     on the ROWS, because the request carries run ids and only the rows say
//     which template each belongs to;
//   - the pending answers must be masked by the SAME implementation the write
//     path uses, or every secret-named field reads as changed on every dispatch.
//
// WHAT THIS FILE DOES NOT ESTABLISH: that the visibility predicate really
// withholds another operator's run. The driver is stubbed, so no predicate is
// evaluated — only that every statement carries it, which the visibility suite
// asserts across the whole feature.
const { test } = require('node:test');
const assert = require('node:assert');
const express = require('express');

let issued = [];
let responder = () => [];

require.cache[require.resolve('../../../../src/edge/db')] = {
  exports: {
    pool: {
      ro: {
        getConnection: async () => ({
          query: async (sql, params) => {
            issued.push({ sql, params });
            const out = responder(sql, params);
            if (out instanceof Error) throw out;
            return out;
          },
          release: () => {},
        }),
      },
      rw: { getConnection: async () => ({ query: async () => [], release: () => {} }) },
    },
    t: (x) => x,
  },
};

const { router } = require('../../../../src/edge/routes/app/flow-recipe-runs/run-answers');
const {
  MIN_COMPARE_RUNS, MAX_COMPARE_RUNS, parseCompareIds, readOutputs,
  REASON_PENDING_UNREADABLE_IDENTITY,
} = require('../../../../src/edge/routes/app/flow-recipe-runs/run-answers');
const { maskDeep } = require('../../../../src/edge/routes/app/flow-recipe-runs/serializer');
const { answerDocumentChanges } = require('../../../../src/edge/routes/app/flow-recipe-runs/input-diff');

function app(user) {
  const a = express();
  a.use(express.json());
  a.use((req, _res, next) => { if (user) req.user = user; next(); });
  a.use('/', router);
  return a;
}

async function call(a, method, path, body) {
  const server = a.listen(0);
  try {
    const { port } = server.address();
    const res = await fetch(`http://127.0.0.1:${port}${path}`, {
      method,
      ...(body === undefined ? {} : {
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(body),
      }),
    });
    const json = await res.json().catch(() => ({}));
    return { status: res.status, json };
  } finally {
    // Closed on the throwing path too. With the close reachable only where
    // nothing threw, a failed assertion leaks this handle, the runner never
    // exits, and the job reports a timeout instead of the assertion that failed.
    server.close();
  }
}

const get = (a, path) => call(a, 'GET', path);
const post = (a, path, body) => call(a, 'POST', path, body);

const PLAIN = { id: 'bbbbbbbb-0000-0000-0000-000000000002', role: 'user' };
const TEMPLATE = 'eeeeeeee-0000-0000-0000-000000000005';
const OTHER_TEMPLATE = 'eeeeeeee-0000-0000-0000-00000000000f';
const RUN_A = 'cccccccc-0000-0000-0000-00000000000a';
const RUN_B = 'cccccccc-0000-0000-0000-00000000000b';
const RUN_C = 'cccccccc-0000-0000-0000-00000000000c';

const captured = (over = {}) => JSON.stringify({
  entered: { size: '10' },
  computed: { total: '20' },
  fields: { size: 'f-size', total: 'f-total' },
  blueprint_id: 'ffffffff-0000-0000-0000-000000000006',
  variant_id: null,
  ...over,
});

function runRow(over = {}) {
  return {
    id: RUN_A,
    created_at: '2026-07-20 09:30:00',
    status: 'success',
    actor_id: PLAIN.id,
    template_id: TEMPLATE,
    output_snapshot: '{"main.txt":"out"}',
    input_snapshot: captured(),
    ...over,
  };
}

/** Answer the run read with these rows and every other statement with nothing.
 *  The actor-name enrichment issues its own read, which is not what any of
 *  these tests is about. */
function serve(rows) {
  responder = (sql) => (sql.includes('flow_recipe_runs') ? rows : []);
}

test.beforeEach(() => { issued = []; responder = () => []; });

// ── the selection's bounds ──────────────────────────────────────────────────

test('the comparison bounds are two to four, and are refused rather than trimmed', () => {
  assert.strictEqual(MIN_COMPARE_RUNS, 2);
  assert.strictEqual(MAX_COMPARE_RUNS, 4);
  assert.ok(parseCompareIds(`${RUN_A}`).error, 'one run is not a comparison');
  assert.ok(parseCompareIds([RUN_A, RUN_B, RUN_C, RUN_A, RUN_B].join(',')).error);
  assert.deepStrictEqual(parseCompareIds(`${RUN_A},${RUN_B}`).ids, [RUN_A, RUN_B]);
});

test('a run named twice is refused, not de-duplicated into a smaller selection', () => {
  const parsed = parseCompareIds(`${RUN_A},${RUN_A}`);
  assert.match(parsed.error, /only be named once/);
});

test('an id that is not an id never reaches a statement', async () => {
  const res = await get(app(PLAIN), '/runs/compare?ids=not-an-id,also-not');
  assert.strictEqual(res.status, 400);
  assert.strictEqual(issued.length, 0);
});

test('the browser and the server agree on the bounds', () => {
  // The two halves cannot import each other, so the numbers exist twice. A
  // selection the browser allows and the server refuses is a control that opens
  // a dialog reporting an error.
  const fs = require('node:fs');
  const path = require('node:path');
  const source = fs.readFileSync(path.join(
    __dirname, '../../../../../src/fmb/pages/flow-runs/run-compare-selection.ts',
  ), 'utf8');
  assert.match(source, new RegExp(`MIN_COMPARE_RUNS = ${MIN_COMPARE_RUNS}\\b`));
  assert.match(source, new RegExp(`MAX_COMPARE_RUNS = ${MAX_COMPARE_RUNS}\\b`));
});

// ── the comparison read ─────────────────────────────────────────────────────

test('a selection spanning two templates is refused', async () => {
  serve([runRow({ id: RUN_A }), runRow({ id: RUN_B, template_id: OTHER_TEMPLATE })]);
  const res = await get(app(PLAIN), `/runs/compare?ids=${RUN_A},${RUN_B}`);
  assert.strictEqual(res.status, 400);
  assert.strictEqual(res.json.error.code, 'CROSS_TEMPLATE_COMPARE');
});

test('runs recorded with NO template are one template\'s worth, not a mixture', async () => {
  serve([runRow({ id: RUN_A, template_id: null }), runRow({ id: RUN_B, template_id: null })]);
  const res = await get(app(PLAIN), `/runs/compare?ids=${RUN_A},${RUN_B}`);
  assert.strictEqual(res.status, 200);
  assert.strictEqual(res.json.data.runs.length, 2);
});

test('a run the caller cannot read refuses the whole comparison', async () => {
  // Silently drawing a smaller comparison would show a panel missing, which
  // reads as a run that recorded nothing.
  serve([runRow({ id: RUN_A })]);
  const res = await get(app(PLAIN), `/runs/compare?ids=${RUN_A},${RUN_B}`);
  assert.strictEqual(res.status, 404);
});

test('a run that recorded nothing arrives as null, never as an empty map', async () => {
  serve([runRow({ id: RUN_A }), runRow({ id: RUN_B, input_snapshot: null })]);
  const res = await get(app(PLAIN), `/runs/compare?ids=${RUN_A},${RUN_B}`);
  const [, second] = res.json.data.runs;
  assert.strictEqual(second.input_capture, 'absent');
  assert.strictEqual(second.entered, null);
  assert.strictEqual(second.computed, null);
  assert.strictEqual(second.fields, null);
});

test('a run whose capture was DROPPED says so, which is not "recorded nothing"', async () => {
  serve([
    runRow({ id: RUN_A }),
    runRow({ id: RUN_B, input_snapshot: JSON.stringify({ not_captured: 'too_large' }) }),
  ]);
  const res = await get(app(PLAIN), `/runs/compare?ids=${RUN_A},${RUN_B}`);
  assert.strictEqual(res.json.data.runs[1].input_capture, 'dropped');
  assert.strictEqual(res.json.data.runs[1].entered, null);
});

test('a run whose form genuinely held nothing arrives as an empty map', async () => {
  serve([
    runRow({ id: RUN_A }),
    runRow({ id: RUN_B, input_snapshot: captured({ entered: {}, computed: {}, fields: {} }) }),
  ]);
  const res = await get(app(PLAIN), `/runs/compare?ids=${RUN_A},${RUN_B}`);
  assert.strictEqual(res.json.data.runs[1].input_capture, 'captured');
  assert.deepStrictEqual(res.json.data.runs[1].entered, {});
});

test('a database without the column reports every run as not recorded', async () => {
  let first = true;
  responder = (sql) => {
    if (!sql.includes('flow_recipe_runs')) return [];
    if (first) {
      first = false;
      return Object.assign(new Error('Unknown column'), { errno: 1054 });
    }
    // The degraded statement does not select the column at all.
    return [runRow({ id: RUN_A, input_snapshot: undefined }), runRow({ id: RUN_B, input_snapshot: undefined })];
  };
  const res = await get(app(PLAIN), `/runs/compare?ids=${RUN_A},${RUN_B}`);
  assert.strictEqual(res.status, 200);
  for (const run of res.json.data.runs) {
    assert.strictEqual(run.input_capture, 'absent');
    assert.strictEqual(run.entered, null);
  }
});

test('outputs this build cannot read are absent rather than invented', async () => {
  assert.deepStrictEqual(readOutputs('{"a":"1"}'), { a: '1' });
  assert.deepStrictEqual(readOutputs('{"a":{"b":1}}'), { a: '{"b":1}' });
  assert.strictEqual(readOutputs('not json'), null);
  assert.strictEqual(readOutputs('[1,2]'), null);
  assert.strictEqual(readOutputs(null), null);
  assert.strictEqual(readOutputs(''), null);
  // SECURITY: a key that would change what the object MEANS rather than what it
  // holds never survives the read.
  assert.ok(!Object.prototype.hasOwnProperty.call(
    readOutputs('{"__proto__":"x","ok":"y"}'), '__proto__',
  ));
});

// ── one run's answers ───────────────────────────────────────────────────────

test('one run\'s answers are readable on their own, without a comparison', async () => {
  serve([runRow({ id: RUN_A })]);
  const res = await get(app(PLAIN), `/runs/${RUN_A}/input`);
  assert.strictEqual(res.status, 200);
  assert.deepStrictEqual(res.json.data.entered, { size: '10' });
  assert.deepStrictEqual(res.json.data.computed, { total: '20' });
  assert.deepStrictEqual(res.json.data.fields, { size: 'f-size', total: 'f-total' });
  // The form the answers were entered into, which is what a replay resolves.
  assert.strictEqual(res.json.data.snapshot_blueprint_id, 'ffffffff-0000-0000-0000-000000000006');
});

// fmb-1782 P2 #1: two templates can share a blueprint and variant, so a
// caller telling a run's template apart from a same-blueprint sibling needs
// the run's own template id — not only the blueprint/variant it snapshotted.
test('the single-run read reports the run\'s template id', async () => {
  serve([runRow({ id: RUN_A, template_id: TEMPLATE })]);
  const res = await get(app(PLAIN), `/runs/${RUN_A}/input`);
  assert.strictEqual(res.status, 200);
  assert.strictEqual(res.json.data.template_id, TEMPLATE);
});

test('the single-run read reports a null template id for a run recorded with no template', async () => {
  serve([runRow({ id: RUN_A, template_id: null })]);
  const res = await get(app(PLAIN), `/runs/${RUN_A}/input`);
  assert.strictEqual(res.status, 200);
  assert.strictEqual(res.json.data.template_id, null);
});

test('a run that is not readable is reported as absent rather than as refused', async () => {
  serve([]);
  assert.strictEqual((await get(app(PLAIN), `/runs/${RUN_A}/input`)).status, 404);
  assert.strictEqual((await get(app(PLAIN), '/runs/not-a-run/input')).status, 404);
});

test('every read is built through the shared rule, which restricts nothing', async () => {
  // These two reads return the recorded answers themselves, so they are the
  // most exposing reads on the mount. They are built through the same predicate
  // as every other run read — currently empty — rather than carrying a scope of
  // their own, so a narrowing reaches them with everything else instead of
  // leaving the document readable after the list around it has closed.
  serve([runRow({ id: RUN_A }), runRow({ id: RUN_B })]);
  await get(app(PLAIN), `/runs/compare?ids=${RUN_A},${RUN_B}`);
  await get(app(PLAIN), `/runs/${RUN_A}/input`);
  const runReads = issued.filter((q) => q.sql.includes('flow_recipe_runs'));
  assert.ok(runReads.length >= 2);
  for (const { sql, params } of runReads) {
    assert.ok(!/r\.`actor_id` = \?/.test(sql), `still scoped: ${sql}`);
    assert.ok(!params.includes(PLAIN.id), `caller identity bound: ${sql}`);
    assert.strictEqual((sql.match(/\?/g) || []).length, params.length);
  }
});

test('an unauthenticated caller reaches no statement at all', async () => {
  serve([runRow()]);
  assert.strictEqual((await get(app(null), `/runs/compare?ids=${RUN_A},${RUN_B}`)).status, 401);
  assert.strictEqual((await get(app(null), `/runs/${RUN_A}/input`)).status, 401);
  assert.strictEqual(issued.length, 0);
});

// ── the pre-dispatch difference ─────────────────────────────────────────────

const pending = (entered, computed = {}) => ({
  input_snapshot: JSON.stringify({
    entered, computed, fields: {}, blueprint_id: null, variant_id: null,
  }),
});

test('identical answers are reported as unchanged, not as nothing to compare', async () => {
  serve([{ id: RUN_A, created_at: '2026-07-20 09:30:00', actor_id: PLAIN.id, input_snapshot: captured() }]);
  const res = await post(
    app(PLAIN), `/groups/t.${TEMPLATE}/pending-diff`, pending({ size: '10' }, { total: '20' }),
  );
  assert.strictEqual(res.json.data.state, 'unchanged');
  assert.deepStrictEqual(res.json.data.changes, []);
  assert.strictEqual(res.json.data.previous.id, RUN_A);
});

test('the changed answers are named, one entry per key and half', async () => {
  serve([{ id: RUN_A, created_at: '2026-07-20 09:30:00', actor_id: PLAIN.id, input_snapshot: captured() }]);
  const res = await post(
    app(PLAIN), `/groups/t.${TEMPLATE}/pending-diff`,
    pending({ size: '11', added: 'new' }, {}),
  );
  assert.strictEqual(res.json.data.state, 'changed');
  assert.deepStrictEqual(res.json.data.changes, [
    { key: 'added', change: 'added', half: 'entered' },
    { key: 'size', change: 'changed', half: 'entered' },
    { key: 'total', change: 'removed', half: 'computed' },
  ]);
});

// THE TWO HALVES SHARE KEYS, and every fixture above happens not to — which is
// the one arrangement `buildFlowInputSnapshot` cannot produce for a computed
// field. The form's value map holds a computed field's value like any other, so
// the producer writes that field into `entered` AND into `computed` under the
// same key. A fixture that keeps them disjoint tests a document the application
// never emits, and stays green whether the halves are compared separately or
// together.
//
// Shaped here the way the real producer shapes it: `qty` is typed, `total` is
// derived from it, and BOTH appear in `entered`.
//
// The field ids are real identifiers because the PENDING document is validated
// by `parseInputSnapshot`, which refuses anything else — a shortened stand-in
// makes the fixture exercise the identity refusal rather than the comparison.
const FIELD_QTY = '11111111-1111-4111-8111-111111111111';
const FIELD_TOTAL = '22222222-2222-4222-8222-222222222222';
const realistic = (qty, total) => ({
  entered: { qty, total },
  computed: { total },
  fields: { qty: FIELD_QTY, total: FIELD_TOTAL },
  blueprint_id: null,
  variant_id: null,
});

test('one operator edit that moves one derived value is TWO changes, not three', async () => {
  serve([{
    id: RUN_A,
    created_at: '2026-07-20 09:30:00',
    actor_id: PLAIN.id,
    input_snapshot: JSON.stringify(realistic('5', '10')),
  }]);
  const res = await post(app(PLAIN), `/groups/t.${TEMPLATE}/pending-diff`, {
    input_snapshot: JSON.stringify(realistic('6', '12')),
  });
  assert.strictEqual(res.json.data.state, 'changed');
  // One entry per FIELD. Comparing the halves separately reported `total` twice
  // — once bare, on a surface where a bare line says a person typed the value.
  assert.deepStrictEqual(res.json.data.changes, [
    { key: 'qty', change: 'changed', half: 'entered' },
    { key: 'total', change: 'changed', half: 'computed' },
  ]);
});

// THE TWO HALVES CAN DISAGREE FOR THE SAME KEY, which neither the disjoint
// fixtures nor the realistic one above exercises: `compute_rules.overridable`
// lets an operator unlock a derived field and type over it, and
// `reconcileComputedField` then keeps THEIR number in the form's value map
// while `computedValue` goes on holding the formula's. The entered half is what
// the outputs — and therefore the payload — are built from.
const overridden = (typed, ruleSays) => ({
  entered: { total: typed },
  computed: { total: ruleSays },
  fields: { total: FIELD_TOTAL },
  blueprint_id: null,
  variant_id: null,
});

test('an overridden derived field is compared on the value that is DISPATCHED', async () => {
  // The operator overrode the rule and has now changed their override from 5 to
  // 6. The rule still says 10 on both sides. Comparing on the rule's opinion
  // reported no change at all, on the one screen whose whole point is that a
  // dispatch cannot be taken back — and the shipped run-to-run indicator, which
  // compares both maps, reads the same pair as changed once the run exists, so
  // the two surfaces contradicted each other about the same two runs.
  serve([{
    id: RUN_A,
    created_at: '2026-07-20 09:30:00',
    actor_id: PLAIN.id,
    input_snapshot: JSON.stringify(overridden('5', '10')),
  }]);
  const res = await post(app(PLAIN), `/groups/t.${TEMPLATE}/pending-diff`, {
    input_snapshot: JSON.stringify(overridden('6', '10')),
  });
  assert.strictEqual(res.json.data.state, 'changed');
  // Still ONE entry and still qualified as derived: which half a line is
  // reported in is a question about the line, not about the number.
  assert.deepStrictEqual(res.json.data.changes, [
    { key: 'total', change: 'changed', half: 'computed' },
  ]);
});

test('an override that did not move reports nothing, whatever the rule now says', () => {
  // Only the formula's opinion moved; the dispatched value is 6 both times.
  // Nothing different is about to be sent, which is the question this surface
  // asks. Documented as the residual disagreement with the shipped indicator.
  assert.deepStrictEqual(
    answerDocumentChanges(
      { entered: { total: '6' }, computed: { total: '10' } },
      { entered: { total: '6' }, computed: { total: '12' } },
    ),
    [],
  );
});

test('a hidden derived field, which never reaches the entered half, still compares', () => {
  // `entered` is the SUBTRACTED value map, so a hidden field with a rule appears
  // only in `computed`. The fallback is what keeps it comparable at all.
  assert.deepStrictEqual(
    answerDocumentChanges(
      { entered: {}, computed: { hidden_total: '10' } },
      { entered: {}, computed: { hidden_total: '11' } },
    ),
    [{ key: 'hidden_total', change: 'changed', half: 'computed' }],
  );
});

test('a derived field is qualified even when only one side derived it', async () => {
  // The rule was added between the two dispatches: `total` was typed before and
  // is derived now. An unqualified line claims a person typed it, so the
  // ambiguous case qualifies.
  serve([{
    id: RUN_A,
    created_at: '2026-07-20 09:30:00',
    actor_id: PLAIN.id,
    input_snapshot: JSON.stringify({
      entered: { qty: '5', total: '9' },
      computed: {},
      fields: {},
      blueprint_id: null,
      variant_id: null,
    }),
  }]);
  const res = await post(app(PLAIN), `/groups/t.${TEMPLATE}/pending-diff`, {
    input_snapshot: JSON.stringify(realistic('5', '10')),
  });
  assert.deepStrictEqual(res.json.data.changes, [
    { key: 'total', change: 'changed', half: 'computed' },
  ]);
});

test('a document whose halves agree reports nothing at all', async () => {
  serve([{
    id: RUN_A,
    created_at: '2026-07-20 09:30:00',
    actor_id: PLAIN.id,
    input_snapshot: JSON.stringify(realistic('5', '10')),
  }]);
  const res = await post(app(PLAIN), `/groups/t.${TEMPLATE}/pending-diff`, {
    input_snapshot: JSON.stringify(realistic('5', '10')),
  });
  assert.strictEqual(res.json.data.state, 'unchanged');
  assert.deepStrictEqual(res.json.data.changes, []);
});

test('a field added or removed is one entry, whichever half it sat in', () => {
  assert.deepStrictEqual(
    answerDocumentChanges(
      { entered: { a: '1', gone: 'x' }, computed: {} },
      { entered: { a: '1', fresh: 'y' }, computed: { fresh: 'y' } },
    ),
    [
      { key: 'fresh', change: 'added', half: 'computed' },
      { key: 'gone', change: 'removed', half: 'entered' },
    ],
  );
});

test('no previous run is its own answer, and names no run', async () => {
  serve([]);
  const res = await post(app(PLAIN), `/groups/t.${TEMPLATE}/pending-diff`, pending({ size: '10' }));
  assert.strictEqual(res.json.data.state, 'unavailable');
  assert.strictEqual(res.json.data.reason, 'first_run');
  assert.strictEqual(res.json.data.previous, null);
});

test('a previous run WITHOUT a snapshot names the run and refuses to compare', async () => {
  serve([{ id: RUN_A, created_at: '2026-07-20 09:30:00', actor_id: PLAIN.id, input_snapshot: null }]);
  const res = await post(app(PLAIN), `/groups/t.${TEMPLATE}/pending-diff`, pending({ size: '10' }));
  assert.strictEqual(res.json.data.state, 'unavailable');
  assert.strictEqual(res.json.data.reason, 'previous_not_recorded');
  // The run is named even though it could not be compared: "there is a previous
  // run and it recorded nothing" is a different fact from "there is none".
  assert.strictEqual(res.json.data.previous.id, RUN_A);
});

test('a previous run whose capture was dropped says so, separately', async () => {
  serve([{
    id: RUN_A,
    created_at: '2026-07-20 09:30:00',
    actor_id: PLAIN.id,
    input_snapshot: JSON.stringify({ not_captured: 'too_large' }),
  }]);
  const res = await post(app(PLAIN), `/groups/t.${TEMPLATE}/pending-diff`, pending({ size: '10' }));
  assert.strictEqual(res.json.data.reason, 'previous_capture_dropped');
});

test('a pending capture the page declined to make is reported, not compared', async () => {
  serve([{ id: RUN_A, created_at: '2026-07-20 09:30:00', actor_id: PLAIN.id, input_snapshot: captured() }]);
  const res = await post(app(PLAIN), `/groups/t.${TEMPLATE}/pending-diff`, {
    input_snapshot: JSON.stringify({ not_captured: 'outputs_stale' }),
  });
  assert.strictEqual(res.json.data.state, 'unavailable');
  assert.strictEqual(res.json.data.reason, 'pending_not_captured');
  // Nothing was read: there is nothing to read it against.
  assert.strictEqual(issued.length, 0);
});

test('the pending answers are masked by the SAME rule the stored ones were', async () => {
  // The stored value is `****` because the write path masked it. Comparing the
  // operator's real value against that would report this field as changed on
  // every dispatch, for ever.
  const stored = JSON.stringify({
    entered: maskDeep({ api_key: 'REAL-SECRET', size: '10' }),
    computed: {},
    fields: {},
    blueprint_id: null,
    variant_id: null,
  });
  serve([{ id: RUN_A, created_at: '2026-07-20 09:30:00', actor_id: PLAIN.id, input_snapshot: stored }]);
  const res = await post(
    app(PLAIN), `/groups/t.${TEMPLATE}/pending-diff`,
    pending({ api_key: 'REAL-SECRET', size: '10' }),
  );
  assert.strictEqual(res.json.data.state, 'unchanged');
});

test('a pending capture the DISPATCH would let through is degraded, not refused', async () => {
  // The dispatch path drops the capture on an identity value that is not
  // identifier-shaped and lets the run out, because the id shape is a
  // convention nothing enforces. A confirmation that refused here would report
  // a broken build in front of a dispatch that would have succeeded, and the
  // generic failure copy would blame the PREVIOUS run for it.
  serve([{ id: RUN_A, created_at: '2026-07-20 09:30:00', actor_id: PLAIN.id, input_snapshot: captured() }]);
  const res = await post(app(PLAIN), `/groups/t.${TEMPLATE}/pending-diff`, {
    input_snapshot: JSON.stringify({
      entered: { size: '10' },
      computed: {},
      fields: { size: 'not-an-identifier' },
      blueprint_id: null,
      variant_id: null,
    }),
  });
  assert.strictEqual(res.status, 200);
  assert.strictEqual(res.json.data.state, 'unavailable');
  assert.strictEqual(res.json.data.reason, REASON_PENDING_UNREADABLE_IDENTITY);
  // Nothing was read: there is nothing to read it against.
  assert.strictEqual(issued.length, 0);
});

test('a pending document this server cannot read is refused rather than compared', async () => {
  serve([]);
  const res = await post(app(PLAIN), `/groups/t.${TEMPLATE}/pending-diff`, {
    input_snapshot: '{"unexpected":"shape"}',
  });
  assert.strictEqual(res.status, 400);
  assert.strictEqual(issued.length, 0);
});

test('a group identifier this server does not recognise reaches no statement', async () => {
  serve([]);
  const res = await post(app(PLAIN), '/groups/wat/pending-diff', pending({ size: '10' }));
  assert.strictEqual(res.status, 404);
  assert.strictEqual(issued.length, 0);
});

test('the runs recorded with no template are addressable as their own group', async () => {
  serve([]);
  const res = await post(app(PLAIN), '/groups/none/pending-diff', pending({ size: '10' }));
  assert.strictEqual(res.status, 200);
  const [read] = issued.filter((q) => q.sql.includes('flow_recipe_runs'));
  // `= NULL` is never true, so the two kinds of group cannot share a comparison.
  assert.match(read.sql, /r\.`template_id` IS NULL/);
});

test('the pending difference never writes', async () => {
  serve([{ id: RUN_A, created_at: '2026-07-20 09:30:00', actor_id: PLAIN.id, input_snapshot: captured() }]);
  await post(app(PLAIN), `/groups/t.${TEMPLATE}/pending-diff`, pending({ size: '11' }));
  for (const { sql } of issued) {
    assert.ok(/^\s*SELECT/i.test(sql), `a read route issued a non-SELECT: ${sql}`);
  }
});
