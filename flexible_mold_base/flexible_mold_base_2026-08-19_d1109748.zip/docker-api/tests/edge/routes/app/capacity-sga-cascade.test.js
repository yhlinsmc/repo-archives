/**
 * capacity-sga-cascade.test.js — the phase-7 item-6 backend cascade
 * (cascadeDbSgaToInstances): editing a database's Primary/Standby SGA re-derives
 * the persisted `sga_gb` of its EXISTING child db_instances in the SAME write tx,
 * so the KVMs "SGA Ref" reflects the edit after the FE refetch.
 *
 * Exercised as the exported in-tx hook against a recording mock connection (the
 * derivation is the shared sga-defaults chain, already unit-tested; here we prove
 * the cascade's WIRING: scoped to the two SGA columns, per-role BATCHED UPDATE,
 * value-diff no-op when the derived value is unchanged — the FE grid re-sends
 * every cell on any row edit — graceful skip on an absent column, and error
 * propagation → factory rollback).
 */
const { describe, it, beforeEach } = require('node:test');
const assert = require('node:assert/strict');

// _shared.js / children.js destructure { t } from ../../../db at load (never call
// it at load time); stub the db module so the require is side-effect-free (no pool).
const dbKey = require.resolve('../../../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: {}, t: (n) => n },
};

const { cascadeDbSgaToInstances } = require('../../../../src/edge/routes/app/capacity/children');

let state;
function freshState() {
  return {
    updates: [],       // { role, sga_gb } for each per-role batched UPDATE issued
    selectedInstances: false,
    throwOnUpdate: false,
    // fixtures the mock returns:
    database: { primary_sga_gb: 64, standby_sga_gb: 48, profile_id: null, scenario_id: 's1' },
    settingsRow: null, // cap_settings row (null → seed defaults)
    profileRow: null,  // cap_vm_profiles row
    instances: [],     // { role, sga_gb } — the CURRENT stored child rows
  };
}

const conn = {
  async query(sql, params = []) {
    if (/SELECT primary_sga_gb, standby_sga_gb, profile_id, scenario_id FROM `cap_databases`/.test(sql)) {
      return state.database ? [state.database] : [];
    }
    if (/SELECT \* FROM `cap_settings`/.test(sql)) {
      return state.settingsRow ? [state.settingsRow] : [];
    }
    if (/SELECT \* FROM `cap_vm_profiles`/.test(sql)) {
      return state.profileRow ? [state.profileRow] : [];
    }
    if (/SELECT role, sga_gb FROM `cap_db_instances` WHERE database_id = \? FOR UPDATE/.test(sql)) {
      state.selectedInstances = true;
      return state.instances;
    }
    if (/UPDATE `cap_db_instances` SET sga_gb = \? WHERE database_id = \? AND role = \? AND sga_gb <> \?/.test(sql)) {
      if (state.throwOnUpdate) throw new Error('simulated db failure');
      state.updates.push({ role: params[2], sga_gb: params[0] });
      return { affectedRows: 1 };
    }
    throw new Error('unexpected SQL in cascade test: ' + sql);
  },
};

const req = { params: { id: 'db1' } };

beforeEach(() => { state = freshState(); });

describe('cascadeDbSgaToInstances — trigger scope', () => {
  it('is a no-op when neither SGA column is present (e.g. gated out on a lagging schema)', async () => {
    state.instances = [{ role: 'primary', sga_gb: 32 }];
    await cascadeDbSgaToInstances(conn, req, { name: 'renamed', profile_id: 'p1' });
    assert.equal(state.selectedInstances, false, 'must not even read instances');
    assert.deepEqual(state.updates, []);
  });

  it('cascades a primary_sga_gb edit to primary instances only (one batched UPDATE)', async () => {
    state.database = { primary_sga_gb: 64, standby_sga_gb: 48, profile_id: null, scenario_id: 's1' };
    state.instances = [
      { role: 'primary', sga_gb: 32 },   // differs → triggers the batched write
      { role: 'primary', sga_gb: 64 },   // already correct → the SQL `sga_gb <> ?` skips it
      { role: 'standby', sga_gb: 16 },
    ];
    await cascadeDbSgaToInstances(conn, req, { primary_sga_gb: 64 });
    assert.deepEqual(state.updates, [{ role: 'primary', sga_gb: 64 }], 'one batched primary UPDATE, standby untouched');
  });

  it('cascades a standby_sga_gb edit to standby instances only', async () => {
    state.database = { primary_sga_gb: 64, standby_sga_gb: 48, profile_id: null, scenario_id: 's1' };
    state.instances = [
      { role: 'primary', sga_gb: 64 },
      { role: 'standby', sga_gb: 16 },
    ];
    await cascadeDbSgaToInstances(conn, req, { standby_sga_gb: 48 });
    assert.deepEqual(state.updates, [{ role: 'standby', sga_gb: 48 }]);
  });

  it('cascades both roles when both SGA columns change', async () => {
    state.database = { primary_sga_gb: 100, standby_sga_gb: 50, profile_id: null, scenario_id: 's1' };
    state.instances = [
      { role: 'primary', sga_gb: 10 },
      { role: 'standby', sga_gb: 10 },
    ];
    await cascadeDbSgaToInstances(conn, req, { primary_sga_gb: 100, standby_sga_gb: 50 });
    assert.deepEqual(
      state.updates.sort((a, b) => a.role.localeCompare(b.role)),
      [{ role: 'primary', sga_gb: 100 }, { role: 'standby', sga_gb: 50 }],
    );
  });

  it('only cascades the present role when the other SGA column was gated out (M3 graceful skip)', async () => {
    state.database = { primary_sga_gb: 64, standby_sga_gb: 48, profile_id: null, scenario_id: 's1' };
    state.instances = [
      { role: 'primary', sga_gb: 10 },
      { role: 'standby', sga_gb: 10 },
    ];
    // primary_sga_gb absent (as the factory's column gate would drop it) → only standby cascades.
    await cascadeDbSgaToInstances(conn, req, { standby_sga_gb: 48 });
    assert.deepEqual(state.updates, [{ role: 'standby', sga_gb: 48 }]);
  });
});

describe('cascadeDbSgaToInstances — value-diff no-op (M1: FE re-sends every cell)', () => {
  it('a full-row PUT re-sending unchanged SGA issues ZERO UPDATE statements', async () => {
    state.database = { primary_sga_gb: 64, standby_sga_gb: 48, profile_id: null, scenario_id: 's1' };
    state.instances = [
      { role: 'primary', sga_gb: 64 },   // already the derived value
      { role: 'standby', sga_gb: 48 },   // already the derived value
    ];
    // The grid sends the whole row on a rename/team edit — SGA keys present but unchanged.
    await cascadeDbSgaToInstances(conn, req, {
      name: 'renamed', profile_id: null, primary_sga_gb: 64, standby_sga_gb: 48,
    });
    assert.equal(state.selectedInstances, true, 'reads instances to compare');
    assert.deepEqual(state.updates, [], 'no UPDATE when derived == stored');
  });
});

describe('cascadeDbSgaToInstances — derivation reuse', () => {
  it('a null primary_sga_gb derives the profile SGA cap for primary instances', async () => {
    state.database = { primary_sga_gb: null, standby_sga_gb: 48, profile_id: 'p1', scenario_id: 's1' };
    state.profileRow = { class: 'DB', mode: 'custom', cpu: 8, mem_gb: 64, sga_cap_gb: 40 };
    state.instances = [{ role: 'primary', sga_gb: 10 }];
    await cascadeDbSgaToInstances(conn, req, { primary_sga_gb: null });
    assert.deepEqual(state.updates, [{ role: 'primary', sga_gb: 40 }], 'falls back to profile cap 40');
  });

  it('a null standby_sga_gb derives the settings standby default', async () => {
    state.database = { primary_sga_gb: 64, standby_sga_gb: null, profile_id: null, scenario_id: 's1' };
    state.settingsRow = { standby_sga_default_gb: 24 };
    state.instances = [{ role: 'standby', sga_gb: 10 }];
    await cascadeDbSgaToInstances(conn, req, { standby_sga_gb: null });
    assert.deepEqual(state.updates, [{ role: 'standby', sga_gb: 24 }]);
  });
});

describe('cascadeDbSgaToInstances — edge cases', () => {
  it('does nothing when the database has no child instances', async () => {
    state.instances = [];
    await cascadeDbSgaToInstances(conn, req, { primary_sga_gb: 64 });
    assert.equal(state.selectedInstances, true, 'reads the (empty) instance set');
    assert.deepEqual(state.updates, []);
  });

  it('does nothing when the database row is gone (defensive)', async () => {
    state.database = null;
    await cascadeDbSgaToInstances(conn, req, { primary_sga_gb: 64 });
    assert.equal(state.selectedInstances, false);
    assert.deepEqual(state.updates, []);
  });

  it('propagates a child UPDATE failure so the factory rolls the tx back', async () => {
    state.database = { primary_sga_gb: 64, standby_sga_gb: 48, profile_id: null, scenario_id: 's1' };
    state.instances = [{ role: 'primary', sga_gb: 10 }];
    state.throwOnUpdate = true;
    await assert.rejects(
      () => cascadeDbSgaToInstances(conn, req, { primary_sga_gb: 64 }),
      /simulated db failure/,
    );
  });
});
