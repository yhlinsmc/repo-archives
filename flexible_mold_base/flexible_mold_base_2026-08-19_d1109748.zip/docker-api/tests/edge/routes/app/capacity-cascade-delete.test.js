'use strict';

/**
 * capacity-cascade-delete.test.js — the approved cascade depth (spec §4 Q20/Q21):
 * a site delete takes its hypervisors with it (their VMs return to the tray) and
 * a database delete takes its instances with it (its db_host VM detaches). Both
 * reverse a prior disposition, so the declaration shape is pinned here and the
 * real-DB half proves the statement matches the declaration.
 *
 * The pure declaration tests run without a database; the real-DB tests skip with
 * a stated reason when none is reachable, and fail instead of skipping under
 * REQUIRE_INTEGRATION_DB=1.
 */
const {
  test, describe, before, after, beforeEach,
} = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const net = require('node:net');
const http = require('node:http');
const express = require('express');
const mariadb = require('mariadb');

const TEST_PREFIX = 'ccd_';
const tbl = (name) => `${TEST_PREFIX}${name}`;

let pool = null;
const lease = () => pool.getConnection();
const handle = () => ({ getConnection: lease, query: (sql, params) => pool.query(sql, params) });

const dbKey = require.resolve('../../../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey,
  filename: dbKey,
  loaded: true,
  exports: {
    pool: { ro: handle(), rw: handle() },
    t: tbl,
    getDynamicPool: async () => ({ ro: handle(), rw: handle() }),
  },
};

const { buildEngineTableDDLs, buildInfraTableDDLs } = require('../../../../src/table-ddls');
const { CHILD_DELETE_BEHAVIOR } = require('../../../../src/edge/routes/app/capacity/_shared');
const { TABLES } = require('../../../../src/shared/constants');
const capacityRouter = require('../../../../src/edge/routes/app/capacity');

// ── Pure declaration shape (spec §4) ─────────────────────────────────────────

describe('the approved cascade depth is declared, not just executed', () => {
  test('database delete cascades its instances and unplaces db_host VMs', () => {
    const b = CHILD_DELETE_BEHAVIOR.databases;
    assert.ok(b.cascade.some((c) => c.table === TABLES.CAP_DB_INSTANCES && c.column === 'database_id'),
      'a database delete no longer cascades its instances');
    assert.ok(b.unplace.some((u) => u.table === TABLES.CAP_VMS && u.column === 'database_id'),
      'a database delete no longer detaches its db_host VMs');
  });

  test('site sweep declares hypervisors as cascade, dc_refs stays block', () => {
    const groups = CHILD_DELETE_BEHAVIOR.sites.sweep.groups;
    const hv = groups.find((g) => g.table === TABLES.CAP_HYPERVISORS);
    const dcRefs = groups.find((g) => g.column === 'dc_refs');
    assert.strictEqual(hv.disposition, 'cascade');
    assert.strictEqual(dcRefs.disposition, 'block');
  });

  test('a VM pinned to the site still only unplaces', () => {
    const vm = CHILD_DELETE_BEHAVIOR.sites.sweep.groups.find((g) => g.kind === 'vm');
    assert.strictEqual(vm.disposition, 'unplace');
  });
});

// ── Real-DB harness (shape shared with capacity-site-delete-real-db.test.js) ──

function parseEnvFile(filePath) {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    const out = {};
    for (const line of content.split('\n')) {
      const m = line.match(/^\s*([A-Z_][A-Z0-9_]*)\s*=\s*(.*)\s*$/);
      if (!m) continue;
      let value = m[2];
      if ((value.startsWith('"') && value.endsWith('"'))
        || (value.startsWith("'") && value.endsWith("'"))) value = value.slice(1, -1);
      out[m[1]] = value;
    }
    return out;
  } catch {
    return null;
  }
}

function probePort(host, port, timeoutMs = 2000) {
  return new Promise((resolve) => {
    const socket = new net.Socket();
    let done = false;
    const finish = (ok) => { if (done) return; done = true; socket.destroy(); resolve(ok); };
    socket.setTimeout(timeoutMs);
    socket.once('connect', () => finish(true));
    socket.once('timeout', () => finish(false));
    socket.once('error', () => finish(false));
    socket.connect(port, host);
  });
}

async function resolveMariaDbConfig() {
  if (process.env.DB_TEST_HOST && process.env.DB_TEST_ROOT_PASSWORD) {
    return {
      host: process.env.DB_TEST_HOST,
      port: parseInt(process.env.DB_TEST_PORT || '3306', 10),
      user: 'root',
      password: process.env.DB_TEST_ROOT_PASSWORD,
    };
  }
  const envPath = path.resolve(__dirname, '../../../../../.devcontainer/.env');
  const env = parseEnvFile(envPath);
  if (!env || !env.DB_ROOT_PASSWORD) return null;
  const port = parseInt(env.DB_PORT || '3306', 10);
  for (const host of ['127.0.0.1', 'mariadb', 'localhost']) {
    if (await probePort(host, port, 2000)) return { host, port, user: 'root', password: env.DB_ROOT_PASSWORD };
  }
  return null;
}

const ADMIN = { id: 'aa11bb22-cc33-4d44-8e55-ff6677889900', role: 'admin' };
const SCENARIO_ID = '11112222-3333-4444-8555-666677778888';

let dbReady = false;
let skipReason = null;
let testDbName = null;
let server = null;
let baseUrl = null;
let currentUser = ADMIN;

before(async () => {
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) {
    skipReason = 'no MariaDB reachable via .devcontainer/.env or env vars';
    if (process.env.REQUIRE_INTEGRATION_DB === '1') throw new Error(`REQUIRE_INTEGRATION_DB=1 set but ${skipReason}.`);
    return;
  }
  testDbName = `cap_cascade_delete_test_${process.pid}_${Date.now()}`;
  let admin = null;
  try {
    admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`CREATE DATABASE \`${testDbName}\``);
    await admin.query(`USE \`${testDbName}\``);
    for (const sql of [...buildInfraTableDDLs(tbl), ...buildEngineTableDDLs(tbl)]) await admin.query(sql);
    await admin.end();
    admin = null;
    pool = mariadb.createPool({
      ...dbConfig, database: testDbName, connectionLimit: 6, connectTimeout: 5000,
    });
    const app = express();
    app.use(express.json());
    app.use((req, _res, next) => { req.user = currentUser; next(); });
    app.use('/edge/app/capacity', capacityRouter);
    server = http.createServer(app);
    await new Promise((r) => server.listen(0, r));
    baseUrl = `http://127.0.0.1:${server.address().port}`;
    dbReady = true;
  } catch (err) {
    skipReason = `setup failed: ${err.message}`;
    if (admin) { try { await admin.end(); } catch { /* best effort */ } }
    if (process.env.REQUIRE_INTEGRATION_DB === '1') throw err;
  }
});

after(async () => {
  if (server) { try { server.close(); } catch { /* best effort */ } }
  if (pool) { try { await pool.end(); } catch { /* best effort */ } }
  if (!testDbName) return;
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) return;
  try {
    const admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`DROP DATABASE IF EXISTS \`${testDbName}\``);
    await admin.end();
  } catch { /* best effort */ }
});

async function call(user, method, url, body) {
  currentUser = user;
  const res = await fetch(`${baseUrl}${url}`, {
    method,
    headers: { 'content-type': 'application/json' },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const text = await res.text();
  let parsed = null;
  try { parsed = JSON.parse(text); } catch { parsed = { raw: text }; }
  return { status: res.status, body: parsed };
}

const q = (sql, params) => pool.query(sql, params);
const one = async (sql, params) => (await pool.query(sql, params))[0];
const rowCount = async (table, where, params) => Number(
  (await one(`SELECT COUNT(*) AS n FROM \`${tbl(table)}\` ${where}`, params)).n,
);

const CAPACITY_TABLES = [
  'cap_waivers', 'cap_rules', 'cap_custom_group_members', 'cap_custom_groups',
  'cap_db_instances', 'cap_vms', 'cap_databases', 'cap_hypervisors', 'cap_sites',
  'cap_versions', 'cap_bundle_items', 'cap_bundles', 'cap_field_defs',
  'cap_vm_profiles', 'cap_disk_combos', 'cap_teams', 'cap_hardware_specs',
  'cap_settings', 'cap_scenarios',
];

const guard = (t) => {
  if (dbReady) return false;
  t.skip(skipReason || 'database not ready');
  return true;
};

beforeEach(async () => {
  if (!dbReady) return;
  for (const name of [...CAPACITY_TABLES, 'feature_audit', 'users']) await q(`DELETE FROM \`${tbl(name)}\``);
  await q(`INSERT INTO \`${tbl('users')}\` (id, email, role, banned) VALUES (?,?,?,0)`,
    [ADMIN.id, 'admin@test.local', 'admin']);
  await q(`INSERT INTO \`${tbl('cap_scenarios')}\` (id, name, owner_id) VALUES (?,?,?)`,
    [SCENARIO_ID, 'a scenario', null]);
});

const base = `/edge/app/capacity/scenarios/${SCENARIO_ID}`;

async function seedSpec(name = 'A') {
  const spec = await call(ADMIN, 'POST', '/edge/app/capacity/config/hardware_specs',
    { name: `spec-${name}`, cpu_total: 64, mem_total_gb: 512, disk_total_gb: 4096 });
  assert.equal(spec.status, 201, JSON.stringify(spec.body));
  return spec.body.data.id;
}

// ── Site delete now cascades its hypervisors ────────────────────────────────

describe('a site delete cascades its hypervisors and returns their VMs to the tray', () => {
  test('the host is deleted, its VM survives detached, and the report names both', async (t) => {
    if (guard(t)) return;
    const specId = await seedSpec();
    const site = await call(ADMIN, 'POST', `${base}/sites`, { name: 'DC-A' });
    const siteId = site.body.data.id;
    const hv = await call(ADMIN, 'POST', `${base}/hypervisors`, { name: 'host-a', site_id: siteId, spec_id: specId });
    const hvId = hv.body.data.id;
    const vm = await call(ADMIN, 'POST', `${base}/vms`, { name: 'kvm1', vm_type: 'ap_host', hypervisor_id: hvId });
    assert.equal(vm.status, 200, JSON.stringify(vm.body));
    const vmId = vm.body.data.id;

    const gone = await call(ADMIN, 'DELETE', `${base}/sites/${siteId}`);
    assert.equal(gone.status, 200, JSON.stringify(gone.body));
    // The site and its hypervisor are gone; the VM survives with a NULL host.
    assert.equal(await rowCount('cap_sites', 'WHERE id = ?', [siteId]), 0);
    assert.equal(await rowCount('cap_hypervisors', 'WHERE id = ?', [hvId]), 0);
    assert.equal(await rowCount('cap_vms', 'WHERE id = ?', [vmId]), 1, 'the VM was deleted rather than unplaced');
    const stored = await one(`SELECT hypervisor_id FROM \`${tbl('cap_vms')}\` WHERE id = ?`, [vmId]);
    assert.equal(stored.hypervisor_id, null, 'the VM still points at a deleted hypervisor');
    // The response names what moved: 1 hypervisor deleted, 1 VM unplaced.
    assert.equal(gone.body.data.cascaded['cap_hypervisors.site_id'], 1);
    assert.equal(gone.body.data.unplaced['cap_vms.hypervisor_id'], 1);
  });

  test('a dc_refs database still blocks the delete (409), and the site survives', async (t) => {
    if (guard(t)) return;
    const site = await call(ADMIN, 'POST', `${base}/sites`, { name: 'DC-A' });
    const siteId = site.body.data.id;
    const db = await call(ADMIN, 'POST', `${base}/databases`,
      { function_name: 'ORDERS', topology: 'single', dc_refs: [siteId] });
    assert.equal(db.status, 200, JSON.stringify(db.body));

    const refused = await call(ADMIN, 'DELETE', `${base}/sites/${siteId}`);
    assert.equal(refused.status, 409, JSON.stringify(refused.body));
    assert.match(refused.body.error.message, /database restricted to this datacenter/);
    assert.equal(await rowCount('cap_sites', 'WHERE id = ?', [siteId]), 1);
  });
});

// ── Database delete now cascades its instances ──────────────────────────────

describe('a database delete cascades its instances and detaches its db_host VM', () => {
  test('both instance rows go, the db_host VM survives with database_id NULL', async (t) => {
    if (guard(t)) return;
    const specId = await seedSpec();
    const site = await call(ADMIN, 'POST', `${base}/sites`, { name: 'DC-A' });
    const hv = await call(ADMIN, 'POST', `${base}/hypervisors`,
      { name: 'host-a', site_id: site.body.data.id, spec_id: specId });
    const vm = await call(ADMIN, 'POST', `${base}/vms`,
      { name: 'dbhost', vm_type: 'db_host', hypervisor_id: hv.body.data.id });
    assert.equal(vm.status, 200, JSON.stringify(vm.body));
    const vmId = vm.body.data.id;
    const db = await call(ADMIN, 'POST', `${base}/databases`, { function_name: 'ORDERS', topology: 'primary_standby' });
    const dbId = db.body.data.id;
    // Attach the db_host VM to the database and give the database two instances.
    await call(ADMIN, 'PUT', `${base}/vms/${vmId}`, { database_id: dbId });
    for (const role of ['primary', 'standby']) {
      const inst = await call(ADMIN, 'POST', `${base}/db_instances`,
        { name: `inst-${role}`, vm_id: vmId, database_id: dbId, role });
      assert.equal(inst.status, 200, JSON.stringify(inst.body));
    }
    assert.equal(await rowCount('cap_db_instances', 'WHERE database_id = ?', [dbId]), 2);

    const gone = await call(ADMIN, 'DELETE', `${base}/databases/${dbId}`);
    assert.equal(gone.status, 200, JSON.stringify(gone.body));
    assert.equal(await rowCount('cap_databases', 'WHERE id = ?', [dbId]), 0);
    assert.equal(await rowCount('cap_db_instances', 'WHERE database_id = ?', [dbId]), 0,
      'the database instances were left dangling');
    assert.equal(await rowCount('cap_vms', 'WHERE id = ?', [vmId]), 1, 'the db_host VM was deleted');
    const stored = await one(`SELECT database_id FROM \`${tbl('cap_vms')}\` WHERE id = ?`, [vmId]);
    assert.equal(stored.database_id, null, 'the db_host VM still points at a deleted database');
    assert.equal(gone.body.data.cascaded['cap_db_instances.database_id'], 2);
    assert.equal(gone.body.data.unplaced['cap_vms.database_id'], 1);
  });
});

// ── B1: a cascaded instance takes its OWN cascade (group memberships) ────────

describe('a cascade child cleans up its own grandchildren, not just its row', () => {
  test('a database delete removes the group memberships of the instances it cascades', async (t) => {
    if (guard(t)) return;
    const specId = await seedSpec();
    const site = await call(ADMIN, 'POST', `${base}/sites`, { name: 'DC-A' });
    const hv = await call(ADMIN, 'POST', `${base}/hypervisors`,
      { name: 'host-a', site_id: site.body.data.id, spec_id: specId });
    const vm = await call(ADMIN, 'POST', `${base}/vms`, { name: 'dbhost', vm_type: 'db_host', hypervisor_id: hv.body.data.id });
    const db = await call(ADMIN, 'POST', `${base}/databases`, { function_name: 'ORDERS', topology: 'primary_standby' });
    const dbId = db.body.data.id;
    await call(ADMIN, 'PUT', `${base}/vms/${vm.body.data.id}`, { database_id: dbId });
    const inst = await call(ADMIN, 'POST', `${base}/db_instances`,
      { name: 'i-primary', vm_id: vm.body.data.id, database_id: dbId, role: 'primary' });
    const groupId = '77770000-1111-4222-8333-444455556666';
    await q(`INSERT INTO \`${tbl('cap_custom_groups')}\` (id, scenario_id, name) VALUES (?,?,?)`,
      [groupId, SCENARIO_ID, 'grp']);
    await q(`INSERT INTO \`${tbl('cap_custom_group_members')}\` (id, scenario_id, group_id, member_instance_id) VALUES (UUID(),?,?,?)`,
      [SCENARIO_ID, groupId, inst.body.data.id]);
    assert.equal(await rowCount('cap_custom_group_members', 'WHERE member_instance_id = ?', [inst.body.data.id]), 1);

    const gone = await call(ADMIN, 'DELETE', `${base}/databases/${dbId}`);
    assert.equal(gone.status, 200, JSON.stringify(gone.body));
    // The instance is gone, and so is the group membership that pointed at it —
    // the direct-instance delete path already cleaned this; the flat cascade must
    // not diverge (a dangling member_instance_id was the defect).
    assert.equal(await rowCount('cap_db_instances', 'WHERE id = ?', [inst.body.data.id]), 0);
    assert.equal(await rowCount('cap_custom_group_members', 'WHERE member_instance_id = ?', [inst.body.data.id]), 0,
      'the cascaded instance left a dangling group membership');
    assert.equal(gone.body.data.cascaded['cap_custom_group_members.member_instance_id'], 1,
      'the delete report does not name the grandchild it removed');
  });

  test('a VM delete removes the group memberships of the instances it cascades', async (t) => {
    if (guard(t)) return;
    const specId = await seedSpec();
    const site = await call(ADMIN, 'POST', `${base}/sites`, { name: 'DC-A' });
    const hv = await call(ADMIN, 'POST', `${base}/hypervisors`,
      { name: 'host-a', site_id: site.body.data.id, spec_id: specId });
    const vm = await call(ADMIN, 'POST', `${base}/vms`, { name: 'dbhost', vm_type: 'db_host', hypervisor_id: hv.body.data.id });
    const vmId = vm.body.data.id;
    const db = await call(ADMIN, 'POST', `${base}/databases`, { function_name: 'ORDERS', topology: 'primary_standby' });
    await call(ADMIN, 'PUT', `${base}/vms/${vmId}`, { database_id: db.body.data.id });
    const inst = await call(ADMIN, 'POST', `${base}/db_instances`,
      { name: 'i-primary', vm_id: vmId, database_id: db.body.data.id, role: 'primary' });
    const groupId = '88880000-1111-4222-8333-444455556666';
    await q(`INSERT INTO \`${tbl('cap_custom_groups')}\` (id, scenario_id, name) VALUES (?,?,?)`,
      [groupId, SCENARIO_ID, 'grp']);
    await q(`INSERT INTO \`${tbl('cap_custom_group_members')}\` (id, scenario_id, group_id, member_instance_id) VALUES (UUID(),?,?,?)`,
      [SCENARIO_ID, groupId, inst.body.data.id]);

    const gone = await call(ADMIN, 'DELETE', `${base}/vms/${vmId}`);
    assert.equal(gone.status, 200, JSON.stringify(gone.body));
    assert.equal(await rowCount('cap_db_instances', 'WHERE id = ?', [inst.body.data.id]), 0);
    assert.equal(await rowCount('cap_custom_group_members', 'WHERE member_instance_id = ?', [inst.body.data.id]), 0,
      'the VM cascade left a dangling instance group membership');
    assert.equal(gone.body.data.cascaded['cap_custom_group_members.member_instance_id'], 1);
  });
});

// ── B2: an oversized auto-snapshot fails the delete with an actionable 400 ───

describe('a delete whose auto-snapshot exceeds the ceiling is a 400, not a 500', () => {
  test('the threshold-crossing cascade rolls back and answers PAYLOAD_TOO_LARGE', async (t) => {
    if (guard(t)) return;
    const specId = await seedSpec();
    const site = await call(ADMIN, 'POST', `${base}/sites`, { name: 'DC-A' });
    const hv = await call(ADMIN, 'POST', `${base}/hypervisors`,
      { name: 'host-a', site_id: site.body.data.id, spec_id: specId });
    const vm = await call(ADMIN, 'POST', `${base}/vms`, { name: 'dbhost', vm_type: 'db_host', hypervisor_id: hv.body.data.id });
    const db = await call(ADMIN, 'POST', `${base}/databases`, { function_name: 'ORDERS', topology: 'primary_standby' });
    const dbId = db.body.data.id;
    // Cross the auto-snapshot threshold (>= 10 cascaded rows) with rows whose
    // metadata inflates the frozen document past the 4 MB ceiling. Inserted
    // directly so the fixture is not bounded by the JSON request-body limit.
    const bigMeta = JSON.stringify({ blob: 'x'.repeat(512 * 1024) });
    for (let i = 0; i < 16; i += 1) {
      await q(
        `INSERT INTO \`${tbl('cap_db_instances')}\` (id, scenario_id, vm_id, database_id, name, role, metadata)`
        + ' VALUES (UUID(),?,?,?,?,?,?)',
        [SCENARIO_ID, vm.body.data.id, dbId, `inst-${i}`, i % 2 ? 'standby' : 'primary', bigMeta],
      );
    }

    const res = await call(ADMIN, 'DELETE', `${base}/databases/${dbId}`);
    assert.equal(res.status, 400, JSON.stringify(res.body).slice(0, 300));
    assert.equal(res.body.error.code, 'PAYLOAD_TOO_LARGE');
    assert.match(res.body.error.message, /snapshot/i);
    // The failed delete rolled back: the database and its instances are intact.
    assert.equal(await rowCount('cap_databases', 'WHERE id = ?', [dbId]), 1, 'the failed delete did not roll back');
    assert.equal(await rowCount('cap_db_instances', 'WHERE database_id = ?', [dbId]), 16);
  });
});

// ── Task 4: sequential deletes stay well-formed ─────────────────────────────

describe('two sequential site deletes stay well-formed', () => {
  test('the second reports zero moved rather than 500', async (t) => {
    if (guard(t)) return;
    const specId = await seedSpec();
    const site = await call(ADMIN, 'POST', `${base}/sites`, { name: 'DC-A' });
    const siteId = site.body.data.id;
    await call(ADMIN, 'POST', `${base}/hypervisors`, { name: 'host-a', site_id: siteId, spec_id: specId });

    const first = await call(ADMIN, 'DELETE', `${base}/sites/${siteId}`);
    assert.equal(first.status, 200, JSON.stringify(first.body));
    assert.equal(first.body.data.cascaded['cap_hypervisors.site_id'], 1);
    // The row is gone, so a repeat is a 404 (not a 500) — the delete re-reads the
    // row under a lock before doing anything.
    const second = await call(ADMIN, 'DELETE', `${base}/sites/${siteId}`);
    assert.equal(second.status, 404, JSON.stringify(second.body));
  });
});
