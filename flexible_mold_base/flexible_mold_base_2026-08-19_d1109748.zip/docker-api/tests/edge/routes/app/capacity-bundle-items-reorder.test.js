/**
 * capacity-bundle-items-reorder.test.js — the phase-6 (spec §D12) bulk
 * drag-reorder route for one GLOBAL bundle's items
 * (PUT /config/bundles/:bundleId/items/reorder). Same contract as the other
 * reorder routes: a bulk order_index rewrite in one transaction under the
 * global-config sentinel lock, gated admin+editor, rejecting a malformed /
 * partial / foreign id set. Registered BEFORE the generic PUT /items/:id so
 * "reorder" is never treated as an item id.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../../../src/edge/db');

let state;
function freshState() {
  return {
    queries: [],
    began: 0, committed: 0, rolledBack: 0, released: 0,
    bundleExists: true,
    currentItemIds: ['i1', 'i2', 'i3'],
  };
}

const conn = {
  async beginTransaction() { state.began += 1; },
  async commit() { state.committed += 1; },
  async rollback() { state.rolledBack += 1; },
  release() { state.released += 1; },
  async query(sql, params = []) {
    state.queries.push({ sql, params });
    if (/SELECT id FROM `fmb_cap_settings` FOR UPDATE/.test(sql)) return [{ id: 's1' }];
    if (/SELECT id FROM `fmb_cap_bundles` WHERE id = \? FOR UPDATE/.test(sql)) {
      return state.bundleExists ? [{ id: params[0] }] : [];
    }
    if (/SELECT id FROM `fmb_cap_bundle_items` WHERE bundle_id = \? FOR UPDATE/.test(sql)) {
      return state.currentItemIds.map((id) => ({ id }));
    }
    if (/^UPDATE `fmb_cap_bundle_items` SET order_index = \? WHERE id = \? AND bundle_id = \?/.test(sql)) {
      return { affectedRows: 1 };
    }
    return [];
  },
};

const poolFacade = {
  getConnection: async () => conn,
  query: (sql, params) => conn.query(sql, params),
};
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: { ro: poolFacade, rw: poolFacade }, t: (n) => `fmb_${n}` },
};

const router = require('../../../../src/edge/routes/app/capacity');

let currentUser; let server; let baseUrl;
before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { req.user = currentUser; next(); });
  app.use('/capacity', router);
  server = http.createServer(app);
  await new Promise((r) => server.listen(0, r));
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});
after(() => server && server.close());
beforeEach(() => {
  state = freshState();
  currentUser = { id: 'u-admin', role: 'admin' };
});

function request(method, path, body) {
  return new Promise((resolve, reject) => {
    const payload = body === undefined ? '' : JSON.stringify(body);
    const r = http.request(
      `${baseUrl}${path}`,
      { method, headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) } },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          const raw = Buffer.concat(chunks).toString('utf8');
          let json = null;
          try { json = JSON.parse(raw); } catch { /* noop */ }
          resolve({ status: res.statusCode, json, raw });
        });
      },
    );
    r.on('error', reject);
    if (payload) r.write(payload);
    r.end();
  });
}

const updates = () =>
  state.queries.filter((q) => /^UPDATE `fmb_cap_bundle_items`/.test(q.sql));
const PATH = '/capacity/config/bundles/b1/items/reorder';

describe('PUT /config/bundles/:bundleId/items/reorder', () => {
  it("rewrites order_index to each item's position in one transaction", async () => {
    const res = await request('PUT', PATH, { orderedIds: ['i3', 'i1', 'i2'] });
    assert.equal(res.status, 200, res.raw);
    assert.equal(res.json.data.reordered, 3);
    assert.equal(state.committed, 1);
    assert.equal(state.rolledBack, 0);
    const u = updates();
    assert.equal(u.length, 3);
    // params: [order_index, id, bundle_id]
    assert.deepEqual(u.map((q) => [q.params[1], q.params[0]]), [['i3', 0], ['i1', 1], ['i2', 2]]);
  });

  it('a plain user is refused 403, nothing rewritten', async () => {
    currentUser = { id: 'u-user', role: 'user' };
    const res = await request('PUT', PATH, { orderedIds: ['i1', 'i2', 'i3'] });
    assert.equal(res.status, 403, res.raw);
    assert.equal(updates().length, 0);
  });

  it('an editor may reorder a bundle\'s items', async () => {
    currentUser = { id: 'u-editor', role: 'editor' };
    const res = await request('PUT', PATH, { orderedIds: ['i2', 'i1', 'i3'] });
    assert.equal(res.status, 200, res.raw);
    assert.equal(updates().length, 3);
  });

  it('404s when the bundle does not exist, nothing rewritten', async () => {
    state.bundleExists = false;
    const res = await request('PUT', PATH, { orderedIds: ['i1', 'i2', 'i3'] });
    assert.equal(res.status, 404, res.raw);
    assert.equal(updates().length, 0);
  });

  it('rejects a missing/empty orderedIds (400)', async () => {
    const res = await request('PUT', PATH, {});
    assert.equal(res.status, 400, res.raw);
    assert.equal(updates().length, 0);
  });

  it('rejects a body with a duplicate id (400)', async () => {
    const res = await request('PUT', PATH, { orderedIds: ['i1', 'i1', 'i2'] });
    assert.equal(res.status, 400, res.raw);
    assert.equal(updates().length, 0);
  });

  it('rejects a PARTIAL id set (missing i3)', async () => {
    const res = await request('PUT', PATH, { orderedIds: ['i1', 'i2'] });
    assert.equal(res.status, 400, res.raw);
    assert.equal(updates().length, 0);
  });

  it('rejects a FOREIGN item id smuggled into the list', async () => {
    const res = await request('PUT', PATH, { orderedIds: ['i1', 'i2', 'foreign'] });
    assert.equal(res.status, 400, res.raw);
    assert.equal(updates().length, 0);
  });
});
