/**
 * user-template-metadata-write-guard.test.js — the write boundary for the three
 * field-key-indexed user_templates columns.
 *
 * Each column is TEXT (65,535 bytes) and every byte of it is assembled in the
 * browser. Without a guard the only limits are the 10 MB body cap and the column
 * itself, and crossing the column either truncates the document or raises 1406
 * depending on sql_mode — neither of which the operator is told about. These
 * tests run against a stubbed connection, so they assert the REFUSAL AND THE
 * ABSENCE OF A WRITE: a mocked INSERT reports success on a document that would
 * never have fitted.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../../../src/edge/db');
const {
  USER_TEMPLATE_METADATA_COLUMN_NAMES,
  MAX_USER_TEMPLATE_METADATA_BYTES,
} = require('../../../../src/edge/lib/user-template-metadata');

const DATABASE_PROBE = /^SELECT DATABASE\(\)/i;
const COLUMN_PROBE = /SELECT COLUMN_NAME FROM information_schema\.COLUMNS/i;
const SELECT_ROW = /^SELECT \* FROM `fmb_user_templates`/i;
const OWNER_NAMES = /FROM `fmb_users`/i;

const TEMPLATE_COLS = [
  'id', 'name', 'owner_id', 'blueprint_id', 'variant_id', 'payload', 'generated_outputs',
  'is_draft', 'created_at', 'updated_at', ...USER_TEMPLATE_METADATA_COLUMN_NAMES,
];

let conn;
// What the stored row hands back on the read after a write. Overridden by the
// read-boundary tests.
let storedRow;

function makeConn() {
  const queries = [];
  return {
    queries,
    async query(sql, params) {
      if (DATABASE_PROBE.test(sql)) return [{ db: 'db_default' }];
      if (COLUMN_PROBE.test(sql)) return TEMPLATE_COLS.map((c) => ({ COLUMN_NAME: c }));
      queries.push({ sql, params });
      if (OWNER_NAMES.test(sql)) return [];
      if (SELECT_ROW.test(sql)) return [{ id: '3cec1b55-8cd6-4dd2-8026-4cfa1fea1029', name: 'Job 1', ...storedRow }];
      // `storedRowId` — "what spelling does the row this reference names carry".
      // The id asked for is echoed back: this double has no column and therefore
      // no collation, so it cannot model a respelling and asserts nothing about
      // one. That half is measured against a real database in
      // tests/integration/owner-identity-real-db.test.js.
      {
        const m = sql.match(/^SELECT id FROM `([^`]+)` WHERE id = \?$/);
        if (m) return params[0] == null ? [] : [{ id: params[0] }];
      }
      if (/^(INSERT|UPDATE)/i.test(sql)) return { affectedRows: 1 };
      throw new Error(`Unmatched query: ${sql.slice(0, 160)}`);
    },
    release() { /* noop */ },
    async beginTransaction() {},
    async commit() {},
    async rollback() {},
  };
}

const poolSpy = {
  rw: { async getConnection() { return conn; } },
  ro: { async getConnection() { return conn; } },
};

require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: {
    pool: poolSpy,
    t: (name) => `fmb_${name}`,
    getDynamicPool: async () => poolSpy,
  },
};

const router = require('../../../../src/edge/routes/app/schema');
const { __clearColumnSetCache } = router.__test__;

let server;
let port;

before(async () => {
  const app = express();
  app.use(express.json({ limit: '10mb' }));
  app.use((req, _res, next) => { req.user = { id: '5b729f1e-5c0b-447c-8144-3210469bc62c', role: 'admin' }; next(); });
  app.use('/edge/app/schema', router);
  await new Promise((resolve) => {
    server = app.listen(0, '127.0.0.1', () => { port = server.address().port; resolve(); });
  });
});

after(async () => {
  await new Promise((resolve) => server.close(resolve));
  delete require.cache[dbKey];
});

beforeEach(() => {
  storedRow = {};
  conn = makeConn();
  __clearColumnSetCache();
});

function send(method, path_, body) {
  return new Promise((resolve, reject) => {
    const payload = body === undefined ? '' : JSON.stringify(body);
    const req = http.request(
      {
        host: '127.0.0.1', port, path: path_, method,
        headers: payload
          ? { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) }
          : {},
      },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          const raw = Buffer.concat(chunks).toString('utf-8');
          let json = null;
          try { json = JSON.parse(raw); } catch { /* noop */ }
          resolve({ status: res.statusCode, raw, json });
        });
      },
    );
    req.on('error', reject);
    req.write(payload);
    req.end();
  });
}

const create = (body) => send('POST', '/edge/app/schema/user_templates', body);
const update = (body) => send('PUT', '/edge/app/schema/user_templates/3cec1b55-8cd6-4dd2-8026-4cfa1fea1029', body);

const writes = () => conn.queries.filter((q) => /^(INSERT|UPDATE)/i.test(q.sql));

const GOOD_BODY = {
  id: '3cec1b55-8cd6-4dd2-8026-4cfa1fea1029',
  name: 'Job 1',
  blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26',
  payload: { size: 'L' },
  field_option_selection: { size: 'Large (L)' },
  computed_field_overrides: { part_no: true },
  cleared_auto_fills: { single_option: { finish: '[["a","A"]]' }, decision: { grade: 'sig-1' } },
};

function oversizedDoc() {
  const doc = {};
  // Comfortably past the cap, and past what the column could hold either way.
  for (let i = 0; i < 2000; i += 1) doc[`field_${i}`] = 'x'.repeat(64);
  assert.ok(Buffer.byteLength(JSON.stringify(doc), 'utf8') > MAX_USER_TEMPLATE_METADATA_BYTES);
  return doc;
}

describe('user_templates metadata write guard — accepts', () => {
  it('stores a well-formed trio, serialized, on create', async () => {
    const res = await create(GOOD_BODY);
    assert.equal(res.status, 200, res.raw);

    const insert = writes().find((q) => /^INSERT/i.test(q.sql));
    assert.ok(insert, 'expected an INSERT');
    const cols = insert.sql.match(/\(([^)]+)\) VALUES/)[1].split(', ');
    for (const column of USER_TEMPLATE_METADATA_COLUMN_NAMES) {
      const idx = cols.indexOf(`\`${column}\``);
      assert.notEqual(idx, -1, `${column} must reach the INSERT`);
      assert.equal(typeof insert.params[idx], 'string');
      assert.deepEqual(JSON.parse(insert.params[idx]), GOOD_BODY[column]);
    }
  });

  it('accepts explicit nulls, which is how the form clears a channel', async () => {
    const res = await update({
      field_option_selection: null,
      computed_field_overrides: null,
      cleared_auto_fills: null,
    });
    assert.equal(res.status, 200, res.raw);
    assert.ok(writes().some((q) => /^UPDATE/i.test(q.sql)), 'expected the clearing UPDATE');
  });

  it('accepts a partial update that mentions none of them', async () => {
    const res = await update({ name: 'Renamed' });
    assert.equal(res.status, 200, res.raw);
  });
});

describe('user_templates metadata read boundary', () => {
  it('hands back null for a document that was stored truncated', async () => {
    // A column truncated before the write guard existed: the DTO mapper cannot
    // parse it and leaves the raw text. Echoed to the client it would come
    // straight back on the next clone, which the write guard would then refuse.
    storedRow = {
      field_option_selection: '{"size":"Lar',
      computed_field_overrides: { part_no: true },
    };
    const res = await send('GET', '/edge/app/schema/user_templates/3cec1b55-8cd6-4dd2-8026-4cfa1fea1029');

    assert.equal(res.status, 200, res.raw);
    assert.equal(res.json.data.field_option_selection, null);
    assert.deepEqual(res.json.data.computed_field_overrides, { part_no: true });
  });

  it('drops the unreadable channel of the one channelled column', async () => {
    // The root of this document parses, so a boundary that only checks the root
    // hands the whole thing back — and the clone that echoes it is then refused.
    // The unreadable part sits one level down, which is where this column keeps
    // its field keys.
    storedRow = {
      cleared_auto_fills: { single_option: '{"finish":"[[', decision: { grade: 'sig-1' } },
    };
    const res = await send('GET', '/edge/app/schema/user_templates/3cec1b55-8cd6-4dd2-8026-4cfa1fea1029');

    assert.equal(res.status, 200, res.raw);
    assert.deepEqual(res.json.data.cleared_auto_fills, { decision: { grade: 'sig-1' } });
  });

  it('hands back what a clone can send straight back', async () => {
    // The round trip the boundary exists to close, at the HTTP surface: read a
    // record whose stored documents are damaged in every way the guard refuses,
    // then create a copy from exactly what was handed back.
    storedRow = {
      field_option_selection: { size: 3, finish: 'Matte' },
      computed_field_overrides: '{"part_no":tr',
      cleared_auto_fills: { single_option: { finish: 7 }, invented: { a: 'b' } },
    };
    const read = await send('GET', '/edge/app/schema/user_templates/3cec1b55-8cd6-4dd2-8026-4cfa1fea1029');
    assert.equal(read.status, 200, read.raw);

    const clone = await create({
      id: 'fd95c565-a1ed-4eca-899d-e99ca3920d2d',
      name: 'Copy',
      blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26',
      field_option_selection: read.json.data.field_option_selection,
      computed_field_overrides: read.json.data.computed_field_overrides,
      cleared_auto_fills: read.json.data.cleared_auto_fills,
    });
    assert.equal(clone.status, 200, clone.raw);
  });

  it('hands back a readable document unchanged', async () => {
    storedRow = { cleared_auto_fills: { decision: { grade: 'sig-1' } } };
    const res = await send('GET', '/edge/app/schema/user_templates/3cec1b55-8cd6-4dd2-8026-4cfa1fea1029');

    assert.equal(res.status, 200, res.raw);
    assert.deepEqual(res.json.data.cleared_auto_fills, { decision: { grade: 'sig-1' } });
  });
});

describe('user_templates metadata write guard — refuses', () => {
  for (const column of USER_TEMPLATE_METADATA_COLUMN_NAMES) {
    it(`a document over the cap in ${column}, on create, without writing`, async () => {
      const doc = column === 'cleared_auto_fills'
        ? { single_option: oversizedDoc() }
        : oversizedDoc();
      const res = await create({ ...GOOD_BODY, [column]: doc });

      assert.equal(res.status, 413, res.raw);
      assert.equal(res.json.error.code, 'TEMPLATE_METADATA_TOO_LARGE');
      assert.match(res.json.error.message, new RegExp(column));
      assert.deepEqual(writes(), [], 'nothing may be written when the document is refused');
    });

    it(`a document over the cap in ${column}, on update, without writing`, async () => {
      const doc = column === 'cleared_auto_fills'
        ? { decision: oversizedDoc() }
        : oversizedDoc();
      const res = await update({ [column]: doc });

      assert.equal(res.status, 413, res.raw);
      assert.deepEqual(writes(), [], 'nothing may be written when the document is refused');
    });
  }

  it('a value of the wrong shape, naming the column and the entry', async () => {
    const res = await create({ ...GOOD_BODY, field_option_selection: { size: { label: 'L' } } });
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'INVALID_TEMPLATE_METADATA');
    assert.match(res.json.error.message, /field_option_selection\.size/);
    assert.deepEqual(writes(), []);
  });

  it('an override marker that is not true', async () => {
    const res = await create({ ...GOOD_BODY, computed_field_overrides: { part_no: 'yes' } });
    assert.equal(res.status, 400, res.raw);
    assert.deepEqual(writes(), []);
  });

  it('a channel cleared_auto_fills does not declare', async () => {
    const res = await create({ ...GOOD_BODY, cleared_auto_fills: { invented: { a: 'b' } } });
    assert.equal(res.status, 400, res.raw);
    assert.match(res.json.error.message, /invented/);
    assert.deepEqual(writes(), []);
  });

  it('a pre-stringified document, which would reach the column unchecked', async () => {
    const res = await create({ ...GOOD_BODY, cleared_auto_fills: JSON.stringify({ decision: {} }) });
    assert.equal(res.status, 400, res.raw);
    assert.deepEqual(writes(), []);
  });

  it('an array in place of a document', async () => {
    const res = await update({ field_option_selection: [] });
    assert.equal(res.status, 400, res.raw);
    assert.deepEqual(writes(), []);
  });
});
