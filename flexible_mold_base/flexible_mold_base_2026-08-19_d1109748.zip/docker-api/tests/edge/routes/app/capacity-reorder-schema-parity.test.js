/**
 * capacity-reorder-schema-parity.test.js — pins the `order_index` column against
 * the ACTUAL table DDL for every table a phase-6 reorder endpoint rewrites
 * (spec §D3 / §D8 / §D12). The node:test route mocks stub query results, so a
 * reorder UPDATE against a table that has no order_index column stays green in
 * both runners yet 500s in production. This test closes that gap: it parses
 * docker-api/src/table-ddls and asserts every reorderable table declares
 * order_index.
 */
const { describe, it, before } = require('node:test');
const assert = require('node:assert/strict');

const dbKey = require.resolve('../../../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: {}, t: (n) => n },
};

const { buildEngineTableDDLs } = require('../../../../src/table-ddls');

const SQL_TYPES = /^`?([a-z_]+)`?\s+(?:CHAR|VARCHAR|INT|DOUBLE|TIMESTAMP|JSON|TEXT|ENUM|BOOLEAN|TINYINT|BIGINT|DATETIME|DECIMAL|FLOAT|BLOB)\b/i;
let columnsByTable;

before(() => {
  columnsByTable = new Map();
  for (const ddl of buildEngineTableDDLs((n) => n)) {
    const m = ddl.match(/CREATE TABLE IF NOT EXISTS `([^`]+)`/);
    if (!m) continue;
    const table = m[1];
    const cols = new Set();
    for (const rawLine of ddl.split('\n')) {
      const line = rawLine.trim();
      if (!line || line.startsWith('--') || line.startsWith('/*')) continue;
      const cm = line.match(SQL_TYPES);
      if (cm) cols.add(cm[1]);
    }
    columnsByTable.set(table, cols);
  }
});

// Every table a reorder endpoint (reorder.js / catalogue-reorder.js / bundles.js
// items/reorder) rewrites `order_index` on. If a table here loses the column, the
// UPDATE 500s at runtime.
const REORDERABLE_TABLES = [
  // scenario-scoped (reorder.js) — phase-4 + phase-6 D8
  'cap_sites', 'cap_hypervisors', 'cap_vms', 'cap_db_instances', 'cap_hardware_specs',
  'cap_databases',
  // global catalogue (catalogue-reorder.js) — phase-6 D3
  'cap_disk_combos', 'cap_teams', 'cap_vm_profiles',
  // bundle items (bundles.js items/reorder) — phase-6 D12
  'cap_bundle_items',
  // bundles rail (bundles.js /reorder) — phase-6 D3 (1.5b)
  'cap_bundles',
];

describe('capacity reorder schema parity', () => {
  it('every reorderable table declares an order_index column', () => {
    for (const table of REORDERABLE_TABLES) {
      const cols = columnsByTable.get(table);
      assert.ok(cols && cols.size > 0, `no columns parsed for ${table}`);
      assert.ok(cols.has('order_index'), `${table} is missing order_index (a reorder UPDATE would 500)`);
    }
  });

  // T3 canonical lock order: reorder.js scans `... ORDER BY id FOR UPDATE`, so
  // every reorderable table must declare the `id` column the scan orders by (it
  // is the CHAR(36) PRIMARY KEY on all cap_* tables — losing it would 500 the
  // ordered scan and break the deadlock-order invariant).
  it('every reorderable table declares the id column the lock-order scan sorts by', () => {
    for (const table of REORDERABLE_TABLES) {
      const cols = columnsByTable.get(table);
      assert.ok(cols && cols.has('id'), `${table} is missing id (the ORDER BY id lock-order column)`);
    }
  });
});
