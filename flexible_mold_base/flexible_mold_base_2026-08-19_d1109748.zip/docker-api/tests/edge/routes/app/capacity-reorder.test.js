/**
 * capacity-reorder.test.js — the phase-4 (spec §6) bulk drag-reorder routes for
 * the four new Local editable tables: Hypervisors / KVMs / DB Instances (child
 * entities) + the scenario-LOCAL Hardware Specs catalogue. Same contract as the
 * Sites reorder (capacity-sites-reorder.test.js): a bulk order_index rewrite in
 * one transaction, gated to the scenario owner/admin, rejecting a malformed /
 * partial / foreign id set. For hardware_specs a GLOBAL (read-only) row id is
 * structurally not in the scenario's local set, so it is rejected the same way a
 * foreign id is.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

// ── Mock edge/db BEFORE requiring the router ──────────────────────────────────
const dbKey = require.resolve('../../../../src/edge/db');

let state;
function freshState() {
  return {
    queries: [],
    began: 0, committed: 0, rolledBack: 0, released: 0,
    scenarioOwner: null, // owner_id read by resolveScenarioWriteAccess (null = shared)
    scenarioExists: true,
    // The scenario's current row-id set for whichever entity is under test (the
    // FOR UPDATE lock read). Order here is irrelevant (pre-reorder set).
    currentRowIds: ['r1', 'r2', 'r3'],
  };
}

const conn = {
  async beginTransaction() { state.began += 1; },
  async commit() { state.committed += 1; },
  async rollback() { state.rolledBack += 1; },
  release() { state.released += 1; },
  async query(sql, params = []) {
    state.queries.push({ sql, params });

    if (/SELECT id, owner_id FROM `fmb_cap_scenarios` WHERE id = \? FOR UPDATE/.test(sql)) {
      return state.scenarioExists ? [{ id: params[0], owner_id: state.scenarioOwner }] : [];
    }
    // The entity's current row set (FOR UPDATE lock) — table-agnostic match.
    // The scan MUST carry `ORDER BY id` (the T3 canonical lock-order fix): the
    // regex pins that so a regression back to an unordered scan misses this
    // branch, empties the set and fails the suite rather than passing silently.
    if (/SELECT id FROM `fmb_\w+` WHERE scenario_id = \? ORDER BY id FOR UPDATE/.test(sql)) {
      return state.currentRowIds.map((id) => ({ id }));
    }
    if (/^UPDATE `fmb_\w+` SET order_index = \? WHERE id = \? AND scenario_id = \?/.test(sql)) {
      return { affectedRows: 1 };
    }
    return [];
  },
};

const poolFacade = {
  getConnection: async () => conn,
  query: (sql, params) => conn.query(sql, params),
};
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: { ro: poolFacade, rw: poolFacade }, t: (n) => `fmb_${n}` },
};

const router = require('../../../../src/edge/routes/app/capacity');

let currentUser; let server; let baseUrl;
before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { req.user = currentUser; next(); });
  app.use('/capacity', router);
  server = http.createServer(app);
  await new Promise((r) => server.listen(0, r));
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});
after(() => server && server.close());
beforeEach(() => {
  state = freshState();
  currentUser = { id: 'u-admin', role: 'admin' };
});

function request(method, path, body) {
  return new Promise((resolve, reject) => {
    const payload = body === undefined ? '' : JSON.stringify(body);
    const r = http.request(
      `${baseUrl}${path}`,
      { method, headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) } },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          const raw = Buffer.concat(chunks).toString('utf8');
          let json = null;
          try { json = JSON.parse(raw); } catch { /* noop */ }
          resolve({ status: res.statusCode, json, raw });
        });
      },
    );
    r.on('error', reject);
    if (payload) r.write(payload);
    r.end();
  });
}

const updatesOf = (table) =>
  state.queries.filter((q) => new RegExp(`^UPDATE \`fmb_${table}\``).test(q.sql));

// The four phase-4 reorderable entities. `table` is the fmb_-prefixed logical
// name the UPDATE targets; `global` flags the catalogue whose read-only global
// rows must be reorder-rejected.
const ENTITIES = [
  { name: 'hypervisors', path: '/capacity/scenarios/scn-1/hypervisors/reorder', table: 'cap_hypervisors', max: 500 },
  { name: 'vms', path: '/capacity/scenarios/scn-1/vms/reorder', table: 'cap_vms', max: 2000 },
  { name: 'db_instances', path: '/capacity/scenarios/scn-1/db_instances/reorder', table: 'cap_db_instances', max: 4000 },
  // phase-6 spec §D8: the Databases tab reorder shares the identical contract.
  { name: 'databases', path: '/capacity/scenarios/scn-1/databases/reorder', table: 'cap_databases', max: 2000 },
  {
    name: 'local-catalogues/hardware_specs',
    path: '/capacity/scenarios/scn-1/local-catalogues/hardware_specs/reorder',
    table: 'cap_hardware_specs',
    max: 2000,
    global: true,
  },
];

for (const ent of ENTITIES) {
  describe(`PUT ${ent.path}`, () => {
    it('rewrites order_index to each id\'s position in one transaction', async () => {
      const res = await request('PUT', ent.path, { orderedIds: ['r3', 'r1', 'r2'] });
      assert.equal(res.status, 200, res.raw);
      assert.equal(res.json.data.reordered, 3);
      assert.equal(state.began, 1);
      assert.equal(state.committed, 1);
      assert.equal(state.rolledBack, 0);

      const updates = updatesOf(ent.table);
      assert.equal(updates.length, 3);
      // params: [order_index, id, scenario_id]
      assert.deepEqual(updates.map((q) => [q.params[1], q.params[0]]), [
        ['r3', 0], ['r1', 1], ['r2', 2],
      ]);
    });

    it('locks the scenario row set in canonical ascending-id order (deadlock-order invariant)', async () => {
      // fmb-1352 item 20: reorder.js and placement-apply.js both write these
      // cap_* rows. The scan MUST acquire its FOR UPDATE row locks in ascending
      // primary-key order (matching placement-apply's compareMove per-move
      // tiebreak) so the two writers can never invert row-lock order. Assert the
      // ORDER BY id sits on the FOR UPDATE scan directly off the query log
      // (mechanical, no live DB).
      const res = await request('PUT', ent.path, { orderedIds: ['r3', 'r1', 'r2'] });
      assert.equal(res.status, 200, res.raw);
      const scan = state.queries.find((q) => new RegExp(
        `^SELECT id FROM \`fmb_${ent.table}\` WHERE scenario_id = \\? ORDER BY id FOR UPDATE$`,
      ).test(q.sql));
      assert.ok(
        scan,
        `expected an ORDER BY id FOR UPDATE scan for ${ent.table}, got: ${state.queries.map((q) => q.sql).join(' | ')}`,
      );
    });

    it('a plain user (not editor/admin) is refused 403, nothing rewritten', async () => {
      currentUser = { id: 'u-user', role: 'user' };
      const res = await request('PUT', ent.path, { orderedIds: ['r1', 'r2', 'r3'] });
      assert.equal(res.status, 403, res.raw);
      assert.equal(updatesOf(ent.table).length, 0);
    });

    it('an editor who does not own a private scenario is refused 403', async () => {
      currentUser = { id: 'u-other-editor', role: 'editor' };
      state.scenarioOwner = 'u-owner';
      const res = await request('PUT', ent.path, { orderedIds: ['r1', 'r2', 'r3'] });
      assert.equal(res.status, 403, res.raw);
      assert.equal(updatesOf(ent.table).length, 0);
    });

    it('the owning editor may reorder their own scenario', async () => {
      currentUser = { id: 'u-owner', role: 'editor' };
      state.scenarioOwner = 'u-owner';
      const res = await request('PUT', ent.path, { orderedIds: ['r2', 'r1', 'r3'] });
      assert.equal(res.status, 200, res.raw);
      assert.equal(updatesOf(ent.table).length, 3);
    });

    it('404s when the scenario does not exist, nothing rewritten', async () => {
      state.scenarioExists = false;
      const res = await request('PUT', ent.path.replace('scn-1', 'nope'), { orderedIds: ['r1', 'r2', 'r3'] });
      assert.equal(res.status, 404, res.raw);
      assert.equal(updatesOf(ent.table).length, 0);
    });

    it('rejects a missing/empty orderedIds (400)', async () => {
      const res = await request('PUT', ent.path, {});
      assert.equal(res.status, 400, res.raw);
      assert.equal(updatesOf(ent.table).length, 0);
    });

    it('rejects a body with a duplicate id (400)', async () => {
      const res = await request('PUT', ent.path, { orderedIds: ['r1', 'r1', 'r2'] });
      assert.equal(res.status, 400, res.raw);
      assert.equal(updatesOf(ent.table).length, 0);
    });

    it('rejects a PARTIAL id set (missing r3) — never a silent subset reorder', async () => {
      const res = await request('PUT', ent.path, { orderedIds: ['r1', 'r2'] });
      assert.equal(res.status, 400, res.raw);
      assert.equal(updatesOf(ent.table).length, 0);
    });

    it('rejects a FOREIGN id smuggled into the list (not this scenario\'s row)', async () => {
      const res = await request('PUT', ent.path, { orderedIds: ['r1', 'r2', 'foreign'] });
      assert.equal(res.status, 400, res.raw);
      assert.equal(updatesOf(ent.table).length, 0);
    });

    it(`rejects an oversized orderedIds array (400, > ${ent.max} bound)`, async () => {
      // One past the entity's per-entity bound (which mirrors wizard.js's
      // supported maximum — a legal full-size set must NOT hit this).
      const orderedIds = Array.from({ length: ent.max + 1 }, (_, i) => `r${i}`);
      const res = await request('PUT', ent.path, { orderedIds });
      assert.equal(res.status, 400, res.raw);
      assert.equal(updatesOf(ent.table).length, 0);
    });

    if (ent.global) {
      it('rejects a GLOBAL (read-only) row id — global rows are not in the scenario\'s local set', async () => {
        // The endpoint's FOR UPDATE read is scoped WHERE scenario_id = ?, so a
        // global row (scenario_id NULL) is never in `currentRowIds`; its id in
        // the body fails the exact-match check exactly like a foreign id.
        const res = await request('PUT', ent.path, { orderedIds: ['r1', 'r2', 'global-spec'] });
        assert.equal(res.status, 400, res.raw);
        assert.equal(updatesOf(ent.table).length, 0);
      });
    }
  });
}
