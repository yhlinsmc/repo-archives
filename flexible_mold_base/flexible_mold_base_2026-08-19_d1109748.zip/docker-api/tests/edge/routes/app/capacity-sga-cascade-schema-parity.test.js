/**
 * capacity-sga-cascade-schema-parity.test.js — validates every column the
 * phase-7 item-6 SGA cascade SQL (cascadeDbSgaToInstances, children.js)
 * references against the ACTUAL table DDL, WITHOUT a live DB.
 *
 * The cascade's node:test uses a mock connection, so a wrong column name (e.g.
 * SELECT `primary_sga` instead of `primary_sga_gb`) would stay green in both
 * runners yet 500 in production and silently break the SGA-Ref cascade. This
 * test closes that gap: it parses docker-api/src/table-ddls and asserts every
 * referenced column exists on its table (CLAUDE.md §6 new-SQL rule).
 */
const { describe, it, before } = require('node:test');
const assert = require('node:assert/strict');

const { buildEngineTableDDLs } = require('../../../../src/table-ddls');

// The exact columns the cascade queries touch, table → columns. Kept in step by
// hand with cascadeDbSgaToInstances; a rename there without a matching edit here
// (or a typo there) trips this test.
const CASCADE_SQL_COLUMNS = {
  cap_databases: ['id', 'primary_sga_gb', 'standby_sga_gb', 'profile_id', 'scenario_id'],
  cap_db_instances: ['role', 'database_id', 'sga_gb'],
  cap_settings: ['scenario_id'],
  cap_vm_profiles: ['id'],
};

const SQL_TYPES = /^`?([a-z_]+)`?\s+(?:CHAR|VARCHAR|INT|DOUBLE|TIMESTAMP|JSON|TEXT|ENUM|BOOLEAN|TINYINT|BIGINT|DATETIME|DECIMAL|FLOAT|BLOB)\b/i;
let columnsByTable;

before(() => {
  columnsByTable = new Map();
  for (const ddl of buildEngineTableDDLs((n) => n)) {
    const m = ddl.match(/CREATE TABLE IF NOT EXISTS `([^`]+)`/);
    if (!m) continue;
    const table = m[1];
    const cols = new Set();
    for (const rawLine of ddl.split('\n')) {
      const line = rawLine.trim();
      if (!line || line.startsWith('--') || line.startsWith('/*')) continue;
      const cm = line.match(SQL_TYPES);
      if (cm) cols.add(cm[1]);
    }
    columnsByTable.set(table, cols);
  }
});

describe('SGA-cascade schema parity', () => {
  it('every column the cascade SQL references exists on its table', () => {
    for (const [table, cols] of Object.entries(CASCADE_SQL_COLUMNS)) {
      const actual = columnsByTable.get(table);
      assert.ok(actual && actual.size > 0, `no columns parsed for ${table}`);
      for (const col of cols) {
        assert.ok(actual.has(col), `${table} has no column '${col}' (cascade SQL would 500)`);
      }
    }
  });

  it('sga_gb is a DOUBLE the cascade can write a derived number into', () => {
    const ddl = buildEngineTableDDLs((n) => n).find((d) => d.includes('CREATE TABLE IF NOT EXISTS `cap_db_instances`'));
    assert.ok(ddl, 'cap_db_instances DDL not found');
    assert.match(ddl, /sga_gb\s+DOUBLE\b/i, 'sga_gb must be a DOUBLE column');
  });

  it('role is the ENUM(primary,standby) the per-role targeting relies on', () => {
    const ddl = buildEngineTableDDLs((n) => n).find((d) => d.includes('CREATE TABLE IF NOT EXISTS `cap_db_instances`'));
    assert.match(ddl, /role\s+ENUM\('primary','standby'\)/i, 'role enum shape changed');
  });
});
