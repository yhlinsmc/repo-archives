/**
 * list-default-shape-regression.test.js — the regression guard for PR 5.
 *
 * PR 5 adds OFFSET + a total count to the shared CRUD list handler. The
 * capability is opt-in and the whole justification for putting it in the shared
 * layer rather than writing a Flow-only query is that no other surface moves.
 * "No other surface moves" is a requirement, so it is pinned here rather than
 * reasoned about.
 *
 * WHY the SQL string is pinned verbatim rather than pattern-matched: a default
 * page size, a re-ordered ORDER BY, an always-on COUNT companion query or a
 * `LIMIT ? OFFSET ?` that degrades to `OFFSET 0` are all changes that a loose
 * `/LIMIT/` assertion would wave through.
 *
 * SCOPE, stated plainly because an overstated one is how a gap gets missed:
 * what this file pins is WHICH rows a request asks for and in WHAT SHAPE they
 * come back — the exact SQL text, the exact bind parameters, the number of
 * statements issued, and the envelope's key set. It pins nothing about what a
 * row CONTAINS. Deleting the owner-name enrichment, or bypassing the read
 * serializer that masks stored secrets, leaves every assertion here green.
 * Row content is covered in list-surface-sweep.test.js, which gives each
 * surface a real row and reads it; that is the file to extend for a content
 * property, not this one.
 *
 * This file was written before the implementation and passed against the
 * pre-change code; it must keep passing afterwards unchanged.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../../../src/edge/db');

let queries;
let rowsByTable;

function makeConn() {
  return {
    async query(sql, params = []) {
      queries.push({ sql, params });
      if (/^SELECT DATABASE\(\)/i.test(sql)) return [{ db: 'testdb' }];
      if (/information_schema\.COLUMNS/i.test(sql)) return [];
      if (/FROM `fmb_users`/.test(sql)) return [];
      const m = sql.match(/FROM `fmb_([a-z_]+)`/);
      if (m) return (rowsByTable[m[1]] || []).map((r) => ({ ...r }));
      return [];
    },
    release() {},
    async beginTransaction() {},
    async commit() {},
    async rollback() {},
  };
}

const poolFacade = {
  async getConnection() { return makeConn(); },
  query: async (sql, params) => makeConn().query(sql, params),
};

require.cache[dbKey] = {
  id: dbKey,
  filename: dbKey,
  loaded: true,
  exports: {
    pool: { ro: poolFacade, rw: poolFacade },
    t: (n) => `fmb_${n}`,
    getDynamicPool: async () => ({ ro: poolFacade, rw: poolFacade }),
  },
};

const schemaRouter = require('../../../../src/edge/routes/app/schema');
const runsRouter = require('../../../../src/edge/routes/app/flow-recipe-runs');

let currentUser;
let server;
let baseUrl;

before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { req.user = currentUser; next(); });
  app.use('/edge/app/schema', schemaRouter);
  app.use('/edge/app/flow-recipe-runs', runsRouter);
  server = http.createServer(app);
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});

after(() => server && server.close());

beforeEach(() => {
  queries = [];
  currentUser = { id: 'u-editor', role: 'editor', email: 'editor@example.test' };
  rowsByTable = {
    blueprint_sections: [
      { id: 's-1', blueprint_id: 'bp-1', section_key: 'alpha', sort_order: 1, matrix_copy: null, created_at: '2026-01-01 00:00:00', updated_at: '2026-01-01 00:00:00' },
      { id: 's-2', blueprint_id: 'bp-1', section_key: 'beta', sort_order: 2, matrix_copy: null, created_at: '2026-01-02 00:00:00', updated_at: '2026-01-02 00:00:00' },
      { id: 's-3', blueprint_id: 'bp-2', section_key: 'gamma', sort_order: 3, matrix_copy: null, created_at: '2026-01-03 00:00:00', updated_at: '2026-01-03 00:00:00' },
    ],
    flow_recipe_runs: [
      { id: 'run-1', recipe_id: 'rec-1', actor_id: 'u-editor', status: 'success', created_at: '2026-01-01 00:00:00', updated_at: '2026-01-01 00:00:00' },
    ],
  };
});

function get(path) {
  return new Promise((resolve, reject) => {
    const r = http.request(`${baseUrl}${path}`, { method: 'GET' }, (res) => {
      const chunks = [];
      res.on('data', (c) => chunks.push(c));
      res.on('end', () => {
        let json = null;
        try { json = JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch { /* noop */ }
        resolve({ status: res.statusCode, json });
      });
    });
    r.on('error', reject);
    r.end();
  });
}

/** Every statement issued against the named physical table. */
const statementsAgainst = (table) =>
  queries.filter((q) => q.sql.includes(`\`fmb_${table}\``));

describe('list default shape — the request with no new parameters', () => {
  it('issues one statement, and it is byte-for-byte the pre-pagination SQL', async () => {
    const res = await get('/edge/app/schema/blueprint_sections');
    assert.equal(res.status, 200);

    const stmts = statementsAgainst('blueprint_sections');
    assert.equal(stmts.length, 1, `expected exactly one statement, saw:\n${stmts.map((s) => s.sql).join('\n')}`);
    assert.equal(
      stmts[0].sql,
      'SELECT * FROM `fmb_blueprint_sections` ORDER BY `created_at` IS NULL, `created_at` ASC',
    );
    assert.deepEqual(stmts[0].params, []);
  });

  it('returns the rows as a bare array in the envelope, in the order the database gave them', async () => {
    const res = await get('/edge/app/schema/blueprint_sections');

    assert.deepEqual(Object.keys(res.json).sort(), ['data', 'error', 'meta']);
    assert.equal(res.json.error, null);
    assert.ok(Array.isArray(res.json.data), 'data must stay a bare array, not a page object');
    assert.deepEqual(res.json.data.map((r) => r.id), ['s-1', 's-2', 's-3']);
    assert.equal(res.json.data.length, 3, 'an unpaginated read is still unlimited');
  });

  it('runs no COUNT companion query when nothing asked for a total', async () => {
    await get('/edge/app/schema/blueprint_sections');
    const counts = queries.filter((q) => /COUNT\(/i.test(q.sql));
    assert.deepEqual(counts, [], 'a total was computed for a caller that did not ask for one');
  });

  it('keeps a declared filter exactly as it was: one WHERE, one bind, no bound page', async () => {
    const res = await get('/edge/app/schema/blueprint_sections?blueprint_id=bp-1');
    assert.equal(res.status, 200);

    const stmts = statementsAgainst('blueprint_sections');
    assert.equal(stmts.length, 1);
    assert.equal(
      stmts[0].sql,
      'SELECT * FROM `fmb_blueprint_sections` WHERE `blueprint_id` = ? ORDER BY `created_at` IS NULL, `created_at` ASC',
    );
    assert.deepEqual(stmts[0].params, ['bp-1']);
    assert.ok(Array.isArray(res.json.data));
  });

  it('keeps the existing ?limit= behaviour: LIMIT only, no OFFSET, still a bare array', async () => {
    // `limit` predates this work and several surfaces send it. Adding OFFSET
    // support must not turn a limit-only request into a paged one.
    const res = await get('/edge/app/schema/blueprint_sections?limit=2');
    assert.equal(res.status, 200);

    const stmts = statementsAgainst('blueprint_sections');
    assert.equal(stmts.length, 1, 'a limit-only read must not gain a COUNT companion');
    assert.equal(
      stmts[0].sql,
      'SELECT * FROM `fmb_blueprint_sections` ORDER BY `created_at` IS NULL, `created_at` ASC LIMIT ?',
    );
    assert.deepEqual(stmts[0].params, [2]);
    assert.ok(Array.isArray(res.json.data), 'a limit-only read must stay a bare array');
  });

  it('keeps sort and order exactly as they were', async () => {
    await get('/edge/app/schema/blueprint_sections?sort=sort_order&order=desc');
    const stmts = statementsAgainst('blueprint_sections');
    assert.equal(
      stmts[0].sql,
      'SELECT * FROM `fmb_blueprint_sections` ORDER BY `sort_order` IS NULL, `sort_order` DESC',
    );
  });

  it('reads the run history unscoped and unbounded, for a non-administrator too', async () => {
    // This mount used to be the file's example of a per-user read scope. The
    // scope is gone deliberately — every authenticated caller reads every run —
    // so what is regression-checked here is that removing it changed the
    // predicate and NOTHING else about the default statement: same columns,
    // same order, still no page bound, still a bare array.
    const res = await get('/edge/app/flow-recipe-runs');
    assert.equal(res.status, 200);

    const stmts = statementsAgainst('flow_recipe_runs');
    assert.equal(stmts.length, 1);
    assert.equal(
      stmts[0].sql,
      'SELECT * FROM `fmb_flow_recipe_runs` ORDER BY `created_at` IS NULL, `created_at` ASC',
    );
    assert.deepEqual(stmts[0].params, []);
    assert.ok(Array.isArray(res.json.data));
  });

  it('an admin on the same mount still reads unscoped and unbounded', async () => {
    currentUser = { id: 'u-admin', role: 'admin', email: 'admin@example.test' };
    await get('/edge/app/flow-recipe-runs');

    const stmts = statementsAgainst('flow_recipe_runs');
    assert.equal(stmts.length, 1);
    assert.equal(
      stmts[0].sql,
      'SELECT * FROM `fmb_flow_recipe_runs` ORDER BY `created_at` IS NULL, `created_at` ASC',
    );
    assert.deepEqual(stmts[0].params, []);
  });
});
