/**
 * delegated-grants-schema-parity.test.js — every column name the delegation and
 * activity code paths reference, checked against the ACTUAL DDL, without a live
 * database.
 *
 * WHY THIS FILE EXISTS SEPARATELY FROM THE BEHAVIOUR TESTS. Those stub the
 * connection, so a query naming a column that does not exist stays green in both
 * runners and only fails against a real database — which has shipped here
 * before. The column names below are read out of the modules that build the SQL
 * rather than retyped, so a rename in one of them fails here instead of in
 * production.
 *
 * It also checks the migration side: the executor resolves a `create-table` step
 * by searching the DDL list for the physical table name and throws at boot when
 * it finds nothing, so a registry entry for a table nobody added to
 * table-ddls.js would otherwise surface only on a real migration run.
 */
const { describe, it, before } = require('node:test');
const assert = require('node:assert/strict');

const { buildEngineTableDDLs, buildAllTableDDLs, ENGINE_TABLE_NAMES } = require('../../../../src/table-ddls');
const { TABLES } = require('../../../../src/shared/constants');
const { getRegistry } = require('../../../../src/edge/lib/dto-mapper');
const { MIGRATION_STEPS } = require('../../../../src/edge/migration-steps');

const SQL_TYPES = /^`?([a-z_]+)`?\s+(?:CHAR|VARCHAR|INT|DOUBLE|TIMESTAMP|JSON|TEXT|ENUM|BOOLEAN|TINYINT|BIGINT|DATETIME|DECIMAL|FLOAT|BLOB)\b/i;

let columnsByTable;
let ddlByTable;

before(() => {
  columnsByTable = new Map();
  ddlByTable = new Map();
  for (const ddl of buildEngineTableDDLs((n) => n)) {
    const m = ddl.match(/CREATE TABLE IF NOT EXISTS `([^`]+)`/);
    if (!m) continue;
    ddlByTable.set(m[1], ddl);
    const cols = new Set();
    for (const rawLine of ddl.split('\n')) {
      const line = rawLine.trim();
      if (!line || line.startsWith('--') || line.startsWith('/*')) continue;
      const cm = line.match(SQL_TYPES);
      if (cm) cols.add(cm[1]);
    }
    columnsByTable.set(m[1], cols);
  }
});

describe('delegated_grants — DDL shape', () => {
  it('is registered as an engine table', () => {
    assert.ok(ENGINE_TABLE_NAMES.includes(TABLES.DELEGATED_GRANTS));
  });

  it('declares exactly the documented column set', () => {
    const cols = columnsByTable.get(TABLES.DELEGATED_GRANTS);
    assert.ok(cols, 'no DDL parsed for delegated_grants');
    assert.deepEqual(
      [...cols].sort(),
      ['created_at', 'granted_by', 'grantee_id', 'id', 'scope_id', 'scope_type'],
    );
  });

  it('carries no level column — there is one grant, not a ladder', () => {
    assert.ok(!columnsByTable.get(TABLES.DELEGATED_GRANTS).has('level'));
  });

  it('constrains scope_type to the two subjects a grant can name', () => {
    assert.match(
      ddlByTable.get(TABLES.DELEGATED_GRANTS),
      /scope_type\s+ENUM\('blueprint','template'\) NOT NULL/,
    );
  });

  it('makes a repeated grant one row', () => {
    assert.match(
      ddlByTable.get(TABLES.DELEGATED_GRANTS),
      /UNIQUE KEY uq_delegated_grant \(scope_type, scope_id, grantee_id\)/,
    );
  });

  it('indexes the question the write gate asks — grantee first', () => {
    assert.match(
      ddlByTable.get(TABLES.DELEGATED_GRANTS),
      /INDEX idx_delegated_grants_grantee \(grantee_id, scope_type, scope_id\)/,
    );
  });

  it('carries no FOREIGN KEY (engine tables are FK-by-convention)', () => {
    assert.doesNotMatch(ddlByTable.get(TABLES.DELEGATED_GRANTS), /FOREIGN KEY/i);
  });
});

describe('template_activity — DDL shape', () => {
  it('is registered as an engine table', () => {
    assert.ok(ENGINE_TABLE_NAMES.includes(TABLES.TEMPLATE_ACTIVITY));
  });

  it('declares exactly the documented column set', () => {
    const cols = columnsByTable.get(TABLES.TEMPLATE_ACTIVITY);
    assert.ok(cols, 'no DDL parsed for template_activity');
    assert.deepEqual(
      [...cols].sort(),
      ['action', 'actor_id', 'created_at', 'id', 'metadata', 'template_id'],
    );
  });

  it('indexes the template and the order the list reads in, together', () => {
    assert.match(
      ddlByTable.get(TABLES.TEMPLATE_ACTIVITY),
      /INDEX idx_template_activity_template_time \(template_id, created_at\)/,
    );
  });

  it('leaves actor_id nullable — an account can be removed after it acted', () => {
    assert.match(ddlByTable.get(TABLES.TEMPLATE_ACTIVITY), /actor_id\s+CHAR\(36\)\s+NULL/);
  });

  it('carries no FOREIGN KEY (engine tables are FK-by-convention)', () => {
    assert.doesNotMatch(ddlByTable.get(TABLES.TEMPLATE_ACTIVITY), /FOREIGN KEY/i);
  });
});

describe('the DTO registry names only columns that exist', () => {
  for (const table of ['DELEGATED_GRANTS', 'TEMPLATE_ACTIVITY']) {
    it(`${TABLES[table]} — every registered column is declared`, () => {
      const cols = columnsByTable.get(TABLES[table]);
      const def = getRegistry()[TABLES[table]];
      assert.ok(def, `${TABLES[table]} is missing from the DTO registry`);
      for (const group of ['booleans', 'timestamps', 'json', 'nullableStrings']) {
        for (const col of def[group] || []) {
          assert.ok(cols.has(col), `dto-mapper names ${col}, which the DDL does not declare`);
        }
      }
    });
  }
});

describe('migration registry — the two new tables', () => {
  it('every create-table step resolves to exactly one CREATE statement', () => {
    const ddls = buildAllTableDDLs((n) => n);
    for (const step of MIGRATION_STEPS.filter((s) => s.kind === 'create-table')) {
      const matches = ddls.filter((s) => s.includes(`\`${step.table}\``));
      assert.ok(
        matches.length >= 1,
        `${step.step}: no DDL defines ${step.table} — the executor throws at boot`,
      );
      assert.match(matches[0], new RegExp(`CREATE TABLE IF NOT EXISTS \`${step.table}\``));
    }
  });

  for (const table of ['DELEGATED_GRANTS', 'TEMPLATE_ACTIVITY']) {
    it(`${TABLES[table]} is a create-table step that degrades rather than fails`, () => {
      const step = MIGRATION_STEPS.find((s) => s.table === TABLES[table]);
      assert.ok(step, `${TABLES[table]} has no migration-steps entry`);
      assert.equal(step.kind, 'create-table');
      // A database whose operator account cannot run the CREATE keeps working:
      // no grants and no trail, which is exactly the behaviour it has today.
      assert.equal(step.severity, 'warning');
    });
  }
});
