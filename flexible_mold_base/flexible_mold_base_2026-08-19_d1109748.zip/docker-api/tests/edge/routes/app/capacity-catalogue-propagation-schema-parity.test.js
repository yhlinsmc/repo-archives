/**
 * capacity-catalogue-propagation-schema-parity.test.js — validates every column
 * catalogue-propagation.js's SQL references against the ACTUAL table DDL,
 * WITHOUT a live DB (template: capacity-delete-preview-schema-parity.test.js).
 * The node:test mocks in the sibling endpoint test stub query results by regex,
 * so a wrong column name stays green there yet 500s in production. This test
 * closes that gap by lifting each statement's literal text straight out of the
 * SOURCE (never a hand-copied restatement of it) and checking the columns it
 * actually names — both directions: the SQL must name a column the DDL has,
 * and the expected column must be the one the SQL, as written, actually names.
 */
const { describe, it, before } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const dbKey = require.resolve('../../../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: {}, t: (n) => n },
};

const { buildEngineTableDDLs } = require('../../../../src/table-ddls');
const { TABLES } = require('../../../../src/shared/constants');

const SQL_TYPES = /^`?([a-z_]+)`?\s+(?:CHAR|VARCHAR|INT|DOUBLE|TIMESTAMP|JSON|TEXT|ENUM|BOOLEAN|TINYINT|BIGINT|DATETIME|DECIMAL|FLOAT|BLOB)\b/i;
let columnsByTable;

before(() => {
  columnsByTable = new Map();
  for (const ddl of buildEngineTableDDLs((n) => n)) {
    const m = ddl.match(/CREATE TABLE IF NOT EXISTS `([^`]+)`/);
    if (!m) continue;
    const table = m[1];
    const cols = new Set();
    for (const rawLine of ddl.split('\n')) {
      const line = rawLine.trim();
      if (!line || line.startsWith('--') || line.startsWith('/*')) continue;
      const cm = line.match(SQL_TYPES);
      if (cm) cols.add(cm[1]);
    }
    columnsByTable.set(table, cols);
  }
});

const SRC = fs.readFileSync(
  path.resolve(__dirname, '../../../../src/edge/routes/app/capacity/catalogue-propagation.js'), 'utf8',
);

/** One statement's text, lifted from the module's own source (delete-preview
 *  parity test's own convention) — read out of what actually runs, not a
 *  hand-copied restatement that could quietly drift from it. `anchor` is any
 *  UNIQUE preceding text; the statement is the FIRST backtick-delimited
 *  literal found after it. */
function liftStatement(anchor) {
  const start = SRC.indexOf(anchor);
  assert.notEqual(start, -1, `catalogue-propagation.js no longer contains: ${anchor}`);
  const open = SRC.indexOf('`', start);
  let close = open + 1;
  while (close < SRC.length
    && !(SRC[close] === '`' && SRC[close - 1] !== '\\')) close += 1;
  return SRC.slice(open + 1, close);
}

const TABLE_CONSTANTS = Object.fromEntries(
  Object.entries(TABLES).map(([name, value]) => [`TABLES.${name}`, String(value)]),
);

/** alias → logical table, taken from a statement's own FROM/JOIN clauses. */
function aliasesOf(statement) {
  const map = new Map();
  for (const m of statement.matchAll(/(?:FROM|JOIN)\s+\\`\$\{t\(([A-Z_.]+)\)\}\\`\s+(\w+)/g)) {
    const table = TABLE_CONSTANTS[m[1]];
    assert.ok(table, `the statement reads ${m[1]}, which is not a TABLES constant`);
    map.set(m[2], table);
  }
  return map;
}

/** Every aliased `alias.column` reference in `statement` exists on the table
 *  that alias names. `minRefs` guards the parse itself. */
function assertColumnParity(statement, aliasTable, minRefs) {
  const refs = [...statement.matchAll(/\b(\w+)\.(\w+)\b/g)]
    .filter(([, alias]) => aliasTable.has(alias))
    .map(([, alias, column]) => ({ table: aliasTable.get(alias), column }));
  assert.ok(refs.length >= minRefs, `only ${refs.length} column references found — the parse has stopped working`);
  for (const { table, column } of refs) {
    assert.ok(
      columnsByTable.get(table).has(column),
      `${table} has no column '${column}' — the propagation preview/apply would 500 while the mocked test stayed green`,
    );
  }
}

/** For a lifted single-table (unaliased) statement, assert BOTH directions for
 *  every expected column: (1) it appears verbatim in the statement AS WRITTEN
 *  (word-boundary — catches a rename/typo on the SQL side, e.g. `mem_gb` →
 *  `mem_gbx`, which a hand-restated expectation list would never see), and
 *  (2) the DDL actually declares it (catches a column dropped/renamed on the
 *  table side). Either direction alone misses the other's failure mode. */
function assertBareColumnsMatchStatement(statement, table, columns) {
  const cols = columnsByTable.get(table);
  assert.ok(cols, `unknown table ${table}`);
  for (const column of columns) {
    assert.match(statement, new RegExp(`\\b${column}\\b`), `statement no longer names column '${column}'`);
    assert.ok(cols.has(column), `${table} has no column '${column}'`);
  }
}

describe('preview: VM×profile join (previewVmProfileDrift)', () => {
  const statement = liftStatement('async function previewVmProfileDrift');
  const aliasTable = aliasesOf(statement);

  it('reads cap_vms and cap_vm_profiles under an alias', () => {
    assert.deepEqual([...aliasTable.values()].sort(), ['cap_vm_profiles', 'cap_vms']);
  });

  it('every aliased column exists on the table it names it on', () => {
    assertColumnParity(statement, aliasTable, 6);
  });
});

describe('preview: VM×disk-combo join (previewDiskComboDrift)', () => {
  const statement = liftStatement('async function previewDiskComboDrift');
  const aliasTable = aliasesOf(statement);

  it('reads cap_vms and cap_disk_combos under an alias', () => {
    assert.deepEqual([...aliasTable.values()].sort(), ['cap_disk_combos', 'cap_vms']);
  });

  it('every aliased column exists on the table it names it on', () => {
    assertColumnParity(statement, aliasTable, 5);
  });
});

describe('apply: locked VM read + UPDATE — cap_vms', () => {
  // Lock order (P2, review round 3): each apply function now runs an UNLOCKED
  // candidate probe (learn the referenced catalogue ids) BEFORE the catalogue
  // row lock, then the LOCKED vmRows read AFTER it — see the why-comment on
  // each function's FOR UPDATE. The two vmRows reads share identical anchor
  // text (`const vmRows = await conn.query(`) across both functions, so the
  // anchors below include the preceding profileById/comboById assignment line
  // to land on the correct one (liftStatement finds the FIRST match in the
  // whole file).
  it('vm_profiles apply\'s unlocked candidate probe reads the real cap_vms columns', () => {
    const statement = liftStatement('async function applyVmProfileDriftForScenario');
    assertBareColumnsMatchStatement(statement, TABLES.CAP_VMS, ['scenario_id', 'sizing_profile_id']);
  });

  it('vm_profiles apply\'s locked read reads the real cap_vms columns it re-derives from', () => {
    const statement = liftStatement(
      'const profileById = new Map(profileRows.map((r) => [String(r.id), r]));\n  const vmRows = await conn.query(',
    );
    assertBareColumnsMatchStatement(
      statement, TABLES.CAP_VMS,
      ['id', 'scenario_id', 'name', 'cpu', 'mem_gb', 'sizing_profile_id'],
    );
  });

  it('vm_profiles apply\'s locked cap_vms read is FOR UPDATE-locked, AFTER the catalogue lock', () => {
    const statement = liftStatement(
      'const profileById = new Map(profileRows.map((r) => [String(r.id), r]));\n  const vmRows = await conn.query(',
    );
    assert.match(statement, /FOR UPDATE\s*$/);
  });

  it('vm_profiles apply writes cpu and mem_gb by their real column names', () => {
    // The UPDATE's SET clause is built dynamically (`${sets.join(', ')}`), so
    // the column names that actually land in it live in these push() literals,
    // not in the template string itself.
    assert.match(SRC, /sets\.push\('cpu = \?'\)/);
    assert.match(SRC, /sets\.push\('mem_gb = \?'\)/);
    assert.ok(columnsByTable.get(TABLES.CAP_VMS).has('cpu'));
    assert.ok(columnsByTable.get(TABLES.CAP_VMS).has('mem_gb'));
  });

  it('disk_combos apply\'s unlocked candidate probe reads the real cap_vms columns', () => {
    const statement = liftStatement('async function applyDiskComboDriftForScenario');
    assertBareColumnsMatchStatement(statement, TABLES.CAP_VMS, ['scenario_id', 'disk_combo_id']);
  });

  it('disk_combos apply\'s locked read reads the real cap_vms columns it re-derives from', () => {
    const statement = liftStatement(
      'const comboById = new Map(comboRows.map((r) => [String(r.id), r]));\n  const vmRows = await conn.query(',
    );
    assertBareColumnsMatchStatement(
      statement, TABLES.CAP_VMS,
      ['id', 'scenario_id', 'name', 'disk_gb', 'disk_combo_id'],
    );
  });

  it('disk_combos apply\'s locked cap_vms read is FOR UPDATE-locked, AFTER the catalogue lock', () => {
    const statement = liftStatement(
      'const comboById = new Map(comboRows.map((r) => [String(r.id), r]));\n  const vmRows = await conn.query(',
    );
    assert.match(statement, /FOR UPDATE\s*$/);
  });

  it('disk_combos apply writes disk_gb by its real column name', () => {
    const statement = liftStatement('for (const d of drift) {\n    await conn.query(');
    assertBareColumnsMatchStatement(statement, TABLES.CAP_VMS, ['disk_gb', 'id', 'scenario_id']);
  });
});

describe('catalogue row lookups', () => {
  it('cap_vm_profiles (preview): every column the sizing derivation reads is real', () => {
    const statement = liftStatement('const profileRows = await dbHandle.query(');
    assertBareColumnsMatchStatement(
      statement, TABLES.CAP_VM_PROFILES,
      ['id', 'name', 'class', 'mode', 'cpu', 'mem_gb', 'sga_cap_gb'],
    );
  });

  it('cap_vm_profiles (apply): every column the sizing derivation reads is real', () => {
    const statement = liftStatement('const profileRows = await conn.query(');
    assertBareColumnsMatchStatement(
      statement, TABLES.CAP_VM_PROFILES,
      ['id', 'name', 'class', 'mode', 'cpu', 'mem_gb', 'sga_cap_gb'],
    );
  });

  // X2 (review round 2): apply must lock the referenced catalogue row so a
  // concurrent global PUT cannot commit a newer row between this read and the
  // scenario transaction's own commit — see the FOR UPDATE why-comment in
  // applyVmProfileDriftForScenario.
  it('cap_vm_profiles (apply): the catalogue read is FOR UPDATE-locked', () => {
    const statement = liftStatement('const profileRows = await conn.query(');
    assert.match(statement, /FOR UPDATE\s*$/);
  });

  it('cap_disk_combos (preview): every column the sum-sizes derivation reads is real', () => {
    const statement = liftStatement('const comboRows = await dbHandle.query(');
    assertBareColumnsMatchStatement(statement, TABLES.CAP_DISK_COMBOS, ['id', 'name', 'sizes']);
  });

  it('cap_disk_combos (apply): every column the sum-sizes derivation reads is real', () => {
    const statement = liftStatement('const comboRows = await conn.query(');
    assertBareColumnsMatchStatement(statement, TABLES.CAP_DISK_COMBOS, ['id', 'name', 'sizes']);
  });

  it('cap_disk_combos (apply): the catalogue read is FOR UPDATE-locked (X2)', () => {
    const statement = liftStatement('const comboRows = await conn.query(');
    assert.match(statement, /FOR UPDATE\s*$/);
  });

  it('cap_scenarios: the name-lookup column is real', () => {
    const statement = liftStatement('async function loadScenarioNames');
    assertBareColumnsMatchStatement(statement, TABLES.CAP_SCENARIOS, ['id', 'name']);
  });

  it('cap_settings (preview, loadFormulaByScenario): scenario_id exists (the rest is SELECT *)', () => {
    const statement = liftStatement('async function loadFormulaByScenario');
    assertBareColumnsMatchStatement(statement, TABLES.CAP_SETTINGS, ['scenario_id']);
  });

  it('cap_settings (apply, single scenario): scenario_id exists (the rest is SELECT *)', () => {
    const statement = liftStatement('const settingsRows = await conn.query(');
    assertBareColumnsMatchStatement(statement, TABLES.CAP_SETTINGS, ['scenario_id']);
  });

  it('readFormulaConstants (shared, _shared.js) reads the real formula columns off a SELECT * row', () => {
    // catalogue-propagation.js SELECTs `*` on cap_settings and hands the row to
    // _shared.js's own `readFormulaConstants` — its own schema-parity coverage
    // lives with the rest of _shared.js's exports (capacity-sga-cascade /
    // capacity-settings-diff schema-parity tests), so this only pins that the
    // FOUR named columns those readers depend on still exist on the table this
    // module queries.
    for (const column of ['mem_cpu_ratio', 'sga_factor', 'sga_divisor', 'sga_subtract']) {
      assert.ok(columnsByTable.get(TABLES.CAP_SETTINGS).has(column), `cap_settings has no column '${column}'`);
    }
  });
});
