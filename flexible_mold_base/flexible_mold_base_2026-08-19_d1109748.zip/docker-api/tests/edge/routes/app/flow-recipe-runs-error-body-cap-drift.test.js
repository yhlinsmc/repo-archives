/**
 * flow-recipe-runs-error-body-cap-drift.test.js — fmb-1741 PR-2 review F6.
 *
 * STEP_ERROR_BODY_TRANSPORT_MAX is duplicated in three places rather than
 * imported (backend code is never imported into the FE bundle; the two
 * backend producers are separate CJS modules with no shared constants file
 * for this feature): `src/fmb/lib/flow/types.ts` (FE, both producers import
 * it from there) and `docker-api/src/infra/routes/flow-recipe-run.js` (the
 * one-shot server orchestrator — `run-chain.ts`, the browser orchestrator,
 * imports the FE twin directly, so it needs no separate pin here). A value
 * changed on one twin without the other is a silent behavioural drift, not a
 * build error — this test reads both source files as TEXT and asserts the
 * literals are equal, so a drift fails CI instead of aging into a PR-2-style
 * repeat.
 *
 * The placeholder STRINGS are deliberately NOT twinned/pinned here — F6's own
 * text: "prefer deriving placeholders server-side so FE/infra only twin the
 * transport max; minimize what is twinned". Each producer's placeholder is
 * generated locally and is never matched against by the edge masker (which
 * treats it as ordinary text, structured-or-not, on its own terms).
 */
const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

function readSource(relPath) {
  return fs.readFileSync(path.resolve(__dirname, relPath), 'utf8');
}

function extractConst(src, name, label) {
  const re = new RegExp(`\\b${name}\\s*=\\s*(\\d+)\\s*;`);
  const m = src.match(re);
  assert.ok(m, `could not find \`${name}\` in ${label} — the twin pin has nothing to compare`);
  return Number(m[1]);
}

test('(F6) STEP_ERROR_BODY_TRANSPORT_MAX is identical across the FE type module and the infra producer', () => {
  const feSrc = readSource('../../../../../src/fmb/lib/flow/types.ts');
  const infraSrc = readSource('../../../../src/infra/routes/flow-recipe-run.js');

  const feValue = extractConst(feSrc, 'STEP_ERROR_BODY_TRANSPORT_MAX', 'types.ts');
  const infraValue = extractConst(infraSrc, 'STEP_ERROR_BODY_TRANSPORT_MAX', 'flow-recipe-run.js');

  assert.strictEqual(feValue, infraValue,
    `STEP_ERROR_BODY_TRANSPORT_MAX drifted: types.ts=${feValue}, flow-recipe-run.js=${infraValue}`);
});

test('(F6) run-chain.ts imports the shared constant rather than declaring its own twin', () => {
  // If run-chain.ts ever stops importing from types.ts and declares its own
  // literal instead, that is a THIRD twin this test does not see — fail loudly
  // rather than silently letting a future drift point open uncovered.
  const chainSrc = readSource('../../../../../src/fmb/lib/flow/run-chain.ts');
  assert.match(chainSrc, /import\s*\{\s*STEP_ERROR_BODY_TRANSPORT_MAX\s*\}\s*from\s*'\.\/types'/,
    'run-chain.ts must import STEP_ERROR_BODY_TRANSPORT_MAX from types.ts, not declare its own literal');
  assert.doesNotMatch(chainSrc, /const\s+STEP_ERROR_BODY_TRANSPORT_MAX\s*=\s*\d+/,
    'run-chain.ts must not declare its own STEP_ERROR_BODY_TRANSPORT_MAX literal — that would be an unpinned third twin');
});

test('(F6) the edge storage cap (STEP_ERROR_BODY_MAX) is NOT twinned to the transport cap — they are different constants', () => {
  // Guards against a future "simplification" that collapses the two into one
  // shared literal, which would silently reintroduce F1 (storage-cap-sized
  // truncation reaching the masker before it runs).
  const serializerSrc = readSource('../../../../src/edge/routes/app/flow-recipe-runs/serializer.js');
  const storageCap = extractConst(serializerSrc, 'STEP_ERROR_BODY_MAX', 'serializer.js');
  assert.strictEqual(storageCap, 8192);
  const infraSrc = readSource('../../../../src/infra/routes/flow-recipe-run.js');
  const transportCap = extractConst(infraSrc, 'STEP_ERROR_BODY_TRANSPORT_MAX', 'flow-recipe-run.js');
  assert.strictEqual(transportCap, 32768);
  assert.notStrictEqual(storageCap, transportCap, 'the storage cap and the transport cap must stay distinct constants');
});
