/**
 * capacity-sites-reorder.test.js — PUT /scenarios/:id/sites/reorder (phase-2
 * spec §4.3 B2): bulk order_index rewrite, in one transaction, gated to the
 * scenario owner/admin, rejecting a malformed / partial / foreign id set.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

// ── Mock edge/db BEFORE requiring the router ──────────────────────────────────
const dbKey = require.resolve('../../../../src/edge/db');

let state;
function freshState() {
  return {
    queries: [],
    began: 0, committed: 0, rolledBack: 0, released: 0,
    scenarioOwner: null, // owner_id read by resolveScenarioWriteAccess (null = shared, any editor may write)
    scenarioExists: true,
    // The scenario's current site id set (FOR UPDATE lock read) — an array of
    // plain ids. Order here is irrelevant (it's the pre-reorder set).
    currentSiteIds: ['s1', 's2', 's3'],
  };
}

const conn = {
  async beginTransaction() { state.began += 1; },
  async commit() { state.committed += 1; },
  async rollback() { state.rolledBack += 1; },
  release() { state.released += 1; },
  async query(sql, params = []) {
    state.queries.push({ sql, params });

    // resolveScenarioWriteAccess: SELECT owner_id FROM cap_scenarios WHERE id = ? FOR UPDATE
    if (/SELECT id, owner_id FROM `fmb_cap_scenarios` WHERE id = \? FOR UPDATE/.test(sql)) {
      return state.scenarioExists ? [{ id: params[0], owner_id: state.scenarioOwner }] : [];
    }

    // The scenario's current site id set (FOR UPDATE lock).
    if (/SELECT id FROM `fmb_cap_sites` WHERE scenario_id = \? FOR UPDATE/.test(sql)) {
      return state.currentSiteIds.map((id) => ({ id }));
    }

    if (/^UPDATE `fmb_cap_sites` SET order_index = \? WHERE id = \? AND scenario_id = \?/.test(sql)) {
      return { affectedRows: 1 };
    }

    return [];
  },
};

const poolFacade = {
  getConnection: async () => conn,
  query: (sql, params) => conn.query(sql, params),
};
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: { ro: poolFacade, rw: poolFacade }, t: (n) => `fmb_${n}` },
};

const router = require('../../../../src/edge/routes/app/capacity');

let currentUser; let server; let baseUrl;
before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { req.user = currentUser; next(); });
  app.use('/capacity', router);
  server = http.createServer(app);
  await new Promise((r) => server.listen(0, r));
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});
after(() => server && server.close());
beforeEach(() => {
  state = freshState();
  currentUser = { id: 'u-admin', role: 'admin' };
});

function request(method, path, body) {
  return new Promise((resolve, reject) => {
    const payload = body === undefined ? '' : JSON.stringify(body);
    const r = http.request(
      `${baseUrl}${path}`,
      { method, headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) } },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          const raw = Buffer.concat(chunks).toString('utf8');
          let json = null;
          try { json = JSON.parse(raw); } catch { /* noop */ }
          resolve({ status: res.statusCode, json, raw });
        });
      },
    );
    r.on('error', reject);
    if (payload) r.write(payload);
    r.end();
  });
}

const updatesOf = (table) =>
  state.queries.filter((q) => new RegExp(`^UPDATE \`fmb_${table}\``).test(q.sql));

describe('PUT /capacity/scenarios/:id/sites/reorder', () => {
  it('rewrites order_index to each id\'s position in one transaction', async () => {
    const res = await request('PUT', '/capacity/scenarios/scn-1/sites/reorder', {
      orderedIds: ['s3', 's1', 's2'],
    });
    assert.equal(res.status, 200, res.raw);
    assert.equal(res.json.data.reordered, 3);
    assert.equal(state.began, 1);
    assert.equal(state.committed, 1);
    assert.equal(state.rolledBack, 0);

    const updates = updatesOf('cap_sites');
    assert.equal(updates.length, 3);
    // params: [order_index, id, scenario_id]
    assert.deepEqual(updates.map((q) => [q.params[1], q.params[0]]), [
      ['s3', 0], ['s1', 1], ['s2', 2],
    ]);
  });

  it('a plain user (not editor/admin) is refused 403, nothing rewritten', async () => {
    currentUser = { id: 'u-user', role: 'user' };
    const res = await request('PUT', '/capacity/scenarios/scn-1/sites/reorder', {
      orderedIds: ['s1', 's2', 's3'],
    });
    assert.equal(res.status, 403, res.raw);
    assert.equal(updatesOf('cap_sites').length, 0);
  });

  it('an editor who does not own a private scenario is refused 403', async () => {
    currentUser = { id: 'u-other-editor', role: 'editor' };
    state.scenarioOwner = 'u-owner';
    const res = await request('PUT', '/capacity/scenarios/scn-1/sites/reorder', {
      orderedIds: ['s1', 's2', 's3'],
    });
    assert.equal(res.status, 403, res.raw);
    assert.equal(updatesOf('cap_sites').length, 0);
  });

  it('the owning editor may reorder their own scenario', async () => {
    currentUser = { id: 'u-owner', role: 'editor' };
    state.scenarioOwner = 'u-owner';
    const res = await request('PUT', '/capacity/scenarios/scn-1/sites/reorder', {
      orderedIds: ['s2', 's1', 's3'],
    });
    assert.equal(res.status, 200, res.raw);
    assert.equal(updatesOf('cap_sites').length, 3);
  });

  it('404s when the scenario does not exist, nothing rewritten', async () => {
    state.scenarioExists = false;
    const res = await request('PUT', '/capacity/scenarios/nope/sites/reorder', {
      orderedIds: ['s1', 's2', 's3'],
    });
    assert.equal(res.status, 404, res.raw);
    assert.equal(updatesOf('cap_sites').length, 0);
  });

  it('rejects a missing/empty orderedIds (400)', async () => {
    const res = await request('PUT', '/capacity/scenarios/scn-1/sites/reorder', {});
    assert.equal(res.status, 400, res.raw);
    assert.equal(updatesOf('cap_sites').length, 0);
  });

  it('rejects a body with a duplicate id (400)', async () => {
    const res = await request('PUT', '/capacity/scenarios/scn-1/sites/reorder', {
      orderedIds: ['s1', 's1', 's2'],
    });
    assert.equal(res.status, 400, res.raw);
    assert.equal(updatesOf('cap_sites').length, 0);
  });

  it('rejects a PARTIAL id set (missing s3) — never a silent subset reorder', async () => {
    const res = await request('PUT', '/capacity/scenarios/scn-1/sites/reorder', {
      orderedIds: ['s1', 's2'],
    });
    assert.equal(res.status, 400, res.raw);
    assert.equal(updatesOf('cap_sites').length, 0);
  });

  it('rejects a FOREIGN id smuggled into the list (not this scenario\'s site)', async () => {
    const res = await request('PUT', '/capacity/scenarios/scn-1/sites/reorder', {
      orderedIds: ['s1', 's2', 'foreign-site'],
    });
    assert.equal(res.status, 400, res.raw);
    assert.equal(updatesOf('cap_sites').length, 0);
  });

  it('rejects an oversized orderedIds array (400, defense-in-depth bound)', async () => {
    const orderedIds = Array.from({ length: 201 }, (_, i) => `s${i}`);
    const res = await request('PUT', '/capacity/scenarios/scn-1/sites/reorder', { orderedIds });
    assert.equal(res.status, 400, res.raw);
    assert.equal(updatesOf('cap_sites').length, 0);
  });
});
