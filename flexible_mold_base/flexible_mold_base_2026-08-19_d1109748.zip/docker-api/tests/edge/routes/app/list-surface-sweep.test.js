/**
 * list-surface-sweep.test.js — T5.3. Every list surface the shared CRUD factory
 * serves, exercised with no new parameters and confirmed unchanged.
 *
 * The pagination work went into the shared layer rather than into a
 * purpose-built Flow query, so "nothing else moved" has to be demonstrated
 * across every consumer, not argued from the fact that they share code. Each
 * surface below is checked for the three things the contract names: the number
 * of rows it asks for (none — no LIMIT, no OFFSET), the order it asks for, and
 * the scoping predicate it carries.
 *
 * The sweep is driven from the mount registries (CHILD_MOUNTS,
 * LOCAL_CATALOGUE_MOUNTS) rather than from a copied list, and completeness is
 * asserted TWICE, because the two available techniques fail in opposite
 * directions and neither is sufficient alone:
 *
 *   - Recording every call the real factory receives is blind to HOW the table
 *     argument is spelled, which is what matters most: this project's own
 *     identifier rule steers new code towards `createCrudRoutes(TABLES.X, …)`,
 *     a form no source-text pattern reliably reads. But it only sees modules
 *     this file loads.
 *   - Walking the source tree sees every module whether or not this file loads
 *     one, which is the case the recorder cannot reach: a mount in its own
 *     router file, registered on the real app, is exactly the shape every
 *     standalone surface in this PR already has.
 *
 * So the recorder answers "is every mount we can see swept?" and the walk
 * answers "can we see every mount?". Deleting either one re-opens a hole that
 * a live, registered surface has already been demonstrated to fit through.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const express = require('express');

const dbKey = require.resolve('../../../../src/edge/db');

const OWNER = 'u-editor';
const SECRET = 'super-secret-value';

let queries;

/**
 * One row per surface. Every surface returns a row, because a sweep whose mock
 * answers `[]` everywhere never inspects a row and therefore cannot see a
 * change to what a row CONTAINS — the review found that deleting the owner-name
 * enrichment, and bypassing the read serializer that masks stored secrets, both
 * left this file green.
 *
 * A row for a surface that declares `serializeRead` must be one the serializer
 * ACTUALLY CHANGES, or the coverage is nominal: a serializer that never fires
 * on the fixture is indistinguishable from one that has been neutered. The
 * assertion below enforces that, so a mount added later with an untriggering
 * fixture fails rather than passing quietly.
 */
function rowFor(table) {
  const base = {
    id: `${table}-row-1`,
    created_at: '2026-01-01 00:00:00',
    updated_at: '2026-01-01 00:00:00',
    owner_id: OWNER,
    scenario_id: 'scn-1',
  };
  if (table === 'api_connectors') {
    return {
      ...base,
      blueprint_id: 'bp-1',
      name: 'Ticket API',
      method: 'POST',
      url: 'https://example.test/api',
      auth_type: 'bearer',
      auth_config: JSON.stringify({ token: SECRET }),
      is_active: 1,
      status: 'approved',
      scenario_id: undefined,
    };
  }
  if (table === 'flow_recipes') {
    return {
      ...base,
      blueprint_id: 'bp-1',
      name: 'Nightly push',
      is_active: 1,
      status: 'approved',
      approved_by: 'u-admin',
      approved_at: '2026-01-01 00:00:00',
      payload_transform_code: 'return input;',
      code_version: 1,
      scenario_id: undefined,
    };
  }
  if (table === 'flow_recipe_steps') {
    return {
      ...base,
      recipe_id: 'rec-1',
      name: 'Create ticket',
      method: 'POST',
      url: 'https://example.test/api',
      auth_type: 'bearer',
      // The sensitive leaf this mount's serializer masks on read.
      auth_config: JSON.stringify({ token: SECRET }),
      sequence: 1,
      scenario_id: undefined,
    };
  }
  if (table === 'user_templates') {
    return {
      ...base,
      blueprint_id: 'bp-1',
      name: 'Saved template',
      is_draft: 0,
      // A marker document the normalizer prunes: the only value this column
      // ever legitimately holds is `true`, so this entry is dropped on read.
      computed_field_overrides: JSON.stringify({ ghost_field: 'not-the-marker' }),
      scenario_id: undefined,
    };
  }
  if (table === 'decision_tables') {
    return {
      ...base,
      blueprint_id: 'bp-1',
      name: 'Sizing table',
      // Unparseable, so the DTO mapper hands it through as a string and the
      // normalizer substitutes a well-formed empty document.
      doc: '{ truncated',
      scenario_id: undefined,
    };
  }
  if (table === 'flow_recipe_runs') {
    return {
      ...base,
      actor_id: OWNER,
      recipe_id: 'rec-1',
      status: 'success',
      // The generic mount's serializeRead drops this column entirely — the
      // dedicated hardened `GET runs/:runId` route is the only byte-exact
      // read port meant to carry it.
      step_results: JSON.stringify([{ step_id: 's1', status: 'ok' }]),
      scenario_id: undefined,
    };
  }
  return base;
}

function makeConn() {
  return {
    async query(sql, params = []) {
      queries.push({ sql, params });
      if (/^SELECT DATABASE\(\)/i.test(sql)) return [{ db: 'testdb' }];
      if (/information_schema\.COLUMNS/i.test(sql)) return [];
      if (/^SELECT 1 AS ok/i.test(sql)) return [{ ok: 1 }];
      // C11 T6 widened makeScenarioExistsGuard to the child/local-catalogue
      // LIST GET (previously POST-only), so every scenario-scoped surface
      // below now probes this before its own SELECT — SCENARIO must answer
      // as a real row or the whole sweep 404s before reaching the fixture.
      if (/^SELECT id FROM `fmb_cap_scenarios` WHERE id = \?/i.test(sql)) return [{ id: SCENARIO }];
      if (/^SELECT COUNT\(/i.test(sql)) return [{ cnt: 0 }];
      // The owner-name enrichment's bounded lookup.
      if (/FROM `fmb_users`/.test(sql)) return [{ id: OWNER, display_name: 'Edith Editor', kc_username: 'edith' }];
      const m = sql.match(/^SELECT \* FROM `fmb_([a-z_0-9]+)`/);
      if (m) return [rowFor(m[1])];
      return [];
    },
    release() {},
    async beginTransaction() {},
    async commit() {},
    async rollback() {},
  };
}

const poolFacade = {
  async getConnection() { return makeConn(); },
  query: async (sql, params) => makeConn().query(sql, params),
};

require.cache[dbKey] = {
  id: dbKey,
  filename: dbKey,
  loaded: true,
  exports: {
    pool: { ro: poolFacade, rw: poolFacade },
    t: (n) => `fmb_${n}`,
    getDynamicPool: async () => ({ ro: poolFacade, rw: poolFacade }),
  },
};

// Record every mount the factory actually receives, by wrapping the real
// function rather than reading the source text for it. The previous version of
// this check grepped for `createCrudRoutes('table_name'`, which the codebase's
// own identifier-via-TABLES rule pushes new code away from — a live
// `createCrudRoutes(TABLES.X, …)` mount joined the application and never joined
// the sweep, with the suite fully green. A router cannot hide from this.
const factoryKey = require.resolve('../../../../src/edge/routes/app/schema/crud-factory');
const realFactory = require(factoryKey);
const RECORDED_MOUNTS = [];
require.cache[factoryKey].exports = {
  ...realFactory,
  createCrudRoutes(logicalName, opts = {}) {
    RECORDED_MOUNTS.push({ logicalName: String(logicalName), opts });
    return realFactory.createCrudRoutes(logicalName, opts);
  },
};

const { mapRowsFromDb } = require('../../../../src/edge/lib/dto-mapper');
const schemaRouter = require('../../../../src/edge/routes/app/schema');
const connectorsRouter = require('../../../../src/edge/routes/app/api-connectors');
const recipesRouter = require('../../../../src/edge/routes/app/flow-recipes');
const stepsRouter = require('../../../../src/edge/routes/app/flow-recipe-steps');
const runsRouter = require('../../../../src/edge/routes/app/flow-recipe-runs');
const capacityRouter = require('../../../../src/edge/routes/app/capacity');
const { CHILD_MOUNTS, LOCAL_CATALOGUE_MOUNTS } = require('../../../../src/edge/routes/app/capacity/_shared');

const SCENARIO = 'scn-1';

/**
 * `GET /scenarios/:id/rules` is registered by catalogue-reads.js AHEAD of the
 * child mount, so the rules LIST is a bespoke global-or-same-scenario read and
 * never reaches the factory. Its factory mount serves writes only. Recorded
 * here rather than dropped from the sweep, and asserted below, because "this
 * surface is unaffected" is a claim that has to be checked like any other.
 */
const BESPOKE_LIST_SEGMENTS = new Set(['rules']);

/**
 * Every list surface the factory serves.
 *   path   — the GET the frontend issues
 *   table  — the logical table behind it
 *   where  — the predicate the surface must still carry for a non-admin caller
 *            ('' when the surface is deliberately unscoped on read)
 */
const SURFACES = [
  // Schema mounts (docker-api/src/edge/routes/app/schema/index.js)
  { path: '/edge/app/schema/hierarchy_nodes', table: 'hierarchy_nodes', where: '' },
  { path: '/edge/app/schema/blueprint_fields', table: 'blueprint_fields', where: '' },
  { path: '/edge/app/schema/field_options', table: 'field_options', where: '' },
  { path: '/edge/app/schema/variant_overrides', table: 'variant_overrides', where: '' },
  { path: '/edge/app/schema/blueprint_sections', table: 'blueprint_sections', where: '' },
  { path: '/edge/app/schema/blueprint_groups', table: 'blueprint_groups', where: '' },
  { path: '/edge/app/schema/blueprint_output_order', table: 'blueprint_output_order', where: '' },
  { path: '/edge/app/schema/decision_tables', table: 'decision_tables', where: '' },
  { path: '/edge/app/schema/user_templates', table: 'user_templates', where: '' },
  // Standalone mounts, each with its own router file
  { path: '/edge/app/api-connectors', table: 'api_connectors', where: '' },
  { path: '/edge/app/flow-recipes', table: 'flow_recipes', where: '' },
  // The steps list refuses an unparented read, so its "no new parameters"
  // request is the one the frontend actually issues.
  { path: '/edge/app/flow-recipe-steps?recipe_id=rec-1', table: 'flow_recipe_steps', where: ' WHERE `recipe_id` = ?' },
  // No scope: the run history is readable by every authenticated caller, so
  // this surface's list is unqualified for every role alike.
  { path: '/edge/app/flow-recipe-runs', table: 'flow_recipe_runs', where: '' },
  { path: '/edge/app/capacity/scenarios', table: 'cap_scenarios', where: '' },
  // Capacity scenario children + scenario-local catalogues (registry-driven below)
  ...Object.entries(CHILD_MOUNTS)
    .filter(([segment]) => !BESPOKE_LIST_SEGMENTS.has(segment))
    .map(([segment, def]) => ({
      path: `/edge/app/capacity/scenarios/${SCENARIO}/${segment}`,
      table: String(def.table),
      where: ' WHERE `scenario_id` = ?',
    })),
  ...Object.entries(LOCAL_CATALOGUE_MOUNTS).map(([catalogue, def]) => ({
    path: `/edge/app/capacity/scenarios/${SCENARIO}/local-catalogues/${catalogue}`,
    table: String(def.table),
    where: ' WHERE `scenario_id` = ?',
  })),
];

let currentUser;
let server;
let baseUrl;

before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { req.user = currentUser; next(); });
  app.use('/edge/app/schema', schemaRouter);
  app.use('/edge/app/api-connectors', connectorsRouter);
  app.use('/edge/app/flow-recipes', recipesRouter);
  app.use('/edge/app/flow-recipe-steps', stepsRouter);
  app.use('/edge/app/flow-recipe-runs', runsRouter);
  app.use('/edge/app/capacity', capacityRouter);
  server = http.createServer(app);
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});

after(() => server && server.close());

beforeEach(() => {
  queries = [];
  currentUser = { id: 'u-editor', role: 'editor', email: 'editor@example.test' };
});

function get(path) {
  return new Promise((resolve, reject) => {
    const r = http.request(`${baseUrl}${path}`, { method: 'GET' }, (res) => {
      const chunks = [];
      res.on('data', (c) => chunks.push(c));
      res.on('end', () => {
        let json = null;
        try { json = JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch { /* noop */ }
        resolve({ status: res.statusCode, json });
      });
    });
    r.on('error', reject);
    r.end();
  });
}

describe('list-surface sweep — every factory-backed list, with no new parameters', () => {
  for (const surface of SURFACES) {
    it(`${surface.table}: unlimited, ordered by created_at, scoped as before`, async () => {
      const res = await get(surface.path);
      assert.equal(res.status, 200, `GET ${surface.path} → ${res.status}: ${JSON.stringify(res.json)}`);

      const stmts = queries.filter((q) => q.sql.startsWith(`SELECT * FROM \`fmb_${surface.table}\``));
      assert.equal(stmts.length, 1, `expected one list statement for ${surface.table}, saw ${stmts.length}`);

      // Row count: no bound of any kind is asked for.
      assert.equal(
        stmts[0].sql,
        `SELECT * FROM \`fmb_${surface.table}\`${surface.where} ORDER BY \`created_at\` IS NULL, \`created_at\` ASC`,
      );

      // No total is computed for a caller that did not ask for one.
      const counts = queries.filter((q) => q.sql.includes(`COUNT(*) AS cnt FROM \`fmb_${surface.table}\``));
      assert.deepEqual(counts, [], `${surface.table} gained an unrequested COUNT`);

      // Response shape: a bare array, not a page object — and it carries the
      // row, so the assertions below are looking at real content.
      assert.ok(Array.isArray(res.json.data), `${surface.table} no longer returns a bare array`);
      assert.equal(res.json.data.length, 1, `${surface.table} dropped its row`);
      assert.equal(res.json.data[0].id, `${surface.table}-row-1`);

      // Row content: the enrichment a mount declares must still be applied.
      // Asserted from the mount's own declaration so a new mount that declares
      // it is covered without editing this test.
      const mount = RECORDED_MOUNTS.find((m) => m.logicalName === surface.table);
      assert.ok(mount, `${surface.table} was never registered on the factory`);
      if (mount.opts.resolveOwnerName) {
        assert.equal(
          res.json.data[0].owner_name,
          'Edith Editor',
          `${surface.table} declares resolveOwnerName but the list row carries no owner_name`,
        );
      }

      // Same technique for the read serializer, so a mount that declares one is
      // covered by construction rather than by someone remembering to add a
      // case. Two distinct failures are separated on purpose:
      //   1. the fixture must be one the mount's OWN serializer changes — if it
      //      is not, this surface's coverage is nominal and a neutered
      //      serializer would look identical to a working one;
      //   2. the response must equal what that serializer produces — which is
      //      what fails when the handler stops applying it.
      if (mount.opts.serializeRead) {
        const mapped = mapRowsFromDb(surface.table, [rowFor(surface.table)])[0];
        const serialized = mount.opts.serializeRead({ ...mapped });
        assert.notDeepEqual(
          serialized,
          mapped,
          `${surface.table} declares serializeRead but its sweep fixture does not trigger it — `
          + 'a neutered serializer would be indistinguishable from a working one. Give rowFor() '
          + 'a value this serializer changes.',
        );
        for (const [key, value] of Object.entries(serialized)) {
          assert.deepEqual(
            res.json.data[0][key],
            value,
            `${surface.table}: the list row's "${key}" is not what its own serializeRead produces`,
          );
        }
        // A serializer that WITHHOLDS a field leaves no key to compare above,
        // so its removal has to be asserted from the other side — otherwise a
        // strip-style serializer (flow_recipes drops its approver) is covered
        // by name only. Keys the owner-name enrichment adds after mapping are
        // not in `mapped`, so they never land in this set.
        for (const key of Object.keys(mapped)) {
          if (key in serialized) continue;
          assert.ok(
            !(key in res.json.data[0]),
            `${surface.table}: its own serializeRead withholds "${key}", but the list row still carries it`,
          );
        }
      }
    });
  }

  it('the connector list still masks a stored secret', async () => {
    // The read serializer is what masks it. Bypassing it left every assertion
    // in the previous version of this file green while secrets went out in
    // plain text on two list surfaces.
    const res = await get('/edge/app/api-connectors');
    assert.equal(res.status, 200);
    assert.equal(
      JSON.stringify(res.json).includes(SECRET),
      false,
      'the stored connector secret reached a list read unmasked',
    );
  });

  it('the recipe list still withholds who approved it and when', async () => {
    // The other read serializer, on the other surface that declares one.
    const res = await get('/edge/app/flow-recipes');
    assert.equal(res.status, 200);
    const row = res.json.data[0];
    assert.equal(row.approved_by, undefined, 'flow_recipes list disclosed approved_by');
    assert.equal(row.approved_at, undefined, 'flow_recipes list disclosed approved_at');
  });

  it('the rules list is the bespoke read, and it too is unlimited and unpaged', async () => {
    const res = await get(`/edge/app/capacity/scenarios/${SCENARIO}/rules`);
    assert.equal(res.status, 200);
    const stmts = queries.filter((q) => q.sql.startsWith('SELECT * FROM `fmb_cap_rules`'));
    assert.equal(stmts.length, 1);
    assert.equal(
      stmts[0].sql,
      'SELECT * FROM `fmb_cap_rules` WHERE scenario_id IS NULL OR scenario_id = ?',
      'the rules list is no longer the bespoke catalogue read — re-check which handler serves it',
    );
    assert.ok(Array.isArray(res.json.data));
  });

  it('covers every scenario child mount and every scenario-local catalogue', () => {
    for (const segment of Object.keys(CHILD_MOUNTS)) {
      if (BESPOKE_LIST_SEGMENTS.has(segment)) continue;
      assert.ok(
        SURFACES.some((s) => s.path.endsWith(`/${segment}`)),
        `child mount '${segment}' is not in the sweep`,
      );
    }
    for (const catalogue of Object.keys(LOCAL_CATALOGUE_MOUNTS)) {
      assert.ok(
        SURFACES.some((s) => s.path.endsWith(`/local-catalogues/${catalogue}`)),
        `local catalogue '${catalogue}' is not in the sweep`,
      );
    }
  });

  it('loads every module that mounts the factory — the reach half of completeness', () => {
    // The recorded-mounts check below can only report mounts in modules this
    // file requires. A `createCrudRoutes` call in a router the sweep does not
    // load is invisible to it however the table argument is spelled — and a
    // surface in its own router file, registered on the app in index-edge.js,
    // is the shape every standalone surface in this PR already has. This walks
    // the whole source tree instead and asserts that each file calling the
    // factory is one the sweep actually pulled in, which it can read off
    // require.cache after the routers above have loaded.
    const root = path.resolve(__dirname, '../../../../src');
    const factoryDefinition = require.resolve('../../../../src/edge/routes/app/schema/crud-factory');
    const callers = [];

    const walk = (dir) => {
      for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
        const full = path.join(dir, entry.name);
        if (entry.isDirectory()) { walk(full); continue; }
        if (!entry.name.endsWith('.js')) continue;
        if (full === factoryDefinition) continue; // where the function is defined
        const src = fs.readFileSync(full, 'utf8');
        // Any invocation, however the argument is written — the point of this
        // assertion is reach, not the argument.
        if (/\bcreateCrudRoutes\s*\(/.test(src)) callers.push(full);
      }
    };
    walk(root);

    assert.ok(callers.length > 0, 'no factory call sites found — the source walk is not walking');

    const notLoaded = callers
      .filter((file) => !require.cache[file])
      .map((file) => path.relative(root, file));

    assert.deepEqual(
      notLoaded,
      [],
      'these modules mount the CRUD factory but the sweep never loads them, so their surfaces are unswept — require the router here',
    );
  });

  it('covers every table actually mounted on the factory', () => {
    // A sweep that silently misses a mount added later is not a sweep — and the
    // way to miss one is to look for mounts in the source TEXT. The previous
    // version matched `createCrudRoutes('table_name'` and was blind to
    // `createCrudRoutes(TABLES.X, …)`, which is the form this project's own
    // identifier rule steers new code towards; a live mount written that way
    // joined the application with the whole suite green. This reads the mounts
    // from the factory itself, so how the argument is spelled cannot matter.
    assert.ok(RECORDED_MOUNTS.length > 0, 'no mounts were recorded — the factory wrapper is not in effect');

    const swept = new Set(SURFACES.map((s) => s.table));
    const bespokeTables = new Set(
      Object.entries(CHILD_MOUNTS)
        .filter(([segment]) => BESPOKE_LIST_SEGMENTS.has(segment))
        .map(([, def]) => String(def.table)),
    );

    const missed = RECORDED_MOUNTS
      .map((m) => m.logicalName)
      .filter((name) => !swept.has(name) && !bespokeTables.has(name));

    assert.deepEqual(
      [...new Set(missed)],
      [],
      'these tables are mounted on the CRUD factory but are not in the sweep',
    );
  });
});

describe('list-surface sweep — the same surfaces as an administrator', () => {
  for (const surface of SURFACES) {
    it(`${surface.table}: an administrator's read is unchanged too`, async () => {
      currentUser = { id: 'u-admin', role: 'admin', email: 'admin@example.test' };
      const res = await get(surface.path);
      assert.equal(res.status, 200, `GET ${surface.path} → ${res.status}: ${JSON.stringify(res.json)}`);

      const stmts = queries.filter((q) => q.sql.startsWith(`SELECT * FROM \`fmb_${surface.table}\``));
      assert.equal(stmts.length, 1);
      // Every remaining scope is structural (a scenario binding is a path
      // segment, not a role decision), so an administrator's statement is the
      // same one. No surface carries a per-user read scope any more.
      assert.ok(!surface.where.includes('actor_id'));
      assert.equal(
        stmts[0].sql,
        `SELECT * FROM \`fmb_${surface.table}\`${surface.where} ORDER BY \`created_at\` IS NULL, \`created_at\` ASC`,
      );
      assert.ok(Array.isArray(res.json.data));
    });
  }
});
