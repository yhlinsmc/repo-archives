/**
 * capacity-delete-preview.test.js — phase-5 PR-4 backend coverage:
 *   - GET  /scenarios/:id/delete-preview      (T1 blast-radius, authz, 404)
 *   - GET  /config/:group/:id/delete-preview  (T2 references, unknown group 400)
 *   - GET  /scenarios/health                  (per-scenario health facts)
 *   - PATCH /scenarios/:id/owner              (admin transfer / shared / gates)
 *
 * Runs against a mock edge/db whose conn dispatches by SQL shape. Both ro and rw
 * share one facade; the rw path also drives beginTransaction/commit/rollback for
 * the owner-transfer flow.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../../../src/edge/db');

// Per-test mutable state.
let queries;
let scenarioRow;      // { id, name, owner_id } | null  (T1 + owner FOR UPDATE)
let userRow;          // { id, role } | null            (owner transfer target lookup)
let scopedCounts;     // { table: n }                   (T1 COUNT(*) WHERE scenario_id)
let namesByTable;     // { table: [{id,name}] }         (T1 name list)
let refCounts;        // { 'table.column': n }          (T2 COUNT(*) WHERE col = ?)
let healthScenarios;  // [{ id }]
let healthGroups;     // { sqlFragment: [{scenario_id,c}] } matched by table name

const conn = {
  async beginTransaction() {},
  async commit() {},
  async rollback() {},
  release() {},
  async query(sql, params = []) {
    queries.push({ sql, params });

    // --- owner transfer: target user lookup ---
    if (/SELECT id, role, banned FROM `fmb_users` WHERE id = \?/.test(sql)) {
      return userRow ? [userRow] : [];
    }
    // --- owner transfer: applyOwnerChange FOR UPDATE ---
    if (/SELECT id, owner_id FROM `fmb_cap_scenarios` WHERE id = \? FOR UPDATE/.test(sql)) {
      return scenarioRow ? [{ id: scenarioRow.id, owner_id: scenarioRow.owner_id }] : [];
    }
    if (/^UPDATE `fmb_cap_scenarios` SET owner_id/.test(sql)) return { affectedRows: 1 };
    if (/^INSERT INTO `fmb_feature_audit`/.test(sql)) return { affectedRows: 1 };

    // --- T1: resolveScenarioWriteAccess gate (owner_id only, unlocked for RO preview) ---
    if (/SELECT id, owner_id FROM `fmb_cap_scenarios` WHERE id = \?(?! FOR UPDATE)/.test(sql)) {
      return scenarioRow ? [{ owner_id: scenarioRow.owner_id }] : [];
    }
    // --- T1: separate name read for the response body ---
    if (/SELECT name FROM `fmb_cap_scenarios` WHERE id = \?/.test(sql)) {
      return scenarioRow ? [{ name: scenarioRow.name }] : [];
    }
    // --- T1: scoped COUNT(*) ---
    let m = sql.match(/SELECT COUNT\(\*\) AS c FROM `fmb_(cap_[a-z_]+)` WHERE scenario_id = \?/);
    if (m) return [{ c: scopedCounts[m[1]] || 0 }];
    // --- T1: bounded name list (display column aliased AS name; databases use
    // function_name, hence the per-entity column) ---
    m = sql.match(/SELECT id, `[a-z_]+` AS name FROM `fmb_(cap_[a-z_]+)` WHERE scenario_id = \? ORDER BY `[a-z_]+` LIMIT \?/);
    if (m) return namesByTable[m[1]] || [];

    // --- T2: reference COUNT(*) ---
    m = sql.match(/SELECT COUNT\(\*\) AS c FROM `fmb_(cap_[a-z_]+)` WHERE `([a-z_]+)` = \?/);
    if (m) return [{ c: refCounts[`${m[1]}.${m[2]}`] || 0 }];

    // --- health: scenario ids ---
    if (/SELECT id FROM `fmb_cap_scenarios`$/.test(sql.trim())) return healthScenarios;
    // --- health: sites group ---
    if (/FROM `fmb_cap_sites` GROUP BY scenario_id/.test(sql)) return healthGroups.sites || [];
    if (/FROM `fmb_cap_databases`\s+WHERE profile_id IS NULL GROUP BY scenario_id/.test(sql)) return healthGroups.noProfile || [];
    // --- health: the stale data-centre cache aggregate ---
    // A plain JOIN, not a LEFT JOIN: both ends resolve and what is wrong is
    // that they disagree, so it must be matched BEFORE the broken-ref branch
    // below rather than falling through it to the default `[]`.
    if (/JOIN `fmb_cap_hypervisors` h[\s\S]*v\.site_id <> h\.site_id/.test(sql)) {
      return healthGroups.staleVmSite || [];
    }
    // --- health: broken-ref LEFT JOINs ---
    if (/LEFT JOIN .* WHERE .* IS NOT NULL AND p\.id IS NULL/s.test(sql)) {
      // Key by FROM table + FK column so a test can target one specific probe
      // (each source table has two probes).
      const fm = sql.match(/FROM `fmb_(cap_[a-z_]+)` c/);
      const cm = sql.match(/ON p\.id = c\.`([a-z_]+)`/);
      const key = fm && cm ? `broken.${fm[1]}.${cm[1]}` : 'broken.unknown';
      return healthGroups[key] || [];
    }
    return [];
  },
};

const poolFacade = { getConnection: async () => conn, query: (s, p) => conn.query(s, p) };
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: { ro: poolFacade, rw: poolFacade }, t: (n) => `fmb_${n}`, getDynamicPool: async () => ({ ro: poolFacade, rw: poolFacade }) },
};

const router = require('../../../../src/edge/routes/app/capacity');
// Same-boundary import (both are backend/CommonJS): derive the expected count-key
// set from the SAME constant the DELETE + preview iterate, so a 17th scoped table
// updates this test automatically instead of drifting from a hand-copied list.
const { SCENARIO_SCOPED_TABLES } = require('../../../../src/edge/routes/app/capacity/_shared');

let currentUser; let server; let baseUrl;
before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { req.user = currentUser; next(); });
  app.use('/capacity', router);
  server = http.createServer(app);
  await new Promise((r) => server.listen(0, r));
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});
after(() => server && server.close());

beforeEach(() => {
  queries = [];
  scenarioRow = { id: 'scn-1', name: 'Prod Plan', owner_id: null };
  userRow = { id: 'u-editor', role: 'editor' };
  scopedCounts = {};
  namesByTable = {};
  refCounts = {};
  healthScenarios = [];
  healthGroups = {};
  currentUser = { id: 'u-admin', role: 'admin' };
});

async function req(method, path, body) {
  const res = await fetch(`${baseUrl}${path}`, {
    method,
    headers: { 'content-type': 'application/json' },
    ...(body !== undefined ? { body: JSON.stringify(body) } : {}),
  });
  const text = await res.text();
  let json = null;
  try { json = text ? JSON.parse(text) : null; } catch { /* non-json */ }
  return { status: res.status, json };
}

// The scenario-scoped tables the DELETE actually wipes — derived live from the
// shared constant so the preview MUST count exactly this set (no hand-copy drift).
const SCOPED_TABLE_KEYS = SCENARIO_SCOPED_TABLES.map(String);

describe('T1 GET /scenarios/:id/delete-preview', () => {
  it('returns counts (keyed by scoped table) + bounded names for an admin', async () => {
    scopedCounts = { cap_sites: 3, cap_vms: 5, cap_databases: 2, cap_db_instances: 4, cap_field_defs: 7 };
    namesByTable = { cap_sites: [{ id: 's1', name: 'DC1' }], cap_vms: [{ id: 'v1', name: 'app-1' }] };
    const { status, json } = await req('GET', '/capacity/scenarios/scn-1/delete-preview');
    assert.equal(status, 200);
    assert.equal(json.data.scenario.name, 'Prod Plan');
    assert.equal(json.data.counts.cap_sites, 3);
    assert.equal(json.data.counts.cap_vms, 5);
    // Previously-omitted scoped tables now surface (stage-1 MED #1).
    assert.equal(json.data.counts.cap_field_defs, 7);
    // names_total = sites+hypervisors+vms+databases = 3+0+5+2
    assert.equal(json.data.names_total, 10);
    assert.ok(json.data.names.some((n) => n.kind === 'site' && n.name === 'DC1'));
  });

  it('counts EXACTLY the scenario-scoped table set (no drift from the DELETE)', async () => {
    const { json } = await req('GET', '/capacity/scenarios/scn-1/delete-preview');
    assert.deepEqual(Object.keys(json.data.counts).sort(), [...SCOPED_TABLE_KEYS].sort());
  });

  it('403s a non-owner editor (mirrors the DELETE gate)', async () => {
    scenarioRow = { id: 'scn-1', name: 'Owned', owner_id: 'someone-else' };
    currentUser = { id: 'u-editor', role: 'editor' };
    const { status, json } = await req('GET', '/capacity/scenarios/scn-1/delete-preview');
    assert.equal(status, 403);
    assert.equal(json.error.code, 'FORBIDDEN');
  });

  it('404s a missing scenario', async () => {
    scenarioRow = null;
    const { status } = await req('GET', '/capacity/scenarios/ghost/delete-preview');
    assert.equal(status, 404);
  });
});

describe('T2 GET /config/:group/:id/delete-preview', () => {
  it('returns kind-noun reference counts and blocked=true when referenced', async () => {
    refCounts = { 'cap_vms.sizing_profile_id': 2, 'cap_databases.profile_id': 1 };
    const { status, json } = await req('GET', '/capacity/config/vm_profiles/prof-1/delete-preview');
    assert.equal(status, 200);
    assert.equal(json.data.blocked, true);
    assert.equal(json.data.total, 3);
    // No scenario names/ids leak — only kind nouns.
    assert.ok(json.data.references.every((r) => typeof r.by === 'string' && !('scenario_id' in r)));
  });

  it('returns blocked=false for an unreferenced row', async () => {
    const { status, json } = await req('GET', '/capacity/config/teams/team-1/delete-preview');
    assert.equal(status, 200);
    assert.equal(json.data.blocked, false);
    assert.equal(json.data.total, 0);
  });

  it('400s an unknown catalogue group', async () => {
    const { status } = await req('GET', '/capacity/config/not_a_group/x/delete-preview');
    assert.equal(status, 400);
  });
});

describe('GET /scenarios/health', () => {
  it('returns per-scenario facts folding sites, missing-profile, and broken refs', async () => {
    healthScenarios = [{ id: 'scn-1' }, { id: 'scn-2' }];
    healthGroups = {
      sites: [{ scenario_id: 'scn-1', c: 2 }],
      noProfile: [{ scenario_id: 'scn-2', c: 1 }],
      'broken.cap_vms.hypervisor_id': [{ scenario_id: 'scn-1', c: 1 }],
    };
    const { status, json } = await req('GET', '/capacity/scenarios/health');
    assert.equal(status, 200);
    const byId = Object.fromEntries(json.data.map((f) => [f.id, f]));
    assert.equal(byId['scn-1'].sites, 2);
    assert.equal(byId['scn-1'].brokenRefs, 1);
    assert.equal(byId['scn-2'].sites, 0);
    assert.equal(byId['scn-2'].databasesWithoutProfile, 1);
  });

  it('401s an unauthenticated caller (no cross-tenant disclosure without a login)', async () => {
    // Pre-fix this handler had no gate and returned 200 with every scenario id +
    // integrity signal to an anonymous request (security C1).
    currentUser = undefined;
    const { status, json } = await req('GET', '/capacity/scenarios/health');
    assert.equal(status, 401);
    assert.equal(json.error.code, 'UNAUTHORIZED');
  });

  it('probes every validated placement FK, not just hypervisor/profile (Codex R2 #1)', async () => {
    // A dangling VM disk_combo ref is counted — pre-fix the aggregate only probed
    // hypervisor_id + sizing_profile_id, so this class reported healthy.
    healthScenarios = [{ id: 'scn-1' }];
    healthGroups = { 'broken.cap_vms.disk_combo_id': [{ scenario_id: 'scn-1', c: 2 }] };
    const { json } = await req('GET', '/capacity/scenarios/health');
    const byId = Object.fromEntries(json.data.map((f) => [f.id, f]));
    assert.equal(byId['scn-1'].brokenRefs, 2);
    // And a broken VM team ref (another new probe).
    healthGroups = { 'broken.cap_vms.team_id': [{ scenario_id: 'scn-1', c: 1 }] };
    const again = await req('GET', '/capacity/scenarios/health');
    assert.equal(again.json.data.find((f) => f.id === 'scn-1').brokenRefs, 1);
  });

  it('encodes reference SCOPE in the integrity joins (Codex R2 #2)', async () => {
    healthScenarios = [{ id: 'scn-1' }];
    healthGroups = {};
    queries = [];
    await req('GET', '/capacity/scenarios/health');
    const joinSql = queries.filter((q) => /LEFT JOIN .* IS NOT NULL AND p\.id IS NULL/s.test(q.sql));
    // A scenario-mode FK (vm.hypervisor_id → cap_hypervisors) must require the
    // target be SAME-scenario; a catalogue-mode FK (vm.sizing_profile_id →
    // cap_vm_profiles) must allow global-or-same-scenario.
    const scenarioJoin = joinSql.find((q) => /`fmb_cap_vms` c\s+LEFT JOIN `fmb_cap_hypervisors`/.test(q.sql));
    const catalogueJoin = joinSql.find((q) => /`fmb_cap_vms` c\s+LEFT JOIN `fmb_cap_vm_profiles`/.test(q.sql));
    assert.ok(scenarioJoin && /p\.scenario_id = c\.scenario_id/.test(scenarioJoin.sql), 'scenario FK join missing same-scenario scope');
    assert.ok(catalogueJoin && /p\.scenario_id IS NULL OR p\.scenario_id = c\.scenario_id/.test(catalogueJoin.sql), 'catalogue FK join missing global-or-same-scenario scope');
  });
});

describe('PATCH /scenarios/:id/owner', () => {
  it('transfers to an existing editor (admin)', async () => {
    scenarioRow = { id: 'scn-1', name: 'P', owner_id: null };
    userRow = { id: 'u-editor', role: 'editor' };
    const { status, json } = await req('PATCH', '/capacity/scenarios/scn-1/owner', { new_owner_id: 'u-editor' });
    assert.equal(status, 200);
    assert.equal(json.data.changed, true);
    assert.equal(json.data.owner_id, 'u-editor');
    // An audit row is written on a real change.
    assert.ok(queries.some((q) => /INSERT INTO `fmb_feature_audit`/.test(q.sql)));
  });

  it('allows make-shared (new_owner_id null)', async () => {
    scenarioRow = { id: 'scn-1', name: 'P', owner_id: 'u-editor' };
    const { status, json } = await req('PATCH', '/capacity/scenarios/scn-1/owner', { new_owner_id: null });
    assert.equal(status, 200);
    assert.equal(json.data.owner_id, null);
  });

  it('403s a non-admin', async () => {
    currentUser = { id: 'u-editor', role: 'editor' };
    const { status } = await req('PATCH', '/capacity/scenarios/scn-1/owner', { new_owner_id: 'u-x' });
    assert.equal(status, 403);
  });

  it('400s a nonexistent target user', async () => {
    userRow = null;
    const { status } = await req('PATCH', '/capacity/scenarios/scn-1/owner', { new_owner_id: 'ghost' });
    assert.equal(status, 400);
  });

  it('400s transferring to a plain user (cannot own a scenario)', async () => {
    userRow = { id: 'u-plain', role: 'user' };
    const { status } = await req('PATCH', '/capacity/scenarios/scn-1/owner', { new_owner_id: 'u-plain' });
    assert.equal(status, 400);
  });
});

// ── the list badge and the detail panel answer the same question ────────────
// The detail panel reports a placed KVM whose cached data centre contradicts
// its host as a data-integrity fault. This aggregate feeds the LIST badge, and
// a rule applied on one of the two is not applied: the list would call a
// scenario healthy while opening it showed the same scenario invalid.
describe('GET /scenarios/health — the stale data-centre cache', () => {
  it('folds a contradicting cache into brokenRefs', async () => {
    healthScenarios = [{ id: 'scn-1' }, { id: 'scn-2' }];
    healthGroups = { staleVmSite: [{ scenario_id: 'scn-1', c: 3 }] };
    const { status, json } = await req('GET', '/capacity/scenarios/health');
    assert.equal(status, 200);
    const byId = Object.fromEntries(json.data.map((f) => [f.id, f]));
    assert.equal(byId['scn-1'].brokenRefs, 3, 'a KVM naming a DC its host does not stand in was not counted');
    assert.equal(byId['scn-2'].brokenRefs, 0, 'a scenario with no drift was charged for another scenario\'s');
  });

  it('adds to the broken-reference count rather than replacing it', async () => {
    // Two different faults, one badge. Overwriting instead of folding would
    // report the smaller of the two and read as an improvement.
    healthScenarios = [{ id: 'scn-1' }];
    healthGroups = {
      'broken.cap_vms.hypervisor_id': [{ scenario_id: 'scn-1', c: 2 }],
      staleVmSite: [{ scenario_id: 'scn-1', c: 1 }],
    };
    const { json } = await req('GET', '/capacity/scenarios/health');
    assert.equal(json.data.find((f) => f.id === 'scn-1').brokenRefs, 3);
  });

  it('asks the ENGINE whether the two data centres differ, not JavaScript', async () => {
    // `CHAR(36)` under a case-folding collation: two spellings of one uuid are
    // one value, and a comparison drawn back into JavaScript would report every
    // respelled-but-equal cache as a fault.
    healthScenarios = [{ id: 'scn-1' }];
    healthGroups = {};
    queries = [];
    await req('GET', '/capacity/scenarios/health');
    const stale = queries.find((q) => /v\.site_id <> h\.site_id/.test(q.sql));
    assert.ok(stale, 'the stale-cache aggregate was never issued');
    // Same scenario on both sides of the join — a host in ANOTHER scenario is
    // not this KVM's host, and joining on id alone would compare against one.
    assert.match(stale.sql, /h\.scenario_id = v\.scenario_id/);
  });
});
