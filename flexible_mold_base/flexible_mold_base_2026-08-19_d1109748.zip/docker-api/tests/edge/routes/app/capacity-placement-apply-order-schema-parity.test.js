/**
 * capacity-placement-apply-order-schema-parity.test.js — validates the columns
 * the item-9 (spec §4.1.4, H1-fixed) per-host order_index write in
 * placement-apply.js references against the ACTUAL `cap_vms` DDL, WITHOUT a
 * live DB. The node:test route mocks stub query results, so a wrong/renamed
 * column here would stay green in both runners yet 500 the whole placement
 * Save in production. This test closes that gap (CLAUDE.md §6 new-SQL rule).
 */
const { describe, it, before } = require('node:test');
const assert = require('node:assert/strict');

const dbKey = require.resolve('../../../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: {}, t: (n) => n },
};

const { buildEngineTableDDLs } = require('../../../../src/table-ddls');

const SQL_TYPES = /^`?([a-z_]+)`?\s+(?:CHAR|VARCHAR|INT|DOUBLE|TIMESTAMP|JSON|TEXT|ENUM|BOOLEAN|TINYINT|BIGINT|DATETIME|DECIMAL|FLOAT|BLOB)\b/i;
let columnsByTable;

before(() => {
  columnsByTable = new Map();
  for (const ddl of buildEngineTableDDLs((n) => n)) {
    const m = ddl.match(/CREATE TABLE IF NOT EXISTS `([^`]+)`/);
    if (!m) continue;
    const table = m[1];
    const cols = new Set();
    for (const rawLine of ddl.split('\n')) {
      const line = rawLine.trim();
      if (!line || line.startsWith('--') || line.startsWith('/*')) continue;
      const cm = line.match(SQL_TYPES);
      if (cm) cols.add(cm[1]);
    }
    columnsByTable.set(table, cols);
  }
});

// SELECT id, order_index FROM cap_vms WHERE scenario_id = ? AND
// hypervisor_id = ? FOR UPDATE (placement-apply.js's per-hostOrders-entry
// membership check + order write).
const REFERENCED_COLUMNS = ['id', 'hypervisor_id', 'order_index', 'scenario_id'];

describe('placement-apply hostOrders schema parity (item 9 / H1)', () => {
  it('cap_vms declares every column the hostOrders SELECT references', () => {
    const cols = columnsByTable.get('cap_vms');
    assert.ok(cols && cols.size > 0, 'no columns parsed for cap_vms');
    for (const col of REFERENCED_COLUMNS) {
      assert.ok(cols.has(col), `cap_vms is missing '${col}' (the resequence SELECT would 500)`);
    }
  });
});
