/**
 * capacity-database-bulk-create-schema-parity.test.js — validates every column
 * the bulk-create endpoint writes (INSERT_COLUMNS) and reads (READ_COLUMNS)
 * against the ACTUAL table DDL, WITHOUT a live DB. The route test mocks stub
 * query results, so a wrong column name (e.g. SELECT `name` from cap_databases,
 * whose display column is `function_name`) stays green in both runners yet 500s
 * in production and rolls back every wizard submit. This test closes that gap by
 * parsing docker-api/src/table-ddls and asserting the referenced columns exist.
 *
 * INSERT_COLUMNS is the SAME array the insert builder iterates, so a column added
 * to a statement is under this check by construction — not a hand-copied list
 * that can agree with the DDL while the statement does not.
 */
const { describe, it, before } = require('node:test');
const assert = require('node:assert/strict');

// _shared / reference-integrity destructure { t } from ../../../db at load; stub
// the db module so the require chain is side-effect-free (no pool).
const dbKey = require.resolve('../../../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: {}, t: (n) => n },
};

const { buildEngineTableDDLs } = require('../../../../src/table-ddls');
const {
  INSERT_COLUMNS, READ_COLUMNS,
} = require('../../../../src/edge/routes/app/capacity/database-bulk-create');

const SQL_TYPES = /^`?([a-z_]+)`?\s+(?:CHAR|VARCHAR|INT|DOUBLE|TIMESTAMP|JSON|TEXT|ENUM|BOOLEAN|TINYINT|BIGINT|DATETIME|DECIMAL|FLOAT|BLOB)\b/i;
let columnsByTable;

before(() => {
  columnsByTable = new Map();
  for (const ddl of buildEngineTableDDLs((n) => n)) {
    const m = ddl.match(/CREATE TABLE IF NOT EXISTS `([^`]+)`/);
    if (!m) continue;
    const cols = new Set();
    for (const rawLine of ddl.split('\n')) {
      const line = rawLine.trim();
      if (!line || line.startsWith('--') || line.startsWith('/*')) continue;
      const cm = line.match(SQL_TYPES);
      if (cm) cols.add(cm[1]);
    }
    columnsByTable.set(m[1], cols);
  }
});

describe('database bulk-create — schema parity', () => {
  it('every INSERT column exists on its table', () => {
    for (const [table, cols] of Object.entries(INSERT_COLUMNS)) {
      const declared = columnsByTable.get(String(table));
      assert.ok(declared && declared.size > 0, `no columns parsed for ${table}`);
      for (const col of cols) {
        assert.ok(declared.has(col), `${table} has no column '${col}' (a wrong INSERT identifier 500s the whole submit)`);
      }
    }
  });

  it('every INSERT table carries scenario_id (the writes are scenario-scoped)', () => {
    for (const table of Object.keys(INSERT_COLUMNS)) {
      assert.ok(columnsByTable.get(String(table)).has('scenario_id'), `${table} is missing scenario_id`);
    }
  });

  it('every READ column exists on its table', () => {
    for (const [table, cols] of Object.entries(READ_COLUMNS)) {
      const declared = columnsByTable.get(String(table));
      assert.ok(declared && declared.size > 0, `no columns parsed for ${table}`);
      for (const col of cols) {
        assert.ok(declared.has(col), `${table} has no column '${col}' (a wrong SELECT identifier 500s a path no mocked runner reaches)`);
      }
    }
  });

  it('cap_databases display column is function_name, not name (the classic 500)', () => {
    const cols = columnsByTable.get('cap_databases');
    assert.ok(INSERT_COLUMNS.cap_databases.includes('function_name'));
    assert.ok(cols.has('function_name'));
  });

  it('cap_db_instances.vm_id is a real column (an instance always has a db_host VM)', () => {
    assert.ok(columnsByTable.get('cap_db_instances').has('vm_id'));
    assert.ok(INSERT_COLUMNS.cap_db_instances.includes('vm_id'));
  });
});
