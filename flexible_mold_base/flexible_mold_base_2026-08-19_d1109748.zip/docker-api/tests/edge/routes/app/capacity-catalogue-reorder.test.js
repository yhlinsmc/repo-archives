/**
 * capacity-catalogue-reorder.test.js — the phase-6 (spec §D3) bulk drag-reorder
 * route for the GLOBAL config catalogues (hardware_specs / disk_combos / teams /
 * vm_profiles) rendered on the CapacityConfig page. It is the global-scope
 * analogue of capacity-reorder.test.js: the scenario-scoped route scopes to
 * `scenario_id = :id`, this one to `scenario_id IS NULL`. Same contract — a bulk
 * order_index rewrite in one transaction, gated admin+editor, rejecting a
 * malformed / partial / foreign id set. A scenario-LOCAL row id is structurally
 * not in the global set, so it is rejected like a foreign id.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../../../src/edge/db');

let state;
function freshState() {
  return {
    queries: [],
    began: 0, committed: 0, rolledBack: 0, released: 0,
    // The catalogue's current GLOBAL row-id set (the FOR UPDATE lock read).
    currentRowIds: ['g1', 'g2', 'g3'],
  };
}

const conn = {
  async beginTransaction() { state.began += 1; },
  async commit() { state.committed += 1; },
  async rollback() { state.rolledBack += 1; },
  release() { state.released += 1; },
  async query(sql, params = []) {
    state.queries.push({ sql, params });
    // lockGlobalConfig sentinel — cap_settings row lock.
    if (/SELECT id FROM `fmb_cap_settings` FOR UPDATE/.test(sql)) return [{ id: 's1' }];
    // The catalogue's current GLOBAL row set (FOR UPDATE) — table-agnostic match.
    if (/SELECT id FROM `fmb_\w+` WHERE scenario_id IS NULL FOR UPDATE/.test(sql)) {
      return state.currentRowIds.map((id) => ({ id }));
    }
    if (/^UPDATE `fmb_\w+` SET order_index = \? WHERE id = \? AND scenario_id IS NULL/.test(sql)) {
      return { affectedRows: 1 };
    }
    return [];
  },
};

const poolFacade = {
  getConnection: async () => conn,
  query: (sql, params) => conn.query(sql, params),
};
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: { ro: poolFacade, rw: poolFacade }, t: (n) => `fmb_${n}` },
};

const router = require('../../../../src/edge/routes/app/capacity');

let currentUser; let server; let baseUrl;
before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { req.user = currentUser; next(); });
  app.use('/capacity', router);
  server = http.createServer(app);
  await new Promise((r) => server.listen(0, r));
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});
after(() => server && server.close());
beforeEach(() => {
  state = freshState();
  currentUser = { id: 'u-admin', role: 'admin' };
});

function request(method, path, body) {
  return new Promise((resolve, reject) => {
    const payload = body === undefined ? '' : JSON.stringify(body);
    const r = http.request(
      `${baseUrl}${path}`,
      { method, headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) } },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          const raw = Buffer.concat(chunks).toString('utf8');
          let json = null;
          try { json = JSON.parse(raw); } catch { /* noop */ }
          resolve({ status: res.statusCode, json, raw });
        });
      },
    );
    r.on('error', reject);
    if (payload) r.write(payload);
    r.end();
  });
}

const updatesOf = (table) =>
  state.queries.filter((q) => new RegExp(`^UPDATE \`fmb_${table}\``).test(q.sql));

const GROUPS = [
  { group: 'hardware_specs', table: 'cap_hardware_specs' },
  { group: 'disk_combos', table: 'cap_disk_combos' },
  { group: 'teams', table: 'cap_teams' },
  { group: 'vm_profiles', table: 'cap_vm_profiles' },
];

for (const { group, table } of GROUPS) {
  const path = `/capacity/config/${group}/reorder`;
  describe(`PUT ${path}`, () => {
    it("rewrites order_index to each id's position in one transaction", async () => {
      const res = await request('PUT', path, { orderedIds: ['g3', 'g1', 'g2'] });
      assert.equal(res.status, 200, res.raw);
      assert.equal(res.json.data.reordered, 3);
      assert.equal(state.began, 1);
      assert.equal(state.committed, 1);
      assert.equal(state.rolledBack, 0);
      const updates = updatesOf(table);
      assert.equal(updates.length, 3);
      // params: [order_index, id]
      assert.deepEqual(updates.map((q) => [q.params[1], q.params[0]]), [
        ['g3', 0], ['g1', 1], ['g2', 2],
      ]);
    });

    it('a plain user (not editor/admin) is refused 403, nothing rewritten', async () => {
      currentUser = { id: 'u-user', role: 'user' };
      const res = await request('PUT', path, { orderedIds: ['g1', 'g2', 'g3'] });
      assert.equal(res.status, 403, res.raw);
      assert.equal(updatesOf(table).length, 0);
    });

    it('an editor may reorder the global catalogue', async () => {
      currentUser = { id: 'u-editor', role: 'editor' };
      const res = await request('PUT', path, { orderedIds: ['g2', 'g1', 'g3'] });
      assert.equal(res.status, 200, res.raw);
      assert.equal(updatesOf(table).length, 3);
    });

    it('rejects a missing/empty orderedIds (400)', async () => {
      const res = await request('PUT', path, {});
      assert.equal(res.status, 400, res.raw);
      assert.equal(updatesOf(table).length, 0);
    });

    it('rejects a body with a duplicate id (400)', async () => {
      const res = await request('PUT', path, { orderedIds: ['g1', 'g1', 'g2'] });
      assert.equal(res.status, 400, res.raw);
      assert.equal(updatesOf(table).length, 0);
    });

    it('rejects a PARTIAL id set (missing g3) — never a silent subset reorder', async () => {
      const res = await request('PUT', path, { orderedIds: ['g1', 'g2'] });
      assert.equal(res.status, 400, res.raw);
      assert.equal(updatesOf(table).length, 0);
    });

    it('rejects a FOREIGN / scenario-LOCAL id smuggled into the list', async () => {
      const res = await request('PUT', path, { orderedIds: ['g1', 'g2', 'local-row'] });
      assert.equal(res.status, 400, res.raw);
      assert.equal(updatesOf(table).length, 0);
    });
  });
}

describe('PUT /capacity/config/:group/reorder — unknown group', () => {
  it('400s a non-reorderable group (e.g. field_defs) without touching the DB', async () => {
    const res = await request('PUT', '/capacity/config/field_defs/reorder', { orderedIds: ['g1'] });
    assert.equal(res.status, 400, res.raw);
    assert.equal(state.began, 0);
  });
});
