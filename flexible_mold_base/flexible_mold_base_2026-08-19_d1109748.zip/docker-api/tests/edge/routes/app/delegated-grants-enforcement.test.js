'use strict';

/**
 * delegated-grants-enforcement.test.js — the two write points a grant reaches,
 * held to the statement they build.
 *
 * WHAT THIS FILE ESTABLISHES. That the delegated arm is present where it must be
 * (the update, and the re-read that follows it), absent where it must not be
 * (delete, create, an administrator's statement, every other mount), bound with
 * exactly the caller's identity and nothing else, and dropped entirely on a
 * database that has no grants table.
 *
 * WHAT IT DOES NOT ESTABLISH, said plainly because the difference matters on a
 * permission check: that the predicate EVALUATES the way it reads. The driver is
 * a stub — it cannot run SQL, so a predicate that is well-formed and wrong looks
 * identical here to one that is right. That question is answered against a real
 * database in `tests/integration/delegated-grants-predicate-real-db.test.js`,
 * which runs these statements for every combination of owner, grantee, subject
 * and revocation. Neither file replaces the other: this one reaches the ROUTES,
 * that one reaches the DATABASE.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../../../src/edge/db');

let queries;
let grantsTablePresent;
let activityTablePresent;
let activityInsertError;
let affectedRows;
let rowToReturn;

function makeConn() {
  return {
    async query(sql, params = []) {
      queries.push({ sql, params });
      if (/^SELECT DATABASE\(\)/i.test(sql)) return [{ db: 'testdb' }];
      if (/information_schema\.TABLES/i.test(sql)) {
        // The probe asks for one named table, and each flag says whether this
        // database has that one.
        const [name] = params;
        if (String(name).endsWith('delegated_grants')) return grantsTablePresent ? [{ 1: 1 }] : [];
        if (String(name).endsWith('template_activity')) return activityTablePresent ? [{ 1: 1 }] : [];
        return [];
      }
      if (/^INSERT INTO `fmb_template_activity`/.test(sql)) {
        if (activityInsertError) throw activityInsertError;
        return { affectedRows: 1 };
      }
      if (/information_schema\.COLUMNS/i.test(sql)) return [];
      if (/^UPDATE/i.test(sql)) return { affectedRows };
      if (/^DELETE/i.test(sql)) return { affectedRows };
      if (/^INSERT/i.test(sql)) return { affectedRows: 1 };
      if (/FROM `fmb_users`/.test(sql)) return [];
      // `storedRowId` — "what spelling does the row this reference names carry".
      // Answered ahead of the catch-all below, which returns the user_templates
      // fixture for ANY select and so answered a hierarchy_nodes probe with a
      // template row: the write then bound `t-1` into `blueprint_id` and the
      // identifier floor rejected it. A double whose fallback answers every
      // question is a double that answers the wrong one.
      //
      // The id asked for is echoed back. This double has no column and therefore
      // no collation, so it cannot model a respelling and says nothing about
      // one; that half is measured against a real database in
      // tests/integration/owner-identity-real-db.test.js.
      {
        const m = sql.match(/^SELECT id FROM `([^`]+)` WHERE id = \?$/);
        if (m) return params[0] == null ? [] : [{ id: params[0] }];
      }
      if (/^SELECT/i.test(sql)) return rowToReturn ? [{ ...rowToReturn }] : [];
      return [];
    },
    release() {},
    async beginTransaction() {},
    async commit() {},
    async rollback() {},
  };
}

const poolFacade = {
  async getConnection() { return makeConn(); },
  query: async (sql, params) => makeConn().query(sql, params),
};

require.cache[dbKey] = {
  id: dbKey,
  filename: dbKey,
  loaded: true,
  exports: {
    pool: { ro: poolFacade, rw: poolFacade },
    t: (n) => `fmb_${n}`,
    getDynamicPool: async () => ({ ro: poolFacade, rw: poolFacade }),
  },
};

const schemaRouter = require('../../../../src/edge/routes/app/schema');
const { _resetGrantsTableCache } = require('../../../../src/edge/lib/delegated-grants');
const { _resetActivityTableCache } = require('../../../../src/edge/lib/template-activity');

const OWNER = { id: '8a6041f3-2968-4209-8eb5-d3469d9f11df', role: 'user', email: 'owner@example.test' };
const GRANTEE = { id: 'a2360010-b3e2-4810-844a-675323c0fe62', role: 'user', email: 'grantee@example.test' };
const ADMIN = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin', email: 'admin@example.test' };
const TEMPLATE_ID = 't-1';

let currentUser;
let server;
let baseUrl;

before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { req.user = currentUser; next(); });
  app.use('/edge/app/schema', schemaRouter);
  server = http.createServer(app);
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});

after(async () => { await new Promise((r) => server.close(r)); });

beforeEach(() => {
  queries = [];
  grantsTablePresent = true;
  activityTablePresent = true;
  activityInsertError = null;
  affectedRows = 1;
  rowToReturn = { id: TEMPLATE_ID, name: 'a record', owner_id: OWNER.id, blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26' };
  currentUser = GRANTEE;
  // The availability probe remembers a table it has seen, for the life of the
  // process. A test that changes the answer has to undo that or it is testing
  // the previous test's database.
  _resetGrantsTableCache();
  _resetActivityTableCache();
});

async function send(method, path, body) {
  const res = await fetch(`${baseUrl}${path}`, {
    method,
    headers: { 'content-type': 'application/json' },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const json = await res.json().catch(() => ({}));
  return { status: res.status, json };
}

const put = (body) => send('PUT', `/edge/app/schema/user_templates/${TEMPLATE_ID}`, body);
const statementsMatching = (re) => queries.filter((q) => re.test(q.sql));
const theUpdate = () => statementsMatching(/^UPDATE `fmb_user_templates`/)[0];

// The three arms, as the predicate builder writes them. Matched rather than
// retyped in every assertion so a change to the SQL fails in one place.
const BLUEPRINT_OWNER_ARM = /EXISTS \(SELECT 1 FROM `fmb_hierarchy_nodes` hnw WHERE hnw\.`id` = `fmb_user_templates`\.`blueprint_id` AND hnw\.`node_type` = 'blueprint' AND hnw\.`owner_id` = \?\)/;
const TEMPLATE_ARM = /EXISTS \(SELECT 1 FROM `fmb_delegated_grants` dgt WHERE dgt\.`grantee_id` = \? AND dgt\.`scope_type` = 'template' AND dgt\.`scope_id` = `fmb_user_templates`\.`id`\)/;
const BLUEPRINT_ARM = /EXISTS \(SELECT 1 FROM `fmb_delegated_grants` dgb JOIN `fmb_hierarchy_nodes` hnb ON hnb\.`id` = dgb\.`scope_id` AND hnb\.`node_type` = 'blueprint' WHERE dgb\.`grantee_id` = \? AND dgb\.`scope_type` = 'blueprint' AND hnb\.`id` = `fmb_user_templates`\.`blueprint_id`\)/;
// The gate that sits outside all three: no arm reaches a record nobody owns.
const OWNED_GATE = /\(`fmb_user_templates`\.`owner_id` IS NOT NULL AND \(EXISTS/;

describe('the update a non-owner issues', () => {
  it('asks ownership OR delegated access, inside one parenthesised group', async () => {
    await put({ name: 'edited' });
    const stmt = theUpdate();
    assert.ok(stmt, 'no UPDATE was issued');
    assert.match(stmt.sql, /WHERE id = \? AND \(`owner_id` = \? OR \(`fmb_user_templates`\.`owner_id` IS NOT NULL/);
    assert.match(stmt.sql, BLUEPRINT_OWNER_ARM);
    assert.match(stmt.sql, TEMPLATE_ARM);
    assert.match(stmt.sql, BLUEPRINT_ARM);
  });

  it('reaches no record that nobody owns, whatever the arms say', async () => {
    // The one boundary delegation did not move. An unowned record is the normal
    // case in a seeded installation; writing it has always been an
    // administrator's business, and a grant is not a way around that. The gate
    // sits OUTSIDE the arms so there is one place it can be read and one place
    // it could be lost.
    await put({ name: 'edited' });
    assert.match(theUpdate().sql, OWNED_GATE);
  });

  it('binds the caller and nothing but the caller, once per arm', async () => {
    await put({ name: 'edited' });
    const stmt = theUpdate();
    // name, id, owner, blueprint-owner arm, template grant arm, blueprint grant arm.
    assert.deepEqual(
      stmt.params,
      ['edited', TEMPLATE_ID, GRANTEE.id, GRANTEE.id, GRANTEE.id, GRANTEE.id],
    );
    assert.equal((stmt.sql.match(/\?/g) || []).length, stmt.params.length);
  });

  it('reads back the row it just wrote, by id, and asks no permission twice', async () => {
    // The write above matched under the full scope — that is what got past the
    // 404 — so the row is one this caller was just permitted to write. Asking
    // again here would ask at a moment when the answer can have changed: access
    // revoked between the two statements would make the re-read match nothing
    // and answer 200 with an empty body about a write that landed.
    await put({ name: 'edited' });
    const reread = statementsMatching(/^SELECT \* FROM `fmb_user_templates`/)[0];
    assert.ok(reread, 'no re-read was issued');
    assert.equal(reread.sql, 'SELECT * FROM `fmb_user_templates` WHERE id = ?');
    assert.deepEqual(reread.params, [TEMPLATE_ID]);
  });

  it('still answers 404 — not 403 — when nothing matched', async () => {
    // Which is the whole point of expressing this as a predicate: "not yours"
    // over an id confirms the record exists. A caller with no grant is told the
    // same thing as a caller naming an id that was never real.
    affectedRows = 0;
    const res = await put({ name: 'edited' });
    assert.equal(res.status, 404);
    assert.equal(res.json.error.code, 'NOT_FOUND');
  });
});

describe('a delegated write may not move the record out of reach', () => {
  it('pins the blueprint when the write carries it', async () => {
    // A blueprint grant reaches this record BECAUSE of its blueprint. A grantee
    // who could rewrite that column could carry the record out from under the
    // blueprint whose owner delegated it, using the access the delegation gave.
    await put({ name: 'edited', blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26' });
    const stmt = theUpdate();
    assert.match(stmt.sql, /OR \(\(`fmb_user_templates`\.`owner_id` IS NOT NULL[\s\S]*\) AND `blueprint_id` <=> \?\)\)/);
    // …and the value compared is the INCOMING one, against the stored row.
    assert.equal(stmt.params[stmt.params.length - 1], 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26');
  });

  it('adds nothing when the write does not carry the blueprint', async () => {
    await put({ name: 'edited' });
    assert.ok(!/blueprint_id` <=>/.test(theUpdate().sql));
  });

  it('leaves the owner\'s own arm unrestricted', async () => {
    // Re-filing their own record is theirs to do. The restriction sits INSIDE
    // the delegated arm, never beside it, so the owner comparison is unchanged.
    currentUser = OWNER;
    await put({ name: 'edited', blueprint_id: '07cbb7a8-0535-464f-80c7-81559ef886e3' });
    const stmt = theUpdate();
    assert.match(stmt.sql, /AND \(`owner_id` = \? OR/);
    const ownerArm = stmt.sql.slice(stmt.sql.indexOf('(`owner_id` = ?'), stmt.sql.indexOf(' OR '));
    assert.ok(!/blueprint_id/.test(ownerArm), ownerArm);
  });

  it('is gone with the rest of the arm on an administrator\'s write', async () => {
    currentUser = ADMIN;
    await put({ name: 'edited', blueprint_id: '07cbb7a8-0535-464f-80c7-81559ef886e3' });
    assert.ok(!/blueprint_id` <=>/.test(theUpdate().sql));
  });
});

describe('the flow cache is not part of what a record update may write', () => {
  it('drops the three columns from the statement, for a delegated writer', async () => {
    // Clearing the run marker turns the OWNER's next dispatch into a create,
    // and a dispatch cannot be taken back. The endpoint that clears them
    // carries the same boundary dispatch does and writes an audit row; the
    // generic update carried neither.
    await put({
      name: 'edited', flow_last_run_id: null, flow_link: null, flow_external_id: null,
    });
    const stmt = theUpdate();
    assert.ok(
      !/flow_last_run_id|flow_link|flow_external_id/.test(stmt.sql),
      `a record update reached the flow cache: ${stmt.sql}`,
    );
    assert.match(stmt.sql, /SET `name` = \?/);
  });

  it('drops them for the owner too, and for an administrator', async () => {
    // Not a restriction aimed at delegation: no role has a reason to set these
    // by hand, and an owner who wants them cleared has an endpoint that says so
    // and records that they did.
    for (const who of [OWNER, ADMIN]) {
      queries = [];
      currentUser = who;
      await put({ name: 'edited', flow_last_run_id: 'da92ef42-3a6f-4dae-82a8-9f3cad1c941e' });
      assert.ok(
        !/flow_last_run_id/.test(theUpdate().sql),
        `${who.role} rewrote the flow cache through the generic update`,
      );
    }
  });
});

describe('where the grant deliberately does not reach', () => {
  it('a delete carries no grant arm — removing a record is not delegated', async () => {
    await send('DELETE', `/edge/app/schema/user_templates/${TEMPLATE_ID}`);
    const del = statementsMatching(/^DELETE FROM `fmb_user_templates`/)[0];
    assert.ok(del, 'no DELETE was issued');
    assert.equal(del.sql, 'DELETE FROM `fmb_user_templates` WHERE id = ? AND `owner_id` = ?');
    assert.deepEqual(del.params, [TEMPLATE_ID, GRANTEE.id]);
  });

  it('a create carries no grant arm — a new record is owned by whoever made it', async () => {
    await send('POST', '/edge/app/schema/user_templates', { name: 'new' });
    const insert = statementsMatching(/^INSERT INTO `fmb_user_templates`/)[0];
    assert.ok(insert, 'no INSERT was issued');
    assert.ok(!/delegated_grants/.test(insert.sql));
    assert.ok(insert.params.includes(GRANTEE.id), 'the creator was not stamped as owner');
  });

  it('an administrator\'s update is the statement it always was', async () => {
    currentUser = ADMIN;
    await put({ name: 'edited' });
    const stmt = theUpdate();
    assert.equal(stmt.sql, 'UPDATE `fmb_user_templates` SET `name` = ? WHERE id = ?');
    assert.deepEqual(stmt.params, ['edited', TEMPLATE_ID]);
  });

  it('no other mount gains the arm', async () => {
    // The option is opt-in and applies one table's grant vocabulary. A sibling
    // mount picking it up would be delegating rows nobody delegated.
    currentUser = { id: '074324b8-a957-403e-8bd0-fc6a4dcf3a6b', role: 'editor', email: 'editor@example.test' };
    await send('PUT', '/edge/app/schema/blueprint_sections/s-1', { section_key: 'renamed' });
    for (const q of queries) {
      assert.ok(!/delegated_grants/.test(q.sql), `a sibling mount reached the grants table: ${q.sql}`);
    }
  });

  it('a linked blueprint stays read-only for a grantee, as it is for everyone', async () => {
    // This database HAS grants (the fixture leaves the table present), and the
    // answer is the same as it would be without them: the lock lives on the
    // schema tables, which carry no grant arm at all, so a grant cannot override
    // it because it never reaches the statement that would have to be widened.
    // Asserted rather than assumed, because "the option was not passed" is
    // exactly the kind of thing a later refactor changes by accident. The lock
    // holds for every role including an administrator, and delegation does not
    // add an exception to a rule that has none.
    currentUser = { id: '074324b8-a957-403e-8bd0-fc6a4dcf3a6b', role: 'editor', email: 'editor@example.test' };
    rowToReturn = { id: '2ce8ba8e-83f5-41ee-8246-a2265095b549', blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', linked_blueprint_id: 'e9dc633a-d9e5-44b6-8baa-1fa26eb88ab8' };
    const res = await send('PUT', '/edge/app/schema/blueprint_fields/2ce8ba8e-83f5-41ee-8246-a2265095b549', { field_label: 'edited' });
    assert.equal(res.status, 409);
    assert.equal(res.json.error.code, 'LINKED_BLUEPRINT_READONLY');
    for (const q of queries) {
      assert.ok(!/delegated_grants/.test(q.sql), `the locked path consulted grants: ${q.sql}`);
    }
  });
});

describe('a database with no grants table', () => {
  it('drops the two arms that read it, and keeps the one that does not', async () => {
    // The CREATE is severity 'warning': an operator account without DDL
    // privilege has no grants table, and every template update on that database
    // must keep working rather than failing on a missing table. What must NOT
    // happen is losing the blueprint owner's own reach with it — that arm reads
    // the hierarchy, which every database has, and it is a right the user
    // granted to blueprint owners, not an optional extra that ships with a
    // table.
    grantsTablePresent = false;
    currentUser = OWNER;
    const res = await put({ name: 'edited' });
    assert.equal(res.status, 200);
    const stmt = theUpdate();
    assert.ok(!/delegated_grants/.test(stmt.sql), `a missing table was named: ${stmt.sql}`);
    assert.match(stmt.sql, BLUEPRINT_OWNER_ARM);
    assert.deepEqual(stmt.params, ['edited', TEMPLATE_ID, OWNER.id, OWNER.id]);
  });

  it('re-probes rather than remembering the absence', async () => {
    // The asymmetry is deliberate: remembering "absent" would keep grants dead
    // for the life of the process even after a boot migration created the table.
    grantsTablePresent = false;
    await put({ name: 'first' });
    grantsTablePresent = true;
    queries = [];
    await put({ name: 'second' });
    assert.match(theUpdate().sql, TEMPLATE_ARM);
  });
});

describe('the trail the update leaves', () => {
  it('records who changed the record, and which columns — never their values', async () => {
    await put({ name: 'edited', payload: { secret: 'value' } });
    const insert = queries.find((q) => /^INSERT INTO `fmb_template_activity`/.test(q.sql));
    assert.ok(insert, 'no trail row was written for a successful update');
    const [, templateId, actorId, action, metadata] = insert.params;
    assert.equal(templateId, TEMPLATE_ID);
    assert.equal(actorId, GRANTEE.id);
    assert.equal(action, 'content.edited');
    const doc = JSON.parse(metadata);
    assert.deepEqual(doc.columns.sort(), ['name', 'payload']);
    assert.ok(!JSON.stringify(doc).includes('value'), 'a written value reached the trail');
  });

  it('records nothing when the update matched nothing', async () => {
    // A refused write is not an edit, and a trail that recorded it would report
    // work that never happened.
    affectedRows = 0;
    await put({ name: 'edited' });
    assert.equal(queries.filter((q) => /^INSERT INTO `fmb_template_activity`/.test(q.sql)).length, 0);
  });

  it('a failing trail write does not fail the update it was recording', async () => {
    // The property the whole design rests on. The record was saved; the trail
    // is bookkeeping, and bookkeeping must not be able to undo it.
    activityInsertError = Object.assign(new Error('trail gone'), { errno: 1146 });
    const res = await put({ name: 'edited' });
    assert.equal(res.status, 200);
    assert.equal(res.json.data.id, TEMPLATE_ID);
  });

  it('leaves no trail on a mount that did not opt in', async () => {
    currentUser = { id: '074324b8-a957-403e-8bd0-fc6a4dcf3a6b', role: 'editor', email: 'editor@example.test' };
    await send('PUT', '/edge/app/schema/blueprint_sections/s-1', { section_key: 'renamed' });
    assert.equal(queries.filter((q) => /`fmb_template_activity`/.test(q.sql)).length, 0);
  });
});
