'use strict';

/**
 * schema-guard-domain-parity.test.js — the declared domain of a guarded column,
 * checked against the column.
 *
 * Two hazards, both of which have shipped here before, and neither of which any
 * amount of mocked-driver testing can see:
 *
 *  1. A ROLE-SCOPED BLOCKLIST WITH NO DOMAIN. `valueGuards.rejectFor` decides
 *     with a JavaScript comparison against a list of literals. The columns it
 *     guards are database ENUMs, whose equality folds case and a trailing space
 *     and additionally accepts an INTEGER as a 1-based member index. A blocklist
 *     is therefore only sound on a value already known to be IDENTICALLY one of
 *     the column's members — which is what an `enumColumns` domain establishes.
 *     Without one, every spelling outside the list walks straight past it into a
 *     statement that stores the value the list denies.
 *
 *  2. A DECLARED DOMAIN THAT DRIFTED FROM THE DDL. `enumColumns` lists are
 *     literals at their mounts. `table-ddls.js` is the single source of truth for
 *     the schema, so the first time an ENUM is narrowed or widened without the
 *     mount following, the gate is either refusing a member the column accepts or
 *     admitting a value it does not have — silently, in both directions.
 *
 * The census here is DERIVED, not listed: `createCrudRoutes` is patched to record
 * every mount, the modules that call it are found by scanning the source tree, and
 * the completeness of both is asserted — a hand-written list of mounts is the same
 * class of second source of truth this file exists to catch. So is a hand-written
 * count of how many comparisons ought to happen: every declared domain is either
 * compared, exempted because the column is not an ENUM, or a failure, and the
 * three are asserted to add up to the census.
 *
 * The DDL side is read a SECOND TIME here, by a different parser, because two of
 * the declared domains are themselves `enumMembersFor(...)` calls — checking those
 * with the same function compares a call with itself and holds no matter how
 * wrong the function is.
 *
 * No database. Both facts are statements about code and DDL text.
 */
const { describe, it, before } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const SRC = path.resolve(__dirname, '../../../../src');

// The route modules load `../../db` at require time; stub it so the census is
// side-effect-free (no pool, no connection).
const dbKey = require.resolve(path.join(SRC, 'edge/db'));
const stubPool = {
  ro: { getConnection: async () => { throw new Error('census: no database'); } },
  rw: { getConnection: async () => { throw new Error('census: no database'); } },
};
require.cache[dbKey] = {
  id: dbKey,
  filename: dbKey,
  loaded: true,
  exports: { pool: stubPool, t: (n) => `fmb_${n}`, getDynamicPool: async () => stubPool },
};

const factoryPath = require.resolve(path.join(SRC, 'edge/routes/app/schema/crud-factory'));
const factory = require(factoryPath);
const { enumMembersFor, ddlFragmentFor } = require(path.join(SRC, 'edge/lib/schema-manifest'));

// ── An independent reading of the DDL text ──────────────────────────────────
//
// Deliberately NOT enumMembersFor. Two of the mounts' declared domains are
// already `enumMembersFor(...)` calls, so checking them with the same function
// compares a call with itself: it holds however wrong that function is, and a
// domain that drifted is unprovable for the very mount this file is named
// around. The comparison needs a second witness, so the members are read here a
// second time, differently — a quote-aware scan rather than a regex bounded at
// the first `)` plus a split on every `,`.
//
// It is also the STRICTER reading on purpose. Where the production reader gives
// up and returns null (a member containing `)` or `,`), this one reads the
// member correctly — so the two disagreeing is what makes "the gate has no
// domain for this column" visible instead of silent.

// The type token is the first word after the (optionally backtick-quoted)
// column name. Read this way rather than from the parsed type so a member
// containing a parenthesis cannot make an ENUM column read as something else.
function typeTokenOf(fragment) {
  const m = fragment.match(/^`?[A-Za-z_][A-Za-z0-9_]*`?\s+([A-Za-z]+)/);
  return m ? m[1].toUpperCase() : null;
}

// Members of `ENUM(...)` from a column-definition line, in DDL order. Throws
// (never returns a partial or a guess) when the text is not a list of quoted
// literals — a domain read from text this function could not follow would be
// exactly the silent divergence this file exists to catch.
function enumMembersFromDdlText(fragment) {
  const open = fragment.match(/\bENUM\s*\(/i);
  if (!open) throw new Error(`no ENUM(...) in the column definition: ${fragment}`);
  let i = open.index + open[0].length;
  const members = [];
  let expecting = 'member';
  while (i < fragment.length) {
    const ch = fragment[i];
    if (ch === ' ' || ch === '\t') { i += 1; continue; }
    if (ch === ')') {
      if (expecting === 'member' && members.length > 0) {
        throw new Error(`trailing comma in ENUM(...): ${fragment}`);
      }
      return members;
    }
    if (expecting === 'separator') {
      if (ch !== ',') throw new Error(`expected ',' or ')' at offset ${i} in: ${fragment}`);
      expecting = 'member';
      i += 1;
      continue;
    }
    if (ch !== "'") throw new Error(`ENUM member is not a quoted literal at offset ${i} in: ${fragment}`);
    i += 1;
    let value = '';
    for (;;) {
      if (i >= fragment.length) throw new Error(`unterminated ENUM member in: ${fragment}`);
      if (fragment[i] === "'") {
        if (fragment[i + 1] === "'") { value += "'"; i += 2; continue; } // '' escape
        i += 1;
        break;
      }
      value += fragment[i];
      i += 1;
    }
    members.push(value);
    expecting = 'separator';
  }
  throw new Error(`unterminated ENUM(...) in: ${fragment}`);
}

// Every .js under src/ whose text calls the factory. Scanned rather than listed:
// a new mounting module added to a list by hand is a module the next author
// forgets, and the census silently stops covering it.
function filesCallingFactory(dir, out = []) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      if (entry.name === 'node_modules' || entry.name === '__tests__') continue;
      filesCallingFactory(full, out);
    } else if (entry.isFile() && entry.name.endsWith('.js')) {
      if (fs.readFileSync(full, 'utf-8').includes('createCrudRoutes(')) out.push(full);
    }
  }
  return out;
}

const mounts = [];

before(() => {
  const original = factory.createCrudRoutes;
  factory.createCrudRoutes = function patched(logicalName, opts = {}) {
    mounts.push({ logicalName, opts });
    return original.call(this, logicalName, opts);
  };

  const callers = filesCallingFactory(SRC);
  for (const file of callers) require(file);
  // The capacity children / local-catalogue families mount inside a function the
  // aggregator calls, so requiring their own module registers nothing. Loading
  // the aggregator is what puts those 12 mounts in the census.
  require(path.join(SRC, 'edge/routes/app/capacity/index'));

  factory.createCrudRoutes = original;

  // A module that calls the factory but never got loaded would drop its mounts
  // from the census, and every assertion below would pass by not looking.
  for (const file of callers) {
    assert.ok(
      require.cache[require.resolve(file)],
      `${path.relative(SRC, file)} calls createCrudRoutes but was not loaded into the census`,
    );
  }
});

describe('guarded-column domains', () => {
  it('the census actually found the mounts (an empty one would pass everything below)', () => {
    assert.ok(mounts.length >= 20, `only ${mounts.length} mounts in the census`);
    const guarded = mounts.filter((m) => m.opts.valueGuards || m.opts.enumColumns);
    assert.ok(guarded.length >= 6, `only ${guarded.length} guarded mounts in the census`);
    // The one role-scoped blocklist in the codebase, named so this file fails
    // rather than thins out if the mount it was written for disappears.
    assert.ok(
      mounts.some((m) => m.logicalName === 'hierarchy_nodes' && m.opts.valueGuards?.node_type?.rejectFor),
      'hierarchy_nodes no longer declares a role-scoped blocklist on node_type',
    );
  });

  it('every role-scoped blocklist names a column with a declared domain', () => {
    // HAZARD 1. A blocklist compared with JavaScript equality cannot judge a
    // value the database folds into one of its entries, so it is only sound
    // behind a domain that has already refused everything not identically a
    // member. The factory refuses to mount one without a domain (asserted
    // below); this says the same thing about every mount that exists today, so
    // removing that constructor check does not go unnoticed either.
    for (const { logicalName, opts } of mounts) {
      if (!opts.valueGuards) continue;
      for (const [col, rules] of Object.entries(opts.valueGuards)) {
        if (!rules || !rules.rejectFor) continue;
        const domain = opts.enumColumns && opts.enumColumns[col];
        assert.ok(
          Array.isArray(domain) && domain.length > 0,
          `${logicalName}.${col} declares a role-scoped blocklist with no enumColumns domain — `
          + 'every spelling the database folds into a forbidden value would pass it',
        );
      }
    }
  });

  it('the second reading of the DDL is worth having (it reads what the first one refuses to)', () => {
    // The witness needs its own witness. A scanner that returned [] for
    // everything, or read only what the production reader already reads, would
    // make the parity comparison below agree with itself again — which is the
    // defect this file is repairing, reintroduced one level down.
    assert.deepEqual(
      enumMembersFromDdlText("node_type ENUM('category','release') NOT NULL"),
      ['category', 'release'],
    );
    // The two shapes the production reader gives up on, read correctly here —
    // this is what makes its null visible as a disagreement rather than a skip.
    assert.deepEqual(
      enumMembersFromDdlText("vm_type ENUM('db_host','ap_host (spare)') NOT NULL"),
      ['db_host', 'ap_host (spare)'],
    );
    assert.deepEqual(
      enumMembersFromDdlText("k ENUM('a,b','c') NOT NULL"),
      ['a,b', 'c'],
    );
    assert.deepEqual(enumMembersFromDdlText("k ENUM('it''s') NOT NULL"), ["it's"]);
    assert.deepEqual(enumMembersFromDdlText("k ENUM('') NOT NULL"), ['']);
    assert.deepEqual(enumMembersFromDdlText('k enum( \'a\' , \'b\' )'), ['a', 'b']);
    // And it refuses rather than guesses.
    assert.throws(() => enumMembersFromDdlText('k VARCHAR(255) NULL'), /no ENUM/);
    assert.throws(() => enumMembersFromDdlText('k ENUM(a,b) NOT NULL'), /not a quoted literal/);
    assert.throws(() => enumMembersFromDdlText('k ENUM("a","b") NOT NULL'), /not a quoted literal/);
    assert.throws(() => enumMembersFromDdlText("k ENUM('a','b' NOT NULL"), /expected/);
    assert.throws(() => enumMembersFromDdlText("k ENUM('a',) NOT NULL"), /trailing comma/);
    assert.throws(() => enumMembersFromDdlText("k ENUM('a"), /unterminated/);
  });

  it('every declared enum domain is exactly the members its column is declared with', () => {
    // HAZARD 2. Only columns the DDL declares as an ENUM have members to match —
    // the rule is derived from the column's own type rather than from a
    // hand-kept list of exemptions (blueprint_sections.matrix_copy is a VARCHAR
    // whose small value set is an application convention, so no ENUM membership
    // exists to compare).
    //
    // NOTHING IS SKIPPED SILENTLY. An earlier form of this test moved on when
    // the production reader returned null, so a member the reader could not
    // parse (one containing `)` or `,`) took its column out of the comparison
    // and left the mount free to declare anything at all — demonstrated by
    // making both changes at once and watching this file stay green. Here the
    // three outcomes are: compared, exempt because the column is not an ENUM, or
    // a FAILURE. There is no fourth.
    const compared = [];
    const exempt = [];
    for (const { logicalName, opts } of mounts) {
      if (!opts.enumColumns) continue;
      for (const [col, declared] of Object.entries(opts.enumColumns)) {
        const where = `${logicalName}.${col}`;
        const fragment = ddlFragmentFor(logicalName, col);
        assert.ok(
          fragment,
          `${where} declares a domain but table-ddls.js defines no such column — `
          + 'the gate is judging writes against a column shape that does not exist',
        );
        if (typeTokenOf(fragment) !== 'ENUM') {
          exempt.push(`${where} (${typeTokenOf(fragment)})`);
          continue;
        }
        let fromText;
        try {
          fromText = enumMembersFromDdlText(fragment);
        } catch (err) {
          assert.fail(`${where}: the DDL declares an ENUM this test cannot read — ${err.message}`);
        }
        assert.ok(fromText.length > 0, `${where}: the DDL declares an ENUM with no members`);
        // The production reader must reach the same answer. When it cannot read
        // a member it returns null, and null here means the running gate has NO
        // domain for a column something declares one for — the mount would fail
        // to build, or judge writes against a domain nobody checked. Either way
        // it is a failure and not an exemption.
        assert.deepEqual(
          enumMembersFor(logicalName, col), fromText,
          `${where}: enumMembersFor returned ${JSON.stringify(enumMembersFor(logicalName, col))} `
          + `for a column whose DDL declares ENUM(${fromText.map((m) => `'${m}'`).join(', ')}) — `
          + 'the domain the gate actually uses is not the one the column has',
        );
        assert.deepEqual(
          declared, fromText,
          `${where} declares [${declared.join(', ')}] but the DDL declares `
          + `ENUM(${fromText.map((m) => `'${m}'`).join(', ')})`,
        );
        compared.push(where);
      }
    }

    // The expected count is DERIVED FROM THE CENSUS, not written down. The
    // number this replaces was `compared >= 5` against a measured 6 — one spare
    // unit, which is all it takes for a column to leave the comparison without
    // anything saying so.
    const declaredTotal = mounts.reduce(
      (n, m) => n + (m.opts.enumColumns ? Object.keys(m.opts.enumColumns).length : 0), 0,
    );
    assert.equal(
      compared.length + exempt.length, declaredTotal,
      `${declaredTotal} declared domains exist but only ${compared.length} were compared and `
      + `${exempt.length} exempted — a column left the comparison without failing`,
    );

    // And the subset that MUST be compared, also derived: a role-scoped
    // blocklist is only sound on a value already known to be identically a
    // member, so a blocklisted column whose domain was never checked against the
    // DDL is the hazard this file is named around, not an exemption.
    for (const { logicalName, opts } of mounts) {
      if (!opts.valueGuards) continue;
      for (const [col, rules] of Object.entries(opts.valueGuards)) {
        if (!rules || !rules.rejectFor) continue;
        assert.ok(
          compared.includes(`${logicalName}.${col}`),
          `${logicalName}.${col} is decided by a role-scoped blocklist but its declared domain `
          + `was never compared against the DDL (exempt: ${exempt.join(', ') || 'none'})`,
        );
      }
    }
  });

  it('the ENUM members are read from the DDL, not from a copy of it', () => {
    // The reader of enumMembersFor: it must return the real member list for a
    // known ENUM, and null (rather than a guess) for a column that is not one.
    assert.deepEqual(
      enumMembersFor('hierarchy_nodes', 'node_type'),
      ['category', 'release', 'blueprint', 'variant'],
    );
    assert.equal(enumMembersFor('blueprint_sections', 'matrix_copy'), null, 'a VARCHAR read as an ENUM');
    assert.equal(enumMembersFor('hierarchy_nodes', 'name'), null);
    assert.equal(enumMembersFor('no_such_table', 'no_such_column'), null);
  });

  it('the factory refuses to mount a role-scoped blocklist with no domain', () => {
    // The mechanical half: the rule above cannot be reintroduced by a new mount,
    // because building one throws before it can serve a request.
    assert.throws(
      () => factory.createCrudRoutes('hierarchy_nodes', {
        valueGuards: { node_type: { rejectFor: { editor: ['category'] } } },
      }),
      /rejectFor/,
      'a blocklist with no declared domain was accepted',
    );
    // ...and an empty domain is not a domain.
    assert.throws(
      () => factory.createCrudRoutes('hierarchy_nodes', {
        valueGuards: { node_type: { rejectFor: { editor: ['category'] } } },
        enumColumns: { node_type: [] },
      }),
      /rejectFor/,
    );
    // The same mount WITH a domain builds, so the check is about the domain and
    // not about rejectFor being unusable.
    assert.doesNotThrow(() => factory.createCrudRoutes('hierarchy_nodes', {
      valueGuards: { node_type: { rejectFor: { editor: ['category'] } } },
      enumColumns: { node_type: ['category', 'release', 'blueprint', 'variant'] },
    }));
    // A guard that is not a role-scoped blocklist needs no domain — the numeric
    // guard checks the value's type itself, and a mount declaring one must keep
    // building.
    assert.doesNotThrow(() => factory.createCrudRoutes('cap_databases', {
      valueGuards: { primary_sga_gb: { numeric: { min: 0, allowNull: true, integer: true } } },
    }));
  });

  it('the factory refuses to mount a domain on a column whose nullability the DDL does not state', () => {
    // Whether a written null is a violation is read from the DDL, and the case
    // that has no answer must be LOUD. A column table-ddls.js does not define
    // has no nullability to read, so the mount does not build — the same
    // require-time refusal a blocklist with no domain gets, rather than a guess
    // that admits nulls a NOT NULL column cannot store (a 500 with a driver
    // stack per request) or refuses nulls a nullable column accepts.
    assert.throws(
      () => factory.createCrudRoutes('hierarchy_nodes', {
        enumColumns: { no_such_column: ['a', 'b'] },
      }),
      /does not say/,
      'a domain was accepted for a column the DDL does not define',
    );
    // And the nullable case is not collateral damage: a declared domain on a
    // column the DDL says accepts NULL builds, and keeps taking nulls.
    assert.doesNotThrow(() => factory.createCrudRoutes('blueprint_sections', {
      enumColumns: { matrix_copy: ['', 'enabled', 'disabled'] },
    }));
  });
});
