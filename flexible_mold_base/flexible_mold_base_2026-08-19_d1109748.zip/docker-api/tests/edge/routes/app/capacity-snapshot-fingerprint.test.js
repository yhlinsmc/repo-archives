/**
 * capacity-snapshot-fingerprint.test.js — the equality the destructive restore
 * path leans on.
 *
 * The fingerprint decides whether an in-place switch proceeds or is refused, so
 * both directions are load-bearing and they fail differently. A fingerprint that
 * misses a real change lets a concurrent edit be deleted with no copy anywhere;
 * a fingerprint that drifts on representation alone refuses every switch, which
 * would make the feature unusable and would be blamed on the wrong thing.
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');

const {
  fingerprintScenarioRows, scenarioOwnedRows, canonicalJson,
} = require('../../../../src/edge/routes/app/capacity/snapshot-fingerprint');

const KEYS = ['sites', 'vms', 'rules', 'settings'];

const live = () => ({
  sites: [{ id: 's-1', scenario_id: 'scn-1', name: 'DC-1' }],
  vms: [
    { id: 'vm-1', scenario_id: 'scn-1', name: 'A', cpu: 4 },
    { id: 'vm-2', scenario_id: 'scn-1', name: 'B', cpu: 8 },
  ],
  rules: [],
  settings: [{ id: 'set-1', scenario_id: 'scn-1', util_amber_pct: 80 }],
});

/** What the same rows look like after a freeze: JSON.stringify into the snapshot
 *  column and JSON.parse back out on the way to the comparison. */
const frozen = (tables) => JSON.parse(JSON.stringify(tables));

const fp = (tables) => fingerprintScenarioRows(tables, KEYS);

describe('snapshot fingerprint — equal state fingerprints equal', () => {
  it('a freeze round-trip of the same rows matches the live rows', () => {
    assert.equal(fp(frozen(live())), fp(live()));
  });

  it('row order is not a change (the snapshot reads carry no ORDER BY)', () => {
    const reordered = live();
    reordered.vms = [reordered.vms[1], reordered.vms[0]];
    assert.equal(fp(reordered), fp(live()));
  });

  it('key order within a row is not a change', () => {
    const rekeyed = live();
    rekeyed.vms = rekeyed.vms.map((r) => ({ cpu: r.cpu, name: r.name, scenario_id: r.scenario_id, id: r.id }));
    assert.equal(fp(rekeyed), fp(live()));
  });

  it('a missing table key and an empty table are the same answer', () => {
    const withoutRules = live();
    delete withoutRules.rules;
    assert.equal(fp(withoutRules), fp(live()));
  });

  it('a Date column matches the ISO string it freezes as', () => {
    const driverSide = { vms: [{ id: 'vm-1', scenario_id: 'scn-1', updated_at: new Date('2026-07-27T10:00:00.000Z') }] };
    assert.equal(fp(driverSide), fp(frozen(driverSide)));
  });

  it('a nested JSON column matches regardless of its own key order', () => {
    const a = { sites: [{ id: 's-1', scenario_id: 'scn-1', metadata: { tier: 1, region: 'eu' } }] };
    const b = { sites: [{ id: 's-1', scenario_id: 'scn-1', metadata: { region: 'eu', tier: 1 } }] };
    assert.equal(fp(a), fp(b));
  });

  it('a global-layer edit is not a scenario change', () => {
    // The restore deletes `scenario_id = ?` rows only, so a global rule or the
    // global settings singleton moving underneath is not work this switch would
    // destroy.
    const withGlobals = live();
    withGlobals.rules = [{ id: 'rule-global', scenario_id: null, name: 'Edited since' }];
    withGlobals.settings = [...withGlobals.settings, { id: 'set-global', scenario_id: null, util_amber_pct: 70 }];
    assert.equal(fp(withGlobals), fp(live()));
  });
});

describe('snapshot fingerprint — a real change is a change', () => {
  it('an edited value', () => {
    const changed = live();
    changed.vms[0].cpu = 6;
    assert.notEqual(fp(changed), fp(live()));
  });

  it('an added row', () => {
    const changed = live();
    changed.vms.push({ id: 'vm-3', scenario_id: 'scn-1', name: 'C', cpu: 2 });
    assert.notEqual(fp(changed), fp(live()));
  });

  it('a deleted row', () => {
    const changed = live();
    changed.vms = [changed.vms[0]];
    assert.notEqual(fp(changed), fp(live()));
  });

  it('a row that moved from the scenario to the global layer', () => {
    const changed = live();
    changed.settings = [{ ...changed.settings[0], scenario_id: null }];
    assert.notEqual(fp(changed), fp(live()));
  });

  it('a table outside the compared key list is invisible', () => {
    // The key list is the caller's contract: it must be the full snapshot key
    // set, or a change in an omitted table waves the switch through.
    const changed = live();
    changed.waivers = [{ id: 'w-1', scenario_id: 'scn-1' }];
    assert.equal(fp(changed), fp(live()));
    assert.notEqual(
      fingerprintScenarioRows(changed, [...KEYS, 'waivers']),
      fingerprintScenarioRows(live(), [...KEYS, 'waivers']),
    );
  });
});

describe('snapshot fingerprint — degenerate input never throws', () => {
  it('null, a string and an array all fingerprint as "no rows"', () => {
    const empty = fp({});
    assert.equal(fp(null), empty);
    assert.equal(fp('not a document'), empty);
    assert.equal(fp([]), empty);
  });

  it('a table entry that is not a row list contributes nothing', () => {
    assert.equal(fp({ vms: { id: 'vm-1' }, sites: null }), fp({}));
  });

  it('scenarioOwnedRows drops non-rows as well as global rows', () => {
    assert.deepEqual(
      scenarioOwnedRows([null, 'x', ['y'], { id: 'g', scenario_id: null }, { id: 'k', scenario_id: 'scn-1' }]),
      [{ id: 'k', scenario_id: 'scn-1' }],
    );
  });

  it('canonicalJson sorts keys at every depth', () => {
    assert.equal(canonicalJson({ b: 1, a: { d: 2, c: [3, { f: 4, e: 5 }] } }), '{"a":{"c":[3,{"e":5,"f":4}],"d":2},"b":1}');
  });
});
