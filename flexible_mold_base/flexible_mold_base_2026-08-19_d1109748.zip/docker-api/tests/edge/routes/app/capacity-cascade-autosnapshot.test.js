'use strict';

/**
 * capacity-cascade-autosnapshot.test.js — a cascade that removes at least
 * AUTO_SNAPSHOT_DELETE_THRESHOLD rows freezes a restorable version first, in the
 * SAME transaction (spec §4 "Auto-snapshot"). Real-DB, because the claim is about
 * a row that must exist after the delete commits and must restore the pre-delete
 * state — a stubbed driver proves neither.
 *
 * Skips with a stated reason when no database is reachable; fails instead of
 * skipping under REQUIRE_INTEGRATION_DB=1.
 */
const {
  test, describe, before, after, beforeEach,
} = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const net = require('node:net');
const http = require('node:http');
const express = require('express');
const mariadb = require('mariadb');

const TEST_PREFIX = 'cas_';
const tbl = (name) => `${TEST_PREFIX}${name}`;

let pool = null;
const lease = () => pool.getConnection();
const handle = () => ({ getConnection: lease, query: (sql, params) => pool.query(sql, params) });

const dbKey = require.resolve('../../../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey,
  filename: dbKey,
  loaded: true,
  exports: {
    pool: { ro: handle(), rw: handle() },
    t: tbl,
    getDynamicPool: async () => ({ ro: handle(), rw: handle() }),
  },
};

const { buildEngineTableDDLs, buildInfraTableDDLs } = require('../../../../src/table-ddls');
const { AUTO_SNAPSHOT_DELETE_THRESHOLD } = require('../../../../src/edge/routes/app/capacity/_shared');
const capacityRouter = require('../../../../src/edge/routes/app/capacity');

function parseEnvFile(filePath) {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    const out = {};
    for (const line of content.split('\n')) {
      const m = line.match(/^\s*([A-Z_][A-Z0-9_]*)\s*=\s*(.*)\s*$/);
      if (!m) continue;
      let value = m[2];
      if ((value.startsWith('"') && value.endsWith('"'))
        || (value.startsWith("'") && value.endsWith("'"))) value = value.slice(1, -1);
      out[m[1]] = value;
    }
    return out;
  } catch {
    return null;
  }
}

function probePort(host, port, timeoutMs = 2000) {
  return new Promise((resolve) => {
    const socket = new net.Socket();
    let done = false;
    const finish = (ok) => { if (done) return; done = true; socket.destroy(); resolve(ok); };
    socket.setTimeout(timeoutMs);
    socket.once('connect', () => finish(true));
    socket.once('timeout', () => finish(false));
    socket.once('error', () => finish(false));
    socket.connect(port, host);
  });
}

async function resolveMariaDbConfig() {
  if (process.env.DB_TEST_HOST && process.env.DB_TEST_ROOT_PASSWORD) {
    return {
      host: process.env.DB_TEST_HOST,
      port: parseInt(process.env.DB_TEST_PORT || '3306', 10),
      user: 'root',
      password: process.env.DB_TEST_ROOT_PASSWORD,
    };
  }
  const envPath = path.resolve(__dirname, '../../../../../.devcontainer/.env');
  const env = parseEnvFile(envPath);
  if (!env || !env.DB_ROOT_PASSWORD) return null;
  const port = parseInt(env.DB_PORT || '3306', 10);
  for (const host of ['127.0.0.1', 'mariadb', 'localhost']) {
    if (await probePort(host, port, 2000)) return { host, port, user: 'root', password: env.DB_ROOT_PASSWORD };
  }
  return null;
}

const ADMIN = { id: 'aa11bb22-cc33-4d44-8e55-ff6677889900', role: 'admin' };
const SCENARIO_ID = '11112222-3333-4444-8555-666677778888';

let dbReady = false;
let skipReason = null;
let testDbName = null;
let server = null;
let baseUrl = null;
let currentUser = ADMIN;

before(async () => {
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) {
    skipReason = 'no MariaDB reachable via .devcontainer/.env or env vars';
    if (process.env.REQUIRE_INTEGRATION_DB === '1') throw new Error(`REQUIRE_INTEGRATION_DB=1 set but ${skipReason}.`);
    return;
  }
  testDbName = `cap_autosnap_test_${process.pid}_${Date.now()}`;
  let admin = null;
  try {
    admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`CREATE DATABASE \`${testDbName}\``);
    await admin.query(`USE \`${testDbName}\``);
    for (const sql of [...buildInfraTableDDLs(tbl), ...buildEngineTableDDLs(tbl)]) await admin.query(sql);
    await admin.end();
    admin = null;
    pool = mariadb.createPool({
      ...dbConfig, database: testDbName, connectionLimit: 6, connectTimeout: 5000,
    });
    const app = express();
    app.use(express.json());
    app.use((req, _res, next) => { req.user = currentUser; next(); });
    app.use('/edge/app/capacity', capacityRouter);
    server = http.createServer(app);
    await new Promise((r) => server.listen(0, r));
    baseUrl = `http://127.0.0.1:${server.address().port}`;
    dbReady = true;
  } catch (err) {
    skipReason = `setup failed: ${err.message}`;
    if (admin) { try { await admin.end(); } catch { /* best effort */ } }
    if (process.env.REQUIRE_INTEGRATION_DB === '1') throw err;
  }
});

after(async () => {
  if (server) { try { server.close(); } catch { /* best effort */ } }
  if (pool) { try { await pool.end(); } catch { /* best effort */ } }
  if (!testDbName) return;
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) return;
  try {
    const admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`DROP DATABASE IF EXISTS \`${testDbName}\``);
    await admin.end();
  } catch { /* best effort */ }
});

async function call(user, method, url, body) {
  currentUser = user;
  const res = await fetch(`${baseUrl}${url}`, {
    method,
    headers: { 'content-type': 'application/json' },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const text = await res.text();
  let parsed = null;
  try { parsed = JSON.parse(text); } catch { parsed = { raw: text }; }
  return { status: res.status, body: parsed };
}

const q = (sql, params) => pool.query(sql, params);
const rowCount = async (table, where, params) => Number(
  (await pool.query(`SELECT COUNT(*) AS n FROM \`${tbl(table)}\` ${where || ''}`, params))[0].n,
);

const CAPACITY_TABLES = [
  'cap_waivers', 'cap_rules', 'cap_custom_group_members', 'cap_custom_groups',
  'cap_db_instances', 'cap_vms', 'cap_databases', 'cap_hypervisors', 'cap_sites',
  'cap_versions', 'cap_bundle_items', 'cap_bundles', 'cap_field_defs',
  'cap_vm_profiles', 'cap_disk_combos', 'cap_teams', 'cap_hardware_specs',
  'cap_settings', 'cap_scenarios',
];

const guard = (t) => {
  if (dbReady) return false;
  t.skip(skipReason || 'database not ready');
  return true;
};

beforeEach(async () => {
  if (!dbReady) return;
  for (const name of [...CAPACITY_TABLES, 'feature_audit', 'users']) await q(`DELETE FROM \`${tbl(name)}\``);
  await q(`INSERT INTO \`${tbl('users')}\` (id, email, role, banned) VALUES (?,?,?,0)`,
    [ADMIN.id, 'admin@test.local', 'admin']);
  await q(`INSERT INTO \`${tbl('cap_scenarios')}\` (id, name, owner_id) VALUES (?,?,?)`,
    [SCENARIO_ID, 'a scenario', null]);
});

const base = `/edge/app/capacity/scenarios/${SCENARIO_ID}`;

async function seedSiteWithHypervisors(count, siteName = 'DC-A') {
  const spec = await call(ADMIN, 'POST', '/edge/app/capacity/config/hardware_specs',
    { name: 'spec-a', cpu_total: 64, mem_total_gb: 512, disk_total_gb: 4096 });
  assert.equal(spec.status, 201, JSON.stringify(spec.body));
  const site = await call(ADMIN, 'POST', `${base}/sites`, { name: siteName });
  const siteId = site.body.data.id;
  for (let i = 0; i < count; i += 1) {
    const hv = await call(ADMIN, 'POST', `${base}/hypervisors`,
      { name: `host-${i}`, site_id: siteId, spec_id: spec.body.data.id });
    assert.equal(hv.status, 200, JSON.stringify(hv.body));
  }
  return siteId;
}

describe('a threshold-crossing cascade snapshots first and restores', () => {
  test(`>= ${AUTO_SNAPSHOT_DELETE_THRESHOLD} deletions create a named version that brings the rows back`, async (t) => {
    if (guard(t)) return;
    const siteId = await seedSiteWithHypervisors(AUTO_SNAPSHOT_DELETE_THRESHOLD, 'DC-A');
    assert.equal(await rowCount('cap_hypervisors'), AUTO_SNAPSHOT_DELETE_THRESHOLD);

    const gone = await call(ADMIN, 'DELETE', `${base}/sites/${siteId}`);
    assert.equal(gone.status, 200, JSON.stringify(gone.body));
    // The response names the snapshot it took.
    assert.ok(gone.body.data.auto_snapshot, 'no auto_snapshot on a threshold-crossing delete');
    assert.equal(gone.body.data.auto_snapshot.name, 'auto before delete sites DC-A');
    // The row exists after commit (row count, not the response) and is the ONLY
    // version — the snapshot writer ran exactly once.
    assert.equal(await rowCount('cap_versions'), 1);
    const versionId = gone.body.data.auto_snapshot.id;
    // Pre-delete state is gone…
    assert.equal(await rowCount('cap_sites'), 0);
    assert.equal(await rowCount('cap_hypervisors'), 0);

    // …and the snapshot restores it: the site and its hypervisors come back.
    const restored = await call(ADMIN, 'POST', `${base}/versions/${versionId}/restore`, {});
    assert.equal(restored.status, 200, JSON.stringify(restored.body));
    assert.equal(await rowCount('cap_sites'), 1, 'the site was not restored');
    assert.equal(await rowCount('cap_hypervisors'), AUTO_SNAPSHOT_DELETE_THRESHOLD,
      'the cascaded hypervisors were not restored');
  });

  test(`fewer than ${AUTO_SNAPSHOT_DELETE_THRESHOLD} deletions take no snapshot`, async (t) => {
    if (guard(t)) return;
    const siteId = await seedSiteWithHypervisors(AUTO_SNAPSHOT_DELETE_THRESHOLD - 1, 'DC-B');

    const gone = await call(ADMIN, 'DELETE', `${base}/sites/${siteId}`);
    assert.equal(gone.status, 200, JSON.stringify(gone.body));
    assert.equal(gone.body.data.auto_snapshot, null, 'a sub-threshold delete created a snapshot');
    assert.equal(await rowCount('cap_versions'), 0);
  });

  test('a max-length entity name does not overflow the cap_versions.name VARCHAR(255) column', async (t) => {
    if (guard(t)) return;
    // cap_sites.name is itself VARCHAR(255), so a legally-stored site name can be
    // long enough that `auto before delete sites <name>` alone exceeds the
    // cap_versions.name column — the label must be bounded independent of what a
    // caller was allowed to store upstream.
    const maxLenName = 'X'.repeat(255);
    const siteId = await seedSiteWithHypervisors(AUTO_SNAPSHOT_DELETE_THRESHOLD, maxLenName);

    const gone = await call(ADMIN, 'DELETE', `${base}/sites/${siteId}`);
    assert.equal(gone.status, 200, JSON.stringify(gone.body));
    assert.ok(gone.body.data.auto_snapshot, 'no auto_snapshot on a threshold-crossing delete');
    const { name } = gone.body.data.auto_snapshot;
    assert.ok(name.length <= 255, `label exceeds cap_versions.name width: ${name.length} chars`);
    assert.ok(name.startsWith('auto before delete sites '), 'the prefix was truncated instead of the name');
    assert.equal(await rowCount('cap_versions'), 1, 'the snapshot INSERT was rejected and rolled back');
  });
});
