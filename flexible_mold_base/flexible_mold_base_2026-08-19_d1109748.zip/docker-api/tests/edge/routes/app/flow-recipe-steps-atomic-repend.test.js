/**
 * flow-recipe-steps-atomic-repend.test.js
 *
 * Drives createCrudRoutes with a fake transactional connection that records the
 * statement order, asserting the parent re-pend UPDATE is issued on the SAME
 * connection (one transaction) as the child write — not via a separate path.
 *
 * This proves the TOCTOU is closed: the parent recipe is locked FOR UPDATE and
 * re-pended in the same transaction as the child step write, so a concurrent
 * admin approve cannot land between the step write and the re-pend.
 */
const { test, beforeEach } = require('node:test');
const assert = require('node:assert');
const express = require('express');

const stmts = [];
const txConn = {
  beginTransaction: async () => { stmts.push('BEGIN'); },
  commit: async () => { stmts.push('COMMIT'); },
  rollback: async () => { stmts.push('ROLLBACK'); },
  release: () => {},
  query: async (sql) => {
    stmts.push(sql.replace(/\s+/g, ' ').trim().slice(0, 120));
    if (/information_schema/i.test(sql)) {
      return [{ COLUMN_NAME: 'id' }, { COLUMN_NAME: 'recipe_id' }, { COLUMN_NAME: 'name' },
        { COLUMN_NAME: 'method' }, { COLUMN_NAME: 'url' }, { COLUMN_NAME: 'auth_type' }];
    }
    if (/SELECT DATABASE\(\)/i.test(sql)) return [{ db: 'testdb' }];
    // Parent recipe row: locked FOR UPDATE to read re-pend status.
    if (/FOR UPDATE/.test(sql) && /FROM `flow_recipes`/.test(sql)) return [{ status: 'approved', owner_id: 'dd288078-1f9f-42af-8f1d-3ce2dcad9efb' }];
    // Child step row: locked FOR UPDATE to serialise concurrent re-parent (via-resolve read).
    if (/FOR UPDATE/.test(sql) && /FROM `flow_recipe_steps`/.test(sql)) return [{ via: '110095e1-0ac0-43a2-8777-9449936efcdd' }];
    // parentOwnership chain SELECT (owner lookup, no FOR UPDATE).
    // Guard with ^SELECT so a combined UPDATE … AND EXISTS (SELECT 1 FROM `flow_recipes` …)
    // issued for editor PUTs falls through to the default { affectedRows: 1 } branch.
    if (/^SELECT/i.test(sql.trim()) && /FROM `flow_recipes`/.test(sql) && /owner_id/.test(sql)) return [{ owner_id: 'dd288078-1f9f-42af-8f1d-3ce2dcad9efb' }];
    // child via-resolve SELECT (PUT/DELETE)
    if (/FROM `flow_recipe_steps`/.test(sql) && /recipe_id/.test(sql) && /^SELECT/i.test(sql.trim())) {
      return [{ via: '110095e1-0ac0-43a2-8777-9449936efcdd' }];
    }
    if (/^SELECT \* FROM `flow_recipe_steps`/i.test(sql.trim())) return [{ id: '8d32f4fc-25e5-40cb-8f60-f36eae4b0dc9', recipe_id: '110095e1-0ac0-43a2-8777-9449936efcdd' }];
    if (/^SELECT/i.test(sql.trim())) return [{ id: '8d32f4fc-25e5-40cb-8f60-f36eae4b0dc9', recipe_id: '110095e1-0ac0-43a2-8777-9449936efcdd', owner_id: 'dd288078-1f9f-42af-8f1d-3ce2dcad9efb' }];
    return { affectedRows: 1, insertId: '8d32f4fc-25e5-40cb-8f60-f36eae4b0dc9' };
  },
};
require.cache[require.resolve('../../../../src/edge/db')] = {
  exports: { pool: { rw: { getConnection: async () => txConn }, ro: { query: async () => [{ owner_id: 'dd288078-1f9f-42af-8f1d-3ce2dcad9efb' }] } }, t: (x) => x },
};

const { createCrudRoutes } = require('../../../../src/edge/routes/app/schema');
const { TABLES } = require('../../../../src/shared/constants');

function app(user) {
  const a = express(); a.use(express.json());
  a.use((req, _res, next) => { req.user = user; next(); });
  a.use('/', createCrudRoutes('flow_recipe_steps', {
    allowedRoles: ['admin', 'editor'],
    parentOwnership: { via: 'recipe_id', chain: [{ table: TABLES.FLOW_RECIPES, match: 'id', readOwner: 'owner_id' }] },
    parentRepend: { table: TABLES.FLOW_RECIPES, via: 'recipe_id', statusCol: 'status', clearCols: ['approved_by', 'approved_at'], repandFrom: ['approved', 'rejected'] },
    filterableColumns: ['recipe_id'],
  }));
  return a;
}
async function req(a, method, path, body) {
  const server = a.listen(0);
  try {
    const port = server.address().port;
    const res = await fetch(`http://127.0.0.1:${port}${path}`, { method, headers: { 'content-type': 'application/json' }, body: body && JSON.stringify(body) });
    const json = await res.json().catch(() => ({}));
    return { status: res.status, json };
  } finally {
    // Closed on the throwing path too. With the close reachable only where
    // nothing threw, a failed assertion leaks this handle, the runner never
    // exits, and the job reports a timeout instead of the assertion that failed.
    server.close();
  }
}

beforeEach(() => { stmts.length = 0; });

test('POST step issues child insert + parent re-pend inside one transaction', async () => {
  await req(app({ id: 'dd288078-1f9f-42af-8f1d-3ce2dcad9efb', role: 'admin' }), 'POST', '/', { recipe_id: '110095e1-0ac0-43a2-8777-9449936efcdd', name: 's', method: 'POST', url: 'https://ok.test/x', auth_type: 'none' });
  assert.ok(stmts.includes('BEGIN'), 'opens a transaction');
  assert.ok(stmts.some((s) => /INSERT INTO `flow_recipe_steps`/i.test(s)), 'inserts the child step');
  assert.ok(stmts.some((s) => /FROM `flow_recipes` WHERE id = \? FOR UPDATE/i.test(s)), 'locks the parent FOR UPDATE');
  assert.ok(stmts.some((s) => /UPDATE `flow_recipes` SET `status` = 'pending'/i.test(s)), 're-pends parent');
  assert.ok(stmts.includes('COMMIT'), 'commits');
  // Ordering invariant: parent lock + re-pend happen AFTER the child insert and BEFORE commit.
  const idxInsert = stmts.findIndex((s) => /INSERT INTO `flow_recipe_steps`/i.test(s));
  const idxLock = stmts.findIndex((s) => /FOR UPDATE/.test(s));
  const idxUpdate = stmts.findIndex((s) => /UPDATE `flow_recipes` SET/i.test(s));
  const idxCommit = stmts.indexOf('COMMIT');
  assert.ok(idxInsert < idxLock && idxLock < idxUpdate && idxUpdate < idxCommit, 'insert → lock → re-pend → commit ordering');
});

test('PUT step re-pends the stored parent inside one transaction', async () => {
  await req(app({ id: 'dd288078-1f9f-42af-8f1d-3ce2dcad9efb', role: 'admin' }), 'PUT', '/8d32f4fc-25e5-40cb-8f60-f36eae4b0dc9', { name: 'renamed' });
  assert.ok(stmts.includes('BEGIN'), 'opens a transaction');
  assert.ok(stmts.some((s) => /UPDATE `flow_recipe_steps`/i.test(s)), 'updates the child step');
  assert.ok(stmts.some((s) => /AS via FROM `flow_recipe_steps` WHERE id = \? FOR UPDATE/i.test(s)), 'locks child row FOR UPDATE before reading stored parent');
  assert.ok(stmts.some((s) => /FROM `flow_recipes` WHERE id = \? FOR UPDATE/i.test(s)), 'locks the parent FOR UPDATE');
  assert.ok(stmts.some((s) => /UPDATE `flow_recipes` SET `status` = 'pending'/i.test(s)), 're-pends parent');
  assert.ok(stmts.includes('COMMIT'), 'commits');
});

test('DELETE step re-pends the stored parent inside one transaction', async () => {
  await req(app({ id: 'dd288078-1f9f-42af-8f1d-3ce2dcad9efb', role: 'admin' }), 'DELETE', '/8d32f4fc-25e5-40cb-8f60-f36eae4b0dc9');
  assert.ok(stmts.includes('BEGIN'), 'opens a transaction');
  assert.ok(stmts.some((s) => /DELETE FROM `flow_recipe_steps`/i.test(s)), 'deletes the child step');
  assert.ok(stmts.some((s) => /AS via FROM `flow_recipe_steps` WHERE id = \? FOR UPDATE/i.test(s)), 'locks child row FOR UPDATE before reading stored parent');
  assert.ok(stmts.some((s) => /FROM `flow_recipes` WHERE id = \? FOR UPDATE/i.test(s)), 'locks the parent FOR UPDATE');
  assert.ok(stmts.some((s) => /UPDATE `flow_recipes` SET `status` = 'pending'/i.test(s)), 're-pends parent');
  assert.ok(stmts.includes('COMMIT'), 'commits');
});

// Regression: editor PUT with recipe_id pointing at a DIFFERENT recipe must NOT
// re-pend the destination recipe. The parent FK is stripped from `data` for
// non-admin PUTs (parentOwnership security strip), so the destination re-pend
// guard reads `data[via]` (undefined after strip) rather than `req.body[via]`.
test('editor PUT with body recipe_id changed re-pends only the stored parent, not the destination', async () => {
  // Stored parent = r1 (mock returns { via: '110095e1-0ac0-43a2-8777-9449936efcdd' }). Body carries r2 (different recipe).
  // After non-admin strip, data.recipe_id is undefined → destVia is undefined → no second re-pend.
  const { status } = await req(app({ id: 'dd288078-1f9f-42af-8f1d-3ce2dcad9efb', role: 'editor' }), 'PUT', '/8d32f4fc-25e5-40cb-8f60-f36eae4b0dc9', { recipe_id: 'a6242ab4-13c9-4e28-80fd-5611bfd66940', name: 'renamed' });
  assert.strictEqual(status, 200, 'PUT succeeds');
  const repends = stmts.filter((s) => /UPDATE `flow_recipes` SET `status` = 'pending'/i.test(s));
  assert.strictEqual(repends.length, 1, 'exactly one re-pend: the stored parent only');
});

// Regression: admin PUT with recipe_id changed must re-pend BOTH the stored
// parent (r1) and the new destination parent (r2). For admin the parent FK is
// NOT stripped, so data.recipe_id = r2 → destVia = r2 → second re-pend fires.
test('admin PUT with recipe_id changed re-pends both stored and destination parents', async () => {
  const { status } = await req(app({ id: 'dd288078-1f9f-42af-8f1d-3ce2dcad9efb', role: 'admin' }), 'PUT', '/8d32f4fc-25e5-40cb-8f60-f36eae4b0dc9', { recipe_id: 'a6242ab4-13c9-4e28-80fd-5611bfd66940', name: 'renamed' });
  assert.strictEqual(status, 200, 'PUT succeeds');
  const repends = stmts.filter((s) => /UPDATE `flow_recipes` SET `status` = 'pending'/i.test(s));
  assert.strictEqual(repends.length, 2, 'exactly two re-pends: stored parent r1 and new destination r2');
});
