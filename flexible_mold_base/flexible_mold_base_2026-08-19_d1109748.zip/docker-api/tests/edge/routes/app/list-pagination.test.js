/**
 * list-pagination.test.js — the opt-in page/offset/total capability added to
 * the shared CRUD list handler.
 *
 * The mock connection here does not implement LIMIT/OFFSET; it answers with the
 * rows it was given. That is deliberate — these tests assert the STATEMENT and
 * the BIND PARAMETERS the handler builds, which is the part the handler is
 * responsible for. A test that asserted the sliced rows would be asserting that
 * the mock can slice.
 *
 * The one thing a mock genuinely cannot vouch for — that the counted rows are
 * the same rows the caller may read — is asserted structurally: the COUNT
 * statement's WHERE clause and bind parameters must equal the row query's.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../../../src/edge/db');

let queries;
let rowsByTable;
let countValue;
let missingTables;

function makeConn() {
  return {
    async query(sql, params = []) {
      queries.push({ sql, params });
      if (/^SELECT DATABASE\(\)/i.test(sql)) return [{ db: 'testdb' }];
      if (/information_schema\.COLUMNS/i.test(sql)) return [];
      for (const absent of missingTables) {
        if (sql.includes(`\`fmb_${absent}\``)) {
          throw Object.assign(new Error(`Table 'fmb_${absent}' doesn't exist`), { errno: 1146 });
        }
      }
      if (/^SELECT COUNT\(/i.test(sql)) return [{ cnt: countValue }];
      if (/FROM `fmb_users`/.test(sql)) return [];
      const m = sql.match(/FROM `fmb_([a-z_]+)`/);
      if (m) return (rowsByTable[m[1]] || []).map((r) => ({ ...r }));
      return [];
    },
    release() {},
    async beginTransaction() {},
    async commit() {},
    async rollback() {},
  };
}

// Counted, not just observed through the statements it issues: "a rejected
// page request must not cost a pool slot" is a claim about taking the
// connection, and a handler that takes one and then rejects issues no
// statement either.
let connectionsTaken;

const poolFacade = {
  async getConnection() { connectionsTaken += 1; return makeConn(); },
  query: async (sql, params) => makeConn().query(sql, params),
};

require.cache[dbKey] = {
  id: dbKey,
  filename: dbKey,
  loaded: true,
  exports: {
    pool: { ro: poolFacade, rw: poolFacade },
    t: (n) => `fmb_${n}`,
    getDynamicPool: async () => ({ ro: poolFacade, rw: poolFacade }),
  },
};

const schemaRouter = require('../../../../src/edge/routes/app/schema');
const runsRouter = require('../../../../src/edge/routes/app/flow-recipe-runs');
const { createCrudRoutes } = require('../../../../src/edge/routes/app/schema');
const { MAX_PAGE_SIZE, parsePageRequest } = require('../../../../src/edge/routes/app/schema/list-query');

/**
 * A mount that exists only in this file, declaring the per-user read scope no
 * shipped mount declares any more.
 *
 * The capability is the FACTORY'S, and it is the one thing a mock cannot vouch
 * for by any other means: that the total is counted over the same rows the
 * caller may read. When the run history opened up, `userScopeColumn` lost its
 * last real consumer — and with it, this property lost its only witness. Rather
 * than delete the coverage, the witness is built here: the next mount to declare
 * a user scope inherits a capability that is still held to counting correctly.
 */
const scopedProbeRouter = createCrudRoutes('flow_recipe_runs', {
  userScopeColumn: 'actor_id',
  writeScopeColumn: 'actor_id',
  filterableColumns: ['recipe_id'],
});

let currentUser;
let server;
let baseUrl;

before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { req.user = currentUser; next(); });
  app.use('/edge/app/schema', schemaRouter);
  app.use('/edge/app/flow-recipe-runs', runsRouter);
  app.use('/edge/app/scoped-probe', scopedProbeRouter);
  server = http.createServer(app);
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});

after(() => server && server.close());

beforeEach(() => {
  queries = [];
  connectionsTaken = 0;
  countValue = 7;
  missingTables = new Set();
  currentUser = { id: 'u-editor', role: 'editor', email: 'editor@example.test' };
  rowsByTable = {
    blueprint_sections: [
      { id: 's-1', blueprint_id: 'bp-1', section_key: 'alpha', sort_order: 1, matrix_copy: null, created_at: '2026-01-01 00:00:00', updated_at: '2026-01-01 00:00:00' },
      { id: 's-2', blueprint_id: 'bp-1', section_key: 'beta', sort_order: 2, matrix_copy: null, created_at: '2026-01-02 00:00:00', updated_at: '2026-01-02 00:00:00' },
    ],
    flow_recipe_runs: [
      { id: 'run-1', recipe_id: 'rec-1', actor_id: 'u-editor', status: 'success', created_at: '2026-01-01 00:00:00', updated_at: '2026-01-01 00:00:00' },
    ],
  };
});

function get(path) {
  return new Promise((resolve, reject) => {
    const r = http.request(`${baseUrl}${path}`, { method: 'GET' }, (res) => {
      const chunks = [];
      res.on('data', (c) => chunks.push(c));
      res.on('end', () => {
        let json = null;
        try { json = JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch { /* noop */ }
        resolve({ status: res.statusCode, json });
      });
    });
    r.on('error', reject);
    r.end();
  });
}

const rowStatement = (table) =>
  queries.find((q) => q.sql.startsWith(`SELECT * FROM \`fmb_${table}\``));
const countStatement = (table) =>
  queries.find((q) => q.sql.startsWith(`SELECT COUNT(*) AS cnt FROM \`fmb_${table}\``));

describe('a paged read orders totally', () => {
  // A page is a window over an ordering, so the ordering has to be total or the
  // window is not well defined. None of the sortable columns is unique and the
  // default one is a one-second-resolution TIMESTAMP on an append-only table,
  // so tie groups are the normal case. Two pages are two independent
  // statements; nothing obliges the engine to break a tie the same way twice,
  // and the symptom is a row served on two pages while another is unreachable
  // at any offset, on an idle database. The mock connection cannot demonstrate
  // that — it does not implement LIMIT/OFFSET — so the statement is what gets
  // pinned, and the premise the fix rests on is checked separately below.
  it('appends the primary key as a tiebreaker on the default sort', async () => {
    const res = await get('/edge/app/schema/blueprint_sections?limit=2&offset=4');
    assert.equal(res.status, 200);
    const stmt = rowStatement('blueprint_sections');
    assert.equal(
      stmt.sql,
      'SELECT * FROM `fmb_blueprint_sections` ORDER BY `created_at` IS NULL, `created_at` ASC, `id` ASC LIMIT ? OFFSET ?',
    );
    assert.deepEqual(stmt.params, [2, 4]);
  });

  it('appends it on an explicit sort too, following the requested direction', async () => {
    // Descending, so the sequence stays monotone as the reader pages down.
    await get('/edge/app/schema/blueprint_sections?sort=sort_order&order=desc&limit=2&offset=0');
    assert.equal(
      rowStatement('blueprint_sections').sql,
      'SELECT * FROM `fmb_blueprint_sections` ORDER BY `sort_order` IS NULL, `sort_order` DESC, `id` DESC LIMIT ? OFFSET ?',
    );
  });

  it('does not repeat itself when the sort column already IS the primary key', async () => {
    await get('/edge/app/schema/blueprint_sections?sort=id&limit=2&offset=0');
    assert.equal(
      rowStatement('blueprint_sections').sql,
      'SELECT * FROM `fmb_blueprint_sections` ORDER BY `id` IS NULL, `id` ASC LIMIT ? OFFSET ?',
    );
  });

  it('adds no tiebreaker to an unpaged read, whose statement must not move', async () => {
    await get('/edge/app/schema/blueprint_sections?limit=2');
    assert.equal(
      rowStatement('blueprint_sections').sql,
      'SELECT * FROM `fmb_blueprint_sections` ORDER BY `created_at` IS NULL, `created_at` ASC LIMIT ?',
    );
  });

  it('every table this factory serves has the single-column primary key the tiebreaker assumes', () => {
    // The tiebreaker is sound only if `id` is present, of the expected type,
    // and UNIQUE ON ITS OWN. Three separate things, so three separate checks:
    // an `id` line carrying the words PRIMARY KEY says nothing about a
    // table-level `PRIMARY KEY (a, b)` sitting further down, and a column
    // declared some other width is a different thing wearing the same name.
    const { buildEngineTableDDLs } = require('../../../../src/table-ddls');
    const noIdColumn = [];
    const wrongType = [];
    const notPrimaryKey = [];
    const compositeKey = [];
    let seen = 0;

    for (const ddl of buildEngineTableDDLs((n) => n)) {
      const m = ddl.match(/CREATE TABLE IF NOT EXISTS `([^`]+)`/);
      if (!m) continue;
      seen += 1;
      const table = m[1];
      const lines = ddl.split('\n').map((s) => s.trim());
      const idLine = lines.find((s) => /^`?id`?\s/i.test(s));
      if (!idLine) { noIdColumn.push(table); continue; }
      if (!/^`?id`?\s+CHAR\(36\)/i.test(idLine)) wrongType.push(`${table}: ${idLine}`);
      if (!/PRIMARY\s+KEY/i.test(idLine)) notPrimaryKey.push(`${table}: ${idLine}`);
      // A table-level key declaration — composite or not — means the column
      // line is not the whole story about uniqueness.
      const tableLevel = lines.find((s) => /^PRIMARY\s+KEY\s*\(/i.test(s));
      if (tableLevel) compositeKey.push(`${table}: ${tableLevel}`);
    }

    assert.ok(seen >= 30, `only ${seen} engine tables were parsed — the DDL reader is not seeing them`);
    assert.deepEqual(noIdColumn, [], 'these tables declare no `id` column');
    assert.deepEqual(wrongType, [], 'these tables declare `id` as something other than CHAR(36)');
    assert.deepEqual(notPrimaryKey, [], 'these tables do not declare `id` as the primary key on its own line');
    assert.deepEqual(compositeKey, [], 'these tables declare a table-level PRIMARY KEY — `id` alone may not be unique');
  });
});

describe('offset and limit combine', () => {

  it('answers with a page object carrying the total and the page it read', async () => {
    const res = await get('/edge/app/schema/blueprint_sections?limit=2&offset=4');
    assert.deepEqual(Object.keys(res.json.data).sort(), ['limit', 'offset', 'rows', 'total']);
    assert.ok(Array.isArray(res.json.data.rows));
    assert.equal(res.json.data.total, 7);
    assert.equal(res.json.data.limit, 2);
    assert.equal(res.json.data.offset, 4);
  });

  it('offset 0 is a page request, not an absent one', async () => {
    // PR 7 asks for page one by sending offset=0; if that fell through to the
    // unpaginated path the first page would silently return every row.
    const res = await get('/edge/app/schema/blueprint_sections?limit=2&offset=0');
    const stmt = rowStatement('blueprint_sections');
    assert.deepEqual(stmt.params, [2, 0]);
    assert.equal(res.json.data.total, 7);
  });

  it('a page past the end is an empty page with the real total, not an error', async () => {
    rowsByTable.blueprint_sections = [];
    countValue = 2;
    const res = await get('/edge/app/schema/blueprint_sections?limit=2&offset=999');
    assert.equal(res.status, 200);
    assert.deepEqual(res.json.data.rows, []);
    assert.equal(res.json.data.total, 2, 'the total describes the result set, not the page');
    assert.equal(res.json.data.offset, 999);
  });

  it('a BigInt count is converted, not passed through', async () => {
    // The pool sets no bigIntAsNumber, so COUNT(*) genuinely arrives as a
    // BigInt and JSON.stringify would throw on it. A zero-valued BigInt does
    // NOT exercise this — Number(0n) is 0 and so is the fallback below — so the
    // value here is deliberately non-zero.
    countValue = 12345n;
    const res = await get('/edge/app/schema/blueprint_sections?limit=2&offset=0');
    assert.equal(res.json.data.total, 12345);
    assert.equal(typeof res.json.data.total, 'number');
  });

  it('a count row that carries no usable number reports zero rather than NaN', async () => {
    // This is the branch the `|| 0` exists for, and the only input that can
    // tell it apart from plain Number(): NaN would serialise to null and a
    // client reading `total` would get something it cannot compare.
    countValue = undefined;
    const res = await get('/edge/app/schema/blueprint_sections?limit=2&offset=0');
    assert.equal(res.json.data.total, 0);
    assert.equal(typeof res.json.data.total, 'number');
  });
});

describe('a mount that tolerates its table being absent', () => {
  it('degrades to an empty page, not to an empty array the client cannot read', async () => {
    // blueprint_groups is additive: on an install whose migration could not
    // create it, the list answers "no rows" rather than 500. A paged caller
    // must get the page shape it asked for, or it reads `undefined.length`.
    missingTables = new Set(['blueprint_groups']);
    const res = await get('/edge/app/schema/blueprint_groups?limit=10&offset=0');
    assert.equal(res.status, 200);
    assert.deepEqual(res.json.data, { rows: [], total: 0, limit: 10, offset: 0 });
  });

  it('still degrades to a bare empty array for an unpaged caller', async () => {
    missingTables = new Set(['blueprint_groups']);
    const res = await get('/edge/app/schema/blueprint_groups');
    assert.equal(res.status, 200);
    assert.deepEqual(res.json.data, []);
  });
});

describe('the total honours every restriction the row query applies', () => {
  it('counts under the same declared filter, with the same binds', async () => {
    await get('/edge/app/schema/blueprint_sections?blueprint_id=bp-1&limit=1&offset=0');
    const rowStmt = rowStatement('blueprint_sections');
    const cntStmt = countStatement('blueprint_sections');
    assert.ok(cntStmt, 'no COUNT statement was issued for a paged read');
    assert.equal(
      cntStmt.sql,
      'SELECT COUNT(*) AS cnt FROM `fmb_blueprint_sections` WHERE `blueprint_id` = ?',
    );
    assert.deepEqual(cntStmt.params, ['bp-1']);
    // The row query's binds are the same list plus the page bounds — which is
    // the property that makes the two agree on WHICH rows are being counted.
    assert.deepEqual(rowStmt.params, ['bp-1', 1, 0]);
  });

  it('counts under the non-admin user scope, so a total cannot leak another user\'s rows', async () => {
    // Read through the local user-scoped mount: see its note above.
    await get('/edge/app/scoped-probe?limit=10&offset=0');
    const cntStmt = countStatement('flow_recipe_runs');
    assert.equal(
      cntStmt.sql,
      'SELECT COUNT(*) AS cnt FROM `fmb_flow_recipe_runs` WHERE `actor_id` = ?',
    );
    assert.deepEqual(cntStmt.params, ['u-editor'], 'the count was not scoped to the caller');
  });

  it('the COUNT predicate is character-identical to the row query predicate', async () => {
    // The two statements are built from one shared WHERE fragment. Asserting
    // the text rather than the behaviour is the point: if someone rebuilds the
    // count predicate separately, this fails even when both happen to agree
    // today.
    await get('/edge/app/scoped-probe?recipe_id=rec-1&limit=5&offset=5');
    const rowStmt = rowStatement('flow_recipe_runs');
    const cntStmt = countStatement('flow_recipe_runs');
    const rowWhere = rowStmt.sql.slice(rowStmt.sql.indexOf(' WHERE '), rowStmt.sql.indexOf(' ORDER BY '));
    const cntWhere = cntStmt.sql.slice(cntStmt.sql.indexOf(' WHERE '));
    assert.equal(cntWhere, rowWhere);
    assert.deepEqual(cntStmt.params, ['rec-1', 'u-editor']);
    assert.deepEqual(rowStmt.params, ['rec-1', 'u-editor', 5, 5]);
  });

  it('an admin counts unscoped, matching the rows an admin reads', async () => {
    currentUser = { id: 'u-admin', role: 'admin', email: 'admin@example.test' };
    await get('/edge/app/scoped-probe?limit=10&offset=0');
    const cntStmt = countStatement('flow_recipe_runs');
    assert.equal(cntStmt.sql, 'SELECT COUNT(*) AS cnt FROM `fmb_flow_recipe_runs`');
    assert.deepEqual(cntStmt.params, []);
  });
});

describe('rejected page requests', () => {
  const cases = [
    ['a negative offset', '?limit=10&offset=-1'],
    ['a fractional offset', '?limit=10&offset=1.5'],
    ['a non-numeric offset', '?limit=10&offset=abc'],
    ['an exponent-notation offset', '?limit=10&offset=1e3'],
    ['a hex offset', '?limit=10&offset=0x10'],
    // Two different spellings, and the first test's name used to cover for the
    // second: `%20` is whitespace padding, which `^\d+$` already refused, while
    // a leading zero is the one this validator used to let through.
    ['a whitespace-padded offset', '?limit=10&offset=%201'],
    ['a trailing-whitespace offset', '?limit=10&offset=1%20'],
    ['a zero-padded offset', '?limit=10&offset=01'],
    ['an all-zeros offset', '?limit=10&offset=000'],
    ['a repeated offset', '?limit=10&offset=1&offset=2'],
    ['an offset with no limit', '?offset=10'],
    ['a zero limit', '?limit=0&offset=0'],
    ['a negative limit', '?limit=-5&offset=0'],
    ['a non-numeric limit', '?limit=abc&offset=0'],
    ['a zero-padded limit', '?limit=010&offset=0'],
    ['an all-zeros limit', '?limit=00&offset=0'],
    [`a limit above ${MAX_PAGE_SIZE}`, `?limit=${MAX_PAGE_SIZE + 1}&offset=0`],
    ['an unbounded limit', '?limit=100000&offset=0'],
  ];

  for (const [label, qs] of cases) {
    it(`${label} is refused with 400, and costs no connection`, async () => {
      const res = await get(`/edge/app/schema/blueprint_sections${qs}`);
      assert.equal(res.status, 400, `expected 400, body: ${JSON.stringify(res.json)}`);
      assert.equal(res.json.error.code, 'INVALID_PAGINATION');
      assert.deepEqual(
        queries.filter((q) => q.sql.includes('fmb_blueprint_sections')),
        [],
        'a rejected page request still reached the database',
      );
      // The statement assertion above is satisfied by a handler that takes a
      // connection and rejects afterwards, which is precisely the behaviour the
      // validator is placed ahead of the pool to avoid.
      assert.equal(connectionsTaken, 0, 'a rejected page request still took a pool connection');
    });
  }

  it('a request that IS valid does take a connection — the counter is live', async () => {
    // Without this, the assertion above would also pass against a mock whose
    // counter never moves.
    await get('/edge/app/schema/blueprint_sections?limit=2&offset=0');
    assert.equal(connectionsTaken, 1);
  });

  it(`the ceiling itself is accepted`, async () => {
    const res = await get(`/edge/app/schema/blueprint_sections?limit=${MAX_PAGE_SIZE}&offset=0`);
    assert.equal(res.status, 200);
    assert.deepEqual(rowStatement('blueprint_sections').params, [MAX_PAGE_SIZE, 0]);
  });
});

describe('parsePageRequest — the unit behind the route assertions', () => {
  it('reports no pagination when offset is absent, whatever limit says', () => {
    assert.deepEqual(parsePageRequest({}), { paginated: false });
    assert.deepEqual(parsePageRequest({ limit: '9999999' }), { paginated: false });
  });

  it('rejects an offset beyond the safe integer range', () => {
    const verdict = parsePageRequest({ limit: '10', offset: '9007199254740993' });
    assert.ok(verdict.error, 'an offset past Number.MAX_SAFE_INTEGER was accepted');
  });

  it('accepts a well-formed page', () => {
    assert.deepEqual(parsePageRequest({ limit: '25', offset: '50' }), {
      paginated: true, limit: 25, offset: 50,
    });
  });

  it('accepts the single digit zero, which is the one leading zero that is canonical', () => {
    assert.deepEqual(parsePageRequest({ limit: '25', offset: '0' }), {
      paginated: true, limit: 25, offset: 0,
    });
  });

  it('admits exactly one spelling per page position', () => {
    // The property behind the individual rejections above: for a given page,
    // there is one query string that reaches the database and every other way
    // of writing the same number is a 400.
    for (const spelling of ['01', '001', ' 1', '1 ', '1.0', '1e0', '+1', '0x1']) {
      const verdict = parsePageRequest({ limit: '10', offset: spelling });
      assert.ok(verdict.error, `offset spelling ${JSON.stringify(spelling)} was accepted as well as "1"`);
    }
    assert.equal(parsePageRequest({ limit: '10', offset: '1' }).offset, 1);
  });
});

describe('the run history itself is counted for everyone, under no scope at all', () => {
  it('a non-administrator reads and counts the whole table', async () => {
    // The mount that used to carry the scope above. Its total is now the size
    // of the whole set, for every caller, which is what the open read rule
    // means when a page is asked for.
    await get('/edge/app/flow-recipe-runs?limit=10&offset=0');
    const rowStmt = rowStatement('flow_recipe_runs');
    const cntStmt = countStatement('flow_recipe_runs');
    assert.ok(!rowStmt.sql.includes('actor_id'), rowStmt.sql);
    assert.equal(cntStmt.sql, 'SELECT COUNT(*) AS cnt FROM `fmb_flow_recipe_runs`');
    assert.deepEqual(cntStmt.params, []);
  });
});
