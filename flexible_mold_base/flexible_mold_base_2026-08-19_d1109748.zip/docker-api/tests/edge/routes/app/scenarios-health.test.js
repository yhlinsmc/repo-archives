/**
 * scenarios-health.test.js — GET /scenarios/health degrades a single failing
 * integrity probe instead of 500ing the whole list badge. The original incident:
 * one throwing probe (an FK probe or the dc_refs JSON_TABLE expansion) took the
 * endpoint down, which then tripped the infra circuit breaker. Each probe now
 * runs in its own try/catch; a failure is reported in a per-row probeErrors
 * marker and the endpoint stays 200 with the other counters intact.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

// Mock edge/db BEFORE requiring the scenarios router (it + _shared + schema all
// pull { pool, t } from ../../../db at load).
const dbKey = require.resolve('../../../../src/edge/db');

// Per-test switch: which probe SQL should reject. null ⇒ every probe resolves.
let rejectMode = null;
let firstFkProbeSeen = false;

const roPool = {
  query: async (sql) => {
    // Seed: the scenario id list.
    if (/SELECT id FROM `fmb_cap_scenarios`/i.test(sql)) {
      return [{ id: 'S1' }, { id: 'S2' }];
    }
    // Incomplete-config aggregate: databases with no sizing profile.
    if (/profile_id IS NULL/i.test(sql)) {
      return [{ scenario_id: 'S2', c: 1 }];
    }
    // Broken-FK probes (the loop): each carries `p.id IS NULL`.
    if (/p\.id IS NULL/i.test(sql)) {
      if (rejectMode === 'fk' && !firstFkProbeSeen) {
        firstFkProbeSeen = true;
        throw new Error("Unknown column 'x' in 'where clause'");
      }
      return [];
    }
    // Stale VM-site cache aggregate.
    if (/v\.site_id <> h\.site_id/i.test(sql)) {
      if (rejectMode === 'vm_site') throw new Error('probe boom');
      return [];
    }
    // Dangling dc_refs aggregate (the JSON_TABLE expansion — self-documented 500 risk).
    if (/JSON_TABLE/i.test(sql)) {
      if (rejectMode === 'dc_refs') throw new Error('Invalid JSON text');
      return [];
    }
    // Site-count aggregate (no join).
    if (/FROM `fmb_cap_sites`/i.test(sql) && /GROUP BY scenario_id/i.test(sql)) {
      return [{ scenario_id: 'S1', c: 2 }];
    }
    return [];
  },
  getConnection: async () => ({
    beginTransaction: async () => {}, commit: async () => {},
    rollback: async () => {}, release: () => {}, query: async () => [],
  }),
};

require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: { ro: roPool, rw: roPool }, t: (n) => `fmb_${n}` },
};

const scenariosRouter = require('../../../../src/edge/routes/app/capacity/scenarios');

let server; let baseUrl;
before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { req.user = { id: 'user-1', role: 'user' }; next(); });
  app.use('/scenarios', scenariosRouter);
  server = http.createServer(app);
  await new Promise((r) => server.listen(0, r));
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});
after(() => server && server.close());
beforeEach(() => { rejectMode = null; firstFkProbeSeen = false; });

function get(path) {
  return new Promise((resolve, reject) => {
    const r = http.request(`${baseUrl}${path}`, { method: 'GET' }, (res) => {
      let data = '';
      res.on('data', (c) => { data += c; });
      res.on('end', () => resolve({ status: res.statusCode, body: data ? JSON.parse(data) : null }));
    });
    r.on('error', reject);
    r.end();
  });
}

describe('GET /scenarios/health probe degradation', () => {
  it('returns 200 with populated counters and no probeErrors when every probe resolves', async () => {
    const res = await get('/scenarios/health');
    assert.equal(res.status, 200);
    const rows = res.body.data;
    assert.equal(rows.length, 2);
    const s1 = rows.find((r) => r.id === 'S1');
    const s2 = rows.find((r) => r.id === 'S2');
    assert.equal(s1.sites, 2);
    assert.equal(s2.databasesWithoutProfile, 1);
    // Happy-path payload shape unchanged: no probeErrors field on any row.
    assert.ok(rows.every((r) => r.probeErrors === undefined));
  });

  it('returns 200 with a probeErrors marker when one FK integrity probe fails', async () => {
    rejectMode = 'fk';
    const res = await get('/scenarios/health');
    assert.equal(res.status, 200, 'a single failing probe must not 500 the endpoint');
    const rows = res.body.data;
    assert.equal(rows.length, 2);
    // Every row carries the degraded-probe marker (a failed probe is global).
    for (const row of rows) {
      assert.ok(Array.isArray(row.probeErrors) && row.probeErrors.length >= 1);
      assert.ok(row.probeErrors.every((p) => p.error === true && typeof p.probe === 'string'));
    }
    // The remaining counters are still populated from the probes that resolved.
    assert.equal(rows.find((r) => r.id === 'S1').sites, 2);
    assert.equal(rows.find((r) => r.id === 'S2').databasesWithoutProfile, 1);
  });

  it('returns 200 with a cap_databases.dc_refs marker when the JSON_TABLE probe fails', async () => {
    rejectMode = 'dc_refs';
    const res = await get('/scenarios/health');
    assert.equal(res.status, 200);
    const markers = res.body.data[0].probeErrors;
    // Probe id follows the unified table.column contract (L1), not the bare 'dc_refs'.
    assert.ok(markers.some((p) => p.probe === 'cap_databases.dc_refs' && p.error === true));
  });

  it('returns 200 with a cap_vms.site_cache marker when the stale-VM-site probe fails', async () => {
    rejectMode = 'vm_site';
    const res = await get('/scenarios/health');
    assert.equal(res.status, 200);
    const markers = res.body.data[0].probeErrors;
    assert.ok(markers.some((p) => p.probe === 'cap_vms.site_cache' && p.error === true));
  });
});
