/**
 * scenarios-health-schema-parity.test.js — validates every column the GET
 * /scenarios/health SQL references against the ACTUAL table DDL, WITHOUT a live
 * DB. The functional test mocks pool.ro.query, so a wrong column name stays
 * green there yet 500s in production and (per the incident) trips the infra
 * breaker. This test parses table-ddls.js and asserts each referenced column
 * exists — for the FK integrity probes, the two JOIN aggregates, and the
 * seed / config-completeness aggregates the health handler runs.
 */
const { describe, it, before } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

// _shared.js destructures { t } from ../../../db at load (never calls it at load
// time); stub the db module so the require is side-effect-free (no pool).
const dbKey = require.resolve('../../../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: {}, t: (n) => n },
};

const { buildEngineTableDDLs } = require('../../../../src/table-ddls');
const { SCENARIO_INTEGRITY_FK_PROBES } = require('../../../../src/edge/routes/app/capacity/_shared');
const { TABLES } = require('../../../../src/shared/constants');

const SQL_TYPES = /^`?([a-z_]+)`?\s+(?:CHAR|VARCHAR|INT|DOUBLE|TIMESTAMP|JSON|TEXT|ENUM|BOOLEAN|TINYINT|BIGINT|DATETIME|DECIMAL|FLOAT|BLOB)\b/i;
let columnsByTable;

before(() => {
  columnsByTable = new Map();
  for (const ddl of buildEngineTableDDLs((n) => n)) {
    const m = ddl.match(/CREATE TABLE IF NOT EXISTS `([^`]+)`/);
    if (!m) continue;
    const cols = new Set();
    for (const rawLine of ddl.split('\n')) {
      const line = rawLine.trim();
      if (!line || line.startsWith('--') || line.startsWith('/*')) continue;
      const cm = line.match(SQL_TYPES);
      if (cm) cols.add(cm[1]);
    }
    columnsByTable.set(m[1], cols);
  }
});

// ── lift the aliased JOIN aggregates from the source, so adding a column to the
// SQL puts it under this check automatically (a hand-copied list could agree
// with the DDL while the statement does not — the failure this file catches). ──
const SCENARIOS_SRC = fs.readFileSync(
  path.resolve(__dirname, '../../../../src/edge/routes/app/capacity/scenarios.js'), 'utf8',
);
const TABLE_CONSTANTS = Object.fromEntries(
  Object.entries(TABLES).map(([name, value]) => [`TABLES.${name}`, String(value)]),
);

function liftStatement(declaration) {
  const start = SCENARIOS_SRC.indexOf(declaration);
  assert.notEqual(start, -1, `scenarios.js no longer declares: ${declaration}`);
  const open = SCENARIOS_SRC.indexOf('`', start);
  let close = open + 1;
  while (close < SCENARIOS_SRC.length
    && !(SCENARIOS_SRC[close] === '`' && SCENARIOS_SRC[close - 1] !== '\\')) close += 1;
  return SCENARIOS_SRC.slice(open + 1, close);
}

function aliasesOf(statement) {
  const map = new Map();
  for (const m of statement.matchAll(/(?:FROM|JOIN)\s+\\`\$\{t\(([A-Z_.]+)\)\}\\`\s+(\w+)/g)) {
    const table = TABLE_CONSTANTS[m[1]];
    assert.ok(table, `the statement reads ${m[1]}, which is not a TABLES constant`);
    map.set(m[2], table);
  }
  return map;
}

function assertColumnParity(statement, aliasTable, minRefs) {
  const refs = [...statement.matchAll(/\b(\w+)\.(\w+)\b/g)]
    .filter(([, alias]) => aliasTable.has(alias))
    .map(([, alias, column]) => ({ table: aliasTable.get(alias), column }));
  assert.ok(refs.length >= minRefs, `only ${refs.length} column references found — the parse has stopped working`);
  for (const { table, column } of refs) {
    assert.ok(
      columnsByTable.get(table).has(column),
      `${table} has no column '${column}' — /health would 500 while every mocked test stayed green`,
    );
  }
}

describe('scenario health SQL — schema parity', () => {
  it('every integrity FK probe references real columns (from.fk, to.id, to.scenario_id)', () => {
    for (const probe of SCENARIO_INTEGRITY_FK_PROBES) {
      const fromCols = columnsByTable.get(String(probe.from));
      const toCols = columnsByTable.get(String(probe.to));
      assert.ok(fromCols && fromCols.has(probe.fk), `${probe.from} has no FK column '${probe.fk}'`);
      assert.ok(toCols && toCols.has('id'), `${probe.to} has no id`);
      assert.ok(toCols.has('scenario_id'), `${probe.to} has no scenario_id (needed for the scope join)`);
    }
  });

  it('the seed + config-completeness aggregates read real columns', () => {
    // SELECT id FROM cap_scenarios / COUNT FROM cap_sites GROUP BY scenario_id /
    // cap_databases WHERE profile_id IS NULL GROUP BY scenario_id.
    assert.ok(columnsByTable.get(String(TABLES.CAP_SCENARIOS)).has('id'), 'cap_scenarios has no id');
    assert.ok(columnsByTable.get(String(TABLES.CAP_SITES)).has('scenario_id'), 'cap_sites has no scenario_id');
    const dbCols = columnsByTable.get(String(TABLES.CAP_DATABASES));
    assert.ok(dbCols.has('scenario_id'), 'cap_databases has no scenario_id');
    assert.ok(dbCols.has('profile_id'), 'cap_databases has no profile_id');
  });

  it('the stale VM-site-cache aggregate names real columns on both tables', () => {
    const statement = liftStatement('const runStaleVmSite = limitedQuery(');
    const aliasTable = aliasesOf(statement);
    assert.deepEqual([...aliasTable.values()].sort(), ['cap_hypervisors', 'cap_vms']);
    assertColumnParity(statement, aliasTable, 6);
  });

  it('the dangling dc_refs aggregate names real columns on both tables', () => {
    const statement = liftStatement('const runDcRefs = limitedQuery(');
    const aliasTable = aliasesOf(statement);
    assert.deepEqual([...aliasTable.values()].sort(), ['cap_databases', 'cap_sites']);
    assertColumnParity(statement, aliasTable, 4);
  });
});
