/**
 * flow-recipe-steps-repend-lock-order.test.js
 *
 * Drives the REAL createCrudRoutes PUT handler with a statement-capturing
 * transactional connection and asserts two properties of the parent re-pend
 * that are observable directly in the emitted SQL statement stream:
 *
 *   (1) ownerCol — the non-admin owner-gate SELECT interpolates the configured
 *       ownerCol, not a hardcoded `owner_id` literal. A second adopter whose
 *       parent owns rows under a different column must get its column in the
 *       SELECT; the old literal would have 500'd (errno-1054, swallowed → no
 *       re-pend).
 *
 *   (2) lock order — an admin re-parent re-pends TWO parents (stored +
 *       destination). The two FOR UPDATE locks must be acquired in a
 *       deterministic (sorted) order regardless of which id is stored vs
 *       destination, so two concurrent opposite-direction re-parents can never
 *       lock the pair in reverse order and deadlock (ABBA). Lock-acquisition
 *       order is deterministic in the statement stream, so this is asserted
 *       deterministically here rather than via a flaky real-InnoDB deadlock
 *       race.
 */
const { test, describe } = require('node:test');
const assert = require('node:assert/strict');
const express = require('express');

const path = require('node:path');
const dbKey = require.resolve('../../../../src/edge/db');
const schemaKey = require.resolve('../../../../src/edge/routes/app/schema');
// schema is a folder of modules (index re-exports helpers/crud-factory/routes-*);
// the db binding is captured in the submodules, so busting only index would leave
// them holding a stale db. Purge the whole subtree so a re-require re-binds the
// mocked db below.
const schemaDir = path.dirname(schemaKey) + path.sep;
const { TABLES } = require('../../../../src/shared/constants');
const { answerParentIdProbe } = require('../../../helpers/parent-id-probe');

// Capturing tx conn. `storedVia` is the child's current parent id returned by
// the via-resolve FOR UPDATE; `rependOwner` is what the parent FOR UPDATE read
// reports back to the owner-gate.
function makeConn(captured, { storedVia, rependOwner, parentIds }) {
  return {
    beginTransaction: async () => { captured.push({ sql: 'BEGIN', params: [] }); },
    commit: async () => { captured.push({ sql: 'COMMIT', params: [] }); },
    rollback: async () => { captured.push({ sql: 'ROLLBACK', params: [] }); },
    release: () => {},
    query: async (sql, params) => {
      const norm = sql.replace(/\s+/g, ' ').trim();
      captured.push({ sql: norm, params: params || [] });
      if (/information_schema/i.test(sql)) {
        return [{ COLUMN_NAME: 'id' }, { COLUMN_NAME: 'recipe_id' }, { COLUMN_NAME: 'name' }];
      }
      if (/SELECT DATABASE\(\)/i.test(sql)) return [{ db: 'testdb' }];
      if (/FOR UPDATE/.test(sql) && /FROM `flow_recipe_steps`/.test(sql)) return [{ via: storedVia }];
      if (/FOR UPDATE/.test(sql) && /FROM `flow_recipes`/.test(sql)) {
        return [{ status: 'approved', owner_id: rependOwner }];
      }
      // The factory asks which spelling the parent row carries before binding
      // one. It has to be answered ahead of the catch-all below, which returns
      // this CHILD's id for any SELECT and would hand back an unrelated row.
      //
      // ANSWERED FROM THE SPELLINGS THIS FIXTURE CLAIMS THE TABLE HOLDS. The
      // helper's default answers with a canonical (lower-cased) id, which is
      // what a table of `UUID()`-minted ids really holds — but the case below
      // is about a table holding an UPPER-case one, so it has to say so. Left
      // to the default, the destination parent would come back lower-cased and
      // the pair whose two sort orders disagree would collapse into a pair
      // where they agree, retiring the assertion in silence.
      const parentId = answerParentIdProbe(sql, params, parentIds);
      if (parentId) return parentId;
      if (/^SELECT \* FROM `flow_recipe_steps`/i.test(norm)) return [{ id: '8d32f4fc-25e5-40cb-8f60-f36eae4b0dc9', recipe_id: storedVia }];
      if (/^SELECT/i.test(norm) && /FROM `flow_recipes`/.test(sql) && /owner_id/.test(sql)) {
        return [{ owner_id: rependOwner }];
      }
      if (/^SELECT/i.test(norm)) return [{ id: '8d32f4fc-25e5-40cb-8f60-f36eae4b0dc9', recipe_id: storedVia }];
      return { affectedRows: 1, insertId: '8d32f4fc-25e5-40cb-8f60-f36eae4b0dc9' };
    },
  };
}

function mountApp(user, routeOpts, conn) {
  require.cache[dbKey] = {
    id: dbKey, filename: dbKey, loaded: true,
    exports: {
      pool: { rw: { getConnection: async () => conn }, ro: { query: async () => [{ owner_id: user.id }] } },
      t: (x) => x,
      getDynamicPool: async () => ({ rw: { getConnection: async () => conn }, ro: { query: async () => [] } }),
    },
  };
  for (const k of Object.keys(require.cache)) {
    if (k.startsWith(schemaDir)) delete require.cache[k];
  }
  const { createCrudRoutes } = require(schemaKey);
  const a = express();
  a.use(express.json());
  a.use((req, _res, next) => { req.user = user; next(); });
  a.use('/', createCrudRoutes('flow_recipe_steps', routeOpts));
  return a;
}

async function req(a, method, path, body) {
  const server = a.listen(0);
  const port = server.address().port;
  try {
    const res = await fetch(`http://127.0.0.1:${port}${path}`, {
      method, headers: { 'content-type': 'application/json' }, body: body && JSON.stringify(body),
    });
    const json = await res.json().catch(() => ({}));
    return { status: res.status, json };
  } finally { server.close(); }
}

const REPEND = {
  table: TABLES.FLOW_RECIPES,
  via: 'recipe_id',
  statusCol: 'status',
  clearCols: ['approved_by', 'approved_at'],
  repandFrom: ['approved', 'rejected'],
};
const OWNERSHIP = { via: 'recipe_id', chain: [{ table: TABLES.FLOW_RECIPES, match: 'id', readOwner: 'owner_id' }] };

describe('parent re-pend — ownerCol interpolation', () => {
  test('owner-gate SELECT uses the configured ownerCol, not a hardcoded literal', async () => {
    const captured = [];
    const conn = makeConn(captured, { storedVia: '1aaaaaaa-0000-4000-8000-000000000001', rependOwner: '405279b5-48c7-4bd5-8427-69d6ff5556a7' });
    const app = mountApp({ id: '405279b5-48c7-4bd5-8427-69d6ff5556a7', role: 'editor' }, {
      allowedRoles: ['admin', 'editor'],
      parentOwnership: OWNERSHIP,
      parentRepend: { ...REPEND, ownerCol: 'owner_uid' },
      filterableColumns: ['recipe_id'],
    }, conn);
    const { status } = await req(app, 'PUT', '/8d32f4fc-25e5-40cb-8f60-f36eae4b0dc9', { name: 'edited' });
    assert.equal(status, 200, 'PUT succeeds');
    const parentReads = captured.filter((q) => /FOR UPDATE/.test(q.sql) && /FROM `flow_recipes`/.test(q.sql));
    const repend = parentReads.find((q) => /AS status/.test(q.sql));
    assert.ok(repend, 'expected a parent re-pend FOR UPDATE SELECT');
    assert.match(repend.sql, /`owner_uid` AS owner_id/, 'owner-gate must interpolate ownerCol');
    assert.doesNotMatch(repend.sql, /`owner_id` AS owner_id/, 'must not use a hardcoded owner_id literal');

    // THE EXISTENCE QUESTION IS ASKED SEPARATELY, and it must name no column the
    // parent table might not have. `statusCol` / `ownerCol` are additive on a
    // no-ALTER install; asked in the same statement, their errno 1054 swallowed
    // the existence answer with them and the guard reported the parent present
    // without ever looking for it.
    const probe = parentReads.find((q) => !/AS status/.test(q.sql));
    assert.ok(probe, 'expected a standalone parent-existence FOR UPDATE SELECT');
    assert.match(probe.sql, /^SELECT id FROM `flow_recipes` WHERE id = \? FOR UPDATE$/);
    assert.equal(
      parentReads.indexOf(probe), 0,
      'the existence probe must be the first thing asked of the parent',
    );
  });
});

describe('parent re-pend — deadlock-safe lock order on admin re-parent', () => {
  async function lockOrderFor(storedVia, destVia) {
    const captured = [];
    // The recipes table holds exactly these two spellings — including an
    // uppercase one, which is the whole point of the divergent-case case.
    const conn = makeConn(captured, {
      storedVia, rependOwner: null, parentIds: [storedVia, destVia],
    });
    const app = mountApp({ id: '5b729f1e-5c0b-447c-8144-3210469bc62c', role: 'admin' }, {
      allowedRoles: ['admin', 'editor'],
      parentOwnership: OWNERSHIP,
      parentRepend: { ...REPEND },
      filterableColumns: ['recipe_id'],
    }, conn);
    const { status } = await req(app, 'PUT', '/8d32f4fc-25e5-40cb-8f60-f36eae4b0dc9', { recipe_id: destVia });
    assert.equal(status, 200, 'PUT succeeds');
    // The ORDER PARENT ROWS ARE FIRST LOCKED IN, which is the deadlock-relevant
    // fact and the only one this suite is about. Each parent is now read twice
    // under the same lock (existence, then approval state), so consecutive reads
    // of one id collapse to the one acquisition they represent — a count of
    // statements would make these assertions depend on how many questions the
    // re-pend happens to ask.
    return captured
      .filter((q) => /FOR UPDATE/.test(q.sql) && /FROM `flow_recipes`/.test(q.sql))
      .map((q) => q.params[0])
      .filter((id, i, all) => i === 0 || all[i - 1] !== id);
  }

  test('stored<dest → locks acquired low,high', async () => {
    assert.deepEqual(await lockOrderFor('1aaaaaaa-0000-4000-8000-000000000001', '9fffffff-0000-4000-8000-000000000009'), ['1aaaaaaa-0000-4000-8000-000000000001', '9fffffff-0000-4000-8000-000000000009']);
  });

  test('stored>dest → locks STILL acquired low,high (sorted, not issue order)', async () => {
    assert.deepEqual(await lockOrderFor('9fffffff-0000-4000-8000-000000000009', '1aaaaaaa-0000-4000-8000-000000000001'), ['1aaaaaaa-0000-4000-8000-000000000001', '9fffffff-0000-4000-8000-000000000009']);
  });

  test('admin keeps same parent (stored===dest) → Set de-dupes to one lock', async () => {
    assert.deepEqual(await lockOrderFor('1aaaaaaa-0000-4000-8000-000000000001', '1aaaaaaa-0000-4000-8000-000000000001'), ['1aaaaaaa-0000-4000-8000-000000000001']);
  });

  // Parent ids are CHAR(36) under MariaDB's case-insensitive collation, so the
  // lock order must be canonical (lowercase) — a case-sensitive JS sort would let
  // two re-parents using different-case ids for the same pair deadlock anyway.
  //
  // THE PAIR IS THE WHOLE TEST. Raw byte order and canonical order must
  // DISAGREE for these two ids, or the assertion passes whether or not the
  // production code lowercases anything and this case asserts nothing. `F`
  // (0x46) sorts before `a` (0x61) as bytes; `f` sorts after `a` once both are
  // folded — so the expected order below is only reachable through the
  // canonical key. Any replacement pair must keep that property: two ids whose
  // first point of difference is a digit (or a same-case letter) makes the two
  // orders agree and quietly retires this test.
  const UPPER_F = 'F1111111-1111-4111-8111-111111111111';
  const LOWER_A = 'a2222222-2222-4222-8222-222222222222';

  test('the fixture pair is one raw byte order gets wrong', () => {
    assert.deepEqual(
      [UPPER_F, LOWER_A].sort(), [UPPER_F, LOWER_A],
      'a raw sort must put the uppercase id FIRST for this case to discriminate',
    );
    assert.deepEqual(
      [UPPER_F, LOWER_A].sort((a, b) => a.toLowerCase().localeCompare(b.toLowerCase())),
      [LOWER_A, UPPER_F],
      'a canonical sort must put the lowercase id first — if the two orders agree, '
      + 'the assertions below hold with or without the canonicalisation they exist to check',
    );
  });

  test('case-divergent ids sort by canonical lowercase key (stable across case)', async () => {
    assert.deepEqual(await lockOrderFor(UPPER_F, LOWER_A), [LOWER_A, UPPER_F]);
    assert.deepEqual(await lockOrderFor(LOWER_A, UPPER_F), [LOWER_A, UPPER_F]);
  });

  test('same row in different case (stored vs dest) collapses to one lock', async () => {
    const order = await lockOrderFor('1aaaaaaa-0000-4000-8000-000000000001', '1AAAAAAA-0000-4000-8000-000000000001');
    assert.equal(order.length, 1, 'a case-only difference is the same DB row → one lock');
  });
});
