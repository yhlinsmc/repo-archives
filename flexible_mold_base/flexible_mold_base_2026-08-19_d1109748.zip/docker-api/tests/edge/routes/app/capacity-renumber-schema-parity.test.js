/**
 * capacity-renumber-schema-parity.test.js — pins every column the B5b renumber
 * routes (renumber.js) read/write against the ACTUAL table DDL. The node:test
 * route mocks stub query results, so a SELECT/UPDATE that names a column the table
 * does not have stays green in both runners yet 500s in production. This test
 * parses docker-api/src/table-ddls and asserts each referenced column exists (no
 * live DB).
 */
const { describe, it, before } = require('node:test');
const assert = require('node:assert/strict');

const dbKey = require.resolve('../../../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: {}, t: (n) => n },
};

const { buildEngineTableDDLs } = require('../../../../src/table-ddls');

const SQL_TYPES = /^`?([a-z_]+)`?\s+(?:CHAR|VARCHAR|INT|DOUBLE|TIMESTAMP|JSON|TEXT|ENUM|BOOLEAN|TINYINT|BIGINT|DATETIME|DECIMAL|FLOAT|BLOB)\b/i;
let columnsByTable;

before(() => {
  columnsByTable = new Map();
  for (const ddl of buildEngineTableDDLs((n) => n)) {
    const m = ddl.match(/CREATE TABLE IF NOT EXISTS `([^`]+)`/);
    if (!m) continue;
    const cols = new Set();
    for (const rawLine of ddl.split('\n')) {
      const line = rawLine.trim();
      if (!line || line.startsWith('--') || line.startsWith('/*')) continue;
      const cm = line.match(SQL_TYPES);
      if (cm) cols.add(cm[1]);
    }
    columnsByTable.set(m[1], cols);
  }
});

// Every column renumber.js names, per table it touches.
const RENUMBER_COLUMNS = {
  // entity reads: id/name/order_index/site_id (+ vm_type on cap_vms) + the
  // scenario_id predicate; name is UPDATE'd.
  cap_hypervisors: ['id', 'name', 'order_index', 'site_id', 'scenario_id', 'name_locked'],
  // function_name (ap-vm-function PR-2): the ap_vm {function} renumber source,
  // added to readTableRows' SELECT (degraded-schema guarded, like name_locked).
  cap_vms: ['id', 'name', 'order_index', 'site_id', 'scenario_id', 'vm_type', 'name_locked', 'function_name'],
  // the {dc} slug source
  cap_sites: ['id', 'name', 'scenario_id'],
  // the effective-pattern read (scenario override + global) + the global-row
  // lock apply takes before it (lockGlobalConfig: SELECT id ... FOR UPDATE)
  cap_settings: ['scenario_id', 'name_patterns', 'id'],
  // the ownership gate (resolveScenarioWriteAccess)
  cap_scenarios: ['id', 'owner_id'],
  // cap-pattern-function (Task 2.3): readHostFunctionRoles' JOIN — the
  // {function}/role resolution source. PR-3 adds name + order_index + id: the
  // preview serializes each db_host's instances as `contents` pills in a
  // deterministic (order_index, id) order.
  cap_db_instances: ['vm_id', 'role', 'database_id', 'scenario_id', 'name', 'order_index', 'id'],
  // topology (spec §7 E2): readDbInstanceRows' JOIN — the DB-instance-name
  // renumber's second input (functionName is function_name, already listed).
  // scenario_id (X2): the preview join's `AND d.scenario_id = di.scenario_id`
  // constraint — a foreign-scenario database_id must not resolve.
  cap_databases: ['id', 'function_name', 'order_index', 'topology', 'scenario_id'],
};

describe('capacity renumber schema parity', () => {
  it('every column the renumber routes read/write exists on its table', () => {
    for (const [table, cols] of Object.entries(RENUMBER_COLUMNS)) {
      const actual = columnsByTable.get(table);
      assert.ok(actual && actual.size > 0, `no columns parsed for ${table}`);
      for (const col of cols) {
        assert.ok(actual.has(col), `${table} is missing ${col} (a renumber query would 500)`);
      }
    }
  });

  // Apply locks each entity table `ORDER BY id FOR UPDATE` (the canonical lock
  // order shared with placement-apply). Every locked table must declare id.
  it('the entity tables declare the id column the FOR UPDATE lock scan sorts by', () => {
    for (const table of ['cap_hypervisors', 'cap_vms', 'cap_db_instances']) {
      assert.ok(columnsByTable.get(table).has('id'), `${table} missing id (lock-order column)`);
    }
  });

  // The apply's MAX_HOSTNAME_LENGTH (255) is the VARCHAR width of the name column;
  // pin it against a DDL change so the over-limit guard can never silently drift
  // from the column it protects (Codex R2 P2-2).
  it('the name column is VARCHAR(255) on both entity tables (the over-limit guard bound)', () => {
    const ddls = new Map();
    for (const ddl of buildEngineTableDDLs((n) => n)) {
      const m = ddl.match(/CREATE TABLE IF NOT EXISTS `([^`]+)`/);
      if (m) ddls.set(m[1], ddl);
    }
    for (const table of ['cap_hypervisors', 'cap_vms', 'cap_db_instances']) {
      const ddl = ddls.get(table);
      assert.ok(ddl, `no DDL for ${table}`);
      assert.match(ddl, /name\s+VARCHAR\(255\)/, `${table}.name must be VARCHAR(255) to match MAX_HOSTNAME_LENGTH`);
    }
  });
});
