/**
 * reference-integrity.test.js — §17.1a shared reference-integrity write
 * validator (capacity/reference-integrity.js). Covers the pure predicate across
 * all three modes + the DB-fetching wrapper (mock handle).
 */
'use strict';

const { describe, it } = require('node:test');
const assert = require('node:assert/strict');

// Stub edge/db BEFORE requiring the validator (which calls t() to build SQL) so
// the unit test needs no configured pool — mirrors capacity-routes.test.js.
const dbKey = require.resolve('../../../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: { ro: {}, rw: {} }, t: (n) => `fmb_${n}` },
};

const {
  referenceOk, checkReferences, messageForMode, canonicalKey,
} = require('../../../../src/edge/routes/app/capacity/reference-integrity');

// A referenced row as `checkReferences` hands it to the predicate: the row's own
// `scenario_id`, plus `same_scenario` — the ENGINE's verdict on whether that is
// the referencing scenario, projected by the probe statement. The predicate no
// longer forms an opinion of its own about two ids being one id, because
// `scenario_id` is CHAR(36) under a case-folding collation and a JavaScript
// comparison was the narrowest of the three opinions in that path.
const GLOBAL = { scenario_id: null, same_scenario: null };
const SAME = { scenario_id: 'scn-1', same_scenario: 1 };
const OTHER = { scenario_id: 'scn-2', same_scenario: 0 };

describe('referenceOk — catalogue mode (global OR same-scenario)', () => {
  it('accepts a global row', () => {
    assert.equal(referenceOk(GLOBAL, { mode: 'catalogue' }), true);
  });
  it('accepts a same-scenario local row', () => {
    assert.equal(referenceOk(SAME, { mode: 'catalogue' }), true);
  });
  it('REJECTS another scenario local row (the core §17.1a gap)', () => {
    assert.equal(referenceOk(OTHER, { mode: 'catalogue' }), false);
  });
  it('rejects a missing (not-found) row', () => {
    assert.equal(referenceOk(null, { mode: 'catalogue' }), false);
    assert.equal(referenceOk(undefined, { mode: 'catalogue' }), false);
  });
  it('treats undefined scenario_id as global', () => {
    assert.equal(referenceOk({}, { mode: 'catalogue' }), true);
  });
  it('defaults to catalogue mode when mode omitted', () => {
    assert.equal(referenceOk(GLOBAL, {}), true);
    assert.equal(referenceOk(OTHER, {}), false);
  });
  it('refuses a scenario-local row when the verdict was never projected', () => {
    // Fail-closed. A caller that fetched the row without the projected column
    // must not be answered "same scenario" by default — the reference is
    // narrowed to global rows only rather than silently widened.
    assert.equal(referenceOk({ scenario_id: 'scn-1' }, { mode: 'catalogue' }), false);
  });
});

describe('referenceOk — scenario mode (same-scenario ONLY, global not valid)', () => {
  it('accepts a same-scenario row', () => {
    assert.equal(referenceOk(SAME, { mode: 'scenario' }), true);
  });
  it('REJECTS a global row (scenario-internal objects are never global)', () => {
    assert.equal(referenceOk(GLOBAL, { mode: 'scenario' }), false);
  });
  it('rejects another scenario row', () => {
    assert.equal(referenceOk(OTHER, { mode: 'scenario' }), false);
  });
  it('rejects a missing row', () => {
    assert.equal(referenceOk(null, { mode: 'scenario' }), false);
  });
  it('refuses when the verdict was never projected', () => {
    assert.equal(referenceOk({ scenario_id: 'scn-1' }, { mode: 'scenario' }), false);
  });
});

describe('referenceOk — global mode (bundles → global rows only)', () => {
  it('accepts a global row', () => {
    assert.equal(referenceOk(GLOBAL, { mode: 'global' }), true);
  });
  it('REJECTS a scenario-local row (a bundle cannot reference a local row)', () => {
    assert.equal(referenceOk(SAME, { mode: 'global' }), false);
    assert.equal(referenceOk(OTHER, { mode: 'global' }), false);
  });
  it('rejects a missing row', () => {
    assert.equal(referenceOk(null, { mode: 'global' }), false);
  });
});

describe('messageForMode', () => {
  it('names the reference kind per mode', () => {
    assert.match(messageForMode('spec_id', 'catalogue'), /global or same-scenario/);
    assert.match(messageForMode('vm_id', 'scenario'), /in this scenario/);
    assert.match(messageForMode('profile_id', 'global'), /global catalogue row/);
  });
});

/**
 * Minimal mock DB handle: resolves the probe statement from a fixture keyed by
 * id. Returns [] for an unknown id (a not-found reference).
 *
 * IT COMPUTES `same_scenario` RATHER THAN BEING TOLD IT. The probe now asks the
 * engine whether the referenced row is in the referencing scenario, so a
 * fixture that carried a hand-written verdict would be asserting on its own
 * answer — and the case-fold is exactly the thing that made the JavaScript
 * comparison wrong. This folds ASCII case the way the column's collation does
 * and nothing else. Whether the real column carries that collation is settled on
 * a real database (tests/integration/capacity-write-identity-real-db.test.js).
 *
 * The bound parameters are (referencingScenarioId, id) in that order, and
 * reading the id from the second slot is what keeps this double honest about
 * the statement it stands in for.
 */
function mockHandle(rowsById) {
  // AND IT RESOLVES THE ROW THE WAY `WHERE id = ?` DOES. The fixture is keyed
  // by the STORED id; the probe binds whatever spelling the caller asked with,
  // and the column folds case. A double that looked the key up exactly would
  // answer "no such row" for the one input class the canonical rebinding exists
  // for — the change could not be seen from here at all. It hands `id` back for
  // the same reason: the real statement projects it, and it is the value every
  // caller now binds.
  const byFolded = new Map(Object.keys(rowsById).map((k) => [k.toLowerCase(), k]));
  return {
    async query(_sql, params) {
      const [referencingScenarioId, id] = params;
      const storedId = id == null ? undefined : byFolded.get(String(id).toLowerCase());
      if (storedId === undefined) return [];
      const row = rowsById[storedId];
      const owner = row.scenario_id;
      const same = owner != null && referencingScenarioId != null
        && String(owner).toLowerCase() === String(referencingScenarioId).toLowerCase();
      // `scenario_id = ?` yields NULL — not 0 — when either side is NULL.
      return [{
        id: storedId,
        ...row,
        same_scenario: owner == null || referencingScenarioId == null ? null : (same ? 1 : 0),
      }];
    },
  };
}

// Identifier-shaped, and ORDERED, because the assertion below is about the
// order the probes run in: the lock protocol sorts by (table, value), so the
// two hardware-spec ids have to be a known way round. `checkReferences`
// refuses a value that is not identifier-shaped before it probes anything,
// which is why the one-letter ids these used to be no longer serve.
const [AATOKEN, BBTOKEN] = ['3e23e816-0039-494a-8389-4f6564e1b134', '594e519a-e499-412b-8943-3b7dd8a97ff0'].sort();
const ZZTOKEN = 'f0e1d2c3-b4a5-4968-8778-695a4b3c2d1e';

describe('checkReferences — DB wrapper', () => {
  it('passes when every catalogue ref is global or same-scenario', async () => {
    const handle = mockHandle({ 'cd0aa985-6147-46c5-84ff-2b7dfee5da20': { scenario_id: null }, '043a7187-74c5-42bd-8a25-adbeb1bfcd5c': { scenario_id: 'scn-1' } });
    const res = await checkReferences(handle, 'scn-1', [
      { column: 'profile_id', value: 'cd0aa985-6147-46c5-84ff-2b7dfee5da20', table: 'cap_vm_profiles', mode: 'catalogue' },
      { column: 'team_id', value: '043a7187-74c5-42bd-8a25-adbeb1bfcd5c', table: 'cap_teams', mode: 'catalogue' },
    ]);
    assert.equal(res.ok, true);
    // And it reports which row each reference RESOLVED to, per (table, asked
    // spelling) — the value its callers bind.
    assert.equal(
      res.canonical.get(canonicalKey('cap_vm_profiles', 'cd0aa985-6147-46c5-84ff-2b7dfee5da20')),
      'cd0aa985-6147-46c5-84ff-2b7dfee5da20',
    );
  });

  it('rejects a catalogue ref pointing at ANOTHER scenario (INVALID_REFERENCE)', async () => {
    const handle = mockHandle({ '65c74c15-a686-487b-86bb-f9958f494fc6': { scenario_id: 'scn-2' } });
    const res = await checkReferences(handle, 'scn-1', [
      { column: 'disk_combo_id', value: '65c74c15-a686-487b-86bb-f9958f494fc6', table: 'cap_disk_combos', mode: 'catalogue' },
    ]);
    assert.equal(res.ok, false);
    assert.equal(res.column, 'disk_combo_id');
    assert.equal(res.code, 'INVALID_REFERENCE');
  });

  it('rejects a global bundle-item ref pointing at a scenario-local row', async () => {
    const handle = mockHandle({ 'a7f32380-cf33-4659-8523-17bd08b28706': { scenario_id: 'scn-9' } });
    const res = await checkReferences(handle, undefined, [
      { column: 'profile_id', value: 'a7f32380-cf33-4659-8523-17bd08b28706', table: 'cap_vm_profiles', mode: 'global' },
    ]);
    assert.equal(res.ok, false);
    assert.equal(res.code, 'INVALID_REFERENCE');
  });

  it('skips a null/undefined value (unset nullable FK)', async () => {
    const handle = mockHandle({});
    const res = await checkReferences(handle, 'scn-1', [
      { column: 'team_id', value: null, table: 'cap_teams', mode: 'catalogue' },
      { column: 'disk_combo_id', value: undefined, table: 'cap_disk_combos', mode: 'catalogue' },
    ]);
    assert.equal(res.ok, true);
    assert.equal(res.canonical.size, 0, 'an unset nullable FK is not a reference to rebind');
  });

  it('rejects a missing referenced row', async () => {
    const handle = mockHandle({});
    const res = await checkReferences(handle, 'scn-1', [
      { column: 'spec_id', value: 'ead6ef03-d61e-460c-833d-6d450c50a1e5', table: 'cap_hardware_specs', mode: 'catalogue' },
    ]);
    assert.equal(res.ok, false);
    assert.equal(res.code, 'INVALID_REFERENCE');
  });

  it('enforces requireVmType on a scenario ref (db_host guard)', async () => {
    const handle = mockHandle({ '3f3474c8-c9fa-4542-8803-03ea9c2af5b6': { scenario_id: 'scn-1', vm_type: 'ap_host' } });
    const res = await checkReferences(handle, 'scn-1', [
      { column: 'vm_id', value: '3f3474c8-c9fa-4542-8803-03ea9c2af5b6', table: 'cap_vms', mode: 'scenario', requireVmType: 'db_host' },
    ]);
    assert.equal(res.ok, false);
    assert.equal(res.code, 'INVALID_PARENT_TYPE');
  });

  it('accepts a same-scenario db_host VM for a requireVmType ref', async () => {
    const handle = mockHandle({ '80da3ccc-a3cd-4787-8518-59fbb6b61f44': { scenario_id: 'scn-1', vm_type: 'db_host' } });
    const res = await checkReferences(handle, 'scn-1', [
      { column: 'vm_id', value: '80da3ccc-a3cd-4787-8518-59fbb6b61f44', table: 'cap_vms', mode: 'scenario', requireVmType: 'db_host' },
    ]);
    assert.equal(res.ok, true);
  });

  it('reports the STORED id for a reference asked for by another spelling', async () => {
    // The half a reference check on its own does not do. `id` is `CHAR(36)`
    // under a case-folding collation, so this reference is legal — and a caller
    // that went on to bind its own spelling would store a value every SQL reader
    // resolves and no JavaScript reader does. The stored id is reported so the
    // statement can bind it.
    const stored = 'cd0aa985-6147-46c5-84ff-2b7dfee5da20';
    const handle = mockHandle({ [stored]: { scenario_id: null } });
    const asked = stored.toUpperCase();
    const res = await checkReferences(handle, 'scn-1', [
      { column: 'profile_id', value: asked, table: 'cap_vm_profiles', mode: 'catalogue' },
    ]);
    assert.equal(res.ok, true, 'the reference was refused, so the case cannot say what it stores');
    assert.equal(res.canonical.get(canonicalKey('cap_vm_profiles', asked)), stored);
  });

  it('reports nothing for a reference it REFUSED', async () => {
    // A rejected reference is not a value any statement goes on to bind, and an
    // entry for it would invite a caller to bind one.
    const handle = mockHandle({ '65c74c15-a686-487b-86bb-f9958f494fc6': { scenario_id: 'scn-2' } });
    const res = await checkReferences(handle, 'scn-1', [
      { column: 'disk_combo_id', value: '65c74c15-a686-487b-86bb-f9958f494fc6', table: 'cap_disk_combos', mode: 'catalogue' },
    ], { lock: true });
    assert.equal(res.ok, false);
    assert.equal(res.canonical, undefined);
  });

  it('rejects a scenario-mode ref that resolves to a global row', async () => {
    const handle = mockHandle({ 'cd0aa985-6147-46c5-84ff-2b7dfee5da20': { scenario_id: null } });
    const res = await checkReferences(handle, 'scn-1', [
      { column: 'database_id', value: 'cd0aa985-6147-46c5-84ff-2b7dfee5da20', table: 'cap_databases', mode: 'scenario' },
    ]);
    assert.equal(res.ok, false);
    assert.equal(res.code, 'INVALID_REFERENCE');
  });

  it('probes in canonical (table, value) order regardless of spec order (deadlock guard)', async () => {
    const seen = [];
    const handle = {
      async query(sql, params) {
        const table = sql.match(/FROM `([^`]+)`/)[1];
        // The id is the SECOND bound parameter — the referencing scenario is
        // bound first, for the projected comparison.
        seen.push(`${table}:${params[1]}`);
        return [{ id: params[1], scenario_id: null, same_scenario: null }];
      },
    };
    // Specs supplied out of order; probes must run table-then-value sorted.
    const res = await checkReferences(handle, 'scn-1', [
      { column: 'team_id', value: ZZTOKEN, table: 'cap_teams', mode: 'catalogue' },
      { column: 'spec_id', value: BBTOKEN, table: 'cap_hardware_specs', mode: 'catalogue' },
      { column: 'spec_id', value: AATOKEN, table: 'cap_hardware_specs', mode: 'catalogue' },
    ], { lock: true });
    assert.equal(res.ok, true);
    assert.deepEqual(seen, [
      `fmb_cap_hardware_specs:${AATOKEN}`, `fmb_cap_hardware_specs:${BBTOKEN}`, `fmb_cap_teams:${ZZTOKEN}`,
    ]);
  });
});
