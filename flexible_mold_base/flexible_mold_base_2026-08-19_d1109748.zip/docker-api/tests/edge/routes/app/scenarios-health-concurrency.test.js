/**
 * scenarios-health-concurrency.test.js — GET /scenarios/health fans out up to
 * 17 aggregate queries (13 FK probes + 4 other aggregates) against pool.ro,
 * whose connectionLimit is 10 (db.js) — firing them all at once can occupy the
 * entire reader pool and queue unrelated traffic. This pins the bound: a
 * delayed mock pool counts how many pool.ro.query calls are in flight at once
 * and asserts the max never exceeds the handler's configured limit.
 */
const { describe, it, before, after } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

// Mock edge/db BEFORE requiring the scenarios router (it + _shared + schema all
// pull { pool, t } from ../../../db at load).
const dbKey = require.resolve('../../../../src/edge/db');

// Must match HEALTH_QUERY_CONCURRENCY in scenarios.js.
const HEALTH_CONCURRENCY_BOUND = 4;

let inFlight = 0;
let maxInFlight = 0;

function delayedRows(rows) {
  inFlight += 1;
  maxInFlight = Math.max(maxInFlight, inFlight);
  return new Promise((resolve) => {
    setTimeout(() => {
      inFlight -= 1;
      resolve(rows);
    }, 5);
  });
}

const roPool = {
  query: async (sql) => {
    // Seed query (scenario id list) runs outside the fan-out — not delayed.
    if (/SELECT id FROM `fmb_cap_scenarios`/i.test(sql)) {
      return [{ id: 'S1' }];
    }
    // Every other aggregate the handler issues (base counts, the 13 FK
    // probes, the two bespoke integrity probes) goes through the SAME
    // limiter — none of these delayed calls should ever exceed the bound.
    return delayedRows([]);
  },
  getConnection: async () => ({
    beginTransaction: async () => {}, commit: async () => {},
    rollback: async () => {}, release: () => {}, query: async () => [],
  }),
};

require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: { ro: roPool, rw: roPool }, t: (n) => `fmb_${n}` },
};

const scenariosRouter = require('../../../../src/edge/routes/app/capacity/scenarios');

let server; let baseUrl;
before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { req.user = { id: 'user-1', role: 'user' }; next(); });
  app.use('/scenarios', scenariosRouter);
  server = http.createServer(app);
  await new Promise((r) => server.listen(0, r));
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});
after(() => server && server.close());

function get(path) {
  return new Promise((resolve, reject) => {
    const r = http.request(`${baseUrl}${path}`, { method: 'GET' }, (res) => {
      let data = '';
      res.on('data', (c) => { data += c; });
      res.on('end', () => resolve({ status: res.statusCode, body: data ? JSON.parse(data) : null }));
    });
    r.on('error', reject);
    r.end();
  });
}

describe('GET /scenarios/health RO query concurrency bound', () => {
  it('never issues more than the configured limit of concurrent RO pool queries at once', async () => {
    const res = await get('/scenarios/health');
    assert.equal(res.status, 200);
    // Sanity: the delayed mock (base aggregates + 13 FK probes + the two
    // bespoke integrity probes = 16 calls) must have actually been exercised
    // for maxInFlight to be a meaningful measurement.
    assert.ok(maxInFlight > 0, 'sanity: the delayed mock must have been exercised');
    assert.ok(
      maxInFlight <= HEALTH_CONCURRENCY_BOUND,
      `expected max in-flight RO queries <= ${HEALTH_CONCURRENCY_BOUND}, saw ${maxInFlight}`,
    );
  });
});
