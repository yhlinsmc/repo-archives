'use strict';

/**
 * hidden-field-disclosure-schema-parity.test.js — every column the disclosure
 * statement names, checked against the DDL, without a database.
 *
 * The route test stubs the driver, so it returns whatever the fixture calls a
 * column and a misspelled one stays green in both runners while 500ing in
 * production. This parses the statement out of the handler and asks
 * table-ddls.js — the only authority on the schema — whether each column exists
 * on the table it is read from.
 */
const { describe, it, before } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const dbKey = require.resolve('../../../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: {}, t: (n) => n },
};

const { buildEngineTableDDLs } = require('../../../../src/table-ddls');
const { TABLES } = require('../../../../src/shared/constants');

const SQL_TYPES = /^`?([a-z_]+)`?\s+(?:CHAR|VARCHAR|INT|DOUBLE|TIMESTAMP|JSON|TEXT|ENUM|BOOLEAN|TINYINT|BIGINT|DATETIME|DECIMAL|FLOAT|BLOB)\b/i;
let columnsByTable;

before(() => {
  columnsByTable = new Map();
  for (const ddl of buildEngineTableDDLs((n) => n)) {
    const m = ddl.match(/CREATE TABLE IF NOT EXISTS `([^`]+)`/);
    if (!m) continue;
    const cols = new Set();
    for (const rawLine of ddl.split('\n')) {
      const line = rawLine.trim();
      if (!line || line.startsWith('--') || line.startsWith('/*')) continue;
      const cm = line.match(SQL_TYPES);
      if (cm) cols.add(cm[1]);
    }
    columnsByTable.set(m[1], cols);
  }
});

// Read from the source rather than restating it: an assertion that hand-copies
// the column list is a second opinion about the statement, and it agrees right
// up until the statement is edited.
const SOURCE = fs.readFileSync(
  path.resolve(__dirname, '../../../../src/edge/routes/app/schema/routes-hidden-field-disclosure.js'),
  'utf-8',
);

/**
 * Every `<alias>.<column>` reference in the disclosure statement.
 *
 * The statement is built by a `selectSql(withCellTargets)` template — the
 * cell_targets column is conditional (see the module comment: an absent
 * column must not throw ER_BAD_FIELD_ERROR) — so the end marker is the
 * literal's own closing backtick+semicolon, not the `` `, `` a query call's
 * second argument used to produce. The conditional branch's text
 * (`o.cell_targets AS override_cell_targets`) is still present verbatim in
 * this source range regardless of which way the ternary evaluates at
 * runtime, so the same static regex still finds it.
 */
function referencesByAlias() {
  const start = SOURCE.indexOf('SELECT f.field_key');
  assert.ok(start > 0, 'the disclosure statement no longer starts where this test looks');
  const end = SOURCE.indexOf('f.field_key`;', start);
  assert.ok(end > start, 'the disclosure statement no longer ends where this test looks');
  const sql = SOURCE.slice(start, end);
  const out = new Map([['f', new Set()], ['o', new Set()]]);
  for (const m of sql.matchAll(/\b([fo])\.([a-z_]+)\b/g)) out.get(m[1]).add(m[2]);
  return out;
}

describe('hidden-field-disclosure schema parity', () => {
  it('every f.<column> exists on blueprint_fields', () => {
    const cols = columnsByTable.get(String(TABLES.BLUEPRINT_FIELDS));
    assert.ok(cols && cols.size > 0, 'no columns parsed for blueprint_fields');
    for (const col of referencesByAlias().get('f')) {
      assert.ok(cols.has(col), `blueprint_fields has no column '${col}'`);
    }
  });

  it('every o.<column> exists on variant_overrides', () => {
    const cols = columnsByTable.get(String(TABLES.VARIANT_OVERRIDES));
    assert.ok(cols && cols.size > 0, 'no columns parsed for variant_overrides');
    for (const col of referencesByAlias().get('o') ) {
      assert.ok(cols.has(col), `variant_overrides has no column '${col}'`);
    }
  });

  it('reads something from each side — an empty reference set would pass vacuously', () => {
    const refs = referencesByAlias();
    assert.ok(refs.get('f').size >= 6, `only ${refs.get('f').size} blueprint_fields columns found`);
    assert.ok(refs.get('o').size >= 3, `only ${refs.get('o').size} variant_overrides columns found`);
  });
});
