'use strict';

/**
 * capacity-child-delete-preview.test.js — the per-child delete-impact preview
 * (T3, spec §4). The point of the endpoint is that its three zones are computed
 * from the SAME CHILD_DELETE_BEHAVIOR the DELETE executes, so the strongest test
 * here seeds one fixture, previews it, then deletes it and asserts the preview's
 * counts equal the delete's reported counts — a disagreement is the defect the
 * one-source design exists to make unreachable.
 *
 * Real-DB: skips with a stated reason when none is reachable, fails instead of
 * skipping under REQUIRE_INTEGRATION_DB=1.
 */
const {
  test, describe, before, after, beforeEach,
} = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const net = require('node:net');
const http = require('node:http');
const express = require('express');
const mariadb = require('mariadb');

const TEST_PREFIX = 'cdp_';
const tbl = (name) => `${TEST_PREFIX}${name}`;

let pool = null;
const lease = () => pool.getConnection();
const handle = () => ({ getConnection: lease, query: (sql, params) => pool.query(sql, params) });

const dbKey = require.resolve('../../../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey,
  filename: dbKey,
  loaded: true,
  exports: {
    pool: { ro: handle(), rw: handle() },
    t: tbl,
    getDynamicPool: async () => ({ ro: handle(), rw: handle() }),
  },
};

const { buildEngineTableDDLs, buildInfraTableDDLs } = require('../../../../src/table-ddls');
const capacityRouter = require('../../../../src/edge/routes/app/capacity');

function parseEnvFile(filePath) {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    const out = {};
    for (const line of content.split('\n')) {
      const m = line.match(/^\s*([A-Z_][A-Z0-9_]*)\s*=\s*(.*)\s*$/);
      if (!m) continue;
      let value = m[2];
      if ((value.startsWith('"') && value.endsWith('"'))
        || (value.startsWith("'") && value.endsWith("'"))) value = value.slice(1, -1);
      out[m[1]] = value;
    }
    return out;
  } catch {
    return null;
  }
}

function probePort(host, port, timeoutMs = 2000) {
  return new Promise((resolve) => {
    const socket = new net.Socket();
    let done = false;
    const finish = (ok) => { if (done) return; done = true; socket.destroy(); resolve(ok); };
    socket.setTimeout(timeoutMs);
    socket.once('connect', () => finish(true));
    socket.once('timeout', () => finish(false));
    socket.once('error', () => finish(false));
    socket.connect(port, host);
  });
}

async function resolveMariaDbConfig() {
  if (process.env.DB_TEST_HOST && process.env.DB_TEST_ROOT_PASSWORD) {
    return {
      host: process.env.DB_TEST_HOST,
      port: parseInt(process.env.DB_TEST_PORT || '3306', 10),
      user: 'root',
      password: process.env.DB_TEST_ROOT_PASSWORD,
    };
  }
  const envPath = path.resolve(__dirname, '../../../../../.devcontainer/.env');
  const env = parseEnvFile(envPath);
  if (!env || !env.DB_ROOT_PASSWORD) return null;
  const port = parseInt(env.DB_PORT || '3306', 10);
  for (const host of ['127.0.0.1', 'mariadb', 'localhost']) {
    if (await probePort(host, port, 2000)) return { host, port, user: 'root', password: env.DB_ROOT_PASSWORD };
  }
  return null;
}

const ADMIN = { id: 'aa11bb22-cc33-4d44-8e55-ff6677889900', role: 'admin' };
const OTHER_EDITOR = { id: 'bb22cc33-dd44-4e55-8f66-001122334455', role: 'editor' };
const SCENARIO_ID = '11112222-3333-4444-8555-666677778888';

let dbReady = false;
let skipReason = null;
let testDbName = null;
let server = null;
let baseUrl = null;
let currentUser = ADMIN;

before(async () => {
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) {
    skipReason = 'no MariaDB reachable via .devcontainer/.env or env vars';
    if (process.env.REQUIRE_INTEGRATION_DB === '1') throw new Error(`REQUIRE_INTEGRATION_DB=1 set but ${skipReason}.`);
    return;
  }
  testDbName = `cap_child_preview_test_${process.pid}_${Date.now()}`;
  let admin = null;
  try {
    admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`CREATE DATABASE \`${testDbName}\``);
    await admin.query(`USE \`${testDbName}\``);
    for (const sql of [...buildInfraTableDDLs(tbl), ...buildEngineTableDDLs(tbl)]) await admin.query(sql);
    await admin.end();
    admin = null;
    pool = mariadb.createPool({
      ...dbConfig, database: testDbName, connectionLimit: 6, connectTimeout: 5000,
    });
    const app = express();
    app.use(express.json());
    app.use((req, _res, next) => { req.user = currentUser; next(); });
    app.use('/edge/app/capacity', capacityRouter);
    server = http.createServer(app);
    await new Promise((r) => server.listen(0, r));
    baseUrl = `http://127.0.0.1:${server.address().port}`;
    dbReady = true;
  } catch (err) {
    skipReason = `setup failed: ${err.message}`;
    if (admin) { try { await admin.end(); } catch { /* best effort */ } }
    if (process.env.REQUIRE_INTEGRATION_DB === '1') throw err;
  }
});

after(async () => {
  if (server) { try { server.close(); } catch { /* best effort */ } }
  if (pool) { try { await pool.end(); } catch { /* best effort */ } }
  if (!testDbName) return;
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) return;
  try {
    const admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`DROP DATABASE IF EXISTS \`${testDbName}\``);
    await admin.end();
  } catch { /* best effort */ }
});

async function call(user, method, url, body) {
  currentUser = user;
  const res = await fetch(`${baseUrl}${url}`, {
    method,
    headers: { 'content-type': 'application/json' },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const text = await res.text();
  let parsed = null;
  try { parsed = JSON.parse(text); } catch { parsed = { raw: text }; }
  return { status: res.status, body: parsed };
}

const q = (sql, params) => pool.query(sql, params);

const CAPACITY_TABLES = [
  'cap_waivers', 'cap_rules', 'cap_custom_group_members', 'cap_custom_groups',
  'cap_db_instances', 'cap_vms', 'cap_databases', 'cap_hypervisors', 'cap_sites',
  'cap_versions', 'cap_bundle_items', 'cap_bundles', 'cap_field_defs',
  'cap_vm_profiles', 'cap_disk_combos', 'cap_teams', 'cap_hardware_specs',
  'cap_settings', 'cap_scenarios',
];

const guard = (t) => {
  if (dbReady) return false;
  t.skip(skipReason || 'database not ready');
  return true;
};

beforeEach(async () => {
  if (!dbReady) return;
  for (const name of [...CAPACITY_TABLES, 'feature_audit', 'users']) await q(`DELETE FROM \`${tbl(name)}\``);
  await q(`INSERT INTO \`${tbl('users')}\` (id, email, role, banned) VALUES (?,?,?,0)`,
    [ADMIN.id, 'admin@test.local', 'admin']);
  await q(`INSERT INTO \`${tbl('users')}\` (id, email, role, banned) VALUES (?,?,?,0)`,
    [OTHER_EDITOR.id, 'editor@test.local', 'editor']);
  await q(`INSERT INTO \`${tbl('cap_scenarios')}\` (id, name, owner_id) VALUES (?,?,?)`,
    [SCENARIO_ID, 'a scenario', null]);
});

const base = `/edge/app/capacity/scenarios/${SCENARIO_ID}`;
const preview = (segment, id, user = ADMIN) => call(user, 'GET', `${base}/${segment}/${id}/delete-preview`);
const zoneKinds = (zone) => zone.map((e) => e.kind).sort();
const zoneCount = (zone, kind) => (zone.find((e) => e.kind === kind) || { count: 0 }).count;

async function seedSpec() {
  const spec = await call(ADMIN, 'POST', '/edge/app/capacity/config/hardware_specs',
    { name: 'spec-a', cpu_total: 64, mem_total_gb: 512, disk_total_gb: 4096 });
  assert.equal(spec.status, 201, JSON.stringify(spec.body));
  return spec.body.data.id;
}

// ── Site preview: three zones from one declaration set ───────────────────────

describe('a site preview names its hypervisors, their VMs, and its blockers', () => {
  test('will_delete = hypervisors, will_unplace = their VMs + pinned VMs, blocked = dc_refs', async (t) => {
    if (guard(t)) return;
    const specId = await seedSpec();
    const site = await call(ADMIN, 'POST', `${base}/sites`, { name: 'DC-A' });
    const siteId = site.body.data.id;
    const hv = await call(ADMIN, 'POST', `${base}/hypervisors`, { name: 'host-a', site_id: siteId, spec_id: specId });
    await call(ADMIN, 'POST', `${base}/vms`, { name: 'onhost', vm_type: 'ap_host', hypervisor_id: hv.body.data.id });
    await call(ADMIN, 'POST', `${base}/vms`, { name: 'pinned', vm_type: 'ap_host', site_id: siteId });
    await call(ADMIN, 'POST', `${base}/databases`, { function_name: 'ORDERS', topology: 'single', dc_refs: [siteId] });

    const res = await preview('sites', siteId);
    assert.equal(res.status, 200, JSON.stringify(res.body));
    const p = res.body.data;
    assert.equal(p.entity.name, 'DC-A');
    // The host is in will_delete; the VM standing on it AND the pinned VM are in
    // will_unplace (kind 'vm' appears for both the pinned site_id group and the
    // nested hypervisor_id group).
    assert.equal(zoneCount(p.will_delete, 'hypervisor'), 1);
    // Two VM groups: the pinned group (site_id → onhost + pinned, since a placed
    // VM's site is derived from its host) and the nested group (hypervisor_id →
    // onhost). onhost is in both — the delete NULLs both its columns, so the
    // per-group counts sum to 3 while the distinct VMs are 2 (this is exactly what
    // the DELETE reports, pinned by the one-source test below).
    // After the server-side merge there is ONE vm entry (a duplicate kind would
    // collide React keys downstream), and its count is the DISTINCT VMs unplaced:
    // onhost is cleared on both site_id and hypervisor_id but is one row, so the
    // pinned + hosted set is {onhost, pinned} = 2, not the 3 the per-column groups
    // would sum to.
    const vmGroups = p.will_unplace.filter((e) => e.kind === 'vm');
    assert.equal(vmGroups.length, 1, 'the two vm groups were not merged into one entry');
    assert.equal(vmGroups[0].count, 2, 'the dual-placed VM was double-counted');
    assert.deepEqual([...vmGroups[0].names].sort(), ['onhost', 'pinned']);
    // The dc_refs database blocks, and blocked_reason names it.
    assert.equal(zoneCount(p.blocked, 'database_dc_ref'), 1);
    assert.match(p.blocked_reason, /database restricted to this datacenter/);
  });
});

// ── Database preview ─────────────────────────────────────────────────────────

describe('a database preview names its instances and its db_host VM', () => {
  test('will_delete = instances, will_unplace = the db_host VM', async (t) => {
    if (guard(t)) return;
    const specId = await seedSpec();
    const site = await call(ADMIN, 'POST', `${base}/sites`, { name: 'DC-A' });
    const hv = await call(ADMIN, 'POST', `${base}/hypervisors`,
      { name: 'host-a', site_id: site.body.data.id, spec_id: specId });
    const vm = await call(ADMIN, 'POST', `${base}/vms`,
      { name: 'dbhost', vm_type: 'db_host', hypervisor_id: hv.body.data.id });
    const db = await call(ADMIN, 'POST', `${base}/databases`, { function_name: 'ORDERS', topology: 'primary_standby' });
    const dbId = db.body.data.id;
    await call(ADMIN, 'PUT', `${base}/vms/${vm.body.data.id}`, { database_id: dbId });
    for (const role of ['primary', 'standby']) {
      await call(ADMIN, 'POST', `${base}/db_instances`, { name: `i-${role}`, vm_id: vm.body.data.id, database_id: dbId, role });
    }

    const res = await preview('databases', dbId);
    assert.equal(res.status, 200, JSON.stringify(res.body));
    const p = res.body.data;
    assert.equal(zoneCount(p.will_delete, 'db_instance'), 2);
    assert.equal(zoneCount(p.will_unplace, 'vm'), 1);
    assert.deepEqual(zoneKinds(p.blocked), []);
    assert.equal(p.blocked_reason, null);
  });
});

// ── No dependents → the light confirm ────────────────────────────────────────

describe('an entity with no dependents previews all-empty', () => {
  test('a bare site reports empty zones (the FE renders a plain confirm)', async (t) => {
    if (guard(t)) return;
    const site = await call(ADMIN, 'POST', `${base}/sites`, { name: 'DC-Empty' });
    const res = await preview('sites', site.body.data.id);
    assert.equal(res.status, 200, JSON.stringify(res.body));
    const p = res.body.data;
    assert.deepEqual([p.will_delete, p.will_unplace, p.blocked], [[], [], []]);
    assert.equal(p.blocked_reason, null);
  });
});

// ── One source: the preview equals what the delete does ─────────────────────

describe('the preview counts equal the delete report on one fixture', () => {
  test('site: preview will_delete/will_unplace match the DELETE cascaded/unplaced', async (t) => {
    if (guard(t)) return;
    const specId = await seedSpec();
    const site = await call(ADMIN, 'POST', `${base}/sites`, { name: 'DC-A' });
    const siteId = site.body.data.id;
    const hv = await call(ADMIN, 'POST', `${base}/hypervisors`, { name: 'host-a', site_id: siteId, spec_id: specId });
    await call(ADMIN, 'POST', `${base}/vms`, { name: 'onhost', vm_type: 'ap_host', hypervisor_id: hv.body.data.id });
    await call(ADMIN, 'POST', `${base}/vms`, { name: 'pinned', vm_type: 'ap_host', site_id: siteId });

    const p = (await preview('sites', siteId)).body.data;
    const gone = await call(ADMIN, 'DELETE', `${base}/sites/${siteId}`);
    assert.equal(gone.status, 200, JSON.stringify(gone.body));

    // Hypervisors: 1 in will_delete === 1 cascaded.
    assert.equal(zoneCount(p.will_delete, 'hypervisor'), gone.body.data.cascaded['cap_hypervisors.site_id']);
    // VMs: the preview reports DISTINCT unplaced rows in ONE merged vm entry, while
    // the delete reports per-column counts. onhost loses both site_id and
    // hypervisor_id, pinned loses site_id — 2 distinct rows the delete moved, even
    // though it cleared 3 columns. Same row set, one source; only the shape differs.
    const vmEntries = p.will_unplace.filter((e) => e.kind === 'vm');
    assert.equal(vmEntries.length, 1, 'the vm zone entries were not merged');
    assert.equal(vmEntries[0].count, 2, 'the preview did not count distinct unplaced VMs');
    const deleteColumns = (gone.body.data.unplaced['cap_vms.site_id'] || 0)
      + (gone.body.data.unplaced['cap_vms.hypervisor_id'] || 0);
    assert.equal(deleteColumns, 3, 'the delete no longer clears both placement columns');
  });
});

// ── B3: a dual-placed VM is one row, counted once ───────────────────────────

describe('the will_unplace zone merges same-kind entries and dedupes by row', () => {
  test('a VM both pinned and hosted in the site is one vm entry counted once', async (t) => {
    if (guard(t)) return;
    const specId = await seedSpec();
    const site = await call(ADMIN, 'POST', `${base}/sites`, { name: 'DC-A' });
    const siteId = site.body.data.id;
    const hv = await call(ADMIN, 'POST', `${base}/hypervisors`, { name: 'host-a', site_id: siteId, spec_id: specId });
    // Hosted on a hypervisor in this site AND (by placement backfill) pinned to
    // it: the delete clears both hypervisor_id and site_id on this single row.
    await call(ADMIN, 'POST', `${base}/vms`, { name: 'dual', vm_type: 'ap_host', hypervisor_id: hv.body.data.id });

    const p = (await preview('sites', siteId)).body.data;
    const vmEntries = p.will_unplace.filter((e) => e.kind === 'vm');
    assert.equal(vmEntries.length, 1, 'the site and hypervisor vm groups were not merged');
    assert.equal(vmEntries[0].count, 1, 'the dual-placed VM was counted twice');
    assert.deepEqual(vmEntries[0].names, ['dual']);
  });
});

// ── B1: a cascade child takes its OWN cascade with it (grandchild) ───────────

describe('a database preview surfaces the group memberships its instances take along', () => {
  test('will_delete names the instances AND the group_member rows referencing them', async (t) => {
    if (guard(t)) return;
    const specId = await seedSpec();
    const site = await call(ADMIN, 'POST', `${base}/sites`, { name: 'DC-A' });
    const hv = await call(ADMIN, 'POST', `${base}/hypervisors`,
      { name: 'host-a', site_id: site.body.data.id, spec_id: specId });
    const vm = await call(ADMIN, 'POST', `${base}/vms`, { name: 'dbhost', vm_type: 'db_host', hypervisor_id: hv.body.data.id });
    const db = await call(ADMIN, 'POST', `${base}/databases`, { function_name: 'ORDERS', topology: 'primary_standby' });
    const dbId = db.body.data.id;
    await call(ADMIN, 'PUT', `${base}/vms/${vm.body.data.id}`, { database_id: dbId });
    const inst = await call(ADMIN, 'POST', `${base}/db_instances`,
      { name: 'i-primary', vm_id: vm.body.data.id, database_id: dbId, role: 'primary' });
    // A custom group whose explicit member is that instance — a grandchild of the
    // database that the cascade deletes but the preview must still name.
    const groupId = '99990000-1111-4222-8333-444455556666';
    const memberId = '99990000-2222-4333-8444-555566667777';
    await q(`INSERT INTO \`${tbl('cap_custom_groups')}\` (id, scenario_id, name) VALUES (?,?,?)`,
      [groupId, SCENARIO_ID, 'grp']);
    await q(`INSERT INTO \`${tbl('cap_custom_group_members')}\` (id, scenario_id, group_id, member_instance_id) VALUES (?,?,?,?)`,
      [memberId, SCENARIO_ID, groupId, inst.body.data.id]);

    const p = (await preview('databases', dbId)).body.data;
    assert.equal(zoneCount(p.will_delete, 'db_instance'), 1);
    assert.equal(zoneCount(p.will_delete, 'group_member'), 1,
      'the preview did not surface the grandchild group membership the delete removes');
  });
});

// ── Authorization mirrors the DELETE gate ────────────────────────────────────

describe('the preview is gated exactly like the child DELETE', () => {
  test('a non-owner editor is 403, and told nothing about the contents', async (t) => {
    if (guard(t)) return;
    const site = await call(ADMIN, 'POST', `${base}/sites`, { name: 'DC-A' });
    await q(`UPDATE \`${tbl('cap_scenarios')}\` SET owner_id = ? WHERE id = ?`, [ADMIN.id, SCENARIO_ID]);
    const res = await preview('sites', site.body.data.id, OTHER_EDITOR);
    assert.equal(res.status, 403, JSON.stringify(res.body));
    assert.equal(res.body.data, null);
  });

  test('a row in another scenario is 404, not enumerated', async (t) => {
    if (guard(t)) return;
    const site = await call(ADMIN, 'POST', `${base}/sites`, { name: 'DC-A' });
    const other = 'deadbeef-1111-4222-8333-444455556666';
    await q(`INSERT INTO \`${tbl('cap_scenarios')}\` (id, name, owner_id) VALUES (?,?,?)`, [other, 'other', null]);
    const res = await call(ADMIN, 'GET', `/edge/app/capacity/scenarios/${other}/sites/${site.body.data.id}/delete-preview`);
    assert.equal(res.status, 404, JSON.stringify(res.body));
  });

  test('an unknown segment is a 400, not a 500', async (t) => {
    if (guard(t)) return;
    const res = await preview('bananas', 'x');
    assert.equal(res.status, 400, JSON.stringify(res.body));
  });
});
