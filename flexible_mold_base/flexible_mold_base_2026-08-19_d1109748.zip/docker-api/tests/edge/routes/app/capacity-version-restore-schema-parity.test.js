/**
 * capacity-version-restore-schema-parity.test.js — validates every column the
 * in-place version-restore SQL references against the ACTUAL table DDL, WITHOUT
 * a live DB. The route tests stub query results, so a wrong column name stays
 * green in both runners yet 500s against a real database — and here that would
 * mean 500ing AFTER the scenario's rows were deleted (the transaction rolls the
 * delete back, but the restore is dead on arrival). This test parses
 * docker-api/src/table-ddls and asserts the restore's fixed column references
 * exist.
 */
const { describe, it, before } = require('node:test');
const assert = require('node:assert/strict');

// _shared.js destructures { t } from ../../../db at load (never calls it at load
// time); stub the db module so the require is side-effect-free (no pool).
const dbKey = require.resolve('../../../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: {}, t: (n) => n },
};

const { buildAllTableDDLs } = require('../../../../src/table-ddls');
const { TABLES } = require('../../../../src/shared/constants');
const {
  SNAPSHOT_TABLES, RESTORE_SKIP_COLUMNS,
} = require('../../../../src/edge/routes/app/capacity/_shared');

const SQL_TYPES = /^`?([a-z_]+)`?\s+(?:CHAR|VARCHAR|INT|DOUBLE|TIMESTAMP|JSON|TEXT|ENUM|BOOLEAN|TINYINT|BIGINT|DATETIME|DECIMAL|FLOAT|BLOB)\b/i;
let columnsByTable;

before(() => {
  columnsByTable = new Map();
  // Engine (cap_*) + infra (feature_audit) DDLs — the restore touches both.
  const ddls = buildAllTableDDLs((n) => n);
  for (const ddl of ddls) {
    const m = ddl.match(/CREATE TABLE IF NOT EXISTS `([^`]+)`/);
    if (!m) continue;
    const cols = new Set();
    for (const rawLine of ddl.split('\n')) {
      const line = rawLine.trim();
      if (!line || line.startsWith('--') || line.startsWith('/*')) continue;
      const cm = line.match(SQL_TYPES);
      if (cm) cols.add(cm[1]);
    }
    columnsByTable.set(m[1], cols);
  }
});

describe('version-restore schema parity', () => {
  it('every snapshot table exists and carries id + scenario_id', () => {
    for (const { key, table } of SNAPSHOT_TABLES) {
      const cols = columnsByTable.get(String(table));
      assert.ok(cols && cols.size > 0, `no columns parsed for ${table} (snapshot key ${key})`);
      // The replay INSERT writes id verbatim; delete + rebind scope on
      // scenario_id, and the freshness fingerprint reads scenario_id off every
      // frozen row to tell the scenario's own rows from the folded-in global
      // layer — a table without it would fingerprint as empty and wave a stale
      // switch through.
      assert.ok(cols.has('id'), `${table} is missing id`);
      assert.ok(cols.has('scenario_id'), `${table} is missing scenario_id`);
    }
  });

  it('the version create + saved-state probe reference real cap_versions columns', () => {
    const cols = columnsByTable.get(String(TABLES.CAP_VERSIONS));
    assert.ok(cols, 'cap_versions DDL not found');
    for (const col of ['id', 'scenario_id', 'name', 'note', 'snapshot', 'created_by']) {
      assert.ok(cols.has(col), `cap_versions has no column '${col}'`);
    }
  });

  it('the two editable version columns exist, and the frozen ones the PUT refuses do too', () => {
    // The whitelist is only meaningful if both halves are real columns: `name`
    // and `note` must be writable, and the frozen columns a caller could
    // otherwise have tried to write must exist to be worth refusing.
    //
    // What this does NOT establish: the route's refusal message is built from
    // `Object.keys(body)`, so it names whatever the caller sent — including a
    // field that is not a column at all. No DDL test can constrain that. This is
    // a column lock, nothing wider.
    const cols = columnsByTable.get(String(TABLES.CAP_VERSIONS));
    for (const col of ['name', 'note']) {
      assert.ok(cols.has(col), `cap_versions has no editable column '${col}'`);
    }
    for (const col of ['snapshot', 'created_at', 'created_by']) {
      assert.ok(cols.has(col), `cap_versions has no frozen column '${col}' — the refusal names a field that does not exist`);
    }
  });

  it('the restore audit INSERT writes real feature_audit columns', () => {
    const cols = columnsByTable.get(String(TABLES.FEATURE_AUDIT));
    assert.ok(cols, 'feature_audit DDL not found');
    for (const col of ['id', 'event_type', 'user_id', 'metadata']) {
      assert.ok(cols.has(col), `feature_audit has no column '${col}'`);
    }
  });

  it('the skipped replay columns are DB-managed columns that really exist', () => {
    // created_at / updated_at are skipped so the DB defaults own them; if a
    // snapshot table had no such column the skip would be silently pointless.
    assert.ok(RESTORE_SKIP_COLUMNS.has('created_at'));
    assert.ok(RESTORE_SKIP_COLUMNS.has('updated_at'));
    assert.ok(RESTORE_SKIP_COLUMNS.has('scenario_id'), 'scenario_id is rebound explicitly, never copied');
    const timestamped = SNAPSHOT_TABLES.filter(({ table }) => {
      const cols = columnsByTable.get(String(table));
      return cols.has('created_at') || cols.has('updated_at');
    });
    assert.ok(timestamped.length > 0, 'no snapshot table has a DB-managed timestamp — the skip set is stale');
  });

  it('cap_versions is not a snapshot table (a restore never prunes history)', () => {
    const keys = SNAPSHOT_TABLES.map(({ table }) => String(table));
    assert.equal(keys.includes(String(TABLES.CAP_VERSIONS)), false);
    assert.equal(keys.includes(String(TABLES.CAP_SCENARIOS)), false);
    // Bundles are global config, never part of a scenario snapshot — so a
    // restore can never write them.
    assert.equal(keys.includes(String(TABLES.CAP_BUNDLES)), false);
    assert.equal(keys.includes(String(TABLES.CAP_BUNDLE_ITEMS)), false);
  });
});
