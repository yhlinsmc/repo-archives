'use strict';

/**
 * delegated-grants-query-parity.test.js — every column the new statements name,
 * checked against the DDL, mechanically, without a live database.
 *
 * WHY THE COLUMN NAMES ARE READ OUT OF THE SOURCE RATHER THAN LISTED HERE. A
 * list retyped in a test is a second copy that drifts, and the failure it would
 * miss is exactly the one that has shipped here before: a mocked connection
 * returns whatever it is told, so a statement naming a column that does not
 * exist passes every route test and 500s against a real database. This file
 * reads the statements as text, pulls the identifiers out of them, and requires
 * each one to exist in `table-ddls.js`.
 *
 * WHAT IT COVERS: the four modules added for delegated access — the predicate
 * builder, the grant lookup, the granting route and the activity route — plus
 * the two statements the shared write paths gained. WHAT IT DOES NOT: whether
 * the statements MEAN the right thing, which is a live-database question and is
 * answered in tests/integration/delegated-grants-predicate-real-db.test.js.
 */
const { describe, it, before } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const { buildEngineTableDDLs, buildInfraTableDDLs } = require('../../../../src/table-ddls');
const { TABLES } = require('../../../../src/shared/constants');

// The predicate builder resolves its table names through the pool's prefix
// helper at call time, which throws when no pool is configured. This file never
// touches a database, so it supplies the identity prefix instead — the SHAPE of
// the statement is what is under test, and the prefix is not part of it.
const dbKey = require.resolve('../../../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey,
  filename: dbKey,
  loaded: true,
  exports: { pool: { ro: null, rw: null }, t: (n) => n, getDynamicPool: async () => ({}) },
};
const { buildTemplateAccessExists } = require('../../../../src/edge/lib/delegated-grants');

const SQL_TYPES = /^`?([a-z_]+)`?\s+(?:CHAR|VARCHAR|INT|DOUBLE|TIMESTAMP|JSON|TEXT|ENUM|BOOLEAN|TINYINT|BIGINT|DATETIME|DECIMAL|FLOAT|BLOB)\b/i;

/** Every source file whose statements this feature added or changed. */
const SOURCES = [
  'src/edge/lib/delegated-grants.js',
  'src/edge/lib/template-activity.js',
  'src/edge/routes/app/delegated-grants.js',
  'src/edge/routes/app/template-activity.js',
];

let columnsByTable;

before(() => {
  columnsByTable = new Map();
  for (const ddl of [...buildEngineTableDDLs((n) => n), ...buildInfraTableDDLs((n) => n)]) {
    const m = ddl.match(/CREATE TABLE IF NOT EXISTS `([^`]+)`/);
    if (!m) continue;
    const cols = new Set();
    for (const rawLine of ddl.split('\n')) {
      const line = rawLine.trim();
      if (!line || line.startsWith('--') || line.startsWith('/*')) continue;
      const cm = line.match(SQL_TYPES);
      if (cm) cols.add(cm[1]);
    }
    columnsByTable.set(m[1], cols);
  }
});

function readSource(relative) {
  return fs.readFileSync(path.join(__dirname, '../../../../', relative), 'utf8');
}

/**
 * The tables a source file names, as `TABLES.X` references inside a `t(...)`
 * call. Anything else would be a hard-coded prefix, which the repository's own
 * lint already refuses — so this doubles as a check that these files play by
 * that rule.
 */
function tablesNamedIn(text) {
  return [...text.matchAll(/t\(TABLES\.([A-Z_]+)\)/g)].map((m) => TABLES[m[1]]);
}

/**
 * Column identifiers a statement names.
 *
 * Two shapes appear in these sources and both are collected: an aliased
 * reference (``dg.`grantee_id` ``) and a bare backticked column inside a
 * statement (``SET `name` = ?``). Reserved SQL words and table names are
 * excluded — a table name in backticks is not a column reference.
 */
function columnsNamedIn(text) {
  const found = new Set();
  for (const [, col] of text.matchAll(/\w+\.`(\w+)`/g)) found.add(col);
  for (const [, list] of text.matchAll(/SELECT ([\w\s,]+?) FROM/g)) {
    for (const raw of list.split(',')) {
      const col = raw.trim();
      if (/^[a-z_][a-z0-9_]*$/.test(col) && col !== 'DISTINCT') found.add(col);
    }
  }
  for (const [, list] of text.matchAll(/INSERT INTO [^(]+\(([^)]+)\)/g)) {
    for (const raw of list.split(',')) {
      const col = raw.trim().replace(/`/g, '');
      if (/^[a-z_][a-z0-9_]*$/.test(col)) found.add(col);
    }
  }
  for (const [, col] of text.matchAll(/WHERE (\w+) = \?/g)) found.add(col);
  return found;
}

describe('the new statements name only columns that exist', () => {
  for (const source of SOURCES) {
    it(`${source} — every column it names is declared somewhere it reads`, () => {
      const text = readSource(source);
      const tables = tablesNamedIn(text);
      assert.ok(tables.length > 0, `${source} names no table through t(TABLES.X)`);

      // The union of the tables this file reads. A file that touches two tables
      // can legitimately name a column that exists on only one of them, so the
      // union is the right test at this granularity — a column that exists on
      // NEITHER is the defect this catches.
      const allowed = new Set();
      for (const table of tables) {
        for (const col of columnsByTable.get(table) || []) allowed.add(col);
      }
      // `cnt` is a COUNT alias, not a column, and appears in the aliased form.
      allowed.add('cnt');

      const unknown = [...columnsNamedIn(text)].filter((c) => !allowed.has(c));
      assert.deepEqual(
        unknown, [],
        `${source} names column(s) no table it reads declares: ${unknown.join(', ')}`,
      );
    });
  }
});

describe('the grant predicate, column by column', () => {
  it('names the grants table\'s own columns and the two it correlates on', () => {
    const { sql } = buildTemplateAccessExists('`user_templates`');
    const grants = columnsByTable.get(TABLES.DELEGATED_GRANTS);
    const hierarchy = columnsByTable.get(TABLES.HIERARCHY_NODES);
    const templates = columnsByTable.get(TABLES.USER_TEMPLATES);
    for (const col of ['grantee_id', 'scope_type', 'scope_id']) {
      assert.ok(grants.has(col), `the predicate names ${col}, which delegated_grants does not declare`);
    }
    // node_type gates the grant arms to blueprints; owner_id is what the third
    // arm — the blueprint's own owner — is decided by.
    for (const col of ['id', 'node_type', 'owner_id']) {
      assert.ok(hierarchy.has(col), `the predicate names ${col}, which hierarchy_nodes does not declare`);
    }
    for (const col of ['id', 'blueprint_id', 'owner_id']) {
      assert.ok(templates.has(col), `the predicate correlates on ${col}, which user_templates does not declare`);
    }
  });

  it('binds exactly as many values as it names, and says how many', () => {
    // A predicate whose bind count is wrong is a misbinding, and on a
    // permission check a misbinding decides the wrong caller's access. Asked of
    // both shapes, because the shape a database without the grants table gets
    // is a different statement with a different count.
    for (const opts of [undefined, { includeGrants: true }, { includeGrants: false }]) {
      const { sql, paramCount } = buildTemplateAccessExists('`user_templates`', opts);
      assert.equal(
        (sql.match(/\?/g) || []).length, paramCount,
        `bind count disagrees with the placeholders for ${JSON.stringify(opts)}`,
      );
    }
  });

  it('names no grants table at all in the shape a database without one gets', () => {
    // The arm that survives reads the hierarchy. If the trimmed shape still
    // named the grants table it would fail on exactly the databases it exists
    // for, and it would do so on every record update.
    const { sql, paramCount } = buildTemplateAccessExists('`user_templates`', { includeGrants: false });
    assert.ok(!sql.includes(TABLES.DELEGATED_GRANTS), `the trimmed predicate names the grants table: ${sql}`);
    assert.equal(paramCount, 1);
  });
});

describe('the write paths\' own new statements', () => {
  it('the delegated arm the shared update path adds resolves to real columns', () => {
    const text = readSource('src/edge/routes/app/schema/crud-factory.js');
    assert.match(text, /grantWritePredicate/, 'the factory no longer builds the delegated arm');
    // The arm's own columns come from the predicate builder, checked above. What
    // the factory adds is the ownership column beside it, which is the mount's
    // declared writeScopeColumn — `user_templates.owner_id`.
    assert.ok(columnsByTable.get(TABLES.USER_TEMPLATES).has('owner_id'));
  });

  it('the dispatch write-back names columns user_templates declares', () => {
    const text = readSource('src/edge/routes/internal/flow-recipes-run.js');
    const cols = columnsByTable.get(TABLES.USER_TEMPLATES);
    for (const col of ['flow_external_id', 'flow_link', 'flow_last_run_id', 'owner_id', 'blueprint_id']) {
      assert.ok(cols.has(col), `the dispatch path names ${col}, which user_templates does not declare`);
      assert.match(text, new RegExp(col), `the dispatch path no longer names ${col}`);
    }
  });
});
