/**
 * capacity-config-degraded-probe.test.js — codex r2 R2-2. The degraded-mode
 * column probe (dropAbsentColumns) that the global-config create/update path runs
 * before a write must query the WRITER, not a read-only replica: DDL can replicate
 * late, so a replica-derived "column absent" would be cached for the process
 * lifetime and silently drop the field on every subsequent write even after the
 * replica catches up. This mounts the real config router behind DISTINCT ro/rw
 * pools and asserts the `information_schema.COLUMNS` probe lands on rw only.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('http');
const express = require('express');

const dbKey = require.resolve('../../../../src/edge/db');

let roQueries = [];
let rwQueries = [];

// The writer connection the transaction runs on (pool.rw.getConnection()).
const conn = {
  async beginTransaction() {},
  async commit() {},
  async rollback() {},
  release() {},
  async query(sql) {
    if (/COALESCE\(MAX\(order_index\)/i.test(sql)) return [{ next: 0 }];
    if (/^\s*INSERT INTO/i.test(sql)) return { affectedRows: 1, insertId: 1 };
    if (/^\s*UPDATE/i.test(sql)) return { affectedRows: 1 };
    if (/SELECT \* FROM `fmb_[a-z_]+` WHERE id = \?/i.test(sql)) {
      return [{ id: 't-1', name: 'Ops', color: '#111', order_index: 0, scenario_id: null }];
    }
    return []; // FOR UPDATE lock + anything else
  },
};

// The physical column set the probe reads — includes name/color so nothing is
// dropped for a healthy schema; the point of the test is WHICH pool answers it.
const COLUMN_ROWS = ['id', 'scenario_id', 'name', 'color', 'order_index'].map((name) => ({ name }));

const roPool = {
  query: async (sql, params) => { roQueries.push(sql); return /information_schema/i.test(sql) ? COLUMN_ROWS : []; },
  getConnection: async () => conn,
};
const rwPool = {
  query: async (sql, params) => { rwQueries.push(sql); return /information_schema/i.test(sql) ? COLUMN_ROWS : []; },
  getConnection: async () => conn,
};

require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: { ro: roPool, rw: rwPool }, t: (n) => `fmb_${n}` },
};

const { _resetColumnSetCache } = require('../../../../src/edge/routes/app/capacity/_shared');
const configRouter = require('../../../../src/edge/routes/app/capacity/config');

let server; let baseUrl;
before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { req.user = { id: 'admin-1', role: 'admin' }; next(); });
  app.use('/config', configRouter);
  server = http.createServer(app);
  await new Promise((r) => server.listen(0, r));
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});
after(() => server && server.close());
beforeEach(() => {
  roQueries = []; rwQueries = [];
  // The column-set cache never expires in production; reset it so each case sees
  // its own probe rather than an earlier case's cached set.
  _resetColumnSetCache();
});

function request(method, path, body) {
  return new Promise((resolve, reject) => {
    const payload = body === undefined ? '' : JSON.stringify(body);
    const r = http.request(`${baseUrl}${path}`, { method, headers: { 'content-type': 'application/json' } }, (res) => {
      let data = '';
      res.on('data', (c) => { data += c; });
      res.on('end', () => resolve({ status: res.statusCode, body: data ? JSON.parse(data) : null }));
    });
    r.on('error', reject);
    if (payload) r.write(payload);
    r.end();
  });
}

const probedInfoSchema = (queries) => queries.some((sql) => /information_schema\.COLUMNS/i.test(sql));

describe('config create — degraded column probe runs on the writer (R2-2)', () => {
  it('POST /config/teams probes information_schema on rw, never ro', async () => {
    const res = await request('POST', '/config/teams', { name: 'Ops', color: '#111' });
    assert.ok(res.status >= 200 && res.status < 300, `${res.status}: ${JSON.stringify(res.body)}`);
    assert.equal(probedInfoSchema(rwQueries), true, 'writer pool must answer the column probe');
    assert.equal(probedInfoSchema(roQueries), false, 'RO replica must never answer the column probe');
  });
});

describe('config update — degraded column probe runs on the writer (R2-2)', () => {
  it('PUT /config/teams/:id probes information_schema on rw, never ro', async () => {
    const res = await request('PUT', '/config/teams/t-1', { name: 'Ops', color: '#222' });
    assert.ok(res.status >= 200 && res.status < 300, `${res.status}: ${JSON.stringify(res.body)}`);
    assert.equal(probedInfoSchema(rwQueries), true, 'writer pool must answer the column probe');
    assert.equal(probedInfoSchema(roQueries), false, 'RO replica must never answer the column probe');
  });
});
