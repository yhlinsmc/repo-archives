/**
 * flow-recipe-runs-secret-matcher-corpus.test.js — the differential between the
 * secret matcher this module replaced and the one it runs, over a corpus that is
 * GENERATED rather than hand-written.
 *
 * WHY IT IS GENERATED. The matcher has now produced a defect in four consecutive
 * rounds: too loose (masking `passenger_count`, `pass_rate`, `bypass_valve` in a
 * column keyed by names domain users write), then too tight (storing
 * `pass_phrase`, `api_keys`, `password2` in plaintext), then too tight somewhere
 * else (`pass_word`, `pass-word`, `passWord`, `pass_wd`, `passWd`), then too
 * tight in a place this file could not see (`db_pass`, `user_pass`,
 * `smtp_pass`). The second fix ran a differential of old against new — over 89
 * candidates typed out by hand — and reported the residual complete. The list
 * simply did not contain `pass_word`, and nothing about it could have said so: a
 * hand-written corpus can only refute a claim about every spelling, never
 * establish one, and the spellings it omits are exactly the ones nobody thought
 * of.
 *
 * WHY THERE IS A NEIGHBOUR AXIS, which is the fourth defect's actual cause. The
 * first version of this file crossed each term with separators, casings, plurals
 * and digits — every dimension except a neighbouring word. For a rule that
 * matches a term whatever surrounds it, that omission is harmless. It is not
 * harmless for a rule that turns on POSITION, and the matcher has exactly one:
 * the bare word `pass`. So the corpus never contained `db_pass`, the residual
 * never contained it either, and the "exactly two families" test passed while a
 * credential was stored verbatim. A corpus that cannot vary the dimension a rule
 * turns on establishes nothing about that rule — which is why every term is now
 * also crossed with a neighbouring word in both positions.
 *
 * The residual — what the old pattern masked and this one stores — is a derived
 * list, and the families below are the whole of it. A term added to the matcher,
 * a spelling it stops seeing, or a family that stops costing anything all move
 * that list and fail here, which is the property the prose in the module header
 * could not have.
 *
 * WHAT THIS FILE DOES NOT DO: judge whether a residual family is acceptable.
 * That argument lives beside each family. This file only refuses to let the set
 * change without someone editing it.
 *
 * WHAT IT ESTABLISHES, STATED AS A BOUNDED CLAIM — because after five rounds on
 * this matcher the most valuable thing here is an honest scope, and every defect
 * so far arrived through a dimension nobody had written down. Over the axes it
 * generates — separator, casing, plural, digit at either end, neighbouring word
 * at either end — every spelling the base pattern masked and this one stores
 * falls into one of the four families, and every declared term has an entry so a
 * term added without one fails.
 *
 * WHAT IT DOES NOT ESTABLISH, all four known and none of them closed here:
 *   1. INTERPOSITION. Nothing is ever generated BETWEEN the two parts of a term,
 *      and adjacency is exactly what the pair rule turns on — the same shape of
 *      blind spot as the missing neighbour axis that stored `db_pass` for a
 *      release. Adding one axis (a digit between the parts) puts ~1,800
 *      unclassified spellings into the residual, so the class is real and would
 *      fail the completeness test today. It is left open deliberately: every
 *      member is `pass` + digit + modifier — `pass2word`, `db_pass2phrase` —
 *      which is not how anything is named, whereas `db_pass` is how half the
 *      world names a password. Recorded rather than closed so the next person
 *      inherits a known gap instead of discovering it.
 *   2. Credentials the BASE PATTERN also missed. This is a differential, so
 *      `pwd`, `db_pwd`, `access_key`, `signing_key`, `jwt`, `hmac`, `salt` and
 *      friends can never appear in the residual, whatever the matcher does with
 *      them. A differential bounds a regression, not a vocabulary.
 *   3. The OVER-masking direction. A domain word this matcher has started
 *      masking is not a residual and never appears here; that trade is pinned in
 *      flow-recipe-runs-serializer.test.js, which lists the physical-pass words
 *      now masked beside the domain words that survive.
 *   4. Neighbours richer than the two stand-ins. In particular the disjointness
 *      test holds partly because neither stand-in contains a term part; a
 *      neighbour like `keystore` would have `keystore_passes` claimed by two
 *      families. That reads as a stronger property than it is.
 */
const { test } = require('node:test');
const assert = require('node:assert');
const {
  isSecretKey,
  keySegments,
  SECRET_SEGMENT_WORDS,
  SECRET_SEGMENT_PAIR_WORDS,
  SECRET_BARE_WORDS,
} = require('../../../../src/edge/routes/app/flow-recipe-runs/serializer');

// The matcher as it stood at v3.2.612, quoted verbatim from
// `git show 1a17bb9f:docker-api/src/edge/routes/app/flow-recipe-runs/serializer.js`.
// Unanchored and case-insensitive: it masked any key CONTAINING one of these,
// which is both why it destroyed ordinary words and why it is the right
// reference for "what a credential name used to be caught by".
const OLD_SECRET_KEY_RE = /(pass(word|wd)?|secret|token|api[-_ ]?key|authorization|bearer|credential|private[-_ ]?key)/i;

// Each term as its WORD PARTS. Joined with no separator, a term is the spelling
// one of the two matchers names outright; the generator below produces every
// other spelling of it. Two sources, and both are needed:
//   - the old pattern's own alternatives, which is what "everything it caught"
//     means; and
//   - the terms the CURRENT matcher names, so a term it catches run-together
//     and misses when split — the `passphrase` / `pass_phrase` class, which is
//     precisely how the second defect happened — appears in the differential.
const TERM_PARTS = Object.freeze([
  ['pass'], ['pass', 'word'], ['pass', 'wd'],
  ['secret'], ['token'], ['authorization'], ['bearer'], ['credential'],
  ['api', 'key'], ['private', 'key'],
  ['pass', 'phrase'], ['pass', 'code'], ['pass', 'key'],
]);

const SEPARATORS = ['', '_', '-', ' ', '.'];
// A digit on either side, with and without a separator: `keySegments` splits
// letter/digit boundaries in both directions and a counted credential
// (`password2` beside a `#backup` one) is a live naming pattern here.
const DIGIT_PREFIXES = ['', '2', '2_'];
const DIGIT_SUFFIXES = ['', '2', '_2'];
// A NEIGHBOURING WORD, on each side, joined by the same separator as the term's
// own parts. This is the axis whose absence stored `db_pass` in plaintext — see
// the file header. Two stand-ins are enough and they are chosen to be different
// in kind: `db` is a word that really does precede credentials in the wild, and
// `x` is meaningless, so a rule that only masks recognised prefixes fails on `x`
// instead of passing by accident.
const NEIGHBOURS = ['db', 'x'];

const capitalise = (w) => w[0].toUpperCase() + w.slice(1);
const CASINGS = [
  (parts) => parts.slice(),                                        // api_key
  (parts) => parts.map((w) => w.toUpperCase()),                    // API_KEY
  (parts) => parts.map((w, i) => (i ? capitalise(w) : w)),         // apiKey
  (parts) => parts.map(capitalise),                                // ApiKey
];
// `pass` → `passes`, not `passs`. The plural spelling has to be the one a
// person would actually write, or the corpus tests a string nobody types.
const pluralise = (w) => (/([sxz]|ch|sh)$/.test(w) ? `${w}es` : `${w}s`);

function generateCorpus() {
  const corpus = new Set();
  for (const parts of TERM_PARTS) {
    for (const plural of [false, true]) {
      const base = plural
        ? parts.map((w, i) => (i === parts.length - 1 ? pluralise(w) : w))
        : parts;
      for (const casing of CASINGS) {
        for (const termSep of SEPARATORS) {
          // A separator is a no-op on a one-word term; skip so the corpus
          // counts distinct spellings rather than repeats. The neighbour loop
          // below still runs, so every neighbour separator is still produced.
          if (termSep !== '' && base.length === 1) continue;
          // The term alone, then the term with a neighbouring word on each side.
          // CASING IS APPLIED TO THE WHOLE COMPOUND, so `db` + `pass` really does
          // produce `dbPass` — casing the neighbour on its own would silently
          // drop the camelCase hump, which is the boundary the matcher reads.
          // The neighbour's separator varies INDEPENDENTLY of the term's own, so
          // `db_password` (bounded neighbour, run-together term) and
          // `dbpass_word` (run-together neighbour, bounded term) are both
          // generated — they land in different families and only one is a loss.
          const spellings = [casing(base).join(termSep)];
          for (const neighbour of NEIGHBOURS) {
            const lead = casing([neighbour, ...base]);
            const trail = casing([...base, neighbour]);
            for (const neighbourSep of SEPARATORS) {
              spellings.push(lead[0] + neighbourSep + lead.slice(1).join(termSep));
              spellings.push(trail.slice(0, -1).join(termSep) + neighbourSep + trail[trail.length - 1]);
            }
          }
          for (const joined of spellings) {
            for (const prefix of DIGIT_PREFIXES) {
              for (const suffix of DIGIT_SUFFIXES) corpus.add(prefix + joined + suffix);
            }
          }
        }
      }
    }
  }
  return [...corpus].sort();
}

// The words a term is built from (`api`, `key`, `pass`, `word`, …), and every
// segment spelling that is ALIGNED to a boundary — a whole term run together
// (`apikey`, `password`), a single part (`key`, `pass`), or either one's plural.
// The run-together family below is "a term part is inside a segment that is not
// one of these", which is exactly "a boundary the old pattern matched across is
// no longer there": `dbpass`, `mypassword`, `api keydb`.
const TERM_PART_WORDS = [...new Set(TERM_PARTS.flat())];
const BOUNDARY_ALIGNED_SEGMENTS = new Set([
  ...TERM_PART_WORDS, ...TERM_PART_WORDS.map(pluralise),
  ...TERM_PARTS.flatMap((parts) => [
    parts.join(''),
    pluralise(parts.join('')),
    parts.map((w, i) => (i === parts.length - 1 ? pluralise(w) : w)).join(''),
  ]),
]);

// A segment carrying at least one letter — the same distinction the matcher
// draws, since `keySegments` splits a trailing count into its own segment.
const isWordSegment = (s) => /[a-z]/.test(s);
const PASS_MODIFIER_RE = /^(code|codes|key|keys)$/;

const CORPUS = generateCorpus();
const OLD_MASKED = CORPUS.filter((k) => OLD_SECRET_KEY_RE.test(k));
// The differential: masked by the pattern this module replaced, STORED by the
// one it runs. Every entry is a credential name that would reach a durable,
// admin-readable row in plaintext.
const RESIDUAL = OLD_MASKED.filter((k) => !isSecretKey(k));

// The families the residual is allowed to contain, each with the reason it is
// allowed to. A predicate rather than a list of spellings, so it covers the
// family and not the examples — the failure mode this whole file exists for.
// They are required to be mutually exclusive below, so each predicate says what
// it means rather than relying on the order they are written in.
const ACCEPTED_LOSSES = [
  {
    name: 'a term run into its neighbour with no boundary at all',
    // `mypassword`, `secretsmanager`, `dbpass`, `apikeyv2`. Segment matching
    // cannot see a term with no separator, no camelCase hump and no digit
    // beside it, and widening to substrings is the loose behaviour this whole
    // change removed. The module header has always named this loss; the
    // neighbour axis is what made it derivable instead of asserted.
    covers: (segments) => segments.some((s) => (
      !BOUNDARY_ALIGNED_SEGMENTS.has(s) && TERM_PART_WORDS.some((t) => s.includes(t))
    )),
  },
  {
    name: '`pass` + `code` / `pass` + `key`, split across a boundary',
    // `passcode` and `passkey` ARE masked as one segment. Split, they collide
    // with a physical pass — `boarding_pass_code`, `gate_pass_key` — in the same
    // vocabulary that produced the first defect, and those are pinned as
    // must-survive in flow-recipe-runs-serializer.test.js. Widening this pair
    // re-breaks that, so the boundary is held from both sides.
    covers: (segments) => segments.some((s, i) => (
      s === 'pass' && PASS_MODIFIER_RE.test(segments[i + 1] || '')
    )),
  },
  {
    name: '`pass` with another word after it — an ordinary word, or a qualified credential',
    // TWO KINDS OF KEY LAND HERE, and the family is named for both because an
    // earlier wording described only the first and was plainly false about the
    // second.
    //
    // Head noun — `pass_rate`, `pass_count`: the key names a rate or a count.
    // This is the loss the retightening exists to take; these were being
    // replaced with asterisks, silently and permanently, in a column keyed by
    // names the people using the system write.
    //
    // Qualifier — `db_pass_old`, `db_pass_backup`, `smtp_pass_new`,
    // `db_pass_hash`: these ARE credentials and they are stored. Nothing in the
    // shape separates them from the first kind; only a list of qualifier words
    // would, and that is the hand-written completeness claim this file exists to
    // replace, while masking on any following word instead re-breaks
    // `pass_rate`. So it is a declared loss, pinned in the serializer test as
    // documented-and-stored, and it leaves the outcome turning on `pass` versus
    // `password` — `password_backup` and `db_password_old` stay masked.
    //
    // The following word has to be an UNRELATED one. If it carries a credential
    // part inside it (`pass codedb`) the key is not the English word modified by
    // something else, it is a term whose boundary was destroyed — which is the
    // family above, and saying so here is what keeps the two disjoint without
    // depending on the order they are written in.
    covers: (segments) => segments.some((s, i) => {
      const next = segments[i + 1] || '';
      return s === 'pass'
        && isWordSegment(next)
        && !PASS_MODIFIER_RE.test(next)
        && !TERM_PART_WORDS.some((t) => next.includes(t));
    }),
  },
  {
    name: 'the plural `passes`, wherever it appears',
    // `passes`, `total_passes`, `passes2`. The singular in the same position IS
    // masked, including counted (`pass2`, `db_pass2`); the plural is not, and
    // the split is a convention argument rather than a preference. A map of
    // credentials is named after the term — `api_keys`, `tokens`, `passwords` —
    // and `passwords` is already masked by the plural this matcher generates for
    // every declared term, so no credential naming convention produces `passes`
    // that is not already covered. Closing it would buy nothing and would mask
    // the plural of an ordinary English word wherever it appears, which is where
    // this matcher's first defect came from.
    covers: (segments) => segments.includes('passes'),
  },
];

const classify = (key) => ACCEPTED_LOSSES.filter((f) => f.covers(keySegments(key)));

test('the generated corpus really contains the spellings a hand-written list missed', () => {
  // The five `pass_word` spellings shipped in plaintext because the previous
  // differential's 89 hand-typed candidates did not include them. If the
  // generator cannot produce them, this file is decoration.
  for (const key of ['pass_word', 'pass-word', 'passWord', 'pass_wd', 'passWd', 'pass phrase', 'API_KEY2']) {
    assert.ok(CORPUS.includes(key), `the generator must produce ${key}`);
  }
  // …and the neighbour axis, whose absence stored the round-four family. Both
  // positions and both stand-ins, or the axis is decoration in the same way.
  for (const key of ['db_pass', 'x_pass', 'dbPass', 'DB_PASS', 'db-pass', 'pass_db', 'pass_x', 'db_password']) {
    assert.ok(CORPUS.includes(key), `the generator must produce ${key}`);
  }
  assert.ok(CORPUS.length > 10000, `corpus is suspiciously small: ${CORPUS.length}`);
  assert.ok(OLD_MASKED.length > 10000, `the old pattern matched only ${OLD_MASKED.length} of ${CORPUS.length}`);
});

test('every term the matcher names has a corpus entry, so no term goes untested', () => {
  // Without this the corpus is a second hand-written list wearing a generator:
  // add `clientsecret` to the matcher and nothing would ever generate
  // `client_secret`. Adding a term now fails here until its parts are declared.
  const spelled = new Set(TERM_PARTS.map((parts) => parts.join('')));
  const paired = new Set(TERM_PARTS.filter((p) => p.length === 2).map((p) => p.join('+')));

  for (const word of SECRET_SEGMENT_WORDS) {
    assert.ok(spelled.has(word), `SECRET_SEGMENT_WORDS names '${word}' but TERM_PARTS cannot spell it`);
  }
  for (const [first, second] of SECRET_SEGMENT_PAIR_WORDS) {
    assert.ok(paired.has(`${first}+${second}`),
      `SECRET_SEGMENT_PAIR_WORDS names '${first}'+'${second}' but TERM_PARTS has no such pair`);
  }
  for (const bare of SECRET_BARE_WORDS) {
    assert.ok(spelled.has(bare), `SECRET_BARE_WORDS names '${bare}' but TERM_PARTS cannot spell it`);
  }
});

test('what the tightened matcher gives up is exactly the documented families', () => {
  const unclassified = RESIDUAL.filter((k) => classify(k).length === 0);
  assert.deepStrictEqual(
    unclassified.slice(0, 12), [],
    `${unclassified.length} credential spelling(s) the old pattern masked are now STORED IN PLAINTEXT `
    + `and belong to no documented family: ${unclassified.slice(0, 12).join(', ')}. `
    + 'Either mask them (a segment word, a pair, or a bare word in trailing position) or add a family '
    + 'here with the reason they are given up, and update the WHAT TIGHTENING COSTS block in the '
    + 'module header to match.',
  );
});

test('each documented family still costs something', () => {
  // A family that has stopped matching anything is a sentence in the module
  // header describing a loss that no longer happens — the prose drifting the
  // other way.
  for (const family of ACCEPTED_LOSSES) {
    const covered = RESIDUAL.filter((k) => family.covers(keySegments(k)));
    assert.ok(covered.length > 0,
      `the family "${family.name}" no longer gives anything up — delete it here and in the module header`);
  }
});

test('the pass-spelled credential family is masked in every generated spelling', () => {
  // The defect itself, stated as its family rather than as the five spellings
  // the review happened to name. `pass_word` / `pass_wd` split into two segments
  // and neither pair was declared, so the values were stored — in the new column
  // and in the two sibling columns that share this matcher.
  const stored = CORPUS.filter((key) => {
    const segments = keySegments(key);
    const isPassSpelling = segments.some((s, i) => (
      s === 'pass' && /^(word|words|wd|wds|phrase|phrases)$/.test(segments[i + 1] || '')
    ));
    return isPassSpelling && !isSecretKey(key);
  });
  assert.deepStrictEqual(stored, [],
    `these password spellings are stored in plaintext: ${stored.slice(0, 12).join(', ')}`);
});

test('an unmodified `pass` is masked in every generated spelling', () => {
  // The round-four defect, stated as its family. `pass` is the standard
  // abbreviation for a password, so `db_pass` / `user_pass` / `smtp_pass` are
  // ordinary credential names in an upstream response body or an outbound
  // payload — neither of which this project gets to name — and the matcher
  // stored all of them because `pass` was matched only as the whole key.
  //
  // The predicate deliberately reads the corpus rather than a list of prefixes:
  // a rule that only masked recognised prefixes passes for `db_pass` and fails
  // here on `x_pass`. A trailing digit does not modify the word either, so
  // `pass2` and `db_pass2` are in scope.
  const stored = CORPUS.filter((key) => {
    const segments = keySegments(key);
    const i = segments.lastIndexOf('pass');
    if (i < 0) return false;
    return segments.slice(i + 1).every((s) => !isWordSegment(s)) && !isSecretKey(key);
  });
  assert.deepStrictEqual(stored, [],
    `these credential spellings are stored in plaintext: ${stored.slice(0, 12).join(', ')}`);
});

test('no residual spelling is claimed by two families, so each reason answers for itself', () => {
  // Overlap would mean a predicate is loose enough to be answering for spellings
  // it does not describe — the way a family stops being a reason and becomes a
  // catch-all. Kept separate from the "each family still costs something" test
  // below so a failure names which of the two properties broke.
  const doubly = RESIDUAL.filter((k) => classify(k).length > 1);
  assert.deepStrictEqual(doubly.slice(0, 12), [],
    `these keys are claimed by more than one family: ${doubly.slice(0, 12).join(', ')}`);
});
