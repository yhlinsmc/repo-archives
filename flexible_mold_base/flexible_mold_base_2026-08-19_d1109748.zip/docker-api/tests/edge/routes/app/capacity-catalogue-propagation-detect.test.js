/**
 * capacity-catalogue-propagation-detect.test.js — the E4 (spec §7 E4 / Q12)
 * PURE drift-detection + scenario-grouping logic, with no DB: `detectVmProfileDrift`,
 * `detectDiskComboDrift` and `groupDriftByScenario` all take already-fetched
 * plain-object fixtures. See catalogue-propagation.js's module doc for why this
 * feature exists (cap_vms.cpu/mem_gb/disk_gb are a prefill-only snapshot of the
 * GLOBAL catalogue, never re-derived after create).
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');

// _shared.js destructures { t } from ../../../db at load time; stub it so the
// require is side-effect-free (no pool), same convention as the schema-parity
// tests in this directory.
const dbKey = require.resolve('../../../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: {}, t: (n) => n },
};

const {
  detectVmProfileDrift, detectDiskComboDrift, groupDriftByScenario,
} = require('../../../../src/edge/routes/app/capacity/catalogue-propagation');

const FORMULA = Object.freeze({ memCpuRatio: 20, sgaFactor: 0.982, sgaDivisor: 2, sgaSubtract: 2 });

describe('detectVmProfileDrift', () => {
  it('flags a formula-mode profile whose CURRENT derived cpu/mem no longer match the stored VM values', () => {
    const profile = { id: 'p1', name: 'DB-Large', class: 'DB', mode: 'formula', cpu: 16, mem_gb: null, sga_cap_gb: null };
    // memCpuRatio 20 × new cpu 16 = 320 — held equal to the OLD stored mem_gb so
    // only cpu is exercised here (mem_gb's own drift is covered separately below).
    const vms = [{ id: 'v1', scenario_id: 's1', name: 'db01', cpu: 8, mem_gb: 320, sizing_profile_id: 'p1' }];
    const drift = detectVmProfileDrift(vms, new Map([['p1', profile]]), new Map([['s1', FORMULA]]));
    assert.deepEqual(drift.map((d) => d.field).sort(), ['cpu']);
    assert.equal(drift[0].oldValue, 8);
    assert.equal(drift[0].newValue, 16);
  });

  it('flags BOTH cpu and mem_gb when both drifted, as two separate entries', () => {
    const profile = { id: 'p1', name: 'DB-Large', class: 'DB', mode: 'custom', cpu: 16, mem_gb: 512, sga_cap_gb: 100 };
    const vms = [{ id: 'v1', scenario_id: 's1', name: 'db01', cpu: 8, mem_gb: 160, sizing_profile_id: 'p1' }];
    const drift = detectVmProfileDrift(vms, new Map([['p1', profile]]), new Map([['s1', FORMULA]]));
    assert.deepEqual(drift.map((d) => d.field).sort(), ['cpu', 'mem_gb']);
  });

  it('reports nothing for a VM whose stored sizing already matches the current profile', () => {
    const profile = { id: 'p1', name: 'DB-Large', class: 'DB', mode: 'custom', cpu: 16, mem_gb: 320, sga_cap_gb: 100 };
    const vms = [{ id: 'v1', scenario_id: 's1', name: 'db01', cpu: 16, mem_gb: 320, sizing_profile_id: 'p1' }];
    assert.deepEqual(detectVmProfileDrift(vms, new Map([['p1', profile]]), new Map([['s1', FORMULA]])), []);
  });

  it('skips a VM whose profile reference no longer resolves (dangling ref is not this feature\'s concern)', () => {
    const vms = [{ id: 'v1', scenario_id: 's1', name: 'db01', cpu: 8, mem_gb: 160, sizing_profile_id: 'gone' }];
    assert.deepEqual(detectVmProfileDrift(vms, new Map(), new Map([['s1', FORMULA]])), []);
  });

  it('falls back to DEFAULT_FORMULA for a scenario missing from formulaByScenario', () => {
    const profile = { id: 'p1', name: 'DB-Large', class: 'DB', mode: 'formula', cpu: 10, mem_gb: null, sga_cap_gb: null };
    // DEFAULT_FORMULA.memCpuRatio = 20 → memGb = 200
    const vms = [{ id: 'v1', scenario_id: 's-unknown', name: 'db01', cpu: 10, mem_gb: 100, sizing_profile_id: 'p1' }];
    const drift = detectVmProfileDrift(vms, new Map([['p1', profile]]), new Map());
    assert.deepEqual(drift.map((d) => [d.field, d.newValue]), [['mem_gb', 200]]);
  });

  it('a scenario\'s OWN formula constants change the derived mem_gb for the SAME formula-mode profile', () => {
    const profile = { id: 'p1', name: 'DB-Large', class: 'DB', mode: 'formula', cpu: 10, mem_gb: null, sga_cap_gb: null };
    const vms = [{ id: 'v1', scenario_id: 's1', name: 'db01', cpu: 10, mem_gb: 200, sizing_profile_id: 'p1' }];
    const customFormula = { memCpuRatio: 30, sgaFactor: 0.982, sgaDivisor: 2, sgaSubtract: 2 };
    const drift = detectVmProfileDrift(vms, new Map([['p1', profile]]), new Map([['s1', customFormula]]));
    assert.deepEqual(drift.map((d) => [d.field, d.newValue]), [['mem_gb', 300]]);
  });
});

describe('detectDiskComboDrift', () => {
  it('flags a VM whose stored disk_gb no longer equals the combo\'s CURRENT summed sizes', () => {
    const combo = { id: 'c1', name: 'OS + Data L', sizes: [512, 2048] };
    const vms = [{ id: 'v1', scenario_id: 's1', name: 'db01', disk_gb: 512, disk_combo_id: 'c1' }];
    const drift = detectDiskComboDrift(vms, new Map([['c1', combo]]));
    assert.deepEqual(drift, [{
      scenarioId: 's1', vmId: 'v1', vmName: 'db01',
      catalogueId: 'c1', catalogueName: 'OS + Data L',
      field: 'disk_gb', oldValue: 512, newValue: 2560,
    }]);
  });

  it('reports nothing when the stored disk_gb already matches', () => {
    const combo = { id: 'c1', name: 'OS + Data L', sizes: [512, 2048] };
    const vms = [{ id: 'v1', scenario_id: 's1', name: 'db01', disk_gb: 2560, disk_combo_id: 'c1' }];
    assert.deepEqual(detectDiskComboDrift(vms, new Map([['c1', combo]])), []);
  });

  it('skips a VM whose combo reference no longer resolves', () => {
    const vms = [{ id: 'v1', scenario_id: 's1', name: 'db01', disk_gb: 512, disk_combo_id: 'gone' }];
    assert.deepEqual(detectDiskComboDrift(vms, new Map()), []);
  });

  // fmb-1736 A.1: an empty `sizes` array is an EMPTY CANDIDATE SET (fmb-1300
  // semantics), not "the true size is 0" — flagging it as drift would silently
  // rewrite a VM's real disk_gb to 0 on apply, from a transient authoring gap
  // rather than any global value someone actually set.
  it('reports nothing for a combo whose sizes array is empty, regardless of the stored disk_gb', () => {
    const combo = { id: 'c1', name: 'OS + Data L', sizes: [] };
    const vms = [{ id: 'v1', scenario_id: 's1', name: 'db01', disk_gb: 512, disk_combo_id: 'c1' }];
    assert.deepEqual(detectDiskComboDrift(vms, new Map([['c1', combo]])), []);
  });

  it('reports nothing for a combo whose sizes is a string-encoded empty array', () => {
    const combo = { id: 'c1', name: 'OS + Data L', sizes: '[]' };
    const vms = [{ id: 'v1', scenario_id: 's1', name: 'db01', disk_gb: 512, disk_combo_id: 'c1' }];
    assert.deepEqual(detectDiskComboDrift(vms, new Map([['c1', combo]])), []);
  });

  it('still flags drift for a combo whose sizes are non-empty (guard does not swallow real drift)', () => {
    const combo = { id: 'c1', name: 'OS + Data L', sizes: [100] };
    const vms = [{ id: 'v1', scenario_id: 's1', name: 'db01', disk_gb: 512, disk_combo_id: 'c1' }];
    const drift = detectDiskComboDrift(vms, new Map([['c1', combo]]));
    assert.equal(drift.length, 1);
    assert.equal(drift[0].newValue, 100);
  });

  // fmb-1736 F4 (review round 1, adv LOW — closes A.1's own rationale): a
  // JUNK-ONLY array is NOT length-empty, so the plain length guard let it
  // through as "has sizes" — `sumDiskComboSizes` then reduces it to 0 exactly
  // like a length-0 array, reproducing the SAME drift-to-0 bug A.1 exists to
  // prevent, via a different empty-candidate shape.
  it('reports nothing for a combo whose sizes array holds only unparsable junk (no finite numeric entry)', () => {
    const combo = { id: 'c1', name: 'OS + Data L', sizes: ['bad'] };
    const vms = [{ id: 'v1', scenario_id: 's1', name: 'db01', disk_gb: 512, disk_combo_id: 'c1' }];
    assert.deepEqual(detectDiskComboDrift(vms, new Map([['c1', combo]])), []);
  });

  // `Number(null) === 0` is a coercion ARTIFACT of the value's absence, not a
  // size anyone authored — counting it would silently readmit the exact
  // "empty candidate reads as a real 0" bug, so `null` is excluded before the
  // numeric coercion even runs (not blind `sumDiskComboSizes` parity).
  it('reports nothing for a combo whose sizes array holds only null', () => {
    const combo = { id: 'c1', name: 'OS + Data L', sizes: [null] };
    const vms = [{ id: 'v1', scenario_id: 's1', name: 'db01', disk_gb: 512, disk_combo_id: 'c1' }];
    assert.deepEqual(detectDiskComboDrift(vms, new Map([['c1', combo]])), []);
  });

  it('still flags drift for a combo whose sizes mix ONE real number among junk (a genuine size is never swallowed by neighboring junk)', () => {
    const combo = { id: 'c1', name: 'OS + Data L', sizes: ['bad', 100, null] };
    const vms = [{ id: 'v1', scenario_id: 's1', name: 'db01', disk_gb: 512, disk_combo_id: 'c1' }];
    const drift = detectDiskComboDrift(vms, new Map([['c1', combo]]));
    assert.equal(drift.length, 1);
    assert.equal(drift[0].newValue, 100);
  });
});

describe('groupDriftByScenario', () => {
  it('folds a flat drift list into ONE row per scenario (Q12 scenario-level granularity)', () => {
    const drift = [
      { scenarioId: 's1', vmId: 'v1', vmName: 'db01', catalogueId: 'p1', catalogueName: 'DB-Large', field: 'cpu', oldValue: 8, newValue: 16 },
      { scenarioId: 's1', vmId: 'v2', vmName: 'db02', catalogueId: 'p1', catalogueName: 'DB-Large', field: 'cpu', oldValue: 8, newValue: 16 },
      { scenarioId: 's2', vmId: 'v3', vmName: 'db03', catalogueId: 'p1', catalogueName: 'DB-Large', field: 'cpu', oldValue: 8, newValue: 16 },
    ];
    const grouped = groupDriftByScenario(drift, new Map([['s1', 'Alpha'], ['s2', 'Beta']]));
    assert.equal(grouped.length, 2);
    const alpha = grouped.find((g) => g.scenarioId === 's1');
    assert.equal(alpha.scenarioName, 'Alpha');
    assert.equal(alpha.vmCount, 2); // two DISTINCT vms, not two drift entries
    assert.equal(alpha.items.length, 1); // one (catalogue, field, old, new) line
    assert.equal(alpha.items[0].vmCount, 2);
  });

  it('a mixed old value on the SAME field produces a SECOND item line rather than merging silently', () => {
    const drift = [
      { scenarioId: 's1', vmId: 'v1', vmName: 'db01', catalogueId: 'p1', catalogueName: 'DB-Large', field: 'cpu', oldValue: 8, newValue: 16 },
      { scenarioId: 's1', vmId: 'v2', vmName: 'db02', catalogueId: 'p1', catalogueName: 'DB-Large', field: 'cpu', oldValue: 4, newValue: 16 },
    ];
    const grouped = groupDriftByScenario(drift, new Map([['s1', 'Alpha']]));
    assert.equal(grouped[0].items.length, 2);
    assert.deepEqual(grouped[0].items.map((i) => i.oldValue).sort(), [4, 8]);
  });

  it('falls back to the raw id when a scenario name is missing from the map', () => {
    const drift = [{ scenarioId: 's-missing', vmId: 'v1', vmName: 'db01', catalogueId: 'p1', catalogueName: 'X', field: 'cpu', oldValue: 1, newValue: 2 }];
    const grouped = groupDriftByScenario(drift, new Map());
    assert.equal(grouped[0].scenarioName, 's-missing');
  });

  it('sorts rows by scenario name for a stable first paint', () => {
    const drift = [
      { scenarioId: 's-b', vmId: 'v1', vmName: 'x', catalogueId: 'p1', catalogueName: 'X', field: 'cpu', oldValue: 1, newValue: 2 },
      { scenarioId: 's-a', vmId: 'v2', vmName: 'y', catalogueId: 'p1', catalogueName: 'X', field: 'cpu', oldValue: 1, newValue: 2 },
    ];
    const grouped = groupDriftByScenario(drift, new Map([['s-b', 'Zeta'], ['s-a', 'Alpha']]));
    assert.deepEqual(grouped.map((g) => g.scenarioName), ['Alpha', 'Zeta']);
  });

  it('an empty drift list yields no rows', () => {
    assert.deepEqual(groupDriftByScenario([], new Map()), []);
  });
});
