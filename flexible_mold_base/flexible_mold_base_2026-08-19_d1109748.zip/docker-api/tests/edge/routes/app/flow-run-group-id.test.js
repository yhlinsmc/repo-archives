// docker-api/tests/edge/routes/app/flow-run-group-id.test.js
//
// The identifier a run group is addressed by. Two kinds of group share one path
// segment, and this file is what holds their spaces apart: a template id is
// arbitrary text — the column is nullable, has no foreign key, and the write
// path checks no shape — so the space of template identifiers must stay disjoint
// from the one word that means "the runs recorded with no template", whatever a
// template id happens to hold.
const { test } = require('node:test');
const assert = require('node:assert');

const {
  NO_TEMPLATE_GROUP, TEMPLATE_GROUP_PREFIX, MAX_GROUP_ID_CHARS,
  GROUP_ID_PARITY_TEMPLATE_IDS, decodeGroupId,
} = require('../../../../src/edge/routes/app/flow-recipe-runs/group-id');

/** The frontend's encoder, restated as the property it has to satisfy rather
 *  than as a copy of it: the real one is `groupRouteId` in
 *  `src/fmb/hooks/useFlowRuns.ts`, and the two are compared against each other
 *  in `src/fmb/hooks/__tests__/flow-run-group-id.parity.test.ts`, which this
 *  runner cannot load. */
const encode = (templateId) => `${TEMPLATE_GROUP_PREFIX}${encodeURIComponent(templateId)}`;

test('the two kinds cannot spell each other — the disjointness the scheme rests on', () => {
  // Collision-freedom is a relation between these two constants: every template
  // identifier begins with the prefix and the no-template identifier does not,
  // so no template id whatsoever can reach the no-template group. A change to
  // either constant that broke this would otherwise be silent.
  assert.ok(!NO_TEMPLATE_GROUP.startsWith(TEMPLATE_GROUP_PREFIX));
  assert.ok(!TEMPLATE_GROUP_PREFIX.startsWith(NO_TEMPLATE_GROUP));
  assert.ok(TEMPLATE_GROUP_PREFIX.length > 0);
});

test('the reserved word names the runs with no template, and nothing else does', () => {
  assert.deepStrictEqual(decodeGroupId(NO_TEMPLATE_GROUP), { ok: true, templateId: null });
  for (const templateId of GROUP_ID_PARITY_TEMPLATE_IDS) {
    assert.notStrictEqual(encode(templateId), NO_TEMPLATE_GROUP);
    assert.notStrictEqual(decodeGroupId(encode(templateId)).templateId, null);
  }
});

test('every template id round trips to itself, whatever text it holds', () => {
  for (const templateId of GROUP_ID_PARITY_TEMPLATE_IDS) {
    assert.deepStrictEqual(
      decodeGroupId(encode(templateId)),
      { ok: true, templateId },
      `identifier for ${JSON.stringify(templateId)} did not name it back`,
    );
  }
});

test('a template id that spells the reserved word opens its own runs', () => {
  // The failure this module exists to end: this identifier used to be the word
  // itself, so the page showed the runs that named NO template under a heading
  // for a template that does exist.
  const decoded = decodeGroupId(encode(NO_TEMPLATE_GROUP));
  assert.strictEqual(decoded.ok, true);
  assert.strictEqual(decoded.templateId, NO_TEMPLATE_GROUP);
});

test('a template id that is not identifier-shaped is still addressable', () => {
  // The other half of the same failure: the first level listed this group and
  // the second refused it, because the second inferred the kind from the shape.
  assert.deepStrictEqual(decodeGroupId(encode('legacy-7')), { ok: true, templateId: 'legacy-7' });
  assert.deepStrictEqual(decodeGroupId(encode('a/b')), { ok: true, templateId: 'a/b' });
  assert.deepStrictEqual(decodeGroupId(encode('')), { ok: true, templateId: '' });
});

test('a segment carrying no kind names nothing, and never the group with no template', () => {
  // Falling through to the no-template group is how a page came to show the
  // wrong rows with confidence, so "unknown" must be its own answer.
  for (const segment of [
    'not-an-id',
    '11111111-1111-1111-1111-111111111111',
    '',
    'None',
    'none ',
    ' none',
    'nonet.',
    't',
    undefined,
    null,
    42,
    ['none'],
  ]) {
    assert.deepStrictEqual(decodeGroupId(segment), { ok: false }, `accepted ${String(segment)}`);
  }
});

test('a payload that is not valid encoding names nothing', () => {
  assert.deepStrictEqual(decodeGroupId(`${TEMPLATE_GROUP_PREFIX}%`), { ok: false });
  assert.deepStrictEqual(decodeGroupId(`${TEMPLATE_GROUP_PREFIX}%zz`), { ok: false });
});

test('the length guard cannot refuse a value the column could hold', () => {
  // It is a guard on input size, not on shape. `template_id` is CHAR(36) in
  // utf8mb4: 36 characters of up to 4 bytes, and percent-encoding spends 3
  // characters per byte, so the widest storable value encodes to this.
  const widest = TEMPLATE_GROUP_PREFIX.length + (36 * 4 * 3);
  assert.ok(MAX_GROUP_ID_CHARS > widest, `${MAX_GROUP_ID_CHARS} would refuse a stored value`);
  assert.deepStrictEqual(decodeGroupId(`${TEMPLATE_GROUP_PREFIX}${'a'.repeat(MAX_GROUP_ID_CHARS)}`), { ok: false });
});
