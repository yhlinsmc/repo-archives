/**
 * capacity-whole-numbers.test.js — fmb-1433 on the server side: a derived
 * capacity number is floored to a whole number, and SGA is accepted as whole
 * numbers only, on EVERY write path into the columns the ruling names.
 *
 * The frontend guard is the operator's first line, not the boundary — a raw API
 * call, a pasted grid cell, an xlsx scenario import and an xlsx/csv config
 * import all reach these same columns without passing through it, so each is
 * probed here:
 *   - `resolveProfileSizing`  — the server twin of the FE formula derive
 *   - `validateColumnTypes`   — the /config + /local-catalogues write guard
 *   - `validateItemBody`      — the bundle-item seed (direct write AND config import)
 *   - `buildImportPlan`       — the scenario xlsx import
 *   - `buildConfigImportPlan` — the first-instance global-config import
 *
 * Every module here destructures `{ t }` from ../../../db at load without
 * calling it, so the db module is stubbed to keep the require side-effect-free
 * (no pool) — the same pattern capacity-sga-cascade.test.js uses.
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');

const dbKey = require.resolve('../../../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: {}, t: (n) => `fmb_${n}` },
};

const {
  resolveProfileSizing, validateColumnTypes, CONFIG_MOUNTS, DEFAULT_FORMULA,
  SETTINGS_COLUMN_TYPES, readFormulaConstants,
} = require('../../../../src/edge/routes/app/capacity/_shared');
const { validateItemBody } = require('../../../../src/edge/routes/app/capacity/bundles');
const { buildImportPlan } = require('../../../../src/edge/routes/app/capacity/io');
const { buildConfigImportPlan } = require('../../../../src/edge/routes/app/capacity/config-import');
const { floorGb, FLOOR_GB_PARITY_INPUTS } = require('../../../../src/shared/capacity/whole-numbers');
const { deriveInstanceSga } = require('../../../../src/shared/capacity/sga-defaults');
const { usableForSpec, computeSgaCap } = require('../../../../src/shared/capacity/evaluator');

const FRACTIONAL_RATIO = { ...DEFAULT_FORMULA, memCpuRatio: 20.5 };

describe('floorGb (shared helper)', () => {
  it('floors, never rounds', () => {
    assert.equal(floorGb(66.7), 66);
    assert.equal(floorGb(0.5), 0);
    assert.equal(floorGb(0.99), 0);
    assert.equal(floorGb(0.9999999999), 0);
  });
  it('treats binary-floating-point noise as the whole number it stands for', () => {
    assert.equal(floorGb(1.9999999999999996), 2);
    assert.equal(floorGb(62.99999999999999), 63);
  });

  // BOTH EDGES OF THE SNAP WINDOW, pinned against the two ways it can be got
  // wrong. The window is absolute (SNAP_EPSILON, in the floored unit) because the
  // error it absorbs is relative to the OPERANDS, not to the result.
  //
  // These two assertions squeeze SNAP_EPSILON from opposite sides, so the pin
  // cannot be satisfied by moving the constant:
  //   - too NARROW and the residue case floors a whole gigabyte too low, which is
  //     the defect the absolute window exists to fix;
  //   - too WIDE and a real value below a whole number is rounded UP, which is
  //     the one thing a function named "floor" must never do.
  // Anyone widening this to chase a newly-found residue fails the second one and
  // has to come back and read this.
  it('is wide enough for the worst float residue the domain produces', () => {
    // Exhaustive search over mem_total_gb 1–8192 × mem_reserved_pct at two
    // decimals: this is the LARGEST below-integer residue in the whole domain
    // (4211.999999999999, i.e. 9.1e-13 short of 4212). Nothing realistic asks
    // the window to absorb more than this.
    assert.equal(floorGb(5625 * (1 - 25.12 / 100)), 4212);
    assert.equal(floorGb(2000 * (1 - 93.65 / 100)), 127);
  });

  it('is narrow enough that a real value below a whole number stays below it', () => {
    // One part in 1e10 under a whole number — three orders of magnitude closer to
    // the boundary than any quantity these columns can express, and it still
    // floors DOWN.
    assert.equal(floorGb(1 - 1e-10), 0);
    assert.equal(floorGb(4212 - 1e-8), 4211);
  });

  it('passes non-finite input through exactly as Math.floor does', () => {
    assert.ok(Number.isNaN(floorGb(NaN)));
    assert.equal(floorGb(Infinity), Infinity);
    assert.equal(floorGb(-Infinity), -Infinity);
  });

  // The parity INPUT SET is the contract this file shares with the two frontend
  // copies (item 8). The identical-output assertion lives in the vitest suite —
  // the only runner that can load all three copies — so what is checked HERE is
  // that the set it will be driven over is worth driving: hand-picking a set of
  // easy inputs would make that parity check as vacuous as the hand-matched
  // expectations it replaces.
  it('publishes an input set that actually exercises the helper', () => {
    const finite = FLOOR_GB_PARITY_INPUTS.filter((v) => Number.isFinite(v));
    assert.ok(FLOOR_GB_PARITY_INPUTS.length >= 20, 'a parity set this small proves little');
    assert.ok(
      finite.some((v) => !Number.isInteger(v) && floorGb(v) > Math.floor(v)),
      'the set must contain float noise that only the snap window resolves',
    );
    assert.ok(
      finite.some((v) => !Number.isInteger(v) && floorGb(v) === Math.floor(v) && v > 0),
      'and a real fraction that must floor DOWN',
    );
    assert.ok(finite.some((v) => v < 0), 'and a negative, where floor and truncate disagree');
    assert.ok(FLOOR_GB_PARITY_INPUTS.some((v) => !Number.isFinite(v)), 'and the pass-through cases');
    for (const v of finite) {
      assert.ok(Number.isInteger(floorGb(v)), `floorGb(${v}) must be whole`);
    }
  });
});

describe('site 1 — resolveProfileSizing floors the derived memory (FE parity)', () => {
  it('formula mode: a fractional ratio still yields whole GB', () => {
    const sizing = resolveProfileSizing({ class: 'DB', mode: 'formula', cpu: 3 }, FRACTIONAL_RATIO);
    assert.equal(sizing.memGb, 61); // 3 × 20.5 = 61.5
  });

  it('formula mode: floors DOWN a value that would round UP (direction pin)', () => {
    const sizing = resolveProfileSizing({ class: 'AP', mode: 'formula', cpu: 1 }, { ...DEFAULT_FORMULA, memCpuRatio: 20.7 });
    assert.equal(sizing.memGb, 20);
  });

  it('the SGA cap derives from the FLOORED memory', () => {
    const sizing = resolveProfileSizing({ class: 'DB', mode: 'formula', cpu: 3 }, FRACTIONAL_RATIO);
    assert.equal(sizing.sgaCapGb, 27); // floor(61 × 0.982 / 2 − 2)
  });

  it('sites 2 + 5 — custom mode floors a stored fraction (rows predate the rule)', () => {
    const sizing = resolveProfileSizing(
      { class: 'DB', mode: 'custom', cpu: 8, mem_gb: 61.5, sga_cap_gb: 27.9 }, DEFAULT_FORMULA,
    );
    assert.equal(sizing.memGb, 61);
    assert.equal(sizing.sgaCapGb, 27);
  });
});

// The SGA cap has TWO producers and one screen shows both: the sizing surface
// derives it through resolveProfileSizing (the KVM SGA-ref column reads that),
// and the evaluator re-derives it in computeSgaCap to decide whether to raise a
// violation. A disagreement is visible as a VM rendered red against a cap no
// violation was raised for.
//
// So these assertions compare the two PRODUCERS, never a producer against a
// hand-written number: a number written here would be a third opinion, and the
// defect this pins was two implementations rounding at different steps, which
// hand-written expectations in two suites cannot see.
describe('the two SGA-cap producers agree (evaluator ↔ sizing surface)', () => {
  // One source of constants for both: the settings ROW feeds computeSgaCap, and
  // the same row is read into the formula shape resolveProfileSizing takes.
  const agreeOn = (profile, settingsRow) => {
    const fromEvaluator = computeSgaCap(profile, settingsRow);
    const fromSizing = resolveProfileSizing(profile, readFormulaConstants(settingsRow)).sgaCapGb;
    assert.equal(
      fromEvaluator, fromSizing,
      `${JSON.stringify(profile)} @ ${JSON.stringify(settingsRow)}: evaluator says ${fromEvaluator}, the sizing surface shows ${fromSizing}`,
    );
    return fromEvaluator;
  };

  const FRACTIONAL_SETTINGS = {
    mem_cpu_ratio: 20.5, sga_factor: 0.982, sga_divisor: 2, sga_subtract: 2,
  };

  it('formula mode: a fractional mem_cpu_ratio does not split them', () => {
    for (const cpu of [1, 2, 3, 5, 7, 8, 16, 33]) {
      agreeOn({ class: 'DB', mode: 'formula', cpu }, FRACTIONAL_SETTINGS);
    }
  });

  it('custom mode: a row still holding a fraction does not split them', () => {
    for (const capGb of [27.9, 96.5, 48.25, 120]) {
      agreeOn({ class: 'DB', mode: 'custom', cpu: 8, mem_gb: 61.5, sga_cap_gb: capGb }, FRACTIONAL_SETTINGS);
    }
  });

  it('neither producer hands an operator a fractional cap', () => {
    const cap = agreeOn({ class: 'DB', mode: 'custom', cpu: 8, sga_cap_gb: 27.9 }, FRACTIONAL_SETTINGS);
    assert.ok(Number.isInteger(cap), `a violation message would read "over its profile cap of ${cap} GB"`);
    const derived = agreeOn({ class: 'DB', mode: 'formula', cpu: 3 }, FRACTIONAL_SETTINGS);
    assert.ok(Number.isInteger(derived));
  });

  it('they agree across the whole constant grid, not just the default one', () => {
    for (const mem_cpu_ratio of [10, 20, 20.5, 20.7, 33.3]) {
      for (const sga_factor of [0.9, 0.982, 1]) {
        for (const sga_divisor of [1, 2, 3]) {
          for (const sga_subtract of [0, 1, 2, 2.5]) {
            for (const cpu of [1, 3, 8, 16]) {
              agreeOn(
                { class: 'DB', mode: 'formula', cpu },
                { mem_cpu_ratio, sga_factor, sga_divisor, sga_subtract },
              );
            }
          }
        }
      }
    }
  });
});

describe('site 3 — usableForSpec floors usable memory (CJS reference)', () => {
  const spec = (over) => ({
    cpu_total: 64, mem_total_gb: 1000, disk_total_gb: 500,
    cpu_reserved: 0, mem_reserved_pct: 0, disk_reserved_gb: 0, ...over,
  });
  it('a fractional reserve leaves whole GB', () => {
    assert.equal(usableForSpec(spec({ mem_total_gb: 250, mem_reserved_pct: 12.5 })).mem, 218);
  });
  it('floors DOWN a value that would round UP (direction pin)', () => {
    assert.equal(usableForSpec(spec({ mem_total_gb: 100, mem_reserved_pct: 33.3 })).mem, 66);
  });
  it('a mathematically whole reserve is not shaved by floating point', () => {
    assert.equal(usableForSpec(spec({ mem_total_gb: 10, mem_reserved_pct: 80 })).mem, 2);
  });

  // A LARGE reserve is where the arithmetic cancels most of its magnitude away
  // and the residue outgrows a result-relative tolerance: every one of these
  // returned a whole gigabyte too little before the window became absolute. The
  // reserves are unrealistic on purpose — they are the smallest ones that reach
  // the failure, so this stays a pin on the tolerance rather than on a scenario.
  it('a large reserve does not lose a whole gigabyte to float residue', () => {
    assert.equal(usableForSpec(spec({ mem_total_gb: 250, mem_reserved_pct: 96.4 })).mem, 9);
    assert.equal(usableForSpec(spec({ mem_total_gb: 500, mem_reserved_pct: 96.2 })).mem, 19);
    assert.equal(usableForSpec(spec({ mem_total_gb: 2000, mem_reserved_pct: 93.65 })).mem, 127);
    assert.equal(usableForSpec(spec({ mem_total_gb: 5625, mem_reserved_pct: 25.12 })).mem, 4212);
  });

  // The negative control. CPU and disk are plain subtractions and are NOT part
  // of the whole-number ruling, so the reserves here are deliberately fractional
  // — with whole reserves the assertion holds whether or not someone extends
  // floorGb across all three resources, which is exactly the mutation it exists
  // to catch.
  it('CPU and disk keep their fractions — the rule is about DERIVED memory only', () => {
    const u = usableForSpec(spec({ cpu_reserved: 1.5, disk_reserved_gb: 50.5 }));
    assert.equal(u.cpu, 62.5);
    assert.equal(u.disk, 449.5);
  });
});

describe('site 4 — the derived instance SGA is whole', () => {
  it('floors a database SGA a legacy row still holds as a fraction', () => {
    assert.equal(deriveInstanceSga('primary', { primary_sga_gb: 96.5 }, null, null), 96);
    assert.equal(deriveInstanceSga('standby', { standby_sga_gb: 48.9 }, null, null), 48);
  });
  it('floors a fractional profile cap falling through the derive chain', () => {
    assert.equal(deriveInstanceSga('primary', null, null, { sgaCapGb: 27.9 }), 27);
  });
});

describe('sites 2 + 5 — the /config and /local-catalogues write guard', () => {
  const types = CONFIG_MOUNTS.vm_profiles.types;

  it('rejects a fractional mem_gb', () => {
    assert.equal(validateColumnTypes({ mem_gb: 61.5 }, types), 'mem_gb must be a whole number');
  });
  it('rejects a fractional sga_cap_gb', () => {
    assert.equal(validateColumnTypes({ sga_cap_gb: 27.9 }, types), 'sga_cap_gb must be a whole number');
  });
  it('accepts a whole value, an explicit null (derive) and an omitted column', () => {
    assert.equal(validateColumnTypes({ mem_gb: 256, sga_cap_gb: 120 }, types), null);
    assert.equal(validateColumnTypes({ mem_gb: null, sga_cap_gb: null }, types), null);
    assert.equal(validateColumnTypes({ name: 'DB-X' }, types), null);
  });
});

describe('the global Standby SGA default is a whole number', () => {
  // One map, two mounts: the global /config/settings write AND the scenario
  // settings.js singleton both run validateColumnTypes over it.
  it('rejects a fractional standby_sga_default_gb', () => {
    assert.equal(
      validateColumnTypes({ standby_sga_default_gb: 32.5 }, SETTINGS_COLUMN_TYPES),
      'standby_sga_default_gb must be a whole number',
    );
  });
  it('leaves the formula constants free to be fractional (a ratio need not be whole)', () => {
    assert.equal(validateColumnTypes({ mem_cpu_ratio: 20.5, sga_factor: 0.982 }, SETTINGS_COLUMN_TYPES), null);
  });
  it('still accepts a whole default and the negative guard is unchanged', () => {
    assert.equal(validateColumnTypes({ standby_sga_default_gb: 32 }, SETTINGS_COLUMN_TYPES), null);
  });
});

describe('site 4 — the bundle-item SGA seed', () => {
  it('rejects a fractional Primary / Standby SGA', () => {
    assert.match(String(validateItemBody({ primary_sga_gb: 96.5 })), /whole number/);
    assert.match(String(validateItemBody({ standby_sga_gb: 48.9 })), /whole number/);
  });
  it('still accepts a whole value and an explicit null (inherit the derive chain)', () => {
    assert.equal(validateItemBody({ type: 'DB', primary_sga_gb: 96, standby_sga_gb: null }), null);
  });
});

// An import is NOT the edit path, and the difference is deliberate (io.js
// WHOLE_NUMBER_IMPORT_RULE): these columns are ones the app derived and wrote,
// the file is accepted or rejected whole, and config import is the only
// supported way to seed a fresh instance. Refusing a fraction here would mean
// this release cannot load the workbook the previous release exported. So the
// value is FLOORED and the report says so — the operator is told, nothing is
// silent, and the seeding path still works.
describe('the import paths floor a derived fraction and report it', () => {
  const floored = (plan, sheet, column) =>
    plan.notices.find((n) => n.sheet === sheet && n.column === column && n.code === 'FLOORED_TO_WHOLE');

  it('scenario xlsx import: a fractional profile mem_gb / sga_cap_gb lands whole, with a notice', () => {
    const plan = buildImportPlan({
      vm_profiles: [{ class: 'DB', name: 'DB-X', mode: 'custom', cpu: 8, mem_gb: 61.5, sga_cap_gb: 27.9 }],
    }, 'u-ed');
    assert.equal(plan.ok, true, JSON.stringify(plan.errors));
    const row = plan.plan.vm_profiles[0].dbRow;
    assert.equal(row.mem_gb, 61);
    assert.equal(row.sga_cap_gb, 27);
    for (const col of ['mem_gb', 'sga_cap_gb']) {
      const notice = floored(plan, 'vm_profiles', col);
      assert.ok(notice, `no notice for ${col}: ${JSON.stringify(plan.notices)}`);
      assert.equal(notice.row, 2, 'the notice names the file row the operator has to look at');
      assert.match(notice.message, /whole number/);
    }
    assert.match(floored(plan, 'vm_profiles', 'mem_gb').message, /61\.5.*61/, 'both values are named');
  });

  // fmb-1433 item 1: cap_db_instances.sga_gb is what the SGA-cap check SUMS.
  // The scenario sheet carries it, and taking it raw would put the exact defect
  // this card exists to close back into the database through the import.
  it('scenario xlsx import: a fractional instance sga_gb lands whole, with a notice', () => {
    const plan = buildImportPlan({
      sites: [{ ref: 's1', name: 'DC-A' }],
      vms: [{ ref: 'vm1', name: 'db-1', vm_type: 'db_host', site_name: 'DC-A' }],
      db_instances: [{ name: 'erp1', role: 'primary', vm_ref: 'vm1', sga_gb: 96.5 }],
    }, 'u-ed');
    assert.equal(plan.ok, true, JSON.stringify(plan.errors));
    assert.equal(plan.plan.db_instances[0].dbRow.sga_gb, 96, 'the row written to cap_db_instances is whole');
    const notice = floored(plan, 'db_instances', 'sga_gb');
    assert.ok(notice, `no notice: ${JSON.stringify(plan.notices)}`);
    assert.match(notice.message, /96\.5/);
  });

  it('scenario xlsx import: a whole profile imports with nothing reported', () => {
    const plan = buildImportPlan({
      vm_profiles: [{ class: 'DB', name: 'DB-X', mode: 'custom', cpu: 8, mem_gb: 64, sga_cap_gb: 28 }],
    }, 'u-ed');
    assert.equal(plan.ok, true, JSON.stringify(plan.errors));
    assert.equal(plan.notices.some((n) => n.code === 'FLOORED_TO_WHOLE'), false);
  });

  it('scenario xlsx import: a VM memory an operator typed is NOT floored (the operator ruled it free-form)', () => {
    const plan = buildImportPlan({
      sites: [{ ref: 's1', name: 'DC-A' }],
      vms: [{ ref: 'vm1', name: 'db-1', vm_type: 'db_host', site_name: 'DC-A', mem_gb: 61.5 }],
    }, 'u-ed');
    assert.equal(plan.ok, true, JSON.stringify(plan.errors));
    assert.equal(plan.plan.vms[0].dbRow.mem_gb, 61.5, 'cap_vms.mem_gb stays exactly what the file says');
    assert.equal(plan.notices.some((n) => n.code === 'FLOORED_TO_WHOLE'), false);
  });

  it('config import: a fractional profile mem_gb lands whole, with a notice', () => {
    const plan = buildConfigImportPlan({
      schema_rev: 1,
      tables: { vm_profiles: [{ class: 'DB', name: 'DB-X', mode: 'custom', cpu: 8, mem_gb: 61.5 }] },
    });
    assert.equal(plan.ok, true, JSON.stringify(plan.errors));
    assert.equal(plan.plan.vm_profiles[0].dbRow.mem_gb, 61);
    assert.ok(floored(plan, 'vm_profiles', 'mem_gb'), JSON.stringify(plan.notices));
  });

  it('config import: a fractional standby SGA default lands whole, and the ratio beside it is untouched', () => {
    const plan = buildConfigImportPlan({
      schema_rev: 1,
      tables: { settings: [{ mem_cpu_ratio: 20.5, standby_sga_default_gb: 32.5 }] },
    });
    assert.equal(plan.ok, true, JSON.stringify(plan.errors));
    const row = plan.plan.settings[0].dbRow;
    assert.equal(row.standby_sga_default_gb, 32);
    assert.equal(row.mem_cpu_ratio, 20.5, 'a ratio is not a capacity quantity and keeps its decimals');
    assert.ok(floored(plan, 'settings', 'standby_sga_default_gb'), JSON.stringify(plan.notices));
    assert.equal(floored(plan, 'settings', 'mem_cpu_ratio'), undefined);
  });

  // The reason the whole change exists: the previous release exported these
  // columns raw, so its own workbook must load.
  it('config import: a workbook the previous release exported still seeds a fresh instance', () => {
    const plan = buildConfigImportPlan({
      schema_rev: 1,
      tables: {
        vm_profiles: [{ class: 'DB', name: 'DB-16C', mode: 'custom', cpu: 8, mem_gb: 61.5, sga_cap_gb: 27.9 }],
        settings: [{ mem_cpu_ratio: 20.5, standby_sga_default_gb: 32.5 }],
      },
    });
    assert.equal(plan.ok, true, `a legacy export must not be unloadable: ${JSON.stringify(plan.errors)}`);
    assert.equal(plan.notices.filter((n) => n.code === 'FLOORED_TO_WHOLE').length, 3);
  });

  // The bundle-item SGA seed reaches this path through the SAME export as every
  // other derived column (the config export is a SELECT *), so a table row
  // written before the rule would otherwise make the app refuse its own
  // workbook. It is floored and reported here, and still refused on the grid's
  // own route — the shared validator sees the already-floored value because the
  // flooring happens while the row is being built.
  it('config import: a fractional bundle-item SGA seed lands whole, with a notice', () => {
    const plan = buildConfigImportPlan({
      schema_rev: 1,
      tables: {
        bundles: [{ ref: 'b1', name: 'Bundle', serial: 1 }],
        bundle_items: [{
          bundle_ref: 'b1', type: 'DB', qty: 1, topology: 'single',
          primary_sga_gb: 96.5, standby_sga_gb: 48.25,
        }],
      },
    });
    assert.equal(plan.ok, true, JSON.stringify(plan.errors));
    const row = plan.plan.bundle_items[0].dbRow;
    assert.equal(row.primary_sga_gb, 96);
    assert.equal(row.standby_sga_gb, 48);
    for (const col of ['primary_sga_gb', 'standby_sga_gb']) {
      assert.ok(floored(plan, 'bundle_items', col), `no notice for ${col}: ${JSON.stringify(plan.notices)}`);
    }
  });

  it('config import: the bundle-item guards it shares with the grid still bite', () => {
    // Flooring must not have turned the shared validator into a no-op: a
    // NEGATIVE seed, and an AP item carrying any SGA at all, are still errors.
    const negative = buildConfigImportPlan({
      schema_rev: 1,
      tables: {
        bundles: [{ ref: 'b1', name: 'Bundle', serial: 1 }],
        bundle_items: [{ bundle_ref: 'b1', type: 'DB', qty: 1, topology: 'single', primary_sga_gb: -5 }],
      },
    });
    assert.equal(negative.ok, false);
    assert.ok(negative.errors.some((e) => e.sheet === 'bundle_items' && /non-negative/.test(e.message)), JSON.stringify(negative.errors));

    const apWithSga = buildConfigImportPlan({
      schema_rev: 1,
      tables: {
        bundles: [{ ref: 'b1', name: 'Bundle', serial: 1 }],
        bundle_items: [{ bundle_ref: 'b1', type: 'AP', qty: 1, primary_sga_gb: 96.5 }],
      },
    });
    assert.equal(apWithSga.ok, false);
    assert.ok(apWithSga.errors.some((e) => e.code === 'INVALID_ITEM_SGA'), JSON.stringify(apWithSga.errors));
  });
});

// The other half of the asymmetry: the route the bundle-items GRID posts to is
// unchanged. An operator typing a fraction into a cell is still refused, because
// there they authored the number and can fix it in place — the import is the
// surface where the value came out of this app's own export.
describe('the bundle-items grid route still refuses what the import floors', () => {
  it('rejects the same fractional seed the import accepts', () => {
    assert.match(String(validateItemBody({ type: 'DB', primary_sga_gb: 96.5 })), /whole number/);
  });
});
