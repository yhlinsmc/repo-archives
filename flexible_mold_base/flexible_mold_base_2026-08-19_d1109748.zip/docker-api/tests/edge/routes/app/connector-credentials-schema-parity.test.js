/**
 * connector-credentials-schema-parity.test.js — every column the credential and
 * review-boundary SQL names, checked against the ACTUAL DDL, with no live DB.
 *
 * WHY THIS EXISTS BESIDE A REAL-DB SUITE. A mocked driver answers with whatever
 * the fixture was told to say, so a query naming a column the table does not
 * have stays green in both runners and 500s in production. The real-DB suite
 * closes that for the paths it drives; this closes it for the statements
 * themselves — including the ones a test can only reach in a degraded shape,
 * and the DECLARED sets (the sensitive-column lists, the enum domains) whose
 * whole value is that they name real columns.
 */
const { describe, it, before } = require('node:test');
const assert = require('node:assert/strict');

// These modules destructure { t } from ../../../db at load; stub it so the
// require is side-effect-free (no pool).
const dbKey = require.resolve('../../../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: {
    pool: { ro: {}, rw: {} },
    t: (n) => n,
    getDynamicPool: async () => ({ ro: {}, rw: {} }),
  },
};

const { buildEngineTableDDLs, buildInfraTableDDLs } = require('../../../../src/table-ddls');
const { TABLES } = require('../../../../src/shared/constants');
const { enumMembersFor, enumColumnsFor } = require('../../../../src/edge/lib/schema-manifest');
const {
  SENSITIVE_PATHS, ALL_SECRET_LEAVES, authTypeMembers,
} = require('../../../../src/edge/lib/auth-config-secrets');
const { PARENT_REPEND_FROM, reviewRecordedSql } = require('../../../../src/edge/lib/review-status');
const connectorApproval = require('../../../../src/edge/routes/app/api-connectors/approval');
const recipeApproval = require('../../../../src/edge/routes/app/flow-recipes/approval');

const SQL_TYPES = /^`?([a-z_]+)`?\s+(?:CHAR|VARCHAR|INT|DOUBLE|TIMESTAMP|JSON|TEXT|ENUM|BOOLEAN|TINYINT|BIGINT|DATETIME|DECIMAL|FLOAT|BLOB)\b/i;
let columnsByTable;

before(() => {
  columnsByTable = new Map();
  for (const ddl of [...buildInfraTableDDLs((n) => n), ...buildEngineTableDDLs((n) => n)]) {
    const m = ddl.match(/CREATE TABLE IF NOT EXISTS `([^`]+)`/);
    if (!m) continue;
    const cols = new Set();
    for (const rawLine of ddl.split('\n')) {
      const line = rawLine.trim();
      if (!line || line.startsWith('--') || line.startsWith('/*')) continue;
      const cm = line.match(SQL_TYPES);
      if (cm) cols.add(cm[1]);
    }
    columnsByTable.set(m[1], cols);
  }
});

const columns = (table) => {
  const cols = columnsByTable.get(String(table));
  assert.ok(cols && cols.size > 0, `no columns parsed for ${table}`);
  return cols;
};

describe('the credential SQL names columns these tables have', () => {
  it('the mask-preserve read names auth_config, auth_type and request_config on both tables', () => {
    // The serializers' `readStored` binds these three, and the stored
    // `request_config` half is what makes a masked credential header mean
    // "unchanged" rather than "overwrite with the sentinel".
    for (const table of [TABLES.API_CONNECTORS, TABLES.FLOW_RECIPE_STEPS]) {
      for (const col of ['auth_config', 'auth_type', 'request_config']) {
        assert.ok(columns(table).has(col), `${table} is missing ${col}`);
      }
    }
  });

  it('every leaf the secret map names is reachable from a declared auth type', () => {
    // The union is derived from the map rather than listed beside it; this is
    // the assertion that says so, so a credential shape added to one and not the
    // other fails here instead of surviving a type change unencrypted.
    const derived = new Set(
      Object.keys(SENSITIVE_PATHS).flatMap((k) => SENSITIVE_PATHS[k].map((p) => p[p.length - 1])),
    );
    assert.deepEqual([...ALL_SECRET_LEAVES].sort(), [...derived].sort());
  });

  it('both tables declare the same auth_type domain, and the map covers it', () => {
    const connector = authTypeMembers(TABLES.API_CONNECTORS);
    const step = authTypeMembers(TABLES.FLOW_RECIPE_STEPS);
    assert.deepEqual(connector, step, 'the two auth_type columns no longer declare the same members');
    for (const member of connector) {
      assert.ok(
        Object.prototype.hasOwnProperty.call(SENSITIVE_PATHS, member),
        `${member} is a declared auth type with no sensitive-leaf path — its secret would be `
        + 'persisted and returned in clear',
      );
    }
  });

  it('the mounts\' enum domains are the DDL\'s whole answer, not a subset', () => {
    // A per-column list at a mount goes wrong by OMITTING a column, which is how
    // `auth_type` came to have no domain at all. Asking the table cannot omit
    // one, and this pins that the mounts still ask the table.
    for (const table of [TABLES.API_CONNECTORS, TABLES.FLOW_RECIPE_STEPS]) {
      const domains = enumColumnsFor(table);
      assert.ok(domains && Object.keys(domains).length > 0, `${table} declares no ENUM columns`);
      for (const [col, members] of Object.entries(domains)) {
        assert.ok(columns(table).has(col), `${table}.${col} is not a column`);
        assert.deepEqual(members, enumMembersFor(table, col), `${table}.${col} domain drifted`);
      }
    }
  });
});

describe('the review-boundary SQL names columns these tables have', () => {
  it('the connector re-pend watches real columns, and can clear a real approval', () => {
    const cols = columns(TABLES.API_CONNECTORS);
    for (const col of connectorApproval.SENSITIVE_SCALAR) {
      assert.ok(cols.has(col), `api_connectors is missing the watched column ${col}`);
    }
    for (const col of ['status', 'approved_by', 'approved_at']) {
      assert.ok(cols.has(col), `api_connectors is missing ${col}`);
    }
  });

  it('the recipe re-pend watches real columns on both of its lists', () => {
    const cols = columns(TABLES.FLOW_RECIPES);
    for (const col of [...recipeApproval.SENSITIVE_SCALAR, ...recipeApproval.JSON_SENSITIVE]) {
      assert.ok(cols.has(col), `flow_recipes is missing the watched column ${col}`);
    }
    for (const col of ['status', 'approved_by', 'approved_at']) {
      assert.ok(cols.has(col), `flow_recipes is missing ${col}`);
    }
  });

  it('every status the re-pend fires from is one the column can hold', () => {
    // NULL is on the list on purpose — a grandfathered parent still dispatches.
    // Every other entry has to be a declared member, or the comparison it feeds
    // is against a value the column never holds and the re-pend never fires.
    const members = enumMembersFor(TABLES.FLOW_RECIPES, 'status');
    for (const state of PARENT_REPEND_FROM) {
      if (state === null) continue;
      assert.ok(members.includes(state), `'${state}' is not a member of flow_recipes.status`);
    }
  });

  it('the SQL predicate names a member of the column it filters', () => {
    // The half no JavaScript test can see: a semantic changed in JavaScript and
    // left alone in the SQL is two answers again.
    const sql = reviewRecordedSql('status');
    const quoted = sql.match(/'([^']+)'/);
    assert.ok(quoted, 'the predicate no longer compares against a literal');
    assert.ok(
      enumMembersFor(TABLES.FLOW_RECIPES, 'status').includes(quoted[1]),
      `the predicate filters on '${quoted[1]}', which flow_recipes.status cannot hold`,
    );
  });

  it('the recipe delete\'s reference gate names a real child column', () => {
    assert.ok(
      columns(TABLES.FLOW_RECIPE_STEPS).has('recipe_id'),
      'flow_recipe_steps is missing recipe_id, which the delete gate filters on',
    );
  });

  it('the transformer reference set names both referrers\' real columns', () => {
    assert.ok(
      columns(TABLES.HIERARCHY_NODES).has('transformer_id'),
      'hierarchy_nodes is missing transformer_id',
    );
    assert.ok(
      columns(TABLES.API_CONNECTORS).has('response_config'),
      'api_connectors is missing response_config, which carries the connector\'s transformer binding',
    );
  });

  it('the author columns the read reduces are real columns', () => {
    for (const col of ['created_by', 'updated_by']) {
      assert.ok(columns(TABLES.TRANSFORMERS).has(col), `transformers is missing ${col}`);
    }
    assert.ok(
      columns(TABLES.TRANSFORMER_VERSIONS).has('created_by'),
      'transformer_versions is missing created_by',
    );
  });

  it('the run column the generic PUT now masks is a real column', () => {
    assert.ok(
      columns(TABLES.FLOW_RECIPE_RUNS).has('error_summary'),
      'flow_recipe_runs is missing error_summary',
    );
  });
});
