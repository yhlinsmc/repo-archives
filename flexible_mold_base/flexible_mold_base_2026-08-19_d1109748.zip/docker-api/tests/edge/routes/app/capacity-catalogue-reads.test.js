/**
 * capacity-catalogue-reads.test.js — GET /scenarios/:id/{specs,profiles} (R1.10).
 *
 * The reference model (spec §2 / §17.1a): a scenario sees GLOBAL catalogue rows
 * (scenario_id IS NULL) plus its own LOCAL rows (scenario_id = X). These
 * read-only mounts must SELECT global-or-same-scenario so the live placement
 * model's usable/SGA math resolves the referenced global catalogue. Runs against
 * a mock edge/db that records every SQL.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../../../src/edge/db');

let queries;
let rowsByTable;
let scenarioExists;

const conn = {
  async query(sql, params = []) {
    queries.push({ sql, params });
    // Scenario-exists guard (L1): SELECT 1 AS ok FROM cap_scenarios WHERE id=?.
    if (/SELECT 1 AS ok FROM `fmb_cap_scenarios` WHERE id = \?/.test(sql)) {
      return scenarioExists ? [{ ok: 1 }] : [];
    }
    const m = sql.match(/SELECT \* FROM `fmb_(cap_[a-z_]+)`/);
    if (m) return rowsByTable[m[1]] || [];
    return [];
  },
};
const poolFacade = { getConnection: async () => conn, query: (s, p) => conn.query(s, p) };
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: { ro: poolFacade, rw: poolFacade }, t: (n) => `fmb_${n}` },
};

const router = require('../../../../src/edge/routes/app/capacity');

let currentUser; let server; let baseUrl;
before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { req.user = currentUser; next(); });
  app.use('/capacity', router);
  server = http.createServer(app);
  await new Promise((r) => server.listen(0, r));
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});
after(() => server && server.close());
beforeEach(() => {
  queries = [];
  scenarioExists = true;
  rowsByTable = {
    cap_hardware_specs: [
      { id: 'gspec', scenario_id: null, name: 'Global', cpu_total: 64, mem_total_gb: 1000, disk_total_gb: 4000, cpu_reserved: 0, mem_reserved_pct: 0, disk_reserved_gb: 0, metadata: null },
      { id: 'lspec', scenario_id: 'scn-1', name: 'Local', cpu_total: 32, mem_total_gb: 500, disk_total_gb: 2000, cpu_reserved: 0, mem_reserved_pct: 0, disk_reserved_gb: 0, metadata: null },
    ],
    cap_vm_profiles: [
      { id: 'gprof', scenario_id: null, class: 'DB', name: 'DB-16C', mode: 'formula', cpu: 16, mem_gb: null, sga_cap_gb: null, allowed_disk_combos: null, metadata: null },
    ],
    cap_rules: [
      // The global default template row + one scenario-local override row.
      { id: 'g-rule', scenario_id: null, type: 'no-oversell', name: 'No oversell', level: 'hypervisor', group_by: 'all_of_type', custom_group_id: null, overrides_rule_id: null, filters: null, params: null, severity: 'hard', enabled: 1 },
      { id: 'o-rule', scenario_id: 'scn-1', type: 'no-oversell', name: 'No oversell', level: 'hypervisor', group_by: 'all_of_type', custom_group_id: null, overrides_rule_id: 'g-rule', filters: null, params: null, severity: 'hard', enabled: 0 },
    ],
  };
  currentUser = { id: 'u-user', role: 'user' };
});

function get(path) {
  return new Promise((resolve, reject) => {
    const r = http.request(`${baseUrl}${path}`, { method: 'GET' }, (res) => {
      const chunks = [];
      res.on('data', (c) => chunks.push(c));
      res.on('end', () => {
        let json = null;
        try { json = JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch { /* noop */ }
        resolve({ status: res.statusCode, json });
      });
    });
    r.on('error', reject);
    r.end();
  });
}

describe('GET /scenarios/:id/{specs,profiles} — global-or-same-scenario reads', () => {
  it('specs: reads global + same-scenario rows (all authenticated)', async () => {
    const res = await get('/capacity/scenarios/scn-1/specs');
    assert.equal(res.status, 200);
    const ids = res.json.data.map((r) => r.id).sort();
    assert.deepEqual(ids, ['gspec', 'lspec']);
  });

  it('specs: the SELECT is scoped global-or-same-scenario with the scenario id bound', async () => {
    await get('/capacity/scenarios/scn-1/specs');
    const q = queries.find((x) => /fmb_cap_hardware_specs/.test(x.sql));
    assert.ok(q, 'a hardware_specs SELECT was issued');
    assert.match(q.sql, /WHERE scenario_id IS NULL OR scenario_id = \?/);
    assert.deepEqual(q.params, ['scn-1']);
  });

  it('profiles: reads the vm_profiles catalogue global-or-same-scenario', async () => {
    const res = await get('/capacity/scenarios/scn-1/profiles');
    assert.equal(res.status, 200);
    assert.deepEqual(res.json.data.map((r) => r.id), ['gprof']);
    const q = queries.find((x) => /fmb_cap_vm_profiles/.test(x.sql));
    assert.match(q.sql, /WHERE scenario_id IS NULL OR scenario_id = \?/);
    assert.deepEqual(q.params, ['scn-1']);
  });

  it('rules: reads the global default template + this scenario\'s local rows merged (FE H2)', async () => {
    const res = await get('/capacity/scenarios/scn-1/rules');
    assert.equal(res.status, 200);
    const ids = res.json.data.map((r) => r.id).sort();
    assert.deepEqual(ids, ['g-rule', 'o-rule']); // global template + scenario override
    const q = queries.find((x) => /fmb_cap_rules/.test(x.sql));
    assert.match(q.sql, /WHERE scenario_id IS NULL OR scenario_id = \?/);
    assert.deepEqual(q.params, ['scn-1']);
  });

  it('404 when the scenario does not exist', async () => {
    scenarioExists = false;
    const res = await get('/capacity/scenarios/nope/specs');
    assert.equal(res.status, 404);
    // The catalogue SELECT must NOT run once the scenario is absent.
    assert.equal(queries.some((x) => /fmb_cap_hardware_specs/.test(x.sql)), false);
  });

  it('401 when unauthenticated', async () => {
    currentUser = undefined;
    const res = await get('/capacity/scenarios/scn-1/specs');
    assert.equal(res.status, 401);
  });
});
