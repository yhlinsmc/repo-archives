'use strict';

/**
 * hidden-field-disclosure-route.test.js — who learns that a field exists.
 *
 * The invariant: a hidden field's reason, and the name of the field that caused
 * it, leave this process only for an administrator or the editor who owns that
 * blueprint. Everyone else gets a refusal whose body carries neither.
 *
 * The assertions are on the RESPONSE BODY, not on a status code alone: a
 * handler that answered 403 and still serialised the catalogue would pass a
 * status check and ship the secret. Every refusal below is checked for the
 * absence of the field key, the field label, the reason and the causing field's
 * name in the bytes the caller receives.
 *
 * The driver is a stub, so what is established here is which question the
 * handler asks and what it answers. The ownership answer itself is driven by
 * `blueprintOwner` — what the database would report for the blueprint named.
 * The same gate is measured against a real database, per role, in
 * tests/integration/hidden-field-disclosure-real-db.test.js.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../../../src/edge/db');

let queries;
let blueprintOwner;   // owner_id the blueprint row reports; undefined = no such row
let fieldRows;        // rows the disclosure SELECT returns

function makeConn() {
  return {
    async query(sql, params = []) {
      queries.push({ sql, params });
      if (/^SELECT owner_id FROM `fmb_hierarchy_nodes`/.test(sql)) {
        return blueprintOwner === undefined ? [] : [{ owner_id: blueprintOwner }];
      }
      if (/FROM `fmb_blueprint_fields`/.test(sql)) return fieldRows;
      return [];
    },
    release() {},
  };
}

const poolFacade = { async getConnection() { return makeConn(); } };

require.cache[dbKey] = {
  id: dbKey,
  filename: dbKey,
  loaded: true,
  exports: {
    pool: { ro: poolFacade, rw: poolFacade },
    t: (n) => `fmb_${n}`,
    getDynamicPool: async () => ({ ro: poolFacade, rw: poolFacade }),
  },
};

const disclosure = require('../../../../src/edge/routes/app/schema/routes-hidden-field-disclosure');

const ADMIN = { id: '11111111-1111-1111-1111-111111111111', role: 'admin' };
const OWNER_EDITOR = { id: '22222222-2222-2222-2222-222222222222', role: 'editor' };
const OTHER_EDITOR = { id: '33333333-3333-3333-3333-333333333333', role: 'editor' };
const PLAIN_USER = { id: '44444444-4444-4444-4444-444444444444', role: 'user' };
const BLUEPRINT = 'aaaaaaaa-0000-0000-0000-00000000000a';
const VARIANT = 'bbbbbbbb-0000-0000-0000-00000000000b';

// One field hidden by a variant policy, one by a rule whose subject is the
// field above it, and one ordinary field that is never hidden at all.
const SECRET_KEY = 'internal_route_code';
const SECRET_LABEL = 'Internal Route Code';
const CAUSE_KEY = 'delivery_mode';
const CAUSE_LABEL = 'Delivery Mode';
const POLICY_KEY = 'legacy_batch_id';
const POLICY_LABEL = 'Legacy Batch Id';

function rows() {
  return [
    {
      field_key: CAUSE_KEY, field_label: CAUSE_LABEL, section: 'general', order_index: 0,
      field_type: 'select', has_rule: 0, rule_subject_key: null,
      override_action: null, override_cell_targets: null,
    },
    {
      field_key: SECRET_KEY, field_label: SECRET_LABEL, section: 'general', order_index: 1,
      field_type: 'text', has_rule: 1, rule_subject_key: CAUSE_KEY,
      override_action: null, override_cell_targets: null,
    },
    {
      field_key: POLICY_KEY, field_label: POLICY_LABEL, section: 'extra', order_index: 2,
      field_type: 'text', has_rule: 0, rule_subject_key: null,
      override_action: 'hide', override_cell_targets: null,
    },
  ];
}

let currentUser;
let server;
let baseUrl;

before(async () => {
  const app = express();
  const router = express.Router();
  disclosure.register(router);
  app.use(express.json());
  app.use((req, _res, next) => { if (currentUser) req.user = currentUser; next(); });
  app.use('/edge/app/schema', router);
  server = http.createServer(app);
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});

after(async () => { await new Promise((r) => server.close(r)); });

beforeEach(() => {
  queries = [];
  blueprintOwner = OWNER_EDITOR.id;
  fieldRows = rows();
  currentUser = ADMIN;
});

async function call(path) {
  const res = await fetch(`${baseUrl}/edge/app/schema${path}`);
  const text = await res.text();
  return { status: res.status, text, json: JSON.parse(text || '{}') };
}

const PATH = `/hidden-field-disclosure/${BLUEPRINT}?variant_id=${VARIANT}`;

/** Nothing about a hidden field reached this caller — the whole body, not a field of it. */
function carriesNothing(res) {
  for (const secret of [SECRET_KEY, SECRET_LABEL, POLICY_KEY, POLICY_LABEL, CAUSE_KEY, CAUSE_LABEL,
    'variant_policy', 'visibility_rule', 'entries']) {
    assert.ok(!res.text.includes(secret), `response leaked ${secret}: ${res.text}`);
  }
}

describe('who is told', () => {
  // The instrument, proved on a response that DOES carry the catalogue. Every
  // refusal below asserts an absence, and an absence assertion that cannot fire
  // is the shape that lets a leak ship green.
  it('the absence check fires on a body that carries the catalogue', async () => {
    const res = await call(PATH);
    assert.equal(res.status, 200);
    assert.throws(() => carriesNothing(res), /leaked/);
  });

  it('an administrator is told, with the reason and the causing field', async () => {
    const res = await call(PATH);
    assert.equal(res.status, 200);
    const byKey = new Map(res.json.data.entries.map((e) => [e.field_key, e]));
    assert.equal(byKey.get(SECRET_KEY).reason, 'visibility_rule');
    assert.equal(byKey.get(SECRET_KEY).cause_field_key, CAUSE_KEY);
    assert.equal(byKey.get(SECRET_KEY).cause_field_label, CAUSE_LABEL);
    assert.equal(byKey.get(POLICY_KEY).reason, 'variant_policy');
    // A field nothing hides is not in the catalogue at all.
    assert.equal(byKey.has(CAUSE_KEY), false);
  });

  it('the editor who owns the blueprint is told', async () => {
    currentUser = OWNER_EDITOR;
    const res = await call(PATH);
    assert.equal(res.status, 200);
    assert.equal(res.json.data.entries.length, 2);
  });

  it('an editor is told about a blueprint nobody owns — shared is shared', async () => {
    currentUser = OTHER_EDITOR;
    blueprintOwner = null;
    const res = await call(PATH);
    assert.equal(res.status, 200);
    assert.equal(res.json.data.entries.length, 2);
  });

  it('an ordinary user is refused, and the refusal carries nothing', async () => {
    currentUser = PLAIN_USER;
    const res = await call(PATH);
    assert.equal(res.status, 403);
    carriesNothing(res);
    // And the question was never asked of the database.
    assert.equal(queries.length, 0);
  });

  it('an unauthenticated caller is refused, and the refusal carries nothing', async () => {
    currentUser = null;
    const res = await call(PATH);
    assert.equal(res.status, 401);
    carriesNothing(res);
    assert.equal(queries.length, 0);
  });

  it('an editor who owns another blueprint is refused, and the refusal carries nothing', async () => {
    currentUser = OTHER_EDITOR;
    blueprintOwner = OWNER_EDITOR.id;
    const res = await call(PATH);
    assert.equal(res.status, 403);
    carriesNothing(res);
    // The ownership question was asked; the catalogue was never read.
    assert.ok(queries.some((q) => /^SELECT owner_id FROM `fmb_hierarchy_nodes`/.test(q.sql)));
    assert.equal(queries.filter((q) => /FROM `fmb_blueprint_fields`/.test(q.sql)).length, 0);
  });

  it('an editor is refused a blueprint that does not exist, and learns no more than that', async () => {
    currentUser = OTHER_EDITOR;
    blueprintOwner = undefined;
    const res = await call(PATH);
    assert.equal(res.status, 403);
    carriesNothing(res);
  });
});

describe('what the catalogue says', () => {
  it('a policy that hides the whole field is the reason, over a rule on the same field', async () => {
    fieldRows = rows();
    fieldRows[1].override_action = 'hide';
    const res = await call(PATH);
    const entry = res.json.data.entries.find((e) => e.field_key === SECRET_KEY);
    assert.equal(entry.reason, 'variant_policy');
    // R3: one reason, said once. The causing field belongs to the rule, and the
    // rule is not what is answering here.
    assert.equal(entry.cause_field_key, undefined);
    assert.equal(entry.cause_field_label, undefined);
  });

  it('a hide narrowed to table cells does not hide the field', async () => {
    fieldRows = rows();
    fieldRows[2].field_type = 'table';
    fieldRows[2].override_cell_targets = JSON.stringify({ rows: [0], columns: null });
    const res = await call(PATH);
    assert.equal(res.json.data.entries.some((e) => e.field_key === POLICY_KEY), false);
  });

  it('a hide whose scope names no cell still speaks for the whole field', async () => {
    fieldRows = rows();
    fieldRows[2].field_type = 'table';
    fieldRows[2].override_cell_targets = JSON.stringify({ rows: [], columns: [] });
    const res = await call(PATH);
    assert.equal(res.json.data.entries.find((e) => e.field_key === POLICY_KEY).reason, 'variant_policy');
  });

  it('says nothing about a causing field that has left the blueprint', async () => {
    fieldRows = rows();
    fieldRows[1].rule_subject_key = 'a_field_that_was_deleted';
    const res = await call(PATH);
    const entry = res.json.data.entries.find((e) => e.field_key === SECRET_KEY);
    assert.equal(entry.reason, 'visibility_rule');
    assert.equal(entry.cause_field_key, undefined);
  });

  it('binds the variant it was asked about, and no variant when none was named', async () => {
    await call(PATH);
    const q = queries.find((x) => /FROM `fmb_blueprint_fields`/.test(x.sql));
    assert.deepEqual(q.params, [VARIANT, BLUEPRINT]);
    queries = [];
    await call(`/hidden-field-disclosure/${BLUEPRINT}`);
    const q2 = queries.find((x) => /FROM `fmb_blueprint_fields`/.test(x.sql));
    assert.deepEqual(q2.params, [null, BLUEPRINT]);
  });

  it('refuses an identifier that is not one, before reaching the database', async () => {
    const res = await call('/hidden-field-disclosure/not-a-uuid');
    assert.equal(res.status, 400);
    assert.equal(queries.length, 0);
    const bad = await call(`/hidden-field-disclosure/${BLUEPRINT}?variant_id=nope`);
    assert.equal(bad.status, 400);
  });
});
