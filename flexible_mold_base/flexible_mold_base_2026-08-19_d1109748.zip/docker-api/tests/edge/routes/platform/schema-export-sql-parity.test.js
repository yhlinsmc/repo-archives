/**
 * schema-export-sql-parity.test.js — CLAUDE.md §6 schema-parity gate for the
 * fmb-1329 T5 SQL export, WITHOUT a live DB.
 *
 * The export never hand-writes column names: missing-table CREATE statements
 * come from the DDL builders, missing-column ALTERs come from ddlFragmentFor —
 * both sourced from table-ddls.js. This test mechanically proves that grounding
 * so a column the export could emit can never reference structure absent from
 * table-ddls.js (the exact drift the §6 rule guards against):
 *   1. every manifest column resolves to a verbatim ddlFragmentFor line;
 *   2. every manifest table has a CREATE TABLE in the builders (missing-table path);
 *   3. a sampled fragment byte-matches its table-ddls source line.
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');

const { buildAllTableDDLs } = require('../../../../src/table-ddls');
const { buildSchemaManifest, ddlFragmentFor } = require('../../../../src/edge/lib/schema-manifest');

const IDENTITY = (base) => base;
const manifest = buildSchemaManifest(IDENTITY);
const allDdls = buildAllTableDDLs(IDENTITY);

describe('schema-export-sql parity (manifest ↔ table-ddls)', () => {
  it('every manifest column resolves to a ddlFragmentFor line (no phantom ALTER targets)', () => {
    const unresolved = [];
    for (const [table, { columns }] of manifest) {
      for (const column of columns) {
        if (!ddlFragmentFor(table, column)) unresolved.push(`${table}.${column}`);
      }
    }
    assert.deepEqual(unresolved, [], `columns with no DDL fragment: ${unresolved.join(', ')}`);
  });

  it('every manifest table has a CREATE TABLE in the builders (no phantom CREATE targets)', () => {
    const missing = [];
    for (const [table] of manifest) {
      const found = allDdls.some((s) => s.includes(`CREATE TABLE IF NOT EXISTS \`${table}\``));
      if (!found) missing.push(table);
    }
    assert.deepEqual(missing, [], `tables with no CREATE TABLE: ${missing.join(', ')}`);
  });

  it('a sampled fragment byte-matches its column-definition line in the source DDL', () => {
    // owner_id is a real user_templates column; its fragment must equal the
    // exact line (trailing comma stripped) inside the CREATE TABLE text.
    const fragment = ddlFragmentFor('user_templates', 'owner_id');
    assert.ok(fragment, 'fragment exists');
    const createDdl = allDdls.find((s) => s.includes('CREATE TABLE IF NOT EXISTS `user_templates`'));
    assert.ok(createDdl, 'user_templates CREATE TABLE exists');
    const lineInDdl = createDdl
      .split('\n')
      .map((l) => l.trim().replace(/,\s*$/, ''))
      .includes(fragment);
    assert.equal(lineInDdl, true, `fragment "${fragment}" must appear verbatim in the CREATE TABLE body`);
  });

  it('the manifest is non-empty (guards against a parser regression silently emptying it)', () => {
    assert.ok(manifest.size >= 1);
  });
});
