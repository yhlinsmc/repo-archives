'use strict';

/**
 * schema-status-proceed-anyway.test.js — fmb-1329 PR2 Codex R1 fix.
 *
 * POST /edge/platform/schema-status/proceed-anyway validates schema_status
 * against a closed union before writing the feature_audit row. Originally
 * [failed, degraded]; widened to include 'unsupported' so the FE can stop
 * hardcoding 'failed' and pass the ACTUAL status from the schema-status
 * payload (ConnectionProfilesTab.tsx's handleSchemaGateProceed). Verifies:
 *   - 'unsupported' is now accepted and lands in the audit row's metadata
 *     JSON exactly as sent (proves the audit trail distinguishes
 *     below-baseline overrides from drift overrides).
 *   - 'failed' / 'degraded' still accepted (regression).
 *   - an out-of-union value is still rejected 400 (closed union, not opened
 *     wide — only the one new documented member was added).
 *
 * Harness mirrors hierarchy-reparent-route.test.js: require.cache DB stub +
 * real HTTP server + makeConn script runner; node:test runner.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

// ── DB stub must be in cache BEFORE the router is required ───────────────────
const dbKey = require.resolve('../../../../src/edge/db');

let conn;

function makeConn() {
  const queries = [];
  return {
    queries,
    async query(sql, params) {
      queries.push({ sql, params });
      if (/INSERT INTO .*feature_audit/i.test(sql)) return { affectedRows: 1 };
      throw new Error(`Unmatched query in proceed-anyway test: ${sql.slice(0, 120)}`);
    },
    release() { /* noop */ },
  };
}

const poolSpy = { rw: { async getConnection() { return conn; } } };

require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: poolSpy, t: (n) => `fmb_${n}`, PLATFORM_SCHEMA_VERSION: '3.2.520' },
};

const router = require('../../../../src/edge/routes/platform/schema-status');

// ── HTTP server ───────────────────────────────────────────────────────────────
let server, port;

function makeApp() {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => {
    req.user = { id: 'admin-uuid-1', role: 'admin' };
    next();
  });
  app.use('/edge/platform/schema-status', router);
  return app;
}

before(async () => {
  await new Promise((resolve) => {
    server = makeApp().listen(0, '127.0.0.1', () => {
      port = server.address().port;
      resolve();
    });
  });
});

after(async () => {
  await new Promise((resolve) => server.close(resolve));
  delete require.cache[dbKey];
});

beforeEach(() => {
  conn = makeConn();
});

function post(path, body) {
  return new Promise((resolve, reject) => {
    const data = JSON.stringify(body);
    const req = http.request({
      method: 'POST', host: '127.0.0.1', port, path,
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(data) },
    }, (res) => {
      let raw = '';
      res.on('data', (chunk) => { raw += chunk; });
      res.on('end', () => resolve({ status: res.statusCode, body: JSON.parse(raw) }));
    });
    req.on('error', reject);
    req.write(data);
    req.end();
  });
}

function baseBody(overrides = {}) {
  return {
    confirmation: 'OVERWRITE',
    connection_profile_id: 'profile-1',
    schema_status: 'failed',
    skipped_steps: [],
    ...overrides,
  };
}

describe('POST /edge/platform/schema-status/proceed-anyway', () => {
  it('accepts schema_status=unsupported and writes it verbatim to the audit row', async () => {
    const res = await post('/edge/platform/schema-status/proceed-anyway', baseBody({ schema_status: 'unsupported' }));
    assert.equal(res.status, 200);
    assert.equal(res.body.data.recorded, true);

    const insert = conn.queries.find((q) => /INSERT INTO .*feature_audit/i.test(q.sql));
    assert.ok(insert, 'audit INSERT was issued');
    const metadata = JSON.parse(insert.params[2]);
    assert.equal(metadata.schema_status, 'unsupported');
  });

  it('still accepts schema_status=failed (regression)', async () => {
    const res = await post('/edge/platform/schema-status/proceed-anyway', baseBody({ schema_status: 'failed' }));
    assert.equal(res.status, 200);
    const insert = conn.queries.find((q) => /INSERT INTO .*feature_audit/i.test(q.sql));
    assert.equal(JSON.parse(insert.params[2]).schema_status, 'failed');
  });

  it('still accepts schema_status=degraded (regression)', async () => {
    const res = await post('/edge/platform/schema-status/proceed-anyway', baseBody({ schema_status: 'degraded' }));
    assert.equal(res.status, 200);
    const insert = conn.queries.find((q) => /INSERT INTO .*feature_audit/i.test(q.sql));
    assert.equal(JSON.parse(insert.params[2]).schema_status, 'degraded');
  });

  it('rejects a schema_status value outside the closed union → 400, no audit row written', async () => {
    const res = await post('/edge/platform/schema-status/proceed-anyway', baseBody({ schema_status: 'aligned' }));
    assert.equal(res.status, 400);
    assert.equal(conn.queries.length, 0, 'no query issued before validation rejects');
  });
});
