/**
 * users-list-schema-parity.test.js — validates every column named in the
 * Users list SELECTs against the ACTUAL table DDL, without a live DB. The
 * node:test mocks stub query results, so a wrong/renamed column stays green
 * in both runners yet 500s in production. Columns are READ OUT OF THE
 * SOURCE (never hand-copied here) so adding one to the SQL puts it under
 * this check automatically — same approach as
 * capacity-delete-preview-schema-parity.test.js.
 */
const { describe, it, before } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const { buildAllTableDDLs } = require('../../../../src/table-ddls');
const { TABLES } = require('../../../../src/shared/constants');

let usersColumns;

before(() => {
  usersColumns = new Set();
  // `fmb_users` is an INFRA table (auth identity, not scenario-engine data),
  // so buildAllTableDDLs is used rather than buildEngineTableDDLs.
  for (const ddl of buildAllTableDDLs((n) => n)) {
    const m = ddl.match(/CREATE TABLE IF NOT EXISTS `([^`]+)`/);
    if (!m || m[1] !== String(TABLES.USERS)) continue;
    for (const rawLine of ddl.split('\n')) {
      const line = rawLine.trim();
      if (!line || line.startsWith('--') || line.startsWith('/*')) continue;
      const cm = line.match(/^`?([a-z_]+)`?\s+(?:CHAR|VARCHAR|INT|DOUBLE|TIMESTAMP|JSON|TEXT|ENUM|BOOLEAN|TINYINT|BIGINT|DATETIME|DECIMAL|FLOAT|BLOB)\b/i);
      if (cm) usersColumns.add(cm[1]);
    }
  }
});

const USERS_SRC = fs.readFileSync(
  path.resolve(__dirname, '../../../../src/edge/routes/platform/users.js'), 'utf8',
);

/** Every `SELECT <cols> FROM \`${t(TABLES.USERS)}\`` statement's column list,
 *  lifted from the route source rather than restated by hand. */
function selectStatementsAgainstUsers() {
  const re = /SELECT\s+([\w,\s]+?)\s+FROM\s+\\`\$\{t\(TABLES\.USERS\)\}\\`/g;
  const statements = [];
  for (const m of USERS_SRC.matchAll(re)) {
    statements.push(m[1].split(',').map((c) => c.trim()));
  }
  return statements;
}

describe('users list route — schema parity', () => {
  it('parses a column set for fmb_users so the check below has something to check', () => {
    assert.ok(usersColumns.size > 0, 'no columns parsed for the users table');
  });

  it('finds SELECT statements against fmb_users — a parse that stopped matching would check nothing', () => {
    const statements = selectStatementsAgainstUsers();
    assert.ok(statements.length >= 2, `only ${statements.length} SELECT...FROM users statements found — the parse has stopped working`);
  });

  it('every column named in every SELECT against fmb_users exists on the table', () => {
    const statements = selectStatementsAgainstUsers();
    for (const cols of statements) {
      for (const col of cols) {
        assert.ok(usersColumns.has(col), `fmb_users has no column '${col}' — referenced in "${cols.join(', ')}"`);
      }
    }
  });

  it('both the GET / and POST action=list SELECTs carry deptid and kc_username', () => {
    const statements = selectStatementsAgainstUsers();
    const listStatements = statements.filter((cols) => cols.includes('created_at') && cols.includes('banned'));
    assert.ok(listStatements.length >= 2, `expected both list SELECTs (GET / and POST action=list), found ${listStatements.length}`);
    for (const cols of listStatements) {
      assert.ok(cols.includes('deptid'), `list SELECT is missing deptid: ${cols.join(', ')}`);
      assert.ok(cols.includes('kc_username'), `list SELECT is missing kc_username: ${cols.join(', ')}`);
    }
  });
});
