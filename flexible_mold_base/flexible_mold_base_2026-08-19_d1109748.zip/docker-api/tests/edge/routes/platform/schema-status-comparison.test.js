/**
 * schema-status-comparison.test.js — fmb-1329 T5.
 *
 * The guard-column probe was replaced by a full expected-vs-live manifest
 * comparison. These tests pin that comparison + the derive verdict WITHOUT a
 * live DB (stub the db module so requiring the route is side-effect-free), and
 * lock the load-bearing invariant: a manually-added-stamp DB that is missing
 * structure must NOT read 'aligned' (what the old drift probe protected).
 */
const { describe, it, before, after } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

// Stub db so the route require pulls no pool. t prefixes with 'mig_' so the
// comparison's prefix-awareness is exercised.
const dbKey = require.resolve('../../../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: {}, t: (n) => `mig_${n}`, PLATFORM_SCHEMA_VERSION: '3.2.520' },
};

const route = require('../../../../src/edge/routes/platform/schema-status');
const { _readSchemaColumns, _computeComparison, _deriveVerdict } = route._internal;
const { buildSchemaManifest } = require('../../../../src/edge/lib/schema-manifest');

const PREFIX_T = (base) => `mig_${base}`;

// Build a live-columns Map that exactly matches the expected manifest, keyed by
// the prefixed physical name (what information_schema returns).
function fullLiveMap(tableFn) {
  const manifest = buildSchemaManifest((b) => b);
  const live = new Map();
  for (const [base, { columns }] of manifest) {
    live.set(tableFn(base), new Set(columns));
  }
  return live;
}

describe('_readSchemaColumns', () => {
  it('shapes information_schema rows into Map<table, Map<column, {type, nullable}>>', async () => {
    const conn = {
      query: async () => ([
        { TABLE_NAME: 'mig_users', COLUMN_NAME: 'id', COLUMN_TYPE: 'char(36)', IS_NULLABLE: 'NO' },
        { TABLE_NAME: 'mig_users', COLUMN_NAME: 'role', COLUMN_TYPE: "enum('admin','editor','user')", IS_NULLABLE: 'NO' },
        { TABLE_NAME: 'mig_hierarchy_nodes', COLUMN_NAME: 'id', COLUMN_TYPE: 'char(36)', IS_NULLABLE: 'NO' },
      ]),
    };
    const map = await _readSchemaColumns(conn);
    assert.deepEqual([...map.get('mig_users').keys()].sort(), ['id', 'role']);
    assert.deepEqual([...map.get('mig_hierarchy_nodes').keys()], ['id']);
    // Per-column metadata is captured (raw type + uppercased nullability).
    assert.deepEqual(map.get('mig_users').get('role'), {
      type: "enum('admin','editor','user')",
      nullable: 'NO',
    });
  });

  it('tolerates rows missing COLUMN_TYPE / IS_NULLABLE (null metadata)', async () => {
    const conn = { query: async () => ([{ TABLE_NAME: 'mig_users', COLUMN_NAME: 'id' }]) };
    const map = await _readSchemaColumns(conn);
    assert.deepEqual(map.get('mig_users').get('id'), { type: null, nullable: null });
  });
});

describe('_computeComparison', () => {
  it('reports zero missing when the live schema matches the manifest', () => {
    const { missing_tables, missing_columns } = _computeComparison(fullLiveMap(PREFIX_T), PREFIX_T);
    assert.deepEqual(missing_tables, []);
    assert.deepEqual(missing_columns, []);
  });

  it('reports a missing table (base name) and a missing column ({table, column})', () => {
    const live = fullLiveMap(PREFIX_T);
    const someTable = [...live.keys()][0]; // prefixed
    live.delete(someTable); // drop a whole table
    const otherTable = [...live.keys()][0];
    const cols = new Set(live.get(otherTable));
    const droppedCol = [...cols][cols.size - 1];
    cols.delete(droppedCol);
    live.set(otherTable, cols);

    const { missing_tables, missing_columns } = _computeComparison(live, PREFIX_T);
    // missing_tables are BASE names (prefix stripped by comparison keying).
    assert.ok(missing_tables.length >= 1, 'a missing table is reported');
    assert.ok(missing_tables.every((n) => !n.startsWith('mig_')), 'missing_tables are base names');
    assert.ok(
      missing_columns.some((c) => `mig_${c.table}` === otherTable && c.column === droppedCol),
      'the dropped column is reported as {table, column} base names',
    );
  });
});

describe('_deriveVerdict (fmb-1329 invariant)', () => {
  it('aligned: stamp at target + full manifest present', () => {
    const v = _deriveVerdict(
      { stampVersion: '3.2.520', auditSkips: [], liveByTable: fullLiveMap(PREFIX_T), comparisonOk: true },
      PREFIX_T,
    );
    assert.equal(v.schema_status, 'aligned');
    assert.equal(v.missing_columns.length, 0);
  });

  it('INVARIANT: manually-stamped-at-target DB missing a column is NOT aligned → degraded', () => {
    const live = fullLiveMap(PREFIX_T);
    const t0 = [...live.keys()][0];
    const cols = new Set(live.get(t0));
    cols.delete([...cols][cols.size - 1]);
    live.set(t0, cols);

    const v = _deriveVerdict(
      { stampVersion: '3.2.520', auditSkips: [], liveByTable: live, comparisonOk: true },
      PREFIX_T,
    );
    assert.equal(v.schema_status, 'degraded');
    assert.ok(v.missing_columns.length >= 1, 'missing column surfaced for remediation');
  });

  it('unsupported: stamp below baseline (overrides comparison)', () => {
    const v = _deriveVerdict(
      { stampVersion: '3.2.400', auditSkips: [], liveByTable: fullLiveMap(PREFIX_T), comparisonOk: true },
      PREFIX_T,
    );
    assert.equal(v.schema_status, 'unsupported');
  });

  it('unsupported: no stamp + engine tables present (foreign / pre-stamp DB)', () => {
    // Only hierarchy_nodes present, no stamp → unsupported; comparison still
    // runs so missing items remain available.
    const live = new Map([['mig_hierarchy_nodes', new Set(['id'])]]);
    const v = _deriveVerdict(
      { stampVersion: null, auditSkips: [], liveByTable: live, comparisonOk: true },
      PREFIX_T,
    );
    assert.equal(v.schema_status, 'unsupported');
    assert.ok(v.missing_tables.length > 0, 'comparison still surfaces the gap');
  });

  it('fresh install: no stamp + no engine tables + full manifest not required → not unsupported', () => {
    // Empty DB (no engine tables) with no stamp is a normal fresh install, not
    // the guard. With nothing present, comparison shows missing → degraded.
    const v = _deriveVerdict(
      { stampVersion: null, auditSkips: [], liveByTable: new Map(), comparisonOk: true },
      PREFIX_T,
    );
    assert.notEqual(v.schema_status, 'unsupported');
  });

  it('unknown: comparison unavailable cannot prove aligned', () => {
    const v = _deriveVerdict(
      { stampVersion: '3.2.520', auditSkips: [], liveByTable: null, comparisonOk: false },
      PREFIX_T,
    );
    assert.equal(v.schema_status, 'unknown');
  });
});

// ── Mounted GET / route — pending_steps envelope (Codex R2 route-level gap) ───
// The internal describes above never exercise the HTTP handler, so the
// pending_steps field the route attaches to the response envelope had no
// route-level assertion (reverting it broke zero tests). This block mounts a
// FRESH copy of the router against a db mock whose target (3.2.579) is ahead of
// the stamp (3.2.520) so the pending derive actually runs, with information_
// schema probes reporting the real v3.2.579 batch as pending.
describe('GET /edge/platform/schema-status — pending_steps envelope', () => {
  let server;
  let base;
  let mode = 'pending'; // 'pending' | 'unknown'

  // Full manifest dump keyed by the mock prefix → computeMissing sees zero
  // missing, so pending_steps is the sole remediation signal under test.
  function fullDumpRows() {
    const manifest = buildSchemaManifest((b) => b);
    const rows = [];
    for (const [base_, { columns, columnMeta }] of manifest) {
      for (const c of columns) {
        const meta = columnMeta.get(c) || {};
        rows.push({
          TABLE_NAME: `mig_${base_}`,
          COLUMN_NAME: c,
          COLUMN_TYPE: meta.type,
          IS_NULLABLE: meta.nullable,
        });
      }
    }
    return rows;
  }

  const roConn = {
    query: async (sql) => {
      // Only the platform_schema_version stamp read (a literal-keyed SELECT)
      // answers here — other system_settings reads (e.g. the AR2-Q11 seed
      // step's marker probe, `key = ?`) fall through to the generic `[]`
      // below, which that step's own eligibility reads as "marker absent".
      if (/system_settings.*'platform_schema_version'/i.test(sql)) {
        if (mode === 'unknown') throw new Error('stamp read blew up');
        return [{ value: '"3.2.520"' }];
      }
      if (/feature_audit/i.test(sql)) return [];
      if (/TABLE_NAME, COLUMN_NAME, COLUMN_TYPE, IS_NULLABLE FROM information_schema\.COLUMNS/i.test(sql)) return fullDumpRows();
      if (/IS_NULLABLE FROM information_schema\.COLUMNS/i.test(sql)) return [{ IS_NULLABLE: 'YES' }];
      if (/SELECT 1 FROM information_schema\.COLUMNS/i.test(sql)) return [{ 1: 1 }];
      if (/information_schema\.TABLES/i.test(sql)) return [{ 1: 1 }];
      if (/information_schema\.STATISTICS/i.test(sql)) return [{ 1: 1 }];
      return [];
    },
    release() {},
    destroy() {},
  };

  before(async () => {
    const routeKey = require.resolve('../../../../src/edge/routes/platform/schema-status');
    require.cache[dbKey] = {
      id: dbKey, filename: dbKey, loaded: true,
      exports: {
        pool: { ro: { getConnection: async () => roConn }, rw: { getConnection: async () => roConn } },
        t: (n) => `mig_${n}`,
        PLATFORM_SCHEMA_VERSION: '3.2.579',
      },
    };
    delete require.cache[routeKey];
    const freshRouter = require('../../../../src/edge/routes/platform/schema-status');
    const app = express();
    app.use(express.json());
    app.use((req, _res, next) => { req.user = { id: 'admin-1', role: 'admin' }; next(); });
    app.use('/', freshRouter);
    server = http.createServer(app);
    await new Promise((r) => server.listen(0, '127.0.0.1', r));
    base = `http://127.0.0.1:${server.address().port}`;
  });

  after(async () => { await new Promise((r) => server.close(r)); });

  it('includes pending_steps with the pending destructive step names when stamp < target', async () => {
    mode = 'pending';
    const res = await fetch(`${base}/`);
    assert.equal(res.status, 200);
    const { data } = await res.json();
    assert.equal(data.schema_status, 'degraded', 'stamp behind target → degraded');
    // Full manifest-matching dump → advisory drift list is present and empty,
    // and does not disturb the verdict.
    assert.deepEqual(data.column_drift, [], 'column_drift present + empty on a matching dump');
    assert.deepEqual(
      [...data.pending_steps].sort(),
      [
        'api_connectors_allowed_hosts_drop',
        // A DB that ran the 3.2.586 batch HAS this column, so its drop is
        // genuinely pending. A DB that never ran it does not, and the probe
        // then reports the step satisfied — which is why withdrawing the
        // matching add-column entry does not change what an older stamp is
        // told to do.
        'blueprint_fields_is_locked_drop',
        // A pure-data reconcile step. Its probe reports satisfied only once its
        // own system_settings marker exists; this mocked roConn answers the
        // marker SELECT with the generic fallback ([]) — marker absent — so the
        // step is still pending.
        'cap_rules_reconcile_default_template',
        // AR2-Q11 (spec §7 E1): a pure-data seed step. This mocked roConn
        // answers its global cap_rules SELECT with the generic fallback ([]),
        // which this step's own eligibility rule reads as "empty global rule
        // set" — eligible for the seed, so not yet satisfied.
        'cap_rules_seed_standby_keep_in_one_site',
        'flow_recipe_runs_created_at_not_null_backfill',
        'flow_recipe_steps_allowed_hosts_drop',
        'user_templates_created_at_not_null_backfill',
        'user_templates_user_id_drop',
      ],
      'every pending destructive/custom step surfaces by name in the envelope',
    );
  });

  it('includes pending_steps: [] in the unknown fallback shape (stamp read failure)', async () => {
    mode = 'unknown';
    const res = await fetch(`${base}/`);
    assert.equal(res.status, 200);
    const { data } = await res.json();
    assert.equal(data.schema_status, 'unknown');
    assert.deepEqual(data.column_drift, [], 'unknown fallback carries column_drift: []');
    assert.deepEqual(data.pending_steps, [], 'unknown fallback still carries pending_steps: []');
  });
});
