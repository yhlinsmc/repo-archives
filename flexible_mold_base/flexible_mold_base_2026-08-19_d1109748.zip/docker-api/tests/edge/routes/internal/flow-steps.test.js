// docker-api/tests/edge/routes/internal/flow-steps.test.js
const { test, beforeEach } = require('node:test');
const assert = require('node:assert');
const express = require('express');

// Stub the edge db pool before requiring the router so all DB calls are isolated.
// `run` / `template` / `nodes` / `owner` back the run-binding + template_* bag
// path (buildTemplateContext); default null → those tables read empty.
const fakeRows = { step: null, recipe: null, blueprint: null, run: null, template: null, nodes: null, owner: null, blueprintNode: null };
const queries = [];
const conn = {
  query: async (sql, params) => {
    queries.push({ sql, params });
    if (/FROM `flow_recipe_steps`/.test(sql)) return fakeRows.step ? [fakeRows.step] : [];
    if (/FROM `flow_recipe_runs`/.test(sql)) return fakeRows.run ? [fakeRows.run] : [];
    if (/FROM `flow_recipes`/.test(sql)) return fakeRows.recipe ? [fakeRows.recipe] : [];
    if (/FROM `user_templates`/.test(sql)) return fakeRows.template ? [fakeRows.template] : [];
    if (/FROM `hierarchy_nodes`/.test(sql)) {
      // Three hierarchy_nodes reads share this table: buildTemplateContext reads
      // `SELECT id, name … IN (…)`; the context.blueprintName resolver reads
      // `SELECT name … WHERE id = ?`; the recipe-manage ownership branch reads
      // `SELECT owner_id … WHERE id = ?`. Disambiguate by the projection.
      if (/SELECT id, name/.test(sql)) return fakeRows.nodes || [];
      if (/SELECT name FROM/.test(sql)) return fakeRows.blueprintNode ? [fakeRows.blueprintNode] : [];
      return fakeRows.blueprint ? [fakeRows.blueprint] : [];
    }
    if (/FROM `users`/.test(sql)) return fakeRows.owner ? [fakeRows.owner] : [];
    if (/INSERT INTO `feature_audit`/.test(sql)) return { affectedRows: 1 };
    // egress policy + default-deny queries (system_settings) → empty = allow-all
    return [];
  },
  release: () => {},
};
require.cache[require.resolve('../../../../src/edge/db')] = {
  exports: {
    pool: { rw: { getConnection: async () => conn }, ro: { query: async () => [] } },
    t: (x) => x,
  },
};

const router = require('../../../../src/edge/routes/internal/flow-steps');

function appWith(user) {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { req.user = user; next(); });
  app.use('/edge/internal/flow-steps', router);
  return app;
}
async function post(app, path, body, user) {
  const server = app.listen(0);
  try {
    const port = server.address().port;
    const res = await fetch(`http://127.0.0.1:${port}${path}`, {
      method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body),
    });
    const json = await res.json();
    return { status: res.status, json };
  } finally {
    // Closed on the throwing path too. With the close reachable only where
    // nothing threw, a failed assertion leaks this handle, the runner never
    // exits, and the job reports a timeout instead of the assertion that failed.
    server.close();
  }
}

beforeEach(() => {
  fakeRows.step = null; fakeRows.recipe = null; fakeRows.blueprint = null;
  fakeRows.run = null; fakeRows.template = null; fakeRows.nodes = null; fakeRows.owner = null;
  fakeRows.blueprintNode = null;
  queries.length = 0;
});

test('400 when step_id missing', async () => {
  const { status } = await post(appWith({ id: 'u1', role: 'editor' }), '/edge/internal/flow-steps/prepare', {});
  assert.strictEqual(status, 400);
});

test('404 when step not found', async () => {
  const { status } = await post(appWith({ id: 'u1', role: 'editor' }), '/edge/internal/flow-steps/prepare', { step_id: 'nope' });
  assert.strictEqual(status, 404);
});

test('422 when parent recipe is not approved', async () => {
  fakeRows.step = { id: 's1', recipe_id: 'r1', method: 'POST', url: 'https://ok.test/x', auth_type: 'none', dispatch_origin: 'edge' };
  fakeRows.recipe = { is_active: 1, status: 'pending' };
  const { status, json } = await post(appWith({ id: 'u1', role: 'editor' }), '/edge/internal/flow-steps/prepare', { step_id: 's1', inputs: {} });
  assert.strictEqual(status, 422);
  assert.strictEqual(json.error.code, 'RECIPE_NOT_APPROVED');
});

test('/result 200 recorded=true on success dispatch', async () => {
  const { status, json } = await post(appWith({ id: 'u1', role: 'infra' }), '/edge/internal/flow-steps/result', { step_id: 's1', success: true });
  assert.strictEqual(status, 200);
  assert.strictEqual(json.data.recorded, true);
});

test('/result duplicate dispatch_id returns recorded=false', async () => {
  const dispatchId = 'idem-test-result-001';
  const app = appWith({ id: 'u1', role: 'infra' });
  await post(app, '/edge/internal/flow-steps/result', { step_id: 's1', dispatch_id: dispatchId, success: true });
  const { status, json } = await post(app, '/edge/internal/flow-steps/result', { step_id: 's1', dispatch_id: dispatchId, success: true });
  assert.strictEqual(status, 200);
  assert.strictEqual(json.data.recorded, false);
  assert.strictEqual(json.data.reason, 'duplicate');
});

// Regression: the step row arrives from the driver with JSON columns (auth_config,
// request_config) as raw strings. The /prepare handler must parse
// them via the dto-mapper before decryptRow and resolveRequest run — otherwise
// resolveRequest reads rc.body off a string (undefined → body is ''), the
// {{payload}} template fill never executes, and auth headers are silently dropped.
//
// This test drives the exact bug: request_config supplied as a JSON STRING, not
// an object. Before the mapRowsFromDb fix the captured body would be '' (empty);
// after the fix it is 'HELLO'.
test('edge /prepare: timeout_ms beyond S2S budget is clamped to 120000 at dispatch', async () => {
  const connDispatch = require('../../../../src/edge/lib/connector-dispatch');
  let capturedOpts;
  const origExecute = connDispatch.executeRequest;
  connDispatch.executeRequest = async (_req, opts) => {
    capturedOpts = opts;
    return { upstream_status: 200, headers: {}, body: '{}', duration_ms: 1 };
  };
  try {
    fakeRows.step = {
      id: 's2', recipe_id: 'r2', name: 'clamp-test',
      method: 'GET', url: 'https://ok.test/clamp',
      auth_type: 'none',
      auth_config: '{}',
      request_config: '{}',
      response_config: '{}',
      input_from_step: null,
      timeout_ms: 999999999,
      dispatch_origin: 'edge',
    };
    fakeRows.recipe = { is_active: 1, status: 'approved' };

    const { status } = await post(
      appWith({ id: 'u1', role: 'editor' }),
      '/edge/internal/flow-steps/prepare',
      { step_id: 's2', inputs: {} },
    );

    assert.strictEqual(status, 200);
    assert.ok(capturedOpts, 'executeRequest was never called');
    assert.strictEqual(capturedOpts.timeoutMs, 120000, `expected timeoutMs 120000 but got ${capturedOpts.timeoutMs}`);
  } finally {
    connDispatch.executeRequest = origExecute;
  }
});

test('edge /prepare: dto-mapper parse of string request_config fills {{payload}}', async () => {
  // Patch connector-dispatch.executeRequest to capture the resolved request
  // without opening a real socket. runEdgeExecute calls module.exports.executeRequest
  // so replacing the property on the cached require is the correct hook.
  const connDispatch = require('../../../../src/edge/lib/connector-dispatch');
  let capturedReq;
  const origExecute = connDispatch.executeRequest;
  connDispatch.executeRequest = async (req) => {
    capturedReq = req;
    return { upstream_status: 201, headers: {}, body: '{}', duration_ms: 1 };
  };
  try {
    // Step row exactly as the MariaDB driver returns it: JSON columns are strings.
    fakeRows.step = {
      id: 's1', recipe_id: 'r1', name: 'test-step',
      method: 'POST', url: 'https://ok.test/x',
      auth_type: 'none',
      auth_config: '{}',                       // raw string, not object
      request_config: '{"body":"{{payload}}"}', // raw string, not object
      response_config: '{}',                   // raw string, not object
      input_from_step: null,
      timeout_ms: null,
      dispatch_origin: 'edge',
    };
    fakeRows.recipe = { is_active: 1, status: 'approved' };

    const { status, json } = await post(
      appWith({ id: 'u1', role: 'editor' }),
      '/edge/internal/flow-steps/prepare',
      { step_id: 's1', inputs: { payload: 'HELLO' } },
    );

    assert.strictEqual(status, 200, `expected 200, got ${status}: ${JSON.stringify(json)}`);
    assert.ok(capturedReq, 'executeRequest was never called — edge dispatch did not reach the outbound call');
    // The critical assertion: {{payload}} must have been filled with 'HELLO'.
    // If request_config was not parsed (string branch), rc.body is undefined →
    // body resolves to '' (empty) and this assertion fails.
    assert.strictEqual(capturedReq.body, 'HELLO', `body should be 'HELLO' but got '${capturedReq.body}'`);
  } finally {
    connDispatch.executeRequest = origExecute;
  }
});

// ─── Author-test deadlock fix: invariant tests ────────────────────────────────
//
// An editor who authored a pending recipe was deadlocked: they couldn't run it
// until an admin approved it, but an admin wouldn't approve an untested recipe.
// Fix: callerCanManageRecipe = isAdmin || recipe.owner_id==caller || blueprintOwner∈{null,caller}
// Egress + SSRF still fire regardless of test mode (invariant 2).

// (a) Editor tests their OWN pending recipe (own blueprint) → passes approval gate.
// RED before fix: old code requires admin for effectiveTest, so non-admin always gets 422.
test('editor with test:true on own pending recipe passes approval gate', async () => {
  const connDispatch = require('../../../../src/edge/lib/connector-dispatch');
  const origExecute = connDispatch.executeRequest;
  connDispatch.executeRequest = async () => ({ upstream_status: 200, headers: {}, body: '{}', duration_ms: 1 });
  try {
    fakeRows.step = {
      id: 's20', recipe_id: 'r20', name: 'author-own',
      method: 'GET', url: 'https://ok.test/run',
      auth_type: 'none', auth_config: '{}', request_config: '{}', response_config: '{}',
      input_from_step: null, timeout_ms: null,
      dispatch_origin: 'edge',
    };
    // Editor owns the recipe AND its bound blueprint.
    fakeRows.recipe = { is_active: 1, status: 'pending', owner_id: 'editor1', blueprint_id: 'bp1' };
    fakeRows.blueprint = { owner_id: 'editor1' };

    const { status, json } = await post(
      appWith({ id: 'editor1', role: 'editor' }),
      '/edge/internal/flow-steps/prepare',
      { step_id: 's20', inputs: {}, test: true },
    );

    // Must NOT be blocked by the approval gate.
    assert.notStrictEqual(
      json.error?.code, 'RECIPE_NOT_APPROVED',
      `approval gate must pass for recipe owner; got: ${JSON.stringify(json)}`,
    );
    assert.strictEqual(status, 200, `expected 200 but got ${status}: ${JSON.stringify(json)}`);
    assert.strictEqual(json.data.test, true, 'test flag must be echoed in response');
  } finally {
    connDispatch.executeRequest = origExecute;
  }
});

// (b) Editor tests a FOREIGN pending recipe (different owner, different blueprint owner) → 422.
test('editor with test:true on foreign pending recipe → 422 RECIPE_NOT_APPROVED', async () => {
  fakeRows.step = {
    id: 's21', recipe_id: 'r21', name: 'foreign',
    method: 'GET', url: 'https://ok.test/run',
    auth_type: 'none', auth_config: '{}', request_config: '{}', response_config: '{}',
    input_from_step: null, timeout_ms: null,
    dispatch_origin: 'edge',
  };
  // Recipe owned by a different user; blueprint also owned by a different user.
  fakeRows.recipe = { is_active: 1, status: 'pending', owner_id: 'other-editor', blueprint_id: 'bp2' };
  fakeRows.blueprint = { owner_id: 'other-editor' };

  const { status, json } = await post(
    appWith({ id: 'editor1', role: 'editor' }),
    '/edge/internal/flow-steps/prepare',
    { step_id: 's21', inputs: {}, test: true },
  );

  assert.strictEqual(status, 422);
  assert.strictEqual(json.error.code, 'RECIPE_NOT_APPROVED');
});

// (c) Plain user-role with test:true on a pending recipe → 422 (flag is inert).
test('user role with test:true on pending recipe → 422 RECIPE_NOT_APPROVED', async () => {
  fakeRows.step = {
    id: 's22', recipe_id: 'r22', name: 'user-test',
    method: 'GET', url: 'https://ok.test/run',
    auth_type: 'none', auth_config: '{}', request_config: '{}', response_config: '{}',
    input_from_step: null, timeout_ms: null,
    dispatch_origin: 'edge',
  };
  // Recipe authored by an editor, not the plain user.
  fakeRows.recipe = { is_active: 1, status: 'pending', owner_id: 'some-editor', blueprint_id: null };

  const { status, json } = await post(
    appWith({ id: 'plain-user', role: 'user' }),
    '/edge/internal/flow-steps/prepare',
    { step_id: 's22', inputs: {}, test: true },
  );

  assert.strictEqual(status, 422);
  assert.strictEqual(json.error.code, 'RECIPE_NOT_APPROVED');
});

// (d) Approved recipe without test flag → 200 (unchanged path).
test('approved recipe without test flag → 200', async () => {
  const connDispatch = require('../../../../src/edge/lib/connector-dispatch');
  const origExecute = connDispatch.executeRequest;
  connDispatch.executeRequest = async () => ({ upstream_status: 200, headers: {}, body: '{}', duration_ms: 1 });
  try {
    fakeRows.step = {
      id: 's23', recipe_id: 'r23', name: 'approved-run',
      method: 'GET', url: 'https://ok.test/run',
      auth_type: 'none', auth_config: '{}', request_config: '{}', response_config: '{}',
      input_from_step: null, timeout_ms: null,
      dispatch_origin: 'edge',
    };
    fakeRows.recipe = { is_active: 1, status: 'approved', owner_id: 'editor1', blueprint_id: null };

    const { status } = await post(
      appWith({ id: 'anyone', role: 'editor' }),
      '/edge/internal/flow-steps/prepare',
      { step_id: 's23', inputs: {} },
    );

    assert.strictEqual(status, 200);
  } finally {
    connDispatch.executeRequest = origExecute;
  }
});

// (e) Admin with test:true on any pending recipe → passes (admin always allowed).
test('admin with test:true on pending recipe → passes gate', async () => {
  const connDispatch = require('../../../../src/edge/lib/connector-dispatch');
  const origExecute = connDispatch.executeRequest;
  connDispatch.executeRequest = async () => ({ upstream_status: 200, headers: {}, body: '{}', duration_ms: 1 });
  try {
    fakeRows.step = {
      id: 's24', recipe_id: 'r24', name: 'admin-test',
      method: 'GET', url: 'https://ok.test/run',
      auth_type: 'none', auth_config: '{}', request_config: '{}', response_config: '{}',
      input_from_step: null, timeout_ms: null,
      dispatch_origin: 'edge',
    };
    // Admin may test a recipe owned by any editor.
    fakeRows.recipe = { is_active: 0, status: 'pending', owner_id: 'some-editor', blueprint_id: null };

    const { status } = await post(
      appWith({ id: 'admin1', role: 'admin' }),
      '/edge/internal/flow-steps/prepare',
      { step_id: 's24', inputs: {}, test: true },
    );

    assert.strictEqual(status, 200);
  } finally {
    connDispatch.executeRequest = origExecute;
  }
});

// (f) SECURITY: Editor owns the bound blueprint but does NOT own the recipe →
// 422 RECIPE_NOT_APPROVED. Blueprint-ownership alone is insufficient — the CRUD
// edit-gate requires BOTH: own the row AND own/share the blueprint (conjunction).
// RED against old OR predicate: editor1 owns bp25 → old code granted authority → 200.
// Correct conjunction: ownerOk=false (recipe owned by other-editor) → denied regardless
// of blueprint ownership. This is the Codex P1 over-grant case.
test('editor owning bound blueprint but NOT the recipe → 422 (blueprint ownership alone insufficient)', async () => {
  fakeRows.step = {
    id: 's25', recipe_id: 'r25', name: 'bp-owner',
    method: 'GET', url: 'https://ok.test/run',
    auth_type: 'none', auth_config: '{}', request_config: '{}', response_config: '{}',
    input_from_step: null, timeout_ms: null,
    dispatch_origin: 'edge',
  };
  // Caller owns the blueprint but NOT the recipe row.
  fakeRows.recipe = { is_active: 1, status: 'pending', owner_id: 'other-editor', blueprint_id: 'bp25' };
  fakeRows.blueprint = { owner_id: 'editor1' };

  const { status, json } = await post(
    appWith({ id: 'editor1', role: 'editor' }),
    '/edge/internal/flow-steps/prepare',
    { step_id: 's25', inputs: {}, test: true },
  );

  assert.strictEqual(status, 422, `expected 422 but got ${status}: ${JSON.stringify(json)}`);
  assert.strictEqual(json.error.code, 'RECIPE_NOT_APPROVED');
});

// (h) Role floor (defense-in-depth): a user-role caller who somehow OWNS the
// pending recipe must still be denied — the ownership branches are gated to role
// 'editor' (admin short-circuits). RED without the role floor: owner_id match would
// flip effectiveTest true → 200; with the floor it stays false → 422.
test('user-role OWNER on pending recipe → still 422 (role floor denies the should-never-exist owner)', async () => {
  fakeRows.step = {
    id: 's27', recipe_id: 'r27', name: 'user-owner',
    method: 'GET', url: 'https://ok.test/run',
    auth_type: 'none', auth_config: '{}', request_config: '{}', response_config: '{}',
    input_from_step: null, timeout_ms: null,
    dispatch_origin: 'edge',
  };
  // Recipe owner_id === caller, but caller is role 'user' (should never own one).
  fakeRows.recipe = { is_active: 1, status: 'pending', owner_id: 'plain-user', blueprint_id: null };

  const { status, json } = await post(
    appWith({ id: 'plain-user', role: 'user' }),
    '/edge/internal/flow-steps/prepare',
    { step_id: 's27', inputs: {}, test: true },
  );

  assert.strictEqual(status, 422);
  assert.strictEqual(json.error.code, 'RECIPE_NOT_APPROVED');
});

// (g) SECURITY: Editor does NOT own the recipe; blueprint owner is null (shared) →
// 422 RECIPE_NOT_APPROVED. A shared blueprint does NOT grant test authority on a
// recipe the caller does not own. Row ownership is required in the conjunction.
// RED against old OR predicate: bpOwner=null → old code granted authority → 200.
// Correct conjunction: ownerOk=false (recipe owned by other-editor) → denied.
// This is the second Codex P1 over-grant case (shared-blueprint foreign recipe).
test('editor on foreign recipe with shared (null-owner) blueprint → 422 (row ownership required)', async () => {
  fakeRows.step = {
    id: 's26', recipe_id: 'r26', name: 'shared-bp',
    method: 'GET', url: 'https://ok.test/run',
    auth_type: 'none', auth_config: '{}', request_config: '{}', response_config: '{}',
    input_from_step: null, timeout_ms: null,
    dispatch_origin: 'edge',
  };
  // Editor does NOT own the recipe; blueprint is shared (null owner).
  fakeRows.recipe = { is_active: 1, status: 'pending', owner_id: 'other-editor', blueprint_id: 'bp26' };
  fakeRows.blueprint = { owner_id: null };

  const { status, json } = await post(
    appWith({ id: 'editor1', role: 'editor' }),
    '/edge/internal/flow-steps/prepare',
    { step_id: 's26', inputs: {}, test: true },
  );

  assert.strictEqual(status, 422, `expected 422 but got ${status}: ${JSON.stringify(json)}`);
  assert.strictEqual(json.error.code, 'RECIPE_NOT_APPROVED');
});

// (f2) Correct positive: editor owns recipe AND blueprint is shared (null owner) → passes.
// Matrix case: self | null(shared bp). ownerOk=true, bpOwnerOk=true (null=shared).
test('editor owning recipe with shared (null-owner) blueprint → passes gate', async () => {
  const connDispatch = require('../../../../src/edge/lib/connector-dispatch');
  const origExecute = connDispatch.executeRequest;
  connDispatch.executeRequest = async () => ({ upstream_status: 200, headers: {}, body: '{}', duration_ms: 1 });
  try {
    fakeRows.step = {
      id: 's28', recipe_id: 'r28', name: 'own-recipe-shared-bp',
      method: 'GET', url: 'https://ok.test/run',
      auth_type: 'none', auth_config: '{}', request_config: '{}', response_config: '{}',
      input_from_step: null, timeout_ms: null,
      dispatch_origin: 'edge',
    };
    // Editor owns the recipe; blueprint is shared (null owner) — both conditions met.
    fakeRows.recipe = { is_active: 1, status: 'pending', owner_id: 'editor1', blueprint_id: 'bp28' };
    fakeRows.blueprint = { owner_id: null };

    const { status, json } = await post(
      appWith({ id: 'editor1', role: 'editor' }),
      '/edge/internal/flow-steps/prepare',
      { step_id: 's28', inputs: {}, test: true },
    );

    assert.strictEqual(status, 200, `expected 200 but got ${status}: ${JSON.stringify(json)}`);
    assert.strictEqual(json.data.test, true);
  } finally {
    connDispatch.executeRequest = origExecute;
  }
});

// (f3) Correct positive: admin-created recipe (null owner_id) + editor owns blueprint → passes.
// Matrix case: null(admin-created) | self. ownerOk=true (null), bpOwnerOk=true.
test('admin-created recipe (null owner_id) and editor owns blueprint → passes gate', async () => {
  const connDispatch = require('../../../../src/edge/lib/connector-dispatch');
  const origExecute = connDispatch.executeRequest;
  connDispatch.executeRequest = async () => ({ upstream_status: 200, headers: {}, body: '{}', duration_ms: 1 });
  try {
    fakeRows.step = {
      id: 's29', recipe_id: 'r29', name: 'null-owner-recipe',
      method: 'GET', url: 'https://ok.test/run',
      auth_type: 'none', auth_config: '{}', request_config: '{}', response_config: '{}',
      input_from_step: null, timeout_ms: null,
      dispatch_origin: 'edge',
    };
    // Recipe has no owner (admin-created); editor owns the blueprint.
    fakeRows.recipe = { is_active: 1, status: 'pending', owner_id: null, blueprint_id: 'bp29' };
    fakeRows.blueprint = { owner_id: 'editor1' };

    const { status, json } = await post(
      appWith({ id: 'editor1', role: 'editor' }),
      '/edge/internal/flow-steps/prepare',
      { step_id: 's29', inputs: {}, test: true },
    );

    assert.strictEqual(status, 200, `expected 200 but got ${status}: ${JSON.stringify(json)}`);
    assert.strictEqual(json.data.test, true);
  } finally {
    connDispatch.executeRequest = origExecute;
  }
});

// infra-mode: multipart body survives the edge → infra S2S prepared block.
//
// resolveAndPin is not stubbed — we use an RFC1918 IP literal (192.168.1.100)
// so ssrf-guard resolves it synchronously without DNS and does not block it.
// The rest of the harness is identical to the existing edge-mode tests above:
// same fakeRows / conn / appWith fixtures.
test('infra /prepare: carries a multipart body through the prepared block', async () => {
  fakeRows.step = {
    id: 's_mp', recipe_id: 'r_mp', name: 'multipart-infra',
    method: 'POST', url: 'https://192.168.1.100/api',
    auth_type: 'none',
    auth_config: '{}',
    request_config: JSON.stringify({
      body: '{{payload}}',
      body_type: 'multipart',
      file_field: 'f',
      file_name: 'p.json',
    }),
    response_config: '{}',
    input_from_step: null,
    timeout_ms: null,
    dispatch_origin: 'infra',
  };
  fakeRows.recipe = { is_active: 1, status: 'approved', owner_id: 'editor1', blueprint_id: null };

  const { status, json } = await post(
    appWith({ id: 'editor1', role: 'editor' }),
    '/edge/internal/flow-steps/prepare',
    { step_id: 's_mp', inputs: { payload: 'hello' } },
  );

  assert.strictEqual(status, 200, `expected 200 but got ${status}: ${JSON.stringify(json)}`);
  assert.strictEqual(json.data.mode, 'infra');
  assert.match(json.data.prepared.headers['Content-Type'], /^multipart\/form-data;/);
  assert.match(json.data.prepared.body, /name="f"; filename="p.json"/);
  assert.match(json.data.prepared.body, /hello/);
});

// (f4) Editor owns recipe but blueprint is owned by another editor → 422.
// Matrix case: self | otherEditor. ownerOk=true but bpOwnerOk=false → denied.
test('editor owns recipe but blueprint owned by another editor → 422 RECIPE_NOT_APPROVED', async () => {
  fakeRows.step = {
    id: 's30', recipe_id: 'r30', name: 'own-recipe-other-bp',
    method: 'GET', url: 'https://ok.test/run',
    auth_type: 'none', auth_config: '{}', request_config: '{}', response_config: '{}',
    input_from_step: null, timeout_ms: null,
    dispatch_origin: 'edge',
  };
  // Editor owns the recipe but the blueprint belongs to a different editor.
  fakeRows.recipe = { is_active: 1, status: 'pending', owner_id: 'editor1', blueprint_id: 'bp30' };
  fakeRows.blueprint = { owner_id: 'other-editor' };

  const { status, json } = await post(
    appWith({ id: 'editor1', role: 'editor' }),
    '/edge/internal/flow-steps/prepare',
    { step_id: 's30', inputs: {}, test: true },
  );

  assert.strictEqual(status, 422, `expected 422 but got ${status}: ${JSON.stringify(json)}`);
  assert.strictEqual(json.error.code, 'RECIPE_NOT_APPROVED');
});

// ─── Server-resolved context.template.* bag + context scalars (vocab v2) ──────
//
// /prepare accepts an OPTIONAL run_id. When present it binds the dispatch to a
// run (recipe + actor, mirroring run-finalize) and injects the run's template's
// `context.template.*` metadata into the {{var}} fill bag. Client input keys are
// renamed to `payload.<k>` (literal `payload` passes through), so a client key
// can NEVER produce a `context.*` key — the context namespace is
// server-authoritative by construction. Fixtures below back buildTemplateContext:
// run → template → hierarchy_nodes (id,name) → users(display_name,kc_username).
// No run_id → no run/template query fires.

// A helper to arm a fully-bound, dispatchable run whose template resolves to a
// single-tier path 'Wind' with owner display name 'Alice Owner'.
function armBoundRun({ stepOver = {}, recipeOver = {}, runOver = {}, templateOver = {} } = {}) {
  fakeRows.step = {
    id: 's_tpl', recipe_id: 'r_tpl', name: 'tpl-step',
    method: 'POST', url: 'https://ok.test/x',
    auth_type: 'none', auth_config: '{}',
    request_config: JSON.stringify({ body: '{{context.template.name}}' }),
    response_config: '{}', input_from_step: null,
    timeout_ms: null, dispatch_origin: 'edge', ...stepOver,
  };
  fakeRows.recipe = { is_active: 1, status: 'approved', owner_id: 'editor1', blueprint_id: null, ...recipeOver };
  fakeRows.run = { id: 'run1', recipe_id: 'r_tpl', template_id: 'tpl-1', actor_id: 'editor1', ...runOver };
  fakeRows.template = {
    id: 'tpl-1', name: 'Turbine Spec',
    category_id: 'cat-1', release_id: null, blueprint_id: null, variant_id: null,
    owner_id: 'owner-1', created_at: '2026-01-01 08:00:00', updated_at: '2026-01-02 09:00:00',
    ...templateOver,
  };
  fakeRows.nodes = [{ id: 'cat-1', name: 'Wind' }];
  fakeRows.owner = { display_name: 'Alice Owner', kc_username: 'alice' };
}

// (t1) A client-supplied `context.template.name` is renamed to
// `payload.context.template.name` and can NEVER shadow the server bag; the
// {{context.template.name}} token fills from the run's real template value.
test('spoofed client context.template.name is renamed away and cannot shadow the server bag', async () => {
  const connDispatch = require('../../../../src/edge/lib/connector-dispatch');
  const origExecute = connDispatch.executeRequest;
  let capturedReq;
  connDispatch.executeRequest = async (req) => { capturedReq = req; return { upstream_status: 200, headers: {}, body: '{}', duration_ms: 1 }; };
  try {
    armBoundRun();
    const { status, json } = await post(
      appWith({ id: 'editor1', role: 'editor' }),
      '/edge/internal/flow-steps/prepare',
      { step_id: 's_tpl', run_id: 'run1', inputs: { 'context.template.name': 'HACKED' } },
    );
    assert.strictEqual(status, 200, `expected 200, got ${status}: ${JSON.stringify(json)}`);
    assert.ok(capturedReq, 'dispatch never reached the outbound call');
    assert.strictEqual(capturedReq.body, 'Turbine Spec', `server value must win; got '${capturedReq.body}'`);
  } finally {
    connDispatch.executeRequest = origExecute;
  }
});

// (t2) Happy path: {{context.template.id}} in the URL and
// {{context.template.name}}/{{context.template.path}} in the body all fill from
// the run's bound template (DB-resolved values).
test('happy path fills {{context.template.id}} in URL and {{context.template.name}} in body', async () => {
  const connDispatch = require('../../../../src/edge/lib/connector-dispatch');
  const origExecute = connDispatch.executeRequest;
  let capturedReq;
  connDispatch.executeRequest = async (req) => { capturedReq = req; return { upstream_status: 200, headers: {}, body: '{}', duration_ms: 1 }; };
  try {
    armBoundRun({
      stepOver: {
        url: 'https://ok.test/tpl/{{context.template.id}}',
        request_config: JSON.stringify({ body: '{{context.template.name}} @ {{context.template.path}}' }),
      },
    });
    const { status, json } = await post(
      appWith({ id: 'editor1', role: 'editor' }),
      '/edge/internal/flow-steps/prepare',
      { step_id: 's_tpl', run_id: 'run1', inputs: {} },
    );
    assert.strictEqual(status, 200, `expected 200, got ${status}: ${JSON.stringify(json)}`);
    assert.ok(capturedReq, 'dispatch never reached the outbound call');
    assert.strictEqual(capturedReq.url, 'https://ok.test/tpl/tpl-1');
    assert.strictEqual(capturedReq.body, 'Turbine Spec @ Wind');
  } finally {
    connDispatch.executeRequest = origExecute;
  }
});

// (t3) Binding: run belongs to a DIFFERENT recipe than the step → 403, no bag,
// no dispatch. A leaked run_id cannot be paired with an arbitrary step.
test('run_id bound to a different recipe → 403 RUN_FORBIDDEN', async () => {
  armBoundRun({ runOver: { recipe_id: 'some-other-recipe' } });
  const { status, json } = await post(
    appWith({ id: 'editor1', role: 'editor' }),
    '/edge/internal/flow-steps/prepare',
    { step_id: 's_tpl', run_id: 'run1', inputs: {} },
  );
  assert.strictEqual(status, 403, `expected 403, got ${status}: ${JSON.stringify(json)}`);
  assert.strictEqual(json.error.code, 'RUN_FORBIDDEN');
});

// (t4) Binding: the run's actor is a different (non-admin) user → 403. The
// caller must own the run (or be an admin).
test('run owned by another actor (non-admin caller) → 403 RUN_FORBIDDEN', async () => {
  armBoundRun({ runOver: { actor_id: 'someone-else' } });
  const { status, json } = await post(
    appWith({ id: 'editor1', role: 'editor' }),
    '/edge/internal/flow-steps/prepare',
    { step_id: 's_tpl', run_id: 'run1', inputs: {} },
  );
  assert.strictEqual(status, 403, `expected 403, got ${status}: ${JSON.stringify(json)}`);
  assert.strictEqual(json.error.code, 'RUN_FORBIDDEN');
});

// (t5) A run_id that resolves to no row is treated as a binding failure → 403
// (no existence signal leaked, no bag).
test('run_id resolving to no row → 403 RUN_FORBIDDEN', async () => {
  fakeRows.step = {
    id: 's_tpl', recipe_id: 'r_tpl', name: 'tpl-step', method: 'GET', url: 'https://ok.test/x',
    auth_type: 'none', auth_config: '{}', request_config: '{}', response_config: '{}',
    input_from_step: null, timeout_ms: null, dispatch_origin: 'edge',
  };
  fakeRows.recipe = { is_active: 1, status: 'approved', owner_id: 'editor1', blueprint_id: null };
  fakeRows.run = null; // no run row for the supplied id
  const { status, json } = await post(
    appWith({ id: 'editor1', role: 'editor' }),
    '/edge/internal/flow-steps/prepare',
    { step_id: 's_tpl', run_id: 'ghost-run', inputs: {} },
  );
  assert.strictEqual(status, 403, `expected 403, got ${status}: ${JSON.stringify(json)}`);
  assert.strictEqual(json.error.code, 'RUN_FORBIDDEN');
});

// (t6) Unbound template: a bound run whose template_id is NULL builds no bag, so
// a referenced {{context.template.id}} falls through the MISSING_INPUT gate →
// 400 naming the token (explicit failure, never a silent empty string).
test('bound run with NULL template_id + {{context.template.id}} token → 400 MISSING_INPUT naming the token', async () => {
  fakeRows.step = {
    id: 's_tpl', recipe_id: 'r_tpl', name: 'tpl-step', method: 'GET',
    url: 'https://ok.test/tpl/{{context.template.id}}',
    auth_type: 'none', auth_config: '{}', request_config: '{}', response_config: '{}',
    input_from_step: null, timeout_ms: null, dispatch_origin: 'edge',
  };
  fakeRows.recipe = { is_active: 1, status: 'approved', owner_id: 'editor1', blueprint_id: null };
  fakeRows.run = { id: 'run1', recipe_id: 'r_tpl', template_id: null, actor_id: 'editor1' };
  const { status, json } = await post(
    appWith({ id: 'editor1', role: 'editor' }),
    '/edge/internal/flow-steps/prepare',
    { step_id: 's_tpl', run_id: 'run1', inputs: {} },
  );
  assert.strictEqual(status, 400, `expected 400, got ${status}: ${JSON.stringify(json)}`);
  assert.strictEqual(json.error.code, 'MISSING_INPUT');
  assert.match(json.error.message, /context\.template\.id/);
});

// (t7) run_id absent → byte-identical legacy behavior: no run/template/nodes/users
// query is issued and {{payload}} fills exactly as before.
test('run_id absent → legacy path (no run load, no bag) fills {{payload}} unchanged', async () => {
  const connDispatch = require('../../../../src/edge/lib/connector-dispatch');
  const origExecute = connDispatch.executeRequest;
  let capturedReq;
  connDispatch.executeRequest = async (req) => { capturedReq = req; return { upstream_status: 200, headers: {}, body: '{}', duration_ms: 1 }; };
  try {
    fakeRows.step = {
      id: 's_legacy', recipe_id: 'r_legacy', name: 'legacy', method: 'POST', url: 'https://ok.test/x',
      auth_type: 'none', auth_config: '{}', request_config: JSON.stringify({ body: '{{payload}}' }),
      response_config: '{}', input_from_step: null, timeout_ms: null, dispatch_origin: 'edge',
    };
    fakeRows.recipe = { is_active: 1, status: 'approved', owner_id: 'editor1', blueprint_id: null };
    // Arm template fixtures too — they must remain UNTOUCHED without a run_id.
    fakeRows.run = { id: 'run1', recipe_id: 'r_legacy', template_id: 'tpl-1', actor_id: 'editor1' };
    fakeRows.template = { id: 'tpl-1', name: 'Turbine Spec', category_id: null, release_id: null, blueprint_id: null, variant_id: null, owner_id: null, created_at: null, updated_at: null };

    const { status } = await post(
      appWith({ id: 'editor1', role: 'editor' }),
      '/edge/internal/flow-steps/prepare',
      { step_id: 's_legacy', inputs: { payload: 'HELLO' } }, // NO run_id
    );

    assert.strictEqual(status, 200);
    assert.strictEqual(capturedReq.body, 'HELLO');
    assert.ok(!queries.some((q) => /FROM `flow_recipe_runs`/.test(q.sql)), 'no run row must be loaded without a run_id');
    assert.ok(!queries.some((q) => /FROM `user_templates`/.test(q.sql)), 'no template bag must be built without a run_id');
  } finally {
    connDispatch.executeRequest = origExecute;
  }
});

// (t8) Rename semantics, no run (no bag): a client key `context.template.name`
// is renamed to `payload.context.template.name`, so the referenced
// {{context.template.name}} token has no server value and hits MISSING_INPUT
// rather than being filled with the caller's value.
test('no run_id + spoofed client context.template.name → 400 MISSING_INPUT (renamed, never filled)', async () => {
  fakeRows.step = {
    id: 's_strip1', recipe_id: 'r_strip1', name: 'strip-nobag', method: 'POST',
    url: 'https://ok.test/x', auth_type: 'none', auth_config: '{}',
    request_config: JSON.stringify({ body: '{{context.template.name}}' }),
    response_config: '{}', input_from_step: null,
    timeout_ms: null, dispatch_origin: 'edge',
  };
  fakeRows.recipe = { is_active: 1, status: 'approved', owner_id: 'editor1', blueprint_id: null };
  const { status, json } = await post(
    appWith({ id: 'editor1', role: 'editor' }),
    '/edge/internal/flow-steps/prepare',
    { step_id: 's_strip1', inputs: { 'context.template.name': 'Trusted Corp Template' } }, // NO run_id
  );
  assert.strictEqual(status, 400, `expected 400, got ${status}: ${JSON.stringify(json)}`);
  assert.strictEqual(json.error.code, 'MISSING_INPUT');
  assert.match(json.error.message, /context\.template\.name/);
});

// (t9) Rename semantics, unbound run (template_id NULL, no bag): a client-supplied
// `context.template.id` is renamed to `payload.context.template.id`, so
// {{context.template.id}} is MISSING_INPUT, never the caller's forged uuid.
test('unbound run + spoofed client context.template.id → 400 MISSING_INPUT (renamed, never filled)', async () => {
  fakeRows.step = {
    id: 's_strip2', recipe_id: 'r_strip2', name: 'strip-unbound', method: 'GET',
    url: 'https://ok.test/tpl/{{context.template.id}}', auth_type: 'none', auth_config: '{}',
    request_config: '{}', response_config: '{}', input_from_step: null,
    timeout_ms: null, dispatch_origin: 'edge',
  };
  fakeRows.recipe = { is_active: 1, status: 'approved', owner_id: 'editor1', blueprint_id: null };
  fakeRows.run = { id: 'run1', recipe_id: 'r_strip2', template_id: null, actor_id: 'editor1' };
  const { status, json } = await post(
    appWith({ id: 'editor1', role: 'editor' }),
    '/edge/internal/flow-steps/prepare',
    { step_id: 's_strip2', run_id: 'run1', inputs: { 'context.template.id': 'forged-other-uuid' } },
  );
  assert.strictEqual(status, 400, `expected 400, got ${status}: ${JSON.stringify(json)}`);
  assert.strictEqual(json.error.code, 'MISSING_INPUT');
  assert.match(json.error.message, /context\.template\.id/);
});

// ─── PR-1 vocab v2: canonical-only tokens + client-key `payload.<k>` rename ────
// One name per datum. Client input keys are renamed to `payload.<k>` (literal
// `payload` passes through); the server bag is the ONLY source of `context.*`.
// Legacy `template_*` / short `template.*` / bare `{{<key>}}` no longer fill.

// (a1) Canonical dispatch: a body mixing {{context.template.name}} (server bag) +
// {{payload.qty}} (client sent bare key `qty`, renamed) fills both; the URL fills
// {{context.template.id}} from the run's template.
test('canonical dispatch fills {{context.template.name}} + {{payload.qty}} + {{context.template.id}}', async () => {
  const connDispatch = require('../../../../src/edge/lib/connector-dispatch');
  const origExecute = connDispatch.executeRequest;
  let capturedReq;
  connDispatch.executeRequest = async (req) => { capturedReq = req; return { upstream_status: 200, headers: {}, body: '{}', duration_ms: 1 }; };
  try {
    armBoundRun({
      stepOver: {
        url: 'https://ok.test/tpl/{{context.template.id}}',
        request_config: JSON.stringify({ body: '{{context.template.name}} | {{payload.qty}}' }),
      },
    });
    const { status, json } = await post(
      appWith({ id: 'editor1', role: 'editor' }),
      '/edge/internal/flow-steps/prepare',
      { step_id: 's_tpl', run_id: 'run1', inputs: { qty: '42' } },
    );
    assert.strictEqual(status, 200, `expected 200, got ${status}: ${JSON.stringify(json)}`);
    assert.ok(capturedReq, 'dispatch never reached the outbound call');
    assert.strictEqual(capturedReq.url, 'https://ok.test/tpl/tpl-1');
    assert.strictEqual(capturedReq.body, 'Turbine Spec | 42');
  } finally {
    connDispatch.executeRequest = origExecute;
  }
});

// (a1b) Removal proof: a legacy {{template_name}} token no longer fills — even
// when the client sends a bare `template_name` key (renamed to
// payload.template_name) — so the token hits MISSING_INPUT.
test('legacy {{template_name}} no longer fills → 400 MISSING_INPUT (removal proof)', async () => {
  armBoundRun({ stepOver: { request_config: JSON.stringify({ body: '{{template_name}}' }) } });
  const { status, json } = await post(
    appWith({ id: 'editor1', role: 'editor' }),
    '/edge/internal/flow-steps/prepare',
    { step_id: 's_tpl', run_id: 'run1', inputs: { template_name: 'legacy value' } },
  );
  assert.strictEqual(status, 400, `expected 400, got ${status}: ${JSON.stringify(json)}`);
  assert.strictEqual(json.error.code, 'MISSING_INPUT');
  assert.match(json.error.message, /template_name/);
});

// (a1c) Removal proof: a bare {{qty}} no longer fills from a client `qty` key —
// only {{payload.qty}} does — so bare {{qty}} hits MISSING_INPUT.
test('bare {{qty}} no longer fills from a client key → 400 MISSING_INPUT (only payload.qty fills)', async () => {
  fakeRows.step = {
    id: 's_bare', recipe_id: 'r_bare', name: 'bare-key', method: 'POST',
    url: 'https://ok.test/x', auth_type: 'none', auth_config: '{}',
    request_config: JSON.stringify({ body: '{{qty}}' }),
    response_config: '{}', input_from_step: null,
    timeout_ms: null, dispatch_origin: 'edge',
  };
  fakeRows.recipe = { is_active: 1, status: 'approved', owner_id: 'editor1', blueprint_id: null };
  const { status, json } = await post(
    appWith({ id: 'editor1', role: 'editor' }),
    '/edge/internal/flow-steps/prepare',
    { step_id: 's_bare', inputs: { qty: '42' } },
  );
  assert.strictEqual(status, 400, `expected 400, got ${status}: ${JSON.stringify(json)}`);
  assert.strictEqual(json.error.code, 'MISSING_INPUT');
});

// (a2) Rename shields the server bag: client-supplied `context.userId` AND
// `context.template.id` are renamed to `payload.context.*` and cannot shadow the
// server values; both tokens resolve to the server-authoritative values.
test('client context.userId / context.template.id are renamed and cannot shadow the server bag (bound run)', async () => {
  const connDispatch = require('../../../../src/edge/lib/connector-dispatch');
  const origExecute = connDispatch.executeRequest;
  let capturedReq;
  connDispatch.executeRequest = async (req) => { capturedReq = req; return { upstream_status: 200, headers: {}, body: '{}', duration_ms: 1 }; };
  try {
    armBoundRun({
      stepOver: {
        url: 'https://ok.test/tpl/{{context.template.id}}',
        request_config: JSON.stringify({ body: '{{context.userId}}' }),
      },
    });
    const { status, json } = await post(
      appWith({ id: 'editor1', role: 'editor' }),
      '/edge/internal/flow-steps/prepare',
      { step_id: 's_tpl', run_id: 'run1', inputs: { 'context.userId': 'forged-user', 'context.template.id': 'forged' } },
    );
    assert.strictEqual(status, 200, `expected 200, got ${status}: ${JSON.stringify(json)}`);
    assert.strictEqual(capturedReq.body, 'editor1', 'context.userId must be the caller id, not the forged value');
    assert.strictEqual(capturedReq.url, 'https://ok.test/tpl/tpl-1', 'context.template.id must be the server value');
  } finally {
    connDispatch.executeRequest = origExecute;
  }
});

// (a3) Rename shields with NO bound run too: a client `context.userId` (renamed to
// payload.context.userId) cannot fill {{context.userId}} with the forged value —
// the server scalar (caller id) is the only source.
test('no run_id + client context.userId is renamed; {{context.userId}} still fills from caller id', async () => {
  const connDispatch = require('../../../../src/edge/lib/connector-dispatch');
  const origExecute = connDispatch.executeRequest;
  let capturedReq;
  connDispatch.executeRequest = async (req) => { capturedReq = req; return { upstream_status: 200, headers: {}, body: '{}', duration_ms: 1 }; };
  try {
    fakeRows.step = {
      id: 's_a3', recipe_id: 'r_a3', name: 'a3', method: 'POST',
      url: 'https://ok.test/x', auth_type: 'none', auth_config: '{}',
      request_config: JSON.stringify({ body: '{{context.userId}}' }),
      response_config: '{}', input_from_step: null,
      timeout_ms: null, dispatch_origin: 'edge',
    };
    fakeRows.recipe = { is_active: 1, status: 'approved', owner_id: 'editor1', blueprint_id: null };
    const { status } = await post(
      appWith({ id: 'editor1', role: 'editor' }),
      '/edge/internal/flow-steps/prepare',
      { step_id: 's_a3', inputs: { 'context.userId': 'forged-user' } }, // NO run_id
    );
    assert.strictEqual(status, 200);
    assert.strictEqual(capturedReq.body, 'editor1');
  } finally {
    connDispatch.executeRequest = origExecute;
  }
});

// (a3b) {{payload}} whole-message still fills from the client's literal `payload`
// key (the one key that passes through the rename unchanged).
test('{{payload}} whole-message fills from the literal client payload key', async () => {
  const connDispatch = require('../../../../src/edge/lib/connector-dispatch');
  const origExecute = connDispatch.executeRequest;
  let capturedReq;
  connDispatch.executeRequest = async (req) => { capturedReq = req; return { upstream_status: 200, headers: {}, body: '{}', duration_ms: 1 }; };
  try {
    fakeRows.step = {
      id: 's_pl', recipe_id: 'r_pl', name: 'payload-passthrough', method: 'POST',
      url: 'https://ok.test/x', auth_type: 'none', auth_config: '{}',
      request_config: JSON.stringify({ body: '{{payload}}' }),
      response_config: '{}', input_from_step: null,
      timeout_ms: null, dispatch_origin: 'edge',
    };
    fakeRows.recipe = { is_active: 1, status: 'approved', owner_id: 'editor1', blueprint_id: null };
    const { status } = await post(
      appWith({ id: 'editor1', role: 'editor' }),
      '/edge/internal/flow-steps/prepare',
      { step_id: 's_pl', inputs: { payload: 'WHOLE-MESSAGE' } },
    );
    assert.strictEqual(status, 200);
    assert.strictEqual(capturedReq.body, 'WHOLE-MESSAGE');
  } finally {
    connDispatch.executeRequest = origExecute;
  }
});

// (a3c) context.displayName is resolved from the caller's own users row
// (fakeRows.owner backs every `FROM users` lookup here) and fills on dispatch.
test('{{context.displayName}} fills from the caller users row (email-safe)', async () => {
  const connDispatch = require('../../../../src/edge/lib/connector-dispatch');
  const origExecute = connDispatch.executeRequest;
  let capturedReq;
  connDispatch.executeRequest = async (req) => { capturedReq = req; return { upstream_status: 200, headers: {}, body: '{}', duration_ms: 1 }; };
  try {
    armBoundRun({ stepOver: { request_config: JSON.stringify({ body: '{{context.displayName}}' }) } });
    const { status, json } = await post(
      appWith({ id: 'editor1', role: 'editor' }),
      '/edge/internal/flow-steps/prepare',
      { step_id: 's_tpl', run_id: 'run1', inputs: {} },
    );
    assert.strictEqual(status, 200, `expected 200, got ${status}: ${JSON.stringify(json)}`);
    assert.strictEqual(capturedReq.body, 'Alice Owner');
  } finally {
    connDispatch.executeRequest = origExecute;
  }
});

// (a3c2) CRITICAL: an email-shaped display_name is stripped to its local part —
// the outbound request never carries a full email.
test('{{context.displayName}} strips an email-shaped display name to the local part', async () => {
  const connDispatch = require('../../../../src/edge/lib/connector-dispatch');
  const origExecute = connDispatch.executeRequest;
  let capturedReq;
  connDispatch.executeRequest = async (req) => { capturedReq = req; return { upstream_status: 200, headers: {}, body: '{}', duration_ms: 1 }; };
  try {
    fakeRows.step = {
      id: 's_dn', recipe_id: 'r_dn', name: 'displayname-strip', method: 'POST',
      url: 'https://ok.test/x', auth_type: 'none', auth_config: '{}',
      request_config: JSON.stringify({ body: '{{context.displayName}}' }),
      response_config: '{}', input_from_step: null,
      timeout_ms: null, dispatch_origin: 'edge',
    };
    fakeRows.recipe = { is_active: 1, status: 'approved', owner_id: 'editor1', blueprint_id: null };
    fakeRows.owner = { display_name: 'someone@example.com', kc_username: null };
    const { status } = await post(
      appWith({ id: 'editor1', role: 'editor' }),
      '/edge/internal/flow-steps/prepare',
      { step_id: 's_dn', inputs: {} }, // ad-hoc, no run_id
    );
    assert.strictEqual(status, 200);
    assert.strictEqual(capturedReq.body, 'someone');
    assert.ok(!capturedReq.body.includes('@'), 'displayName must never be a full email');
  } finally {
    connDispatch.executeRequest = origExecute;
  }
});

// (a3c3) Fail-closed: no users row for the caller → context.displayName is
// OMITTED → {{context.displayName}} hits the MISSING_INPUT gate (never "").
test('{{context.displayName}} with no caller users row → 400 MISSING_INPUT', async () => {
  fakeRows.step = {
    id: 's_dn2', recipe_id: 'r_dn2', name: 'displayname-missing', method: 'POST',
    url: 'https://ok.test/x', auth_type: 'none', auth_config: '{}',
    request_config: JSON.stringify({ body: '{{context.displayName}}' }),
    response_config: '{}', input_from_step: null,
    timeout_ms: null, dispatch_origin: 'edge',
  };
  fakeRows.recipe = { is_active: 1, status: 'approved', owner_id: 'editor1', blueprint_id: null };
  fakeRows.owner = null; // caller users row absent
  const { status, json } = await post(
    appWith({ id: 'editor1', role: 'editor' }),
    '/edge/internal/flow-steps/prepare',
    { step_id: 's_dn2', inputs: {} }, // ad-hoc, no run_id
  );
  assert.strictEqual(status, 400, `expected 400, got ${status}: ${JSON.stringify(json)}`);
  assert.strictEqual(json.error.code, 'MISSING_INPUT');
  assert.match(json.error.message, /context\.displayName/);
});

// (a4) Legacy assertion kept under v2 semantics: a bound run + a body reading
// {{context.userId}} fills with the authenticated caller's id.
test('{{context.userId}} fills from caller identity on a bound run', async () => {
  const connDispatch = require('../../../../src/edge/lib/connector-dispatch');
  const origExecute = connDispatch.executeRequest;
  let capturedReq;
  connDispatch.executeRequest = async (req) => { capturedReq = req; return { upstream_status: 200, headers: {}, body: '{}', duration_ms: 1 }; };
  try {
    armBoundRun({ stepOver: { request_config: JSON.stringify({ body: '{{context.userId}}' }) } });
    const { status, json } = await post(
      appWith({ id: 'editor1', role: 'editor' }),
      '/edge/internal/flow-steps/prepare',
      { step_id: 's_tpl', run_id: 'run1', inputs: { 'context.userId': 'forged-user' } },
    );
    assert.strictEqual(status, 200, `expected 200, got ${status}: ${JSON.stringify(json)}`);
    assert.strictEqual(capturedReq.body, 'editor1', 'context.userId must be the caller id, not the forged value');
  } finally {
    connDispatch.executeRequest = origExecute;
  }
});

// (a5) context.userId is available on EVERY dispatch — including an ad-hoc step
// test with NO run_id (no bag). {{context.userId}} fills from req.user.id.
test('{{context.userId}} fills on an ad-hoc step test (no run_id)', async () => {
  const connDispatch = require('../../../../src/edge/lib/connector-dispatch');
  const origExecute = connDispatch.executeRequest;
  let capturedReq;
  connDispatch.executeRequest = async (req) => { capturedReq = req; return { upstream_status: 200, headers: {}, body: '{}', duration_ms: 1 }; };
  try {
    fakeRows.step = {
      id: 's_ctx1', recipe_id: 'r_ctx1', name: 'ctx-userid', method: 'POST',
      url: 'https://ok.test/x', auth_type: 'none', auth_config: '{}',
      request_config: JSON.stringify({ body: '{{context.userId}}' }),
      response_config: '{}', input_from_step: null,
      timeout_ms: null, dispatch_origin: 'edge',
    };
    fakeRows.recipe = { is_active: 1, status: 'approved', owner_id: 'editor1', blueprint_id: null };
    const { status } = await post(
      appWith({ id: 'editor1', role: 'editor' }),
      '/edge/internal/flow-steps/prepare',
      { step_id: 's_ctx1', inputs: {} }, // NO run_id
    );
    assert.strictEqual(status, 200);
    assert.strictEqual(capturedReq.body, 'editor1');
  } finally {
    connDispatch.executeRequest = origExecute;
  }
});

// (a6) context.blueprintName resolves from the verified run row's blueprint NODE
// (name, not id). On an ad-hoc test (no run) it is absent → the token hits the
// MISSING_INPUT gate.
test('{{context.blueprintName}} on an ad-hoc test (no run) → 400 MISSING_INPUT', async () => {
  fakeRows.step = {
    id: 's_ctx2', recipe_id: 'r_ctx2', name: 'ctx-bp-missing', method: 'GET',
    url: 'https://ok.test/bp/{{context.blueprintName}}', auth_type: 'none', auth_config: '{}',
    request_config: '{}', response_config: '{}', input_from_step: null,
    timeout_ms: null, dispatch_origin: 'edge',
  };
  fakeRows.recipe = { is_active: 1, status: 'approved', owner_id: 'editor1', blueprint_id: null };
  const { status, json } = await post(
    appWith({ id: 'editor1', role: 'editor' }),
    '/edge/internal/flow-steps/prepare',
    { step_id: 's_ctx2', inputs: {} }, // NO run_id
  );
  assert.strictEqual(status, 400, `expected 400, got ${status}: ${JSON.stringify(json)}`);
  assert.strictEqual(json.error.code, 'MISSING_INPUT');
});

// (a7) context.blueprintName resolves the run's blueprint_id to its hierarchy
// NODE NAME (vocabulary rule: names, not ids).
test('{{context.blueprintName}} fills the blueprint node name from the verified run row', async () => {
  const connDispatch = require('../../../../src/edge/lib/connector-dispatch');
  const origExecute = connDispatch.executeRequest;
  let capturedReq;
  connDispatch.executeRequest = async (req) => { capturedReq = req; return { upstream_status: 200, headers: {}, body: '{}', duration_ms: 1 }; };
  try {
    armBoundRun({
      stepOver: {
        url: 'https://ok.test/bp',
        request_config: JSON.stringify({ body: '{{context.blueprintName}}' }),
      },
      runOver: { blueprint_id: 'bp-run-77' },
    });
    fakeRows.blueprintNode = { name: 'North Sea Alpha' };
    const { status, json } = await post(
      appWith({ id: 'editor1', role: 'editor' }),
      '/edge/internal/flow-steps/prepare',
      { step_id: 's_tpl', run_id: 'run1', inputs: {} },
    );
    assert.strictEqual(status, 200, `expected 200, got ${status}: ${JSON.stringify(json)}`);
    assert.strictEqual(capturedReq.body, 'North Sea Alpha');
  } finally {
    connDispatch.executeRequest = origExecute;
  }
});

// (a8) context.variantName resolves the bound template's variant node NAME.
test('{{context.variantName}} fills the variant node name from the bound template', async () => {
  const connDispatch = require('../../../../src/edge/lib/connector-dispatch');
  const origExecute = connDispatch.executeRequest;
  let capturedReq;
  connDispatch.executeRequest = async (req) => { capturedReq = req; return { upstream_status: 200, headers: {}, body: '{}', duration_ms: 1 }; };
  try {
    armBoundRun({
      stepOver: { request_config: JSON.stringify({ body: '{{context.variantName}}' }) },
      templateOver: {
        id: 'tpl-1', name: 'Turbine Spec',
        category_id: 'cat-1', release_id: null, blueprint_id: null, variant_id: 'var-9',
        owner_id: 'owner-1', created_at: '2026-01-01 08:00:00', updated_at: '2026-01-02 09:00:00',
      },
    });
    // buildTemplateContext's path query returns both tiers; the variant tier NAME
    // is what context.variantName reads.
    fakeRows.nodes = [{ id: 'cat-1', name: 'Wind' }, { id: 'var-9', name: 'Offshore Variant' }];
    const { status, json } = await post(
      appWith({ id: 'editor1', role: 'editor' }),
      '/edge/internal/flow-steps/prepare',
      { step_id: 's_tpl', run_id: 'run1', inputs: {} },
    );
    assert.strictEqual(status, 200, `expected 200, got ${status}: ${JSON.stringify(json)}`);
    assert.strictEqual(capturedReq.body, 'Offshore Variant');
  } finally {
    connDispatch.executeRequest = origExecute;
  }
});

// (a9) context.variantName has no value when the template has no variant → the
// token fails closed through the MISSING_INPUT gate.
test('{{context.variantName}} with a template that has no variant → 400 MISSING_INPUT', async () => {
  armBoundRun({ stepOver: { request_config: JSON.stringify({ body: '{{context.variantName}}' }) } });
  // default armBoundRun template has variant_id: null
  const { status, json } = await post(
    appWith({ id: 'editor1', role: 'editor' }),
    '/edge/internal/flow-steps/prepare',
    { step_id: 's_tpl', run_id: 'run1', inputs: {} },
  );
  assert.strictEqual(status, 400, `expected 400, got ${status}: ${JSON.stringify(json)}`);
  assert.strictEqual(json.error.code, 'MISSING_INPUT');
  assert.match(json.error.message, /context\.variantName/);
});
