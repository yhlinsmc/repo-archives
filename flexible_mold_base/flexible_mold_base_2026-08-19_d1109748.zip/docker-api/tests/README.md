# docker-api tests

Tests for the Express API backend, run via Node's built-in test runner
(`node --test`, stable since Node 20). Zero dev dependencies — everything
uses the stdlib `node:test` and `node:assert/strict` modules plus the
production dependencies already declared in `package.json`.

## Layout

```
tests/
├── unit/           # Pure-function tests, no DB, no network
│   ├── smoke.test.js
│   └── dto-mapper.test.js
├── integration/    # Real DB + real migrations, opt-in
│   └── run-schema-migrations.test.js
└── README.md
```

## Commands

```bash
# Run everything (unit + integration if DB available)
npm test

# Unit tests only — fast, no DB, safe to run in CI
npm run test:unit

# Integration tests only — needs MariaDB
npm run test:integration
```

The `test` script uses a shell glob (`'tests/**/*.test.js'`) instead of a
bare directory path because Node 20+ treats a positional path argument as
a file to execute, not a directory to scan — the glob form is the
documented discovery pattern.

## Integration test DB auto-detection

The integration suite tries three sources for a MariaDB connection, in
order:

1. `DB_TEST_URL` env var (e.g. `mariadb://user:pass@host:3306/db`) — use
   this in CI or non-DevContainer environments.
2. Process env `DB_HOST` / `DB_PORT` / `DB_USER` / `DB_ROOT_PASSWORD` /
   `DB_NAME` (individual vars, same names as production).
3. Parsed from `.devcontainer/.env` at the repo root — the fully-automated
   local path used when Claude or a developer runs `npm test` from the
   WSL host against a running DevContainer.

If none of those resolve a reachable MariaDB, integration tests are
**skipped gracefully** (`test.skip(...)`) rather than failing. This
keeps `npm test` green in environments without a database.

Each integration test creates a fresh, isolated test database
(`<base>_test_v322_<pid>`) so it cannot pollute dev data, and drops the
database on teardown.

## CI wiring (future)

`.gitlab-ci.yml` currently only runs `npm test` at the repo root (Vitest
frontend tests). Wiring `cd docker-api && npm test` into the CI test stage
is tracked as a separate follow-up — it needs a MariaDB service container
in the runner, which is a bigger CI change than this test-infra PR.
