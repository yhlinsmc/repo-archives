/**
 * capacity-topology.test.js — TOPO-R1 fix-batch item 5: BE-only coverage for
 * `docker-api/src/shared/capacity/topology.js`'s node/instance-count table
 * (`TOPOLOGY_NODE_DEFS`, `resolveNodeCounts`, `RAC_MIN_NODES`/`RAC_MAX_NODES`)
 * so a BE-only regression surfaces in the node:test runner without needing
 * the FE vitest suite (`topology-mirror-parity.test.ts` already covers the
 * FE↔BE cross-runtime agreement; this file covers the BE module in isolation,
 * same discipline as `capacity-name-patterns.test.js`'s own server-mirror
 * describe blocks).
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const {
  TOPOLOGY, TOPOLOGY_NODE_DEFS, RAC_MIN_NODES, RAC_MAX_NODES, resolveNodeCounts,
} = require('../../src/shared/capacity/topology');

describe('TOPOLOGY_NODE_DEFS shape', () => {
  it('single/primary/primary_standby have topology-fixed primary sides', () => {
    assert.deepEqual(TOPOLOGY_NODE_DEFS[TOPOLOGY.SINGLE], { primary: { fixed: 1 } });
    assert.deepEqual(TOPOLOGY_NODE_DEFS[TOPOLOGY.PRIMARY], { primary: { fixed: 2 } });
    assert.deepEqual(
      TOPOLOGY_NODE_DEFS[TOPOLOGY.PRIMARY_STANDBY],
      { primary: { fixed: 2 }, standby: { fixed: 2 } },
    );
  });
  it('the RAC family has a min/max primary range', () => {
    assert.deepEqual(TOPOLOGY_NODE_DEFS[TOPOLOGY.RAC_MULTINODE], { primary: { min: 2, max: 100 } });
    assert.deepEqual(
      TOPOLOGY_NODE_DEFS[TOPOLOGY.RAC_MULTINODE_STANDBY],
      { primary: { min: 2, max: 100 }, standby: { default: 'primary', floor: 1 } },
    );
  });
  it('every entry is frozen (import-time immutability)', () => {
    for (const value of Object.values(TOPOLOGY)) {
      const spec = TOPOLOGY_NODE_DEFS[value];
      assert.ok(Object.isFrozen(spec));
      assert.ok(Object.isFrozen(spec.primary));
      if (spec.standby) assert.ok(Object.isFrozen(spec.standby));
    }
  });
});

describe('RAC_MIN_NODES / RAC_MAX_NODES', () => {
  it('are the rac_multinode primary min/max, byte-parity with the FE mirror', () => {
    assert.equal(RAC_MIN_NODES, 2);
    assert.equal(RAC_MAX_NODES, 100);
  });
});

describe('resolveNodeCounts per topology', () => {
  it('single: fixed 1 primary, 0 standby, ignores both count args', () => {
    assert.deepEqual(resolveNodeCounts('single', 99, 99), { primary: 1, standby: 0 });
  });
  it('primary: fixed 2 primary, 0 standby', () => {
    assert.deepEqual(resolveNodeCounts('primary', 5, 5), { primary: 2, standby: 0 });
  });
  it('primary_standby: fixed 2 primary + 2 standby, nodeCount ignored', () => {
    assert.deepEqual(resolveNodeCounts('primary_standby', 99, undefined), { primary: 2, standby: 2 });
  });
  it('rac_multinode: primary floors to the min when nodeCount is below it', () => {
    assert.deepEqual(resolveNodeCounts('rac_multinode', 1, undefined), { primary: 2, standby: 0 });
  });
  it('rac_multinode: primary passes through when at/above the min (no upper clamp here)', () => {
    assert.deepEqual(resolveNodeCounts('rac_multinode', 4, undefined), { primary: 4, standby: 0 });
    assert.deepEqual(resolveNodeCounts('rac_multinode', 101, undefined), { primary: 101, standby: 0 });
  });
  it('rac_multinode_standby: standby defaults to the resolved primary count (S=N)', () => {
    assert.deepEqual(resolveNodeCounts('rac_multinode_standby', 4, undefined), { primary: 4, standby: 4 });
  });
  it('rac_multinode_standby: an explicit standbyNodeCount overrides the default', () => {
    assert.deepEqual(resolveNodeCounts('rac_multinode_standby', 4, 2), { primary: 4, standby: 2 });
  });
  it('rac_multinode_standby: null standbyNodeCount falls through to the default like undefined', () => {
    assert.deepEqual(
      resolveNodeCounts('rac_multinode_standby', 4, null),
      resolveNodeCounts('rac_multinode_standby', 4, undefined),
    );
  });
  it('rac_multinode_standby: a negative standby count clamps to the floor (1)', () => {
    assert.deepEqual(resolveNodeCounts('rac_multinode_standby', 3, -5), { primary: 3, standby: 1 });
  });
  it('unknown topology value returns null (byte-parity with wizard.js old default: return null)', () => {
    assert.equal(resolveNodeCounts('bogus', 4, 2), null);
    assert.equal(resolveNodeCounts(undefined, 4, 2), null);
  });
});
