/**
 * blueprint-import-compute-rule-guard.test.js
 *
 * The import paths build their INSERT from the columns the target table
 * actually has, intersected with the keys of the UPLOADED payload — by design,
 * so any column added later travels automatically. compute_rule and value_source
 * inherited that the moment they were declared, which handed an importer a way
 * past every guard the field write routes apply: an unvalidated rule reaches the
 * column, and the next legitimate write anywhere in that blueprint loads it,
 * finds a cycle, and refuses an edit that has nothing wrong with it. Import is
 * open to editors, and the overwrite mode can target a blueprint that is shared
 * with everyone.
 *
 * These tests drive the real route over HTTP against a mocked driver, so they
 * exercise the wiring (payload → validation → INSERT), not the validator alone.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../src/edge/db');
const { __clearPortableColumnCache } = require('../../src/edge/lib/portable-insert');
const { MAX_CONCAT_PARTS } = require('../../src/edge/lib/compute-rule-validate');

const PREFIX = 'fmb_';
const DB_NAME = 'testdb';

// The probe reports the policy columns this PR adds, so an unguarded import
// would carry them into the INSERT.
const COLUMN_META = {
  blueprint_fields: [
    'id', 'blueprint_id', 'field_key', 'field_label', 'field_type', 'is_required',
    'default_value', 'placeholder', 'tooltip', 'section', 'order_index',
    'table_config', 'visibility_rule', 'value_source', 'value_scope', 'compute_rule', 'created_at',
  ],
  field_options: ['id', 'field_id', 'option_label', 'option_value', 'sort_order', 'created_at'],
  blueprint_sections: ['id', 'blueprint_id', 'section_key', 'display_label', 'sort_order', 'created_at'],
};

let inserts;

const tableSuffix = (physical) => (physical.startsWith(PREFIX) ? physical.slice(PREFIX.length) : physical);

function makeConn() {
  return {
    async query(sql, params) {
      if (/^SELECT DATABASE\(\)/i.test(sql)) return [{ db: DB_NAME }];
      if (/information_schema\.TABLES/i.test(sql)) return [];
      if (/information_schema\.COLUMNS/i.test(sql)) {
        return (COLUMN_META[tableSuffix(params[0])] || []).map((c) => ({ COLUMN_NAME: c }));
      }
      // Parent validation: target_parent_id resolves to a Release node.
      if (/FROM `fmb_hierarchy_nodes`/i.test(sql) && /WHERE id = \?/i.test(sql)) {
        return [{ id: params[0], node_type: 'release', parent_id: null }];
      }
      if (/^INSERT INTO/i.test(sql)) {
        const m = sql.match(/INSERT INTO `([^`]+)`/i);
        inserts.push({ table: m ? tableSuffix(m[1]) : '', sql, params });
        return { affectedRows: 1 };
      }
      return [];
    },
    async beginTransaction() {},
    async commit() {},
    async rollback() {},
    release() {},
  };
}

const poolSpy = {
  rw: { async getConnection() { return makeConn(); } },
  ro: { async getConnection() { return makeConn(); } },
};

require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: poolSpy, t: (name) => `${PREFIX}${name}`, getDynamicPool: async () => poolSpy },
};

const router = require('../../src/edge/routes/app/blueprint-export');

let server;
let port;

before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { req.user = { id: 'editor-1', role: 'editor' }; next(); });
  app.use('/edge/app/schema', router);
  await new Promise((resolve) => {
    server = app.listen(0, '127.0.0.1', () => { port = server.address().port; resolve(); });
  });
});

after(async () => {
  await new Promise((resolve) => server.close(resolve));
  delete require.cache[dbKey];
});

beforeEach(() => {
  inserts = [];
  __clearPortableColumnCache();
});

function importJson(payload) {
  return new Promise((resolve, reject) => {
    const data = JSON.stringify(payload);
    const req = http.request({
      method: 'POST', host: '127.0.0.1', port,
      path: '/edge/app/schema/blueprint-import?target_parent_id=rel-1',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(data) },
    }, (res) => {
      let raw = '';
      res.on('data', (c) => { raw += c; });
      res.on('end', () => resolve({ status: res.statusCode, body: raw ? JSON.parse(raw) : null }));
    });
    req.on('error', reject);
    req.write(data);
    req.end();
  });
}

const concat = (...keys) => ({
  op: 'concat',
  overridable: false,
  output_type: 'string',
  config: { parts: keys.map((key) => ({ type: 'field', key })) },
});

function field(overrides) {
  return {
    id: `f-${overrides.field_key}`, blueprint_id: 'node-1',
    field_label: 'L', field_type: 'text', is_required: 0, section: 'general',
    ...overrides,
  };
}

function payloadWith(fields) {
  return {
    import_version: 1,
    hierarchy_node: { id: 'node-1', name: 'My Blueprint', node_type: 'blueprint' },
    blueprint_fields: fields,
    field_options: [],
    blueprint_sections: [],
    blueprint_output_order: [],
  };
}

const fieldInserts = () => inserts.filter((i) => i.table === 'blueprint_fields');
const errorsOf = (res) => (res.body && res.body.validation_errors) || [];

describe('JSON import — compute_rule is validated before it is written', () => {
  it('rejects a rule whose source field is not in the payload', async () => {
    const res = await importJson(payloadWith([
      field({ field_key: 'pn', compute_rule: concat('ghost') }),
    ]));
    assert.equal(res.status, 400);
    assert.ok(errorsOf(res).some((e) => /pn/.test(e) && /missing_source/.test(e)),
      `expected a per-field missing_source error, got ${JSON.stringify(errorsOf(res))}`);
    assert.equal(fieldInserts().length, 0, 'the whole import must be rejected, not partially applied');
  });

  it('rejects a rule with an op the resolver cannot read', async () => {
    const res = await importJson(payloadWith([
      field({ field_key: 'pn', compute_rule: { op: 'danger', overridable: false, output_type: 'string', config: {} } }),
    ]));
    assert.equal(res.status, 400);
    assert.ok(errorsOf(res).some((e) => /unknown_op/.test(e)));
    assert.equal(fieldInserts().length, 0);
  });

  it('rejects a rule whose output type contradicts the field type', async () => {
    const res = await importJson(payloadWith([
      field({
        field_key: 'qty', field_type: 'text',
        compute_rule: { op: 'arith', overridable: false, output_type: 'number', config: { operator: 'add', operands: [{ type: 'literal', value: 1 }] } },
      }),
    ]));
    assert.equal(res.status, 400);
    assert.ok(errorsOf(res).some((e) => /output_type_mismatch/.test(e)));
  });

  it('rejects a payload whose rules form a cycle', async () => {
    const res = await importJson(payloadWith([
      field({ field_key: 'a', compute_rule: concat('b') }),
      field({ field_key: 'b', compute_rule: concat('a') }),
    ]));
    assert.equal(res.status, 400);
    assert.ok(errorsOf(res).some((e) => /cycle/i.test(e)));
    assert.equal(fieldInserts().length, 0);
  });

  it('rejects a self-referencing rule', async () => {
    const res = await importJson(payloadWith([
      field({ field_key: 'a', compute_rule: concat('a') }),
    ]));
    assert.equal(res.status, 400);
    assert.ok(errorsOf(res).some((e) => /cycle/i.test(e)));
  });

  it('rejects a value that is not a rule object at all', async () => {
    for (const bad of [['a'], 'not a rule', 42]) {
      const res = await importJson(payloadWith([field({ field_key: 'pn', compute_rule: bad })]));
      assert.equal(res.status, 400, `expected ${JSON.stringify(bad)} to be rejected`);
      assert.equal(fieldInserts().length, 0);
    }
  });

  it('rejects an oversize rule and names the limit', async () => {
    const res = await importJson(payloadWith([
      field({
        field_key: 'pn',
        compute_rule: {
          op: 'concat', overridable: false, output_type: 'string',
          config: { parts: Array.from({ length: MAX_CONCAT_PARTS + 1 }, () => ({ type: 'literal', text: 'x' })) },
        },
      }),
    ]));
    assert.equal(res.status, 400);
    assert.ok(errorsOf(res).some((e) => e.includes(String(MAX_CONCAT_PARTS))));
  });

  it('rejects a value_source outside the vocabulary', async () => {
    const res = await importJson(payloadWith([field({ field_key: 'pn', value_source: 'yes' })]));
    assert.equal(res.status, 400);
    assert.ok(errorsOf(res).some((e) => /value_source/.test(e)));
    assert.equal(fieldInserts().length, 0);
  });

  it('rejects a mode the payload columns contradict', async () => {
    // The import is the write path that never came from the authoring UI, so it
    // is where a mode with no payload behind it would otherwise land.
    const res = await importJson(payloadWith([field({ field_key: 'pn', value_source: 'calculated' })]));
    assert.equal(res.status, 400);
    assert.ok(errorsOf(res).some((e) => /requires a compute_rule/.test(e)));
    assert.equal(fieldInserts().length, 0);
  });

  it('imports a sound rule, carrying both policy columns through', async () => {
    const res = await importJson(payloadWith([
      field({ field_key: 'model', value_source: 'locked' }),
      field({ field_key: 'pn', value_source: 'calculated', compute_rule: concat('model') }),
    ]));
    assert.equal(res.status, 200);
    const withRule = fieldInserts().find((i) => i.sql.includes('`compute_rule`'));
    assert.ok(withRule, 'the INSERT must still carry compute_rule');
    assert.ok(withRule.sql.includes('`value_source`'));
    // A JSON column must reach the driver as text; binding the object itself
    // persists "[object Object]".
    assert.ok(withRule.params.includes(JSON.stringify(concat('model'))),
      'compute_rule must be serialized before it is bound');
  });

  it('accepts a payload with no rules at all (unchanged behaviour)', async () => {
    const res = await importJson(payloadWith([field({ field_key: 'pn' })]));
    assert.equal(res.status, 200);
    assert.equal(fieldInserts().length, 1);
  });
});

// Validation runs before the transaction opens and outside the route's own
// try/catch, so a validator that throws instead of returning its rejection does
// not become a 500 — Express leaves the rejection unhandled and the process
// exits, turning one small authenticated request into a pod outage. Each payload
// below reads a property off an entry the uploader controls.
describe('JSON import — a malformed rule entry is answered, not fatal', () => {
  const malformed = [
    ['concat.parts', 'text', { op: 'concat', overridable: false, output_type: 'string', config: { parts: [null] } }],
    ['concat.parts holding a scalar', 'text', { op: 'concat', overridable: false, output_type: 'string', config: { parts: [42] } }],
    ['arith.operands', 'number', { op: 'arith', overridable: false, output_type: 'number', config: { operator: 'add', operands: [null] } }],
    ['lookup.table', 'text', { op: 'lookup', overridable: false, output_type: 'string', config: { source: 'model', table: [null] } }],
  ];

  for (const [label, fieldType, rule] of malformed) {
    it(`rejects ${label} with a structured 400 and writes nothing`, async () => {
      const res = await importJson(payloadWith([
        field({ field_key: 'model' }),
        field({ field_key: 'pn', field_type: fieldType, compute_rule: rule }),
      ]));
      assert.equal(res.status, 400);
      assert.ok(errorsOf(res).some((e) => /pn/.test(e) && /bad_config/.test(e)),
        `expected a per-field bad_config error, got ${JSON.stringify(errorsOf(res))}`);
      assert.equal(inserts.length, 0, 'nothing may be written for a rejected payload');
    });
  }

  it('answers a malformed table_config column entry instead of dying', async () => {
    // The field context is built from every field BEFORE any single rule is
    // judged, so a malformed column entry is read earlier than the rule guard
    // above and needs its own guarantee.
    const res = await importJson(payloadWith([
      field({ field_key: 'items', field_type: 'table', table_config: { columns: [null] } }),
    ]));
    assert.ok(res.status === 200 || res.status === 400, `expected an answer, got ${res.status}`);
  });

  it('answers a payload whose row is not an object', async () => {
    const res = await importJson(payloadWith([null]));
    assert.equal(res.status, 400);
    assert.equal(inserts.length, 0);
  });
});
