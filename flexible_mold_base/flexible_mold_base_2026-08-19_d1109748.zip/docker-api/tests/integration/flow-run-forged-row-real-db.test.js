'use strict';

/**
 * flow-run-forged-row-real-db.test.js — where a run row may come from, and what
 * trusting one costs when the answer is "anywhere".
 *
 * The finalize write-back does not re-ask who may reach the record it writes.
 * That is deliberate — a revocation must not erase the record of a dispatch that
 * already went out — and it is only sound because of one thing: a run row naming
 * a record exists ONLY because the gated dispatch path allowed it. This file is
 * the test of that premise, and it drives the real routers on a real database
 * because the premise is about which rows exist, which a stubbed driver answers
 * with whatever the fixture was told to say.
 *
 * BOTH ROUTERS ARE MOUNTED, and that is the point. The write-back lives on the
 * internal run router; the row-creating paths live on the app CRUD mount. A test
 * that mounted only one of them could not see the two of them compose, and it is
 * the composition that is the defect.
 *
 * THE TWO WAYS A ROW COULD NAME A RECORD NOBODY CHECKED:
 *   create — POST on the CRUD mount stamps the actor and takes the record
 *            reference from the body, so any authenticated caller could mint a
 *            row that names somebody else's record;
 *   retarget — PUT on the same mount matches the caller's own row and could
 *            move its record reference afterwards, which reaches the same place
 *            from a row the gate really did approve.
 * Closing one and not the other closes nothing.
 *
 * Skips with a stated reason when no database is reachable, and fails instead of
 * skipping when REQUIRE_INTEGRATION_DB=1.
 */
const { test, describe, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const net = require('node:net');
const http = require('node:http');
const express = require('express');
const mariadb = require('mariadb');

const TEST_PREFIX = 'ffr_';
const tbl = (name) => `${TEST_PREFIX}${name}`;

let pool = null;
const lease = () => pool.getConnection();

const dbKey = require.resolve('../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey,
  filename: dbKey,
  loaded: true,
  exports: {
    pool: { ro: { getConnection: lease }, rw: { getConnection: lease } },
    t: tbl,
    getDynamicPool: async () => ({ ro: { getConnection: lease }, rw: { getConnection: lease } }),
  },
};

const { buildEngineTableDDLs } = require('../../src/table-ddls');
const { TABLES } = require('../../src/shared/constants');
const { _resetGrantsTableCache } = require('../../src/edge/lib/delegated-grants');
const internalRouter = require('../../src/edge/routes/internal/flow-recipes-run');
const runsMount = require('../../src/edge/routes/app/flow-recipe-runs');

// ── Config auto-detection (same shape as the sibling integration tests) ──────

function parseEnvFile(filePath) {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    const out = {};
    for (const line of content.split('\n')) {
      const m = line.match(/^\s*([A-Z_][A-Z0-9_]*)\s*=\s*(.*)\s*$/);
      if (!m) continue;
      let value = m[2];
      if ((value.startsWith('"') && value.endsWith('"'))
        || (value.startsWith("'") && value.endsWith("'"))) {
        value = value.slice(1, -1);
      }
      out[m[1]] = value;
    }
    return out;
  } catch {
    return null;
  }
}

function probePort(host, port, timeoutMs = 2000) {
  return new Promise((resolve) => {
    const socket = new net.Socket();
    let done = false;
    const finish = (ok) => {
      if (done) return;
      done = true;
      socket.destroy();
      resolve(ok);
    };
    socket.setTimeout(timeoutMs);
    socket.once('connect', () => finish(true));
    socket.once('timeout', () => finish(false));
    socket.once('error', () => finish(false));
    socket.connect(port, host);
  });
}

async function resolveMariaDbConfig() {
  if (process.env.DB_TEST_HOST && process.env.DB_TEST_ROOT_PASSWORD) {
    return {
      host: process.env.DB_TEST_HOST,
      port: parseInt(process.env.DB_TEST_PORT || '3306', 10),
      user: 'root',
      password: process.env.DB_TEST_ROOT_PASSWORD,
    };
  }
  const envPath = path.resolve(__dirname, '../../../.devcontainer/.env');
  const env = parseEnvFile(envPath);
  if (!env || !env.DB_ROOT_PASSWORD) return null;
  const port = parseInt(env.DB_PORT || '3306', 10);
  for (const host of ['127.0.0.1', 'mariadb', 'localhost']) {
    if (await probePort(host, port, 2000)) {
      return { host, port, user: 'root', password: env.DB_ROOT_PASSWORD };
    }
  }
  return null;
}

// ── Fixture ─────────────────────────────────────────────────────────────────

const OWNER = 'u-owner';
const ATTACKER = 'u-attacker';
const BP1 = 'bp-1';
const T1 = 'tpl-1';
const RECIPE = 'r-1';

const FORGED_EXTERNAL_ID = 'ATTACKER-CHOSEN-ID';
const FORGED_LINK = 'https://attacker.invalid/whatever';

let dbReady = false;
let skipReason = null;
let testDbName = null;
let server = null;
let baseUrl = null;
let currentUser = { id: OWNER, role: 'user' };

function ddlFor(...tables) {
  const wanted = new Set(tables.map((n) => tbl(n)));
  return buildEngineTableDDLs(tbl).filter((sql) => {
    const m = sql.match(/CREATE TABLE IF NOT EXISTS `([^`]+)`/);
    return m && wanted.has(m[1]);
  });
}

before(async () => {
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) {
    skipReason = 'no MariaDB reachable via .devcontainer/.env or env vars';
    if (process.env.REQUIRE_INTEGRATION_DB === '1') {
      throw new Error(`REQUIRE_INTEGRATION_DB=1 set but ${skipReason}.`);
    }
    return;
  }
  testDbName = `flow_forged_test_${process.pid}_${Date.now()}`;
  let admin = null;
  try {
    admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`CREATE DATABASE \`${testDbName}\``);
    await admin.query(`USE \`${testDbName}\``);
    const statements = ddlFor(
      TABLES.HIERARCHY_NODES, TABLES.USER_TEMPLATES, TABLES.DELEGATED_GRANTS,
      TABLES.FLOW_RECIPES, TABLES.FLOW_RECIPE_STEPS, TABLES.FLOW_RECIPE_RUNS,
      TABLES.TEMPLATE_ACTIVITY,
    );
    assert.equal(statements.length, 7, 'the DDL list no longer defines all seven tables');
    for (const sql of statements) await admin.query(sql);

    await admin.query(
      `INSERT INTO \`${tbl('hierarchy_nodes')}\` (id, name, node_type, owner_id) VALUES (?, 'BP1', 'blueprint', ?)`,
      [BP1, OWNER],
    );
    await admin.query(
      `INSERT INTO \`${tbl('user_templates')}\` (id, name, blueprint_id, owner_id) VALUES (?, 'one', ?, ?)`,
      [T1, BP1, OWNER],
    );
    await admin.query(
      `INSERT INTO \`${tbl('flow_recipes')}\`
         (id, name, is_active, blueprint_id, content_type, link_extract, external_id_extract, runs_on, status)
       VALUES (?, 'recipe', 1, ?, 'application/json', ?, ?, 'both', 'approved')`,
      [RECIPE, BP1, JSON.stringify({ path: 'url' }), JSON.stringify({ path: 'id' })],
    );
    await admin.query(
      `INSERT INTO \`${tbl('flow_recipe_steps')}\` (id, recipe_id, \`sequence\`, name, method, url)
       VALUES ('s-1', ?, 1, 'step one', 'POST', 'https://upstream.invalid/create')`,
      [RECIPE],
    );
    await admin.end();
    admin = null;

    pool = mariadb.createPool({
      ...dbConfig, database: testDbName, connectionLimit: 4, connectTimeout: 5000,
    });
    _resetGrantsTableCache();

    const app = express();
    app.use(express.json());
    app.use((req, _res, next) => { req.user = currentUser; next(); });
    app.use('/edge/internal/flow-recipes', internalRouter);
    app.use('/edge/app/flow-recipe-runs', runsMount);
    server = http.createServer(app);
    await new Promise((r) => server.listen(0, r));
    baseUrl = `http://127.0.0.1:${server.address().port}`;
    dbReady = true;
  } catch (err) {
    skipReason = `setup failed: ${err.message}`;
    if (admin) { try { await admin.end(); } catch { /* best effort */ } }
    if (process.env.REQUIRE_INTEGRATION_DB === '1') throw err;
  }
});

after(async () => {
  if (server) { try { server.close(); } catch { /* best effort */ } }
  if (pool) { try { await pool.end(); } catch { /* best effort */ } }
  if (!testDbName) return;
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) return;
  try {
    const admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`DROP DATABASE IF EXISTS \`${testDbName}\``);
    await admin.end();
  } catch { /* best effort */ }
});

// ── Driving the real routes ─────────────────────────────────────────────────

async function send(method, pathname, body, user) {
  currentUser = user;
  const res = await fetch(`${baseUrl}${pathname}`, {
    method,
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
  });
  const text = await res.text();
  let parsed = null;
  try { parsed = JSON.parse(text); } catch { parsed = { raw: text }; }
  return { status: res.status, body: parsed };
}

const RUNS = '/edge/app/flow-recipe-runs';
const INTERNAL = '/edge/internal/flow-recipes';

/** The generic create on the run mount — the path this file is about. */
const createRunRow = (user, over = {}) => send('POST', `${RUNS}/`, {
  recipe_id: RECIPE,
  template_id: T1,
  blueprint_id: BP1,
  status: 'partial',
  mode: 'create',
  ...over,
}, user);

const updateRunRow = (user, runId, body) => send('PUT', `${RUNS}/${runId}`, body, user);

const begin = (user, over = {}) => send('POST', `${INTERNAL}/run-begin`, {
  recipe_id: RECIPE, payload: { a: 1 }, template_id: T1, ...over,
}, user);

const finalize = (user, runId) => send('POST', `${INTERNAL}/run-finalize`, {
  run_id: runId,
  recipe_id: RECIPE,
  ok: true,
  upstream_status: 200,
  body: JSON.stringify({ url: FORGED_LINK, id: FORGED_EXTERNAL_ID }),
}, user);

async function templateRow() {
  const rows = await pool.query(
    `SELECT owner_id, flow_external_id, flow_link, flow_last_run_id
       FROM \`${tbl('user_templates')}\` WHERE id = ?`, [T1],
  );
  return rows[0];
}

async function runRow(id) {
  const rows = await pool.query(
    `SELECT id, actor_id, template_id, status FROM \`${tbl('flow_recipe_runs')}\` WHERE id = ?`, [id],
  );
  return rows[0] || null;
}

async function runCount() {
  const rows = await pool.query(`SELECT COUNT(*) AS n FROM \`${tbl('flow_recipe_runs')}\``);
  return Number(rows[0].n);
}

const guard = (t) => {
  if (!dbReady) { t.skip(skipReason || 'database not ready'); return true; }
  return false;
};

beforeEach(async () => {
  if (!dbReady) return;
  await pool.query(`DELETE FROM \`${tbl('delegated_grants')}\``);
  await pool.query(`DELETE FROM \`${tbl('flow_recipe_runs')}\``);
  await pool.query(`DELETE FROM \`${tbl('template_activity')}\``);
  await pool.query(
    `UPDATE \`${tbl('user_templates')}\`
        SET owner_id = ?, flow_external_id = NULL, flow_link = NULL, flow_last_run_id = NULL
      WHERE id = ?`,
    [OWNER, T1],
  );
  await pool.query(
    `UPDATE \`${tbl('hierarchy_nodes')}\` SET owner_id = ? WHERE id = ?`, [OWNER, BP1],
  );
});

describe('a run row may name a record only because the dispatch gate allowed it', () => {
  test('a stranger cannot mint a run naming somebody else\'s record', async (t) => {
    if (guard(t)) return;
    // THE DEFECT, at its source. The generic create on this mount stamps the
    // actor from the session and takes the record reference from the body, so
    // the row it writes satisfies every binding finalize checks while standing
    // for a permission nobody ever asked about.
    const created = await createRunRow({ id: ATTACKER, role: 'user' });

    assert.notEqual(
      created.status, 200,
      `a run row naming another user's record was created: ${JSON.stringify(created.body)}`,
    );
    assert.equal(await runCount(), 0, 'a refused create left a run row behind');
  });

  test('and so cannot drive the write-back onto that record', async (t) => {
    if (guard(t)) return;
    // The consequence, end to end, through the real finalize route. A record
    // that reads as pushed against an id of the attacker's choosing turns its
    // owner's next dispatch into an update aimed at it, and the link is what the
    // record displays.
    const created = await createRunRow({ id: ATTACKER, role: 'user' });
    const runId = created.status === 200 ? created.body.data.id : null;

    if (runId) {
      // Only reachable while the create path is open. Kept so the failure this
      // test reports is the write itself, not merely a status code.
      const ended = await finalize({ id: ATTACKER, role: 'user' }, runId);
      assert.equal(ended.status, 200, `finalize: ${JSON.stringify(ended.body)}`);
    }

    const row = await templateRow();
    assert.equal(row.flow_external_id, null, 'a stranger set the record\'s external id');
    assert.equal(row.flow_link, null, 'a stranger set the link the record displays');
    assert.equal(row.flow_last_run_id, null, 'a stranger made the record read as pushed');
  });

  test('and refused at the path the proxy actually forwards', async (t) => {
    if (guard(t)) return;
    // The infra proxy builds the edge path as `<mount> + (req.path === '/' ? ''
    // : req.path)`, so a browser POST arrives here with NO trailing slash. A
    // refusal that only covered the spelling this file happens to use would be a
    // refusal of nothing.
    const created = await send('POST', RUNS, {
      recipe_id: RECIPE, template_id: T1, status: 'partial',
    }, { id: ATTACKER, role: 'user' });
    assert.equal(created.status, 405, `expected a refusal, got ${JSON.stringify(created.body)}`);
    assert.equal(await runCount(), 0);
  });

  test('an owner posting there is refused too — the path is closed, not scoped', async (t) => {
    if (guard(t)) return;
    // The rule is about where a row comes from, not about who is asking. An
    // owner has a route that creates runs and it is the gated one; a second
    // source that happens to be safe for one caller is a second source.
    const created = await createRunRow({ id: OWNER, role: 'user' });
    assert.notEqual(created.status, 200, 'the create path is still open');
    assert.equal(await runCount(), 0);
  });

  test('an administrator posting there is refused too', async (t) => {
    if (guard(t)) return;
    // Admin write-scope skips the actor stamp on this mount, so an open create
    // route is at its most permissive exactly here.
    const created = await createRunRow({ id: 'u-admin', role: 'admin' }, { actor_id: ATTACKER });
    assert.notEqual(created.status, 200, 'the create path is still open to an administrator');
    assert.equal(await runCount(), 0);
  });

  test('a run the gate did approve cannot be retargeted at another record', async (t) => {
    if (guard(t)) return;
    // THE SIBLING. Closing the create path alone leaves this one: begin a run
    // the gate allows — one naming no record at all needs no permission — then
    // move its record reference with the generic update, which matches the
    // caller's own row by design. Same write-back, same consequence, from a row
    // that really was minted by the gated path.
    const began = await begin({ id: ATTACKER, role: 'user' }, { template_id: undefined });
    assert.equal(began.status, 200, `run-begin: ${JSON.stringify(began.body)}`);
    const runId = began.body.data.run_id;
    assert.equal((await runRow(runId)).template_id, null, 'the fixture run already names a record');

    const moved = await updateRunRow({ id: ATTACKER, role: 'user' }, runId, { template_id: T1 });
    // The update itself may legitimately answer 200 — what must not happen is
    // the column moving. Asserting the stored value rather than the status is
    // what makes this independent of how the refusal is spelled.
    assert.equal(
      (await runRow(runId)).template_id, null,
      `the run was retargeted at another user's record (PUT ${moved.status})`,
    );

    const ended = await finalize({ id: ATTACKER, role: 'user' }, runId);
    assert.equal(ended.status, 200, `finalize: ${JSON.stringify(ended.body)}`);

    const row = await templateRow();
    assert.equal(row.flow_last_run_id, null, 'a retargeted run reached the write-back');
    assert.equal(row.flow_external_id, null);
    assert.equal(row.flow_link, null);
  });

  test('and cannot be retargeted by spelling the column with a capital either', async (t) => {
    if (guard(t)) return;
    // THE SAME ACT, ONE LETTER DIFFERENT. A column identifier is case-insensitive
    // to this database, so `Template_Id` IS the column `template_id` — while the
    // strip that refuses the retarget is `delete data['template_id']` and never
    // sees the cased key. The case above passes on the spelling it happens to
    // use; this is the property it claims, driven end to end on the same
    // fixture, through the write-back that is the consequence.
    const began = await begin({ id: ATTACKER, role: 'user' }, { template_id: undefined });
    assert.equal(began.status, 200, `run-begin: ${JSON.stringify(began.body)}`);
    const runId = began.body.data.run_id;
    assert.equal((await runRow(runId)).template_id, null, 'the fixture run already names a record');

    const moved = await updateRunRow({ id: ATTACKER, role: 'user' }, runId, { Template_Id: T1 });
    assert.equal(
      (await runRow(runId)).template_id, null,
      `the run was retargeted at another user's record (PUT ${moved.status})`,
    );

    const ended = await finalize({ id: ATTACKER, role: 'user' }, runId);
    assert.equal(ended.status, 200, `finalize: ${JSON.stringify(ended.body)}`);

    const row = await templateRow();
    assert.equal(row.flow_last_run_id, null, 'a retargeted run reached the write-back');
    assert.equal(row.flow_external_id, null);
    assert.equal(row.flow_link, null);
  });

  test('a cased spelling does not carry a credential past the masking either', async (t) => {
    if (guard(t)) return;
    // The other half of what the cased key reached around: the mount's write
    // serializer is keyed on the canonical name too, so a secret arriving under
    // any other spelling is stored on a durable row that every administrator
    // reads, exactly as it was sent.
    const began = await begin({ id: OWNER, role: 'user' });
    assert.equal(began.status, 200, `run-begin: ${JSON.stringify(began.body)}`);
    const runId = began.body.data.run_id;

    const put = await updateRunRow({ id: OWNER, role: 'user' }, runId, {
      Step_Results: JSON.stringify({ headers: { authorization: 'Bearer REAL-SECRET' } }),
    });

    const rows = await pool.query(
      `SELECT step_results FROM \`${tbl('flow_recipe_runs')}\` WHERE id = ?`, [runId],
    );
    // THE STORED ROW IS ASSERTED FIRST, and the order is the point. `step_results`
    // is a JSON column and the driver hands it back ALREADY PARSED, so
    // `String(row)` is '[object Object]' — a search for a substring of it can
    // never find anything, whatever is stored. Stringifying the structure is what
    // makes this assertion capable of failing; written the other way it reported
    // green while the row held the bearer token verbatim.
    //
    // Put BELOW the status assertion, it was capable of failing and still never
    // ran: any regression that lets the credential land also makes the PUT answer
    // 200, so the status line fired first and this one was never reached. What a
    // credential must not do is be READABLE ON THE ROW — true whether the write
    // is refused or accepted-and-masked — so that is asserted before the narrower
    // claim about how it is currently refused.
    assert.equal(
      JSON.stringify(rows[0].step_results ?? '').includes('REAL-SECRET'), false,
      `a credential was stored unmasked (PUT ${put.status})`,
    );
    assert.equal(put.status, 400, `the cased key was accepted (${JSON.stringify(put.body)})`);
  });

  test('a credential sent under the canonical key is masked on the row that keeps it', async (t) => {
    if (guard(t)) return;
    // THE MASKING PROPERTY, WITH A WITNESS OF ITS OWN. The case above sends a
    // spelling the mount refuses, so under an intact refusal no row can hold the
    // token and its masking assertion is satisfied by something other than
    // masking. This one sends the column's OWN name, in its own case, from the
    // run's own actor — an update that is SUPPOSED to succeed. The only thing
    // standing between the credential and a durable row every administrator reads
    // is the serializer, so if it stops redacting, this goes red on its own,
    // whatever the refusal above is doing.
    const began = await begin({ id: OWNER, role: 'user' });
    assert.equal(began.status, 200, `run-begin: ${JSON.stringify(began.body)}`);
    const runId = began.body.data.run_id;

    const put = await updateRunRow({ id: OWNER, role: 'user' }, runId, {
      step_results: JSON.stringify({
        headers: { authorization: 'Bearer REAL-SECRET' },
        note: 'A-KEPT-VALUE',
      }),
    });
    assert.equal(put.status, 200, `a legitimate update was refused: ${JSON.stringify(put.body)}`);

    const rows = await pool.query(
      `SELECT step_results FROM \`${tbl('flow_recipe_runs')}\` WHERE id = ?`, [runId],
    );
    const stored = JSON.stringify(rows[0].step_results ?? '');
    // The document really did land — otherwise "no credential in the row" would
    // be true of an empty column, and this test would be reporting on a write
    // that never happened rather than on the masking of one that did.
    assert.equal(stored.includes('A-KEPT-VALUE'), true, `the update did not land: ${stored}`);
    assert.equal(stored.includes('REAL-SECRET'), false, `a credential was stored unmasked: ${stored}`);
  });

  test('a finished run cannot be re-armed and fired at the record again', async (t) => {
    if (guard(t)) return;
    // THE SECOND SIBLING, and the one that survives closing both paths above.
    // Finalize refuses a run that already reached a terminal state — that is its
    // replay guard, and it is what makes the write-back the record of ONE
    // completed dispatch. The generic update can write the run's status, so the
    // guard can be disarmed from outside and the same row fired again, with
    // values chosen at the later moment, by an actor whose access may be long
    // gone. The run row stops being the record of an act and becomes a standing
    // permission to write that record.
    await pool.query(
      `INSERT INTO \`${tbl('delegated_grants')}\` (id, scope_type, scope_id, grantee_id, granted_by)
       VALUES ('g-1', 'template', ?, ?, ?)`,
      [T1, ATTACKER, OWNER],
    );
    const began = await begin({ id: ATTACKER, role: 'user' });
    assert.equal(began.status, 200, `run-begin: ${JSON.stringify(began.body)}`);
    const runId = began.body.data.run_id;
    assert.equal((await finalize({ id: ATTACKER, role: 'user' }, runId)).status, 200);
    const recorded = await templateRow();
    assert.equal(recorded.flow_external_id, FORGED_EXTERNAL_ID, 'the fixture dispatch did not record');

    // Access is withdrawn. The dispatch that already happened stays recorded —
    // that is the rule this branch established — but nothing further may write.
    await pool.query(`DELETE FROM \`${tbl('delegated_grants')}\``);

    const rearmed = await updateRunRow({ id: ATTACKER, role: 'user' }, runId, { status: 'partial' });
    const after = await runRow(runId);
    assert.equal(
      after.status, 'success',
      `a finished run was re-armed through the generic update (PUT ${rearmed.status})`,
    );

    const again = await send('POST', `${INTERNAL}/run-finalize`, {
      run_id: runId,
      recipe_id: RECIPE,
      ok: true,
      upstream_status: 200,
      body: JSON.stringify({ url: 'https://attacker.invalid/second', id: 'SECOND-ID' }),
    }, { id: ATTACKER, role: 'user' });
    assert.equal(again.status, 409, `a finished run finalized twice: ${JSON.stringify(again.body)}`);

    const row = await templateRow();
    assert.equal(row.flow_external_id, FORGED_EXTERNAL_ID, 'the record was rewritten after access ended');
    assert.equal(row.flow_link, FORGED_LINK);
  });

  test('an owner\'s own run still records itself — the gated path is untouched', async (t) => {
    if (guard(t)) return;
    // The control. A fix that refused more often would satisfy every case above
    // and remove the feature, so the one path that must keep working is asserted
    // end to end on the same fixture.
    const began = await begin({ id: OWNER, role: 'user' });
    assert.equal(began.status, 200, `run-begin: ${JSON.stringify(began.body)}`);
    const ended = await finalize({ id: OWNER, role: 'user' }, began.body.data.run_id);
    assert.equal(ended.status, 200, `run-finalize: ${JSON.stringify(ended.body)}`);

    const row = await templateRow();
    assert.equal(row.flow_last_run_id, began.body.data.run_id);
    assert.equal(row.flow_external_id, FORGED_EXTERNAL_ID);
    assert.equal(row.flow_link, FORGED_LINK);
  });

  test('the run mount still reads, and still updates what it may', async (t) => {
    if (guard(t)) return;
    // The rest of the mount is not collateral. A reader still reads the run, and
    // the update path still writes the columns it was always allowed to write —
    // otherwise "the create path is closed" would be indistinguishable from "the
    // mount is broken".
    const began = await begin({ id: OWNER, role: 'user' });
    assert.equal(began.status, 200);
    const runId = began.body.data.run_id;

    const read = await send('GET', `${RUNS}/${runId}`, undefined, { id: OWNER, role: 'user' });
    assert.equal(read.status, 200, `GET: ${JSON.stringify(read.body)}`);
    assert.equal(read.body.data.id, runId);

    const edited = await updateRunRow({ id: OWNER, role: 'user' }, runId, { error_summary: 'noted' });
    assert.equal(edited.status, 200, `PUT: ${JSON.stringify(edited.body)}`);
    const rows = await pool.query(
      `SELECT error_summary FROM \`${tbl('flow_recipe_runs')}\` WHERE id = ?`, [runId],
    );
    assert.equal(rows[0].error_summary, 'noted', 'a legitimate update no longer lands');
  });
});
