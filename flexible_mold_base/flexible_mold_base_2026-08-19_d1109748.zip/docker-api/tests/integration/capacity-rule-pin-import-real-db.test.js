'use strict';

/**
 * capacity-rule-pin-import-real-db.test.js — the keep-in-one-site pin
 * (cap_rules.params.site_id) on the paths the write-side guard does not cover:
 * the scenario import (io.js) and the global-config import (config-import.js),
 * plus the type-strict validation of the pin value itself.
 *
 * WHY A REAL DATABASE. The claim is about the BYTES cap_rules.params holds after
 * a statement committed — a scenario import re-mints every site under a fresh
 * uuid, so whether the stored pin names the NEW site or the dead source id is
 * the engine's answer to the INSERT this path builds, not a fixture's. A stubbed
 * driver returns whatever it was told, which is exactly how a remap that never
 * ran and a fixture that hard-codes the right id stay green together.
 *
 * Skips with a stated reason when no database is reachable, and fails instead of
 * skipping when REQUIRE_INTEGRATION_DB=1.
 */
const {
  test, describe, before, after, beforeEach,
} = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const net = require('node:net');
const http = require('node:http');
const express = require('express');
const mariadb = require('mariadb');

const TEST_PREFIX = 'crp_';
const tbl = (name) => `${TEST_PREFIX}${name}`;

let pool = null;
const lease = () => pool.getConnection();
const handle = () => ({ getConnection: lease, query: (sql, params) => pool.query(sql, params) });

const dbKey = require.resolve('../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey,
  filename: dbKey,
  loaded: true,
  exports: {
    pool: { ro: handle(), rw: handle() },
    t: tbl,
    getDynamicPool: async () => ({ ro: handle(), rw: handle() }),
  },
};

const { buildEngineTableDDLs, buildInfraTableDDLs } = require('../../src/table-ddls');
const capacityRouter = require('../../src/edge/routes/app/capacity');

// ── Config auto-detection (same shape as the sibling integration tests) ──────

function parseEnvFile(filePath) {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    const out = {};
    for (const line of content.split('\n')) {
      const m = line.match(/^\s*([A-Z_][A-Z0-9_]*)\s*=\s*(.*)\s*$/);
      if (!m) continue;
      let value = m[2];
      if ((value.startsWith('"') && value.endsWith('"'))
        || (value.startsWith("'") && value.endsWith("'"))) {
        value = value.slice(1, -1);
      }
      out[m[1]] = value;
    }
    return out;
  } catch {
    return null;
  }
}

function probePort(host, port, timeoutMs = 2000) {
  return new Promise((resolve) => {
    const socket = new net.Socket();
    let done = false;
    const finish = (ok) => {
      if (done) return;
      done = true;
      socket.destroy();
      resolve(ok);
    };
    socket.setTimeout(timeoutMs);
    socket.once('connect', () => finish(true));
    socket.once('timeout', () => finish(false));
    socket.once('error', () => finish(false));
    socket.connect(port, host);
  });
}

async function resolveMariaDbConfig() {
  if (process.env.DB_TEST_HOST && process.env.DB_TEST_ROOT_PASSWORD) {
    return {
      host: process.env.DB_TEST_HOST,
      port: parseInt(process.env.DB_TEST_PORT || '3306', 10),
      user: 'root',
      password: process.env.DB_TEST_ROOT_PASSWORD,
    };
  }
  const envPath = path.resolve(__dirname, '../../../.devcontainer/.env');
  const env = parseEnvFile(envPath);
  if (!env || !env.DB_ROOT_PASSWORD) return null;
  const port = parseInt(env.DB_PORT || '3306', 10);
  for (const host of ['127.0.0.1', 'mariadb', 'localhost']) {
    if (await probePort(host, port, 2000)) {
      return { host, port, user: 'root', password: env.DB_ROOT_PASSWORD };
    }
  }
  return null;
}

// ── Fixture ─────────────────────────────────────────────────────────────────

const ADMIN_ID = 'aa11bb22-cc33-4d44-8e55-ff6677889900';
const ADMIN = { id: ADMIN_ID, role: 'admin' };
const SCENARIO_ID = '11112222-3333-4444-8555-666677778888';
// A well-formed uuid that never names a row this test creates — the source-side
// site id an exported pin carries, and the "site not in this import" pin target.
const SOURCE_SITE_ID = 'aaaaaaaa-bbbb-4ccc-8ddd-eeeeeeeeeeee';
const ABSENT_SITE_ID = 'ffffffff-1111-4222-8333-444444444444';

let dbReady = false;
let skipReason = null;
let testDbName = null;
let server = null;
let baseUrl = null;
let currentUser = ADMIN;

before(async () => {
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) {
    skipReason = 'no MariaDB reachable via .devcontainer/.env or env vars';
    if (process.env.REQUIRE_INTEGRATION_DB === '1') {
      throw new Error(`REQUIRE_INTEGRATION_DB=1 set but ${skipReason}.`);
    }
    return;
  }
  testDbName = `cap_rule_pin_import_test_${process.pid}_${Date.now()}`;
  let admin = null;
  try {
    admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`CREATE DATABASE \`${testDbName}\``);
    await admin.query(`USE \`${testDbName}\``);
    for (const sql of [...buildInfraTableDDLs(tbl), ...buildEngineTableDDLs(tbl)]) {
      await admin.query(sql);
    }
    await admin.end();
    admin = null;

    pool = mariadb.createPool({
      ...dbConfig, database: testDbName, connectionLimit: 6, connectTimeout: 5000,
    });

    const app = express();
    app.use(express.json());
    app.use((req, _res, next) => { req.user = currentUser; next(); });
    app.use('/edge/app/capacity', capacityRouter);
    server = http.createServer(app);
    await new Promise((r) => server.listen(0, r));
    baseUrl = `http://127.0.0.1:${server.address().port}`;
    dbReady = true;
  } catch (err) {
    skipReason = `setup failed: ${err.message}`;
    if (admin) { try { await admin.end(); } catch { /* best effort */ } }
    if (process.env.REQUIRE_INTEGRATION_DB === '1') throw err;
  }
});

after(async () => {
  if (server) { try { server.close(); } catch { /* best effort */ } }
  if (pool) { try { await pool.end(); } catch { /* best effort */ } }
  if (!testDbName) return;
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) return;
  try {
    const admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`DROP DATABASE IF EXISTS \`${testDbName}\``);
    await admin.end();
  } catch { /* best effort */ }
});

async function call(user, method, url, body) {
  currentUser = user;
  const res = await fetch(`${baseUrl}${url}`, {
    method,
    headers: { 'content-type': 'application/json' },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const text = await res.text();
  let parsed = null;
  try { parsed = JSON.parse(text); } catch { parsed = { raw: text }; }
  return { status: res.status, body: parsed };
}

const q = (sql, params) => pool.query(sql, params);
const one = async (sql, params) => (await pool.query(sql, params))[0];

const CAPACITY_TABLES = [
  'cap_waivers', 'cap_rules', 'cap_custom_group_members', 'cap_custom_groups',
  'cap_db_instances', 'cap_vms', 'cap_databases', 'cap_hypervisors', 'cap_sites',
  'cap_versions', 'cap_bundle_items', 'cap_bundles', 'cap_field_defs',
  'cap_vm_profiles', 'cap_disk_combos', 'cap_teams', 'cap_hardware_specs',
  'cap_settings', 'cap_scenarios',
];

const guard = (t) => {
  if (dbReady) return false;
  t.skip(skipReason || 'database not ready');
  return true;
};

const rowCount = async (table, where, params) => Number(
  (await one(`SELECT COUNT(*) AS n FROM \`${tbl(table)}\` ${where}`, params)).n,
);

// The mariadb driver returns a JSON column as a string here; parse either shape.
const asObject = (v) => (typeof v === 'string' ? JSON.parse(v) : v);

beforeEach(async () => {
  if (!dbReady) return;
  for (const name of [...CAPACITY_TABLES, 'feature_audit', 'users']) {
    await q(`DELETE FROM \`${tbl(name)}\``);
  }
  await q(
    `INSERT INTO \`${tbl('users')}\` (id, email, role, banned) VALUES (?,?,?,0)`,
    [ADMIN_ID, 'admin@test.local', 'admin'],
  );
  await q(
    `INSERT INTO \`${tbl('cap_scenarios')}\` (id, name, owner_id) VALUES (?,?,?)`,
    [SCENARIO_ID, 'a scenario', null],
  );
});

const base = `/edge/app/capacity/scenarios/${SCENARIO_ID}`;

/** The workbook the browser xlsx transform produces (xlsx-io.ts): every row
 *  carries a `ref` = its source id, and `params` is emitted verbatim so the pin
 *  still names the SOURCE site id. */
const pinSheets = (pinSiteId, { siteRef = SOURCE_SITE_ID } = {}) => ({
  sites: [{ ref: siteRef, name: 'DC-A' }],
  rules: [{
    ref: 'rule-ref-1',
    name: 'PIN',
    type: 'keep-in-one-site',
    level: 'db_instance',
    group_by: 'each_primary_cluster',
    severity: 'hard',
    enabled: true,
    params: { site_id: pinSiteId },
  }],
});

// ── P1: scenario import (io.js) remaps the pin to the re-minted site ─────────

describe('P1 scenario import: a keep-in-one-site pin is remapped to the re-minted site', () => {
  test('the stored pin equals the NEW site id, not the dead source id', async (t) => {
    if (guard(t)) return;
    // The pin in the workbook names SOURCE_SITE_ID; the sites sheet carries that
    // same id as its `ref`. Import mints a fresh uuid for the site, so a pin left
    // verbatim would name a site that no longer exists.
    const res = await call(ADMIN, 'POST', `${base}/import`, {
      mode: 'commit',
      sheets: pinSheets(SOURCE_SITE_ID),
    });
    assert.equal(res.status, 200, JSON.stringify(res.body));

    const site = await one(`SELECT id FROM \`${tbl('cap_sites')}\` WHERE scenario_id = ?`, [SCENARIO_ID]);
    const rule = await one(`SELECT params FROM \`${tbl('cap_rules')}\` WHERE scenario_id = ?`, [SCENARIO_ID]);
    const storedPin = asObject(rule.params).site_id;

    // Re-mint happened: the site does not keep its source id.
    assert.notEqual(site.id, SOURCE_SITE_ID, 'the imported site kept the source id — no re-mint, test is inert');
    // The stored pin is BYTE-EQUAL to the new site id — the value the delete
    // sweep and the evaluator both read. REVERT PROBE: remove the params.site_id
    // remap block in io.js buildImportPlan and this assertion goes red on the
    // stored value (storedPin stays === SOURCE_SITE_ID, a dangling pin).
    assert.equal(storedPin, site.id, 'the pin was not remapped to the re-minted site id');
  });

  test('a pin to a site absent from the import is CLEARED, with a notice', async (t) => {
    if (guard(t)) return;
    // The rule pins ABSENT_SITE_ID; the sites sheet carries only SOURCE_SITE_ID,
    // so the pin resolves to nothing. The dc_refs convention: drop it (clear to
    // the empty "any single site") and report it, rather than store a dead pin.
    const res = await call(ADMIN, 'POST', `${base}/import`, {
      mode: 'commit',
      sheets: pinSheets(ABSENT_SITE_ID),
    });
    assert.equal(res.status, 200, JSON.stringify(res.body));

    const rule = await one(`SELECT params FROM \`${tbl('cap_rules')}\` WHERE scenario_id = ?`, [SCENARIO_ID]);
    const storedPin = asObject(rule.params).site_id;
    assert.equal(storedPin, '', 'a dangling pin was stored dead instead of cleared');

    const dropped = (res.body.notices || []).find(
      (n) => n.code === 'DROPPED_STALE_REFERENCE' && n.sheet === 'rules',
    );
    assert.ok(dropped, `no DROPPED_STALE_REFERENCE notice: ${JSON.stringify(res.body.notices)}`);
  });

  test('validate mode reports the cleared pin without writing', async (t) => {
    if (guard(t)) return;
    const res = await call(ADMIN, 'POST', `${base}/import`, {
      mode: 'validate',
      sheets: pinSheets(ABSENT_SITE_ID),
    });
    assert.equal(res.status, 200, JSON.stringify(res.body));
    assert.ok((res.body.notices || []).some((n) => n.code === 'DROPPED_STALE_REFERENCE'));
    // Nothing was written on a dry run.
    assert.equal(await rowCount('cap_rules', 'WHERE scenario_id = ?', [SCENARIO_ID]), 0);
  });
});

// ── P1: config import (config-import.js) rejects a global site pin ───────────

describe('P1 config import: a global template rule cannot pin a specific site', () => {
  const globalRuleSheet = (siteId) => ({
    tables: {
      rules: [{
        ref: 'grule-1',
        name: 'GLOBAL-PIN',
        type: 'keep-in-one-site',
        level: 'db_instance',
        group_by: 'each_primary_cluster',
        severity: 'hard',
        enabled: true,
        params: { site_id: siteId },
      }],
    },
    schema_rev: 0,
  });

  test('a specific-site pin is refused (INVALID_GLOBAL_RULE)', async (t) => {
    if (guard(t)) return;
    // config import writes the GLOBAL layer (scenario_id IS NULL). A specific-site
    // pin has no coherent global meaning — sites are scenario-scoped.
    const res = await call(ADMIN, 'POST', '/edge/app/capacity/config/import/validate',
      globalRuleSheet(SOURCE_SITE_ID));
    assert.equal(res.status, 200, JSON.stringify(res.body));
    const report = res.body.data;
    assert.equal(report.ok, false, 'a global specific-site pin was accepted');
    // REVERT PROBE: remove the validateGlobalRuleWritePayload call in
    // config-import.js and report.ok flips to true (the pin passes).
    const bad = (report.issues || []).find((i) => i.code === 'INVALID_GLOBAL_RULE');
    assert.ok(bad, `no INVALID_GLOBAL_RULE issue: ${JSON.stringify(report.issues)}`);
  });

  test('an empty-string pin ("any single site") is accepted', async (t) => {
    if (guard(t)) return;
    // Empty site_id pins nothing; it is the legal global default, not a rejection.
    const res = await call(ADMIN, 'POST', '/edge/app/capacity/config/import/validate',
      globalRuleSheet(''));
    assert.equal(res.status, 200, JSON.stringify(res.body));
    const report = res.body.data;
    const globalRuleErr = (report.issues || []).find((i) => i.code === 'INVALID_GLOBAL_RULE');
    assert.equal(globalRuleErr, undefined, 'an empty-string pin was wrongly rejected as a global pin');
  });
});

// ── P2: a non-string params.site_id is refused at the write boundary ─────────

describe('P2 direct rule write: params.site_id must be a string', () => {
  const postPin = (siteId) => call(ADMIN, 'POST', `${base}/rules`, {
    type: 'keep-in-one-site',
    name: 'PIN',
    level: 'db_instance',
    group_by: 'each_primary_cluster',
    severity: 'hard',
    params: { site_id: siteId },
  });

  for (const [label, value] of [['0 (number)', 0], ['false (boolean)', false], ['{} (object)', {}]]) {
    test(`params.site_id = ${label} is refused (400) and nothing is written`, async (t) => {
      if (guard(t)) return;
      // rulePinnedSiteId returns null for each of these (typeof !== 'string'), so
      // the pin write-guard never probed a site and the row would have landed —
      // then the evaluator String()-coerces it into an unsatisfiable pin. REVERT
      // PROBE: remove the INVALID_SITE_PIN check in validateRuleWritePayload and
      // the POST returns 200, leaving a row (rowCount 1) the delete sweep can
      // never see.
      const res = await postPin(value);
      assert.equal(res.status, 400, JSON.stringify(res.body));
      assert.equal(res.body.error.code, 'INVALID_SITE_PIN', JSON.stringify(res.body));
      assert.equal(await rowCount('cap_rules', 'WHERE scenario_id = ?', [SCENARIO_ID]), 0,
        'a non-string pin was stored — the evaluator would read an unsatisfiable pin');
    });
  }

  test('params.site_id = "" ("any single site") is accepted and stored', async (t) => {
    if (guard(t)) return;
    // Empty string is the legal "no pin" value; it must survive the new check.
    const res = await postPin('');
    assert.equal(res.status, 200, JSON.stringify(res.body));
    assert.equal(await rowCount('cap_rules', 'WHERE scenario_id = ?', [SCENARIO_ID]), 1);
    const rule = await one(`SELECT params FROM \`${tbl('cap_rules')}\` WHERE scenario_id = ?`, [SCENARIO_ID]);
    assert.equal(asObject(rule.params).site_id, '');
  });
});
