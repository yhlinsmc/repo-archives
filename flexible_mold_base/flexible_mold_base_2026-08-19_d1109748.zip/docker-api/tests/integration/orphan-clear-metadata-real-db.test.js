/**
 * orphan-clear-metadata-real-db.test.js
 *
 * The orphan-clear statement, executed by a real MariaDB.
 *
 * WHY THIS EXISTS AS A SEPARATE, DB-BACKED TEST. Every other test on this path
 * asserts SQL text and bound parameters against a stubbed connection. That
 * catches a statement that was built wrong; it cannot catch a statement that was
 * built exactly as intended and means something else to the engine — and this
 * endpoint had precisely that exposure, because the channelled metadata column
 * has two key sites and a clause per site assigned one column twice in a single
 * statement. Whether both removals survived was then a property of the order the
 * engine evaluates a SET list in, which a mock returns `{affectedRows: 1}` to
 * regardless.
 *
 * The statement under test is CAPTURED FROM THE ROUTE rather than written here:
 * a copy in a test file is a second source that drifts, which is the same class
 * of defect this whole change is about. The route runs against a stub that
 * records the SQL, and the recorded SQL is then run against a real database.
 *
 * Auto-detects a reachable MariaDB and skips cleanly when there is none, in the
 * shape the other integration tests in this directory use.
 */
const { test, describe, before, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const net = require('node:net');
const http = require('node:http');
const express = require('express');
const mariadb = require('mariadb');

const {
  USER_TEMPLATE_METADATA_COLUMN_NAMES,
} = require('../../src/edge/lib/user-template-metadata');

const TEST_PREFIX = 'orph_';

// ── Config auto-detection (same shape as the sibling integration tests) ──────

function parseEnvFile(filePath) {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    const out = {};
    for (const line of content.split('\n')) {
      const m = line.match(/^\s*([A-Z_][A-Z0-9_]*)\s*=\s*(.*)\s*$/);
      if (!m) continue;
      let value = m[2];
      if ((value.startsWith('"') && value.endsWith('"'))
        || (value.startsWith("'") && value.endsWith("'"))) {
        value = value.slice(1, -1);
      }
      out[m[1]] = value;
    }
    return out;
  } catch {
    return null;
  }
}

function probePort(host, port, timeoutMs) {
  return new Promise((resolve) => {
    const socket = new net.Socket();
    let done = false;
    const finish = (ok) => {
      if (done) return;
      done = true;
      socket.destroy();
      resolve(ok);
    };
    socket.setTimeout(timeoutMs);
    socket.once('connect', () => finish(true));
    socket.once('timeout', () => finish(false));
    socket.once('error', () => finish(false));
    socket.connect(port, host);
  });
}

async function resolveMariaDbConfig() {
  if (process.env.DB_TEST_HOST && process.env.DB_TEST_ROOT_PASSWORD) {
    return {
      host: process.env.DB_TEST_HOST,
      port: parseInt(process.env.DB_TEST_PORT || '3306', 10),
      user: 'root',
      password: process.env.DB_TEST_ROOT_PASSWORD,
    };
  }
  const envPath = path.resolve(__dirname, '../../../.devcontainer/.env');
  const env = parseEnvFile(envPath);
  if (!env || !env.DB_ROOT_PASSWORD) return null;
  const port = parseInt(env.DB_PORT || '3306', 10);
  for (const host of ['127.0.0.1', 'mariadb', 'localhost']) {
    if (await probePort(host, port, 2000)) {
      return { host, port, user: 'root', password: env.DB_ROOT_PASSWORD };
    }
  }
  return null;
}

// ── Capture the statements the route actually issues ─────────────────────────

const TEMPLATE_COLUMNS = [
  'id', 'blueprint_id', 'payload', ...USER_TEMPLATE_METADATA_COLUMN_NAMES,
];

async function captureRouteStatements(key) {
  const dbKey = require.resolve('../../src/edge/db');
  const captured = [];
  const conn = {
    async query(sql, params) {
      if (/^SELECT DATABASE\(\)/i.test(sql)) return [{ db: 'capture' }];
      if (/information_schema\.COLUMNS/i.test(sql)) {
        return TEMPLATE_COLUMNS.map((c) => ({ COLUMN_NAME: c }));
      }
      captured.push({ sql, params });
      // The re-check reads the payload DOCUMENT and indexes it in JavaScript
      // (the way the scanner does), so this stub answers with what the row
      // holds rather than with a pre-extracted value. A scalar under a checkbox
      // field is a residual, which is what makes the capture below reach the
      // type_mismatch UPDATE.
      if (/^SELECT bf\.field_type/i.test(sql)) return [{ ft: 'checkbox', payload: { [key]: 'a' } }];
      return { affectedRows: 1 };
    },
    release() { /* noop */ },
    async beginTransaction() {},
    async commit() {},
    async rollback() {},
  };
  const poolSpy = {
    rw: { async getConnection() { return conn; } },
    ro: { async getConnection() { return conn; } },
  };
  const saved = require.cache[dbKey];
  require.cache[dbKey] = {
    id: dbKey,
    filename: dbKey,
    loaded: true,
    exports: { pool: poolSpy, t: (n) => `${TEST_PREFIX}${n}`, getDynamicPool: async () => poolSpy },
  };
  // Loaded under the stub so the route resolves the stubbed db module.
  delete require.cache[require.resolve('../../src/edge/routes/app/schema')];
  const router = require('../../src/edge/routes/app/schema');

  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { req.user = { id: 'admin-1', role: 'admin' }; next(); });
  app.use('/edge/app/schema', router);
  const server = app.listen(0, '127.0.0.1');
  await new Promise((resolve) => server.once('listening', resolve));
  const port = server.address().port;

  const call = (suffix) => new Promise((resolve, reject) => {
    const req = http.request({
      method: 'DELETE',
      host: '127.0.0.1',
      port,
      path: `/edge/app/schema/field-data-orphans/t1/${encodeURIComponent(key)}${suffix}`,
    }, (res) => {
      res.on('data', () => {});
      res.on('end', resolve);
    });
    req.on('error', reject);
    req.end();
  });

  try {
    await call('');
    await call('?kind=type_mismatch');
  } finally {
    await new Promise((resolve) => server.close(resolve));
    delete require.cache[require.resolve('../../src/edge/routes/app/schema')];
    if (saved) require.cache[dbKey] = saved; else delete require.cache[dbKey];
  }

  const updates = captured.filter((c) => /^UPDATE/i.test(c.sql));
  const orphan = updates.find((u) => /NOT EXISTS/i.test(u.sql));
  const mismatch = updates.find((u) => !/NOT EXISTS/i.test(u.sql));
  assert.ok(orphan, 'no orphan-path UPDATE was captured');
  assert.ok(mismatch, 'no type_mismatch UPDATE was captured');
  return { orphan, mismatch };
}

// ── Fixture ──────────────────────────────────────────────────────────────────

const KEY = 'finish';
const CLEARED_BEFORE = {
  single_option: { finish: 'sig-A', other: 'sig-B' },
  decision: { finish: 'sig-C' },
};

function templatesDDL() {
  return `CREATE TABLE \`${TEST_PREFIX}user_templates\` (
    id CHAR(36) PRIMARY KEY,
    blueprint_id CHAR(36),
    payload JSON,
    field_option_selection TEXT NULL DEFAULT NULL,
    computed_field_overrides TEXT NULL DEFAULT NULL,
    cleared_auto_fills TEXT NULL DEFAULT NULL
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`;
}

function nodesDDL() {
  return `CREATE TABLE \`${TEST_PREFIX}hierarchy_nodes\` (
    id CHAR(36) PRIMARY KEY,
    linked_blueprint_id CHAR(36) NULL
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`;
}

function fieldsDDL() {
  return `CREATE TABLE \`${TEST_PREFIX}blueprint_fields\` (
    id CHAR(36) PRIMARY KEY,
    blueprint_id CHAR(36),
    field_key VARCHAR(255)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`;
}

let dbReady = false;
let dbConfig = null;
let testDbName = null;
let skipReason = null;
let statements = null;
let conn = null;

before(async () => {
  dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) {
    skipReason = 'no reachable MariaDB (set DB_TEST_HOST/DB_TEST_ROOT_PASSWORD or run in DevContainer)';
    // The flag is honoured on this branch too, not only in the `catch` below.
    // This is the branch a checkout without `.devcontainer/.env` reaches, so it
    // is the one that turned "no database at all" into a green run.
    if (process.env.REQUIRE_INTEGRATION_DB === '1') {
      throw new Error(`REQUIRE_INTEGRATION_DB=1 set but ${skipReason}.`);
    }
    return;
  }
  testDbName = `integ_orph_${process.pid}_${Date.now()}`;
  try {
    statements = await captureRouteStatements(KEY);
    const admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`CREATE DATABASE \`${testDbName}\``);
    await admin.end();
    conn = await mariadb.createConnection({ ...dbConfig, database: testDbName, connectTimeout: 5000 });
    await conn.query(templatesDDL());
    await conn.query(nodesDDL());
    await conn.query(fieldsDDL());
    await conn.query(`INSERT INTO \`${TEST_PREFIX}hierarchy_nodes\` VALUES ('bp-1', NULL)`);
    dbReady = true;
  } catch (err) {
    skipReason = `setup failed: ${err.message}`;
    if (process.env.REQUIRE_INTEGRATION_DB === '1') throw err;
  }
});

after(async () => {
  if (conn) { try { await conn.end(); } catch { /* best effort */ } }
  if (testDbName && dbConfig) {
    try {
      const cleanup = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
      await cleanup.query(`DROP DATABASE IF EXISTS \`${testDbName}\``);
      await cleanup.end();
    } catch (err) {
      console.error(`[teardown] failed to drop ${testDbName}: ${err.message}`);
    }
  }
});

async function seed(cleared) {
  await conn.query(`DELETE FROM \`${TEST_PREFIX}user_templates\``);
  await conn.query(
    `INSERT INTO \`${TEST_PREFIX}user_templates\` VALUES (?, 'bp-1', ?, ?, ?, ?)`,
    [
      't1',
      JSON.stringify({ finish: '', size: 'L' }),
      JSON.stringify({ finish: 'Matte', size: 'Large (L)' }),
      JSON.stringify({ finish: true }),
      cleared,
    ],
  );
}

async function storedRow() {
  const rows = await conn.query(
    `SELECT payload, field_option_selection, computed_field_overrides, cleared_auto_fills
       FROM \`${TEST_PREFIX}user_templates\` WHERE id = 't1'`,
  );
  return rows[0];
}

describe('orphan clear — what the database does with the statement', () => {
  test('removes the key from BOTH channels of the channelled column', async (t) => {
    if (!dbReady) { t.skip(skipReason); return; }
    await seed(JSON.stringify(CLEARED_BEFORE));

    await conn.query(statements.orphan.sql, statements.orphan.params);

    const row = await storedRow();
    const cleared = JSON.parse(row.cleared_auto_fills);
    assert.deepEqual(
      cleared, { single_option: { other: 'sig-B' }, decision: {} },
      'both channels must lose the key; a column assigned once per channel leaves this '
      + 'to the engine\'s SET evaluation order',
    );
    assert.deepEqual(JSON.parse(row.field_option_selection), { size: 'Large (L)' });
    assert.deepEqual(JSON.parse(row.computed_field_overrides), {});
    assert.deepEqual(
      typeof row.payload === 'string' ? JSON.parse(row.payload) : row.payload,
      { size: 'L' },
    );
  });

  test('the type_mismatch statement clears both channels too', async (t) => {
    if (!dbReady) { t.skip(skipReason); return; }
    await seed(JSON.stringify(CLEARED_BEFORE));

    await conn.query(statements.mismatch.sql, statements.mismatch.params);

    const cleared = JSON.parse((await storedRow()).cleared_auto_fills);
    assert.deepEqual(cleared, { single_option: { other: 'sig-B' }, decision: {} });
  });

  test('leaves a document the engine cannot parse exactly as it found it', async (t) => {
    if (!dbReady) { t.skip(skipReason); return; }
    const corrupt = '{"single_option":{"finish":"sig-A"';
    await seed(corrupt);

    await conn.query(statements.orphan.sql, statements.orphan.params);

    assert.equal(
      (await storedRow()).cleared_auto_fills, corrupt,
      'an unparseable document must survive the repair rather than becoming NULL',
    );
  });

  test('leaves a NULL document NULL', async (t) => {
    if (!dbReady) { t.skip(skipReason); return; }
    await seed(null);

    await conn.query(statements.orphan.sql, statements.orphan.params);

    assert.equal((await storedRow()).cleared_auto_fills, null);
  });
});
