'use strict';

/**
 * owner-identity-real-db.test.js — one spelling of an owner, against a real
 * database, reading the stored rows back.
 *
 * WHAT THIS FILE IS ABOUT. Every owner-bearing column in this schema is
 * `CHAR(36)` under `utf8mb4_general_ci`, and that collation folds case. So a
 * guard that proves a user row exists — `SELECT id FROM users WHERE id = ?` —
 * resolves the row for ANY spelling of that id, and the producer then binds the
 * CLIENT's spelling into `SET owner_id = ?`. Measured against MariaDB 10.11: the
 * engine does not absorb a respelling, it stores the new bytes. From that moment
 * the deployment holds two different answers to "who owns this row":
 *
 *   every SQL reader  — `WHERE owner_id = ?`, an EXISTS predicate, an index —
 *                       still resolves the true owner, because the collation
 *                       folds the difference away;
 *   every JS reader   — `row.owner_id === req.user.id` (shared/helpers.js
 *                       `isOwnerOrAdmin`), `ownerId === user.id`
 *                       (`callerOwnsSubject`), `.find(n => n.id === parentId)` in
 *                       the front end — resolves NOBODY.
 *
 * One `PATCH …/owner` therefore splits authorization in two. That is why the
 * assertions below are on STORED VALUES and ROW COUNTS: the defect is what the
 * bytes in the column are, and a status code cannot see it. A mocked driver
 * answers "which row did that statement match" with whatever the fixture was
 * told to say, so it can neither show the split nor prove it is gone.
 *
 * The file covers both halves in one chain, per the card: the producer stores
 * the resolved id, and the true owner can then still act.
 *
 * Skips with a stated reason when no database is reachable, and FAILS instead of
 * skipping when REQUIRE_INTEGRATION_DB=1 — a silent skip is the failure mode
 * this whole line of work exists to end.
 */
const {
  test, describe, before, after, beforeEach,
} = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const net = require('node:net');
const http = require('node:http');
const express = require('express');
const mariadb = require('mariadb');

const TEST_PREFIX = 'oid_';
const tbl = (name) => `${TEST_PREFIX}${name}`;

let pool = null;
const lease = () => pool.getConnection();
// Both halves of the real pool object: routes lease a connection for their
// transactions AND call `pool.ro.query` directly for the reads that need no
// transaction. A stand-in offering only one of the two turns whichever guard
// takes the other path into a 500 that looks like a refusal.
const handle = () => ({ getConnection: lease, query: (sql, params) => pool.query(sql, params) });

const dbKey = require.resolve('../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey,
  filename: dbKey,
  loaded: true,
  exports: {
    pool: { ro: handle(), rw: handle() },
    t: tbl,
    getDynamicPool: async () => ({ ro: handle(), rw: handle() }),
  },
};

const { buildEngineTableDDLs, buildInfraTableDDLs } = require('../../src/table-ddls');
const schemaRouter = require('../../src/edge/routes/app/schema');
const transformersRouter = require('../../src/edge/routes/app/transformers');
const connectorsRouter = require('../../src/edge/routes/app/api-connectors');
const capacityRouter = require('../../src/edge/routes/app/capacity');
const grantsRouter = require('../../src/edge/routes/app/delegated-grants');

// ── Config auto-detection (same shape as the sibling integration tests) ──────

function parseEnvFile(filePath) {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    const out = {};
    for (const line of content.split('\n')) {
      const m = line.match(/^\s*([A-Z_][A-Z0-9_]*)\s*=\s*(.*)\s*$/);
      if (!m) continue;
      let value = m[2];
      if ((value.startsWith('"') && value.endsWith('"'))
        || (value.startsWith("'") && value.endsWith("'"))) {
        value = value.slice(1, -1);
      }
      out[m[1]] = value;
    }
    return out;
  } catch {
    return null;
  }
}

function probePort(host, port, timeoutMs = 2000) {
  return new Promise((resolve) => {
    const socket = new net.Socket();
    let done = false;
    const finish = (ok) => {
      if (done) return;
      done = true;
      socket.destroy();
      resolve(ok);
    };
    socket.setTimeout(timeoutMs);
    socket.once('connect', () => finish(true));
    socket.once('timeout', () => finish(false));
    socket.once('error', () => finish(false));
    socket.connect(port, host);
  });
}

async function resolveMariaDbConfig() {
  if (process.env.DB_TEST_HOST && process.env.DB_TEST_ROOT_PASSWORD) {
    return {
      host: process.env.DB_TEST_HOST,
      port: parseInt(process.env.DB_TEST_PORT || '3306', 10),
      user: 'root',
      password: process.env.DB_TEST_ROOT_PASSWORD,
    };
  }
  const envPath = path.resolve(__dirname, '../../../.devcontainer/.env');
  const env = parseEnvFile(envPath);
  if (!env || !env.DB_ROOT_PASSWORD) return null;
  const port = parseInt(env.DB_PORT || '3306', 10);
  for (const host of ['127.0.0.1', 'mariadb', 'localhost']) {
    if (await probePort(host, port, 2000)) {
      return { host, port, user: 'root', password: env.DB_ROOT_PASSWORD };
    }
  }
  return null;
}

// ── Fixture ─────────────────────────────────────────────────────────────────

// Identifiers carrying hex LETTERS, deliberately: a uuid of digits only has one
// spelling, so it could not exercise the defect at all. `.toUpperCase()` on
// these is a different JavaScript string and the same stored row under
// `utf8mb4_general_ci`, which is the entire premise under test.
const OWNER_ID = 'abcdef01-2345-6789-abcd-ef0123456789';
const OWNER_ALIAS = OWNER_ID.toUpperCase();
const SECOND_ID = 'bcdefa02-3456-789a-bcde-fa0123456789';
const SECOND_ALIAS = SECOND_ID.toUpperCase();
const ADMIN_ID = 'cdefab03-4567-89ab-cdef-ab0123456789';

const ADMIN = { id: ADMIN_ID, role: 'admin' };
const OWNER = { id: OWNER_ID, role: 'editor' };
const SECOND = { id: SECOND_ID, role: 'editor' };

let dbReady = false;
let skipReason = null;
let testDbName = null;
let server = null;
let baseUrl = null;
let currentUser = ADMIN;

before(async () => {
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) {
    skipReason = 'no MariaDB reachable via .devcontainer/.env or env vars';
    if (process.env.REQUIRE_INTEGRATION_DB === '1') {
      throw new Error(`REQUIRE_INTEGRATION_DB=1 set but ${skipReason}.`);
    }
    return;
  }
  testDbName = `owner_identity_test_${process.pid}_${Date.now()}`;
  let admin = null;
  try {
    admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`CREATE DATABASE \`${testDbName}\``);
    await admin.query(`USE \`${testDbName}\``);
    // Every table, built from the DDL that creates the real ones. A hand-picked
    // subset drops a table some guard probes and turns its refusal into a
    // degrade nobody asked for.
    for (const sql of [...buildInfraTableDDLs(tbl), ...buildEngineTableDDLs(tbl)]) {
      await admin.query(sql);
    }
    await admin.end();
    admin = null;

    pool = mariadb.createPool({
      ...dbConfig, database: testDbName, connectionLimit: 6, connectTimeout: 5000,
    });

    const app = express();
    app.use(express.json());
    app.use((req, _res, next) => { req.user = currentUser; next(); });
    app.use('/edge/app/schema', schemaRouter);
    app.use('/edge/app/transformers', transformersRouter);
    app.use('/edge/app/api-connectors', connectorsRouter);
    app.use('/edge/app/capacity', capacityRouter);
    app.use('/edge/app/delegated-grants', grantsRouter);
    server = http.createServer(app);
    await new Promise((r) => server.listen(0, r));
    baseUrl = `http://127.0.0.1:${server.address().port}`;
    dbReady = true;
  } catch (err) {
    skipReason = `setup failed: ${err.message}`;
    if (admin) { try { await admin.end(); } catch { /* best effort */ } }
    if (process.env.REQUIRE_INTEGRATION_DB === '1') throw err;
  }
});

after(async () => {
  if (server) { try { server.close(); } catch { /* best effort */ } }
  if (pool) { try { await pool.end(); } catch { /* best effort */ } }
  if (!testDbName) return;
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) return;
  try {
    const admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`DROP DATABASE IF EXISTS \`${testDbName}\``);
    await admin.end();
  } catch { /* best effort */ }
});

async function call(user, method, url, body) {
  currentUser = user;
  const res = await fetch(`${baseUrl}${url}`, {
    method,
    headers: { 'content-type': 'application/json' },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const text = await res.text();
  let parsed = null;
  try { parsed = JSON.parse(text); } catch { parsed = { raw: text }; }
  return { status: res.status, body: parsed };
}

const q = (sql, params) => pool.query(sql, params);
const one = async (sql, params) => (await pool.query(sql, params))[0];
const countOf = async (sql, params) => Number((await one(sql, params)).n);

const guard = (t) => {
  if (dbReady) return false;
  t.skip(skipReason || 'database not ready');
  return true;
};

/**
 * The stored bytes of one column, read back with no folding.
 *
 * `BINARY` is the point of this helper rather than a flourish: reading the
 * column plainly and comparing in JavaScript would work, but a future reader
 * could not tell whether the assertion is about the value or about the
 * collation. Casting to binary states that this test asks the exact question the
 * broken JS consumers ask.
 */
async function storedBytes(table, column, id) {
  const row = await one(
    `SELECT CAST(\`${column}\` AS BINARY) AS v FROM \`${tbl(table)}\` WHERE id = ?`,
    [id],
  );
  if (!row || row.v == null) return null;
  return Buffer.isBuffer(row.v) ? row.v.toString('utf8') : String(row.v);
}

const RELEASE_ID = '11111111-1111-4111-8111-111111111111';
// Hex LETTERS again, and for the same reason as the user ids: this is the one
// the reparent respells, and an all-digit uuid has a single spelling — a
// fixture built from one would pass the case below without the fix.
const RELEASE_TWO_ID = 'dabcde04-5678-49bc-8ef0-123456789abc';
const BLUEPRINT_ID = '33333333-3333-4333-8333-333333333333';
const TEMPLATE_ID = '44444444-4444-4444-8444-444444444444';
const CONNECTOR_ID = '55555555-5555-4555-8555-555555555555';
const TRANSFORMER_ID = '66666666-6666-4666-8666-666666666666';
const SCENARIO_ID = '77777777-7777-4777-8777-777777777777';

beforeEach(async () => {
  if (!dbReady) return;
  for (const name of ['delegated_grants', 'feature_audit', 'user_templates', 'api_connectors',
    'transformers', 'cap_scenarios', 'hierarchy_nodes', 'users']) {
    await q(`DELETE FROM \`${tbl(name)}\``);
  }
  await q(
    `INSERT INTO \`${tbl('users')}\` (id, email, role, banned) VALUES (?,?,?,0),(?,?,?,0),(?,?,?,0)`,
    [
      OWNER_ID, 'owner@test.local', 'editor',
      SECOND_ID, 'second@test.local', 'editor',
      ADMIN_ID, 'admin@test.local', 'admin',
    ],
  );
  await q(
    `INSERT INTO \`${tbl('hierarchy_nodes')}\` (id, parent_id, name, node_type) VALUES (?,?,?,?),(?,?,?,?)`,
    [RELEASE_ID, null, 'release one', 'release', RELEASE_TWO_ID, null, 'release two', 'release'],
  );
  await q(
    `INSERT INTO \`${tbl('hierarchy_nodes')}\` (id, parent_id, name, node_type, owner_id) VALUES (?,?,?,?,?)`,
    [BLUEPRINT_ID, RELEASE_ID, 'a blueprint', 'blueprint', null],
  );
  await q(
    `INSERT INTO \`${tbl('user_templates')}\` (id, name, blueprint_id, owner_id) VALUES (?,?,?,?)`,
    [TEMPLATE_ID, 'a template', BLUEPRINT_ID, ADMIN_ID],
  );
  // BOUND to the shared blueprint, deliberately. An UNBOUND connector is
  // refused an editor target by an earlier arm of the same route ("bind it to a
  // blueprint they own or that is shared first"), so a fixture with a null
  // `blueprint_id` answers 400 for a reason that has nothing to do with owner
  // identity — a red that would pass again the moment the real defect was
  // reintroduced.
  await q(
    `INSERT INTO \`${tbl('api_connectors')}\` (id, name, url, blueprint_id, owner_id) VALUES (?,?,?,?,?)`,
    [CONNECTOR_ID, 'a connector', 'https://example.invalid/x', BLUEPRINT_ID, ADMIN_ID],
  );
  await q(
    `INSERT INTO \`${tbl('transformers')}\` (id, name, code, owner_id) VALUES (?,?,?,?)`,
    [TRANSFORMER_ID, 'a transformer', 'module.exports = () => ({});', null],
  );
  await q(
    `INSERT INTO \`${tbl('cap_scenarios')}\` (id, name, owner_id) VALUES (?,?,?)`,
    [SCENARIO_ID, 'a scenario', null],
  );
});

// ── The premise, stated mechanically ────────────────────────────────────────

describe('the premise: the column folds case and the engine keeps the new bytes', () => {
  test('a case-only UPDATE persists the alias, and SQL still resolves the row', async (t) => {
    if (guard(t)) return;
    await q(`UPDATE \`${tbl('hierarchy_nodes')}\` SET owner_id = ? WHERE id = ?`,
      [OWNER_ALIAS, BLUEPRINT_ID]);
    // The engine did not absorb the respelling — this is measurement M1, and
    // every case below is downstream of it being true.
    assert.equal(await storedBytes('hierarchy_nodes', 'owner_id', BLUEPRINT_ID), OWNER_ALIAS);
    // …and yet every SQL reader still resolves the true owner. Two answers, one
    // column: that is the split this file exists to close.
    const matched = await countOf(
      `SELECT COUNT(*) AS n FROM \`${tbl('hierarchy_nodes')}\` WHERE id = ? AND owner_id = ?`,
      [BLUEPRINT_ID, OWNER_ID],
    );
    assert.equal(matched, 1);
  });
});

// ── T1: the producers bind the resolved id ──────────────────────────────────

describe('rank 12 / X11–X14 / F18 — the resolved id is what gets stored', () => {
  test('rank 12 (blueprint): PATCH owner with an alias stores the canonical id', async (t) => {
    if (guard(t)) return;
    const res = await call(ADMIN, 'PATCH', `/edge/app/schema/hierarchy_nodes/${BLUEPRINT_ID}/owner`,
      { new_owner_id: OWNER_ALIAS });
    assert.equal(res.status, 200);
    assert.equal(await storedBytes('hierarchy_nodes', 'owner_id', BLUEPRINT_ID), OWNER_ID);
  });

  test('rank 12 (template): PATCH owner with an alias stores the canonical id', async (t) => {
    if (guard(t)) return;
    const res = await call(ADMIN, 'PATCH', `/edge/app/schema/user_templates/${TEMPLATE_ID}/owner`,
      { new_owner_id: OWNER_ALIAS });
    assert.equal(res.status, 200);
    assert.equal(await storedBytes('user_templates', 'owner_id', TEMPLATE_ID), OWNER_ID);
  });

  test('X12/F18 (connector): PATCH owner with an alias stores the canonical id', async (t) => {
    if (guard(t)) return;
    const res = await call(ADMIN, 'PATCH', `/edge/app/api-connectors/${CONNECTOR_ID}/owner`,
      { new_owner_id: OWNER_ALIAS });
    assert.equal(res.status, 200);
    assert.equal(await storedBytes('api_connectors', 'owner_id', CONNECTOR_ID), OWNER_ID);
  });

  test('X13 (transformer): PATCH owner with an alias stores the canonical id', async (t) => {
    if (guard(t)) return;
    const res = await call(ADMIN, 'PATCH', `/edge/app/transformers/${TRANSFORMER_ID}/owner`,
      { new_owner_id: OWNER_ALIAS });
    assert.equal(res.status, 200);
    assert.equal(await storedBytes('transformers', 'owner_id', TRANSFORMER_ID), OWNER_ID);
  });

  test('X14 (capacity scenario): PATCH owner with an alias stores the canonical id', async (t) => {
    if (guard(t)) return;
    const res = await call(ADMIN, 'PATCH', `/edge/app/capacity/scenarios/${SCENARIO_ID}/owner`,
      { new_owner_id: OWNER_ALIAS });
    assert.equal(res.status, 200);
    assert.equal(await storedBytes('cap_scenarios', 'owner_id', SCENARIO_ID), OWNER_ID);
  });

  test('X11 (grant): the grantee stored is the canonical id, not the spelling asked for', async (t) => {
    if (guard(t)) return;
    await q(`UPDATE \`${tbl('hierarchy_nodes')}\` SET owner_id = ? WHERE id = ?`,
      [OWNER_ID, BLUEPRINT_ID]);
    const res = await call(OWNER, 'POST', '/edge/app/delegated-grants',
      { scope_type: 'blueprint', scope_id: BLUEPRINT_ID, grantee_id: SECOND_ALIAS });
    assert.equal(res.status, 201);
    const row = await one(
      `SELECT CAST(grantee_id AS BINARY) AS v FROM \`${tbl('delegated_grants')}\``,
    );
    const stored = Buffer.isBuffer(row.v) ? row.v.toString('utf8') : String(row.v);
    assert.equal(stored, SECOND_ID);
  });

  test('a target that does not exist is still refused, and stores nothing', async (t) => {
    if (guard(t)) return;
    const res = await call(ADMIN, 'PATCH', `/edge/app/schema/hierarchy_nodes/${BLUEPRINT_ID}/owner`,
      { new_owner_id: 'fedcba09-8765-4321-fedc-ba9876543210' });
    assert.equal(res.status, 400);
    assert.equal(await storedBytes('hierarchy_nodes', 'owner_id', BLUEPRINT_ID), null);
  });
});

// ── The consumer half: the true owner can still act ─────────────────────────

describe('rank 12, the other half — after a transfer the true owner is still the owner', () => {
  test('the new owner may delegate over the blueprint they were just given', async (t) => {
    if (guard(t)) return;
    const transfer = await call(ADMIN, 'PATCH', `/edge/app/schema/hierarchy_nodes/${BLUEPRINT_ID}/owner`,
      { new_owner_id: OWNER_ALIAS });
    assert.equal(transfer.status, 200);
    // `callerOwnsSubject` (delegated-grants.js) asks `ownerId === user.id` — a
    // JavaScript reader. With the alias stored it resolves nobody and the true
    // owner is answered 404 over their own record.
    const grant = await call(OWNER, 'POST', '/edge/app/delegated-grants',
      { scope_type: 'blueprint', scope_id: BLUEPRINT_ID, grantee_id: SECOND_ID });
    assert.equal(await countOf(`SELECT COUNT(*) AS n FROM \`${tbl('delegated_grants')}\``), 1);
    assert.equal(grant.status, 201);
  });

  test('the new owner of a template may delegate over it', async (t) => {
    if (guard(t)) return;
    const transfer = await call(ADMIN, 'PATCH', `/edge/app/schema/user_templates/${TEMPLATE_ID}/owner`,
      { new_owner_id: OWNER_ALIAS });
    assert.equal(transfer.status, 200);
    const grant = await call(OWNER, 'POST', '/edge/app/delegated-grants',
      { scope_type: 'template', scope_id: TEMPLATE_ID, grantee_id: SECOND_ID });
    assert.equal(await countOf(`SELECT COUNT(*) AS n FROM \`${tbl('delegated_grants')}\``), 1);
    assert.equal(grant.status, 201);
  });
});

// ── T2: "did the owner change" is asked of the column ───────────────────────

describe('rank 15 — the owner precondition is asked of the column', () => {
  test('the genuine owner may release a row whose column holds another spelling', async (t) => {
    if (guard(t)) return;
    // A row already carrying an alias: what a deployment holds today, and what
    // every one of these routes has been producing.
    await q(`UPDATE \`${tbl('hierarchy_nodes')}\` SET owner_id = ? WHERE id = ?`,
      [OWNER_ALIAS, BLUEPRINT_ID]);
    const res = await call(OWNER, 'POST', `/edge/app/schema/hierarchy_nodes/${BLUEPRINT_ID}/release`);
    // On a STORED VALUE first, deliberately: the release actually cleared the
    // column, rather than the route merely answering 200.
    assert.equal(await storedBytes('hierarchy_nodes', 'owner_id', BLUEPRINT_ID), null);
    assert.equal(res.status, 200);
  });

  test('naming the current owner in another spelling is not a transfer', async (t) => {
    if (guard(t)) return;
    await q(`UPDATE \`${tbl('hierarchy_nodes')}\` SET owner_id = ? WHERE id = ?`,
      [OWNER_ID, BLUEPRINT_ID]);
    const res = await call(ADMIN, 'PATCH', `/edge/app/schema/hierarchy_nodes/${BLUEPRINT_ID}/owner`,
      { new_owner_id: OWNER_ALIAS });
    // On a ROW COUNT: nothing moved, so the trail must not gain a line saying
    // ownership changed hands. Today the short-circuit compares the stored
    // spelling against the one the client typed, calls that a change, writes
    // the alias into the column and records a transfer that never happened.
    assert.equal(await countOf(`SELECT COUNT(*) AS n FROM \`${tbl('feature_audit')}\``), 0);
    assert.equal(await storedBytes('hierarchy_nodes', 'owner_id', BLUEPRINT_ID), OWNER_ID);
    assert.equal(res.status, 200);
  });

  test('the genuine owner re-claiming such a row is answered as a no-op', async (t) => {
    if (guard(t)) return;
    await q(`UPDATE \`${tbl('hierarchy_nodes')}\` SET owner_id = ? WHERE id = ?`,
      [OWNER_ALIAS, BLUEPRINT_ID]);
    const res = await call(OWNER, 'POST', `/edge/app/schema/hierarchy_nodes/${BLUEPRINT_ID}/claim`);
    // The only case in this file whose discriminator is genuinely the status:
    // both the broken 409 and the fixed 200 leave the column alone and write no
    // audit row, so there is no stored fact that separates them. Its DATA
    // consequence — the true owner locked out of their own record — is what the
    // release case above asserts on a stored value.
    assert.equal(res.status, 200);
    assert.equal(res.body.data.claimed, false);
    assert.equal(await countOf(`SELECT COUNT(*) AS n FROM \`${tbl('feature_audit')}\``), 0);
  });

  test('a stranger is still refused, and the column is untouched', async (t) => {
    if (guard(t)) return;
    await q(`UPDATE \`${tbl('hierarchy_nodes')}\` SET owner_id = ? WHERE id = ?`,
      [OWNER_ALIAS, BLUEPRINT_ID]);
    const res = await call(SECOND, 'POST', `/edge/app/schema/hierarchy_nodes/${BLUEPRINT_ID}/release`);
    assert.equal(res.status, 403);
    assert.equal(await storedBytes('hierarchy_nodes', 'owner_id', BLUEPRINT_ID), OWNER_ALIAS);
  });
});

// ── T3: a self-grant is refused the way the index decides it ────────────────

describe('X15 — a self-grant is refused the way the index decides it', () => {
  test('granting yourself under another spelling stores no row', async (t) => {
    if (guard(t)) return;
    await q(`UPDATE \`${tbl('hierarchy_nodes')}\` SET owner_id = ? WHERE id = ?`,
      [OWNER_ID, BLUEPRINT_ID]);
    const res = await call(OWNER, 'POST', '/edge/app/delegated-grants',
      { scope_type: 'blueprint', scope_id: BLUEPRINT_ID, grantee_id: OWNER_ALIAS });
    // On a ROW COUNT, because the harm is the row surviving: a grant to
    // yourself outlives the ownership it was made under, so an owner who
    // self-grants and then hands the record on keeps write and dispatch over a
    // record they no longer own.
    assert.equal(await countOf(`SELECT COUNT(*) AS n FROM \`${tbl('delegated_grants')}\``), 0);
    assert.equal(res.status, 400);
  });

  test('and the harm it prevents: no grant survives the transfer away', async (t) => {
    if (guard(t)) return;
    await q(`UPDATE \`${tbl('hierarchy_nodes')}\` SET owner_id = ? WHERE id = ?`,
      [OWNER_ID, BLUEPRINT_ID]);
    await call(OWNER, 'POST', '/edge/app/delegated-grants',
      { scope_type: 'blueprint', scope_id: BLUEPRINT_ID, grantee_id: OWNER_ALIAS });
    const transfer = await call(ADMIN, 'PATCH', `/edge/app/schema/hierarchy_nodes/${BLUEPRINT_ID}/owner`,
      { new_owner_id: SECOND_ID });
    assert.equal(transfer.status, 200);
    const held = await countOf(
      `SELECT COUNT(*) AS n FROM \`${tbl('delegated_grants')}\` WHERE grantee_id = ?`,
      [OWNER_ID],
    );
    assert.equal(held, 0);
  });

  test('granting a colleague is unaffected', async (t) => {
    if (guard(t)) return;
    await q(`UPDATE \`${tbl('hierarchy_nodes')}\` SET owner_id = ? WHERE id = ?`,
      [OWNER_ID, BLUEPRINT_ID]);
    const res = await call(OWNER, 'POST', '/edge/app/delegated-grants',
      { scope_type: 'blueprint', scope_id: BLUEPRINT_ID, grantee_id: SECOND_ID });
    assert.equal(res.status, 201);
    assert.equal(await countOf(`SELECT COUNT(*) AS n FROM \`${tbl('delegated_grants')}\``), 1);
  });
});

// ── T4: the reparent stores the id the re-stamp will use ────────────────────

describe('rank 53 — the reparent stores the id the re-stamp will use', () => {
  test('a target named in another spelling is stored canonically', async (t) => {
    if (guard(t)) return;
    const res = await call(ADMIN, 'POST', `/edge/app/schema/hierarchy_nodes/${BLUEPRINT_ID}/reparent`,
      { newParentId: RELEASE_TWO_ID.toUpperCase() });
    assert.equal(res.status, 200);
    // The front end builds the tree with `.find(n => n.id === node.parent_id)`.
    // A parent_id holding a spelling no node's id carries drops the branch out
    // of the tree while every SQL reader still resolves it.
    assert.equal(await storedBytes('hierarchy_nodes', 'parent_id', BLUEPRINT_ID), RELEASE_TWO_ID);
  });

  test('the stored parent really is a row, byte for byte', async (t) => {
    if (guard(t)) return;
    await call(ADMIN, 'POST', `/edge/app/schema/hierarchy_nodes/${BLUEPRINT_ID}/reparent`,
      { newParentId: RELEASE_TWO_ID.toUpperCase() });
    // A join that folds nothing: the count is 1 only when the child's stored
    // parent_id is byte-identical to some node's stored id.
    const joined = await countOf(
      `SELECT COUNT(*) AS n FROM \`${tbl('hierarchy_nodes')}\` child
         JOIN \`${tbl('hierarchy_nodes')}\` parent
           ON CAST(child.parent_id AS BINARY) = CAST(parent.id AS BINARY)
        WHERE child.id = ?`,
      [BLUEPRINT_ID],
    );
    assert.equal(joined, 1);
  });

  test('a parent that does not exist is still refused', async (t) => {
    if (guard(t)) return;
    const res = await call(ADMIN, 'POST', `/edge/app/schema/hierarchy_nodes/${BLUEPRINT_ID}/reparent`,
      { newParentId: 'fedcba09-8765-4321-fedc-ba9876543210' });
    assert.equal(res.status, 400);
    assert.equal(await storedBytes('hierarchy_nodes', 'parent_id', BLUEPRINT_ID), RELEASE_ID);
  });
});

// ── F19: the connector reassign has an identifier floor ─────────────────────

describe('F19 — a padded id resolves a user, and the STORED id is what lands', () => {
  test('a padded spelling stores the id the user row holds', async (t) => {
    if (guard(t)) return;
    // A CHAR comparison pads the shorter operand, so `WHERE id = 'uuid '`
    // resolves a user row and the "does this person exist" guard passes on a
    // string that is not byte-identical to any id.
    //
    // THIS ROUTE HELD A `UUID_RE` FLOOR FOR THAT, AND THE FLOOR HAS BEEN
    // REMOVED. Its stated reason — "every sibling owner route reaches its
    // target through a UUID_RE-checked path; this one did not" — was not true:
    // none of the four siblings validates the shape. And the harm it named is
    // answered by the resolver, which returns the STORED id that every
    // statement then binds, so a padded spelling never reaches the column. What
    // the floor DID reach was a deployment whose `users.id` values are not
    // canonical uuids, where it made this the only record type an administrator
    // could not repair.
    const res = await call(ADMIN, 'PATCH', `/edge/app/api-connectors/${CONNECTOR_ID}/owner`,
      { new_owner_id: `${OWNER_ID} ` });
    assert.equal(res.status, 200, `the transfer was refused: ${JSON.stringify(res.body)}`);
    assert.equal(
      await storedBytes('api_connectors', 'owner_id', CONNECTOR_ID), OWNER_ID,
      'a padded spelling reached the owner column',
    );
  });

  test('an id that resolves no user is refused, and the owner is unchanged', async (t) => {
    if (guard(t)) return;
    // The refusal that does the work now: not a shape rule, but "there is no
    // such user". It answers every string the shape floor answered, and does
    // not answer any string a real user's id spells.
    const res = await call(ADMIN, 'PATCH', `/edge/app/api-connectors/${CONNECTOR_ID}/owner`,
      { new_owner_id: 'not-a-uuid' });
    assert.equal(
      await storedBytes('api_connectors', 'owner_id', CONNECTOR_ID), ADMIN_ID,
      'a value naming no user moved the connector',
    );
    assert.equal(res.status, 400);
  });
});

// ── T5: the generic scenario PUT does not transfer ownership ────────────────

describe('E33 — the generic scenario PUT does not transfer ownership', () => {
  test('an owner_id in a PUT body leaves the stored owner untouched', async (t) => {
    if (guard(t)) return;
    await q(`UPDATE \`${tbl('cap_scenarios')}\` SET owner_id = ? WHERE id = ?`,
      [OWNER_ID, SCENARIO_ID]);
    const res = await call(ADMIN, 'PUT', `/edge/app/capacity/scenarios/${SCENARIO_ID}`,
      { name: 'renamed', owner_id: SECOND_ID });
    assert.equal(res.status, 200);
    // The rename went through — this is not a route that stopped working.
    assert.equal((await one(
      `SELECT name FROM \`${tbl('cap_scenarios')}\` WHERE id = ?`, [SCENARIO_ID],
    )).name, 'renamed');
    // The transfer did not. A transfer goes through the endpoint that validates
    // the target and writes the trail; the generic mount is not a second door.
    assert.equal(await storedBytes('cap_scenarios', 'owner_id', SCENARIO_ID), OWNER_ID);
  });

  test('and no ownership audit line is written by that PUT', async (t) => {
    if (guard(t)) return;
    await q(`UPDATE \`${tbl('cap_scenarios')}\` SET owner_id = ? WHERE id = ?`,
      [OWNER_ID, SCENARIO_ID]);
    await call(ADMIN, 'PUT', `/edge/app/capacity/scenarios/${SCENARIO_ID}`,
      { name: 'renamed', owner_id: SECOND_ID });
    const trail = await countOf(
      `SELECT COUNT(*) AS n FROM \`${tbl('feature_audit')}\` WHERE event_type LIKE '%owner%'`,
    );
    assert.equal(trail, 0);
  });

  test('the dedicated transfer endpoint still works', async (t) => {
    if (guard(t)) return;
    const res = await call(ADMIN, 'PATCH', `/edge/app/capacity/scenarios/${SCENARIO_ID}/owner`,
      { new_owner_id: SECOND_ID });
    assert.equal(res.status, 200);
    assert.equal(await storedBytes('cap_scenarios', 'owner_id', SCENARIO_ID), SECOND_ID);
  });
});

// ── E33's other two doors: the same act through the generic PUT ────────────

describe('E33 — the generic PUT is not a second transfer route', () => {
  test('a blueprint\'s owner does not move through the generic PUT', async (t) => {
    if (guard(t)) return;
    // `ownerColumn` strips owner_id from a NON-admin body only, so an
    // administrator's ordinary PUT could hand the record to anybody with none
    // of what makes the dedicated endpoint safe: no target check, no cascade to
    // the variants that inherit the owner, and no audit line — the only record
    // a transfer happened at all.
    await q(`UPDATE \`${tbl('hierarchy_nodes')}\` SET owner_id = ? WHERE id = ?`,
      [OWNER_ID, BLUEPRINT_ID]);

    const res = await call(ADMIN, 'PUT', `/edge/app/schema/hierarchy_nodes/${BLUEPRINT_ID}`,
      { name: 'renamed blueprint', owner_id: SECOND_ID });

    assert.equal(res.status, 200, `the rename was refused: ${JSON.stringify(res.body)}`);
    // The rename landed — this is not a route that stopped working.
    assert.equal((await one(
      `SELECT name FROM \`${tbl('hierarchy_nodes')}\` WHERE id = ?`, [BLUEPRINT_ID],
    )).name, 'renamed blueprint');
    assert.equal(await storedBytes('hierarchy_nodes', 'owner_id', BLUEPRINT_ID), OWNER_ID);
  });

  test('nor a connector\'s', async (t) => {
    if (guard(t)) return;
    const res = await call(ADMIN, 'PUT', `/edge/app/api-connectors/${CONNECTOR_ID}`,
      { name: 'renamed connector', url: 'https://example.invalid/y', owner_id: SECOND_ID });

    assert.equal(res.status, 200, `the rename was refused: ${JSON.stringify(res.body)}`);
    assert.equal((await one(
      `SELECT name FROM \`${tbl('api_connectors')}\` WHERE id = ?`, [CONNECTOR_ID],
    )).name, 'renamed connector');
    assert.equal(await storedBytes('api_connectors', 'owner_id', CONNECTOR_ID), ADMIN_ID);
  });

  test('nor a template\'s, the fourth door and the one keyed on another option', async (t) => {
    if (guard(t)) return;
    // `user_templates` declares `writeScopeColumn: 'owner_id'` rather than
    // `ownerColumn`, and that column is stripped from a PUT body only for a
    // NON-admin role — so the sweep that closed the other three, keyed on the
    // option name, walked past this one. An administrator's ordinary PUT wrote
    // the value straight into the column with none of what PATCH
    // /user_templates/:id/owner does: no check the target user exists, no
    // canonical id, and no audit row.
    const res = await call(ADMIN, 'PUT', `/edge/app/schema/user_templates/${TEMPLATE_ID}`,
      { name: 'renamed template', owner_id: SECOND_ID });

    assert.equal(res.status, 200, `the rename was refused: ${JSON.stringify(res.body)}`);
    assert.equal((await one(
      `SELECT name FROM \`${tbl('user_templates')}\` WHERE id = ?`, [TEMPLATE_ID],
    )).name, 'renamed template', 'the rename stopped working');
    assert.equal(
      await storedBytes('user_templates', 'owner_id', TEMPLATE_ID), ADMIN_ID,
      'the generic PUT moved the template to another owner',
    );
  });

  test('and the same PUT will not invent an owner that is not a user', async (t) => {
    if (guard(t)) return;
    // The value the old door accepted that no route should: not another user's
    // id, but a string no user row carries at all. Such a record is owned by
    // nobody — unreachable through every owner-scoped read, with no route left
    // to repair it.
    const res = await call(ADMIN, 'PUT', `/edge/app/schema/user_templates/${TEMPLATE_ID}`,
      { name: 'renamed again', owner_id: 'not-a-user-at-all' });

    assert.equal(res.status, 200, `the rename was refused: ${JSON.stringify(res.body)}`);
    assert.equal(
      await storedBytes('user_templates', 'owner_id', TEMPLATE_ID), ADMIN_ID,
      'a value that is not a user id reached the owner column',
    );
  });

  test('a template CREATE names a real user, spelled the way that user spells it', async (t) => {
    if (guard(t)) return;
    // The create side of the same column. `writeScopeColumn` overwrites the
    // body's value for a non-admin only, so an administrator's POST carried its
    // own — including a spelling the user row does not hold, which leaves the
    // record owned by somebody no JavaScript reader of the column can find.
    const created = await call(ADMIN, 'POST', '/edge/app/schema/user_templates',
      { name: 'a new template', blueprint_id: BLUEPRINT_ID, owner_id: OWNER_ALIAS });
    assert.equal(created.status, 200, `the create was refused: ${JSON.stringify(created.body)}`);
    assert.equal(
      await storedBytes('user_templates', 'owner_id', created.body.data.id), OWNER_ID,
      'the create stored the body\'s spelling of the owner',
    );

    const refused = await call(ADMIN, 'POST', '/edge/app/schema/user_templates',
      { name: 'another', blueprint_id: BLUEPRINT_ID, owner_id: 'not-a-user-at-all' });
    assert.equal(refused.status, 400, `expected a refusal, got ${JSON.stringify(refused.body)}`);
    assert.equal(
      await countOf(`SELECT COUNT(*) AS n FROM \`${tbl('user_templates')}\` WHERE name = ?`, ['another']),
      0, 'a record owned by nobody was created',
    );
  });

  test('a template may be owned by a plain user — the role gate is not this mount\'s', async (t) => {
    if (guard(t)) return;
    // `ownerColumn` and `writeScopeColumn` name the same kind of value and mean
    // opposite things about who may hold it. The first gates writing on the
    // mount's role set, so an owner outside that set owns a record they cannot
    // touch — which is why the shared binding refuses one. The second is the
    // BYPASS of that gate: it is what lets an ordinary user save their own
    // template on a mount whose `allowedRoles` defaults to admin. Reading the
    // role set on a `writeScopeColumn` mount would refuse a plain user their own
    // record, which is most of what this table is for.
    const PLAIN_ID = 'abcdef08-9abc-4def-8012-3456789abcde';
    await q(
      `INSERT INTO \`${tbl('users')}\` (id, email, role, banned) VALUES (?,?,?,0)`,
      [PLAIN_ID, 'plain@test.local', 'user'],
    );
    const created = await call(ADMIN, 'POST', '/edge/app/schema/user_templates',
      { name: 'owned by a plain user', blueprint_id: BLUEPRINT_ID, owner_id: PLAIN_ID });
    assert.equal(created.status, 200, `the create was refused: ${JSON.stringify(created.body)}`);
    assert.equal(await storedBytes('user_templates', 'owner_id', created.body.data.id), PLAIN_ID);
  });

  test('and the dedicated endpoints still transfer both', async (t) => {
    if (guard(t)) return;
    // The other half: closing a second door must not close the first.
    const node = await call(ADMIN, 'PATCH', `/edge/app/schema/hierarchy_nodes/${BLUEPRINT_ID}/owner`,
      { new_owner_id: SECOND_ID });
    assert.equal(node.status, 200, `the blueprint transfer was refused: ${JSON.stringify(node.body)}`);
    assert.equal(await storedBytes('hierarchy_nodes', 'owner_id', BLUEPRINT_ID), SECOND_ID);

    const connector = await call(ADMIN, 'PATCH', `/edge/app/api-connectors/${CONNECTOR_ID}/owner`,
      { new_owner_id: SECOND_ID });
    assert.equal(connector.status, 200, `the connector transfer was refused: ${JSON.stringify(connector.body)}`);
    assert.equal(await storedBytes('api_connectors', 'owner_id', CONNECTOR_ID), SECOND_ID);
  });
});

// ── The two owner comparisons that were still JavaScript ────────────────────

/**
 * A blueprint nothing else points at, so a cascade delete has only the node to
 * remove. The fixture's own blueprint carries a template AND a connector, and a
 * delete that failed on one of those would be a red with nothing to do with who
 * the owner is.
 *
 * Hex LETTERS, for the reason the user ids carry them: this id is respelled
 * below and an all-digit uuid has one spelling.
 */
const ALIAS_OWNED_BLUEPRINT_ID = 'eabcde05-6789-4abc-8def-0123456789ab';

async function seedAliasOwnedBlueprint() {
  // The owner column holds the OTHER spelling of the owner's id — the state a
  // transfer left behind before the producers were made to bind the stored one,
  // and the state this database still holds for rows written back then. Nothing
  // in this PR rewrites such a row, so the readers have to answer for it.
  await q(
    `INSERT INTO \`${tbl('hierarchy_nodes')}\` (id, parent_id, name, node_type, owner_id)
     VALUES (?,?,?,?,?)`,
    [ALIAS_OWNED_BLUEPRINT_ID, RELEASE_ID, 'an alias-owned blueprint', 'blueprint', OWNER_ALIAS],
  );
  // The premise, measured rather than assumed: to the engine that row is the
  // owner's, which is why every SQL-side enforcement point already lets them
  // through and only the JavaScript readers did not.
  assert.equal(
    await countOf(
      `SELECT COUNT(*) AS n FROM \`${tbl('hierarchy_nodes')}\` WHERE id = ? AND owner_id = ?`,
      [ALIAS_OWNED_BLUEPRINT_ID, OWNER_ID],
    ),
    1,
    'this column no longer resolves the owner under another spelling; the cases below rest on that',
  );
}

const nodeCount = (id) => countOf(
  `SELECT COUNT(*) AS n FROM \`${tbl('hierarchy_nodes')}\` WHERE id = ?`, [id],
);

describe('isOwnerOrAdmin — the row check is asked of the column', () => {
  test('the owner of an alias row may delete it, and the row is gone', async (t) => {
    if (guard(t)) return;
    await seedAliasOwnedBlueprint();

    const res = await call(OWNER, 'DELETE', `/edge/app/schema/hierarchy_nodes/${ALIAS_OWNED_BLUEPRINT_ID}`);

    // The row count is the assertion, and it is the one written to discriminate:
    // a 403 leaves the node in place, so this goes red on the stored rows rather
    // than on how the refusal was spelled.
    assert.equal(
      await nodeCount(ALIAS_OWNED_BLUEPRINT_ID), 0,
      `the genuine owner was refused their own blueprint: ${res.status} ${JSON.stringify(res.body)}`,
    );
  });

  test('and a stranger still is not the owner', async (t) => {
    if (guard(t)) return;
    // The other half of a guard. A comparison that answered "same" for every
    // pair would satisfy the case above and hand every editor every record, so
    // the direction is pinned here on the same kind of assertion.
    await seedAliasOwnedBlueprint();

    await call(SECOND, 'DELETE', `/edge/app/schema/hierarchy_nodes/${ALIAS_OWNED_BLUEPRINT_ID}`);

    assert.equal(await nodeCount(ALIAS_OWNED_BLUEPRINT_ID), 1, 'a stranger deleted a blueprint they do not own');
  });

  test('a shared blueprint stays writable by any editor', async (t) => {
    if (guard(t)) return;
    // The fixture blueprint carries owner_id NULL, which the convention reads as
    // shared. Kept beside the two cases above because a fix that asked the
    // column about a NULL would refuse every editor every shared record.
    await q(`DELETE FROM \`${tbl('user_templates')}\``);
    await q(`DELETE FROM \`${tbl('api_connectors')}\``);

    await call(SECOND, 'DELETE', `/edge/app/schema/hierarchy_nodes/${BLUEPRINT_ID}`);

    assert.equal(await nodeCount(BLUEPRINT_ID), 0, 'an editor was refused a shared blueprint');
  });
});

describe('callerOwnsSubject — the grant gate is asked of the column', () => {
  const grantCount = () => countOf(
    `SELECT COUNT(*) AS n FROM \`${tbl('delegated_grants')}\` WHERE scope_id = ?`,
    [ALIAS_OWNED_BLUEPRINT_ID],
  );

  test('the owner of an alias row may delegate over it, and the grant is stored', async (t) => {
    if (guard(t)) return;
    await seedAliasOwnedBlueprint();

    const res = await call(OWNER, 'POST', '/edge/app/delegated-grants', {
      scope_type: 'blueprint', scope_id: ALIAS_OWNED_BLUEPRINT_ID, grantee_id: SECOND_ID,
    });

    assert.equal(
      await grantCount(), 1,
      `the genuine owner could not delegate over their own blueprint: ${res.status} ${JSON.stringify(res.body)}`,
    );
  });

  test('and somebody who does not own it still cannot', async (t) => {
    if (guard(t)) return;
    await seedAliasOwnedBlueprint();

    await call(SECOND, 'POST', '/edge/app/delegated-grants', {
      scope_type: 'blueprint', scope_id: ALIAS_OWNED_BLUEPRINT_ID, grantee_id: ADMIN_ID,
    });

    assert.equal(await grantCount(), 0, 'a stranger granted access over a record they do not own');
  });
});

// ── a banned account is not a valid owner target, on every verb ─────────────

describe('the shared resolver refuses a banned target', () => {
  const BANNED_ID = 'fabcde06-789a-4bcd-8ef0-123456789abc';

  async function seedBannedUser() {
    await q(
      `INSERT INTO \`${tbl('users')}\` (id, email, role, banned) VALUES (?,?,?,1)`,
      [BANNED_ID, 'banned@test.local', 'editor'],
    );
    // The premise: the account is a REAL, resolvable user — so a refusal below
    // is about the ban and not about the row being missing.
    assert.equal(
      await countOf(`SELECT COUNT(*) AS n FROM \`${tbl('users')}\` WHERE id = ?`, [BANNED_ID]),
      1,
    );
  }

  // Every route that reaches `resolveCanonicalUserId`, with the column each one
  // would have moved. Enumerated rather than sampled: the resolver is now the
  // one place this belongs, and a route that stopped using it would show up
  // here as a green that should be red.
  const verbs = [
    {
      label: 'a blueprint',
      url: () => `/edge/app/schema/hierarchy_nodes/${BLUEPRINT_ID}/owner`,
      table: 'hierarchy_nodes',
      id: () => BLUEPRINT_ID,
      before: () => q(`UPDATE \`${tbl('hierarchy_nodes')}\` SET owner_id = ? WHERE id = ?`,
        [OWNER_ID, BLUEPRINT_ID]),
      expect: () => OWNER_ID,
    },
    {
      label: 'a template',
      url: () => `/edge/app/schema/user_templates/${TEMPLATE_ID}/owner`,
      table: 'user_templates',
      id: () => TEMPLATE_ID,
      expect: () => ADMIN_ID,
    },
    {
      label: 'a connector',
      url: () => `/edge/app/api-connectors/${CONNECTOR_ID}/owner`,
      table: 'api_connectors',
      id: () => CONNECTOR_ID,
      expect: () => ADMIN_ID,
    },
    {
      label: 'a transformer',
      url: () => `/edge/app/transformers/${TRANSFORMER_ID}/owner`,
      table: 'transformers',
      id: () => TRANSFORMER_ID,
      before: () => q(`UPDATE \`${tbl('transformers')}\` SET owner_id = ? WHERE id = ?`,
        [OWNER_ID, TRANSFORMER_ID]),
      expect: () => OWNER_ID,
    },
    {
      label: 'a scenario',
      url: () => `/edge/app/capacity/scenarios/${SCENARIO_ID}/owner`,
      table: 'cap_scenarios',
      id: () => SCENARIO_ID,
      before: () => q(`UPDATE \`${tbl('cap_scenarios')}\` SET owner_id = ? WHERE id = ?`,
        [OWNER_ID, SCENARIO_ID]),
      expect: () => OWNER_ID,
    },
  ];

  for (const verb of verbs) {
    test(`${verb.label} is not handed to a banned account`, async (t) => {
      if (guard(t)) return;
      // A banned account cannot authenticate, so it can never act on what it
      // owns — handing it a record strands that record: the ban's own audit path
      // refuses the login and no route lets the previous owner take it back.
      await seedBannedUser();
      if (verb.before) await verb.before();

      const res = await call(ADMIN, 'PATCH', verb.url(), { new_owner_id: BANNED_ID });

      // The stored column first, so a removed guard turns this red on a moved
      // record rather than on a status code.
      assert.equal(
        await storedBytes(verb.table, 'owner_id', verb.id()), verb.expect(),
        `${verb.label} was transferred to a banned account`,
      );
      assert.equal(res.status, 400, `expected a refusal, got ${JSON.stringify(res.body)}`);
      assert.match(res.body.error.message, /banned/i,
        'the refusal told the administrator the account does not exist');
    });
  }

  test('and neither is a record created through the generic CRUD path', async (t) => {
    if (guard(t)) return;
    // The route the enumeration above did not reach. The dedicated PATCH
    // endpoints are not the only way an owner column is written: an
    // administrator's POST carries its own `owner_id`, which reaches the same
    // resolver through `bindStoredOwnerId` — and that call site had a rejection
    // map of its own, written before the resolver learned to refuse a ban. It
    // folded every reason but `ambiguous` into "must be the id of an existing
    // user", so this request used to answer that a visible account did not
    // exist.
    await seedBannedUser();
    const res = await call(ADMIN, 'POST', '/edge/app/schema/user_templates',
      { name: 'for a banned owner', blueprint_id: BLUEPRINT_ID, owner_id: BANNED_ID });

    // The row count first: the sentence is secondary to the record not existing.
    assert.equal(
      await countOf(
        `SELECT COUNT(*) AS n FROM \`${tbl('user_templates')}\` WHERE name = ?`,
        ['for a banned owner'],
      ),
      0, 'a record was created owned by an account that cannot sign in',
    );
    assert.equal(res.status, 400, `expected a refusal, got ${JSON.stringify(res.body)}`);
    assert.match(res.body.error.message, /banned/i,
      'the refusal told the administrator the account does not exist');
  });

  test('a grant to a banned account is still refused, and says no more than it did', async (t) => {
    if (guard(t)) return;
    // The resolver's ban refusal replaced a second `WHERE id = ? AND banned = 0`
    // read on this path, which had become unreachable. This asserts the outcome
    // did not move with it — and that this route still declines to say WHY,
    // which is its own decision: a grantee is somebody the caller names, so
    // separating "no such person" from "that person is banned" would answer
    // questions about accounts the caller may know nothing about.
    await seedBannedUser();
    await q(`UPDATE \`${tbl('hierarchy_nodes')}\` SET owner_id = ? WHERE id = ?`,
      [OWNER_ID, BLUEPRINT_ID]);

    const res = await call(OWNER, 'POST', '/edge/app/delegated-grants',
      { scope_type: 'blueprint', scope_id: BLUEPRINT_ID, grantee_id: BANNED_ID });

    assert.equal(
      await countOf(`SELECT COUNT(*) AS n FROM \`${tbl('delegated_grants')}\``), 0,
      'a grant was stored for an account that cannot sign in',
    );
    assert.equal(res.status, 400, `expected a refusal, got ${JSON.stringify(res.body)}`);
    assert.doesNotMatch(res.body.error.message, /banned/i,
      'the grant route disclosed the reason; this one deliberately does not');
  });

  test('and an unbanned account is still a valid target', async (t) => {
    if (guard(t)) return;
    // The other direction, so the guard cannot be "refuse everybody".
    await seedBannedUser();
    const res = await call(ADMIN, 'PATCH', `/edge/app/schema/user_templates/${TEMPLATE_ID}/owner`,
      { new_owner_id: OWNER_ID });
    assert.equal(res.status, 200, `the transfer was refused: ${JSON.stringify(res.body)}`);
    assert.equal(await storedBytes('user_templates', 'owner_id', TEMPLATE_ID), OWNER_ID);
  });
});

// ── the parent-chain gate is asked of the column ────────────────────────────

describe('checkParentOwnership — an editor whose parent row holds an alias', () => {
  // Every mount that declares `parentOwnership` shares this gate, and it ended
  // in a JavaScript `===` against the caller's id while the EXISTS clause it
  // sits beside — the one appended to the UPDATE and the DELETE — folds case.
  // So the two halves of the same authorization disagreed, and the half that
  // used JavaScript refused the genuine owner.
  // The shared beforeEach does not clear this table, and both cases below
  // assert on a COUNT — so each states its own pre-state rather than inheriting
  // the previous one's row and passing (or failing) for that reason.
  const clearSections = () => q(`DELETE FROM \`${tbl('blueprint_sections')}\``);

  async function seedAliasOwnedBlueprint() {
    await clearSections();
    await q(`UPDATE \`${tbl('hierarchy_nodes')}\` SET owner_id = ? WHERE id = ?`,
      [OWNER_ALIAS, BLUEPRINT_ID]);
    assert.equal(
      await countOf(
        `SELECT COUNT(*) AS n FROM \`${tbl('hierarchy_nodes')}\` WHERE id = ? AND owner_id = ?`,
        [BLUEPRINT_ID, OWNER_ID],
      ),
      1, 'this column no longer resolves the owner under another spelling',
    );
  }

  test('may author a child row under it, and the row lands', async (t) => {
    if (guard(t)) return;
    await seedAliasOwnedBlueprint();

    const res = await call(OWNER, 'POST', '/edge/app/schema/blueprint_sections',
      { blueprint_id: BLUEPRINT_ID, section_key: 'general', display_label: 'General', sort_order: 0 });

    assert.equal(
      await countOf(`SELECT COUNT(*) AS n FROM \`${tbl('blueprint_sections')}\``), 1,
      'the owner was refused a create under their own blueprint',
    );
    assert.equal(res.status, 200, `the create was refused: ${JSON.stringify(res.body)}`);
  });

  test('and a stranger still is not, with nothing written', async (t) => {
    if (guard(t)) return;
    await clearSections();
    await q(`UPDATE \`${tbl('hierarchy_nodes')}\` SET owner_id = ? WHERE id = ?`,
      [SECOND_ID, BLUEPRINT_ID]);

    const res = await call(OWNER, 'POST', '/edge/app/schema/blueprint_sections',
      { blueprint_id: BLUEPRINT_ID, section_key: 'general', display_label: 'General', sort_order: 0 });

    assert.equal(
      await countOf(`SELECT COUNT(*) AS n FROM \`${tbl('blueprint_sections')}\``), 0,
      'a non-owner authored a row under somebody else\'s blueprint',
    );
    assert.equal(res.status, 403);
  });
});

// ── a non-canonical user id is still a user id ──────────────────────────────

describe('a deployment whose user ids are not canonical uuids', () => {
  // Measured elsewhere in this repository and recorded at `crud-factory.js`:
  // deployments exist whose `users.id` values are not uuids, and templates
  // seeded from another environment carry them. Every owner route has to reach
  // such a user or the records they own cannot be repaired at all — and the
  // generic-PUT fallback is closed by `immutableColumns: ['owner_id']`.
  const LEGACY_ID = 'legacy-user-7';

  async function seedLegacyUser() {
    await q(
      `INSERT INTO \`${tbl('users')}\` (id, email, role, banned) VALUES (?,?,?,0)`,
      [LEGACY_ID, 'legacy@test.local', 'editor'],
    );
  }

  test('a connector transfers to one, and the column holds their id', async (t) => {
    if (guard(t)) return;
    // This route refused it — the only one of the five that did, on a shape
    // floor whose stated reason (a padded id resolving the row) is answered by
    // binding the resolver's STORED id two lines later.
    await seedLegacyUser();
    await q(`UPDATE \`${tbl('hierarchy_nodes')}\` SET owner_id = NULL WHERE id = ?`, [BLUEPRINT_ID]);

    const res = await call(ADMIN, 'PATCH', `/edge/app/api-connectors/${CONNECTOR_ID}/owner`,
      { new_owner_id: LEGACY_ID });

    assert.equal(res.status, 200, `the transfer was refused: ${JSON.stringify(res.body)}`);
    assert.equal(
      await storedBytes('api_connectors', 'owner_id', CONNECTOR_ID), LEGACY_ID,
      'the connector did not reach the user it was transferred to',
    );
  });

  test('and its siblings already did', async (t) => {
    if (guard(t)) return;
    // The parity this restores, asserted rather than assumed.
    await seedLegacyUser();
    const res = await call(ADMIN, 'PATCH', `/edge/app/schema/user_templates/${TEMPLATE_ID}/owner`,
      { new_owner_id: LEGACY_ID });
    assert.equal(res.status, 200, `the transfer was refused: ${JSON.stringify(res.body)}`);
    assert.equal(await storedBytes('user_templates', 'owner_id', TEMPLATE_ID), LEGACY_ID);
  });

  test('and a value naming no user is still refused, with the owner unchanged', async (t) => {
    if (guard(t)) return;
    const res = await call(ADMIN, 'PATCH', `/edge/app/api-connectors/${CONNECTOR_ID}/owner`,
      { new_owner_id: 'nobody-at-all' });

    assert.equal(
      await storedBytes('api_connectors', 'owner_id', CONNECTOR_ID), ADMIN_ID,
      'a value naming no user moved the connector',
    );
    assert.equal(res.status, 400);
  });
});

// ── F4 — the columns that hold a row id, on a mount with no parent option ────

/**
 * `user_templates` declares none of `inheritOwnerFromParent` / `parentOwnership`
 * / `parentRepend`, which is what the factory used to derive its binding list
 * from — so its five client-supplied row references were bound by nothing. They
 * are `CHAR(36)` under a case-folding collation, so the create's own guards
 * resolve the referenced row under any spelling and the INSERT stored the
 * caller's.
 *
 * The readers that break are in the browser: the input page builds a create with
 * `parent_id` taken from a URL search param, the clone path does the same, and
 * the live preview reads the mount back with
 * `.filter(r => r.blueprint_id === blueprintId)`. Assertions are therefore on
 * the STORED BYTES — a record with a respelled `blueprint_id` is returned by
 * every list query, so nothing about the response can show the defect.
 */
describe('F4 — a template stores the id its references actually carry', () => {
  test('the premise: a respelled reference resolves the same row', async (t) => {
    if (guard(t)) return;
    assert.equal(
      await countOf(
        `SELECT COUNT(*) AS n FROM \`${tbl('hierarchy_nodes')}\` WHERE id = ?`,
        [RELEASE_TWO_ID.toUpperCase()],
      ),
      1,
      'this column no longer resolves the node under another spelling; the cases below rest on it',
    );
  });

  test('a create binds the stored spelling of every reference it carries', async (t) => {
    if (guard(t)) return;
    // A parent template whose own id carries hex letters, so "the other
    // spelling" is a different JavaScript string and the same stored row.
    const PARENT_ID = 'eabcde05-6789-4abc-8def-0123456789ab';
    await q(
      `INSERT INTO \`${tbl('user_templates')}\` (id, name, blueprint_id, owner_id) VALUES (?,?,?,?)`,
      [PARENT_ID, 'the parent', BLUEPRINT_ID, ADMIN_ID],
    );

    const created = await call(ADMIN, 'POST', '/edge/app/schema/user_templates', {
      name: 'a child template',
      blueprint_id: BLUEPRINT_ID,
      release_id: RELEASE_TWO_ID.toUpperCase(),
      parent_id: PARENT_ID.toUpperCase(),
    });
    assert.equal(created.status, 200, `the create was refused: ${JSON.stringify(created.body)}`);
    const id = created.body.data.id;

    assert.equal(
      await storedBytes('user_templates', 'release_id', id), RELEASE_TWO_ID,
      'the create stored the body\'s spelling of release_id',
    );
    assert.equal(
      await storedBytes('user_templates', 'parent_id', id), PARENT_ID,
      'the create stored the body\'s spelling of parent_id — the column the input page '
      + 'fills from a URL search param and the tree then resolves with ===',
    );
  });

  test('and so does an update', async (t) => {
    if (guard(t)) return;
    const res = await call(ADMIN, 'PUT', `/edge/app/schema/user_templates/${TEMPLATE_ID}`,
      { release_id: RELEASE_TWO_ID.toUpperCase() });
    assert.equal(res.status, 200, `the update was refused: ${JSON.stringify(res.body)}`);
    assert.equal(await storedBytes('user_templates', 'release_id', TEMPLATE_ID), RELEASE_TWO_ID);
  });

  test('binding an UPPERCASE stored id does not trip the identifier floor', async (t) => {
    if (guard(t)) return;
    // The direction that could have been made worse rather than better. The
    // identifier floor runs again on the object the statement binds
    // (`reassertWriteGates`), so if it demanded LOWERCASE the binding would take
    // a body this server had just accepted and reject it — the caller's spelling
    // passing and the stored one failing, which is a 500 on a legal write.
    // `UUID_RE` is `/i`, and this measures that rather than trusting it.
    const UPPER_PARENT = 'ABCDEF07-89AB-4CDE-8F01-23456789ABCD';
    await q(
      `INSERT INTO \`${tbl('user_templates')}\` (id, name, blueprint_id, owner_id) VALUES (?,?,?,?)`,
      [UPPER_PARENT, 'the uppercase parent', BLUEPRINT_ID, ADMIN_ID],
    );
    const created = await call(ADMIN, 'POST', '/edge/app/schema/user_templates',
      { name: 'child of an uppercase parent', blueprint_id: BLUEPRINT_ID, parent_id: UPPER_PARENT.toLowerCase() });
    assert.equal(created.status, 200, `the create was refused: ${JSON.stringify(created.body)}`);
    assert.equal(
      await storedBytes('user_templates', 'parent_id', created.body.data.id), UPPER_PARENT,
      'the binding did not take the stored spelling',
    );
  });

  test('a reference naming no row is left exactly as it was', async (t) => {
    if (guard(t)) return;
    // The binding is not a second opinion about whether a reference is legal:
    // `storedRowId` answers null for an id naming nothing, and the value passes
    // through untouched for the FK guards to judge. Asserting this keeps a
    // future "helpful" rewrite from turning a missing parent into a silent NULL.
    const orphan = 'fabcde06-789a-4bcd-8ef0-123456789abc';
    const created = await call(ADMIN, 'POST', '/edge/app/schema/user_templates',
      { name: 'points at nothing', blueprint_id: BLUEPRINT_ID, parent_id: orphan });
    assert.equal(created.status, 200, `the create was refused: ${JSON.stringify(created.body)}`);
    assert.equal(
      await storedBytes('user_templates', 'parent_id', created.body.data.id), orphan,
      'a reference naming no row was rewritten rather than left alone',
    );
  });
});
