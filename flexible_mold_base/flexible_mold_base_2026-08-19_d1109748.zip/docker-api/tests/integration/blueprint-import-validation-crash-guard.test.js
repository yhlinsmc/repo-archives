/**
 * blueprint-import-validation-crash-guard.test.js
 *
 * The import routes validate before they open a transaction, which puts that
 * validation outside the route's own try/catch. Express does not catch a
 * rejection from an async handler, so a validator that throws instead of
 * returning its rejection does not produce a 500 — the rejection goes unhandled
 * and the process exits. One small authenticated request would then be a pod
 * outage, and the client sees no response at all.
 *
 * The per-entry guards in compute-rule-validate.js close today's throw. This
 * file asserts the other half: that the ROUTE answers even when validation
 * throws something it was never written to expect, so a future change inside
 * the validator cannot reach the process again. The guard module is replaced
 * with one that throws a RangeError — an error class no import path handles —
 * before the router is loaded, which is why this lives in its own file: the
 * replacement must not leak into the tests that exercise real validation.
 */
const { describe, it, before, after } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../src/edge/db');
const guardKey = require.resolve('../../src/edge/lib/blueprint-field-import-guard');

const PREFIX = 'fmb_';

const SYNTHETIC = 'synthetic validator failure';
let inserts;

function throwSynthetic() {
  throw new RangeError(SYNTHETIC);
}

require.cache[guardKey] = {
  id: guardKey,
  filename: guardKey,
  loaded: true,
  exports: {
    checkImportedBlueprintFields: throwSynthetic,
    assertImportedBlueprintFields: throwSynthetic,
    importedRulesCycleInVariants: () => false,
  },
};

function makeConn() {
  return {
    async query(sql, params) {
      if (/^SELECT DATABASE\(\)/i.test(sql)) return [{ db: 'testdb' }];
      if (/information_schema\./i.test(sql)) return [];
      if (/FROM `fmb_hierarchy_nodes`/i.test(sql) && /WHERE id = \?/i.test(sql)) {
        return [{ id: params[0], node_type: 'release', parent_id: null }];
      }
      if (/^INSERT INTO/i.test(sql)) {
        inserts.push(sql);
        return { affectedRows: 1 };
      }
      return [];
    },
    async beginTransaction() {},
    async commit() {},
    async rollback() {},
    release() {},
  };
}

const poolSpy = {
  rw: { async getConnection() { return makeConn(); } },
  ro: { async getConnection() { return makeConn(); } },
};

require.cache[dbKey] = {
  id: dbKey,
  filename: dbKey,
  loaded: true,
  exports: { pool: poolSpy, t: (name) => `${PREFIX}${name}`, getDynamicPool: async () => poolSpy },
};

const router = require('../../src/edge/routes/app/blueprint-export');

let server;
let port;

before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { req.user = { id: 'editor-1', role: 'editor' }; next(); });
  app.use('/edge/app/schema', router);
  await new Promise((resolve) => {
    server = app.listen(0, '127.0.0.1', () => { port = server.address().port; resolve(); });
  });
});

after(async () => {
  await new Promise((resolve) => server.close(resolve));
  delete require.cache[dbKey];
  delete require.cache[guardKey];
});

function post(path, body, contentType) {
  inserts = [];
  return new Promise((resolve, reject) => {
    const req = http.request({
      method: 'POST', host: '127.0.0.1', port, path,
      headers: { 'Content-Type': contentType, 'Content-Length': Buffer.byteLength(body) },
    }, (res) => {
      let raw = '';
      res.on('data', (c) => { raw += c; });
      res.on('end', () => {
        let parsed = null;
        try { parsed = raw ? JSON.parse(raw) : null; } catch { parsed = null; }
        resolve({ status: res.statusCode, body: parsed, raw });
      });
    });
    req.on('error', reject);
    req.write(body);
    req.end();
  });
}

const JSON_PAYLOAD = JSON.stringify({
  import_version: 1,
  hierarchy_node: { id: 'node-1', name: 'My Blueprint', node_type: 'blueprint' },
  blueprint_fields: [{ id: 'f-1', field_key: 'pn', field_label: 'L', field_type: 'text' }],
  field_options: [],
  blueprint_sections: [],
  blueprint_output_order: [],
});

const YAML_PAYLOAD = 'import_version: 1\nblueprint:\n  name: My Blueprint\nfields:\n  - key: pn\n';

describe('import validation that throws is answered by the route', () => {
  it('JSON import responds instead of leaving the rejection unhandled', async () => {
    const res = await post('/edge/app/schema/blueprint-import?target_parent_id=rel-1', JSON_PAYLOAD, 'application/json');
    assert.equal(res.status, 500);
    assert.equal(res.body && res.body.error && res.body.error.code, 'INTERNAL_ERROR');
    assert.equal(inserts.length, 0, 'a failed validation must not write');
  });

  it('the response does not leak the internal failure to the client', async () => {
    const res = await post('/edge/app/schema/blueprint-import?target_parent_id=rel-1', JSON_PAYLOAD, 'application/json');
    assert.ok(!res.raw.includes(SYNTHETIC), 'internal error text must stay in the log');
  });

  it('YAML import responds instead of leaving the rejection unhandled', async () => {
    const res = await post('/edge/app/schema/blueprint-import-yaml?target_parent_id=rel-1', YAML_PAYLOAD, 'text/yaml');
    assert.equal(res.status, 500);
    assert.equal(res.body && res.body.error && res.body.error.code, 'INTERNAL_ERROR');
    assert.equal(inserts.length, 0);
  });

  it('a dry run is guarded too — it validates on the same path', async () => {
    const res = await post('/edge/app/schema/blueprint-import?dry_run=true&target_parent_id=rel-1', JSON_PAYLOAD, 'application/json');
    assert.equal(res.status, 500);
    assert.equal(inserts.length, 0);
  });
});
