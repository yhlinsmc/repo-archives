/**
 * variant-overrides-post-toctou.test.js — v3.2.107
 *
 * Verifies the TOCTOU race-only safety net at INSERT time for
 * `POST /variant_overrides`. The pre-INSERT context check already does
 * coherence/ownership validation; this test proves the guard at INSERT
 * time blocks a concurrent owner_id transfer / parent_id flip /
 * node_type flip occurring between the pre-INSERT SELECT and the
 * INSERT itself, plus best-effort triple uniqueness.
 *
 * What we prove
 * -------------
 *   (a) admin coherence-violation race      — concurrent parent_id flip
 *       mid-flight is rejected post-INSERT with 409 race_detected
 *   (b) editor OLD-ownership race           — concurrent owner_id transfer
 *       mid-flight is rejected with 409 race_detected
 *   (c) triple-uniqueness happy path        — pre-existing matching triple
 *       is rejected with 409 duplicate_exists (deterministic 50ms window
 *       since the row exists before the INSERT begins)
 *   (d) admin happy path                    — no race, INSERT succeeds 200
 *
 * What we skip (per design doc Section "Premise 5", Eng review #6)
 * ----------------------------------------------------------------
 *   - Microsecond concurrent racer simulation — without UNIQUE, NOT
 *     EXISTS is best-effort. Phase B UNIQUE migration is the structural
 *     fix; we accept loose 409 labeling under user D2 decision (a).
 *   - HTTP-level Promise.all racing — adds S2S/app-boot noise without
 *     strengthening the SQL predicate proof. Mirrors v3.2.106 design.
 *
 * Auto-detects MariaDB the same way the v3.2.106 PUT TOCTOU test does.
 * Graceful skip when no DB reachable; CI sets REQUIRE_INTEGRATION_DB=1.
 */

const { test, describe, before, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const net = require('node:net');
const mariadb = require('mariadb');

const {
  buildVariantOverrideInsertExistsClause,
  buildDuplicateActionTripleNotExistsClause,
} = require('../../src/edge/lib/variant-override-helpers');

// ── Config auto-detection (verbatim from v3.2.106 toctou test) ───────────────

function parseEnvFile(filePath) {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    const out = {};
    for (const line of content.split('\n')) {
      const m = line.match(/^\s*([A-Z_][A-Z0-9_]*)\s*=\s*(.*)\s*$/);
      if (!m) continue;
      let value = m[2];
      if ((value.startsWith('"') && value.endsWith('"')) ||
          (value.startsWith("'") && value.endsWith("'"))) {
        value = value.slice(1, -1);
      }
      out[m[1]] = value;
    }
    return out;
  } catch {
    return null;
  }
}

function probePort(host, port, timeoutMs = 2000) {
  return new Promise((resolve) => {
    const socket = new net.Socket();
    let done = false;
    const finish = (ok) => {
      if (done) return;
      done = true;
      socket.destroy();
      resolve(ok);
    };
    socket.setTimeout(timeoutMs);
    socket.once('connect', () => finish(true));
    socket.once('timeout', () => finish(false));
    socket.once('error', () => finish(false));
    socket.connect(port, host);
  });
}

async function resolveMariaDbConfig() {
  if (process.env.DB_TEST_HOST && process.env.DB_TEST_ROOT_PASSWORD) {
    return {
      host: process.env.DB_TEST_HOST,
      port: parseInt(process.env.DB_TEST_PORT || '3306', 10),
      user: 'root',
      password: process.env.DB_TEST_ROOT_PASSWORD,
    };
  }
  const envPath = path.resolve(__dirname, '../../../.devcontainer/.env');
  const env = parseEnvFile(envPath);
  if (!env || !env.DB_ROOT_PASSWORD) return null;
  const port = parseInt(env.DB_PORT || '3306', 10);
  const password = env.DB_ROOT_PASSWORD;
  const candidates = ['127.0.0.1', 'mariadb', 'localhost'];
  for (const host of candidates) {
    if (await probePort(host, port, 2000)) {
      return { host, port, user: 'root', password };
    }
  }
  return null;
}

// ── Fixture ──────────────────────────────────────────────────────────────────

const TEST_PREFIX = 'vop_'; // variant_overrides POST toctou
const TABLES_LOCAL = {
  HIERARCHY_NODES: 'hierarchy_nodes',
  BLUEPRINT_FIELDS: 'blueprint_fields',
  VARIANT_OVERRIDES: 'variant_overrides',
};
const tbl = (name) => `${TEST_PREFIX}${name}`;

const HIERARCHY_NODES_DDL = `
  CREATE TABLE \`${tbl('hierarchy_nodes')}\` (
    id          CHAR(36) PRIMARY KEY,
    name        VARCHAR(255) NOT NULL DEFAULT '',
    node_type   ENUM('generation','release','blueprint','variant') NOT NULL,
    parent_id   CHAR(36) NULL,
    owner_id    CHAR(36) NULL DEFAULT NULL,
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
`;

const BLUEPRINT_FIELDS_DDL = `
  CREATE TABLE \`${tbl('blueprint_fields')}\` (
    id            CHAR(36) PRIMARY KEY,
    blueprint_id  CHAR(36) NOT NULL,
    field_key     VARCHAR(255) NOT NULL,
    created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
`;

// v3.2.109+ shape: action NOT NULL DEFAULT '' + UNIQUE on the duplicate
// triple. Tests covering the application-layer NOT EXISTS guard still
// fire correctly under this shape; the new UNIQUE backstops duplicate
// inserts that bypass NOT EXISTS via microsecond races.
const VARIANT_OVERRIDES_DDL = `
  CREATE TABLE \`${tbl('variant_overrides')}\` (
    id             CHAR(36) PRIMARY KEY,
    variant_id     CHAR(36),
    field_id       CHAR(36),
    action         VARCHAR(100) NOT NULL DEFAULT '',
    override_value TEXT,
    created_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_variant_override_triple (variant_id, field_id, action)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
`;

const ADMIN_ID = 'admin-aaaa';
const EDITOR1_ID = 'editor-1111';
const OTHER_USER = 'editor-2222';
const BP1_ID = 'bp-1';
const V1_ID = 'v-1';
const F1_ID = 'f-1';

let dbReady = false;
let dbConfig = null;
let testDbName = null;
let skipReason = null;
let pool = null;

before(async () => {
  dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) {
    skipReason = 'no MariaDB reachable via .devcontainer/.env or env vars';
    if (process.env.REQUIRE_INTEGRATION_DB === '1') {
      throw new Error(
        `REQUIRE_INTEGRATION_DB=1 set but ${skipReason}. ` +
        'CI expected an integration database; check the test stage.',
      );
    }
    return;
  }

  testDbName = `vo_post_toctou_${process.pid}_${Date.now()}`;
  let adminConn = null;
  try {
    adminConn = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await adminConn.query(`CREATE DATABASE \`${testDbName}\``);
    await adminConn.query(`USE \`${testDbName}\``);
    await adminConn.query(HIERARCHY_NODES_DDL);
    await adminConn.query(BLUEPRINT_FIELDS_DDL);
    await adminConn.query(VARIANT_OVERRIDES_DDL);

    await adminConn.query(
      `INSERT INTO \`${tbl('hierarchy_nodes')}\` (id, name, node_type, parent_id, owner_id) VALUES
       (?, 'BP1', 'blueprint', NULL, ?),
       (?, 'V1',  'variant',   ?,    NULL)`,
      [BP1_ID, EDITOR1_ID, V1_ID, BP1_ID],
    );
    await adminConn.query(
      `INSERT INTO \`${tbl('blueprint_fields')}\` (id, blueprint_id, field_key) VALUES (?, ?, 'k1')`,
      [F1_ID, BP1_ID],
    );
    await adminConn.end();
    adminConn = null;

    pool = mariadb.createPool({
      ...dbConfig,
      database: testDbName,
      connectionLimit: 4,
      connectTimeout: 5000,
    });
    dbReady = true;
  } catch (err) {
    skipReason = `setup failed: ${err.message}`;
    if (adminConn) { try { await adminConn.end(); } catch {} }
    if (testDbName) {
      try {
        const cleanup = await mariadb.createConnection(dbConfig);
        await cleanup.query(`DROP DATABASE IF EXISTS \`${testDbName}\``);
        await cleanup.end();
      } catch {}
      testDbName = null;
    }
    if (process.env.REQUIRE_INTEGRATION_DB === '1') throw err;
  }
});

after(async () => {
  if (pool) {
    try { await pool.end(); } catch {}
    pool = null;
  }
  if (testDbName && dbConfig) {
    try {
      const cleanup = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
      await cleanup.query(`DROP DATABASE IF EXISTS \`${testDbName}\``);
      await cleanup.end();
    } catch (err) {
      console.error(`[teardown] failed to drop ${testDbName}: ${err.message}`);
    }
  }
});

// ── attemptPost — mirrors schema.js POST shape SQL-only ───────────────────────
// Pre-INSERT checks that pass at the start, mid-race mutator widens the
// race window, then INSERT ... SELECT WHERE EXISTS AND NOT EXISTS fires.

async function attemptPost({ role, voId, variantId, fieldId, action, userId, overrideValue, midRaceMutator }) {
  const conn = await pool.getConnection();
  try {
    if (midRaceMutator) await midRaceMutator();
    await new Promise((resolve) => setTimeout(resolve, 50));

    const post = buildVariantOverrideInsertExistsClause({
      role,
      variantId,
      fieldId,
      userId,
      t: (name) => `${TEST_PREFIX}${name}`,
      TABLES: TABLES_LOCAL,
    });
    const triple = buildDuplicateActionTripleNotExistsClause({
      variantId,
      fieldId,
      action,
      t: (name) => `${TEST_PREFIX}${name}`,
      TABLES: TABLES_LOCAL,
    });

    const result = await conn.query(
      `INSERT INTO \`${tbl('variant_overrides')}\` (id, variant_id, field_id, action, override_value)
       SELECT ?, ?, ?, ?, ? FROM (SELECT 1) AS insert_src
       WHERE ${post.clause} AND ${triple.clause}`,
      [voId, variantId, fieldId, action, overrideValue, ...post.params, ...triple.params],
    );

    if (result.affectedRows === 0) {
      const dupRows = await conn.query(
        `SELECT 1 FROM \`${tbl('variant_overrides')}\`
         WHERE variant_id <=> ? AND field_id <=> ? AND action <=> ? LIMIT 1`,
        [variantId, fieldId, action],
      );
      if (dupRows.length > 0) return { ok: false, status: 409, reason: 'duplicate_exists' };
      return { ok: false, status: 409, reason: 'race_detected' };
    }
    return { ok: true, status: 200 };
  } catch (err) {
    return { ok: false, status: 500, reason: err.code || err.message };
  } finally {
    conn.release();
  }
}

async function clearOverrides() {
  const conn = await pool.getConnection();
  try {
    await conn.query(`DELETE FROM \`${tbl('variant_overrides')}\``);
  } finally {
    conn.release();
  }
}

async function resetFixture() {
  const conn = await pool.getConnection();
  try {
    await conn.query(
      `UPDATE \`${tbl('hierarchy_nodes')}\` SET owner_id = ? WHERE id = ?`,
      [EDITOR1_ID, BP1_ID],
    );
    await conn.query(
      `UPDATE \`${tbl('hierarchy_nodes')}\` SET parent_id = ?, node_type = 'variant' WHERE id = ?`,
      [BP1_ID, V1_ID],
    );
  } finally {
    conn.release();
  }
}

// ── Tests ────────────────────────────────────────────────────────────────────

describe('POST /variant_overrides — TOCTOU INSERT guard', () => {
  test('(d) admin happy path — no race, INSERT succeeds', async (ctx) => {
    if (!dbReady) return ctx.skip(skipReason);
    await clearOverrides();
    await resetFixture();
    const result = await attemptPost({
      role: 'admin',
      voId: 'happy-1',
      variantId: V1_ID,
      fieldId: F1_ID,
      action: 'lock',
      userId: ADMIN_ID,
      overrideValue: 'init',
    });
    assert.equal(result.ok, true);
    assert.equal(result.status, 200);
  });

  test('(c) duplicate triple → 409 duplicate_exists', async (ctx) => {
    if (!dbReady) return ctx.skip(skipReason);
    await clearOverrides();
    await resetFixture();
    // Seed an existing matching row first
    const seedConn = await pool.getConnection();
    try {
      await seedConn.query(
        `INSERT INTO \`${tbl('variant_overrides')}\` (id, variant_id, field_id, action, override_value)
         VALUES (?, ?, ?, ?, ?)`,
        ['existing-1', V1_ID, F1_ID, 'lock', 'pre-existing'],
      );
    } finally {
      seedConn.release();
    }
    const result = await attemptPost({
      role: 'admin',
      voId: 'dup-attempt',
      variantId: V1_ID,
      fieldId: F1_ID,
      action: 'lock',
      userId: ADMIN_ID,
      overrideValue: 'second',
    });
    assert.equal(result.ok, false);
    assert.equal(result.status, 409);
    assert.equal(result.reason, 'duplicate_exists');
  });

  test('(a) admin coherence-violation race — parent_id flip mid-flight → 409 race_detected', async (ctx) => {
    if (!dbReady) return ctx.skip(skipReason);
    await clearOverrides();
    await resetFixture();
    const result = await attemptPost({
      role: 'admin',
      voId: 'race-a',
      variantId: V1_ID,
      fieldId: F1_ID,
      action: 'lock',
      userId: ADMIN_ID,
      overrideValue: 'attempted',
      midRaceMutator: async () => {
        // Concurrent flip: V1.parent_id → null (orphan), breaks coherence
        // (variant.parent_id no longer matches field.blueprint_id).
        const mutConn = await pool.getConnection();
        try {
          await mutConn.query(
            `UPDATE \`${tbl('hierarchy_nodes')}\` SET parent_id = NULL WHERE id = ?`,
            [V1_ID],
          );
        } finally {
          mutConn.release();
        }
      },
    });
    assert.equal(result.ok, false);
    assert.equal(result.status, 409);
    assert.equal(result.reason, 'race_detected');
  });

  test('(b) editor ownership race — owner transferred mid-flight → 409 race_detected', async (ctx) => {
    if (!dbReady) return ctx.skip(skipReason);
    await clearOverrides();
    await resetFixture();
    const result = await attemptPost({
      role: 'editor',
      voId: 'race-b',
      variantId: V1_ID,
      fieldId: F1_ID,
      action: 'lock',
      userId: EDITOR1_ID,
      overrideValue: 'attempted',
      midRaceMutator: async () => {
        // Concurrent ownership transfer: BP1.owner_id → OTHER_USER.
        // Editor's INSERT-time predicate (bp.owner_id = ?) now fails.
        const mutConn = await pool.getConnection();
        try {
          await mutConn.query(
            `UPDATE \`${tbl('hierarchy_nodes')}\` SET owner_id = ? WHERE id = ?`,
            [OTHER_USER, BP1_ID],
          );
        } finally {
          mutConn.release();
        }
      },
    });
    assert.equal(result.ok, false);
    assert.equal(result.status, 409);
    assert.equal(result.reason, 'race_detected');
  });

  test('post-INSERT row count matches expected (admin happy + 3 race-rejected)', async (ctx) => {
    if (!dbReady) return ctx.skip(skipReason);
    // After all four scenarios above, only the (d) happy path inserted.
    // (c) was blocked by triple uniqueness (seeded row remains).
    // (a) and (b) were blocked by post-state coherence/ownership.
    const conn = await pool.getConnection();
    try {
      const rows = await conn.query(
        `SELECT id FROM \`${tbl('variant_overrides')}\` ORDER BY created_at`,
      );
      // Last test left exactly the seeded "existing-1" row (clearOverrides
      // ran at start of (b), and (b)'s INSERT was blocked).
      assert.equal(rows.length, 0, 'last clearOverrides + blocked INSERT leaves zero rows');
    } finally {
      conn.release();
    }
  });

  test('UNIQUE backstops the application-layer NOT EXISTS check (1062 ER_DUP_ENTRY)', async (ctx) => {
    if (!dbReady) return ctx.skip(skipReason);
    await clearOverrides();
    await resetFixture();

    // Insert the first row directly (bypass attemptPost so we control the
    // path). Then attempt a second direct INSERT of the same triple.
    // Without uq_variant_override_triple the second INSERT would land;
    // with the constraint, MariaDB rejects it with errno 1062. The POST
    // handler maps this to 409 duplicate_exists; the SQL-level assert
    // here proves the schema-side backstop is wired even if a future
    // refactor removes the application-layer NOT EXISTS pre-flight.
    const seedConn = await pool.getConnection();
    try {
      await seedConn.query(
        `INSERT INTO \`${tbl('variant_overrides')}\` (id, variant_id, field_id, action, override_value)
         VALUES (?, ?, ?, ?, ?)`,
        ['unique-1', V1_ID, F1_ID, 'lock', 'first'],
      );
      let dupErrno = null;
      try {
        await seedConn.query(
          `INSERT INTO \`${tbl('variant_overrides')}\` (id, variant_id, field_id, action, override_value)
           VALUES (?, ?, ?, ?, ?)`,
          ['unique-2', V1_ID, F1_ID, 'lock', 'second'],
        );
      } catch (err) {
        dupErrno = err.errno || null;
      }
      assert.equal(dupErrno, 1062, 'UNIQUE must reject duplicate triple INSERT with errno 1062');
    } finally {
      seedConn.release();
    }
    await clearOverrides();
  });
});
