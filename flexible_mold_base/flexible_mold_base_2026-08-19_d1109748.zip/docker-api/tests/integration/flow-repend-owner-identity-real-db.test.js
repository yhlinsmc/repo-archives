'use strict';

/**
 * flow-repend-owner-identity-real-db.test.js — an approval does not survive a
 * step write, whichever way the writer spells their own id.
 *
 * WHAT THIS FILE IS ABOUT. Writing a step of a `flow_recipe` is admitted by SQL
 * on every verb: the `parentOwnership` chain SELECT the POST runs, and the chain
 * EXISTS appended to the editor's UPDATE and DELETE. `flow_recipes.owner_id` is
 * `CHAR(36)` under `utf8mb4_general_ci`, so all three admit an editor whose
 * stored `owner_id` differs from the id in their token ONLY in case. The gate
 * that runs next — `repandParentInTx`, which clears the parent recipe's approval
 * so a step the approver never saw cannot ride an approved recipe — decided the
 * same question with a JavaScript `!==`, and therefore skipped for exactly the
 * caller SQL had just admitted.
 *
 * The end state that produced is the one `repandParentInTx`'s own comment names
 * as the thing it exists to prevent: an APPROVED recipe carrying a swapped step.
 * Measured on a scratch database before the fix — POST 200, step inserted,
 * `status` still `approved` and `approved_by` still set.
 *
 * WHY THE ASSERTIONS ARE ON STORED VALUES AND ROW COUNTS. Every one of these
 * requests answers 200 both before and after the fix; the status code cannot see
 * the defect at all. What moves is what the parent row holds afterwards, so that
 * is what is read back. A mocked driver would answer "what did that UPDATE do"
 * with whatever the fixture was told to say and could show none of it.
 *
 * THE THIRD CASE IS THE ONE THAT KEEPS THE FIX HONEST. Widening a gate that
 * refuses is only correct if the population it refuses is unchanged, so a
 * stranger is exercised on every verb and asserted to write nothing AND to leave
 * the approval standing.
 *
 * Skips with a stated reason when no database is reachable, and FAILS instead of
 * skipping when REQUIRE_INTEGRATION_DB=1 — a silent skip is the failure mode
 * this whole line of work exists to end.
 */
const {
  test, describe, before, after, beforeEach,
} = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const net = require('node:net');
const http = require('node:http');
const express = require('express');
const mariadb = require('mariadb');

const TEST_PREFIX = 'frp_';
const tbl = (name) => `${TEST_PREFIX}${name}`;

let pool = null;
const lease = () => pool.getConnection();
// Both halves of the real pool object: the CRUD factory leases a connection for
// its write transaction AND the read-scope middleware calls `pool.ro.query`
// directly. A stand-in offering only one of the two turns whichever gate takes
// the other path into a 500 that reads like a refusal.
const handle = () => ({ getConnection: lease, query: (sql, params) => pool.query(sql, params) });

const dbKey = require.resolve('../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey,
  filename: dbKey,
  loaded: true,
  exports: {
    pool: { ro: handle(), rw: handle() },
    t: tbl,
    getDynamicPool: async () => ({ ro: handle(), rw: handle() }),
  },
};

const { buildEngineTableDDLs, buildInfraTableDDLs } = require('../../src/table-ddls');
const stepsRouter = require('../../src/edge/routes/app/flow-recipe-steps');
const recipesRouter = require('../../src/edge/routes/app/flow-recipes');

// ── Config auto-detection (same shape as the sibling integration tests) ──────

function parseEnvFile(filePath) {
  try {
    const out = {};
    for (const line of fs.readFileSync(filePath, 'utf-8').split('\n')) {
      const m = line.match(/^\s*([A-Z_][A-Z0-9_]*)\s*=\s*(.*)\s*$/);
      if (!m) continue;
      let value = m[2];
      if ((value.startsWith('"') && value.endsWith('"'))
        || (value.startsWith("'") && value.endsWith("'"))) {
        value = value.slice(1, -1);
      }
      out[m[1]] = value;
    }
    return out;
  } catch {
    return null;
  }
}

function probePort(host, port, timeoutMs = 2000) {
  return new Promise((resolve) => {
    const socket = new net.Socket();
    let done = false;
    const finish = (ok) => {
      if (done) return;
      done = true;
      socket.destroy();
      resolve(ok);
    };
    socket.setTimeout(timeoutMs);
    socket.once('connect', () => finish(true));
    socket.once('timeout', () => finish(false));
    socket.once('error', () => finish(false));
    socket.connect(port, host);
  });
}

async function resolveMariaDbConfig() {
  if (process.env.DB_TEST_HOST && process.env.DB_TEST_ROOT_PASSWORD) {
    return {
      host: process.env.DB_TEST_HOST,
      port: parseInt(process.env.DB_TEST_PORT || '3306', 10),
      user: 'root',
      password: process.env.DB_TEST_ROOT_PASSWORD,
    };
  }
  const env = parseEnvFile(path.resolve(__dirname, '../../../.devcontainer/.env'));
  if (!env || !env.DB_ROOT_PASSWORD) return null;
  const port = parseInt(env.DB_PORT || '3306', 10);
  for (const host of ['127.0.0.1', 'mariadb', 'localhost']) {
    if (await probePort(host, port, 2000)) {
      return { host, port, user: 'root', password: env.DB_ROOT_PASSWORD };
    }
  }
  return null;
}

// ── Fixture ─────────────────────────────────────────────────────────────────

// Hex LETTERS, deliberately: a uuid of digits only has one spelling, so a
// fixture built from one could not exercise the defect at all.
const EDITOR_STORED = 'C0FFEE11-2345-4789-ABCD-EF0123456789';
const EDITOR_ALIAS = EDITOR_STORED.toLowerCase();
const STRANGER_ID = 'dddddaa1-2345-4789-abcd-ef0123456789';
const ADMIN_ID = 'cdefab03-4567-49ab-8def-ab0123456789';

const RECIPE_ID = 'aaaaaaa1-1111-4111-8111-111111111111';
const BLUEPRINT_ID = 'bbbbbbb2-2222-4222-8222-222222222222';
const RELEASE_ID = 'ccccccc3-3333-4333-8333-333333333333';
const SEEDED_STEP_ID = 'eeeeeee5-5555-4555-8555-555555555555';

// The editor as the row spells them, and the same editor as their token spells
// them. Same person, same stored row, two JavaScript strings.
const EDITOR_AS_STORED = { id: EDITOR_STORED, role: 'editor' };
const EDITOR_AS_ALIAS = { id: EDITOR_ALIAS, role: 'editor' };
const STRANGER = { id: STRANGER_ID, role: 'editor' };

let dbReady = false;
let skipReason = null;
let testDbName = null;
let server = null;
let baseUrl = null;
let currentUser = EDITOR_AS_STORED;

before(async () => {
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) {
    skipReason = 'no MariaDB reachable via .devcontainer/.env or env vars';
    if (process.env.REQUIRE_INTEGRATION_DB === '1') {
      throw new Error(`REQUIRE_INTEGRATION_DB=1 set but ${skipReason}.`);
    }
    return;
  }
  testDbName = `flow_repend_test_${process.pid}_${Date.now()}`;
  let admin = null;
  try {
    admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`CREATE DATABASE \`${testDbName}\``);
    await admin.query(`USE \`${testDbName}\``);
    // Every table, built from the DDL that creates the real ones. A hand-picked
    // subset drops a table some guard probes and turns its refusal into a
    // degrade nobody asked for.
    for (const sql of [...buildInfraTableDDLs(tbl), ...buildEngineTableDDLs(tbl)]) {
      await admin.query(sql);
    }
    await admin.end();
    admin = null;

    pool = mariadb.createPool({
      ...dbConfig, database: testDbName, connectionLimit: 6, connectTimeout: 5000,
    });

    const app = express();
    app.use(express.json());
    app.use((req, _res, next) => { req.user = currentUser; next(); });
    app.use('/edge/app/flow-recipe-steps', stepsRouter);
    app.use('/edge/app/flow-recipes', recipesRouter);
    server = http.createServer(app);
    await new Promise((r) => server.listen(0, r));
    baseUrl = `http://127.0.0.1:${server.address().port}`;
    dbReady = true;
  } catch (err) {
    skipReason = `setup failed: ${err.message}`;
    if (admin) { try { await admin.end(); } catch { /* best effort */ } }
    if (process.env.REQUIRE_INTEGRATION_DB === '1') throw err;
  }
});

after(async () => {
  if (server) { try { server.close(); } catch { /* best effort */ } }
  if (pool) { try { await pool.end(); } catch { /* best effort */ } }
  if (!testDbName) return;
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) return;
  try {
    const admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`DROP DATABASE IF EXISTS \`${testDbName}\``);
    await admin.end();
  } catch { /* best effort */ }
});

async function call(user, method, url, body) {
  currentUser = user;
  const res = await fetch(`${baseUrl}${url}`, {
    method,
    headers: { 'content-type': 'application/json' },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const text = await res.text();
  let parsed = null;
  try { parsed = JSON.parse(text); } catch { parsed = { raw: text }; }
  return { status: res.status, body: parsed };
}

const q = (sql, params) => pool.query(sql, params);
const one = async (sql, params) => (await pool.query(sql, params))[0];
const countOf = async (sql, params) => Number((await one(sql, params)).n);

const guard = (t) => {
  if (dbReady) return false;
  t.skip(skipReason || 'database not ready');
  return true;
};

/** The stored bytes of one column, read back with no folding. */
async function storedBytesOf(table, column, id) {
  const row = await one(
    `SELECT CAST(\`${column}\` AS BINARY) AS v FROM \`${tbl(table)}\` WHERE id = ?`, [id],
  );
  if (!row || row.v == null) return null;
  return Buffer.isBuffer(row.v) ? row.v.toString('utf8') : String(row.v);
}

/** The parent recipe's approval state, read back as stored. */
async function approvalState() {
  const row = await one(
    `SELECT status, CAST(approved_by AS BINARY) AS approved_by, approved_at
       FROM \`${tbl('flow_recipes')}\` WHERE id = ?`,
    [RECIPE_ID],
  );
  const approvedBy = row.approved_by == null ? null
    : (Buffer.isBuffer(row.approved_by) ? row.approved_by.toString('utf8') : String(row.approved_by));
  return { status: row.status, approvedBy, approvedAt: row.approved_at == null ? null : 'set' };
}

const stepCount = () => countOf(
  `SELECT COUNT(*) AS n FROM \`${tbl('flow_recipe_steps')}\` WHERE recipe_id = ?`, [RECIPE_ID],
);

const stepBody = (name) => ({
  recipe_id: RECIPE_ID, name, url: 'https://example.invalid/x', method: 'POST',
});

beforeEach(async () => {
  if (!dbReady) return;
  for (const name of ['flow_recipe_steps', 'flow_recipes', 'feature_audit', 'hierarchy_nodes', 'users']) {
    await q(`DELETE FROM \`${tbl(name)}\``);
  }
  await q(
    `INSERT INTO \`${tbl('users')}\` (id, email, role, banned) VALUES (?,?,?,0),(?,?,?,0),(?,?,?,0)`,
    [EDITOR_STORED, 'editor@test.local', 'editor',
      STRANGER_ID, 'stranger@test.local', 'editor',
      ADMIN_ID, 'admin@test.local', 'admin'],
  );
  await q(
    `INSERT INTO \`${tbl('hierarchy_nodes')}\` (id, parent_id, name, node_type) VALUES (?,?,?,?)`,
    [RELEASE_ID, null, 'release', 'release'],
  );
  // The blueprint is SHARED (owner NULL) on purpose: this file is about the
  // RECIPE's owner deciding the re-pend, and a blueprint owned by somebody would
  // let the recipe mount's own chain refuse first, for a reason that has nothing
  // to do with what is under test.
  await q(
    `INSERT INTO \`${tbl('hierarchy_nodes')}\` (id, parent_id, name, node_type, owner_id) VALUES (?,?,?,?,?)`,
    [BLUEPRINT_ID, RELEASE_ID, 'a blueprint', 'blueprint', null],
  );
  await q(
    `INSERT INTO \`${tbl('flow_recipes')}\`
       (id, name, owner_id, blueprint_id, status, approved_by, approved_at)
     VALUES (?,?,?,?,'approved',?,NOW())`,
    [RECIPE_ID, 'a recipe', EDITOR_STORED, BLUEPRINT_ID, ADMIN_ID],
  );
});

// ── The premise, stated mechanically ────────────────────────────────────────

describe('the premise: the owner column folds case, so SQL admits the alias', () => {
  test('the recipe stores one spelling and SQL resolves it from the other', async (t) => {
    if (guard(t)) return;
    // What the row actually holds — not the spelling the caller will use.
    const stored = await one(
      `SELECT CAST(owner_id AS BINARY) AS v FROM \`${tbl('flow_recipes')}\` WHERE id = ?`,
      [RECIPE_ID],
    );
    const bytes = Buffer.isBuffer(stored.v) ? stored.v.toString('utf8') : String(stored.v);
    assert.equal(bytes, EDITOR_STORED);
    assert.notEqual(EDITOR_ALIAS, EDITOR_STORED, 'the two spellings must differ as JS strings');
    // …and yet the engine resolves the row from the other spelling. Both halves
    // of the premise: the bytes differ, the column calls them one value. Every
    // case below is downstream of this being true.
    assert.equal(
      await countOf(
        `SELECT COUNT(*) AS n FROM \`${tbl('flow_recipes')}\` WHERE id = ? AND owner_id = ?`,
        [RECIPE_ID, EDITOR_ALIAS],
      ),
      1,
    );
  });
});

// ── The defect: the approval must not survive the write SQL admitted ────────

describe('an approved recipe loses its approval when a step is written', () => {
  test('POST by the owner spelling their id the way the row does', async (t) => {
    if (guard(t)) return;
    const res = await call(EDITOR_AS_STORED, 'POST', '/edge/app/flow-recipe-steps/', stepBody('control'));
    assert.equal(res.status, 200);
    assert.equal(await stepCount(), 1);
    assert.deepEqual(await approvalState(), { status: 'pending', approvedBy: null, approvedAt: null });
  });

  test('POST by the SAME owner spelling their id the other way', async (t) => {
    if (guard(t)) return;
    // The whole finding. This request is admitted — the chain SELECT folds case
    // — so the step lands; the question is only whether the approval goes with
    // it. Before the fix: 200, one step, and `status` still `approved`.
    const res = await call(EDITOR_AS_ALIAS, 'POST', '/edge/app/flow-recipe-steps/', stepBody('the alias'));
    assert.equal(res.status, 200);
    assert.equal(await stepCount(), 1, 'the write is admitted — that is the premise, not the defect');
    assert.deepEqual(
      await approvalState(), { status: 'pending', approvedBy: null, approvedAt: null },
      'an approved recipe kept its approval across a step its approver never saw',
    );
  });

  test('PUT by the owner under the other spelling — the verb with no preWriteInTx', async (t) => {
    if (guard(t)) return;
    // This mount declares no `preWriteInTx`, so the factory's early
    // `checkParentOwnership` never runs on a PUT and the chain EXISTS appended
    // to the UPDATE is the only thing that admits. It folds, so this write has
    // always landed; the re-pend beside it has always been the JavaScript one.
    await q(
      `INSERT INTO \`${tbl('flow_recipe_steps')}\` (id, recipe_id, name, url, method) VALUES (?,?,?,?,?)`,
      [SEEDED_STEP_ID, RECIPE_ID, 'seeded', 'https://example.invalid/x', 'POST'],
    );
    const res = await call(EDITOR_AS_ALIAS, 'PUT',
      `/edge/app/flow-recipe-steps/${SEEDED_STEP_ID}`, { name: 'renamed by the alias' });
    assert.equal(res.status, 200);
    const nameNow = (await one(
      `SELECT name FROM \`${tbl('flow_recipe_steps')}\` WHERE id = ?`, [SEEDED_STEP_ID],
    )).name;
    assert.equal(nameNow, 'renamed by the alias', 'the write is admitted — the premise');
    assert.deepEqual(await approvalState(), { status: 'pending', approvedBy: null, approvedAt: null });
  });

  test('DELETE by the owner under the other spelling', async (t) => {
    if (guard(t)) return;
    await q(
      `INSERT INTO \`${tbl('flow_recipe_steps')}\` (id, recipe_id, name, url, method) VALUES (?,?,?,?,?)`,
      [SEEDED_STEP_ID, RECIPE_ID, 'seeded', 'https://example.invalid/x', 'POST'],
    );
    const res = await call(EDITOR_AS_ALIAS, 'DELETE', `/edge/app/flow-recipe-steps/${SEEDED_STEP_ID}`);
    assert.equal(res.status, 200);
    assert.equal(await stepCount(), 0, 'the delete is admitted — the premise');
    assert.deepEqual(await approvalState(), { status: 'pending', approvedBy: null, approvedAt: null });
  });
});

// ── The other direction: nothing about a stranger changed ───────────────────

describe('a stranger is still refused, writes nothing, and moves no approval', () => {
  test('POST is refused and the recipe keeps its approval', async (t) => {
    if (guard(t)) return;
    const res = await call(STRANGER, 'POST', '/edge/app/flow-recipe-steps/', stepBody('by a stranger'));
    assert.equal(res.status, 403);
    assert.equal(await stepCount(), 0);
    // The approval standing is the assertion that matters: a re-pend fired by a
    // caller who may not write the child would be a way to strip anyone's
    // approval, which is what the owner gate inside the re-pend is for.
    assert.equal((await approvalState()).status, 'approved');
  });

  test('PUT and DELETE are refused, the row is untouched, and the approval stands', async (t) => {
    if (guard(t)) return;
    await q(
      `INSERT INTO \`${tbl('flow_recipe_steps')}\` (id, recipe_id, name, url, method) VALUES (?,?,?,?,?)`,
      [SEEDED_STEP_ID, RECIPE_ID, 'seeded', 'https://example.invalid/x', 'POST'],
    );
    const put = await call(STRANGER, 'PUT',
      `/edge/app/flow-recipe-steps/${SEEDED_STEP_ID}`, { name: 'stranger rename' });
    assert.equal(put.status, 404); // existence-leak parity: this path answers 404
    assert.equal(
      (await one(`SELECT name FROM \`${tbl('flow_recipe_steps')}\` WHERE id = ?`, [SEEDED_STEP_ID])).name,
      'seeded',
    );
    const del = await call(STRANGER, 'DELETE', `/edge/app/flow-recipe-steps/${SEEDED_STEP_ID}`);
    assert.equal(del.status, 404);
    assert.equal(await stepCount(), 1);
    assert.equal((await approvalState()).status, 'approved');
  });
});

// ── The read half of the same question ──────────────────────────────────────

describe('the reader admits exactly the caller the writer admits', () => {
  test('the owner under the other spelling can read the steps they may write', async (t) => {
    if (guard(t)) return;
    await q(
      `INSERT INTO \`${tbl('flow_recipe_steps')}\` (id, recipe_id, name, url, method) VALUES (?,?,?,?,?)`,
      [SEEDED_STEP_ID, RECIPE_ID, 'seeded', 'https://example.invalid/x', 'POST'],
    );
    // Before the fix both of these were 403 for a caller the POST answered 200:
    // one question, two answers, split down the middle of a single mount.
    const list = await call(EDITOR_AS_ALIAS, 'GET', `/edge/app/flow-recipe-steps/?recipe_id=${RECIPE_ID}`);
    assert.equal(list.status, 200);
    assert.equal(list.body.data.length, 1);
    const single = await call(EDITOR_AS_ALIAS, 'GET', `/edge/app/flow-recipe-steps/${SEEDED_STEP_ID}`);
    assert.equal(single.status, 200);
    assert.equal(single.body.data.id, SEEDED_STEP_ID);
  });

  test('a stranger still cannot read either shape', async (t) => {
    if (guard(t)) return;
    await q(
      `INSERT INTO \`${tbl('flow_recipe_steps')}\` (id, recipe_id, name, url, method) VALUES (?,?,?,?,?)`,
      [SEEDED_STEP_ID, RECIPE_ID, 'seeded', 'https://example.invalid/x', 'POST'],
    );
    const list = await call(STRANGER, 'GET', `/edge/app/flow-recipe-steps/?recipe_id=${RECIPE_ID}`);
    assert.equal(list.status, 403);
    const single = await call(STRANGER, 'GET', `/edge/app/flow-recipe-steps/${SEEDED_STEP_ID}`);
    assert.equal(single.status, 403);
  });
});

// ── F7 — the mount whose only transfer route is the generic PUT ─────────────

/**
 * `immutableColumns: ['owner_id']` gives a mount exactly one route to an
 * ownership change — the dedicated endpoint, which refuses a target who could
 * not act on the record and writes a `feature_audit` row. That strip is scoped
 * to the mounts that HAVE such an endpoint, and `flow_recipes` does not: its
 * generic PUT is the only way its owner can ever change.
 *
 * So the shared binding has to establish the same facts. It already resolved the
 * target to a real, canonical, non-banned user; it did not check that the target
 * may hold a recipe at all, and it recorded nothing. Handing a recipe to a plain
 * `user` left it owned by somebody the mount's own admin-or-editor gate then
 * refuses — an unusable record, with nothing saying how it got that way.
 */
describe('F7 — a recipe handed over through the generic PUT', () => {
  const PLAIN_USER_ID = 'baddaa11-2345-4789-abcd-ef0123456789';
  const OTHER_EDITOR_ID = 'ceedaa22-3456-4789-abcd-ef0123456789';

  const seedTargets = () => q(
    `INSERT INTO \`${tbl('users')}\` (id, email, role, banned) VALUES (?,?,?,0),(?,?,?,0)`,
    [PLAIN_USER_ID, 'plain@test.local', 'user', OTHER_EDITOR_ID, 'other@test.local', 'editor'],
  );

  const auditRows = () => q(
    `SELECT metadata FROM \`${tbl('feature_audit')}\` WHERE event_type = 'flow_recipes.owner.transfer'`,
  );
  const ownerNow = () => storedBytesOf('flow_recipes', 'owner_id', RECIPE_ID);

  test('is refused when the new owner could not act on it', async (t) => {
    if (guard(t)) return;
    await seedTargets();
    const res = await call({ id: ADMIN_ID, role: 'admin' }, 'PUT',
      `/edge/app/flow-recipes/${RECIPE_ID}`, { owner_id: PLAIN_USER_ID });

    // The stored column first: a refusal that still moved the row is the failure
    // this is about, and the status code cannot see it.
    assert.equal(await ownerNow(), EDITOR_STORED, 'the recipe was handed to a role that cannot edit it');
    assert.equal(res.status, 400, `expected a refusal, got ${JSON.stringify(res.body)}`);
    assert.match(res.body.error.message, /admin or editor/i);
    assert.equal((await auditRows()).length, 0, 'a refused transfer left a trail claiming it happened');
  });

  test('is allowed to an editor, and leaves a trail naming both ends', async (t) => {
    if (guard(t)) return;
    await seedTargets();
    const res = await call({ id: ADMIN_ID, role: 'admin' }, 'PUT',
      `/edge/app/flow-recipes/${RECIPE_ID}`, { owner_id: OTHER_EDITOR_ID });
    assert.equal(res.status, 200, `the transfer was refused: ${JSON.stringify(res.body)}`);
    assert.equal(await ownerNow(), OTHER_EDITOR_ID);

    const audit = await auditRows();
    assert.equal(audit.length, 1, 'the only route to a transfer on this mount recorded nothing');
    const meta = typeof audit[0].metadata === 'string' ? JSON.parse(audit[0].metadata) : audit[0].metadata;
    assert.equal(meta.row_id, RECIPE_ID);
    assert.equal(meta.old_owner_id, EDITOR_STORED);
    assert.equal(meta.new_owner_id, OTHER_EDITOR_ID);
    assert.equal(meta.actor_role, 'admin');
  });

  test('a transfer names the target by the spelling that user row carries', async (t) => {
    if (guard(t)) return;
    await seedTargets();
    const res = await call({ id: ADMIN_ID, role: 'admin' }, 'PUT',
      `/edge/app/flow-recipes/${RECIPE_ID}`, { owner_id: OTHER_EDITOR_ID.toUpperCase() });
    assert.equal(res.status, 200, `the transfer was refused: ${JSON.stringify(res.body)}`);
    assert.equal(await ownerNow(), OTHER_EDITOR_ID, 'the column stored the body\'s spelling');
  });

  test('a save that does not move the owner writes no trail', async (t) => {
    if (guard(t)) return;
    // A trail row per save would make the record of a handover impossible to
    // find among the ordinary edits.
    await seedTargets();
    const res = await call({ id: ADMIN_ID, role: 'admin' }, 'PUT',
      `/edge/app/flow-recipes/${RECIPE_ID}`, { name: 'renamed, same owner' });
    assert.equal(res.status, 200, `the save was refused: ${JSON.stringify(res.body)}`);
    assert.equal(await ownerNow(), EDITOR_STORED);
    assert.equal((await auditRows()).length, 0);

    // …and neither does re-sending the owner it already has.
    const again = await call({ id: ADMIN_ID, role: 'admin' }, 'PUT',
      `/edge/app/flow-recipes/${RECIPE_ID}`, { owner_id: EDITOR_STORED });
    assert.equal(again.status, 200, `the save was refused: ${JSON.stringify(again.body)}`);
    assert.equal((await auditRows()).length, 0);
  });
});
