'use strict';

/**
 * infra-impersonation-gate.test.js
 *
 * Integration test that boots the REAL infra Express app against a stub edge
 * server. Proves two properties that unit tests cannot:
 *
 *  1. A non-admin sending x-impersonate-user-id cannot impersonate
 *     (header ignored — response is never IMPERSONATION_READ_ONLY).
 *  2. The impersonation read-only gate is mounted AFTER auth (mount-order)
 *     and 403s an admin's impersonated write BEFORE it reaches edge.
 *
 * Zero new npm deps — uses node core http + native fetch.
 * No MariaDB needed — infra never touches DB; edge is stubbed.
 */

// ── Env must be set BEFORE any src/ module is required ──────────────────────
process.env.SUPPRESS_INFRA_BOOT = '1';
process.env.API_ROLE = 'infra';
process.env.PORT = '13211';
process.env.EDGE_API_URL = 'http://127.0.0.1:13212';
process.env.JWT_SECRET = 'test-secret-for-impersonation-gate-tests';
process.env.S2S_API_KEY = 'test-s2s-key-for-impersonation-gate-tests';
process.env.APP_NAME = 'TestApp';
process.env.BASE_URL = 'http://localhost:13211';
process.env.FRONTEND_URL = 'http://localhost:3000';
process.env.NODE_ENV = 'test';
process.env.DISABLE_RATE_LIMIT = 'true';
// No KEYCLOAK_ISSUER_BASE_URL → auth mode stays local.
delete process.env.KEYCLOAK_ISSUER_BASE_URL;
delete process.env.KEYCLOAK_CLIENT_ID;
delete process.env.KEYCLOAK_CLIENT_SECRET;
delete process.env.KEYCLOAK_SECRET;

const { describe, it, before, after } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const { signHs256 } = require('../helpers/jwt-hs256');

// Undici is bundled with Node 18+ as the native fetch implementation.
// We use it here solely to create an HTTPS dispatcher that skips self-signed
// cert verification — the dev container has a real cert at
// .devcontainer/certs/dev.cert which makes the infra server boot as HTTPS.
const { Agent, fetch: undiciFetch, setGlobalDispatcher, getGlobalDispatcher } = require('undici');

// Set a global dispatcher that does NOT verify TLS — test-only, self-signed certs.
// AIRGAP rule: undici is a built-in Node module, zero new npm deps.
const _originalDispatcher = getGlobalDispatcher();
const _tlsInsecureAgent = new Agent({ connect: { rejectUnauthorized: false } });
setGlobalDispatcher(_tlsInsecureAgent);

// ── Stub edge identities ──────────────────────────────────────────────────────
const IDENTITIES = {
  'admin-1': { id: 'admin-1', email: 'admin@test.local', role: 'admin' },
  'user-9':  { id: 'user-9',  email: 'user@test.local',  role: 'user'  },
};

// ── Startup guard — only bootstrap once per process ──────────────────────────
let _started = false;

// ── Infra server handle capture + listen-complete promise ────────────────────
// bootstrap() calls server.listen(PORT, cb) but does NOT return the server.
// Problem: node:test tracks async activity started in before() hooks. When
// server.listen() is called fire-and-forget inside before(), the listen handle
// outlives the before() scope → node:test detects it as a leaked activity and
// marks the file-level test as failed even though all 3 test assertions pass.
//
// Fix (no production code change): intercept net.Server.prototype.listen to
// (a) capture the server ref for cleanup in after(), and (b) resolve a Promise
// when listen fires so before() can properly AWAIT the listen completion,
// keeping the handle fully inside before()'s async scope.
const net = require('node:net');
let _infraServer = null;
let _infraListenResolve = null;
const _infraListenReady = new Promise(resolve => { _infraListenResolve = resolve; });
const _origListen = net.Server.prototype.listen;
net.Server.prototype.listen = function patchedListen(...args) {
  // Capture every server that binds to INFRA_PORT (13211).
  const portArg = args.find(a => typeof a === 'number' || (typeof a === 'string' && /^\d+$/.test(a)));
  if (String(portArg) === String(13211)) {
    _infraServer = this;
    // Wrap the user-supplied callback (last arg if function) so we get
    // notified when listen completes without removing the original callback.
    const cbIdx = args.findLastIndex(a => typeof a === 'function');
    const originalCb = cbIdx >= 0 ? args[cbIdx] : null;
    const wrappedCb = function (...cbArgs) {
      _infraListenResolve?.();
      if (originalCb) originalCb.apply(this, cbArgs);
    };
    if (cbIdx >= 0) {
      args = [...args];
      args[cbIdx] = wrappedCb;
    } else {
      // No callback provided — attach via 'listening' event instead
      this.once('listening', () => _infraListenResolve?.());
    }
  }
  return _origListen.apply(this, args);
};

// ── Stub edge server (port 13212) ─────────────────────────────────────────────
let stubEdge;

function startStubEdge() {
  return new Promise((resolve, reject) => {
    stubEdge = http.createServer((req, res) => {
      let body = '';
      req.on('data', chunk => { body += chunk; });
      req.on('end', () => {
        res.setHeader('Content-Type', 'application/json');

        // GET /edge/health → pool-state cache uses this
        if (req.method === 'GET' && req.url === '/edge/health') {
          return res.end(JSON.stringify({
            api: 'ok',
            role: 'edge',
            db: 'ok',
            pool: {
              pool_state: 'configured',
              hint_code: null,
              env_keys_present: { DB_RW_HOST: true, DB_RW_USER: true, DB_RW_PASSWORD: true, DB_RW_NAME: true },
              db_config_json_present: true,
              table_prefix_set: true,
              last_configure_error: null,
            },
          }));
        }

        // GET /edge/internal/system/auth-mode → called at boot + per-request access-check
        if (req.method === 'GET' && req.url === '/edge/internal/system/auth-mode') {
          return res.end(JSON.stringify({
            auth_mode: 'local',
            source: 'stub',
            pool_ready: true,
          }));
        }

        // POST /edge/internal/auth/identity-resolve → auth middleware
        if (req.method === 'POST' && req.url === '/edge/internal/auth/identity-resolve') {
          let parsed = {};
          try { parsed = JSON.parse(body); } catch { /* ignore */ }
          const userId = parsed.userId;
          const user = IDENTITIES[userId] || null;
          return res.end(JSON.stringify({
            user,
            banned: false,
            pool_ready: true,
            jit_provisioned: false,
            auth_mode: 'local',
          }));
        }

        // Catch-all: let any other forwarded route reach here with a generic 200
        // (covers /edge/app/schema/user_templates, /edge/platform/access-check, etc.)
        res.end(JSON.stringify({ success: true, data: {} }));
      });
    });

    stubEdge.on('error', reject);
    stubEdge.listen(13212, '127.0.0.1', () => resolve());
  });
}

// Base URL: infra boots as HTTPS when dev certs exist (.devcontainer/certs/).
// We detect at runtime rather than hardcode so the test works in both
// a devcontainer (HTTPS) and a minimal CI environment (HTTP).
const INFRA_PORT = 13211;
let INFRA_BASE; // set in before()

// ── Poll until infra is listening ─────────────────────────────────────────────
async function waitForInfra(maxMs = 5000) {
  const deadline = Date.now() + maxMs;
  while (Date.now() < deadline) {
    for (const scheme of ['https', 'http']) {
      try {
        const resp = await undiciFetch(`${scheme}://127.0.0.1:${INFRA_PORT}/health`);
        if (resp.ok) {
          INFRA_BASE = `${scheme}://127.0.0.1:${INFRA_PORT}`;
          return;
        }
      } catch {
        // not yet up on this scheme
      }
    }
    await new Promise(r => setTimeout(r, 150));
  }
  throw new Error('infra did not start within ' + maxMs + 'ms');
}

// ── JWT helper ────────────────────────────────────────────────────────────────
// Async: jose signing is async (was sync jsonwebtoken.sign).
function mintJwt(userId) {
  return signHs256({ sub: userId }, process.env.JWT_SECRET, { expiresIn: '5m' });
}

// ── HTTP helper (undici fetch for TLS-insecure, no supertest) ────────────────
async function apiRequest({ method = 'GET', path, userId, impersonateId, body }) {
  const headers = {
    'Authorization': `Bearer ${await mintJwt(userId)}`,
    'Content-Type': 'application/json',
  };
  if (impersonateId) {
    headers['x-impersonate-user-id'] = impersonateId;
  }
  const resp = await undiciFetch(`${INFRA_BASE}${path}`, {
    method,
    headers,
    body: body != null ? JSON.stringify(body) : undefined,
  });
  const json = await resp.json().catch(() => null);
  return { status: resp.status, body: json };
}

// ── Test suite ────────────────────────────────────────────────────────────────
describe('infra impersonation gate', () => {
  before(async () => {
    if (_started) return; // guard against double-boot if node:test re-enters
    _started = true;

    // Start the stub edge first so infra's boot-time auth-mode fetch succeeds.
    await startStubEdge();

    // Load and bootstrap the real infra app. We await _infraListenReady so
    // the server.listen() completion is fully inside before()'s async scope —
    // this prevents node:test from detecting the listen handle as a "leaked"
    // async activity after the before hook exits.
    const { bootstrap } = require('../../src/index-infra');
    // Race: bootstrap fires server.listen(); the listen patch resolves
    // _infraListenReady when the callback fires. waitForInfra() confirms
    // the HTTP/HTTPS stack is responding. Both must complete.
    await Promise.all([
      bootstrap(),
      _infraListenReady,
      waitForInfra(),
    ]);
  });

  after(async () => {
    // Close both servers so node:test does not report open-handle warnings.
    // Infra server is captured via the net.Server.prototype.listen patch above
    // (since bootstrap() does not return the handle).
    const closeServer = (srv) => new Promise(resolve => {
      if (!srv) return resolve();
      srv.closeAllConnections?.();
      srv.close(resolve);
    });
    await closeServer(_infraServer);
    await closeServer(stubEdge);
    // Restore the listen patch and the global dispatcher.
    net.Server.prototype.listen = _origListen;
    setGlobalDispatcher(_originalDispatcher);
  });

  it('admin with x-impersonate-user-id: POST /api/* → 403 IMPERSONATION_READ_ONLY', async () => {
    // Arrange: admin-1 (role=admin) impersonating user-9 (role=user).
    // The auth cache may hold admin-1 from a previous request — clear it so
    // the fresh resolve path runs and sets req.impersonator correctly.
    const { _resetCacheForTests } = require('../../src/infra/middleware/auth');
    _resetCacheForTests();

    // Act: POST (mutating method) with impersonation header.
    const { status, body } = await apiRequest({
      method: 'POST',
      path: '/api/schema/user_templates',
      userId: 'admin-1',
      impersonateId: 'user-9',
      body: { probe: true },
    });

    // Assert: impersonation read-only gate fires at 403 before the request
    // can reach the pool-gate or edge forwarding.
    assert.strictEqual(status, 403, `expected 403 but got ${status}: ${JSON.stringify(body)}`);
    assert.strictEqual(body?.error?.code ?? body?.code, 'IMPERSONATION_READ_ONLY',
      `expected code IMPERSONATION_READ_ONLY, got: ${JSON.stringify(body)}`);
  });

  it('admin with x-impersonate-user-id: GET /api/* is NOT blocked by the gate (status !== 403)', async () => {
    // Arrange: same admin + target, but GET (read method).
    const { _resetCacheForTests } = require('../../src/infra/middleware/auth');
    _resetCacheForTests();

    // Act: GET with impersonation header.
    const { status, body } = await apiRequest({
      method: 'GET',
      path: '/api/schema/user_templates',
      userId: 'admin-1',
      impersonateId: 'user-9',
    });

    // Assert: read-only gate must NOT block the request (it only blocks writes).
    // The stub edge pool is configured and the catch-all returns {success:true,data:{}}
    // via forwarding — so the full round-trip must complete with HTTP 200.
    assert.strictEqual(status, 200,
      `GET should forward successfully and return 200 but got ${status}: ${JSON.stringify(body)}`);
    assert.strictEqual(body?.success, true,
      `GET forwarded response must carry success:true from stub catch-all, got: ${JSON.stringify(body)}`);
  });

  it('non-admin with x-impersonate-user-id: header ignored — response is never IMPERSONATION_READ_ONLY', async () => {
    // Arrange: user-9 (role=user) — non-admin cannot trigger impersonation.
    // Auth middleware ignores the header when the real user is not admin,
    // so req.impersonator is never set, so the gate is a no-op.
    const { _resetCacheForTests } = require('../../src/infra/middleware/auth');
    _resetCacheForTests();

    // Act: POST with impersonation header, but caller is a non-admin user.
    const { status, body } = await apiRequest({
      method: 'POST',
      path: '/api/schema/user_templates',
      userId: 'user-9',
      impersonateId: 'admin-1',   // attempting to impersonate admin (should be silently ignored)
      body: { probe: true },
    });

    // Assert: the gate must NEVER fire for a non-admin.
    // The x-impersonate-user-id header is silently dropped for non-admins, so
    // the request flows through as user-9's own identity. The stub edge pool is
    // configured and the catch-all returns {success:true,data:{}} — so the full
    // round-trip completes with HTTP 200, proving the request was forwarded as
    // the real (non-impersonated) user rather than dying at any earlier gate.
    assert.strictEqual(status, 200,
      `non-admin POST should forward as real user and return 200 but got ${status}: ${JSON.stringify(body)}`);
    assert.strictEqual(body?.success, true,
      `non-admin POST forwarded response must carry success:true from stub catch-all, got: ${JSON.stringify(body)}`);
  });
});
