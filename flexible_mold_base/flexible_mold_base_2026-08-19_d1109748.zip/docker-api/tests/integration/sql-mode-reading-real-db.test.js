'use strict';

/**
 * sql-mode-reading-real-db.test.js — the probe is asked of a real engine, and
 * its answer is checked against what that engine actually does to a bad write.
 *
 * WHY A REAL DATABASE, and it is not a formality here. Every other assertion
 * about this probe is about the server's own arithmetic and a stub answers it
 * perfectly. This one is about the PREMISE the whole reporting rests on: that
 * `@@SESSION.sql_mode` predicts whether a value the column cannot hold is
 * refused or silently substituted. A stub cannot show that, because a stub does
 * not substitute anything — it returns what the fixture said. So the mode is
 * read, and then the engine is asked to store something it cannot, and the two
 * answers are required to agree.
 *
 * That is the check that would catch the reporting being confidently wrong: a
 * server whose mode string says STRICT while the write silently truncates
 * anyway, or the reverse, makes the health field worse than absent.
 *
 * Skips with a stated reason when no database is reachable, and FAILS instead of
 * skipping when REQUIRE_INTEGRATION_DB=1 — a silently skipped integration test
 * is the failure mode this line of work exists to end.
 */
const { test, describe, before, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const net = require('node:net');
const mariadb = require('mariadb');

const { SQL_MODE_STATE, probeSqlMode, isStrictMode } = require('../../src/shared/lib/sql-mode');

const TEST_TABLE = 'sqlmode_probe_fixture';

function parseEnvFile(filePath) {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    const out = {};
    for (const line of content.split('\n')) {
      const m = line.match(/^\s*([A-Z_][A-Z0-9_]*)\s*=\s*(.*)\s*$/);
      if (!m) continue;
      let value = m[2];
      if ((value.startsWith('"') && value.endsWith('"'))
        || (value.startsWith("'") && value.endsWith("'"))) {
        value = value.slice(1, -1);
      }
      out[m[1]] = value;
    }
    return out;
  } catch {
    return null;
  }
}

function probePort(host, port, timeoutMs = 2000) {
  return new Promise((resolve) => {
    const socket = new net.Socket();
    let done = false;
    const finish = (ok) => { if (done) return; done = true; socket.destroy(); resolve(ok); };
    socket.setTimeout(timeoutMs);
    socket.once('connect', () => finish(true));
    socket.once('timeout', () => finish(false));
    socket.once('error', () => finish(false));
    socket.connect(port, host);
  });
}

async function resolveMariaDbConfig() {
  if (process.env.DB_TEST_HOST && process.env.DB_TEST_ROOT_PASSWORD) {
    return {
      host: process.env.DB_TEST_HOST,
      port: parseInt(process.env.DB_TEST_PORT || '3306', 10),
      user: 'root',
      password: process.env.DB_TEST_ROOT_PASSWORD,
    };
  }
  const envPath = path.resolve(__dirname, '../../../.devcontainer/.env');
  const env = parseEnvFile(envPath);
  if (!env || !env.DB_ROOT_PASSWORD) return null;
  const port = parseInt(env.DB_PORT || '3306', 10);
  for (const host of ['127.0.0.1', 'mariadb', 'localhost']) {
    if (await probePort(host, port, 2000)) {
      return { host, port, user: 'root', password: env.DB_ROOT_PASSWORD };
    }
  }
  return null;
}

let pool = null;
let dbReady = false;
let skipReason = null;
let testDbName = null;

before(async () => {
  const config = await resolveMariaDbConfig();
  if (!config) {
    skipReason = 'no reachable MariaDB (set DB_TEST_HOST + DB_TEST_ROOT_PASSWORD, '
      + 'or provide .devcontainer/.env)';
    if (process.env.REQUIRE_INTEGRATION_DB === '1') throw new Error(skipReason);
    return;
  }
  testDbName = `fmb_sqlmode_${Date.now()}`;
  const admin = await mariadb.createConnection({ ...config, connectionLimit: 1 });
  await admin.query(`CREATE DATABASE \`${testDbName}\``);
  await admin.end();
  pool = mariadb.createPool({ ...config, database: testDbName, connectionLimit: 4 });
  const conn = await pool.getConnection();
  try {
    await conn.query(
      `CREATE TABLE \`${TEST_TABLE}\` (
         id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
         label VARCHAR(4) NOT NULL DEFAULT ''
       ) ENGINE=InnoDB`,
    );
  } finally {
    conn.release();
  }
  dbReady = true;
});

after(async () => {
  if (!pool) return;
  const conn = await pool.getConnection();
  try { await conn.query(`DROP DATABASE IF EXISTS \`${testDbName}\``); } finally { conn.release(); }
  await pool.end();
});

const guard = (t) => {
  if (!dbReady) { t.skip(skipReason || 'database not ready'); return true; }
  return false;
};

describe('the sql_mode reading, against a real engine', () => {
  test('the probe returns a decided answer on a live connection', async (t) => {
    if (guard(t)) return;
    const conn = await pool.getConnection();
    try {
      const reading = await probeSqlMode(conn);
      // UNKNOWN here would mean the probe cannot read a value every MariaDB
      // answers — the reporting would then be permanently uninformative on every
      // deployment while looking like a working feature.
      assert.notEqual(
        reading.state, SQL_MODE_STATE.UNKNOWN,
        'the probe could not read @@SESSION.sql_mode from a live connection',
      );
      assert.equal(typeof reading.mode, 'string');
    } finally {
      conn.release();
    }
  });

  test('and its answer predicts what the engine does to a value the column cannot hold', async (t) => {
    if (guard(t)) return;
    const conn = await pool.getConnection();
    try {
      const reading = await probeSqlMode(conn);
      // Over-long for VARCHAR(4). Under a strict mode this is error 1406; under
      // a lax one the row is INSERTED with the value truncated to four
      // characters and the caller is told it succeeded.
      let refused = false;
      try {
        await conn.query(`INSERT INTO \`${TEST_TABLE}\` (label) VALUES (?)`, ['abcdefghij']);
      } catch (err) {
        refused = true;
        assert.equal(err.errno, 1406, 'the refusal is the data-too-long error, not something else');
      }
      assert.equal(
        refused, reading.state === SQL_MODE_STATE.STRICT,
        `the probe read '${reading.mode}' and called it ${reading.state}, but the engine `
        + `${refused ? 'refused' : 'accepted'} a value the column cannot hold. The health field `
        + 'derived from this reading would be telling an operator the opposite of the truth.',
      );
      if (!refused) {
        const rows = await conn.query(`SELECT label FROM \`${TEST_TABLE}\``);
        assert.equal(
          rows[0].label, 'abcd',
          'the lax path is supposed to have stored a truncated value — if it stored the whole '
          + 'string the column is not what this fixture thinks it is',
        );
      }
    } finally {
      conn.release();
    }
  });

  test('and it predicts the OTHER direction too, on an engine made lax', async (t) => {
    if (guard(t)) return;
    // THE HALF THAT MATTERS AND CANNOT BE ASSUMED. The test above can only show
    // whichever behaviour this machine's server happens to be configured for,
    // and every server a developer runs is strict — so the lax branch, which is
    // the entire reason this reporting exists, would never be exercised. The
    // mode is changed for THIS SESSION only, on a connection into this test's
    // own throwaway database, and restored before the connection goes back to
    // the pool: nothing global is touched and no other test inherits it.
    const conn = await pool.getConnection();
    let original = null;
    try {
      original = (await conn.query('SELECT @@SESSION.sql_mode AS mode'))[0].mode;
      await conn.query("SET SESSION sql_mode = ''");
      const reading = await probeSqlMode(conn);
      assert.equal(reading.state, SQL_MODE_STATE.LAX, `probe read '${reading.mode}' as ${reading.state}`);
      await conn.query(`DELETE FROM \`${TEST_TABLE}\``);
      // The same statement the strict session refused. Here it SUCCEEDS, and
      // the caller is told nothing.
      await conn.query(`INSERT INTO \`${TEST_TABLE}\` (label) VALUES (?)`, ['abcdefghij']);
      const rows = await conn.query(`SELECT label FROM \`${TEST_TABLE}\``);
      assert.equal(
        rows[0].label, 'abcd',
        'the lax session was supposed to store a truncated value and report success — this is '
        + 'the silent substitution the health field warns an operator about, measured rather '
        + 'than described',
      );
      await conn.query(`DELETE FROM \`${TEST_TABLE}\``);
    } finally {
      if (original != null) {
        try { await conn.query('SET SESSION sql_mode = ?', [original]); } catch { /* released anyway */ }
      }
      conn.release();
    }
  });

  test('and the classifier agrees with the engine about this deployment\'s own mode string', async (t) => {
    if (guard(t)) return;
    const conn = await pool.getConnection();
    try {
      // The engine's own spelling, not one this repository wrote down. A
      // classifier tested only against hand-written mode strings is a classifier
      // tested against its author's idea of what a mode string looks like.
      const rows = await conn.query('SELECT @@SESSION.sql_mode AS mode');
      const raw = rows[0].mode;
      assert.equal(typeof raw, 'string');
      assert.equal(typeof isStrictMode(raw), 'boolean', `unreadable live mode string: ${raw}`);
    } finally {
      conn.release();
    }
  });
});
