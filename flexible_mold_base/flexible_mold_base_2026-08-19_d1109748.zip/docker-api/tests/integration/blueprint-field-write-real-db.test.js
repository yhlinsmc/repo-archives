'use strict';

/**
 * blueprint-field-write-real-db.test.js — the blueprint-field write paths, on a
 * real database, reading the stored rows back.
 *
 * WHY A REAL DATABASE IS THE ONLY INSTRUMENT THAT SETTLES THESE. Every case here
 * is a claim about which rows a statement matched, or about the bytes a column
 * kept — and a mocked driver answers both with whatever the fixture was told to
 * say. That is how this family survived seven previous reviews. So each case
 * asserts a STORED VALUE or a ROW COUNT; a status code alone is never the
 * assertion where the row is about data.
 *
 * What each block settles:
 *
 *   rows 51/52, 6/35, 18/19 — one derivation of what the statement will write:
 *              a parent id respelt in another case, and a destructive cascade
 *              driven by a column the statement never named.
 *   row 1, X16 — a field type nobody declared, deleting every option row of the
 *              field on its way through a block whose branches it matches none
 *              of.
 *   rows 4, 25 — a field key with no shape rule and no clash rule, and the
 *              key-migration endpoint aimed at a sibling's key, which merges two
 *              fields' answers in every record of the blueprint.
 *   rows 13, 14, X18 — an empty string reaching a link column, and an id in
 *              another case walking past the self-link refusal into the
 *              transition that deletes the blueprint's own schema.
 *   row 8, and 18/19's destructive half — the blueprint a field is moved INTO,
 *              never checked; a numeric id resolving an arbitrary one.
 *   the race half of 4 and 25 — the UNIQUE index, and the databases it cannot be
 *              created on.
 *
 * Skips with a stated reason when no database is reachable, and FAILS instead of
 * skipping when REQUIRE_INTEGRATION_DB=1 — a silent skip is the failure mode
 * this whole line of work exists to end.
 */
const { test, describe, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const net = require('node:net');
const http = require('node:http');
const express = require('express');
const mariadb = require('mariadb');

const TEST_PREFIX = 'bfw_';
const tbl = (name) => `${TEST_PREFIX}${name}`;

let pool = null;
const lease = () => pool.getConnection();

const dbKey = require.resolve('../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey,
  filename: dbKey,
  loaded: true,
  exports: {
    pool: { ro: { getConnection: lease }, rw: { getConnection: lease } },
    t: tbl,
    getDynamicPool: async () => ({ ro: { getConnection: lease }, rw: { getConnection: lease } }),
  },
};

const { buildEngineTableDDLs, buildInfraTableDDLs } = require('../../src/table-ddls');
const schemaRouter = require('../../src/edge/routes/app/schema');
const importRouter = require('../../src/edge/routes/app/blueprint-export');
const { fixtureUserId } = require('../helpers/fixture-ids');

// ── Config auto-detection (same shape as the sibling integration tests) ──────

function parseEnvFile(filePath) {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    const out = {};
    for (const line of content.split('\n')) {
      const m = line.match(/^\s*([A-Z_][A-Z0-9_]*)\s*=\s*(.*)\s*$/);
      if (!m) continue;
      let value = m[2];
      if ((value.startsWith('"') && value.endsWith('"'))
        || (value.startsWith("'") && value.endsWith("'"))) {
        value = value.slice(1, -1);
      }
      out[m[1]] = value;
    }
    return out;
  } catch {
    return null;
  }
}

function probePort(host, port, timeoutMs = 2000) {
  return new Promise((resolve) => {
    const socket = new net.Socket();
    let done = false;
    const finish = (ok) => {
      if (done) return;
      done = true;
      socket.destroy();
      resolve(ok);
    };
    socket.setTimeout(timeoutMs);
    socket.once('connect', () => finish(true));
    socket.once('timeout', () => finish(false));
    socket.once('error', () => finish(false));
    socket.connect(port, host);
  });
}

async function resolveMariaDbConfig() {
  if (process.env.DB_TEST_HOST && process.env.DB_TEST_ROOT_PASSWORD) {
    return {
      host: process.env.DB_TEST_HOST,
      port: parseInt(process.env.DB_TEST_PORT || '3306', 10),
      user: 'root',
      password: process.env.DB_TEST_ROOT_PASSWORD,
    };
  }
  const envPath = path.resolve(__dirname, '../../../.devcontainer/.env');
  const env = parseEnvFile(envPath);
  if (!env || !env.DB_ROOT_PASSWORD) return null;
  const port = parseInt(env.DB_PORT || '3306', 10);
  for (const host of ['127.0.0.1', 'mariadb', 'localhost']) {
    if (await probePort(host, port, 2000)) {
      return { host, port, user: 'root', password: env.DB_ROOT_PASSWORD };
    }
  }
  return null;
}

// ── Fixture ─────────────────────────────────────────────────────────────────

const ADMIN = { id: fixtureUserId('admin'), role: 'admin' };
const EDITOR = { id: fixtureUserId('editor'), role: 'editor' };
const OTHER_EDITOR = { id: '2af146d0-081f-4869-8a8f-3bf248676df8', role: 'editor' };

// Lower-case canonical spellings; the case-fold cases send the upper-case form
// of the SAME id, which the column's collation calls one value and JavaScript
// calls two.
const BP_MINE = 'a1b2c3d4-1111-4222-8333-000000000001';
const BP_SHARED = 'a1b2c3d4-1111-4222-8333-000000000002';
const BP_THEIRS = 'a1b2c3d4-1111-4222-8333-000000000003';
const FIELD_ID = 'f1e2d3c4-1111-4222-8333-000000000001';
const SIBLING_ID = 'f1e2d3c4-1111-4222-8333-000000000002';

let dbReady = false;
let skipReason = null;
let testDbName = null;
let server = null;
let baseUrl = null;
let currentUser = ADMIN;

before(async () => {
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) {
    skipReason = 'no MariaDB reachable via .devcontainer/.env or env vars';
    if (process.env.REQUIRE_INTEGRATION_DB === '1') {
      throw new Error(`REQUIRE_INTEGRATION_DB=1 set but ${skipReason}.`);
    }
    return;
  }
  testDbName = `bp_field_write_test_${process.pid}_${Date.now()}`;
  let admin = null;
  try {
    admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`CREATE DATABASE \`${testDbName}\``);
    await admin.query(`USE \`${testDbName}\``);
    // Every table, built from the DDL that creates the real ones — a hand-picked
    // subset drops a table some guard probes and turns its refusal into a
    // degrade nobody asked for.
    for (const sql of [...buildInfraTableDDLs(tbl), ...buildEngineTableDDLs(tbl)]) {
      await admin.query(sql);
    }
    await admin.end();
    admin = null;

    pool = mariadb.createPool({
      ...dbConfig, database: testDbName, connectionLimit: 6, connectTimeout: 5000,
    });

    const app = express();
    app.use(express.json());
    app.use((req, _res, next) => { req.user = currentUser; next(); });
    app.use('/edge/app/schema', schemaRouter);
    // The import routes mount at the same prefix in the real server
    // (index-edge.js), and one case below needs a duplicate the real UNIQUE
    // index raises rather than one a fixture was told to raise.
    app.use('/edge/app/schema', importRouter);
    server = http.createServer(app);
    await new Promise((r) => server.listen(0, r));
    baseUrl = `http://127.0.0.1:${server.address().port}`;
    dbReady = true;
  } catch (err) {
    skipReason = `setup failed: ${err.message}`;
    if (admin) { try { await admin.end(); } catch { /* best effort */ } }
    if (process.env.REQUIRE_INTEGRATION_DB === '1') throw err;
  }
});

after(async () => {
  if (server) { try { server.close(); } catch { /* best effort */ } }
  if (pool) { try { await pool.end(); } catch { /* best effort */ } }
  if (!testDbName) return;
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) return;
  try {
    const admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`DROP DATABASE IF EXISTS \`${testDbName}\``);
    await admin.end();
  } catch { /* best effort */ }
});

async function call(user, method, url, body) {
  currentUser = user;
  const res = await fetch(`${baseUrl}${url}`, {
    method,
    headers: { 'content-type': 'application/json' },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const text = await res.text();
  let parsed = null;
  try { parsed = JSON.parse(text); } catch { parsed = { raw: text }; }
  return { status: res.status, body: parsed };
}

const putField = (user, id, body) => call(user, 'PUT', `/edge/app/schema/blueprint_fields/${id}`, body);
const postField = (user, body) => call(user, 'POST', '/edge/app/schema/blueprint_fields', body);
const renameKey = (user, id, body) => call(user, 'POST', `/edge/app/schema/rename/${id}`, body);

const one = async (sql, params) => (await pool.query(sql, params))[0];
const countOf = async (sql, params) => Number((await one(sql, params)).n);
const storedField = (id = FIELD_ID) => one(`SELECT * FROM \`${tbl('blueprint_fields')}\` WHERE id = ?`, [id]);

const guard = (t) => {
  if (!dbReady) { t.skip(skipReason || 'database not ready'); return true; }
  return false;
};

/** Clear every table this file writes to, so each case states its own pre-state. */
beforeEach(async () => {
  if (!dbReady) return;
  for (const name of ['field_options', 'variant_overrides', 'blueprint_fields', 'user_templates',
    'blueprint_sections', 'blueprint_groups', 'blueprint_output_order', 'decision_tables',
    'hierarchy_nodes', 'feature_audit']) {
    await pool.query(`DELETE FROM \`${tbl(name)}\``);
  }
  for (const [id, owner] of [[BP_MINE, EDITOR.id], [BP_SHARED, null], [BP_THEIRS, OTHER_EDITOR.id]]) {
    await pool.query(
      `INSERT INTO \`${tbl('hierarchy_nodes')}\` (id, name, node_type, owner_id) VALUES (?, ?, 'blueprint', ?)`,
      [id, `bp-${id.slice(-4)}`, owner],
    );
  }
});

/**
 * A field on BP_MINE, with the type and key the case needs.
 *
 * The column list is built from the row rather than fixed, because one case
 * drops an additive column to reproduce a database whose operator could not add
 * it — naming that column here would fail the fixture instead of the assertion.
 */
async function seedField(overrides = {}) {
  const row = {
    id: FIELD_ID,
    blueprint_id: BP_MINE,
    field_key: 'city',
    field_label: 'City',
    field_type: 'text',
    ...overrides,
  };
  const columns = Object.keys(row);
  await pool.query(
    `INSERT INTO \`${tbl('blueprint_fields')}\` (${columns.map((c) => `\`${c}\``).join(', ')})
     VALUES (${columns.map(() => '?').join(', ')})`,
    columns.map((c) => row[c]),
  );
  return row;
}

async function seedOptions(fieldId, values, validParentValues = null) {
  for (const value of values) {
    await pool.query(
      `INSERT INTO \`${tbl('field_options')}\`
         (id, field_id, option_label, option_value, valid_parent_values)
       VALUES (UUID(), ?, ?, ?, ?)`,
      [fieldId, value, value, validParentValues],
    );
  }
}

/** A JSON column comes back parsed on some driver versions and as text on others. */
const asJson = (value) => (typeof value === 'string' ? JSON.parse(value) : value);

const optionCount = (fieldId) => countOf(
  `SELECT COUNT(*) AS n FROM \`${tbl('field_options')}\` WHERE field_id = ?`, [fieldId],
);

// ── T1 — one derivation: the value a guard reads is the value the statement
//        writes (rows 18, 19, 35, 51, 52) ──────────────────────────────────────

describe('the value the guard reads and the value the statement writes', () => {
  test('a blueprint respelt in another case leaves the stored id byte-identical', async (t) => {
    if (guard(t)) return;
    // ROW 51/52. The field editor spreads the whole form, so the parent id
    // travels back on every save — and an id that arrives in another case is the
    // SAME ROW to the column's collation and a DIFFERENT STRING to every
    // JavaScript reader that resolves a blueprint by exact match (the export
    // fingerprint, the reparent re-stamp, every Map keyed by blueprint_id).
    // Stored as sent, the field belongs to a blueprint that does not exist as
    // far as those readers are concerned.
    await seedField();
    const res = await putField(ADMIN, FIELD_ID, {
      field_label: 'City renamed',
      blueprint_id: BP_MINE.toUpperCase(),
    });
    assert.equal(res.status, 200, `a legitimate save was refused: ${JSON.stringify(res.body)}`);

    const row = await storedField();
    assert.equal(
      row.blueprint_id, BP_MINE,
      'the stored blueprint id is no longer the spelling the hierarchy row holds',
    );
    assert.equal(row.field_label, 'City renamed', 'the legitimate half of the write did not land');
  });

  test('a body key the column gate dropped moves no destructive cascade', async (t) => {
    if (guard(t)) return;
    // ROW 6/35. The per-option parent tags are wiped when a field's parent
    // changes. On a database whose operator could not add `depends_on_field_key`
    // the column is dropped from the statement — so the parent CANNOT change —
    // while the wipe was decided by asking whether the BODY mentioned it. A
    // label-only save from the field editor (which always spreads the column)
    // then cleared tags an administrator had set, on the databases least able to
    // recover them.
    const bfTable = tbl('blueprint_fields');
    await pool.query(`ALTER TABLE \`${bfTable}\` DROP COLUMN depends_on_field_key`);
    // The column set is cached per (database, table); the drop above invalidates
    // a cache this process may already have filled from an earlier case.
    schemaRouter.__test__.__clearColumnSetCache();
    try {
      await seedField();
      await seedOptions(FIELD_ID, ['a', 'b'], JSON.stringify(['north']));

      const res = await putField(ADMIN, FIELD_ID, {
        field_label: 'City renamed',
        depends_on_field_key: 'region',
      });
      assert.equal(res.status, 200, `a legitimate save was refused: ${JSON.stringify(res.body)}`);

      const tagged = await countOf(
        `SELECT COUNT(*) AS n FROM \`${tbl('field_options')}\`
           WHERE field_id = ? AND valid_parent_values IS NOT NULL`,
        [FIELD_ID],
      );
      assert.equal(tagged, 2, 'a column the statement never wrote cleared the option tags');
    } finally {
      await pool.query(
        `ALTER TABLE \`${bfTable}\` ADD COLUMN depends_on_field_key VARCHAR(255) NULL DEFAULT NULL`,
      );
      schemaRouter.__test__.__clearColumnSetCache();
    }
  });

  test('a parent the statement really writes still clears the tags', async (t) => {
    if (guard(t)) return;
    // The other half of the same guard: what it must NOT stop doing. A real
    // parent change leaves every per-option tag pointing at the previous
    // parent's values, so the clear is the behaviour, not the defect.
    await seedField();
    await seedOptions(FIELD_ID, ['a', 'b'], JSON.stringify(['north']));

    const res = await putField(ADMIN, FIELD_ID, { depends_on_field_key: 'region' });
    assert.equal(res.status, 200, `a legitimate save was refused: ${JSON.stringify(res.body)}`);

    const tagged = await countOf(
      `SELECT COUNT(*) AS n FROM \`${tbl('field_options')}\`
         WHERE field_id = ? AND valid_parent_values IS NOT NULL`,
      [FIELD_ID],
    );
    assert.equal(tagged, 0, 'a real parent change left the previous parent\'s tags in place');
    assert.equal((await storedField()).depends_on_field_key, 'region');
  });
});

// ── T2 — the destructive type block, gated by the value the statement writes
//        (row 1, X16) ───────────────────────────────────────────────────────────

describe('a field type the column does not have', () => {
  test('a type outside the declared set is refused and the options survive', async (t) => {
    if (guard(t)) return;
    // ROW 1, THE CRITICAL. The three statements that decide what to DESTROY
    // compare this column against a literal, and the column is a plain VARCHAR
    // with no member list anywhere. A type nobody declared read as a CHANGE, so
    // the destructive block ran and deleted every option row of the field —
    // while the value that caused it matched no branch, was stored, and renders
    // as nothing.
    await seedField({ field_type: 'select' });
    await seedOptions(FIELD_ID, ['north', 'south', 'east']);
    assert.equal(await optionCount(FIELD_ID), 3, 'the fixture did not seed the options');

    const res = await putField(EDITOR, FIELD_ID, { field_type: 'Selected' });

    assert.equal(await optionCount(FIELD_ID), 3, 'a type nobody declared deleted the field options');
    assert.equal((await storedField()).field_type, 'select', 'the undeclared type was stored');
    assert.equal(res.status, 400, `expected a stable refusal, got ${JSON.stringify(res.body)}`);
    assert.equal(res.body.error.code, 'INVALID_COLUMN_VALUE');
  });

  test('a type respelt with a trailing space is refused rather than stored', async (t) => {
    if (guard(t)) return;
    // The spelling the collation calls the SAME value: it moves no gate, so
    // nothing is destroyed — and the bytes are still stored (measured: a
    // trailing space is physically kept, it only COMPARES equal because the
    // collation pads). Every JavaScript reader of this column then sees a type
    // it has no branch for.
    await seedField({ field_type: 'select' });
    await seedOptions(FIELD_ID, ['north', 'south', 'east']);

    const res = await putField(EDITOR, FIELD_ID, { field_type: 'select ' });

    assert.equal((await storedField()).field_type, 'select', 'the padded spelling was stored');
    assert.equal(await optionCount(FIELD_ID), 3, 'a refused write destroyed the options');
    assert.equal(res.status, 400, `expected a stable refusal, got ${JSON.stringify(res.body)}`);
  });

  test('the side data of every destructive branch survives an undeclared type', async (t) => {
    if (guard(t)) return;
    // X16 — the two siblings nobody listed. `checkbox` owns choice_config and
    // `table` owns table_config and the field's own cell scope; each is cleared
    // by the same block, on the same trigger, and each was reachable by the same
    // undeclared value.
    await seedField({ field_type: 'checkbox', choice_config: JSON.stringify({ maxSelected: 2 }) });
    let refused = await putField(EDITOR, FIELD_ID, { field_type: 'CheckBoxes' });
    assert.equal(refused.status, 400, `expected a refusal, got ${JSON.stringify(refused.body)}`);
    assert.notEqual((await storedField()).choice_config, null, 'the checkbox limits were cleared');

    await pool.query(`DELETE FROM \`${tbl('blueprint_fields')}\``);
    await seedField({ field_type: 'table', table_config: JSON.stringify({ columns: [] }) });
    refused = await putField(EDITOR, FIELD_ID, { field_type: 'Tables' });
    assert.equal(refused.status, 400, `expected a refusal, got ${JSON.stringify(refused.body)}`);
    assert.notEqual((await storedField()).table_config, null, 'the table definition was cleared');
  });

  test('a genuine type change still deletes, and reports what it deleted', async (t) => {
    if (guard(t)) return;
    // The other half of the guard: what it must NOT refuse. A real
    // select → text change is the operator's own request, the options are
    // meaningless afterwards, and the audit row must report the number the
    // DELETE actually matched rather than a count taken from somewhere else.
    await seedField({ field_type: 'select' });
    await seedOptions(FIELD_ID, ['north', 'south', 'east']);

    const res = await putField(EDITOR, FIELD_ID, { field_type: 'text' });
    assert.equal(res.status, 200, `a legitimate type change was refused: ${JSON.stringify(res.body)}`);

    assert.equal(await optionCount(FIELD_ID), 0, 'the options of the abandoned type were kept');
    assert.equal((await storedField()).field_type, 'text');
    const audit = await one(
      `SELECT metadata FROM \`${tbl('feature_audit')}\`
        WHERE event_type = 'blueprint.field.type_changed'`,
    );
    assert.ok(audit, 'the type change wrote no audit row');
    const meta = asJson(audit.metadata);
    assert.equal(meta.deleted_options_count, 3, 'the audit did not report what the DELETE matched');
  });

  test('the generic create refuses an undeclared type too, and stores no row', async (t) => {
    if (guard(t)) return;
    // The mirror. The custom PUT shadows the factory's update, but its CREATE is
    // the generic one — a domain enforced on one verb is a domain a caller
    // reaches around by using the other.
    const created = await postField(EDITOR, {
      blueprint_id: BP_MINE, field_key: 'zone', field_label: 'Zone', field_type: 'Selected',
    });
    assert.equal(
      await countOf(`SELECT COUNT(*) AS n FROM \`${tbl('blueprint_fields')}\``),
      0, 'an undeclared type was created',
    );
    assert.equal(created.status, 400, `expected a stable refusal, got ${JSON.stringify(created.body)}`);
  });

  // ── The other side of the same column: a type ALREADY STORED outside the
  //    declared spelling, which the write gate above cannot reach. ────────────

  test('a stored `Table` still gives up its table definition when the type changes',
    async (t) => {
      if (guard(t)) return;
      // The gate above makes identity a precondition of the value being WRITTEN,
      // which is what lets the three destructive comparisons be plain literals.
      // It says nothing about a value already in the table, and those
      // comparisons judge the OLD row: to the engine a stored `'Table'` IS
      // `'table'`, so the change is detected — and `oldRow.field_type ===
      // 'table'` is false, so the clear that belongs to the change never runs.
      // The field stops being a table with its table_config intact.
      //
      // Seeded through a direct INSERT because that is how such a row arrives:
      // rows predating the write gate, and the import paths, which build their
      // INSERTs from the payload's own columns.
      await seedField({ field_type: 'Table', table_config: JSON.stringify({ columns: [] }) });

      const res = await putField(EDITOR, FIELD_ID, { field_type: 'text' });
      assert.equal(res.status, 200, `a legitimate type change was refused: ${JSON.stringify(res.body)}`);

      const row = await storedField();
      assert.equal(row.field_type, 'text');
      assert.equal(row.table_config, null, 'a field that stopped being a table kept its columns');
    });

  test('a stored `Table` gives up its cell scope, which is the half that widens later',
    async (t) => {
      if (guard(t)) return;
      // The scope is the consequential one: left in the column it is inert on a
      // non-table field and comes back to life the moment the field is a table
      // again, silently narrowing a whole-field setting to cells nobody picked.
      // Its absence also makes the row incoherent to the post-state check, so
      // before this fix the field could not be re-typed AT ALL — the change was
      // refused 400 and the row stayed `'Table'`, unrepairable through the only
      // surface that edits it.
      await seedField({
        field_type: 'Table',
        table_config: JSON.stringify({ columns: [] }),
        value_scope: JSON.stringify({ rows: [1], columns: null }),
        value_source: 'locked',
      });

      const res = await putField(EDITOR, FIELD_ID, { field_type: 'text', value_source: 'locked' });
      assert.equal(res.status, 200, `the field could not be re-typed at all: ${JSON.stringify(res.body)}`);

      const row = await storedField();
      assert.equal(row.field_type, 'text');
      assert.equal(row.value_scope, null, 'a cell scope survived onto a field that has no cells');
    });

  test('a stored `Select` gives up its options, and a stored `Checkbox` its limits too',
    async (t) => {
      if (guard(t)) return;
      // The remaining two branches of the same block, with the row counts as the
      // assertion: orphaned option rows belong to a type the field no longer has,
      // and they are what the next save of the field renders.
      await seedField({ field_type: 'Select' });
      await seedOptions(FIELD_ID, ['north', 'south']);

      let res = await putField(EDITOR, FIELD_ID, { field_type: 'text' });
      assert.equal(res.status, 200, `a legitimate type change was refused: ${JSON.stringify(res.body)}`);
      assert.equal(await optionCount(FIELD_ID), 0, 'the options of the abandoned type were kept');

      await pool.query(`DELETE FROM \`${tbl('blueprint_fields')}\``);
      await seedField({ field_type: 'CHECKBOX', choice_config: JSON.stringify({ maxSelected: 2 }) });
      await seedOptions(FIELD_ID, ['north', 'south']);

      res = await putField(EDITOR, FIELD_ID, { field_type: 'text' });
      assert.equal(res.status, 200, `a legitimate type change was refused: ${JSON.stringify(res.body)}`);
      assert.equal(await optionCount(FIELD_ID), 0, 'the options of the abandoned type were kept');
      assert.equal((await storedField()).choice_config, null, 'the checkbox limits were kept');
    });

  test('a stored type the column calls NOTHING declared destroys nothing', async (t) => {
    if (guard(t)) return;
    // The control. Resolving the stored spelling must not become "guess the
    // nearest member": a stored `'Selected'` is no member of the domain, so no
    // branch owns its side data and none of it may be deleted.
    await seedField({ field_type: 'Selected' });
    await seedOptions(FIELD_ID, ['north', 'south']);

    const res = await putField(EDITOR, FIELD_ID, { field_type: 'text' });
    assert.equal(res.status, 200, `a legitimate type change was refused: ${JSON.stringify(res.body)}`);
    assert.equal(
      await optionCount(FIELD_ID), 2,
      'a stored type outside the domain had its side data deleted by a branch that does not own it',
    );
  });
});

// ── T3 — one shape rule and one clash rule for `field_key` (rows 4, 25) ───────

/** A second field on the same blueprint, so a key can collide with something. */
async function seedSibling(fieldKey = 'zone') {
  await pool.query(
    `INSERT INTO \`${tbl('blueprint_fields')}\` (id, blueprint_id, field_key, field_label, field_type)
     VALUES (?, ?, ?, 'Zone', 'text')`,
    [SIBLING_ID, BP_MINE, fieldKey],
  );
}

/** A record holding an answer under each field's key. */
async function seedTemplate(payload) {
  await pool.query(
    `INSERT INTO \`${tbl('user_templates')}\` (id, blueprint_id, name, payload, owner_id)
     VALUES (UUID(), ?, 'record', ?, ?)`,
    [BP_MINE, JSON.stringify(payload), EDITOR.id],
  );
}

const storedPayload = async () => asJson(
  (await one(`SELECT payload FROM \`${tbl('user_templates')}\``)).payload,
);

describe('a field key that would collide with a sibling', () => {
  test('the migration is refused, and the sibling keeps the answers it holds', async (t) => {
    if (guard(t)) return;
    // ROW 4. The rename endpoint copies every record's answer from the old key
    // to the new one with JSON_SET, scoped to the blueprint and to nothing else.
    // Aimed at a key a SIBLING field already owns, that statement overwrites the
    // sibling's answer in every record of the blueprint, and the two fields then
    // read the same one. Nothing is recoverable afterwards: the previous value
    // is not written anywhere.
    await seedField({ field_key: 'city' });
    await seedSibling('zone');
    await seedTemplate({ city: 'Kaohsiung', zone: 'north' });

    const res = await renameKey(EDITOR, FIELD_ID, { old_key: 'city', new_key: 'zone' });

    const payload = await storedPayload();
    assert.equal(payload.zone, 'north', 'the sibling field\'s stored answer was overwritten');
    assert.equal(payload.city, 'Kaohsiung', 'the refused migration moved the answer anyway');
    assert.equal(res.status, 409, `expected a stable refusal, got ${JSON.stringify(res.body)}`);
  });

  test('the write that would create the collision is refused first', async (t) => {
    if (guard(t)) return;
    // ROW 25/4, the other half: the key is WRITTEN here, and the endpoint that
    // writes it had no rule at all — not a shape rule, not a uniqueness rule.
    await seedField({ field_key: 'city' });
    await seedSibling('zone');

    const exact = await putField(EDITOR, FIELD_ID, { field_key: 'zone' });
    assert.equal((await storedField()).field_key, 'city', 'the colliding key was stored');
    assert.equal((await storedField(SIBLING_ID)).field_key, 'zone', 'the sibling\'s key moved');
    assert.equal(exact.status, 409, `expected a stable refusal, got ${JSON.stringify(exact.body)}`);

    // And compared the way the INDEX compares. A sibling stored before the shape
    // rule existed can hold `ZONE`; that is the same key to the column, to the
    // `WHERE field_key = ?` lookup every reader uses, and to the unique index —
    // and a different string to a JavaScript comparison, which is what would let
    // the duplicate through.
    await pool.query(
      `UPDATE \`${tbl('blueprint_fields')}\` SET field_key = 'ZONE' WHERE id = ?`, [SIBLING_ID],
    );
    const folded = await putField(EDITOR, FIELD_ID, { field_key: 'zone' });
    assert.equal((await storedField()).field_key, 'city', 'the key the column already holds was stored twice');
    assert.equal(folded.status, 409, `expected a stable refusal, got ${JSON.stringify(folded.body)}`);
  });

  test('a key the migration endpoint would refuse is refused by the write too', async (t) => {
    if (guard(t)) return;
    // ROW 25 (B8). One shape rule, enforced by the endpoint that WRITES a key
    // and by the one that MIGRATES it. The write had none, so a key the rename
    // endpoint refuses — and that every JSON path is built from — could be
    // stored by the save beside it.
    await seedField({ field_key: 'city' });

    for (const badKey of ['9zone', 'Zone Name', '', null]) {
      const res = await putField(EDITOR, FIELD_ID, { field_key: badKey });
      assert.equal(
        (await storedField()).field_key, 'city',
        `a key of the wrong shape (${JSON.stringify(badKey)}) was stored`,
      );
      assert.equal(res.status, 400, `expected a stable refusal for ${JSON.stringify(badKey)}, got ${JSON.stringify(res.body)}`);
    }
  });

  test('a free key still moves, and the migration still moves the answers', async (t) => {
    if (guard(t)) return;
    // The other half of both guards: renaming a field to a key nobody holds is
    // the ordinary path the Schema Builder takes, and it must still carry the
    // records' answers with it.
    await seedField({ field_key: 'city' });
    await seedTemplate({ city: 'Kaohsiung' });

    // The order the Schema Builder uses: migrate the answers while the stored
    // key is still the old one, then save the field under the new key.
    const migrated = await renameKey(EDITOR, FIELD_ID, { old_key: 'city', new_key: 'town' });
    assert.equal(migrated.status, 200, `a legitimate migration was refused: ${JSON.stringify(migrated.body)}`);
    const payload = await storedPayload();
    assert.equal(payload.town, 'Kaohsiung', 'the answer did not move with the key');
    assert.equal(payload.city, undefined, 'the answer was left under the old key as well');

    const moved = await putField(EDITOR, FIELD_ID, { field_key: 'town' });
    assert.equal(moved.status, 200, `a legitimate rename was refused: ${JSON.stringify(moved.body)}`);
    assert.equal((await storedField()).field_key, 'town');
  });
});

// ── T4 — the link / transformer family: absence is presence, not truthiness
//        (rows 13, 14, X18) ─────────────────────────────────────────────────────

const putNode = (user, id, body) => call(user, 'PUT', `/edge/app/schema/hierarchy_nodes/${id}`, body);
const postNode = (user, body) => call(user, 'POST', '/edge/app/schema/hierarchy_nodes', body);
const storedNode = (id) => one(`SELECT * FROM \`${tbl('hierarchy_nodes')}\` WHERE id = ?`, [id]);
const fieldCount = (blueprintId) => countOf(
  `SELECT COUNT(*) AS n FROM \`${tbl('blueprint_fields')}\` WHERE blueprint_id = ?`, [blueprintId],
);

describe('an empty string is not a link', () => {
  test('a blueprint whose stored link is empty can still have its schema edited', async (t) => {
    if (guard(t)) return;
    // ROW 13, measured live: `''` really is stored in this column, and every
    // reader tests `!= null`, so the empty string reads as LINKED — a blueprint
    // that borrows a schema from nowhere. Schema editing is then refused 409 for
    // EVERY role including an administrator, and the row cannot be repaired
    // through any surface that would have to write to it.
    await pool.query(
      `UPDATE \`${tbl('hierarchy_nodes')}\` SET linked_blueprint_id = '' WHERE id = ?`, [BP_MINE],
    );
    await seedField({ field_label: 'City' });

    const res = await putField(ADMIN, FIELD_ID, { field_label: 'City renamed' });

    assert.equal(
      (await storedField()).field_label, 'City renamed',
      'a blueprint linked to nothing refused an administrator its own schema',
    );
    assert.equal(res.status, 200, `expected the edit to land, got ${JSON.stringify(res.body)}`);
  });

  test('an empty link is refused with the sentence that says what to send instead', async (t) => {
    if (guard(t)) return;
    // AN EMPTY SELECT IS THE LIKELIEST OPERATOR INPUT ON THIS COLUMN, and the
    // refusal it meets is the only thing that tells them what to do about it.
    // Once the identifier floor ran first, `''` answered the floor's generic
    // sentence about the canonical 36-character form — true, and no help at all
    // to someone who cleared a picker: the value they need to send is `null`,
    // and nothing said so. The blank rule the sibling link columns still answer
    // with is asked first again, for all three of them.
    const res = await putNode(ADMIN, BP_MINE, { linked_blueprint_id: '' });

    assert.equal(
      (await storedNode(BP_MINE)).linked_blueprint_id, null,
      'an empty value was stored as this blueprint\'s link',
    );
    assert.equal(res.status, 400, `expected a stable refusal, got ${JSON.stringify(res.body)}`);
    assert.equal(res.body.error.code, 'INVALID_LINK_TARGET');
    assert.match(res.body.error.message, /Send null to clear it/);
  });

  test('an empty transformer is refused rather than stored', async (t) => {
    if (guard(t)) return;
    // ROW 14/X18. `body.transformer_id || body.transformer_version || null` reads
    // `''` as "no transformer", so the guard that forbids a blueprint carrying
    // both a link and a transformer was decided about a value the statement did
    // not write. The column then holds `''`, which every later read of the pair
    // — the exclusivity guard, the grandfather rule, the picker — takes for a
    // transformer that is there.
    const created = await postNode(ADMIN, {
      name: 'blank-transformer', node_type: 'blueprint', transformer_id: '',
    });
    assert.equal(
      await countOf(
        `SELECT COUNT(*) AS n FROM \`${tbl('hierarchy_nodes')}\` WHERE transformer_id = ''`,
      ),
      0, 'an empty transformer was stored',
    );
    assert.equal(created.status, 400, `expected a stable refusal, got ${JSON.stringify(created.body)}`);
  });

  test('an empty transformer version is refused on the update too', async (t) => {
    if (guard(t)) return;
    // The twin nobody listed: the same fold, on the verb that also decides
    // whether the write is the link TRANSITION that clears the blueprint's own
    // schema.
    const res = await putNode(ADMIN, BP_MINE, { transformer_version: '' });
    assert.equal(
      (await storedNode(BP_MINE)).transformer_version, null,
      'an empty transformer version was stored',
    );
    assert.equal(res.status, 400, `expected a stable refusal, got ${JSON.stringify(res.body)}`);
  });

  test('a blueprint cannot link to itself under another spelling of its own id', async (t) => {
    if (guard(t)) return;
    // The self-link refusal compares the caller's value with the row's id in
    // JavaScript, and the ids are CHAR(36) under a collation that folds case. So
    // the same id in another spelling walks past the refusal, resolves the row
    // itself as the link target, and the transition handler then does what a
    // transition does: DELETES the blueprint's own fields, sections, groups,
    // options and output order, because a linked blueprint's own schema is
    // unreachable. The blueprint ends up linked to itself with nothing left.
    await seedField();
    await seedSibling('zone');
    assert.equal(await fieldCount(BP_MINE), 2, 'the fixture did not seed the schema');

    const res = await putNode(ADMIN, BP_MINE, { linked_blueprint_id: BP_MINE.toUpperCase() });

    assert.equal(await fieldCount(BP_MINE), 2, 'a self-link deleted the blueprint\'s own schema');
    assert.equal((await storedNode(BP_MINE)).linked_blueprint_id, null, 'the blueprint was linked to itself');
    assert.equal(res.status, 400, `expected a stable refusal, got ${JSON.stringify(res.body)}`);
  });

  test('a real link still lands, and still clears the schema it makes unreachable', async (t) => {
    if (guard(t)) return;
    // The other half: linking to another blueprint is the feature, and the clear
    // is what the feature does — the linked blueprint renders the SOURCE's
    // fields, so its own would be unreachable rows nobody can edit or delete.
    await seedField();
    assert.equal(await fieldCount(BP_MINE), 1);

    const res = await putNode(ADMIN, BP_MINE, { linked_blueprint_id: BP_SHARED });
    assert.equal(res.status, 200, `a legitimate link was refused: ${JSON.stringify(res.body)}`);
    assert.equal((await storedNode(BP_MINE)).linked_blueprint_id, BP_SHARED);
    assert.equal(await fieldCount(BP_MINE), 0, 'the now-unreachable schema was left behind');
  });
});

// ── T13 — a value that names no ROW is not a link either (the second half of
//          "absence is presence, never truthiness") ──────────────────────────

/** Everything the link transition DELETES, so the assertion can be its counts. */
async function seedWholeSchema() {
  await seedField();
  await seedOptions(FIELD_ID, ['red']);
  await pool.query(
    `INSERT INTO \`${tbl('blueprint_sections')}\` (id, blueprint_id, section_key, display_label)
     VALUES (UUID(), ?, 'overview', 'Overview')`, [BP_MINE],
  );
  await pool.query(
    `INSERT INTO \`${tbl('blueprint_groups')}\` (id, blueprint_id, group_key, display_label, color_key)
     VALUES (UUID(), ?, 'lane_a', 'Lane A', 'blue')`, [BP_MINE],
  );
  await pool.query(
    `INSERT INTO \`${tbl('blueprint_output_order')}\` (id, blueprint_id, output_key, sort_order)
     VALUES (UUID(), ?, 'city', 1)`, [BP_MINE],
  );
  await pool.query(
    `INSERT INTO \`${tbl('decision_tables')}\` (id, blueprint_id, name, doc)
     VALUES (UUID(), ?, 'rules', ?)`, [BP_MINE, JSON.stringify({ inputs: [], outputs: [], rules: [] })],
  );
}

const scoped = (table, column = 'blueprint_id') => countOf(
  `SELECT COUNT(*) AS n FROM \`${tbl(table)}\` WHERE \`${column}\` = ?`, [BP_MINE],
);

/** Every row the transition would destroy, counted per table. */
async function schemaRowCounts() {
  return {
    fields: await scoped('blueprint_fields'),
    options: await countOf(
      `SELECT COUNT(*) AS n FROM \`${tbl('field_options')}\` WHERE field_id = ?`, [FIELD_ID],
    ),
    sections: await scoped('blueprint_sections'),
    groups: await scoped('blueprint_groups'),
    output_order: await scoped('blueprint_output_order'),
    decision_tables: await scoped('decision_tables'),
  };
}

const FULL_SCHEMA = {
  fields: 1, options: 1, sections: 1, groups: 1, output_order: 1, decision_tables: 1,
};

describe('a link column that names no row at all', () => {
  for (const [label, value] of [['a JSON number', 0], ['a JSON boolean', false]]) {
    for (const actor of ['admin', 'editor']) {
      test(`${label} sent as ${actor} destroys nothing`, async (t) => {
        if (guard(t)) return;
        // The refusal in front of this handler only ever looked at STRINGS, so a
        // JSON number walked through it and `linkTargetOf` — which maps only
        // `null` and `''` to absent — reported it as a link target. `WHERE id =
        // 0` is then a CHAR-vs-number comparison MariaDB resolves in NUMERIC
        // context, which matches an arbitrary set of uuid rows, so the target
        // lookup found a blueprint, the self-link probe's non-string fail-safe
        // answered "not this row", and the null→linked transition fired: every
        // field, option, section, group, decision table and output-order row of
        // the blueprint DELETED, `'0'` stored in the column, and the emptied
        // blueprint reading as LINKED afterwards — which makes every schema
        // route answer 409 for every role, so nothing can repair it.
        //
        // The assertion is the row counts, not the status.
        await seedWholeSchema();
        assert.deepEqual(await schemaRowCounts(), FULL_SCHEMA, 'the fixture did not seed the schema');

        const user = actor === 'admin' ? ADMIN : EDITOR;
        const res = await putNode(user, BP_MINE, { linked_blueprint_id: value });

        assert.deepEqual(
          await schemaRowCounts(), FULL_SCHEMA,
          `${label} cleared the blueprint's own schema (HTTP ${res.status})`,
        );
        assert.equal(
          (await storedNode(BP_MINE)).linked_blueprint_id, null,
          'a value that names no row was stored as this blueprint\'s link',
        );
        assert.equal(res.status, 400, `expected a stable refusal, got ${JSON.stringify(res.body)}`);
        assert.equal(res.body.error.code, 'INVALID_ID_FORMAT');
      });
    }
  }

  test('the create path answers the same way', async (t) => {
    if (guard(t)) return;
    // It already did, but only by handing the body on to the factory at the end
    // of a middleware that had already resolved a row with the value. Both verbs
    // now refuse before anything reads it.
    const created = await postNode(ADMIN, {
      name: 'numeric-link', node_type: 'blueprint', linked_blueprint_id: 0,
    });
    assert.equal(created.status, 400, `expected a stable refusal, got ${JSON.stringify(created.body)}`);
    assert.equal(created.body.error.code, 'INVALID_ID_FORMAT');
  });

  test('a numeric id on the create path resolves no referrers at all', async (t) => {
    if (guard(t)) return;
    // THE OTHER OPERAND OF THE SAME COMPARISON. The link value is floor-checked
    // on both verbs; the id the guard is ABOUT is not — on create it is
    // `body.id || null`, which passes `true` and any number. It is the sole bind
    // of `WHERE linked_blueprint_id = ?` in the B1 referrer probe, and MariaDB
    // resolves a CHAR(36) column against a number in NUMERIC context: every
    // stored value whose leading digit-run is 1 answers that predicate. So the
    // question "is this blueprint a link source for others" is decided about an
    // arbitrary set of rows belonging to no one, and the self-link probe's
    // non-string fail-safe reads the same operand as "not this row".
    //
    // Refusal-only, never destructive — but it is the hazard the floor exists
    // for, on the operand beside the one it guards.
    const BP_ONE = '1a2b3c4d-1111-4222-8333-000000000004';
    await pool.query(
      `INSERT INTO \`${tbl('hierarchy_nodes')}\` (id, name, node_type) VALUES (?, 'numeric-lead', 'blueprint')`,
      [BP_ONE],
    );
    await pool.query(
      `UPDATE \`${tbl('hierarchy_nodes')}\` SET linked_blueprint_id = ? WHERE id = ?`,
      [BP_ONE, BP_THEIRS],
    );

    const created = await postNode(ADMIN, {
      id: 1, name: 'numeric-id', node_type: 'blueprint', linked_blueprint_id: BP_SHARED,
    });

    assert.equal(created.status, 400, `expected a stable refusal, got ${JSON.stringify(created.body)}`);
    assert.equal(created.body.error.code, 'INVALID_ID_FORMAT');
  });

  test('a numeric transformer no longer reads as no transformer at all', async (t) => {
    if (guard(t)) return;
    // `effTransformerId || effTransformerVersion` is the same truthiness fold in
    // its third spelling: `0` is transformer metadata the statement WILL write,
    // and `0 || null` read it as "this blueprint has no transformer" — so a
    // create naming BOTH a link and a numeric transformer passed the
    // exclusivity guard and stored the pair B5 exists to forbid. transformer_id
    // is a declared non-identifier column (its file half is a registry key, not
    // a row), so the floor does not judge it; the XOR guard must.
    const created = await postNode(ADMIN, {
      name: 'both-set', node_type: 'blueprint', linked_blueprint_id: BP_SHARED, transformer_id: 0,
    });
    assert.equal(
      await countOf(
        `SELECT COUNT(*) AS n FROM \`${tbl('hierarchy_nodes')}\`
          WHERE transformer_id = '0' AND linked_blueprint_id IS NOT NULL`,
      ),
      0, 'a blueprint was stored carrying both a link and a transformer',
    );
    assert.equal(created.status, 400, `expected a stable refusal, got ${JSON.stringify(created.body)}`);
    assert.equal(created.body.error.code, 'TRANSFORMER_LINK_EXCLUSIVE');
  });

  test('a legacy both-set row can still be saved when the write moves nothing', async (t) => {
    if (guard(t)) return;
    // The grandfather exists so a row that was ALREADY carrying both a link and
    // a transformer can be saved at all — to change an unrelated field, or to
    // clear one side and repair it. It is switched off by "did this write change
    // the pair", which was a JavaScript `!==` on a column every reader resolves
    // with `WHERE id = ?`. So a client echoing back the id it had been given in
    // another case — the field editor spreads the whole form, so ids travel back
    // on every save — read as a CHANGE, and the row could not be saved at all.
    await pool.query(
      `UPDATE \`${tbl('hierarchy_nodes')}\` SET linked_blueprint_id = ?, transformer_id = ?
        WHERE id = ?`,
      [BP_SHARED, 'a1b2c3d4-1111-4222-8333-000000000099', BP_MINE],
    );

    const res = await putNode(ADMIN, BP_MINE, {
      linked_blueprint_id: BP_SHARED.toUpperCase(), name: 'renamed',
    });

    const row = await storedNode(BP_MINE);
    assert.equal(row.name, 'renamed', 'a save that moves nothing was refused');
    assert.equal(
      row.linked_blueprint_id, BP_SHARED,
      'the resend rewrote the link column in the caller\'s spelling',
    );
    assert.equal(res.status, 200, `expected the save to land, got ${JSON.stringify(res.body)}`);
  });

  test('a legacy both-set row still cannot have the forbidden pair edited', async (t) => {
    if (guard(t)) return;
    // The control. The grandfather is for a write that leaves the pair alone; a
    // write that points the link at a DIFFERENT blueprint while the transformer
    // stays set is still editing the invalid combination rather than repairing
    // it, and must still be refused.
    await pool.query(
      `UPDATE \`${tbl('hierarchy_nodes')}\` SET linked_blueprint_id = ?, transformer_id = ?
        WHERE id = ?`,
      [BP_SHARED, 'a1b2c3d4-1111-4222-8333-000000000099', BP_MINE],
    );

    const res = await putNode(ADMIN, BP_MINE, { linked_blueprint_id: BP_THEIRS });

    assert.equal(
      (await storedNode(BP_MINE)).linked_blueprint_id, BP_SHARED,
      'the forbidden pair was edited rather than repaired',
    );
    assert.equal(res.status, 400, `expected a stable refusal, got ${JSON.stringify(res.body)}`);
    assert.equal(res.body.error.code, 'TRANSFORMER_LINK_EXCLUSIVE');
  });

  test('a legitimate link still transitions with the whole schema seeded', async (t) => {
    if (guard(t)) return;
    // The control for every refusal above: a fix that refused these bodies by
    // refusing all of them would be indistinguishable from one that works.
    await seedWholeSchema();
    const res = await putNode(ADMIN, BP_MINE, { linked_blueprint_id: BP_SHARED });

    assert.equal(res.status, 200, `a legitimate link was refused: ${JSON.stringify(res.body)}`);
    assert.deepEqual(
      await schemaRowCounts(),
      { fields: 0, options: 0, sections: 0, groups: 0, output_order: 0, decision_tables: 0 },
      'the now-unreachable schema was left behind',
    );
    assert.equal((await storedNode(BP_MINE)).linked_blueprint_id, BP_SHARED);
  });
});

// ── T13b — and the spelling the link column KEEPS is the stored one ──────────

describe('the spelling the link column keeps', () => {
  test('a transition stores the target row\'s own id, not the caller\'s spelling', async (t) => {
    if (guard(t)) return;
    // The engine resolves `WHERE id = ?` under the column's collation, so the
    // uppercase form finds the blueprint and every guard is decided about the
    // right row — and the statement then wrote the caller's bytes. SQL still
    // resolves the link; JavaScript does not. The read-only banner names its
    // source with `allNodes.find(n => n.id === linkedSourceId)` and the link
    // picker matches its `Select` value byte-wise, so a blueprint that IS linked
    // shows an empty picker and an unnamed source.
    await seedField();
    const res = await putNode(ADMIN, BP_MINE, { linked_blueprint_id: BP_SHARED.toUpperCase() });

    assert.equal(res.status, 200, `a legitimate link was refused: ${JSON.stringify(res.body)}`);
    assert.equal(
      (await storedNode(BP_MINE)).linked_blueprint_id, BP_SHARED,
      'the link column holds bytes no JavaScript reader resolves to the source',
    );
  });

  test('a resend of the same link in another case leaves the stored bytes alone', async (t) => {
    if (guard(t)) return;
    // The non-transition half: the row is ALREADY linked, so this handler hands
    // the body to the factory, which binds what the caller sent. The Hierarchy
    // form spreads the whole node, so the id it was given travels back on every
    // save of an unrelated field.
    await pool.query(
      `UPDATE \`${tbl('hierarchy_nodes')}\` SET linked_blueprint_id = ? WHERE id = ?`,
      [BP_SHARED, BP_MINE],
    );

    const res = await putNode(ADMIN, BP_MINE, {
      linked_blueprint_id: BP_SHARED.toUpperCase(), name: 'renamed',
    });

    const row = await storedNode(BP_MINE);
    assert.equal(res.status, 200, `a legitimate save was refused: ${JSON.stringify(res.body)}`);
    assert.equal(row.name, 'renamed', 'the save did not land');
    assert.equal(
      row.linked_blueprint_id, BP_SHARED,
      'an echo of the id in another case rewrote the link column',
    );
  });

  test('a move to a different source stores that source\'s own id', async (t) => {
    if (guard(t)) return;
    // Still not a transition — the row is linked before and after — so it also
    // falls through to the factory, and the target it names is a THIRD row whose
    // stored spelling is the one every reader resolves.
    await pool.query(
      `UPDATE \`${tbl('hierarchy_nodes')}\` SET linked_blueprint_id = ? WHERE id = ?`,
      [BP_SHARED, BP_MINE],
    );

    const res = await putNode(ADMIN, BP_MINE, { linked_blueprint_id: BP_THEIRS.toUpperCase() });

    assert.equal(res.status, 200, `a legitimate re-link was refused: ${JSON.stringify(res.body)}`);
    assert.equal(
      (await storedNode(BP_MINE)).linked_blueprint_id, BP_THEIRS,
      'the re-link stored the caller\'s spelling of the new source',
    );
  });

  test('a create stores the target row\'s own id too', async (t) => {
    if (guard(t)) return;
    // THE SAME DEFECT ON THE OTHER VERB, and the reason the normalisation is not
    // written into the transition branch alone: the create path hands the body
    // straight to the factory once the link constraints pass, so a POST naming
    // its source in another case stores that spelling on a brand-new row.
    const created = await postNode(ADMIN, {
      name: 'linked-child', node_type: 'blueprint',
      linked_blueprint_id: BP_SHARED.toUpperCase(),
    });

    assert.equal(created.status, 200, `a legitimate create was refused: ${JSON.stringify(created.body)}`);
    const stored = await one(
      `SELECT linked_blueprint_id FROM \`${tbl('hierarchy_nodes')}\` WHERE name = ?`,
      ['linked-child'],
    );
    assert.equal(
      stored.linked_blueprint_id, BP_SHARED,
      'the create stored the caller\'s spelling of the source',
    );
  });
});

// ── T5 — the destination is checked, not just the source (row 8) ─────────────

describe('the blueprint a field is moved INTO', () => {
  test('an editor cannot move a field into a blueprint they do not own', async (t) => {
    if (guard(t)) return;
    // ROW 8. Ownership was resolved from the row's STORED parent — the blueprint
    // the field is leaving — so an editor who owns the source could name any
    // blueprint at all as the destination. The field lands under a blueprint
    // they cannot read, in a schema its owner did not author, and the column
    // carries no foreign key to say otherwise.
    await seedField();
    const res = await putField(EDITOR, FIELD_ID, { blueprint_id: BP_THEIRS });

    assert.equal(
      (await storedField()).blueprint_id, BP_MINE,
      'an editor moved a field into a blueprint owned by someone else',
    );
    assert.equal(res.status, 404, `expected the existence-leak-parity refusal, got ${JSON.stringify(res.body)}`);
  });

  test('a field cannot be orphaned by naming no blueprint', async (t) => {
    if (guard(t)) return;
    // ROWS 18/19's destructive half. `data.blueprint_id != null` read an explicit
    // null as "unchanged", so every gate judged the stored parent while the
    // UPDATE wrote NULL — the field left the hierarchy entirely, reachable by no
    // schema route and listed under no blueprint.
    await seedField();
    const res = await putField(ADMIN, FIELD_ID, { blueprint_id: null });

    assert.equal((await storedField()).blueprint_id, BP_MINE, 'the field was orphaned');
    assert.notEqual(res.status, 200, `expected a refusal, got ${JSON.stringify(res.body)}`);
  });

  test('a destination that is not a blueprint is refused for every role', async (t) => {
    if (guard(t)) return;
    // Existence and node_type are asked of EVERY role, because the column has no
    // foreign key: an id nobody checked leaves the field unreachable from the
    // hierarchy the Schema Builder walks, and an administrator's write is no
    // more able to make a variant into a blueprint than an editor's.
    const VARIANT = 'a1b2c3d4-1111-4222-8333-00000000000v'.replace('v', '4');
    await pool.query(
      `INSERT INTO \`${tbl('hierarchy_nodes')}\` (id, name, node_type, parent_id) VALUES (?, 'v', 'variant', ?)`,
      [VARIANT, BP_MINE],
    );
    await seedField();

    for (const destination of [VARIANT, 'a1b2c3d4-1111-4222-8333-999999999999']) {
      const res = await putField(ADMIN, FIELD_ID, { blueprint_id: destination });
      assert.equal(
        (await storedField()).blueprint_id, BP_MINE,
        `a field was moved onto ${destination}`,
      );
      assert.notEqual(res.status, 200, `expected a refusal, got ${JSON.stringify(res.body)}`);
    }
  });

  test('a numeric destination resolves no blueprint at all', async (t) => {
    if (guard(t)) return;
    // The identifier floor, on the handler that bypasses the factory carrying
    // it. Measured through this driver: `WHERE id = ?` with a JS `0` is sent as
    // a true numeric bind and matches every CHAR(36) row whose leading digit-run
    // is 0 — so the destination guard would be decided about an ARBITRARY
    // blueprint, and the statement would then store the literal.
    await seedField();
    const res = await putField(EDITOR, FIELD_ID, { blueprint_id: 0 });

    assert.equal((await storedField()).blueprint_id, BP_MINE, 'a numeric destination was stored');
    assert.equal(res.status, 400, `expected a stable refusal, got ${JSON.stringify(res.body)}`);
    assert.equal(res.body.error.code, 'INVALID_ID_FORMAT');
  });

  test('a move into a shared blueprint still lands', async (t) => {
    if (guard(t)) return;
    // The other half of the guard: a blueprint nobody owns is shared, and moving
    // a field into it is the ordinary path an editor takes.
    await seedField();
    const res = await putField(EDITOR, FIELD_ID, { blueprint_id: BP_SHARED });

    assert.equal(res.status, 200, `a legitimate move was refused: ${JSON.stringify(res.body)}`);
    assert.equal((await storedField()).blueprint_id, BP_SHARED, 'the legitimate move did not land');
  });
});

// ── T15 — the duplicate an import produces is refused as a duplicate ─────────

describe('a duplicate field key an import produces', () => {
  const RELEASE = 'a1b2c3d4-1111-4222-8333-0000000000e1';

  const importPayload = (fieldKeys) => ({
    import_version: 1,
    hierarchy_node: { name: 'imported', node_type: 'blueprint', is_active: true },
    blueprint_fields: fieldKeys.map((key, i) => ({
      id: `f0000000-0000-4000-8000-00000000000${i}`,
      field_key: key,
      field_label: key,
      field_type: 'text',
      section: 'general',
    })),
    field_options: [],
    blueprint_sections: [],
    blueprint_output_order: [],
  });

  const runImport = (payload) => call(
    ADMIN, 'POST', `/edge/app/schema/blueprint-import?target_parent_id=${RELEASE}`, payload,
  );

  const importedFieldCount = () => countOf(
    `SELECT COUNT(*) AS n FROM \`${tbl('blueprint_fields')}\` WHERE field_key IN ('city', 'City')`,
  );

  beforeEach(async () => {
    if (!dbReady) return;
    await pool.query(
      `INSERT INTO \`${tbl('hierarchy_nodes')}\` (id, name, node_type) VALUES (?, 'rel', 'release')`,
      [RELEASE],
    );
  });

  test('is answered as a duplicate, not as a server fault', async (t) => {
    if (guard(t)) return;
    // The payload validator refuses two IDENTICAL keys, in JavaScript — so
    // `city` and `City` pass it, and the UNIQUE index, which folds case, is what
    // catches them. On a database that took that index the 1062 reached the
    // route's catch-all and came back as a 500 "Import failed": the operator is
    // told their file caused a server fault, and invited to retry something that
    // can never succeed. Both endpoints that WRITE this key already answer 409
    // for the same collision. Refusing is right; the sentence was not.
    const res = await runImport(importPayload(['city', 'City']));

    assert.equal(await importedFieldCount(), 0, 'a duplicate pair was stored');
    assert.equal(res.status, 409, `expected the duplicate refusal, got ${JSON.stringify(res.body)}`);
    assert.equal(res.body.error.code, 'DUPLICATE_FIELD_KEY');
  });

  test('an import with distinct keys still lands', async (t) => {
    if (guard(t)) return;
    // The control: mapping 1062 must not become "refuse the import".
    const res = await runImport(importPayload(['city', 'zone']));

    assert.equal(res.status, 200, `a legitimate import was refused: ${JSON.stringify(res.body)}`);
    assert.equal(
      await countOf(`SELECT COUNT(*) AS n FROM \`${tbl('blueprint_fields')}\` WHERE field_key = 'city'`),
      1, 'the import stored nothing',
    );
  });
});

// ── T14 — the clash probe's own default, which excluded every row ────────────

const { fieldKeyTaken } = require('../../src/edge/routes/app/schema/field-key');

describe('the field-key clash probe asked with no row to exclude', () => {
  const askProbe = async (...args) => {
    const conn = await pool.getConnection();
    try {
      return await fieldKeyTaken(conn, ...args);
    } finally {
      conn.release();
    }
  };

  test('answers about the rows that are really there', async (t) => {
    if (guard(t)) return;
    // `id <> NULL` is UNKNOWN for every row, so the probe's own default
    // `excludeFieldId = null` did not mean "exclude nothing" — it meant "match
    // nothing", and the guard answered "this key is free" about every key in the
    // table. Dormant only because both callers today pass a real id; this is the
    // module whose whole purpose is to be the ONE place the rule lives, so a
    // create-path caller taking the default would have got a guard that had
    // already stopped working. Asserted against seeded ROWS, not a status.
    await seedField({ field_key: 'city' });

    assert.equal(await askProbe(BP_MINE, 'city'), true, 'a key a field really holds read as free');
    assert.equal(await askProbe(BP_MINE, 'zone'), false, 'a key no field holds read as taken');
  });

  test('still folds capitalisation the way the index does, with no row excluded', async (t) => {
    if (guard(t)) return;
    // The property the probe exists for must survive the default too: the column
    // folds case, so `City` and `city` are one key to the index that enforces
    // this and to any `WHERE field_key = ?` lookup.
    await seedField({ field_key: 'City' });
    assert.equal(await askProbe(BP_MINE, 'city'), true, 'the probe stopped asking the column');
  });

  test('still excludes the named row when one is named', async (t) => {
    if (guard(t)) return;
    // The control: the exclusion is what lets a field be saved under the key it
    // already holds, and it must keep working.
    await seedField({ field_key: 'city' });
    assert.equal(await askProbe(BP_MINE, 'city', FIELD_ID), false, 'a field clashed with itself');
    await seedSibling('city2');
    assert.equal(
      await askProbe(BP_MINE, 'city', SIBLING_ID), true,
      'a key another field holds read as free',
    );
  });

  test('a key held under a DIFFERENT blueprint is not taken here', async (t) => {
    if (guard(t)) return;
    // The other control: the rule is one key per BLUEPRINT, and dropping the
    // exclusion must not widen it into one key per installation.
    await seedField({ field_key: 'city' });
    assert.equal(await askProbe(BP_SHARED, 'city'), false, 'the probe left its blueprint');
  });
});

// ── T6 — the UNIQUE index the probe cannot be, and the databases it cannot
//        be created on (the race half of rows 4 and 25) ───────────────────────

const { createMigrationsModule } = require('../../src/edge/migrations');
const { MIGRATION_STEPS } = require('../../src/edge/migration-steps');
const { derivePendingStepNames } = require('../../src/edge/lib/pending-steps');

const FIELD_KEY_STEP = 'blueprint_fields_field_key_unique_index';
const fieldsTable = () => tbl('blueprint_fields');

async function indexIsUnique(indexName) {
  const rows = await pool.query(
    `SELECT NON_UNIQUE FROM information_schema.STATISTICS
      WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND INDEX_NAME = ? LIMIT 1`,
    [fieldsTable(), indexName],
  );
  return rows.length > 0 && Number(rows[0].NON_UNIQUE) === 0;
}

describe('one field key per blueprint, in the schema', () => {
  test('a database built from the DDL carries the unique index', async (t) => {
    if (guard(t)) return;
    // The backstop the in-transaction probe cannot be: two writes claiming one
    // key can both pass a probe, and only the index refuses the second.
    assert.equal(
      await indexIsUnique('uq_blueprint_field_key'), true,
      'a freshly created blueprint_fields has no unique (blueprint_id, field_key) index',
    );
  });

  test('the index really refuses the duplicate the probe would have raced', async (t) => {
    if (guard(t)) return;
    await seedField({ field_key: 'city' });
    await assert.rejects(
      () => pool.query(
        `INSERT INTO \`${fieldsTable()}\` (id, blueprint_id, field_key, field_type)
         VALUES (UUID(), ?, 'city', 'text')`,
        [BP_MINE],
      ),
      (err) => err.errno === 1062,
      'the database accepted a second field under the same key',
    );
    assert.equal(
      await countOf(
        `SELECT COUNT(*) AS n FROM \`${fieldsTable()}\` WHERE blueprint_id = ? AND field_key = 'city'`,
        [BP_MINE],
      ),
      1, 'a duplicate key row landed',
    );
  });

  test('a database that already holds duplicates is carried, not failed', async (t) => {
    if (guard(t)) return;
    // The migration cannot create this index on a customer database that
    // already has duplicate pairs, and an unconditional ALTER would fail on
    // every boot there. The step scans first and skips — accounted as a skip, so
    // the version stamp is held back and the step stays VISIBLE in
    // schema/status' pending list instead of being silently declared done. The
    // app-layer probe is what carries that database until a DBA resolves them.
    await pool.query(`ALTER TABLE \`${fieldsTable()}\` DROP INDEX uq_blueprint_field_key`);
    try {
      await seedField({ field_key: 'city' });
      await pool.query(
        `INSERT INTO \`${fieldsTable()}\` (id, blueprint_id, field_key, field_type)
         VALUES (?, ?, 'city', 'text')`,
        [SIBLING_ID, BP_MINE],
      );

      const step = MIGRATION_STEPS.find((s) => s.step === FIELD_KEY_STEP);
      assert.ok(step, 'the registry has no entry for the field-key index');
      const migrations = createMigrationsModule({
        t: tbl,
        PLATFORM_SCHEMA_VERSION: '3.2.629',
        _configFull: { database: testDbName, user: 'root' },
        _tablePrefix: TEST_PREFIX,
        APP_TABLE_NAMES: [],
      });
      const conn = await pool.getConnection();
      let result;
      let pending;
      try {
        result = await migrations._runMigrationSteps(conn, [step]);
        pending = await derivePendingStepNames(conn, tbl, [step]);
      } finally {
        conn.release();
      }

      assert.equal(result.skippedSteps, 1, 'the skip was not accounted, so the stamp would advance');
      assert.equal(await indexIsUnique('uq_blueprint_field_key'), false, 'the index was created over duplicates');
      assert.deepEqual(pending, [FIELD_KEY_STEP], 'the skipped step is not visible as pending');
      assert.equal(
        await countOf(`SELECT COUNT(*) AS n FROM \`${fieldsTable()}\``), 2,
        'the skipped migration touched the rows',
      );

      // And the app-layer probe still refuses the NEXT duplicate, which is what
      // carries this database while a DBA resolves the ones it already holds.
      const THIRD_ID = 'f1e2d3c4-1111-4222-8333-000000000003';
      await pool.query(
        `INSERT INTO \`${fieldsTable()}\` (id, blueprint_id, field_key, field_type)
         VALUES (?, ?, 'zone', 'text')`,
        [THIRD_ID, BP_MINE],
      );
      const res = await putField(ADMIN, THIRD_ID, { field_key: 'city' });
      assert.equal(
        (await storedField(THIRD_ID)).field_key, 'zone',
        'a third duplicate was written on a database with no index to refuse it',
      );
      assert.equal(res.status, 409, `expected the probe's refusal, got ${JSON.stringify(res.body)}`);
    } finally {
      await pool.query(`DELETE FROM \`${fieldsTable()}\``);
      await pool.query(
        `ALTER TABLE \`${fieldsTable()}\` ADD UNIQUE KEY uq_blueprint_field_key (blueprint_id, field_key)`,
      );
    }
  });

  test('a database with no duplicates gains the index and reports nothing pending', async (t) => {
    if (guard(t)) return;
    // The ordinary upgrade: the same step, on the same database, once the
    // duplicates are gone. This is what makes the skip above a hold rather than
    // a dead end.
    await pool.query(`ALTER TABLE \`${fieldsTable()}\` DROP INDEX uq_blueprint_field_key`);
    let restored = false;
    try {
      await seedField({ field_key: 'city' });
      const step = MIGRATION_STEPS.find((s) => s.step === FIELD_KEY_STEP);
      const migrations = createMigrationsModule({
        t: tbl,
        PLATFORM_SCHEMA_VERSION: '3.2.629',
        _configFull: { database: testDbName, user: 'root' },
        _tablePrefix: TEST_PREFIX,
        APP_TABLE_NAMES: [],
      });
      const conn = await pool.getConnection();
      let result;
      let pending;
      try {
        result = await migrations._runMigrationSteps(conn, [step]);
        pending = await derivePendingStepNames(conn, tbl, [step]);
      } finally {
        conn.release();
      }

      assert.equal(result.skippedSteps, 0, 'a clean database still skipped the step');
      restored = await indexIsUnique('uq_blueprint_field_key');
      assert.equal(restored, true, 'the index was not created on a clean database');
      assert.deepEqual(pending, [], 'a satisfied step is still reported pending');
    } finally {
      if (!restored) {
        await pool.query(
          `ALTER TABLE \`${fieldsTable()}\` ADD UNIQUE KEY uq_blueprint_field_key (blueprint_id, field_key)`,
        );
      }
    }
  });
});
