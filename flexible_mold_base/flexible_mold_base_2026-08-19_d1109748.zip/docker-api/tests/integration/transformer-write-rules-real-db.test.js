'use strict';

/**
 * transformer-write-rules-real-db.test.js — the create rule and the update rule
 * for a column are the same rule, and "referenced" means every table that
 * references it.
 *
 * Every case reads the stored row back. Three of these defects are invisible to
 * a status code by construction: a lost update answers 200 with the row it just
 * overwrote, an empty string written over live code answers 200 with an empty
 * `code`, and a hard delete that misses a referrer answers 200 exactly as a
 * legitimate delete does. And two of them depend on the DATABASE's answer rather
 * than JavaScript's — `code TEXT NOT NULL` accepts `''`, and a 300-character
 * name is `ERROR 1406` under the deployed strict `sql_mode` where the create
 * path gives a clean 400.
 *
 * The run-serializer case lives here too: it is the same invariant on a
 * different column — two write paths to `error_summary` that disagree about
 * whether it can carry a secret.
 *
 * Skips with a stated reason when no database is reachable, and fails instead
 * of skipping when REQUIRE_INTEGRATION_DB=1.
 */
const { test, describe, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const net = require('node:net');
const http = require('node:http');
const express = require('express');
const mariadb = require('mariadb');

const TEST_PREFIX = 'txwr_';
const tbl = (name) => `${TEST_PREFIX}${name}`;

let pool = null;
const lease = () => pool.getConnection();
const query = (sql, params) => pool.query(sql, params);
const poolFacade = { getConnection: lease, query };

const dbKey = require.resolve('../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey,
  filename: dbKey,
  loaded: true,
  exports: {
    pool: { ro: poolFacade, rw: poolFacade },
    t: tbl,
    getDynamicPool: async () => ({ ro: poolFacade, rw: poolFacade }),
  },
};

const { buildEngineTableDDLs, buildInfraTableDDLs } = require('../../src/table-ddls');
const { TABLES } = require('../../src/shared/constants');
const transformersRouter = require('../../src/edge/routes/app/transformers');
const runsRouter = require('../../src/edge/routes/app/flow-recipe-runs');

const { fixtureUserId } = require('../helpers/fixture-ids');

// ── Config auto-detection (same shape as the sibling integration tests) ──────

function parseEnvFile(filePath) {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    const out = {};
    for (const line of content.split('\n')) {
      const m = line.match(/^\s*([A-Z_][A-Z0-9_]*)\s*=\s*(.*)\s*$/);
      if (!m) continue;
      let value = m[2];
      if ((value.startsWith('"') && value.endsWith('"'))
        || (value.startsWith("'") && value.endsWith("'"))) {
        value = value.slice(1, -1);
      }
      out[m[1]] = value;
    }
    return out;
  } catch {
    return null;
  }
}

function probePort(host, port, timeoutMs = 2000) {
  return new Promise((resolve) => {
    const socket = new net.Socket();
    let done = false;
    const finish = (ok) => {
      if (done) return;
      done = true;
      socket.destroy();
      resolve(ok);
    };
    socket.setTimeout(timeoutMs);
    socket.once('connect', () => finish(true));
    socket.once('timeout', () => finish(false));
    socket.once('error', () => finish(false));
    socket.connect(port, host);
  });
}

async function resolveMariaDbConfig() {
  if (process.env.DB_TEST_HOST && process.env.DB_TEST_ROOT_PASSWORD) {
    return {
      host: process.env.DB_TEST_HOST,
      port: parseInt(process.env.DB_TEST_PORT || '3306', 10),
      user: 'root',
      password: process.env.DB_TEST_ROOT_PASSWORD,
    };
  }
  const envPath = path.resolve(__dirname, '../../../.devcontainer/.env');
  const env = parseEnvFile(envPath);
  if (!env || !env.DB_ROOT_PASSWORD) return null;
  const port = parseInt(env.DB_PORT || '3306', 10);
  for (const host of ['127.0.0.1', 'mariadb', 'localhost']) {
    if (await probePort(host, port, 2000)) {
      return { host, port, user: 'root', password: env.DB_ROOT_PASSWORD };
    }
  }
  return null;
}

// ── Fixture ─────────────────────────────────────────────────────────────────

const ADMIN = { id: fixtureUserId('admin'), role: 'admin', email: 'author@corp.example' };

const WANTED_TABLES = [
  TABLES.TRANSFORMERS,
  TABLES.TRANSFORMER_VERSIONS,
  TABLES.HIERARCHY_NODES,
  TABLES.API_CONNECTORS,
  TABLES.FLOW_RECIPE_RUNS,
  TABLES.FEATURE_AUDIT,
  TABLES.USERS,
];

let dbReady = false;
let skipReason = null;
let testDbName = null;
let server = null;
let baseUrl = null;
let currentUser = ADMIN;

before(async () => {
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) {
    skipReason = 'no MariaDB reachable via .devcontainer/.env or env vars';
    if (process.env.REQUIRE_INTEGRATION_DB === '1') {
      throw new Error(`REQUIRE_INTEGRATION_DB=1 set but ${skipReason}.`);
    }
    return;
  }
  testDbName = `tx_write_test_${process.pid}_${Date.now()}`;
  let admin = null;
  try {
    admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`CREATE DATABASE \`${testDbName}\``);
    await admin.query(`USE \`${testDbName}\``);
    const wanted = new Set(WANTED_TABLES.map(tbl));
    const statements = [...buildInfraTableDDLs(tbl), ...buildEngineTableDDLs(tbl)].filter((sql) => {
      const m = sql.match(/CREATE TABLE IF NOT EXISTS `([^`]+)`/);
      return m && wanted.has(m[1]);
    });
    assert.equal(
      statements.length, wanted.size,
      `the DDL list no longer defines all of: ${[...wanted].join(', ')}`,
    );
    for (const sql of statements) await admin.query(sql);
    await admin.end();
    admin = null;

    pool = mariadb.createPool({
      ...dbConfig, database: testDbName, connectionLimit: 6, connectTimeout: 5000,
    });

    const app = express();
    app.use(express.json());
    app.use((req, _res, next) => { req.user = currentUser; next(); });
    app.use('/edge/app/transformers', transformersRouter);
    app.use('/edge/app/flow-recipe-runs', runsRouter);
    server = http.createServer(app);
    await new Promise((r) => server.listen(0, r));
    baseUrl = `http://127.0.0.1:${server.address().port}`;
    dbReady = true;
  } catch (err) {
    skipReason = `setup failed: ${err.message}`;
    if (admin) { try { await admin.end(); } catch { /* best effort */ } }
    if (process.env.REQUIRE_INTEGRATION_DB === '1') throw err;
  }
});

after(async () => {
  if (server) { try { server.close(); } catch { /* best effort */ } }
  if (pool) { try { await pool.end(); } catch { /* best effort */ } }
  if (!testDbName) return;
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) return;
  try {
    const admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`DROP DATABASE IF EXISTS \`${testDbName}\``);
    await admin.end();
  } catch { /* best effort */ }
});

const guard = (t) => {
  if (!dbReady) { t.skip(skipReason || 'database not ready'); return true; }
  return false;
};

async function call(user, method, url, body) {
  currentUser = user;
  const res = await fetch(`${baseUrl}${url}`, {
    method,
    headers: { 'content-type': 'application/json' },
    ...(body === undefined ? {} : { body: JSON.stringify(body) }),
  });
  const text = await res.text();
  let parsed = null;
  try { parsed = JSON.parse(text); } catch { parsed = { raw: text }; }
  return { status: res.status, body: parsed };
}

beforeEach(async () => {
  if (!dbReady) return;
  await query(`DELETE FROM \`${tbl(TABLES.TRANSFORMER_VERSIONS)}\``);
  await query(`DELETE FROM \`${tbl(TABLES.TRANSFORMERS)}\``);
  await query(`DELETE FROM \`${tbl(TABLES.API_CONNECTORS)}\``);
  await query(`DELETE FROM \`${tbl(TABLES.HIERARCHY_NODES)}\``);
  await query(`DELETE FROM \`${tbl(TABLES.FLOW_RECIPE_RUNS)}\``);
});

const LIVE_CODE = 'module.exports = (input) => ({ ok: true, input });';

async function createTransformer(user = ADMIN, over = {}) {
  const res = await call(user, 'POST', '/edge/app/transformers', {
    name: 'fixture', description: 'd', code: LIVE_CODE, ...over,
  });
  assert.equal(res.status, 201, `fixture create was refused: ${JSON.stringify(res.body)}`);
  return res.body.data.id;
}

async function storedTransformer(id) {
  const rows = await query(
    `SELECT id, name, description, code, code_size, version, is_active, created_by, updated_by
       FROM \`${tbl(TABLES.TRANSFORMERS)}\` WHERE id = ?`,
    [id],
  );
  return rows[0] || null;
}

describe('who authored this is one value on every surface', () => {
  test('no transformer surface returns an author\'s full email address', async (t) => {
    if (guard(t)) return;
    // `owner_name` on the very same response object is reduced to its local part
    // under a stated never-return-email contract; `created_by`/`updated_by` STORE
    // `req.user.email` and were returned raw beside it. So every admin and
    // editor reading the list learned every author's full address, and the same
    // value is durable — it is written into every version row too.
    const id = await createTransformer();
    await call(ADMIN, 'PUT', `/edge/app/transformers/${id}`, {
      code: `${LIVE_CODE}\n// touched`, expected_version: 1,
    });

    const stored = await storedTransformer(id);
    assert.equal(stored.created_by, ADMIN.email, 'the fixture no longer stores the email');

    const surfaces = [
      ['list', await call(ADMIN, 'GET', '/edge/app/transformers')],
      ['single', await call(ADMIN, 'GET', `/edge/app/transformers/${id}`)],
      ['versions', await call(ADMIN, 'GET', `/edge/app/transformers/${id}/versions`)],
    ];
    for (const [label, res] of surfaces) {
      assert.equal(res.status, 200, `${label}: ${JSON.stringify(res.body)}`);
      assert.equal(
        JSON.stringify(res.body).includes(ADMIN.email), false,
        `${label}: the response carried the author's full email address`,
      );
      assert.equal(
        JSON.stringify(res.body).includes('author'), true,
        `${label}: the author attribution was lost entirely, not reduced`,
      );
    }
  });

  test('the create and update responses carry the reduced form too', async (t) => {
    if (guard(t)) return;
    // The two surfaces that re-read the row with `SELECT *` right after writing
    // it. A rule applied to the list and not to the write's own response is the
    // same defect one hop later.
    const created = await call(ADMIN, 'POST', '/edge/app/transformers', {
      name: 'fresh', code: LIVE_CODE,
    });
    assert.equal(created.status, 201, JSON.stringify(created.body));
    assert.equal(created.body.data.created_by, 'author');

    const updated = await call(ADMIN, 'PUT', `/edge/app/transformers/${created.body.data.id}`, {
      code: `${LIVE_CODE} `, expected_version: 1,
    });
    assert.equal(updated.status, 200, JSON.stringify(updated.body));
    assert.equal(updated.body.data.updated_by, 'author');
  });
});

describe('two write paths to one column agree about what it can carry', () => {
  test('the generic run PUT masks a secret in error_summary, as the finalize path does', async (t) => {
    if (guard(t)) return;
    // The finalize path masks this column because an upstream failure body is
    // exactly where a credential-vending service echoes a token back. The
    // generic PUT — open to the run's own actor and to any admin — wrote the
    // same column raw into a row every authenticated caller reads.
    const runId = '77777777-7777-4777-8777-777777777777';
    await query(
      `INSERT INTO \`${tbl(TABLES.FLOW_RECIPE_RUNS)}\`
         (id, recipe_id, actor_id, mode, status)
       VALUES (?, '88888888-8888-4888-8888-888888888888', ?, 'create', 'partial')`,
      [runId, ADMIN.id],
    );

    const res = await call(ADMIN, 'PUT', `/edge/app/flow-recipe-runs/${runId}`, {
      error_summary: '{"message":"upstream refused","access_token":"a-real-token"}',
    });
    assert.equal(res.status, 200, `the run update was refused: ${JSON.stringify(res.body)}`);

    const rows = await query(
      `SELECT error_summary FROM \`${tbl(TABLES.FLOW_RECIPE_RUNS)}\` WHERE id = ?`, [runId],
    );
    assert.equal(
      rows[0].error_summary.includes('a-real-token'), false,
      'the generic PUT stored a secret-named value in the audit column verbatim',
    );
    assert.equal(
      rows[0].error_summary.includes('upstream refused'), true,
      'masking removed the diagnostic the column exists for',
    );
  });
});

describe('the create rule and the update rule for a column are the same rule', () => {
  async function versionRows(id) {
    return query(
      `SELECT version, code FROM \`${tbl(TABLES.TRANSFORMER_VERSIONS)}\`
        WHERE transformer_id = ? ORDER BY version`,
      [id],
    );
  }

  test('an empty code is refused instead of overwriting the live code', async (t) => {
    if (guard(t)) return;
    // Two different notions of "absent", three lines apart: the size guard tested
    // TRUTHINESS (`if (code && …)`) so `''` was "no code supplied, nothing to
    // check", and the back-fill tested NULLISH (`code ?? existing.code`) so `''`
    // was a value and went to the column. `code TEXT NOT NULL` accepts it, so the
    // live code was replaced by an empty string, `code_size` recomputed as 0, and
    // `GET /active` — which every data-entry client reads — then served an empty
    // transformer. A version snapshot recording the empty code was written too.
    const id = await createTransformer();

    const res = await call(ADMIN, 'PUT', `/edge/app/transformers/${id}`, {
      code: '', expected_version: 1,
    });

    const stored = await storedTransformer(id);
    assert.equal(stored.code, LIVE_CODE, `the live code was overwritten (PUT ${res.status})`);
    assert.equal(stored.version, 1, 'a refused save still bumped the version');
    assert.equal((await versionRows(id)).length, 1, 'a refused save wrote a version snapshot');
    assert.equal(res.status, 400, `expected a stable 400, got ${JSON.stringify(res.body)}`);
  });

  test('the update path judges name and description by the create path\'s rules', async (t) => {
    if (guard(t)) return;
    // The create path requires a string name of at most 255 characters and a
    // description of at most 10000; the update path had NEITHER. `PUT
    // {"name": 12345}` stored '12345'; a 300-character name is ERROR 1406 under
    // the deployed strict sql_mode and surfaced as a 500 with a driver stack
    // where POST gives a clean 400; and `name ?? existing.name` let `''` through,
    // because `??` is nullish and `''` is not.
    const id = await createTransformer();
    const cases = [
      ['a number', { name: 12345 }],
      ['an empty string', { name: '' }],
      ['a 300-character name', { name: 'n'.repeat(300) }],
      ['a 10001-character description', { description: 'd'.repeat(10001) }],
    ];
    for (const [label, body] of cases) {
      const res = await call(ADMIN, 'PUT', `/edge/app/transformers/${id}`, {
        ...body, expected_version: 1,
      });
      assert.equal(res.status, 400, `${label}: expected a stable 400, got ${JSON.stringify(res.body)}`);
      const stored = await storedTransformer(id);
      assert.equal(stored.name, 'fixture', `${label}: the stored name moved`);
      assert.equal(stored.description, 'd', `${label}: the stored description moved`);
      assert.equal(stored.version, 1, `${label}: a refused save bumped the version`);
    }
  });

  test('a second save of the same version is a conflict, not a silent overwrite', async (t) => {
    if (guard(t)) return;
    // TWO EDITORS, ONE TRANSFORMER. The optimistic lock was skipped entirely when
    // the client omitted `expected_version`, which is the caller deciding whether
    // the server enforces. Both saves answered 200 and the second overwrote the
    // first's code with no conflict and no signal — the FOR UPDATE serialises
    // them, so the counter and the version table stay consistent; the CODE is
    // what was lost.
    const id = await createTransformer();

    const first = await call(ADMIN, 'PUT', `/edge/app/transformers/${id}`, {
      code: 'FIRST-EDITOR-CODE', expected_version: 1,
    });
    assert.equal(first.status, 200, `the first save was refused: ${JSON.stringify(first.body)}`);

    // Both saves are the same authorised author holding the same stale view of
    // the row — the role is not what this is about, the version is.
    const second = await call(ADMIN, 'PUT', `/edge/app/transformers/${id}`, {
      code: 'SECOND-EDITOR-CODE', expected_version: 1,
    });
    assert.equal(second.status, 409, `expected a conflict, got ${JSON.stringify(second.body)}`);
    assert.equal(
      (await storedTransformer(id)).code, 'FIRST-EDITOR-CODE',
      'the second save overwrote the first with no conflict',
    );
  });

  test('a save that states no expectation is refused, not silently unguarded', async (t) => {
    if (guard(t)) return;
    // The half that made the conflict above skippable. Verified before closing
    // it: both clients of this endpoint already send `expected_version`, so this
    // costs no client change.
    const id = await createTransformer();

    const res = await call(ADMIN, 'PUT', `/edge/app/transformers/${id}`, { code: 'UNGUARDED' });
    assert.equal(res.status, 400, `expected a refusal, got ${JSON.stringify(res.body)}`);
    assert.equal(
      (await storedTransformer(id)).code, LIVE_CODE,
      'an unguarded save landed anyway',
    );
  });

  test('an ordinary versioned save still lands and still snapshots', async (t) => {
    if (guard(t)) return;
    // The control for the whole group. A rule set that refused every update
    // would satisfy every case above and remove the feature.
    const id = await createTransformer();
    const res = await call(ADMIN, 'PUT', `/edge/app/transformers/${id}`, {
      name: 'renamed', code: 'NEXT-CODE', expected_version: 1, change_note: 'ordinary edit',
    });
    assert.equal(res.status, 200, `a legitimate save was refused: ${JSON.stringify(res.body)}`);

    const stored = await storedTransformer(id);
    assert.equal(stored.code, 'NEXT-CODE');
    assert.equal(stored.name, 'renamed');
    assert.equal(stored.version, 2);
    assert.equal(stored.code_size, Buffer.byteLength('NEXT-CODE', 'utf8'));
    assert.deepEqual((await versionRows(id)).map((r) => r.version), [1, 2]);
  });
});

describe('"referenced" means every table that references it', () => {
  test('a hard delete is refused while a connector still binds the transformer', async (t) => {
    if (guard(t)) return;
    // The guard knew ONE referrer — hierarchy_nodes.transformer_id. Connectors
    // reference a transformer too, through `response_config.transformer_id`, and
    // `?hard=true` deleted it out from under them: each such connector's declared
    // output keys degrade to null and its badge layer silently reverts to "no
    // declared outputs". Asserted on the row count, because a delete that misses
    // a referrer answers 200 exactly as a legitimate delete does.
    const id = await createTransformer();
    await query(
      `INSERT INTO \`${tbl(TABLES.API_CONNECTORS)}\`
         (id, name, url, auth_type, response_config)
       VALUES ('dddddddd-dddd-4ddd-8ddd-dddddddddddd', 'binder',
               'https://upstream.test/x', 'none', ?)`,
      [JSON.stringify({ transformer_id: id, outputs: [] })],
    );

    const res = await call(ADMIN, 'DELETE', `/edge/app/transformers/${id}?hard=true`);

    const rows = await query(
      `SELECT id FROM \`${tbl(TABLES.TRANSFORMERS)}\` WHERE id = ?`, [id],
    );
    assert.equal(
      rows.length, 1,
      `the transformer was deleted out from under a connector bound to it (DELETE ${res.status})`,
    );
    assert.equal(res.status, 409, `expected a refusal, got ${JSON.stringify(res.body)}`);
  });

  test('a hard delete still works when nothing references it', async (t) => {
    if (guard(t)) return;
    // The control: the reference set got wider, not universal.
    const id = await createTransformer();
    const res = await call(ADMIN, 'DELETE', `/edge/app/transformers/${id}?hard=true`);
    assert.equal(res.status, 200, `a legitimate delete was refused: ${JSON.stringify(res.body)}`);
    const rows = await query(
      `SELECT id FROM \`${tbl(TABLES.TRANSFORMERS)}\` WHERE id = ?`, [id],
    );
    assert.equal(rows.length, 0, 'the delete did not land');
  });

  test('the blueprint referrer the guard already knew is still refused', async (t) => {
    if (guard(t)) return;
    // Widening a reference set must not narrow it: the referrer the guard
    // already had is asserted beside the one it gained.
    const id = await createTransformer();
    await query(
      `INSERT INTO \`${tbl(TABLES.HIERARCHY_NODES)}\` (id, name, node_type, transformer_id)
       VALUES ('eeeeeeee-eeee-4eee-8eee-eeeeeeeeeeee', 'bp-binder', 'blueprint', ?)`,
      [id],
    );
    const res = await call(ADMIN, 'DELETE', `/edge/app/transformers/${id}?hard=true`);
    assert.equal(res.status, 409, `expected a refusal, got ${JSON.stringify(res.body)}`);
    const rows = await query(
      `SELECT id FROM \`${tbl(TABLES.TRANSFORMERS)}\` WHERE id = ?`, [id],
    );
    assert.equal(rows.length, 1, 'a refused delete removed the transformer anyway');
  });
});
