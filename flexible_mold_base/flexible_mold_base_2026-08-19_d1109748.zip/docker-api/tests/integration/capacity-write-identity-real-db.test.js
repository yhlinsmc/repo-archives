'use strict';

/**
 * capacity-write-identity-real-db.test.js — what the capacity mounts actually
 * store, read back from the column.
 *
 * WHY A REAL DATABASE. Every claim in this file is a claim about the bytes a
 * column holds after a statement ran, or about how many rows a statement left
 * behind. A mocked driver answers both with whatever the fixture was told to
 * say — which is how this family survived seven rounds — and three of the
 * defects here are the DATABASE's own answer rather than the code's: an ENUM
 * assignment folds case and reads an integer as a 1-based member index, an
 * omitted NOT NULL ENUM with no DEFAULT takes the first declared member, and a
 * `CHAR(36)` comparison resolves a row for any spelling of its id. None of the
 * three is visible to a stub.
 *
 * WHAT EVERY CASE ASSERTS. A stored value or a row count, never only a status
 * code, and the discriminating assertion is written so it is the one that
 * reports. Where a defect genuinely has no data consequence the case says so at
 * the site rather than dressing a status assertion up as one.
 *
 * Skips with a stated reason when no database is reachable, and fails instead
 * of skipping when REQUIRE_INTEGRATION_DB=1.
 */
const {
  test, describe, before, after, beforeEach,
} = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const net = require('node:net');
const http = require('node:http');
const express = require('express');
const mariadb = require('mariadb');

const TEST_PREFIX = 'cwi_';
const tbl = (name) => `${TEST_PREFIX}${name}`;

let pool = null;
const lease = () => pool.getConnection();
// The capacity guards use BOTH halves of the real pool object — `pool.rw.query`
// for the pre-middleware probes and `pool.rw.getConnection` for the write
// transactions — so the stand-in has to offer both or a guard becomes a 500 that
// looks like a refusal.
const handle = () => ({ getConnection: lease, query: (sql, params) => pool.query(sql, params) });

const dbKey = require.resolve('../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey,
  filename: dbKey,
  loaded: true,
  exports: {
    pool: { ro: handle(), rw: handle() },
    t: tbl,
    getDynamicPool: async () => ({ ro: handle(), rw: handle() }),
  },
};

const { buildEngineTableDDLs, buildInfraTableDDLs } = require('../../src/table-ddls');
const capacityRouter = require('../../src/edge/routes/app/capacity');
const { MAX_DC_REFS_ENTRIES } = require('../../src/edge/routes/app/capacity/_shared');

// ── Config auto-detection (same shape as the sibling integration tests) ──────

function parseEnvFile(filePath) {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    const out = {};
    for (const line of content.split('\n')) {
      const m = line.match(/^\s*([A-Z_][A-Z0-9_]*)\s*=\s*(.*)\s*$/);
      if (!m) continue;
      let value = m[2];
      if ((value.startsWith('"') && value.endsWith('"'))
        || (value.startsWith("'") && value.endsWith("'"))) {
        value = value.slice(1, -1);
      }
      out[m[1]] = value;
    }
    return out;
  } catch {
    return null;
  }
}

function probePort(host, port, timeoutMs = 2000) {
  return new Promise((resolve) => {
    const socket = new net.Socket();
    let done = false;
    const finish = (ok) => {
      if (done) return;
      done = true;
      socket.destroy();
      resolve(ok);
    };
    socket.setTimeout(timeoutMs);
    socket.once('connect', () => finish(true));
    socket.once('timeout', () => finish(false));
    socket.once('error', () => finish(false));
    socket.connect(port, host);
  });
}

async function resolveMariaDbConfig() {
  if (process.env.DB_TEST_HOST && process.env.DB_TEST_ROOT_PASSWORD) {
    return {
      host: process.env.DB_TEST_HOST,
      port: parseInt(process.env.DB_TEST_PORT || '3306', 10),
      user: 'root',
      password: process.env.DB_TEST_ROOT_PASSWORD,
    };
  }
  const envPath = path.resolve(__dirname, '../../../.devcontainer/.env');
  const env = parseEnvFile(envPath);
  if (!env || !env.DB_ROOT_PASSWORD) return null;
  const port = parseInt(env.DB_PORT || '3306', 10);
  for (const host of ['127.0.0.1', 'mariadb', 'localhost']) {
    if (await probePort(host, port, 2000)) {
      return { host, port, user: 'root', password: env.DB_ROOT_PASSWORD };
    }
  }
  return null;
}

// ── Fixture ─────────────────────────────────────────────────────────────────

// Hex LETTERS throughout, and that is load-bearing rather than cosmetic: an
// all-digit uuid has exactly one spelling, so a fixture built from one would
// pass every case below without any of the fixes.
const ADMIN_ID = 'cdefab03-4567-89ab-cdef-ab0123456789';
const EDITOR_ID = 'abcdef01-2345-6789-abcd-ef0123456789';
const ADMIN = { id: ADMIN_ID, role: 'admin' };
const EDITOR = { id: EDITOR_ID, role: 'editor' };

const SCENARIO_ID = 'abcabc11-2222-4333-8444-555566667777';
const SCENARIO_ALIAS = SCENARIO_ID.toUpperCase();

let dbReady = false;
let skipReason = null;
let testDbName = null;
let server = null;
let baseUrl = null;
let currentUser = ADMIN;

before(async () => {
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) {
    skipReason = 'no MariaDB reachable via .devcontainer/.env or env vars';
    if (process.env.REQUIRE_INTEGRATION_DB === '1') {
      throw new Error(`REQUIRE_INTEGRATION_DB=1 set but ${skipReason}.`);
    }
    return;
  }
  testDbName = `cap_write_identity_test_${process.pid}_${Date.now()}`;
  let admin = null;
  try {
    admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`CREATE DATABASE \`${testDbName}\``);
    await admin.query(`USE \`${testDbName}\``);
    // Every table, built from the DDL that creates the real ones. A hand-picked
    // subset drops a table some guard probes and turns its refusal into a
    // degrade nobody asked for.
    for (const sql of [...buildInfraTableDDLs(tbl), ...buildEngineTableDDLs(tbl)]) {
      await admin.query(sql);
    }
    await admin.end();
    admin = null;

    pool = mariadb.createPool({
      ...dbConfig, database: testDbName, connectionLimit: 6, connectTimeout: 5000,
    });

    const app = express();
    app.use(express.json());
    app.use((req, _res, next) => { req.user = currentUser; next(); });
    app.use('/edge/app/capacity', capacityRouter);
    server = http.createServer(app);
    await new Promise((r) => server.listen(0, r));
    baseUrl = `http://127.0.0.1:${server.address().port}`;
    dbReady = true;
  } catch (err) {
    skipReason = `setup failed: ${err.message}`;
    if (admin) { try { await admin.end(); } catch { /* best effort */ } }
    if (process.env.REQUIRE_INTEGRATION_DB === '1') throw err;
  }
});

after(async () => {
  if (server) { try { server.close(); } catch { /* best effort */ } }
  if (pool) { try { await pool.end(); } catch { /* best effort */ } }
  if (!testDbName) return;
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) return;
  try {
    const admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`DROP DATABASE IF EXISTS \`${testDbName}\``);
    await admin.end();
  } catch { /* best effort */ }
});

async function call(user, method, url, body) {
  currentUser = user;
  const res = await fetch(`${baseUrl}${url}`, {
    method,
    headers: { 'content-type': 'application/json' },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const text = await res.text();
  let parsed = null;
  try { parsed = JSON.parse(text); } catch { parsed = { raw: text }; }
  return { status: res.status, body: parsed };
}

const q = (sql, params) => pool.query(sql, params);
const one = async (sql, params) => (await pool.query(sql, params))[0];
const countOf = async (sql, params) => Number((await one(sql, params)).n);
const rowsIn = (table) => q(`SELECT * FROM \`${tbl(table)}\``);

const guard = (t) => {
  if (dbReady) return false;
  t.skip(skipReason || 'database not ready');
  return true;
};

/**
 * The stored bytes of one column, read back with no folding.
 *
 * `BINARY` is the point rather than a flourish: reading the column plainly and
 * comparing in JavaScript would work, but a future reader could not tell whether
 * the assertion is about the value or about the collation. Casting to binary
 * states that this asks the exact question the broken JavaScript readers ask.
 */
async function storedBytes(table, column, id) {
  const row = await one(
    `SELECT CAST(\`${column}\` AS BINARY) AS v FROM \`${tbl(table)}\` WHERE id = ?`,
    [id],
  );
  if (!row || row.v == null) return null;
  return Buffer.isBuffer(row.v) ? row.v.toString('utf8') : String(row.v);
}

const CAPACITY_TABLES = [
  'cap_waivers', 'cap_rules', 'cap_custom_group_members', 'cap_custom_groups',
  'cap_db_instances', 'cap_vms', 'cap_databases', 'cap_hypervisors', 'cap_sites',
  'cap_versions', 'cap_bundle_items', 'cap_bundles', 'cap_field_defs',
  'cap_vm_profiles', 'cap_disk_combos', 'cap_teams', 'cap_hardware_specs',
  'cap_settings', 'cap_scenarios',
];

beforeEach(async () => {
  if (!dbReady) return;
  for (const name of [...CAPACITY_TABLES, 'feature_audit', 'users']) {
    await q(`DELETE FROM \`${tbl(name)}\``);
  }
  await q(
    `INSERT INTO \`${tbl('users')}\` (id, email, role, banned) VALUES (?,?,?,0),(?,?,?,0)`,
    [ADMIN_ID, 'admin@test.local', 'admin', EDITOR_ID, 'editor@test.local', 'editor'],
  );
  await q(
    `INSERT INTO \`${tbl('cap_scenarios')}\` (id, name, owner_id) VALUES (?,?,?)`,
    [SCENARIO_ID, 'a scenario', null],
  );
});

// ── E1 / E23 — the scenario a child row is bound to ─────────────────────────

describe('E1 — a child row stores the scenario id, not the URL spelling', () => {
  test('the premise: the URL segment resolves the scenario under any spelling', async (t) => {
    if (guard(t)) return;
    // Measured rather than assumed, and measured on the exact predicate the
    // exists guard uses. This is what makes the whole family reachable: the
    // segment is admitted, so whatever it spells goes on to be written.
    assert.equal(
      await countOf(
        `SELECT COUNT(*) AS n FROM \`${tbl('cap_scenarios')}\` WHERE id = ?`, [SCENARIO_ALIAS],
      ),
      1,
      'this column no longer resolves the scenario under another spelling; the cases below rest on it',
    );
  });

  test('a create through a respelled URL stores the scenario\'s own id', async (t) => {
    if (guard(t)) return;
    const created = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ALIAS}/sites`,
      { name: 'dc1' });
    assert.equal(created.status, 200, `the create was refused: ${JSON.stringify(created.body)}`);

    const sites = await rowsIn('cap_sites');
    assert.equal(sites.length, 1);
    // The stored bytes are the assertion. A row carrying the caller's spelling
    // is found by every `WHERE scenario_id = ?` — so it looks healthy — while
    // the PUT binding, the reference-integrity check and the clone id-map all
    // resolve it in JavaScript and do not.
    assert.equal(
      await storedBytes('cap_sites', 'scenario_id', sites[0].id), SCENARIO_ID,
      'the child row was stamped with the URL spelling rather than the scenario id',
    );
  });

  test('and that row is editable through the canonical URL', async (t) => {
    if (guard(t)) return;
    // The consequence, asserted on the stored row rather than on the refusal:
    // the PUT binding compares the row\'s scenario_id against the URL in
    // JavaScript, so a row stamped with the other spelling is 404 forever from
    // the URL the application itself builds.
    const created = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ALIAS}/sites`,
      { name: 'dc1' });
    const siteId = created.body.data.id;

    await call(ADMIN, 'PUT', `/edge/app/capacity/scenarios/${SCENARIO_ID}/sites/${siteId}`,
      { name: 'renamed' });

    assert.equal(
      (await one(`SELECT name FROM \`${tbl('cap_sites')}\` WHERE id = ?`, [siteId])).name,
      'renamed',
      'a row created through one spelling of its scenario cannot be edited through the other',
    );
  });

  test('and a sibling may reference it', async (t) => {
    if (guard(t)) return;
    // E23\'s half of the same defect, at the point it first bites: the write
    // validator asks whether the referenced row belongs to THIS scenario, and
    // it asks in JavaScript. A hypervisor could not be placed on a site whose
    // scenario_id held the other spelling.
    const spec = await call(ADMIN, 'POST', '/edge/app/capacity/config/hardware_specs',
      { name: 'spec', cpu_total: 64, mem_total_gb: 512, disk_total_gb: 4096 });
    assert.equal(spec.status, 201, `the spec create was refused: ${JSON.stringify(spec.body)}`);
    const site = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ALIAS}/sites`,
      { name: 'dc1' });

    await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/hypervisors`, {
      name: 'hv1', site_id: site.body.data.id, spec_id: spec.body.data.id,
    });

    assert.equal(
      (await rowsIn('cap_hypervisors')).length, 1,
      'a hypervisor could not be placed on a site created through the other spelling',
    );
  });

  test('a URL that names no scenario is still refused, and stores nothing', async (t) => {
    if (guard(t)) return;
    // The other half of the guard. Resolving the segment to a stored id must
    // not become a way of accepting one that resolves to nothing.
    const created = await call(ADMIN, 'POST',
      '/edge/app/capacity/scenarios/99999999-9999-4999-8999-999999999999/sites', { name: 'dc1' });
    assert.equal(created.status, 404, `expected a not-found, got ${JSON.stringify(created.body)}`);
    assert.deepEqual(await rowsIn('cap_sites'), [], 'a refused create left a row behind');
  });
});

// ── E3–E6 / X3 / X19 — the rules mount ──────────────────────────────────────

const scenarioRules = () => q(
  `SELECT id, type, level, group_by, severity, enabled, overrides_rule_id
     FROM \`${tbl('cap_rules')}\` WHERE scenario_id IS NOT NULL`,
);

/** A global template rule whose type legally takes exactly one level. */
async function seedGlobalRule(overrides = {}) {
  const res = await call(ADMIN, 'POST', '/edge/app/capacity/config/rules', {
    type: 'max-vms-per-host',
    name: 'at most eight per host',
    level: 'hypervisor',
    params: { max: 8 },
    severity: 'hard',
    enabled: true,
    ...overrides,
  });
  assert.equal(res.status, 201, `the global rule fixture was refused: ${JSON.stringify(res.body)}`);
  return res.body.data;
}

/** A plain scenario-local rule the PUT cases edit. */
async function seedScenarioRule() {
  const res = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/rules`, {
    type: 'max-vms-per-host', name: 'local rule', level: 'hypervisor', params: { max: 4 },
  });
  assert.equal(res.status, 200, `the scenario rule fixture was refused: ${JSON.stringify(res.body)}`);
  return res.body.data;
}

describe('E3/E6 — a rule write nobody judged', () => {
  test('the premise: this column reads an empty string as no member at all', async (t) => {
    if (guard(t)) return;
    // Measured rather than assumed. Under the deployed strict mode the column
    // refuses it outright — which is why the guard gap surfaced as a 500 with a
    // driver stack rather than as the stable 400 every other unstorable
    // spelling gets. The point of the fix is the ANSWER, not the outcome.
    await assert.rejects(
      () => q(
        `INSERT INTO \`${tbl('cap_rules')}\` (id, scenario_id, type, name, level)
         VALUES (UUID(), ?, '', 'raw', 'hypervisor')`,
        [SCENARIO_ID],
      ),
      'this database now stores an empty string in that ENUM; the refusals below assume it cannot',
    );
  });

  test('an empty type on a PUT is refused, and the stored row does not move', async (t) => {
    if (guard(t)) return;
    // E3. Two guards, one write, and neither judged it: `if (body.type)` read
    // '' as "no type supplied, nothing to check", while the merge guard read
    // the key's PRESENCE as "the type was resent, no merge needed". The level
    // edit rode along unchecked.
    const rule = await seedScenarioRule();

    await call(ADMIN, 'PUT', `/edge/app/capacity/scenarios/${SCENARIO_ID}/rules/${rule.id}`,
      { type: '', level: 'vm' });

    const [stored] = await scenarioRules();
    assert.equal(stored.type, 'max-vms-per-host', 'the stored type moved');
    assert.equal(stored.level, 'hypervisor', 'an unjudged level edit persisted');
  });

  test('an explicit null level is refused with a stable 400, and nothing moves', async (t) => {
    if (guard(t)) return;
    // E6. `body.level != null` treated an explicit null as "not choosing", so
    // the per-type check was skipped and NULL reached a NOT NULL column.
    const rule = await seedScenarioRule();

    const res = await call(ADMIN, 'PUT', `/edge/app/capacity/scenarios/${SCENARIO_ID}/rules/${rule.id}`,
      { level: null });

    assert.equal(res.status, 400, `expected a stable 400, got ${JSON.stringify(res.body)}`);
    assert.equal((await scenarioRules())[0].level, 'hypervisor', 'the stored level moved');
  });

  test('a level the type does not take is still refused', async (t) => {
    if (guard(t)) return;
    // The check that already worked, kept beside the two above: closing a way
    // round a guard must not be a way of turning the guard off.
    const rule = await seedScenarioRule();

    await call(ADMIN, 'PUT', `/edge/app/capacity/scenarios/${SCENARIO_ID}/rules/${rule.id}`,
      { type: 'max-vms-per-host', level: 'db_instance' });

    assert.equal((await scenarioRules())[0].level, 'hypervisor', 'an illegal level persisted');
  });

  test('a legitimate rule edit still lands', async (t) => {
    if (guard(t)) return;
    // The other half. A fix that refused every rule write would satisfy every
    // case above while removing the feature.
    const rule = await seedScenarioRule();

    const res = await call(ADMIN, 'PUT', `/edge/app/capacity/scenarios/${SCENARIO_ID}/rules/${rule.id}`,
      { type: 'max-instances-per-vm', level: 'vm' });

    assert.equal(res.status, 200, `a legitimate edit was refused: ${JSON.stringify(res.body)}`);
    const [stored] = await scenarioRules();
    assert.equal(stored.type, 'max-instances-per-vm');
    assert.equal(stored.level, 'vm');
  });
});

describe('E4/X19 — the override fill runs before the validator, not after', () => {
  test('a self-contradicting override is refused, and no row lands', async (t) => {
    if (guard(t)) return;
    // THE ONE THAT LANDS A ROW WITH NO DB ERROR. The body carries no `type`, so
    // the per-type legality check was skipped entirely; the fill then supplied
    // the type from the referenced global rule AFTER the validator had run, and
    // both values are legal ENUM members — so the database accepted a rule
    // whose type takes only `hypervisor` while its level says `db_instance`.
    // The evaluator then never matches it and it silently stops firing, while
    // any later PUT that resends the type is 400'd: the API refuses to
    // reproduce a state it just created.
    const globalRule = await seedGlobalRule();

    const res = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/rules`, {
      overrides_rule_id: globalRule.id, level: 'db_instance', enabled: false,
    });

    assert.deepEqual(
      await scenarioRules(), [],
      `a self-contradicting override row landed (POST ${res.status})`,
    );
  });

  test('an override that omits the identity columns still lands and is coherent', async (t) => {
    if (guard(t)) return;
    // The feature the fill exists for, asserted on the stored row: the
    // documented override payload is the target plus `enabled`, and the NOT
    // NULL identity columns are filled from the target. Running the fill first
    // must not stop that from working.
    const globalRule = await seedGlobalRule();

    const res = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/rules`, {
      overrides_rule_id: globalRule.id, enabled: false,
    });
    assert.equal(res.status, 200, `a documented override was refused: ${JSON.stringify(res.body)}`);

    const [stored] = await scenarioRules();
    assert.equal(stored.type, 'max-vms-per-host', 'the type was not filled from the target');
    assert.equal(stored.level, 'hypervisor', 'the level was not filled from the target');
    assert.equal(String(stored.overrides_rule_id), globalRule.id);
  });
});

describe('E5 — the ENUM columns the rules mount never guarded', () => {
  for (const [column, value, label] of [
    ['severity', 'bogus', 'a value the column cannot store'],
    ['severity', 'Soft', 'a spelling the column folds'],
    ['type', 'No-Oversell', 'a folded type'],
    ['level', 1, 'the member index of the first level'],
  ]) {
    test(`${column} = ${JSON.stringify(value)} (${label}) is refused, and no row lands`, async (t) => {
      if (guard(t)) return;
      // Every one of these reaches the column as a value the mount never
      // judged: a folded spelling is silently normalised, an integer is read as
      // a 1-based member index, and an unstorable string is a driver error that
      // escapes as a 500. The mount had no declared domain for any of the four
      // ENUMs on this table — it is the one mount the factory's enum gate never
      // covered.
      const res = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/rules`, {
        type: 'max-vms-per-host', name: 'r', level: 'hypervisor', [column]: value,
      });

      assert.deepEqual(
        await scenarioRules(), [],
        `a rule carrying ${column} = ${JSON.stringify(value)} landed (POST ${res.status})`,
      );
      // AND the answer, because for three of these four the row count alone
      // does not discriminate: the COLUMN refuses them, so no row landed before
      // the fix either — as a driver error escaping to the client as a 500 with
      // a stack logged per request. The claim being made here is that the mount
      // judges them, and that is visible only in the answer. (The code varies by
      // which guard speaks first: the per-type rule validator or the column's
      // own declared domain. Both are stable 400s; neither is the driver.)
      assert.equal(
        res.status, 400,
        `expected the mount to refuse ${column} = ${JSON.stringify(value)} with a stable 400, `
        + `got ${JSON.stringify(res.body)}`,
      );
    });
  }

  test('a canonical severity still lands', async (t) => {
    if (guard(t)) return;
    const res = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/rules`, {
      type: 'max-vms-per-host', name: 'r', level: 'hypervisor', severity: 'soft',
    });
    assert.equal(res.status, 200, `a legitimate create was refused: ${JSON.stringify(res.body)}`);
    assert.equal((await scenarioRules())[0].severity, 'soft');
  });

  test('a nullable enumerated column still accepts null', async (t) => {
    if (guard(t)) return;
    // `group_by` is nullable in the DDL, so a declared domain must not start
    // refusing the null that means "no grouping".
    const res = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/rules`, {
      type: 'max-vms-per-host', name: 'r', level: 'hypervisor', group_by: null,
    });
    assert.equal(res.status, 200, `a null group_by was refused: ${JSON.stringify(res.body)}`);
    assert.equal((await scenarioRules())[0].group_by, null);
  });
});

// ── E7–E12 — field_defs judged on the value the column will hold ────────────

const fieldDefs = () => q(
  `SELECT id, entity_type, field_key, data_type, options FROM \`${tbl('cap_field_defs')}\``,
);

const postFieldDef = (body) => call(ADMIN, 'POST', '/edge/app/capacity/config/field_defs', body);
const putFieldDef = (id, body) => call(ADMIN, 'PUT', `/edge/app/capacity/config/field_defs/${id}`, body);

async function seedFieldDef(body) {
  const res = await postFieldDef({ entity_type: 'vm', field_key: 'cost', data_type: 'text', ...body });
  assert.equal(res.status, 201, `the field-def fixture was refused: ${JSON.stringify(res.body)}`);
  return res.body.data;
}

describe('E7–E9 — a guard keyed on an ENUM value, on the create path', () => {
  test('the premise: this column folds these spellings to the value the guard forbids', async (t) => {
    if (guard(t)) return;
    // Measured with no router in the way, so the fold is shown to be the
    // DATABASE's. Each of these IS the forbidden value to the only party whose
    // opinion the stored row reflects — including the integer, which MariaDB
    // reads as a 1-BASED MEMBER INDEX, and 'scenario' is the first member
    // declared.
    for (const [label, sent, folded] of [
      ["'Scenario'", 'Scenario', 'scenario'],
      ["'SCENARIO'", 'SCENARIO', 'scenario'],
      ['1 (the member index)', 1, 'scenario'],
      ["'Vm'", 'Vm', 'vm'],
    ]) {
      await q(`DELETE FROM \`${tbl('cap_field_defs')}\``);
      await q(
        `INSERT INTO \`${tbl('cap_field_defs')}\` (id, entity_type, field_key, data_type)
         VALUES (UUID(), ?, 'raw', 'text')`,
        [sent],
      );
      assert.equal(
        (await fieldDefs())[0].entity_type, folded,
        `this database no longer folds ${label} to '${folded}'`,
      );
    }
  });

  test('E7: a custom field cannot target the entity with nowhere to store it', async (t) => {
    if (guard(t)) return;
    // The guard exists because cap_scenarios has no `metadata` column, so a
    // 'scenario' field def has nowhere to write its value. It compared
    // `body.entity_type === 'scenario'` — one literal, in JavaScript — while
    // the column folds every spelling below to exactly that.
    for (const value of ['Scenario', 'SCENARIO', 1, '1']) {
      await q(`DELETE FROM \`${tbl('cap_field_defs')}\``);
      const res = await postFieldDef({ entity_type: value, field_key: 'x', data_type: 'text' });
      assert.deepEqual(
        await fieldDefs(), [],
        `a field def targeting the scenario entity landed via ${JSON.stringify(value)} (POST ${res.status})`,
      );
    }
  });

  test('E8: a key that collides with a native column is still a collision', async (t) => {
    if (guard(t)) return;
    // `ENTITY_NATIVE_FIELD_KEYS['Vm']` is `undefined`, so the whole collision
    // check was SKIPPED — not failed, skipped. The row lands as entity 'vm'
    // with a field_key that already names a native vm column, which is the
    // "two grid columns with the identical key, whichever is second silently
    // wins the read AND the write" outcome the check exists to refuse.
    const res = await postFieldDef({ entity_type: 'Vm', field_key: 'name', data_type: 'text' });

    assert.deepEqual(
      await fieldDefs(), [],
      `a colliding custom field landed under a folded entity_type (POST ${res.status})`,
    );
  });

  test('E8b: a vm field_key of "sga_ref" is a collision too (fmb-1582 gap 1)', async (t) => {
    if (guard(t)) return;
    // `sga_ref` names no `cap_vms` column — it is the KVMs grid's synthetic,
    // client-rendered SGA reference column (capacity-sga-ref.ts) — so it was
    // absent from ENTITY_NATIVE_FIELD_KEYS.vm and this create landed. A
    // custom field under that key would then render as a second grid column
    // sharing the derived cell's own key.
    const res = await postFieldDef({ entity_type: 'vm', field_key: 'sga_ref', data_type: 'text' });

    assert.deepEqual(
      await fieldDefs(), [],
      `a "sga_ref" custom field landed for entity_type vm (POST ${res.status})`,
    );
  });

  test('E9: the reserved option sentinel is still reserved under a folded data_type', async (t) => {
    if (guard(t)) return;
    // `body.data_type === 'enum'` is false for 'ENUM', so the reserved-sentinel
    // check was skipped and the stored enum field owns an option whose value IS
    // the front end's "no value chosen" token — a real choice and the absence
    // of one become the same token in the grid.
    const res = await postFieldDef({
      entity_type: 'vm', field_key: 'tier', data_type: 'ENUM',
      options: [{ label: 'unset', value: '__unset__' }],
    });

    assert.deepEqual(
      await fieldDefs(), [],
      `an enum field owning the null sentinel landed (POST ${res.status})`,
    );
  });

  test('a legitimate custom field still lands, with the value the column holds', async (t) => {
    if (guard(t)) return;
    // The other half. A gate that refused every field def would satisfy every
    // case above while removing the feature.
    const res = await postFieldDef({
      entity_type: 'vm', field_key: 'cost_centre', data_type: 'enum',
      options: [{ label: 'A', value: 'a' }],
    });
    assert.equal(res.status, 201, `a legitimate create was refused: ${JSON.stringify(res.body)}`);

    const [stored] = await fieldDefs();
    assert.equal(stored.entity_type, 'vm');
    assert.equal(stored.data_type, 'enum');
    assert.equal(stored.field_key, 'cost_centre');
  });
});

describe('E10/E11 — the same guards on the partial-update path', () => {
  test('E10: a folded entity_type on a PUT does not move the row past the collision check', async (t) => {
    if (guard(t)) return;
    // The merge guard reads the body's spelling for the half the body supplied,
    // so the same identity lookup misses and the collision check is skipped —
    // the partial-update gap this function was ADDED to close, reopened for any
    // non-canonical spelling.
    // `cpu` is a native VM column and not a native site column, so the def is
    // legitimate where it starts and collides only where the PUT moves it.
    const def = await seedFieldDef({ entity_type: 'site', field_key: 'cpu' });

    await putFieldDef(def.id, { entity_type: 'Vm' });

    assert.equal(
      (await fieldDefs())[0].entity_type, 'site',
      'a folded entity_type moved a def onto an entity whose native column it collides with',
    );
  });

  test('E11: a folded data_type on a PUT does not skip the sentinel check', async (t) => {
    if (guard(t)) return;
    const def = await seedFieldDef({
      entity_type: 'vm', field_key: 'tier', data_type: 'text',
      options: [{ label: 'unset', value: '__unset__' }],
    });

    await putFieldDef(def.id, { data_type: 'ENUM' });

    assert.equal(
      (await fieldDefs())[0].data_type, 'text',
      'a folded data_type turned a def into an enum owning the null sentinel',
    );
  });

  test('a legitimate partial update still lands', async (t) => {
    if (guard(t)) return;
    const def = await seedFieldDef({ entity_type: 'vm', field_key: 'cost' });

    const res = await putFieldDef(def.id, { entity_type: 'database' });

    assert.equal(res.status, 200, `a legitimate update was refused: ${JSON.stringify(res.body)}`);
    assert.equal((await fieldDefs())[0].entity_type, 'database');
  });
});

describe('E12 — the uniqueness guard cannot opt out of a value it cannot read', () => {
  test('a numeric entity_type does not create a second owner of one metadata key', async (t) => {
    if (guard(t)) return;
    // The uniqueness probe returned early for a non-string ("not my concern"),
    // and the UNIQUE index cannot help for global rows because MariaDB treats
    // each NULL scenario_id as distinct. So the app layer was the ONLY enforcer
    // and it declined to run — while the column folded `1` to the first member
    // and inserted. Two definitions owning the identical metadata JSON key:
    // whichever save lands second silently wins and the other's data becomes
    // unreachable.
    await seedFieldDef({ entity_type: 'site', field_key: 'cost' });
    assert.equal((await fieldDefs()).length, 1);

    const res = await postFieldDef({ entity_type: 2, field_key: 'cost', data_type: 'text' });

    assert.equal(
      (await fieldDefs()).length, 1,
      `a second definition of the same key landed under a numeric entity_type (POST ${res.status})`,
    );
  });

  test('and a genuine duplicate is still refused', async (t) => {
    if (guard(t)) return;
    // The check the numeric value walked past, still working for the value it
    // was written for.
    await seedFieldDef({ entity_type: 'site', field_key: 'cost' });

    await postFieldDef({ entity_type: 'site', field_key: 'cost', data_type: 'text' });

    assert.equal((await fieldDefs()).length, 1, 'a duplicate field key landed');
  });
});

// ── E21/E22 — a delete gate probes every reference that exists ──────────────

const siteCount = () => countOf(`SELECT COUNT(*) AS n FROM \`${tbl('cap_sites')}\``);
const comboCount = () => countOf(`SELECT COUNT(*) AS n FROM \`${tbl('cap_disk_combos')}\``);

async function seedSpecAndSite() {
  const spec = await call(ADMIN, 'POST', '/edge/app/capacity/config/hardware_specs',
    { name: 'spec', cpu_total: 64, mem_total_gb: 512, disk_total_gb: 4096 });
  assert.equal(spec.status, 201, `the spec fixture was refused: ${JSON.stringify(spec.body)}`);
  const site = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/sites`, { name: 'dc1' });
  assert.equal(site.status, 200, `the site fixture was refused: ${JSON.stringify(site.body)}`);
  return { specId: spec.body.data.id, siteId: site.body.data.id };
}

describe('E22 — deleting a site does not dangle the VMs pinned to it', () => {
  test('a VM pinned to the site survives the delete with a site that exists', async (t) => {
    if (guard(t)) return;
    // The write side has always insisted `cap_vms.site_id` reference a site in
    // THIS scenario; the delete side declared only the hypervisor reference. So
    // deleting a site the hypervisors had left, while VMs were still pinned to
    // it, left every one of those VMs pointing at nothing — and the scenario
    // health read then counted them as broken references, i.e. the product
    // reported the corruption it had just created.
    const { siteId } = await seedSpecAndSite();
    const vm = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/vms`,
      { name: 'kvm1', vm_type: 'db_host', site_id: siteId });
    assert.equal(vm.status, 200, `the VM fixture was refused: ${JSON.stringify(vm.body)}`);

    await call(ADMIN, 'DELETE', `/edge/app/capacity/scenarios/${SCENARIO_ID}/sites/${siteId}`);

    // The stored reference is the assertion: whatever the delete answered, no
    // VM may be left naming a site that is not there.
    const dangling = await countOf(
      `SELECT COUNT(*) AS n FROM \`${tbl('cap_vms')}\` v
        WHERE v.site_id IS NOT NULL
          AND NOT EXISTS (SELECT 1 FROM \`${tbl('cap_sites')}\` s WHERE s.id = v.site_id)`,
    );
    assert.equal(dangling, 0, 'a VM is pinned to a site that no longer exists');
  });

  test('a hypervisor on the site is cascaded with it (spec §4 reversal)', async (t) => {
    if (guard(t)) return;
    // The reversal (user-approved, spec §4): a hypervisor is an OWNED child, so
    // the site delete takes it along rather than refusing. A dc_refs restriction
    // is the only reference that still blocks (asserted in the sibling
    // capacity-site-delete-real-db.test.js).
    const { specId, siteId } = await seedSpecAndSite();
    const hv = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/hypervisors`,
      { name: 'hv1', site_id: siteId, spec_id: specId });

    const gone = await call(ADMIN, 'DELETE', `/edge/app/capacity/scenarios/${SCENARIO_ID}/sites/${siteId}`);
    assert.equal(gone.status, 200, JSON.stringify(gone.body));
    assert.equal(await siteCount(), 0, 'the site was not deleted');
    const hvLeft = await countOf(
      `SELECT COUNT(*) AS n FROM \`${tbl('cap_hypervisors')}\` WHERE id = ?`, [hv.body.data.id],
    );
    assert.equal(hvLeft, 0, 'the hypervisor was left dangling on a deleted site');
  });

  test('an unreferenced site still deletes', async (t) => {
    if (guard(t)) return;
    const { siteId } = await seedSpecAndSite();

    await call(ADMIN, 'DELETE', `/edge/app/capacity/scenarios/${SCENARIO_ID}/sites/${siteId}`);

    assert.equal(await siteCount(), 0, 'an unreferenced site could not be deleted');
  });
});

describe('E21 — a combo a profile permits is a reference', () => {
  async function seedComboAndProfile(allowList) {
    const combo = await call(ADMIN, 'POST', '/edge/app/capacity/config/disk_combos',
      { name: 'combo-a', sizes: [100, 200] });
    assert.equal(combo.status, 201, `the combo fixture was refused: ${JSON.stringify(combo.body)}`);
    const comboId = combo.body.data.id;
    const profile = await call(ADMIN, 'POST', '/edge/app/capacity/config/vm_profiles', {
      class: 'DB', name: 'profile-a', mode: 'formula', cpu: 8,
      allowed_disk_combos: allowList === 'the combo' ? [comboId] : [],
    });
    assert.equal(profile.status, 201, `the profile fixture was refused: ${JSON.stringify(profile.body)}`);
    return comboId;
  }

  test('a combo referenced only by an allow-list cannot be deleted', async (t) => {
    if (guard(t)) return;
    // Nothing breaks the moment it is deleted, which is why this was written
    // off as a soft reference — but the version/export closure pulls a combo
    // referenced ONLY from an allow-list so the document can be remapped, and
    // the importer raises UNRESOLVED_REF when it cannot find it. The scenario
    // becomes permanently un-re-importable, silently.
    const comboId = await seedComboAndProfile('the combo');

    await call(ADMIN, 'DELETE', `/edge/app/capacity/config/disk_combos/${comboId}`);

    assert.equal(await comboCount(), 1, 'a combo a profile permits was deleted');
  });

  test('a combo nothing permits still deletes', async (t) => {
    if (guard(t)) return;
    // The other half, and the one that matters most here: an allow-list is an
    // ordinary column on every profile, so a probe that answered "referenced"
    // too readily would make the whole catalogue undeletable.
    const comboId = await seedComboAndProfile('nothing');

    await call(ADMIN, 'DELETE', `/edge/app/capacity/config/disk_combos/${comboId}`);

    assert.equal(await comboCount(), 0, 'an unreferenced combo could not be deleted');
  });

  test('a respelled id cannot delete a combo an allow-list still permits', async (t) => {
    if (guard(t)) return;
    // fmb-1537. The delete guard's allow-list probe is a byte-exact JSON_CONTAINS,
    // but `WHERE id = ?` folds case: a respelled id resolved the row for the
    // DELETE while missing the reference, so the combo was deleted with a 200
    // while a profile still named it — leaving the export/version closure
    // permanently unable to resolve the id. The guard must bind the STORED id.
    const comboId = await seedComboAndProfile('the combo');
    const respelled = comboId.toUpperCase();
    assert.notEqual(respelled, comboId,
      'fixture id carried no case-bearing character — this probe cannot discriminate');

    const res = await call(ADMIN, 'DELETE', `/edge/app/capacity/config/disk_combos/${respelled}`);

    assert.equal(await comboCount(), 1, 'a respelled id deleted a combo a profile still permits');
    assert.equal(res.status, 409, 'the respelled delete was not refused');
  });
});

describe('fmb-1537 — the scenario-local catalogue delete guard binds the stored id too', () => {
  const localComboCount = () => countOf(
    `SELECT COUNT(*) AS n FROM \`${tbl('cap_disk_combos')}\` WHERE scenario_id = ?`, [SCENARIO_ID],
  );

  test('a respelled id cannot delete a scenario-local combo a profile still permits', async (t) => {
    if (guard(t)) return;
    // The _shared.js twin of the config-side site: the SAME shared guard and the
    // SAME byte-exact allow-list probe, reached through the local-catalogues
    // DELETE. Both verbs of the family are one fix; this pins the second site.
    const combo = await call(ADMIN, 'POST',
      `/edge/app/capacity/scenarios/${SCENARIO_ID}/local-catalogues/disk_combos`, { name: 'combo-local' });
    assert.ok(combo.status < 300 && combo.body.data && combo.body.data.id,
      `local combo fixture refused: ${JSON.stringify(combo.body)}`);
    const comboId = combo.body.data.id;
    // A global profile whose allow-list names the local combo. The guard's
    // jsonListRefs probe is deliberately not scenario-scoped, so any live
    // reference blocks the local delete.
    const profile = await call(ADMIN, 'POST', '/edge/app/capacity/config/vm_profiles', {
      class: 'DB', name: 'profile-ref-local', mode: 'formula', cpu: 8, allowed_disk_combos: [comboId],
    });
    assert.equal(profile.status, 201, `profile fixture refused: ${JSON.stringify(profile.body)}`);
    const respelled = comboId.toUpperCase();
    assert.notEqual(respelled, comboId,
      'fixture id carried no case-bearing character — this probe cannot discriminate');

    const res = await call(ADMIN, 'DELETE',
      `/edge/app/capacity/scenarios/${SCENARIO_ID}/local-catalogues/disk_combos/${respelled}`);

    assert.equal(await localComboCount(), 1,
      'a respelled id deleted a scenario-local combo a profile still permits');
    assert.equal(res.status, 409, 'the respelled local delete was not refused');
  });
});

// ── E26/E58 — a gate as wide as the write it authorises ─────────────────────

const { DEFAULT_RULE_TEMPLATE } = require('../../src/shared/capacity/rule-types');

/** The seeded global rule template, as rows in the real table. */
async function seedRuleTemplate() {
  for (const rule of DEFAULT_RULE_TEMPLATE) {
    await q(
      `INSERT INTO \`${tbl('cap_rules')}\` (id, scenario_id, type, name, level, group_by, params, severity, enabled)
       VALUES (UUID(), NULL, ?, ?, ?, ?, ?, ?, ?)`,
      [rule.type, rule.name, rule.level, rule.group_by, JSON.stringify(rule.params || {}),
        rule.severity, rule.enabled ? 1 : 0],
    );
  }
}

const emptyGate = async () => {
  const res = await call(ADMIN, 'POST', '/edge/app/capacity/config/import/validate', { tables: {} });
  assert.equal(res.status, 200, `the gate read failed: ${JSON.stringify(res.body)}`);
  return res.body.data.emptyGate;
};

describe('E26 — the untouched-template gate sees the edits an operator makes', () => {
  test('an untouched template still reads as empty', async (t) => {
    if (guard(t)) return;
    // The control, and the one that makes the case below mean something: a gate
    // that answered "not empty" for everything would satisfy it while removing
    // the feature the gate exists to offer.
    await seedRuleTemplate();
    assert.equal(await emptyGate(), true, 'the untouched seed no longer reads as an empty config');
  });

  test('a rule the operator switched off is operator work', async (t) => {
    if (guard(t)) return;
    // THE HOLE, AT ITS WIDEST POINT. The signature compared six columns and
    // omitted `enabled` — turning a default rule off is the likeliest edit an
    // operator makes, and it signed IDENTICAL to the seed. The gate then said
    // "untouched", and the write it authorises DELETEs every global rule and
    // re-mints it: the operator's switched-off rule comes back on, silently.
    await seedRuleTemplate();
    const [rule] = await q(`SELECT id FROM \`${tbl('cap_rules')}\` WHERE name = 'No oversell'`);
    const res = await call(ADMIN, 'PUT', `/edge/app/capacity/config/rules/${rule.id}`, { enabled: false });
    assert.equal(res.status, 200, `the fixture edit was refused: ${JSON.stringify(res.body)}`);
    // The stored edit is real — this is what the gate has to see.
    assert.equal(
      Number((await one(`SELECT enabled FROM \`${tbl('cap_rules')}\` WHERE id = ?`, [rule.id])).enabled),
      0,
    );

    // This arm's discriminator is the gate's own answer rather than a stored
    // row, and that is stated rather than dressed up: the destructive write it
    // authorises needs a whole valid workbook to reach, so what is asserted
    // here is the decision, and the stored consequence of getting it wrong is
    // the re-minted rule set described above.
    assert.equal(await emptyGate(), false, 'a switched-off default rule read as an untouched template');
  });

  test('a rule whose filters the operator narrowed is operator work too', async (t) => {
    if (guard(t)) return;
    // The second omitted column, and the same shape.
    await seedRuleTemplate();
    const [rule] = await q(`SELECT id FROM \`${tbl('cap_rules')}\` WHERE name = 'No oversell'`);
    await call(ADMIN, 'PUT', `/edge/app/capacity/config/rules/${rule.id}`,
      { filters: { conditions: [{ field: 'team', op: 'eq', value: 'erp' }] } });

    assert.equal(await emptyGate(), false, 'a narrowed filter read as an untouched template');
  });
});

// ── E51 — the wizard looks a profile up on the side the caller queries it with

describe('E51 — a profiled VM is sized from the profile, not from the client', () => {
  async function seedGlobalProfile() {
    const res = await call(ADMIN, 'POST', '/edge/app/capacity/config/vm_profiles',
      { class: 'DB', name: 'DB-16C', mode: 'formula', cpu: 16 });
    assert.equal(res.status, 201, `the profile fixture was refused: ${JSON.stringify(res.body)}`);
    return res.body.data.id;
  }

  const wizardPayload = (profileId) => ({
    name: 'wizard scenario',
    sites: [{ ref: 's1', name: 'DC-A' }],
    databases: [{ ref: 'd1', function_name: 'erp', topology: 'single' }],
    vms: [{
      ref: 'vm1', name: 'erp-db-1', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1',
      sizing_profile_id: profileId,
      // The client's own numbers, deliberately nothing like what the profile
      // derives. These are what a missed Map lookup falls through to.
      cpu: 1, mem_gb: 1,
    }],
    db_instances: [{ name: 'erp1', vm_ref: 'vm1', database_ref: 'd1', role: 'primary' }],
  });

  const storedVm = () => one(`SELECT cpu, mem_gb, sizing_profile_id FROM \`${tbl('cap_vms')}\``);

  test('the canonical spelling derives the sizing (the control)', async (t) => {
    if (guard(t)) return;
    // Establishes what "derived" looks like on this database, so the case below
    // is comparing against a measured number rather than an assumed one.
    const profileId = await seedGlobalProfile();

    const res = await call(ADMIN, 'POST', '/edge/app/capacity/scenarios/wizard', wizardPayload(profileId));
    assert.equal(res.status, 201, `the wizard create was refused: ${JSON.stringify(res.body)}`);

    const vm = await storedVm();
    assert.equal(Number(vm.cpu), 16, 'the profile did not drive cpu even for the canonical spelling');
    assert.ok(Number(vm.mem_gb) > 1, 'the profile did not drive mem_gb even for the canonical spelling');
  });

  test('and so does another spelling of the same profile id', async (t) => {
    if (guard(t)) return;
    // THE ROW. Every gate passes — the reference check resolves the profile in
    // SQL, and the profile-class check is keyed on the body's side so it
    // resolves too — and then the sizing Map, keyed on the DB's spelling,
    // MISSES. The derivation falls through to `row.cpu ?? 0` / `row.mem_gb ??
    // 0`, i.e. the client's numbers, and the stored row claims a profile while
    // carrying hand-chosen sizing.
    const profileId = await seedGlobalProfile();

    const res = await call(ADMIN, 'POST', '/edge/app/capacity/scenarios/wizard',
      wizardPayload(profileId.toUpperCase()));
    assert.equal(res.status, 201, `the wizard create was refused: ${JSON.stringify(res.body)}`);

    const vm = await storedVm();
    assert.equal(
      Number(vm.cpu), 16,
      'a VM claiming a profile was stored with the client\'s own cpu',
    );
    assert.ok(
      Number(vm.mem_gb) > 1,
      'a VM claiming a profile was stored with the client\'s own mem_gb',
    );
    // AND WHAT THE COLUMN NOW HOLDS. Deriving the sizing correctly is only half
    // of it: the INSERT bound `row.sizing_profile_id` — the client's spelling —
    // so the VM ended up claiming a profile through a value the front end's own
    // `.find(p => p.id === vm.sizing_profile_id)` resolves to nobody. The
    // reference check had already resolved the row; it just was not what got
    // stored.
    assert.equal(
      await storedBytes('cap_vms', 'sizing_profile_id', (await one(`SELECT id FROM \`${tbl('cap_vms')}\``)).id),
      profileId,
      'the VM stored the spelling the caller sent rather than the profile\'s own id',
    );
  });

  test('and every other catalogue reference the wizard writes', async (t) => {
    if (guard(t)) return;
    // The same shape on the columns nobody looked at: a hypervisor's spec, and a
    // database's profile / disk combo / team. All five reach the INSERT the same
    // way, so fixing only the one the sizing hydration reads would leave four.
    const profileId = await seedGlobalProfile();
    const spec = await call(ADMIN, 'POST', '/edge/app/capacity/config/hardware_specs',
      { name: 'spec-a', cpu_total: 64, mem_total_gb: 512, disk_total_gb: 4096 });
    assert.equal(spec.status, 201, `the spec fixture was refused: ${JSON.stringify(spec.body)}`);
    const team = await call(ADMIN, 'POST', '/edge/app/capacity/config/teams', { name: 'team-a' });
    assert.equal(team.status, 201, `the team fixture was refused: ${JSON.stringify(team.body)}`);
    const specId = spec.body.data.id;
    const teamId = team.body.data.id;

    const payload = wizardPayload(profileId);
    payload.hypervisors = [{ ref: 'h1', name: 'kvm-1', site_ref: 's1', spec_id: specId.toUpperCase() }];
    payload.databases = [{
      ref: 'd1', function_name: 'erp', topology: 'single',
      profile_id: profileId.toUpperCase(), team_id: teamId.toUpperCase(),
    }];
    const res = await call(ADMIN, 'POST', '/edge/app/capacity/scenarios/wizard', payload);
    assert.equal(res.status, 201, `the wizard create was refused: ${JSON.stringify(res.body)}`);

    const hv = await one(`SELECT id FROM \`${tbl('cap_hypervisors')}\``);
    const db = await one(`SELECT id FROM \`${tbl('cap_databases')}\``);
    assert.equal(await storedBytes('cap_hypervisors', 'spec_id', hv.id), specId,
      'a hypervisor stored the caller\'s spelling of its hardware spec');
    assert.equal(await storedBytes('cap_databases', 'profile_id', db.id), profileId,
      'a database stored the caller\'s spelling of its profile');
    assert.equal(await storedBytes('cap_databases', 'team_id', db.id), teamId,
      'a database stored the caller\'s spelling of its team');
  });
});

// ── E53 — a catalogue FK is an identifier before it is a reference ──────────

describe('E53 — a numeric catalogue FK is refused, not resolved', () => {
  test('the premise: this column really does answer a numeric comparison', async (t) => {
    if (guard(t)) return;
    // Measured with no route in the way. MariaDB compares a CHAR column against
    // a NUMBER in numeric context, converting the column side with
    // leading-digit semantics — so `WHERE id = 0` matches every id starting `0`
    // or `a`–`f`. This is what made "does the referenced row exist" answerable
    // by an arbitrary row.
    const spec = await call(ADMIN, 'POST', '/edge/app/capacity/config/hardware_specs',
      { name: 'spec', cpu_total: 64, mem_total_gb: 512, disk_total_gb: 4096 });
    assert.equal(spec.status, 201, `the spec fixture was refused: ${JSON.stringify(spec.body)}`);
    // Force an id whose first character makes the numeric conversion match.
    const numericish = 'abcdefab-1111-4111-8111-111111111111';
    await q(`UPDATE \`${tbl('cap_hardware_specs')}\` SET id = ? WHERE id = ?`,
      [numericish, spec.body.data.id]);

    const matched = await countOf(
      `SELECT COUNT(*) AS n FROM \`${tbl('cap_hardware_specs')}\` WHERE id = ?`, [0],
    );
    assert.equal(matched, 1, 'this database no longer resolves a CHAR id against the number 0');
  });

  test('a numeric spec_id stores nothing (regression guard)', async (t) => {
    if (guard(t)) return;
    // LABELLED A REGRESSION GUARD, NOT A PROBE, and measured as such: the
    // generic child factory already carries the identifier floor, so this arm
    // was refused before this change too. It is kept because the floor added
    // here sits BELOW that one, and a later mount that bypasses the factory
    // would land exactly here.
    const spec = await call(ADMIN, 'POST', '/edge/app/capacity/config/hardware_specs',
      { name: 'spec', cpu_total: 64, mem_total_gb: 512, disk_total_gb: 4096 });
    assert.equal(spec.status, 201);
    await q(`UPDATE \`${tbl('cap_hardware_specs')}\` SET id = ? WHERE id = ?`,
      ['abcdefab-1111-4111-8111-111111111111', spec.body.data.id]);
    const site = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/sites`, { name: 'dc1' });

    const res = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/hypervisors`,
      { name: 'hv1', site_id: site.body.data.id, spec_id: 0 });

    assert.deepEqual(
      await rowsIn('cap_hypervisors'), [],
      `a hypervisor referencing the number 0 landed (POST ${res.status})`,
    );
  });

  test('and so does a numeric profile id in the wizard', async (t) => {
    if (guard(t)) return;
    // The same hole on the path that does NOT go through the child factory.
    // THE FIXTURE DETAIL THAT MAKES THIS A PROBE. A catalogue that contains no
    // row the numeric comparison resolves would refuse `0` as an ordinary
    // missing reference, and the case would pass with the floor removed — which
    // is what it did before this profile was given an id beginning with a hex
    // LETTER. `'abcdefab-…'` converts to 0 under MariaDB's leading-digit
    // semantics, so `WHERE id = 0` really does resolve it and the reference
    // check really does answer "allowed".
    const profile = await call(ADMIN, 'POST', '/edge/app/capacity/config/vm_profiles',
      { class: 'DB', name: 'DB-16C', mode: 'formula', cpu: 16 });
    assert.equal(profile.status, 201, `the profile fixture was refused: ${JSON.stringify(profile.body)}`);
    await q(`UPDATE \`${tbl('cap_vm_profiles')}\` SET id = ? WHERE id = ?`,
      ['abcdefab-2222-4222-8222-222222222222', profile.body.data.id]);
    assert.equal(
      await countOf(`SELECT COUNT(*) AS n FROM \`${tbl('cap_vm_profiles')}\` WHERE id = ?`, [0]),
      1,
      'the fixture profile is not resolved by the numeric comparison, so this case would not probe anything',
    );

    const res = await call(ADMIN, 'POST', '/edge/app/capacity/scenarios/wizard', {
      name: 'wizard scenario',
      sites: [{ ref: 's1', name: 'DC-A' }],
      databases: [{ ref: 'd1', function_name: 'erp', topology: 'single' }],
      vms: [{
        ref: 'vm1', name: 'erp-db-1', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1',
        sizing_profile_id: 0,
      }],
      db_instances: [{ name: 'erp1', vm_ref: 'vm1', database_ref: 'd1', role: 'primary' }],
    });

    assert.deepEqual(
      await rowsIn('cap_vms'), [],
      `a wizard VM referencing the number 0 landed (POST ${res.status})`,
    );
  });

  test('a real catalogue reference still lands', async (t) => {
    if (guard(t)) return;
    // The other half: a floor that refused every reference would satisfy both
    // cases above and remove the catalogue.
    const spec = await call(ADMIN, 'POST', '/edge/app/capacity/config/hardware_specs',
      { name: 'spec', cpu_total: 64, mem_total_gb: 512, disk_total_gb: 4096 });
    const site = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/sites`, { name: 'dc1' });

    const res = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/hypervisors`,
      { name: 'hv1', site_id: site.body.data.id, spec_id: spec.body.data.id });

    assert.equal(res.status, 200, `a legitimate reference was refused: ${JSON.stringify(res.body)}`);
    assert.equal((await rowsIn('cap_hypervisors')).length, 1);
  });
});

// ── E19/E20/E37 — a create names the ENUM the engine would choose for it ────

describe('E19/E37 — an omitted NOT NULL ENUM is refused, not defaulted', () => {
  test('the premise: this database fills the absent column with the first member', async (t) => {
    if (guard(t)) return;
    // MEASURED, and the whole reason these rows are corruption rather than an
    // availability problem: an omitted NOT NULL VARCHAR errors under this
    // sql_mode, but an omitted NOT NULL ENUM does not — MariaDB substitutes the
    // FIRST DECLARED MEMBER with no error and no warning. 'scenario' is the
    // first member of cap_field_defs.entity_type, and it is the one value the
    // field-def guard exists to refuse.
    await q(
      `INSERT INTO \`${tbl('cap_field_defs')}\` (id, field_key, data_type)
       VALUES (UUID(), 'raw', 'text')`,
    );
    assert.equal(
      (await fieldDefs())[0].entity_type, 'scenario',
      'this database no longer substitutes the first ENUM member for an absent column',
    );
  });

  test('E37: a config create that omits the column stores nothing', async (t) => {
    if (guard(t)) return;
    // The forbidden row, created by not mentioning the column. There was no
    // required-field check on any config mount, so the omission walked past the
    // guard that refuses `entity_type: 'scenario'` outright.
    const res = await postFieldDef({ field_key: 'x', data_type: 'text' });

    assert.deepEqual(
      await fieldDefs(), [],
      `a field def landed with an entity_type nobody named (POST ${res.status})`,
    );
  });

  test('E19: a child create that omits its enumerated column stores nothing', async (t) => {
    if (guard(t)) return;
    // The same shape at a mount that DOES declare its domain: the value gate
    // judges a value that is present, and returns null for an absent one — so
    // the column with no value reached the INSERT and became `db_host`, which
    // then legally carries DB instances.
    const res = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/vms`,
      { name: 'kvm1' });

    assert.deepEqual(
      await rowsIn('cap_vms'), [],
      `a VM landed with a vm_type nobody named (POST ${res.status})`,
    );
  });

  test('a create that names the column still lands', async (t) => {
    if (guard(t)) return;
    // The other half. A required-on-create rule that fired for every column
    // would satisfy both cases above and stop every create.
    const res = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/vms`,
      { name: 'kvm1', vm_type: 'ap_host' });

    assert.equal(res.status, 200, `a legitimate create was refused: ${JSON.stringify(res.body)}`);
    assert.equal((await rowsIn('cap_vms'))[0].vm_type, 'ap_host');
  });

  test('and a column with a real declared default is not required', async (t) => {
    if (guard(t)) return;
    // `cap_sites.topology` is a NOT NULL ENUM WITH a declared DEFAULT, so the
    // value an omission gets is one somebody chose rather than an artifact of
    // declaration order. Requiring it would break the ordinary create.
    const res = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/sites`,
      { name: 'dc1' });

    assert.equal(res.status, 200, `a site create was refused for an unnamed default: ${JSON.stringify(res.body)}`);
    assert.equal((await rowsIn('cap_sites'))[0].topology, 'site');
  });

  test('a PUT that does not touch the column is unaffected', async (t) => {
    if (guard(t)) return;
    // Present-only semantics stay correct for an update: a column can be
    // legitimately absent from a partial PUT, and the stored value is already a
    // value somebody named.
    const created = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/vms`,
      { name: 'kvm1', vm_type: 'ap_host' });

    const res = await call(ADMIN, 'PUT',
      `/edge/app/capacity/scenarios/${SCENARIO_ID}/vms/${created.body.data.id}`, { name: 'renamed' });

    assert.equal(res.status, 200, `a partial update was refused: ${JSON.stringify(res.body)}`);
    const [vm] = await rowsIn('cap_vms');
    assert.equal(vm.name, 'renamed');
    assert.equal(vm.vm_type, 'ap_host', 'the untouched enumerated column moved');
  });
});

// ── E40 — the import and the route agree on what a duplicate field key is ───

describe('E40 — one notion of "the same field key"', () => {
  const importValidate = (tables) => call(ADMIN, 'POST',
    '/edge/app/capacity/config/import/validate', { tables });

  test('the premise: the route calls these two spellings one key', async (t) => {
    if (guard(t)) return;
    // Measured through the route rather than assumed, because it is what makes
    // the workbook's verdict wrong: the probe is `WHERE entity_type = ? AND
    // field_key = ?` under a case-folding collation, so the second spelling is
    // refused and the state the workbook produces is one this API cannot make.
    await seedFieldDef({ entity_type: 'vm', field_key: 'cost' });

    const second = await postFieldDef({ entity_type: 'vm', field_key: 'Cost', data_type: 'text' });

    assert.equal(
      (await fieldDefs()).length, 1,
      `the route accepted a second spelling of one key (POST ${second.status})`,
    );
  });

  test('a workbook carrying both spellings is refused', async (t) => {
    if (guard(t)) return;
    // The import compared the two byte for byte and called them two keys, so a
    // workbook carrying both imported cleanly and created exactly the state the
    // route refuses above — and one the operator can never repair through the
    // normal route, because the UNIQUE index cannot arbitrate for global rows
    // (each NULL scenario_id is distinct to MariaDB).
    const res = await importValidate({
      field_defs: [
        { entity_type: 'vm', field_key: 'cost', label: 'Cost', data_type: 'text' },
        { entity_type: 'vm', field_key: 'Cost', label: 'Cost again', data_type: 'text' },
      ],
    });

    assert.equal(res.status, 200, `the validate call failed: ${JSON.stringify(res.body)}`);
    assert.equal(
      res.body.data.ok, false,
      'a workbook carrying two spellings of one field key validated cleanly',
    );
    assert.ok(
      res.body.data.issues.some((i) => i.code === 'DUPLICATE_FIELD_DEF'),
      `no duplicate was reported: ${JSON.stringify(res.body.data.issues)}`,
    );
  });

  test('and two genuinely different keys still import', async (t) => {
    if (guard(t)) return;
    // The other half: folding the key must not start calling distinct keys one.
    const res = await importValidate({
      field_defs: [
        { entity_type: 'vm', field_key: 'cost', label: 'Cost', data_type: 'text' },
        { entity_type: 'vm', field_key: 'owner', label: 'Owner', data_type: 'text' },
      ],
    });

    assert.equal(res.status, 200);
    assert.ok(
      !res.body.data.issues.some((i) => i.code === 'DUPLICATE_FIELD_DEF'),
      `two distinct keys were called a duplicate: ${JSON.stringify(res.body.data.issues)}`,
    );
  });
});

// ── E56 — a replace-all import does not reset what its sheet is silent about ─

describe('E56 — the columns the databases sheet does not carry', () => {
  const storedDatabase = () => one(
    `SELECT function_name, topology, primary_sga_gb, standby_sga_gb, dc_refs
       FROM \`${tbl('cap_databases')}\``,
  );

  async function seedDatabaseWithSeeds() {
    const created = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/databases`,
      { function_name: 'erp', topology: 'single', primary_sga_gb: 64, standby_sga_gb: 32 });
    assert.equal(created.status, 200, `the database fixture was refused: ${JSON.stringify(created.body)}`);
    // dc_refs has no write route of its own; the point of the case is what an
    // import does to a value that is already stored, not how it got there.
    await q(`UPDATE \`${tbl('cap_databases')}\` SET dc_refs = ? WHERE id = ?`,
      [JSON.stringify(['a-site']), created.body.data.id]);
    const before = await storedDatabase();
    assert.equal(Number(before.primary_sga_gb), 64, 'the fixture did not store the SGA seed');
    return created.body.data.id;
  }

  const importSheet = () => call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/import`, {
    mode: 'commit',
    sheets: { databases: [{ function_name: 'erp', topology: 'single' }] },
  });

  test('a structurally clean import keeps the SGA seeds and the DC restriction', async (t) => {
    if (guard(t)) return;
    // The import declares neither column, so the replace-all re-inserted the
    // database without them and both became NULL. Nothing LOOKED broken,
    // because both NULLs are inheritance-semantic: the numbers simply became
    // derived values and the placement restriction disappeared, with no error
    // and no notice. The child instances' own sga_gb IS carried by the sheet,
    // so afterwards the parent said "derive" while the children held the old
    // explicit numbers.
    await seedDatabaseWithSeeds();

    const res = await importSheet();
    assert.equal(res.status, 200, `the import was refused: ${JSON.stringify(res.body)}`);

    const after = await storedDatabase();
    assert.equal(Number(after.primary_sga_gb), 64, 'a clean import cleared the Primary SGA seed');
    assert.equal(Number(after.standby_sga_gb), 32, 'a clean import cleared the Standby SGA seed');
    assert.ok(after.dc_refs != null, 'a clean import cleared the DC restriction');
  });

  test('and the columns the sheet DOES carry still come from the sheet', async (t) => {
    if (guard(t)) return;
    // The other half, and the one that matters: preserving what the sheet is
    // silent about must not start preserving what it speaks about, or the
    // import would stop importing.
    await seedDatabaseWithSeeds();

    const res = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/import`, {
      mode: 'commit',
      sheets: { databases: [{ function_name: 'erp', topology: 'primary_standby' }] },
    });
    assert.equal(res.status, 200, `the import was refused: ${JSON.stringify(res.body)}`);

    assert.equal((await storedDatabase()).topology, 'primary_standby', 'a declared column was not imported');
  });

  test('a database the sheet introduces carries nothing', async (t) => {
    if (guard(t)) return;
    // There is no row to carry from, and the DDL's own defaults are the right
    // answer for a row nobody had yet.
    await seedDatabaseWithSeeds();

    await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/import`, {
      mode: 'commit',
      sheets: { databases: [{ function_name: 'crm', topology: 'single' }] },
    });

    const after = await storedDatabase();
    assert.equal(after.function_name, 'crm');
    assert.equal(after.primary_sga_gb, null, 'a brand-new database inherited another row\'s SGA seed');
  });
});

// ── the carried DC restriction names sites the same import re-minted ─────────

describe('a preserved reference points at the row that replaced its target', () => {
  const storedDatabase = () => one(
    `SELECT id, function_name, dc_refs FROM \`${tbl('cap_databases')}\``,
  );
  const storedSites = () => q(
    `SELECT id, name FROM \`${tbl('cap_sites')}\` ORDER BY name`,
  );
  const dcRefsOf = (row) => {
    if (row.dc_refs == null) return null;
    return typeof row.dc_refs === 'string' ? JSON.parse(row.dc_refs) : row.dc_refs;
  };

  // A scenario whose database is restricted to one of its two DCs. The
  // restriction is written directly because `dc_refs` has no write route of its
  // own; what the case is about is what an import does to a stored one.
  async function seedRestrictedDatabase() {
    const dcA = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/sites`, { name: 'DC-A' });
    const dcB = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/sites`, { name: 'DC-B' });
    assert.equal(dcA.status, 200, `the site fixture was refused: ${JSON.stringify(dcA.body)}`);
    assert.equal(dcB.status, 200, `the site fixture was refused: ${JSON.stringify(dcB.body)}`);
    const db = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/databases`,
      { function_name: 'erp', topology: 'single' });
    assert.equal(db.status, 200, `the database fixture was refused: ${JSON.stringify(db.body)}`);
    await q(`UPDATE \`${tbl('cap_databases')}\` SET dc_refs = ? WHERE id = ?`,
      [JSON.stringify([dcA.body.data.id]), db.body.data.id]);
    return { dcA: dcA.body.data.id, dcB: dcB.body.data.id };
  }

  const roundTrip = (sites) => call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/import`, {
    mode: 'commit',
    sheets: {
      sites,
      databases: [{ function_name: 'erp', topology: 'single' }],
    },
  });

  test('the premise: a replace-all gives every site a new id', async (t) => {
    if (guard(t)) return;
    // Measured, because the whole defect rests on it: the commit DELETEs the
    // scenario's rows and re-INSERTs them under a freshly minted uuid, so any
    // stored id naming one of them names nothing afterwards.
    const { dcA } = await seedRestrictedDatabase();

    const res = await roundTrip([{ ref: dcA, name: 'DC-A' }, { name: 'DC-B' }]);
    assert.equal(res.status, 200, `the import was refused: ${JSON.stringify(res.body)}`);

    const sites = await storedSites();
    assert.equal(sites.length, 2);
    assert.ok(
      sites.every((s) => String(s.id) !== dcA),
      'the sites kept their ids; the cases below rest on them being re-minted',
    );
  });

  test('an exported workbook re-points the restriction at the new site row', async (t) => {
    if (guard(t)) return;
    // The ordinary export → import round trip. Every exported row carries its
    // own id in `ref`, so the restriction resolves exactly — the same ref-first
    // resolution the importer applies to every declared reference.
    const { dcA, dcB } = await seedRestrictedDatabase();

    const res = await roundTrip([{ ref: dcA, name: 'DC-A' }, { ref: dcB, name: 'DC-B' }]);
    assert.equal(res.status, 200, `the import was refused: ${JSON.stringify(res.body)}`);

    const sites = await storedSites();
    const newDcA = String(sites.find((s) => s.name === 'DC-A').id);
    assert.deepEqual(
      dcRefsOf(await storedDatabase()), [newDcA],
      'the restriction still names the site id the import deleted, so it admits no site at all',
    );
  });

  test('a hand-filled workbook with no ref column resolves it by name', async (t) => {
    if (guard(t)) return;
    // The fallback half, and the same order the importer resolves a declared
    // reference by: ref first, then the name.
    await seedRestrictedDatabase();

    const res = await roundTrip([{ name: 'DC-A' }, { name: 'DC-B' }]);
    assert.equal(res.status, 200, `the import was refused: ${JSON.stringify(res.body)}`);

    const sites = await storedSites();
    const newDcA = String(sites.find((s) => s.name === 'DC-A').id);
    assert.deepEqual(dcRefsOf(await storedDatabase()), [newDcA]);
  });

  test('a restriction naming a site the workbook drops is dropped, and reported', async (t) => {
    if (guard(t)) return;
    // Nothing replaces DC-A, so nothing can be pointed at. The entry goes
    // rather than being stored dead: an empty restriction reads as "all DCs",
    // which is coherent, while a list of ids no site holds admits NO site —
    // `filterDcCandidates` returns none and every placed VM reports itself
    // outside its own restriction.
    await seedRestrictedDatabase();

    const res = await roundTrip([{ name: 'DC-B' }]);
    assert.equal(res.status, 200, `the import was refused: ${JSON.stringify(res.body)}`);

    assert.deepEqual(
      dcRefsOf(await storedDatabase()), [],
      'a reference to a row this import no longer contains was carried over dead',
    );
    assert.ok(
      (res.body.notices || []).some((n) => n.code === 'DROPPED_STALE_REFERENCE'),
      'the restriction narrowed with no notice — the same silence the carry-over exists to end',
    );
  });

  test('a value that is not a reference is carried untouched', async (t) => {
    if (guard(t)) return;
    // The rule is keyed on the VALUE, so it has to leave alone anything that
    // does not name a row this import deleted — including the SGA seeds beside
    // it on the same row.
    await seedRestrictedDatabase();
    const dbRow = await storedDatabase();
    await q(`UPDATE \`${tbl('cap_databases')}\` SET primary_sga_gb = 64, dc_refs = ? WHERE id = ?`,
      [JSON.stringify(['not-an-id']), dbRow.id]);

    const res = await roundTrip([{ name: 'DC-A' }, { name: 'DC-B' }]);
    assert.equal(res.status, 200, `the import was refused: ${JSON.stringify(res.body)}`);

    const after = await one(
      `SELECT primary_sga_gb, dc_refs FROM \`${tbl('cap_databases')}\``,
    );
    assert.equal(Number(after.primary_sga_gb), 64, 'a carried value was lost');
    assert.deepEqual(dcRefsOf(after), ['not-an-id'], 'a value naming no deleted row was rewritten');
  });
});

// ── the child mounts bind the reference their own check resolved ────────────

describe('a child row stores the catalogue id, not the spelling the body sent', () => {
  async function seedGlobalTeam() {
    const res = await call(ADMIN, 'POST', '/edge/app/capacity/config/teams', { name: 'payments' });
    assert.equal(res.status, 201, `the team fixture was refused: ${JSON.stringify(res.body)}`);
    return res.body.data.id;
  }

  test('on create', async (t) => {
    if (guard(t)) return;
    // The §17.1a check resolves the reference through the COLUMN, which folds
    // case, so this create is legal and always was. What it stored was the
    // caller's spelling — a value every `WHERE team_id = ?` resolves and the
    // grid's own team lookup, keyed on the team's id, does not.
    const teamId = await seedGlobalTeam();

    const created = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/databases`,
      { function_name: 'erp', topology: 'single', team_id: teamId.toUpperCase() });
    assert.equal(created.status, 200, `the create was refused: ${JSON.stringify(created.body)}`);

    assert.equal(
      await storedBytes('cap_databases', 'team_id', created.body.data.id), teamId,
      'the child row stored the body\'s spelling of its team reference',
    );
  });

  test('and on update', async (t) => {
    if (guard(t)) return;
    // The other verb, on the same mount and through the same hook — this family
    // has twice been fixed on one verb and left open on the other.
    const teamId = await seedGlobalTeam();
    const created = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/databases`,
      { function_name: 'erp', topology: 'single' });
    assert.equal(created.status, 200, `the create was refused: ${JSON.stringify(created.body)}`);

    const updated = await call(ADMIN, 'PUT',
      `/edge/app/capacity/scenarios/${SCENARIO_ID}/databases/${created.body.data.id}`,
      { team_id: teamId.toUpperCase() });
    assert.equal(updated.status, 200, `the update was refused: ${JSON.stringify(updated.body)}`);

    assert.equal(
      await storedBytes('cap_databases', 'team_id', created.body.data.id), teamId,
      'the update stored the body\'s spelling of its team reference',
    );
  });
});

// ── a dc_refs entry stores the site's spelling, not the caller's ─────────────
//
// dc_refs is the last capacity reference that stored whatever the caller sent.
// It is a JSON LIST of cap_sites ids, not a scalar FK, so it is absent from
// CHILD_FK_VALIDATIONS and the §17.1a rebind never reached it. The site delete's
// probe and every frontend reader compare bytes, so a case-/pad-variant of a
// real site id resolved in SQL and admitted nothing to the readers — a broken
// restriction the backend called healthy. The fix binds the site's own spelling
// on write; the readers are NOT loosened (their byte comparison is deliberate).
describe('a dc_refs entry stores the site id, not the spelling the body sent', () => {
  async function seedSite(name = 'DC-A') {
    const res = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/sites`, { name });
    assert.equal(res.status, 200, `the site fixture was refused: ${JSON.stringify(res.body)}`);
    return res.body.data.id;
  }
  const dcRefsBytes = async (dbId) => {
    const raw = await storedBytes('cap_databases', 'dc_refs', dbId);
    return raw == null ? null : JSON.parse(raw);
  };
  const FAKE_SITE = '00000000-0000-4000-8000-0000000000ab';

  test('on create, a respelled entry is stored as the site\'s own id', async (t) => {
    if (guard(t)) return;
    const siteId = await seedSite();
    assert.notEqual(String(siteId).toUpperCase(), siteId, 'the site id has no letters to re-case');
    const created = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/databases`,
      { function_name: 'erp', topology: 'single', dc_refs: [String(siteId).toUpperCase()] });
    assert.equal(created.status, 200, `the create was refused: ${JSON.stringify(created.body)}`);
    assert.deepEqual(await dcRefsBytes(created.body.data.id), [siteId],
      'the create stored the caller\'s spelling of a real site id');
  });

  test('on create, a trailing-space entry (which SQL pads) is stored canonical', async (t) => {
    if (guard(t)) return;
    // PAD SPACE makes `'x ' = 'x'` true under every MariaDB collation, so `= ?`
    // resolves the site while every reader's byte comparison does not — the same
    // split as case, reached a second way.
    const siteId = await seedSite();
    const created = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/databases`,
      { function_name: 'erp', topology: 'single', dc_refs: [`${siteId} `] });
    assert.equal(created.status, 200, `the create was refused: ${JSON.stringify(created.body)}`);
    assert.deepEqual(await dcRefsBytes(created.body.data.id), [siteId]);
  });

  test('and on update — both verbs through the one hook', async (t) => {
    if (guard(t)) return;
    const siteId = await seedSite();
    const created = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/databases`,
      { function_name: 'erp', topology: 'single' });
    assert.equal(created.status, 200, `the create was refused: ${JSON.stringify(created.body)}`);
    const updated = await call(ADMIN, 'PUT',
      `/edge/app/capacity/scenarios/${SCENARIO_ID}/databases/${created.body.data.id}`,
      { dc_refs: [String(siteId).toUpperCase()] });
    assert.equal(updated.status, 200, `the update was refused: ${JSON.stringify(updated.body)}`);
    assert.deepEqual(await dcRefsBytes(created.body.data.id), [siteId]);
  });

  test('a canonical entry is stored byte-identical (the control)', async (t) => {
    if (guard(t)) return;
    const siteId = await seedSite();
    const created = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/databases`,
      { function_name: 'erp', topology: 'single', dc_refs: [siteId] });
    assert.equal(created.status, 200, `the create was refused: ${JSON.stringify(created.body)}`);
    assert.equal(await storedBytes('cap_databases', 'dc_refs', created.body.data.id),
      JSON.stringify([siteId]), 'a canonical entry was needlessly rewritten');
  });

  test('an entry naming no site is left exactly as it was (not validated away)', async (t) => {
    if (guard(t)) return;
    // Canonicalisation is not reference validation: dc_refs is deliberately not a
    // declared reference on the write side (site-references.js top note), so an
    // entry that names no site is stored verbatim and the health check reports it
    // — refusing or dropping it would change what the column may store.
    await seedSite();
    const created = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/databases`,
      { function_name: 'erp', topology: 'single', dc_refs: [FAKE_SITE] });
    assert.equal(created.status, 200, `the create was refused: ${JSON.stringify(created.body)}`);
    assert.deepEqual(await dcRefsBytes(created.body.data.id), [FAKE_SITE]);
  });

  test('a mixed list rewrites the resolving entry and preserves order and the rest', async (t) => {
    if (guard(t)) return;
    const siteId = await seedSite();
    const created = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/databases`,
      { function_name: 'erp', topology: 'single', dc_refs: [String(siteId).toUpperCase(), FAKE_SITE] });
    assert.equal(created.status, 200, `the create was refused: ${JSON.stringify(created.body)}`);
    assert.deepEqual(await dcRefsBytes(created.body.data.id), [siteId, FAKE_SITE]);
  });

  test('an unrelated update leaves a pre-existing variant untouched', async (t) => {
    if (guard(t)) return;
    // The pre-existing-broken-reference rule: a save that does not carry dc_refs
    // must not silently rewrite a restriction already stored (a partial PUT).
    const siteId = await seedSite();
    const created = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/databases`,
      { function_name: 'erp', topology: 'single' });
    assert.equal(created.status, 200, `the create was refused: ${JSON.stringify(created.body)}`);
    const variant = JSON.stringify([String(siteId).toUpperCase()]);
    await q(`UPDATE \`${tbl('cap_databases')}\` SET dc_refs = ? WHERE id = ?`, [variant, created.body.data.id]);

    const updated = await call(ADMIN, 'PUT',
      `/edge/app/capacity/scenarios/${SCENARIO_ID}/databases/${created.body.data.id}`,
      { function_name: 'renamed' });
    assert.equal(updated.status, 200, `the update was refused: ${JSON.stringify(updated.body)}`);
    assert.equal(await storedBytes('cap_databases', 'dc_refs', created.body.data.id), variant,
      'a save that did not carry dc_refs rewrote a stored restriction');
  });
});

// ── a dc_refs write is bounded by entry count, not by what each entry resolves ─
//
// canonicalizeDcRefs resolves each distinct string entry with one awaited SELECT
// inside the write transaction, one at a time, under the row locks the write
// already holds. Unbounded, a write-capable caller can send thousands of entries
// and hold those locks for as long as they take to resolve. The cap is a
// resource bound on the write, not reference validation: an entry that resolves
// to nothing is still stored verbatim at or under the cap, same as the suite
// above establishes without it.
describe('a dc_refs write is bounded by entry count', () => {
  async function seedSite(name = 'DC-A') {
    const res = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/sites`, { name });
    assert.equal(res.status, 200, `the site fixture was refused: ${JSON.stringify(res.body)}`);
    return res.body.data.id;
  }
  const dcRefsBytes = async (dbId) => {
    const raw = await storedBytes('cap_databases', 'dc_refs', dbId);
    return raw == null ? null : JSON.parse(raw);
  };
  const filler = (n) => Array.from({ length: n }, (_, i) => `zz-not-a-site-${i}`);

  test(`a write of ${MAX_DC_REFS_ENTRIES + 1} entries is refused, and nothing lands`, async (t) => {
    if (guard(t)) return;
    const res = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/databases`,
      { function_name: 'erp', topology: 'single', dc_refs: filler(MAX_DC_REFS_ENTRIES + 1) });
    assert.equal(res.status, 400, `expected a refusal, got ${JSON.stringify(res.body)}`);
    assert.equal(res.body.error.code, 'TOO_MANY_DC_REFS_ENTRIES');
    assert.equal(
      await countOf(`SELECT COUNT(*) AS n FROM \`${tbl('cap_databases')}\``), 0,
      'a write over the cap still landed a row',
    );
  });

  test(`a write of exactly ${MAX_DC_REFS_ENTRIES} entries passes and still canonicalises`, async (t) => {
    if (guard(t)) return;
    const siteId = await seedSite();
    const entries = filler(MAX_DC_REFS_ENTRIES - 1).concat(String(siteId).toUpperCase());
    assert.equal(entries.length, MAX_DC_REFS_ENTRIES, 'the fixture is not sized at the cap');

    const created = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/databases`,
      { function_name: 'erp', topology: 'single', dc_refs: entries });
    assert.equal(created.status, 200, `a write at the cap was refused: ${JSON.stringify(created.body)}`);

    const stored = await dcRefsBytes(created.body.data.id);
    assert.equal(stored.length, MAX_DC_REFS_ENTRIES);
    assert.equal(stored[stored.length - 1], siteId,
      'a write at the cap stored the caller\'s spelling instead of the site\'s own');
  });
});

// ── the bulk writers scope by the scenario's own id ──────────────────────────

describe('a bulk write stamps the scenario id, not the URL spelling', () => {
  test('a replace-all import through a respelled URL', async (t) => {
    if (guard(t)) return;
    // T7 fixed the single-row child writes to bind the stored scenario id. The
    // import reaches the same column for EVERY row it re-inserts and took
    // `req.params.scenarioId` — so one request left the whole scenario's content
    // carrying a `scenario_id` no scenario's `id` holds. Every `WHERE
    // scenario_id = ?` still finds those rows, so nothing reports a problem,
    // and every JavaScript reader of the column resolves nobody.
    const res = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ALIAS}/import`, {
      mode: 'commit',
      sheets: {
        sites: [{ name: 'DC-A' }],
        databases: [{ function_name: 'erp', topology: 'single' }],
      },
    });
    assert.equal(res.status, 200, `the import was refused: ${JSON.stringify(res.body)}`);

    const sites = await rowsIn('cap_sites');
    const databases = await rowsIn('cap_databases');
    assert.equal(sites.length, 1);
    assert.equal(databases.length, 1);
    assert.equal(
      await storedBytes('cap_sites', 'scenario_id', sites[0].id), SCENARIO_ID,
      'an imported site was stamped with the URL spelling',
    );
    assert.equal(
      await storedBytes('cap_databases', 'scenario_id', databases[0].id), SCENARIO_ID,
      'an imported database was stamped with the URL spelling',
    );
  });

  test('and a version restore through one', async (t) => {
    if (guard(t)) return;
    // The second bulk writer, reached through the same access gate.
    const site = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/sites`, { name: 'DC-A' });
    assert.equal(site.status, 200, `the site fixture was refused: ${JSON.stringify(site.body)}`);
    const version = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/versions`,
      { name: 'baseline' });
    assert.equal(version.status, 201, `the freeze was refused: ${JSON.stringify(version.body)}`);

    const restored = await call(ADMIN, 'POST',
      `/edge/app/capacity/scenarios/${SCENARIO_ALIAS}/versions/${version.body.data.id}/restore`,
      { confirm: true });
    assert.equal(restored.status, 200, `the restore was refused: ${JSON.stringify(restored.body)}`);

    const sites = await rowsIn('cap_sites');
    assert.equal(sites.length, 1, 'the restore did not replay the frozen site');
    assert.equal(
      await storedBytes('cap_sites', 'scenario_id', sites[0].id), SCENARIO_ID,
      'a restored row was stamped with the URL spelling',
    );
  });
});

// ── "is this scenario the caller's" is asked of the column ──────────────────

describe('an editor owning a scenario under another spelling of their id', () => {
  // The state a transfer left behind before the producers were made to bind the
  // stored id. Nothing rewrites such a row, so the READERS have to answer for
  // it — and the failure is in the direction that refuses the genuine owner.
  const EDITOR_ALIAS = EDITOR_ID.toUpperCase();

  async function seedAliasOwnedScenario() {
    await q(`UPDATE \`${tbl('cap_scenarios')}\` SET owner_id = ? WHERE id = ?`,
      [EDITOR_ALIAS, SCENARIO_ID]);
    assert.equal(
      await countOf(
        `SELECT COUNT(*) AS n FROM \`${tbl('cap_scenarios')}\` WHERE id = ? AND owner_id = ?`,
        [SCENARIO_ID, EDITOR_ID],
      ),
      1, 'this column no longer resolves the owner under another spelling',
    );
  }

  test('may delete a child row of it, and the row is gone', async (t) => {
    if (guard(t)) return;
    const created = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/sites`, { name: 'DC-A' });
    assert.equal(created.status, 200, `the site fixture was refused: ${JSON.stringify(created.body)}`);
    await seedAliasOwnedScenario();

    const res = await call(EDITOR, 'DELETE',
      `/edge/app/capacity/scenarios/${SCENARIO_ID}/sites/${created.body.data.id}`);

    assert.equal(
      await countOf(`SELECT COUNT(*) AS n FROM \`${tbl('cap_sites')}\``), 0,
      'the owner was refused the delete of a row in their own scenario',
    );
    assert.equal(res.status, 200, `the delete was refused: ${JSON.stringify(res.body)}`);
  });

  test('may delete a scenario-local catalogue row of it', async (t) => {
    if (guard(t)) return;
    const created = await call(ADMIN, 'POST',
      `/edge/app/capacity/scenarios/${SCENARIO_ID}/local-catalogues/teams`, { name: 'payments' });
    assert.equal(created.status, 200, `the team fixture was refused: ${JSON.stringify(created.body)}`);
    await seedAliasOwnedScenario();

    const res = await call(EDITOR, 'DELETE',
      `/edge/app/capacity/scenarios/${SCENARIO_ID}/local-catalogues/teams/${created.body.data.id}`);

    assert.equal(
      await countOf(`SELECT COUNT(*) AS n FROM \`${tbl('cap_teams')}\` WHERE scenario_id IS NOT NULL`), 0,
      'the owner was refused the delete of a local catalogue row in their own scenario',
    );
    assert.equal(res.status, 200, `the delete was refused: ${JSON.stringify(res.body)}`);
  });

  test('and may write its settings, which land on the row', async (t) => {
    if (guard(t)) return;
    await seedAliasOwnedScenario();

    const res = await call(EDITOR, 'PUT', `/edge/app/capacity/scenarios/${SCENARIO_ID}/settings`,
      { mem_cpu_ratio: 12 });

    const stored = await one(
      `SELECT mem_cpu_ratio FROM \`${tbl('cap_settings')}\` WHERE scenario_id = ?`, [SCENARIO_ID],
    );
    assert.ok(stored, 'the owner was refused a settings write on their own scenario');
    assert.equal(Number(stored.mem_cpu_ratio), 12);
    assert.equal(res.status, 200, `the write was refused: ${JSON.stringify(res.body)}`);
  });

  test('a stranger is still refused, and nothing moves', async (t) => {
    if (guard(t)) return;
    // The other direction, so the fix cannot be "let everybody through".
    const created = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/sites`, { name: 'DC-A' });
    assert.equal(created.status, 200, `the site fixture was refused: ${JSON.stringify(created.body)}`);
    await q(`UPDATE \`${tbl('cap_scenarios')}\` SET owner_id = ? WHERE id = ?`, [ADMIN_ID, SCENARIO_ID]);

    const res = await call(EDITOR, 'DELETE',
      `/edge/app/capacity/scenarios/${SCENARIO_ID}/sites/${created.body.data.id}`);

    assert.equal(
      await countOf(`SELECT COUNT(*) AS n FROM \`${tbl('cap_sites')}\``), 1,
      'a non-owner deleted a row from somebody else\'s scenario',
    );
    assert.equal(res.status, 403);
  });
});

// ── a create names the enumerated column the engine would choose for it ──────

describe('the required-on-create rule, on the mounts nobody had tested', () => {
  // The rule lives inside `createCrudRoutes` and is not opt-in, so it reaches
  // every mount that declares a domain — not only the ones this card edited.
  // The suite proved it for `cap_vms.vm_type` alone; these are the other three.
  //
  // The refusal is INTENDED on each of them. A NOT NULL ENUM with no DEFAULT
  // takes the FIRST DECLARED MEMBER when a create omits it — measured on this
  // engine, not assumed — so the alternative is a row silently claiming a class,
  // a role or a rule type nobody chose. Every surface that creates one of these
  // sends the field.

  test('the premise: the engine really does fill an omitted ENUM itself', async (t) => {
    if (guard(t)) return;
    // Measured with no route in the way, on the exact column the case below is
    // about. Without this the refusal looks like pedantry rather than the only
    // way to keep the operator's choice from being invented.
    await q(
      `INSERT INTO \`${tbl('cap_vm_profiles')}\` (id, scenario_id, name) VALUES (?,?,?)`,
      ['aaaaaaa1-1111-4111-8111-111111111111', SCENARIO_ID, 'unclassed'],
    );
    const row = await one(
      `SELECT class FROM \`${tbl('cap_vm_profiles')}\` WHERE id = ?`,
      ['aaaaaaa1-1111-4111-8111-111111111111'],
    );
    assert.equal(row.class, 'DB', 'this column no longer takes the first member on omission');
  });

  test('a scenario-local vm_profile create must name its class', async (t) => {
    if (guard(t)) return;
    const res = await call(ADMIN, 'POST',
      `/edge/app/capacity/scenarios/${SCENARIO_ID}/local-catalogues/vm_profiles`,
      { name: 'local profile', mode: 'formula', cpu: 8 });

    assert.equal(
      await countOf(`SELECT COUNT(*) AS n FROM \`${tbl('cap_vm_profiles')}\``), 0,
      'a profile landed with a class the engine chose',
    );
    assert.equal(res.status, 400, `expected a refusal, got ${JSON.stringify(res.body)}`);
    assert.equal(res.body.error.code, 'COLUMN_REQUIRED');
  });

  test('and one that names it is created', async (t) => {
    if (guard(t)) return;
    // The other direction: the rule must not have closed the mount.
    const res = await call(ADMIN, 'POST',
      `/edge/app/capacity/scenarios/${SCENARIO_ID}/local-catalogues/vm_profiles`,
      { name: 'local profile', class: 'AP', mode: 'formula', cpu: 8 });
    assert.equal(res.status, 200, `the create was refused: ${JSON.stringify(res.body)}`);
    assert.equal((await one(`SELECT class FROM \`${tbl('cap_vm_profiles')}\``)).class, 'AP');
  });

  test('a db_instance create must name its role', async (t) => {
    if (guard(t)) return;
    const vm = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/vms`,
      { name: 'kvm-1', vm_type: 'db_host' });
    assert.equal(vm.status, 200, `the VM fixture was refused: ${JSON.stringify(vm.body)}`);

    const res = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/db_instances`,
      { name: 'inst-1', vm_id: vm.body.data.id });

    assert.equal(
      await countOf(`SELECT COUNT(*) AS n FROM \`${tbl('cap_db_instances')}\``), 0,
      'an instance landed as a primary nobody declared',
    );
    assert.equal(res.status, 400, `expected a refusal, got ${JSON.stringify(res.body)}`);
    assert.equal(res.body.error.code, 'COLUMN_REQUIRED');
  });

  test('a non-override rule create must name its type and level', async (t) => {
    if (guard(t)) return;
    // An OVERRIDE row is the documented exception — it carries neither, and the
    // fill guard supplies both from the global rule it overrides. A plain rule
    // has no such source.
    const res = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/rules`,
      { name: 'a rule', enabled: true });

    assert.equal(
      await countOf(`SELECT COUNT(*) AS n FROM \`${tbl('cap_rules')}\``), 0,
      'a rule landed with a type and level the engine chose',
    );
    assert.equal(res.status, 400, `expected a refusal, got ${JSON.stringify(res.body)}`);
  });

  test('an override create with no target names the REFERENCE, not the column', async (t) => {
    if (guard(t)) return;
    // The diagnosis this rule displaced. An override payload is documented never
    // to carry `type`, so answering COLUMN_REQUIRED about it sends the operator
    // to a field they are right not to have sent. The only thing wrong with the
    // request is the `overrides_rule_id`.
    const res = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/rules`,
      { overrides_rule_id: 'aaaaaaa2-2222-4222-8222-222222222222', enabled: false });

    assert.equal(
      await countOf(`SELECT COUNT(*) AS n FROM \`${tbl('cap_rules')}\``), 0,
      'an override landed against a rule that does not exist',
    );
    assert.equal(res.status, 400, `expected a refusal, got ${JSON.stringify(res.body)}`);
    assert.equal(res.body.error.code, 'INVALID_REFERENCE');
    assert.match(res.body.error.message, /overrides_rule_id/);
  });

  // fmb-1549: the rule above was ENUM-only (`enumRequiredOnCreate`, filtered to
  // columns with a declared domain) — a NOT NULL column of any OTHER type
  // omitted the same way fell straight through to the database's own
  // constraint violation, mapped generically to a 500 naming no column at all.
  // Measured live: `POST …/hypervisors` without `spec_id` → 500; `POST
  // …/databases` without `function_name` → 500, while `topology` (an ENUM)
  // alone answered a clean 400. These are the two named columns from that
  // report, plus one more mount to prove the derivation, not a hand list.

  test('a hypervisor create must name its spec_id (non-enum column, fmb-1549)', async (t) => {
    if (guard(t)) return;
    const site = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/sites`, { name: 'DC-req' });
    assert.equal(site.status, 200, `the site fixture was refused: ${JSON.stringify(site.body)}`);

    const res = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/hypervisors`,
      { name: 'hv-1', site_id: site.body.data.id });

    assert.equal(
      await countOf(`SELECT COUNT(*) AS n FROM \`${tbl('cap_hypervisors')}\``), 0,
      'a hypervisor landed with no spec at all',
    );
    assert.equal(res.status, 400, `expected a refusal, got ${JSON.stringify(res.body)}`);
    assert.equal(res.body.error.code, 'COLUMN_REQUIRED');
    assert.match(res.body.error.message, /spec_id/);
  });

  test('a database create must name its function_name (non-enum column, fmb-1549)', async (t) => {
    if (guard(t)) return;
    const res = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/databases`,
      { topology: 'single' });

    assert.equal(
      await countOf(`SELECT COUNT(*) AS n FROM \`${tbl('cap_databases')}\``), 0,
      'a database landed with no function_name at all',
    );
    assert.equal(res.status, 400, `expected a refusal, got ${JSON.stringify(res.body)}`);
    assert.equal(res.body.error.code, 'COLUMN_REQUIRED');
    assert.match(res.body.error.message, /function_name/);
  });

  test('a database create that names every required column still succeeds', async (t) => {
    if (guard(t)) return;
    // The other direction: the widened rule must not have closed the mount.
    const res = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/databases`,
      { function_name: 'erp', topology: 'single' });
    assert.equal(res.status, 200, `the create was refused: ${JSON.stringify(res.body)}`);
    assert.equal((await one(`SELECT function_name FROM \`${tbl('cap_databases')}\``)).function_name, 'erp');
  });

  test('a site create must name its name (a third mount, proving the set is derived, not two hand-picked columns)', async (t) => {
    if (guard(t)) return;
    const res = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/sites`, {});

    assert.equal(
      await countOf(`SELECT COUNT(*) AS n FROM \`${tbl('cap_sites')}\``), 0,
      'a site landed with no name at all',
    );
    assert.equal(res.status, 400, `expected a refusal, got ${JSON.stringify(res.body)}`);
    assert.equal(res.body.error.code, 'COLUMN_REQUIRED');
    assert.match(res.body.error.message, /name/);
  });

  // Same defect family, the OTHER call site: /config mounts use a bespoke
  // handler (createCrudRoutes cannot express the scenario_id IS NULL template
  // scope) that already called this rule's function for its ENUM columns —
  // widening the ONE shared function fixes both call sites in the same change.
  test('a global hardware_specs create must name its name (config.js call site, same widened rule)', async (t) => {
    if (guard(t)) return;
    const res = await call(ADMIN, 'POST', '/edge/app/capacity/config/hardware_specs', { cpu_total: 32 });

    assert.equal(
      await countOf(`SELECT COUNT(*) AS n FROM \`${tbl('cap_hardware_specs')}\``), 0,
      'a global hardware spec landed with no name at all',
    );
    assert.equal(res.status, 400, `expected a refusal, got ${JSON.stringify(res.body)}`);
    assert.equal(res.body.error.code, 'BAD_REQUEST');
    assert.match(res.body.error.message, /name/);
  });
});

// ── an explicit null bypassed missingRequiredColumnOnCreate (D5 review finding 2)
//
// `missingRequiredColumnOnCreate` derived presence from the WRITE BODY'S KEY
// SET (Object.keys / collectWrite's hasOwnProperty), so `{ spec_id: null }`
// counted as "present" and reached the database as a raw, unmapped NOT NULL
// violation — reproducing fmb-1549 for every non-enum required column, just
// with the value spelled `null` instead of omitted.
describe('an explicit null on a required column is refused the same as its absence (fmb-1549 twin)', () => {
  test('a hypervisor create with spec_id: null is refused COLUMN_REQUIRED, not a raw DB error', async (t) => {
    if (guard(t)) return;
    const site = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/sites`, { name: 'DC-null' });
    assert.equal(site.status, 200, `the site fixture was refused: ${JSON.stringify(site.body)}`);

    const res = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/hypervisors`,
      { name: 'hv-null', site_id: site.body.data.id, spec_id: null });

    assert.equal(
      await countOf(`SELECT COUNT(*) AS n FROM \`${tbl('cap_hypervisors')}\``), 0,
      'a hypervisor landed despite an explicit null spec_id',
    );
    assert.equal(res.status, 400, `expected a refusal, got ${JSON.stringify(res.body)}`);
    assert.equal(res.body.error.code, 'COLUMN_REQUIRED');
    assert.match(res.body.error.message, /spec_id/);
  });

  test('a database create with function_name: null is refused COLUMN_REQUIRED, not a raw DB error', async (t) => {
    if (guard(t)) return;
    const res = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/databases`,
      { function_name: null, topology: 'single' });

    assert.equal(
      await countOf(`SELECT COUNT(*) AS n FROM \`${tbl('cap_databases')}\``), 0,
      'a database landed despite an explicit null function_name',
    );
    assert.equal(res.status, 400, `expected a refusal, got ${JSON.stringify(res.body)}`);
    assert.equal(res.body.error.code, 'COLUMN_REQUIRED');
    assert.match(res.body.error.message, /function_name/);
  });

  test('a global hardware_specs create with name: null is refused, not a raw DB error (config.js call site)', async (t) => {
    if (guard(t)) return;
    const res = await call(ADMIN, 'POST', '/edge/app/capacity/config/hardware_specs', { name: null, cpu_total: 32 });

    assert.equal(
      await countOf(`SELECT COUNT(*) AS n FROM \`${tbl('cap_hardware_specs')}\``), 0,
      'a global hardware spec landed despite an explicit null name',
    );
    assert.equal(res.status, 400, `expected a refusal, got ${JSON.stringify(res.body)}`);
    assert.equal(res.body.error.code, 'BAD_REQUEST');
    assert.match(res.body.error.message, /name/);
  });

  test('an empty string and a zero are still values, not treated as missing', async (t) => {
    if (guard(t)) return;
    // The rule this guards against overcorrecting: '' and 0 are the caller's
    // VALUES, not an absence — only an explicit null is refused here (the
    // pre-existing EMPTY_NOT_ALLOWED / numeric guards, if any, are a separate
    // concern from a different gate).
    const res = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/databases`,
      { function_name: 'zero-fixture', topology: 'single', node_count: 0 });
    assert.equal(res.status, 200, `a legitimate zero/empty value was refused: ${JSON.stringify(res.body)}`);
  });
});

// ── the required-on-create rule reaches local catalogues too (D5 review finding 3)
//
// LOCAL_CATALOGUE_MOUNTS wires enumColumns (so class is already covered by the
// factory's own enumRequiredOnCreate mechanism, same as the global /config
// mount — see local-catalogues.js's own top note), but never called
// missingRequiredColumnOnCreate, so a NOT-NULL-no-default column of any OTHER
// type reached the database's own constraint violation as a raw 500, exactly
// the shape fmb-1549 closed on children.js and config.js.
describe('the required-on-create rule reaches local catalogues too (item 3)', () => {
  test('a scenario-local vm_profile create must name its name, not just its class', async (t) => {
    if (guard(t)) return;
    const res = await call(ADMIN, 'POST',
      `/edge/app/capacity/scenarios/${SCENARIO_ID}/local-catalogues/vm_profiles`,
      { class: 'DB', mode: 'formula', cpu: 8 });

    assert.equal(
      await countOf(`SELECT COUNT(*) AS n FROM \`${tbl('cap_vm_profiles')}\` WHERE scenario_id = ?`, [SCENARIO_ID]),
      0, 'a local profile landed with no name at all',
    );
    assert.equal(res.status, 400, `expected a refusal, got ${JSON.stringify(res.body)}`);
    assert.equal(res.body.error.code, 'COLUMN_REQUIRED');
    assert.match(res.body.error.message, /name/);
  });

  test('a scenario-local hardware_specs create must name its name', async (t) => {
    if (guard(t)) return;
    const res = await call(ADMIN, 'POST',
      `/edge/app/capacity/scenarios/${SCENARIO_ID}/local-catalogues/hardware_specs`, { cpu_total: 16 });

    assert.equal(
      await countOf(`SELECT COUNT(*) AS n FROM \`${tbl('cap_hardware_specs')}\` WHERE scenario_id = ?`, [SCENARIO_ID]),
      0, 'a local hardware spec landed with no name at all',
    );
    assert.equal(res.status, 400, `expected a refusal, got ${JSON.stringify(res.body)}`);
    assert.equal(res.body.error.code, 'COLUMN_REQUIRED');
    assert.match(res.body.error.message, /name/);
  });

  test('a scenario-local create that names everything required still succeeds (the rule did not close the mount)', async (t) => {
    if (guard(t)) return;
    const res = await call(ADMIN, 'POST',
      `/edge/app/capacity/scenarios/${SCENARIO_ID}/local-catalogues/hardware_specs`, { name: 'local-spec', cpu_total: 16 });
    assert.equal(res.status, 200, `the create was refused: ${JSON.stringify(res.body)}`);
    assert.equal((await one(
      `SELECT name FROM \`${tbl('cap_hardware_specs')}\` WHERE scenario_id = ?`, [SCENARIO_ID],
    )).name, 'local-spec');
  });
});

// ── a delete reports what it moved ──────────────────────────────────────────

describe('deleting a site says how many VMs lost their pin', () => {
  test('the count matches the rows the statement actually changed', async (t) => {
    if (guard(t)) return;
    // The answer used to be `{id, deleted:true}` whatever the blast radius was,
    // so an operator removing one DC could not tell whether it had unpinned five
    // VMs or none — while the blueprint owner cascade beside it reports
    // `cascaded_variants`. The assertion is on both the reported number AND the
    // stored rows, because a count nothing checks is a number, not a report.
    const site = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/sites`, { name: 'DC-A' });
    assert.equal(site.status, 200, `the site fixture was refused: ${JSON.stringify(site.body)}`);
    for (const name of ['kvm-1', 'kvm-2']) {
      const vm = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/vms`,
        { name, vm_type: 'ap_host', site_id: site.body.data.id });
      assert.equal(vm.status, 200, `the VM fixture was refused: ${JSON.stringify(vm.body)}`);
    }

    const res = await call(ADMIN, 'DELETE',
      `/edge/app/capacity/scenarios/${SCENARIO_ID}/sites/${site.body.data.id}`);
    assert.equal(res.status, 200, `the delete was refused: ${JSON.stringify(res.body)}`);

    assert.equal(
      await countOf(`SELECT COUNT(*) AS n FROM \`${tbl('cap_vms')}\` WHERE site_id IS NULL`), 2,
      'the delete did not unpin the VMs standing in the site',
    );
    assert.equal(
      res.body.data.unplaced['cap_vms.site_id'], 2,
      'the delete reported a different number than it changed',
    );
  });

  test('and reports zero when nothing was standing there', async (t) => {
    if (guard(t)) return;
    // A count that is only ever present when it is interesting is a count a
    // caller has to guess about.
    const site = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/sites`, { name: 'DC-B' });
    assert.equal(site.status, 200, `the site fixture was refused: ${JSON.stringify(site.body)}`);

    const res = await call(ADMIN, 'DELETE',
      `/edge/app/capacity/scenarios/${SCENARIO_ID}/sites/${site.body.data.id}`);
    assert.equal(res.status, 200, `the delete was refused: ${JSON.stringify(res.body)}`);
    assert.equal(res.body.data.unplaced['cap_vms.site_id'], 0);
  });
});

// ── F3 — the version writers bind the scenario's own id ─────────────────────

/**
 * The version endpoints hold the resolved scenario in `access` before they write
 * anything: `resolveScenarioWriteAccess` projects `cap_scenarios.id` precisely so
 * its callers can bind it. The restore path takes it for the rows it re-inserts.
 * The three sites below did not — they bound `req.params.scenarioId`, which
 * `WHERE id = ?` had already admitted under any spelling.
 *
 * A WHERE parameter is not on this list and does not need to be: the column
 * folds, so `WHERE scenario_id = ?` resolves the row either way. What is on the
 * list is every place the value is WRITTEN DOWN or HANDED BACK — a stored FK, a
 * durable audit line, a response the browser resolves in JavaScript — because
 * those are the readers that do not fold.
 */
const auditRows = (eventType) => q(
  `SELECT metadata FROM \`${tbl('feature_audit')}\` WHERE event_type = ?`, [eventType],
);
const metadataOf = (row) => (typeof row.metadata === 'string' ? JSON.parse(row.metadata) : row.metadata);

describe('F3 — a version records the scenario id, not the URL spelling', () => {
  test('the premise: the versions URL resolves the scenario under either spelling', async (t) => {
    if (guard(t)) return;
    const res = await call(ADMIN, 'GET', `/edge/app/capacity/scenarios/${SCENARIO_ALIAS}/versions`);
    assert.equal(res.status, 200, 'the respelled scenario is not reachable; the cases below rest on it');
  });

  test('a create through a respelled URL stores the scenario\'s own id', async (t) => {
    if (guard(t)) return;
    const res = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ALIAS}/versions`,
      { name: 'v1' });
    assert.equal(res.status, 201, `the version create was refused: ${JSON.stringify(res.body)}`);

    const versions = await rowsIn('cap_versions');
    assert.equal(versions.length, 1);
    // The stored bytes. A version carrying the caller's spelling is still found
    // by every `WHERE scenario_id = ?` — so the list keeps showing it — while
    // anything resolving the scope in JavaScript does not.
    assert.equal(
      await storedBytes('cap_versions', 'scenario_id', versions[0].id), SCENARIO_ID,
      'the version was stamped with the URL spelling rather than the scenario id',
    );
    // And the body the client is handed says the same thing the row does.
    assert.equal(res.body.data.scenario_id, SCENARIO_ID);
  });

  test('a rename through a respelled URL writes the scenario\'s own id into the trail', async (t) => {
    if (guard(t)) return;
    const created = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/versions`,
      { name: 'v1' });
    assert.equal(created.status, 201, `the version fixture was refused: ${JSON.stringify(created.body)}`);

    const res = await call(ADMIN, 'PUT',
      `/edge/app/capacity/scenarios/${SCENARIO_ALIAS}/versions/${created.body.data.id}`,
      { name: 'v1 renamed' });
    assert.equal(res.status, 200, `the rename was refused: ${JSON.stringify(res.body)}`);

    const audit = await auditRows('cap_scenario.version.edit');
    assert.equal(audit.length, 1, 'the rename wrote no audit row');
    assert.equal(
      metadataOf(audit[0]).scenario_id, SCENARIO_ID,
      'the audit line names a scenario id no scenario carries',
    );
  });

  test('a restore through a respelled URL does the same', async (t) => {
    if (guard(t)) return;
    const created = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/versions`,
      { name: 'v1' });
    assert.equal(created.status, 201, `the version fixture was refused: ${JSON.stringify(created.body)}`);

    const res = await call(ADMIN, 'POST',
      `/edge/app/capacity/scenarios/${SCENARIO_ALIAS}/versions/${created.body.data.id}/restore`,
      { confirm: true });
    assert.equal(res.status, 200, `the restore was refused: ${JSON.stringify(res.body)}`);

    assert.equal(res.body.data.scenario_id, SCENARIO_ID);
    const audit = await auditRows('cap_scenario.version.restore');
    assert.equal(audit.length, 1, 'the restore wrote no audit row');
    assert.equal(
      metadataOf(audit[0]).scenario_id, SCENARIO_ID,
      'the audit line names a scenario id no scenario carries',
    );
  });
});

// ── a clone's dc_refs names the clone's own site, not the source's ───────────
//
// The clone deep-copies every scenario row under a freshly minted id and remaps
// each scalar FK (CLONE_FK_COLUMNS) and each JSON-list reference. dc_refs is a
// JSON list of cap_sites ids — like allowed_disk_combos, and unlike a scalar FK
// — so it needs its own remap: left verbatim it would name the SOURCE sites,
// which the clone reminted, so every restriction would admit no data centre. A
// clone that mints a broken reference is a second way past T1's write-time fix.
describe('a clone remaps a dc_refs restriction to the site that replaced its target', () => {
  async function seedRestrictedScenario() {
    const dcA = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/sites`, { name: 'DC-A' });
    const dcB = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/sites`, { name: 'DC-B' });
    assert.equal(dcA.status, 200, `the site fixture was refused: ${JSON.stringify(dcA.body)}`);
    assert.equal(dcB.status, 200, `the site fixture was refused: ${JSON.stringify(dcB.body)}`);
    const db = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/databases`,
      { function_name: 'erp', topology: 'single', dc_refs: [dcA.body.data.id] });
    assert.equal(db.status, 200, `the database fixture was refused: ${JSON.stringify(db.body)}`);
    return { dcA: dcA.body.data.id };
  }
  const cloneSiteIdByName = (cloneId, name) => one(
    `SELECT id FROM \`${tbl('cap_sites')}\` WHERE scenario_id = ? AND name = ?`, [cloneId, name],
  );
  const cloneDbDcRefs = async (cloneId) => {
    const row = await one(
      `SELECT dc_refs FROM \`${tbl('cap_databases')}\` WHERE scenario_id = ?`, [cloneId],
    );
    if (!row || row.dc_refs == null) return null;
    return typeof row.dc_refs === 'string' ? JSON.parse(row.dc_refs) : row.dc_refs;
  };

  test('the restriction points at the clone\'s DC-A, not the source\'s', async (t) => {
    if (guard(t)) return;
    const { dcA } = await seedRestrictedScenario();

    const cloned = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/clone`,
      { name: 'a clone' });
    assert.equal(cloned.status, 201, `the clone was refused: ${JSON.stringify(cloned.body)}`);
    const cloneId = cloned.body.data.id;

    const cloneDcA = (await cloneSiteIdByName(cloneId, 'DC-A')).id;
    assert.notEqual(cloneDcA, dcA, 'the premise fails: the clone reused the source site id');
    assert.deepEqual(await cloneDbDcRefs(cloneId), [cloneDcA],
      'the clone carried the source site id into a restriction naming a site that does not exist in it');
  });

  // The branch the test above never exercises: `remapDcRefs` keeps an entry
  // verbatim when `idMap` does not know it — a dc_refs value already dangling
  // in the source (never a site id at all here, but the same code path a
  // case-variant write-time canonicalisation missed would take). Verbatim means
  // byte-for-byte, not "still a string": a rewrite that folded, trimmed or
  // touched it in any way would be invisible to the assertion above, which only
  // checks the live entry.
  test('a non-matching entry beside a live one survives the clone untouched', async (t) => {
    if (guard(t)) return;
    const DANGLING = '00000000-0000-4000-8000-0000000000ab';
    const dcA = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/sites`, { name: 'DC-A' });
    assert.equal(dcA.status, 200, `the site fixture was refused: ${JSON.stringify(dcA.body)}`);
    const db = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/databases`,
      { function_name: 'erp', topology: 'single', dc_refs: [dcA.body.data.id, DANGLING] });
    assert.equal(db.status, 200, `the database fixture was refused: ${JSON.stringify(db.body)}`);

    const cloned = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/clone`,
      { name: 'a clone' });
    assert.equal(cloned.status, 201, `the clone was refused: ${JSON.stringify(cloned.body)}`);
    const cloneId = cloned.body.data.id;

    const cloneDcA = (await cloneSiteIdByName(cloneId, 'DC-A')).id;
    assert.notEqual(cloneDcA, dcA.body.data.id, 'the premise fails: the clone reused the source site id');
    assert.deepEqual(await cloneDbDcRefs(cloneId), [cloneDcA, DANGLING],
      'the clone either failed to remap the live entry or rewrote the entry idMap does not know');
  });

  // dcRefEntries reads an unreadable element (a nested array, an object) as its
  // own entry rather than a gap — it can never RESOLVE, so it must survive a
  // clone exactly as untouched as any other dangling entry. The old remap coerced
  // every element with `String()` before the lookup: `String([siteId])` drops the
  // brackets, so a single-element nested array happens to stringify to the site
  // id itself, hits the map, and is REPLACED by the clone's scalar site id — an
  // element that was never a live reference becomes one.
  test('a nested-array entry is not flattened, and not remapped through the site map', async (t) => {
    if (guard(t)) return;
    const dcA = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/sites`, { name: 'DC-A' });
    assert.equal(dcA.status, 200, `the site fixture was refused: ${JSON.stringify(dcA.body)}`);
    const nested = [[dcA.body.data.id]];
    const db = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/databases`,
      { function_name: 'erp', topology: 'single', dc_refs: nested });
    assert.equal(db.status, 200, `the database fixture was refused: ${JSON.stringify(db.body)}`);

    const cloned = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/clone`,
      { name: 'a clone' });
    assert.equal(cloned.status, 201, `the clone was refused: ${JSON.stringify(cloned.body)}`);
    const cloneId = cloned.body.data.id;

    assert.deepEqual(await cloneDbDcRefs(cloneId), nested,
      'the nested array stringified down to the site id, matched the site map, and was replaced by the '
      + "clone's scalar site id instead of surviving verbatim");
  });

  // The old remap resolved every element through the SAME idMap Phase 1 builds
  // for every cloned table (hypervisors, vms, …), not a sites-only submap. A
  // dc_refs entry only ever names a site, so a dangling entry that happens to
  // equal some OTHER table's source id must still be left verbatim — resolving
  // it through the all-tables map silently rewrites it to that row's clone id,
  // inventing a resolution dc_refs never had.
  test('a dangling entry equal to another table\'s source id is not remapped through it', async (t) => {
    if (guard(t)) return;
    const spec = await call(ADMIN, 'POST', '/edge/app/capacity/config/hardware_specs',
      { name: 'spec', cpu_total: 64, mem_total_gb: 512, disk_total_gb: 4096 });
    assert.equal(spec.status, 201, `the spec fixture was refused: ${JSON.stringify(spec.body)}`);
    const site = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/sites`, { name: 'DC-A' });
    assert.equal(site.status, 200, `the site fixture was refused: ${JSON.stringify(site.body)}`);
    const hv = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/hypervisors`,
      { name: 'hv1', site_id: site.body.data.id, spec_id: spec.body.data.id });
    assert.equal(hv.status, 200, `the hypervisor fixture was refused: ${JSON.stringify(hv.body)}`);
    const hvId = hv.body.data.id;

    const db = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/databases`,
      { function_name: 'erp', topology: 'single', dc_refs: [hvId] });
    assert.equal(db.status, 200, `the database fixture was refused: ${JSON.stringify(db.body)}`);

    const cloned = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/clone`,
      { name: 'a clone' });
    assert.equal(cloned.status, 201, `the clone was refused: ${JSON.stringify(cloned.body)}`);
    const cloneId = cloned.body.data.id;

    assert.deepEqual(await cloneDbDcRefs(cloneId), [hvId],
      'the dangling entry happened to equal a source hypervisor id, and the all-tables idMap rewrote it '
      + "to the clone hypervisor's own id instead of leaving it verbatim");
  });
});

// ── fmb-1566's deferred half: allowed_disk_combos gets dc_refs' D4 fix ──────────
// remapAllowedDiskCombos carried the SAME shape D4 fixed on remapDcRefs — the
// ALL-tables idMap and a `String()` coercion before the lookup — because it was
// written first and remapDcRefs copied it verbatim before D4 corrected the copy.
describe('a clone remaps an allowed_disk_combos restriction the same way dc_refs is remapped (fmb-1566)', () => {
  async function seedLocalComboAndProfile() {
    const combo = await call(ADMIN, 'POST',
      `/edge/app/capacity/scenarios/${SCENARIO_ID}/local-catalogues/disk_combos`, { name: 'combo-local' });
    assert.equal(combo.status, 200, `the combo fixture was refused: ${JSON.stringify(combo.body)}`);
    return combo.body.data.id;
  }
  const cloneComboIdByName = (cloneId, name) => one(
    `SELECT id FROM \`${tbl('cap_disk_combos')}\` WHERE scenario_id = ? AND name = ?`, [cloneId, name],
  );
  const cloneProfileAllowedCombos = async (cloneId) => {
    const row = await one(
      `SELECT allowed_disk_combos FROM \`${tbl('cap_vm_profiles')}\` WHERE scenario_id = ?`, [cloneId],
    );
    if (!row || row.allowed_disk_combos == null) return null;
    return typeof row.allowed_disk_combos === 'string'
      ? JSON.parse(row.allowed_disk_combos) : row.allowed_disk_combos;
  };

  test('a live combo reference points at the clone\'s combo, not the source\'s', async (t) => {
    if (guard(t)) return;
    const comboId = await seedLocalComboAndProfile();
    const profile = await call(ADMIN, 'POST',
      `/edge/app/capacity/scenarios/${SCENARIO_ID}/local-catalogues/vm_profiles`,
      { class: 'DB', name: 'profile-local', mode: 'formula', cpu: 8, allowed_disk_combos: [comboId] });
    assert.equal(profile.status, 200, `the profile fixture was refused: ${JSON.stringify(profile.body)}`);

    const cloned = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/clone`,
      { name: 'a clone' });
    assert.equal(cloned.status, 201, `the clone was refused: ${JSON.stringify(cloned.body)}`);
    const cloneId = cloned.body.data.id;

    const cloneCombo = (await cloneComboIdByName(cloneId, 'combo-local')).id;
    assert.notEqual(cloneCombo, comboId, 'the premise fails: the clone reused the source combo id');
    assert.deepEqual(await cloneProfileAllowedCombos(cloneId), [cloneCombo],
      'the clone carried the source combo id into an allow-list naming a combo that does not exist in it');
  });

  // The old remap coerced every element with `String()` before the lookup:
  // `String([comboId])` drops the brackets, so a single-element nested array
  // happens to stringify to the combo id itself, hits the map, and is REPLACED
  // by the clone's scalar combo id — an element that was never a live reference
  // becomes one.
  test('a nested-array entry survives the clone byte-for-byte, not flattened or remapped', async (t) => {
    if (guard(t)) return;
    const comboId = await seedLocalComboAndProfile();
    const nested = [[comboId]];
    const profile = await call(ADMIN, 'POST',
      `/edge/app/capacity/scenarios/${SCENARIO_ID}/local-catalogues/vm_profiles`,
      { class: 'DB', name: 'profile-local', mode: 'formula', cpu: 8, allowed_disk_combos: nested });
    assert.equal(profile.status, 200, `the profile fixture was refused: ${JSON.stringify(profile.body)}`);

    const cloned = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/clone`,
      { name: 'a clone' });
    assert.equal(cloned.status, 201, `the clone was refused: ${JSON.stringify(cloned.body)}`);
    const cloneId = cloned.body.data.id;

    assert.deepEqual(await cloneProfileAllowedCombos(cloneId), nested,
      'the nested array stringified down to the combo id, matched the combo map, and was replaced by the '
      + "clone's scalar combo id instead of surviving verbatim");
  });

  // The old remap resolved every element through the SAME idMap Phase 1 builds
  // for every cloned table, not a disk_combos-only submap. An allow-list entry
  // only ever names a combo, so a dangling entry that happens to equal some
  // OTHER table's source id must still be left verbatim.
  test('a dangling entry equal to another table\'s source id is not remapped through it', async (t) => {
    if (guard(t)) return;
    const site = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/sites`, { name: 'DC-A' });
    assert.equal(site.status, 200, `the site fixture was refused: ${JSON.stringify(site.body)}`);
    const siteId = site.body.data.id;

    const profile = await call(ADMIN, 'POST',
      `/edge/app/capacity/scenarios/${SCENARIO_ID}/local-catalogues/vm_profiles`,
      { class: 'DB', name: 'profile-local', mode: 'formula', cpu: 8, allowed_disk_combos: [siteId] });
    assert.equal(profile.status, 200, `the profile fixture was refused: ${JSON.stringify(profile.body)}`);

    const cloned = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/clone`,
      { name: 'a clone' });
    assert.equal(cloned.status, 201, `the clone was refused: ${JSON.stringify(cloned.body)}`);
    const cloneId = cloned.body.data.id;

    assert.deepEqual(await cloneProfileAllowedCombos(cloneId), [siteId],
      'the dangling entry happened to equal a source site id, and the all-tables idMap rewrote it to the '
      + "clone site's own id instead of leaving it verbatim");
  });
});

// ── fmb-1566 item 4a: a vm_profile write canonicalises its allow-list ──────────
// diskComboAllowed judges an ALREADY-canonicalised disk_combo_id (the §17.1a
// scalar-FK validator rewrites it to the combo's own spelling) with a byte
// `.includes` against allowed_disk_combos. Before this fix nothing canonicalised
// the allow-list's OWN entries, so a case-variant combo id written into it
// silently refused a combo the operator meant to permit — the same spelling
// disagreement D4 measured on dc_refs, on the other side of the comparison.
describe('a vm_profile write canonicalises its allow-list to the combo\'s own spelling', () => {
  const profileAllowedCombos = async (profileId) => {
    const row = await one(
      `SELECT allowed_disk_combos FROM \`${tbl('cap_vm_profiles')}\` WHERE id = ?`, [profileId],
    );
    if (!row || row.allowed_disk_combos == null) return null;
    return typeof row.allowed_disk_combos === 'string'
      ? JSON.parse(row.allowed_disk_combos) : row.allowed_disk_combos;
  };

  test('the global /config/vm_profiles mount rewrites a case-variant entry on create', async (t) => {
    if (guard(t)) return;
    const combo = await call(ADMIN, 'POST', '/edge/app/capacity/config/disk_combos', { name: 'combo-g' });
    assert.equal(combo.status, 201, `the combo fixture was refused: ${JSON.stringify(combo.body)}`);
    const comboId = combo.body.data.id;
    const variant = comboId.toUpperCase();
    assert.notEqual(variant, comboId, 'premise fails: the id has no letters to case-vary');

    const profile = await call(ADMIN, 'POST', '/edge/app/capacity/config/vm_profiles',
      { class: 'DB', name: 'profile-g', mode: 'formula', cpu: 8, allowed_disk_combos: [variant] });
    assert.equal(profile.status, 201, `the profile fixture was refused: ${JSON.stringify(profile.body)}`);

    assert.deepEqual(await profileAllowedCombos(profile.body.data.id), [comboId],
      "the allow-list kept the caller's spelling instead of the combo's own");
  });

  test('the local-catalogues mount rewrites on create, and the write path then accepts the combo', async (t) => {
    if (guard(t)) return;
    const combo = await call(ADMIN, 'POST',
      `/edge/app/capacity/scenarios/${SCENARIO_ID}/local-catalogues/disk_combos`, { name: 'combo-local' });
    assert.equal(combo.status, 200, `the combo fixture was refused: ${JSON.stringify(combo.body)}`);
    const comboId = combo.body.data.id;
    const variant = comboId.toUpperCase();
    assert.notEqual(variant, comboId, 'premise fails: the id has no letters to case-vary');

    const profile = await call(ADMIN, 'POST',
      `/edge/app/capacity/scenarios/${SCENARIO_ID}/local-catalogues/vm_profiles`,
      { class: 'DB', name: 'profile-local', mode: 'formula', cpu: 8, allowed_disk_combos: [variant] });
    assert.equal(profile.status, 200, `the profile fixture was refused: ${JSON.stringify(profile.body)}`);
    const profileId = profile.body.data.id;

    assert.deepEqual(await profileAllowedCombos(profileId), [comboId],
      "the allow-list kept the caller's spelling instead of the combo's own");

    // Closing the loop: a VM naming this profile + the combo's OWN spelling must
    // be ACCEPTED. Before the fix the allow-list still held the caller's UPPER
    // variant and diskComboAllowed's byte .includes refused a combo the operator
    // had just been told was permitted.
    const vm = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/vms`,
      { name: 'kvm1', vm_type: 'db_host', sizing_profile_id: profileId, disk_combo_id: comboId });
    assert.equal(vm.status, 200, `expected the combo to be allowed: ${JSON.stringify(vm.body)}`);
  });

  test('an entry naming no combo survives byte-for-byte (the allow-list stays a soft, unvalidated list)', async (t) => {
    if (guard(t)) return;
    const DANGLING = '00000000-0000-4000-8000-0000000000ab';
    const profile = await call(ADMIN, 'POST', '/edge/app/capacity/config/vm_profiles',
      { class: 'DB', name: 'profile-dangling', mode: 'formula', cpu: 8, allowed_disk_combos: [DANGLING] });
    assert.equal(profile.status, 201, `the profile fixture was refused: ${JSON.stringify(profile.body)}`);

    assert.deepEqual(await profileAllowedCombos(profile.body.data.id), [DANGLING],
      'an entry naming no combo was dropped or rewritten instead of surviving verbatim');
  });

  test('a PUT that does not touch allowed_disk_combos leaves a stored value unchanged', async (t) => {
    if (guard(t)) return;
    const combo = await call(ADMIN, 'POST', '/edge/app/capacity/config/disk_combos', { name: 'combo-put' });
    assert.equal(combo.status, 201, `the combo fixture was refused: ${JSON.stringify(combo.body)}`);
    const comboId = combo.body.data.id;
    const profile = await call(ADMIN, 'POST', '/edge/app/capacity/config/vm_profiles',
      { class: 'DB', name: 'profile-put', mode: 'formula', cpu: 8, allowed_disk_combos: [comboId] });
    assert.equal(profile.status, 201, `the profile fixture was refused: ${JSON.stringify(profile.body)}`);
    const profileId = profile.body.data.id;

    const put = await call(ADMIN, 'PUT', `/edge/app/capacity/config/vm_profiles/${profileId}`, { name: 'renamed' });
    assert.equal(put.status, 200, `the PUT was refused: ${JSON.stringify(put.body)}`);

    assert.deepEqual(await profileAllowedCombos(profileId), [comboId],
      'a PUT that never named allowed_disk_combos still touched it');
  });
});

// ── an allowed_disk_combos write is bounded by entry count (D5 review finding 1)
//
// makeAllowedDiskCombosCanonicalizer resolves each distinct string entry with
// one awaited SELECT inside the write transaction, one at a time, under the
// row locks the write already holds — the sibling of makeDcRefsCanonicalizer,
// which this same suite already bounds (MAX_DC_REFS_ENTRIES). Unbounded, a
// write-capable caller can send thousands of entries and hold those locks for
// as long as they take to resolve.
describe('an allowed_disk_combos write is bounded by entry count', () => {
  const { MAX_ALLOWED_DISK_COMBOS_ENTRIES } = require('../../src/edge/routes/app/capacity/_shared');
  const profileAllowedCombos = async (profileId) => {
    const row = await one(
      `SELECT allowed_disk_combos FROM \`${tbl('cap_vm_profiles')}\` WHERE id = ?`, [profileId],
    );
    if (!row || row.allowed_disk_combos == null) return null;
    return typeof row.allowed_disk_combos === 'string'
      ? JSON.parse(row.allowed_disk_combos) : row.allowed_disk_combos;
  };
  const filler = (n) => Array.from({ length: n }, (_, i) => `zz-not-a-combo-${i}`);

  test(`the global /config/vm_profiles mount refuses ${MAX_ALLOWED_DISK_COMBOS_ENTRIES + 1} entries, nothing lands`, async (t) => {
    if (guard(t)) return;
    const res = await call(ADMIN, 'POST', '/edge/app/capacity/config/vm_profiles', {
      class: 'DB', name: 'profile-overcap', mode: 'formula', cpu: 8,
      allowed_disk_combos: filler(MAX_ALLOWED_DISK_COMBOS_ENTRIES + 1),
    });
    assert.equal(res.status, 400, `expected a refusal, got ${JSON.stringify(res.body)}`);
    assert.equal(
      await countOf(`SELECT COUNT(*) AS n FROM \`${tbl('cap_vm_profiles')}\` WHERE name = 'profile-overcap'`), 0,
      'a write over the cap still landed a row',
    );
  });

  test(`the local-catalogues vm_profiles mount refuses ${MAX_ALLOWED_DISK_COMBOS_ENTRIES + 1} entries, nothing lands`, async (t) => {
    if (guard(t)) return;
    const res = await call(ADMIN, 'POST',
      `/edge/app/capacity/scenarios/${SCENARIO_ID}/local-catalogues/vm_profiles`, {
        class: 'DB', name: 'profile-overcap-local', mode: 'formula', cpu: 8,
        allowed_disk_combos: filler(MAX_ALLOWED_DISK_COMBOS_ENTRIES + 1),
      });
    assert.equal(res.status, 400, `expected a refusal, got ${JSON.stringify(res.body)}`);
    assert.equal(
      await countOf(
        `SELECT COUNT(*) AS n FROM \`${tbl('cap_vm_profiles')}\` WHERE name = 'profile-overcap-local'`,
      ), 0,
      'a write over the cap still landed a row',
    );
  });

  test(`a write of exactly ${MAX_ALLOWED_DISK_COMBOS_ENTRIES} entries passes and still canonicalises`, async (t) => {
    if (guard(t)) return;
    const combo = await call(ADMIN, 'POST', '/edge/app/capacity/config/disk_combos', { name: 'combo-cap' });
    assert.equal(combo.status, 201, `the combo fixture was refused: ${JSON.stringify(combo.body)}`);
    const comboId = combo.body.data.id;
    const entries = filler(MAX_ALLOWED_DISK_COMBOS_ENTRIES - 1).concat(comboId.toUpperCase());
    assert.equal(entries.length, MAX_ALLOWED_DISK_COMBOS_ENTRIES, 'the fixture is not sized at the cap');

    const profile = await call(ADMIN, 'POST', '/edge/app/capacity/config/vm_profiles', {
      class: 'DB', name: 'profile-atcap', mode: 'formula', cpu: 8, allowed_disk_combos: entries,
    });
    assert.equal(profile.status, 201, `a write at the cap was refused: ${JSON.stringify(profile.body)}`);

    const stored = await profileAllowedCombos(profile.body.data.id);
    assert.equal(stored.length, MAX_ALLOWED_DISK_COMBOS_ENTRIES);
    assert.equal(stored[stored.length - 1], comboId,
      'a write at the cap stored the caller\'s spelling instead of the combo\'s own');
  });
});

// ── item 5: cap_rules.params.site_id survives a clone as a dangling copy ───────
// A keep-in-one-site rule's params carries a nested site_id the evaluator reads
// directly (shared/capacity/evaluator.js). The clone copied cap_rules.params
// verbatim, so a cloned rule went on pinning the SOURCE scenario's site —
// census-invisible (nested JSON) and documented in site-references.js's own top
// note as outside the site-DELETE sweep for the identical reason.
describe('a clone remaps a keep-in-one-site rule\'s pinned site_id (item 5)', () => {
  const cloneRuleParams = async (cloneId) => {
    const row = await one(
      `SELECT params FROM \`${tbl('cap_rules')}\` WHERE scenario_id = ? AND type = 'keep-in-one-site'`,
      [cloneId],
    );
    if (!row || row.params == null) return null;
    return typeof row.params === 'string' ? JSON.parse(row.params) : row.params;
  };

  test('the pinned site_id points at the clone\'s own site, not the source\'s', async (t) => {
    if (guard(t)) return;
    const site = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/sites`, { name: 'DC-A' });
    assert.equal(site.status, 200, `the site fixture was refused: ${JSON.stringify(site.body)}`);
    const siteId = site.body.data.id;

    const rule = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/rules`, {
      type: 'keep-in-one-site', name: 'pinned', level: 'db_instance', group_by: 'each_primary_cluster',
      params: { site_id: siteId }, severity: 'hard', enabled: true,
    });
    assert.equal(rule.status, 200, `the rule fixture was refused: ${JSON.stringify(rule.body)}`);

    const cloned = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/clone`,
      { name: 'a clone' });
    assert.equal(cloned.status, 201, `the clone was refused: ${JSON.stringify(cloned.body)}`);
    const cloneId = cloned.body.data.id;

    const cloneSite = await one(
      `SELECT id FROM \`${tbl('cap_sites')}\` WHERE scenario_id = ? AND name = ?`, [cloneId, 'DC-A'],
    );
    assert.notEqual(cloneSite.id, siteId, 'the premise fails: the clone reused the source site id');
    assert.deepEqual(await cloneRuleParams(cloneId), { site_id: cloneSite.id },
      'the clone carried the source site id into a rule that now pins a site that does not exist in it');
  });

  test('a site_id naming no site (already dangling in the source) survives the clone verbatim', async (t) => {
    if (guard(t)) return;
    const DANGLING = '00000000-0000-4000-8000-0000000000ab';
    // Straight to the column: the /rules mount now REJECTS a pin at a site that
    // does not exist (makeRuleSitePinLockValidator, fmb-1538), so a dangling pin can
    // only be a PRE-FIX / imported row. The clone must still carry it verbatim (it
    // remaps only pins that resolve in the source's own sites).
    await q(
      `INSERT INTO \`${tbl('cap_rules')}\` (id, scenario_id, type, name, level, group_by, params, severity, enabled)`
      + ' VALUES (UUID(), ?, ?, ?, ?, ?, ?, ?, 1)',
      [SCENARIO_ID, 'keep-in-one-site', 'pinned-dangling', 'db_instance', 'each_primary_cluster',
        JSON.stringify({ site_id: DANGLING }), 'hard'],
    );

    const cloned = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/clone`,
      { name: 'a clone' });
    assert.equal(cloned.status, 201, `the clone was refused: ${JSON.stringify(cloned.body)}`);
    const cloneId = cloned.body.data.id;

    assert.deepEqual(await cloneRuleParams(cloneId), { site_id: DANGLING },
      'a dangling site_id was dropped or rewritten instead of surviving verbatim');
  });

  test('other params keys and other rule types are unaffected', async (t) => {
    if (guard(t)) return;
    const rule = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/rules`, {
      type: 'max-vms-per-host', name: 'unrelated', level: 'hypervisor', group_by: 'all_of_type',
      params: { max: 8 }, severity: 'hard', enabled: true,
    });
    assert.equal(rule.status, 200, `the rule fixture was refused: ${JSON.stringify(rule.body)}`);

    const cloned = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/clone`,
      { name: 'a clone' });
    assert.equal(cloned.status, 201, `the clone was refused: ${JSON.stringify(cloned.body)}`);
    const cloneId = cloned.body.data.id;

    const row = await one(
      `SELECT params FROM \`${tbl('cap_rules')}\` WHERE scenario_id = ? AND type = 'max-vms-per-host'`,
      [cloneId],
    );
    const params = typeof row.params === 'string' ? JSON.parse(row.params) : row.params;
    assert.deepEqual(params, { max: 8 }, 'a rule with no site_id key was touched by the site_id remap');
  });
});
