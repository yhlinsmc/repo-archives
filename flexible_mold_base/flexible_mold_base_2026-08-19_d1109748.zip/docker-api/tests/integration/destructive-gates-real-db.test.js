'use strict';

/**
 * destructive-gates-real-db.test.js — the gates in front of the statements that
 * DELETE and RELABEL, on a real database, reading the stored rows back.
 *
 * WHY A REAL DATABASE IS THE ONLY INSTRUMENT THAT SETTLES THESE. Every case in
 * this file is a claim about WHICH ROWS A STATEMENT MATCHED — which is the one
 * question a mocked driver answers with whatever the fixture was told to say.
 * That is how this family survived several previous reviews. So every case here
 * asserts a STORED VALUE or a ROW COUNT; a status code alone is never the
 * assertion where the row is about data.
 *
 * What each block settles:
 *
 *   row 2  — a move whose destination is the row being deleted, spelt in another
 *            case: the fields are relabelled onto a lane the same transaction
 *            then removes, in the groups lane and the sections lane alike.
 *   row 29 — a rename keyed on the key rather than on the row the gate locked
 *            and approved, collapsing two lanes onto one key on a database
 *            whose UNIQUE index was never created.
 *   row 5  — the sections reconcile dropping a key its fields still name, which
 *            the groups reconcile has always refused.
 *   row 7  — a hand-rolled cascade choosing its children from an unlocked
 *            snapshot, deleting them, and then re-evaluating its own predicate:
 *            a field that leaves the section keeps its row and loses its
 *            options.
 *   rows 20, 21, 22 — two option values the column calls one value; a stored
 *            field type outside the declared domain deciding which guard runs;
 *            and an option row carrying the caller's spelling of its parent id
 *            rather than the field's own.
 *   row 30 — a residual judged against one of two field rows that share a key,
 *            with the scanner and the deleter picking different ones.
 *
 * Each block also carries the controls for its own fix: what the gate must NOT
 * refuse, and what the repair must still do. A fix that closed every case above
 * by refusing everything would be indistinguishable from one that works without
 * them.
 *
 * Skips with a stated reason when no database is reachable, and FAILS instead of
 * skipping when REQUIRE_INTEGRATION_DB=1 — a silent skip is the failure mode
 * this whole line of work exists to end.
 */
const { test, describe, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const net = require('node:net');
const http = require('node:http');
const express = require('express');
const mariadb = require('mariadb');

const TEST_PREFIX = 'dgt_';
const tbl = (name) => `${TEST_PREFIX}${name}`;

let pool = null;
const lease = () => pool.getConnection();

const dbKey = require.resolve('../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey,
  filename: dbKey,
  loaded: true,
  exports: {
    pool: { ro: { getConnection: lease }, rw: { getConnection: lease } },
    t: tbl,
    getDynamicPool: async () => ({ ro: { getConnection: lease }, rw: { getConnection: lease } }),
  },
};

const { buildEngineTableDDLs, buildInfraTableDDLs } = require('../../src/table-ddls');
const schemaRouter = require('../../src/edge/routes/app/schema');
const { fixtureUserId } = require('../helpers/fixture-ids');
const { MAX_REPLACE_OPTIONS } = require('../../src/edge/routes/app/schema/helpers');

// ── Config auto-detection (same shape as the sibling integration tests) ──────

function parseEnvFile(filePath) {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    const out = {};
    for (const line of content.split('\n')) {
      const m = line.match(/^\s*([A-Z_][A-Z0-9_]*)\s*=\s*(.*)\s*$/);
      if (!m) continue;
      let value = m[2];
      if ((value.startsWith('"') && value.endsWith('"'))
        || (value.startsWith("'") && value.endsWith("'"))) {
        value = value.slice(1, -1);
      }
      out[m[1]] = value;
    }
    return out;
  } catch {
    return null;
  }
}

function probePort(host, port, timeoutMs = 2000) {
  return new Promise((resolve) => {
    const socket = new net.Socket();
    let done = false;
    const finish = (ok) => {
      if (done) return;
      done = true;
      socket.destroy();
      resolve(ok);
    };
    socket.setTimeout(timeoutMs);
    socket.once('connect', () => finish(true));
    socket.once('timeout', () => finish(false));
    socket.once('error', () => finish(false));
    socket.connect(port, host);
  });
}

async function resolveMariaDbConfig() {
  if (process.env.DB_TEST_HOST && process.env.DB_TEST_ROOT_PASSWORD) {
    return {
      host: process.env.DB_TEST_HOST,
      port: parseInt(process.env.DB_TEST_PORT || '3306', 10),
      user: 'root',
      password: process.env.DB_TEST_ROOT_PASSWORD,
    };
  }
  const envPath = path.resolve(__dirname, '../../../.devcontainer/.env');
  const env = parseEnvFile(envPath);
  if (!env || !env.DB_ROOT_PASSWORD) return null;
  const port = parseInt(env.DB_PORT || '3306', 10);
  for (const host of ['127.0.0.1', 'mariadb', 'localhost']) {
    if (await probePort(host, port, 2000)) {
      return { host, port, user: 'root', password: env.DB_ROOT_PASSWORD };
    }
  }
  return null;
}

// ── Fixture ─────────────────────────────────────────────────────────────────

const ADMIN = { id: fixtureUserId('admin'), role: 'admin' };
const EDITOR = { id: fixtureUserId('editor'), role: 'editor' };

// Lower-case canonical spellings; the case-fold cases send the upper-case form
// of the SAME id, which the column's collation calls one value and JavaScript
// calls two.
const BP = 'c0ffee00-1111-4222-8333-000000000001';
const FIELD_A = 'f1e2d3c4-2222-4222-8333-00000000000a';
const FIELD_B = 'f1e2d3c4-2222-4222-8333-00000000000b';
const VARIANT = 'c0ffee00-1111-4222-8333-000000000002';

let dbConfigMemo = null;
let dbReady = false;
let skipReason = null;
let testDbName = null;
let server = null;
let baseUrl = null;
let currentUser = ADMIN;

before(async () => {
  dbConfigMemo = await resolveMariaDbConfig();
  if (!dbConfigMemo) {
    skipReason = 'no MariaDB reachable via .devcontainer/.env or env vars';
    if (process.env.REQUIRE_INTEGRATION_DB === '1') {
      throw new Error(`REQUIRE_INTEGRATION_DB=1 set but ${skipReason}.`);
    }
    return;
  }
  testDbName = `destructive_gates_test_${process.pid}_${Date.now()}`;
  let admin = null;
  try {
    admin = await mariadb.createConnection({ ...dbConfigMemo, connectTimeout: 5000 });
    await admin.query(`CREATE DATABASE \`${testDbName}\``);
    await admin.query(`USE \`${testDbName}\``);
    // Every table, built from the DDL that creates the real ones — a hand-picked
    // subset drops a table some guard probes and turns its refusal into a
    // degrade nobody asked for.
    for (const sql of [...buildInfraTableDDLs(tbl), ...buildEngineTableDDLs(tbl)]) {
      await admin.query(sql);
    }
    await admin.end();
    admin = null;

    pool = mariadb.createPool({
      ...dbConfigMemo, database: testDbName, connectionLimit: 6, connectTimeout: 5000,
    });

    const app = express();
    // The deployed limit (index-edge.js), not express's 100kb default: one case
    // here sends the honest echo of a field carrying more options than the bound
    // allows, and under the default that body is rejected by the parser — so the
    // route's own answer, which is what the case is about, would never be read.
    app.use(express.json({ limit: '10mb' }));
    app.use((req, _res, next) => { req.user = currentUser; next(); });
    app.use('/edge/app/schema', schemaRouter);
    server = http.createServer(app);
    await new Promise((r) => server.listen(0, r));
    baseUrl = `http://127.0.0.1:${server.address().port}`;
    dbReady = true;
  } catch (err) {
    skipReason = `setup failed: ${err.message}`;
    if (admin) { try { await admin.end(); } catch { /* best effort */ } }
    if (process.env.REQUIRE_INTEGRATION_DB === '1') throw err;
  }
});

after(async () => {
  if (server) { try { server.close(); } catch { /* best effort */ } }
  if (pool) { try { await pool.end(); } catch { /* best effort */ } }
  if (!testDbName || !dbConfigMemo) return;
  try {
    const admin = await mariadb.createConnection({ ...dbConfigMemo, connectTimeout: 5000 });
    await admin.query(`DROP DATABASE IF EXISTS \`${testDbName}\``);
    await admin.end();
  } catch { /* best effort */ }
});

async function call(user, method, url, body) {
  currentUser = user;
  const res = await fetch(`${baseUrl}${url}`, {
    method,
    headers: { 'content-type': 'application/json' },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const text = await res.text();
  let parsed = null;
  try { parsed = JSON.parse(text); } catch { parsed = { raw: text }; }
  return { status: res.status, body: parsed };
}

const post = (user, url, body) => call(user, 'POST', url, body);

const rows = (sql, params) => pool.query(sql, params);
const one = async (sql, params) => (await pool.query(sql, params))[0];
const countOf = async (sql, params) => Number((await one(sql, params)).n);

const groupRows = () => rows(
  `SELECT id, group_key, display_label, color_key FROM \`${tbl('blueprint_groups')}\`
    WHERE blueprint_id = ? ORDER BY group_key`, [BP],
);
const sectionRows = () => rows(
  `SELECT id, section_key, display_label, sort_order FROM \`${tbl('blueprint_sections')}\`
    WHERE blueprint_id = ? ORDER BY section_key`, [BP],
);
const fieldRows = () => rows(
  `SELECT id, field_key, section, group_key, matrix_row_key, field_type
     FROM \`${tbl('blueprint_fields')}\` WHERE blueprint_id = ? ORDER BY field_key`, [BP],
);

const guard = (t) => {
  if (!dbReady) { t.skip(skipReason || 'database not ready'); return true; }
  return false;
};

/** Clear every table this file writes to, so each case states its own pre-state. */
beforeEach(async () => {
  if (!dbReady) return;
  for (const name of ['field_options', 'variant_overrides', 'blueprint_fields',
    'blueprint_groups', 'blueprint_sections', 'user_templates', 'hierarchy_nodes',
    'feature_audit']) {
    await pool.query(`DELETE FROM \`${tbl(name)}\``);
  }
  await pool.query(
    `INSERT INTO \`${tbl('hierarchy_nodes')}\` (id, name, node_type, owner_id)
     VALUES (?, 'bp', 'blueprint', ?), (?, 'variant', 'variant', ?)`,
    [BP, EDITOR.id, VARIANT, EDITOR.id],
  );
});

async function seedGroup(groupKey, extra = {}) {
  const row = {
    id: extra.id || undefined,
    blueprint_id: BP,
    group_key: groupKey,
    display_label: extra.display_label ?? `label-${groupKey}`,
    color_key: extra.color_key ?? `color-${groupKey}`,
    sort_order: extra.sort_order ?? 1,
  };
  if (row.id === undefined) delete row.id;
  const columns = Object.keys(row);
  await pool.query(
    `INSERT INTO \`${tbl('blueprint_groups')}\` (${columns.map((c) => `\`${c}\``).join(', ')})
     VALUES (${columns.map(() => '?').join(', ')})`,
    columns.map((c) => row[c]),
  );
}

async function seedSection(sectionKey, extra = {}) {
  const row = {
    blueprint_id: BP,
    section_key: sectionKey,
    display_label: extra.display_label ?? `label-${sectionKey}`,
    sort_order: extra.sort_order ?? 1,
  };
  const columns = Object.keys(row);
  await pool.query(
    `INSERT INTO \`${tbl('blueprint_sections')}\` (${columns.map((c) => `\`${c}\``).join(', ')})
     VALUES (${columns.map(() => '?').join(', ')})`,
    columns.map((c) => row[c]),
  );
}

async function seedField(overrides = {}) {
  const row = {
    id: FIELD_A,
    blueprint_id: BP,
    field_key: 'city',
    field_label: 'City',
    field_type: 'text',
    ...overrides,
  };
  const columns = Object.keys(row);
  await pool.query(
    `INSERT INTO \`${tbl('blueprint_fields')}\` (${columns.map((c) => `\`${c}\``).join(', ')})
     VALUES (${columns.map(() => '?').join(', ')})`,
    columns.map((c) => row[c]),
  );
  return row;
}

// ── T8 — the target and the source are the same question the database answers
//        (row 2: C-02 groups, C-03 sections) ─────────────────────────────────

describe('a delete whose destination is the row being deleted', () => {
  test('moving a lane onto its own key in another case is refused, and the lane survives',
    async (t) => {
      if (guard(t)) return;
      // ROW 2 (C-02). `target_group_key !== group_key` is a JavaScript
      // comparison; both lock SELECTs below resolve `WHERE group_key = ?` under
      // the column's collation, so 'Lane_A' and 'lane_a' find the SAME ROW and
      // both "does it exist" checks pass. The UPDATE then relabels every field
      // to the target spelling and the DELETE removes the only group row there
      // ever was — 200 `{ok:true}`, and every field now names a lane that does
      // not exist. The assertion is the surviving row count and the fields'
      // stored key, not the status.
      await seedGroup('lane_a');
      await seedField({ id: FIELD_A, field_key: 'city', group_key: 'lane_a' });
      await seedField({ id: FIELD_B, field_key: 'zone', group_key: 'lane_a' });

      const res = await post(ADMIN, '/edge/app/schema/blueprint_groups/delete-with-reassign', {
        blueprint_id: BP, group_key: 'lane_a', action: 'move', target_group_key: 'Lane_A',
      });

      const groups = await groupRows();
      assert.equal(
        groups.length, 1,
        `the only group row was deleted while its fields were moved onto it (HTTP ${res.status})`,
      );
      assert.equal(groups[0].group_key, 'lane_a', 'the surviving group row was respelt');
      const fields = await fieldRows();
      assert.deepEqual(
        fields.map((f) => f.group_key), ['city', 'zone'].map(() => 'lane_a'),
        'the fields were relabelled onto a lane that no longer exists',
      );
    });

  test('deleting a section onto its own key in another case is refused, and the section survives',
    async (t) => {
      if (guard(t)) return;
      // ROW 2 (C-03), the mirror. Same gate, same collation, and the section's
      // metadata row — its label, icon, description and order — is what the
      // DELETE removes while the fields are pointed at the spelling it held.
      await seedSection('overview');
      await seedField({ id: FIELD_A, field_key: 'city', section: 'overview' });

      const res = await post(ADMIN, '/edge/app/schema/blueprint_sections/delete-with-reassign', {
        blueprint_id: BP, section_key: 'overview', action: 'move', target_section: 'Overview',
      });

      const sections = await sectionRows();
      assert.equal(
        sections.length, 1,
        `the only section row was deleted while its fields were moved onto it (HTTP ${res.status})`,
      );
      assert.equal(sections[0].section_key, 'overview', 'the surviving section row was respelt');
      assert.equal(
        (await fieldRows())[0].section, 'overview',
        'the field was relabelled onto a section that no longer exists',
      );
    });

  test('a genuine move between two lanes still lands', async (t) => {
    if (guard(t)) return;
    // The control. A gate that refuses the case above by refusing every move
    // would satisfy the two cases above and remove the feature.
    await seedGroup('lane_a');
    await seedGroup('lane_b');
    await seedField({ id: FIELD_A, field_key: 'city', group_key: 'lane_a' });

    const res = await post(ADMIN, '/edge/app/schema/blueprint_groups/delete-with-reassign', {
      blueprint_id: BP, group_key: 'lane_a', action: 'move', target_group_key: 'lane_b',
    });
    assert.equal(res.status, 200, `a legitimate move was refused: ${JSON.stringify(res.body)}`);

    const groups = await groupRows();
    assert.deepEqual(groups.map((g) => g.group_key), ['lane_b'], 'the target lane did not survive');
    assert.equal((await fieldRows())[0].group_key, 'lane_b', 'the field did not move');
  });

  test('a genuine section move still lands', async (t) => {
    if (guard(t)) return;
    await seedSection('overview');
    await seedSection('details');
    await seedField({ id: FIELD_A, field_key: 'city', section: 'overview' });

    const res = await post(ADMIN, '/edge/app/schema/blueprint_sections/delete-with-reassign', {
      blueprint_id: BP, section_key: 'overview', action: 'move', target_section: 'details',
    });
    assert.equal(res.status, 200, `a legitimate move was refused: ${JSON.stringify(res.body)}`);

    const sections = await sectionRows();
    assert.deepEqual(sections.map((s) => s.section_key), ['details'], 'the target section did not survive');
    assert.equal((await fieldRows())[0].section, 'details', 'the field did not move');
  });

  test('clearing a lane, which names no target at all, still lands', async (t) => {
    if (guard(t)) return;
    // The other action on the same endpoint: `clear` never names a target, so
    // the new gate must not have anything to say about it.
    await seedGroup('lane_a');
    await seedField({ id: FIELD_A, field_key: 'city', group_key: 'lane_a' });

    const res = await post(ADMIN, '/edge/app/schema/blueprint_groups/delete-with-reassign', {
      blueprint_id: BP, group_key: 'lane_a', action: 'clear',
    });
    assert.equal(res.status, 200, `a legitimate clear was refused: ${JSON.stringify(res.body)}`);
    assert.equal((await groupRows()).length, 0, 'the cleared lane row survived');
    assert.equal((await fieldRows())[0].group_key, '', 'the field was not ungrouped');
  });
});

describe('the order the new gates run in', () => {
  const OTHER_BP = 'c0ffee00-1111-4222-8333-00000000000e';

  async function seedOtherOwnedBlueprint() {
    await pool.query(
      `INSERT INTO \`${tbl('hierarchy_nodes')}\` (id, name, node_type, owner_id)
       VALUES (?, 'theirs', 'blueprint', ?)`,
      [OTHER_BP, ADMIN.id],
    );
    await pool.query(
      `INSERT INTO \`${tbl('blueprint_groups')}\` (id, blueprint_id, group_key, display_label)
       VALUES (UUID(), ?, 'lane_a', 'Theirs')`,
      [OTHER_BP],
    );
  }

  test('an editor who may not write the blueprint is refused before the new gate speaks',
    async (t) => {
      if (guard(t)) return;
      // The engine-resolved "is the target the row being deleted" gate needs a
      // connection, so it moved from before the transaction to inside it. That
      // puts it downstream of the ownership check, which is the order it must
      // keep: a caller who cannot write this blueprint must not learn from the
      // shape of a refusal whether two of its lane keys are the same lane.
      await seedOtherOwnedBlueprint();

      const res = await post(EDITOR, '/edge/app/schema/blueprint_groups/delete-with-reassign', {
        blueprint_id: OTHER_BP, group_key: 'lane_a', action: 'move', target_group_key: 'Lane_A',
      });
      assert.equal(res.status, 403, `expected the ownership refusal, got ${JSON.stringify(res.body)}`);
      assert.equal(
        await countOf(
          `SELECT COUNT(*) AS n FROM \`${tbl('blueprint_groups')}\` WHERE blueprint_id = ?`,
          [OTHER_BP],
        ),
        1,
        'a refused request removed a lane row',
      );
    });

  test('a plain user reaches no gate at all', async (t) => {
    if (guard(t)) return;
    // The role that may not write schema at all is refused before any
    // connection is taken, so none of the new engine questions is even asked.
    await seedGroup('lane_a');

    const res = await post(
      { id: fixtureUserId('user'), role: 'user' },
      '/edge/app/schema/blueprint_groups/delete-with-reassign',
      { blueprint_id: BP, group_key: 'lane_a', action: 'move', target_group_key: 'Lane_A' },
    );
    assert.equal(res.status, 403, `expected a refusal, got ${JSON.stringify(res.body)}`);
    assert.equal((await groupRows()).length, 1, 'a refused request removed a lane row');
  });
});

// ── T9 — the rename UPDATE is bounded by the row the gate approved
//        (row 29: C-24) ──────────────────────────────────────────────────────

describe('a rename that acts on more rows than the gate approved', () => {
  test('two lanes the column already calls one key are not collapsed onto the new key',
    async (t) => {
      if (guard(t)) return;
      // ROW 29 (C-24). The gate locks ONE row and takes `targetRows[0].id`; the
      // UPDATE that follows was keyed on `group_key` and NOT on that id, so on a
      // database whose `uq_blueprint_group_key` was never created — the same
      // class of database every column probe in this handler exists for — the
      // statement acted on EVERY row the collation calls `lane_a`. Two lanes,
      // each with its own label and colour, came out holding one key: the second
      // lane's identity is destroyed and no later read can tell the two apart.
      const groupsTable = tbl('blueprint_groups');
      await pool.query(`ALTER TABLE \`${groupsTable}\` DROP INDEX uq_blueprint_group_key`);
      try {
        await seedGroup('lane_a', { display_label: 'First lane' });
        await seedGroup('Lane_A', { display_label: 'Second lane' });

        const res = await post(ADMIN, '/edge/app/schema/blueprint_groups/rename-with-cascade', {
          blueprint_id: BP, group_key: 'lane_a', new_group_key: 'zone_b',
        });

        const groups = await groupRows();
        assert.equal(groups.length, 2, 'a rename deleted a lane row');
        const renamed = groups.filter((g) => g.group_key === 'zone_b');
        assert.equal(
          renamed.length, 1,
          `the rename collapsed ${renamed.length} lane rows onto one key (HTTP ${res.status})`,
        );
        const survivor = groups.find((g) => g.group_key !== 'zone_b');
        assert.ok(
          ['lane_a', 'Lane_A'].includes(survivor.group_key),
          `the untouched lane now holds '${survivor.group_key}'`,
        );
        assert.deepEqual(
          groups.map((g) => g.display_label).sort(),
          ['First lane', 'Second lane'],
          'a lane lost the label that was the only thing telling it apart',
        );
      } finally {
        // The rows go before the index does: while the defect is live they are
        // the duplicate the index refuses, and an ALTER that throws here would
        // replace the assertion above with its own error.
        await pool.query(`DELETE FROM \`${groupsTable}\``);
        await pool.query(
          `ALTER TABLE \`${groupsTable}\` ADD UNIQUE KEY uq_blueprint_group_key (blueprint_id, group_key)`,
        );
      }
    });

  test('an ordinary rename still renames the lane and re-points every field', async (t) => {
    if (guard(t)) return;
    // The control. Binding the statement to the approved row must not stop the
    // rename landing, nor stop the cascade that is the whole reason this
    // endpoint exists.
    await seedGroup('lane_a');
    await seedField({ id: FIELD_A, field_key: 'city', group_key: 'lane_a' });
    await seedField({ id: FIELD_B, field_key: 'zone', matrix_row_key: 'lane_a' });

    const res = await post(ADMIN, '/edge/app/schema/blueprint_groups/rename-with-cascade', {
      blueprint_id: BP, group_key: 'lane_a', new_group_key: 'zone_b',
    });
    assert.equal(res.status, 200, `a legitimate rename was refused: ${JSON.stringify(res.body)}`);

    assert.deepEqual((await groupRows()).map((g) => g.group_key), ['zone_b']);
    const fields = await fieldRows();
    assert.equal(fields.find((f) => f.field_key === 'city').group_key, 'zone_b',
      'the lane membership did not follow the rename');
    assert.equal(fields.find((f) => f.field_key === 'zone').matrix_row_key, 'zone_b',
      'the matrix reference did not follow the rename');
  });

  test('a case-only renaming of one lane still stores the new spelling', async (t) => {
    if (guard(t)) return;
    // The control the duplicate case must not take away. A rename that changes
    // only capitalisation IS a rename — measured (db-semantics §Q1), the engine
    // stores the new spelling rather than absorbing it — and it is how a legacy
    // key is normalised. The gate excludes the row being renamed from its own
    // duplicate probe precisely so this stays legal.
    await seedGroup('Lane_A');
    await seedField({ id: FIELD_A, field_key: 'city', group_key: 'Lane_A' });

    const res = await post(ADMIN, '/edge/app/schema/blueprint_groups/rename-with-cascade', {
      blueprint_id: BP, group_key: 'Lane_A', new_group_key: 'lane_a',
    });
    assert.equal(res.status, 200, `a legitimate normalisation was refused: ${JSON.stringify(res.body)}`);

    assert.deepEqual((await groupRows()).map((g) => g.group_key), ['lane_a'],
      'the stored spelling did not move');
    assert.equal((await fieldRows())[0].group_key, 'lane_a',
      'the field kept the old spelling of a key that no longer exists');
  });
});

// ── T10 — the sections lane gets the reference check its mirror already has
//        (row 5: B70) ────────────────────────────────────────────────────────

describe('a replace that drops a key fields still name', () => {
  const sectionSnapshot = (key, label = `label-${key}`, sortOrder = 1) => ({
    section_key: key, display_label: label, sort_order: sortOrder,
  });
  const groupSnapshot = (key) => ({
    group_key: key, display_label: `label-${key}`, color_key: `color-${key}`, sort_order: 1,
  });

  test('a section still referenced by a field cannot be dropped', async (t) => {
    if (guard(t)) return;
    // ROW 5 (B70). The groups lane refuses to drop a `group_key` a field still
    // names; the sections lane — the same reconcile, the same reference by
    // string (`blueprint_fields.section` joins `blueprint_sections.section_key`)
    // — had no such check and deleted the row. What is destroyed is the
    // section's metadata: its label, icon, description, layout and order. The
    // field survives naming a section that now has none, which renders, so
    // nothing tells an operator the label they wrote is gone.
    await seedSection('overview', { display_label: 'Overview' });
    await seedField({ id: FIELD_A, field_key: 'city', section: 'overview' });

    const res = await post(ADMIN, '/edge/app/schema/blueprint_sections/replace', {
      blueprint_id: BP,
      expected: [sectionSnapshot('overview', 'Overview')],
      next: [],
    });

    const sections = await sectionRows();
    assert.equal(
      sections.length, 1,
      `a section a field still names was dropped (HTTP ${res.status})`,
    );
    assert.equal(sections[0].display_label, 'Overview', 'the section metadata was rewritten');
    assert.equal((await fieldRows())[0].section, 'overview',
      'the field no longer names the section it was in');
  });

  test('a section a field names in another case cannot be dropped either', async (t) => {
    if (guard(t)) return;
    // The same refusal, resolved the way the reference is resolved. A field
    // holding `Overview` is in the section `overview` to every predicate the
    // engine evaluates, so dropping the row still strands it.
    await seedSection('overview', { display_label: 'Overview' });
    await seedField({ id: FIELD_A, field_key: 'city', section: 'Overview' });

    const res = await post(ADMIN, '/edge/app/schema/blueprint_sections/replace', {
      blueprint_id: BP,
      expected: [sectionSnapshot('overview', 'Overview')],
      next: [],
    });

    assert.equal(
      (await sectionRows()).length, 1,
      `a section a field names in another case was dropped (HTTP ${res.status})`,
    );
  });

  test('an empty section is still dropped by the same replace', async (t) => {
    if (guard(t)) return;
    // The control. The reconcile's ordinary job is adding, relabelling and
    // reordering sections, and removing one nothing references; a check that
    // refused every removal would satisfy the cases above and remove the
    // feature.
    await seedSection('overview', { display_label: 'Overview' });
    await seedSection('details', { display_label: 'Details', sort_order: 2 });
    await seedField({ id: FIELD_A, field_key: 'city', section: 'overview' });

    const res = await post(ADMIN, '/edge/app/schema/blueprint_sections/replace', {
      blueprint_id: BP,
      expected: [sectionSnapshot('overview', 'Overview'), sectionSnapshot('details', 'Details', 2)],
      next: [sectionSnapshot('overview', 'Overview')],
    });
    assert.equal(res.status, 200, `a legitimate removal was refused: ${JSON.stringify(res.body)}`);
    assert.deepEqual((await sectionRows()).map((s) => s.section_key), ['overview']);
  });

  test('a reorder that renames nothing still lands', async (t) => {
    if (guard(t)) return;
    // The path the Schema Builder actually takes: every existing key is present
    // in `next`, only `sort_order` moves. Nothing departs, so the new check has
    // nothing to say.
    await seedSection('overview', { display_label: 'Overview' });
    await seedSection('details', { display_label: 'Details', sort_order: 2 });
    await seedField({ id: FIELD_A, field_key: 'city', section: 'overview' });

    const res = await post(ADMIN, '/edge/app/schema/blueprint_sections/replace', {
      blueprint_id: BP,
      expected: [sectionSnapshot('overview', 'Overview'), sectionSnapshot('details', 'Details', 2)],
      next: [sectionSnapshot('details', 'Details'), sectionSnapshot('overview', 'Overview', 2)],
    });
    assert.equal(res.status, 200, `a legitimate reorder was refused: ${JSON.stringify(res.body)}`);
    const sections = await sectionRows();
    assert.equal(sections.find((s) => s.section_key === 'details').sort_order, 1);
    assert.equal(sections.find((s) => s.section_key === 'overview').sort_order, 2);
  });

  test('a case-only rename of a section fields still name is refused, in both lanes',
    async (t) => {
      if (guard(t)) return;
      // THE CONSEQUENCE OF HOLDING TWO DIFFERENT COMPARISONS AT ONCE, pinned so
      // it is a decision rather than an accident. The delete set is keyed
      // BYTE-wise (a case-only change is a delete plus an insert, and the
      // case-folding UNIQUE is why the delete must come first), while the
      // reference guard asks the ENGINE (a field holding `Overview` is in
      // `overview`). So a case-only rename of a section that still has fields
      // departs by the first comparison and is still referenced by the second,
      // and is refused — the same refusal the groups lane gives on the same
      // input, which is why both halves are asserted here.
      //
      // WHAT THE TWO LANES DO NOT SHARE IS THE REMEDY, and an earlier version of
      // this comment claimed they did. A group is re-cased through
      // `blueprint_groups/rename-with-cascade`, which re-points every field in
      // one transaction; sections have no such endpoint, so for a section a
      // field names there is no request that performs the act at all — this
      // reconcile refuses it and `delete-with-reassign` refuses a target its own
      // collation calls the source (the case two blocks above). That gap is the
      // missing sections mirror of rename-with-cascade, tracked on its own; this
      // case pins the refusal, not the gap.
      await seedSection('Overview', { display_label: 'Overview' });
      await seedField({ id: FIELD_A, field_key: 'city', section: 'Overview' });

      const res = await post(ADMIN, '/edge/app/schema/blueprint_sections/replace', {
        blueprint_id: BP,
        expected: [sectionSnapshot('Overview', 'Overview')],
        next: [sectionSnapshot('overview', 'Overview')],
      });

      assert.deepEqual(
        (await sectionRows()).map((s) => s.section_key), ['Overview'],
        `the metadata row moved under the fields naming it (HTTP ${res.status})`,
      );
      assert.equal(res.status, 409);
      assert.equal(res.body.error.code, 'SECTION_KEY_IN_USE');
      // AND THE SENTENCE NAMES AN ACT THAT IS AVAILABLE. It used to say to move
      // the fields via delete-with-reassign, which refuses a target its own
      // collation calls the section being removed — so the operator was sent to
      // a door that answers this same input with another refusal. A DIFFERENT
      // section is the part that makes the instruction true.
      assert.match(res.body.error.message, /different section/);

      // The groups lane, which this one mirrors, on the same input.
      await seedGroup('Lane_A');
      await seedField({ id: FIELD_B, field_key: 'zone', group_key: 'Lane_A' });
      const grouped = await post(ADMIN, '/edge/app/schema/blueprint_groups/replace', {
        blueprint_id: BP,
        expected: [groupSnapshot('Lane_A')],
        next: [groupSnapshot('lane_a')],
      });
      assert.deepEqual(
        (await groupRows()).map((g) => g.group_key), ['Lane_A'],
        `the two lanes disagreed about the same act (HTTP ${grouped.status})`,
      );
      // AND THE REASON, not just the row counts — the sections half above asserts
      // its code and this mirror did not. Measured: with the echo made stale this
      // lane answers 409 STALE_REVISION, which leaves the rows identically
      // unchanged, so row counts alone cannot tell the refusal this case is about
      // from a refusal that would have happened whatever the guard did.
      assert.equal(grouped.status, 409);
      assert.equal(grouped.body.error.code, 'GROUP_KEY_IN_USE');
    });

  test('a case-only rename of an EMPTY section still lands', async (t) => {
    if (guard(t)) return;
    // The control for the pair: with nothing referencing it, the byte-keyed
    // delete set does its job — the old row goes, the new spelling is inserted,
    // and the reconcile is how a key is normalised when no field names it.
    await seedSection('Overview', { display_label: 'Overview' });

    const res = await post(ADMIN, '/edge/app/schema/blueprint_sections/replace', {
      blueprint_id: BP,
      expected: [sectionSnapshot('Overview', 'Overview')],
      next: [sectionSnapshot('overview', 'Overview')],
    });

    assert.equal(res.status, 200, `a legitimate rename was refused: ${JSON.stringify(res.body)}`);
    assert.deepEqual((await sectionRows()).map((s) => s.section_key), ['overview']);
  });

  test('the groups lane this mirrors still refuses the same act', async (t) => {
    if (guard(t)) return;
    // The model, kept beside the copy: the check the sections lane has just
    // gained is the one already in the tree, and this states that adopting it
    // did not disturb it.
    await seedGroup('lane_a');
    await seedField({ id: FIELD_A, field_key: 'city', group_key: 'lane_a' });

    const res = await post(ADMIN, '/edge/app/schema/blueprint_groups/replace', {
      blueprint_id: BP,
      expected: [groupSnapshot('lane_a')],
      next: [],
    });
    assert.equal(
      (await groupRows()).length, 1,
      `the groups lane dropped a referenced key (HTTP ${res.status})`,
    );
  });
});

// ── T11 — the child cleanup is driven by the predicate the parent DELETE will
//        re-evaluate (row 7: C-04) ────────────────────────────────────────────

describe('a cascade whose children are chosen from an unlocked snapshot', () => {
  const delay = (ms) => new Promise((r) => setTimeout(r, ms));

  /** Has this promise settled yet? Never rethrows — the caller asserts. */
  async function settledWithin(promise, ms) {
    const marker = Symbol('pending');
    const guarded = promise.then((v) => v, (e) => e);
    return (await Promise.race([guarded, delay(ms).then(() => marker)])) !== marker;
  }

  async function seedOverride(fieldId, action = 'lock') {
    await pool.query(
      `INSERT INTO \`${tbl('variant_overrides')}\` (id, variant_id, field_id, action)
       VALUES (UUID(), ?, ?, ?)`,
      [VARIANT, fieldId, action],
    );
  }

  const optionCount = (fieldId) => countOf(
    `SELECT COUNT(*) AS n FROM \`${tbl('field_options')}\` WHERE field_id = ?`, [fieldId],
  );
  const overrideCount = (fieldId) => countOf(
    `SELECT COUNT(*) AS n FROM \`${tbl('variant_overrides')}\` WHERE field_id = ?`, [fieldId],
  );

  test('the engine really holds this transaction at a consistent read', async (t) => {
    if (guard(t)) return;
    // THE PREMISE, MEASURED. The case below turns on a plain SELECT inside a
    // transaction reading a row a concurrent uncommitted UPDATE has already
    // moved. That is a property of the isolation level, not of the route, and if
    // a deployment ever changes it this is the assertion that says so — next to
    // the case that depends on it.
    // `transaction_isolation` is the 11.1+ spelling; 10.x answers only to
    // `tx_isolation`, and this suite must state the premise on both.
    let level = null;
    for (const variable of ['@@transaction_isolation', '@@tx_isolation']) {
      try {
        level = (await one(`SELECT ${variable} AS lvl`)).lvl;
        break;
      } catch { /* the other spelling */ }
    }
    assert.equal(
      String(level).toUpperCase().replace(/[-\s]/g, ''), 'REPEATABLEREAD',
      'this server no longer defaults to REPEATABLE READ',
    );
  });

  /**
   * A connection of its own, so the short lock-wait it sets cannot be released
   * back into the pool and shorten someone else's wait later.
   */
  async function withImpatientConnection(fn) {
    const conn = await mariadb.createConnection({
      ...dbConfigMemo, database: testDbName, connectTimeout: 5000,
    });
    try {
      await conn.query('SET SESSION innodb_lock_wait_timeout = 1');
      return await fn(conn);
    } finally {
      try { await conn.end(); } catch { /* best effort */ }
    }
  }

  /** Did this statement block on someone else's lock? */
  async function blockedOnALock(run) {
    try {
      await run();
      return false;
    } catch (err) {
      if (err && (err.code === 'ER_LOCK_WAIT_TIMEOUT' || err.errno === 1205)) return true;
      throw err;
    }
  }

  for (const [label, lockTheSection, seedTheField] of [
    ['while it holds a section that has fields', true, true],
    ['while it holds a section that is empty', true, false],
    ['while the move relabels the section', false, true],
  ]) {
    test(`no field can arrive in the section ${label}`, async (t) => {
      if (guard(t)) return;
      // THE PREMISE THE METADATA DELETE RESTS ON, MEASURED, and stated here
      // because a reviewer read the delete-with-reassign handler as committing
      // the very state the sections replace refuses: the field DELETE is bound
      // to the ids the snapshot LOCKED, while the `blueprint_sections` DELETE
      // that follows is predicate-based and unconditional — so a field arriving
      // after the snapshot would survive the cascade and be left naming a
      // section whose metadata row is gone.
      //
      // It cannot arrive, and the FIRST reason depends on no isolation level and
      // no query plan. Before anything else, this handler takes
      // `isBlueprintLinkedLocked` on the blueprint
      // (routes-group-section-maint.js) — a PRIMARY-KEY row lock on
      // `hierarchy_nodes`, held until the transaction ends. Every path in this
      // application that can make a field name a section of an EXISTING
      // blueprint takes a lock on that same row before it writes: the factory's
      // create and update through `rejectIfParentLinked` → `isLinkedParentLocked`
      // (crud-factory.js), the custom `PUT /blueprint_fields/:id`
      // (routes-blueprint-fields.js), the reconcile and maintenance routes
      // (routes-replace.js, routes-group-section-maint.js,
      // routes-field-options.js), and `overwriteBlueprint`, which takes its own
      // `SELECT id … FOR UPDATE` on it (blueprint-serialization.js). The two
      // import routes insert fields only into a blueprint they created in the
      // same transaction, so they cannot reach an existing section at all. Each
      // of those blocks on the lock this handler already holds.
      //
      // The SECOND reason is the engine's, and it is what THIS test measures,
      // because its instrument is a raw INSERT on a connection of its own — a
      // thing no application path is. Under this server's REPEATABLE READ (the
      // case above asserts it), both of the handler's own statements — the
      // `SELECT … FOR UPDATE` in the delete branch and the `UPDATE … SET section`
      // in the move branch — take next-key locks over the range they scan,
      // INCLUDING the gaps and INCLUDING when they match no rows at all, so a
      // write into that range blocks too.
      //
      // So no re-assertion is added before the metadata DELETE: it would be
      // unreachable code guarding a window that is already closed twice over.
      // Note what a move to READ COMMITTED would do — it would turn THIS test
      // red while the invariant itself still held on the row lock, so a failure
      // here is a signal to re-derive the argument, not proof that fields can
      // now arrive.
      await seedSection('overview');
      if (seedTheField) {
        await seedField({ id: FIELD_A, field_key: 'city', section: 'overview' });
      }

      const holder = await pool.getConnection();
      try {
        await holder.beginTransaction();
        if (lockTheSection) {
          await holder.query(
            `SELECT id FROM \`${tbl('blueprint_fields')}\`
              WHERE blueprint_id = ? AND section = ? FOR UPDATE`,
            [BP, 'overview'],
          );
        } else {
          await holder.query(
            `UPDATE \`${tbl('blueprint_fields')}\` SET section = ?
              WHERE blueprint_id = ? AND section = ?`,
            ['details', BP, 'overview'],
          );
        }

        const arrived = await withImpatientConnection((conn) => blockedOnALock(() => conn.query(
          `INSERT INTO \`${tbl('blueprint_fields')}\`
             (id, blueprint_id, field_key, field_label, field_type, section)
           VALUES (?, ?, 'zip', 'Zip', 'text', 'overview')`,
          [FIELD_B, BP],
        )));

        assert.equal(
          arrived, true,
          'a field arrived in the section the cascade had already locked — the metadata '
          + 'DELETE that follows now needs the emptiness re-assertion this test says it does not',
        );
      } finally {
        try { await holder.rollback(); } catch { /* best effort */ }
        holder.release();
      }
    });
  }

  test('a field that leaves the section mid-delete keeps its options and overrides',
    async (t) => {
      if (guard(t)) return;
      // ROW 7 (C-04). The section delete chose the fields to cascade over with
      // an UNLOCKED `SELECT id … WHERE blueprint_id = ? AND section = ?`, deleted
      // those ids' options and variant overrides, and only then issued the
      // parent DELETE — which RE-EVALUATES the same predicate against the latest
      // committed rows. Between the two, a field can leave the section. The
      // parent DELETE then matches nothing, the field survives, and its options
      // and overrides are already gone: the row is stranded with its choices
      // destroyed, and the response still reports the snapshot's count as
      // `deleted_fields`.
      //
      // Held open deterministically by a second connection rather than by
      // hoping for an interleaving: it takes the row lock first, so the request
      // blocks — pre-fix at the parent DELETE, with the children already gone;
      // post-fix at the snapshot, before anything is deleted.
      await seedSection('overview');
      await seedField({ id: FIELD_A, field_key: 'city', section: 'overview' });
      await pool.query(
        `INSERT INTO \`${tbl('field_options')}\` (id, field_id, option_label, option_value)
         VALUES (UUID(), ?, 'A', 'a'), (UUID(), ?, 'B', 'b')`,
        [FIELD_A, FIELD_A],
      );
      await seedOverride(FIELD_A);

      const other = await mariadb.createConnection({
        ...dbConfigMemo, database: testDbName, connectTimeout: 5000,
      });
      let pending = null;
      try {
        await other.beginTransaction();
        await other.query(
          `UPDATE \`${tbl('blueprint_fields')}\` SET section = 'moved' WHERE id = ?`, [FIELD_A],
        );

        pending = post(ADMIN, '/edge/app/schema/blueprint_sections/delete-with-reassign', {
          blueprint_id: BP, section_key: 'overview', action: 'delete',
        });
        assert.equal(
          await settledWithin(pending, 500), false,
          'the request did not block on the row the other transaction holds',
        );
        await other.commit();
      } finally {
        try { await other.end(); } catch { /* best effort */ }
      }
      const res = await pending;

      assert.equal(
        await optionCount(FIELD_A), 2,
        `the options of a field the DELETE did not remove were destroyed (HTTP ${res.status})`,
      );
      assert.equal(
        await overrideCount(FIELD_A), 1,
        'the variant overrides of a field the DELETE did not remove were destroyed',
      );
      const fields = await fieldRows();
      assert.equal(fields.length, 1, 'the field that left the section was deleted anyway');
      assert.equal(fields[0].section, 'moved');
      assert.equal(
        res.body?.data?.deleted_fields, 0,
        'the response reported deleting a field the statement did not delete',
      );
    });

  test('an ordinary section delete still removes the fields, options and overrides',
    async (t) => {
      if (guard(t)) return;
      // The control. Locking the snapshot must not stop the cascade doing its
      // job, and the counts it reports must be the ones the statements produced.
      await seedSection('overview');
      await seedField({ id: FIELD_A, field_key: 'city', section: 'overview' });
      await seedField({ id: FIELD_B, field_key: 'zone', section: 'overview' });
      await pool.query(
        `INSERT INTO \`${tbl('field_options')}\` (id, field_id, option_label, option_value)
         VALUES (UUID(), ?, 'A', 'a'), (UUID(), ?, 'B', 'b')`,
        [FIELD_A, FIELD_B],
      );
      await seedOverride(FIELD_A);

      const res = await post(ADMIN, '/edge/app/schema/blueprint_sections/delete-with-reassign', {
        blueprint_id: BP, section_key: 'overview', action: 'delete',
      });
      assert.equal(res.status, 200, `a legitimate delete was refused: ${JSON.stringify(res.body)}`);

      assert.deepEqual(await fieldRows(), [], 'the fields in the section survived');
      assert.equal(await optionCount(FIELD_A), 0, 'an option row was orphaned');
      assert.equal(await optionCount(FIELD_B), 0, 'an option row was orphaned');
      assert.equal(await overrideCount(FIELD_A), 0, 'a variant override was orphaned');
      assert.equal((await sectionRows()).length, 0, 'the section metadata row survived');
      assert.deepEqual(
        [res.body.data.deleted_fields, res.body.data.deleted_options, res.body.data.deleted_overrides],
        [2, 2, 1],
        'the report does not match what the statements did',
      );
    });

  test('a section with no fields at all still deletes its metadata row', async (t) => {
    if (guard(t)) return;
    // The empty case: no children to lock, nothing to cascade, and the metadata
    // DELETE must still run.
    await seedSection('overview');

    const res = await post(ADMIN, '/edge/app/schema/blueprint_sections/delete-with-reassign', {
      blueprint_id: BP, section_key: 'overview', action: 'delete',
    });
    assert.equal(res.status, 200, `a legitimate delete was refused: ${JSON.stringify(res.body)}`);
    assert.equal((await sectionRows()).length, 0, 'the section metadata row survived');
    assert.equal(res.body.data.deleted_fields, 0);
  });
});

// ── T12 — field_options: one notion of "the same option", one spelling of the
//        parent id (rows 20 B51, 21 B54, 22 B53) ────────────────────────────

describe('the options of a field, and the field they say they belong to', () => {
  const opt = (label, value, sortOrder = 1) => ({
    option_label: label, option_value: value, sort_order: sortOrder,
  });
  const replaceOptions = (user, body) =>
    post(user, '/edge/app/schema/field_options/replace', body);

  const storedOptions = () => rows(
    `SELECT id, field_id, option_label, option_value FROM \`${tbl('field_options')}\`
      ORDER BY option_value`,
  );
  const optionCount = async () => countOf(`SELECT COUNT(*) AS n FROM \`${tbl('field_options')}\``);

  test('the column really calls two spellings of an option value one value', async (t) => {
    if (guard(t)) return;
    // THE PREMISE, MEASURED, and written directly so the fold is shown to be the
    // DATABASE's rather than something a route does. `option_value` is
    // `VARCHAR(255)` under a case-folding, space-padding collation, and a
    // checkbox answer is stored BY this value — so two options the column calls
    // one value cannot be told apart by any predicate the engine evaluates. If a
    // later collation change stops folding them, this is the assertion that says
    // so, next to the guard that depends on it.
    await seedField({ field_type: 'checkbox' });
    await pool.query(
      `INSERT INTO \`${tbl('field_options')}\` (id, field_id, option_label, option_value)
       VALUES (UUID(), ?, 'Upper', 'Red'), (UUID(), ?, 'Lower', 'red')`,
      [FIELD_A, FIELD_A],
    );
    const matched = await countOf(
      `SELECT COUNT(*) AS n FROM \`${tbl('field_options')}\` WHERE option_value = ?`, ['red'],
    );
    assert.equal(matched, 2, 'this database no longer folds Red and red into one stored value');
    const padded = await countOf(
      `SELECT COUNT(*) AS n FROM \`${tbl('field_options')}\` WHERE option_value = ?`, ['red   '],
    );
    assert.equal(padded, 2, 'this database no longer pads a trailing space when comparing');
  });

  test('two option values the column calls one value are refused on a multi-select',
    async (t) => {
      if (guard(t)) return;
      // ROW 20 (B51). The uniqueness guard a checkbox field needs — its answers
      // are stored BY `option_value` — was a JavaScript `Set`, which calls 'Red'
      // and 'red' two options while every predicate the engine evaluates calls
      // them one. Both were stored, and a stored answer can no longer be
      // resolved to one option by anything that asks the database.
      await seedField({ field_type: 'checkbox' });

      const res = await replaceOptions(ADMIN, {
        field_id: FIELD_A,
        expected: [],
        next: [opt('Upper', 'Red', 1), opt('Lower', 'red', 2)],
      });

      assert.equal(
        await optionCount(), 0,
        `two options the column calls one value were stored (HTTP ${res.status})`,
      );
    });

  test('a multi-select with genuinely distinct values still saves', async (t) => {
    if (guard(t)) return;
    // The control. A guard that refused every option list would satisfy the case
    // above and remove the feature.
    await seedField({ field_type: 'checkbox' });

    const res = await replaceOptions(ADMIN, {
      field_id: FIELD_A,
      expected: [],
      next: [opt('Red', 'red', 1), opt('Blue', 'blue', 2)],
    });
    assert.equal(res.status, 200, `a legitimate save was refused: ${JSON.stringify(res.body)}`);
    assert.deepEqual(
      (await storedOptions()).map((r) => r.option_value), ['blue', 'red'],
    );
  });

  const optionList = (n) => Array.from({ length: n }, (_, i) => opt(`L${i}`, `v${i}`, i));

  test('an option list past the bound is refused, and nothing is stored', async (t) => {
    if (guard(t)) return;
    // The guard above turned the LENGTH OF A REQUEST ARRAY into the SIZE OF A
    // QUERY: it asks the column, one `UNION ALL` branch per distinct value.
    // Before it, the same check was an in-process `Set` and the array never
    // reached the database at all. Unbounded, a body under the 10MB limit builds
    // a statement with six figures of branches — measured, 20k options really do
    // save, in seconds.
    await seedField({ field_type: 'checkbox' });

    const res = await replaceOptions(ADMIN, {
      field_id: FIELD_A, expected: [], next: optionList(MAX_REPLACE_OPTIONS + 1),
    });

    assert.equal(await optionCount(), 0, `an unbounded option list was stored (HTTP ${res.status})`);
    assert.equal(res.status, 400, `expected a stable refusal, got ${JSON.stringify(res.body)}`);
    assert.equal(res.body.error.code, 'TOO_MANY_OPTIONS');
  });

  test('a field that already carries more options than the bound can still be shrunk',
    async (t) => {
      if (guard(t)) return;
      // THE STATE THE BOUND MUST NOT TRAP. `expected` is not a write: it is the
      // optimistic-lock echo of what the server ALREADY holds, compared
      // row-for-row against the stored rows and bound to nothing. Capping it
      // with `next` made a field that predates the bound unshrinkable through
      // this endpoint — the honest echo of its rows is refused 400
      // TOO_MANY_OPTIONS however short `next` is, and a truncated echo is
      // refused 409 STALE_REVISION, so there is no request the endpoint accepts
      // and the field can only be emptied one row at a time through the generic
      // DELETE. Such fields are reachable: the measurement that produced the
      // bound stored 20,000 options through this same route.
      await seedField({ field_type: 'select' });
      const overTheBound = MAX_REPLACE_OPTIONS + 5;
      const values = Array.from({ length: overTheBound }, (_, i) => [FIELD_A, `L${i}`, `v${i}`, i]);
      await pool.batch(
        `INSERT INTO \`${tbl('field_options')}\` (id, field_id, option_label, option_value, sort_order)
         VALUES (UUID(), ?, ?, ?, ?)`,
        values,
      );
      assert.equal(await optionCount(), overTheBound, 'the fixture did not seed the pre-state');

      const current = await rows(
        `SELECT id, option_label, option_value, sort_order FROM \`${tbl('field_options')}\`
          WHERE field_id = ?`, [FIELD_A],
      );
      const res = await replaceOptions(ADMIN, {
        field_id: FIELD_A,
        expected: current.map((r) => ({
          id: r.id, option_label: r.option_label, option_value: r.option_value,
          sort_order: r.sort_order,
        })),
        next: [opt('Red', 'red', 1), opt('Blue', 'blue', 2)],
      });

      assert.equal(res.status, 200, `an honest echo of the stored rows was refused: ${JSON.stringify(res.body)}`);
      assert.equal(await optionCount(), 2, 'the field could not be shrunk');
    });

  test('a list at the bound still saves every row', async (t) => {
    if (guard(t)) return;
    // The control for the bound: the number has to be above anything an operator
    // authors (the largest real lists — countries, currencies — are in the low
    // hundreds), so the list AT it must still land in full.
    await seedField({ field_type: 'checkbox' });

    const res = await replaceOptions(ADMIN, {
      field_id: FIELD_A, expected: [], next: optionList(MAX_REPLACE_OPTIONS),
    });

    assert.equal(res.status, 200, `a list at the bound was refused: ${JSON.stringify(res.body)}`);
    assert.equal(await optionCount(), MAX_REPLACE_OPTIONS, 'the save dropped rows silently');
  });

  test('a select field keeps its duplicate-value aliases', async (t) => {
    if (guard(t)) return;
    // The other control, and the reason this guard is keyed on the field type at
    // all: a single-select may legitimately carry two labels over one value.
    await seedField({ field_type: 'select' });

    const res = await replaceOptions(ADMIN, {
      field_id: FIELD_A,
      expected: [],
      next: [opt('Crimson', 'red', 1), opt('Scarlet', 'red', 2)],
    });
    assert.equal(res.status, 200, `a legitimate alias list was refused: ${JSON.stringify(res.body)}`);
    assert.equal(await optionCount(), 2, 'the alias list did not survive');
  });

  test('a field whose stored type is outside the declared domain is not judged as a select',
    async (t) => {
      if (guard(t)) return;
      // ROW 21 (B54). The guard runs only when the STORED `field_type` is
      // byte-identically 'checkbox'. The column is a plain VARCHAR, so a legacy
      // row can hold 'Checkbox' — which the database calls the same value and no
      // reader of this application draws — and the uniqueness guard silently did
      // not run. The write path now refuses to store such a spelling, but rows
      // that predate that refusal are still there, and this endpoint reads one
      // of them.
      //
      // Refusing is the only answer that is not a guess: to the engine the field
      // IS a checkbox, to every JavaScript reader it is nothing at all, and
      // storing options under either reading commits to one of them.
      await seedField({ field_type: 'Checkbox' });

      const res = await replaceOptions(ADMIN, {
        field_id: FIELD_A,
        expected: [],
        next: [opt('Upper', 'Red', 1), opt('Lower', 'red', 2)],
      });

      assert.equal(
        await optionCount(), 0,
        `options were stored under a field whose type no reader agrees about (HTTP ${res.status})`,
      );
    });

  test('a field with no type at all still saves its options', async (t) => {
    if (guard(t)) return;
    // The control for the case above, and the boundary the shared domain draws:
    // the column is nullable, so NULL is a value it may legitimately hold, and
    // the domain gate declares presence and null are not violations. A field
    // with no type is no reader's checkbox, so its options are saved unjudged
    // exactly as before.
    await seedField({ field_type: null });

    const res = await replaceOptions(ADMIN, {
      field_id: FIELD_A,
      expected: [],
      next: [opt('Red', 'red', 1), opt('Blue', 'blue', 2)],
    });
    assert.equal(res.status, 200, `a legitimate save was refused: ${JSON.stringify(res.body)}`);
    assert.equal(await optionCount(), 2, 'the options did not survive');
  });

  test('an option row carries the field id the field itself holds', async (t) => {
    if (guard(t)) return;
    // ROW 22 (B53). The ownership lookup resolves the field with `WHERE id = ?`
    // under the column's collation, so a `field_id` spelt in another case finds
    // the row and passes every gate — and then the INSERT bound the CALLER'S
    // spelling. The option rows come to name their field in bytes no JavaScript
    // reader resolves to it: the options panel keys its lists by field id, the
    // export walks fields and collects options by exact match, and the delete
    // cascade in `delete-renormalize` removes options `WHERE field_id = ?` from
    // the field row it just read. Under the engine those reads still match; the
    // application's own do not.
    await seedField({ field_type: 'select' });

    const res = await replaceOptions(ADMIN, {
      field_id: FIELD_A.toUpperCase(),
      expected: [],
      next: [opt('Red', 'red', 1)],
    });
    assert.equal(res.status, 200, `a legitimate save was refused: ${JSON.stringify(res.body)}`);

    const stored = await storedOptions();
    assert.equal(stored.length, 1);
    assert.equal(
      stored[0].field_id, FIELD_A,
      'the option row names its field in a spelling the field row does not hold',
    );
  });

  test('an option row updated through an aliased field id keeps the field own spelling',
    async (t) => {
      if (guard(t)) return;
      // The control for the arm that never bound the parent id: an UPDATE keys
      // on the option row's own id, and the re-read the response is built from
      // resolves under the collation either way, so both were already correct.
      // Binding the resolved id everywhere must not disturb them — a fix that
      // moved the defect from the INSERT arm to this one would satisfy the case
      // above and leave the same rows behind.
      await seedField({ field_type: 'select' });
      await pool.query(
        `INSERT INTO \`${tbl('field_options')}\` (id, field_id, option_label, option_value, sort_order)
         VALUES (?, ?, 'Red', 'red', 1)`,
        ['0b7f5c02-1111-4222-8333-00000000000f', FIELD_A],
      );

      const res = await replaceOptions(ADMIN, {
        field_id: FIELD_A.toUpperCase(),
        expected: [{
          id: '0b7f5c02-1111-4222-8333-00000000000f',
          option_label: 'Red',
          option_value: 'red',
          sort_order: 1,
          valid_parent_values: null,
        }],
        next: [{
          id: '0b7f5c02-1111-4222-8333-00000000000f', ...opt('Ruby', 'ruby', 1),
        }],
      });
      assert.equal(res.status, 200, `a legitimate save was refused: ${JSON.stringify(res.body)}`);

      const stored = await storedOptions();
      assert.equal(stored.length, 1);
      assert.equal(stored[0].option_value, 'ruby', 'the update did not land');
      assert.equal(stored[0].field_id, FIELD_A, 'the update respelt the parent id');
      assert.equal(res.body.data.rows.length, 1, 'the response lost the row it just wrote');
    });
});

// ── T13 — the orphan delete judges the row the scanner flagged (row 30: C-12) ─

describe('a residual judged against one of two fields that share a key', () => {
  const TEMPLATE = 'ba5eba11-1111-4222-8333-000000000001';
  const LOW_ID = 'aaaaaaaa-1111-4222-8333-000000000001';
  const HIGH_ID = 'bbbbbbbb-1111-4222-8333-000000000002';

  async function seedTemplate(payload) {
    await pool.query(
      `INSERT INTO \`${tbl('user_templates')}\` (id, name, blueprint_id, payload)
       VALUES (?, 'tpl', ?, ?)`,
      [TEMPLATE, BP, JSON.stringify(payload)],
    );
  }

  async function storedPayload() {
    const row = await one(
      `SELECT payload FROM \`${tbl('user_templates')}\` WHERE id = ?`, [TEMPLATE],
    );
    return typeof row.payload === 'string' ? JSON.parse(row.payload) : row.payload;
  }

  const scan = () => post(ADMIN, '/edge/app/schema/field-data-orphans', {});
  const clearMismatch = (key) => call(
    ADMIN, 'DELETE', `/edge/app/schema/field-data-orphans/${TEMPLATE}/${key}?kind=type_mismatch`,
  );
  const clearOrphan = (key) => call(
    ADMIN, 'DELETE', `/edge/app/schema/field-data-orphans/${TEMPLATE}/${key}`,
  );

  /**
   * Two field rows sharing `(blueprint_id, field_key)`, in a stated id order.
   *
   * The index that now forbids this pair cannot be created on a database that
   * already holds duplicates — the migration step skips, visibly, rather than
   * failing boot — so these rows are exactly the state the deployed schema is
   * still allowed to be in, and the one the fix has to survive.
   */
  async function seedDuplicatePair(lowType, highType) {
    await pool.query(
      `ALTER TABLE \`${tbl('blueprint_fields')}\` DROP INDEX uq_blueprint_field_key`,
    );
    await seedField({ id: LOW_ID, field_key: 'city', field_type: lowType });
    await seedField({ id: HIGH_ID, field_key: 'city', field_type: highType });
  }

  async function restoreFieldKeyIndex() {
    await pool.query(`DELETE FROM \`${tbl('blueprint_fields')}\``);
    await pool.query(
      `ALTER TABLE \`${tbl('blueprint_fields')}\`
       ADD UNIQUE KEY uq_blueprint_field_key (blueprint_id, field_key)`,
    );
  }

  for (const [label, lowType, highType] of [
    ['the checkbox row first', 'checkbox', 'text'],
    ['the checkbox row last', 'text', 'checkbox'],
  ]) {
    test(`a value one of the two fields accepts survives, with ${label}`, async (t) => {
      if (guard(t)) return;
      // ROW 30 (C-12). Two rows share `(blueprint_id, field_key)`. The scanner
      // built a Map keyed by `field_key` and kept the LAST row's `field_type`;
      // the delete re-check joined on the same key with no `LIMIT` and read
      // `rows[0].ft` — whichever the engine handed back first. Nothing makes
      // those the same row, so the two orders below disagree with each other,
      // and a `"plain string"` that the `text` field accepts was reported as a
      // mismatch and then REMOVED from the payload by a JSON_REMOVE that judged
      // it against the `checkbox` row. The value is stored nowhere else.
      //
      // Both orders are run because which row the engine returns first is not a
      // contract, and a fix that merely made the two agree on an arbitrary row
      // would still destroy the value in one of them.
      await seedDuplicatePair(lowType, highType);
      try {
        await seedTemplate({ city: 'plain string' });

        const scanned = await scan();
        assert.equal(scanned.status, 200, `the scan failed: ${JSON.stringify(scanned.body)}`);
        assert.deepEqual(
          scanned.body.data.orphans.filter((o) => o.orphan_key === 'city'), [],
          'the scanner flagged a value one of the two fields accepts',
        );

        const cleared = await clearMismatch('city');
        assert.deepEqual(
          await storedPayload(), { city: 'plain string' },
          `a value one of the two fields accepts was removed (HTTP ${cleared.status})`,
        );
      } finally {
        await restoreFieldKeyIndex();
      }
    });
  }

  test('a value neither of the two fields accepts is still reported and cleared', async (t) => {
    if (guard(t)) return;
    // The control for the duplicate case. Judging every row that holds the key
    // must not become "never a mismatch": when NO field with that key accepts
    // the value, it is a residual and the repair endpoint must still remove it.
    await seedDuplicatePair('checkbox', 'table');
    try {
      await seedTemplate({ city: 'plain string' });

      const scanned = await scan();
      const flagged = scanned.body.data.orphans.filter((o) => o.orphan_key === 'city');
      assert.equal(flagged.length, 1, 'a value no field accepts was not reported');
      assert.equal(flagged[0].kind, 'type_mismatch');

      const cleared = await clearMismatch('city');
      assert.equal(cleared.status, 200, `the repair was refused: ${JSON.stringify(cleared.body)}`);
      assert.deepEqual(await storedPayload(), {}, 'the residual was not removed');
    } finally {
      await restoreFieldKeyIndex();
    }
  });

  test('an ordinary mismatch against a single field is still reported and cleared', async (t) => {
    if (guard(t)) return;
    // The path with no duplicates at all — the one every database that took the
    // index is on. It must be untouched.
    await seedField({ id: FIELD_A, field_key: 'city', field_type: 'checkbox' });
    await seedTemplate({ city: 'plain string' });

    const scanned = await scan();
    const flagged = scanned.body.data.orphans.filter((o) => o.orphan_key === 'city');
    assert.equal(flagged.length, 1, 'a genuine mismatch stopped being reported');
    assert.equal(flagged[0].field_type, 'checkbox');

    const cleared = await clearMismatch('city');
    assert.equal(cleared.status, 200, `the repair was refused: ${JSON.stringify(cleared.body)}`);
    assert.deepEqual(await storedPayload(), {}, 'the residual was not removed');
  });

  test('a key no field holds at all is still an orphan and still cleared', async (t) => {
    if (guard(t)) return;
    // The other lane of the same endpoint, which resolves the relationship with
    // a set-based `NOT EXISTS` and was already right. Kept beside the changed
    // one so adopting its shape cannot quietly disturb it.
    await seedField({ id: FIELD_A, field_key: 'city', field_type: 'text' });
    await seedTemplate({ city: 'kept', ghost: 'gone' });

    const scanned = await scan();
    const flagged = scanned.body.data.orphans.filter((o) => o.orphan_key === 'ghost');
    assert.equal(flagged.length, 1, 'a genuine orphan stopped being reported');
    assert.equal(flagged[0].kind, 'orphan');

    const cleared = await clearOrphan('ghost');
    assert.equal(cleared.status, 200, `the repair was refused: ${JSON.stringify(cleared.body)}`);
    assert.deepEqual(await storedPayload(), { city: 'kept' }, 'the wrong key was removed');
  });

  test('a key a field holds in another case is not an orphan to the scanner or the deleter',
    async (t) => {
      if (guard(t)) return;
      // byte-compare, on both sides, and stated as a control because the two
      // must not drift apart: a payload key is looked up in a JavaScript Map by
      // the scanner and matched with `BINARY ?` by the deleter, so a field
      // spelt `City` does NOT hold the key `city` for either of them. Both
      // therefore call this a residual, and they agree — which is the property
      // this row is about.
      await seedField({ id: FIELD_A, field_key: 'City', field_type: 'text' });
      await seedTemplate({ city: 'residual' });

      const scanned = await scan();
      const flagged = scanned.body.data.orphans.filter((o) => o.orphan_key === 'city');
      assert.equal(flagged.length, 1, 'the scanner folded two field keys into one');
      assert.equal(flagged[0].kind, 'orphan');

      const cleared = await clearOrphan('city');
      assert.equal(cleared.status, 200, `the deleter disagreed with the scanner: ${JSON.stringify(cleared.body)}`);
      assert.deepEqual(await storedPayload(), {}, 'the residual was not removed');
    });
});
