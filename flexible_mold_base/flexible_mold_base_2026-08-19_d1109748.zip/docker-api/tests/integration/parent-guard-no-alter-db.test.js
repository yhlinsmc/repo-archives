'use strict';

/**
 * parent-guard-no-alter-db.test.js — the orphan guard on a database that never
 * got the approval columns.
 *
 * `flow_recipes.status` / `approved_by` / `approved_at` / `review_note` are
 * ADDITIVE: `table-ddls.js` describes them as columns a no-ALTER install may
 * simply not have, and `flow-recipes/approval.js` carries an
 * APPROVAL_UNAVAILABLE arm for that install. The child-write guard that refuses
 * a parent which is not there asked for the parent's existence and its approval
 * state in ONE statement, then swallowed errno 1054 as "the parent is fine" —
 * so on this shape the existence question was never asked at all, and a POST
 * naming a recipe that never existed stored a step carrying an encrypted
 * credential that no editor can reach again.
 *
 * The premise is asserted mechanically rather than described: the test issues
 * the combined statement itself and requires errno 1054 before judging the
 * guard. Both directions are covered — the refusal must appear, and the
 * DEGRADE must survive it (a write whose parent DOES exist still lands, with no
 * approval to re-pend).
 *
 * Skips with a stated reason when no database is reachable, and fails instead
 * of skipping when REQUIRE_INTEGRATION_DB=1.
 */
const { test, describe, before, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const net = require('node:net');
const http = require('node:http');
const express = require('express');
const mariadb = require('mariadb');

process.env.SETTINGS_ENCRYPTION_KEY = process.env.SETTINGS_ENCRYPTION_KEY
  || 'parent-guard-no-alter-db-test-key';

const TEST_PREFIX = 'pgna_';
const tbl = (name) => `${TEST_PREFIX}${name}`;

let pool = null;
const poolFacade = {
  getConnection: () => pool.getConnection(),
  query: (sql, params) => pool.query(sql, params),
};

// The double is DERIVED from the real module, not hand-listed: a partial stand-in
// for a module that grows a member is a fixture that ages into a silent hole.
const dbKey = require.resolve('../../src/edge/db');
const realDb = require('../../src/edge/db');
const realDbEntry = require.cache[dbKey];
require.cache[dbKey] = {
  ...realDbEntry,
  exports: {
    ...realDb,
    pool: { ro: poolFacade, rw: poolFacade },
    t: tbl,
    getDynamicPool: async () => ({ ro: poolFacade, rw: poolFacade }),
  },
};

const { buildEngineTableDDLs, buildInfraTableDDLs } = require('../../src/table-ddls');
const { TABLES } = require('../../src/shared/constants');
const stepsRouter = require('../../src/edge/routes/app/flow-recipe-steps');
const recipesRouter = require('../../src/edge/routes/app/flow-recipes');
const { fixtureUserId } = require('../helpers/fixture-ids');

// ── Config auto-detection (same shape as the sibling integration tests) ──────

function parseEnvFile(filePath) {
  try {
    const raw = fs.readFileSync(filePath, 'utf8');
    const out = {};
    for (const line of raw.split('\n')) {
      const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
      if (m) out[m[1]] = m[2].replace(/^["']|["']$/g, '');
    }
    return out;
  } catch {
    return null;
  }
}

function probePort(host, port, timeoutMs = 2000) {
  return new Promise((resolve) => {
    const socket = new net.Socket();
    let done = false;
    const finish = (ok) => {
      if (done) return;
      done = true;
      socket.destroy();
      resolve(ok);
    };
    socket.setTimeout(timeoutMs);
    socket.once('connect', () => finish(true));
    socket.once('timeout', () => finish(false));
    socket.once('error', () => finish(false));
    socket.connect(port, host);
  });
}

async function resolveMariaDbConfig() {
  if (process.env.DB_TEST_HOST && process.env.DB_TEST_ROOT_PASSWORD) {
    return {
      host: process.env.DB_TEST_HOST,
      port: parseInt(process.env.DB_TEST_PORT || '3306', 10),
      user: 'root',
      password: process.env.DB_TEST_ROOT_PASSWORD,
    };
  }
  const envPath = path.resolve(__dirname, '../../../.devcontainer/.env');
  const env = parseEnvFile(envPath);
  if (!env || !env.DB_ROOT_PASSWORD) return null;
  const port = parseInt(env.DB_PORT || '3306', 10);
  for (const host of ['127.0.0.1', 'mariadb', 'localhost']) {
    if (await probePort(host, port, 2000)) {
      return { host, port, user: 'root', password: env.DB_ROOT_PASSWORD };
    }
  }
  return null;
}

// ── Fixture ─────────────────────────────────────────────────────────────────

const ADMIN = { id: fixtureUserId('admin'), role: 'admin' };
const BLUEPRINT = '11111111-1111-4111-8111-111111111111';

const WANTED_TABLES = [
  TABLES.API_CONNECTORS,
  TABLES.FLOW_RECIPE_STEPS,
  TABLES.FLOW_RECIPES,
  TABLES.FLOW_RECIPE_CODE_VERSIONS,
  TABLES.HIERARCHY_NODES,
  TABLES.SYSTEM_SETTINGS,
  TABLES.FEATURE_AUDIT,
  TABLES.USERS,
];

// The approval surface `flow-recipes/approval.js` answers APPROVAL_UNAVAILABLE
// for. Dropping them reproduces the install, and the premise test below proves
// the drop actually defeated the statement the guard used to issue.
const ADDITIVE_APPROVAL_COLUMNS = ['status', 'approved_by', 'approved_at', 'review_note'];

let dbReady = false;
let skipReason = null;
let testDbName = null;
let server = null;
let baseUrl = null;

before(async () => {
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) {
    skipReason = 'no MariaDB reachable via .devcontainer/.env or env vars';
    if (process.env.REQUIRE_INTEGRATION_DB === '1') {
      throw new Error(`REQUIRE_INTEGRATION_DB=1 set but ${skipReason}.`);
    }
    return;
  }
  testDbName = `pg_noalter_${process.pid}_${Date.now()}`;
  let admin = null;
  try {
    admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`CREATE DATABASE \`${testDbName}\``);
    await admin.query(`USE \`${testDbName}\``);
    const wanted = new Set(WANTED_TABLES.map(tbl));
    const statements = [...buildInfraTableDDLs(tbl), ...buildEngineTableDDLs(tbl)].filter((sql) => {
      const m = sql.match(/CREATE TABLE IF NOT EXISTS `([^`]+)`/);
      return m && wanted.has(m[1]);
    });
    assert.equal(
      statements.length, wanted.size,
      `the DDL list no longer defines all of: ${[...wanted].join(', ')}`,
    );
    for (const sql of statements) await admin.query(sql);
    for (const col of ADDITIVE_APPROVAL_COLUMNS) {
      await admin.query(`ALTER TABLE \`${tbl(TABLES.FLOW_RECIPES)}\` DROP COLUMN \`${col}\``);
    }
    await admin.end();
    admin = null;

    pool = mariadb.createPool({
      ...dbConfig, database: testDbName, connectionLimit: 8, connectTimeout: 5000,
    });
    await pool.query(
      `INSERT INTO \`${tbl(TABLES.HIERARCHY_NODES)}\` (id, name, node_type, owner_id)
       VALUES (?, 'shared-blueprint', 'blueprint', NULL)`,
      [BLUEPRINT],
    );

    const app = express();
    app.use(express.json());
    app.use((req, _res, next) => { req.user = ADMIN; next(); });
    app.use('/edge/app/flow-recipe-steps', stepsRouter);
    app.use('/edge/app/flow-recipes', recipesRouter);
    server = http.createServer(app);
    await new Promise((r) => server.listen(0, r));
    baseUrl = `http://127.0.0.1:${server.address().port}`;
    dbReady = true;
  } catch (err) {
    skipReason = `setup failed: ${err.message}`;
    if (admin) { try { await admin.end(); } catch { /* best effort */ } }
    if (process.env.REQUIRE_INTEGRATION_DB === '1') throw err;
  }
});

after(async () => {
  if (server) { try { server.close(); } catch { /* best effort */ } }
  if (pool) { try { await pool.end(); } catch { /* best effort */ } }
  require.cache[dbKey] = realDbEntry;
  if (!testDbName) return;
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) return;
  try {
    const admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`DROP DATABASE IF EXISTS \`${testDbName}\``);
    await admin.end();
  } catch { /* best effort */ }
});

const guard = (t) => {
  if (!dbReady) { t.skip(skipReason || 'database not ready'); return true; }
  return false;
};

async function call(method, url, body) {
  const res = await fetch(`${baseUrl}${url}`, {
    method,
    headers: { 'content-type': 'application/json' },
    ...(body === undefined ? {} : { body: JSON.stringify(body) }),
  });
  const text = await res.text();
  let parsed = null;
  try { parsed = JSON.parse(text); } catch { parsed = { raw: text }; }
  return { status: res.status, body: parsed };
}

let seq = 0;
const uid = (tag) => `${tag}${String(seq += 1).padStart(4, '0')}-4444-4444-8444-444444444444`;

async function seedRecipe(id = uid('aaaa')) {
  await pool.query(
    `INSERT INTO \`${tbl(TABLES.FLOW_RECIPES)}\` (id, name, blueprint_id, owner_id)
     VALUES (?, 'r', ?, NULL)`,
    [id, BLUEPRINT],
  );
  return id;
}

const stepBody = (recipeId, over = {}) => ({
  recipe_id: recipeId,
  name: 'st',
  method: 'POST',
  url: 'https://upstream.test/v1/step',
  auth_type: 'bearer',
  auth_config: { token: 'the-real-step-token' },
  ...over,
});

const orphanCount = async () => Number((await pool.query(
  `SELECT COUNT(*) AS n FROM \`${tbl(TABLES.FLOW_RECIPE_STEPS)}\` s
   WHERE NOT EXISTS (SELECT 1 FROM \`${tbl(TABLES.FLOW_RECIPES)}\` r WHERE r.id = s.recipe_id)`,
))[0].n);

describe('the child write asks whether its parent is there on a DB without the approval columns', () => {
  test('PREMISE: the combined statement the guard used to issue is unaskable here', async (t) => {
    if (guard(t)) return;
    const recipeId = await seedRecipe();
    let errno = null;
    try {
      await pool.query(
        `SELECT \`status\` AS status, \`owner_id\` AS owner_id
         FROM \`${tbl(TABLES.FLOW_RECIPES)}\` WHERE id = ?`,
        [recipeId],
      );
    } catch (err) {
      errno = err && err.errno;
    }
    assert.equal(
      errno, 1054,
      'this fixture is not the degraded shape — the approval columns are still present',
    );
    // And the half that is NOT additive still answers, which is the whole point
    // of splitting the two questions.
    const rows = await pool.query(
      `SELECT id FROM \`${tbl(TABLES.FLOW_RECIPES)}\` WHERE id = ?`, [recipeId],
    );
    assert.equal(rows.length, 1, 'the existence question is answerable and was not asked');
  });

  test('a POST naming a recipe that never existed is refused, and stores nothing', async (t) => {
    if (guard(t)) return;
    const ghost = uid('eeee');
    const before = await orphanCount();
    const res = await call('POST', '/edge/app/flow-recipe-steps', stepBody(ghost));
    assert.equal(res.status, 404, `expected a refusal, got ${res.status}`);
    assert.equal(res.body.error && res.body.error.code, 'PARENT_NOT_FOUND');
    const rows = await pool.query(
      `SELECT id FROM \`${tbl(TABLES.FLOW_RECIPE_STEPS)}\` WHERE recipe_id = ?`, [ghost],
    );
    assert.equal(rows.length, 0, 'a refused create left a row behind');
    assert.equal(await orphanCount(), before, 'the orphan count moved on a refused create');
  });

  test('the DEGRADE survives the refusal: a write whose parent EXISTS still lands', async (t) => {
    if (guard(t)) return;
    const recipeId = await seedRecipe();
    const res = await call('POST', '/edge/app/flow-recipe-steps', stepBody(recipeId));
    assert.equal(
      res.status, 200,
      `the missing approval columns turned into a refusal: ${JSON.stringify(res.body)}`,
    );
    const rows = await pool.query(
      `SELECT id FROM \`${tbl(TABLES.FLOW_RECIPE_STEPS)}\` WHERE recipe_id = ?`, [recipeId],
    );
    assert.equal(rows.length, 1, 'the step did not store on the degraded DB');
    // A PUT on the same step degrades the same way — the re-pend has nothing to
    // clear and must not refuse for it.
    const put = await call('PUT', `/edge/app/flow-recipe-steps/${rows[0].id}`, { name: 'renamed' });
    assert.equal(put.status, 200, `a partial edit was refused: ${JSON.stringify(put.body)}`);
  });

  test('the interleaving that races a recipe DELETE leaves no orphan', async (t) => {
    if (guard(t)) return;
    const before = await orphanCount();
    const tally = {};
    for (let i = 0; i < 10; i += 1) {
      const recipeId = await seedRecipe();
      const [del, post] = await Promise.all([
        call('DELETE', `/edge/app/flow-recipes/${recipeId}`),
        call('POST', '/edge/app/flow-recipe-steps', stepBody(recipeId)),
      ]);
      const key = `recipeDEL=${del.status} stepPOST=${post.status}`;
      tally[key] = (tally[key] || 0) + 1;
    }
    assert.equal(
      await orphanCount(), before,
      `the race orphaned a step carrying a credential; outcomes: ${JSON.stringify(tally)}`,
    );
  });
});
