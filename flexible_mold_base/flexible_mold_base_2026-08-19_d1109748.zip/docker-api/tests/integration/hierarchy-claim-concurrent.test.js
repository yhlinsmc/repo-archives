/**
 * hierarchy-claim-concurrent.test.js — v3.2.110 PR-A (E-H1)
 *
 * Verifies that the v3.2.110 `POST /api/hierarchy_nodes/:id/claim`
 * endpoint serializes correctly under concurrent attempts. The endpoint
 * uses `SELECT ... FOR UPDATE` inside the applyOwnerChange helper to
 * lock the row before reading the current owner and committing the new
 * one — this test proves the lock actually holds when two editors race
 * for the same NULL-owned row.
 *
 * Why this exists (E-H1 from /autoplan review):
 *   The simpler version of this test — `Promise.all` over two claim
 *   attempts and assert one wins — passes even if FOR UPDATE is missing,
 *   because the UPDATE-with-NULL-guard would catch the conflict by itself
 *   ("UPDATE ... WHERE owner_id IS NULL" affecting 0 rows in the loser).
 *   This test adds a BARRIER: both transactions BEGIN and run their
 *   SELECT FOR UPDATE before either is allowed to commit. With FOR UPDATE
 *   in place the second SELECT blocks until the first COMMITs; without
 *   it both reads would see NULL and both UPDATEs would race.
 *
 * What this proves:
 *   1. Two concurrent claims on the same NULL row produce exactly one
 *      audit row, not two — torn write detection.
 *   2. Final owner_id is one of the two editors (never NULL, never
 *      half-updated).
 *   3. The loser's SELECT FOR UPDATE waits for the winner's commit then
 *      observes priorOwner = winner.id — which the helper maps to
 *      conflict_reason='NOT_NULL' and the route returns 409 ALREADY_OWNED.
 *
 * Skips gracefully when no MariaDB is reachable (same logic as
 * transformer-owner-transfer-concurrent.test.js). REQUIRE_INTEGRATION_DB=1
 * promotes skip to failure for CI.
 *
 * Zero new npm dependencies — uses the same `mariadb` driver already in
 * docker-api/package.json. AIRGAP-clean.
 */

const { test, describe, before, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const net = require('node:net');
const mariadb = require('mariadb');
const { applyOwnerChange } = require('../../src/edge/services/ownership');
const { TABLES } = require('../../src/shared/constants');

const TEST_PREFIX = 'hcc_'; // hierarchy claim concurrent

function parseEnvFile(filePath) {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    const out = {};
    for (const line of content.split('\n')) {
      const m = line.match(/^\s*([A-Z_][A-Z0-9_]*)\s*=\s*(.*)\s*$/);
      if (!m) continue;
      let value = m[2];
      if ((value.startsWith('"') && value.endsWith('"')) ||
          (value.startsWith("'") && value.endsWith("'"))) {
        value = value.slice(1, -1);
      }
      out[m[1]] = value;
    }
    return out;
  } catch {
    return null;
  }
}

function probePort(host, port, timeoutMs = 2000) {
  return new Promise((resolve) => {
    const socket = new net.Socket();
    let done = false;
    const finish = (ok) => {
      if (done) return;
      done = true;
      socket.destroy();
      resolve(ok);
    };
    socket.setTimeout(timeoutMs);
    socket.once('connect', () => finish(true));
    socket.once('timeout', () => finish(false));
    socket.once('error', () => finish(false));
    socket.connect(port, host);
  });
}

async function resolveMariaDbConfig() {
  if (process.env.DB_TEST_HOST && process.env.DB_TEST_ROOT_PASSWORD) {
    return {
      host: process.env.DB_TEST_HOST,
      port: parseInt(process.env.DB_TEST_PORT || '3306', 10),
      user: 'root',
      password: process.env.DB_TEST_ROOT_PASSWORD,
    };
  }
  const envPath = path.resolve(__dirname, '../../../.devcontainer/.env');
  const env = parseEnvFile(envPath);
  if (!env || !env.DB_ROOT_PASSWORD) return null;
  const port = parseInt(env.DB_PORT || '3306', 10);
  const password = env.DB_ROOT_PASSWORD;
  const candidates = ['127.0.0.1', 'mariadb', 'localhost'];
  for (const host of candidates) {
    if (await probePort(host, port, 2000)) {
      return { host, port, user: 'root', password };
    }
  }
  return null;
}

const HIERARCHY_DDL = `
  CREATE TABLE \`${TEST_PREFIX}hierarchy_nodes\` (
    id              CHAR(36)     PRIMARY KEY,
    parent_id       CHAR(36)     NULL,
    node_type       VARCHAR(32)  NOT NULL DEFAULT 'blueprint',
    name            VARCHAR(255) NOT NULL,
    description     TEXT,
    is_active       BOOLEAN      NOT NULL DEFAULT TRUE,
    sort_order      INT          NOT NULL DEFAULT 0,
    created_by      VARCHAR(255),
    updated_by      VARCHAR(255),
    owner_id        CHAR(36)     NULL DEFAULT NULL,
    created_at      TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
`;

const FEATURE_AUDIT_DDL = `
  CREATE TABLE \`${TEST_PREFIX}feature_audit\` (
    id          CHAR(36)     PRIMARY KEY,
    event_type  VARCHAR(64)  NOT NULL,
    user_id     VARCHAR(255),
    metadata    JSON,
    created_at  TIMESTAMP    DEFAULT CURRENT_TIMESTAMP
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
`;

const EDITOR1_ID = 'editor-test-1111';
const EDITOR2_ID = 'editor-test-2222';
const TARGET_ROW_ID = 'blueprint-target-id';
const AUDIT_EVENT = 'blueprint.owner.transfer';

const testT = (name) => `${TEST_PREFIX}${name}`;

let dbReady = false;
let dbConfig = null;
let testDbName = null;
let skipReason = null;
let pool = null;

before(async () => {
  dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) {
    skipReason = 'no MariaDB reachable via .devcontainer/.env or env vars';
    if (process.env.REQUIRE_INTEGRATION_DB === '1') {
      throw new Error(`REQUIRE_INTEGRATION_DB=1 set but ${skipReason}`);
    }
    return;
  }

  testDbName = `v32110_test_claim_${process.pid}_${Date.now()}`;
  let adminConn = null;
  try {
    adminConn = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await adminConn.query(`CREATE DATABASE \`${testDbName}\``);
    await adminConn.query(`USE \`${testDbName}\``);
    await adminConn.query(HIERARCHY_DDL);
    await adminConn.query(FEATURE_AUDIT_DDL);
    await adminConn.query(
      `INSERT INTO \`${TEST_PREFIX}hierarchy_nodes\`
        (id, node_type, name, is_active, sort_order, owner_id)
       VALUES (?, 'blueprint', 'TestBlueprint', TRUE, 0, NULL)`,
      [TARGET_ROW_ID],
    );
    await adminConn.end();
    adminConn = null;

    pool = mariadb.createPool({
      ...dbConfig,
      database: testDbName,
      connectionLimit: 4,
      connectTimeout: 5000,
    });

    dbReady = true;
  } catch (err) {
    skipReason = `setup failed: ${err.message}`;
    if (adminConn) { try { await adminConn.end(); } catch {} }
    if (testDbName) {
      try {
        const cleanup = await mariadb.createConnection(dbConfig);
        await cleanup.query(`DROP DATABASE IF EXISTS \`${testDbName}\``);
        await cleanup.end();
      } catch {}
      testDbName = null;
    }
    if (process.env.REQUIRE_INTEGRATION_DB === '1') throw err;
  }
});

after(async () => {
  if (pool) {
    try { await pool.end(); } catch {}
    pool = null;
  }
  if (testDbName && dbConfig) {
    try {
      const cleanup = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
      await cleanup.query(`DROP DATABASE IF EXISTS \`${testDbName}\``);
      await cleanup.end();
    } catch (err) {
      console.error(`[teardown] failed to drop ${testDbName}: ${err.message}`);
    }
  }
});

/**
 * E-H1 barrier helper.
 *
 * Each "side" of the race acquires its own pool connection, begins a
 * transaction, then awaits `arrived()` before issuing the SELECT FOR
 * UPDATE. `arrived()` blocks until BOTH sides have reached the barrier,
 * so the SELECTs run with maximum overlap. Without FOR UPDATE both would
 * see priorOwner=NULL; with FOR UPDATE the second SELECT blocks until
 * the first transaction commits.
 */
function makeBarrier(n) {
  let waiters = 0;
  let resolveAll;
  const allArrived = new Promise((resolve) => { resolveAll = resolve; });
  return async function arrive() {
    waiters += 1;
    if (waiters >= n) resolveAll();
    await allArrived;
  };
}

async function claimWithBarrier(arrive, actorId) {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    // Wait until the other side is also inside its transaction before
    // issuing the SELECT FOR UPDATE — this exposes the race surface.
    await arrive();
    const result = await applyOwnerChange(conn, TABLES.HIERARCHY_NODES, TARGET_ROW_ID, actorId, {
      actor: { id: actorId, role: 'editor' },
      action: 'claim',
      requireCondition: 'null',
      auditEventType: AUDIT_EVENT,
      t: testT,
    });
    await conn.commit();
    return result;
  } catch (err) {
    try { await conn.rollback(); } catch {}
    return { changed: false, error: err.message };
  } finally {
    conn.release();
  }
}

describe('hierarchy_nodes claim — concurrent FOR UPDATE serialization (v3.2.110 E-H1)', () => {
  test('two concurrent claims on the same NULL row produce exactly one winner + one 409 loser', async (t) => {
    if (!dbReady) { t.skip(skipReason); return; }

    // Pre-state assertion: owner is NULL
    const conn0 = await pool.getConnection();
    try {
      const rows = await conn0.query(
        `SELECT owner_id FROM \`${TEST_PREFIX}hierarchy_nodes\` WHERE id = ?`,
        [TARGET_ROW_ID],
      );
      assert.equal(rows.length, 1);
      assert.equal(rows[0].owner_id, null);
    } finally {
      conn0.release();
    }

    const barrier = makeBarrier(2);
    const [r1, r2] = await Promise.all([
      claimWithBarrier(barrier, EDITOR1_ID),
      claimWithBarrier(barrier, EDITOR2_ID),
    ]);

    // Exactly one changed=true, one conflict
    const winners = [r1, r2].filter((r) => r.changed === true);
    const losers = [r1, r2].filter((r) => r.conflict_reason === 'NOT_NULL');
    assert.equal(winners.length, 1, `expected exactly 1 winner, got ${winners.length}: ${JSON.stringify([r1, r2])}`);
    assert.equal(losers.length, 1, `expected exactly 1 NOT_NULL loser, got ${losers.length}: ${JSON.stringify([r1, r2])}`);

    // Final owner must be the winner's actor id, not NULL, not both editors at once
    const conn1 = await pool.getConnection();
    let finalOwner;
    try {
      const rows = await conn1.query(
        `SELECT owner_id FROM \`${TEST_PREFIX}hierarchy_nodes\` WHERE id = ?`,
        [TARGET_ROW_ID],
      );
      finalOwner = rows[0].owner_id;
    } finally {
      conn1.release();
    }
    assert.notEqual(finalOwner, null, 'final owner must not be NULL after both attempts');
    assert.equal(finalOwner, winners[0].new_owner, 'final DB owner must match winner');

    // Exactly one audit row was written
    const conn2 = await pool.getConnection();
    let auditRows;
    try {
      auditRows = await conn2.query(
        `SELECT id, event_type, metadata FROM \`${TEST_PREFIX}feature_audit\``,
      );
    } finally {
      conn2.release();
    }
    assert.equal(auditRows.length, 1, `expected exactly 1 audit row, got ${auditRows.length}`);
    const meta = typeof auditRows[0].metadata === 'string'
      ? JSON.parse(auditRows[0].metadata)
      : auditRows[0].metadata;
    assert.equal(meta.action, 'claim');
    assert.equal(meta.new_owner_id, winners[0].new_owner);
    assert.equal(meta.old_owner_id, null);
  });

  test('idempotent re-claim by current owner returns idempotent_same_actor without new audit row', async (t) => {
    if (!dbReady) { t.skip(skipReason); return; }
    // Continuation: row is now owned by whoever won the prior race.
    const conn = await pool.getConnection();
    let currentOwner;
    try {
      const rows = await conn.query(
        `SELECT owner_id FROM \`${TEST_PREFIX}hierarchy_nodes\` WHERE id = ?`,
        [TARGET_ROW_ID],
      );
      currentOwner = rows[0].owner_id;
    } finally {
      conn.release();
    }

    const conn2 = await pool.getConnection();
    let result;
    try {
      await conn2.beginTransaction();
      result = await applyOwnerChange(conn2, TABLES.HIERARCHY_NODES, TARGET_ROW_ID, currentOwner, {
        actor: { id: currentOwner, role: 'editor' },
        action: 'claim',
        requireCondition: 'null',
        auditEventType: AUDIT_EVENT,
        t: testT,
      });
      await conn2.commit();
    } finally {
      conn2.release();
    }

    assert.equal(result.changed, false);
    assert.equal(result.idempotent_same_actor, true);

    const conn3 = await pool.getConnection();
    let auditRows;
    try {
      auditRows = await conn3.query(`SELECT id FROM \`${TEST_PREFIX}feature_audit\``);
    } finally {
      conn3.release();
    }
    assert.equal(auditRows.length, 1, 'idempotent re-claim must not write a new audit row');
  });
});
