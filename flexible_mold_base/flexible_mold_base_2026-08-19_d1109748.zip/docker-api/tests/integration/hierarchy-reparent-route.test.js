'use strict';

/**
 * hierarchy-reparent-route.test.js
 *
 * Route-level tests for the two blueprint reparent endpoints:
 *   POST /hierarchy_nodes/:id/reparent-preview
 *   POST /hierarchy_nodes/:id/reparent
 *
 * Harness mirrors schema-factory-parent-ownership.test.js:
 * - require.cache injection to stub the DB module before loading the router.
 * - Express app bootstrapped against a real HTTP server on an ephemeral port.
 * - makeConn() script runner for per-test query mocking.
 * - node:test runner (matches docker-api/tests runner).
 */

const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

// ── DB stub must be in cache BEFORE the router is required ───────────────────
const dbKey = require.resolve('../../src/edge/db');

// portable-insert caches columns in a module-level Map. Clear it between tests
// so stubs from one test don't pollute the next.
const portableInsertKey = require.resolve('../../src/edge/lib/portable-insert');

let conn;

function makeConn(scripts) {
  const queries = [];
  return {
    queries,
    async query(sql, params) {
      queries.push({ sql, params });
      for (const [matcher, response] of scripts) {
        if (matcher.test(sql)) {
          return typeof response === 'function' ? response(sql, params) : response;
        }
      }
      // Linked-blueprint write guard probes — default to "not linked"
      if (/SELECT linked_blueprint_id FROM/.test(sql)) return [];
      if (/ AS bid FROM/.test(sql) || / AS fk FROM/.test(sql)) return [];
      // The owner precondition is asked of the COLUMN — `owner_id` is
      // `CHAR(36)` under a case-folding collation and the SQL write scope on
      // the same table folds too, so a JavaScript `!==` here would refuse the
      // genuine owner of a row whose column holds another spelling of their id.
      // The probe is answered the way `utf8mb4_general_ci` answers it, not
      // waved through with a constant: a stub returning a fixed `same` would be
      // deciding the 403-vs-200 branch these tests are about.
      if (/SELECT DATABASE\(\)/.test(sql)) return [{ db: 'reparent_test_db' }];
      if (/information_schema\.COLUMNS/.test(sql)) {
        return [{ cs: 'utf8mb4', co: 'utf8mb4_general_ci' }];
      }
      if (/<=>/.test(sql)) {
        const [a, b] = params;
        return [{ same: String(a).toLowerCase() === String(b).toLowerCase() ? 1 : 0 }];
      }
      throw new Error(`Unmatched query in reparent test: ${sql.slice(0, 120)}`);
    },
    release() { /* noop */ },
    async beginTransaction() {},
    async commit() {},
    async rollback() {},
  };
}

const poolSpy = {
  rw: { async getConnection() { return conn; } },
  ro: { async getConnection() { return conn; } },
};

require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: {
    pool: poolSpy,
    t: (name) => `fmb_${name}`,
    getDynamicPool: async () => poolSpy,
  },
};

const router = require('../../src/edge/routes/app/schema');
const { _clearColumnCollationCache } = require('../../src/edge/routes/app/schema/write-value');

// ── HTTP server ───────────────────────────────────────────────────────────────
let adminServer, adminPort;
let editorServer, editorPort;

function makeApp(role, userId) {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => {
    req.user = { id: userId || `${role}-1`, role };
    next();
  });
  app.use('/edge/app/schema', router);
  return app;
}

before(async () => {
  await new Promise((resolve) => {
    adminServer = makeApp('admin', 'admin-uuid-1').listen(0, '127.0.0.1', () => {
      adminPort = adminServer.address().port;
      resolve();
    });
  });
  await new Promise((resolve) => {
    editorServer = makeApp('editor', 'editor-uuid-1').listen(0, '127.0.0.1', () => {
      editorPort = editorServer.address().port;
      resolve();
    });
  });
});

after(async () => {
  await new Promise((resolve) => adminServer.close(resolve));
  await new Promise((resolve) => editorServer.close(resolve));
  delete require.cache[dbKey];
});

beforeEach(() => {
  conn = null;
  // Clear the portable-insert column cache so each test gets fresh stub results
  if (require.cache[portableInsertKey]) {
    const mod = require.cache[portableInsertKey].exports;
    if (typeof mod.__clearPortableColumnCache === 'function') mod.__clearPortableColumnCache();
  }
  // Same reason as above for the collation probe: it memoises per
  // schema.table.column, so a cached entry would make the query script a test
  // sees depend on which test ran before it.
  _clearColumnCollationCache();
});

// ── HTTP helpers ──────────────────────────────────────────────────────────────
function post(port, path, body) {
  return new Promise((resolve, reject) => {
    const data = JSON.stringify(body);
    const req = http.request({
      method: 'POST', host: '127.0.0.1', port, path,
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(data) },
    }, (res) => {
      let raw = '';
      res.on('data', (chunk) => { raw += chunk; });
      res.on('end', () => resolve({ status: res.statusCode, body: JSON.parse(raw) }));
    });
    req.on('error', reject);
    req.write(data);
    req.end();
  });
}

// ── Common fixtures ───────────────────────────────────────────────────────────
const BLUEPRINT_ID  = '11111111-1111-4111-8111-111111111111';
const RELEASE_ID    = '22222222-2222-4222-8222-222222222222';
const CATEGORY_ID   = '33333333-3333-4333-8333-333333333333';
const OTHER_BP_ID   = '44444444-4444-4444-8444-444444444444';
const DESCENDANT_ID = '55555555-5555-4555-8555-555555555555';
const CHILD_ID      = '66666666-6666-4666-8666-666666666666';
const VARIANT_ID    = '77777777-7777-4777-8777-777777777777';

function blueprintRow(overrides = {}) {
  return { id: BLUEPRINT_ID, node_type: 'blueprint', owner_id: null, parent_id: RELEASE_ID, ...overrides };
}

function releaseRow(overrides = {}) {
  return { id: RELEASE_ID, node_type: 'release', is_active: 1, parent_id: CATEGORY_ID, ...overrides };
}

// collectDescendantIds uses iterative BFS: `SELECT id FROM ... WHERE parent_id IN (?)`.
// The SQL spans two lines so the regex uses the /s flag to match newlines.
// The stub returns [] so every BFS iteration terminates immediately.
const NO_DESCENDANTS = [/SELECT id FROM[\s\S]* WHERE parent_id IN/, []];

// Scripts for reparent-preview happy path (shared/NULL-owned blueprint).
function previewScripts({ ownerOverride } = {}) {
  return [
    // validateReparent: blueprint SELECT FOR UPDATE
    [/SELECT id, node_type, owner_id.* FROM .* FOR UPDATE/, [blueprintRow({ owner_id: ownerOverride ?? null })]],
    // validateReparent: target parent SELECT
    [/SELECT id, node_type, is_active FROM .* WHERE id = \?/, [releaseRow()]],
    // collectDescendantIds: BFS terminates immediately (no children)
    NO_DESCENDANTS,
    // countAffectedTemplates: list query (returns 3 rows, under the 500 cap)
    [/SELECT id, name FROM[\s\S]*user_templates/i, [
      { id: 'tpl-1', name: 'Alpha' },
      { id: 'tpl-2', name: 'Beta' },
      { id: 'tpl-3', name: 'Gamma' },
    ]],
    // pathLabel for blueprint node (walks up: blueprint → release → category)
    // pathLabel for target parent (walks up: release → category)
    // Both paths share the same walk logic; matcher handles both.
    [/SELECT name, parent_id FROM/, (_sql, params) => {
      const id = params[0];
      if (id === BLUEPRINT_ID)  return [{ name: 'MyBlueprint', parent_id: RELEASE_ID }];
      if (id === RELEASE_ID)    return [{ name: 'Release A', parent_id: CATEGORY_ID }];
      if (id === CATEGORY_ID)   return [{ name: 'Category X', parent_id: null }];
      return [];
    }],
  ];
}

// Scripts for the reparent (transactional) happy path.
function reparentScripts({ ownerOverride } = {}) {
  return [
    // validateReparent: blueprint SELECT FOR UPDATE
    [/SELECT id, node_type, owner_id.* FROM .* FOR UPDATE/, [blueprintRow({ owner_id: ownerOverride ?? null })]],
    // validateReparent: target parent SELECT
    [/SELECT id, node_type, is_active FROM .* WHERE id = \?/, [releaseRow()]],
    // collectDescendantIds: no children
    NO_DESCENDANTS,
    // UPDATE parent_id
    [/UPDATE .* SET parent_id = \? WHERE id = \?/, { affectedRows: 1 }],
    // resolveAncestors: walks new parent's chain (release → category)
    [/SELECT id, node_type, parent_id FROM/, (_sql, params) => {
      const id = params[0];
      if (id === RELEASE_ID)  return [{ id: RELEASE_ID,  node_type: 'release',  parent_id: CATEGORY_ID }];
      if (id === CATEGORY_ID) return [{ id: CATEGORY_ID, node_type: 'category', parent_id: null }];
      return [];
    }],
    // restampTemplates: UPDATE user_templates
    [/UPDATE .* SET release_id/, { affectedRows: 3 }],
    // feature_audit INSERT
    [/feature_audit/, { affectedRows: 1 }],
  ];
}

// ── Tests ─────────────────────────────────────────────────────────────────────

describe('POST /hierarchy_nodes/:id/reparent-preview', () => {
  it('admin moves a shared blueprint to valid release → 200 with affectedTemplates', async () => {
    conn = makeConn(previewScripts());
    const res = await post(adminPort, `/edge/app/schema/hierarchy_nodes/${BLUEPRINT_ID}/reparent-preview`,
      { newParentId: RELEASE_ID });
    assert.equal(res.status, 200, JSON.stringify(res.body));
    assert.equal(res.body.data.affectedTemplates, 3);
    assert.ok(Array.isArray(res.body.data.affectedTemplateList), 'affectedTemplateList must be an array');
    assert.equal(res.body.data.affectedTemplateList.length, 3);
    assert.ok(res.body.data.oldPath.includes('MyBlueprint'), `oldPath: ${res.body.data.oldPath}`);
    assert.ok(res.body.data.newPath.includes('MyBlueprint'), `newPath: ${res.body.data.newPath}`);
    // Preview must NOT issue UPDATE parent_id
    const updates = conn.queries.filter((q) => /SET parent_id/.test(q.sql));
    assert.equal(updates.length, 0, 'preview must not UPDATE parent_id');
  });

  it('editor trying to preview a move of a blueprint owned by someone else → 403', async () => {
    conn = makeConn([
      [/SELECT id, node_type, owner_id.* FROM .* FOR UPDATE/, [blueprintRow({ owner_id: 'other-editor-id' })]],
      [/SELECT id, node_type, is_active FROM .* WHERE id = \?/, [releaseRow()]],
      NO_DESCENDANTS,
    ]);
    const res = await post(editorPort, `/edge/app/schema/hierarchy_nodes/${BLUEPRINT_ID}/reparent-preview`,
      { newParentId: RELEASE_ID });
    assert.equal(res.status, 403, JSON.stringify(res.body));
    assert.equal(res.body.error.code, 'FORBIDDEN');
  });

  it('node is not a blueprint → 400', async () => {
    conn = makeConn([
      [/SELECT id, node_type, owner_id.* FROM .* FOR UPDATE/, [{ id: BLUEPRINT_ID, node_type: 'release', owner_id: null }]],
      [/SELECT id, node_type, is_active FROM .* WHERE id = \?/, [releaseRow()]],
      NO_DESCENDANTS,
    ]);
    const res = await post(adminPort, `/edge/app/schema/hierarchy_nodes/${BLUEPRINT_ID}/reparent-preview`,
      { newParentId: RELEASE_ID });
    assert.equal(res.status, 400, JSON.stringify(res.body));
    assert.equal(res.body.error.code, 'BAD_REQUEST');
  });

  it('newParentId equals blueprint id (self-move) → 400', async () => {
    conn = makeConn([]);
    const res = await post(adminPort, `/edge/app/schema/hierarchy_nodes/${BLUEPRINT_ID}/reparent-preview`,
      { newParentId: BLUEPRINT_ID });
    assert.equal(res.status, 400, JSON.stringify(res.body));
    assert.equal(res.body.error.code, 'BAD_REQUEST');
  });

  it('target node_type is blueprint (not category/release) → 400', async () => {
    conn = makeConn([
      [/SELECT id, node_type, owner_id.* FROM .* FOR UPDATE/, [blueprintRow()]],
      [/SELECT id, node_type, is_active FROM .* WHERE id = \?/, [{ id: OTHER_BP_ID, node_type: 'blueprint', is_active: 1 }]],
      NO_DESCENDANTS,
    ]);
    const res = await post(adminPort, `/edge/app/schema/hierarchy_nodes/${BLUEPRINT_ID}/reparent-preview`,
      { newParentId: OTHER_BP_ID });
    assert.equal(res.status, 400, JSON.stringify(res.body));
    assert.equal(res.body.error.code, 'BAD_REQUEST');
  });

  it('target is a category (wrong tier) → 400', async () => {
    conn = makeConn([
      [/SELECT id, node_type, owner_id.* FROM .* FOR UPDATE/, [blueprintRow()]],
      [/SELECT id, node_type, is_active FROM .* WHERE id = \?/, [{ id: CATEGORY_ID, node_type: 'category', is_active: 1 }]],
      NO_DESCENDANTS,
    ]);
    const res = await post(adminPort, `/edge/app/schema/hierarchy_nodes/${BLUEPRINT_ID}/reparent-preview`,
      { newParentId: CATEGORY_ID });
    assert.equal(res.status, 400, JSON.stringify(res.body));
    assert.match(res.body.error.message, /Release/);
  });

  it('newParentId is a descendant (cycle guard) → 400', async () => {
    conn = makeConn([
      [/SELECT id, node_type, owner_id.* FROM .* FOR UPDATE/, [blueprintRow()]],
      // Stub as release so the tier guard passes; cycle detection fires next
      [/SELECT id, node_type, is_active FROM .* WHERE id = \?/, [{ id: DESCENDANT_ID, node_type: 'release', is_active: 1 }]],
      // BFS first iteration returns the descendant id, proving cycle
      [/SELECT id FROM[\s\S]* WHERE parent_id IN/, [{ id: DESCENDANT_ID }]],
    ]);
    const res = await post(adminPort, `/edge/app/schema/hierarchy_nodes/${BLUEPRINT_ID}/reparent-preview`,
      { newParentId: DESCENDANT_ID });
    assert.equal(res.status, 400, JSON.stringify(res.body));
    assert.ok(res.body.error.message.includes('descendant'), `message: ${res.body.error.message}`);
  });
});

describe('POST /hierarchy_nodes/:id/reparent', () => {
  it('admin moves a shared blueprint → 200 with restamped count', async () => {
    conn = makeConn(reparentScripts());
    const res = await post(adminPort, `/edge/app/schema/hierarchy_nodes/${BLUEPRINT_ID}/reparent`,
      { newParentId: RELEASE_ID });
    assert.equal(res.status, 200, JSON.stringify(res.body));
    assert.equal(res.body.data.ok, true);
    assert.equal(res.body.data.parent_id, RELEASE_ID);
    assert.equal(typeof res.body.data.restamped, 'number');
    // UPDATE parent_id must have been called exactly once
    const updates = conn.queries.filter((q) => /SET parent_id/.test(q.sql));
    assert.equal(updates.length, 1, 'must UPDATE parent_id exactly once');
    // Audit INSERT must have been called
    const audits = conn.queries.filter((q) => /feature_audit/.test(q.sql));
    assert.equal(audits.length, 1, 'must INSERT one audit row');
  });

  it('editor moving their OWN blueprint → 200', async () => {
    conn = makeConn(reparentScripts({ ownerOverride: 'editor-uuid-1' }));
    const res = await post(editorPort, `/edge/app/schema/hierarchy_nodes/${BLUEPRINT_ID}/reparent`,
      { newParentId: RELEASE_ID });
    assert.equal(res.status, 200, JSON.stringify(res.body));
    assert.equal(res.body.data.ok, true);
  });

  it('editor moving a blueprint owned by someone else → 403', async () => {
    conn = makeConn([
      [/SELECT id, node_type, owner_id.* FROM .* FOR UPDATE/, [blueprintRow({ owner_id: 'stranger-uuid' })]],
      [/SELECT id, node_type, is_active FROM .* WHERE id = \?/, [releaseRow()]],
      NO_DESCENDANTS,
    ]);
    const res = await post(editorPort, `/edge/app/schema/hierarchy_nodes/${BLUEPRINT_ID}/reparent`,
      { newParentId: RELEASE_ID });
    assert.equal(res.status, 403, JSON.stringify(res.body));
    assert.equal(res.body.error.code, 'FORBIDDEN');
  });

  it('node is not a blueprint → 400', async () => {
    conn = makeConn([
      [/SELECT id, node_type, owner_id.* FROM .* FOR UPDATE/, [{ id: BLUEPRINT_ID, node_type: 'category', owner_id: null }]],
      [/SELECT id, node_type, is_active FROM .* WHERE id = \?/, [releaseRow()]],
      NO_DESCENDANTS,
    ]);
    const res = await post(adminPort, `/edge/app/schema/hierarchy_nodes/${BLUEPRINT_ID}/reparent`,
      { newParentId: RELEASE_ID });
    assert.equal(res.status, 400, JSON.stringify(res.body));
    assert.equal(res.body.error.code, 'BAD_REQUEST');
  });

  it('newParentId equals nodeId → 400', async () => {
    conn = makeConn([]);
    const res = await post(adminPort, `/edge/app/schema/hierarchy_nodes/${BLUEPRINT_ID}/reparent`,
      { newParentId: BLUEPRINT_ID });
    assert.equal(res.status, 400, JSON.stringify(res.body));
    assert.equal(res.body.error.code, 'BAD_REQUEST');
  });

  it('target has node_type variant → 400', async () => {
    conn = makeConn([
      [/SELECT id, node_type, owner_id.* FROM .* FOR UPDATE/, [blueprintRow()]],
      [/SELECT id, node_type, is_active FROM .* WHERE id = \?/, [{ id: VARIANT_ID, node_type: 'variant', is_active: 1 }]],
      NO_DESCENDANTS,
    ]);
    const res = await post(adminPort, `/edge/app/schema/hierarchy_nodes/${BLUEPRINT_ID}/reparent`,
      { newParentId: VARIANT_ID });
    assert.equal(res.status, 400, JSON.stringify(res.body));
    assert.equal(res.body.error.code, 'BAD_REQUEST');
  });

  it('target is a category (wrong tier) → 400', async () => {
    conn = makeConn([
      [/SELECT id, node_type, owner_id.* FROM .* FOR UPDATE/, [blueprintRow()]],
      [/SELECT id, node_type, is_active FROM .* WHERE id = \?/, [{ id: CATEGORY_ID, node_type: 'category', is_active: 1 }]],
      NO_DESCENDANTS,
    ]);
    const res = await post(adminPort, `/edge/app/schema/hierarchy_nodes/${BLUEPRINT_ID}/reparent`,
      { newParentId: CATEGORY_ID });
    assert.equal(res.status, 400, JSON.stringify(res.body));
    assert.match(res.body.error.message, /Release/);
  });

  it('newParentId is a descendant (cycle guard) → 400', async () => {
    conn = makeConn([
      [/SELECT id, node_type, owner_id.* FROM .* FOR UPDATE/, [blueprintRow()]],
      // Stub as release so the tier guard passes; cycle detection fires next
      [/SELECT id, node_type, is_active FROM .* WHERE id = \?/, [{ id: CHILD_ID, node_type: 'release', is_active: 1 }]],
      // BFS first iteration returns the child id, so CHILD_ID is in descendants
      [/SELECT id FROM[\s\S]* WHERE parent_id IN/, [{ id: CHILD_ID }]],
    ]);
    const res = await post(adminPort, `/edge/app/schema/hierarchy_nodes/${BLUEPRINT_ID}/reparent`,
      { newParentId: CHILD_ID });
    assert.equal(res.status, 400, JSON.stringify(res.body));
    assert.ok(res.body.error.message.includes('descendant'), `message: ${res.body.error.message}`);
  });
});
