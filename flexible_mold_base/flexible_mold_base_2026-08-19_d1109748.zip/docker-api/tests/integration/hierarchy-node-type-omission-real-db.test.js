'use strict';

/**
 * hierarchy-node-type-omission-real-db.test.js — the value a guard never saw.
 *
 * `hierarchy_nodes.node_type` is `ENUM('category','release','blueprint','variant')
 * NOT NULL` with no declared DEFAULT, and MariaDB gives such a column an implicit
 * default of the FIRST member — 'category'. That is precisely the top tier the
 * mount's value guard forbids an editor.
 *
 * The guard reads `data[col]` and every arm of it is conditioned on the value
 * being present, so a body that simply leaves the column out is not judged at
 * all, while the INSERT that follows omits the column and lets the database
 * choose. Same destination as spelling the column with a capital letter, reached
 * without spelling it at all.
 *
 * THIS RUNS ON A REAL DATABASE BECAUSE THE DEFECT IS THE DATABASE'S ANSWER. A
 * stubbed driver returns whatever the fixture was told to return, so it can
 * neither show the implicit default nor prove it is gone; the premise under test
 * is what MariaDB does with a column nobody named.
 *
 * Skips with a stated reason when no database is reachable, and fails instead of
 * skipping when REQUIRE_INTEGRATION_DB=1.
 */
const { test, describe, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const net = require('node:net');
const http = require('node:http');
const express = require('express');
const mariadb = require('mariadb');

const TEST_PREFIX = 'hno_';
const tbl = (name) => `${TEST_PREFIX}${name}`;

let pool = null;
const lease = () => pool.getConnection();

const dbKey = require.resolve('../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey,
  filename: dbKey,
  loaded: true,
  exports: {
    pool: { ro: { getConnection: lease }, rw: { getConnection: lease } },
    t: tbl,
    getDynamicPool: async () => ({ ro: { getConnection: lease }, rw: { getConnection: lease } }),
  },
};

const { buildEngineTableDDLs } = require('../../src/table-ddls');
const { TABLES } = require('../../src/shared/constants');
const schemaRouter = require('../../src/edge/routes/app/schema');

const { fixtureUserId } = require('../helpers/fixture-ids');
// ── Config auto-detection (same shape as the sibling integration tests) ──────

function parseEnvFile(filePath) {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    const out = {};
    for (const line of content.split('\n')) {
      const m = line.match(/^\s*([A-Z_][A-Z0-9_]*)\s*=\s*(.*)\s*$/);
      if (!m) continue;
      let value = m[2];
      if ((value.startsWith('"') && value.endsWith('"'))
        || (value.startsWith("'") && value.endsWith("'"))) {
        value = value.slice(1, -1);
      }
      out[m[1]] = value;
    }
    return out;
  } catch {
    return null;
  }
}

function probePort(host, port, timeoutMs = 2000) {
  return new Promise((resolve) => {
    const socket = new net.Socket();
    let done = false;
    const finish = (ok) => {
      if (done) return;
      done = true;
      socket.destroy();
      resolve(ok);
    };
    socket.setTimeout(timeoutMs);
    socket.once('connect', () => finish(true));
    socket.once('timeout', () => finish(false));
    socket.once('error', () => finish(false));
    socket.connect(port, host);
  });
}

async function resolveMariaDbConfig() {
  if (process.env.DB_TEST_HOST && process.env.DB_TEST_ROOT_PASSWORD) {
    return {
      host: process.env.DB_TEST_HOST,
      port: parseInt(process.env.DB_TEST_PORT || '3306', 10),
      user: 'root',
      password: process.env.DB_TEST_ROOT_PASSWORD,
    };
  }
  const envPath = path.resolve(__dirname, '../../../.devcontainer/.env');
  const env = parseEnvFile(envPath);
  if (!env || !env.DB_ROOT_PASSWORD) return null;
  const port = parseInt(env.DB_PORT || '3306', 10);
  for (const host of ['127.0.0.1', 'mariadb', 'localhost']) {
    if (await probePort(host, port, 2000)) {
      return { host, port, user: 'root', password: env.DB_ROOT_PASSWORD };
    }
  }
  return null;
}

// ── Fixture ─────────────────────────────────────────────────────────────────

const EDITOR = { id: fixtureUserId('editor'), role: 'editor' };
const ADMIN = { id: fixtureUserId('admin'), role: 'admin' };

let dbReady = false;
let skipReason = null;
let testDbName = null;
let server = null;
let baseUrl = null;
let currentUser = EDITOR;

before(async () => {
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) {
    skipReason = 'no MariaDB reachable via .devcontainer/.env or env vars';
    if (process.env.REQUIRE_INTEGRATION_DB === '1') {
      throw new Error(`REQUIRE_INTEGRATION_DB=1 set but ${skipReason}.`);
    }
    return;
  }
  testDbName = `hier_omit_test_${process.pid}_${Date.now()}`;
  let admin = null;
  try {
    admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`CREATE DATABASE \`${testDbName}\``);
    await admin.query(`USE \`${testDbName}\``);
    const wanted = tbl(TABLES.HIERARCHY_NODES);
    const statements = buildEngineTableDDLs(tbl).filter((sql) => {
      const m = sql.match(/CREATE TABLE IF NOT EXISTS `([^`]+)`/);
      return m && m[1] === wanted;
    });
    assert.equal(statements.length, 1, 'the DDL list no longer defines hierarchy_nodes');
    for (const sql of statements) await admin.query(sql);
    await admin.end();
    admin = null;

    pool = mariadb.createPool({
      ...dbConfig, database: testDbName, connectionLimit: 4, connectTimeout: 5000,
    });

    const app = express();
    app.use(express.json());
    app.use((req, _res, next) => { req.user = currentUser; next(); });
    app.use('/edge/app/schema', schemaRouter);
    server = http.createServer(app);
    await new Promise((r) => server.listen(0, r));
    baseUrl = `http://127.0.0.1:${server.address().port}`;
    dbReady = true;
  } catch (err) {
    skipReason = `setup failed: ${err.message}`;
    if (admin) { try { await admin.end(); } catch { /* best effort */ } }
    if (process.env.REQUIRE_INTEGRATION_DB === '1') throw err;
  }
});

after(async () => {
  if (server) { try { server.close(); } catch { /* best effort */ } }
  if (pool) { try { await pool.end(); } catch { /* best effort */ } }
  if (!testDbName) return;
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) return;
  try {
    const admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`DROP DATABASE IF EXISTS \`${testDbName}\``);
    await admin.end();
  } catch { /* best effort */ }
});

async function createNode(user, body) {
  currentUser = user;
  const res = await fetch(`${baseUrl}/edge/app/schema/hierarchy_nodes`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
  });
  const text = await res.text();
  let parsed = null;
  try { parsed = JSON.parse(text); } catch { parsed = { raw: text }; }
  return { status: res.status, body: parsed };
}

async function updateNode(user, id, body) {
  currentUser = user;
  const res = await fetch(`${baseUrl}/edge/app/schema/hierarchy_nodes/${id}`, {
    method: 'PUT',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
  });
  const text = await res.text();
  let parsed = null;
  try { parsed = JSON.parse(text); } catch { parsed = { raw: text }; }
  return { status: res.status, body: parsed };
}

async function storedNodes() {
  return pool.query(
    `SELECT id, name, node_type, parent_id, owner_id FROM \`${tbl('hierarchy_nodes')}\` ORDER BY name`,
  );
}

// Spellings this database reads as one of the forbidden tiers while a
// JavaScript comparison against the blocklist reads them as something else. An
// ENUM comparison folds case and a trailing space under the column's collation,
// and MariaDB additionally accepts an INTEGER as a 1-BASED MEMBER INDEX — so `1`
// is 'category', the first member and the top tier.
const FOLDING_SPELLINGS = [
  ["'Category'", 'Category', 'category'],
  ["'CATEGORY'", 'CATEGORY', 'category'],
  ["'cAtEgOrY'", 'cAtEgOrY', 'category'],
  ["'category ' (trailing space)", 'category ', 'category'],
  ['1 (the ENUM member index of category)', 1, 'category'],
  ["'1'", '1', 'category'],
  ['true', true, 'category'],
  ["['category']", ['category'], 'category'],
  ["'Release' (the other forbidden tier)", 'Release', 'release'],
];

const guard = (t) => {
  if (!dbReady) { t.skip(skipReason || 'database not ready'); return true; }
  return false;
};

beforeEach(async () => {
  if (!dbReady) return;
  await pool.query(`DELETE FROM \`${tbl('hierarchy_nodes')}\``);
});

describe('a guarded column an editor never names', () => {
  test('the database supplies the forbidden value when the column is absent', async (t) => {
    if (guard(t)) return;
    // THE PREMISE, MEASURED RATHER THAN ASSUMED, and measured through a caller
    // the guard does not name so the create is allowed to reach the statement.
    // An administrator may hold a top-tier node, so this row is legitimate — what
    // it establishes is that omitting the column does NOT mean omitting a value.
    // If a later change gives the column an explicit default, this is the
    // assertion that says so, next to the guard that depends on the answer.
    const created = await createNode(ADMIN, { name: 'admin-omits-the-type' });
    assert.equal(created.status, 200, `an administrator was refused: ${JSON.stringify(created.body)}`);

    const rows = await storedNodes();
    assert.equal(rows.length, 1);
    assert.equal(
      rows[0].node_type, 'category',
      'this database did not fill the absent column with the first ENUM member; '
      + 'the refusal below rests on the fact that it does',
    );
  });

  test('an editor cannot reach that value by leaving the column out', async (t) => {
    if (guard(t)) return;
    // THE ESCALATION. Naming the column with the forbidden value is refused, and
    // so is naming it with a capital letter — this is the same act with the
    // column not named at all, which reaches the same top-tier row: parent_id
    // NULL, owned by the editor, indistinguishable from one an administrator
    // made.
    const created = await createNode(EDITOR, { name: 'editor-omits-the-type' });

    assert.notEqual(
      created.status, 200,
      `an editor created a node without naming its type: ${JSON.stringify(created.body)}`,
    );
    assert.deepEqual(await storedNodes(), [], 'a refused create left a node behind');
  });

  test('and is still refused when it names the value outright', async (t) => {
    if (guard(t)) return;
    // The route the guard already closed, kept beside the new one: closing the
    // second must not be a way of reopening the first.
    const created = await createNode(EDITOR, { name: 'editor-names-it', node_type: 'category' });
    assert.equal(created.status, 403, `expected a refusal, got ${JSON.stringify(created.body)}`);
    assert.deepEqual(await storedNodes(), [], 'a refused create left a node behind');
  });

  test('an editor creating the tier they are allowed still lands', async (t) => {
    if (guard(t)) return;
    // The other half of a guard: what it must NOT refuse. A blueprint is the
    // editor's own tier, and a create that names it is the ordinary path the
    // Hierarchy Manager takes.
    const created = await createNode(EDITOR, { name: 'editor-blueprint', node_type: 'blueprint' });
    assert.equal(created.status, 200, `a legitimate create was refused: ${JSON.stringify(created.body)}`);

    const rows = await storedNodes();
    assert.equal(rows.length, 1);
    assert.equal(rows[0].node_type, 'blueprint');
    assert.equal(rows[0].owner_id, EDITOR.id, 'the created row is not owned by its creator');
  });
});

describe('a value the guard and the column spell differently', () => {
  test('the database reads every one of these spellings as the forbidden tier', async (t) => {
    if (guard(t)) return;
    // THE PREMISE, MEASURED. Written directly, with no router in the way, so the
    // fold is shown to be the DATABASE's and not something the route does. This
    // is what makes the refusals below necessary rather than fussy: each of
    // these values IS the tier, to the only party whose opinion the stored row
    // reflects. If a later collation or column change stops folding them, this
    // is the assertion that says so, next to the guard that depends on it.
    for (const [label, sent, folded] of FOLDING_SPELLINGS) {
      await pool.query(`DELETE FROM \`${tbl('hierarchy_nodes')}\``);
      await pool.query(
        `INSERT INTO \`${tbl('hierarchy_nodes')}\` (id, name, node_type) VALUES (UUID(), 'raw', ?)`,
        [sent],
      );
      const rows = await storedNodes();
      assert.equal(
        rows[0].node_type, folded,
        `this database no longer folds ${label} to '${folded}'`,
      );
    }
  });

  for (const [label, value, folded] of FOLDING_SPELLINGS) {
    test(`an editor cannot create the forbidden tier by spelling it ${label}`, async (t) => {
      if (guard(t)) return;
      // THE ESCALATION, THIRD DOOR. Naming the forbidden value is refused, and
      // so is not naming the column at all. This names it — in a spelling the
      // blocklist does not contain and the column does not distinguish — and
      // lands the same row: top tier, parent_id NULL, owned by the editor,
      // indistinguishable from one an administrator made.
      const created = await createNode(EDITOR, { name: `spelled-${label}`, node_type: value });
      assert.notEqual(
        created.status, 200,
        `an editor created a '${folded}' node by spelling it ${label}: ${JSON.stringify(created.body)}`,
      );
      assert.deepEqual(await storedNodes(), [], 'a refused create left a node behind');
    });

    test(`an editor cannot move a node to the forbidden tier by spelling it ${label}`, async (t) => {
      if (guard(t)) return;
      // The same act from the other side, and the one an omission guard cannot
      // reach: begin with the tier the editor may legitimately hold, then move
      // it. The stored value — not the status — is the assertion, so this stays
      // independent of how the refusal is spelled.
      const seed = await createNode(EDITOR, { name: 'own-blueprint', node_type: 'blueprint' });
      assert.equal(seed.status, 200, `the fixture create was refused: ${JSON.stringify(seed.body)}`);
      const id = seed.body.data.id;

      const moved = await updateNode(EDITOR, id, { node_type: value });
      const rows = await storedNodes();
      assert.equal(
        rows[0].node_type, 'blueprint',
        `an editor moved their own node to '${folded}' by spelling it ${label} (PUT ${moved.status})`,
      );
    });
  }

  test('an editor may still move their node between the tiers they may hold', async (t) => {
    if (guard(t)) return;
    // The control for the refusal above. `variant` is an ordinary destination
    // for an editor's own row, and a fix that refused every update would satisfy
    // every case above while removing the feature.
    const seed = await createNode(EDITOR, { name: 'own-blueprint', node_type: 'blueprint' });
    assert.equal(seed.status, 200, `the fixture create was refused: ${JSON.stringify(seed.body)}`);

    const moved = await updateNode(EDITOR, seed.body.data.id, { node_type: 'variant' });
    assert.equal(moved.status, 200, `a legitimate update was refused: ${JSON.stringify(moved.body)}`);
    assert.equal((await storedNodes())[0].node_type, 'variant', 'a legitimate update no longer lands');
  });

  test('an administrator is still refused a value the column cannot store, with a stable 400', async (t) => {
    if (guard(t)) return;
    // The role the blocklist does not name reaches the column check rather than
    // the guard, and must get the same stable refusal every other guarded-enum
    // mount gives — not the 500 + logged stack that an ENUM truncation raised
    // when the value reached the INSERT.
    const created = await createNode(ADMIN, { name: 'admin-nonsense', node_type: 'zzz' });
    assert.equal(created.status, 400, `expected a stable 400, got ${JSON.stringify(created.body)}`);
    assert.equal(created.body.error.code, 'INVALID_COLUMN_VALUE');
    assert.deepEqual(await storedNodes(), [], 'a refused create left a node behind');
  });

  test('a null NAMING the column is refused with the same stable 400, on both verbs', async (t) => {
    if (guard(t)) return;
    // THE VALUE THE SUITE NEVER ASKED THE DATABASE ABOUT. `{"node_type": null}`
    // is not the omission above — it names the column and asks for NULL to be
    // written. The column is NOT NULL, so nothing can land either way; what
    // differs is the answer the caller gets. Passed through, MariaDB raises
    // ER_BAD_NULL_ERROR and the route returns 500 with a driver stack logged per
    // request — for an administrator's create and for BOTH roles' updates.
    // Refused by the column's own domain instead, it is the same stable 400 that
    // every other unstorable spelling gets.
    //
    // The editor's CREATE is deliberately not in this list: for the role the
    // blocklist names, a null on create is the omission the guard exists to
    // catch and is refused earlier, with a 403 — asserted just below so the two
    // refusals cannot quietly become one.
    const seed = await createNode(EDITOR, { name: 'own-blueprint', node_type: 'blueprint' });
    assert.equal(seed.status, 200, `the fixture create was refused: ${JSON.stringify(seed.body)}`);
    const id = seed.body.data.id;

    const cases = [
      ['administrator POST', () => createNode(ADMIN, { name: 'admin-null', node_type: null })],
      ['editor PUT', () => updateNode(EDITOR, id, { node_type: null })],
      ['administrator PUT', () => updateNode(ADMIN, id, { node_type: null })],
    ];
    for (const [label, run] of cases) {
      const res = await run();
      assert.equal(res.status, 400, `${label}: expected a stable 400, got ${JSON.stringify(res.body)}`);
      assert.equal(res.body.error.code, 'INVALID_COLUMN_VALUE', `${label}: wrong code`);
    }
    // Nothing moved: one row, still the tier the fixture created, and no row
    // from the administrator's create.
    const rows = await storedNodes();
    assert.equal(rows.length, 1, 'a refused write left a row behind');
    assert.equal(rows[0].id, id);
    assert.equal(rows[0].node_type, 'blueprint', 'a refused update changed the stored tier');
  });

  test('an editor naming no tier on create is still the guard refusing, not the column', async (t) => {
    if (guard(t)) return;
    // The control for the case above. A null on CREATE from the role the
    // blocklist names must keep its own refusal: the guard runs first and its
    // subject is "this role did not say what it is creating", which is a
    // different fact from "the column cannot store this". If both ever collapse
    // into the column's 400, the create-time requirement has stopped running and
    // nothing else in the suite would say so.
    const created = await createNode(EDITOR, { name: 'editor-null', node_type: null });
    assert.equal(created.status, 403, `expected the guard's refusal, got ${JSON.stringify(created.body)}`);
    assert.equal(created.body.error.code, 'VALUE_GUARD');
    assert.deepEqual(await storedNodes(), [], 'a refused create left a node behind');
  });

  test('an administrator may still create the top tier the editor may not', async (t) => {
    if (guard(t)) return;
    // The role control for the whole family: every refusal above is keyed to a
    // role, and the role the list does not name must reach the database exactly
    // as before — including the top tier itself.
    const created = await createNode(ADMIN, { name: 'admin-category', node_type: 'category' });
    assert.equal(created.status, 200, `an administrator was refused: ${JSON.stringify(created.body)}`);
    const rows = await storedNodes();
    assert.equal(rows[0].node_type, 'category');
    assert.equal(rows[0].owner_id, ADMIN.id);
  });
});
