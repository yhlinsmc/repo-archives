/**
 * schema-status-operator-mode.test.js — RFC docs/RFC/visibility-surface.md §7
 *
 * Operator-mode integration test for the visibility surface. Boots
 * `ensureInfrastructure` as a DML-only fixture user (the "operator-mode"
 * topology — DB account holds SELECT/INSERT/UPDATE/DELETE on infra tables
 * but no CREATE/ALTER), then asserts the schema-status admin endpoint
 * surfaces the gap as `degraded` or `failed`.
 *
 * Hard-fail capability check (RFC §7 mandate)
 * ───────────────────────────────────────────
 * `before()` runs CREATE USER + DROP USER round-trip on the test DB. Failure
 * throws — there is no `t.skip`, no env-flag bypass. The mock unit tests
 * (`migrations-registry.test.js`, `migration-sanitizer.test.js`) already
 * cover the JS branch logic; this integration test exists specifically to
 * verify the real DB privilege mechanism end-to-end. Silently skipping it
 * would defeat its purpose and reproduce the v3.2.99–101 silent-drift class
 * of bugs.
 *
 * The DB-unreachable path (no MariaDB at all) follows the existing
 * `run-schema-migrations.test.js` pattern: graceful skip locally; throw
 * when REQUIRE_INTEGRATION_DB=1 (CI). The CAPABILITY check (CREATE USER
 * works) is what RFC §7 hard-fails on — that is a different signal than
 * "no DB available".
 *
 * Test structure
 * ──────────────
 *  1. Resolve MariaDB config + capability check (CREATE USER + DROP USER)
 *  2. As admin: create throwaway DB, build infra DDL with v3.1.1-shape
 *     hierarchy_nodes (VARCHAR node_type so the migration has something
 *     to do)
 *  3. Create operator user with SELECT/INSERT/UPDATE/DELETE only
 *  4. Configure pool as operator → ensureInfrastructure → assert WARN log
 *     and platform_schema_version not bumped (test 1)
 *  5. Mount minimal express with schema-status route + admin user injection
 *     → GET /api/platform/schema/status → assert schema_status is
 *     'unsupported' with the baseline-guard skip surfaced (test 2)
 *  6. afterAll: DROP USER + DROP DATABASE cleanup
 */
const { test, describe, before, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const net = require('node:net');
const http = require('node:http');
const mariadb = require('mariadb');
const express = require('express');

const {
  configurePool,
  shutdown,
  pool,
  t: tbl,
  ensureInfrastructure,
  PLATFORM_SCHEMA_VERSION,
} = require('../../src/edge/db');
const { TABLES } = require('../../src/shared/constants');
const schemaStatusRouter = require('../../src/edge/routes/platform/schema-status');

// ── Config auto-detection (mirrors run-schema-migrations.test.js) ────────────

function parseEnvFile(filePath) {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    const out = {};
    for (const line of content.split('\n')) {
      const m = line.match(/^\s*([A-Z_][A-Z0-9_]*)\s*=\s*(.*)\s*$/);
      if (!m) continue;
      let value = m[2];
      if ((value.startsWith('"') && value.endsWith('"')) ||
          (value.startsWith("'") && value.endsWith("'"))) {
        value = value.slice(1, -1);
      }
      out[m[1]] = value;
    }
    return out;
  } catch {
    return null;
  }
}

function probePort(host, port, timeoutMs = 2000) {
  return new Promise((resolve) => {
    const socket = new net.Socket();
    let done = false;
    const finish = (ok) => {
      if (done) return;
      done = true;
      socket.destroy();
      resolve(ok);
    };
    socket.setTimeout(timeoutMs);
    socket.once('connect', () => finish(true));
    socket.once('timeout', () => finish(false));
    socket.once('error', () => finish(false));
    socket.connect(port, host);
  });
}

async function resolveMariaDbConfig() {
  if (process.env.DB_TEST_HOST && process.env.DB_TEST_ROOT_PASSWORD) {
    return {
      host: process.env.DB_TEST_HOST,
      port: parseInt(process.env.DB_TEST_PORT || '3306', 10),
      user: 'root',
      password: process.env.DB_TEST_ROOT_PASSWORD,
    };
  }
  const envPath = path.resolve(__dirname, '../../../.devcontainer/.env');
  const env = parseEnvFile(envPath);
  if (!env || !env.DB_ROOT_PASSWORD) return null;
  const port = parseInt(env.DB_PORT || '3306', 10);
  const password = env.DB_ROOT_PASSWORD;
  const candidates = ['127.0.0.1', 'mariadb', 'localhost'];
  for (const host of candidates) {
    if (await probePort(host, port, 2000)) {
      return { host, port, user: 'root', password };
    }
  }
  return null;
}

// ── Fixture builders ─────────────────────────────────────────────────────────
// Operator-mode prefix kept distinct from the v3.2.0 migration test prefix
// so parallel test runs don't collide on table names.
const TEST_PREFIX = 'op_';

function infraTablesDDL(prefix) {
  // Minimal infra tables that ensureInfrastructure will encounter. The full
  // DDL set is built dynamically in db.js; we only need the tables the
  // schema-status endpoint reads from + the v3.1.1-shape hierarchy_nodes.
  return [
    `CREATE TABLE \`${prefix}users\` (
       id CHAR(36) PRIMARY KEY,
       email VARCHAR(255) NOT NULL,
       role VARCHAR(32) NOT NULL DEFAULT 'user',
       created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
       UNIQUE KEY uk_email (email)
     ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
    `CREATE TABLE \`${prefix}login_audit\` (
       id CHAR(36) PRIMARY KEY,
       user_id CHAR(36),
       auth_provider VARCHAR(32) NOT NULL,
       created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
     ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
    `CREATE TABLE \`${prefix}system_settings\` (
       \`key\` VARCHAR(255) PRIMARY KEY,
       value TEXT,
       updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
     ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
    `CREATE TABLE \`${prefix}db_connections\` (
       id CHAR(36) PRIMARY KEY,
       name VARCHAR(255) NOT NULL,
       host VARCHAR(255) NOT NULL,
       port INT NOT NULL,
       database_name VARCHAR(255) NOT NULL,
       username VARCHAR(255) NOT NULL,
       encrypted_password TEXT,
       created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
     ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
    `CREATE TABLE \`${prefix}access_rules\` (
       id CHAR(36) PRIMARY KEY,
       rule_type VARCHAR(32) NOT NULL,
       rule_value VARCHAR(255) NOT NULL,
       created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
     ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
    `CREATE TABLE \`${prefix}feature_audit\` (
       id CHAR(36) PRIMARY KEY,
       event_type VARCHAR(64) NOT NULL,
       user_id CHAR(36),
       metadata JSON,
       created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
       INDEX idx_event_type (event_type),
       INDEX idx_created_at (created_at)
     ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
    // v3.1.1-shape hierarchy_nodes: this stamp-less, pre-baseline shape is what
    // makes the fixture DB classify as 'unsupported' under the baseline guard
    // (the operator user can DML but not ALTER/CREATE, so it can never migrate
    // itself up to the current baseline shape).
    `CREATE TABLE \`${prefix}hierarchy_nodes\` (
       id CHAR(36) PRIMARY KEY,
       parent_id CHAR(36),
       name VARCHAR(255) NOT NULL,
       node_type VARCHAR(32) NOT NULL DEFAULT '',
       sort_order INT,
       created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
       INDEX idx_parent_id (parent_id)
     ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  ];
}

// ── Test state ───────────────────────────────────────────────────────────────

let dbConfig = null;
let testDbName = null;
let operatorUser = null;
const operatorPassword = 'op_test_pw_x';
let dbReady = false;
let skipReason = null;

before(async () => {
  dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) {
    skipReason = 'no MariaDB reachable via .devcontainer/.env or env vars';
    if (process.env.REQUIRE_INTEGRATION_DB === '1') {
      throw new Error(
        `REQUIRE_INTEGRATION_DB=1 set but ${skipReason}. ` +
        'CI expected an integration database; check the test stage.',
      );
    }
    return;
  }

  testDbName = `op_test_${process.pid}_${Date.now()}`;
  operatorUser = `op_user_${process.pid}_${Date.now()}`;

  let adminConn = null;
  try {
    adminConn = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });

    // RFC §7 hard-fail capability check. CREATE USER + DROP USER round-trip
    // proves the test fixture user has sufficient privileges to provision
    // the operator-mode account this test depends on. Failure throws
    // unconditionally — no env-flag bypass.
    try {
      await adminConn.query("CREATE USER 'fmb_capability_probe'@'%' IDENTIFIED BY 'X'");
      await adminConn.query("DROP USER 'fmb_capability_probe'@'%'");
    } catch (err) {
      throw new Error(
        'CI MariaDB lacks CREATE USER + DROP USER capability — operator-mode ' +
        'integration tests cannot run. Fix the CI fixture before merging. ' +
        `Underlying error: ${err && err.message}`,
      );
    }

    await adminConn.query(`CREATE DATABASE \`${testDbName}\``);
    await adminConn.query(`USE \`${testDbName}\``);
    for (const ddl of infraTablesDDL(TEST_PREFIX)) {
      await adminConn.query(ddl);
    }
    // Seed two hierarchy_nodes rows so the backfill UPDATE has work and
    // can verify it actually mutated rows (depth 0 + depth 1).
    await adminConn.query(
      `INSERT INTO \`${TEST_PREFIX}hierarchy_nodes\` (id, parent_id, name, node_type)
       VALUES ('root-uid', NULL, 'Root', ''), ('child-uid', 'root-uid', 'Child', '')`,
    );

    await adminConn.query(
      `CREATE USER '${operatorUser}'@'%' IDENTIFIED BY '${operatorPassword}'`,
    );
    await adminConn.query(
      `GRANT SELECT, INSERT, UPDATE, DELETE ON \`${testDbName}\`.* TO '${operatorUser}'@'%'`,
    );
    await adminConn.query('FLUSH PRIVILEGES');

    await adminConn.end();
    adminConn = null;

    // Configure the application pool with the OPERATOR user. ensureInfrastructure
    // will execute against this restricted account, mirroring the production
    // operator-mode topology.
    await configurePool({
      host: dbConfig.host,
      port: dbConfig.port,
      user: operatorUser,
      password: operatorPassword,
      database: testDbName,
      tablePrefix: TEST_PREFIX,
    });

    dbReady = true;
  } catch (err) {
    skipReason = `setup failed: ${err.message}`;
    if (adminConn) {
      try { await adminConn.end(); } catch { /* ignore */ }
    }
    // Best-effort cleanup of the partial state
    try {
      const cleanup = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
      if (operatorUser) {
        try { await cleanup.query(`DROP USER IF EXISTS '${operatorUser}'@'%'`); } catch { /* ignore */ }
      }
      if (testDbName) {
        try { await cleanup.query(`DROP DATABASE IF EXISTS \`${testDbName}\``); } catch { /* ignore */ }
      }
      await cleanup.end();
    } catch { /* ignore */ }
    operatorUser = null;
    testDbName = null;
    // Capability-check failures are framed for the developer in the message
    // already — re-throw so the test runner shows the stack and the suite
    // does not silently turn green on a misconfigured fixture.
    throw err;
  }
});

after(async () => {
  try { await shutdown(); } catch { /* ignore */ }

  if (testDbName && dbConfig) {
    try {
      const cleanup = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
      if (operatorUser) {
        try { await cleanup.query(`DROP USER IF EXISTS '${operatorUser}'@'%'`); } catch (err) {
          console.error(`[teardown] failed to drop user ${operatorUser}: ${err.message}`);
        }
      }
      try { await cleanup.query(`DROP DATABASE IF EXISTS \`${testDbName}\``); } catch (err) {
        console.error(`[teardown] failed to drop ${testDbName}: ${err.message}`);
      }
      await cleanup.end();
    } catch (err) {
      console.error(`[teardown] cleanup connection failed: ${err.message}`);
    }
  }
});

// ── Tests ────────────────────────────────────────────────────────────────────

describe('schema-status operator-mode integration — RFC §7', () => {
  test('ensureInfrastructure as operator does not bump platform_schema_version (RFC §7 #2)', async (t) => {
    if (!dbReady) { t.skip(skipReason); return; }

    // RFC §7 #2 lists two observable signals asserted here from an operator-mode
    // boot: (1) WARN log emitted, (2) runSchemaMigrations does not bump
    // platform_schema_version.
    //
    // Signal (1) — the WARN log — is emitted by pino which writes through
    // sonic-boom directly to fd 1 (process.stdout.fd). The JS-level
    // process.stdout.write override used elsewhere in the test suite cannot
    // intercept fd-level sync writes, so log-content assertion is brittle
    // here. Instead, we rely on signal (2): the version stamp stayed below the
    // runtime target AND the schema-status endpoint reports degraded/failed
    // (next test), so the operator-mode detection chain is proven end-to-end
    // without depending on log capture. The ddl_preflight_skip step's WARN log remains the
    // primary operator-facing signal in production logs; humans inspecting
    // `kubectl logs` see it directly.

    await ensureInfrastructure({ context: 'boot' });

    const conn = await pool.rw.getConnection();
    try {
      const rows = await conn.query(
        `SELECT value FROM \`${tbl(TABLES.SYSTEM_SETTINGS)}\` WHERE \`key\` = 'platform_schema_version' LIMIT 1`,
      );
      const stamped = rows.length ? rows[0].value : null;
      const parsed = stamped && typeof stamped === 'string'
        ? (() => { try { return JSON.parse(stamped); } catch { return stamped; } })()
        : stamped;
      assert.notEqual(
        parsed, PLATFORM_SCHEMA_VERSION,
        `operator-mode boot must not bump platform_schema_version to ${PLATFORM_SCHEMA_VERSION}; got ${parsed}`,
      );
    } finally {
      conn.release();
    }
  });

  test('schema-status endpoint returns degraded or failed with operator-mode step', async (t) => {
    if (!dbReady) { t.skip(skipReason); return; }

    // Mount the schema-status router in a minimal express app + inject an
    // admin identity. requireAdmin only checks req.user.role === 'admin'.
    const app = express();
    app.use(express.json());
    app.use((req, _res, next) => {
      req.user = { id: 'test-admin', role: 'admin' };
      next();
    });
    app.use('/api/platform/schema-status', schemaStatusRouter);

    const server = http.createServer(app);
    await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
    const port = server.address().port;

    try {
      const res = await fetch(`http://127.0.0.1:${port}/api/platform/schema-status`);
      assert.equal(res.status, 200, 'schema-status endpoint must return 200');
      const body = await res.json();
      // apiOk wraps payload under .data — accept either flat or wrapped shape
      // to stay forward-compatible with helpers.js.
      const payload = body && body.data ? body.data : body;

      // fmb-1329 T5: the operator-mode fixture is a stamp-less DB carrying
      // engine tables (hierarchy_nodes) → the baseline guard classifies it
      // 'unsupported'. The full-schema comparison (which replaced the guard
      // probe) still runs, so the gap surfaces as missing tables/columns for
      // remediation.
      assert.equal(
        payload.schema_status, 'unsupported',
        `expected schema_status 'unsupported' on stamp-less operator-mode DB; got ${payload.schema_status}`,
      );
      assert.equal(payload.baseline_version, '3.2.520', 'baseline_version surfaced');
      const missingTables = Array.isArray(payload.missing_tables) ? payload.missing_tables : [];
      const missingColumns = Array.isArray(payload.missing_columns) ? payload.missing_columns : [];
      assert.ok(
        missingTables.length > 0 || missingColumns.length > 0,
        `comparison must surface the schema gap; got missing_tables=${JSON.stringify(missingTables)} missing_columns=${JSON.stringify(missingColumns)}`,
      );
    } finally {
      await new Promise((resolve) => server.close(resolve));
    }
  });
});
