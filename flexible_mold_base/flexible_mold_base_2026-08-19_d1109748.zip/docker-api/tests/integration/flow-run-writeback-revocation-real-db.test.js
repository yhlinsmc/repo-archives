'use strict';

/**
 * flow-run-writeback-revocation-real-db.test.js — what a dispatch records when
 * the access that started it does not survive it.
 *
 * WHY THIS IS A REAL DATABASE AND NOT A STUB. The thing under test is which rows
 * an UPDATE matches, and a stubbed driver answers that with whatever the test
 * told it to answer. Every ordering below is produced by really inserting a
 * grant, really deleting it, and really running the shipped route against the
 * shipped DDL — so the row count is MariaDB's answer, not the fixture's.
 *
 * THE ORDERING THAT MATTERS is begin → revoke → finalize. The run is authorised
 * when it begins; the grant is gone by the time it ends. What the write-back
 * records decides whether the record reads as pushed, and that decides whether
 * the NEXT dispatch is a create or an update. A create that should have been an
 * update repeats work upstream that cannot be taken back, so the observable
 * asserted here is not the row alone but the mode the next run-begin derives
 * from it.
 *
 * The three orderings are all present, because the fix must be a statement about
 * every one of them and not only the broken one:
 *   revoke AFTER finalize   — recorded, and always was.
 *   revoke BETWEEN them     — recorded. This is the defect.
 *   revoke BEFORE begin     — refused at begin, no run row, nothing recorded.
 *                             This is what stops "authorised at begin" being a
 *                             way in rather than a way through.
 *
 * AND THE ORDERING INSIDE BEGIN, which is the same question one statement
 * earlier: a revoke that lands after run-begin has asked who may dispatch and
 * before it creates the run row. "Authorised at begin" is only a defensible
 * rule if BEGIN itself is decided at the moment it writes — otherwise the run
 * row, which everything downstream now trusts, can be created for an actor
 * whose access was already gone when it was created. That ordering cannot be
 * produced from outside the request, so it is produced from inside it: see the
 * statement hook below.
 *
 * Skips with a stated reason when no database is reachable, and fails instead of
 * skipping when REQUIRE_INTEGRATION_DB=1.
 */
const { test, describe, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const net = require('node:net');
const http = require('node:http');
const express = require('express');
const mariadb = require('mariadb');

const TEST_PREFIX = 'frw_';
const tbl = (name) => `${TEST_PREFIX}${name}`;

// The route resolves its table names through `t()` at call time and leases its
// connection from `pool.rw`. Pointing both at this fixture BEFORE the router is
// required is what lets this file exercise the shipped route rather than a copy
// of its statements.
let pool = null;

/**
 * Runs before every statement the ROUTE issues, when a test sets it.
 *
 * The one thing a test cannot otherwise reach: the orderings inside a single
 * request. Everything else here is produced by issuing statements around the
 * route; a revoke that has to land between two of the route's own statements
 * has to be issued between them.
 */
let beforeStatement = null;

/**
 * The leased connection, with the hook in front of `query` and everything else
 * forwarded untouched — `release`, and the `info.database` the table-presence
 * cache keys on. A wrapper rather than a patched connection: the object goes
 * back to the pool afterwards, and a patched method would go back with it.
 */
function watched(conn, hook) {
  return new Proxy(conn, {
    get(target, prop) {
      if (prop === 'query') {
        return async (sql, params) => {
          await hook(sql);
          return target.query(sql, params);
        };
      }
      const value = Reflect.get(target, prop, target);
      return typeof value === 'function' ? value.bind(target) : value;
    },
  });
}

const lease = async () => {
  const conn = await pool.getConnection();
  return beforeStatement ? watched(conn, beforeStatement) : conn;
};
const dbKey = require.resolve('../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey,
  filename: dbKey,
  loaded: true,
  exports: {
    pool: { ro: { getConnection: lease }, rw: { getConnection: lease } },
    t: tbl,
    getDynamicPool: async () => ({ ro: { getConnection: lease }, rw: { getConnection: lease } }),
  },
};

const { buildEngineTableDDLs } = require('../../src/table-ddls');
const { TABLES } = require('../../src/shared/constants');
const { _resetGrantsTableCache } = require('../../src/edge/lib/delegated-grants');
const router = require('../../src/edge/routes/internal/flow-recipes-run');

// ── Config auto-detection (same shape as the sibling integration tests) ──────

function parseEnvFile(filePath) {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    const out = {};
    for (const line of content.split('\n')) {
      const m = line.match(/^\s*([A-Z_][A-Z0-9_]*)\s*=\s*(.*)\s*$/);
      if (!m) continue;
      let value = m[2];
      if ((value.startsWith('"') && value.endsWith('"'))
        || (value.startsWith("'") && value.endsWith("'"))) {
        value = value.slice(1, -1);
      }
      out[m[1]] = value;
    }
    return out;
  } catch {
    return null;
  }
}

function probePort(host, port, timeoutMs = 2000) {
  return new Promise((resolve) => {
    const socket = new net.Socket();
    let done = false;
    const finish = (ok) => {
      if (done) return;
      done = true;
      socket.destroy();
      resolve(ok);
    };
    socket.setTimeout(timeoutMs);
    socket.once('connect', () => finish(true));
    socket.once('timeout', () => finish(false));
    socket.once('error', () => finish(false));
    socket.connect(port, host);
  });
}

async function resolveMariaDbConfig() {
  if (process.env.DB_TEST_HOST && process.env.DB_TEST_ROOT_PASSWORD) {
    return {
      host: process.env.DB_TEST_HOST,
      port: parseInt(process.env.DB_TEST_PORT || '3306', 10),
      user: 'root',
      password: process.env.DB_TEST_ROOT_PASSWORD,
    };
  }
  const envPath = path.resolve(__dirname, '../../../.devcontainer/.env');
  const env = parseEnvFile(envPath);
  if (!env || !env.DB_ROOT_PASSWORD) return null;
  const port = parseInt(env.DB_PORT || '3306', 10);
  for (const host of ['127.0.0.1', 'mariadb', 'localhost']) {
    if (await probePort(host, port, 2000)) {
      return { host, port, user: 'root', password: env.DB_ROOT_PASSWORD };
    }
  }
  return null;
}

// ── Fixture ─────────────────────────────────────────────────────────────────

const OWNER = 'u-owner';
const GRANTEE = 'u-grantee';
const STRANGER = 'u-stranger';
const BP1 = 'bp-1';
const T1 = 'tpl-1';
const RECIPE = 'r-1';

let dbReady = false;
let skipReason = null;
let testDbName = null;
let server = null;
let baseUrl = null;
let currentUser = { id: OWNER, role: 'user' };

function ddlFor(...tables) {
  const wanted = new Set(tables.map((n) => tbl(n)));
  return buildEngineTableDDLs(tbl).filter((sql) => {
    const m = sql.match(/CREATE TABLE IF NOT EXISTS `([^`]+)`/);
    return m && wanted.has(m[1]);
  });
}

before(async () => {
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) {
    skipReason = 'no MariaDB reachable via .devcontainer/.env or env vars';
    if (process.env.REQUIRE_INTEGRATION_DB === '1') {
      throw new Error(`REQUIRE_INTEGRATION_DB=1 set but ${skipReason}.`);
    }
    return;
  }
  testDbName = `flow_writeback_test_${process.pid}_${Date.now()}`;
  let admin = null;
  try {
    admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`CREATE DATABASE \`${testDbName}\``);
    await admin.query(`USE \`${testDbName}\``);
    const statements = ddlFor(
      TABLES.HIERARCHY_NODES, TABLES.USER_TEMPLATES, TABLES.DELEGATED_GRANTS,
      TABLES.FLOW_RECIPES, TABLES.FLOW_RECIPE_STEPS, TABLES.FLOW_RECIPE_RUNS,
      TABLES.TEMPLATE_ACTIVITY,
    );
    assert.equal(statements.length, 7, 'the DDL list no longer defines all seven tables');
    for (const sql of statements) await admin.query(sql);

    await admin.query(
      `INSERT INTO \`${tbl('hierarchy_nodes')}\` (id, name, node_type, owner_id) VALUES (?, 'BP1', 'blueprint', ?)`,
      [BP1, OWNER],
    );
    await admin.query(
      `INSERT INTO \`${tbl('user_templates')}\` (id, name, blueprint_id, owner_id) VALUES (?, 'one', ?, ?)`,
      [T1, BP1, OWNER],
    );
    await admin.query(
      `INSERT INTO \`${tbl('flow_recipes')}\`
         (id, name, is_active, blueprint_id, content_type, link_extract, external_id_extract, runs_on, status)
       VALUES (?, 'recipe', 1, ?, 'application/json', ?, ?, 'both', 'approved')`,
      [RECIPE, BP1, JSON.stringify({ path: 'url' }), JSON.stringify({ path: 'id' })],
    );
    // One JS-free HTTP step, so the recipe takes the server-orchestrated path
    // and run-begin needs no client_orchestration flag.
    await admin.query(
      `INSERT INTO \`${tbl('flow_recipe_steps')}\` (id, recipe_id, \`sequence\`, name, method, url)
       VALUES ('s-1', ?, 1, 'step one', 'POST', 'https://upstream.invalid/create')`,
      [RECIPE],
    );
    await admin.end();
    admin = null;

    pool = mariadb.createPool({
      ...dbConfig, database: testDbName, connectionLimit: 4, connectTimeout: 5000,
    });
    _resetGrantsTableCache();

    const app = express();
    app.use(express.json());
    app.use((req, _res, next) => { req.user = currentUser; next(); });
    app.use('/edge/internal/flow-recipes', router);
    server = http.createServer(app);
    await new Promise((r) => server.listen(0, r));
    baseUrl = `http://127.0.0.1:${server.address().port}`;
    dbReady = true;
  } catch (err) {
    skipReason = `setup failed: ${err.message}`;
    if (admin) { try { await admin.end(); } catch { /* best effort */ } }
    if (process.env.REQUIRE_INTEGRATION_DB === '1') throw err;
  }
});

after(async () => {
  if (server) { try { server.close(); } catch { /* best effort */ } }
  if (pool) { try { await pool.end(); } catch { /* best effort */ } }
  if (!testDbName) return;
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) return;
  try {
    const admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`DROP DATABASE IF EXISTS \`${testDbName}\``);
    await admin.end();
  } catch { /* best effort */ }
});

// ── Driving the real routes ─────────────────────────────────────────────────

async function post(pathname, body, user) {
  currentUser = user;
  const res = await fetch(`${baseUrl}/edge/internal/flow-recipes/${pathname}`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
  });
  return { status: res.status, body: await res.json() };
}

const begin = (user, over = {}) => post('run-begin', {
  recipe_id: RECIPE, payload: { a: 1 }, template_id: T1, ...over,
}, user);

const finalize = (user, runId) => post('run-finalize', {
  run_id: runId,
  recipe_id: RECIPE,
  ok: true,
  upstream_status: 200,
  body: JSON.stringify({ url: 'https://upstream.invalid/RUN', id: 'EXT-1' }),
}, user);

async function grantTemplateToGrantee() {
  await pool.query(
    `INSERT INTO \`${tbl('delegated_grants')}\` (id, scope_type, scope_id, grantee_id, granted_by)
     VALUES ('g-1', 'template', ?, ?, ?)`,
    [T1, GRANTEE, OWNER],
  );
}

const revokeAll = () => pool.query(`DELETE FROM \`${tbl('delegated_grants')}\``);

async function templateRow() {
  const rows = await pool.query(
    `SELECT owner_id, flow_external_id, flow_link, flow_last_run_id
       FROM \`${tbl('user_templates')}\` WHERE id = ?`, [T1],
  );
  return rows[0];
}

async function runCount() {
  const rows = await pool.query(`SELECT COUNT(*) AS n FROM \`${tbl('flow_recipe_runs')}\``);
  return Number(rows[0].n);
}

const guard = (t) => {
  if (!dbReady) { t.skip(skipReason || 'database not ready'); return true; }
  return false;
};

beforeEach(async () => {
  beforeStatement = null;
  if (!dbReady) return;
  await revokeAll();
  await pool.query(`DELETE FROM \`${tbl('flow_recipe_runs')}\``);
  await pool.query(`DELETE FROM \`${tbl('template_activity')}\``);
  await pool.query(
    `UPDATE \`${tbl('user_templates')}\`
        SET owner_id = ?, flow_external_id = NULL, flow_link = NULL, flow_last_run_id = NULL
      WHERE id = ?`,
    [OWNER, T1],
  );
  // The blueprint's owner reaches every record under it, so a test that hands
  // the RECORD away has changed nothing unless this is restored too.
  await pool.query(
    `UPDATE \`${tbl('hierarchy_nodes')}\` SET owner_id = ? WHERE id = ?`, [OWNER, BP1],
  );
});

describe('a dispatch records itself against the access that began it', () => {
  test('revoked between begin and finalize: the record still reads as pushed', async (t) => {
    if (guard(t)) return;
    // THE DEFECT. The write-back used to re-ask "may this actor reach this
    // record" at finalize time. A grant that was live at begin and gone at
    // finalize made that question answer no, so the write matched nothing —
    // while the run itself finalized as a success. The record then still read
    // as never pushed, and the owner's next dispatch was a CREATE of something
    // that had already been created upstream.
    await grantTemplateToGrantee();

    const began = await begin({ id: GRANTEE, role: 'user' });
    assert.equal(began.status, 200, `run-begin: ${JSON.stringify(began.body)}`);
    assert.equal(began.body.data.mode, 'create', 'a never-pushed record dispatches as a create');
    const runId = began.body.data.run_id;

    // The grant is withdrawn while the dispatch is in flight.
    await revokeAll();

    const ended = await finalize({ id: GRANTEE, role: 'user' }, runId);
    assert.equal(ended.status, 200, `run-finalize: ${JSON.stringify(ended.body)}`);
    assert.equal(ended.body.data.status, 'success');

    const row = await templateRow();
    assert.equal(
      row.flow_last_run_id, runId,
      'the successful dispatch did not record itself on the record it dispatched',
    );
    assert.equal(row.flow_external_id, 'EXT-1');
    assert.equal(row.flow_link, 'https://upstream.invalid/RUN');

    // The consumer that makes this matter: the mode the next dispatch derives.
    const next = await begin({ id: OWNER, role: 'user' });
    assert.equal(next.status, 200, `second run-begin: ${JSON.stringify(next.body)}`);
    assert.equal(
      next.body.data.mode, 'update',
      'the next dispatch would repeat upstream work that cannot be taken back',
    );
  });

  test('revoked after finalize: unchanged, and always recorded', async (t) => {
    if (guard(t)) return;
    await grantTemplateToGrantee();
    const began = await begin({ id: GRANTEE, role: 'user' });
    assert.equal(began.status, 200);
    const ended = await finalize({ id: GRANTEE, role: 'user' }, began.body.data.run_id);
    assert.equal(ended.status, 200);
    await revokeAll();

    const row = await templateRow();
    assert.equal(row.flow_last_run_id, began.body.data.run_id);
  });

  test('revoked before begin: refused, with no run row to carry an authorisation', async (t) => {
    if (guard(t)) return;
    // What stops "the run row is the authorisation" from being a way in. The
    // run row only exists because run-begin let it, so an actor whose access was
    // already gone has nothing to finalize.
    const began = await begin({ id: GRANTEE, role: 'user' });
    assert.equal(began.status, 403, `expected a refusal, got ${JSON.stringify(began.body)}`);
    assert.equal(began.body.error.code, 'TEMPLATE_FORBIDDEN');
    assert.equal(await runCount(), 0, 'a refused dispatch created a run row');
    assert.equal((await templateRow()).flow_last_run_id, null);
  });

  test('a stranger cannot finalize somebody else\'s run, so cannot reach the write-back', async (t) => {
    if (guard(t)) return;
    await grantTemplateToGrantee();
    const began = await begin({ id: GRANTEE, role: 'user' });
    assert.equal(began.status, 200);

    const stolen = await finalize({ id: STRANGER, role: 'user' }, began.body.data.run_id);
    assert.equal(stolen.status, 403);
    assert.equal(stolen.body.error.code, 'RUN_FORBIDDEN');
    assert.equal((await templateRow()).flow_last_run_id, null, 'a refused finalize wrote the cache');
  });

  test('a record that lost its owner mid-run is still reached by nothing', async (t) => {
    if (guard(t)) return;
    // The one boundary delegation did not move, and the write-back keeps it
    // whether or not it asks who is writing: no arm reaches a record nobody
    // owns, because writing one has always been an administrator's business.
    await grantTemplateToGrantee();
    const began = await begin({ id: GRANTEE, role: 'user' });
    assert.equal(began.status, 200);

    await pool.query(
      `UPDATE \`${tbl('user_templates')}\` SET owner_id = NULL WHERE id = ?`, [T1],
    );

    const ended = await finalize({ id: GRANTEE, role: 'user' }, began.body.data.run_id);
    assert.equal(ended.status, 200, 'the run must still finalize — the write-back is best-effort');
    assert.equal(ended.body.data.status, 'success');
    assert.equal(
      (await templateRow()).flow_last_run_id, null,
      'the write-back reached a record nobody owns',
    );
  });

  test('an owner\'s own dispatch records itself with no grant anywhere', async (t) => {
    if (guard(t)) return;
    const began = await begin({ id: OWNER, role: 'user' });
    assert.equal(began.status, 200);
    const ended = await finalize({ id: OWNER, role: 'user' }, began.body.data.run_id);
    assert.equal(ended.status, 200);
    assert.equal((await templateRow()).flow_last_run_id, began.body.data.run_id);
  });

  test('a database with no grants table still records an owner\'s dispatch', async (t) => {
    if (guard(t)) return;
    // The write-back must not depend on a table whose migration an operator
    // account may have been unable to run.
    await pool.query(`DROP TABLE \`${tbl('delegated_grants')}\``);
    _resetGrantsTableCache();
    try {
      const began = await begin({ id: OWNER, role: 'user' });
      assert.equal(began.status, 200, `run-begin: ${JSON.stringify(began.body)}`);
      const ended = await finalize({ id: OWNER, role: 'user' }, began.body.data.run_id);
      assert.equal(ended.status, 200, `run-finalize: ${JSON.stringify(ended.body)}`);
      assert.equal((await templateRow()).flow_last_run_id, began.body.data.run_id);
    } finally {
      for (const sql of ddlFor(TABLES.DELEGATED_GRANTS)) await pool.query(sql);
      _resetGrantsTableCache();
    }
  });
});

/**
 * The window INSIDE run-begin.
 *
 * HOW THE INTERLEAVING IS MADE DETERMINISTIC, rather than raced for and hoped
 * for. The window is between two of the route's own statements, so nothing
 * issued from outside the request can be placed in it by timing. Instead the
 * connection the route leases is wrapped, and the revoke is issued — and
 * AWAITED TO COMPLETION, on a different connection — the moment the route asks
 * for the recipe's step list. That statement is issued strictly after the route
 * has decided who may dispatch and strictly before it creates the run row, so
 * the revoke is committed inside the window on every execution. There is no
 * sleep, no polling, and no second thread: the route's next statement does not
 * begin until the revoke has finished.
 *
 * A CONTROL CASE RUNS THE SAME HOOK AND CHANGES NOTHING, because a fix that
 * simply refused every hooked request would satisfy the two cases above and
 * break the feature.
 */
describe('the run row is created only if the access still holds when it is created', () => {
  /** Fires once, at the step-list read — the last statement before the INSERT. */
  function atTheStepList(action) {
    let fired = 0;
    beforeStatement = async (sql) => {
      if (fired || !/flow_recipe_steps/.test(sql)) return;
      fired += 1;
      await action();
    };
    return () => fired;
  }

  test('a grant revoked in that window creates no run, so there is nothing to dispatch', async (t) => {
    if (guard(t)) return;
    // WHY THIS IS NOT THE SAME TEST AS "revoked before begin". There the read
    // itself sees no grant. Here the read sees one and the write does not, and
    // between them the route serialises the payload and loads the steps — real
    // work, not an instant. The run row is what everything downstream trusts as
    // the proof that the dispatch was authorised, so a row created after the
    // grant was withdrawn makes that proof state something untrue, and hands the
    // caller the payload to dispatch on the strength of it.
    await grantTemplateToGrantee();
    const fired = atTheStepList(revokeAll);

    const began = await begin({ id: GRANTEE, role: 'user' });

    assert.equal(fired(), 1, 'the revoke never landed in the window this test is about');
    assert.equal(began.status, 403, `expected a refusal, got ${JSON.stringify(began.body)}`);
    assert.equal(began.body.error.code, 'TEMPLATE_FORBIDDEN');
    assert.equal(await runCount(), 0, 'a run row was created for access that was already gone');
    assert.equal(began.body.data, null, 'a payload was handed out to be dispatched');
  });

  test('and the same holds for ownership handed away in that window', async (t) => {
    if (guard(t)) return;
    // Ownership is the other way in, and it changes through an ordinary write
    // that has nothing to do with grants. A gate that only re-asked about grants
    // would leave this one open.
    //
    // The blueprint goes to somebody else FIRST, and that is not incidental:
    // its owner reaches every record under it, so with the fixture's default
    // this actor would still be allowed after the record was handed away and
    // the case would assert nothing.
    await pool.query(
      `UPDATE \`${tbl('hierarchy_nodes')}\` SET owner_id = ? WHERE id = ?`, [STRANGER, BP1],
    );
    const fired = atTheStepList(() => pool.query(
      `UPDATE \`${tbl('user_templates')}\` SET owner_id = ? WHERE id = ?`, [STRANGER, T1],
    ));

    const began = await begin({ id: OWNER, role: 'user' });

    assert.equal(fired(), 1, 'ownership never changed inside the window');
    assert.equal(began.status, 403, `expected a refusal, got ${JSON.stringify(began.body)}`);
    assert.equal(await runCount(), 0, 'a run row was created for a record the actor no longer owns');
  });

  test('the control: the same hook, changing nothing, still dispatches', async (t) => {
    if (guard(t)) return;
    // Without this, a fix that refused any request whose connection was watched
    // — or simply refused more often — would pass both cases above.
    await grantTemplateToGrantee();
    const fired = atTheStepList(async () => { await pool.query('SELECT 1'); });

    const began = await begin({ id: GRANTEE, role: 'user' });

    assert.equal(fired(), 1, 'the hook did not run, so this control proves nothing');
    assert.equal(began.status, 200, `run-begin: ${JSON.stringify(began.body)}`);
    assert.equal(await runCount(), 1);
  });

  test('an administrator still dispatches a record nobody owns', async (t) => {
    if (guard(t)) return;
    // The one caller no arm of delegated access covers. An administrator's
    // permission is not a row that another statement can delete, and gating them
    // on the access predicate would refuse them the records they are the only
    // party allowed to dispatch.
    await pool.query(`UPDATE \`${tbl('user_templates')}\` SET owner_id = NULL WHERE id = ?`, [T1]);

    const began = await begin({ id: 'u-admin', role: 'admin' });

    assert.equal(began.status, 200, `run-begin: ${JSON.stringify(began.body)}`);
    assert.equal(await runCount(), 1);
  });

  test('a database with no grants table still lets an owner begin a run', async (t) => {
    if (guard(t)) return;
    // The gate names the grants table in two of its three arms, so it must be
    // built without them on a database whose operator account could not create
    // it — otherwise the statement that decides every dispatch would be the one
    // statement that cannot run there.
    await pool.query(`DROP TABLE \`${tbl('delegated_grants')}\``);
    _resetGrantsTableCache();
    try {
      const began = await begin({ id: OWNER, role: 'user' });
      assert.equal(began.status, 200, `run-begin: ${JSON.stringify(began.body)}`);
      assert.equal(await runCount(), 1);
    } finally {
      for (const sql of ddlFor(TABLES.DELEGATED_GRANTS)) await pool.query(sql);
      _resetGrantsTableCache();
    }
  });

  test('and still lets a blueprint owner begin one, which needs no grants table', async (t) => {
    if (guard(t)) return;
    // The arm that reads the hierarchy. It is the reach that must survive a
    // missing optional table, and on the gate it is the only arm left.
    await pool.query(`UPDATE \`${tbl('user_templates')}\` SET owner_id = ? WHERE id = ?`, [STRANGER, T1]);
    await pool.query(`DROP TABLE \`${tbl('delegated_grants')}\``);
    _resetGrantsTableCache();
    try {
      // OWNER owns BP1, which T1 belongs to; they do not own T1 itself.
      const began = await begin({ id: OWNER, role: 'user' });
      assert.equal(began.status, 200, `run-begin: ${JSON.stringify(began.body)}`);
      assert.equal(await runCount(), 1);
    } finally {
      for (const sql of ddlFor(TABLES.DELEGATED_GRANTS)) await pool.query(sql);
      _resetGrantsTableCache();
    }
  });
});
