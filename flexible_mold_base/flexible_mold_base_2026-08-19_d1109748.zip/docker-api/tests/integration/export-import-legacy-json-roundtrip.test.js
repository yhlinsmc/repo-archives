/**
 * export-import-legacy-json-roundtrip.test.js
 *
 * Proves the three v3.2.126/127 JSON columns survive an export → seed-import
 * round-trip:
 *   - user_templates.field_option_selection  (v3.2.126 — {field_key: label})
 *   - user_templates.computed_field_overrides (v3.2.127 — {field_key: true})
 *   - variant_overrides.compute_rule          (v3.2.127 — ComputeRule object)
 *
 * All three are registered as `json` in the dto-mapper registry, so the export
 * route parses-then-reserialises them (mapRowFromDb → mapRowToDb) rather than
 * wrapping the raw driver string verbatim. This test proves that guarantee.
 *
 * Harness mirrors export-import-cascade-roundtrip.test.js exactly: mock the db
 * module in require.cache, mount on throwaway Express servers, drive over real
 * HTTP. Assertions are at the in-process seed level (no real MariaDB needed).
 */
const { describe, it, before, after } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const { splitSqlStatements } = require('../../src/sql-utils');

const dbKey = require.resolve('../../src/edge/db');

// ── Mock DB module shared by both routes. ────────────────────────────────────
const PREFIX = 'fmb_';
const DB_NAME = 'testdb';

let roConnFactory;
let rwConnFactory;

const poolSpy = {
  ro: { async getConnection() { return roConnFactory(); } },
  rw: { async getConnection() { return rwConnFactory(); } },
};

require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: {
    pool: poolSpy,
    t: (name) => `${PREFIX}${name}`,
    getDbConfig: () => ({ database: DB_NAME, tablePrefix: PREFIX }),
    isPoolReady: () => true,
  },
};

const exportRouter = require('../../src/edge/routes/platform/export');
const registerSeed = require('../../src/edge/routes/platform/setup/seed-data');

// ── Fixture rows. The driver returns JSON columns as raw strings exactly as
// MariaDB stored them. The test checks that export.js parses + reserialises
// them into clean JSON literals. ─────────────────────────────────────────────

// Minimal ComputeRule (concat op) as the driver would return it: raw JSON string.
const COMPUTE_RULE_OBJ = {
  op: 'concat',
  overridable: true,
  output_type: 'string',
  config: { parts: [{ type: 'field', key: 'series' }, { type: 'literal', text: '-' }], separator: '' },
};

const VARIANT_OVERRIDES_ROW = {
  id: 'vo-1',
  variant_id: 'var-1',
  blueprint_field_id: 'bf-1',
  field_key: 'part_no',
  action: 'compute',
  override_value: null,
  compute_rule: JSON.stringify(COMPUTE_RULE_OBJ), // raw string, as driver returns
  created_at: '2026-06-01 00:00:00',
};

// A compute_rule whose config references a table_cell source. table_cell refs
// carry stable string keys (table_key / column_key) plus a row selector, none
// of which the schema-driven export/import knows or cares about — they ride
// through inside the opaque JSON column. This row pins that the nested shape is
// preserved so a future refactor can't silently drop the table_cell ref.
const COMPUTE_RULE_TABLE_CELL_OBJ = {
  op: 'concat',
  overridable: true,
  output_type: 'string',
  config: {
    parts: [
      { type: 'field', key: 'prefix' },
      { type: 'table_cell', cell: { table_key: 'items', column_key: 'part', row: 'last' } },
    ],
    separator: '',
  },
};

const VARIANT_OVERRIDES_TABLE_CELL_ROW = {
  id: 'vo-2',
  variant_id: 'var-1',
  blueprint_field_id: 'bf-2',
  field_key: 'assembly_no',
  action: 'compute',
  override_value: null,
  compute_rule: JSON.stringify(COMPUTE_RULE_TABLE_CELL_OBJ), // raw string, as driver returns
  created_at: '2026-06-01 00:00:00',
};

// field_option_selection and computed_field_overrides together on one template row.
const FIELD_OPTION_SELECTION_OBJ = { size: 'Large (L)' };
const COMPUTED_FIELD_OVERRIDES_OBJ = { part_no: true };

const USER_TEMPLATES_ROW = {
  id: 'tpl-1',
  name: 'test-template',
  owner_id: null,
  schema_version: null,
  is_draft: 1,
  payload: '{}',
  generated_outputs: null,
  field_option_selection: JSON.stringify(FIELD_OPTION_SELECTION_OBJ),
  computed_field_overrides: JSON.stringify(COMPUTED_FIELD_OVERRIDES_OBJ),
  created_at: '2026-06-01 00:00:00',
  updated_at: '2026-06-01 00:00:00',
};

const COLUMN_META = {
  variant_overrides: [
    { COLUMN_NAME: 'id', DATA_TYPE: 'varchar' },
    { COLUMN_NAME: 'variant_id', DATA_TYPE: 'varchar' },
    { COLUMN_NAME: 'blueprint_field_id', DATA_TYPE: 'varchar' },
    { COLUMN_NAME: 'field_key', DATA_TYPE: 'varchar' },
    { COLUMN_NAME: 'action', DATA_TYPE: 'varchar' },
    { COLUMN_NAME: 'override_value', DATA_TYPE: 'varchar' },
    { COLUMN_NAME: 'compute_rule', DATA_TYPE: 'longtext' },
    { COLUMN_NAME: 'created_at', DATA_TYPE: 'timestamp' },
  ],
  user_templates: [
    { COLUMN_NAME: 'id', DATA_TYPE: 'varchar' },
    { COLUMN_NAME: 'name', DATA_TYPE: 'varchar' },
    { COLUMN_NAME: 'owner_id', DATA_TYPE: 'varchar' },
    { COLUMN_NAME: 'schema_version', DATA_TYPE: 'varchar' },
    { COLUMN_NAME: 'is_draft', DATA_TYPE: 'tinyint' },
    { COLUMN_NAME: 'payload', DATA_TYPE: 'longtext' },
    { COLUMN_NAME: 'generated_outputs', DATA_TYPE: 'longtext' },
    { COLUMN_NAME: 'field_option_selection', DATA_TYPE: 'longtext' },
    { COLUMN_NAME: 'computed_field_overrides', DATA_TYPE: 'longtext' },
    { COLUMN_NAME: 'created_at', DATA_TYPE: 'timestamp' },
    { COLUMN_NAME: 'updated_at', DATA_TYPE: 'timestamp' },
  ],
};

const TABLE_ROWS = {
  variant_overrides: [VARIANT_OVERRIDES_ROW, VARIANT_OVERRIDES_TABLE_CELL_ROW],
  user_templates: [USER_TEMPLATES_ROW],
};

function makeExportConn() {
  return {
    async query(sql, params) {
      if (/^SELECT \* FROM/.test(sql)) {
        const m = sql.match(/`([^`]+)`/);
        const physical = m ? m[1] : '';
        const tableName = physical.startsWith(PREFIX) ? physical.slice(PREFIX.length) : physical;
        return TABLE_ROWS[tableName] || [];
      }
      if (/information_schema\.COLUMNS/i.test(sql)) {
        const physical = params[1];
        const tableName = physical.startsWith(PREFIX) ? physical.slice(PREFIX.length) : physical;
        return COLUMN_META[tableName] || [];
      }
      return [];
    },
    release() { /* noop */ },
  };
}

let exportServer;
let exportPort;
let seedServer;
let seedPort;

let seedCapture;

function makeSeedConn(opts = {}) {
  const missingColumns = new Set(opts.missingColumns || []);
  return {
    async query(sql) {
      if (/SELECT COUNT\(\*\)/i.test(sql)) return [{ cnt: 0 }];
      if (/INFORMATION_SCHEMA\.COLUMNS/i.test(sql)) return [];
      if (/INSERT\s+INTO/i.test(sql)) {
        for (const col of missingColumns) {
          if (new RegExp(`\`${col}\``).test(sql)) {
            const err = new Error(`Unknown column '${col}' in 'field list'`);
            err.code = 'ER_BAD_FIELD_ERROR';
            err.errno = 1054;
            throw err;
          }
        }
        seedCapture.applied.push(sql);
        return { affectedRows: 1 };
      }
      return { affectedRows: 0 };
    },
    async beginTransaction() { seedCapture.began = true; },
    async commit() { seedCapture.committed = true; },
    async rollback() { seedCapture.rolledBack = true; },
    release() { /* noop */ },
  };
}

before(async () => {
  roConnFactory = makeExportConn;

  const exportApp = express();
  exportApp.use(express.json());
  exportApp.use((req, _res, next) => { req.user = { id: 'admin-1', role: 'admin' }; next(); });
  exportApp.use('/api/export', exportRouter);
  await new Promise((resolve) => {
    exportServer = exportApp.listen(0, '127.0.0.1', () => {
      exportPort = exportServer.address().port;
      resolve();
    });
  });

  const seedApp = express();
  seedApp.use(express.json());
  const seedRouter = express.Router();
  registerSeed(seedRouter);
  seedApp.use('/api/setup', seedRouter);
  await new Promise((resolve) => {
    seedServer = seedApp.listen(0, '127.0.0.1', () => {
      seedPort = seedServer.address().port;
      resolve();
    });
  });
});

after(async () => {
  await new Promise((resolve) => exportServer.close(resolve));
  await new Promise((resolve) => seedServer.close(resolve));
  delete require.cache[dbKey];
});

function getText(port, path_) {
  return new Promise((resolve, reject) => {
    const req = http.request({ host: '127.0.0.1', port, path: path_, method: 'GET' }, (res) => {
      const chunks = [];
      res.on('data', (c) => chunks.push(c));
      res.on('end', () => resolve({ status: res.statusCode, body: Buffer.concat(chunks).toString('utf-8') }));
    });
    req.on('error', reject);
    req.end();
  });
}

function postJson(port, path_, body) {
  return new Promise((resolve, reject) => {
    const payload = JSON.stringify(body);
    const req = http.request(
      {
        host: '127.0.0.1', port, path: path_, method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) },
      },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          const raw = Buffer.concat(chunks).toString('utf-8');
          let json = null;
          try { json = JSON.parse(raw); } catch { /* noop */ }
          resolve({ status: res.statusCode, raw, json });
        });
      },
    );
    req.on('error', reject);
    req.write(payload);
    req.end();
  });
}

function extractInsert(sql, tableName) {
  const stmts = splitSqlStatements(sql);
  return stmts.find((s) => new RegExp(`INSERT INTO \`(__PREFIX__|${PREFIX})${tableName}\``).test(s));
}

describe('export emits clean JSON for v3.2.126/127 columns', () => {
  it('variant_overrides INSERT carries compute_rule as a clean JSON literal', async () => {
    const { status, body } = await getText(exportPort, '/api/export/mariadb-sql');
    assert.equal(status, 200);

    const insert = extractInsert(body, 'variant_overrides');
    assert.ok(insert, 'export must contain a variant_overrides INSERT');

    assert.match(insert, /`compute_rule`/);

    // The exported literal must open with the JSON object brace, not contain
    // a double-escaped inner quote that signals the raw string was wrapped
    // verbatim without the parse-reserialise cycle.
    assert.match(insert, /'{"op":"concat"/);
    assert.doesNotMatch(insert, /\\"op\\"/);
  });

  it('user_templates INSERT carries field_option_selection as a clean JSON literal', async () => {
    const { status, body } = await getText(exportPort, '/api/export/mariadb-sql');
    assert.equal(status, 200);

    const insert = extractInsert(body, 'user_templates');
    assert.ok(insert, 'export must contain a user_templates INSERT');

    assert.match(insert, /`field_option_selection`/);
    assert.match(insert, /'{"size":"Large \(L\)"}'/ );
    assert.doesNotMatch(insert, /\\"size\\"/);
  });

  it('user_templates INSERT carries computed_field_overrides as a clean JSON literal', async () => {
    const { status, body } = await getText(exportPort, '/api/export/mariadb-sql');
    assert.equal(status, 200);

    const insert = extractInsert(body, 'user_templates');
    assert.ok(insert, 'export must contain a user_templates INSERT');

    assert.match(insert, /`computed_field_overrides`/);
    assert.match(insert, /'{"part_no":true}'/);
    assert.doesNotMatch(insert, /\\"part_no\\"/);
  });
});

describe('round-trip via seed import', () => {
  // Asserted at the in-process seed level — real POST /api/setup/seed handler,
  // mock conn captures the SQL handed to the driver. We stop short of a real
  // MariaDB write (no DB in unit CI), but everything up to and including the
  // driver-bound SQL is the production code path.
  it('all three JSON columns survive export → seed apply and parse back to original objects', async () => {
    const { body: dump } = await getText(exportPort, '/api/export/mariadb-sql');

    seedCapture = { applied: [], began: false, committed: false, rolledBack: false };
    rwConnFactory = () => makeSeedConn();

    const res = await postJson(seedPort, '/api/setup/seed', { sql: dump });
    assert.equal(res.status, 200, `seed import should succeed: ${res.raw}`);
    assert.equal(seedCapture.committed, true, 'seed txn must commit');
    assert.equal(seedCapture.rolledBack, false, 'seed txn must not roll back');

    const voInsert = seedCapture.applied.find((s) => /variant_overrides/.test(s));
    const tplInsert = seedCapture.applied.find((s) => /user_templates/.test(s));
    assert.ok(voInsert, 'variant_overrides INSERT must reach the driver');
    assert.ok(tplInsert, 'user_templates INSERT must reach the driver');

    // compute_rule: extract the JSON object literal and round-trip it.
    // The literal starts with { and ends before the closing quote; a greedy
    // match on the first occurrence covering "op" is sufficient.
    const crMatch = voInsert.match(/'(\{"op":"concat"[^']*\})'/);
    assert.ok(crMatch, 'variant_overrides INSERT must embed a compute_rule JSON literal');
    assert.deepEqual(JSON.parse(crMatch[1]), COMPUTE_RULE_OBJ);

    // field_option_selection: the {"size":"Large (L)"} literal.
    const fosMatch = tplInsert.match(/'(\{"size":"Large \(L\)"\})'/);
    assert.ok(fosMatch, 'user_templates INSERT must embed a field_option_selection JSON literal');
    assert.deepEqual(JSON.parse(fosMatch[1]), FIELD_OPTION_SELECTION_OBJ);

    // computed_field_overrides: the {"part_no":true} literal.
    const cfoMatch = tplInsert.match(/'(\{"part_no":true\})'/);
    assert.ok(cfoMatch, 'user_templates INSERT must embed a computed_field_overrides JSON literal');
    assert.deepEqual(JSON.parse(cfoMatch[1]), COMPUTED_FIELD_OVERRIDES_OBJ);
  });

  it('a compute_rule with a table_cell source survives the round-trip with table_key/column_key/row intact', async () => {
    const { body: dump } = await getText(exportPort, '/api/export/mariadb-sql');

    seedCapture = { applied: [], began: false, committed: false, rolledBack: false };
    rwConnFactory = () => makeSeedConn();

    const res = await postJson(seedPort, '/api/setup/seed', { sql: dump });
    assert.equal(res.status, 200, `seed import should succeed: ${res.raw}`);
    assert.equal(seedCapture.committed, true, 'seed txn must commit');
    assert.equal(seedCapture.rolledBack, false, 'seed txn must not roll back');

    const voInsert = seedCapture.applied.find((s) => /variant_overrides/.test(s));
    assert.ok(voInsert, 'variant_overrides INSERT must reach the driver');

    // The variant_overrides INSERT is a single multi-row statement; pick out the
    // table_cell rule by its distinctive nested literal. The JSON values contain
    // no single quotes, so a [^']* slice up to the closing quote is exact.
    const tcMatch = voInsert.match(/'(\{"op":"concat"[^']*"table_cell"[^']*\})'/);
    assert.ok(tcMatch, 'variant_overrides INSERT must embed the table_cell compute_rule JSON literal');

    const parsed = JSON.parse(tcMatch[1]);
    assert.deepEqual(parsed, COMPUTE_RULE_TABLE_CELL_OBJ);

    // Explicitly pin the three table_cell keys the refactor must never drop.
    const cell = parsed.config.parts.find((p) => p.type === 'table_cell').cell;
    assert.equal(cell.table_key, 'items');
    assert.equal(cell.column_key, 'part');
    assert.equal(cell.row, 'last');
  });
});

describe('operator-mode: target schema missing compute_rule', () => {
  // When the target deployment never received the compute_rule ADD COLUMN
  // migration, the seed INSERT naming that column raises ER_BAD_FIELD_ERROR
  // (errno 1054). v3.2.151 classifies this schema-drift as an actionable
  // 422 SEED_SCHEMA_MISMATCH (naming the mismatch) instead of an opaque 500.
  // The whole batch must still roll back and never commit a partial batch.
  it('surfaces a 422 SEED_SCHEMA_MISMATCH and rolls back rather than corrupting the batch', async () => {
    const { body: dump } = await getText(exportPort, '/api/export/mariadb-sql');

    seedCapture = { applied: [], began: false, committed: false, rolledBack: false };
    rwConnFactory = () => makeSeedConn({ missingColumns: ['compute_rule'] });

    const res = await postJson(seedPort, '/api/setup/seed', { sql: dump });

    assert.equal(res.status, 422, 'schema-behind target surfaces as 422 SEED_SCHEMA_MISMATCH');
    assert.equal(res.json?.error?.code, 'SEED_SCHEMA_MISMATCH');
    assert.equal(res.json?.error?.details?.errno, 1054);
    assert.match(res.json?.error?.details?.db_message || '', /Unknown column 'compute_rule'/);
    assert.equal(seedCapture.rolledBack, true, 'batch must roll back on the failing statement');
    assert.equal(seedCapture.committed, false, 'must not commit a partial batch');
  });
});
