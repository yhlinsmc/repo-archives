/**
 * compute-cycle-cross-level.test.js — the two-level compute-cycle guard against
 * a REAL MariaDB schema built from table-ddls.js, driving the real routes over
 * HTTP.
 *
 * WHY a real DB here: every other test around this guard stubs its query
 * results, so a column that exists only in code — or a JSON column whose driver
 * representation differs from the fixture's — stays green in both runners and
 * only fails in production. This test creates the actual declared schema, writes
 * real rows, and asserts the cycle spanning one blueprint-level rule and one
 * variant-level rule is rejected from EITHER direction:
 *
 *   direction 1: blueprint rule stored first, the variant-override write closes
 *                the loop;
 *   direction 2: variant override stored first, the blueprint-field write
 *                closes the loop.
 *
 * Graceful skip when no MariaDB is reachable; CI sets REQUIRE_INTEGRATION_DB=1.
 */
'use strict';

const { test, describe, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const net = require('node:net');
const http = require('node:http');
const express = require('express');
const mariadb = require('mariadb');

const TEST_PREFIX = 'ccx_';
const t = (name) => `${TEST_PREFIX}${name}`;

// Inject the db module BEFORE the router is required: `pool` is read through a
// live getter so the real pool can be created later, in before().
let realPool = null;
const dbKey = require.resolve('../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey,
  filename: dbKey,
  loaded: true,
  exports: {
    t,
    getDynamicPool: async () => require(dbKey).pool,
    get pool() {
      return {
        rw: { getConnection: () => realPool.getConnection() },
        ro: { getConnection: () => realPool.getConnection() },
      };
    },
  },
};

const { buildAllTableDDLs } = require('../../src/table-ddls');
const router = require('../../src/edge/routes/app/schema');

// ── Config auto-detection (same shape as the other integration tests) ────────

function parseEnvFile(filePath) {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    const out = {};
    for (const line of content.split('\n')) {
      const m = line.match(/^\s*([A-Z_][A-Z0-9_]*)\s*=\s*(.*)\s*$/);
      if (!m) continue;
      let value = m[2];
      if ((value.startsWith('"') && value.endsWith('"'))
          || (value.startsWith("'") && value.endsWith("'"))) {
        value = value.slice(1, -1);
      }
      out[m[1]] = value;
    }
    return out;
  } catch {
    return null;
  }
}

function probePort(host, port, timeoutMs = 2000) {
  return new Promise((resolve) => {
    const socket = new net.Socket();
    let done = false;
    const finish = (ok) => {
      if (done) return;
      done = true;
      socket.destroy();
      resolve(ok);
    };
    socket.setTimeout(timeoutMs);
    socket.once('connect', () => finish(true));
    socket.once('timeout', () => finish(false));
    socket.once('error', () => finish(false));
    socket.connect(port, host);
  });
}

async function resolveMariaDbConfig() {
  if (process.env.DB_TEST_HOST && process.env.DB_TEST_ROOT_PASSWORD) {
    return {
      host: process.env.DB_TEST_HOST,
      port: parseInt(process.env.DB_TEST_PORT || '3306', 10),
      user: 'root',
      password: process.env.DB_TEST_ROOT_PASSWORD,
    };
  }
  const env = parseEnvFile(path.resolve(__dirname, '../../../.devcontainer/.env'));
  if (!env || !env.DB_ROOT_PASSWORD) return null;
  const port = parseInt(env.DB_PORT || '3306', 10);
  for (const host of ['127.0.0.1', 'mariadb', 'localhost']) {
    if (await probePort(host, port, 2000)) {
      return { host, port, user: 'root', password: env.DB_ROOT_PASSWORD };
    }
  }
  return null;
}

// ── Fixture ids ─────────────────────────────────────────────────────────────

const BP_ID = 'bp-ccx-0001';
const V1_ID = 'v-ccx-0001';
const V2_ID = 'v-ccx-0002';
const F_A_ID = 'f-ccx-a-01'; // field_key 'cyc_a'
const F_B_ID = 'f-ccx-b-01'; // field_key 'cyc_b'
const F_P_ID = 'f-ccx-p-01'; // field_key 'plain'

const concat = (...keys) => ({
  op: 'concat',
  overridable: false,
  output_type: 'string',
  config: { parts: keys.map((key) => ({ type: 'field', key })) },
});

let dbConfig = null;
let testDbName = null;
let dbReady = false;
let skipReason = null;
let server = null;
let port = null;

before(async () => {
  dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) {
    skipReason = 'no MariaDB reachable via .devcontainer/.env or env vars';
    if (process.env.REQUIRE_INTEGRATION_DB === '1') {
      throw new Error(`REQUIRE_INTEGRATION_DB=1 set but ${skipReason}.`);
    }
    return;
  }

  testDbName = `ccx_${process.pid}_${Date.now()}`;
  let adminConn = null;
  try {
    adminConn = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await adminConn.query(`CREATE DATABASE \`${testDbName}\``);
    await adminConn.end();
    adminConn = null;

    realPool = mariadb.createPool({
      ...dbConfig, database: testDbName, connectionLimit: 4, connectTimeout: 5000,
    });
    const conn = await realPool.getConnection();
    try {
      // The declared schema itself — not a hand-copied subset, so a column this
      // guard reads but table-ddls.js never declares fails here.
      for (const ddl of buildAllTableDDLs(t)) await conn.query(ddl);
      await conn.query(
        `INSERT INTO \`${t('hierarchy_nodes')}\` (id, name, node_type, parent_id, owner_id) VALUES
         (?, 'BP', 'blueprint', NULL, NULL),
         (?, 'V1', 'variant',   ?,    NULL),
         (?, 'V2', 'variant',   ?,    NULL)`,
        [BP_ID, V1_ID, BP_ID, V2_ID, BP_ID],
      );
      await conn.query(
        `INSERT INTO \`${t('blueprint_fields')}\` (id, blueprint_id, field_key, field_type) VALUES
         (?, ?, 'cyc_a', 'text'), (?, ?, 'cyc_b', 'text'), (?, ?, 'plain', 'text')`,
        [F_A_ID, BP_ID, F_B_ID, BP_ID, F_P_ID, BP_ID],
      );
    } finally {
      conn.release();
    }

    const app = express();
    app.use(express.json());
    app.use((req, _res, next) => { req.user = { id: 'admin-ccx', role: 'admin' }; next(); });
    app.use('/edge/app/schema', router);
    await new Promise((resolve) => {
      server = app.listen(0, '127.0.0.1', () => { port = server.address().port; resolve(); });
    });
    dbReady = true;
  } catch (err) {
    skipReason = `setup failed: ${err.message}`;
    if (adminConn) { try { await adminConn.end(); } catch { /* teardown */ } }
    if (process.env.REQUIRE_INTEGRATION_DB === '1') throw err;
  }
});

after(async () => {
  if (server) await new Promise((resolve) => server.close(resolve));
  if (realPool) { try { await realPool.end(); } catch { /* teardown */ } }
  if (testDbName && dbConfig) {
    try {
      const cleanup = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
      await cleanup.query(`DROP DATABASE IF EXISTS \`${testDbName}\``);
      await cleanup.end();
    } catch (err) {
      process.stderr.write(`[teardown] failed to drop ${testDbName}: ${err.message}\n`);
    }
  }
  delete require.cache[dbKey];
});

beforeEach(async () => {
  if (!dbReady) return;
  const conn = await realPool.getConnection();
  try {
    await conn.query(`DELETE FROM \`${t('variant_overrides')}\``);
    // BOTH columns, or the reset leaves rows in the one state the write
    // boundary refuses — a mode naming a rule that is no longer there.
    await conn.query(
      `UPDATE \`${t('blueprint_fields')}\` SET compute_rule = NULL, value_source = 'entered'`,
    );
  } finally {
    conn.release();
  }
});

function request(method, urlPath, body) {
  return new Promise((resolve, reject) => {
    const data = JSON.stringify(body);
    const r = http.request({
      method, host: '127.0.0.1', port, path: urlPath,
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(data) },
    }, (res) => {
      let raw = '';
      res.on('data', (c) => { raw += c; });
      res.on('end', () => resolve({ status: res.statusCode, body: raw ? JSON.parse(raw) : null }));
    });
    r.on('error', reject);
    r.write(data);
    r.end();
  });
}

const postOverride = (body) => request('POST', '/edge/app/schema/variant_overrides', body);
const putField = (id, body) => request('PUT', `/edge/app/schema/blueprint_fields/${id}`, body);
/**
 * A blueprint-level rule write, in the shape the write boundary now requires:
 * the rule and the mode it is the rule OF travel together, so a stored
 * 'calculated' can never outlive the rule that made it true.
 */
const putRule = (id, rule) => putField(id, { value_source: 'calculated', compute_rule: rule });

async function countOverrides() {
  const conn = await realPool.getConnection();
  try {
    const rows = await conn.query(`SELECT COUNT(*) AS n FROM \`${t('variant_overrides')}\``);
    return Number(rows[0].n);
  } finally {
    conn.release();
  }
}

async function storedRule(fieldId) {
  const conn = await realPool.getConnection();
  try {
    const rows = await conn.query(
      `SELECT compute_rule FROM \`${t('blueprint_fields')}\` WHERE id = ?`, [fieldId],
    );
    const raw = rows[0].compute_rule;
    return typeof raw === 'string' ? JSON.parse(raw) : raw;
  } finally {
    conn.release();
  }
}

describe('compute cycle spanning both levels — real schema, real routes', () => {
  test('direction 1: a variant override that closes a loop with a stored blueprint rule is rejected', async (ctx) => {
    if (!dbReady) return ctx.skip(skipReason);

    // Persist the blueprint-level half: cyc_a <- cyc_b, applying to every variant.
    const seed = await putRule(F_A_ID, concat('cyc_b'));
    assert.equal(seed.status, 200, JSON.stringify(seed.body));
    assert.deepEqual(await storedRule(F_A_ID), concat('cyc_b'));

    // The variant-level half closes the loop: cyc_b <- cyc_a.
    const res = await postOverride({
      variant_id: V1_ID, field_id: F_B_ID, action: 'compute', compute_rule: concat('cyc_a'),
    });
    assert.equal(res.status, 400, JSON.stringify(res.body));
    assert.equal(res.body.error.code, 'cycle');
    assert.equal(await countOverrides(), 0, 'the rejected override must not be persisted');
  });

  test('direction 2: a blueprint-field write that closes a loop with a stored variant override is rejected', async (ctx) => {
    if (!dbReady) return ctx.skip(skipReason);

    // Persist the variant-level half first: cyc_a <- cyc_b on V1 only.
    const seed = await postOverride({
      variant_id: V1_ID, field_id: F_A_ID, action: 'compute', compute_rule: concat('cyc_b'),
    });
    assert.equal(seed.status, 200, JSON.stringify(seed.body));

    // The blueprint-level half closes the loop for V1.
    const res = await putRule(F_B_ID, concat('cyc_a'));
    assert.equal(res.status, 400, JSON.stringify(res.body));
    assert.equal(res.body.error.code, 'cycle');
    assert.equal(await storedRule(F_B_ID), null, 'the rejected rule must not be persisted');
  });

  test('one blueprint-field write is checked against every variant', async (ctx) => {
    if (!dbReady) return ctx.skip(skipReason);

    // V1 is harmless; only V2 would cycle. The write must still be rejected.
    let seed = await postOverride({
      variant_id: V1_ID, field_id: F_A_ID, action: 'compute', compute_rule: concat('plain'),
    });
    assert.equal(seed.status, 200, JSON.stringify(seed.body));
    seed = await postOverride({
      variant_id: V2_ID, field_id: F_A_ID, action: 'compute', compute_rule: concat('cyc_b'),
    });
    assert.equal(seed.status, 200, JSON.stringify(seed.body));

    const res = await putRule(F_B_ID, concat('cyc_a'));
    assert.equal(res.status, 400, JSON.stringify(res.body));
    assert.equal(res.body.error.code, 'cycle');
  });

  test('a blueprint rule shadowed by the variant it would cycle in is accepted', async (ctx) => {
    if (!dbReady) return ctx.skip(skipReason);

    // V1 would cycle (cyc_a <- cyc_b) but also replaces cyc_b with a rule of its
    // own, so the incoming blueprint rule on cyc_b never evaluates there.
    let seed = await postOverride({
      variant_id: V1_ID, field_id: F_A_ID, action: 'compute', compute_rule: concat('cyc_b'),
    });
    assert.equal(seed.status, 200, JSON.stringify(seed.body));
    seed = await postOverride({
      variant_id: V1_ID, field_id: F_B_ID, action: 'compute', compute_rule: concat('plain'),
    });
    assert.equal(seed.status, 200, JSON.stringify(seed.body));

    const res = await putRule(F_B_ID, concat('cyc_a'));
    assert.equal(res.status, 200, JSON.stringify(res.body));
    assert.deepEqual(await storedRule(F_B_ID), concat('cyc_a'));
  });

  test('a blueprint rule that cycles with itself is rejected even with no variants involved', async (ctx) => {
    if (!dbReady) return ctx.skip(skipReason);
    const res = await putRule(F_B_ID, concat('cyc_b'));
    assert.equal(res.status, 400, JSON.stringify(res.body));
    assert.equal(res.body.error.code, 'cycle');
    assert.equal(await storedRule(F_B_ID), null);
  });

  test('cell_targets is rejected on a non-table field against the real schema', async (ctx) => {
    if (!dbReady) return ctx.skip(skipReason);
    const res = await postOverride({
      variant_id: V1_ID, field_id: F_A_ID, action: 'lock', cell_targets: { columns: ['qty'] },
    });
    assert.equal(res.status, 400, JSON.stringify(res.body));
    assert.equal(res.body.error.code, 'INVALID_CELL_TARGETS');
    assert.equal(await countOverrides(), 0);
  });
});
