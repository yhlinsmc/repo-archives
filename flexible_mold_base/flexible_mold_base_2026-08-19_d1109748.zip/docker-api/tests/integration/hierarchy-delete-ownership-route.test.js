'use strict';

/**
 * hierarchy-delete-ownership-route.test.js
 *
 * Route-level tests for the two owner-aware hierarchy destructive endpoints:
 *   GET    /hierarchy_nodes/:id/cascade-preview
 *   DELETE /hierarchy_nodes/:id
 *
 * Both switched from admin-only to admin-or-owner: an editor may preview /
 * delete a blueprint (or its variants) they own; other users' blueprints and
 * structural nodes stay 403 for non-admins. Harness mirrors
 * hierarchy-reparent-route.test.js (require.cache DB stub + real HTTP server +
 * makeConn script runner; node:test runner).
 */

const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');
const { answerCollationProbe } = require('../helpers/collation-probe');

// ── DB stub must be in cache BEFORE the router is required ───────────────────
const dbKey = require.resolve('../../src/edge/db');
const portableInsertKey = require.resolve('../../src/edge/lib/portable-insert');

let conn;

function makeConn(scripts) {
  const queries = [];
  return {
    queries,
    async query(sql, params) {
      // The owner check asks the COLUMN whether the row is the caller's, so the
      // double has to be able to answer as the column would — see
      // tests/helpers/collation-probe.js. Kept out of `queries` because every
      // SQL-shape assertion in this file is about which STATEMENTS the route
      // issues.
      const probed = answerCollationProbe(sql, params);
      if (probed !== undefined) return probed;
      queries.push({ sql, params });
      for (const [matcher, response] of scripts) {
        if (matcher.test(sql)) {
          return typeof response === 'function' ? response(sql, params) : response;
        }
      }
      // ── Generic fallbacks for the cascade machinery so each test only needs
      //    to script the authorization-relevant queries. ──
      // Owner-fetch: default to "missing row" unless a test scripts it.
      if (/SELECT id, node_type, owner_id FROM/.test(sql)) return [];
      // collectDescendantIds BFS: no descendants.
      if (/SELECT id FROM[\s\S]* WHERE parent_id IN/.test(sql)) return [];
      // previewCascade COUNT(*) queries.
      if (/SELECT COUNT\(\*\) AS n/.test(sql)) return [{ n: 0 }];
      // tableExists(blueprint_groups) probe → treat table as absent (skip delete).
      if (/information_schema\.TABLES/.test(sql)) return [];
      // previewCascade user_templates list → none affected.
      if (/SELECT id, name FROM[\s\S]*user_templates/i.test(sql)) return [];
      // DELETE referrer guard → no borrowers by default.
      if (/SELECT id, name FROM[\s\S]*linked_blueprint_id IN/.test(sql)) return [];
      // Cascade deletes: root hierarchy_nodes delete reports 1 row; dependents 0.
      if (/DELETE FROM[^\n]*hierarchy_nodes/i.test(sql)) return { affectedRows: 1 };
      if (/DELETE FROM/i.test(sql)) return { affectedRows: 0 };
      throw new Error(`Unmatched query in delete-ownership test: ${sql.slice(0, 140)}`);
    },
    release() { /* noop */ },
    async beginTransaction() {},
    async commit() {},
    async rollback() {},
  };
}

const poolSpy = {
  rw: { async getConnection() { return conn; } },
  ro: { async getConnection() { return conn; } },
};

require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: {
    pool: poolSpy,
    t: (name) => `fmb_${name}`,
    getDynamicPool: async () => poolSpy,
  },
};

const router = require('../../src/edge/routes/app/schema');

// ── HTTP servers, one per role ────────────────────────────────────────────────
let adminServer, adminPort;
let editorServer, editorPort;
let userServer, userPort;

function makeApp(role, userId) {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => {
    req.user = { id: userId || `${role}-1`, role };
    next();
  });
  app.use('/edge/app/schema', router);
  return app;
}

before(async () => {
  await new Promise((resolve) => {
    adminServer = makeApp('admin', 'admin-uuid-1').listen(0, '127.0.0.1', () => {
      adminPort = adminServer.address().port; resolve();
    });
  });
  await new Promise((resolve) => {
    editorServer = makeApp('editor', 'editor-uuid-1').listen(0, '127.0.0.1', () => {
      editorPort = editorServer.address().port; resolve();
    });
  });
  await new Promise((resolve) => {
    userServer = makeApp('user', 'user-uuid-1').listen(0, '127.0.0.1', () => {
      userPort = userServer.address().port; resolve();
    });
  });
});

after(async () => {
  await new Promise((resolve) => adminServer.close(resolve));
  await new Promise((resolve) => editorServer.close(resolve));
  await new Promise((resolve) => userServer.close(resolve));
  delete require.cache[dbKey];
});

beforeEach(() => {
  conn = null;
  if (require.cache[portableInsertKey]) {
    const mod = require.cache[portableInsertKey].exports;
    if (typeof mod.__clearPortableColumnCache === 'function') mod.__clearPortableColumnCache();
  }
});

// ── HTTP helpers ──────────────────────────────────────────────────────────────
function request(method, port, path) {
  return new Promise((resolve, reject) => {
    const req = http.request({ method, host: '127.0.0.1', port, path }, (res) => {
      let raw = '';
      res.on('data', (chunk) => { raw += chunk; });
      res.on('end', () => resolve({ status: res.statusCode, body: raw ? JSON.parse(raw) : null }));
    });
    req.on('error', reject);
    req.end();
  });
}
const get = (port, path) => request('GET', port, path);
const del = (port, path) => request('DELETE', port, path);

// ── Fixtures ──────────────────────────────────────────────────────────────────
const BLUEPRINT_ID = '11111111-1111-4111-8111-111111111111';
const VARIANT_ID   = '77777777-7777-4777-8777-777777777777';
const RELEASE_ID   = '22222222-2222-4222-8222-222222222222';
const EDITOR_ID    = 'editor-uuid-1';
const STRANGER_ID  = 'stranger-uuid';

// Node-fetch rows returned by the owner gate SELECT (`id, node_type, owner_id`).
const blueprintNode = (owner_id) => [{ id: BLUEPRINT_ID, node_type: 'blueprint', owner_id }];
const variantNode   = (owner_id) => [{ id: VARIANT_ID, node_type: 'variant', owner_id }];
const structuralNode = () => [{ id: RELEASE_ID, node_type: 'release', owner_id: null }];

const OWNER_FETCH = /SELECT id, node_type, owner_id FROM/;

const previewPath = (id) => `/edge/app/schema/hierarchy_nodes/${id}/cascade-preview`;
const deletePath  = (id) => `/edge/app/schema/hierarchy_nodes/${id}`;

function countDeletes(c) {
  return c.queries.filter((q) => /^\s*DELETE FROM/i.test(q.sql)).length;
}

// ── cascade-preview ─────────────────────────────────────────────────────────────
describe('GET /hierarchy_nodes/:id/cascade-preview — owner-aware', () => {
  it('admin previews any blueprint → 200 with counts', async () => {
    conn = makeConn([[OWNER_FETCH, blueprintNode(null)]]);
    const res = await get(adminPort, previewPath(BLUEPRINT_ID));
    assert.equal(res.status, 200, JSON.stringify(res.body));
    assert.equal(typeof res.body.data.nodes, 'number');
    assert.equal(res.body.data.blueprint_fields, 0);
  });

  it('editor previews a blueprint they OWN → 200', async () => {
    conn = makeConn([[OWNER_FETCH, blueprintNode(EDITOR_ID)]]);
    const res = await get(editorPort, previewPath(BLUEPRINT_ID));
    assert.equal(res.status, 200, JSON.stringify(res.body));
    assert.equal(typeof res.body.data.nodes, 'number');
  });

  it('editor previews a shared (NULL-owner) blueprint → 200', async () => {
    conn = makeConn([[OWNER_FETCH, blueprintNode(null)]]);
    const res = await get(editorPort, previewPath(BLUEPRINT_ID));
    assert.equal(res.status, 200, JSON.stringify(res.body));
  });

  it('editor previews a VARIANT of their own blueprint (inherited owner) → 200', async () => {
    conn = makeConn([[OWNER_FETCH, variantNode(EDITOR_ID)]]);
    const res = await get(editorPort, previewPath(VARIANT_ID));
    assert.equal(res.status, 200, JSON.stringify(res.body));
  });

  it("editor previews another user's blueprint → 403", async () => {
    conn = makeConn([[OWNER_FETCH, blueprintNode(STRANGER_ID)]]);
    const res = await get(editorPort, previewPath(BLUEPRINT_ID));
    assert.equal(res.status, 403, JSON.stringify(res.body));
    assert.equal(res.body.error.code, 'FORBIDDEN');
    assert.match(res.body.error.message, /blueprint you own/);
  });

  it("editor previews another user's VARIANT → 403", async () => {
    conn = makeConn([[OWNER_FETCH, variantNode(STRANGER_ID)]]);
    const res = await get(editorPort, previewPath(VARIANT_ID));
    assert.equal(res.status, 403, JSON.stringify(res.body));
    assert.equal(res.body.error.code, 'FORBIDDEN');
    assert.match(res.body.error.message, /blueprint you own/);
  });

  it('editor previews a STRUCTURAL node (release) → 403 (admin-only)', async () => {
    conn = makeConn([[OWNER_FETCH, structuralNode()]]);
    const res = await get(editorPort, previewPath(RELEASE_ID));
    assert.equal(res.status, 403, JSON.stringify(res.body));
    assert.equal(res.body.error.code, 'FORBIDDEN');
  });

  it('plain user → 403 (blocked at the coarse gate)', async () => {
    conn = makeConn([[OWNER_FETCH, blueprintNode(null)]]);
    const res = await get(userPort, previewPath(BLUEPRINT_ID));
    assert.equal(res.status, 403, JSON.stringify(res.body));
    assert.equal(res.body.error.code, 'FORBIDDEN');
  });

  it('admin previews a MISSING node → 404 (no bogus 200)', async () => {
    // Owner-fetch falls through to the default "[] = missing" fallback.
    conn = makeConn([]);
    const res = await get(adminPort, previewPath(BLUEPRINT_ID));
    assert.equal(res.status, 404, JSON.stringify(res.body));
    assert.equal(res.body.error.code, 'NOT_FOUND');
  });

  it('editor previews a MISSING node → 404 (not a misleading 403)', async () => {
    conn = makeConn([]);
    const res = await get(editorPort, previewPath(BLUEPRINT_ID));
    assert.equal(res.status, 404, JSON.stringify(res.body));
    assert.equal(res.body.error.code, 'NOT_FOUND');
  });
});

// ── DELETE ──────────────────────────────────────────────────────────────────────
describe('DELETE /hierarchy_nodes/:id — owner-aware', () => {
  it('admin deletes a blueprint → 200 with cascade applied', async () => {
    conn = makeConn([[OWNER_FETCH, blueprintNode(null)]]);
    const res = await del(adminPort, deletePath(BLUEPRINT_ID));
    assert.equal(res.status, 200, JSON.stringify(res.body));
    assert.equal(res.body.data.ok, true);
    assert.equal(res.body.data.applied.nodes, 1);
  });

  it('admin deletes a STRUCTURAL node → 200 (only admins may)', async () => {
    conn = makeConn([[OWNER_FETCH, structuralNode()]]);
    const res = await del(adminPort, deletePath(RELEASE_ID));
    assert.equal(res.status, 200, JSON.stringify(res.body));
  });

  it('editor deletes a blueprint they OWN → 200', async () => {
    conn = makeConn([[OWNER_FETCH, blueprintNode(EDITOR_ID)]]);
    const res = await del(editorPort, deletePath(BLUEPRINT_ID));
    assert.equal(res.status, 200, JSON.stringify(res.body));
    assert.equal(res.body.data.ok, true);
  });

  it('editor deletes a VARIANT of their own blueprint → 200', async () => {
    conn = makeConn([[OWNER_FETCH, variantNode(EDITOR_ID)]]);
    const res = await del(editorPort, deletePath(VARIANT_ID));
    assert.equal(res.status, 200, JSON.stringify(res.body));
  });

  it("editor deletes another user's VARIANT → 403 and NO rows deleted", async () => {
    conn = makeConn([[OWNER_FETCH, variantNode(STRANGER_ID)]]);
    const res = await del(editorPort, deletePath(VARIANT_ID));
    assert.equal(res.status, 403, JSON.stringify(res.body));
    assert.equal(res.body.error.code, 'FORBIDDEN');
    assert.match(res.body.error.message, /blueprint you own/);
    assert.equal(countDeletes(conn), 0, 'denied delete must mutate nothing');
  });

  it("editor deletes another user's blueprint → 403 and NO rows deleted", async () => {
    conn = makeConn([[OWNER_FETCH, blueprintNode(STRANGER_ID)]]);
    const res = await del(editorPort, deletePath(BLUEPRINT_ID));
    assert.equal(res.status, 403, JSON.stringify(res.body));
    assert.equal(res.body.error.code, 'FORBIDDEN');
    assert.match(res.body.error.message, /blueprint you own/);
    // The guard runs before cascadeDeleteNode — no DELETE statement issued.
    assert.equal(countDeletes(conn), 0, 'denied delete must mutate nothing');
  });

  it('editor deletes a STRUCTURAL node → 403 and NO rows deleted', async () => {
    conn = makeConn([[OWNER_FETCH, structuralNode()]]);
    const res = await del(editorPort, deletePath(RELEASE_ID));
    assert.equal(res.status, 403, JSON.stringify(res.body));
    assert.equal(countDeletes(conn), 0);
  });

  it('plain user → 403 (coarse gate) and NO rows deleted', async () => {
    conn = makeConn([[OWNER_FETCH, blueprintNode(null)]]);
    const res = await del(userPort, deletePath(BLUEPRINT_ID));
    assert.equal(res.status, 403, JSON.stringify(res.body));
    assert.equal(countDeletes(conn), 0);
  });

  it('missing node → 404 (unchanged) and NO rows deleted', async () => {
    // Owner-fetch falls through to the default "[] = missing" fallback.
    conn = makeConn([]);
    const res = await del(adminPort, deletePath(BLUEPRINT_ID));
    assert.equal(res.status, 404, JSON.stringify(res.body));
    assert.equal(res.body.error.code, 'NOT_FOUND');
    assert.equal(countDeletes(conn), 0);
  });

  it('referrer-link guard still fires under the new gate → 409 and NO rows deleted', async () => {
    conn = makeConn([
      [OWNER_FETCH, blueprintNode(EDITOR_ID)],
      // A borrowing blueprint links to the target → referrer guard trips.
      [/SELECT id, name FROM[\s\S]*linked_blueprint_id IN/, [{ id: 'ref-1', name: 'Borrower' }]],
    ]);
    const res = await del(editorPort, deletePath(BLUEPRINT_ID));
    assert.equal(res.status, 409, JSON.stringify(res.body));
    assert.equal(res.body.error.code, 'LINK_SOURCE_IN_USE');
    // Referrer guard rolls back before the cascade — no hierarchy_nodes delete.
    const nodeDeletes = conn.queries.filter((q) => /DELETE FROM[^\n]*hierarchy_nodes/i.test(q.sql));
    assert.equal(nodeDeletes.length, 0, 'referrer 409 must not delete nodes');
  });

  it('owner check for DELETE resolves under FOR UPDATE (inside the write transaction)', async () => {
    conn = makeConn([[OWNER_FETCH, blueprintNode(EDITOR_ID)]]);
    await del(editorPort, deletePath(BLUEPRINT_ID));
    const ownerFetch = conn.queries.find((q) => OWNER_FETCH.test(q.sql));
    assert.ok(ownerFetch, 'owner gate must SELECT the node');
    assert.match(ownerFetch.sql, /FOR UPDATE/, 'DELETE owner gate must lock the row FOR UPDATE');
  });
});
