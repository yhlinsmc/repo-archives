/**
 * variant-overrides-toctou.test.js — v3.2.106 P1
 *
 * Verifies the TOCTOU race-only safety net (AND EXISTS subquery on UPDATE)
 * for `PUT /variant_overrides/:id`. The pre-UPDATE checks already do
 * coherence/ownership validation; this test proves the guard at UPDATE
 * time blocks a concurrent owner_id transfer / parent_id flip /
 * node_type flip occurring between the pre-UPDATE SELECT and the UPDATE
 * itself.
 *
 * What we prove
 * -------------
 *   (a) admin coherence-violation race      — concurrent parent_id flip
 *       mid-flight is rejected post-UPDATE with 409 race_detected
 *   (b) editor OLD-ownership race           — concurrent owner_id transfer
 *       mid-flight is rejected with 409 race_detected
 *   (c) editor NEW-pair race on fkChanged   — concurrent node_type flip
 *       on the new variant target is rejected with 409 race_detected
 *   (d) admin no-FK-change happy path       — admin doesn't carry the
 *       editor OLD-ownership extra EXISTS, so the row updates 200
 *
 * What we skip (per design doc and CEO/Eng consensus)
 * ---------------------------------------------------
 *   - Lock-wait timeout exhaustion          (innodb_lock_wait_timeout
 *                                            tuning is a separate hardening
 *                                            concern)
 *   - Deadlock victim retry                 (no transactions inside the
 *                                            handler; the AND EXISTS happens
 *                                            within a single UPDATE statement)
 *
 * How it connects
 * ---------------
 * Auto-detects MariaDB the same way `transformer-owner-transfer-concurrent.test.js`
 * does (env vars first, then .devcontainer/.env, then probe candidate hosts).
 * If none respond → graceful t.skip() unless REQUIRE_INTEGRATION_DB=1. On
 * reachable DB: creates an ephemeral DB `vo_toctou_test_<pid>_<ms>`, builds
 * the three minimal tables (hierarchy_nodes, blueprint_fields,
 * variant_overrides), seeds the fixture, runs the race, asserts post-state,
 * drops the DB.
 *
 * Zero new npm dependencies — uses the same `mariadb` driver already in
 * docker-api/package.json. AIRGAP-clean.
 */

const { test, describe, before, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const net = require('node:net');
const mariadb = require('mariadb');

// Load the helper from production source — mirrors the SQL the handler emits.
const { buildVariantOverrideUpdateExistsClause } = require('../../src/edge/lib/variant-override-helpers');

// ── Config auto-detection (verbatim shape from canonical pattern) ────────────

function parseEnvFile(filePath) {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    const out = {};
    for (const line of content.split('\n')) {
      const m = line.match(/^\s*([A-Z_][A-Z0-9_]*)\s*=\s*(.*)\s*$/);
      if (!m) continue;
      let value = m[2];
      if ((value.startsWith('"') && value.endsWith('"')) ||
          (value.startsWith("'") && value.endsWith("'"))) {
        value = value.slice(1, -1);
      }
      out[m[1]] = value;
    }
    return out;
  } catch {
    return null;
  }
}

function probePort(host, port, timeoutMs = 2000) {
  return new Promise((resolve) => {
    const socket = new net.Socket();
    let done = false;
    const finish = (ok) => {
      if (done) return;
      done = true;
      socket.destroy();
      resolve(ok);
    };
    socket.setTimeout(timeoutMs);
    socket.once('connect', () => finish(true));
    socket.once('timeout', () => finish(false));
    socket.once('error', () => finish(false));
    socket.connect(port, host);
  });
}

async function resolveMariaDbConfig() {
  if (process.env.DB_TEST_HOST && process.env.DB_TEST_ROOT_PASSWORD) {
    return {
      host: process.env.DB_TEST_HOST,
      port: parseInt(process.env.DB_TEST_PORT || '3306', 10),
      user: 'root',
      password: process.env.DB_TEST_ROOT_PASSWORD,
    };
  }
  const envPath = path.resolve(__dirname, '../../../.devcontainer/.env');
  const env = parseEnvFile(envPath);
  if (!env || !env.DB_ROOT_PASSWORD) return null;
  const port = parseInt(env.DB_PORT || '3306', 10);
  const password = env.DB_ROOT_PASSWORD;
  const candidates = ['127.0.0.1', 'mariadb', 'localhost'];
  for (const host of candidates) {
    if (await probePort(host, port, 2000)) {
      return { host, port, user: 'root', password };
    }
  }
  return null;
}

// ── Fixture ──────────────────────────────────────────────────────────────────

const TEST_PREFIX = 'vot_'; // variant_overrides toctou test

const TABLES_LOCAL = {
  HIERARCHY_NODES: 'hierarchy_nodes',
  BLUEPRINT_FIELDS: 'blueprint_fields',
  VARIANT_OVERRIDES: 'variant_overrides',
};
const tbl = (name) => `${TEST_PREFIX}${name}`;

const HIERARCHY_NODES_DDL = `
  CREATE TABLE \`${tbl('hierarchy_nodes')}\` (
    id          CHAR(36) PRIMARY KEY,
    name        VARCHAR(255) NOT NULL DEFAULT '',
    node_type   ENUM('generation','release','blueprint','variant') NOT NULL,
    parent_id   CHAR(36) NULL,
    owner_id    CHAR(36) NULL DEFAULT NULL,
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
`;

const BLUEPRINT_FIELDS_DDL = `
  CREATE TABLE \`${tbl('blueprint_fields')}\` (
    id            CHAR(36) PRIMARY KEY,
    blueprint_id  CHAR(36) NOT NULL,
    field_key     VARCHAR(255) NOT NULL,
    created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
`;

// v3.2.109+ shape — match production schema for parity with the
// post-migration runtime invariants (action NOT NULL, UNIQUE on triple).
const VARIANT_OVERRIDES_DDL = `
  CREATE TABLE \`${tbl('variant_overrides')}\` (
    id             CHAR(36) PRIMARY KEY,
    variant_id     CHAR(36),
    field_id       CHAR(36),
    action         VARCHAR(100) NOT NULL DEFAULT '',
    override_value TEXT,
    created_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_variant_override_triple (variant_id, field_id, action)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
`;

// Seed entities — two blueprints (BP1, BP2), two variants (V1 under BP1,
// V2 under BP2), two fields (F1 under BP1, F2 under BP2), two editors
// (E1 owns BP1, E2 owns BP2), and two override rows (one under each
// blueprint). Names suffixed for traceability across race scenarios.
const ADMIN_ID = 'admin-aaaa';
const EDITOR1_ID = 'editor-1111';
const EDITOR2_ID = 'editor-2222';
const BP1_ID = 'bp-1';
const BP2_ID = 'bp-2';
const V1_ID = 'v-1';
const V2_ID = 'v-2';
const F1_ID = 'f-1';
const F2_ID = 'f-2';
const VO1_ID = 'vo-1'; // (V1, F1) under BP1, owned by E1
const VO2_ID = 'vo-2'; // (V2, F2) under BP2, owned by E2

// ── Test state ───────────────────────────────────────────────────────────────

let dbReady = false;
let dbConfig = null;
let testDbName = null;
let skipReason = null;
let pool = null;

before(async () => {
  dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) {
    skipReason = 'no MariaDB reachable via .devcontainer/.env or env vars';
    if (process.env.REQUIRE_INTEGRATION_DB === '1') {
      throw new Error(
        `REQUIRE_INTEGRATION_DB=1 set but ${skipReason}. ` +
        'CI expected an integration database; check the test stage.',
      );
    }
    return;
  }

  testDbName = `vo_toctou_test_${process.pid}_${Date.now()}`;
  let adminConn = null;
  try {
    adminConn = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await adminConn.query(`CREATE DATABASE \`${testDbName}\``);
    await adminConn.query(`USE \`${testDbName}\``);
    await adminConn.query(HIERARCHY_NODES_DDL);
    await adminConn.query(BLUEPRINT_FIELDS_DDL);
    await adminConn.query(VARIANT_OVERRIDES_DDL);

    // Two blueprints with distinct owners
    await adminConn.query(
      `INSERT INTO \`${tbl('hierarchy_nodes')}\` (id, name, node_type, parent_id, owner_id) VALUES
       (?, 'BP1', 'blueprint', NULL, ?),
       (?, 'BP2', 'blueprint', NULL, ?)`,
      [BP1_ID, EDITOR1_ID, BP2_ID, EDITOR2_ID],
    );
    // Two variants, one under each blueprint
    await adminConn.query(
      `INSERT INTO \`${tbl('hierarchy_nodes')}\` (id, name, node_type, parent_id, owner_id) VALUES
       (?, 'V1', 'variant', ?, NULL),
       (?, 'V2', 'variant', ?, NULL)`,
      [V1_ID, BP1_ID, V2_ID, BP2_ID],
    );
    // Two fields, one under each blueprint
    await adminConn.query(
      `INSERT INTO \`${tbl('blueprint_fields')}\` (id, blueprint_id, field_key) VALUES
       (?, ?, 'k1'),
       (?, ?, 'k2')`,
      [F1_ID, BP1_ID, F2_ID, BP2_ID],
    );
    // Two override rows, one in each blueprint, with action='lock'
    await adminConn.query(
      `INSERT INTO \`${tbl('variant_overrides')}\` (id, variant_id, field_id, action, override_value) VALUES
       (?, ?, ?, 'lock', 'init'),
       (?, ?, ?, 'lock', 'init')`,
      [VO1_ID, V1_ID, F1_ID, VO2_ID, V2_ID, F2_ID],
    );
    await adminConn.end();
    adminConn = null;

    pool = mariadb.createPool({
      ...dbConfig,
      database: testDbName,
      connectionLimit: 4,
      connectTimeout: 5000,
    });

    dbReady = true;
  } catch (err) {
    skipReason = `setup failed: ${err.message}`;
    if (adminConn) { try { await adminConn.end(); } catch {} }
    if (testDbName) {
      try {
        const cleanup = await mariadb.createConnection(dbConfig);
        await cleanup.query(`DROP DATABASE IF EXISTS \`${testDbName}\``);
        await cleanup.end();
      } catch {}
      testDbName = null;
    }
    if (process.env.REQUIRE_INTEGRATION_DB === '1') throw err;
  }
});

after(async () => {
  if (pool) {
    try { await pool.end(); } catch {}
    pool = null;
  }
  if (testDbName && dbConfig) {
    try {
      const cleanup = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
      await cleanup.query(`DROP DATABASE IF EXISTS \`${testDbName}\``);
      await cleanup.end();
    } catch (err) {
      console.error(`[teardown] failed to drop ${testDbName}: ${err.message}`);
    }
  }
});

// ── Helpers — replicate the production UPDATE shape ──────────────────────────
//
// Mirrors schema.js:1655-1675 — UPDATE WHERE id = ? AND <guard.clause>.
// The test exercises the SQL itself, not the route, because P1's race
// closure is at the SQL level and proving it independent of HTTP makes
// the proof-of-concept legible.

async function attemptPut({ role, voId, oldVariantId, oldFieldId, body, userId, midRaceMutator }) {
  const conn = await pool.getConnection();
  try {
    // Resolve new pair (PATCH-style merge) — matches handler line 1592-1594
    const newVariantId = body.variant_id != null ? body.variant_id : oldVariantId;
    const newFieldId = body.field_id != null ? body.field_id : oldFieldId;
    // Mirror handler: setIncludes* tracks whether the body provided that
    // FK at all (regardless of whether the value differs from old).
    const setIncludesVariantId = body.variant_id !== undefined;
    const setIncludesFieldId = body.field_id !== undefined;

    // Brief delay before UPDATE exposes the race window — without this,
    // both transactions can complete fast enough that the race surface
    // is barely measurable. Mid-race mutator runs from the OUTSIDE during
    // this window.
    if (midRaceMutator) await midRaceMutator();
    await new Promise((resolve) => setTimeout(resolve, 50));

    const guard = buildVariantOverrideUpdateExistsClause({
      role,
      setIncludesVariantId,
      setIncludesFieldId,
      newVariantId,
      newFieldId,
      userId,
      t: (name) => `${TEST_PREFIX}${name}`,
      TABLES: TABLES_LOCAL,
    });

    // Build SET clause from body (only override_value here — keep simple)
    const setKeys = Object.keys(body).filter((k) => k !== 'variant_id' && k !== 'field_id');
    const setSql = setKeys.length
      ? setKeys.map((k) => `\`${k}\` = ?`).join(', ')
      : '`override_value` = `override_value`'; // no-op SET if nothing else changed
    const setParams = setKeys.map((k) => body[k]);

    // Fold FK changes into SET when body provided them
    const fkSets = [];
    const fkParams = [];
    if (setIncludesVariantId) {
      fkSets.push('`variant_id` = ?');
      fkParams.push(body.variant_id);
    }
    if (setIncludesFieldId) {
      fkSets.push('`field_id` = ?');
      fkParams.push(body.field_id);
    }
    const fullSet = [setSql, ...fkSets].filter(Boolean).join(', ');

    const sql = `UPDATE \`${tbl('variant_overrides')}\` AS vo SET ${fullSet} WHERE vo.id = ? AND ${guard.clause}`;
    const params = [...setParams, ...fkParams, voId, ...guard.params];
    const result = await conn.query(sql, params);

    if (result.affectedRows === 0) {
      const stillThere = await conn.query(
        `SELECT 1 FROM \`${tbl('variant_overrides')}\` WHERE id = ? LIMIT 1`,
        [voId],
      );
      if (stillThere.length === 0) return { ok: false, status: 404, reason: 'not_found' };
      return { ok: false, status: 409, reason: 'race_detected' };
    }
    return { ok: true, status: 200 };
  } catch (err) {
    return { ok: false, status: 500, reason: err.code || err.message };
  } finally {
    conn.release();
  }
}

// Reset row to known state between tests
async function resetFixture() {
  const conn = await pool.getConnection();
  try {
    // Reset blueprint owners
    await conn.query(
      `UPDATE \`${tbl('hierarchy_nodes')}\` SET owner_id = ? WHERE id = ?`,
      [EDITOR1_ID, BP1_ID],
    );
    await conn.query(
      `UPDATE \`${tbl('hierarchy_nodes')}\` SET owner_id = ? WHERE id = ?`,
      [EDITOR2_ID, BP2_ID],
    );
    // Reset variant parent_id and node_type
    await conn.query(
      `UPDATE \`${tbl('hierarchy_nodes')}\` SET parent_id = ?, node_type = 'variant' WHERE id = ?`,
      [BP1_ID, V1_ID],
    );
    await conn.query(
      `UPDATE \`${tbl('hierarchy_nodes')}\` SET parent_id = ?, node_type = 'variant' WHERE id = ?`,
      [BP2_ID, V2_ID],
    );
    // Reset override row contents
    await conn.query(
      `UPDATE \`${tbl('variant_overrides')}\` SET variant_id = ?, field_id = ?, override_value = 'init' WHERE id = ?`,
      [V1_ID, F1_ID, VO1_ID],
    );
    await conn.query(
      `UPDATE \`${tbl('variant_overrides')}\` SET variant_id = ?, field_id = ?, override_value = 'init' WHERE id = ?`,
      [V2_ID, F2_ID, VO2_ID],
    );
  } finally {
    conn.release();
  }
}

// ── Tests ────────────────────────────────────────────────────────────────────

describe('PUT /variant_overrides/:id — TOCTOU race-only safety net (v3.2.106 P1)', () => {
  test('(a) admin coherence-violation race — concurrent parent_id flip → 409 race_detected', async (t) => {
    if (!dbReady) { t.skip(skipReason); return; }
    await resetFixture();

    // Admin attempts cosmetic edit on VO1. Concurrent attacker mutates V1's
    // parent_id from BP1 → BP2 mid-flight. The pre-UPDATE coherence check
    // would have passed (V1.parent_id = F1.blueprint_id at SELECT time),
    // but the UPDATE-time EXISTS must reject because v.parent_id != f.blueprint_id
    // by then.
    const result = await attemptPut({
      role: 'admin',
      voId: VO1_ID,
      oldVariantId: V1_ID,
      oldFieldId: F1_ID,
      body: { override_value: 'admin-edit' },
      userId: ADMIN_ID,
      midRaceMutator: async () => {
        const conn = await pool.getConnection();
        try {
          await conn.query(
            `UPDATE \`${tbl('hierarchy_nodes')}\` SET parent_id = ? WHERE id = ?`,
            [BP2_ID, V1_ID],
          );
        } finally {
          conn.release();
        }
      },
    });

    assert.equal(result.ok, false, `expected race rejection, got ${JSON.stringify(result)}`);
    assert.equal(result.status, 409);
    assert.equal(result.reason, 'race_detected');

    // Confirm the row was NOT mutated despite the race losing
    const conn = await pool.getConnection();
    try {
      const rows = await conn.query(
        `SELECT override_value FROM \`${tbl('variant_overrides')}\` WHERE id = ?`,
        [VO1_ID],
      );
      assert.equal(rows[0].override_value, 'init', 'row must not have been mutated when EXISTS rejected');
    } finally {
      conn.release();
    }
  });

  test('(b) editor OLD-ownership race — concurrent owner_id transfer → 409 race_detected', async (t) => {
    if (!dbReady) { t.skip(skipReason); return; }
    await resetFixture();

    // Editor1 (owns BP1) attempts cosmetic edit on VO1. Concurrent attacker
    // transfers BP1 owner from E1 → E2 mid-flight. Pre-UPDATE check passed
    // because the SELECT saw E1 still owning BP1; UPDATE-time EXISTS must
    // reject because bp.owner_id != E1 at the moment of the UPDATE.
    //
    // Note: editor + fkChanged=false collapses to single EXISTS that uses
    // the OLD pair via newVariantId/newFieldId fallback to old.* (same row).
    const result = await attemptPut({
      role: 'editor',
      voId: VO1_ID,
      oldVariantId: V1_ID,
      oldFieldId: F1_ID,
      body: { override_value: 'editor-edit' },
      userId: EDITOR1_ID,
      midRaceMutator: async () => {
        const conn = await pool.getConnection();
        try {
          await conn.query(
            `UPDATE \`${tbl('hierarchy_nodes')}\` SET owner_id = ? WHERE id = ?`,
            [EDITOR2_ID, BP1_ID],
          );
        } finally {
          conn.release();
        }
      },
    });

    assert.equal(result.ok, false, `expected race rejection, got ${JSON.stringify(result)}`);
    assert.equal(result.status, 409);
    assert.equal(result.reason, 'race_detected');
  });

  test('(c) editor NEW-pair race on fkChanged — concurrent node_type flip → 409 race_detected', async (t) => {
    if (!dbReady) { t.skip(skipReason); return; }
    await resetFixture();

    // Editor1 owns both BP1 and BP2 (give them BP2 too for this test)
    const setupConn = await pool.getConnection();
    try {
      await setupConn.query(
        `UPDATE \`${tbl('hierarchy_nodes')}\` SET owner_id = ? WHERE id = ?`,
        [EDITOR1_ID, BP2_ID],
      );
    } finally {
      setupConn.release();
    }

    // Editor1 attempts to swap VO1 from (V1, F1) under BP1 to (V2, F2) under BP2.
    // Concurrent attacker flips V2.node_type from 'variant' → 'release' mid-flight.
    // Pre-UPDATE check passed because V2 was 'variant' at SELECT time;
    // UPDATE-time EXISTS must reject the NEW pair because v.node_type != 'variant'.
    const result = await attemptPut({
      role: 'editor',
      voId: VO1_ID,
      oldVariantId: V1_ID,
      oldFieldId: F1_ID,
      body: { variant_id: V2_ID, field_id: F2_ID, override_value: 'swap' },
      userId: EDITOR1_ID,
      midRaceMutator: async () => {
        const conn = await pool.getConnection();
        try {
          await conn.query(
            `UPDATE \`${tbl('hierarchy_nodes')}\` SET node_type = 'release' WHERE id = ?`,
            [V2_ID],
          );
        } finally {
          conn.release();
        }
      },
    });

    assert.equal(result.ok, false, `expected race rejection, got ${JSON.stringify(result)}`);
    assert.equal(result.status, 409);
    assert.equal(result.reason, 'race_detected');
  });

  test('(d) admin no-FK-change happy path — no race, EXISTS guard passes → 200', async (t) => {
    if (!dbReady) { t.skip(skipReason); return; }
    await resetFixture();

    const result = await attemptPut({
      role: 'admin',
      voId: VO1_ID,
      oldVariantId: V1_ID,
      oldFieldId: F1_ID,
      body: { override_value: 'admin-clean-edit' },
      userId: ADMIN_ID,
      // no midRaceMutator
    });

    assert.equal(result.ok, true, `expected 200, got ${JSON.stringify(result)}`);
    assert.equal(result.status, 200);

    const conn = await pool.getConnection();
    try {
      const rows = await conn.query(
        `SELECT override_value FROM \`${tbl('variant_overrides')}\` WHERE id = ?`,
        [VO1_ID],
      );
      assert.equal(rows[0].override_value, 'admin-clean-edit', 'row must reflect admin edit');
    } finally {
      conn.release();
    }
  });

  test('(e) editor happy path on owned blueprint — no race, EXISTS passes → 200', async (t) => {
    if (!dbReady) { t.skip(skipReason); return; }
    await resetFixture();

    const result = await attemptPut({
      role: 'editor',
      voId: VO1_ID,
      oldVariantId: V1_ID,
      oldFieldId: F1_ID,
      body: { override_value: 'editor-clean-edit' },
      userId: EDITOR1_ID,
      // no midRaceMutator
    });

    assert.equal(result.ok, true, `expected 200, got ${JSON.stringify(result)}`);
    assert.equal(result.status, 200);
  });

  test('(f) editor cosmetic PUT — concurrent FK mutation on the row itself → 409 race_detected', async (t) => {
    if (!dbReady) { t.skip(skipReason); return; }
    await resetFixture();

    // v3.2.109+ uq_variant_override_triple: pre-delete vo-2 so the
    // mutator below can move vo-1 → (V2, F2) without a UNIQUE collision
    // shadowing the COALESCE-guard signal we are actually asserting.
    {
      const cleanupConn = await pool.getConnection();
      try {
        await cleanupConn.query(
          `DELETE FROM \`${tbl('variant_overrides')}\` WHERE id = ?`,
          [VO2_ID],
        );
      } finally {
        cleanupConn.release();
      }
    }

    // The row Codex flagged in P1 review: editor1 sends a no-FK cosmetic
    // PUT (override_value only). Pre-UPDATE SELECT reads vo-1 with FKs
    // (V1, F1) under BP1 (editor1 owns). Concurrent attacker mutates
    // vo-1's variant_id from V1 → V2 (V2 lives under BP2, editor1 does
    // NOT own). Without the COALESCE-vo.column guard, the EXISTS would
    // validate the bound (V1, F1) pair (still valid) and the cosmetic
    // edit would slip through to a row editor1 no longer has authority
    // over. With the guard, COALESCE(NULL, vo.variant_id) sees V2 at
    // UPDATE time, lookup hits BP2 owned by editor2, owner clause fails
    // → affectedRows=0 → 409 race_detected.
    const result = await attemptPut({
      role: 'editor',
      voId: VO1_ID,
      oldVariantId: V1_ID,
      oldFieldId: F1_ID,
      body: { override_value: 'editor-cosmetic' },
      userId: EDITOR1_ID,
      midRaceMutator: async () => {
        const conn = await pool.getConnection();
        try {
          await conn.query(
            `UPDATE \`${tbl('variant_overrides')}\` SET variant_id = ?, field_id = ? WHERE id = ?`,
            [V2_ID, F2_ID, VO1_ID],
          );
        } finally {
          conn.release();
        }
      },
    });

    assert.equal(result.ok, false, `expected race rejection, got ${JSON.stringify(result)}`);
    assert.equal(result.status, 409);
    assert.equal(result.reason, 'race_detected');

    // Confirm the row's override_value was NOT changed by editor1's stale write
    const conn = await pool.getConnection();
    try {
      const rows = await conn.query(
        `SELECT override_value FROM \`${tbl('variant_overrides')}\` WHERE id = ?`,
        [VO1_ID],
      );
      assert.equal(rows[0].override_value, 'init', 'row must not have been mutated when EXISTS rejected');
    } finally {
      conn.release();
    }
  });
});
