/**
 * orphan-blank-link-real-db.test.js
 *
 * A blueprint whose `linked_blueprint_id` is stored EMPTY, put to a real
 * MariaDB through the real orphan endpoints, asserted on the STORED ROWS.
 *
 * WHAT THIS PINS, AND WHY A MOCK COULD NOT. JavaScript reads a stored `''` as
 * "no link" — that reading is what makes a row bricked by an empty link
 * repairable. Every SQL reader of the same column resolved it with
 * `COALESCE(hn.linked_blueprint_id, ut.blueprint_id)`, and COALESCE replaces
 * only NULL. Measured before the fix, on this schema: the effective blueprint
 * resolved to `''`, which is the id of no row, so the scanner reported BOTH of a
 * template's valid answers as residuals and the delete endpoint — asking the
 * identical expression in its re-check — agreed and removed them. Stored payload
 * `{"finish":"Matte","size":"L"}` became `{}`.
 *
 * Whether `COALESCE` looks past an empty string is the engine's answer, not
 * ours, and a stubbed connection returns `{affectedRows: 1}` to any statement at
 * all. So every assertion here is about what a real database still holds after
 * the route ran, and each of the four query sites that resolve the link gets its
 * own case: the scanner, the editor-ownership re-check, the type-mismatch
 * re-check, and the orphan delete re-check.
 *
 * The controls are the other half. A genuine residual must still be found and
 * still be removed, and a genuine link must still resolve to its source
 * blueprint — otherwise "nothing was deleted" would pass this file by doing
 * nothing at all.
 *
 * Auto-detects a reachable MariaDB and skips cleanly when there is none, in the
 * shape the sibling integration tests use.
 */
const { test, describe, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const net = require('node:net');
const http = require('node:http');
const express = require('express');
const mariadb = require('mariadb');

const TEST_PREFIX = 'obl_';
const tbl = (name) => `${TEST_PREFIX}${name}`;

let pool = null;
const lease = () => pool.getConnection();

const dbKey = require.resolve('../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey,
  filename: dbKey,
  loaded: true,
  exports: {
    pool: { ro: { getConnection: lease }, rw: { getConnection: lease } },
    t: tbl,
    getDynamicPool: async () => ({ ro: { getConnection: lease }, rw: { getConnection: lease } }),
  },
};

const { buildEngineTableDDLs } = require('../../src/table-ddls');
const { TABLES } = require('../../src/shared/constants');
const schemaRouter = require('../../src/edge/routes/app/schema');

// ── Config auto-detection (same shape as the sibling integration tests) ──────

function parseEnvFile(filePath) {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    const out = {};
    for (const line of content.split('\n')) {
      const m = line.match(/^\s*([A-Z_][A-Z0-9_]*)\s*=\s*(.*)\s*$/);
      if (!m) continue;
      let value = m[2];
      if ((value.startsWith('"') && value.endsWith('"'))
        || (value.startsWith("'") && value.endsWith("'"))) {
        value = value.slice(1, -1);
      }
      out[m[1]] = value;
    }
    return out;
  } catch {
    return null;
  }
}

function probePort(host, port, timeoutMs) {
  return new Promise((resolve) => {
    const socket = new net.Socket();
    let done = false;
    const finish = (ok) => { if (done) return; done = true; socket.destroy(); resolve(ok); };
    socket.setTimeout(timeoutMs);
    socket.once('connect', () => finish(true));
    socket.once('timeout', () => finish(false));
    socket.once('error', () => finish(false));
    socket.connect(port, host);
  });
}

async function resolveMariaDbConfig() {
  if (process.env.DB_TEST_HOST && process.env.DB_TEST_ROOT_PASSWORD) {
    return {
      host: process.env.DB_TEST_HOST,
      port: parseInt(process.env.DB_TEST_PORT || '3306', 10),
      user: 'root',
      password: process.env.DB_TEST_ROOT_PASSWORD,
    };
  }
  const env = parseEnvFile(path.resolve(__dirname, '../../../.devcontainer/.env'));
  if (!env || !env.DB_ROOT_PASSWORD) return null;
  const port = parseInt(env.DB_PORT || '3306', 10);
  for (const host of ['127.0.0.1', 'mariadb', 'localhost']) {
    if (await probePort(host, port, 2000)) {
      return { host, port, user: 'root', password: env.DB_ROOT_PASSWORD };
    }
  }
  return null;
}

/** The three tables this fixture needs, taken from the shipped DDL list. */
function ddlFor(...tables) {
  const wanted = new Set(tables.map((n) => tbl(n)));
  return buildEngineTableDDLs(tbl).filter((sql) => {
    const m = sql.match(/CREATE TABLE IF NOT EXISTS `([^`]+)`/);
    return m && wanted.has(m[1]);
  });
}

// ── Fixture ──────────────────────────────────────────────────────────────────

const EDITOR = 'e0000000-0000-0000-0000-0000000000ed';
const OTHER_EDITOR = 'e0000000-0000-0000-0000-0000000000ff';

const BP_BLANK = 'b1000000-0000-0000-0000-000000000001'; // linked_blueprint_id = ''
const BP_SHARED = 'b1000000-0000-0000-0000-000000000002'; // linked_blueprint_id = NULL
const BP_SOURCE = 'b1000000-0000-0000-0000-000000000003'; // a real link target
const BP_LINKED = 'b1000000-0000-0000-0000-000000000004'; // linked_blueprint_id = BP_SOURCE

const T_BLANK = 'c1000000-0000-0000-0000-000000000001';
const T_BLANK_MISMATCH = 'c1000000-0000-0000-0000-000000000002';
const T_LINKED = 'c1000000-0000-0000-0000-000000000003';
const T_SHARED = 'c1000000-0000-0000-0000-000000000004';

let dbReady = false;
let skipReason = null;
let testDbName = null;
let dbConfig = null;
let server = null;
let port = null;
let identity = { id: 'admin-1', role: 'admin' };

before(async () => {
  dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) {
    skipReason = 'no MariaDB reachable via .devcontainer/.env or env vars';
    if (process.env.REQUIRE_INTEGRATION_DB === '1') {
      throw new Error(`REQUIRE_INTEGRATION_DB=1 set but ${skipReason}.`);
    }
    return;
  }
  testDbName = `orph_blank_link_${process.pid}_${Date.now()}`;
  let admin = null;
  try {
    admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`CREATE DATABASE \`${testDbName}\``);
    await admin.query(`USE \`${testDbName}\``);
    const statements = ddlFor(
      TABLES.HIERARCHY_NODES, TABLES.USER_TEMPLATES, TABLES.BLUEPRINT_FIELDS,
    );
    assert.equal(statements.length, 3, 'the DDL list no longer defines all three tables');
    for (const sql of statements) await admin.query(sql);

    await admin.query(
      `INSERT INTO \`${tbl('hierarchy_nodes')}\`
         (id, name, node_type, linked_blueprint_id, owner_id) VALUES
       (?, 'Blank link', 'blueprint', '',   ?),
       (?, 'Shared',     'blueprint', NULL, NULL),
       (?, 'Source',     'blueprint', NULL, NULL),
       (?, 'Linked',     'blueprint', ?,    NULL)`,
      [BP_BLANK, EDITOR, BP_SHARED, BP_SOURCE, BP_LINKED, BP_SOURCE],
    );
    await admin.query(
      `INSERT INTO \`${tbl('blueprint_fields')}\` (id, blueprint_id, field_key, field_type) VALUES
       (UUID(), ?, 'finish', 'text'), (UUID(), ?, 'tags', 'checkbox'),
       (UUID(), ?, 'finish', 'text'),
       (UUID(), ?, 'shared_key', 'text')`,
      [BP_BLANK, BP_BLANK, BP_SHARED, BP_SOURCE],
    );
    await admin.end();
    admin = null;
    pool = mariadb.createPool({
      ...dbConfig, database: testDbName, connectionLimit: 4, connectTimeout: 5000,
    });

    const app = express();
    app.use(express.json());
    app.use((req, _res, next) => { req.user = { ...identity }; next(); });
    app.use('/edge/app/schema', schemaRouter);
    server = app.listen(0, '127.0.0.1');
    await new Promise((resolve) => server.once('listening', resolve));
    port = server.address().port;
    dbReady = true;
  } catch (err) {
    skipReason = `setup failed: ${err.message}`;
    if (admin) { try { await admin.end(); } catch { /* best effort */ } }
    if (process.env.REQUIRE_INTEGRATION_DB === '1') throw err;
  }
});

after(async () => {
  if (server) await new Promise((resolve) => server.close(resolve));
  if (pool) { try { await pool.end(); } catch { /* best effort */ } }
  if (testDbName && dbConfig) {
    try {
      const cleanup = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
      await cleanup.query(`DROP DATABASE IF EXISTS \`${testDbName}\``);
      await cleanup.end();
    } catch (err) {
      console.error(`[teardown] failed to drop ${testDbName}: ${err.message}`);
    }
  }
});

/** Every template row restored, so one case's delete cannot decide the next. */
beforeEach(async () => {
  if (!dbReady) return;
  identity = { id: 'admin-1', role: 'admin' };
  const conn = await pool.getConnection();
  try {
    await conn.query(`DELETE FROM \`${tbl('user_templates')}\``);
    await conn.query(
      `INSERT INTO \`${tbl('user_templates')}\` (id, name, blueprint_id, payload, owner_id) VALUES
       (?, 'Blank-link tpl',  ?, ?, ?),
       (?, 'Blank mismatch',  ?, ?, ?),
       (?, 'Linked tpl',      ?, ?, NULL),
       (?, 'Shared tpl',      ?, ?, NULL)`,
      [
        T_BLANK, BP_BLANK,
        JSON.stringify({ finish: 'Matte', tags: '["a","b"]', gone: 'residual' }), EDITOR,
        T_BLANK_MISMATCH, BP_BLANK,
        JSON.stringify({ tags: 'not-an-array' }), EDITOR,
        T_LINKED, BP_LINKED, JSON.stringify({ shared_key: 'kept' }),
        T_SHARED, BP_SHARED, JSON.stringify({ finish: 'Gloss' }),
      ],
    );
  } finally {
    conn.release();
  }
});

// ── Driving the real routes ──────────────────────────────────────────────────

function call(method, urlPath, body) {
  return new Promise((resolve, reject) => {
    const payload = body ? JSON.stringify(body) : null;
    const req = http.request({
      method,
      host: '127.0.0.1',
      port,
      path: urlPath,
      headers: payload
        ? { 'content-type': 'application/json', 'content-length': Buffer.byteLength(payload) }
        : {},
    }, (res) => {
      let buf = '';
      res.on('data', (d) => { buf += d; });
      res.on('end', () => {
        let parsed = null;
        try { parsed = buf ? JSON.parse(buf) : null; } catch { parsed = null; }
        resolve({ status: res.statusCode, body: parsed });
      });
    });
    req.on('error', reject);
    if (payload) req.write(payload);
    req.end();
  });
}

async function scan() {
  const res = await call('POST', '/edge/app/schema/field-data-orphans', {});
  assert.equal(res.status, 200, `scan failed: ${JSON.stringify(res.body)}`);
  return (res.body?.data ?? res.body).orphans;
}

function clearKey(templateId, key, kind) {
  const suffix = kind === 'type_mismatch' ? '?kind=type_mismatch' : '';
  return call('DELETE', `/edge/app/schema/field-data-orphans/${templateId}/${encodeURIComponent(key)}${suffix}`);
}

/** What the database HOLDS for a template, not what a route said about it. */
async function storedPayload(templateId) {
  const conn = await pool.getConnection();
  try {
    const rows = await conn.query(
      `SELECT payload FROM \`${tbl('user_templates')}\` WHERE id = ?`, [templateId],
    );
    if (!rows.length) return null;
    const p = rows[0].payload;
    return typeof p === 'string' ? JSON.parse(p) : p;
  } finally {
    conn.release();
  }
}

const keysOn = (orphans, templateId) => orphans
  .filter((o) => o.template_id === templateId)
  .map((o) => `${o.kind}:${o.orphan_key}`)
  .sort();

// ── Cases ────────────────────────────────────────────────────────────────────

describe('a stored blank link, put to a real database', () => {
  test('PREMISE: the column really holds an empty string, and IS NULL answers 0 for it', async (t) => {
    if (!dbReady) { t.skip(skipReason); return; }
    const conn = await pool.getConnection();
    try {
      // Everything below is only interesting if this row is genuinely what the
      // defect report claims. A blank that the engine had quietly turned into
      // NULL would make every other case here pass for the wrong reason.
      const rows = await conn.query(
        `SELECT linked_blueprint_id AS link,
                (linked_blueprint_id IS NULL) AS is_null,
                CHAR_LENGTH(linked_blueprint_id) AS len,
                (NULLIF(linked_blueprint_id, '') IS NULL) AS folds_to_absent
           FROM \`${tbl('hierarchy_nodes')}\` WHERE id = ?`,
        [BP_BLANK],
      );
      assert.equal(rows[0].link, '');
      assert.equal(Number(rows[0].is_null), 0, 'the engine stored NULL, not a blank');
      assert.equal(Number(rows[0].len), 0);
      assert.equal(
        Number(rows[0].folds_to_absent), 1,
        'NULLIF does not fold this value, so the SQL reader cannot agree with linkTargetOf',
      );
    } finally {
      conn.release();
    }
  });

  test('PREMISE: a spaces-only link reaches both readers as the same blank', async (t) => {
    if (!dbReady) { t.skip(skipReason); return; }
    // The shared expression uses NULLIF rather than an explicit IS NULL OR = ''
    // because the column is CHAR(36): the engine strips trailing spaces on
    // retrieval and compares under a PAD SPACE collation, so a spaces-only row
    // is `''` to JavaScript AND folds in SQL. That is the engine's behaviour,
    // asserted here rather than assumed in a comment.
    const conn = await pool.getConnection();
    const probe = 'b1000000-0000-0000-0000-0000000000aa';
    try {
      await conn.query(
        `INSERT INTO \`${tbl('hierarchy_nodes')}\` (id, name, node_type, linked_blueprint_id)
         VALUES (?, 'Spaces', 'blueprint', '   ')`, [probe],
      );
      const rows = await conn.query(
        `SELECT linked_blueprint_id AS link,
                (NULLIF(linked_blueprint_id, '') IS NULL) AS folds_to_absent
           FROM \`${tbl('hierarchy_nodes')}\` WHERE id = ?`, [probe],
      );
      assert.equal(rows[0].link, '', 'CHAR(36) no longer strips the padding');
      assert.equal(Number(rows[0].folds_to_absent), 1);
    } finally {
      await conn.query(`DELETE FROM \`${tbl('hierarchy_nodes')}\` WHERE id = ?`, [probe]);
      conn.release();
    }
  });

  test('SCANNER: a blank link falls back to the template\'s own blueprint', async (t) => {
    if (!dbReady) { t.skip(skipReason); return; }
    const orphans = await scan();
    assert.deepEqual(
      keysOn(orphans, T_BLANK), ['orphan:gone'],
      'the valid answers under a blank-link blueprint were reported as residuals; '
      + 'the scanner resolved the effective blueprint to the empty string',
    );
    assert.deepEqual(keysOn(orphans, T_BLANK_MISMATCH), ['type_mismatch:tags']);
  });

  test('SCANNER control: a genuine link still resolves to its source blueprint', async (t) => {
    if (!dbReady) { t.skip(skipReason); return; }
    const orphans = await scan();
    assert.deepEqual(
      keysOn(orphans, T_LINKED), [],
      'a key belonging to the LINKED blueprint was reported as a residual, so the fold '
      + 'broke real link resolution',
    );
    assert.deepEqual(keysOn(orphans, T_SHARED), []);
  });

  test('DELETE re-check: a valid answer under a blank link survives the delete', async (t) => {
    if (!dbReady) { t.skip(skipReason); return; }
    const res = await clearKey(T_BLANK, 'finish');
    // THE STORED ROW IS ASSERTED FIRST, DELIBERATELY. The harm this case exists
    // for is answers leaving the database, and a status code is the endpoint's
    // opinion about that rather than the fact. Asserted the other way round, a
    // regression reports itself as "expected 409, got 200" and says nothing
    // about the two answers that are now gone.
    assert.deepEqual(
      await storedPayload(T_BLANK),
      { finish: 'Matte', tags: '["a","b"]', gone: 'residual' },
      'a valid answer was deleted from the stored payload',
    );
    assert.equal(res.status, 409, 'the endpoint agreed to clear a valid answer');
    assert.equal(res.body?.error?.code ?? res.body?.code, 'STALE_ORPHAN');
  });

  test('DELETE re-check control: a genuine residual is still removed, and only it', async (t) => {
    if (!dbReady) { t.skip(skipReason); return; }
    const res = await clearKey(T_BLANK, 'gone');
    assert.equal(res.status, 200, JSON.stringify(res.body));
    assert.deepEqual(
      await storedPayload(T_BLANK),
      { finish: 'Matte', tags: '["a","b"]' },
      'the residual went but so did something else, or nothing went at all',
    );
  });

  test('DELETE re-check control: a linked blueprint\'s key is still refused', async (t) => {
    if (!dbReady) { t.skip(skipReason); return; }
    const res = await clearKey(T_LINKED, 'shared_key');
    assert.equal(res.status, 409);
    assert.deepEqual(await storedPayload(T_LINKED), { shared_key: 'kept' });
  });

  test('MISMATCH re-check: a valid value under a blank link is refused', async (t) => {
    if (!dbReady) { t.skip(skipReason); return; }
    // Before the fix the join resolved no field row at all, so this path
    // answered 409 for every key — right outcome, wrong reason. The control
    // below is what tells the two apart.
    const res = await clearKey(T_BLANK, 'tags', 'type_mismatch');
    assert.equal(res.status, 409);
    assert.deepEqual(
      await storedPayload(T_BLANK),
      { finish: 'Matte', tags: '["a","b"]', gone: 'residual' },
    );
  });

  test('MISMATCH re-check control: a genuine mismatch under a blank link is cleared', async (t) => {
    if (!dbReady) { t.skip(skipReason); return; }
    const res = await clearKey(T_BLANK_MISMATCH, 'tags', 'type_mismatch');
    assert.deepEqual(
      await storedPayload(T_BLANK_MISMATCH), {},
      'the residual is still in the stored payload: the endpoint could not reach the '
      + 'field declaration through the blank link, so the repair surface is unreachable '
      + 'for exactly the rows that need it',
    );
    assert.equal(res.status, 200, JSON.stringify(res.body));
  });

  test('OWNERSHIP: the owning editor can repair a row under a blank-link blueprint', async (t) => {
    if (!dbReady) { t.skip(skipReason); return; }
    // The ownership re-check joins the EFFECTIVE blueprint and fails closed when
    // that row is missing. Resolved as `''` it was always missing, so the owner
    // of the bricked blueprint was 404'd off their own data — the same
    // unrepairable state the blank link created everywhere else.
    identity = { id: EDITOR, role: 'editor' };
    const seen = await scan();
    assert.deepEqual(keysOn(seen, T_BLANK), ['orphan:gone'], 'the owner cannot see it');

    const res = await clearKey(T_BLANK, 'gone');
    assert.equal(res.status, 200, JSON.stringify(res.body));
    assert.deepEqual(await storedPayload(T_BLANK), { finish: 'Matte', tags: '["a","b"]' });
  });

  test('OWNERSHIP control: a non-owning editor is still refused, and nothing moves', async (t) => {
    if (!dbReady) { t.skip(skipReason); return; }
    identity = { id: OTHER_EDITOR, role: 'editor' };
    const seen = await scan();
    assert.deepEqual(keysOn(seen, T_BLANK), [], 'a non-owner was shown another owner\'s row');

    const res = await clearKey(T_BLANK, 'gone');
    assert.equal(res.status, 404);
    assert.deepEqual(
      await storedPayload(T_BLANK),
      { finish: 'Matte', tags: '["a","b"]', gone: 'residual' },
    );
  });
});
