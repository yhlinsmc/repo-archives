'use strict';

/**
 * flow-run-step-results-precision-real-db.test.js — the digits the driver
 * rounded before any of our code ran.
 *
 * step_results is a JSON-typed column (table-ddls.js). The mariadb driver
 * (autoJsonMap, on by default with extended metadata against MariaDB >= 10.5.2)
 * parses a JSON column into a JS object AT conn.query, rounding any 16+-digit
 * integer through its own JSON.parse before this process ever sees the bytes.
 * A stubbed driver returns whatever the fixture said — a string — so the route
 * tests are structurally blind to this hop. The premise under test is what the
 * REAL driver + REAL server do with a stored 17-digit integer, and whether the
 * detail statement's CAST AS CHAR defeats the rounding.
 *
 * Skips with a stated reason when no database is reachable, and fails instead of
 * skipping when REQUIRE_INTEGRATION_DB=1.
 */
const { test, describe, before, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const net = require('node:net');
const http = require('node:http');
const express = require('express');
const mariadb = require('mariadb');

const TEST_PREFIX = 'frr_';
const tbl = (name) => `${TEST_PREFIX}${name}`;

let pool = null;
const lease = () => pool.getConnection();

const dbKey = require.resolve('../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey,
  filename: dbKey,
  loaded: true,
  exports: {
    pool: { ro: { getConnection: lease }, rw: { getConnection: lease } },
    t: tbl,
    getDynamicPool: async () => ({ ro: { getConnection: lease }, rw: { getConnection: lease } }),
  },
};

const { buildEngineTableDDLs, buildInfraTableDDLs } = require('../../src/table-ddls');
const { TABLES } = require('../../src/shared/constants');
const { router } = require('../../src/edge/routes/app/flow-recipe-runs/aggregate');

// ── Config auto-detection (same shape as the sibling integration tests) ──────
function parseEnvFile(filePath) {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    const out = {};
    for (const line of content.split('\n')) {
      const m = line.match(/^\s*([A-Z_][A-Z0-9_]*)\s*=\s*(.*)\s*$/);
      if (!m) continue;
      let value = m[2];
      if ((value.startsWith('"') && value.endsWith('"'))
        || (value.startsWith("'") && value.endsWith("'"))) value = value.slice(1, -1);
      out[m[1]] = value;
    }
    return out;
  } catch { return null; }
}

function probePort(host, port, timeoutMs = 2000) {
  return new Promise((resolve) => {
    const socket = new net.Socket();
    let done = false;
    const finish = (ok) => { if (done) return; done = true; socket.destroy(); resolve(ok); };
    socket.setTimeout(timeoutMs);
    socket.once('connect', () => finish(true));
    socket.once('timeout', () => finish(false));
    socket.once('error', () => finish(false));
    socket.connect(port, host);
  });
}

async function resolveMariaDbConfig() {
  if (process.env.DB_TEST_HOST && process.env.DB_TEST_ROOT_PASSWORD) {
    return {
      host: process.env.DB_TEST_HOST,
      port: parseInt(process.env.DB_TEST_PORT || '3306', 10),
      user: 'root', password: process.env.DB_TEST_ROOT_PASSWORD,
    };
  }
  const envPath = path.resolve(__dirname, '../../../.devcontainer/.env');
  const env = parseEnvFile(envPath);
  if (!env || !env.DB_ROOT_PASSWORD) return null;
  const port = parseInt(env.DB_PORT || '3306', 10);
  for (const host of ['127.0.0.1', 'mariadb', 'localhost']) {
    if (await probePort(host, port, 2000)) {
      return { host, port, user: 'root', password: env.DB_ROOT_PASSWORD };
    }
  }
  return null;
}

// ── Fixture ─────────────────────────────────────────────────────────────────
const ADMIN = { id: '22222222-2222-2222-2222-222222222222', role: 'admin' };
const RUN_BIG = 'aaaaaaaa-0000-0000-0000-0000000000b1';
const RUN_NULL = 'aaaaaaaa-0000-0000-0000-0000000000b2';
const DIGITS = '98765432109876543'; // 17 digits, above Number.MAX_SAFE_INTEGER
const ROUNDED = '98765432109876540'; // what JSON.parse yields for the above
const STEP_RESULTS_TEXT = `[{"step":1,"external_ref":${DIGITS}}]`;

let dbReady = false;
let skipReason = null;
let testDbName = null;
let server = null;
let baseUrl = null;

before(async () => {
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) {
    skipReason = 'no MariaDB reachable via .devcontainer/.env or env vars';
    if (process.env.REQUIRE_INTEGRATION_DB === '1') throw new Error(`REQUIRE_INTEGRATION_DB=1 set but ${skipReason}.`);
    return;
  }
  testDbName = `frr_stepres_test_${process.pid}_${Date.now()}`;
  let admin = null;
  try {
    admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`CREATE DATABASE \`${testDbName}\``);
    await admin.query(`USE \`${testDbName}\``);
    // All infra + engine tables: the detail read LEFT JOINs flow_recipes and the
    // enrichment reads users, so a single table is not enough.
    for (const sql of [...buildInfraTableDDLs(tbl), ...buildEngineTableDDLs(tbl)]) await admin.query(sql);
    await admin.end();
    admin = null;

    pool = mariadb.createPool({ ...dbConfig, database: testDbName, connectionLimit: 4, connectTimeout: 5000 });

    const runs = tbl(TABLES.FLOW_RECIPE_RUNS);
    await pool.query(
      `INSERT INTO \`${runs}\` (id, recipe_id, actor_id, mode, status, step_results) VALUES (?, ?, ?, 'create', 'success', ?)`,
      [RUN_BIG, '33333333-3333-3333-3333-333333333333', ADMIN.id, STEP_RESULTS_TEXT],
    );
    await pool.query(
      `INSERT INTO \`${runs}\` (id, recipe_id, actor_id, mode, status, step_results) VALUES (?, ?, ?, 'create', 'failed', NULL)`,
      [RUN_NULL, '33333333-3333-3333-3333-333333333333', ADMIN.id],
    );

    const app = express();
    app.use(express.json());
    app.use((req, _res, next) => { req.user = ADMIN; next(); });
    app.use('/', router);
    server = http.createServer(app);
    await new Promise((r) => server.listen(0, r));
    baseUrl = `http://127.0.0.1:${server.address().port}`;
    dbReady = true;
  } catch (err) {
    skipReason = `setup failed: ${err.message}`;
    if (admin) { try { await admin.end(); } catch { /* best effort */ } }
    if (process.env.REQUIRE_INTEGRATION_DB === '1') throw err;
  }
});

after(async () => {
  if (server) { try { server.close(); } catch { /* best effort */ } }
  if (pool) { try { await pool.end(); } catch { /* best effort */ } }
  if (!testDbName) return;
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) return;
  try {
    const admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`DROP DATABASE IF EXISTS \`${testDbName}\``);
    await admin.end();
  } catch { /* best effort */ }
});

const guard = (t) => { if (!dbReady) { t.skip(skipReason || 'database not ready'); return true; } return false; };

async function getRun(id) {
  const res = await fetch(`${baseUrl}/runs/${id}`);
  const text = await res.text();
  let body = null; try { body = JSON.parse(text); } catch { body = { raw: text }; }
  return { status: res.status, body };
}

describe('flow run step_results precision on a real database', () => {
  test('the instrument works: a raw JSON-column read DOES round the 17-digit int', async (t) => {
    if (guard(t)) return;
    // THE PREMISE, MEASURED. Proves the driver rounds a JSON column and that the
    // DB actually stored the big integer, so the green assertion below is not
    // vacuous — the round trip really did have a chance to lose the digits.
    const raw = await pool.query(
      `SELECT step_results FROM \`${tbl(TABLES.FLOW_RECIPE_RUNS)}\` WHERE id = ?`, [RUN_BIG],
    );
    const v = raw[0].step_results;
    assert.equal(typeof v, 'object', 'the driver did not autoJsonMap this JSON column — the premise moved');
    assert.ok(JSON.stringify(v).includes(ROUNDED), `expected the rounded ${ROUNDED}, got ${JSON.stringify(v)}`);
    assert.ok(!JSON.stringify(v).includes(DIGITS), 'the raw read somehow preserved the digits — premise moved');
  });

  test('the detail read ships step_results as a byte-exact string, digits intact', async (t) => {
    if (guard(t)) return;
    const { status, body } = await getRun(RUN_BIG);
    assert.equal(status, 200, `read failed: ${JSON.stringify(body)}`);
    assert.equal(typeof body.data.step_results, 'string', 'step_results did not arrive as raw text');
    assert.ok(body.data.step_results.includes(DIGITS),
      `the 17-digit integer was rounded: ${body.data.step_results}`);
    assert.ok(!body.data.step_results.includes(ROUNDED), 'the rounded neighbour appeared');
    assert.equal(body.data.step_results, STEP_RESULTS_TEXT, 'the bytes are not identical to what was stored');
  });

  test('a NULL step_results arrives as an empty string (Y-pattern)', async (t) => {
    if (guard(t)) return;
    const { body } = await getRun(RUN_NULL);
    assert.equal(body.data.step_results, '');
  });
});
