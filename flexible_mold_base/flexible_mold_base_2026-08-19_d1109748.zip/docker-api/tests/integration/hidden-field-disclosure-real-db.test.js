'use strict';

/**
 * hidden-field-disclosure-real-db.test.js — the gate, and the statement behind
 * it, against a real engine.
 *
 * TWO THINGS A STUBBED DRIVER CANNOT ESTABLISH, and both are the point of this
 * unit:
 *
 *  - The ownership half of the gate compares `owner_id` through the COLUMN's
 *    own collation (`isOwnerOrAdmin` → `sameStoredValue`). A fixture answering
 *    "the owner is X" proves the branch is wired, never that the engine agrees
 *    about who X is. Here the editor's id is stored in another case, which is a
 *    row shape that exists in this system, and the engine is what decides.
 *  - The catalogue statement reads the visibility rule's subject with
 *    `JSON_UNQUOTE(JSON_EXTRACT(...))`. A stub returns whatever the fixture
 *    named the column; only the engine can say the path resolves.
 *
 * Measured once per role: administrator, the editor who owns the blueprint, an
 * editor who owns another, and an ordinary user.
 *
 * Skips with a stated reason when no database is reachable, and fails instead
 * of skipping when REQUIRE_INTEGRATION_DB=1.
 */
const { test, describe, before, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const net = require('node:net');
const http = require('node:http');
const express = require('express');
const mariadb = require('mariadb');

const TEST_PREFIX = 'hfd_';
const tbl = (name) => `${TEST_PREFIX}${name}`;

let pool = null;
const lease = () => pool.getConnection();

const dbKey = require.resolve('../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey,
  filename: dbKey,
  loaded: true,
  exports: {
    pool: { ro: { getConnection: lease }, rw: { getConnection: lease } },
    t: tbl,
    getDynamicPool: async () => ({ ro: { getConnection: lease }, rw: { getConnection: lease } }),
  },
};

const { buildEngineTableDDLs } = require('../../src/table-ddls');
const { TABLES } = require('../../src/shared/constants');
const schemaRouter = require('../../src/edge/routes/app/schema');
const { fixtureUserId } = require('../helpers/fixture-ids');

function parseEnvFile(filePath) {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    const out = {};
    for (const line of content.split('\n')) {
      const m = line.match(/^\s*([A-Z_][A-Z0-9_]*)\s*=\s*(.*)\s*$/);
      if (!m) continue;
      let value = m[2];
      if ((value.startsWith('"') && value.endsWith('"'))
        || (value.startsWith("'") && value.endsWith("'"))) {
        value = value.slice(1, -1);
      }
      out[m[1]] = value;
    }
    return out;
  } catch {
    return null;
  }
}

function probePort(host, port, timeoutMs = 2000) {
  return new Promise((resolve) => {
    const socket = new net.Socket();
    let done = false;
    const finish = (ok) => { if (done) return; done = true; socket.destroy(); resolve(ok); };
    socket.setTimeout(timeoutMs);
    socket.once('connect', () => finish(true));
    socket.once('timeout', () => finish(false));
    socket.once('error', () => finish(false));
    socket.connect(port, host);
  });
}

async function resolveMariaDbConfig() {
  if (process.env.DB_TEST_HOST && process.env.DB_TEST_ROOT_PASSWORD) {
    return {
      host: process.env.DB_TEST_HOST,
      port: parseInt(process.env.DB_TEST_PORT || '3306', 10),
      user: 'root',
      password: process.env.DB_TEST_ROOT_PASSWORD,
    };
  }
  const envPath = path.resolve(__dirname, '../../../.devcontainer/.env');
  const env = parseEnvFile(envPath);
  if (!env || !env.DB_ROOT_PASSWORD) return null;
  const port = parseInt(env.DB_PORT || '3306', 10);
  for (const host of ['127.0.0.1', 'mariadb', 'localhost']) {
    if (await probePort(host, port, 2000)) {
      return { host, port, user: 'root', password: env.DB_ROOT_PASSWORD };
    }
  }
  return null;
}

// ── Fixture ─────────────────────────────────────────────────────────────────

const ADMIN = { id: fixtureUserId('admin'), role: 'admin' };
const OWNER_EDITOR = { id: fixtureUserId('editor'), role: 'editor' };
// A second editor: `fixtureUserId` has no entry for one and falls back to the
// plain user's id, which would make two of the four roles below the same person.
const OTHER_EDITOR = { id: '7f3c2b18-4a55-4e21-9c0d-6b8e1f2a3d44', role: 'editor' };
const PLAIN_USER = { id: fixtureUserId('user'), role: 'user' };

const BLUEPRINT = '0a0a0a0a-0000-4000-8000-00000000000a';
const VARIANT = '0b0b0b0b-0000-4000-8000-00000000000b';
const CAUSE_FIELD = '0c0c0c0c-0000-4000-8000-00000000000c';
const RULED_FIELD = '0d0d0d0d-0000-4000-8000-00000000000d';
const POLICY_FIELD = '0e0e0e0e-0000-4000-8000-00000000000e';

const SECRET_KEY = 'internal_route_code';
const SECRET_LABEL = 'Internal Route Code';
const CAUSE_KEY = 'delivery_mode';

let dbReady = false;
let skipReason = null;
let testDbName = null;
let server = null;
let baseUrl = null;
let currentUser = ADMIN;

before(async () => {
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) {
    skipReason = 'no MariaDB reachable via .devcontainer/.env or env vars';
    if (process.env.REQUIRE_INTEGRATION_DB === '1') {
      throw new Error(`REQUIRE_INTEGRATION_DB=1 set but ${skipReason}.`);
    }
    return;
  }
  // Named for this process, and dropped by that exact name in `after`. The
  // container is shared: nothing here enumerates databases or matches a prefix.
  testDbName = `zz_c9_${process.pid}_hfd`;
  let admin = null;
  try {
    admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`CREATE DATABASE \`${testDbName}\``);
    await admin.query(`USE \`${testDbName}\``);
    const wanted = new Set([
      tbl(TABLES.HIERARCHY_NODES), tbl(TABLES.BLUEPRINT_FIELDS), tbl(TABLES.VARIANT_OVERRIDES),
    ]);
    const statements = buildEngineTableDDLs(tbl).filter((sql) => {
      const m = sql.match(/CREATE TABLE IF NOT EXISTS `([^`]+)`/);
      return m && wanted.has(m[1]);
    });
    assert.equal(statements.length, wanted.size, 'the DDL list no longer defines all three tables');
    for (const sql of statements) await admin.query(sql);

    // The blueprint is owned by OWNER_EDITOR — stored in UPPER case. `owner_id`
    // is CHAR(36) under a case-folding collation, so this row is theirs to every
    // statement in the system, and a JavaScript `===` would call it nobody's.
    await admin.query(
      `INSERT INTO \`${tbl(TABLES.HIERARCHY_NODES)}\` (id, name, node_type, owner_id)
       VALUES (?, 'BP', 'blueprint', ?)`,
      [BLUEPRINT, OWNER_EDITOR.id.toUpperCase()],
    );
    await admin.query(
      `INSERT INTO \`${tbl(TABLES.BLUEPRINT_FIELDS)}\`
         (id, blueprint_id, field_key, field_label, field_type, section, order_index, visibility_rule)
       VALUES (?, ?, ?, 'Delivery Mode', 'select', 'general', 0, NULL)`,
      [CAUSE_FIELD, BLUEPRINT, CAUSE_KEY],
    );
    await admin.query(
      `INSERT INTO \`${tbl(TABLES.BLUEPRINT_FIELDS)}\`
         (id, blueprint_id, field_key, field_label, field_type, section, order_index, visibility_rule)
       VALUES (?, ?, ?, ?, 'text', 'general', 1, ?)`,
      [RULED_FIELD, BLUEPRINT, SECRET_KEY, SECRET_LABEL,
        JSON.stringify({ field_key: CAUSE_KEY, operator: 'eq', value: 'air' })],
    );
    await admin.query(
      `INSERT INTO \`${tbl(TABLES.BLUEPRINT_FIELDS)}\`
         (id, blueprint_id, field_key, field_label, field_type, section, order_index)
       VALUES (?, ?, 'legacy_batch_id', 'Legacy Batch Id', 'text', 'extra', 2)`,
      [POLICY_FIELD, BLUEPRINT],
    );
    await admin.query(
      `INSERT INTO \`${tbl(TABLES.VARIANT_OVERRIDES)}\` (id, variant_id, field_id, action)
       VALUES (UUID(), ?, ?, 'hide')`,
      [VARIANT, POLICY_FIELD],
    );
    await admin.end();
    admin = null;

    pool = mariadb.createPool({
      ...dbConfig, database: testDbName, connectionLimit: 4, connectTimeout: 5000,
    });

    const app = express();
    app.use(express.json());
    app.use((req, _res, next) => { if (currentUser) req.user = currentUser; next(); });
    app.use('/edge/app/schema', schemaRouter);
    server = http.createServer(app);
    await new Promise((r) => server.listen(0, '127.0.0.1', r));
    baseUrl = `http://127.0.0.1:${server.address().port}`;
    dbReady = true;
  } catch (err) {
    skipReason = `setup failed: ${err.message}`;
    if (admin) { try { await admin.end(); } catch { /* best effort */ } }
    if (process.env.REQUIRE_INTEGRATION_DB === '1') throw err;
  }
});

after(async () => {
  if (server) { try { server.close(); } catch { /* best effort */ } }
  if (pool) { try { await pool.end(); } catch { /* best effort */ } }
  if (!testDbName) return;
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) return;
  try {
    const admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    // By the exact name recorded above. Never by pattern.
    await admin.query(`DROP DATABASE IF EXISTS \`${testDbName}\``);
    await admin.end();
  } catch { /* best effort */ }
});

async function ask(user) {
  currentUser = user;
  const res = await fetch(
    `${baseUrl}/edge/app/schema/hidden-field-disclosure/${BLUEPRINT}?variant_id=${VARIANT}`,
  );
  const text = await res.text();
  let parsed = null;
  try { parsed = JSON.parse(text); } catch { parsed = { raw: text }; }
  return { status: res.status, text, body: parsed };
}

function assertCarriesNothing(res) {
  for (const secret of [SECRET_KEY, SECRET_LABEL, CAUSE_KEY, 'legacy_batch_id',
    'variant_policy', 'visibility_rule', 'entries']) {
    assert.ok(!res.text.includes(secret), `response leaked ${secret}: ${res.text}`);
  }
}

describe('the hidden-field disclosure, per role, against a real engine', () => {
  test('an administrator reads the catalogue, and the rule\'s subject resolves', async (t) => {
    if (!dbReady) return t.skip(skipReason);
    const res = await ask(ADMIN);
    assert.equal(res.status, 200);
    const byKey = new Map(res.body.data.entries.map((e) => [e.field_key, e]));
    assert.equal(byKey.size, 2);
    // The engine read the JSON path — a stub could not have.
    assert.equal(byKey.get(SECRET_KEY).reason, 'visibility_rule');
    assert.equal(byKey.get(SECRET_KEY).cause_field_key, CAUSE_KEY);
    assert.equal(byKey.get(SECRET_KEY).cause_field_label, 'Delivery Mode');
    assert.equal(byKey.get(SECRET_KEY).section, 'general');
    assert.equal(byKey.get(SECRET_KEY).order_index, 1);
    assert.equal(byKey.get('legacy_batch_id').reason, 'variant_policy');
  });

  test('the owning editor reads it, though the column spells their id in another case', async (t) => {
    if (!dbReady) return t.skip(skipReason);
    const res = await ask(OWNER_EDITOR);
    assert.equal(res.status, 200);
    assert.equal(res.body.data.entries.length, 2);
  });

  test('an editor who owns another blueprint is refused, and told nothing', async (t) => {
    if (!dbReady) return t.skip(skipReason);
    const res = await ask(OTHER_EDITOR);
    assert.equal(res.status, 403);
    assertCarriesNothing(res);
  });

  test('an ordinary user is refused, and told nothing', async (t) => {
    if (!dbReady) return t.skip(skipReason);
    const res = await ask(PLAIN_USER);
    assert.equal(res.status, 403);
    assertCarriesNothing(res);
  });

  test('the absence check fires on a body that does carry the catalogue', async (t) => {
    if (!dbReady) return t.skip(skipReason);
    const res = await ask(ADMIN);
    assert.throws(() => assertCarriesNothing(res), /leaked/);
  });
});

/**
 * A second, independent scratch schema — deliberately not sharing the DB
 * above — so that dropping `cell_targets` here cannot touch a table the first
 * describe block's assertions read. `variant_overrides.cell_targets` is an
 * additive column whose migration entry is severity 'warning'
 * (migration-steps.js): a DBA who could not run the ALTER (the no-DDL flow,
 * CLAUDE.md §6/fmb-1329) leaves a real engine with the column simply gone, and
 * only a real engine can say whether naming it in a SELECT throws
 * ER_BAD_FIELD_ERROR — a stubbed driver returns whatever a fixture calls a
 * column, mocked-column-set or not.
 *
 * REUSES `baseUrl`/`server` (already running against `schemaRouter`) rather
 * than standing up a second Express app: `request-pool.js` destructures
 * `pool` from `db.js` AT ITS OWN MODULE LOAD, once, so a second
 * `require.cache[dbKey]` swap installed after that point is never read by any
 * already-cached route module — only the module-level `pool` variable this
 * file's mock closure (`lease`) already re-reads on every call can be
 * repointed. That is the ONE thing this suite's mock was built to allow, so
 * this reuses it instead of fighting it with a fresh router.
 */
describe('the disclosure statement against a DB that warn-skipped the cell_targets ALTER', () => {
  let dbReady2 = false;
  let skipReason2 = null;
  let testDbName2 = null;
  let pool2 = null;
  let originalPool = null;

  const BP2 = '1a1a1a1a-0000-4000-8000-00000000001a';
  const FIELD2 = '1c1c1c1c-0000-4000-8000-00000000001c';
  const VARIANT2 = '1b1b1b1b-0000-4000-8000-00000000001b';
  const POLICY_KEY2 = 'legacy_batch_id';

  before(async () => {
    const dbConfig = await resolveMariaDbConfig();
    if (!dbConfig) {
      skipReason2 = 'no MariaDB reachable via .devcontainer/.env or env vars';
      if (process.env.REQUIRE_INTEGRATION_DB === '1') {
        throw new Error(`REQUIRE_INTEGRATION_DB=1 set but ${skipReason2}.`);
      }
      return;
    }
    testDbName2 = `zz_c9_${process.pid}_hfdnc`;
    let admin = null;
    try {
      admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
      await admin.query(`CREATE DATABASE \`${testDbName2}\``);
      await admin.query(`USE \`${testDbName2}\``);
      const wanted = new Set([
        tbl(TABLES.HIERARCHY_NODES), tbl(TABLES.BLUEPRINT_FIELDS), tbl(TABLES.VARIANT_OVERRIDES),
      ]);
      const statements = buildEngineTableDDLs(tbl).filter((sql) => {
        const m = sql.match(/CREATE TABLE IF NOT EXISTS `([^`]+)`/);
        return m && wanted.has(m[1]);
      });
      assert.equal(statements.length, wanted.size, 'the DDL list no longer defines all three tables');
      for (const sql of statements) await admin.query(sql);

      // Standing in for an ALTER that a no-DDL-privilege operator never ran.
      await admin.query(`ALTER TABLE \`${tbl(TABLES.VARIANT_OVERRIDES)}\` DROP COLUMN cell_targets`);

      await admin.query(
        `INSERT INTO \`${tbl(TABLES.HIERARCHY_NODES)}\` (id, name, node_type, owner_id)
         VALUES (?, 'BP2', 'blueprint', ?)`,
        [BP2, ADMIN.id],
      );
      await admin.query(
        `INSERT INTO \`${tbl(TABLES.BLUEPRINT_FIELDS)}\`
           (id, blueprint_id, field_key, field_label, field_type, section, order_index)
         VALUES (?, ?, ?, 'Legacy Batch Id', 'text', 'extra', 0)`,
        [FIELD2, BP2, POLICY_KEY2],
      );
      await admin.query(
        `INSERT INTO \`${tbl(TABLES.VARIANT_OVERRIDES)}\` (id, variant_id, field_id, action)
         VALUES (UUID(), ?, ?, 'hide')`,
        [VARIANT2, FIELD2],
      );
      await admin.end();
      admin = null;

      pool2 = mariadb.createPool({
        ...dbConfig, database: testDbName2, connectionLimit: 4, connectTimeout: 5000,
      });
      // Swap the SAME module-level `pool` the file-level `lease()` closure
      // already reads per call — the FIRST scratch DB's tests have all
      // completed by the time this nested describe's `before` runs (node:test
      // executes top-level suites in registration order), so nothing else is
      // reading `pool` concurrently. Restored in `after`.
      originalPool = pool;
      pool = pool2;
      dbReady2 = true;
    } catch (err) {
      skipReason2 = `setup failed: ${err.message}`;
      if (admin) { try { await admin.end(); } catch { /* best effort */ } }
      if (process.env.REQUIRE_INTEGRATION_DB === '1') throw err;
    }
  });

  after(async () => {
    pool = originalPool;
    if (pool2) { try { await pool2.end(); } catch { /* best effort */ } }
    if (!testDbName2) return;
    const dbConfig = await resolveMariaDbConfig();
    if (!dbConfig) return;
    try {
      const admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
      // By the exact name recorded above. Never by pattern.
      await admin.query(`DROP DATABASE IF EXISTS \`${testDbName2}\``);
      await admin.end();
    } catch { /* best effort */ }
  });

  test('answers 200 with whole-field semantics, not 500', async (t) => {
    if (!dbReady2) return t.skip(skipReason2);
    currentUser = ADMIN;
    const res = await fetch(`${baseUrl}/edge/app/schema/hidden-field-disclosure/${BP2}?variant_id=${VARIANT2}`);
    assert.equal(res.status, 200);
    const body = await res.json();
    const entry = body.data.entries.find((e) => e.field_key === POLICY_KEY2);
    assert.ok(entry, 'the policy-hidden field must still be disclosed with the column gone');
    assert.equal(entry.reason, 'variant_policy');
  });
});
