// forward-to-edge-pathprefix.test.js — CLASS PROOF for the breaker-key fix.
//
// Every forwardToEdge(...) CALL in docker-api/src/infra MUST name a bounded
// breaker scope: `pathPrefix` (the usual case) or `breakerKey` (when the path
// guard must stay strict yet the breaker still needs a bounded route-class key,
// e.g. the is-admin route). An id-bearing literal keyed per request grew the
// breaker map without bound AND never accumulated the 3 failures that open a
// route's circuit. This scans the source so a FUTURE caller that omits both
// fails HERE, not silently in production. (The runtime fallback in
// resolveBreakerKey is the safety net; this is the guard that finds the omission.)
const fs = require('node:fs');
const path = require('node:path');
const { test } = require('node:test');
const assert = require('node:assert/strict');

const INFRA_DIR = path.join(__dirname, '..', '..', 'src', 'infra');

function listJsFiles(dir) {
  const out = [];
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) out.push(...listJsFiles(full));
    else if (entry.isFile() && entry.name.endsWith('.js')) out.push(full);
  }
  return out;
}

// Strip block + line comments so a `forwardToEdge(` mentioned in prose is not
// counted. The line-comment rule keeps `http://`-style colons intact.
function stripComments(src) {
  return src
    .replace(/\/\*[\s\S]*?\*\//g, '')
    .replace(/([^:])\/\/[^\n]*/g, '$1');
}

// The balanced-parenthesis argument text of every forwardToEdge(...) CALL (not
// the function definition) in one source string.
function forwardCallArgs(src) {
  const out = [];
  const needle = 'forwardToEdge(';
  let from = 0;
  for (;;) {
    const at = src.indexOf(needle, from);
    if (at === -1) break;
    from = at + needle.length;
    // Skip the definition `function forwardToEdge(` / `async function forwardToEdge(`.
    if (/function\s+$/.test(src.slice(Math.max(0, at - 20), at))) continue;
    let depth = 1;
    let i = from;
    for (; i < src.length && depth > 0; i += 1) {
      const ch = src[i];
      if (ch === '(') depth += 1;
      else if (ch === ')') depth -= 1;
    }
    out.push(src.slice(from, i - 1));
  }
  return out;
}

test('every forwardToEdge call in infra names a bounded breaker scope (pathPrefix or breakerKey)', () => {
  const files = listJsFiles(INFRA_DIR);
  const offenders = [];
  let callCount = 0;
  for (const file of files) {
    const src = stripComments(fs.readFileSync(file, 'utf8'));
    for (const args of forwardCallArgs(src)) {
      callCount += 1;
      if (!/\bpathPrefix\b/.test(args) && !/\bbreakerKey\b/.test(args)) {
        offenders.push(
          `${path.relative(INFRA_DIR, file)} :: forwardToEdge(${args.slice(0, 80).replace(/\s+/g, ' ')}…)`,
        );
      }
    }
  }
  // Sanity: the scanner actually found the known call sites — guards against a
  // silently empty scan that would pass vacuously if the pattern ever drifted.
  assert.ok(callCount >= 15, `expected the scan to find the infra forwardToEdge calls, saw ${callCount}`);
  assert.deepEqual(offenders, [], `forwardToEdge calls missing a breaker scope:\n${offenders.join('\n')}`);
});
