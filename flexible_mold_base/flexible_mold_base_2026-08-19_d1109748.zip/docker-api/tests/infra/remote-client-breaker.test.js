// remote-client-breaker.test.js — the infra circuit breaker is keyed per edge
// mount prefix, so 5xx from one edge route cannot open the breaker for an
// unrelated route. A module-global breaker (the pre-fmb bug) let three edge
// 500s from ANY proxied route synthetic-503 EVERY route for OPEN_DURATION_MS —
// a failing /health probe collateral-503'd the rest. These tests pin the
// isolation and confirm each route still trips on its own 3 consecutive 5xx.
const { test } = require('node:test');
const assert = require('node:assert/strict');

const {
  forwardToEdge,
  getCircuitState,
  _resetCircuitBreaker,
} = require('../../src/infra/lib/remote-client');

// Reuse the module's real fetch seam: swap global.fetch, record every call,
// restore on return/throw so one test never bleeds into the next.
function makeFakeResponse({ status = 200, headers = {}, body = null }) {
  const headerMap = new Map(
    Object.entries(headers).map(([k, v]) => [k.toLowerCase(), v]),
  );
  return {
    status,
    ok: status >= 200 && status < 300,
    headers: { get: (name) => headerMap.get(name.toLowerCase()) },
    json: async () => body,
    text: async () => (typeof body === 'string' ? body : JSON.stringify(body)),
  };
}

async function withStubbedFetch(stubFn, fn) {
  const calls = [];
  const originalFetch = global.fetch;
  global.fetch = async (...args) => {
    calls.push({ url: args[0], options: args[1] });
    return stubFn(...args);
  };
  try {
    return { result: await fn(), calls };
  } finally {
    global.fetch = originalFetch;
  }
}

// A 5xx upstream response is what recordFailure keys on (resp.status >= 500) —
// the exact incident mechanism (edge 500s from the /health handler).
const fiveHundred = async () => makeFakeResponse({
  status: 500,
  headers: { 'content-type': 'application/json' },
  body: { success: false },
});

async function driveFailures(prefix, times) {
  for (let i = 0; i < times; i += 1) {
    await withStubbedFetch(fiveHundred, () => forwardToEdge({
      method: 'GET', path: prefix, pathPrefix: prefix, user: { id: 'u' },
    }));
  }
}

test('breaker opened by route A does not short-circuit route B', async () => {
  // Arrange: force 3 recorded 5xx failures for one edge mount prefix.
  _resetCircuitBreaker();
  await driveFailures('/edge/app/flow', 3);
  assert.equal(getCircuitState('/edge/app/flow'), 'open', 'route A breaker must be open');

  // Act: a request to an UNRELATED prefix must reach fetch (not be short-circuited).
  const okStub = async () => makeFakeResponse({
    status: 200, headers: { 'content-type': 'application/json' }, body: { ok: true },
  });
  const { result, calls } = await withStubbedFetch(okStub, () => forwardToEdge({
    method: 'GET', path: '/edge/app/capacity', pathPrefix: '/edge/app/capacity', user: { id: 'u' },
  }));

  // Assert: route B forwarded and stayed closed; only route A is open.
  assert.equal(calls.length, 1, 'route B must reach fetch while route A is open');
  assert.equal(result.status, 200);
  assert.equal(getCircuitState('/edge/app/capacity'), 'closed', 'route B breaker must stay closed');
});

test('breaker still opens per route after 3 consecutive 5xx on that route', async () => {
  // Arrange: 3 failures on the capacity prefix.
  _resetCircuitBreaker();
  await driveFailures('/edge/app/capacity', 3);
  assert.equal(getCircuitState('/edge/app/capacity'), 'open');

  // Act + Assert: the 4th call to the SAME route short-circuits with a synthetic
  // 503 without reaching fetch (a stub that throws proves fetch is not called).
  const fatalStub = async () => { throw new Error('BUG: fetch reached while breaker open'); };
  const { result, calls } = await withStubbedFetch(fatalStub, () => forwardToEdge({
    method: 'GET', path: '/edge/app/capacity', pathPrefix: '/edge/app/capacity', user: { id: 'u' },
  }));

  assert.equal(calls.length, 0, 'an open breaker must short-circuit before fetch');
  assert.equal(result.status, 503);
  assert.equal(result.data.error.code, 'EDGE_UNAVAILABLE');
});

test('distinct id-bearing paths under one pathPrefix share a single breaker (trips after 3)', async () => {
  // The C1 shape: three DIFFERENT id-bearing paths, all under one route-class
  // prefix. Pre-fix each keyed its own breaker (unbounded map + never 3 failures);
  // now they fold into one breaker that opens on the combined 3.
  _resetCircuitBreaker();
  const prefix = '/edge/internal/public-read/templates';
  for (const id of ['id-aaa', 'id-bbb', 'id-ccc']) {
    await withStubbedFetch(fiveHundred, () => forwardToEdge({
      method: 'GET', path: `${prefix}/${id}`, pathPrefix: prefix, user: { id: 'u' },
    }));
  }
  assert.equal(getCircuitState(prefix), 'open', 'shared-prefix breaker must open after 3 combined failures');

  // A 4th, previously-unseen id under the same prefix is short-circuited (proves
  // the breaker is shared, not per-id).
  const fatalStub = async () => { throw new Error('BUG: fetch reached while breaker open'); };
  const { result, calls } = await withStubbedFetch(fatalStub, () => forwardToEdge({
    method: 'GET', path: `${prefix}/id-ddd`, pathPrefix: prefix, user: { id: 'u' },
  }));
  assert.equal(calls.length, 0, 'the shared breaker short-circuits every id under the prefix');
  assert.equal(result.status, 503);
  assert.equal(result.data.error.code, 'EDGE_UNAVAILABLE');
});

test('a call naming NO breaker scope falls back to one bounded shared breaker (never per-path)', async () => {
  // Runtime safety net: a caller that supplies neither pathPrefix nor breakerKey
  // must NOT key on the raw path. Three DISTINCT paths fold into the single
  // '__unscoped__' key and open it together — bounded by construction.
  _resetCircuitBreaker();
  for (const id of ['x1', 'x2', 'x3']) {
    await withStubbedFetch(fiveHundred, () => forwardToEdge({
      method: 'GET', path: `/edge/anything/${id}`, user: { id: 'u' },
    }));
  }
  assert.equal(getCircuitState(), 'open', 'the shared unscoped breaker must open after 3 combined failures');
});

test('no-key getCircuitState reports the worst state across routes', async () => {
  // Backward-compatible observability: after one route trips, the no-arg form
  // (used by existing callers that only ask "is anything open") reads 'open'.
  _resetCircuitBreaker();
  await driveFailures('/edge/app/flow', 3);
  assert.equal(getCircuitState(), 'open');
  _resetCircuitBreaker();
  assert.equal(getCircuitState(), 'closed');
});
