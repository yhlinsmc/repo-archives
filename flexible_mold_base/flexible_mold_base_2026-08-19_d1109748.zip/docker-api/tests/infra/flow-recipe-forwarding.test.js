// Tests that forwarding.js mounts the flow-recipes family proxy routes and
// the dispatch action mount before the blanket steps CRUD forward.
const { test } = require('node:test');
const assert = require('node:assert');

let dispatchMounted = false;

require.cache[require.resolve('../../src/infra/lib/remote-client')] = {
  exports: {
    createForwardingProxy: (target) => {
      const fn = (_req, _res, next) => next && next();
      fn._target = target;
      return fn;
    },
    createRawBodyForwardingProxy: () => (_q, _s, n) => n && n(),
    forwardToEdge: async () => ({ status: 200, data: {} }),
    passthroughResponse: () => {},
  },
};
require.cache[require.resolve('../../src/infra/routes/connector-fetch')] = { exports: () => {} };
require.cache[require.resolve('../../src/infra/routes/flow-step-dispatch')] = {
  exports: (app) => { dispatchMounted = true; },
};

const forwarding = require('../../src/infra/forwarding');

test('mounts flow-recipes family forwards and the dispatch route', () => {
  const used = [];
  const app = {
    use: (path, mw) => used.push({ path, target: mw && mw._target }),
    post: () => {},
    get: () => {},
  };

  // mountRemainingRoutes is the exported entry (confirmed from forwarding.js exports).
  forwarding.mountRemainingRoutes(app);

  assert.ok(
    used.some((u) => u.path === '/api/flow-recipes' && u.target === '/edge/app/flow-recipes'),
    'should mount /api/flow-recipes → /edge/app/flow-recipes',
  );
  assert.ok(
    used.some((u) => u.path === '/api/flow-recipe-steps' && u.target === '/edge/app/flow-recipe-steps'),
    'should mount /api/flow-recipe-steps → /edge/app/flow-recipe-steps',
  );
  assert.ok(
    used.some((u) => u.path === '/api/flow-recipe-runs' && u.target === '/edge/app/flow-recipe-runs'),
    'should mount /api/flow-recipe-runs → /edge/app/flow-recipe-runs',
  );
  assert.strictEqual(dispatchMounted, true, 'should call mountFlowStepDispatch(app)');
});
