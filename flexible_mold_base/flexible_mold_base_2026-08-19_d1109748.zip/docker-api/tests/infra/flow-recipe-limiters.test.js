// docker-api/tests/infra/flow-recipe-limiters.test.js
const { test } = require('node:test');
const assert = require('node:assert');
const { flowRecipeLimiterKind } = require('../../src/infra/limiters');

test('dispatch POST is classified dispatch', () => {
  assert.strictEqual(flowRecipeLimiterKind('POST', '/s1/dispatch'), 'dispatch');
  assert.strictEqual(flowRecipeLimiterKind('POST', '/s1/dispatch/'), 'dispatch');
});
test('mutations are classified write', () => {
  assert.strictEqual(flowRecipeLimiterKind('POST', '/'), 'write');
  assert.strictEqual(flowRecipeLimiterKind('PATCH', '/r1/approve'), 'write');
  assert.strictEqual(flowRecipeLimiterKind('DELETE', '/r1'), 'write');
  // reset-flow-link (mounted under /api/flow-templates) shares the write budget
  assert.strictEqual(flowRecipeLimiterKind('POST', '/tpl1/reset-flow-link'), 'write');
});
test('reads are unlimited (null)', () => {
  assert.strictEqual(flowRecipeLimiterKind('GET', '/'), null);
});
