// docker-api/tests/infra/keycloak-oidc-session.test.js
//
// Session-store smoke for the stateless encrypted-cookie migration (phase-5
// PR-5, item #30). The former in-process MemoryStore was wiped on every infra
// pod restart / ArgoCD auto-sync, forcing every user to re-login. The fix moves
// the session into an encrypted client cookie (no server-side store), so it
// survives restarts. These tests lock in: (1) no server-side store is attached,
// (2) the middleware still fails CLOSED when the encryption secret is
// missing/placeholder (no insecurely-keyed session can ever be issued).
const { describe, it, beforeEach, afterEach } = require('node:test');
const assert = require('node:assert/strict');

// shared/config validates required env at load time; set them before the
// module require (same pattern as tests/unit/index-infra-boot.test.js).
process.env.JWT_SECRET = process.env.JWT_SECRET || 'a'.repeat(48);
process.env.S2S_API_KEY = process.env.S2S_API_KEY || 's2s-test';

const { buildKeycloakMiddleware } = require('../../src/infra/middleware/keycloak-oidc');

describe('keycloak-oidc — stateless-cookie session', () => {
  const REAL = {};
  const KEYS = [
    'KEYCLOAK_ISSUER_BASE_URL', 'KEYCLOAK_CLIENT_ID', 'KEYCLOAK_CLIENT_SECRET',
    'KEYCLOAK_SECRET', 'BASE_URL', 'NODE_ENV',
  ];

  beforeEach(() => {
    KEYS.forEach(k => { REAL[k] = process.env[k]; });
    // A fast-failing issuer so the async startup discovery probe rejects
    // immediately (connection refused) and clears its 5s timer — keeps the
    // test event loop from lingering.
    process.env.KEYCLOAK_ISSUER_BASE_URL = 'http://127.0.0.1:1/realms/test';
    process.env.KEYCLOAK_CLIENT_ID = 'test-client';
    process.env.KEYCLOAK_CLIENT_SECRET = 'test-client-secret-value';
    process.env.KEYCLOAK_SECRET = 'a-real-40-char-random-session-secret-xyz1';
    process.env.BASE_URL = 'https://api.example.com';
    process.env.NODE_ENV = 'test';
  });

  afterEach(() => {
    KEYS.forEach(k => {
      if (REAL[k] === undefined) delete process.env[k];
      else process.env[k] = REAL[k];
    });
  });

  it('builds exactly one OIDC middleware from a valid config', () => {
    const mw = buildKeycloakMiddleware();
    assert.strictEqual(mw.length, 1);
    assert.strictEqual(typeof mw[0], 'function');
  });

  it('attaches no server-side session store (stateless encrypted cookie)', () => {
    // Regression guard: the former MemoryStore was exposed as `_sessionStore`.
    // A stateless-cookie session must attach no server-side store — that is
    // exactly what lets the session survive an infra pod restart.
    const mw = buildKeycloakMiddleware();
    assert.strictEqual(mw[0]._sessionStore, undefined);
  });

  it('fails closed (returns no middleware) when KEYCLOAK_SECRET is missing', () => {
    delete process.env.KEYCLOAK_SECRET;
    assert.deepStrictEqual(buildKeycloakMiddleware(), []);
  });

  it('fails closed (returns no middleware) when KEYCLOAK_SECRET is a placeholder', () => {
    process.env.KEYCLOAK_SECRET = 'changeme';
    assert.deepStrictEqual(buildKeycloakMiddleware(), []);
  });
});
