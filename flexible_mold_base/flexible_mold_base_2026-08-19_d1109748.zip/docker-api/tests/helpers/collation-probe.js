'use strict';

/**
 * collation-probe.js — the query shapes `sameStoredValue` issues, answered the
 * way `utf8mb4_general_ci` answers them.
 *
 * WHY A DOUBLE NEEDS THIS AT ALL. "Is this row the caller's" is a question
 * about a COLUMN, so the guards that ask it hand the two spellings to the
 * engine rather than comparing them in JavaScript. Any connection double
 * standing in for that engine therefore sees three extra statements — which
 * database this connection is on, how the column is declared, and the
 * comparison itself — and a double that throws on them turns an authorization
 * test into a 500.
 *
 * WHY IT ANSWERS RATHER THAN WAVES THROUGH. A stub returning a constant `same`
 * would be deciding the branch under test: every owner check would pass, or
 * every one would fail, and the assertion would be measuring the stub. So the
 * comparison here folds ASCII case exactly as the column's collation does, and
 * nothing else.
 *
 * WHAT IT CANNOT SETTLE. That the real column carries that collation, and that
 * the engine really keeps the new bytes on a case-only write, are facts about a
 * database — they are measured in the real-DB suites
 * (`tests/integration/owner-identity-real-db.test.js` opens by proving exactly
 * this), and this helper only keeps a unit double honest about the shape.
 */

// Matched on the projected aliases rather than on the table name: a test's own
// `information_schema.COLUMNS` read (a column-set probe, say) is a different
// statement and must keep reaching that test's own script.
const DATABASE_NAME_PROBE = /SELECT\s+DATABASE\(\)\s+AS\s+db/i;
const COLUMN_COLLATION_PROBE = /COLLATION_NAME\s+AS\s+co/i;
const SAME_STORED_VALUE_PROBE = /<=>/;

/** True for the statements `sameStoredValue` issues and nothing else. */
function isCollationProbe(sql) {
  const text = String(sql);
  return DATABASE_NAME_PROBE.test(text)
    || COLUMN_COLLATION_PROBE.test(text)
    || SAME_STORED_VALUE_PROBE.test(text);
}

/**
 * The engine's answer to one of those three, or `undefined` when the statement
 * is not one of them — so a caller can write `answerCollationProbe(sql, params)
 * ?? <its own script>` and keep its own SQL untouched.
 *
 * @param {string} sql
 * @param {*[]} [params]
 * @returns {object[]|undefined}
 */
function answerCollationProbe(sql, params) {
  const text = String(sql);
  if (DATABASE_NAME_PROBE.test(text)) return [{ db: 'probe_db' }];
  if (COLUMN_COLLATION_PROBE.test(text)) return [{ cs: 'utf8mb4', co: 'utf8mb4_general_ci' }];
  if (SAME_STORED_VALUE_PROBE.test(text)) {
    const [a, b] = params || [];
    // What `utf8mb4_general_ci` answers for two ASCII spellings. A NULL on
    // either side alone never reaches here — `sameStoredValue` settles that
    // without a query — so this only has to fold case.
    return [{ same: String(a).toLowerCase() === String(b).toLowerCase() ? 1 : 0 }];
  }
  return undefined;
}

module.exports = { isCollationProbe, answerCollationProbe };
