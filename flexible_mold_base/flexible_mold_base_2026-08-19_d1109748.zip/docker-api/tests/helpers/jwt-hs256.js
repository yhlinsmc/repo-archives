'use strict';

/**
 * jwt-hs256.js — shared test helper for minting HS256 bearer tokens with jose.
 *
 * Replaces the per-test `jsonwebtoken.sign(...)` calls after the jose migration.
 * Mirrors the claim shape the edge login route emits (sub [+ optional claims],
 * iat, and — when expiresIn is given — exp). Async because jose signing is async.
 */
const { SignJWT } = require('jose');

/**
 * @param {object} payload - JWT claims (e.g. { sub, email, role }).
 * @param {string} secret - HS256 signing secret (string; encoded internally).
 * @param {object} [opts]
 * @param {string|number} [opts.expiresIn] - jose setExpirationTime value
 *   (e.g. '24h', '5m', or a numeric epoch-seconds). Omit for a non-expiring token.
 * @returns {Promise<string>} signed compact JWS.
 */
async function signHs256(payload, secret, { expiresIn } = {}) {
  let builder = new SignJWT(payload)
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt();
  if (expiresIn !== undefined) builder = builder.setExpirationTime(expiresIn);
  return builder.sign(new TextEncoder().encode(secret));
}

module.exports = { signHs256 };
