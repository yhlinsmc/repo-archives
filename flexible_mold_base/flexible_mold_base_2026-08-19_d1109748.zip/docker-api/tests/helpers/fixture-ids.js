'use strict';

/**
 * fixture-ids.js — identifiers for fixtures, in the shape the column declares.
 *
 * Every id and FK in this schema is `CHAR(36)`, and the write gate now refuses a
 * value bound to one of those columns that is not of the identifier shape —
 * because MariaDB compares a CHAR column against a NUMBER in numeric context and
 * `WHERE id = 0` matches an arbitrary set of rows. A fixture spelling a user id
 * `'admin-1'` therefore exercises a request the deployed system cannot receive:
 * every id it stores is server-generated, and the identity header carries the
 * user's row id.
 *
 * Stable literals rather than `uuidv4()` per run, so a failure message names the
 * same id twice and a snapshot-style assertion stays comparable.
 */
const FIXTURE_USER_IDS = Object.freeze({
  admin: '5b729f1e-5c0b-447c-8144-3210469bc62c',
  editor: '405279b5-48c7-4bd5-8427-69d6ff5556a7',
  user: 'adeb723a-494c-4e33-8cdf-2374d0c68779',
  service_account: '6d0c8f2a-9f4b-4f6c-8f1d-2a7c4e5b9d31',
});

/** The fixture user id for a role, defaulting to the plain-user one. */
function fixtureUserId(role) {
  return FIXTURE_USER_IDS[role] || FIXTURE_USER_IDS.user;
}

module.exports = { FIXTURE_USER_IDS, fixtureUserId };
