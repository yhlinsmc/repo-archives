'use strict';

/**
 * parent-id-probe.js — the statement the CRUD factory issues to learn the id a
 * parent row actually holds, answered the way the column answers it.
 *
 * WHY A DOUBLE SEES THIS AT ALL. Every gate on a parent reference asks SQL —
 * the ownership chain's JOIN, the linked-blueprint probe, the FK's own
 * `WHERE id = ?` — and those columns are `CHAR(36)` under a case-folding
 * collation, so all of them resolve the parent for ANY spelling of its id. The
 * write therefore has to ask which spelling the parent really carries and bind
 * THAT, or the row ends up hanging off a value every SQL reader resolves and
 * the front end's `.find(n => n.id === node.parent_id)` resolves to nobody.
 * A connection double that throws on the extra statement turns an ordinary
 * create into a 500.
 *
 * WHAT IT CANNOT SETTLE. Whether the rebinding actually changes the stored
 * bytes is a fact about a database, and it is measured in the real-DB suite
 * (`tests/integration/write-core-identity-real-db.test.js`). This helper only
 * keeps a unit double honest about the SHAPE.
 */

// Anchored on the whole statement, not on a fragment: a test's own `SELECT id
// FROM x WHERE id = ? FOR UPDATE`, or one projecting more than `id`, is a
// different statement and must keep reaching that test's own script.
const PARENT_ID_PROBE = /^SELECT id FROM `[^`]+` WHERE id = \?$/;

/** True for the parent-id resolution statement and nothing else. */
function isParentIdProbe(sql) {
  return PARENT_ID_PROBE.test(String(sql).trim());
}

/**
 * The engine's answer, or `undefined` when the statement is not that probe — so
 * a caller can write `answerParentIdProbe(sql, params) ?? <its own script>` and
 * leave its own SQL untouched.
 *
 * `storedIds` is what the double claims the table holds. Given one, the lookup
 * folds ASCII case exactly as the column's collation does and answers with the
 * STORED spelling, so a test can watch a named row come back under the spelling
 * that row carries, and an unknown id come back as no row at all.
 *
 * OMITTED, IT STILL ANSWERS WITH A CANONICAL SPELLING rather than echoing what
 * it was asked. It used to echo, and every one of this helper's call sites omits
 * `storedIds` — so `bindStoredParentIds` was a no-op in every unit test in the
 * tree and its only witness was one real-DB suite. An echo is not a neutral
 * default, it is a claim: "this table holds exactly the bytes you sent", which
 * is the one thing a `CHAR(36)` id column under a folding collation does NOT
 * promise. Lower-casing is the honest claim in its place — every id this system
 * puts in such a column comes from `UUID()` or `uuidv4()`, and both produce
 * lower-case — so a double that models no particular rows still models a real
 * table, and a test that sends a respelled reference sees it come back bound.
 *
 * Whether the rebinding changes the bytes on DISK is still a fact about a
 * database, and still measured in the real-DB suites.
 *
 * @param {string} sql
 * @param {*[]} [params]
 * @param {string[]} [storedIds]
 * @returns {object[]|undefined}
 */
function answerParentIdProbe(sql, params, storedIds) {
  if (!isParentIdProbe(sql)) return undefined;
  const asked = (params || [])[0];
  if (!Array.isArray(storedIds)) {
    return typeof asked === 'string' ? [{ id: asked.toLowerCase() }] : [];
  }
  const folded = String(asked).toLowerCase();
  const stored = storedIds.find((id) => String(id).toLowerCase() === folded);
  return stored === undefined ? [] : [{ id: stored }];
}

module.exports = { isParentIdProbe, answerParentIdProbe };
