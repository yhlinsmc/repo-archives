/**
 * mock-connector-server.js — native-http canned server for connector dispatch
 * tests + manual ONPREM curl verification. Lives under tests/, excluded from
 * dist-source by the manifest.exclude.txt `docker-api/tests/` rule and guarded
 * by verify-preflight-checks.sh, so it never ships.
 *
 *   GET  /echo        → 200 JSON { ok, headers } (reflects request headers so a
 *                        test can assert the injected auth header arrived)
 *   GET  /delay?ms=N  → responds after N ms (timeout test)
 *   GET  /large?mb=N  → streams N MB (size-cap test)
 *   GET  /redirect    → 302 Location: /echo (manual-redirect test)
 *   POST /echo-body   → 200 JSON { body } (body round-trip)
 *
 * Programmatic: const { server, port } = await start();  // listens on 127.0.0.1:0
 * Manual:       node tests/helpers/mock-connector-server.js   // fixed :8799
 */
const http = require('node:http');

function handler(req, res) {
  const u = new URL(req.url, 'http://mock');
  if (u.pathname === '/echo') {
    res.writeHead(200, { 'content-type': 'application/json' });
    return res.end(JSON.stringify({ ok: true, headers: req.headers }));
  }
  if (u.pathname === '/delay') {
    const ms = Number(u.searchParams.get('ms') || '50');
    return setTimeout(() => { res.writeHead(200); res.end('late'); }, ms);
  }
  if (u.pathname === '/large') {
    const mb = Number(u.searchParams.get('mb') || '1');
    res.writeHead(200, { 'content-type': 'application/octet-stream' });
    const chunk = Buffer.alloc(1024 * 1024, 0x61);
    let i = 0;
    const pump = () => {
      if (i++ >= mb) return res.end();
      if (res.write(chunk)) pump(); else res.once('drain', pump);
    };
    return pump();
  }
  if (u.pathname === '/redirect') { res.writeHead(302, { location: '/echo' }); return res.end(); }
  if (u.pathname === '/echo-body' && req.method === 'POST') {
    let b = '';
    req.on('data', (c) => { b += c; });
    req.on('end', () => {
      res.writeHead(200, { 'content-type': 'application/json' });
      res.end(JSON.stringify({ body: b }));
    });
    return;
  }
  res.writeHead(404); res.end('nope');
}

function start() {
  const server = http.createServer(handler);
  return new Promise((resolve) => {
    server.listen(0, '127.0.0.1', () => resolve({ server, port: server.address().port }));
  });
}

if (require.main === module) {
  http.createServer(handler).listen(8799, () => console.log('mock connector server on http://127.0.0.1:8799'));
}

module.exports = { start };
