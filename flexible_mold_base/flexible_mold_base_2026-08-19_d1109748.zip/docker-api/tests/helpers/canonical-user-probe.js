'use strict';

/**
 * canonical-user-probe.js — the statement `resolveCanonicalUserId` issues, and
 * the answer a `users` table gives it.
 *
 * WHY A DOUBLE SEES THIS. `users.id` is `CHAR(36)` under a case-folding
 * collation, so a write that takes an owner from a request body has to ask
 * which row the spelling names and bind the spelling THAT row carries — a
 * respelled id leaves the record owned, to SQL, by somebody no JavaScript
 * reader of the column can find. Any connection double standing in for a write
 * path that carries an owner therefore sees one extra statement, and a double
 * that throws on it turns an ordinary create into a 500.
 *
 * WHY IT ANSWERS RATHER THAN WAVES THROUGH. A stub returning a constant row
 * would decide the branch under test: every owner would exist, and the refusal
 * this guard is for could never be seen. Given a user list it folds ASCII case
 * exactly as the column's collation does and answers with the STORED spelling;
 * given none it answers "no such user", which is the fail-closed direction and
 * the honest thing for a double that models no users at all.
 */

// Anchored on the whole statement so a test's own `users` read keeps reaching
// that test's own script.
const CANONICAL_USER_PROBE = /^SELECT id, role, banned FROM `[^`]+` WHERE id = \?$/;

/** True for the canonical-user resolution statement and nothing else. */
function isCanonicalUserProbe(sql) {
  return CANONICAL_USER_PROBE.test(String(sql).replace(/\s+/g, ' ').trim());
}

/**
 * The engine's answer, or `undefined` when the statement is not that probe — so
 * a caller can write `answerCanonicalUserProbe(sql, params, users) ?? <its own
 * script>` and leave its own SQL untouched.
 *
 * @param {string} sql
 * @param {*[]} [params]
 * @param {Array<{id: string, role?: string, banned?: boolean}>} [users] what the
 *   double claims the table holds
 * @returns {object[]|undefined}
 */
function answerCanonicalUserProbe(sql, params, users) {
  if (!isCanonicalUserProbe(sql)) return undefined;
  const asked = (params || [])[0];
  if (typeof asked !== 'string') return [];
  const folded = asked.toLowerCase();
  const row = (users || []).find((u) => String(u.id).toLowerCase() === folded);
  return row ? [{ id: row.id, role: row.role ?? null, banned: row.banned ? 1 : 0 }] : [];
}

module.exports = { isCanonicalUserProbe, answerCanonicalUserProbe };
