#!/usr/bin/env bash
# docker-api/tests/migration-e2e/run.sh — fmb-1329 Task 7 docker e2e migration
# suite entry point.
#
# NOT part of the default `node --test 'tests/**/*.test.js'` glob (this file
# is not a `.test.js` — scenarios.js is the driver, run.sh is the harness) and
# NOT wired into `npm test` — it needs a real docker daemon plus a disposable
# MariaDB, so it stays opt-in. Run explicitly:
#
#   bash docker-api/tests/migration-e2e/run.sh
#
# scripts/cicd/ship-gate-check.sh Step 23 invokes this conditionally (only
# when the diff touches the migration engine: migrations.js /
# migration-steps.js / table-ddls.js / schema-manifest.js) and WARN-skips
# rather than hard-failing when docker is unavailable.
#
# Lifecycle mirrors scripts/migration-baseline/deletion-gate.sh: boots one
# disposable MariaDB container, waits for readiness, tears it down
# unconditionally via trap. Unlike deletion-gate.sh (which shells out via
# `docker exec ... mariadb` to avoid a TCP dependency), this suite drives the
# REAL production executor (`runSchemaMigrations()`), whose `conn.query()`
# calls need a live driver connection — so the container publishes a host
# port and scenarios.js connects over TCP via the `mariadb` npm package
# (already a docker-api dependency; no new npm deps added).
set -euo pipefail

if [[ -t 1 ]]; then
  RED='\033[0;31m'; GREEN='\033[0;32m'; CYAN='\033[0;36m'; YELLOW='\033[0;33m'; NC='\033[0m'
else
  RED=''; GREEN=''; CYAN=''; YELLOW=''; NC=''
fi
log()  { echo -e "${CYAN}[migration-e2e]${NC} $*"; }
warn() { echo -e "${YELLOW}[migration-e2e]${NC} $*" >&2; }
err()  { echo -e "${RED}[migration-e2e]${NC} $*" >&2; }
ok()   { echo -e "${GREEN}[migration-e2e]${NC} $*"; }

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DOCKER_API_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"

if ! command -v docker >/dev/null 2>&1; then
  err "docker not found — this suite needs a real disposable MariaDB."
  exit 1
fi

if [[ ! -d "$DOCKER_API_DIR/node_modules/mariadb" ]]; then
  err "docker-api/node_modules/mariadb not installed — run 'npm ci' in docker-api/ first."
  exit 1
fi

IMAGE="${SCHEMA_E2E_IMAGE:-mariadb:11.4}"
CONTAINER="fmb-schema-e2e-$$"
ROOT_PASSWORD="e2e_root_pw_$$"

cleanup() {
  docker rm -f "$CONTAINER" >/dev/null 2>&1 || true
}
trap cleanup EXIT

log "starting disposable container ${CONTAINER} (${IMAGE})..."
docker run -d --rm \
  --name "$CONTAINER" \
  -e MARIADB_ROOT_PASSWORD="$ROOT_PASSWORD" \
  -e MARIADB_ALLOW_EMPTY_ROOT_PASSWORD=no \
  -p 127.0.0.1:0:3306 \
  "$IMAGE" >/dev/null

log "waiting for container readiness..."
READY=0
for _ in $(seq 1 60); do
  if docker exec -e MYSQL_PWD="$ROOT_PASSWORD" "$CONTAINER" \
      mariadb -uroot -e 'SELECT 1' >/dev/null 2>&1; then
    READY=1
    break
  fi
  sleep 1
done
if [[ "$READY" -ne 1 ]]; then
  err "container never became ready within 60s."
  exit 1
fi
ok "container ready."

HOST_PORT="$(docker port "$CONTAINER" 3306/tcp | tail -1 | sed -E 's/.*:([0-9]+)$/\1/')"
if [[ -z "$HOST_PORT" ]]; then
  err "could not determine the published host port for 3306/tcp."
  exit 1
fi
log "published on 127.0.0.1:${HOST_PORT}"

log "running scenario driver (node --test)..."
# `node --test` does not forward argv after `--` to the test file's own
# process.argv — connection params go through env instead.
# Wrapped in if/else (not a bare subshell) so a non-zero exit under `set -e`
# doesn't terminate the script before the RC capture + FAIL banner below run.
set +e
(cd "$DOCKER_API_DIR" && \
  SCHEMA_E2E_HOST=127.0.0.1 SCHEMA_E2E_PORT="$HOST_PORT" SCHEMA_E2E_PASSWORD="$ROOT_PASSWORD" \
  node --test --test-reporter=spec "tests/migration-e2e/scenarios.js")
RC=$?
set -e

if [[ "$RC" -eq 0 ]]; then
  ok "all migration e2e scenarios passed."
else
  err "migration e2e suite FAILED (rc=$RC)."
fi
exit "$RC"
