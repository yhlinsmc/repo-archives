/**
 * scenarios.js — fmb-1329 Task 7 docker e2e migration suite driver.
 *
 * Plain `node:test`, run via docker-api/tests/migration-e2e/run.sh (never
 * directly — needs a live MariaDB the harness boots + tears down). Proves
 * the REAL executor (`docker-api/src/edge/migrations.js`) against a real
 * connection: mocked-conn coverage already lives in
 * docker-api/src/edge/__tests__/migration-executor.test.js — this suite is
 * the second verification layer (spec §11 Q11-2), the thing a stub cannot
 * prove (real MariaDB privilege errors, real information_schema state, real
 * GET_LOCK/advisory-lock behavior).
 *
 * Fixture steps (drop-column / add-column entries used in scenarios 1-7) are
 * injected via the executor's `opts.steps` parameter — they never touch the
 * production registry (MIGRATION_STEPS stayed empty through PR1, spec §9).
 * Scenario 8 (fmb-1329 T11) is the one exception by design: it imports and
 * runs the REAL production custom entries directly, since what's under test
 * there is the entries' own dirty-data-safe backfill logic, not just the
 * executor's generic custom-kind dispatch (already unit-tested against a
 * mocked conn).
 *
 * Connection params come from env (not argv — `node --test` does not
 * forward args after `--` to the test file's own process.argv):
 *   SCHEMA_E2E_HOST / SCHEMA_E2E_PORT / SCHEMA_E2E_PASSWORD
 */
'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const mariadb = require('mariadb');

const { createMigrationsModule } = require('../../src/edge/migrations');
const {
  buildInfraTableDDLs,
  buildEngineTableDDLs,
  INFRA_TABLE_NAMES,
  ENGINE_TABLE_NAMES,
} = require('../../src/table-ddls');
const { TABLES } = require('../../src/shared/constants');
const { ddlFragmentFor } = require('../../src/edge/lib/schema-manifest');
const { readSchemaColumns, computeMissing, computeColumnDrift } = require('../../src/edge/lib/schema-comparison');
const { derivePendingStepNames, derivePendingStepsSql } = require('../../src/edge/lib/pending-steps');
const {
  BASELINE_SCHEMA_VERSION,
  PLATFORM_SCHEMA_VERSION,
  MIGRATION_STEPS,
} = require('../../src/edge/migration-steps');

const HOST = process.env.SCHEMA_E2E_HOST || '127.0.0.1';
const PORT = Number(process.env.SCHEMA_E2E_PORT || 3306);
const ROOT_PASSWORD = process.env.SCHEMA_E2E_PASSWORD;
if (!ROOT_PASSWORD) {
  throw new Error('SCHEMA_E2E_PASSWORD env var is required — run via docker-api/tests/migration-e2e/run.sh, not directly.');
}

const APP_TABLE_NAMES = INFRA_TABLE_NAMES.concat(ENGINE_TABLE_NAMES);
const PREFIX = 'fmb_';
const t = (base) => `${PREFIX}${base}`;

let dbCounter = 0;

async function connectAs(user, password, database) {
  return mariadb.createConnection({
    host: HOST,
    port: PORT,
    user,
    password,
    database: database || undefined,
    connectTimeout: 10000,
  });
}

async function freshDatabase(rootConn) {
  dbCounter += 1;
  const dbName = `fmb_e2e_${process.pid}_${dbCounter}`;
  await rootConn.query(`CREATE DATABASE \`${dbName}\``);
  await rootConn.query(`USE \`${dbName}\``);
  return dbName;
}

async function applyFullSchema(conn) {
  for (const ddl of buildInfraTableDDLs(t)) await conn.query(ddl);
  for (const ddl of buildEngineTableDDLs(t)) await conn.query(ddl);
}

async function readStamp(conn) {
  const rows = await conn.query(
    `SELECT value FROM \`${t(TABLES.SYSTEM_SETTINGS)}\` WHERE \`key\` = 'platform_schema_version' LIMIT 1`,
  );
  if (!rows.length || !rows[0].value) return null;
  try {
    return JSON.parse(rows[0].value);
  } catch {
    return rows[0].value;
  }
}

async function writeStamp(conn, version) {
  await conn.query(
    `INSERT INTO \`${t(TABLES.SYSTEM_SETTINGS)}\` (id, \`key\`, value, description)
     VALUES (UUID(), 'platform_schema_version', ?, 'e2e seed')`,
    [JSON.stringify(version)],
  );
}

async function countMigrationAudits(conn) {
  const rows = await conn.query(
    `SELECT COUNT(*) AS c FROM \`${t(TABLES.FEATURE_AUDIT)}\` WHERE event_type LIKE 'schema_migration.%'`,
  );
  return Number(rows[0].c);
}

async function columnExists(conn, physicalTable, column) {
  const rows = await conn.query(
    `SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?`,
    [physicalTable, column],
  );
  return rows.length > 0;
}

async function columnIsNullable(conn, physicalTable, column) {
  const rows = await conn.query(
    `SELECT IS_NULLABLE FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?`,
    [physicalTable, column],
  );
  return rows.length > 0 && rows[0].IS_NULLABLE === 'YES';
}

function makeModule(dbName, extraDeps = {}) {
  return createMigrationsModule({
    t,
    PLATFORM_SCHEMA_VERSION: BASELINE_SCHEMA_VERSION,
    _configFull: { database: dbName, user: 'root' },
    _tablePrefix: PREFIX,
    APP_TABLE_NAMES,
    ...extraDeps,
  });
}

// ── Scenario 1: fresh empty DB — full DDL + boot-equivalent run ───────────
// Boot order mirrors production: ensureInfrastructure() creates infra
// tables first (no engine tables exist yet, no stamp) — the FIRST
// runSchemaMigrations call writes the stamp on that infra-only shape. Only
// afterward does the Setup Wizard create engine tables. Replicating this
// order matters: creating a PARTIAL/incomplete engine schema with no stamp
// trips the baseline guard's completeness check (scenario 6). A COMPLETE
// unstamped schema is the wizard case and is allowed to stamp (scenario 7);
// the infra-only-first order here is the fresh-install path (zero engine tables).
test('scenario 1: fresh empty DB -> boot-equivalent run -> zero missing, stamp written', async () => {
  const rootConn = await connectAs('root', ROOT_PASSWORD);
  try {
    const dbName = await freshDatabase(rootConn);
    for (const ddl of buildInfraTableDDLs(t)) await rootConn.query(ddl);

    const m = makeModule(dbName);
    await m.runSchemaMigrations(rootConn, { context: 'boot', steps: [] });
    assert.equal(await readStamp(rootConn), BASELINE_SCHEMA_VERSION, 'stamp written after infra-only boot');

    for (const ddl of buildEngineTableDDLs(t)) await rootConn.query(ddl);

    const liveByTable = await readSchemaColumns(rootConn);
    const { missing_tables, missing_columns } = computeMissing(liveByTable, t);
    assert.deepEqual(missing_tables, [], 'no missing tables after full DDL');
    assert.deepEqual(missing_columns, [], 'no missing columns after full DDL');
    // fmb-1360: a freshly-created schema straight from table-ddls.js must show
    // ZERO advisory type/nullability drift against the parsed manifest — this is
    // the real-DB proof that the normalization folds every MariaDB representation
    // quirk (BOOLEAN/int-width/JSON) for the types actually in use.
    assert.deepEqual(computeColumnDrift(liveByTable, t), [], 'no column drift on a fresh full-DDL schema');
  } finally {
    await rootConn.end();
  }
});

// ── Scenario 2: unprivileged user -> skip + degrade; re-grant -> converge ─
// Q9 guarantee (spec §4.7): switching to a privileged account and rebooting
// auto-completes migrations. Uses a REAL manifest column
// (user_templates.flow_external_id) removed from an otherwise-complete
// schema, so ddlFragmentFor() returns a real fragment and the SQL-export
// code path (schema-export-sql.js's _buildExportSql, exercised inline
// below via the same missing-columns shape) has something genuine to
// render — not a synthetic column absent from table-ddls.js.
test('scenario 2: unprivileged user skips + degrades; re-grant converges + stamp advances', async () => {
  const rootConn = await connectAs('root', ROOT_PASSWORD);
  let unprivConn;
  try {
    const dbName = await freshDatabase(rootConn);

    // Establish a baseline stamp via a privileged infra-only boot first
    // (production shape: the stamp already exists by the time engine
    // tables show up — see scenario 1's comment on baseline-guard
    // ordering; creating engine tables before any stamp exists would trip
    // the "no stamp + engine tables present" foreign-DB guard).
    for (const ddl of buildInfraTableDDLs(t)) await rootConn.query(ddl);
    const seedModule = makeModule(dbName);
    await seedModule.runSchemaMigrations(rootConn, { context: 'boot', steps: [] });
    assert.equal(await readStamp(rootConn), BASELINE_SCHEMA_VERSION);

    for (const ddl of buildEngineTableDDLs(t)) await rootConn.query(ddl);

    // Simulate "this column needs a migration": drop a real manifest column.
    await rootConn.query(`ALTER TABLE \`${t(TABLES.USER_TEMPLATES)}\` DROP COLUMN flow_external_id`);

    const fragment = ddlFragmentFor(TABLES.USER_TEMPLATES, 'flow_external_id');
    assert.ok(fragment, 'ddlFragmentFor must resolve a real fragment for a manifest column');
    const addStep = {
      kind: 'add-column',
      table: TABLES.USER_TEMPLATES,
      column: 'flow_external_id',
      ddl: fragment,
      step: 'e2e_flow_external_id_add',
      severity: 'warning',
    };

    const unprivUser = 'e2e_unpriv';
    const unprivPassword = 'e2e_unpriv_pw';
    await rootConn.query(`CREATE USER '${unprivUser}'@'%' IDENTIFIED BY '${unprivPassword}'`);
    await rootConn.query(`GRANT SELECT, INSERT, UPDATE, DELETE ON \`${dbName}\`.* TO '${unprivUser}'@'%'`);

    const targetVersion = '9.9.2';
    const unprivModule = makeModule(dbName, { PLATFORM_SCHEMA_VERSION: targetVersion, _configFull: { database: dbName, user: unprivUser } });

    unprivConn = await connectAs(unprivUser, unprivPassword, dbName);
    await unprivModule.runSchemaMigrations(unprivConn, { context: 'boot', steps: [addStep] });

    // Degraded: column still absent, stamp still at the seeded baseline.
    assert.equal(await columnExists(rootConn, t(TABLES.USER_TEMPLATES), 'flow_external_id'), false, 'column NOT added — DDL privilege missing');
    assert.equal(await readStamp(rootConn), BASELINE_SCHEMA_VERSION, 'stamp NOT advanced while degraded');

    // Export SQL non-empty: the same shape schema-export-sql.js renders
    // (CREATE/ALTER statements from the DDL builders + ddlFragmentFor).
    const liveByTable = await readSchemaColumns(rootConn);
    const { missing_columns } = computeMissing(liveByTable, t);
    const flowMissing = missing_columns.find((m) => m.table === 'user_templates' && m.column === 'flow_external_id');
    assert.ok(flowMissing, 'comparison must report the dropped column as missing');
    const exportSql = `ALTER TABLE \`${t('user_templates')}\` ADD COLUMN ${ddlFragmentFor('user_templates', 'flow_external_id')};`;
    assert.ok(exportSql.includes('ALTER TABLE'), 'export SQL is non-empty and names the missing column');
    assert.ok(exportSql.includes('flow_external_id'));

    // Re-grant ALTER -> converge on the SAME connection's next call (grants
    // are re-probed via SHOW GRANTS on every preflight, not cached).
    await rootConn.query(`GRANT ALTER ON \`${dbName}\`.* TO '${unprivUser}'@'%'`);
    // A DB-level privilege GRANT (as opposed to a global mysql.user change)
    // is only picked up by a session's ACL cache on its NEXT authentication
    // — an already-open connection keeps evaluating against the privilege
    // snapshot from CONNECT time. Reconnecting mirrors "switch to a
    // privileged account and restart" (Q9's actual guarantee) more
    // faithfully than reusing the same session anyway.
    await unprivConn.end();
    unprivConn = await connectAs(unprivUser, unprivPassword, dbName);
    await unprivModule.runSchemaMigrations(unprivConn, { context: 'boot', steps: [addStep] });

    assert.equal(await columnExists(rootConn, t(TABLES.USER_TEMPLATES), 'flow_external_id'), true, 'column added after re-grant');
    assert.equal(await readStamp(rootConn), targetVersion, 'stamp advances after convergence');
  } finally {
    if (unprivConn) await unprivConn.end();
    await rootConn.end();
  }
});

// ── Scenario 3: drop-column fixture idempotency ────────────────────────────
// Exercises _runMigrationSteps directly (not the outer runSchemaMigrations
// version gate) so the SECOND call genuinely re-probes live state rather
// than short-circuiting on "already at target version" — proving the
// drop-column step's own idempotency, which is the thing under test.
test('scenario 3: drop-column fixture -> drops once, idempotent re-run (no error, no skip)', async () => {
  const rootConn = await connectAs('root', ROOT_PASSWORD);
  try {
    const dbName = await freshDatabase(rootConn);
    await applyFullSchema(rootConn);
    await rootConn.query(`ALTER TABLE \`${t(TABLES.USER_TEMPLATES)}\` ADD COLUMN fixture_extra_col VARCHAR(50) NULL`);

    const dropStep = {
      kind: 'drop-column',
      table: TABLES.USER_TEMPLATES,
      column: 'fixture_extra_col',
      step: 'e2e_fixture_extra_col_drop',
      severity: 'warning',
    };
    const m = makeModule(dbName);

    const first = await m._runMigrationSteps(rootConn, [dropStep]);
    assert.equal(first.skippedSteps, 0, 'clean drop is not accounted as skipped');
    assert.equal(await columnExists(rootConn, t(TABLES.USER_TEMPLATES), 'fixture_extra_col'), false);

    const auditBefore = await countMigrationAudits(rootConn);
    const second = await m._runMigrationSteps(rootConn, [dropStep]);
    const auditAfter = await countMigrationAudits(rootConn);

    assert.equal(second.skippedSteps, 0, 'idempotent re-run: probe finds column absent, no error, no skip');
    assert.equal(auditAfter, auditBefore, 'idempotent re-run writes no new audit row (nothing failed)');
    assert.equal(await columnExists(rootConn, t(TABLES.USER_TEMPLATES), 'fixture_extra_col'), false);
  } finally {
    await rootConn.end();
  }
});

// ── Scenario 4: baseline guard ─────────────────────────────────────────────
// A stamp below BASELINE_SCHEMA_VERSION must block the executor entirely —
// including a step that WOULD otherwise apply cleanly (proves the guard
// runs before step execution, not just before the version bump).
test("scenario 4: baseline guard — stamp '3.2.400' -> nothing runs, stamp unchanged, unsupported", async () => {
  const rootConn = await connectAs('root', ROOT_PASSWORD);
  try {
    const dbName = await freshDatabase(rootConn);
    await applyFullSchema(rootConn);
    await rootConn.query(`ALTER TABLE \`${t(TABLES.USER_TEMPLATES)}\` DROP COLUMN flow_external_id`);
    await writeStamp(rootConn, '3.2.400');

    const fragment = ddlFragmentFor(TABLES.USER_TEMPLATES, 'flow_external_id');
    const addStep = {
      kind: 'add-column',
      table: TABLES.USER_TEMPLATES,
      column: 'flow_external_id',
      ddl: fragment,
      step: 'e2e_baseline_guard_probe',
      severity: 'warning',
    };
    const m = makeModule(dbName, { PLATFORM_SCHEMA_VERSION: '9.9.3' });

    const result = await m.runSchemaMigrations(rootConn, { context: 'boot', steps: [addStep] });

    assert.equal(await readStamp(rootConn), '3.2.400', 'stamp untouched below baseline');
    assert.equal(await columnExists(rootConn, t(TABLES.USER_TEMPLATES), 'flow_external_id'), false, 'step never ran below baseline');
    // runSchemaMigrations wraps _runSchemaMigrationsLocked in the GET_LOCK
    // helper, which returns its inner result on the acquired path.
    assert.deepEqual(result, { unsupported: true });
  } finally {
    await rootConn.end();
  }
});

// ── Scenario 5 (coordinator addition): stamped-baseline DB boot is a no-op ─
test('scenario 5: stamped-3.2.520 DB boot -> no-op (nothing executed, stamp unchanged)', async () => {
  const rootConn = await connectAs('root', ROOT_PASSWORD);
  try {
    const dbName = await freshDatabase(rootConn);
    await applyFullSchema(rootConn);
    await writeStamp(rootConn, BASELINE_SCHEMA_VERSION);

    const m = makeModule(dbName);
    const auditBefore = await countMigrationAudits(rootConn);
    await m.runSchemaMigrations(rootConn, { context: 'boot', steps: [] });
    const auditAfter = await countMigrationAudits(rootConn);

    assert.equal(await readStamp(rootConn), BASELINE_SCHEMA_VERSION, 'stamp unchanged on no-op boot');
    assert.equal(auditAfter, auditBefore, 'no new schema_migration audit rows on no-op boot');
  } finally {
    await rootConn.end();
  }
});

// ── Scenario 6 (Codex R2 P1a/P1b): unstamped pre-baseline DB via init-db ────
// A real production non-boot caller (Setup Wizard's init-db path). An unstamped
// DB carrying engine tables in an OLD shape (a column dropped to simulate a
// pre-baseline schema) must be classified unsupported and MUST NOT be stamped —
// the exact masking bug the boot-gate allowed (init-db would fill missing tables,
// no-op the empty executor, and advance the stamp over an incomplete schema).
test('scenario 6: unstamped DB with a pre-baseline (missing-column) engine table -> init-db -> unsupported, no stamp', async () => {
  const rootConn = await connectAs('root', ROOT_PASSWORD);
  try {
    const dbName = await freshDatabase(rootConn);
    await applyFullSchema(rootConn);
    // Simulate a pre-baseline shape: drop a real manifest column so the
    // completeness comparison fails. No stamp is written.
    await rootConn.query(`ALTER TABLE \`${t(TABLES.USER_TEMPLATES)}\` DROP COLUMN flow_external_id`);
    assert.equal(await readStamp(rootConn), null, 'precondition: no stamp');

    const m = makeModule(dbName);
    const result = await m.runSchemaMigrations(rootConn, { context: 'init-db', steps: [] });

    assert.deepEqual(result, { unsupported: true }, 'guard fires in init-db context (not boot-gated)');
    assert.equal(await readStamp(rootConn), null, 'stamp NOT written onto an unstamped, incomplete schema');
  } finally {
    await rootConn.end();
  }
});

// ── Scenario 7 (Codex R2): unstamped COMPLETE schema via init-db (wizard) ───
// The Setup Wizard creates the full schema then calls runSchemaMigrations with
// {context:'init-db'} and no stamp yet. A COMPLETE schema is proven-current, so
// the guard MUST allow the run and the clean empty executor stamps it. This is
// the case that MUST keep working after the boot-gate removal.
test('scenario 7: unstamped COMPLETE schema (Setup Wizard) -> init-db -> stamp written', async () => {
  const rootConn = await connectAs('root', ROOT_PASSWORD);
  try {
    const dbName = await freshDatabase(rootConn);
    await applyFullSchema(rootConn); // complete manifest, no stamp
    assert.equal(await readStamp(rootConn), null, 'precondition: no stamp');

    const m = makeModule(dbName);
    const result = await m.runSchemaMigrations(rootConn, { context: 'init-db', steps: [] });

    assert.notDeepEqual(result, { unsupported: true }, 'complete unstamped schema is NOT unsupported');
    assert.equal(await readStamp(rootConn), BASELINE_SCHEMA_VERSION, 'stamp written for the wizard-complete schema');
  } finally {
    await rootConn.end();
  }
});

// ── Scenario 8 (fmb-1329 T11, closes fmb-0533): created_at NOT NULL backfill ─
// Exercises the REAL production custom steps (imported from migration-steps.js,
// not a fixture) against a legacy-shape DB: applyFullSchema() creates the
// CURRENT (already NOT NULL) schema, then the test ALTERs both created_at
// columns back to nullable to simulate a pre-T11 DB, seeds NULL + non-NULL
// rows, and proves the backfill is dirty-data-safe (NULLs -> NOW(), existing
// values untouched) and idempotent (second run issues no UPDATE/ALTER).
test('scenario 8: created_at NOT NULL backfill -> NULL rows filled, non-NULL untouched, idempotent re-run', async () => {
  const rootConn = await connectAs('root', ROOT_PASSWORD);
  try {
    const dbName = await freshDatabase(rootConn);
    await applyFullSchema(rootConn);

    const utTable = t(TABLES.USER_TEMPLATES);
    const frrTable = t(TABLES.FLOW_RECIPE_RUNS);
    // Simulate the pre-T11 (nullable) shape on a schema that otherwise
    // already matches the current baseline manifest.
    await rootConn.query(`ALTER TABLE \`${utTable}\` MODIFY COLUMN created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP`);
    await rootConn.query(`ALTER TABLE \`${frrTable}\` MODIFY COLUMN created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP`);

    const [{ id: utFixedId }] = await rootConn.query('SELECT UUID() AS id');
    await rootConn.query(`INSERT INTO \`${utTable}\` (id, created_at) VALUES (UUID(), NULL)`);
    await rootConn.query(`INSERT INTO \`${utTable}\` (id, created_at) VALUES (?, '2020-01-01 00:00:00')`, [utFixedId]);

    const [{ id: frrFixedId }] = await rootConn.query('SELECT UUID() AS id');
    await rootConn.query(
      `INSERT INTO \`${frrTable}\` (id, recipe_id, actor_id, status, created_at)
       VALUES (UUID(), UUID(), UUID(), 'success', NULL)`,
    );
    await rootConn.query(
      `INSERT INTO \`${frrTable}\` (id, recipe_id, actor_id, status, created_at)
       VALUES (?, UUID(), UUID(), 'success', '2020-01-01 00:00:00')`,
      [frrFixedId],
    );

    // Snapshot the fixed row's timestamp BEFORE migration so the "untouched"
    // assertion below compares against the driver's own round-trip value
    // (sidesteps server-timezone conversion — no hardcoded epoch expectation).
    const [utFixedBefore] = await rootConn.query(`SELECT created_at FROM \`${utTable}\` WHERE id = ?`, [utFixedId]);
    const [frrFixedBefore] = await rootConn.query(`SELECT created_at FROM \`${frrTable}\` WHERE id = ?`, [frrFixedId]);

    const utStep = MIGRATION_STEPS.find((s) => s.step === 'user_templates_created_at_not_null_backfill');
    const frrStep = MIGRATION_STEPS.find((s) => s.step === 'flow_recipe_runs_created_at_not_null_backfill');
    assert.ok(utStep && frrStep, 'both T11 backfill steps must exist in the production registry');

    const m = makeModule(dbName);
    const first = await m._runMigrationSteps(rootConn, [utStep, frrStep]);
    assert.equal(first.skippedSteps, 0, 'clean backfill is not accounted as skipped');

    const utRows = await rootConn.query(`SELECT id, created_at FROM \`${utTable}\``);
    assert.equal(utRows.some((r) => r.created_at === null), false, 'no NULL created_at rows remain');
    const utFixedAfter = utRows.find((r) => r.id === utFixedId);
    assert.equal(utFixedAfter.created_at.getTime(), utFixedBefore.created_at.getTime(),
      'pre-existing non-NULL created_at value untouched by the backfill');

    const frrRows = await rootConn.query(`SELECT id, created_at FROM \`${frrTable}\``);
    assert.equal(frrRows.some((r) => r.created_at === null), false, 'no NULL created_at rows remain');
    const frrFixedAfter = frrRows.find((r) => r.id === frrFixedId);
    assert.equal(frrFixedAfter.created_at.getTime(), frrFixedBefore.created_at.getTime(),
      'pre-existing non-NULL created_at value untouched by the backfill');

    const utNullable = await columnIsNullable(rootConn, utTable, 'created_at');
    const frrNullable = await columnIsNullable(rootConn, frrTable, 'created_at');
    assert.equal(utNullable, false, 'user_templates.created_at is NOT NULL after the backfill');
    assert.equal(frrNullable, false, 'flow_recipe_runs.created_at is NOT NULL after the backfill');

    // Idempotent re-run: the probe finds NOT NULL already and short-circuits
    // (unit-tested directly against a mocked conn in
    // migration-steps-created-at-backfill.test.js); here just prove it
    // completes cleanly against the real DB with no skips and no data churn.
    const second = await m._runMigrationSteps(rootConn, [utStep, frrStep]);
    assert.equal(second.skippedSteps, 0, 'idempotent re-run is not accounted as skipped');
    const utFixedAfterRerun = (await rootConn.query(`SELECT created_at FROM \`${utTable}\` WHERE id = ?`, [utFixedId]))[0];
    assert.equal(utFixedAfterRerun.created_at.getTime(), utFixedBefore.created_at.getTime(),
      'idempotent re-run does not alter existing values');
  } finally {
    await rootConn.end();
  }
});

// ── Scenario 9 (Codex R2, fmb-1329 PR2): CRUD-only remediation round-trip ────
// The acceptance test for this fix. A CRUD-only operator account cannot run the
// v3.2.579 destructive/custom batch; those steps are INVISIBLE to the
// missing-structure comparison (a drop leaves an EXTRA column; a NOT NULL
// backfill changes nullability), so before this fix the export rendered a no-op
// and the stamp could never advance. Proves the full loop:
//   1. legacy pre-3.2.579 shape + baseline stamp; CRUD-only boot = operator-mode
//      skip (preflight blocks DDL, stamp untouched);
//   2. pending_steps + export SQL derived READ-ONLY on the CRUD-only account;
//   3. a DBA applies the exported SQL via a privileged (root) account;
//   4. a direct step re-run on the CRUD-only account: every probe satisfied,
//      skippedSteps 0 (no spurious errno-1142);
//   5. a privileged reboot advances the stamp to 3.2.579 (spec §4.7 Q9 path).
test('scenario 9: CRUD-only remediation round-trip -> export SQL -> DBA applies -> probes satisfied -> privileged reboot stamps 3.2.579', async () => {
  const rootConn = await connectAs('root', ROOT_PASSWORD);
  let unprivConn;
  let unprivConn2;
  try {
    const dbName = await freshDatabase(rootConn);
    await applyFullSchema(rootConn);

    const utTable = t(TABLES.USER_TEMPLATES);
    const frrTable = t(TABLES.FLOW_RECIPE_RUNS);
    const acTable = t(TABLES.API_CONNECTORS);
    const frsTable = t(TABLES.FLOW_RECIPE_STEPS);
    const crTable = t(TABLES.CAP_RULES);
    const ssTable = t(TABLES.SYSTEM_SETTINGS);

    // Rewind to a legacy pre-3.2.579 shape so the real registry steps are all
    // pending: re-add the dropped columns + index, and MODIFY created_at back
    // to nullable with a NULL row to prove the backfill.
    await rootConn.query(`ALTER TABLE \`${acTable}\` ADD COLUMN allowed_hosts JSON NULL`);
    await rootConn.query(`ALTER TABLE \`${frsTable}\` ADD COLUMN allowed_hosts JSON NULL`);
    await rootConn.query(`ALTER TABLE \`${utTable}\` ADD COLUMN user_id CHAR(36) NULL DEFAULT NULL`);
    await rootConn.query(`ALTER TABLE \`${utTable}\` ADD INDEX idx_user_templates_user_draft (user_id, is_draft)`);
    await rootConn.query(`ALTER TABLE \`${utTable}\` MODIFY COLUMN created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP`);
    await rootConn.query(`ALTER TABLE \`${frrTable}\` MODIFY COLUMN created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP`);
    await rootConn.query(`INSERT INTO \`${utTable}\` (id, created_at) VALUES (UUID(), NULL)`);
    await rootConn.query(
      `INSERT INTO \`${frrTable}\` (id, recipe_id, actor_id, status, created_at)
       VALUES (UUID(), UUID(), UUID(), 'success', NULL)`,
    );

    await writeStamp(rootConn, BASELINE_SCHEMA_VERSION);

    const unprivUser = 'e2e_crud_only';
    const unprivPassword = 'e2e_crud_only_pw';
    await rootConn.query(`CREATE USER '${unprivUser}'@'%' IDENTIFIED BY '${unprivPassword}'`);
    await rootConn.query(`GRANT SELECT, INSERT, UPDATE, DELETE ON \`${dbName}\`.* TO '${unprivUser}'@'%'`);

    const unprivModule = makeModule(dbName, {
      PLATFORM_SCHEMA_VERSION,
      _configFull: { database: dbName, user: unprivUser },
    });

    // (1) CRUD-only boot: preflight lacks ALTER -> operator-mode skip, no DDL,
    // stamp untouched at baseline.
    unprivConn = await connectAs(unprivUser, unprivPassword, dbName);
    await unprivModule.runSchemaMigrations(unprivConn, { context: 'boot', steps: MIGRATION_STEPS });
    assert.equal(await readStamp(rootConn), BASELINE_SCHEMA_VERSION, 'CRUD-only boot leaves the stamp at baseline');
    assert.equal(await columnExists(rootConn, acTable, 'allowed_hosts'), true, 'no drop happened under CRUD-only');

    // (2) READ-ONLY derivation on the CRUD-only account (SELECT-only).
    const pendingNames = await derivePendingStepNames(unprivConn, t, MIGRATION_STEPS);
    assert.deepEqual(
      [...pendingNames].sort(),
      [
        'api_connectors_allowed_hosts_drop',
        'cap_rules_reconcile_default_template',
        'cap_rules_seed_standby_keep_in_one_site',
        'flow_recipe_runs_created_at_not_null_backfill',
        'flow_recipe_steps_allowed_hosts_drop',
        'user_templates_created_at_not_null_backfill',
        'user_templates_user_id_drop',
      ],
      'all five v3.2.579 steps plus the two cap_rules seed/reconcile steps are reported pending on the legacy shape',
    );

    const pendingSql = await derivePendingStepsSql(unprivConn, t, MIGRATION_STEPS);
    const joined = pendingSql.join('\n');
    assert.ok(pendingSql.length > 0, 'export SQL is non-empty');
    assert.ok(joined.includes(`ALTER TABLE \`${acTable}\` DROP COLUMN \`allowed_hosts\`;`), 'drops api_connectors.allowed_hosts');
    assert.ok(joined.includes(`ALTER TABLE \`${frsTable}\` DROP COLUMN \`allowed_hosts\`;`), 'drops flow_recipe_steps.allowed_hosts');
    assert.ok(joined.includes(`ALTER TABLE \`${utTable}\` DROP INDEX \`idx_user_templates_user_draft\`;`), 'drops the companion index first');
    assert.ok(joined.includes(`ALTER TABLE \`${utTable}\` DROP COLUMN \`user_id\`;`), 'drops user_templates.user_id');
    assert.ok(joined.includes('SET `created_at` = NOW() WHERE `created_at` IS NULL'), 'backfills NULL created_at');
    assert.ok(joined.includes('MODIFY COLUMN `created_at` TIMESTAMP NOT NULL'), 'aligns created_at NOT NULL');
    // DROP INDEX must precede DROP COLUMN for the composite index case.
    assert.ok(
      joined.indexOf(`DROP INDEX \`idx_user_templates_user_draft\``) <
        joined.indexOf(`ALTER TABLE \`${utTable}\` DROP COLUMN \`user_id\``),
      'DROP INDEX is emitted before DROP COLUMN',
    );
    // AR2-Q11: the CRUD-only export must also carry the cap_rules seed — the
    // empty-set branch (all 8 template rows), the standby-row guard, and the
    // system_settings marker upsert.
    assert.ok(joined.includes(`INSERT INTO \`${crTable}\` (id, scenario_id, type, name, level, group_by, params, severity, enabled)`),
      'exports the cap_rules seed INSERT');
    assert.ok(joined.includes(`WHERE NOT EXISTS (SELECT 1 FROM \`${crTable}\` WHERE scenario_id IS NULL)`),
      'the empty-set seed is guarded on the whole global set, not per-row');
    assert.ok(joined.includes(`type = 'keep-in-one-site' AND group_by = 'each_standby_cluster'`),
      'the standby row insert carries its own (type, group_by) guard');
    assert.ok(joined.includes(`INSERT INTO \`${ssTable}\` (\`key\`, value, description)`)
      && joined.includes('migration_seed_ar2q11_standby_rule'),
      'exports the AR2-Q11 seed-marker upsert');

    // (3) DBA applies the exported SQL via the privileged (root) account.
    for (const stmt of pendingSql) await rootConn.query(stmt);

    assert.equal(await columnExists(rootConn, acTable, 'allowed_hosts'), false, 'allowed_hosts dropped after apply');
    assert.equal(await columnExists(rootConn, utTable, 'user_id'), false, 'user_id dropped after apply');
    assert.equal(await columnIsNullable(rootConn, utTable, 'created_at'), false, 'user_templates.created_at is NOT NULL after apply');
    assert.equal(await columnIsNullable(rootConn, frrTable, 'created_at'), false, 'flow_recipe_runs.created_at is NOT NULL after apply');
    const utNulls = await rootConn.query(`SELECT COUNT(*) AS c FROM \`${utTable}\` WHERE created_at IS NULL`);
    assert.equal(Number(utNulls[0].c), 0, 'no NULL created_at rows remain after the backfill');

    // AR2-Q11: cap_rules started empty (applyFullSchema creates the table but
    // seeds no rows) -> the DBA-applied SQL took the empty-set branch and
    // inserted the FULL 8-row DEFAULT_RULE_TEMPLATE, plus the durable marker.
    const crRows = await rootConn.query(`SELECT type, group_by FROM \`${crTable}\` WHERE scenario_id IS NULL`);
    assert.equal(crRows.length, 8, 'the empty-set branch seeded the full 8-row template, not just the new row');
    assert.ok(
      crRows.some((r) => r.type === 'keep-in-one-site' && r.group_by === 'each_standby_cluster'),
      'the new standby keep-in-one-site row is present after DBA apply',
    );
    const markerRows = await rootConn.query(
      `SELECT value FROM \`${ssTable}\` WHERE \`key\` = 'migration_seed_ar2q11_standby_rule' LIMIT 1`,
    );
    assert.equal(markerRows.length, 1, 'the AR2-Q11 seed marker is written after DBA apply');
    const reconcileMarkerRows = await rootConn.query(
      `SELECT value FROM \`${ssTable}\` WHERE \`key\` = 'migration_reconcile_default_rule_template' LIMIT 1`,
    );
    assert.equal(reconcileMarkerRows.length, 1, 'the .814 default-rule-template reconcile marker is written after DBA apply');

    // (4) CRUD-only step re-run: every probe satisfied, no DDL attempted, zero
    // skips (no spurious errno-1142). Direct _runMigrationSteps mirrors the
    // idempotency scenarios (bypasses the preflight/version gate on purpose).
    unprivConn2 = await connectAs(unprivUser, unprivPassword, dbName);
    const converge = await unprivModule._runMigrationSteps(unprivConn2, MIGRATION_STEPS);
    assert.equal(converge.skippedSteps, 0, 'all steps satisfied on the CRUD-only account — zero skips');
    const pendingAfter = await derivePendingStepNames(unprivConn2, t, MIGRATION_STEPS);
    assert.deepEqual(pendingAfter, [], 'no steps remain pending after remediation');

    // (5) Privileged reboot advances the stamp (spec §4.7 Q9 convergence).
    const rootModule = makeModule(dbName, {
      PLATFORM_SCHEMA_VERSION,
      _configFull: { database: dbName, user: 'root' },
    });
    await rootModule.runSchemaMigrations(rootConn, { context: 'boot', steps: MIGRATION_STEPS });
    assert.equal(await readStamp(rootConn), PLATFORM_SCHEMA_VERSION, 'privileged reboot advances the stamp to 3.2.579');
  } finally {
    if (unprivConn) await unprivConn.end();
    if (unprivConn2) await unprivConn2.end();
    await rootConn.end();
  }
});

// ── Scenario 10 (3.2.598): the legacy is_locked / compute_rule translation ─
// The second exception to the fixture rule, for the same reason as scenario 8:
// what is under test is the production entry's own data mapping, not the
// executor's dispatch. Builds the PRE-3.2.598 shape (is_locked present, the two
// mode columns absent), seeds one row of each legacy combination, runs the three
// REAL registry entries in registry order, and asserts every combination
// survives — because the version that shipped without this step would have
// unlocked the locked rows and stopped the computed ones computing.
test('scenario 10: legacy is_locked/compute_rule survive the value_source migration', async () => {
  const rootConn = await connectAs('root', ROOT_PASSWORD);
  try {
    const dbName = await freshDatabase(rootConn);
    await applyFullSchema(rootConn);

    const bf = t(TABLES.BLUEPRINT_FIELDS);
    // Wind the table back to the pre-3.2.598 shape.
    await rootConn.query(`ALTER TABLE \`${bf}\` DROP COLUMN value_source`);
    await rootConn.query(`ALTER TABLE \`${bf}\` DROP COLUMN value_scope`);
    await rootConn.query(`ALTER TABLE \`${bf}\` ADD COLUMN is_locked TINYINT(1) NOT NULL DEFAULT 0`);

    const overridableRule = JSON.stringify({
      op: 'concat', overridable: true, output_type: 'string',
      config: { parts: [{ type: 'field', key: 'src' }], separator: '' },
    });
    const strictRule = JSON.stringify({
      op: 'concat', overridable: false, output_type: 'string',
      config: { parts: [{ type: 'field', key: 'src' }], separator: '' },
    });

    // The four legacy shapes, one row each.
    const seed = [
      ['f-neither', 'neither', 0, null],
      ['f-locked', 'locked_only', 1, null],
      ['f-rule', 'rule_only', 0, overridableRule],
      ['f-both', 'both', 1, overridableRule],
      // A fifth: a rule that was ALREADY non-overridable under a lock, so the
      // forced rewrite has nothing to change and must not corrupt it.
      ['f-both-strict', 'both_strict', 1, strictRule],
    ];
    for (const [id, key, locked, rule] of seed) {
      await rootConn.query(
        `INSERT INTO \`${bf}\` (id, blueprint_id, field_key, field_label, field_type, is_locked, compute_rule)
         VALUES (?, 'bp-1', ?, ?, 'text', ?, ?)`,
        [id, key, key, locked, rule],
      );
    }

    const before = await rootConn.query(
      `SELECT id, is_locked, compute_rule FROM \`${bf}\` ORDER BY id`,
    );
    console.log('BEFORE:', JSON.stringify(before.map((r) => ({
      id: r.id, is_locked: Number(r.is_locked), rule: r.compute_rule,
    }))));

    const steps = MIGRATION_STEPS.filter((s) => s.version === '3.2.598');
    assert.equal(steps.length, 4, 'add value_source, add value_scope, translate, drop is_locked');
    assert.deepEqual(
      steps.map((s) => s.step),
      [
        'blueprint_fields_value_source_add',
        'blueprint_fields_value_scope_add',
        'blueprint_fields_value_source_translate_legacy',
        'blueprint_fields_is_locked_drop',
      ],
      'the translation must sit between the adds and the drop',
    );

    const m = makeModule(dbName);
    const run = await m._runMigrationSteps(rootConn, steps);
    assert.equal(run.skippedSteps, 0, 'no step skipped');

    const after = await rootConn.query(
      `SELECT id, value_source, value_scope, compute_rule FROM \`${bf}\` ORDER BY id`,
    );
    const byId = new Map(after.map((r) => [r.id, r]));
    console.log('AFTER:', JSON.stringify(after.map((r) => ({
      id: r.id, value_source: r.value_source, rule: r.compute_rule,
    }))));

    const overridableOf = (raw) => JSON.parse(typeof raw === 'string' ? raw : JSON.stringify(raw)).overridable;

    assert.equal(byId.get('f-neither').value_source, 'entered');
    assert.equal(byId.get('f-neither').compute_rule, null);

    assert.equal(byId.get('f-locked').value_source, 'locked', 'a locked field must stay locked');
    assert.equal(byId.get('f-locked').compute_rule, null);

    assert.equal(byId.get('f-rule').value_source, 'calculated', 'a computed field must keep computing');
    assert.equal(overridableOf(byId.get('f-rule').compute_rule), true,
      'a rule that was overridable stays overridable — nothing locked that field');

    assert.equal(byId.get('f-both').value_source, 'calculated');
    assert.equal(overridableOf(byId.get('f-both').compute_rule), false,
      'locked AND computed becomes a non-overridable calculation — both properties kept');

    assert.equal(byId.get('f-both-strict').value_source, 'calculated');
    assert.equal(overridableOf(byId.get('f-both-strict').compute_rule), false);

    // The legacy column is gone, and every row is coherent by the write
    // boundary's own predicate — so the next save of any of them succeeds.
    const cols = await rootConn.query(
      `SELECT COLUMN_NAME FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = 'is_locked'`,
      [bf],
    );
    assert.equal(cols.length, 0, 'is_locked is dropped once its state has been carried across');
    const { checkValueSourcePayload } = require('../../src/shared/field-value-source');
    for (const row of after) {
      const issue = checkValueSourcePayload(
        { value_source: row.value_source, compute_rule: row.compute_rule, value_scope: row.value_scope },
        { fieldType: 'text', parseRule: (v) => (typeof v === 'string' ? JSON.parse(v) : v) },
      );
      assert.equal(issue, null, `${row.id} must be coherent: ${issue && issue.detail}`);
    }

    // Idempotent: a second run finds every probe satisfied and changes nothing.
    const again = await m._runMigrationSteps(rootConn, steps);
    assert.equal(again.skippedSteps, 0);
    const twice = await rootConn.query(`SELECT id, value_source FROM \`${bf}\` ORDER BY id`);
    assert.deepEqual(
      twice.map((r) => r.value_source),
      after.map((r) => r.value_source),
      'a re-run changes nothing',
    );
  } finally {
    await rootConn.end();
  }
});

// ── Scenario 11 (AR2 closeout): DEFAULT_RULE_TEMPLATE reconcile ─────────────
// The acceptance test for cap_rules_reconcile_default_template. A template row
// (`keep-apart / each_standby_cluster`) shipped a release early with no
// migration, so an upgraded non-empty global set is missing it. This runs the
// REAL production entry directly (like scenarios 8/10) — what's under test is
// the entry's own missing-row backfill + marker durability, not the executor's
// generic custom-kind dispatch. Covers the full decision table:
//   6-row pre-3.2.536 start -> 8; 7-row post-.807 start -> 8; empty -> 8;
//   operator-deleted-with-marker -> stays deleted; idempotent double-run.
test('scenario 11: reconcile inserts only MISSING template rows once, marker makes operator deletions durable', async () => {
  const { DEFAULT_RULE_TEMPLATE } = require('../../src/shared/capacity/rule-types');
  const RECONCILE_MARKER = 'migration_reconcile_default_rule_template';
  const rootConn = await connectAs('root', ROOT_PASSWORD);
  const step = MIGRATION_STEPS.find((s) => s.step === 'cap_rules_reconcile_default_template');
  assert.ok(step, 'the reconcile step is in the production registry');

  const STANDBY_KEEP_APART = { type: 'keep-apart', group_by: 'each_standby_cluster' };
  const STANDBY_KEEP_IN_ONE = { type: 'keep-in-one-site', group_by: 'each_standby_cluster' };
  const isRow = (id) => (r) => r.type === id.type && r.group_by === id.group_by;

  async function seedRows(conn, crTable, rows) {
    for (const row of rows) {
      await conn.query(
        `INSERT INTO \`${crTable}\` (id, scenario_id, type, name, level, group_by, params, severity, enabled)
         VALUES (UUID(), NULL, ?, ?, ?, ?, ?, ?, ?)`,
        [row.type, row.name, row.level, row.group_by, JSON.stringify(row.params || {}), row.severity, row.enabled ? 1 : 0],
      );
    }
  }
  async function globalRows(conn, crTable) {
    return conn.query(`SELECT type, group_by FROM \`${crTable}\` WHERE scenario_id IS NULL`);
  }
  async function markerPresent(conn, ssTable) {
    const rows = await conn.query(`SELECT value FROM \`${ssTable}\` WHERE \`key\` = ? LIMIT 1`, [RECONCILE_MARKER]);
    return rows.length > 0;
  }
  // A fresh DB + schema + module, returning the physical table names and module.
  async function freshCapRules() {
    const dbName = await freshDatabase(rootConn);
    await applyFullSchema(rootConn);
    return { crTable: t(TABLES.CAP_RULES), ssTable: t(TABLES.SYSTEM_SETTINGS), m: makeModule(dbName) };
  }

  try {
    // Case A — 6-row pre-3.2.536 start (missing BOTH standby rows) -> 8 rows.
    {
      const { crTable, ssTable, m } = await freshCapRules();
      const sixRows = DEFAULT_RULE_TEMPLATE.filter(
        (r) => !isRow(STANDBY_KEEP_APART)(r) && !isRow(STANDBY_KEEP_IN_ONE)(r),
      );
      assert.equal(sixRows.length, 6, 'the pre-3.2.536 template had 6 rows');
      await seedRows(rootConn, crTable, sixRows);
      const res = await m._runMigrationSteps(rootConn, [step]);
      assert.equal(res.skippedSteps, 0, 'reconcile does not skip on a privileged account');
      const after = await globalRows(rootConn, crTable);
      assert.equal(after.length, DEFAULT_RULE_TEMPLATE.length, 'the 6-row set is reconciled to the full template');
      assert.ok(after.some(isRow(STANDBY_KEEP_APART)), 'the never-migrated keep-apart standby row is inserted');
      assert.ok(after.some(isRow(STANDBY_KEEP_IN_ONE)), 'the keep-in-one-site standby row is inserted');
      assert.ok(await markerPresent(rootConn, ssTable), 'the reconcile marker is written');
    }

    // Case B — 7-row post-.807 start (missing ONLY keep-apart standby) -> 8.
    {
      const { crTable, ssTable, m } = await freshCapRules();
      const sevenRows = DEFAULT_RULE_TEMPLATE.filter((r) => !isRow(STANDBY_KEEP_APART)(r));
      assert.equal(sevenRows.length, 7, 'the post-.807 bugged set had 7 rows');
      await seedRows(rootConn, crTable, sevenRows);
      await m._runMigrationSteps(rootConn, [step]);
      const after = await globalRows(rootConn, crTable);
      assert.equal(after.length, 8, 'the 7-row set gains exactly the one missing row');
      assert.ok(after.some(isRow(STANDBY_KEEP_APART)), 'the single missing row is backfilled');
      assert.ok(await markerPresent(rootConn, ssTable), 'the reconcile marker is written');
    }

    // Case C — fresh empty global set -> full template.
    {
      const { crTable, ssTable, m } = await freshCapRules();
      await m._runMigrationSteps(rootConn, [step]);
      const after = await globalRows(rootConn, crTable);
      assert.equal(after.length, DEFAULT_RULE_TEMPLATE.length, 'an empty set is seeded to the full template');
      assert.ok(await markerPresent(rootConn, ssTable), 'the reconcile marker is written');
    }

    // Case D — operator-deleted-with-marker -> stays deleted (never resurrected).
    {
      const { crTable, ssTable, m } = await freshCapRules();
      await seedRows(rootConn, crTable, DEFAULT_RULE_TEMPLATE);
      await m._runMigrationSteps(rootConn, [step]); // writes the marker
      assert.ok(await markerPresent(rootConn, ssTable), 'first run wrote the marker');
      await rootConn.query(
        `DELETE FROM \`${crTable}\` WHERE scenario_id IS NULL AND type = ? AND group_by = ?`,
        [STANDBY_KEEP_APART.type, STANDBY_KEEP_APART.group_by],
      );
      await m._runMigrationSteps(rootConn, [step]); // marker present -> no re-seed
      const after = await globalRows(rootConn, crTable);
      assert.equal(after.length, DEFAULT_RULE_TEMPLATE.length - 1, 'a deletion after the marker is not resurrected');
      assert.ok(!after.some(isRow(STANDBY_KEEP_APART)), 'the operator-deleted row stays gone');
    }

    // Case E — idempotent double-run: no duplicate rows, one marker.
    {
      const { crTable, ssTable, m } = await freshCapRules();
      const sevenRows = DEFAULT_RULE_TEMPLATE.filter((r) => !isRow(STANDBY_KEEP_APART)(r));
      await seedRows(rootConn, crTable, sevenRows);
      await m._runMigrationSteps(rootConn, [step]);
      const first = await globalRows(rootConn, crTable);
      await m._runMigrationSteps(rootConn, [step]);
      const second = await globalRows(rootConn, crTable);
      assert.equal(second.length, first.length, 'a re-run inserts nothing more');
      assert.equal(second.length, 8, 'still the full template, no duplicates');
      const markerRows = await rootConn.query(
        `SELECT COUNT(*) AS c FROM \`${ssTable}\` WHERE \`key\` = ?`, [RECONCILE_MARKER],
      );
      assert.equal(Number(markerRows[0].c), 1, 'exactly one marker row');
    }

    // Case F — combined ordering: 6-row pre-3.2.536 start, FULL registry (both
    // .807 cap_rules_seed_standby_keep_in_one_site and .814
    // cap_rules_reconcile_default_template run in registry order, not the
    // isolated single-step harness the other cases use) -> 8 rows, no
    // duplicates. Proves the two steps compose instead of double-inserting the
    // keep-in-one-site row .807 already seeds before .814 reconciles the rest.
    {
      const { crTable, ssTable, m } = await freshCapRules();
      const sixRows = DEFAULT_RULE_TEMPLATE.filter(
        (r) => !isRow(STANDBY_KEEP_APART)(r) && !isRow(STANDBY_KEEP_IN_ONE)(r),
      );
      await seedRows(rootConn, crTable, sixRows);
      const res = await m._runMigrationSteps(rootConn, MIGRATION_STEPS);
      assert.equal(res.skippedSteps, 0, 'the full registry does not skip on a privileged account');
      const after = await globalRows(rootConn, crTable);
      assert.equal(after.length, DEFAULT_RULE_TEMPLATE.length, 'the full registry run reconciles the 6-row set to 8');
      const seen = new Set();
      for (const r of after) {
        const key = `${r.type}::${r.group_by}`;
        assert.ok(!seen.has(key), `no duplicate (type, group_by) row: ${key}`);
        seen.add(key);
      }
      assert.ok(after.some(isRow(STANDBY_KEEP_APART)), 'keep-apart standby row present after the full registry run');
      assert.ok(after.some(isRow(STANDBY_KEEP_IN_ONE)), 'keep-in-one-site standby row present after the full registry run');
      assert.ok(await markerPresent(rootConn, ssTable), 'the .814 reconcile marker is written by the full registry run');
    }

    // Case G — Codex P2: a stale exported remediationSql() script applied AFTER
    // the marker already exists must NOT resurrect an operator-deleted row. The
    // per-row guard in remediationSql() checks (type, group_by) row absence
    // ONLY — without a marker-absence predicate too it would re-insert the
    // deleted row, diverging from run()'s marker short-circuit.
    {
      const { crTable, ssTable, m } = await freshCapRules();
      await seedRows(rootConn, crTable, DEFAULT_RULE_TEMPLATE);
      await m._runMigrationSteps(rootConn, [step]); // writes the marker
      assert.ok(await markerPresent(rootConn, ssTable), 'marker written before the exported script is applied');
      await rootConn.query(
        `DELETE FROM \`${crTable}\` WHERE scenario_id IS NULL AND type = ? AND group_by = ?`,
        [STANDBY_KEEP_APART.type, STANDBY_KEEP_APART.group_by],
      );
      const statements = step.remediationSql(t);
      for (const stmt of statements) await rootConn.query(stmt);
      const after = await globalRows(rootConn, crTable);
      assert.equal(after.length, DEFAULT_RULE_TEMPLATE.length - 1, 'the exported script does not resurrect the deleted row');
      assert.ok(!after.some(isRow(STANDBY_KEEP_APART)), 'the operator-deleted row stays gone after the exported script');
    }
  } finally {
    await rootConn.end();
  }
});
