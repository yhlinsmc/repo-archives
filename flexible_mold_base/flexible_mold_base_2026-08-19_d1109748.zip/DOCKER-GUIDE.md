# Docker Guide for flexible_mold_base

A beginner-friendly guide to Docker concepts as used in this project.

---

## Why Docker?

Imagine shipping your application as a **shipping container** — everything it needs
(code, dependencies, runtime) is packed inside a standardized box. That box runs
identically on any machine that has Docker installed, whether it's your laptop,
a cloud server, or an air-gapped private network.

Without Docker, deploying means installing Node.js, copying files, running `npm install`,
configuring services, and hoping nothing conflicts. With Docker, you run one command
and get the exact same result every time.

---

## Key Concepts

### Image vs Container

- **Image**: A read-only blueprint (like a class). Built once with `docker build`.
- **Container**: A running instance of an image (like an object). Created with `docker run`.

You can run multiple containers from the same image. Stopping a container does not
delete it — you can restart it later.

### Bind Mount

A bind mount connects a folder on your host machine to a folder inside the container.
Changes in either location are reflected instantly — no copy step needed.

```
Host (WSL)                    Container
┌──────────────────┐         ┌──────────────────┐
│ /home/user/      │  bind   │ /workspace/      │
│   flexible_mold_base│ ──────> │   flexible_mold_base│
│     src/         │  mount  │     src/         │
│     docker-api/  │         │     docker-api/  │
└──────────────────┘         └──────────────────┘
     Edit here                 Changes appear
     (Claude Code,             instantly (Vite HMR
      VS Code)                 reloads browser)
```

This is how daily development works: you edit code on the host, and the DevContainer
sees the changes immediately.

### Environment Variables

Configuration values passed to a container at startup. They control behavior without
changing code:

```bash
DB_RW_HOST=192.168.1.100    # Where is the writer database?
DB_RW_PASSWORD=secret123    # How to authenticate against the writer?
NODE_ENV=production         # Production or development mode?
```

---

## Dockerfile Inventory

This project has two Dockerfiles:

### Root `Dockerfile` — Production Image

Used for: **ONPREM** and **AIRGAP** deployment.

Builds a single image used by both API-infra and API-edge (selected via `API_ROLE` env var):
1. Stage 1 (frontend-builder): Installs npm packages, runs `npm run build` to produce static files
2. Stage 2 (api-deps): Installs only Express API production dependencies
3. Stage 3 (runner): Copies the built frontend + API into a slim Node.js image

Result: One image, two roles. `API_ROLE=infra` serves frontend + auth + forwarding.
`API_ROLE=edge` serves DB routes via S2S authentication.

### `docker-api/Dockerfile` — API-Only Image

Used for: **CLOUD** deployment on Render.

Builds only the Express API server (no frontend). The frontend is hosted separately
by Lovable in CLOUD mode.

---

## Development Workflow (Daily)

For everyday development, you do NOT rebuild the Docker image. Instead:

0. **Open the DevContainer** in VS Code:
   - Press `Ctrl+Shift+P` > "Dev Containers: Reopen in Container"
   - VS Code opens a terminal inside the container
   - `docker-api/.env` is auto-created from `docker-api/.env.example` on first build

1. **Start the dev servers** (3 terminals inside the DevContainer):
   ```bash
   # Terminal 1: Frontend (Vite with hot-reload)
   npm run dev:local
   # Opens on https://localhost:3000

   # Terminal 2: API-edge (DB-facing, must start first)
   cd docker-api && API_ROLE=edge node src/index.js
   # Runs on http://localhost:3201 (edge reads EDGE_PORT, defaults to 3201)

   # Terminal 3: API-infra (frontend-facing, forwards to edge)
   cd docker-api && EDGE_API_URL=http://localhost:3201 node src/index.js
   # Runs on https://localhost:3200
   ```

   > **Note:** `S2S_API_KEY` must be set in `docker-api/.env` for infra/edge communication.
   > If not set, generate one: `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"`
   > and add `S2S_API_KEY=<value>` to `docker-api/.env`.

   > **Single-process mode (simpler):** If you only need API-infra without edge isolation,
   > just run `cd docker-api && node src/index.js`. It defaults to `API_ROLE=infra` and
   > falls back to direct DB access when edge is unreachable.

2. **Verify services are running:**
   ```bash
   curl -sk https://localhost:3200/health
   # Expected: {"api":"ok","role":"infra","db":"ok","auth_mode":"...","edge":"ok"}
   ```

3. **Edit code on the host** (Claude Code, VS Code, or any editor):
   - The bind mount syncs changes instantly to the container
   - Vite HMR reloads the browser automatically
   - No rebuild needed for code changes

4. **API Documentation** (interactive Scalar UI):
   - Frontend-facing: https://localhost:3200/api/docs
   - Edge-facing: http://localhost:3201/edge/docs

```
You edit src/App.tsx
       │
       ▼
Bind mount syncs to container
       │
       ▼
Vite detects change
       │
       ▼
Browser hot-reloads (~100ms)
```

---

## Production Verification (Milestone)

When you need to verify the production build (before deploying to AIRGAP):

```bash
# 1. Copy and configure production env
cp .env.production.example .env.production
# Edit: set BASE_IMAGE, DB_*, JWT_SECRET, S2S_API_KEY, SETTINGS_ENCRYPTION_KEY

# 2. Build and start dual-service production stack
docker compose up --build
# api-infra on :3200 (serves frontend + auth + forwarding)
# api-edge on :3201 (internal, DB access only)

# 3. Verify
curl http://localhost:3200/health
# Expected: {"api":"ok","role":"infra","db":"...","edge":"ok"}

# 4. Clean up
docker compose down
```

> **v2.0.0:** Production uses two containers from the same image. `API_ROLE=infra`
> serves the frontend and handles auth. `API_ROLE=edge` handles all DB operations.
> Both share `.env.production`. `S2S_API_KEY` must be set.

**When to do this:**
- Before transferring the image to the private network
- After major dependency updates
- When changing VITE_* environment variables (these are baked in at build time)

**You do NOT need to do this for:**
- Daily code changes (use `npm run dev` inside DevContainer instead)
- Runtime env var changes (just restart the container)

---

## DevContainer Setup

### ONPREM (Default)

The ONPREM DevContainer includes a MariaDB sidecar for local development:

```
.devcontainer/
├── Dockerfile.dev                       # Node 22 dev image
├── docker-compose.yml                   # Node 22 + MariaDB sidecar (base config)
├── .env                                 # Created from .env.example, gitignored
├── onprem/
│   ├── devcontainer.json                # VS Code config (ONPREM, default)
│   └── .env.example                     # Environment template
└── airgap/
    ├── devcontainer.json                # VS Code config (AIRGAP)
    ├── docker-compose.override.yml      # Override: proxy, root user, custom images
    └── .env.example                     # Environment template
```

**Setup:**
1. Copy `.devcontainer/onprem/.env.example` to `.devcontainer/.env`
2. Edit `.devcontainer/.env` — set `DB_ROOT_PASSWORD` and `DB_RW_PASSWORD` to your own values
3. Open project in VS Code
4. Click "Reopen in Container" when prompted (or `Ctrl+Shift+P` > Dev Containers)
5. Select `onprem` as the named configuration when prompted

> **Security**: The `.devcontainer/.env` file contains credentials and is gitignored.
> Docker Compose will **fail to start** if `.env` is missing — this is intentional
> to prevent accidental use of hardcoded defaults.

The MariaDB sidecar is optional — you can also connect to an external database
(e.g. Zeabur MariaDB) via the Setup Page in the app.

### AIRGAP

The AIRGAP DevContainer skips the MariaDB sidecar (MariaDB runs on the
private network separately):

**Setup:**
1. Copy `.devcontainer/airgap/.env.example` to `.devcontainer/.env`
2. Update `DEVCONTAINER_IMAGE` to match your private registry
3. Set `VSCODE_HTTP_PROXY` if needed
4. In VS Code, select `airgap` as the named configuration

> **Security**: All image names and credentials are loaded from `.devcontainer/.env` (gitignored).
> No defaults are embedded in the compose files — missing variables will cause startup failure.

**Key differences from ONPREM:**
- No MariaDB sidecar (connects to external DB on private network)
- `remoteUser: root` (matches internal deployment pattern)
- Proxy settings passed from host environment
- Docker image names are configurable for private registries

### How the Express API Finds the Database

The `.devcontainer/.env` file only configures the **MariaDB sidecar container itself**
(root password, database name, user credentials). It does NOT tell the Express API
where to connect. The API resolves its DB connection through a separate priority chain:

```
Priority 1: data/db-config.json   (written by Setup Wizard via POST /api/setup/configure-db)
         │
         ▼  not found?
Priority 2: docker-api/.env       (DB_RW_HOST, DB_RW_PORT, DB_RW_USER, DB_RW_PASSWORD, DB_NAME)
         │
         ▼  not found?
Priority 3: setup-required mode   (only /api/setup and /health respond; all other routes return 503)
```

**For daily DevContainer development, there are two approaches:**

| Approach | How | When to Use |
|----------|-----|-------------|
| **Setup Wizard** (recommended) | Start API, open `http://localhost:3000/setup`, fill DB credentials in Step 2 | First time, or when switching databases |
| **docker-api/.env** file | Create `docker-api/.env` with `DB_RW_HOST=mariadb`, `DB_RW_PORT=3306`, etc. | Automated/repeatable setup |

When using the MariaDB sidecar, the DB host is `mariadb` (Docker Compose service name),
not `localhost`. Example `docker-api/.env`:

```env
DB_RW_HOST=mariadb
DB_RW_PORT=3306
DB_RW_USER=appuser
DB_RW_PASSWORD=<same as DB_RW_PASSWORD in .devcontainer/.env>
DB_NAME=app_db
DB_TABLE_PREFIX=
JWT_SECRET=<generate with: openssl rand -hex 32>
```

Once the API connects successfully, the config is saved to `docker-api/data/db-config.json`
and persists across restarts (Priority 1).

---

## Environment Comparison

| | CLOUD | ONPREM | AIRGAP |
|---|-----------|-------------|-----------------|
| **Host OS** | Any (Lovable hosted) | Windows WSL (Ubuntu 24.04) | Ubuntu 22.04 (isolated) |
| **Auth** | Supabase Auth | Local JWT / Keycloak OIDC | Local JWT / Keycloak OIDC |
| **Database** | Supabase PostgreSQL + optional MariaDB | MariaDB (sidecar or external) | MariaDB (external, private network) |
| **Frontend hosting** | Lovable Publish | Vite dev server / Docker | Docker container |
| **API hosting** | Render (Express) | DevContainer / Docker | Docker container |
| **Internet required** | Yes | Optional | No |
| **Docker image naming** | N/A | Default (`node:22-bookworm`) | Custom registry (`registry.internal/...`) |
| **Proxy** | No | No | Yes (HTTP_PROXY, HTTPS_PROXY) |

---

## AIRGAP Variables

For air-gapped environments, all Docker image names and network settings must be
configurable. See `.devcontainer/airgap/.env.example`:

```env
# Custom Docker images (private registry)
DEVCONTAINER_IMAGE=registry.internal/devtools/node:22-bookworm

# Proxy (for VS Code Server)
VSCODE_HTTP_PROXY=http://proxy.internal:80
```

---

## Common Operations

### Rebuild the DevContainer
```bash
# In VS Code: Ctrl+Shift+P > "Dev Containers: Rebuild Container"
# Or from terminal (from project root):
cd .devcontainer && docker compose build --no-cache
```

### Update the base image
```bash
docker pull node:22-bookworm
docker pull mariadb:10.11
# Then rebuild the DevContainer
```

### Transfer image to air-gapped network
```bash
# Build
docker build -t flexible_mold_base:latest .

# Export
docker save flexible_mold_base:latest | gzip > flexible_mold_base.tar.gz

# Transfer via USB, SCP, or internal file server

# On the target machine:
docker load < flexible_mold_base.tar.gz
docker run -d --name flexible_mold_base -p 3200:3200 --env-file .env flexible_mold_base:latest
```

### View container logs
```bash
docker logs flexible_mold_base          # All logs
docker logs -f flexible_mold_base       # Follow (live tail)
docker logs --tail 50 flexible_mold_base  # Last 50 lines
```

### Shell into a running container
```bash
docker exec -it flexible_mold_base bash
```

### Check container health
```bash
curl http://localhost:3200/health
# Expected: {"api":"ok","role":"infra","db":"ok","auth_mode":"...","edge":"ok"}
```

### Reset everything (nuclear option)
```bash
# Stop and remove containers + volumes (deletes all MariaDB data)
docker compose down -v

# Remove the image
docker rmi flexible_mold_base:latest
```
