'use strict';

/**
 * aggregate.js — the run history read as groups rather than as rows.
 *
 * WHY THIS IS NOT THE GENERIC CRUD FACTORY. The factory reads rows; this surface
 * reads GROUPS — one row per template, carrying a count and the run that
 * describes it — and no aggregation is expressible through it. The factory
 * gained pagination for this feature; it did not gain grouping, and teaching it
 * to aggregate would put a query planner in the module every table in the
 * application is served by.
 *
 *   GET /groups                one row per template, most recent activity first
 *   GET /groups/:groupId/runs  that group's runs, newest first
 *   GET /runs/:runId           one run in full, for the row detail
 *
 * All three read under the rule in `visibility.js` — currently no restriction at
 * all, for every authenticated caller — applied to the counts as well as to the
 * rows, so the two can never disagree about how much exists.
 *
 * WHY A GROUP CAN HAVE NO TEMPLATE. `template_id` is nullable and nothing
 * deletes a run when its template goes, so three kinds of group arrive here: a
 * template that exists, a template id that no longer resolves, and runs recorded
 * with no template at all. All three keep their runs — a deleted template is not
 * a reason to lose the record of what it dispatched. Which of them a second-level
 * request names is decided by `group-id.js`, whose identifiers carry their kind
 * so that the third can never be reached by a value of the first two.
 */
const express = require('express');
const { pool, t } = require('../../../db');
const {
  requireAuth, apiOk, apiError, UUID_RE,
} = require('../../../../shared/helpers');
const { TABLES } = require('../../../../shared/constants');
const { mapRowsFromDb, normalizeTimestamp } = require('../../../lib/dto-mapper');
const { attachOwnerNames } = require('../../../lib/owner-name-enrichment');
const { normalizeRows } = require('../../../../shared/serializers/normalize-nullable');
const { logger: rootLogger } = require('../../../../shared/lib/logger');
const { parsePageRequest } = require('../schema/list-query');
const { buildRunVisibility } = require('./visibility');
const { decodeGroupId, NO_TEMPLATE_GROUP } = require('./group-id');
const { attachInputDiff, readSnapshot } = require('./input-diff');
const {
  buildGroupsSql, buildGroupCountSql, buildGroupFacetActorsSql, buildGroupFilterPredicate,
  buildTemplateByIdSql,
  buildGroupRunsSql, buildGroupRunsCountSql, buildRunDetailSql, groupPredicate,
  DEFAULT_GROUP_SORT, isGroupSortField,
} = require('./run-queries');

const logger = rootLogger.child({ module: 'edge-flow-run-history' });

const router = express.Router();

// SECURITY: authentication for the whole router rather than per handler. None of
// this is public — being signed in is the whole of the read rule, which makes
// this gate the only thing standing between the history and an anonymous
// caller. It is placed here so a route added later inherits it instead of having
// to remember it.
router.use((req, res, next) => { if (requireAuth(req, res)) next(); });

/** The page a caller gets when they ask for no particular page. Well under the
 *  shared ceiling: this table grows with dispatches, so an unbounded default
 *  would be an unbounded read of it. */
const DEFAULT_PAGE_SIZE = 50;

const dbError = (res) => {
  const e = apiError('Database operation failed', 'INTERNAL_ERROR', 500);
  res.status(e.status).json(e.body);
};

/**
 * The page these routes serve, validated by the shared list layer's own parser
 * so a page position has one spelling across the application.
 *
 * Unlike the generic list read, a page is ALWAYS applied here — an unpaged read
 * of an execution-scale table is what this feature exists to stop. A caller that
 * supplies neither bound gets the default page; a caller that supplies a limit
 * without a position is asking for the first page, and is answered as such
 * rather than having the limit quietly dropped.
 */
function resolvePage(query) {
  const q = query || {};
  if (q.offset === undefined && q.limit === undefined) {
    return { paginated: true, limit: DEFAULT_PAGE_SIZE, offset: 0 };
  }
  return parsePageRequest({ ...q, offset: q.offset === undefined ? '0' : q.offset });
}

function pageError(res, page) {
  const e = apiError(page.error.message, page.error.code, 400);
  res.status(e.status).json(e.body);
}

/** Rename the shared owner enrichment's output to the column it was run for.
 *  A run's actor is not an owner, and calling the field `owner_name` on a row
 *  that has no owner column invites a reader to act on it as one.
 *
 *  Exported for the sibling router that reads a run's recorded answers: both
 *  surfaces name the same person and a second copy of this renaming would let
 *  one of them start calling the field something else. The dependency runs one
 *  way — that module requires this one, never the reverse — so the mount order
 *  in `index.js` stays the only thing that decides which router sees a path
 *  first. */
async function attachActorNames(conn, rows, actorColumn, prefix) {
  await attachOwnerNames(conn, rows, actorColumn, `\`${t(TABLES.USERS)}\``);
  for (const row of rows) {
    if (!row) continue;
    row[`${prefix}_name`] = row.owner_name ?? '';
    row[`${prefix}_username`] = row.owner_username ?? '';
    delete row.owner_name;
    delete row.owner_username;
  }
  return rows;
}

// ── Level one: one row per template ─────────────────────────────────────────

/**
 * The order a caller asked for, reduced to a name this module recognises.
 *
 * The name is looked up in the statement builder's own table, so nothing the
 * caller sends is interpolated; an unrecognised name falls back to the default
 * rather than being refused, because an ordering is a presentation choice and a
 * page of history is still the right answer under the wrong one.
 */
function resolveSort(query) {
  const q = query || {};
  const field = isGroupSortField(q.sort) ? q.sort : DEFAULT_GROUP_SORT.field;
  const dir = q.order === 'asc' || q.order === 'desc' ? q.order : DEFAULT_GROUP_SORT.dir;
  return { field, dir };
}

/** The outcomes a run can end in — mirrors the `flow_recipe_runs.status` ENUM.
 *  A value outside this set names nothing, so it is DROPPED rather than sent
 *  to the statement, the same rule an unrecognised `sort` follows: a filter is
 *  a presentation choice, and a page of history is still the right answer
 *  under one the caller mistyped. */
const VALID_OUTCOMES = new Set(['success', 'partial', 'failed']);

/** `YYYY-MM-DD`, the one shape `from`/`to` are accepted in. */
const ISO_DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

/** A comma-separated id list, reduced to the entries that are actually a UUID.
 *  An id that is not one names nothing in the hierarchy this filters on and is
 *  dropped rather than reaching the statement — the query stays parameterized
 *  either way, but a caller who mistyped one id among several keeps the ones
 *  that were real instead of losing the whole filter to it. */
function parseIdList(raw) {
  if (typeof raw !== 'string' || raw.trim() === '') return [];
  return raw.split(',').map((s) => s.trim()).filter((s) => UUID_RE.test(s));
}

/** A single string query value. Express turns a repeated key into an array;
 *  a filter is not a field a caller can widen by repeating it, so an array
 *  here names nothing rather than being joined into one. */
function single(v) {
  return typeof v === 'string' ? v : undefined;
}

/**
 * The `/groups` filter parameters, validated to the shapes `run-queries.js`
 * trusts. Every field defaults to "no filter" rather than to a refusal, the
 * same rule `resolveSort` follows and `resolvePage` deliberately does not: a
 * malformed page silently served is a caller reading the wrong slice without
 * knowing it, but a dropped filter just widens the result to "unfiltered on
 * that field" — a fact the count and the rows both show, not one hidden from
 * the caller.
 */
function resolveFilters(query) {
  const q = query || {};
  const search = single(q.search);
  const outcome = single(q.outcome);
  const actor = single(q.actor);
  const from = single(q.from);
  const to = single(q.to);
  return {
    search: search && search.trim() !== '' ? search.trim() : null,
    category: parseIdList(single(q.category)),
    release: parseIdList(single(q.release)),
    blueprint: parseIdList(single(q.blueprint)),
    variant: parseIdList(single(q.variant)),
    outcome: outcome && VALID_OUTCOMES.has(outcome) ? outcome : null,
    actor: actor && UUID_RE.test(actor) ? actor : null,
    from: from && ISO_DATE_RE.test(from) ? from : null,
    to: to && ISO_DATE_RE.test(to) ? to : null,
  };
}

router.get('/groups', async (req, res) => {
  const page = resolvePage(req.query);
  if (page.error) return pageError(res, page);
  const sort = resolveSort(req.query);
  const filterPred = buildGroupFilterPredicate(resolveFilters(req.query));

  const visibility = buildRunVisibility(req.user, 'r');
  try {
    const conn = await pool.ro.getConnection();
    try {
      const rows = await conn.query(
        buildGroupsSql(visibility.sql, sort, filterPred),
        [...visibility.params, ...filterPred.params, page.limit, page.offset],
      );
      const totalRows = await conn.query(
        buildGroupCountSql(visibility.sql, filterPred),
        [...visibility.params, ...filterPred.params],
      );

      const shaped = rows.map((row) => {
        // A group whose template id no longer resolves keeps its place and is
        // reported as such: the runs happened, and hiding them because their
        // template was deleted would lose history the row itself still holds.
        const exists = row.template_row_id != null;
        return {
          // Y-pattern carve-out, same class as `parent_id`: NULL is a state of
          // its own here — runs recorded with no template — and coalescing it to
          // '' would make that group indistinguishable from a template whose id
          // happens to be empty.
          template_id: row.template_id ?? null,
          template_name: exists ? row.template_name : '',
          template_exists: exists,
          blueprint_id: exists ? row.template_blueprint_id : null,
          variant_id: exists ? row.template_variant_id : null,
          run_count: Number(row.run_count) || 0,
          last_run_at: normalizeTimestamp(row.last_run_at),
          last_run_id: row.last_run_id,
          last_status: row.last_status,
          last_actor_id: row.last_actor_id,
        };
      });
      await attachActorNames(conn, shaped, 'last_actor_id', 'last_actor');

      return res.json(apiOk({
        rows: normalizeRows(shaped, ['template_name', 'blueprint_id', 'variant_id', 'last_run_at']),
        total: Number(totalRows[0].cnt) || 0,
        limit: page.limit,
        offset: page.offset,
        sort: sort.field,
        order: sort.dir,
      }));
    } finally {
      conn.release();
    }
  } catch (err) {
    logger.error({ err }, 'Failed to list flow run groups');
    return dbError(res);
  }
});

/**
 * The "run by" facet: every actor who has a run this caller may see, read
 * under the same visibility rule as `/groups` so the picker never offers a
 * name that would filter the list down to nothing this caller can read.
 *
 * The category/release/blueprint/variant facets are NOT served here — the
 * hierarchy tree is already fetched whole by every page that reads it
 * (`useAllHierarchyNodes`), so a second, narrower copy of it would be a
 * second thing to keep in sync with the first rather than a new fact this
 * route knows.
 */
router.get('/groups/facets', async (req, res) => {
  const visibility = buildRunVisibility(req.user, 'r');
  try {
    const conn = await pool.ro.getConnection();
    try {
      const rows = await conn.query(buildGroupFacetActorsSql(visibility.sql), visibility.params);
      const actorRows = rows.map((row) => ({ id: row.actor_id }));
      await attachActorNames(conn, actorRows, 'id', 'actor');
      const actors = actorRows.map((row) => ({
        id: row.id, name: row.actor_name, username: row.actor_username,
      }));
      return res.json(apiOk({ actors: normalizeRows(actors, ['name', 'username']) }));
    } finally {
      conn.release();
    }
  } catch (err) {
    logger.error({ err }, 'Failed to list flow run facets');
    return dbError(res);
  }
});

// ── Level two: one group's runs ─────────────────────────────────────────────

/** Read the page with the additive snapshot column, falling back to the column
 *  set a database that warn-skipped the ALTER actually has. */
async function readRunPage(conn, visibility, group, page) {
  const params = [...group.params, ...visibility.params, page.limit + 1, page.offset];
  try {
    const rows = await conn.query(
      buildGroupRunsSql(visibility.sql, group.sql, { withSnapshot: true }), params,
    );
    return { rows, hasSnapshotColumn: true };
  } catch (err) {
    if (!(err && (err.errno === 1054 || err.code === 'ER_BAD_FIELD_ERROR'))) throw err;
    const rows = await conn.query(
      buildGroupRunsSql(visibility.sql, group.sql, { withSnapshot: false }), params,
    );
    return { rows, hasSnapshotColumn: false };
  }
}

/**
 * The template a second-level page is headed by, when it still exists.
 *
 * WHY THIS ONE READ IS BUILT WITHOUT THE VISIBILITY PREDICATE, deliberately, and
 * would stay that way if the rule narrowed. It reads the template's own row —
 * its name and its place in the hierarchy — not any run, so the run boundary is
 * not what governs it. A template's name is already readable by every
 * authenticated caller from the templates list itself, which carries no user
 * scope by design; withholding it here would hide nothing and would leave the
 * page unable to say what its runs are runs OF.
 */
async function readGroupMeta(conn, templateId) {
  const absent = {
    template_id: templateId,
    template_name: '',
    template_exists: false,
    blueprint_id: null,
    variant_id: null,
  };
  if (templateId === null) return absent;
  const rows = await conn.query(buildTemplateByIdSql(), [templateId]);
  if (!rows.length) return absent;
  return {
    template_id: rows[0].id,
    template_name: rows[0].name,
    template_exists: true,
    blueprint_id: rows[0].blueprint_id,
    variant_id: rows[0].variant_id,
  };
}

router.get('/groups/:groupId/runs', async (req, res) => {
  // The segment is an IDENTIFIER, not a template id: it carries which kind of
  // group it names, so a template whose id happens to spell the no-template
  // group's word cannot address that group's runs. See `group-id.js`.
  const parsedGroup = decodeGroupId(req.params.groupId);
  if (!parsedGroup.ok) {
    const e = apiError('Unknown run group', 'NOT_FOUND', 404);
    return res.status(e.status).json(e.body);
  }
  const page = resolvePage(req.query);
  if (page.error) return pageError(res, page);

  const visibility = buildRunVisibility(req.user, 'r');
  const group = groupPredicate(parsedGroup.templateId);
  try {
    const conn = await pool.ro.getConnection();
    try {
      // One row PAST the page, so the oldest row on it is compared against the
      // run before it rather than reported as the first run of the template.
      // That row is a comparison partner only: it belongs to the next page and
      // is never returned.
      const { rows, hasSnapshotColumn } = await readRunPage(conn, visibility, group, page);
      const mapped = mapRowsFromDb('flow_recipe_runs', rows);
      const pageRows = mapped.slice(0, page.limit);
      const lookahead = mapped.length > page.limit ? mapped[page.limit] : undefined;

      const totalRows = await conn.query(
        buildGroupRunsCountSql(visibility.sql, group.sql),
        [...group.params, ...visibility.params],
      );

      const shaped = attachInputDiff(pageRows, lookahead, { hasSnapshotColumn });
      await attachActorNames(conn, shaped, 'actor_id', 'actor');
      const groupMeta = await readGroupMeta(conn, parsedGroup.templateId);

      return res.json(apiOk({
        // `started_at` / `finished_at` are nullable timestamps the DTO mapper
        // leaves as NULL; the list prints a placeholder for an empty one, so
        // they cross the boundary as '' with the rest of the nullable display
        // fields rather than as a second absent-value spelling.
        rows: normalizeRows(shaped, [
          'input_diff_reason', 'blueprint_id', 'started_at', 'finished_at',
        ]),
        total: Number(totalRows[0].cnt) || 0,
        limit: page.limit,
        offset: page.offset,
        group: normalizeRows([groupMeta], ['template_name', 'blueprint_id', 'variant_id'])[0],
      }));
    } finally {
      conn.release();
    }
  } catch (err) {
    logger.error({ err, groupId: req.params.groupId }, 'Failed to list runs for a flow run group');
    return dbError(res);
  }
});

// ── One run in full ─────────────────────────────────────────────────────────

/** Read one run with the additive columns, falling back to the set a database
 *  that warn-skipped their ALTER actually has. The two are dropped together:
 *  MariaDB names only the first missing column, so telling them apart would mean
 *  parsing the error text. */
async function readRunDetail(conn, visibilitySql, params) {
  try {
    const rows = await conn.query(buildRunDetailSql(visibilitySql, { withAdditive: true }), params);
    return { rows, hasAdditive: true };
  } catch (err) {
    if (!(err && (err.errno === 1054 || err.code === 'ER_BAD_FIELD_ERROR'))) throw err;
    const rows = await conn.query(buildRunDetailSql(visibilitySql, { withAdditive: false }), params);
    return { rows, hasAdditive: false };
  }
}

router.get('/runs/:runId', async (req, res) => {
  const notFound = () => {
    const e = apiError('Run not found', 'NOT_FOUND', 404);
    return res.status(e.status).json(e.body);
  };
  if (!UUID_RE.test(String(req.params.runId))) return notFound();

  const visibility = buildRunVisibility(req.user, 'r');
  const params = [req.params.runId, ...visibility.params];
  try {
    const conn = await pool.ro.getConnection();
    try {
      const { rows, hasAdditive } = await readRunDetail(conn, visibility.sql, params);
      // A run the caller may not read is reported as absent rather than as
      // refused: answering "not yours" over an id confirms the run exists.
      if (!rows.length) return notFound();

      const [row] = mapRowsFromDb('flow_recipe_runs', rows);
      // The captured document itself is NOT returned. Nothing on this screen
      // renders it, and it is the one column on the row whose size is bounded
      // only by its own limit. What the detail states is whether the answers
      // were recorded at all — a fact about this run alone, unlike the list's
      // indicator, which is a comparison with the run before it.
      const rest = Object.fromEntries(
        Object.entries(row).filter(([k]) => k !== 'input_snapshot'),
      );
      const detail = {
        ...rest,
        recipe_name: row.recipe_name ?? '',
        // Explicitly null on the degraded tier rather than absent: the column
        // is not in that statement, and a key the client has to tell apart from
        // a real value by its absence is a second spelling of "not recorded".
        code_version: hasAdditive ? (row.code_version ?? null) : null,
        input_capture: hasAdditive ? readSnapshot(row.input_snapshot).state : 'absent',
      };
      await attachActorNames(conn, [detail], 'actor_id', 'actor');
      return res.json(apiOk(normalizeRows([detail], ['recipe_name', 'blueprint_id'])[0]));
    } finally {
      conn.release();
    }
  } catch (err) {
    logger.error({ err, runId: req.params.runId }, 'Failed to read a flow run');
    return dbError(res);
  }
});

module.exports = {
  router, NO_TEMPLATE_GROUP, DEFAULT_PAGE_SIZE, attachActorNames,
};
