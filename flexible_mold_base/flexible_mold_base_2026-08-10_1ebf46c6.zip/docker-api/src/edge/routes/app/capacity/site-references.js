'use strict';

/**
 * site-references.js — everything that still points at a data centre, produced
 * ONCE.
 *
 * THE QUESTION THIS ASKS. Not "does a row exist that names this site" but "does
 * a reference to this site still RESOLVE" — resolve the way the code that reads
 * it resolves it. The two are different for `cap_databases.dc_refs`, which
 * stores whatever spelling the caller typed: every reader of that column
 * (`dcRefsAdmitsSite`'s `dcRefs.includes(siteId)`, the placement candidate
 * filter, the health check's `Set.has`) compares byte-for-byte, so an entry
 * spelled with different case admits nothing, restricts nothing and blocks
 * nothing. `JSON_CONTAINS(col, JSON_QUOTE(?))` is that same byte comparison,
 * which is why the probe below uses it rather than a folding one: a folding
 * probe here would refuse a delete over a reference no reader can follow, and
 * the entry it refused for would still be dangling afterwards. Such an entry is
 * not a live reference — it is a broken one, and the scenario health check is
 * what reports it.
 *
 * The scalar `site_id` columns are the opposite case and need no help: they are
 * `CHAR(36)` under the schema's folding collation and `= ?` is the same
 * comparison every statement that reads them makes.
 *
 * ONE SWEEP, TWO CALLERS. The delete-impact preview the operator sees and the
 * refusal the DELETE issues are the SAME object: this function's return value.
 * Neither caller counts anything of its own, so there is no second query set for
 * the preview to disagree with — which is the defect this shape exists to make
 * unreachable, not a property two tests happen to assert the same number for.
 *
 * WHAT IT DOES NOT CLOSE. `dc_refs` is not a declared reference on the write
 * side, so a `cap_databases` write adding this site to a restriction list does
 * not lock the `cap_sites` row the delete holds, and the two can therefore
 * interleave: a restriction naming a site can be committed inside the window
 * between this sweep and the DELETE. Declaring `dc_refs` a validated reference
 * is what would close it, and that is a change to the write path (and to what
 * the column is allowed to store), not to this one. The dangling entry it can
 * leave is exactly what the scenario health check reports.
 */

const { t } = require('../../../db');
const { TABLES } = require('../../../../shared/constants');

// The affected-name list is bounded per group so a large estate cannot balloon
// the response; the COUNT beside it is always exact, so a caller can render an
// honest "+N more".
const NAME_LIST_CAP = 20;

/**
 * The kinds of reference this sweep covers, and what a delete does about each.
 *
 * IT IS NOT EVERYTHING THAT CAN NAME A SITE, and "the three kinds" would be the
 * sentence a later change got built on. A `keep-in-one-site` rule stores a site
 * id inside `cap_rules.params` (`params.site_id`, read by the evaluator), and
 * that one is outside this sweep: not swept, not blocked, not cleared, not
 * reported. Measured on MariaDB 10.11 — with such a rule in place, deleting the
 * pinned data centre returns 200 and the rule goes on emitting the same HARD
 * violation, now naming a site that no longer exists ("must stay on the pinned
 * site but occupies 1 site(s)"), which no placement can satisfy and no health
 * check reports. Adding a kind here means first deciding what a delete owes a
 * rule it makes unsatisfiable — a different question from the three below, each
 * of which has an obvious answer.
 *
 * `disposition` is the whole contract:
 *   'block'   — the reference cannot be rewritten, so the delete is refused while
 *               it exists. A `dc_refs` entry cannot be scrubbed because an EMPTY
 *               list means "all data centres" (placement-dc-candidates.ts), so
 *               removing the last id would silently widen a database from "only
 *               these DCs" to "any DC" — the same rule that keeps a disk combo
 *               out of a profile allow-list from being scrubbed. The operator
 *               edits those restriction lists by hand (spec §4 Q21).
 *   'unplace' — the reference is nullable and NULL is a meaningful state, so the
 *               delete clears it. `cap_vms.site_id` on an unplaced VM is the
 *               operator's INTENDED site; when the site goes away the intent has
 *               nowhere left to point, and the VM returns to "no intended DC".
 *   'cascade' — the reference is an OWNED child, deleted with the site (spec §4
 *               Q20). `cap_hypervisors.site_id` is NOT NULL and a hypervisor is
 *               meaningless without a data centre, so the delete removes each
 *               hypervisor — first applying the hypervisor's OWN delete behavior
 *               (its VMs return to the tray, `hypervisor_id` NULL). This replaces
 *               the earlier `block` (409 refusal), a user-approved reversal.
 *
 * The unplace statement's own WHERE clause is built from this entry, so the
 * number the preview reports for that group is the number of rows the UPDATE
 * changes — not an estimate of it.
 */
const SITE_REFERENCE_GROUPS = Object.freeze([
  Object.freeze({
    kind: 'hypervisor',
    disposition: 'cascade',
    table: TABLES.CAP_HYPERVISORS,
    column: 'site_id',
    nameCol: 'name',
    label: 'Hypervisors placed here',
    singular: 'hypervisor placed here',
    plural: 'hypervisors placed here',
  }),
  Object.freeze({
    kind: 'vm',
    disposition: 'unplace',
    table: TABLES.CAP_VMS,
    column: 'site_id',
    nameCol: 'name',
    label: 'VMs pinned to this datacenter',
    singular: 'VM pinned to this datacenter',
    plural: 'VMs pinned to this datacenter',
  }),
  Object.freeze({
    kind: 'database_dc_ref',
    disposition: 'block',
    table: TABLES.CAP_DATABASES,
    column: 'dc_refs',
    nameCol: 'function_name',
    // A JSON list of site ids rather than a scalar column, so the probe is a
    // containment test. See the byte-comparison note at the top of the file.
    jsonList: true,
    label: 'Databases restricted to this datacenter',
    singular: 'database restricted to this datacenter',
    plural: 'databases restricted to this datacenter',
  }),
]);

/**
 * The WHERE fragment + bound value that decides whether a row of `group`
 * references `siteId`. Shared by the count, the name list and (for the unplace
 * groups) the statement that clears the column — one predicate, so a row cannot
 * be counted by one and missed by another.
 *
 * JSON_VALID guards the probe, not the data: MariaDB declares a JSON column with
 * a `json_valid` CHECK so ordinary writes cannot store non-JSON, but a table
 * created before that constraint can hold text the JSON functions raise on, and
 * a DELETE that 500s because of an unrelated row is a worse answer than the
 * refusal it was computing.
 */
function referencePredicate(group) {
  return group.jsonList
    ? `\`${group.column}\` IS NOT NULL AND JSON_VALID(\`${group.column}\`)`
      + ` AND JSON_CONTAINS(\`${group.column}\`, JSON_QUOTE(?))`
    : `\`${group.column}\` = ?`;
}

/** The value the predicate binds. JSON_QUOTE takes the id as text. */
function referenceValue(group, siteId) {
  return group.jsonList ? String(siteId) : siteId;
}

/**
 * Every reference to `siteId` within `scenarioId`, grouped by kind.
 *
 * `dbHandle` is either a pool (the read-only preview) or an open write
 * transaction's connection (the delete) — both answer `.query`.
 *
 * `siteId` MUST BE THE SPELLING THE ROW HOLDS, not the one a URL carried. The
 * scalar probes fold case and would not notice, but the `dc_refs` probe is a
 * byte comparison: given a respelled id it finds nothing in a restriction list
 * holding the stored one, and the delete that should have been refused goes
 * through. Each caller resolves it for itself because the two need different
 * reads — the delete already holds the row FOR UPDATE and reuses that row, and
 * a read-only preview must not take that lock. A mechanical check that both
 * still pass a stored value lives in capacity-site-delete-one-source.test.js.
 *
 * @returns {Promise<{groups: Array, total: number, blocked: boolean}>}
 */
async function sweepSiteReferences(dbHandle, scenarioId, siteId) {
  const groups = [];
  // The exact scenario-scoped predicate each group counted with, handed back so a
  // caller that MERGES zones (the delete-impact preview) can OR this together with
  // a nested reference against the same table and let the database dedupe by row —
  // one source, since the predicate here is the same one this sweep counts with.
  // Kept OFF `groups` so it never rides into the 409 payload (`details.references`).
  const predicates = [];
  for (const group of SITE_REFERENCE_GROUPS) {
    const predicate = referencePredicate(group);
    const value = referenceValue(group, siteId);
    predicates.push({
      kind: group.kind,
      table: group.table,
      where: `scenario_id = ? AND ${predicate}`,
      params: [scenarioId, value],
    });
    const countRows = await dbHandle.query(
      `SELECT COUNT(*) AS c FROM \`${t(group.table)}\` WHERE scenario_id = ? AND ${predicate}`,
      [scenarioId, value],
    );
    const count = Number(countRows[0].c);
    let names = [];
    if (count > 0) {
      // nameCol/column come from the frozen declaration above (never
      // request-derived), so the interpolated identifiers are safe; the values
      // are still bound.
      const rows = await dbHandle.query(
        `SELECT id, \`${group.nameCol}\` AS name FROM \`${t(group.table)}\``
        + ` WHERE scenario_id = ? AND ${predicate} ORDER BY \`${group.nameCol}\` LIMIT ?`,
        [scenarioId, value, NAME_LIST_CAP],
      );
      names = rows.map((r) => ({ id: r.id, name: r.name == null ? '' : String(r.name) }));
    }
    groups.push({
      kind: group.kind,
      disposition: group.disposition,
      label: group.label,
      count,
      names,
    });
  }
  const total = groups.reduce((sum, g) => sum + g.count, 0);
  return {
    groups,
    predicates,
    total,
    // The refusal, decided here so both callers read one answer rather than each
    // deriving one.
    blocked: groups.some((g) => g.disposition === 'block' && g.count > 0),
  };
}

/** English, no first person: what the operator has to clear first. */
function siteDeleteRefusalMessage(sweep) {
  const parts = sweep.groups
    .filter((g) => g.disposition === 'block' && g.count > 0)
    .map((g) => {
      const noun = SITE_REFERENCE_GROUPS.find((d) => d.kind === g.kind);
      return `${g.count} ${g.count === 1 ? noun.singular : noun.plural}`;
    });
  const listed = parts.length > 1
    ? `${parts.slice(0, -1).join(', ')} and ${parts[parts.length - 1]}`
    : parts[0];
  return `Cannot delete this datacenter while it is still referenced by ${listed}`;
}

/**
 * The delete behaviour declaration for the sites mount. `groups` is the SAME
 * frozen list the sweep reads, so the require-time coverage check, the unplace
 * statement and the refusal all describe one reference set.
 */
const SITE_REFERENCE_SWEEP = Object.freeze({
  groups: SITE_REFERENCE_GROUPS,
  run: sweepSiteReferences,
  refusalMessage: siteDeleteRefusalMessage,
});

module.exports = {
  SITE_REFERENCE_GROUPS,
  SITE_REFERENCE_SWEEP,
  NAME_LIST_CAP,
  sweepSiteReferences,
  siteDeleteRefusalMessage,
  referencePredicate,
  referenceValue,
};
