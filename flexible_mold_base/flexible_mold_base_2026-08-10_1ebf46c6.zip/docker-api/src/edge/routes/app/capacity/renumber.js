/**
 * @openapi
 * /edge/app/capacity/scenarios/{scenarioId}/renumber-preview:
 *   post:
 *     tags: [App - Capacity]
 *     summary: Preview the old→new hostname renumber for a scenario (admin+editor).
 *     description: >
 *       Spec B5 Q18/Q20. Read-only. Recomputes every hypervisor / KVM-host /
 *       AP-VM name from the scenario's EFFECTIVE naming patterns (scenario
 *       override → global → built-in defaults) in current `order_index` display
 *       order, and returns the full old→new list. No writes.
 *     parameters:
 *       - { name: scenarioId, in: path, required: true, schema: { type: string } }
 *     responses:
 *       200: { description: "The old→new plan: [{ id, entityType, oldName, newName, tooLong, duplicate }]" }
 *       403: { description: Not the scenario owner (and not admin), or a plain user }
 *       404: { description: Scenario not found }
 * /edge/app/capacity/scenarios/{scenarioId}/renumber:
 *   post:
 *     tags: [App - Capacity]
 *     summary: Apply the hostname renumber for a scenario in one transaction (admin+editor).
 *     description: >
 *       Spec B5 Q18. Recomputes names server-side (never trusts a client-sent
 *       name), enforces scenario-wide per-entity-type uniqueness, and writes
 *       every changed name in ONE transaction — any duplicate rolls the whole
 *       apply back (409), nothing is written. Drag reorder never renames; this
 *       explicit action is the only path that re-sequences names.
 *     parameters:
 *       - { name: scenarioId, in: path, required: true, schema: { type: string } }
 *     responses:
 *       200: { description: "Applied: { applied, renamed: [{ id, entityType, oldName, newName }] }" }
 *       403: { description: Not the scenario owner (and not admin), or a plain user }
 *       404: { description: Scenario not found }
 *       409: { description: The computed names collide within an entity type — nothing applied }
 */

/**
 * capacity/renumber.js — the explicit Renumber toolbar action (spec B5b). Two
 * POST routes on the scenario: a read-only preview and a transactional apply.
 *
 * Numbering (fork-2, wizard-consistent, computeRenumberPlan in
 * shared/capacity/name-patterns.js): group each entity type by its resolved {dc}
 * slug (a {dc}-free pattern = one scenario-wide group), seq 1..k in order_index
 * order, pad width = max(declared, digits(groupCount)). Hand-edited names are
 * renumbered like any other — that is the point of the action.
 *
 * CONCURRENCY. The PRIMARY protection is scenario-row serialization: apply locks
 * cap_scenarios FOR UPDATE first (resolveScenarioWriteAccess), and every other
 * same-scenario writer (placement-apply, reorder, the child CRUD) does the same,
 * so two writers of the same scenario never run their row writes concurrently at
 * all. The SECONDARY, defence-in-depth guard is per-row lock order: each entity
 * table is locked in ONE unfiltered `ORDER BY id FOR UPDATE` pass per scenario —
 * ascending primary-key order, the same order placement-apply's compareMove
 * takes on the shared cap_vms rows — so even absent the scenario-row lock the
 * per-row acquisition order could not invert. cap_vms carries BOTH kvm_host
 * (db_host) and ap_vm (ap_host) rows; it is locked ONCE unfiltered and split by
 * vm_type in JS AFTER the lock — a per-vm_type filtered scan would take its
 * locks in two id-monotonic-but-interleaved passes, breaking that single
 * ascending order. The display-order sort (order_index, id) that drives seq is
 * applied in JS after the locks are taken in id order.
 */
const express = require('express');
const { pool, t } = require('../../../db');
const { requireAdminOrEditor, apiOk, apiError } = require('../../../../shared/helpers');
const { logger } = require('../../../../shared/lib/logger');
const { TABLES } = require('../../../../shared/constants');
const {
  siteSlug, computeRenumberPlan, firstDuplicateName, duplicateNameFlags, firstOverlengthName,
  resolveEffectiveNamePatterns,
} = require('../../../../shared/capacity/name-patterns');
const { resolveScenarioWriteAccess, safeRollback, tableColumnSet } = require('./_shared');

// The name column is VARCHAR(255) on BOTH cap_hypervisors and cap_vms
// (table-ddls.js). A computed hostname must fit the SMALLER limit (they are equal
// at 255); pinned against a DDL change by the renumber schema-parity test.
const MAX_HOSTNAME_LENGTH = 255;

// The renumberable entity types (spec B5), grouped by TABLE so each table is
// read/locked exactly ONCE (cap_vms carries two entity types, split by vm_type
// after the single lock pass). `vmType` NULL = the whole table is one entity
// type; otherwise it filters that table's rows in JS. `label` is used only in
// the 409 message; `patternKey` selects the entity's pattern from the resolved
// effective set.
const RENUMBER_TABLES = [
  {
    table: TABLES.CAP_HYPERVISORS,
    hasVmType: false,
    entities: [{ entityType: 'hypervisor', vmType: null, patternKey: 'hypervisor', label: 'hypervisor' }],
  },
  {
    table: TABLES.CAP_VMS,
    hasVmType: true,
    entities: [
      { entityType: 'kvm_host', vmType: 'db_host', patternKey: 'kvm_host', label: 'KVM host' },
      { entityType: 'ap_vm', vmType: 'ap_host', patternKey: 'ap_vm', label: 'application VM' },
    ],
  },
];

/** Parse a name_patterns JSON column value: the driver may hand back a parsed
 *  object or the raw JSON string (C3). null/blank/`null` → null (inherited). */
function parseNamePatterns(raw) {
  if (raw === null || raw === undefined) return null;
  if (typeof raw === 'string') {
    const trimmed = raw.trim();
    if (trimmed === '' || trimmed === 'null') return null;
    try { return JSON.parse(trimmed); } catch { return null; }
  }
  if (typeof raw === 'object' && !Array.isArray(raw)) return raw;
  return null;
}

/**
 * Resolve the scenario's EFFECTIVE naming patterns from cap_settings: its own
 * override row (scenario_id = the scenario) wins, else the global row
 * (scenario_id IS NULL), else the built-in defaults — the SAME tier chain the FE
 * placement prefill resolves, via the shared resolveEffectiveNamePatterns.
 */
async function resolveEffectivePatterns(dbHandle, scenarioId) {
  // Degraded-schema guard (C1, READ side): a warn-skipped name_patterns migration
  // (no DDL privilege) leaves the column ABSENT — a direct SELECT of it would 500
  // both preview and apply. Probe the physical column set via the WRITER pool
  // (never let an RO replica's lagging absence get cached — B5a R2-2) and, when
  // the column is missing, resolve to the built-in defaults: with no column there
  // are no stored overrides anywhere to read. An empty/odd probe (no `id`) is
  // treated as "unknown, assume present" and falls through, mirroring
  // dropAbsentColumns' fail-safe.
  const settingsCols = await tableColumnSet(pool.rw, TABLES.CAP_SETTINGS);
  if (settingsCols.has('id') && !settingsCols.has('name_patterns')) {
    return resolveEffectiveNamePatterns(null, null);
  }
  const scenRows = await dbHandle.query(
    `SELECT scenario_id, name_patterns FROM \`${t(TABLES.CAP_SETTINGS)}\` WHERE scenario_id = ?`,
    [scenarioId],
  );
  const globalRows = await dbHandle.query(
    `SELECT scenario_id, name_patterns FROM \`${t(TABLES.CAP_SETTINGS)}\` WHERE scenario_id IS NULL LIMIT 1`,
  );
  const scenarioRow = scenRows.length
    ? { scenario_id: scenRows[0].scenario_id, name_patterns: parseNamePatterns(scenRows[0].name_patterns) }
    : null;
  const globalRow = globalRows.length
    ? { scenario_id: globalRows[0].scenario_id, name_patterns: parseNamePatterns(globalRows[0].name_patterns) }
    : null;
  return resolveEffectiveNamePatterns(scenarioRow, globalRow);
}

/** scenario site-id → site name (for the {dc} slug). One read, no lock. */
async function readSiteNames(dbHandle, scenarioId) {
  const rows = await dbHandle.query(
    `SELECT id, name FROM \`${t(TABLES.CAP_SITES)}\` WHERE scenario_id = ?`,
    [scenarioId],
  );
  const byId = new Map();
  for (const r of rows) byId.set(r.id, r.name);
  return byId;
}

/**
 * Read one TABLE's rows (unfiltered — one pass), shaped for computeRenumberPlan.
 * For the APPLY path (`lock`) the scan is a single `ORDER BY id FOR UPDATE`
 * (canonical lock order); display order (order_index, id) is imposed in JS
 * afterward. For PREVIEW the DB orders by (order_index, id) directly (no lock).
 * `vm_type` is carried when the table has it so the caller can split entity types
 * in JS without a second scan.
 */
async function readTableRows(dbHandle, scenarioId, table, hasVmType, siteNames, { lock }) {
  const cols = hasVmType
    ? 'id, name, order_index, site_id, vm_type'
    : 'id, name, order_index, site_id';
  const order = lock ? 'ORDER BY id FOR UPDATE' : 'ORDER BY order_index, id';
  const raw = await dbHandle.query(
    `SELECT ${cols} FROM \`${t(table)}\` WHERE scenario_id = ? ${order}`,
    [scenarioId],
  );
  const rows = raw.map((r) => ({
    id: r.id,
    name: r.name,
    order_index: Number(r.order_index) || 0,
    vm_type: hasVmType ? r.vm_type : null,
    // Unplaced (site_id NULL, or a dangling id not in the scenario's sites) → ''
    // slug → the {dc}-free group (computeRenumberPlan strips {dc} there).
    dcSlug: r.site_id && siteNames.has(r.site_id) ? siteSlug(siteNames.get(r.site_id)) : '',
  }));
  if (lock) {
    // Locks were taken in id order above; now impose display order for seq.
    rows.sort((a, b) => (a.order_index - b.order_index) || (a.id < b.id ? -1 : a.id > b.id ? 1 : 0));
  }
  return rows;
}

/** Split a table's rows into its entity types (by vm_type) and compute each
 *  type's plan, tagging every plan item with its entityType. */
function plansForTable(tableSpec, rows, patterns) {
  return tableSpec.entities.map((entity) => {
    const entityRows = entity.vmType ? rows.filter((r) => r.vm_type === entity.vmType) : rows;
    const plan = computeRenumberPlan(entityRows, patterns[entity.patternKey]);
    return { entity, table: tableSpec.table, plan };
  });
}

const router = express.Router();

// POST preview — read-only. Admin+editor (the toolbar action is canWrite-gated),
// but takes NO lock (a RO handle must not FOR UPDATE).
router.post('/scenarios/:scenarioId/renumber-preview', async (req, res) => {
  if (!requireAdminOrEditor(req, res)) return;
  const scenarioId = req.params.scenarioId;
  try {
    const access = await resolveScenarioWriteAccess(pool.ro, scenarioId, req.user, { lock: false });
    if (!access.found) {
      const e = apiError('Scenario not found', 'NOT_FOUND', 404);
      return res.status(e.status).json(e.body);
    }
    if (!access.allowed) {
      const e = apiError('Not the scenario owner', 'FORBIDDEN', 403);
      return res.status(e.status).json(e.body);
    }
    const patterns = await resolveEffectivePatterns(pool.ro, scenarioId);
    const siteNames = await readSiteNames(pool.ro, scenarioId);
    const preview = [];
    for (const tableSpec of RENUMBER_TABLES) {
      const rows = await readTableRows(pool.ro, scenarioId, tableSpec.table, tableSpec.hasVmType, siteNames, { lock: false });
      for (const { entity, plan } of plansForTable(tableSpec, rows, patterns)) {
        // Same fold, same scope as apply's firstDuplicateName gate (the full
        // per-entity-type newNames list, ALL rows incl. unchanged ones) — every
        // colliding row is flagged (fmb-1649), not just the second occurrence,
        // so the dialog can block Confirm before the user reaches apply's
        // deterministic 409 (same input → same collision, no retry escapes it).
        const dupFlags = duplicateNameFlags(plan.map((p) => p.newName));
        plan.forEach((item, idx) => {
          preview.push({
            id: item.id,
            entityType: entity.entityType,
            oldName: item.oldName,
            newName: item.newName,
            // Surface an over-limit name BEFORE apply (Codex R2 P2-2): the dialog
            // flags the row and blocks confirm, so the user shortens the pattern
            // rather than hitting the apply-time 409.
            tooLong: item.newName.length > MAX_HOSTNAME_LENGTH,
            duplicate: dupFlags[idx],
          });
        });
      }
    }
    res.json(apiOk(preview));
  } catch (err) {
    logger.error({ err, scenarioId }, `Failed to preview capacity renumber for scenario id=${scenarioId}`);
    const e = apiError('Database operation failed', 'INTERNAL_ERROR', 500);
    res.status(e.status).json(e.body);
  }
});

// POST apply — one transaction. Recompute server-side, enforce per-entity-type
// uniqueness, write every CHANGED name, whole rollback on any duplicate.
router.post('/scenarios/:scenarioId/renumber', async (req, res) => {
  if (!requireAdminOrEditor(req, res)) return;
  const scenarioId = req.params.scenarioId;

  let conn;
  try {
    conn = await pool.rw.getConnection();
    await conn.beginTransaction();

    const access = await resolveScenarioWriteAccess(conn, scenarioId, req.user);
    if (!access.found) {
      await safeRollback(conn);
      const e = apiError('Scenario not found', 'NOT_FOUND', 404);
      return res.status(e.status).json(e.body);
    }
    if (!access.allowed) {
      await safeRollback(conn);
      const e = apiError('Not the scenario owner', 'FORBIDDEN', 403);
      return res.status(e.status).json(e.body);
    }

    const patterns = await resolveEffectivePatterns(conn, scenarioId);
    const siteNames = await readSiteNames(conn, scenarioId);

    // Phase 1: lock each TABLE once (ascending id) and compute every entity
    // type's plan. No write yet — the uniqueness gate must clear for ALL types
    // first so a conflict in a later type still rolls the earlier types back.
    const allPlans = [];
    for (const tableSpec of RENUMBER_TABLES) {
      const rows = await readTableRows(conn, scenarioId, tableSpec.table, tableSpec.hasVmType, siteNames, { lock: true });
      for (const planned of plansForTable(tableSpec, rows, patterns)) {
        const newNames = planned.plan.map((p) => p.newName);
        const dup = firstDuplicateName(newNames);
        if (dup !== null) {
          await safeRollback(conn);
          const e = apiError(
            `Renumber would create a duplicate ${planned.entity.label} name "${dup}" — no changes applied. Adjust the ${planned.entity.label} naming pattern and retry.`,
            'CONFLICT', 409,
          );
          return res.status(e.status).json(e.body);
        }
        // Over-limit guard (Codex R2 P2-2): a long site slug + pattern prefix can
        // compute a name past the VARCHAR(255) column — reject the whole apply
        // (a strict INSERT would 500, a lax one would truncate) on the same
        // rollback-before-any-write path as the duplicate guard.
        const tooLong = firstOverlengthName(newNames, MAX_HOSTNAME_LENGTH);
        if (tooLong !== null) {
          await safeRollback(conn);
          const e = apiError(
            `Renumber would create a ${planned.entity.label} name longer than ${MAX_HOSTNAME_LENGTH} characters ("${tooLong.slice(0, 40)}…") — no changes applied. Shorten the ${planned.entity.label} naming pattern or the site name and retry.`,
            'CONFLICT', 409,
          );
          return res.status(e.status).json(e.body);
        }
        allPlans.push(planned);
      }
    }

    // Phase 2: write only the CHANGED rows (case-sensitive compare so a case-only
    // rename is still applied). Uniqueness already cleared for every type.
    const renamed = [];
    for (const { entity, table, plan } of allPlans) {
      for (const item of plan) {
        if (item.newName === item.oldName) continue;
        await conn.query(
          `UPDATE \`${t(table)}\` SET name = ? WHERE id = ? AND scenario_id = ?`,
          [item.newName, item.id, scenarioId],
        );
        renamed.push({
          id: item.id, entityType: entity.entityType, oldName: item.oldName, newName: item.newName,
        });
      }
    }

    await conn.commit();
    res.json(apiOk({ applied: renamed.length, renamed }));
  } catch (err) {
    await safeRollback(conn);
    logger.error({ err, scenarioId }, `Failed to apply capacity renumber for scenario id=${scenarioId}`);
    const e = apiError('Database operation failed', 'INTERNAL_ERROR', 500);
    res.status(e.status).json(e.body);
  } finally {
    if (conn) conn.release();
  }
});

module.exports = router;
