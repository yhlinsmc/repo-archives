/**
 * name-patterns.js — server-side mirror of the FE hostname-pattern contract
 * (spec B5a). The FE (src/fmb/capacity/lib/hostname-pattern.ts) is the single
 * NAME FORMATTER; this module carries only the two pieces the server needs —
 * the built-in DEFAULT_NAME_PATTERNS and the all-or-nothing validation — so a
 * settings write can reject a malformed pattern set with a 400 (the input-
 * boundary gate, commander fork-1 ruling). CJS/TS cannot share a module, so the
 * defaults + validation are duplicated here and held to the FE copy by a parity
 * test (the repo's standard cross-runtime triple-mirror discipline).
 */

/** Built-in defaults — MUST stay byte-identical to the FE DEFAULT_NAME_PATTERNS. */
const DEFAULT_NAME_PATTERNS = Object.freeze({
  hypervisor: 'hv-{dc}-{seq:2}',
  kvm_host: 'kvm-{dc}-{seq:2}',
  ap_vm: 'ap-{seq:2}',
});

const NAME_PATTERN_ENTITIES = Object.freeze([
  { key: 'hypervisor', label: 'Hypervisor' },
  { key: 'kvm_host', label: 'KVM host' },
  { key: 'ap_vm', label: 'Application VM' },
]);

const SEQ_MAX_WIDTH = 12;
// Length + token-count caps (Review FIX-1, ReDoS): the FE nextSeq builds a regex
// from a stored pattern; hundreds of {seq} groups make it backtrack for seconds.
// MUST stay in lockstep with the FE validateHostnamePattern caps.
const MAX_PATTERN_LENGTH = 64;
const MAX_TOKEN_GROUPS = 8;
const TOKEN_GROUP_RE = /\{[^{}]*\}/g;
const KNOWN_TOKEN_RE = /^(dc|seq(?::(\d+))?)$/;
const SEQ_GROUP_RE = /^\{seq(?::\d+)?\}$/;
const SEQ_TOKEN_RE = /^seq(?::\d+)?$/;
const DC_TOKEN_RE = /\{dc\}/;

/**
 * All-or-nothing validation of ONE pattern string. Returns an error message or
 * null. Mirrors the FE validateHostnamePattern (caps + require-{seq} in lockstep).
 * @param {unknown} pattern
 * @returns {string|null}
 */
function validatePattern(pattern) {
  if (typeof pattern !== 'string') return 'must be text';
  if (pattern.trim().length === 0) return 'must not be empty';
  if (pattern.length > MAX_PATTERN_LENGTH) return `must be at most ${MAX_PATTERN_LENGTH} characters`;
  const groups = pattern.match(TOKEN_GROUP_RE) || [];
  if (groups.length > MAX_TOKEN_GROUPS) return `must have at most ${MAX_TOKEN_GROUPS} tokens`;
  for (const group of groups) {
    const inner = group.slice(1, -1);
    const match = KNOWN_TOKEN_RE.exec(inner);
    if (!match) return `has an unknown token "${group}" (use {dc}, {seq} or {seq:N})`;
    if (match[2] !== undefined) {
      const width = Number(match[2]);
      if (!(width >= 1 && width <= SEQ_MAX_WIDTH)) {
        return `zero-pad width in "${group}" must be between 1 and ${SEQ_MAX_WIDTH}`;
      }
    }
  }
  // A pattern with no {seq} (Review FIX-3) generates identical names — reject it
  // at the boundary (the FE wizard's free-text path stays lenient).
  if (!groups.some((group) => SEQ_GROUP_RE.test(group))) return 'must include a {seq} sequence token';
  if (/[{}]/.test(pattern.replace(TOKEN_GROUP_RE, ''))) return 'has an unbalanced { or }';
  return null;
}

/**
 * Validate a whole name_patterns write value. A null/absent value is valid
 * (inherited). A non-null value MUST be a plain object carrying a valid pattern
 * for every entity type — a single bad entry rejects the WHOLE set (vendor-config
 * lesson). Returns an error message or null.
 * @param {unknown} value
 * @returns {string|null}
 */
function validateNamePatternsWrite(value) {
  if (value === null || value === undefined) return null;
  // The settings route sends a parsed object; the config-import path sends the
  // JSON column as a string (C3). Accept both — parse a string first so an import
  // is held to the same all-or-nothing rules and cannot bypass the boundary.
  let obj = value;
  if (typeof obj === 'string') {
    const trimmed = obj.trim();
    if (trimmed === '' || trimmed === 'null') return null; // blank/null cell = inherited
    try { obj = JSON.parse(trimmed); } catch { return 'name_patterns must be a valid JSON object or null'; }
    if (obj === null) return null;
  }
  if (typeof obj !== 'object' || Array.isArray(obj)) {
    return 'name_patterns must be an object or null';
  }
  value = obj;
  // Exact key-set (Review FIX-6): an extra key would persist verbatim into the
  // JSON column, and a missing one would store a half-set. MUST match the FE
  // validateNamePatterns check.
  const expected = NAME_PATTERN_ENTITIES.map((entity) => entity.key);
  const keys = Object.keys(value);
  if (keys.length !== expected.length
    || !expected.every((key) => Object.prototype.hasOwnProperty.call(value, key))) {
    return `name_patterns must contain exactly: ${expected.join(', ')}`;
  }
  for (const { key, label } of NAME_PATTERN_ENTITIES) {
    const err = validatePattern(value[key]);
    if (err) return `name_patterns.${key} (${label}) ${err}`;
  }
  return null;
}

// ── Name-construction mirror (spec B5b, Renumber apply) ──────────────────────
// The FE (hostname-pattern.ts) stays the single NAME FORMATTER for the browser;
// the Renumber APPLY path recomputes names server-side (it must never trust a
// client-sent name), so the formatting + effective-pattern-resolution primitives
// are mirrored here and held BYTE-IDENTICAL to the FE by a behavioral parity test
// (name-patterns-mirror-parity.test.ts). CJS/TS cannot share a module, so this is
// the repo's standard cross-runtime mirror discipline — there is ONE server copy,
// not a per-route third copy.

/** A site name → a {dc} slug (`DC-1` → `dc1`). Mirrors the FE siteSlug. */
function siteSlug(name) {
  return String(name == null ? '' : name).toLowerCase().replace(/[^a-z0-9]+/g, '');
}

function renderSeq(spec, seq) {
  const match = /^seq(?::(\d+))?$/.exec(spec);
  const width = match && match[1] !== undefined ? Number(match[1]) : 1;
  return String(Math.max(0, Math.floor(seq))).padStart(width, '0');
}

/** Construct ONE name. LENIENT: {dc} → ctx.dc, {seq}/{seq:N} → padded seq, any
 *  other {token} left verbatim (fork-1 ruling). Mirrors the FE formatHostname. */
function formatHostname(pattern, ctx) {
  return String(pattern).replace(TOKEN_GROUP_RE, (token) => {
    const inner = token.slice(1, -1);
    if (inner === 'dc') return ctx.dc;
    if (SEQ_TOKEN_RE.test(inner)) return renderSeq(inner, ctx.seq);
    return token;
  });
}

/** Widen the seq token's zero-pad to fit a whole batch: W = max(declared, digits
 *  of count). Mirrors the FE withBatchSeqWidth. */
function withBatchSeqWidth(pattern, count) {
  const need = String(Math.max(0, Math.floor(count))).length;
  return String(pattern).replace(/\{seq(?::(\d+))?\}/g, (_token, declaredWidth) => {
    const declared = declaredWidth !== undefined ? Number(declaredWidth) : 1;
    return `{seq:${Math.max(declared, need)}}`;
  });
}

/** Drop the {dc} token (plus one adjacent literal separator) so an unplaced
 *  entity proposes `kvm-{seq:2}`, not a dangling `kvm--01`. Mirrors the FE. */
function patternWithoutDc(pattern) {
  return String(pattern)
    .replace(/\{dc\}[-_.:/]/, '')
    .replace(/[-_.:/]\{dc\}/, '')
    .replace(/\{dc\}/, '');
}

/** Resolve a stored name_patterns value (whole-set override, or null = inherited)
 *  to a full set, filling built-in defaults per field. Mirrors the FE. */
function resolveNamePatterns(raw) {
  if (!raw) return { ...DEFAULT_NAME_PATTERNS };
  return {
    hypervisor: raw.hypervisor || DEFAULT_NAME_PATTERNS.hypervisor,
    kvm_host: raw.kvm_host || DEFAULT_NAME_PATTERNS.kvm_host,
    ap_vm: raw.ap_vm || DEFAULT_NAME_PATTERNS.ap_vm,
  };
}

/**
 * The SINGLE effective-pattern predicate, mirrored from the FE resolveEffective-
 * NamePatterns (Review FIX-2). A scenario's OWN override wins, else the GLOBAL
 * row, else the built-in defaults. Ownership is the row's own non-null
 * `scenario_id` (falling back to the live route's synthetic `is_override`). Each
 * row's `name_patterns` MUST already be a parsed object or null (the caller
 * parses the JSON column). Behaviorally identical to the FE so the canvas prefill
 * and the server renumber can never disagree about which tier is in force.
 */
function resolveEffectiveNamePatterns(scenarioRow, globalRow) {
  const owned = !!scenarioRow && (
    (scenarioRow.scenario_id !== null && scenarioRow.scenario_id !== undefined)
    || scenarioRow.is_override === true
  );
  if (owned) {
    return resolveNamePatterns(
      (scenarioRow && scenarioRow.name_patterns)
      || (globalRow && globalRow.name_patterns)
      || null,
    );
  }
  return resolveNamePatterns(
    (scenarioRow && scenarioRow.name_patterns)
    || (globalRow && globalRow.name_patterns)
    || null,
  );
}

/** Whether a pattern groups by {dc} at all. */
function patternHasDc(pattern) {
  return DC_TOKEN_RE.test(String(pattern));
}

/**
 * Fork-2 wizard-consistent renumber plan for ONE entity type. `rows` are the
 * scenario's rows of that type ALREADY in display order (order_index, then id),
 * each `{ id, name, dcSlug }`. Grouping mirrors the wizard generator exactly:
 *   - a {dc} pattern groups by the row's resolved dc slug; an empty slug (an
 *     UNPLACED entity — no site) is its own group and drops {dc} so it proposes
 *     `kvm-01`, never a dangling `kvm--01` (the create-dialog patternWithoutDc
 *     path);
 *   - a {dc}-free pattern is ONE scenario-wide group.
 * Within each group seq runs 1..k in the given order; the seq pad widens to
 * max(declared, digits(k)) so a group of 100 renders 3-wide. Returns
 * `[{ id, oldName, newName }]` in the SAME order as `rows` (display order).
 */
function computeRenumberPlan(rows, pattern) {
  const hasDc = patternHasDc(pattern);
  const keyOf = (row) => (hasDc ? (row.dcSlug || '') : '');
  const counts = new Map();
  for (const row of rows) {
    const key = keyOf(row);
    counts.set(key, (counts.get(key) || 0) + 1);
  }
  // Precompute the batch-widened pattern per group key (the empty-slug group of a
  // {dc} pattern uses the {dc}-stripped form).
  const batchByKey = new Map();
  for (const [key, count] of counts) {
    const eff = hasDc && key === '' ? patternWithoutDc(pattern) : pattern;
    batchByKey.set(key, withBatchSeqWidth(eff, count));
  }
  const seqByKey = new Map();
  return rows.map((row) => {
    const key = keyOf(row);
    const seq = (seqByKey.get(key) || 0) + 1;
    seqByKey.set(key, seq);
    return {
      id: row.id,
      oldName: row.name,
      newName: formatHostname(batchByKey.get(key), { dc: key, seq }),
    };
  });
}

/**
 * The first name that repeats (case-insensitively, matching the DB's case-folding
 * collation and the create-dialog duplicate guard) within `names`, else null.
 * The renumber-apply uniqueness guarantee: even a MALFORMED stored pattern (e.g.
 * a legacy {seq}-less override that the lenient formatter would render identically
 * for every row) is caught here and rolls the whole apply back, rather than
 * persisting a duplicate name the create dialogs would then reject.
 */
function firstDuplicateName(names) {
  const seen = new Set();
  for (const name of names) {
    const folded = String(name).trim().toLowerCase();
    if (seen.has(folded)) return name;
    seen.add(folded);
  }
  return null;
}

/**
 * Per-row duplicate flags for `names`, same fold and same scope as
 * `firstDuplicateName` (case-insensitively, trimmed) but marking EVERY member
 * of a collision — not just the first repeat — so a preview can highlight
 * both sides of the clash instead of only the second occurrence. Used by the
 * renumber preview route so the dialog can block Confirm before the user
 * reaches apply's deterministic 409 (same input → same collision, every
 * retry loops back to the same wall).
 * @param {string[]} names
 * @returns {boolean[]} same length as `names`; true where that row's folded
 *   name occurs more than once in the list.
 */
function duplicateNameFlags(names) {
  const foldedOf = names.map((name) => String(name).trim().toLowerCase());
  const counts = new Map();
  for (const folded of foldedOf) counts.set(folded, (counts.get(folded) || 0) + 1);
  return foldedOf.map((folded) => counts.get(folded) > 1);
}

/**
 * The first computed name that exceeds `maxLength` characters, else null. A
 * long-but-valid {dc} slug (a long site name) plus a pattern prefix can compute a
 * hostname past the name column's VARCHAR limit; renumber must reject that whole
 * apply (a strict-mode INSERT would 500, a lax one would silently truncate) rather
 * than persist or lose data.
 * @param {string[]} names
 * @param {number} maxLength
 * @returns {string|null}
 */
function firstOverlengthName(names, maxLength) {
  for (const name of names) {
    if (String(name).length > maxLength) return name;
  }
  return null;
}

module.exports = {
  DEFAULT_NAME_PATTERNS,
  NAME_PATTERN_ENTITIES,
  validatePattern,
  validateNamePatternsWrite,
  siteSlug,
  formatHostname,
  withBatchSeqWidth,
  patternWithoutDc,
  patternHasDc,
  resolveNamePatterns,
  resolveEffectiveNamePatterns,
  computeRenumberPlan,
  firstDuplicateName,
  duplicateNameFlags,
  firstOverlengthName,
};
