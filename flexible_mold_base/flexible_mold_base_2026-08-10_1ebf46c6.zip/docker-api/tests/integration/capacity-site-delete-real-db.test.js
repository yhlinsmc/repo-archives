'use strict';

/**
 * capacity-site-delete-real-db.test.js — what still points at a data centre,
 * and what the delete does about it.
 *
 * WHY A REAL DATABASE. Two of the three references are questions only the engine
 * can answer. `cap_databases.dc_refs` is a JSON column probed with
 * JSON_CONTAINS/JSON_QUOTE, and whether that matches a given spelling is
 * MariaDB's answer, not a fixture's; the unplace half is a claim about the bytes
 * `cap_vms.site_id` holds after a statement committed. A stubbed driver returns
 * whatever it was told to, which is exactly how a preview that counts one set
 * and a delete that acts on another stay green.
 *
 * Skips with a stated reason when no database is reachable, and fails instead of
 * skipping when REQUIRE_INTEGRATION_DB=1.
 */
const {
  test, describe, before, after, beforeEach,
} = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const net = require('node:net');
const http = require('node:http');
const express = require('express');
const mariadb = require('mariadb');

const TEST_PREFIX = 'csd_';
const tbl = (name) => `${TEST_PREFIX}${name}`;

let pool = null;
const lease = () => pool.getConnection();
// The capacity guards use BOTH halves of the real pool object — `.query` for the
// unlocked probes and `.getConnection` for the write transactions — so the
// stand-in has to offer both or a guard becomes a 500 that looks like a refusal.
const handle = () => ({ getConnection: lease, query: (sql, params) => pool.query(sql, params) });

const dbKey = require.resolve('../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey,
  filename: dbKey,
  loaded: true,
  exports: {
    pool: { ro: handle(), rw: handle() },
    t: tbl,
    getDynamicPool: async () => ({ ro: handle(), rw: handle() }),
  },
};

const { buildEngineTableDDLs, buildInfraTableDDLs } = require('../../src/table-ddls');
const capacityRouter = require('../../src/edge/routes/app/capacity');

// ── Config auto-detection (same shape as the sibling integration tests) ──────

function parseEnvFile(filePath) {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    const out = {};
    for (const line of content.split('\n')) {
      const m = line.match(/^\s*([A-Z_][A-Z0-9_]*)\s*=\s*(.*)\s*$/);
      if (!m) continue;
      let value = m[2];
      if ((value.startsWith('"') && value.endsWith('"'))
        || (value.startsWith("'") && value.endsWith("'"))) {
        value = value.slice(1, -1);
      }
      out[m[1]] = value;
    }
    return out;
  } catch {
    return null;
  }
}

function probePort(host, port, timeoutMs = 2000) {
  return new Promise((resolve) => {
    const socket = new net.Socket();
    let done = false;
    const finish = (ok) => {
      if (done) return;
      done = true;
      socket.destroy();
      resolve(ok);
    };
    socket.setTimeout(timeoutMs);
    socket.once('connect', () => finish(true));
    socket.once('timeout', () => finish(false));
    socket.once('error', () => finish(false));
    socket.connect(port, host);
  });
}

async function resolveMariaDbConfig() {
  if (process.env.DB_TEST_HOST && process.env.DB_TEST_ROOT_PASSWORD) {
    return {
      host: process.env.DB_TEST_HOST,
      port: parseInt(process.env.DB_TEST_PORT || '3306', 10),
      user: 'root',
      password: process.env.DB_TEST_ROOT_PASSWORD,
    };
  }
  const envPath = path.resolve(__dirname, '../../../.devcontainer/.env');
  const env = parseEnvFile(envPath);
  if (!env || !env.DB_ROOT_PASSWORD) return null;
  const port = parseInt(env.DB_PORT || '3306', 10);
  for (const host of ['127.0.0.1', 'mariadb', 'localhost']) {
    if (await probePort(host, port, 2000)) {
      return { host, port, user: 'root', password: env.DB_ROOT_PASSWORD };
    }
  }
  return null;
}

// ── Fixture ─────────────────────────────────────────────────────────────────

const ADMIN_ID = 'aa11bb22-cc33-4d44-8e55-ff6677889900';
const ADMIN = { id: ADMIN_ID, role: 'admin' };
const OTHER_EDITOR_ID = 'bb22cc33-dd44-4e55-8f66-001122334455';
const OTHER_EDITOR = { id: OTHER_EDITOR_ID, role: 'editor' };
const SCENARIO_ID = '11112222-3333-4444-8555-666677778888';

let dbReady = false;
let skipReason = null;
let testDbName = null;
let server = null;
let baseUrl = null;
let currentUser = ADMIN;

before(async () => {
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) {
    skipReason = 'no MariaDB reachable via .devcontainer/.env or env vars';
    if (process.env.REQUIRE_INTEGRATION_DB === '1') {
      throw new Error(`REQUIRE_INTEGRATION_DB=1 set but ${skipReason}.`);
    }
    return;
  }
  testDbName = `cap_site_delete_test_${process.pid}_${Date.now()}`;
  let admin = null;
  try {
    admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`CREATE DATABASE \`${testDbName}\``);
    await admin.query(`USE \`${testDbName}\``);
    for (const sql of [...buildInfraTableDDLs(tbl), ...buildEngineTableDDLs(tbl)]) {
      await admin.query(sql);
    }
    await admin.end();
    admin = null;

    pool = mariadb.createPool({
      ...dbConfig, database: testDbName, connectionLimit: 6, connectTimeout: 5000,
    });

    const app = express();
    app.use(express.json());
    app.use((req, _res, next) => { req.user = currentUser; next(); });
    app.use('/edge/app/capacity', capacityRouter);
    server = http.createServer(app);
    await new Promise((r) => server.listen(0, r));
    baseUrl = `http://127.0.0.1:${server.address().port}`;
    dbReady = true;
  } catch (err) {
    skipReason = `setup failed: ${err.message}`;
    if (admin) { try { await admin.end(); } catch { /* best effort */ } }
    if (process.env.REQUIRE_INTEGRATION_DB === '1') throw err;
  }
});

after(async () => {
  if (server) { try { server.close(); } catch { /* best effort */ } }
  if (pool) { try { await pool.end(); } catch { /* best effort */ } }
  if (!testDbName) return;
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) return;
  try {
    const admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`DROP DATABASE IF EXISTS \`${testDbName}\``);
    await admin.end();
  } catch { /* best effort */ }
});

async function call(user, method, url, body) {
  currentUser = user;
  const res = await fetch(`${baseUrl}${url}`, {
    method,
    headers: { 'content-type': 'application/json' },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const text = await res.text();
  let parsed = null;
  try { parsed = JSON.parse(text); } catch { parsed = { raw: text }; }
  return { status: res.status, body: parsed };
}

const q = (sql, params) => pool.query(sql, params);
const one = async (sql, params) => (await pool.query(sql, params))[0];

const CAPACITY_TABLES = [
  'cap_waivers', 'cap_rules', 'cap_custom_group_members', 'cap_custom_groups',
  'cap_db_instances', 'cap_vms', 'cap_databases', 'cap_hypervisors', 'cap_sites',
  'cap_versions', 'cap_bundle_items', 'cap_bundles', 'cap_field_defs',
  'cap_vm_profiles', 'cap_disk_combos', 'cap_teams', 'cap_hardware_specs',
  'cap_settings', 'cap_scenarios',
];

const guard = (t) => {
  if (dbReady) return false;
  t.skip(skipReason || 'database not ready');
  return true;
};

/** Row counts, read straight from the table rather than from a response body. */
const rowCount = async (table, where, params) => Number(
  (await one(`SELECT COUNT(*) AS n FROM \`${tbl(table)}\` ${where}`, params)).n,
);
const storedVmSite = async (vmId) => (
  await one(`SELECT site_id FROM \`${tbl('cap_vms')}\` WHERE id = ?`, [vmId])
).site_id;

beforeEach(async () => {
  if (!dbReady) return;
  for (const name of [...CAPACITY_TABLES, 'feature_audit', 'users']) {
    await q(`DELETE FROM \`${tbl(name)}\``);
  }
  await q(
    `INSERT INTO \`${tbl('users')}\` (id, email, role, banned) VALUES (?,?,?,0)`,
    [ADMIN_ID, 'admin@test.local', 'admin'],
  );
  await q(
    `INSERT INTO \`${tbl('users')}\` (id, email, role, banned) VALUES (?,?,?,0)`,
    [OTHER_EDITOR_ID, 'editor@test.local', 'editor'],
  );
  await q(
    `INSERT INTO \`${tbl('cap_scenarios')}\` (id, name, owner_id) VALUES (?,?,?)`,
    [SCENARIO_ID, 'a scenario', null],
  );
});

const base = `/edge/app/capacity/scenarios/${SCENARIO_ID}`;

/** One data centre, and a hardware spec to hang hosts on. */
async function seedSite(name = 'DC-A') {
  const spec = await call(ADMIN, 'POST', '/edge/app/capacity/config/hardware_specs',
    { name: `spec-${name}`, cpu_total: 64, mem_total_gb: 512, disk_total_gb: 4096 });
  assert.equal(spec.status, 201, `the spec fixture was refused: ${JSON.stringify(spec.body)}`);
  const site = await call(ADMIN, 'POST', `${base}/sites`, { name });
  assert.equal(site.status, 200, `the site fixture was refused: ${JSON.stringify(site.body)}`);
  return { siteId: site.body.data.id, specId: spec.body.data.id };
}

const deleteSite = (siteId, user = ADMIN) => call(user, 'DELETE', `${base}/sites/${siteId}`);

/**
 * The reference groups a refused site delete reports. There is no preview
 * endpoint: the refusal IS where an operator learns what points at the site, so
 * every case below reads the answer out of the 409 the delete returns.
 */
const refusalGroups = (res) => {
  assert.ok(res.body.error && res.body.error.details, `no reference detail on the refusal: ${JSON.stringify(res.body)}`);
  return res.body.error.details.references;
};
const groupOf = (groups, kind) => groups.find((g) => g.kind === kind);

/** What the delete reports about a site WITHOUT deleting it: drive it, read the
 *  groups, and — when it succeeded — put the site back is not possible, so this
 *  is only used where a refusal is expected. */
const groupsOfRefusal = async (siteId) => refusalGroups(await deleteSite(siteId));

// ── The premise ─────────────────────────────────────────────────────────────

describe('the premise: an unreferenced data centre deletes', () => {
  test('nothing points at a fresh site', async (t) => {
    if (guard(t)) return;
    // Every refusal below rests on this: if a bare site were already blocked the
    // cases would pass without anything they claim to test being true.
    const { siteId } = await seedSite();
    const gone = await deleteSite(siteId);
    assert.equal(gone.status, 200, JSON.stringify(gone.body));
    assert.equal(await rowCount('cap_sites', 'WHERE id = ?', [siteId]), 0);
  });
});

// ── Reference kind 1: a hypervisor placed at the site ───────────────────────

describe('a hypervisor placed at the data centre', () => {
  test('the delete cascades the host (spec §4 reversal), and the report names it', async (t) => {
    if (guard(t)) return;
    const { siteId, specId } = await seedSite();
    const hv = await call(ADMIN, 'POST', `${base}/hypervisors`,
      { name: 'host-a', site_id: siteId, spec_id: specId });
    assert.equal(hv.status, 200, JSON.stringify(hv.body));

    const gone = await deleteSite(siteId);
    assert.equal(gone.status, 200, JSON.stringify(gone.body));
    // The row counts, not the status code: the host is gone with the site, and
    // the response names how many it cascaded.
    assert.equal(await rowCount('cap_sites', 'WHERE id = ?', [siteId]), 0);
    assert.equal(await rowCount('cap_hypervisors', 'WHERE id = ?', [hv.body.data.id]), 0,
      'the hypervisor was left dangling on a deleted site');
    assert.equal(gone.body.data.cascaded['cap_hypervisors.site_id'], 1);
  });

  test('and it deletes once the host has moved away', async (t) => {
    if (guard(t)) return;
    const { siteId, specId } = await seedSite();
    const other = await call(ADMIN, 'POST', `${base}/sites`, { name: 'DC-B' });
    const hv = await call(ADMIN, 'POST', `${base}/hypervisors`,
      { name: 'host-a', site_id: siteId, spec_id: specId });
    assert.equal(hv.status, 200, JSON.stringify(hv.body));

    const moved = await call(ADMIN, 'PUT', `${base}/hypervisors/${hv.body.data.id}`,
      { site_id: other.body.data.id });
    assert.equal(moved.status, 200, JSON.stringify(moved.body));

    const gone = await deleteSite(siteId);
    assert.equal(gone.status, 200, JSON.stringify(gone.body));
    assert.equal(await rowCount('cap_sites', 'WHERE id = ?', [siteId]), 0);
  });
});

// ── Reference kind 2: a VM carrying the site ────────────────────────────────

describe('a VM whose intended data centre is this one', () => {
  test('the delete unpins it rather than refusing, and says how many it moved', async (t) => {
    if (guard(t)) return;
    // The disposition is the contract: this reference is nullable and NULL is a
    // meaningful state, so the site delete clears it. A test that only asserted
    // the 200 would pass with the column left dangling.
    const { siteId } = await seedSite();
    const vm = await call(ADMIN, 'POST', `${base}/vms`,
      { name: 'kvm1', vm_type: 'ap_host', site_id: siteId });
    assert.equal(vm.status, 200, JSON.stringify(vm.body));
    const vmId = vm.body.data.id;
    assert.equal(await storedVmSite(vmId), siteId, 'the fixture never pinned the VM');

    const gone = await deleteSite(siteId);
    assert.equal(gone.status, 200, JSON.stringify(gone.body));
    assert.equal(await storedVmSite(vmId), null, 'the VM was left pointing at a deleted site');
    assert.equal(gone.body.data.unplaced['cap_vms.site_id'], 1);
  });

  test('and a refusal for another reason still names it, as something that WILL move', async (t) => {
    if (guard(t)) return;
    // The reason the refusal reports every kind and not only the blocking ones:
    // an operator clearing a dc_refs restriction needs to know the KVM goes
    // unpinned too. (A dc_refs database is now the only blocker — a hypervisor
    // cascades, spec §4.)
    const { siteId } = await seedSite();
    await call(ADMIN, 'POST', `${base}/databases`,
      { function_name: 'ORDERS', topology: 'single', dc_refs: [siteId] });
    const vm = await call(ADMIN, 'POST', `${base}/vms`,
      { name: 'kvm1', vm_type: 'ap_host', site_id: siteId });
    assert.equal(vm.status, 200, JSON.stringify(vm.body));

    const group = groupOf(await groupsOfRefusal(siteId), 'vm');
    assert.equal(group.count, 1);
    assert.equal(group.disposition, 'unplace');
    assert.deepEqual(group.names.map((n) => n.name), ['kvm1']);
    // And it is not what the refusal blames.
    assert.equal(/VM/.test((await deleteSite(siteId)).body.error.message), false);
  });
});

// ── Reference kind 3: a database restricted to the site ─────────────────────

describe('a database whose dc_refs restriction names this data centre', () => {
  test('the delete is refused and the refusal names the database', async (t) => {
    if (guard(t)) return;
    const { siteId } = await seedSite();
    const db = await call(ADMIN, 'POST', `${base}/databases`,
      { function_name: 'ORDERS', topology: 'single', dc_refs: [siteId] });
    assert.equal(db.status, 200, JSON.stringify(db.body));

    const refused = await deleteSite(siteId);
    assert.equal(refused.status, 409, JSON.stringify(refused.body));
    const group = groupOf(refusalGroups(refused), 'database_dc_ref');
    assert.equal(group.count, 1);
    assert.equal(group.disposition, 'block');
    assert.deepEqual(group.names.map((n) => n.name), ['ORDERS']);
    assert.equal(await rowCount('cap_sites', 'WHERE id = ?', [siteId]), 1);
  });

  test('and it deletes once the restriction no longer names it', async (t) => {
    if (guard(t)) return;
    const { siteId } = await seedSite();
    const other = await call(ADMIN, 'POST', `${base}/sites`, { name: 'DC-B' });
    const db = await call(ADMIN, 'POST', `${base}/databases`,
      { function_name: 'ORDERS', topology: 'single', dc_refs: [siteId] });
    assert.equal(db.status, 200, JSON.stringify(db.body));

    const narrowed = await call(ADMIN, 'PUT', `${base}/databases/${db.body.data.id}`,
      { dc_refs: [other.body.data.id] });
    assert.equal(narrowed.status, 200, JSON.stringify(narrowed.body));

    const gone = await deleteSite(siteId);
    assert.equal(gone.status, 200, JSON.stringify(gone.body));
    assert.equal(await rowCount('cap_sites', 'WHERE id = ?', [siteId]), 0);
  });

  test('a restriction naming a DIFFERENT site does not block this one', async (t) => {
    if (guard(t)) return;
    // The probe has to discriminate. A containment test that matched any
    // non-empty list would refuse every delete in a scenario that uses dc_refs
    // at all, and the case above would not notice.
    const { siteId } = await seedSite();
    const other = await call(ADMIN, 'POST', `${base}/sites`, { name: 'DC-B' });
    const db = await call(ADMIN, 'POST', `${base}/databases`,
      { function_name: 'ORDERS', topology: 'single', dc_refs: [other.body.data.id] });
    assert.equal(db.status, 200, JSON.stringify(db.body));

    const gone = await deleteSite(siteId);
    assert.equal(gone.status, 200, JSON.stringify(gone.body));
  });
});

// ── The spelling the statement is given ─────────────────────────────────────

describe('a caller who spells the site id differently still gets the same answer', () => {
  test('a respelled id is refused for a dc_refs restriction it does not byte-match', async (t) => {
    if (guard(t)) return;
    // The gate resolves the row under any spelling — `CHAR(36)` folds case — so
    // a URL naming the site in upper case reaches the delete. The dc_refs probe
    // does NOT fold: it asks whether the restriction list byte-contains a given
    // string. Handed the caller's spelling it finds nothing, and a delete that
    // must be refused goes through and leaves the restriction dangling. The
    // stored spelling is what the sweep has to be given.
    const { siteId } = await seedSite();
    assert.notEqual(String(siteId).toUpperCase(), siteId, 'the fixture id has no letters to re-case');
    const db = await call(ADMIN, 'POST', `${base}/databases`,
      { function_name: 'ORDERS', topology: 'single', dc_refs: [siteId] });
    assert.equal(db.status, 200, JSON.stringify(db.body));

    const refused = await deleteSite(String(siteId).toUpperCase());
    assert.equal(refused.status, 409, JSON.stringify(refused.body));
    assert.equal(await rowCount('cap_sites', 'WHERE id = ?', [siteId]), 1);
  });
});

// ── One refusal, every kind, with names ─────────────────────────────────────

describe('the refusal is the whole account of what points at the site', () => {
  test('all three kinds, named, and only the blocking ones are blamed', async (t) => {
    if (guard(t)) return;
    const { siteId, specId } = await seedSite();
    await call(ADMIN, 'POST', `${base}/hypervisors`, { name: 'host-a', site_id: siteId, spec_id: specId });
    await call(ADMIN, 'POST', `${base}/vms`, { name: 'kvm1', vm_type: 'ap_host', site_id: siteId });
    await call(ADMIN, 'POST', `${base}/databases`, { function_name: 'ORDERS', topology: 'single', dc_refs: [siteId] });

    const refused = await deleteSite(siteId);
    assert.equal(refused.status, 409, JSON.stringify(refused.body));
    const groups = refusalGroups(refused);
    assert.deepEqual(groups.map((g) => g.kind).sort(), ['database_dc_ref', 'hypervisor', 'vm']);
    for (const kind of ['hypervisor', 'vm', 'database_dc_ref']) {
      assert.equal(groupOf(groups, kind).count, 1, `${kind} was not counted`);
      assert.equal(groupOf(groups, kind).names.length, 1, `${kind} was counted but not named`);
    }
    // Only the dc_refs database blocks now; the hypervisor and VM are reported as
    // things that WILL move, never as the reason for the refusal (spec §4).
    assert.match(refused.body.error.message, /database restricted to this datacenter/);
    assert.equal(/hypervisor placed here/.test(refused.body.error.message), false);
    assert.equal(await rowCount('cap_sites', 'WHERE id = ?', [siteId]), 1);
  });
});

// ── Authorization ───────────────────────────────────────────────────────────

describe('the delete is gated as it always was', () => {
  test('a non-owner editor is refused, and told nothing about the contents', async (t) => {
    if (guard(t)) return;
    const { siteId } = await seedSite();
    await q(`UPDATE \`${tbl('cap_scenarios')}\` SET owner_id = ? WHERE id = ?`, [ADMIN_ID, SCENARIO_ID]);

    const refused = await deleteSite(siteId, OTHER_EDITOR);
    assert.equal(refused.status, 403, JSON.stringify(refused.body));
    assert.equal(refused.body.error.details, undefined, 'a 403 enumerated the scenario');
    assert.equal(await rowCount('cap_sites', 'WHERE id = ?', [siteId]), 1);
  });

  test('a site in another scenario is 404, not enumerated', async (t) => {
    if (guard(t)) return;
    const { siteId } = await seedSite();
    const otherScenario = 'deadbeef-1111-4222-8333-444455556666';
    await q(`INSERT INTO \`${tbl('cap_scenarios')}\` (id, name, owner_id) VALUES (?,?,?)`,
      [otherScenario, 'other', null]);
    const res = await call(ADMIN, 'DELETE',
      `/edge/app/capacity/scenarios/${otherScenario}/sites/${siteId}`);
    assert.equal(res.status, 404, JSON.stringify(res.body));
    assert.equal(await rowCount('cap_sites', 'WHERE id = ?', [siteId]), 1);
  });
});

// ── T2: a dc_refs entry naming a site that does not exist ───────────────────

const factsFor = (body) => body.data.find((f) => f.id === SCENARIO_ID);
const healthFacts = () => call(ADMIN, 'GET', '/edge/app/capacity/scenarios/health');

describe('a dc_refs entry naming a site that is not in the scenario', () => {
  test('the scenario-health aggregate reports it', async (t) => {
    if (guard(t)) return;
    // Written straight to the column: the write path refuses nothing about
    // dc_refs today (that reference is not declared), and a site deleted out
    // from under an entry leaves exactly this state.
    const { siteId } = await seedSite();
    const db = await call(ADMIN, 'POST', `${base}/databases`,
      { function_name: 'ORDERS', topology: 'single', dc_refs: [siteId] });
    assert.equal(db.status, 200, JSON.stringify(db.body));

    const before = await healthFacts();
    assert.equal(before.status, 200, JSON.stringify(before.body));
    assert.equal(factsFor(before.body).brokenRefs, 0, 'a resolvable restriction is not a broken reference');

    await q(
      `UPDATE \`${tbl('cap_databases')}\` SET dc_refs = ? WHERE id = ?`,
      [JSON.stringify(['4b3d1f0a-0000-4000-8000-000000000000']), db.body.data.id],
    );

    assert.equal(factsFor((await healthFacts()).body).brokenRefs, 1,
      'a dc_refs entry naming no site went unreported');
  });

  test('a STORED spelling no reader can follow counts as dangling, not as a live reference', async (t) => {
    if (guard(t)) return;
    // The two halves of one rule, about the READERS. `dcRefsAdmitsSite` compares
    // byte for byte, so an entry differing only in case restricts nothing and
    // admits nothing — it must therefore NOT block the site's delete, and it MUST
    // be reported as a broken reference. Seeded straight to the column: the write
    // path now canonicalises a variant it is given (see the sibling test below),
    // so a stored variant is what a site deleted out from under an entry, or a
    // pre-fix row, leaves — and the readers must go on treating it as dangling.
    const { siteId } = await seedSite();
    assert.notEqual(String(siteId).toUpperCase(), siteId, 'the fixture id has no letters to re-case');
    const db = await call(ADMIN, 'POST', `${base}/databases`,
      { function_name: 'ORDERS', topology: 'single' });
    assert.equal(db.status, 200, JSON.stringify(db.body));
    await q(`UPDATE \`${tbl('cap_databases')}\` SET dc_refs = ? WHERE id = ?`,
      [JSON.stringify([String(siteId).toUpperCase()]), db.body.data.id]);

    assert.equal(factsFor((await healthFacts()).body).brokenRefs, 1);
    const gone = await deleteSite(siteId);
    assert.equal(gone.status, 200, JSON.stringify(gone.body));
  });

  test('a variant handed to the write path is canonicalised, so it DOES block the delete', async (t) => {
    if (guard(t)) return;
    // The other side of the same rule, on the write. A caller-supplied case
    // variant of a real site id used to store verbatim and leave a broken
    // restriction (fmb-1541: the delete then returned 200). The write now binds
    // the site's own spelling, so the restriction resolves for every reader and
    // the delete is refused — the same 409 a canonically-spelled entry gets.
    const { siteId } = await seedSite();
    assert.notEqual(String(siteId).toUpperCase(), siteId, 'the fixture id has no letters to re-case');
    const db = await call(ADMIN, 'POST', `${base}/databases`,
      { function_name: 'ORDERS', topology: 'single', dc_refs: [String(siteId).toUpperCase()] });
    assert.equal(db.status, 200, JSON.stringify(db.body));

    assert.equal(factsFor((await healthFacts()).body).brokenRefs, 0,
      'a variant the write path was handed stayed dangling');
    const refused = await deleteSite(siteId);
    assert.equal(refused.status, 409, JSON.stringify(refused.body));
    assert.equal(await rowCount('cap_sites', 'WHERE id = ?', [siteId]), 1);
  });

  test('an unrestricted database reports nothing', async (t) => {
    if (guard(t)) return;
    // Null, [] and [""] all mean "all data centres" — none is a reference and
    // none is dangling.
    await seedSite();
    for (const [name, dcRefs] of [['ORDERS', undefined], ['BILLING', []], ['STOCK', ['']]]) {
      const res = await call(ADMIN, 'POST', `${base}/databases`,
        { function_name: name, topology: 'single', ...(dcRefs === undefined ? {} : { dc_refs: dcRefs }) });
      assert.equal(res.status, 200, JSON.stringify(res.body));
    }
    assert.equal(factsFor((await healthFacts()).body).brokenRefs, 0);
  });
});

// ── The three copies of one rule, compared ──────────────────────────────────
//
// What a dc_refs entry IS, and when one resolves, exists in three places: the
// reference implementation, its frontend mirror (compared to the reference by
// placement-dc-candidates.parity.test.ts) and the SQL aggregate below. Each of
// the three was wrong about a different clause of the same sentence, and each
// disagreed with the other two on a different input — so fixing them case by
// case only swapped which layer was wrong.
//
// This drives the SQL over the corpus the reference publishes and compares it to
// the reference's own answer. Not a second set of expectations: a differential
// test, so a drift fails on the input it drifted on.
describe('the SQL aggregate answers exactly what the reference rule answers', () => {
  const { danglingDcRefs, DC_REFS_PARITY_CASES, DC_REFS_PARITY_SITE_ID } = require('../../src/shared/capacity/dc-refs');

  /** Store one dc_refs value verbatim. Returns false when the ENGINE refuses it
   *  (a JSON column carries a json_valid CHECK) — an input the column cannot
   *  hold is not an input either copy has to agree about. */
  const storeCase = async (index, raw) => {
    const value = typeof raw === 'string' ? raw : (raw === null ? null : JSON.stringify(raw));
    try {
      await q(
        `INSERT INTO \`${tbl('cap_databases')}\` (id, scenario_id, function_name, topology, dc_refs)`
        + ' VALUES (UUID(), ?, ?, ?, ?)',
        [SCENARIO_ID, `F${index}`, 'single', value],
      );
      return true;
    } catch {
      return false;
    }
  };

  /** The scenario's only site is the id the corpus is written against. */
  const seedCorpusSite = async () => {
    await q(`INSERT INTO \`${tbl('cap_sites')}\` (id, scenario_id, name) VALUES (?,?,?)`,
      [DC_REFS_PARITY_SITE_ID, SCENARIO_ID, 'DC-A']);
  };

  test('the corpus is not empty and reaches the shapes the copies split on', async (t) => {
    if (guard(t)) return;
    // Without this the two cases below are vacuously green.
    assert.ok(DC_REFS_PARITY_CASES.length > 15, `only ${DC_REFS_PARITY_CASES.length} cases`);
    const raws = DC_REFS_PARITY_CASES.map((c) => JSON.stringify(c.raw));
    for (const shape of [
      [`${DC_REFS_PARITY_SITE_ID}ZZZZ`], [`${DC_REFS_PARITY_SITE_ID} `], [''], [' '],
      [DC_REFS_PARITY_SITE_ID.toUpperCase(), DC_REFS_PARITY_SITE_ID],
    ]) {
      assert.ok(raws.includes(JSON.stringify(shape)), `the corpus lost ${JSON.stringify(shape)}`);
    }
  });

  test('case by case, on a real database', async (t) => {
    if (guard(t)) return;
    await seedCorpusSite();
    const siteIds = new Set([DC_REFS_PARITY_SITE_ID]);
    const mismatches = [];
    for (const [i, testCase] of DC_REFS_PARITY_CASES.entries()) {
      await q(`DELETE FROM \`${tbl('cap_databases')}\``);
      if (!(await storeCase(i, testCase.raw))) continue;
      const sql = factsFor((await healthFacts()).body).brokenRefs;
      const reference = danglingDcRefs(testCase.raw, siteIds).length;
      if (sql !== reference) mismatches.push(`${testCase.name}: sql=${sql} reference=${reference}`);
    }
    assert.deepEqual(mismatches, [], 'the SQL and the reference rule disagree');
  });

  test('and on the whole corpus at once, in both row orders', async (t) => {
    if (guard(t)) return;
    // Cardinality and ROW ORDER, which a one-row fixture cannot reach: an
    // aggregate that reuses one entry's verdict for a later one, or counts a
    // duplicate twice, is only visible with many rows in play.
    await seedCorpusSite();
    const siteIds = new Set([DC_REFS_PARITY_SITE_ID]);
    for (const order of ['as published', 'reversed']) {
      await q(`DELETE FROM \`${tbl('cap_databases')}\``);
      const cases = order === 'reversed' ? [...DC_REFS_PARITY_CASES].reverse() : DC_REFS_PARITY_CASES;
      let reference = 0;
      for (const [i, testCase] of cases.entries()) {
        if (!(await storeCase(i, testCase.raw))) continue;
        reference += danglingDcRefs(testCase.raw, siteIds).length;
      }
      assert.ok(reference > 5, `the corpus produced only ${reference} dangling entries — it has stopped biting`);
      assert.equal(factsFor((await healthFacts()).body).brokenRefs, reference,
        `the aggregate disagreed with the reference rule (${order})`);
    }
  });
});
