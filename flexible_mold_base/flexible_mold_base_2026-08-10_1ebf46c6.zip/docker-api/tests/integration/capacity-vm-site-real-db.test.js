'use strict';

/**
 * capacity-vm-site-real-db.test.js — which data centre a VM is in, read back
 * from the column after each write path ran.
 *
 * WHY A REAL DATABASE. Every claim here is a claim about the bytes
 * `cap_vms.site_id` holds once a statement committed. A mocked driver answers
 * that with whatever the fixture was told to say, and the defect this file
 * exists for is precisely a value nobody wrote: the placement canvas moves a VM
 * between hosts by writing `hypervisor_id` alone, so the moment the new host
 * stands in another data centre the column still names the old one. Nothing in
 * the request or the response says so — only the stored row does.
 *
 * THE INVARIANT. A placed VM's data centre IS its host's; `cap_vms.site_id` is
 * a cache of that answer. While the VM is unplaced there is no host to ask and
 * the column carries the operator's INTENDED site, which is why unplacing must
 * not blank it.
 *
 * Skips with a stated reason when no database is reachable, and fails instead
 * of skipping when REQUIRE_INTEGRATION_DB=1.
 */
const {
  test, describe, before, after, beforeEach,
} = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const net = require('node:net');
const http = require('node:http');
const express = require('express');
const mariadb = require('mariadb');

const TEST_PREFIX = 'cvs_';
const tbl = (name) => `${TEST_PREFIX}${name}`;

let pool = null;
const lease = () => pool.getConnection();
// The capacity guards use BOTH halves of the real pool object — `pool.rw.query`
// for the pre-middleware probes and `pool.rw.getConnection` for the write
// transactions — so the stand-in has to offer both or a guard becomes a 500
// that looks like a refusal.
const handle = () => ({ getConnection: lease, query: (sql, params) => pool.query(sql, params) });

const dbKey = require.resolve('../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey,
  filename: dbKey,
  loaded: true,
  exports: {
    pool: { ro: handle(), rw: handle() },
    t: tbl,
    getDynamicPool: async () => ({ ro: handle(), rw: handle() }),
  },
};

const { buildEngineTableDDLs, buildInfraTableDDLs } = require('../../src/table-ddls');
const capacityRouter = require('../../src/edge/routes/app/capacity');
const { syncVmSiteCache } = require('../../src/edge/routes/app/capacity/_shared');

// ── Config auto-detection (same shape as the sibling integration tests) ──────

function parseEnvFile(filePath) {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    const out = {};
    for (const line of content.split('\n')) {
      const m = line.match(/^\s*([A-Z_][A-Z0-9_]*)\s*=\s*(.*)\s*$/);
      if (!m) continue;
      let value = m[2];
      if ((value.startsWith('"') && value.endsWith('"'))
        || (value.startsWith("'") && value.endsWith("'"))) {
        value = value.slice(1, -1);
      }
      out[m[1]] = value;
    }
    return out;
  } catch {
    return null;
  }
}

function probePort(host, port, timeoutMs = 2000) {
  return new Promise((resolve) => {
    const socket = new net.Socket();
    let done = false;
    const finish = (ok) => {
      if (done) return;
      done = true;
      socket.destroy();
      resolve(ok);
    };
    socket.setTimeout(timeoutMs);
    socket.once('connect', () => finish(true));
    socket.once('timeout', () => finish(false));
    socket.once('error', () => finish(false));
    socket.connect(port, host);
  });
}

async function resolveMariaDbConfig() {
  if (process.env.DB_TEST_HOST && process.env.DB_TEST_ROOT_PASSWORD) {
    return {
      host: process.env.DB_TEST_HOST,
      port: parseInt(process.env.DB_TEST_PORT || '3306', 10),
      user: 'root',
      password: process.env.DB_TEST_ROOT_PASSWORD,
    };
  }
  const envPath = path.resolve(__dirname, '../../../.devcontainer/.env');
  const env = parseEnvFile(envPath);
  if (!env || !env.DB_ROOT_PASSWORD) return null;
  const port = parseInt(env.DB_PORT || '3306', 10);
  for (const host of ['127.0.0.1', 'mariadb', 'localhost']) {
    if (await probePort(host, port, 2000)) {
      return { host, port, user: 'root', password: env.DB_ROOT_PASSWORD };
    }
  }
  return null;
}

// ── Fixture ─────────────────────────────────────────────────────────────────

const ADMIN_ID = 'cdefab03-4567-89ab-cdef-ab0123456789';
const ADMIN = { id: ADMIN_ID, role: 'admin' };
const SCENARIO_ID = 'abcabc11-2222-4333-8444-555566667777';

let dbReady = false;
let skipReason = null;
let testDbName = null;
let server = null;
let baseUrl = null;
let currentUser = ADMIN;

before(async () => {
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) {
    skipReason = 'no MariaDB reachable via .devcontainer/.env or env vars';
    if (process.env.REQUIRE_INTEGRATION_DB === '1') {
      throw new Error(`REQUIRE_INTEGRATION_DB=1 set but ${skipReason}.`);
    }
    return;
  }
  testDbName = `cap_vm_site_test_${process.pid}_${Date.now()}`;
  let admin = null;
  try {
    admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`CREATE DATABASE \`${testDbName}\``);
    await admin.query(`USE \`${testDbName}\``);
    // Every table, built from the DDL that creates the real ones. A hand-picked
    // subset drops a table some guard probes and turns its refusal into a
    // degrade nobody asked for.
    for (const sql of [...buildInfraTableDDLs(tbl), ...buildEngineTableDDLs(tbl)]) {
      await admin.query(sql);
    }
    await admin.end();
    admin = null;

    pool = mariadb.createPool({
      ...dbConfig, database: testDbName, connectionLimit: 6, connectTimeout: 5000,
    });

    const app = express();
    app.use(express.json());
    app.use((req, _res, next) => { req.user = currentUser; next(); });
    app.use('/edge/app/capacity', capacityRouter);
    server = http.createServer(app);
    await new Promise((r) => server.listen(0, r));
    baseUrl = `http://127.0.0.1:${server.address().port}`;
    dbReady = true;
  } catch (err) {
    skipReason = `setup failed: ${err.message}`;
    if (admin) { try { await admin.end(); } catch { /* best effort */ } }
    if (process.env.REQUIRE_INTEGRATION_DB === '1') throw err;
  }
});

after(async () => {
  if (server) { try { server.close(); } catch { /* best effort */ } }
  if (pool) { try { await pool.end(); } catch { /* best effort */ } }
  if (!testDbName) return;
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) return;
  try {
    const admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`DROP DATABASE IF EXISTS \`${testDbName}\``);
    await admin.end();
  } catch { /* best effort */ }
});

async function call(user, method, url, body) {
  currentUser = user;
  const res = await fetch(`${baseUrl}${url}`, {
    method,
    headers: { 'content-type': 'application/json' },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const text = await res.text();
  let parsed = null;
  try { parsed = JSON.parse(text); } catch { parsed = { raw: text }; }
  return { status: res.status, body: parsed };
}

const q = (sql, params) => pool.query(sql, params);
const one = async (sql, params) => (await pool.query(sql, params))[0];
const countOf = async (sql, params) => Number((await one(sql, params)).n);

const CAPACITY_TABLES = [
  'cap_waivers', 'cap_rules', 'cap_custom_group_members', 'cap_custom_groups',
  'cap_db_instances', 'cap_vms', 'cap_databases', 'cap_hypervisors', 'cap_sites',
  'cap_versions', 'cap_bundle_items', 'cap_bundles', 'cap_field_defs',
  'cap_vm_profiles', 'cap_disk_combos', 'cap_teams', 'cap_hardware_specs',
  'cap_settings', 'cap_scenarios',
];

const guard = (t) => {
  if (dbReady) return false;
  t.skip(skipReason || 'database not ready');
  return true;
};

/** The stored data-centre pin of one VM, read with no folding. */
const storedSiteOf = async (vmId) => {
  const row = await one(`SELECT site_id FROM \`${tbl('cap_vms')}\` WHERE id = ?`, [vmId]);
  return row ? row.site_id : undefined;
};

beforeEach(async () => {
  if (!dbReady) return;
  for (const name of [...CAPACITY_TABLES, 'feature_audit', 'users']) {
    await q(`DELETE FROM \`${tbl(name)}\``);
  }
  await q(
    `INSERT INTO \`${tbl('users')}\` (id, email, role, banned) VALUES (?,?,?,0)`,
    [ADMIN_ID, 'admin@test.local', 'admin'],
  );
  await q(
    `INSERT INTO \`${tbl('cap_scenarios')}\` (id, name, owner_id) VALUES (?,?,?)`,
    [SCENARIO_ID, 'a scenario', null],
  );
});

const base = `/edge/app/capacity/scenarios/${SCENARIO_ID}`;

/** Two data centres and one host standing in each — the smallest estate in
 *  which "which DC is this VM in" can have two different answers. */
async function seedTwoDataCentres() {
  const spec = await call(ADMIN, 'POST', '/edge/app/capacity/config/hardware_specs',
    { name: 'spec', cpu_total: 64, mem_total_gb: 512, disk_total_gb: 4096 });
  assert.equal(spec.status, 201, `the spec fixture was refused: ${JSON.stringify(spec.body)}`);
  const siteA = await call(ADMIN, 'POST', `${base}/sites`, { name: 'DC-A' });
  const siteB = await call(ADMIN, 'POST', `${base}/sites`, { name: 'DC-B' });
  assert.equal(siteA.status, 200, `the DC-A fixture was refused: ${JSON.stringify(siteA.body)}`);
  assert.equal(siteB.status, 200, `the DC-B fixture was refused: ${JSON.stringify(siteB.body)}`);
  const hvA = await call(ADMIN, 'POST', `${base}/hypervisors`,
    { name: 'host-a', site_id: siteA.body.data.id, spec_id: spec.body.data.id });
  const hvB = await call(ADMIN, 'POST', `${base}/hypervisors`,
    { name: 'host-b', site_id: siteB.body.data.id, spec_id: spec.body.data.id });
  assert.equal(hvA.status, 200, `the host-a fixture was refused: ${JSON.stringify(hvA.body)}`);
  assert.equal(hvB.status, 200, `the host-b fixture was refused: ${JSON.stringify(hvB.body)}`);
  return {
    siteA: siteA.body.data.id,
    siteB: siteB.body.data.id,
    hvA: hvA.body.data.id,
    hvB: hvB.body.data.id,
    // Handed back so a case can add a host of its own to this estate — one that
    // stands in NO data centre, which the two-host fixture cannot express.
    spec: spec.body.data.id,
  };
}

// ── The premise, measured ───────────────────────────────────────────────────

describe('the premise: the two hosts really do stand in different data centres', () => {
  test('each host stores the site it was created in', async (t) => {
    if (guard(t)) return;
    // Every case below rests on this: if the fixture put both hosts in one DC
    // the disagreement would be unreachable and each assertion would pass
    // without any of the fixes.
    const { siteA, siteB, hvA, hvB } = await seedTwoDataCentres();
    assert.notEqual(siteA, siteB);
    assert.equal((await one(`SELECT site_id FROM \`${tbl('cap_hypervisors')}\` WHERE id = ?`, [hvA])).site_id, siteA);
    assert.equal((await one(`SELECT site_id FROM \`${tbl('cap_hypervisors')}\` WHERE id = ?`, [hvB])).site_id, siteB);
  });
});

// ── The generic child mount: create AND update ──────────────────────────────

describe('a VM created on a host is in that host\'s data centre', () => {
  test('a create naming another DC stores the host\'s', async (t) => {
    if (guard(t)) return;
    // The caller says one thing and the placement says another. The placement
    // wins, because it is the thing that exists: a VM standing on host-a is in
    // DC-A whatever any column says about it.
    const { siteA, siteB, hvA } = await seedTwoDataCentres();
    const vm = await call(ADMIN, 'POST', `${base}/vms`,
      { name: 'kvm1', vm_type: 'ap_host', hypervisor_id: hvA, site_id: siteB });
    assert.equal(vm.status, 200, `the create was refused: ${JSON.stringify(vm.body)}`);

    assert.equal(
      await storedSiteOf(vm.body.data.id), siteA,
      'the VM stores a data centre its host does not stand in',
    );
  });

  test('a create with no host keeps the intended DC the caller named', async (t) => {
    if (guard(t)) return;
    // The other half of the same rule, and the one a fix can easily break:
    // there is no host to ask, so the column IS the answer.
    const { siteA } = await seedTwoDataCentres();
    const vm = await call(ADMIN, 'POST', `${base}/vms`,
      { name: 'kvm1', vm_type: 'ap_host', site_id: siteA });
    assert.equal(vm.status, 200, `the create was refused: ${JSON.stringify(vm.body)}`);

    assert.equal(await storedSiteOf(vm.body.data.id), siteA, 'an unplaced VM lost its intended DC');
  });
});

describe('moving a VM through the grid takes its data centre along', () => {
  test('a PUT that changes the host rewrites the stored DC', async (t) => {
    if (guard(t)) return;
    const { siteB, hvA, hvB } = await seedTwoDataCentres();
    const vm = await call(ADMIN, 'POST', `${base}/vms`,
      { name: 'kvm1', vm_type: 'ap_host', hypervisor_id: hvA });
    assert.equal(vm.status, 200, `the create was refused: ${JSON.stringify(vm.body)}`);
    const vmId = vm.body.data.id;

    const moved = await call(ADMIN, 'PUT', `${base}/vms/${vmId}`, { hypervisor_id: hvB });
    assert.equal(moved.status, 200, `the move was refused: ${JSON.stringify(moved.body)}`);

    assert.equal(await storedSiteOf(vmId), siteB, 'the VM moved data centres and the column did not');
  });

  test('and the response body already carries the new DC', async (t) => {
    if (guard(t)) return;
    // The grid renders what the PUT hands back. A cache the same statement
    // wrote, reported one refetch later, is a cell that shows the old DC for as
    // long as the operator looks at it.
    const { siteB, hvA, hvB } = await seedTwoDataCentres();
    const vm = await call(ADMIN, 'POST', `${base}/vms`,
      { name: 'kvm1', vm_type: 'ap_host', hypervisor_id: hvA });
    const moved = await call(ADMIN, 'PUT', `${base}/vms/${vm.body.data.id}`, { hypervisor_id: hvB });

    assert.equal(moved.body.data.site_id, siteB, 'the PUT answered with the DC the VM has just left');
  });

  test('a PUT that only names a DC changes nothing', async (t) => {
    if (guard(t)) return;
    // The cache is not an input. A caller who wants a placed VM in another data
    // centre moves it to a host that stands there; there is no second door.
    const { siteA, siteB, hvA } = await seedTwoDataCentres();
    const vm = await call(ADMIN, 'POST', `${base}/vms`,
      { name: 'kvm1', vm_type: 'ap_host', hypervisor_id: hvA });
    const vmId = vm.body.data.id;

    const res = await call(ADMIN, 'PUT', `${base}/vms/${vmId}`, { site_id: siteB });
    assert.equal(res.status, 200, `the update was refused: ${JSON.stringify(res.body)}`);

    assert.equal(
      await storedSiteOf(vmId), siteA,
      'a plain PUT moved a placed VM to a data centre its host does not stand in',
    );
  });

  test('and on a row whose cache already contradicts its host it changes nothing either', async (t) => {
    if (guard(t)) return;
    // WHAT THE PARTIAL PUT DOES WITH A ROW THAT IS ALREADY WRONG, which is the
    // one thing the branch's answer ("keep what the row holds") has to be said
    // out loud about: it neither re-derives from the host nor takes the
    // caller's value. Both of the other two answers are defensible enough to
    // have been written by accident, so the assertion has to be able to tell
    // all three apart — hence a THIRD data centre that only the caller names.
    //
    // WRITTEN BY HAND BECAUSE NOTHING CAN REACH IT ANY MORE, and that is the
    // point of the case rather than a shortcut. Rows in this state were written
    // before the derive existed, and by the derive itself while it answered
    // from a read view — two ordinary concurrent edits were enough, which is
    // the interleaving driven in capacity-lock-order-real-db.test.js. Repairing
    // them is a backfill's job; the remedy is a no-op re-save of the host's
    // Site, pinned further down this file.
    const { siteA, siteB, hvA } = await seedTwoDataCentres();
    const dcC = await call(ADMIN, 'POST', `${base}/sites`, { name: 'DC-C' });
    assert.equal(dcC.status, 200, `the DC-C fixture was refused: ${JSON.stringify(dcC.body)}`);
    const askedFor = dcC.body.data.id;

    const vm = await call(ADMIN, 'POST', `${base}/vms`,
      { name: 'kvm1', vm_type: 'ap_host', hypervisor_id: hvA });
    const vmId = vm.body.data.id;
    await q(`UPDATE \`${tbl('cap_vms')}\` SET site_id = ? WHERE id = ?`, [siteB, vmId]);
    assert.equal(await storedSiteOf(vmId), siteB, 'the premise: the row starts out contradicting its host');
    assert.notEqual(siteA, siteB);
    assert.notEqual(askedFor, siteA);
    assert.notEqual(askedFor, siteB);

    const res = await call(ADMIN, 'PUT', `${base}/vms/${vmId}`, { site_id: askedFor });
    assert.equal(res.status, 200, `the update was refused: ${JSON.stringify(res.body)}`);
    assert.equal(
      await storedSiteOf(vmId), siteB,
      'the partial PUT rewrote the cache of a placed VM: the host\'s own DC means it re-derived, and the '
      + 'DC the caller named means a hand-set value was stored over the placement',
    );
    assert.equal(
      res.body.data.site_id, siteB,
      'the response offered the caller a data centre the row does not hold',
    );
  });

  test('the premise: a host always names a data centre, so nothing derives nothing', async (t) => {
    if (guard(t)) return;
    // Why the "did the host resolve to a data centre" branches in the derive
    // and in the staged Save are DEFENSIVE rather than live: `cap_hypervisors.
    // site_id` is NOT NULL (table-ddls.js), so there is no such thing as a host
    // standing nowhere and no write path can leave a placed VM with nothing to
    // derive from. A case built on one would be measuring a state the product
    // cannot reach.
    const { spec } = await seedTwoDataCentres();
    const before = await countOf(`SELECT COUNT(*) AS n FROM \`${tbl('cap_hypervisors')}\``);
    const res = await call(ADMIN, 'POST', `${base}/hypervisors`, { name: 'host-nowhere', spec_id: spec });
    assert.ok(res.status >= 400, `a host was created with no data centre: ${JSON.stringify(res.body)}`);
    assert.equal(
      await countOf(`SELECT COUNT(*) AS n FROM \`${tbl('cap_hypervisors')}\``), before,
      'the refusal still landed a row',
    );
  });

  test('an unplaced VM\'s intended DC is still editable', async (t) => {
    if (guard(t)) return;
    // Closing the door on a placed VM must not close it on the one case where
    // the column is the only answer there is.
    const { siteA, siteB } = await seedTwoDataCentres();
    const vm = await call(ADMIN, 'POST', `${base}/vms`,
      { name: 'kvm1', vm_type: 'ap_host', site_id: siteA });
    const vmId = vm.body.data.id;

    const res = await call(ADMIN, 'PUT', `${base}/vms/${vmId}`, { site_id: siteB });
    assert.equal(res.status, 200, `the update was refused: ${JSON.stringify(res.body)}`);

    assert.equal(await storedSiteOf(vmId), siteB, 'an unplaced VM could not be re-pinned');
  });
});

// ── The placement canvas ────────────────────────────────────────────────────

describe('the placement canvas moves a VM and its data centre together', () => {
  test('a staged move to a host in another DC rewrites the stored DC', async (t) => {
    if (guard(t)) return;
    const { siteB, hvA, hvB } = await seedTwoDataCentres();
    const vm = await call(ADMIN, 'POST', `${base}/vms`,
      { name: 'kvm1', vm_type: 'ap_host', hypervisor_id: hvA });
    const vmId = vm.body.data.id;

    const res = await call(ADMIN, 'POST', `${base}/placement/apply`, {
      moves: [{ kind: 'vm', id: vmId, from: hvA, to: hvB }],
    });
    assert.equal(res.status, 200, `the apply was refused: ${JSON.stringify(res.body)}`);

    assert.equal(await storedSiteOf(vmId), siteB, 'the canvas moved the VM and left its DC behind');
  });

  test('unplacing keeps the data centre it was last in as the intended one', async (t) => {
    if (guard(t)) return;
    // A VM dragged to the unplaced tray has no host to derive from, and blanking
    // the column would throw away the only thing left saying where the operator
    // meant it to go.
    const { siteB, hvB } = await seedTwoDataCentres();
    const vm = await call(ADMIN, 'POST', `${base}/vms`,
      { name: 'kvm1', vm_type: 'ap_host', hypervisor_id: hvB });
    const vmId = vm.body.data.id;

    const res = await call(ADMIN, 'POST', `${base}/placement/apply`, {
      moves: [{ kind: 'vm', id: vmId, from: hvB, to: null }],
    });
    assert.equal(res.status, 200, `the apply was refused: ${JSON.stringify(res.body)}`);

    assert.equal(await storedSiteOf(vmId), siteB, 'unplacing a VM threw away its intended data centre');
  });
});

// ── A host changes data centre ──────────────────────────────────────────────

describe('moving a host to another data centre takes its VMs along', () => {
  test('every VM on the host follows it', async (t) => {
    if (guard(t)) return;
    // The other direction of the same relation, and the one nothing has ever
    // covered: the VMs do not move, but the data centre they are in changes
    // under them.
    const { siteA, siteB, hvA } = await seedTwoDataCentres();
    const ids = [];
    for (const name of ['kvm1', 'kvm2']) {
      const vm = await call(ADMIN, 'POST', `${base}/vms`,
        { name, vm_type: 'ap_host', hypervisor_id: hvA });
      assert.equal(vm.status, 200, `the VM fixture was refused: ${JSON.stringify(vm.body)}`);
      ids.push(vm.body.data.id);
    }

    const res = await call(ADMIN, 'PUT', `${base}/hypervisors/${hvA}`, { site_id: siteB });
    assert.equal(res.status, 200, `the host edit was refused: ${JSON.stringify(res.body)}`);

    for (const id of ids) {
      assert.equal(await storedSiteOf(id), siteB, 'a VM stayed in the data centre its host has left');
    }
    assert.equal(
      await countOf(`SELECT COUNT(*) AS n FROM \`${tbl('cap_vms')}\` WHERE site_id = ?`, [siteA]), 0,
      'a VM is still pinned to the data centre nothing stands in',
    );
  });

  test('a VM on another host is not dragged along', async (t) => {
    if (guard(t)) return;
    // The cascade is scoped to the host that moved. A statement that forgot the
    // `hypervisor_id` predicate would repin the whole scenario and still pass
    // the case above.
    const { siteA, siteB, hvA, hvB } = await seedTwoDataCentres();
    const onB = await call(ADMIN, 'POST', `${base}/vms`,
      { name: 'kvm-on-b', vm_type: 'ap_host', hypervisor_id: hvB });
    const onA = await call(ADMIN, 'POST', `${base}/vms`,
      { name: 'kvm-on-a', vm_type: 'ap_host', hypervisor_id: hvA });

    await call(ADMIN, 'PUT', `${base}/hypervisors/${hvB}`, { site_id: siteA });

    assert.equal(await storedSiteOf(onB.body.data.id), siteA, 'the moved host\'s VM did not follow it');
    assert.equal(await storedSiteOf(onA.body.data.id), siteA, 'host-a\'s own VM should still be in DC-A');
    // host-a never moved, so its VM's DC is DC-A for its own reason — assert the
    // untouched host itself, which is what a runaway UPDATE would have changed.
    assert.equal(
      (await one(`SELECT site_id FROM \`${tbl('cap_hypervisors')}\` WHERE id = ?`, [hvA])).site_id, siteA,
      'the cascade rewrote a host it was not asked about',
    );
  });

  test('a host edit that does not touch the DC leaves the VMs alone', async (t) => {
    if (guard(t)) return;
    const { siteA, hvA } = await seedTwoDataCentres();
    const vm = await call(ADMIN, 'POST', `${base}/vms`,
      { name: 'kvm1', vm_type: 'ap_host', hypervisor_id: hvA });

    const res = await call(ADMIN, 'PUT', `${base}/hypervisors/${hvA}`, { name: 'host-a-renamed' });
    assert.equal(res.status, 200, `the rename was refused: ${JSON.stringify(res.body)}`);

    assert.equal(await storedSiteOf(vm.body.data.id), siteA);
  });
});

// ── The bulk paths: clone and restore ───────────────────────────────────────

/** Reproduce a row written before the rule existed: the placement says one data
 *  centre and the cache says the other. Direct SQL on this throw-away test
 *  database is the only way to reach a state no write path can produce any
 *  more. */
async function driftTheCache(vmId, siteId) {
  await q(`UPDATE \`${tbl('cap_vms')}\` SET site_id = ? WHERE id = ?`, [siteId, vmId]);
}

/** Every hex letter's case flipped — CHAR(36) ids are digits and a-f letters,
 *  and the column's default collation folds a-f against A-F, so this alone
 *  produces a value collation-EQUAL to the original but byte-different: the
 *  shape `syncVmSiteCache`'s case-sensitive predicate has to catch. */
function flipCase(id) {
  return id.replace(/[a-f]/gi, (c) => (c === c.toLowerCase() ? c.toUpperCase() : c.toLowerCase()));
}

/** `flipCase` needs at least one a-f letter to produce a distinct-but-
 *  collation-equal respelling — a UUID with zero hex letters (astronomically
 *  unlikely from a random generator, but not impossible) has no such
 *  respelling to test, which made the fixture's guard assertion an
 *  unbounded, if vanishingly rare, source of test flakiness. Force one in
 *  deterministically rather than depend on luck: `UUID_RE` (helpers.js) has
 *  no version/variant constraint, so overwriting one character is a valid
 *  id. Both the site's own row and the one hypervisor the caller names are
 *  rewritten so the fixture stays internally consistent. */
async function ensureLetterInSiteId(siteId, hypervisorId) {
  if (/[a-f]/i.test(siteId)) return siteId;
  const seeded = `a${siteId.slice(1)}`;
  await q(`UPDATE \`${tbl('cap_sites')}\` SET id = ? WHERE id = ?`, [seeded, siteId]);
  await q(`UPDATE \`${tbl('cap_hypervisors')}\` SET site_id = ? WHERE id = ?`, [seeded, hypervisorId]);
  return seeded;
}

// ── The remedy for rows written before any of this ──────────────────────────

describe('a legacy drifted row is repaired by re-saving its host\'s data centre', () => {
  test('a no-op re-save of the SAME site repins every VM on that host', async (t) => {
    if (guard(t)) return;
    // NOTHING IN THIS LINE OF WORK BACKFILLS. Every write path now keeps the
    // column in step, which is true only for rows written after it ships — and
    // on deploy the new health finding fires on every legacy contradicting row
    // and flips its scenario's list badge to invalid. This is the operator's
    // remedy, and it is measured here rather than asserted in a comment: the
    // grid re-sends every non-readOnly cell on any row change, so `site_id`
    // lands in the written keys even when the value is unchanged, and
    // `cascadeHypervisorSiteToVms` then repairs that host's VMs.
    const { siteA, siteB, hvA } = await seedTwoDataCentres();
    const ids = [];
    for (const name of ['kvm1', 'kvm2']) {
      const vm = await call(ADMIN, 'POST', `${base}/vms`,
        { name, vm_type: 'ap_host', hypervisor_id: hvA });
      ids.push(vm.body.data.id);
    }
    // Reach the state no write path can produce any more.
    for (const id of ids) await driftTheCache(id, siteB);
    assert.equal(await storedSiteOf(ids[0]), siteB, 'the fixture failed to create the drift');

    // The host is not moved: it is saved with the data centre it already has.
    const res = await call(ADMIN, 'PUT', `${base}/hypervisors/${hvA}`, { site_id: siteA });
    assert.equal(res.status, 200, `the re-save was refused: ${JSON.stringify(res.body)}`);

    for (const id of ids) {
      assert.equal(await storedSiteOf(id), siteA, 'a legacy drifted VM was not repaired by the re-save');
    }
    assert.equal(
      await countOf(`SELECT COUNT(*) AS n FROM \`${tbl('cap_vms')}\` WHERE site_id = ?`, [siteB]), 0,
      'a VM is still pinned to a data centre its host does not stand in',
    );
  });

  test('and it repairs only that host\'s VMs', async (t) => {
    if (guard(t)) return;
    // The remedy is per host, which is what makes it a remedy an operator can
    // reason about — and a cascade that repinned the whole scenario would pass
    // the case above while destroying every unplaced VM's intended site.
    const { siteA, siteB, hvA, hvB } = await seedTwoDataCentres();
    const onA = await call(ADMIN, 'POST', `${base}/vms`,
      { name: 'kvm-on-a', vm_type: 'ap_host', hypervisor_id: hvA });
    const onB = await call(ADMIN, 'POST', `${base}/vms`,
      { name: 'kvm-on-b', vm_type: 'ap_host', hypervisor_id: hvB });
    const unplaced = await call(ADMIN, 'POST', `${base}/vms`,
      { name: 'kvm-unplaced', vm_type: 'ap_host', site_id: siteB });
    await driftTheCache(onA.body.data.id, siteB);
    await driftTheCache(onB.body.data.id, siteA);

    await call(ADMIN, 'PUT', `${base}/hypervisors/${hvA}`, { site_id: siteA });

    assert.equal(await storedSiteOf(onA.body.data.id), siteA, 'the re-saved host\'s VM was not repaired');
    assert.equal(await storedSiteOf(onB.body.data.id), siteA, 'another host\'s drifted VM was repaired without being asked');
    assert.equal(
      await storedSiteOf(unplaced.body.data.id), siteB,
      'an unplaced VM\'s intended site was overwritten by another host\'s re-save',
    );
  });
});

// ── The case-variant half of the legacy contradiction (fmb-1581) ───────────

describe('syncVmSiteCache rewrites a case-respelled site_id, not just a wrong one', () => {
  test('a case-only mismatch is rewritten to the host\'s exact stored spelling', async (t) => {
    if (guard(t)) return;
    // The CHAR(36) collation is case-insensitive, so `v.site_id <=> h.site_id`
    // with no cast reads a respelled id as ALREADY equal and skips the row —
    // while `capacity-scenario-health.ts` builds its site-id `Set` from the
    // real sites' exact-case ids and flags this VM's respelling as a
    // dangling reference ("references a missing datacenter"), since it
    // matches no member of that `Set`. This is that legacy row, reached the
    // only way it still can be: no write path produces it any more.
    const { siteA, hvA } = await seedTwoDataCentres();
    const siteAId = await ensureLetterInSiteId(siteA, hvA);
    const vm = await call(ADMIN, 'POST', `${base}/vms`,
      { name: 'kvm1', vm_type: 'ap_host', hypervisor_id: hvA });
    const vmId = vm.body.data.id;
    const respelled = flipCase(siteAId);
    await q(`UPDATE \`${tbl('cap_vms')}\` SET site_id = ? WHERE id = ?`, [respelled, vmId]);
    assert.equal(await storedSiteOf(vmId), respelled, 'the premise: the row starts out respelled');

    const conn = await pool.getConnection();
    try {
      await syncVmSiteCache(conn, SCENARIO_ID);
    } finally {
      conn.release();
    }

    assert.equal(
      await storedSiteOf(vmId), siteAId,
      'a case-respelled site_id was left in place instead of rewritten to the host\'s exact spelling',
    );
  });

  test('a NULL site_id cache is still filled', async (t) => {
    if (guard(t)) return;
    // Regression pin for the `<=>` fill path: a byte-sensitive comparison must
    // not stop treating an unfilled cache as needing a write.
    const { siteA, hvA } = await seedTwoDataCentres();
    const vm = await call(ADMIN, 'POST', `${base}/vms`,
      { name: 'kvm1', vm_type: 'ap_host', hypervisor_id: hvA });
    const vmId = vm.body.data.id;
    await q(`UPDATE \`${tbl('cap_vms')}\` SET site_id = NULL WHERE id = ?`, [vmId]);
    assert.equal(await storedSiteOf(vmId), null, 'the premise: the cache starts out unfilled');

    const conn = await pool.getConnection();
    try {
      await syncVmSiteCache(conn, SCENARIO_ID);
    } finally {
      conn.release();
    }

    assert.equal(await storedSiteOf(vmId), siteA, 'a NULL site_id cache was not filled');
  });

  test('a row that already matches its host is not rewritten', async (t) => {
    if (guard(t)) return;
    // No rewrite churn on an already-canonical row: asserted on affectedRows,
    // not just on the stored value staying the same.
    const { hvA } = await seedTwoDataCentres();
    await call(ADMIN, 'POST', `${base}/vms`,
      { name: 'kvm1', vm_type: 'ap_host', hypervisor_id: hvA });

    const conn = await pool.getConnection();
    let affected;
    try {
      affected = await syncVmSiteCache(conn, SCENARIO_ID);
    } finally {
      conn.release();
    }

    assert.equal(affected, 0, 'a row that already matches its host was rewritten anyway');
  });
});

describe('a scenario that is copied does not carry a contradiction into the copy', () => {
  test('a clone stores each VM\'s host data centre', async (t) => {
    if (guard(t)) return;
    const { siteA, siteB, hvA } = await seedTwoDataCentres();
    const vm = await call(ADMIN, 'POST', `${base}/vms`,
      { name: 'kvm1', vm_type: 'ap_host', hypervisor_id: hvA });
    await driftTheCache(vm.body.data.id, siteB);

    const clone = await call(ADMIN, 'POST', `/edge/app/capacity/scenarios/${SCENARIO_ID}/clone`,
      { name: 'a copy' });
    assert.equal(clone.status, 201, `the clone was refused: ${JSON.stringify(clone.body)}`);

    // The clone mints new ids for every row, so the assertion is on the
    // RELATION rather than on a known id: no VM in the copy may name a data
    // centre its own host does not stand in. BINARY on both sides, matching
    // `syncVmSiteCache`'s predicate: a bare `<=>` folds case and would call a
    // case-only mismatch "no contradiction" — the exact defect class this PR
    // makes real; the assertion has to use the same definition of "matches"
    // as production or it would pass a clone it should fail.
    const contradictions = await countOf(
      `SELECT COUNT(*) AS n FROM \`${tbl('cap_vms')}\` v
         JOIN \`${tbl('cap_hypervisors')}\` h ON h.id = v.hypervisor_id AND h.scenario_id = v.scenario_id
        WHERE v.scenario_id = ? AND NOT (BINARY v.site_id <=> BINARY h.site_id)`,
      [clone.body.data.id],
    );
    assert.equal(contradictions, 0, 'the clone carries a VM whose data centre disagrees with its host');
    // And the drift really was there to be carried — otherwise the case above
    // passes on a scenario that never had the defect.
    assert.notEqual(siteA, siteB);
  });
});

describe('an import cannot bring a contradiction in from a workbook', () => {
  /** The VMs sheet names a host AND a site independently, so a workbook can say
   *  two different data centres for one KVM and nothing cross-checks them. */
  const sheetsNaming = (vmRow) => ({
    hardware_specs: [{ name: 'spec', cpu_total: 64, mem_total_gb: 512, disk_total_gb: 4096 }],
    sites: [{ name: 'DC-A' }, { name: 'DC-B' }],
    hypervisors: [{ name: 'host-a', site_name: 'DC-A', spec_name: 'spec' }],
    vms: [vmRow],
  });
  const siteIdNamed = async (name) => (await one(
    `SELECT id FROM \`${tbl('cap_sites')}\` WHERE name = ? AND scenario_id = ?`, [name, SCENARIO_ID],
  )).id;

  test('a placed row takes the host\'s data centre, not the sheet\'s', async (t) => {
    if (guard(t)) return;
    const res = await call(ADMIN, 'POST', `${base}/import`, {
      mode: 'commit',
      sheets: sheetsNaming({ name: 'kvm1', vm_type: 'ap_host', hypervisor_name: 'host-a', site_name: 'DC-B' }),
    });
    assert.equal(res.status, 200, `the import was refused: ${JSON.stringify(res.body)}`);

    const vm = await one(`SELECT id, site_id FROM \`${tbl('cap_vms')}\``);
    assert.equal(vm.site_id, await siteIdNamed('DC-A'), 'the import stored the sheet\'s data centre over the host\'s');
  });

  test('an unplaced row keeps the data centre the sheet named', async (t) => {
    if (guard(t)) return;
    // The import is the one path that can legitimately state an intended site
    // in bulk, so the reconcile must not reach a row with no host.
    const res = await call(ADMIN, 'POST', `${base}/import`, {
      mode: 'commit',
      sheets: sheetsNaming({ name: 'kvm1', vm_type: 'ap_host', site_name: 'DC-B' }),
    });
    assert.equal(res.status, 200, `the import was refused: ${JSON.stringify(res.body)}`);

    const vm = await one(`SELECT id, hypervisor_id, site_id FROM \`${tbl('cap_vms')}\``);
    assert.equal(vm.hypervisor_id, null);
    assert.equal(vm.site_id, await siteIdNamed('DC-B'), 'an unplaced imported VM lost its intended data centre');
  });
});

describe('restoring a frozen version does not restore a contradiction', () => {
  test('a restored VM names the data centre of the host it is restored onto', async (t) => {
    if (guard(t)) return;
    const { siteA, siteB, hvA } = await seedTwoDataCentres();
    const vm = await call(ADMIN, 'POST', `${base}/vms`,
      { name: 'kvm1', vm_type: 'ap_host', hypervisor_id: hvA });
    const vmId = vm.body.data.id;
    await driftTheCache(vmId, siteB);

    const version = await call(ADMIN, 'POST', `${base}/versions`, { name: 'v1' });
    assert.equal(version.status, 201, `the freeze was refused: ${JSON.stringify(version.body)}`);
    const restored = await call(ADMIN, 'POST',
      `${base}/versions/${version.body.data.id}/restore`, { confirm: true });
    assert.equal(restored.status, 200, `the restore was refused: ${JSON.stringify(restored.body)}`);

    assert.equal(
      await storedSiteOf(vmId), siteA,
      'the restore replayed a data centre the restored host does not stand in',
    );
  });
});
