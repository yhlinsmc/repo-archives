/**
 * capacity/rule-types.js — the config-rewrite rule-type registry (CJS).
 *
 * The five keeper families = six concrete rule types (spec §13.1). This module
 * is the SEAM that lets the route layer (validateRuleWritePayload in _shared.js)
 * validate a rule write against the new target model WITHOUT depending on the
 * evaluator's internal logic. The evaluator (evaluator.js / evaluator.ts) is
 * rewritten in a later task to import THIS module and delete its old-type map;
 * until then the evaluator keeps its own (old) map and this module is consumed
 * only by the routes. Keep this list + the levels/group-bys authoritative here.
 *
 * Target model (spec §13.4): a rule's target = level + structural group_by +
 * built-in-attribute filters. Each type constrains which levels and group-bys
 * are legal (defense-in-depth over the DB ENUM; the sentence editor already
 * constrains the UI).
 */
'use strict';

// The six concrete rule types (five families; "Density limit" = two types).
const RULE_TYPES = Object.freeze([
  'no-oversell',
  'max-vms-per-host',
  'max-instances-per-vm',
  'keep-apart',
  'spread-across-sites',
  'keep-in-one-site',
]);

// Legal `level` per type (spec §13.1 table + §13.4). Built-ins are hypervisor-
// level; the density VM check is vm-level; the relational rules are db_instance-
// level (they reach db-host VMs through the cluster the instance belongs to).
const RULE_LEGAL_LEVELS = Object.freeze({
  'no-oversell': ['hypervisor'],
  'max-vms-per-host': ['hypervisor'],
  'max-instances-per-vm': ['vm'],
  'keep-apart': ['db_instance'],
  'spread-across-sites': ['db_instance'],
  'keep-in-one-site': ['db_instance'],
});

// The structural group-bys (spec §13.4). Relational rules target a structural
// group; built-ins + the density rules target the whole class (all_of_type).
const RELATIONAL_GROUP_BYS = Object.freeze([
  'each_database', 'each_primary_cluster', 'each_standby_cluster', 'all_of_type', 'custom_group',
]);

const RULE_LEGAL_GROUP_BYS = Object.freeze({
  'no-oversell': ['all_of_type'],
  'max-vms-per-host': ['all_of_type'],
  'max-instances-per-vm': ['all_of_type'],
  'keep-apart': RELATIONAL_GROUP_BYS,
  'spread-across-sites': RELATIONAL_GROUP_BYS,
  'keep-in-one-site': RELATIONAL_GROUP_BYS,
});

// The default global rule template (spec §13.1a): six rows, all-hard, all-on,
// with the explicit non-conflicting targets. Seeded ONCE as global template
// rows (scenario_id NULL); scenarios reference this template (reference model —
// no per-scenario copy). Params carry each type's tunables. `name` uses the UI
// vocabulary (§13.1/§13.2). This is the single source the seed migration reads.
// Phase-2 spec §6.2/§11: an each_standby_cluster keep-apart row joins the
// existing each_primary_cluster one so a same-VM standby collapse (C2's
// generalized per-instance placement) is flagged out of the box, matching
// the primary case. Same severity as the primary keep-apart; no evaluator
// change needed — each_standby_cluster is already a legal keep-apart group_by.
// `enabled` is stated rather than left to the column's default, because this
// list is compared against STORED rows to decide whether the seeded template is
// still untouched — and turning a default rule off is the likeliest edit an
// operator makes. A template entry that stays silent about the column would
// leave that comparison unable to tell "still seeded" from "switched off".
const DEFAULT_RULE_TEMPLATE = Object.freeze([
  { type: 'no-oversell', name: 'No oversell', level: 'hypervisor', group_by: 'all_of_type', params: { resources: ['cpu', 'mem', 'disk'] }, severity: 'hard', enabled: true },
  { type: 'max-vms-per-host', name: 'Max VMs per host', level: 'hypervisor', group_by: 'all_of_type', params: { max: 8 }, severity: 'hard', enabled: true },
  { type: 'max-instances-per-vm', name: 'Max instances per VM', level: 'vm', group_by: 'all_of_type', params: { max: 4 }, severity: 'hard', enabled: true },
  { type: 'keep-apart', name: 'Keep apart', level: 'db_instance', group_by: 'each_primary_cluster', params: {}, severity: 'hard', enabled: true },
  { type: 'keep-apart', name: 'Keep apart (standby)', level: 'db_instance', group_by: 'each_standby_cluster', params: {}, severity: 'hard', enabled: true },
  { type: 'keep-in-one-site', name: 'Keep in one site', level: 'db_instance', group_by: 'each_primary_cluster', params: {}, severity: 'hard', enabled: true },
  { type: 'spread-across-sites', name: 'Spread across sites', level: 'db_instance', group_by: 'each_database', params: { min_sites: 2 }, severity: 'hard', enabled: true },
]);

module.exports = {
  RULE_TYPES,
  RULE_LEGAL_LEVELS,
  RULE_LEGAL_GROUP_BYS,
  RELATIONAL_GROUP_BYS,
  DEFAULT_RULE_TEMPLATE,
};
