/**
 * forwarding.js — All edge-forwarding proxy route mounts + OpenAPI JSDoc.
 *
 * Extracted from index-infra.js for single-responsibility.
 * Each route here forwards to API-edge via createForwardingProxy.
 */
const express = require('express');
const { createForwardingProxy, createRawBodyForwardingProxy, forwardToEdge, passthroughResponse } = require('./lib/remote-client');
const mountConnectorFetch = require('./routes/connector-fetch');
const mountFlowStepDispatch = require('./routes/flow-step-dispatch');
const mountFlowRecipeRun = require('./routes/flow-recipe-run');

/**
 * Mount auth-specific forwarding routes.
 * Called AFTER auth + access-check middleware, BEFORE authSessionRoutes.
 *
 * Ordering contract (load-bearing):
 *   1. mountAuthForwarding(app)     — specific auth paths to edge
 *   2. app.use('/api/auth', authSessionRoutes)  — infra-local (/me, GET /mode)
 *   3. mountRemainingRoutes(app)    — audit catch-all + all other routes
 *
 * @param {import('express').Express} app
 */
function mountAuthForwarding(app) {
  // NOTE: /api/auth/sessions is on edge (DB access belongs on edge).
  // Must be mounted BEFORE auth session routes so it wins route matching.
  app.use('/api/auth/sessions', createForwardingProxy('/edge/platform/auth/sessions'));

  // NOTE: auth split — password/DB routes forwarded to edge,
  // session/identity routes handled directly by infra.
  // Order matters: specific paths before the general /api/auth mount.
  app.use('/api/auth/login', createForwardingProxy('/edge/platform/auth-password/login'));
  app.use('/api/auth/change-password', createForwardingProxy('/edge/platform/auth-password/change-password'));
  app.use('/api/auth/diagnostics/details', createForwardingProxy('/edge/platform/auth-password/diagnostics/details'));
  // PUT /api/auth/mode → edge (DB write); GET /api/auth/mode → infra (session context)
  // Use app.use so req.path resolves to '/' inside the proxy handler — matches
  // the Express convention createForwardingProxy assumes (see remote-client.js).
  // Restrict to PUT via inline method guard. app.put leaves req.path='/api/auth/mode'
  // which produces fullPath='/edge/platform/auth-password/mode/api/auth/mode' → edge 404.
  app.use('/api/auth/mode', (req, res, next) => {
    if (req.method !== 'PUT') return next();
    return createForwardingProxy('/edge/platform/auth-password/mode')(req, res, next);
  });
  // GET /api/auth/:id/is-admin → edge (DB query). Custom handler because
  // createForwardingProxy doesn't propagate Express route params.
  // NOTE: use passthroughResponse to inherit the forwarding proxy's
  // Content-Type / header passthrough contract.
  app.get('/api/auth/:id/is-admin', async (req, res, next) => {
    try {
      const result = await forwardToEdge({
        method: 'GET',
        // SECURITY: encode the param. Express has already decoded `:id` once,
        // so `%2f` is a real '/' by now — interpolating it raw lets the client
        // add segments to the upstream path, and the guard cannot catch that
        // one: with no declared prefix it compares the built path against
        // itself. Encoding here keeps the id one segment; do not instead pass a
        // shorter pathPrefix, which would widen what this site accepts.
        path: `/edge/platform/auth-password/${encodeURIComponent(req.params.id)}/is-admin`,
        user: req.user,
        query: req.query,
        headers: req.headers['authorization'] ? { authorization: req.headers['authorization'] } : {},
      });
      passthroughResponse(res, result);
    } catch (err) {
      next(err);
    }
  });
}

/**
 * Mount remaining forwarding routes (audit catch-all + all non-auth routes).
 * Called AFTER authSessionRoutes so infra-local auth routes win matching.
 *
 * @param {import('express').Express} app
 */
function mountRemainingRoutes(app) {
  /**
   * @openapi
   * /api/auth/audit-log:
   *   post:
   *     summary: Record a login event
   *     tags: [Audit]
   *     description: Forwards to API-edge /edge/platform/audit/audit-log
   *     requestBody:
   *       content: { application/json: { schema: { type: object, required: [username], properties: { username: { type: string }, success: { type: boolean }, reason: { type: string } } } } }
   *     responses: { 200: { description: Logged, content: { application/json: { schema: { $ref: '#/components/schemas/ApiResponse' } } } } }
   */
  app.use('/api/auth', createForwardingProxy('/edge/platform/audit')); // → edge

  /**
   * @openapi
   * /api/system-settings:
   *   get:
   *     summary: List all system settings
   *     tags: [System Settings]
   *     responses: { 200: { description: Settings list, content: { application/json: { schema: { $ref: '#/components/schemas/ApiResponse' } } } } }
   *   put:
   *     summary: Bulk upsert settings
   *     tags: [System Settings]
   *     responses: { 200: { description: Updated } }
   */
  app.use('/api/system-settings', createForwardingProxy('/edge/platform/settings')); // → edge

  /**
   * @openapi
   * /api/db-connections:
   *   get:
   *     summary: List DB connection profiles
   *     tags: [DB Connections]
   *     responses: { 200: { description: Connection list, content: { application/json: { schema: { $ref: '#/components/schemas/ApiResponse' } } } } }
   *   post:
   *     summary: Create connection profile
   *     tags: [DB Connections]
   *     responses: { 200: { description: Created } }
   * /api/db-connections/test:
   *   post:
   *     summary: Test connection credentials
   *     tags: [DB Connections]
   *     responses: { 200: { description: Connection test result } }
   * /api/db-connections/{id}:
   *   get:
   *     summary: Get connection profile
   *     tags: [DB Connections]
   *     parameters: [{ name: id, in: path, required: true, schema: { type: string } }]
   *     responses: { 200: { description: Profile } }
   *   put:
   *     summary: Update connection profile
   *     tags: [DB Connections]
   *     parameters: [{ name: id, in: path, required: true, schema: { type: string } }]
   *     responses: { 200: { description: Updated } }
   *   delete:
   *     summary: Delete connection profile
   *     tags: [DB Connections]
   *     parameters: [{ name: id, in: path, required: true, schema: { type: string } }]
   *     responses: { 200: { description: Deleted } }
   * /api/db-connections/{id}/activate:
   *   post:
   *     summary: Activate a connection profile
   *     tags: [DB Connections]
   *     parameters: [{ name: id, in: path, required: true, schema: { type: string } }]
   *     responses: { 200: { description: Activated } }
   */
  app.use('/api/db-connections', createForwardingProxy('/edge/platform/connections')); // → edge

  /**
   * @openapi
   * /api/users:
   *   get:
   *     summary: List all users (admin)
   *     tags: [Users]
   *     responses: { 200: { description: User list, content: { application/json: { schema: { $ref: '#/components/schemas/ApiResponse' } } } } }
   *   post:
   *     summary: Create user or dispatch action
   *     tags: [Users]
   *     responses: { 200: { description: Action completed } }
   * /api/users/{id}/ban:
   *   post:
   *     summary: Ban/unban user
   *     tags: [Users]
   *     parameters: [{ name: id, in: path, required: true, schema: { type: string } }]
   *     responses: { 200: { description: Updated } }
   * /api/users/{id}/role:
   *   put:
   *     summary: Update user role
   *     tags: [Users]
   *     parameters: [{ name: id, in: path, required: true, schema: { type: string } }]
   *     responses: { 200: { description: Role updated } }
   * /api/users/{id}/reset-password:
   *   put:
   *     summary: Reset user password (admin)
   *     tags: [Users]
   *     parameters: [{ name: id, in: path, required: true, schema: { type: string } }]
   *     responses: { 200: { description: Password reset } }
   */
  app.use('/api/users', createForwardingProxy('/edge/platform/users')); // → edge

  /**
   * @openapi
   * /api/query-proxy:
   *   post:
   *     summary: Execute raw SQL query (admin only)
   *     tags: [Query Proxy]
   *     requestBody:
   *       content: { application/json: { schema: { type: object, properties: { sql: { type: string }, params: { type: array } } } } }
   *     responses: { 200: { description: Query result, content: { application/json: { schema: { $ref: '#/components/schemas/ApiResponse' } } } } }
   */
  app.use('/api/query-proxy', createForwardingProxy('/edge/platform/query')); // → edge

  /**
   * @openapi
   * /api/schema/{table}:
   *   get:
   *     summary: List records from an engine table
   *     tags: [Schema CRUD]
   *     parameters: [{ name: table, in: path, required: true, schema: { type: string } }]
   *     responses: { 200: { description: Record list, content: { application/json: { schema: { $ref: '#/components/schemas/ApiResponse' } } } } }
   *   post:
   *     summary: Create a record
   *     tags: [Schema CRUD]
   *     parameters: [{ name: table, in: path, required: true, schema: { type: string } }]
   *     responses: { 201: { description: Created } }
   * /api/schema/{table}/{id}:
   *   get:
   *     summary: Get record by ID
   *     tags: [Schema CRUD]
   *     parameters: [{ name: table, in: path, required: true, schema: { type: string } }, { name: id, in: path, required: true, schema: { type: string } }]
   *     responses: { 200: { description: Record } }
   *   put:
   *     summary: Update record
   *     tags: [Schema CRUD]
   *     parameters: [{ name: table, in: path, required: true, schema: { type: string } }, { name: id, in: path, required: true, schema: { type: string } }]
   *     responses: { 200: { description: Updated } }
   *   delete:
   *     summary: Delete record
   *     tags: [Schema CRUD]
   *     parameters: [{ name: table, in: path, required: true, schema: { type: string } }, { name: id, in: path, required: true, schema: { type: string } }]
   *     responses: { 200: { description: Deleted } }
   */
  // NOTE: YAML round-trip blueprint import requires raw text/yaml body
  // forwarding (the default JSON-encoding proxy would corrupt the body).
  // Mount BEFORE the generic /api/schema proxy so this specific path wins
  // route matching. express.text() captures the body as a string for
  // createRawBodyForwardingProxy to forward verbatim.
  app.use(
    '/api/schema/blueprint-import-yaml',
    express.text({ type: ['text/yaml', 'application/yaml', 'application/x-yaml'], limit: '256kb' }),
    createRawBodyForwardingProxy('/edge/app/schema/blueprint-import-yaml'),
  );
  app.use('/api/schema', createForwardingProxy('/edge/app/schema')); // → edge

  /**
   * @openapi
   * /api/sync-schema:
   *   post:
   *     summary: Sync schema and data from external source
   *     tags: [Sync Schema]
   *     responses: { 200: { description: Sync result } }
   * /api/sync-schema/status:
   *   get:
   *     summary: Get row counts for all engine tables
   *     tags: [Sync Schema]
   *     responses: { 200: { description: Table status, content: { application/json: { schema: { $ref: '#/components/schemas/ApiResponse' } } } } }
   * /api/sync-schema/export-sql:
   *   get:
   *     summary: Export DDL + data as SQL with __PREFIX__ placeholders
   *     tags: [Sync Schema]
   *     responses: { 200: { description: SQL export } }
   * /api/sync-schema/import-sql:
   *   post:
   *     summary: Import SQL with prefix substitution
   *     tags: [Sync Schema]
   *     responses: { 200: { description: Import result } }
   * /api/sync-schema/truncate-table:
   *   post:
   *     summary: Truncate an engine table
   *     tags: [Sync Schema]
   *     responses: { 200: { description: Table truncated } }
   */
  app.use('/api/sync-schema', createForwardingProxy('/edge/app/sync-schema')); // → edge

  /**
   * @openapi
   * /api/export/mariadb-sql:
   *   get:
   *     summary: Export engine tables as MariaDB SQL seed file
   *     tags: [Export]
   *     parameters: [{ name: tablePrefix, in: query, schema: { type: string } }]
   *     responses: { 200: { description: SQL download } }
   */
  app.use('/api/export', createForwardingProxy('/edge/platform/export')); // → edge

  /**
   * @openapi
   * /api/transformers:
   *   get:
   *     summary: List all transformers
   *     tags: [Transformers]
   *     responses: { 200: { description: Transformer list, content: { application/json: { schema: { $ref: '#/components/schemas/ApiResponse' } } } } }
   *   post:
   *     summary: Create transformer
   *     tags: [Transformers]
   *     responses: { 201: { description: Created } }
   * /api/transformers/{id}:
   *   get:
   *     summary: Get transformer by ID
   *     tags: [Transformers]
   *     parameters: [{ name: id, in: path, required: true, schema: { type: string } }]
   *     responses: { 200: { description: Transformer } }
   *   put:
   *     summary: Update transformer (optimistic lock)
   *     tags: [Transformers]
   *     parameters: [{ name: id, in: path, required: true, schema: { type: string } }]
   *     responses: { 200: { description: Updated } }
   *   delete:
   *     summary: Delete transformer
   *     tags: [Transformers]
   *     parameters: [{ name: id, in: path, required: true, schema: { type: string } }]
   *     responses: { 200: { description: Deleted } }
   * /api/transformers/{id}/versions:
   *   get:
   *     summary: Get version history
   *     tags: [Transformers]
   *     parameters: [{ name: id, in: path, required: true, schema: { type: string } }]
   *     responses: { 200: { description: Version list } }
   * /api/transformers/{id}/rollback/{ver}:
   *   put:
   *     summary: Rollback to version
   *     tags: [Transformers]
   *     parameters: [{ name: id, in: path, required: true, schema: { type: string } }, { name: ver, in: path, required: true, schema: { type: integer } }]
   *     responses: { 200: { description: Rolled back } }
   * /api/transformers/{id}/export:
   *   get:
   *     summary: Export transformer as JSON
   *     tags: [Transformers]
   *     parameters: [{ name: id, in: path, required: true, schema: { type: string } }]
   *     responses: { 200: { description: JSON export } }
   * /api/transformers/{id}/clone:
   *   post:
   *     summary: Clone transformer
   *     tags: [Transformers]
   *     parameters: [{ name: id, in: path, required: true, schema: { type: string } }]
   *     responses: { 201: { description: Cloned } }
   * /api/transformers/import:
   *   post:
   *     summary: Import transformer from JSON
   *     tags: [Transformers]
   *     responses: { 201: { description: Imported } }
   */
  app.use('/api/transformers', createForwardingProxy('/edge/app/transformers')); // → edge
  // Connector dispatch is owned by infra (origin routing happens via the edge
  // internal /prepare endpoint). Mount the specific /:id/fetch handler BEFORE
  // the blanket CRUD forward so it wins route matching; CRUD/usable/io still
  // forward to edge.
  mountConnectorFetch(app);
  app.use('/api/api-connectors', createForwardingProxy('/edge/app/api-connectors')); // → edge

  // Flow-recipes family. Mount the dispatch action and the server-run handler
  // BEFORE the blanket CRUD forward so specific POST /:id/dispatch and
  // POST /:id/run routes win over the generic proxy.
  mountFlowStepDispatch(app);
  mountFlowRecipeRun(app);
  app.use('/api/flow-recipes', createForwardingProxy('/edge/app/flow-recipes')); // → edge
  app.use('/api/flow-recipe-steps', createForwardingProxy('/edge/app/flow-recipe-steps')); // → edge
  app.use('/api/flow-recipe-runs', createForwardingProxy('/edge/app/flow-recipe-runs')); // → edge

  // Capacity Planner. Whole subtree (config + scenarios + scenario-scoped
  // children) forwards to edge under a single mount.
  app.use('/api/app/capacity', createForwardingProxy('/edge/app/capacity')); // → edge

  /**
   * @openapi
   * /api/delegated-grants:
   *   get:
   *     summary: Who holds delegated access to one subject
   *     tags: [Delegated Grants]
   *     responses: { 200: { description: Grant list } }
   *   post:
   *     summary: Grant one person access to one subject
   *     tags: [Delegated Grants]
   *     responses: { 201: { description: Granted } }
   * /api/delegated-grants/{id}:
   *   delete:
   *     summary: Revoke one grant
   *     tags: [Delegated Grants]
   *     parameters: [{ name: id, in: path, required: true, schema: { type: string } }]
   *     responses: { 200: { description: Revoked } }
   */
  app.use('/api/delegated-grants', createForwardingProxy('/edge/app/delegated-grants')); // → edge

  /**
   * @openapi
   * /api/template-activity/{templateId}:
   *   get:
   *     summary: One page of a record's activity trail
   *     tags: [Template Activity]
   *     parameters: [{ name: templateId, in: path, required: true, schema: { type: string } }]
   *     responses: { 200: { description: Trail page } }
   * /api/template-activity/{templateId}/generated:
   *   post:
   *     summary: Record that output was produced for a record
   *     tags: [Template Activity]
   *     parameters: [{ name: templateId, in: path, required: true, schema: { type: string } }]
   *     responses: { 200: { description: Recorded, or dropped } }
   */
  app.use('/api/template-activity', createForwardingProxy('/edge/app/template-activity')); // → edge

  /**
   * @openapi
   * /api/access-rules:
   *   get:
   *     summary: List access rules
   *     tags: [Access Rules]
   *     responses: { 200: { description: Rules list, content: { application/json: { schema: { $ref: '#/components/schemas/ApiResponse' } } } } }
   *   post:
   *     summary: Create access rule
   *     tags: [Access Rules]
   *     responses: { 200: { description: Created } }
   * /api/access-rules/{id}:
   *   put:
   *     summary: Update access rule
   *     tags: [Access Rules]
   *     parameters: [{ name: id, in: path, required: true, schema: { type: string } }]
   *     responses: { 200: { description: Updated } }
   *   delete:
   *     summary: Delete access rule
   *     tags: [Access Rules]
   *     parameters: [{ name: id, in: path, required: true, schema: { type: string } }]
   *     responses: { 200: { description: Deleted } }
   */
  app.use('/api/access-rules', createForwardingProxy('/edge/platform/access-rules')); // → edge

  // NOTE: /api/users-create is a forwarding alias → /edge/platform/users.
  app.use('/api/users-create', createForwardingProxy('/edge/platform/users')); // → edge

  /**
   * @openapi
   * /api/admin/feature-audit:
   *   get:
   *     summary: Paginated feature audit tail (admin only)
   *     tags: [Admin]
   *     responses: { 200: { description: Event list } }
   *   post:
   *     summary: Append a feature audit event (admin only)
   *     tags: [Admin]
   *     responses: { 200: { description: Recorded } }
   * /api/admin/debug/dto-mapper/{table}:
   *   get:
   *     summary: Diagnostic — show raw vs mapped row + per-column transforms
   *     tags: [Admin]
   *     parameters:
   *       - { name: table,  in: path,  required: true, schema: { type: string } }
   *       - { name: row_id, in: query, required: true, schema: { type: string } }
   *     responses: { 200: { description: Diagnostic payload } }
   */
  app.use('/api/admin/feature-audit', createForwardingProxy('/edge/platform/feature-audit')); // → edge
  app.use('/api/admin/debug',         createForwardingProxy('/edge/platform/debug'));         // → edge

  /**
   * NOTE: DB-layer GRANT/REVOKE UI — standard S2S forwarding; the edge route
   * is admin-gated and self-guarded, and privileges.js is only mounted on edge.
   *
   * @openapi
   * /api/admin/privileges/current-user:
   *   get:
   *     summary: Current MariaDB session + GRANT OPTION status
   *     tags: [Admin - Privileges]
   *     responses: { 200: { description: Current user + grants } }
   * /api/admin/privileges/users:
   *   get:
   *     summary: Enumerate MariaDB users
   *     tags: [Admin - Privileges]
   *     responses: { 200: { description: User list } }
   * /api/admin/privileges/grants/{user}:
   *   get:
   *     summary: SHOW GRANTS for a specific user
   *     tags: [Admin - Privileges]
   *     parameters: [{ name: user, in: path, required: true, schema: { type: string } }]
   *     responses: { 200: { description: Parsed grants } }
   * /api/admin/privileges/grant:
   *   post:
   *     summary: GRANT DML privileges on infrastructure + engine tables to a MariaDB user
   *     tags: [Admin - Privileges]
   *     responses:
   *       200: { description: All grants succeeded }
   *       207: { description: Partial success }
   *       409: { description: Self-guarded target }
   * /api/admin/privileges/revoke:
   *   post:
   *     summary: REVOKE DML privileges from a MariaDB user
   *     tags: [Admin - Privileges]
   *     responses:
   *       200: { description: All revokes succeeded }
   *       207: { description: Partial success }
   *       409: { description: Self-guarded target }
   * /api/admin/privileges/audit:
   *   get:
   *     summary: Privileges audit tail (paginated, filterable)
   *     tags: [Admin - Privileges]
   *     responses: { 200: { description: Event list } }
   */
  app.use('/api/admin/privileges', createForwardingProxy('/edge/platform/privileges')); // → edge

  /**
   * NOTE: visibility surface admin endpoint — strictly separated from /health
   * (public); this surface is admin-only and live-derived.
   *
   * @openapi
   * /api/platform/schema/status:
   *   get:
   *     summary: Live-derived platform schema-migration health (admin only)
   *     tags: [Platform - Schema Status]
   *     parameters:
   *       - { name: source, in: query, required: false, schema: { type: string, enum: [ui] } }
   *     responses:
   *       200: { description: Derived schema status }
   *       403: { description: Admin required }
   * /api/platform/schema/proceed-anyway:
   *   post:
   *     summary: Admin override for failed schema-status DB switch
   *     tags: [Platform - Schema Status]
   *     responses:
   *       200: { description: Audit row written }
   *       400: { description: Validation error }
   *       403: { description: Admin required }
   */
  app.use('/api/platform/schema/status',          createForwardingProxy('/edge/platform/schema-status'));
  app.use('/api/platform/schema/proceed-anyway',  createForwardingProxy('/edge/platform/schema-status/proceed-anyway'));
  app.use('/api/platform/schema/export-sql',      createForwardingProxy('/edge/platform/schema-export-sql'));

  /**
   * @openapi
   * /api/admin/service-accounts:
   *   get:
   *     summary: List service accounts (admin only, never returns token_hash or the plaintext token)
   *     tags: [Admin - Service Accounts]
   *     responses: { 200: { description: Service account list } }
   *   post:
   *     summary: Register a service account for an app-issued API key
   *     tags: [Admin - Service Accounts]
   *     responses: { 200: { description: Registered — returns token_prefix only, never the token } }
   * /api/admin/service-accounts/hierarchy-roots:
   *   get:
   *     summary: Bounded hierarchy-node directory feeding the register-dialog picker
   *     tags: [Admin - Service Accounts]
   *     responses: { 200: { description: Hierarchy node list } }
   * /api/admin/service-accounts/{id}/rotate:
   *   post:
   *     summary: Rotate a service account's token (re-hash + replace token_prefix)
   *     tags: [Admin - Service Accounts]
   *     parameters: [{ name: id, in: path, required: true, schema: { type: string } }]
   *     responses: { 200: { description: Rotated — returns the new token_prefix only } }
   * /api/admin/service-accounts/{id}/deactivate:
   *   post:
   *     summary: Deactivate a service account (is_active=0); blocks resolves immediately
   *     tags: [Admin - Service Accounts]
   *     parameters: [{ name: id, in: path, required: true, schema: { type: string } }]
   *     responses: { 200: { description: Deactivated } }
   */
  app.use('/api/admin/service-accounts', createForwardingProxy('/edge/platform/service-accounts')); // → edge
}

module.exports = { mountAuthForwarding, mountRemainingRoutes };
