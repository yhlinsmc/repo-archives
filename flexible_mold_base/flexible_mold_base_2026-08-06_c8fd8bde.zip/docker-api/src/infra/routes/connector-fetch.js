/**
 * connector-fetch.js — infra-side handler for POST /api/api-connectors/:id/fetch.
 *
 * Asks edge to prepare the dispatch (the only infra→edge S2S direction). For
 * edge-origin, edge already executed — pass the envelope through. For infra-
 * origin, edge returns the assembled request + an edge-pinned IP; infra runs the
 * socket against that pinned IP (no re-resolve → no DNS-rebinding window),
 * re-validating the pin defensively, then reports the outcome back to edge for
 * the audit close.
 *
 * BOUNDARY: imports only from shared/lib + infra/lib — never edge/. No DB access.
 * SECURITY: prepared.headers carries the injected auth secret; it is used to
 * build the outbound request and is never logged.
 */
const { forwardToEdge, passthroughResponse } = require('../lib/remote-client');
const { executeRequest } = require('../../shared/lib/connector-http');
const { isBlockedIp } = require('../../shared/lib/ssrf-guard');
const { apiOk, apiError, requireAuth } = require('../../shared/helpers');
const { logger: rootLogger } = require('../../shared/lib/logger');

const logger = rootLogger.child({ module: 'infra-connector-fetch' });

const ERROR_STATUS = { SSRF_BLOCKED: 422, CONNECTOR_TIMEOUT: 504, CONNECTOR_RESPONSE_TOO_LARGE: 502, CONNECTOR_UNREACHABLE: 502, BAD_CONNECTOR_URL: 422 };

function hostOf(url) { try { return new URL(url).host; } catch { return null; } }

// Best-effort audit close. A failure here does NOT change the client response
// (the user's data is valid); the pending audit row simply stays open.
async function reportResult(user, body, reqId) {
  try {
    await forwardToEdge({
      method: 'POST', path: '/edge/internal/connectors/result', user, body,
      ...(reqId ? { headers: { 'x-request-id': reqId } } : {}),
    });
  } catch (e) {
    logger.warn({ err: e, connectorId: body.connector_id }, 'connector result report failed id=' + body.connector_id);
  }
}

function mountConnectorFetch(app) {
  app.post('/api/api-connectors/:id/fetch', async (req, res) => {
    if (!requireAuth(req, res)) return;
    // Connector-level authorization is enforced by edge /prepare (it loads and
    // validates the connector); this tier only requires an authenticated caller.
    const inputs = (req.body && req.body.inputs) || {};
    const test = (req.body && req.body.test) === true;
    try {
      const prep = await forwardToEdge({
        method: 'POST', path: '/edge/internal/connectors/prepare', user: req.user,
        body: { connector_id: req.params.id, inputs, test }, reqPath: req.originalUrl,
        ...(req.id ? { headers: { 'x-request-id': req.id } } : {}),
      });
      if (prep.status !== 200) return passthroughResponse(res, prep);

      const data = (prep.data && prep.data.data) || {};
      // SECURITY: use edge-decided data.test, never raw req.body.test — edge re-derives the flag
      // against the admin role, so only a verified admin can tag audit rows and bypass the breaker.
      const isTest = data.test === true;
      if (data.mode === 'edge') return res.json(apiOk(data.envelope));

      if (data.mode !== 'infra' || !data.prepared) {
        const e = apiError('Malformed prepare response', 'INTERNAL_ERROR', 502);
        return res.status(e.status).json(e.body);
      }

      const p = data.prepared;
      if (!p.pinned_ip || !p.family || !p.url || !p.method) {
        const e = apiError('Malformed prepared request', 'INTERNAL_ERROR', 502);
        return res.status(e.status).json(e.body);
      }
      // Defense in depth: never connect to a pin that classifies as blocked.
      if (isBlockedIp(p.pinned_ip)) {
        await reportResult(req.user, { dispatch_id: data.dispatch_id, connector_id: req.params.id, success: false, error_code: 'SSRF_BLOCKED', host: hostOf(p.url), method: p.method, test: isTest }, req.id);
        const e = apiError('Connector request failed', 'SSRF_BLOCKED', 422);
        return res.status(e.status).json(e.body);
      }

      // Pin: connect to the edge-resolved IP; keep the hostname for TLS SNI.
      // all-aware: Node's autoSelectFamily (default on, Node 20+) calls the
      // lookup with { all: true } and expects the array form.
      const pinnedLookup = (_host, options, cb) => {
        const callback = typeof options === 'function' ? options : cb;
        const wantAll = !!(options && typeof options === 'object' && options.all);
        if (wantAll) return callback(null, [{ address: p.pinned_ip, family: p.family }]);
        return callback(null, p.pinned_ip, p.family);
      };

      try {
        const out = await executeRequest(
          { method: p.method, url: p.url, headers: p.headers, body: p.body },
          { lookup: pinnedLookup, timeoutMs: p.timeout_ms, maxBytes: p.max_bytes },
        );
        await reportResult(req.user, { dispatch_id: data.dispatch_id, connector_id: req.params.id, success: true, upstream_status: out.upstream_status, duration_ms: out.duration_ms, host: hostOf(p.url), method: p.method, test: isTest }, req.id);
        return res.json(apiOk(out));
      } catch (de) {
        logger.warn({ err: de, connectorId: req.params.id }, 'infra connector execute failed id=' + req.params.id);
        await reportResult(req.user, { dispatch_id: data.dispatch_id, connector_id: req.params.id, success: false, error_code: de.code || 'CONNECTOR_ERROR', host: hostOf(p.url), method: p.method, test: isTest }, req.id);
        const status = ERROR_STATUS[de.code] || 502;
        const e = apiError('Connector request failed', de.code || 'CONNECTOR_ERROR', status);
        return res.status(e.status).json(e.body);
      }
    } catch (err) {
      logger.error({ err, connectorId: req.params.id }, 'infra connector fetch failed id=' + req.params.id);
      const e = apiError('Dispatch failed', 'INTERNAL_ERROR', 500);
      res.status(e.status).json(e.body);
    }
  });
}

module.exports = mountConnectorFetch;
