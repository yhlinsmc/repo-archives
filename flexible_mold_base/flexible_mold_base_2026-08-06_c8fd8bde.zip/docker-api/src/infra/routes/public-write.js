/**
 * public-write.js — Public Integration API write surface (infra, namespace
 * /api/public/v1). Mounted AFTER public-gate (machine-tier Bearer gate sets
 * req.machinePrincipal) and AFTER the shared post-auth public limiter. This
 * router only forwards S2S to the edge create handler (infra-talks-to-edge-only:
 * no DB here) carrying the machine principal contract + the JSON body + the
 * Idempotency-Key header, and maps edge results to the public error model [M4].
 *
 * The router matches ONLY POST /templates and otherwise falls through (next), so
 * a GET under /api/public/v1 continues on to the public-read router mounted after
 * it. The shared limiter is mounted ONCE at the namespace (index-infra) — never
 * inside this router — so reads and writes share a single per-account budget
 * (plan decision 3) and a read is not double-counted while passing through.
 *
 * A dedicated failed-owner-lookup limiter [P3-HIGH] runs FIRST but ONLY for
 * requests that carry `owner_username` (the username-existence probe), so plain
 * creates are untouched and only failed owner lookups burn its budget.
 *
 * Endpoints:
 *   POST /templates    create a template shell from a hierarchy name-path (§6)
 */
const express = require('express');
const { forwardToEdge } = require('../lib/remote-client');
const { createOwnerLookupFailLimiter } = require('../limiters');
const {
  isPublicErrorCode,
  upstreamErrorCode,
  publicMappingForInternalCode,
} = require('../../shared/lib/public-errors');
const { logger: rootLogger } = require('../../shared/lib/logger');

const logger = rootLogger.child({ module: 'public-write-infra' });
const router = express.Router();

const EDGE_BASE = '/edge/internal/public-write';

// Edge statuses whose public `error` code is relayed verbatim. Mirrors the
// public-read relay so a genuine auth/scope/validation rejection surfaces as its
// public code rather than being masked as an outage; the isPublicErrorCode guard
// still prevents any internal code/meta from leaking.
const RELAYABLE_STATUSES = new Set([400, 401, 404, 409]);

// Anti-enumeration limiter for the owner_username lookup — created once.
const ownerLookupFailLimiter = createOwnerLookupFailLimiter();

/** True when the parsed body carries a non-empty owner_username. */
function carriesOwnerUsername(req) {
  const v = req.body && typeof req.body === 'object' ? req.body.owner_username : undefined;
  return typeof v === 'string' && v.trim() !== '';
}

/**
 * Relay an edge write result under the public error model.
 * - 201/200: edge already returns a public-shaped body → relay verbatim.
 * - 400/401/404/409 carrying a whitelisted public `error` code → relay that code,
 *   propagating a forwarded Retry-After hint (still-reserved idempotency 409).
 * - anything else (500/502/503/circuit-open/timeout/unknown) → edge_unreachable,
 *   collapsing any internal apiError envelope so meta.db_type/provider never leak.
 */
function relayPublic(res, result) {
  if (result.status === 201 || result.status === 200) {
    return res.status(result.status).json(result.data);
  }
  const code = upstreamErrorCode(result.data);
  // An infra-side refusal (internal envelope) is not an outage. Same decision as
  // the read relay, taken in the same shared helper.
  const internal = publicMappingForInternalCode(code);
  if (internal) {
    return res.status(internal.status).json({ error: internal.code });
  }
  if (RELAYABLE_STATUSES.has(result.status) && isPublicErrorCode(code)) {
    const retryAfter = result.headers && result.headers['retry-after'];
    if (retryAfter) res.setHeader('Retry-After', retryAfter);
    return res.status(result.status).json({ error: code });
  }
  return res.status(503).json({ error: 'edge_unreachable' });
}

async function forwardCreate(req, res) {
  const principal = req.machinePrincipal;
  // [L3] defensive: the upstream gate always sets this, but guard so the router
  // never depends on mount order for its fail-closed behaviour.
  if (!principal || !principal.sub) {
    return res.status(401).json({ error: 'invalid_token' });
  }
  try {
    const result = await forwardToEdge({
      method: 'POST',
      path: `${EDGE_BASE}/templates`,
      // x-forwarded-user-id = sub; edge s2s-verify reconstructs the machine
      // principal from principalType + scope headers (never trusts these blindly).
      user: { id: principal.sub, email: '' },
      principal: { principalType: 'service_account', scope: principal.scope },
      body: req.body,
      headers: {
        // The Idempotency-Key is the customer's dedup token — forward it verbatim.
        ...(req.headers['idempotency-key'] ? { 'idempotency-key': req.headers['idempotency-key'] } : {}),
        ...(req.id ? { 'x-request-id': req.id } : {}),
      },
      reqPath: req.originalUrl || req.path,
    });
    return relayPublic(res, result);
  } catch (err) {
    // forwardToEdge builds the URL + S2S headers before its own try block, so a
    // synchronous throw there would otherwise become an unhandled rejection.
    logger.error({ err: err.message }, 'public write forward threw');
    return res.status(503).json({ error: 'edge_unreachable' });
  }
}

/**
 * @openapi
 * /api/public/v1/templates:
 *   post:
 *     summary: Create template
 *     description: >
 *       Creates an empty template **shell** attached to a point in the
 *       blueprint hierarchy. A shell has no field data — a human finishes it
 *       later in the web UI.
 *
 *
 *       **Owner assignment.** Omit `owner_username` and the shell is owned by
 *       the service account. Provide it — the Keycloak username of a user who
 *       has signed in at least once — and that user owns the shell; an unknown
 *       username returns `400 owner_not_found`, an ambiguous one `409
 *       owner_ambiguous` (repeated failed lookups are rate limited, so this
 *       field cannot enumerate usernames). The audit trail always records your
 *       integration account as the creator. The response names the owner by
 *       `owner_username` only — never an email, and no owner id.
 *
 *
 *       **The response carries the same FIELDS `GET /templates/{id}` returns**,
 *       minus `payload` and `generated_outputs`, so one field mapper handles
 *       both. The envelopes differ: this operation returns the object at the
 *       top level, the read operations wrap it in `data`.
 *
 *
 *       **Idempotency-Key (required).** Every request must carry an
 *       `Idempotency-Key` header (1–128 characters from `A-Z a-z 0-9 . _ -`).
 *       The key opens a 24-hour dedup window: the SAME key with the SAME body
 *       replays the original `201` (including the original `id`) — no second
 *       template, safe to retry; the SAME key with a DIFFERENT body returns
 *       `409 idempotency_conflict`. A still-in-flight duplicate also returns
 *       `409 idempotency_conflict` with a `Retry-After` header. See "Generating
 *       your Idempotency-Key" in the API description; the `id` cannot be your
 *       key (it does not exist yet) — persist the returned `id`.
 *
 *
 *       **Name-path resolution.** `path` is a `/`-separated chain of hierarchy
 *       names, leaf last (e.g. `Category A/Release 1/Blueprint X/Variant S`).
 *       The leaf may be a blueprint OR a variant. Matching is suffix-based,
 *       case- and accent-insensitive, and Unicode-normalized — send the leaf,
 *       or enough ancestor names (within your granted scope) to make it unique.
 *       0 matches or any out-of-scope match returns `404 path_not_found`; 2+
 *       returns `409 path_ambiguous`.
 *
 *
 *       **Body is strict.** Only `path` / `name` / `owner_username` are
 *       accepted — any other key, including `payload`, is rejected `400
 *       validation_failed`. Create the shell, then have a human fill it in the UI.
 *     tags: [Public API]
 *     security: [{ bearerAuth: [] }, { apiKeyAuth: [] }]
 *     x-codeSamples:
 *       - lang: Shell
 *         label: curl (both auth carriers)
 *         source: |
 *           API_BASE="https://your-app-host"        # the host serving this portal
 *           API_KEY="paste-the-key-shown-once-at-creation"
 *
 *           # One Idempotency-Key per intent — reuse it to retry, never for a second template.
 *           # Direct path — send the key as a Bearer token:
 *           curl -sS -X POST "$API_BASE/api/public/v1/templates" \
 *             -H "Authorization: Bearer $API_KEY" \
 *             -H "Content-Type: application/json" \
 *             -H "Idempotency-Key: work-order-4711" \
 *             -d '{
 *                   "path": "Category A/Release 1/Blueprint X/Variant S",
 *                   "name": "Template-0001"
 *                 }'
 *
 *           # Through an API gateway the same key travels as an api_key header:
 *           curl -sS -X POST "$API_BASE/api/public/v1/templates" \
 *             -H "api_key: $API_KEY" \
 *             -H "Content-Type: application/json" \
 *             -H "Idempotency-Key: work-order-4712" \
 *             -d '{
 *                   "path": "Category A/Release 1/Blueprint X/Variant S",
 *                   "name": "Template-0002"
 *                 }'
 *     parameters:
 *       - name: Idempotency-Key
 *         in: header
 *         required: true
 *         schema: { type: string, pattern: '^[A-Za-z0-9._-]{1,128}$', example: "work-order-4711" }
 *         description: >
 *           A stable, persisted, per-intent dedup key — 1–128 characters from
 *           `A-Z a-z 0-9 . _ -`. Use an id the calling system already has for
 *           the intent (a work-order or ticket id); if there is none, generate
 *           a random one and **persist it before the first attempt**. One
 *           intent = one key: a retry reuses it, a new template needs a new
 *           one. The key opens a 24-hour dedup window — same key with the same
 *           body replays the original `201` (including the original `id`),
 *           same key with a different body returns `409
 *           idempotency_conflict`. The template `id` cannot serve as the key
 *           (it does not exist until the create succeeds) and there is no
 *           lookup-by-key endpoint, so persist the returned `id`. A replay
 *           returns the body **exactly as it was first returned** (it is not an
 *           echo of the request), so for up to 24
 *           hours after this API changes its response shape a key first used
 *           before the change still replays the older body — that is the replay
 *           guarantee holding, not a regression. A new key always returns the
 *           current shape.
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [path]
 *             additionalProperties: false
 *             properties:
 *               path:
 *                 type: string
 *                 maxLength: 512
 *                 description: The hierarchy name-path to the blueprint or variant the shell attaches to.
 *                 example: "Category A/Release 1/Blueprint X/Variant S"
 *               name:
 *                 type: string
 *                 maxLength: 255
 *                 description: A human label. Trimmed, capped at 255 characters. Defaults to "(unnamed)".
 *                 example: "Template-0001"
 *               owner_username:
 *                 type: string
 *                 maxLength: 255
 *                 description: The Keycloak username of the human who will own the shell. Absent → owned by your integration account.
 *                 example: "jsmith"
 *           example:
 *             path: "Category A/Release 1/Blueprint X/Variant S"
 *             name: "Template-0001"
 *     responses:
 *       201:
 *         description: Shell created (or the original result replayed for a same-key/same-body retry)
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 id: { type: string, description: "Template id — the handle for every subsequent call. Persist it.", example: "a1a10000-0000-0000-0000-000000000001" }
 *                 name: { type: string, description: "The label the shell was created with.", example: "Template-0001" }
 *                 is_draft: { type: boolean, description: "Always true for a new shell — a human completes it in the web UI.", example: true }
 *                 path:
 *                   type: object
 *                   description: The resolved hierarchy names, truncated at the granted scope boundary. A tier outside the grant is omitted.
 *                   properties:
 *                     category: { type: string, description: "Category name.", example: "Category A" }
 *                     release: { type: string, description: "Release name.", example: "Release 1" }
 *                     blueprint: { type: string, description: "Blueprint name.", example: "Blueprint X" }
 *                     variant: { type: string, description: "Variant name; absent when the path resolved to a blueprint leaf.", example: "Variant S" }
 *                 owner_username: { type: string, nullable: true, description: "Owner's username (never an email). Null when the shell is owned by your integration account, or when the named owner is a locally-authenticated user (who has no Keycloak username).", example: "jsmith" }
 *                 schema_version: { type: string, nullable: true, description: "Null on a new shell — it is set when a human first saves the template.", example: null }
 *                 created_at: { type: string, format: date-time, description: "When the shell was created (UTC, ISO 8601).", example: "2026-07-11T12:00:00.000Z" }
 *                 updated_at: { type: string, format: date-time, description: "When the shell was last modified (UTC, ISO 8601). Equal to created_at on a new shell.", example: "2026-07-11T12:00:00.000Z" }
 *             example:
 *               id: "a1a10000-0000-0000-0000-000000000001"
 *               name: "Template-0001"
 *               is_draft: true
 *               path: { category: "Category A", release: "Release 1", blueprint: "Blueprint X", variant: "Variant S" }
 *               owner_username: "jsmith"
 *               schema_version: null
 *               created_at: "2026-07-11T12:00:00.000Z"
 *               updated_at: "2026-07-11T12:00:00.000Z"
 *       400:
 *         description: Missing/malformed Idempotency-Key, missing path, an unknown body key, a payload field, or an unknown owner_username
 *         content:
 *           application/json:
 *             schema: { $ref: '#/components/schemas/PublicError' }
 *             example: { error: validation_failed }
 *       401:
 *         description: Missing/unknown/deactivated token
 *         content:
 *           application/json:
 *             schema: { $ref: '#/components/schemas/PublicError' }
 *             example: { error: invalid_token }
 *       404:
 *         description: The name-path matches nothing you are allowed to see
 *         content:
 *           application/json:
 *             schema: { $ref: '#/components/schemas/PublicError' }
 *             example: { error: path_not_found }
 *       409:
 *         description: Ambiguous name-path, ambiguous owner_username, or an Idempotency-Key conflict
 *         content:
 *           application/json:
 *             schema: { $ref: '#/components/schemas/PublicError' }
 *             example: { error: idempotency_conflict }
 *       415:
 *         description: Content-Type other than application/json
 *         content:
 *           application/json:
 *             schema: { $ref: '#/components/schemas/PublicError' }
 *             example: { error: validation_failed }
 *       429:
 *         description: >
 *           Per-account budget exceeded — reads and writes draw on one shared
 *           per-minute budget, and repeated failed `owner_username` lookups
 *           burn a second, narrower budget of their own. This response also
 *           carries `Retry-After`, which must be honoured before retrying.
 *           `RateLimit-*` headers appear on every response, but they describe
 *           two different budgets: on an authenticated response the
 *           per-account per-minute one, on an unauthenticated rejection a
 *           separate, longer-windowed budget keyed by source IP.
 *         content:
 *           application/json:
 *             schema: { $ref: '#/components/schemas/PublicError' }
 *             example: { error: rate_limited }
 *       503:
 *         description: Temporary backend problem — retry with the same Idempotency-Key
 *         content:
 *           application/json:
 *             schema: { $ref: '#/components/schemas/PublicError' }
 *             example: { error: edge_unreachable }
 */
router.post(
  '/templates',
  // Failed-owner-lookup guard runs only when owner_username is present, so plain
  // creates never touch it (skipSuccessfulRequests → only >=400 burns budget).
  (req, res, next) => (carriesOwnerUsername(req) ? ownerLookupFailLimiter(req, res, next) : next()),
  forwardCreate,
);

module.exports = router;
