const { TABLES } = require('../../../../shared/constants');

/**
 * privileges.js — DB-layer GRANT/REVOKE UI backend.
 *
 * Surface for a DBA (holding a MariaDB session with GRANT OPTION) to grant
 * and revoke DML privileges on the application's infrastructure + engine
 * tables (prefix applied dynamically via t()) to service accounts used by
 * the application. Every grant/revoke attempt is audited via the
 * `feature_audit` table using a 2-phase pattern (pending → success|fail)
 * so that partial failures and crash-during-execute are visible in the
 * audit tail. See plan E-H3.
 *
 * Endpoints (all admin-only, mounted under /edge/platform/privileges):
 *   GET  /current-user       — CURRENT_USER() + grantOption + SHOW GRANTS parsed
 *   GET  /users              — MariaDB user enumeration (SELECT User, Host FROM mysql.user)
 *   GET  /grants/:user       — SHOW GRANTS FOR 'user'@'%' (lazy; avoid N+1)
 *   POST /grant              — body { mysqlUser, tables[], privileges[] }
 *   POST /revoke             — body { mysqlUser, tables[], privileges[] }
 *   GET  /audit              — feature_audit tail filtered to db_privilege.*
 *   GET  /audit.csv          — same as /audit but streamed CSV (D-H6)
 *
 * Security layers:
 *   - requireAdmin (app-layer) gate on every route
 *   - Self-guard dual (Q3): rejects target username that matches
 *     SUBSTRING_INDEX(CURRENT_USER(),'@',1) (E-M1) — blocked for both GRANT
 *     and REVOKE. Env DB_RW_USER / DB_RO_USER match blocks REVOKE only;
 *     GRANT to those accounts is allowed (bootstrap path). Shape: 409 + code SELF_GUARDED.
 *   - Identifier allowlist (E-L1): mysqlUser matches
 *     /^[a-zA-Z_][a-zA-Z0-9_]{0,31}$/. Same pattern also enforced client-
 *     side for UX, but the backend is authoritative.
 *   - Table allowlist: base names must appear in INFRA_TABLE_NAMES ∪
 *     ENGINE_TABLE_NAMES. The route never accepts a raw table name; it
 *     prepends the live t() prefix before emitting GRANT.
 *   - Privilege allowlist: DML 4 + REFERENCES + LOCK TABLES + EXECUTE
 *     (per CEO review C-M1). DDL keywords (CREATE / DROP / ALTER /
 *     TRUNCATE / RENAME / GRANT OPTION / SUPER / FILE / PROCESS /
 *     SHUTDOWN / RELOAD) are always rejected.
 *   - SQL smuggling: identifiers pre-validated, no string concatenation
 *     of user input into the GRANT statement body. Only backtick-wrapped
 *     allowlisted names.
 *
 * Audit layout (feature_audit.event_type):
 *   db_privilege.grant.pending   — INSERT before SQL execution
 *   db_privilege.grant.success   — INSERT after all GRANT succeeded
 *   db_privilege.grant.fail      — INSERT after any GRANT failed (per-row results)
 *   db_privilege.revoke.pending  — same, for REVOKE
 *   db_privilege.revoke.success  — same, for REVOKE
 *   db_privilege.revoke.fail     — same, for REVOKE
 *
 * Pending + terminal rows share a correlationId (stored in metadata.corrId)
 * so the UI can link them. The 2-phase approach uses two INSERTs rather
 * than UPDATE-on-JSON because the feature_audit schema already has no
 * `result` column and MySQL JSON_SET semantics are ugly for this use.
 * If the terminal INSERT fails we log with pino level=error and still
 * return success to the client — the GRANT landed, the operator sees
 * the orphan pending row on the audit tail and can reconcile.
 */

const router = require('express').Router();
const { pool, t, getDbConfig } = require('../../../db');
const { buildExportFilename, contentDispositionAttachment } = require('../../../../shared/lib/export-filename');
const { apiOk, apiError, requireAdmin, uuidv4 } = require('../../../../shared/helpers');
const { logger: rootLogger } = require('../../../../shared/lib/logger');
const { requirePrefix } = require('../../../../shared/lib/db-errors');
const logger = rootLogger.child({ module: 'privileges' });

const {
  evaluateSelfGuard,
  validateIsoDate,
  validateMysqlUser,
  validatePrivileges,
  validateTables,
  containsForbiddenToken,
  MYSQL_USER_RE,
  ISO8601_RE,
  PRIVILEGE_ALLOWLIST,
  ALLOWED_TABLE_BASE_NAMES,
  FORBIDDEN_TOKENS,
} = require('./grant-validation');
const { performBatch, normaliseGrantSpecs } = require('./sql-builders');
const {
  AUDIT_EVENT_TYPES,
  _normaliseAuditRow,
  _safeParseJson,
  _csvField,
  _summariseAudit,
} = require('./audit-helpers');

// ── Self-guard (Q3 + E-M1) ────────────────────────────────────────────────

/**
 * Returns the DBA's own username portion, read fresh from the MariaDB
 * session (so host-form like 'dba@%' strips to 'dba' via SUBSTRING_INDEX).
 * CURRENT_USER() is the authoritative source — whatever the DBA typed
 * in the MariaDB client can differ from DB_RW_USER.
 */
async function currentUsername(conn) {
  const rows = await conn.query(
    'SELECT SUBSTRING_INDEX(CURRENT_USER(),\'@\',1) AS u',
  );
  return rows[0]?.u ?? null;
}

// ── Audit helpers (2-phase) ───────────────────────────────────────────────

async function insertAuditRow(conn, { eventType, userId, metadata }) {
  const id = uuidv4();
  await conn.query(
    `INSERT INTO \`${t(TABLES.FEATURE_AUDIT)}\` (id, event_type, user_id, metadata)
     VALUES (?, ?, ?, ?)`,
    [id, eventType, userId || null, metadata ? JSON.stringify(metadata) : null],
  );
  return id;
}

// NOTE: SHOW GRANTS parser extracted to shared/lib/parse-grants.js so
// schema-init's pre-flight permission check can consume the same logic —
// one source of truth for the MariaDB grant string grammar.
const {
  parseGrantLine,
  hasGrantOption,
} = require('../../../../shared/lib/parse-grants');

// ── Routes ────────────────────────────────────────────────────────────────

/**
 * GET /current-user — { mysqlUser, grantOption, grants[] }
 *
 * UI consumers: when grantOption === false, PrivilegesPanel enters
 * read-only mode (D-H1 fold).
 */
router.get('/current-user', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  let conn;
  try {
    conn = await pool.rw.getConnection();
    const user = await currentUsername(conn);
    const rows = await conn.query('SHOW GRANTS');
    // MariaDB SHOW GRANTS returns an array of single-column rows where
    // the column name varies ("Grants for user@host"). Extract the first
    // value per row regardless of the column key.
    const lines = rows.map((r) => Object.values(r)[0]).filter(Boolean);
    const grants = lines.map(parseGrantLine).filter(Boolean);

    // NOTE: Expose the live tablePrefix so the UI's diff mode can match
    // existing grants against the fully-qualified table names the backend
    // will actually emit. The `tableFqns` array is a pre-computed
    // [base, fullyQualified] map so the UI doesn't need its own t() helper.
    const cfg = getDbConfig() || {};
    const tablePrefix = requirePrefix(cfg.tablePrefix, 'privileges:tablePrefix');
    // NOTE: Schema-aware GRANT OPTION check — least-privilege deploys hold
    // `GRANT ALL ON \`<schema>\`.* WITH GRANT OPTION` (no *.*), which
    // MariaDB accepts for intra-schema GRANT/REVOKE. Pass the live schema
    // so the UI isn't locked into read-only mode on schema-level grants.
    res.json(apiOk({
      mysqlUser: user,
      grantOption: hasGrantOption(grants, cfg.database),
      grants,
      tablePrefix,
      database: cfg.database || null,
    }));
  } catch (err) {
    logger.error({ err }, 'Failed to read CURRENT_USER + SHOW GRANTS');
    const e = apiError('Failed to read current MariaDB session privileges', 'INTERNAL_ERROR', 500, { cause: err });
    res.status(e.status).json(e.body);
  } finally {
    if (conn) conn.release();
  }
});

/**
 * GET /users — enumerate MariaDB users (no grants). UI pairs with
 * lazy-loading from /grants/:user (E-M6).
 */
router.get('/users', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  let conn;
  try {
    conn = await pool.ro.getConnection();
    // NOTE: Restrict enumeration to Host='%'. Every downstream GRANT /
    // REVOKE / SHOW GRANTS statement hardcodes '<user>'@'%', so showing
    // accounts bound to a different host would let the DBA select a
    // dropdown row that doesn't match the account the matrix actually
    // operates on. This UI manages @'%'-host service accounts only.
    const rows = await conn.query(
      "SELECT User, Host FROM mysql.user WHERE Host = '%' ORDER BY User",
    );
    res.json(apiOk({ users: rows.map((r) => ({ user: r.User, host: r.Host })) }));
  } catch (err) {
    // mysql.user is typically only SELECT-able by the DBA role. If the
    // session cannot read it, return a structured 403 so the UI can
    // explain to the operator rather than surface a generic 500.
    if (err?.code === 'ER_DBACCESS_DENIED_ERROR' || err?.code === 'ER_ACCESS_DENIED_ERROR' || err?.code === 'ER_TABLEACCESS_DENIED_ERROR') {
      const e = apiError('Session lacks SELECT on mysql.user. Log in as a DBA to list users.', 'MYSQL_USER_READ_DENIED', 403);
      return res.status(e.status).json(e.body);
    }
    logger.error({ err }, 'Failed to SELECT mysql.user');
    const e = apiError('Failed to enumerate MariaDB users', 'INTERNAL_ERROR', 500, { cause: err });
    res.status(e.status).json(e.body);
  } finally {
    if (conn) conn.release();
  }
});

/**
 * GET /grants/:user — SHOW GRANTS FOR '<user>'@'%'.
 * Identifier allowlist enforced.
 */
router.get('/grants/:user', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  const mysqlUser = req.params.user;
  const idErr = validateMysqlUser(mysqlUser);
  if (idErr) {
    const e = apiError(idErr, 'INVALID_IDENTIFIER', 400);
    return res.status(e.status).json(e.body);
  }
  let conn;
  try {
    // NOTE: SHOW GRANTS is read-only; route through pool.ro so this
    // endpoint does not consume a writer-pool slot.
    conn = await pool.ro.getConnection();
    // SHOW GRANTS with a parameter isn't possible — we have to inject.
    // Safe because the identifier already passed MYSQL_USER_RE, but we
    // still wrap in backticks-equivalent single quotes at the SQL level.
    const escaped = mysqlUser.replace(/'/g, "''");
    const rows = await conn.query(`SHOW GRANTS FOR '${escaped}'@'%'`);
    const lines = rows.map((r) => Object.values(r)[0]).filter(Boolean);
    const grants = lines.map(parseGrantLine).filter(Boolean);
    res.json(apiOk({ mysqlUser, grants }));
  } catch (err) {
    if (err?.code === 'ER_NONEXISTING_GRANT') {
      // MariaDB returns this when the user has no grants at all — legit
      // result for a freshly created user, not an error for our UI.
      return res.json(apiOk({ mysqlUser, grants: [] }));
    }
    logger.error({ err, mysqlUser }, 'Failed to read SHOW GRANTS for user=' + mysqlUser);
    const e = apiError('Failed to read grants for user', 'INTERNAL_ERROR', 500, { cause: err });
    res.status(e.status).json(e.body);
  } finally {
    if (conn) conn.release();
  }
});

async function handleGrantOrRevoke(req, res, op) {
  if (!requireAdmin(req, res)) return;
  const body = req.body || {};
  const { mysqlUser } = body;

  const idErr = validateMysqlUser(mysqlUser);
  if (idErr) {
    const e = apiError(idErr, 'INVALID_IDENTIFIER', 400);
    return res.status(e.status).json(e.body);
  }

  // NOTE: Normalise to per-table specs so the matrix UI can submit
  // "INSERT on A + SELECT on B" without the flat tables × privileges
  // cross-product accidentally granting all pairs.
  const norm = normaliseGrantSpecs(body);
  if (norm.error) {
    // sec-rev LOW-2 log-vs-body split preserved.
    if (norm.error === 'privilege not permitted') {
      logger.warn(
        {
          rejected: Array.isArray(body.privileges) ? body.privileges
            : (Array.isArray(body.grants) ? body.grants.flatMap((g) => g?.privileges ?? []) : []),
          op,
          initiator: req.user?.email ?? null,
        },
        'privilege allowlist rejected request',
      );
      const e = apiError(norm.error, 'INVALID_PRIVILEGES', 400);
      return res.status(e.status).json(e.body);
    }
    const code = norm.error.startsWith('mysqlUser')
      ? 'INVALID_IDENTIFIER'
      : (norm.error.includes('table')
        ? 'INVALID_TABLES'
        : 'INVALID_GRANTS');
    const e = apiError(norm.error, code, 400);
    return res.status(e.status).json(e.body);
  }
  const grantSpecs = norm.specs;

  const correlationId = uuidv4();
  let conn;
  try {
    conn = await pool.rw.getConnection();

    // Self-guard after connection (we need CURRENT_USER()).
    const currentUser = await currentUsername(conn);
    const sg = evaluateSelfGuard(mysqlUser, currentUser, op);
    if (sg.self) {
      const e = apiError(
        `Refusing to ${op.toLowerCase()} privileges on the current session or the app's own service account (reason: ${sg.reason}).`,
        'SELF_GUARDED',
        409,
      );
      return res.status(e.status).json(e.body);
    }

    // GRANT OPTION pre-flight — avoid attempting a batch where every row
    // will ER_DBACCESS_DENIED. UI already checks via /current-user, this
    // is just a backstop.
    // NOTE: Pass live schema so schema-level WITH GRANT OPTION also passes
    // this backstop (parity with /current-user response).
    const rows = await conn.query('SHOW GRANTS');
    const lines = rows.map((r) => Object.values(r)[0]).filter(Boolean);
    const parsedGrants = lines.map(parseGrantLine).filter(Boolean);
    const cfgForGate = getDbConfig() || {};
    if (!hasGrantOption(parsedGrants, cfgForGate.database)) {
      const e = apiError(
        `Current MariaDB session does not hold GRANT OPTION on ${cfgForGate.database ? '`' + cfgForGate.database + '`.* or ' : ''}*.*. Log in as a DBA.`,
        'NO_GRANT_OPTION',
        403,
      );
      return res.status(e.status).json(e.body);
    }

    // Phase 1: pending audit row
    const userId = req.user?.id || null;
    const pendingMeta = {
      corrId: correlationId,
      op,
      mysqlUser,
      grantSpecs,
      // Keep legacy flat fields for back-compat with audit tail parsers.
      tables: grantSpecs.map((s) => s.table),
      privileges: Array.from(new Set(grantSpecs.flatMap((s) => s.privileges))),
      initiator: req.user?.email || null,
      startedAt: new Date().toISOString(),
    };
    try {
      await insertAuditRow(conn, {
        eventType: op === 'GRANT' ? AUDIT_EVENT_TYPES.grantPending : AUDIT_EVENT_TYPES.revokePending,
        userId,
        metadata: pendingMeta,
      });
    } catch (auditErr) {
      // Pre-SQL audit failure → refuse to perform the operation. We'd
      // rather have the DBA retry than produce an unaudited GRANT.
      logger.error({ err: auditErr, correlationId }, 'Failed to insert pending audit row corrId=' + correlationId);
      const e = apiError('Failed to write audit pending row; aborted before execute', 'AUDIT_INSERT_FAILED', 500);
      return res.status(e.status).json(e.body);
    }

    // Phase 2: run the batch (per-spec emission — no cross-product).
    const results = await performBatch(conn, op, { mysqlUser, grantSpecs }, t);
    const allOk = results.every((r) => r.ok);
    const terminalEvent = allOk
      ? (op === 'GRANT' ? AUDIT_EVENT_TYPES.grantSuccess : AUDIT_EVENT_TYPES.revokeSuccess)
      : (op === 'GRANT' ? AUDIT_EVENT_TYPES.grantFail : AUDIT_EVENT_TYPES.revokeFail);

    // Phase 3: terminal audit row (non-fatal on failure — log loud and
    // continue so the client sees the per-row result).
    try {
      await insertAuditRow(conn, {
        eventType: terminalEvent,
        userId,
        metadata: {
          corrId: correlationId,
          op,
          mysqlUser,
          results,
          completedAt: new Date().toISOString(),
        },
      });
    } catch (auditErr) {
      logger.error(
        { err: auditErr, correlationId, results },
        'Failed to insert terminal audit row; SQL already executed — reconcile via audit tail',
      );
    }

    const status = allOk ? 200 : 207; // 207 Multi-Status for partial success
    res.status(status).json(apiOk({
      correlationId,
      allOk,
      results,
    }));
  } catch (err) {
    logger.error({ err, correlationId, op }, 'Unhandled failure in ' + op + ' corrId=' + correlationId);
    const e = apiError(`${op} failed unexpectedly`, 'INTERNAL_ERROR', 500, { cause: err });
    res.status(e.status).json(e.body);
  } finally {
    if (conn) conn.release();
  }
}

router.post('/grant', (req, res) => handleGrantOrRevoke(req, res, 'GRANT'));
router.post('/revoke', (req, res) => handleGrantOrRevoke(req, res, 'REVOKE'));

/**
 * GET /audit — feature_audit tail restricted to db_privilege.* events.
 * Pagination + date filter (D-H6).
 */
router.get('/audit', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  let limit = parseInt(req.query.limit, 10);
  if (Number.isNaN(limit) || limit <= 0) limit = 50;
  if (limit > 500) limit = 500;
  let offset = parseInt(req.query.offset, 10);
  if (Number.isNaN(offset) || offset < 0) offset = 0;

  const params = [];
  const wheres = ["event_type LIKE 'db_privilege.%'"];

  if (req.query.eventType && typeof req.query.eventType === 'string') {
    // Only allow our own known event types
    if (!Object.values(AUDIT_EVENT_TYPES).includes(req.query.eventType)) {
      const e = apiError(`Unknown eventType: ${req.query.eventType}`, 'BAD_REQUEST', 400);
      return res.status(e.status).json(e.body);
    }
    wheres.push('event_type = ?');
    params.push(req.query.eventType);
  }

  const startErr = validateIsoDate(req.query.startDate);
  if (startErr) {
    const e = apiError(`startDate: ${startErr}`, 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }
  if (req.query.startDate) {
    wheres.push('created_at >= ?');
    params.push(req.query.startDate);
  }
  const endErr = validateIsoDate(req.query.endDate);
  if (endErr) {
    const e = apiError(`endDate: ${endErr}`, 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }
  if (req.query.endDate) {
    wheres.push('created_at <= ?');
    params.push(req.query.endDate);
  }

  const whereSql = 'WHERE ' + wheres.join(' AND ');
  let conn;
  try {
    conn = await pool.ro.getConnection();
    const rows = await conn.query(
      `SELECT id, event_type, user_id, metadata, created_at
         FROM \`${t(TABLES.FEATURE_AUDIT)}\`
         ${whereSql}
         ORDER BY created_at DESC
         LIMIT ? OFFSET ?`,
      [...params, limit, offset],
    );
    const totalRows = await conn.query(
      `SELECT COUNT(*) AS cnt FROM \`${t(TABLES.FEATURE_AUDIT)}\` ${whereSql}`,
      params,
    );
    res.json(apiOk({
      events: rows.map(_normaliseAuditRow),
      total: Number(totalRows[0].cnt) || 0,
      limit,
      offset,
    }));
  } catch (err) {
    logger.error({ err }, 'Failed to read privileges audit tail');
    const e = apiError('Failed to read audit tail', 'INTERNAL_ERROR', 500, { cause: err });
    res.status(e.status).json(e.body);
  } finally {
    if (conn) conn.release();
  }
});

/**
 * GET /audit.csv — same filters as /audit but streams CSV.
 * Columns: created_at, event_type, user_id, corrId, mysqlUser, op, summary.
 */
router.get('/audit.csv', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  const startErr = validateIsoDate(req.query.startDate);
  if (startErr) {
    const e = apiError(`startDate: ${startErr}`, 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }
  const endErr = validateIsoDate(req.query.endDate);
  if (endErr) {
    const e = apiError(`endDate: ${endErr}`, 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }
  let conn;
  try {
    conn = await pool.ro.getConnection();
    const params = [];
    const wheres = ["event_type LIKE 'db_privilege.%'"];
    if (req.query.startDate) {
      wheres.push('created_at >= ?'); params.push(req.query.startDate);
    }
    if (req.query.endDate) {
      wheres.push('created_at <= ?'); params.push(req.query.endDate);
    }
    const whereSql = 'WHERE ' + wheres.join(' AND ');

    const rows = await conn.query(
      `SELECT id, event_type, user_id, metadata, created_at
         FROM \`${t(TABLES.FEATURE_AUDIT)}\`
         ${whereSql}
         ORDER BY created_at DESC
         LIMIT 5000`,
      params,
    );

    const auditDb = (getDbConfig() || {}).database || 'export';
    const auditFilename = buildExportFilename({ kind: 'privileges-audit', entity: auditDb, ext: 'csv' });
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', contentDispositionAttachment(auditFilename));
    res.write('created_at,event_type,user_id,corrId,mysqlUser,op,summary\n');
    for (const row of rows) {
      const meta = _safeParseJson(row.metadata) || {};
      const summary = _summariseAudit(meta);
      res.write([
        _csvField(row.created_at),
        _csvField(row.event_type),
        _csvField(row.user_id || ''),
        _csvField(meta.corrId || ''),
        _csvField(meta.mysqlUser || ''),
        _csvField(meta.op || ''),
        _csvField(summary),
      ].join(',') + '\n');
    }
    res.end();
  } catch (err) {
    logger.error({ err }, 'Failed to stream privileges audit CSV');
    if (!res.headersSent) {
      const e = apiError('Failed to stream audit CSV', 'INTERNAL_ERROR', 500, { cause: err });
      res.status(e.status).json(e.body);
    } else {
      res.end();
    }
  } finally {
    if (conn) conn.release();
  }
});

// Exported for unit tests — not part of the router API.
module.exports = router;
module.exports._internal = {
  validateMysqlUser,
  validatePrivileges,
  validateTables,
  validateIsoDate,
  normaliseGrantSpecs,
  containsForbiddenToken,
  parseGrantLine,
  hasGrantOption,
  evaluateSelfGuard,
  MYSQL_USER_RE,
  ISO8601_RE,
  PRIVILEGE_ALLOWLIST,
  ALLOWED_TABLE_BASE_NAMES,
  AUDIT_EVENT_TYPES,
  FORBIDDEN_TOKENS,
};
