const { TABLES } = require('../../../shared/constants');

const router = require('express').Router();
const bcrypt = require('bcryptjs');
const { pool, t } = require('../../db');
const { apiOk, apiError, requireAdmin, requireAdminOrEditor, uuidv4 } = require('../../../shared/helpers');
const { logger: rootLogger } = require('../../../shared/lib/logger');
const { validatePassword } = require('../../../shared/password-validator');
const logger = rootLogger.child({ module: 'users' });

/**
 * @openapi
 * /edge/platform/users:
 *   get:
 *     summary: List all users
 *     tags: [Platform - Users]
 *     responses:
 *       200:
 *         description: User list
 *         content: { application/json: { schema: { $ref: '#/components/schemas/ApiResponse' } } }
 *       401: { description: Unauthorized }
 *       403: { description: Admin required }
 *   post:
 *     summary: Create user or dispatch action (list, ban, unban, updateRole, delete, resetPassword)
 *     tags: [Platform - Users]
 *     requestBody:
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               action: { type: string, enum: [list, ban, unban, updateRole, delete, resetPassword, create] }
 *               email: { type: string }
 *               password: { type: string }
 *               display_name: { type: string }
 *               userId: { type: string }
 *               role: { type: string, enum: [admin, user] }
 *     responses:
 *       200: { description: Action completed }
 *       400: { description: Validation error }
 *       401: { description: Unauthorized }
 *       403: { description: Admin required }
 */
router.get('/', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  try {
    // NOTE: Idempotent read → pool.ro. Falls back to the writer when no
    // separate read endpoint is configured, so the code path is identical
    // for local dev and for the full RW/RO deployment.
    const conn = await pool.ro.getConnection();
    try {
      const rows = await conn.query(
        `SELECT id, display_name, email, created_at, role, banned FROM \`${t(TABLES.USERS)}\` ORDER BY created_at DESC`
      );
      res.json(apiOk(rows));
    } finally {
      conn.release();
    }
  } catch (err) {
    logger.error({ err }, 'Failed to list users');
    const e = apiError('Database operation failed', 'INTERNAL_ERROR');
    res.status(e.status).json(e.body);
  }
});

// GET /assignable — bounded directory for owner self-reassign pickers.
// Admin+editor only; returns id + display_name + role ONLY (never email —
// PII/compliance), active (non-banned) users. Feeds the transfer-owner picker
// so a non-admin owner can choose a transferee; grants no transfer power
// itself (the reassign routes re-validate caller + target).
router.get('/assignable', async (req, res) => {
  if (!requireAdminOrEditor(req, res)) return;
  try {
    const conn = await pool.ro.getConnection();
    try {
      const rows = await conn.query(
        `SELECT id, display_name, role FROM \`${t(TABLES.USERS)}\`
         WHERE banned = 0 ORDER BY display_name IS NULL, display_name`
      );
      res.json(apiOk(rows));
    } finally {
      conn.release();
    }
  } catch (err) {
    logger.error({ err }, 'Failed to list assignable users');
    const e = apiError('Database operation failed', 'INTERNAL_ERROR');
    res.status(e.status).json(e.body);
  }
});

// POST /edge/platform/users — action dispatch
router.post('/', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  const { action } = req.body || {};

  if (action === 'list') {
    try {
      // NOTE: POST-with-action=list is the same idempotent read as GET /;
      // route to pool.ro.
      const conn = await pool.ro.getConnection();
      try {
        const rows = await conn.query(
          `SELECT id, display_name, email, created_at, role, banned FROM \`${t(TABLES.USERS)}\` ORDER BY created_at DESC`
        );
        res.json(apiOk({ users: rows }));
      } finally { conn.release(); }
    } catch (err) {
      logger.error({ err }, 'Failed to list users');
      const e = apiError('Database operation failed', 'INTERNAL_ERROR');
      res.status(e.status).json(e.body);
    }
    return;
  }

  if (action === 'ban' || action === 'unban') {
    const { userId } = req.body;
    if (!userId) { const e = apiError('userId required', 'BAD_REQUEST', 400); return res.status(e.status).json(e.body); }
    try {
      const conn = await pool.rw.getConnection();
      try {
        await conn.query(`UPDATE \`${t(TABLES.USERS)}\` SET banned = ? WHERE id = ?`, [action === 'ban', userId]);
        res.json(apiOk(null));
      } finally { conn.release(); }
    } catch (err) {
      logger.error({ err, userId, action }, 'Failed to update user ban state userId=' + userId + ' action=' + action);
      const e = apiError('Database operation failed', 'INTERNAL_ERROR');
      res.status(e.status).json(e.body);
    }
    return;
  }

  if (action === 'updateRole') {
    const { userId, role } = req.body;
    if (!userId || !role || !['admin', 'editor', 'user'].includes(role)) {
      const e = apiError('userId and valid role required', 'BAD_REQUEST', 400);
      return res.status(e.status).json(e.body);
    }
    try {
      const conn = await pool.rw.getConnection();
      try {
        await conn.query(`UPDATE \`${t(TABLES.USERS)}\` SET role = ? WHERE id = ?`, [role, userId]);
        res.json(apiOk(null));
      } finally { conn.release(); }
    } catch (err) {
      logger.error({ err, userId, role }, 'Failed to update user role userId=' + userId + ' role=' + role);
      const e = apiError('Database operation failed', 'INTERNAL_ERROR');
      res.status(e.status).json(e.body);
    }
    return;
  }

  if (action === 'delete') {
    const { userId } = req.body;
    if (!userId) { const e = apiError('userId required', 'BAD_REQUEST', 400); return res.status(e.status).json(e.body); }
    try {
      const conn = await pool.rw.getConnection();
      try {
        await conn.query(`DELETE FROM \`${t(TABLES.USERS)}\` WHERE id = ?`, [userId]);
        res.json(apiOk(null));
      } finally { conn.release(); }
    } catch (err) {
      logger.error({ err, userId }, 'Failed to delete user userId=' + userId);
      const e = apiError('Database operation failed', 'INTERNAL_ERROR');
      res.status(e.status).json(e.body);
    }
    return;
  }

  if (action === 'resetPassword') {
    const { userId: targetId, password: newPw } = req.body;
    if (!targetId) { const e = apiError('userId required', 'BAD_REQUEST', 400); return res.status(e.status).json(e.body); }
    const pwErr = validatePassword(newPw);
    if (pwErr) { const e = apiError(pwErr, 'BAD_REQUEST', 400); return res.status(e.status).json(e.body); }
    try {
      // SELECT + UPDATE + audit INSERT all on the same conn → pool.rw.
      const conn = await pool.rw.getConnection();
      try {
        const userRows = await conn.query(
          `SELECT keycloak_sub, email FROM \`${t(TABLES.USERS)}\` WHERE id = ?`, [targetId]
        );
        if (!userRows.length) { const e = apiError('User not found', 'NOT_FOUND', 404); return res.status(e.status).json(e.body); }
        const targetUser = userRows[0];
        if (targetUser.keycloak_sub) {
          logger.warn({ targetUserId: targetId, adminId: req.user?.id }, 'local password set for Keycloak account');
        }
        const hash = await bcrypt.hash(newPw, 10);
        await conn.query(`UPDATE \`${t(TABLES.USERS)}\` SET password_hash = ? WHERE id = ?`, [hash, targetId]);
        const auditReason = targetUser.keycloak_sub ? 'admin_set_local_password_for_keycloak_account' : 'password_reset';
        try {
          await conn.query(
            `INSERT INTO \`${t(TABLES.LOGIN_AUDIT)}\` (username, auth_provider, reason, success) VALUES (?, 'LOCAL', ?, TRUE)`,
            [targetUser.email, auditReason]
          );
        } catch (auditErr) {
          logger.warn({ err: auditErr }, 'audit log failed for password reset');
        }
        res.json(apiOk({
          message: targetUser.keycloak_sub
            ? `Local password set for ${targetUser.email}. This does NOT change their Keycloak SSO password.`
            : 'Password reset successfully',
        }));
      } finally { conn.release(); }
    } catch (err) {
      logger.error({ err, userId: targetId }, 'Failed to reset user password userId=' + targetId);
      const e = apiError('Database error', 'DB_ERROR');
      res.status(e.status).json(e.body);
    }
    return;
  }

  // Default: action "create"
  const { email, password, display_name } = req.body;
  if (!email || !password) {
    const e = apiError('email and password required', 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }
  const pwError = validatePassword(password);
  if (pwError) {
    const e = apiError(pwError, 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }
  try {
    const id = uuidv4();
    const hash = await bcrypt.hash(password, 10);
    const conn = await pool.rw.getConnection();
    try {
      await conn.query(
        `INSERT INTO \`${t(TABLES.USERS)}\` (id, email, password_hash, display_name) VALUES (?, ?, ?, ?)`,
        [id, email, hash, display_name || email.split('@')[0]]
      );
      res.json(apiOk({ id, email }));
    } finally {
      conn.release();
    }
  } catch (err) {
    // Email lives in the structured binding (redactable via pino redact.paths
    // at a future framework-boundary PR) but is NOT concatenated into the
    // pino `msg` string because pino redact covers structured fields only.
    logger.error({ err, email }, 'Failed to create user');
    const e = apiError('Database operation failed', 'INTERNAL_ERROR');
    res.status(e.status).json(e.body);
  }
});

// POST /edge/platform/users/:id/ban
router.post('/:id/ban', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  try {
    const conn = await pool.rw.getConnection();
    try {
      await conn.query(`UPDATE \`${t(TABLES.USERS)}\` SET banned = ? WHERE id = ?`, [!!req.body.banned, req.params.id]);
      res.json(apiOk(null));
    } finally {
      conn.release();
    }
  } catch (err) {
    logger.error({ err, userId: req.params.id }, 'Failed to update user ban state userId=' + req.params.id);
    const e = apiError('Database operation failed', 'INTERNAL_ERROR');
    res.status(e.status).json(e.body);
  }
});

// PUT /edge/platform/users/:id/role
router.put('/:id/role', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  const { role } = req.body;
  if (!role || !['admin', 'editor', 'user'].includes(role)) {
    const e = apiError('role must be "admin", "editor", or "user"', 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }
  try {
    const conn = await pool.rw.getConnection();
    try {
      await conn.query(`UPDATE \`${t(TABLES.USERS)}\` SET role = ? WHERE id = ?`, [role, req.params.id]);
      res.json(apiOk(null));
    } finally {
      conn.release();
    }
  } catch (err) {
    logger.error({ err, userId: req.params.id, role }, 'Failed to update user role userId=' + req.params.id + ' role=' + role);
    const e = apiError('Database operation failed', 'INTERNAL_ERROR');
    res.status(e.status).json(e.body);
  }
});

// PUT /edge/platform/users/:id/reset-password
router.put('/:id/reset-password', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  const { password } = req.body;
  if (!password) {
    const e = apiError('password is required', 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }
  const pwError = validatePassword(password);
  if (pwError) {
    const e = apiError(pwError, 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }
  try {
    // SELECT + UPDATE + audit INSERT all on same conn → pool.rw.
    const conn = await pool.rw.getConnection();
    try {
      const userRows = await conn.query(
        `SELECT keycloak_sub, password_hash, email FROM \`${t(TABLES.USERS)}\` WHERE id = ?`,
        [req.params.id]
      );
      if (!userRows.length) {
        const e = apiError('User not found', 'NOT_FOUND', 404);
        return res.status(e.status).json(e.body);
      }
      const targetUser = userRows[0];
      const isKeycloakAccount = !!targetUser.keycloak_sub;

      if (isKeycloakAccount) {
        logger.warn(
          { targetUserId: req.params.id, adminId: req.user?.id },
          'local password set for Keycloak account'
        );
      }

      const hash = await bcrypt.hash(password, 10);
      await conn.query(
        `UPDATE \`${t(TABLES.USERS)}\` SET password_hash = ? WHERE id = ?`,
        [hash, req.params.id]
      );
      const auditReason = isKeycloakAccount
        ? 'admin_set_local_password_for_keycloak_account'
        : 'password_reset';
      try {
        await conn.query(
          `INSERT INTO \`${t(TABLES.LOGIN_AUDIT)}\` (username, auth_provider, reason, success)
           VALUES (?, 'LOCAL', ?, TRUE)`,
          [targetUser.email, auditReason]
        );
      } catch (auditErr) {
        logger.warn({ err: auditErr }, 'audit log failed for password reset');
      }
      res.json(apiOk({
        message: isKeycloakAccount
          ? `Local password set for ${targetUser.email}. This does NOT change their Keycloak SSO password.`
          : 'Password reset successfully',
      }));
    } finally {
      conn.release();
    }
  } catch (err) {
    logger.error({ err, userId: req.params.id }, 'Failed to reset user password userId=' + req.params.id);
    const e = apiError('Database error', 'DB_ERROR');
    res.status(e.status).json(e.body);
  }
});

module.exports = router;
module.exports.validatePassword = validatePassword;
