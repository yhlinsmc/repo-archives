const { TABLES } = require('../../../shared/constants');

/**
 * feature-audit.js — Lightweight feature event log.
 *
 * Records structured feature events for admin diagnostics.
 *
 * Routes:
 *   POST /edge/platform/feature-audit         — append one event (admin only)
 *   GET  /edge/platform/feature-audit         — paginated tail (admin only)
 *
 * Allowed event_type values are restricted to a server-side allowlist so
 * that the table cannot be polluted with arbitrary strings via the API.
 */
const router = require('express').Router();
const { pool, t } = require('../../db');
const { apiOk, apiError, requireAdmin, uuidv4 } = require('../../../shared/helpers');
const { mapRowsFromDb } = require('../../lib/dto-mapper');
const { escapeLikePattern } = require('../../lib/sql-like');
const { logger: rootLogger } = require('../../../shared/lib/logger');
const logger = rootLogger.child({ module: 'feature-audit' });

// NOTE: Write-allowlist (clients may POST) vs read-allowlist (admins may
// filter on GET) are split. System events (schema_migration.* +
// schema_status.*) live ONLY in the read allowlist — any HTTP POST
// attempting to forge them returns 400. The visibility-surface admin
// endpoint uses the most-recent `schema_migration.completed` row as the
// cutoff for skipped events; allowing client POSTs would let an admin forge
// a completed row to hide real drift.
//
// SECURITY: an event's `metadata` is persisted as a JSON column (no length
// cap, stored verbatim) and is admin-searchable — the GET list endpoint runs
// a free-text `q` LIKE over the serialized metadata. Do NOT put secrets,
// tokens, raw credentials, or PII in metadata for any event below; keep it to
// non-sensitive identifiers/counts (table names are already prefix-redacted).
const WRITABLE_EVENT_TYPES = new Set([
  'transformer.execute.success',
  'transformer.execute.fail',
  'grid.paste.event',
  'migration.ran',
  'draft.saved',
  'zero-cleanup.ran',
  // Two-stage data-clear audit: `.attempt` always fires before exactly one
  // outcome event. Lets ops distinguish "we attempted but were blocked"
  // from "we never attempted" in the audit timeline.
  'data_clear.attempt',
  'data_clear.blocked_by_fk',
  'data_clear.success',
  'data_clear.fallback_to_delete',
  'data_clear.fail',
  'blueprint.field.type_changed',
  'transformer.version.delete',
  'transformer.version.auto_prune',
  'blueprint.owner.transfer',
  'transformer.owner.transfer',
  // Admin read-only impersonation session boundary (start/stop), recorded by
  // the real admin so the audit trail names the operator, not the target.
  'impersonation.start',
  'impersonation.stop',
]);

// SYSTEM_EVENT_TYPES are written ONLY by trusted server paths (boot-time
// runSchemaMigrations + the admin schema-status route). They appear in the
// read allowlist so admins can filter, but rejecting POSTs keeps audit
// integrity — a forged schema_migration.completed could hide real drift.
const SYSTEM_EVENT_TYPES = new Set([
  'schema_migration.completed',
  'schema_migration.skipped',
  'schema_migration.alter_skipped',
  // variant_overrides boot cleanup events (edge/db.js _writeMigrationAudit).
  // Readable so admins can filter on them — these are the forensic trail for
  // any boot-time row deletion.
  'schema_migration.variant_override_null_action_cleanup',
  'schema_migration.variant_override_invalid_action_cleanup',
  // blueprint_groups dedup before the (blueprint_id, group_key) UNIQUE ADD —
  // same forensic-trail rationale: the boot migration deletes duplicate rows.
  'schema_migration.blueprint_groups_dedup',
  // blueprint_sections dedup before the (blueprint_id, section_key) UNIQUE ADD —
  // same forensic-trail rationale.
  'schema_migration.blueprint_sections_dedup',
  // one-time repair of blueprint_field group_key / matrix_row_key refs orphaned
  // by the 3.2.428 dedup (which deleted loser case-variant group rows without
  // repointing the referencing fields). Records repointed / ambiguous / unmatched
  // field samples so an operator can resolve the cases the migration would not
  // guess. Boot-written only; readable so admins can filter.
  'schema_migration.blueprint_group_ref_repair',
  'schema_status.read',
  'schema_status.proceed_anyway',
  // blueprint_groups rename-with-cascade audit row (schema.js) — written by a
  // direct in-transaction INSERT, never through this router's POST handler.
  // Server-only like the schema_migration.* events above: a client POST here
  // is a forgery vector (an admin could fabricate a rename row with arbitrary
  // metadata), so it stays read-allowlisted only.
  'blueprint_group.rename',
  // A schema edit dropped the compute rule the field carried, because the rule
  // no longer means anything against the field's new type / key / columns.
  // Written in the same transaction as the schema edit (routes-blueprint-fields),
  // never through this router's POST: it is the forensic record of a value the
  // operator did not ask to delete, so a client must not be able to fabricate it.
  'blueprint.field.compute_rule_cleared',
]);

const READABLE_EVENT_TYPES = new Set([...WRITABLE_EVENT_TYPES, ...SYSTEM_EVENT_TYPES]);

// Severity is authored here, next to the event-type allowlist, so it is a
// single source of truth the frontend reads via /event-types rather than
// guessing a colour from the type string. Only failures and risk signals are
// listed; everything else is routine and defaults to 'info'. A readable type
// without an entry shows neutral on the dashboard — never mis-coloured.
//   error   — a genuine failure
//   warning — not a failure, but worth an operator's eye (refused / forced /
//             skipped: a safeguard fired or an admin overrode a guard)
const EVENT_SEVERITY = new Map([
  ['transformer.execute.fail', 'error'],
  ['data_clear.fail', 'error'],
  ['data_clear.blocked_by_fk', 'warning'],
  ['data_clear.fallback_to_delete', 'warning'],
  ['schema_status.proceed_anyway', 'warning'],
  ['schema_migration.skipped', 'warning'],
  ['schema_migration.alter_skipped', 'warning'],
  // Not a failure: the schema edit succeeded. It is listed because a stored
  // rule stopped existing as a side effect, which an operator should see.
  ['blueprint.field.compute_rule_cleared', 'warning'],
]);

function severityFor(eventType) {
  return EVENT_SEVERITY.get(eventType) || 'info';
}

/**
 * @openapi
 * /edge/platform/feature-audit:
 *   post:
 *     summary: Append a feature audit event (admin only)
 *     tags: [Platform - Feature Audit]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [event_type]
 *             properties:
 *               event_type: { type: string }
 *               metadata:   { type: object }
 *     responses:
 *       200: { description: Recorded }
 *       400: { description: Unknown event_type }
 *       403: { description: Admin required }
 *   get:
 *     summary: Paginated feature audit tail (admin only)
 *     tags: [Platform - Feature Audit]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - { name: limit,      in: query, schema: { type: integer, default: 100, maximum: 1000 } }
 *       - { name: offset,     in: query, schema: { type: integer, default: 0 } }
 *       - { name: event_type, in: query, schema: { type: string } }
 *       - { name: q, in: query, schema: { type: string, maxLength: 200 }, description: Free-text search across event_type, metadata, and user_id }
 *     responses:
 *       200: { description: Event list, content: { application/json: { schema: { $ref: '#/components/schemas/ApiResponse' } } } }
 *       403: { description: Admin required }
 */
router.post('/', async (req, res) => {
  if (!requireAdmin(req, res)) return;

  const { event_type, metadata } = req.body || {};
  if (!event_type || typeof event_type !== 'string') {
    const e = apiError('event_type required', 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }
  if (!WRITABLE_EVENT_TYPES.has(event_type)) {
    const e = apiError(`Unknown event_type: ${event_type}`, 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }

  let conn;
  try {
    conn = await pool.rw.getConnection();
    const id = uuidv4();
    await conn.query(
      `INSERT INTO \`${t(TABLES.FEATURE_AUDIT)}\` (id, event_type, user_id, metadata)
       VALUES (?, ?, ?, ?)`,
      [
        id,
        event_type,
        req.user?.id || null,
        metadata ? JSON.stringify(metadata) : null,
      ],
    );
    res.json(apiOk({ id, event_type }));
  } catch (err) {
    logger.error({ err, eventType: event_type }, 'Failed to insert feature_audit row eventType=' + event_type);
    const e = apiError('Database operation failed', 'INTERNAL_ERROR');
    res.status(e.status).json(e.body);
  } finally {
    if (conn) conn.release();
  }
});

// Distinct event types actually present in the table, intersected with the
// read allowlist so every returned value is a legal `event_type` filter (the
// GET / handler 400s on a non-readable type). This drives the admin filter
// dropdown — it can no longer drift away from the data the way a hard-coded
// frontend list did.
router.get('/event-types', async (req, res) => {
  if (!requireAdmin(req, res)) return;

  const readable = [...READABLE_EVENT_TYPES];
  const placeholders = readable.map(() => '?').join(', ');

  let conn;
  try {
    conn = await pool.ro.getConnection();
    const rows = await conn.query(
      `SELECT DISTINCT event_type
         FROM \`${t(TABLES.FEATURE_AUDIT)}\`
        WHERE event_type IN (${placeholders})
        ORDER BY event_type ASC`,
      readable,
    );
    res.json(apiOk({
      event_types: rows.map((r) => ({
        type: r.event_type,
        severity: severityFor(r.event_type),
      })),
    }));
  } catch (err) {
    logger.error({ err }, 'Failed to read distinct feature_audit event types');
    const e = apiError('Database operation failed', 'INTERNAL_ERROR');
    res.status(e.status).json(e.body);
  } finally {
    if (conn) conn.release();
  }
});

router.get('/', async (req, res) => {
  if (!requireAdmin(req, res)) return;

  let limit = parseInt(req.query.limit, 10);
  if (Number.isNaN(limit) || limit <= 0) limit = 100;
  if (limit > 1000) limit = 1000;
  let offset = parseInt(req.query.offset, 10);
  if (Number.isNaN(offset) || offset < 0) offset = 0;

  const params = [];
  const conditions = [];
  if (req.query.event_type) {
    if (!READABLE_EVENT_TYPES.has(req.query.event_type)) {
      const e = apiError(`Unknown event_type: ${req.query.event_type}`, 'BAD_REQUEST', 400);
      return res.status(e.status).json(e.body);
    }
    conditions.push('event_type = ?');
    params.push(req.query.event_type);
  }
  // Free-text search across event_type, metadata (JSON serialized to text by
  // the LIKE coercion), and user_id. Lets an operator find e.g. the variant_id
  // inside a cleanup event's metadata sample. ANDed with the event_type filter.
  // Cap length so an oversized q can't drive a pathological scan/packet.
  const q = typeof req.query.q === 'string' ? req.query.q.trim().slice(0, 200) : '';
  if (q) {
    const like = `%${escapeLikePattern(q)}%`;
    conditions.push(
      "(event_type LIKE ? ESCAPE '|' OR metadata LIKE ? ESCAPE '|' OR user_id LIKE ? ESCAPE '|')",
    );
    params.push(like, like, like);
  }
  const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

  let conn;
  try {
    conn = await pool.ro.getConnection();
    const rows = await conn.query(
      `SELECT id, event_type, user_id, metadata, created_at
         FROM \`${t(TABLES.FEATURE_AUDIT)}\`
         ${where}
         ORDER BY created_at DESC
         LIMIT ? OFFSET ?`,
      [...params, limit, offset],
    );
    const totalRows = await conn.query(
      `SELECT COUNT(*) AS cnt FROM \`${t(TABLES.FEATURE_AUDIT)}\` ${where}`,
      params,
    );
    res.json(apiOk({
      events: mapRowsFromDb('feature_audit', rows),
      total: Number(totalRows[0].cnt) || 0,
      limit,
      offset,
    }));
  } catch (err) {
    logger.error({ err }, 'Failed to read feature_audit rows');
    const e = apiError('Database operation failed', 'INTERNAL_ERROR');
    res.status(e.status).json(e.body);
  } finally {
    if (conn) conn.release();
  }
});

module.exports = router;
