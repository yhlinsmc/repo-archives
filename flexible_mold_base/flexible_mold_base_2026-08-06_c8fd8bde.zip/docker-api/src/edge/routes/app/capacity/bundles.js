/**
 * @openapi
 * /edge/app/capacity/config/bundles:
 *   get:
 *     tags: [App - Capacity]
 *     summary: List global bundle templates, each with its ordered items (all authenticated).
 *     responses:
 *       200: { description: Bundles with nested items }
 *   post:
 *     tags: [App - Capacity]
 *     summary: Create a global bundle (admin+editor). serial auto-assigns when omitted.
 *     responses:
 *       201: { description: Created }
 *       403: { description: Admin or editor required }
 * /edge/app/capacity/config/bundles/{id}:
 *   get:    { tags: [App - Capacity], summary: One bundle with its items }
 *   put:    { tags: [App - Capacity], summary: Update a bundle header (admin+editor) }
 *   delete: { tags: [App - Capacity], summary: Delete a bundle + cascade its items (admin+editor) }
 * /edge/app/capacity/config/bundles/{bundleId}/items:
 *   post:   { tags: [App - Capacity], summary: Add an item to a bundle (admin+editor) }
 * /edge/app/capacity/config/bundles/{bundleId}/items/{id}:
 *   put:    { tags: [App - Capacity], summary: Update a bundle item (admin+editor) }
 *   delete: { tags: [App - Capacity], summary: Delete a bundle item (admin+editor) }
 */

/**
 * capacity/bundles.js — CRUD for the GLOBAL bundle templates (spec §7). A bundle
 * is a pure global-config template that the wizard stamps into a scenario as
 * independent, fully-editable rows recording NO membership back (§7.2). Unlike
 * the catalogue tables, cap_bundles / cap_bundle_items carry NO scenario_id — a
 * bundle is global-only. Read = all authenticated; write = admin+editor (spec §7,
 * the same tier as /config catalogues).
 *
 * Bespoke (not the generic createCrudRoutes factory nor config.js's CONFIG_MOUNTS
 * loop) because bundles have no scenario_id scope and items nest under a bundle.
 * Every bundle-item catalogue FK (profile_id / disk_combo_id / team_id) is
 * write-validated GLOBAL-only via the §17.1a reference-integrity validator
 * (mode 'global') — a global bundle cannot reference a scenario-local row.
 * prefill_custom_group is a NAME string pre-fill, not an FK, so it is unvalidated.
 */
const express = require('express');
const { pool, t } = require('../../../db');
const { requireAuth, requireAdminOrEditor, apiOk, apiError, uuidv4 } = require('../../../../shared/helpers');
const { TABLES } = require('../../../../shared/constants');
const { mapRowsFromDb } = require('../../../lib/dto-mapper');
const { logger } = require('../../../../shared/lib/logger');
const { checkReferences, canonicalKey } = require('./reference-integrity');
const {
  BUNDLE_COLUMNS, BUNDLE_ITEM_COLUMNS, BUNDLE_ITEM_FK_SPECS,
  BUNDLE_ITEM_TYPES, BUNDLE_ITEM_TOPOLOGIES, safeRollback, checkDiskComboPairInTx,
  lockGlobalConfig,
} = require('./_shared');

const router = express.Router();

// RAC cluster node ceiling — mirrors the wizard's RAC cap (spec §10.1) so a
// direct bundle-item write cannot store a cluster larger than the UI allows.
const RAC_NODE_MAX = 100;

// Generous upper bound on a bundle-items reorder body (phase-6 §D12). The endpoint
// requires the COMPLETE current item set, so this must exceed any realistic bundle
// size or a legal full reorder could never succeed.
const MAX_BUNDLE_ITEM_REORDER_ROWS = 1000;

// Generous upper bound on a bundles reorder body (phase-6 §D3 1.5b) — the endpoint
// requires the COMPLETE current bundle set.
const MAX_BUNDLE_REORDER_ROWS = 2000;

const dbError = (res) => {
  const e = apiError('Database operation failed', 'INTERNAL_ERROR', 500);
  res.status(e.status).json(e.body);
};

const badRequest = (res, message) => {
  const e = apiError(message, 'BAD_REQUEST', 400);
  res.status(e.status).json(e.body);
};

// A 400 that preserves the validator's own error code (e.g. INVALID_REFERENCE
// from the §17.1a check) rather than flattening it to BAD_REQUEST.
const rejectWithCode = (res, message, code) => {
  const e = apiError(message, code, 400);
  res.status(e.status).json(e.body);
};

const notFound = (res) => {
  const e = apiError('Not found', 'NOT_FOUND', 404);
  res.status(e.status).json(e.body);
};

// Build the write column set from a body restricted to `allowed`. No JSON columns
// on either bundle table, so values pass through verbatim.
function collectWrite(allowed, body) {
  const cols = [];
  const values = [];
  for (const col of allowed) {
    if (!Object.prototype.hasOwnProperty.call(body, col)) continue;
    cols.push(col);
    values.push(body[col]);
  }
  return { cols, values };
}

// Validate a bundle header write body: `serial` (when supplied) must be a
// positive integer — it is the display order (§7.3), never an arbitrary shape;
// `name` (when supplied) must be a non-empty trimmed string. `serialOptional`
// lets POST treat an omitted/null serial as "auto-assign the next value" rather
// than an error, while PUT rejects a null serial (a bundle cannot lose its
// order). Returns an error message or null.
function validateBundleHeader(body, { serialOptional }) {
  if (Object.prototype.hasOwnProperty.call(body, 'serial')) {
    const s = body.serial;
    const omitted = s === undefined || s === null;
    if (!(omitted && serialOptional) && (!Number.isInteger(s) || s < 1)) {
      return 'serial must be a positive integer';
    }
  }
  if (Object.prototype.hasOwnProperty.call(body, 'name')
    && (typeof body.name !== 'string' || !body.name.trim())) {
    return 'name must not be empty';
  }
  return null;
}

// Validate a bundle-item write body: the ENUM columns (type / topology) reject a
// non-canonical value with a 400 (mirrors children.js CHILD_ENUM_COLUMNS), and
// qty must be a positive integer when present. Returns an error message or null.
function validateItemBody(body) {
  if (Object.prototype.hasOwnProperty.call(body, 'type')
    && !BUNDLE_ITEM_TYPES.includes(body.type)) {
    return `type must be one of ${BUNDLE_ITEM_TYPES.join(', ')}`;
  }
  if (Object.prototype.hasOwnProperty.call(body, 'topology')
    && body.topology !== null && !BUNDLE_ITEM_TOPOLOGIES.includes(body.topology)) {
    return `topology must be one of ${BUNDLE_ITEM_TOPOLOGIES.join(', ')}`;
  }
  if (Object.prototype.hasOwnProperty.call(body, 'qty')
    && (!Number.isInteger(body.qty) || body.qty < 1)) {
    return 'qty must be a positive integer';
  }
  // node_count SHAPE only (2 ≤ N ≤ cap when present/non-null) — the server-side
  // mirror of the FE cap (candidates 514 item 4). The topology COUPLING (RAC
  // requires it, non-RAC forbids it) is checked on the EFFECTIVE merged row by
  // topologyNodeCountError, because a partial PUT can change one of the pair and
  // leave the other stored value inconsistent (Codex P2).
  if (Object.prototype.hasOwnProperty.call(body, 'node_count') && body.node_count !== null
    && (!Number.isInteger(body.node_count) || body.node_count < 2 || body.node_count > RAC_NODE_MAX)) {
    return `node_count must be an integer between 2 and ${RAC_NODE_MAX}`;
  }
  // Phase-2 A4: SGA defaults are nullable non-negative GB sizes (null = inherit
  // the derive chain), and WHOLE numbers (fmb-1433) — this seed is stamped
  // straight into cap_databases' own SGA columns, so it obeys the destination's
  // rule. Shape only here; the DB-only coupling (an AP item carries no SGA) is
  // checked on the EFFECTIVE type by sgaDbOnlyError.
  for (const col of ['primary_sga_gb', 'standby_sga_gb']) {
    if (Object.prototype.hasOwnProperty.call(body, col) && body[col] !== null) {
      const v = body[col];
      if (typeof v !== 'number' || !Number.isFinite(v) || v < 0) {
        return `${col} must be a non-negative number or null`;
      }
      if (!Number.isInteger(v)) return `${col} must be a whole number`;
    }
  }
  return null;
}

// SGA defaults apply to DB items only (spec §3.3 A4: "AP items hide both"). An AP
// effective-type item carrying a non-null Primary/Standby SGA is rejected. Callers
// pass the EFFECTIVE (merged) values: on POST the request IS the row; on PUT the
// merged (body ⊕ stored) SGA so a type→AP flip that leaves stale stored SGA is
// caught (Codex r2 P2-4). `sga` carries primary_sga_gb / standby_sga_gb. Returns an
// error message or null.
function sgaDbOnlyError(effType, sga) {
  if (effType !== 'AP') return null;
  if ((sga.primary_sga_gb != null) || (sga.standby_sga_gb != null)) {
    return 'Primary/Standby SGA apply to DB items only';
  }
  return null;
}

// The topology/node_count coupling on the EFFECTIVE (merged) row: RAC requires a
// node_count in range; every other topology (single / primary / primary_standby,
// or an AP item's null topology) must carry NO node_count. Called with the
// post-merge values so a PUT that flips topology away from RAC while a stale
// node_count remains stored — or a RAC POST that omits node_count — is rejected
// (Codex P2). Returns an error message or null.
function topologyNodeCountError(topology, nodeCount) {
  const hasNode = nodeCount !== null && nodeCount !== undefined;
  if (topology === 'rac') {
    if (!hasNode) return `RAC topology requires node_count (an integer between 2 and ${RAC_NODE_MAX})`;
    return null;
  }
  if (hasNode) return 'node_count is only valid for the RAC topology';
  return null;
}

// Run the §17.1a global-only FK check for the item FKs present in `body`.
// Returns an apiError-shaped rejection, or null. `conn` is the write
// TRANSACTION connection: `lock: true` probes each referenced catalogue row
// FOR UPDATE so a concurrent catalogue DELETE cannot commit between this check
// and the caller's INSERT/UPDATE (cap_bundle_items has no DB-level FK, so a lost
// race would dangle the reference).
async function checkItemGlobalFks(conn, body) {
  const active = BUNDLE_ITEM_FK_SPECS
    .filter((s) => Object.prototype.hasOwnProperty.call(body, s.column))
    .map((s) => ({ ...s, value: body[s.column] }));
  if (!active.length) return null;
  const result = await checkReferences(conn, undefined, active, { lock: true });
  if (!result.ok) return { message: result.message, code: result.code };
  // The statement binds what the check resolved. These columns are `CHAR(36)`
  // under a case-folding collation, so the check admits any spelling of a legal
  // reference — and the INSERT/UPDATE below writes `body[column]` verbatim. A
  // stored spelling the catalogue row does not hold still resolves in SQL and
  // resolves nothing for the wizard's stamp, which reads a bundle item's
  // profile out of a Map keyed on the profile's own id.
  for (const s of active) {
    const stored = result.canonical.get(canonicalKey(s.table, s.value));
    if (stored != null) body[s.column] = stored;
  }
  return null;
}

// A bundle item's `type` must match the referenced profile's `class` (a DB item
// → a DB profile, an AP item → an AP profile). Reads the profile row FOR UPDATE
// inside the caller's transaction. `effType` / `effProfileId` are the EFFECTIVE
// (merged) values so a PUT that changes only one of the pair still validates
// against the other's stored value. Existence is left to the §17.1a FK check
// (a missing profile is reported there), so a not-found row is skipped here.
// Returns an apiError-shaped rejection, or null.
async function checkItemProfileClass(conn, effType, effProfileId) {
  if (effProfileId == null) return null;
  const rows = await conn.query(
    `SELECT class FROM \`${t(TABLES.CAP_VM_PROFILES)}\` WHERE id = ? FOR UPDATE`, [effProfileId],
  );
  if (!rows.length) return null;
  return itemProfileClassError(effType, rows[0].class);
}

// The PURE item.type ↔ profile.class rule (a DB item needs a DB profile, an AP
// item an AP profile). Extracted so the gated config-import path (config-import.js)
// reuses the EXACT rule the direct write path enforces, resolving the profile from
// the in-payload rows rather than the DB. Returns an apiError-shaped rejection or null.
function itemProfileClassError(effType, profileClass) {
  if (profileClass == null) return null;
  if (profileClass !== effType) {
    return {
      code: 'INVALID_REFERENCE',
      message: `type ${effType} does not match the referenced profile class ${profileClass}`,
    };
  }
  return null;
}

// GET /config/bundles — every bundle with its ordered items nested (the config
// page's right rail renders bundle cards each with a mini-table of items, §7.3).
router.get('/', async (req, res) => {
  if (!requireAuth(req, res)) return;
  try {
    const bundles = await pool.ro.query(
      // phase-6 §D3 (1.5b): order_index is the display-order driver; serial is now
      // just a user-edited label kept as a stable tiebreaker.
      `SELECT * FROM \`${t(TABLES.CAP_BUNDLES)}\` ORDER BY order_index ASC, serial ASC, created_at ASC`,
    );
    const items = await pool.ro.query(
      `SELECT * FROM \`${t(TABLES.CAP_BUNDLE_ITEMS)}\` ORDER BY order_index ASC, created_at ASC`,
    );
    const mappedItems = mapRowsFromDb(TABLES.CAP_BUNDLE_ITEMS, items);
    const byBundle = new Map();
    for (const item of mappedItems) {
      if (!byBundle.has(item.bundle_id)) byBundle.set(item.bundle_id, []);
      byBundle.get(item.bundle_id).push(item);
    }
    const mapped = mapRowsFromDb(TABLES.CAP_BUNDLES, bundles)
      .map((b) => ({ ...b, items: byBundle.get(b.id) || [] }));
    res.json(apiOk(mapped));
  } catch (err) {
    logger.error({ err }, 'Failed to list capacity bundles');
    dbError(res);
  }
});

// GET /config/bundles/:id — one bundle with its items.
router.get('/:id', async (req, res) => {
  if (!requireAuth(req, res)) return;
  try {
    const bundles = await pool.ro.query(
      `SELECT * FROM \`${t(TABLES.CAP_BUNDLES)}\` WHERE id = ?`, [req.params.id],
    );
    if (!bundles.length) return notFound(res);
    const items = await pool.ro.query(
      `SELECT * FROM \`${t(TABLES.CAP_BUNDLE_ITEMS)}\` WHERE bundle_id = ? ORDER BY order_index ASC, created_at ASC`,
      [req.params.id],
    );
    const bundle = mapRowsFromDb(TABLES.CAP_BUNDLES, bundles)[0];
    bundle.items = mapRowsFromDb(TABLES.CAP_BUNDLE_ITEMS, items);
    res.json(apiOk(bundle));
  } catch (err) {
    logger.error({ err }, 'Failed to fetch capacity bundle');
    dbError(res);
  }
});

// POST /config/bundles — create a bundle header (admin+editor). serial is
// server-assigned to the next value when the body omits it (the display order,
// §7.3) so the client never has to manage it.
router.post('/', async (req, res) => {
  if (!requireAdminOrEditor(req, res)) return;
  const body = req.body || {};
  const headerErr = validateBundleHeader(body, { serialOptional: true });
  if (headerErr) return badRequest(res, headerErr);
  const name = typeof body.name === 'string' ? body.name.trim() : '';
  if (!name) return badRequest(res, 'name is required');
  const id = uuidv4();
  let conn;
  try {
    conn = await pool.rw.getConnection();
    await conn.beginTransaction();
    // Serialize this global-bundle create against the first-instance config import
    // (P1): the sentinel lock is taken first so a bundle created between the import's
    // empty-gate check and its clear cannot be silently wiped.
    await lockGlobalConfig(conn);
    let serial = body.serial;
    if (serial === undefined || serial === null) {
      // Allocate the next serial under a lock so two concurrent auto-serial POSTs
      // cannot read the same MAX and collide. FOR UPDATE only locks the rows it
      // scans — on an EMPTY table it locks nothing, so the very first two concurrent
      // inserts could still tie; the uq_cap_bundles_serial UNIQUE key (v3.2.520) is
      // the backstop that turns that residual race into a 1062 → 409 (mapped below),
      // never a silent duplicate.
      const rows = await conn.query(
        `SELECT COALESCE(MAX(serial), 0) + 1 AS next FROM \`${t(TABLES.CAP_BUNDLES)}\` FOR UPDATE`,
      );
      serial = rows[0] ? Number(rows[0].next) : 1;
    } else {
      // Explicit serial: reject a collision with an existing bundle up front (a
      // friendly 409), paired with the UNIQUE backstop for the race. The probe runs
      // in this transaction so the row it sees cannot vanish before the INSERT.
      const dup = await conn.query(
        `SELECT id FROM \`${t(TABLES.CAP_BUNDLES)}\` WHERE serial = ? LIMIT 1`, [serial],
      );
      if (dup.length) {
        await safeRollback(conn);
        const e = apiError(`serial ${serial} is already in use by another bundle`, 'CONFLICT', 409);
        return res.status(e.status).json(e.body);
      }
    }
    // phase-6 §D3 (1.5b): a new bundle lands at the END of the rail order
    // (order_index = MAX+1), read under the sentinel lock so concurrent creates
    // serialise. The /config/bundles/reorder route is the only path that changes
    // an existing bundle's order.
    const orderRows = await conn.query(
      `SELECT COALESCE(MAX(order_index), -1) + 1 AS next FROM \`${t(TABLES.CAP_BUNDLES)}\``,
    );
    const orderIndex = Number(orderRows[0] ? orderRows[0].next : 0);
    await conn.query(
      `INSERT INTO \`${t(TABLES.CAP_BUNDLES)}\` (id, serial, name, order_index) VALUES (?, ?, ?, ?)`,
      [id, serial, name, orderIndex],
    );
    const rows = await conn.query(
      `SELECT * FROM \`${t(TABLES.CAP_BUNDLES)}\` WHERE id = ?`, [id],
    );
    await conn.commit();
    const bundle = mapRowsFromDb(TABLES.CAP_BUNDLES, rows)[0];
    bundle.items = [];
    res.status(201).json(apiOk(bundle));
  } catch (err) {
    await safeRollback(conn);
    // uq_cap_bundles_serial backstop: a serial that raced past the pre-check
    // (empty-table auto-assign tie, or a concurrent explicit insert) surfaces as
    // 1062 → the same friendly 409 the pre-check returns.
    if (err && err.errno === 1062) {
      const e = apiError('serial is already in use by another bundle', 'CONFLICT', 409);
      return res.status(e.status).json(e.body);
    }
    logger.error({ err }, 'Failed to create capacity bundle');
    dbError(res);
  } finally {
    if (conn) conn.release();
  }
});

// PUT /config/bundles/reorder — bulk order_index rewrite for the whole Bundles
// rail (phase-6 spec §D3 1.5b). Registered BEFORE the generic `PUT /:id` so
// "reorder" is not treated as a bundle id. Same contract as the other reorder
// routes: the body's id set must equal the current bundle set EXACTLY (a
// partial/foreign list is rejected 400), rewritten in one transaction under the
// global-config sentinel lock. Write = admin+editor.
router.put('/reorder', async (req, res) => {
  if (!requireAdminOrEditor(req, res)) return;
  const { orderedIds } = req.body || {};
  if (
    !Array.isArray(orderedIds)
    || orderedIds.length === 0
    || !orderedIds.every((id) => typeof id === 'string' && id.length > 0)
  ) {
    return badRequest(res, 'orderedIds must be a non-empty array of bundle ids');
  }
  if (orderedIds.length > MAX_BUNDLE_REORDER_ROWS) {
    return badRequest(res, `orderedIds exceeds ${MAX_BUNDLE_REORDER_ROWS} limit`);
  }
  if (new Set(orderedIds).size !== orderedIds.length) {
    return badRequest(res, 'orderedIds contains a duplicate id');
  }
  let conn;
  try {
    conn = await pool.rw.getConnection();
    await conn.beginTransaction();
    // Serialize against the config import (P1); then lock every bundle row and
    // require the body to match exactly — closes a stale-tab move (a bundle
    // deleted elsewhere) and rejects a foreign id smuggled into the rewrite.
    await lockGlobalConfig(conn);
    const existing = await conn.query(
      `SELECT id FROM \`${t(TABLES.CAP_BUNDLES)}\` FOR UPDATE`,
    );
    const existingIds = new Set(existing.map((r) => r.id));
    const bodyIds = new Set(orderedIds);
    const sameSet = existingIds.size === bodyIds.size && [...existingIds].every((id) => bodyIds.has(id));
    if (!sameSet) {
      await safeRollback(conn);
      return badRequest(res, 'orderedIds must match the current bundle set exactly');
    }
    for (let i = 0; i < orderedIds.length; i += 1) {
      await conn.query(
        `UPDATE \`${t(TABLES.CAP_BUNDLES)}\` SET order_index = ? WHERE id = ?`,
        [i, orderedIds[i]],
      );
    }
    await conn.commit();
    res.json(apiOk({ reordered: orderedIds.length }));
  } catch (err) {
    await safeRollback(conn);
    logger.error({ err }, 'Failed to reorder capacity bundles');
    dbError(res);
  } finally {
    if (conn) conn.release();
  }
});

// PUT /config/bundles/:id — update a bundle header (serial / name).
router.put('/:id', async (req, res) => {
  if (!requireAdminOrEditor(req, res)) return;
  const body = req.body || {};
  const headerErr = validateBundleHeader(body, { serialOptional: false });
  if (headerErr) return badRequest(res, headerErr);
  // Store the trimmed name so a rename lands the same normalized value POST does.
  if (typeof body.name === 'string') body.name = body.name.trim();
  const { cols, values } = collectWrite(BUNDLE_COLUMNS, body);
  if (!cols.length) return badRequest(res, 'No writable fields supplied');
  let conn;
  try {
    conn = await pool.rw.getConnection();
    // One transaction under the global-config sentinel lock (P1) so this update is
    // serialized against the config import's clear-then-insert.
    await conn.beginTransaction();
    await lockGlobalConfig(conn);
    // A serial change must not collide with ANOTHER bundle's serial — validateBundleHeader
    // only checks the shape (positive integer), so without this a PUT could set an
    // arbitrary duplicate serial. Friendly 409 up front; the uq_cap_bundles_serial
    // UNIQUE key (v3.2.520) is the race backstop (mapped below).
    if (Object.prototype.hasOwnProperty.call(body, 'serial') && body.serial != null) {
      const dup = await conn.query(
        `SELECT id FROM \`${t(TABLES.CAP_BUNDLES)}\` WHERE serial = ? AND id <> ? LIMIT 1`,
        [body.serial, req.params.id],
      );
      if (dup.length) {
        await safeRollback(conn);
        const e = apiError(`serial ${body.serial} is already in use by another bundle`, 'CONFLICT', 409);
        return res.status(e.status).json(e.body);
      }
    }
    const sets = cols.map((c) => `\`${c}\` = ?`).join(', ');
    const result = await conn.query(
      `UPDATE \`${t(TABLES.CAP_BUNDLES)}\` SET ${sets} WHERE id = ?`,
      [...values, req.params.id],
    );
    if (!result.affectedRows) { await safeRollback(conn); return notFound(res); }
    const rows = await conn.query(
      `SELECT * FROM \`${t(TABLES.CAP_BUNDLES)}\` WHERE id = ?`, [req.params.id],
    );
    await conn.commit();
    res.json(apiOk(mapRowsFromDb(TABLES.CAP_BUNDLES, rows)[0]));
  } catch (err) {
    await safeRollback(conn);
    if (err && err.errno === 1062) {
      const e = apiError('serial is already in use by another bundle', 'CONFLICT', 409);
      return res.status(e.status).json(e.body);
    }
    logger.error({ err }, 'Failed to update capacity bundle');
    dbError(res);
  } finally {
    if (conn) conn.release();
  }
});

// DELETE /config/bundles/:id — delete the bundle and cascade its items in one
// transaction (no back-reference exists elsewhere: stamping records no
// membership, §7.2, so nothing else points at a bundle).
router.delete('/:id', async (req, res) => {
  if (!requireAdminOrEditor(req, res)) return;
  let conn;
  try {
    conn = await pool.rw.getConnection();
    await conn.beginTransaction();
    // Sentinel lock first (P1) so the delete serializes against the config import.
    await lockGlobalConfig(conn);
    const rows = await conn.query(
      `SELECT id FROM \`${t(TABLES.CAP_BUNDLES)}\` WHERE id = ? FOR UPDATE`, [req.params.id],
    );
    if (!rows.length) { await safeRollback(conn); return notFound(res); }
    await conn.query(
      `DELETE FROM \`${t(TABLES.CAP_BUNDLE_ITEMS)}\` WHERE bundle_id = ?`, [req.params.id],
    );
    await conn.query(
      `DELETE FROM \`${t(TABLES.CAP_BUNDLES)}\` WHERE id = ?`, [req.params.id],
    );
    await conn.commit();
    res.json(apiOk({ id: req.params.id, deleted: true }));
  } catch (err) {
    await safeRollback(conn);
    logger.error({ err }, 'Failed to delete capacity bundle');
    dbError(res);
  } finally {
    if (conn) conn.release();
  }
});

// POST /config/bundles/:bundleId/items — add an item to a bundle (admin+editor).
router.post('/:bundleId/items', async (req, res) => {
  if (!requireAdminOrEditor(req, res)) return;
  const body = req.body || {};
  const bodyErr = validateItemBody(body);
  if (bodyErr) return badRequest(res, bodyErr);
  if (!BUNDLE_ITEM_TYPES.includes(body.type)) return badRequest(res, 'type is required');
  // On create the request IS the effective row: an AP item may not carry SGA.
  const sgaErr = sgaDbOnlyError(body.type, body);
  if (sgaErr) return badRequest(res, sgaErr);
  // On create the request IS the effective row: enforce the topology/node_count
  // coupling directly (a null topology → AP item, forbids node_count).
  const couplingErr = topologyNodeCountError(
    Object.prototype.hasOwnProperty.call(body, 'topology') ? body.topology : null,
    Object.prototype.hasOwnProperty.call(body, 'node_count') ? body.node_count : null,
  );
  if (couplingErr) return badRequest(res, couplingErr);
  const id = uuidv4();
  let conn;
  try {
    conn = await pool.rw.getConnection();
    // One transaction so the parent-exists lock and the §17.1a global-FK probe
    // cannot be invalidated by a concurrent bundle/catalogue delete landing
    // between the checks and the INSERT (would otherwise dangle the FK).
    await conn.beginTransaction();
    // Sentinel lock first (P1) so this item create serializes against the config
    // import's clear-then-insert.
    await lockGlobalConfig(conn);
    // The parent bundle must exist (else the item would orphan); lock it so it
    // cannot be deleted before this INSERT commits.
    const bundle = await conn.query(
      `SELECT id FROM \`${t(TABLES.CAP_BUNDLES)}\` WHERE id = ? FOR UPDATE`, [req.params.bundleId],
    );
    if (!bundle.length) { await safeRollback(conn); return notFound(res); }
    // phase-6 spec §D12: an added item lands at the END of the bundle's order
    // (order_index = MAX+1) unless the caller supplied an explicit index (the
    // config-import seed path does). Read under the bundle FOR UPDATE lock so
    // concurrent appends serialise; the /items/reorder route is the only path
    // that changes an existing item's index.
    if (body.order_index === undefined || body.order_index === null) {
      const maxRows = await conn.query(
        `SELECT COALESCE(MAX(order_index), -1) + 1 AS next FROM \`${t(TABLES.CAP_BUNDLE_ITEMS)}\` WHERE bundle_id = ?`,
        [req.params.bundleId],
      );
      body.order_index = Number(maxRows[0] ? maxRows[0].next : 0);
    }
    const fkErr = await checkItemGlobalFks(conn, body);
    if (fkErr) { await safeRollback(conn); return rejectWithCode(res, fkErr.message, fkErr.code); }
    // type must match the referenced profile's class (body.type is required + valid here).
    const classErr = await checkItemProfileClass(conn, body.type, body.profile_id ?? null);
    if (classErr) { await safeRollback(conn); return rejectWithCode(res, classErr.message, classErr.code); }
    // A bundle item's profile+disk pair must obey the profile's allow-list (§5.3);
    // an unusable stamp would otherwise be savable but rejected at every wizard
    // stamp (server-side derivation now validates the produced payload).
    const comboErr = await checkDiskComboPairInTx(conn, body.profile_id ?? null, body.disk_combo_id ?? null);
    if (comboErr) { await safeRollback(conn); return rejectWithCode(res, comboErr.message, comboErr.code); }
    const { cols, values } = collectWrite(BUNDLE_ITEM_COLUMNS, body);
    const allCols = ['id', 'bundle_id', ...cols];
    const quoted = allCols.map((c) => `\`${c}\``).join(', ');
    const placeholders = allCols.map(() => '?');
    await conn.query(
      `INSERT INTO \`${t(TABLES.CAP_BUNDLE_ITEMS)}\` (${quoted}) VALUES (${placeholders.join(', ')})`,
      [id, req.params.bundleId, ...values],
    );
    const rows = await conn.query(
      `SELECT * FROM \`${t(TABLES.CAP_BUNDLE_ITEMS)}\` WHERE id = ?`, [id],
    );
    await conn.commit();
    res.status(201).json(apiOk(mapRowsFromDb(TABLES.CAP_BUNDLE_ITEMS, rows)[0]));
  } catch (err) {
    await safeRollback(conn);
    logger.error({ err }, 'Failed to create capacity bundle item');
    dbError(res);
  } finally {
    if (conn) conn.release();
  }
});

// PUT /config/bundles/:bundleId/items/reorder — bulk order_index rewrite for one
// bundle's items (phase-6 spec §D12). Registered BEFORE the generic
// `PUT /:bundleId/items/:id` so "reorder" is not treated as an item id. Same
// contract as reorder.js: the body's id set must equal the bundle's current item
// set EXACTLY (a partial/foreign list is rejected 400), rewritten in one
// transaction under the global-config sentinel lock. Write = admin+editor.
router.put('/:bundleId/items/reorder', async (req, res) => {
  if (!requireAdminOrEditor(req, res)) return;
  const { orderedIds } = req.body || {};
  if (
    !Array.isArray(orderedIds)
    || orderedIds.length === 0
    || !orderedIds.every((id) => typeof id === 'string' && id.length > 0)
  ) {
    return badRequest(res, 'orderedIds must be a non-empty array of bundle item ids');
  }
  if (orderedIds.length > MAX_BUNDLE_ITEM_REORDER_ROWS) {
    return badRequest(res, `orderedIds exceeds ${MAX_BUNDLE_ITEM_REORDER_ROWS} limit`);
  }
  if (new Set(orderedIds).size !== orderedIds.length) {
    return badRequest(res, 'orderedIds contains a duplicate id');
  }
  let conn;
  try {
    conn = await pool.rw.getConnection();
    await conn.beginTransaction();
    // Serialize against the config import (P1); then lock the parent bundle so it
    // cannot be deleted mid-rewrite.
    await lockGlobalConfig(conn);
    const bundle = await conn.query(
      `SELECT id FROM \`${t(TABLES.CAP_BUNDLES)}\` WHERE id = ? FOR UPDATE`, [req.params.bundleId],
    );
    if (!bundle.length) { await safeRollback(conn); return notFound(res); }
    // Lock the bundle's current item set, then require the body to match exactly —
    // closes a stale-tab drag (an item deleted elsewhere mid-drag) and rejects a
    // foreign item id smuggled into the rewrite.
    const existing = await conn.query(
      `SELECT id FROM \`${t(TABLES.CAP_BUNDLE_ITEMS)}\` WHERE bundle_id = ? FOR UPDATE`, [req.params.bundleId],
    );
    const existingIds = new Set(existing.map((r) => r.id));
    const bodyIds = new Set(orderedIds);
    const sameSet = existingIds.size === bodyIds.size && [...existingIds].every((id) => bodyIds.has(id));
    if (!sameSet) {
      await safeRollback(conn);
      return badRequest(res, "orderedIds must match this bundle's current item set exactly");
    }
    for (let i = 0; i < orderedIds.length; i += 1) {
      await conn.query(
        `UPDATE \`${t(TABLES.CAP_BUNDLE_ITEMS)}\` SET order_index = ? WHERE id = ? AND bundle_id = ?`,
        [i, orderedIds[i], req.params.bundleId],
      );
    }
    await conn.commit();
    res.json(apiOk({ reordered: orderedIds.length }));
  } catch (err) {
    await safeRollback(conn);
    logger.error({ err }, 'Failed to reorder capacity bundle items');
    dbError(res);
  } finally {
    if (conn) conn.release();
  }
});

// PUT /config/bundles/:bundleId/items/:id — update a bundle item. The item must
// belong to the URL bundle (else 404), and any changed catalogue FK re-passes the
// §17.1a global-only check.
router.put('/:bundleId/items/:id', async (req, res) => {
  if (!requireAdminOrEditor(req, res)) return;
  const body = req.body || {};
  const bodyErr = validateItemBody(body);
  if (bodyErr) return badRequest(res, bodyErr);
  const { cols, values } = collectWrite(BUNDLE_ITEM_COLUMNS, body);
  if (!cols.length) return badRequest(res, 'No writable fields supplied');
  let conn;
  try {
    conn = await pool.rw.getConnection();
    // One transaction so the belongs-to lock and the §17.1a global-FK probe
    // cannot be invalidated by a concurrent delete of the referenced catalogue
    // row between the checks and the UPDATE.
    await conn.beginTransaction();
    // Sentinel lock first (P1) so this item update serializes against the config import.
    await lockGlobalConfig(conn);
    // Read the stored type + profile_id + SGA alongside the belongs-to lock so the
    // class and DB-only-SGA checks can validate the EFFECTIVE (merged) row when a PUT
    // changes only one of the coupled fields.
    const existing = await conn.query(
      `SELECT id, type, profile_id, disk_combo_id, topology, node_count, primary_sga_gb, standby_sga_gb FROM \`${t(TABLES.CAP_BUNDLE_ITEMS)}\` WHERE id = ? AND bundle_id = ? FOR UPDATE`,
      [req.params.id, req.params.bundleId],
    );
    if (!existing.length) { await safeRollback(conn); return notFound(res); }
    const fkErr = await checkItemGlobalFks(conn, body);
    if (fkErr) { await safeRollback(conn); return rejectWithCode(res, fkErr.message, fkErr.code); }
    // An AP item may not carry SGA — check the EFFECTIVE (merged) type AND SGA
    // values (Codex r2 P2-4): a PUT flipping type to AP without resending the SGA
    // fields leaves the STORED SGA values, so a body-only check would miss the stale
    // pair. Mirrors the topology/node_count merge below (reject, don't auto-clear).
    {
      const has = (k) => Object.prototype.hasOwnProperty.call(body, k);
      const effType = has('type') ? body.type : existing[0].type;
      const effPrimary = has('primary_sga_gb') ? body.primary_sga_gb : existing[0].primary_sga_gb;
      const effStandby = has('standby_sga_gb') ? body.standby_sga_gb : existing[0].standby_sga_gb;
      const sgaErr = sgaDbOnlyError(effType, { primary_sga_gb: effPrimary, standby_sga_gb: effStandby });
      if (sgaErr) { await safeRollback(conn); return badRequest(res, sgaErr); }
    }
    // Validate the EFFECTIVE topology/node_count pair — a PUT changing only one
    // of them keeps the stored value for the other, so a flip to a non-RAC
    // topology while node_count stays set (or vice versa) is caught here (Codex P2).
    {
      const hasT = Object.prototype.hasOwnProperty.call(body, 'topology');
      const hasN = Object.prototype.hasOwnProperty.call(body, 'node_count');
      const effTopology = hasT ? body.topology : existing[0].topology;
      const effNodeCount = hasN ? body.node_count : existing[0].node_count;
      const couplingErr = topologyNodeCountError(effTopology, effNodeCount);
      if (couplingErr) { await safeRollback(conn); return badRequest(res, couplingErr); }
    }
    // When a PUT touches type and/or profile_id, re-validate the merged pair
    // against the profile's class (unchanged fields keep their stored value).
    const has = (k) => Object.prototype.hasOwnProperty.call(body, k);
    if (has('type') || has('profile_id')) {
      const effType = has('type') ? body.type : existing[0].type;
      const effProfileId = has('profile_id') ? body.profile_id : existing[0].profile_id;
      const classErr = await checkItemProfileClass(conn, effType, effProfileId);
      if (classErr) { await safeRollback(conn); return rejectWithCode(res, classErr.message, classErr.code); }
    }
    // Re-validate the merged profile+disk pair against the allow-list (§5.3) when a
    // PUT touches either side (an unchanged side keeps its stored value).
    if (has('profile_id') || has('disk_combo_id')) {
      const effProfileId = has('profile_id') ? body.profile_id : existing[0].profile_id;
      const effDiskComboId = has('disk_combo_id') ? body.disk_combo_id : existing[0].disk_combo_id;
      const comboErr = await checkDiskComboPairInTx(conn, effProfileId ?? null, effDiskComboId ?? null);
      if (comboErr) { await safeRollback(conn); return rejectWithCode(res, comboErr.message, comboErr.code); }
    }
    const sets = cols.map((c) => `\`${c}\` = ?`).join(', ');
    await conn.query(
      `UPDATE \`${t(TABLES.CAP_BUNDLE_ITEMS)}\` SET ${sets} WHERE id = ? AND bundle_id = ?`,
      [...values, req.params.id, req.params.bundleId],
    );
    const rows = await conn.query(
      `SELECT * FROM \`${t(TABLES.CAP_BUNDLE_ITEMS)}\` WHERE id = ?`, [req.params.id],
    );
    await conn.commit();
    res.json(apiOk(mapRowsFromDb(TABLES.CAP_BUNDLE_ITEMS, rows)[0]));
  } catch (err) {
    await safeRollback(conn);
    logger.error({ err }, 'Failed to update capacity bundle item');
    dbError(res);
  } finally {
    if (conn) conn.release();
  }
});

// DELETE /config/bundles/:bundleId/items/:id — delete one item.
router.delete('/:bundleId/items/:id', async (req, res) => {
  if (!requireAdminOrEditor(req, res)) return;
  let conn;
  try {
    conn = await pool.rw.getConnection();
    // Delete under the global-config sentinel lock (P1) so it serializes against
    // the config import's clear-then-insert.
    await conn.beginTransaction();
    await lockGlobalConfig(conn);
    const result = await conn.query(
      `DELETE FROM \`${t(TABLES.CAP_BUNDLE_ITEMS)}\` WHERE id = ? AND bundle_id = ?`,
      [req.params.id, req.params.bundleId],
    );
    if (!result.affectedRows) { await safeRollback(conn); return notFound(res); }
    await conn.commit();
    res.json(apiOk({ id: req.params.id, deleted: true }));
  } catch (err) {
    await safeRollback(conn);
    logger.error({ err }, 'Failed to delete capacity bundle item');
    dbError(res);
  } finally {
    if (conn) conn.release();
  }
});

module.exports = router;
// Pure item-validation rules reused by the gated config-import path (config-import.js)
// so an imported bundle item obeys the same checks a direct write does (spec Fix-3
// ruling: reuse, do not duplicate). The DB-bound wrappers stay route-private.
// validateBundleHeader / validateItemBody are exported for the same reuse (P2-1).
module.exports.sgaDbOnlyError = sgaDbOnlyError;
module.exports.topologyNodeCountError = topologyNodeCountError;
module.exports.itemProfileClassError = itemProfileClassError;
module.exports.validateBundleHeader = validateBundleHeader;
module.exports.validateItemBody = validateItemBody;
