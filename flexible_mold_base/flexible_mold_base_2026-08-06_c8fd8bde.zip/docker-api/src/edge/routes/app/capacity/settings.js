/**
 * @openapi
 * /edge/app/capacity/scenarios/{scenarioId}/settings:
 *   get:
 *     tags: [App - Capacity]
 *     summary: Get the scenario's cap_settings singleton row (all authenticated).
 *     parameters:
 *       - { name: scenarioId, in: path, required: true, schema: { type: string } }
 *     responses:
 *       200: { description: The scenario's EFFECTIVE settings — its own override row (is_override true) or the global seed fallback (is_override false) }
 *       404: { description: The scenario id does not exist, or no global settings seed row is present }
 *   put:
 *     tags: [App - Capacity]
 *     summary: Update the scenario's cap_settings singleton row (owner+admin).
 *     parameters:
 *       - { name: scenarioId, in: path, required: true, schema: { type: string } }
 *     responses:
 *       200: { description: Updated (or minted, if the scenario had none yet) }
 *       403: { description: Not the scenario owner (and not admin/editor) }
 */

/**
 * capacity/settings.js — per-scenario cap_settings singleton (PR-B Task 1).
 *
 * Unlike every other scenario-scoped child (children.js), a scenario carries
 * AT MOST ONE cap_settings row — an OPTIONAL per-scenario OVERRIDE of the global
 * settings row (spec §9 / §2.4). In the reference model (spec §2) scenario
 * create copies nothing; a scenario without an override row falls back to the
 * seeded GLOBAL settings row (the evaluator snapshot resolves that fallback,
 * violations.js). This mount is bespoke rather than the generic
 * createCrudRoutes factory (which has no singleton semantic): GET returns the
 * scenario's override row, PUT edits it — and, race-safely, MINTS the override
 * row on first write. There is deliberately no POST and no DELETE.
 *
 * Permission mirrors every other scenario child (owner + admin via
 * SCENARIO_OWNERSHIP, spec §7) — NOT admin+editor, which is config.js's
 * global-template tier only.
 */
const express = require('express');
const { pool, t } = require('../../../db');
const {
  requireAuth, requireAdminOrEditor, apiOk, apiError, uuidv4,
} = require('../../../../shared/helpers');
const { TABLES } = require('../../../../shared/constants');
const { mapRowsFromDb } = require('../../../lib/dto-mapper');
const { logger } = require('../../../../shared/lib/logger');
const { validateColumnTypes, SETTINGS_COLUMN_TYPES } = require('./_shared');
const { sameStoredValue } = require('../schema/write-value');

const router = express.Router();

const WRITABLE_COLUMNS = [
  'mem_cpu_ratio', 'sga_factor', 'sga_divisor', 'sga_subtract', 'util_amber_pct',
  'util_red_pct', 'overcommit_default_enabled', 'layer_defaults',
];

function collectWrite(body) {
  const cols = [];
  const values = [];
  for (const col of WRITABLE_COLUMNS) {
    if (!Object.prototype.hasOwnProperty.call(body, col)) continue;
    let v = body[col];
    if (col === 'layer_defaults' && v !== null && typeof v === 'object') v = JSON.stringify(v);
    cols.push(col);
    values.push(v);
  }
  return { cols, values };
}

const dbError = (res) => {
  const e = apiError('Database operation failed', 'INTERNAL_ERROR', 500);
  res.status(e.status).json(e.body);
};

// GET returns the scenario's EFFECTIVE settings (config-rewrite obligation 4 /
// spec §2.4 / §9.2): the scenario's own OVERRIDE row when present (is_override
// true), else the guaranteed GLOBAL seed row as a fallback (is_override false).
// It never 404s on "no override row" — that path was the §9.1 undefined-crash
// family; the reference model guarantees a global row so the effective settings
// always resolve. A 404 is reserved for a scenario id that does not exist (a
// fallback for a non-existent scenario would mask a bad id). This keeps the FE
// queryFn's never-undefined obligation (§9.2 guard 2) satisfiable with a real
// payload rather than an empty resolve.
router.get('/scenarios/:scenarioId/settings', async (req, res) => {
  if (!requireAuth(req, res)) return;
  const scenarioId = req.params.scenarioId;
  try {
    const scen = await pool.ro.query(
      `SELECT 1 AS ok FROM \`${t(TABLES.CAP_SCENARIOS)}\` WHERE id = ?`, [scenarioId],
    );
    if (!scen.length) {
      const e = apiError('Not found', 'NOT_FOUND', 404);
      return res.status(e.status).json(e.body);
    }
    const overrideRows = await pool.ro.query(
      `SELECT * FROM \`${t(TABLES.CAP_SETTINGS)}\` WHERE scenario_id = ?`, [scenarioId],
    );
    if (overrideRows.length) {
      const row = mapRowsFromDb(TABLES.CAP_SETTINGS, overrideRows)[0];
      return res.json(apiOk({ ...row, is_override: true }));
    }
    const globalRows = await pool.ro.query(
      `SELECT * FROM \`${t(TABLES.CAP_SETTINGS)}\` WHERE scenario_id IS NULL LIMIT 1`,
    );
    if (!globalRows.length) {
      // The seed guarantees a global row; its absence means an un-seeded / broken
      // DB. 404 rather than fabricate constants — the FE queryFn maps it to null.
      const e = apiError('No settings available', 'NOT_FOUND', 404);
      return res.status(e.status).json(e.body);
    }
    const row = mapRowsFromDb(TABLES.CAP_SETTINGS, globalRows)[0];
    res.json(apiOk({ ...row, is_override: false }));
  } catch (err) {
    logger.error({ err, scenarioId }, 'Failed to fetch capacity scenario settings');
    dbError(res);
  }
});

router.put('/scenarios/:scenarioId/settings', async (req, res) => {
  // Role gate FIRST (mirrors children.js childWriteRoleGate / makeChildDelete):
  // a plain user is refused before any DB-touching guard runs, regardless of
  // ownership — editor write additionally requires owning (or a shared) scenario.
  if (!requireAdminOrEditor(req, res)) return;
  const scenarioId = req.params.scenarioId;
  // Type-check the RAW body before collectWrite's JSON stringification, so a
  // wrong-shaped value (e.g. a string where a number is expected) 400s with
  // the offending column name instead of either violating the DB column's
  // type at INSERT/UPDATE time (a 500) or silently coercing.
  const typeErr = validateColumnTypes(req.body || {}, SETTINGS_COLUMN_TYPES);
  if (typeErr) {
    const e = apiError(typeErr, 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }
  const { cols, values } = collectWrite(req.body || {});
  if (!cols.length) {
    const e = apiError('No writable fields supplied', 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }

  let conn;
  try {
    conn = await pool.rw.getConnection();
    await conn.beginTransaction();

    // Locking the scenario row here is also the cardinality guard: two
    // concurrent PUTs for the same scenario serialize on this lock, so the
    // "settings row exists?" check below can never race into a double INSERT.
    // The id comes back with the owner because the INSERT below binds it. This
    // `WHERE id = ?` resolves the scenario for any spelling of it — the column
    // is CHAR(36) under a case-folding collation — so binding the caller's
    // spelling would stamp the settings row with a value no scenario's id
    // holds. Every SQL reader would still find it and every JavaScript reader
    // would not, which is the same split the scenario-scoped child mounts
    // produced.
    const scenRows = await conn.query(
      `SELECT id, owner_id FROM \`${t(TABLES.CAP_SCENARIOS)}\` WHERE id = ? FOR UPDATE`,
      [scenarioId],
    );
    if (!scenRows.length) {
      await conn.rollback();
      const e = apiError('Not found', 'NOT_FOUND', 404);
      return res.status(e.status).json(e.body);
    }
    const ownerId = scenRows[0].owner_id;
    // collation-compare, the same question as the id above and for the same
    // reason: `owner_id` folds case, so a JavaScript `===` refuses the genuine
    // owner a scenario every `WHERE owner_id = ?` already calls theirs.
    if (req.user.role !== 'admin' && ownerId !== null
      && !(await sameStoredValue(conn, t(TABLES.CAP_SCENARIOS), 'owner_id', ownerId, req.user.id))) {
      await conn.rollback();
      const e = apiError('Not allowed: you do not own this scenario', 'FORBIDDEN', 403);
      return res.status(e.status).json(e.body);
    }

    const existing = await conn.query(
      `SELECT id FROM \`${t(TABLES.CAP_SETTINGS)}\` WHERE scenario_id = ?`,
      [scenarioId],
    );
    if (existing.length) {
      const sets = cols.map((c) => `\`${c}\` = ?`).join(', ');
      await conn.query(
        `UPDATE \`${t(TABLES.CAP_SETTINGS)}\` SET ${sets} WHERE scenario_id = ?`,
        [...values, scenarioId],
      );
    } else {
      const id = uuidv4();
      const allCols = ['id', 'scenario_id', ...cols];
      const quoted = allCols.map((c) => `\`${c}\``).join(', ');
      const placeholders = allCols.map(() => '?');
      await conn.query(
        `INSERT INTO \`${t(TABLES.CAP_SETTINGS)}\` (${quoted}) VALUES (${placeholders.join(', ')})`,
        [id, scenRows[0].id, ...values],
      );
    }

    const rows = await conn.query(
      `SELECT * FROM \`${t(TABLES.CAP_SETTINGS)}\` WHERE scenario_id = ?`,
      [scenarioId],
    );
    await conn.commit();
    res.json(apiOk(mapRowsFromDb(TABLES.CAP_SETTINGS, rows)[0]));
  } catch (err) {
    if (conn) await conn.rollback();
    logger.error({ err, scenarioId }, 'Failed to update capacity scenario settings');
    dbError(res);
  } finally {
    if (conn) conn.release();
  }
});

module.exports = router;
