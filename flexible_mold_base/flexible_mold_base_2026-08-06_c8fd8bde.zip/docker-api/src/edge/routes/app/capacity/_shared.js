/**
 * capacity/_shared.js — shared maps + helpers for the Capacity Planner module.
 *
 * Route split (spec §7 + config-rewrite §2/§16):
 *   /config/{hardware_specs|disk_combos|teams|vm_profiles|field_defs|settings|rules}
 *       → global catalogue rows (scenario_id IS NULL); write = admin+editor.
 *   /config/bundles (+ items)  → global bundle templates (bundles.js, bespoke).
 *   /scenarios (+ /scenarios/:scenarioId/{children})
 *       → scenario-scoped rows; write = owner+admin via ownerColumn /
 *         parentOwnership; read = all authenticated (spec §7 Q11).
 *
 * REFERENCE MODEL (config-rewrite §2, Model B): creating a scenario copies
 * NOTHING — a scenario REFERENCES the live global catalogues by FK. The old
 * deep-copy-on-create (`TEMPLATE_TABLES` / `deepCopyTemplateRows`) is RETIRED.
 * Version snapshots are the only copy mechanism (a freeze resolves + copies the
 * referenced catalogue closure so a frozen version is immune to later edits,
 * §17.4). Every scenario catalogue FK is write-validated global-or-same-scenario
 * by the §17.1a reference-integrity validator (reference-integrity.js).
 */
const { TABLES } = require('../../../../shared/constants');
const { pool, t } = require('../../../db');
const { uuidv4, apiOk, apiError, requireAdminOrEditor } = require('../../../../shared/helpers');
const { logger } = require('../../../../shared/lib/logger');
const {
  RULE_TYPES, RULE_LEGAL_LEVELS, RULE_LEGAL_GROUP_BYS, DEFAULT_RULE_TEMPLATE,
} = require('../../../../shared/capacity/rule-types');
const { floorGb } = require('../../../../shared/capacity/whole-numbers');
const { canonicalizeDcRefs, dcRefEntries } = require('../../../../shared/capacity/dc-refs');
const { ENTITY_NATIVE_FIELD_KEYS } = require('../../../../shared/capacity/entity-native-field-keys');
const { checkReferences, canonicalKey, messageForMode } = require('./reference-integrity');
const { SITE_REFERENCE_SWEEP } = require('./site-references');
const { sameStoredValue } = require('../schema/write-value');
const {
  enumColumnsFor, columnNullabilityFor, ddlFragmentFor, parseColumnMeta,
  notNullNoDefaultColumnsFor,
} = require('../../../lib/schema-manifest');

/**
 * Express middleware for the nested /scenarios/:scenarioId/* child mounts.
 * Binds the child write/read to the URL's scenario: a write body's scenario_id
 * is forced to the path param (so a client cannot smuggle a row into another
 * scenario), and a GET is scoped to that scenario via the factory's filterable
 * scenario_id column. The generic CRUD factory declares scenario_id in
 * immutableColumns, so a PUT cannot reparent the row across scenarios.
 */
function bindScenarioScope(req, _res, next) {
  const scenarioId = req.params.scenarioId;
  // THE SCOPE IS A PROPERTY OF THE URL, NOT OF THE WRITE, and the two part
  // company on a PUT: the factory strips `scenario_id` from the update body
  // (immutableColumns) precisely so a row cannot be reparented across
  // scenarios, so the in-transaction guards cannot read the scope off the
  // object the statement will write. Nor can they read `req.params.scenarioId`
  // — the factory's own Router does not mergeParams, so it is undefined
  // in there. Recorded here, once, on the request itself.
  req.capacityScenarioId = scenarioId;
  if (req.method === 'GET') {
    req.query = { ...req.query, scenario_id: scenarioId };
  } else {
    req.body = { ...(req.body || {}), scenario_id: scenarioId };
  }
  next();
}

/**
 * The scenario a child write is scoped to, for the in-transaction guards.
 *
 * Deliberately does NOT read `req.body.scenario_id`, even though
 * bindScenarioScope puts it there: a guard that resolves a value from the body
 * is resolving something the statement may not be writing, which is the whole
 * of the family of defects the write core was rebuilt to end. The URL is the
 * authority, and `req.params.scenarioId` is kept as the second reading only for
 * a caller mounted directly on the child router (where params ARE visible).
 */
function scenarioScopeOf(req) {
  if (req.capacityScenarioId != null) return req.capacityScenarioId;
  return req.params ? req.params.scenarioId : undefined;
}

// DoS bounds on a rule write (spec: never-block means the evaluator cannot
// reject at eval time, so the STORED rule is bounded instead). A rule whose
// filters carry thousands of conditions, or a multi-MB JSON blob, would make the
// pure evaluator's per-rule scan cost explode.
const MAX_RULE_CONDITIONS = 50;
const MAX_RULE_JSON_BYTES = 8192;

/**
 * Validate a rule write body against the config-rewrite target model
 * (spec §13.4: level + structural group_by + built-in-attribute filters).
 * Returns `{ code, message }` on rejection (caller responds 400), else null.
 * Bounds the `filters`/`params` JSON size + the filter condition count, and —
 * as defense-in-depth over the DB ENUMs — rejects a `level`/`group_by` outside
 * the type's legal set (rule-types.js; the sentence editor already constrains
 * the UI). Partial-update safe: a column absent from `body` (or `type` absent on
 * a partial PUT) is not checked. Tolerates filters/params as an object OR a
 * pre-serialized JSON string.
 *
 * `opts.strictType`: reject a `type` outside the six keeper types (INVALID_TYPE).
 * It is OPT-IN (defaults off) so a partial PUT that omits `type` is not forced to
 * carry one. Every write path that supplies a `type` passes `strictType: true`:
 * the config/scenario rules mounts AND — since R5 — the import path
 * (io.js buildImportPlan, whose rules-sheet enum is now the six-keeper
 * RULE_TYPES). There is no longer an R1–R4 broken-window exemption.
 */
function validateRuleWritePayload(body, opts = {}) {
  if (!body || typeof body !== 'object') return null;
  const strictType = opts.strictType === true;

  let filtersObj = null;
  for (const key of ['filters', 'params']) {
    const val = body[key];
    if (val === undefined || val === null) continue;
    let serialized = '';
    let parsed = val;
    if (typeof val === 'string') {
      serialized = val;
      try { parsed = JSON.parse(val); } catch { parsed = null; }
    } else {
      try { serialized = JSON.stringify(val); } catch { serialized = ''; }
    }
    if (serialized && Buffer.byteLength(serialized, 'utf8') > MAX_RULE_JSON_BYTES) {
      return { code: 'PAYLOAD_TOO_LARGE', message: `rule ${key} exceeds ${MAX_RULE_JSON_BYTES} bytes` };
    }
    if (key === 'filters') filtersObj = parsed;
  }

  // filters is the AND-list of built-in-attribute conditions (spec §13.4). Bound
  // its length whether it arrives as a bare array or a { conditions: [...] } wrap.
  if (filtersObj != null) {
    const conditions = Array.isArray(filtersObj)
      ? filtersObj
      : (filtersObj && Array.isArray(filtersObj.conditions) ? filtersObj.conditions : null);
    if (conditions && conditions.length > MAX_RULE_CONDITIONS) {
      return { code: 'TOO_MANY_CONDITIONS', message: `rule filters have more than ${MAX_RULE_CONDITIONS} conditions` };
    }
  }

  // Per-type level / group_by (spec §13.4): reject a value outside the type's
  // legal set server-side. When `type` is absent (a partial PUT) neither is
  // checkable against a type.
  //
  // PRESENCE, NOT TRUTHINESS, and the two really did disagree. This guard read
  // `if (body.type)`, so `{"type": ""}` was "no type supplied, nothing to
  // check"; the merged-state guard below reads `hasOwnProperty`, so the same
  // body was "the type was resent, no merge needed". `{"type": "", "level":
  // "vm"}` was therefore judged by NEITHER, and the level edit rode along
  // unchecked into a column whose legal set for the STORED type does not
  // contain it. Both guards ask the same question now, so no body can be absent
  // to one and present to the other.
  if (Object.prototype.hasOwnProperty.call(body, 'type')) {
    // Unknown type (direct write path): an unrecognised type would otherwise skip
    // the level / group_by legality checks entirely (undefined map lookups) and
    // land as a DB ENUM 500 (or silently pass a bad row). Reject it explicitly
    // (spec §13.1). Opt-in so the R5-deferred import path is not force-migrated.
    if (strictType && !RULE_TYPES.includes(body.type)) {
      return { code: 'INVALID_TYPE', message: `rule type '${body.type}' is not a known rule type` };
    }
    const legalLevels = RULE_LEGAL_LEVELS[body.type];
    // An empty string used to be skipped here alongside null, as if it were a
    // way of NOT choosing. It is not: `level` is a NOT NULL ENUM and `''` names
    // no member, so skipping the check only meant the refusal came from the
    // driver as a 500 instead of from here as a 400. `null` keeps its skip
    // because it is a legitimate value on the nullable half of this pair
    // (`group_by`), and the mount's own declared domain refuses it on `level`.
    if (legalLevels && body.level != null && !legalLevels.includes(body.level)) {
      return { code: 'INVALID_LEVEL', message: `level '${body.level}' is not valid for rule type '${body.type}'` };
    }
    const legalGroupBys = RULE_LEGAL_GROUP_BYS[body.type];
    if (legalGroupBys && body.group_by != null && !legalGroupBys.includes(body.group_by)) {
      return { code: 'INVALID_GROUP_BY', message: `group_by '${body.group_by}' is not valid for rule type '${body.type}'` };
    }
  }
  return null;
}

/**
 * Extra guard for the GLOBAL template rules mount (/config/rules): a global
 * template row is the org default — it can be neither an override
 * (`overrides_rule_id` targets a global rule from a SCENARIO, spec §17.1) nor a
 * reference to a custom group (custom groups are scenario-level, spec §11.3).
 * Both are meaningless on a global row, so reject them (400). Returns
 * `{ code, message }` on rejection, else null. The scenario rules mount does NOT
 * call this — there both columns are legitimate.
 */
function validateGlobalRuleWritePayload(body) {
  if (!body || typeof body !== 'object') return null;
  if (body.overrides_rule_id != null) {
    return { code: 'INVALID_GLOBAL_RULE', message: 'a global template rule cannot set overrides_rule_id (overrides are scenario-local)' };
  }
  if (body.custom_group_id != null) {
    return { code: 'INVALID_GLOBAL_RULE', message: 'a global template rule cannot reference a custom group (custom groups are scenario-level)' };
  }
  return null;
}

/** Express pre-middleware wrapper for validateRuleWritePayload (POST/PUT). The
 * scenario rules mount is a direct write path → strict-type checking is on. */
function ruleWriteGuard(req, res, next) {
  if (req.method === 'POST' || req.method === 'PUT') {
    const bad = validateRuleWritePayload(req.body || {}, { strictType: true });
    if (bad) {
      const e = apiError(bad.message, bad.code, 400);
      return res.status(e.status).json(e.body);
    }
  }
  return next();
}

/**
 * PUT-only merged-state validation for cap_rules (Codex finding). The per-type
 * level / group_by legality checks in validateRuleWritePayload only fire when
 * `type` is present in the body — a partial PUT that changes `level` or
 * `group_by` WITHOUT resending `type` (e.g. `{ level: 'vm' }` on a hypervisor-
 * only no-oversell rule) skips them and can persist an illegal target. Mirrors
 * validateFieldDefPutMerge: read the CURRENT row via the caller-supplied
 * `fetchExisting` (scoped by the caller — scenario_id = ? for the scenario mount,
 * scenario_id IS NULL for /config/rules), merge the body over it, and re-run the
 * checks against the TRUE final state. Only touches the DB when a merge could
 * change the outcome (level/group_by touched but type absent); a PUT that resends
 * `type` — already fully checked by validateRuleWritePayload — is a no-op here.
 * Returns `{ code, message }` on rejection, else null.
 */
async function validateRulePutMerge(fetchExisting, body, opts = {}) {
  if (!body || typeof body !== 'object') return null;
  const touches = (k) => Object.prototype.hasOwnProperty.call(body, k);
  if (touches('type') || (!touches('level') && !touches('group_by'))) return null;
  const existing = await fetchExisting();
  if (!existing) return null; // the caller's own not-found guard handles a missing row
  const merged = {
    type: existing.type,
    level: touches('level') ? body.level : existing.level,
    group_by: touches('group_by') ? body.group_by : existing.group_by,
  };
  return validateRuleWritePayload(merged, opts);
}

/**
 * A cap_custom_group_members row must reference EXACTLY ONE concrete member: a VM
 * (member_vm_id) XOR a db_instance (member_instance_id) — spec §11.3 (a custom
 * group's member list is explicit, and a member is one entity). Both set, or
 * neither, is a malformed member row and is rejected 400 (there is no DB-level
 * CHECK backing this — MariaDB's is limited — so the invariant is app-enforced).
 * Returns `{ code, message }` on rejection, else null.
 */
function validateGroupMemberXor(memberVmId, memberInstanceId) {
  const hasVm = memberVmId != null;
  const hasInstance = memberInstanceId != null;
  if (hasVm === hasInstance) {
    return {
      code: 'INVALID_MEMBER',
      message: 'a custom group member must reference exactly one of member_vm_id or member_instance_id',
    };
  }
  return null;
}

/**
 * Express middleware for child mounts that carry a `created_by` audit column
 * (cap_waivers only — cap_versions left the generic mounts for the bespoke
 * versions.js, which stamps created_by itself). SECURITY: the actor is the sole authority on the
 * audit trail — a client-supplied created_by / created_at / updated_at is
 * stripped, and created_by is server-stamped to req.user.id on create. On
 * update the created_by is stripped (never re-attributed to the editor).
 */
function stampAuditColumns(req, _res, next) {
  if ((req.method === 'POST' || req.method === 'PUT') && req.body && typeof req.body === 'object') {
    delete req.body.created_at;
    delete req.body.updated_at;
    if (req.method === 'POST') {
      req.body.created_by = req.user && req.user.id ? req.user.id : null;
    } else {
      delete req.body.created_by;
    }
  }
  next();
}

// Scenario-scoped children: URL path segment → { table, factory opts }.
// parentOwnership walks scenario_id → cap_scenarios.owner_id (spec §7); reads
// stay open (requireAuth in the factory GET). scenario_id is immutable so a PUT
// cannot move a row to another scenario. Owner check on POST reads the injected
// body.scenario_id; on PUT/DELETE it reads the row's own scenario_id.
const SCENARIO_OWNERSHIP = Object.freeze({
  via: 'scenario_id',
  chain: [{ table: TABLES.CAP_SCENARIOS, match: 'id', readOwner: 'owner_id' }],
});

// Scenario-scoped children (config-rewrite §10–12): the placement + database
// entities. The catalogues (hardware_specs / disk_combos / teams / vm_profiles /
// field_defs) are now GLOBAL config (/config/*), not scenario children — a
// scenario REFERENCES them (reference model). cap_sizing_tiers is dropped.
const CHILD_MOUNTS = Object.freeze({
  sites:                { table: TABLES.CAP_SITES,                filterableColumns: ['scenario_id'] },
  hypervisors:          { table: TABLES.CAP_HYPERVISORS,         filterableColumns: ['scenario_id', 'site_id', 'spec_id'] },
  databases:            { table: TABLES.CAP_DATABASES,           filterableColumns: ['scenario_id', 'topology', 'team_id'] },
  vms:                  { table: TABLES.CAP_VMS,                 filterableColumns: ['scenario_id', 'hypervisor_id', 'site_id', 'vm_type', 'database_id'] },
  db_instances:         { table: TABLES.CAP_DB_INSTANCES,        filterableColumns: ['scenario_id', 'vm_id', 'database_id', 'role'] },
  custom_groups:        { table: TABLES.CAP_CUSTOM_GROUPS,       filterableColumns: ['scenario_id', 'team_id'] },
  custom_group_members: { table: TABLES.CAP_CUSTOM_GROUP_MEMBERS, filterableColumns: ['scenario_id', 'group_id'] },
  rules:                { table: TABLES.CAP_RULES,               filterableColumns: ['scenario_id', 'overrides_rule_id'] },
  waivers:              { table: TABLES.CAP_WAIVERS,             filterableColumns: ['scenario_id', 'rule_id'] },
  // cap_versions is NOT a generic child mount — versions.js owns it bespoke
  // (server-computed snapshots only; a client cannot forge one via the generic
  // POST). Its PUT is a two-field whitelist, not the factory's column-driven
  // update: everything about a version except its name and note is frozen.
});

// Reserved field_key values a cap_field_defs row must never carry (Review
// Gate finding): the FE builds a custom field's metadata write via a flat
// `metadata[field_key] = value` bracket-assignment (capacity-grid-adapter.ts
// gridRowToPayload) — for `field_key === '__proto__'` that would invoke
// Object.prototype's legacy `__proto__` accessor (Annex B) instead of
// setting a normal own property. The FE also defends this by building that
// accumulator via Object.create(null); this is the server-authoritative
// reject-at-the-source half of the same fix. `constructor`/`prototype`
// aren't exploitable via a single flat assignment today but are blocked too
// as cheap insurance against a future recursive/path-based merge.
const RESERVED_FIELD_KEYS = new Set(['__proto__', 'constructor', 'prototype']);

// The SAME prototype-accessor names must never appear as an OWN key of a stored
// metadata JSON PAYLOAD (RESERVED_FIELD_KEYS above blocks them as custom-field
// NAMES; this blocks them as data-row metadata keys). Persisting one re-opens
// prototype-pollution risk wherever the blob is later spread onto a normal-prototype
// object. Single source for BOTH the bulk-import path (io.js buildMetadata) and the
// generic child-CRUD / config / wizard metadata-column write guard below.
const RESERVED_META_KEYS = RESERVED_FIELD_KEYS;

/**
 * Reject a metadata write payload (object OR JSON string) carrying a reserved
 * prototype key as an OWN property. Returns { code, message } or null. A null /
 * empty / non-object / unparseable value is passed through (its own validator owns
 * that error) — this guard rejects only a genuine reserved OWN key.
 */
function reservedMetadataKeyError(metadata) {
  if (metadata == null) return null;
  let obj = metadata;
  if (typeof obj === 'string') {
    if (obj.trim() === '') return null;
    try { obj = JSON.parse(obj); } catch { return null; }
  }
  if (!obj || typeof obj !== 'object' || Array.isArray(obj)) return null;
  for (const k of Object.keys(obj)) {
    if (RESERVED_META_KEYS.has(k)) {
      return { code: 'RESERVED_FIELD_KEY', message: `metadata key "${k}" is reserved` };
    }
  }
  return null;
}

/**
 * POST/PUT pre-middleware rejecting a body.metadata payload with a reserved
 * prototype OWN key (400). Applied to every metadata-bearing child-CRUD write mount
 * so the reject-at-the-source invariant holds on the raw API too, not just bulk
 * import. No-op when the body carries no metadata.
 */
function rejectReservedMetadataKeys(req, res, next) {
  if (req.method !== 'POST' && req.method !== 'PUT') return next();
  const body = req.body || {};
  if (!Object.prototype.hasOwnProperty.call(body, 'metadata')) return next();
  const bad = reservedMetadataKeyError(body.metadata);
  if (bad) {
    const e = apiError(bad.message, bad.code, 400);
    return res.status(e.status).json(e.body);
  }
  return next();
}

// Must match the FE's NULL_SENTINEL (src/fmb/capacity/lib/capacity-grid-adapter.ts)
// — the string a nullable <select> uses to represent "no value chosen".
const NULL_SENTINEL = '__unset__';

/** Shared scan for `optionsRaw` (object OR pre-serialized JSON string)
 *  containing the NULL_SENTINEL value, either as a bare string option or a
 *  `{ label, value }` option object. Returns true iff found. Malformed JSON
 *  parses to `null` and is tolerated (not this function's concern). */
function optionsContainSentinel(optionsRaw) {
  let options = optionsRaw;
  if (typeof options === 'string') {
    try { options = JSON.parse(options); } catch { options = null; }
  }
  if (!Array.isArray(options)) return false;
  return options.some((opt) => (
    (typeof opt === 'string' ? opt : (opt && typeof opt === 'object' ? opt.value : undefined)) === NULL_SENTINEL
  ));
}

/**
 * Validates a cap_field_defs write body (shared by the global config/
 * field_defs mount and the scenario-scoped scenarios/:id/fields mount).
 * Returns an error message, or null if the body is fine. Partial-update
 * safe: a column absent from `body` (a PUT that doesn't touch it) is not
 * checked — matches every other column-presence gate in this module. (The
 * data_type/options CROSS-request partial-update case — a PUT touching only
 * ONE of the two columns, relying on the row's already-stored value for the
 * other — is NOT this function's job; see validateFieldDefPutMerge below,
 * which reads the existing row and re-runs the SAME sentinel check below
 * against the merged final state.)
 */
function validateFieldDefWrite(body) {
  if (!body || typeof body !== 'object') return null;
  if (typeof body.field_key === 'string' && RESERVED_FIELD_KEYS.has(body.field_key)) {
    return `field_key "${body.field_key}" is reserved`;
  }
  // cap_scenarios has no `metadata` column (table-ddls.js) — a custom field
  // targeting entity_type 'scenario' would have nowhere to write its value.
  if (body.entity_type === 'scenario') {
    return 'entity_type "scenario" cannot carry custom fields (no metadata column)';
  }
  if (typeof body.entity_type === 'string' && typeof body.field_key === 'string') {
    const nativeKeys = ENTITY_NATIVE_FIELD_KEYS[body.entity_type];
    if (nativeKeys && nativeKeys.includes(body.field_key)) {
      return `field_key "${body.field_key}" conflicts with a native ${body.entity_type} column`;
    }
  }
  if (body.data_type === 'enum' && Object.prototype.hasOwnProperty.call(body, 'options')) {
    if (optionsContainSentinel(body.options)) return `enum option value "${NULL_SENTINEL}" is reserved`;
  }
  return null;
}

/**
 * Uniqueness guard for `(scenario_id, entity_type, field_key)` (Review Gate
 * finding, Codex r2): two cap_field_defs rows for the SAME entity_type with
 * the SAME field_key in the SAME scope (the global template, or the SAME
 * scenario) would both own the identical `metadata` JSON key — whichever
 * save lands second silently wins and the other definition's data becomes
 * unreachable. A DB-level UNIQUE (scenario_id, entity_type, field_key) backs
 * this (table-ddls.js); this app-layer check is the primary enforcer and — for
 * the global-only rows whose NULL scenario_id the UNIQUE index cannot police
 * (MariaDB treats each NULL as distinct) — the ONLY one. `fetchDuplicate` is
 * caller-supplied so config.js (scenario_id IS NULL scope) and children.js
 * (scenario_id = ? scope, excluding the row's own id on a PUT) can each
 * probe with their own predicate. Returns an error message, or null. A
 * missing/non-string `entityType`/`fieldKey` is not this function's concern
 * (the NOT NULL DDL constraint is the backstop for a malformed create).
 */
async function rejectIfFieldDefDuplicate(fetchDuplicate, entityType, fieldKey) {
  if (typeof entityType !== 'string' || typeof fieldKey !== 'string') return null;
  const duplicate = await fetchDuplicate(entityType, fieldKey);
  if (duplicate) return `a field_key "${fieldKey}" already exists for entity_type "${entityType}"`;
  return null;
}

/**
 * PUT-only partial-update gap fix (Review Gate finding, Codex r1 + r2):
 * validateFieldDefWrite's checks above only fire when the RELEVANT columns
 * are present in the SAME request body —
 *   - the enum/options sentinel check needs BOTH `data_type` and `options`;
 *   - the native-column key-collision check needs BOTH `entity_type` and
 *     `field_key`.
 * A PUT touching only ONE column of either pair (relying on the row's
 * already-stored value for the other) sails straight through both checks
 * unchecked. This reads the CURRENT row (via the caller-supplied
 * `fetchExisting`, so config.js and children.js can each use their own scope
 * predicate) only when exactly ONE column of a pair is touched, merges it
 * onto `body`, and re-runs the SAME checks against that TRUE final state.
 * It also re-runs the (scenario_id, entity_type, field_key) uniqueness
 * guard whenever `entity_type` OR `field_key` is touched (the key tuple
 * could have changed even if only one half moved) via the caller-supplied
 * `fetchDuplicate` (see rejectIfFieldDefDuplicate). Returns an error
 * message, or null. `fetchExisting`/`fetchDuplicate` are only invoked when
 * actually needed — a PUT touching neither pair's columns is a pure no-op
 * here (no DB round trip).
 */
async function validateFieldDefPutMerge(fetchExisting, fetchDuplicate, body) {
  if (!body || typeof body !== 'object') return null;
  const touches = (key) => Object.prototype.hasOwnProperty.call(body, key);
  const touchesEntityType = touches('entity_type');
  const touchesFieldKey = touches('field_key');
  const touchesDataType = touches('data_type');
  const touchesOptions = touches('options');
  const needsKeyMerge = touchesEntityType !== touchesFieldKey; // exactly one of the pair touched
  const needsSentinelMerge = touchesDataType !== touchesOptions; // exactly one of the pair touched
  const needsUniqueCheck = touchesEntityType || touchesFieldKey; // the key tuple could have moved
  if (!needsKeyMerge && !needsSentinelMerge && !needsUniqueCheck) return null;

  const existing = await fetchExisting();
  if (!existing) return null; // row not found — the caller's own not-found guard handles this

  const mergedEntityType = touchesEntityType ? body.entity_type : existing.entity_type;
  const mergedFieldKey = touchesFieldKey ? body.field_key : existing.field_key;

  if (needsKeyMerge) {
    const nativeKeys = ENTITY_NATIVE_FIELD_KEYS[mergedEntityType];
    if (nativeKeys && typeof mergedFieldKey === 'string' && nativeKeys.includes(mergedFieldKey)) {
      return `field_key "${mergedFieldKey}" conflicts with a native ${mergedEntityType} column`;
    }
  }
  if (needsSentinelMerge) {
    const mergedDataType = touchesDataType ? body.data_type : existing.data_type;
    const mergedOptions = touchesOptions ? body.options : existing.options;
    if (mergedDataType === 'enum' && optionsContainSentinel(mergedOptions)) {
      return `enum option value "${NULL_SENTINEL}" is reserved`;
    }
  }
  if (needsUniqueCheck) {
    const dupErr = await rejectIfFieldDefDuplicate(fetchDuplicate, mergedEntityType, mergedFieldKey);
    if (dupErr) return dupErr;
  }
  return null;
}

/**
 * The first ENUM column of `table` whose value in `body` is outside the
 * column's DECLARED domain, as an error message — or null when every named
 * enumerated column carries a member.
 *
 * WHY THE BESPOKE MOUNTS NEED THEIR OWN COPY OF THE FACTORY'S GATE. The
 * `/config` handlers build their own INSERT/UPDATE, so `createCrudRoutes`'
 * `enumColumns` never runs for them — and the guards they DO run are JavaScript
 * identity lookups on the raw body: `body.entity_type === 'scenario'`,
 * `ENTITY_NATIVE_FIELD_KEYS[body.entity_type]`, `body.data_type === 'enum'`.
 * The column those values land in folds case and reads an INTEGER as a 1-BASED
 * MEMBER INDEX, so `'Scenario'` and `1` are both the one value the first of
 * those guards exists to refuse, and `'Vm'` makes the second look up
 * `undefined` and SKIP the collision check entirely rather than fail it. The
 * uniqueness probe opts out of a non-string for the same reason and the UNIQUE
 * index cannot cover global rows, so nothing was left judging it.
 *
 * The answer is not to teach each of those three to fold — that is a fourth
 * opinion about what the column means. It is to refuse a value the column would
 * fold BEFORE any of them compares, so every guard downstream is looking at the
 * value the row will hold.
 *
 * DOMAINS AND NULLABILITY BOTH COME FROM THE DDL, for the reason the factory's
 * own gate gives: they are questions the schema already answers, and a
 * hand-kept answer beside it goes wrong in silence the first time a column
 * moves. A null is a VALUE here, not an absence — it names the column and asks
 * for NULL — so it is refused exactly where the column is NOT NULL and accepted
 * where it is nullable.
 *
 * Present-only: a column the body does not name is not judged, matching every
 * other column-presence gate in this module.
 *
 * @param {string} table  base table name (a `TABLES.*` value)
 * @param {object} body   the raw write body
 * @returns {string|null}
 */
function enumDomainViolation(table, body) {
  if (!body || typeof body !== 'object') return null;
  const domains = enumColumnsFor(table);
  if (!domains) return null;
  for (const [column, members] of Object.entries(domains)) {
    if (!Object.prototype.hasOwnProperty.call(body, column)) continue;
    const value = body[column];
    if (value === undefined) continue;
    const shown = members.join(', ');
    if (value === null) {
      if (columnNullabilityFor(table, column) !== 'NO') continue;
      return `${column} may not be null; it must be one of: ${shown}`;
    }
    // Identity, not the database's equality: a value that merely FOLDS to a
    // member is exactly the one the guards downstream cannot judge.
    if (!members.includes(value)) return `${column} must be one of: ${shown}`;
  }
  return null;
}

/**
 * The first NOT-NULL-no-default column of `table` that a CREATE must name and
 * this one does not, as an error message — or null when every such column is
 * present.
 *
 * WHY OMISSION IS NOT ABSENCE, AND WHY THIS IS NOT ENUM-ONLY. Measured under
 * the deployed strict `sql_mode` (db-enum-omission-1500.md): an INSERT that
 * omits a NOT NULL ENUM column with no declared DEFAULT stores the FIRST
 * DECLARED MEMBER, silently, with no error and no warning — corruption, not
 * an availability problem. A NOT NULL VARCHAR/CHAR/etc. column with no default
 * fails LOUDLY instead (a bare constraint violation the database raises on its
 * own), but that failure reaches the caller as a generic 500 naming no column
 * at all — the same "the caller did not say" gap, just a different symptom
 * (fmb-1549: `hypervisors` without `spec_id`, `databases` without
 * `function_name`, both mapped to 500 while `topology`'s ENUM omission alone
 * answered a clean 400). A hand-picked list of "the columns that also need
 * this" reproduces exactly the defect it would be fixing — the fix is to stop
 * filtering by type at all.
 *
 * The column set is the DDL's answer: every column the table declares NOT
 * NULL with nothing the engine can supply, of any type. `notNullNoDefaultColumnsFor`
 * answering null (a table the DDL does not describe) requires nothing, because
 * a caller cannot be held to a schema this process cannot read.
 *
 * AN EXPLICIT `null` IS TREATED IDENTICALLY TO ABSENCE (D5 review finding 2).
 * `presentColumns` (a key set — `Object.keys(req.body)`, `collectWrite`'s
 * `hasOwnProperty`) cannot tell "the caller supplied a value" from "the caller
 * named the column and asked for NULL" — `{ spec_id: null }` has `spec_id` in
 * its key set, so key-presence alone let it through to the database's own NOT
 * NULL constraint (an unmapped 500), reproducing this same gap for every
 * required column with `null` spelled out instead of omitted. `body` is the
 * one extra thing this needs to tell the two apart; `''` and `0` are VALUES,
 * not this rule's concern — only an explicit `null` reads as nothing. A NOT
 * NULL ENUM's explicit `null` is refused earlier by `enumDomainViolation` /
 * the factory's own `enumViolation` with a value-shaped message of its own;
 * this rule still judges it too (so a caller relying on this function alone
 * is still covered), and the two can never disagree because both refuse.
 *
 * @param {string} table base table name (a `TABLES.*` value)
 * @param {string[]} presentColumns the columns the statement will name
 * @param {object} [body] the raw write body — needed only to tell an explicit
 *   `null` apart from a genuinely supplied value; omitted, this behaves
 *   exactly as key-presence-only did before.
 * @returns {string|null}
 */
function missingRequiredColumnOnCreate(table, presentColumns, body) {
  const required = notNullNoDefaultColumnsFor(table);
  if (!required) return null;
  const domains = enumColumnsFor(table) || {};
  const present = new Set(presentColumns || []);
  const hasBody = body != null && typeof body === 'object';
  for (const column of required) {
    if (present.has(column) && !(hasBody && body[column] === null)) continue;
    const members = domains[column];
    return members
      ? `${column} is required; it must be one of: ${members.join(', ')}`
      : `${column} is required`;
  }
  return null;
}

/**
 * Lightweight per-column type guard for the two BESPOKE (non-createCrudRoutes)
 * capacity write handlers — config.js's CONFIG_MOUNTS loop and settings.js's
 * singleton PUT. (The generic createCrudRoutes factory children.js uses has
 * its own additive-column/enumColumns gates; these two don't get that for
 * free since they hand-roll their INSERT/UPDATE.) Present-only (a partial PUT
 * omitting a column is unaffected). Returns the first offending column's
 * error message, or null.
 *
 * Each `typeSpec` entry is either a bare kind string (shorthand for
 * `{ kind, nullable: false }`) or `{ kind, nullable }`. `undefined` (the
 * column key absent from the body — a partial PUT that doesn't touch it) is
 * ALWAYS skipped regardless of `nullable`. An explicit `null` is only
 * accepted for a column marked `nullable: true` (Review Gate finding, Codex
 * r2: the old code unconditionally skipped `null` for every column here,
 * including several genuinely `NOT NULL` DB columns — e.g. cap_settings.
 * mem_cpu_ratio — so `{ mem_cpu_ratio: null }` sailed through this guard and
 * hit the DB as a 500 constraint violation instead of a clean 400).
 * `nullable` is derived from each table's own DDL (table-ddls.js); the
 * per-mount `types` maps below annotate every genuinely nullable column.
 *   'number'    — typeof === 'number' (and finite; NaN/Infinity rejected)
 *   'boolean'   — typeof === 'boolean'
 *   'json'      — typeof === 'object' (object OR array; excludes primitives
 *                 and pre-stringified JSON text — this app's own FE always
 *                 sends the parsed value, never a JSON string)
 *   'jsonObject'— typeof === 'object' AND NOT an array (cap_settings.layer_defaults)
 */
function validateColumnTypes(body, typeSpec) {
  if (!body || typeof body !== 'object') return null;
  for (const [col, spec] of Object.entries(typeSpec)) {
    if (!Object.prototype.hasOwnProperty.call(body, col)) continue;
    const kind = typeof spec === 'string' ? spec : spec.kind;
    const nullable = typeof spec === 'string' ? false : !!spec.nullable;
    const v = body[col];
    if (v === undefined) continue;
    if (v === null) {
      if (nullable) continue;
      return `${col} must not be null`;
    }
    if (kind === 'number' && (typeof v !== 'number' || !Number.isFinite(v))) return `${col} must be a number`;
    // Whole-number columns (fmb-1433): SGA and a custom-mode profile's hand-set
    // MEM are integers only. Refused, never silently floored — the caller sees
    // the value it sent rejected rather than a different number persisted.
    if (kind === 'number' && spec.integer && !Number.isInteger(v)) return `${col} must be a whole number`;
    if (kind === 'boolean' && typeof v !== 'boolean') return `${col} must be a boolean`;
    if (kind === 'json' && typeof v !== 'object') return `${col} must be an object or array`;
    if (kind === 'jsonObject' && (typeof v !== 'object' || Array.isArray(v))) return `${col} must be an object`;
  }
  return null;
}

// Per-scenario settings singleton write columns + types — shared with
// settings.js so both bespoke cap_settings write paths (global template row
// here, scenario copy there) apply the identical type guard. Every column
// here is `NOT NULL` in cap_settings' own DDL EXCEPT `layer_defaults` (a
// plain nullable JSON column) — see table-ddls.js.
const SETTINGS_COLUMN_TYPES = Object.freeze({
  mem_cpu_ratio: 'number',
  sga_factor: 'number',
  sga_divisor: 'number',
  sga_subtract: 'number',
  // Operator-editable global standby-SGA fallback (phase-2 spec §6.1, Q1). NOT
  // NULL DEFAULT 32 in cap_settings' DDL. Only the GLOBAL config settings route
  // (config.js CONFIG_MOUNTS) writes it; the scenario settings.js WRITABLE_COLUMNS
  // deliberately omits it, so a scenario override cannot rewrite this global.
  // Whole numbers only (fmb-1433): this is an SGA size the operator types, and a
  // surface must not accept a value it will not honour — `deriveInstanceSga`
  // floors it, so 32.5 would silently behave as 32. The four constants above are
  // ratios/factors and stay free to carry decimals; the rule is about the RESULT.
  standby_sga_default_gb: { kind: 'number', integer: true },
  util_amber_pct: 'number',
  util_red_pct: 'number',
  overcommit_default_enabled: 'boolean',
  layer_defaults: { kind: 'jsonObject', nullable: true },
});

// Whole-body settings write guard (config.js validateGroupWrite): the standby
// SGA default is a GB size, so a negative value is rejected 400 rather than
// stored (the type guard above only checks it is a finite number). Present-only —
// a partial PUT that omits it is unaffected. Returns an error message or null.
function validateSettingsWrite(body) {
  if (!body || typeof body !== 'object') return null;
  if (Object.prototype.hasOwnProperty.call(body, 'standby_sga_default_gb')) {
    const v = body.standby_sga_default_gb;
    if (typeof v === 'number' && Number.isFinite(v) && v < 0) {
      return 'standby_sga_default_gb must not be negative';
    }
  }
  return null;
}

// Config (template) tables: URL segment → { table, cols, json }. Only these
// columns are writable through the /config route; scenario_id is forced NULL by
// the handler and is intentionally NOT in `cols` (a client cannot set it).
// `types` (optional) is checked by config.js before every INSERT/UPDATE —
// see validateColumnTypes above. `validate` (optional) is an extra whole-body
// check (field_defs' reserved-key / NULL_SENTINEL rules, which span two
// columns and can't be expressed as a single-column type).
// `references` (optional) declares catalogue-FK columns validated by the §17.1a
// reference-integrity helper (mode 'global' on a /config write — a global row
// may only reference another global row). config.js runs these before INSERT.
const CONFIG_MOUNTS = Object.freeze({
  hardware_specs: {
    table: TABLES.CAP_HARDWARE_SPECS,
    cols: ['name', 'cpu_total', 'mem_total_gb', 'disk_total_gb',
      'cpu_reserved', 'mem_reserved_pct', 'disk_reserved_gb', 'metadata'],
    json: ['metadata'],
    // Raw totals + reserved are NOT NULL (DEFAULT 0); metadata is nullable JSON.
    types: {
      cpu_total: 'number', mem_total_gb: 'number', disk_total_gb: 'number',
      cpu_reserved: 'number', mem_reserved_pct: 'number', disk_reserved_gb: 'number',
      metadata: { kind: 'json', nullable: true },
    },
  },
  disk_combos: {
    table: TABLES.CAP_DISK_COMBOS,
    cols: ['name', 'sizes'],
    json: ['sizes'],
    // sizes is a plain nullable JSON list column.
    types: { sizes: { kind: 'json', nullable: true } },
  },
  teams: {
    table: TABLES.CAP_TEAMS,
    cols: ['name', 'color'],
    json: [],
  },
  vm_profiles: {
    table: TABLES.CAP_VM_PROFILES,
    cols: ['class', 'name', 'mode', 'cpu', 'mem_gb', 'sga_cap_gb', 'allowed_disk_combos', 'metadata'],
    json: ['allowed_disk_combos', 'metadata'],
    // cap_vm_profiles (merged entity, §3): cpu is NOT NULL (DEFAULT 0); mem_gb /
    // sga_cap_gb are nullable (derived at read time in formula mode); the two
    // JSON columns are nullable.
    types: {
      cpu: 'number',
      // Whole numbers only (fmb-1433): both are hand-set in custom mode and
      // NULL in formula mode (derived at read time).
      mem_gb: { kind: 'number', nullable: true, integer: true },
      sga_cap_gb: { kind: 'number', nullable: true, integer: true },
      allowed_disk_combos: { kind: 'json', nullable: true },
      metadata: { kind: 'json', nullable: true },
    },
  },
  field_defs: {
    table: TABLES.CAP_FIELD_DEFS,
    cols: ['entity_type', 'field_key', 'label', 'data_type', 'required', 'default_value', 'options'],
    json: ['options'],
    // cap_field_defs (§8): required is NOT NULL (DEFAULT FALSE); default_value
    // and options are plain nullable columns.
    types: {
      required: 'boolean',
      options: { kind: 'json', nullable: true },
    },
    validate: validateFieldDefWrite,
  },
  settings: {
    table: TABLES.CAP_SETTINGS,
    cols: ['mem_cpu_ratio', 'sga_factor', 'sga_divisor', 'sga_subtract', 'standby_sga_default_gb',
      'util_amber_pct', 'util_red_pct', 'overcommit_default_enabled', 'layer_defaults'],
    json: ['layer_defaults'],
    types: SETTINGS_COLUMN_TYPES,
    validate: validateSettingsWrite,
    // At most one global-default settings row (scenario_id IS NULL). A second
    // POST is rejected 409 — the caller PUTs the existing row instead. The row
    // is seeded at schema creation (spec §9.2) so the "never configured" state
    // ceases to exist.
    singleton: true,
  },
  rules: {
    table: TABLES.CAP_RULES,
    cols: ['type', 'name', 'level', 'group_by', 'custom_group_id', 'filters', 'params', 'severity', 'enabled'],
    json: ['filters', 'params'],
    // cap_rules (config-rewrite §13.4): filters/params are plain nullable JSON.
    types: { filters: { kind: 'json', nullable: true }, params: { kind: 'json', nullable: true } },
  },
});

// Config-layer catalogue delete guard (config-rewrite obligation 3 — the
// delete-side analog of the §17.1a write validator). A GLOBAL catalogue row must
// not be deleted while any LIVE row references it, else the referencing FK
// dangles. Frozen version snapshots do NOT block: a snapshot lives as JSON inside
// cap_versions.snapshot (it carries its own resolved copy of the closure, §2.1),
// not as a live row, so a plain row probe never sees it. Both live SCENARIO rows
// AND global bundle items count — a bundle item is global config that references
// a global catalogue (§17.1a mode 'global'); deleting its referent would dangle.
// This same map drives the scenario-LOCAL catalogue delete (a local row can only
// be referenced same-scenario, so the un-scoped probe is still correct there).
const CONFIG_DELETE_GUARDS = Object.freeze({
  hardware_specs: {
    label: 'hardware spec',
    refs: [{ table: TABLES.CAP_HYPERVISORS, column: 'spec_id', by: 'a hypervisor' }],
  },
  vm_profiles: {
    label: 'VM profile',
    refs: [
      { table: TABLES.CAP_VMS, column: 'sizing_profile_id', by: 'a VM' },
      { table: TABLES.CAP_DATABASES, column: 'profile_id', by: 'a database' },
      { table: TABLES.CAP_BUNDLE_ITEMS, column: 'profile_id', by: 'a bundle item' },
    ],
  },
  disk_combos: {
    label: 'disk combo',
    refs: [
      { table: TABLES.CAP_VMS, column: 'disk_combo_id', by: 'a VM' },
      { table: TABLES.CAP_DATABASES, column: 'disk_combo_id', by: 'a database' },
      { table: TABLES.CAP_BUNDLE_ITEMS, column: 'disk_combo_id', by: 'a bundle item' },
    ],
    // A combo id also appears inside cap_vm_profiles.allowed_disk_combos, a
    // JSON list of the combos a profile permits. This used to be written off as
    // a "soft reference, intentionally not a delete blocker" — but two other
    // subsystems treat it as a hard one: the version/export closure pulls a
    // combo referenced ONLY from an allow-list so the document can be
    // remapped, and the importer raises UNRESOLVED_REF when it cannot find it.
    // So deleting such a combo breaks nothing today and makes the scenario
    // permanently un-re-importable, which is the worst of the three positions.
    // The other two are right: it is a reference.
    //
    // Scrubbing the id out of the allow-lists instead is NOT an option and the
    // reason is a product rule, not a preference: an empty allow-list means "no
    // restriction", so removing the last id would silently widen a profile from
    // "only these combos" to "any combo".
    jsonListRefs: [
      { table: TABLES.CAP_VM_PROFILES, column: 'allowed_disk_combos', by: 'a VM profile allow-list' },
    ],
  },
  teams: {
    label: 'team',
    refs: [
      { table: TABLES.CAP_VMS, column: 'team_id', by: 'a VM' },
      { table: TABLES.CAP_DATABASES, column: 'team_id', by: 'a database' },
      { table: TABLES.CAP_CUSTOM_GROUPS, column: 'team_id', by: 'a custom group' },
      { table: TABLES.CAP_BUNDLE_ITEMS, column: 'team_id', by: 'a bundle item' },
    ],
  },
  // A GLOBAL template rule must not be deleted while a scenario override row
  // (overrides_rule_id) or an Exception (waivers.rule_id) still points at it —
  // deleting it would leave the override orphaned (silently dropped at eval) and
  // the Exception dangling (candidates 514 #3). The same un-scoped probe is
  // correct: an override / Exception from ANY scenario blocks the global delete.
  rules: {
    label: 'rule',
    refs: [
      { table: TABLES.CAP_RULES, column: 'overrides_rule_id', by: 'a scenario override' },
      { table: TABLES.CAP_WAIVERS, column: 'rule_id', by: 'an Exception' },
    ],
  },
});

// Probe each referencing (table, column) for a live row pointing at catalogue row
// `id`. Returns the first blocker's human phrase (e.g. 'a VM'), or null when the
// row is unreferenced. `dbHandle` must be a rw connection so a just-committed
// reference is visible. The probe is deliberately NOT scenario-scoped: a
// reference from ANY live scenario blocks a GLOBAL delete; a scenario-LOCAL row
// can only be referenced by its own scenario, so the same probe is correct there.
async function findCatalogueReferenceBlocker(dbHandle, group, id) {
  const guard = CONFIG_DELETE_GUARDS[group];
  if (!guard) return null;
  for (const ref of guard.refs) {
    const rows = await dbHandle.query(
      `SELECT 1 AS ref FROM \`${t(ref.table)}\` WHERE \`${ref.column}\` = ? LIMIT 1`, [id],
    );
    if (rows.length) return ref.by;
  }
  for (const ref of guard.jsonListRefs || []) {
    // byte-compare: an id inside a JSON list is resolved by exact string lookup
    // by everything that reads it — the closure builder's `idMap.get(String(id))`
    // and the importer's own resolution — so this probe has to ask the same
    // question they do. A folding comparison here would report a reference the
    // remap will not find, which is the opposite error and just as silent.
    //
    // JSON_VALID guards the probe rather than the data: the column is declared
    // JSON but a row written before that (or by an operator) can hold text the
    // JSON functions raise on, and a DELETE that 500s on a malformed row
    // elsewhere in the table is a worse answer than the refusal this is
    // computing.
    const rows = await dbHandle.query(
      `SELECT 1 AS ref FROM \`${t(ref.table)}\`
        WHERE \`${ref.column}\` IS NOT NULL
          AND JSON_VALID(\`${ref.column}\`)
          AND JSON_CONTAINS(\`${ref.column}\`, JSON_QUOTE(?))
        LIMIT 1`,
      [String(id)],
    );
    if (rows.length) return ref.by;
  }
  return null;
}

// Scenario-LOCAL catalogue additions (spec §2.4): a scenario may add its OWN
// hardware_specs / vm_profiles / disk_combos / teams (a row with scenario_id set
// to the scenario, flagged local). Custom field defs are GLOBAL-ONLY (§8) and are
// deliberately absent. These reuse the same tables + CONFIG_MOUNTS type defs as
// /config; the ONLY difference is scope — a local write forces scenario_id = the
// URL param (owner+admin), where /config forces scenario_id IS NULL (admin+editor).
// None of the four carry a scalar catalogue FK, so no §17.1a FK validator is wired
// here (vm_profiles.allowed_disk_combos is a soft JSON allow-list, unvalidated on
// the global /config path too — parity preserved).
const LOCAL_CATALOGUE_MOUNTS = Object.freeze({
  hardware_specs: { table: TABLES.CAP_HARDWARE_SPECS, filterableColumns: ['scenario_id'] },
  vm_profiles:    { table: TABLES.CAP_VM_PROFILES,    filterableColumns: ['scenario_id', 'class', 'mode'] },
  disk_combos:    { table: TABLES.CAP_DISK_COMBOS,    filterableColumns: ['scenario_id'] },
  teams:          { table: TABLES.CAP_TEAMS,          filterableColumns: ['scenario_id'] },
});

// Bundle (global config template, spec §7) writable column sets. cap_bundles is a
// pure header (serial + name); cap_bundle_items carries the per-row template.
// prefill_custom_group is a NAME string (a wizard-time pre-fill hint), NOT an FK —
// custom groups are scenario-level, so a global bundle item cannot hold a custom
// group id; it stamps a group of that name into the scenario at pick time (§7.2).
const BUNDLE_COLUMNS = Object.freeze(['serial', 'name']);
const BUNDLE_ITEM_COLUMNS = Object.freeze([
  'order_index', 'type', 'qty', 'profile_id', 'function_name', 'topology',
  'node_count', 'disk_combo_id', 'team_id',
  // Phase-2 A4: bundle-item SGA defaults a stamp carries into the wizard's SGA
  // fields (spec §3.3 A4 / §6.1). DB items only; nullable (null = inherit the
  // derive chain) — validated in bundles.js validateItemBody.
  'primary_sga_gb', 'standby_sga_gb',
  'prefill_custom_group',
]);
// §17.1a mode 'global': a global bundle item's catalogue FKs may reference GLOBAL
// rows only (a bundle cannot point at any scenario-local row).
const BUNDLE_ITEM_FK_SPECS = Object.freeze([
  { column: 'profile_id', table: TABLES.CAP_VM_PROFILES, mode: 'global' },
  { column: 'disk_combo_id', table: TABLES.CAP_DISK_COMBOS, mode: 'global' },
  { column: 'team_id', table: TABLES.CAP_TEAMS, mode: 'global' },
]);
const BUNDLE_ITEM_TYPES = Object.freeze(['DB', 'AP']);
const BUNDLE_ITEM_TOPOLOGIES = Object.freeze(['single', 'primary', 'primary_standby', 'rac']);

// Every table a scenario delete must clear (WHERE scenario_id = ?), leaf-first.
// cap_scenarios itself is NOT here — the caller deletes it last. The catalogue
// tables appear so a scenario's LOCAL rows (scenario-local additions, §2.2) are
// removed; a delete only touches WHERE scenario_id = the scenario, never the
// global scenario_id IS NULL catalogue rows. cap_field_defs is global-only (no
// scenario rows) but is included for symmetry (deletes nothing). cap_bundles /
// cap_bundle_items are pure global config (no scenario_id) and never appear.
const SCENARIO_SCOPED_TABLES = Object.freeze([
  TABLES.CAP_WAIVERS,
  TABLES.CAP_CUSTOM_GROUP_MEMBERS,
  TABLES.CAP_CUSTOM_GROUPS,
  TABLES.CAP_DB_INSTANCES,
  TABLES.CAP_VMS,
  TABLES.CAP_DATABASES,
  TABLES.CAP_HYPERVISORS,
  TABLES.CAP_SITES,
  TABLES.CAP_VERSIONS,
  TABLES.CAP_RULES,
  TABLES.CAP_VM_PROFILES,
  TABLES.CAP_DISK_COMBOS,
  TABLES.CAP_TEAMS,
  TABLES.CAP_HARDWARE_SPECS,
  TABLES.CAP_FIELD_DEFS,
  TABLES.CAP_SETTINGS,
]);

// Display (name) column per primary scenario entity surfaced in a delete-impact
// preview's affected-name list. cap_databases' display identity is
// `function_name`, NOT `name` — a hard-coded `name` here would be an unknown
// column at runtime and 500 the whole (fail-closed) preview. A schema-parity
// test validates every column named here against the DDL (no live DB needed).
const SCENARIO_ENTITY_DISPLAY = Object.freeze([
  { kind: 'site', table: TABLES.CAP_SITES, nameCol: 'name' },
  { kind: 'hypervisor', table: TABLES.CAP_HYPERVISORS, nameCol: 'name' },
  { kind: 'vm', table: TABLES.CAP_VMS, nameCol: 'name' },
  { kind: 'database', table: TABLES.CAP_DATABASES, nameCol: 'function_name' },
]);

// Cross-entity reference checks per child segment, validated by the §17.1a
// reference-integrity helper (reference-integrity.js). Per spec §17.1a:
//   mode 'scenario'  → a scenario-internal placement ref (must be same-scenario).
//   mode 'catalogue' → a catalogue ref (GLOBAL or same-scenario-local).
//   requireVmType    → the referenced VM must be of this vm_type (db_instances
//                      may only hang off a db_host VM). A null value skips.
const CHILD_FK_VALIDATIONS = Object.freeze({
  hypervisors: [
    { column: 'site_id', table: TABLES.CAP_SITES, mode: 'scenario' },
    { column: 'spec_id', table: TABLES.CAP_HARDWARE_SPECS, mode: 'catalogue' },
  ],
  databases: [
    { column: 'profile_id', table: TABLES.CAP_VM_PROFILES, mode: 'catalogue' },
    { column: 'disk_combo_id', table: TABLES.CAP_DISK_COMBOS, mode: 'catalogue' },
    { column: 'team_id', table: TABLES.CAP_TEAMS, mode: 'catalogue' },
  ],
  vms: [
    { column: 'hypervisor_id', table: TABLES.CAP_HYPERVISORS, mode: 'scenario' },
    { column: 'site_id', table: TABLES.CAP_SITES, mode: 'scenario' },
    { column: 'sizing_profile_id', table: TABLES.CAP_VM_PROFILES, mode: 'catalogue' },
    { column: 'disk_combo_id', table: TABLES.CAP_DISK_COMBOS, mode: 'catalogue' },
    { column: 'team_id', table: TABLES.CAP_TEAMS, mode: 'catalogue' },
    { column: 'database_id', table: TABLES.CAP_DATABASES, mode: 'scenario' },
  ],
  db_instances: [
    { column: 'vm_id', table: TABLES.CAP_VMS, mode: 'scenario', requireVmType: 'db_host' },
    { column: 'database_id', table: TABLES.CAP_DATABASES, mode: 'scenario' },
  ],
  // A scenario rule row (config-rewrite §13.4 / §17.1): a custom_group_id must
  // reference a custom group in THIS scenario (custom groups are scenario-level,
  // §11.3); an overrides_rule_id must reference a GLOBAL template rule (an
  // override re-parameterises a global rule, never another scenario's local one).
  rules: [
    { column: 'custom_group_id', table: TABLES.CAP_CUSTOM_GROUPS, mode: 'scenario' },
    { column: 'overrides_rule_id', table: TABLES.CAP_RULES, mode: 'global-row' },
  ],
  custom_groups: [
    { column: 'team_id', table: TABLES.CAP_TEAMS, mode: 'catalogue' },
  ],
  custom_group_members: [
    { column: 'group_id', table: TABLES.CAP_CUSTOM_GROUPS, mode: 'scenario' },
    { column: 'member_vm_id', table: TABLES.CAP_VMS, mode: 'scenario' },
    { column: 'member_instance_id', table: TABLES.CAP_DB_INSTANCES, mode: 'scenario' },
  ],
  waivers: [
    // A waiver may reference a global template rule OR a scenario-local rule.
    { column: 'rule_id', table: TABLES.CAP_RULES, mode: 'catalogue' },
  ],
});

// Scenario-health integrity FK probes (Layer A list aggregate). DERIVED from
// CHILD_FK_VALIDATIONS + CHILD_MOUNTS so the list-health probe set cannot drift
// from the write-time §17.1a reference validator. Restricted to the placement
// entities the pure computeScenarioHealth also models (hypervisors / databases /
// vms / db_instances) and to scenario/catalogue modes — a 'global'/'global-row'
// ref or the db_instance vm_type refinement is a different validation, out of the
// dangling/scope scope of health. Each entry: { from, fk, to, mode }.
const SCENARIO_HEALTH_FK_SEGMENTS = Object.freeze(['hypervisors', 'databases', 'vms', 'db_instances']);
const SCENARIO_INTEGRITY_FK_PROBES = Object.freeze(
  SCENARIO_HEALTH_FK_SEGMENTS.flatMap((segment) =>
    (CHILD_FK_VALIDATIONS[segment] || [])
      .filter((spec) => spec.mode === 'scenario' || spec.mode === 'catalogue')
      .map((spec) => Object.freeze({
        from: CHILD_MOUNTS[segment].table,
        fk: spec.column,
        to: spec.table,
        mode: spec.mode,
      })),
  ),
);

/**
 * Build a createCrudRoutes `preWriteInTx` hook that runs the §17.1a
 * reference-integrity check INSIDE the factory's
 * write transaction and with a FOR UPDATE lock on every referenced row
 * (checkReferences lock:true). This closes the child-write vs catalogue-delete
 * race (514-cand #1): the referenced catalogue row is held from the check through
 * the caller's own INSERT/UPDATE, so a concurrent config.js catalogue DELETE
 * cannot commit a dangling reference (bundles.js / wizard.js / io.js protocol).
 * `conn` is the factory's OPEN transaction connection. Returns
 * `{ status, code, message }` on rejection (the factory rolls back + responds),
 * else null. Present-only; a NULL value is a cleared nullable FK and skips.
 * The lock path probes in a canonical (table, value) order (reference-integrity.js)
 * so concurrent child writes acquire the row locks in one sequence (deadlock-free).
 */
function makeScenarioFkLockValidator(specs) {
  return async function validateScenarioFksLocked(conn, req, data) {
    // THE REFERENCES THIS CHECKS ARE THE ONES THE STATEMENT WILL WRITE. `data`
    // is that object; `req.body` is not, because by the time a hook runs the
    // factory has already removed the columns this caller may not write. A
    // column present in the body and absent from `data` is one the write does
    // not carry, and locking + validating a reference the statement will never
    // store is the divergence this contract exists to end.
    const write = data || {};
    const active = specs
      .filter((s) => Object.prototype.hasOwnProperty.call(write, s.column))
      .map((s) => ({ ...s, value: write[s.column] }));
    if (!active.length) return null;
    // The scope, however, is NOT a column of this write: `scenario_id` is
    // immutable, so the factory strips it from every PUT. bindScenarioScope
    // records the URL's scenario on the request for exactly this reason.
    const scenarioId = scenarioScopeOf(req);
    const result = await checkReferences(conn, scenarioId, active, { lock: true });
    if (!result.ok) return { status: 400, code: result.code, message: result.message };
    // AND THE STATEMENT BINDS WHAT THE CHECK RESOLVED. `data` is the object the
    // INSERT/UPDATE is built from, and these columns are `CHAR(36)` under a
    // case-folding collation — so the check above passes for a spelling the
    // referenced row does not hold, and without this the write would store that
    // spelling. Every SQL reader goes on resolving it; the front end's own
    // `.find(n => n.id === row.<fk>)`, every Map keyed on the stored id and the
    // sizing hydration do not. Rebinding here covers BOTH verbs on every mount
    // that declares references, which is why it is here and not at a call site.
    for (const s of active) {
      const stored = result.canonical.get(canonicalKey(s.table, s.value));
      if (stored != null) write[s.column] = stored;
    }
    return null;
  };
}

/**
 * Build a createCrudRoutes `preWriteInTx` hook that canonicalises a written
 * `cap_databases.dc_refs` value to the spellings the scenario's `cap_sites` rows
 * actually hold — the JSON-list counterpart of the scalar rebind
 * `makeScenarioFkLockValidator` does for `site_id`. `dc_refs` is not a scalar FK,
 * so it is absent from CHILD_FK_VALIDATIONS and reaches this the only other way a
 * write-time reference can: its own hook.
 *
 * BOTH VERBS, ONE HOOK: `preWriteInTx` runs on POST and on PUT, and `data`
 * carries `dc_refs` only when THIS write sets it — a partial PUT that omits it is
 * untouched, so an unrelated save never rewrites a restriction it was not given
 * (nor a pre-existing dangling one).
 *
 * At this point in the factory `dc_refs` is already the JSON string form
 * (`mapRowToDb` ran before the transaction), so the hook parses, rewrites the
 * resolving entries and re-serialises. `null` is an explicit clear (= all data
 * centres) and needs no resolution.
 *
 * DELIBERATELY NOT `FOR UPDATE`. A site's id is immutable, so a plain read yields
 * the correct canonical spelling; the only thing a lock would add is closing the
 * `dc_refs`-write vs site-delete race, which `site-references.js` documents as
 * intentionally open (`dc_refs` is not a validated reference — closing it changes
 * what the column may store). Matching by `= ?` uses the SAME `CHAR(36)`
 * case-folding comparison every scalar `site_id` reader makes, so a resolved
 * value is byte-identical to a real site id and the byte-comparison readers admit
 * it.
 */
// DoS bound on the same hook (mirrors MAX_RULE_CONDITIONS above): each distinct
// string entry costs one awaited SELECT inside the write transaction, run one at
// a time under the row locks the write already holds. Sized like
// sites-reorder.js's own MAX_SITES=200 bulk-rewrite ceiling — a resource bound
// on the write, not a cap on how many sites a scenario may legitimately hold.
// This is entry COUNT, not reference validity: `dcRefEntries` counts a dangling
// entry same as a resolving one (this hook never rejects one for failing to
// resolve — that semantic stays with `canonicalizeDcRefs`, see its doc-block).
const MAX_DC_REFS_ENTRIES = 200;

function makeDcRefsCanonicalizer() {
  return async function canonicalizeDcRefsOnWrite(conn, req, data) {
    const write = data || {};
    if (!Object.prototype.hasOwnProperty.call(write, 'dc_refs')) return null;
    const raw = write.dc_refs;
    if (raw == null) return null;
    if (dcRefEntries(raw).length > MAX_DC_REFS_ENTRIES) {
      return {
        code: 'TOO_MANY_DC_REFS_ENTRIES',
        message: `dc_refs exceeds ${MAX_DC_REFS_ENTRIES} entries`,
        status: 400,
      };
    }
    const scenarioId = scenarioScopeOf(req);
    const resolve = async (entry) => {
      const rows = await conn.query(
        `SELECT id FROM \`${t(TABLES.CAP_SITES)}\` WHERE scenario_id = ? AND id = ? LIMIT 1`,
        [scenarioId, entry],
      );
      return rows.length ? rows[0].id : null;
    };
    const canon = await canonicalizeDcRefs(raw, resolve);
    if (canon) write.dc_refs = JSON.stringify(canon);
    return null;
  };
}

/**
 * Build a createCrudRoutes `preWriteInTx` hook that canonicalises a written
 * `cap_vm_profiles.allowed_disk_combos` value to the spellings the referenced
 * `cap_disk_combos` rows actually hold — the vm_profiles counterpart of
 * `makeDcRefsCanonicalizer` above (D4's fix for dc_refs; fmb-1566's deferred
 * half, item 4a).
 *
 * WHY THIS MATTERS EVEN THOUGH THE ALLOW-LIST STAYS UNVALIDATED. The block below
 * (`diskComboAllowed`) judges a WRITTEN `disk_combo_id` — already canonicalised
 * to its own row's spelling by the §17.1a scalar-FK validator — with a byte
 * `.includes` against this list. An allow-list entry stored in the CALLER's
 * spelling therefore silently refuses a combo the operator meant to permit: the
 * identical spelling-disagreement shape D4 measured on dc_refs, on the OTHER
 * side of the same comparison. Canonicalising here, not loosening the compare
 * there, is the same choice D4 made and for the same reason (`dcRefsAdmitsSite`'s
 * note above).
 *
 * `resolve(entry)` accepts a GLOBAL combo (scenario_id IS NULL) or one LOCAL to
 * the profile's OWN scenario — the §17.1a 'catalogue' mode, the same rule
 * `disk_combo_id`'s own scalar FK is held to. `scenarioScopeOf(req)` is the
 * PROFILE's scenario: undefined/null on the global /config mount (so only
 * `scenario_id IS NULL` rows resolve — `scenario_id = ?` never matches a NULL
 * parameter in SQL), the URL scenario id on /local-catalogues.
 *
 * Same non-validating philosophy as dc_refs: an unresolvable entry (a combo id
 * naming nothing this profile may reference, or any non-string element) is left
 * BYTE-FOR-BYTE as it was — this hook only ever rewrites a spelling, never
 * rejects a write, matching the "soft JSON allow-list, unvalidated" design this
 * module already states for `allowed_disk_combos` (existence is still not
 * enforced; only a RESOLVING entry's spelling moves).
 */
// DoS bound on the same hook (mirrors MAX_DC_REFS_ENTRIES above): each distinct
// string entry costs one awaited SELECT inside the write transaction — here run
// one at a time under the row locks the write already holds, with NO cap before
// D5 review finding 1. Sized identically to the dc_refs cap (this hook resolves
// the same shape of list, one entry at a time). This is entry COUNT, not
// reference validity: an entry that fails to resolve is still stored verbatim
// at or under the cap, same as `canonicalizeAllowedDiskCombosOnWrite` does
// without it.
const MAX_ALLOWED_DISK_COMBOS_ENTRIES = 200;

function makeAllowedDiskCombosCanonicalizer() {
  return async function canonicalizeAllowedDiskCombosOnWrite(conn, req, data) {
    const write = data || {};
    if (!Object.prototype.hasOwnProperty.call(write, 'allowed_disk_combos')) return null;
    const raw = write.allowed_disk_combos;
    if (raw == null) return null;
    let list = raw;
    if (typeof list === 'string') {
      try { list = JSON.parse(list); } catch { return null; }
    }
    if (!Array.isArray(list)) return null;
    // Refuse BEFORE any per-entry resolution, mirroring makeDcRefsCanonicalizer's
    // own cap check — no partial resolve-then-reject, no query issued past the
    // limit.
    if (list.length > MAX_ALLOWED_DISK_COMBOS_ENTRIES) {
      return {
        code: 'TOO_MANY_ALLOWED_DISK_COMBOS_ENTRIES',
        message: `allowed_disk_combos exceeds ${MAX_ALLOWED_DISK_COMBOS_ENTRIES} entries`,
        status: 400,
      };
    }
    const scenarioId = scenarioScopeOf(req) ?? null;
    const cache = new Map();
    const resolve = async (entry) => {
      if (cache.has(entry)) return cache.get(entry);
      const rows = await conn.query(
        `SELECT id FROM \`${t(TABLES.CAP_DISK_COMBOS)}\` WHERE id = ? AND (scenario_id IS NULL OR scenario_id = ?) LIMIT 1`,
        [entry, scenarioId],
      );
      const canon = rows.length ? rows[0].id : null;
      cache.set(entry, canon);
      return canon;
    };
    let changed = false;
    const out = [];
    for (const el of list) {
      if (typeof el === 'string' && el) {
        // eslint-disable-next-line no-await-in-loop -- one distinct entry at a
        // time, under the row locks the write already holds; mirrors
        // canonicalizeDcRefs's own sequential resolution.
        const canon = await resolve(el);
        if (canon != null && canon !== el) { out.push(canon); changed = true; continue; }
      }
      out.push(el);
    }
    if (changed) write.allowed_disk_combos = JSON.stringify(out);
    return null;
  };
}

// ── Disk-combo allow-list enforcement (spec §5.3, item D) ────────────────────
//
// vm_profiles.allowed_disk_combos is a JSON list of the disk-combo ids a profile
// permits — historically a SOFT, unvalidated allow-list. This block adds the
// write-time enforcement (spec §5.3): whenever a RESULTING persisted row pairs a
// profile reference with a disk_combo_id, the combo MUST be in that profile's
// allow-list, else 400. Semantics deliberately mirror the FE dropdown filter
// (contract 3) and preserve the soft history:
//   - profile OR combo absent (Custom / no-profile / no-disk) → accept (no pair).
//   - profile row missing → not this check's concern (§17.1a rejects it first).
//   - allow-list null / not-an-array / EMPTY → no restriction defined → accept
//     (tightening a soft list, not retro-breaking rows whose profile never set
//     one).
//   - allow-list non-empty and the combo is NOT a member → reject 400.
// INVARIANT: enforcement is WRITE-TIME only — editing a profile's allow-list does
// NOT retro-validate rows already pairing it with a now-disallowed combo (spec
// §5.3 accepted limitation).

const DISK_COMBO_REJECTION = Object.freeze({
  status: 400,
  code: 'DISK_COMBO_NOT_ALLOWED',
  message: "disk_combo_id is not in the chosen profile's allowed disk combos",
});

// Parse a JSON id-list column (object OR pre-serialized string) to an array of
// STRING ids. A null / unparseable / non-array value → []. Ids are stringified so
// a uuid compares consistently with a stringified disk_combo_id.
function parseIdList(raw) {
  let list = raw;
  if (typeof list === 'string') {
    try { list = JSON.parse(list); } catch { return []; }
  }
  if (!Array.isArray(list)) return [];
  return list.map((v) => String(v));
}

// True when pairing `diskComboId` with a profile carrying `allowedRaw` is allowed.
// An empty / absent allow-list is treated as "no restriction defined" (soft-list
// history preserved); a non-empty list enforces membership.
function diskComboAllowed(allowedRaw, diskComboId) {
  if (diskComboId == null) return true; // no disk → no pair to enforce
  const allowed = parseIdList(allowedRaw);
  if (allowed.length === 0) return true; // no allow-list defined → accept
  return allowed.includes(String(diskComboId));
}

// Read the profile's allow-list on `conn` and judge the (profile, combo) pair.
// Returns a rejection descriptor `{ status, code, message }` or null. A missing
// profile row returns null: the §17.1a reference check owns that rejection.
async function checkDiskComboPairInTx(conn, profileId, diskComboId) {
  if (profileId == null || diskComboId == null) return null;
  const rows = await conn.query(
    `SELECT allowed_disk_combos FROM \`${t(TABLES.CAP_VM_PROFILES)}\` WHERE id = ?`,
    [profileId],
  );
  if (!rows.length) return null;
  if (diskComboAllowed(rows[0].allowed_disk_combos, diskComboId)) return null;
  return { ...DISK_COMBO_REJECTION };
}

/**
 * Build a createCrudRoutes `preWriteInTx` hook that enforces the disk-combo
 * allow-list (spec §5.3) on the RESULTING row of a vms / databases write, INSIDE
 * the factory's write transaction. `profileCol` is the row's profile FK column
 * (`sizing_profile_id` for vms, `profile_id` for databases). On POST the pair is
 * read from the body; on a partial PUT the existing row is loaded + locked
 * (FOR UPDATE, same tx) and the patch merged, so a one-sided update (only a new
 * combo, or only a new profile) is validated against its true final state.
 * Returns `{ status, code, message }` on rejection, else null.
 *
 * LOCK ORDERING CAVEAT: on a PUT this self-locks the mount's OWN row (`table`)
 * FOR UPDATE, OUTSIDE reference-integrity.js's canonical compareCatalogueTable
 * ordering (it runs AFTER makeScenarioFkLockValidator's FK locks). For the vms
 * mount this is safe — cap_vms sorts after every vms FK table, so the self-lock
 * is acquired last, keeping the sequence globally canonical. For the DATABASES
 * mount it is NOT: cap_databases sorts BEFORE its FK tables (cap_disk_combos /
 * cap_teams / cap_vm_profiles), yet the factory locks those FK rows first and
 * cap_databases (self) last — the inverse of the order a vms write uses (it locks
 * cap_databases as an FK BEFORE cap_disk_combos). So a databases PUT that changes
 * disk_combo_id and a concurrent vms write on the SAME (database, disk_combo) can
 * form a lock cycle. This is a PRE-EXISTING narrow race (predates the flip lock);
 * InnoDB deadlock-detects and aborts one txn (error 1213, retryable) rather than
 * hanging. Tracked, not fixed here — a proper fix folds the self-write row into
 * the canonical lock order. The vms invariant above IS mechanically tested.
 */
function makeDiskComboLockValidator(table, profileCol) {
  return async function validateDiskComboLocked(conn, req, data, ctx) {
    // The RESULTING row is what this rule is about, so both sides of the pair
    // are read from the object the statement will bind, never from the body.
    const write = data || {};
    const isUpdate = ctx ? ctx.isUpdate === true : req.method !== 'POST';
    let profileId;
    let diskComboId;
    if (!isUpdate) {
      profileId = write[profileCol] != null ? write[profileCol] : null;
      diskComboId = write.disk_combo_id != null ? write.disk_combo_id : null;
    } else { // PUT — validate the MERGED (existing ⊕ patch) pair
      const touchesProfile = Object.prototype.hasOwnProperty.call(write, profileCol);
      const touchesDisk = Object.prototype.hasOwnProperty.call(write, 'disk_combo_id');
      if (!touchesProfile && !touchesDisk) return null; // neither side changes → nothing to enforce
      // A side the patch supplies wins; a side it omits is pulled from the stored
      // row. `undefined` marks a side still to be resolved from the existing row.
      profileId = touchesProfile ? (write[profileCol] != null ? write[profileCol] : null) : undefined;
      diskComboId = touchesDisk ? (write.disk_combo_id != null ? write.disk_combo_id : null) : undefined;
      // Load + lock the existing row ONLY for the side(s) the patch does not carry
      // (a full PUT of both fields needs no read — the pair is fully determined).
      if (profileId === undefined || diskComboId === undefined) {
        const rowId = ctx && ctx.id != null ? ctx.id : rowIdFromPath(req);
        if (!rowId) return null;
        // The scope is the URL's scenario (scenario_id is immutable and is
        // stripped from the update), matching makeScenarioFkLockValidator.
        const scenarioId = scenarioScopeOf(req);
        const rows = await conn.query(
          `SELECT \`${profileCol}\` AS profile_id, disk_combo_id FROM \`${t(table)}\` WHERE id = ? AND scenario_id = ? FOR UPDATE`,
          [rowId, scenarioId],
        );
        const existing = rows[0];
        if (!existing) return null; // makeRowScenarioBinding already 404s a missing/foreign row
        if (profileId === undefined) profileId = existing.profile_id;
        if (diskComboId === undefined) diskComboId = existing.disk_combo_id;
      }
    }
    return checkDiskComboPairInTx(conn, profileId, diskComboId);
  };
}

/**
 * Compose several createCrudRoutes `preWriteInTx` hooks into one, run in order;
 * the first hook to return a rejection short-circuits (the factory rolls back +
 * responds). Layers the disk-combo allow-list check after the §17.1a catalogue-FK
 * lock check on the vms / databases mounts.
 */
function composePreWriteInTx(...hooks) {
  const active = hooks.filter(Boolean);
  // FORWARDS THE WHOLE SIGNATURE. This wrapper is the single choke point every
  // capacity mount's guards run through, so an argument it drops is an argument
  // no inner hook can ever see, however carefully the inner hook is written —
  // and `data`/`ctx` are exactly the arguments that stop a guard deciding about
  // a value the statement is not writing.
  return async function runPreWriteHooks(conn, req, data, ctx) {
    for (const hook of active) {
      const err = await hook(conn, req, data, ctx);
      if (err) return err;
    }
    return null;
  };
}

// ── Profile-derived sizing (spec §3.1.6 / §5.2, wizard server-side derivation) ─
//
// The wizard persists a VM/instance's real sizing SERVER-SIDE (plan revision TA.1)
// so no client can recreate the `?? 0` autofill bug. These pure helpers mirror the
// FE's capacity-config-model.ts formula (a server-derived value equals what the
// grid would compute). cap_vm_profiles carries NO disk column (DDL) — disk always
// comes from the chosen disk combo's sizes, never the profile.

const DEFAULT_FORMULA = Object.freeze({
  memCpuRatio: 20, sgaFactor: 0.982, sgaDivisor: 2, sgaSubtract: 2,
});

function toFiniteNumber(v, fallback) {
  const n = typeof v === 'number' ? v : Number(v);
  return Number.isFinite(n) ? n : fallback;
}

// Read the formula constants off a settings row. A null row / null column falls
// back to DEFAULT_FORMULA; a zero divisor is coerced to the default to avoid a
// divide-by-zero (FE parity, readFormulaConstants).
function readFormulaConstants(settingsRow) {
  if (!settingsRow) return { ...DEFAULT_FORMULA };
  const divisor = toFiniteNumber(settingsRow.sga_divisor, DEFAULT_FORMULA.sgaDivisor)
    || DEFAULT_FORMULA.sgaDivisor;
  return {
    memCpuRatio: toFiniteNumber(settingsRow.mem_cpu_ratio, DEFAULT_FORMULA.memCpuRatio),
    sgaFactor: toFiniteNumber(settingsRow.sga_factor, DEFAULT_FORMULA.sgaFactor),
    sgaDivisor: divisor,
    sgaSubtract: toFiniteNumber(settingsRow.sga_subtract, DEFAULT_FORMULA.sgaSubtract),
  };
}

// Resolve a profile row's effective { cpu, memGb, sgaCapGb } (spec §9.3). Formula
// mode derives mem from cpu and the DB-class SGA cap from mem; custom mode uses the
// hand-set columns. sgaCapGb is null for an AP-class profile (no SGA). Mirrors
// capacity-config-model.ts profileDisplayValues. Returns null for a missing profile.
function resolveProfileSizing(profile, formula) {
  if (!profile) return null;
  const cpu = toFiniteNumber(profile.cpu, 0);
  const isDb = String(profile.class) === 'DB';
  if (String(profile.mode) === 'custom') {
    // Whole numbers by input rule (fmb-1433), but the columns stay DOUBLE and
    // were never migrated — a row authored before the rule can still hold a
    // fraction, so the read floors it rather than deriving a fractional VM.
    return {
      cpu,
      memGb: floorGb(toFiniteNumber(profile.mem_gb, 0)),
      sgaCapGb: isDb ? floorGb(toFiniteNumber(profile.sga_cap_gb, 0)) : null,
    };
  }
  const memGb = floorGb(cpu * formula.memCpuRatio);
  return {
    cpu,
    memGb,
    sgaCapGb: isDb
      ? Math.floor((memGb * formula.sgaFactor) / formula.sgaDivisor - formula.sgaSubtract)
      : null,
  };
}

// Sum a disk combo's `sizes` JSON list (object OR string) to a GB total. A null /
// unparseable / non-array value → 0; non-numeric entries are ignored.
function sumDiskComboSizes(sizesRaw) {
  let sizes = sizesRaw;
  if (typeof sizes === 'string') {
    try { sizes = JSON.parse(sizes); } catch { return 0; }
  }
  if (!Array.isArray(sizes)) return 0;
  return sizes.reduce((sum, v) => {
    const n = typeof v === 'number' ? v : Number(v);
    return Number.isFinite(n) ? sum + n : sum;
  }, 0);
}

// Extract the row id from a child mount's request path. The mount strips the
// `/scenarios/:scenarioId/<segment>` prefix, so for a `/:id` route (PUT/DELETE)
// req.path is `/<id>`; for the collection route (list/create) it is `/`.
function rowIdFromPath(req) {
  const seg = req.path.split('/').filter(Boolean);
  return seg[0];
}

const notFound = (res) => {
  const e = apiError('Not found', 'NOT_FOUND', 404);
  res.status(e.status).json(e.body);
};
const childDbError = (res) => {
  const e = apiError('Database operation failed', 'INTERNAL_ERROR', 500);
  res.status(e.status).json(e.body);
};

/**
 * Fast role gate for the child mounts' write methods. The scenario-exists /
 * row-binding / flip / FK pre-guards each issue a DB SELECT; without this an
 * unauthorized caller would touch the DB before the factory's own write gate
 * rejected them. Reads (GET) stay open to all authenticated users (spec §7);
 * writes require admin or editor — a plain user is refused 403 before any query.
 * (makeChildDelete keeps its own identical gate as defense in depth.)
 */
function childWriteRoleGate(req, res, next) {
  if (req.method === 'GET') return next();
  if (!requireAdminOrEditor(req, res)) return;
  return next();
}

// cap_waivers.object_set_key column width (table-ddls.js VARCHAR(512)). A value
// past this would be silently truncated by the DB, corrupting the deterministic
// waiver-match key (a truncated key would never re-match its intended subject
// set on recompute) — so an oversized write is rejected 400 at the source.
const MAX_OBJECT_SET_KEY = 512;

/**
 * POST/PUT guard for the cap_waivers child mount: validate a client-supplied
 * object_set_key. Present-only — a body that omits the column, or sends null (an
 * unset key the NOT NULL DDL / caller handles), is unaffected. The io.js import
 * path computes object_set_key server-side (objectSetKey over the resolved
 * subject ids), so this guard covers the direct-write vector only.
 * SECURITY: a PRESENT non-string value (number / array / object) would otherwise
 * slip past a length-only check and stringify unpredictably at the DB write —
 * this is the ONLY validator covering this column on the waivers mount — so ANY
 * present non-string is rejected 400, as is any string past the column width.
 */
function makeObjectSetKeyGuard() {
  return function objectSetKeyGuard(req, res, next) {
    if (req.method !== 'POST' && req.method !== 'PUT') return next();
    const v = req.body ? req.body.object_set_key : undefined;
    if (v === undefined || v === null) return next();
    if (typeof v !== 'string') {
      const e = apiError('object_set_key must be a string', 'BAD_REQUEST', 400);
      return res.status(e.status).json(e.body);
    }
    if (v.length > MAX_OBJECT_SET_KEY) {
      const e = apiError(`object_set_key exceeds ${MAX_OBJECT_SET_KEY} characters`, 'BAD_REQUEST', 400);
      return res.status(e.status).json(e.body);
    }
    return next();
  };
}

/**
 * POST + list-GET guard: the URL-bound scenario must exist, AND (on POST) the
 * row is stamped with the id that scenario actually carries.
 *
 * ASKING WHETHER IT EXISTS IS ONLY HALF. `cap_scenarios.id` is `CHAR(36)` under
 * a case-folding collation, so this `WHERE id = ?` resolves the scenario for any
 * spelling of it — and `bindScenarioScope` then forced the CALLER'S spelling
 * into `body.scenario_id`, which is what the INSERT bound. The row landed
 * carrying a value no scenario's `id` holds.
 *
 * Nothing looked wrong afterwards, because every `WHERE scenario_id = ?` still
 * found it. What stopped working was every reader that resolves the scope in
 * JavaScript: the PUT row binding 404'd the row through the URL the application
 * itself builds, the reference-integrity check refused any sibling that tried to
 * point at it, and a clone's id map missed it so the copy kept pointing at the
 * SOURCE scenario's rows. Half-editable, unreferenceable, and created by nothing
 * more than a URL spelling.
 *
 * So the stored id is read back and becomes the scope from here on — recorded on
 * the request for the in-transaction guards and re-bound into the body the
 * statement is built from. The caller's spelling is not used again.
 *
 * 404 (not 403) — a missing scenario is a not-found, and this runs for every
 * role: the generic factory checks ownership only for editors
 * (parentOwnership), so an admin would otherwise create an orphan child under a
 * scenario_id nothing resolves.
 *
 * ALSO THE LIST GET (`req.path === '/'`, i.e. `GET .../sites` with no `:id`),
 * added for the same reason as POST: a scenario_id that resolves no row is not
 * "a scenario with zero children", it is a scenario that is not there, and
 * `GET /scenarios/:id` (scenarios.js, the generic single-row factory route)
 * already answers that with 404. Before this, every child list silently
 * filtered to nothing instead — `WHERE scenario_id = ?` matches no rows either
 * way, so a deleted scenario's child list and a real, empty scenario's child
 * list were the same response.
 *
 * THE SINGLE-ROW GET (`/:id`) IS DELIBERATELY LEFT OUT. Per this file's mount
 * comment, that route "fetches strictly by id and ignores the injected query
 * filter, so a direct id read can cross scenarios" — a documented, intentional
 * design (reads are open to all authenticated users). Gating it on the URL's
 * scenarioId would refuse a perfectly valid row whenever that segment happened
 * to be stale or spelled for a different scenario, which is exactly the
 * cross-scenario read this mount chose to allow. PUT/DELETE need no addition
 * either: their target is always `/:id`, and a row under a deleted scenario
 * (cascade-removed with it) already 404s through the ordinary row lookup.
 */
function makeScenarioExistsGuard() {
  return async function scenarioExistsGuard(req, res, next) {
    const isListGet = req.method === 'GET' && req.path === '/';
    if (req.method !== 'POST' && !isListGet) return next();
    try {
      const rows = await pool.rw.query(
        `SELECT id FROM \`${t(TABLES.CAP_SCENARIOS)}\` WHERE id = ?`,
        [req.params.scenarioId],
      );
      if (!rows.length) return notFound(res);
      req.capacityScenarioId = rows[0].id;
      if (req.body && typeof req.body === 'object') req.body.scenario_id = rows[0].id;
    } catch (err) {
      logger.error({ err, scenarioId: req.params.scenarioId }, 'capacity scenario-exists guard failed');
      return childDbError(res);
    }
    return next();
  };
}

/**
 * PUT guard: the target row must belong to the URL-bound scenario. Without it,
 * the factory PUT resolves ownership from the row's OWN scenario_id, so a caller
 * who owns scenario B could edit B's row via scenario A's URL. 404 (not 403) so
 * cross-scenario existence is not revealed. (DELETE is handled by makeChildDelete,
 * which performs the same in-scenario check inside its transaction.)
 *
 * "IS THIS ROW IN THAT SCENARIO" IS ASKED OF THE COLUMN, in the statement that
 * fetches the row rather than in JavaScript afterwards. The comparison used to
 * be `String(row.scenario_id) !== String(req.params.scenarioId)`, which is a
 * third opinion about scenario identity next to this file's exists guard (SQL)
 * and reference-integrity's own check — and the narrowest of the three, so it
 * refused rows the rest of the system considers in scope. Binding the scope into
 * the predicate also removes the null case the old code had to special-case:
 * `scenario_id = ?` never matches NULL, so a GLOBAL row cannot satisfy a
 * scenario-bound PUT and no `String(null)` can look like a path segment.
 *
 * The stored scenario id is then the scope for everything downstream, for the
 * same reason the create path re-binds it: the in-transaction reference checks
 * compare it against other rows' stored values.
 */
function makeRowScenarioBinding(table) {
  return async function rowScenarioBinding(req, res, next) {
    if (req.method !== 'PUT') return next();
    const rowId = rowIdFromPath(req);
    if (!rowId) return next();
    try {
      const rows = await pool.rw.query(
        `SELECT scenario_id FROM \`${t(table)}\` WHERE id = ? AND scenario_id = ?`,
        [rowId, req.params.scenarioId],
      );
      if (!rows.length) return notFound(res);
      req.capacityScenarioId = rows[0].scenario_id;
    } catch (err) {
      logger.error({ err, table, rowId }, 'capacity row-scenario binding failed');
      return childDbError(res);
    }
    return next();
  };
}

/**
 * createCrudRoutes `preWriteInTx` guard on cap_vms: flipping vm_type to 'ap_host'
 * while the VM still owns cap_db_instances is rejected 409 — an ap_host is a leaf
 * and cannot carry DB instances (spec §2.3: db_instances are children of a
 * db_host VM only). Runs the check INSIDE the factory's write transaction,
 * locking the target cap_vms row FOR UPDATE first so it serialises with a
 * concurrent db_instance INSERT (extends #629's in-tx locking to this read).
 * That INSERT's §17.1a FK check FOR UPDATE-locks the SAME vm row (requireVmType
 * 'db_host', makeScenarioFkLockValidator), so the two paths contend on one row
 * lock: either this flip commits first (the INSERT's re-read then sees
 * vm_type='ap_host' → 400 INVALID_PARENT_TYPE) or the INSERT commits first (this
 * probe then sees the new instance → 409). Neither can leave an ap_host owning a
 * db_instance. The scenario scope is bindScenarioScope's forced body.scenario_id
 * (the factory Router does not mergeParams, so req.params.scenarioId is undefined
 * here — matching makeScenarioFkLockValidator / makeDiskComboLockValidator).
 * Returns `{ status, code, message }` on rejection, else null.
 *
 * LOCK ORDERING INVARIANT: this self-lock on cap_vms sits OUTSIDE
 * reference-integrity.js's canonical compareCatalogueTable ordering (it runs in
 * the vms preWriteInTx AFTER makeScenarioFkLockValidator has locked the vms FK
 * catalogue rows). It is deadlock-safe ONLY because cap_vms sorts AFTER every
 * table in CHILD_FK_VALIDATIONS.vms — so the FK locks are all acquired before
 * this one and the whole sequence stays globally canonical (cap_vms locked last).
 * A future vms FK spec pointing at a table that sorts >= cap_vms would break this;
 * a mechanical test asserts the invariant so it fails loudly instead of
 * deadlocking in production.
 */
function makeVmTypeFlipLockValidator() {
  return async function vmTypeFlipLocked(conn, req, data, ctx) {
    // The flip this refuses is the one the UPDATE will store, so the value is
    // read from `data` rather than from the body it arrived in.
    const write = data || {};
    // Case-insensitive ENUM: 'AP_HOST' would be accepted + normalised by the DB,
    // so lower-case before comparing (the factory enumColumns 400s a non-canonical
    // value first, so a stored vm_type is always canonical lowercase).
    const vmType = write.vm_type != null ? String(write.vm_type).toLowerCase() : null;
    const isUpdate = ctx ? ctx.isUpdate === true : req.method === 'PUT';
    if (!isUpdate || vmType !== 'ap_host') return null;
    const rowId = ctx && ctx.id != null ? ctx.id : rowIdFromPath(req);
    if (!rowId) return null;
    const scenarioId = scenarioScopeOf(req);
    // Lock the vm row so a racing db_instance INSERT (which FOR UPDATE-locks the
    // same row through its FK check) serialises against this flip.
    await conn.query(
      `SELECT id FROM \`${t(TABLES.CAP_VMS)}\` WHERE id = ? AND scenario_id = ? FOR UPDATE`,
      [rowId, scenarioId],
    );
    const dep = await conn.query(
      `SELECT 1 FROM \`${t(TABLES.CAP_DB_INSTANCES)}\` WHERE vm_id = ? AND scenario_id = ? LIMIT 1`,
      [rowId, scenarioId],
    );
    if (dep.length) {
      return {
        status: 409,
        code: 'CONFLICT',
        message: 'Cannot change this VM to ap_host while it still has DB instances; remove them first',
      };
    }
    return null;
  };
}

/**
 * POST/PUT guard on cap_rules: at most ONE override row per (scenario,
 * overrides_rule_id) (spec §17.1 — an override carries a single scenario's
 * enabled/params/severity state for a given global rule; a second would make the
 * effective rule ambiguous). Only fires when the body sets `overrides_rule_id`;
 * a plain scenario-local rule (no override target) is unaffected. Excludes the
 * row's own id on a PUT so a no-op re-save never self-collides. 409 on a
 * duplicate. Runs after the reference-integrity FK validator (which already
 * confirmed the target is a global rule).
 */
function makeRuleOverrideUniquenessGuard() {
  return async function ruleOverrideUniqueness(req, res, next) {
    if (req.method !== 'POST' && req.method !== 'PUT') return next();
    const body = req.body || {};
    if (body.overrides_rule_id == null) return next();
    const scenarioId = req.params.scenarioId;
    const excludeId = req.method === 'PUT' ? rowIdFromPath(req) : null;
    try {
      const rows = await pool.rw.query(
        `SELECT 1 FROM \`${t(TABLES.CAP_RULES)}\` WHERE scenario_id = ? AND overrides_rule_id = ?`
        + (excludeId ? ' AND id != ?' : '') + ' LIMIT 1',
        excludeId ? [scenarioId, body.overrides_rule_id, excludeId] : [scenarioId, body.overrides_rule_id],
      );
      if (rows.length) {
        const e = apiError('An override for this rule already exists in this scenario', 'CONFLICT', 409);
        return res.status(e.status).json(e.body);
      }
    } catch (err) {
      logger.error({ err, scenarioId }, 'capacity rule override uniqueness check failed');
      const e = apiError('Database operation failed', 'INTERNAL_ERROR', 500);
      return res.status(e.status).json(e.body);
    }
    return next();
  };
}

/**
 * POST middleware for the scenario cap_rules mount: fill an override row's NOT
 * NULL identity columns from the referenced global rule (Codex R1.14 #1). An
 * override row's documented payload is `overrides_rule_id` + `enabled`
 * (+ params/severity) — the evaluator resolves type/level/group_by/name from the
 * target (resolveEffectiveRules) and never reads the override's own copies. But
 * cap_rules.type/name/level are NOT NULL with no defaults, so the generic INSERT
 * would 500. Rather than make those columns nullable (weakening the constraint
 * for EVERY row), default the omitted ones from the referenced global rule at
 * insert (option a): NOT NULL integrity is kept and a raw row read is coherent.
 * The values are cosmetic for evaluation (the target is re-read at eval time), so
 * later drift of the global row's name is harmless.
 *
 * AND WHEN THE TARGET IS NOT THERE, THIS GUARD SAYS SO ITSELF. It used to fill
 * nothing and fall through, on the reasoning that the §17.1a FK check further
 * down would reject the bad `overrides_rule_id` before any INSERT. That is no
 * longer what the operator is told: the create-time requirement on a NOT NULL
 * ENUM with no default now refuses the unfilled body FIRST, with
 * COLUMN_REQUIRED naming `type` — a column an override payload is documented
 * never to carry. Still a 400, and still nothing written, but the sentence sends
 * the reader to the wrong field. A body that NEEDS the fill and has no target to
 * fill from cannot succeed by any route, so refusing it here with the reference
 * reason changes no outcome and fixes the diagnosis. The message is the §17.1a
 * validator's own, so there is one sentence for one refusal.
 */
function makeOverrideFillGuard() {
  const FILL_COLS = ['type', 'name', 'level', 'group_by'];
  return async function overrideFill(req, res, next) {
    if (req.method !== 'POST') return next();
    const body = req.body || {};
    if (body.overrides_rule_id == null) return next();
    if (!FILL_COLS.some((c) => body[c] == null)) return next(); // client supplied them all
    try {
      const rows = await pool.rw.query(
        `SELECT type, name, level, group_by FROM \`${t(TABLES.CAP_RULES)}\` WHERE id = ? AND scenario_id IS NULL`,
        [body.overrides_rule_id],
      );
      const target = rows[0];
      if (!target) {
        const e = apiError(
          messageForMode('overrides_rule_id', 'global-row'), 'INVALID_REFERENCE', 400,
        );
        return res.status(e.status).json(e.body);
      }
      for (const c of FILL_COLS) {
        if (body[c] == null && target[c] != null) body[c] = target[c];
      }
    } catch (err) {
      logger.error({ err }, 'capacity override identity fill failed');
      return childDbError(res);
    }
    return next();
  };
}

/**
 * PUT middleware for the scenario cap_rules mount: re-validate a partial update's
 * merged (existing ⊕ body) level / group_by legality (validateRulePutMerge). The
 * sync ruleWriteGuard above only sees the request body, so a `{ level: 'vm' }`
 * PUT on a hypervisor-only rule bypasses the per-type check; this reads the stored
 * row (scoped to THIS scenario) and re-checks the true final state. POST is fully
 * covered by ruleWriteGuard (the whole row is present) → this only handles PUT.
 */
function makeRulePutMergeGuard() {
  return async function rulePutMerge(req, res, next) {
    if (req.method !== 'PUT') return next();
    const rowId = rowIdFromPath(req);
    if (!rowId) return next();
    try {
      const bad = await validateRulePutMerge(
        async () => {
          const rows = await pool.rw.query(
            `SELECT type, level, group_by FROM \`${t(TABLES.CAP_RULES)}\` WHERE id = ? AND scenario_id = ?`,
            [rowId, req.params.scenarioId],
          );
          return rows[0] || null;
        },
        req.body || {},
        { strictType: true },
      );
      if (bad) {
        const e = apiError(bad.message, bad.code, 400);
        return res.status(e.status).json(e.body);
      }
    } catch (err) {
      logger.error({ err, rowId }, 'capacity rule PUT merge validation failed');
      const e = apiError('Database operation failed', 'INTERNAL_ERROR', 500);
      return res.status(e.status).json(e.body);
    }
    return next();
  };
}

/**
 * POST/PUT middleware for the scenario cap_custom_group_members mount: enforce the
 * exactly-one-member invariant (validateGroupMemberXor). On POST the body is the
 * whole row. On PUT it merges the body over the stored row (scoped to THIS
 * scenario) so a partial update cannot break the invariant — e.g. adding
 * member_vm_id to a row that already carries member_instance_id (→ both), or
 * clearing the only member (→ neither). A PUT touching neither member column
 * leaves a valid stored row valid → skipped without a DB round trip. Runs after
 * makeRowScenarioBinding (which 404s a cross-scenario / missing row first).
 */
function makeCustomGroupMemberXorGuard() {
  return async function customGroupMemberXor(req, res, next) {
    if (req.method !== 'POST' && req.method !== 'PUT') return next();
    const body = req.body || {};
    if (req.method === 'POST') {
      const bad = validateGroupMemberXor(body.member_vm_id, body.member_instance_id);
      if (bad) {
        const e = apiError(bad.message, bad.code, 400);
        return res.status(e.status).json(e.body);
      }
      return next();
    }
    const touches = (k) => Object.prototype.hasOwnProperty.call(body, k);
    if (!touches('member_vm_id') && !touches('member_instance_id')) return next();
    const rowId = rowIdFromPath(req);
    if (!rowId) return next();
    try {
      const rows = await pool.rw.query(
        `SELECT member_vm_id, member_instance_id FROM \`${t(TABLES.CAP_CUSTOM_GROUP_MEMBERS)}\` WHERE id = ? AND scenario_id = ?`,
        [rowId, req.params.scenarioId],
      );
      const existing = rows[0];
      if (!existing) return next(); // makeRowScenarioBinding already 404s a missing row
      const mergedVm = touches('member_vm_id') ? body.member_vm_id : existing.member_vm_id;
      const mergedInstance = touches('member_instance_id') ? body.member_instance_id : existing.member_instance_id;
      const bad = validateGroupMemberXor(mergedVm, mergedInstance);
      if (bad) {
        const e = apiError(bad.message, bad.code, 400);
        return res.status(e.status).json(e.body);
      }
    } catch (err) {
      logger.error({ err, rowId }, 'capacity custom group member XOR guard failed');
      return childDbError(res);
    }
    return next();
  };
}

// Per-segment DELETE dependent semantics (spec §2.3):
//   unplace — the reference is OPTIONAL, so a delete NULLs it (never orphans):
//     hypervisor delete → cap_vms.hypervisor_id = NULL (NULL = unplaced VM).
//     vm_profile delete → cap_vms.sizing_profile_id = NULL (profile = prefill-only).
//   cascade — the child cannot exist without the parent, so delete children first:
//     vm delete   → cap_db_instances (an instance is a child of its db_host VM).
//     rule delete → cap_waivers (a waiver is a per-occurrence exception for a rule).
//   block  — the reference is REQUIRED (NOT NULL) with no NULL semantic, so a
//     still-referenced parent delete is refused 409:
//     site / hardware_spec delete → a cap_hypervisors row still points at it.
// NOTE: hardware_specs / vm_profiles / disk_combos / teams are now GLOBAL config
// (deleted via config.js, not a scenario child) — a referential guard on a
// GLOBAL catalogue delete (a hypervisor still points at the spec, a VM at the
// profile) is a config-layer concern deferred to a later slice (tracked in the
// report); it is not a scenario-child delete behavior.
const CHILD_DELETE_BEHAVIOR = Object.freeze({
  hypervisors: { unplace: [{ table: TABLES.CAP_VMS, column: 'hypervisor_id' }] },
  vms:         { cascade: [{ table: TABLES.CAP_DB_INSTANCES, column: 'vm_id' }, { table: TABLES.CAP_CUSTOM_GROUP_MEMBERS, column: 'member_vm_id' }] },
  db_instances: { cascade: [{ table: TABLES.CAP_CUSTOM_GROUP_MEMBERS, column: 'member_instance_id' }] },
  databases:   { unplace: [{ table: TABLES.CAP_VMS, column: 'database_id' }, { table: TABLES.CAP_DB_INSTANCES, column: 'database_id' }] },
  custom_groups: {
    // A rule that targets this group (custom_group_id) would be left dangling —
    // the evaluator resolves an empty member set and the rule silently stops
    // flagging (Codex r2 P1). Refuse 409 while any scenario rule references it;
    // otherwise cascade its explicit members, then delete.
    block: [{ table: TABLES.CAP_RULES, column: 'custom_group_id', message: 'Cannot delete this group while a rule targets it' }],
    cascade: [{ table: TABLES.CAP_CUSTOM_GROUP_MEMBERS, column: 'group_id' }],
  },
  rules:       { cascade: [{ table: TABLES.CAP_WAIVERS, column: 'rule_id' }] },
  // sites declares no per-column probes of its own. Its reference set is
  // produced by ONE sweep (site-references.js) that the delete-impact preview
  // also reads, so the refusal and the preview cannot count different rows —
  // and the same declaration supplies the columns the unplace statement clears
  // and the columns the require-time coverage check below looks for.
  //
  // THE UNPLACE CAN REACH A PLACED VM, and an earlier reading of this that said
  // otherwise was wrong. The blocking groups only guarantee no HYPERVISOR
  // stands in the site being deleted; a VM placed on a host in some other data
  // centre can still hold this site in its cache if the row predates the one
  // write path (nothing backfills those). The statement is scoped by `site_id`,
  // not by placement, so it clears that cache too — and the sweep counts by the
  // same predicate, so what the preview reports is what the statement changes.
  // Harmless: a placed VM's data centre is derived from its host and answers the
  // same either way, and both the health check and the derivation skip a NULL
  // cache. Worth stating because the sentence "this only touches unplaced VMs"
  // is the kind of claim a later change would be built on.
  sites: { sweep: SITE_REFERENCE_SWEEP },
});

/**
 * Every scenario-internal reference the WRITE side declares to `table`, as
 * `{ table, column }` pairs.
 *
 * THE SET OF THINGS THAT REFERENCE A ROW IS ONE SET. `CHILD_FK_VALIDATIONS` is
 * the writer's statement of it — the validator that refuses a reference to a
 * row outside this scenario — and `CHILD_DELETE_BEHAVIOR` above is the
 * deleter's. They were two hand-kept lists, and the failure mode of two lists
 * is not disagreement about a value but a MISSING ENTRY: `cap_vms.site_id` was
 * declared a real scenario-mode FK and appeared nowhere on the delete side.
 *
 * Only `mode: 'scenario'` refs are inverted here. A catalogue-mode ref points
 * at the GLOBAL catalogue layer, whose deletes are guarded by
 * CONFIG_DELETE_GUARDS rather than by a scenario child delete; a 'global-row'
 * ref (an override's target) likewise can only name a global rule.
 */
function scenarioReferencesTo(table) {
  const refs = [];
  for (const [segment, specs] of Object.entries(CHILD_FK_VALIDATIONS)) {
    const referencingTable = CHILD_MOUNTS[segment] && CHILD_MOUNTS[segment].table;
    if (!referencingTable) continue;
    for (const spec of specs) {
      if (spec.mode !== 'scenario') continue;
      if (spec.table !== table) continue;
      refs.push({ table: referencingTable, column: spec.column });
    }
  }
  return refs;
}

// A declared reference with no delete behaviour is a dangling row waiting to
// happen, and the module refuses to build rather than serve one. This is the
// same require-time refusal the factory gives a declared domain it cannot judge
// nullability for, and for the same reason: a gate that cannot answer for what
// it is admitting must not answer requests. It fires at import, so a new FK
// declared without a delete behaviour fails the test run rather than a later
// scenario health read.
for (const [segment, def] of Object.entries(CHILD_MOUNTS)) {
  const behavior = CHILD_DELETE_BEHAVIOR[segment] || {};
  // `SET col = NULL` can only clear a scalar column. A JSON-list reference
  // cannot be unplaced by it — and clearing the last entry of a `dc_refs` list
  // would not mean "no site" but "every site" — so a declaration that paired the
  // two would write a statement nobody could read as its author intended. Refuse
  // at import, like the coverage check below.
  for (const group of (behavior.sweep ? behavior.sweep.groups : [])) {
    if (group.disposition === 'unplace' && group.jsonList) {
      throw new Error(
        `[CHILD_DELETE_BEHAVIOR]: ${segment} declares ${group.table}.${group.column} as a JSON-list `
        + 'reference to unplace, and the unplace statement can only NULL a scalar column',
      );
    }
  }
  const covered = new Set(
    ['block', 'unplace', 'cascade']
      .flatMap((kind) => behavior[kind] || [])
      // A swept segment declares its references in the sweep instead of as
      // per-column probes; they answer this check exactly as the others do.
      .concat(behavior.sweep ? behavior.sweep.groups : [])
      .map((entry) => `${entry.table}.${entry.column}`),
  );
  for (const ref of scenarioReferencesTo(def.table)) {
    const key = `${ref.table}.${ref.column}`;
    if (covered.has(key)) continue;
    throw new Error(
      `[CHILD_DELETE_BEHAVIOR]: ${key} is declared a scenario reference to ${def.table} `
      + `(CHILD_FK_VALIDATIONS) but the ${segment} delete does not say what becomes of it — `
      + 'the write side would refuse to create that reference and the delete side would dangle it',
    );
  }
}

/**
 * Bring `cap_vms.site_id` back into step with the hosts the VMs stand on, for
 * rows that ALREADY EXIST — the SQL half of `shared/capacity/vm-site.js`.
 *
 * WHY A SECOND EXPRESSION OF ONE RULE. The JavaScript derivation answers about
 * one row in hand; the paths below rebuild a whole scenario in one transaction
 * (an import's delete-then-insert, a clone's row copy, a restore's replay) and
 * have no row in hand at all. A rule applied on one of the two layers is not
 * applied — a restore would land a contradiction the health check then reports.
 * The two are held together by the real-DB suite, which drives both.
 *
 * Only the `host` branch is expressible here, and that is the whole point: an
 * UNPLACED VM's `site_id` is the operator's intended site and nothing derives
 * it, so the join drops those rows and leaves them exactly as they are.
 * `NOT (v.site_id <=> h.site_id)` rather than `<>` so a cache that was never
 * written (NULL) is filled rather than skipped; `<=>` also folds case the way
 * the `CHAR(36)` collation does, so a respelled-but-equal id is not rewritten.
 *
 * `opts.vmIds` narrows to rows the caller has already locked — see the lock-order
 * note in placement-apply.js before widening it. Returns the rows changed.
 */
async function syncVmSiteCache(conn, scenarioId, opts = {}) {
  const params = [scenarioId];
  let extra = '';
  if (opts.hypervisorId != null) {
    extra += ' AND v.hypervisor_id = ?';
    params.push(opts.hypervisorId);
  }
  if (Array.isArray(opts.vmIds)) {
    // An empty list means "no rows", never "every row".
    if (!opts.vmIds.length) return 0;
    extra += ` AND v.id IN (${opts.vmIds.map(() => '?').join(', ')})`;
    params.push(...opts.vmIds);
  }
  const result = await conn.query(
    `UPDATE \`${t(TABLES.CAP_VMS)}\` v
       JOIN \`${t(TABLES.CAP_HYPERVISORS)}\` h
         ON h.id = v.hypervisor_id AND h.scenario_id = v.scenario_id
        SET v.site_id = h.site_id
      WHERE v.scenario_id = ? AND v.hypervisor_id IS NOT NULL
        AND NOT (v.site_id <=> h.site_id)${extra}`,
    params,
  );
  return Number((result && result.affectedRows) || 0);
}

/**
 * DELETE handler for a child entity: verifies the scenario + row exist and the
 * caller owns (or shares) the scenario, applies the dependent semantics above,
 * and deletes the row — all in ONE transaction on ONE connection. Registered as
 * a pre-middleware so it fully handles DELETE ahead of the generic factory
 * (whose blind DELETE would orphan dependents). Non-DELETE falls through.
 */
function makeChildDelete(table, behavior = {}) {
  return async function childDelete(req, res, next) {
    if (req.method !== 'DELETE') return next();
    if (!requireAdminOrEditor(req, res)) return;
    const scenarioId = req.params.scenarioId;
    const rowId = rowIdFromPath(req);
    if (!rowId) return next();
    let conn;
    try {
      conn = await pool.rw.getConnection();
      await conn.beginTransaction();
      // Permission via the owning scenario (locked): admin always; editor only
      // when the scenario is shared (owner_id NULL) or their own.
      const scen = await conn.query(
        `SELECT owner_id FROM \`${t(TABLES.CAP_SCENARIOS)}\` WHERE id = ? FOR UPDATE`, [scenarioId],
      );
      if (!scen.length) { await conn.rollback(); return notFound(res); }
      const owner = scen[0].owner_id;
      // collation-compare: "is this scenario the caller's" is a question about a
      // COLUMN — the write scope's own `WHERE owner_id = ?` folds case — so a
      // `===` here refused the GENUINE owner a row every statement in the system
      // calls theirs.
      if (req.user.role !== 'admin' && owner !== null
        && !(await sameStoredValue(conn, t(TABLES.CAP_SCENARIOS), 'owner_id', owner, req.user.id))) {
        await conn.rollback();
        const e = apiError('Not allowed: you do not own this scenario', 'FORBIDDEN', 403);
        return res.status(e.status).json(e.body);
      }
      // Row must belong to this scenario (else 404 without revealing existence).
      const row = await conn.query(
        `SELECT id FROM \`${t(table)}\` WHERE id = ? AND scenario_id = ? FOR UPDATE`, [rowId, scenarioId],
      );
      if (!row.length) { await conn.rollback(); return notFound(res); }
      // THE SPELLING THE ROW HOLDS, not the one the URL carried. Every statement
      // below except one compares a `CHAR(36)` column under a folding collation,
      // so for those two the two spellings ARE one value and either would do.
      // The sweep's `dc_refs` probe is the exception: JSON containment is a byte
      // comparison, so handed the caller's spelling it finds nothing in a
      // restriction list holding the stored one — the site deletes, the
      // restriction dangles, and the preview (which reads the stored id) has
      // already told the operator the delete was blocked. Measured on MariaDB
      // 10.11 in capacity-site-delete-real-db.test.js: an upper-cased id in the
      // URL turned a 409 into a 200 with the row gone.
      const storedId = row[0].id;
      // A swept segment asks ONE question where the others ask a list of them,
      // and its answer is the whole account of what points at this row: the 409
      // carries that value, so an operator is told WHAT to clear rather than
      // only that something is in the way.
      //
      // IT RUNS BEFORE THE `block` LOOP, and the order is load-bearing rather
      // than tidy. Both reads above are LOCKING ones, which always see the
      // latest committed row; this is the transaction's first plain read, so it
      // is the one that fixes the REPEATABLE READ snapshot every later plain
      // read answers from. A probe placed in front of it would fix that snapshot
      // earlier and hand the sweep a view of the world from before its own
      // question was asked — while the site row it holds stays locked, so
      // nothing would look wrong. `block` and `sweep` are never both declared
      // (the require-time check below covers each reference exactly once), so
      // running the sweep first costs no segment a statement. The order is
      // pinned in capacity-site-delete-one-source.test.js.
      let sweep = null;
      if (behavior.sweep) {
        sweep = await behavior.sweep.run(conn, scenarioId, storedId);
        if (sweep.blocked) {
          await conn.rollback();
          const e = apiError(
            behavior.sweep.refusalMessage(sweep), 'CONFLICT', 409,
            { details: { references: sweep.groups } },
          );
          return res.status(e.status).json(e.body);
        }
      }
      // Blockers first (409): a required reference has no NULL fallback.
      for (const b of behavior.block || []) {
        const dep = await conn.query(
          `SELECT 1 FROM \`${t(b.table)}\` WHERE \`${b.column}\` = ? AND scenario_id = ? LIMIT 1`,
          [rowId, scenarioId],
        );
        if (dep.length) {
          await conn.rollback();
          const e = apiError(b.message, 'CONFLICT', 409);
          return res.status(e.status).json(e.body);
        }
      }
      // WHAT ELSE THIS DELETE DID, COUNTED AND REPORTED. A site delete unpins
      // every VM standing in it and a hypervisor delete unplaces every VM it
      // hosted; a database delete takes its instances with it. The answer used
      // to be `{id, deleted:true}` whatever the blast radius was, so an operator
      // removing one row could not tell whether it had moved five objects or
      // none — while the blueprint owner cascade beside it reports
      // `cascaded_variants`. Reported per column so the number names WHAT moved.
      const unplaced = {};
      // Derived from the sweep's own declaration when the segment has one, so
      // the rows this statement clears are the rows the preview counted — the
      // predicate below is the sweep's predicate for the same group.
      const unplaceRefs = behavior.sweep
        ? behavior.sweep.groups.filter((g) => g.disposition === 'unplace')
        : (behavior.unplace || []);
      for (const u of unplaceRefs) {
        const result = await conn.query(
          `UPDATE \`${t(u.table)}\` SET \`${u.column}\` = NULL WHERE \`${u.column}\` = ? AND scenario_id = ?`,
          [rowId, scenarioId],
        );
        unplaced[`${u.table}.${u.column}`] = Number((result && result.affectedRows) || 0);
      }
      // Cascade delete dependent children first.
      const cascaded = {};
      for (const c of behavior.cascade || []) {
        const result = await conn.query(
          `DELETE FROM \`${t(c.table)}\` WHERE \`${c.column}\` = ? AND scenario_id = ?`,
          [rowId, scenarioId],
        );
        cascaded[`${c.table}.${c.column}`] = Number((result && result.affectedRows) || 0);
      }
      await conn.query(`DELETE FROM \`${t(table)}\` WHERE id = ? AND scenario_id = ?`, [rowId, scenarioId]);
      await conn.commit();
      res.json(apiOk({
        id: rowId, deleted: true, unplaced, cascaded,
      }));
    } catch (err) {
      if (conn) await conn.rollback();
      logger.error({ err, table, rowId }, 'capacity child delete failed');
      childDbError(res);
    } finally {
      if (conn) conn.release();
    }
  };
}

/**
 * POST/PUT pre-middleware that runs a config group's per-column type guard (and
 * whole-body `validate`, if any) against the RAW body, so a write is
 * type-checked exactly like the global /config write (config.js's own
 * validateGroupWrite). `group` is a CONFIG_MOUNTS key.
 */
function makeConfigTypeGuard(group) {
  const def = CONFIG_MOUNTS[group];
  return function configTypeGuard(req, res, next) {
    if (req.method !== 'POST' && req.method !== 'PUT') return next();
    const body = req.body || {};
    if (def && def.types) {
      const typeErr = validateColumnTypes(body, def.types);
      if (typeErr) {
        const e = apiError(typeErr, 'BAD_REQUEST', 400);
        return res.status(e.status).json(e.body);
      }
    }
    if (def && def.validate) {
      const err = def.validate(body);
      if (err) {
        const e = apiError(err, 'BAD_REQUEST', 400);
        return res.status(e.status).json(e.body);
      }
    }
    return next();
  };
}

/**
 * DELETE handler for a scenario-LOCAL catalogue row (local-catalogues.js):
 * verifies the scenario + local row exist and the caller owns (or shares) the
 * scenario, refuses 409 when any live row still references it
 * (findCatalogueReferenceBlocker — the same guard the global /config delete
 * uses), then deletes — all in ONE transaction. Registered as a pre-middleware
 * so it fully handles DELETE ahead of the generic factory (whose blind DELETE
 * would dangle the referencing FK). Non-DELETE falls through. `group` is a
 * CONFIG_DELETE_GUARDS key.
 */
function makeLocalCatalogueDelete(table, group) {
  return async function localCatalogueDelete(req, res, next) {
    if (req.method !== 'DELETE') return next();
    if (!requireAdminOrEditor(req, res)) return;
    const scenarioId = req.params.scenarioId;
    const rowId = rowIdFromPath(req);
    if (!rowId) return next();
    let conn;
    try {
      conn = await pool.rw.getConnection();
      await conn.beginTransaction();
      const scen = await conn.query(
        `SELECT owner_id FROM \`${t(TABLES.CAP_SCENARIOS)}\` WHERE id = ? FOR UPDATE`, [scenarioId],
      );
      if (!scen.length) { await conn.rollback(); return notFound(res); }
      const owner = scen[0].owner_id;
      // collation-compare: "is this scenario the caller's" is a question about a
      // COLUMN — the write scope's own `WHERE owner_id = ?` folds case — so a
      // `===` here refused the GENUINE owner a row every statement in the system
      // calls theirs.
      if (req.user.role !== 'admin' && owner !== null
        && !(await sameStoredValue(conn, t(TABLES.CAP_SCENARIOS), 'owner_id', owner, req.user.id))) {
        await conn.rollback();
        const e = apiError('Not allowed: you do not own this scenario', 'FORBIDDEN', 403);
        return res.status(e.status).json(e.body);
      }
      // The row must be a LOCAL row of THIS scenario (scenario_id = X). A global
      // row (scenario_id IS NULL) is deleted via /config, never here.
      const row = await conn.query(
        `SELECT id FROM \`${t(table)}\` WHERE id = ? AND scenario_id = ? FOR UPDATE`, [rowId, scenarioId],
      );
      if (!row.length) { await conn.rollback(); return notFound(res); }
      const blocker = await findCatalogueReferenceBlocker(conn, group, rowId);
      if (blocker) {
        await conn.rollback();
        const label = (CONFIG_DELETE_GUARDS[group] && CONFIG_DELETE_GUARDS[group].label) || group;
        const e = apiError(`Cannot delete this ${label} while ${blocker} references it`, 'CONFLICT', 409);
        return res.status(e.status).json(e.body);
      }
      await conn.query(`DELETE FROM \`${t(table)}\` WHERE id = ? AND scenario_id = ?`, [rowId, scenarioId]);
      await conn.commit();
      res.json(apiOk({ id: rowId, deleted: true }));
    } catch (err) {
      await safeRollback(conn);
      logger.error({ err, table, rowId }, 'capacity local catalogue delete failed');
      childDbError(res);
    } finally {
      if (conn) conn.release();
    }
  };
}

// ── Versioning + clone (PR-E) ────────────────────────────────────────────────

// The scenario-scoped rows a version snapshot freezes and a clone deep-copies
// (WHERE scenario_id = ?), parent-before-child. cap_versions is EXCLUDED (a
// version never nests another; a clone starts fresh history). The catalogue
// tables appear so a scenario's LOCAL rows (scenario-local additions, §2.2)
// travel with the scenario; the referenced GLOBAL catalogue rows are added ONLY
// to a version freeze / export by the closure step (buildScenarioSnapshotDoc),
// never to a live clone (a clone keeps referencing the live global catalogues).
// cap_field_defs is global-only (definitions are global config; a scenario has
// no field-def rows — custom VALUES live in each row's metadata) and never
// appears here. Each entry's `key` is the snapshot document's per-table key.
const SNAPSHOT_TABLES = Object.freeze([
  { key: 'hardware_specs', table: TABLES.CAP_HARDWARE_SPECS },
  { key: 'disk_combos', table: TABLES.CAP_DISK_COMBOS },
  { key: 'teams', table: TABLES.CAP_TEAMS },
  { key: 'vm_profiles', table: TABLES.CAP_VM_PROFILES },
  { key: 'settings', table: TABLES.CAP_SETTINGS },
  { key: 'rules', table: TABLES.CAP_RULES },
  { key: 'sites', table: TABLES.CAP_SITES },
  { key: 'hypervisors', table: TABLES.CAP_HYPERVISORS },
  { key: 'databases', table: TABLES.CAP_DATABASES },
  { key: 'vms', table: TABLES.CAP_VMS },
  { key: 'db_instances', table: TABLES.CAP_DB_INSTANCES },
  { key: 'custom_groups', table: TABLES.CAP_CUSTOM_GROUPS },
  { key: 'custom_group_members', table: TABLES.CAP_CUSTOM_GROUP_MEMBERS },
  { key: 'waivers', table: TABLES.CAP_WAIVERS },
]);

// The catalogue snapshot keys (a subset of SNAPSHOT_TABLES) whose GLOBAL rows are
// pulled into a version freeze / export as the referenced closure (§17.4).
const CATALOGUE_CLOSURE = Object.freeze([
  { key: 'hardware_specs', table: TABLES.CAP_HARDWARE_SPECS, refs: [{ key: 'hypervisors', col: 'spec_id' }] },
  {
    key: 'vm_profiles', table: TABLES.CAP_VM_PROFILES,
    refs: [{ key: 'vms', col: 'sizing_profile_id' }, { key: 'databases', col: 'profile_id' }],
  },
  {
    key: 'disk_combos', table: TABLES.CAP_DISK_COMBOS,
    refs: [{ key: 'vms', col: 'disk_combo_id' }, { key: 'databases', col: 'disk_combo_id' }],
    // A VM profile's allowed_disk_combos is a JSON list of disk-combo ids — a
    // combo referenced ONLY there (permitted but not yet chosen by any VM/db)
    // must still travel in the closure so an export→import round-trip can remap
    // the allow-list (io.js P2). vm_profiles is closed BEFORE disk_combos here,
    // so tables.vm_profiles already holds the pulled global profiles when this
    // runs.
    jsonListRefs: [{ key: 'vm_profiles', col: 'allowed_disk_combos' }],
  },
  {
    key: 'teams', table: TABLES.CAP_TEAMS,
    refs: [{ key: 'vms', col: 'team_id' }, { key: 'databases', col: 'team_id' }, { key: 'custom_groups', col: 'team_id' }],
  },
]);

// Snapshot document schema revision — lets a future migration detect an old
// snapshot shape rather than mis-parsing it.
const SNAPSHOT_SCHEMA_REV = 1;

// Reject a pathological snapshot document (a corrupt or adversarially large
// scenario). At the design scale ceiling (§8: ≤ ~3 DC / 60 hypervisors / 90
// VMs / 100 DB instances) the JSON is a few hundred KB; 4 MB is a generous
// backstop that still fits the JSON column and keeps one row bounded.
const SNAPSHOT_MAX_BYTES = 4 * 1024 * 1024;

// Per-snapshot-key FK-by-convention columns whose value is another
// scenario-scoped row's id and MUST be remapped to the clone's minted ids.
// object_set_key (waivers) is NOT a plain id column — it is a '|'-joined sorted
// id set and is remapped by remapObjectSetKey below, not listed here.
const CLONE_FK_COLUMNS = Object.freeze({
  hypervisors: ['site_id', 'spec_id'],
  databases: ['profile_id', 'disk_combo_id', 'team_id'],
  vms: ['hypervisor_id', 'site_id', 'sizing_profile_id', 'disk_combo_id', 'team_id', 'database_id'],
  db_instances: ['vm_id', 'database_id'],
  custom_groups: ['team_id'],
  custom_group_members: ['group_id', 'member_vm_id', 'member_instance_id'],
  rules: ['overrides_rule_id', 'custom_group_id'],
  waivers: ['rule_id'],
});

// Columns never carried on a scenario clone: id + scenario_id are minted /
// rebound; created_at / updated_at fall to their DB defaults.
const CLONE_SKIP_COLUMNS = new Set(['id', 'scenario_id', 'created_at', 'updated_at']);

// A JSON column comes back from the driver as a string (re-insertable verbatim)
// or, when the mapper parsed it, as an object — re-stringify an object so the
// JSON column receives text, never "[object Object]".
function jsonReinsertable(val) {
  return val !== null && typeof val === 'object' ? JSON.stringify(val) : val;
}

/**
 * Remap a vm_profiles.allowed_disk_combos JSON id-list through the clone's
 * COMBOS-ONLY id-map, mirroring the import-side remap (io.js P2). Each id is
 * either a scenario-local disk-combo (present in comboIdMap → its new id) or a
 * live global disk-combo (absent from comboIdMap → kept as-is). A non-array /
 * unparseable value passes through verbatim (jsonReinsertable). No "unresolved"
 * error path: unlike import, every id here is either scenario-local (remapped)
 * or a still-live global row (kept).
 *
 * `comboIdMap` MUST be the disk_combos-only submap, never the ALL-tables idMap —
 * same reasoning as `remapDcRefs` below (fmb-1566's deferred half, D4 found and
 * fixed the identical shape on dc_refs first): an allow-list entry only ever
 * names a disk combo, so remapping through every cloned table's id would
 * silently rewrite a dangling entry that happens to equal some OTHER table's
 * source id (a site, a vm, …) to that row's clone id — inventing a resolution
 * the source never had.
 *
 * ONLY a non-empty STRING element is looked up, and only a resolving one is
 * rewritten (`typeof rawId === 'string' && rawId`, no `String()` coercion): a
 * `String()` coercion would fold a single-element nested array `[comboId]` down
 * to the bare id text and let it resolve through the map, minting a live
 * reference out of a value the allow-list check never reads as one. Every
 * non-string element — a nested array, an object, a number, null — passes
 * through UNTOUCHED, so a malformed entry survives the clone byte-for-byte.
 */
function remapAllowedDiskCombos(val, comboIdMap) {
  if (val == null) return val;
  let list = val;
  if (typeof list === 'string') { try { list = JSON.parse(list); } catch { return jsonReinsertable(val); } }
  if (!Array.isArray(list)) return jsonReinsertable(val);
  const remapped = list.map((rawId) => (
    typeof rawId === 'string' && rawId ? (comboIdMap.get(rawId) || rawId) : rawId
  ));
  return JSON.stringify(remapped);
}

/**
 * Remap a cap_databases.dc_refs JSON id-list through the clone's SITE id-map.
 * dc_refs is a JSON list of cap_sites ids, so — like allowed_disk_combos — it is
 * NOT in CLONE_FK_COLUMNS (that is the scalar-FK list) and would otherwise carry
 * the SOURCE site ids straight into the clone, where the sites hold freshly
 * minted ids: every restriction would name a site that no longer exists and
 * admit no data centre.
 *
 * `siteIdMap` MUST be the sites-only submap, never the ALL-tables idMap: a
 * dc_refs entry only ever names a site (dcRefEntries / dcRefsAdmitsSite never
 * read it as anything else), so remapping through every cloned table's id would
 * silently rewrite a dangling entry that happens to equal some OTHER table's
 * source id (a hypervisor, a vm, …) to that row's clone id — inventing a
 * resolution the source never had.
 *
 * ONLY a non-empty STRING element is looked up, and only a resolving one is
 * rewritten (`typeof rawId === 'string' && rawId`, no `String()` coercion):
 * a live entry (present in siteIdMap) is rewritten to the clone's site id; a
 * dangling entry (a case-variant that write-time canonicalisation never
 * resolved) is kept verbatim, so the clone preserves the source's own
 * brokenness rather than inventing a resolution, and the scenario health check
 * reports it exactly as it does in the source. Every non-string element —
 * a nested array, an object, a number, null — passes through UNTOUCHED: a
 * `String()` coercion would fold a single-element nested array `[siteId]` down
 * to the bare id text and let it resolve through the map, minting a live
 * reference out of a value `dcRefEntries` never reads as one. A non-array /
 * unparseable value passes through verbatim (jsonReinsertable).
 */
function remapDcRefs(val, siteIdMap) {
  if (val == null) return val;
  let list = val;
  if (typeof list === 'string') { try { list = JSON.parse(list); } catch { return jsonReinsertable(val); } }
  if (!Array.isArray(list)) return jsonReinsertable(val);
  const remapped = list.map((rawId) => (
    typeof rawId === 'string' && rawId ? (siteIdMap.get(rawId) || rawId) : rawId
  ));
  return JSON.stringify(remapped);
}

/**
 * Remap the `site_id` key inside a cap_rules.params JSON value through the
 * clone's SITE id-map, at whatever depth it appears (item 5, deferred by D4:
 * a `keep-in-one-site` rule's `params.site_id` — the pinned data centre the
 * evaluator reads at `evaluator.js`'s `params.site_id`, see the doc-comment
 * there — was copied verbatim by the clone, so a cloned rule went on pinning
 * the SOURCE scenario's site; census-invisible because it is nested JSON, and
 * `site-references.js`'s own top note documents this same reference as
 * outside the site-DELETE sweep for the identical reason).
 *
 * DELIBERATELY NARROW: this walks for the KEY `site_id` only, not every
 * string value in `params`. A rule's params carries filter thresholds and
 * other rule-shape data that are strings and are not site references —
 * walking every string risks rewriting one of those on the (astronomically
 * unlikely, but not provably impossible) chance it collides with a real site
 * id. `site_id` is the ONLY key any rule type's evaluator reads as one today
 * (see the module doc above this function); if a second key needs the same
 * treatment, that is a reason to promote this walk to its own unit — per the
 * D5 brief, not a reason to widen the key list here.
 *
 * ONLY a non-empty STRING value under that key is looked up, and only a
 * resolving one is rewritten, same as `remapDcRefs` / `remapAllowedDiskCombos`:
 * an id naming no site in `siteIdMap` — or any other type this key happens to
 * hold, from a malformed row — survives verbatim. A non-object / unparseable
 * `params` passes through verbatim (jsonReinsertable).
 */
function remapRuleParamsSiteId(val, siteIdMap) {
  if (val == null) return val;
  let obj = val;
  if (typeof obj === 'string') { try { obj = JSON.parse(obj); } catch { return jsonReinsertable(val); } }
  if (obj === null || typeof obj !== 'object') return jsonReinsertable(val);
  const walk = (node) => {
    if (Array.isArray(node)) return node.map(walk);
    if (node !== null && typeof node === 'object') {
      const out = {};
      for (const [k, v] of Object.entries(node)) {
        out[k] = (k === 'site_id' && typeof v === 'string' && v) ? (siteIdMap.get(v) || v) : walk(v);
      }
      return out;
    }
    return node;
  };
  return JSON.stringify(walk(obj));
}

/**
 * Read every scenario-scoped row (the 11 SNAPSHOT_TABLES) for `scenarioId` on
 * `conn`, keyed by the snapshot document key. Used to build a version snapshot
 * (freeze the live state) and to clone the live working state.
 */
async function readScenarioSnapshotTables(conn, scenarioId) {
  const tables = {};
  for (const { key, table } of SNAPSHOT_TABLES) {
    tables[key] = await conn.query(
      `SELECT * FROM \`${t(table)}\` WHERE scenario_id = ?`, [scenarioId],
    );
  }
  return tables;
}

/**
 * Build the canonical scenario snapshot document — `{ schema_rev, tables }` —
 * from a scenario's live scenario-scoped rows on `conn`. This is the single
 * shared builder for BOTH the PR-E version freeze (versions.js POST) and the
 * PR-F export projection (io.js GET /export): the two paths must produce the
 * identical document shape so an export round-trips through the same reader a
 * version snapshot does. Both keys must always be present — consumers
 * (`isReadableSnapshotDoc`, `fingerprintScenarioRows`'s canonical-JSON
 * comparison) read the object structurally, so field order carries no
 * meaning.
 */
async function buildScenarioSnapshotDoc(conn, scenarioId) {
  const tables = await readScenarioSnapshotTables(conn, scenarioId);
  await addCatalogueClosure(conn, tables);
  await addGlobalConfigLayer(conn, tables);
  return { schema_rev: SNAPSHOT_SCHEMA_REV, tables };
}

/**
 * §17.4 catalogue closure: pull the GLOBAL catalogue rows a scenario REFERENCES
 * (scenario_id IS NULL) into the snapshot so a frozen version / export is
 * self-contained and immune to later global edits. Mutates `tables` in place,
 * merging each referenced global row into its catalogue key alongside any
 * scenario-local rows already read. Deterministic (referenced ids sorted; a row
 * already present as a local row is not duplicated). A live clone does NOT call
 * this — it keeps referencing the live global catalogues.
 */
async function addCatalogueClosure(conn, tables) {
  for (const { key, table, refs, jsonListRefs } of CATALOGUE_CLOSURE) {
    const present = new Set((tables[key] || []).map((r) => String(r.id)));
    const wanted = new Set();
    for (const { key: srcKey, col } of refs) {
      for (const row of tables[srcKey] || []) {
        const v = row[col];
        if (v != null && !present.has(String(v))) wanted.add(String(v));
      }
    }
    // JSON-list references (vm_profiles.allowed_disk_combos): parse the list and
    // pull each referenced id the same way as a scalar FK column.
    for (const { key: srcKey, col } of jsonListRefs || []) {
      for (const row of tables[srcKey] || []) {
        let list = row[col];
        if (typeof list === 'string') { try { list = JSON.parse(list); } catch { list = null; } }
        if (Array.isArray(list)) {
          for (const v of list) if (v != null && !present.has(String(v))) wanted.add(String(v));
        }
      }
    }
    if (!wanted.size) continue;
    const ids = [...wanted].sort();
    const placeholders = ids.map(() => '?').join(', ');
    const globalRows = await conn.query(
      `SELECT * FROM \`${t(table)}\` WHERE scenario_id IS NULL AND id IN (${placeholders})`,
      ids,
    );
    // Sort by id for a deterministic closure order, then append to the key.
    globalRows.sort((a, b) => String(a.id).localeCompare(String(b.id)));
    tables[key] = [...(tables[key] || []), ...globalRows];
  }
}

/**
 * §2 / §9 / §13 effective-global layer: a scenario's EVALUATED state is not just
 * its own rows — it also sees the GLOBAL rule template (every scenario_id IS NULL
 * rule; violations.js reads `scenario_id IS NULL OR = ?` and applies them all)
 * and, when it has no local settings override, the GLOBAL settings singleton
 * (violations.js falls back via `ORDER BY scenario_id IS NULL LIMIT 1`). Unlike
 * addCatalogueClosure (FK-reached: only referenced catalogue rows), this pulls
 * ALL global rules + the global settings row unconditionally, because the
 * evaluator applies rules by visibility (not by FK) and the settings fallback is
 * a whole-row default. Without this a frozen version / export would DRIFT the
 * moment someone edits the global rule template or the global settings — the
 * freeze would no longer reproduce the evaluation it captured (spec §2 "version
 * snapshots are the only copy mechanism"). Mutates `tables` in place, merging
 * into the `rules` / `settings` keys and de-duplicating by id against any rows
 * already read (a scenario-local override row already present is not doubled).
 * A live clone does NOT call this (it references the live global layer).
 */
async function addGlobalConfigLayer(conn, tables) {
  const rulePresent = new Set((tables.rules || []).map((r) => String(r.id)));
  const globalRules = (await conn.query(
    `SELECT * FROM \`${t(TABLES.CAP_RULES)}\` WHERE scenario_id IS NULL`,
  )).filter((r) => !rulePresent.has(String(r.id)));
  if (globalRules.length) {
    globalRules.sort((a, b) => String(a.id).localeCompare(String(b.id)));
    tables.rules = [...(tables.rules || []), ...globalRules];
  }

  const settingsPresent = new Set((tables.settings || []).map((r) => String(r.id)));
  const globalSettings = (await conn.query(
    `SELECT * FROM \`${t(TABLES.CAP_SETTINGS)}\` WHERE scenario_id IS NULL`,
  )).filter((r) => !settingsPresent.has(String(r.id)));
  if (globalSettings.length) {
    tables.settings = [...(tables.settings || []), ...globalSettings];
  }
}

/**
 * Read the GLOBAL catalogue layer (`scenario_id IS NULL`) for the config export
 * (io.js / config.js GET /config/export). The reference model means the global
 * config IS the catalogue layer (hardware_specs, disk_combos, teams, vm_profiles,
 * field_defs, settings, rules). Reuses the SNAPSHOT_TABLES key names + adds the
 * global-only field_defs so a config export carries the full global layer. `db`
 * is any query-capable handle (pool.ro or a connection). Global config IMPORT is
 * out of scope (export only, §19).
 */
async function readConfigTemplateTables(db) {
  const tables = {};
  const configTables = [
    { key: 'hardware_specs', table: TABLES.CAP_HARDWARE_SPECS },
    { key: 'disk_combos', table: TABLES.CAP_DISK_COMBOS },
    { key: 'teams', table: TABLES.CAP_TEAMS },
    { key: 'vm_profiles', table: TABLES.CAP_VM_PROFILES },
    { key: 'field_defs', table: TABLES.CAP_FIELD_DEFS },
    { key: 'settings', table: TABLES.CAP_SETTINGS },
    { key: 'rules', table: TABLES.CAP_RULES },
  ];
  for (const { key, table } of configTables) {
    tables[key] = await db.query(
      `SELECT * FROM \`${t(table)}\` WHERE scenario_id IS NULL`,
    );
  }
  // Bundles + items are pure global config (no scenario_id column) — the whole
  // table IS the template. Parent-before-child so a config-export workbook keeps
  // the bundle header ahead of its items (§17.4 config export now covers the
  // global catalogues, incl. bundles).
  tables.bundles = await db.query(`SELECT * FROM \`${t(TABLES.CAP_BUNDLES)}\``);
  tables.bundle_items = await db.query(`SELECT * FROM \`${t(TABLES.CAP_BUNDLE_ITEMS)}\``);
  return tables;
}

/**
 * Build the global-config export document — `{ schema_rev, tables }` — from the
 * template layer. Same shape as a scenario snapshot, restricted to the tables
 * that have a template layer (import of the global layer is deliberately out of
 * scope — export only).
 */
async function buildConfigTemplateDoc(db) {
  const tables = await readConfigTemplateTables(db);
  return { schema_rev: SNAPSHOT_SCHEMA_REV, tables };
}

// The seeded default of the global cap_settings singleton — the DDL defaults
// (table-ddls.js) plus the explicit formula-constant seed (db.js §9.2/§9.3). A
// global settings row whose user-meaningful columns still equal ALL of these is
// the untouched seed; ANY divergence is operator work the first-instance import
// must not clobber. id / scenario_id / timestamps are server-managed → excluded.
const SETTINGS_SEED_DEFAULTS = Object.freeze({
  mem_cpu_ratio: 20,
  sga_factor: 0.982,
  sga_divisor: 2,
  sga_subtract: 2,
  standby_sga_default_gb: 32,
  util_amber_pct: 80,
  util_red_pct: 90,
  overcommit_default_enabled: false,
  layer_defaults: null,
});

// A nullable JSON column counts as "still seeded" when it is null / empty string
// / the literal `null` / an empty object; real content is operator data.
function layerDefaultsIsSeeded(raw) {
  if (raw == null) return true;
  let obj = raw;
  if (typeof raw === 'string') {
    const s = raw.trim();
    if (s === '' || s === 'null') return true;
    try { obj = JSON.parse(s); } catch { return false; }
  }
  if (obj == null) return true;
  if (typeof obj === 'object' && !Array.isArray(obj)) return Object.keys(obj).length === 0;
  return false;
}

// True when a global settings row diverges from the seeded default in ANY
// user-meaningful column (operator work the import must not overwrite).
function settingsRowIsEdited(row) {
  if (!row) return false;
  for (const [col, def] of Object.entries(SETTINGS_SEED_DEFAULTS)) {
    if (col === 'layer_defaults') {
      if (!layerDefaultsIsSeeded(row[col])) return true;
    } else if (col === 'overcommit_default_enabled') {
      const v = row[col];
      const asBool = v === true || v === 1 || v === '1';
      if (asBool !== def) return true;
    } else if (Number(row[col]) !== def) {
      return true;
    }
  }
  return false;
}

// Stable (sorted-key) JSON so a rule params comparison ignores key order and the
// mariadb driver's native-object-vs-serialized-string ambiguity.
function stableStringify(value) {
  if (value === null || typeof value !== 'object') return JSON.stringify(value ?? null);
  if (Array.isArray(value)) return `[${value.map(stableStringify).join(',')}]`;
  return `{${Object.keys(value).sort().map((k) => `${JSON.stringify(k)}:${stableStringify(value[k])}`).join(',')}}`;
}
function canonicalRuleParams(raw) {
  let obj = raw;
  if (raw == null) obj = {};
  else if (typeof raw === 'string') {
    const s = raw.trim();
    if (s === '') obj = {};
    else { try { obj = JSON.parse(s); } catch { return `raw:${raw}`; } }
  }
  return stableStringify(obj);
}
/**
 * A rule row's template-relevant signature: the columns an operator can edit
 * through the rules mount, canonicalised so two representations of one value
 * compare equal.
 *
 * THE COLUMN LIST IS THE MOUNT'S OWN EDITABLE SET, not a second one written
 * beside it. It used to name six columns by hand — type, name, level, group_by,
 * params, severity — and the two it left out are the two most likely edits an
 * operator makes: turning a default rule OFF (`enabled`) and narrowing its
 * `filters`. This signature is what a gate uses to decide "is the seeded rule
 * template still untouched", and the write that gate authorises DELETEs every
 * global rule and re-mints them. So the gate that exists to guarantee the import
 * can never clobber operator work had a hole exactly the width of the work an
 * operator is likeliest to have done: a rule they had disabled signed identical
 * to the seed, the import read "untouched", and it was deleted and re-minted
 * enabled. Derived from `CONFIG_MOUNTS.rules.cols`, the gate is as wide as the
 * write it authorises, and stays that way when a column is added.
 *
 * The canonicalisers come from the DDL for the same reason: a JSON column
 * arrives as an object or as text depending on the driver, and a BOOLEAN as
 * `true` / `1` / `'1'`, so comparing raw values would report an edit where
 * nothing moved.
 */
const RULE_TEMPLATE_SIGNATURE_COLUMNS = Object.freeze(CONFIG_MOUNTS.rules.cols.map((column) => {
  const declared = ddlFragmentFor(TABLES.CAP_RULES, column);
  const type = declared ? parseColumnMeta(declared).type : null;
  return Object.freeze({
    column,
    json: CONFIG_MOUNTS.rules.json.includes(column),
    boolean: type === 'tinyint',
  });
}));

function ruleTemplateSignature(row) {
  return JSON.stringify(RULE_TEMPLATE_SIGNATURE_COLUMNS.map(({ column, json, boolean }) => {
    const value = row[column];
    if (json) return canonicalRuleParams(value);
    if (boolean) return value === true || value === 1 || value === '1';
    return value ?? null;
  }));
}
// True when the global rule set is NOT the untouched default template — a
// different row count, OR the same count with any semantically different row (an
// in-place edit a bare COUNT would miss).
function rulesDifferFromTemplate(ruleRows) {
  if (!Array.isArray(ruleRows) || ruleRows.length !== DEFAULT_RULE_TEMPLATE.length) return true;
  const actual = ruleRows.map(ruleTemplateSignature).sort();
  const expected = DEFAULT_RULE_TEMPLATE.map(ruleTemplateSignature).sort();
  return actual.some((sig, i) => sig !== expected[i]);
}

/**
 * "Is the entire global config empty?" gate for the first-instance config import
 * (spec §3.3 A2 / §3.5). The import is only offered / committed when EVERY
 * user-content catalogue is empty AND the two seeded singletons (settings row +
 * rule template) are still their untouched defaults. Seeded rows are excluded so
 * a fresh instance qualifies, but — unlike a bare row COUNT — an EDITED seed
 * counts as non-empty so the import cannot clobber operator work:
 *   - no-seed catalogues (hardware_specs / disk_combos / teams / vm_profiles /
 *     field_defs / bundles / bundle_items): ANY row → non-empty.
 *   - cap_settings: the seeded singleton stays empty; a row differing from the
 *     seed defaults in any user-meaningful column (or a second global row) →
 *     non-empty (a bare "never count settings" rule missed an edited row).
 *   - cap_rules: the seeded DEFAULT_RULE_TEMPLATE stays empty; a semantically
 *     changed set — added, removed, OR an in-place edit at the same count →
 *     non-empty (a bare "count > template length" rule missed same-count edits).
 * `db` is any query-capable handle (pool.ro or a transaction connection — the
 * commit path re-runs this under its own tx so the gate cannot be raced).
 * Returns true only when the config is empty-equivalent.
 */
async function isGlobalConfigEmpty(db) {
  const rows = await db.query(
    `SELECT
       (SELECT COUNT(*) FROM \`${t(TABLES.CAP_HARDWARE_SPECS)}\` WHERE scenario_id IS NULL) AS hardware_specs,
       (SELECT COUNT(*) FROM \`${t(TABLES.CAP_DISK_COMBOS)}\` WHERE scenario_id IS NULL) AS disk_combos,
       (SELECT COUNT(*) FROM \`${t(TABLES.CAP_TEAMS)}\` WHERE scenario_id IS NULL) AS teams,
       (SELECT COUNT(*) FROM \`${t(TABLES.CAP_VM_PROFILES)}\` WHERE scenario_id IS NULL) AS vm_profiles,
       (SELECT COUNT(*) FROM \`${t(TABLES.CAP_FIELD_DEFS)}\` WHERE scenario_id IS NULL) AS field_defs,
       (SELECT COUNT(*) FROM \`${t(TABLES.CAP_BUNDLES)}\`) AS bundles,
       (SELECT COUNT(*) FROM \`${t(TABLES.CAP_BUNDLE_ITEMS)}\`) AS bundle_items`,
  );
  const r = rows[0] || {};
  const userContent = ['hardware_specs', 'disk_combos', 'teams', 'vm_profiles', 'field_defs', 'bundles', 'bundle_items'];
  if (userContent.some((k) => Number(r[k]) > 0)) return false;

  // Settings singleton: edited (or duplicated) → operator work → non-empty.
  const settingsRows = await db.query(
    `SELECT mem_cpu_ratio, sga_factor, sga_divisor, sga_subtract, standby_sga_default_gb,
            util_amber_pct, util_red_pct, overcommit_default_enabled, layer_defaults
       FROM \`${t(TABLES.CAP_SETTINGS)}\` WHERE scenario_id IS NULL`,
  );
  if (settingsRows.length > 1) return false;
  if (settingsRows.some(settingsRowIsEdited)) return false;

  // Rule template: any semantic divergence (incl. a same-count in-place edit).
  // The SELECT names the SAME columns the signature compares, derived from the
  // one list, because a semantic widened in JavaScript and not in SQL is no
  // widening at all: a column the statement never fetched reads as `undefined`
  // on every row and signs identical for all of them.
  const ruleRows = await db.query(
    `SELECT ${RULE_TEMPLATE_SIGNATURE_COLUMNS.map(({ column }) => `\`${column}\``).join(', ')}
       FROM \`${t(TABLES.CAP_RULES)}\` WHERE scenario_id IS NULL`,
  );
  if (rulesDifferFromTemplate(ruleRows)) return false;

  // Scenario references to the GLOBAL rule template: even when the global config
  // is otherwise empty, the seeded rules persist and a scenario override
  // (cap_rules.overrides_rule_id) or an Exception (cap_waivers.rule_id) may point
  // at them. The import CLEARS + REMINTS the global rules (new ids), so any such
  // reference would dangle — treat it as non-empty (mirrors the global-rule delete
  // guard, CONFIG_DELETE_GUARDS.rules). Catalogue references need no analog: the
  // count check above already blocks on any global catalogue row, so an empty
  // catalogue set has nothing a scenario could reference.
  const overrideRef = await db.query(
    `SELECT 1 AS ref FROM \`${t(TABLES.CAP_RULES)}\` WHERE scenario_id IS NOT NULL AND overrides_rule_id IS NOT NULL LIMIT 1`,
  );
  if (overrideRef.length) return false;
  const waiverRef = await db.query(
    `SELECT 1 AS ref FROM \`${t(TABLES.CAP_WAIVERS)}\` w
       JOIN \`${t(TABLES.CAP_RULES)}\` r ON w.rule_id = r.id
      WHERE r.scenario_id IS NULL LIMIT 1`,
  );
  if (waiverRef.length) return false;

  return true;
}

/**
 * Serialize a GLOBAL-config write against the first-instance config import's
 * gate + clear-then-insert. Both the import commit AND every ordinary global-config
 * writer (config.js mounts, bundles routes) take this one row-lock inside their
 * write transaction BEFORE mutating, so an ordinary write cannot land a global row
 * between the import's empty-gate check and its clear (which would silently wipe
 * it). The cap_settings singleton is the sentinel — always seeded, so the lock
 * always hits a real row; it is never itself the contended write target.
 * MUST be called inside an open transaction (a FOR UPDATE lock in autocommit mode
 * releases immediately). Lock ordering: cap_settings is acquired FIRST in every
 * path that takes it, so it cannot form a cycle with the per-row catalogue locks.
 */
async function lockGlobalConfig(conn) {
  await conn.query(`SELECT id FROM \`${t(TABLES.CAP_SETTINGS)}\` FOR UPDATE`);
}

/**
 * Remap a waiver's object_set_key — a deterministic sorted '|'-join of the
 * violation's subject ids (evaluator.js objectSetKey) — through the clone's id
 * map, then RE-SORT. Re-sorting is required: the clone mints fresh ids that sort
 * differently, and the evaluator rebuilds the key by sorting the NEW ids, so the
 * cloned waiver must carry the same sorted-new-id key to re-match. An id absent
 * from the map (defensive: a well-formed waiver only references live subjects)
 * is left as-is.
 */
function remapObjectSetKey(key, idMap) {
  if (typeof key !== 'string' || key === '') return key;
  return key.split('|').map((seg) => idMap.get(seg) || seg).sort().join('|');
}

/**
 * Deep-copy `tablesData` (either live rows or a frozen snapshot's rows) into
 * `newScenarioId` on `conn`, minting brand-new ids for every row and remapping
 * every FK-by-convention column + waiver object_set_key to those new ids. Runs
 * inside the caller's transaction. Column names come from each row's own keys
 * (DB-controlled via SELECT * / a server-built snapshot, never client input) and
 * are backtick-quoted. Returns the old→new id map (seeded with the source
 * scenario id so a scenario-level waiver subject remaps too).
 */
async function deepCopyScenarioRows(conn, tablesData, newScenarioId, sourceScenarioId) {
  // A frozen snapshot carries the GLOBAL layer too (addGlobalConfigLayer /
  // addCatalogueClosure pull scenario_id IS NULL rows for read/export/evaluate
  // fidelity). A CLONE reconstitutes only the SCENARIO-LOCAL layer and, like a
  // live scenario (reference model, spec §2), re-references the LIVE global
  // catalogues / rules / settings — so those global rows must NOT be reborn as
  // scenario-local copies (which would double-apply every global rule and clutter
  // the catalogue with orphan duplicates). A scenario-local FK that pointed at a
  // skipped global row keeps its original (live) global id via the idMap fallback
  // below, so the reference still resolves. Discriminator: a scenario-scoped row
  // always carries a non-null scenario_id; only the injected global-layer rows
  // are null. (Live clone: readScenarioSnapshotTables never adds the global layer,
  // so nothing is skipped there — its refs stay live, unchanged.)
  const isGlobalLayerRow = (row) => row.scenario_id == null;
  // Phase 1 — mint a new id for every SCENARIO-LOCAL row (and the scenario id
  // itself) up front, so a forward reference (e.g. a db_instance's vm_id) resolves
  // regardless of table order. Global-layer rows are intentionally left out of the
  // map so a FK pointing at one falls through to its live global id.
  //
  // `siteIdMap` / `comboIdMap` are submaps of `idMap` carrying only ONE table's
  // ids each: a dc_refs entry only ever names a site, and an allowed_disk_combos
  // entry only ever names a disk combo (never a hypervisor, a vm, …), so
  // `remapDcRefs` / `remapAllowedDiskCombos` must resolve against that one table
  // alone — resolving against the ALL-tables map would let a dangling entry that
  // happens to equal some OTHER cloned table's source id get silently rewritten
  // to that row's clone id (D4's finding on dc_refs; the same shape was still
  // live on allowed_disk_combos, fmb-1566's deferred half).
  const idMap = new Map();
  const siteIdMap = new Map();
  const comboIdMap = new Map();
  if (sourceScenarioId != null) idMap.set(String(sourceScenarioId), newScenarioId);
  for (const { key } of SNAPSHOT_TABLES) {
    for (const row of tablesData[key] || []) {
      if (isGlobalLayerRow(row)) continue;
      const newId = uuidv4();
      idMap.set(String(row.id), newId);
      if (key === 'sites') siteIdMap.set(String(row.id), newId);
      if (key === 'disk_combos') comboIdMap.set(String(row.id), newId);
    }
  }
  // Phase 2 — insert each SCENARIO-LOCAL row with its remapped id, the new
  // scenario_id, and every FK column / object_set_key remapped.
  for (const { key, table } of SNAPSHOT_TABLES) {
    const fkCols = CLONE_FK_COLUMNS[key] || [];
    for (const row of tablesData[key] || []) {
      if (isGlobalLayerRow(row)) continue;
      const cols = [];
      const placeholders = [];
      const values = [];
      for (const [col, val] of Object.entries(row)) {
        if (CLONE_SKIP_COLUMNS.has(col)) continue;
        let out;
        if (fkCols.includes(col)) {
          out = val == null ? null : (idMap.get(String(val)) || val);
        } else if (col === 'object_set_key') {
          out = remapObjectSetKey(val, idMap);
        } else if (key === 'vm_profiles' && col === 'allowed_disk_combos') {
          // A scenario-local VM profile's allow-list is a JSON list of disk-combo
          // ids — remap it (CLONE_FK_COLUMNS has no vm_profiles entry, so this
          // JSON-list column would otherwise carry SOURCE ids into the clone).
          // Combos-only map (see the Phase 1 note above) — never the ALL-tables idMap.
          out = remapAllowedDiskCombos(val, comboIdMap);
        } else if (key === 'databases' && col === 'dc_refs') {
          // A database's DC restriction is a JSON list of cap_sites ids — remap it
          // for the same reason (a scalar-FK-list omission would leave it naming
          // the source's now-reminted sites, admitting no data centre). Sites-only
          // map (see the Phase 1 note above) — never the ALL-tables idMap.
          out = remapDcRefs(val, siteIdMap);
        } else if (key === 'rules' && col === 'params') {
          // A keep-in-one-site rule's params carries a nested site_id the
          // evaluator reads directly — remap it the same way (item 5, D5's
          // deferred half of D4). Sites-only map, same reasoning as dc_refs.
          out = remapRuleParamsSiteId(val, siteIdMap);
        } else {
          out = jsonReinsertable(val);
        }
        cols.push(`\`${col}\``);
        placeholders.push('?');
        values.push(out);
      }
      cols.push('`id`', '`scenario_id`');
      placeholders.push('?', '?');
      values.push(idMap.get(String(row.id)), newScenarioId);
      await conn.query(
        `INSERT INTO \`${t(table)}\` (${cols.join(', ')}) VALUES (${placeholders.join(', ')})`,
        values,
      );
    }
  }
  // A copy must not be born contradicting itself. The rows are copied verbatim
  // (with their references remapped), so a SOURCE written before the cache was
  // derived — or a frozen snapshot taken then — hands its stale `site_id`
  // straight into the new scenario, where the health check reports it as a
  // fault of the copy. Here, at the end of the caller's own transaction, is the
  // one place both clone paths pass through.
  await syncVmSiteCache(conn, newScenarioId);
  return idMap;
}

// ── In-place restore (version → same scenario) ───────────────────────────────

// Columns never carried on a RESTORE replay. Unlike a clone, a restore keeps
// each frozen row's OWN id: the rows it replaces are deleted in the same
// transaction, so the ids are free — and keeping them means every
// FK-by-convention column and every waiver object_set_key still resolves with no
// remap at all. scenario_id is dropped from the row and re-bound to the target
// scenario explicitly (a snapshot row can never drag another scenario's id in).
// created_at / updated_at fall back to their DB defaults: the driver hands
// timestamps back as Date objects, which JSON.stringify freezes as ISO-8601 text
// ("…T…Z") — not a portable DATETIME literal, and its UTC suffix would shift the
// value against a server-local column. The frozen snapshot stays the record of
// the original times.
const RESTORE_SKIP_COLUMNS = new Set(['scenario_id', 'created_at', 'updated_at']);

// A column name that may be interpolated into an INSERT's backtick-quoted column
// list. Snapshot keys are DB-controlled (SELECT * of a server-built freeze), but
// the restore is destructive and the document is long-lived JSON, so the replay
// re-checks the shape rather than trusting provenance.
const SAFE_COLUMN_NAME = /^[A-Za-z_][A-Za-z0-9_]*$/;

/**
 * Pre-flight a snapshot's `tables` document for an IN-PLACE restore. Returns
 * null when the document is replayable, else a human-readable reason.
 *
 * SAFETY: this runs BEFORE the destructive delete. A malformed snapshot must
 * fail with the scenario untouched — a restore that emptied the scenario and
 * then choked on row 3 would be indistinguishable from data loss to the
 * operator, even though the transaction rolls it back.
 */
function findSnapshotRestoreBlocker(tablesData) {
  if (!tablesData || typeof tablesData !== 'object' || Array.isArray(tablesData)) {
    return 'the snapshot carries no tables document';
  }
  // SAFETY: the restore DELETEs every scenario-scoped table and re-inserts only
  // what the document carries, so a MISSING key silently erases that table's
  // live rows — the operator never saw them represented in the version they
  // restored. An absent key cannot be waved through as "that table was empty at
  // freeze time" either: SNAPSHOT_TABLES has gained keys since schema_rev 1 was
  // minted WITHOUT a rev bump, so a freeze predating those tables still passes
  // the schema_rev gate. Refuse instead, and name the tables. An empty ARRAY is
  // a genuinely empty table and still restores.
  const missingKeys = SNAPSHOT_TABLES
    .filter(({ key }) => tablesData[key] === undefined || tablesData[key] === null)
    .map(({ key }) => key);
  if (missingKeys.length) {
    return `it was saved before the current table set and carries no rows for ${missingKeys.join(', ')}`
      + ' — restoring it would erase those tables';
  }
  for (const { key } of SNAPSHOT_TABLES) {
    const rows = tablesData[key];
    if (!Array.isArray(rows)) return `the snapshot's "${key}" entry is not a list of rows`;
    for (const row of rows) {
      if (!row || typeof row !== 'object' || Array.isArray(row)) {
        return `the snapshot's "${key}" list holds an entry that is not a row`;
      }
      // Global-layer rows are never replayed (see restoreScenarioRowsFromTables),
      // so they are not validated as scenario rows either.
      if (row.scenario_id == null) continue;
      if (typeof row.id !== 'string' || row.id === '') {
        return `a "${key}" row in the snapshot has no id`;
      }
      for (const col of Object.keys(row)) {
        if (!SAFE_COLUMN_NAME.test(col)) return `a "${key}" row in the snapshot has an unusable column name`;
      }
    }
  }
  return null;
}

/**
 * Delete every scenario-scoped row of `scenarioId` on `conn`, inside the
 * caller's transaction — the "clear" half of an in-place restore. Iterates
 * SNAPSHOT_TABLES in REVERSE (child before parent): the schema carries no
 * DB-level FOREIGN KEY constraints, so this is not required today, but the order
 * keeps the statement sequence valid if constraints are ever added.
 *
 * cap_versions is NOT a snapshot table, so version history survives a restore;
 * neither is cap_scenarios, so the scenario row (name / note / owner) survives.
 * Every statement is scoped by `scenario_id = ?`, so the GLOBAL config layer
 * (scenario_id IS NULL) is never in range. Returns per-key deleted counts.
 */
async function deleteScenarioScopedRows(conn, scenarioId) {
  const counts = {};
  for (let i = SNAPSHOT_TABLES.length - 1; i >= 0; i -= 1) {
    const { key, table } = SNAPSHOT_TABLES[i];
    const result = await conn.query(
      `DELETE FROM \`${t(table)}\` WHERE scenario_id = ?`, [scenarioId],
    );
    counts[key] = Number((result && result.affectedRows) || 0);
  }
  return counts;
}

/**
 * Replay a frozen snapshot's rows into `scenarioId` on `conn`, inside the
 * caller's transaction — the "refill" half of an in-place restore. Call only
 * after deleteScenarioScopedRows (the ids are reused verbatim) and only with a
 * document findSnapshotRestoreBlocker has cleared. Parent-before-child order.
 *
 * The snapshot also carries the GLOBAL layer (addCatalogueClosure /
 * addGlobalConfigLayer pull scenario_id IS NULL rows so a freeze reproduces the
 * evaluation it captured). Those rows are SKIPPED here for the same reason a
 * clone skips them: reviving them as scenario-local copies would double-apply
 * every global rule and clutter the catalogue with orphan duplicates. The
 * restored scenario keeps referencing the LIVE global layer by id.
 *
 * Returns per-key restored counts.
 */
async function restoreScenarioRowsFromTables(conn, tablesData, scenarioId) {
  const counts = {};
  for (const { key, table } of SNAPSHOT_TABLES) {
    let written = 0;
    for (const row of tablesData[key] || []) {
      if (row.scenario_id == null) continue;
      const cols = [];
      const placeholders = [];
      const values = [];
      for (const [col, val] of Object.entries(row)) {
        if (RESTORE_SKIP_COLUMNS.has(col)) continue;
        cols.push(`\`${col}\``);
        placeholders.push('?');
        // NOTE: this is the SAME scenario_id the snapshot was frozen from, so
        // `dc_refs` / `allowed_disk_combos` / a rule's `params.site_id` need no
        // remap here the way deepCopyScenarioRows' clone path needs one — a
        // referenced site/combo that is still there resolves by its own
        // unchanged id. If one was deleted (and perhaps re-created under a new
        // id) since the snapshot, jsonReinsertable puts the frozen reference
        // back UNCHANGED rather than trying to re-mint a resolution: the same
        // "unresolvable survives byte-for-byte, never invented" preserve
        // semantics remapDcRefs/remapAllowedDiskCombos/remapRuleParamsSiteId
        // apply on clone (D4's T2) — restore just reaches it by having nothing
        // to remap in the first place, not by a second copy of that decision.
        values.push(jsonReinsertable(val));
      }
      cols.push('`scenario_id`');
      placeholders.push('?');
      values.push(scenarioId);
      await conn.query(
        `INSERT INTO \`${t(table)}\` (${cols.join(', ')}) VALUES (${placeholders.join(', ')})`,
        values,
      );
      written += 1;
    }
    counts[key] = written;
  }
  // A restore replays a frozen scenario's rows verbatim BY DESIGN — that is why
  // a pre-rule `sga_gb` survives one — but `site_id` is not a value the operator
  // ever typed: it is a cache of where the restored host stands, and replaying a
  // stale one lands the restored scenario in the state the health check calls
  // invalid, on rows the operator has just been told were restored faithfully.
  // The placement itself is replayed untouched; only the cache of it is derived.
  await syncVmSiteCache(conn, scenarioId);
  return counts;
}

/**
 * Roll back `conn` without ever rejecting — a rollback that itself throws (a
 * dropped socket, a pool-killed connection) must not turn into an unhandled
 * promise rejection in an async Express handler (Express 4 does not catch async
 * handler rejections and this codebase has no global unhandledRejection trap).
 * Logs and swallows. Safe to call from an early-return site AND the outer catch.
 */
async function safeRollback(conn) {
  if (!conn) return;
  try { await conn.rollback(); } catch (err) { logger.error({ err }, 'capacity rollback failed'); }
}

/**
 * Resolve whether `user` may WRITE `scenarioId` (owner + admin, spec §7),
 * locking the scenario row FOR UPDATE on `conn`. Returns:
 *   { found: false }                        → scenario missing (caller → 404)
 *   { found: true, allowed: false, ownerId }→ not owner and not admin (→ 403)
 *   { found: true, allowed: true,  ownerId }→ may write
 * Mirrors makeChildDelete / scenarios.delete: admin always; an editor only when
 * the scenario is shared (owner_id NULL) or their own.
 * @param user assumed already authenticated by the caller's requireAuth /
 *   requireAdminOrEditor guard (this reads user.role / user.id without a null
 *   check — do not call it before that guard has run).
 */
/**
 * Build an in-tx CREATE transform (schema factory `transformCreateInTx`) that
 * appends a new row at the END of its scenario's ordering: `order_index` =
 * MAX(order_index)+1 within `data.scenario_id` (phase-4 spec §6, mirroring
 * sites' own append semantics). Shared by the reorderable child mounts
 * (hypervisors / vms / db_instances, children.js) and the scenario-LOCAL
 * hardware_specs catalogue mount (local-catalogues.js).
 *
 * INTENTIONALLY LOCK-FREE (unlike children.js's own sites append, which locks
 * the scenario row FOR UPDATE): these entities' creates already lock FK rows
 * (cap_vms / cap_databases / cap_hypervisors …) in preWriteInTx, and layering a
 * cap_scenarios FOR UPDATE on top would add a new lock-ordering edge (deadlock
 * risk). A rare concurrent double-append can tie two rows on the same index;
 * that is cosmetic and self-heals on the next drag-reorder, which rewrites
 * every row's index. The reorder endpoint is the only path that changes an
 * existing row's order.
 */
function makeAppendOrderIndexOnCreate(table) {
  return async (conn, req, data) => {
    const rows = await conn.query(
      `SELECT COALESCE(MAX(order_index), -1) + 1 AS next FROM \`${t(table)}\` WHERE scenario_id = ?`,
      [data.scenario_id],
    );
    data.order_index = Number(rows[0] ? rows[0].next : 0);
    return data;
  };
}

// Single source of truth for the "may this user write/delete this scenario"
// gate (admin always; an editor only for a shared or self-owned scenario). The
// write/delete paths pass a transaction conn with the default FOR UPDATE lock;
// a read-only preview passes a ro handle with { lock: false } (a RO replica must
// not take a row lock).
//
// IT PROJECTS THE ID, AND THAT ONE COLUMN IS WHAT ITS CALLERS BIND.
// `WHERE id = ?` resolves the scenario for any spelling of it — the column is
// CHAR(36) under a case-folding collation — so a caller that goes on to stamp
// `req.params.scenarioId` into every child row it writes stores a value no
// scenario's `id` holds. Every SQL reader still finds those rows and every
// JavaScript reader does not: the "half-editable, unreferenceable" state the
// single-row write paths were already fixed for.
//
// WHICH CALLERS HAVE TO BIND IT: every one that WRITES the value down or HANDS
// IT BACK — a stored FK (the replace-all import, the version restore's
// re-insert, the version create), a durable audit line (the restore and rename
// trails), or a response body the browser resolves in JavaScript. A caller that
// only uses the value as a WHERE parameter does not need it, because the column
// folds and the predicate resolves the row either way.
//
// That distinction is the list, and stating it as a rule rather than as a count
// is deliberate: an earlier version of this comment said "the two bulk writers"
// and named them. There were three — the version create was the third, in a file
// the same sweep had already edited — and a comment that enumerates instances
// goes stale the moment somebody adds one, while a comment that names the
// PROPERTY can be checked against any new caller.
//
// AND THE OWNER COMPARISON IS ASKED OF THE COLUMN. `owner_id` folds case too,
// so a `===` here resolved nobody for a row every `WHERE owner_id = ?` in the
// system calls that owner's — and the failure was in the direction that refuses
// the GENUINE owner their own scenario, with no way to repair it from the UI.
async function resolveScenarioWriteAccess(dbHandle, scenarioId, user, { lock = true } = {}) {
  const rows = await dbHandle.query(
    `SELECT id, owner_id FROM \`${t(TABLES.CAP_SCENARIOS)}\` WHERE id = ?${lock ? ' FOR UPDATE' : ''}`,
    [scenarioId],
  );
  if (!rows.length) return { found: false };
  const ownerId = rows[0].owner_id;
  const allowed = user.role === 'admin' || ownerId === null
    || await sameStoredValue(dbHandle, t(TABLES.CAP_SCENARIOS), 'owner_id', ownerId, user.id);
  return {
    found: true, allowed, ownerId, scenarioId: rows[0].id,
  };
}

/**
 * Create a new scenario from `tablesData` (a live read or a frozen snapshot's
 * rows) on `conn`, inside the caller's transaction. owner-scope: an editor
 * stamps themselves; an admin leaves owner_id NULL (shared) — mirrors scenario
 * create. Returns the new scenario id. Deep-copies every scenario-scoped row
 * with remapped ids (deepCopyScenarioRows).
 */
async function cloneScenarioFromTables(conn, { name, note, actor, tablesData, sourceScenarioId }) {
  const newId = uuidv4();
  const ownerId = actor.role === 'editor' ? actor.id : null;
  await conn.query(
    `INSERT INTO \`${t(TABLES.CAP_SCENARIOS)}\` (id, name, owner_id, note) VALUES (?, ?, ?, ?)`,
    [newId, name, ownerId, note ?? null],
  );
  await deepCopyScenarioRows(conn, tablesData, newId, sourceScenarioId);
  return newId;
}

module.exports = {
  SCENARIO_SCOPED_TABLES,
  SCENARIO_ENTITY_DISPLAY,
  SCENARIO_INTEGRITY_FK_PROBES,
  SNAPSHOT_TABLES,
  CATALOGUE_CLOSURE,
  SNAPSHOT_SCHEMA_REV,
  SNAPSHOT_MAX_BYTES,
  readScenarioSnapshotTables,
  buildScenarioSnapshotDoc,
  addCatalogueClosure,
  addGlobalConfigLayer,
  readConfigTemplateTables,
  buildConfigTemplateDoc,
  isGlobalConfigEmpty,
  lockGlobalConfig,
  validateSettingsWrite,
  deepCopyScenarioRows,
  RESTORE_SKIP_COLUMNS,
  findSnapshotRestoreBlocker,
  deleteScenarioScopedRows,
  restoreScenarioRowsFromTables,
  remapObjectSetKey,
  resolveScenarioWriteAccess,
  makeAppendOrderIndexOnCreate,
  cloneScenarioFromTables,
  safeRollback,
  CHILD_FK_VALIDATIONS,
  CHILD_DELETE_BEHAVIOR,
  MAX_RULE_CONDITIONS,
  MAX_RULE_JSON_BYTES,
  MAX_DC_REFS_ENTRIES,
  MAX_ALLOWED_DISK_COMBOS_ENTRIES,
  validateRuleWritePayload,
  validateGlobalRuleWritePayload,
  validateRulePutMerge,
  validateGroupMemberXor,
  ruleWriteGuard,
  makeRulePutMergeGuard,
  makeCustomGroupMemberXorGuard,
  makeOverrideFillGuard,
  makeRuleOverrideUniquenessGuard,
  bindScenarioScope,
  stampAuditColumns,
  childWriteRoleGate,
  makeScenarioFkLockValidator,
  makeDcRefsCanonicalizer,
  makeAllowedDiskCombosCanonicalizer,
  parseIdList,
  diskComboAllowed,
  checkDiskComboPairInTx,
  makeDiskComboLockValidator,
  composePreWriteInTx,
  DEFAULT_FORMULA,
  readFormulaConstants,
  resolveProfileSizing,
  sumDiskComboSizes,
  RESERVED_META_KEYS,
  reservedMetadataKeyError,
  rejectReservedMetadataKeys,
  makeScenarioExistsGuard,
  makeRowScenarioBinding,
  makeVmTypeFlipLockValidator,
  MAX_OBJECT_SET_KEY,
  makeObjectSetKeyGuard,
  makeChildDelete,
  syncVmSiteCache,
  makeConfigTypeGuard,
  makeLocalCatalogueDelete,
  CONFIG_DELETE_GUARDS,
  findCatalogueReferenceBlocker,
  LOCAL_CATALOGUE_MOUNTS,
  BUNDLE_COLUMNS,
  BUNDLE_ITEM_COLUMNS,
  BUNDLE_ITEM_FK_SPECS,
  BUNDLE_ITEM_TYPES,
  BUNDLE_ITEM_TOPOLOGIES,
  SCENARIO_OWNERSHIP,
  CHILD_MOUNTS,
  CONFIG_MOUNTS,
  validateFieldDefWrite,
  validateFieldDefPutMerge,
  rejectIfFieldDefDuplicate,
  validateColumnTypes,
  enumDomainViolation,
  missingRequiredColumnOnCreate,
  SETTINGS_COLUMN_TYPES,
  ENTITY_NATIVE_FIELD_KEYS,
};
