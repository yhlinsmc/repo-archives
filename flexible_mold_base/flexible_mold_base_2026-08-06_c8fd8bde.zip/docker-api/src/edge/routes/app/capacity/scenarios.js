/**
 * @openapi
 * /edge/app/capacity/scenarios:
 *   get:
 *     tags: [App - Capacity]
 *     summary: List scenarios (all authenticated).
 *     responses:
 *       200: { description: Scenario list }
 *   post:
 *     tags: [App - Capacity]
 *     summary: Create a scenario (references the global catalogues; copies nothing).
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [name]
 *             properties:
 *               name: { type: string }
 *               note: { type: string }
 *     responses:
 *       201: { description: Created scenario (with template rows deep-copied) }
 *       403: { description: Admin or editor required }
 * /edge/app/capacity/scenarios/{id}:
 *   get:    { tags: [App - Capacity], summary: Get a scenario }
 *   put:    { tags: [App - Capacity], summary: Update a scenario (owner+admin) }
 *   delete: { tags: [App - Capacity], summary: Delete a scenario (owner+admin) }
 */

/**
 * capacity/scenarios.js — scenario CRUD.
 *
 * POST is bespoke: it inserts the scenario row only — the reference model
 * (config-rewrite §2, Model B) copies NOTHING at create; a scenario REFERENCES
 * the live global catalogues by FK. owner_id follows the owner-scope pattern —
 * an editor-created scenario is stamped to the actor; an admin-created scenario
 * stays NULL (shared). GET / PUT / DELETE reuse the generic CRUD factory with
 * ownerColumn owner_id (identical semantics to api_connectors).
 */
const express = require('express');
const { pool, t } = require('../../../db');
const { createCrudRoutes } = require('../schema');
const { requireAuth, requireAdmin, requireAdminOrEditor, apiOk, apiError, uuidv4 } = require('../../../../shared/helpers');
const { TABLES } = require('../../../../shared/constants');
const { mapRowsFromDb } = require('../../../lib/dto-mapper');
const { applyOwnerChange } = require('../../../services/ownership');
const { resolveCanonicalUserId, ownerTargetRejection } = require('../schema/write-value');
const { logger } = require('../../../../shared/lib/logger');
const {
  SCENARIO_SCOPED_TABLES, SNAPSHOT_MAX_BYTES, SCENARIO_INTEGRITY_FK_PROBES,
  readScenarioSnapshotTables, cloneScenarioFromTables, resolveScenarioWriteAccess, safeRollback,
} = require('./_shared');

const router = express.Router();

const MAX_NAME = 255;
const MAX_NOTE = 10000;

// POST / — create scenario + deep-copy template. Registered BEFORE the factory
// so it wins for POST /; the factory still serves GET / PUT / DELETE.
router.post('/', async (req, res) => {
  if (!requireAdminOrEditor(req, res)) return;
  const body = req.body || {};
  const name = typeof body.name === 'string' ? body.name.trim() : '';
  if (!name) {
    const e = apiError('name is required', 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }
  if (name.length > 255) {
    const e = apiError('name exceeds 255 characters', 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }
  const note = body.note ?? null;
  if (note !== null && (typeof note !== 'string' || note.length > 10000)) {
    const e = apiError('note must be a string up to 10000 characters', 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }

  // Owner-scope: editor stamps the actor; admin leaves NULL (shared). A
  // client-supplied owner_id is ignored — the server is the sole authority.
  const ownerId = req.user.role === 'editor' ? req.user.id : null;
  const id = uuidv4();
  let conn;
  try {
    conn = await pool.rw.getConnection();
    await conn.beginTransaction();
    // Reference model (config-rewrite §2, Model B): a scenario REFERENCES the
    // live global catalogues by FK — nothing is copied at create. The old
    // deep-copy-on-create is retired; version freeze is the only copy mechanism.
    await conn.query(
      `INSERT INTO \`${t(TABLES.CAP_SCENARIOS)}\` (id, name, owner_id, note) VALUES (?, ?, ?, ?)`,
      [id, name, ownerId, note],
    );
    await conn.commit();

    const rows = await conn.query(
      `SELECT * FROM \`${t(TABLES.CAP_SCENARIOS)}\` WHERE id = ?`, [id],
    );
    res.status(201).json(apiOk(mapRowsFromDb(TABLES.CAP_SCENARIOS, rows)[0]));
  } catch (err) {
    await safeRollback(conn);
    logger.error({ err, scenarioId: id }, `Failed to create capacity scenario id=${id}`);
    const e = apiError('Database operation failed', 'INTERNAL_ERROR', 500);
    res.status(e.status).json(e.body);
  } finally {
    if (conn) conn.release();
  }
});

// GET /health — per-scenario config-health facts for the LIST status badge
// (spec §9, item 7, Layer A). RO pool; read is open to every authenticated user
// (like GET /). Returns COUNTS only (no entity names) so the list can compute a
// status via the pure scenarioStatusFromFacts without fetching each scenario's
// full entity graph. Rule-violation counts are intentionally omitted here (they
// need the evaluator, run per-scenario in the detail view) — the list badge
// reflects data-integrity + incomplete-config, the two cheap aggregate classes.
// Registered BEFORE the factory so /scenarios/health is not treated as /:id.
router.get('/health', async (req, res) => {
  // Read is open to every authenticated user (like GET /), but authentication IS
  // required — the infra access-check lets an anonymous request through, so this
  // handler is the sole gate. Without it the endpoint would enumerate every
  // scenario id + integrity signal to an unauthenticated caller.
  if (!requireAuth(req, res)) return;
  try {
    // Seed every scenario at zero, then fold each aggregate probe in.
    const scenarios = await pool.ro.query(`SELECT id FROM \`${t(TABLES.CAP_SCENARIOS)}\``);
    const facts = new Map();
    for (const s of scenarios) {
      facts.set(s.id, { id: s.id, sites: 0, brokenRefs: 0, databasesWithoutProfile: 0 });
    }
    const bump = (scenarioId, key, delta) => {
      const f = facts.get(scenarioId);
      if (f) f[key] += Number(delta);
    };

    const sitesRows = await pool.ro.query(
      `SELECT scenario_id, COUNT(*) AS c FROM \`${t(TABLES.CAP_SITES)}\` GROUP BY scenario_id`,
    );
    for (const r of sitesRows) bump(r.scenario_id, 'sites', r.c);

    const noProfileRows = await pool.ro.query(
      `SELECT scenario_id, COUNT(*) AS c FROM \`${t(TABLES.CAP_DATABASES)}\`
       WHERE profile_id IS NULL GROUP BY scenario_id`,
    );
    for (const r of noProfileRows) bump(r.scenario_id, 'databasesWithoutProfile', r.c);

    // Broken-FK probes: a non-null FK whose LEFT JOIN target is absent. Each row
    // is one integrity fault; all fold into a single brokenRefs count per scenario.
    // The probe set + reference SCOPE are derived from CHILD_FK_VALIDATIONS (via
    // SCENARIO_INTEGRITY_FK_PROBES) so this list-aggregate agrees with both the
    // write-time validator and the pure detail validator. Scope is encoded in the
    // JOIN: a 'scenario' ref must be same-scenario (a target in ANOTHER scenario
    // is NOT valid); a 'catalogue' ref is global (scenario_id IS NULL) OR
    // same-scenario. A plain id-only join would wrongly accept a cross-scenario
    // target (Codex R2) and undercount broken refs.
    for (const probe of SCENARIO_INTEGRITY_FK_PROBES) {
      const scopeJoin = probe.mode === 'scenario'
        ? 'p.scenario_id = c.scenario_id'
        : '(p.scenario_id IS NULL OR p.scenario_id = c.scenario_id)';
      const rows = await pool.ro.query(
        `SELECT c.scenario_id AS scenario_id, COUNT(*) AS c
         FROM \`${t(probe.from)}\` c
         LEFT JOIN \`${t(probe.to)}\` p ON p.id = c.\`${probe.fk}\` AND ${scopeJoin}
         WHERE c.\`${probe.fk}\` IS NOT NULL AND p.id IS NULL
         GROUP BY c.scenario_id`,
      );
      for (const r of rows) bump(r.scenario_id, 'brokenRefs', r.c);
    }

    // THE SAME RULE, ON THE LAYER THAT READS THE SAME COLUMN. The detail panel
    // (computeScenarioHealth) reports a placed VM whose cached `site_id`
    // contradicts the host it stands on as a data-integrity fault. This
    // aggregate feeds the LIST badge, and a rule applied on one of the two is
    // not applied: the list would call a scenario healthy while opening it
    // showed the same scenario invalid. It is not derivable from
    // CHILD_FK_VALIDATIONS — that list says a reference must RESOLVE, and both
    // ends of this one resolve perfectly; what is wrong is that they disagree.
    //
    // `<>` rather than a JavaScript comparison, for the same reason the FE
    // folds case here: these are `CHAR(36)` under a case-folding collation, so
    // two spellings of one uuid are one value.
    const staleVmSiteRows = await pool.ro.query(
      `SELECT v.scenario_id AS scenario_id, COUNT(*) AS c
         FROM \`${t(TABLES.CAP_VMS)}\` v
         JOIN \`${t(TABLES.CAP_HYPERVISORS)}\` h
           ON h.id = v.hypervisor_id AND h.scenario_id = v.scenario_id
        WHERE v.hypervisor_id IS NOT NULL AND v.site_id IS NOT NULL AND v.site_id <> h.site_id
        GROUP BY v.scenario_id`,
    );
    for (const r of staleVmSiteRows) bump(r.scenario_id, 'brokenRefs', r.c);

    // THE SAME RULE, ON THE LAYER THAT READS THE SAME COLUMN — the second one.
    // `cap_databases.dc_refs` restricts a database to a set of data centres, and
    // an entry naming a site the scenario does not have restricts it to nothing
    // that exists: the candidate filter admits no host on that entry's account
    // and nothing tells the operator why. The detail panel reports it as a
    // broken reference, so this aggregate has to as well, or the list would call
    // the scenario healthy while opening it showed the same scenario invalid.
    //
    // WHAT AN ENTRY IS, AND WHEN ONE RESOLVES, IS NOT DECIDED HERE. It is stated
    // once in shared/capacity/dc-refs.js and this statement is one of its three
    // copies — the one that has to answer without loading the rows. It is held
    // to the rule by a differential test that drives this exact SQL and the
    // reference implementation over the same published corpus against a real
    // database (capacity-site-delete-real-db.test.js), so a drift fails on the
    // input it drifted on. Three independent readings of this column is how the
    // list badge and the detail panel came to disagree in three different
    // directions at once; the corpus is what stops a fourth.
    //
    // EVERY CLAUSE BELOW IS A CLAUSE OF THAT RULE, and each was got wrong:
    //
    //   VARCHAR(1024), not VARCHAR(36) — a width equal to a site id silently
    //     truncates a longer entry back ONTO an id and calls it resolvable. The
    //     width only has to EXCEED a site id's length: the comparison is exact,
    //     so nothing longer than an id can equal one. Tied to the DDL by the
    //     parity test rather than left as a number to trust.
    //
    //   JSON_CONTAINS(JSON_ARRAY(s.id), JSON_QUOTE(r.site_ref)) BESIDE the `=`,
    //     not instead of it. `=` gives the index lookup; every MariaDB collation
    //     — utf8mb4_bin included — is PAD SPACE, so `'x ' = 'x'` is TRUE and an
    //     entry with a trailing space reads as resolvable while `includes`
    //     refuses it. JSON string comparison is exact and does not pad, so it
    //     narrows the index's superset to the readers' answer.
    //
    //   CHAR_LENGTH(...) > 0, not `<> ''` — PAD SPACE again: `' ' <> ''` is
    //     FALSE, so a whitespace entry would be dropped as empty here while the
    //     readers keep it and resolve it to nothing.
    //
    //   COUNT(DISTINCT d.id, <the entry's JSON text>) — one broken reference
    //     written twice is one broken reference, and two databases naming the
    //     same absent site are two. Counting rows called the first of those two
    //     faults. The KEY is the thing to be careful about: `r.site_ref` is a
    //     JSON_TABLE column on the connection collation, so a DISTINCT over it
    //     folds case AND pads — `[X, x]`, `[X, "X "]` and `[x, X, "X "]` each
    //     counted 1 where the rule says 2, after three other clauses in this
    //     same statement had been written specifically to stop that. JSON_QUOTE
    //     does not fold or pad, so keying on it asks the rule's question.
    //
    //   AN ELEMENT THAT IS NOT A SCALAR IS STILL AN ENTRY. `PATH '$'` on an
    //     object or a nested array yields NULL, indistinguishable here from a
    //     JSON `null` element — and dropping both made `[{}]` read as "every
    //     data centre" instead of "no data centre this can name". FOR ORDINALITY
    //     is what tells the two apart: the element's own JSON_TYPE. Such an
    //     entry can never resolve (the LEFT JOIN has no value to match), and it
    //     keys on its JSON text so two identical objects are one entry.
    //
    // The IF() wrapper guards the expansion, not the data: MariaDB gives a JSON
    // column a json_valid CHECK, but a table created before that can hold text
    // JSON_TABLE raises on, and a 500 here would take the whole list badge down.
    const danglingDcRefRows = await pool.ro.query(
      `SELECT d.scenario_id AS scenario_id,
              COUNT(DISTINCT d.id, COALESCE(
                JSON_QUOTE(r.site_ref),
                JSON_EXTRACT(d.dc_refs, CONCAT('$[', r.pos - 1, ']'))
              )) AS c
         FROM \`${t(TABLES.CAP_DATABASES)}\` d
         JOIN JSON_TABLE(
                IF(JSON_VALID(d.dc_refs), d.dc_refs, JSON_ARRAY()),
                '$[*]' COLUMNS (pos FOR ORDINALITY, site_ref VARCHAR(1024) PATH '$')
              ) r ON 1 = 1
         LEFT JOIN \`${t(TABLES.CAP_SITES)}\` s
                ON s.scenario_id = d.scenario_id AND s.id = r.site_ref
               AND JSON_CONTAINS(JSON_ARRAY(s.id), JSON_QUOTE(r.site_ref))
        WHERE d.dc_refs IS NOT NULL AND s.id IS NULL
          AND (
            (r.site_ref IS NOT NULL AND CHAR_LENGTH(r.site_ref) > 0)
            OR JSON_TYPE(JSON_EXTRACT(d.dc_refs, CONCAT('$[', r.pos - 1, ']'))) IN ('OBJECT', 'ARRAY')
          )
        GROUP BY d.scenario_id`,
    );
    for (const r of danglingDcRefRows) bump(r.scenario_id, 'brokenRefs', r.c);

    res.json(apiOk(Array.from(facts.values())));
  } catch (err) {
    logger.error({ err }, 'Failed to build capacity scenario health facts');
    const e = apiError('Database operation failed', 'INTERNAL_ERROR', 500);
    res.status(e.status).json(e.body);
  }
});

// DELETE /:id — cascade-delete the scenario and its entire scoped subtree in one
// transaction. Registered BEFORE the factory (like POST) so it wins for
// DELETE /:id; the generic factory DELETE would drop only the cap_scenarios row
// and orphan every child (there are no DB FKs / ON DELETE CASCADE). Permission
// mirrors the factory's ownerColumn DELETE: admin always; an editor only when the
// scenario is shared (owner_id NULL) or their own. Owner read + delete run in one
// tx with the scenario row locked FOR UPDATE (SA-delete precedent, #598).
router.delete('/:id', async (req, res) => {
  if (!requireAdminOrEditor(req, res)) return;
  const id = req.params.id;
  let conn;
  try {
    conn = await pool.rw.getConnection();
    await conn.beginTransaction();
    // Single source of truth for the admin-or-owner gate (FOR UPDATE locks the
    // row for the cascade). The T1 delete-preview reuses the SAME helper (RO,
    // unlocked) so the preview can never disagree with this gate.
    const access = await resolveScenarioWriteAccess(conn, id, req.user);
    if (!access.found) {
      await safeRollback(conn);
      const e = apiError('Not found', 'NOT_FOUND', 404);
      return res.status(e.status).json(e.body);
    }
    if (!access.allowed) {
      await safeRollback(conn);
      const e = apiError('Not allowed: you do not own this scenario', 'FORBIDDEN', 403);
      return res.status(e.status).json(e.body);
    }
    // Every scenario-scoped row (WHERE scenario_id = id) — the global template
    // rows (scenario_id IS NULL) are never touched — then the scenario itself.
    for (const table of SCENARIO_SCOPED_TABLES) {
      await conn.query(`DELETE FROM \`${t(table)}\` WHERE scenario_id = ?`, [id]);
    }
    await conn.query(`DELETE FROM \`${t(TABLES.CAP_SCENARIOS)}\` WHERE id = ?`, [id]);
    await conn.commit();
    res.json(apiOk({ id, deleted: true }));
  } catch (err) {
    await safeRollback(conn);
    logger.error({ err, scenarioId: id }, `Failed to delete capacity scenario id=${id}`);
    const e = apiError('Database operation failed', 'INTERNAL_ERROR', 500);
    res.status(e.status).json(e.body);
  } finally {
    if (conn) conn.release();
  }
});

// POST /:id/clone — deep-copy a scenario's LIVE working state into a brand-new
// scenario (spec §5). Read is open to all authenticated users, so an
// admin/editor may clone any scenario; the clone is a fresh create (owner-scope:
// editor stamps self, admin leaves NULL). All ids are minted anew and every FK /
// waiver object_set_key is remapped (deepCopyScenarioRows). Registered before
// the factory so /:id/clone is not shadowed by the factory's /:id routes.
router.post('/:id/clone', async (req, res) => {
  if (!requireAdminOrEditor(req, res)) return;
  const sourceId = req.params.id;
  const body = req.body || {};
  const rawName = typeof body.name === 'string' ? body.name.trim() : '';
  if (rawName.length > MAX_NAME) {
    const e = apiError(`name exceeds ${MAX_NAME} characters`, 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }
  const noteOverride = body.note;
  if (noteOverride != null && (typeof noteOverride !== 'string' || noteOverride.length > MAX_NOTE)) {
    const e = apiError(`note must be a string up to ${MAX_NOTE} characters`, 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }

  let conn;
  try {
    conn = await pool.rw.getConnection();
    await conn.beginTransaction();

    const src = await conn.query(
      `SELECT name, note FROM \`${t(TABLES.CAP_SCENARIOS)}\` WHERE id = ?`, [sourceId],
    );
    if (!src.length) {
      await safeRollback(conn);
      const e = apiError('Scenario not found', 'NOT_FOUND', 404);
      return res.status(e.status).json(e.body);
    }
    const cloneName = (rawName || `${src[0].name} (copy)`).slice(0, MAX_NAME);
    const cloneNote = noteOverride !== undefined ? (noteOverride ?? null) : (src[0].note ?? null);

    const tablesData = await readScenarioSnapshotTables(conn, sourceId);
    // Size cap (parity with the version-freeze SNAPSHOT_MAX_BYTES guard,
    // versions.js): a clone deep-copies every scenario-scoped row, so an
    // oversized source would balloon the write. Measure the copied payload the
    // same way freeze measures its snapshot (serialized byte length vs the SAME
    // shared 4MB constant — no second limit) and reject before any INSERT.
    if (Buffer.byteLength(JSON.stringify(tablesData), 'utf8') > SNAPSHOT_MAX_BYTES) {
      await safeRollback(conn);
      const e = apiError('Scenario is too large to clone', 'PAYLOAD_TOO_LARGE', 400);
      return res.status(e.status).json(e.body);
    }
    const newId = await cloneScenarioFromTables(conn, {
      name: cloneName, note: cloneNote, actor: req.user, tablesData, sourceScenarioId: sourceId,
    });
    await conn.commit();

    const rows = await conn.query(
      `SELECT * FROM \`${t(TABLES.CAP_SCENARIOS)}\` WHERE id = ?`, [newId],
    );
    res.status(201).json(apiOk(mapRowsFromDb(TABLES.CAP_SCENARIOS, rows)[0]));
  } catch (err) {
    await safeRollback(conn);
    logger.error({ err, sourceId }, `Failed to clone capacity scenario id=${sourceId}`);
    const e = apiError('Database operation failed', 'INTERNAL_ERROR', 500);
    res.status(e.status).json(e.body);
  } finally {
    if (conn) conn.release();
  }
});

// PATCH /:id/owner — admin transfer of a scenario to another admin/editor, or to
// "shared" (owner_id = null). Registered BEFORE the factory so /:id/owner is not
// shadowed by the factory's PUT /:id. Admin-only (spec §11): consistent with the
// other ownership tables, an editor never reassigns ownership. A scenario is only
// writable by admin+editor, so the target (when not shared) must be one of those
// roles — a plain user cannot own a scenario. new_owner_id === null makes it
// shared (owner NULL). The audit + FOR-UPDATE + same-owner short-circuit all live
// in the shared applyOwnerChange service (parity with api_connectors reassign).
const OWNER_AUDIT_EVENT = 'cap_scenario.owner.transfer';
router.patch('/:id/owner', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  const body = req.body || {};
  // new_owner_id: a non-empty string id (transfer) OR null (make shared). Any
  // other shape (undefined, number, '') is rejected before any DB work.
  const rawOwner = body.new_owner_id;
  const makeShared = rawOwner === null;
  if (!makeShared && (typeof rawOwner !== 'string' || rawOwner.length === 0)) {
    const e = apiError('new_owner_id must be a non-empty string id or null (shared)', 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }
  let conn;
  try {
    conn = await pool.rw.getConnection();
    await conn.beginTransaction();

    // collation-compare: the column decides which user row this spelling names.
    // `ownerId` is the STORED spelling and is what the UPDATE binds — resolving
    // the row without rebinding its id stores an alias that the scenario
    // screen's own owner lookup cannot match.
    let ownerId = null;
    if (!makeShared) {
      // Target must be a real, existing admin/editor. A plain user can never own
      // a scenario (create/write is admin+editor), so transferring to one would
      // strand the row. The FE picker already filters, but a direct PATCH must
      // not bypass it. Never echo the target's email — only id + role are read.
      const target = await resolveCanonicalUserId(conn, t(TABLES.USERS), rawOwner);
      if (!target.ok) {
        await safeRollback(conn);
        // One mapping for every route that asks the shared resolver, so an
        // administrator gets the same sentence whichever record they transfer —
        // including the banned-account refusal, which is not "no such user".
        const rejection = ownerTargetRejection(target.reason);
        const e = apiError(rejection.message, rejection.code, rejection.status);
        return res.status(e.status).json(e.body);
      }
      if (target.role !== 'admin' && target.role !== 'editor') {
        await safeRollback(conn);
        const e = apiError('Target user must be an admin or editor', 'BAD_REQUEST', 400);
        return res.status(e.status).json(e.body);
      }
      ownerId = target.id;
    }

    const result = await applyOwnerChange(conn, TABLES.CAP_SCENARIOS, req.params.id, ownerId, {
      actor: req.user,
      action: makeShared ? 'make_shared' : 'transfer',
      requireCondition: 'any', // admin transfer: no precondition on current owner
      auditEventType: OWNER_AUDIT_EVENT,
      t,
    });

    if (result.conflict_reason === 'NOT_FOUND') {
      await safeRollback(conn);
      const e = apiError('Not found', 'NOT_FOUND', 404);
      return res.status(e.status).json(e.body);
    }
    if (result.unchanged_same_owner) {
      await conn.commit();
      return res.json(apiOk({ owner_id: result.new_owner, changed: false }));
    }
    await conn.commit();
    res.json(apiOk({
      owner_id: result.new_owner,
      old_owner_id: result.prior_owner,
      changed: true,
    }));
  } catch (err) {
    await safeRollback(conn);
    logger.error({ err, scenarioId: req.params.id }, `Failed to transfer capacity scenario owner id=${req.params.id}`);
    const e = apiError('Database operation failed', 'INTERNAL_ERROR', 500);
    res.status(e.status).json(e.body);
  } finally {
    if (conn) conn.release();
  }
});

// GET / + GET /:id + PUT /:id via the generic factory. Its own POST / and
// DELETE /:id are shadowed by the bespoke handlers above.
router.use('/', createCrudRoutes('cap_scenarios', {
  ownerColumn: 'owner_id',
  allowedRoles: ['admin', 'editor'],
  resolveOwnerName: 'owner_id',
  // A TRANSFER GOES THROUGH THE ENDPOINT ABOVE, AND THERE IS NO SECOND DOOR.
  // `ownerColumn` alone strips this column from a NON-ADMIN body, which leaves
  // an administrator's generic PUT able to hand a scenario to anybody — without
  // the target's existence or role being checked, without the id being resolved
  // to the spelling the column stores, and without the `feature_audit` line
  // that is the only record any of it happened. Every one of those is done by
  // `PATCH /:id/owner`, so the column is immutable here: `immutableColumns` is
  // role-agnostic, which is the property this needs and the one `ownerColumn`
  // does not have.
  immutableColumns: ['owner_id'],
}));

module.exports = router;
