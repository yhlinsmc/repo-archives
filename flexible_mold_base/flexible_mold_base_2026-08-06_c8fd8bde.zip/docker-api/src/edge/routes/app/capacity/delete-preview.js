/**
 * capacity/delete-preview.js — fail-closed delete-impact preview endpoints
 * (spec §10, item 8). Two tiers of blast-radius preview, both READ-ONLY (ro
 * pool): the FE fetches a preview BEFORE opening its confirm dialog and BLOCKS
 * the delete if the fetch fails (never degrades to a generic confirm).
 *
 *   T1  GET /scenarios/:id/delete-preview
 *       Whole-scenario blast radius: per-scoped-table row counts + a bounded
 *       list of the primary entities' names (sites/hypervisors/VMs/databases).
 *       Authz MIRRORS the scenario DELETE gate exactly (admin always; an editor
 *       only for a shared or self-owned scenario) — a non-owner editor gets 403
 *       so the preview cannot enumerate a scenario they may not delete. The
 *       names listed all belong to THIS scenario (the caller is authorized to
 *       delete it), so surfacing them leaks nothing across a scope boundary.
 *
 *   T2  GET /config/:group/:id/delete-preview
 *       Which entities reference a GLOBAL catalogue row (a delete is refused
 *       server-side while any live row references it). Returns COUNTS + kind
 *       nouns only ('a VM', 'a database', …) — deliberately NO scenario names or
 *       ids (SECURITY: a global row is cross-scope by nature; the prior
 *       cross-scenario precedent surfaces kind nouns, never foreign names/UUIDs).
 *       Admin+editor (the global-config tier).
 */
'use strict';

const express = require('express');
const { pool, t } = require('../../../db');
const { requireAdminOrEditor, apiOk, apiError } = require('../../../../shared/helpers');
const { TABLES } = require('../../../../shared/constants');
const { logger } = require('../../../../shared/lib/logger');
const { CONFIG_DELETE_GUARDS, SCENARIO_SCOPED_TABLES, SCENARIO_ENTITY_DISPLAY, resolveScenarioWriteAccess } = require('./_shared');

const router = express.Router();

// The cap of names returned in a T1 preview. The exact per-kind counts are
// always accurate; the list is bounded so a huge scenario cannot balloon the
// response or the dialog ("+N more" is derived from names_total on the FE).
const NAME_LIST_CAP = 40;

// Primary named entities surfaced in the T1 affected-name list — each with its
// real display column (SCENARIO_ENTITY_DISPLAY; cap_databases uses function_name,
// not name). Local catalogue rows are config, not placement — counted, not listed.
const T1_NAMED_ENTITIES = SCENARIO_ENTITY_DISPLAY;

// T1: whole-scenario delete impact. RO pool. Authz + counted-table set both reuse
// the DELETE handler's single sources of truth (resolveScenarioWriteAccess and
// SCENARIO_SCOPED_TABLES) so the preview can never disagree with the real delete.
router.get('/scenarios/:id/delete-preview', async (req, res) => {
  if (!requireAdminOrEditor(req, res)) return;
  const id = req.params.id;
  try {
    // Same gate as DELETE /:id, RO + unlocked (a replica must not FOR UPDATE): a
    // non-owner editor is 403'd so the preview never enumerates a scenario they
    // cannot delete.
    const access = await resolveScenarioWriteAccess(pool.ro, id, req.user, { lock: false });
    if (!access.found) {
      const e = apiError('Not found', 'NOT_FOUND', 404);
      return res.status(e.status).json(e.body);
    }
    if (!access.allowed) {
      const e = apiError('Not allowed: you do not own this scenario', 'FORBIDDEN', 403);
      return res.status(e.status).json(e.body);
    }
    // The gate helper reads owner_id only; fetch the name for the response body.
    const nameRows = await pool.ro.query(
      `SELECT name FROM \`${t(TABLES.CAP_SCENARIOS)}\` WHERE id = ?`, [id],
    );
    const name = nameRows.length ? nameRows[0].name : '';

    // Per-scoped-table counts, keyed by logical table name and derived from the
    // SAME SCENARIO_SCOPED_TABLES the DELETE iterates — so a table added to the
    // cascade automatically appears in the blast radius (no hand-list drift).
    const counts = {};
    for (const table of SCENARIO_SCOPED_TABLES) {
      const rows = await pool.ro.query(
        `SELECT COUNT(*) AS c FROM \`${t(table)}\` WHERE scenario_id = ?`, [id],
      );
      counts[String(table)] = Number(rows[0].c);
    }

    // Bounded affected-name list drawn from the primary placement entities. The
    // true total is the sum of their exact counts, so the FE "+N more" is exact.
    const namesTotal = T1_NAMED_ENTITIES.reduce((sum, e) => sum + (counts[String(e.table)] || 0), 0);
    const names = [];
    for (const { kind, table, nameCol } of T1_NAMED_ENTITIES) {
      if (names.length >= NAME_LIST_CAP) break;
      const remaining = NAME_LIST_CAP - names.length;
      // nameCol is from a frozen static config (never request-derived), so the
      // interpolated identifier is safe — value is still parameterized.
      const rows = await pool.ro.query(
        `SELECT id, \`${nameCol}\` AS name FROM \`${t(table)}\` WHERE scenario_id = ? ORDER BY \`${nameCol}\` LIMIT ?`,
        [id, remaining],
      );
      for (const r of rows) names.push({ id: r.id, name: r.name, kind });
    }

    res.json(apiOk({
      scenario: { id, name },
      counts,
      names,
      names_total: namesTotal,
    }));
  } catch (err) {
    logger.error({ err, scenarioId: id }, `Failed to build scenario delete preview id=${id}`);
    const e = apiError('Database operation failed', 'INTERNAL_ERROR', 500);
    res.status(e.status).json(e.body);
  }
});

// T2: which entities reference a GLOBAL catalogue row. RO pool. Counts + kind
// nouns only (no scenario names/ids — SECURITY, cross-scope). Admin+editor.
router.get('/config/:group/:id/delete-preview', async (req, res) => {
  if (!requireAdminOrEditor(req, res)) return;
  const { group, id } = req.params;
  const guard = CONFIG_DELETE_GUARDS[group];
  if (!guard) {
    const e = apiError('No delete-impact preview for this catalogue group', 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }
  try {
    const references = [];
    let total = 0;
    for (const ref of guard.refs) {
      const rows = await pool.ro.query(
        `SELECT COUNT(*) AS c FROM \`${t(ref.table)}\` WHERE \`${ref.column}\` = ?`, [id],
      );
      const count = Number(rows[0].c);
      if (count > 0) {
        references.push({ by: ref.by, count });
        total += count;
      }
    }
    res.json(apiOk({
      group,
      id,
      label: guard.label,
      references, // [{ by: 'a VM', count: 3 }, …] — kind nouns only, no names
      total,
      blocked: total > 0, // a referenced global row cannot be deleted (§ delete guard)
    }));
  } catch (err) {
    logger.error({ err, group, rowId: id }, `Failed to build catalogue delete preview group=${group} id=${id}`);
    const e = apiError('Database operation failed', 'INTERNAL_ERROR', 500);
    res.status(e.status).json(e.body);
  }
});

module.exports = router;
