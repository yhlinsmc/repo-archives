/**
 * @openapi
 * /edge/app/capacity/config/import/validate:
 *   post:
 *     tags: [App - Capacity]
 *     summary: Dry-run a first-instance global-config import (admin+editor).
 *     description: >
 *       Parses a `{ schema_rev, tables }` payload (the shape the config export
 *       produces, re-parsed browser-side from xlsx/csv), reports the empty-config
 *       gate + structural issues + a per-catalogue summary, and writes NOTHING.
 *     responses:
 *       200: { description: Validation report }
 *       403: { description: Admin or editor required }
 *       413: { description: Import payload exceeds the size cap }
 * /edge/app/capacity/config/import/commit:
 *   post:
 *     tags: [App - Capacity]
 *     summary: Commit a first-instance global-config import (admin+editor).
 *     description: >
 *       Re-checks the empty-config gate UNDER the transaction and, only when the
 *       config is empty, writes every catalogue in one transaction. Returns 409 if
 *       the config is non-empty at commit time (server-enforced, not UI-only).
 *     responses:
 *       200: { description: Commit result (inserted counts) }
 *       403: { description: Admin or editor required }
 *       409: { description: Config is not empty — import is first-instance-seeding only }
 *       413: { description: Import payload exceeds the size cap }
 *       422: { description: Structural errors — nothing written }
 */

/**
 * capacity/config-import.js — the GATED first-instance global-config import
 * (phase-2 spec §3.3 A2 / §8 / §9). Distinct from io.js's SCENARIO import: this
 * writes the GLOBAL catalogue layer (scenario_id IS NULL + the bundle tables) and
 * runs ONLY when the whole global config is empty (server-enforced gate).
 *
 * SECURITY (spec §9 — the parse surface is treated as hostile):
 *   1. Size caps — request body (edge parser) + a serialized-payload byte cap +
 *      a per-catalogue row cap, all BEFORE the O(rows) passes.
 *   2. Sheet + column allow-list — only the nine known catalogue keys and their
 *      known columns; an unknown sheet is rejected, an unknown column is dropped
 *      with a reported warning. No dynamic table/column name reaches SQL — every
 *      INSERT is built from the KNOWN dbRow keys, backtick-quoted, parameterized.
 *   3. No formula evaluation — cells are literal text/number only (the browser
 *      parser reads values, never formulas; a leading =/+/-/@ is data here).
 *   4. Server re-validation — validate's output is advisory; commit re-parses and
 *      re-checks the empty gate under the transaction (never trusts the client).
 *   5. Empty gate — seeds an empty instance only; it can never overwrite a live
 *      config, bounding the blast radius.
 *   6. No secrets — only capacity catalogues are accepted; no secret-bearing
 *      field exists in the allow-list, and the encrypted system_settings surface
 *      is untouched.
 * Ids are MINTED server-side and FK columns are remapped to those minted ids, so
 * a client-supplied id is never trusted as a primary key.
 */
const express = require('express');
const { pool, t } = require('../../../db');
const {
  requireAdminOrEditor, apiOk, apiError, uuidv4,
} = require('../../../../shared/helpers');
const { logger } = require('../../../../shared/lib/logger');
const { TABLES } = require('../../../../shared/constants');
const { RULE_TYPES, RELATIONAL_GROUP_BYS } = require('../../../../shared/capacity/rule-types');
const { floorGb } = require('../../../../shared/capacity/whole-numbers');
const {
  isGlobalConfigEmpty, lockGlobalConfig, SNAPSHOT_SCHEMA_REV, safeRollback, validateRuleWritePayload,
  RESERVED_META_KEYS, diskComboAllowed, validateSettingsWrite, ENTITY_NATIVE_FIELD_KEYS,
} = require('./_shared');
// Reuse the direct bundle write path's validators (Fix-3 + Codex r2 P2-1 ruling:
// an imported bundle/item must obey the same rules, not a duplicated copy). FK
// targets live IN the payload (empty-instance seed) so the profile-class +
// disk-combo checks resolve against the just-built vm_profiles rows rather than the DB.
const {
  sgaDbOnlyError, topologyNodeCountError, itemProfileClassError,
  validateBundleHeader, validateItemBody,
} = require('./bundles');

const router = express.Router();

// Import payload cap (io.js MAX_IMPORT_BYTES precedent). The whole global config
// at design scale is a few hundred KB; 4 MB is a generous DoS backstop under the
// 10 MB edge body parser.
const MAX_IMPORT_BYTES = 4 * 1024 * 1024;
// Per-catalogue row cap — a structural error, not a 500. Well above any real
// global catalogue.
const MAX_ROWS_PER_SHEET = 10000;

// Server-managed / non-writable columns tolerated on the file but never taken.
const SERVER_MANAGED_COLUMNS = new Set(['id', 'scenario_id', 'created_at', 'updated_at', 'scope']);

// The 409 message is verbatim from spec §3.3.
const NON_EMPTY_MESSAGE = 'global config is not empty; import is only available for first-instance seeding';

// WHOLE_NUMBER_IMPORT_RULE (fmb-1433) — same contract as the scenario import
// (io.js carries the long form): a `spec.integers` column holds a derived
// capacity quantity, so a fraction is FLOORED and reported, never refused.
// Refusing would make this release unable to seed a fresh instance from the
// workbook the previous release exported — and config import is the ONLY
// supported bootstrap, so that failure has no way around it. The grid still
// refuses the same fraction, because there the operator is authoring the number
// and can fix it on the spot.
const WHOLE_NUMBER_NOTICE_CODE = 'FLOORED_TO_WHOLE';

// ── Per-catalogue import contract (the nine global-config sheets) ──────────────
// nameCol   — the display-name column other sheets resolve by name.
// required  — must be present + non-empty.
// strings/numbers/booleans/enums/jsonCols — typed columns.
// integers  — the WHOLE-NUMBER subset of `numbers` (WHOLE_NUMBER_IMPORT_RULE).
// hasMetadata — folds cf:<key> columns into a metadata JSON string.
// fk        — { fileCol: { idCol, target, refCol, nullable? } } name/ref → id.
// jsonListRef — { col, target } a JSON id-list remapped through the target's ids.
const N = (a) => a;
const CONFIG_SPECS = Object.freeze([
  {
    key: 'hardware_specs', table: TABLES.CAP_HARDWARE_SPECS, nameCol: 'name', scoped: true,
    required: ['name'], strings: ['name'], enums: {},
    numbers: N(['cpu_total', 'mem_total_gb', 'disk_total_gb', 'cpu_reserved', 'mem_reserved_pct', 'disk_reserved_gb', 'order_index']),
    booleans: [], jsonCols: ['metadata'], hasMetadata: true, fk: {},
    // codex r2 P2: this catalogue is one of the drag-reorderable global config
    // pages (config.js ORDERABLE_CONFIG_GROUPS) — an export round-trip must not
    // silently reset every row to the DEFAULT 0 front-of-list position. A doc
    // exported before order_index existed carries no such column at all; that
    // case seeds sequential indices from row position (below) rather than
    // colliding every row on 0.
    seedSequentialOrderIndex: true,
  },
  {
    key: 'disk_combos', table: TABLES.CAP_DISK_COMBOS, nameCol: 'name', scoped: true,
    required: ['name'], strings: ['name'], enums: {}, numbers: ['order_index'], booleans: [],
    jsonCols: ['sizes'], hasMetadata: false, fk: {},
    seedSequentialOrderIndex: true,
  },
  {
    key: 'teams', table: TABLES.CAP_TEAMS, nameCol: 'name', scoped: true,
    required: ['name'], strings: ['name', 'color'], enums: {}, numbers: ['order_index'], booleans: [],
    jsonCols: [], hasMetadata: false, fk: {},
    seedSequentialOrderIndex: true,
  },
  {
    key: 'vm_profiles', table: TABLES.CAP_VM_PROFILES, nameCol: 'name', scoped: true,
    required: ['class', 'name'], strings: ['name'],
    enums: { class: ['DB', 'AP'], mode: ['formula', 'custom'] },
    numbers: ['cpu', 'mem_gb', 'sga_cap_gb', 'order_index'],
    // Whole numbers only (fmb-1433) — the same rule the profiles grid enforces,
    // so a seeding workbook cannot be the way around it.
    integers: ['mem_gb', 'sga_cap_gb'],
    booleans: [],
    jsonCols: ['allowed_disk_combos', 'metadata'], hasMetadata: true, fk: {},
    jsonListRef: { col: 'allowed_disk_combos', target: 'disk_combos' },
    seedSequentialOrderIndex: true,
  },
  {
    key: 'field_defs', table: TABLES.CAP_FIELD_DEFS, nameCol: null, scoped: true,
    required: ['entity_type', 'field_key', 'data_type'],
    strings: ['field_key', 'label', 'default_value'],
    enums: {
      entity_type: ['scenario', 'site', 'hardware_spec', 'hypervisor', 'vm', 'db_instance', 'database'],
      data_type: ['text', 'number', 'bool', 'enum'],
    },
    numbers: [], booleans: ['required'], jsonCols: ['options'], hasMetadata: false, fk: {},
  },
  {
    key: 'settings', table: TABLES.CAP_SETTINGS, nameCol: null, scoped: true, singleton: true,
    required: [], strings: [], enums: {},
    numbers: ['mem_cpu_ratio', 'sga_factor', 'sga_divisor', 'sga_subtract', 'standby_sga_default_gb', 'util_amber_pct', 'util_red_pct'],
    // The standby SGA default is an SGA size (fmb-1433) — whole numbers only, on
    // the seeding-workbook path as well as the settings form. The ratio/factor
    // constants beside it stay free to carry decimals.
    integers: ['standby_sga_default_gb'],
    booleans: ['overcommit_default_enabled'], jsonCols: ['layer_defaults'], hasMetadata: false, fk: {},
  },
  {
    key: 'rules', table: TABLES.CAP_RULES, nameCol: 'name', scoped: true, ruleRow: true,
    required: ['type', 'name', 'level'], strings: ['name'],
    enums: {
      type: RULE_TYPES, level: ['hypervisor', 'vm', 'db_instance'],
      group_by: RELATIONAL_GROUP_BYS, severity: ['hard', 'soft'],
    },
    numbers: [], booleans: ['enabled'], jsonCols: ['filters', 'params'], hasMetadata: false, fk: {},
    // A GLOBAL rule may not be an override nor reference a custom group (§17.1);
    // these export columns are recognised (not "unknown") but must be empty.
    forbidNonEmpty: ['custom_group_name', 'custom_group_ref', 'overrides_rule_name', 'overrides_rule_ref'],
  },
  {
    key: 'bundles', table: TABLES.CAP_BUNDLES, nameCol: 'name', scoped: false,
    required: ['name'], strings: ['name'], enums: {}, numbers: ['serial', 'order_index'], booleans: [],
    jsonCols: [], hasMetadata: false, fk: {},
    seedSequentialOrderIndex: true,
  },
  {
    key: 'bundle_items', table: TABLES.CAP_BUNDLE_ITEMS, nameCol: null, scoped: false,
    required: ['type'], strings: ['function_name', 'prefill_custom_group'],
    enums: { type: ['DB', 'AP'], topology: ['single', 'primary', 'primary_standby', 'rac'] },
    numbers: ['order_index', 'qty', 'node_count', 'primary_sga_gb', 'standby_sga_gb'],
    // The SGA seeds are stamped straight into cap_databases' SGA columns, so they
    // are whole numbers (fmb-1433) — and the config export emits them with
    // SELECT *, so a table row written before the rule leaves the app holding a
    // workbook it would otherwise refuse to load. Same treatment as every other
    // derived column: WHOLE_NUMBER_IMPORT_RULE. Flooring here also lands the
    // value in dbRow BEFORE the shared `validateItemBody` sees it, so the grid's
    // hard refusal stays exactly as it is on the route that grid posts to.
    integers: ['primary_sga_gb', 'standby_sga_gb'],
    booleans: [],
    jsonCols: [], hasMetadata: false,
    fk: {
      bundle_name: { idCol: 'bundle_id', target: 'bundles', refCol: 'bundle_ref' },
      profile_name: { idCol: 'profile_id', target: 'vm_profiles', refCol: 'profile_ref', nullable: true },
      disk_combo_name: { idCol: 'disk_combo_id', target: 'disk_combos', refCol: 'disk_combo_ref', nullable: true },
      team_name: { idCol: 'team_id', target: 'teams', refCol: 'team_ref', nullable: true },
    },
  },
]);

const SPEC_BY_KEY = new Map(CONFIG_SPECS.map((s) => [s.key, s]));
// Parent-before-child insertion order (no DB-level FK exists between config
// tables, but bundles precede their items and disk_combos precede the profiles
// whose allow-lists reference them, for readability + app correctness).
const INSERT_ORDER = Object.freeze([
  'hardware_specs', 'disk_combos', 'teams', 'vm_profiles', 'field_defs', 'settings', 'rules', 'bundles', 'bundle_items',
]);

// ── Cell coercion (tolerate spreadsheet string cells; never evaluate) ──────────

function isEmpty(v) { return v == null || (typeof v === 'string' && v.trim() === ''); }

function coerceNumber(v) {
  if (typeof v === 'number' && Number.isFinite(v)) return { ok: true, value: v };
  if (typeof v === 'string' && v.trim() !== '') {
    const n = Number(v);
    if (Number.isFinite(n)) return { ok: true, value: n };
  }
  return { ok: false };
}
function coerceBoolean(v) {
  if (typeof v === 'boolean') return { ok: true, value: v };
  if (v === 0 || v === 1) return { ok: true, value: v === 1 };
  if (typeof v === 'string') {
    const s = v.trim().toLowerCase();
    if (s === 'true' || s === '1') return { ok: true, value: true };
    if (s === 'false' || s === '0') return { ok: true, value: false };
  }
  return { ok: false };
}
function coerceJson(v) {
  if (v == null) return { ok: true, value: null };
  if (typeof v === 'object') {
    try { return { ok: true, value: JSON.stringify(v) }; } catch { return { ok: false }; }
  }
  if (typeof v === 'string') {
    if (v.trim() === '') return { ok: true, value: null };
    try { JSON.parse(v); return { ok: true, value: v }; } catch { return { ok: false }; }
  }
  return { ok: false };
}

function allowedColumn(spec, col) {
  if (SERVER_MANAGED_COLUMNS.has(col)) return true;
  if (col === 'ref') return true;
  if (col === spec.nameCol) return true;
  if (spec.required.includes(col) || spec.strings.includes(col) || spec.numbers.includes(col)
    || spec.booleans.includes(col) || spec.jsonCols.includes(col)) return true;
  if (Object.prototype.hasOwnProperty.call(spec.enums, col)) return true;
  if (Object.prototype.hasOwnProperty.call(spec.fk, col)) return true;
  for (const def of Object.values(spec.fk)) if (def.refCol === col) return true;
  if ((spec.forbidNonEmpty || []).includes(col)) return true;
  if (spec.hasMetadata && (col === 'metadata' || col.startsWith('cf:'))) return true;
  return false;
}

// Fold cf:<key> (+ explicit metadata) into a metadata JSON string with a
// null-prototype accumulator so a cf:__proto__ cell cannot pollute Object.prototype.
function buildMetadata(spec, row, push) {
  if (!spec.hasMetadata) return null;
  const acc = Object.create(null);
  let touched = false;
  const base = row.metadata;
  if (base && typeof base === 'object') {
    for (const [k, val] of Object.entries(base)) {
      if (RESERVED_META_KEYS.has(k)) { push('metadata', 'RESERVED_FIELD_KEY', `metadata key "${k}" is reserved`); return null; }
      acc[k] = val; touched = true;
    }
  } else if (typeof base === 'string' && base.trim() !== '') {
    let parsed = null;
    try { parsed = JSON.parse(base); } catch { push('metadata', 'INVALID_JSON', 'metadata is not valid JSON'); return null; }
    if (parsed && typeof parsed === 'object') {
      for (const [k, val] of Object.entries(parsed)) {
        if (RESERVED_META_KEYS.has(k)) { push('metadata', 'RESERVED_FIELD_KEY', `metadata key "${k}" is reserved`); return null; }
        acc[k] = val; touched = true;
      }
    }
  }
  for (const col of Object.keys(row)) {
    if (!col.startsWith('cf:')) continue;
    const key = col.slice(3);
    if (RESERVED_META_KEYS.has(key)) { push(col, 'RESERVED_FIELD_KEY', `custom field key "${key}" is reserved`); continue; }
    acc[key] = row[col]; touched = true;
  }
  return touched ? JSON.stringify(acc) : null;
}

/**
 * Whether a serialized payload exceeds the size cap. Exported for a boundary unit
 * test (a 4 MB payload cannot be sent through the test harness's body parser).
 */
function configImportPayloadTooLarge(tables) {
  let serialized;
  try { serialized = JSON.stringify(tables ?? {}); } catch { return true; }
  return Buffer.byteLength(serialized, 'utf8') > MAX_IMPORT_BYTES;
}

/**
 * PURE (no DB): validate + resolve a `{ schema_rev, tables }` config-import
 * payload. Mints a fresh id per row, coerces native columns, folds cf: metadata,
 * resolves FK-by-ref-then-name WITHIN the payload (the target config is empty, so
 * every FK target must be present), and remaps vm_profiles.allowed_disk_combos.
 * Returns { ok, errors, notices, summary:{<key>:count}, schemaRevMatch, plan }.
 * `plan[key]` = rows to INSERT (dbRow keys are known columns only). `actorId` is
 * unused today (no created_by column on the config tables) but kept for parity.
 */
function buildConfigImportPlan(payload) {
  const errors = [];
  const notices = [];
  const summary = {};
  const input = payload && typeof payload.tables === 'object' && payload.tables ? payload.tables : {};
  const schemaRevMatch = Number(payload && payload.schema_rev) === SNAPSHOT_SCHEMA_REV;

  // Unknown top-level sheet keys are rejected (spec §9.2).
  for (const key of Object.keys(input)) {
    if (!SPEC_BY_KEY.has(key)) {
      errors.push({ sheet: key, row: 0, code: 'UNKNOWN_SHEET', message: `unknown sheet "${key}"` });
    }
  }

  // Phase 1 — per-row native validation + id minting.
  const built = {}; // key → [{ rowNum, id, name, refToken, dbRow, raw }]
  for (const spec of CONFIG_SPECS) {
    const raw = input[spec.key];
    const rows = Array.isArray(raw) ? raw : [];
    if (raw !== undefined && !Array.isArray(raw)) {
      errors.push({ sheet: spec.key, row: 0, code: 'BAD_SHEET', message: `sheet "${spec.key}" must be an array of rows` });
    }
    built[spec.key] = [];
    if (rows.length > MAX_ROWS_PER_SHEET) {
      errors.push({ sheet: spec.key, row: 0, code: 'TOO_MANY_ROWS', message: `sheet "${spec.key}" has ${rows.length} rows (max ${MAX_ROWS_PER_SHEET})` });
      continue;
    }
    const seenRef = new Set();
    const droppedCols = new Set();
    rows.forEach((row, i) => {
      const rowNum = i + 2; // header occupies file row 1
      const push = (column, code, message) => errors.push(column
        ? { sheet: spec.key, row: rowNum, column, code, message }
        : { sheet: spec.key, row: rowNum, code, message });
      const noteFloored = (column, was, now) => notices.push({
        sheet: spec.key, row: rowNum, column, code: WHOLE_NUMBER_NOTICE_CODE,
        message: `${column} ${was} was imported as ${now} — a derived capacity quantity is stored as a whole number`,
      });
      if (!row || typeof row !== 'object' || Array.isArray(row)) { push(undefined, 'BAD_ROW', 'row must be an object'); return; }

      // Unknown columns are DROPPED with a reported warning (spec §9.2), not an error.
      for (const col of Object.keys(row)) if (!allowedColumn(spec, col)) droppedCols.add(col);

      for (const col of spec.required) if (isEmpty(row[col])) push(col, 'MISSING_FIELD', `${col} is required`);

      const dbRow = {};
      for (const col of spec.strings) {
        if (Object.prototype.hasOwnProperty.call(row, col) && !isEmpty(row[col])) dbRow[col] = String(row[col]);
      }
      for (const [col, legal] of Object.entries(spec.enums)) {
        if (isEmpty(row[col])) continue;
        const val = String(row[col]);
        if (!legal.includes(val)) push(col, 'INVALID_ENUM', `${col} "${val}" is not one of ${legal.join(', ')}`);
        else dbRow[col] = val;
      }
      // A `spec.integers` column is floored and reported rather than refused —
      // WHOLE_NUMBER_IMPORT_RULE carries the why.
      for (const col of spec.numbers) {
        if (isEmpty(row[col])) continue;
        const c = coerceNumber(row[col]);
        if (!c.ok) { push(col, 'INVALID_NUMBER', `${col} must be a number`); continue; }
        if ((spec.integers || []).includes(col) && !Number.isInteger(c.value)) {
          dbRow[col] = floorGb(c.value);
          noteFloored(col, c.value, dbRow[col]);
        } else dbRow[col] = c.value;
      }
      // codex r2 P2: a reorderable global catalogue's order_index round-trips
      // through export/import (it is now a plain column in spec.numbers above).
      // An OLDER export predating this column carries no order_index cell at all
      // (isEmpty above then skips it) — seed a SEQUENTIAL index from the row's
      // position in the sheet so the imported set still has a deterministic,
      // spread-out order, instead of every row colliding on the column DEFAULT 0
      // (which would visually re-sort the whole catalogue to created_at order).
      if (spec.seedSequentialOrderIndex && !Object.prototype.hasOwnProperty.call(dbRow, 'order_index')) {
        dbRow.order_index = i;
      }
      for (const col of spec.booleans) {
        if (isEmpty(row[col])) continue;
        const c = coerceBoolean(row[col]);
        if (!c.ok) push(col, 'INVALID_BOOLEAN', `${col} must be true or false`);
        else dbRow[col] = c.value ? 1 : 0;
      }
      for (const col of spec.jsonCols) {
        if (!Object.prototype.hasOwnProperty.call(row, col)) continue;
        const c = coerceJson(row[col]);
        if (!c.ok) push(col, 'INVALID_JSON', `${col} is not valid JSON`);
        else if (c.value !== null) dbRow[col] = c.value;
      }
      if (spec.hasMetadata) {
        const meta = buildMetadata(spec, row, push);
        if (meta !== null) dbRow.metadata = meta;
      }
      // A GLOBAL rule may not carry an override / custom-group reference (§17.1).
      for (const col of spec.forbidNonEmpty || []) {
        if (!isEmpty(row[col])) push(col, 'INVALID_GLOBAL_RULE', `${col} is not allowed on a global rule (imports seed the global template only)`);
      }
      // A rule row obeys the same target-model + DoS bounds the direct write path
      // enforces (six-keeper type allow-list, per-type level/group_by legality,
      // filters/params size) — an import must not bypass them.
      if (spec.ruleRow) {
        const bad = validateRuleWritePayload(
          { type: dbRow.type, level: dbRow.level, group_by: dbRow.group_by, filters: row.filters, params: row.params },
          { strictType: true },
        );
        if (bad) push(undefined, bad.code, bad.message);
      }

      const id = uuidv4();
      const name = spec.nameCol && !isEmpty(row[spec.nameCol]) ? String(row[spec.nameCol]) : null;
      const refToken = !isEmpty(row.ref) ? String(row.ref) : null;
      if (refToken != null) {
        if (seenRef.has(refToken)) push('ref', 'DUPLICATE_REF', `duplicate ref "${refToken}"`);
        else seenRef.add(refToken);
      }
      built[spec.key].push({ rowNum, id, name, refToken, dbRow, raw: row });
    });
    for (const col of droppedCols) {
      notices.push({ sheet: spec.key, code: 'DROPPED_COLUMN', message: `column "${col}" in sheet "${spec.key}" is not recognised and was dropped` });
    }
  }

  // Phase 1.5 — build ref→id and name→[id] maps of the MINTED ids per catalogue.
  const refToId = {}; const nameToIds = {};
  for (const spec of CONFIG_SPECS) {
    refToId[spec.key] = new Map(); nameToIds[spec.key] = new Map();
    for (const b of built[spec.key]) {
      if (b.refToken != null) refToId[spec.key].set(b.refToken, b.id);
      if (b.name != null) {
        const list = nameToIds[spec.key].get(b.name) || [];
        list.push(b.id); nameToIds[spec.key].set(b.name, list);
      }
    }
  }

  // A settings singleton — at most one imported settings row.
  const settingsBuilt = built.settings || [];
  settingsBuilt.slice(1).forEach((b) => {
    errors.push({ sheet: 'settings', row: b.rowNum, code: 'DUPLICATE', message: 'only one settings row is allowed' });
  });

  // Phase 2 — resolve FK columns (ref-first, name-fallback) + remap JSON id-lists.
  for (const spec of CONFIG_SPECS) {
    for (const b of built[spec.key]) {
      const push = (column, code, message) => errors.push({ sheet: spec.key, row: b.rowNum, column, code, message });
      for (const [fileCol, def] of Object.entries(spec.fk)) {
        let resolved = null;
        const rawRef = def.refCol ? b.raw[def.refCol] : undefined;
        if (!isEmpty(rawRef)) {
          resolved = refToId[def.target].get(String(rawRef));
          if (!resolved) { push(def.refCol, 'UNRESOLVED_REF', `${def.refCol} "${rawRef}" matches no ${def.target} in the import`); continue; }
        } else {
          const rawName = b.raw[fileCol];
          if (isEmpty(rawName)) {
            if (!def.nullable) push(fileCol, 'MISSING_FIELD', `${fileCol} (or ${def.refCol}) is required`);
            continue;
          }
          const ids = nameToIds[def.target].get(String(rawName)) || [];
          if (ids.length === 0) { push(fileCol, 'UNRESOLVED_REF', `${fileCol} "${rawName}" matches no ${def.target} in the import`); continue; }
          if (ids.length >= 2) { push(fileCol, 'UNRESOLVED_REF', `${fileCol} "${rawName}" matches ${ids.length} ${def.target} rows; use ${def.refCol} to disambiguate`); continue; }
          resolved = ids[0];
        }
        b.dbRow[def.idCol] = resolved;
      }
      // vm_profiles.allowed_disk_combos: a JSON id-list of ORIGINAL disk-combo ids
      // (the export writes original ids; each imported disk_combo carries that id
      // as its `ref`) → remap each through the disk_combos ref map.
      if (spec.jsonListRef && b.dbRow[spec.jsonListRef.col] != null) {
        let list = null;
        try { list = JSON.parse(b.dbRow[spec.jsonListRef.col]); } catch { list = null; }
        if (Array.isArray(list)) {
          const remapped = []; let bad = false;
          for (const origId of list) {
            const mapped = refToId[spec.jsonListRef.target].get(String(origId));
            if (!mapped) { push(spec.jsonListRef.col, 'UNRESOLVED_REF', `${spec.jsonListRef.col} references ${spec.jsonListRef.target} "${origId}" not present in the import`); bad = true; break; }
            remapped.push(mapped);
          }
          if (!bad) b.dbRow[spec.jsonListRef.col] = JSON.stringify(remapped);
        }
      }
    }
  }

  // Phase 3 — bundle items obey the SAME business rules the direct bundles route
  // enforces (spec Fix-3 ruling), reusing its helpers: DB-only SGA, topology/node
  // coupling, item.type ↔ profile.class, and the profile's disk-combo allow-list.
  // The profile is resolved from the in-payload vm_profiles (Phase 2 remapped both
  // the item's profile_id/disk_combo_id and the profile's allowed_disk_combos to
  // MINTED ids), so an invalid item is a validate-phase error, never an inserted row.
  const profileById = new Map();
  for (const b of built.vm_profiles || []) {
    profileById.set(b.id, { class: b.dbRow.class, allowedDiskCombos: b.dbRow.allowed_disk_combos });
  }
  for (const b of built.bundle_items || []) {
    const push = (code, message) => errors.push({ sheet: 'bundle_items', row: b.rowNum, code, message });
    const item = b.dbRow;
    // Numeric shape the direct route enforces (Codex r2 P2-1): integer qty ≥1,
    // RAC node_count in range, SGA non-negative. Reuses validateItemBody verbatim.
    const shapeErr = validateItemBody(item);
    if (shapeErr) push('INVALID_ITEM', shapeErr);
    const sgaErr = sgaDbOnlyError(item.type, item);
    if (sgaErr) push('INVALID_ITEM_SGA', sgaErr);
    const couplingErr = topologyNodeCountError(item.topology ?? null, item.node_count ?? null);
    if (couplingErr) push('INVALID_ITEM_TOPOLOGY', couplingErr);
    const profile = item.profile_id != null ? profileById.get(item.profile_id) : null;
    if (profile) {
      const classErr = itemProfileClassError(item.type, profile.class);
      if (classErr) push(classErr.code, classErr.message);
      if (item.disk_combo_id != null && !diskComboAllowed(profile.allowedDiskCombos, item.disk_combo_id)) {
        push('DISK_COMBO_NOT_ALLOWED', "disk_combo_id is not in the chosen profile's allowed disk combos");
      }
    }
  }

  // Bundle headers: serial shape (integer ≥1) via the direct-route validator, plus
  // app-level duplicate-serial rejection WITHIN the import (the route's DB UNIQUE
  // key has no analog here) — Codex r2 P2-1.
  const seenSerial = new Map();
  for (const b of built.bundles || []) {
    const headerErr = validateBundleHeader(b.dbRow, { serialOptional: true });
    if (headerErr) errors.push({ sheet: 'bundles', row: b.rowNum, code: 'INVALID_BUNDLE', message: headerErr });
    const serial = b.dbRow.serial;
    if (serial != null) {
      if (seenSerial.has(serial)) errors.push({ sheet: 'bundles', row: b.rowNum, code: 'DUPLICATE_SERIAL', message: `serial ${serial} is used by more than one bundle in the import` });
      else seenSerial.set(serial, b.rowNum);
    }
  }

  // Settings: the non-negative standby-default guard the settings route applies
  // (Codex r2 P2-2), reusing validateSettingsWrite.
  for (const b of settingsBuilt) {
    const settingsErr = validateSettingsWrite(b.dbRow);
    if (settingsErr) errors.push({ sheet: 'settings', row: b.rowNum, code: 'INVALID_SETTINGS', message: settingsErr });
  }

  // Field defs: reject a duplicate (entity_type, field_key) pair WITHIN the import
  // (the route's UNIQUE (scenario_id, entity_type, field_key) guard) — Codex r2 P2-3.
  //
  // THE KEY IS THE ONE THE ROUTE USES, and it used to be a different one. The
  // route's probe is `WHERE entity_type = ? AND field_key = ?` under a
  // case-folding collation, so it calls 'Cost' and 'cost' one key and refuses
  // the second. This compared the two byte for byte and called them two, so a
  // workbook carrying BOTH spellings imported cleanly and produced a state the
  // API itself would have refused and can never repair through the normal
  // route. The UNIQUE index cannot arbitrate either: MariaDB treats each NULL
  // scenario_id as distinct and every global def has one, so the app layer is
  // the only enforcer. The route is the authority — it is the surface an
  // operator meets afterwards.
  const seenFieldKey = new Set();
  for (const b of built.field_defs || []) {
    const et = b.dbRow.entity_type; const fk = b.dbRow.field_key;
    if (et == null || fk == null) continue; // a missing required field is already flagged
    const key = `${String(et).toLowerCase()}\u0000${String(fk).toLowerCase()}`;
    if (seenFieldKey.has(key)) errors.push({ sheet: 'field_defs', row: b.rowNum, code: 'DUPLICATE_FIELD_DEF', message: `a field_key "${fk}" already exists for entity_type "${et}" in the import` });
    else seenFieldKey.add(key);
  }

  // Field defs: reject a field_key that collides with its entity_type's own
  // native column (fmb-1582 review wave). The direct-write route rejects this
  // at the source (_shared.js validateFieldDefWrite), but this import path
  // never consulted the same guard — a seeding workbook could plant a
  // "primary_sga_gb" custom field for entity_type "database" and it would
  // land in cap_field_defs, producing a second grid column under the key the
  // real database column already occupies (capacity-field-defs.ts
  // dropNativeKeyCollisions only defends the READ side; the write must be
  // gated here too).
  for (const b of built.field_defs || []) {
    const et = b.dbRow.entity_type; const fk = b.dbRow.field_key;
    if (et == null || fk == null) continue; // a missing required field is already flagged
    const nativeKeys = ENTITY_NATIVE_FIELD_KEYS[et];
    if (nativeKeys && nativeKeys.includes(fk)) {
      errors.push({ sheet: 'field_defs', row: b.rowNum, code: 'NATIVE_KEY_COLLISION', message: `field_key "${fk}" conflicts with a native ${et} column` });
    }
  }

  // Disk-combo names: mirror the client-side DiskCombosCard rules server-side.
  // A combo name is joined into a comma-separated allow-list wire encoding by the
  // VM Profiles disk multiSelect, so a comma inside a name corrupts that CSV — it
  // must be rejected at the write boundary, not only in the UI. Names must also be
  // unique within the import. The uniqueness key mirrors DiskCombosCard exactly:
  // trim THEN lower-case (the grid compares `(name ?? '').trim().toLowerCase()`),
  // so `OS` and ` os ` collide. The comma check runs on the raw name — trim only
  // strips leading/trailing whitespace and never removes an interior comma, so
  // trimming first would not change its verdict.
  const seenComboName = new Set();
  for (const b of built.disk_combos || []) {
    if (b.name == null) continue; // a missing name already raised MISSING_FIELD
    if (b.name.includes(',')) {
      errors.push({ sheet: 'disk_combos', row: b.rowNum, column: 'name', code: 'INVALID_DISK_COMBO_NAME', message: `disk combo name "${b.name}" cannot contain a comma` });
    }
    const key = b.name.trim().toLowerCase();
    if (seenComboName.has(key)) {
      errors.push({ sheet: 'disk_combos', row: b.rowNum, column: 'name', code: 'DUPLICATE_DISK_COMBO_NAME', message: `disk combo name "${b.name}" is used by more than one row in the import` });
    } else {
      seenComboName.add(key);
    }
  }

  const plan = {};
  for (const spec of CONFIG_SPECS) {
    plan[spec.key] = built[spec.key].map((b) => ({ id: b.id, dbRow: b.dbRow }));
    summary[spec.key] = plan[spec.key].length;
  }
  return { ok: errors.length === 0, errors, notices, summary, schemaRevMatch, plan };
}

// ── Commit: clear-then-insert per catalogue that the plan populates ────────────
// A catalogue absent from the import is left untouched (so a partial import that
// omits e.g. rules keeps the seeded default template); a catalogue present in the
// import replaces the existing global rows of that table (the seed/default). The
// empty gate guarantees no USER content is being replaced.
async function writeConfigPlan(conn, plan) {
  const inserted = {};
  for (const key of INSERT_ORDER) {
    const spec = SPEC_BY_KEY.get(key);
    const rows = plan[key] || [];
    inserted[key] = 0;
    if (rows.length === 0) continue;
    // Clear existing global rows of this catalogue before re-inserting.
    if (spec.scoped) await conn.query(`DELETE FROM \`${t(spec.table)}\` WHERE scenario_id IS NULL`);
    else await conn.query(`DELETE FROM \`${t(spec.table)}\``);
    for (const { id, dbRow } of rows) {
      const cols = []; const placeholders = []; const values = [];
      for (const [col, val] of Object.entries(dbRow)) { cols.push(`\`${col}\``); placeholders.push('?'); values.push(val); }
      cols.push('`id`'); placeholders.push('?'); values.push(id);
      if (spec.scoped) { cols.push('`scenario_id`'); placeholders.push('?'); values.push(null); }
      await conn.query(
        `INSERT INTO \`${t(spec.table)}\` (${cols.join(', ')}) VALUES (${placeholders.join(', ')})`,
        values,
      );
      inserted[key] += 1;
    }
  }
  return inserted;
}

// ── Routes ────────────────────────────────────────────────────────────────────

const dbError = (res) => {
  const e = apiError('Database operation failed', 'INTERNAL_ERROR', 500);
  res.status(e.status).json(e.body);
};

function readPayload(req, res) {
  const body = req.body || {};
  if (!body.tables || typeof body.tables !== 'object' || Array.isArray(body.tables)) {
    const e = apiError('tables must be an object keyed by catalogue', 'BAD_REQUEST', 400);
    res.status(e.status).json(e.body);
    return null;
  }
  if (configImportPayloadTooLarge(body.tables)) {
    const e = apiError('Import payload is too large', 'PAYLOAD_TOO_LARGE', 413);
    res.status(e.status).json(e.body);
    return null;
  }
  return body;
}

// POST /config/import/validate — dry run (no writes).
router.post('/import/validate', async (req, res) => {
  if (!requireAdminOrEditor(req, res)) return;
  const payload = readPayload(req, res);
  if (!payload) return;
  try {
    const emptyGate = await isGlobalConfigEmpty(pool.ro);
    const report = buildConfigImportPlan(payload);
    res.json(apiOk({
      ok: report.ok,
      emptyGate,
      schemaRevMatch: report.schemaRevMatch,
      issues: [...report.errors, ...report.notices],
      summary: report.summary,
    }));
  } catch (err) {
    logger.error({ err }, 'Failed to validate capacity config import');
    dbError(res);
  }
});

// POST /config/import/commit — write all catalogues in one tx if the config is
// empty. Re-checks the gate under the transaction (server-enforced, not UI-only).
router.post('/import/commit', async (req, res) => {
  if (!requireAdminOrEditor(req, res)) return;
  const payload = readPayload(req, res);
  if (!payload) return;
  let conn;
  try {
    conn = await pool.rw.getConnection();
    await conn.beginTransaction();
    // Serialization point (empty-gate TOCTOU) via the SHARED global-config lock:
    // lock the cap_settings sentinel FOR UPDATE BEFORE evaluating the gate. Two
    // commits racing an empty seed contend on this row-lock — the winner writes and
    // commits, the loser then re-reads a now-non-empty config and 409s. Every
    // ordinary global-config writer (config.js / bundles.js) takes the SAME lock in
    // its write tx, so an ordinary write cannot land a global row between this gate
    // check and the clear-then-insert below (P1). cap_settings is always seeded, so
    // this always locks a real row.
    await lockGlobalConfig(conn);
    // Gate re-check UNDER the transaction: a client that skips the UI and posts
    // commit directly against a non-empty config gets 409 (spec §9.4).
    const empty = await isGlobalConfigEmpty(conn);
    if (!empty) {
      await safeRollback(conn);
      const e = apiError(NON_EMPTY_MESSAGE, 'CONFLICT', 409);
      return res.status(e.status).json(e.body);
    }
    const report = buildConfigImportPlan(payload);
    if (!report.ok) {
      await safeRollback(conn);
      return res.status(422).json({ ok: false, errors: report.errors, notices: report.notices, summary: report.summary });
    }
    const inserted = await writeConfigPlan(conn, report.plan);
    await conn.commit();
    // The notices ride along on SUCCESS too (io.js's scenario-import commit does
    // the same): a FLOORED_TO_WHOLE row is the record that a value in the file
    // is not the value now in the database, and a commit reached directly —
    // without the validate dry-run — is the only place it would be told.
    res.json(apiOk({ ok: true, inserted, notices: report.notices }));
  } catch (err) {
    await safeRollback(conn);
    logger.error({ err }, 'Failed to commit capacity config import');
    dbError(res);
  } finally {
    if (conn) conn.release();
  }
});

module.exports = router;
module.exports.buildConfigImportPlan = buildConfigImportPlan;
module.exports.configImportPayloadTooLarge = configImportPayloadTooLarge;
module.exports.MAX_IMPORT_BYTES = MAX_IMPORT_BYTES;
module.exports.CONFIG_SPECS = CONFIG_SPECS;
