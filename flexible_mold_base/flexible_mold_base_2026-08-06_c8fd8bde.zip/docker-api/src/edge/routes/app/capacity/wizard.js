/**
 * @openapi
 * /edge/app/capacity/scenarios/wizard:
 *   post:
 *     tags: [App - Capacity]
 *     summary: Create a full scenario skeleton in one pass (admin+editor).
 *     description: >
 *       The setup wizard's create endpoint (spec §15). One request materializes a
 *       scenario plus its sites, hypervisors, application/database VMs, databases,
 *       and DB instances in ONE transaction, referencing the global catalogues by
 *       FK (copies nothing — reference model, §2). The frontend sends the fully
 *       resolved rows after the Step-5 matrix adjustments; cross-entity links are
 *       carried by client-supplied `ref` tokens (site_ref / database_ref / vm_ref)
 *       that this endpoint resolves to freshly minted ids. Any invalid row rejects
 *       the whole request (400) and nothing is written.
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [name]
 *             properties:
 *               name: { type: string }
 *               description: { type: string }
 *               bundle_id: { type: string, description: provenance only — never persisted (§7.2) }
 *               sites: { type: array, items: { type: object } }
 *               hypervisors: { type: array, items: { type: object } }
 *               databases: { type: array, items: { type: object } }
 *               vms: { type: array, items: { type: object } }
 *               db_instances: { type: array, items: { type: object } }
 *     responses:
 *       201: { description: Created scenario id + per-entity counts }
 *       400: { description: Validation failed — nothing written (per-row details) }
 *       403: { description: Admin or editor required }
 */

/**
 * capacity/wizard.js — the setup-wizard bulk create endpoint (R3, spec §15).
 *
 * REFERENCE MODEL (§2): the wizard REFERENCES the global catalogues by FK and
 * copies nothing. BUNDLE PROVENANCE records NO membership (§7.2): a `bundle_id`
 * may ride along the request as provenance metadata but is never persisted — the
 * stamped rows are ordinary independent scenario rows.
 *
 * Cross-entity links inside one request use client-supplied `ref` tokens, not
 * real ids (the frontend cannot know the ids this endpoint will mint):
 *   hypervisor.site_ref → a sites[].ref     · vm.site_ref → a sites[].ref
 *   vm.database_ref     → a databases[].ref · db_instance.vm_ref → a vms[].ref
 *   db_instance.database_ref → a databases[].ref
 * They are resolved in memory to minted ids. Only the CATALOGUE FKs
 * (spec_id / profile_id / disk_combo_id / team_id) are real global-catalogue ids;
 * those pass the §17.1a reference-integrity validator under a FOR-UPDATE lock so a
 * concurrent catalogue delete cannot dangle the reference (bundles.js precedent;
 * the unlocked legacy child-write pattern is deliberately NOT copied here).
 *
 * Topology materialization is FE-computed (the wizard renders the node table);
 * this endpoint RE-VALIDATES it server-side (spec §10.1, locked): the per-database
 * instance counts by role must match the topology (single→1 primary; primary→2
 * primary; primary+standby→2 primary + 2 standby; RAC N→N primary), a standby
 * instance is legal only under a primary+standby database, and DB instances hang
 * off db_host VMs only.
 */
const express = require('express');
const { pool, t } = require('../../../db');
const {
  requireAdminOrEditor, apiOk, apiError, uuidv4,
} = require('../../../../shared/helpers');
const { TABLES } = require('../../../../shared/constants');
const { logger } = require('../../../../shared/lib/logger');
const { checkReferences, canonicalKey } = require('./reference-integrity');
const {
  safeRollback, reservedMetadataKeyError,
  DEFAULT_FORMULA, readFormulaConstants, resolveProfileSizing, sumDiskComboSizes,
  diskComboAllowed,
} = require('./_shared');
const { deriveInstanceSga } = require('../../../../shared/capacity/sga-defaults');

const router = express.Router();

/**
 * Fetch catalogue rows by the ids the CLIENT asked for, carrying each requested
 * spelling back with its row.
 *
 * WHY THE REQUESTED SPELLING HAS TO COME BACK. These ids land in a Map that is
 * later read with the body's value — `profileById.get(row.sizing_profile_id)` —
 * and `cap_vm_profiles.id` is `CHAR(36)` under a case-folding collation. A map
 * keyed on the row's OWN id therefore MISSES for any spelling that is not
 * byte-identical, while every gate upstream passes: `checkReferences` accepts
 * the reference because SQL resolves it, and the profile-class check passes
 * because it is keyed on the body's side. The miss then falls through to
 * `row.cpu ?? 0` / `row.mem_gb ?? 0` — the client's own numbers — so a row that
 * claims a profile is persisted with hand-chosen sizing, which is precisely the
 * autofill the server-side derivation exists to make impossible. The disk-combo
 * allow-list check returns null on the same miss, so §5.3 is skipped too.
 *
 * The JOIN is what makes this one question rather than two: `p.id = w.want`
 * compares under the COLUMN's collation, so the engine decides which requested
 * spelling names which row, exactly as `WHERE id = ?` does everywhere else. A
 * case-fold performed here in JavaScript would be a second opinion about the
 * column's equality — the thing this whole path went wrong on.
 *
 * IT IS NOW THE SECOND LOCK ON A DOOR THE PLAN ALREADY SHUTS, and it stays
 * keyed on the REQUESTED spelling for that reason. The reference check rewrites
 * every catalogue FK in the plan to the id its row carries before this runs, so
 * the two keys coincide and no test can tell them apart. Keyed on the row's own
 * id instead, this would go back to MISSING — silently, and falling through to
 * the client's own numbers — the moment that rewrite were removed or ordered
 * after it. The failure direction of the two keyings is what decides this, not
 * which of them is redundant today.
 *
 * @param {object} conn open connection (the write connection)
 * @param {string} table logical table name (a `TABLES.*` value)
 * @param {string} columns extra projection, each qualified `p.`
 * @param {string[]} ids the spellings the client asked for
 */
async function selectByRequestedId(conn, table, columns, ids) {
  if (!ids.length) return [];
  const wanted = ids.map(() => 'SELECT ? AS want').join(' UNION ALL ');
  return conn.query(
    `SELECT w.want AS requested_id, p.id, ${columns}
       FROM (${wanted}) w
       JOIN \`${t(table)}\` p ON p.id = w.want`,
    ids,
  );
}

const MAX_NAME = 255;
const MAX_DESCRIPTION = 120; // Step-1 description + per-database description (spec §15.1 / §15.5).
const MAX_SITES = 3;         // Site cap (spec §15.2, feedback round-1 item 5).
const RAC_MIN_NODES = 2;     // RAC is a cluster — at least two nodes (spec §10.1).

// DoS bounds on the four unbounded arrays (Review Gate finding H1). Each accepted
// row is one awaited INSERT inside a single held transaction/connection, so an
// unbounded array from an authenticated editor is a self-service write-pool
// exhaustion vector. These caps sit comfortably above the realistic full-scale
// dataset (Q12: 3 DC / 60 HV / 90 KVM / 100 instances) and short-circuit BEFORE
// any per-row work or the transaction opens (413, mirroring versions.js). RAC
// node_count is bounded too (each node → one instance, so it can never demand
// more than the db_instances cap).
const MAX_HYPERVISORS = 500;
const MAX_DATABASES = 500;
const MAX_VMS = 2000;
const MAX_DB_INSTANCES = 4000;
const RAC_MAX_NODES = 100;
const MAX_METADATA_BYTES = 8192; // Per-row metadata blob cap (mirrors _shared.js MAX_RULE_JSON_BYTES).

// True when a metadata value is an object whose serialized form exceeds the cap
// (or cannot be serialized at all — a circular structure). A non-object/absent
// value is not this helper's concern (the caller's typeof check handles it).
function metadataTooLarge(meta) {
  if (meta == null || typeof meta !== 'object') return false;
  let serialized;
  try { serialized = JSON.stringify(meta); } catch { return true; }
  return typeof serialized === 'string' && Buffer.byteLength(serialized, 'utf8') > MAX_METADATA_BYTES;
}

const TOPOLOGIES = new Set(['single', 'primary', 'primary_standby', 'rac']);
const VM_TYPES = new Set(['db_host', 'ap_host']);
const INSTANCE_ROLES = new Set(['primary', 'standby']);

// Expected instance counts by role for a database's topology (spec §10.1). The
// standby cluster node count is fixed at 2 for primary+standby; RAC carries a
// custom node_count. A VM (node) hosts one instance in the wizard's clean
// generation, so the node count equals the total instance count.
function expectedInstanceCounts(topology, nodeCount) {
  switch (topology) {
    case 'single': return { primary: 1, standby: 0 };
    case 'primary': return { primary: 2, standby: 0 };
    case 'primary_standby': return { primary: 2, standby: 2 };
    case 'rac': return { primary: nodeCount, standby: 0 };
    default: return null;
  }
}

const isNonEmptyString = (v) => typeof v === 'string' && v.trim() !== '';
const isPositiveInt = (v) => Number.isInteger(v) && v > 0;
const isNonNegNumber = (v) => typeof v === 'number' && Number.isFinite(v) && v >= 0;
// A JSON column value: an object/array is re-stringified for storage; null/absent
// stays absent (DB default). A non-object is rejected by the caller's field check.
const jsonForStore = (v) => (v !== null && typeof v === 'object' ? JSON.stringify(v) : v);

/**
 * Validate the whole payload PURELY (no I/O) and, on success, return the resolved
 * build plan (minted ids + resolved intra-batch links). Returns
 * `{ ok:false, errors:[string] }` or `{ ok:true, plan }`. Structural coherence +
 * topology counts are checked here; the CATALOGUE reference-integrity check runs
 * later against the DB (needs the FOR-UPDATE lock).
 */
function buildWizardPlan(body) {
  const errors = [];
  const b = body && typeof body === 'object' ? body : {};

  const name = isNonEmptyString(b.name) ? b.name.trim() : '';
  if (!name) errors.push('name is required');
  else if (name.length > MAX_NAME) errors.push(`name exceeds ${MAX_NAME} characters`);

  let note = null;
  if (b.description != null) {
    if (typeof b.description !== 'string') errors.push('description must be a string');
    else if (b.description.length > MAX_DESCRIPTION) errors.push(`description exceeds ${MAX_DESCRIPTION} characters`);
    else note = b.description;
  }
  if (b.bundle_id != null && typeof b.bundle_id !== 'string') {
    errors.push('bundle_id must be a string');
  }

  const asArray = (key) => {
    const v = b[key];
    if (v === undefined || v === null) return [];
    if (!Array.isArray(v)) { errors.push(`${key} must be an array`); return []; }
    return v;
  };
  const sites = asArray('sites');
  const hypervisors = asArray('hypervisors');
  const databases = asArray('databases');
  const vms = asArray('vms');
  const dbInstances = asArray('db_instances');

  // DoS bounds (Review Gate H1): reject an oversized array BEFORE any per-row
  // loop or transaction. Returned as a distinct `tooLarge` result so the route
  // answers 413 (payload too large) rather than a per-row 400.
  const boundsErrors = [];
  if (hypervisors.length > MAX_HYPERVISORS) boundsErrors.push(`hypervisors exceeds the maximum of ${MAX_HYPERVISORS} rows`);
  if (databases.length > MAX_DATABASES) boundsErrors.push(`databases exceeds the maximum of ${MAX_DATABASES} rows`);
  if (vms.length > MAX_VMS) boundsErrors.push(`vms exceeds the maximum of ${MAX_VMS} rows`);
  if (dbInstances.length > MAX_DB_INSTANCES) boundsErrors.push(`db_instances exceeds the maximum of ${MAX_DB_INSTANCES} rows`);
  if (boundsErrors.length) return { ok: false, tooLarge: true, errors: boundsErrors };

  // A bare-string field check helper that records a per-entity error.
  const label = (entity, i) => `${entity}[${i}]`;
  // metadata field check: must be an object (or absent) and within the byte cap.
  const metaError = (entity, i, meta) => {
    if (meta != null && typeof meta !== 'object') return `${label(entity, i)}: metadata must be an object`;
    if (metadataTooLarge(meta)) return `${label(entity, i)}: metadata exceeds ${MAX_METADATA_BYTES} bytes`;
    // Reject a reserved prototype key (__proto__/constructor/prototype) — the
    // reject-at-the-source invariant, shared with the import / child-CRUD paths.
    const rk = reservedMetadataKeyError(meta);
    if (rk) return `${label(entity, i)}: ${rk.message}`;
    return null;
  };

  // ── sites ────────────────────────────────────────────────────────────────
  if (sites.length < 1) errors.push('at least one site is required');
  if (sites.length > MAX_SITES) errors.push(`a scenario may have at most ${MAX_SITES} sites`);
  const siteIdByRef = new Map();
  sites.forEach((row, i) => {
    const r = row && typeof row === 'object' ? row : {};
    if (!isNonEmptyString(r.ref)) { errors.push(`${label('sites', i)}: ref is required`); return; }
    if (siteIdByRef.has(r.ref)) errors.push(`${label('sites', i)}: duplicate ref "${r.ref}"`);
    if (!isNonEmptyString(r.name)) errors.push(`${label('sites', i)}: name is required`);
    else if (r.name.length > MAX_NAME) errors.push(`${label('sites', i)}: name exceeds ${MAX_NAME} characters`);
    const siteMeta = metaError('sites', i, r.metadata); if (siteMeta) errors.push(siteMeta);
    siteIdByRef.set(r.ref, uuidv4());
  });

  // ── databases ────────────────────────────────────────────────────────────
  const dbByRef = new Map(); // ref → { id, topology, node_count }
  databases.forEach((row, i) => {
    const r = row && typeof row === 'object' ? row : {};
    if (!isNonEmptyString(r.ref)) { errors.push(`${label('databases', i)}: ref is required`); return; }
    if (dbByRef.has(r.ref)) errors.push(`${label('databases', i)}: duplicate ref "${r.ref}"`);
    if (!isNonEmptyString(r.function_name)) errors.push(`${label('databases', i)}: function_name is required`);
    else if (r.function_name.length > MAX_NAME) errors.push(`${label('databases', i)}: function_name exceeds ${MAX_NAME} characters`);
    if (!TOPOLOGIES.has(r.topology)) errors.push(`${label('databases', i)}: topology must be one of single, primary, primary_standby, rac`);
    let nodeCount = null;
    if (r.topology === 'rac') {
      if (!isPositiveInt(r.node_count) || r.node_count < RAC_MIN_NODES || r.node_count > RAC_MAX_NODES) {
        errors.push(`${label('databases', i)}: RAC node_count must be an integer >= ${RAC_MIN_NODES} and <= ${RAC_MAX_NODES}`);
      } else {
        nodeCount = r.node_count;
      }
    }
    if (r.description != null) {
      if (typeof r.description !== 'string') errors.push(`${label('databases', i)}: description must be a string`);
      else if (r.description.length > MAX_DESCRIPTION) errors.push(`${label('databases', i)}: description exceeds ${MAX_DESCRIPTION} characters`);
    }
    // Row-level SGA seeds (spec §5.3 C1 / §6.1): inheritance-semantic nullable —
    // absent/null means "derive" (primary → profile cap / standby → the
    // scenario-effective standby default). A present value must be a non-negative
    // number; it both persists onto cap_databases and drives the per-instance
    // sga_gb derivation (deriveInstanceSga, spec §6.3).
    for (const sgaCol of ['primary_sga_gb', 'standby_sga_gb']) {
      if (r[sgaCol] == null) continue;
      if (!isNonNegNumber(r[sgaCol])) {
        errors.push(`${label('databases', i)}: ${sgaCol} must be a non-negative number`);
      } else if (!Number.isInteger(r[sgaCol])) {
        // SGA is accepted as whole numbers only (fmb-1433); the wizard floors it
        // client-side, so a fraction here is a caller that skipped the wizard.
        errors.push(`${label('databases', i)}: ${sgaCol} must be a whole number`);
      }
    }
    // dc_refs (spec §5.3 C3): the placement-candidate DC restriction. Absent/null/
    // empty = all DCs; a present value must be an array of site refs that each
    // resolve to a site in THIS payload (persisted as the minted site ids). A stale
    // ref is rejected — the wizard only ever sends live refs.
    if (r.dc_refs != null) {
      if (!Array.isArray(r.dc_refs)) errors.push(`${label('databases', i)}: dc_refs must be an array`);
      else r.dc_refs.forEach((ref, j) => {
        if (!isNonEmptyString(ref) || !siteIdByRef.has(ref)) errors.push(`${label('databases', i)}: dc_refs[${j}] does not match a site`);
      });
    }
    const dbMeta = metaError('databases', i, r.metadata); if (dbMeta) errors.push(dbMeta);
    dbByRef.set(r.ref, { id: uuidv4(), topology: r.topology, node_count: nodeCount });
  });

  // ── hypervisors ──────────────────────────────────────────────────────────
  hypervisors.forEach((row, i) => {
    const r = row && typeof row === 'object' ? row : {};
    if (!isNonEmptyString(r.name)) errors.push(`${label('hypervisors', i)}: name is required`);
    else if (r.name.length > MAX_NAME) errors.push(`${label('hypervisors', i)}: name exceeds ${MAX_NAME} characters`);
    if (!isNonEmptyString(r.site_ref) || !siteIdByRef.has(r.site_ref)) {
      errors.push(`${label('hypervisors', i)}: site_ref does not match a site`);
    }
    if (!isNonEmptyString(r.spec_id)) errors.push(`${label('hypervisors', i)}: spec_id is required`);
    const hvMeta = metaError('hypervisors', i, r.metadata); if (hvMeta) errors.push(hvMeta);
  });

  // ── vms ──────────────────────────────────────────────────────────────────
  const vmByRef = new Map(); // ref → { id, vm_type }
  vms.forEach((row, i) => {
    const r = row && typeof row === 'object' ? row : {};
    if (!isNonEmptyString(r.ref)) { errors.push(`${label('vms', i)}: ref is required`); return; }
    if (vmByRef.has(r.ref)) errors.push(`${label('vms', i)}: duplicate ref "${r.ref}"`);
    if (!isNonEmptyString(r.name)) errors.push(`${label('vms', i)}: name is required`);
    else if (r.name.length > MAX_NAME) errors.push(`${label('vms', i)}: name exceeds ${MAX_NAME} characters`);
    if (!VM_TYPES.has(r.vm_type)) errors.push(`${label('vms', i)}: vm_type must be db_host or ap_host`);
    if (!isNonEmptyString(r.site_ref) || !siteIdByRef.has(r.site_ref)) {
      errors.push(`${label('vms', i)}: site_ref does not match a site`);
    }
    // database_ref is a db_host-only NON-NORMATIVE hint (§10.3); an ap_host VM
    // must not carry one, and a set value must resolve to a batch database.
    if (r.database_ref != null) {
      if (r.vm_type === 'ap_host') errors.push(`${label('vms', i)}: an ap_host VM cannot reference a database`);
      else if (!dbByRef.has(r.database_ref)) errors.push(`${label('vms', i)}: database_ref does not match a database`);
    }
    for (const numCol of ['cpu', 'mem_gb', 'disk_gb']) {
      if (r[numCol] != null && !isNonNegNumber(r[numCol])) errors.push(`${label('vms', i)}: ${numCol} must be a non-negative number`);
    }
    const vmMeta = metaError('vms', i, r.metadata); if (vmMeta) errors.push(vmMeta);
    vmByRef.set(r.ref, { id: uuidv4(), vm_type: r.vm_type });
  });

  // ── db_instances + topology coherence ────────────────────────────────────
  // Tally instances per (database ref, role) so the counts can be checked
  // against each database's topology after the loop.
  const perDbCounts = new Map(); // dbRef → { primary, standby }
  const instancePlan = [];
  dbInstances.forEach((row, i) => {
    const r = row && typeof row === 'object' ? row : {};
    if (!isNonEmptyString(r.name)) errors.push(`${label('db_instances', i)}: name is required`);
    else if (r.name.length > MAX_NAME) errors.push(`${label('db_instances', i)}: name exceeds ${MAX_NAME} characters`);
    if (!INSTANCE_ROLES.has(r.role)) errors.push(`${label('db_instances', i)}: role must be primary or standby`);
    const vm = isNonEmptyString(r.vm_ref) ? vmByRef.get(r.vm_ref) : undefined;
    if (!vm) errors.push(`${label('db_instances', i)}: vm_ref does not match a VM`);
    else if (vm.vm_type !== 'db_host') errors.push(`${label('db_instances', i)}: vm_ref must reference a db_host VM`);
    const db = isNonEmptyString(r.database_ref) ? dbByRef.get(r.database_ref) : undefined;
    if (!db) errors.push(`${label('db_instances', i)}: database_ref does not match a database`);
    if (r.sga_gb != null && !isNonNegNumber(r.sga_gb)) errors.push(`${label('db_instances', i)}: sga_gb must be a non-negative number`);
    const instMeta = metaError('db_instances', i, r.metadata); if (instMeta) errors.push(instMeta);
    // A standby instance is legal only under a primary+standby database (§10.1).
    if (db && r.role === 'standby' && db.topology !== 'primary_standby') {
      errors.push(`${label('db_instances', i)}: a standby instance is only allowed under a primary_standby database`);
    }
    if (db && INSTANCE_ROLES.has(r.role)) {
      const tally = perDbCounts.get(r.database_ref) || { primary: 0, standby: 0 };
      tally[r.role] += 1;
      perDbCounts.set(r.database_ref, tally);
    }
    if (vm && db) {
      instancePlan.push({
        id: uuidv4(), row: r, vmId: vm.id, dbId: db.id,
      });
    }
  });

  // Every database's per-role instance count must match its topology (spec §10.1).
  for (const [ref, meta] of dbByRef) {
    const expected = expectedInstanceCounts(meta.topology, meta.node_count);
    if (!expected) continue; // an invalid topology already recorded an error above
    const got = perDbCounts.get(ref) || { primary: 0, standby: 0 };
    if (got.primary !== expected.primary || got.standby !== expected.standby) {
      errors.push(
        `databases ref "${ref}" (${meta.topology}): expected ${expected.primary} primary + `
        + `${expected.standby} standby instance(s), got ${got.primary} + ${got.standby}`,
      );
    }
  }

  if (errors.length) return { ok: false, errors };

  return {
    ok: true,
    plan: {
      name, note, siteIdByRef, dbByRef, vmByRef,
      sites, hypervisors, databases, vms, instancePlan,
    },
  };
}

// Collect the CATALOGUE reference specs (real global-catalogue ids) the payload
// carries, deduplicated by (table, id) so the FOR-UPDATE probe runs once per
// distinct catalogue row. Intra-batch links (site/database/vm) are NOT here —
// they are resolved in memory, not against the DB.
function collectCatalogueSpecs(plan) {
  const seen = new Set();
  const specs = [];
  const add = (column, value, table) => {
    if (value == null) return;
    const dedupeKey = `${table}:${value}`;
    if (seen.has(dedupeKey)) return;
    seen.add(dedupeKey);
    specs.push({ column, value, table, mode: 'catalogue' });
  };
  for (const h of plan.hypervisors) add('spec_id', h.spec_id, TABLES.CAP_HARDWARE_SPECS);
  for (const d of plan.databases) {
    add('profile_id', d.profile_id, TABLES.CAP_VM_PROFILES);
    add('disk_combo_id', d.disk_combo_id, TABLES.CAP_DISK_COMBOS);
    add('team_id', d.team_id, TABLES.CAP_TEAMS);
  }
  for (const v of plan.vms) {
    add('sizing_profile_id', v.sizing_profile_id, TABLES.CAP_VM_PROFILES);
    add('disk_combo_id', v.disk_combo_id, TABLES.CAP_DISK_COMBOS);
    add('team_id', v.team_id, TABLES.CAP_TEAMS);
  }
  return specs;
}

// Every catalogue FK the plan carries, as (row, column, table) — ONE list, read
// by both the check that resolves these references and the rewrite that binds
// what it resolved. Two lists here would be two opinions about which columns are
// references, and the rewrite would silently skip whichever one they disagreed
// about.
function catalogueFkSites(plan) {
  const sites = [];
  for (const h of plan.hypervisors) sites.push([h, 'spec_id', TABLES.CAP_HARDWARE_SPECS]);
  for (const d of plan.databases) {
    sites.push([d, 'profile_id', TABLES.CAP_VM_PROFILES]);
    sites.push([d, 'disk_combo_id', TABLES.CAP_DISK_COMBOS]);
    sites.push([d, 'team_id', TABLES.CAP_TEAMS]);
  }
  for (const v of plan.vms) {
    sites.push([v, 'sizing_profile_id', TABLES.CAP_VM_PROFILES]);
    sites.push([v, 'disk_combo_id', TABLES.CAP_DISK_COMBOS]);
    sites.push([v, 'team_id', TABLES.CAP_TEAMS]);
  }
  return sites;
}

/**
 * Rewrite every catalogue FK in the plan to the id the reference check resolved
 * it to. A column whose value is null, or one the check did not answer for, is
 * left exactly as it was.
 */
function applyCanonicalCatalogueIds(plan, canonical) {
  if (!canonical) return;
  for (const [row, column, table] of catalogueFkSites(plan)) {
    const value = row[column];
    if (value == null) continue;
    const stored = canonical.get(canonicalKey(table, value));
    if (stored != null) row[column] = stored;
  }
}

// Profile-class coherence (bundles.js `checkItemProfileClass` parity, R2): the
// §17.1a check only confirms a profile FK is a legal (global/same-scenario) row —
// it does NOT confirm the profile's CLASS. A db_host VM and every database must
// reference a DB-class profile; an ap_host VM must reference an AP-class profile.
// Runs inside the caller's transaction so the class read sees the same rows the
// §17.1a check already locked FOR UPDATE. A missing profile is left to the §17.1a
// check (skipped here). Returns `{ code, message }` on mismatch, else null.
async function checkProfileClasses(conn, plan) {
  const wants = []; // { column, profileId, expected }
  for (const d of plan.databases) {
    if (d.profile_id != null) wants.push({ column: `databases ref "${d.ref}" profile_id`, profileId: d.profile_id, expected: 'DB' });
  }
  for (const v of plan.vms) {
    if (v.sizing_profile_id == null) continue;
    const expected = v.vm_type === 'db_host' ? 'DB' : 'AP';
    wants.push({ column: `vms ref "${v.ref}" sizing_profile_id`, profileId: v.sizing_profile_id, expected });
  }
  if (!wants.length) return null;

  const classById = new Map();
  for (const id of new Set(wants.map((w) => w.profileId))) {
    const rows = await conn.query(
      `SELECT class FROM \`${t(TABLES.CAP_VM_PROFILES)}\` WHERE id = ?`, [id],
    );
    if (rows.length) classById.set(id, rows[0].class);
  }
  for (const w of wants) {
    const actual = classById.get(w.profileId);
    if (actual != null && actual !== w.expected) {
      return {
        code: 'INVALID_REFERENCE',
        message: `${w.column} must reference a ${w.expected}-class profile (referenced profile is ${actual}-class)`,
      };
    }
  }
  return null;
}

// Hydrate the catalogue rows the server-side sizing derivation (TA.1) + the
// disk-combo allow-list check (TA.2) need, read on the IN-TX (already FOR-UPDATE
// locked) connection. Returns { profileById, comboSizesById, formula, dbProfileById }.
// Only queries when a profile / combo id is actually referenced (a payload with no
// catalogue refs adds no reads).
async function loadSizingContext(conn, plan) {
  const profileIds = new Set();
  const comboIds = new Set();
  for (const v of plan.vms) {
    if (v.sizing_profile_id != null) profileIds.add(v.sizing_profile_id);
    if (v.disk_combo_id != null) comboIds.add(v.disk_combo_id);
  }
  for (const d of plan.databases) {
    if (d.profile_id != null) profileIds.add(d.profile_id);
    if (d.disk_combo_id != null) comboIds.add(d.disk_combo_id);
  }

  const profileById = new Map();
  if (profileIds.size) {
    const rows = await selectByRequestedId(
      conn, TABLES.CAP_VM_PROFILES,
      'p.class, p.mode, p.cpu, p.mem_gb, p.sga_cap_gb, p.allowed_disk_combos',
      [...profileIds],
    );
    for (const r of rows) profileById.set(r.requested_id, r);
  }

  const comboSizesById = new Map();
  if (comboIds.size) {
    const rows = await selectByRequestedId(conn, TABLES.CAP_DISK_COMBOS, 'p.sizes', [...comboIds]);
    for (const r of rows) {
      const gb = sumDiskComboSizes(r.sizes);
      // A referenced combo with empty/malformed `sizes` derives disk_gb = 0 — the
      // exact silent-zero class this derivation exists to kill. Persist the 0 (the
      // derivation stays unchanged) but surface it so an operator can spot the
      // mis-seeded combo instead of shipping a silently zero-disk VM.
      if (!(gb > 0)) {
        logger.warn({ combo_id: r.id }, `Derived zero disk_gb from disk combo ${r.id} (empty or malformed sizes)`);
      }
      comboSizesById.set(r.requested_id, gb);
    }
  }

  let formula = { ...DEFAULT_FORMULA };
  // A STANDBY instance needs the scenario-effective standby-default setting
  // (§6.3) even when no VM/database in the payload references a sizing
  // profile at all — so the settings row is read whenever either a profile
  // OR any standby instance is present, not gated on profileIds alone.
  const needsSettingsRow = profileIds.size > 0
    || plan.instancePlan.some((inst) => inst.row.role === 'standby');
  let settingsRow = null;
  if (needsSettingsRow) {
    const srows = await conn.query(
      `SELECT mem_cpu_ratio, sga_factor, sga_divisor, sga_subtract, standby_sga_default_gb `
      + `FROM \`${t(TABLES.CAP_SETTINGS)}\` WHERE scenario_id IS NULL LIMIT 1`,
    );
    settingsRow = srows[0] || null;
    formula = readFormulaConstants(settingsRow);
  }

  // Minted database id → its profile_id (VM sizing derivation, TA.1) and its
  // own primary_sga_gb/standby_sga_gb (spec §6.3 instance-sga derivation).
  // The latter two fields ride on the SAME validated database spec row but
  // are not yet WRITTEN by this endpoint (wizard payload/insert wiring for
  // cap_databases.primary_sga_gb/standby_sga_gb is PR-4's C1) — reading them
  // here now is forward-compatible and a no-op until then (`?? null`
  // resolves through deriveInstanceSga's own fallback chain exactly like an
  // explicit null).
  const dbProfileById = new Map();
  const dbSgaByDb = new Map();
  for (const d of plan.databases) {
    const meta = plan.dbByRef.get(d.ref);
    if (!meta) continue;
    dbProfileById.set(meta.id, d.profile_id ?? null);
    dbSgaByDb.set(meta.id, { primary_sga_gb: d.primary_sga_gb ?? null, standby_sga_gb: d.standby_sga_gb ?? null });
  }

  return {
    profileById, comboSizesById, formula, dbProfileById, dbSgaByDb, settingsRow,
  };
}

// The database profile's SGA cap (DB-class formula/custom), else 0 when the
// database has no profile or an AP-class one (not derivable).
function profileSgaCapForDb(dbId, ctx) {
  const profileId = ctx.dbProfileById.get(dbId);
  const sizing = profileId != null
    ? resolveProfileSizing(ctx.profileById.get(profileId), ctx.formula)
    : null;
  return sizing && sizing.sgaCapGb != null ? sizing.sgaCapGb : 0;
}

// TA.2: enforce the disk-combo allow-list (spec §5.3) on the RESULTING wizard
// rows. A VM/database that pairs a profile with a disk combo outside that
// profile's allow-list is rejected 400. A missing profile is left to the §17.1a
// check; a null/empty allow-list is unrestricted (soft-list parity). Returns a
// human message on the FIRST violation, else null.
function validateWizardDiskCombos(plan, profileById) {
  const check = (label, profileId, comboId) => {
    if (profileId == null || comboId == null) return null;
    const profile = profileById.get(profileId);
    if (!profile) return null; // §17.1a owns a missing/foreign profile
    if (diskComboAllowed(profile.allowed_disk_combos, comboId)) return null;
    return `${label}: disk_combo_id is not in the chosen profile's allowed disk combos`;
  };
  for (const v of plan.vms) {
    const err = check(`vms ref "${v.ref}"`, v.sizing_profile_id ?? null, v.disk_combo_id ?? null);
    if (err) return err;
  }
  for (const d of plan.databases) {
    const err = check(`databases ref "${d.ref}"`, d.profile_id ?? null, d.disk_combo_id ?? null);
    if (err) return err;
  }
  return null;
}

// Derive a VM's persisted { cpu, mem_gb, disk_gb } (TA.1). A profiled row's
// cpu/mem_gb are SERVER-derived from the profile (client cpu/mem_gb ignored — the
// profile-lock contract 2); a row with a disk combo takes disk_gb from the combo's
// summed sizes. A no-profile ("Custom") row keeps the client cpu/mem_gb; a row
// with no disk combo keeps the client disk_gb. The client-value fallback survives
// ONLY for the genuinely non-derivable case (no `?? 0` remains for a derivable field).
function deriveVmSizing(row, ctx) {
  const sizing = row.sizing_profile_id != null
    ? resolveProfileSizing(ctx.profileById.get(row.sizing_profile_id), ctx.formula)
    : null;
  const cpu = sizing ? sizing.cpu : (row.cpu ?? 0);
  const memGb = sizing ? sizing.memGb : (row.mem_gb ?? 0);
  const diskGb = row.disk_combo_id != null && ctx.comboSizesById.has(row.disk_combo_id)
    ? ctx.comboSizesById.get(row.disk_combo_id)
    : (row.disk_gb ?? 0);
  return { cpu, mem_gb: memGb, disk_gb: diskGb };
}

// Resolve one instancePlan entry + the sizing context into the shared
// derive-by-role helper's args (sga-defaults.js `deriveInstanceSga`, spec
// §6.3). REPLACES the legacy per-instance client-override + standby-mirrors-
// primary logic entirely (spec §4.3 B5): sga_gb is now derived ONLY from the
// database-level primary_sga_gb/standby_sga_gb and the scenario-effective
// standby default — never from a client-supplied instance value (a legacy
// caller's `sga_gb` field is silently ignored, per the never-block
// invariant, not rejected).
function resolveInstanceSga(inst, ctx) {
  const database = ctx.dbSgaByDb.get(inst.dbId) ?? null;
  const profile = { sgaCapGb: profileSgaCapForDb(inst.dbId, ctx) };
  return deriveInstanceSga(inst.row.role, database, ctx.settingsRow, profile);
}

// Insert one row with an explicit backtick-quoted column list. `cols` is an
// ordered [name, value] list; null/undefined values are still written (the DB
// applies its own default only when the column is absent, so an explicit null is
// intentional for a nullable FK).
async function insertRow(conn, table, cols) {
  const names = cols.map(([c]) => `\`${c}\``).join(', ');
  const placeholders = cols.map(() => '?').join(', ');
  const values = cols.map(([, v]) => v);
  await conn.query(
    `INSERT INTO \`${t(table)}\` (${names}) VALUES (${placeholders})`,
    values,
  );
}

// POST /scenarios/wizard — bespoke bulk create. Registered ahead of the generic
// scenario + child mounts (index.js) so /scenarios/wizard is not shadowed.
router.post('/scenarios/wizard', async (req, res) => {
  if (!requireAdminOrEditor(req, res)) return;

  const built = buildWizardPlan(req.body || {});
  if (!built.ok) {
    const e = built.tooLarge
      ? apiError('Wizard payload is too large', 'PAYLOAD_TOO_LARGE', 413, { details: built.errors })
      : apiError('Wizard payload is invalid', 'BAD_REQUEST', 400, { details: built.errors });
    return res.status(e.status).json(e.body);
  }
  const plan = built.plan;

  // Owner-scope mirrors scenario create (spec §7): an editor stamps the actor; an
  // admin leaves owner_id NULL (shared). A client-supplied owner_id is ignored.
  const ownerId = req.user.role === 'editor' ? req.user.id : null;
  const scenarioId = uuidv4();

  let conn;
  try {
    conn = await pool.rw.getConnection();
    await conn.beginTransaction();

    // §17.1a catalogue reference-integrity under a FOR-UPDATE lock: every catalogue
    // FK must reference a GLOBAL (or same-scenario, none yet) row, and the lock
    // holds the referenced rows so a concurrent catalogue delete cannot dangle the
    // FK between this check and the INSERTs (bundles.js protocol).
    const catalogueSpecs = collectCatalogueSpecs(plan);
    if (catalogueSpecs.length) {
      const result = await checkReferences(conn, scenarioId, catalogueSpecs, { lock: true });
      if (!result.ok) {
        await safeRollback(conn);
        const e = apiError(result.message, result.code, 400);
        return res.status(e.status).json(e.body);
      }
      // AND THE ROWS NOW CARRY WHAT THE CHECK RESOLVED. The check asks the
      // COLUMN which row each spelling names — `id` is `CHAR(36)` under a
      // case-folding collation — so it passes for a spelling the catalogue row
      // does not hold, and every INSERT below binds its value straight out of
      // `plan`. Rewriting them here, once, is what makes the answer the check
      // arrived at the value the statements store: the alternative is a stored
      // `sizing_profile_id` that resolves the profile in SQL and resolves
      // NOTHING for the front end's `.find(p => p.id === vm.sizing_profile_id)`.
      applyCanonicalCatalogueIds(plan, result.canonical);
    }

    // Profile-class coherence (db_host/database → DB, ap_host → AP), read under
    // the lock the §17.1a check just took (bundles.js parity).
    const classResult = await checkProfileClasses(conn, plan);
    if (classResult) {
      await safeRollback(conn);
      const e = apiError(classResult.message, classResult.code, 400);
      return res.status(e.status).json(e.body);
    }

    // Hydrate the catalogue rows for server-side sizing derivation (TA.1) + the
    // disk-combo allow-list check (TA.2), read under the lock the §17.1a check
    // took. Both run BEFORE any INSERT so a violation writes nothing.
    const sizingCtx = await loadSizingContext(conn, plan);
    const diskComboError = validateWizardDiskCombos(plan, sizingCtx.profileById);
    if (diskComboError) {
      await safeRollback(conn);
      const e = apiError(diskComboError, 'DISK_COMBO_NOT_ALLOWED', 400);
      return res.status(e.status).json(e.body);
    }

    // Scenario row (reference model: nothing is copied).
    await insertRow(conn, TABLES.CAP_SCENARIOS, [
      ['id', scenarioId], ['name', plan.name], ['owner_id', ownerId], ['note', plan.note],
    ]);

    // Sites. order_index = array position (phase-2 spec §4.3 B1) — the
    // wizard's own site ORDER is the sole author of DC display order; every
    // DC-ordered read (grid, placement, PNG) sorts by it so they agree.
    for (let i = 0; i < plan.sites.length; i += 1) {
      const row = plan.sites[i];
      await insertRow(conn, TABLES.CAP_SITES, [
        ['id', plan.siteIdByRef.get(row.ref)], ['scenario_id', scenarioId],
        ['name', row.name], ['order_index', i], ['metadata', jsonForStore(row.metadata ?? null)],
      ]);
    }

    // Hypervisors (site_id resolved from the batch; spec_id is a global catalogue id).
    // order_index = array position (phase-4 spec §6, mirroring sites): the wizard's
    // own row order authors the grid / placement / PNG display order, so a
    // wizard-created scenario has a deterministic order without a first drag.
    for (let i = 0; i < plan.hypervisors.length; i += 1) {
      const row = plan.hypervisors[i];
      await insertRow(conn, TABLES.CAP_HYPERVISORS, [
        ['id', uuidv4()], ['scenario_id', scenarioId],
        ['site_id', plan.siteIdByRef.get(row.site_ref)], ['spec_id', row.spec_id],
        ['name', row.name], ['order_index', i], ['metadata', jsonForStore(row.metadata ?? null)],
      ]);
    }

    // Databases. order_index = array position (phase-6 spec §D8, mirroring the
    // other reorderable entities): the wizard's own row order authors the
    // Databases tab display order without a first drag.
    for (let i = 0; i < plan.databases.length; i += 1) {
      const row = plan.databases[i];
      const meta = plan.dbByRef.get(row.ref);
      // dc_refs (spec §5.3 C3): map the validated client site refs to the minted
      // site ids and store as a JSON array; an empty/absent selection stays NULL
      // (= all DCs), inheritance-semantic — never coalesced.
      const dcIds = Array.isArray(row.dc_refs) && row.dc_refs.length
        ? row.dc_refs.map((ref) => plan.siteIdByRef.get(ref))
        : null;
      await insertRow(conn, TABLES.CAP_DATABASES, [
        ['id', meta.id], ['scenario_id', scenarioId],
        ['function_name', row.function_name], ['topology', row.topology],
        ['node_count', meta.node_count], ['profile_id', row.profile_id ?? null],
        ['disk_combo_id', row.disk_combo_id ?? null], ['team_id', row.team_id ?? null],
        // Row-level SGA seeds (spec §5.3 C1 / §6.1): inheritance-semantic nullable
        // — an explicit null persists "derive/use-default", never coalesced. These
        // are the SAME values loadSizingContext feeds deriveInstanceSga, so the
        // persisted database row and its instances' derived sga_gb agree.
        ['primary_sga_gb', row.primary_sga_gb ?? null], ['standby_sga_gb', row.standby_sga_gb ?? null],
        ['dc_refs', jsonForStore(dcIds)],
        ['description', row.description ?? null], ['order_index', i],
        ['metadata', jsonForStore(row.metadata ?? null)],
      ]);
    }

    // VMs (site-pinned, host-UNPLACED → hypervisor_id NULL; database_id is the
    // db_host-only non-normative generation hint, §10.3).
    for (let i = 0; i < plan.vms.length; i += 1) {
      const row = plan.vms[i];
      const databaseId = row.vm_type === 'db_host' && row.database_ref != null
        ? plan.dbByRef.get(row.database_ref).id
        : null;
      // Server-derived sizing (TA.1): profiled rows get profile CPU/MEM, disk from
      // the chosen combo — no `?? 0` fall-through for a derivable field.
      const sizing = deriveVmSizing(row, sizingCtx);
      // order_index = array position (phase-4 spec §6, mirroring sites).
      await insertRow(conn, TABLES.CAP_VMS, [
        ['id', plan.vmByRef.get(row.ref).id], ['scenario_id', scenarioId],
        ['vm_type', row.vm_type], ['hypervisor_id', null],
        ['site_id', plan.siteIdByRef.get(row.site_ref)],
        ['cpu', sizing.cpu], ['mem_gb', sizing.mem_gb], ['disk_gb', sizing.disk_gb],
        ['sizing_profile_id', row.sizing_profile_id ?? null],
        ['disk_combo_id', row.disk_combo_id ?? null], ['team_id', row.team_id ?? null],
        ['database_id', databaseId], ['name', row.name], ['order_index', i],
        ['metadata', jsonForStore(row.metadata ?? null)],
      ]);
    }

    // DB instances (vm_id + database_id resolved to minted ids).
    // order_index = array position (phase-4 spec §6, mirroring sites).
    for (let i = 0; i < plan.instancePlan.length; i += 1) {
      const inst = plan.instancePlan[i];
      const row = inst.row;
      await insertRow(conn, TABLES.CAP_DB_INSTANCES, [
        ['id', inst.id], ['scenario_id', scenarioId],
        ['vm_id', inst.vmId], ['database_id', inst.dbId],
        ['name', row.name], ['role', row.role], ['sga_gb', resolveInstanceSga(inst, sizingCtx)],
        ['order_index', i], ['metadata', jsonForStore(row.metadata ?? null)],
      ]);
    }

    await conn.commit();

    return res.status(201).json(apiOk({
      id: scenarioId,
      counts: {
        sites: plan.sites.length,
        hypervisors: plan.hypervisors.length,
        databases: plan.databases.length,
        vms: plan.vms.length,
        db_instances: plan.instancePlan.length,
      },
    }));
  } catch (err) {
    await safeRollback(conn);
    logger.error({ err, scenarioId }, `Failed to create capacity scenario via wizard id=${scenarioId}`);
    const e = apiError('Database operation failed', 'INTERNAL_ERROR', 500);
    return res.status(e.status).json(e.body);
  } finally {
    if (conn) conn.release();
  }
});

module.exports = router;
module.exports.buildWizardPlan = buildWizardPlan;
module.exports.expectedInstanceCounts = expectedInstanceCounts;
