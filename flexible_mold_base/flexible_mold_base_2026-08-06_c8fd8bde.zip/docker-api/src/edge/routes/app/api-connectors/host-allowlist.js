/**
 * host-allowlist.js — GET /host-allowlist — admin/editor, returns the raw
 * stored value of the global connector egress allow-list from system_settings.
 *
 * Accessible to editors (not admin-only) so the connector editor and list page
 * can render the allow-list enforcement state without requiring an admin session.
 * The setting key is non-secret (host patterns, not credentials); only the write
 * path (ConnectorAllowlistTab) requires admin-level access via a separate route.
 *
 * Returns: { value: <raw stored value> | null, defaultDeny: boolean }
 *   value: null → key is absent from system_settings (opt-in allow-all)
 *   value: array → stored host-pattern list (may be empty, invalid strings, etc.)
 *   value: any other JSON → present but corrupt (caller parses; backend fails closed)
 *   defaultDeny → the admin deny-by-default flag (empty list blocks dispatch when on)
 */
const { apiOk, apiError, requireAdminOrEditor } = require('../../../../shared/helpers');
const { fetchAllowlistRawValue } = require('../../../../shared/lib/host-allowlist');
const { loadEgressDefaultDeny } = require('../../../../shared/lib/egress-policy');
const { logger: rootLogger } = require('../../../../shared/lib/logger');

const logger = rootLogger.child({ module: 'api-connectors-host-allowlist' });

function register(router) {
  // Lazy-required so the pool (which requires mariadb) is only loaded when the
  // router is actually wired up at server boot — not at module-require time.
  const { pool, t } = require('../../../db'); // eslint-disable-line global-require

  router.get('/host-allowlist', async (req, res) => {
    if (!requireAdminOrEditor(req, res)) return;

    try {
      const query = (sql, params) => pool.ro.query(sql, params);
      const [value, defaultDeny] = await Promise.all([
        fetchAllowlistRawValue(query, t),
        loadEgressDefaultDeny(query, t),
      ]);
      return res.json(apiOk({ value, defaultDeny }));
    } catch (err) {
      logger.error({ err }, 'failed to read connector host allow-list');
      const e = apiError('Database operation failed', 'INTERNAL_ERROR');
      return res.status(e.status).json(e.body);
    }
  });
}

module.exports = register;
