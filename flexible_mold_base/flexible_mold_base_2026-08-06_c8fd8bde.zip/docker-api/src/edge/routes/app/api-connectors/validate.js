/**
 * validate.js — shared write-shape validators for api_connectors.
 *
 * The chain-wiring check lives here so every write path (create, update, import)
 * holds a payload to the exact same shape contract — a malformed
 * input_from_step would otherwise be stored and surface as a confusing runtime
 * chain break instead of a friendly 400 at the boundary.
 */

/**
 * Validate request_config.input_from_step against the chain-wiring contract.
 *
 * @param {unknown} requestConfig - the connector's request_config (parsed object or null)
 * @param {unknown} sequence - the connector's own sequence (integer, or undefined/null)
 * @returns {string|null} an error message when invalid, or null when OK / absent
 */
function validateInputFromStep(requestConfig, sequence) {
  if (!requestConfig || typeof requestConfig !== 'object') return null;
  const ifs = requestConfig.input_from_step;
  if (ifs == null) return null;
  if (!Array.isArray(ifs)) return 'request_config.input_from_step must be an array';
  for (const e of ifs) {
    if (!e || typeof e !== 'object') return 'input_from_step entries must be objects';
    if (typeof e.var !== 'string' || !e.var.trim()) return 'input_from_step var must be a non-empty string';
    if (!Number.isInteger(e.from_sequence) || e.from_sequence < 1) return 'input_from_step from_sequence must be a positive integer';
    if (typeof e.path !== 'string' || !e.path.trim()) return 'input_from_step path must be a non-empty string';
    if (Number.isInteger(sequence) && e.from_sequence >= sequence) {
      return 'input_from_step from_sequence must reference an earlier step (smaller than this connector\'s sequence)';
    }
  }
  // INVARIANT: declaring step wiring requires declaring your own step position
  // in the same write — otherwise the earlier-step check above is skipped and a
  // self/future from_sequence reaches the DB, surfacing as a runtime chain
  // failure instead of this friendly 400. Empty array / null still pass without
  // a sequence so clearing wiring stays easy.
  if (ifs.length > 0 && !Number.isInteger(sequence)) {
    return 'sequence is required when declaring input_from_step';
  }
  return null;
}

// List-filter comparison operators, mirrored from the FE FilterOp union
// (src/fmb/hooks/useApiConnectors.ts). Kept in lockstep with the apply engine's
// accepted ops; a rows-sink join key may compare with any of these.
const FILTER_OPS = new Set(['eq', 'neq', 'contains', 'gt', 'lt', 'gte', 'lte', 'in']);

/**
 * Validate response_config.outputs[] rows-sink `match` blocks against the
 * enrich-by-key contract. A `to:rows` sink may carry an optional `match`
 * ({row_column, element_field, op?}) to enrich existing rows by key instead of
 * creating one row per element; a PARTIAL match (one join key missing) is a
 * malformed config that would silently degrade at runtime, so reject it here
 * with a friendly 400.
 *
 * @param {unknown} responseConfig - the connector's response_config (parsed object or null)
 * @returns {string|null} an error message when invalid, or null when OK / absent
 */
function validateResponseOutputs(responseConfig) {
  if (!responseConfig || typeof responseConfig !== 'object') return null;
  const outputs = responseConfig.outputs;
  if (outputs == null) return null;
  if (!Array.isArray(outputs)) return 'response_config.outputs must be an array';
  for (const o of outputs) {
    if (!o || typeof o !== 'object') continue;
    const to = o.to;
    if (!to || typeof to !== 'object' || to.mode !== 'rows') continue;
    if (to.order_by != null) {
      if (!Array.isArray(to.order_by)) return 'rows-sink order_by must be an array';
      for (const k of to.order_by) {
        if (!k || typeof k !== 'object') return 'rows-sink order_by entry must be an object';
        if (typeof k.column !== 'string' || !k.column.trim()) return 'rows-sink order_by entry must have a non-empty string column';
        if (k.dir !== 'asc' && k.dir !== 'desc') return "rows-sink order_by entry dir must be 'asc' or 'desc'";
      }
      // Defense in depth (Fix 3): order_by is meaningless on a join sink — the
      // apply engine skips the join fan-out path and the FE editor hides the
      // control for mergeRows. Reject the combination at the write boundary so
      // a hand-edited import can't store an incoherent config that silently does
      // nothing at runtime.
      if (to.match != null) {
        return 'rows-sink order_by cannot be combined with match (join); order_by only applies to create-rows fan-out';
      }
    }
    if (to.match == null) {
      // No join key declared = create-rows fan-out; on_no_match is meaningless
      // without a match, so a stray value here is a malformed config.
      if (to.on_no_match != null && to.on_no_match !== 'skip') return "rows-sink on_no_match must be 'skip' when present";
      continue;
    }
    if (typeof to.match !== 'object') return 'rows-sink match must be an object';
    // The match may be the legacy single-pair shape ({row_column, element_field,
    // op?}) or the composite keys[] shape; a row matches an element iff EVERY key
    // matches. Validate each key (accepting either shape via the legacy fallback).
    const rawKeys = Array.isArray(to.match.keys) ? to.match.keys : [to.match];
    if (rawKeys.length === 0) return 'rows-sink match must declare at least one key';
    let allEq = true;
    for (const m of rawKeys) {
      if (!m || typeof m !== 'object') return 'rows-sink match key must be an object';
      if (typeof m.row_column !== 'string' || !m.row_column.trim()) return 'rows-sink match.row_column must be a non-empty string';
      if (typeof m.element_field !== 'string' || !m.element_field.trim()) return 'rows-sink match.element_field must be a non-empty string';
      if (m.op != null && !FILTER_OPS.has(m.op)) return `rows-sink match.op must be one of: ${[...FILTER_OPS].join(', ')}`;
      if ((m.op ?? 'eq') !== 'eq') allEq = false;
    }
    // A join may skip unmatched elements or create a row for each (upsert).
    if (to.on_no_match != null && to.on_no_match !== 'skip' && to.on_no_match !== 'create') {
      return "rows-sink on_no_match must be 'skip' or 'create' when present";
    }
    // Upsert-by-key is only well-defined under equality on EVERY key (the FE
    // guards this too); a non-eq key has no unique-row identity to create against.
    if (to.on_no_match === 'create' && !allEq) {
      return "rows-sink on_no_match 'create' requires every match key op to be 'eq'";
    }
  }
  return null;
}

/**
 * Validate request_config.input_cells[] row indices. A 1-based `row` marks a
 * fixed single-cell input (resolved once); when present it must be a positive
 * integer, else the runtime cell binding silently breaks.
 *
 * @param {unknown} requestConfig - the connector's request_config (parsed object or null)
 * @returns {string|null} an error message when invalid, or null when OK / absent
 */
function validateInputCells(requestConfig) {
  if (!requestConfig || typeof requestConfig !== 'object') return null;
  const cells = requestConfig.input_cells;
  if (cells == null) return null;
  if (!Array.isArray(cells)) return 'request_config.input_cells must be an array';
  for (const c of cells) {
    if (!c || typeof c !== 'object') continue;
    if (c.row != null && (!Number.isInteger(c.row) || c.row < 1)) {
      return 'input_cells row must be a positive integer when present';
    }
  }
  return null;
}

/**
 * Normalize a rows-sink `match` to the composite keys[] shape, mirroring the FE
 * twin (src/fmb/lib/connectors/row-match.ts). Accepts the legacy single-pair
 * shape ({row_column, element_field, op?}) and the keys[] shape; drops a
 * fully-blank key and an invalid op. Returns undefined when no key survives.
 *
 * @param {unknown} raw - the stored/parsed match block
 * @returns {{keys: Array<{row_column: string, element_field: string, op?: string}>}|undefined}
 */
function normalizeRowMatch(raw) {
  if (!raw || typeof raw !== 'object') return undefined;
  const rawKeys = Array.isArray(raw.keys) ? raw.keys : [raw];
  const keys = [];
  for (const k of rawKeys) {
    if (!k || typeof k !== 'object') continue;
    const row_column = typeof k.row_column === 'string' ? k.row_column : '';
    const element_field = typeof k.element_field === 'string' ? k.element_field : '';
    if (!row_column && !element_field) continue;
    const op = (typeof k.op === 'string' && FILTER_OPS.has(k.op)) ? k.op : undefined;
    keys.push(op ? { row_column, element_field, op } : { row_column, element_field });
  }
  return keys.length ? { keys } : undefined;
}

/**
 * Validate cross-field connector coherence, mirroring the editor's save-time
 * guards (src/fmb/components/admin/api-connectors/connector-save-guards.ts) so a
 * hand-edited import or a raw API write is held to the same contract the editor
 * enforces — otherwise an incoherent connector reaches the DB and degrades
 * silently at runtime (getTableBinding picks one table, the fan-out modal drops
 * a mixed output) instead of surfacing as a friendly 400.
 *
 * Kept in lockstep with the FE module; the error strings are byte-identical so
 * the same message surfaces whichever boundary rejects.
 *
 * @param {unknown} requestConfig - the connector's request_config (parsed object or null)
 * @param {unknown} responseConfig - the connector's response_config (parsed object or null)
 * @returns {string|null} an error message when incoherent, or null when OK / absent
 */
function validateConnectorCoherence(requestConfig, responseConfig) {
  const outputs = responseConfig && typeof responseConfig === 'object' && Array.isArray(responseConfig.outputs)
    ? responseConfig.outputs
    : [];

  // Fan-out (Table rows) is single-purpose: a rows output cannot mix with
  // field/cell outputs, and there can be only one. Mixed/multiple rows outputs
  // are silently dropped at apply time.
  const rowsCount = outputs.filter((o) => o && o.to && typeof o.to === 'object' && o.to.mode === 'rows').length;
  if (rowsCount > 0) {
    if (rowsCount !== outputs.length) return 'A fan-out connector can only have Table rows outputs.';
    if (rowsCount > 1) return 'A fan-out connector can have only one Table rows output.';
  }

  // Only AND (match:'all') filters are implemented; a cell-sourced filter value
  // resolves via a single per-output override, so it is valid only in a
  // single-condition filter.
  for (const o of outputs) {
    if (!o || !o.from || typeof o.from !== 'object' || o.from.mode !== 'list' || !o.from.where) continue;
    const where = o.from.where;
    if (where.match !== 'all') {
      return 'Filter match must be "all" (AND); "any" (OR) is not supported.';
    }
    if (Array.isArray(where.conditions) && where.conditions.length > 1
      && where.conditions.some((c) => c && c.value && c.value.kind === 'cell')) {
      return 'A cell-sourced filter value is only allowed in a single-condition filter.';
    }
  }

  const cells = requestConfig && typeof requestConfig === 'object' && Array.isArray(requestConfig.input_cells)
    ? requestConfig.input_cells
    : [];
  const isValidCell = (c) => Boolean(
    c && typeof c === 'object' && c.table_key && typeof c.var === 'string' && c.var.trim()
      && (c.source === 'manual' || c.column_key),
  );
  // A per-row cell is a valid cell with no numeric `row` (a fixed cell pins a row
  // and single-fetches). Runtime per-row dispatch keys off this, not the stored
  // mode — a create-rows fan-out (rows output WITHOUT a match) is scalar-input
  // only, so it can never run bound to a per-row cell.
  const hasPerRowCell = cells.some((c) => isValidCell(c) && typeof c.row !== 'number');
  if (hasPerRowCell && outputs.some((o) => o && o.to && o.to.mode === 'rows' && !o.to.match)) {
    return 'A fan-out (Table rows) connector must use scalar inputs — it cannot bind table-cell inputs.';
  }

  // Table-coherence: a connector with a table input cell must reference exactly
  // one table (across input cells + cell outputs) and bind a single input cell —
  // the per-row dispatch sends one variable per row, so a second table/cell is
  // silently dropped. Triggered by a valid input cell (mirrors the FE
  // requestMode==='table' on normalized stored data); a scalar connector that
  // writes a fixed cell output but has no table input is left untouched.
  if (cells.some(isValidCell)) {
    const tableKeys = new Set();
    cells.forEach((c) => { if (c && c.table_key) tableKeys.add(c.table_key); });
    outputs.forEach((o) => { if (o && o.to && o.to.mode === 'cell' && o.to.table_key) tableKeys.add(o.to.table_key); });
    if (tableKeys.size > 1) return 'All table cells must reference one table field.';
    // Count only column cells (not manual cells) toward the "only one table input column" limit
    const columnCells = cells.filter((c) => isValidCell(c) && c.column_key);
    if (columnCells.length > 1) return 'A table connector supports only one table input column.';
  }

  return null;
}

module.exports = { validateInputFromStep, validateResponseOutputs, validateInputCells, validateConnectorCoherence, normalizeRowMatch, FILTER_OPS };
