/**
 * api-connectors/index.js — router assembly for the API Connectors feature.
 *
 * End-user (non-admin) routes are registered FIRST so they are not subject to
 * the blanket admin gate that follows:
 *   GET /usable     — minimal projection for data-entry users (requireAuth)
 *
 * Dispatch (POST /:id/fetch) is now handled by infra via the edge-internal
 * /edge/internal/connectors/prepare endpoint. This router no longer registers
 * a fetch route.
 *
 * Admin-only routes (CRUD + io) are registered after the gate:
 *   serializeWrite / serializeRead: encrypt secrets on write, mask on read.
 *   io.js: cross-environment export (no secrets) / import (unbound fallback),
 *   registered before the CRUD router so /import and /:id/export match ahead of
 *   the generic /:id handler. blueprint_id / is_active are the filterable columns.
 */
const express = require('express');
const { pool, t } = require('../../../db');
const { createCrudRoutes } = require('../schema');
// The one resolver for "which database is this request about" — the same one the
// factory this guard is mounted beside uses to pick the pool it writes to.
const { resolveRwPool } = require('../schema/request-pool');
const { enumColumnsFor } = require('../../../lib/schema-manifest');
const { requireAdminOrEditor, apiError } = require('../../../../shared/helpers');
const { TABLES } = require('../../../../shared/constants');
const { logger } = require('../../../../shared/lib/logger');
const { serializeWrite, serializeRead } = require('./serializer');
const { validateInputFromStep, validateResponseOutputs, validateInputCells, validateConnectorCoherence } = require('./validate');
const { egressAllowedForUrl } = require('../../../../shared/lib/egress-policy');
// Shared url guard: absolute http(s) with NO embedded credentials (userinfo in a
// url is never legit — auth belongs in auth_config; a stored userinfo url leaks a
// Basic-auth secret in the plaintext url column + on export).
const { isStorableHttpUrl } = require('../../../../shared/lib/portable-url-redaction');

const router = express.Router();

// Shared 400 envelope for the write-shape guards below — one definition so the
// code/shape can't drift between the bundle-fields and chain-wiring checks.
const badRequest = (res, message) =>
  res.status(400).json({ ok: false, error: { code: 'BAD_REQUEST', message } });

// End-user (non-admin) routes MUST be registered BEFORE the blanket admin gate
// below. Data-entry users read a minimal projection (usable.js enforces it) and
// fire a connector; they never see url/auth/templates.
require('./usable')(router);     // GET /usable        (requireAuth, projection)

// Everything below is admin-OR-editor: secrets stay masked (serializeRead),
// and writes are owner-scoped by the CRUD factory (ownerColumn + parentOwnership).
// Editors see every connector's metadata (endpoint, auth-header names) by design
// — the same view-all contract as user_templates. Plain users never reach here
// (they get the minimal /usable projection above).
router.use((req, res, next) => {
  if (!requireAdminOrEditor(req, res)) return;
  next();
});

// SECURITY: pin the stored url to an absolute http(s) URL (no userinfo) at the
// write boundary (dispatch executes it). The shared CRUD factory has no per-field
// 400 hook, so validate POST/PUT here (the /import path validates its own payload).
router.use((req, res, next) => {
  if ((req.method === 'POST' || req.method === 'PUT') && req.path !== '/import'
      && req.body && Object.prototype.hasOwnProperty.call(req.body, 'url')) {
    if (!isStorableHttpUrl(req.body.url)) {
      return res.status(400).json({ ok: false, error: { code: 'BAD_REQUEST', message: 'url must be an absolute http(s) URL' } });
    }
  }
  next();
});

// SECURITY: save-time mirror of the dispatch-time global egress allow-list gate
// (edge /prepare). Reject a create/update whose url+method+path is off the admin
// allow-list, so the operator gets a fast 422 at save instead of a silent
// EGRESS_BLOCKED only when they later try to fetch. Empty list = allow-all
// (opt-in). Only fires when `url` is present (a partial PUT not touching the url
// is unaffected). Method defaults to the connector default (GET) when a partial
// PUT omits it; the dispatch gate re-checks with the stored method as the
// backstop. /import carries the url in its own payload and clone reads it
// server-side from the source row, so neither passes through this body-`url`
// guard; both run the same egressAllowedForUrl gate inline in their handlers.
router.use(async (req, res, next) => {
  if ((req.method !== 'POST' && req.method !== 'PUT') || req.path === '/import') return next();
  if (!req.body || !Object.prototype.hasOwnProperty.call(req.body, 'url')) return next();
  try {
    const egress = await egressAllowedForUrl(req.body.url, req.body.method || 'GET', (sql, params) => pool.ro.query(sql, params), t);
    if (!egress.ok) {
      return res.status(422).json({ ok: false, error: { code: 'EGRESS_BLOCKED', message: 'Connector request is not on the admin egress allow-list', reason: egress.reason } });
    }
  } catch (err) {
    logger.error({ err }, 'connector egress allow-list save check failed');
    return res.status(500).json({ ok: false, error: { code: 'INTERNAL_ERROR', message: 'Database operation failed' } });
  }
  return next();
});

// Bundle-field consistency: group metadata is all-or-nothing. Without a
// group_id the other three are forced NULL (no orphan label/mode/sequence);
// with one, mode+sequence are required and shape-checked here so a bad value
// gets a friendly 400 instead of a DB enum/type 500.
//
// A PARTIAL UPDATE THAT OMITS `group_id` HAS SAID NOTHING ABOUT IT. This guard
// used to fire on "any of the four keys is present", then find `group_id`
// ABSENT — `undefined == null` — and read that as "the caller means ungrouped",
// writing four NULLs. So `PUT {"group_label":"New label"}`, a label rename and
// the most ordinary edit there is, silently removed the connector from its
// bundle; on a chain group that also broke every sibling's `input_from_step`
// wiring, which references members by sequence. The all-or-nothing invariant is
// unchanged — what changes is which fact establishes the bundle: the body's
// `group_id` when the body names it, and otherwise the STORED one, exactly as
// the import path reasons about the same fields.
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const GROUP_FIELDS = ['group_id', 'group_label', 'group_mode', 'sequence'];
router.use(async (req, res, next) => {
  if ((req.method !== 'POST' && req.method !== 'PUT') || req.path === '/import' || !req.body) return next();
  const b = req.body;
  const touched = GROUP_FIELDS.some((k) => Object.prototype.hasOwnProperty.call(b, k));
  if (!touched) return next();
  const bad = (msg) => badRequest(res, msg);
  const namesGroupId = Object.prototype.hasOwnProperty.call(b, 'group_id');

  // The body does not name the bundle, so the row's own bundle is the effective
  // one. Only reachable on a PUT: a create has no stored row, and its absent
  // `group_id` genuinely does mean ungrouped.
  const rowIdMatch = req.path.match(/^\/([^/]+)$/);
  if (!namesGroupId && req.method === 'PUT' && rowIdMatch) {
    let storedGroupId = null;
    try {
      // Read on the write pool: the question is what the row this statement is
      // about to update belongs to, and a replica's answer is a different row's.
      //
      // AND ON THE WRITE POOL THIS REQUEST IS ABOUT. A request may carry `db`,
      // naming a Custom API connection; the factory resolves it and writes there,
      // while the static `pool.rw` this used to read asked the DEFAULT database.
      // Both of its answers were wrong and both were 200s: no row there, so the
      // four bundle fields fell through UNVALIDATED — the orphan state this
      // branch exists to prevent — or a same-id row there, so the decision was
      // taken about a different record entirely.
      const rows = await (await resolveRwPool(req)).query(
        `SELECT group_id FROM \`${t(TABLES.API_CONNECTORS)}\` WHERE id = ?`,
        [rowIdMatch[1]],
      );
      if (!rows.length) return next(); // absent row → the CRUD path answers 404
      storedGroupId = rows[0].group_id;
    } catch (err) {
      // Fail-closed: an unverifiable bundle state must not be written past.
      logger.error({ err, id: rowIdMatch[1] }, 'connector bundle-state probe failed');
      const e = apiError('Database operation failed', 'INTERNAL_ERROR');
      return res.status(e.status).json(e.body);
    }
    if (storedGroupId == null) {
      // Ungrouped, and the body did not say otherwise — the three remaining
      // fields have no bundle to belong to. Degraded to NULL rather than
      // refused, matching how the import path treats the same incoherence: they
      // would otherwise be orphan values that /usable and the chain runner read
      // as membership.
      b.group_label = null; b.group_mode = null; b.sequence = null;
      return next();
    }
    // Grouped. The present fields are judged against that bundle; the absent
    // ones keep what the row holds.
    if (Object.prototype.hasOwnProperty.call(b, 'group_mode')
      && b.group_mode !== 'aggregation' && b.group_mode !== 'chain') {
      return bad("group_mode must be 'aggregation' or 'chain' when group_id is set");
    }
    if (Object.prototype.hasOwnProperty.call(b, 'sequence')
      && (!Number.isInteger(b.sequence) || b.sequence < 1)) {
      return bad('sequence must be a positive integer when group_id is set');
    }
    if (b.group_label != null && (typeof b.group_label !== 'string' || b.group_label.length > 255)) {
      return bad('group_label must be a string ≤ 255 characters');
    }
    return next();
  }

  if (b.group_id == null || b.group_id === '') {
    b.group_id = null; b.group_label = null; b.group_mode = null; b.sequence = null;
    return next();
  }
  if (typeof b.group_id !== 'string' || !UUID_RE.test(b.group_id)) return bad('group_id must be a UUID');
  if (b.group_mode !== 'aggregation' && b.group_mode !== 'chain') return bad("group_mode must be 'aggregation' or 'chain' when group_id is set");
  if (!Number.isInteger(b.sequence) || b.sequence < 1) return bad('sequence must be a positive integer when group_id is set');
  if (b.group_label != null && (typeof b.group_label !== 'string' || b.group_label.length > 255)) return bad('group_label must be a string ≤ 255 characters');
  return next();
});

// Chain-wiring shape check: request_config.input_from_step is consumed by the
// data-entry chain runner; a malformed entry would surface as a confusing
// runtime chain break, so reject it at the write boundary with a friendly 400.
// NOTE: shape-only by design — input_from_step on a non-chain connector is
// accepted and stored (the chain runner only reads it for chain-mode groups,
// and the admin editor normalizes it away on non-chain saves). Rejecting by
// mode here would break the opaque round-trip contract for imports/exports.
router.use((req, res, next) => {
  if ((req.method !== 'POST' && req.method !== 'PUT') || req.path === '/import' || !req.body) return next();
  const msg = validateInputFromStep(req.body.request_config, req.body.sequence)
    || validateInputCells(req.body.request_config)
    || validateResponseOutputs(req.body.response_config)
    || validateConnectorCoherence(req.body.request_config, req.body.response_config);
  if (msg) return badRequest(res, msg);
  return next();
});

// Per-connector timeout bounds. NULL/absent = system default. Otherwise an
// integer in [1000, 120000] ms (1–120 s). Defense-in-depth behind the editor's
// own clamp so a raw API call can't store a 0 / negative / connection-wedging
// value. Scoped to POST/PUT (the only body-bearing writes of timeout_ms);
// PATCH /:id/owner carries no connector columns, so it is intentionally outside.
const TIMEOUT_MIN_MS = 1000;
const TIMEOUT_MAX_MS = 120000;
router.use((req, res, next) => {
  if ((req.method !== 'POST' && req.method !== 'PUT') || req.path === '/import' || !req.body) return next();
  if (!Object.prototype.hasOwnProperty.call(req.body, 'timeout_ms')) return next();
  const v = req.body.timeout_ms;
  if (v == null) { req.body.timeout_ms = null; return next(); }
  if (!Number.isInteger(v) || v < TIMEOUT_MIN_MS || v > TIMEOUT_MAX_MS) {
    return badRequest(res, `timeout_ms must be an integer between ${TIMEOUT_MIN_MS} and ${TIMEOUT_MAX_MS} (ms), or null`);
  }
  return next();
});

// SECURITY: connectors are never shared (owner_id is stamped on every POST),
// but the generic CRUD owner predicate treats a NULL owner_id as a shared row
// any editor may write. A degraded/seeded NULL-owned connector must therefore
// be admin-only to modify — reject non-admin PUT/DELETE on such a row here
// (admin bypasses; the CRUD factory still enforces owner-or-NULL for the rest).
// Fail-closed on probe error: an unverifiable owner state must not be mutated.
//
// ASKED OF THE DATABASE THIS REQUEST IS ABOUT, and on the pool the write lands
// on. This guard predates the bundle probe below it and had the same two faults,
// on the same rows and the same verbs: the static pool ignores a request's `db`
// override, so it asked the DEFAULT database about an id living in another and
// admitted the write on "no such row"; and `ro` may address a replica, so a
// gate about the row a statement is about to write could be decided from a
// stale copy of it.
router.use(async (req, res, next) => {
  if (req.method !== 'PUT' && req.method !== 'DELETE') return next();
  if (!req.user || req.user.role === 'admin') return next();
  const m = req.path.match(/^\/([^/]+)$/); // the row id, not a nested path
  if (!m) return next();
  try {
    const rows = await (await resolveRwPool(req)).query(
      `SELECT owner_id FROM \`${t(TABLES.API_CONNECTORS)}\` WHERE id = ?`,
      [m[1]],
    );
    if (rows.length && rows[0].owner_id == null) {
      const e = apiError('This connector has no owner; only an admin can modify it', 'FORBIDDEN', 403);
      return res.status(e.status).json(e.body);
    }
    return next();
  } catch (err) {
    logger.error({ err, id: m[1] }, 'connector null-owner guard probe failed');
    const e = apiError('Database operation failed', 'INTERNAL_ERROR');
    return res.status(e.status).json(e.body);
  }
});

require('./io')(router);

// Admin/editor health derive, registered before the CRUD catch-all so `/health`
// is not captured by the generic `/:id` GET (same ordering rule as io's
// `/import`).
require('./health')(router);

// Admin/editor allow-list read, registered before the CRUD catch-all so
// `/host-allowlist` is not captured by the generic `/:id` GET.
require('./host-allowlist')(router);

// Owner reassign (PATCH /:id/owner) — registered before the CRUD `/:id` so it
// is not shadowed by the factory's PUT/DELETE. Admin transfers any connector;
// the current owner transfers their own.
require('./reassign')(router);

// Clone (POST /:id/clone) — registered before the CRUD `/:id` so it is not
// shadowed by the factory's catch-all. Copies the source connector (encrypted
// secrets included, server-side) into a new owner-stamped row.
require('./clone')(router);

// Approval lifecycle (PATCH /:id/approve, /:id/reject) + the create/edit status
// middleware — registered before the CRUD `/:id` so the PATCH routes are not
// shadowed and the status stamp runs ahead of the factory's INSERT/UPDATE.
require('./approval')(router);
// The columns whose change re-pends this connector are declared beside the
// approval lifecycle they belong to, and read here — one list, not two.
const { SENSITIVE_SCALAR } = require('./approval');

router.use('/', createCrudRoutes('api_connectors', {
  // owner_id is stamped to the creator on POST (every role, never NULL — so a
  // connector is never "shared"); editor PUT/DELETE is scoped to their own row.
  // `ownerColumn` strips owner_id from a NON-admin body only, so an
  // administrator's generic PUT could still hand this record to anybody —
  // through the CRUD factory, with none of what makes the dedicated transfer
  // endpoint safe: no check that the target exists, no check that they may hold
  // it, no resolution of the id to the spelling the column stores, and no audit
  // line, which is the only record a transfer happened at all. `immutableColumns`
  // is role-agnostic — the property this needs and the one `ownerColumn` does
  // not have — so a transfer has exactly one route.
  //
  // Scoped to the mounts that HAVE that route rather than made a property of
  // `ownerColumn` in the factory: flow_recipes declares `ownerColumn` and has no
  // dedicated owner endpoint, so a role-agnostic strip in the shared layer would
  // remove its only way to change a recipe's owner.
  //
  // AND WHAT THAT SCOPING THEREFORE LEAVES flow_recipes DOING, said out loud
  // because the sentence above named it as the reason without saying so: its
  // generic PUT IS a transfer route. The shared binding was given the other two
  // facts this endpoint establishes rather than left with only the first — it
  // resolves the target, refuses one whose role the mount would not let act on
  // the record, and writes a `feature_audit` row once the scoped UPDATE has
  // matched. So the difference between a mount with a dedicated endpoint and one
  // without is now the shape of the request, not what is checked or recorded.
  immutableColumns: ['owner_id'],
  ownerColumn: 'owner_id',
  // Editors may author connectors; plain users cannot (blanket gate above).
  allowedRoles: ['admin', 'editor'],
  // Editor create must bind to a blueprint they own or that is shared (NULL
  // owner). Admin bypasses; a null blueprint_id from an editor is rejected
  // (must bind on create). Mirrors blueprint_fields' single-hop chain.
  parentOwnership: {
    via: 'blueprint_id',
    chain: [{ table: TABLES.HIERARCHY_NODES, match: 'id', readOwner: 'owner_id' }],
  },
  // SECURITY: owner_id is deliberately NOT filterable — an editor must not be
  // able to enumerate "all connectors owned by user X" via ?owner_id=<uuid>.
  filterableColumns: ['blueprint_id', 'is_active'],
  resolveOwnerName: 'owner_id',
  // THE DOMAIN IS THE TABLE'S, ASKED OF THE DDL — not a list of columns kept
  // here. `enumColumnsFor` answers for EVERY ENUM column the table declares, so
  // this mount cannot be missing one: the failure a per-column list produces is
  // not a wrong value but an omitted column, and `auth_type` was exactly that
  // omission. Without a domain, `PUT {"auth_type":"Bearer"}` reached the
  // serializer, which resolved no sensitive leaf for that spelling, stripped the
  // token the column was about to keep as `'bearer'`, and wrote `{}` over the
  // stored ciphertext with a 200.
  //
  // REFUSING THE SPELLING IS STRICTLY BETTER THAN FOLDING IT. The engine stores
  // `'Bearer'`, `'BEARER'`, `'bearer '` and the ordinal `2` as the one member
  // `'bearer'`; canonicalising them here would make this request work and leave
  // every later reader still comparing against a value the caller chose. The
  // caller sends what the column stores.
  enumColumns: enumColumnsFor(TABLES.API_CONNECTORS),
  serializeWrite,
  // The serializer resolves "a `****` leaf means unchanged" by reading the
  // stored ciphertext back and binding it — a decision about the row this
  // statement is about to update, which was being taken on `pool.ro`: another
  // pool, another connection, no transaction and no lock. It now runs inside the
  // update transaction and takes the row `FOR UPDATE`.
  serializeWriteInTx: true,
  // SECURITY: a change to where, how or with what credential shape this
  // connector connects clears its approval, inside the same transaction and the
  // same statement as the change itself. NULL is on the list of states this
  // fires from, and that is the row it closes: NULL means grandfathered =
  // dispatches, so an editor could re-point a grandfathered connector at a new
  // endpoint and it went on dispatching with no review at all. Which states
  // re-pend is review-status.js's answer, not this mount's.
  repandOnSensitiveChange: {
    statusCol: 'status',
    clearCols: ['approved_by', 'approved_at'],
    columns: SENSITIVE_SCALAR,
  },
  serializeRead,
}));

module.exports = router;
