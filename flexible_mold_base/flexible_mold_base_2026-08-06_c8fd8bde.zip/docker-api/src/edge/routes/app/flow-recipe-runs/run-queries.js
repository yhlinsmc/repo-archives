'use strict';

/**
 * run-queries.js — every statement the two run surfaces read, built in one place.
 *
 * WHY THE SQL IS BUILT HERE RATHER THAN INLINE IN THE ROUTE. A mocked route test
 * stubs the driver, so a column that does not exist produces a green test and a
 * 500 against a real database. The statements are therefore built by exported
 * functions and every column reference is written as `alias.\`column\``, which
 * lets `flow-run-aggregate-schema-parity.test.js` read the ACTUAL statement text,
 * resolve each alias through {@link SQL_ALIASES}, and require the column to exist
 * in `table-ddls.js`. A reference written any other way — a bare column name, an
 * alias this module does not declare — fails that test rather than passing it by
 * being invisible.
 *
 * WHY WINDOW FUNCTIONS ARE ALLOWED HERE. The grouped read needs the LAST run of
 * each group, not an aggregate of it, and a self-join on MAX(created_at) returns
 * two rows for two runs recorded in the same second — `created_at` is a TIMESTAMP
 * with one-second resolution on a table that records machine-driven dispatches.
 * MariaDB has had window functions since 10.2.0, and this schema already requires
 * 10.2.1 for the `DEFAULT (UUID())` clauses every table in `table-ddls.js` is
 * created with, so no database that can hold these tables lacks them.
 */
const { t } = require('../../../db');
const { TABLES } = require('../../../../shared/constants');

/** Table alias → logical table, for the parity test and for the reader.
 *
 *  The hierarchy alias that used to be declared here is gone with the read rule
 *  that needed it (`visibility.js`): no statement joins the hierarchy any more.
 *  A narrowing that brings the join back must declare its alias here, and the
 *  parity test says so by name if it does not. */
const SQL_ALIASES = Object.freeze({
  r: TABLES.FLOW_RECIPE_RUNS,
  ut: TABLES.USER_TEMPLATES,
  fr: TABLES.FLOW_RECIPES,
  u: TABLES.USERS,
});

/** Aliases that name a derived table rather than a real one. */
const DERIVED_ALIASES = Object.freeze(['g']);

/**
 * The fields the grouped read's derived table exposes. The outer query may
 * reference these and nothing else; the parity test holds it to that, which is
 * what keeps `g.` from becoming an unchecked way to name a column.
 */
const GROUP_DERIVED_FIELDS = Object.freeze([
  'template_id', 'last_run_id', 'last_status', 'last_actor_id',
  'last_run_at', 'run_count', 'rn',
]);

/**
 * What the first level may be ordered by, and the expression each name orders
 * on. A caller supplies the NAME; nothing a caller sends reaches the statement.
 *
 * The actor is ordered on the same coalesce the display name falls back
 * through, so the column reads in the order it is sorted in. It is ordered on
 * only — the visible name still comes from the shared enrichment, which is what
 * keeps an email out of the response.
 */
const GROUP_SORT_EXPRESSIONS = Object.freeze({
  template_name: 'ut.`name`',
  run_count: 'g.`run_count`',
  last_run_at: 'g.`last_run_at`',
  last_status: 'g.`last_status`',
  last_actor_name: 'COALESCE(u.`display_name`, u.`kc_username`)',
});

/** The order a caller gets when they ask for none: what happened lately. */
const DEFAULT_GROUP_SORT = Object.freeze({ field: 'last_run_at', dir: 'desc' });

/**
 * Whether a caller's `sort` value names one of the orderings above.
 *
 * The string check is not decoration. A repeated query parameter arrives as an
 * ARRAY, and a property lookup converts an array to its joined string, so
 * `?sort=run_count&sort=run_count` would pass a bare `hasOwnProperty` and then
 * travel on as an array through everything that echoes the field back. Nothing
 * unsafe reaches the statement either way — the expression is always read from
 * this table, never built from the value — but a field that is not a string is
 * not a field.
 *
 * `hasOwnProperty` rather than `in`, so `constructor` and `__proto__` name
 * nothing.
 */
function isGroupSortField(value) {
  return typeof value === 'string'
    && Object.prototype.hasOwnProperty.call(GROUP_SORT_EXPRESSIONS, value);
}

/**
 * One row per template.
 *
 * The count and the last run come from the same pass: `COUNT(*) OVER` counts the
 * partition the row is in and `ROW_NUMBER() OVER` names its newest member, so
 * the group's size and the run it is described by cannot come from two different
 * readings of the table. `id` breaks the ordering tie, because two runs can share
 * a second and a group described by whichever of them the engine happened to
 * return first would change between requests.
 *
 * A NULL `template_id` is one partition of its own — window partitioning treats
 * NULLs as equal, exactly as GROUP BY does — so runs recorded with no template
 * arrive as a group rather than disappearing into the join.
 *
 * THE TWO JOINS SIT OUTSIDE THE WINDOW PASS, over one row per group rather than
 * one per run: the template supplies the group's name, and the actor is joined
 * for the ORDER BY alone. Inside the pass they would be a lookup per run scanned
 * on a table that grows with every dispatch.
 *
 * The ordering is always total. Whatever it is sorted by, activity and then the
 * group key follow as tiebreakers, and after `rn = 1` the group key is unique —
 * a page is a window over an ordering, and an ordering with ties is not one.
 */
function buildGroupsSql(visibilitySql, sort) {
  const where = visibilitySql ? ` WHERE ${visibilitySql}` : '';
  const field = isGroupSortField(sort && sort.field) ? sort.field : DEFAULT_GROUP_SORT.field;
  const dir = (sort && sort.dir === 'asc') ? 'ASC' : 'DESC';
  const expression = GROUP_SORT_EXPRESSIONS[field];
  // NULLS LAST in both directions, the rule every other list read in this
  // application follows: two of these expressions are nullable — a group whose
  // template is gone has no name, and an actor whose account is gone has none
  // either — and without it an A-to-Z sort leads with the rows that have no
  // letter to sort on.
  const primary = `${expression} IS NULL, ${expression} ${dir}`;
  // Activity then the group key make the order total. The tiebreaker on
  // activity is dropped when it IS the ordering, so the statement does not
  // repeat a term it already carries.
  const tiebreakers = field === 'last_run_at'
    ? ['g.`template_id` DESC']
    : ['g.`last_run_at` DESC', 'g.`template_id` DESC'];
  // The last run's OWN blueprint is deliberately not selected. The path drawn
  // beside a first-level entry is the template's current blueprint — that is
  // what the entry names — so a second, historical blueprint id travelled the
  // whole statement and was read by nothing.
  return 'SELECT g.`template_id`, g.`run_count`, g.`last_run_at`, g.`last_run_id`,'
    + ' g.`last_status`, g.`last_actor_id`,'
    + ' ut.`id` AS template_row_id, ut.`name` AS template_name,'
    + ' ut.`blueprint_id` AS template_blueprint_id, ut.`variant_id` AS template_variant_id'
    + ' FROM ('
    + ' SELECT r.`template_id` AS template_id,'
    + ' r.`id` AS last_run_id,'
    + ' r.`status` AS last_status,'
    + ' r.`actor_id` AS last_actor_id,'
    + ' r.`created_at` AS last_run_at,'
    + ' COUNT(*) OVER (PARTITION BY r.`template_id`) AS run_count,'
    + ' ROW_NUMBER() OVER (PARTITION BY r.`template_id`'
    + ' ORDER BY r.`created_at` DESC, r.`id` DESC) AS rn'
    + ` FROM \`${t(TABLES.FLOW_RECIPE_RUNS)}\` r${where}`
    + ') g'
    + ` LEFT JOIN \`${t(TABLES.USER_TEMPLATES)}\` ut ON ut.\`id\` = g.\`template_id\``
    + ` LEFT JOIN \`${t(TABLES.USERS)}\` u ON u.\`id\` = g.\`last_actor_id\``
    + ' WHERE g.`rn` = 1'
    + ` ORDER BY ${[primary, ...tiebreakers].join(', ')}`
    + ' LIMIT ? OFFSET ?';
}

/**
 * How many groups the caller can see — counted over the same predicate the rows
 * are read under, so the total behind a page can never describe a wider set than
 * the page is drawn from.
 */
function buildGroupCountSql(visibilitySql) {
  const where = visibilitySql ? ` WHERE ${visibilitySql}` : '';
  return 'SELECT COUNT(*) AS cnt FROM ('
    + ` SELECT 1 FROM \`${t(TABLES.FLOW_RECIPE_RUNS)}\` r${where}`
    + ' GROUP BY r.`template_id`) g';
}

/**
 * The group predicate. A group is identified by its template id, and the group
 * of runs recorded WITHOUT one is identified by the absence of it — `= NULL` is
 * never true, so the two cases cannot share a comparison.
 */
function groupPredicate(templateId) {
  return templateId === null
    ? { sql: 'r.`template_id` IS NULL', params: [] }
    : { sql: 'r.`template_id` = ?', params: [templateId] };
}

/** The list columns for one group's runs. The three large snapshot columns are
 *  deliberately absent: a history list renders none of them, and one of them is
 *  bounded only by LONGTEXT. `input_snapshot` is read as a document only for the
 *  difference indicator, and only through the variant below. */
const RUN_LIST_COLUMNS = Object.freeze([
  'id', 'created_at', 'started_at', 'finished_at', 'status', 'actor_id',
  'result_link', 'external_flow_id', 'error_summary', 'blueprint_id',
]);

/**
 * One group's runs, newest first.
 *
 * `withSnapshot` selects the additive `input_snapshot` column. A database whose
 * operator account could not run the ALTER does not have it, and the statement
 * then fails with 1054; the caller re-issues without it and every row reports
 * its difference as unavailable, which is the truth on that database.
 *
 * `id` joins the ordering for the same reason it does in the grouped read: a
 * page is a window over an ordering and `created_at` alone is not one.
 */
function buildGroupRunsSql(visibilitySql, groupSql, { withSnapshot }) {
  const cols = RUN_LIST_COLUMNS.map((c) => `r.\`${c}\``);
  if (withSnapshot) cols.push('r.`input_snapshot`');
  const predicates = [groupSql];
  if (visibilitySql) predicates.push(visibilitySql);
  return `SELECT ${cols.join(', ')}`
    + ` FROM \`${t(TABLES.FLOW_RECIPE_RUNS)}\` r`
    + ` WHERE ${predicates.join(' AND ')}`
    + ' ORDER BY r.`created_at` DESC, r.`id` DESC'
    + ' LIMIT ? OFFSET ?';
}

/** How many runs the caller can see in one group. */
function buildGroupRunsCountSql(visibilitySql, groupSql) {
  const predicates = [groupSql];
  if (visibilitySql) predicates.push(visibilitySql);
  return 'SELECT COUNT(*) AS cnt'
    + ` FROM \`${t(TABLES.FLOW_RECIPE_RUNS)}\` r`
    + ` WHERE ${predicates.join(' AND ')}`;
}

/**
 * The columns a comparison reads, beside the two snapshot documents.
 *
 * `template_id` is selected although nothing renders it: the comparison is
 * offered within one template's history and the route refuses a selection that
 * spans more than one, so the statement has to return the value that refusal is
 * decided on rather than trusting the caller's grouping.
 */
const RUN_COMPARE_COLUMNS = Object.freeze([
  'id', 'created_at', 'status', 'actor_id', 'template_id', 'output_snapshot',
]);

/**
 * A named handful of runs, for reading side by side.
 *
 * WHY THE IDS ARE PLACEHOLDERS AND THE COUNT IS THE ONLY THING BUILT IN. An `IN`
 * list is the one place a statement's SHAPE depends on how many values arrive,
 * so the count is what varies and every value still travels as a parameter. The
 * caller bounds the count before it gets here.
 *
 * `withSnapshot` behaves exactly as it does in the list read: a database whose
 * operator account could not run the ALTER does not have the column, the
 * statement fails with 1054, and the caller re-issues without it — every run
 * then reports that its answers were not recorded, which is the truth there.
 *
 * Ordered oldest first, because the OLDEST selected run is the baseline the
 * others are marked against and a comparison reads left to right from it.
 */
function buildRunsByIdSql(visibilitySql, count, { withSnapshot }) {
  const cols = RUN_COMPARE_COLUMNS.map((c) => `r.\`${c}\``);
  if (withSnapshot) cols.push('r.`input_snapshot`');
  const predicates = [`r.\`id\` IN (${Array.from({ length: count }, () => '?').join(', ')})`];
  if (visibilitySql) predicates.push(visibilitySql);
  return `SELECT ${cols.join(', ')}`
    + ` FROM \`${t(TABLES.FLOW_RECIPE_RUNS)}\` r`
    + ` WHERE ${predicates.join(' AND ')}`
    + ' ORDER BY r.`created_at` ASC, r.`id` ASC';
}

/**
 * The most recent run of one group that this caller can see — the run a dispatch
 * about to be made will be compared against.
 *
 * The same ordering and the same read rule as the list, so the confirmation
 * names the run the history will show above the new one. The rule is currently
 * "no restriction" (`visibility.js`), and building this statement through the
 * same predicate is what keeps that true of the confirmation too if it narrows.
 */
function buildLatestGroupRunSql(visibilitySql, groupSql, { withSnapshot }) {
  const cols = ['r.`id`', 'r.`created_at`', 'r.`actor_id`'];
  if (withSnapshot) cols.push('r.`input_snapshot`');
  const predicates = [groupSql];
  if (visibilitySql) predicates.push(visibilitySql);
  return `SELECT ${cols.join(', ')}`
    + ` FROM \`${t(TABLES.FLOW_RECIPE_RUNS)}\` r`
    + ` WHERE ${predicates.join(' AND ')}`
    + ' ORDER BY r.`created_at` DESC, r.`id` DESC'
    + ' LIMIT 1';
}

/** One template's own row, for the second-level page header. */
function buildTemplateByIdSql() {
  return 'SELECT ut.`id`, ut.`name`, ut.`blueprint_id`, ut.`variant_id`'
    + ` FROM \`${t(TABLES.USER_TEMPLATES)}\` ut WHERE ut.\`id\` = ?`;
}

/** The columns the row detail renders, beside the recipe's name. */
const RUN_DETAIL_COLUMNS = Object.freeze([
  'id', 'recipe_id', 'template_id', 'blueprint_id', 'actor_id', 'mode',
  'code_version', 'status', 'result_link', 'external_flow_id', 'error_summary',
  'started_at', 'finished_at', 'created_at', 'rendered_payload',
  'output_snapshot', 'step_results',
]);

/**
 * One run in full, under the same read rule as the lists.
 *
 * This statement exists rather than the generic CRUD read serving the detail
 * because the detail carries the recipe's name and the additive columns, and
 * because building it here is what keeps the detail agreeing with the list it
 * was opened from under whatever the rule is.
 *
 * `code_version` is additive like `input_snapshot`; both are dropped together in
 * the fallback tier, so a database missing either serves the run without them
 * rather than failing the read.
 */
function buildRunDetailSql(visibilitySql, { withAdditive }) {
  const cols = RUN_DETAIL_COLUMNS
    .filter((c) => withAdditive || c !== 'code_version')
    .map((c) => `r.\`${c}\``);
  if (withAdditive) cols.push('r.`input_snapshot`');
  cols.push('fr.`name` AS recipe_name');
  const predicates = ['r.`id` = ?'];
  if (visibilitySql) predicates.push(visibilitySql);
  return `SELECT ${cols.join(', ')}`
    + ` FROM \`${t(TABLES.FLOW_RECIPE_RUNS)}\` r`
    + ` LEFT JOIN \`${t(TABLES.FLOW_RECIPES)}\` fr ON fr.\`id\` = r.\`recipe_id\``
    + ` WHERE ${predicates.join(' AND ')}`;
}

module.exports = {
  SQL_ALIASES,
  DERIVED_ALIASES,
  GROUP_DERIVED_FIELDS,
  GROUP_SORT_EXPRESSIONS,
  DEFAULT_GROUP_SORT,
  isGroupSortField,
  RUN_LIST_COLUMNS,
  RUN_DETAIL_COLUMNS,
  RUN_COMPARE_COLUMNS,
  buildRunsByIdSql,
  buildLatestGroupRunSql,
  buildGroupsSql,
  buildGroupCountSql,
  buildTemplateByIdSql,
  buildGroupRunsSql,
  buildGroupRunsCountSql,
  buildRunDetailSql,
  groupPredicate,
};
