/**
 * flow-recipe-runs/index.js — run history for the Author-Flow feature.
 *
 * A run record reports one dispatch. actor_id is the WRITE scope (a PUT matches
 * only the writer's own row); serializeWrite masks secrets before persist. The
 * authoritative dispatch trail is feature_audit (server-written, append-only by
 * design).
 *
 * THERE IS NO READ SCOPE, and its absence is the decision. Every authenticated
 * caller reads every run, here and on the history surface mounted ahead of this
 * one alike; the rule and what it exposes are set out in `visibility.js`. The
 * generic mount previously declared `userScopeColumn: 'actor_id'`, which is what
 * confined a reader to their own rows — removing it is what opens this surface,
 * and putting it back is what would close it again.
 *
 * Writing is unchanged by that: a caller still may not alter someone else's run.
 * What may be READ and what may be WRITTEN are two rules here, not one.
 *
 * THIS MOUNT DOES NOT CREATE RUNS, and that is a security property rather than
 * a missing feature — see the 405 below and the immutable list beside it for the
 * two halves of it.
 */
const express = require('express');
const { createCrudRoutes } = require('../schema');
const { apiError } = require('../../../../shared/helpers');
const { TABLES } = require('../../../../shared/constants');
const { enumMembersFor } = require('../../../lib/schema-manifest');
const { serializeWrite } = require('./serializer');
const { router: aggregateRouter } = require('./aggregate');
const { router: answersRouter } = require('./run-answers');

const router = express.Router();

// The recorded-answer reads mount FIRST, ahead of the grouped history, because
// that router claims `GET /runs/:runId` and would otherwise read `compare` as a
// run id. They are a separate router rather than more routes on the history's:
// these two are the only reads on this mount that return the captured document
// itself, and keeping them in one file is what makes that boundary one file to
// audit.
router.use('/', answersRouter);

// The grouped history (aggregate.js) mounts next: the generic factory below
// claims `GET /:id`, which would otherwise read `groups` as a run id. It reads
// under the same rule as the factory — every authenticated caller, every run —
// stated once in `visibility.js` and applied to the rows and their counts alike.
//
// Mounting at '/' also puts that router's authentication gate ahead of the
// factory's routes. All five of the factory's routes already gate on the same
// check, so the only difference is which module emits the identical 401.
router.use('/', aggregateRouter);

// SECURITY: THE ONLY SOURCE OF A RUN ROW IS THE GATED DISPATCH PATH.
//
// `run-finalize` writes the dispatch's result back onto the record the run
// names, and it does NOT re-ask whether the actor may reach that record — by
// design, because a permission withdrawn mid-dispatch must not erase the record
// of a dispatch that already went out (the long form is at that statement). The
// whole of what makes that sound is one premise: a run row naming a record
// exists only because `run-begin` asked, as part of the statement that created
// it, who may dispatch. The generic create broke exactly that premise. It
// stamped the actor from the session and took the record reference from the
// BODY, so any authenticated caller could mint a row satisfying every binding
// finalize checks — and then have the write-back stamp an external id of their
// choosing, plus the link the record displays, onto somebody else's record,
// which turns that owner's next dispatch into an update aimed at it. The same
// forged row is also what `internal/flow-steps.js` binds a dispatch's
// `context.template.*` bag to, so the reference decides what leaves the system
// as well as what is written to it.
//
// WHY THE ROUTE IS WITHDRAWN RATHER THAN NARROWED. Stripping the record reference
// on create would close the write-back specifically and leave a way to mint run
// HISTORY that no dispatch produced, on a surface every authenticated caller
// reads. Nothing needs the route either way: the browser dispatches through
// `flow-recipes/:id/run-begin` (`src/fmb/lib/flow/run-chain.ts`), and no export,
// script, seed or test creates a run any other way. The create-then-finalize
// shape this route was built for was replaced by run-begin/run-finalize.
//
// A caller who posts here gets 405 with `Allow: GET` and nothing is written.
// 405 rather than letting it fall through to 404: the collection answers GET, so
// "this verb is not offered" is the true statement and "no such thing" is not.
//
// THE POSITION OF THIS HANDLER IS THE MECHANISM. It claims the collection path
// ahead of the factory below, whose create route is still registered and is now
// simply never reached; and it sits after the two routers above so their
// authentication gate answers first, leaving an unauthenticated caller the same
// 401 it always got.
router.post('/', (_req, res) => {
  const e = apiError(
    'Runs are created by dispatching a recipe, not by writing this collection',
    'METHOD_NOT_ALLOWED', 405,
  );
  res.set('Allow', 'GET');
  return res.status(e.status).json(e.body);
});

router.use('/', createCrudRoutes('flow_recipe_runs', {
  // No userScopeColumn: see the read rule above. Reads are open to every
  // authenticated caller; writes are not.
  writeScopeColumn: 'actor_id',
  // WHY THIS COMMENT: if create is ever reopened (the 405 above removed or
  // moved below the factory), `status` will 400 as COLUMN_REQUIRED — it is
  // NOT NULL with no default, so a create body must name it, and this mount
  // declares no default for it. The reflex fix is `enumOptionalOnCreate:
  // ['status']`, and that is the wrong fix: it silently restores the hole
  // this file was written to close (the engine choosing the first ENUM
  // member — see the `status`/`mode` comment below). `status` is
  // server-stamped by run-finalize, so the correct fix is adding it to
  // `serverOnlyColumns` — and the factory refuses that while it is also on
  // `immutableColumns` below, so the immutable entry has to move or drop
  // first. Whoever reopens create needs both changes, not the one that
  // merely makes the 400 go away.
  // WHAT A RUN ROW IS TRUSTED FOR IS FIXED WHEN IT IS CREATED; what it merely
  // reports is not. These columns are the first half — every one of them is
  // stamped by run-begin from a server-side read, and every one is later read by
  // something that treats the row as an answer rather than as data:
  //   actor_id      — who the run is, and this mount's write scope. The generic
  //                   PUT already scopes WHERE actor_id = caller, but without
  //                   the strip a body value would still reach the SET list and
  //                   let a caller re-attribute their own run (or an admin any
  //                   run).
  //   template_id   — WHICH RECORD the finalize write-back writes, and which
  //                   record's values flow-steps puts in the dispatch context.
  //                   Leaving it writable reaches that write-back from a row the
  //                   gate really did approve: begin a run naming no record —
  //                   which needs no permission at all — then move it onto
  //                   somebody else's. Closing the create route alone leaves
  //                   this open, which is why both halves are here.
  //   blueprint_id  — run-begin stamps it from the recipe's own binding rather
  //                   than the body so the row reflects the authoritative one;
  //                   a PUT that rewrote it would undo that at leisure, and
  //                   flow-steps reads it for the dispatch context too.
  //   recipe_id     — finalize binds the run to the recipe whose extract specs
  //                   it applies, and flow-steps binds a step's dispatch the
  //                   same way. A run that can change recipes afterwards makes
  //                   both bindings statements about the present rather than
  //                   about what ran.
  //   status        — finalize's own replay guard is a terminal-state
  //                   precondition on its UPDATE, so a run may reach the
  //                   write-back once. Writable here, that guard can be
  //                   disarmed from outside and the row fired again with values
  //                   chosen at the later moment, by an actor whose access has
  //                   since been withdrawn: the row stops being the record of
  //                   one act and becomes a standing permission over the record.
  //   input_snapshot— what the operator entered, recorded with the run's own
  //                   INSERT; editable afterwards by its author, it is no longer
  //                   the one thing it is kept for.
  //   created_at    — WHICH RUN IS THE LAST ONE. It is the sole ORDER BY term
  //                   (id breaks the tie) in all three statements the history
  //                   surface is built from: the group's last run/status/actor,
  //                   the head of a group's run list, and the baseline the
  //                   pre-dispatch diff is taken against. The row's own INSERT
  //                   stamps it and nothing in this repository writes it through
  //                   the generic route; leaving it writable let an author
  //                   decide, after the fact, which of their runs those three
  //                   answer with. It sits on this list rather than the
  //                   reported-not-trusted side because nothing REPORTS it —
  //                   three statements DECIDE on it.
  // SCOPE: the factory strips these in the UPDATE handler only, and that is the
  // whole of the enforcement here — the factory still REGISTERS a create route,
  // but the handler above claims the same path first, so nothing on this mount
  // ever reaches it. Moving that responder below this call, or deleting it,
  // re-opens the create path in silence.
  immutableColumns: [
    'actor_id', 'input_snapshot', 'template_id', 'blueprint_id', 'recipe_id', 'status',
    'created_at',
  ],
  filterableColumns: ['recipe_id'],
  // `mode` says whether the run created the record or updated one, and it is the
  // last enumerated column on this mount a PUT body can still name. Without a
  // domain the engine decides what it stores: an ENUM comparison folds case and
  // a trailing space, and MariaDB reads an INTEGER written to an ENUM column as
  // a 1-BASED MEMBER INDEX — so `{"mode": 2}` stores 'update' and `{"mode":
  // "UPDATE"}` stores 'update' while matching no string any reader of this
  // column compares against. Read from the DDL rather than restated, so a
  // narrowed or widened column moves the gate with it.
  //
  // `status` is the same column-level exposure on the OTHER verb, and it is
  // gated here rather than left to the route ordering above. The strip that
  // keeps a body away from it runs on update only, so a CREATE body can name it;
  // what stops one arriving is that the 405 responder claims `POST /` ahead of
  // the factory, in this file, several dozen lines up. That is a rule held open
  // by the position of a handler, and the reason a reader is asked to look there
  // is a comment. With a domain declared, moving or deleting that responder can
  // no longer reopen an ungated terminal-state column in silence: `{"status": 2}`
  // — which the engine would store as 'partial' by 1-based member index — is
  // refused by the same gate on both verbs.
  enumColumns: {
    mode: enumMembersFor(TABLES.FLOW_RECIPE_RUNS, 'mode'),
    status: enumMembersFor(TABLES.FLOW_RECIPE_RUNS, 'status'),
  },
  serializeWrite,
}));

module.exports = router;
