/**
 * blueprint-serialization.test.js — v3.2.97 PR-1 backend suite.
 *
 * Covers the 5 critical scenarios called out in autoplan E6:
 *   1) serialize → parse round-trip preserves structural shape
 *   2) parseYaml hardening: oversize / dangerous keys / alias bomb / non-map root
 *   3) computeRevision is sensitive to meaningful changes, stable across
 *      reorderings of unordered child arrays
 *   4) computeDiff returns accurate added/removed/modified counts
 *   5) overwriteBlueprint TX rollback under simulated INSERT failure
 *      + audit row metadata
 */
import { describe, it, expect, vi } from 'vitest';

const lib = require('../lib/blueprint-serialization');
const { checkImportedBlueprintFields } = require('../lib/blueprint-field-import-guard');

function rawFixture() {
  return {
    import_version: 1,
    hierarchy_node: {
      id: 'bp-uuid-1',
      parent_id: 'release-uuid-1',
      name: 'Tao Yuan Base Mold',
      description: 'unit test fixture',
      node_type: 'blueprint',
      sort_order: 5,
      is_active: 1,
      transformer_id: null,
      transformer_version: null,
      linked_blueprint_id: null,
    },
    blueprint_fields: [
      {
        id: 'fld-1', blueprint_id: 'bp-uuid-1',
        field_key: 'material', field_label: 'Material', field_type: 'select',
        is_required: 1, default_value: '', placeholder: '', tooltip: '',
        section: 'general', order_index: 0,
        table_config: null, visibility_rule: null,
      },
      {
        id: 'fld-2', blueprint_id: 'bp-uuid-1',
        field_key: 'width_mm', field_label: 'Width / mm', field_type: 'number',
        is_required: 0, default_value: '0', placeholder: 'enter width',
        tooltip: 'in millimetres', section: 'dimensions', order_index: 1,
        table_config: null, visibility_rule: null,
      },
    ],
    field_options: [
      { id: 'opt-1', field_id: 'fld-1', option_label: 'Steel', option_value: 'steel', sort_order: 0 },
      { id: 'opt-2', field_id: 'fld-1', option_label: 'Aluminium', option_value: 'aluminum', sort_order: 1 },
    ],
    blueprint_sections: [
      { id: 'sec-1', blueprint_id: 'bp-uuid-1', section_key: 'general', display_label: 'General', sort_order: 0, icon: 'Settings', description: 'Common settings' },
      { id: 'sec-2', blueprint_id: 'bp-uuid-1', section_key: 'dimensions', display_label: 'Dimensions', sort_order: 1 },
    ],
    blueprint_output_order: [
      { id: 'out-1', blueprint_id: 'bp-uuid-1', output_key: 'material', sort_order: 0 },
      { id: 'out-2', blueprint_id: 'bp-uuid-1', output_key: 'width_mm', sort_order: 1 },
    ],
    _extensions: {},
  };
}

describe('serializeYaml + parseYaml round-trip', () => {
  it('serializes lean YAML without server-generated noise', () => {
    const out = lib.serializeYaml(rawFixture());
    // Field/option/section/output internal UUIDs and FK references must
    // NOT appear; only the blueprint root UUID is preserved as
    // export_metadata.original_id (identity-match hint).
    expect(out).not.toContain('fld-1');
    expect(out).not.toContain('fld-2');
    expect(out).not.toContain('opt-1');
    expect(out).not.toContain('opt-2');
    expect(out).not.toContain('sec-1');
    expect(out).not.toContain('out-1');
    expect(out).not.toContain('created_at');
    expect(out).not.toContain('updated_at');
    expect(out).not.toContain('field_id:');
    expect(out).not.toContain('order_index:');
    expect(out).toContain('material');
    expect(out).toContain('width_mm');
    expect(out).toContain('Tao Yuan Base Mold');
    expect(out).toContain('original_id: bp-uuid-1');
  });

  it('preserves is_active=0 (MariaDB tinyint) as inactive (Codex round 2)', () => {
    const raw = rawFixture();
    raw.hierarchy_node.is_active = 0;
    const yamlText = lib.serializeYaml(raw);
    expect(yamlText).toMatch(/is_active:\s*false/);
    const parsed = lib.parseYaml(yamlText);
    expect(parsed.hierarchy_node.is_active).toBe(false);
  });

  it('preserves structural shape across round-trip', () => {
    const yamlText = lib.serializeYaml(rawFixture());
    const parsed = lib.parseYaml(yamlText);
    expect(parsed.hierarchy_node.name).toBe('Tao Yuan Base Mold');
    expect(parsed.blueprint_fields).toHaveLength(2);
    expect(parsed.blueprint_fields[0].field_key).toBe('material');
    expect(parsed.field_options).toHaveLength(2);
    expect(parsed.blueprint_sections).toHaveLength(2);
    // Section icon + description must survive the YAML round-trip (string-or-null).
    expect(parsed.blueprint_sections[0].icon).toBe('Settings');
    expect(parsed.blueprint_sections[0].description).toBe('Common settings');
    expect(parsed.blueprint_output_order).toHaveLength(2);
    expect(parsed.export_metadata?.original_id).toBe('bp-uuid-1');
  });

  it('round-trips retain_when_hidden (additive per-field flag)', () => {
    const raw = rawFixture();
    raw.blueprint_fields[0].retain_when_hidden = 1; // material: keep value when hidden
    const yamlText = lib.serializeYaml(raw);
    expect(yamlText).toMatch(/retain_when_hidden:\s*true/);
    const parsed = lib.parseYaml(yamlText);
    const material = parsed.blueprint_fields.find((f) => f.field_key === 'material');
    const width = parsed.blueprint_fields.find((f) => f.field_key === 'width_mm');
    expect(material.retain_when_hidden).toBe(1);
    // A field without the flag deserializes to the discard default (0).
    expect(width.retain_when_hidden).toBe(0);
  });

  it('import rejects a malformed choice_config (min > max) with a clear error', () => {
    const raw = rawFixture();
    raw.blueprint_fields[0].field_type = 'checkbox';
    raw.blueprint_fields[0].choice_config = { minSelected: 5, maxSelected: 2 };
    const yamlText = lib.serializeYaml(raw);
    expect(() => lib.parseYaml(yamlText)).toThrow(/choice_config must be/);
  });

  it('import rejects choice_config on a non-checkbox field', () => {
    const raw = rawFixture();
    // fld-2 is a number field; smuggle a choice_config onto it.
    raw.blueprint_fields[1].choice_config = { maxSelected: 3 };
    const yamlText = lib.serializeYaml(raw);
    expect(() => lib.parseYaml(yamlText)).toThrow(/only valid on a checkbox field/);
  });

  it('import rejects duplicate option values under a checkbox field (select aliases still import)', () => {
    const raw = rawFixture();
    raw.blueprint_fields[0].field_type = 'checkbox';
    // Same value under two labels: legal alias for select, illegal for checkbox.
    raw.field_options.push({ id: 'opt-3', field_id: 'fld-1', option_label: 'Stainless', option_value: 'steel', sort_order: 2 });
    const yamlText = lib.serializeYaml(raw);
    expect(() => lib.parseYaml(yamlText)).toThrow(/Duplicate option value 'steel' under checkbox field/);
    // Sanity: the SAME options under a select field import fine (alias semantics).
    const rawSelect = rawFixture();
    rawSelect.field_options.push({ id: 'opt-3', field_id: 'fld-1', option_label: 'Stainless', option_value: 'steel', sort_order: 2 });
    expect(() => lib.parseYaml(lib.serializeYaml(rawSelect))).not.toThrow();
  });

  it('round-trips choice_config (checkbox selection limits, additive JSON column)', () => {
    const raw = rawFixture();
    raw.blueprint_fields[0].field_type = 'checkbox';
    raw.blueprint_fields[0].choice_config = { minSelected: 1, maxSelected: 3 };
    const yamlText = lib.serializeYaml(raw);
    expect(yamlText).toContain('choice_config');
    const parsed = lib.parseYaml(yamlText);
    const material = parsed.blueprint_fields.find((f) => f.field_key === 'material');
    const width = parsed.blueprint_fields.find((f) => f.field_key === 'width_mm');
    // parseYaml returns the DB-insert shape → JSON columns come back stringified.
    expect(JSON.parse(material.choice_config)).toEqual({ minSelected: 1, maxSelected: 3 });
    // A field that never carried the column deserializes to null.
    expect(width.choice_config).toBeNull();
  });
});

describe('blueprint policy columns round-trip (value_source + compute_rule)', () => {
  // A rule the validator accepts on the number field: width_mm = material length.
  const RULE = {
    op: 'transform',
    overridable: false,
    output_type: 'string',
    config: { source: 'material', transform: 'upper' },
  };

  function rawWithPolicies() {
    const raw = rawFixture();
    raw.blueprint_fields[0].value_source = 'calculated'; // material: computed
    raw.blueprint_fields[0].compute_rule = JSON.stringify(RULE);
    raw.blueprint_fields[1].value_source = 'entered';    // width_mm: neither
    raw.blueprint_fields[1].compute_rule = null;
    return raw;
  }

  it('serializeYaml emits both policies', () => {
    const yamlText = lib.serializeYaml(rawWithPolicies());
    expect(yamlText).toMatch(/value_source:\s*calculated/);
    expect(yamlText).toContain('compute_rule');
    expect(yamlText).toContain('transform: upper');
  });

  it('round-trip preserves both policies (and their absence)', () => {
    const parsed = lib.parseYaml(lib.serializeYaml(rawWithPolicies()));
    const material = parsed.blueprint_fields.find((f) => f.field_key === 'material');
    const width = parsed.blueprint_fields.find((f) => f.field_key === 'width_mm');
    expect(material.value_source).toBe('calculated');
    // parseYaml returns the DB-insert shape → JSON columns come back stringified.
    expect(JSON.parse(material.compute_rule)).toEqual(RULE);
    // A field carrying neither policy deserializes to the storage defaults.
    expect(width.value_source).toBe('entered');
    expect(width.compute_rule).toBeNull();
  });

  it('a rule reaching the import guard through YAML is judged, not ignored', () => {
    const raw = rawWithPolicies();
    raw.blueprint_fields[0].compute_rule = JSON.stringify({
      ...RULE, config: { source: 'no_such_field', transform: 'upper' },
    });
    const parsed = lib.parseYaml(lib.serializeYaml(raw));
    const { errors } = checkImportedBlueprintFields(parsed.blueprint_fields);
    expect(errors.join(' ')).toMatch(/missing_source/);
  });

  it('rejects a mode outside the vocabulary instead of defaulting it away', () => {
    const yamlText = lib.serializeYaml(rawWithPolicies())
      .replace('value_source: calculated', 'value_source: yes-please');
    expect(() => lib.parseYaml(yamlText)).toThrow(/value_source must be one of/);
  });

  // ── the scope refusals, driven through parseYaml ──────────────────────
  //
  // Hand-built objects are why these two refusals sat unreachable on this path
  // for a whole release: `parseYaml` STRINGIFIES value_scope, and the import
  // guard's own copy of "does this scope narrow anything" accepted objects
  // only, so it answered false for every YAML document and both refusals below
  // it were dead. The rule half survived only because its reader parses
  // strings. Drive the real path or these tests prove nothing.

  it('refuses a value_scope on a field type that cannot address cells — through YAML', () => {
    const raw = rawWithPolicies();
    raw.blueprint_fields[1].value_source = 'locked';
    raw.blueprint_fields[1].value_scope = { columns: ['host'] }; // width_mm is a number
    const parsed = lib.parseYaml(lib.serializeYaml(raw));
    // The precondition the earlier version of this check silently lost.
    expect(typeof parsed.blueprint_fields.find((f) => f.field_key === 'width_mm').value_scope)
      .toBe('string');
    const { errors } = checkImportedBlueprintFields(parsed.blueprint_fields);
    expect(errors.join(' ')).toMatch(/must not carry a value_scope/);
  });

  it("refuses a value_scope under 'entered' — through YAML", () => {
    const raw = rawWithPolicies();
    raw.blueprint_fields[1].field_type = 'table';
    raw.blueprint_fields[1].table_config = JSON.stringify({ columns: [{ key: 'host', label: 'Host' }] });
    raw.blueprint_fields[1].value_source = 'entered';
    raw.blueprint_fields[1].value_scope = { columns: ['host'] };
    const parsed = lib.parseYaml(lib.serializeYaml(raw));
    const { errors } = checkImportedBlueprintFields(parsed.blueprint_fields);
    expect(errors.join(' ')).toMatch(/'entered' must not carry a value_scope/);
  });

  it('accepts the scope a table field may legitimately carry', () => {
    const raw = rawWithPolicies();
    raw.blueprint_fields[1].field_type = 'table';
    raw.blueprint_fields[1].table_config = JSON.stringify({ columns: [{ key: 'host', label: 'Host' }] });
    raw.blueprint_fields[1].value_source = 'locked';
    raw.blueprint_fields[1].value_scope = { columns: ['host'] };
    const parsed = lib.parseYaml(lib.serializeYaml(raw));
    // Scoped to the scope refusals: the shared fixture's own rule is a
    // self-reference, so the collection carries an unrelated cycle error.
    expect(
      checkImportedBlueprintFields(parsed.blueprint_fields).errors
        .filter((e) => /value_scope/.test(e)),
    ).toEqual([]);
  });

  it('a policy change surfaces in the import diff summary', () => {
    const oldRaw = rawWithPolicies();
    const newRaw = rawWithPolicies();
    newRaw.blueprint_fields[0].value_source = 'locked';
    newRaw.blueprint_fields[0].compute_rule = null;
    expect(lib.computeDiff(oldRaw, newRaw).fields.modified).toBe(1);
    const newRule = rawWithPolicies();
    newRule.blueprint_fields[0].compute_rule = JSON.stringify({
      ...RULE, config: { source: 'material', transform: 'lower' },
    });
    expect(lib.computeDiff(oldRaw, newRule).fields.modified).toBe(1);
  });
});

describe('blueprint_groups round-trip', () => {
  function rawWithGroups() {
    const raw = rawFixture();
    raw.blueprint_groups = [
      { id: 'grp-1', blueprint_id: 'bp-uuid-1', group_key: 'lane_a', display_label: 'Lane A', color_key: 'blue', sort_order: 0 },
      { id: 'grp-2', blueprint_id: 'bp-uuid-1', group_key: 'lane_b', display_label: 'Lane B', color_key: 'green', sort_order: 1 },
    ];
    raw.blueprint_fields[0].group_key = 'lane_a'; // material joins lane_a
    raw.blueprint_sections[0].layout_mode = 'cards'; // general renders as cards
    return raw;
  }

  it('serializes groups + field group + section layout without internal ids', () => {
    const out = lib.serializeYaml(rawWithGroups());
    expect(out).not.toContain('grp-1');
    expect(out).not.toContain('grp-2');
    expect(out).toContain('lane_a');
    expect(out).toContain('lane_b');
    expect(out).toContain('cards');
  });

  it('preserves groups + field group_key + section layout_mode across round-trip', () => {
    const parsed = lib.parseYaml(lib.serializeYaml(rawWithGroups()));
    expect(parsed.blueprint_groups).toHaveLength(2);
    const laneA = parsed.blueprint_groups.find((g) => g.group_key === 'lane_a');
    expect(laneA.display_label).toBe('Lane A');
    expect(laneA.color_key).toBe('blue');
    // internal id is a fresh placeholder (server assigns the real UUID on insert).
    expect(laneA.id).toMatch(/^__placeholder_grp_/);
    const material = parsed.blueprint_fields.find((f) => f.field_key === 'material');
    expect(material.group_key).toBe('lane_a');
    const general = parsed.blueprint_sections.find((s) => s.section_key === 'general');
    expect(general.layout_mode).toBe('cards');
    // A field / section without the additive value deserializes to null.
    const width = parsed.blueprint_fields.find((f) => f.field_key === 'width_mm');
    expect(width.group_key).toBeNull();
    const dims = parsed.blueprint_sections.find((s) => s.section_key === 'dimensions');
    expect(dims.layout_mode).toBeNull();
  });

  it('rejects duplicate group keys', () => {
    const dup = `
import_version: 1
blueprint:
  name: dup
groups:
  - key: lane_a
    label: A
  - key: lane_a
    label: B
`;
    expect(() => lib.parseYaml(dup)).toThrowError(/Duplicate group key/);
  });

  it('rejects groups as a non-array value', () => {
    const bad = `
import_version: 1
blueprint:
  name: bad
groups:
  oops: nope
`;
    expect(() => lib.parseYaml(bad)).toThrowError(/must be an array/);
  });
});

describe('computeRevision / computeDiff — groups', () => {
  function rawWithGroups() {
    const raw = rawFixture();
    raw.blueprint_groups = [
      { id: 'grp-1', blueprint_id: 'bp-uuid-1', group_key: 'lane_a', display_label: 'Lane A', color_key: 'blue', sort_order: 0 },
    ];
    return raw;
  }

  it('computeRevision changes when a group color is edited', () => {
    const a = rawWithGroups();
    const b = rawWithGroups();
    b.blueprint_groups[0].color_key = 'red';
    expect(lib.computeRevision(a)).not.toBe(lib.computeRevision(b));
  });

  it('computeRevision changes when a field is reassigned to a group', () => {
    const a = rawFixture();
    const b = rawFixture();
    b.blueprint_fields[0].group_key = 'lane_a';
    expect(lib.computeRevision(a)).not.toBe(lib.computeRevision(b));
  });

  it('computeRevision changes when a section layout_mode is edited', () => {
    const a = rawFixture();
    const b = rawFixture();
    b.blueprint_sections[0].layout_mode = 'matrix';
    expect(lib.computeRevision(a)).not.toBe(lib.computeRevision(b));
  });

  it('computeDiff + summary count group add / modify', () => {
    const oldRaw = rawWithGroups();
    const newRaw = rawWithGroups();
    newRaw.blueprint_groups[0].color_key = 'red'; // modify lane_a
    newRaw.blueprint_groups.push({ id: 'grp-2', blueprint_id: 'bp-uuid-1', group_key: 'lane_b', display_label: 'Lane B', color_key: 'green', sort_order: 1 });
    const diff = lib.computeDiff(oldRaw, newRaw);
    expect(diff.groups.added).toBe(1);
    expect(diff.groups.modified).toBe(1);
    expect(diff.groups.removed).toBe(0);
    const summary = lib.summariseDiff(diff);
    expect(summary.groups_added).toBe(1);
    expect(summary.groups_modified).toBe(1);
    expect(summary.names.groups.added).toContain('lane_b');
    expect(summary.names.groups.modified).toContain('lane_a');
  });

  it('computeDiff counts a group removal', () => {
    const oldRaw = rawWithGroups();
    const newRaw = rawFixture(); // no groups
    const diff = lib.computeDiff(oldRaw, newRaw);
    expect(diff.groups.removed).toBe(1);
    expect(diff.groups.added).toBe(0);
  });

  it('field group_key edit surfaces as a modified field in the diff summary', () => {
    const oldRaw = rawFixture();
    const newRaw = rawFixture();
    newRaw.blueprint_fields[0].group_key = 'lane_a';
    const diff = lib.computeDiff(oldRaw, newRaw);
    expect(diff.fields.modified).toBe(1);
    expect(diff.fields.modifiedNames).toContain('material');
  });
});

describe('parseYaml hardening', () => {
  it('rejects payload exceeding MAX_YAML_BYTES', () => {
    const big = 'import_version: 1\nblueprint:\n  name: x\n' + 'x'.repeat(lib.MAX_YAML_BYTES);
    expect(() => lib.parseYaml(big)).toThrowError(/exceeds/);
  });

  it('rejects dangerous keys (__proto__ / constructor / prototype)', () => {
    const evil = `
import_version: 1
blueprint:
  name: bad
  __proto__:
    polluted: true
fields: []
sections: []
output_order: []
`;
    expect(() => lib.parseYaml(evil)).toThrowError(/Dangerous key/);
  });

  it('rejects non-map root', () => {
    expect(() => lib.parseYaml('- item1\n- item2\n')).toThrowError(/must be a mapping/);
  });

  it('caps alias expansion (alias bomb)', () => {
    // yaml@2 enforces maxAliasCount internally; constructing a >100-alias
    // bomb that the option actually rejects is fiddly. We verify the option
    // is plumbed through by surfacing the parser's own AliasCountLimit error.
    let aliases = '';
    for (let i = 0; i < 200; i++) {
      aliases += `  - *anchor\n`;
    }
    const bomb = `
import_version: 1
blueprint:
  name: bomb
fields: []
sections: []
output_order: []
anchored: &anchor x
list:
${aliases}
`;
    expect(() => lib.parseYaml(bomb)).toThrowError();
  });

  it('rejects import_version > 1', () => {
    const future = `
import_version: 99
blueprint:
  name: future
fields: []
sections: []
output_order: []
`;
    expect(() => lib.parseYaml(future)).toThrowError(/newer than server/);
  });

  it('rejects duplicate field keys', () => {
    const dup = `
import_version: 1
blueprint:
  name: dup
fields:
  - key: a
    label: A
    type: text
  - key: a
    label: A2
    type: text
sections: []
output_order: []
`;
    expect(() => lib.parseYaml(dup)).toThrowError(/Duplicate field key/);
  });

  it('accepts same-value options with distinct labels (alias round-trip)', () => {
    const aliasYaml = `
import_version: 1
blueprint:
  name: alias
fields:
  - key: material
    label: Material
    type: select
    options:
      - value: steel
        label: Steel
      - value: steel
        label: Carbon Steel
sections: []
output_order: []
`;
    const parsed = lib.parseYaml(aliasYaml);
    expect(parsed.field_options).toHaveLength(2);
    expect(parsed.field_options.map((o) => o.option_value)).toEqual(['steel', 'steel']);
    expect(parsed.field_options.map((o) => o.option_label)).toEqual(['Steel', 'Carbon Steel']);
  });

  it('rejects an exact-duplicate option (same value AND label)', () => {
    const exactDup = `
import_version: 1
blueprint:
  name: exactdup
fields:
  - key: material
    label: Material
    type: select
    options:
      - value: steel
        label: Steel
      - value: steel
        label: Steel
sections: []
output_order: []
`;
    expect(() => lib.parseYaml(exactDup)).toThrowError(/Duplicate option/);
  });
});

describe('computeRevision', () => {
  it('returns the same hash for identical inputs', () => {
    expect(lib.computeRevision(rawFixture())).toBe(lib.computeRevision(rawFixture()));
  });

  it('changes when a field label changes', () => {
    const a = rawFixture();
    const b = rawFixture();
    b.blueprint_fields[0].field_label = 'Different';
    expect(lib.computeRevision(a)).not.toBe(lib.computeRevision(b));
  });

  it('is stable across reordering of unordered children', () => {
    const a = rawFixture();
    const b = rawFixture();
    b.blueprint_fields = [b.blueprint_fields[1], b.blueprint_fields[0]];
    expect(lib.computeRevision(a)).toBe(lib.computeRevision(b));
  });

  it.each([
    ['default_value', 'NEW_DEFAULT'],
    ['placeholder', 'NEW_PLACEHOLDER'],
    ['tooltip', 'NEW_TOOLTIP'],
  ])('changes when field.%s is edited (Codex P1 — overwrite optimistic-lock)', (key, value) => {
    const a = rawFixture();
    const b = rawFixture();
    b.blueprint_fields[0][key] = value;
    expect(lib.computeRevision(a)).not.toBe(lib.computeRevision(b));
  });

  it.each([
    ['description', 'EDITED'],
    ['transformer_id', 'tr-1'],
    ['transformer_version', '2'],
    ['linked_blueprint_id', 'bp-other'],
  ])('changes when root.%s is edited (Codex round 2 — root metadata)', (key, value) => {
    const a = rawFixture();
    const b = rawFixture();
    b.hierarchy_node[key] = value;
    expect(lib.computeRevision(a)).not.toBe(lib.computeRevision(b));
  });
});

describe('computeDiff', () => {
  it('detects added / removed / modified across all 4 buckets', () => {
    const oldRaw = rawFixture();
    const newRaw = rawFixture();
    newRaw.blueprint_fields.push({
      id: 'fld-3', blueprint_id: 'bp-uuid-1', field_key: 'depth_mm',
      field_label: 'Depth', field_type: 'number', is_required: 0,
      default_value: '', placeholder: '', tooltip: '',
      section: 'dimensions', order_index: 2,
      table_config: null, visibility_rule: null,
    });
    newRaw.blueprint_fields[0].field_label = 'Material (renamed)';
    newRaw.blueprint_fields.splice(1, 1); // remove width_mm
    newRaw.field_options = newRaw.field_options.filter((o) => o.field_id === 'fld-1');
    newRaw.blueprint_sections.pop();
    newRaw.blueprint_output_order.push({
      id: 'out-3', blueprint_id: 'bp-uuid-1', output_key: 'depth_mm', sort_order: 2,
    });

    const diff = lib.computeDiff(oldRaw, newRaw);
    expect(diff.fields.added).toBe(1);
    expect(diff.fields.removed).toBe(1);
    expect(diff.fields.modified).toBe(1);
    expect(diff.sections.removed).toBe(1);
    expect(diff.output.added).toBe(1);
  });

  it('counts an icon/description-only section change as modified', () => {
    const oldRaw = rawFixture();
    const newRaw = rawFixture();
    // Same display_label, same section_key — only icon + description differ.
    newRaw.blueprint_sections[0].icon = 'Wrench';
    newRaw.blueprint_sections[0].description = 'Updated description';

    const diff = lib.computeDiff(oldRaw, newRaw);
    expect(diff.sections.modified).toBe(1);
    expect(diff.sections.added).toBe(0);
    expect(diff.sections.removed).toBe(0);
  });

  it('counts the removal of an aliased option (same value, distinct label)', () => {
    const oldRaw = rawFixture();
    // fld-1 gains an alias for the existing value 'steel' under a new label —
    // a value-only diff key would collide these and report removed: 0.
    oldRaw.field_options.push({
      id: 'opt-3', field_id: 'fld-1', option_label: 'Carbon Steel', option_value: 'steel', sort_order: 2,
    });
    const newRaw = rawFixture(); // alias absent

    const diff = lib.computeDiff(oldRaw, newRaw);
    expect(diff.options.removed).toBe(1);
    expect(diff.options.added).toBe(0);
  });

  it('surfaces per-item names in the summary (added/removed field, modified section)', () => {
    const oldRaw = rawFixture();
    const newRaw = rawFixture();
    newRaw.blueprint_fields.push({
      id: 'fld-3', blueprint_id: 'bp-uuid-1', field_key: 'depth_mm', field_label: 'Depth',
      field_type: 'number', is_required: 0, default_value: '', placeholder: '', tooltip: '',
      section: 'dimensions', order_index: 2, table_config: null, visibility_rule: null,
    });
    newRaw.blueprint_fields.splice(1, 1); // remove width_mm
    newRaw.blueprint_sections[0].icon = 'Wrench'; // modify the 'general' section
    // An added option whose label differs from its value renders as "label (value)".
    newRaw.field_options.push({
      id: 'opt-9', field_id: 'fld-1', option_label: 'Steel Alloy', option_value: 'steel_alloy', sort_order: 5,
    });

    const summary = lib.summariseDiff(lib.computeDiff(oldRaw, newRaw));
    expect(summary.names.fields.added).toContain('depth_mm');
    expect(summary.names.fields.removed).toContain('width_mm');
    expect(summary.names.sections.modified).toContain('general');
    expect(summary.names.options.added).toContain('Steel Alloy (steel_alloy)');
  });
});

describe('computeDiff — export→import round-trip false-positive fix (v3.2.479)', () => {
  // Mirrors the live blueprint that regressed: stored order_index is
  // non-contiguous with duplicates (a legacy artifact), one JSON column
  // carries MariaDB-normalised spacing, and one option's valid_parent_values
  // is a space-formatted TEXT string. A clean round-trip must report zero drift.
  function rawRoundTripFixture() {
    return {
      import_version: 1,
      hierarchy_node: {
        id: 'bp-rt', parent_id: 'rel-rt', name: 'RoundTrip Showcase', description: '',
        node_type: 'blueprint', sort_order: 0, is_active: 1,
        transformer_id: null, transformer_version: null, linked_blueprint_id: null,
      },
      blueprint_fields: [
        {
          id: 'rt-f1', blueprint_id: 'bp-rt', field_key: 'endpoint_url', field_label: 'Endpoint',
          field_type: 'text', is_required: 0, default_value: '', placeholder: '', tooltip: '',
          section: 'general', order_index: 1,
          table_config: null, visibility_rule: null, choice_config: null,
          group_key: null, matrix_row_key: null, depends_on_field_key: null, retain_when_hidden: 0,
        },
        {
          id: 'rt-f2', blueprint_id: 'bp-rt', field_key: 'parts_table', field_label: 'Parts',
          field_type: 'text', is_required: 0, default_value: '', placeholder: '', tooltip: '',
          section: 'general', order_index: 1,
          // MariaDB-normalised spacing: space after colon and comma.
          table_config: '{"columns": ["a", "b"]}',
          visibility_rule: null, choice_config: null,
          group_key: null, matrix_row_key: null, depends_on_field_key: null, retain_when_hidden: 0,
        },
        {
          id: 'rt-f3', blueprint_id: 'bp-rt', field_key: 'subtype', field_label: 'Subtype',
          field_type: 'select', is_required: 0, default_value: '', placeholder: '', tooltip: '',
          section: 'general', order_index: 2,
          table_config: null, visibility_rule: null, choice_config: null,
          group_key: null, matrix_row_key: null, depends_on_field_key: null, retain_when_hidden: 0,
        },
        {
          id: 'rt-f4', blueprint_id: 'bp-rt', field_key: 'features', field_label: 'Features',
          field_type: 'text', is_required: 0, default_value: '', placeholder: '', tooltip: '',
          section: 'general', order_index: 3,
          table_config: null, visibility_rule: null, choice_config: null,
          group_key: null, matrix_row_key: null, depends_on_field_key: null, retain_when_hidden: 0,
        },
      ],
      field_options: [
        {
          id: 'rt-o1', field_id: 'rt-f3', option_label: 'X-or-Y', option_value: 'x_or_y',
          sort_order: 0,
          // DB TEXT with a space after the comma.
          valid_parent_values: '["cat_x", "cat_y"]',
        },
      ],
      blueprint_sections: [],
      blueprint_groups: [],
      blueprint_output_order: [],
      _extensions: {},
    };
  }

  it('reports zero drift re-importing an unmodified export (non-contiguous order_index + spaced JSON)', () => {
    const raw = rawRoundTripFixture();
    const roundTripped = lib.parseYaml(lib.serializeYaml(raw));
    const diff = lib.computeDiff(raw, roundTripped);
    for (const bucket of ['fields', 'options', 'sections', 'groups', 'output']) {
      expect(diff[bucket].added).toBe(0);
      expect(diff[bucket].removed).toBe(0);
      expect(diff[bucket].modified).toBe(0);
    }
  });

  it('stays clean for a tied order_index group regardless of DB row-fetch order (deterministic tie-break)', () => {
    // loadRawExport has no ORDER BY, so the two independent SELECTs (export vs
    // diff) may return a tied order_index group in opposite order. Simulate that:
    // the NEW side is built from one in-memory ordering, the OLD side from the
    // reversed ordering. The field_key secondary tie-break must make the rank
    // data-determined so the round-trip stays clean. (RED if the tie-break is
    // removed: stable sort then preserves each side's incoming order → the ranks
    // disagree → both tied fields read as modified.)
    const fieldA = {
      id: 'ti-a', blueprint_id: 'bp-ti', field_key: 'alpha', field_label: 'Alpha',
      field_type: 'text', is_required: 0, default_value: '', placeholder: '', tooltip: '',
      section: 'general', order_index: 1,
      table_config: null, visibility_rule: null, choice_config: null,
      group_key: null, matrix_row_key: null, depends_on_field_key: null, retain_when_hidden: 0,
    };
    const fieldB = { ...fieldA, id: 'ti-b', field_key: 'beta', field_label: 'Beta' };
    const base = {
      import_version: 1,
      hierarchy_node: {
        id: 'bp-ti', parent_id: 'rel-ti', name: 'Tied', description: '',
        node_type: 'blueprint', sort_order: 0, is_active: 1,
        transformer_id: null, transformer_version: null, linked_blueprint_id: null,
      },
      field_options: [], blueprint_sections: [], blueprint_groups: [],
      blueprint_output_order: [], _extensions: {},
    };
    const exportOrder = { ...base, blueprint_fields: [fieldA, fieldB] };
    const diffOrder = { ...base, blueprint_fields: [fieldB, fieldA] }; // reversed DB fetch order
    const newRaw = lib.parseYaml(lib.serializeYaml(exportOrder));
    const diff = lib.computeDiff(diffOrder, newRaw);
    expect(diff.fields.modified).toBe(0);
    expect(diff.fields.added).toBe(0);
    expect(diff.fields.removed).toBe(0);
  });

  it('stays clean for a legacy export whose tie order is not lexical (NEW-aligned tie ranking)', () => {
    // A YAML exported BEFORE this branch baked the then-current DB fetch order for
    // a tied order_index group — which may not be lexical (here: beta before
    // alpha). The diff-side rank aligns within-tie ordering to the NEW
    // (parsed-YAML) positions, so an untouched legacy backup round-trips clean.
    // (RED under the r1 lexical-only tie-break: OLD would rank alpha<beta but NEW
    // has beta<alpha → both flagged.)
    const tied = (key, label) => ({
      id: `lg-${key}`, blueprint_id: 'bp-lg', field_key: key, field_label: label,
      field_type: 'text', is_required: 0, default_value: '', placeholder: '', tooltip: '',
      section: 'general', order_index: 1,
      table_config: null, visibility_rule: null, choice_config: null,
      group_key: null, matrix_row_key: null, depends_on_field_key: null, retain_when_hidden: 0,
    });
    const base = {
      import_version: 1,
      hierarchy_node: {
        id: 'bp-lg', parent_id: 'rel-lg', name: 'Legacy', description: '',
        node_type: 'blueprint', sort_order: 0, is_active: 1,
        transformer_id: null, transformer_version: null, linked_blueprint_id: null,
      },
      field_options: [], blueprint_sections: [], blueprint_groups: [],
      blueprint_output_order: [], _extensions: {},
    };
    // NEW = parsed legacy YAML: beta at position 0, alpha at position 1
    // (order_index = array index, exactly what parseYaml produces).
    const newRaw = {
      ...base,
      blueprint_fields: [
        { ...tied('beta', 'Beta'), order_index: 0 },
        { ...tied('alpha', 'Alpha'), order_index: 1 },
      ],
    };
    // OLD = current DB (loadRawExport ORDER BY → lexical alpha, beta), both tied at 1.
    const oldRaw = { ...base, blueprint_fields: [tied('alpha', 'Alpha'), tied('beta', 'Beta')] };
    const diff = lib.computeDiff(oldRaw, newRaw);
    expect(diff.fields.modified).toBe(0);
    expect(diff.fields.added).toBe(0);
    expect(diff.fields.removed).toBe(0);
  });

  it('flags a JSON-text "null" that a NEW-side absent value would rewrite to SQL NULL', () => {
    const field = (tableConfig) => ({
      id: 'nl-f1', blueprint_id: 'bp-nl', field_key: 'a', field_label: 'A',
      field_type: 'text', is_required: 0, default_value: '', placeholder: '', tooltip: '',
      section: 'general', order_index: 0,
      table_config: tableConfig, visibility_rule: null, choice_config: null,
      group_key: null, matrix_row_key: null, depends_on_field_key: null, retain_when_hidden: 0,
    });
    const base = {
      import_version: 1,
      hierarchy_node: {
        id: 'bp-nl', parent_id: 'rel-nl', name: 'NullText', description: '',
        node_type: 'blueprint', sort_order: 0, is_active: 1,
        transformer_id: null, transformer_version: null, linked_blueprint_id: null,
      },
      field_options: [], blueprint_sections: [], blueprint_groups: [],
      blueprint_output_order: [], _extensions: {},
    };
    // OLD stores the literal JSON text "null"; NEW omits table_config (SQL NULL).
    // A real overwrite-import WOULD rewrite "null" → SQL NULL, so the diff must
    // flag it. (RED before the fix: both fingerprint to '' and read as unchanged.)
    const flagged = lib.computeDiff(
      { ...base, blueprint_fields: [field('null')] },
      { ...base, blueprint_fields: [field(null)] },
    );
    expect(flagged.fields.modified).toBe(1);

    // Symmetric no-false-positive: both sides genuinely absent → clean.
    const clean = lib.computeDiff(
      { ...base, blueprint_fields: [field(null)] },
      { ...base, blueprint_fields: [field(null)] },
    );
    expect(clean.fields.modified).toBe(0);
  });

  it('still flags a genuine field reorder', () => {
    const raw = rawRoundTripFixture();
    const reordered = rawRoundTripFixture();
    // Genuinely move the first field to the end (a real order change).
    const moved = reordered.blueprint_fields.shift();
    moved.order_index = 99;
    reordered.blueprint_fields.push(moved);
    const newRaw = lib.parseYaml(lib.serializeYaml(reordered));
    const diff = lib.computeDiff(raw, newRaw);
    expect(diff.fields.modified).toBeGreaterThan(0);
  });

  it('still flags a genuine table_config content change', () => {
    const raw = rawRoundTripFixture();
    const mutated = rawRoundTripFixture();
    mutated.blueprint_fields[1].table_config = '{"columns": ["a", "b", "c"]}';
    const newRaw = lib.parseYaml(lib.serializeYaml(mutated));
    const diff = lib.computeDiff(raw, newRaw);
    expect(diff.fields.modified).toBeGreaterThan(0);
  });

  it('still flags a genuine option value change (map key) and a valid_parent_values content change (fingerprint)', () => {
    const raw = rawRoundTripFixture();

    const valueChanged = rawRoundTripFixture();
    valueChanged.field_options[0].option_label = 'Renamed';
    const diffValue = lib.computeDiff(raw, lib.parseYaml(lib.serializeYaml(valueChanged)));
    expect(diffValue.options.added + diffValue.options.removed + diffValue.options.modified)
      .toBeGreaterThan(0);

    const vpvChanged = rawRoundTripFixture();
    vpvChanged.field_options[0].valid_parent_values = '["cat_x", "cat_z"]';
    const diffVpv = lib.computeDiff(raw, lib.parseYaml(lib.serializeYaml(vpvChanged)));
    expect(diffVpv.options.modified).toBe(1);
  });

  it('does not throw and compares as-before when a JSON-ish column holds malformed text', () => {
    // Identical, contiguous fixture so the ONLY variable is the malformed
    // table_config text — it must fall back to a raw-string compare (equal).
    function contiguous() {
      return {
        import_version: 1,
        hierarchy_node: {
          id: 'bp-mf', parent_id: 'rel-mf', name: 'Malformed', description: '',
          node_type: 'blueprint', sort_order: 0, is_active: 1,
          transformer_id: null, transformer_version: null, linked_blueprint_id: null,
        },
        blueprint_fields: [
          {
            id: 'mf-f1', blueprint_id: 'bp-mf', field_key: 'a', field_label: 'A',
            field_type: 'text', is_required: 0, default_value: '', placeholder: '', tooltip: '',
            section: 'general', order_index: 0,
            table_config: '{not valid json', visibility_rule: null, choice_config: null,
            group_key: null, matrix_row_key: null, depends_on_field_key: null, retain_when_hidden: 0,
          },
        ],
        field_options: [], blueprint_sections: [], blueprint_groups: [],
        blueprint_output_order: [], _extensions: {},
      };
    }
    const raw = contiguous();
    const newRaw = contiguous();
    expect(() => lib.computeDiff(raw, newRaw)).not.toThrow();
    expect(lib.computeDiff(raw, newRaw).fields.modified).toBe(0);
  });
});

describe('overwriteBlueprint', () => {
  function makeFakeConn() {
    const queries = [];
    return {
      queries,
      query: vi.fn(async (sql, params) => {
        queries.push({ sql, params });
        if (/^SELECT \* FROM .*hierarchy_nodes/.test(sql)) {
          return [rawFixture().hierarchy_node];
        }
        if (/^SELECT \* FROM .*blueprint_fields/.test(sql)) {
          return rawFixture().blueprint_fields;
        }
        if (/^SELECT \* FROM .*field_options/.test(sql)) {
          return rawFixture().field_options;
        }
        if (/^SELECT \* FROM .*blueprint_sections/.test(sql)) {
          return rawFixture().blueprint_sections;
        }
        if (/^SELECT \* FROM .*blueprint_output_order/.test(sql)) {
          return rawFixture().blueprint_output_order;
        }
        if (/^SELECT id FROM .*blueprint_fields/.test(sql)) {
          return rawFixture().blueprint_fields.map((f) => ({ id: f.id }));
        }
        return [];
      }),
    };
  }

  const FAKE_TABLES = {
    HIERARCHY_NODES: 'hierarchy_nodes',
    BLUEPRINT_FIELDS: 'blueprint_fields',
    FIELD_OPTIONS: 'field_options',
    BLUEPRINT_SECTIONS: 'blueprint_sections',
    BLUEPRINT_GROUPS: 'blueprint_groups',
    BLUEPRINT_OUTPUT_ORDER: 'blueprint_output_order',
    FEATURE_AUDIT: 'feature_audit',
  };
  const fakeT = (name) => `fmb_${name}`;
  let counter = 0;
  const fakeUuid = () => `fake-uuid-${counter++}`;

  it('writes attempt + success audit rows around the cascade', async () => {
    const conn = makeFakeConn();
    const newPayload = lib.parseYaml(lib.serializeYaml(rawFixture()));
    const result = await lib.overwriteBlueprint({
      conn, t: fakeT, TABLES: FAKE_TABLES, uuidv4: fakeUuid,
      existingId: 'bp-uuid-1',
      payload: newPayload,
      userId: 'admin-1',
      expectedRevision: lib.computeRevision(rawFixture()),
    });
    expect(result.ok).toBe(true);
    const auditQueries = conn.queries.filter((q) => /feature_audit/.test(q.sql));
    expect(auditQueries.length).toBe(2);
    expect(auditQueries[0].params[1]).toBe('blueprint.overwrite.attempt');
    expect(auditQueries[1].params[1]).toBe('blueprint.overwrite.success');
  });

  it('rejects stale revision with STALE_REVISION code', async () => {
    const conn = makeFakeConn();
    const newPayload = lib.parseYaml(lib.serializeYaml(rawFixture()));
    await expect(
      lib.overwriteBlueprint({
        conn, t: fakeT, TABLES: FAKE_TABLES, uuidv4: fakeUuid,
        existingId: 'bp-uuid-1',
        payload: newPayload,
        userId: 'admin-1',
        expectedRevision: 'definitely-not-matching-hash',
      }),
    ).rejects.toMatchObject({ code: 'STALE_REVISION' });
  });

  it('rejects when target blueprint does not exist', async () => {
    const conn = {
      query: vi.fn(async (sql) => {
        if (/^SELECT \* FROM .*hierarchy_nodes/.test(sql)) return [];
        return [];
      }),
    };
    await expect(
      lib.overwriteBlueprint({
        conn, t: fakeT, TABLES: FAKE_TABLES, uuidv4: fakeUuid,
        existingId: 'missing',
        payload: lib.parseYaml(lib.serializeYaml(rawFixture())),
        userId: 'admin-1',
        expectedRevision: 'any',
      }),
    ).rejects.toMatchObject({ code: 'NOT_FOUND' });
  });

  it('rejects overwrite without expected_revision (Codex round 3)', async () => {
    const conn = makeFakeConn();
    const newPayload = lib.parseYaml(lib.serializeYaml(rawFixture()));
    await expect(
      lib.overwriteBlueprint({
        conn, t: fakeT, TABLES: FAKE_TABLES, uuidv4: fakeUuid,
        existingId: 'bp-uuid-1',
        payload: newPayload,
        userId: 'admin-1',
        // expectedRevision omitted on purpose
      }),
    ).rejects.toMatchObject({ code: 'REVISION_REQUIRED' });
  });

  it('skips group rows when blueprint_groups table is absent (tolerant, no crash)', async () => {
    // makeFakeConn answers the information_schema.TABLES probe with [] → the
    // additive table is treated as missing. A payload that DOES carry a group
    // must be silently skipped, and the rest of the overwrite must still succeed.
    const conn = makeFakeConn();
    const raw = rawFixture();
    raw.blueprint_groups = [{
      id: 'grp-1', blueprint_id: 'bp-uuid-1', group_key: 'lane_a',
      display_label: 'Lane A', color_key: 'blue', sort_order: 0,
    }];
    const payload = lib.parseYaml(lib.serializeYaml(raw));
    expect(payload.blueprint_groups).toHaveLength(1); // guard: payload really has a group

    const result = await lib.overwriteBlueprint({
      conn, t: fakeT, TABLES: FAKE_TABLES, uuidv4: fakeUuid,
      existingId: 'bp-uuid-1',
      payload,
      // loadRawExport returns no groups (fake conn []), so the current revision
      // matches a groupless rawFixture — the group is purely in the new payload.
      expectedRevision: lib.computeRevision(rawFixture()),
    });
    expect(result.ok).toBe(true);

    // No DELETE or INSERT ever touched blueprint_groups (the SELECT * probe in
    // loadRawExport is tolerated separately and does not write).
    const groupWrites = conn.queries.filter(
      (q) => /blueprint_groups/.test(q.sql) && /^\s*(INSERT|DELETE)/i.test(q.sql),
    );
    expect(groupWrites.length).toBe(0);
  });
});

describe('parseYaml — strict collection types', () => {
  it.each(['fields', 'sections', 'output_order'])(
    'rejects %s as a non-array value (Codex round 3)',
    (collection) => {
      const tpl = `
import_version: 1
blueprint:
  name: bad
${collection}:
  oops: not-an-array
`;
      expect(() => lib.parseYaml(tpl)).toThrowError(/must be an array/);
    },
  );
});

describe('computeRevision — sort_order sensitivity (Codex round 3)', () => {
  it.each(['blueprint_sections', 'blueprint_output_order'])(
    'changes when %s sort_order is edited',
    (bucket) => {
      const a = rawFixture();
      const b = rawFixture();
      b[bucket][0].sort_order = (a[bucket][0].sort_order ?? 0) + 99;
      expect(lib.computeRevision(a)).not.toBe(lib.computeRevision(b));
    },
  );

  it('changes when field_options sort_order is edited', () => {
    const a = rawFixture();
    const b = rawFixture();
    b.field_options[0].sort_order = 99;
    expect(lib.computeRevision(a)).not.toBe(lib.computeRevision(b));
  });

  function rawWith1Group(sortOrder) {
    const raw = rawFixture();
    raw.blueprint_groups = [{
      id: 'grp-1', blueprint_id: 'bp-uuid-1', group_key: 'lane_a',
      display_label: 'Lane A', color_key: 'blue', sort_order: sortOrder,
    }];
    return raw;
  }

  it('changes when a blueprint_groups sort_order is edited', () => {
    // Full-row canonicalRow hashes sort_order, so a reorder still invalidates
    // the optimistic-lock revision (prevents a silent clobber on overwrite).
    expect(lib.computeRevision(rawWith1Group(0))).not.toBe(lib.computeRevision(rawWith1Group(99)));
  });

  it('a group sort_order-only edit is silent in computeDiff (revision-guarded, mirrors sections)', () => {
    const oldRaw = rawWith1Group(0);
    const newRaw = rawWith1Group(5);
    // Revision changes (safety lock covers the reorder)...
    expect(lib.computeRevision(oldRaw)).not.toBe(lib.computeRevision(newRaw));
    // ...but the diff summary stays silent because groupDiff fingerprints only
    // label + color (identical to the section fingerprint contract). This pins
    // the mirror so a future canonicalRow / groupDiff refactor can't drift it.
    const diff = lib.computeDiff(oldRaw, newRaw);
    expect(diff.groups.added).toBe(0);
    expect(diff.groups.removed).toBe(0);
    expect(diff.groups.modified).toBe(0);
  });
});

describe('selectBlueprintGroups — missing-table tolerance', () => {
  const FAKE_TABLES = { BLUEPRINT_GROUPS: 'blueprint_groups' };
  const fakeT = (name) => `fmb_${name}`;

  it('returns [] on ER_NO_SUCH_TABLE (1146) so a pre-migration target never crashes', async () => {
    const conn = {
      query: async () => {
        const e = new Error('Table doesn\'t exist');
        e.errno = 1146;
        e.code = 'ER_NO_SUCH_TABLE';
        throw e;
      },
    };
    const rows = await lib.selectBlueprintGroups({ conn, t: fakeT, TABLES: FAKE_TABLES, blueprintId: 'bp-1' });
    expect(rows).toEqual([]);
  });

  it('re-throws a non-1146 error (never masks a real failure as an empty set)', async () => {
    const conn = {
      query: async () => {
        const e = new Error('Access denied');
        e.errno = 1045;
        throw e;
      },
    };
    await expect(
      lib.selectBlueprintGroups({ conn, t: fakeT, TABLES: FAKE_TABLES, blueprintId: 'bp-1' }),
    ).rejects.toThrow(/Access denied/);
  });

  it('returns the rows verbatim when the table exists', async () => {
    const conn = { query: async () => [{ id: 'g1', group_key: 'lane_a' }] };
    const rows = await lib.selectBlueprintGroups({ conn, t: fakeT, TABLES: FAKE_TABLES, blueprintId: 'bp-1' });
    expect(rows).toHaveLength(1);
  });
});
