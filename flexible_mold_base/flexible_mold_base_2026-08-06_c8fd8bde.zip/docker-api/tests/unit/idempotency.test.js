/**
 * idempotency.test.js — RED-first coverage for the P3 idempotency helper
 * (docker-api/src/edge/lib/idempotency.js), spec §6 M2.
 *
 * Pure surface only (the reserve/create/finalize SQL orchestration + the
 * concurrent double-fire proof live in the edge public-write route test, which
 * needs the real handler + a mock pool):
 *   - canonicalize gives a stable key order so a reordered body fingerprints
 *     identically (the dedup window keys on INTENT, not byte order).
 *   - bodyFingerprint is SHA-256 hex, order-insensitive, value-sensitive.
 *   - classifyExisting is the reserve-collision decision: expired / different
 *     fingerprint / same-fingerprint-still-reserved / same-fingerprint-finalized.
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');

const {
  canonicalize,
  bodyFingerprint,
  classifyExisting,
  RESERVED_STATUS,
} = require('../../src/edge/lib/idempotency');

describe('canonicalize — stable deep key order', () => {
  it('sorts object keys recursively, preserves array order', () => {
    const out = canonicalize({ b: 1, a: { d: 4, c: 3 }, arr: [{ y: 2, x: 1 }] });
    assert.equal(JSON.stringify(out), JSON.stringify({ a: { c: 3, d: 4 }, arr: [{ x: 1, y: 2 }], b: 1 }));
  });
});

describe('bodyFingerprint — SHA-256 hex, order-insensitive, value-sensitive', () => {
  it('is a 64-char hex digest', () => {
    assert.match(bodyFingerprint({ path: 'a/b' }), /^[0-9a-f]{64}$/);
  });

  it('reordered keys → identical fingerprint', () => {
    assert.equal(
      bodyFingerprint({ path: 'Cat/Rel/BP', name: 'x', owner_username: 'u' }),
      bodyFingerprint({ owner_username: 'u', name: 'x', path: 'Cat/Rel/BP' }),
    );
  });

  it('changed value → different fingerprint', () => {
    assert.notEqual(bodyFingerprint({ path: 'a' }), bodyFingerprint({ path: 'b' }));
  });

  it('null/undefined body fingerprints deterministically (no throw)', () => {
    assert.equal(bodyFingerprint(null), bodyFingerprint(undefined));
    assert.match(bodyFingerprint(null), /^[0-9a-f]{64}$/);
  });

  it('NFC vs NFD encodings of the same body → identical fingerprint', () => {
    // "Café" composed (U+00E9) vs decomposed (e + U+0301). The name-path resolver
    // NFC-normalises before matching, so the fingerprint must too — otherwise two
    // byte-different-but-identical retries would be treated as different intents.
    const composed = 'Caf\u00e9/Rev'; // é as a single code point (NFC)
    const decomposed = 'Cafe\u0301/Rev'; // e + combining acute accent (NFD)
    assert.notEqual(composed, decomposed); // genuinely different bytes
    assert.equal(bodyFingerprint({ path: composed }), bodyFingerprint({ path: decomposed }));
  });
});

describe('classifyExisting — reserve-collision decision', () => {
  const FP = bodyFingerprint({ path: 'a' });
  const NOW = Date.parse('2026-07-11T12:00:00Z');
  const FUTURE = '2026-07-11 13:00:00'; // driver naive-UTC string, +1h
  const PAST = '2026-07-11 11:00:00';   // −1h

  it('expired reservation → expired (replace & proceed)', () => {
    const r = classifyExisting(
      { body_fingerprint: FP, response_status: RESERVED_STATUS, response_body: null, expires_at: PAST },
      FP, NOW,
    );
    assert.equal(r.kind, 'expired');
  });

  it('different fingerprint (live) → conflict_fingerprint', () => {
    const r = classifyExisting(
      { body_fingerprint: 'ff'.repeat(32), response_status: 201, response_body: {}, expires_at: FUTURE },
      FP, NOW,
    );
    assert.equal(r.kind, 'conflict_fingerprint');
  });

  it('same fingerprint, still reserved (in-flight) → conflict_reserved', () => {
    const r = classifyExisting(
      { body_fingerprint: FP, response_status: RESERVED_STATUS, response_body: null, expires_at: FUTURE },
      FP, NOW,
    );
    assert.equal(r.kind, 'conflict_reserved');
  });

  it('same fingerprint, finalized → replay stored status + body', () => {
    const body = { id: 't-1', is_draft: true };
    const r = classifyExisting(
      { body_fingerprint: FP, response_status: 201, response_body: body, expires_at: FUTURE },
      FP, NOW,
    );
    assert.equal(r.kind, 'replay');
    assert.equal(r.status, 201);
    assert.deepEqual(r.body, body);
  });

  it('replay parses a JSON-string response_body (driver LONGTEXT variant)', () => {
    const r = classifyExisting(
      { body_fingerprint: FP, response_status: 201, response_body: '{"id":"t-2"}', expires_at: FUTURE },
      FP, NOW,
    );
    assert.equal(r.kind, 'replay');
    assert.deepEqual(r.body, { id: 't-2' });
  });

  it('expiry takes precedence over a fingerprint mismatch (stale row is replaceable)', () => {
    const r = classifyExisting(
      { body_fingerprint: 'ff'.repeat(32), response_status: 201, response_body: {}, expires_at: PAST },
      FP, NOW,
    );
    assert.equal(r.kind, 'expired');
  });
});
