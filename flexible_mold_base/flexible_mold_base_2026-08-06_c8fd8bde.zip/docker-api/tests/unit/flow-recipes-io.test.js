/**
 * flow-recipes-io.test.js — recipe export/import route behaviour.
 *
 * Boots the real flow-recipes router against a mocked db pool (require.cache
 * seed, same pattern as api-connectors-io.test.js) and asserts:
 *   - GET /:id/export bundles recipe + steps, strips step secrets, carries lineage
 *   - export degrades on a no-ALTER source (missing runs_on / step-code columns)
 *   - POST /import binds by lineage, re-stamps approval, preserves step sequence
 *   - import egress allow-list gate (api step blocked; compute sentinel skipped)
 *   - import editor/admin unbound rules + malformed-metadata degrade + url hard-reject
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../src/edge/db');

let state;
function makeConn() {
  return {
    async beginTransaction() {},
    async commit() {},
    async rollback() {},
    async query(sql, params) {
      state.queries.push({ sql, params });

      // hierarchy nodes — export (id,parent_id,name) + import (…,node_type)
      if (/SELECT id, parent_id, name(?:, node_type)? FROM `fmb_hierarchy_nodes`/.test(sql)) {
        return state.nodes || [];
      }
      if (/SELECT owner_id FROM `fmb_hierarchy_nodes` WHERE id = \?/.test(sql)) {
        return state.blueprintOwner === undefined ? [] : [{ owner_id: state.blueprintOwner }];
      }
      if (/SELECT 1 FROM `fmb_hierarchy_nodes`/.test(sql)) {
        return state.blueprintExists ? [{ 1: 1 }] : [];
      }

      // recipe export SELECT (full carries runs_on; legacy drops it)
      if (/FROM `fmb_flow_recipes` WHERE id = \?/.test(sql) && /SELECT name, description/.test(sql)) {
        if (/runs_on/.test(sql) && state.failRecipeRunsOn) {
          const e = new Error("Unknown column 'runs_on'");
          e.code = 'ER_BAD_FIELD_ERROR'; e.errno = 1054; throw e;
        }
        return state.exportRow ? [state.exportRow] : [];
      }
      // steps export SELECT (full carries step_type/before/after; legacy drops)
      if (/FROM `fmb_flow_recipe_steps` WHERE recipe_id = \?/.test(sql) && /SELECT `sequence`, name, method/.test(sql)) {
        if (/step_type/.test(sql) && state.failStepCols) {
          const e = new Error("Unknown column 'step_type'");
          e.code = 'ER_BAD_FIELD_ERROR'; e.errno = 1054; throw e;
        }
        return state.exportSteps || [];
      }

      // recipe INSERT + best-effort UPDATEs
      if (/^INSERT INTO `fmb_flow_recipes`/.test(sql.trim())) {
        state.recipeInsertParams = params;
        return { affectedRows: 1 };
      }
      if (/UPDATE `fmb_flow_recipes` SET payload_transform_code/.test(sql)) {
        if (state.failPayloadCodeUpdate) {
          const e = new Error("Unknown column 'payload_transform_code'");
          e.code = 'ER_BAD_FIELD_ERROR'; e.errno = 1054; throw e;
        }
        state.payloadCodeUpdate = params; return { affectedRows: 1 };
      }
      if (/UPDATE `fmb_flow_recipes` SET runs_on/.test(sql)) {
        if (state.failRunsOnUpdate) {
          const e = new Error("Unknown column 'runs_on'");
          e.code = 'ER_BAD_FIELD_ERROR'; e.errno = 1054; throw e;
        }
        state.runsOnUpdate = params; return { affectedRows: 1 };
      }
      if (/UPDATE `fmb_flow_recipes` SET status/.test(sql)) {
        state.statusUpdate = sql; return { affectedRows: 1 };
      }
      // step INSERT + best-effort code UPDATE
      if (/^INSERT INTO `fmb_flow_recipe_steps`/.test(sql.trim())) {
        (state.stepInserts ||= []).push(params);
        return { affectedRows: 1 };
      }
      if (/UPDATE `fmb_flow_recipe_steps`\s+SET step_type/.test(sql)) {
        if (state.failStepCodeUpdate) {
          const e = new Error("Unknown column 'step_type'");
          e.code = 'ER_BAD_FIELD_ERROR'; e.errno = 1054; throw e;
        }
        (state.stepCodeUpdates ||= []).push(params); return { affectedRows: 1 };
      }
      // counter-column presence probe (import seed gates on it)
      if (/information_schema\.COLUMNS/i.test(sql)) {
        return state.counterColumnAbsent ? [] : [{ 1: 1 }];
      }
      // code-version seed (fresh v1 'import' chain)
      if (/^INSERT INTO `fmb_flow_recipe_code_versions`/.test(sql.trim())) {
        if (state.failCodeVersionSeed) {
          const e = new Error("Table doesn't exist"); e.errno = 1146; e.code = 'ER_NO_SUCH_TABLE'; throw e;
        }
        state.codeVersionSeed = { sql, params }; return { affectedRows: 1 };
      }
      // read-back
      if (/SELECT \* FROM `fmb_flow_recipes` WHERE id = \?/.test(sql)) {
        return [{ id: params[0], name: 'imported', status: 'pending' }];
      }
      // pre-delete step probe (delete-guard middleware) — never on import path
      if (/SELECT 1 FROM `fmb_flow_recipe_steps`/.test(sql)) return [];
      // egress allow-list read
      if (/SELECT `value` FROM `fmb_system_settings` WHERE `key` = \?/.test(sql)) {
        return state.allowlistRow === undefined ? [] : [{ value: state.allowlistRow }];
      }
      return [];
    },
    release() {},
  };
}

const poolSpy = {
  ro: { async getConnection() { return makeConn(); }, async query(sql, params) { return makeConn().query(sql, params); } },
  rw: { async getConnection() { return makeConn(); }, async query(sql, params) { return makeConn().query(sql, params); } },
};

require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: poolSpy, t: (name) => `fmb_${name}`, getDynamicPool: async () => poolSpy },
};

const router = require('../../src/edge/routes/app/flow-recipes');

let server;
let base;
let currentUser;

before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { req.user = currentUser; next(); });
  app.use('/r', router);
  server = http.createServer(app);
  await new Promise((r) => server.listen(0, r));
  base = `http://127.0.0.1:${server.address().port}`;
});

after(() => server && server.close());

beforeEach(() => {
  state = { queries: [], blueprintExists: false, exportRow: null, exportSteps: [], nodes: [], recipeInsertParams: null, stepInserts: null };
  currentUser = { id: 'admin-1', role: 'admin', email: 'a@x' };
});

async function req(method, path, body) {
  const res = await fetch(`${base}${path}`, {
    method,
    headers: { 'content-type': 'application/json' },
    body: body ? JSON.stringify(body) : undefined,
  });
  return { status: res.status, json: await res.json() };
}

const baseRecipe = () => ({
  name: 'weather flow', description: null, is_active: 1, blueprint_id: 'bp-1',
  content_type: 'application/json', payload_transform_code: 'return {}',
  consumed_output_keys: JSON.stringify(['a', 'b']),
  link_extract: null, external_id_extract: null, runs_on: 'create',
});

describe('GET /:id/export', () => {
  it('bundles recipe + steps and strips step secrets', async () => {
    state.exportRow = baseRecipe();
    state.exportSteps = [{
      sequence: 1, name: 'push', method: 'POST', url: 'http://svc/x',
      auth_type: 'bearer', auth_config: JSON.stringify({ token: 'enc:v1:secret' }),
      request_config: null, response_config: null, input_from_step: null,
      dispatch_origin: 'infra', timeout_ms: null,
      step_type: 'api', before_code: null, after_code: null,
    }];
    const { status, json } = await req('GET', '/r/abc/export');
    assert.equal(status, 200);
    assert.equal(json.data.export_version, 1);
    assert.equal(json.data.recipe.name, 'weather flow');
    assert.equal(json.data.recipe.runs_on, 'create');
    assert.deepEqual(json.data.recipe.consumed_output_keys, ['a', 'b']);
    assert.equal(json.data.steps.length, 1);
    assert.equal('token' in json.data.steps[0].auth_config, false, 'step secret must not be exported');
    assert.ok(json.data.exported_at);
  });

  it('404s when the recipe is missing', async () => {
    state.exportRow = null;
    const { status, json } = await req('GET', '/r/none/export');
    assert.equal(status, 404);
    assert.equal(json.error.code, 'NOT_FOUND');
  });

  it('carries the blueprint lineage as recipe.blueprint_path', async () => {
    state.exportRow = baseRecipe();
    state.nodes = [
      { id: 'g', parent_id: null, name: 'Gen A' },
      { id: 'r', parent_id: 'g', name: 'Release 1' },
      { id: 'bp-1', parent_id: 'r', name: 'Mold' },
    ];
    const { status, json } = await req('GET', '/r/abc/export');
    assert.equal(status, 200);
    assert.deepEqual(json.data.recipe.blueprint_path, ['Gen A', 'Release 1', 'Mold']);
  });

  it('degrades runs_on to null when the source lacks the column (no-ALTER)', async () => {
    state.exportRow = { ...baseRecipe() }; delete state.exportRow.runs_on;
    state.failRecipeRunsOn = true;
    const { status, json } = await req('GET', '/r/abc/export');
    assert.equal(status, 200, 'a missing runs_on column must not fail the export');
    assert.strictEqual(json.data.recipe.runs_on, null);
  });

  it('defaults step_type=api when the source lacks the chaining columns (no-ALTER)', async () => {
    state.exportRow = baseRecipe();
    state.failStepCols = true;
    state.exportSteps = [{
      sequence: 1, name: 'push', method: 'POST', url: 'http://svc/x',
      auth_type: 'none', auth_config: null, request_config: null,
      response_config: null, input_from_step: null, dispatch_origin: 'infra',
      timeout_ms: null,
    }];
    const { status, json } = await req('GET', '/r/abc/export');
    assert.equal(status, 200);
    assert.equal(json.data.steps[0].step_type, 'api');
    assert.strictEqual(json.data.steps[0].before_code, null);
  });

  it('lets an editor export any recipe', async () => {
    currentUser = { id: 'ed-1', role: 'editor', email: 'e@x' };
    state.exportRow = baseRecipe();
    const { status } = await req('GET', '/r/abc/export');
    assert.equal(status, 200);
  });

  it('strips a stray ciphertext leaf that does not belong to the current auth_type', async () => {
    state.exportRow = baseRecipe();
    // auth_type changed to 'none' but a stale bearer token ciphertext lingers.
    state.exportSteps = [{
      sequence: 1, name: 'stale', method: 'POST', url: 'http://svc/x',
      auth_type: 'none', auth_config: JSON.stringify({ token: 'enc:v1:STALE' }),
      request_config: null, response_config: null, input_from_step: null,
      dispatch_origin: 'infra', timeout_ms: null,
      step_type: 'api', before_code: null, after_code: null,
    }];
    const { status, json } = await req('GET', '/r/abc/export');
    assert.equal(status, 200);
    assert.equal('token' in json.data.steps[0].auth_config, false, 'stray ciphertext must not survive export');
  });

  it('blanks credential-valued request_config headers on export', async () => {
    state.exportRow = baseRecipe();
    state.exportSteps = [{
      sequence: 1, name: 'h', method: 'POST', url: 'http://svc/x', auth_type: 'none',
      auth_config: null,
      request_config: JSON.stringify({ headers: { Authorization: 'Bearer SECRET', 'X-Api-Key': 'k', 'X-Trace': 'ok' }, body: '{}' }),
      response_config: null, input_from_step: null, dispatch_origin: 'infra',
      timeout_ms: null, step_type: 'api', before_code: null, after_code: null,
    }];
    const { status, json } = await req('GET', '/r/abc/export');
    assert.equal(status, 200);
    const h = json.data.steps[0].request_config.headers;
    assert.equal(h.Authorization, '', 'Authorization value blanked');
    assert.equal(h['X-Api-Key'], '', 'api-key value blanked');
    assert.equal(h['X-Trace'], 'ok', 'non-sensitive header kept');
  });

  it('strips URL-embedded credentials from a step url on export', async () => {
    state.exportRow = baseRecipe();
    state.exportSteps = [{
      sequence: 1, name: 'creds', method: 'POST', url: 'https://user:s3cr3t@svc/x',
      auth_type: 'none', auth_config: null, request_config: null, response_config: null,
      input_from_step: null, dispatch_origin: 'infra', timeout_ms: null,
      step_type: 'api', before_code: null, after_code: null,
    }];
    const { status, json } = await req('GET', '/r/abc/export');
    assert.equal(status, 200);
    assert.equal(json.data.steps[0].url, 'https://svc/x', 'userinfo must be stripped from the exported url');
  });

  it('rejects a plain user export with 403', async () => {
    currentUser = { id: 'u-1', role: 'user', email: 'u@x' };
    state.exportRow = baseRecipe();
    const { status, json } = await req('GET', '/r/abc/export');
    assert.equal(status, 403);
    assert.equal(json.error.code, 'FORBIDDEN');
  });
});

describe('POST /import', () => {
  it('imports a recipe + steps, preserves sequence, stamps approved for admin', async () => {
    state.blueprintExists = true;
    const { status, json } = await req('POST', '/r/import', {
      recipe: { name: 'w', blueprint_id: 'bp-1', content_type: 'application/json', runs_on: 'both' },
      steps: [
        { sequence: 1, name: 's1', method: 'POST', url: 'http://svc/a', auth_type: 'none' },
        { sequence: 2, name: 's2', method: 'GET', url: 'http://svc/b', auth_type: 'none' },
      ],
    });
    assert.equal(status, 201);
    assert.equal(json.data.steps_imported, 2);
    assert.equal(state.recipeInsertParams[5], 'bp-1', 'recipe binds the blueprint');
    assert.equal(state.stepInserts.length, 2);
    assert.equal(state.stepInserts[0][2], 1, 'step 1 sequence preserved');
    assert.equal(state.stepInserts[1][2], 2, 'step 2 sequence preserved');
    assert.ok(state.statusUpdate && /status='approved'/.test(state.statusUpdate), 'admin import → approved');
  });

  it('does not persist a masked credential header on an imported step', async () => {
    // THE MIRROR LANE, on the verb that creates the row. A hand-built bundle
    // carrying `"Authorization":"****"` stored the four literal characters as
    // the header the step is dispatched with. Export blanks these to `''`, so a
    // genuine round trip never reaches it — a hand-edited bundle does, and that
    // is what this path accepts.
    state.blueprintExists = true;
    const { status } = await req('POST', '/r/import', {
      recipe: { name: 'w', blueprint_id: 'bp-1' },
      steps: [{
        sequence: 1,
        name: 's1',
        method: 'POST',
        url: 'http://svc/a',
        auth_type: 'none',
        request_config: { headers: { Authorization: '****', Accept: 'application/json' } },
      }],
    });
    assert.equal(status, 201);
    // Step INSERT param index 8 = request_config.
    const stored = JSON.parse(state.stepInserts[0][8]);
    assert.equal(
      stored.headers.Authorization, undefined,
      'the mask sentinel was stored as the step credential header',
    );
    assert.equal(
      stored.headers.Accept, 'application/json',
      'an ordinary header was dropped with it',
    );
  });

  it('rejects an import whose consumed_output_keys has a reserved "payload." key → 400 (Task 2)', async () => {
    state.blueprintExists = true;
    const { status, json } = await req('POST', '/r/import', {
      recipe: { name: 'w', blueprint_id: 'bp-1', consumed_output_keys: ['ok', 'payload.qty'] },
      steps: [],
    });
    assert.equal(status, 400, `expected 400, got ${status}: ${JSON.stringify(json)}`);
    assert.equal(json.error.code, 'RESERVED_OUTPUT_KEY');
    assert.equal(state.recipeInsertParams, null, 'a reserved-key import must not INSERT');
  });

  it('rejects an import whose consumed_output_keys is exactly "payload" → 400 (Task 2)', async () => {
    state.blueprintExists = true;
    const { status, json } = await req('POST', '/r/import', {
      recipe: { name: 'w', blueprint_id: 'bp-1', consumed_output_keys: ['payload'] },
      steps: [],
    });
    assert.equal(status, 400, `expected 400, got ${status}: ${JSON.stringify(json)}`);
    assert.equal(json.error.code, 'RESERVED_OUTPUT_KEY');
  });

  it('imports normally when consumed_output_keys has only non-reserved keys ("qty", "payloadX")', async () => {
    state.blueprintExists = true;
    const { status, json } = await req('POST', '/r/import', {
      recipe: { name: 'w', blueprint_id: 'bp-1', consumed_output_keys: ['qty', 'payloadX'] },
      steps: [],
    });
    assert.equal(status, 201, `expected 201, got ${status}: ${JSON.stringify(json)}`);
  });

  it('seeds a fresh v1 import history row recording the imported code', async () => {
    state.blueprintExists = true;
    const { status } = await req('POST', '/r/import', {
      recipe: { name: 'w', blueprint_id: 'bp-1', payload_transform_code: 'return 42;' },
      steps: [],
    });
    assert.equal(status, 201);
    assert.ok(state.codeVersionSeed, 'a v1 history row must be seeded');
    assert.ok(/VALUES \(\?, \?, 1, \?, 'import', \?\)/.test(state.codeVersionSeed.sql), 'version literal 1 + action import');
    assert.equal(state.codeVersionSeed.params[2], 'return 42;', 'history code = imported code');
    assert.equal(state.codeVersionSeed.params[3], 'admin-1', 'created_by = importer');
  });

  it('still imports when the target lacks the code-version table (no-ALTER best-effort)', async () => {
    state.blueprintExists = true;
    state.failCodeVersionSeed = true;
    const { status, json } = await req('POST', '/r/import', {
      recipe: { name: 'w', blueprint_id: 'bp-1', payload_transform_code: 'return 42;' },
      steps: [],
    });
    assert.equal(status, 201, 'a missing history table must not fail the import');
    assert.equal(json.data.steps_imported, 0);
  });

  it('seeds no history when the code UPDATE 1054s on a legacy target (code not stored)', async () => {
    // COHERENCE: the payload_transform_code column is absent, so the code was never
    // stored on the recipe row; a v1 history row must not claim it.
    state.blueprintExists = true;
    state.failPayloadCodeUpdate = true;
    const { status } = await req('POST', '/r/import', {
      recipe: { name: 'w', blueprint_id: 'bp-1', payload_transform_code: 'return 42;' },
      steps: [],
    });
    assert.equal(status, 201, 'import still succeeds');
    assert.equal(state.codeVersionSeed, undefined, 'no history row when the code was not stored');
  });

  it('seeds no history when the counter column is absent (history table present)', async () => {
    // COHERENCE: code stored but the code_version counter column is missing → later
    // CRUD PUTs would degrade unversioned, so a v1 chain start here would be stale.
    state.blueprintExists = true;
    state.counterColumnAbsent = true;
    const { status } = await req('POST', '/r/import', {
      recipe: { name: 'w', blueprint_id: 'bp-1', payload_transform_code: 'return 42;' },
      steps: [],
    });
    assert.equal(status, 201, 'import still succeeds');
    assert.equal(state.codeVersionSeed, undefined, 'no v1 seed without the counter column');
  });

  it('stamps status=pending on an editor import', async () => {
    currentUser = { id: 'ed-1', role: 'editor', email: 'e@x' };
    state.blueprintExists = true; state.blueprintOwner = 'ed-1';
    const { status } = await req('POST', '/r/import', {
      recipe: { name: 'w', blueprint_id: 'bp-1' }, steps: [],
    });
    assert.equal(status, 201);
    assert.ok(state.statusUpdate && /status='pending'/.test(state.statusUpdate));
  });

  it('rejects a payload missing recipe.name', async () => {
    const { status, json } = await req('POST', '/r/import', { recipe: {} });
    assert.equal(status, 400);
    assert.equal(json.error.code, 'BAD_REQUEST');
  });

  it('blocks an off-allow-list api step (422, nothing imported, names the step)', async () => {
    state.blueprintExists = true;
    state.allowlistRow = JSON.stringify(['allowed.example.com']);
    const { status, json } = await req('POST', '/r/import', {
      recipe: { name: 'w', blueprint_id: 'bp-1' },
      steps: [{ sequence: 1, name: 'leaky', method: 'POST', url: 'http://blocked.example.net/x', auth_type: 'none' }],
    });
    assert.equal(status, 422);
    assert.equal(json.error.code, 'EGRESS_BLOCKED');
    assert.match(json.error.message, /leaky/);
    assert.equal(state.recipeInsertParams, null, 'an off-list import must not INSERT');
  });

  it('skips the egress check for a compute step (sentinel url) and imports', async () => {
    state.blueprintExists = true;
    state.allowlistRow = JSON.stringify(['allowed.example.com']);
    const { status } = await req('POST', '/r/import', {
      recipe: { name: 'w', blueprint_id: 'bp-1' },
      steps: [{ sequence: 1, name: 'calc', step_type: 'compute', before_code: 'return {x:1}' }],
    });
    assert.equal(status, 201, 'a compute step must not be egress-checked');
    assert.equal(state.stepInserts[0][5], 'https://compute.invalid/', 'compute url pinned to sentinel');
  });

  it('allows an on-allow-list api step (201)', async () => {
    state.blueprintExists = true;
    state.allowlistRow = JSON.stringify(['allowed.example.com']);
    const { status } = await req('POST', '/r/import', {
      recipe: { name: 'w', blueprint_id: 'bp-1' },
      steps: [{ sequence: 1, name: 's', method: 'POST', url: 'http://allowed.example.com/x', auth_type: 'none' }],
    });
    assert.equal(status, 201);
  });

  it('hard-rejects an api step with a non-http url (400, no insert)', async () => {
    state.blueprintExists = true;
    const { status, json } = await req('POST', '/r/import', {
      recipe: { name: 'w', blueprint_id: 'bp-1' },
      steps: [{ sequence: 1, name: 'bad', method: 'POST', url: 'file:///etc/passwd', auth_type: 'none' }],
    });
    assert.equal(status, 400);
    assert.equal(json.error.code, 'BAD_REQUEST');
    assert.equal(state.recipeInsertParams, null);
  });

  it('rejects an api step url with embedded credentials (400, no insert)', async () => {
    state.blueprintExists = true;
    const { status, json } = await req('POST', '/r/import', {
      recipe: { name: 'w', blueprint_id: 'bp-1' },
      steps: [{ sequence: 1, name: 'creds', method: 'POST', url: 'https://user:pass@svc/x', auth_type: 'none' }],
    });
    assert.equal(status, 400);
    assert.equal(json.error.code, 'BAD_REQUEST');
    assert.equal(state.recipeInsertParams, null);
  });

  it('preserves a bare-string link_extract spec on import (not nulled by JSON.parse)', async () => {
    state.blueprintExists = true;
    const { status } = await req('POST', '/r/import', {
      recipe: { name: 'w', blueprint_id: 'bp-1', link_extract: '$.data.url', external_id_extract: { path: '$.id' } },
      steps: [],
    });
    assert.equal(status, 201);
    // INSERT params: id,name,desc,is_active,owner,blueprint_id,content_type,
    //   consumed_output_keys,link_extract,external_id_extract (payload_transform_code
    //   + runs_on are separate best-effort UPDATEs).
    assert.equal(state.recipeInsertParams[8], JSON.stringify('$.data.url'), 'bare-string link_extract preserved');
    assert.equal(state.recipeInsertParams[9], JSON.stringify({ path: '$.id' }), 'object external_id_extract preserved');
  });

  it('binds by a unique blueprint_path even when blueprint_id is foreign', async () => {
    state.nodes = [
      { id: 'g', parent_id: null, name: 'Gen A', node_type: 'generation' },
      { id: 'local-bp', parent_id: 'g', name: 'Mold', node_type: 'blueprint' },
    ];
    const { status } = await req('POST', '/r/import', {
      recipe: { name: 'w', blueprint_id: 'foreign-uuid', blueprint_path: ['Gen A', 'Mold'] },
      steps: [],
    });
    assert.equal(status, 201);
    assert.equal(state.recipeInsertParams[5], 'local-bp', 'path match binds the LOCAL blueprint id');
  });

  it('stays unbound when no blueprint resolves (admin) and flags unbound', async () => {
    state.blueprintExists = false;
    const { status, json } = await req('POST', '/r/import', {
      recipe: { name: 'w', blueprint_id: 'ghost' }, steps: [],
    });
    assert.equal(status, 201);
    assert.strictEqual(state.recipeInsertParams[5], null);
    assert.equal(json.data.unbound, true);
  });

  it('rejects an editor import that resolves no own/shared blueprint (403, no insert)', async () => {
    currentUser = { id: 'ed-1', role: 'editor', email: 'e@x' };
    state.blueprintExists = true; state.blueprintOwner = 'someone-else';
    const { status, json } = await req('POST', '/r/import', {
      recipe: { name: 'w', blueprint_id: 'bp-1' }, steps: [],
    });
    assert.equal(status, 403);
    assert.equal(json.error.code, 'FORBIDDEN');
    assert.equal(state.recipeInsertParams, null);
  });

  it('degrades malformed recipe metadata to defaults (no runs_on UPDATE, default content_type)', async () => {
    state.blueprintExists = true;
    const { status } = await req('POST', '/r/import', {
      recipe: { name: 'w', blueprint_id: 'bp-1', content_type: 'bogus', runs_on: 'nope', consumed_output_keys: 'garbage' },
      steps: [],
    });
    assert.equal(status, 201);
    assert.equal(state.recipeInsertParams[6], 'application/json', 'bogus content_type degrades to default');
    assert.strictEqual(state.recipeInsertParams[7], null, 'non-array consumed_output_keys degrades to null');
    assert.equal(state.runsOnUpdate, undefined, 'runs_on=both default issues no UPDATE');
  });

  it('coerces a malformed extract spec (array) to null', async () => {
    state.blueprintExists = true;
    const { status } = await req('POST', '/r/import', {
      recipe: { name: 'w', blueprint_id: 'bp-1', link_extract: ['nope'], external_id_extract: { nope: 1 } },
      steps: [],
    });
    assert.equal(status, 201);
    assert.strictEqual(state.recipeInsertParams[8], null, 'array link_extract → null');
    assert.strictEqual(state.recipeInsertParams[9], null, 'pathless object external_id_extract → null');
  });

  it('still imports when the target lacks payload_transform_code (no-ALTER best-effort)', async () => {
    state.blueprintExists = true; state.failPayloadCodeUpdate = true;
    const { status } = await req('POST', '/r/import', {
      recipe: { name: 'w', blueprint_id: 'bp-1', payload_transform_code: 'return {}' }, steps: [],
    });
    assert.equal(status, 201, 'a missing payload_transform_code column must not fail the import');
  });

  it('still imports when the target lacks runs_on (no-ALTER best-effort)', async () => {
    state.blueprintExists = true; state.failRunsOnUpdate = true;
    const { status } = await req('POST', '/r/import', {
      recipe: { name: 'w', blueprint_id: 'bp-1', runs_on: 'create' }, steps: [],
    });
    assert.equal(status, 201, 'a missing runs_on column must not fail the import');
  });

  it('rejects a JS/compute step on a target lacking the chaining columns (422)', async () => {
    state.blueprintExists = true; state.failStepCodeUpdate = true;
    const { status, json } = await req('POST', '/r/import', {
      recipe: { name: 'w', blueprint_id: 'bp-1' },
      steps: [{ sequence: 1, name: 'calc', step_type: 'compute', before_code: 'return {x:1}' }],
    });
    assert.equal(status, 422);
    assert.equal(json.error.code, 'CHAINING_UNSUPPORTED');
  });

  it('rejects an import with more than 100 steps (400, no insert)', async () => {
    state.blueprintExists = true;
    const steps = Array.from({ length: 101 }, (_, i) => ({ sequence: i + 1, name: `s${i}`, method: 'POST', url: 'http://svc/x', auth_type: 'none' }));
    const { status, json } = await req('POST', '/r/import', {
      recipe: { name: 'w', blueprint_id: 'bp-1' }, steps,
    });
    assert.equal(status, 400);
    assert.equal(json.error.code, 'BAD_REQUEST');
    assert.equal(state.recipeInsertParams, null);
  });

  it('rejects a plain user import with 403 (no insert)', async () => {
    currentUser = { id: 'u-1', role: 'user', email: 'u@x' };
    const { status, json } = await req('POST', '/r/import', {
      recipe: { name: 'w', blueprint_id: 'bp-1' }, steps: [],
    });
    assert.equal(status, 403);
    assert.equal(json.error.code, 'FORBIDDEN');
    assert.equal(state.recipeInsertParams, null);
  });
});
