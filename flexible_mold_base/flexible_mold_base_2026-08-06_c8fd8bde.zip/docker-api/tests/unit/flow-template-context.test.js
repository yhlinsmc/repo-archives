/**
 * flow-template-context.test.js
 *
 * Unit tests for buildTemplateContext(conn, templateId) — the server-side
 * template-info bag builder consumed by the flow-steps /prepare injection point.
 * Data-vocabulary unification v2: the bag carries EXACTLY the 6 canonical
 * `context.template.<field>` keys (camelCase) — no legacy `template_*` and no
 * short `template.*` forms. Stubs the db module so the helper can be exercised in
 * isolation without booting any route or pool (mirrors clear-table-helper.test.js's
 * require.cache stub convention).
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');

const dbKey = require.resolve('../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey,
  filename: dbKey,
  loaded: true,
  exports: {
    t: (name) => `fmb_${name}`,
  },
};

const { buildTemplateContext, resolveCallerDisplayName, resolveHierarchyNodeName } = require('../../src/edge/lib/flow-template-context');

const TPL_RX = /FROM `fmb_user_templates`/;
const NODE_RX = /FROM `fmb_hierarchy_nodes`/;
const USERS_RX = /FROM `fmb_users`/;

// Canonical bag keys — the complete, only set the builder emits.
const K = {
  id: 'context.template.id',
  name: 'context.template.name',
  path: 'context.template.path',
  ownerName: 'context.template.ownerName',
  createdAt: 'context.template.createdAt',
  updatedAt: 'context.template.updatedAt',
};

function templateRow(over = {}) {
  return {
    id: 'tpl-1',
    name: 'Turbine Spec',
    category_id: 'cat-1',
    release_id: 'rel-1',
    blueprint_id: 'bp-1',
    variant_id: 'var-1',
    owner_id: 'owner-1',
    created_at: '2026-01-01 08:00:00',
    updated_at: '2026-02-02 09:30:15',
    ...over,
  };
}

function makeConn(scripts) {
  const queries = [];
  return {
    queries,
    async query(sql, params) {
      queries.push({ sql, params });
      for (const [matcher, response] of scripts) {
        if (matcher.test(sql)) {
          return typeof response === 'function' ? response(sql, params) : response;
        }
      }
      throw new Error(`Unmatched query: ${sql.slice(0, 120)}`);
    },
  };
}

describe('buildTemplateContext — falsy / missing-row short-circuits', () => {
  it('returns null for a falsy templateId without issuing any query', async () => {
    const conn = makeConn([]);
    assert.equal(await buildTemplateContext(conn, null), null);
    assert.equal(await buildTemplateContext(conn, undefined), null);
    assert.equal(await buildTemplateContext(conn, ''), null);
    assert.equal(conn.queries.length, 0);
  });

  it('returns null when the template row no longer exists', async () => {
    const conn = makeConn([[TPL_RX, []]]);
    const result = await buildTemplateContext(conn, 'ghost-tpl');
    assert.equal(result, null);
  });
});

describe('buildTemplateContext — happy path (canonical bag)', () => {
  it('returns EXACTLY the 6 canonical context.template.* keys, with a " › "-joined path and owner display name', async () => {
    const conn = makeConn([
      [TPL_RX, [templateRow()]],
      [NODE_RX, [
        { id: 'cat-1', name: 'Wind' },
        { id: 'rel-1', name: '2026 Release' },
        { id: 'bp-1', name: 'Turbine Blueprint' },
        { id: 'var-1', name: 'Offshore Variant' },
      ]],
      [USERS_RX, [{ display_name: 'Alice Owner', kc_username: 'alice' }]],
    ]);

    const result = await buildTemplateContext(conn, 'tpl-1');

    assert.deepEqual(Object.keys(result.bag).sort(), [
      'context.template.createdAt',
      'context.template.id',
      'context.template.name',
      'context.template.ownerName',
      'context.template.path',
      'context.template.updatedAt',
    ]);
    assert.equal(result.bag[K.id], 'tpl-1');
    assert.equal(result.bag[K.name], 'Turbine Spec');
    assert.equal(result.bag[K.path], 'Wind › 2026 Release › Turbine Blueprint › Offshore Variant');
    assert.equal(result.bag[K.ownerName], 'Alice Owner');
    assert.equal(result.bag[K.createdAt], '2026-01-01T08:00:00.000Z');
    assert.equal(result.bag[K.updatedAt], '2026-02-02T09:30:15.000Z');
    // variantName is the variant tier's NAME, kept OUTSIDE the template bag.
    assert.equal(result.variantName, 'Offshore Variant');
  });

  it('emits no legacy `template_*` and no short `template.*` keys', async () => {
    const conn = makeConn([
      [TPL_RX, [templateRow()]],
      [NODE_RX, [{ id: 'cat-1', name: 'Wind' }, { id: 'rel-1', name: 'Rel' }, { id: 'bp-1', name: 'BP' }, { id: 'var-1', name: 'Var' }]],
      [USERS_RX, [{ display_name: 'Alice', kc_username: 'alice' }]],
    ]);
    const result = await buildTemplateContext(conn, 'tpl-1');
    for (const k of Object.keys(result.bag)) {
      assert.ok(k.startsWith('context.template.'), `unexpected non-canonical key: ${k}`);
    }
    assert.ok(!('template_id' in result.bag));
    assert.ok(!('template.name' in result.bag));
  });

  it('never selects or returns an email key anywhere in the bag or the users query', async () => {
    const conn = makeConn([
      [TPL_RX, [templateRow()]],
      [NODE_RX, [{ id: 'cat-1', name: 'Wind' }, { id: 'rel-1', name: 'Rel' }, { id: 'bp-1', name: 'BP' }, { id: 'var-1', name: 'Var' }]],
      // A hostile/legacy driver row carrying an email leaf must still not leak,
      // since the resolver only ever reads display_name/kc_username off it.
      [USERS_RX, [{ display_name: 'Alice Owner', kc_username: 'alice', email: 'alice@example.com' }]],
    ]);

    const result = await buildTemplateContext(conn, 'tpl-1');

    assert.ok(!('email' in result.bag), 'no email key anywhere in the returned bag');
    assert.deepEqual(JSON.stringify(result.bag).includes('example.com'), false);
    const usersQ = conn.queries.find((q) => USERS_RX.test(q.sql));
    assert.ok(usersQ, 'users lookup query must fire');
    assert.ok(!/email/i.test(usersQ.sql), 'email column must never be selected');
  });

  it('accepts native Date objects for created_at/updated_at (driver may return either shape)', async () => {
    const conn = makeConn([
      [TPL_RX, [templateRow({
        created_at: new Date('2026-03-03T00:00:00.000Z'),
        updated_at: new Date('2026-04-04T12:34:56.000Z'),
      })]],
      [NODE_RX, [{ id: 'cat-1', name: 'Wind' }, { id: 'rel-1', name: 'Rel' }, { id: 'bp-1', name: 'BP' }, { id: 'var-1', name: 'Var' }]],
      [USERS_RX, [{ display_name: 'Alice', kc_username: 'alice' }]],
    ]);

    const result = await buildTemplateContext(conn, 'tpl-1');
    assert.equal(result.bag[K.createdAt], '2026-03-03T00:00:00.000Z');
    assert.equal(result.bag[K.updatedAt], '2026-04-04T12:34:56.000Z');
  });

  it('propagates a NULL timestamp as null on the canonical key', async () => {
    const conn = makeConn([
      [TPL_RX, [templateRow({ created_at: null })]],
      [NODE_RX, [{ id: 'cat-1', name: 'Wind' }, { id: 'rel-1', name: 'Rel' }, { id: 'bp-1', name: 'BP' }, { id: 'var-1', name: 'Var' }]],
      [USERS_RX, [{ display_name: 'Alice', kc_username: 'alice' }]],
    ]);
    const result = await buildTemplateContext(conn, 'tpl-1');
    assert.equal(result.bag[K.createdAt], null);
  });
});

describe('buildTemplateContext — owner-name Y-pattern coalescing', () => {
  it('NULL owner_id → context.template.ownerName is "" and no users query is issued', async () => {
    const conn = makeConn([
      [TPL_RX, [templateRow({ owner_id: null })]],
      [NODE_RX, [{ id: 'cat-1', name: 'Wind' }, { id: 'rel-1', name: 'Rel' }, { id: 'bp-1', name: 'BP' }, { id: 'var-1', name: 'Var' }]],
    ]);
    const result = await buildTemplateContext(conn, 'tpl-1');
    assert.equal(result.bag[K.ownerName], '');
    assert.ok(!conn.queries.some((q) => USERS_RX.test(q.sql)), 'no users query for a NULL owner');
  });

  it('owner_id present but the user row is gone (deleted) → "" (Y-pattern, not "Unknown")', async () => {
    const conn = makeConn([
      [TPL_RX, [templateRow({ owner_id: 'ghost-owner' })]],
      [NODE_RX, [{ id: 'cat-1', name: 'Wind' }, { id: 'rel-1', name: 'Rel' }, { id: 'bp-1', name: 'BP' }, { id: 'var-1', name: 'Var' }]],
      [USERS_RX, []],
    ]);
    const result = await buildTemplateContext(conn, 'tpl-1');
    assert.equal(result.bag[K.ownerName], '');
  });

  it('falls back to kc_username when display_name is NULL', async () => {
    const conn = makeConn([
      [TPL_RX, [templateRow()]],
      [NODE_RX, [{ id: 'cat-1', name: 'Wind' }, { id: 'rel-1', name: 'Rel' }, { id: 'bp-1', name: 'BP' }, { id: 'var-1', name: 'Var' }]],
      [USERS_RX, [{ display_name: null, kc_username: 'kc.bob' }]],
    ]);
    const result = await buildTemplateContext(conn, 'tpl-1');
    assert.equal(result.bag[K.ownerName], 'kc.bob');
  });

  it('CRITICAL: email-shaped kc_username (display_name NULL) is stripped to the local part only, never a full email', async () => {
    const conn = makeConn([
      [TPL_RX, [templateRow()]],
      [NODE_RX, [{ id: 'cat-1', name: 'Wind' }, { id: 'rel-1', name: 'Rel' }, { id: 'bp-1', name: 'BP' }, { id: 'var-1', name: 'Var' }]],
      [USERS_RX, [{ display_name: null, kc_username: 'someone@example.com' }]],
    ]);
    const result = await buildTemplateContext(conn, 'tpl-1');
    assert.equal(result.bag[K.ownerName], 'someone');
    assert.ok(!result.bag[K.ownerName].includes('@'), 'context.template.ownerName must never contain @');
  });

  it('both display_name and kc_username NULL → "" (never null, matches Y-pattern string coalesce)', async () => {
    const conn = makeConn([
      [TPL_RX, [templateRow()]],
      [NODE_RX, [{ id: 'cat-1', name: 'Wind' }, { id: 'rel-1', name: 'Rel' }, { id: 'bp-1', name: 'BP' }, { id: 'var-1', name: 'Var' }]],
      [USERS_RX, [{ display_name: null, kc_username: null }]],
    ]);
    const result = await buildTemplateContext(conn, 'tpl-1');
    assert.equal(result.bag[K.ownerName], '');
  });
});

describe('buildTemplateContext — context.template.path hierarchy join', () => {
  it('skips NULL FK links, preserving category → release → blueprint → variant order', async () => {
    const conn = makeConn([
      [TPL_RX, [templateRow({ release_id: null })]],
      [NODE_RX, [
        { id: 'cat-1', name: 'Wind' },
        { id: 'bp-1', name: 'Turbine Blueprint' },
        { id: 'var-1', name: 'Offshore Variant' },
      ]],
      [USERS_RX, [{ display_name: 'Alice', kc_username: 'alice' }]],
    ]);
    const result = await buildTemplateContext(conn, 'tpl-1');
    assert.equal(result.bag[K.path], 'Wind › Turbine Blueprint › Offshore Variant');
    const nodeQ = conn.queries.find((q) => NODE_RX.test(q.sql));
    assert.deepEqual(nodeQ.params, ['cat-1', 'bp-1', 'var-1'], 'release_id must be excluded from the IN-clause params');
  });

  it('skips an FK pointing at a since-deleted hierarchy node (orphaned link)', async () => {
    const conn = makeConn([
      [TPL_RX, [templateRow()]],
      // blueprint_id/variant_id rows never come back — deleted nodes.
      [NODE_RX, [{ id: 'cat-1', name: 'Wind' }, { id: 'rel-1', name: '2026 Release' }]],
      [USERS_RX, [{ display_name: 'Alice', kc_username: 'alice' }]],
    ]);
    const result = await buildTemplateContext(conn, 'tpl-1');
    assert.equal(result.bag[K.path], 'Wind › 2026 Release');
  });

  it('all four FK links NULL → context.template.path is "" and no hierarchy_nodes query is issued', async () => {
    const conn = makeConn([
      [TPL_RX, [templateRow({ category_id: null, release_id: null, blueprint_id: null, variant_id: null })]],
      [USERS_RX, [{ display_name: 'Alice', kc_username: 'alice' }]],
    ]);
    const result = await buildTemplateContext(conn, 'tpl-1');
    assert.equal(result.bag[K.path], '');
    assert.ok(!conn.queries.some((q) => NODE_RX.test(q.sql)), 'no hierarchy_nodes query when every FK is NULL');
  });
});

describe('buildTemplateContext — context.variantName (variant tier NAME)', () => {
  it('resolves variantName from the variant_id node, reusing the path query (no extra round-trip)', async () => {
    const conn = makeConn([
      [TPL_RX, [templateRow()]],
      [NODE_RX, [
        { id: 'cat-1', name: 'Wind' },
        { id: 'rel-1', name: 'Rel' },
        { id: 'bp-1', name: 'BP' },
        { id: 'var-1', name: 'Offshore Variant' },
      ]],
      [USERS_RX, [{ display_name: 'Alice', kc_username: 'alice' }]],
    ]);
    const result = await buildTemplateContext(conn, 'tpl-1');
    assert.equal(result.variantName, 'Offshore Variant');
    // kept OUT of the template bag (it is a run scalar, not a context.template.* field)
    assert.ok(!('context.variantName' in result.bag));
    // exactly one hierarchy_nodes query — the path query is reused for the name
    assert.equal(conn.queries.filter((q) => NODE_RX.test(q.sql)).length, 1);
  });

  it('variantName is null when the template has no variant_id (never emitted → fails closed)', async () => {
    const conn = makeConn([
      [TPL_RX, [templateRow({ variant_id: null })]],
      [NODE_RX, [{ id: 'cat-1', name: 'Wind' }, { id: 'rel-1', name: 'Rel' }, { id: 'bp-1', name: 'BP' }]],
      [USERS_RX, [{ display_name: 'Alice', kc_username: 'alice' }]],
    ]);
    const result = await buildTemplateContext(conn, 'tpl-1');
    assert.equal(result.variantName, null);
  });

  it('variantName is null when the variant node was deleted (orphaned FK)', async () => {
    const conn = makeConn([
      [TPL_RX, [templateRow()]],
      // var-1 row never comes back — deleted node
      [NODE_RX, [{ id: 'cat-1', name: 'Wind' }, { id: 'rel-1', name: 'Rel' }, { id: 'bp-1', name: 'BP' }]],
      [USERS_RX, [{ display_name: 'Alice', kc_username: 'alice' }]],
    ]);
    const result = await buildTemplateContext(conn, 'tpl-1');
    assert.equal(result.variantName, null);
  });

  it('variantName is null when every FK is NULL (no hierarchy query)', async () => {
    const conn = makeConn([
      [TPL_RX, [templateRow({ category_id: null, release_id: null, blueprint_id: null, variant_id: null })]],
      [USERS_RX, [{ display_name: 'Alice', kc_username: 'alice' }]],
    ]);
    const result = await buildTemplateContext(conn, 'tpl-1');
    assert.equal(result.variantName, null);
  });
});

describe('resolveHierarchyNodeName — context.blueprintName source', () => {
  it('returns null for a falsy nodeId without issuing any query', async () => {
    const conn = makeConn([]);
    assert.equal(await resolveHierarchyNodeName(conn, null), null);
    assert.equal(await resolveHierarchyNodeName(conn, ''), null);
    assert.equal(conn.queries.length, 0);
  });

  it('returns the node name when present', async () => {
    const conn = makeConn([[NODE_RX, [{ name: 'Turbine Blueprint' }]]]);
    assert.equal(await resolveHierarchyNodeName(conn, 'bp-1'), 'Turbine Blueprint');
  });

  it('returns null when the node was deleted (fails closed)', async () => {
    const conn = makeConn([[NODE_RX, []]]);
    assert.equal(await resolveHierarchyNodeName(conn, 'ghost'), null);
  });

  it('returns null for an empty node name', async () => {
    const conn = makeConn([[NODE_RX, [{ name: '' }]]]);
    assert.equal(await resolveHierarchyNodeName(conn, 'bp-1'), null);
  });
});

describe('resolveCallerDisplayName — context.displayName scalar source', () => {
  it('returns null for a falsy userId without issuing any query', async () => {
    const conn = makeConn([]);
    assert.equal(await resolveCallerDisplayName(conn, null), null);
    assert.equal(await resolveCallerDisplayName(conn, undefined), null);
    assert.equal(await resolveCallerDisplayName(conn, ''), null);
    assert.equal(conn.queries.length, 0);
  });

  it('returns the display_name when present', async () => {
    const conn = makeConn([[USERS_RX, [{ display_name: 'Alice Owner', kc_username: 'alice' }]]]);
    assert.equal(await resolveCallerDisplayName(conn, 'u1'), 'Alice Owner');
  });

  it('falls back to kc_username when display_name is NULL', async () => {
    const conn = makeConn([[USERS_RX, [{ display_name: null, kc_username: 'kc.bob' }]]]);
    assert.equal(await resolveCallerDisplayName(conn, 'u1'), 'kc.bob');
  });

  it('returns null (NOT "") when the user row is gone — omit-key semantics, fails closed', async () => {
    const conn = makeConn([[USERS_RX, []]]);
    assert.equal(await resolveCallerDisplayName(conn, 'ghost'), null);
  });

  it('returns null when both display_name and kc_username are NULL', async () => {
    const conn = makeConn([[USERS_RX, [{ display_name: null, kc_username: null }]]]);
    assert.equal(await resolveCallerDisplayName(conn, 'u1'), null);
  });

  it('CRITICAL: email-shaped value is stripped to the local part only, never a full email', async () => {
    const conn = makeConn([[USERS_RX, [{ display_name: 'someone@example.com', kc_username: null }]]]);
    const name = await resolveCallerDisplayName(conn, 'u1');
    assert.equal(name, 'someone');
    assert.ok(!name.includes('@'));
  });

  it('never selects an email column', async () => {
    const conn = makeConn([[USERS_RX, [{ display_name: 'Alice', kc_username: 'alice' }]]]);
    await resolveCallerDisplayName(conn, 'u1');
    const usersQ = conn.queries.find((q) => USERS_RX.test(q.sql));
    assert.ok(!/email/i.test(usersQ.sql), 'email column must never be selected');
  });
});

describe('buildTemplateContext — identifier-via-tables', () => {
  it('reads through the injected t() helper for every physical table name (fmb_ prefix applied)', async () => {
    const conn = makeConn([
      [TPL_RX, [templateRow()]],
      [NODE_RX, [{ id: 'cat-1', name: 'Wind' }, { id: 'rel-1', name: 'Rel' }, { id: 'bp-1', name: 'BP' }, { id: 'var-1', name: 'Var' }]],
      [USERS_RX, [{ display_name: 'Alice', kc_username: 'alice' }]],
    ]);
    await buildTemplateContext(conn, 'tpl-1');
    assert.ok(conn.queries.some((q) => /`fmb_user_templates`/.test(q.sql)));
    assert.ok(conn.queries.some((q) => /`fmb_hierarchy_nodes`/.test(q.sql)));
    assert.ok(conn.queries.some((q) => /`fmb_users`/.test(q.sql)));
  });
});
