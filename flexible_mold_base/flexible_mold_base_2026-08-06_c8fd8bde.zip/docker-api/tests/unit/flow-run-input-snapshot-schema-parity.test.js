/**
 * flow-run-input-snapshot-schema-parity.test.js — the column lists the run INSERT
 * is built from are checked against the ACTUAL table DDL, WITHOUT a live database.
 *
 * WHAT THIS FILE CHECKS, EXACTLY: the three exported arrays in
 * `edge/lib/flow-run-insert.js`. That is only worth anything because the SQL is
 * built from those arrays and nothing else — which is pinned from the other end,
 * in flow-recipes-run-begin.test.js ("the INSERT names exactly the columns the
 * shared declaration lists"), by comparing the statement the real route emits
 * against these same arrays. The two together are the claim; neither is on its
 * own.
 *
 * Why it is needed: the run-begin tests stub `conn.query`, so a misspelled column
 * produces a statement no test ever runs against a real schema. Both runners stay
 * green, the live database answers 1054, and the route's additive-column fallback
 * reads that as "this database must be missing the column" — so the capture
 * silently stops happening and nothing reports it. Same class as the capacity
 * delete-preview parity test, applied to a hand-written INSERT.
 */
const { describe, it, before } = require('node:test');
const assert = require('node:assert/strict');

const { buildSchemaManifest } = require('../../src/edge/lib/schema-manifest');
const {
  RUN_ROW_BASE_COLUMNS,
  RUN_ROW_ADDITIVE_COLUMNS,
  RUN_ROW_SQL_COLUMNS,
} = require('../../src/edge/lib/flow-run-insert');
const { MIGRATION_STEPS } = require('../../src/edge/migration-steps');

let runColumns;

before(() => {
  const manifest = buildSchemaManifest((base) => base);
  const entry = manifest.get('flow_recipe_runs');
  assert.ok(entry, 'table-ddls.js does not create flow_recipe_runs');
  runColumns = new Set(entry.columns);
});

describe('flow_recipe_runs INSERT <-> table-ddls parity', () => {
  it('every column the run INSERT names exists in table-ddls.js', () => {
    const named = [
      ...RUN_ROW_BASE_COLUMNS,
      ...RUN_ROW_ADDITIVE_COLUMNS,
      ...RUN_ROW_SQL_COLUMNS,
    ];
    const missing = named.filter((c) => !runColumns.has(c));
    assert.deepEqual(missing, [], `run INSERT names columns absent from table-ddls.js: ${missing.join(', ')}`);
  });

  it('input_snapshot is a column of flow_recipe_runs, distinct from the two older snapshots', () => {
    assert.ok(runColumns.has('input_snapshot'), 'flow_recipe_runs has no input_snapshot column');
    // Named together because the point of the new column is that neither of the
    // other two holds what the operator entered; a change that folded it into
    // one of them would break the reason it was added.
    assert.ok(runColumns.has('output_snapshot'), 'flow_recipe_runs has no output_snapshot column');
    assert.ok(runColumns.has('rendered_payload'), 'flow_recipe_runs has no rendered_payload column');
  });

  it('input_snapshot is among the columns the INSERT is built from', () => {
    // The whole contract of the column: a run that fails mid-chain never reaches
    // finalize, so a snapshot written by an UPDATE would be missing on exactly
    // the runs worth reading back. That the emitted statement really is built
    // from this set is pinned in flow-recipes-run-begin.test.js; here it is only
    // asserted that the set contains the column.
    assert.ok(
      [...RUN_ROW_BASE_COLUMNS, ...RUN_ROW_ADDITIVE_COLUMNS].includes('input_snapshot'),
      'input_snapshot is not among the columns the run INSERT sets',
    );
  });

  it('input_snapshot is treated as additive, matching its registry entry', () => {
    // A column the migration registry ships as add-column may be absent on an
    // operator-mode DB that warn-skipped the ALTER. If the INSERT listed it as a
    // base column the fallback could never drop it and every run on such a DB
    // would fail — so the two declarations have to agree.
    const entry = MIGRATION_STEPS.find((s) => s.step === 'flow_recipe_runs_input_snapshot_add');
    assert.ok(entry, 'no migration registry entry for flow_recipe_runs.input_snapshot');
    assert.equal(entry.kind, 'add-column');
    assert.ok(
      RUN_ROW_ADDITIVE_COLUMNS.includes('input_snapshot'),
      'input_snapshot ships as an additive migration but the INSERT treats it as mandatory',
    );
  });
});
