/**
 * identity-resolve.test.js
 *
 * Edge-side /edge/internal/auth/identity-resolve coverage:
 *   - oidc source: JIT happy path (calls pool.rw.beginTransaction + commits)
 *   - oidc source: banned (writes login_audit + still 200)
 *   - jwt-bearer source: pool.ro SELECT, returns user
 *   - jwt-bearer source: banned (escalates to pool.rw for audit)
 *   - pool not ready: returns pool_ready=false with auth_mode=env fallback
 *   - invalid source: 400
 */
const { describe, it, beforeEach, before, after } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

// JWT_SECRET must be set BEFORE shared/config.js loads
process.env.JWT_SECRET = process.env.JWT_SECRET || 'a'.repeat(48);

const dbKey = require.resolve('../../src/edge/db');
const jitKey = require.resolve('../../src/lib/jit-provisioner');
const configKey = require.resolve('../../src/shared/config');

let poolReady = true;
let calls;

function makeSpyPool() {
  calls = { rw: 0, ro: 0, rwQueries: [], roQueries: [], beganTx: 0, committed: 0, rolledBack: 0 };
  return {
    rw: {
      async getConnection() {
        calls.rw++;
        return {
          async query(sql, params) {
            calls.rwQueries.push({ sql, params });
            return [];
          },
          async beginTransaction() { calls.beganTx++; },
          async commit() { calls.committed++; },
          async rollback() { calls.rolledBack++; },
          release() {},
        };
      },
    },
    ro: {
      async getConnection() {
        calls.ro++;
        return {
          async query(sql, params) {
            calls.roQueries.push({ sql, params });
            if (/FROM `[^`]*users` WHERE id =/.test(sql)) {
              return currentUserRow ? [currentUserRow] : [];
            }
            return [];
          },
          release() {},
        };
      },
    },
  };
}

const poolSpy = {};

require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: {
    pool: poolSpy,
    t: (name) => `fmb_${name}`,
    isPoolReady: () => poolReady,
  },
};

// Stub jit-provisioner so OIDC source returns a deterministic user
let nextJitResult;
let lastJitArgs;
require.cache[jitKey] = {
  id: jitKey, filename: jitKey, loaded: true,
  exports: {
    jitProvision: async (args) => { lastJitArgs = args; return nextJitResult; },
  },
};

// Stub resolveAuthModeAsync to avoid DB call inside identity-resolve
require.cache[configKey] = {
  id: configKey, filename: configKey, loaded: true,
  exports: {
    resolveAuthMode: () => 'local',
    resolveAuthModeAsync: async () => 'local',
    getAuthModeSource: () => 'env',
    JWT_SECRET: process.env.JWT_SECRET,
    detectAuthMode: async () => {},
    probeKeycloakDiscovery: async () => false,
  },
};

let currentUserRow;
let server;
let port;

before(async () => {
  Object.assign(poolSpy, makeSpyPool());
  const router = require('../../src/edge/routes/internal/identity-resolve');
  const app = express();
  app.use(express.json());
  app.use('/edge/internal/auth', router);
  await new Promise((resolve) => {
    server = app.listen(0, '127.0.0.1', () => { port = server.address().port; resolve(); });
  });
});

after(async () => {
  await new Promise((resolve) => server.close(resolve));
  delete require.cache[dbKey];
  delete require.cache[jitKey];
  delete require.cache[configKey];
});

beforeEach(() => {
  Object.assign(poolSpy, makeSpyPool());
  poolReady = true;
  currentUserRow = null;
  nextJitResult = null;
  lastJitArgs = undefined;
});

function postJson(path_, body) {
  return new Promise((resolve, reject) => {
    const payload = JSON.stringify(body);
    const req = http.request(
      {
        host: '127.0.0.1', port, path: path_, method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) },
      },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          const raw = Buffer.concat(chunks).toString('utf-8');
          let json = null;
          try { json = JSON.parse(raw); } catch { /* noop */ }
          resolve({ status: res.statusCode, raw, json });
        });
      },
    );
    req.on('error', reject);
    req.write(payload);
    req.end();
  });
}

describe('identity-resolve — OIDC source', () => {
  it('JIT happy path: beginTransaction + commit on rw, returns user', async () => {
    nextJitResult = { id: 'jit1', email: 'new@test', role: 'user', banned: 0, kc_username: 'new' };
    const res = await postJson('/edge/internal/auth/identity-resolve', {
      source: 'oidc',
      claims: { sub: 'sub1', email: 'new@test' },
      auditInfo: { ip: '1.2.3.4', userAgent: 'test' },
    });
    assert.equal(res.status, 200);
    assert.equal(res.json.data.user.id, 'jit1');
    assert.equal(res.json.data.jit_provisioned, true);
    assert.equal(res.json.data.banned, false);
    assert.equal(calls.beganTx, 1);
    assert.equal(calls.committed, 1);
    assert.equal(calls.rolledBack, 0);
  });

  it('banned: returns user=null + banned=true + commit (audit row preserved)', async () => {
    nextJitResult = { id: 'b1', email: 'banned@test', role: 'user', banned: 1, kc_username: 'banned', deptid: 'X' };
    const res = await postJson('/edge/internal/auth/identity-resolve', {
      source: 'oidc',
      claims: { sub: 'sub2', email: 'banned@test' },
      auditInfo: { ip: '1.2.3.4', userAgent: 'test' },
    });
    assert.equal(res.status, 200);
    assert.equal(res.json.data.user, null);
    assert.equal(res.json.data.banned, true);
    assert.equal(calls.committed, 1);
    const auditInsert = calls.rwQueries.find((q) => /INSERT INTO `fmb_login_audit`/.test(q.sql));
    assert.ok(auditInsert, 'login_audit INSERT must be issued for banned OIDC');
  });

  it('collision skip: strips the transient marker off user, returns it as email_resync_skipped_for sibling', async () => {
    nextJitResult = {
      id: 'c1', email: 'old@test', role: 'user', banned: 0, kc_username: 'c',
      emailResyncSkippedFor: 'taken@test',
    };
    const res = await postJson('/edge/internal/auth/identity-resolve', {
      source: 'oidc',
      claims: { sub: 'sub-collide', email: 'taken@test' },
    });
    assert.equal(res.status, 200);
    // Marker must NOT appear on the response user object (feeds req.user + cache
    // + /api/auth/me).
    assert.equal('emailResyncSkippedFor' in res.json.data.user, false);
    assert.equal(res.json.data.user.email, 'old@test');
    // Exposed as a sibling response field for infra's drift check.
    assert.equal(res.json.data.email_resync_skipped_for, 'taken@test');
  });

  it('no collision: no marker on user and sibling field absent from the body', async () => {
    nextJitResult = { id: 'n1', email: 'clean@test', role: 'user', banned: 0, kc_username: 'n' };
    const res = await postJson('/edge/internal/auth/identity-resolve', {
      source: 'oidc',
      claims: { sub: 'sub-clean', email: 'clean@test' },
    });
    assert.equal(res.status, 200);
    assert.equal('emailResyncSkippedFor' in res.json.data.user, false);
    assert.equal('email_resync_skipped_for' in res.json.data, false,
      'undefined marker must be omitted from the JSON body');
  });

  it('returns 400 when claims missing for oidc source', async () => {
    const res = await postJson('/edge/internal/auth/identity-resolve', {
      source: 'oidc',
    });
    assert.equal(res.status, 400);
  });

  it('passes freshLogin=true through to jitProvision when body sets it', async () => {
    nextJitResult = { id: 'f1', email: 'fresh@test', role: 'user', banned: 0, kc_username: 'fresh' };
    await postJson('/edge/internal/auth/identity-resolve', {
      source: 'oidc',
      claims: { sub: 'sub3', email: 'fresh@test' },
      freshLogin: true,
    });
    assert.equal(lastJitArgs.freshLogin, true);
  });

  it('defaults freshLogin to false when body omits it', async () => {
    nextJitResult = { id: 'f2', email: 'x@test', role: 'user', banned: 0, kc_username: 'x' };
    await postJson('/edge/internal/auth/identity-resolve', {
      source: 'oidc',
      claims: { sub: 'sub4', email: 'x@test' },
    });
    assert.equal(lastJitArgs.freshLogin, false);
  });

  it('coerces a non-boolean freshLogin to false (only literal true counts)', async () => {
    nextJitResult = { id: 'f3', email: 'y@test', role: 'user', banned: 0, kc_username: 'y' };
    await postJson('/edge/internal/auth/identity-resolve', {
      source: 'oidc',
      claims: { sub: 'sub5', email: 'y@test' },
      freshLogin: 'true',
    });
    assert.equal(lastJitArgs.freshLogin, false);
  });
});

describe('identity-resolve — JWT-bearer source', () => {
  it('happy path: pool.ro SELECT only, returns user', async () => {
    currentUserRow = { id: 'u1', email: 'alice@test', role: 'user', banned: 0 };
    const res = await postJson('/edge/internal/auth/identity-resolve', {
      source: 'jwt-bearer',
      userId: 'u1',
      auditInfo: { ip: null, userAgent: null },
    });
    assert.equal(res.status, 200);
    assert.equal(res.json.data.user.id, 'u1');
    assert.equal(res.json.data.banned, false);
    assert.equal(calls.ro, 1);
    assert.equal(calls.rw, 0);
  });

  it('banned: pool.ro SELECT then pool.rw audit INSERT', async () => {
    currentUserRow = { id: 'u2', email: 'banned@test', role: 'user', banned: 1 };
    const res = await postJson('/edge/internal/auth/identity-resolve', {
      source: 'jwt-bearer',
      userId: 'u2',
      auditInfo: { ip: null, userAgent: null },
    });
    assert.equal(res.status, 200);
    assert.equal(res.json.data.user, null);
    assert.equal(res.json.data.banned, true);
    assert.equal(calls.ro, 1);
    assert.equal(calls.rw, 1);
    const auditInsert = calls.rwQueries.find((q) => /INSERT INTO `fmb_login_audit`/.test(q.sql));
    assert.ok(auditInsert, 'login_audit INSERT must be issued for banned JWT');
  });

  it('user not found: returns user=null + banned=false', async () => {
    currentUserRow = null;
    const res = await postJson('/edge/internal/auth/identity-resolve', {
      source: 'jwt-bearer',
      userId: 'nope',
    });
    assert.equal(res.status, 200);
    assert.equal(res.json.data.user, null);
    assert.equal(res.json.data.banned, false);
  });

  it('returns 400 when userId missing', async () => {
    const res = await postJson('/edge/internal/auth/identity-resolve', {
      source: 'jwt-bearer',
    });
    assert.equal(res.status, 400);
  });
});

describe('identity-resolve — pool not ready', () => {
  it('returns pool_ready=false with auth_mode env fallback', async () => {
    poolReady = false;
    const res = await postJson('/edge/internal/auth/identity-resolve', {
      source: 'jwt-bearer',
      userId: 'u1',
    });
    assert.equal(res.status, 200);
    assert.equal(res.json.data.pool_ready, false);
    assert.equal(res.json.data.user, null);
    assert.equal(res.json.data.auth_mode, 'local');
  });
});

describe('identity-resolve — input validation', () => {
  it('returns 400 on invalid source', async () => {
    const res = await postJson('/edge/internal/auth/identity-resolve', { source: 'invalid' });
    assert.equal(res.status, 400);
  });
});
