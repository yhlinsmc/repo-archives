/**
 * index-infra-boot.test.js — cold-boot contract for v3.2.118 infra.
 *
 * Pins the pool-state cache machinery extracted to infra/lib/pool-state-cache.js
 * — the single source of truth for /health, the pool-gate, and any future
 * gate that needs to know whether edge is reachable + ready.
 *
 * Invariants verified:
 *   - reachable + db=ok  ⇒ ready=true,  edge_unreachable=false
 *   - reachable=false    ⇒ ready=false, edge_unreachable=true, hint=edge_unreachable
 *   - reachable + db=err ⇒ ready=false, edge_unreachable=false
 *   - positive state caches for 5s (one fetch across 3 hits)
 *   - invalidate() forces refresh
 */
const { describe, it, beforeEach, before, after } = require('node:test');
const assert = require('node:assert/strict');

process.env.JWT_SECRET = process.env.JWT_SECRET || 'a'.repeat(48);
process.env.S2S_API_KEY = process.env.S2S_API_KEY || 's2s-test';

const edgeClientKey = require.resolve('../../src/infra/lib/edge-state-client');
const cacheKey = require.resolve('../../src/infra/lib/pool-state-cache');

let healthImpl;
let fetchCalls;

require.cache[edgeClientKey] = {
  id: edgeClientKey, filename: edgeClientKey, loaded: true,
  exports: {
    resolveIdentity: async () => ({ user: null, jit_provisioned: false, auth_mode: 'local', banned: false, pool_ready: true }),
    fetchAuthMode: async () => ({ auth_mode: 'local', source: 'env', pool_ready: true }),
    fetchEdgeHealth: async () => { fetchCalls++; return healthImpl(); },
    getEdgeBaseUrl: () => 'http://api-edge:3201',
    EdgeUnreachable: class extends Error { constructor(m) { super(m); this.name = 'EdgeUnreachable'; } },
    EdgeTimeout: class extends Error { constructor(m) { super(m); this.name = 'EdgeTimeout'; } },
    EdgeAuthFailed: class extends Error { constructor(m) { super(m); this.name = 'EdgeAuthFailed'; } },
    EdgeBadResponse: class extends Error { constructor(m) { super(m); this.name = 'EdgeBadResponse'; } },
  },
};

const { getCachedPoolState, invalidatePoolStateCache } = require('../../src/infra/lib/pool-state-cache');

beforeEach(() => {
  invalidatePoolStateCache();
  fetchCalls = 0;
  healthImpl = () => ({ reachable: true, db: 'ok', pool: { pool_state: 'configured', hint_code: null } });
});

after(() => {
  delete require.cache[edgeClientKey];
  delete require.cache[cacheKey];
});

describe('pool-state-cache — cold-boot contract', () => {
  it('returns ready=true when edge reports db=ok', async () => {
    const state = await getCachedPoolState();
    assert.equal(state.ready, true);
    assert.equal(state.edge_unreachable, false);
    assert.equal(state.db, 'ok');
    assert.equal(state.pool.pool_state, 'configured');
  });

  it('returns edge_unreachable=true when fetchEdgeHealth reports reachable=false', async () => {
    healthImpl = () => ({ reachable: false, db: 'unknown', pool: null });
    const state = await getCachedPoolState();
    assert.equal(state.ready, false);
    assert.equal(state.edge_unreachable, true);
    assert.equal(state.db, 'unknown');
    assert.equal(state.pool.hint_code, 'edge_unreachable');
  });

  it('returns ready=false when edge reports db=error (pool degraded)', async () => {
    healthImpl = () => ({ reachable: true, db: 'error', pool: { pool_state: 'degraded', hint_code: 'connection_refused' } });
    const state = await getCachedPoolState();
    assert.equal(state.ready, false);
    assert.equal(state.edge_unreachable, false);
    assert.equal(state.pool.pool_state, 'degraded');
    assert.equal(state.pool.hint_code, 'connection_refused');
  });

  it('caches positive state for ~5s (multiple calls produce only one fetch)', async () => {
    await getCachedPoolState();
    await getCachedPoolState();
    await getCachedPoolState();
    assert.equal(fetchCalls, 1);
  });

  it('invalidate forces refresh', async () => {
    await getCachedPoolState();
    invalidatePoolStateCache();
    await getCachedPoolState();
    assert.equal(fetchCalls, 2);
  });

  it('negative state caches only briefly (refreshes within 2s window if invalidated)', async () => {
    healthImpl = () => ({ reachable: false, db: 'unknown', pool: null });
    const a = await getCachedPoolState();
    const b = await getCachedPoolState();
    assert.equal(fetchCalls, 1, 'within 1s negative TTL the cached value is reused');
    assert.strictEqual(a.edge_unreachable, b.edge_unreachable);
  });
});
