const { test } = require('node:test');
const assert = require('node:assert');
const { Writable } = require('node:stream');
const pino = require('pino');

const { redactConfig } = require('../../src/shared/lib/logger');

test('req.body.db.password and readPassword are redacted', () => {
  let captured = '';
  const sink = new Writable({ write(chunk, _e, cb) { captured += chunk.toString(); cb(); } });
  const log = pino({ redact: redactConfig }, sink);
  log.info(
    { req: { body: { db: { password: 'SHOULD_NOT_APPEAR', readPassword: 'ALSO_NOT' } } } },
    'x',
  );
  assert.ok(!captured.includes('SHOULD_NOT_APPEAR'), 'db.password redacted');
  assert.ok(!captured.includes('ALSO_NOT'), 'db.readPassword redacted');
});
