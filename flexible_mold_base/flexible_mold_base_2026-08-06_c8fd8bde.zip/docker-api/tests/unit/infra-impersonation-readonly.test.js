const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const { impersonationReadOnly } = require('../../src/infra/middleware/impersonation-readonly');

function mockRes() {
  return { statusCode: 200, body: null, status(c){this.statusCode=c;return this;}, json(b){this.body=b;return this;} };
}

describe('impersonationReadOnly (infra)', () => {
  it('blocks a non-GET /api request while impersonating', () => {
    const req = { method: 'POST', path: '/api/schema/user_templates', impersonator: { id: 'admin-1' } };
    const res = mockRes();
    let nx = false;
    impersonationReadOnly(req, res, () => { nx = true; });
    assert.equal(nx, false);
    assert.equal(res.statusCode, 403);
    assert.equal(res.body.error.code, 'IMPERSONATION_READ_ONLY');
  });

  it('allows a GET /api request while impersonating', () => {
    const req = { method: 'GET', path: '/api/schema/user_templates', impersonator: { id: 'admin-1' } };
    const res = mockRes();
    let nx = false;
    impersonationReadOnly(req, res, () => { nx = true; });
    assert.equal(nx, true);
  });

  for (const method of ['PUT', 'PATCH', 'DELETE']) {
    it(`blocks a ${method} /api request while impersonating`, () => {
      const req = { method, path: '/api/schema/x', impersonator: { id: 'admin-1' } };
      const res = mockRes();
      let nx = false;
      impersonationReadOnly(req, res, () => { nx = true; });
      assert.equal(nx, false);
      assert.equal(res.statusCode, 403);
    });
  }

  it('ignores non-/api paths', () => {
    const req = { method: 'POST', path: '/health', impersonator: { id: 'admin-1' } };
    const res = mockRes();
    let nx = false;
    impersonationReadOnly(req, res, () => { nx = true; });
    assert.equal(nx, true);
  });

  it('does nothing when not impersonating', () => {
    const req = { method: 'POST', path: '/api/schema/x' };
    const res = mockRes();
    let nx = false;
    impersonationReadOnly(req, res, () => { nx = true; });
    assert.equal(nx, true);
  });

  it('allows the read-only /api/schema/field_options/by-fields POST while impersonating', () => {
    const req = { method: 'POST', path: '/api/schema/field_options/by-fields', impersonator: { id: 'admin-1' } };
    const res = mockRes();
    let nx = false;
    impersonationReadOnly(req, res, () => { nx = true; });
    assert.equal(nx, true);
  });

  it('still blocks a sibling write POST (/api/schema/field_options/replace) while impersonating', () => {
    const req = { method: 'POST', path: '/api/schema/field_options/replace', impersonator: { id: 'admin-1' } };
    const res = mockRes();
    let nx = false;
    impersonationReadOnly(req, res, () => { nx = true; });
    assert.equal(nx, false);
    assert.equal(res.statusCode, 403);
  });

  it('allows the read-only /api/schema/blueprint_fields/by-blueprints POST while impersonating', () => {
    const req = { method: 'POST', path: '/api/schema/blueprint_fields/by-blueprints', impersonator: { id: 'admin-1' } };
    const res = mockRes();
    let nx = false;
    impersonationReadOnly(req, res, () => { nx = true; });
    assert.equal(nx, true);
  });

  it('still blocks a sibling write POST (/api/schema/blueprint_fields/delete-renormalize) while impersonating', () => {
    const req = { method: 'POST', path: '/api/schema/blueprint_fields/delete-renormalize', impersonator: { id: 'admin-1' } };
    const res = mockRes();
    let nx = false;
    impersonationReadOnly(req, res, () => { nx = true; });
    assert.equal(nx, false);
    assert.equal(res.statusCode, 403);
  });

  it('allows the read-only orphan scan POST (/api/schema/field-data-orphans) while impersonating', () => {
    const req = { method: 'POST', path: '/api/schema/field-data-orphans', impersonator: { id: 'admin-1' } };
    const res = mockRes();
    let nx = false;
    impersonationReadOnly(req, res, () => { nx = true; });
    assert.equal(nx, true);
  });

  it('still blocks the orphan clear DELETE (/api/schema/field-data-orphans/:t/:k) while impersonating', () => {
    const req = { method: 'DELETE', path: '/api/schema/field-data-orphans/t1/colors', impersonator: { id: 'admin-1' } };
    const res = mockRes();
    let nx = false;
    impersonationReadOnly(req, res, () => { nx = true; });
    assert.equal(nx, false);
    assert.equal(res.statusCode, 403);
  });
});
