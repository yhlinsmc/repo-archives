/**
 * flow-recipe-steps-crud.test.js
 *
 * Boots the real flow-recipe-steps router against a mocked pool and asserts:
 *   (a) POST a step with bearer token → 2xx, auth_config masked to ****
 *   (b) POST with a non-http url → 400 (URL guard)
 *   (c) POST with method='FOO' → 400 INVALID_METHOD (method allowlist)
 *   (d) re-pend on POST: recipe status='approved' → UPDATE flow_recipes pending
 *   (e) re-pend on PUT: SELECT recipe_id then UPDATE flow_recipes pending
 *
 * Harness mirrors api-connectors-crud-mask.test.js + api-connectors-approval.test.js.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

process.env.SETTINGS_ENCRYPTION_KEY = 'flow-recipe-steps-test-key';

const dbKey = require.resolve('../../src/edge/db');
const { encrypt } = require('../../src/shared/lib/settings-crypto');

// Pre-encrypt a stored secret so the mock can return a realistic ciphertext row.
const STORED_TOKEN_CT = encrypt('stored-secret');

// Columns the information_schema probe returns for fmb_flow_recipe_steps.
// Returns [] (null colSet) falls through to keep-all-keys mode — colSet=null
// is intentionally used in the crud-mask test. Here we return the actual shape
// so the operator-mode gate does not silently drop columns.
const STEP_COLUMNS = [
  'id', 'recipe_id', 'name', 'description', 'step_order',
  'url', 'method', 'auth_type', 'auth_config',
  'request_config', 'response_config', 'input_from_step',
  'step_type', 'before_code', 'after_code',
  'created_at', 'updated_at',
].map((c) => ({ COLUMN_NAME: c }));

// Shared queries capture — reset before each test.
let queries;
// Per-test override for the owner_id returned by queries on fmb_flow_recipes.
// Default '5b729f1e-5c0b-447c-8144-3210469bc62c' matches req.user.id so ownership checks pass.
let recipeOwnerId;
// Per-test override for the parent recipe status read by the re-pend FOR UPDATE
// SELECT. Default 'approved' so the re-pend UPDATE fires.
let recipeStatus;

function makeStepRow(overrides = {}) {
  return {
    id: 'a6106eb9-46f9-491a-8027-c4a21a20204e', recipe_id: 'd0edcb09-2c66-4d79-8114-5c3e787de042',
    name: 'Step 1', step_order: 1,
    auth_type: 'bearer',
    // Stored as a JSON string; dto-mapper parses it → serializeRead masks token.
    auth_config: JSON.stringify({ token: STORED_TOKEN_CT }),
    url: null, method: null,
    request_config: null, response_config: null,
    input_from_step: null,
    created_at: '2026-01-01 00:00:00', updated_at: '2026-01-01 00:00:00',
    ...overrides,
  };
}

// Per-request connection: handles the CRUD factory's getConnection() calls.
function makeConn() {
  return {
    async beginTransaction() {},
    async commit() {},
    async rollback() {},
    async query(sql, params) {
      queries.push({ via: 'conn', sql, params });
      if (/SELECT DATABASE\(\)/.test(sql)) return [{ db: 'testdb' }];
      if (/information_schema\.COLUMNS/i.test(sql)) return STEP_COLUMNS;
      if (/FROM `fmb_users`/.test(sql)) return [];
      // Every SELECT against the parent table answers with the WHOLE row this
      // fixture claims to hold, matched on the table alone. Three statements read
      // it — the parentOwnership chain (owner_id), the re-pend's existence probe
      // (id only, because the approval columns are additive) and the re-pend's
      // own read (status + owner_id) — and an arm keyed on the columns any one of
      // them projects goes silently unmatched the moment that projection changes,
      // dropping the double through to `return []` and answering "no such parent"
      // for a parent this fixture says is there.
      if (/^SELECT/i.test(sql.trim()) && /FROM `fmb_flow_recipes`/.test(sql)) {
        return [{ id: params[0], owner_id: recipeOwnerId, status: recipeStatus }];
      }
      // re-pend via-resolve (PUT/DELETE): SELECT `recipe_id` AS via FROM steps.
      if (/SELECT `recipe_id` AS via FROM `fmb_flow_recipe_steps`/.test(sql)) {
        return [{ via: 'd0edcb09-2c66-4d79-8114-5c3e787de042' }];
      }
      if (/^INSERT INTO `fmb_flow_recipe_steps`/i.test(sql.trim())) {
        return { affectedRows: 1 };
      }
      if (/^UPDATE `fmb_flow_recipe_steps`/i.test(sql.trim())) {
        return { affectedRows: 1 };
      }
      if (/^DELETE FROM `fmb_flow_recipe_steps`/i.test(sql.trim())) {
        return { affectedRows: 1 };
      }
      // The mask-preserve read. It runs on THIS connection now, inside the write
      // transaction and FOR UPDATE — matched on the table and the column it
      // needs rather than on the statement's exact text, so adding a column to
      // that query cannot make this arm stop matching and leave the double
      // answering "no stored secret" by falling through.
      if (/SELECT .*auth_config.*FROM `fmb_flow_recipe_steps` WHERE id = \? FOR UPDATE/.test(sql)) {
        return [{
          auth_config: JSON.stringify({ token: STORED_TOKEN_CT }),
          auth_type: 'bearer',
          request_config: null,
        }];
      }
      if (/SELECT \* FROM `fmb_flow_recipe_steps` WHERE id = \?/.test(sql)) {
        return [makeStepRow({ id: params[0] })];
      }
      return [];
    },
    release() {},
  };
}

// Pool spy: handles direct pool.ro.query / pool.rw.query calls from the
// re-pend middleware and the serializer's readStored.
const poolSpy = {
  ro: {
    async getConnection() { return makeConn(); },
    async query(sql, params) {
      queries.push({ via: 'pool.ro', sql, params });
      // The serializer's mask-preserve read is no longer here — it moved onto
      // the write connection (see makeConn), so an arm for it in this facade
      // would model a call that never arrives.
      // re-pend middleware: resolve parent recipe_id for PUT/DELETE
      if (/SELECT recipe_id FROM `fmb_flow_recipe_steps`/.test(sql)) {
        return [{ recipe_id: 'd0edcb09-2c66-4d79-8114-5c3e787de042' }];
      }
      // re-pend ownership pre-check: verify editor owns the recipe before re-pending
      if (/SELECT owner_id FROM `fmb_flow_recipes`/.test(sql)) {
        return [{ owner_id: recipeOwnerId }];
      }
      return [];
    },
  },
  rw: {
    async getConnection() { return makeConn(); },
    async query(sql, params) {
      queries.push({ via: 'pool.rw', sql, params });
      // re-pend middleware: set parent recipe back to pending
      if (/UPDATE `fmb_flow_recipes`/.test(sql)) {
        return { affectedRows: 1 };
      }
      return { affectedRows: 0 };
    },
  },
};

require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: poolSpy, t: (name) => `fmb_${name}` },
};

// Require schema first so __test__.__clearColumnSetCache is available.
const schema = require('../../src/edge/routes/app/schema');
const router = require('../../src/edge/routes/app/flow-recipe-steps');

let server; let base; let role;

before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { req.user = { id: '5b729f1e-5c0b-447c-8144-3210469bc62c', role, email: 'a@x' }; next(); });
  app.use('/s', router);
  server = http.createServer(app);
  await new Promise((r) => server.listen(0, r));
  base = `http://127.0.0.1:${server.address().port}`;
});
after(() => server && server.close());
beforeEach(() => {
  queries = [];
  role = 'admin';
  recipeOwnerId = '5b729f1e-5c0b-447c-8144-3210469bc62c'; // default: matches req.user.id so ownership passes
  recipeStatus = 'approved'; // default: re-pend fires (approved → pending)
  schema.__test__.__clearColumnSetCache();
});

async function req(method, path, body) {
  const res = await fetch(`${base}${path}`, {
    method,
    headers: { 'content-type': 'application/json' },
    body: body ? JSON.stringify(body) : undefined,
  });
  return { status: res.status, json: await res.json().catch(() => ({})) };
}

describe('flow-recipe-steps — (a) secret masking on POST', () => {
  it('POST a step with bearer token → 2xx, auth_config masked to ****', async () => {
    const { status, json } = await req('POST', '/s', {
      recipe_id: 'd0edcb09-2c66-4d79-8114-5c3e787de042',
      name: 'Step 1',
      auth_type: 'bearer',
      auth_config: { token: 'plain-secret' },
    });
    assert.equal(status, 200, `expected 200, got ${status}: ${JSON.stringify(json)}`);
    assert.equal(
      json.data.auth_config.token, '****',
      'response must mask the bearer token to ****',
    );
  });
});

describe('flow-recipe-steps — chaining column write guard', () => {
  it('POST with step_type=bogus → 400', async () => {
    const { status, json } = await req('POST', '/s', {
      recipe_id: 'd0edcb09-2c66-4d79-8114-5c3e787de042', name: 'Step', step_type: 'bogus',
    });
    assert.equal(status, 400);
    assert.equal(json.error.code, 'BAD_REQUEST');
  });

  it('POST with non-string before_code → 400', async () => {
    const { status } = await req('POST', '/s', {
      recipe_id: 'd0edcb09-2c66-4d79-8114-5c3e787de042', name: 'Step', before_code: { not: 'a string' },
    });
    assert.equal(status, 400);
  });

  it('POST a step url with embedded credentials → 400', async () => {
    const { status, json } = await req('POST', '/s', {
      recipe_id: 'd0edcb09-2c66-4d79-8114-5c3e787de042', name: 'Step', method: 'POST', url: 'https://user:pass@svc/x',
    });
    assert.equal(status, 400, 'userinfo in a step url is rejected at the write boundary');
    assert.equal(json.error.code, 'BAD_REQUEST');
  });

  it('POST with before_code over 32KB → 413', async () => {
    const { status, json } = await req('POST', '/s', {
      recipe_id: 'd0edcb09-2c66-4d79-8114-5c3e787de042', name: 'Step', before_code: 'x'.repeat(32 * 1024 + 1),
    });
    assert.equal(status, 413);
    assert.equal(json.error.code, 'PAYLOAD_TOO_LARGE');
  });

  it('POST a compute step with valid before_code → 2xx', async () => {
    const { status, json } = await req('POST', '/s', {
      recipe_id: 'd0edcb09-2c66-4d79-8114-5c3e787de042', name: 'Compute', step_type: 'compute',
      before_code: 'return { outputs: { derived: JSON.stringify(1) } }',
    });
    assert.equal(status, 200, `expected 200, got ${status}: ${JSON.stringify(json)}`);
  });

  it('clearing a code slot with null is accepted', async () => {
    const { status } = await req('POST', '/s', {
      recipe_id: 'd0edcb09-2c66-4d79-8114-5c3e787de042', name: 'Step', before_code: null, after_code: '',
    });
    assert.equal(status, 200);
  });
});

describe('flow-recipe-steps — (b) URL guard', () => {
  it('POST with non-http url → 400', async () => {
    const { status } = await req('POST', '/s', {
      recipe_id: 'd0edcb09-2c66-4d79-8114-5c3e787de042',
      name: 'Step',
      url: 'ftp://x.example.com/resource',
    });
    assert.equal(status, 400);
  });

  it('POST with http url → not blocked by url guard', async () => {
    const { status } = await req('POST', '/s', {
      recipe_id: 'd0edcb09-2c66-4d79-8114-5c3e787de042',
      name: 'Step',
      url: 'http://host/path',
      method: 'GET',
    });
    // May be 200 or another code depending on other guards, but must not be 400 from url guard.
    assert.notEqual(status, 400);
  });
});

describe('flow-recipe-steps — (c) HTTP method allowlist', () => {
  it('POST with method=FOO → 400 INVALID_METHOD', async () => {
    const { status, json } = await req('POST', '/s', {
      recipe_id: 'd0edcb09-2c66-4d79-8114-5c3e787de042',
      name: 'Step',
      url: 'http://host/path',
      method: 'FOO',
    });
    assert.equal(status, 400);
    assert.equal(json.error, 'INVALID_METHOD');
  });

  it('POST with method=get (lowercase) → normalised and accepted', async () => {
    const { status } = await req('POST', '/s', {
      recipe_id: 'd0edcb09-2c66-4d79-8114-5c3e787de042',
      name: 'Step',
      url: 'http://host/path',
      method: 'get',
    });
    // Guard normalises to GET and allows it; result may be 200 or another code.
    assert.notEqual(status, 400);
  });
});

describe('flow-recipe-steps — (d) re-pend parent recipe on POST', () => {
  it('POST with recipe_id → UPDATE flow_recipes SET status=pending fires', async () => {
    await req('POST', '/s', {
      recipe_id: 'd0edcb09-2c66-4d79-8114-5c3e787de042',
      name: 'Step 1',
      auth_type: 'none',
      auth_config: {},
    });
    const repend = queries.find(
      (q) => /UPDATE `fmb_flow_recipes`/.test(q.sql)
           && Array.isArray(q.params) && q.params.includes('d0edcb09-2c66-4d79-8114-5c3e787de042'),
    );
    assert.ok(repend, 'must issue UPDATE on fmb_flow_recipes with d0edcb09-2c66-4d79-8114-5c3e787de042 as param');
    assert.ok(
      repend.sql.includes("`status` = 'pending'"),
      "UPDATE must contain `status` = 'pending'",
    );
  });

  it('POST without recipe_id → no UPDATE on flow_recipes', async () => {
    await req('POST', '/s', { name: 'Step', auth_type: 'none', auth_config: {} });
    const repend = queries.find((q) => /UPDATE `fmb_flow_recipes`/.test(q.sql));
    assert.equal(repend, undefined, 'must not issue UPDATE when recipe_id is absent');
  });
});

describe('flow-recipe-steps — (e) re-pend parent recipe on PUT', () => {
  it('PUT /:id → SELECT recipe_id then UPDATE flow_recipes SET status=pending', async () => {
    const { status } = await req('PUT', '/s/a6106eb9-46f9-491a-8027-c4a21a20204e', { name: 'Step 1 updated' });
    // The re-pend via-resolve SELECT must have fired (on the write conn).
    const selectQ = queries.find(
      (q) => /SELECT `recipe_id` AS via FROM `fmb_flow_recipe_steps`/.test(q.sql),
    );
    assert.ok(selectQ, 'must SELECT recipe_id from fmb_flow_recipe_steps for PUT');
    // The re-pend UPDATE must have fired with the resolved recipe_id.
    const updateQ = queries.find(
      (q) => /UPDATE `fmb_flow_recipes`/.test(q.sql)
           && Array.isArray(q.params) && q.params.includes('d0edcb09-2c66-4d79-8114-5c3e787de042'),
    );
    assert.ok(updateQ, 'must UPDATE flow_recipes with resolved d0edcb09-2c66-4d79-8114-5c3e787de042 on PUT');
    // The step write itself should succeed.
    assert.equal(status, 200, `PUT expected 200, got ${status}`);
  });
});

describe('flow-recipe-steps — (d2) re-pend covers rejected recipes', () => {
  it('rejected recipe is re-pended (rejected→edit→pending lifecycle)', async () => {
    // The status gate is now in JS (repandFrom includes 'rejected'): the
    // FOR UPDATE SELECT reads the locked status, then the UPDATE fires only
    // when status ∈ repandFrom. Drive a rejected parent and assert it re-pends.
    recipeStatus = 'rejected';
    await req('POST', '/s', {
      recipe_id: 'd0edcb09-2c66-4d79-8114-5c3e787de042',
      name: 'Step 1',
      auth_type: 'none',
      auth_config: {},
    });
    const repend = queries.find(
      (q) => /UPDATE `fmb_flow_recipes`/.test(q.sql)
           && Array.isArray(q.params) && q.params.includes('d0edcb09-2c66-4d79-8114-5c3e787de042'),
    );
    assert.ok(repend, 'UPDATE on fmb_flow_recipes must fire for a rejected recipe');
    assert.ok(
      repend.sql.includes("`status` = 'pending'"),
      "UPDATE must set `status` = 'pending'",
    );
  });

  it('a recipe not in repandFrom (e.g. already pending) is NOT re-pended', async () => {
    recipeStatus = 'pending';
    await req('POST', '/s', {
      recipe_id: 'd0edcb09-2c66-4d79-8114-5c3e787de042',
      name: 'Step 1',
      auth_type: 'none',
      auth_config: {},
    });
    const repend = queries.find((q) => /UPDATE `fmb_flow_recipes`/.test(q.sql));
    assert.equal(repend, undefined, 'no UPDATE when status is outside repandFrom');
  });
});

describe('flow-recipe-steps — (f) cross-owner POST: 403, re-pend UPDATE not fired', () => {
  it('editor POST under a recipe owned by someone else → 403, UPDATE not fired', async () => {
    role = 'editor';
    recipeOwnerId = 'other-user'; // recipe owned by a different user
    const { status } = await req('POST', '/s', {
      recipe_id: 'd0edcb09-2c66-4d79-8114-5c3e787de042',
      name: 'Step',
      auth_type: 'none',
      auth_config: {},
    });
    // createCrudRoutes returns 403 when editor does not own the parent recipe.
    assert.equal(status, 403, `expected 403 for cross-owner POST, got ${status}`);
    // The re-pend UPDATE must NOT have fired — ownership pre-check bailed early.
    const repend = queries.find((q) => /UPDATE `fmb_flow_recipes`/.test(q.sql));
    assert.equal(repend, undefined, 'UPDATE on flow_recipes must not fire for cross-owner editor');
  });
});

describe('flow-recipe-steps — (f2) shared recipe (null owner): editor POST must re-pend', () => {
  it('editor POST step on a shared (null owner_id) approved recipe → UPDATE fires, 2xx', async () => {
    role = 'editor';
    recipeOwnerId = null; // shared recipe — owner_id IS NULL
    const { status } = await req('POST', '/s', {
      recipe_id: 'd0edcb09-2c66-4d79-8114-5c3e787de042',
      name: 'Step',
      auth_type: 'none',
      auth_config: {},
    });
    // The step write must succeed — null owner means any editor can write via parentOwnership.
    assert.ok(status >= 200 && status < 300, `expected 2xx for shared recipe POST, got ${status}`);
    // The re-pend UPDATE must have fired — approval bypass must not be possible for shared recipes.
    const repend = queries.find(
      (q) => /UPDATE `fmb_flow_recipes`/.test(q.sql)
           && Array.isArray(q.params) && q.params.includes('d0edcb09-2c66-4d79-8114-5c3e787de042'),
    );
    assert.ok(repend, 'UPDATE on fmb_flow_recipes must fire for shared (null owner) recipe');
    assert.ok(
      repend.sql.includes("`status` = 'pending'"),
      "UPDATE must set `status` = 'pending'",
    );
  });
});

describe('flow-recipe-steps — (g) DELETE: re-pend SELECT + UPDATE fire for owner', () => {
  it('editor DELETE step whose recipe is owned by editor → re-pend fires, 200', async () => {
    role = 'editor';
    // recipeOwnerId stays '5b729f1e-5c0b-447c-8144-3210469bc62c' (matches req.user.id) — editor owns the recipe.
    const { status } = await req('DELETE', '/s/a6106eb9-46f9-491a-8027-c4a21a20204e');
    // The via-resolve SELECT must have fired (resolves parent from stored step row).
    const selectQ = queries.find(
      (q) => /SELECT `recipe_id` AS via FROM `fmb_flow_recipe_steps`/.test(q.sql),
    );
    assert.ok(selectQ, 'must SELECT recipe_id from fmb_flow_recipe_steps for DELETE');
    // The re-pend UPDATE must have fired with the resolved recipe_id.
    const updateQ = queries.find(
      (q) => /UPDATE `fmb_flow_recipes`/.test(q.sql)
           && Array.isArray(q.params) && q.params.includes('d0edcb09-2c66-4d79-8114-5c3e787de042'),
    );
    assert.ok(updateQ, 'must UPDATE flow_recipes with d0edcb09-2c66-4d79-8114-5c3e787de042 on DELETE');
    assert.equal(status, 200, `DELETE expected 200, got ${status}`);
  });
});
