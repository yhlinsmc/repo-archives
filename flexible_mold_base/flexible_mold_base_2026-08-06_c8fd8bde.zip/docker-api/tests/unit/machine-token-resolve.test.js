/**
 * machine-token-resolve.test.js
 *
 * Edge /edge/internal/machine-token coverage (S2S-only token resolution):
 *   - POST /resolve happy path → 200 { sub, scope } + last_used_at stamped
 *   - unknown token → 401 invalid_token + a login_audit row (machine_token,
 *     reason unknown_token, success 0), dummy-compare path taken on the miss
 *   - inactive account (deactivate then resolve) → immediate 401 invalid_token
 *     + audit reason inactive
 *   - tampered / truncated token (hash no longer maps a row) → 401 invalid_token
 *   - the credential lookup reads the WRITER pool, never a replica
 *
 * The DB pool is a require.cache spy (no real MariaDB); the hash module is
 * wrapped to observe the dummy-compare argument on a miss.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../src/edge/db');
const hashKey = require.resolve('../../src/edge/lib/machine-token-hash');

// Real hash impl, wrapped so the test can assert the dummy-compare path.
const realHash = require('../../src/edge/lib/machine-token-hash');
const { hashToken } = realHash;
let verifyCalls;
require.cache[hashKey] = {
  id: hashKey, filename: hashKey, loaded: true,
  exports: {
    hashToken: realHash.hashToken,
    verifyTokenHash: (token, storedHash) => {
      verifyCalls.push({ token, storedHash });
      return realHash.verifyTokenHash(token, storedHash);
    },
  },
};

let serviceAccountRow;
let seededHash;
let calls;

function makeSpyPool() {
  calls = { roQueries: [], rwQueries: [] };
  const conn = (bucket) => ({
    async query(sql, params) {
      bucket.push({ sql, params });
      if (/FROM `[^`]*service_accounts` WHERE token_hash/.test(sql)) {
        // Faithful lookup: only the row whose stored hash equals the presented
        // token's hash is returned (tampered/truncated tokens miss).
        return serviceAccountRow && params[0] === seededHash ? [serviceAccountRow] : [];
      }
      return [];
    },
    release() {},
  });
  return {
    ro: { async getConnection() { return conn(calls.roQueries); } },
    rw: { async getConnection() { return conn(calls.rwQueries); } },
  };
}

const poolSpy = {};
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: poolSpy, t: (name) => `fmb_${name}`, isPoolReady: () => true },
};

let server;
let port;

before(async () => {
  Object.assign(poolSpy, makeSpyPool());
  const router = require('../../src/edge/routes/internal/machine-token');
  const app = express();
  app.use(express.json());
  app.use('/edge/internal/machine-token', router);
  await new Promise((resolve) => {
    server = app.listen(0, '127.0.0.1', () => { port = server.address().port; resolve(); });
  });
});

after(async () => {
  await new Promise((resolve) => server.close(resolve));
  delete require.cache[dbKey];
  delete require.cache[hashKey];
});

beforeEach(() => {
  Object.assign(poolSpy, makeSpyPool());
  serviceAccountRow = null;
  seededHash = null;
  verifyCalls = [];
});

function request(method, path_, body) {
  return new Promise((resolve, reject) => {
    const payload = body === undefined ? null : JSON.stringify(body);
    const headers = { 'Content-Type': 'application/json' };
    if (payload) headers['Content-Length'] = Buffer.byteLength(payload);
    const req = http.request({ host: '127.0.0.1', port, path: path_, method, headers }, (res) => {
      const chunks = [];
      res.on('data', (c) => chunks.push(c));
      res.on('end', () => {
        const raw = Buffer.concat(chunks).toString('utf-8');
        let json = null;
        try { json = JSON.parse(raw); } catch { /* noop */ }
        resolve({ status: res.statusCode, raw, json });
      });
    });
    req.on('error', reject);
    if (payload) req.write(payload);
    req.end();
  });
}

function findAuditInsert() {
  return calls.rwQueries.find((q) => /INSERT INTO `fmb_login_audit`/.test(q.sql));
}

function seedAccount({ token, isActive = 1, scope = { roots: ['n1'], operations: ['read'] } }) {
  seededHash = hashToken(token);
  // token_hash is selected back so the route re-verifies against the PERSISTED
  // hash, not the just-computed lookup value.
  serviceAccountRow = { id: 'sa1', token_hash: seededHash, scope, is_active: isActive };
}

describe('machine-token /resolve — happy path', () => {
  it('returns { sub, scope } for a valid token and stamps last_used_at', async () => {
    const scope = { roots: ['n1', 'n2'], operations: ['read'] };
    seedAccount({ token: 'live-token', scope });
    const res = await request('POST', '/edge/internal/machine-token/resolve', {
      token: 'live-token', auditInfo: { ip: '10.0.0.1', userAgent: 'curl/8' },
    });
    assert.equal(res.status, 200);
    assert.equal(res.json.sub, 'sa1');
    assert.deepEqual(res.json.scope, scope);
    const update = calls.rwQueries.find((q) => /UPDATE `fmb_service_accounts` SET last_used_at/.test(q.sql));
    assert.ok(update, 'last_used_at UPDATE must be issued on success');
    assert.equal(update.params[0], 'sa1');
    assert.equal(findAuditInsert(), undefined, 'no failure audit on success');
    // The constant-time verify re-checked the token against the row's PERSISTED
    // token_hash, not merely the just-computed lookup value.
    assert.ok(
      verifyCalls.some((c) => c.storedHash === hashToken('live-token')),
      'verify must run against the row persisted token_hash',
    );
  });

  it('reads the credential/is_active lookup from the writer pool, never a replica', async () => {
    seedAccount({ token: 'live-token' });
    const res = await request('POST', '/edge/internal/machine-token/resolve', { token: 'live-token' });
    assert.equal(res.status, 200);
    const lookup = calls.rwQueries.find((q) =>
      /SELECT id, token_hash, scope, is_active FROM `fmb_service_accounts` WHERE token_hash/.test(q.sql));
    assert.ok(lookup, 'lookup MUST go through the rw (writer) pool');
    assert.equal(calls.roQueries.length, 0, 'auth decision must not read a (possibly stale) replica');
  });

  it('parses a JSON-string scope column (driver returned string)', async () => {
    seededHash = hashToken('live-token');
    serviceAccountRow = { id: 'sa1', token_hash: seededHash, scope: '{"roots":["x"],"operations":["read"]}', is_active: 1 };
    const res = await request('POST', '/edge/internal/machine-token/resolve', { token: 'live-token' });
    assert.equal(res.status, 200);
    assert.deepEqual(res.json.scope, { roots: ['x'], operations: ['read'] });
  });

  it('malformed scope JSON → 503 (no throw), never resolves a sub', async () => {
    seededHash = hashToken('live-token');
    serviceAccountRow = { id: 'sa1', token_hash: seededHash, scope: '{not valid json', is_active: 1 };
    const res = await request('POST', '/edge/internal/machine-token/resolve', { token: 'live-token' });
    assert.equal(res.status, 503);
    assert.equal('sub' in res.json, false);
  });
});

describe('machine-token /resolve — uniform invalid_token (no enumeration) + audit', () => {
  it('unknown token → 401 invalid_token + audit row, dummy-compare path taken', async () => {
    serviceAccountRow = null;
    const res = await request('POST', '/edge/internal/machine-token/resolve', {
      token: 'nope', auditInfo: { ip: '1.2.3.4', userAgent: 'x' },
    });
    assert.equal(res.status, 401);
    assert.deepEqual(res.json, { error: 'invalid_token' });
    const audit = findAuditInsert();
    assert.ok(audit, 'audit row must be written');
    assert.match(audit.sql, /'machine_token'/);
    assert.match(audit.sql, /FALSE/);
    assert.equal(audit.params[0], 'unknown_token');
    // dummy-compare: verify ran against the fixed all-zero hash on the miss.
    const missCompare = verifyCalls.find((c) => c.storedHash === '0'.repeat(64));
    assert.ok(missCompare, 'verifyTokenHash must run against DUMMY_TOKEN_HASH on a miss');
  });

  it('inactive account (deactivate then resolve) → immediate 401 + audit reason inactive', async () => {
    seedAccount({ token: 'live-token', isActive: 0 });
    const res = await request('POST', '/edge/internal/machine-token/resolve', { token: 'live-token' });
    assert.equal(res.status, 401);
    assert.deepEqual(res.json, { error: 'invalid_token' });
    const audit = findAuditInsert();
    assert.ok(audit);
    assert.equal(audit.params[0], 'inactive');
  });

  it('tampered token (hash no longer maps a row) → 401 invalid_token', async () => {
    seedAccount({ token: 'live-token' });
    const res = await request('POST', '/edge/internal/machine-token/resolve', { token: 'live-tokeX' });
    assert.equal(res.status, 401);
    assert.deepEqual(res.json, { error: 'invalid_token' });
    assert.equal(findAuditInsert().params[0], 'unknown_token');
  });

  it('truncated token → 401 invalid_token (indistinguishable shape)', async () => {
    seedAccount({ token: 'live-token' });
    const res = await request('POST', '/edge/internal/machine-token/resolve', { token: 'live-tok' });
    assert.equal(res.status, 401);
    assert.deepEqual(res.json, { error: 'invalid_token' });
  });

  it('missing token → 401 invalid_token without a DB lookup', async () => {
    const res = await request('POST', '/edge/internal/machine-token/resolve', {});
    assert.equal(res.status, 401);
    assert.deepEqual(res.json, { error: 'invalid_token' });
    assert.equal(calls.rwQueries.length, 0, 'no DB touch on malformed input');
  });

  it('over-length token → 401 invalid_token without a DB lookup', async () => {
    const res = await request('POST', '/edge/internal/machine-token/resolve', { token: 'x'.repeat(4097) });
    assert.equal(res.status, 401);
    assert.deepEqual(res.json, { error: 'invalid_token' });
    assert.equal(calls.rwQueries.length, 0);
  });
});
