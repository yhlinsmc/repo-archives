/**
 * flow-payload-serialize.test.js
 *
 * Unit tests for the flow payload serializer shared lib — the dispatch-path
 * counterpart to the FE deep-json-format. A flow payload whose nested members
 * are already JSON strings must be expanded before JSON/YAML serialization so
 * the value dispatched upstream (and previewed) contains real nested structure,
 * not escaped `\n` / quoted JSON.
 */
const { it, describe } = require('node:test');
const assert = require('node:assert/strict');
const yaml = require('yaml');
const {
  deepJsonExpand,
  serializeFlowPayload,
} = require('../../src/shared/lib/flow-payload-serialize');

describe('deepJsonExpand', () => {
  it('parses a JSON-string value into real structure', () => {
    assert.deepEqual(
      deepJsonExpand({ data: '[{"x":1}]' }),
      { data: [{ x: 1 }] },
    );
  });

  it('recurses into arrays and nested strings', () => {
    assert.deepEqual(
      deepJsonExpand({ a: ['{"b":2}', 3] }),
      { a: [{ b: 2 }, 3] },
    );
  });

  it('leaves a non-JSON string untouched', () => {
    assert.deepEqual(deepJsonExpand({ s: 'hello' }), { s: 'hello' });
  });

  it('passes through null / undefined / scalars', () => {
    assert.equal(deepJsonExpand(null), null);
    assert.equal(deepJsonExpand(undefined), undefined);
    assert.equal(deepJsonExpand(5), 5);
  });

  it('strips prototype-pollution keys on expand', () => {
    const out = deepJsonExpand({ good: 1, __proto__: { polluted: true }, constructor: 'x', prototype: 'y' });
    assert.deepEqual(Object.keys(out), ['good']);
  });

  it('strips prototype-pollution keys nested inside an expanded JSON string', () => {
    const out = deepJsonExpand({ nested: '{"__proto__":{"p":1},"ok":2}' });
    assert.deepEqual(out, { nested: { ok: 2 } });
  });

  it('fail-closed: a pathologically deep payload does not overflow the stack', () => {
    let deep = { leaf: 1 };
    for (let i = 0; i < 5000; i++) deep = { child: deep };
    // Must not throw RangeError; past the depth cap the subtree is left as-is.
    assert.doesNotThrow(() => deepJsonExpand(deep));
  });
});

describe('serializeFlowPayload — JSON', () => {
  it('serializes an expanded nested-JSON-string field with no escaped quotes', () => {
    const out = serializeFlowPayload({ data: '[{"x":1}]' }, 'application/json');
    assert.equal(out, '{"data":[{"x":1}]}');
    assert.ok(!out.includes('\\"'), 'must not contain escaped quotes');
    assert.ok(!out.includes('\\n'), 'must not contain escaped newlines');
  });

  it('coerces a non-object payload to {}', () => {
    assert.equal(serializeFlowPayload(null, 'application/json'), '{}');
    assert.equal(serializeFlowPayload('nope', 'application/json'), '{}');
    assert.equal(serializeFlowPayload(42, 'application/json'), '{}');
  });

  it('is a no-op shape change for a payload with no nested JSON strings', () => {
    assert.equal(serializeFlowPayload({ a: 1 }, 'application/json'), '{"a":1}');
  });
});

describe('serializeFlowPayload — YAML', () => {
  it('emits real nested structure (round-trips) for a nested-JSON-string field', () => {
    const out = serializeFlowPayload({ data: '[{"x":1}]' }, 'application/yaml');
    // Parsed back, the field is a real array/object, not a quoted JSON scalar.
    assert.deepEqual(yaml.parse(out), { data: [{ x: 1 }] });
    assert.ok(!out.includes('[{"x":1}]'), 'must not embed the raw JSON string as a scalar');
  });

  it('renders a multiline string as real line breaks (no escaped \\n)', () => {
    const out = serializeFlowPayload({ note: 'line1\nline2' }, 'application/yaml');
    assert.ok(!out.includes('\\n'), 'multiline value must not be an escaped scalar');
    assert.deepEqual(yaml.parse(out), { note: 'line1\nline2' });
  });
});
