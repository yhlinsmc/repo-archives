/**
 * flow-recipes-run-begin.test.js
 *
 * Tests for POST /edge/internal/flow-recipes/run-begin — the gate + serialize +
 * create-partial-run S2S endpoint. Mirrors connectors-prepare.test.js harness:
 * mocked pool injected via require.cache before router require, single live server.
 *
 * Covers:
 *   (a) approved+active+bound → 200, partial run created, actor_id server-stamped
 *   (b) status !== 'approved' → 422 RECIPE_NOT_APPROVED, no run row created
 *   (c) is_active=0 → 409 RECIPE_INACTIVE
 *   (d) blueprint_id=null → 422 RECIPE_UNBOUND
 *   (e) plain user role is accepted (no role gate)
 *   (f) YAML content_type serializes via yaml.stringify
 *   (g) template ownership: own, shared, foreign, admin-bypass
 *   (h) link_extract and external_id_extract NOT returned in run-begin response
 */
const { it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');
const yaml = require('yaml');

const dbKey = require.resolve('../../src/edge/db');

// ── Mock state (reset in beforeEach) ─────────────────────────────────────────
let recipeRow = null;
let stepsRows = [];
let templateRow = null;         // returned by user_templates SELECT (null = not found)
let lastRunInsert = null;       // full extracted column→value map for the INSERT
let lastRunInsertSql = null;    // raw SQL string of the INSERT (for NOW() assertion)
let lastRunInsertParams = null; // raw params array of the INSERT (for ISO-string assertion)
let runInsertCount = 0;
let currentUserId = 'u1';
let currentRole = 'user';
// When true, a SELECT naming the additive chaining columns throws errno 1054 to
// simulate a no-ALTER operator-mode DB; the legacy fallback query must succeed.
let simulateMissingChainingColumns = false;
// When true, the run INSERT that names code_version throws errno 1054 to model a
// no-ALTER DB missing that column; the retry INSERT (without code_version) succeeds.
let simulateMissingRunCodeVersion = false;
// Columns the simulated DB does NOT have on flow_recipe_runs. Any INSERT naming
// one throws errno 1054, and the information_schema probe the route falls back
// to reports the rest as present — which is what distinguishes "drop only the
// absent column" from "drop everything optional".
let missingRunColumns = new Set();
let activityInserts = [];
// Delegated access. `grantRows` is what the grant lookup finds; the presence
// flag models a database whose operator account could not create the table at
// all, on which dispatch must behave exactly as it did before grants existed.
let grantRows = [];
let grantsTablePresent = false;
// Who owns the blueprint the template names. A blueprint's owner may dispatch
// every record under it without any grant existing, so this is what the
// hierarchy answers when that arm asks.
let blueprintOwnerId = null;
// The trail of who dispatched what. Absent by default so every case written
// before it existed keeps issuing exactly the statements it did.
let activityTablePresent = false;
let activityInsertError = null;
// What a database says when the permission the run INSERT carries no longer
// holds: the statement runs and matches nothing. Off by default, so every case
// written before the gate existed keeps getting its row.
let gatedInsertMatchesNothing = false;

// The simulated DB's absent columns, folded together so the older
// code_version-specific switch keeps working unchanged.
function absentRunColumns() {
  const absent = new Set(missingRunColumns);
  if (simulateMissingRunCodeVersion) absent.add('code_version');
  return absent;
}

const conn = {
  async query(sql, params) {
    if (simulateMissingChainingColumns && /(runs_on|step_type|before_code|after_code|flow_last_run_id)/.test(sql)) {
      const e = new Error("Unknown column");
      e.errno = 1054;
      e.code = 'ER_BAD_FIELD_ERROR';
      throw e;
    }
    // EVERY INSERT IS MATCHED BEFORE ANY SELECT BRANCH. The run INSERT carries
    // its own permission predicate now, so its text names `user_templates` and
    // the grants table as well — and the branches below, which match on the
    // table a statement mentions, would otherwise claim it and answer it as a
    // template read.
    if (/^\s*INSERT INTO/i.test(sql)) return insertQuery(sql, params);
    // Recipe SELECT
    if (/FROM `fmb_flow_recipes`/.test(sql) && /WHERE id = \?/.test(sql)) {
      return recipeRow ? [recipeRow] : [];
    }
    // User_templates SELECT (template ownership check)
    if (/FROM `fmb_user_templates`/.test(sql)) {
      return templateRow ? [templateRow] : [];
    }
    // Steps SELECT
    if (/FROM `fmb_flow_recipe_steps`/.test(sql)) {
      return stepsRows;
    }
    // Availability probes: one flag per table.
    if (/information_schema\.TABLES/i.test(sql)) {
      const [name] = params || [];
      if (String(name).endsWith('delegated_grants')) return grantsTablePresent ? [{ 1: 1 }] : [];
      if (String(name).endsWith('template_activity')) return activityTablePresent ? [{ 1: 1 }] : [];
      return [];
    }
    // The grant lookup itself.
    if (/FROM `fmb_delegated_grants`/.test(sql)) {
      return grantRows;
    }
    // "Do you own this blueprint" — the one arm that reads no optional table.
    if (/SELECT 1 AS owned FROM `fmb_hierarchy_nodes`/.test(sql)) {
      const [, callerId] = params || [];
      return blueprintOwnerId && callerId === blueprintOwnerId ? [{ owned: 1 }] : [];
    }
    // Additive-column probe the run INSERT falls back to on a 1054. Candidate
    // names arrive as bound params, never in the SQL text.
    if (/information_schema\.COLUMNS/i.test(sql)) {
      const candidates = (params || []).slice(1);
      return candidates
        .filter((c) => !absentRunColumns().has(c))
        .map((c) => ({ COLUMN_NAME: c }));
    }
    return [];
  },
  release() {},
};

/**
 * The INSERTs, answered apart from the reads.
 *
 * WHAT THIS DELIBERATELY DOES NOT DO: evaluate the run INSERT's permission
 * predicate. A stub cannot, and one that modelled the predicate would be a
 * second implementation of the rule, agreeing with itself. What is asserted
 * here is that the predicate is IN the statement and bound to the caller;
 * whether it decides correctly, and whether it closes the window it was added
 * for, is settled against a real database in
 * tests/integration/flow-run-writeback-revocation-real-db.test.js.
 *
 * `gatedInsertMatchesNothing` is the one lever: it makes the gated INSERT
 * report zero rows, which is how a database says "the answer changed" — so the
 * ROUTE's handling of that answer can be asserted without pretending the stub
 * worked it out.
 */
function insertQuery(sql, params) {
  if (/INSERT INTO `fmb_template_activity`/i.test(sql)) {
    activityInserts.push({ sql, params });
    if (activityInsertError) throw activityInsertError;
    return { affectedRows: 1 };
  }
  if (/INSERT INTO `fmb_flow_recipe_runs`/i.test(sql)) {
    for (const col of absentRunColumns()) {
      if (new RegExp(`\\b${col}\\b`).test(sql)) {
        const e = new Error(`Unknown column '${col}'`);
        e.errno = 1054; e.code = 'ER_BAD_FIELD_ERROR'; throw e;
      }
    }
    runInsertCount++;
    lastRunInsertSql = sql;
    lastRunInsertParams = params || [];
    // Parse column names from SQL so the test is column-order-agnostic.
    // NOTE: started_at uses NOW() in SQL (no bound param), so it maps to undefined
    // in lastRunInsert — that is intentional and asserted in the P1 tests below.
    // The gated form binds its predicate params AFTER the column values, so the
    // positional pairing below is unaffected by it.
    const colMatch = sql.match(/INSERT INTO `fmb_flow_recipe_runs` \(([^)]+)\)/i);
    if (colMatch) {
      const cols = colMatch[1].split(',').map((c) => c.trim().replace(/`/g, ''));
      const obj = {};
      cols.forEach((col, i) => { obj[col] = params[i]; });
      lastRunInsert = obj;
    }
    const gated = /\bSELECT\b/i.test(sql);
    const affectedRows = gated && gatedInsertMatchesNothing ? 0 : 1;
    return { insertId: 'run-inserted', affectedRows };
  }
  return [];
}

// Inject mock DB before requiring the router so no real DB connection fires.
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: {
    pool: {
      ro: { getConnection: async () => conn },
      rw: { getConnection: async () => conn },
    },
    t: (name) => `fmb_${name}`,
  },
};

const router = require('../../src/edge/routes/internal/flow-recipes-run');
const { _resetGrantsTableCache } = require('../../src/edge/lib/delegated-grants');
const { _resetActivityTableCache } = require('../../src/edge/lib/template-activity');

let server; let baseUrl;
before(async () => {
  const app = express();
  app.use(express.json());
  // Inject a user identity — the router must NEVER trust body.actor_id.
  app.use((req, _res, next) => {
    req.user = { id: currentUserId, role: currentRole };
    next();
  });
  app.use('/edge/internal/flow-recipes', router);
  server = http.createServer(app);
  await new Promise((r) => server.listen(0, r));
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});
after(() => server && server.close());

beforeEach(() => {
  recipeRow = null;
  stepsRows = [];
  templateRow = null;
  lastRunInsert = null;
  lastRunInsertSql = null;
  lastRunInsertParams = null;
  runInsertCount = 0;
  currentUserId = 'u1';
  currentRole = 'user';
  simulateMissingChainingColumns = false;
  simulateMissingRunCodeVersion = false;
  missingRunColumns = new Set();
  grantRows = [];
  grantsTablePresent = false;
  blueprintOwnerId = null;
  activityTablePresent = false;
  activityInsertError = null;
  activityInserts = [];
  gatedInsertMatchesNothing = false;
  // The availability probe remembers a table it has seen for the life of the
  // process, so a test that changes the answer has to undo that.
  _resetGrantsTableCache();
  _resetActivityTableCache();
});

// ── Helpers ───────────────────────────────────────────────────────────────────

function makeRecipe(overrides = {}) {
  return {
    id: 'r1', status: 'approved', is_active: 1, blueprint_id: 'bp1',
    content_type: 'application/json',
    link_extract: JSON.stringify({ path: 'url' }),
    external_id_extract: JSON.stringify({ path: 'id' }),
    consumed_output_keys: null,
    ...overrides,
  };
}

async function post(body) {
  const res = await fetch(`${baseUrl}/edge/internal/flow-recipes/run-begin`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
  });
  return { status: res.status, body: await res.json() };
}

// ── (a) approved + active + bound → 200, partial run, actor_id server-stamped ─

it('returns 200 and creates a partial run for an approved active bound recipe', async () => {
  recipeRow = makeRecipe();
  stepsRows = [
    { id: 's1', sequence: 1 },
    { id: 's2', sequence: 2 },
  ];
  // template_id is sent in the body so set a matching owned templateRow
  templateRow = { owner_id: 'u1' };

  const r = await post({
    recipe_id: 'r1',
    payload: { a: 1 },
    output_snapshot: '{"x":1}',
    template_id: 'tpl1',
    blueprint_id: 'bp1',
    mode: 'create',
  });

  assert.equal(r.status, 200);
  assert.ok(r.body.data.run_id, 'run_id must be returned');
  assert.equal(r.body.data.serialized_payload, JSON.stringify({ a: 1 }),
    'serialized_payload must be JSON.stringify(payload) for application/json');
  assert.deepEqual(r.body.data.steps, [
    { id: 's1', sequence: 1, step_type: 'api', before_code: null, after_code: null },
    { id: 's2', sequence: 2, step_type: 'api', before_code: null, after_code: null },
  ], 'steps must be ordered by sequence and carry the chaining columns');
  assert.equal(r.body.data.requires_client_orchestration, false,
    'a JS-free recipe must not require client orchestration');
});

it('flags requires_client_orchestration when a step carries before/after JS or is compute', async () => {
  recipeRow = makeRecipe();
  stepsRows = [
    { id: 's1', sequence: 1, step_type: 'api', before_code: 'return { outputs: {} }', after_code: null },
    { id: 's2', sequence: 2, step_type: 'compute', before_code: 'return { outputs: {} }', after_code: null },
  ];
  templateRow = { owner_id: 'u1' };

  const r = await post({ recipe_id: 'r1', payload: {}, template_id: 'tpl1', client_orchestration: true });
  assert.equal(r.status, 200);
  assert.equal(r.body.data.requires_client_orchestration, true);
  assert.equal(r.body.data.steps[1].step_type, 'compute');
});

it('rejects a JS recipe with USE_CLIENT_ORCHESTRATION when the caller is the server orchestrator', async () => {
  recipeRow = makeRecipe();
  stepsRows = [{ id: 's1', sequence: 1, step_type: 'api', before_code: 'return { outputs: {} }', after_code: null }];
  templateRow = { owner_id: 'u1' };

  // client_orchestration omitted (falsey) → the legacy server path → must fail closed.
  const r = await post({ recipe_id: 'r1', payload: {}, template_id: 'tpl1' });
  assert.equal(r.status, 422);
  assert.equal(r.body.error.code, 'USE_CLIENT_ORCHESTRATION');
  assert.equal(runInsertCount, 0, 'no orphan partial run row may be created on rejection');
});

it('derives update mode from a prior-pushed template and enforces a create-only trigger', async () => {
  recipeRow = makeRecipe({ runs_on: 'create' });
  stepsRows = [{ id: 's1', sequence: 1 }];
  templateRow = { owner_id: 'u1', flow_last_run_id: 'RUN-123' };

  const r = await post({ recipe_id: 'r1', payload: {}, template_id: 'tpl1', mode: 'create' });
  assert.equal(r.status, 409);
  assert.equal(r.body.error.code, 'FLOW_MODE_MISMATCH');
  assert.equal(runInsertCount, 0, 'a mismatched run must not create a run row');
});

it('no-ALTER DB (missing chaining columns) still runs a JS-free recipe via legacy fallback', async () => {
  simulateMissingChainingColumns = true;
  recipeRow = makeRecipe(); // no runs_on key — legacy shape
  stepsRows = [{ id: 's1', sequence: 1 }];
  templateRow = { owner_id: 'u1' };

  const r = await post({ recipe_id: 'r1', payload: { a: 1 }, template_id: 'tpl1' });
  assert.equal(r.status, 200, `legacy recipe must still run, got ${JSON.stringify(r.body)}`);
  assert.equal(r.body.data.requires_client_orchestration, false);
  assert.deepEqual(r.body.data.steps, [{ id: 's1', sequence: 1, step_type: 'api', before_code: null, after_code: null }]);
});

it('FLOW_MODE_MISMATCH fires before USE_CLIENT_ORCHESTRATION when both conditions hold', async () => {
  // A prior-pushed template (mode=update) running a create-only recipe whose steps
  // also carry JS: the mode guard must win so the modal shows the reset hatch
  // rather than a doomed client-orchestration round-trip.
  recipeRow = makeRecipe({ runs_on: 'create' });
  stepsRows = [{ id: 's1', sequence: 1, step_type: 'api', before_code: 'return { outputs: {} }', after_code: null }];
  templateRow = { owner_id: 'u1', flow_last_run_id: 'RUN-1' };

  const r = await post({ recipe_id: 'r1', payload: {}, template_id: 'tpl1' });
  assert.equal(r.status, 409);
  assert.equal(r.body.error.code, 'FLOW_MODE_MISMATCH');
  assert.equal(runInsertCount, 0);
});

it('allows a create-trigger recipe for a never-pushed template (mode derived = create)', async () => {
  recipeRow = makeRecipe({ runs_on: 'create' });
  stepsRows = [{ id: 's1', sequence: 1 }];
  templateRow = { owner_id: 'u1', flow_last_run_id: null };

  const r = await post({ recipe_id: 'r1', payload: {}, template_id: 'tpl1' });
  assert.equal(r.status, 200);
  assert.equal(r.body.data.mode, 'create');
});

it('stamps actor_id from req.user.id — never from the request body', async () => {
  recipeRow = makeRecipe();
  stepsRows = [{ id: 's1', sequence: 1 }];
  currentUserId = 'u-plain';

  await post({
    recipe_id: 'r1',
    payload: { x: 2 },
    // Caller attempts to forge actor_id — must be ignored
    actor_id: 'attacker-id',
  });

  assert.equal(runInsertCount, 1, 'exactly one INSERT must have been issued');
  assert.equal(lastRunInsert.actor_id, 'u-plain',
    'actor_id must be server-stamped from req.user.id, not from body');
  assert.equal(lastRunInsert.status, 'partial',
    'run status must be partial on creation');
});

it('does NOT expose link_extract or external_id_extract in run-begin response', async () => {
  recipeRow = makeRecipe();
  stepsRows = [];

  const r = await post({ recipe_id: 'r1', payload: {} });

  assert.equal(r.status, 200);
  // Finalize re-reads extract specs from DB — run-begin must not relay them.
  assert.equal(r.body.data.link_extract, undefined,
    'link_extract must not be returned in run-begin response');
  assert.equal(r.body.data.external_id_extract, undefined,
    'external_id_extract must not be returned in run-begin response');
});

// ── (b) status !== 'approved' → 422, no run row ──────────────────────────────

it('returns 422 RECIPE_NOT_APPROVED for a pending recipe and creates no run', async () => {
  recipeRow = makeRecipe({ status: 'pending' });
  stepsRows = [];

  const r = await post({ recipe_id: 'r1', payload: {} });

  assert.equal(r.status, 422);
  assert.equal(r.body.error.code, 'RECIPE_NOT_APPROVED');
  assert.equal(runInsertCount, 0, 'no run row must be created for a non-approved recipe');
});

it('returns 422 RECIPE_NOT_APPROVED for a rejected recipe', async () => {
  recipeRow = makeRecipe({ status: 'rejected' });

  const r = await post({ recipe_id: 'r1', payload: {} });

  assert.equal(r.status, 422);
  assert.equal(r.body.error.code, 'RECIPE_NOT_APPROVED');
  assert.equal(runInsertCount, 0);
});

// ── (c) is_active=0 → 409 RECIPE_INACTIVE ────────────────────────────────────

it('returns 409 RECIPE_INACTIVE when is_active is 0', async () => {
  recipeRow = makeRecipe({ is_active: 0 });

  const r = await post({ recipe_id: 'r1', payload: {} });

  assert.equal(r.status, 409);
  assert.equal(r.body.error.code, 'RECIPE_INACTIVE');
  assert.equal(runInsertCount, 0);
});

// ── (d) blueprint_id=null → 422 RECIPE_UNBOUND ───────────────────────────────

it('returns 422 RECIPE_UNBOUND when blueprint_id is null', async () => {
  recipeRow = makeRecipe({ blueprint_id: null });

  const r = await post({ recipe_id: 'r1', payload: {} });

  assert.equal(r.status, 422);
  assert.equal(r.body.error.code, 'RECIPE_UNBOUND');
  assert.equal(runInsertCount, 0);
});

// ── (e) plain user role is accepted (no role gate) ───────────────────────────

it('accepts a caller with role user (no role gate on run-begin)', async () => {
  recipeRow = makeRecipe();
  stepsRows = [{ id: 's1', sequence: 1 }];
  currentRole = 'user';
  currentUserId = 'u-plain-user';

  const r = await post({ recipe_id: 'r1', payload: { q: 7 } });

  assert.equal(r.status, 200, `user-role must be accepted; got ${r.body.error?.code}`);
  assert.equal(lastRunInsert.actor_id, 'u-plain-user');
});

// ── (f) YAML content_type serializes via yaml.stringify ──────────────────────

it('serializes payload via yaml.stringify when content_type is application/yaml', async () => {
  recipeRow = makeRecipe({ content_type: 'application/yaml' });
  stepsRows = [{ id: 's1', sequence: 1 }];

  const payload = { title: 'hello', count: 3 };
  const r = await post({ recipe_id: 'r1', payload });

  assert.equal(r.status, 200);
  const expectedYaml = yaml.stringify(payload, { lineWidth: 0 });
  assert.equal(r.body.data.serialized_payload, expectedYaml,
    'YAML content_type must produce yaml.stringify output');
});

// ── (f2) nested JSON-string members are expanded before serialize (dispatch) ──

it('expands nested JSON-string members in the dispatched serialized_payload (JSON)', async () => {
  recipeRow = makeRecipe({ content_type: 'application/json' });
  stepsRows = [{ id: 's1', sequence: 1 }];

  // A table field arrives as a JSON-stringified array (the real-world shape).
  const r = await post({ recipe_id: 'r1', payload: { rows: '[{"x":1}]' } });

  assert.equal(r.status, 200);
  assert.equal(r.body.data.serialized_payload, '{"rows":[{"x":1}]}',
    'nested JSON-string must be expanded to real structure, not an escaped scalar');
  assert.ok(!r.body.data.serialized_payload.includes('\\"'),
    'dispatched payload must not contain escaped quotes');
});

it('expands nested JSON-string members before yaml.stringify (dispatch)', async () => {
  recipeRow = makeRecipe({ content_type: 'application/yaml' });
  stepsRows = [{ id: 's1', sequence: 1 }];

  const r = await post({ recipe_id: 'r1', payload: { rows: '[{"x":1}]' } });

  assert.equal(r.status, 200);
  assert.deepEqual(yaml.parse(r.body.data.serialized_payload), { rows: [{ x: 1 }] },
    'YAML dispatch must carry real nested structure');
});

// ── not found → 404 ──────────────────────────────────────────────────────────

it('returns 404 RECIPE_NOT_FOUND when the recipe does not exist', async () => {
  recipeRow = null;

  const r = await post({ recipe_id: 'no-such-recipe', payload: {} });

  assert.equal(r.status, 404);
  assert.equal(r.body.error.code, 'RECIPE_NOT_FOUND');
  assert.equal(runInsertCount, 0);
});

// ── (g) template ownership guard ─────────────────────────────────────────────

it('allows run-begin when template_id is owned by the caller', async () => {
  recipeRow = makeRecipe();
  stepsRows = [{ id: 's1', sequence: 1 }];
  templateRow = { owner_id: 'u1' }; // currentUserId default

  const r = await post({ recipe_id: 'r1', payload: {}, template_id: 'tpl-own' });

  assert.equal(r.status, 200, `expected 200 for owned template; got ${r.body.error?.code}`);
  assert.equal(runInsertCount, 1, 'run INSERT must be issued for an owned template');
});

it('returns 403 TEMPLATE_FORBIDDEN when template_id belongs to another user', async () => {
  recipeRow = makeRecipe();
  stepsRows = [];
  templateRow = { owner_id: 'other-user' }; // not currentUserId ('u1')

  const r = await post({ recipe_id: 'r1', payload: {}, template_id: 'tpl-foreign' });

  assert.equal(r.status, 403, `expected 403 for foreign template; got ${r.status}`);
  assert.equal(r.body.error.code, 'TEMPLATE_FORBIDDEN');
  assert.equal(runInsertCount, 0, 'no run INSERT on forbidden template');
});

it('returns 403 TEMPLATE_FORBIDDEN for a null-owner (shared) template when caller is non-admin', async () => {
  recipeRow = makeRecipe();
  stepsRows = [];
  templateRow = { owner_id: null }; // shared — non-admin must NOT write through to finalize cache
  currentRole = 'user';             // plain user — admin bypass must NOT apply

  const r = await post({ recipe_id: 'r1', payload: {}, template_id: 'tpl-shared' });

  assert.equal(r.status, 403, `expected 403 for null-owner template (non-admin); got ${r.status}`);
  assert.equal(r.body.error.code, 'TEMPLATE_FORBIDDEN');
  assert.equal(runInsertCount, 0, 'no run INSERT must be issued for a shared template by a non-admin');
});

it('allows admin to run with a null-owner (shared) template (admin bypass)', async () => {
  recipeRow = makeRecipe();
  stepsRows = [{ id: 's1', sequence: 1 }];
  templateRow = { owner_id: null }; // shared
  currentRole = 'admin';
  currentUserId = 'admin-user';

  const r = await post({ recipe_id: 'r1', payload: {}, template_id: 'tpl-shared' });

  assert.equal(r.status, 200, `expected admin bypass 200 for null-owner template; got ${r.body.error?.code}`);
  assert.equal(runInsertCount, 1, 'run INSERT must be issued for admin with shared template');
});

it('allows admin to run with a foreign-owned template (admin bypass)', async () => {
  recipeRow = makeRecipe();
  stepsRows = [{ id: 's1', sequence: 1 }];
  templateRow = { owner_id: 'some-other-user' }; // foreign to the admin
  currentRole = 'admin';
  currentUserId = 'admin-user';

  const r = await post({ recipe_id: 'r1', payload: {}, template_id: 'tpl-foreign' });

  assert.equal(r.status, 200, `expected admin bypass 200; got ${r.body.error?.code}`);
  assert.equal(runInsertCount, 1, 'run INSERT must be issued for admin bypass');
});

it('returns 403 TEMPLATE_FORBIDDEN when template_id does not exist (fail-closed)', async () => {
  recipeRow = makeRecipe();
  stepsRows = [];
  templateRow = null; // not found in DB

  const r = await post({ recipe_id: 'r1', payload: {}, template_id: 'nonexistent-tpl' });

  assert.equal(r.status, 403, `expected 403 for missing template; got ${r.status}`);
  assert.equal(r.body.error.code, 'TEMPLATE_FORBIDDEN');
  assert.equal(runInsertCount, 0);
});

// ── P1 lock: started_at stamped via NOW(), no ISO-8601 string bound as a param ──

it('P1: INSERT uses NOW() for started_at — no ISO-8601 string bound as a DATETIME param', async () => {
  recipeRow = makeRecipe();
  stepsRows = [{ id: 's1', sequence: 1 }];

  const r = await post({ recipe_id: 'r1', payload: {} });

  assert.equal(r.status, 200, `expected 200; got ${r.body.error?.code}`);
  assert.equal(runInsertCount, 1, 'INSERT must be issued');
  assert.ok(lastRunInsertSql, 'INSERT SQL must be captured');
  assert.match(lastRunInsertSql, /NOW\(\)/, 'INSERT SQL must contain NOW() for started_at');
  // No ISO-8601 string (YYYY-MM-DDTHH:mm:ss.sssZ) must appear as a bound param
  const isoPattern = /\dT\d.*Z/;
  assert.ok(
    !(lastRunInsertParams || []).some((v) => typeof v === 'string' && isoPattern.test(v)),
    'no ISO-8601 timestamp must be bound as a param in the run INSERT (use NOW() instead)',
  );
});

// ── P2 lock: mode defaults to 'create', never null ──────────────────────────────

it("P2: mode defaults to 'create' when omitted — prevents null into NOT-NULL ENUM col", async () => {
  recipeRow = makeRecipe();
  stepsRows = [{ id: 's1', sequence: 1 }];

  // Omit mode entirely from the body
  const r = await post({ recipe_id: 'r1', payload: {} });

  assert.equal(r.status, 200, `expected 200; got ${r.body.error?.code}`);
  assert.equal(runInsertCount, 1, 'INSERT must be issued');
  assert.equal(lastRunInsert.mode, 'create',
    "mode must default to 'create' when omitted (prevents NULL into NOT-NULL ENUM)");
});

it("P2: mode='update' from request body is passed through unchanged", async () => {
  recipeRow = makeRecipe();
  stepsRows = [{ id: 's1', sequence: 1 }];

  const r = await post({ recipe_id: 'r1', payload: {}, mode: 'update' });

  assert.equal(r.status, 200, `expected 200; got ${r.body.error?.code}`);
  assert.equal(runInsertCount, 1, 'INSERT must be issued');
  assert.equal(lastRunInsert.mode, 'update', "mode='update' must be passed through");
});

it("P2: any unknown mode value is coerced to 'create' (defensive)", async () => {
  recipeRow = makeRecipe();
  stepsRows = [{ id: 's1', sequence: 1 }];

  const r = await post({ recipe_id: 'r1', payload: {}, mode: 'invalid-value' });

  assert.equal(r.status, 200, `expected 200; got ${r.body.error?.code}`);
  assert.equal(runInsertCount, 1, 'INSERT must be issued');
  assert.equal(lastRunInsert.mode, 'create',
    "unknown mode must be coerced to 'create'");
});

// ── code_version snapshot ─────────────────────────────────────────────────────

it('snapshots the recipe code_version onto the run INSERT', async () => {
  recipeRow = makeRecipe({ code_version: 5 });
  stepsRows = [{ id: 's1', sequence: 1 }];

  const r = await post({ recipe_id: 'r1', payload: {}, mode: 'create' });

  assert.equal(r.status, 200, `expected 200; got ${r.body.error?.code}`);
  assert.equal(runInsertCount, 1, 'INSERT must be issued exactly once');
  assert.ok(/code_version/.test(lastRunInsertSql), 'the INSERT must name code_version');
  assert.equal(lastRunInsert.code_version, 5, 'the run must carry the recipe code_version');
});

it('carries code_version=null when the recipe has none (pre-feature recipe)', async () => {
  recipeRow = makeRecipe(); // no code_version field
  stepsRows = [{ id: 's1', sequence: 1 }];

  const r = await post({ recipe_id: 'r1', payload: {}, mode: 'create' });

  assert.equal(r.status, 200);
  assert.strictEqual(lastRunInsert.code_version, null, 'absent code_version → null snapshot');
});

it('retries the run INSERT without code_version on a no-ALTER DB (errno 1054)', async () => {
  recipeRow = makeRecipe({ code_version: 3 });
  stepsRows = [{ id: 's1', sequence: 1 }];
  simulateMissingRunCodeVersion = true;

  const r = await post({ recipe_id: 'r1', payload: {}, mode: 'create' });

  assert.equal(r.status, 200, `a missing code_version column must not fail the run; got ${r.body.error?.code}`);
  // The first INSERT (with code_version) threw 1054 before counting; the retry
  // (without code_version) is the one that lands.
  assert.equal(runInsertCount, 1, 'exactly one INSERT lands (the fallback)');
  assert.ok(!/code_version/.test(lastRunInsertSql), 'the landed INSERT must omit code_version');
});

// ── input_snapshot: what the operator entered, recorded on the run row ────────

const { MAX_RUN_INPUT_SNAPSHOT_BYTES } = require('../../src/edge/routes/app/flow-recipe-runs/serializer');

// The identity half holds `blueprint_fields.id` / `hierarchy_nodes.id` values —
// CHAR(36), UUID-defaulted — and the write boundary checks the shape, because
// that half is the one stored unmasked. Readable stand-ins that are still UUIDs.
const id = (n) => `${String(n).padStart(8, '0')}-0000-4000-8000-000000000000`;
const FIELD_ID = { site_name: id(1), turbine_count: id(2), total_kw: id(3), api_key: id(4) };
const BLUEPRINT_ID = id(90);

const snapshotDoc = (over = {}) => JSON.stringify({
  entered: { site_name: 'north', turbine_count: '12' },
  computed: { total_kw: '4200' },
  fields: {
    site_name: FIELD_ID.site_name,
    turbine_count: FIELD_ID.turbine_count,
    total_kw: FIELD_ID.total_kw,
  },
  blueprint_id: BLUEPRINT_ID,
  variant_id: null,
  ...over,
});
const SNAPSHOT = snapshotDoc();

it('the server one-shot path records what the operator entered on the run row', async () => {
  // client_orchestration omitted → the JS-free recipe the one-shot server
  // orchestrator runs. It reaches run-begin through the same S2S call.
  recipeRow = makeRecipe();
  stepsRows = [{ id: 's1', sequence: 1 }];
  templateRow = { owner_id: 'u1' };

  const r = await post({ recipe_id: 'r1', payload: {}, input_snapshot: SNAPSHOT, template_id: 'tpl1' });

  assert.equal(r.status, 200);
  assert.equal(runInsertCount, 1);
  assert.deepEqual(JSON.parse(lastRunInsert.input_snapshot), JSON.parse(SNAPSHOT),
    'the one-shot path must record the entered and computed values');
  assert.equal(r.body.data.input_snapshot_notice, null, 'nothing to tell the operator on the ordinary path');
});

it('the browser-chain path records it too, for a recipe carrying per-step JS', async () => {
  // The path a recipe with per-step code is FORCED onto: the one-shot
  // orchestrator refuses it, so if only that path captured, the recipes most
  // worth reading back would be the ones with nothing recorded.
  recipeRow = makeRecipe();
  stepsRows = [{ id: 's1', sequence: 1, step_type: 'api', before_code: 'return { outputs: {} }', after_code: null }];
  templateRow = { owner_id: 'u1' };

  const r = await post({
    recipe_id: 'r1', payload: {}, input_snapshot: SNAPSHOT,
    template_id: 'tpl1', client_orchestration: true,
  });

  assert.equal(r.status, 200);
  assert.equal(r.body.data.requires_client_orchestration, true,
    'fixture must be a recipe that only the browser chain can run');
  assert.equal(runInsertCount, 1);
  assert.deepEqual(JSON.parse(lastRunInsert.input_snapshot), JSON.parse(SNAPSHOT),
    'the browser-chain path must record the same document');
});

it('records the snapshot on the INSERT itself, while the run is still partial', async () => {
  // The reason it is not a later update: a run that fails mid-chain never
  // reaches finalize. The statement that creates the row is the one that must
  // carry the snapshot, and the row it creates is not yet a finished run.
  recipeRow = makeRecipe();
  stepsRows = [{ id: 's1', sequence: 1 }];

  await post({ recipe_id: 'r1', payload: {}, input_snapshot: SNAPSHOT });

  assert.match(lastRunInsertSql, /INSERT INTO `fmb_flow_recipe_runs`/i);
  assert.match(lastRunInsertSql, /\binput_snapshot\b/,
    'the creating INSERT must name input_snapshot');
  assert.equal(lastRunInsert.status, 'partial',
    'the snapshot lands before any step has run');
  assert.ok(lastRunInsertParams.includes(SNAPSHOT),
    'the snapshot must be a bound parameter of that same INSERT');
});

it('the INSERT names exactly the columns the shared declaration lists, and no others', async () => {
  // Ties the arrays the schema-parity test checks against table-ddls.js to the
  // SQL this route actually emits. Without this the parity test proves only that
  // three exported arrays are well-named.
  const {
    RUN_ROW_BASE_COLUMNS, RUN_ROW_ADDITIVE_COLUMNS, RUN_ROW_SQL_COLUMNS,
  } = require('../../src/edge/lib/flow-run-insert');
  recipeRow = makeRecipe();
  stepsRows = [{ id: 's1', sequence: 1 }];

  await post({ recipe_id: 'r1', payload: {}, input_snapshot: SNAPSHOT });

  const named = lastRunInsertSql
    .match(/INSERT INTO `fmb_flow_recipe_runs` \(([^)]+)\)/i)[1]
    .split(',').map((c) => c.trim().replace(/`/g, ''));
  assert.deepEqual(
    named,
    [...RUN_ROW_BASE_COLUMNS, ...RUN_ROW_ADDITIVE_COLUMNS, ...RUN_ROW_SQL_COLUMNS],
    'the emitted INSERT must be built from the declared column lists, in that order',
  );
});

it('masks a secret-named entered value before the snapshot reaches the row', async () => {
  recipeRow = makeRecipe();
  stepsRows = [{ id: 's1', sequence: 1 }];

  await post({
    recipe_id: 'r1',
    payload: {},
    input_snapshot: snapshotDoc({
      entered: { site_name: 'north', api_key: 'sk-live-1' },
      computed: {},
      fields: { site_name: FIELD_ID.site_name, api_key: FIELD_ID.api_key },
    }),
  });

  const stored = JSON.parse(lastRunInsert.input_snapshot);
  assert.equal(stored.entered.api_key, '****', 'a secret-named entered value must not be stored verbatim');
  assert.equal(stored.entered.site_name, 'north');
  // THE HALF NOBODY LOOKED AT. This fixture already named a secret field and
  // recorded its id, and the assertions above walked past the id — so masking
  // the whole document, id map included, turned `api_key`'s id into '****' and
  // two reviews read the change without seeing it. A field id is not a secret;
  // it is the entire mechanism that tells a renamed field from a reused key,
  // and it is needed most for exactly the fields worth masking.
  assert.equal(stored.fields.api_key, FIELD_ID.api_key,
    'the stable field id must survive masking, or the row cannot say which field this was');
  assert.equal(stored.fields.site_name, FIELD_ID.site_name);
});

// CHANGED BEHAVIOUR: a capture whose field ids are not identifiers used to
// refuse the whole request. It now degrades, for the same reason the oversized
// case does — see below, and the block above `fieldIdProblem`. The premise of
// the refusal was that such an id could not have been produced by this
// application, and nothing enforces that; if one ever landed in a blueprint, the
// refusal would have failed EVERY dispatch from it with no operator lever.
it('dispatches the run when a field id is not an identifier, and stores none of it', async () => {
  // The other side of leaving that half unmasked: `fields` was checked only as
  // "a map of strings", so this document — a valid capture in every other
  // respect — parked a credential in the one half the serializer deliberately
  // stores verbatim, on a route any authenticated user can reach. Degrading does
  // not weaken that: the value is still refused, and what lands on the row is a
  // marker with no client text in it at all.
  recipeRow = makeRecipe();
  stepsRows = [{ id: 's1', sequence: 1 }];
  runInsertCount = 0;

  const r = await post({
    recipe_id: 'r1',
    payload: {},
    input_snapshot: snapshotDoc({
      entered: { site_name: 'north' },
      computed: {},
      fields: { note: 'sk-live-SECRET' },
    }),
  });

  assert.equal(r.status, 200, `the run must still be dispatched; got ${JSON.stringify(r.body).slice(0, 200)}`);
  assert.equal(runInsertCount, 1, 'the run row is created');
  const stored = JSON.parse(lastRunInsert.input_snapshot);
  assert.deepEqual(stored, { not_captured: 'unreadable_identity' },
    'the row states a capture was attempted and dropped, and carries no client text');
  assert.ok(!lastRunInsert.input_snapshot.includes('sk-live-SECRET'),
    'nothing of the refused document reaches the column');
  assert.ok(!JSON.stringify(r.body).includes('sk-live-SECRET'),
    'and the response must not echo the value it refused either');

  const notice = r.body.data.input_snapshot_notice;
  assert.ok(notice, 'the operator must be told, or the drop is silent');
  assert.match(notice, /was dispatched/, 'it must say the run happened');
  assert.doesNotMatch(notice, /input_snapshot|column/, 'no schema vocabulary reaches the operator');
});

it('still refuses a scope id that is not an identifier by degrading, not by failing the run', async () => {
  // blueprint_id and variant_id travel in the same unmasked half and take the
  // same route. Pinned separately because they are checked by a different
  // function, and an earlier round closed one of the two and not the other.
  recipeRow = makeRecipe();
  stepsRows = [{ id: 's1', sequence: 1 }];
  runInsertCount = 0;

  const r = await post({
    recipe_id: 'r1',
    payload: {},
    input_snapshot: snapshotDoc({ variant_id: 'sk-live-SECRET' }),
  });

  assert.equal(r.status, 200);
  assert.equal(runInsertCount, 1);
  assert.deepEqual(JSON.parse(lastRunInsert.input_snapshot), { not_captured: 'unreadable_identity' });
  assert.ok(!JSON.stringify(r.body).includes('sk-live-SECRET'));
});

// CHANGED BEHAVIOUR: an oversized snapshot used to refuse the whole request, so
// no run row was created and nothing was dispatched. It now degrades — this file
// states two functions away that losing the capture is degraded and losing the
// run is not, and blocking a dispatch to protect an audit row contradicted it.
it('dispatches the run when the snapshot is oversized, and records that the capture was dropped', async () => {
  recipeRow = makeRecipe();
  stepsRows = [{ id: 's1', sequence: 1 }];
  const oversized = snapshotDoc({ entered: { notes: 'x'.repeat(MAX_RUN_INPUT_SNAPSHOT_BYTES + 1) } });

  const r = await post({ recipe_id: 'r1', payload: {}, input_snapshot: oversized });

  assert.equal(r.status, 200, `the run must still be created; got ${JSON.stringify(r.body).slice(0, 200)}`);
  assert.equal(runInsertCount, 1, 'the run row is created');
  const stored = JSON.parse(lastRunInsert.input_snapshot);
  assert.equal(stored.not_captured, 'too_large',
    'the row must say a capture was attempted and dropped — NULL would read as never attempted');
  assert.equal(stored.limit, MAX_RUN_INPUT_SNAPSHOT_BYTES);
  assert.ok(stored.bytes > MAX_RUN_INPUT_SNAPSHOT_BYTES);
  assert.equal(stored.entered, undefined, 'nothing of the oversized document is stored');
});

it('tells the operator the capture was dropped, in a sentence about the run and not about a column', async () => {
  recipeRow = makeRecipe();
  stepsRows = [{ id: 's1', sequence: 1 }];
  const oversized = snapshotDoc({ entered: { notes: 'x'.repeat(MAX_RUN_INPUT_SNAPSHOT_BYTES + 1) } });

  const r = await post({ recipe_id: 'r1', payload: {}, input_snapshot: oversized });

  const notice = r.body.data.input_snapshot_notice;
  assert.ok(notice, 'the response must carry the notice, or the drop is silent');
  assert.match(notice, /was dispatched/, 'it must say the run happened');
  assert.match(notice, /\d+ KB/, 'it must give the operator a size they can act on');
  assert.doesNotMatch(notice, /input_snapshot|column|bytes/, 'no schema vocabulary reaches the operator');
});

it('refuses a snapshot whose shape it cannot read, and creates no run row', async () => {
  // A document this server cannot read was not built by this application, so
  // there is no operator condition to be lenient about — unlike the size case.
  recipeRow = makeRecipe();
  stepsRows = [{ id: 's1', sequence: 1 }];

  const r = await post({ recipe_id: 'r1', payload: {}, input_snapshot: 'api_key=sk-live-1' });

  assert.equal(r.status, 400);
  assert.equal(r.body.error.code, 'INVALID_RUN_INPUT_SNAPSHOT');
  assert.equal(runInsertCount, 0);
});

it('records a client-stated non-capture verbatim, so the reason survives on the row', async () => {
  recipeRow = makeRecipe();
  stepsRows = [{ id: 's1', sequence: 1 }];

  const r = await post({
    recipe_id: 'r1', payload: {},
    input_snapshot: JSON.stringify({ not_captured: 'outputs_stale' }),
  });

  assert.equal(r.status, 200);
  assert.deepEqual(JSON.parse(lastRunInsert.input_snapshot), { not_captured: 'outputs_stale' });
});

it('a DB missing only input_snapshot still records the run and keeps code_version', async () => {
  // The migration entry is additive with severity 'warning', which claims a
  // skipped ALTER degrades rather than fails. This is that claim: the run is
  // still recorded, and the OTHER additive column is not collateral damage.
  recipeRow = makeRecipe({ code_version: 7 });
  stepsRows = [{ id: 's1', sequence: 1 }];
  missingRunColumns = new Set(['input_snapshot']);

  const r = await post({ recipe_id: 'r1', payload: {}, input_snapshot: SNAPSHOT });

  assert.equal(r.status, 200, `a missing input_snapshot column must not fail the run; got ${JSON.stringify(r.body)}`);
  assert.equal(runInsertCount, 1, 'exactly one INSERT lands (the fallback)');
  assert.ok(!/\binput_snapshot\b/.test(lastRunInsertSql), 'the landed INSERT must omit input_snapshot');
  assert.equal(lastRunInsert.code_version, 7,
    'the column the DB does have must survive the fallback');
});

it('binds NULL when no snapshot is supplied, rather than failing the run', async () => {
  recipeRow = makeRecipe();
  stepsRows = [{ id: 's1', sequence: 1 }];

  const r = await post({ recipe_id: 'r1', payload: {} });

  assert.equal(r.status, 200);
  assert.equal(lastRunInsert.input_snapshot, null);
});

// NULL MEANS NOT SUPPLIED, AND ONLY THAT. These three pin the boundary between
// the column's three states. A type guard here used to coerce anything that was
// not a non-empty string to null, which sent a malformed snapshot straight past
// the write boundary: the run returned 200 with no capture and no notice, and
// the row then claimed the strongest of the three states — never attempted —
// about an attempt that was actually made and thrown away. This is the route
// where the operator would never learn it, because unlike the direct write path
// the response they see is a successful run.
it('refuses a snapshot sent as an object rather than dropping it and reporting success', async () => {
  recipeRow = makeRecipe();
  stepsRows = [{ id: 's1', sequence: 1 }];

  const r = await post({
    recipe_id: 'r1', payload: {},
    input_snapshot: { entered: { api_key: 'sk-live-1' }, computed: {} },
  });

  assert.equal(r.status, 400, `a non-string snapshot must be refused; got ${JSON.stringify(r.body).slice(0, 200)}`);
  assert.equal(r.body.error.code, 'INVALID_RUN_INPUT_SNAPSHOT');
  assert.equal(runInsertCount, 0, 'no run row, and in particular no row claiming nothing was attempted');
});

it('refuses an empty-string snapshot rather than storing the NULL that reads as never attempted', async () => {
  recipeRow = makeRecipe();
  stepsRows = [{ id: 's1', sequence: 1 }];

  const r = await post({ recipe_id: 'r1', payload: {}, input_snapshot: '' });

  assert.equal(r.status, 400);
  assert.equal(r.body.error.code, 'INVALID_RUN_INPUT_SNAPSHOT');
  assert.equal(runInsertCount, 0);
});

it('still binds NULL for an explicit null, which is a caller saying it has none', async () => {
  // The other side of the same boundary: a caller that states it captured
  // nothing is not malformed, and must not be refused.
  recipeRow = makeRecipe();
  stepsRows = [{ id: 's1', sequence: 1 }];

  const r = await post({ recipe_id: 'r1', payload: {}, input_snapshot: null });

  assert.equal(r.status, 200);
  assert.equal(lastRunInsert.input_snapshot, null);
});

// ── Delegated dispatch ───────────────────────────────────────────────────────
//
// Dispatch is the guarded action. These cases are the ones the grant changed;
// every ownership case above is unchanged and still passes, which is the point
// — delegation widened who may dispatch and moved nothing else.
//
// The grant lookup here is a stub, so what these establish is that the route
// ASKS the question at the right moment and acts on the answer. Whether the
// question's SQL answers correctly is settled against a real database in
// tests/integration/delegated-grants-predicate-real-db.test.js.

it('a grantee dispatches a template they do not own', async () => {
  recipeRow = makeRecipe();
  stepsRows = [{ id: 's1', sequence: 1 }];
  templateRow = { owner_id: 'other-user', blueprint_id: 'bp-1' };
  grantsTablePresent = true;
  grantRows = [{ granted: 1 }];

  const r = await post({ recipe_id: 'r1', payload: {}, template_id: 'tpl-foreign' });

  assert.equal(r.status, 200, `expected a grantee to dispatch; got ${r.body.error?.code}`);
  assert.equal(runInsertCount, 1);
});

it('a caller with no grant is still refused, and no run row is created', async () => {
  recipeRow = makeRecipe();
  stepsRows = [{ id: 's1', sequence: 1 }];
  templateRow = { owner_id: 'other-user', blueprint_id: 'bp-1' };
  grantsTablePresent = true;
  grantRows = [];

  const r = await post({ recipe_id: 'r1', payload: {}, template_id: 'tpl-foreign' });

  assert.equal(r.status, 403);
  assert.equal(r.body.error.code, 'TEMPLATE_FORBIDDEN');
  assert.equal(runInsertCount, 0, 'a refused dispatch must leave no partial run behind');
});

it('a shared template is still refused, grant or no grant', async () => {
  // A record nobody owns is reached by no delegated arm — and the grant row is
  // PRESENT here on purpose. With no grant this case says nothing about
  // delegation: it would pass on a build where the arm reached unowned records,
  // which is the state this test was written to forbid and did not.
  recipeRow = makeRecipe();
  stepsRows = [{ id: 's1', sequence: 1 }];
  templateRow = { owner_id: null, blueprint_id: 'bp-1' };
  grantsTablePresent = true;
  grantRows = [{ granted: 1 }];

  const r = await post({ recipe_id: 'r1', payload: {}, template_id: 'tpl-shared' });

  assert.equal(r.status, 403, `a grant reached a record nobody owns; got ${JSON.stringify(r.body).slice(0, 200)}`);
  assert.equal(r.body.error.code, 'TEMPLATE_FORBIDDEN');
  assert.equal(runInsertCount, 0, 'a refused dispatch must leave no partial run behind');
});

it('a blueprint owner dispatches a record under their blueprint, with no grant anywhere', async () => {
  // The fourth part of the rule the user stated: a blueprint's owner may
  // dispatch every record under that blueprint. Without it they are the only
  // party who can hand out something they can never use — and they cannot even
  // grant it to themselves, because granting to yourself is refused.
  //
  // The grants table is deliberately ABSENT here: this reach reads the
  // hierarchy, and it must not arrive with an optional table.
  recipeRow = makeRecipe();
  stepsRows = [{ id: 's1', sequence: 1 }];
  templateRow = { owner_id: 'someone-else', blueprint_id: 'bp-1' };
  grantsTablePresent = false;
  blueprintOwnerId = 'u1';

  const r = await post({ recipe_id: 'r1', payload: {}, template_id: 'tpl-under-my-blueprint' });

  assert.equal(r.status, 200, `a blueprint owner was refused; got ${JSON.stringify(r.body).slice(0, 200)}`);
  assert.equal(runInsertCount, 1);
});

it('and reaches nothing under a blueprint they do not own', async () => {
  recipeRow = makeRecipe();
  stepsRows = [{ id: 's1', sequence: 1 }];
  templateRow = { owner_id: 'someone-else', blueprint_id: 'bp-1' };
  grantsTablePresent = false;
  blueprintOwnerId = 'a-different-person';

  const r = await post({ recipe_id: 'r1', payload: {}, template_id: 'tpl-elsewhere' });

  assert.equal(r.status, 403);
  assert.equal(r.body.error.code, 'TEMPLATE_FORBIDDEN');
});

it('a blueprint owner does not reach a record nobody owns either', async () => {
  // The same boundary the grant arm stops at, applied to the arm that was added
  // beside it: an unowned record is nobody's to delegate and nobody's to reach.
  recipeRow = makeRecipe();
  stepsRows = [{ id: 's1', sequence: 1 }];
  templateRow = { owner_id: null, blueprint_id: 'bp-1' };
  grantsTablePresent = false;
  blueprintOwnerId = 'u1';

  const r = await post({ recipe_id: 'r1', payload: {}, template_id: 'tpl-shared' });

  assert.equal(r.status, 403);
  assert.equal(r.body.error.code, 'TEMPLATE_FORBIDDEN');
  assert.equal(runInsertCount, 0);
});

it('an owner never pays for a permission lookup of its own', async () => {
  // Ownership is the common case and answering it costs no statement. Asserted
  // rather than assumed: a permission read on every dispatch would be a cost
  // nobody asked for, and one more thing to fail.
  //
  // WHAT MOVED, AND WHAT DID NOT. The statement that creates the run now
  // carries the access predicate, so the grants table is NAMED on an owner's
  // path — inside the one statement that was always going to be issued, so
  // that no revocation can land between the answer and the write. What is
  // forbidden here is a lookup of its OWN: that is the round trip, and the
  // extra thing to fail. Both halves are asserted, because a build that simply
  // dropped the check would satisfy the first alone.
  recipeRow = makeRecipe();
  stepsRows = [{ id: 's1', sequence: 1 }];
  templateRow = { owner_id: 'u1', blueprint_id: 'bp-1' };
  grantsTablePresent = true;
  let grantLookups = 0;
  grantRows = [];
  const origQuery = conn.query;
  conn.query = async function countingQuery(sql, params) {
    if (/^\s*SELECT/i.test(sql) && /FROM `fmb_delegated_grants`/.test(sql)) grantLookups += 1;
    return origQuery.call(this, sql, params);
  };
  try {
    const r = await post({ recipe_id: 'r1', payload: {}, template_id: 'tpl-own' });
    assert.equal(r.status, 200);
    assert.equal(grantLookups, 0, 'an owner was made to pay for a permission lookup');
    assert.match(
      lastRunInsertSql, /fmb_delegated_grants/,
      'the check did not move onto the INSERT — it disappeared',
    );
  } finally {
    conn.query = origQuery;
  }
});

it('a database with no grants table dispatches exactly as it did before', async () => {
  recipeRow = makeRecipe();
  stepsRows = [{ id: 's1', sequence: 1 }];
  templateRow = { owner_id: 'other-user', blueprint_id: 'bp-1' };
  grantsTablePresent = false;
  grantRows = [{ granted: 1 }]; // would match, if the table were there to read

  const r = await post({ recipe_id: 'r1', payload: {}, template_id: 'tpl-foreign' });

  assert.equal(r.status, 403, 'a missing grants table must fall back to ownership, not open up');
  assert.equal(r.body.error.code, 'TEMPLATE_FORBIDDEN');
});

// ── The permission the run row is created through ────────────────────────────
//
// The gate above is asked before the payload is serialized and the steps are
// read; the answer can change in that time. These cases are about the SECOND
// asking, which is part of the INSERT itself, and they assert its shape and the
// route's handling of its answer. A stub cannot evaluate the predicate, so
// whether it decides correctly — and whether it really closes the window — is
// settled in tests/integration/flow-run-writeback-revocation-real-db.test.js.

it('creates the run through the permission, not merely after it', async () => {
  recipeRow = makeRecipe();
  stepsRows = [{ id: 's1', sequence: 1 }];
  templateRow = { owner_id: 'other-user', blueprint_id: 'bp-1' };
  grantsTablePresent = true;
  grantRows = [{ granted: 1 }];

  const r = await post({ recipe_id: 'r1', payload: {}, template_id: 'tpl-foreign' });

  assert.equal(r.status, 200, `expected a grantee to dispatch; got ${r.body.error?.code}`);
  // The row comes from a source that has to match, not from a VALUES list that
  // always does.
  assert.match(lastRunInsertSql, /INSERT INTO `fmb_flow_recipe_runs` \([^)]+\) SELECT /i);
  assert.match(lastRunInsertSql, /FROM `fmb_user_templates` ut WHERE ut\.`id` = \?/);
  assert.ok(!/\bVALUES\b/i.test(lastRunInsertSql), 'an unconditional VALUES list creates the row regardless');
  // All three arms of the one rule, and the owner gate outside them.
  assert.match(lastRunInsertSql, /ut\.`owner_id` = \?/, 'the owner arm');
  assert.match(lastRunInsertSql, /ut\.`owner_id` IS NOT NULL/, 'no arm reaches a record nobody owns');
  assert.match(lastRunInsertSql, /fmb_hierarchy_nodes` hnw/, "the blueprint owner's arm");
  assert.match(lastRunInsertSql, /fmb_delegated_grants` dgt/, 'the template-grant arm');
  assert.match(lastRunInsertSql, /fmb_delegated_grants` dgb/, 'the blueprint-grant arm');
  // Bound to the caller once per arm, after the column values — never to
  // anything the request body supplied.
  assert.deepEqual(
    lastRunInsertParams.slice(-5), ['tpl-foreign', 'u1', 'u1', 'u1', 'u1'],
    'the predicate must bind the template and the caller, once per arm',
  );
});

it('a run whose permission no longer matches is refused, not reported as begun', async () => {
  // What a database answers when the access is gone by the time the row would
  // be written: the statement runs and matches nothing. The route must read
  // that as the refusal it is — with no run id handed back, because there is no
  // run, and nothing for the caller to dispatch on the strength of.
  recipeRow = makeRecipe();
  stepsRows = [{ id: 's1', sequence: 1 }];
  templateRow = { owner_id: 'other-user', blueprint_id: 'bp-1' };
  grantsTablePresent = true;
  grantRows = [{ granted: 1 }];
  gatedInsertMatchesNothing = true;

  const r = await post({ recipe_id: 'r1', payload: {}, template_id: 'tpl-foreign' });

  assert.equal(r.status, 403, `expected a refusal; got ${JSON.stringify(r.body).slice(0, 200)}`);
  assert.equal(r.body.error.code, 'TEMPLATE_FORBIDDEN');
  assert.equal(r.body.data, null, 'a payload was handed out for a run that does not exist');
});

it('an administrator is not gated, because their permission is not a row', async () => {
  // Gating them on the access predicate would refuse them the unowned records
  // they are the only party allowed to dispatch — which is what this fixture is.
  recipeRow = makeRecipe();
  stepsRows = [{ id: 's1', sequence: 1 }];
  templateRow = { owner_id: null, blueprint_id: 'bp-1' };
  currentRole = 'admin';
  grantsTablePresent = true;

  const r = await post({ recipe_id: 'r1', payload: {}, template_id: 'tpl-shared' });

  assert.equal(r.status, 200, `an administrator was refused; got ${r.body.error?.code}`);
  assert.equal(runInsertCount, 1);
  assert.match(lastRunInsertSql, /\bVALUES\b/i, 'an administrator must not be gated on the access predicate');
});

it('a run with no record is not gated either — there is nothing to guard', async () => {
  recipeRow = makeRecipe();
  stepsRows = [{ id: 's1', sequence: 1 }];
  grantsTablePresent = true;

  const r = await post({ recipe_id: 'r1', payload: {} });

  assert.equal(r.status, 200);
  assert.match(lastRunInsertSql, /\bVALUES\b/i);
  assert.ok(!/fmb_user_templates/.test(lastRunInsertSql), 'a template-less run named a template');
});

it('drops the two grant arms on a database that has no grants table', async () => {
  // The gate is the statement every dispatch now depends on, so it must not be
  // the one statement that cannot run where the optional table was never
  // created. The blueprint-owner arm reads the hierarchy and stays.
  recipeRow = makeRecipe();
  stepsRows = [{ id: 's1', sequence: 1 }];
  templateRow = { owner_id: 'someone-else', blueprint_id: 'bp-1' };
  grantsTablePresent = false;
  blueprintOwnerId = 'u1';

  const r = await post({ recipe_id: 'r1', payload: {}, template_id: 'tpl-under-my-blueprint' });

  assert.equal(r.status, 200, `a blueprint owner was refused; got ${r.body.error?.code}`);
  assert.ok(!/fmb_delegated_grants/.test(lastRunInsertSql), 'the gate named a table this database does not have');
  assert.match(lastRunInsertSql, /fmb_hierarchy_nodes` hnw/, "the blueprint owner's arm must survive");
  assert.deepEqual(
    lastRunInsertParams.slice(-3), ['tpl-under-my-blueprint', 'u1', 'u1'],
    'one bind per surviving arm, and no orphaned placeholder',
  );
});

// ── The trail a dispatch leaves ──────────────────────────────────────────────

it('records who dispatched the record, and which run it produced', async () => {
  recipeRow = makeRecipe();
  stepsRows = [{ id: 's1', sequence: 1 }];
  templateRow = { owner_id: 'u1', blueprint_id: 'bp-1' };
  activityTablePresent = true;

  const r = await post({ recipe_id: 'r1', payload: {}, template_id: 'tpl-own' });

  assert.equal(r.status, 200);
  assert.equal(activityInserts.length, 1, 'no trail row was written for a dispatch');
  const [, templateId, actorId, action, metadata] = activityInserts[0].params;
  assert.equal(templateId, 'tpl-own');
  assert.equal(actorId, 'u1');
  assert.equal(action, 'flow.dispatched');
  const doc = JSON.parse(metadata);
  assert.equal(doc.run_id, r.body.data.run_id);
  assert.equal(doc.recipe_id, 'r1');
});

it('records nothing when there is no record to attach it to', async () => {
  // The trail is per-record. A dispatch with no record still has its entry in
  // the platform's own dispatch log, which is where that coverage lives.
  recipeRow = makeRecipe();
  stepsRows = [{ id: 's1', sequence: 1 }];
  activityTablePresent = true;

  const r = await post({ recipe_id: 'r1', payload: {} });

  assert.equal(r.status, 200);
  assert.equal(activityInserts.length, 0);
});

it('a failing trail write does not fail the dispatch it was recording', async () => {
  // A dispatch cannot be taken back, so a bookkeeping failure must never be
  // able to turn a dispatch that happened into a request that reports failure.
  recipeRow = makeRecipe();
  stepsRows = [{ id: 's1', sequence: 1 }];
  templateRow = { owner_id: 'u1', blueprint_id: 'bp-1' };
  activityTablePresent = true;
  activityInsertError = Object.assign(new Error('trail gone'), { errno: 1146 });

  const r = await post({ recipe_id: 'r1', payload: {}, template_id: 'tpl-own' });

  assert.equal(r.status, 200, 'a dropped trail row failed the dispatch');
  assert.ok(r.body.data.run_id, 'the run was not created');
  assert.equal(runInsertCount, 1);
});
