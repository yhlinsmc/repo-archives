/**
 * flow-recipes-code-version.test.js
 *
 * Boots the real flow-recipes router against a mocked pool and asserts the
 * generic CRUD factory's `codeVersioning` option, as mounted on flow_recipes:
 *
 *   - PUT that changes payload_transform_code → same-tx UPDATE with a
 *     code_version bump + an INSERT into flow_recipe_code_versions (action
 *     'update'), ordered begin < UPDATE < history-INSERT < commit.
 *   - PUT that keeps the same code / omits the column → no bump, no history row.
 *   - POST → seeds history v1 (action 'create') in the same tx.
 *   - Hard DELETE → history rows cleaned in the same tx.
 *   - No-ALTER DB (missing history table OR missing code_version column) → the
 *     core CRUD write still succeeds; versioning is skipped (no rollback).
 *
 * Harness mirrors flow-recipes-crud.test.js, adding per-query ordering capture
 * and configurable stored-row / column-set / degradation state.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../src/edge/db');

const OLD_CODE = 'return { a: 1 };';

// information_schema.COLUMNS result — includes code_version + payload_transform_code
// by default. A test can drop either to model a partial-migration DB.
function columnRows() {
  const cols = [
    'id', 'name', 'description', 'blueprint_id', 'owner_id', 'is_active',
    'status', 'approved_by', 'approved_at', 'review_note',
    'content_type',
    'consumed_output_keys', 'link_extract', 'external_id_extract',
    'created_at', 'updated_at',
  ];
  if (hasCodeColumn) cols.push('payload_transform_code');
  if (hasVersionColumn) cols.push('code_version');
  return cols.map((c) => ({ COLUMN_NAME: c }));
}

// ── Per-test mutable state (reset in beforeEach) ─────────────────────────────
let role;
let hasVersionColumn;      // false → columnSet omits code_version
let hasCodeColumn;         // false → columnSet omits payload_transform_code (gated out)
let preReadThrows1054;     // true → the FOR UPDATE pre-read throws (col missing)
let historyTableMissing;   // true → history INSERT/DELETE throws 1146 AND the TABLES probe reports absent
let storedRow;             // { code, version } returned by the pre-read
let approvalRow;           // pool.ro approval re-pend probe row
let stepRows;              // pool.ro pre-delete step probe rows
let conn;                  // shared recording connection (reset per test)
// The factory caches column-set + history-table probes per (db, table) for the
// process lifetime (schema is stable in production). Tests simulate DIFFERENT DB
// shapes in one process, so each test gets a unique db name to avoid cache bleed.
let dbSeq = 0;
let currentDb;

function makeRecipeRow(overrides = {}) {
  return {
    id: 'd0edcb09-2c66-4d79-8114-5c3e787de042', name: 'My Recipe', description: null,
    blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', owner_id: '5b729f1e-5c0b-447c-8144-3210469bc62c', is_active: 1,
    status: 'approved', approved_by: '5b729f1e-5c0b-447c-8144-3210469bc62c', approved_at: '2026-01-01 00:00:00',
    review_note: null, payload_transform_code: OLD_CODE,
    content_type: 'application/json', code_version: storedRow ? storedRow.version : 1,
    consumed_output_keys: null, link_extract: null, external_id_extract: null,
    created_at: '2026-01-01 00:00:00', updated_at: '2026-01-01 00:00:00',
    ...overrides,
  };
}

function badField(errno, code) {
  const e = new Error('degraded'); e.errno = errno; e.code = code; return e;
}

function makeConn() {
  const queries = [];
  let began = false; let committed = false; let rolledBack = false;
  return {
    queries,
    began: () => began,
    committed: () => committed,
    rolledBack: () => rolledBack,
    async beginTransaction() { began = true; queries.push({ sql: 'BEGIN' }); },
    async commit() { committed = true; queries.push({ sql: 'COMMIT' }); },
    async rollback() { rolledBack = true; queries.push({ sql: 'ROLLBACK' }); },
    async query(sql, params) {
      queries.push({ sql, params });
      if (/SELECT DATABASE\(\)/.test(sql)) return [{ db: currentDb }];
      if (/information_schema\.COLUMNS/i.test(sql)) return columnRows();
      // History-table presence probe (tableExistsInCurrentSchema) — absent when
      // historyTableMissing so the PUT bump decision degrades to a plain write.
      if (/information_schema\.TABLES/i.test(sql)) {
        const tbl = params && params[0];
        if (historyTableMissing && /flow_recipe_code_versions/.test(String(tbl))) return [];
        return [{ 1: 1 }];
      }
      if (/FROM `fmb_users`/.test(sql)) return [{ id: '5b729f1e-5c0b-447c-8144-3210469bc62c', name: 'Admin User' }];
      // parentOwnership chain lookup (editor POST/PUT). ^SELECT guards against
      // matching an UPDATE … AND EXISTS(SELECT 1 FROM `fmb_hierarchy_nodes` …).
      if (/^SELECT\b/i.test(sql.trim()) && /FROM `fmb_hierarchy_nodes`/.test(sql)) {
        return [{ owner_id: null }];
      }
      // codeVersioning pre-read (FOR UPDATE) — the value under test.
      if (/AS code.*AS version FROM `fmb_flow_recipes`/i.test(sql) && /FOR UPDATE/i.test(sql)) {
        if (preReadThrows1054) throw badField(1054, 'ER_BAD_FIELD_ERROR');
        return storedRow ? [{ code: storedRow.code, version: storedRow.version }] : [];
      }
      // The delete's entitlement read, which now runs BEFORE either lock so a
      // caller with no right to the row never makes the handler take one. This
      // fixture's requests are the admin's, whose scope clause is empty and whom
      // the DELETE below matches — so the row is there for both statements.
      if (/^SELECT id FROM `fmb_flow_recipes` WHERE id = \?/.test(sql.trim())) {
        return [{ id: params[0] }];
      }
      // GET-by-id / post-write re-read.
      if (/SELECT \* FROM `fmb_flow_recipes` WHERE id = \?/.test(sql)) {
        return [makeRecipeRow({ id: params[0] })];
      }
      if (/^INSERT INTO `fmb_flow_recipes`/i.test(sql.trim())) return { affectedRows: 1 };
      if (/^UPDATE `fmb_flow_recipes`/i.test(sql.trim())) return { affectedRows: 1 };
      if (/^DELETE FROM `fmb_flow_recipes`/i.test(sql.trim())) return { affectedRows: 1 };
      // History table INSERT / DELETE (the versioning side effect).
      if (/`fmb_flow_recipe_code_versions`/.test(sql)) {
        if (historyTableMissing) throw badField(1146, 'ER_NO_SUCH_TABLE');
        return { affectedRows: 1 };
      }
      return [];
    },
    release() {},
  };
}

const poolSpy = {
  ro: {
    async getConnection() { return conn; },
    async query(sql) {
      if (/FROM `fmb_flow_recipe_steps`/.test(sql)) return stepRows;
      // approval re-pend probe
      if (/FROM `fmb_flow_recipes`/.test(sql)) return approvalRow ? [approvalRow] : [];
      return [];
    },
  },
  rw: { async getConnection() { return conn; } },
};

require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: poolSpy, t: (name) => `fmb_${name}`, getDynamicPool: async () => poolSpy },
};

const router = require('../../src/edge/routes/app/flow-recipes');

let server; let baseUrl;
before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => {
    req.user = { id: role === 'editor' ? 'editor-1' : '5b729f1e-5c0b-447c-8144-3210469bc62c', role, email: 'a@x' };
    next();
  });
  app.use('/fr', router);
  server = http.createServer(app);
  await new Promise((r) => server.listen(0, r));
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});

after(async () => {
  await new Promise((r) => server.close(r));
  delete require.cache[dbKey];
});

beforeEach(() => {
  currentDb = `testdb_${++dbSeq}`;
  role = 'admin';
  hasVersionColumn = true;
  hasCodeColumn = true;
  preReadThrows1054 = false;
  historyTableMissing = false;
  storedRow = { code: OLD_CODE, version: 1 };
  approvalRow = {
    status: 'approved', payload_transform_code: OLD_CODE, content_type: 'application/json',
    runs_on: 'both', consumed_output_keys: null, link_extract: null, external_id_extract: null,
  };
  stepRows = [];
  conn = makeConn();
});

function req(method, path, body) {
  return new Promise((resolve, reject) => {
    const r = http.request(`${baseUrl}${path}`, { method, headers: { 'content-type': 'application/json' } }, (res) => {
      let raw = '';
      res.on('data', (c) => { raw += c; });
      res.on('end', () => resolve({ status: res.statusCode, body: raw ? JSON.parse(raw) : null }));
    });
    r.on('error', reject);
    if (body !== undefined) r.write(JSON.stringify(body));
    r.end();
  });
}

function idxOf(re) {
  return conn.queries.findIndex((q) => re.test(q.sql));
}

describe('flow_recipes codeVersioning — PUT changed code', () => {
  it('bumps code_version in the same UPDATE and appends an update history row, ordered begin<update<history<commit', async () => {
    const res = await req('PUT', '/fr/d0edcb09-2c66-4d79-8114-5c3e787de042', { payload_transform_code: 'return { a: 2 };' });
    assert.equal(res.status, 200);

    const updateCall = conn.queries.find((q) => /^UPDATE `fmb_flow_recipes`/i.test((q.sql || '').trim()));
    assert.ok(updateCall, 'a flow_recipes UPDATE must run');
    assert.ok(/`code_version` = \?/.test(updateCall.sql), 'the UPDATE must fold in the code_version bump');

    const historyCall = conn.queries.find((q) => /INSERT INTO `fmb_flow_recipe_code_versions`/i.test(q.sql || ''));
    assert.ok(historyCall, 'a history row must be inserted');
    // params: [id, recipe_id, version, code, created_by] with action literal 'update'
    assert.ok(/'update'/.test(historyCall.sql), 'history action must be update');
    assert.equal(historyCall.params[1], 'd0edcb09-2c66-4d79-8114-5c3e787de042', 'history fk = recipe id');
    assert.equal(historyCall.params[2], 2, 'history version = stored + 1');
    assert.equal(historyCall.params[3], 'return { a: 2 };', 'history code = new code');
    assert.equal(historyCall.params[4], '5b729f1e-5c0b-447c-8144-3210469bc62c', 'history created_by = requester');

    const iBegin = idxOf(/^BEGIN$/);
    const iUpdate = idxOf(/^UPDATE `fmb_flow_recipes`/i);
    const iHistory = idxOf(/INSERT INTO `fmb_flow_recipe_code_versions`/i);
    const iCommit = idxOf(/^COMMIT$/);
    assert.ok(iBegin >= 0 && iBegin < iUpdate, 'begin before update');
    assert.ok(iUpdate < iHistory, 'update before history insert');
    assert.ok(iHistory < iCommit, 'history insert before commit');
    assert.equal(conn.committed(), true);
  });
});

describe('flow_recipes codeVersioning — client-supplied version is server-owned', () => {
  it('POST ignores a client code_version — the create INSERT omits it (DDL default 1 stands)', async () => {
    const res = await req('POST', '/fr', {
      name: 'New', blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', payload_transform_code: 'return {};', code_version: 999,
    });
    assert.equal(res.status, 200);
    const insertCall = conn.queries.find((q) => /^INSERT INTO `fmb_flow_recipes`/i.test((q.sql || '').trim()));
    assert.ok(insertCall, 'recipe INSERT must run');
    assert.ok(!/code_version/.test(insertCall.sql), 'a client-supplied code_version must never reach the INSERT');
    // The v1 create history row is still the sole authority for the first version.
    const historyCall = conn.queries.find((q) => /INSERT INTO `fmb_flow_recipe_code_versions`/i.test(q.sql || ''));
    assert.ok(historyCall && /VALUES \(\?, \?, 1, /.test(historyCall.sql), 'history seeded at v1 regardless of body');
  });

  it('PUT ignores a client code_version with no code change — no bump, no history, no version write', async () => {
    const res = await req('PUT', '/fr/d0edcb09-2c66-4d79-8114-5c3e787de042', { code_version: 999, name: 'Renamed' });
    assert.equal(res.status, 200);
    const updateCall = conn.queries.find((q) => /^UPDATE `fmb_flow_recipes`/i.test((q.sql || '').trim()));
    assert.ok(updateCall, 'a rename UPDATE must run');
    assert.ok(!/`code_version` = \?/.test(updateCall.sql), 'client code_version must never be written');
    assert.ok(!conn.queries.some((q) => /INSERT INTO `fmb_flow_recipe_code_versions`/i.test(q.sql || '')), 'no history row on a non-code edit');
  });
});

describe('flow_recipes codeVersioning — explicit null clears a non-null code', () => {
  it('PUT payload_transform_code=null against a stored non-null code → bump + history row with code NULL', async () => {
    const res = await req('PUT', '/fr/d0edcb09-2c66-4d79-8114-5c3e787de042', { payload_transform_code: null });
    assert.equal(res.status, 200);
    const updateCall = conn.queries.find((q) => /^UPDATE `fmb_flow_recipes`/i.test((q.sql || '').trim()));
    assert.ok(/`code_version` = \?/.test(updateCall.sql), 'a NULL-clear is a real change → bump');
    const historyCall = conn.queries.find((q) => /INSERT INTO `fmb_flow_recipe_code_versions`/i.test(q.sql || ''));
    assert.ok(historyCall, 'history row appended');
    assert.ok(/'update'/.test(historyCall.sql), 'action update');
    assert.equal(historyCall.params[2], 2, 'version stored+1');
    assert.strictEqual(historyCall.params[3], null, 'recorded code is NULL');
    assert.equal(conn.committed(), true);
  });
});

describe('flow_recipes codeVersioning — no bump cases', () => {
  it('PUT with the same code → no bump, no history row', async () => {
    const res = await req('PUT', '/fr/d0edcb09-2c66-4d79-8114-5c3e787de042', { payload_transform_code: OLD_CODE });
    assert.equal(res.status, 200);
    const updateCall = conn.queries.find((q) => /^UPDATE `fmb_flow_recipes`/i.test((q.sql || '').trim()));
    // No UPDATE at all is possible only if the whole body degraded to nothing;
    // here name/status stay, but code_version must NOT be set.
    if (updateCall) assert.ok(!/`code_version` = \?/.test(updateCall.sql), 'no version bump on unchanged code');
    assert.ok(!conn.queries.some((q) => /INSERT INTO `fmb_flow_recipe_code_versions`/i.test(q.sql || '')), 'no history row');
  });

  it('PUT that omits payload_transform_code → no pre-read, no bump, no history row', async () => {
    const res = await req('PUT', '/fr/d0edcb09-2c66-4d79-8114-5c3e787de042', { name: 'Renamed' });
    assert.equal(res.status, 200);
    assert.ok(!conn.queries.some((q) => /AS version FROM `fmb_flow_recipes`/i.test(q.sql || '')), 'no version pre-read when watch column absent');
    assert.ok(!conn.queries.some((q) => /INSERT INTO `fmb_flow_recipe_code_versions`/i.test(q.sql || '')), 'no history row');
  });
});

describe('flow_recipes codeVersioning — POST seeds v1', () => {
  it('POST seeds a create history row at version 1 in the same tx', async () => {
    const res = await req('POST', '/fr', { name: 'New', blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', payload_transform_code: 'return {};' });
    assert.equal(res.status, 200);
    const historyCall = conn.queries.find((q) => /INSERT INTO `fmb_flow_recipe_code_versions`/i.test(q.sql || ''));
    assert.ok(historyCall, 'v1 history row inserted');
    assert.ok(/'create'/.test(historyCall.sql), 'action create');
    // POST seeds version as a SQL literal 1, so params are [id, recipe_id, code, created_by].
    assert.ok(/VALUES \(\?, \?, 1, \?, 'create', \?\)/.test(historyCall.sql), 'version literal 1 in SQL');
    assert.equal(historyCall.params[2], 'return {};', 'code = created code');
    assert.equal(historyCall.params[3], '5b729f1e-5c0b-447c-8144-3210469bc62c', 'created_by = requester');
    assert.equal(conn.committed(), true);
    const iHistory = idxOf(/INSERT INTO `fmb_flow_recipe_code_versions`/i);
    const iCommit = idxOf(/^COMMIT$/);
    assert.ok(iHistory >= 0 && iHistory < iCommit, 'history seeded before commit');
  });
});

describe('flow_recipes codeVersioning — DELETE cleans history', () => {
  it('hard DELETE removes history rows in the same tx and commits', async () => {
    const res = await req('DELETE', '/fr/d0edcb09-2c66-4d79-8114-5c3e787de042');
    assert.equal(res.status, 200);
    const cleanup = conn.queries.find((q) => /^DELETE FROM `fmb_flow_recipe_code_versions`/i.test((q.sql || '').trim()));
    assert.ok(cleanup, 'history cleanup DELETE must run');
    assert.equal(cleanup.params[0], 'd0edcb09-2c66-4d79-8114-5c3e787de042', 'cleanup keyed on recipe id');
    const iDelRecipe = idxOf(/^DELETE FROM `fmb_flow_recipes`/i);
    const iDelHistory = idxOf(/^DELETE FROM `fmb_flow_recipe_code_versions`/i);
    const iCommit = idxOf(/^COMMIT$/);
    assert.ok(iDelRecipe >= 0 && iDelRecipe < iDelHistory, 'recipe delete before history cleanup');
    assert.ok(iDelHistory < iCommit, 'cleanup before commit');
    assert.equal(conn.committed(), true);
  });
});

describe('flow_recipes codeVersioning — version coherence on partial-migration DBs', () => {
  it('changed-code PUT with the history table absent → plain update, NO bump, no history, no rollback', async () => {
    historyTableMissing = true; // the TABLES probe reports absent
    const res = await req('PUT', '/fr/d0edcb09-2c66-4d79-8114-5c3e787de042', { payload_transform_code: 'return { a: 2 };' });
    assert.equal(res.status, 200);
    const updateCall = conn.queries.find((q) => /^UPDATE `fmb_flow_recipes`/i.test((q.sql || '').trim()));
    assert.ok(updateCall, 'the code change still persists via a plain UPDATE');
    assert.ok(!/`code_version` = \?/.test(updateCall.sql), 'counter must NOT move without its history row');
    assert.ok(!conn.queries.some((q) => /INSERT INTO `fmb_flow_recipe_code_versions`/i.test(q.sql || '')), 'no history row attempted');
    assert.equal(conn.rolledBack(), false);
    assert.equal(conn.committed(), true);
  });

  it('POST with the code column gated out (history table present) → no orphan v1 seed', async () => {
    hasCodeColumn = false; // payload_transform_code absent from colSet → gated out of the INSERT
    const res = await req('POST', '/fr', { name: 'New', blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', payload_transform_code: 'return {};' });
    assert.equal(res.status, 200);
    const insertCall = conn.queries.find((q) => /^INSERT INTO `fmb_flow_recipes`/i.test((q.sql || '').trim()));
    assert.ok(insertCall && !/payload_transform_code/.test(insertCall.sql), 'the code was gated out of the INSERT');
    assert.ok(!conn.queries.some((q) => /INSERT INTO `fmb_flow_recipe_code_versions`/i.test(q.sql || '')), 'no v1 seed claiming a code the row never stored');
  });

  it('POST with the history table present but the counter column absent → no stale v1 seed', async () => {
    hasVersionColumn = false; // code_version ALTER skipped → later PUTs degrade unversioned
    const res = await req('POST', '/fr', { name: 'New', blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', payload_transform_code: 'return {};' });
    assert.equal(res.status, 200);
    assert.ok(!conn.queries.some((q) => /INSERT INTO `fmb_flow_recipe_code_versions`/i.test(q.sql || '')), 'no v1 seed when the counter column is absent');
  });
});

describe('flow_recipes codeVersioning — no-ALTER legacy DB degrades gracefully', () => {
  it('PUT changed code with missing code_version column → CRUD succeeds, no bump, no rollback', async () => {
    hasVersionColumn = false;
    preReadThrows1054 = true;
    const res = await req('PUT', '/fr/d0edcb09-2c66-4d79-8114-5c3e787de042', { payload_transform_code: 'return { a: 2 };' });
    assert.equal(res.status, 200);
    const updateCall = conn.queries.find((q) => /^UPDATE `fmb_flow_recipes`/i.test((q.sql || '').trim()));
    if (updateCall) assert.ok(!/`code_version` = \?/.test(updateCall.sql), 'no bump when column absent');
    assert.ok(!conn.queries.some((q) => /INSERT INTO `fmb_flow_recipe_code_versions`/i.test(q.sql || '')), 'no history row');
    assert.equal(conn.rolledBack(), false, 'must not roll back the core write');
    assert.equal(conn.committed(), true);
  });

  it('POST with missing history table → recipe still created, no rollback', async () => {
    historyTableMissing = true;
    const res = await req('POST', '/fr', { name: 'New', blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', payload_transform_code: 'return {};' });
    assert.equal(res.status, 200);
    assert.equal(conn.rolledBack(), false, 'missing history table must not roll back the create');
    assert.equal(conn.committed(), true);
  });

  it('DELETE with missing history table → recipe still deleted, no rollback', async () => {
    historyTableMissing = true;
    const res = await req('DELETE', '/fr/d0edcb09-2c66-4d79-8114-5c3e787de042');
    assert.equal(res.status, 200);
    assert.equal(conn.rolledBack(), false, 'missing history table must not roll back the delete');
    assert.equal(conn.committed(), true);
  });
});
