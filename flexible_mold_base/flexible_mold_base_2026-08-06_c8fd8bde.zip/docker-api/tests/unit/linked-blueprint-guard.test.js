/**
 * linked-blueprint-guard.test.js — linked-blueprint integrity fixes.
 *
 * Covers:
 *   - validateLinkConstraints (B1/B2/B5): XOR, self-link, invalid target,
 *     link-to-linked, source-cannot-be-linked, happy path.
 *   - isBlueprintLinked / resolveLinkCheckBlueprintId (S1/S2 resolution).
 *   - Route wiring: schema-write on a linked blueprint → 409
 *     LINKED_BLUEPRINT_READONLY; delete of a link source → 409
 *     LINK_SOURCE_IN_USE; hierarchy PUT null→linked transition clears the
 *     blueprint's own schema + writes the audit row; PUT XOR + link-to-linked.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const { fixtureUserId } = require('../helpers/fixture-ids');
const assert = require('node:assert/strict');
const { answerParentIdProbe } = require('../helpers/parent-id-probe');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../src/edge/db');

let conn;
function makeConn(scripts) {
  const queries = [];
  return {
    queries,
    async query(sql, params) {
      queries.push({ sql, params });
      for (const [matcher, response] of scripts) {
        if (matcher.test(sql)) {
          return typeof response === 'function' ? response(sql, params) : response;
        }
      }
      // Additive-table existence probe (blueprint_groups / decision_tables);
      // default to "absent" so the schema-clear path skips those DELETEs unless
      // a test opts in via `probe(...)`.
      if (/information_schema\.TABLES/.test(sql)) return [];
      // The self-link question is asked of the ENGINE now (write-value.js
      // `sameStoredValue`): the ids are CHAR(36) under a collation that folds
      // case, and a JavaScript comparison answered "not itself" for the same id
      // in another spelling. Answered here the way the column answers it, so
      // this double cannot disagree with the database about which row an id
      // names; the case that matters is settled on a real database
      // (tests/integration/blueprint-field-write-real-db.test.js).
      if (/^SELECT DATABASE\(\)/i.test(sql)) return [{ db: 'fixture_db' }];
      if (/CHARACTER_SET_NAME AS cs/.test(sql)) return [{ cs: 'utf8mb4', co: 'utf8mb4_general_ci' }];
      if (/<=>/.test(sql) && / AS same/.test(sql)) {
        const fold = (v) => String(v).toLowerCase().replace(/\s+$/, '');
        return [{ same: fold((params || [])[0]) === fold((params || [])[1]) ? 1 : 0 }];
      }
      // The factory asks which spelling the parent row really carries before it
      // binds one. Answered rather than thrown on — see tests/helpers.
      const parentId = answerParentIdProbe(sql, params);
      if (parentId) return parentId;
      throw new Error(`Unmatched query: ${sql.slice(0, 120)}`);
    },
    release() {},
    async beginTransaction() {},
    async commit() {},
    async rollback() {},
  };
}

const poolSpy = {
  rw: { async getConnection() { return conn; } },
  ro: { async getConnection() { return conn; } },
};

require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: {
    pool: poolSpy,
    t: (name) => `fmb_${name}`,
    getDynamicPool: async () => poolSpy,
    PLATFORM_SCHEMA_VERSION: '0.0.0-test',
  },
};

const router = require('../../src/edge/routes/app/schema');
const {
  validateLinkConstraints,
  isBlueprintLinked,
  resolveLinkCheckBlueprintId,
  __clearColumnSetCache,
} = router.__test__;
const { TABLES } = require('../../src/shared/constants');

// Answer the additive-table existence probe PER TABLE (keyed on the probed
// physical name). A blanket yes/no would let one additive table's opt-in
// silently flip the other's, so a DELETE assertion could pass for the wrong
// reason — the same per-table treatment hierarchy-cascade.test.js uses.
function probe(...presentPhysicalNames) {
  const present = new Set(presentPhysicalNames);
  return [
    /information_schema\.TABLES/,
    (_sql, params) => (present.has(params && params[0]) ? [{ 1: 1 }] : []),
  ];
}

// A conn whose SELECTs are answered from a small fixture.
function fixtureConn({ target, referrers }) {
  return makeConn([
    [/SELECT node_type, linked_blueprint_id FROM/, target === undefined ? [] : [target]],
    [/linked_blueprint_id = \? AND node_type/, referrers || []],
  ]);
}

describe('validateLinkConstraints', () => {
  it('rejects transformer + link both set (B5)', async () => {
    const err = await validateLinkConstraints(fixtureConn({}), 'fc66f597-f43b-4889-82ce-57289d61b049', 'blueprint', 'dba8baa0-1b87-40f3-8e42-a1b303ce7435', 'd0f3049e-cb12-4f2c-881d-f3f1df150ca9');
    assert.equal(err.code, 'TRANSFORMER_LINK_EXCLUSIVE');
    assert.equal(err.status, 400);
  });

  it('returns null when not linking (link null)', async () => {
    const err = await validateLinkConstraints(fixtureConn({}), 'fc66f597-f43b-4889-82ce-57289d61b049', 'blueprint', null, 'd0f3049e-cb12-4f2c-881d-f3f1df150ca9');
    assert.equal(err, null);
  });

  it('grandfathers an already-both-set row when allowExistingBothSet=true (v3.2.344)', async () => {
    // A row that was ALREADY both-set in storage must be saveable (update an
    // unrelated field, or clear one side to repair it). With the grandfather
    // flag, the XOR guard does not block it — the B1/target checks below still
    // run (link target 'dba8baa0-1b87-40f3-8e42-a1b303ce7435' resolves to a valid unlinked blueprint).
    const err = await validateLinkConstraints(
      fixtureConn({ target: { node_type: 'blueprint', linked_blueprint_id: null } }),
      'fc66f597-f43b-4889-82ce-57289d61b049', 'blueprint', 'dba8baa0-1b87-40f3-8e42-a1b303ce7435', 'd0f3049e-cb12-4f2c-881d-f3f1df150ca9', true,
    );
    assert.equal(err, null);
  });

  it('still rejects both-set on create (allowExistingBothSet defaults false)', async () => {
    // POST/create passes no flag → strict: a fresh both-set row is rejected at
    // the source, so the grandfather path can never be used to MAKE a new one.
    const err = await validateLinkConstraints(fixtureConn({}), 'fc66f597-f43b-4889-82ce-57289d61b049', 'blueprint', 'dba8baa0-1b87-40f3-8e42-a1b303ce7435', 'd0f3049e-cb12-4f2c-881d-f3f1df150ca9');
    assert.equal(err.code, 'TRANSFORMER_LINK_EXCLUSIVE');
    assert.equal(err.status, 400);
  });

  it('rejects a non-blueprint node being linked', async () => {
    const err = await validateLinkConstraints(fixtureConn({}), 'v', 'variant', 'dba8baa0-1b87-40f3-8e42-a1b303ce7435', null);
    assert.equal(err.code, 'INVALID_LINK_TARGET');
  });

  it('rejects self-link', async () => {
    const err = await validateLinkConstraints(fixtureConn({}), 'fc66f597-f43b-4889-82ce-57289d61b049', 'blueprint', 'fc66f597-f43b-4889-82ce-57289d61b049', null);
    assert.equal(err.code, 'SELF_LINK');
  });

  it('rejects a missing / non-blueprint target', async () => {
    const err = await validateLinkConstraints(fixtureConn({ target: undefined }), 'fc66f597-f43b-4889-82ce-57289d61b049', 'blueprint', 'gone', null);
    assert.equal(err.code, 'INVALID_LINK_TARGET');
  });

  it('rejects linking to an already-linked blueprint (B1)', async () => {
    const err = await validateLinkConstraints(
      fixtureConn({ target: { node_type: 'blueprint', linked_blueprint_id: '3ffc5e4c-7590-40b9-8e30-078408c03488' } }),
      'fc66f597-f43b-4889-82ce-57289d61b049', 'blueprint', '80e30937-66ba-4c2a-86d5-4a97c3a1fca1', null,
    );
    assert.equal(err.code, 'LINK_TO_LINKED');
    assert.equal(err.status, 409);
  });

  it('rejects making a link source into a linked blueprint (B1 other direction)', async () => {
    const err = await validateLinkConstraints(
      fixtureConn({ target: { node_type: 'blueprint', linked_blueprint_id: null }, referrers: [{ id: '6040bc76-a49b-477d-8288-d6c3c73600cd' }] }),
      'fc66f597-f43b-4889-82ce-57289d61b049', 'blueprint', '80e30937-66ba-4c2a-86d5-4a97c3a1fca1', null,
    );
    assert.equal(err.code, 'SOURCE_CANNOT_BE_LINKED');
    assert.equal(err.status, 409);
  });

  it('accepts a valid link to an independent blueprint', async () => {
    const err = await validateLinkConstraints(
      fixtureConn({ target: { node_type: 'blueprint', linked_blueprint_id: null }, referrers: [] }),
      'fc66f597-f43b-4889-82ce-57289d61b049', 'blueprint', '80e30937-66ba-4c2a-86d5-4a97c3a1fca1', null,
    );
    assert.equal(err, null);
  });
});

describe('isBlueprintLinked', () => {
  it('true when linked_blueprint_id non-null', async () => {
    const c = makeConn([[/SELECT linked_blueprint_id FROM/, [{ linked_blueprint_id: 'dba8baa0-1b87-40f3-8e42-a1b303ce7435' }]]]);
    assert.equal(await isBlueprintLinked(c, 'fc66f597-f43b-4889-82ce-57289d61b049'), true);
  });
  it('false when null', async () => {
    const c = makeConn([[/SELECT linked_blueprint_id FROM/, [{ linked_blueprint_id: null }]]]);
    assert.equal(await isBlueprintLinked(c, 'fc66f597-f43b-4889-82ce-57289d61b049'), false);
  });
  it('false when no blueprintId (no query)', async () => {
    const c = makeConn([]);
    assert.equal(await isBlueprintLinked(c, null), false);
  });
});

describe('resolveLinkCheckBlueprintId', () => {
  it('direct column from body needs no query', async () => {
    const c = makeConn([]);
    const bid = await resolveLinkCheckBlueprintId(c, 'blueprint_fields', { column: 'blueprint_id' }, { blueprint_id: 'fc66f597-f43b-4889-82ce-57289d61b049' }, null);
    assert.equal(bid, 'fc66f597-f43b-4889-82ce-57289d61b049');
  });
  it('direct column from row id queries the row', async () => {
    const c = makeConn([[/SELECT `blueprint_id` AS bid FROM/, [{ bid: 'fc66f597-f43b-4889-82ce-57289d61b049' }]]]);
    const bid = await resolveLinkCheckBlueprintId(c, 'blueprint_fields', { column: 'blueprint_id' }, undefined, 'row-1');
    assert.equal(bid, 'fc66f597-f43b-4889-82ce-57289d61b049');
  });
  it('fk form resolves field_id → blueprint_fields.blueprint_id', async () => {
    const c = makeConn([[/SELECT `blueprint_id` AS bid FROM `fmb_blueprint_fields`/, [{ bid: 'fc66f597-f43b-4889-82ce-57289d61b049' }]]]);
    const bid = await resolveLinkCheckBlueprintId(
      c, 'field_options',
      { fk: 'field_id', lookupTable: TABLES.BLUEPRINT_FIELDS, lookupIdCol: 'id', blueprintCol: 'blueprint_id' },
      { field_id: 'b630a50b-4ef8-45c6-80b9-3eca727bd015' }, null,
    );
    assert.equal(bid, 'fc66f597-f43b-4889-82ce-57289d61b049');
  });
});

// ── Route wiring ──────────────────────────────────────────────────────
function makeApp(role) {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { req.user = { id: fixtureUserId(role), role }; next(); });
  app.use('/edge/app/schema', router);
  return app;
}

let server; let port; let adminApp;
before(async () => {
  adminApp = makeApp('admin');
  await new Promise((resolve) => { server = adminApp.listen(0, '127.0.0.1', () => { port = server.address().port; resolve(); }); });
});
after(async () => { await new Promise((resolve) => server.close(resolve)); delete require.cache[dbKey]; });
beforeEach(() => { conn = null; __clearColumnSetCache(); });

function request(method, path, body) {
  return new Promise((resolve, reject) => {
    const data = body !== undefined ? JSON.stringify(body) : '';
    const headers = data ? { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(data) } : {};
    const req = http.request({ method, host: '127.0.0.1', port, path, headers }, (res) => {
      let raw = '';
      res.on('data', (c) => { raw += c; });
      res.on('end', () => resolve({ status: res.statusCode, body: raw ? JSON.parse(raw) : null }));
    });
    req.on('error', reject);
    if (data) req.write(data);
    req.end();
  });
}

describe('route: schema write on a linked blueprint → 409 (S1/S2)', () => {
  it('POST /blueprint_fields rejected when parent blueprint is linked', async () => {
    conn = makeConn([[/SELECT linked_blueprint_id FROM/, [{ linked_blueprint_id: 'dba8baa0-1b87-40f3-8e42-a1b303ce7435' }]]]);
    const res = await request('POST', '/edge/app/schema/blueprint_fields', {
      blueprint_id: '47855752-d227-4867-8769-6ab0661f0ef4', field_key: 'x', field_label: 'X', field_type: 'text',
    });
    assert.equal(res.status, 409);
    assert.equal(res.body.error.code, 'LINKED_BLUEPRINT_READONLY');
  });

  it('POST /field_options rejected via field_id → blueprint hop when linked', async () => {
    conn = makeConn([
      [/SELECT `blueprint_id` AS bid FROM `fmb_blueprint_fields`/, [{ bid: '47855752-d227-4867-8769-6ab0661f0ef4' }]],
      [/SELECT linked_blueprint_id FROM/, [{ linked_blueprint_id: "dba8baa0-1b87-40f3-8e42-a1b303ce7435" }]],
    ]);
    const res = await request('POST', '/edge/app/schema/field_options', {
      field_id: 'b630a50b-4ef8-45c6-80b9-3eca727bd015', option_label: 'A', option_value: 'a',
    });
    assert.equal(res.status, 409);
    assert.equal(res.body.error.code, 'LINKED_BLUEPRINT_READONLY');
  });
});

describe('route: delete a link source → 409 LINK_SOURCE_IN_USE (B3)', () => {
  it('DELETE /hierarchy_nodes/:id rejected when other blueprints link to it', async () => {
    conn = makeConn([
      // Owner gate node-fetch (admin passes regardless of owner).
      [/SELECT id, node_type, owner_id FROM/, [{ id: '905685fc-3b3f-4983-86d6-3b5e38df81c7', node_type: 'blueprint', owner_id: null }]],
      [/parent_id IN/, []], // leaf node, no descendants
      [/linked_blueprint_id IN/, [{ id: '0c00edd0-00ad-4088-8505-875fd96cf745', name: 'Borrower' }]],
    ]);
    const res = await request('DELETE', '/edge/app/schema/hierarchy_nodes/905685fc-3b3f-4983-86d6-3b5e38df81c7');
    assert.equal(res.status, 409);
    assert.equal(res.body.error.code, 'LINK_SOURCE_IN_USE');
    assert.deepEqual(res.body.details.dependents, [{ id: '0c00edd0-00ad-4088-8505-875fd96cf745', name: 'Borrower' }]);
  });

  it('rejects deleting an ancestor when an OUTSIDE borrower links to a descendant (P1)', async () => {
    conn = makeConn([
      // Owner gate node-fetch (admin passes; structural ancestor node).
      [/SELECT id, node_type, owner_id FROM/, [{ id: 'f3afd15a-b606-4f27-8613-7209af0cedcd', node_type: 'release', owner_id: null }]],
      // collectDescendantIds BFS: gen-del → [desc-bp], desc-bp → []
      [/parent_id IN/, (_sql, params) => (params.includes('f3afd15a-b606-4f27-8613-7209af0cedcd') ? [{ id: 'f1e2d165-9087-45f8-8b37-9d0bf050b408' }] : [])],
      [/linked_blueprint_id IN/, [{ id: '104428da-6bcd-4a8a-8a0f-9de18e2c8881', name: 'Outside Borrower' }]],
    ]);
    const res = await request('DELETE', '/edge/app/schema/hierarchy_nodes/f3afd15a-b606-4f27-8613-7209af0cedcd');
    assert.equal(res.status, 409);
    assert.equal(res.body.error.code, 'LINK_SOURCE_IN_USE');
  });
});

describe('route: non-blueprint nodes cannot carry a link (P2)', () => {
  it('POST a variant with linked_blueprint_id → 400 INVALID_LINK_TARGET', async () => {
    conn = makeConn([]); // rejected before any query
    const res = await request('POST', '/edge/app/schema/hierarchy_nodes', {
      node_type: 'variant', name: 'V', linked_blueprint_id: '264ea353-70c4-4d9f-82c1-df2c766ff8ee', parent_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26',
    });
    assert.equal(res.status, 400);
    assert.equal(res.body.error.code, 'INVALID_LINK_TARGET');
  });

  it('POST a blueprint with link + transformer_version (no id) → 400 XOR', async () => {
    conn = makeConn([]); // XOR rejected before any query
    const res = await request('POST', '/edge/app/schema/hierarchy_nodes', {
      node_type: 'blueprint', name: 'BP', linked_blueprint_id: 'dba8baa0-1b87-40f3-8e42-a1b303ce7435', transformer_version: 3,
    });
    assert.equal(res.status, 400);
    assert.equal(res.body.error.code, 'TRANSFORMER_LINK_EXCLUSIVE');
  });

  it('PUT a variant introducing a link → 400 INVALID_LINK_TARGET', async () => {
    conn = makeConn([
      [/SELECT node_type, owner_id, linked_blueprint_id, transformer_id/, [{ node_type: 'variant', owner_id: null, linked_blueprint_id: null, transformer_id: null }]],
    ]);
    const res = await request('PUT', '/edge/app/schema/hierarchy_nodes/v-1', { linked_blueprint_id: '264ea353-70c4-4d9f-82c1-df2c766ff8ee' });
    assert.equal(res.status, 400);
    assert.equal(res.body.error.code, 'INVALID_LINK_TARGET');
  });
});

describe('route: editor cannot bypass the linked guard via a spoofed parent FK (P2)', () => {
  it('PUT /blueprint_sections resolves the parent from the STORED row, not the body', async () => {
    conn = makeConn([
      // Body claims an unlinked parent, but the stored row belongs to a linked bp.
      [/SELECT `blueprint_id` AS bid FROM `fmb_blueprint_sections`/, [{ bid: '47855752-d227-4867-8769-6ab0661f0ef4' }]],
      [/SELECT linked_blueprint_id FROM/, [{ linked_blueprint_id: 'dba8baa0-1b87-40f3-8e42-a1b303ce7435' }]],
    ]);
    const res = await request('PUT', '/edge/app/schema/blueprint_sections/sec-1', {
      blueprint_id: 'c3d8194b-dda9-46a0-8b2b-54f10da0fb88', display_label: 'X',
    });
    assert.equal(res.status, 409);
    assert.equal(res.body.error.code, 'LINKED_BLUEPRINT_READONLY');
  });

  it('PUT /blueprint_sections cannot MOVE a row INTO a linked blueprint', async () => {
    conn = makeConn([
      // stored row is under an unlinked blueprint, but the body reparents to a linked one.
      [/SELECT `blueprint_id` AS bid FROM `fmb_blueprint_sections`/, [{ bid: 'c3d8194b-dda9-46a0-8b2b-54f10da0fb88' }]],
      [/SELECT linked_blueprint_id FROM/, (_s, p) => (p[0] === '47855752-d227-4867-8769-6ab0661f0ef4' ? [{ linked_blueprint_id: 'dba8baa0-1b87-40f3-8e42-a1b303ce7435' }] : [{ linked_blueprint_id: null }])],
    ]);
    const res = await request('PUT', '/edge/app/schema/blueprint_sections/sec-1', {
      blueprint_id: '47855752-d227-4867-8769-6ab0661f0ef4', display_label: 'X',
    });
    assert.equal(res.status, 409);
    assert.equal(res.body.error.code, 'LINKED_BLUEPRINT_READONLY');
  });
});

describe('route: hierarchy PUT link integrity + auto-clear (B1/B5/Q3)', () => {
  it('rejects PUT that sets both transformer and link (XOR, B5)', async () => {
    conn = makeConn([
      [/SELECT node_type, owner_id, linked_blueprint_id, transformer_id/, [{ node_type: 'blueprint', owner_id: null, linked_blueprint_id: null, transformer_id: null }]],
    ]);
    const res = await request('PUT', '/edge/app/schema/hierarchy_nodes/fc66f597-f43b-4889-82ce-57289d61b049', {
      linked_blueprint_id: 'dba8baa0-1b87-40f3-8e42-a1b303ce7435', transformer_id: 'd0f3049e-cb12-4f2c-881d-f3f1df150ca9',
    });
    assert.equal(res.status, 400);
    assert.equal(res.body.error.code, 'TRANSFORMER_LINK_EXCLUSIVE');
  });

  it('rejects PUT setting a link when a transformer_version is already stored (XOR, B5)', async () => {
    conn = makeConn([
      [/SELECT node_type, owner_id, linked_blueprint_id, transformer_id/, [{ node_type: 'blueprint', owner_id: null, linked_blueprint_id: null, transformer_id: null, transformer_version: 3 }]],
    ]);
    // Body sets only the link; stored transformer_version must still trip XOR.
    const res = await request('PUT', '/edge/app/schema/hierarchy_nodes/fc66f597-f43b-4889-82ce-57289d61b049', { linked_blueprint_id: 'dba8baa0-1b87-40f3-8e42-a1b303ce7435' });
    assert.equal(res.status, 400);
    assert.equal(res.body.error.code, 'TRANSFORMER_LINK_EXCLUSIVE');
  });

  it('rejects PUT that CHANGES the transformer on an already-both-set row (v3.2.344 grandfather is repair-only)', async () => {
    // Stored row is both-set (link + transformer). A PUT that swaps the
    // transformer to a NEW value keeps editing the forbidden pair rather than
    // repairing it, so the grandfather must NOT apply → XOR still fires.
    conn = makeConn([
      [/SELECT node_type, owner_id, linked_blueprint_id, transformer_id/, [{ node_type: 'blueprint', owner_id: null, linked_blueprint_id: 'dba8baa0-1b87-40f3-8e42-a1b303ce7435', transformer_id: '5551dcdf-992f-4929-8098-a89130f7e0eb', transformer_version: null }]],
    ]);
    const res = await request('PUT', '/edge/app/schema/hierarchy_nodes/fc66f597-f43b-4889-82ce-57289d61b049', { transformer_id: 'fdf8e40e-9ac4-4d54-8d1c-8d3ed5537cb4' });
    assert.equal(res.status, 400);
    assert.equal(res.body.error.code, 'TRANSFORMER_LINK_EXCLUSIVE');
  });

  it('rejects PUT linking to an already-linked blueprint (B1)', async () => {
    conn = makeConn([
      [/SELECT node_type, owner_id, linked_blueprint_id, transformer_id/, [{ node_type: 'blueprint', owner_id: null, linked_blueprint_id: null, transformer_id: null }]],
      [/SELECT node_type, linked_blueprint_id FROM/, [{ node_type: 'blueprint', linked_blueprint_id: '3ffc5e4c-7590-40b9-8e30-078408c03488' }]],
    ]);
    const res = await request('PUT', '/edge/app/schema/hierarchy_nodes/fc66f597-f43b-4889-82ce-57289d61b049', { linked_blueprint_id: '80e30937-66ba-4c2a-86d5-4a97c3a1fca1' });
    assert.equal(res.status, 409);
    assert.equal(res.body.error.code, 'LINK_TO_LINKED');
  });

  it('null→linked transition clears own schema + writes audit (Q3)', async () => {
    conn = makeConn([
      [/SELECT node_type, owner_id, linked_blueprint_id, transformer_id/, [{ node_type: 'blueprint', owner_id: null, linked_blueprint_id: null, transformer_id: null }]],
      [/SELECT (?:id, )?node_type, linked_blueprint_id FROM/,
        [{ id: 'dba8baa0-1b87-40f3-8e42-a1b303ce7435', node_type: 'blueprint', linked_blueprint_id: null }]],
      [/linked_blueprint_id = \? AND node_type/, []],
      [/DELETE FROM `fmb_variant_overrides`/, { affectedRows: 0 }],
      [/DELETE FROM `fmb_field_options`/, { affectedRows: 0 }],
      [/DELETE FROM `fmb_blueprint_fields`/, { affectedRows: 2 }],
      [/DELETE FROM `fmb_blueprint_sections`/, { affectedRows: 1 }],
      // Both additive tables present → their rows must be cleared too (no orphans).
      probe('fmb_blueprint_groups', 'fmb_decision_tables'),
      [/DELETE FROM `fmb_blueprint_groups`/, { affectedRows: 3 }],
      [/DELETE FROM `fmb_decision_tables`/, { affectedRows: 3 }],
      [/DELETE FROM `fmb_blueprint_output_order`/, { affectedRows: 0 }],
      [/INSERT INTO `fmb_feature_audit`/, { affectedRows: 1 }],
      [/SELECT DATABASE\(\)/, [{ db: 'testdb' }]],
      [/information_schema\.COLUMNS/, []],
      [/UPDATE `fmb_hierarchy_nodes` SET/, { affectedRows: 1 }],
      [/SELECT \* FROM `fmb_hierarchy_nodes` WHERE id = \?/, [{ id: 'fc66f597-f43b-4889-82ce-57289d61b049', name: 'X', linked_blueprint_id: 'dba8baa0-1b87-40f3-8e42-a1b303ce7435' }]],
    ]);
    const res = await request('PUT', '/edge/app/schema/hierarchy_nodes/fc66f597-f43b-4889-82ce-57289d61b049', {
      name: 'X', node_type: 'blueprint', linked_blueprint_id: 'dba8baa0-1b87-40f3-8e42-a1b303ce7435', is_active: true,
    });
    assert.equal(res.status, 200);
    // The blueprint's own schema rows were deleted (incl. variant overrides
    // and the additive color-group rows)...
    assert.ok(conn.queries.some((q) => /DELETE FROM `fmb_blueprint_fields`/.test(q.sql)));
    assert.ok(conn.queries.some((q) => /DELETE FROM `fmb_variant_overrides`/.test(q.sql)));
    assert.ok(conn.queries.some((q) => /DELETE FROM `fmb_blueprint_groups`/.test(q.sql)));
    // ...and an audit row recorded the clear.
    const audit = conn.queries.find((q) => /INSERT INTO `fmb_feature_audit`/.test(q.sql));
    assert.ok(audit);
    assert.ok(audit.params.includes('blueprint.linked.schema_cleared'));
  });

  it('clears the blueprint\'s decision tables in the same transaction, and audits how many', async () => {
    // A linked blueprint borrows its schema, so rules written against THIS
    // blueprint's field keys can no longer be repaired OR deleted through the
    // route (every write on a linked parent is refused, admin included). They
    // must go with the rest of the now-unreachable schema.
    conn = makeConn([
      [/SELECT node_type, owner_id, linked_blueprint_id, transformer_id/, [{ node_type: 'blueprint', owner_id: null, linked_blueprint_id: null, transformer_id: null }]],
      [/SELECT (?:id, )?node_type, linked_blueprint_id FROM/,
        [{ id: 'dba8baa0-1b87-40f3-8e42-a1b303ce7435', node_type: 'blueprint', linked_blueprint_id: null }]],
      [/linked_blueprint_id = \? AND node_type/, []],
      [/DELETE FROM `fmb_variant_overrides`/, { affectedRows: 0 }],
      [/DELETE FROM `fmb_field_options`/, { affectedRows: 0 }],
      [/DELETE FROM `fmb_blueprint_fields`/, { affectedRows: 2 }],
      [/DELETE FROM `fmb_blueprint_sections`/, { affectedRows: 1 }],
      // decision_tables present, blueprint_groups absent — the probe is per
      // table, so this also proves the two are not gated on one answer.
      probe('fmb_decision_tables'),
      [/DELETE FROM `fmb_decision_tables`/, { affectedRows: 3 }],
      [/DELETE FROM `fmb_blueprint_output_order`/, { affectedRows: 0 }],
      [/INSERT INTO `fmb_feature_audit`/, { affectedRows: 1 }],
      [/SELECT DATABASE\(\)/, [{ db: 'testdb' }]],
      [/information_schema\.COLUMNS/, []],
      [/UPDATE `fmb_hierarchy_nodes` SET/, { affectedRows: 1 }],
      [/SELECT \* FROM `fmb_hierarchy_nodes` WHERE id = \?/, [{ id: 'fc66f597-f43b-4889-82ce-57289d61b049', name: 'X', linked_blueprint_id: 'dba8baa0-1b87-40f3-8e42-a1b303ce7435' }]],
    ]);
    const res = await request('PUT', '/edge/app/schema/hierarchy_nodes/fc66f597-f43b-4889-82ce-57289d61b049', {
      name: 'X', node_type: 'blueprint', linked_blueprint_id: 'dba8baa0-1b87-40f3-8e42-a1b303ce7435', is_active: true,
    });
    assert.equal(res.status, 200);
    const del = conn.queries.find((q) => /DELETE FROM `fmb_decision_tables`/.test(q.sql));
    assert.ok(del, 'expected the decision_tables DELETE');
    assert.deepEqual(del.params, ['fc66f597-f43b-4889-82ce-57289d61b049'], 'must delete only THIS blueprint\'s tables');
    // Issued before the audit row, i.e. inside the same transaction as the rest
    // of the clear — a delete that landed after it would not roll back with it.
    const delAt = conn.queries.indexOf(del);
    const auditAt = conn.queries.findIndex((q) => /INSERT INTO `fmb_feature_audit`/.test(q.sql));
    assert.ok(delAt < auditAt, 'decision_tables DELETE must precede the audit row');
    // blueprint_groups is absent on this target — its own probe said so.
    assert.ok(!conn.queries.some((q) => /DELETE FROM `fmb_blueprint_groups`/.test(q.sql)));
    const audit = conn.queries[auditAt];
    assert.equal(JSON.parse(audit.params[3]).decision_tables_cleared, 3);
  });

  it('skips the decision_tables DELETE on a pre-migration target lacking the table', async () => {
    conn = makeConn([
      [/SELECT node_type, owner_id, linked_blueprint_id, transformer_id/, [{ node_type: 'blueprint', owner_id: null, linked_blueprint_id: null, transformer_id: null }]],
      [/SELECT (?:id, )?node_type, linked_blueprint_id FROM/,
        [{ id: 'dba8baa0-1b87-40f3-8e42-a1b303ce7435', node_type: 'blueprint', linked_blueprint_id: null }]],
      [/linked_blueprint_id = \? AND node_type/, []],
      [/DELETE FROM `fmb_variant_overrides`/, { affectedRows: 0 }],
      [/DELETE FROM `fmb_field_options`/, { affectedRows: 0 }],
      [/DELETE FROM `fmb_blueprint_fields`/, { affectedRows: 0 }],
      [/DELETE FROM `fmb_blueprint_sections`/, { affectedRows: 0 }],
      // Only blueprint_groups exists here.
      probe('fmb_blueprint_groups'),
      [/DELETE FROM `fmb_blueprint_groups`/, { affectedRows: 1 }],
      [/DELETE FROM `fmb_blueprint_output_order`/, { affectedRows: 0 }],
      [/INSERT INTO `fmb_feature_audit`/, { affectedRows: 1 }],
      [/SELECT DATABASE\(\)/, [{ db: 'testdb' }]],
      [/information_schema\.COLUMNS/, []],
      [/UPDATE `fmb_hierarchy_nodes` SET/, { affectedRows: 1 }],
      [/SELECT \* FROM `fmb_hierarchy_nodes` WHERE id = \?/, [{ id: 'fc66f597-f43b-4889-82ce-57289d61b049', name: 'X', linked_blueprint_id: 'dba8baa0-1b87-40f3-8e42-a1b303ce7435' }]],
    ]);
    const res = await request('PUT', '/edge/app/schema/hierarchy_nodes/fc66f597-f43b-4889-82ce-57289d61b049', {
      name: 'X', node_type: 'blueprint', linked_blueprint_id: 'dba8baa0-1b87-40f3-8e42-a1b303ce7435', is_active: true,
    });
    assert.equal(res.status, 200);
    assert.ok(
      !conn.queries.some((q) => /DELETE FROM `fmb_decision_tables`/.test(q.sql)),
      'must not DELETE a table that does not exist',
    );
    const audit = conn.queries.find((q) => /INSERT INTO `fmb_feature_audit`/.test(q.sql));
    assert.equal(JSON.parse(audit.params[3]).decision_tables_cleared, 0);
  });

  it('link-transition PUT with parent_id in body must not include parent_id in UPDATE SET (reparent bypass prevention)', async () => {
    // A client supplying parent_id alongside the link transition must not be
    // able to reparent the blueprint; parent_id must be stripped before the
    // self-built UPDATE so the cycle guard + re-stamp + audit in /reparent
    // remain the only mutation path.
    conn = makeConn([
      [/SELECT node_type, owner_id, linked_blueprint_id, transformer_id/, [{ node_type: 'blueprint', owner_id: null, linked_blueprint_id: null, transformer_id: null }]],
      [/SELECT (?:id, )?node_type, linked_blueprint_id FROM/,
        [{ id: 'dba8baa0-1b87-40f3-8e42-a1b303ce7435', node_type: 'blueprint', linked_blueprint_id: null }]],
      [/linked_blueprint_id = \? AND node_type/, []],
      [/DELETE FROM `fmb_variant_overrides`/, { affectedRows: 0 }],
      [/DELETE FROM `fmb_field_options`/, { affectedRows: 0 }],
      [/DELETE FROM `fmb_blueprint_fields`/, { affectedRows: 0 }],
      [/DELETE FROM `fmb_blueprint_sections`/, { affectedRows: 0 }],
      [/DELETE FROM `fmb_blueprint_output_order`/, { affectedRows: 0 }],
      [/INSERT INTO `fmb_feature_audit`/, { affectedRows: 1 }],
      [/SELECT DATABASE\(\)/, [{ db: 'testdb' }]],
      [/information_schema\.COLUMNS/, []],
      [/UPDATE `fmb_hierarchy_nodes` SET/, { affectedRows: 1 }],
      [/SELECT \* FROM `fmb_hierarchy_nodes` WHERE id = \?/, [{ id: 'fc66f597-f43b-4889-82ce-57289d61b049', name: 'X', linked_blueprint_id: 'dba8baa0-1b87-40f3-8e42-a1b303ce7435', parent_id: 'bec5a523-4ad9-4118-85e5-260ace52c0ae' }]],
    ]);
    const res = await request('PUT', '/edge/app/schema/hierarchy_nodes/fc66f597-f43b-4889-82ce-57289d61b049', {
      name: 'X', linked_blueprint_id: 'dba8baa0-1b87-40f3-8e42-a1b303ce7435', parent_id: '562b514d-685d-45fb-85cd-febbb0c1817a',
    });
    assert.equal(res.status, 200);
    // The UPDATE must not include parent_id in its SET clause.
    const updateQuery = conn.queries.find((q) => /UPDATE `fmb_hierarchy_nodes` SET/.test(q.sql));
    assert.ok(updateQuery, 'expected an UPDATE query');
    assert.ok(
      !/`parent_id`/.test(updateQuery.sql),
      `parent_id must not appear in UPDATE SET clause; got: ${updateQuery.sql}`,
    );
    // The attacker-supplied value must not be in the params either.
    assert.ok(
      !updateQuery.params.includes('562b514d-685d-45fb-85cd-febbb0c1817a'),
      `562b514d-685d-45fb-85cd-febbb0c1817a must not be in UPDATE params; got: ${JSON.stringify(updateQuery.params)}`,
    );
  });
});
