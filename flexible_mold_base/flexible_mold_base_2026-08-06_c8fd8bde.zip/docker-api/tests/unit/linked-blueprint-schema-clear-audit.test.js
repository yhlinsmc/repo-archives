/**
 * linked-blueprint-schema-clear-audit.test.js — 2c.
 *
 * The null→linked transition clears the blueprint's own schema inside a
 * transaction and writes a `blueprint.linked.schema_cleared` audit row. If the
 * final UPDATE affects 0 rows (blueprint deleted concurrently) the rollback
 * drops that audit — so a `blueprint.linked.schema_clear.failed` row must be
 * written on a fresh connection to record the attempt.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../src/edge/db');

let conn;
// Ordered matchers with a permissive default ([] for unmatched reads, harmless
// for the clear DELETEs / audit INSERTs whose affectedRows the route ignores).
function makeConn(scripts) {
  const queries = [];
  return {
    queries,
    async query(sql, params) {
      queries.push({ sql, params });
      for (const [matcher, response] of scripts) {
        if (matcher.test(sql)) return typeof response === 'function' ? response(sql, params) : response;
      }
      return [];
    },
    release() {},
    async beginTransaction() {},
    async commit() {},
    async rollback() {},
  };
}

const poolSpy = {
  rw: { async getConnection() { return conn; } },
  ro: { async getConnection() { return conn; } },
};

require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: {
    pool: poolSpy,
    t: (name) => `fmb_${name}`,
    getDynamicPool: async () => poolSpy,
    PLATFORM_SCHEMA_VERSION: '0.0.0-test',
  },
};

const router = require('../../src/edge/routes/app/schema');
const { __clearColumnSetCache } = router.__test__;

function makeApp(role) {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { req.user = { id: `${role}-1`, role }; next(); });
  app.use('/edge/app/schema', router);
  return app;
}

let server; let port;
before(async () => {
  const app = makeApp('admin');
  await new Promise((resolve) => { server = app.listen(0, '127.0.0.1', () => { port = server.address().port; resolve(); }); });
});
after(async () => { await new Promise((resolve) => server.close(resolve)); delete require.cache[dbKey]; });
beforeEach(() => { conn = null; __clearColumnSetCache(); });

function request(method, path, body) {
  return new Promise((resolve, reject) => {
    const data = body !== undefined ? JSON.stringify(body) : '';
    const headers = data ? { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(data) } : {};
    const req = http.request({ method, host: '127.0.0.1', port, path: `/edge/app/schema${path}`, headers }, (res) => {
      let raw = '';
      res.on('data', (c) => { raw += c; });
      res.on('end', () => resolve({ status: res.statusCode, body: raw ? JSON.parse(raw) : null }));
    });
    req.on('error', reject);
    if (data) req.write(data);
    req.end();
  });
}

function failedAuditRows(c) {
  return c.queries.filter((q) => /INSERT INTO `fmb_feature_audit`/.test(q.sql)
    && Array.isArray(q.params) && q.params.includes('blueprint.linked.schema_clear.failed'));
}

// NOTE: poolSpy returns the same singleton `conn` for both the transaction and
// the fresh auditSchemaClearFailed connection, so this asserts the failed-audit
// INSERT is *issued* on the rollback path — not the production invariant that it
// runs on a SEPARATE autocommit connection (that survives the rollback). The
// separate-connection behavior is exercised end-to-end by the integration tests.
describe('schema_clear.failed audit on transition rollback', () => {
  it('writes the failed audit when the final UPDATE affects 0 rows', async () => {
    conn = makeConn([
      // stored row: independent blueprint (null→linked transition).
      [/SELECT node_type, owner_id, linked_blueprint_id, transformer_id, transformer_version/, [{ node_type: 'blueprint', owner_id: null, linked_blueprint_id: null, transformer_id: null, transformer_version: null }]],
      // validateLinkConstraints target + transition FOR UPDATE re-check: unlinked blueprint.
      [/SELECT (?:id, )?node_type, linked_blueprint_id FROM `fmb_hierarchy_nodes`/,
        [{ id: 'dba8baa0-1b87-40f3-8e42-a1b303ce7435', node_type: 'blueprint', linked_blueprint_id: null }]],
      // referrers check: none.
      [/linked_blueprint_id = \? AND node_type = 'blueprint' LIMIT 1/, []],
      // final metadata UPDATE: blueprint vanished → 0 rows → rollback.
      [/UPDATE `fmb_hierarchy_nodes` SET/, { affectedRows: 0 }],
    ]);
    // A real identifier, because the link columns now carry the identifier
    // floor: a value that is not one is refused before the transition can run,
    // and this case is about what happens AFTER it runs.
    const res = await request('PUT', '/hierarchy_nodes/bp-1', {
      linked_blueprint_id: 'a1b2c3d4-1111-4222-8333-000000000002',
    });
    assert.equal(res.status, 404);
    assert.equal(failedAuditRows(conn).length, 1, 'expected exactly one schema_clear.failed audit row');
  });
});
