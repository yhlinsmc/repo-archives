/**
 * flow-extract.test.js
 *
 * Tests for extractFlowResult — the server-side twin of the deleted FE
 * extract-result.ts. Validates path extraction, legacy bare-string specs,
 * and the prototype-pollution guard ported from response-path-getter.ts.
 *
 * Run:
 *   cd docker-api && NODE_ENV=test node --test tests/unit/flow-extract.test.js
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');

const { extractFlowResult } = require('../../src/shared/lib/flow-extract');

describe('extractFlowResult — object-spec extraction', () => {
  it('extracts link and externalId via {path} object specs', () => {
    const body = JSON.stringify({ url: 'https://flow/x', id: 'F-9' });
    const out = extractFlowResult(body, {
      link_extract: { path: 'url' },
      external_id_extract: { path: 'id' },
    });
    assert.deepEqual(out, { link: 'https://flow/x', externalId: 'F-9' });
  });

  it('extracts a nested path using dot notation', () => {
    const body = JSON.stringify({ flow: { url: 'https://deep/y', ref: 'D-7' } });
    const out = extractFlowResult(body, {
      link_extract: { path: 'flow.url' },
      external_id_extract: { path: 'flow.ref' },
    });
    assert.deepEqual(out, { link: 'https://deep/y', externalId: 'D-7' });
  });

  it('extracts an array element via bracket notation', () => {
    const body = JSON.stringify({ results: [{ link: 'https://arr/z' }] });
    const out = extractFlowResult(body, {
      link_extract: { path: 'results[0].link' },
      external_id_extract: null,
    });
    assert.equal(out.link, 'https://arr/z');
    assert.equal(out.externalId, null);
  });
});

describe('extractFlowResult — bare-string legacy spec', () => {
  it('tolerates a bare-string spec (legacy rows before {path} DTO shape)', () => {
    const body = JSON.stringify({ nested: { link: 'https://legacy', ext: 'LE-1' } });
    const out = extractFlowResult(body, {
      link_extract: 'nested.link',
      external_id_extract: 'nested.ext',
    });
    assert.deepEqual(out, { link: 'https://legacy', externalId: 'LE-1' });
  });

  it('treats an empty bare-string spec as missing (returns null)', () => {
    const body = JSON.stringify({ url: 'x' });
    const out = extractFlowResult(body, { link_extract: '', external_id_extract: '   ' });
    assert.equal(out.link, null);
    assert.equal(out.externalId, null);
  });
});

describe('extractFlowResult — missing / absent paths', () => {
  it('returns null when path does not exist in the body', () => {
    const body = JSON.stringify({ other: 'value' });
    const out = extractFlowResult(body, {
      link_extract: { path: 'url' },
      external_id_extract: { path: 'id' },
    });
    assert.deepEqual(out, { link: null, externalId: null });
  });

  it('returns null when spec is null', () => {
    const body = JSON.stringify({ url: 'x' });
    const out = extractFlowResult(body, { link_extract: null, external_id_extract: undefined });
    assert.equal(out.link, null);
    assert.equal(out.externalId, null);
  });

  it('returns null when spec.path is empty string', () => {
    const body = JSON.stringify({ url: 'x' });
    const out = extractFlowResult(body, { link_extract: { path: '' } });
    assert.equal(out.link, null);
  });
});

describe('extractFlowResult — non-JSON body', () => {
  it('returns { link: null, externalId: null } for an HTML error body', () => {
    const out = extractFlowResult('<html>error</html>', { link_extract: { path: 'url' } });
    assert.deepEqual(out, { link: null, externalId: null });
  });

  it('returns { link: null, externalId: null } for a plain-text body', () => {
    const out = extractFlowResult('Internal Server Error', { link_extract: { path: 'url' } });
    assert.deepEqual(out, { link: null, externalId: null });
  });

  it('returns { link: null, externalId: null } for an empty body', () => {
    const out = extractFlowResult('', { link_extract: { path: 'url' } });
    assert.deepEqual(out, { link: null, externalId: null });
  });
});

describe('extractFlowResult — value coercion', () => {
  it('coerces a number value to string via String()', () => {
    const body = JSON.stringify({ count: 42 });
    const out = extractFlowResult(body, { link_extract: { path: 'count' } });
    assert.equal(out.link, '42');
  });

  it('coerces a boolean value to string via String()', () => {
    const body = JSON.stringify({ flag: true });
    const out = extractFlowResult(body, { link_extract: { path: 'flag' } });
    assert.equal(out.link, 'true');
  });
});

describe('extractFlowResult — prototype-pollution guard (CRITICAL SECURITY)', () => {
  it('blocks __proto__ path and returns null without polluting Object.prototype', () => {
    // The body key "__proto__" is an own property on the parsed object in modern V8,
    // NOT the prototype. The path guard must still block the __proto__ token.
    const body = '{"a":1}';
    const out = extractFlowResult(body, { link_extract: { path: '__proto__.polluted' } });
    assert.equal(out.link, null, '__proto__ path must be blocked by the guard');
    // CRITICAL: Object.prototype must not have been mutated
    assert.equal(({}).polluted, undefined, 'Object.prototype must not be polluted');
  });

  it('blocks constructor path and returns null', () => {
    const body = JSON.stringify({ constructor: { name: 'Attacker' } });
    const out = extractFlowResult(body, { link_extract: { path: 'constructor' } });
    assert.equal(out.link, null, 'constructor path must be blocked by the guard');
    // Object.prototype.constructor must still be Object
    assert.equal(({}).constructor, Object, 'Object.prototype.constructor must not be overwritten');
  });

  it('blocks prototype path and returns null', () => {
    const body = JSON.stringify({ prototype: { isAdmin: true } });
    const out = extractFlowResult(body, { link_extract: { path: 'prototype.isAdmin' } });
    assert.equal(out.link, null, 'prototype path must be blocked by the guard');
  });

  it('blocks a deeply-nested forbidden key mid-path', () => {
    const body = JSON.stringify({ a: { __proto__: { x: 1 } } });
    const out = extractFlowResult(body, { link_extract: { path: 'a.__proto__.x' } });
    assert.equal(out.link, null, 'forbidden key mid-path must still be blocked');
  });
});
