const test = require('node:test');
const assert = require('node:assert/strict');

const limiterPath = require.resolve('../../src/infra/limiters');
const rateLimitPath = require.resolve('express-rate-limit');
const cachePath = require.resolve('../../src/infra/lib/rate-limit-config-cache');

function withLimiterModule(env, fn) {
  const originalEnv = {
    RATE_LIMIT_SETUP_WINDOW_MS: process.env.RATE_LIMIT_SETUP_WINDOW_MS,
    RATE_LIMIT_SETUP_MAX: process.env.RATE_LIMIT_SETUP_MAX,
    DISABLE_RATE_LIMIT: process.env.DISABLE_RATE_LIMIT,
  };
  const originalRateLimit = require.cache[rateLimitPath];
  const calls = [];

  delete require.cache[limiterPath];
  require.cache[rateLimitPath] = {
    id: rateLimitPath,
    filename: rateLimitPath,
    loaded: true,
    exports: (options) => {
      calls.push(options);
      return (_req, _res, next) => next();
    },
  };

  for (const key of Object.keys(originalEnv)) delete process.env[key];
  Object.assign(process.env, env);

  try {
    const mod = require(limiterPath);
    fn({ mod, calls });
  } finally {
    delete require.cache[limiterPath];
    if (originalRateLimit) require.cache[rateLimitPath] = originalRateLimit;
    else delete require.cache[rateLimitPath];
    for (const [key, value] of Object.entries(originalEnv)) {
      if (value === undefined) delete process.env[key];
      else process.env[key] = value;
    }
  }
}

function withCountingLimiters(env, fn) {
  const originalEnv = {};
  for (const key of Object.keys(env)) {
    originalEnv[key] = process.env[key];
    process.env[key] = env[key];
  }
  originalEnv.DISABLE_RATE_LIMIT = process.env.DISABLE_RATE_LIMIT;
  delete process.env.DISABLE_RATE_LIMIT;
  const originalRateLimit = require.cache[rateLimitPath];
  const originalCache = require.cache[cachePath];
  const buckets = [];
  delete require.cache[limiterPath];

  // Stub the cache so the snapshot is all-null → env/default path is exercised
  // (DB override is tested separately in limiters-resolve-rate-limit.test.js).
  require.cache[cachePath] = {
    id: cachePath, filename: cachePath, loaded: true,
    exports: {
      getRateLimitSnapshot: () => ({ general: null, connectorFetch: null, connectorWrite: null, auditSearch: null }),
      maybeRefresh: () => {},
      seedAtBoot: async () => {},
    },
  };

  const mockRateLimitFn = (options) => {
    const bucket = new Map();
    buckets.push({ options, bucket });
    return (req, res, next) => {
      if (options.skip?.(req, res)) return next();
      const key = req.ip || '127.0.0.1';
      const count = (bucket.get(key) || 0) + 1;
      bucket.set(key, count);
      // max may be a function (DB-snapshot-aware) or a static number.
      const maxVal = typeof options.max === 'function' ? options.max() : options.max;
      if (count > maxVal) {
        res.statusCode = 429;
        res.body = options.message;
        return undefined;
      }
      return next();
    };
  };
  // Expose ipKeyGenerator so modules that destructure it (e.g. limiters.js)
  // get a usable function rather than undefined under the mock.
  mockRateLimitFn.ipKeyGenerator = (ip) => (ip ? `ip:${ip}` : 'ip:unknown');
  require.cache[rateLimitPath] = {
    id: rateLimitPath,
    filename: rateLimitPath,
    loaded: true,
    exports: mockRateLimitFn,
  };

  try {
    const limiters = require(limiterPath);
    fn({ limiters, makeApp: createMiddlewareHarness, buckets });
  } finally {
    delete require.cache[limiterPath];
    if (originalRateLimit) require.cache[rateLimitPath] = originalRateLimit;
    else delete require.cache[rateLimitPath];
    if (originalCache) require.cache[cachePath] = originalCache;
    else delete require.cache[cachePath];
    for (const [key, value] of Object.entries(originalEnv)) {
      if (value === undefined) delete process.env[key];
      else process.env[key] = value;
    }
  }
}

function createMiddlewareHarness() {
  const stack = [];
  return {
    use(path, middleware) {
      stack.push({ path, middleware });
    },
    request(originalPath, { user, method = 'GET' } = {}) {
      const req = {
        originalUrl: originalPath,
        path: originalPath,
        method,
        ip: '127.0.0.1',
        user: user || null,
        session: null,
        headers: {},
      };
      const res = {
        statusCode: 204,
        body: null,
        setHeader() {},
        getHeader() { return undefined; },
        end() {},
        json(body) { this.body = body; return this; },
        status(code) { this.statusCode = code; return this; },
      };
      let index = 0;
      function next() {
        const layer = stack[index++];
        if (!layer || res.statusCode === 429) return;
        if (!originalPath.startsWith(layer.path)) return next();
        // Express only invokes 4-arg (error-handling) middleware when an error
        // is in flight; this harness has no error path, so skip them as Express
        // would for a normal request.
        if (layer.middleware.length >= 4) return next();
        const priorPath = req.path;
        req.path = originalPath.slice(layer.path.length - (layer.path.endsWith('/') ? 1 : 0)) || '/';
        layer.middleware(req, res, next);
        req.path = priorPath;
      }
      next();
      return res.statusCode;
    },
  };
}

function repeat(count, fn) {
  const statuses = [];
  for (let i = 0; i < count; i++) {
    statuses.push(fn(i));
  }
  return statuses;
}

test('setupLimiter uses default setup rate limit budget when env is unset', () => {
  withLimiterModule({}, ({ calls }) => {
    assert.equal(calls.length, 1);
    assert.equal(calls[0].windowMs, 5 * 60 * 1000);
    assert.equal(calls[0].max, 10);
  });
});

test('setupLimiter honours setup-specific env overrides', () => {
  withLimiterModule(
    {
      RATE_LIMIT_SETUP_WINDOW_MS: '120000',
      RATE_LIMIT_SETUP_MAX: '3',
    },
    ({ calls }) => {
      assert.equal(calls.length, 1);
      assert.equal(calls[0].windowMs, 120000);
      assert.equal(calls[0].max, 3);
    },
  );
});

// readPositive backstop (NOT a production-reachable fallback — a 0 window is
// authoritatively rejected at boot by the `.positive()` Zod guard; see the
// config-schema test). This asserts the defense-in-depth layer that covers
// SKIP_CONFIG_VALIDATION dev boots: a nonpositive window coerces to the 5-min
// default so the limiter is never built with an illegal windowMs. The
// zero-means-block-all semantic belongs to MAX only, never the window.
test('setupLimiter readPositive backstop coerces a nonpositive window to the default', () => {
  withLimiterModule(
    { RATE_LIMIT_SETUP_WINDOW_MS: '0' },
    ({ calls }) => {
      assert.equal(calls.length, 1);
      assert.equal(calls[0].windowMs, 5 * 60 * 1000);
    },
  );
});

test('generalLimiter throttles the 201st unauthenticated request', () => {
  withCountingLimiters(
    {
      RATE_LIMIT_GENERAL_WINDOW_MS: '60000',
      RATE_LIMIT_GENERAL_MAX: '200',
    },
    ({ limiters, makeApp }) => {
      const app = makeApp();
      limiters.mountAuthenticatedLimiters(app);
      const statuses = repeat(201, () => app.request('/api/ping'));
      assert.equal(statuses.slice(0, 200).every((status) => status === 204), true);
      assert.equal(statuses[200], 429);
    },
  );
});

test('generalLimiter bypasses authenticated requests', () => {
  withCountingLimiters(
    {
      RATE_LIMIT_GENERAL_WINDOW_MS: '60000',
      RATE_LIMIT_GENERAL_MAX: '200',
    },
    ({ limiters, makeApp }) => {
      const app = makeApp();
      limiters.mountAuthenticatedLimiters(app);
      const statuses = repeat(201, () => app.request('/api/ping', { user: { id: 'u1' } }));
      assert.equal(statuses.every((status) => status === 204), true);
    },
  );
});

test('db-status uses statusLimiter instead of the general bucket', () => {
  withCountingLimiters(
    {
      RATE_LIMIT_GENERAL_WINDOW_MS: '60000',
      RATE_LIMIT_GENERAL_MAX: '1',
      RATE_LIMIT_STATUS_MAX: '300',
    },
    ({ limiters, makeApp }) => {
      const app = makeApp();
      limiters.mountAuthenticatedLimiters(app);
      assert.equal(app.request('/api/other'), 204);
      assert.equal(app.request('/api/other'), 429);
      assert.equal(app.request('/api/setup/db-status'), 204);
    },
  );
});

// SECURITY / config: setupLimiter now uses the guarded readLimit, so an
// explicit RATE_LIMIT_SETUP_MAX=0 is honored fail-closed (express-rate-limit v8
// treats max:0 as block-all — 429 on the first call, NOT "no limiter") instead
// of the old `Number(env) || 10` shape silently restoring 10.
test('setupLimiter honours RATE_LIMIT_SETUP_MAX=0 (0 blocks all setup traffic, fail-closed)', () => {
  withCountingLimiters(
    { RATE_LIMIT_SETUP_MAX: '0' },
    ({ limiters, makeApp }) => {
      const app = makeApp();
      limiters.mountPreAuthLimiters(app);
      // First setup POST is already over the 0 budget → 429. The pre-readLimit
      // `Number('0') || 10` would have allowed 10 through here.
      assert.equal(app.request('/api/setup/test-db', { method: 'POST' }), 429);
    },
  );
});

test('setupLimiter covers setup mutations without throttling db-status', () => {
  withCountingLimiters(
    {
      RATE_LIMIT_SETUP_WINDOW_MS: '60000',
      RATE_LIMIT_SETUP_MAX: '1',
    },
    ({ limiters, makeApp }) => {
      const app = makeApp();
      limiters.mountPreAuthLimiters(app);
      assert.equal(app.request('/api/setup/test-db', { method: 'POST' }), 204);
      assert.equal(app.request('/api/setup/test-db', { method: 'POST' }), 429);
      assert.equal(app.request('/api/setup/db-status'), 204);
    },
  );
});

test('authLoginLimiter still throttles authenticated login attempts', () => {
  withCountingLimiters(
    {
      RATE_LIMIT_AUTH_WINDOW_MS: '60000',
      RATE_LIMIT_AUTH_MAX: '20',
    },
    ({ limiters, makeApp }) => {
      const app = makeApp();
      limiters.mountPreAuthLimiters(app);
      const statuses = repeat(21, () => app.request('/api/auth/login', { user: { id: 'u1' } }));
      assert.equal(statuses.slice(0, 20).every((status) => status === 204), true);
      assert.equal(statuses[20], 429);
    },
  );
});

test('passwordLimiter still throttles authenticated password attempts', () => {
  withCountingLimiters(
    {
      RATE_LIMIT_PASSWORD_WINDOW_MS: '60000',
      RATE_LIMIT_PASSWORD_MAX: '5',
    },
    ({ limiters, makeApp }) => {
      const app = makeApp();
      limiters.mountPreAuthLimiters(app);
      const statuses = repeat(6, () => app.request('/api/auth/change-password', { user: { id: 'u1' } }));
      assert.equal(statuses.slice(0, 5).every((status) => status === 204), true);
      assert.equal(statuses[5], 429);
    },
  );
});

// SECURITY (v3.2.86): destructiveOpsLimiter must NOT bypass authenticated
// requests. Combined with the v3.2.86 'unsafe-eval' relaxation, a stolen
// admin token would otherwise allow unbounded XSS-eval-chained destructive
// calls on /api/sync-schema/{clear,truncate,drop}-table. These tests guard
// against a future refactor that re-introduces a `skip` function on this
// limiter and silently restores the pre-v3.2.86 unbounded-admin behavior.
test('destructiveOpsLimiter throttles authenticated admin after default budget on /api/sync-schema/clear-table', () => {
  withCountingLimiters(
    {
      RATE_LIMIT_DESTRUCTIVE_WINDOW_MS: '900000',
      RATE_LIMIT_DESTRUCTIVE_MAX: '5',
    },
    ({ limiters, makeApp }) => {
      const app = makeApp();
      limiters.mountAuthenticatedLimiters(app);
      const statuses = repeat(6, () =>
        app.request('/api/sync-schema/clear-table', {
          user: { id: 'admin1' },
          method: 'POST',
        }),
      );
      assert.equal(
        statuses.slice(0, 5).every((s) => s === 204),
        true,
        'first 5 destructive calls must succeed',
      );
      assert.equal(statuses[5], 429, '6th destructive call must be rate-limited even for authenticated admin');
    },
  );
});

// SECURITY: the admin feature-audit search/list surface runs a LIKE %q% scan
// and is admin-only, so it bypasses generalLimiter's authenticated-skip. A
// stolen admin token could otherwise hammer the full-scan unbounded. These
// guard the dedicated auditSearchLimiter (per-user budget, mounted before the
// general /api/ limiter) against a refactor that drops it.
test('auditSearchLimiter throttles authenticated admin after budget on /api/admin/feature-audit', () => {
  withCountingLimiters(
    {
      RATE_LIMIT_AUDIT_SEARCH_WINDOW_MS: '60000',
      RATE_LIMIT_AUDIT_SEARCH_MAX: '5',
      RATE_LIMIT_GENERAL_MAX: '2000',
    },
    ({ limiters, makeApp }) => {
      const app = makeApp();
      limiters.mountAuthenticatedLimiters(app);
      const statuses = repeat(6, () =>
        app.request('/api/admin/feature-audit?q=cleanup', { user: { id: 'admin1' }, method: 'GET' }),
      );
      assert.equal(statuses.slice(0, 5).every((s) => s === 204), true, 'first 5 audit reads must succeed');
      assert.equal(statuses[5], 429, '6th audit read must be rate-limited even for authenticated admin');
    },
  );
});

test('auditSearchLimiter has no skip function (authenticated bypass must stay closed)', () => {
  withCountingLimiters(
    { RATE_LIMIT_AUDIT_SEARCH_MAX: '63' },
    ({ limiters, makeApp, buckets }) => {
      const app = makeApp();
      limiters.mountAuthenticatedLimiters(app);
      const auditBucket = buckets.find((b) => {
        const v = typeof b.options.max === 'function' ? b.options.max() : b.options.max;
        return v === 63;
      });
      assert.ok(auditBucket, 'auditSearchLimiter must be registered');
      assert.equal(
        auditBucket.options.skip,
        undefined,
        'auditSearchLimiter MUST NOT have a skip — authenticated bypass would re-open the uncapped admin full-scan',
      );
    },
  );
});

test('auditSearchLimiter keyGenerator is per-user with ip fallback', () => {
  withCountingLimiters(
    { RATE_LIMIT_AUDIT_SEARCH_MAX: '63' },
    ({ limiters, makeApp, buckets }) => {
      const app = makeApp();
      limiters.mountAuthenticatedLimiters(app);
      const auditBucket = buckets.find((b) => {
        const v = typeof b.options.max === 'function' ? b.options.max() : b.options.max;
        return v === 63;
      });
      assert.ok(auditBucket, 'auditSearchLimiter must be registered');
      assert.strictEqual(typeof auditBucket.options.keyGenerator, 'function',
        'auditSearchLimiter must define a keyGenerator so one compromised admin cannot starve others');
      assert.match(auditBucket.options.keyGenerator({ user: { id: 'u9' }, ip: '10.0.0.1' }), /u9/,
        'keyGenerator must embed user id when present');
      assert.match(auditBucket.options.keyGenerator({ user: null, ip: '10.0.0.2' }), /ip:/,
        'keyGenerator must fall back to ip: when no user id');
    },
  );
});

test('auditSearchLimiter budget covers the /event-types sub-path of the same mount', () => {
  withCountingLimiters(
    {
      RATE_LIMIT_AUDIT_SEARCH_WINDOW_MS: '60000',
      RATE_LIMIT_AUDIT_SEARCH_MAX: '2',
      RATE_LIMIT_GENERAL_MAX: '2000',
    },
    ({ limiters, makeApp }) => {
      const app = makeApp();
      limiters.mountAuthenticatedLimiters(app);
      assert.equal(app.request('/api/admin/feature-audit', { user: { id: 'a' }, method: 'GET' }), 204);
      assert.equal(app.request('/api/admin/feature-audit/event-types', { user: { id: 'a' }, method: 'GET' }), 204);
      // 3rd request on the shared mount budget is rejected.
      assert.equal(app.request('/api/admin/feature-audit?q=x', { user: { id: 'a' }, method: 'GET' }), 429);
    },
  );
});

// SECURITY: /api/query-proxy runs arbitrary admin SQL (incl. DDL) and
// /api/admin/privileges manages MariaDB grants. Both are admin-only, so they
// bypass generalLimiter's authenticated-skip. A stolen admin token could
// otherwise drive them unbounded. These guard the dedicated adminOpsLimiter
// (one shared per-user budget across both mounts, before the general /api/
// limiter) against a refactor that drops it.
test('adminOpsLimiter throttles authenticated admin after budget on /api/query-proxy', () => {
  withCountingLimiters(
    { RATE_LIMIT_ADMIN_OPS_MAX: '5', RATE_LIMIT_GENERAL_MAX: '2000' },
    ({ limiters, makeApp }) => {
      const app = makeApp();
      limiters.mountAuthenticatedLimiters(app);
      const statuses = repeat(6, () =>
        app.request('/api/query-proxy', { user: { id: 'admin1' }, method: 'POST' }),
      );
      assert.equal(statuses.slice(0, 5).every((s) => s === 204), true, 'first 5 query-proxy calls must succeed');
      assert.equal(statuses[5], 429, '6th query-proxy call must be rate-limited even for authenticated admin');
    },
  );
});

test('adminOpsLimiter shares one budget across query-proxy and admin/privileges', () => {
  withCountingLimiters(
    { RATE_LIMIT_ADMIN_OPS_MAX: '2', RATE_LIMIT_GENERAL_MAX: '2000' },
    ({ limiters, makeApp }) => {
      const app = makeApp();
      limiters.mountAuthenticatedLimiters(app);
      assert.equal(app.request('/api/query-proxy', { user: { id: 'a' }, method: 'POST' }), 204);
      assert.equal(app.request('/api/admin/privileges/users', { user: { id: 'a' }, method: 'GET' }), 204);
      // 3rd request on the shared mount budget (either path) is rejected.
      assert.equal(app.request('/api/admin/privileges/grants/root', { user: { id: 'a' }, method: 'GET' }), 429);
    },
  );
});

test('adminOpsLimiter has no skip function (authenticated bypass must stay closed)', () => {
  withCountingLimiters(
    { RATE_LIMIT_ADMIN_OPS_MAX: '47' },
    ({ limiters, makeApp, buckets }) => {
      const app = makeApp();
      limiters.mountAuthenticatedLimiters(app);
      const adminBucket = buckets.find((b) => {
        const v = typeof b.options.max === 'function' ? b.options.max() : b.options.max;
        return v === 47;
      });
      assert.ok(adminBucket, 'adminOpsLimiter must be registered');
      assert.equal(
        adminBucket.options.skip,
        undefined,
        'adminOpsLimiter MUST NOT have a skip — authenticated bypass would re-open the uncapped admin routes',
      );
    },
  );
});

test('adminOpsLimiter keyGenerator is per-user with ip fallback', () => {
  withCountingLimiters(
    { RATE_LIMIT_ADMIN_OPS_MAX: '47' },
    ({ limiters, makeApp, buckets }) => {
      const app = makeApp();
      limiters.mountAuthenticatedLimiters(app);
      const adminBucket = buckets.find((b) => {
        const v = typeof b.options.max === 'function' ? b.options.max() : b.options.max;
        return v === 47;
      });
      assert.ok(adminBucket, 'adminOpsLimiter must be registered');
      assert.strictEqual(typeof adminBucket.options.keyGenerator, 'function',
        'adminOpsLimiter must define a keyGenerator so one compromised admin cannot starve others');
      assert.match(adminBucket.options.keyGenerator({ user: { id: 'u9' }, ip: '10.0.0.1' }), /u9/,
        'keyGenerator must embed user id when present');
      assert.match(adminBucket.options.keyGenerator({ user: null, ip: '10.0.0.2' }), /ip:/,
        'keyGenerator must fall back to ip: when no user id');
    },
  );
});

test('destructiveOpsLimiter budget is shared across clear-table / truncate-table / drop-table', () => {
  withCountingLimiters(
    {
      RATE_LIMIT_DESTRUCTIVE_WINDOW_MS: '900000',
      RATE_LIMIT_DESTRUCTIVE_MAX: '3',
    },
    ({ limiters, makeApp }) => {
      const app = makeApp();
      limiters.mountAuthenticatedLimiters(app);
      assert.equal(
        app.request('/api/sync-schema/clear-table', { user: { id: 'a' }, method: 'POST' }),
        204,
      );
      assert.equal(
        app.request('/api/sync-schema/truncate-table', { user: { id: 'a' }, method: 'POST' }),
        204,
      );
      assert.equal(
        app.request('/api/sync-schema/drop-table', { user: { id: 'a' }, method: 'POST' }),
        204,
      );
      // Budget exhausted across the three paths — admin cannot circumvent by switching destructive op.
      assert.equal(
        app.request('/api/sync-schema/clear-table', { user: { id: 'a' }, method: 'POST' }),
        429,
      );
    },
  );
});

test('destructiveOpsLimiter has no skip function (the bypass that would re-open v3.2.86 attack window)', () => {
  withCountingLimiters(
    {
      RATE_LIMIT_DESTRUCTIVE_WINDOW_MS: '900000',
      RATE_LIMIT_DESTRUCTIVE_MAX: '5',
    },
    ({ limiters, makeApp, buckets }) => {
      const app = makeApp();
      limiters.mountAuthenticatedLimiters(app);
      // The destructive limiter is identifiable by its 5-call max budget.
      const destructive = buckets.find((b) => b.options.max === 5);
      assert.ok(destructive, 'destructiveOpsLimiter must be registered');
      assert.equal(
        destructive.options.skip,
        undefined,
        'destructiveOpsLimiter MUST NOT have a skip function — that would re-introduce the authenticated bypass',
      );
    },
  );
});

test('readLimit honours RATE_LIMIT_*_MAX=0 instead of falling back to default', () => {
  withCountingLimiters(
    {
      RATE_LIMIT_GENERAL_WINDOW_MS: '60000',
      RATE_LIMIT_GENERAL_MAX: '0',
    },
    ({ limiters, makeApp }) => {
      const app = makeApp();
      limiters.mountAuthenticatedLimiters(app);
      // 0 must mean "block everything" — without the readLimit guard, the
      // earlier `Number(env) || default` shape would silently restore 2000.
      assert.equal(app.request('/api/anything'), 429);
    },
  );
});

test('readLimit ignores non-numeric RATE_LIMIT_*_MAX and uses default', () => {
  withCountingLimiters(
    {
      RATE_LIMIT_GENERAL_WINDOW_MS: '60000',
      RATE_LIMIT_GENERAL_MAX: 'not-a-number',
    },
    ({ limiters, makeApp, buckets }) => {
      const app = makeApp();
      limiters.mountAuthenticatedLimiters(app);
      app.request('/api/anything');
      // generalLimiter is the last bucket created in mountAuthenticatedLimiters.
      // max is now a function (DB-snapshot-aware); resolve it to check the value.
      const general = buckets[buckets.length - 1];
      const maxVal = typeof general.options.max === 'function' ? general.options.max() : general.options.max;
      assert.equal(maxVal, 2000);
    },
  );
});

// ── connectorFetchLimiter (P4) ────────────────────────────────────────────────

// SECURITY: POST /:id/fetch is non-admin (any authed data-entry user) so it
// bypasses generalLimiter's authenticated-skip. Without its own budget, a
// single token could drive unbounded outbound calls. These tests guard against
// a future refactor silently removing that budget.

test('connectorFetchLimiter throttles POST /api/api-connectors/:id/fetch after budget', () => {
  withCountingLimiters(
    {
      RATE_LIMIT_CONNECTOR_FETCH_WINDOW_MS: '60000',
      RATE_LIMIT_CONNECTOR_FETCH_MAX: '2',
    },
    ({ limiters, makeApp }) => {
      const app = makeApp();
      limiters.mountAuthenticatedLimiters(app);
      assert.equal(app.request('/api/api-connectors/c1/fetch', { user: { id: 'u1' }, method: 'POST' }), 204);
      assert.equal(app.request('/api/api-connectors/c1/fetch', { user: { id: 'u1' }, method: 'POST' }), 204);
      assert.equal(app.request('/api/api-connectors/c1/fetch', { user: { id: 'u1' }, method: 'POST' }), 429,
        '3rd POST /fetch must be rate-limited');
    },
  );
});

test('connectorFetchLimiter does not throttle GET /api/api-connectors/usable', () => {
  withCountingLimiters(
    {
      RATE_LIMIT_CONNECTOR_FETCH_WINDOW_MS: '60000',
      RATE_LIMIT_CONNECTOR_FETCH_MAX: '1',
    },
    ({ limiters, makeApp }) => {
      const app = makeApp();
      limiters.mountAuthenticatedLimiters(app);
      // Budget is 1, but GET /usable must never consume it.
      assert.equal(app.request('/api/api-connectors/usable', { user: { id: 'u1' }, method: 'GET' }), 204);
      assert.equal(app.request('/api/api-connectors/usable', { user: { id: 'u1' }, method: 'GET' }), 204,
        '2nd GET /usable must not be rate-limited');
    },
  );
});

test('connectorFetchLimiter has no skip function (authenticated bypass must stay closed)', () => {
  withCountingLimiters(
    {
      RATE_LIMIT_CONNECTOR_FETCH_WINDOW_MS: '60000',
      RATE_LIMIT_CONNECTOR_FETCH_MAX: '60',
    },
    ({ limiters, makeApp, buckets }) => {
      const app = makeApp();
      limiters.mountAuthenticatedLimiters(app);
      const fetchBucket = buckets.find((b) => {
        const v = typeof b.options.max === 'function' ? b.options.max() : b.options.max;
        return v === 60 && !b.options.skip;
      });
      assert.ok(fetchBucket, 'connectorFetchLimiter must be registered');
      assert.equal(
        fetchBucket.options.skip,
        undefined,
        'connectorFetchLimiter MUST NOT have a skip function — authenticated bypass would allow unbounded outbound calls',
      );
    },
  );
});

// ── failedResolveIpLimiter (Public Integration API pre-auth brute-force guard) ─

// SECURITY: Auth v2 has no token endpoint; the pre-auth guard caps repeated
// FAILED resolves per source IP and must NOT inherit bypassWhenAuthenticated.
test('failedResolveIpLimiter throttles repeated requests after budget (counting mock)', () => {
  withCountingLimiters(
    {
      RATE_LIMIT_PUBLIC_RESOLVE_FAIL_WINDOW_MS: '900000',
      RATE_LIMIT_PUBLIC_RESOLVE_FAIL_MAX: '2',
    },
    ({ limiters, makeApp }) => {
      const app = makeApp();
      limiters.mountPreAuthLimiters(app);
      assert.equal(app.request('/api/public/v1/blueprints'), 204);
      assert.equal(app.request('/api/public/v1/blueprints'), 204);
      assert.equal(app.request('/api/public/v1/blueprints'), 429,
        'requests past the per-IP budget must be rate-limited');
    },
  );
});

test('failedResolveIpLimiter: ip-only key, skip-successful, no authenticated bypass, public 429', () => {
  withCountingLimiters(
    { RATE_LIMIT_PUBLIC_RESOLVE_FAIL_MAX: '41' },
    ({ limiters, makeApp, buckets }) => {
      const app = makeApp();
      limiters.mountPreAuthLimiters(app);
      const bucket = buckets.find((b) => b.options.max === 41);
      assert.ok(bucket, 'failedResolveIpLimiter must be registered');
      // Only 4xx (invalid token) burns budget; a successful read is refunded.
      assert.equal(bucket.options.skipSuccessfulRequests, true,
        'only failed resolves may consume the budget');
      // No authenticated bypass — machine traffic must never inherit the human skip.
      assert.equal(bucket.options.skip, undefined,
        'failedResolveIpLimiter MUST NOT have a skip');
      assert.equal(bucket.options.standardHeaders, true, 'must emit RateLimit-*/Retry-After');
      // Keyed on ip alone — no client identity, no per-token key.
      const key = bucket.options.keyGenerator({ ip: '10.0.0.9' });
      assert.match(key, /10\.0\.0\.9/, 'key must embed the ip');
      assert.equal(typeof bucket.options.handler, 'function',
        'public-model 429 must go through the handler (no internal apiError meta)');
    },
  );
});

test('connectorFetchLimiter keyGenerator falls back to ip when no user id is present', () => {
  withCountingLimiters(
    {
      RATE_LIMIT_CONNECTOR_FETCH_WINDOW_MS: '60000',
      RATE_LIMIT_CONNECTOR_FETCH_MAX: '60',
    },
    ({ limiters, makeApp, buckets }) => {
      const app = makeApp();
      limiters.mountAuthenticatedLimiters(app);
      const fetchBucket = buckets.find((b) => {
        const v = typeof b.options.max === 'function' ? b.options.max() : b.options.max;
        return v === 60 && !b.options.skip;
      });
      assert.ok(fetchBucket, 'connectorFetchLimiter must be registered');
      assert.strictEqual(typeof fetchBucket.options.keyGenerator, 'function',
        'connectorFetchLimiter must define a keyGenerator for per-user keying');
      // User-id present → key contains the user id.
      const reqWithUser = { user: { id: 'u42' }, ip: '10.0.0.1' };
      assert.match(fetchBucket.options.keyGenerator(reqWithUser), /u42/,
        'keyGenerator must embed user id when req.user.id is present');
      // No user → key contains ip (fallback).
      const reqNoUser = { user: null, ip: '10.0.0.2' };
      const fallbackKey = fetchBucket.options.keyGenerator(reqNoUser);
      assert.match(fallbackKey, /ip:/,
        'keyGenerator must fall back to ip: prefix when no user id is available');
    },
  );
});
