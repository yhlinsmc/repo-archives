/**
 * flow-recipe-steps-serializer.test.js
 *
 * Pins the field-level secret handling for flow_recipe_steps: encrypt-on-write,
 * mask-on-read, decrypt round-trip, and the mask-preserve-on-update behaviour
 * (an unchanged `****` secret must keep the stored ciphertext, never overwrite
 * it with the mask). The db module is mocked via require.cache so the stored
 * read-back can be exercised without a live database (same pattern as
 * api-connector-serializer.test.js).
 */
const { describe, it, before, beforeEach } = require('node:test');
const assert = require('node:assert/strict');

// settings-crypto reads SETTINGS_ENCRYPTION_KEY per call; set it before the
// serializer (and the crypto module) are first required.
process.env.SETTINGS_ENCRYPTION_KEY = 'unit-test-key-do-not-use-in-prod';

const dbKey = require.resolve('../../src/edge/db');
let storedRows = [];
const poolSpy = {
  ro: {
    async query() { return storedRows; },
  },
};
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: poolSpy, t: (name) => `fmb_${name}` },
};

const ser = require('../../src/edge/routes/app/flow-recipe-steps/serializer');
const { encrypt } = require('../../src/shared/lib/settings-crypto');

const ENC = 'enc:v1:';

describe('flow-recipe-steps serializer — pure transforms', () => {
  it('encrypts the bearer token leaf, decrypt round-trips, mask hides it', () => {
    const enc = ser.encryptAuthConfig({ token: 'sk-secret' }, 'bearer');
    assert.ok(enc.token.startsWith(ENC), 'token must be encrypted');
    assert.equal(ser.decryptAuthConfig(enc, 'bearer').token, 'sk-secret');
    assert.equal(ser.maskAuthConfig(enc, 'bearer').token, '****');
  });

  it('encrypts only the api_key value, never the header name', () => {
    const enc = ser.encryptAuthConfig({ header: 'X-API-Key', value: 'abc123' }, 'api_key');
    assert.equal(enc.header, 'X-API-Key');
    assert.ok(enc.value.startsWith(ENC));
    assert.equal(ser.maskAuthConfig(enc, 'api_key').value, '****');
    assert.equal(ser.maskAuthConfig(enc, 'api_key').header, 'X-API-Key');
  });

  it('encrypts only the basic password, never the username', () => {
    const enc = ser.encryptAuthConfig({ username: 'bob', password: 'hunter2' }, 'basic');
    assert.equal(enc.username, 'bob');
    assert.ok(enc.password.startsWith(ENC));
    assert.equal(ser.decryptAuthConfig(enc, 'basic').password, 'hunter2');
  });

  it('auth_type none has no sensitive leaf', () => {
    assert.deepEqual(ser.encryptAuthConfig({}, 'none'), {});
  });

  it('encrypt is idempotent (an already-encrypted leaf is not double-wrapped)', () => {
    const once = ser.encryptAuthConfig({ token: 'x' }, 'bearer');
    const twice = ser.encryptAuthConfig(once, 'bearer');
    assert.equal(twice.token, once.token);
  });
});

describe('flow-recipe-steps serializer — hooks', () => {
  it('serializeWrite (create) encrypts and never reads the pool', async () => {
    const out = await ser.serializeWrite(
      { auth_type: 'bearer', auth_config: { token: 'plain' } },
      { isUpdate: false, id: 'new' },
    );
    assert.ok(out.auth_config.token.startsWith(ENC));
  });

  it('serializeRead masks the stored ciphertext for the API response', () => {
    const stored = { auth_type: 'bearer', auth_config: { token: encrypt('zzz') }, name: 's1' };
    const out = ser.serializeRead(stored);
    assert.equal(out.auth_config.token, '****');
    assert.equal(out.name, 's1');
  });

  it('serializeRead does NOT strip approved_by/approved_at (approval is on the recipe, not the step)', () => {
    // Steps have no approval columns — this serializer must not delete fields
    // that are not its concern (a future step enrichment could add them).
    const stored = {
      auth_type: 'none', auth_config: null, name: 's1',
      approved_by: 'admin-user-id', approved_at: '2026-06-27T00:00:00Z',
    };
    const out = ser.serializeRead(stored);
    assert.equal(out.approved_by, 'admin-user-id');
    assert.equal(out.approved_at, '2026-06-27T00:00:00Z');
    assert.equal(out.name, 's1');
  });

  it('full round-trip: write → stored ciphertext → decryptRow recovers plaintext', async () => {
    const written = await ser.serializeWrite(
      { auth_type: 'basic', auth_config: { username: 'u', password: 'p@ss' } },
      { isUpdate: false },
    );
    const recovered = ser.decryptRow({ auth_type: 'basic', auth_config: written.auth_config });
    assert.equal(recovered.auth_config.password, 'p@ss');
    assert.equal(recovered.auth_config.username, 'u');
  });

  it('serializeWrite passes through a body that carries no auth_config', async () => {
    const body = { name: 'rename only', is_active: false };
    const out = await ser.serializeWrite(body, { isUpdate: true, id: 'x' });
    assert.deepEqual(out, body);
  });

  it('(f) POST auth_type none with stray token → token stripped; serializeRead exposes no secret', async () => {
    // SECURITY: auth_type='none' has no sensitive leaf — a token in auth_config
    // must be stripped (not persisted unencrypted) and must not appear in the
    // API response even if somehow stored.
    const out = await ser.serializeWrite(
      { auth_type: 'none', auth_config: { token: 'x' } },
      { isUpdate: false },
    );
    assert.equal('token' in (out.auth_config || {}), false, 'token must be stripped for auth_type none');
    const masked = ser.serializeRead({ auth_type: 'none', auth_config: out.auth_config });
    assert.equal('token' in (masked.auth_config || {}), false, 'serializeRead must not expose stray token');
  });

  it('(g) POST auth_type basic with stray token → token stripped, password encrypted', async () => {
    // SECURITY: only `password` is the sensitive leaf for basic auth; a `token`
    // key in auth_config must be stripped to prevent cross-type leakage.
    const out = await ser.serializeWrite(
      { auth_type: 'basic', auth_config: { username: 'u', password: 'p', token: 'leak' } },
      { isUpdate: false },
    );
    assert.equal('token' in out.auth_config, false, 'stray token must be stripped for basic auth_type');
    assert.ok(out.auth_config.password.startsWith(ENC), 'password must be encrypted');
    assert.equal(out.auth_config.username, 'u', 'non-secret username must survive');
  });
});

describe('flow-recipe-steps serializer — mask-preserve on update', () => {
  beforeEach(() => { storedRows = []; });

  it('a `****` token is replaced by the stored ciphertext, not re-stored as the mask', async () => {
    const stored = encrypt('original-secret');
    storedRows = [{ auth_config: JSON.stringify({ token: stored }), auth_type: 'bearer' }];
    const out = await ser.serializeWrite(
      { auth_type: 'bearer', auth_config: { token: '****' } },
      { isUpdate: true, id: 's1' },
    );
    assert.equal(out.auth_config.token, stored, 'must keep the stored ciphertext');
    assert.equal(ser.decryptRow({ auth_type: 'bearer', auth_config: out.auth_config }).auth_config.token, 'original-secret');
  });

  it('a real new secret on update overwrites the stored one (encrypted)', async () => {
    storedRows = [{ auth_config: JSON.stringify({ token: encrypt('old') }), auth_type: 'bearer' }];
    const out = await ser.serializeWrite(
      { auth_type: 'bearer', auth_config: { token: 'brand-new' } },
      { isUpdate: true, id: 's1' },
    );
    assert.ok(out.auth_config.token.startsWith(ENC));
    assert.equal(ser.decryptRow({ auth_type: 'bearer', auth_config: out.auth_config }).auth_config.token, 'brand-new');
  });

  it('a `****` token with no stored secret drops the leaf (mask never persisted)', async () => {
    storedRows = [{ auth_config: JSON.stringify({}), auth_type: 'bearer' }];
    const out = await ser.serializeWrite(
      { auth_type: 'bearer', auth_config: { token: '****' } },
      { isUpdate: true, id: 's1' },
    );
    assert.equal('token' in out.auth_config, false, 'masked-with-no-prior must not persist "****"');
  });

  it('recovers auth_type from the stored row when the update body omits it', async () => {
    const stored = encrypt('kept');
    storedRows = [{ auth_config: JSON.stringify({ value: stored, header: 'X-Key' }), auth_type: 'api_key' }];
    const out = await ser.serializeWrite(
      { auth_config: { value: '****', header: 'X-Key' } },
      { isUpdate: true, id: 's1' },
    );
    assert.equal(out.auth_config.value, stored);
  });

  it('(h) PUT auth_type bearer→basic with no auth_config → stale token leaf cleared', async () => {
    // SECURITY: changing auth_type from bearer to basic without supplying a new
    // auth_config must strip the old token ciphertext so it cannot leak unmasked
    // through serializeRead (which would mask only the `password` leaf for basic).
    const stored = encrypt('bearer-token');
    storedRows = [{ auth_config: JSON.stringify({ token: stored }), auth_type: 'bearer' }];
    const out = await ser.serializeWrite(
      { auth_type: 'basic' }, // type-change only — no auth_config in body
      { isUpdate: true, id: 's1' },
    );
    assert.ok(out.auth_config !== undefined, 'auth_config must be set in the output');
    assert.equal('token' in (out.auth_config || {}), false, 'stale bearer token must be stripped on type change to basic');
  });
});

describe('flow-recipe-steps serializer — no encryption key', () => {
  let saved;
  before(() => { saved = process.env.SETTINGS_ENCRYPTION_KEY; });

  it('encryptAuthConfig is fail-closed: throws ENCRYPTION_KEY_MISSING rather than storing plaintext', () => {
    delete process.env.SETTINGS_ENCRYPTION_KEY;
    try {
      assert.throws(
        () => ser.encryptAuthConfig({ token: 'plain' }, 'bearer'),
        (err) => err && err.code === 'ENCRYPTION_KEY_MISSING',
        'a secret must never be persisted unencrypted',
      );
    } finally {
      process.env.SETTINGS_ENCRYPTION_KEY = saved;
    }
  });

  it('encryptAuthConfig with no sensitive leaf (auth_type none) does not require a key', () => {
    delete process.env.SETTINGS_ENCRYPTION_KEY;
    try {
      const out = ser.encryptAuthConfig({}, 'none');
      assert.deepEqual(out, {}, 'no secret leaf → nothing to encrypt → no throw');
    } finally {
      process.env.SETTINGS_ENCRYPTION_KEY = saved;
    }
  });
});
