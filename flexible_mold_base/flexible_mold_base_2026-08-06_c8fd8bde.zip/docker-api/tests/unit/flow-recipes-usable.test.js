/**
 * flow-recipes-usable.test.js
 *
 * Tests GET /usable?blueprint_id=<id>: narrow projection of approved+active
 * flow recipes for plain data-entry users (requireAuth, not requireAdminOrEditor).
 *
 * Harness mirrors flow-recipes-crud.test.js: real router against a mocked pool
 * injected via require.cache before requiring the router.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../src/edge/db');

// Per-test rows returned by the usable SELECT on fmb_flow_recipes.
let usableRows = [];
// When true the middleware omits req.user, triggering requireAuth → 401.
let skipAuth = false;
// Per-test caller role (used when skipAuth = false).
let role = 'user';

function makeConn() {
  return {
    async query(sql) {
      // Usable endpoint SELECT: narrow projection of fmb_flow_recipes
      if (/consumed_output_keys/.test(sql) && /fmb_flow_recipes/.test(sql)) {
        return usableRows;
      }
      // information_schema probe (CRUD factory schema introspection — not hit by
      // the usable handler itself, but may be triggered by other handlers if any
      // test accidentally hits a CRUD route. Return empty to let it fall through.)
      if (/information_schema/i.test(sql)) return [];
      if (/SELECT DATABASE\(\)/.test(sql)) return [{ db: 'testdb' }];
      return [];
    },
    release() {},
  };
}

const poolSpy = {
  ro: {
    async getConnection() { return makeConn(); },
    async query(sql, params) { return makeConn().query(sql, params); },
  },
  rw: {
    async getConnection() { return makeConn(); },
    async query(sql, params) { return makeConn().query(sql, params); },
  },
};

require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: poolSpy, t: (name) => `fmb_${name}` },
};

const router = require('../../src/edge/routes/app/flow-recipes');

let server; let base;
before(async () => {
  const app = express();
  app.use(express.json());
  // Inject req.user unless skipAuth is true (simulates unauthenticated caller).
  app.use((req, _res, next) => {
    if (!skipAuth) {
      req.user = { id: 'user-1', role, email: 'u@x' };
    }
    next();
  });
  app.use('/fr', router);
  server = http.createServer(app);
  await new Promise((r) => server.listen(0, r));
  base = `http://127.0.0.1:${server.address().port}`;
});
after(() => server && server.close());
beforeEach(() => { usableRows = []; skipAuth = false; role = 'user'; });

async function req(method, path, body) {
  const res = await fetch(`${base}${path}`, {
    method,
    headers: { 'content-type': 'application/json' },
    body: body ? JSON.stringify(body) : undefined,
  });
  const text = await res.text();
  let json;
  try { json = JSON.parse(text); } catch { json = text; }
  return { status: res.status, json };
}

describe('flow-recipes /usable — approved+active projection', () => {
  it('returns narrow projection of approved+active recipes with no owner/status/secret leak', async () => {
    // Seed with the sensitive columns a real SELECT could carry so the strip is
    // actually exercised — projecting the raw row would fail the leak loop below.
    usableRows = [{
      id: 'r1', name: 'A', description: '',
      payload_transform_code: 'CODE',
      consumed_output_keys: JSON.stringify(['k']),
      owner_id: 'someone-else', status: 'approved', url: 'https://x',
      auth_config: '{"secret":"S"}', review_note: 'ok', approved_by: 'admin-x',
    }];
    const { status, json } = await req('GET', '/fr/usable?blueprint_id=11111111-1111-1111-1111-111111111111');
    assert.equal(status, 200, `expected 200, got ${status}: ${JSON.stringify(json)}`);
    assert.ok(Array.isArray(json.data), 'response must have a data array');
    assert.equal(json.data.length, 1, 'must return one recipe row');
    const row = json.data[0];
    // Projection fields present.
    assert.equal(row.id, 'r1');
    assert.equal(row.name, 'A');
    assert.equal(row.description, '');
    assert.equal(row.payload_transform_code, 'CODE');
    assert.deepEqual(row.consumed_output_keys, ['k']);
    // Sensitive / admin-only field names AND their values must NOT appear.
    const s = JSON.stringify(json);
    for (const leak of ['owner_id', 'someone-else', 'auth_config', 'secret', 'url', 'review_note', 'approved_by']) {
      assert.ok(!s.includes(leak), `must not leak: ${leak}`);
    }
  });

  it('consumed_output_keys falls back to [] when DB value is null', async () => {
    usableRows = [{
      id: 'r2', name: 'B', description: null,
      payload_transform_code: null,
      consumed_output_keys: null,
    }];
    const { status, json } = await req('GET', '/fr/usable?blueprint_id=11111111-1111-1111-1111-111111111111');
    assert.equal(status, 200, `expected 200, got ${status}: ${JSON.stringify(json)}`);
    assert.deepEqual(json.data[0].consumed_output_keys, [], 'null consumed_output_keys must project as []');
  });

  it('returns empty data array when no recipes match', async () => {
    usableRows = [];
    const { status, json } = await req('GET', '/fr/usable?blueprint_id=11111111-1111-1111-1111-111111111111');
    assert.equal(status, 200, `expected 200, got ${status}`);
    assert.deepEqual(json.data, [], 'no-match must return empty array');
  });
});

describe('flow-recipes /usable — blueprint_id required', () => {
  it('returns 400 when blueprint_id query param is absent', async () => {
    const { status } = await req('GET', '/fr/usable');
    assert.equal(status, 400, `missing blueprint_id must return 400, got ${status}`);
  });

  it('returns 400 when blueprint_id is not a valid UUID', async () => {
    const { status } = await req('GET', '/fr/usable?blueprint_id=not-a-uuid');
    assert.equal(status, 400, `non-UUID blueprint_id must return 400, got ${status}`);
  });
});

describe('flow-recipes /usable — authentication required', () => {
  it('returns 401 when request carries no authenticated user', async () => {
    skipAuth = true;
    const { status } = await req('GET', '/fr/usable?blueprint_id=11111111-1111-1111-1111-111111111111');
    assert.equal(status, 401, `unauthenticated request must return 401, got ${status}`);
  });
});
