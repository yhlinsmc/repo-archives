const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

test('infra connector-fetch imports only shared/lib + infra/lib — never edge/ or a DB module', () => {
  const src = fs.readFileSync(path.join(__dirname, '../../src/infra/routes/connector-fetch.js'), 'utf8');
  const requires = [...src.matchAll(/require\(\s*['"]([^'"]+)['"]\s*\)/g)].map((m) => m[1]);
  assert.ok(requires.length > 0, 'expected at least one require');
  for (const r of requires) {
    assert.ok(!/(^|\/)edge\//.test(r), `forbidden edge import: ${r}`);
    assert.ok(!/\b(mariadb|mysql2|pg)\b/.test(r), `forbidden DB driver import: ${r}`);
    assert.ok(!/\/db$/.test(r), `forbidden DB module import: ${r}`);
  }
});
