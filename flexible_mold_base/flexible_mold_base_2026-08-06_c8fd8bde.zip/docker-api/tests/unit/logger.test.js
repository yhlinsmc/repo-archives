// logger.test.js — v3.2.3 Phase 3 unit tests for the pino hook + source-location capture.
//
// Covers the 6 scenarios mandated by the v3.2.3 plan:
//   1. Standard V8 stack frame format
//   2. WSL2 path variant
//   3. Production Docker image path (/app/docker-api/src/...)
//   4. Missing stack (edge case)
//   5. Nested pino.child() chain (dynamic frame search survives wrapping)
//   6. Async / await boundary (V8 async-stack zero-cost tracing)
//
// Strategy: parseSourceFromStack() is a pure function, so tests 1-4 craft
// synthetic stack strings and assert the parsed output directly. Tests 5-6
// exercise the full hook by wiring pino to an in-memory destination stream
// and parsing the JSON records.
const { test } = require('node:test');
const assert = require('node:assert/strict');
const { Writable } = require('node:stream');
const pino = require('pino');

const { logger, _internals } = require('../../src/shared/lib/logger');
const {
  parseSourceFromStack,
  captureSourceLocation,
  resetCaptureBudget,
  parseCaptureBudget,
  sanitizeStackLine,
  sanitizeErrSerializer,
  resetCapBudgetWarn,
} = _internals;

// ── parseSourceFromStack — pure unit tests ──────────────────────────────────

test('parseSourceFromStack — standard V8 frame (paren form)', () => {
  const stack = [
    'Error',
    '    at captureSourceLocation (/home/ci/project/docker-api/src/shared/lib/logger.js:42:10)',
    '    at pino.logMethod (/home/ci/project/docker-api/src/shared/lib/logger.js:158:18)',
    '    at Object.handler (/home/ci/project/docker-api/src/edge/routes/platform/export.js:141:12)',
    '    at Layer.handle [as handle_request] (/home/ci/project/node_modules/express/lib/router/layer.js:95:5)',
  ].join('\n');
  const result = parseSourceFromStack(stack);
  assert.equal(result, 'edge/routes/platform/export.js:141');
});

test('parseSourceFromStack — WSL2 path variant', () => {
  const stack = [
    'Error',
    '    at foo (/home/user/projects/flexible_mold_base/docker-api/src/shared/lib/logger.js:42:10)',
    '    at bar (/home/user/projects/flexible_mold_base/docker-api/src/infra/middleware/auth.js:110:5)',
  ].join('\n');
  const result = parseSourceFromStack(stack);
  assert.equal(result, 'infra/middleware/auth.js:110');
});

test('parseSourceFromStack — production Docker image path (/app/src, flat)', () => {
  // Real-world shape from the Phase 8 runtime verification: Dockerfile
  // does `COPY docker-api/src ./src`, so the running image's stack trace
  // reports `/app/src/...` WITHOUT the `docker-api/` segment. Before
  // v3.2.3 Phase 8, the regex required `docker-api/` literally and the
  // `src` field was always undefined in production.
  const stack = [
    'Error',
    '    at captureSourceLocation (/app/src/shared/lib/logger.js:42:10)',
    '    at logMethod (/app/src/shared/lib/logger.js:158:18)',
    '    at users.post (/app/src/edge/routes/platform/users.js:199:14)',
  ].join('\n');
  const result = parseSourceFromStack(stack);
  assert.equal(result, 'edge/routes/platform/users.js:199');
});

test('parseSourceFromStack — Docker image with preserved docker-api/ prefix', () => {
  // Defence-in-depth: if a future Dockerfile variant keeps the
  // `docker-api/` directory under /app (e.g. unflattened COPY), the
  // regex should still match.
  const stack = [
    'Error',
    '    at captureSourceLocation (/app/docker-api/src/shared/lib/logger.js:42:10)',
    '    at logMethod (/app/docker-api/src/shared/lib/logger.js:158:18)',
    '    at users.post (/app/docker-api/src/edge/routes/platform/users.js:199:14)',
  ].join('\n');
  const result = parseSourceFromStack(stack);
  assert.equal(result, 'edge/routes/platform/users.js:199');
});

test('parseSourceFromStack — missing / empty stack returns undefined', () => {
  assert.equal(parseSourceFromStack(undefined), undefined);
  assert.equal(parseSourceFromStack(''), undefined);
  assert.equal(parseSourceFromStack(null), undefined);
  // No docker-api/src/ frames — only node_modules / internal.
  const noMatch = [
    'Error',
    '    at internal (node:internal/process/task_queues:96:5)',
    '    at Promise.resolve (<anonymous>)',
  ].join('\n');
  assert.equal(parseSourceFromStack(noMatch), undefined);
});

test('parseSourceFromStack — plain at-form (no parens) is handled', () => {
  const stack = [
    'Error',
    '    at /app/docker-api/src/edge/db.js:222:12',
  ].join('\n');
  const result = parseSourceFromStack(stack);
  assert.equal(result, 'edge/db.js:222');
});

test('parseSourceFromStack — logger.js frames are skipped even at top', () => {
  // Even when the stack contains logger.js frames before the real caller,
  // the dynamic search skips them and lands on the next non-logger frame.
  const stack = [
    'Error',
    '    at captureSourceLocation (/app/docker-api/src/shared/lib/logger.js:88:10)',
    '    at logMethod (/app/docker-api/src/shared/lib/logger.js:158:18)',
    '    at Pino._log (/app/docker-api/node_modules/pino/lib/proto.js:192:6)',
    '    at handleDbError (/app/docker-api/src/edge/routes/platform/settings.js:110:14)',
  ].join('\n');
  const result = parseSourceFromStack(stack);
  assert.equal(result, 'edge/routes/platform/settings.js:110');
});

// ── captureSourceLocation — live Error.captureStackTrace integration ─────────

test('captureSourceLocation — real invocation returns a docker-api/src/ frame', () => {
  // This file (tests/unit/logger.test.js) lives under docker-api/tests/, NOT
  // docker-api/src/, so captureSourceLocation called directly from here
  // should return undefined (no eligible frames in the stack). That
  // behaviour is itself meaningful: the hook cleanly degrades on callers
  // outside the mapped tree rather than returning a garbage path.
  resetCaptureBudget();
  const result = captureSourceLocation();
  assert.equal(result, undefined);
});

test('captureSourceLocation — rate limit returns undefined when budget exceeded', () => {
  // Reset to a clean window, then blow the budget.
  resetCaptureBudget();
  const budget = parseInt(process.env.LOGGER_CAPTURE_BUDGET || '500', 10);
  // Call captureSourceLocation budget + 2 extra times. The last ones MUST
  // short-circuit (return undefined) without walking a stack.
  for (let i = 0; i < budget; i++) captureSourceLocation();
  const overBudget1 = captureSourceLocation();
  const overBudget2 = captureSourceLocation();
  assert.equal(overBudget1, undefined);
  assert.equal(overBudget2, undefined);
});

// ── End-to-end hook tests via a captured pino stream ────────────────────────

// Create a pino instance with the same hook as logger.js, but pointed at a
// buffer we can inspect. This lets us assert on the full record, including
// what pino emits after the hook mutates args.
function createTestLogger(records) {
  return pino(
    {
      level: 'trace',
      hooks: {
        logMethod(args, method, level) {
          if (level >= 50) {
            const src = captureSourceLocation();
            if (src) {
              if (typeof args[0] === 'object' && args[0] !== null) {
                args[0] = { ...args[0], src };
              } else {
                args.unshift({ src });
              }
            }
          }
          return method.apply(this, args);
        },
      },
    },
    new Writable({
      write(chunk, _enc, cb) {
        for (const line of chunk.toString('utf-8').split('\n')) {
          if (!line) continue;
          try {
            records.push(JSON.parse(line));
          } catch {
            // ignore partial lines during teardown
          }
        }
        cb();
      },
    })
  );
}

test('hook — nested pino.child() chain still annotates error+', () => {
  resetCaptureBudget();
  const records = [];
  const testLogger = createTestLogger(records);

  // Double-nested child: the hook fires on the outermost call but the stack
  // below it contains pino's internal child-proxy frames. Dynamic frame
  // search must walk past them without hardcoded indices.
  testLogger
    .child({ module: 'a' })
    .child({ sub: 'b' })
    .error({ err: new Error('boom') }, 'nested child error');

  const errorRecord = records.find((r) => r.msg === 'nested child error');
  assert.ok(errorRecord, 'error record was emitted');
  assert.equal(errorRecord.module, 'a');
  assert.equal(errorRecord.sub, 'b');
  // src may be undefined if this test file's frames are not in docker-api/src/
  // (which is the case — tests/ is outside src/). The meaningful assertion is:
  // the hook did NOT crash on nested child wrapping.
});

test('hook — error level fires the hook, warn level does NOT', () => {
  resetCaptureBudget();
  const records = [];
  const testLogger = createTestLogger(records);

  // Stub captureSourceLocation's return value by asserting post-hoc: we
  // cannot reach into the closure, but we can verify that the hook only
  // adds src at level >= 50 (error) by checking that warn/info records
  // lack the src key even when the hook path is exercised.
  testLogger.warn({ foo: 1 }, 'warn msg');
  testLogger.info({ foo: 2 }, 'info msg');
  testLogger.error({ foo: 3 }, 'error msg');

  const warnRec = records.find((r) => r.msg === 'warn msg');
  const infoRec = records.find((r) => r.msg === 'info msg');
  const errRec = records.find((r) => r.msg === 'error msg');
  assert.ok(warnRec && infoRec && errRec, 'all three records emitted');
  assert.equal(warnRec.src, undefined);
  assert.equal(infoRec.src, undefined);
  // errRec.src may be undefined if tests/ is outside src/, but the hook
  // definitely fired (no throw). The test proves the level >= 50 gate works.
});

test('hook — async / await boundary does not break the logger', async () => {
  resetCaptureBudget();
  const records = [];
  const testLogger = createTestLogger(records);

  async function inner() {
    testLogger.error({ stage: 'inner' }, 'async error');
  }
  async function outer() {
    await Promise.resolve();
    await inner();
  }
  await outer();

  const rec = records.find((r) => r.msg === 'async error');
  assert.ok(rec, 'async error record was emitted');
  assert.equal(rec.stage, 'inner');
});

// ── Module-level sanity ──────────────────────────────────────────────────────

test('logger module exports the expected public + private surface', () => {
  assert.ok(typeof logger === 'object' && logger !== null);
  assert.equal(typeof logger.error, 'function');
  assert.equal(typeof logger.info, 'function');
  assert.equal(typeof logger.child, 'function');
  assert.equal(typeof _internals.captureSourceLocation, 'function');
  assert.equal(typeof _internals.parseSourceFromStack, 'function');
  assert.equal(typeof _internals.resetCaptureBudget, 'function');
  assert.equal(typeof _internals.parseCaptureBudget, 'function');
});

// ── v3.2.3 post-ship review fixes ───────────────────────────────────────────

// H1 — parseCaptureBudget must NOT silently accept NaN-producing env values.
// The pre-fix implementation was `parseInt(env || '500', 10)`, which
// returned NaN for "NaN", "abc", "", etc. Because `_captureCount > NaN`
// is always false, the rate-limiter was completely disabled when the env
// var was misconfigured. Guard by Number.isFinite + require strictly
// positive.

test('parseCaptureBudget — valid positive integer', () => {
  assert.equal(parseCaptureBudget('1000'), 1000);
  assert.equal(parseCaptureBudget('1'), 1);
  assert.equal(parseCaptureBudget('99999'), 99999);
});

test('parseCaptureBudget — undefined / null / empty fall back to 500', () => {
  assert.equal(parseCaptureBudget(undefined), 500);
  assert.equal(parseCaptureBudget(null), 500);
  assert.equal(parseCaptureBudget(''), 500);
});

test('parseCaptureBudget — NaN-producing strings fall back to 500 (H1 fix)', () => {
  assert.equal(parseCaptureBudget('NaN'), 500);
  assert.equal(parseCaptureBudget('abc'), 500);
  assert.equal(parseCaptureBudget('not-a-number'), 500);
  // `parseInt` tolerates trailing garbage: "123abc" → 123. That's fine.
  assert.equal(parseCaptureBudget('123abc'), 123);
});

test('parseCaptureBudget — zero and negative fall back to 500', () => {
  assert.equal(parseCaptureBudget('0'), 500);
  assert.equal(parseCaptureBudget('-5'), 500);
  assert.equal(parseCaptureBudget('-500'), 500);
});

test('parseCaptureBudget — Infinity strings fall back to 500', () => {
  // parseInt('Infinity', 10) returns NaN, not Infinity — but verify
  // the guard covers both cases belt-and-braces.
  assert.equal(parseCaptureBudget('Infinity'), 500);
  assert.equal(parseCaptureBudget('-Infinity'), 500);
});

// NH1 — v3.2.4 retro-review: H1 guard still accepted values high enough to
// effectively disable the DoS rate-limiter. Values above MAX_CAPTURE_BUDGET
// (100_000) must fall back to DEFAULT and emit a stderr warning so the
// operator notices the misconfiguration.

test('parseCaptureBudget — values above MAX_CAPTURE_BUDGET fall back + warn (NH1 fix)', () => {
  // v3.2.4 Phase 3 NL1 — the dedup guard means only the FIRST over-cap
  // call fires a warning per process. Use resetCapBudgetWarn() between
  // calls to exercise each offending value, so the assertions can
  // confirm the warning content for every value.
  resetCapBudgetWarn();
  const captured = [];
  const origWrite = process.stderr.write.bind(process.stderr);
  // eslint-disable-next-line no-param-reassign
  process.stderr.write = (chunk, ...rest) => {
    captured.push(String(chunk));
    // Honour any callback so pino / node internals don't wedge.
    const cb = rest[rest.length - 1];
    if (typeof cb === 'function') cb();
    return true;
  };
  try {
    assert.equal(parseCaptureBudget('99999999'), 500);
    resetCapBudgetWarn();
    assert.equal(parseCaptureBudget('1000000'), 500);
    resetCapBudgetWarn();
    assert.equal(parseCaptureBudget('100001'), 500);
  } finally {
    process.stderr.write = origWrite;
  }
  const joined = captured.join('');
  assert.ok(
    joined.includes('exceeds cap'),
    `stderr warning missing "exceeds cap", got: ${JSON.stringify(joined)}`
  );
  assert.ok(
    joined.includes('99999999'),
    'warning mentioned the first offending value'
  );
  assert.ok(
    joined.includes('1000000'),
    'warning mentioned the second offending value'
  );
});

test('NL1 — parseCaptureBudget over-cap warning fires exactly once per process (dedup)', () => {
  // v3.2.4 Phase 3 NL1 — defensive dedup guard. In production the
  // helper is called once at require-time so the dedup is mostly
  // theoretical, but if a future refactor exposes parseCaptureBudget
  // to a hot path, the guard prevents warning-spam on every call.
  resetCapBudgetWarn();
  const captured = [];
  const origWrite = process.stderr.write.bind(process.stderr);
  // eslint-disable-next-line no-param-reassign
  process.stderr.write = (chunk, ...rest) => {
    captured.push(String(chunk));
    const cb = rest[rest.length - 1];
    if (typeof cb === 'function') cb();
    return true;
  };
  try {
    // Three over-cap calls, NO reset between them. Only the first
    // should fire a warning; the second + third should fall back
    // silently.
    assert.equal(parseCaptureBudget('99999999'), 500);
    assert.equal(parseCaptureBudget('1000000'), 500);
    assert.equal(parseCaptureBudget('100001'), 500);
  } finally {
    process.stderr.write = origWrite;
  }
  const joined = captured.join('');
  const warnCount = (joined.match(/exceeds cap/g) || []).length;
  assert.equal(
    warnCount,
    1,
    `NL1 dedup failed: expected exactly 1 "exceeds cap" warning, got ${warnCount}: ${JSON.stringify(joined)}`
  );
  // And the one warning should mention the FIRST over-cap value, not
  // the later ones (first-wins ordering).
  assert.ok(
    joined.includes('99999999'),
    'dedup warning should mention the first value that tripped it'
  );
});

test('parseCaptureBudget — value just at MAX_CAPTURE_BUDGET passes through', () => {
  // 100_000 is the cap (inclusive). The helper caps on strict `>`, so the
  // boundary value itself must be accepted unchanged — proves the cap is
  // "> MAX" not ">= MAX".
  assert.equal(parseCaptureBudget('100000'), 100000);
});

test('parseCaptureBudget — value just under MAX_CAPTURE_BUDGET passes through', () => {
  assert.equal(parseCaptureBudget('99999'), 99999);
});

// NH2 — v3.2.4 retro-review: H2 gate used strict-equality NODE_ENV check,
// which left `_internals` exposed on any `.env` that set NODE_ENV=Production
// (capital P) or similar. Gate now uses lowercase coercion — verify all
// common case variants resolve to production.

function _spawnInternalsProbe(nodeEnvValue) {
  const { spawnSync } = require('node:child_process');
  const path = require('node:path');
  const loggerPath = path.resolve(__dirname, '../../src/shared/lib/logger.js');
  // Clean minimal env (NM4) — inherit only PATH so node can locate runtime
  // deps, but drop every other LOGGER_* / PINO_* / DEBUG / etc. that might
  // stain the subprocess output.
  const env = { PATH: process.env.PATH || '' };
  if (nodeEnvValue !== undefined) env.NODE_ENV = nodeEnvValue;
  return spawnSync(
    process.execPath,
    ['-e', `const m = require(${JSON.stringify(loggerPath)}); process.stdout.write("INTERNALS:" + String(typeof m._internals));`],
    { env, encoding: 'utf-8' }
  );
}

test('_internals gated out when NODE_ENV=Production (capital P) (NH2 fix)', () => {
  const result = _spawnInternalsProbe('Production');
  assert.equal(result.status, 0, `subprocess failed: ${result.stderr}`);
  assert.ok(
    result.stdout.includes('INTERNALS:undefined'),
    `expected _internals undefined, got stdout: ${result.stdout}`
  );
});

test('_internals gated out when NODE_ENV=PRODUCTION (all caps) (NH2 fix)', () => {
  const result = _spawnInternalsProbe('PRODUCTION');
  assert.equal(result.status, 0, `subprocess failed: ${result.stderr}`);
  assert.ok(
    result.stdout.includes('INTERNALS:undefined'),
    `expected _internals undefined, got stdout: ${result.stdout}`
  );
});

test('_internals IS present when NODE_ENV=prod (not an exact match) (NH2 fix)', () => {
  // `'prod'.toLowerCase() === 'production'` is false — `prod` is NOT a
  // production alias, the check requires the full word. Prove the gate is
  // not overly loose.
  const result = _spawnInternalsProbe('prod');
  assert.equal(result.status, 0, `subprocess failed: ${result.stderr}`);
  assert.ok(
    result.stdout.includes('INTERNALS:object'),
    `expected _internals object (prod is NOT production), got stdout: ${result.stdout}`
  );
});

test('_internals gated out when NODE_ENV has trailing whitespace trimmed — negative case', () => {
  // `' production '.toLowerCase() === 'production'` is false because the
  // guard uses `.toLowerCase()` not `.trim()`. Document that we did NOT
  // over-normalise — a stray space in an .env file is still a
  // misconfiguration that should be loud (via _internals still being
  // exposed + the v3.2.4 Phase 2 NM7 stderr warning), not silently
  // "corrected".
  const result = _spawnInternalsProbe(' production ');
  assert.equal(result.status, 0, `subprocess failed: ${result.stderr}`);
  assert.ok(
    result.stdout.includes('INTERNALS:object'),
    `expected _internals object (whitespace NOT trimmed by design), got stdout: ${result.stdout}`
  );
});

// ── v3.2.4 Phase 2 NM7 — NODE_ENV whitespace warning ────────────────────────

// NM7: when NODE_ENV contains the substring 'production' (case-insensitive)
// but does not exactly match 'production' after lowercasing, the module
// emits a one-shot stderr warning at require-time. This catches stray
// whitespace (` production `, `production `, ` production`), case +
// whitespace combos (`Production `), and production-look-alike values
// (`production-test`, `production-staging`) that previously left
// `_internals` silently exposed.

function _spawnWarnProbe(nodeEnvValue) {
  const { spawnSync } = require('node:child_process');
  const path = require('node:path');
  const loggerPath = path.resolve(__dirname, '../../src/shared/lib/logger.js');
  const env = { PATH: process.env.PATH || '' };
  if (nodeEnvValue !== undefined) env.NODE_ENV = nodeEnvValue;
  return spawnSync(
    process.execPath,
    ['-e', `require(${JSON.stringify(loggerPath)}); process.stdout.write("DONE");`],
    { env, encoding: 'utf-8' }
  );
}

test('NM7 — NODE_ENV=" production " triggers whitespace warning', () => {
  const result = _spawnWarnProbe(' production ');
  assert.equal(result.status, 0, `subprocess failed: ${result.stderr}`);
  assert.ok(result.stdout.includes('DONE'), 'subprocess completed');
  assert.match(
    result.stderr,
    /\[logger\] NODE_ENV=.* looks like a production intent but does not exactly match/,
    `expected NM7 warning, got stderr: ${result.stderr}`
  );
  assert.match(result.stderr, /_internals surface will remain EXPOSED/);
});

test('NM7 — NODE_ENV="production " (trailing space only) triggers warning', () => {
  const result = _spawnWarnProbe('production ');
  assert.equal(result.status, 0, `subprocess failed: ${result.stderr}`);
  assert.match(result.stderr, /looks like a production intent/);
});

test('NM7 — NODE_ENV=" production" (leading space only) triggers warning', () => {
  const result = _spawnWarnProbe(' production');
  assert.equal(result.status, 0, `subprocess failed: ${result.stderr}`);
  assert.match(result.stderr, /looks like a production intent/);
});

test('NM7 — NODE_ENV="production-test" triggers warning (look-alike)', () => {
  // production-test, production-staging, productionx etc. are all
  // substring matches that should warn. The substring test is the point:
  // any value that looks production-ish but is not exact deserves a flag.
  const result = _spawnWarnProbe('production-test');
  assert.equal(result.status, 0, `subprocess failed: ${result.stderr}`);
  assert.match(result.stderr, /looks like a production intent/);
});

test('NM7 — NODE_ENV="production" (exact match) does NOT warn', () => {
  const result = _spawnWarnProbe('production');
  assert.equal(result.status, 0, `subprocess failed: ${result.stderr}`);
  // Exact match → isProduction = true → the NM7 branch never runs.
  assert.ok(
    !result.stderr.includes('looks like a production intent'),
    `expected no NM7 warning for exact 'production', got stderr: ${result.stderr}`
  );
});

test('NM7 — NODE_ENV="Production" (uppercase exact) does NOT warn', () => {
  // NH2 + NM7 interaction: 'Production'.toLowerCase() === 'production' so
  // isProduction is true, and the NM7 branch never runs.
  const result = _spawnWarnProbe('Production');
  assert.equal(result.status, 0, `subprocess failed: ${result.stderr}`);
  assert.ok(
    !result.stderr.includes('looks like a production intent'),
    `expected no NM7 warning for 'Production', got stderr: ${result.stderr}`
  );
});

test('NM7 — NODE_ENV="development" does NOT warn (no substring match)', () => {
  const result = _spawnWarnProbe('development');
  assert.equal(result.status, 0, `subprocess failed: ${result.stderr}`);
  assert.ok(
    !result.stderr.includes('looks like a production intent'),
    `expected no NM7 warning for 'development', got stderr: ${result.stderr}`
  );
});

test('NM7 — NODE_ENV="test" does NOT warn', () => {
  const result = _spawnWarnProbe('test');
  assert.equal(result.status, 0, `subprocess failed: ${result.stderr}`);
  assert.ok(!result.stderr.includes('looks like a production intent'));
});

test('NM7 — unset NODE_ENV does NOT warn', () => {
  const result = _spawnWarnProbe(undefined);
  assert.equal(result.status, 0, `subprocess failed: ${result.stderr}`);
  assert.ok(!result.stderr.includes('looks like a production intent'));
});

// ── v3.2.4 Phase 2 M2 — err stack path sanitization ─────────────────────────

test('sanitizeStackLine — rewrites WSL dev absolute path to src/', () => {
  const line = '    at foo (/home/user/projects/flexible_mold_base/docker-api/src/edge/routes/platform/export.js:141:12)';
  assert.equal(
    sanitizeStackLine(line),
    '    at foo (src/edge/routes/platform/export.js:141:12)'
  );
});

test('sanitizeStackLine — rewrites production /app/src/ path to src/', () => {
  const line = '    at handler (/app/src/edge/db.js:222:12)';
  assert.equal(sanitizeStackLine(line), '    at handler (src/edge/db.js:222:12)');
});

test('sanitizeStackLine — rewrites /app/docker-api/src/ (alt layout) to src/', () => {
  const line = '    at x (/app/docker-api/src/shared/lib/logger.js:88:10)';
  assert.equal(sanitizeStackLine(line), '    at x (src/shared/lib/logger.js:88:10)');
});

test('sanitizeStackLine — rewrites CI bind-mount /builds/.../src/ to src/', () => {
  const line = '    at y (/builds/ci/flexible-mold-base/docker-api/src/shared/lib/logger.js:88:10)';
  assert.equal(sanitizeStackLine(line), '    at y (src/shared/lib/logger.js:88:10)');
});

test('sanitizeStackLine — rewrites absolute /node_modules/ to node_modules/', () => {
  const line = '    at Layer.handle (/home/user/projects/flexible_mold_base/docker-api/node_modules/express/lib/router/layer.js:95:5)';
  assert.equal(
    sanitizeStackLine(line),
    '    at Layer.handle (node_modules/express/lib/router/layer.js:95:5)'
  );
});

test('sanitizeStackLine — leaves node: internal frames alone', () => {
  const line = '    at internal (node:internal/process/task_queues:96:5)';
  assert.equal(sanitizeStackLine(line), line);
});

test('sanitizeStackLine — idempotent on already-relative paths', () => {
  const line = '    at foo (src/edge/db.js:10:5)';
  assert.equal(sanitizeStackLine(line), line);
});

test('sanitizeStackLine — handles plain at-form (no parens)', () => {
  const line = '    at /app/src/edge/db.js:222:12';
  assert.equal(sanitizeStackLine(line), '    at src/edge/db.js:222:12');
});

test('sanitizeErrSerializer — preserves type + message + other own props', () => {
  const err = new Error('boom');
  err.code = 'E_BOOM';
  err.statusCode = 500;
  const out = sanitizeErrSerializer(err);
  assert.equal(out.type, 'Error');
  assert.equal(out.message, 'boom');
  assert.equal(out.code, 'E_BOOM');
  assert.equal(out.statusCode, 500);
  assert.ok(typeof out.stack === 'string' && out.stack.length > 0);
});

test('sanitizeErrSerializer — strips absolute paths from stack lines', () => {
  // Craft a synthetic stack so we don't depend on the test runner's cwd.
  const err = Object.create(Error.prototype);
  err.message = 'crafted';
  err.stack = [
    'Error: crafted',
    '    at realFn (/home/user/projects/flexible_mold_base/docker-api/src/edge/routes/platform/export.js:141:12)',
    '    at Layer.handle (/home/user/projects/flexible_mold_base/docker-api/node_modules/express/lib/router/layer.js:95:5)',
    '    at internal (node:internal/process/task_queues:96:5)',
  ].join('\n');

  const out = sanitizeErrSerializer(err);
  assert.ok(typeof out.stack === 'string');
  assert.ok(
    !out.stack.includes('/home/user/projects'),
    `expected absolute WSL path stripped, got: ${out.stack}`
  );
  assert.ok(
    !out.stack.includes('/docker-api/'),
    `expected /docker-api/ prefix stripped, got: ${out.stack}`
  );
  assert.ok(
    out.stack.includes('src/edge/routes/platform/export.js:141:12'),
    `expected relative src/ path preserved, got: ${out.stack}`
  );
  assert.ok(
    out.stack.includes('node_modules/express/lib/router/layer.js:95:5'),
    `expected relative node_modules path preserved, got: ${out.stack}`
  );
  assert.ok(
    out.stack.includes('node:internal/process/task_queues:96:5'),
    `expected node: internal frames preserved as-is, got: ${out.stack}`
  );
});

test('sanitizeErrSerializer — safe on err without stack', () => {
  // Some error-like objects skip capturing a stack (e.g. thrown plain
  // objects, very deep recursion, or `{ message: 'oops' }`). The helper
  // must not crash.
  const fakeErr = Object.create(Error.prototype);
  fakeErr.message = 'no stack';
  // Intentionally do NOT set stack.
  const out = sanitizeErrSerializer(fakeErr);
  assert.equal(out.message, 'no stack');
  // base.stack may be undefined OR an empty string; either is fine.
});

test('sanitizeErrSerializer — safe on non-Error input', () => {
  // pino.stdSerializers.err passes through non-Error input as-is. Our
  // wrapper MUST NOT throw AND must preserve the input identity when
  // there is no `.stack` field to rewrite. A weak `doesNotThrow` test
  // would pass even if the serializer returned something pathological
  // like an empty object or `undefined` for a non-empty input — so
  // assert the specific expected values instead.
  assert.equal(sanitizeErrSerializer(undefined), undefined);
  assert.equal(sanitizeErrSerializer(null), null);
  // stdSerializers.err returns non-Error objects unchanged (reference
  // equality), so a string input should round-trip.
  assert.equal(sanitizeErrSerializer('plain string'), 'plain string');
  assert.equal(sanitizeErrSerializer(42), 42);
});

// H2 — `_internals` must be undefined when NODE_ENV === 'production'.
// Runs a subprocess because NODE_ENV is read at module load time; we
// cannot change it from inside the already-loaded test process.
//
// v3.2.4 Phase 5.2 (NM1 + NM4) — migrated to the `_spawnInternalsProbe`
// helper which uses (a) the `INTERNALS:` marker token on stdout instead of
// the flaky `stderr.trim().split('\n').pop()` tail pattern (NM1), and
// (b) a clean minimal `env: { PATH, NODE_ENV }` instead of `...process.env`
// which was inheriting LOGGER_CAPTURE_BUDGET / PINO_* / DEBUG and staining
// the subprocess output (NM4). Behaviour identical — these still assert
// the canonical H2 property that _internals is absent under production
// and present under non-production.

test('_internals is absent from module.exports in production (H2 fix)', () => {
  const result = _spawnInternalsProbe('production');
  assert.equal(result.status, 0, `subprocess failed: ${result.stderr}`);
  assert.ok(
    result.stdout.includes('INTERNALS:undefined'),
    `expected _internals undefined, got stdout: ${result.stdout}`
  );
});

test('_internals IS present in module.exports when NODE_ENV is not production', () => {
  const result = _spawnInternalsProbe('test');
  assert.equal(result.status, 0, `subprocess failed: ${result.stderr}`);
  assert.ok(
    result.stdout.includes('INTERNALS:object'),
    `expected _internals object, got stdout: ${result.stdout}`
  );
});

// ── v3.2.6 P51-C1 / P51-C3 / LOW3 — pino redact config ──────────────────
//
// v3.2.4 Phase 5.1 moved `email` out of pino `msg` strings and into
// structured bindings to satisfy the PII-expansion HIGH findings. But the
// `redact.paths` config in logger.js was never updated to redact the new
// `email` binding — so `logger.info({ email: '...'}, 'login')` still
// writes the literal email into the JSON record.
//
// P51-C3: `db.js` also binds the DB config-file path on "Failed to read
// DB config file" errors — the absolute container path was not redacted
// either, because the Phase 2 M2 sanitizeErrSerializer only touches
// `err.stack`, not top-level string bindings.
//
// LOW3: the original P51-C3 fix used the bare `'path'` binding name,
// which collaterally redacted four legitimate non-sensitive log sites
// (circuit-breaker upstream URLs in remote-client.js, CA cert paths in
// keycloak-oidc.js). v3.2.6 LOW3 renames the redact key to `'configPath'`
// and renames collateral bindings to `routePath` / `caCertPath` so that
// only db config bindings get redacted. The negative-control test at the
// bottom of this section is the invariant guard for that rename.
//
// These tests build a fresh pino instance wired to an in-memory
// destination, using the REAL redactConfig from _internals (not a
// duplicate), and assert the censor replaces (or does NOT replace) the
// value as appropriate.

test('redact — email binding is replaced with [Redacted] (v3.2.6 P51-C1)', () => {
  const records = [];
  const dest = new Writable({
    write(chunk, _enc, cb) {
      for (const line of chunk.toString('utf-8').split('\n')) {
        if (!line) continue;
        try { records.push(JSON.parse(line)); } catch { /* partial */ }
      }
      cb();
    },
  });
  const testLogger = pino(
    { level: 'trace', redact: _internals.redactConfig },
    dest,
  );
  testLogger.info({ email: 'alice@example.com' }, 'login attempt');

  const rec = records.find((r) => r.msg === 'login attempt');
  assert.ok(rec, 'record was emitted');
  assert.equal(rec.email, '[Redacted]');
});

test('redact — configPath binding is replaced with [Redacted] (v3.2.6 P51-C3 / LOW3)', () => {
  const records = [];
  const dest = new Writable({
    write(chunk, _enc, cb) {
      for (const line of chunk.toString('utf-8').split('\n')) {
        if (!line) continue;
        try { records.push(JSON.parse(line)); } catch { /* partial */ }
      }
      cb();
    },
  });
  const testLogger = pino(
    { level: 'trace', redact: _internals.redactConfig },
    dest,
  );
  testLogger.error(
    { configPath: '/app/src/config/db.json', err: new Error('ENOENT') },
    'Failed to read DB config file',
  );

  const rec = records.find((r) => r.msg === 'Failed to read DB config file');
  assert.ok(rec, 'record was emitted');
  assert.equal(rec.configPath, '[Redacted]');
});

test('redact — LOW3 invariant: routePath / caCertPath / bare path bindings pass through', () => {
  // Negative control for the v3.2.6 LOW3 rename. The whole point of
  // moving the redact key from bare 'path' to 'configPath' is so that
  // legitimate non-sensitive bindings — `routePath` (remote-client.js
  // upstream API route), `caCertPath` (keycloak-oidc.js operator-known
  // env var), and a hypothetical bare `path` field that does not match
  // any redact key — remain visible in logs for ops debugging.
  //
  // If a future contributor re-adds 'path' to redact.paths without
  // grepping the call sites, this test fails loudly and points at the
  // four observability sites that would silently break.
  const records = [];
  const dest = new Writable({
    write(chunk, _enc, cb) {
      for (const line of chunk.toString('utf-8').split('\n')) {
        if (!line) continue;
        try { records.push(JSON.parse(line)); } catch { /* partial */ }
      }
      cb();
    },
  });
  const testLogger = pino(
    { level: 'trace', redact: _internals.redactConfig },
    dest,
  );
  testLogger.warn(
    {
      routePath: '/api/users',
      caCertPath: '/etc/ssl/keycloak-ca.pem',
      // A literal `path` binding is NOT one of the call sites this PR
      // touches, but the rename invariant must hold for it too: bare
      // `path` is not in redact.paths, so it must NOT be redacted.
      path: '/should/pass/through',
    },
    'observability invariant',
  );

  const rec = records.find((r) => r.msg === 'observability invariant');
  assert.ok(rec, 'record was emitted');
  assert.equal(rec.routePath, '/api/users');
  assert.equal(rec.caCertPath, '/etc/ssl/keycloak-ca.pem');
  assert.equal(rec.path, '/should/pass/through');
});

test('redact — existing paths still redact after v3.2.6 additions (regression guard)', () => {
  // Defence-in-depth: adding new entries must not reorder or drop the
  // existing password / authorization / cookie / secret / clientSecret
  // redactions. One test per representative entry would be overkill;
  // assert the full superset at once.
  const records = [];
  const dest = new Writable({
    write(chunk, _enc, cb) {
      for (const line of chunk.toString('utf-8').split('\n')) {
        if (!line) continue;
        try { records.push(JSON.parse(line)); } catch { /* partial */ }
      }
      cb();
    },
  });
  const testLogger = pino(
    { level: 'trace', redact: _internals.redactConfig },
    dest,
  );
  testLogger.info(
    {
      password: 'hunter2',
      secret: 'sk-abc',
      clientSecret: 'xyz',
      req: {
        body: { password: 'hunter2' },
        headers: { authorization: 'Bearer tok', cookie: 'sid=abc' },
      },
    },
    'credentials checked',
  );

  const rec = records.find((r) => r.msg === 'credentials checked');
  assert.ok(rec, 'record was emitted');
  assert.equal(rec.password, '[Redacted]');
  assert.equal(rec.secret, '[Redacted]');
  assert.equal(rec.clientSecret, '[Redacted]');
  assert.equal(rec.req.body.password, '[Redacted]');
  assert.equal(rec.req.headers.authorization, '[Redacted]');
  assert.equal(rec.req.headers.cookie, '[Redacted]');
});

test('redact — non-PII fields pass through unchanged', () => {
  // Negative control: make sure the redact engine does not over-redact.
  const records = [];
  const dest = new Writable({
    write(chunk, _enc, cb) {
      for (const line of chunk.toString('utf-8').split('\n')) {
        if (!line) continue;
        try { records.push(JSON.parse(line)); } catch { /* partial */ }
      }
      cb();
    },
  });
  const testLogger = pino(
    { level: 'trace', redact: _internals.redactConfig },
    dest,
  );
  testLogger.info(
    { module: 'db', poolSize: 10, hostname: 'db.example.com' },
    'pool configured',
  );

  const rec = records.find((r) => r.msg === 'pool configured');
  assert.ok(rec, 'record was emitted');
  assert.equal(rec.module, 'db');
  assert.equal(rec.poolSize, 10);
  assert.equal(rec.hostname, 'db.example.com');
});

test('redact — err.sql binding is replaced with [Redacted]', () => {
  const records = [];
  const dest = new Writable({
    write(chunk, _enc, cb) {
      for (const line of chunk.toString('utf-8').split('\n')) {
        if (!line) continue;
        try { records.push(JSON.parse(line)); } catch { /* partial */ }
      }
      cb();
    },
  });
  const testLogger = pino(
    { level: 'trace', redact: _internals.redactConfig },
    dest,
  );
  const fakeErr = Object.assign(new Error('Duplicate entry'), {
    sql: 'INSERT INTO `fmb_users` (email) VALUES (?)',
    values: ['alice@example.com'],
  });
  testLogger.error({ err: fakeErr }, 'query failed');

  const rec = records.find((r) => r.msg === 'query failed');
  assert.ok(rec, 'record was emitted');
  assert.equal(rec.err.sql, '[Redacted]');
});

test('redact — err.values binding is replaced with [Redacted]', () => {
  const records = [];
  const dest = new Writable({
    write(chunk, _enc, cb) {
      for (const line of chunk.toString('utf-8').split('\n')) {
        if (!line) continue;
        try { records.push(JSON.parse(line)); } catch { /* partial */ }
      }
      cb();
    },
  });
  const testLogger = pino(
    { level: 'trace', redact: _internals.redactConfig },
    dest,
  );
  const fakeErr = Object.assign(new Error('Duplicate entry'), {
    sql: 'INSERT INTO `fmb_users` (email) VALUES (?)',
    values: ['alice@example.com'],
  });
  testLogger.error({ err: fakeErr }, 'query failed');

  const rec = records.find((r) => r.msg === 'query failed');
  assert.ok(rec, 'record was emitted');
  assert.equal(rec.err.values, '[Redacted]');
});

test('redact — err.cause.sql binding is replaced with [Redacted]', () => {
  const records = [];
  const dest = new Writable({
    write(chunk, _enc, cb) {
      for (const line of chunk.toString('utf-8').split('\n')) {
        if (!line) continue;
        try { records.push(JSON.parse(line)); } catch { /* partial */ }
      }
      cb();
    },
  });
  const testLogger = pino(
    { level: 'trace', redact: _internals.redactConfig },
    dest,
  );
  const fakeErr = Object.assign(new Error('Wrapped query failure'), {
    cause: {
      sql: 'GRANT SELECT ON `fmb_app_data` TO ?',
      values: ['admin@example.com'],
    },
  });
  testLogger.error({ err: fakeErr }, 'wrapped query failed');

  const rec = records.find((r) => r.msg === 'wrapped query failed');
  assert.ok(rec, 'record was emitted');
  assert.equal(rec.err.cause.sql, '[Redacted]');
});

test('redact — err.cause.values binding is replaced with [Redacted]', () => {
  const records = [];
  const dest = new Writable({
    write(chunk, _enc, cb) {
      for (const line of chunk.toString('utf-8').split('\n')) {
        if (!line) continue;
        try { records.push(JSON.parse(line)); } catch { /* partial */ }
      }
      cb();
    },
  });
  const testLogger = pino(
    { level: 'trace', redact: _internals.redactConfig },
    dest,
  );
  const fakeErr = Object.assign(new Error('Wrapped query failure'), {
    cause: {
      sql: 'GRANT SELECT ON `fmb_app_data` TO ?',
      values: ['admin@example.com'],
    },
  });
  testLogger.error({ err: fakeErr }, 'wrapped query failed');

  const rec = records.find((r) => r.msg === 'wrapped query failed');
  assert.ok(rec, 'record was emitted');
  assert.equal(rec.err.cause.values, '[Redacted]');
});

test('redact — err.sqlMessage embeds user-supplied value (ER_DUP_ENTRY) is replaced', () => {
  const records = [];
  const dest = new Writable({
    write(chunk, _enc, cb) {
      for (const line of chunk.toString('utf-8').split('\n')) {
        if (!line) continue;
        try { records.push(JSON.parse(line)); } catch { /* partial */ }
      }
      cb();
    },
  });
  const testLogger = pino(
    { level: 'trace', redact: _internals.redactConfig },
    dest,
  );
  const fakeErr = Object.assign(new Error('ER_DUP_ENTRY'), {
    sqlMessage: "Duplicate entry 'alice@example.com' for key 'users.email'",
    text: "Duplicate entry 'alice@example.com' for key 'users.email'",
  });
  testLogger.error({ err: fakeErr }, 'duplicate entry');

  const rec = records.find((r) => r.msg === 'duplicate entry');
  assert.ok(rec, 'record was emitted');
  assert.equal(rec.err.sqlMessage, '[Redacted]');
  assert.equal(rec.err.text, '[Redacted]');
});

test('redact — err.cause.sqlMessage / err.cause.text on wrapped errors are replaced', () => {
  const records = [];
  const dest = new Writable({
    write(chunk, _enc, cb) {
      for (const line of chunk.toString('utf-8').split('\n')) {
        if (!line) continue;
        try { records.push(JSON.parse(line)); } catch { /* partial */ }
      }
      cb();
    },
  });
  const testLogger = pino(
    { level: 'trace', redact: _internals.redactConfig },
    dest,
  );
  const fakeErr = Object.assign(new Error('Wrapped'), {
    cause: {
      sqlMessage: "Data too long for column 'email' at row 1 — value 'attacker@evil.example'",
      text: "Data too long for column 'email' at row 1 — value 'attacker@evil.example'",
    },
  });
  testLogger.error({ err: fakeErr }, 'wrapped duplicate');

  const rec = records.find((r) => r.msg === 'wrapped duplicate');
  assert.ok(rec, 'record was emitted');
  assert.equal(rec.err.cause.sqlMessage, '[Redacted]');
  assert.equal(rec.err.cause.text, '[Redacted]');
});

test('serializer — MariaDB SqlError message + stack header are scrubbed (preserve code)', () => {
  // Simulates the actual mariadb SqlError shape: super() builds message
  // by appending "\nsql: <sql>" so err.message + stack header contain
  // user values from the server error string.
  const fakeSqlError = Object.assign(new Error('(conn:1, no:1062, SQLState:23000) Duplicate entry \'alice@example.com\' for key \'users.email\'\nsql: INSERT INTO `fmb_users` (email) VALUES (?) - parameters:[\'alice@example.com\']'), {
    name: 'SqlError',
    sqlMessage: "Duplicate entry 'alice@example.com' for key 'users.email'",
    sql: "INSERT INTO `fmb_users` (email) VALUES (?)",
    fatal: false,
    errno: 1062,
    sqlState: '23000',
    code: 'ER_DUP_ENTRY',
  });
  const result = _internals.sanitizeErrSerializer(fakeSqlError);
  assert.equal(result.message, '[Redacted MariaDB ER_DUP_ENTRY]');
  assert.ok(!result.stack.includes("'alice@example.com'"), 'stack must not contain user value');
  assert.ok(!result.stack.includes("INSERT INTO"), 'stack must not contain SQL');
  assert.ok(result.stack.startsWith('SqlError: [Redacted MariaDB ER_DUP_ENTRY]'), 'stack header is the safe form');
  assert.match(result.stack, /\n\s+at /, 'stack frames preserved for triage');
});

test('serializer — wrapped SqlError as err.cause is also scrubbed', () => {
  const innerSqlError = Object.assign(new Error('(conn:1, no:1062, SQLState:23000) Duplicate entry \'admin@evil.example\' for key \'users.email\'\nsql: GRANT SELECT ON `fmb_app_data` TO ?'), {
    name: 'SqlError',
    sqlMessage: "Duplicate entry 'admin@evil.example' for key 'users.email'",
    sql: "GRANT SELECT ON `fmb_app_data` TO ?",
    errno: 1062,
    code: 'ER_DUP_ENTRY',
  });
  const wrapper = Object.assign(new Error('config-swap failed'), { cause: innerSqlError });
  const result = _internals.sanitizeErrSerializer(wrapper);
  assert.ok(result.cause, 'cause preserved');
  assert.equal(result.cause.message, '[Redacted MariaDB ER_DUP_ENTRY]');
  assert.ok(!result.cause.stack.includes("'admin@evil.example'"), 'cause stack must not leak user value');
  assert.ok(!result.cause.stack.includes('GRANT SELECT'), 'cause stack must not leak SQL');
});

test('serializer — non-MariaDB Error message + stack are unchanged', () => {
  // Negative control: regular Error must NOT be touched by SqlError scrub
  const regular = new Error('User not found');
  const result = _internals.sanitizeErrSerializer(regular);
  assert.equal(result.message, 'User not found', 'plain Error message preserved');
  assert.ok(result.stack.startsWith('Error: User not found'), 'plain Error stack header preserved');
});

test('serializer — deeply wrapped SqlError (Error -> Error -> SqlError) is scrubbed at every level', () => {
  // Path-based redact only covers err and err.cause; without serializer-
  // level structural scrub, the innermost SqlError's sql/values/sqlMessage
  // would leak. Confirm the scrub runs on cause.cause.
  const innermost = Object.assign(new Error('inner'), {
    name: 'SqlError',
    sql: 'SELECT * FROM `fmb_users` WHERE email = ?',
    values: ['victim@example.com'],
    sqlMessage: "Duplicate entry 'victim@example.com' for key 'users.email'",
    text: "Duplicate entry 'victim@example.com' for key 'users.email'",
    errno: 1062,
    code: 'ER_DUP_ENTRY',
  });
  const middle = Object.assign(new Error('middle wrap'), { cause: innermost });
  const outer = Object.assign(new Error('outer wrap'), { cause: middle });

  const result = _internals.sanitizeErrSerializer(outer);
  assert.ok(result.cause && result.cause.cause, 'two-level cause chain serialized');
  assert.equal(result.cause.cause.message, '[Redacted MariaDB ER_DUP_ENTRY]');
  assert.equal(result.cause.cause.sql, '[Redacted]');
  assert.equal(result.cause.cause.values, '[Redacted]');
  assert.equal(result.cause.cause.sqlMessage, '[Redacted]');
  assert.equal(result.cause.cause.text, '[Redacted]');
  assert.ok(!JSON.stringify(result).includes("'victim@example.com'"), 'victim email must not survive anywhere in serialized output');
  assert.ok(!JSON.stringify(result).includes('SELECT * FROM'), 'inner SQL must not survive anywhere');
});

test('serializer — cyclic cause chain (a.cause=b; b.cause=a) terminates without RangeError', () => {
  const a = new Error('a');
  const b = new Error('b');
  a.cause = b;
  b.cause = a;
  // Should NOT throw
  const result = _internals.sanitizeErrSerializer(a);
  assert.equal(result.message, 'a');
  assert.ok(result.cause, 'first cause level serialized');
  assert.equal(result.cause.message, 'b');
  assert.ok(result.cause.cause, 'second cause level serialized');
  assert.equal(result.cause.cause.message, '[cycle in cause chain]', 'cycle detected and replaced with stub');
});

test('serializer — plain-object cause is dropped to preserve pino default PII safety', () => {
  // Pino's stdSerializers.err historically dropped non-Error causes so
  // `new Error('x', { cause: { password: 'hunter2' } })` did not surface
  // password in logs. The custom serializer must preserve that behavior;
  // only Error-instance causes get recursively serialized.
  const wrapper = new Error('wrapper');
  wrapper.cause = { password: 'hunter2', clientSecret: 's3cret' };
  const result = _internals.sanitizeErrSerializer(wrapper);
  assert.equal(result.cause, undefined, 'plain-object cause is not exposed');
});

test('serializer — Error-instance cause with PII own-props (password/secret/etc) is redacted', () => {
  // Path-based redact in redactConfig.paths only covers explicitly listed
  // err.cause.* keys. Errors used as causes can carry password/secret/
  // email own-properties; copy-loop would expose them under err.cause.*.
  // Cause-level PII key blocklist must redact each.
  const inner = Object.assign(new Error('inner failure'), {
    password: 'hunter2',
    clientSecret: 's3cret',
    secret: 'topsecret',
    email: 'leak@example.com',
    authorization: 'Bearer token-123',
    cookie: 'session=abc',
    token: 'jwt-blob',
    apiKey: 'key-X',
    api_key: 'key-Y',
    readPassword: 'ro-pass',
    read_encrypted_password: 'enc-blob',
    configPath: '/app/config/db.json',
    // Non-PII fields should pass through unchanged:
    code: 'EAUTH',
    statusCode: 401,
  });
  const outer = Object.assign(new Error('outer'), { cause: inner });
  const result = _internals.sanitizeErrSerializer(outer);
  assert.ok(result.cause, 'Error-instance cause is serialized');
  // PII keys are scrubbed:
  assert.equal(result.cause.password, '[Redacted]');
  assert.equal(result.cause.clientSecret, '[Redacted]');
  assert.equal(result.cause.secret, '[Redacted]');
  assert.equal(result.cause.email, '[Redacted]');
  assert.equal(result.cause.authorization, '[Redacted]');
  assert.equal(result.cause.cookie, '[Redacted]');
  assert.equal(result.cause.token, '[Redacted]');
  assert.equal(result.cause.apiKey, '[Redacted]');
  assert.equal(result.cause.api_key, '[Redacted]');
  assert.equal(result.cause.readPassword, '[Redacted]');
  assert.equal(result.cause.read_encrypted_password, '[Redacted]');
  assert.equal(result.cause.configPath, '[Redacted]');
  // Non-PII fields preserved for triage:
  assert.equal(result.cause.code, 'EAUTH');
  assert.equal(result.cause.statusCode, 401);
});

test('logMethod hook — scrubSqlInMessage replaces full SqlError-shaped strings', () => {
  // SqlError prefix `(conn:N, no:N, SQLState:...)` precedes the server
  // message (which for ER_DUP_ENTRY embeds user values like
  // 'alice@example.com'). Whole-string replacement is required because
  // the server-message prefix itself can leak user data.
  const direct = _internals.scrubSqlInMessage(
    "(conn:1, no:1062) Duplicate entry 'alice@example.com' for key 'users.email'\nsql: INSERT INTO users (email) VALUES (?) - parameters:['alice@example.com']"
  );
  assert.ok(!direct.includes('Duplicate entry'), 'server-message prefix scrubbed (would leak user value)');
  assert.ok(!direct.includes("'alice@example.com'"), 'user value not present anywhere');
  assert.ok(!direct.includes('INSERT INTO'), 'SQL not present');
  assert.ok(direct.includes('[Redacted MariaDB SqlError'));

  // No-op cases:
  assert.equal(_internals.scrubSqlInMessage('plain message'), 'plain message');
  assert.equal(_internals.scrubSqlInMessage(undefined), undefined);
  assert.equal(_internals.scrubSqlInMessage(null), null);
  assert.deepEqual(_internals.scrubSqlInMessage({ a: 1 }), { a: 1 });
});

test('logMethod hook — `logger.error({ err }, err.message)` does not leak SQL via top-level msg', () => {
  // End-to-end assertion: build a fresh pino with full config (hooks +
  // redact + serializer), log a SqlError-style payload using the
  // {bindings, msg} pattern Codex flagged at /home/user/projects/
  // flexible_mold_base/docker-api/src/shared/lib/logger.js:511. The top
  // level msg field MUST NOT contain the SQL substring even though it
  // came from err.message.
  const records = [];
  const dest = new Writable({
    write(chunk, _enc, cb) {
      for (const line of chunk.toString('utf-8').split('\n')) {
        if (!line) continue;
        try { records.push(JSON.parse(line)); } catch { /* partial */ }
      }
      cb();
    },
  });
  const fakeSqlError = Object.assign(new Error('(conn:1, no:1062, SQLState:23000) Duplicate entry \'victim@example.com\' for key \'users.email\'\nsql: INSERT INTO `fmb_users` (email) VALUES (?) - parameters:[\'victim@example.com\']'), {
    name: 'SqlError',
    sqlMessage: "Duplicate entry 'victim@example.com' for key 'users.email'",
    sql: 'INSERT INTO `fmb_users` (email) VALUES (?)',
    errno: 1062,
    code: 'ER_DUP_ENTRY',
  });
  // Wire a pino with the same hook + redact + serializer as production.
  const testLogger = pino(
    {
      level: 'trace',
      hooks: {
        logMethod(args, method, _level) {
          for (let i = 0; i < args.length; i++) {
            if (typeof args[i] === 'string') {
              args[i] = _internals.scrubSqlInMessage(args[i]);
            }
          }
          return method.apply(this, args);
        },
      },
      redact: _internals.redactConfig,
      serializers: { err: _internals.sanitizeErrSerializer },
    },
    dest,
  );
  testLogger.error({ err: fakeSqlError }, fakeSqlError.message);

  const rec = records.find((r) => r.err);
  assert.ok(rec, 'record was emitted');
  assert.ok(!rec.msg.includes('INSERT INTO'), 'top-level msg must not leak SQL');
  assert.ok(!rec.msg.includes("'victim@example.com'"), 'top-level msg must not leak user value via server-message prefix');
  assert.ok(!rec.msg.includes('Duplicate entry'), 'server-message prefix scrubbed');
  assert.ok(rec.msg.includes('[Redacted MariaDB SqlError'), 'msg has redaction marker');
  assert.equal(rec.err.message, '[Redacted MariaDB ER_DUP_ENTRY]', 'err.message scrubbed');
});

// v3.2.29 carry-over from v3.2.27 LOW-1: pin the transport-skip behaviour
// added in v3.2.27 T1. pino-pretty's worker_thread is a reffed handle that
// keeps the test subprocess event loop alive forever — in CI this surfaced
// as `npm test` hanging at the end of the run. Skipping the transport
// conditional on isTestEnv removes the worker_thread.
//
// Strategy: spawn a child node process with NODE_ENV=test, require the
// logger module, emit an error log, and assert the process exits within
// the spawnSync timeout. With the transport active the child would hang
// on the worker_thread until killed by signal.
const { spawnSync } = require('node:child_process');
const path = require('node:path');

test('logger — NODE_ENV=test does NOT keep the event loop alive (transport skipped)', () => {
  const loggerPath = path.resolve(__dirname, '../../src/shared/lib/logger.js');
  const child = spawnSync(
    process.execPath,
    [
      '-e',
      `const { logger } = require(${JSON.stringify(loggerPath)});
       logger.error('transport-skip regression probe');`,
    ],
    {
      // Explicitly DO NOT call process.exit — let the event loop drain
      // naturally. If the worker_thread transport is active it would refuse
      // to drain and the spawnSync timeout would kill the process via signal.
      env: { ...process.env, NODE_ENV: 'test' },
      timeout: 5000,
      encoding: 'utf-8',
    },
  );

  assert.equal(child.signal, null,
    `subprocess was killed by signal ${child.signal} (transport keepalive likely active)`);
  assert.equal(child.status, 0,
    `subprocess exited with status ${child.status}; stderr=${child.stderr}`);
});

test('logger — NODE_TEST_CONTEXT=child-v8 alone also triggers transport skip', () => {
  // Belt-and-suspenders signal documented in logger.js — used by node:test
  // child runners that may not have NODE_ENV=test set.
  const loggerPath = path.resolve(__dirname, '../../src/shared/lib/logger.js');
  const child = spawnSync(
    process.execPath,
    [
      '-e',
      `const { logger } = require(${JSON.stringify(loggerPath)});
       logger.warn('belt-and-suspenders probe');`,
    ],
    {
      env: {
        ...process.env,
        NODE_ENV: 'development',
        NODE_TEST_CONTEXT: 'child-v8',
      },
      timeout: 5000,
      encoding: 'utf-8',
    },
  );

  assert.equal(child.signal, null);
  assert.equal(child.status, 0);
  // The expected one-shot stderr notice from logger.js when NODE_TEST_CONTEXT
  // is the only signal — pin it so future refactors don't silently drop the warning.
  assert.match(child.stderr, /pino-pretty transport suppressed/);
});

// ── parseLogLevel — LOG_LEVEL env override ──────────────────────────────────
test('parseLogLevel returns the fallback for empty/undefined', () => {
  const { parseLogLevel } = _internals;
  assert.equal(parseLogLevel(undefined, 'info'), 'info');
  assert.equal(parseLogLevel('', 'debug'), 'debug');
  assert.equal(parseLogLevel(null, 'warn'), 'warn');
});

test('parseLogLevel accepts a valid level (case/space-insensitive)', () => {
  const { parseLogLevel } = _internals;
  assert.equal(parseLogLevel('DEBUG', 'info'), 'debug');
  assert.equal(parseLogLevel('  warn ', 'info'), 'warn');
  assert.equal(parseLogLevel('silent', 'info'), 'silent');
});

test('parseLogLevel falls back + warns on an invalid level', () => {
  const { parseLogLevel } = _internals;
  const chunks = [];
  const origWrite = process.stderr.write;
  process.stderr.write = (s) => { chunks.push(String(s)); return true; };
  try {
    assert.equal(parseLogLevel('verbose', 'info'), 'info');
  } finally {
    process.stderr.write = origWrite;
  }
  assert.match(chunks.join(''), /LOG_LEVEL=verbose invalid/);
});

test('resolvedLogLevel is a valid pino level', () => {
  assert.ok(['trace', 'debug', 'info', 'warn', 'error', 'fatal', 'silent'].includes(_internals.resolvedLogLevel));
});
