/**
 * flow-recipes-crud.test.js
 *
 * Boots the real flow-recipes router against a mocked pool and asserts:
 *   (a) editor POST with NO blueprint_id (null, pre-binding) stamps owner_id + status pending
 *   (b) GET enriches owner_name + serializeRead strips approved_by/approved_at
 *   (c) editor PUT on their own recipe succeeds (ownerColumn write-scope)
 *   (d) ?is_active=1 filter is forwarded in the SELECT WHERE clause
 *
 * blueprint_id is nullable/pre-binding (spec §4.1) — no parentOwnership is
 * applied, so editors can POST without a blueprint binding.
 *
 * Harness mirrors api-connectors-crud-mask.test.js.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../src/edge/db');

const RECIPE_COLUMNS = [
  'id', 'name', 'description', 'blueprint_id', 'owner_id', 'is_active',
  'status', 'approved_by', 'approved_at', 'review_note',
  'payload_transform_code', 'content_type',
  'consumed_output_keys', 'link_extract', 'external_id_extract',
  'created_at', 'updated_at',
].map((c) => ({ COLUMN_NAME: c }));

// Shared capture — reset before each test.
let captured;
// Per-test role override.
let role;
// Per-test step rows returned by the pre-DELETE guard probe.
// Default [] = no steps, guard passes.
let stepRows;
// Per-test rows returned by the parentOwnership chain lookup against
// fmb_hierarchy_nodes. Default [] = no blueprint found → editor POST/PUT
// denied (403). Set to [{ owner_id: <id> }] per test to control gate outcome.
let blueprintOwnerRows;

function makeRecipeRow(overrides = {}) {
  return {
    id: 'd0edcb09-2c66-4d79-8114-5c3e787de042', name: 'My Recipe', description: null,
    blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', owner_id: '5b729f1e-5c0b-447c-8144-3210469bc62c', is_active: 1,
    status: 'approved', approved_by: '5b729f1e-5c0b-447c-8144-3210469bc62c', approved_at: '2026-01-01 00:00:00',
    review_note: null, payload_transform_code: null,
    content_type: 'application/json',
    consumed_output_keys: null, link_extract: null, external_id_extract: null,
    created_at: '2026-01-01 00:00:00', updated_at: '2026-01-01 00:00:00',
    ...overrides,
  };
}

function makeConn() {
  return {
    async beginTransaction() {},
    async commit() {},
    async rollback() {},
    async query(sql, params) {
      if (/SELECT DATABASE\(\)/.test(sql)) return [{ db: 'testdb' }];
      if (/information_schema\.COLUMNS/i.test(sql)) return RECIPE_COLUMNS;
      // owner-name enrichment
      if (/FROM `fmb_users`/.test(sql)) return [{ id: '5b729f1e-5c0b-447c-8144-3210469bc62c', name: 'Admin User' }];
      // The entitlement read the PUT and the DELETE both take before anything
      // locks, carrying the same scope as their statement. It has to be matched
      // BEFORE the chain arm below: an editor's copy of it ends
      // `AND EXISTS (SELECT 1 FROM \`fmb_hierarchy_nodes\` …)`, which that arm
      // would otherwise answer with the POST-time chain rows. This fixture's
      // row is the caller's — the statements below answer affectedRows
      // regardless of their WHERE, so the predicate itself is measured by the
      // evaluator double in nonowner-write-scoping.test.js and by the real-DB
      // suites, not here.
      if (/^SELECT id FROM `fmb_flow_recipes` WHERE id = \?/.test(sql.trim())) {
        return [{ id: params[0] }];
      }
      // parentOwnership chain lookup (POST-time): SELECT j0.owner_id … FROM fmb_hierarchy_nodes …
      // Guard with ^SELECT so an UPDATE … AND EXISTS (SELECT 1 FROM `fmb_hierarchy_nodes` …)
      // falls through to the UPDATE handler below rather than returning blueprintOwnerRows.
      if (/^SELECT\b/i.test(sql.trim()) && /FROM `fmb_hierarchy_nodes`/.test(sql)) return blueprintOwnerRows;
      // The approval re-pend probe and the delete's reference gate both run on
      // THIS connection now, inside the write transaction — matched on shape
      // rather than on the statement's exact text, so a column added to either
      // query cannot make the arm stop matching and leave the double answering
      // by falling through.
      if (/^SELECT .*`status`.*FROM `fmb_flow_recipes` WHERE id = \? FOR UPDATE/.test(sql.trim())) {
        return [makeRecipeRow()];
      }
      if (/^SELECT 1 FROM `fmb_flow_recipe_steps` WHERE `recipe_id` = \?/.test(sql.trim())) {
        return stepRows;
      }
      // approval re-pend probe (PUT), legacy middleware shape
      if (/SELECT status, payload_transform_code, content_type/.test(sql)) {
        return [makeRecipeRow()];
      }
      // GET by id
      if (/SELECT \* FROM `fmb_flow_recipes` WHERE id = \?/.test(sql)) {
        return [makeRecipeRow({ id: params[0] })];
      }
      // GET list (with optional WHERE)
      if (/SELECT \* FROM `fmb_flow_recipes`/.test(sql)) {
        captured.listSql = sql;
        return [makeRecipeRow()];
      }
      if (/^INSERT INTO `fmb_flow_recipes`/i.test(sql.trim())) {
        captured.insert = { sql, params };
        return { affectedRows: 1 };
      }
      if (/^UPDATE `fmb_flow_recipes`/i.test(sql.trim())) {
        captured.update = { sql, params };
        return { affectedRows: 1 };
      }
      return [];
    },
    release() {},
  };
}

const poolSpy = {
  ro: {
    async getConnection() { return makeConn(); },
    async query(sql, params) {
      // The pre-DELETE step probe moved onto the write connection (see makeConn)
      // — an arm for it here would model a call that never arrives.
      return makeConn().query(sql, params);
    },
  },
  rw: {
    async getConnection() { return makeConn(); },
    async query(sql, params) { return makeConn().query(sql, params); },
  },
};

require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: poolSpy, t: (name) => `fmb_${name}` },
};

const router = require('../../src/edge/routes/app/flow-recipes');

let server; let base;
before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => {
    req.user = { id: role === 'editor' ? '405279b5-48c7-4bd5-8427-69d6ff5556a7' : '5b729f1e-5c0b-447c-8144-3210469bc62c', role, email: 'a@x' };
    next();
  });
  app.use('/fr', router);
  server = http.createServer(app);
  await new Promise((r) => server.listen(0, r));
  base = `http://127.0.0.1:${server.address().port}`;
});
after(() => server && server.close());
beforeEach(() => { captured = {}; role = 'admin'; stepRows = []; blueprintOwnerRows = []; });

async function req(method, path, body) {
  const res = await fetch(`${base}${path}`, {
    method,
    headers: { 'content-type': 'application/json' },
    body: body ? JSON.stringify(body) : undefined,
  });
  const text = await res.text();
  let json;
  try { json = JSON.parse(text); } catch { json = text; }
  return { status: res.status, json };
}

describe('flow-recipes CRUD — editor POST stamps owner_id + status pending when bound to own blueprint', () => {
  it('editor POST bound to own blueprint stamps owner_id = editor id and status pending', async () => {
    role = 'editor';
    // Recipes require a blueprint binding; the editor must own the blueprint (or
    // it must be shared). parentOwnership gate passes when owner_id = editor-1.
    blueprintOwnerRows = [{ owner_id: '405279b5-48c7-4bd5-8427-69d6ff5556a7' }];
    const { status } = await req('POST', '/fr', {
      name: 'My Recipe', blueprint_id: '1e45e2d0-3704-4291-8f2d-1143bef905a2',
      content_type: 'application/json',
    });
    assert.equal(status, 200);
    // INSERT must have been captured.
    assert.ok(captured.insert, 'INSERT must have been called');
    // The INSERT SQL should contain owner_id stamped to editor-1.
    const colMatch = captured.insert.sql.match(/INSERT INTO `fmb_flow_recipes` \(([^)]+)\)/);
    assert.ok(colMatch, 'INSERT should specify columns');
    const cols = colMatch[1].split(',').map((c) => c.trim().replace(/`/g, ''));
    // owner_id should appear in the column list.
    assert.ok(cols.includes('owner_id'), 'INSERT must include owner_id column');
    const ownerIdx = cols.indexOf('owner_id');
    const insertedOwnerId = captured.insert.params[ownerIdx];
    assert.equal(insertedOwnerId, '405279b5-48c7-4bd5-8427-69d6ff5556a7', 'owner_id must be stamped to the editor');
    // status should be 'pending' for an editor POST (approval middleware).
    const statusIdx = cols.indexOf('status');
    assert.ok(statusIdx !== -1, 'INSERT must include status column');
    assert.equal(captured.insert.params[statusIdx], 'pending', 'status must be pending for editor');
  });
});

describe('flow-recipes CRUD — GET strips approved_by/approved_at via serializeRead', () => {
  it('GET list returns owner_name and strips approved_by + approved_at', async () => {
    const { status, json } = await req('GET', '/fr');
    assert.equal(status, 200);
    assert.ok(Array.isArray(json.data), 'response must have data array');
    const row = json.data[0];
    // owner_name is enriched from fmb_users.
    assert.ok('owner_name' in row, 'response must include owner_name');
    // serializeRead must strip approved_by and approved_at.
    assert.ok(!Object.prototype.hasOwnProperty.call(row, 'approved_by'), 'approved_by must be stripped');
    assert.ok(!Object.prototype.hasOwnProperty.call(row, 'approved_at'), 'approved_at must be stripped');
    // status and review_note remain visible.
    assert.ok(Object.prototype.hasOwnProperty.call(row, 'status'), 'status must remain');
  });
});

describe('flow-recipes CRUD — editor PUT on own recipe succeeds (ownerColumn write-scope)', () => {
  it('editor PUT on their own recipe issues UPDATE (ownerColumn scopes write)', async () => {
    role = 'editor';
    // parentOwnership is embedded in the UPDATE WHERE clause as an EXISTS
    // subquery (no separate chain lookup). The mock returns affectedRows=1
    // regardless of WHERE conditions, so the UPDATE is the success signal.
    const { status } = await req('PUT', '/fr/d0edcb09-2c66-4d79-8114-5c3e787de042', {
      name: 'Updated Name',
      content_type: 'application/json',
    });
    assert.equal(status, 200);
    assert.ok(captured.update, 'UPDATE must have been called for editor PUT');
  });
});

describe('flow-recipes CRUD — filter ?is_active=1 builds WHERE', () => {
  it('?is_active=1 is forwarded in the SELECT WHERE clause', async () => {
    const { status } = await req('GET', '/fr?is_active=1');
    assert.equal(status, 200);
    assert.ok(captured.listSql, 'list SELECT must have been issued');
    assert.ok(/is_active/.test(captured.listSql), '?is_active=1 must appear in the WHERE clause');
  });
});

describe('flow-recipes CRUD — pre-DELETE guard: reject if steps exist', () => {
  it('DELETE recipe that has steps → 409 RECIPE_HAS_STEPS', async () => {
    // Simulate a recipe that still has step rows.
    stepRows = [{ 1: 1 }];
    const { status, json } = await req('DELETE', '/fr/d0edcb09-2c66-4d79-8114-5c3e787de042');
    assert.equal(status, 409, `expected 409, got ${status}: ${JSON.stringify(json)}`);
    // The refusal now travels in the standard envelope every other refusal on
    // this path uses — `{ error: { code, message } }` — because it is the CRUD
    // factory issuing it rather than a middleware with its own shape. The bare
    // string this replaced had no reader outside this assertion.
    assert.equal(json.error.code, 'RECIPE_HAS_STEPS', 'error code must be RECIPE_HAS_STEPS');
  });

  it('DELETE recipe with no steps → guard passes (not 409)', async () => {
    // stepRows is [] (default) → no steps → guard passes, CRUD factory handles the delete.
    const { status } = await req('DELETE', '/fr/d0edcb09-2c66-4d79-8114-5c3e787de042');
    assert.notEqual(status, 409, 'guard must not block deletion when no steps exist');
  });
});

describe('flow-recipes CRUD — parentOwnership blueprint gate', () => {
  it('editor POST bound to own blueprint → 200', async () => {
    role = 'editor';
    blueprintOwnerRows = [{ owner_id: '405279b5-48c7-4bd5-8427-69d6ff5556a7' }];
    const { status } = await req('POST', '/fr', {
      name: 'Own Blueprint Recipe', blueprint_id: '1e45e2d0-3704-4291-8f2d-1143bef905a2',
      content_type: 'application/json',
    });
    assert.equal(status, 200, 'editor POST on own blueprint must succeed');
    assert.ok(captured.insert, 'INSERT must have been called');
  });

  it('editor POST bound to foreign blueprint → 403', async () => {
    role = 'editor';
    blueprintOwnerRows = [{ owner_id: 'f8addf3d-8098-4ebe-8156-d3a8afaea553' }];
    const { status, json } = await req('POST', '/fr', {
      name: 'Foreign Blueprint Recipe', blueprint_id: '5e5cd5ae-aecb-4971-8d9a-9526c4d4c154',
      content_type: 'application/json',
    });
    assert.equal(status, 403, `editor must be denied when blueprint is foreign (got ${status}: ${JSON.stringify(json)})`);
    assert.ok(!captured.insert, 'INSERT must NOT have been called');
  });

  it('editor POST bound to shared blueprint (owner_id = null) → 200', async () => {
    role = 'editor';
    blueprintOwnerRows = [{ owner_id: null }];
    const { status } = await req('POST', '/fr', {
      name: 'Shared Blueprint Recipe', blueprint_id: 'eda78c32-3df9-4e76-86ca-d4d7045c843c',
      content_type: 'application/json',
    });
    assert.equal(status, 200, 'editor POST on shared (null-owner) blueprint must succeed');
    assert.ok(captured.insert, 'INSERT must have been called');
  });

  it('editor POST with null blueprint_id → 403', async () => {
    role = 'editor';
    // blueprintOwnerRows stays [] (default) — irrelevant because parentValue==null
    // short-circuits the chain lookup immediately.
    const { status, json } = await req('POST', '/fr', {
      name: 'Unbound Recipe', blueprint_id: null,
      content_type: 'application/json',
    });
    assert.equal(status, 403, `null blueprint_id must be denied for editor (got ${status}: ${JSON.stringify(json)})`);
    assert.ok(!captured.insert, 'INSERT must NOT have been called');
  });

  it('admin POST with any blueprint → 200 (admin bypasses parentOwnership gate)', async () => {
    role = 'admin';
    // blueprintOwnerRows stays [] — admin bypasses the gate, no chain lookup issued.
    const { status } = await req('POST', '/fr', {
      name: 'Admin Recipe', blueprint_id: 'f65dbeb6-4d86-4704-82e6-444f8631fdf8',
      content_type: 'application/json',
    });
    assert.equal(status, 200, 'admin POST must always succeed regardless of blueprint ownership');
    assert.ok(captured.insert, 'INSERT must have been called');
  });
});

describe('flow-recipes CRUD — consumed_output_keys reserved-key guard (Task 2)', () => {
  it('POST with a consumed_output_keys entry exactly "payload" → 400 RESERVED_OUTPUT_KEY, no INSERT', async () => {
    role = 'admin';
    const { status, json } = await req('POST', '/fr', {
      name: 'Bad Keys', blueprint_id: 'f65dbeb6-4d86-4704-82e6-444f8631fdf8', content_type: 'application/json',
      consumed_output_keys: ['ok', 'payload'],
    });
    assert.equal(status, 400, `expected 400, got ${status}: ${JSON.stringify(json)}`);
    assert.equal(json.error.code, 'RESERVED_OUTPUT_KEY');
    assert.match(json.error.message, /payload/);
    assert.ok(!captured.insert, 'INSERT must NOT run when a reserved key is present');
  });

  it('POST with a consumed_output_keys entry starting "payload." → 400 RESERVED_OUTPUT_KEY', async () => {
    role = 'admin';
    const { status, json } = await req('POST', '/fr', {
      name: 'Bad Keys 2', blueprint_id: 'f65dbeb6-4d86-4704-82e6-444f8631fdf8', content_type: 'application/json',
      consumed_output_keys: ['payload.qty'],
    });
    assert.equal(status, 400, `expected 400, got ${status}: ${JSON.stringify(json)}`);
    assert.equal(json.error.code, 'RESERVED_OUTPUT_KEY');
    assert.ok(!captured.insert, 'INSERT must NOT run');
  });

  it('POST with only non-reserved keys ("qty", "payloadX") → 200 (INSERT runs)', async () => {
    role = 'admin';
    const { status, json } = await req('POST', '/fr', {
      name: 'Good Keys', blueprint_id: 'f65dbeb6-4d86-4704-82e6-444f8631fdf8', content_type: 'application/json',
      consumed_output_keys: ['qty', 'payloadX'],
    });
    assert.equal(status, 200, `expected 200, got ${status}: ${JSON.stringify(json)}`);
    assert.ok(captured.insert, 'INSERT must run for non-reserved keys');
  });

  it('PUT with a reserved consumed_output_keys entry → 400, no UPDATE', async () => {
    role = 'admin';
    const { status, json } = await req('PUT', '/fr/d0edcb09-2c66-4d79-8114-5c3e787de042', {
      name: 'Updated', content_type: 'application/json',
      consumed_output_keys: ['payload'],
    });
    assert.equal(status, 400, `expected 400, got ${status}: ${JSON.stringify(json)}`);
    assert.equal(json.error.code, 'RESERVED_OUTPUT_KEY');
    assert.ok(!captured.update, 'UPDATE must NOT run when a reserved key is present');
  });

  it('POST without consumed_output_keys is unaffected (guard is a no-op) → 200', async () => {
    role = 'admin';
    const { status } = await req('POST', '/fr', {
      name: 'No Keys', blueprint_id: 'f65dbeb6-4d86-4704-82e6-444f8631fdf8', content_type: 'application/json',
    });
    assert.equal(status, 200);
    assert.ok(captured.insert, 'INSERT must run when consumed_output_keys is absent');
  });
});
