/**
 * api-connectors-clone.test.js — POST /:id/clone route behaviour.
 *
 * Boots the real api-connectors router against a mocked db pool (require.cache
 * seed, same pattern as api-connectors-io.test.js) and asserts:
 *   - admin clone stamps the caller as owner, names "<src> (copy)", copies the
 *     encrypted auth_config ciphertext VERBATIM (secret survives, never masked),
 *     and drops bundle membership (group fields NULL in the INSERT)
 *   - a caller-supplied name overrides the default
 *   - a missing source 404s
 *   - the editor blueprint-ownership gate mirrors import (own/shared 201,
 *     foreign 403 no insert)
 *   - a plain user is rejected 403
 *   - an api_connector.clone audit row is written, secret-free
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../src/edge/db');

let state;
function makeConn() {
  return {
    async query(sql, params) {
      state.queries.push({ sql, params });
      if (/SELECT owner_id FROM `fmb_hierarchy_nodes` WHERE id = \?/.test(sql)) {
        return state.blueprintOwner === undefined ? [] : [{ owner_id: state.blueprintOwner }];
      }
      // Source row read (clone): SELECT name, description, ... FROM api_connectors
      if (/FROM `fmb_api_connectors` WHERE id = \?/.test(sql) && /SELECT name, description/.test(sql)) {
        return state.sourceRow ? [state.sourceRow] : [];
      }
      if (/^INSERT INTO `fmb_api_connectors`/.test(sql.trim())) {
        state.insertParams = params;
        return { affectedRows: 1 };
      }
      if (/^INSERT INTO `fmb_feature_audit`/.test(sql.trim())) {
        state.auditParams = params;
        return { affectedRows: 1 };
      }
      // Best-effort timeout_ms carry (clone): src→dst self-join UPDATE.
      if (/SET dst\.timeout_ms = src\.timeout_ms/.test(sql)) {
        if (state.failTimeoutCarry) {
          const e = new Error("Unknown column 'timeout_ms'");
          e.code = 'ER_BAD_FIELD_ERROR'; e.errno = 1054;
          throw e;
        }
        return { affectedRows: 1 };
      }
      if (/SELECT \* FROM `fmb_api_connectors` WHERE id = \?/.test(sql)) {
        return [{ id: params[0], name: 'cloned' }];
      }
      // Save-time egress allow-list read (hostAllowedForUrl). Absent state →
      // [] rows → loadHostAllowlist returns [] → allow-all, so existing tests
      // are unaffected; set state.allowlistRow to enforce.
      if (/SELECT `value` FROM `fmb_system_settings` WHERE `key` = \?/.test(sql)) {
        return state.allowlistRow === undefined ? [] : [{ value: state.allowlistRow }];
      }
      return [];
    },
    release() {},
  };
}

// The real pool facade (edge/db.js) exposes BOTH .getConnection() and .query();
// the allow-list gate calls pool.ro.query() directly, so the mock must too.
const poolSpy = {
  ro: { async getConnection() { return makeConn(); }, async query(sql, params) { return makeConn().query(sql, params); } },
  rw: { async getConnection() { return makeConn(); }, async query(sql, params) { return makeConn().query(sql, params); } },
};

require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: poolSpy, t: (name) => `fmb_${name}` },
};

const router = require('../../src/edge/routes/app/api-connectors');

let server;
let base;
let currentUser;

before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { req.user = currentUser; next(); });
  app.use('/c', router);
  server = http.createServer(app);
  await new Promise((r) => server.listen(0, r));
  base = `http://127.0.0.1:${server.address().port}`;
});

after(() => server && server.close());

function bearerSource(overrides = {}) {
  return {
    name: 'Weather', description: 'd', is_active: 1, owner_id: 'admin-1', blueprint_id: 'bp-1',
    section_key: 'sec', method: 'GET', url: 'http://svc/x', auth_type: 'bearer',
    auth_config: JSON.stringify({ token: 'enc:v1:abc:def:cipher' }),
    request_config: null, response_config: null, dispatch_origin: 'infra',
    ...overrides,
  };
}

beforeEach(() => {
  state = { queries: [], sourceRow: null, insertParams: null, auditParams: null, blueprintOwner: undefined };
  currentUser = { id: 'admin-1', role: 'admin', email: 'a@x' };
});

async function req(method, path, body) {
  const res = await fetch(`${base}${path}`, {
    method,
    headers: { 'content-type': 'application/json' },
    body: body ? JSON.stringify(body) : undefined,
  });
  return { status: res.status, json: await res.json() };
}

// INSERT params index map:
//   0 id, 1 name, 2 description, 3 is_active, 4 owner_id, 5 blueprint_id,
//   6 section_key, 7 method, 8 url, 9 auth_type, 10 auth_config,
//   11 request_config, 12 response_config, 13 dispatch_origin
describe('POST /:id/clone', () => {
  it('admin clone: owner stamped, default "(copy)" name, encrypted secret copied verbatim', async () => {
    state.sourceRow = bearerSource();
    const { status, json } = await req('POST', '/c/src-1/clone');
    assert.equal(status, 201);
    const p = state.insertParams;
    assert.equal(p[1], 'Weather (copy)', 'name defaults to "<src> (copy)"');
    assert.equal(p[4], 'admin-1', 'owner stamped to the caller');
    assert.equal(p[5], 'bp-1', 'blueprint binding copied from source');
    assert.match(p[10], /enc:v1:abc:def:cipher/, 'encrypted secret copied verbatim (not masked/stripped)');
    // The masked read response never carries plaintext or ciphertext.
    assert.equal(json.data.id, p[0]);
  });

  it('sanitizes URL-embedded credentials from a legacy source url on clone', async () => {
    state.sourceRow = bearerSource({ url: 'https://user:s3cr3t@svc/x' });
    const { status } = await req('POST', '/c/src-1/clone');
    assert.equal(status, 201);
    assert.equal(state.insertParams[8], 'https://svc/x', 'clone must not copy url credentials forward');
  });

  it('rejects a clone whose source url host is off the egress allow-list (422, no insert)', async () => {
    state.sourceRow = bearerSource({ url: 'http://blocked.example.net/x' });
    state.allowlistRow = JSON.stringify(['allowed.example.com']);
    const { status, json } = await req('POST', '/c/src-1/clone');
    assert.equal(status, 422);
    assert.equal(json.error.code, 'EGRESS_BLOCKED');
    assert.equal(state.insertParams, null, 'an off-list clone must not INSERT');
  });

  it('allows a clone whose source url host is on the egress allow-list (201)', async () => {
    state.sourceRow = bearerSource({ url: 'http://allowed.example.com/x' });
    state.allowlistRow = JSON.stringify(['allowed.example.com']);
    const { status } = await req('POST', '/c/src-1/clone');
    assert.equal(status, 201);
  });

  it('stamps status=approved on an admin clone (approval lifecycle)', async () => {
    state.sourceRow = bearerSource();
    const { status } = await req('POST', '/c/src-1/clone');
    assert.equal(status, 201);
    const upd = state.queries.find((q) => /UPDATE `fmb_api_connectors`/.test(q.sql) && /status='approved'/.test(q.sql));
    assert.ok(upd, 'an admin clone must stamp status=approved');
  });

  it('stamps status=pending on an editor clone (no auto-approve via clone)', async () => {
    currentUser = { id: 'ed-1', role: 'editor', email: 'e@x' };
    state.sourceRow = bearerSource({ owner_id: 'ed-1' });
    state.blueprintOwner = 'ed-1';
    const { status } = await req('POST', '/c/src-1/clone');
    assert.equal(status, 201);
    const upd = state.queries.find((q) => /UPDATE `fmb_api_connectors`/.test(q.sql) && /status='pending'/.test(q.sql));
    assert.ok(upd, 'an editor clone must stamp status=pending, never NULL');
  });

  it('carries the source per-connector timeout to the clone (tolerant src→dst UPDATE)', async () => {
    state.sourceRow = bearerSource();
    const { status } = await req('POST', '/c/src-1/clone');
    assert.equal(status, 201);
    const carry = state.queries.find((q) => /SET dst\.timeout_ms = src\.timeout_ms/.test(q.sql));
    assert.ok(carry, 'clone must issue the timeout carry UPDATE');
    assert.deepEqual(carry.params, ['src-1', state.insertParams[0]], 'carries from source id to new clone id');
  });

  it('clone still succeeds (201) when the target lacks timeout_ms (no-ALTER DB)', async () => {
    state.sourceRow = bearerSource();
    state.failTimeoutCarry = true; // simulate Unknown column 'timeout_ms'
    const { status } = await req('POST', '/c/src-1/clone');
    assert.equal(status, 201, 'a missing timeout_ms column must not fail the clone');
  });

  it('clone drops bundle membership (group fields NULL in the INSERT SQL)', async () => {
    state.sourceRow = bearerSource();
    await req('POST', '/c/src-1/clone');
    const insertQuery = state.queries.find((q) => /^INSERT INTO `fmb_api_connectors`/.test(q.sql.trim()));
    assert.ok(insertQuery, 'an INSERT ran');
    assert.match(insertQuery.sql, /NULL, NULL, NULL, NULL\)/, 'group_id/label/mode/sequence inserted as NULL');
  });

  it('strips chain wiring (input_from_step) when cloning — the clone is unbundled', async () => {
    state.sourceRow = bearerSource({
      request_config: JSON.stringify({
        input_from_step: [{ var: 'x', from_sequence: 1, path: 'a' }],
        headers: { a: 'b' },
      }),
    });
    const { status } = await req('POST', '/c/src-1/clone');
    assert.equal(status, 201);
    const rc = JSON.parse(state.insertParams[11]);
    assert.equal('input_from_step' in rc, false, 'stale chain wiring removed');
    assert.deepEqual(rc.headers, { a: 'b' }, 'other request_config keys preserved');
  });

  it('uses a caller-supplied name when provided', async () => {
    state.sourceRow = bearerSource();
    await req('POST', '/c/src-1/clone', { name: 'My Clone' });
    assert.equal(state.insertParams[1], 'My Clone');
  });

  it('404s when the source connector is missing', async () => {
    state.sourceRow = null;
    const { status, json } = await req('POST', '/c/missing/clone');
    assert.equal(status, 404);
    assert.equal(json.error.code, 'NOT_FOUND');
    assert.equal(state.insertParams, null, 'no INSERT for a missing source');
  });

  it('writes a secret-free api_connector.clone audit row', async () => {
    state.sourceRow = bearerSource();
    await req('POST', '/c/src-1/clone');
    assert.ok(state.auditParams, 'an audit row was written');
    const meta = state.auditParams[2];
    assert.match(meta, /"source_id":"src-1"/);
    assert.doesNotMatch(meta, /enc:v1|cipher|token/, 'audit metadata carries no secret content');
  });

  describe('editor source-ownership gate', () => {
    it('lets an editor clone a connector they OWN on a blueprint they own', async () => {
      currentUser = { id: 'ed-1', role: 'editor', email: 'e@x' };
      state.sourceRow = bearerSource({ owner_id: 'ed-1', blueprint_id: 'bp-1' });
      state.blueprintOwner = 'ed-1';
      const { status } = await req('POST', '/c/src-1/clone');
      assert.equal(status, 201);
      assert.equal(state.insertParams[4], 'ed-1', 'clone owned by the editor');
    });

    it('lets an editor clone their own connector on a SHARED (NULL-owner) blueprint', async () => {
      currentUser = { id: 'ed-1', role: 'editor', email: 'e@x' };
      state.sourceRow = bearerSource({ owner_id: 'ed-1', blueprint_id: 'bp-1' });
      state.blueprintOwner = null;
      const { status } = await req('POST', '/c/src-1/clone');
      assert.equal(status, 201);
    });

    it('rejects an editor who owns the source but whose blueprint is now foreign (403, no insert)', async () => {
      // The blueprint was shared at create time but later claimed by another
      // user; the clone would otherwise land active on a blueprint the editor
      // can no longer manage, bypassing the create/import parentOwnership gate.
      currentUser = { id: 'ed-1', role: 'editor', email: 'e@x' };
      state.sourceRow = bearerSource({ owner_id: 'ed-1', blueprint_id: 'bp-1' });
      state.blueprintOwner = 'someone-else';
      const { status, json } = await req('POST', '/c/src-1/clone');
      assert.equal(status, 403);
      assert.equal(json.error.code, 'FORBIDDEN');
      assert.equal(state.insertParams, null, 'no INSERT when the blueprint is foreign');
    });

    it('rejects an editor cloning a connector owned by SOMEONE ELSE (403, no insert)', async () => {
      // Even when the editor owns the connector's blueprint, cloning copies the
      // source credential — they must own the source itself.
      currentUser = { id: 'ed-1', role: 'editor', email: 'e@x' };
      state.sourceRow = bearerSource({ owner_id: 'someone-else' });
      const { status, json } = await req('POST', '/c/src-1/clone');
      assert.equal(status, 403);
      assert.equal(json.error.code, 'FORBIDDEN');
      assert.equal(state.insertParams, null, 'no INSERT when the editor does not own the source');
    });

    it('rejects an editor cloning a NULL-owned (degraded) connector (403, no insert)', async () => {
      currentUser = { id: 'ed-1', role: 'editor', email: 'e@x' };
      state.sourceRow = bearerSource({ owner_id: null });
      const { status, json } = await req('POST', '/c/src-1/clone');
      assert.equal(status, 403);
      assert.equal(json.error.code, 'FORBIDDEN');
      assert.equal(state.insertParams, null);
    });

    it('lets an admin clone a connector owned by someone else', async () => {
      // currentUser defaults to admin-1; source owned by another user.
      state.sourceRow = bearerSource({ owner_id: 'someone-else' });
      const { status } = await req('POST', '/c/src-1/clone');
      assert.equal(status, 201);
      assert.equal(state.insertParams[4], 'admin-1', 'admin clone owned by the admin');
    });
  });

  it('rejects a plain user (403, no insert)', async () => {
    currentUser = { id: 'u-1', role: 'user', email: 'u@x' };
    state.sourceRow = bearerSource();
    const { status, json } = await req('POST', '/c/src-1/clone');
    assert.equal(status, 403);
    assert.equal(json.error.code, 'FORBIDDEN');
    assert.equal(state.insertParams, null, 'plain user clone must not insert');
  });
});
