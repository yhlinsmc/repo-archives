// docker-api/tests/unit/flow-dispatch-step.test.js
// Direct unit tests for the dispatchOneStep shared primitive.
// Mocks: forwardToEdge, executeRequest, isBlockedIp.
const { test } = require('node:test');
const assert = require('node:assert');

// --- mutable state controlled per test ---
let forwardToEdgeImpl = async () => ({ status: 200, data: { ok: true } });
let executeRequestImpl = async () => ({ upstream_status: 200, headers: {}, body: '{}', duration_ms: 5 });
let isBlockedIpImpl = () => false;
const edgeCalls = [];

// --- inject mocks before requiring the module under test ---
require.cache[require.resolve('../../src/infra/lib/remote-client')] = {
  exports: {
    forwardToEdge: async (opts) => { edgeCalls.push(opts); return forwardToEdgeImpl(opts); },
  },
};
require.cache[require.resolve('../../src/shared/lib/connector-http')] = {
  exports: { executeRequest: async (req, opts) => executeRequestImpl(req, opts) },
};
require.cache[require.resolve('../../src/shared/lib/ssrf-guard')] = {
  exports: { isBlockedIp: (ip) => isBlockedIpImpl(ip) },
};
require.cache[require.resolve('../../src/shared/lib/logger')] = {
  exports: { logger: { child: () => ({ warn: () => {}, error: () => {}, info: () => {} }) } },
};

const { dispatchOneStep } = require('../../src/infra/lib/flow-dispatch-step');

const USER = { id: 'u1', role: 'editor' };

test('edge-mode: returns ok:true with envelope, does not call /result', async () => {
  edgeCalls.length = 0;
  forwardToEdgeImpl = async (opts) => {
    if (opts.path.endsWith('/prepare')) {
      return { status: 200, data: { data: { mode: 'edge', envelope: { upstream_status: 201, body: '{"id":1}' } } } };
    }
    return { status: 200, data: { ok: true } };
  };

  const r = await dispatchOneStep({ stepId: 's1', inputs: { payload: '{}' }, runId: null, test: false, user: USER, reqId: 'r1' });

  assert.strictEqual(r.ok, true);
  assert.strictEqual(r.status, 200);
  assert.deepStrictEqual(r.envelope, { upstream_status: 201, body: '{"id":1}' });
  assert.ok(edgeCalls.some((c) => c.path.endsWith('/prepare')), 'should call /prepare');
  assert.ok(!edgeCalls.some((c) => c.path.endsWith('/result')), 'edge-mode must NOT call /result');
});

test('infra-mode success: executes socket, reports result success, returns ok:true with envelope', async () => {
  edgeCalls.length = 0;
  forwardToEdgeImpl = async (opts) => {
    if (opts.path.endsWith('/prepare')) {
      return {
        status: 200,
        data: {
          data: {
            mode: 'infra', dispatch_id: 'd1', recipe_id: 'rc1',
            prepared: { method: 'POST', url: 'https://ok.test/x', headers: {}, body: '{}', pinned_ip: '93.184.216.34', family: 4, timeout_ms: 10000, max_bytes: 1000000 },
          },
        },
      };
    }
    return { status: 200, data: { ok: true } };
  };
  executeRequestImpl = async () => ({ upstream_status: 200, headers: {}, body: '{"ok":true}', duration_ms: 7 });
  isBlockedIpImpl = () => false;

  const r = await dispatchOneStep({ stepId: 's1', inputs: {}, runId: 'run1', test: false, user: USER, reqId: 'r1' });

  assert.strictEqual(r.ok, true);
  assert.strictEqual(r.status, 200);
  assert.strictEqual(r.envelope.upstream_status, 200);
  const resultCall = edgeCalls.find((c) => c.path.endsWith('/result'));
  assert.ok(resultCall, 'should report outcome to /result');
  assert.strictEqual(resultCall.body.success, true);
  assert.strictEqual(resultCall.body.step_id, 's1');
  assert.strictEqual(resultCall.body.run_id, 'run1');
});

test('non-200 prepare: returns ok:false with passthrough prep shape, does NOT call /result', async () => {
  edgeCalls.length = 0;
  forwardToEdgeImpl = async (opts) => {
    if (opts.path.endsWith('/prepare')) {
      return { status: 422, data: { error: { message: 'RECIPE_NOT_APPROVED', code: 'RECIPE_NOT_APPROVED' } } };
    }
    return { status: 200, data: { ok: true } };
  };

  const r = await dispatchOneStep({ stepId: 's1', inputs: {}, runId: null, test: false, user: USER, reqId: 'r1' });

  assert.strictEqual(r.ok, false);
  assert.strictEqual(r.status, 422);
  assert.ok(r.prep, 'should carry the passthrough prep object');
  assert.ok(!edgeCalls.some((c) => c.path.endsWith('/result')), 'non-200 prepare must NOT call /result');
});

test('malformed prepare (unknown mode): returns ok:false status:502 INTERNAL_ERROR', async () => {
  edgeCalls.length = 0;
  forwardToEdgeImpl = async (opts) => {
    if (opts.path.endsWith('/prepare')) {
      return { status: 200, data: { data: { mode: 'unknown' } } };
    }
    return { status: 200, data: { ok: true } };
  };

  const r = await dispatchOneStep({ stepId: 's1', inputs: {}, runId: null, test: false, user: USER, reqId: 'r1' });

  assert.strictEqual(r.ok, false);
  assert.strictEqual(r.status, 502);
  assert.strictEqual(r.errorCode, 'INTERNAL_ERROR');
});

test('malformed prepare (infra with no prepared): returns ok:false status:502 INTERNAL_ERROR', async () => {
  edgeCalls.length = 0;
  forwardToEdgeImpl = async (opts) => {
    if (opts.path.endsWith('/prepare')) {
      // mode=infra but missing the prepared object
      return { status: 200, data: { data: { mode: 'infra', dispatch_id: 'd1', recipe_id: 'rc1' } } };
    }
    return { status: 200, data: { ok: true } };
  };

  const r = await dispatchOneStep({ stepId: 's1', inputs: {}, runId: null, test: false, user: USER, reqId: 'r1' });

  assert.strictEqual(r.ok, false);
  assert.strictEqual(r.status, 502);
  assert.strictEqual(r.errorCode, 'INTERNAL_ERROR');
});

test('infra-mode execute throws: returns ok:false, errorCode from thrown error, calls reportResult with success:false', async () => {
  edgeCalls.length = 0;
  forwardToEdgeImpl = async (opts) => {
    if (opts.path.endsWith('/prepare')) {
      return {
        status: 200,
        data: {
          data: {
            mode: 'infra', dispatch_id: 'd3', recipe_id: 'rc1',
            prepared: { method: 'POST', url: 'https://ok.test/x', headers: {}, body: '{}', pinned_ip: '93.184.216.34', family: 4, timeout_ms: 5000, max_bytes: 1000000 },
          },
        },
      };
    }
    return { status: 200, data: { ok: true } };
  };
  isBlockedIpImpl = () => false;
  const connErr = Object.assign(new Error('connection refused'), { code: 'CONNECTOR_UNREACHABLE' });
  executeRequestImpl = async () => { throw connErr; };

  const r = await dispatchOneStep({ stepId: 's1', inputs: {}, runId: 'run1', test: false, user: USER, reqId: 'r1' });

  assert.strictEqual(r.ok, false);
  // CONNECTOR_UNREACHABLE maps to 502 per ERROR_STATUS map
  assert.strictEqual(r.status, 502);
  assert.strictEqual(r.errorCode, 'CONNECTOR_UNREACHABLE');
  const resultCall = edgeCalls.find((c) => c.path.endsWith('/result'));
  assert.ok(resultCall, 'should report failure to /result');
  assert.strictEqual(resultCall.body.success, false);
  assert.strictEqual(resultCall.body.error_code, 'CONNECTOR_UNREACHABLE');
  assert.strictEqual(resultCall.body.step_id, 's1');
  assert.strictEqual(resultCall.body.run_id, 'run1');
});

test('SSRF-blocked pin: returns ok:false 422 SSRF_BLOCKED, calls reportResult with success:false', async () => {
  edgeCalls.length = 0;
  forwardToEdgeImpl = async (opts) => {
    if (opts.path.endsWith('/prepare')) {
      return {
        status: 200,
        data: {
          data: {
            mode: 'infra', dispatch_id: 'd2', recipe_id: 'rc1',
            prepared: { method: 'POST', url: 'https://ok.test/x', headers: {}, body: '{}', pinned_ip: '127.0.0.1', family: 4 },
          },
        },
      };
    }
    return { status: 200, data: { ok: true } };
  };
  isBlockedIpImpl = () => true;

  const r = await dispatchOneStep({ stepId: 's1', inputs: {}, runId: null, test: false, user: USER, reqId: 'r1' });

  assert.strictEqual(r.ok, false);
  assert.strictEqual(r.status, 422);
  assert.strictEqual(r.errorCode, 'SSRF_BLOCKED');
  const resultCall = edgeCalls.find((c) => c.path.endsWith('/result'));
  assert.ok(resultCall, 'should report failure to /result');
  assert.strictEqual(resultCall.body.success, false);
  assert.strictEqual(resultCall.body.error_code, 'SSRF_BLOCKED');
});
