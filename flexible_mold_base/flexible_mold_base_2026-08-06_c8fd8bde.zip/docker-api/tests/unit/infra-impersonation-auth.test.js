const { describe, it, beforeEach, afterEach } = require('node:test');
const assert = require('node:assert/strict');
const { signHs256 } = require('../helpers/jwt-hs256');

// >= 32 chars: config.js now hard-fails a shorter JWT_SECRET at load (local mode).
process.env.JWT_SECRET = 'test-secret-impersonation-min-32chars';

const edgeClient = require('../../src/infra/lib/edge-state-client');
const authMiddleware = require('../../src/infra/middleware/auth');

function makeReq(token, impersonateId) {
  const headers = { authorization: `Bearer ${token}` };
  if (impersonateId) headers['x-impersonate-user-id'] = impersonateId;
  return { headers, path: '/api/schema/user_templates', method: 'GET', ip: '127.0.0.1', user: null };
}

/**
 * Simulate an OIDC-authed request (express-openid-connect populates req.oidc).
 * The `sub` claim maps to keycloak_sub via mapTokenToUser; the resolved user
 * identity comes from edge resolveIdentity via source:'oidc'.
 */
function makeOidcReq(sub, impersonateId) {
  const headers = {};
  if (impersonateId) headers['x-impersonate-user-id'] = impersonateId;
  return {
    headers,
    path: '/api/schema/user_templates',
    method: 'GET',
    ip: '127.0.0.1',
    user: null,
    oidc: {
      isAuthenticated: () => true,
      user: { sub },
    },
  };
}

function makeRes() { return {}; }

describe('infra impersonation auth', () => {
  let origResolve;
  beforeEach(() => {
    authMiddleware._resetCacheForTests();
    origResolve = edgeClient.resolveIdentity;
  });
  afterEach(() => { edgeClient.resolveIdentity = origResolve; });

  it('admin impersonating a user → req.user is the target, impersonated=true, impersonator is the admin', async () => {
    edgeClient.resolveIdentity = async ({ userId }) => {
      if (userId === 'admin-1') return { user: { id: 'admin-1', email: 'a@x', role: 'admin' }, banned: false, pool_ready: true };
      if (userId === 'user-9') return { user: { id: 'user-9', email: 'u@x', role: 'user' }, banned: false, pool_ready: true };
      return { user: null, banned: false, pool_ready: true };
    };
    const token = await signHs256({ sub: 'admin-1' }, process.env.JWT_SECRET);
    const req = makeReq(token, 'user-9');
    await authMiddleware(req, makeRes(), () => {});
    assert.equal(req.user.id, 'user-9');
    assert.equal(req.user.role, 'user');
    assert.equal(req.user.impersonated, true);
    assert.equal(req.impersonator.id, 'admin-1');
  });

  it('non-admin sending the header is ignored → req.user stays the real user, no impersonation', async () => {
    edgeClient.resolveIdentity = async ({ userId }) => {
      if (userId === 'user-1') return { user: { id: 'user-1', email: 'u@x', role: 'user' }, banned: false, pool_ready: true };
      return { user: { id: userId, email: 'x', role: 'user' }, banned: false, pool_ready: true };
    };
    const token = await signHs256({ sub: 'user-1' }, process.env.JWT_SECRET);
    const req = makeReq(token, 'user-9');
    await authMiddleware(req, makeRes(), () => {});
    assert.equal(req.user.id, 'user-1');
    assert.equal(!!req.user.impersonated, false);
    assert.equal(req.impersonator, undefined);
  });

  it('admin impersonating another admin is refused (downgrade-only) → req.user stays the real admin', async () => {
    edgeClient.resolveIdentity = async ({ userId }) => {
      if (userId === 'admin-1') return { user: { id: 'admin-1', email: 'a@x', role: 'admin' }, banned: false, pool_ready: true };
      if (userId === 'admin-2') return { user: { id: 'admin-2', email: 'b@x', role: 'admin' }, banned: false, pool_ready: true };
      return { user: null, banned: false, pool_ready: true };
    };
    const token = await signHs256({ sub: 'admin-1' }, process.env.JWT_SECRET);
    const req = makeReq(token, 'admin-2');
    await authMiddleware(req, makeRes(), () => {});
    assert.equal(req.user.id, 'admin-1');
    assert.equal(!!req.user.impersonated, false);
  });

  it('impersonating a missing/banned target is refused → req.user stays the real admin', async () => {
    edgeClient.resolveIdentity = async ({ userId }) => {
      if (userId === 'admin-1') return { user: { id: 'admin-1', email: 'a@x', role: 'admin' }, banned: false, pool_ready: true };
      if (userId === 'gone') return { user: null, banned: false, pool_ready: true };
      return { user: null, banned: false, pool_ready: true };
    };
    const token = await signHs256({ sub: 'admin-1' }, process.env.JWT_SECRET);
    const req = makeReq(token, 'gone');
    await authMiddleware(req, makeRes(), () => {});
    assert.equal(req.user.id, 'admin-1');
    assert.equal(!!req.user.impersonated, false);
  });

  it('admin impersonating self is ignored (no-op)', async () => {
    edgeClient.resolveIdentity = async ({ userId }) => {
      if (userId === 'admin-1') return { user: { id: 'admin-1', email: 'a@x', role: 'admin' }, banned: false, pool_ready: true };
      return { user: null, banned: false, pool_ready: true };
    };
    const token = await signHs256({ sub: 'admin-1' }, process.env.JWT_SECRET);
    const req = makeReq(token, 'admin-1');
    await authMiddleware(req, makeRes(), () => {});
    assert.equal(req.user.id, 'admin-1');
    assert.equal(!!req.user.impersonated, false);
    assert.equal(req.impersonator, undefined);
  });

  it('impersonating a banned target is refused → req.user stays the real admin', async () => {
    edgeClient.resolveIdentity = async ({ userId }) => {
      if (userId === 'admin-1') return { user: { id: 'admin-1', email: 'a@x', role: 'admin' }, banned: false, pool_ready: true };
      if (userId === 'banned-9') return { user: { id: 'banned-9', email: 'b@x', role: 'user' }, banned: true, pool_ready: true };
      return { user: null, banned: false, pool_ready: true };
    };
    const token = await signHs256({ sub: 'admin-1' }, process.env.JWT_SECRET);
    const req = makeReq(token, 'banned-9');
    await authMiddleware(req, makeRes(), () => {});
    assert.equal(req.user.id, 'admin-1');
    assert.equal(!!req.user.impersonated, false);
    assert.equal(req.impersonator, undefined);
  });

  it('impersonation is refused when the pool is not ready (setup mode) → req.user stays the real admin', async () => {
    edgeClient.resolveIdentity = async ({ userId }) => {
      if (userId === 'admin-1') return { user: { id: 'admin-1', email: 'a@x', role: 'admin' }, banned: false, pool_ready: true };
      if (userId === 'user-9') return { user: { id: 'user-9', email: 'u@x', role: 'user' }, banned: false, pool_ready: false };
      return { user: null, banned: false, pool_ready: true };
    };
    const token = await signHs256({ sub: 'admin-1' }, process.env.JWT_SECRET);
    const req = makeReq(token, 'user-9');
    await authMiddleware(req, makeRes(), () => {});
    assert.equal(req.user.id, 'admin-1');
    assert.equal(!!req.user.impersonated, false);
    assert.equal(req.impersonator, undefined);
  });

  // ── OIDC path impersonation (Fix A) ──────────────────────────────────────

  it('OIDC: admin impersonating a user → req.user is the target, impersonated=true, impersonator is the admin', async () => {
    // resolveIdentity is called twice: first for the OIDC source (admin resolution),
    // then for jwt-bearer source (target resolution inside resolveImpersonation).
    edgeClient.resolveIdentity = async ({ source, claims, userId }) => {
      if (source === 'oidc' && claims?.sub === 'kc-admin-1') {
        return { user: { id: 'admin-1', email: 'a@x', role: 'admin' }, banned: false, pool_ready: true };
      }
      if (source === 'jwt-bearer' && userId === 'user-9') {
        return { user: { id: 'user-9', email: 'u@x', role: 'user' }, banned: false, pool_ready: true };
      }
      return { user: null, banned: false, pool_ready: true };
    };
    const req = makeOidcReq('kc-admin-1', 'user-9');
    await authMiddleware(req, makeRes(), () => {});
    assert.equal(req.user.id, 'user-9');
    assert.equal(req.user.role, 'user');
    assert.equal(req.user.impersonated, true);
    assert.equal(req.impersonator.id, 'admin-1');
  });

  it('OIDC: non-admin sending the header is ignored → req.user stays the real user, no impersonation', async () => {
    edgeClient.resolveIdentity = async ({ source, claims }) => {
      if (source === 'oidc' && claims?.sub === 'kc-user-1') {
        return { user: { id: 'user-1', email: 'u@x', role: 'user' }, banned: false, pool_ready: true };
      }
      return { user: null, banned: false, pool_ready: true };
    };
    const req = makeOidcReq('kc-user-1', 'user-9');
    await authMiddleware(req, makeRes(), () => {});
    assert.equal(req.user.id, 'user-1');
    assert.equal(!!req.user.impersonated, false);
    assert.equal(req.impersonator, undefined);
  });

  it('OIDC: impersonated identity is never cached — only the real admin is stored', async () => {
    let resolveCount = 0;
    edgeClient.resolveIdentity = async ({ source, claims, userId }) => {
      resolveCount += 1;
      if (source === 'oidc' && claims?.sub === 'kc-admin-2') {
        return { user: { id: 'admin-2', email: 'a2@x', role: 'admin' }, banned: false, pool_ready: true };
      }
      if (source === 'jwt-bearer' && userId === 'user-8') {
        return { user: { id: 'user-8', email: 'u8@x', role: 'user' }, banned: false, pool_ready: true };
      }
      return { user: null, banned: false, pool_ready: true };
    };

    // First request — cold cache
    const req1 = makeOidcReq('kc-admin-2', 'user-8');
    await authMiddleware(req1, makeRes(), () => {});
    assert.equal(req1.user.id, 'user-8');
    assert.equal(req1.user.impersonated, true);
    const firstCount = resolveCount;

    // Second request — admin should be served from cache; target still re-resolves
    const req2 = makeOidcReq('kc-admin-2', 'user-8');
    await authMiddleware(req2, makeRes(), () => {});
    assert.equal(req2.user.id, 'user-8');
    assert.equal(req2.user.impersonated, true);
    assert.equal(req2.impersonator.id, 'admin-2');
    // Only the target resolve re-ran (cache hit for admin, so total = firstCount + 1)
    assert.equal(resolveCount, firstCount + 1);
  });
});

/**
 * OIDC identity-cache drift bypass: a warm kc:<sub> cache entry must not mask a
 * Keycloak attribute change (deptid / verified email) for the full TTL, because
 * access-check authorises on those. A drifted claim forces a re-resolve (which
 * re-syncs the DB edge-side) and refreshes the cache; a non-drift or
 * absent/unverified/placeholder claim keeps serving from cache (no stampede).
 */
describe('infra OIDC identity-cache drift bypass', () => {
  let origResolve;
  beforeEach(() => {
    authMiddleware._resetCacheForTests();
    origResolve = edgeClient.resolveIdentity;
  });
  afterEach(() => { edgeClient.resolveIdentity = origResolve; });

  function oidcReq(claims) {
    return {
      headers: {}, path: '/api/schema/user_templates', method: 'GET',
      ip: '127.0.0.1', user: null,
      oidc: { isAuthenticated: () => true, user: claims },
    };
  }

  it('no drift: second request with identical claims is served from cache (single resolve)', async () => {
    let count = 0;
    edgeClient.resolveIdentity = async () => {
      count += 1;
      return { user: { id: 'u-1', email: 'a@corp', role: 'user', deptid: 'eng' }, banned: false, pool_ready: true };
    };
    const claims = { sub: 'kc-1', deptid: 'eng', email: 'a@corp', email_verified: true };
    const r1 = oidcReq(claims); await authMiddleware(r1, {}, () => {});
    const r2 = oidcReq(claims); await authMiddleware(r2, {}, () => {});
    assert.equal(count, 1, 'second request hits cache, no re-resolve');
    assert.equal(r2.user.deptid, 'eng');
  });

  it('deptid drift within TTL: bypasses cache, re-resolves, req.user + cache reflect the fresh deptid', async () => {
    let count = 0;
    edgeClient.resolveIdentity = async ({ claims }) => {
      count += 1;
      // Edge re-syncs and returns the value that matches the presented claim.
      return { user: { id: 'u-1', email: 'a@corp', role: 'user', deptid: claims.deptid }, banned: false, pool_ready: true };
    };
    const r1 = oidcReq({ sub: 'kc-1', deptid: 'eng', email: 'a@corp', email_verified: true });
    await authMiddleware(r1, {}, () => {});
    assert.equal(r1.user.deptid, 'eng');

    // Same sub (warm cache) but the new token carries a changed deptid.
    const r2 = oidcReq({ sub: 'kc-1', deptid: 'ops', email: 'a@corp', email_verified: true });
    await authMiddleware(r2, {}, () => {});
    assert.equal(count, 2, 'drift forced a re-resolve');
    assert.equal(r2.user.deptid, 'ops', 'fresh deptid served');

    // Cache now holds the fresh value: a third identical request re-uses it.
    const r3 = oidcReq({ sub: 'kc-1', deptid: 'ops', email: 'a@corp', email_verified: true });
    await authMiddleware(r3, {}, () => {});
    assert.equal(count, 2, 'no further resolve once cache refreshed to fresh deptid');
    assert.equal(r3.user.deptid, 'ops');
  });

  it('verified email change within TTL: bypasses cache and re-resolves', async () => {
    let count = 0;
    edgeClient.resolveIdentity = async ({ claims }) => {
      count += 1;
      return { user: { id: 'u-1', email: claims.email, role: 'user', deptid: 'eng' }, banned: false, pool_ready: true };
    };
    await authMiddleware(oidcReq({ sub: 'kc-1', deptid: 'eng', email: 'old@corp', email_verified: true }), {}, () => {});
    const r2 = oidcReq({ sub: 'kc-1', deptid: 'eng', email: 'new@corp', email_verified: true });
    await authMiddleware(r2, {}, () => {});
    assert.equal(count, 2);
    assert.equal(r2.user.email, 'new@corp');
  });

  it('unverified email change is NOT drift: keeps serving from cache (no stampede)', async () => {
    let count = 0;
    edgeClient.resolveIdentity = async () => {
      count += 1;
      return { user: { id: 'u-1', email: 'a@corp', role: 'user', deptid: 'eng' }, banned: false, pool_ready: true };
    };
    await authMiddleware(oidcReq({ sub: 'kc-1', deptid: 'eng', email: 'a@corp', email_verified: true }), {}, () => {});
    // A later token asserts a different email but WITHOUT verification — ignored.
    await authMiddleware(oidcReq({ sub: 'kc-1', deptid: 'eng', email: 'spoof@corp', email_verified: false }), {}, () => {});
    assert.equal(count, 1, 'unverified email must not force a re-resolve');
  });

  it('absent deptid + placeholder email (token omits scopes) is NOT drift: cache still served', async () => {
    let count = 0;
    edgeClient.resolveIdentity = async () => {
      count += 1;
      return { user: { id: 'u-1', email: 'real@corp', role: 'user', deptid: 'eng' }, banned: false, pool_ready: true };
    };
    // First login carries full claims → cache holds real@corp / eng.
    await authMiddleware(oidcReq({ sub: 'kc-1', deptid: 'eng', email: 'real@corp', email_verified: true }), {}, () => {});
    // Next token omits email + deptid scopes: mapper yields deptid=null and the
    // `kc-1@keycloak` placeholder. Neither counts as drift → served from cache.
    await authMiddleware(oidcReq({ sub: 'kc-1' }), {}, () => {});
    await authMiddleware(oidcReq({ sub: 'kc-1' }), {}, () => {});
    assert.equal(count, 1, 'absent/placeholder claims must not force re-resolves');
  });

  // Composed-loop regression: an email-collision skip on the edge (email column
  // not written) used to leave the cache holding the OLD stored email while the
  // token kept presenting the NEW colliding one — drift fired on every request,
  // permanently bypassing the cache. The sibling marker email_resync_skipped_for
  // rides back on the entry and quiets drift for that exact value only.
  it('collision-skip marker: repeated request with the SAME still-colliding email is served from cache (no re-resolve)', async () => {
    let count = 0;
    edgeClient.resolveIdentity = async () => {
      count += 1;
      // Edge skipped the email re-sync (address taken by another account): the
      // user keeps the OLD stored email, and the colliding value returns as the
      // sibling marker.
      return {
        user: { id: 'u-1', email: 'old@corp', role: 'user', deptid: 'eng' },
        email_resync_skipped_for: 'taken@corp',
        banned: false, pool_ready: true,
      };
    };
    const claims = { sub: 'kc-1', deptid: 'eng', email: 'taken@corp', email_verified: true };
    const r1 = oidcReq(claims); await authMiddleware(r1, {}, () => {});
    const r2 = oidcReq(claims); await authMiddleware(r2, {}, () => {});
    assert.equal(count, 1, 'marked colliding email → drift quiet → second request hits cache');
    // Marker must never leak onto req.user (it lives on the cache entry only).
    assert.equal('emailResyncSkippedFor' in r1.user, false, 'marker absent from req.user');
    assert.equal(r1.user.email, 'old@corp');
  });

  it('collision-skip marker: a DIFFERENT verified email than the marked one still fires drift', async () => {
    let count = 0;
    edgeClient.resolveIdentity = async () => {
      count += 1;
      return {
        user: { id: 'u-1', email: 'old@corp', role: 'user', deptid: 'eng' },
        email_resync_skipped_for: 'taken@corp',
        banned: false, pool_ready: true,
      };
    };
    await authMiddleware(oidcReq({ sub: 'kc-1', deptid: 'eng', email: 'taken@corp', email_verified: true }), {}, () => {});
    // KC email changed again to a new address → no longer matches the marker.
    await authMiddleware(oidcReq({ sub: 'kc-1', deptid: 'eng', email: 'other@corp', email_verified: true }), {}, () => {});
    assert.equal(count, 2, 'email differing from the marked value must bypass the cache');
  });

  it('collision-skip marker: token email reverting to the cached (stored) value is served from cache', async () => {
    let count = 0;
    edgeClient.resolveIdentity = async () => {
      count += 1;
      return {
        user: { id: 'u-1', email: 'old@corp', role: 'user', deptid: 'eng' },
        email_resync_skipped_for: 'taken@corp',
        banned: false, pool_ready: true,
      };
    };
    await authMiddleware(oidcReq({ sub: 'kc-1', deptid: 'eng', email: 'taken@corp', email_verified: true }), {}, () => {});
    // Collision resolved by a KC revert: the token now presents the address that
    // is already stored → matches cached.email → quiet regardless of the marker.
    await authMiddleware(oidcReq({ sub: 'kc-1', deptid: 'eng', email: 'old@corp', email_verified: true }), {}, () => {});
    assert.equal(count, 1, 'email matching cached value is not drift');
  });

  it('legacy edge without the sibling marker keeps original drift behaviour', async () => {
    let count = 0;
    edgeClient.resolveIdentity = async () => {
      count += 1;
      // Old edge pod (rolling deploy): no email_resync_skipped_for field at all.
      return { user: { id: 'u-1', email: 'old@corp', role: 'user', deptid: 'eng' }, banned: false, pool_ready: true };
    };
    await authMiddleware(oidcReq({ sub: 'kc-1', deptid: 'eng', email: 'taken@corp', email_verified: true }), {}, () => {});
    await authMiddleware(oidcReq({ sub: 'kc-1', deptid: 'eng', email: 'taken@corp', email_verified: true }), {}, () => {});
    assert.equal(count, 2, 'undefined marker → unchanged pre-existing drift (re-resolve every request)');
  });
});
