/**
 * index-frontend.js unit tests (v3.2.14).
 *
 * Spins up the Express app on an ephemeral port, exercises GET /health
 * and GET /config.js, and validates the XSS-safe script injection.
 */
const { describe, it, after, beforeEach, afterEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');

// Snapshot env and reset between tests so each spec boots with a clean slate.
const originalEnv = { ...process.env };

function resetEnv() {
  for (const k of ['API_ROLE', 'PORT', 'API_BASE', 'NODE_ENV', 'TRUST_PROXY', 'ZONE_ENV']) {
    delete process.env[k];
  }
  Object.assign(process.env, originalEnv);
  delete process.env.API_BASE;
  delete process.env.PORT;
  delete process.env.ZONE_ENV;
}

function get(port, path_, headers = {}) {
  return new Promise((resolve, reject) => {
    const req = http.get(
      { host: '127.0.0.1', port, path: path_, headers },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () =>
          resolve({
            status: res.statusCode,
            headers: res.headers,
            body: Buffer.concat(chunks).toString('utf-8'),
          }),
        );
      },
    );
    req.on('error', reject);
  });
}

async function boot({ apiBase, nodeEnv = 'production', zoneEnv } = {}) {
  resetEnv();
  process.env.API_ROLE = 'frontend';
  process.env.PORT = '0'; // let the OS pick an ephemeral port
  // Default to production so byte-exact body assertions stay deterministic.
  // v3.2.28 appends a localStorage override snippet in non-prod, so dev-mode
  // tests opt in via { nodeEnv: 'development' }.
  process.env.NODE_ENV = nodeEnv;
  if (apiBase !== undefined) process.env.API_BASE = apiBase;
  if (zoneEnv !== undefined) process.env.ZONE_ENV = zoneEnv;
  // v3.2.52a CI-hang fix: v3.2.51 PR-3 made printBootBanner call
  // deriveSchemeFromBaseUrl(process.env.BASE_URL) inside the FRONTEND
  // app.listen callback. On developer machines docker-api/.env provides
  // BASE_URL via dotenv.config(); on CI that file is gitignored and
  // absent, so printBootBanner throws inside the listen callback. The
  // uncaught throw leaves the TCP server listening but in a state that
  // hangs `node --test` (pipelines #180/#181 hit the 3600s timeout).
  // Pin a deterministic BASE_URL here so the banner succeeds regardless
  // of the dotenv file's presence.
  if (!process.env.BASE_URL) {
    process.env.BASE_URL = 'https://test.localhost:3200';
  }
  // v3.2.54 PR-2: FRONTEND role now requires FRONTEND_URL for the
  // banner's "external" row, parallel to INFRA's BASE_URL requirement.
  // APP_NAME is also mandatory for every role (product name no longer
  // hardcoded in boot-banner.js). Pin both deterministically so the
  // frontend app.listen callback doesn't throw inside the test harness.
  if (!process.env.FRONTEND_URL) {
    process.env.FRONTEND_URL = 'https://test-fmb-web.localhost';
  }
  if (!process.env.APP_NAME) {
    process.env.APP_NAME = 'Flexible Mold Base';
  }
  // NOTE: index-frontend.js calls app.listen() at require time. Re-require
  // per test to pick up the fresh env.
  delete require.cache[require.resolve('../../src/index-frontend')];

  // Intercept app.listen to capture the server instance.
  const express = require('express');
  const origListen = express.application.listen;
  let captured;
  express.application.listen = function (...args) {
    const server = origListen.apply(this, args);
    captured = server;
    return server;
  };

  require('../../src/index-frontend');

  express.application.listen = origListen;

  // Wait for the server to actually be listening.
  await new Promise((r) => captured.once('listening', r).on('listening', r));
  return captured;
}

describe('index-frontend — /health', () => {
  let server;
  afterEach(() => server?.close());

  it('returns 200 with role:frontend', async () => {
    server = await boot();
    const port = server.address().port;
    const res = await get(port, '/health');
    assert.equal(res.status, 200);
    const body = JSON.parse(res.body);
    assert.equal(body.role, 'frontend');
    assert.equal(body.api, 'ok');
  });
});

describe('index-frontend — /config.js', () => {
  let server;
  afterEach(() => server?.close());

  it('returns window.__API_BASE__ = "" when API_BASE unset', async () => {
    server = await boot();
    const port = server.address().port;
    const res = await get(port, '/config.js');
    assert.equal(res.status, 200);
    assert.match(res.headers['content-type'], /application\/javascript/);
    assert.equal(res.headers['cache-control'], 'no-store');
    assert.equal(res.headers['x-content-type-options'], 'nosniff');
    // v3.2.54 PR-2: APP_NAME is pinned in the test harness so a well-known
    // __APP_NAME__ line accompanies __API_BASE__. The v3.2.50b Q9 UC2 seed
    // path remains unchanged; only the test expectation picks up the new
    // required-env surface.
    assert.match(res.body, /^window\.__API_BASE__ = "";$/m);
    assert.match(res.body, /window\.__APP_NAME__ = "Flexible Mold Base";/);
  });

  it('emits the absolute URL verbatim when API_BASE set', async () => {
    server = await boot({ apiBase: 'https://zonea-fmb-api.localhost' });
    const port = server.address().port;
    const res = await get(port, '/config.js');
    assert.match(
      res.body,
      /window\.__API_BASE__ = "https:\/\/zonea-fmb-api\.localhost";/,
    );
    assert.match(res.body, /window\.__APP_NAME__ = "Flexible Mold Base";/);
  });

  it('escapes </script> to prevent HTML break-out', async () => {
    // Zod validates the scheme prefix (^https?://) at startup but does NOT
    // validate the path. A URL like this would pass config-schema validation,
    // so escapeForInlineScript is the real line of defence against the
    // `</script>` break-out vector.
    server = await boot({ apiBase: 'https://evil.com/</script><script>alert(1)</script>' });
    const port = server.address().port;
    const res = await get(port, '/config.js');
    // The `<` MUST be escaped to `\u003c` so it cannot prematurely close
    // a host page's inline script tag.
    assert.equal(res.body.includes('</script>'), false, '</script> must be escaped');
    assert.match(res.body, /\\u003c/);
  });

  it('escapes U+2028 / U+2029 (JS line terminators)', async () => {
    // These would break a pre-ES2019 JavaScript parser embedded in HTML.
    server = await boot({ apiBase: 'https://example.com/\u2028path' });
    const port = server.address().port;
    const res = await get(port, '/config.js');
    assert.equal(res.body.includes('\u2028'), false);
    assert.match(res.body, /\\u2028/);
  });
});

describe('index-frontend — /config.js host-aware (v3.2.28)', () => {
  let server;
  afterEach(() => server?.close());

  it('Host: localhost:8130 → http://localhost:8143 (allowlist hit)', async () => {
    server = await boot({ apiBase: 'https://prod-fallback.example' });
    const port = server.address().port;
    const res = await get(port, '/config.js', { Host: 'localhost:8130' });
    assert.equal(res.status, 200);
    assert.match(res.body, /window\.__API_BASE__ = "http:\/\/localhost:8143";/);
  });

  it('Host: evil.com → falls back to env API_BASE (closed allowlist)', async () => {
    server = await boot({ apiBase: 'https://prod-fallback.example' });
    const port = server.address().port;
    const res = await get(port, '/config.js', { Host: 'evil.com' });
    assert.equal(res.status, 200);
    assert.match(res.body, /window\.__API_BASE__ = "https:\/\/prod-fallback\.example";/);
  });

  it('dev mode appends localStorage override snippet', async () => {
    server = await boot({ apiBase: 'http://localhost:8143', nodeEnv: 'development' });
    const port = server.address().port;
    const res = await get(port, '/config.js', { Host: 'localhost:8130' });
    assert.equal(res.status, 200);
    assert.match(res.body, /fmb_api_base_override/);
    assert.match(res.body, /window\.__API_BASE__ = "http:\/\/localhost:8143";/);
  });

  it('dev mode override snippet enforces strict allowlist regex (v3.2.31 REV-MED)', async () => {
    server = await boot({ apiBase: 'http://localhost:8143', nodeEnv: 'development' });
    const port = server.address().port;
    const res = await get(port, '/config.js', { Host: 'localhost:8130' });
    assert.equal(res.status, 200);

    // MED fold (review): extract the regex from the served snippet and
    // exercise IT (not a duplicate literal in the test). Catches drift if
    // someone tightens the production regex but forgets the test mirror.
    const regexMatch = res.body.match(/\/\^https\?:\\\/\\\/[^/]+\$\//);
    assert.ok(regexMatch, 'served snippet must include the allowlist regex literal');
    // Reconstruct the actual regex by stripping the surrounding `/` and
    // unescaping the `\\/` (escaped JS string slash → regex slash).
    const regexBody = regexMatch[0].slice(1, -1).replace(/\\\//g, '/');
    const allowRegex = new RegExp(regexBody);

    const accept = ['http://localhost', 'https://api.example', 'https://api.example:443', 'http://10.0.0.1:8080'];
    const reject = [
      'http://attacker/x',                    // path
      'http://attacker?q=1',                  // query
      'http://attacker#frag',                 // fragment
      'http://user:pass@attacker',            // userinfo
      'javascript:alert(1)',                  // alt scheme
      'file:///etc/passwd',                   // alt scheme
      'http://attacker:99999999',             // 8-digit port (>5 digits rejected)
      'ftp://attacker',                       // non-http(s) scheme
    ];
    for (const u of accept) assert.ok(allowRegex.test(u), `should accept ${u}`);
    for (const u of reject) assert.ok(!allowRegex.test(u), `should reject ${u}`);
    // And the served body must include the rejection console.warn so the
    // dev sees rejection instead of a silent fall-through.
    assert.match(res.body, /\[config\.js\] fmb_api_base_override rejected/);
  });

  it('production mode does NOT include the localStorage snippet', async () => {
    server = await boot({ apiBase: 'https://api.example', nodeEnv: 'production' });
    const port = server.address().port;
    const res = await get(port, '/config.js', { Host: 'api.example' });
    assert.equal(res.status, 200);
    assert.equal(res.body.includes('fmb_api_base_override'), false);
  });
});

describe('index-frontend — /config.js ZONE_ENV signal', () => {
  let server;
  afterEach(() => server?.close());

  it('emits window.__ZONE_ENV__ = "test" when ZONE_ENV=test', async () => {
    server = await boot({ apiBase: 'https://zonetest-fmb-api.localhost', zoneEnv: 'test' });
    const port = server.address().port;
    const res = await get(port, '/config.js');
    assert.match(res.body, /window\.__ZONE_ENV__ = "test";/);
  });

  it('coerces unknown ZONE_ENV to "production"', async () => {
    server = await boot({ apiBase: 'https://zonea-fmb-api.localhost', zoneEnv: 'staging' });
    const port = server.address().port;
    const res = await get(port, '/config.js');
    assert.match(res.body, /window\.__ZONE_ENV__ = "production";/);
  });

  it('defaults ZONE_ENV to "production" when unset', async () => {
    server = await boot({ apiBase: 'https://zonea-fmb-api.localhost' });
    const port = server.address().port;
    const res = await get(port, '/config.js');
    assert.match(res.body, /window\.__ZONE_ENV__ = "production";/);
  });

  it('treats mixed-case TEST as test (case-insensitive)', async () => {
    server = await boot({ apiBase: 'https://zonetest-fmb-api.localhost', zoneEnv: 'TEST' });
    const port = server.address().port;
    const res = await get(port, '/config.js');
    assert.match(res.body, /window\.__ZONE_ENV__ = "test";/);
  });
});

describe('index-frontend — CSP directives (eval isolated to /sandbox.html)', () => {
  let server;
  afterEach(() => server?.close());

  // Black-box assertion on the actual mounted Helmet response header. The
  // main app document must NOT allow eval — the transformer sandbox's
  // new Function() runs in the null-origin /sandbox.html iframe instead.
  // Inverts the prior v3.2.86 invariant. See LEARN.md §76.
  it('main document CSP forbids unsafe-eval and blob workers', async () => {
    server = await boot();
    const port = server.address().port;
    const res = await get(port, '/health');
    assert.equal(res.status, 200);
    const csp = res.headers['content-security-policy'];
    assert.ok(csp, 'Content-Security-Policy header must be present');
    assert.match(csp, /script-src[^;]*'self'/, 'script-src must include self');
    assert.doesNotMatch(csp, /script-src[^;]*'unsafe-eval'/, "main-doc script-src must NOT include 'unsafe-eval'");
    assert.doesNotMatch(csp, /worker-src[^;]*blob:/, 'main-doc worker-src must NOT include blob:');
  });

  // The eval relaxation is scoped to /sandbox.html ONLY. The document body is
  // served from a string baked into JS (shared/sandbox-document.cjs), NOT a
  // static asset — so the body assertion below proves the worker bootstrap is
  // actually delivered (the failure mode that broke ONPREM: an HTML sanitiser
  // strips <script> from .html files, leaving an iframe that never posts ready).
  it('/sandbox.html carries the scoped relaxed CSP (unsafe-eval + blob worker, connect-src none)', async () => {
    server = await boot();
    const port = server.address().port;
    const res = await get(port, '/sandbox.html');
    const csp = res.headers['content-security-policy'];
    assert.ok(csp, 'sandbox CSP header must be present');
    assert.match(csp, /script-src[^;]*'unsafe-eval'/, "sandbox script-src must include 'unsafe-eval'");
    assert.match(csp, /worker-src[^;]*blob:/, 'sandbox worker-src must include blob:');
    assert.match(csp, /connect-src 'none'/, 'sandbox must block network egress');
    assert.match(csp, /frame-ancestors 'self'/, 'only the app may frame the sandbox');
  });

  it('/sandbox.html serves the worker bootstrap inline (HTML body, not a stripped shell)', async () => {
    server = await boot();
    const port = server.address().port;
    const res = await get(port, '/sandbox.html');
    assert.equal(res.status, 200);
    assert.match(res.headers['content-type'] || '', /text\/html/);
    assert.match(res.body, /<script>/, 'inline <script> must be present');
    assert.match(res.body, /WORKER_BOOTSTRAP/, 'worker bootstrap must be present');
    assert.match(res.body, /new Function\(/, 'the new Function eval site must be present');
    assert.match(res.body, /__fmbSandbox: 'ready'/, 'the ready handshake must be present');
  });

  // window.open('/sandbox.html') (Sec-Fetch-Dest: document) must be refused so
  // the eval-relaxed CSP never applies to a top-level navigation on the app
  // origin.
  it('/sandbox.html refuses a top-level document navigation (403)', async () => {
    server = await boot();
    const port = server.address().port;
    const res = await get(port, '/sandbox.html', { 'sec-fetch-dest': 'document' });
    assert.equal(res.status, 403);
  });
});

describe('index-frontend — Origin-Agent-Cluster disabled', () => {
  let server;
  afterEach(() => server?.close());

  // The frontend helmet disables origin-keying so no document response
  // requests it. See index-frontend.js for the rationale (browser-sticky
  // warning, no ingress layer, negligible isolation benefit).
  it('does not emit Origin-Agent-Cluster on document responses', async () => {
    server = await boot();
    const port = server.address().port;
    const res = await get(port, '/health');
    assert.equal(res.status, 200);
    assert.equal(
      'origin-agent-cluster' in res.headers,
      false,
      'Origin-Agent-Cluster must not be emitted',
    );
  });
});

describe('index-frontend — SPA fallback', () => {
  let server;
  afterEach(() => server?.close());

  it('returns 404 JSON for /api/* so mis-routed API calls surface clearly', async () => {
    server = await boot();
    const port = server.address().port;
    const res = await get(port, '/api/anything');
    assert.equal(res.status, 404);
    const body = JSON.parse(res.body);
    assert.equal(body.success, false);
    assert.match(body.error, /API not routed/);
  });
});

after(() => {
  // Restore env to the very original state for test-runner cleanliness.
  resetEnv();
});
