/**
 * hierarchy-cascade.test.js — v3.2.89 PR-1b
 *
 * Unit tests for the hierarchy-cascade service. Stub-based (mocks the
 * connection's query method) so we exercise the SQL DELETE order +
 * iterative-BFS descendant compute without booting a real MariaDB.
 *
 * Verifies:
 *   - collectDescendantIds finds all descendants via parent_id walk
 *   - cycle guard: maxDepth limits runaway traversal
 *   - cascadeDeleteNode issues DELETEs in dependency-safe order
 *     (field_options → blueprint_fields → sections → output_order →
 *     variant_overrides → user_templates → hierarchy_nodes)
 *   - previewCascade returns counts without writing
 *   - Empty descendants → no DELETE issued, returns zero counts
 *   - Category-tier orphan fix: user_templates DELETE/COUNT includes the
 *     category_id column (no live probe — the retired generation_id twin
 *     is a dropped legacy column, fmb-1329 T9)
 */
const { describe, it, beforeEach } = require('node:test');
const assert = require('node:assert/strict');

const {
  collectDescendantIds,
  previewCascade,
  cascadeDeleteNode,
} = require('../../src/edge/lib/hierarchy-cascade');

// The portable-insert column cache is module-level and survives across tests in
// the same process. Clear it before each test so probe calls are not swallowed
// by a stale cache hit from a previous test's connection stub.
const { __clearPortableColumnCache } = require('../../src/edge/lib/portable-insert');

const t = (name) => `fmb_${name}`;

function makeConn(opts = {}) {
  const queries = [];
  const tree = opts.tree || {}; // { parentId: [childId, ...] }
  const counts = opts.counts || {};
  const onWrite = opts.onWrite;
  // blueprint_groups and decision_tables are additive engine tables probed via
  // information_schema.TABLES. Default absent so pre-existing tests keep their
  // exact DELETE-order expectations; opt in per-test to exercise the new path.
  // The probe answer is PER TABLE (keyed on the probed physical name) — a
  // blanket yes/no would make one additive table's opt-in silently flip the
  // other's, so a DELETE-order assertion could pass for the wrong reason.
  const presentTables = new Set(opts.presentTables || []);
  if (opts.withGroupsTable === true) presentTables.add('fmb_blueprint_groups');
  return {
    queries,
    query: async (sql, params) => {
      queries.push({ sql, params });
      // tableExistsInCurrentSchema probe: SELECT 1 FROM information_schema.TABLES
      if (/information_schema\.TABLES/i.test(sql)) {
        return presentTables.has(params && params[0]) ? [{ 1: 1 }] : [];
      }
      // SELECT id FROM hierarchy_nodes WHERE parent_id IN (?, ?, ...)
      if (/SELECT id FROM `fmb_hierarchy_nodes`/i.test(sql)) {
        const out = [];
        for (const pid of params) {
          for (const childId of tree[pid] || []) {
            out.push({ id: childId });
          }
        }
        return out;
      }
      // SELECT id, name FROM user_templates ... (impact-preview list query)
      if (/^SELECT id, name FROM `fmb_user_templates`/i.test(sql)) {
        return (opts.templateList || []);
      }
      // SELECT COUNT(*) AS n FROM ...
      if (/^SELECT COUNT\(\*\) AS n/i.test(sql)) {
        // Match by table token in SQL
        const tableMatch = sql.match(/FROM `fmb_(\w+)`/);
        const key = tableMatch ? tableMatch[1] : 'unknown';
        return [{ n: counts[key] ?? 0 }];
      }
      // DELETE FROM ...
      if (/^DELETE FROM/i.test(sql)) {
        if (onWrite) onWrite(sql, params);
        const tableMatch = sql.match(/FROM `fmb_(\w+)`/);
        const key = tableMatch ? tableMatch[1] : 'unknown';
        return { affectedRows: counts[`${key}_deleted`] ?? counts[key] ?? 0 };
      }
      return { affectedRows: 0 };
    },
  };
}

describe('collectDescendantIds — iterative BFS', () => {
  it('returns just the root when no descendants', async () => {
    const conn = makeConn({ tree: {} });
    const ids = await collectDescendantIds(conn, t, 'root-1');
    assert.deepEqual(ids, ['root-1']);
  });

  it('walks 3-level tree', async () => {
    const conn = makeConn({
      tree: {
        'root': ['c1', 'c2'],
        'c1': ['gc1', 'gc2'],
        'c2': ['gc3'],
      },
    });
    const ids = await collectDescendantIds(conn, t, 'root');
    assert.deepEqual(
      ids.sort(),
      ['c1', 'c2', 'gc1', 'gc2', 'gc3', 'root'].sort(),
    );
  });

  it('respects maxDepth as cycle guard', async () => {
    const conn = makeConn({
      tree: {
        'a': ['b'],
        'b': ['a'], // cycle
      },
    });
    const ids = await collectDescendantIds(conn, t, 'a', { maxDepth: 2 });
    // a + b collected; cycle detection via Set prevents infinite re-add
    assert.deepEqual(ids.sort(), ['a', 'b']);
  });
});

describe('previewCascade', () => {
  it('returns counts without issuing DELETEs', async () => {
    __clearPortableColumnCache();
    const conn = makeConn({
      tree: { root: ['c1'] },
      counts: {
        blueprint_fields: 3,
        field_options: 7,
        blueprint_sections: 2,
        blueprint_output_order: 4,
        variant_overrides: 1,
        user_templates: 5,
      },
      templateList: [
        { id: 't1', name: 'a' },
        { id: 't2', name: 'b' },
        { id: 't3', name: 'c' },
        { id: 't4', name: 'd' },
        { id: 't5', name: 'e' },
      ],
    });
    const counts = await previewCascade(conn, t, 'root');
    assert.equal(counts.nodes, 2);
    assert.equal(counts.children, 1);
    assert.equal(counts.blueprint_fields, 3);
    assert.equal(counts.field_options, 7);
    assert.equal(counts.blueprint_sections, 2);
    assert.equal(counts.blueprint_output_order, 4);
    assert.equal(counts.variant_overrides, 1);
    assert.equal(counts.user_templates, 5);
    const writes = conn.queries.filter((q) => /^DELETE/i.test(q.sql));
    assert.equal(writes.length, 0);
  });

  it('counts blueprint_groups when the table exists, zero when it does not', async () => {
    __clearPortableColumnCache();
    const withTable = await previewCascade(
      makeConn({ tree: { root: [] }, withGroupsTable: true, counts: { blueprint_groups: 6 } }),
      t, 'root',
    );
    assert.equal(withTable.blueprint_groups, 6);

    __clearPortableColumnCache();
    const withoutTable = await previewCascade(
      makeConn({ tree: { root: [] }, withGroupsTable: false, counts: { blueprint_groups: 6 } }),
      t, 'root',
    );
    assert.equal(withoutTable.blueprint_groups, 0);
  });

  it('counts decision_tables when the table exists, zero when it does not', async () => {
    __clearPortableColumnCache();
    const withTable = await previewCascade(
      makeConn({
        tree: { root: [] },
        presentTables: ['fmb_decision_tables'],
        counts: { decision_tables: 3 },
      }),
      t, 'root',
    );
    assert.equal(withTable.decision_tables, 3);

    __clearPortableColumnCache();
    const withoutTable = await previewCascade(
      makeConn({ tree: { root: [] }, counts: { decision_tables: 3 } }),
      t, 'root',
    );
    assert.equal(withoutTable.decision_tables, 0);
  });

  it('returns a capped user_template_list plus the true total', async () => {
    __clearPortableColumnCache();
    // 3 affected templates; cap is far higher so all 3 are listed and total=3.
    const conn = makeConn({
      tree: { root: ['c1'] },
      counts: { user_templates: 3 },
      templateList: [
        { id: 'tA', name: 'Alpha' },
        { id: 'tB', name: 'Bravo' },
        { id: 'tC', name: 'Charlie' },
      ],
    });
    const counts = await previewCascade(conn, t, 'root');
    assert.equal(counts.user_templates, 3);
    assert.deepEqual(counts.user_template_list.map((r) => r.name), ['Alpha', 'Bravo', 'Charlie']);
    const writes = conn.queries.filter((q) => /^DELETE/i.test(q.sql));
    assert.equal(writes.length, 0);
  });
});

describe('cascadeDeleteNode', () => {
  it('issues DELETEs in dependency-safe order', async () => {
    __clearPortableColumnCache();
    const writes = [];
    const conn = makeConn({
      tree: { root: ['c1'] },
      counts: {
        blueprint_fields: 3, blueprint_fields_deleted: 3,
        field_options: 7, field_options_deleted: 7,
        blueprint_sections: 2, blueprint_sections_deleted: 2,
        blueprint_output_order: 4, blueprint_output_order_deleted: 4,
        variant_overrides: 1, variant_overrides_deleted: 1,
        user_templates: 5, user_templates_deleted: 5,
        hierarchy_nodes: 2, hierarchy_nodes_deleted: 2,
      },
      onWrite: (sql) => {
        const m = sql.match(/FROM `fmb_(\w+)`/);
        if (m) writes.push(m[1]);
      },
    });
    const applied = await cascadeDeleteNode(conn, t, 'root');
    assert.deepEqual(writes, [
      'field_options',         // 1: chained via blueprint_fields subquery
      'blueprint_fields',      // 2
      'blueprint_sections',    // 3
      'blueprint_output_order',// 4
      'variant_overrides',     // 5
      'user_templates',        // 6
      'hierarchy_nodes',       // 7: leaves last
    ]);
    assert.equal(applied.nodes, 2);
    assert.equal(applied.blueprint_fields, 3);
    assert.equal(applied.field_options, 7);
    assert.equal(applied.blueprint_sections, 2);
    assert.equal(applied.blueprint_output_order, 4);
    assert.equal(applied.variant_overrides, 1);
    assert.equal(applied.user_templates, 5);
  });

  it('deletes blueprint_groups (between sections and output_order) when the table exists', async () => {
    __clearPortableColumnCache();
    const writes = [];
    const conn = makeConn({
      tree: { root: [] },
      withGroupsTable: true,
      counts: {
        blueprint_sections: 2, blueprint_sections_deleted: 2,
        blueprint_groups: 4, blueprint_groups_deleted: 4,
        blueprint_output_order: 1, blueprint_output_order_deleted: 1,
        hierarchy_nodes: 1, hierarchy_nodes_deleted: 1,
      },
      onWrite: (sql) => {
        const m = sql.match(/FROM `fmb_(\w+)`/);
        if (m) writes.push(m[1]);
      },
    });
    const applied = await cascadeDeleteNode(conn, t, 'root');
    assert.deepEqual(writes, [
      'field_options',
      'blueprint_fields',
      'blueprint_sections',
      'blueprint_groups',       // new: additive engine table, no longer orphaned
      'blueprint_output_order',
      'variant_overrides',
      'user_templates',
      'hierarchy_nodes',
    ]);
    assert.equal(applied.blueprint_groups, 4);
  });

  it('skips the blueprint_groups DELETE on a pre-migration target lacking the table', async () => {
    __clearPortableColumnCache();
    const writes = [];
    const conn = makeConn({
      tree: { root: [] },
      withGroupsTable: false,
      counts: { hierarchy_nodes: 1, hierarchy_nodes_deleted: 1 },
      onWrite: (sql) => {
        const m = sql.match(/FROM `fmb_(\w+)`/);
        if (m) writes.push(m[1]);
      },
    });
    const applied = await cascadeDeleteNode(conn, t, 'root');
    assert.ok(!writes.includes('blueprint_groups'), 'must not DELETE a table that does not exist');
    assert.equal(applied.blueprint_groups, 0);
  });

  it('deletes decision_tables (between overrides and templates) when the table exists', async () => {
    __clearPortableColumnCache();
    const writes = [];
    const conn = makeConn({
      tree: { root: [] },
      presentTables: ['fmb_decision_tables'],
      counts: {
        variant_overrides: 1, variant_overrides_deleted: 1,
        decision_tables: 2, decision_tables_deleted: 2,
        user_templates: 1, user_templates_deleted: 1,
        hierarchy_nodes: 1, hierarchy_nodes_deleted: 1,
      },
      onWrite: (sql) => {
        const m = sql.match(/FROM `fmb_(\w+)`/);
        if (m) writes.push(m[1]);
      },
    });
    const applied = await cascadeDeleteNode(conn, t, 'root');
    assert.deepEqual(writes, [
      'field_options',
      'blueprint_fields',
      'blueprint_sections',
      // blueprint_groups absent on this target — its own probe, not this one.
      'blueprint_output_order',
      'variant_overrides',
      'decision_tables',
      'user_templates',
      'hierarchy_nodes',
    ]);
    assert.equal(applied.decision_tables, 2);
  });

  it('skips the decision_tables DELETE on a pre-migration target lacking the table', async () => {
    __clearPortableColumnCache();
    const writes = [];
    const conn = makeConn({
      tree: { root: [] },
      counts: { hierarchy_nodes: 1, hierarchy_nodes_deleted: 1 },
      onWrite: (sql) => {
        const m = sql.match(/FROM `fmb_(\w+)`/);
        if (m) writes.push(m[1]);
      },
    });
    const applied = await cascadeDeleteNode(conn, t, 'root');
    assert.ok(!writes.includes('decision_tables'), 'must not DELETE a table that does not exist');
    assert.equal(applied.decision_tables, 0);
  });

  it('returns zero counts when no descendants found', async () => {
    // Connection always returns empty descendant list — simulates a node id
    // that doesn't exist OR has no parent_id row.
    const conn = {
      queries: [],
      query: async (sql, params) => {
        conn.queries.push({ sql, params });
        if (/SELECT id FROM `fmb_hierarchy_nodes`/i.test(sql)) return [];
        return { affectedRows: 0 };
      },
    };
    // collectDescendantIds always seeds the root, so to test "no descendants
    // OR root" we override behavior — but the helper always returns at least
    // [rootId]. The "missing node" case is detected by the route handler via
    // affectedRows on hierarchy_nodes DELETE = 0, NOT by descendant count.
    // Verify that when DELETE returns 0 affectedRows, applied.nodes is 0.
    conn.query = async (sql, params) => {
      conn.queries.push({ sql, params });
      if (/SELECT id FROM `fmb_hierarchy_nodes`/i.test(sql)) {
        return params[0] === 'root' ? [] : [];
      }
      if (/^DELETE/i.test(sql)) return { affectedRows: 0 };
      return { affectedRows: 0 };
    };
    const applied = await cascadeDeleteNode(conn, t, 'missing-id');
    assert.equal(applied.nodes, 0);
  });

  it('user_templates DELETE includes category_id IN, never generation_id (fmb-1329 T9: probe retired, column dropped)', async () => {
    // A Category-tier node has blueprint_id = NULL on its templates; only the
    // top-tier FK (category_id) points at the deleted node. The sweep MUST
    // match that column or the templates become orphans. generation_id is a
    // dropped legacy column (spec §4.6) — templateMatch() no longer probes
    // for it (or issues any information_schema.COLUMNS query at all).
    let capturedSql = null;
    let capturedParams = null;
    const conn = makeConn({
      tree: { 'cat-1': [] },
      counts: {
        user_templates: 2, user_templates_deleted: 2,
        hierarchy_nodes: 1, hierarchy_nodes_deleted: 1,
      },
      onWrite: (sql, params) => {
        if (/FROM `fmb_user_templates`/i.test(sql)) {
          capturedSql = sql;
          capturedParams = params;
        }
      },
    });
    await cascadeDeleteNode(conn, t, 'cat-1');

    // The DELETE SQL must contain all three match branches so a top-tier-only
    // template (blueprint_id NULL, category_id set) is caught.
    assert.ok(
      capturedSql !== null,
      'user_templates DELETE was never issued',
    );
    assert.ok(
      /category_id IN/i.test(capturedSql),
      `Expected "category_id IN" in user_templates DELETE but got:\n${capturedSql}`,
    );
    assert.ok(
      !/generation_id IN/i.test(capturedSql),
      `Expected NO "generation_id IN" (dropped column) but got:\n${capturedSql}`,
    );
    assert.ok(
      /blueprint_id IN/i.test(capturedSql),
      `Expected "blueprint_id IN" in user_templates DELETE but got:\n${capturedSql}`,
    );
    assert.ok(
      /variant_id IN/i.test(capturedSql),
      `Expected "variant_id IN" in user_templates DELETE but got:\n${capturedSql}`,
    );

    // Bound params must line up with the placeholders on this destructive path:
    // 3 IN-clauses (blueprint_id, variant_id, category_id) × the single
    // descendant id ('cat-1') = 3 params. A wrong push count would delete the
    // wrong rows or throw.
    assert.equal(
      capturedParams.length, 3,
      `Expected 3 bound params (3 clauses × 1 id) but got ${capturedParams.length}`,
    );

    // No column probe: category_id is a base, non-additive column, so
    // templateMatch() builds the WHERE clause with zero DB round-trips.
    const probeQuery = conn.queries.find((q) =>
      /information_schema\.COLUMNS/i.test(q.sql),
    );
    assert.equal(
      probeQuery, undefined,
      'Expected NO information_schema.COLUMNS probe (probe retired with generation_id)',
    );
  });
});
