/**
 * flow-run-wiring.test.js — Task 6 wiring assertions.
 *
 * Covers three integration points for POST /api/flow-recipes/:id/run:
 *   (a) flowRecipeLimiterKind classifies /run as 'dispatch' budget
 *   (b) remote-client has 20 s timeout entries for run-begin + run-finalize
 *   (c) forwarding.js calls mountFlowRecipeRun BEFORE the blanket /api/flow-recipes proxy
 */
const { test } = require('node:test');
const assert = require('node:assert');

// ── (a) Limiter classification ───────────────────────────────────────────────
// flowRecipeLimiterKind is the pure function that flowGate delegates to.
// Testing it directly avoids needing an HTTP harness.
const { flowRecipeLimiterKind } = require('../../src/infra/limiters');

test('flowGate: POST /<id>/run routes to dispatch budget', () => {
  assert.strictEqual(flowRecipeLimiterKind('POST', '/r1/run'), 'dispatch');
  assert.strictEqual(flowRecipeLimiterKind('POST', '/r1/run/'), 'dispatch'); // trailing-slash guard
});

test('flowGate: POST /<uuid>/run (real UUID) routes to dispatch budget', () => {
  const uuid = 'a1b2c3d4-e5f6-7890-abcd-ef1234567890';
  assert.strictEqual(flowRecipeLimiterKind('POST', `/${uuid}/run`), 'dispatch');
});

test('flowGate: POST /run with nothing before it is still dispatch (regex anchored to end)', () => {
  // Edge case: bare /run path segment at root — not a realistic URL on this mount
  // but the regex must not accidentally double-match. Since /\/run\/?$/ does match,
  // this is expected to return 'dispatch' (the run budget is per-user anyway).
  assert.strictEqual(flowRecipeLimiterKind('POST', '/run'), 'dispatch');
});

test('flowGate: POST /run regression — existing /dispatch still classified dispatch', () => {
  assert.strictEqual(flowRecipeLimiterKind('POST', '/s1/dispatch'), 'dispatch');
  assert.strictEqual(flowRecipeLimiterKind('POST', '/s1/dispatch/'), 'dispatch');
});

test('flowGate: POST / (create recipe) is still write, not dispatch', () => {
  assert.strictEqual(flowRecipeLimiterKind('POST', '/'), 'write');
});

test('flowGate: GET /r1 is still unlimited (null)', () => {
  assert.strictEqual(flowRecipeLimiterKind('GET', '/r1'), null);
});

// ── (b) S2S timeout overrides ────────────────────────────────────────────────
// _getTimeoutForPath is exposed as a test helper from remote-client.js.
// Load the REAL module here so assertions hit the actual TIMEOUT_OVERRIDES array.
const { _getTimeoutForPath } = require('../../src/infra/lib/remote-client');

test('S2S timeout: /edge/internal/flow-recipes/run-begin is 20_000 ms', () => {
  assert.strictEqual(_getTimeoutForPath('/edge/internal/flow-recipes/run-begin'), 20_000);
});

test('S2S timeout: /edge/internal/flow-recipes/run-finalize is 20_000 ms', () => {
  assert.strictEqual(_getTimeoutForPath('/edge/internal/flow-recipes/run-finalize'), 20_000);
});

test('S2S timeout: /edge/internal paths do NOT match /edge/app/flow-recipes override', () => {
  // Validate that the internal entries are genuinely needed:
  // /edge/internal/flow-recipes/... does NOT start with /edge/app/flow-recipes,
  // so without their own entries they would fall through to DEFAULT_TIMEOUT_MS (10s).
  // The test above already proves they get 20_000 ms — this test just documents
  // why the entries exist rather than relying on the /edge/app/flow-recipes blanket.
  assert.ok(
    !'/edge/internal/flow-recipes/run-begin'.startsWith('/edge/app/flow-recipes'),
    '/edge/internal does NOT share the /edge/app prefix',
  );
  // Existing /edge/app/flow-recipes override is unaffected.
  assert.strictEqual(_getTimeoutForPath('/edge/app/flow-recipes'), 20_000);
  // Unknown path still uses the default.
  assert.strictEqual(_getTimeoutForPath('/edge/platform/users'), 10_000);
});

// ── (c) Mount order: mountFlowRecipeRun before blanket /api/flow-recipes proxy ─
// Stub all forwarding.js dependencies before loading the module so we can
// capture the call sequence without a real HTTP server.

const mountCallSeq = [];
let runHandlerMounted = false;

require.cache[require.resolve('../../src/infra/lib/remote-client')] = {
  exports: {
    createForwardingProxy: (target) => {
      const fn = (_req, _res, next) => next && next();
      fn._target = target;
      return fn;
    },
    createRawBodyForwardingProxy: () => (_q, _s, n) => n && n(),
    forwardToEdge: async () => ({ status: 200, data: {} }),
    passthroughResponse: () => {},
  },
};
require.cache[require.resolve('../../src/infra/routes/connector-fetch')] = { exports: () => {} };
require.cache[require.resolve('../../src/infra/routes/flow-step-dispatch')] = {
  exports: () => {},
};
require.cache[require.resolve('../../src/infra/routes/flow-recipe-run')] = {
  exports: (_app) => {
    mountCallSeq.push('mountFlowRecipeRun');
    runHandlerMounted = true;
  },
};
// Clear any previously cached forwarding.js so our stubs take effect.
delete require.cache[require.resolve('../../src/infra/forwarding')];
const forwarding = require('../../src/infra/forwarding');

test('forwarding: mountFlowRecipeRun is called', () => {
  const app = {
    use: (path, _mw) => {
      if (path === '/api/flow-recipes') mountCallSeq.push('blanket-proxy');
    },
    post: () => {},
    get: () => {},
  };

  forwarding.mountRemainingRoutes(app);

  assert.strictEqual(runHandlerMounted, true, 'mountFlowRecipeRun should have been called');
});

test('forwarding: mountFlowRecipeRun appears BEFORE blanket /api/flow-recipes proxy in call sequence', () => {
  const runIdx = mountCallSeq.indexOf('mountFlowRecipeRun');
  const proxyIdx = mountCallSeq.indexOf('blanket-proxy');

  assert.ok(runIdx !== -1, 'mountFlowRecipeRun should be in the call sequence');
  assert.ok(proxyIdx !== -1, 'blanket /api/flow-recipes proxy should be in the call sequence');
  assert.ok(
    runIdx < proxyIdx,
    `mountFlowRecipeRun (seq ${runIdx}) must precede blanket proxy (seq ${proxyIdx}) so the specific POST handler wins route matching`,
  );
});
