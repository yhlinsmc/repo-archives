/**
 * flow-recipes-approval.test.js — the admin approval lifecycle for flow recipes.
 *
 * Mirrors api-connectors-approval.test.js harness. Uses a minimal express router
 * (no CRUD factory) with stub POST/PUT routes so the test only exercises the
 * approval middleware and the PATCH approve/reject routes.
 *
 * Cases:
 *   (a) editor POST → status pending
 *   (b) admin POST → approved + approved_by/at stamped
 *   (c) PATCH /:id/approve editor→403, admin→200 status approved
 *   (d) PATCH /:id/reject no note→400, with note→status rejected
 *   (e) PUT changing payload_transform_code on approved recipe → re-pends
 *   (f) PUT changing only name/description → stays approved (no re-pend)
 *   (g) PUT changing link_extract JSON → re-pends
 *   (h) approval columns absent (errno 1054) → approve→409 APPROVAL_UNAVAILABLE;
 *       write middleware re-pend probe failure → next() called (request proceeds)
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

// Mock the DB module via require.cache BEFORE requiring the approval module so
// the approval module's top-level `require('../../../db')` resolves to the mock.
const dbKey = require.resolve('../../src/edge/db');
let existingRow; let updated; let audited; let simulateNoRunsOnColumn;
const conn = {
  async query(sql, params) {
    // Simulate a no-ALTER DB missing ONLY runs_on: the full projection 1054s, the
    // legacy projection (no runs_on) succeeds.
    if (simulateNoRunsOnColumn && /runs_on/.test(sql) && /FROM `fmb_flow_recipes`/.test(sql)) {
      const e = new Error('Unknown column'); e.errno = 1054; e.code = 'ER_BAD_FIELD_ERROR'; throw e;
    }
    if (/SELECT status, payload_transform_code, content_type,.*FROM `fmb_flow_recipes`/.test(sql)) {
      return existingRow ? [existingRow] : [];
    }
    if (/UPDATE `fmb_flow_recipes`/.test(sql)) {
      updated.push({ sql, params });
      return { affectedRows: existingRow ? 1 : 0 };
    }
    if (/INSERT INTO `fmb_feature_audit`/.test(sql)) {
      audited.push({ event: params[1], meta: JSON.parse(params[3]) });
      return { affectedRows: 1 };
    }
    return [];
  },
  release() {},
};
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: {
    pool: {
      ro: { query: (sql, params) => conn.query(sql, params) },
      rw: { getConnection: async () => conn },
    },
    t: (n) => `fmb_${n}`,
  },
};

const registerApproval = require('../../src/edge/routes/app/flow-recipes/approval');

let role; let server; let baseUrl;
before(async () => {
  const app = express(); app.use(express.json());
  app.use((req, _res, next) => { req.user = { id: 'u-admin', role }; next(); });

  // Mount approval routes (middleware + PATCH approve/reject) on a minimal router.
  // Stub POST/PUT routes capture whatever the approval middleware stamped into req.body.
  const router = express.Router();
  registerApproval(router);
  router.post('/', (req, res) => res.json({ ok: true, body: req.body }));
  router.put('/:id', (req, res) => res.json({ ok: true, body: req.body }));
  app.use('/r', router);

  server = http.createServer(app);
  await new Promise((resolve) => server.listen(0, resolve));
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});
after(() => server && server.close());
beforeEach(() => {
  existingRow = null; updated = []; audited = []; role = 'admin'; simulateNoRunsOnColumn = false;
});

const req = (method, path, body) =>
  fetch(`${baseUrl}${path}`, {
    method,
    headers: { 'content-type': 'application/json' },
    body: body ? JSON.stringify(body) : undefined,
  }).then(async (r) => ({ status: r.status, json: await r.json().catch(() => ({})) }));

// Valid-UUID fixtures for the PATCH routes (UUID guard rejects malformed ids before DB).
const RID = '11111111-1111-4111-8111-111111111111';
const MISSING_ID = '22222222-2222-4222-8222-222222222222';

describe('status stamping on create (POST)', () => {
  it('(a) editor POST → status pending', async () => {
    role = 'editor';
    const r = await req('POST', '/r', { name: 'recipe-1', content_type: 'application/json' });
    assert.equal(r.status, 200);
    assert.equal(r.json.body.status, 'pending');
    // approved_by must not be present (editor creates pending, no approver)
    assert.equal(Object.prototype.hasOwnProperty.call(r.json.body, 'approved_by'), false);
  });

  it('(b) admin POST → approved + approved_by/at stamped', async () => {
    role = 'admin';
    const r = await req('POST', '/r', { name: 'recipe-2', content_type: 'application/json' });
    assert.equal(r.status, 200);
    assert.equal(r.json.body.status, 'approved');
    assert.equal(r.json.body.approved_by, 'u-admin');
    assert.ok(r.json.body.approved_at, 'approved_at should be set');
  });

  it('client-supplied status is stripped (editor cannot self-approve)', async () => {
    role = 'editor';
    const r = await req('POST', '/r', { name: 'recipe-3', status: 'approved', approved_by: 'u-admin' });
    assert.equal(r.status, 200);
    assert.equal(r.json.body.status, 'pending');
    // The client-injected approved_by must have been stripped before middleware stamped status
    assert.equal(r.json.body.approved_by, undefined);
  });
});

describe('payload_transform_code length guard', () => {
  const tooBig = 'x'.repeat(32 * 1024 + 1);
  const atLimit = 'x'.repeat(32 * 1024);

  it('POST with oversized code → 400 CODE_TOO_LARGE', async () => {
    role = 'editor';
    const r = await req('POST', '/r', { name: 'big', payload_transform_code: tooBig });
    assert.equal(r.status, 400);
    assert.equal(r.json.error?.code ?? r.json.code, 'CODE_TOO_LARGE');
  });

  it('PUT with oversized code → 400 (rejected before re-pend probe)', async () => {
    existingRow = { id: 'r1', status: 'approved', payload_transform_code: 'CODE-1' };
    const r = await req('PUT', '/r/r1', { payload_transform_code: tooBig });
    assert.equal(r.status, 400);
    assert.equal(r.json.error?.code ?? r.json.code, 'CODE_TOO_LARGE');
  });

  it('non-string code (object) → 400 CODE_INVALID (cannot slip past the byte check)', async () => {
    role = 'editor';
    const r = await req('POST', '/r', { name: 'obj', payload_transform_code: { a: 'x'.repeat(40000) } });
    assert.equal(r.status, 400);
    assert.equal(r.json.error?.code ?? r.json.code, 'CODE_INVALID');
  });

  it('code exactly at the limit is accepted', async () => {
    role = 'editor';
    const r = await req('POST', '/r', { name: 'edge', payload_transform_code: atLimit });
    assert.equal(r.status, 200);
    assert.equal(r.json.body.status, 'pending');
  });
});

// THE RE-PEND IS NO LONGER A MIDDLEWARE, so these cases can no longer be
// expressed by mounting the middleware over a stub PUT: the probe runs inside
// the CRUD factory's write transaction with the row locked, and the verdict is
// folded into the same UPDATE. Which is the point — the middleware read the row
// on `pool.ro` while the approve/reject PATCHes wrote `pool.rw`, with nothing
// holding it in between.
//
// The behaviour they asserted is now covered where it can be asserted on the
// STORED row, and the pointer is to the case that actually drives this mount's
// PUT: `tests/integration/connector-credentials-real-db.test.js`, "the recipe
// mount re-pends on the columns it declares, through its own route". That
// describe drives `PUT /edge/app/flow-recipes/:id` once per watched column and
// reads back `status` + the cleared approval bookkeeping, so a typo in this
// mount's `columns` / `jsonColumns` / `statusCol` wiring fails there.
//
// What stays HERE is the half that is a pure decision — the policy every reader
// of the column shares — and the mount's declaration of which columns it
// watches. Neither half substitutes for the other: this file cannot see the
// wiring, and the route-level file cannot state the policy about a status no
// fixture happens to hold.
describe('what a status means, and which columns re-pend a recipe', () => {
  const { repandRequired, dispatchAllowed, reviewRecorded } = require('../../src/edge/lib/review-status');
  const { SENSITIVE_SCALAR, JSON_SENSITIVE } = require('../../src/edge/routes/app/flow-recipes/approval');

  it('a grandfathered row dispatches, so a sensitive change to it must re-pend', () => {
    // The row this pair exists for. NULL is read as APPROVED by the dispatch
    // gate; the re-pend used to read the same NULL as "nothing to re-pend", and
    // between the two readings a recipe kept running edits nobody reviewed.
    assert.equal(dispatchAllowed(null), true);
    assert.equal(repandRequired(null, true), true);
    assert.equal(repandRequired(null, false), false);
  });

  it('an approved row re-pends on a sensitive change and not otherwise', () => {
    assert.equal(repandRequired('approved', true), true);
    assert.equal(repandRequired('approved', false), false);
  });

  it('a rejected row re-pends on any edit — that is the resubmit path', () => {
    assert.equal(repandRequired('rejected', false), true);
  });

  it('a pending row is already pending and is left alone', () => {
    assert.equal(repandRequired('pending', true), false);
    assert.equal(dispatchAllowed('pending'), false);
    assert.equal(reviewRecorded('pending'), false);
  });

  it('the recipe mount watches exactly the columns this file documents', () => {
    // A list read by the mount rather than restated there, pinned so a column
    // dropping off it is a failure rather than a quietly narrower review gate.
    assert.deepEqual(
      [...SENSITIVE_SCALAR],
      ['payload_transform_code', 'content_type', 'runs_on'],
    );
    assert.deepEqual(
      [...JSON_SENSITIVE],
      ['consumed_output_keys', 'link_extract', 'external_id_extract'],
    );
  });
});

describe('(c) PATCH /:id/approve', () => {
  it('editor → 403', async () => {
    role = 'editor'; existingRow = { id: RID };
    const r = await req('PATCH', `/r/${RID}/approve`);
    assert.equal(r.status, 403);
  });

  it('admin → 200 status approved + audit event', async () => {
    existingRow = { id: RID };
    const r = await req('PATCH', `/r/${RID}/approve`);
    assert.equal(r.status, 200);
    assert.equal(updated.some((u) => /status='approved'/.test(u.sql)), true);
    assert.deepEqual(audited.map((a) => a.event), ['flow_recipe.approval.granted']);
  });

  it('malformed id → 400 (before any DB access)', async () => {
    existingRow = { id: RID };
    const r = await req('PATCH', '/r/not-a-uuid/approve');
    assert.equal(r.status, 400);
    assert.equal(r.json.error.code, 'BAD_REQUEST');
    assert.equal(updated.length, 0);
  });

  it('missing recipe → 404', async () => {
    existingRow = null;
    const r = await req('PATCH', `/r/${MISSING_ID}/approve`);
    assert.equal(r.status, 404);
  });

  it('(h) no approval columns (no-ALTER DB) → 409 APPROVAL_UNAVAILABLE', async () => {
    existingRow = { id: RID };
    // Override conn.query to throw ER_BAD_FIELD_ERROR on the UPDATE.
    const origQuery = conn.query.bind(conn);
    conn.query = async (sql, params) => {
      if (/UPDATE `fmb_flow_recipes`/.test(sql)) {
        const e = new Error("Unknown column 'status'");
        e.code = 'ER_BAD_FIELD_ERROR'; e.errno = 1054; throw e;
      }
      return origQuery(sql, params);
    };
    try {
      const r = await req('PATCH', `/r/${RID}/approve`);
      assert.equal(r.status, 409);
      assert.equal(r.json.error.code, 'APPROVAL_UNAVAILABLE');
    } finally { conn.query = origQuery; }
  });
});

describe('(d) PATCH /:id/reject', () => {
  it('admin without a note → 400', async () => {
    existingRow = { id: RID };
    const r = await req('PATCH', `/r/${RID}/reject`, {});
    assert.equal(r.status, 400);
  });

  it('admin with a note → rejected + audit event', async () => {
    existingRow = { id: RID };
    const r = await req('PATCH', `/r/${RID}/reject`, { review_note: 'unsafe link extractor' });
    assert.equal(r.status, 200);
    assert.equal(
      updated.some((u) => /status='rejected'/.test(u.sql) && u.params.includes('unsafe link extractor')),
      true,
    );
    assert.deepEqual(audited.map((a) => a.event), ['flow_recipe.approval.rejected']);
  });

  it('editor → 403', async () => {
    role = 'editor'; existingRow = { id: RID };
    const r = await req('PATCH', `/r/${RID}/reject`, { review_note: 'denied' });
    assert.equal(r.status, 403);
  });

  it('malformed id → 400', async () => {
    existingRow = { id: RID };
    const r = await req('PATCH', '/r/not-a-uuid/reject', { review_note: 'x' });
    assert.equal(r.status, 400);
    assert.equal(r.json.error.code, 'BAD_REQUEST');
    assert.equal(updated.length, 0);
  });

  it('missing recipe → 404', async () => {
    existingRow = null;
    const r = await req('PATCH', `/r/${MISSING_ID}/reject`, { review_note: 'no match' });
    assert.equal(r.status, 404);
  });
});

describe('(h) write-middleware: errno-1054 re-pend probe failure → request proceeds', () => {
  it('PUT re-pend probe throws ER_BAD_FIELD_ERROR → next() called, route responds 200', async () => {
    existingRow = { id: 'r2', status: 'approved' };
    // Override the ro.query to throw ER_BAD_FIELD_ERROR (no approval columns on this DB).
    const origRoQuery = require.cache[dbKey].exports.pool.ro.query;
    require.cache[dbKey].exports.pool.ro.query = async (sql) => {
      if (/SELECT status.*FROM `fmb_flow_recipes`/.test(sql)) {
        const e = new Error("Unknown column 'status'");
        e.code = 'ER_BAD_FIELD_ERROR'; e.errno = 1054; throw e;
      }
      return [];
    };
    try {
      const r = await req('PUT', '/r/r2', { payload_transform_code: 'CODE-CHANGED' });
      // The middleware calls next() on ER_BAD_FIELD_ERROR → stub PUT route returns 200.
      assert.equal(r.status, 200);
      // status must NOT be 'pending' — no re-pend was applied.
      assert.notEqual(r.json.body.status, 'pending');
    } finally {
      require.cache[dbKey].exports.pool.ro.query = origRoQuery;
    }
  });
});
