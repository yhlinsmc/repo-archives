/**
 * field-options-empty-guard.test.js
 *
 * Generic CRUD `trimmedNonEmptyColumns` gate (route 2, per-row): field_options
 * option_label/option_value can never persist empty/whitespace-only strings
 * through the generic CRUD write path.
 *
 * Spy-pool HTTP harness copied from blueprint-groups-integrity.test.js.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const { answerParentIdProbe } = require('../helpers/parent-id-probe');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../src/edge/db');

let conn;

// Flexible spy connection. `scripts` is an array of [regex, responseOrFn].
// Falls back to safe defaults: DATABASE() → a name, information_schema.COLUMNS
// → [] (so getActualColumnSet caches null = "unknown, keep all keys"), the
// linked-blueprint probe → [] (not linked). Anything else unmatched throws so a
// test surfaces an unexpected query.
function makeConn(scripts = []) {
  const queries = [];
  const events = [];
  return {
    queries,
    events,
    async query(sql, params) {
      queries.push({ sql, params });
      for (const [matcher, response] of scripts) {
        if (matcher.test(sql)) {
          return typeof response === 'function' ? response(sql, params) : response;
        }
      }
      if (/SELECT DATABASE\(\)/i.test(sql)) return [{ db: 'testdb' }];
      if (/information_schema\.COLUMNS/i.test(sql)) return [];
      if (/SELECT linked_blueprint_id FROM/i.test(sql)) return [];
      // The factory asks which spelling the parent row really carries before it
      // binds one. Answered rather than thrown on — see tests/helpers.
      const parentId = answerParentIdProbe(sql, params);
      if (parentId) return parentId;
      throw new Error(`Unmatched query: ${sql.slice(0, 90)}`);
    },
    async beginTransaction() { events.push('begin'); },
    async commit() { events.push('commit'); },
    async rollback() { events.push('rollback'); },
    release() { events.push('release'); },
  };
}

const poolSpy = {
  rw: { async getConnection() { return conn; } },
  ro: { async getConnection() { return conn; } },
};

require.cache[dbKey] = {
  id: dbKey,
  filename: dbKey,
  loaded: true,
  exports: {
    pool: poolSpy,
    t: (name) => `fmb_${name}`,
    getDynamicPool: async () => poolSpy,
  },
};

const router = require('../../src/edge/routes/app/schema');
// Clear the (db,table) column-set cache between tests so a null probe result
// from one test does not leak into the next.
const { __clearColumnSetCache } = router.__test__;

let server;
let port;

before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => {
    req.user = { id: '5b729f1e-5c0b-447c-8144-3210469bc62c', email: 'admin@test', role: 'admin' };
    next();
  });
  app.use('/edge/app/schema', router);
  await new Promise((resolve) => {
    server = app.listen(0, '127.0.0.1', () => {
      port = server.address().port;
      resolve();
    });
  });
});

after(async () => {
  await new Promise((resolve) => server.close(resolve));
  delete require.cache[dbKey];
});

beforeEach(() => { conn = null; __clearColumnSetCache(); });

function send(method, path, body) {
  return new Promise((resolve, reject) => {
    const data = Buffer.from(JSON.stringify(body), 'utf-8');
    const req = http.request({
      method, host: '127.0.0.1', port, path,
      headers: { 'Content-Type': 'application/json', 'Content-Length': data.length },
    }, (res) => {
      const chunks = [];
      res.on('data', (c) => chunks.push(c));
      res.on('end', () => {
        const raw = Buffer.concat(chunks).toString('utf-8');
        let json = null;
        try { json = raw ? JSON.parse(raw) : null; } catch { /* */ }
        resolve({ status: res.statusCode, json });
      });
    });
    req.on('error', reject);
    req.write(data);
    req.end();
  });
}
const post = (p, b) => send('POST', p, b);
const put = (p, b) => send('PUT', p, b);

describe('field_options generic CRUD — trimmedNonEmptyColumns gate (Q11 route 2)', () => {
  it('rejects a POST whose option_value is whitespace-only (400 EMPTY_NOT_ALLOWED)', async () => {
    conn = makeConn(); // gate short-circuits before any DB query
    const res = await post('/edge/app/schema/field_options', {
      field_id: '2ce8ba8e-83f5-41ee-8246-a2265095b549', option_label: 'Ghost', option_value: '   ', sort_order: 0,
    });
    assert.equal(res.status, 400);
    assert.equal(res.json.error.code, 'EMPTY_NOT_ALLOWED');
  });

  it('rejects a POST whose option_label is empty (400 EMPTY_NOT_ALLOWED)', async () => {
    conn = makeConn();
    const res = await post('/edge/app/schema/field_options', {
      field_id: '2ce8ba8e-83f5-41ee-8246-a2265095b549', option_label: '', option_value: 'x', sort_order: 0,
    });
    assert.equal(res.status, 400);
    assert.equal(res.json.error.code, 'EMPTY_NOT_ALLOWED');
  });

  it('rejects a PUT whose present option_label is whitespace-only (400 EMPTY_NOT_ALLOWED)', async () => {
    conn = makeConn();
    const res = await put('/edge/app/schema/field_options/c6f4aeee-3349-4d1b-802d-1558a7780cf1', { option_label: '   ' });
    assert.equal(res.status, 400);
    assert.equal(res.json.error.code, 'EMPTY_NOT_ALLOWED');
  });

  it('does NOT fire the gate on a partial PUT that omits the option strings (R5)', async () => {
    // sort_order-only update: option_label/option_value are undefined → the gate
    // is skipped. The request then reaches the (unscripted) write path, so we
    // assert only that the gate did not reject it — this isolates the guard from
    // the unrelated ownership/write SQL.
    conn = makeConn();
    const res = await put('/edge/app/schema/field_options/c6f4aeee-3349-4d1b-802d-1558a7780cf1', { sort_order: 3 });
    assert.notEqual(res.json?.error?.code, 'EMPTY_NOT_ALLOWED');
  });

  it('does NOT fire the gate on a POST with valid non-empty option strings', async () => {
    conn = makeConn();
    const res = await post('/edge/app/schema/field_options', {
      field_id: '2ce8ba8e-83f5-41ee-8246-a2265095b549', option_label: 'Sedan', option_value: 'sedan', sort_order: 0,
    });
    assert.notEqual(res.json?.error?.code, 'EMPTY_NOT_ALLOWED');
  });

  it('rejects a POST that omits option_value entirely (400 EMPTY_NOT_ALLOWED)', async () => {
    // Present-only semantics are correct for PUT (partial update) but a create
    // must not be able to bypass the gate by simply never sending the column
    // — that would persist NULL, recreating exactly the dirty rows the gate
    // exists to prevent.
    conn = makeConn();
    const res = await post('/edge/app/schema/field_options', {
      field_id: '2ce8ba8e-83f5-41ee-8246-a2265095b549', option_label: 'Ghost', sort_order: 0,
    });
    assert.equal(res.status, 400);
    assert.equal(res.json.error.code, 'EMPTY_NOT_ALLOWED');
  });

  it('rejects a POST that omits option_label entirely (400 EMPTY_NOT_ALLOWED)', async () => {
    conn = makeConn();
    const res = await post('/edge/app/schema/field_options', {
      field_id: '2ce8ba8e-83f5-41ee-8246-a2265095b549', option_value: 'x', sort_order: 0,
    });
    assert.equal(res.status, 400);
    assert.equal(res.json.error.code, 'EMPTY_NOT_ALLOWED');
  });
});

describe('POST /field_options/replace — whitespace-only rejected (Q11 route 2, bulk)', () => {
  it('rejects a next item whose option_value is whitespace-only (400 BAD_REQUEST)', async () => {
    conn = makeConn(); // rejected during validation, before any DB query
    const res = await post('/edge/app/schema/field_options/replace', {
      field_id: '2ce8ba8e-83f5-41ee-8246-a2265095b549', expected: [],
      next: [{ option_label: 'Ghost', option_value: '   ', sort_order: 0 }],
    });
    assert.equal(res.status, 400);
    assert.equal(res.json.error.code, 'BAD_REQUEST');
  });

  it('rejects a next item whose option_label is whitespace-only (400 BAD_REQUEST)', async () => {
    conn = makeConn();
    const res = await post('/edge/app/schema/field_options/replace', {
      field_id: '2ce8ba8e-83f5-41ee-8246-a2265095b549', expected: [],
      next: [{ option_label: '  ', option_value: 'x', sort_order: 0 }],
    });
    assert.equal(res.status, 400);
    assert.equal(res.json.error.code, 'BAD_REQUEST');
  });

  it('allows a legacy whitespace-only expected row to be deleted (expected=[dirty], next=[])', async () => {
    // expected is a never-persisted optimistic-lock echo of current server
    // state, not a write. It must tolerate a pre-existing dirty row so the
    // delete-repair save (dropping that row from next) is not dead-ended.
    conn = makeConn();
    const res = await post('/edge/app/schema/field_options/replace', {
      field_id: '2ce8ba8e-83f5-41ee-8246-a2265095b549',
      expected: [{ id: 'c6f4aeee-3349-4d1b-802d-1558a7780cf1', option_label: 'Ghost', option_value: '   ', sort_order: 0 }],
      next: [],
    });
    assert.notEqual(res.json?.error?.code, 'BAD_REQUEST');
  });

  it('allows a legacy whitespace-only expected row alongside a clean next row', async () => {
    conn = makeConn();
    const res = await post('/edge/app/schema/field_options/replace', {
      field_id: '2ce8ba8e-83f5-41ee-8246-a2265095b549',
      expected: [{ id: 'c6f4aeee-3349-4d1b-802d-1558a7780cf1', option_label: 'Ghost', option_value: '   ', sort_order: 0 }],
      next: [{ option_label: 'Sedan', option_value: 'sedan', sort_order: 0 }],
    });
    assert.notEqual(res.json?.error?.code, 'BAD_REQUEST');
  });

  it('allows a legacy NULL-label/value expected row to be deleted (expected=[dirty], next=[])', async () => {
    // The DDL leaves option_label/option_value nullable and the serializer
    // does not coalesce them, so a legacy row can be a literal SQL NULL, not
    // just an empty/whitespace string. Same dead-end as the whitespace case
    // if expected does not tolerate it.
    conn = makeConn();
    const res = await post('/edge/app/schema/field_options/replace', {
      field_id: '2ce8ba8e-83f5-41ee-8246-a2265095b549',
      expected: [{ id: 'c6f4aeee-3349-4d1b-802d-1558a7780cf1', option_label: null, option_value: null, sort_order: 0 }],
      next: [],
    });
    assert.notEqual(res.json?.error?.code, 'BAD_REQUEST');
  });
});
