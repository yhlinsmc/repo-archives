// docker-api/tests/unit/limiters-resolve-rate-limit.test.js
const { describe, it, beforeEach, afterEach, after } = require('node:test');
const assert = require('node:assert/strict');

const cacheKey = require.resolve('../../src/infra/lib/rate-limit-config-cache');
const limitersKey = require.resolve('../../src/infra/limiters');
let snap = { general: null, connectorFetch: null, connectorWrite: null, auditSearch: null };
require.cache[cacheKey] = {
  id: cacheKey, filename: cacheKey, loaded: true,
  exports: { getRateLimitSnapshot: () => snap, maybeRefresh: () => {}, seedAtBoot: async () => {} },
};

const { resolveRateLimit } = require('../../src/infra/limiters');

beforeEach(() => { snap = { general: null, connectorFetch: null, connectorWrite: null, auditSearch: null }; delete process.env.RATE_LIMIT_GENERAL_MAX; });
afterEach(() => { delete process.env.RATE_LIMIT_GENERAL_MAX; });
// Restore the real modules so a shared-process runner doesn't inherit the
// cache stub (and the limiters module loaded against it). No-op under
// node:test's default file-per-process isolation.
after(() => { delete require.cache[cacheKey]; delete require.cache[limitersKey]; });

describe('resolveRateLimit precedence DB > env > default', () => {
  it('uses the DB snapshot value when present', () => {
    snap.general = 1500;
    process.env.RATE_LIMIT_GENERAL_MAX = '999';
    assert.equal(resolveRateLimit('general', 2000), 1500);
  });
  it('falls through to the provided fallback when DB is null', () => {
    snap.general = null;
    assert.equal(resolveRateLimit('general', 777), 777);
  });
});
