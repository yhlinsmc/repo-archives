/**
 * machine-token-verify.test.js — infra-side validateMachineToken S2S seam.
 *
 * Auth v2: infra no longer verifies a JWT locally; it forwards the raw token to
 * edge (POST /edge/internal/machine-token/resolve) and trusts the { sub, scope }
 * a 200 carries. This proves:
 *   - a 200 resolve returns { sub, scope }
 *   - any non-200 (401 unknown/inactive, 503 edge-unreachable, other) throws
 *     (the gate fails closed)
 *   - the forward targets the resolve path and carries { token, auditInfo } + reqPath
 *
 * forwardToEdge is stubbed via require.cache — no real edge, no jose, no keys.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');

const remoteClientPath = require.resolve('../../src/infra/lib/remote-client');
const mtvPath = require.resolve('../../src/infra/lib/machine-token-verify');

let nextForward;      // { status, data } the stub returns
let lastForwardArgs;

require.cache[remoteClientPath] = {
  id: remoteClientPath, filename: remoteClientPath, loaded: true,
  exports: {
    forwardToEdge: async (args) => { lastForwardArgs = args; return nextForward; },
  },
};

let mtv;
before(() => { mtv = require(mtvPath); });
after(() => {
  delete require.cache[remoteClientPath];
  delete require.cache[mtvPath];
});
beforeEach(() => { nextForward = undefined; lastForwardArgs = undefined; });

describe('validateMachineToken — S2S resolve seam', () => {
  it('returns { sub, scope } when edge resolves the token (200)', async () => {
    nextForward = { status: 200, data: { sub: 'sa-42', scope: { roots: ['n1'], operations: ['read'] } } };
    const out = await mtv.validateMachineToken('opaque-token', {
      reqPath: '/api/public/v1/blueprints',
      auditInfo: { ip: '10.0.0.1', userAgent: 'curl/8' },
    });
    assert.deepEqual(out, { sub: 'sa-42', scope: { roots: ['n1'], operations: ['read'] } });
  });

  it('forwards to the resolve path carrying { token, auditInfo } + reqPath', async () => {
    nextForward = { status: 200, data: { sub: 'sa-1', scope: { roots: ['n1'] } } };
    await mtv.validateMachineToken('the-token', {
      reqPath: '/api/public/v1/runs', auditInfo: { ip: '1.2.3.4', userAgent: 'ua' },
    });
    assert.equal(lastForwardArgs.method, 'POST');
    assert.equal(lastForwardArgs.path, '/edge/internal/machine-token/resolve');
    assert.equal(lastForwardArgs.body.token, 'the-token');
    assert.deepEqual(lastForwardArgs.body.auditInfo, { ip: '1.2.3.4', userAgent: 'ua' });
    assert.equal(lastForwardArgs.reqPath, '/api/public/v1/runs');
  });

  it('throws on a 401 (unknown/inactive token) — gate fails closed', async () => {
    nextForward = { status: 401, data: { error: 'invalid_token' } };
    await assert.rejects(() => mtv.validateMachineToken('bad', {}));
  });

  it('throws on a 503 (edge-unreachable) — gate fails closed', async () => {
    nextForward = { status: 503, data: { error: 'edge_unreachable' } };
    await assert.rejects(() => mtv.validateMachineToken('any', {}));
  });

  it('throws on any other non-200 status', async () => {
    nextForward = { status: 502, data: null };
    await assert.rejects(() => mtv.validateMachineToken('any', {}));
  });

  it('works without opts (auditInfo/reqPath default to undefined)', async () => {
    nextForward = { status: 200, data: { sub: 'sa-9', scope: { roots: ['x'] } } };
    const out = await mtv.validateMachineToken('t');
    assert.equal(out.sub, 'sa-9');
    assert.equal(lastForwardArgs.body.auditInfo, undefined);
    assert.equal(lastForwardArgs.reqPath, undefined);
  });
});
