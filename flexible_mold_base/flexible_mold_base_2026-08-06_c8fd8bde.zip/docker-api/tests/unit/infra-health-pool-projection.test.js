'use strict';

/**
 * infra-health-pool-projection.test.js — what infra republishes from the edge
 * pool diagnostic, and what it does not.
 *
 * `GET /health` on infra is mounted ahead of every auth middleware, and the
 * gateway's `prefix: /` route lands there, so its body is readable by anyone who
 * can reach the host. The body's `pool` block comes straight out of this cache.
 *
 * Copying edge's diagnostic verbatim made that surface grow by accident: a field
 * added to `buildPoolDiagnostic` for an operator became public the moment it was
 * added, with no decision taken. So the cache PROJECTS onto a declared list, and
 * this file pins both halves — the fields consumers actually read still arrive,
 * and a field that is not on the list does not, whether or not anyone remembered
 * it existed.
 *
 * The list is now the shared one, declared next to the builder and imported
 * here, because withholding a field from THIS endpoint while /edge/health kept
 * answering the same question is how the first attempt at that reading left a
 * second door open. What remains worth doing here is the version skew: during a
 * rolling deploy this republishes a reply from an edge of a different build.
 */

const { describe, it, beforeEach, after } = require('node:test');
const assert = require('node:assert/strict');

process.env.JWT_SECRET = process.env.JWT_SECRET || 'a'.repeat(48);
process.env.S2S_API_KEY = process.env.S2S_API_KEY || 's2s-test';

const edgeClientKey = require.resolve('../../src/infra/lib/edge-state-client');
const cacheKey = require.resolve('../../src/infra/lib/pool-state-cache');

let healthImpl;

require.cache[edgeClientKey] = {
  id: edgeClientKey,
  filename: edgeClientKey,
  loaded: true,
  exports: { fetchEdgeHealth: async () => healthImpl() },
};

const {
  getCachedPoolState, invalidatePoolStateCache, PUBLISHED_POOL_FIELDS,
} = require('../../src/infra/lib/pool-state-cache');
const { buildPoolDiagnostic } = require('../../src/shared/lib/pool-diagnostic');

// The shape edge really sends — BUILT BY THE BUILDER EDGE USES, not hand-listed
// beside it. A hand-written copy of another module's output drifts the moment
// that module gains a field, and drifts silently: the double keeps answering
// for a shape nothing produces any more, and the projection under test is then
// measured against a fiction.
const EDGE_POOL = Object.freeze(buildPoolDiagnostic({
  poolReady: true,
  lastError: null,
  envPresence: { DB_RW_HOST: true },
  dbConfigJsonPresent: true,
  tablePrefixSet: true,
  encryptionKeyPresent: true,
}));

beforeEach(() => {
  invalidatePoolStateCache();
  healthImpl = () => ({ reachable: true, db: 'ok', pool: { ...EDGE_POOL } });
});

after(() => {
  delete require.cache[edgeClientKey];
  delete require.cache[cacheKey];
});

describe('the pool block infra publishes on an unauthenticated surface', () => {
  it('does not carry whether this engine silently substitutes a value it cannot store', async () => {
    // The edge THIS build ships does not send the reading at all — it is not on
    // the diagnostic any more, because withholding it here would have left the
    // same answer readable straight off /edge/health. So the case worth pinning
    // is the one where this projection is the only thing standing in the way:
    // during a rolling deploy infra republishes a reply from an edge of a
    // DIFFERENT build, and an older one does send it.
    healthImpl = () => ({
      reachable: true, db: 'ok', pool: { ...EDGE_POOL, configured_pool_strict_writes: 'lax' },
    });
    const { pool } = await getCachedPoolState();
    // Named twice on purpose: `undefined` is what a consumer sees, and the
    // absent key is what a reader of the response body sees. A blacklist that
    // set the field to undefined would satisfy only the first.
    assert.equal(pool.configured_pool_strict_writes, undefined);
    assert.equal(
      Object.prototype.hasOwnProperty.call(pool, 'configured_pool_strict_writes'), false,
      'a caller who has not authenticated must not learn that a truncating or clamping '
      + 'write is worth attempting against this host',
    );
  });

  it('and the edge this build ships does not send it in the first place', async () => {
    // The fixture is the real builder's output, so this asserts about the
    // producer rather than about a copy of it: the reading is off the body both
    // health endpoints are built from, not merely off one of them.
    assert.equal(
      Object.prototype.hasOwnProperty.call(EDGE_POOL, 'configured_pool_strict_writes'), false,
    );
  });

  it('still carries every field the diagnostics panel and the pool gate read', async () => {
    const { pool } = await getCachedPoolState();
    assert.deepEqual(pool, {
      pool_state: 'configured',
      hint_code: null,
      env_keys_present: { DB_RW_HOST: true },
      db_config_json_present: true,
      table_prefix_set: true,
      last_configure_error: null,
      degraded_grants: null,
      encryption_key_present: true,
    });
  });

  it('drops a field edge adds that nobody decided to publish', async () => {
    // The property that makes this a whitelist rather than one removal. The
    // next field added to the edge diagnostic reaches the public body only if
    // someone puts its name on the list.
    healthImpl = () => ({
      reachable: true,
      db: 'ok',
      pool: { ...EDGE_POOL, db_host: 'db-primary.internal', some_future_field: 'leaked' },
    });
    const { pool } = await getCachedPoolState();
    assert.equal(pool.db_host, undefined);
    assert.equal(pool.some_future_field, undefined);
    assert.deepEqual(Object.keys(pool).sort(), [...PUBLISHED_POOL_FIELDS].sort());
  });

  it('keeps the synthesised block when edge does not answer', async () => {
    healthImpl = () => ({ reachable: false, db: 'unknown', pool: null });
    const state = await getCachedPoolState();
    assert.equal(state.edge_unreachable, true);
    assert.equal(state.pool.pool_state, 'setup-required');
    assert.equal(state.pool.hint_code, 'edge_unreachable');
    // The strict-writes reading is not synthesised as 'unknown' here either:
    // it is not part of this surface at all, so there is nothing to report as
    // unmeasured. Anything else would put the name back on a public body.
    assert.equal(
      Object.prototype.hasOwnProperty.call(state.pool, 'configured_pool_strict_writes'), false,
    );
  });

  it('reports a partial edge reply as partial rather than as a set of undefined fields', async () => {
    healthImpl = () => ({
      reachable: true, db: 'ok', pool: { pool_state: 'degraded', hint_code: 'table_missing' },
    });
    const { pool } = await getCachedPoolState();
    assert.deepEqual(Object.keys(pool).sort(), ['hint_code', 'pool_state']);
  });
});
