/**
 * flow-recipes-serialize.test.js
 *
 * Tests the /serialize endpoint mounted on the flow-recipes router:
 *   (a) POST /serialize {payload:{a:1,b:[1,2]}} → 200, apiOk envelope,
 *       data.text is YAML that round-trips back to the original object
 *   (b) POST /serialize {payload:null} → 400 INVALID_PAYLOAD
 *   (c) POST /serialize {payload:"x"} (primitive string) → 400 INVALID_PAYLOAD
 *   (d) POST /serialize {payload:[1,2,3]} → 200 (array is a valid YAML doc)
 *   (e) /serialize is reachable — not swallowed by /:id GET
 *
 * The serialize endpoint lives at POST /fr/serialize; it is registered AFTER
 * requireAdminOrEditor (so it is gated) and before the CRUD /:id catch-all to
 * avoid shadowing. The test server sets req.user to an editor so the gate
 * passes; unauthenticated access returns 401.
 */
const { describe, it, before, after } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');
const yaml = require('yaml');

// Mock the DB module BEFORE requiring the router so all require('../../../db')
// calls inside flow-recipes/* resolve to the stub.
const dbKey = require.resolve('../../src/edge/db');
if (!require.cache[dbKey]) {
  require.cache[dbKey] = {
    id: dbKey, filename: dbKey, loaded: true,
    exports: {
      pool: {
        ro: { getConnection: async () => ({ query: async () => [], release() {} }), query: async () => [] },
        rw: { getConnection: async () => ({ query: async () => [], release() {} }), query: async () => [] },
      },
      t: (n) => `fmb_${n}`,
    },
  };
}

const router = require('../../src/edge/routes/app/flow-recipes');

let server; let base;
before(async () => {
  const app = express();
  // Mirror index-edge.js: global json body parser (10mb cap); route has no local parser.
  app.use(express.json());
  // /serialize is gated by requireAdminOrEditor — set req.user so the gate passes.
  app.use((req, _res, next) => {
    req.user = { id: 'editor-1', role: 'editor', email: 'a@x' };
    next();
  });
  app.use('/fr', router);
  server = http.createServer(app);
  await new Promise((r) => server.listen(0, r));
  base = `http://127.0.0.1:${server.address().port}`;
});
after(() => server && server.close());

async function post(body) {
  const res = await fetch(`${base}/fr/serialize`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
  });
  const text = await res.text();
  let json = null;
  try { json = JSON.parse(text); } catch (_) {}
  return { status: res.status, contentType: res.headers.get('content-type'), text, json };
}

describe('flow-recipes /serialize — valid object payload → apiOk envelope', () => {
  it('returns 200 application/json envelope; data.text round-trips via yaml.parse', async () => {
    const payload = { a: 1, b: [1, 2] };
    const { status, contentType, json } = await post({ payload });
    assert.equal(status, 200, 'should return 200');
    assert.ok(contentType?.includes('application/json'), 'content-type must be application/json');
    assert.equal(json.error, null, 'envelope error must be null');
    assert.ok(typeof json.data.text === 'string', 'data.text must be a string');
    const parsed = yaml.parse(json.data.text);
    assert.deepEqual(parsed, payload, 'yaml.parse of data.text must equal the original payload');
  });
});

describe('flow-recipes /serialize — array payload → apiOk envelope', () => {
  it('accepts an array (valid YAML document) and returns 200 envelope', async () => {
    const payload = [1, 2, 3];
    const { status, contentType, json } = await post({ payload });
    assert.equal(status, 200);
    assert.ok(contentType?.includes('application/json'));
    assert.equal(json.error, null);
    assert.deepEqual(yaml.parse(json.data.text), payload);
  });
});

describe('flow-recipes /serialize — null payload → 400', () => {
  it('POST {payload:null} → 400 INVALID_PAYLOAD', async () => {
    const { status, json } = await post({ payload: null });
    assert.equal(status, 400);
    assert.equal(json.error, 'INVALID_PAYLOAD');
  });
});

describe('flow-recipes /serialize — primitive payload → 400', () => {
  it('POST {payload:"x"} (string) → 400 INVALID_PAYLOAD', async () => {
    const { status, json } = await post({ payload: 'x' });
    assert.equal(status, 400);
    assert.equal(json.error, 'INVALID_PAYLOAD');
  });

  it('POST {payload:42} (number) → 400 INVALID_PAYLOAD', async () => {
    const { status, json } = await post({ payload: 42 });
    assert.equal(status, 400);
    assert.equal(json.error, 'INVALID_PAYLOAD');
  });
});

describe('flow-recipes /serialize — route is not swallowed by /:id', () => {
  it('/serialize is reachable as POST (not intercepted by GET /:id catch-all)', async () => {
    // A GET /fr/serialize would be captured by the CRUD factory /:id GET and
    // return a 404 (no such recipe id). POST /fr/serialize must route to the
    // serialize handler regardless. A valid object payload must yield 200.
    const { status } = await post({ payload: { check: true } });
    assert.equal(status, 200, `/serialize returned unexpected status ${status}`);
  });
});

// Auth-gate regression — /serialize must stay behind requireAdminOrEditor.
// This describe spins up its own app WITHOUT the req.user injection middleware
// so the router's gate is exercised with an unauthenticated request.
describe('flow-recipes /serialize — auth gate regression (unauthenticated → 401)', () => {
  let unauthServer; let unauthBase;
  before(async () => {
    const unauthApp = express();
    // Deliberately no req.user middleware — simulate an unauthenticated request.
    unauthApp.use(express.json());
    unauthApp.use('/fr', router);
    unauthServer = http.createServer(unauthApp);
    await new Promise((r) => unauthServer.listen(0, r));
    unauthBase = `http://127.0.0.1:${unauthServer.address().port}`;
  });
  after(() => unauthServer && unauthServer.close());

  it('POST /serialize without req.user is rejected by the auth gate (401)', async () => {
    const res = await fetch(`${unauthBase}/fr/serialize`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ payload: { a: 1 } }),
    });
    // requireAdminOrEditor calls requireAuth which returns 401 when req.user is absent.
    assert.equal(res.status, 401, `expected 401 from auth gate, got ${res.status}`);
  });
});
