'use strict';

const { test } = require('node:test');
const assert = require('node:assert/strict');
const { BLUEPRINT_PARENT_TYPES, isValidBlueprintParent } = require('../../src/shared/hierarchy-tiers');

test('blueprint parent must be release only', () => {
  assert.deepEqual(BLUEPRINT_PARENT_TYPES, ['release']);
  assert.equal(isValidBlueprintParent('release'), true);
  assert.equal(isValidBlueprintParent('category'), false);
  assert.equal(isValidBlueprintParent('generation'), false);
  assert.equal(isValidBlueprintParent('blueprint'), false);
  assert.equal(isValidBlueprintParent('variant'), false);
});
