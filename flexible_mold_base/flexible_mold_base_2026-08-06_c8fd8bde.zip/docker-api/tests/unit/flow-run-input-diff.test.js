// docker-api/tests/unit/flow-run-input-diff.test.js
//
// Whether a run's answers differ from the run before it — and, above all, the
// difference between "they did not change" and "there is nothing to compare".
// Conflating those two is the single most misleading thing the history can say.
const { test } = require('node:test');
const assert = require('node:assert');

const {
  DIFF_CHANGED, DIFF_UNCHANGED, DIFF_UNAVAILABLE,
  REASON_FIRST_RUN, REASON_NOT_RECORDED, REASON_CAPTURE_DROPPED,
  REASON_PREVIOUS_NOT_RECORDED,
  readSnapshot, compareRunInput, attachInputDiff,
} = require('../../src/edge/routes/app/flow-recipe-runs/input-diff');

const FIELD_A = '11111111-1111-1111-1111-111111111111';

function captured({ entered = {}, computed = {} } = {}) {
  return JSON.stringify({
    entered,
    computed,
    fields: { size: FIELD_A },
    blueprint_id: '22222222-2222-2222-2222-222222222222',
    variant_id: null,
  });
}

// ── reading one stored document ─────────────────────────────────────────────

test('a captured document reads as captured', () => {
  const read = readSnapshot(captured({ entered: { size: '10' } }));
  assert.strictEqual(read.state, 'captured');
  assert.deepStrictEqual(read.entered, { size: '10' });
});

test('a document stating the capture was dropped is not read as captured', () => {
  assert.strictEqual(readSnapshot(JSON.stringify({ not_captured: 'too_large' })).state, 'dropped');
});

test('NULL — no capture was ever attempted — is not read as captured', () => {
  assert.strictEqual(readSnapshot(null).state, 'absent');
  assert.strictEqual(readSnapshot('').state, 'absent');
});

test('an unreadable document is read as absent, never as a comparable one', () => {
  // Being unable to read a document is not evidence about what it said.
  assert.strictEqual(readSnapshot('not json at all').state, 'absent');
  assert.strictEqual(readSnapshot('[1,2,3]').state, 'absent');
  assert.strictEqual(readSnapshot(JSON.stringify({ entered: 'text' })).state, 'absent');
});

// ── comparing two runs ──────────────────────────────────────────────────────

test('the same answers report unchanged', () => {
  const doc = captured({ entered: { size: '10', name: 'a' }, computed: { total: '20' } });
  assert.deepStrictEqual(compareRunInput(doc, doc), { diff: DIFF_UNCHANGED, reason: null });
});

test('key order is not a difference', () => {
  const a = JSON.stringify({
    entered: { size: '10', name: 'a' }, computed: {}, fields: {}, blueprint_id: null, variant_id: null,
  });
  const b = JSON.stringify({
    entered: { name: 'a', size: '10' }, computed: {}, fields: {}, blueprint_id: null, variant_id: null,
  });
  assert.strictEqual(compareRunInput(a, b).diff, DIFF_UNCHANGED);
});

test('a changed answer reports changed', () => {
  const now = captured({ entered: { size: '11' } });
  const before = captured({ entered: { size: '10' } });
  assert.deepStrictEqual(compareRunInput(now, before), { diff: DIFF_CHANGED, reason: null });
});

test('an answer added or removed is a difference, not a shorter loop', () => {
  const more = captured({ entered: { size: '10', extra: 'x' } });
  const fewer = captured({ entered: { size: '10' } });
  assert.strictEqual(compareRunInput(more, fewer).diff, DIFF_CHANGED);
  assert.strictEqual(compareRunInput(fewer, more).diff, DIFF_CHANGED);
});

test('a computed value that drifted under identical typing is a difference', () => {
  // The computed half is part of what produced the payload; calling this "no
  // changes" would hide exactly the drift this page is read for.
  const now = captured({ entered: { size: '10' }, computed: { total: '21' } });
  const before = captured({ entered: { size: '10' }, computed: { total: '20' } });
  assert.strictEqual(compareRunInput(now, before).diff, DIFF_CHANGED);
});

test('identifiers moving under identical answers is not a difference', () => {
  // A field deleted and recreated, or a blueprint edited between runs, changes
  // the identifiers while the operator typed the same thing.
  const now = JSON.stringify({
    entered: { size: '10' }, computed: {},
    fields: { size: FIELD_A }, blueprint_id: 'b1', variant_id: 'v1',
  });
  const before = JSON.stringify({
    entered: { size: '10' }, computed: {},
    fields: { size: '99999999-9999-9999-9999-999999999999' }, blueprint_id: 'b2', variant_id: null,
  });
  assert.strictEqual(compareRunInput(now, before).diff, DIFF_UNCHANGED);
});

test('a run with no run before it says so, and does not say "no changes"', () => {
  const { diff, reason } = compareRunInput(captured({ entered: { size: '10' } }), undefined);
  assert.strictEqual(diff, DIFF_UNAVAILABLE);
  assert.strictEqual(reason, REASON_FIRST_RUN);
});

test('a run recorded before the answers were captured says so', () => {
  const { diff, reason } = compareRunInput(null, captured());
  assert.strictEqual(diff, DIFF_UNAVAILABLE);
  assert.strictEqual(reason, REASON_NOT_RECORDED);
});

test('a run whose capture was dropped is distinguished from one never attempted', () => {
  const dropped = compareRunInput(JSON.stringify({ not_captured: 'too_large' }), captured());
  assert.strictEqual(dropped.reason, REASON_CAPTURE_DROPPED);
  assert.notStrictEqual(dropped.reason, REASON_NOT_RECORDED);
});

test('a comparable run whose predecessor has nothing recorded reports that', () => {
  const { diff, reason } = compareRunInput(captured({ entered: { size: '10' } }), null);
  assert.strictEqual(diff, DIFF_UNAVAILABLE);
  assert.strictEqual(reason, REASON_PREVIOUS_NOT_RECORDED);
});

test('no path returns "unchanged" for a run that was never captured', () => {
  for (const value of [null, '', 'garbage', JSON.stringify({ not_captured: 'outputs_stale' })]) {
    const { diff } = compareRunInput(value, captured());
    assert.notStrictEqual(diff, DIFF_UNCHANGED);
    assert.strictEqual(diff, DIFF_UNAVAILABLE);
  }
});

// ── a page of runs ──────────────────────────────────────────────────────────

test('each row is compared with the next older row on the page', () => {
  const rows = [
    { id: 'r3', input_snapshot: captured({ entered: { size: '12' } }) },
    { id: 'r2', input_snapshot: captured({ entered: { size: '12' } }) },
    { id: 'r1', input_snapshot: captured({ entered: { size: '10' } }) },
  ];
  const out = attachInputDiff(rows, undefined, { hasSnapshotColumn: true });
  assert.strictEqual(out[0].input_diff, DIFF_UNCHANGED);
  assert.strictEqual(out[1].input_diff, DIFF_CHANGED);
  // Oldest row on the page with nothing behind it.
  assert.strictEqual(out[2].input_diff, DIFF_UNAVAILABLE);
  assert.strictEqual(out[2].input_diff_reason, REASON_FIRST_RUN);
});

test('the row one past the page is the oldest row\'s partner and is not returned', () => {
  const rows = [{ id: 'r2', input_snapshot: captured({ entered: { size: '12' } }) }];
  const lookahead = { id: 'r1', input_snapshot: captured({ entered: { size: '10' } }) };
  const out = attachInputDiff(rows, lookahead, { hasSnapshotColumn: true });
  assert.strictEqual(out.length, 1);
  assert.strictEqual(out[0].input_diff, DIFF_CHANGED);
});

test('the stored document never reaches the response', () => {
  const rows = [{ id: 'r1', input_snapshot: captured({ entered: { secret_note: 'x' } }) }];
  const [out] = attachInputDiff(rows, undefined, { hasSnapshotColumn: true });
  assert.ok(!('input_snapshot' in out));
});

test('a database without the column reports every row as not recorded', () => {
  const rows = [{ id: 'r2' }, { id: 'r1' }];
  const out = attachInputDiff(rows, undefined, { hasSnapshotColumn: false });
  for (const row of out) {
    assert.strictEqual(row.input_diff, DIFF_UNAVAILABLE);
    assert.strictEqual(row.input_diff_reason, REASON_NOT_RECORDED);
  }
});
