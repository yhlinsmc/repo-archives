/**
 * hierarchy-path.test.js — server-side lineage resolver used by connector
 * export/import path binding.
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const { buildHierarchyPath, pathsEqual, findBlueprintIdsByPath } = require('../../src/edge/lib/hierarchy-path');

const nodes = [
  { id: 'g', parent_id: null, name: 'Gen A', node_type: 'generation' },
  { id: 'r', parent_id: 'g', name: 'Release 1', node_type: 'release' },
  { id: 'b1', parent_id: 'r', name: 'Mold', node_type: 'blueprint' },
  { id: 'g2', parent_id: null, name: 'Gen B', node_type: 'generation' },
  { id: 'b2', parent_id: 'g2', name: 'Mold', node_type: 'blueprint' }, // same name, other lineage
  { id: 'orphan', parent_id: 'missing', name: 'Orphan', node_type: 'blueprint' },
  { id: 'cA', parent_id: 'cB', name: 'A', node_type: 'blueprint' },
  { id: 'cB', parent_id: 'cA', name: 'B', node_type: 'release' },
];

describe('buildHierarchyPath', () => {
  it('builds the full ancestor chain root to self', () => {
    assert.deepEqual(buildHierarchyPath(nodes, 'b1'), ['Gen A', 'Release 1', 'Mold']);
  });
  it('returns empty array for a missing id', () => {
    assert.deepEqual(buildHierarchyPath(nodes, 'nope'), []);
  });
  it('stops at a broken parent link', () => {
    assert.deepEqual(buildHierarchyPath(nodes, 'orphan'), ['Orphan']);
  });
  it('is cycle-safe', () => {
    assert.deepEqual(buildHierarchyPath(nodes, 'cA'), ['B', 'A']);
  });
});

describe('pathsEqual', () => {
  it('is true for identical chains', () => {
    assert.equal(pathsEqual(['a', 'b'], ['a', 'b']), true);
  });
  it('is false for different length or content', () => {
    assert.equal(pathsEqual(['a'], ['a', 'b']), false);
    assert.equal(pathsEqual(['a', 'b'], ['a', 'c']), false);
    assert.equal(pathsEqual('a', ['a']), false);
  });
});

describe('findBlueprintIdsByPath', () => {
  it('returns the single blueprint whose lineage matches', () => {
    assert.deepEqual(findBlueprintIdsByPath(nodes, ['Gen A', 'Release 1', 'Mold']), ['b1']);
    assert.deepEqual(findBlueprintIdsByPath(nodes, ['Gen B', 'Mold']), ['b2']);
  });
  it('returns multiple ids when two blueprints share a lineage (ambiguous)', () => {
    const dup = [
      { id: 'x1', parent_id: null, name: 'Root', node_type: 'blueprint' },
      { id: 'x2', parent_id: null, name: 'Root', node_type: 'blueprint' },
    ];
    assert.equal(findBlueprintIdsByPath(dup, ['Root']).length, 2);
  });
  it('returns empty when no blueprint matches', () => {
    assert.deepEqual(findBlueprintIdsByPath(nodes, ['Gen A', 'Mold']), []);
  });
  it('returns empty for an empty target path', () => {
    assert.deepEqual(findBlueprintIdsByPath(nodes, []), []);
  });
  it('only matches blueprint node_type, not intermediate nodes', () => {
    // 'Gen A' alone is a generation node, never a blueprint match.
    assert.deepEqual(findBlueprintIdsByPath(nodes, ['Gen A']), []);
  });
});
