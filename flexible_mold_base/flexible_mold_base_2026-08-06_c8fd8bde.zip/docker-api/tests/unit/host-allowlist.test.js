/**
 * host-allowlist.test.js — global egress allow-list matcher + loader.
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const { hostAllowed, hostFromUrl } = require('../../src/shared/lib/host-allowlist');

describe('hostAllowed — empty list (opt-in)', () => {
  it('allows everything when the list is empty', () => {
    assert.equal(hostAllowed('anything.com', []), true);
  });
  it('allows everything when the list is null/undefined/non-array', () => {
    assert.equal(hostAllowed('anything.com', null), true);
    assert.equal(hostAllowed('anything.com', undefined), true);
    assert.equal(hostAllowed('anything.com', 'api.x.com'), true);
  });
});

describe('hostAllowed — exact host', () => {
  it('matches an exact host', () => {
    assert.equal(hostAllowed('api.example.com', ['api.example.com']), true);
  });
  it('rejects a host not on the list', () => {
    assert.equal(hostAllowed('evil.com', ['api.example.com']), false);
  });
  it('is case-insensitive', () => {
    assert.equal(hostAllowed('API.Example.COM', ['api.example.com']), true);
    assert.equal(hostAllowed('api.example.com', ['API.EXAMPLE.COM']), true);
  });
  it('tolerates a trailing FQDN dot on the host and the pattern', () => {
    assert.equal(hostAllowed('api.example.com.', ['api.example.com']), true);
    assert.equal(hostAllowed('api.example.com', ['api.example.com.']), true);
  });
  it('does not match a different host that merely shares a suffix string', () => {
    assert.equal(hostAllowed('evil-example.com', ['example.com']), false);
    assert.equal(hostAllowed('notexample.com', ['example.com']), false);
  });
});

describe('hostAllowed — *.suffix wildcard', () => {
  it('matches a subdomain', () => {
    assert.equal(hostAllowed('a.example.com', ['*.example.com']), true);
    assert.equal(hostAllowed('a.b.example.com', ['*.example.com']), true);
  });
  it('does NOT match the apex (must be listed explicitly)', () => {
    assert.equal(hostAllowed('example.com', ['*.example.com']), false);
  });
  it('rejects suffix-confusion bypasses', () => {
    // boundary is the leading dot — these must all fail
    assert.equal(hostAllowed('a.example.com.attacker.net', ['*.example.com']), false);
    assert.equal(hostAllowed('example.com.attacker.net', ['*.example.com']), false);
    assert.equal(hostAllowed('evilexample.com', ['*.example.com']), false);
    assert.equal(hostAllowed('evil-example.com', ['*.example.com']), false);
  });
  it('a bare "*." never matches everything', () => {
    assert.equal(hostAllowed('anything.com', ['*.']), false);
  });
  it('apex listed alongside the wildcard allows both', () => {
    const list = ['example.com', '*.example.com'];
    assert.equal(hostAllowed('example.com', list), true);
    assert.equal(hostAllowed('a.example.com', list), true);
  });
});

describe('hostAllowed — port', () => {
  it('a host-only pattern matches any port', () => {
    assert.equal(hostAllowed('api.example.com:8443', ['api.example.com']), true);
    assert.equal(hostAllowed('api.example.com', ['api.example.com']), true);
  });
  it('a port-pinned pattern requires that exact port', () => {
    assert.equal(hostAllowed('api.example.com:8443', ['api.example.com:8443']), true);
    assert.equal(hostAllowed('api.example.com:9999', ['api.example.com:8443']), false);
    assert.equal(hostAllowed('api.example.com', ['api.example.com:8443']), false);
  });
  it('port pinning composes with the wildcard', () => {
    assert.equal(hostAllowed('a.example.com:443', ['*.example.com:443']), true);
    assert.equal(hostAllowed('a.example.com:80', ['*.example.com:443']), false);
  });
});

describe('hostAllowed — junk entries', () => {
  it('ignores empty/non-string patterns but honours valid ones', () => {
    assert.equal(hostAllowed('api.example.com', ['', '  ', null, 42, 'api.example.com']), true);
    assert.equal(hostAllowed('evil.com', ['', '  ', null, 42]), false);
  });
  it('rejects an empty host against a non-empty list', () => {
    assert.equal(hostAllowed('', ['api.example.com']), false);
  });
});

describe('hostFromUrl — scheme default port', () => {
  it('fills 443 for https and 80 for http', () => {
    assert.equal(hostFromUrl('https://api.example.com/x'), 'api.example.com:443');
    assert.equal(hostFromUrl('http://api.example.com/x'), 'api.example.com:80');
  });
  it('preserves an explicit non-default port', () => {
    assert.equal(hostFromUrl('https://api.example.com:8443/x'), 'api.example.com:8443');
  });
  it('keeps IPv6 bracket form', () => {
    assert.equal(hostFromUrl('http://[2001:db8::1]:8080/x'), '[2001:db8::1]:8080');
    assert.equal(hostFromUrl('https://[2001:db8::1]/x'), '[2001:db8::1]:443');
  });
  it('returns empty on an unparseable url', () => {
    assert.equal(hostFromUrl('not a url'), '');
  });
});

describe('port-pinning via hostFromUrl (the default-port fix)', () => {
  it('a :443 pattern matches a plain https URL', () => {
    assert.equal(hostAllowed(hostFromUrl('https://api.example.com/x'), ['api.example.com:443']), true);
  });
  it('a :443 pattern does NOT match an http (port 80) URL', () => {
    assert.equal(hostAllowed(hostFromUrl('http://api.example.com/x'), ['api.example.com:443']), false);
  });
  it('a :8443 pattern matches only the explicit 8443 URL', () => {
    assert.equal(hostAllowed(hostFromUrl('https://api.example.com:8443/x'), ['api.example.com:8443']), true);
    assert.equal(hostAllowed(hostFromUrl('https://api.example.com/x'), ['api.example.com:8443']), false);
  });
  it('a host-only pattern still matches any scheme/port', () => {
    assert.equal(hostAllowed(hostFromUrl('https://api.example.com/x'), ['api.example.com']), true);
    assert.equal(hostAllowed(hostFromUrl('http://api.example.com:9000/x'), ['api.example.com']), true);
  });
});

describe('IPv6 footgun (fails safe)', () => {
  it('a bare "::1" pattern does NOT match the bracketed URL host', () => {
    assert.equal(hostAllowed(hostFromUrl('http://[::1]:8443/x'), ['::1']), false);
  });
  it('the bracket form "[::1]:8443" matches', () => {
    assert.equal(hostAllowed(hostFromUrl('http://[::1]:8443/x'), ['[::1]:8443']), true);
  });
});
