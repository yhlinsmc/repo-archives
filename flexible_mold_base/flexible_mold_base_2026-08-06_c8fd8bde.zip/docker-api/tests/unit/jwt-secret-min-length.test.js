'use strict';

/**
 * jwt-secret-min-length.test.js
 *
 * Pins the JWT_SECRET min-length startup validation added with the jose
 * migration. jose does NOT enforce a minimum HS256 key length (a 1-char secret
 * signs+verifies fine), so config.js must reject a weak secret itself.
 *
 * Two layers:
 *   1. validateJwtSecret(secret, mode) — pure branch coverage.
 *   2. Real module-load: requiring config.js with a too-short secret in local
 *      mode must process.exit(1) with a clear, non-leaking message (child proc).
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const { spawnSync } = require('node:child_process');

// >= 32 chars so requiring config.js in THIS process does not exit.
process.env.JWT_SECRET = process.env.JWT_SECRET || 'a'.repeat(48);

const { validateJwtSecret, MIN_JWT_SECRET_LENGTH } = require('../../src/shared/config');

const DOCKER_API_ROOT = path.join(__dirname, '..', '..');

describe('validateJwtSecret — pure branch coverage', () => {
  it('minimum length constant is 32', () => {
    assert.equal(MIN_JWT_SECRET_LENGTH, 32);
  });

  it('local mode + missing secret → not ok, "required" message', () => {
    const r = validateJwtSecret(undefined, 'local');
    assert.equal(r.ok, false);
    assert.match(r.message, /required/);
  });

  it('local mode + known placeholder → not ok', () => {
    const r = validateJwtSecret('change-me', 'local');
    assert.equal(r.ok, false);
    assert.match(r.message, /placeholder/i);
  });

  it('local mode + secret shorter than 32 → not ok, "32 characters" message', () => {
    const r = validateJwtSecret('a'.repeat(31), 'local');
    assert.equal(r.ok, false);
    assert.match(r.message, /32 characters/);
  });

  it('local mode + exactly 32 chars → ok', () => {
    assert.equal(validateJwtSecret('a'.repeat(32), 'local').ok, true);
  });

  it('local mode + long secret → ok', () => {
    assert.equal(validateJwtSecret('a'.repeat(64), 'local').ok, true);
  });

  it('keycloak mode + unset secret → ok (JWT optional)', () => {
    assert.equal(validateJwtSecret(undefined, 'keycloak').ok, true);
  });

  it('keycloak mode + short secret → ok (local-auth gate does not apply)', () => {
    assert.equal(validateJwtSecret('short', 'keycloak').ok, true);
  });

  it('failure messages never echo the secret value', () => {
    const secret = 'super-secret-do-not-leak';
    const r = validateJwtSecret(secret, 'local');
    assert.equal(r.ok, false);
    assert.ok(!r.message.includes(secret), 'message must not contain the secret value');
  });
});

describe('config.js module load — startup enforcement', () => {
  function loadConfigWith(jwtSecret) {
    return spawnSync(
      process.execPath,
      ['-e', "require('./src/shared/config'); process.stdout.write('LOADED_OK');"],
      {
        cwd: DOCKER_API_ROOT,
        encoding: 'utf-8',
        env: {
          ...process.env,
          JWT_SECRET: jwtSecret,
          NODE_ENV: 'test',
          // Force local mode: no keycloak issuer so resolveAuthMode() → 'local'.
          KEYCLOAK_ISSUER_BASE_URL: '',
          AUTH_MODE_OVERRIDE: '',
        },
      },
    );
  }

  it('too-short secret → exit 1 with clear "32 characters" message', () => {
    const res = loadConfigWith('too-short');
    assert.notEqual(res.status, 0, 'process must exit non-zero on short secret');
    const out = `${res.stdout}${res.stderr}`;
    assert.match(out, /32 characters/, 'must print the min-length reason');
    assert.ok(!out.includes('LOADED_OK'), 'config must not finish loading');
  });

  it('valid secret → loads cleanly (exit 0)', () => {
    const res = loadConfigWith('a'.repeat(48));
    assert.equal(res.status, 0, `expected clean load, got status ${res.status}: ${res.stderr}`);
    assert.match(res.stdout, /LOADED_OK/);
  });
});
