/**
 * flow-recipe-run-finalize-relay.test.js
 *
 * The infra POST /api/flow-recipes/:id/run-finalize handler is a thin
 * destructure-and-forward relay. v3.2.417 renamed the resolved_link /
 * resolved_external_id fields to the step-emit signal (link_emitted /
 * link_emitted_value / external_id_emitted / external_id_emitted_value).
 * A typo in that relay would silently degrade every client-orchestrated run to
 * "always not-emitted" with no red test elsewhere, so assert the pass-through
 * directly by capturing the forwardToEdge body.
 *
 * Run:
 *   cd docker-api && NODE_ENV=test node --test tests/unit/flow-recipe-run-finalize-relay.test.js
 */
const { test } = require('node:test');
const assert = require('node:assert/strict');

// Stub the S2S client BEFORE loading the route module so the handler forwards
// into our capture instead of hitting edge.
let capturedBody = null;
require.cache[require.resolve('../../src/infra/lib/remote-client')] = {
  exports: {
    forwardToEdge: async ({ body }) => {
      capturedBody = body;
      return { status: 200, data: { data: { finalized: true } } };
    },
    passthroughResponse: (res, r) => res.status(r.status).json(r.data),
  },
};
// dispatchOneStep is imported by the module but unused on this path — stub it out.
require.cache[require.resolve('../../src/infra/lib/flow-dispatch-step')] = {
  exports: { dispatchOneStep: async () => ({ ok: true, envelope: { upstream_status: 200, body: '{}' } }) },
};

const mountFlowRecipeRun = require('../../src/infra/routes/flow-recipe-run');

// Minimal express-shaped app that captures the POST handlers by path.
function collectRoutes() {
  const routes = {};
  const app = {
    post: (p, h) => { routes[p] = h; },
    get: () => {},
  };
  mountFlowRecipeRun(app);
  return routes;
}

function makeRes() {
  const res = { _status: 200, _json: null };
  res.status = (c) => { res._status = c; return res; };
  res.json = (b) => { res._json = b; return res; };
  return res;
}

test('run-finalize relay forwards the 4 emit fields and drops legacy resolved_* fields', async () => {
  const routes = collectRoutes();
  const handler = routes['/api/flow-recipes/:id/run-finalize'];
  assert.ok(handler, 'run-finalize handler must be mounted');

  const req = {
    params: { id: 'r1' },
    user: { id: 'u1', role: 'user' },
    id: 'req-1',
    body: {
      run_id: 'run1',
      ok: true,
      upstream_status: 200,
      body: '{"url":"https://x"}',
      error_summary: null,
      step_results: '[]',
      link_emitted: true,
      link_emitted_value: 'https://step/LINK',
      external_id_emitted: true,
      external_id_emitted_value: 'STEP-ID',
      // A stale/forged legacy pair — the relay must NOT forward these.
      resolved_link: 'https://forged',
      resolved_external_id: 'FORGED',
    },
  };
  const res = makeRes();
  await handler(req, res);

  assert.equal(res._status, 200);
  assert.ok(capturedBody, 'forwardToEdge should have been called');
  assert.equal(capturedBody.recipe_id, 'r1', 'recipe_id stamped from the URL param');
  assert.equal(capturedBody.link_emitted, true);
  assert.equal(capturedBody.link_emitted_value, 'https://step/LINK');
  assert.equal(capturedBody.external_id_emitted, true);
  assert.equal(capturedBody.external_id_emitted_value, 'STEP-ID');
  // Trust boundary: the legacy fields are no longer part of the relay contract.
  assert.equal('resolved_link' in capturedBody, false, 'resolved_link must not be forwarded');
  assert.equal('resolved_external_id' in capturedBody, false, 'resolved_external_id must not be forwarded');
});

test('run-finalize relay requires auth', async () => {
  const routes = collectRoutes();
  const handler = routes['/api/flow-recipes/:id/run-finalize'];
  const req = { params: { id: 'r1' }, body: {} }; // no req.user
  const res = makeRes();
  await handler(req, res);
  assert.equal(res._status, 401);
});
