/**
 * internal-spec-route.test.js — the login-gated internal (infra) OpenAPI spec
 * route (GET /api/openapi.json) and the production /api/docs stub.
 *
 * Posture change (v3.2.484): the internal spec was previously served with NO
 * auth in ALL environments and the prod /api/docs stub advertised its URL. It
 * is now an operator surface gated to a logged-in human (req.user only, the
 * same model as the public docs portal), and the stub no longer names it.
 *
 * Auth is faked with the neighbouring route-test convention (public-docs-route
 * .test.js): a middleware that conditionally copies a controllable currentUser
 * onto req.user. The gate reads req.user ONLY, so sending an Authorization
 * header without setting req.user models an opaque machine token.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

// Force the real rate limiter regardless of ambient DISABLE_RATE_LIMIT (mirrors
// public-docs-route.test.js) — createInternalSpecLimiter() must actually
// throttle for the rate-limiting describe block below.
delete process.env.DISABLE_RATE_LIMIT;
const { mountInternalSpec } = require('../../src/infra/routes/internal-spec');
const { DOCS_DISABLED_MESSAGE } = require('../../src/shared/docs-disabled');

let currentUser;

function buildServer() {
  const app = express();
  app.use((req, _res, next) => { if (currentUser) req.user = currentUser; next(); });
  mountInternalSpec(app);
  return app;
}

function request(path_, headers = {}) {
  return new Promise((resolve, reject) => {
    const req = http.request(
      { host: '127.0.0.1', port, path: path_, method: 'GET', headers },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          const raw = Buffer.concat(chunks).toString('utf-8');
          let json = null; try { json = JSON.parse(raw); } catch { /* non-json */ }
          resolve({ status: res.statusCode, headers: res.headers, raw, json });
        });
      },
    );
    req.on('error', reject);
    req.end();
  });
}

let server;
let port;

before(async () => {
  const app = buildServer();
  await new Promise((resolve) => { server = app.listen(0, '127.0.0.1', () => { port = server.address().port; resolve(); }); });
});

after(async () => { await new Promise((resolve) => server.close(resolve)); });

beforeEach(() => { currentUser = null; });

describe('GET /api/openapi.json (login-gated internal spec)', () => {
  it('401 for an anonymous caller (no req.user)', async () => {
    const res = await request('/api/openapi.json');
    assert.equal(res.status, 401);
    assert.equal(res.json?.error?.code, 'UNAUTHORIZED');
  });

  it('a raw Bearer token alone does NOT grant access (gate trusts req.user only)', async () => {
    const res = await request('/api/openapi.json', { Authorization: 'Bearer sa-opaque-machine-token' });
    assert.equal(res.status, 401);
    assert.equal(res.json?.error?.code, 'UNAUTHORIZED');
  });

  it('200 for a logged-in human and serves an OpenAPI document', async () => {
    currentUser = { id: 'u-1', role: 'user', email: 'u@x' };
    const res = await request('/api/openapi.json');
    assert.equal(res.status, 200);
    assert.equal(typeof res.json?.openapi, 'string');
    assert.ok(res.json?.paths && Object.keys(res.json.paths).length > 0, 'expected a non-empty paths object');
  });
});

describe('production /api/docs stub no longer advertises the raw spec URL', () => {
  it('the shared stub message does not name openapi.json', () => {
    assert.doesNotMatch(DOCS_DISABLED_MESSAGE, /openapi\.json/);
  });

  it('createApp serves the stub without an openapi.json pointer under NODE_ENV=production', async () => {
    const prev = process.env.NODE_ENV;
    process.env.NODE_ENV = 'production';
    let prodServer;
    try {
      // Require after setting NODE_ENV so createApp mounts the prod stub branch.
      const { createApp } = require('../../src/infra/app-setup');
      const app = createApp();
      await new Promise((resolve) => { prodServer = app.listen(0, '127.0.0.1', resolve); });
      const prodPort = prodServer.address().port;
      const res = await new Promise((resolve, reject) => {
        const req = http.request({ host: '127.0.0.1', port: prodPort, path: '/api/docs', method: 'GET' }, (r) => {
          const chunks = [];
          r.on('data', (c) => chunks.push(c));
          r.on('end', () => resolve({ status: r.statusCode, raw: Buffer.concat(chunks).toString('utf-8') }));
        });
        req.on('error', reject);
        req.end();
      });
      assert.equal(res.status, 200);
      assert.doesNotMatch(res.raw, /openapi\.json/);
    } finally {
      if (prodServer) await new Promise((resolve) => prodServer.close(resolve));
      process.env.NODE_ENV = prev;
    }
  });
});

describe('rate limiting (real express-rate-limit, MEDIUM security finding fix)', () => {
  const ENV_KEYS = ['RATE_LIMIT_INTERNAL_SPEC_MAX', 'RATE_LIMIT_INTERNAL_SPEC_WINDOW_MS'];
  const savedEnv = {};
  before(() => { for (const k of ENV_KEYS) savedEnv[k] = process.env[k]; });
  after(() => {
    for (const k of ENV_KEYS) {
      if (savedEnv[k] === undefined) delete process.env[k];
      else process.env[k] = savedEnv[k];
    }
  });

  // createInternalSpecLimiter() reads process.env at mount time (called inside
  // mountInternalSpec), so a low budget only needs to be set before mounting a
  // fresh app. The user id is driven by an X-Sim-User header (read before the
  // limiter runs) so a single server can exercise the per-user keyGenerator
  // across multiple simulated identities.
  async function buildLimitedServer(env) {
    for (const [k, v] of Object.entries(env)) process.env[k] = String(v);
    const app = express();
    app.use((req, _res, next) => {
      const userId = req.headers['x-sim-user'];
      req.user = userId ? { id: userId, role: 'user', email: `${userId}@x` } : { id: 'u-1', role: 'user', email: 'u@x' };
      next();
    });
    mountInternalSpec(app);
    const server = app.listen(0, '127.0.0.1');
    await new Promise((resolve) => server.on('listening', resolve));
    return server;
  }

  function get(port, path_, { user } = {}) {
    return new Promise((resolve, reject) => {
      const headers = user ? { 'X-Sim-User': user } : {};
      const req = http.request({ host: '127.0.0.1', port, path: path_, method: 'GET', headers }, (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => resolve({ status: res.statusCode, headers: res.headers }));
      });
      req.on('error', reject);
      req.end();
    });
  }

  it('throttles a logged-in caller after the configured per-user budget', async () => {
    const server = await buildLimitedServer({ RATE_LIMIT_INTERNAL_SPEC_MAX: '2', RATE_LIMIT_INTERNAL_SPEC_WINDOW_MS: '900000' });
    const { port } = server.address();
    try {
      const one = await get(port, '/api/openapi.json');
      const two = await get(port, '/api/openapi.json');
      const three = await get(port, '/api/openapi.json');
      assert.equal(one.status, 200);
      assert.equal(two.status, 200);
      assert.equal(three.status, 429, 'requests beyond the budget must be throttled');
    } finally {
      await new Promise((resolve) => server.close(resolve));
    }
  });

  it('budgets are per user — a second authenticated user is unaffected by the first user exhausting theirs', async () => {
    const server = await buildLimitedServer({ RATE_LIMIT_INTERNAL_SPEC_MAX: '1', RATE_LIMIT_INTERNAL_SPEC_WINDOW_MS: '900000' });
    const { port } = server.address();
    try {
      assert.equal((await get(port, '/api/openapi.json', { user: 'u-1' })).status, 200);
      assert.equal((await get(port, '/api/openapi.json', { user: 'u-1' })).status, 429, 'first user is throttled after their own budget');
      // A different authenticated user still has their own full budget.
      assert.equal((await get(port, '/api/openapi.json', { user: 'u-2' })).status, 200);
    } finally {
      await new Promise((resolve) => server.close(resolve));
    }
  });
});
