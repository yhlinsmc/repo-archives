// buildHierarchyPath runs the shared FE/BE fixture
// (src/fmb/lib/hierarchy/__fixtures__/hierarchy-path-cases.json — the FE
// vitest consumes the same file; edit cases there only). pathsEqual and
// findBlueprintIdsByPath are BE-only exports tested locally.
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const { buildHierarchyPath, pathsEqual, findBlueprintIdsByPath } = require('../../src/edge/lib/hierarchy-path');
const fixture = require('../../../src/fmb/lib/hierarchy/__fixtures__/hierarchy-path-cases.json');

describe('buildHierarchyPath (shared fixture)', () => {
  // Guards the loop below against a fixture emptied by a bad merge — zero
  // registered cases would otherwise pass vacuously.
  it('fixture case set is non-empty', () => {
    assert.ok(fixture.cases.length > 0);
  });
  for (const tc of fixture.cases) {
    it(tc.name, () => {
      assert.deepEqual(buildHierarchyPath(tc.nodes, tc.id), tc.expected);
    });
  }
});

describe('pathsEqual', () => {
  it('exact element-wise equality only', () => {
    assert.equal(pathsEqual(['a', 'b'], ['a', 'b']), true);
    assert.equal(pathsEqual(['a', 'b'], ['a', 'c']), false);
    assert.equal(pathsEqual(['a'], ['a', 'b']), false);
    assert.equal(pathsEqual(null, ['a']), false);
  });
});

describe('findBlueprintIdsByPath', () => {
  const nodes = [
    { id: 'r', parent_id: null, name: 'Root', node_type: 'folder' },
    { id: 'b1', parent_id: 'r', name: 'BP', node_type: 'blueprint' },
    { id: 'r2', parent_id: null, name: 'Root2', node_type: 'folder' },
    { id: 'b2', parent_id: 'r2', name: 'BP', node_type: 'blueprint' },
  ];
  it('unique lineage match returns one id', () => {
    assert.deepEqual(findBlueprintIdsByPath(nodes, ['Root', 'BP']), ['b1']);
  });
  it('only blueprint nodes are considered', () => {
    assert.deepEqual(findBlueprintIdsByPath(nodes, ['Root']), []);
  });
  it('empty/invalid target path returns no ids', () => {
    assert.deepEqual(findBlueprintIdsByPath(nodes, []), []);
    assert.deepEqual(findBlueprintIdsByPath(nodes, null), []);
  });
});
