const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const rcKey = require.resolve('../../src/infra/lib/remote-client');
const rc = require('../../src/infra/lib/remote-client');
let prepareResult; let resultCalls; let prepareCalls; let failResult = false;
rc.forwardToEdge = async ({ path, body }) => {
  if (path === '/edge/internal/connectors/prepare') { prepareCalls.push(body); return prepareResult; }
  if (path === '/edge/internal/connectors/result') {
    if (failResult) throw new Error('result down');
    resultCalls.push(body); return { status: 200, data: { ok: true, data: { recorded: true } }, contentType: 'application/json', headers: {} };
  }
  throw new Error('unexpected path ' + path);
};
require.cache[rcKey].exports = rc;

const chKey = require.resolve('../../src/shared/lib/connector-http');
const ch = require('../../src/shared/lib/connector-http');
let execBehavior = () => ({ upstream_status: 200, headers: { 'content-type': 'application/json' }, body: '{"ok":1}', truncated: false, duration_ms: 4 });
ch.executeRequest = (...a) => Promise.resolve().then(() => execBehavior(...a));
require.cache[chKey].exports = ch;

const guardKey = require.resolve('../../src/shared/lib/ssrf-guard');
const guard = require('../../src/shared/lib/ssrf-guard');
let blocked = false;
guard.isBlockedIp = () => blocked;
require.cache[guardKey].exports = guard;

const handler = require('../../src/infra/routes/connector-fetch');

let server; let baseUrl;
before(async () => {
  const app = express(); app.use(express.json());
  app.use((req, _res, next) => { req.user = { id: 'u1', role: 'user' }; next(); });
  handler(app);
  server = http.createServer(app); await new Promise((r) => server.listen(0, r));
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});
after(() => server && server.close());
beforeEach(() => { resultCalls = []; prepareCalls = []; blocked = false; failResult = false; execBehavior = () => ({ upstream_status: 200, headers: { 'content-type': 'application/json' }, body: '{"ok":1}', truncated: false, duration_ms: 4 }); });

async function fire(id, inputs) {
  const res = await fetch(`${baseUrl}/api/api-connectors/${id}/fetch`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ inputs }) });
  return { status: res.status, body: await res.json() };
}

async function fireWith(id, payload) {
  const res = await fetch(`${baseUrl}/api/api-connectors/${id}/fetch`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(payload) });
  return { status: res.status, body: await res.json() };
}

it('mode:edge passes the envelope straight through (no outbound, no result call)', async () => {
  prepareResult = { status: 200, data: { ok: true, data: { mode: 'edge', envelope: { upstream_status: 201, headers: {}, body: '{}', duration_ms: 3 } } }, contentType: 'application/json', headers: {} };
  const r = await fire('live', {});
  assert.equal(r.status, 200);
  assert.equal(r.body.data.upstream_status, 201);
  assert.equal(resultCalls.length, 0);
});

it('mode:infra executes outbound with the pinned ip, returns envelope, reports success', async () => {
  prepareResult = { status: 200, data: { ok: true, data: { mode: 'infra', dispatch_id: 'd1', prepared: { method: 'GET', url: 'http://svc.internal/x', headers: { Authorization: 'Bearer S' }, pinned_ip: '10.0.0.9', family: 4, timeout_ms: 10000, max_bytes: 5242880 } } }, contentType: 'application/json', headers: {} };
  const r = await fire('live', {});
  assert.equal(r.status, 200);
  assert.equal(r.body.data.upstream_status, 200);
  assert.equal(resultCalls.length, 1);
  assert.equal(resultCalls[0].success, true);
  assert.equal(resultCalls[0].dispatch_id, 'd1');
});

it('mode:infra re-validates the pinned ip and 422s a blocked one + reports failure', async () => {
  blocked = true;
  prepareResult = { status: 200, data: { ok: true, data: { mode: 'infra', dispatch_id: 'd2', prepared: { method: 'GET', url: 'http://svc.internal/x', headers: {}, pinned_ip: '169.254.169.254', family: 4, timeout_ms: 10000, max_bytes: 5242880 } } }, contentType: 'application/json', headers: {} };
  const r = await fire('live', {});
  assert.equal(r.status, 422);
  assert.equal(r.body.error.code, 'SSRF_BLOCKED');
  assert.equal(resultCalls[0].success, false);
});

it('mode:infra outbound failure maps the code + reports failure but still 5xx', async () => {
  execBehavior = () => { const e = new Error('timeout'); e.code = 'CONNECTOR_TIMEOUT'; throw e; };
  prepareResult = { status: 200, data: { ok: true, data: { mode: 'infra', dispatch_id: 'd3', prepared: { method: 'GET', url: 'http://svc.internal/x', headers: {}, pinned_ip: '10.0.0.9', family: 4, timeout_ms: 10000, max_bytes: 5242880 } } }, contentType: 'application/json', headers: {} };
  const r = await fire('live', {});
  assert.equal(r.status, 504);
  assert.equal(r.body.error.code, 'CONNECTOR_TIMEOUT');
  assert.equal(resultCalls[0].success, false);
  assert.equal(resultCalls[0].error_code, 'CONNECTOR_TIMEOUT');
});

it('edge prepare error (404) passes through unchanged', async () => {
  prepareResult = { status: 404, data: { ok: false, error: { code: 'NOT_FOUND', message: 'Connector not found' } }, contentType: 'application/json', headers: {} };
  const r = await fire('nope', {});
  assert.equal(r.status, 404);
  assert.equal(r.body.error.code, 'NOT_FOUND');
  assert.equal(resultCalls.length, 0);
});

it('502s a malformed prepare response (unknown mode)', async () => {
  prepareResult = { status: 200, data: { ok: true, data: { mode: 'unknown' } }, contentType: 'application/json', headers: {} };
  const r = await fire('live', {});
  assert.equal(r.status, 502);
  assert.equal(r.body.error.code, 'INTERNAL_ERROR');
  assert.equal(resultCalls.length, 0);
});

it('502s an infra prepare missing pin fields', async () => {
  prepareResult = { status: 200, data: { ok: true, data: { mode: 'infra', dispatch_id: 'd9', prepared: { method: 'GET', url: 'http://svc.internal/x', headers: {} } } }, contentType: 'application/json', headers: {} };
  const r = await fire('live', {});
  assert.equal(r.status, 502);
  assert.equal(r.body.error.code, 'INTERNAL_ERROR');
});

it('still returns the envelope to the client when the result report fails (best-effort audit)', async () => {
  failResult = true;
  prepareResult = { status: 200, data: { ok: true, data: { mode: 'infra', dispatch_id: 'd8', prepared: { method: 'GET', url: 'http://svc.internal/x', headers: {}, pinned_ip: '10.0.0.9', family: 4, timeout_ms: 10000, max_bytes: 5242880 } } }, contentType: 'application/json', headers: {} };
  const r = await fire('live', {});
  assert.equal(r.status, 200);
  assert.equal(r.body.data.upstream_status, 200);
});

it('forwards test:true to /prepare', async () => {
  prepareResult = { status: 200, data: { ok: true, data: { mode: 'edge', test: true, envelope: { upstream_status: 200, headers: {}, body: '{}', truncated: false, duration_ms: 1 } } }, contentType: 'application/json', headers: {} };
  const r = await fireWith('c1', { inputs: { a: '1' }, test: true });
  assert.equal(r.status, 200);
  assert.equal(prepareCalls.length, 1);
  assert.equal(prepareCalls[0].test, true);
  assert.deepEqual(prepareCalls[0].inputs, { a: '1' });
});

it('infra-mode reports the edge-decided test flag to /result', async () => {
  prepareResult = { status: 200, data: { ok: true, data: { mode: 'infra', test: true, dispatch_id: 'd1', prepared: { method: 'GET', url: 'http://svc.internal/x', headers: {}, body: null, pinned_ip: '10.0.0.9', family: 4, timeout_ms: 10000, max_bytes: 5242880 } } }, contentType: 'application/json', headers: {} };
  execBehavior = () => ({ upstream_status: 200, headers: {}, body: '{}', truncated: false, duration_ms: 2 });
  const r = await fireWith('c1', { inputs: {}, test: true });
  assert.equal(r.status, 200);
  assert.equal(resultCalls.length, 1);
  assert.equal(resultCalls[0].test, true);
});

it('non-admin test:true — edge decides test:false, infra reports test:false to /result', async () => {
  // Edge ignored the client flag (non-admin) and returned an infra-mode prepare with test:false.
  prepareResult = { status: 200, data: { ok: true, data: {
    mode: 'infra', test: false, dispatch_id: 'd99',
    prepared: { method: 'GET', url: 'http://svc.internal/x', headers: {},
      body: null, pinned_ip: '10.0.0.9', family: 4,
      timeout_ms: 10000, max_bytes: 5242880 }
  } }, contentType: 'application/json', headers: {} };
  execBehavior = () => ({ upstream_status: 200, headers: {}, body: '{}', truncated: false, duration_ms: 2 });
  const r = await fireWith('c1', { inputs: {}, test: true });
  assert.equal(r.status, 200);
  assert.equal(resultCalls.length, 1);
  assert.equal(resultCalls[0].test, false);
});

it('fetch forwards a 422 DECRYPT_AUTH_FAIL from edge /prepare unchanged', async () => {
  prepareResult = {
    status: 422,
    data: {
      data: null,
      error: {
        code: 'DECRYPT_AUTH_FAIL',
        message: "This connector's secret was encrypted with a different SETTINGS_ENCRYPTION_KEY (likely carried by a data sync from another environment). Edit the connector and re-enter the credential.",
      },
    },
    contentType: 'application/json',
    headers: {},
  };
  const r = await fire('c1', { inputs: {} });
  assert.strictEqual(r.status, 422);
  assert.strictEqual(r.body.error.code, 'DECRYPT_AUTH_FAIL');
  assert.strictEqual(resultCalls.length, 0);
});

it('infra pinnedLookup honors all:true (array form) and all:false (single-arg)', async () => {
  prepareResult = { status: 200, data: { ok: true, data: {
    mode: 'infra', test: false, dispatch_id: 'dLK',
    prepared: { method: 'GET', url: 'http://svc.internal/x', headers: {}, body: null,
      pinned_ip: '10.0.0.9', family: 4, timeout_ms: 10000, max_bytes: 5242880 }
  } }, contentType: 'application/json', headers: {} };
  let capturedLookup = null;
  execBehavior = async (_resolved, opts) => { capturedLookup = opts.lookup; return { upstream_status: 200, headers: {}, body: '{}', truncated: false, duration_ms: 1 }; };
  const r = await fireWith('c1', { inputs: {} });
  assert.equal(r.status, 200);
  assert.equal(typeof capturedLookup, 'function');
  // all:true — Node autoSelectFamily expects an array of { address, family }
  await new Promise((resolve) => capturedLookup('svc.internal', { all: true }, (err, result) => {
    assert.equal(err, null);
    assert.deepEqual(result, [{ address: '10.0.0.9', family: 4 }]);
    resolve();
  }));
  // all:false (classic form) — expects (null, address, family) positional args
  await new Promise((resolve) => capturedLookup('svc.internal', { all: false }, (err, address, family) => {
    assert.equal(err, null);
    assert.equal(address, '10.0.0.9');
    assert.equal(family, 4);
    resolve();
  }));
});
