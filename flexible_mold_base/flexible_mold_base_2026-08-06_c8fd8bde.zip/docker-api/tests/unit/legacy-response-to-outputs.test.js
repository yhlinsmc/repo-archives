// Unit coverage for the legacy response_config → outputs[] converter and its
// malformed-row guard. A hand-edited or partially-migrated row can carry a
// mapping with no target or a lookup with no cell; the converter must skip such
// a row rather than emit a garbage output or throw on a missing property.
const { it, describe } = require('node:test');
const assert = require('node:assert/strict');

const {
  legacyResponseToOutputs,
  normalizeResponseOutputs,
} = require('../../src/edge/lib/legacy-response-to-outputs');

describe('legacyResponseToOutputs', () => {
  it('converts a scalar mapping to value → field', () => {
    const outs = legacyResponseToOutputs({ mappings: [{ path: 'main.temp', field_key: 'f' }] });
    assert.equal(outs.length, 1);
    assert.deepEqual(outs[0].from, { mode: 'value', path: 'main.temp' });
    assert.deepEqual(outs[0].to, { mode: 'field', field_key: 'f' });
  });

  it('converts a cell mapping to value → cell', () => {
    const outs = legacyResponseToOutputs({ mappings: [{ path: 'p', cell: { table_key: 't', column_key: 'c' } }] });
    assert.deepEqual(outs[0].to, { mode: 'cell', table_key: 't', column_key: 'c', row: 0 });
  });

  it('converts field- and cell-target lookups', () => {
    const field = legacyResponseToOutputs({ lookups: [{
      list_path: 'd', filter_column: 'k', filter_value: { kind: 'literal', value: 'v' },
      extract_column: 'ip', target: { kind: 'field', field_key: 'gw' },
    }] });
    assert.deepEqual(field[0].to, { mode: 'field', field_key: 'gw', extract: 'ip', reduce: 'pick' });
    const cell = legacyResponseToOutputs({ lookups: [{
      list_path: 'd', filter_column: 'k', filter_value: { kind: 'literal', value: 'v' },
      extract_column: 'x', target: { kind: 'cell', cell: { table_key: 't', column_key: 'c', row: 3 } },
    }] });
    assert.deepEqual(cell[0].to, { mode: 'cell', table_key: 't', column_key: 'c', row: 3, extract: 'x', reduce: 'pick' });
  });

  it('skips a malformed mapping with neither cell nor field_key', () => {
    const outs = legacyResponseToOutputs({ mappings: [
      { path: 'orphan' },
      { path: 'ok', field_key: 'f' },
    ] });
    assert.equal(outs.length, 1);
    assert.deepEqual(outs[0].to, { mode: 'field', field_key: 'f' });
  });

  it('skips a lookup with a missing target without throwing', () => {
    assert.doesNotThrow(() => legacyResponseToOutputs({ lookups: [{ list_path: 'd', filter_column: 'k' }] }));
    const outs = legacyResponseToOutputs({ lookups: [{ list_path: 'd', filter_column: 'k' }] });
    assert.equal(outs.length, 0);
  });

  it('skips a cell-target lookup with no cell without throwing', () => {
    const outs = legacyResponseToOutputs({ lookups: [{
      list_path: 'd', filter_column: 'k', filter_value: { kind: 'literal', value: 'v' },
      extract_column: 'x', target: { kind: 'cell' },
    }] });
    assert.equal(outs.length, 0);
  });

  it('skips a target with a cell object but a missing/unknown kind (FE/BE lockstep)', () => {
    const outs = legacyResponseToOutputs({ lookups: [{
      list_path: 'd', filter_column: 'k', filter_value: { kind: 'literal', value: 'v' },
      extract_column: 'x', target: { cell: { table_key: 't', column_key: 'c', row: 0 } },
    }] });
    assert.equal(outs.length, 0);
  });

  it('normalizeResponseOutputs prefers stored outputs[] over legacy', () => {
    assert.deepEqual(normalizeResponseOutputs({ outputs: [{ id: 'x' }], mappings: [{ path: 'p', field_key: 'f' }] }), [{ id: 'x' }]);
    assert.deepEqual(normalizeResponseOutputs({}), []);
  });
});
