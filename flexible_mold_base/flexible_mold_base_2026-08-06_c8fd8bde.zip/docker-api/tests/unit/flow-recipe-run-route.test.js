// docker-api/tests/unit/flow-recipe-run-route.test.js
//
// Unit tests for POST /api/flow-recipes/:id/run (infra server-run orchestrator).
// Harness mirrors flow-dispatch-step.test.js: mocks injected via require.cache
// before requiring the module under test; each test resets mutable mock state.
//
// Run:
//   cd docker-api && NODE_ENV=test node --test tests/unit/flow-recipe-run-route.test.js
const { test } = require('node:test');
const assert = require('node:assert');
const express = require('express');

// ── Mutable mock state — reset per test ──────────────────────────────────────
const edgeCalls = [];
const dispatchCalls = [];
let forwardToEdgeImpl = async () => ({ status: 200, data: { ok: true } });
let dispatchOneStepImpl = async () => ({
  ok: true, status: 200,
  envelope: { upstream_status: 200, body: '{}' },
});

// ── Cache injection (before any require of the module under test) ─────────────
require.cache[require.resolve('../../src/infra/lib/remote-client')] = {
  exports: {
    forwardToEdge: async (opts) => {
      edgeCalls.push(opts);
      return forwardToEdgeImpl(opts);
    },
    passthroughResponse: (res, result) => {
      // Simplified: reproduce JSON passthrough behaviour only (all mocked responses are JSON).
      res.status(result.status).json(result.data);
    },
  },
};

require.cache[require.resolve('../../src/infra/lib/flow-dispatch-step')] = {
  exports: {
    dispatchOneStep: async (opts) => {
      dispatchCalls.push(opts);
      return dispatchOneStepImpl(opts);
    },
  },
};

require.cache[require.resolve('../../src/shared/lib/logger')] = {
  exports: { logger: { child: () => ({ warn: () => {}, error: () => {}, info: () => {} }) } },
};

const mountFlowRecipeRun = require('../../src/infra/routes/flow-recipe-run');

// ── Test helpers ──────────────────────────────────────────────────────────────

function makeApp({ user } = {}) {
  const a = express();
  a.use(express.json());
  if (user) {
    a.use((req, _res, next) => { req.user = user; req.id = 'test-req-id'; next(); });
  }
  mountFlowRecipeRun(a);
  return a;
}

async function post(app, path, body) {
  const server = app.listen(0);
  const port = server.address().port;
  try {
    const res = await fetch(`http://127.0.0.1:${port}${path}`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(body),
    });
    const json = await res.json();
    return { status: res.status, body: json };
  } finally {
    server.close();
  }
}

// ── Shared mock fixtures ──────────────────────────────────────────────────────

const RUN_BEGIN_OK = {
  status: 200,
  data: {
    data: {
      run_id: 'run1',
      steps: [{ id: 's1', sequence: 1 }],
      serialized_payload: '{"a":1}',
      link_extract: { path: 'url' },
      external_id_extract: { path: 'id' },
    },
  },
};

const RUN_FINALIZE_SUCCESS = {
  status: 200,
  data: {
    data: { runId: 'run1', status: 'success', link: 'https://flow/x', externalId: 'F-9' },
  },
};

const RUN_FINALIZE_FAILED = {
  status: 200,
  data: {
    data: { runId: 'run1', status: 'failed', link: null, externalId: null },
  },
};

// ── Tests ─────────────────────────────────────────────────────────────────────

test('(a) plain user + approved recipe: run-begin 200 → step dispatched ok (2xx envelope) → run-finalize success → 200 with runId/status/link/externalId', async () => {
  edgeCalls.length = 0;
  dispatchCalls.length = 0;

  forwardToEdgeImpl = async (opts) => {
    if (opts.path.endsWith('/run-begin')) return RUN_BEGIN_OK;
    if (opts.path.endsWith('/run-finalize')) return RUN_FINALIZE_SUCCESS;
    return { status: 200, data: { ok: true } };
  };
  dispatchOneStepImpl = async () => ({
    ok: true, status: 200,
    envelope: { upstream_status: 200, body: '{"url":"https://flow/x","id":"F-9"}' },
  });

  const app = makeApp({ user: { id: 'u-plain', role: 'user' } });
  const r = await post(app, '/api/flow-recipes/r1/run', {
    payload: { a: 1 },
    output_snapshot: '{}',
    template_id: 'tpl1',
    blueprint_id: 'bp1',
    mode: 'create',
  });

  assert.equal(r.status, 200, `expected 200, got ${r.status}: ${JSON.stringify(r.body)}`);
  // input_snapshot_notice is present on every response, null when there is
  // nothing to say. Always-present rather than conditional so a caller reads one
  // shape; the exact-shape assertion is kept exact for that reason.
  assert.deepEqual(r.body.data, {
    runId: 'run1', status: 'success', link: 'https://flow/x', externalId: 'F-9',
    input_snapshot_notice: null,
  });

  // run-begin must have been called with recipe_id from URL param
  const beginCall = edgeCalls.find((c) => c.path.endsWith('/run-begin'));
  assert.ok(beginCall, 'run-begin must be called');
  assert.equal(beginCall.body.recipe_id, 'r1');

  // dispatchOneStep must have been called once for the single step
  assert.equal(dispatchCalls.length, 1, 'dispatchOneStep must be called exactly once');
  assert.equal(dispatchCalls[0].stepId, 's1');
  assert.equal(dispatchCalls[0].runId, 'run1');
  assert.equal(dispatchCalls[0].test, false);

  // run-finalize must have been called with ok:true
  const finalizeCall = edgeCalls.find((c) => c.path.endsWith('/run-finalize'));
  assert.ok(finalizeCall, 'run-finalize must be called');
  assert.equal(finalizeCall.body.ok, true);
  assert.equal(finalizeCall.body.run_id, 'run1');
  assert.equal(finalizeCall.body.recipe_id, 'r1');
});

test('(b) run-begin gate rejection (422 RECIPE_NOT_APPROVED) → passthrough 422, dispatchOneStep never called', async () => {
  edgeCalls.length = 0;
  dispatchCalls.length = 0;

  forwardToEdgeImpl = async (opts) => {
    if (opts.path.endsWith('/run-begin')) {
      return {
        status: 422,
        data: { error: { code: 'RECIPE_NOT_APPROVED', message: 'Recipe is awaiting admin approval' } },
      };
    }
    return { status: 200, data: { ok: true } };
  };
  dispatchOneStepImpl = async () => {
    throw new Error('dispatchOneStep must NOT be called on run-begin rejection');
  };

  const app = makeApp({ user: { id: 'u', role: 'user' } });
  const r = await post(app, '/api/flow-recipes/r1/run', { payload: {} });

  assert.equal(r.status, 422, `expected 422 passthrough, got ${r.status}`);
  assert.equal(dispatchCalls.length, 0, 'dispatchOneStep must NOT be called when run-begin fails');

  // run-finalize must NOT be called either
  const finalizeCall = edgeCalls.find((c) => c.path.endsWith('/run-finalize'));
  assert.equal(finalizeCall, undefined, 'run-finalize must NOT be called on gate rejection');
});

test('(c) step dispatch returns ok:false → run-finalize called with ok:false → route returns failed response', async () => {
  edgeCalls.length = 0;
  dispatchCalls.length = 0;

  forwardToEdgeImpl = async (opts) => {
    if (opts.path.endsWith('/run-begin')) return RUN_BEGIN_OK;
    if (opts.path.endsWith('/run-finalize')) return RUN_FINALIZE_FAILED;
    return { status: 200, data: { ok: true } };
  };
  dispatchOneStepImpl = async () => ({
    ok: false, status: 502,
    errorCode: 'CONNECTOR_UNREACHABLE',
    message: 'Connection refused',
  });

  const app = makeApp({ user: { id: 'u', role: 'user' } });
  const r = await post(app, '/api/flow-recipes/r1/run', { payload: { q: 1 } });

  // route should still return 200 (finalize itself succeeded)
  assert.equal(r.status, 200, `expected 200 from finalize path, got ${r.status}`);
  assert.equal(r.body.data.status, 'failed', 'data.status must be failed');

  // dispatchOneStep must have been called once (for the step that failed)
  assert.equal(dispatchCalls.length, 1, 'dispatchOneStep must be called once');

  // run-finalize must be called with ok:false
  const finalizeCall = edgeCalls.find((c) => c.path.endsWith('/run-finalize'));
  assert.ok(finalizeCall, 'run-finalize must be called even on step failure');
  assert.equal(finalizeCall.body.ok, false, 'finalize must receive ok:false');
  assert.equal(finalizeCall.body.run_id, 'run1');
  assert.equal(finalizeCall.body.recipe_id, 'r1');
  assert.ok(
    typeof finalizeCall.body.error_summary === 'string' && finalizeCall.body.error_summary.length > 0,
    'finalize must receive a non-empty error_summary on step failure',
  );
});

test('(d) anonymous caller (no req.user) → 401 Unauthorized, no edge calls', async () => {
  edgeCalls.length = 0;
  dispatchCalls.length = 0;

  forwardToEdgeImpl = async () => {
    throw new Error('forwardToEdge must NOT be called for an anonymous request');
  };
  dispatchOneStepImpl = async () => {
    throw new Error('dispatchOneStep must NOT be called for an anonymous request');
  };

  // makeApp without user → req.user is never set
  const app = makeApp();
  const r = await post(app, '/api/flow-recipes/r1/run', { payload: {} });

  assert.equal(r.status, 401, `expected 401, got ${r.status}`);
  assert.equal(edgeCalls.length, 0, 'no edge calls must be made for anonymous requests');
  assert.equal(dispatchCalls.length, 0, 'no dispatch calls must be made for anonymous requests');
});

test('(e) multi-step recipe: step 1 fails → step 2 NEVER dispatched, run-finalize called with ok:false', async () => {
  edgeCalls.length = 0;
  dispatchCalls.length = 0;

  // run-begin returns a 2-step recipe.
  forwardToEdgeImpl = async (opts) => {
    if (opts.path.endsWith('/run-begin')) {
      return {
        status: 200,
        data: {
          data: {
            run_id: 'run1',
            steps: [{ id: 's1', sequence: 1 }, { id: 's2', sequence: 2 }],
            serialized_payload: '{"a":1}',
            link_extract: { path: 'url' },
            external_id_extract: { path: 'id' },
          },
        },
      };
    }
    if (opts.path.endsWith('/run-finalize')) return RUN_FINALIZE_FAILED;
    return { status: 200, data: { ok: true } };
  };
  // First (and only) dispatch returns ok:false → the loop must break before step 2.
  dispatchOneStepImpl = async () => ({
    ok: false, status: 502,
    errorCode: 'CONNECTOR_UNREACHABLE',
    message: 'Connection refused',
  });

  const app = makeApp({ user: { id: 'u', role: 'user' } });
  const r = await post(app, '/api/flow-recipes/r1/run', { payload: { a: 1 } });

  // Only step 1 dispatched; step 2 must never run (break-on-first-failure).
  assert.equal(dispatchCalls.length, 1, 'step 2 must NOT be dispatched after step 1 fails');
  assert.equal(dispatchCalls[0].stepId, 's1', 'the dispatched step must be step 1');

  const finalizeCall = edgeCalls.find((c) => c.path.endsWith('/run-finalize'));
  assert.ok(finalizeCall, 'run-finalize must be called after a step failure');
  assert.equal(finalizeCall.body.ok, false, 'finalize must receive ok:false');
  assert.equal(r.body.data.status, 'failed');
});

test('(g) step 1 transport-ok but upstream_status:500 → step 2 NOT dispatched, step_results[0] ok:false, run finalizes ok:false', async () => {
  edgeCalls.length = 0;
  dispatchCalls.length = 0;

  // run-begin returns a 2-step recipe.
  forwardToEdgeImpl = async (opts) => {
    if (opts.path.endsWith('/run-begin')) {
      return {
        status: 200,
        data: {
          data: {
            run_id: 'run1',
            steps: [{ id: 's1', sequence: 1 }, { id: 's2', sequence: 2 }],
            serialized_payload: '{"a":1}',
          },
        },
      };
    }
    if (opts.path.endsWith('/run-finalize')) return RUN_FINALIZE_FAILED;
    return { status: 200, data: { ok: true } };
  };
  // Step 1: transport succeeds (ok:true) but upstream service returns 500.
  dispatchOneStepImpl = async () => ({
    ok: true,
    status: 200,
    envelope: { upstream_status: 500, body: 'Internal Server Error' },
  });

  const app = makeApp({ user: { id: 'u', role: 'user' } });
  const r = await post(app, '/api/flow-recipes/r1/run', { payload: { a: 1 } });

  // Only step 1 dispatched — loop must stop on non-2xx upstream.
  assert.equal(dispatchCalls.length, 1, 'step 2 must NOT be dispatched when step 1 upstream_status is 500');
  assert.equal(dispatchCalls[0].stepId, 's1', 'only step 1 must be dispatched');

  // run-finalize must be called with ok:false.
  const finalizeCall = edgeCalls.find((c) => c.path.endsWith('/run-finalize'));
  assert.ok(finalizeCall, 'run-finalize must be called after a non-2xx step');
  assert.equal(finalizeCall.body.ok, false, 'finalize must receive ok:false when step upstream_status is 500');

  // step_results must record step 1 as ok:false with its upstream_status.
  const parsedStepResults = JSON.parse(finalizeCall.body.step_results);
  assert.equal(parsedStepResults.length, 1, 'step_results must contain exactly one entry');
  assert.equal(parsedStepResults[0].step_id, 's1', 'step_results must contain step 1');
  assert.equal(parsedStepResults[0].ok, false, 'step 1 must be recorded ok:false');
  assert.equal(parsedStepResults[0].upstream_status, 500, 'step 1 must record the actual 500 upstream_status');

  // overall run must be failed.
  assert.equal(r.body.data.status, 'failed', 'run data.status must be failed');
});

test('(f) empty-steps guard: steps:[] → run-finalize ok:false, dispatchOneStep never called', async () => {
  edgeCalls.length = 0;
  dispatchCalls.length = 0;

  // run-begin succeeds but the recipe has zero steps.
  forwardToEdgeImpl = async (opts) => {
    if (opts.path.endsWith('/run-begin')) {
      return {
        status: 200,
        data: {
          data: {
            run_id: 'run1',
            steps: [],
            serialized_payload: '{"a":1}',
            link_extract: { path: 'url' },
            external_id_extract: { path: 'id' },
          },
        },
      };
    }
    if (opts.path.endsWith('/run-finalize')) return RUN_FINALIZE_FAILED;
    return { status: 200, data: { ok: true } };
  };
  dispatchOneStepImpl = async () => {
    throw new Error('dispatchOneStep must NOT be called when the recipe has no steps');
  };

  const app = makeApp({ user: { id: 'u', role: 'user' } });
  const r = await post(app, '/api/flow-recipes/r1/run', { payload: { a: 1 } });

  // A recipe with no steps must NOT silently report success.
  assert.equal(dispatchCalls.length, 0, 'no step dispatch for an empty-steps recipe');

  const finalizeCall = edgeCalls.find((c) => c.path.endsWith('/run-finalize'));
  assert.ok(finalizeCall, 'run-finalize must be called to mark the run failed');
  assert.equal(finalizeCall.body.ok, false, 'empty-steps run must finalize with ok:false');
  assert.equal(
    finalizeCall.body.error_summary, 'Recipe has no steps to run',
    'empty-steps run must carry an explanatory error_summary',
  );
  assert.equal(r.body.data.status, 'failed');
});

// ── input_snapshot relay: infra carries it to edge on BOTH orchestration paths ─

test('(i) the one-shot orchestrator relays input_snapshot to edge run-begin', async () => {
  edgeCalls.length = 0;
  dispatchCalls.length = 0;
  forwardToEdgeImpl = async (opts) => {
    if (opts.path.endsWith('/run-begin')) return RUN_BEGIN_OK;
    return RUN_FINALIZE_SUCCESS;
  };
  dispatchOneStepImpl = async () => ({ ok: true, status: 200, envelope: { upstream_status: 200, body: '{}' } });

  const snapshot = JSON.stringify({ entered: { site: 'north' }, computed: { total: '42' } });
  const app = makeApp({ user: { id: 'u1', role: 'user' } });
  const res = await post(app, '/api/flow-recipes/r1/run', {
    payload: { a: 1 },
    output_snapshot: '{"o":1}',
    input_snapshot: snapshot,
    template_id: 'tpl1',
    blueprint_id: 'bp1',
  });

  assert.equal(res.status, 200);
  const beginCall = edgeCalls.find((c) => c.path.endsWith('/run-begin'));
  assert.ok(beginCall, 'run-begin must be called');
  assert.equal(beginCall.body.input_snapshot, snapshot,
    'infra must forward input_snapshot verbatim, or the one-shot path records nothing');
});

test('(j) the browser-chain begin endpoint relays input_snapshot to edge run-begin', async () => {
  edgeCalls.length = 0;
  forwardToEdgeImpl = async () => RUN_BEGIN_OK;

  const snapshot = JSON.stringify({ entered: { site: 'south' }, computed: {} });
  const app = makeApp({ user: { id: 'u1', role: 'user' } });
  const res = await post(app, '/api/flow-recipes/r1/run-begin', {
    payload: { a: 1 },
    output_snapshot: '{"o":1}',
    input_snapshot: snapshot,
    template_id: 'tpl1',
  });

  assert.equal(res.status, 200);
  const beginCall = edgeCalls.find((c) => c.path.endsWith('/run-begin'));
  assert.ok(beginCall, 'run-begin must be called');
  assert.equal(beginCall.body.client_orchestration, true, 'fixture must be the browser-chain endpoint');
  assert.equal(beginCall.body.input_snapshot, snapshot,
    'infra must forward input_snapshot on the chain path too');
});

test('(k) the one-shot orchestrator carries the dropped-capture notice back to the caller', async () => {
  // Edge creates the run and reports that its capture was dropped. Infra
  // consumes the begin response internally on this path, so without an explicit
  // relay the operator would be told nothing at all.
  edgeCalls.length = 0;
  dispatchCalls.length = 0;
  const NOTICE = 'The run was dispatched, but the entered values were too large to record with it (128 KB; the limit is 64 KB). Shorten the longest answers and run again to record them.';
  forwardToEdgeImpl = async (opts) => {
    if (opts.path.endsWith('/run-begin')) {
      return { status: 200, data: { data: { ...RUN_BEGIN_OK.data.data, input_snapshot_notice: NOTICE } } };
    }
    return RUN_FINALIZE_SUCCESS;
  };
  dispatchOneStepImpl = async () => ({ ok: true, status: 200, envelope: { upstream_status: 200, body: '{}' } });

  const app = makeApp({ user: { id: 'u1', role: 'user' } });
  const res = await post(app, '/api/flow-recipes/r1/run', { payload: { a: 1 }, template_id: 'tpl1' });

  assert.equal(res.status, 200);
  assert.equal(res.body.data.input_snapshot_notice, NOTICE);
  assert.equal(res.body.data.status, 'success', 'the run itself still succeeded');
});

test('(l) a recipe with no steps still carries the notice on its failed-run response', async () => {
  // The empty-steps guard answers from a different return point; a notice
  // attached to only one of the two would be lost on whichever path was missed.
  edgeCalls.length = 0;
  const NOTICE = 'The run was dispatched, but the entered values were too large to record with it (128 KB; the limit is 64 KB). Shorten the longest answers and run again to record them.';
  forwardToEdgeImpl = async (opts) => {
    if (opts.path.endsWith('/run-begin')) {
      return { status: 200, data: { data: { run_id: 'run1', steps: [], serialized_payload: '{}', input_snapshot_notice: NOTICE } } };
    }
    return RUN_FINALIZE_FAILED;
  };

  const app = makeApp({ user: { id: 'u1', role: 'user' } });
  const res = await post(app, '/api/flow-recipes/r1/run', { payload: { a: 1 } });

  assert.equal(res.status, 200);
  assert.equal(res.body.data.input_snapshot_notice, NOTICE);
});
