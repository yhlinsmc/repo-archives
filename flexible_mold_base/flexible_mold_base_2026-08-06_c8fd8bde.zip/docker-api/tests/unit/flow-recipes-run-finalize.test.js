/**
 * flow-recipes-run-finalize.test.js
 *
 * Tests for POST /edge/internal/flow-recipes/run-finalize.
 * Mirrors the run-begin test harness: mocked pool injected via require.cache
 * before router require, single live server per suite.
 *
 * Covers:
 *   (a) ok=true + 2xx → success, extracts link/externalId from DB specs, writes cache
 *   (b) ok=false → failed + null link + null externalId + no cache write
 *   (c) non-2xx upstream_status → failed even if ok=true
 *   (d) cache write-back failure still returns 200 success (best-effort)
 *   (e) extract specs come from DB, not from request body (SECURITY invariant)
 *   (f) cache UPDATE is owner-scoped; 0-row no-op still finalizes success (IDOR guard)
 *   (g) step_results sent as JSON string are parsed + masked before persisting
 *
 * Run:
 *   cd docker-api && NODE_ENV=test node --test tests/unit/flow-recipes-run-finalize.test.js
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../src/edge/db');

// ── Mock state (reset in beforeEach) ─────────────────────────────────────────
let recipeRow = null;       // returned by recipe SELECT
let runRow = null;          // returned by run SELECT
let lastRunUpdate = null;   // captured UPDATE params for flow_recipe_runs
let runUpdateCount = 0;
let cacheUpdateCount = 0;
let lastCacheUpdate = null; // captured UPDATE params for user_templates
let grantsTablePresent = false; // does this database carry delegated_grants?
let shouldCacheThrow = false; // set true to simulate cache write-back failure
let runUpdateAffectedRows = 1; // simulate the replay-guard precondition matching 0 rows
let cacheUpdateAffectedRows = 1; // simulate owner-scoped WHERE matching 0 rows
let currentUserId = 'u1';
let currentRole = 'admin';
let stepCodeRows = [];          // returned by the step step_type/before/after SELECT

const conn = {
  async query(sql, params) {
    // Step code SELECT (requiresClient derivation) — match before the generic
    // recipe SELECT since both could otherwise be ambiguous.
    if (/FROM `fmb_flow_recipe_steps`/.test(sql)) {
      return stepCodeRows;
    }
    // Recipe SELECT
    if (/FROM `fmb_flow_recipes`/.test(sql) && /WHERE id = \?/.test(sql)) {
      return recipeRow ? [recipeRow] : [];
    }
    // Run SELECT (get template_id + actor_id + recipe_id)
    if (/FROM `fmb_flow_recipe_runs`/.test(sql) && /WHERE id = \?/.test(sql)) {
      return runRow ? [runRow] : [];
    }
    // Run UPDATE (finalize)
    if (/UPDATE `fmb_flow_recipe_runs`/i.test(sql)) {
      runUpdateCount++;
      // Capture column→value from the SET clause generically
      // We'll record just the raw params array and sql for assertion
      lastRunUpdate = { sql, params };
      return { affectedRows: runUpdateAffectedRows };
    }
    // Availability probe for the grants table. Absent unless a test says
    // otherwise, which keeps every case written before delegation existed on
    // the statement it was written against.
    if (/information_schema\.TABLES/i.test(sql)) {
      const [name] = params || [];
      return grantsTablePresent && String(name).endsWith('delegated_grants') ? [{ 1: 1 }] : [];
    }
    // User_templates cache write-back UPDATE
    if (/UPDATE `fmb_user_templates`/i.test(sql)) {
      cacheUpdateCount++;
      if (shouldCacheThrow) throw new Error('cache write-back simulated failure');
      lastCacheUpdate = { sql, params };
      return { affectedRows: cacheUpdateAffectedRows };
    }
    return [];
  },
  release() {},
};

// Inject mock DB before requiring the router so no real DB connection fires.
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: {
    pool: {
      ro: { getConnection: async () => conn },
      rw: { getConnection: async () => conn },
    },
    t: (name) => `fmb_${name}`,
  },
};

const router = require('../../src/edge/routes/internal/flow-recipes-run');
const { _resetGrantsTableCache } = require('../../src/edge/lib/delegated-grants');

let server; let baseUrl;
before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => {
    req.user = { id: currentUserId, role: currentRole };
    next();
  });
  app.use('/edge/internal/flow-recipes', router);
  server = http.createServer(app);
  await new Promise((r) => server.listen(0, r));
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});
after(() => server && server.close());

beforeEach(() => {
  recipeRow = null;
  runRow = null;
  lastRunUpdate = null;
  runUpdateCount = 0;
  cacheUpdateCount = 0;
  lastCacheUpdate = null;
  shouldCacheThrow = false;
  runUpdateAffectedRows = 1;
  cacheUpdateAffectedRows = 1;
  currentUserId = 'u1';
  currentRole = 'admin';
  stepCodeRows = [];
  grantsTablePresent = false;
  _resetGrantsTableCache();
});

// ── Helpers ───────────────────────────────────────────────────────────────────

function makeRecipe(overrides = {}) {
  return {
    id: 'r1',
    // link_extract and external_id_extract are stored as JSON strings in the DB;
    // mapRowsFromDb will parse them to objects.
    link_extract: JSON.stringify({ path: 'url' }),
    external_id_extract: JSON.stringify({ path: 'id' }),
    ...overrides,
  };
}

function makeRun(overrides = {}) {
  return {
    id: 'run1',
    recipe_id: 'r1',
    template_id: 'tpl1',
    actor_id: 'u1',
    ...overrides,
  };
}

async function postFinalize(body) {
  const res = await fetch(`${baseUrl}/edge/internal/flow-recipes/run-finalize`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
  });
  return { status: res.status, body: await res.json() };
}

// ── (a) success path: ok=true + 2xx → finalize success + extract + cache ──────

describe('run-finalize success path', () => {
  it('returns 200 with status=success, extracts link and externalId from DB specs', async () => {
    recipeRow = makeRecipe();
    runRow = makeRun();

    const upstreamBody = JSON.stringify({ url: 'https://flow/RUN1', id: 'EXT-99' });
    const r = await postFinalize({
      run_id: 'run1',
      recipe_id: 'r1',
      ok: true,
      upstream_status: 200,
      body: upstreamBody,
      step_results: [{ step_id: 's1', status: 'ok' }],
    });

    assert.equal(r.status, 200, `Expected 200, got ${r.status}: ${JSON.stringify(r.body)}`);
    assert.equal(r.body.data.status, 'success');
    assert.equal(r.body.data.link, 'https://flow/RUN1');
    assert.equal(r.body.data.externalId, 'EXT-99');
    assert.equal(r.body.data.runId, 'run1');
  });

  it('issues a run UPDATE with status=success and result_link/external_flow_id', async () => {
    recipeRow = makeRecipe();
    runRow = makeRun();

    const upstreamBody = JSON.stringify({ url: 'https://flow/RUN2', id: 'EXT-100' });
    await postFinalize({
      run_id: 'run1',
      recipe_id: 'r1',
      ok: true,
      upstream_status: 201,
      body: upstreamBody,
    });

    assert.equal(runUpdateCount, 1, 'exactly one run UPDATE must be issued');
    assert.ok(lastRunUpdate.sql, 'UPDATE sql must be captured');
    // Verify the UPDATE sets the right status
    assert.ok(/status/.test(lastRunUpdate.sql), 'UPDATE must reference status column');
    // result_link and external_flow_id must be in the UPDATE
    assert.ok(
      /result_link/.test(lastRunUpdate.sql) || lastRunUpdate.params.includes('https://flow/RUN2'),
      'UPDATE must include result_link',
    );
  });

  it('writes cache back to user_templates on success', async () => {
    recipeRow = makeRecipe();
    runRow = makeRun({ template_id: 'tpl-cache' });

    const upstreamBody = JSON.stringify({ url: 'https://flow/cache', id: 'EXT-C' });
    await postFinalize({
      run_id: 'run1',
      recipe_id: 'r1',
      ok: true,
      upstream_status: 200,
      body: upstreamBody,
    });

    assert.equal(cacheUpdateCount, 1, 'cache write-back UPDATE must be issued once');
    assert.ok(lastCacheUpdate, 'cache UPDATE must be captured');
    // flow_link, flow_external_id, flow_last_run_id must be params
    assert.ok(
      lastCacheUpdate.params.includes('https://flow/cache'),
      'flow_link must be in cache UPDATE params',
    );
    assert.ok(
      lastCacheUpdate.params.includes('EXT-C'),
      'flow_external_id must be in cache UPDATE params',
    );
    assert.ok(
      lastCacheUpdate.params.includes('run1'),
      'flow_last_run_id (run_id) must be in cache UPDATE params',
    );
    assert.ok(
      lastCacheUpdate.params.includes('tpl-cache'),
      'template_id must be in cache WHERE clause params',
    );
  });

  it('does not write cache when template_id is null', async () => {
    recipeRow = makeRecipe();
    runRow = makeRun({ template_id: null });

    await postFinalize({
      run_id: 'run1',
      recipe_id: 'r1',
      ok: true,
      upstream_status: 200,
      body: JSON.stringify({ url: 'x', id: 'y' }),
    });

    assert.equal(cacheUpdateCount, 0, 'no cache write when template_id is null');
  });
});

// ── (b) ok=false → failed, no link, no cache write ───────────────────────────

describe('run-finalize failure path (ok=false)', () => {
  it('returns 200 with status=failed and null link/externalId when ok=false', async () => {
    recipeRow = makeRecipe();
    runRow = makeRun();

    const r = await postFinalize({
      run_id: 'run1',
      recipe_id: 'r1',
      ok: false,
      upstream_status: 500,
      body: '<html>error</html>',
      error_summary: 'Upstream returned 500',
    });

    assert.equal(r.status, 200);
    assert.equal(r.body.data.status, 'failed');
    assert.equal(r.body.data.link, null);
    assert.equal(r.body.data.externalId, null);
  });

  it('issues a run UPDATE with status=failed on ok=false and does not write cache', async () => {
    recipeRow = makeRecipe();
    runRow = makeRun();

    await postFinalize({
      run_id: 'run1',
      recipe_id: 'r1',
      ok: false,
      upstream_status: 503,
      body: 'gateway timeout',
      error_summary: 'Step 2 timed out',
    });

    assert.equal(runUpdateCount, 1, 'exactly one run UPDATE must be issued');
    assert.equal(cacheUpdateCount, 0, 'no cache write on failure');
  });
});

// ── (c) non-2xx upstream_status → failed even when ok=true ───────────────────

describe('run-finalize: non-2xx upstream_status', () => {
  it('treats ok=true + 400 as failure', async () => {
    recipeRow = makeRecipe();
    runRow = makeRun();

    const r = await postFinalize({
      run_id: 'run1',
      recipe_id: 'r1',
      ok: true,
      upstream_status: 400,
      body: JSON.stringify({ error: 'bad request' }),
    });

    assert.equal(r.status, 200);
    assert.equal(r.body.data.status, 'failed');
    assert.equal(r.body.data.link, null);
    assert.equal(cacheUpdateCount, 0, 'no cache write on non-2xx');
  });

  it('treats ok=true + 500 as failure', async () => {
    recipeRow = makeRecipe();
    runRow = makeRun();

    const r = await postFinalize({
      run_id: 'run1',
      recipe_id: 'r1',
      ok: true,
      upstream_status: 500,
      body: '{}',
    });

    assert.equal(r.status, 200);
    assert.equal(r.body.data.status, 'failed');
  });
});

// ── (d) cache write-back failure does NOT fail the call ──────────────────────

describe('run-finalize: cache write-back best-effort', () => {
  it('still returns 200 success when user_templates UPDATE throws', async () => {
    recipeRow = makeRecipe();
    runRow = makeRun({ template_id: 'tpl-err' });
    shouldCacheThrow = true;

    const upstreamBody = JSON.stringify({ url: 'https://flow/ok', id: 'EXT-ok' });
    const r = await postFinalize({
      run_id: 'run1',
      recipe_id: 'r1',
      ok: true,
      upstream_status: 200,
      body: upstreamBody,
    });

    // The run must be finalized with success
    assert.equal(r.status, 200, `Expected 200, got ${r.status}: ${JSON.stringify(r.body)}`);
    assert.equal(r.body.data.status, 'success', 'run must still be marked success despite cache failure');
    assert.equal(r.body.data.link, 'https://flow/ok');
    // The run UPDATE must still have been issued (before cache write-back)
    assert.equal(runUpdateCount, 1, 'run UPDATE must be issued even when cache throws');
    // The cache write was attempted
    assert.equal(cacheUpdateCount, 1, 'cache UPDATE must have been attempted');
  });
});

// ── (e) SECURITY: extract specs come from DB, not from request body ───────────

describe('run-finalize: DB-authoritative extract specs (SECURITY)', () => {
  it('uses DB link_extract and ignores any link_extract supplied in request body', async () => {
    // DB says path='url'
    recipeRow = makeRecipe({
      link_extract: JSON.stringify({ path: 'url' }),
      external_id_extract: JSON.stringify({ path: 'id' }),
    });
    runRow = makeRun();

    const upstreamBody = JSON.stringify({ url: 'https://legit/link', id: 'REAL-ID', malicious: 'STOLEN' });

    // Caller tries to supply a different (attacker-controlled) extract spec in the body
    const r = await postFinalize({
      run_id: 'run1',
      recipe_id: 'r1',
      ok: true,
      upstream_status: 200,
      body: upstreamBody,
      // These must NOT be used by the server — infra is a lower-trust tier
      link_extract: { path: 'malicious' },
      external_id_extract: { path: 'malicious' },
    });

    assert.equal(r.status, 200);
    // Must have extracted from 'url' (DB spec), not 'malicious' (body-supplied spec)
    assert.equal(r.body.data.link, 'https://legit/link', 'link must come from DB spec path=url');
    assert.equal(r.body.data.externalId, 'REAL-ID', 'externalId must come from DB spec path=id');
  });
});

// ── validation: missing run_id or recipe_id → 400 ────────────────────────────

describe('run-finalize: input validation', () => {
  it('returns 400 when run_id is missing', async () => {
    const r = await postFinalize({ recipe_id: 'r1', ok: true, upstream_status: 200, body: '{}' });
    assert.equal(r.status, 400);
  });

  it('returns 400 when recipe_id is missing', async () => {
    const r = await postFinalize({ run_id: 'run1', ok: true, upstream_status: 200, body: '{}' });
    assert.equal(r.status, 400);
  });

  it('returns 404 when recipe does not exist', async () => {
    recipeRow = null;
    runRow = makeRun();
    const r = await postFinalize({ run_id: 'run1', recipe_id: 'no-recipe', ok: true, upstream_status: 200, body: '{}' });
    assert.equal(r.status, 404);
  });

  it('returns 404 when run does not exist', async () => {
    recipeRow = makeRecipe();
    runRow = null;
    const r = await postFinalize({ run_id: 'no-run', recipe_id: 'r1', ok: true, upstream_status: 200, body: '{}' });
    assert.equal(r.status, 404);
  });
});

// ── (1) run↔recipe binding check (SECURITY) ──────────────────────────────────

describe('run-finalize: run↔recipe binding', () => {
  it('returns 400 RUN_RECIPE_MISMATCH when run.recipe_id !== request recipe_id', async () => {
    // Recipe B's specs supplied, but the run belongs to recipe A.
    recipeRow = makeRecipe({ id: 'recipeB' });
    runRow = makeRun({ recipe_id: 'recipeA' });

    const r = await postFinalize({
      run_id: 'run1',
      recipe_id: 'recipeB',
      ok: true,
      upstream_status: 200,
      body: JSON.stringify({ url: 'https://x', id: 'Y' }),
    });

    assert.equal(r.status, 400, `Expected 400, got ${r.status}: ${JSON.stringify(r.body)}`);
    assert.equal(r.body.error.code, 'RUN_RECIPE_MISMATCH');
    assert.equal(runUpdateCount, 0, 'no run UPDATE must be issued on mismatch');
    assert.equal(cacheUpdateCount, 0, 'no cache write on mismatch');
  });

  it('proceeds normally when run.recipe_id matches request recipe_id', async () => {
    recipeRow = makeRecipe({ id: 'r1' });
    runRow = makeRun({ recipe_id: 'r1' });

    const r = await postFinalize({
      run_id: 'run1',
      recipe_id: 'r1',
      ok: true,
      upstream_status: 200,
      body: JSON.stringify({ url: 'https://ok', id: 'OK' }),
    });

    assert.equal(r.status, 200);
    assert.equal(r.body.data.status, 'success');
  });
});

// ── (2) replay / re-finalize guard (idempotent-safe) ─────────────────────────

describe('run-finalize: replay guard', () => {
  it('returns 409 RUN_ALREADY_FINALIZED when the status-scoped UPDATE matches 0 rows', async () => {
    recipeRow = makeRecipe();
    runRow = makeRun();
    // Simulate the run already being in a terminal state: the
    // `WHERE status NOT IN ('success','failed')` precondition matches nothing.
    runUpdateAffectedRows = 0;

    const r = await postFinalize({
      run_id: 'run1',
      recipe_id: 'r1',
      ok: true,
      upstream_status: 200,
      body: JSON.stringify({ url: 'https://replay', id: 'R' }),
    });

    assert.equal(r.status, 409, `Expected 409, got ${r.status}: ${JSON.stringify(r.body)}`);
    assert.equal(r.body.error.code, 'RUN_ALREADY_FINALIZED');
    // The UPDATE was attempted once but matched 0 rows; the cache must NOT be re-written.
    assert.equal(runUpdateCount, 1, 'finalize UPDATE was attempted once');
    assert.equal(cacheUpdateCount, 0, 'cache must NOT be re-written on a replayed finalize');
  });

  it('scopes the finalize UPDATE with a NOT IN (success,failed) precondition', async () => {
    recipeRow = makeRecipe();
    runRow = makeRun();

    await postFinalize({
      run_id: 'run1',
      recipe_id: 'r1',
      ok: true,
      upstream_status: 200,
      body: JSON.stringify({ url: 'https://x', id: 'Y' }),
    });

    assert.ok(lastRunUpdate, 'an UPDATE must have been captured');
    assert.match(
      lastRunUpdate.sql,
      /status NOT IN \('success',\s*'failed'\)/,
      'UPDATE must carry the terminal-state precondition to be replay-safe',
    );
  });

  it('applies the replay precondition on the failure path too', async () => {
    recipeRow = makeRecipe();
    runRow = makeRun();
    runUpdateAffectedRows = 0;

    const r = await postFinalize({
      run_id: 'run1',
      recipe_id: 'r1',
      ok: false,
      upstream_status: 500,
      body: 'err',
      error_summary: 'boom',
    });

    assert.equal(r.status, 409);
    assert.equal(r.body.error.code, 'RUN_ALREADY_FINALIZED');
  });
});

// ── (3) end-to-end masking: secret-named keys redacted in run UPDATE params ───

describe('run-finalize: end-to-end secret masking in persisted params', () => {
  it('masks a secret-named key inside step_results before the run UPDATE', async () => {
    recipeRow = makeRecipe();
    runRow = makeRun();

    await postFinalize({
      run_id: 'run1',
      recipe_id: 'r1',
      ok: true,
      upstream_status: 200,
      body: JSON.stringify({ url: 'https://x', id: 'Y' }),
      step_results: [{ step_id: 's1', token: 'S', response: { authorization: 'Bearer LEAK' } }],
    });

    assert.ok(lastRunUpdate, 'run UPDATE must be captured');
    const persisted = lastRunUpdate.params.filter((p) => typeof p === 'string');
    // The secret value must NOT appear verbatim in any persisted param.
    assert.ok(
      !persisted.some((p) => p.includes('Bearer LEAK')),
      'raw secret value must not be persisted',
    );
    assert.ok(
      !persisted.some((p) => /"token":"S"/.test(p)),
      'secret-named key value must not be persisted verbatim',
    );
    // A masked marker must be present in the step_results param.
    assert.ok(
      persisted.some((p) => p.includes('****')),
      'masked marker must be present in the persisted step_results',
    );
  });

  it('masks a secret-named key inside error_summary before the run UPDATE', async () => {
    recipeRow = makeRecipe();
    runRow = makeRun();

    await postFinalize({
      run_id: 'run1',
      recipe_id: 'r1',
      ok: false,
      upstream_status: 500,
      body: 'gateway error',
      error_summary: JSON.stringify({ message: 'auth failed', token: 'SECRET-TOK' }),
    });

    assert.ok(lastRunUpdate, 'run UPDATE must be captured');
    const persisted = lastRunUpdate.params.filter((p) => typeof p === 'string');
    assert.ok(
      !persisted.some((p) => p.includes('SECRET-TOK')),
      'secret value inside error_summary must not be persisted verbatim',
    );
    assert.ok(
      persisted.some((p) => p.includes('****')),
      'masked marker must be present in the persisted error_summary',
    );
  });

  it('masks secrets in step_results when sent as a JSON string (parse-then-mask path)', async () => {
    recipeRow = makeRecipe();
    runRow = makeRun();

    // Real infra caller sends JSON.stringify(stepResults), not a live JS array.
    const stepResultsStr = JSON.stringify([{
      step_id: 's1',
      token: 'LEAKED-TOKEN',
      response: { authorization: 'Bearer STRING-LEAK' },
    }]);

    await postFinalize({
      run_id: 'run1',
      recipe_id: 'r1',
      ok: true,
      upstream_status: 200,
      body: JSON.stringify({ url: 'https://x', id: 'Y' }),
      step_results: stepResultsStr, // sent as JSON STRING, not live JS array
    });

    assert.ok(lastRunUpdate, 'run UPDATE must be captured');
    const persisted = lastRunUpdate.params.filter((p) => typeof p === 'string');
    assert.ok(
      !persisted.some((p) => p.includes('LEAKED-TOKEN')),
      'token value inside string-encoded step_results must not be persisted verbatim',
    );
    assert.ok(
      !persisted.some((p) => p.includes('Bearer STRING-LEAK')),
      'authorization value inside string-encoded step_results must not be persisted verbatim',
    );
    assert.ok(
      persisted.some((p) => p.includes('****')),
      'masked placeholder must be present in the persisted step_results',
    );
  });
});

// ── (f) the shape of the write-back statement ────────────────────────────────

describe('run-finalize: what the cache write-back is scoped to', () => {
  // WHAT A MOCKED DRIVER CAN AND CANNOT SHOW. It can show which statement the
  // route emits and what it binds — that the write names the run's own record,
  // that it asks nothing about who is calling, and that it still refuses a
  // record nobody owns. It cannot show which ROWS that matches, because it does
  // not evaluate SQL. The orderings of begin, revoke and finalize are put to a
  // real database in
  // tests/integration/flow-run-writeback-revocation-real-db.test.js.

  it('names the run\'s record and binds nothing about the caller', async () => {
    // The authorisation is the run row: run-begin refused before creating one
    // unless this actor could dispatch this template, and finalize is bound to
    // that actor. Re-asking the permission question here is what let a
    // revocation mid-run drop the record of a dispatch that had already gone
    // out — after which the next dispatch is a create of something already
    // created upstream.
    recipeRow = makeRecipe();
    runRow = makeRun({ actor_id: 'u-grantee', template_id: 'tpl-foreign' });
    grantsTablePresent = true;

    const r = await postFinalize({
      run_id: 'run1',
      recipe_id: 'r1',
      ok: true,
      upstream_status: 200,
      body: JSON.stringify({ url: 'https://flow/ok', id: 'EXT-ok' }),
    });

    assert.equal(r.status, 200);
    assert.ok(lastCacheUpdate, 'cache UPDATE must be captured');
    assert.deepEqual(
      lastCacheUpdate.params,
      ['EXT-ok', 'https://flow/ok', 'run1', 'tpl-foreign'],
      'the write-back binds the run\'s result and its record, and nothing else',
    );
    assert.ok(
      !lastCacheUpdate.params.includes('u-grantee'),
      'the write-back re-asks who is calling',
    );
    assert.ok(
      !/delegated_grants|hierarchy_nodes/.test(lastCacheUpdate.sql),
      'the write-back re-derives a permission instead of relying on the run row',
    );
    assert.equal(
      (lastCacheUpdate.sql.match(/\?/g) || []).length,
      lastCacheUpdate.params.length,
      'the write-back binds a different number of values than it names',
    );
  });

  it('still reaches no record that nobody owns', async () => {
    // The one boundary delegation did not move. run-begin refuses a non-admin a
    // shared record, so a null-owner template on a run means an administrator
    // ran it; that case no-ops here exactly as it always did.
    recipeRow = makeRecipe();
    runRow = makeRun({ actor_id: 'u1', template_id: 'tpl-null-owner' });
    cacheUpdateAffectedRows = 0;

    const r = await postFinalize({
      run_id: 'run1',
      recipe_id: 'r1',
      ok: true,
      upstream_status: 200,
      body: JSON.stringify({ url: 'https://flow/ok', id: 'EXT-ok' }),
    });

    assert.equal(r.status, 200, 'run must still finalize success when the cache write matches 0 rows');
    assert.equal(r.body.data.status, 'success');
    assert.equal(runUpdateCount, 1, 'run UPDATE must succeed');
    assert.equal(cacheUpdateCount, 1, 'cache UPDATE must be attempted (best-effort)');
    assert.match(
      lastCacheUpdate.sql,
      /owner_id IS NOT NULL/,
      'the write-back must exclude a record nobody owns',
    );
  });

  it('emits the same statement on a database with no grants table', async () => {
    // Nothing on this path reads that table any more, so its absence cannot
    // change what a dispatch records. Before, the missing table trimmed the
    // predicate and a probe statement had to be issued to find out.
    recipeRow = makeRecipe();
    runRow = makeRun({ actor_id: 'u1', template_id: 'tpl-own' });
    grantsTablePresent = false;

    const r = await postFinalize({
      run_id: 'run1',
      recipe_id: 'r1',
      ok: true,
      upstream_status: 200,
      body: JSON.stringify({ url: 'https://flow/ok', id: 'EXT-ok' }),
    });

    assert.equal(r.status, 200);
    assert.ok(!/delegated_grants/.test(lastCacheUpdate.sql), 'a missing table was named');
    assert.deepEqual(
      lastCacheUpdate.params,
      ['EXT-ok', 'https://flow/ok', 'run1', 'tpl-own'],
    );
  });
});

// ── P1 lock: finished_at stamped via NOW(), no ISO-8601 string bound as a param ─

describe('run-finalize: P1 lock — finished_at via NOW()', () => {
  it('success path: UPDATE uses NOW() for finished_at — no ISO-8601 string bound as a param', async () => {
    recipeRow = makeRecipe();
    runRow = makeRun();

    await postFinalize({
      run_id: 'run1',
      recipe_id: 'r1',
      ok: true,
      upstream_status: 200,
      body: JSON.stringify({ url: 'https://flow/p1', id: 'EXT-P1' }),
    });

    assert.equal(runUpdateCount, 1, 'run UPDATE must be issued');
    assert.ok(lastRunUpdate, 'run UPDATE must be captured');
    assert.match(lastRunUpdate.sql, /NOW\(\)/, 'success-path UPDATE SQL must contain NOW() for finished_at');
    assert.ok(
      !/finished_at=\?/.test(lastRunUpdate.sql),
      'success-path UPDATE SQL must NOT use a ? placeholder for finished_at',
    );
    // No ISO-8601 string (YYYY-MM-DDTHH:mm:ss.sssZ) must appear as a bound param
    const isoPattern = /\dT\d.*Z/;
    assert.ok(
      !lastRunUpdate.params.some((v) => typeof v === 'string' && isoPattern.test(v)),
      'no ISO-8601 timestamp must be bound as a param in the success-path run UPDATE',
    );
  });

  it('failure path: UPDATE uses NOW() for finished_at — no ISO-8601 string bound as a param', async () => {
    recipeRow = makeRecipe();
    runRow = makeRun();

    await postFinalize({
      run_id: 'run1',
      recipe_id: 'r1',
      ok: false,
      upstream_status: 500,
      body: 'error',
      error_summary: 'step failed',
    });

    assert.equal(runUpdateCount, 1, 'run UPDATE must be issued');
    assert.ok(lastRunUpdate, 'run UPDATE must be captured');
    assert.match(lastRunUpdate.sql, /NOW\(\)/, 'failure-path UPDATE SQL must contain NOW() for finished_at');
    assert.ok(
      !/finished_at=\?/.test(lastRunUpdate.sql),
      'failure-path UPDATE SQL must NOT use a ? placeholder for finished_at',
    );
    const isoPattern = /\dT\d.*Z/;
    assert.ok(
      !lastRunUpdate.params.some((v) => typeof v === 'string' && isoPattern.test(v)),
      'no ISO-8601 timestamp must be bound as a param in the failure-path run UPDATE',
    );
  });
});

// ── server-authoritative extraction + step-emit override (v3.2.417) ──────────

describe('run-finalize: server-authoritative extraction with step-emit override', () => {
  it('BUG FIX: client-orchestrated + no emit fields → server extracts link/externalId from the body', async () => {
    // The real caller (BuildFlowModal) never passed extract specs, so a purely
    // picked-path recipe used to resolve NULL. The server now re-extracts from the
    // final response body using the DB-stored specs — even for the client path.
    recipeRow = makeRecipe(); // link_extract path='url', external_id_extract path='id'
    runRow = makeRun();
    stepCodeRows = [{ step_type: 'api', before_code: 'return {}', after_code: null }]; // requiresClient

    const r = await postFinalize({
      run_id: 'run1',
      recipe_id: 'r1',
      ok: true,
      upstream_status: 200,
      body: JSON.stringify({ url: 'https://server/RIGHT', id: 'SRV-1' }),
      // NO emit fields — the client picked a path but no step emitted link/external_id.
    });

    assert.equal(r.status, 200, `Expected 200, got ${r.status}: ${JSON.stringify(r.body)}`);
    assert.equal(r.body.data.status, 'success');
    assert.equal(r.body.data.link, 'https://server/RIGHT', 'server extracts link from DB spec path=url');
    assert.equal(r.body.data.externalId, 'SRV-1', 'server extracts externalId from DB spec path=id');
  });

  it('client-orchestrated + link_emitted=true overrides the server-extracted link', async () => {
    recipeRow = makeRecipe();
    runRow = makeRun();
    stepCodeRows = [{ step_type: 'api', before_code: null, after_code: 'return {}' }]; // requiresClient

    const r = await postFinalize({
      run_id: 'run1',
      recipe_id: 'r1',
      ok: true,
      upstream_status: 200,
      body: JSON.stringify({ url: 'https://server/body', id: 'SRV-9' }),
      link_emitted: true,
      link_emitted_value: 'https://step/OVERRIDE',
    });

    assert.equal(r.status, 200);
    assert.equal(r.body.data.link, 'https://step/OVERRIDE', 'explicit emit overrides the body path');
    // external_id was NOT emitted → falls back to server extraction from the body.
    assert.equal(r.body.data.externalId, 'SRV-9', 'un-emitted externalId still server-extracted');
  });

  it('client-orchestrated + external_id_emitted=true value=null suppresses server extraction (null wins)', async () => {
    recipeRow = makeRecipe();
    runRow = makeRun();
    stepCodeRows = [{ step_type: 'compute', before_code: 'return {}', after_code: null }]; // requiresClient

    const r = await postFinalize({
      run_id: 'run1',
      recipe_id: 'r1',
      ok: true,
      upstream_status: 200,
      // Body carries an id at the DB spec path, but the explicit null emit must win.
      body: JSON.stringify({ url: 'https://server/link', id: 'WOULD-EXTRACT' }),
      external_id_emitted: true,
      external_id_emitted_value: null,
    });

    assert.equal(r.status, 200);
    assert.equal(r.body.data.externalId, null, 'explicit null emit overrides even a present body value');
    // link was NOT emitted → server-extracted from the body.
    assert.equal(r.body.data.link, 'https://server/link', 'un-emitted link still server-extracted');
  });

  it('rejects an emitted external_id longer than 255 chars → 400 PAYLOAD_TOO_LARGE, no UPDATE', async () => {
    recipeRow = makeRecipe();
    runRow = makeRun();
    stepCodeRows = [{ step_type: 'api', before_code: null, after_code: 'return {}' }]; // requiresClient

    const r = await postFinalize({
      run_id: 'run1',
      recipe_id: 'r1',
      ok: true,
      upstream_status: 200,
      body: '{}',
      external_id_emitted: true,
      external_id_emitted_value: 'x'.repeat(256),
    });

    assert.equal(r.status, 400, `Expected 400, got ${r.status}: ${JSON.stringify(r.body)}`);
    assert.equal(r.body.error.code, 'PAYLOAD_TOO_LARGE');
    assert.equal(runUpdateCount, 0, 'no run UPDATE on a rejected oversize emitted id');
  });

  it('rejects a server-extracted external_id longer than 255 chars → 400 PAYLOAD_TOO_LARGE', async () => {
    recipeRow = makeRecipe();
    runRow = makeRun();
    stepCodeRows = [{ step_type: 'api', before_code: null, after_code: 'return {}' }]; // requiresClient

    const r = await postFinalize({
      run_id: 'run1',
      recipe_id: 'r1',
      ok: true,
      upstream_status: 200,
      // No emit — the oversize id is server-extracted from the body at spec path=id.
      body: JSON.stringify({ url: 'https://ok', id: 'y'.repeat(300) }),
    });

    assert.equal(r.status, 400, `Expected 400, got ${r.status}: ${JSON.stringify(r.body)}`);
    assert.equal(r.body.error.code, 'PAYLOAD_TOO_LARGE');
    assert.equal(runUpdateCount, 0, 'no run UPDATE on a rejected oversize server-extracted id');
  });

  it('rejects an emitted link longer than MAX_LINK_LEN → 400 PAYLOAD_TOO_LARGE, no UPDATE', async () => {
    recipeRow = makeRecipe();
    runRow = makeRun();
    stepCodeRows = [{ step_type: 'api', before_code: null, after_code: 'return {}' }]; // requiresClient

    const r = await postFinalize({
      run_id: 'run1',
      recipe_id: 'r1',
      ok: true,
      upstream_status: 200,
      body: '{}',
      link_emitted: true,
      link_emitted_value: 'h'.repeat(8193), // > MAX_LINK_LEN (8192)
    });

    assert.equal(r.status, 400, `Expected 400, got ${r.status}: ${JSON.stringify(r.body)}`);
    assert.equal(r.body.error.code, 'PAYLOAD_TOO_LARGE');
    assert.equal(runUpdateCount, 0, 'no run UPDATE on a rejected oversize emitted link');
  });

  it('rejects a server-extracted link longer than MAX_LINK_LEN → 400 PAYLOAD_TOO_LARGE', async () => {
    recipeRow = makeRecipe();
    runRow = makeRun();
    stepCodeRows = [{ step_type: 'api', before_code: null, after_code: 'return {}' }]; // requiresClient

    const r = await postFinalize({
      run_id: 'run1',
      recipe_id: 'r1',
      ok: true,
      upstream_status: 200,
      // No emit — the oversize link is server-extracted from the body at spec path=url.
      body: JSON.stringify({ url: 'z'.repeat(9000), id: 'ok' }),
    });

    assert.equal(r.status, 400, `Expected 400, got ${r.status}: ${JSON.stringify(r.body)}`);
    assert.equal(r.body.error.code, 'PAYLOAD_TOO_LARGE');
    assert.equal(runUpdateCount, 0, 'no run UPDATE on a rejected oversize server-extracted link');
  });

  it('trust boundary: legacy resolved_link/resolved_external_id in body are IGNORED', async () => {
    recipeRow = makeRecipe();
    runRow = makeRun();
    stepCodeRows = [{ step_type: 'api', before_code: null, after_code: 'return {}' }]; // requiresClient

    const r = await postFinalize({
      run_id: 'run1',
      recipe_id: 'r1',
      ok: true,
      upstream_status: 200,
      body: JSON.stringify({ url: 'https://server/REAL', id: 'REAL-ID' }),
      // A lower-trust infra tier must not be able to inject a resolved value — the
      // server extracts from the body it received, never trusting these fields.
      resolved_link: 'https://client/FORGED',
      resolved_external_id: 'FORGED',
    });

    assert.equal(r.status, 200);
    assert.equal(r.body.data.link, 'https://server/REAL', 'legacy resolved_link ignored; server extraction wins');
    assert.equal(r.body.data.externalId, 'REAL-ID', 'legacy resolved_external_id ignored');
  });

  it('finalizes a compute-only chain as success despite a null upstream_status (emit override)', async () => {
    recipeRow = makeRecipe();
    runRow = makeRun();
    stepCodeRows = [{ step_type: 'compute', before_code: 'return {}', after_code: null }];

    const r = await postFinalize({
      run_id: 'run1', recipe_id: 'r1', ok: true,
      upstream_status: null, // no HTTP happened — compute-only
      body: '',
      link_emitted: true, link_emitted_value: 'https://built/local',
      external_id_emitted: true, external_id_emitted_value: 'LOCAL-1',
    });

    assert.equal(r.status, 200);
    assert.equal(r.body.data.status, 'success', 'compute-only success must not be downgraded to failed');
    assert.equal(r.body.data.link, 'https://built/local');
    assert.equal(r.body.data.externalId, 'LOCAL-1');
  });

  it('server-loop path unchanged: requiresClient false → extracts from the body', async () => {
    recipeRow = makeRecipe();
    runRow = makeRun();
    stepCodeRows = []; // no JS → server-orchestrated, no emit possible

    const r = await postFinalize({
      run_id: 'run1',
      recipe_id: 'r1',
      ok: true,
      upstream_status: 200,
      body: JSON.stringify({ url: 'https://jsonpath/ok', id: 'JP-1' }),
    });

    assert.equal(r.body.data.link, 'https://jsonpath/ok', 'server-loop extracts from DB JSONPath');
    assert.equal(r.body.data.externalId, 'JP-1');
  });
});

// ── reset-flow-link: owner-scoped clear of the prior-push signal ─────────────

describe('reset-flow-link', () => {
  async function postReset(body, role = 'admin', userId = 'u1') {
    currentRole = role;
    currentUserId = userId;
    const res = await fetch(`${baseUrl}/edge/internal/flow-recipes/reset-flow-link`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(body),
    });
    return { status: res.status, body: await res.json() };
  }

  it('400 when template_id is missing', async () => {
    const r = await postReset({});
    assert.equal(r.status, 400);
    assert.equal(r.body.error.code, 'BAD_REQUEST');
  });

  it('non-admin reset carries the same boundary dispatch does, and reports cleared', async () => {
    // It clears the marker that decides whether the next dispatch creates or
    // updates upstream, so it is scoped to exactly the people who may dispatch:
    // the owner, or someone with delegated access. Scoped to the owner alone it
    // was a boundary its own comment claimed to share with the write-back and
    // did not.
    cacheUpdateAffectedRows = 1;
    grantsTablePresent = true;
    const r = await postReset({ template_id: 'tpl1' }, 'editor', 'u-editor');
    assert.equal(r.status, 200);
    assert.equal(r.body.data.cleared, true);
    assert.match(lastCacheUpdate.sql, /WHERE id=\? AND \(owner_id=\? OR \(`fmb_user_templates`\.`owner_id` IS NOT NULL/);
    assert.deepEqual(
      lastCacheUpdate.params,
      ['tpl1', 'u-editor', 'u-editor', 'u-editor', 'u-editor'],
    );
    assert.equal(
      (lastCacheUpdate.sql.match(/\?/g) || []).length,
      lastCacheUpdate.params.length,
      'the reset binds a different number of values than it names',
    );
  });

  it('foreign/unowned template clears 0 rows → cleared:false (no IDOR leak)', async () => {
    cacheUpdateAffectedRows = 0;
    const r = await postReset({ template_id: 'tpl-foreign' }, 'editor', 'u-editor');
    assert.equal(r.status, 200);
    assert.equal(r.body.data.cleared, false);
  });

  it('admin reset is not owner-scoped (mirrors run-begin admin bypass)', async () => {
    cacheUpdateAffectedRows = 1;
    const r = await postReset({ template_id: 'tpl1' }, 'admin', 'u-admin');
    assert.equal(r.status, 200);
    assert.ok(!/owner_id=\?/.test(lastCacheUpdate.sql), 'admin reset must not be owner-scoped');
    assert.deepEqual(lastCacheUpdate.params, ['tpl1']);
  });
});

// ── finalize hardening: length cap + actor binding ───────────────────────────

describe('run-finalize hardening', () => {
  it('non-admin caller who is not the run actor is forbidden', async () => {
    recipeRow = makeRecipe();
    runRow = makeRun({ actor_id: 'u-owner' });
    currentRole = 'editor';
    currentUserId = 'u-other';
    const r = await postFinalize({ run_id: 'run1', recipe_id: 'r1', ok: true, upstream_status: 200, body: '{}' });
    assert.equal(r.status, 403);
    assert.equal(r.body.error.code, 'RUN_FORBIDDEN');
  });

  it('the run actor may finalize their own run', async () => {
    recipeRow = makeRecipe();
    runRow = makeRun({ actor_id: 'u-self' });
    currentRole = 'editor';
    currentUserId = 'u-self';
    const r = await postFinalize({ run_id: 'run1', recipe_id: 'r1', ok: true, upstream_status: 200, body: '{}' });
    assert.equal(r.status, 200);
  });

  it('coalesces an object-shaped error_summary to null (FE contract is string|null)', async () => {
    recipeRow = makeRecipe();
    runRow = makeRun();
    // The FE always sends error_summary as string|null, but an authed run actor
    // can POST an object. It must never reach the persisted param as a live
    // object — coalesce to null so the audit row keeps a clean shape.
    const r = await postFinalize({
      run_id: 'run1',
      recipe_id: 'r1',
      ok: false,
      upstream_status: 500,
      body: 'gateway error',
      error_summary: { message: 'auth failed', nested: { token: 'SECRET-OBJ' } },
    });

    assert.equal(r.status, 200);
    assert.equal(r.body.data.status, 'failed');
    assert.ok(lastRunUpdate, 'run UPDATE must be captured');
    // Failure branch params: [status, error_summary, step_results, runId].
    const persistedErrorSummary = lastRunUpdate.params[1];
    assert.ok(
      persistedErrorSummary === null || typeof persistedErrorSummary === 'string',
      `error_summary param must be string|null, got ${typeof persistedErrorSummary}`,
    );
    assert.equal(persistedErrorSummary, null, 'object-shaped error_summary coalesces to null');
    // Defense-in-depth: no persisted string param leaks the object's secret value.
    const persistedStrings = lastRunUpdate.params.filter((p) => typeof p === 'string');
    assert.ok(
      !persistedStrings.some((p) => p.includes('SECRET-OBJ')),
      'secret value inside object error_summary must not be persisted',
    );
  });

  it('preserves a normal string error_summary (masking still applies)', async () => {
    recipeRow = makeRecipe();
    runRow = makeRun();
    const r = await postFinalize({
      run_id: 'run1',
      recipe_id: 'r1',
      ok: false,
      upstream_status: 500,
      body: 'gateway error',
      error_summary: 'Step 2 timed out',
    });

    assert.equal(r.status, 200);
    assert.equal(lastRunUpdate.params[1], 'Step 2 timed out');
  });
});

// ── the snapshot of what was entered survives finalize ───────────────────────

describe('run-finalize: input_snapshot is not rewritten', () => {
  it('a failed finalize leaves input_snapshot alone, so a run that broke mid-chain keeps it', async () => {
    // The snapshot is written by the INSERT at run-begin. Finalize must not
    // name the column at all — a SET that touched it would be the one path able
    // to erase what was entered, and it is the path a broken run takes.
    recipeRow = makeRecipe();
    runRow = makeRun();

    await postFinalize({
      run_id: 'run1',
      recipe_id: 'r1',
      ok: false,
      upstream_status: 500,
      body: 'gateway error',
      error_summary: 'Step 2 failed',
    });

    assert.equal(runUpdateCount, 1);
    assert.ok(!/\binput_snapshot\b/.test(lastRunUpdate.sql),
      'the failure UPDATE must not name input_snapshot');
  });

  it('a successful finalize leaves it alone too', async () => {
    recipeRow = makeRecipe();
    runRow = makeRun();

    await postFinalize({
      run_id: 'run1',
      recipe_id: 'r1',
      ok: true,
      upstream_status: 200,
      body: JSON.stringify({ url: 'https://x/f1', id: 'f1' }),
    });

    assert.equal(runUpdateCount, 1);
    assert.ok(!/\binput_snapshot\b/.test(lastRunUpdate.sql),
      'the success UPDATE must not name input_snapshot');
  });
});
