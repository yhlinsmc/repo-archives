/**
 * Unit tests for jit-provisioner.js — focused on v3.2.31 KEYCLOAK_ADMIN_EMAILS
 * auto-promotion logic. The jitProvision happy paths (lookup-by-sub,
 * email-fallback bind, stale-sub rebind, new user) are exercised through a
 * minimal in-memory `conn` double that records SQL the production code would
 * have run.
 *
 * Run: node --test docker-api/tests/unit/jit-provisioner.test.js
 */
const { describe, it, beforeEach, afterEach } = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');

// Inject a recording logger BEFORE the module loads so the email-collision WARN
// can be asserted (and proven to carry no raw email). Harmless to the other
// tests, which do not inspect logs.
const loggerKey = require.resolve('../../src/shared/lib/logger');
const logRecords = [];
const recLogger = {
  child: () => recLogger,
  info: (obj, msg) => logRecords.push({ level: 'info', obj, msg }),
  warn: (obj, msg) => logRecords.push({ level: 'warn', obj, msg }),
  error: (obj, msg) => logRecords.push({ level: 'error', obj, msg }),
  debug: () => {},
  trace: () => {},
};
require.cache[loggerKey] = {
  id: loggerKey, filename: loggerKey, loaded: true,
  exports: { logger: recLogger },
};

const {
  jitProvision,
  parseAdminEmails,
  shouldAutoPromote,
  resolveAccessRuleRole,
  resyncBoundUserClaims,
} = require(path.join(__dirname, '..', '..', 'src', 'lib', 'jit-provisioner'));

const t = (name) => `fmb_${name}`;
const baseAudit = { ip: '127.0.0.1', userAgent: 'jest' };

function makeConn(seed = {}) {
  const users = seed.users ? [...seed.users] : [];
  const rules = seed.rules ? [...seed.rules] : [];
  const audits = [];
  let nextId = users.length + 1;
  // When seed.failEmailUpdateOnce is set, the first re-sync UPDATE that includes
  // the email column throws a MariaDB-shaped ER_DUP_ENTRY (simulating the
  // pre-check→write UNIQUE race); subsequent UPDATEs succeed.
  let emailUpdateFailed = false;
  const conn = {
    queries: [],
    users,
    rules,
    audits,
    async beginTransaction() {},
    async commit() {},
    async rollback() {},
    async query(sql, params) {
      conn.queries.push({ sql, params });
      const norm = sql.replace(/\s+/g, ' ').trim();
      if (/^SELECT .* FROM `fmb_users` WHERE keycloak_sub = \?$/.test(norm)) {
        return users.filter((u) => u.keycloak_sub === params[0]);
      }
      if (/WHERE email = \? AND keycloak_sub IS NULL/.test(norm)) {
        return users.filter((u) => u.email === params[0] && u.keycloak_sub == null);
      }
      if (/WHERE email = \? AND keycloak_sub IS NOT NULL AND keycloak_sub != \?/.test(norm)) {
        return users.filter((u) => u.email === params[0] && u.keycloak_sub != null && u.keycloak_sub !== params[1]);
      }
      if (/SELECT COUNT\(\*\) AS cnt FROM `fmb_users`/.test(norm)) {
        return [{ cnt: users.length }];
      }
      if (/SELECT role FROM `fmb_access_rules` WHERE rule_type = 'user' AND rule_value = \? AND enabled = TRUE/.test(norm)) {
        return rules
          .filter((r) => r.rule_type === 'user' && r.rule_value === params[0] && r.enabled)
          .slice(0, 1)
          .map((r) => ({ role: r.role }));
      }
      if (/SELECT role FROM `fmb_access_rules` WHERE rule_type = 'deptid' AND rule_value = \? AND enabled = TRUE/.test(norm)) {
        return rules
          .filter((r) => r.rule_type === 'deptid' && r.rule_value === params[0] && r.enabled)
          .slice(0, 1)
          .map((r) => ({ role: r.role }));
      }
      // Collision pre-check for the Step 1 email re-sync.
      if (/^SELECT id FROM `fmb_users` WHERE email = \? AND id != \? LIMIT 1$/.test(norm)) {
        return users
          .filter((u) => u.email === params[0] && u.id !== params[1])
          .slice(0, 1)
          .map((u) => ({ id: u.id }));
      }
      // Step 2 bind / stale-sub rebind — fixed column set with COALESCE display_name.
      if (/^UPDATE `fmb_users` SET keycloak_sub = \?, kc_username = \?, deptid = \?, user_id = \?, display_name = COALESCE/.test(norm)) {
        const id = params[params.length - 1];
        const u = users.find((row) => row.id === id);
        if (u) {
          u.keycloak_sub = params[0];
          u.kc_username = params[1];
          u.deptid = params[2];
          u.user_id = params[3];
          u.display_name = u.display_name || params[4];
          u.role = params[5];
        }
        return { affectedRows: 1 };
      }
      // Step 1 profile re-sync — dynamic subset of email/display_name/deptid/kc_username.
      if (/^UPDATE `fmb_users` SET /.test(norm)) {
        const setClause = norm.match(/^UPDATE `fmb_users` SET (.+) WHERE id = \?$/)[1];
        if (seed.failEmailUpdateOnce && !emailUpdateFailed && /email = \?/.test(setClause)) {
          emailUpdateFailed = true;
          const e = new Error("Duplicate entry for key 'email'");
          e.code = 'ER_DUP_ENTRY';
          e.errno = 1062;
          throw e;
        }
        const id = params[params.length - 1];
        const u = users.find((row) => row.id === id);
        if (u) {
          setClause.split(', ').forEach((assign, i) => {
            u[assign.replace(/ = \?$/, '')] = params[i];
          });
        }
        return { affectedRows: 1 };
      }
      if (/^INSERT INTO `fmb_users`/.test(norm)) {
        users.push({
          id: params[0],
          email: params[1],
          keycloak_sub: params[2],
          deptid: params[3],
          kc_username: params[4],
          user_id: params[5],
          display_name: params[6],
          role: params[7],
          banned: 0,
        });
        nextId += 1;
        return { affectedRows: 1, insertId: nextId };
      }
      if (/^INSERT INTO `fmb_login_audit`/.test(norm)) {
        audits.push(params);
        return { affectedRows: 1 };
      }
      throw new Error(`unhandled SQL: ${norm}`);
    },
  };
  return conn;
}

const baseMapped = {
  keycloak_sub: 'kc-sub-1',
  email: 'alice@example.com',
  email_verified: true,
  kc_username: 'alice',
  deptid: 'eng',
  user_id: 42,
  display_name: 'Alice',
};

describe('parseAdminEmails', () => {
  it('returns empty Set for empty/undefined input', () => {
    assert.strictEqual(parseAdminEmails(undefined).size, 0);
    assert.strictEqual(parseAdminEmails('').size, 0);
    assert.strictEqual(parseAdminEmails('   ').size, 0);
  });

  it('lowercases and trims entries', () => {
    const set = parseAdminEmails(' ALICE@example.com , Bob@Example.COM ');
    assert.deepStrictEqual([...set], ['alice@example.com', 'bob@example.com']);
  });

  it('drops empty CSV entries (trailing commas / double commas)', () => {
    const set = parseAdminEmails('a@x,,b@x,');
    assert.deepStrictEqual([...set], ['a@x', 'b@x']);
  });
});

describe('shouldAutoPromote', () => {
  let prev;
  beforeEach(() => { prev = process.env.KEYCLOAK_ADMIN_EMAILS; });
  afterEach(() => {
    if (prev === undefined) delete process.env.KEYCLOAK_ADMIN_EMAILS;
    else process.env.KEYCLOAK_ADMIN_EMAILS = prev;
  });

  it('false when env var unset', () => {
    delete process.env.KEYCLOAK_ADMIN_EMAILS;
    assert.strictEqual(shouldAutoPromote({ email: 'alice@example.com', email_verified: true }), false);
  });

  it('true when email matches (case-insensitive)', () => {
    process.env.KEYCLOAK_ADMIN_EMAILS = 'alice@example.com';
    assert.strictEqual(shouldAutoPromote({ email: 'ALICE@example.com', email_verified: true }), true);
  });

  it('false when email_verified explicitly false', () => {
    process.env.KEYCLOAK_ADMIN_EMAILS = 'alice@example.com';
    assert.strictEqual(shouldAutoPromote({ email: 'alice@example.com', email_verified: false }), false);
  });

  it('false when email_verified omitted (defense-in-depth, MED fold)', () => {
    process.env.KEYCLOAK_ADMIN_EMAILS = 'alice@example.com';
    // The mapper normalises absent claim to `false`, so this case shouldn't
    // happen in production. Guard is === true so any non-true value blocks
    // promotion even if a future call site bypasses the mapper.
    assert.strictEqual(shouldAutoPromote({ email: 'alice@example.com' }), false);
  });

  it('false when email_verified is the string "true" (only boolean true counts)', () => {
    process.env.KEYCLOAK_ADMIN_EMAILS = 'alice@example.com';
    assert.strictEqual(shouldAutoPromote({ email: 'alice@example.com', email_verified: 'true' }), false);
  });

  it('false when email not in list', () => {
    process.env.KEYCLOAK_ADMIN_EMAILS = 'bob@example.com';
    assert.strictEqual(shouldAutoPromote({ email: 'alice@example.com', email_verified: true }), false);
  });

  it('false when email missing on claims', () => {
    process.env.KEYCLOAK_ADMIN_EMAILS = 'alice@example.com';
    assert.strictEqual(shouldAutoPromote({ email_verified: true }), false);
  });
});

describe('jitProvision — KEYCLOAK_ADMIN_EMAILS auto-promotion', () => {
  let prev;
  beforeEach(() => { prev = process.env.KEYCLOAK_ADMIN_EMAILS; });
  afterEach(() => {
    if (prev === undefined) delete process.env.KEYCLOAK_ADMIN_EMAILS;
    else process.env.KEYCLOAK_ADMIN_EMAILS = prev;
  });

  it('Step 3 (new user, not first) auto-promotes when listed', async () => {
    process.env.KEYCLOAK_ADMIN_EMAILS = 'alice@example.com';
    const conn = makeConn({
      users: [{ id: 'pre-1', email: 'someone@x', keycloak_sub: 'other-sub', role: 'user' }],
    });
    const out = await jitProvision({ mapped: baseMapped, conn, t, auditInfo: baseAudit });
    assert.strictEqual(out.role, 'admin');
    const newRow = conn.users.find((u) => u.email === 'alice@example.com');
    assert.strictEqual(newRow.role, 'admin');
  });

  it('Step 3 (new user, not first) stays user when env unset', async () => {
    delete process.env.KEYCLOAK_ADMIN_EMAILS;
    const conn = makeConn({
      users: [{ id: 'pre-1', email: 'someone@x', keycloak_sub: 'other-sub', role: 'user' }],
    });
    const out = await jitProvision({ mapped: baseMapped, conn, t, auditInfo: baseAudit });
    assert.strictEqual(out.role, 'user');
  });

  it('Step 3 first user always admin (env irrelevant)', async () => {
    delete process.env.KEYCLOAK_ADMIN_EMAILS;
    const conn = makeConn();
    const out = await jitProvision({ mapped: baseMapped, conn, t, auditInfo: baseAudit });
    assert.strictEqual(out.role, 'admin');
  });

  it('Step 2a (email-fallback bind) promotes when listed', async () => {
    process.env.KEYCLOAK_ADMIN_EMAILS = 'alice@example.com';
    const conn = makeConn({
      users: [{ id: 'u-1', email: 'alice@example.com', keycloak_sub: null, role: 'user' }],
    });
    const out = await jitProvision({ mapped: baseMapped, conn, t, auditInfo: baseAudit });
    assert.strictEqual(out.role, 'admin');
    assert.strictEqual(conn.users[0].role, 'admin');
  });

  it('Step 2a never downgrades existing admin', async () => {
    delete process.env.KEYCLOAK_ADMIN_EMAILS;
    const conn = makeConn({
      users: [{ id: 'u-1', email: 'alice@example.com', keycloak_sub: null, role: 'admin' }],
    });
    const out = await jitProvision({ mapped: baseMapped, conn, t, auditInfo: baseAudit });
    assert.strictEqual(out.role, 'admin');
  });

  it('Step 2b (stale-sub rebind) promotes when listed', async () => {
    process.env.KEYCLOAK_ADMIN_EMAILS = 'alice@example.com';
    const conn = makeConn({
      users: [{ id: 'u-1', email: 'alice@example.com', keycloak_sub: 'old-sub', role: 'user' }],
    });
    const out = await jitProvision({ mapped: baseMapped, conn, t, auditInfo: baseAudit });
    assert.strictEqual(out.role, 'admin');
    assert.strictEqual(conn.users[0].role, 'admin');
  });

  it('Step 1 (existing-bound user) NEVER changes role even if listed', async () => {
    process.env.KEYCLOAK_ADMIN_EMAILS = 'alice@example.com';
    const conn = makeConn({
      users: [{ id: 'u-1', email: 'alice@example.com', keycloak_sub: 'kc-sub-1', role: 'user' }],
    });
    const out = await jitProvision({ mapped: baseMapped, conn, t, auditInfo: baseAudit });
    // Step 1 returns existing row as-is — promotion happens only on first
    // bind. Existing users go through scripts/promote-admin.sh or admin UI.
    assert.strictEqual(out.role, 'user');
  });
});

describe('resolveAccessRuleRole — access-rule role lookup', () => {
  const preUser = { id: 'pre-1', email: 'someone@x', keycloak_sub: 'other-sub', role: 'user' };

  it('returns null when no rule matches', async () => {
    const conn = makeConn({ rules: [] });
    assert.strictEqual(await resolveAccessRuleRole(conn, t, baseMapped), null);
  });

  it('matches a deptid rule', async () => {
    const conn = makeConn({ rules: [{ rule_type: 'deptid', rule_value: 'eng', role: 'editor', enabled: true }] });
    assert.strictEqual(await resolveAccessRuleRole(conn, t, baseMapped), 'editor');
  });

  it('skips the user-email branch when email is absent (falls through to deptid)', async () => {
    const conn = makeConn({ rules: [{ rule_type: 'deptid', rule_value: 'eng', role: 'editor', enabled: true }] });
    const out = await resolveAccessRuleRole(conn, t, { deptid: 'eng' });
    assert.strictEqual(out, 'editor');
    // no user-email query should have run without an email claim
    assert.ok(!conn.queries.some((q) => /rule_type = 'user'/.test(q.sql)));
  });

  it('skips a user-email rule when email is unverified (privilege guard)', async () => {
    const conn = makeConn({ rules: [{ rule_type: 'user', rule_value: 'alice@example.com', role: 'editor', enabled: true }] });
    const out = await resolveAccessRuleRole(conn, t, { ...baseMapped, email_verified: false });
    assert.strictEqual(out, null);
  });

  it('prefers a user-email rule over a deptid rule', async () => {
    const conn = makeConn({
      rules: [
        { rule_type: 'deptid', rule_value: 'eng', role: 'user', enabled: true },
        { rule_type: 'user', rule_value: 'alice@example.com', role: 'editor', enabled: true },
      ],
    });
    assert.strictEqual(await resolveAccessRuleRole(conn, t, baseMapped), 'editor');
  });

  it('ignores a disabled rule', async () => {
    const conn = makeConn({ rules: [{ rule_type: 'deptid', rule_value: 'eng', role: 'editor', enabled: false }] });
    assert.strictEqual(await resolveAccessRuleRole(conn, t, baseMapped), null);
  });

  it('jitProvision: new user (not first) is seeded editor from a matching deptid rule', async () => {
    delete process.env.KEYCLOAK_ADMIN_EMAILS;
    const conn = makeConn({
      users: [preUser],
      rules: [{ rule_type: 'deptid', rule_value: 'eng', role: 'editor', enabled: true }],
    });
    const out = await jitProvision({ mapped: baseMapped, conn, t, auditInfo: baseAudit });
    assert.strictEqual(out.role, 'editor');
    assert.strictEqual(conn.users.find((u) => u.email === 'alice@example.com').role, 'editor');
  });

  it('jitProvision: a legacy role=admin rule is capped to user (rules never mint admins)', async () => {
    delete process.env.KEYCLOAK_ADMIN_EMAILS;
    const conn = makeConn({
      users: [preUser],
      rules: [{ rule_type: 'deptid', rule_value: 'eng', role: 'admin', enabled: true }],
    });
    const out = await jitProvision({ mapped: baseMapped, conn, t, auditInfo: baseAudit });
    assert.strictEqual(out.role, 'user');
  });

  it('jitProvision: new user with no matching rule stays user', async () => {
    delete process.env.KEYCLOAK_ADMIN_EMAILS;
    const conn = makeConn({ users: [preUser], rules: [] });
    const out = await jitProvision({ mapped: baseMapped, conn, t, auditInfo: baseAudit });
    assert.strictEqual(out.role, 'user');
  });

  it('jitProvision: first user is admin even with an editor rule (first-user wins)', async () => {
    delete process.env.KEYCLOAK_ADMIN_EMAILS;
    const conn = makeConn({ rules: [{ rule_type: 'deptid', rule_value: 'eng', role: 'editor', enabled: true }] });
    const out = await jitProvision({ mapped: baseMapped, conn, t, auditInfo: baseAudit });
    assert.strictEqual(out.role, 'admin');
  });

  it('jitProvision: KEYCLOAK_ADMIN_EMAILS wins over an editor rule', async () => {
    process.env.KEYCLOAK_ADMIN_EMAILS = 'alice@example.com';
    const conn = makeConn({
      users: [preUser],
      rules: [{ rule_type: 'deptid', rule_value: 'eng', role: 'editor', enabled: true }],
    });
    const out = await jitProvision({ mapped: baseMapped, conn, t, auditInfo: baseAudit });
    assert.strictEqual(out.role, 'admin');
    delete process.env.KEYCLOAK_ADMIN_EMAILS;
  });

  it('jitProvision: an existing bound user is NOT re-seeded from a rule (provisioning-only)', async () => {
    delete process.env.KEYCLOAK_ADMIN_EMAILS;
    const conn = makeConn({
      users: [{ id: 'u-1', email: 'alice@example.com', keycloak_sub: 'kc-sub-1', role: 'user', banned: 0 }],
      rules: [{ rule_type: 'deptid', rule_value: 'eng', role: 'editor', enabled: true }],
    });
    const out = await jitProvision({ mapped: baseMapped, conn, t, auditInfo: baseAudit });
    assert.strictEqual(out.role, 'user');
  });
});

describe('jitProvision — freshLogin audit (Recent Logins freshness fix)', () => {
  it('Step 1: freshLogin writes one success audit row for an existing bound user', async () => {
    const conn = makeConn({
      users: [{ id: 'u-1', email: 'alice@example.com', keycloak_sub: 'kc-sub-1', role: 'user', banned: 0 }],
    });
    const out = await jitProvision({ mapped: baseMapped, conn, t, auditInfo: baseAudit, freshLogin: true });
    assert.strictEqual(out.id, 'u-1');
    assert.strictEqual(conn.audits.length, 1);
    // success column is the last param (TRUE handled by literal in SQL — the
    // row is recorded; provider is KEYCLOAK literal in the insert).
    const params = conn.audits[0];
    assert.strictEqual(params[0], 'alice'); // kc_username || email
    assert.strictEqual(params[1], 'eng');   // deptid
  });

  it('Step 1: no freshLogin flag writes zero audit rows (token re-verification path)', async () => {
    const conn = makeConn({
      users: [{ id: 'u-1', email: 'alice@example.com', keycloak_sub: 'kc-sub-1', role: 'user', banned: 0 }],
    });
    const out = await jitProvision({ mapped: baseMapped, conn, t, auditInfo: baseAudit });
    assert.strictEqual(out.id, 'u-1');
    assert.strictEqual(conn.audits.length, 0);
  });

  it('Step 1: freshLogin on a banned user writes zero audit rows', async () => {
    const conn = makeConn({
      users: [{ id: 'u-1', email: 'alice@example.com', keycloak_sub: 'kc-sub-1', role: 'user', banned: 1 }],
    });
    const out = await jitProvision({ mapped: baseMapped, conn, t, auditInfo: baseAudit, freshLogin: true });
    assert.strictEqual(out.id, 'u-1');
    assert.strictEqual(out.banned, 1);
    assert.strictEqual(conn.audits.length, 0);
  });

  it('new-user path is unaffected by freshLogin (still one provisioning audit row)', async () => {
    const conn = makeConn();
    await jitProvision({ mapped: baseMapped, conn, t, auditInfo: baseAudit, freshLogin: true });
    // Step 3 writes its own success row; freshLogin must not double it.
    assert.strictEqual(conn.audits.length, 1);
  });
});

describe('jitProvision — banned guard on first-bind audit (Step 2a/2b)', () => {
  it('Step 2a (email-fallback bind) of a banned user binds but writes NO success row', async () => {
    const conn = makeConn({
      users: [{ id: 'u-1', email: 'alice@example.com', keycloak_sub: null, role: 'user', banned: 1 }],
    });
    const out = await jitProvision({ mapped: baseMapped, conn, t, auditInfo: baseAudit });
    // bind still happens (sub associated) so the next request resolves the row...
    assert.strictEqual(conn.users[0].keycloak_sub, 'kc-sub-1');
    // ...but a banned user must not get a misleading success login_audit row.
    // identity-resolve writes its own FALSE 'account_banned' row instead.
    assert.strictEqual(conn.audits.length, 0);
    assert.strictEqual(out.banned, 1);
  });

  it('Step 2a (email-fallback bind) of a non-banned user still writes one success row', async () => {
    const conn = makeConn({
      users: [{ id: 'u-1', email: 'alice@example.com', keycloak_sub: null, role: 'user', banned: 0 }],
    });
    await jitProvision({ mapped: baseMapped, conn, t, auditInfo: baseAudit });
    assert.strictEqual(conn.audits.length, 1);
  });

  it('Step 2b (stale-sub rebind) of a banned user rebinds but writes NO success row', async () => {
    const conn = makeConn({
      users: [{ id: 'u-1', email: 'alice@example.com', keycloak_sub: 'old-sub', role: 'user', banned: 1 }],
    });
    const out = await jitProvision({ mapped: baseMapped, conn, t, auditInfo: baseAudit });
    assert.strictEqual(conn.users[0].keycloak_sub, 'kc-sub-1');
    assert.strictEqual(conn.audits.length, 0);
    assert.strictEqual(out.banned, 1);
  });

  it('Step 2b (stale-sub rebind) of a non-banned user still writes one rebind row', async () => {
    const conn = makeConn({
      users: [{ id: 'u-1', email: 'alice@example.com', keycloak_sub: 'old-sub', role: 'user', banned: 0 }],
    });
    await jitProvision({ mapped: baseMapped, conn, t, auditInfo: baseAudit });
    assert.strictEqual(conn.audits.length, 1);
  });
});

describe('jitProvision — Step 1 KC-owned profile re-sync', () => {
  // Normalised re-sync UPDATEs only (excludes the Step 2 bind UPDATE, which
  // carries keycloak_sub + COALESCE display_name).
  const resyncUpdatesOf = (conn) =>
    conn.queries
      .map((q) => q.sql.replace(/\s+/g, ' ').trim())
      .filter((s) => /^UPDATE `fmb_users` SET /.test(s) && !/COALESCE/.test(s));

  beforeEach(() => { logRecords.length = 0; });

  it('(a) refreshes drifted deptid + display_name; leaves role/banned/password_hash byte-identical', async () => {
    const conn = makeConn({
      users: [{
        id: 'u-1', email: 'alice@example.com', keycloak_sub: 'kc-sub-1',
        role: 'user', banned: 0, password_hash: 'STORED-HASH', user_id: 42,
        deptid: 'old-dept', kc_username: 'alice', display_name: 'Old Name',
      }],
    });
    const out = await jitProvision({ mapped: baseMapped, conn, t, auditInfo: baseAudit });

    const updates = resyncUpdatesOf(conn);
    assert.strictEqual(updates.length, 1, 'exactly one re-sync UPDATE');
    // Only the drifted columns; admin-owned columns absent.
    assert.match(updates[0], /display_name = \?/);
    assert.match(updates[0], /deptid = \?/);
    assert.ok(!/role = \?/.test(updates[0]), 'role never in re-sync UPDATE');
    assert.ok(!/banned = \?/.test(updates[0]), 'banned never in re-sync UPDATE');
    assert.ok(!/password_hash = \?/.test(updates[0]), 'password_hash never in re-sync UPDATE');
    assert.ok(!/email = \?/.test(updates[0]), 'email unchanged (no drift)');
    assert.ok(!/kc_username = \?/.test(updates[0]), 'kc_username unchanged (no drift)');

    assert.strictEqual(conn.users[0].deptid, 'eng');
    assert.strictEqual(conn.users[0].display_name, 'Alice');
    // Admin-owned columns byte-identical.
    assert.strictEqual(conn.users[0].role, 'user');
    assert.strictEqual(conn.users[0].banned, 0);
    assert.strictEqual(conn.users[0].password_hash, 'STORED-HASH');
    // Returned row carries the refreshed values (downstream access-check reads these).
    assert.strictEqual(out.deptid, 'eng');
    assert.strictEqual(out.display_name, 'Alice');
    assert.strictEqual(out.role, 'user');
  });

  it('(b) email collision with another row: email kept, other columns updated, WARN (no raw email), login succeeds', async () => {
    const conn = makeConn({
      users: [
        {
          id: 'u-1', email: 'old@example.com', keycloak_sub: 'kc-sub-1',
          role: 'user', banned: 0, deptid: 'old-dept', kc_username: 'alice', display_name: 'Old',
        },
        { id: 'u-2', email: 'alice@example.com', keycloak_sub: 'other-sub', role: 'user' },
      ],
    });
    const out = await jitProvision({ mapped: baseMapped, conn, t, auditInfo: baseAudit });

    // Login succeeded on the bound row.
    assert.strictEqual(out.id, 'u-1');
    // Email column untouched (collision), other drift applied.
    assert.strictEqual(conn.users[0].email, 'old@example.com');
    assert.strictEqual(conn.users[0].deptid, 'eng');
    assert.strictEqual(conn.users[0].display_name, 'Alice');
    assert.strictEqual(out.email, 'old@example.com');
    // Transient marker carries the still-colliding value so infra's cache can
    // quiet the drift check for it (never persisted; not the stored email).
    assert.strictEqual(out.emailResyncSkippedFor, 'alice@example.com',
      'skip branch exposes the colliding email as the transient marker');
    const updates = resyncUpdatesOf(conn);
    assert.strictEqual(updates.length, 1);
    assert.ok(!/email = \?/.test(updates[0]), 'skipped email column must not be in the UPDATE');

    // Structured WARN present, carrying both ids and NO raw email.
    const warn = logRecords.find((r) => r.level === 'warn' && /re-sync skipped/.test(r.msg));
    assert.ok(warn, 'a skip WARN must be logged');
    assert.strictEqual(warn.obj.userId, 'u-1');
    assert.strictEqual(warn.obj.conflictUserId, 'u-2');
    assert.ok(!JSON.stringify(warn).includes('alice@example.com'), 'WARN must not contain the raw email');
  });

  it('(c) no drift issues zero UPDATE (no per-login write amplification)', async () => {
    const conn = makeConn({
      users: [{
        id: 'u-1', email: 'alice@example.com', keycloak_sub: 'kc-sub-1',
        role: 'user', banned: 0, deptid: 'eng', kc_username: 'alice', display_name: 'Alice',
      }],
    });
    const out = await jitProvision({ mapped: baseMapped, conn, t, auditInfo: baseAudit });
    assert.strictEqual(resyncUpdatesOf(conn).length, 0);
    // No email collision pre-check either (email did not drift).
    assert.ok(!conn.queries.some((q) => /id != \? LIMIT 1/.test(q.sql)));
    assert.strictEqual(out.id, 'u-1');
    assert.strictEqual(out.deptid, 'eng');
  });

  it('(d) email change without collision updates the email column', async () => {
    const conn = makeConn({
      users: [{
        id: 'u-1', email: 'old@example.com', keycloak_sub: 'kc-sub-1',
        role: 'user', banned: 0, deptid: 'eng', kc_username: 'alice', display_name: 'Alice',
      }],
    });
    const out = await jitProvision({ mapped: baseMapped, conn, t, auditInfo: baseAudit });
    const updates = resyncUpdatesOf(conn);
    assert.strictEqual(updates.length, 1);
    assert.match(updates[0], /email = \?/);
    assert.strictEqual(conn.users[0].email, 'alice@example.com');
    assert.strictEqual(out.email, 'alice@example.com');
    assert.strictEqual(conn.users[0].role, 'user');
    // No collision was skipped → no transient marker on the returned row.
    assert.strictEqual(out.emailResyncSkippedFor, undefined, 'no marker when email syncs cleanly');
  });

  it('(f) an absent claim never clears a stored column (deptid preserved on partial token)', async () => {
    const conn = makeConn({
      users: [{
        id: 'u-1', email: 'alice@example.com', keycloak_sub: 'kc-sub-1',
        role: 'user', banned: 0, deptid: 'eng', kc_username: 'alice', display_name: 'Alice',
      }],
    });
    // Token omits deptid/kc_username/display_name (null per mapper contract).
    const partial = { keycloak_sub: 'kc-sub-1', email: 'alice@example.com', email_verified: true, deptid: null, kc_username: null, display_name: null, user_id: null };
    const out = await jitProvision({ mapped: partial, conn, t, auditInfo: baseAudit });
    assert.strictEqual(resyncUpdatesOf(conn).length, 0, 'no UPDATE for absent claims');
    assert.strictEqual(conn.users[0].deptid, 'eng');
    assert.strictEqual(out.deptid, 'eng');
  });

  it('direct resyncBoundUserClaims: zero drift returns the same object reference', async () => {
    const conn = makeConn();
    const existing = { id: 'u-9', email: 'a@b', deptid: 'eng', kc_username: 'k', display_name: 'D', role: 'admin', banned: 0 };
    const mapped = { email: 'a@b', deptid: 'eng', kc_username: 'k', display_name: 'D' };
    const out = await resyncBoundUserClaims({ existing, mapped, conn, t });
    assert.strictEqual(out, existing);
    assert.strictEqual(conn.queries.length, 0);
  });

  it('(g) mapper email-fallback placeholder never overwrites the stored real email; other columns still sync', async () => {
    const conn = makeConn({
      users: [{
        id: 'u-1', email: 'real@example.com', keycloak_sub: 'kc-sub-1',
        role: 'user', banned: 0, deptid: 'old', kc_username: 'alice', display_name: 'Alice',
      }],
    });
    // A token missing the email claim: mapTokenToUser yields `${sub}@keycloak`.
    const mapped = {
      keycloak_sub: 'kc-sub-1', email: 'kc-sub-1@keycloak', email_verified: true,
      deptid: 'eng', kc_username: 'alice', display_name: 'Alice', user_id: null,
    };
    const out = await jitProvision({ mapped, conn, t, auditInfo: baseAudit });

    // Real email untouched — the placeholder is treated as absent.
    assert.strictEqual(conn.users[0].email, 'real@example.com');
    assert.strictEqual(out.email, 'real@example.com');
    // Other drifted columns still re-sync, in one UPDATE without email.
    const updates = resyncUpdatesOf(conn);
    assert.strictEqual(updates.length, 1);
    assert.ok(!/email = \?/.test(updates[0]), 'placeholder email must not be written');
    assert.match(updates[0], /deptid = \?/);
    assert.strictEqual(conn.users[0].deptid, 'eng');
    // Skip is silent for the placeholder (not the collision WARN path).
    assert.ok(!conn.queries.some((q) => /id != \? LIMIT 1/.test(q.sql)), 'no collision pre-check for a placeholder skip');
  });

  it('(h) guard is an exact per-sub match, not a broad @keycloak suffix block: a differently-shaped @keycloak address still syncs', async () => {
    const conn = makeConn({
      users: [{
        id: 'u-1', email: 'old@example.com', keycloak_sub: 'kc-sub-1',
        role: 'user', banned: 0, deptid: 'eng', kc_username: 'alice', display_name: 'Alice',
      }],
    });
    // `@keycloak` suffix but NOT this sub's placeholder → a genuine value → syncs.
    const mapped = {
      keycloak_sub: 'kc-sub-1', email: 'other-sub@keycloak', email_verified: true,
      deptid: 'eng', kc_username: 'alice', display_name: 'Alice', user_id: null,
    };
    const out = await jitProvision({ mapped, conn, t, auditInfo: baseAudit });
    const updates = resyncUpdatesOf(conn);
    assert.strictEqual(updates.length, 1);
    assert.match(updates[0], /email = \?/, 'a non-placeholder address must still sync');
    assert.strictEqual(conn.users[0].email, 'other-sub@keycloak');
    assert.strictEqual(out.email, 'other-sub@keycloak');
  });

  it('email UNIQUE race: UPDATE-with-email throws ER_DUP_ENTRY, retry drops email, other columns persist, WARN, login succeeds', async () => {
    const conn = makeConn({
      failEmailUpdateOnce: true,
      users: [{
        id: 'u-1', email: 'old@example.com', keycloak_sub: 'kc-sub-1',
        role: 'user', banned: 0, deptid: 'old-dept', kc_username: 'alice', display_name: 'Old',
      }],
    });
    // Both email and deptid drift; the pre-check finds no clash (no other row
    // seeded), so email is included in the first UPDATE — which the mock fails
    // once with ER_DUP_ENTRY to simulate the pre-check→write race.
    const out = await jitProvision({ mapped: baseMapped, conn, t, auditInfo: baseAudit });

    const updates = resyncUpdatesOf(conn);
    assert.strictEqual(updates.length, 2, 'first (with email, throws) + retry (without email)');
    assert.match(updates[0], /email = \?/, 'first attempt includes email');
    assert.ok(!/email = \?/.test(updates[1]), 'retry excludes email');
    // Login succeeded; email untouched, other drift persisted.
    assert.strictEqual(out.id, 'u-1');
    assert.strictEqual(conn.users[0].email, 'old@example.com');
    assert.strictEqual(conn.users[0].deptid, 'eng');
    assert.strictEqual(conn.users[0].display_name, 'Alice');
    assert.strictEqual(out.deptid, 'eng');
    // Structured WARN for the race, carrying userId only (no raw email).
    const warn = logRecords.find((r) => r.level === 'warn' && /UNIQUE race/.test(r.msg));
    assert.ok(warn, 'a UNIQUE-race WARN must be logged');
    assert.strictEqual(warn.obj.userId, 'u-1');
    assert.ok(!JSON.stringify(warn).includes('@'), 'WARN must not contain any email');
  });

  it('(i) unverified email is NOT re-synced (mirrors Step 2 bind gate); other columns still sync', async () => {
    const conn = makeConn({
      users: [{
        id: 'u-1', email: 'old@example.com', keycloak_sub: 'kc-sub-1',
        role: 'user', banned: 0, deptid: 'old-dept', kc_username: 'alice', display_name: 'Alice',
      }],
    });
    // New email present but NOT verified; deptid also drifted.
    const mapped = {
      keycloak_sub: 'kc-sub-1', email: 'new@example.com', email_verified: false,
      deptid: 'eng', kc_username: 'alice', display_name: 'Alice', user_id: null,
    };
    const out = await jitProvision({ mapped, conn, t, auditInfo: baseAudit });

    // Email untouched (unverified), deptid synced.
    assert.strictEqual(conn.users[0].email, 'old@example.com');
    assert.strictEqual(out.email, 'old@example.com');
    assert.strictEqual(conn.users[0].deptid, 'eng');
    const updates = resyncUpdatesOf(conn);
    assert.strictEqual(updates.length, 1);
    assert.ok(!/email = \?/.test(updates[0]), 'unverified email must not be written');
    assert.match(updates[0], /deptid = \?/);
    // Unverified email is skipped before the collision pre-check runs.
    assert.ok(!conn.queries.some((q) => /id != \? LIMIT 1/.test(q.sql)), 'no collision pre-check for an unverified-email skip');
  });

  it('(j) verified email change is re-synced', async () => {
    const conn = makeConn({
      users: [{
        id: 'u-1', email: 'old@example.com', keycloak_sub: 'kc-sub-1',
        role: 'user', banned: 0, deptid: 'eng', kc_username: 'alice', display_name: 'Alice',
      }],
    });
    const mapped = {
      keycloak_sub: 'kc-sub-1', email: 'new@example.com', email_verified: true,
      deptid: 'eng', kc_username: 'alice', display_name: 'Alice', user_id: null,
    };
    const out = await jitProvision({ mapped, conn, t, auditInfo: baseAudit });
    const updates = resyncUpdatesOf(conn);
    assert.strictEqual(updates.length, 1);
    assert.match(updates[0], /email = \?/);
    assert.strictEqual(conn.users[0].email, 'new@example.com');
    assert.strictEqual(out.email, 'new@example.com');
  });
});
