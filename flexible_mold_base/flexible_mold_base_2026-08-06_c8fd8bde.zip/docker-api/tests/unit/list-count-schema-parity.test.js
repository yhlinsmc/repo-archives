/**
 * list-count-schema-parity.test.js — the new SQL this PR introduces is the
 * COUNT companion the paged list read issues, and its WHERE clause is built
 * from each mount's declared filterable columns plus its user-scope column.
 *
 * Every route test in this repo runs against a mocked connection, so a column
 * name that does not exist stays green in both runners and 500s against a real
 * database (the shipped precedent: cap_databases queried by `name` when the
 * display column is `function_name`). This test therefore reads the mount
 * declarations from the routers themselves — by standing in for the CRUD
 * factory while they load, so nothing is transcribed — and checks every column
 * they can put into a predicate against the DDL in table-ddls.js.
 *
 * It covers the row query's predicate as well, because the two are the same
 * fragment by construction; that is the property being protected.
 */
const { describe, it, before } = require('node:test');
const assert = require('node:assert/strict');
const express = require('express');

const dbKey = require.resolve('../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey,
  filename: dbKey,
  loaded: true,
  exports: {
    pool: { ro: {}, rw: {} },
    t: (n) => `fmb_${n}`,
    getDynamicPool: async () => ({ ro: {}, rw: {} }),
  },
};

// Stand in for the factory so that loading the routers records what each mount
// declares. A transcribed copy of these declarations would be the exact kind of
// second source of truth this test exists to make unnecessary.
const MOUNTS = [];
const factoryKey = require.resolve('../../src/edge/routes/app/schema/crud-factory');
require.cache[factoryKey] = {
  id: factoryKey,
  filename: factoryKey,
  loaded: true,
  exports: {
    createCrudRoutes(logicalName, opts = {}) {
      MOUNTS.push({ logicalName: String(logicalName), opts });
      return express.Router();
    },
  },
};

require('../../src/edge/routes/app/schema');
require('../../src/edge/routes/app/api-connectors');
require('../../src/edge/routes/app/flow-recipes');
require('../../src/edge/routes/app/flow-recipe-steps');
require('../../src/edge/routes/app/flow-recipe-runs');
require('../../src/edge/routes/app/capacity');

const { buildEngineTableDDLs } = require('../../src/table-ddls');

const SQL_TYPES = /^`?([a-z_]+)`?\s+(?:CHAR|VARCHAR|INT|DOUBLE|TIMESTAMP|JSON|TEXT|ENUM|BOOLEAN|TINYINT|BIGINT|DATETIME|DECIMAL|FLOAT|BLOB)\b/i;

let columnsByTable;

before(() => {
  columnsByTable = new Map();
  for (const ddl of buildEngineTableDDLs((n) => n)) {
    const m = ddl.match(/CREATE TABLE IF NOT EXISTS `([^`]+)`/);
    if (!m) continue;
    const cols = new Set();
    for (const rawLine of ddl.split('\n')) {
      const line = rawLine.trim();
      if (!line || line.startsWith('--') || line.startsWith('/*')) continue;
      const cm = line.match(SQL_TYPES);
      if (cm) cols.add(cm[1]);
    }
    columnsByTable.set(m[1], cols);
  }
});

describe('paged list COUNT — schema parity of every predicate column', () => {
  it('records a mount for every table the factory serves', () => {
    assert.ok(MOUNTS.length >= 16, `only ${MOUNTS.length} mounts were recorded`);
    const names = new Set(MOUNTS.map((m) => m.logicalName));
    for (const expected of ['user_templates', 'flow_recipe_runs', 'api_connectors', 'cap_sites']) {
      assert.ok(names.has(expected), `mount '${expected}' was not recorded`);
    }
  });

  it('every mounted table has a DDL', () => {
    for (const { logicalName } of MOUNTS) {
      assert.ok(
        columnsByTable.has(logicalName),
        `no DDL in table-ddls.js for mounted table '${logicalName}'`,
      );
    }
  });

  it('every declared filterable column exists — a filter reaches both the rows and the count', () => {
    for (const { logicalName, opts } of MOUNTS) {
      const cols = columnsByTable.get(logicalName);
      for (const col of opts.filterableColumns || []) {
        assert.ok(
          cols.has(col),
          `${logicalName} declares filterable column '${col}', which is not in its DDL`,
        );
      }
    }
  });

  it('every user-scope column exists — it is the predicate that keeps a total honest', () => {
    for (const { logicalName, opts } of MOUNTS) {
      if (!opts.userScopeColumn) continue;
      assert.ok(
        columnsByTable.get(logicalName).has(opts.userScopeColumn),
        `${logicalName} scopes reads on '${opts.userScopeColumn}', which is not in its DDL`,
      );
    }
  });

  it('every write-scope column exists — it is what a paged owner view will filter on', () => {
    for (const { logicalName, opts } of MOUNTS) {
      if (!opts.writeScopeColumn) continue;
      assert.ok(
        columnsByTable.get(logicalName).has(opts.writeScopeColumn),
        `${logicalName} scopes writes on '${opts.writeScopeColumn}', which is not in its DDL`,
      );
    }
  });

  it('every mounted table has created_at — the list orders by it unconditionally', () => {
    for (const { logicalName } of MOUNTS) {
      assert.ok(
        columnsByTable.get(logicalName).has('created_at'),
        `${logicalName} has no created_at, but the list handler always orders by it`,
      );
    }
  });
});
