'use strict';

/**
 * connector-credentials-real-db.test.js — the stored bytes of a credential.
 *
 * Every case here reads the row back and asserts on what the COLUMN holds. A
 * status code cannot tell these defects apart from working software: the API
 * masks a secret on read, so a connector whose token is intact and one whose
 * token has just been overwritten with `{}` return the SAME response body. The
 * only witness is the stored ciphertext, compared byte for byte across the
 * request under test.
 *
 * It runs on a real database because the premise is the database's answer. The
 * column is `auth_type ENUM('none','bearer','api_key','basic')`, and the engine
 * folds `'Bearer'`, `'BEARER'`, `'bearer '` and the ordinal `2` into the single
 * stored member `'bearer'` — while `SENSITIVE_PATHS['Bearer']` is `undefined`,
 * so JavaScript concludes the connector has no secret at all. A stubbed driver
 * answers whichever half the fixture was told to say and cannot show the two
 * disagreeing.
 *
 * Skips with a stated reason when no database is reachable, and fails instead
 * of skipping when REQUIRE_INTEGRATION_DB=1.
 */
const { test, describe, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const net = require('node:net');
const http = require('node:http');
const express = require('express');
const mariadb = require('mariadb');

// The encryption key must exist before the serializers are required: each warns
// once at load when it is absent, and `encrypt()` is fail-closed without it, so
// every secret-carrying save would answer 422 instead of storing ciphertext.
process.env.SETTINGS_ENCRYPTION_KEY = process.env.SETTINGS_ENCRYPTION_KEY
  || 'connector-credentials-real-db-test-key';

const TEST_PREFIX = 'ccred_';
const tbl = (name) => `${TEST_PREFIX}${name}`;

let pool = null;
// Off for every other case in this file, so nothing below is leased through a
// connection that answers differently from the one production leases. The one
// describe that turns it on says why it has to.
let hideColumnMetadata = false;
/**
 * The same connection, with the column-metadata probe answering NO ROWS.
 *
 * `getActualColumnSet` returns null for three situations — the probe threw, it
 * returned no rows, or it returned rows carrying no usable names — and null
 * means UNKNOWN, not "the column is absent". This reproduces the middle one,
 * which is what a database account with no `information_schema` reach for this
 * table gives every request. Everything else on the connection is the real
 * thing, so the row, the statement and the stored bytes are still the
 * database's answer.
 *
 * A Proxy rather than a hand-written wrapper: the surface a leased connection
 * has to keep is whatever the factory calls on it, and a listed one is a list
 * that goes stale silently.
 */
function withHiddenColumnMetadata(conn) {
  return new Proxy(conn, {
    get(target, prop) {
      if (prop === 'query') {
        return (sql, params) => (
          /information_schema\.COLUMNS/i.test(String(sql))
            ? Promise.resolve([])
            : target.query(sql, params)
        );
      }
      const value = target[prop];
      return typeof value === 'function' ? value.bind(target) : value;
    },
  });
}
const lease = async () => {
  const conn = await pool.getConnection();
  return hideColumnMetadata ? withHiddenColumnMetadata(conn) : conn;
};
const query = (sql, params) => pool.query(sql, params);
const poolFacade = { getConnection: lease, query };

const dbKey = require.resolve('../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey,
  filename: dbKey,
  loaded: true,
  exports: {
    pool: { ro: poolFacade, rw: poolFacade },
    t: tbl,
    getDynamicPool: async () => ({ ro: poolFacade, rw: poolFacade }),
  },
};

const { buildEngineTableDDLs, buildInfraTableDDLs } = require('../../src/table-ddls');
const { TABLES } = require('../../src/shared/constants');
// The process-wide memo of "which columns does this table actually have". It
// caches its NULL, so a case that forces the probe to answer unknown has to be
// able to undo that for the cases after it.
const { _columnSetCache } = require('../../src/edge/routes/app/schema/helpers');
const connectorsRouter = require('../../src/edge/routes/app/api-connectors');
const stepsRouter = require('../../src/edge/routes/app/flow-recipe-steps');
const recipesRouter = require('../../src/edge/routes/app/flow-recipes');

const { fixtureUserId } = require('../helpers/fixture-ids');

// ── Config auto-detection (same shape as the sibling integration tests) ──────

function parseEnvFile(filePath) {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    const out = {};
    for (const line of content.split('\n')) {
      const m = line.match(/^\s*([A-Z_][A-Z0-9_]*)\s*=\s*(.*)\s*$/);
      if (!m) continue;
      let value = m[2];
      if ((value.startsWith('"') && value.endsWith('"'))
        || (value.startsWith("'") && value.endsWith("'"))) {
        value = value.slice(1, -1);
      }
      out[m[1]] = value;
    }
    return out;
  } catch {
    return null;
  }
}

function probePort(host, port, timeoutMs = 2000) {
  return new Promise((resolve) => {
    const socket = new net.Socket();
    let done = false;
    const finish = (ok) => {
      if (done) return;
      done = true;
      socket.destroy();
      resolve(ok);
    };
    socket.setTimeout(timeoutMs);
    socket.once('connect', () => finish(true));
    socket.once('timeout', () => finish(false));
    socket.once('error', () => finish(false));
    socket.connect(port, host);
  });
}

async function resolveMariaDbConfig() {
  if (process.env.DB_TEST_HOST && process.env.DB_TEST_ROOT_PASSWORD) {
    return {
      host: process.env.DB_TEST_HOST,
      port: parseInt(process.env.DB_TEST_PORT || '3306', 10),
      user: 'root',
      password: process.env.DB_TEST_ROOT_PASSWORD,
    };
  }
  const envPath = path.resolve(__dirname, '../../../.devcontainer/.env');
  const env = parseEnvFile(envPath);
  if (!env || !env.DB_ROOT_PASSWORD) return null;
  const port = parseInt(env.DB_PORT || '3306', 10);
  for (const host of ['127.0.0.1', 'mariadb', 'localhost']) {
    if (await probePort(host, port, 2000)) {
      return { host, port, user: 'root', password: env.DB_ROOT_PASSWORD };
    }
  }
  return null;
}

// ── Fixture ─────────────────────────────────────────────────────────────────

const EDITOR = { id: fixtureUserId('editor'), role: 'editor' };
const ADMIN = { id: fixtureUserId('admin'), role: 'admin' };

const WANTED_TABLES = [
  TABLES.API_CONNECTORS,
  TABLES.FLOW_RECIPE_STEPS,
  TABLES.FLOW_RECIPES,
  TABLES.FLOW_RECIPE_CODE_VERSIONS,
  TABLES.HIERARCHY_NODES,
  TABLES.SYSTEM_SETTINGS,
  TABLES.FEATURE_AUDIT,
  TABLES.USERS,
];

let dbReady = false;
let skipReason = null;
let testDbName = null;
let server = null;
let baseUrl = null;
let currentUser = ADMIN;
let sharedBlueprintId = null;

before(async () => {
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) {
    skipReason = 'no MariaDB reachable via .devcontainer/.env or env vars';
    if (process.env.REQUIRE_INTEGRATION_DB === '1') {
      throw new Error(`REQUIRE_INTEGRATION_DB=1 set but ${skipReason}.`);
    }
    return;
  }
  testDbName = `conn_cred_test_${process.pid}_${Date.now()}`;
  let admin = null;
  try {
    admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`CREATE DATABASE \`${testDbName}\``);
    await admin.query(`USE \`${testDbName}\``);
    const wanted = new Set(WANTED_TABLES.map(tbl));
    const statements = [...buildInfraTableDDLs(tbl), ...buildEngineTableDDLs(tbl)].filter((sql) => {
      const m = sql.match(/CREATE TABLE IF NOT EXISTS `([^`]+)`/);
      return m && wanted.has(m[1]);
    });
    assert.equal(
      statements.length, wanted.size,
      `the DDL list no longer defines all of: ${[...wanted].join(', ')}`,
    );
    for (const sql of statements) await admin.query(sql);
    await admin.end();
    admin = null;

    pool = mariadb.createPool({
      ...dbConfig, database: testDbName, connectionLimit: 6, connectTimeout: 5000,
    });

    const app = express();
    app.use(express.json());
    app.use((req, _res, next) => { req.user = currentUser; next(); });
    app.use('/edge/app/api-connectors', connectorsRouter);
    app.use('/edge/app/flow-recipe-steps', stepsRouter);
    app.use('/edge/app/flow-recipes', recipesRouter);
    server = http.createServer(app);
    await new Promise((r) => server.listen(0, r));
    baseUrl = `http://127.0.0.1:${server.address().port}`;
    dbReady = true;
  } catch (err) {
    skipReason = `setup failed: ${err.message}`;
    if (admin) { try { await admin.end(); } catch { /* best effort */ } }
    if (process.env.REQUIRE_INTEGRATION_DB === '1') throw err;
  }
});

after(async () => {
  if (server) { try { server.close(); } catch { /* best effort */ } }
  if (pool) { try { await pool.end(); } catch { /* best effort */ } }
  if (!testDbName) return;
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) return;
  try {
    const admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`DROP DATABASE IF EXISTS \`${testDbName}\``);
    await admin.end();
  } catch { /* best effort */ }
});

const guard = (t) => {
  if (!dbReady) { t.skip(skipReason || 'database not ready'); return true; }
  return false;
};

async function call(user, method, url, body) {
  currentUser = user;
  const res = await fetch(`${baseUrl}${url}`, {
    method,
    headers: { 'content-type': 'application/json' },
    ...(body === undefined ? {} : { body: JSON.stringify(body) }),
  });
  const text = await res.text();
  let parsed = null;
  try { parsed = JSON.parse(text); } catch { parsed = { raw: text }; }
  return { status: res.status, body: parsed };
}

// The connector shape used everywhere below. `url` is on no allow-list, which
// is allow-all (the settings row is absent), and the blueprint is shared so an
// editor may bind to it.
const connectorBody = (over = {}) => ({
  name: 'cred-fixture',
  blueprint_id: sharedBlueprintId,
  method: 'GET',
  url: 'https://upstream.test/v1/resource',
  auth_type: 'bearer',
  auth_config: { token: 'the-real-token' },
  ...over,
});

async function storedConnector(id) {
  const rows = await query(
    `SELECT id, auth_type, auth_config, url, request_config, status, group_id,
            group_label, group_mode, \`sequence\`
       FROM \`${tbl(TABLES.API_CONNECTORS)}\` WHERE id = ?`,
    [id],
  );
  return rows[0] || null;
}

async function storedStep(id) {
  const rows = await query(
    `SELECT id, auth_type, auth_config FROM \`${tbl(TABLES.FLOW_RECIPE_STEPS)}\` WHERE id = ?`,
    [id],
  );
  return rows[0] || null;
}

// The bytes the column holds, as a string, regardless of whether this driver
// hands a JSON column back parsed or raw.
const authConfigBytes = (row) => (
  row == null || row.auth_config == null
    ? null
    : (typeof row.auth_config === 'string' ? row.auth_config : JSON.stringify(row.auth_config))
);

beforeEach(async () => {
  if (!dbReady) return;
  await query(`DELETE FROM \`${tbl(TABLES.API_CONNECTORS)}\``);
  await query(`DELETE FROM \`${tbl(TABLES.FLOW_RECIPE_STEPS)}\``);
  await query(`DELETE FROM \`${tbl(TABLES.FLOW_RECIPE_CODE_VERSIONS)}\``);
  await query(`DELETE FROM \`${tbl(TABLES.FLOW_RECIPES)}\``);
  await query(`DELETE FROM \`${tbl(TABLES.HIERARCHY_NODES)}\``);
  await query(`DELETE FROM \`${tbl(TABLES.FEATURE_AUDIT)}\``);
  sharedBlueprintId = '11111111-1111-4111-8111-111111111111';
  await query(
    `INSERT INTO \`${tbl(TABLES.HIERARCHY_NODES)}\` (id, name, node_type, owner_id)
     VALUES (?, 'shared-blueprint', 'blueprint', NULL)`,
    [sharedBlueprintId],
  );
});

async function createConnector(user = ADMIN, over = {}) {
  const res = await call(user, 'POST', '/edge/app/api-connectors', connectorBody(over));
  assert.equal(res.status, 200, `fixture create was refused: ${JSON.stringify(res.body)}`);
  return res.body.data.id;
}

async function createRecipeWithStep(over = {}) {
  const recipeId = '22222222-2222-4222-8222-222222222222';
  await query(
    `INSERT INTO \`${tbl(TABLES.FLOW_RECIPES)}\` (id, name, blueprint_id, owner_id, status)
     VALUES (?, 'cred-recipe', ?, NULL, 'approved')`,
    [recipeId, sharedBlueprintId],
  );
  const res = await call(ADMIN, 'POST', '/edge/app/flow-recipe-steps', {
    recipe_id: recipeId,
    name: 'cred-step',
    method: 'POST',
    url: 'https://upstream.test/v1/step',
    auth_type: 'bearer',
    auth_config: { token: 'the-real-step-token' },
    ...over,
  });
  assert.equal(res.status, 200, `fixture step create was refused: ${JSON.stringify(res.body)}`);
  return { recipeId, stepId: res.body.data.id };
}

// The spellings this column folds into `'bearer'` while `SENSITIVE_PATHS`
// resolves none of them. `2` is the 1-based ENUM member index of 'bearer'.
const FOLDING_SPELLINGS = [
  ["'Bearer'", 'Bearer'],
  ["'BEARER'", 'BEARER'],
  ["'bearer ' (trailing space)", 'bearer '],
  ['2 (the ENUM member index of bearer)', 2],
];

describe('the value that decides which leaf is a secret', () => {
  test('the database folds every one of these spellings into the stored member', async (t) => {
    if (guard(t)) return;
    // THE PREMISE, MEASURED, written straight to the column with no router in
    // the way — so the fold is shown to be the DATABASE's. If a later collation
    // or column change stops folding them, this is the assertion that says so,
    // next to the refusals that depend on it.
    for (const [label, sent] of FOLDING_SPELLINGS) {
      const id = `33333333-3333-4333-8333-${String(FOLDING_SPELLINGS.indexOf(sent) + 1).padStart(12, '0')}`;
      await query(`DELETE FROM \`${tbl(TABLES.API_CONNECTORS)}\``);
      await query(
        `INSERT INTO \`${tbl(TABLES.API_CONNECTORS)}\` (id, name, url, auth_type)
         VALUES (?, 'raw', 'https://upstream.test/x', ?)`,
        [id, sent],
      );
      const row = await storedConnector(id);
      assert.equal(row.auth_type, 'bearer', `this database no longer folds ${label} to 'bearer'`);
    }
  });

  for (const [label, spelling] of FOLDING_SPELLINGS) {
    test(`a connector's stored token survives a PUT spelling the type ${label}`, async (t) => {
      if (guard(t)) return;
      // THE CREDENTIAL-DESTRUCTION ROW. `pathsFor(<this spelling>)` is `[]`, so
      // the mask is never resolved, `stripStraySecretLeaves` deletes the token
      // because nothing is sanctioned, and `auth_config = '{}'` is written over
      // the ciphertext — 200 OK, and the masked read looks identical either way.
      // The assertion is therefore the stored bytes, before and after.
      const id = await createConnector();
      const before = authConfigBytes(await storedConnector(id));
      assert.match(before, /enc:v1:/, 'the fixture did not store an encrypted token');

      const res = await call(ADMIN, 'PUT', `/edge/app/api-connectors/${id}`, {
        auth_type: spelling,
        auth_config: { token: '****' },
      });

      const after = authConfigBytes(await storedConnector(id));
      assert.equal(
        after, before,
        `spelling the type ${label} changed the stored credential (PUT ${res.status})`,
      );
      assert.equal(res.status, 400, `expected a stable refusal, got ${JSON.stringify(res.body)}`);
      assert.equal(res.body.error.code, 'INVALID_COLUMN_VALUE');
    });

    test(`a connector create spelling the type ${label} does not discard the typed secret`, async (t) => {
      if (guard(t)) return;
      // The create direction of the same row: the operator types a real secret,
      // the strip runs against an empty sanctioned set, and `{}` is stored with
      // a 201. Either the create is refused, or the secret is stored encrypted —
      // silently keeping neither is the defect.
      const res = await call(ADMIN, 'POST', '/edge/app/api-connectors', connectorBody({
        auth_type: spelling,
        auth_config: { token: 'a-secret-the-operator-typed' },
      }));
      const rows = await query(`SELECT id, auth_type, auth_config FROM \`${tbl(TABLES.API_CONNECTORS)}\``);
      if (res.status === 200) {
        assert.equal(rows.length, 1);
        assert.match(
          authConfigBytes(rows[0]) || '', /enc:v1:/,
          `spelling the type ${label} stored a bearer connector with no credential`,
        );
      } else {
        assert.equal(res.status, 400, `expected a stable refusal, got ${JSON.stringify(res.body)}`);
        assert.equal(res.body.error.code, 'INVALID_COLUMN_VALUE');
        assert.equal(rows.length, 0, 'a refused create left a connector behind');
      }
    });

    test(`a recipe step's stored token survives a PUT spelling the type ${label}`, async (t) => {
      if (guard(t)) return;
      // The twin mount, whose serializer has a SECOND entry point api_connectors
      // does not have: a body carrying auth_type and no auth_config at all loads
      // the stored config and cleans it against the new type — with an unresolved
      // spelling the sanctioned set is empty, so the stored token is stripped and
      // re-persisted as `{}`. Both request shapes are asserted here.
      const { stepId } = await createRecipeWithStep();
      const before = authConfigBytes(await storedStep(stepId));
      assert.match(before, /enc:v1:/, 'the fixture did not store an encrypted step token');

      const withConfig = await call(ADMIN, 'PUT', `/edge/app/flow-recipe-steps/${stepId}`, {
        auth_type: spelling,
        auth_config: { token: '****' },
      });
      assert.equal(
        authConfigBytes(await storedStep(stepId)), before,
        `spelling the type ${label} changed the stored step credential (PUT ${withConfig.status})`,
      );
      assert.equal(withConfig.status, 400, `expected a stable refusal, got ${JSON.stringify(withConfig.body)}`);

      const typeOnly = await call(ADMIN, 'PUT', `/edge/app/flow-recipe-steps/${stepId}`, {
        auth_type: spelling,
      });
      assert.equal(
        authConfigBytes(await storedStep(stepId)), before,
        `a type-only PUT spelling ${label} changed the stored step credential (PUT ${typeOnly.status})`,
      );
      assert.equal(typeOnly.status, 400, `expected a stable refusal, got ${JSON.stringify(typeOnly.body)}`);
    });
  }

  test('a type naming an Object.prototype member is refused, not a 500', async (t) => {
    if (guard(t)) return;
    // `SENSITIVE_PATHS['constructor']` resolves the INHERITED property — a
    // Function — and the `|| []` fallback never fires because a Function is
    // truthy, so the leaf transform throws a bare TypeError and the factory's
    // catch-all reports it as a server fault. The column could never store the
    // value either way; what this pins is the shape of the answer.
    for (const spelling of ['constructor', '__proto__', 'toString', 'hasOwnProperty']) {
      const res = await call(ADMIN, 'POST', '/edge/app/api-connectors', connectorBody({
        auth_type: spelling,
        auth_config: { token: 'x' },
      }));
      assert.equal(res.status, 400, `${spelling}: expected a stable 400, got ${JSON.stringify(res.body)}`);
      assert.equal(res.body.error.code, 'INVALID_COLUMN_VALUE', `${spelling}: wrong code`);
    }
    const rows = await query(`SELECT id FROM \`${tbl(TABLES.API_CONNECTORS)}\``);
    assert.equal(rows.length, 0, 'a refused create left a connector behind');
  });

  test('the canonical spellings still save and still store an encrypted secret', async (t) => {
    if (guard(t)) return;
    // The other half of a gate: what it must NOT refuse. Every declared member,
    // through the ordinary path, with the secret leaf each one sanctions.
    const cases = [
      ['none', {}, null],
      ['bearer', { token: 'tok' }, 'token'],
      ['api_key', { header: 'X-Api-Key', value: 'val' }, 'value'],
      ['basic', { username: 'u', password: 'p' }, 'password'],
    ];
    for (const [authType, authConfig, secretLeaf] of cases) {
      await query(`DELETE FROM \`${tbl(TABLES.API_CONNECTORS)}\``);
      const res = await call(ADMIN, 'POST', '/edge/app/api-connectors', connectorBody({
        auth_type: authType, auth_config: authConfig,
      }));
      assert.equal(res.status, 200, `${authType} was refused: ${JSON.stringify(res.body)}`);
      const row = await storedConnector(res.body.data.id);
      assert.equal(row.auth_type, authType);
      if (secretLeaf) {
        const stored = JSON.parse(authConfigBytes(row));
        assert.match(stored[secretLeaf], /^enc:v1:/, `${authType}: the secret leaf was not encrypted`);
      }
    }
  });
});

// The state the engine can actually leave behind, produced the way it happens:
// under a non-strict `sql_mode` an ENUM assignment naming no member stores the
// invalid member `''` (ordinal 0) with warning 1265. Written on a leased
// connection whose mode is restored afterwards, so no later test inherits it.
async function forceStoredAuthType(table, id, raw) {
  const conn = await lease();
  let restore = null;
  try {
    restore = (await conn.query('SELECT @@session.sql_mode AS m'))[0].m;
    await conn.query('SET SESSION sql_mode = ?', ['']);
    await conn.query(
      `UPDATE \`${tbl(table)}\` SET auth_type = ? WHERE id = ?`, [raw, id],
    );
  } finally {
    if (restore !== null) {
      try { await conn.query('SET SESSION sql_mode = ?', [restore]); } catch { /* best effort */ }
    }
    conn.release();
  }
}

describe('the type a partial update resolves its leaf from is the STORED one, so that is judged too', () => {
  test('the engine stores the invalid member for an undeclared assignment', async (t) => {
    if (guard(t)) return;
    // THE PREMISE, MEASURED. Everything below is about a row in this state, so
    // if a future engine/mode change stops producing it, this says so first.
    const id = await createConnector();
    await forceStoredAuthType(TABLES.API_CONNECTORS, id, 'Zzz-not-a-member');
    const row = await storedConnector(id);
    assert.equal(row.auth_type, '', 'this database no longer stores the invalid ENUM member');
  });

  test("a partial PUT cannot destroy the credential of a row whose stored type is out of domain", async (t) => {
    if (guard(t)) return;
    // THE ROW THE MOUNT GATE CANNOT SEE. `refuseUndeclaredAuthType` judges the
    // BODY's auth_type and this body carries none — the effective type comes off
    // the stored row, `pathsFor('')` is `[]`, and every transform reads that as
    // "this row has no secret": the mask is never resolved, the stray strip
    // deletes the token, and `{}` lands over the ciphertext with a 200.
    const id = await createConnector();
    await forceStoredAuthType(TABLES.API_CONNECTORS, id, 'Zzz-not-a-member');
    const before = authConfigBytes(await storedConnector(id));
    assert.match(before, /enc:v1:/, 'the fixture did not store an encrypted token');

    const res = await call(ADMIN, 'PUT', `/edge/app/api-connectors/${id}`, {
      name: 'edited', auth_config: { token: '****' },
    });

    assert.equal(
      authConfigBytes(await storedConnector(id)), before,
      `the stored credential was rewritten (PUT ${res.status})`,
    );
    assert.equal(res.status, 409, `expected a refusal, got ${JSON.stringify(res.body)}`);
    assert.equal(res.body.error?.code, 'STORED_AUTH_TYPE_UNREADABLE');
  });

  test('a replacement secret sent to such a row is refused, not silently dropped', async (t) => {
    if (guard(t)) return;
    // WORSE THAN THE LOSS ITSELF. The operator noticing the credential is wrong
    // and typing a new one got a 200 and an empty column — the repair dropped
    // with the same silence. A refusal that names the remedy is the only answer
    // that does not lie about what was stored.
    const id = await createConnector();
    await forceStoredAuthType(TABLES.API_CONNECTORS, id, 'Zzz-not-a-member');
    const before = authConfigBytes(await storedConnector(id));

    const res = await call(ADMIN, 'PUT', `/edge/app/api-connectors/${id}`, {
      auth_config: { token: 'brand-new-secret' },
    });

    assert.equal(res.status, 409, `expected a refusal, got ${JSON.stringify(res.body)}`);
    assert.equal(
      authConfigBytes(await storedConnector(id)), before,
      'a refused write changed the column anyway',
    );
    assert.match(
      String(res.body.error?.message), /auth_type/,
      'the refusal does not name the column the operator has to send',
    );
  });

  test('naming the type repairs the row in one save', async (t) => {
    if (guard(t)) return;
    // THE WAY OUT, asserted rather than asserted-about. The refusal above is
    // only acceptable because this request exists and works.
    const id = await createConnector();
    await forceStoredAuthType(TABLES.API_CONNECTORS, id, 'Zzz-not-a-member');

    const res = await call(ADMIN, 'PUT', `/edge/app/api-connectors/${id}`, {
      auth_type: 'bearer', auth_config: { token: 'repaired-secret' },
    });

    assert.equal(res.status, 200, `the repair was refused: ${JSON.stringify(res.body)}`);
    const row = await storedConnector(id);
    assert.equal(row.auth_type, 'bearer', 'the type was not repaired');
    const stored = JSON.parse(authConfigBytes(row));
    assert.match(stored.token, /^enc:v1:/, 'the replacement secret was not stored encrypted');
  });

  test('an edit that names neither auth column still works on such a row', async (t) => {
    if (guard(t)) return;
    // The control on the refusal's reach: a guard about `auth_config` must not
    // make an out-of-domain row uneditable in every other respect.
    const id = await createConnector();
    await forceStoredAuthType(TABLES.API_CONNECTORS, id, 'Zzz-not-a-member');
    const before = authConfigBytes(await storedConnector(id));

    const res = await call(ADMIN, 'PUT', `/edge/app/api-connectors/${id}`, { name: 'renamed' });

    assert.equal(res.status, 200, `an ordinary edit was refused: ${JSON.stringify(res.body)}`);
    assert.equal(
      authConfigBytes(await storedConnector(id)), before,
      'an edit naming no auth column changed the credential',
    );
  });

  test('a masked PUT on a row whose stored type IS a member still preserves the secret', async (t) => {
    if (guard(t)) return;
    // The control the whole guard is measured against: the ordinary partial
    // update must go on resolving `****` to the stored ciphertext.
    const id = await createConnector();
    const before = authConfigBytes(await storedConnector(id));

    const res = await call(ADMIN, 'PUT', `/edge/app/api-connectors/${id}`, {
      name: 'edited', auth_config: { token: '****' },
    });

    assert.equal(res.status, 200, `the edit was refused: ${JSON.stringify(res.body)}`);
    assert.equal(
      authConfigBytes(await storedConnector(id)), before,
      'the mask did not resolve to the stored ciphertext',
    );
  });

  test("a step's credential is protected by the same rule", async (t) => {
    if (guard(t)) return;
    // THE MIRROR. The step serializer is the same code on the same column, and
    // "fixed on one lane, left on the other" is the shape this card exists for.
    const { stepId } = await createRecipeWithStep();
    await forceStoredAuthType(TABLES.FLOW_RECIPE_STEPS, stepId, 'Zzz-not-a-member');
    const before = authConfigBytes(await storedStep(stepId));
    assert.match(before, /enc:v1:/, 'the fixture did not store an encrypted step token');

    const res = await call(ADMIN, 'PUT', `/edge/app/flow-recipe-steps/${stepId}`, {
      auth_config: { token: '****' },
    });

    assert.equal(
      authConfigBytes(await storedStep(stepId)), before,
      `the stored step credential was rewritten (PUT ${res.status})`,
    );
    assert.equal(res.status, 409, `expected a refusal, got ${JSON.stringify(res.body)}`);

    const repair = await call(ADMIN, 'PUT', `/edge/app/flow-recipe-steps/${stepId}`, {
      auth_type: 'bearer', auth_config: { token: 'repaired-step-secret' },
    });
    assert.equal(repair.status, 200, `the step repair was refused: ${JSON.stringify(repair.body)}`);
    assert.match(
      JSON.parse(authConfigBytes(await storedStep(stepId))).token, /^enc:v1:/,
      'the step repair did not store an encrypted secret',
    );
  });
});

describe('one representation cannot carry a secret the other says is not there', () => {
  // A row already in the state a type change used to leave behind: the type says
  // 'none', the column still physically holds the bearer ciphertext. Written
  // directly so the case survives the write-path fix — the rows this shape
  // produced are already in deployed databases, and the read is what serves them.
  async function seedStrayLeafRow(id, ciphertext) {
    await query(
      `INSERT INTO \`${tbl(TABLES.API_CONNECTORS)}\`
         (id, name, owner_id, blueprint_id, url, auth_type, auth_config, status)
       VALUES (?, 'legacy-stray', ?, ?, 'https://upstream.test/v1/resource', 'none', ?, 'approved')`,
      [id, ADMIN.id, sharedBlueprintId, JSON.stringify({ token: ciphertext })],
    );
  }

  test('changing the type clears the leaf the new type says is not there', async (t) => {
    if (guard(t)) return;
    // A canonical, no-trick PUT. The serializer used to opt out entirely when the
    // body carried no `auth_config`, so the bearer ciphertext stayed in the
    // column while the row now claimed to have no credential — and the read
    // masked nothing for the new type, so it came back verbatim to every admin
    // AND every editor, on a mount that is view-all by design.
    const id = await createConnector();
    assert.match(authConfigBytes(await storedConnector(id)), /enc:v1:/);

    const res = await call(ADMIN, 'PUT', `/edge/app/api-connectors/${id}`, { auth_type: 'none' });
    assert.equal(res.status, 200, `a canonical type change was refused: ${JSON.stringify(res.body)}`);

    const stored = JSON.parse(authConfigBytes(await storedConnector(id)) || '{}');
    assert.equal(
      Object.prototype.hasOwnProperty.call(stored, 'token'), false,
      'the previous type\'s ciphertext is still in the column',
    );
  });

  test('the same on the step mount, which already had the branch', async (t) => {
    if (guard(t)) return;
    // The sibling this behaviour was copied from — asserted here so closing the
    // gap on one mount cannot quietly open it on the other.
    const { stepId } = await createRecipeWithStep();
    assert.match(authConfigBytes(await storedStep(stepId)), /enc:v1:/);

    const res = await call(ADMIN, 'PUT', `/edge/app/flow-recipe-steps/${stepId}`, { auth_type: 'none' });
    assert.equal(res.status, 200, `a canonical type change was refused: ${JSON.stringify(res.body)}`);

    const stored = JSON.parse(authConfigBytes(await storedStep(stepId)) || '{}');
    assert.equal(Object.prototype.hasOwnProperty.call(stored, 'token'), false);
  });

  test('a row already carrying a stray leaf never returns it through a read', async (t) => {
    if (guard(t)) return;
    // The half a write-path fix cannot reach. Masking asked what the CURRENT type
    // sanctions, and 'none' sanctions nothing, so the leaf went out untouched.
    const id = '44444444-4444-4444-8444-444444444444';
    const ciphertext = 'enc:v1:aaaaaaaaaaaaaaaaaaaaaaaa:bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb:cccccccccccc';
    await seedStrayLeafRow(id, ciphertext);

    for (const [label, res] of [
      ['single', await call(EDITOR, 'GET', `/edge/app/api-connectors/${id}`)],
      ['list', await call(EDITOR, 'GET', '/edge/app/api-connectors')],
    ]) {
      assert.equal(res.status, 200, `${label}: ${JSON.stringify(res.body)}`);
      assert.equal(
        JSON.stringify(res.body).includes(ciphertext), false,
        `${label}: the read returned the stray ciphertext verbatim`,
      );
    }
  });

  test('a clone does not carry a stray leaf into the row it creates', async (t) => {
    if (guard(t)) return;
    // Clone is the one secret-carrying path whose whole purpose is to copy the
    // ciphertext, and it was the only one that did not strip stray leaves first
    // — so a row left in the state above was duplicated into a second row, and
    // the leak followed the copy.
    const sourceId = '55555555-5555-4555-8555-555555555555';
    const ciphertext = 'enc:v1:dddddddddddddddddddddddd:eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee:ffffffffffff';
    await seedStrayLeafRow(sourceId, ciphertext);

    const res = await call(ADMIN, 'POST', `/edge/app/api-connectors/${sourceId}/clone`, {});
    assert.equal(res.status, 201, `the clone was refused: ${JSON.stringify(res.body)}`);

    const clone = await storedConnector(res.body.data.id);
    const stored = JSON.parse(authConfigBytes(clone) || '{}');
    assert.equal(
      Object.prototype.hasOwnProperty.call(stored, 'token'), false,
      'the clone copied a secret leaf its own type says is not there',
    );
  });

  test('a clone of a healthy connector still copies a working credential', async (t) => {
    if (guard(t)) return;
    // The control for the strip. Clone exists so the duplicate is immediately
    // usable without re-entering credentials; a fix that stripped the SANCTIONED
    // leaf too would satisfy the case above and remove the feature.
    const sourceId = await createConnector();
    const before = JSON.parse(authConfigBytes(await storedConnector(sourceId)));

    const res = await call(ADMIN, 'POST', `/edge/app/api-connectors/${sourceId}/clone`, {});
    assert.equal(res.status, 201, `the clone was refused: ${JSON.stringify(res.body)}`);

    const clone = await storedConnector(res.body.data.id);
    assert.equal(clone.auth_type, 'bearer');
    assert.equal(
      JSON.parse(authConfigBytes(clone)).token, before.token,
      'the clone no longer carries the source credential',
    );
  });
});

describe('"unchanged" is decided against the row the statement will update', () => {
  // A concurrent, committed change to the stored credential, interleaved so the
  // outcome depends on WHICH connection the mask is resolved against. The other
  // transaction holds the row while the PUT is in flight and commits a different
  // ciphertext; a mask-preserve that read an unsynchronised snapshot beforehand
  // writes the value it saw back over that commit, silently reverting it — and
  // the same read MISSING (replica lag, a row created moments earlier) drops the
  // leaf entirely, which is how "keep what is stored" deletes a credential.
  async function withConcurrentCommit(table, id, nextCiphertext, fire) {
    const other = await pool.getConnection();
    let inflight;
    try {
      await other.beginTransaction();
      await other.query(`SELECT id FROM \`${table}\` WHERE id = ? FOR UPDATE`, [id]);
      await other.query(
        `UPDATE \`${table}\` SET auth_config = ? WHERE id = ?`,
        [JSON.stringify({ token: nextCiphertext }), id],
      );
      inflight = fire();
      // Long enough that a read taken outside this transaction has certainly
      // happened and certainly missed the uncommitted value.
      await new Promise((r) => setTimeout(r, 150));
      await other.commit();
    } finally {
      other.release();
    }
    return inflight;
  }

  test('a masked connector secret preserves what the row holds at write time', async (t) => {
    if (guard(t)) return;
    const id = await createConnector();
    const committed = 'enc:v1:111111111111111111111111:22222222222222222222222222222222:333333333333';

    const inflight = await withConcurrentCommit(
      tbl(TABLES.API_CONNECTORS), id, committed,
      () => call(ADMIN, 'PUT', `/edge/app/api-connectors/${id}`, {
        auth_type: 'bearer',
        auth_config: { token: '****' },
      }),
    );
    const res = await inflight;
    assert.equal(res.status, 200, `the masked save was refused: ${JSON.stringify(res.body)}`);

    assert.equal(
      JSON.parse(authConfigBytes(await storedConnector(id))).token, committed,
      'the mask was resolved against a snapshot the write then overwrote',
    );
  });

  test('a masked step secret preserves what the row holds at write time', async (t) => {
    if (guard(t)) return;
    const { stepId } = await createRecipeWithStep();
    const committed = 'enc:v1:444444444444444444444444:55555555555555555555555555555555:666666666666';

    const inflight = await withConcurrentCommit(
      tbl(TABLES.FLOW_RECIPE_STEPS), stepId, committed,
      () => call(ADMIN, 'PUT', `/edge/app/flow-recipe-steps/${stepId}`, {
        auth_type: 'bearer',
        auth_config: { token: '****' },
      }),
    );
    const res = await inflight;
    assert.equal(res.status, 200, `the masked save was refused: ${JSON.stringify(res.body)}`);

    assert.equal(
      JSON.parse(authConfigBytes(await storedStep(stepId))).token, committed,
      'the mask was resolved against a snapshot the write then overwrote',
    );
  });

  test('an ordinary masked save with nothing concurrent still keeps the secret', async (t) => {
    if (guard(t)) return;
    // The control. Moving the read onto the write connection must not change the
    // uncontended path, which is every real save: `****` still means "keep what
    // is stored", and a real new secret still replaces it.
    const id = await createConnector();
    const before = JSON.parse(authConfigBytes(await storedConnector(id))).token;

    const kept = await call(ADMIN, 'PUT', `/edge/app/api-connectors/${id}`, {
      name: 'renamed', auth_type: 'bearer', auth_config: { token: '****' },
    });
    assert.equal(kept.status, 200, `the masked save was refused: ${JSON.stringify(kept.body)}`);
    assert.equal(JSON.parse(authConfigBytes(await storedConnector(id))).token, before);

    const replaced = await call(ADMIN, 'PUT', `/edge/app/api-connectors/${id}`, {
      auth_type: 'bearer', auth_config: { token: 'a-brand-new-token' },
    });
    assert.equal(replaced.status, 200, `a real rotation was refused: ${JSON.stringify(replaced.body)}`);
    const after = JSON.parse(authConfigBytes(await storedConnector(id))).token;
    assert.match(after, /^enc:v1:/, 'the rotated secret was not encrypted');
    assert.notEqual(after, before, 'a rotation did not replace the stored secret');
  });
});

describe('the mask sentinel is never the credential, on either verb', () => {
  test('a create carrying a masked token does not store the four characters', async (t) => {
    if (guard(t)) return;
    // THE VERB THE MASK RESOLUTION SKIPPED. `token` IS sanctioned for bearer, so
    // the stray strip keeps it; `encryptAuthConfig` returns the sentinel
    // untouched by its own contract; and `****` was persisted UNENCRYPTED as the
    // credential — which `decryptLeafOrThrow` reads as a legacy plaintext secret
    // and sends upstream. The assertion is the stored bytes, because the masked
    // read of a row holding `****` and one holding a real token are identical.
    const res = await call(ADMIN, 'POST', '/edge/app/api-connectors', connectorBody({
      auth_type: 'bearer', auth_config: { token: '****' },
    }));
    assert.equal(res.status, 200, `the create was refused: ${JSON.stringify(res.body)}`);

    const bytes = authConfigBytes(await storedConnector(res.body.data.id));
    assert.ok(
      !bytes.includes('****'),
      `the mask sentinel was persisted as the credential: ${bytes}`,
    );
    assert.equal(JSON.parse(bytes).token, undefined, 'the unresolvable leaf was kept');
  });

  test('a create carrying a real token still stores it encrypted', async (t) => {
    if (guard(t)) return;
    // The control: dropping the sentinel must not drop a genuine secret.
    const id = await createConnector();
    assert.match(
      JSON.parse(authConfigBytes(await storedConnector(id))).token, /^enc:v1:/,
      'an ordinary create stopped storing its secret',
    );
  });

  test('the same on a step create', async (t) => {
    if (guard(t)) return;
    // THE MIRROR LANE. Same column, same serializer shape, same verb.
    const { stepId } = await createRecipeWithStep({ auth_config: { token: '****' } });
    const bytes = authConfigBytes(await storedStep(stepId));
    assert.ok(
      !bytes.includes('****'),
      `the step create persisted the mask sentinel as the credential: ${bytes}`,
    );
    assert.equal(JSON.parse(bytes).token, undefined, 'the unresolvable step leaf was kept');
  });

  test('an api_key create carrying a masked value keeps the header name it does not hide', async (t) => {
    if (guard(t)) return;
    // The leaf that is dropped is the SANCTIONED one, not the whole config: the
    // header NAME of an api_key connector is not a secret and must survive.
    const res = await call(ADMIN, 'POST', '/edge/app/api-connectors', connectorBody({
      auth_type: 'api_key', auth_config: { header: 'X-Api-Key', value: '****' },
    }));
    assert.equal(res.status, 200, `the create was refused: ${JSON.stringify(res.body)}`);

    const stored = JSON.parse(authConfigBytes(await storedConnector(res.body.data.id)));
    assert.equal(stored.value, undefined, 'the sentinel was stored as the api-key value');
    assert.equal(stored.header, 'X-Api-Key', 'the non-secret header name was dropped with it');
  });

  test('a row that ALREADY holds the sentinel is repaired by an ordinary save', async (t) => {
    if (guard(t)) return;
    // THE ROWS THE CREATE PATH LEFT BEHIND. The resolver replaced a masked leaf
    // with the stored value whenever that value was a non-empty string — and
    // `'****'` is a non-empty string, so a row already holding it kept it on
    // every save. `decryptLeafOrThrow` returns any value without the `enc:v1:`
    // prefix verbatim, so such a row dispatched `Bearer ****` for as long as it
    // existed, and no ordinary edit could clear it. Measured before this changed:
    // PUT with the same body answered 200 and the column was unchanged.
    const id = 'cccccccc-cccc-4ccc-8ccc-cccccccccccc';
    await query(
      `INSERT INTO \`${tbl(TABLES.API_CONNECTORS)}\`
         (id, name, url, method, auth_type, auth_config, owner_id, status)
       VALUES (?, 'legacy-masked', 'https://upstream.test/x', 'GET', 'bearer', ?, ?, 'approved')`,
      [id, JSON.stringify({ token: '****' }), ADMIN.id],
    );

    const res = await call(ADMIN, 'PUT', `/edge/app/api-connectors/${id}`, {
      name: 'legacy-masked-renamed', auth_config: { token: '****' },
    });
    assert.equal(res.status, 200, `the save was refused: ${JSON.stringify(res.body)}`);

    const bytes = authConfigBytes(await storedConnector(id));
    assert.ok(
      !bytes.includes('****'),
      `an ordinary save carried the mask sentinel forward as the credential: ${bytes}`,
    );
    assert.equal(JSON.parse(bytes).token, undefined, 'the unusable leaf was kept');
  });

  test('the same repair on a step row', async (t) => {
    if (guard(t)) return;
    // THE MIRROR LANE, whose serializer carries the identical clause.
    const { stepId } = await createRecipeWithStep();
    await query(
      `UPDATE \`${tbl(TABLES.FLOW_RECIPE_STEPS)}\` SET auth_config = ? WHERE id = ?`,
      [JSON.stringify({ token: '****' }), stepId],
    );

    const res = await call(ADMIN, 'PUT', `/edge/app/flow-recipe-steps/${stepId}`, {
      auth_config: { token: '****' },
    });
    assert.equal(res.status, 200, `the save was refused: ${JSON.stringify(res.body)}`);

    const bytes = authConfigBytes(await storedStep(stepId));
    assert.ok(
      !bytes.includes('****'),
      `the step save carried the mask sentinel forward as the credential: ${bytes}`,
    );
  });

  test('a stored credential HEADER that is the sentinel is repaired the same way', async (t) => {
    if (guard(t)) return;
    // THE THIRD PLACE THE CLAUSE LIVES. `resolveMaskedRequestConfigHeaders` sits
    // directly under a comment saying the literal `****` must never become the
    // value a request is dispatched with, and its own length test carried it
    // forward.
    const id = 'cccccccc-cccc-4ccc-8ccc-ccccccccccce';
    await query(
      `INSERT INTO \`${tbl(TABLES.API_CONNECTORS)}\`
         (id, name, url, method, auth_type, request_config, owner_id, status)
       VALUES (?, 'legacy-header', 'https://upstream.test/x', 'GET', 'none', ?, ?, 'approved')`,
      [id, JSON.stringify({ headers: { Authorization: '****' } }), ADMIN.id],
    );

    const res = await call(ADMIN, 'PUT', `/edge/app/api-connectors/${id}`, {
      request_config: { headers: { Authorization: '****' } },
    });
    assert.equal(res.status, 200, `the save was refused: ${JSON.stringify(res.body)}`);

    const [row] = await query(
      `SELECT request_config FROM \`${tbl(TABLES.API_CONNECTORS)}\` WHERE id = ?`, [id],
    );
    const bytes = typeof row.request_config === 'string'
      ? row.request_config : JSON.stringify(row.request_config);
    assert.ok(
      !bytes.includes('****'),
      `an ordinary save carried the mask sentinel forward as a dispatched header: ${bytes}`,
    );
  });

  test('a real stored credential is still carried forward by a masked save', async (t) => {
    if (guard(t)) return;
    // The control for all three above: "unchanged" must still mean unchanged.
    const id = await createConnector();
    const before = authConfigBytes(await storedConnector(id));
    assert.match(JSON.parse(before).token, /^enc:v1:/, 'the fixture stored no ciphertext');

    const res = await call(ADMIN, 'PUT', `/edge/app/api-connectors/${id}`, {
      name: 'renamed-but-same-secret', auth_config: { token: '****' },
    });
    assert.equal(res.status, 200, `the save was refused: ${JSON.stringify(res.body)}`);
    assert.equal(
      authConfigBytes(await storedConnector(id)), before,
      'a masked save destroyed the real stored credential it means to preserve',
    );
  });
});

describe('a value already classified as a secret is classified the same way on every surface', () => {
  const REAL_HEADER = 'Bearer a-token-typed-into-a-header';

  test('a credential-valued header is not returned by the ordinary read', async (t) => {
    if (guard(t)) return;
    // Export already blanks these, under a comment saying an export must carry
    // no secret. The CRUD read applied no such rule, so the same value went out
    // in full on every GET and every list — to every admin AND every editor, on
    // a view-all mount. One vocabulary, every surface.
    const id = await createConnector(ADMIN, {
      request_config: { headers: { Authorization: REAL_HEADER, 'X-Trace': 'not-a-secret' }, body: '' },
    });

    const stored = await storedConnector(id);
    const storedHeaders = JSON.parse(
      typeof stored.request_config === 'string' ? stored.request_config : JSON.stringify(stored.request_config),
    ).headers;
    assert.equal(storedHeaders.Authorization, REAL_HEADER, 'the fixture did not store the header');

    for (const [label, res] of [
      ['single', await call(EDITOR, 'GET', `/edge/app/api-connectors/${id}`)],
      ['list', await call(EDITOR, 'GET', '/edge/app/api-connectors')],
    ]) {
      assert.equal(res.status, 200, `${label}: ${JSON.stringify(res.body)}`);
      assert.equal(
        JSON.stringify(res.body).includes(REAL_HEADER), false,
        `${label}: the read returned the credential header verbatim`,
      );
      assert.equal(
        JSON.stringify(res.body).includes('not-a-secret'), true,
        `${label}: an ordinary header stopped being returned`,
      );
    }
  });

  test('sending the masked header back keeps the stored credential', async (t) => {
    if (guard(t)) return;
    // The other half, and the one that makes masking usable rather than
    // destructive: the editor renders what the read gave it and saves the whole
    // config back, so a mask that is not resolved would overwrite the credential
    // with the literal sentinel.
    const id = await createConnector(ADMIN, {
      request_config: { headers: { Authorization: REAL_HEADER }, body: '' },
    });

    const res = await call(ADMIN, 'PUT', `/edge/app/api-connectors/${id}`, {
      name: 'renamed',
      request_config: { headers: { Authorization: '****', 'X-Added': 'v' }, body: '' },
    });
    assert.equal(res.status, 200, `the save was refused: ${JSON.stringify(res.body)}`);

    const stored = await storedConnector(id);
    const headers = JSON.parse(
      typeof stored.request_config === 'string' ? stored.request_config : JSON.stringify(stored.request_config),
    ).headers;
    assert.equal(headers.Authorization, REAL_HEADER, 'the masked save overwrote the stored credential');
    assert.equal(headers['X-Added'], 'v', 'the rest of the config did not save');
  });

  test('a masked header with nothing stored behind it is not persisted as the sentinel', async (t) => {
    if (guard(t)) return;
    // The safe arm of the same rule, matching what the token field already does:
    // the string `****` must never become the credential a request is dispatched
    // with.
    const id = await createConnector(ADMIN, {
      request_config: { headers: { Authorization: '****' }, body: '' },
    });
    const stored = await storedConnector(id);
    const headers = JSON.parse(
      typeof stored.request_config === 'string' ? stored.request_config : JSON.stringify(stored.request_config),
    ).headers;
    assert.equal(
      Object.prototype.hasOwnProperty.call(headers, 'Authorization'), false,
      'the mask sentinel was stored as a header value',
    );
  });

  test('a non-credential header is still saved and returned exactly as typed', async (t) => {
    if (guard(t)) return;
    // The control. Only names the shared vocabulary calls credentials are
    // masked; a fix that masked every header would satisfy the cases above and
    // make the headers editor useless.
    const id = await createConnector(ADMIN, {
      request_config: { headers: { 'X-Trace': '****', Accept: 'application/json' }, body: '' },
    });
    const res = await call(ADMIN, 'GET', `/edge/app/api-connectors/${id}`);
    assert.equal(res.body.data.request_config.headers['X-Trace'], '****');
    assert.equal(res.body.data.request_config.headers.Accept, 'application/json');
    const stored = JSON.parse(
      typeof (await storedConnector(id)).request_config === 'string'
        ? (await storedConnector(id)).request_config
        : JSON.stringify((await storedConnector(id)).request_config),
    );
    assert.equal(stored.headers['X-Trace'], '****', 'an ordinary header lost its literal value');
  });

  test('a legacy url carrying credentials is not returned with them', async (t) => {
    if (guard(t)) return;
    // Three of four surfaces already agree that url userinfo is a Basic-auth
    // secret: new writes refuse it, export sanitises it, clone sanitises it. The
    // ordinary read did not, so a row written before the guard shipped handed
    // its plaintext credential to every editor on GET.
    const id = '66666666-6666-4666-8666-666666666666';
    await query(
      `INSERT INTO \`${tbl(TABLES.API_CONNECTORS)}\`
         (id, name, owner_id, blueprint_id, url, auth_type, status)
       VALUES (?, 'legacy-userinfo', ?, ?, 'https://svc:hunter2@upstream.test/v1/x', 'none', 'approved')`,
      [id, ADMIN.id, sharedBlueprintId],
    );

    const res = await call(EDITOR, 'GET', `/edge/app/api-connectors/${id}`);
    assert.equal(res.status, 200, JSON.stringify(res.body));
    assert.equal(
      JSON.stringify(res.body).includes('hunter2'), false,
      'the read returned the url-embedded credential',
    );
    assert.equal(res.body.data.url, 'https://upstream.test/v1/x');
  });

  test('a step mount hides the same two things', async (t) => {
    if (guard(t)) return;
    // The mirror. A check present on one lane and absent on its twin is the
    // shape this card keeps finding, so the twin is asserted rather than assumed.
    const { stepId } = await createRecipeWithStep({
      request_config: { headers: { 'X-Api-Key': 'a-real-step-key' } },
    });
    const res = await call(ADMIN, 'GET', `/edge/app/flow-recipe-steps/${stepId}`);
    assert.equal(res.status, 200, JSON.stringify(res.body));
    assert.equal(
      JSON.stringify(res.body).includes('a-real-step-key'), false,
      'the step read returned the credential header verbatim',
    );

    const put = await call(ADMIN, 'PUT', `/edge/app/flow-recipe-steps/${stepId}`, {
      request_config: { headers: { 'X-Api-Key': '****' } },
    });
    assert.equal(put.status, 200, `the masked step save was refused: ${JSON.stringify(put.body)}`);
    const stored = await query(
      `SELECT request_config FROM \`${tbl(TABLES.FLOW_RECIPE_STEPS)}\` WHERE id = ?`, [stepId],
    );
    const raw = stored[0].request_config;
    const headers = JSON.parse(typeof raw === 'string' ? raw : JSON.stringify(raw)).headers;
    assert.equal(headers['X-Api-Key'], 'a-real-step-key', 'the masked step save overwrote the credential');
  });
});

describe('one reading of what a NULL status means', () => {
  async function approvalOf(id) {
    const rows = await query(
      `SELECT status, approved_by, approved_at FROM \`${tbl(TABLES.API_CONNECTORS)}\` WHERE id = ?`,
      [id],
    );
    return rows[0];
  }

  test('a grandfathered connector re-pends when what it dispatches changes', async (t) => {
    if (guard(t)) return;
    // THE ROW. NULL status is grandfathered, which the dispatch gate reads as
    // APPROVED — so this connector DOES dispatch. The re-pend read the same NULL
    // as "not approved, nothing to re-pend" and declined to fire, so an editor
    // could re-point it at a new endpoint and it kept dispatching there with no
    // review at all. Asserted on the stored status, not the response.
    const id = await createConnector();
    await query(
      `UPDATE \`${tbl(TABLES.API_CONNECTORS)}\` SET status = NULL, approved_by = NULL WHERE id = ?`,
      [id],
    );
    assert.equal((await approvalOf(id)).status, null, 'the fixture is not grandfathered');

    const res = await call(ADMIN, 'PUT', `/edge/app/api-connectors/${id}`, {
      url: 'https://elsewhere.test/v1/resource',
    });
    assert.equal(res.status, 200, `the edit was refused: ${JSON.stringify(res.body)}`);

    const after = await approvalOf(id);
    assert.equal(after.status, 'pending', 'a grandfathered connector kept dispatching to a new endpoint');
    const stored = await storedConnector(id);
    assert.equal(stored.url, 'https://elsewhere.test/v1/resource', 'the edit itself did not land');
  });

  test('an approved connector re-pends and its approval record is cleared', async (t) => {
    if (guard(t)) return;
    // The re-pend has to clear the approval bookkeeping in the same statement,
    // or the row reads as pending while still naming who approved it and when.
    const id = await createConnector();
    assert.equal((await approvalOf(id)).status, 'approved');
    assert.notEqual((await approvalOf(id)).approved_by, null);

    const res = await call(ADMIN, 'PUT', `/edge/app/api-connectors/${id}`, { auth_type: 'none' });
    assert.equal(res.status, 200, JSON.stringify(res.body));

    const after = await approvalOf(id);
    assert.equal(after.status, 'pending');
    assert.equal(after.approved_by, null, 'a pending row still names its approver');
    assert.equal(after.approved_at, null, 'a pending row still carries its approval time');
  });

  test('a cosmetic edit leaves the approval alone, on both states', async (t) => {
    if (guard(t)) return;
    // The control for the whole rule. A re-pend that fires on everything is one
    // an operator learns to clear without looking.
    const approved = await createConnector();
    const grandfathered = await createConnector(ADMIN, { name: 'grandfathered' });
    await query(
      `UPDATE \`${tbl(TABLES.API_CONNECTORS)}\` SET status = NULL WHERE id = ?`, [grandfathered],
    );

    for (const [label, id, expected] of [
      ['approved', approved, 'approved'],
      ['grandfathered', grandfathered, null],
    ]) {
      const res = await call(ADMIN, 'PUT', `/edge/app/api-connectors/${id}`, { name: `renamed-${label}` });
      assert.equal(res.status, 200, `${label}: ${JSON.stringify(res.body)}`);
      assert.equal(
        (await approvalOf(id)).status, expected,
        `${label}: a rename changed the review state`,
      );
    }
  });

  test('the re-pend is decided against the row the statement updates', async (t) => {
    if (guard(t)) return;
    // The probe used to read `pool.ro` while the approve/reject PATCHes write
    // `pool.rw`, with nothing holding the row in between — so a status that
    // changed between the probe and the UPDATE was decided against the old one.
    // Here a second transaction commits an approval mid-flight; the edit must be
    // judged against what it commits.
    const id = await createConnector();
    await query(
      `UPDATE \`${tbl(TABLES.API_CONNECTORS)}\` SET status = 'rejected', approved_by = NULL WHERE id = ?`,
      [id],
    );

    const other = await pool.getConnection();
    let inflight;
    try {
      await other.beginTransaction();
      await other.query(
        `SELECT id FROM \`${tbl(TABLES.API_CONNECTORS)}\` WHERE id = ? FOR UPDATE`, [id],
      );
      await other.query(
        `UPDATE \`${tbl(TABLES.API_CONNECTORS)}\` SET status = 'approved' WHERE id = ?`, [id],
      );
      // A cosmetic edit. Judged against 'rejected' it re-pends (the resubmit
      // path); judged against the row the statement will actually update it must
      // not, because the connector is approved and nothing sensitive changed.
      inflight = call(ADMIN, 'PUT', `/edge/app/api-connectors/${id}`, { name: 'renamed-mid-flight' });
      await new Promise((r) => setTimeout(r, 150));
      await other.commit();
    } finally {
      other.release();
    }
    const res = await inflight;
    assert.equal(res.status, 200, JSON.stringify(res.body));
    assert.equal(
      (await approvalOf(id)).status, 'approved',
      'the re-pend was decided against a snapshot the write then overwrote',
    );
  });

  test('editing a step re-pends its grandfathered parent recipe', async (t) => {
    if (guard(t)) return;
    // The same rule from the child side. A grandfathered recipe's steps DO
    // dispatch, and `repandFrom` did not list NULL — so a step could be swapped
    // under a recipe that went on dispatching the new step unreviewed.
    const { recipeId, stepId } = await createRecipeWithStep();
    await query(
      `UPDATE \`${tbl(TABLES.FLOW_RECIPES)}\` SET status = NULL WHERE id = ?`, [recipeId],
    );

    const res = await call(ADMIN, 'PUT', `/edge/app/flow-recipe-steps/${stepId}`, {
      url: 'https://elsewhere.test/v1/step',
    });
    assert.equal(res.status, 200, `the step edit was refused: ${JSON.stringify(res.body)}`);

    const rows = await query(
      `SELECT status FROM \`${tbl(TABLES.FLOW_RECIPES)}\` WHERE id = ?`, [recipeId],
    );
    assert.equal(rows[0].status, 'pending', 'a grandfathered recipe kept dispatching a swapped step');
  });
});

describe('the recipe mount re-pends on the columns it declares, through its own route', () => {
  // THE COVERAGE THE REMOVAL COMMENT CLAIMED WAS ALREADY HERE. Seven route-level
  // cases were deleted from `tests/unit/flow-recipes-approval.test.js` when the
  // re-pend stopped being a middleware, under a note saying the behaviour "is now
  // covered … in connector-credentials-real-db.test.js". It was not: that file
  // drove no PUT to `/edge/app/flow-recipes/:id` and named none of these columns.
  //
  // The mechanism is the shared factory's and is covered on the connector mount,
  // so nothing was live — but the WIRING is per-mount, and a typo in this mount's
  // `columns` / `jsonColumns` / `statusCol` would leave an edited recipe
  // dispatching unreviewed with nothing failing. These assert on the STORED
  // status, which is the only place the difference shows.
  const RECIPE_ID = '44444444-4444-4444-8444-444444444444';

  async function approvedRecipe(over = {}) {
    const cols = {
      payload_transform_code: 'CODE-1',
      content_type: 'application/json',
      runs_on: 'create',
      consumed_output_keys: JSON.stringify(['key1']),
      link_extract: JSON.stringify({ path: '$.link' }),
      external_id_extract: JSON.stringify({ path: '$.id' }),
      ...over,
    };
    const names = Object.keys(cols);
    await query(
      `INSERT INTO \`${tbl(TABLES.FLOW_RECIPES)}\`
         (id, name, blueprint_id, owner_id, status, approved_by, approved_at,
          ${names.map((c) => `\`${c}\``).join(', ')})
       VALUES (?, 'repend-recipe', ?, NULL, 'approved', ?, NOW(),
          ${names.map(() => '?').join(', ')})`,
      [RECIPE_ID, sharedBlueprintId, ADMIN.id, ...names.map((c) => cols[c])],
    );
    return RECIPE_ID;
  }

  async function recipeApproval() {
    const rows = await query(
      `SELECT status, approved_by, approved_at FROM \`${tbl(TABLES.FLOW_RECIPES)}\` WHERE id = ?`,
      [RECIPE_ID],
    );
    return rows[0];
  }

  const SENSITIVE_EDITS = [
    ['payload_transform_code', { payload_transform_code: 'CODE-CHANGED' }],
    ['content_type', { content_type: 'application/yaml' }],
    ['runs_on', { runs_on: 'both' }],
    ['consumed_output_keys', { consumed_output_keys: ['key2'] }],
    ['link_extract', { link_extract: { path: '$.different_link' } }],
    ['external_id_extract', { external_id_extract: { path: '$.other_id' } }],
  ];

  for (const [column, body] of SENSITIVE_EDITS) {
    test(`changing ${column} on an approved recipe re-pends it`, async (t) => {
      if (guard(t)) return;
      await approvedRecipe();

      const res = await call(ADMIN, 'PUT', `/edge/app/flow-recipes/${RECIPE_ID}`, body);
      assert.equal(res.status, 200, `the edit was refused: ${JSON.stringify(res.body)}`);

      const after = await recipeApproval();
      assert.equal(after.status, 'pending', `a change to ${column} left the recipe approved`);
      assert.equal(after.approved_by, null, 'the approval record was not cleared');
      assert.equal(after.approved_at, null, 'the approval record was not cleared');
    });
  }

  test('a spelling the column would fold is refused before it reaches the statement', async (t) => {
    if (guard(t)) return;
    // THE PREMISE THE CHANGE COMPARE RESTS ON. The re-pend decides with a
    // JavaScript `!==` against the stored member, which is sound only if a domain
    // gate has already proved the written value is IDENTICALLY a member. This
    // mount declared no domain at all, so `application/JSON` reached the
    // statement with the caller's spelling — the engine folded it to
    // `application/json` and the compare called that a change.
    await approvedRecipe();

    const res = await call(ADMIN, 'PUT', `/edge/app/flow-recipes/${RECIPE_ID}`, {
      content_type: 'application/JSON',
    });

    assert.equal(res.status, 400, `expected a refusal, got ${JSON.stringify(res.body)}`);
    assert.equal(res.body.error?.code, 'INVALID_COLUMN_VALUE');
    const after = await recipeApproval();
    assert.equal(after.status, 'approved', 'a refused edit re-pended the recipe anyway');
  });

  test('the database really does fold that spelling, which is why it must be refused', async (t) => {
    if (guard(t)) return;
    // The premise of the premise, written straight to the column with no router
    // in the way — so the refusal above is shown to be about a real fold rather
    // than a value the engine would have rejected anyway.
    await approvedRecipe();
    const conn = await lease();
    let restore = null;
    try {
      restore = (await conn.query('SELECT @@session.sql_mode AS m'))[0].m;
      await conn.query('SET SESSION sql_mode = ?', ['']);
      await conn.query(
        `UPDATE \`${tbl(TABLES.FLOW_RECIPES)}\` SET content_type = ? WHERE id = ?`,
        ['application/JSON', RECIPE_ID],
      );
    } finally {
      if (restore !== null) {
        try { await conn.query('SET SESSION sql_mode = ?', [restore]); } catch { /* best effort */ }
      }
      conn.release();
    }
    const rows = await query(
      `SELECT content_type FROM \`${tbl(TABLES.FLOW_RECIPES)}\` WHERE id = ?`, [RECIPE_ID],
    );
    assert.equal(
      rows[0].content_type, 'application/json',
      'this database no longer folds the case of an ENUM member on write',
    );
  });

  test('a cosmetic edit leaves an approved recipe approved', async (t) => {
    if (guard(t)) return;
    // The control. A gate that re-pends every edit satisfies the six above and
    // makes approval worthless.
    await approvedRecipe();

    const res = await call(ADMIN, 'PUT', `/edge/app/flow-recipes/${RECIPE_ID}`, {
      name: 'renamed', description: 'updated desc',
    });
    assert.equal(res.status, 200, `the edit was refused: ${JSON.stringify(res.body)}`);

    const after = await recipeApproval();
    assert.equal(after.status, 'approved', 'a rename re-pended the recipe');
    assert.equal(after.approved_by, ADMIN.id, 'a rename cleared the approval record');
  });

  test('re-sending the same sensitive value does not re-pend', async (t) => {
    if (guard(t)) return;
    // The other control: the comparison is against the STORED value, so an edit
    // that changes nothing must not cost a review.
    await approvedRecipe();

    const res = await call(ADMIN, 'PUT', `/edge/app/flow-recipes/${RECIPE_ID}`, {
      runs_on: 'create', content_type: 'application/json',
    });
    assert.equal(res.status, 200, `the edit was refused: ${JSON.stringify(res.body)}`);
    assert.equal((await recipeApproval()).status, 'approved', 'an unchanged value re-pended');
  });

  test('a rejected recipe returns to pending on any edit — the resubmit path', async (t) => {
    if (guard(t)) return;
    await approvedRecipe();
    await query(
      `UPDATE \`${tbl(TABLES.FLOW_RECIPES)}\` SET status = 'rejected' WHERE id = ?`, [RECIPE_ID],
    );

    const res = await call(ADMIN, 'PUT', `/edge/app/flow-recipes/${RECIPE_ID}`, { name: 'resubmit' });
    assert.equal(res.status, 200, `the edit was refused: ${JSON.stringify(res.body)}`);
    assert.equal((await recipeApproval()).status, 'pending', 'a rejected recipe could not be resubmitted');
  });

  test('a grandfathered recipe re-pends on a sensitive change and not otherwise', async (t) => {
    if (guard(t)) return;
    // NULL is read as approved by the dispatch gate, so this recipe DOES run.
    await approvedRecipe();
    await query(
      `UPDATE \`${tbl(TABLES.FLOW_RECIPES)}\` SET status = NULL, approved_by = NULL WHERE id = ?`,
      [RECIPE_ID],
    );

    const cosmetic = await call(ADMIN, 'PUT', `/edge/app/flow-recipes/${RECIPE_ID}`, { name: 'renamed' });
    assert.equal(cosmetic.status, 200, `the edit was refused: ${JSON.stringify(cosmetic.body)}`);
    assert.equal((await recipeApproval()).status, null, 'a cosmetic edit pended a grandfathered recipe');

    const sensitive = await call(ADMIN, 'PUT', `/edge/app/flow-recipes/${RECIPE_ID}`, {
      payload_transform_code: 'CODE-2',
    });
    assert.equal(sensitive.status, 200, `the edit was refused: ${JSON.stringify(sensitive.body)}`);
    assert.equal(
      (await recipeApproval()).status, 'pending',
      'a grandfathered recipe kept dispatching code nobody reviewed',
    );
  });
});

describe('a partial update that omits a key has said nothing about it', () => {
  const GROUP_ID = '99999999-9999-4999-8999-999999999999';

  async function bundledConnector() {
    const id = await createConnector(ADMIN, {
      group_id: GROUP_ID, group_label: 'Original label', group_mode: 'chain', sequence: 2,
    });
    const row = await storedConnector(id);
    assert.equal(row.group_id, GROUP_ID, 'the fixture did not store its bundle');
    return id;
  }

  test('renaming a bundle label does not remove the connector from the bundle', async (t) => {
    if (guard(t)) return;
    // The most ordinary edit there is. `touched` was true because ONE of the four
    // bundle keys was present, `group_id` was then found absent — `undefined ==
    // null` — and the write was read as "the caller means ungrouped", so four
    // NULLs landed. For a chain group that also breaks every sibling's
    // `input_from_step` wiring, which references members by sequence.
    const id = await bundledConnector();

    const res = await call(ADMIN, 'PUT', `/edge/app/api-connectors/${id}`, {
      group_label: 'New label',
    });
    assert.equal(res.status, 200, `the rename was refused: ${JSON.stringify(res.body)}`);

    const row = await storedConnector(id);
    assert.equal(row.group_id, GROUP_ID, 'the connector silently left its bundle');
    assert.equal(row.group_mode, 'chain', 'the bundle mode was cleared');
    assert.equal(row.sequence, 2, 'the chain position was cleared');
    assert.equal(row.group_label, 'New label', 'the rename itself did not land');
  });

  test('naming group_id as null is still an instruction to ungroup', async (t) => {
    if (guard(t)) return;
    // The other half. "Absence is not an instruction" must not become "there is
    // no way to say it" — an explicit null still clears the whole bundle.
    const id = await bundledConnector();

    const res = await call(ADMIN, 'PUT', `/edge/app/api-connectors/${id}`, { group_id: null });
    assert.equal(res.status, 200, `the ungroup was refused: ${JSON.stringify(res.body)}`);

    const row = await storedConnector(id);
    assert.deepEqual(
      [row.group_id, row.group_label, row.group_mode, row.sequence],
      [null, null, null, null],
      'an explicit ungroup left bundle metadata behind',
    );
  });

  test('bundle metadata is never stored without the bundle it belongs to', async (t) => {
    if (guard(t)) return;
    // The invariant the four-NULL reset was protecting, kept: a connector that
    // is NOT in a bundle cannot acquire a label, a mode or a position on its own
    // — those would be orphan values that /usable and the chain runner would
    // read as membership.
    const id = await createConnector();
    assert.equal((await storedConnector(id)).group_id, null);

    const res = await call(ADMIN, 'PUT', `/edge/app/api-connectors/${id}`, {
      group_label: 'orphan', group_mode: 'chain', sequence: 3,
    });
    assert.equal(res.status, 200, `the edit was refused: ${JSON.stringify(res.body)}`);

    const row = await storedConnector(id);
    assert.deepEqual(
      [row.group_id, row.group_label, row.group_mode, row.sequence],
      [null, null, null, null],
      'an ungrouped connector acquired bundle metadata',
    );
  });

  test('moving a bundled connector to a new position still works', async (t) => {
    if (guard(t)) return;
    // The control: a partial PUT that omits group_id must still be able to
    // change the fields it DOES name, against the bundle the row is in.
    const id = await bundledConnector();

    const res = await call(ADMIN, 'PUT', `/edge/app/api-connectors/${id}`, { sequence: 5 });
    assert.equal(res.status, 200, `the move was refused: ${JSON.stringify(res.body)}`);

    const row = await storedConnector(id);
    assert.equal(row.group_id, GROUP_ID);
    assert.equal(row.sequence, 5, 'the move did not land');
  });
});

describe('a gate whose failure orphans encrypted credentials runs under the delete\'s own lock', () => {
  test('a step committed while the delete is in flight refuses the delete', async (t) => {
    if (guard(t)) return;
    // THE RACE, MADE DETERMINISTIC. The probe was an unlocked `SELECT 1 … LIMIT
    // 1` on `pool.ro`, taken before the delete's transaction existed — so a step
    // inserted in that window was invisible to it and orphaned by the DELETE.
    // The mount's own comment says why that matters: an orphan step carries an
    // encrypted credential and is unreachable to editors thereafter, because the
    // ownership chain needs the parent that no longer exists.
    //
    // Here the step INSERT is committed while the DELETE is in flight. The
    // assertion is on the rows, not the status: the recipe must still be there
    // and the step must still have its parent.
    //
    // THIS IS ONLY ONE OF THE TWO INTERLEAVINGS, and it is the one that cannot
    // produce an orphan — the step is already in the table (uncommitted) when
    // the probe reads, so the probe blocks and then sees it. The other order,
    // where the DELETE goes first and the step lands behind it, is the case the
    // gate is actually claimed to close and is exercised by the two tests below,
    // through the POST route rather than a raw connection that takes no lock the
    // handler would take.
    const recipeId = 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa';
    await query(
      `INSERT INTO \`${tbl(TABLES.FLOW_RECIPES)}\` (id, name, blueprint_id, owner_id, status)
       VALUES (?, 'racy-recipe', ?, NULL, 'approved')`,
      [recipeId, sharedBlueprintId],
    );

    const other = await pool.getConnection();
    let inflight;
    try {
      await other.beginTransaction();
      await other.query(
        `INSERT INTO \`${tbl(TABLES.FLOW_RECIPE_STEPS)}\`
           (id, recipe_id, \`sequence\`, name, method, url, auth_type)
         VALUES (?, ?, 1, 'racy-step', 'POST', 'https://upstream.test/v1/step', 'bearer')`,
        ['bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb', recipeId],
      );
      inflight = call(ADMIN, 'DELETE', `/edge/app/flow-recipes/${recipeId}`);
      await new Promise((r) => setTimeout(r, 150));
      await other.commit();
    } finally {
      other.release();
    }
    const res = await inflight;

    const recipes = await query(
      `SELECT id FROM \`${tbl(TABLES.FLOW_RECIPES)}\` WHERE id = ?`, [recipeId],
    );
    const steps = await query(
      `SELECT id, recipe_id FROM \`${tbl(TABLES.FLOW_RECIPE_STEPS)}\` WHERE recipe_id = ?`, [recipeId],
    );
    assert.equal(steps.length, 1, 'the step under test is gone');
    assert.equal(
      recipes.length, 1,
      `the recipe was deleted out from under its step, orphaning an encrypted credential (DELETE ${res.status})`,
    );
    assert.equal(res.status, 409, `expected a refusal, got ${JSON.stringify(res.body)}`);
  });

  test('the delete takes its two locks in the order every step write takes them', async (t) => {
    if (guard(t)) return;
    // THE ORDER, MADE DETERMINISTIC. Every step write locks the CHILD first (its
    // own row, `FOR UPDATE` — the serializer's stored-row read and the factory's
    // re-parent capture both do this) and the parent LAST, in
    // `repandParentInTx`. Taking this gate's child lock AFTER the DELETE had
    // taken the parent's inverted that and closed a cycle. Measured through the
    // routes over 160 concurrent pairs before this changed: 69 step writes died
    // with errno 1213 and were answered 500 — a retryable engine decision
    // dressed as a server fault, on a request that was entirely valid.
    //
    // The raw connection here PLAYS the step write, in its exact lock order, and
    // holds the child lock across the delete so the interleaving is not left to
    // chance. With the probe after the DELETE, the two hold one lock each and
    // want the other's: one of them MUST be rolled back as the victim, so both
    // assertions below are live. With the probe before it, the delete waits for
    // the child lock first and no cycle can form.
    const { recipeId, stepId } = await createRecipeWithStep();

    const stepWrite = await pool.getConnection();
    let victim = null;
    let inflight;
    try {
      await stepWrite.beginTransaction();
      // 1. the child lock, exactly as the step write takes it
      await stepWrite.query(
        `SELECT id FROM \`${tbl(TABLES.FLOW_RECIPE_STEPS)}\` WHERE id = ? FOR UPDATE`,
        [stepId],
      );
      // 2. the delete, which must not be able to reach the parent lock first
      inflight = call(ADMIN, 'DELETE', `/edge/app/flow-recipes/${recipeId}`);
      await new Promise((r) => setTimeout(r, 200));
      // 3. the parent lock, exactly as `repandParentInTx` takes it
      try {
        await stepWrite.query(
          `SELECT status FROM \`${tbl(TABLES.FLOW_RECIPES)}\` WHERE id = ? FOR UPDATE`,
          [recipeId],
        );
        await stepWrite.commit();
      } catch (err) {
        victim = err.errno;
        try { await stepWrite.rollback(); } catch { /* best effort */ }
      }
    } finally {
      stepWrite.release();
    }
    const res = await inflight;

    assert.equal(
      victim, null,
      `the step write was rolled back by the engine (errno ${victim}) — the delete's`
      + ' locks are in the opposite order to every step write',
    );
    assert.notEqual(
      res.status, 500,
      `the delete died on a lock: ${JSON.stringify(res.body)}`,
    );
    assert.equal(res.status, 409, `expected a refusal, got ${JSON.stringify(res.body)}`);
  });

  test('a step created behind the delete is refused rather than orphaned', async (t) => {
    if (guard(t)) return;
    // THE INTERLEAVING THE GATE IS CLAIMED TO CLOSE, and the one it does not.
    // The recipe has no steps, so the delete has nothing to refuse and commits;
    // the step POST then lands naming a parent that is gone. The gap lock makes
    // the INSERT WAIT — and then it lands, and it is orphaned, because nothing
    // re-checked the parent after the wait: `repandParentInTx` answered a
    // vanished parent with a silent return, `checkParentOwnership` returns true
    // for an admin without querying, and there is no foreign key. Measured
    // through these two routes before the fix: 20 of 20 pairs left an orphan.
    //
    // Driven through the POST route, not a raw INSERT: a connection that never
    // takes the locks the handler takes cannot observe what the handler does.
    const recipeId = 'dddddddd-dddd-4ddd-8ddd-dddddddddddd';
    await query(
      `INSERT INTO \`${tbl(TABLES.FLOW_RECIPES)}\` (id, name, blueprint_id, owner_id, status)
       VALUES (?, 'doomed-recipe', ?, NULL, 'approved')`,
      [recipeId, sharedBlueprintId],
    );

    const del = call(ADMIN, 'DELETE', `/edge/app/flow-recipes/${recipeId}`);
    const post = call(ADMIN, 'POST', '/edge/app/flow-recipe-steps', {
      recipe_id: recipeId,
      name: 'late-step',
      method: 'POST',
      url: 'https://upstream.test/v1/step',
      auth_type: 'bearer',
      auth_config: { token: 'the-real-step-token' },
    });
    const [delRes, postRes] = await Promise.all([del, post]);

    const orphans = await query(
      `SELECT s.id FROM \`${tbl(TABLES.FLOW_RECIPE_STEPS)}\` s
        WHERE NOT EXISTS (
          SELECT 1 FROM \`${tbl(TABLES.FLOW_RECIPES)}\` r WHERE r.id = s.recipe_id
        )`,
    );
    assert.equal(
      orphans.length, 0,
      'a step carrying an encrypted credential was left with no parent'
      + ` (DELETE ${delRes.status}, POST ${postRes.status})`,
    );
    // Whichever side won, the pair has to be coherent: either the delete was
    // refused because the step got in first, or the step was refused because
    // its parent had gone.
    assert.ok(
      (delRes.status === 200 && postRes.status === 404)
      || (delRes.status === 409 && postRes.status === 200),
      `incoherent pair: DELETE ${delRes.status}, POST ${JSON.stringify(postRes.body)}`,
    );
  });

  test('a step naming a recipe that never existed is refused, with no race at all', async (t) => {
    if (guard(t)) return;
    // THE SAME END STATE WITHOUT ANY CONCURRENCY. `checkParentOwnership` returns
    // true for an admin without querying, and the column carries no foreign key,
    // so an id naming nothing produced a 200 and a step no editor can reach.
    const res = await call(ADMIN, 'POST', '/edge/app/flow-recipe-steps', {
      recipe_id: 'eeeeeeee-eeee-4eee-8eee-eeeeeeeeeeee',
      name: 'parentless-step',
      method: 'POST',
      url: 'https://upstream.test/v1/step',
      auth_type: 'bearer',
      auth_config: { token: 'the-real-step-token' },
    });

    assert.equal(res.status, 404, `expected a refusal, got ${JSON.stringify(res.body)}`);
    assert.equal(res.body.error?.code, 'PARENT_NOT_FOUND');
    const rows = await query(
      `SELECT id FROM \`${tbl(TABLES.FLOW_RECIPE_STEPS)}\` WHERE recipe_id = ?`,
      ['eeeeeeee-eeee-4eee-8eee-eeeeeeeeeeee'],
    );
    assert.equal(rows.length, 0, 'a refused create left the row behind');
  });

  test('a step whose parent already vanished can still be repaired in place', async (t) => {
    if (guard(t)) return;
    // THE RULE THE GUARD'S OWN COMMENT STATES, which the code did the opposite of.
    // "The parent this write NAMES has to exist" was implemented as "the parent
    // the row ends up under", falling back to the STORED parent — which is every
    // partial edit. So a step whose recipe had been deleted answered 404 to every
    // edit that did not re-parent it, and the one that matters is the edit that
    // strips its stored credential: the encrypted secret stayed in the row with
    // no way to clear it. Measured before this changed: `PUT {name}` 404,
    // `PUT {auth_type:'none'}` 404.
    const { recipeId, stepId } = await createRecipeWithStep();
    await query(`DELETE FROM \`${tbl(TABLES.FLOW_RECIPES)}\` WHERE id = ?`, [recipeId]);

    const renamed = await call(ADMIN, 'PUT', `/edge/app/flow-recipe-steps/${stepId}`, { name: 'repaired' });
    assert.equal(renamed.status, 200, `an ordinary edit was refused: ${JSON.stringify(renamed.body)}`);

    const cleared = await call(ADMIN, 'PUT', `/edge/app/flow-recipe-steps/${stepId}`, { auth_type: 'none' });
    assert.equal(cleared.status, 200, `the credential-clearing edit was refused: ${JSON.stringify(cleared.body)}`);

    // Asserted on the stored bytes, not the status: the point of the repair is
    // that the ciphertext is gone from the column.
    const row = await storedStep(stepId);
    const [stored] = await query(
      `SELECT name FROM \`${tbl(TABLES.FLOW_RECIPE_STEPS)}\` WHERE id = ?`, [stepId],
    );
    assert.equal(stored.name, 'repaired', 'the rename answered 200 without landing');
    assert.equal(row.auth_type, 'none');
    assert.equal(
      authConfigBytes(row), '{}',
      'the stored credential survived the edit that exists to remove it',
    );
  });

  test('an orphaned step is still refused a move onto a parent that is not there', async (t) => {
    if (guard(t)) return;
    // The other half of the same decision, so making the partial edit work cannot
    // be mistaken for switching the guard off: this write NAMES a destination, and
    // a destination that does not exist is the orphan the guard is about.
    const { recipeId, stepId } = await createRecipeWithStep();
    await query(`DELETE FROM \`${tbl(TABLES.FLOW_RECIPES)}\` WHERE id = ?`, [recipeId]);

    const res = await call(ADMIN, 'PUT', `/edge/app/flow-recipe-steps/${stepId}`, {
      recipe_id: 'ffffffff-ffff-4fff-8fff-ffffffffffff',
    });
    assert.equal(res.status, 404, `expected a refusal, got ${JSON.stringify(res.body)}`);
    assert.equal(res.body.error?.code, 'PARENT_NOT_FOUND');

    // And the documented repair still works: re-parent onto a recipe that exists.
    const liveRecipeId = '44444444-4444-4444-8444-444444444444';
    await query(
      `INSERT INTO \`${tbl(TABLES.FLOW_RECIPES)}\` (id, name, blueprint_id, owner_id, status)
       VALUES (?, 'rehome', ?, NULL, 'approved')`,
      [liveRecipeId, sharedBlueprintId],
    );
    const moved = await call(ADMIN, 'PUT', `/edge/app/flow-recipe-steps/${stepId}`, {
      recipe_id: liveRecipeId,
    });
    assert.equal(moved.status, 200, `the repair was refused: ${JSON.stringify(moved.body)}`);
    const [stored] = await query(
      `SELECT recipe_id FROM \`${tbl(TABLES.FLOW_RECIPE_STEPS)}\` WHERE id = ?`, [stepId],
    );
    assert.equal(stored.recipe_id, liveRecipeId, 'the re-parent answered 200 without landing');
  });

  test('moving a step to a recipe that does not exist is refused', async (t) => {
    if (guard(t)) return;
    // The verb that MOVES a child is the other half. An admin PUT keeps the
    // parent FK in the row being written, so it can re-parent onto anything.
    const { stepId } = await createRecipeWithStep();

    const res = await call(ADMIN, 'PUT', `/edge/app/flow-recipe-steps/${stepId}`, {
      recipe_id: 'ffffffff-ffff-4fff-8fff-ffffffffffff',
    });

    assert.equal(res.status, 404, `expected a refusal, got ${JSON.stringify(res.body)}`);
    const rows = await query(
      `SELECT recipe_id FROM \`${tbl(TABLES.FLOW_RECIPE_STEPS)}\` WHERE id = ?`, [stepId],
    );
    assert.notEqual(
      rows[0].recipe_id, 'ffffffff-ffff-4fff-8fff-ffffffffffff',
      'a refused move landed anyway',
    );
  });

  test('an ordinary step create and an ordinary move both still work', async (t) => {
    if (guard(t)) return;
    // The control on the refusal's reach: the gate must not make the feature
    // unusable. A create under a live recipe, and a move onto another live one.
    const { recipeId, stepId } = await createRecipeWithStep();
    const otherRecipeId = '99999999-9999-4999-8999-999999999999';
    await query(
      `INSERT INTO \`${tbl(TABLES.FLOW_RECIPES)}\` (id, name, blueprint_id, owner_id, status)
       VALUES (?, 'other-recipe', ?, NULL, 'approved')`,
      [otherRecipeId, sharedBlueprintId],
    );

    const moved = await call(ADMIN, 'PUT', `/edge/app/flow-recipe-steps/${stepId}`, {
      recipe_id: otherRecipeId,
    });
    assert.equal(moved.status, 200, `a legitimate move was refused: ${JSON.stringify(moved.body)}`);
    const rows = await query(
      `SELECT recipe_id FROM \`${tbl(TABLES.FLOW_RECIPE_STEPS)}\` WHERE id = ?`, [stepId],
    );
    assert.equal(rows[0].recipe_id, otherRecipeId, 'the move did not land');

    const created = await call(ADMIN, 'POST', '/edge/app/flow-recipe-steps', {
      recipe_id: recipeId,
      name: 'second-step',
      method: 'POST',
      url: 'https://upstream.test/v1/step',
      auth_type: 'none',
      auth_config: {},
    });
    assert.equal(created.status, 200, `a legitimate create was refused: ${JSON.stringify(created.body)}`);
  });

  test('a recipe with no steps still deletes', async (t) => {
    if (guard(t)) return;
    // The control. A gate that refuses every delete would satisfy the case above
    // and remove the feature.
    const recipeId = 'cccccccc-cccc-4ccc-8ccc-cccccccccccc';
    await query(
      `INSERT INTO \`${tbl(TABLES.FLOW_RECIPES)}\` (id, name, blueprint_id, owner_id, status)
       VALUES (?, 'lonely-recipe', ?, NULL, 'approved')`,
      [recipeId, sharedBlueprintId],
    );

    const res = await call(ADMIN, 'DELETE', `/edge/app/flow-recipes/${recipeId}`);
    assert.equal(res.status, 200, `a legitimate delete was refused: ${JSON.stringify(res.body)}`);
    const rows = await query(
      `SELECT id FROM \`${tbl(TABLES.FLOW_RECIPES)}\` WHERE id = ?`, [recipeId],
    );
    assert.equal(rows.length, 0, 'the delete did not land');
  });

  test('a recipe whose steps are already committed is refused', async (t) => {
    if (guard(t)) return;
    // The uncontended case the old middleware also covered, kept so moving the
    // probe cannot quietly drop it.
    const { recipeId } = await createRecipeWithStep();
    const res = await call(ADMIN, 'DELETE', `/edge/app/flow-recipes/${recipeId}`);
    assert.equal(res.status, 409, `expected a refusal, got ${JSON.stringify(res.body)}`);
    const rows = await query(
      `SELECT id FROM \`${tbl(TABLES.FLOW_RECIPES)}\` WHERE id = ?`, [recipeId],
    );
    assert.equal(rows.length, 1, 'a refused delete removed the recipe anyway');
  });
});

describe('the locks that gate a delete are taken only for a caller entitled to the row', () => {
  const STRANGER = '9d949f1e-5c0b-447c-8144-3210469bc222';

  /**
   * A recipe owned by somebody who is not the editor, carrying one step whose
   * row is held under an X lock by an unrelated transaction for the duration of
   * `body`. The holder is always released, so a failing assertion cannot leave a
   * lock behind and stall the rest of the file.
   */
  async function withLockedStepOf(ownerId, body) {
    const recipeId = '33333333-3333-4333-8333-333333333333';
    await query(
      `INSERT INTO \`${tbl(TABLES.FLOW_RECIPES)}\` (id, name, blueprint_id, owner_id, status)
       VALUES (?, 'foreign-recipe', ?, ?, 'approved')`,
      [recipeId, sharedBlueprintId, ownerId],
    );
    const created = await call(ADMIN, 'POST', '/edge/app/flow-recipe-steps', {
      recipe_id: recipeId,
      name: 'locked-step',
      method: 'POST',
      url: 'https://upstream.test/v1/step',
      auth_type: 'bearer',
      auth_config: { token: 'the-real-step-token' },
    });
    assert.equal(created.status, 200, `fixture step create was refused: ${JSON.stringify(created.body)}`);
    const stepId = created.body.data.id;

    const holder = await pool.getConnection();
    try {
      await holder.beginTransaction();
      await holder.query(
        `SELECT id FROM \`${tbl(TABLES.FLOW_RECIPE_STEPS)}\` WHERE id = ? FOR UPDATE`,
        [stepId],
      );
      return await body({ recipeId, stepId, release: () => holder.rollback() });
    } finally {
      try { await holder.rollback(); } catch { /* already released */ }
      holder.release();
    }
  }

  /** Whether `p` settled within `ms`, without consuming its eventual value. */
  function settledWithin(p, ms) {
    const marker = Symbol('pending');
    return Promise.race([
      p.then(() => true, () => true),
      new Promise((r) => setTimeout(() => r(marker), ms)),
    ]).then((v) => v !== marker);
  }

  test('an editor who owns nothing is answered without waiting on the row\'s children', async (t) => {
    if (guard(t)) return;
    // THE LOCK USED TO BE TAKEN BEFORE THE AUTHORIZATION. The reference probe
    // runs `SELECT 1 FROM <child> WHERE <fk> = ? LIMIT 1 FOR UPDATE`, and it ran
    // ahead of the ownership-scoped DELETE — so any authenticated editor could
    // make this handler queue behind a lock on rows they have no right to read.
    // Measured against a step row held by an unrelated transaction: the 404 was
    // still correct, and it took 1213 ms to say so, with a handler and a pooled
    // connection held the whole time (up to `innodb_lock_wait_timeout`, 50 s by
    // default). Six of them in flight starved the pool: an unrelated legitimate
    // read did not answer within 3000 ms.
    //
    // Asserted on SETTLEMENT WHILE THE LOCK IS STILL HELD rather than on a
    // duration: the defect is unbounded waiting, so "answered before the holder
    // let go" is the property, and it cannot pass by being fast.
    await withLockedStepOf(STRANGER, async ({ recipeId }) => {
      const inflight = call(EDITOR, 'DELETE', `/edge/app/flow-recipes/${recipeId}`);
      const answered = await settledWithin(inflight, 750);
      const res = await inflight;
      assert.ok(
        answered,
        'the unauthorised delete parked on a lock over rows the caller cannot see',
      );
      assert.equal(res.status, 404, `expected 404, got ${JSON.stringify(res.body)}`);
      const rows = await query(
        `SELECT id FROM \`${tbl(TABLES.FLOW_RECIPES)}\` WHERE id = ?`, [recipeId],
      );
      assert.equal(rows.length, 1, 'an unauthorised delete removed the recipe');
    });
  });

  test('an entitled caller STILL takes the child lock first, ahead of the statement', async (t) => {
    if (guard(t)) return;
    // The other half, and the reason the fix is an added read rather than a
    // moved probe: for a caller the DELETE would match, the child lock must
    // still be acquired before the parent's, or the deadlock this ordering was
    // introduced to remove comes straight back. So this delete MUST wait.
    await withLockedStepOf(null, async ({ recipeId, release }) => {
      const inflight = call(ADMIN, 'DELETE', `/edge/app/flow-recipes/${recipeId}`);
      const answeredEarly = await settledWithin(inflight, 750);
      assert.equal(
        answeredEarly, false,
        'the entitled delete did not wait for the child lock — the probe no longer runs before the statement',
      );
      await release();
      const res = await inflight;
      assert.equal(res.status, 409, `expected a refusal, got ${JSON.stringify(res.body)}`);
    });
  });
});

describe('the re-pend when the table\'s column list cannot be read', () => {
  /**
   * Run `body` with the column-metadata probe answering unknown, and with the
   * memo of that answer cleared on both sides — it caches the null for the life
   * of the process, so leaving it would hand every later case in this file a
   * table it believes has no columns.
   */
  async function withUnknownColumnMetadata(body) {
    _columnSetCache.clear();
    hideColumnMetadata = true;
    try {
      return await body();
    } finally {
      hideColumnMetadata = false;
      _columnSetCache.clear();
    }
  }

  /**
   * Run `body` against a table that genuinely does not have `column` — the
   * no-ALTER deployment this path is required to degrade on rather than a
   * simulation of one. The declaration is taken from the live table and put
   * back verbatim, so this cannot drift from the DDL the suite creates.
   */
  async function withColumnDropped(table, column, body) {
    const shown = await query(`SHOW CREATE TABLE \`${table}\``);
    const declaration = String(shown[0]['Create Table'])
      .split('\n')
      .map((line) => line.trim().replace(/,$/, ''))
      .find((line) => line.startsWith(`\`${column}\``));
    assert.ok(declaration, `the table no longer declares \`${column}\``);
    await query(`ALTER TABLE \`${table}\` DROP COLUMN \`${column}\``);
    _columnSetCache.clear();
    try {
      return await body();
    } finally {
      await query(`ALTER TABLE \`${table}\` ADD COLUMN ${declaration}`);
      _columnSetCache.clear();
    }
  }

  /** The review state the column holds, which is the only witness here. */
  async function storedApproval(id) {
    const rows = await query(
      `SELECT status, approved_by, approved_at, url
         FROM \`${tbl(TABLES.API_CONNECTORS)}\` WHERE id = ?`,
      [id],
    );
    return rows[0] || null;
  }

  /** An editor's connector, approved by an administrator through the PATCH. */
  async function approvedEditorConnector() {
    const id = await createConnector(EDITOR);
    const approved = await call(ADMIN, 'PATCH', `/edge/app/api-connectors/${id}/approve`);
    assert.equal(approved.status, 200, `the fixture approval was refused: ${JSON.stringify(approved.body)}`);
    const before = await storedApproval(id);
    assert.equal(before.status, 'approved', 'the fixture did not leave an approved connector');
    assert.ok(before.approved_by, 'the fixture recorded no approver, so a cleared one proves nothing');
    return id;
  }

  test('an approved connector does not stay approved because the probe answered nothing', async (t) => {
    if (guard(t)) return;
    // THE FAIL-OPEN. The re-pend was gated on `colSet && colSet.has(statusCol)`,
    // and `colSet` is null for UNKNOWN — the probe threw, or answered no rows,
    // or answered rows with no usable names. On a table that really does have
    // `status`, unknown made the whole block disappear: the editor re-points the
    // connector at another endpoint and it keeps the approval that covered the
    // old one, so it goes on dispatching with no renewed review. The null is
    // cached per (database, table), so one unlucky probe does this to every
    // write for the life of the process.
    //
    // Asserted on the stored review state, not on the status code: the response
    // is a 200 either way.
    const id = await approvedEditorConnector();

    const moved = await withUnknownColumnMetadata(() => call(
      EDITOR, 'PUT', `/edge/app/api-connectors/${id}`, { url: 'https://elsewhere.test/v1/resource' },
    ));
    assert.equal(moved.status, 200, `a legitimate edit was refused: ${JSON.stringify(moved.body)}`);

    const after = await storedApproval(id);
    assert.equal(after.url, 'https://elsewhere.test/v1/resource', 'the edit did not land at all');
    assert.equal(
      after.status, 'pending',
      'the connector kept its approval across a change of endpoint, because the column probe answered unknown',
    );
    assert.equal(after.approved_by, null, 'the approver of the old endpoint is still recorded');
    assert.equal(after.approved_at, null, 'the approval time of the old endpoint is still recorded');
  });

  test('and a watched column this database lacks does not take the others with it', async (t) => {
    if (guard(t)) return;
    // PARTIAL DEGRADATION IS ITS OWN FAIL-OPEN. `dispatch_origin` is one of the
    // four watched columns and exactly the kind an install that cannot ALTER
    // does not have. A fix that answers unknown by attempting the full probe and
    // swallowing the missing-column error would skip the re-pend for `url`,
    // `method` and `auth_type` too — every watched column lost to the one that
    // is absent — and this case is what tells those two shapes apart.
    const id = await approvedEditorConnector();

    const moved = await withColumnDropped(
      tbl(TABLES.API_CONNECTORS), 'dispatch_origin',
      () => withUnknownColumnMetadata(() => call(
        EDITOR, 'PUT', `/edge/app/api-connectors/${id}`, { url: 'https://partial.test/v1/resource' },
      )),
    );
    assert.equal(moved.status, 200, `a legitimate edit was refused: ${JSON.stringify(moved.body)}`);

    const after = await storedApproval(id);
    assert.equal(after.url, 'https://partial.test/v1/resource', 'the edit did not land at all');
    assert.equal(
      after.status, 'pending',
      'one absent watched column cancelled the re-pend for the three the table still has',
    );
    assert.equal(after.approved_by, null, 'the approver of the old endpoint is still recorded');
  });

  for (const [label, run] of [
    ['the probe cannot say so', (body) => withUnknownColumnMetadata(body)],
    ['the probe says so', (body) => body()],
  ]) {
    test(`a database with no status column at all still takes the write when ${label}`, async (t) => {
      if (guard(t)) return;
      // THE OTHER HALF OF THE GATE: what it must NOT do. A deployment whose
      // operator cannot run the ALTER has no approval feature to enforce, and
      // the edit has to land there exactly as it did before. Both probe states
      // are run because they reach the decision by different routes — one reads
      // the absence out of `information_schema`, the other out of the locked row
      // itself — and a fix that only degrades on one of them is a 500 on the
      // other.
      const id = await createConnector(EDITOR);

      const moved = await withColumnDropped(tbl(TABLES.API_CONNECTORS), 'status', () => run(() => call(
        EDITOR, 'PUT', `/edge/app/api-connectors/${id}`, { url: 'https://no-status.test/v1/resource' },
      )));
      assert.equal(moved.status, 200, `the edit was refused on a table with no status: ${JSON.stringify(moved.body)}`);

      const rows = await query(
        `SELECT url FROM \`${tbl(TABLES.API_CONNECTORS)}\` WHERE id = ?`, [id],
      );
      assert.equal(rows[0].url, 'https://no-status.test/v1/resource', 'the edit did not land');
    });
  }

  test('a known column list still re-pends exactly as it did', async (t) => {
    if (guard(t)) return;
    // The control for the path that was already right: the case above changes
    // what happens when the probe cannot answer, and must not change what
    // happens when it can.
    const id = await approvedEditorConnector();

    const moved = await call(
      EDITOR, 'PUT', `/edge/app/api-connectors/${id}`, { url: 'https://known.test/v1/resource' },
    );
    assert.equal(moved.status, 200, `a legitimate edit was refused: ${JSON.stringify(moved.body)}`);

    const after = await storedApproval(id);
    assert.equal(after.status, 'pending', 'the re-pend stopped firing on an ordinary edit');
    assert.equal(after.approved_by, null);
  });

  test('an edit that changes nothing watched leaves the approval alone', async (t) => {
    if (guard(t)) return;
    // The other direction of the same control, with the probe unknown: the fix
    // must not turn "we cannot read the column list" into "re-pend everything",
    // which would revoke an approval on an edit no reviewer needs to see.
    const id = await approvedEditorConnector();

    const moved = await withUnknownColumnMetadata(() => call(
      EDITOR, 'PUT', `/edge/app/api-connectors/${id}`, { name: 'renamed-but-not-repointed' },
    ));
    assert.equal(moved.status, 200, `a legitimate edit was refused: ${JSON.stringify(moved.body)}`);

    const after = await storedApproval(id);
    assert.equal(after.status, 'approved', 'a rename revoked the approval');
    assert.ok(after.approved_by, 'a rename cleared the approver');
  });
});

describe('the locks an update takes are taken only for a caller entitled to the row', () => {
  const STRANGER = '9d949f1e-5c0b-447c-8144-3210469bc333';

  /**
   * A connector owned by somebody who is not the editor, held under an X lock by
   * an unrelated transaction for the duration of `body`. The holder is always
   * released, so a failing assertion cannot leave a lock behind and stall the
   * rest of the file.
   */
  async function withLockedConnectorOf(ownerId, body) {
    const id = await createConnector(ADMIN);
    await query(
      `UPDATE \`${tbl(TABLES.API_CONNECTORS)}\` SET owner_id = ? WHERE id = ?`,
      [ownerId, id],
    );
    const holder = await pool.getConnection();
    try {
      await holder.beginTransaction();
      await holder.query(
        `SELECT id FROM \`${tbl(TABLES.API_CONNECTORS)}\` WHERE id = ? FOR UPDATE`,
        [id],
      );
      return await body({ id, release: () => holder.rollback() });
    } finally {
      try { await holder.rollback(); } catch { /* already released */ }
      holder.release();
    }
  }

  /** Whether `p` settled within `ms`, without consuming its eventual value. */
  function settledWithin(p, ms) {
    const marker = Symbol('pending');
    return Promise.race([
      p.then(() => true, () => true),
      new Promise((r) => setTimeout(() => r(marker), ms)),
    ]).then((v) => v !== marker);
  }

  test('an editor who owns nothing is answered without waiting on the row', async (t) => {
    if (guard(t)) return;
    // EVERY LOCK ON THIS PATH USED TO BE TAKEN BEFORE THE AUTHORIZATION. The
    // serializer reads the row FOR UPDATE, and so do the uniqueness, re-parent,
    // code-version and re-pend probes, while the pre-write hook locks the rows
    // this one references — all of them ahead of the ownership-scoped UPDATE
    // that decides whether the caller may touch it at all. So any authenticated
    // editor who knew an id could park a handler and a pooled connection behind
    // whoever held that row, for up to `innodb_lock_wait_timeout`, and still
    // (correctly) be told 404 afterwards. The same exposure on the delete path
    // was measured at 1213 ms for one request, with six in flight starving the
    // pool.
    //
    // Asserted on SETTLEMENT WHILE THE LOCK IS STILL HELD rather than on a
    // duration: the defect is unbounded waiting, so "answered before the holder
    // let go" is the property, and it cannot pass by being fast.
    await withLockedConnectorOf(STRANGER, async ({ id }) => {
      const inflight = call(EDITOR, 'PUT', `/edge/app/api-connectors/${id}`, { name: 'hijacked' });
      const answered = await settledWithin(inflight, 750);
      const res = await inflight;
      assert.ok(answered, 'the unauthorised update parked on a lock over a row the caller cannot see');
      assert.equal(res.status, 404, `expected 404, got ${JSON.stringify(res.body)}`);
      const rows = await query(
        `SELECT name FROM \`${tbl(TABLES.API_CONNECTORS)}\` WHERE id = ?`, [id],
      );
      assert.equal(rows[0].name, 'cred-fixture', 'an unauthorised update changed the row');
    });
  });

  test('an entitled caller STILL takes the row lock ahead of the statement', async (t) => {
    if (guard(t)) return;
    // The other half, and the reason the fix is an added read rather than a
    // moved probe: for a caller the UPDATE would match, every probe must still
    // run where it ran and take what it took, or the serialisation those probes
    // exist for is gone. So this update MUST wait for the holder.
    await withLockedConnectorOf(ADMIN.id, async ({ id, release }) => {
      const inflight = call(ADMIN, 'PUT', `/edge/app/api-connectors/${id}`, { name: 'renamed-by-admin' });
      const answeredEarly = await settledWithin(inflight, 750);
      assert.equal(
        answeredEarly, false,
        'the entitled update did not wait for the row lock — the probes no longer run before the statement',
      );
      await release();
      const res = await inflight;
      assert.equal(res.status, 200, `expected the update to land, got ${JSON.stringify(res.body)}`);
      const rows = await query(
        `SELECT name FROM \`${tbl(TABLES.API_CONNECTORS)}\` WHERE id = ?`, [id],
      );
      assert.equal(rows[0].name, 'renamed-by-admin', 'the entitled update did not land');
    });
  });

  test('an entitled EDITOR still takes the row lock ahead of the statement', async (t) => {
    if (guard(t)) return;
    // The ADMIN case above cannot witness this ordering at all: an
    // administrator's scope clause is empty, so the entitlement read is skipped
    // outright and that path is byte-identical to before the fix — it would stay
    // green even if the read's lock order regressed for the callers who DO run
    // it. An editor's scope clause is never empty, so this is that caller, on a
    // row it actually owns.
    await withLockedConnectorOf(EDITOR.id, async ({ id, release }) => {
      const inflight = call(EDITOR, 'PUT', `/edge/app/api-connectors/${id}`, { name: 'renamed-by-owner-editor' });
      const answeredEarly = await settledWithin(inflight, 750);
      assert.equal(
        answeredEarly, false,
        'the entitled editor\'s update did not wait for the row lock — the entitlement read no longer runs '
        + 'where the other probes on this path run',
      );
      await release();
      const res = await inflight;
      assert.equal(res.status, 200, `expected the update to land, got ${JSON.stringify(res.body)}`);
      const rows = await query(
        `SELECT name FROM \`${tbl(TABLES.API_CONNECTORS)}\` WHERE id = ?`, [id],
      );
      assert.equal(rows[0].name, 'renamed-by-owner-editor', 'the entitled editor\'s update did not land');
    });
  });

  test('an entitled editor is not refused by the read that refuses the stranger', async (t) => {
    if (guard(t)) return;
    // The control the added read most needs: a scope that answers "no" to a
    // caller the statement would have matched is a 404 on a legitimate edit, and
    // nothing else here would say so. The editor owns this one.
    const id = await createConnector(EDITOR);
    const res = await call(EDITOR, 'PUT', `/edge/app/api-connectors/${id}`, { name: 'renamed-by-owner' });
    assert.equal(res.status, 200, `a legitimate edit was refused: ${JSON.stringify(res.body)}`);
    const rows = await query(
      `SELECT name FROM \`${tbl(TABLES.API_CONNECTORS)}\` WHERE id = ?`, [id],
    );
    assert.equal(rows[0].name, 'renamed-by-owner', 'a legitimate edit did not land');
  });
});
