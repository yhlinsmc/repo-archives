/**
 * public-read-keyset-real-db.test.js — CRITICAL regression (silent data loss):
 * the Public Integration API P2 keyset pagination (`/templates`, `/runs`) dropped
 * EVERY row past page 1 whenever a `created_at` had a single-digit month/day (and
 * additionally skewed by the process TZ). Root cause: the continuation param was
 * bound as a JS `Date`, which the mariadb TEXT protocol serialises via the
 * process-local TZ and WITHOUT zero-padding (Asia/Taipei: 2026-03-07T14:04:05Z →
 * '2026-3-7 22:4:5'). Compared against the string-typed
 * `COALESCE(created_at, '1970-01-01 00:00:00')` that breaks both ways.
 *
 * Why this needs a REAL MariaDB: the bug lives in the live driver's Date
 * serialisation — a mock/in-memory harness cannot exercise it, which is exactly
 * why it shipped. The fix binds a canonical zero-padded UTC string
 * (public-scope.utcSqlDatetime) so the comparison is exact.
 *
 * This file drives the EXACT production keyset fragment + ORDER BY
 * (`publicRead._keysetFragment` / `_ORDER_BY`) and the real cursor
 * encode/decode, so a revert to `new Date(cursor.c)` re-fails it.
 *
 * DB isolation: NEVER touches the shared dev-infra-mariadb. CI path uses
 * DB_TEST_HOST + a throwaway DATABASE; local path spins a throwaway container
 * (unique name, random port, --rm). Neither available → the DB-backed suite
 * skips gracefully (the TZ-independent bind guards below still run).
 */
const { test, describe, before, after } = require('node:test');
const assert = require('node:assert/strict');
const net = require('node:net');
const path = require('node:path');
const { spawnSync, execFileSync } = require('node:child_process');
const crypto = require('node:crypto');
const mariadb = require('mariadb');

const { encodeCursor, decodeCursor, utcSqlDatetime } = require('../../src/edge/lib/public-scope');
const publicRead = require('../../src/edge/routes/internal/public-read');

const TABLE = 'p2ks_templates';
const LIMIT = 2;

// Seed spanning: a NULL created_at (sorts first via the 1970 sentinel),
// single-digit month/day (the padding-break case), a single-digit hour, a
// double-digit month/day, and a created_at TIE (id tie-break). > 2 pages at
// LIMIT=2. Canonical zero-padded strings so lexicographic == chronological.
const SEED = [
  ['n-null', null],
  ['m03-d01', '2026-03-01 00:00:00'],
  ['m03-d02', '2026-03-02 09:05:07'],
  ['m03-d07', '2026-03-07 14:04:05'],
  ['m11-d09', '2026-11-09 23:59:59'],
  ['m12-d25a', '2026-12-25 12:00:00'],
  ['m12-d25b', '2026-12-25 12:00:00'],
];
const SENTINEL = '1970-01-01 00:00:00';
// Expected total order under COALESCE(created_at, sentinel) ASC, id ASC.
const EXPECTED = [...SEED]
  .sort((a, b) => {
    const ka = a[1] || SENTINEL;
    const kb = b[1] || SENTINEL;
    if (ka < kb) return -1;
    if (ka > kb) return 1;
    return a[0] < b[0] ? -1 : a[0] > b[0] ? 1 : 0;
  })
  .map((r) => r[0]);

// ── TZ-independent bind guards (no DB; always run) ───────────────────────────
// These fail immediately if the fix is reverted to binding a JS Date.
describe('keyset bind is a canonical zero-padded UTC string (not a Date)', () => {
  test('c=0 → the 1970 NULL sentinel string, never a Date', () => {
    const { params } = publicRead._keysetFragment({ c: 0, i: 'x' });
    assert.equal(typeof params[0], 'string', 'param must be a string, not a Date');
    assert.equal(params[0], SENTINEL);
    assert.equal(params[1], SENTINEL);
    assert.equal(params[2], 'x');
  });

  test('single-digit month/day instant is zero-padded UTC', () => {
    const { params } = publicRead._keysetFragment({ c: Date.UTC(2026, 2, 7, 14, 4, 5), i: 'r1' });
    assert.equal(params[0], '2026-03-07 14:04:05');
    assert.equal(params[0], params[1]);
  });

  test('bind is identical under a non-UTC process TZ (deployed Asia/Taipei zone)', () => {
    const routePath = path.resolve(__dirname, '../../src/edge/routes/internal/public-read.js');
    const script = `
      const assert = require('node:assert/strict');
      const pr = require(${JSON.stringify(routePath)});
      assert.equal(process.env.TZ, 'Asia/Taipei');
      // Sanity: a bound Date WOULD serialise wrong here (the shipped bug).
      const p = pr._keysetFragment({ c: Date.UTC(2026, 2, 7, 14, 4, 5), i: 'r1' }).params;
      assert.equal(p[0], '2026-03-07 14:04:05', 'bind must be UTC + padded under Asia/Taipei');
      console.log('TZ_BIND_PASS');
    `;
    const out = execFileSync(process.execPath, ['-e', script], {
      env: { ...process.env, TZ: 'Asia/Taipei' },
      encoding: 'utf8',
    });
    assert.match(out, /TZ_BIND_PASS/);
  });
});

// ── Real-MariaDB pagination (throwaway; skips if unavailable) ─────────────────

function getFreePort() {
  return new Promise((resolve, reject) => {
    const srv = net.createServer();
    srv.once('error', reject);
    srv.listen(0, '127.0.0.1', () => {
      const { port } = srv.address();
      srv.close(() => resolve(port));
    });
  });
}

function dockerAvailable() {
  const r = spawnSync('docker', ['version', '--format', '{{.Server.Version}}'], { encoding: 'utf8' });
  return r.status === 0 && !!(r.stdout && r.stdout.trim());
}

function pickLocalImage() {
  const r = spawnSync('docker', ['images', '--format', '{{.Repository}}:{{.Tag}}'], { encoding: 'utf8' });
  if (r.status !== 0) return null;
  const have = new Set((r.stdout || '').split('\n').map((s) => s.trim()));
  for (const img of ['mariadb:11', 'mariadb:10.11', 'mariadb:latest']) {
    if (have.has(img)) return img;
  }
  return null;
}

async function waitForDb(cfg, timeoutMs) {
  const deadline = Date.now() + timeoutMs;
  let lastErr;
  while (Date.now() < deadline) {
    let conn;
    try {
      conn = await mariadb.createConnection({ ...cfg, connectTimeout: 2000 });
      await conn.query('SELECT 1');
      await conn.end();
      return true;
    } catch (err) {
      lastErr = err;
      if (conn) { try { await conn.end(); } catch { /* ignore */ } }
      await new Promise((r) => setTimeout(r, 1000));
    }
  }
  throw lastErr || new Error('mariadb not ready');
}

let container = null; // { name } when we spun one
let pool = null;
let dbCfg = null; // { host, port, user, password, database }
let skipReason = null;

/**
 * Resolve a throwaway MariaDB. CI: DB_TEST_HOST (+ DB_TEST_ROOT_PASSWORD) → a
 * throwaway DATABASE on that server. Local: a throwaway CONTAINER. Never the
 * shared dev-infra-mariadb .devcontainer/.env auto-detect.
 */
async function resolveThrowaway() {
  const database = `p2ks_${process.pid}_${Date.now()}`;

  if (process.env.DB_TEST_HOST && process.env.DB_TEST_ROOT_PASSWORD) {
    const server = {
      host: process.env.DB_TEST_HOST,
      port: parseInt(process.env.DB_TEST_PORT || '3306', 10),
      user: 'root',
      password: process.env.DB_TEST_ROOT_PASSWORD,
    };
    await waitForDb(server, 10_000);
    const admin = await mariadb.createConnection(server);
    try { await admin.query(`CREATE DATABASE \`${database}\``); } finally { await admin.end(); }
    return { ...server, database };
  }

  if (!dockerAvailable()) { skipReason = 'docker unavailable'; return null; }
  const image = pickLocalImage();
  if (!image) { skipReason = 'no local mariadb image'; return null; }

  const name = `p2ks-test-${process.pid}-${crypto.randomBytes(4).toString('hex')}`;
  const password = crypto.randomBytes(12).toString('hex');
  const port = await getFreePort();
  const run = spawnSync('docker', [
    'run', '-d', '--rm', '--name', name,
    '-e', `MARIADB_ROOT_PASSWORD=${password}`,
    '-e', `MARIADB_DATABASE=${database}`,
    '-p', `127.0.0.1:${port}:3306`,
    image,
  ], { encoding: 'utf8' });
  if (run.status !== 0) { skipReason = `docker run failed: ${run.stderr || ''}`.slice(0, 200); return null; }
  container = { name };
  const server = { host: '127.0.0.1', port, user: 'root', password };
  await waitForDb(server, 60_000);
  return { ...server, database };
}

function teardownContainer() {
  if (container) {
    spawnSync('docker', ['rm', '-f', container.name], { encoding: 'utf8' });
    container = null;
  }
}

// Drive the EXACT production keyset fragment + ORDER BY over a real connection,
// following the real encode/decode cursor across every page.
async function collectAllPages(conn) {
  const collected = [];
  const pages = [];
  let cursor = null;
  let guard = 0;
  do {
    const { clause, params } = publicRead._keysetFragment(cursor);
    // eslint-disable-next-line no-await-in-loop
    const rows = await conn.query(
      `SELECT id, created_at FROM \`${TABLE}\` WHERE 1=1${clause} ${publicRead._ORDER_BY} LIMIT ?`,
      [...params, LIMIT + 1],
    );
    const hasMore = rows.length > LIMIT;
    const pageRows = hasMore ? rows.slice(0, LIMIT) : rows;
    pages.push(pageRows.map((r) => r.id));
    for (const r of pageRows) collected.push(r.id);
    const last = pageRows[pageRows.length - 1];
    const next = hasMore && last ? encodeCursor(last) : null;
    cursor = next ? decodeCursor(next) : null;
    guard += 1;
  } while (cursor && guard < 100);
  return { collected, pages };
}

describe('real-mariadb keyset pagination returns every row across pages', () => {
  before(async () => {
    try {
      dbCfg = await resolveThrowaway();
    } catch (err) {
      skipReason = `throwaway DB setup failed: ${err && err.message}`;
      teardownContainer();
      dbCfg = null;
      return;
    }
    if (!dbCfg) return;
    pool = mariadb.createPool({
      host: dbCfg.host, port: dbCfg.port, user: dbCfg.user, password: dbCfg.password,
      database: dbCfg.database, connectionLimit: 4,
      // Mirror the production pool exactly — dateStrings + UTC session are load
      // bearing for this bug's reproduction.
      dateStrings: true, timezone: '+00:00',
    });
    const conn = await pool.getConnection();
    try {
      await conn.query(
        `CREATE TABLE \`${TABLE}\` (id CHAR(36) PRIMARY KEY, created_at TIMESTAMP NULL DEFAULT NULL) ENGINE=InnoDB`,
      );
      for (const [id, ts] of SEED) {
        // eslint-disable-next-line no-await-in-loop
        await conn.query(`INSERT INTO \`${TABLE}\` (id, created_at) VALUES (?, ?)`, [id, ts]);
      }
    } finally {
      conn.release();
    }
  });

  after(async () => {
    if (pool) {
      if (dbCfg && !container) {
        // CI throwaway-DATABASE mode: drop the DB we created.
        try {
          const admin = await pool.getConnection();
          try { await admin.query(`DROP DATABASE IF EXISTS \`${dbCfg.database}\``); } finally { admin.release(); }
        } catch { /* best effort */ }
      }
      await pool.end();
      pool = null;
    }
    teardownContainer();
  });

  test('every row appears exactly once, in order, following next_cursor', async (t) => {
    if (!dbCfg) { t.skip(`real MariaDB unavailable: ${skipReason || 'unknown'}`); return; }
    const conn = await pool.getConnection();
    let result;
    try {
      result = await collectAllPages(conn);
    } finally {
      conn.release();
    }
    // No loss.
    assert.equal(result.collected.length, SEED.length,
      `expected all ${SEED.length} rows, got ${result.collected.length}: pages=${JSON.stringify(result.pages)}`);
    // No dup.
    assert.equal(new Set(result.collected).size, SEED.length, 'duplicate rows across pages');
    // Correct total order (created_at then id, NULL first via sentinel).
    assert.deepEqual(result.collected, EXPECTED);
    // Pages are bounded by LIMIT and the last is a partial (proves real paging,
    // not one big page).
    for (const p of result.pages) assert.ok(p.length <= LIMIT);
  });

  test('same completeness under a non-UTC process TZ (Asia/Taipei) via real driver', async (t) => {
    if (!dbCfg) { t.skip(`real MariaDB unavailable: ${skipReason || 'unknown'}`); return; }
    // The driver serialises bound params in the PROCESS TZ — re-run the whole
    // paginate loop in a child pinned to Asia/Taipei (the deployed edge zone) so
    // both the TZ skew AND the padding break are active in the old code path.
    const routePath = path.resolve(__dirname, '../../src/edge/routes/internal/public-read.js');
    const scopePath = path.resolve(__dirname, '../../src/edge/lib/public-scope.js');
    const script = `
      const assert = require('node:assert/strict');
      const mariadb = require(${JSON.stringify(require.resolve('mariadb'))});
      const pr = require(${JSON.stringify(routePath)});
      const { encodeCursor, decodeCursor } = require(${JSON.stringify(scopePath)});
      const TABLE = ${JSON.stringify(TABLE)};
      const LIMIT = ${LIMIT};
      const EXPECTED = ${JSON.stringify(EXPECTED)};
      const cfg = JSON.parse(process.env.P2KS_CFG);
      assert.equal(process.env.TZ, 'Asia/Taipei');
      (async () => {
        const pool = mariadb.createPool({ ...cfg, connectionLimit: 2, dateStrings: true, timezone: '+00:00' });
        const conn = await pool.getConnection();
        const collected = [];
        let cursor = null, guard = 0;
        do {
          const { clause, params } = pr._keysetFragment(cursor);
          const rows = await conn.query(
            'SELECT id, created_at FROM \`' + TABLE + '\` WHERE 1=1' + clause + ' ' + pr._ORDER_BY + ' LIMIT ?',
            [...params, LIMIT + 1]);
          const hasMore = rows.length > LIMIT;
          const pageRows = hasMore ? rows.slice(0, LIMIT) : rows;
          for (const r of pageRows) collected.push(r.id);
          const last = pageRows[pageRows.length - 1];
          const next = hasMore && last ? encodeCursor(last) : null;
          cursor = next ? decodeCursor(next) : null;
          guard += 1;
        } while (cursor && guard < 100);
        conn.release();
        await pool.end();
        assert.deepEqual(collected, EXPECTED, 'Asia/Taipei paginate must return every row in order');
        console.log('TZ_PAGINATE_PASS');
      })().catch((e) => { console.error(e); process.exit(1); });
    `;
    const out = execFileSync(process.execPath, ['-e', script], {
      env: {
        ...process.env,
        TZ: 'Asia/Taipei',
        P2KS_CFG: JSON.stringify({
          host: dbCfg.host, port: dbCfg.port, user: dbCfg.user, password: dbCfg.password, database: dbCfg.database,
        }),
      },
      encoding: 'utf8',
    });
    assert.match(out, /TZ_PAGINATE_PASS/);
  });
});
