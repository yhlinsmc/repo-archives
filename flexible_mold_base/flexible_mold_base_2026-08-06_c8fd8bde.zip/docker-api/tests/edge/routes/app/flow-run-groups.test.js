// docker-api/tests/edge/routes/app/flow-run-groups.test.js
//
// The grouped run history: one row per template, what it counts, and the two
// groups that have no template row behind them.
const { test } = require('node:test');
const assert = require('node:assert');
const express = require('express');

// Every statement the route issues, in order, so a test can assert on the SQL
// itself — the visibility predicate and the page bounds are properties of the
// statement, not of the stubbed rows.
let issued = [];
let responder = () => [];

require.cache[require.resolve('../../../../src/edge/db')] = {
  exports: {
    pool: {
      ro: {
        getConnection: async () => ({
          query: async (sql, params) => {
            issued.push({ sql, params });
            const out = responder(sql, params);
            if (out instanceof Error) throw out;
            return out;
          },
          release: () => {},
        }),
      },
      rw: { getConnection: async () => ({ query: async () => [], release: () => {} }) },
    },
    t: (x) => x,
  },
};

const { router } = require('../../../../src/edge/routes/app/flow-recipe-runs/aggregate');

function app(user) {
  const a = express();
  a.use(express.json());
  a.use((req, _res, next) => { if (user) req.user = user; next(); });
  a.use('/', router);
  return a;
}

async function get(a, path) {
  const server = a.listen(0);
  try {
    const { port } = server.address();
    const res = await fetch(`http://127.0.0.1:${port}${path}`);
    const json = await res.json().catch(() => ({}));
    return { status: res.status, json };
  } finally {
    // Closed on the throwing path too. With the close reachable only where
    // nothing threw, a failed assertion leaks this handle, the runner never
    // exits, and the job reports a timeout instead of the assertion that failed.
    server.close();
  }
}

const ADMIN = { id: 'aaaaaaaa-0000-0000-0000-000000000001', role: 'admin' };
const USER = { id: 'bbbbbbbb-0000-0000-0000-000000000002', role: 'user' };
const TEMPLATE_A = '11111111-1111-1111-1111-111111111111';
const TEMPLATE_GONE = '22222222-2222-2222-2222-222222222222';

/** A stub that answers each statement by what it is asking for. */
function stub({ groups = [], total = 0, users = [] } = {}) {
  return (sql) => {
    if (sql.includes('ROW_NUMBER()')) return groups;
    if (sql.includes('COUNT(*) AS cnt')) return [{ cnt: total }];
    if (sql.includes('SELECT id, display_name, kc_username')) return users;
    return [];
  };
}

/** A row as the grouped statement returns it: the window pass's own fields plus
 *  the joined template's, which are NULL when the template no longer exists. */
function groupRow(over) {
  return {
    template_id: TEMPLATE_A,
    run_count: 3,
    last_run_at: '2026-07-20 09:30:00',
    last_run_id: 'cccccccc-0000-0000-0000-000000000003',
    last_status: 'success',
    last_actor_id: USER.id,
    template_row_id: TEMPLATE_A,
    template_name: 'Nightly build',
    template_blueprint_id: 'bp',
    template_variant_id: 'var',
    ...over,
  };
}

/** The joined template columns as they arrive for a group with no template row. */
const NO_TEMPLATE_ROW = {
  template_row_id: null,
  template_name: null,
  template_blueprint_id: null,
  template_variant_id: null,
};

test.beforeEach(() => { issued = []; responder = stub(); });

test('a group carries its count, its last run and its template name', async () => {
  responder = stub({
    groups: [groupRow()],
    total: 1,
    users: [{ id: USER.id, display_name: 'Ada', kc_username: 'ada' }],
  });
  const { status, json } = await get(app(ADMIN), '/groups');
  assert.strictEqual(status, 200);
  const [row] = json.data.rows;
  assert.strictEqual(row.template_id, TEMPLATE_A);
  assert.strictEqual(row.template_name, 'Nightly build');
  assert.strictEqual(row.template_exists, true);
  assert.strictEqual(row.run_count, 3);
  assert.strictEqual(row.last_status, 'success');
  assert.strictEqual(row.last_actor_name, 'Ada');
  assert.strictEqual(json.data.total, 1);
});

test('a timestamp reaches the client pinned to UTC, not as the driver spelling', async () => {
  responder = stub({ groups: [groupRow()], total: 1 });
  const { json } = await get(app(ADMIN), '/groups');
  assert.strictEqual(json.data.rows[0].last_run_at, '2026-07-20T09:30:00Z');
});

test('a group whose template was deleted keeps its runs and says the template is gone', async () => {
  responder = stub({
    // The join found no template row for this id.
    groups: [groupRow({ template_id: TEMPLATE_GONE, ...NO_TEMPLATE_ROW })],
    total: 1,
  });
  const { json } = await get(app(ADMIN), '/groups');
  const [row] = json.data.rows;
  assert.strictEqual(row.template_id, TEMPLATE_GONE);
  assert.strictEqual(row.template_exists, false);
  assert.strictEqual(row.template_name, '');
  assert.strictEqual(row.run_count, 3);
});

test('runs recorded with no template are a group, and its id stays null', async () => {
  responder = stub({ groups: [groupRow({ template_id: null, ...NO_TEMPLATE_ROW })], total: 1 });
  const { json } = await get(app(ADMIN), '/groups');
  const [row] = json.data.rows;
  assert.strictEqual(row.template_id, null);
  assert.strictEqual(row.template_exists, false);
  assert.strictEqual(row.template_name, '');
});

test('the grouped read partitions by template and names the newest run of each', async () => {
  responder = stub({ groups: [groupRow()], total: 1 });
  await get(app(ADMIN), '/groups');
  const [{ sql }] = issued;
  assert.match(sql, /PARTITION BY r\.`template_id`/);
  assert.match(sql, /ORDER BY r\.`created_at` DESC, r\.`id` DESC/);
  assert.match(sql, /WHERE g\.`rn` = 1/);
});

test('the page ordering is total, and does not repeat the term it is already sorted by', async () => {
  responder = stub({ groups: [groupRow()], total: 1 });
  await get(app(ADMIN), '/groups');
  assert.match(
    issued[0].sql,
    /ORDER BY g\.`last_run_at` IS NULL, g\.`last_run_at` DESC, g\.`template_id` DESC LIMIT/,
  );
});

test('a nullable ordering puts the rows with nothing to sort on last, in both directions', async () => {
  // A group whose template is gone has no name; an actor whose account is gone
  // has none either. Without this an A-to-Z sort leads with them.
  responder = stub({ groups: [], total: 0 });
  await get(app(ADMIN), '/groups?sort=template_name&order=asc');
  assert.match(issued[0].sql, /ORDER BY ut\.`name` IS NULL, ut\.`name` ASC/);
});

test('the default order is what happened lately', async () => {
  responder = stub({ groups: [], total: 0 });
  const { json } = await get(app(ADMIN), '/groups');
  assert.strictEqual(json.data.sort, 'last_run_at');
  assert.strictEqual(json.data.order, 'desc');
});

test('a requested order is applied and echoed back', async () => {
  responder = stub({ groups: [], total: 0 });
  const { json } = await get(app(ADMIN), '/groups?sort=run_count&order=asc');
  assert.match(issued[0].sql, /ORDER BY g\.`run_count` IS NULL, g\.`run_count` ASC/);
  assert.strictEqual(json.data.sort, 'run_count');
  assert.strictEqual(json.data.order, 'asc');
});

test('a column the list cannot be ordered by falls back to the default order', async () => {
  responder = stub({ groups: [], total: 0 });
  const { json } = await get(app(ADMIN), '/groups?sort=whatever%60--&order=sideways');
  // Nothing the caller sent reaches the statement: the name is looked up, never
  // interpolated.
  assert.ok(!issued[0].sql.includes('whatever'));
  assert.match(issued[0].sql, /ORDER BY g\.`last_run_at` IS NULL, g\.`last_run_at` DESC/);
  assert.strictEqual(json.data.sort, 'last_run_at');
});

test('a repeated sort parameter names nothing, and neither does a prototype key', async () => {
  // A repeated query parameter arrives as an array, and a property lookup would
  // convert it back to the same string; a field that is not a string is not a
  // field. `constructor` and `__proto__` name nothing either.
  responder = stub({ groups: [], total: 0 });
  const { json } = await get(app(ADMIN), '/groups?sort=run_count&sort=run_count');
  assert.strictEqual(json.data.sort, 'last_run_at');
  issued = [];
  const proto = await get(app(ADMIN), '/groups?sort=constructor');
  assert.strictEqual(proto.json.data.sort, 'last_run_at');
  assert.ok(!issued[0].sql.includes('constructor'));
});

test('the template name and the actor can each order the list', async () => {
  responder = stub({ groups: [], total: 0 });
  await get(app(ADMIN), '/groups?sort=template_name&order=asc');
  assert.match(issued[0].sql, /ORDER BY ut\.`name` IS NULL, ut\.`name` ASC/);
  issued = [];
  await get(app(ADMIN), '/groups?sort=last_actor_name&order=asc');
  assert.match(
    issued[0].sql,
    /ORDER BY COALESCE\(u\.`display_name`, u\.`kc_username`\) IS NULL, COALESCE\(u\.`display_name`, u\.`kc_username`\) ASC/,
  );
});

test('the grouped read carries no column nothing reads out of it', async () => {
  // The run's own blueprint was selected in the derived table and never read:
  // the blueprint a first-level entry names is the TEMPLATE's current one, which
  // the join already supplies. A column that travels the whole statement and is
  // dropped at the end is a column a later reader has to prove is dead.
  responder = stub({ groups: [], total: 0 });
  await get(app(ADMIN), '/groups');
  assert.ok(!issued[0].sql.includes('last_blueprint_id'));
  assert.ok(issued[0].sql.includes('ut.`blueprint_id` AS template_blueprint_id'));
});

test('the default page is applied when the caller asks for none', async () => {
  responder = stub({ groups: [], total: 0 });
  const { json } = await get(app(ADMIN), '/groups');
  assert.strictEqual(json.data.limit, 50);
  assert.strictEqual(json.data.offset, 0);
  assert.deepStrictEqual(issued[0].params.slice(-2), [50, 0]);
});

test('a page position is honoured, and the total counts the same predicate', async () => {
  responder = stub({ groups: [], total: 42 });
  const { json } = await get(app(USER), '/groups?limit=2&offset=4');
  assert.deepStrictEqual(issued[0].params.slice(-2), [2, 4]);
  assert.strictEqual(json.data.total, 42);
  const countQuery = issued.find((q) => q.sql.includes('COUNT(*) AS cnt'));
  // Same predicate, same bindings as the row query — which is now none at all.
  // The pairing is what matters: a count built over a different set than the
  // rows tells the reader how much exists beyond what they were shown.
  assert.deepStrictEqual(countQuery.params, []);
});

test('a limit with no position is read as the first page rather than dropped', async () => {
  responder = stub({ groups: [], total: 0 });
  const { json } = await get(app(ADMIN), '/groups?limit=5');
  assert.strictEqual(json.data.limit, 5);
  assert.strictEqual(json.data.offset, 0);
});

test('a malformed page is refused before a connection is taken', async () => {
  const { status, json } = await get(app(ADMIN), '/groups?limit=5&offset=-1');
  assert.strictEqual(status, 400);
  assert.strictEqual(json.error.code, 'INVALID_PAGINATION');
  assert.strictEqual(issued.length, 0);
});

test('a page size above the shared ceiling is refused, not clamped', async () => {
  const { status } = await get(app(ADMIN), '/groups?limit=5000&offset=0');
  assert.strictEqual(status, 400);
});

test('an unauthenticated caller is refused', async () => {
  const { status } = await get(app(null), '/groups');
  assert.strictEqual(status, 401);
  assert.strictEqual(issued.length, 0);
});

test('a database failure is reported as a server error, not as an empty history', async () => {
  responder = () => new Error('boom');
  const { status, json } = await get(app(ADMIN), '/groups');
  assert.strictEqual(status, 500);
  assert.ok(!json.data);
});
