/**
 * POST /api/schema/variant_overrides/by-variants — the batch read that replaces
 * a repeated `?variant_id=` GET filter (which the infra→edge proxy folds into
 * one comma-joined scalar, so it matches zero rows on a real deployment).
 *
 * Two halves:
 *  - route behaviour: auth is required, the argument is validated, and the SQL
 *    is a real IN clause with one placeholder per id;
 *  - SCHEMA PARITY: every column the SELECT names is checked against the ACTUAL
 *    DDL in table-ddls.js. The query result here is a stub, so a column that
 *    does not exist would stay green in both runners and 500 on a live
 *    deployment — this is the check that closes that gap.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const { buildEngineTableDDLs } = require('../../../../src/table-ddls');
const { TABLES } = require('../../../../src/shared/constants');

// ── schema parity ───────────────────────────────────────────────────────────
// The column list the route SELECTs. Kept as data so the parity check below and
// the route stay comparable by inspection; a drift between the two is the thing
// the route test's SQL assertion catches.
const SELECTED_COLUMNS = [
  'id', 'variant_id', 'field_id', 'action', 'override_value',
  'compute_rule', 'cell_targets', 'created_at',
];

const SQL_TYPES = /^`?([a-z_]+)`?\s+(?:CHAR|VARCHAR|INT|DOUBLE|TIMESTAMP|JSON|TEXT|ENUM|BOOLEAN|TINYINT|BIGINT|DATETIME|DECIMAL|FLOAT|BLOB)\b/i;
let variantOverrideColumns;

before(() => {
  for (const ddl of buildEngineTableDDLs((n) => n)) {
    const m = ddl.match(/CREATE TABLE IF NOT EXISTS `([^`]+)`/);
    if (!m || m[1] !== TABLES.VARIANT_OVERRIDES) continue;
    const cols = new Set();
    for (const rawLine of ddl.split('\n')) {
      const line = rawLine.trim();
      if (!line || line.startsWith('--') || line.startsWith('/*')) continue;
      const cm = line.match(SQL_TYPES);
      if (cm) cols.add(cm[1]);
    }
    variantOverrideColumns = cols;
  }
});

describe('variant_overrides/by-variants — schema parity against table-ddls.js', () => {
  it('parses a column set for variant_overrides', () => {
    assert.ok(variantOverrideColumns && variantOverrideColumns.size > 0);
  });

  it('every column the SELECT names exists on the table', () => {
    for (const col of SELECTED_COLUMNS) {
      assert.ok(
        variantOverrideColumns.has(col),
        `variant_overrides has no column '${col}' — the batch read would 500 on a live deployment`,
      );
    }
  });

  it('the filter column exists, and so does the column the caller regroups on', () => {
    assert.ok(variantOverrideColumns.has('variant_id'));
    assert.ok(variantOverrideColumns.has('field_id'));
    assert.ok(variantOverrideColumns.has('action'));
  });
});

// ── route behaviour ─────────────────────────────────────────────────────────
const dbKey = require.resolve('../../../../src/edge/db');

let queries;
let stubRows;
let currentUser;

function makeConn() {
  return {
    async query(sql, params) {
      queries.push({ sql, params });
      return stubRows;
    },
    release() {},
  };
}

require.cache[dbKey] = {
  id: dbKey,
  filename: dbKey,
  loaded: true,
  exports: {
    pool: {
      ro: { getConnection: async () => makeConn() },
      rw: { getConnection: async () => makeConn() },
    },
    t: (n) => `fmb_${n}`,
    getDynamicPool: async () => ({ ro: { getConnection: async () => makeConn() } }),
  },
};

const variantOverrides = require('../../../../src/edge/routes/app/schema/routes-variant-overrides');

let server;
let baseUrl;

before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { req.user = currentUser; next(); });
  const router = express.Router();
  variantOverrides.register(router);
  app.use('/api/schema', router);
  server = http.createServer(app);
  await new Promise((resolve) => server.listen(0, resolve));
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});

beforeEach(() => {
  queries = [];
  stubRows = [];
  currentUser = { id: 'u1', role: 'user' };
});

after(async () => {
  // Without this the listening socket keeps the runner alive after the last
  // assertion — a green suite that never exits.
  if (server) await new Promise((resolve) => server.close(resolve));
});

async function post(body) {
  const res = await fetch(`${baseUrl}/api/schema/variant_overrides/by-variants`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  return { status: res.status, body: await res.json() };
}

describe('POST /variant_overrides/by-variants', () => {
  it('requires an authenticated caller', async () => {
    currentUser = undefined;
    const r = await post({ variant_ids: ['v1'] });
    assert.equal(r.status, 401);
    assert.equal(queries.length, 0);
  });

  it('serves a plain user — this is a read, and the write gate is elsewhere', async () => {
    stubRows = [{ id: 'o1', variant_id: 'v1', field_id: 'f1', action: 'hide' }];
    const r = await post({ variant_ids: ['v1'] });
    assert.equal(r.status, 200);
    assert.equal(r.body.data.length, 1);
  });

  it('builds a real IN clause with one placeholder per id', async () => {
    await post({ variant_ids: ['v1', 'v2', 'v3'] });
    assert.equal(queries.length, 1);
    // The failure this route exists to prevent is an equality match against a
    // comma-joined scalar; assert the opposite shape explicitly.
    assert.match(queries[0].sql, /WHERE variant_id IN \(\?, \?, \?\)/);
    assert.deepEqual(queries[0].params, ['v1', 'v2', 'v3']);
    assert.ok(!/variant_id\s*=\s*\?/.test(queries[0].sql));
  });

  it('selects exactly the columns the parity check validated', async () => {
    await post({ variant_ids: ['v1'] });
    for (const col of SELECTED_COLUMNS) {
      assert.match(queries[0].sql, new RegExp(`\\b${col}\\b`), `SELECT is missing ${col}`);
    }
  });

  it('rejects a non-array argument', async () => {
    const r = await post({ variant_ids: 'v1' });
    assert.equal(r.status, 400);
    assert.equal(queries.length, 0);
  });

  it('rejects non-string ids rather than passing them to the driver', async () => {
    const r = await post({ variant_ids: ['v1', 42] });
    assert.equal(r.status, 400);
    assert.equal(queries.length, 0);
  });

  it('short-circuits an empty list without touching the database', async () => {
    const r = await post({ variant_ids: [] });
    assert.equal(r.status, 200);
    assert.deepEqual(r.body.data, []);
    assert.equal(queries.length, 0);
  });

  it('caps the batch size', async () => {
    const r = await post({ variant_ids: Array.from({ length: 1001 }, (_, i) => `v${i}`) });
    assert.equal(r.status, 400);
    assert.equal(queries.length, 0);
  });
});
