/**
 * capacity-rule-guard.test.js — the DoS bounds on a rule write (PR-C review):
 * filters conditions ≤ 50 and filters/params JSON ≤ 8KB, plus per-type level /
 * group_by legality (config-rewrite target model), on both the scenario rules
 * mount and the config template rules mount. Pure-function units + 400-path
 * integration (the guard rejects before any DB query).
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../../../src/edge/db');
// Stub db: the guard rejects before any query runs, so an empty stub suffices.
const stub = { getConnection: async () => ({ async query() { return []; }, release() {} }), query: async () => [] };
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: { ro: stub, rw: stub }, t: (n) => `fmb_${n}` },
};

const {
  validateRuleWritePayload, validateGlobalRuleWritePayload, MAX_RULE_CONDITIONS,
} = require('../../../../src/edge/routes/app/capacity/_shared');
const router = require('../../../../src/edge/routes/app/capacity');

const manyConditions = (n) => Array.from({ length: n }, (_, i) => ({ field: 'role', op: '=', value: `v${i}` }));

describe('validateRuleWritePayload (pure)', () => {
  it('accepts an in-bounds filters/params', () => {
    assert.equal(validateRuleWritePayload({ level: 'vm', filters: manyConditions(3), params: { max: 8 } }), null);
  });
  it('accepts a missing filters/params', () => {
    assert.equal(validateRuleWritePayload({ name: 'r' }), null);
  });
  it('rejects > 50 conditions', () => {
    const bad = validateRuleWritePayload({ level: 'vm', filters: manyConditions(MAX_RULE_CONDITIONS + 1) });
    assert.equal(bad.code, 'TOO_MANY_CONDITIONS');
  });
  it('rejects an oversized JSON blob', () => {
    const bad = validateRuleWritePayload({ params: { blob: 'x'.repeat(9000) } });
    assert.equal(bad.code, 'PAYLOAD_TOO_LARGE');
  });
  it('tolerates filters arriving as a JSON string', () => {
    const bad = validateRuleWritePayload({ filters: JSON.stringify(manyConditions(51)) });
    assert.equal(bad.code, 'TOO_MANY_CONDITIONS');
  });
  it('rejects a level illegal for the rule type', () => {
    const bad = validateRuleWritePayload({ type: 'no-oversell', level: 'db_instance' });
    assert.equal(bad.code, 'INVALID_LEVEL');
  });
  it('rejects a group_by illegal for the rule type', () => {
    const bad = validateRuleWritePayload({ type: 'no-oversell', level: 'hypervisor', group_by: 'each_database' });
    assert.equal(bad.code, 'INVALID_GROUP_BY');
  });
  it('accepts a legal level + group_by for the type', () => {
    assert.equal(validateRuleWritePayload({ type: 'keep-apart', level: 'db_instance', group_by: 'each_primary_cluster' }), null);
  });
  it('skips the level check when type is absent (partial PUT)', () => {
    assert.equal(validateRuleWritePayload({ level: 'anything' }), null);
  });
  it('rejects an unknown rule type under strictType (M1 — no silent skip)', () => {
    const bad = validateRuleWritePayload({ type: 'made-up-type', level: 'vm' }, { strictType: true });
    assert.equal(bad.code, 'INVALID_TYPE');
  });
  it('does NOT reject an unknown type without strictType (import path keeps the R5 broken-window)', () => {
    assert.equal(validateRuleWritePayload({ type: 'anti-colocation', level: 'vm' }), null);
  });
});

describe('validateGlobalRuleWritePayload (pure)', () => {
  it('rejects a global row that sets overrides_rule_id', () => {
    const bad = validateGlobalRuleWritePayload({ type: 'keep-apart', overrides_rule_id: 'g1' });
    assert.equal(bad.code, 'INVALID_GLOBAL_RULE');
  });
  it('rejects a global row that references a custom group', () => {
    const bad = validateGlobalRuleWritePayload({ type: 'keep-apart', custom_group_id: 'cg1' });
    assert.equal(bad.code, 'INVALID_GLOBAL_RULE');
  });
  it('accepts a plain global template row', () => {
    assert.equal(validateGlobalRuleWritePayload({ type: 'keep-apart', name: 'x' }), null);
  });
});

let server; let baseUrl;
before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { req.user = { id: 'u-admin', role: 'admin' }; next(); });
  app.use('/capacity', router);
  server = http.createServer(app);
  await new Promise((r) => server.listen(0, r));
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});
after(() => server && server.close());
beforeEach(() => {});

function post(path, body) {
  return new Promise((resolve, reject) => {
    const payload = JSON.stringify(body);
    const r = http.request(
      `${baseUrl}${path}`,
      { method: 'POST', headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) } },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          let json = null;
          try { json = JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch { /* noop */ }
          resolve({ status: res.statusCode, json });
        });
      },
    );
    r.on('error', reject);
    r.write(payload); r.end();
  });
}

describe('rule-write guard (integration, 400 before DB)', () => {
  it('scenario rules mount rejects > 50 conditions', async () => {
    const res = await post('/capacity/scenarios/scn-1/rules', {
      type: 'spread-across-sites', name: 'x', level: 'db_instance', group_by: 'each_database',
      severity: 'hard', enabled: true, filters: manyConditions(51), params: { min_sites: 2 },
    });
    assert.equal(res.status, 400);
    assert.equal(res.json.error.code, 'TOO_MANY_CONDITIONS');
  });
  it('config template rules mount rejects an oversized params blob', async () => {
    const res = await post('/capacity/config/rules', {
      type: 'keep-apart', name: 'x', level: 'db_instance', severity: 'soft', enabled: true, params: { blob: 'y'.repeat(9000) },
    });
    assert.equal(res.status, 400);
    assert.equal(res.json.error.code, 'PAYLOAD_TOO_LARGE');
  });
  it('scenario rules mount rejects an illegal level for the type', async () => {
    const res = await post('/capacity/scenarios/scn-1/rules', {
      type: 'no-oversell', name: 'x', level: 'db_instance', severity: 'hard', enabled: true,
    });
    assert.equal(res.status, 400);
    assert.equal(res.json.error.code, 'INVALID_LEVEL');
  });
  it('config template rules mount rejects an illegal level for the type', async () => {
    // A level the COLUMN accepts but the TYPE does not, so the per-type rule is
    // the one that speaks. (`'site'` used to sit here and is not a member of
    // the level ENUM at all — that is now refused one step earlier, by the
    // column's own declared domain, and is asserted just below so both
    // refusals stay distinguishable.)
    const res = await post('/capacity/config/rules', {
      type: 'max-instances-per-vm', name: 'x', level: 'db_instance', severity: 'soft', enabled: true,
    });
    assert.equal(res.status, 400);
    assert.equal(res.json.error.code, 'INVALID_LEVEL');
  });
  it('config template rules mount rejects a level the column cannot store', async () => {
    // Not a member of the level ENUM. Before the config mounts carried the
    // column's declared domain this reached the INSERT and came back as a
    // driver error — a 500 with a stack logged per request — for every value
    // the per-type map happened not to name.
    const res = await post('/capacity/config/rules', {
      type: 'max-instances-per-vm', name: 'x', level: 'site', severity: 'soft', enabled: true,
    });
    assert.equal(res.status, 400);
    assert.match(res.json.error.message, /level must be one of/);
  });
  it('scenario rules mount rejects an unknown rule type (M1)', async () => {
    const res = await post('/capacity/scenarios/scn-1/rules', {
      type: 'made-up-type', name: 'x', level: 'vm', severity: 'soft', enabled: true,
    });
    assert.equal(res.status, 400);
    assert.equal(res.json.error.code, 'INVALID_TYPE');
  });
  it('config rules mount rejects a global row that sets overrides_rule_id (H1)', async () => {
    const res = await post('/capacity/config/rules', {
      type: 'keep-apart', name: 'x', level: 'db_instance', group_by: 'each_primary_cluster',
      severity: 'soft', enabled: true, overrides_rule_id: 'g-rule',
    });
    assert.equal(res.status, 400);
    assert.equal(res.json.error.code, 'INVALID_GLOBAL_RULE');
  });
  it('config rules mount rejects a global row that references a custom group (H1)', async () => {
    const res = await post('/capacity/config/rules', {
      type: 'keep-apart', name: 'x', level: 'db_instance', group_by: 'custom_group',
      severity: 'soft', enabled: true, custom_group_id: 'cg-1',
    });
    assert.equal(res.status, 400);
    assert.equal(res.json.error.code, 'INVALID_GLOBAL_RULE');
  });
});
