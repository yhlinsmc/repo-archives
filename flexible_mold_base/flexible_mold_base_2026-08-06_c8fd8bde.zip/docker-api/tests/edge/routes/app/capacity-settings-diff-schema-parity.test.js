'use strict';

/**
 * capacity-settings-diff-schema-parity.test.js — the two column lists that
 * decide "is this imported settings row merely the global singleton?" are the
 * table's own editable columns, checked against `table-ddls.js` rather than
 * against each other.
 *
 * WHY A PARITY TEST AND NOT A ROUTE TEST. The list that was wrong said it
 * "mirrors cap_settings' editable columns" and omitted one of them, and no
 * behavioural test could see that: the diff compared eight columns, agreed with
 * itself about all eight, and dropped a genuine scenario override whose only
 * difference was the ninth. The claim being made is about a COLUMN SET, so the
 * assertion is against the schema.
 *
 * A mocked route test is worse than useless here for the same reason: the
 * fixture would carry whichever columns the list already names.
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');

const dbKey = require.resolve('../../../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: { ro: {}, rw: {} }, t: (n) => `fmb_${n}` },
};

const { CONFIG_MOUNTS } = require('../../../../src/edge/routes/app/capacity/_shared');
const ioRouter = require('../../../../src/edge/routes/app/capacity/io');
const { buildSchemaManifest } = require('../../../../src/edge/lib/schema-manifest');
const { TABLES } = require('../../../../src/shared/constants');

// Columns the server owns rather than the operator: identity, scope and the
// audit timestamps. Everything else on this table is a value a scenario can
// legitimately override, and therefore a value the diff has to look at.
const SERVER_MANAGED = new Set(['id', 'scenario_id', 'created_at', 'updated_at']);

// What the scenario `settings` sheet declares, read off the sheet spec the
// importer builds its rows from — the same reading `allowedColumnsOf` does, so
// this cannot be a second opinion about which columns the sheet carries.
function sheetDeclaredColumns() {
  const spec = ioRouter.SHEET_SPECS.find((s) => s.key === 'settings');
  assert.ok(spec, 'the settings sheet spec is gone');
  return [
    ...(spec.strings || []), ...(spec.numbers || []), ...(spec.integers || []),
    ...(spec.booleans || []), ...(spec.jsonCols || []), ...Object.keys(spec.enums || {}),
  ];
}

describe('the settings diff compares every column an operator can set', () => {
  const declared = buildSchemaManifest((base) => base).get(TABLES.CAP_SETTINGS);

  it('table-ddls.js still describes cap_settings', () => {
    // The premise. Without it, every set below is empty and every assertion
    // passes for the wrong reason.
    assert.ok(declared, 'cap_settings is no longer in the DDL');
    assert.ok(declared.columns.length > 4, 'cap_settings has no value columns at all');
  });

  it('the mount writes exactly the columns the DDL leaves to the operator', () => {
    const operatorColumns = declared.columns.filter((c) => !SERVER_MANAGED.has(c)).sort();
    assert.deepEqual(
      [...CONFIG_MOUNTS.settings.cols].sort(), operatorColumns,
      'the settings mount and the table disagree about which columns an operator sets',
    );
  });

  it('the import diff reads that set NARROWED to what its own sheet carries', () => {
    // A diff may only compare a column the import path can populate. The
    // scenario `settings` sheet deliberately does not carry
    // `standby_sga_default_gb` — it is a GLOBAL operator setting, and the front
    // end marks it config-only because emitting it on a scenario sheet would
    // make a re-import here fail UNKNOWN_COLUMN. Comparing it anyway put an
    // always-`undefined` operand against an always-numeric one, so the value
    // path answered "not the global row" for every settings row ever imported.
    const sheetColumns = new Set(sheetDeclaredColumns());
    assert.deepEqual(
      [...ioRouter.SETTINGS_VALUE_COLS].sort(),
      [...CONFIG_MOUNTS.settings.cols].filter((c) => sheetColumns.has(c)).sort(),
      'the scenario import compares a set of settings columns its own sheet cannot fill',
    );
  });

  it('and the narrowing is a real exclusion, not an empty one', () => {
    // Without this, the assertion above passes just as well if the sheet ever
    // grows every column and the two sets coincide again — which is exactly the
    // shape that let the previous list agree with itself.
    const excluded = [...CONFIG_MOUNTS.settings.cols]
      .filter((c) => !ioRouter.SETTINGS_VALUE_COLS.includes(c));
    assert.deepEqual(
      excluded, ['standby_sga_default_gb'],
      'the set of settings columns a scenario sheet cannot carry has changed; the FE `configOnly` '
      + 'marking in xlsx-io.ts is the other half of this contract and must move with it',
    );
  });

  it('and treats the DDL\'s JSON columns as JSON', () => {
    // The diff compares a JSON column as canonical text because the driver
    // hands it back as an object or as a string depending on how it was
    // written; comparing it by value reports an edit where nothing moved.
    assert.deepEqual(
      [...ioRouter.SETTINGS_JSON_COLS].sort(),
      [...CONFIG_MOUNTS.settings.json].sort(),
    );
  });
});
