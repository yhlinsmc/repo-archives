// docker-api/tests/edge/routes/app/flow-recipe-runs-serializer.test.js
const { test } = require('node:test');
const assert = require('node:assert');
const { serializeWrite, maskDeep, keySegments, MAX_RUN_INPUT_SNAPSHOT_BYTES } = require('../../../../src/edge/routes/app/flow-recipe-runs/serializer');
const { parseInputSnapshot } = require('../../../../src/edge/lib/flow-run-input-snapshot');

test('maskDeep redacts secret-keyed leaves at any depth', () => {
  const out = maskDeep({ id: 1, token: 'abc', nested: { api_key: 'k', label: 'ok' }, list: [{ password: 'p' }] });
  assert.strictEqual(out.id, 1);
  assert.strictEqual(out.token, '****');
  assert.strictEqual(out.nested.api_key, '****');
  assert.strictEqual(out.nested.label, 'ok');
  assert.strictEqual(out.list[0].password, '****');
});

test('serializeWrite masks step_results object', async () => {
  const out = await serializeWrite({ actor_id: 'u1', step_results: [{ name: 's1', response: { authorization: 'Bearer x', flow_id: 9 } }] });
  assert.strictEqual(out.step_results[0].response.authorization, '****');
  assert.strictEqual(out.step_results[0].response.flow_id, 9);
});

test('serializeWrite masks JSON rendered_payload', async () => {
  const json = await serializeWrite({ rendered_payload: JSON.stringify({ name: 'wf', secret: 's' }) });
  assert.deepStrictEqual(JSON.parse(json.rendered_payload), { name: 'wf', secret: '****' });
});

test('serializeWrite masks YAML rendered_payload (secret not stored verbatim in the audit row)', async () => {
  const out = await serializeWrite({ rendered_payload: 'name: wf\nsecret: s\n' });
  const parsed = require('yaml').parse(out.rendered_payload);
  assert.strictEqual(parsed.name, 'wf');
  assert.strictEqual(parsed.secret, '****');
});

test('serializeWrite leaves an opaque (non-JSON, non-YAML-mapping) rendered_payload verbatim', async () => {
  const out = await serializeWrite({ rendered_payload: 'just a plain string' });
  assert.strictEqual(out.rendered_payload, 'just a plain string');
});

test('serializeWrite redacts secret inside JSON-encoded string body in step_results', async () => {
  const out = await serializeWrite({
    actor_id: 'u1',
    step_results: [{ name: 'step1', response: { body: '{"access_token":"sk-1","ok":true}' } }],
  });
  const parsedBody = JSON.parse(out.step_results[0].response.body);
  assert.strictEqual(parsedBody.access_token, '****');
  assert.strictEqual(parsedBody.ok, true);
});

test('serializeWrite masks JSON output_snapshot but leaves non-JSON as-is', async () => {
  const json = await serializeWrite({ output_snapshot: JSON.stringify({ field: 'value', api_key: 'sk-x' }) });
  assert.deepStrictEqual(JSON.parse(json.output_snapshot), { field: 'value', api_key: '****' });
  const plain = await serializeWrite({ output_snapshot: 'plain-text-snapshot' });
  assert.strictEqual(plain.output_snapshot, 'plain-text-snapshot');
});

test('maskDeep fail-closed: over-depth subtree returns mask sentinel not raw secret', () => {
  // Build an object nested MAX_DEPTH+2 levels deep with a secret at the bottom.
  // The subtree beyond depth 64 must come back as '****', not the raw value.
  let inner = { access_token: 'leak' };
  for (let i = 0; i < 66; i++) inner = { child: inner };
  const result = maskDeep(inner);
  // Walk down until we hit '****' — it must occur before we see the raw secret.
  let node = result;
  let sawMask = false;
  for (let i = 0; i < 70; i++) {
    if (node === '****') { sawMask = true; break; }
    if (typeof node !== 'object' || node === null) break;
    node = node.child;
  }
  assert.ok(sawMask, 'expected mask sentinel at depth cap, but walked past without hitting it');
});

test('maskDeep drops prototype-pollution keys at every level (defense-in-depth, mirrors deepJsonExpand)', () => {
  // Built via JSON.parse so __proto__/constructor/prototype are OWN enumerable
  // keys — exactly how a crafted upstream response body / error_summary arrives.
  const malicious = JSON.parse(
    '{"__proto__":{"polluted":"yes"},"constructor":{"c":1},"prototype":{"p":1},"safe":"ok","token":"sk"}',
  );
  const out = maskDeep(malicious);
  // __proto__ key must be dropped, not fed to out[k] (which would swap out's prototype).
  assert.strictEqual(out.polluted, undefined, '__proto__ must be dropped, not applied to the result prototype');
  assert.strictEqual(Object.prototype.hasOwnProperty.call(out, 'constructor'), false);
  assert.strictEqual(Object.prototype.hasOwnProperty.call(out, 'prototype'), false);
  // Global prototype must stay clean.
  assert.strictEqual({}.polluted, undefined, 'Object.prototype must not be polluted');
  // Non-dangerous keys still pass through; secrets still masked.
  assert.strictEqual(out.safe, 'ok');
  assert.strictEqual(out.token, '****');
});

test('maskDeep drops prototype-pollution keys inside a JSON-encoded string leaf', () => {
  // The step-body / error_summary path: a JSON-encoded string re-parsed by maskDeep.
  // Include constructor/prototype (not just __proto__): a bare __proto__ swaps the
  // object's [[Prototype]] and never survives the re-JSON.stringify, so it does not
  // discriminate on this path; constructor/prototype are plain own keys that DO
  // survive without the guard — they make this a genuine RED for the string leaf.
  const out = maskDeep({ body: '{"__proto__":{"polluted":"yes"},"constructor":{"c":1},"prototype":{"p":1},"api_key":"sk","ok":true}' });
  const parsed = JSON.parse(out.body);
  assert.strictEqual(parsed.polluted, undefined);
  assert.strictEqual(Object.prototype.hasOwnProperty.call(parsed, '__proto__'), false);
  assert.strictEqual(Object.prototype.hasOwnProperty.call(parsed, 'constructor'), false);
  assert.strictEqual(Object.prototype.hasOwnProperty.call(parsed, 'prototype'), false);
  assert.strictEqual({}.polluted, undefined, 'Object.prototype must not be polluted');
  assert.strictEqual(parsed.api_key, '****');
  assert.strictEqual(parsed.ok, true);
});

test('serializeWrite stamps actor_id from the authenticated user on create (admin path included)', async () => {
  // Admin POSTs without actor_id (generic write-scope stamp skips admins) — the
  // serializer must stamp it, otherwise the NOT NULL actor_id column rejects the insert.
  const out = await serializeWrite({ recipe_id: 'r1', status: 'partial' }, { isUpdate: false, req: { user: { id: 'admin-1' } } });
  assert.strictEqual(out.actor_id, 'admin-1');
});

test('serializeWrite does not stamp actor_id on update', async () => {
  const out = await serializeWrite({ status: 'success' }, { isUpdate: true, req: { user: { id: 'admin-1' } } });
  assert.strictEqual('actor_id' in out, false);
});

test('serializeWrite without ctx leaves actor_id untouched (back-compat)', async () => {
  const out = await serializeWrite({ actor_id: 'preset', status: 'partial' });
  assert.strictEqual(out.actor_id, 'preset');
});

// ── secret-key matching is by whole key SEGMENT, not by substring ────────────

test('a key whose ordinary English happens to contain a secret word is NOT masked', () => {
  // The exact list the review executed against the previous unanchored pattern,
  // which replaced six of these eight with the mask. `input_snapshot` is keyed by
  // blueprint field_key, authored by domain users, so these are the vocabulary —
  // and the loss was silent and permanent.
  const domainKeys = [
    'passenger_count', 'bypass_valve', 'pass_rate', 'passive_cooling',
    'tokenizer_mode', 'credentialing_body', 'total_passes', 'site_name',
    // The boundary the widening below is NOT allowed to cross. `passcode` and
    // `passkey` are masked as one segment, but split across a separator they
    // name a physical pass in this same vocabulary, so the pair rule
    // deliberately stops short of them.
    'boarding_pass_code', 'gate_pass_key', 'boarding_pass_count',
    // `pass` is the English word when another word FOLLOWS it: that word is the
    // head noun and it says what the value is — a rate, a count, a code — and
    // none of those is a password.
    'pass_rate', 'pass_count', 'first_pass_yield', 'total_pass_count',
    // The plural stays stored: a map of credentials is named after the term
    // (`api_keys`, `tokens`, `passwords`) and `passwords` is already masked, so
    // masking `passes` would buy nothing and cost an everyday English plural.
    'passes', 'boarding_passes', 'weld_passes',
  ];
  const out = maskDeep(Object.fromEntries(domainKeys.map((k) => [k, 'kept'])));
  for (const k of domainKeys) {
    assert.strictEqual(out[k], 'kept', `${k} must survive masking`);
  }
});

test('the secret-key spellings this codebase uses are all still masked', () => {
  const secretKeys = [
    'password', 'passwd', 'pass', 'secret', 'clientSecret', 'secret_key',
    'token', 'tokens', 'access_token', 'auth_token',
    'authorization', 'Authorization', 'bearer',
    'credential', 'credentials',
    'api_key', 'API_KEY', 'apiKey', 'api-key', 'apikey', 'APIKey', 'X-Api-Key', 'XApiKey',
    'private_key', 'privateKey', 'privatekey',
  ];
  const out = maskDeep(Object.fromEntries(secretKeys.map((k) => [k, 'sk-live-1'])));
  for (const k of secretKeys) {
    assert.strictEqual(out[k], '****', `${k} must still be masked`);
  }
});

// The whole-segment rule is a TIGHTENING, and a tightening's own failure mode is
// a genuine secret the loose pattern caught and the tight one drops. These two
// tests are the families that were dropped and are now caught again; each is a
// family rather than the examples that exposed it, because closing the named
// examples and not the family is how the matcher regressed the first time.

test('every spelling of the pass-prefixed credential vocabulary is masked', () => {
  // Masked by the old substring pattern via a bare `pass`, then silently stored
  // once matching became segment-based. A passphrase is the standard key name
  // for an SSH / PEM / PKCS#12 key's own secret — exactly what a domain author
  // would name a blueprint field `key_passphrase`.
  const keys = [
    'passphrase', 'passphrases', 'pass_phrase', 'pass-phrase', 'passPhrase',
    'PassPhrase', 'pass phrase', 'pass_phrases', 'key_passphrase', 'pem_passphrase',
    'sshPassphrase', 'SSHPassphrase', 'ssh_pass_phrase', 'keyPassphrase',
    'PEM_PASS_PHRASE', 'passphrase2', 'pass_phrase2',
    'passcode', 'passcodes', 'passkey', 'passkeys',
  ];
  const out = maskDeep(Object.fromEntries(keys.map((k) => [k, 'sk-live-1'])));
  for (const k of keys) assert.strictEqual(out[k], '****', `${k} must be masked`);
});

test('a counted credential is masked whether or not a separator precedes the digit', () => {
  // `keySegments` glued a trailing digit to its word, so `password2` segmented
  // as one unknown word and was stored while `password_2` was masked — an
  // outcome nobody authored, turning on punctuation. Paired live/backup
  // credential naming is a live pattern in this project.
  const keys = [
    'password2', 'password_2', 'token2', 'token_2', 'secret2', 'db_password1',
    'api_key2', 'apiKey2', 'apikey2', 'private_key2', 'passcode2',
    // ...and the mirror boundary, digit-then-letter.
    'v2token', 'v2_token', 's3_secret', 'x2_password', 'token2fa',
  ];
  const out = maskDeep(Object.fromEntries(keys.map((k) => [k, 'sk-live-1'])));
  for (const k of keys) assert.strictEqual(out[k], '****', `${k} must be masked`);
});

test('an unmodified `pass` is masked, whatever precedes it and however it is spelled', () => {
  // The fourth defect in this matcher's history. `pass` was a credential only as
  // the WHOLE key, so every `<something>_pass` — the standard abbreviation for a
  // password, and an entirely ordinary key in an upstream response body or an
  // outbound payload, neither of which this project names — was stored verbatim
  // on a durable, admin-readable row. The old substring pattern masked all of
  // these; this file's own "what it gives up" test did not name them, and the
  // generated corpus could not see them, because nothing in it ever put a word
  // NEXT TO a term.
  //
  // `unheard_of_pass` is here deliberately: the rule is positional, not a list
  // of the prefixes someone thought of, and a prefix list would pass every other
  // entry here and fail that one.
  const keys = [
    'pass', 'PASS', 'db_pass', 'user_pass', 'smtp_pass', 'sftp_pass', 'ftp_pass',
    'admin_pass', 'root_pass', 'mysql_pass', 'svc_pass', 'unheard_of_pass',
    'DB_PASS', 'db-pass', 'db.pass', 'db pass', 'dbPass', 'DbPass', 'myPass',
    // A counted credential is the same credential: a digit is not the word that
    // would make `pass` ordinary. This is the same rule the counted-credential
    // test below applies to `password2` / `token2`, and applying it to `pass`
    // REVERSES an earlier round, which stored `pass2` as "the second pass".
    'pass2', 'pass_2', '2_pass', 'db_pass2', 'db_pass_2', 'dbPass2',
  ];
  const out = maskDeep(Object.fromEntries(keys.map((k) => [k, 'sk-live-1'])));
  for (const k of keys) assert.strictEqual(out[k], '****', `${k} must be masked`);
});

test('what the unmodified-`pass` rule costs is listed here, not discovered later', () => {
  // The other direction, and the one no differential against the old pattern can
  // show: the old pattern masked these too, so they never appear in the corpus
  // residual. A `pass` with no word after it is read as a password even when it
  // names a physical pass or a machining pass. That is the deliberate price of
  // not having a hand-written list of credential prefixes, and it is pinned here
  // so that changing the rule has to come and change the sentence too.
  //
  // WHY THIS IS THE RIGHT WAY TO FAIL, and not a claim that the cost is zero:
  // by shape alone `db_pass` and `boarding_pass` are the same key, and a matcher
  // that reads names cannot separate them. Not masking loses a credential into a
  // durable row, permanently and invisibly; masking loses a domain value to
  // `****`, which is on the screen for someone to notice and report. The
  // `_count` / `_code` / `_key` / `_rate` forms of the same words survive — see
  // the domain-vocabulary test above — because there the following word is the
  // head of the compound. That is NOT a claim that a credential is never named
  // with something after `pass`: `db_pass_backup` is one and is stored. The
  // test below pins that half.
  //
  // These are invented names chosen to be ordinary, not names taken from
  // anywhere: what a key is called at runtime is authored by whoever uses the
  // system, so no snapshot of that could justify a rule meant to hold for names
  // nobody has written yet.
  const masked = [
    'boarding_pass', 'gate_pass', 'first_pass', 'second_pass', 'day_pass',
    // …and the counted spellings, which read as "the second pass" as readily as
    // "the second password".
    'pass2', '2_pass',
  ];
  const out = maskDeep(Object.fromEntries(masked.map((k) => [k, 'kept'])));
  for (const k of masked) {
    assert.strictEqual(out[k], '****',
      `${k} is documented as masked — if that changed, update the CHANGELOG and the module header`);
  }
});

test('a credential QUALIFIED after `pass` is documented as stored — the other half of that trade', () => {
  // The half that was missing. The cost test above pins the ordinary words this
  // rule started masking; nothing pinned the credentials it stops masking, so
  // the trade could move on one side only — which is how family 3's stated
  // reason came to cover a subclass it was false for.
  //
  // `pass` followed by a QUALIFIER rather than a head noun is still a password:
  // `db_pass_backup` is not "a pass that is a backup". It is stored anyway,
  // because nothing in the shape separates it from `pass_rate`, and the only two
  // fixes are a hand-written qualifier list — the completeness claim this module
  // refuses, having been broken by one twice — or masking on any following word,
  // which re-breaks `pass_rate` and reverses the retightening.
  const stored = [
    'db_pass_old', 'db_pass_new', 'db_pass_backup', 'smtp_pass_new',
    'db_pass_hash', 'db_pass_prod', 'db_pass_v2',
  ];
  const out = maskDeep(Object.fromEntries(stored.map((k) => [k, 'sk-live-1'])));
  for (const k of stored) {
    assert.strictEqual(out[k], 'sk-live-1',
      `${k} is documented as STORED — if that changed, update the CHANGELOG and the module header`);
  }
  // And the boundary this leaves behind, asserted so it is impossible to read
  // the loss as wider than it is: the same key spelled with the full word is
  // masked, so what is given up belongs to the abbreviation.
  const stillMasked = ['password_backup', 'db_password_old', 'db_passwd_backup'];
  const out2 = maskDeep(Object.fromEntries(stillMasked.map((k) => [k, 'sk-live-1'])));
  for (const k of stillMasked) {
    assert.strictEqual(out2[k], '****',
      `${k} is masked by the full word — the outcome turns on 'pass' versus 'password'`);
  }
});

test('a two-segment credential term is masked in the plural too', () => {
  // The pair list was hand-written in the singular while the single-word list
  // carried both numbers, so `api_keys` — an ordinary name for a map of
  // credentials — was stored. Plurals are generated from the pair list now.
  const keys = ['api_keys', 'apiKeys', 'X-Api-Keys', 'private_keys', 'privateKeys'];
  const out = maskDeep(Object.fromEntries(keys.map((k) => [k, 'sk-live-1'])));
  for (const k of keys) assert.strictEqual(out[k], '****', `${k} must be masked`);
});

test('the widened matcher reaches the two sibling columns as well', async () => {
  // The three columns share one matcher, so a spelling restored for
  // `input_snapshot` must be restored for the columns that carry upstream
  // response bodies too — that is where a vended credential actually echoes.
  const out = await serializeWrite({
    output_snapshot: JSON.stringify({ key_passphrase: 'sk-live-1', pass_rate: '0.98' }),
    step_results: { one: { body: { api_keys: { primary: 'sk-live-1' }, password2: 'sk-live-1' } } },
  });
  const snap = JSON.parse(out.output_snapshot);
  assert.strictEqual(snap.key_passphrase, '****');
  assert.strictEqual(snap.pass_rate, '0.98');
  assert.strictEqual(out.step_results.one.body.api_keys, '****');
  assert.strictEqual(out.step_results.one.body.password2, '****');
});

test('what whole-segment matching gives up is listed here, not discovered later', () => {
  // The CHANGELOG entry and the module header both state what this matcher
  // costs. The first draft of that text claimed it cost nothing — it said the
  // tightening kept "every genuine credential name it caught before", which was
  // false when it was written. Prose cannot be checked; this can. A later change
  // that starts catching these must come here and change the sentence too, and
  // nothing may claim the list is empty while it is not.
  const givenUp = ['mypassword', 'secretsmanager', 'apikeyv2'];
  const out = maskDeep(Object.fromEntries(givenUp.map((k) => [k, 'sk-live-1'])));
  for (const k of givenUp) {
    assert.strictEqual(out[k], 'sk-live-1',
      `${k} is documented as stored, not masked — if that changed, update the CHANGELOG and the module header`);
  }
});

test('segment splitting handles separators, camel case, acronym runs and digits', () => {
  assert.deepStrictEqual(keySegments('api_key'), ['api', 'key']);
  assert.deepStrictEqual(keySegments('apiKey'), ['api', 'key']);
  assert.deepStrictEqual(keySegments('XApiKey'), ['x', 'api', 'key']);
  assert.deepStrictEqual(keySegments('X-Api-Key'), ['x', 'api', 'key']);
  assert.deepStrictEqual(keySegments('total_passes'), ['total', 'passes']);
  assert.deepStrictEqual(keySegments('password2'), ['password', '2']);
  assert.deepStrictEqual(keySegments('v2token'), ['v', '2', 'token']);
});

// ── input_snapshot: a declared shape, then masking, then a size bound ────────

// Identity values are `blueprint_fields.id` / `hierarchy_nodes.id` — CHAR(36),
// UUID-defaulted — and the write boundary checks the shape, because that half of
// the document is stored unmasked. A readable stand-in that is still a UUID.
const id = (n) => `${String(n).padStart(8, '0')}-0000-4000-8000-000000000000`;
const FIELD_ID = { site_name: id(1), api_key: id(2), db_password1: id(3), total_kw: id(4), access_token: id(5) };
const BLUEPRINT_ID = id(90);

const snapshotDocObject = (over = {}) => ({
  entered: { site_name: 'north' },
  computed: {},
  fields: { site_name: FIELD_ID.site_name },
  blueprint_id: BLUEPRINT_ID,
  variant_id: null,
  ...over,
});
const snapshotDoc = (over = {}) => JSON.stringify(snapshotDocObject(over));

test('serializeWrite masks a secret-named field inside input_snapshot', async () => {
  const out = await serializeWrite({
    input_snapshot: snapshotDoc({
      entered: { site_name: 'north', api_key: 'sk-live-1' },
      computed: { total_kw: '4200' },
      fields: { site_name: FIELD_ID.site_name, api_key: FIELD_ID.api_key, total_kw: FIELD_ID.total_kw },
    }),
  });
  const parsed = JSON.parse(out.input_snapshot);
  assert.strictEqual(parsed.entered.site_name, 'north');
  assert.strictEqual(parsed.entered.api_key, '****');
  assert.strictEqual(parsed.computed.total_kw, '4200');
});

test('masking redacts the value maps and leaves the identity map alone', async () => {
  // The check that was missing. Masking ran over the whole document, so for a
  // field named `api_key` the stable field id became '****' — destroying, for
  // precisely the fields most worth auditing, the mechanism that distinguishes
  // "the same field, renamed" from "a different field wearing the old key".
  // Two reviews read that change without noticing, because every assertion
  // looked at `entered` and none looked at `fields`.
  const doc = snapshotDocObject({
    entered: { site_name: 'north', api_key: 'sk-live-1', db_password1: 'sk-live-2' },
    computed: { total_kw: '4200', access_token: 'sk-live-3' },
    fields: {
      site_name: FIELD_ID.site_name,
      api_key: FIELD_ID.api_key,
      db_password1: FIELD_ID.db_password1,
      total_kw: FIELD_ID.total_kw,
      access_token: FIELD_ID.access_token,
    },
  });
  const out = await serializeWrite({ input_snapshot: JSON.stringify(doc) });
  const stored = JSON.parse(out.input_snapshot);

  // Values: masked wherever the name says secret.
  assert.strictEqual(stored.entered.api_key, '****');
  assert.strictEqual(stored.entered.db_password1, '****');
  assert.strictEqual(stored.computed.access_token, '****');
  assert.strictEqual(stored.entered.site_name, 'north');
  assert.strictEqual(stored.computed.total_kw, '4200');

  // Identity: untouched, byte for byte, INCLUDING the secret-named keys. A field
  // id names a row, never its contents.
  assert.deepStrictEqual(stored.fields, doc.fields);
  assert.strictEqual(stored.blueprint_id, BLUEPRINT_ID);
  assert.strictEqual(stored.variant_id, null);
  // …and the document still carries exactly its five declared keys.
  assert.deepStrictEqual(Object.keys(stored),
    ['entered', 'computed', 'fields', 'blueprint_id', 'variant_id']);
});

test('the identity half may hold nothing but identifiers, which is what makes leaving it unmasked safe', async () => {
  // The hole the exemption above opened. `fields` was validated as "a map of
  // strings", so a caller could park a credential in it under an innocuous name
  // and this branch would deliberately store it unmasked, in a durable,
  // admin-readable row, from a create route open to any authenticated user. The
  // fix is not to start masking it again — that re-breaks the field ids — but to
  // bound the half to what it claims to hold.
  await assert.rejects(
    () => serializeWrite({ input_snapshot: snapshotDoc({ fields: { note: 'sk-live-SECRET' } }) }),
    (e) => {
      // A DISTINCT CODE from the document-shape refusals. The value is refused
      // either way and nothing unmasked reaches the column either way; the code
      // is what lets the dispatch path degrade instead of failing the run, since
      // the id shape is a convention every writer happens to keep rather than an
      // invariant anything enforces. The direct create route, which this call
      // is, still refuses — the snapshot is the whole request there, so there is
      // no dispatch to save.
      assert.strictEqual(e.code, 'INVALID_RUN_INPUT_SNAPSHOT_IDENTITY');
      assert.strictEqual(e.status, 400);
      assert.match(e.message, /the field reference for fields\.note must be an identifier/);
      // The refusal reaches an operator verbatim and is logged. It names the
      // entry, never the value it refused, or the refusal is its own leak.
      assert.doesNotMatch(e.message, /sk-live-SECRET/);
      return true;
    },
  );
  // A number is refused by the same check — the old one would have refused this
  // and accepted the string above, which is the wrong way round.
  await assert.rejects(
    () => serializeWrite({ input_snapshot: snapshotDoc({ fields: { site_name: 7 } }) }),
    (e) => { assert.strictEqual(e.code, 'INVALID_RUN_INPUT_SNAPSHOT_IDENTITY'); return true; },
  );
  // …but a `fields` that is not a map at all is a malformed DOCUMENT, not an
  // unrecognised id, and keeps the undegradable code. The two must not collapse
  // into one: the degrade path is justified by the id shape being a convention,
  // and that argument says nothing about a document of the wrong shape.
  await assert.rejects(
    () => serializeWrite({ input_snapshot: snapshotDoc({ fields: 'not a map' }) }),
    (e) => { assert.strictEqual(e.code, 'INVALID_RUN_INPUT_SNAPSHOT'); return true; },
  );
});

test('the two scope ids are identifiers or nothing, for the same reason', async () => {
  // blueprint_id and variant_id travel unmasked beside `fields`, so 'any string'
  // left two more unmasked slots on the same row. Null still means "no
  // blueprint / no variant was selected" and is untouched.
  for (const over of [{ blueprint_id: 'sk-live-SECRET' }, { variant_id: 'sk-live-SECRET' }]) {
    await assert.rejects(
      () => serializeWrite({ input_snapshot: snapshotDoc(over) }),
      (e) => {
        // Same distinct code as the `fields` half — one identity rule, one
        // degrade decision, so the dispatch path cannot treat the two halves
        // differently by accident.
        assert.strictEqual(e.code, 'INVALID_RUN_INPUT_SNAPSHOT_IDENTITY');
        assert.match(e.message, /must be an identifier or empty/);
        assert.doesNotMatch(e.message, /sk-live-SECRET/);
        return true;
      },
    );
  }
  const out = await serializeWrite({ input_snapshot: snapshotDoc({ blueprint_id: null, variant_id: null }) });
  const stored = JSON.parse(out.input_snapshot);
  assert.strictEqual(stored.blueprint_id, null);
  assert.strictEqual(stored.variant_id, null);
});

// CHANGED BEHAVIOUR: this column used to store an unparseable value verbatim,
// exactly as its two siblings still do. It refuses now — the masking guarantee
// held only for the one shape a cooperative client sends, and the create route
// it also serves is open to any authenticated user.
test('serializeWrite refuses a non-JSON input_snapshot instead of storing it verbatim', async () => {
  await assert.rejects(
    () => serializeWrite({ input_snapshot: 'api_key=sk-live-1, site=north' }),
    (err) => {
      assert.strictEqual(err.code, 'INVALID_RUN_INPUT_SNAPSHOT');
      assert.strictEqual(err.status, 400);
      return true;
    },
  );
});

test('serializeWrite refuses an input_snapshot sent as an object, which would skip masking entirely', async () => {
  // The reviewer's live exploit: nothing downstream stringifies this column, so
  // a plain object was serialised by the driver on the wire with the secret
  // intact and the size bound never run.
  await assert.rejects(
    () => serializeWrite({ input_snapshot: { entered: { api_key: 'sk-live-SECRET' }, computed: {} } }),
    (err) => {
      assert.strictEqual(err.code, 'INVALID_RUN_INPUT_SNAPSHOT');
      assert.strictEqual(err.status, 400);
      return true;
    },
  );
});

test('serializeWrite refuses a document missing a declared key, or carrying an undeclared one', async () => {
  const missing = JSON.stringify({ entered: {}, computed: {} });
  await assert.rejects(() => serializeWrite({ input_snapshot: missing }), (e) => {
    assert.strictEqual(e.code, 'INVALID_RUN_INPUT_SNAPSHOT');
    assert.match(e.message, /incomplete, missing: fields, blueprint_id, variant_id/);
    return true;
  });
  await assert.rejects(
    () => serializeWrite({ input_snapshot: snapshotDoc({ surprise: 1 }) }),
    (e) => {
      assert.strictEqual(e.code, 'INVALID_RUN_INPUT_SNAPSHOT');
      assert.match(e.message, /unrecognised entries: surprise/);
      return true;
    },
  );
});

test('serializeWrite refuses a half whose values are not strings', async () => {
  await assert.rejects(
    () => serializeWrite({ input_snapshot: snapshotDoc({ entered: { n: 12 } }) }),
    (e) => { assert.strictEqual(e.code, 'INVALID_RUN_INPUT_SNAPSHOT'); return true; },
  );
});

test('serializeWrite accepts a stated non-capture, and only for a reason a client may state', async () => {
  const out = await serializeWrite({ input_snapshot: JSON.stringify({ not_captured: 'outputs_stale' }) });
  assert.deepStrictEqual(JSON.parse(out.input_snapshot), { not_captured: 'outputs_stale' });

  // 'too_large' is the server's to write, never a client's to claim.
  await assert.rejects(
    () => serializeWrite({ input_snapshot: JSON.stringify({ not_captured: 'too_large' }) }),
    (e) => { assert.strictEqual(e.code, 'INVALID_RUN_INPUT_SNAPSHOT'); return true; },
  );
  // …and it may not be smuggled alongside a capture.
  await assert.rejects(
    () => serializeWrite({ input_snapshot: snapshotDoc({ not_captured: 'outputs_stale' }) }),
    (e) => { assert.strictEqual(e.code, 'INVALID_RUN_INPUT_SNAPSHOT'); return true; },
  );
});

test('serializeWrite refuses an oversized input_snapshot rather than truncating it', async () => {
  const oversized = snapshotDoc({
    entered: { notes: 'x'.repeat(MAX_RUN_INPUT_SNAPSHOT_BYTES + 1) },
  });
  await assert.rejects(
    () => serializeWrite({ input_snapshot: oversized }),
    (err) => {
      assert.strictEqual(err.code, 'RUN_INPUT_SNAPSHOT_TOO_LARGE');
      assert.strictEqual(err.status, 413);
      // The operator is told a size, not a schema: no column name in the text.
      assert.match(err.message, /the entered values are \d+ bytes; the limit is \d+ bytes/);
      assert.doesNotMatch(err.message, /input_snapshot/);
      // The numbers ride on the error so a caller that degrades instead of
      // refusing can restate them without parsing the sentence.
      assert.strictEqual(typeof err.bytes, 'number');
      assert.strictEqual(err.limit, MAX_RUN_INPUT_SNAPSHOT_BYTES);
      return true;
    },
  );
});

test('the size bound is applied to the masked bytes, not the bytes that arrived', async () => {
  // Built to exceed the limit BEFORE masking and to sit under it after, so the
  // two measurements disagree and only the post-mask one lets this through.
  const secret = 'y'.repeat(MAX_RUN_INPUT_SNAPSHOT_BYTES);
  const doc = snapshotDoc({ entered: { site_name: 'north', access_token: secret } });
  const arrivedBytes = Buffer.byteLength(doc, 'utf8');
  assert.ok(arrivedBytes > MAX_RUN_INPUT_SNAPSHOT_BYTES,
    'fixture must arrive oversized, or this proves nothing');

  const out = await serializeWrite({ input_snapshot: doc });

  const storedBytes = Buffer.byteLength(out.input_snapshot, 'utf8');
  assert.ok(storedBytes <= MAX_RUN_INPUT_SNAPSHOT_BYTES, 'the stored document is within the bound');
  assert.ok(storedBytes < arrivedBytes, 'masking is what brought it under');
  assert.strictEqual(JSON.parse(out.input_snapshot).entered.access_token, '****');
});

test('a snapshot exactly at the limit is accepted (the bound is a maximum, not a margin)', async () => {
  // Grown to the byte, so an off-by-one in the comparison shows up here.
  const pad = MAX_RUN_INPUT_SNAPSHOT_BYTES - Buffer.byteLength(snapshotDoc({ entered: { n: '' } }), 'utf8');
  const doc = snapshotDoc({ entered: { n: 'z'.repeat(pad) } });
  assert.strictEqual(Buffer.byteLength(doc, 'utf8'), MAX_RUN_INPUT_SNAPSHOT_BYTES);
  const out = await serializeWrite({ input_snapshot: doc });
  assert.strictEqual(Buffer.byteLength(out.input_snapshot, 'utf8'), MAX_RUN_INPUT_SNAPSHOT_BYTES);
});

test('no refusal this module can produce names a database column', async () => {
  // A property over the whole family, not over the messages that exist today.
  // The size message was reworded to drop `input_snapshot` and the shape
  // refusals, written afterwards in the same batch, put it back — the run modal
  // renders these verbatim into a role="alert". Enumerating every input shape
  // that can be refused is what stops the next refusal reopening it again.
  const rejected = [
    42, null, ['a'], '', 'not json at all', '"a string"', '[]',
    JSON.stringify({ not_captured: 'outputs_stale', entered: {} }),
    JSON.stringify({ not_captured: 'too_large' }),
    JSON.stringify({ not_captured: 'invented_reason' }),
    JSON.stringify({ entered: {}, computed: {} }),
    JSON.stringify(snapshotDocObject({ surprise: 1 })),
    JSON.stringify(snapshotDocObject({ entered: 'not an object' })),
    JSON.stringify(snapshotDocObject({ entered: { n: 12 } })),
    JSON.stringify(snapshotDocObject({ entered: JSON.parse('{"__proto__":"x"}') })),
    JSON.stringify(snapshotDocObject({ blueprint_id: 7 })),
    // The identity-half branches, which are refusals like any other and reach
    // the same role="alert" — enumerated here so a reworded one cannot reopen
    // the column-name rule this test exists for.
    JSON.stringify(snapshotDocObject({ blueprint_id: 'bp1' })),
    JSON.stringify(snapshotDocObject({ variant_id: 'v1' })),
    JSON.stringify(snapshotDocObject({ fields: { site_name: 'f1' } })),
    JSON.stringify(snapshotDocObject({ fields: { site_name: 7 } })),
  ];
  const seen = new Set();
  for (const value of rejected) {
    let message = null;
    try { parseInputSnapshot(value); } catch (e) { message = e.message; }
    assert.notStrictEqual(message, null, `${JSON.stringify(value)} should have been refused`);
    assert.doesNotMatch(message, /input_snapshot/,
      `an operator sees this text; it must not name a column: "${message}"`);
    assert.match(message, /^the entered values could not be recorded: /,
      `every refusal leads with the same operator sentence: "${message}"`);
    seen.add(message.replace(/:.*$/, (m) => m.split(':').slice(0, 2).join(':')));
  }
  // Distinct wordings, not one message reached sixteen ways.
  assert.ok(seen.size >= 8, `expected the fixtures to reach most refusal branches, reached ${seen.size}`);
});

test('the two sibling snapshot columns keep their store-verbatim behaviour', async () => {
  // Only the new column is strict. Changing the siblings is a separate piece of
  // work, and this pins that this change did not quietly do it.
  const out = await serializeWrite({
    output_snapshot: 'plain-text-snapshot',
    rendered_payload: 'just a plain string',
  });
  assert.strictEqual(out.output_snapshot, 'plain-text-snapshot');
  assert.strictEqual(out.rendered_payload, 'just a plain string');
});
