/**
 * capacity-site-delete-one-source.test.js — the site delete's refusal has one
 * source, and nothing may be inserted in front of it.
 *
 * The sites delete used to declare its own `block` probes; the reference set is
 * now produced by one function whose return value IS the 409's payload. The
 * failure mode of two hand-kept lists is never a disagreement about a value but
 * a MISSING ENTRY on one side, so what is checked here is the shape — a
 * behaviour test can only show that two answers matched for the state it seeded.
 *
 * There is no site delete-impact preview endpoint any more. There was one, and
 * nothing called it: a site is deleted by staging its row out of the Sites grid
 * and saving, so the product has no per-site confirm step to hang a preview on,
 * and an endpoint no operator can reach is not an answer to "show them what
 * points at it". The refusal carries the same sweep, names included.
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

// _shared.js destructures { t } from ../../../db at load (never calls it at load
// time); stub the db module so the require is side-effect-free (no pool).
const dbKey = require.resolve('../../../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: {}, t: (n) => n },
};

const { CHILD_DELETE_BEHAVIOR } = require('../../../../src/edge/routes/app/capacity/_shared');
const {
  sweepSiteReferences, siteDeleteRefusalMessage, SITE_REFERENCE_GROUPS,
} = require('../../../../src/edge/routes/app/capacity/site-references');

const SHARED_SRC = fs.readFileSync(
  path.resolve(__dirname, '../../../../src/edge/routes/app/capacity/_shared.js'), 'utf8',
);

/** The generic child DELETE handler's body. */
const childDeleteBody = (() => {
  const marker = 'function makeChildDelete(table, behavior = {}) {';
  const start = SHARED_SRC.indexOf(marker);
  assert.notEqual(start, -1, 'makeChildDelete is gone or renamed');
  const end = SHARED_SRC.indexOf('\nfunction ', start + marker.length);
  return SHARED_SRC.slice(start, end === -1 ? SHARED_SRC.length : end);
})();

describe('the site delete refuses from ONE reference set', () => {
  it('the sites delete declares no reference probes of its own', () => {
    const behavior = CHILD_DELETE_BEHAVIOR.sites;
    assert.equal(behavior.block, undefined, 'a second declaration of what blocks a site delete');
    assert.equal(behavior.unplace, undefined, 'a second declaration of what a site delete clears');
    assert.equal(behavior.cascade, undefined);
    assert.deepEqual(Object.keys(behavior), ['sweep']);
  });

  it('the delete holds the very function the sweep module exports', () => {
    // Identity, not equality of behaviour: two functions that happen to agree
    // today are exactly the arrangement this replaced.
    assert.equal(CHILD_DELETE_BEHAVIOR.sites.sweep.run, sweepSiteReferences);
    assert.equal(CHILD_DELETE_BEHAVIOR.sites.sweep.refusalMessage, siteDeleteRefusalMessage);
    assert.equal(CHILD_DELETE_BEHAVIOR.sites.sweep.groups, SITE_REFERENCE_GROUPS);
  });

  it('the 409 carries that set rather than a summary of it', () => {
    // `details: { references: sweep.groups }` — the groups themselves, names
    // included. A count-only refusal is what left an operator unable to tell
    // WHICH hypervisor to move.
    assert.match(childDeleteBody, /details:\s*\{\s*references:\s*sweep\.groups\s*\}/);
  });

  it('there is no site delete-preview endpoint left to disagree with it', () => {
    const routeSrc = fs.readFileSync(
      path.resolve(__dirname, '../../../../src/edge/routes/app/capacity/delete-preview.js'), 'utf8',
    );
    assert.equal(routeSrc.includes('sites/:id/delete-preview'), false);
    assert.equal(routeSrc.includes('sweepSiteReferences'), false,
      'a second caller of the sweep is back, and nothing here checks what it does with the answer');
  });
});

// The sweep's one precondition, checked where it is easy to get wrong: it must
// be handed the spelling the ROW holds. The dc_refs probe is a byte comparison,
// so a respelled id silently finds nothing and a delete that should have been
// refused goes through. Measured once on a real database
// (capacity-site-delete-real-db.test.js); this stops it coming back.
describe('the sweep is handed a stored id, never a request path segment', () => {
  it('the delete passes the id its locking read returned', () => {
    assert.match(SHARED_SRC, /const storedId = row\[0\]\.id;/,
      'the child delete no longer captures the stored id from its locking read');
    const m = SHARED_SRC.match(/behavior\.sweep\.run\(([^)]*)\)/);
    assert.ok(m, 'the sweep is no longer run');
    const args = m[1].split(',');
    assert.equal(args.length, 3);
    assert.equal(args[2].trim(), 'storedId');
  });
});

// A plain read taken earlier in the transaction fixes the REPEATABLE READ
// snapshot the sweep then answers from, while the site row it holds stays
// locked — so the sweep could miss a reference committed in between. Today the
// sweep is the first read that is not a locking one, and that holds by ORDERING
// rather than by any rule, which is exactly what a later change takes away
// without noticing. The order is therefore pinned rather than commented.
//
// WHAT THIS IS NOT: proof that the sweep sees the latest committed state.
// It is a change-detector for the handler's read order. `sameStoredValue` on the
// editor branch can itself query, and the window this guards is strictly smaller
// than the one site-references.js already documents — a reference committed
// between the sweep and the DELETE, which no ordering can close. Both close
// together, and only when dc_refs becomes a declared reference on the write
// side; adding locks here would buy the smaller half at the price of a lock
// order that contradicts every other capacity mount.
describe('nothing reads before the sweep except under a lock', () => {
  const READS = /conn\.query\(|sameStoredValue\(|behavior\.sweep\.run\(|FOR UPDATE/g;

  it('the handler still takes the reads it took, in the order it took them', () => {
    const sequence = [...childDeleteBody.matchAll(READS)].map((m) => m[0]);
    assert.deepEqual(sequence.slice(0, 6), [
      'conn.query(', 'FOR UPDATE', // the owning scenario, locked
      'sameStoredValue(', // editor-only ownership comparison, and it can query
      'conn.query(', 'FOR UPDATE', // this row, locked
      'behavior.sweep.run(', // the first read that is not a locking one
    ], 'a read was added before the sweep, or the sweep moved');
  });
});

describe('the refusal message', () => {
  const sweepOf = (counts) => ({
    groups: SITE_REFERENCE_GROUPS.map((g) => ({
      kind: g.kind, disposition: g.disposition, label: g.label, count: counts[g.kind] || 0, names: [],
    })),
  });

  it('names only what actually blocks, singular and plural', () => {
    assert.equal(
      siteDeleteRefusalMessage(sweepOf({ hypervisor: 1 })),
      'Cannot delete this datacenter while it is still referenced by 1 hypervisor placed here',
    );
    assert.match(siteDeleteRefusalMessage(sweepOf({ database_dc_ref: 3 })), /3 databases restricted/);
  });

  it('does not mention a pinned VM, which does not block', () => {
    const message = siteDeleteRefusalMessage(sweepOf({ hypervisor: 1, vm: 4 }));
    assert.equal(/VM/.test(message), false, 'the refusal blames something it is not refusing for');
  });
});
