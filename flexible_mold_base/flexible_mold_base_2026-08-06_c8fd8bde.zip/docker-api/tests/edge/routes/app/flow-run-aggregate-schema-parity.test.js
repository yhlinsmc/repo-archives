// docker-api/tests/edge/routes/app/flow-run-aggregate-schema-parity.test.js
//
// Every column the run-history statements name, checked against the actual DDL
// WITHOUT a live database.
//
// The route tests stub the driver, so a statement naming a column that does not
// exist passes both runners and 500s against a real database — there is a
// shipped precedent where exactly that reached production. This test reads the
// STATEMENT TEXT the route builders emit, resolves each alias through the
// module's own declaration, and requires the column to exist in table-ddls.js.
// A reference written in any other shape (a bare column, an undeclared alias)
// fails here rather than passing by being unreadable.
const { describe, it, before } = require('node:test');
const assert = require('node:assert/strict');

const dbKey = require.resolve('../../../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: {}, t: (n) => n },
};

const { buildEngineTableDDLs, buildInfraTableDDLs } = require('../../../../src/table-ddls');
const {
  SQL_ALIASES, DERIVED_ALIASES, GROUP_DERIVED_FIELDS, GROUP_SORT_EXPRESSIONS,
  RUN_LIST_COLUMNS, RUN_DETAIL_COLUMNS,
  RUN_COMPARE_COLUMNS,
  buildGroupsSql, buildGroupCountSql, buildTemplateByIdSql,
  buildGroupRunsSql, buildGroupRunsCountSql, buildRunDetailSql, groupPredicate,
  buildRunsByIdSql, buildLatestGroupRunSql,
} = require('../../../../src/edge/routes/app/flow-recipe-runs/run-queries');
const { buildRunVisibility } = require('../../../../src/edge/routes/app/flow-recipe-runs/visibility');

const SQL_TYPES = /^`?([a-z_]+)`?\s+(?:CHAR|VARCHAR|INT|DOUBLE|TIMESTAMP|JSON|TEXT|LONGTEXT|ENUM|BOOLEAN|TINYINT|BIGINT|DATETIME|DECIMAL|FLOAT|BLOB)\b/i;
let columnsByTable;

before(() => {
  columnsByTable = new Map();
  const identity = (n) => n;
  for (const ddl of [...buildInfraTableDDLs(identity), ...buildEngineTableDDLs(identity)]) {
    const m = ddl.match(/CREATE TABLE IF NOT EXISTS `([^`]+)`/);
    if (!m) continue;
    const cols = new Set();
    for (const rawLine of ddl.split('\n')) {
      const line = rawLine.trim();
      if (!line || line.startsWith('--') || line.startsWith('/*')) continue;
      const cm = line.match(SQL_TYPES);
      if (cm) cols.add(cm[1]);
    }
    columnsByTable.set(m[1], cols);
  }
});

const VIEWER = { id: '11111111-1111-1111-1111-111111111111', role: 'user' };
const ADMIN = { id: '22222222-2222-2222-2222-222222222222', role: 'admin' };
const TEMPLATE = '33333333-3333-3333-3333-333333333333';

/** Every statement these routes can emit, including each degraded variant — a
 *  fallback tier nobody checks is a statement that only fails on the database
 *  that needs it. */
function everyStatement() {
  const named = groupPredicate(TEMPLATE);
  const nameless = groupPredicate(null);
  const statements = [];
  for (const user of [VIEWER, ADMIN]) {
    const vis = buildRunVisibility(user, 'r').sql;
    statements.push(
      ['group count', buildGroupCountSql(vis)],
      ['run detail (full)', buildRunDetailSql(vis, { withAdditive: true })],
      ['run detail (legacy)', buildRunDetailSql(vis, { withAdditive: false })],
    );
    // Every order the first level can be asked for: an ordering names a column
    // too, and one that names a column that does not exist fails only when
    // somebody picks that heading.
    for (const field of Object.keys(GROUP_SORT_EXPRESSIONS)) {
      for (const dir of ['asc', 'desc']) {
        statements.push([`groups by ${field} ${dir}`, buildGroupsSql(vis, { field, dir })]);
      }
    }
    for (const group of [named, nameless]) {
      statements.push(
        ['group runs (full)', buildGroupRunsSql(vis, group.sql, { withSnapshot: true })],
        ['group runs (legacy)', buildGroupRunsSql(vis, group.sql, { withSnapshot: false })],
        ['group runs count', buildGroupRunsCountSql(vis, group.sql)],
        ['latest group run (full)', buildLatestGroupRunSql(vis, group.sql, { withSnapshot: true })],
        ['latest group run (legacy)', buildLatestGroupRunSql(vis, group.sql, { withSnapshot: false })],
      );
    }
    // Every selection size the comparison accepts: the statement's shape depends
    // on how many ids arrive, so one size checked is one shape checked.
    for (const count of [2, 3, 4]) {
      statements.push(
        [`runs by id x${count} (full)`, buildRunsByIdSql(vis, count, { withSnapshot: true })],
        [`runs by id x${count} (legacy)`, buildRunsByIdSql(vis, count, { withSnapshot: false })],
      );
    }
  }
  statements.push(['template by id', buildTemplateByIdSql()]);
  return statements;
}

describe('flow run history schema parity', () => {
  it('parses a column set for every table these statements read', () => {
    for (const table of Object.values(SQL_ALIASES)) {
      const cols = columnsByTable.get(String(table));
      assert.ok(cols && cols.size > 0, `no columns parsed for ${table}`);
    }
  });

  it('every column reference resolves to a real column', () => {
    for (const [label, sql] of everyStatement()) {
      const refs = [...sql.matchAll(/(\w+)\.`(\w+)`/g)];
      assert.ok(refs.length > 0, `${label}: no column references found — the shape this test reads changed`);
      for (const [, alias, column] of refs) {
        if (DERIVED_ALIASES.includes(alias)) {
          assert.ok(
            GROUP_DERIVED_FIELDS.includes(column),
            `${label}: ${alias}.${column} is not a field the derived table exposes`,
          );
          continue;
        }
        const table = SQL_ALIASES[alias];
        assert.ok(table, `${label}: alias '${alias}' is not declared in SQL_ALIASES`);
        assert.ok(
          columnsByTable.get(String(table)).has(column),
          `${label}: ${table} has no column '${column}'`,
        );
      }
    }
  });

  it('every declared column list exists on the runs table', () => {
    const cols = columnsByTable.get('flow_recipe_runs');
    for (const c of [...RUN_LIST_COLUMNS, ...RUN_DETAIL_COLUMNS, ...RUN_COMPARE_COLUMNS]) {
      assert.ok(cols.has(c), `flow_recipe_runs has no column '${c}'`);
    }
  });

  it('the two additive columns the fallback tiers drop are real columns', () => {
    const cols = columnsByTable.get('flow_recipe_runs');
    for (const c of ['input_snapshot', 'code_version']) {
      assert.ok(cols.has(c), `flow_recipe_runs has no column '${c}'`);
    }
  });

  it('the ownership check reads the hierarchy columns it names', () => {
    const cols = columnsByTable.get('hierarchy_nodes');
    for (const c of ['id', 'owner_id', 'node_type']) {
      assert.ok(cols.has(c), `hierarchy_nodes has no column '${c}'`);
    }
  });

  it('the actor name enrichment reads the users columns it names', () => {
    const cols = columnsByTable.get('users');
    for (const c of ['id', 'display_name', 'kc_username']) {
      assert.ok(cols.has(c), `users has no column '${c}'`);
    }
  });

  it('every order the first level offers names a real column', () => {
    // The expressions are interpolated, so a name that does not exist is a
    // statement nobody sees fail until an operator clicks that heading.
    for (const expression of Object.values(GROUP_SORT_EXPRESSIONS)) {
      for (const [, alias, column] of expression.matchAll(/(\w+)\.`(\w+)`/g)) {
        const table = DERIVED_ALIASES.includes(alias) ? null : SQL_ALIASES[alias];
        if (table === null) {
          assert.ok(
            GROUP_DERIVED_FIELDS.includes(column),
            `sort expression ${expression} names ${column}, which the derived table does not expose`,
          );
        } else {
          assert.ok(table, `sort expression ${expression} uses undeclared alias '${alias}'`);
          assert.ok(
            columnsByTable.get(String(table)).has(column),
            `sort expression ${expression}: ${table} has no column '${column}'`,
          );
        }
      }
    }
  });

  it('the grouped statement selects exactly the fields it declares', () => {
    const sql = buildGroupsSql('', null);
    for (const field of GROUP_DERIVED_FIELDS) {
      assert.ok(
        sql.includes(`AS ${field}`),
        `the derived table declares '${field}' but the statement does not produce it`,
      );
    }
  });
});
