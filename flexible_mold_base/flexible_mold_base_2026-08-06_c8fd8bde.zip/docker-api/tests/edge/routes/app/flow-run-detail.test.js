// docker-api/tests/edge/routes/app/flow-run-detail.test.js
//
// One run in full: what it carries, what it deliberately does not, and the
// visibility rule it reads under — which has to be the SAME rule the list it was
// opened from used, or a run visible in the list would 404 when opened.
const { test } = require('node:test');
const assert = require('node:assert');
const express = require('express');

let issued = [];
let responder = () => [];

require.cache[require.resolve('../../../../src/edge/db')] = {
  exports: {
    pool: {
      ro: {
        getConnection: async () => ({
          query: async (sql, params) => {
            issued.push({ sql, params });
            const out = responder(sql, params);
            if (out instanceof Error) throw out;
            return out;
          },
          release: () => {},
        }),
      },
      rw: { getConnection: async () => ({ query: async () => [], release: () => {} }) },
    },
    t: (x) => x,
  },
};

const { router } = require('../../../../src/edge/routes/app/flow-recipe-runs/aggregate');

function app(user) {
  const a = express();
  a.use(express.json());
  a.use((req, _res, next) => { if (user) req.user = user; next(); });
  a.use('/', router);
  return a;
}

async function get(a, path) {
  const server = a.listen(0);
  try {
    const { port } = server.address();
    const res = await fetch(`http://127.0.0.1:${port}${path}`);
    const json = await res.json().catch(() => ({}));
    return { status: res.status, json };
  } finally {
    // Closed on the throwing path too. With the close reachable only where
    // nothing threw, a failed assertion leaks this handle, the runner never
    // exits, and the job reports a timeout instead of the assertion that failed.
    server.close();
  }
}

const ADMIN = { id: 'aaaaaaaa-0000-0000-0000-000000000001', role: 'admin' };
const PLAIN = { id: 'bbbbbbbb-0000-0000-0000-000000000002', role: 'user' };
const RUN = 'cccccccc-0000-0000-0000-000000000003';

function detailRow(over) {
  return {
    id: RUN,
    recipe_id: 'dddddddd-0000-0000-0000-000000000004',
    recipe_name: 'Submit build',
    template_id: 'eeeeeeee-0000-0000-0000-000000000005',
    blueprint_id: 'ffffffff-0000-0000-0000-000000000006',
    actor_id: PLAIN.id,
    mode: 'create',
    code_version: 3,
    status: 'success',
    result_link: 'https://example.invalid/run/1',
    external_flow_id: 'X-1',
    error_summary: null,
    started_at: '2026-07-20 09:30:00',
    finished_at: '2026-07-20 09:30:12',
    created_at: '2026-07-20 09:30:00',
    rendered_payload: '{"size":"10"}',
    output_snapshot: '{"text":"out"}',
    step_results: null,
    input_snapshot: JSON.stringify({
      entered: { size: '10' }, computed: {}, fields: {}, blueprint_id: null, variant_id: null,
    }),
    ...over,
  };
}

function stub({ rows = [], users = [], failAdditive = false } = {}) {
  return (sql) => {
    if (sql.includes('SELECT id, display_name, kc_username')) return users;
    if (sql.includes('input_snapshot')) {
      if (failAdditive) {
        const e = new Error("Unknown column 'input_snapshot'");
        e.errno = 1054;
        return e;
      }
      return rows;
    }
    if (sql.includes('FROM `flow_recipe_runs`')) {
      return rows.map((row) => {
        const copy = { ...row };
        delete copy.input_snapshot;
        delete copy.code_version;
        return copy;
      });
    }
    return [];
  };
}

test.beforeEach(() => { issued = []; responder = stub(); });

test('a run carries its execution detail, its payload and its outputs', async () => {
  responder = stub({
    rows: [detailRow()],
    users: [{ id: PLAIN.id, display_name: 'Ada', kc_username: 'ada' }],
  });
  const { status, json } = await get(app(ADMIN), `/runs/${RUN}`);
  assert.strictEqual(status, 200);
  assert.strictEqual(json.data.recipe_name, 'Submit build');
  assert.strictEqual(json.data.mode, 'create');
  assert.strictEqual(json.data.code_version, 3);
  assert.strictEqual(json.data.actor_name, 'Ada');
  assert.strictEqual(json.data.rendered_payload, '{"size":"10"}');
  assert.strictEqual(json.data.output_snapshot, '{"text":"out"}');
  // Timestamps arrive pinned to UTC, not in the driver's spelling.
  assert.strictEqual(json.data.started_at, '2026-07-20T09:30:00Z');
});

test('the recorded answers are reported as a state, and never returned', async () => {
  responder = stub({ rows: [detailRow()] });
  const { json } = await get(app(ADMIN), `/runs/${RUN}`);
  assert.strictEqual(json.data.input_capture, 'captured');
  assert.ok(!('input_snapshot' in json.data));
});

test('a run whose capture was dropped is not reported as one that recorded nothing', async () => {
  responder = stub({
    rows: [detailRow({ input_snapshot: JSON.stringify({ not_captured: 'too_large' }) })],
  });
  const { json } = await get(app(ADMIN), `/runs/${RUN}`);
  assert.strictEqual(json.data.input_capture, 'dropped');
});

test('a run recorded before the column existed reports nothing recorded', async () => {
  responder = stub({ rows: [detailRow({ input_snapshot: null })] });
  const { json } = await get(app(ADMIN), `/runs/${RUN}`);
  assert.strictEqual(json.data.input_capture, 'absent');
});

test('a database without the additive columns still serves the run', async () => {
  responder = stub({ rows: [detailRow()], failAdditive: true });
  const { status, json } = await get(app(ADMIN), `/runs/${RUN}`);
  assert.strictEqual(status, 200);
  assert.strictEqual(json.data.input_capture, 'absent');
  assert.strictEqual(json.data.id, RUN);
});

test('the read carries the same rule as the list it was opened from', async () => {
  // Which is now no restriction at all: the detail binds the run id and nothing
  // else. It matters that this is the SAME rule rather than the same outcome —
  // the detail is built through the shared predicate, so a narrowing reaches the
  // detail and the list together and the two cannot disagree about what exists.
  responder = stub({ rows: [detailRow()] });
  await get(app(PLAIN), `/runs/${RUN}`);
  const [{ sql, params }] = issued;
  assert.ok(!/r\.`actor_id` = \?/.test(sql));
  assert.ok(!/hierarchy_nodes/.test(sql));
  assert.deepStrictEqual(params, [RUN]);
});

test('an administrator reads it the same way — the role decides nothing here', async () => {
  responder = stub({ rows: [detailRow()] });
  await get(app(ADMIN), `/runs/${RUN}`);
  const [{ sql, params }] = issued;
  assert.ok(!sql.includes('actor_id` = ?'));
  assert.deepStrictEqual(params, [RUN]);
});

test('a run the caller may not read is absent, not refused', async () => {
  // "Not yours" over an id confirms the run exists.
  responder = stub({ rows: [] });
  const { status, json } = await get(app(PLAIN), `/runs/${RUN}`);
  assert.strictEqual(status, 404);
  assert.strictEqual(json.error.code, 'NOT_FOUND');
});

test('a segment that is not an identifier never reaches the database', async () => {
  const { status } = await get(app(ADMIN), '/runs/not-an-id');
  assert.strictEqual(status, 404);
  assert.strictEqual(issued.length, 0);
});

test('an unauthenticated caller is refused', async () => {
  const { status } = await get(app(null), `/runs/${RUN}`);
  assert.strictEqual(status, 401);
  assert.strictEqual(issued.length, 0);
});
