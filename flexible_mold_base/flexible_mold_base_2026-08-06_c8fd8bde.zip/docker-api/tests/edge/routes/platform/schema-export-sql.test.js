/**
 * schema-export-sql.test.js — fmb-1329 T5.
 *
 * Covers the DBA remediation SQL export: the pure statement renderer
 * (_buildExportSql) and the mounted endpoint (admin-only, text/plain). No live
 * DB — the db module is stubbed with a mock read pool.
 */
const { describe, it, before, after } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

// Mock read connection: answers the stamp read + the information_schema.COLUMNS
// dump. Returning an empty column set makes every manifest table "missing" so
// the export renders CREATE TABLE statements.
const mockConn = {
  query: async (sql) => {
    if (/system_settings/i.test(sql)) return [{ value: '"3.2.520"' }];
    if (/information_schema\.COLUMNS/i.test(sql)) return [];
    return [];
  },
  release() {},
};

// Mock write connection: records every INSERT so tests can assert on the
// export audit row without a live DB.
const auditInserts = [];
const mockAuditConn = {
  query: async (sql, params) => {
    if (/INSERT INTO .*feature_audit/i.test(sql)) {
      auditInserts.push({ sql, params });
    }
    return [];
  },
  release() {},
};

const dbKey = require.resolve('../../../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: {
    pool: {
      ro: { getConnection: async () => mockConn },
      rw: { getConnection: async () => mockAuditConn },
    },
    t: (n) => `mig_${n}`,
    PLATFORM_SCHEMA_VERSION: '3.2.520',
  },
};

const router = require('../../../../src/edge/routes/platform/schema-export-sql');
const { _buildExportSql } = router._internal;

describe('_buildExportSql (pure renderer)', () => {
  it('emits a header naming stamp / target / baseline and no USE statement', () => {
    const sql = _buildExportSql({ stamp: '3.2.400', missing_tables: [], missing_columns: [], tableFn: (n) => `mig_${n}` });
    assert.match(sql, /-- current stamp: 3\.2\.400/);
    assert.match(sql, /-- target:\s+3\.2\.520/);
    assert.match(sql, /-- baseline:\s+3\.2\.520/);
    assert.equal(/^\s*USE\s/im.test(sql), false, 'must not emit USE');
    assert.match(sql, /No missing tables or columns/);
  });

  it('renders CREATE TABLE for a missing table via the DDL builders (prefix only via tableFn)', () => {
    const tableFn = (n) => `zz_${n}`;
    const sql = _buildExportSql({ stamp: null, missing_tables: ['user_templates'], missing_columns: [], tableFn });
    assert.match(sql, /CREATE TABLE IF NOT EXISTS `zz_user_templates`/);
    // No hardcoded prefix leaked — the only table prefix present is the one the
    // caller's tableFn produced.
    assert.equal(/`fmb_user_templates`/.test(sql), false);
  });

  it('renders ALTER ... ADD COLUMN from the manifest fragment for a missing column', () => {
    const sql = _buildExportSql({
      stamp: '3.2.520',
      missing_tables: [],
      missing_columns: [{ table: 'user_templates', column: 'owner_id' }],
      tableFn: (n) => `mig_${n}`,
    });
    assert.match(sql, /ALTER TABLE `mig_user_templates` ADD COLUMN `?owner_id`?\s+CHAR\(36\)/i);
  });
});

describe('GET /edge/platform/schema-export-sql (mounted endpoint)', () => {
  let server;
  let base;
  let userRole = 'admin';

  before(async () => {
    const app = express();
    app.use((req, _res, next) => { req.user = userRole ? { id: 'u', role: userRole } : undefined; next(); });
    app.use('/', router);
    server = http.createServer(app);
    await new Promise((r) => server.listen(0, '127.0.0.1', r));
    base = `http://127.0.0.1:${server.address().port}`;
  });

  after(async () => { await new Promise((r) => server.close(r)); });

  it('admin GET returns 200 text/plain with the header + CREATE statements', async () => {
    userRole = 'admin';
    const res = await fetch(`${base}/`);
    assert.equal(res.status, 200);
    assert.match(res.headers.get('content-type') || '', /text\/plain/);
    const body = await res.text();
    assert.match(body, /-- target:\s+3\.2\.520/);
    assert.match(body, /CREATE TABLE IF NOT EXISTS/);
  });

  it('a successful export writes a schema_export.sql audit row (actor id, no schema content)', async () => {
    auditInserts.length = 0;
    userRole = 'admin';
    const res = await fetch(`${base}/`);
    assert.equal(res.status, 200);
    assert.equal(auditInserts.length, 1, 'exactly one audit row written for a successful export');
    const [{ sql, params }] = auditInserts;
    assert.match(sql, /'schema_export\.sql'/);
    const [, userId, metadataJson] = params;
    assert.equal(userId, 'u', 'audit row records the authed admin as actor');
    const metadata = JSON.parse(metadataJson);
    assert.deepEqual(
      Object.keys(metadata).sort(),
      ['missing_columns_count', 'missing_tables_count'],
      'audit metadata carries counts only — no table/column names, no SQL text',
    );
  });

  it('non-admin GET is rejected by the mounted auth middleware (403)', async () => {
    auditInserts.length = 0;
    userRole = 'user';
    const res = await fetch(`${base}/`);
    assert.equal(res.status, 403);
    assert.equal(auditInserts.length, 0, 'a rejected (403) request must not write an audit row');
  });
});

// ── Pending destructive/custom section (Codex R2 route-level gap) ─────────────
// The mounted describe above runs with stamp == target, so the pending derive
// is skipped and the pending section never rendered (reverting it broke zero
// route tests). This block mounts a FRESH router against a db mock whose target
// (3.2.579) is ahead of the stamp (3.2.520), with information_schema probes
// driving the real v3.2.579 batch, and asserts the section round-trips over
// HTTP — including the no-pending path.
describe('GET /edge/platform/schema-export-sql — pending destructive/custom section', () => {
  const { buildSchemaManifest } = require('../../../../src/edge/lib/schema-manifest');
  let server;
  let base2;
  // Full manifest dump keyed by the mock prefix → zero missing structure, so
  // the pending section is the sole remediation content under test.
  function fullDumpRows() {
    const manifest = buildSchemaManifest((b) => b);
    const rows = [];
    for (const [b, { columns }] of manifest) {
      for (const c of columns) rows.push({ TABLE_NAME: `mig_${b}`, COLUMN_NAME: c });
    }
    return rows;
  }
  const state = {
    dropColPresent: true, indexPresent: true, createdAtNullable: true,
    fieldKeyIndexPresent: true,
  };
  const roConn = {
    query: async (sql, params) => {
      if (/system_settings/i.test(sql)) return [{ value: '"3.2.520"' }];
      if (/TABLE_NAME, COLUMN_NAME, COLUMN_TYPE, IS_NULLABLE FROM information_schema\.COLUMNS/i.test(sql)) return fullDumpRows();
      if (/IS_NULLABLE FROM information_schema\.COLUMNS/i.test(sql)) return [{ IS_NULLABLE: state.createdAtNullable ? 'YES' : 'NO' }];
      if (/SELECT 1 FROM information_schema\.COLUMNS/i.test(sql)) return state.dropColPresent ? [{ 1: 1 }] : [];
      if (/information_schema\.TABLES/i.test(sql)) return [{ 1: 1 }];
      if (/information_schema\.STATISTICS/i.test(sql)) {
        // Two different index questions reach this probe, and answering them
        // as one is how a fixture starts lying: `indexPresent` is about the
        // companion index a drop-column step removes, and the unique field-key
        // index is about whether the schema HAS its key constraint. Keyed on
        // the bound index name so neither can flip the other.
        const indexName = Array.isArray(params) ? params[1] : undefined;
        if (indexName === 'uq_blueprint_field_key') {
          return state.fieldKeyIndexPresent ? [{ 1: 1 }] : [];
        }
        return state.indexPresent ? [{ 1: 1 }] : [];
      }
      if (/INSERT INTO .*feature_audit/i.test(sql)) return [];
      return [];
    },
    release() {},
  };

  before(async () => {
    const routeKey = require.resolve('../../../../src/edge/routes/platform/schema-export-sql');
    require.cache[dbKey] = {
      id: dbKey, filename: dbKey, loaded: true,
      exports: {
        pool: { ro: { getConnection: async () => roConn }, rw: { getConnection: async () => roConn } },
        t: (n) => `mig_${n}`,
        PLATFORM_SCHEMA_VERSION: '3.2.579',
      },
    };
    delete require.cache[routeKey];
    const freshRouter = require('../../../../src/edge/routes/platform/schema-export-sql');
    const app = express();
    app.use((req, _res, next) => { req.user = { id: 'admin-2', role: 'admin' }; next(); });
    app.use('/', freshRouter);
    server = http.createServer(app);
    await new Promise((r) => server.listen(0, '127.0.0.1', r));
    base2 = `http://127.0.0.1:${server.address().port}`;
  });

  after(async () => { await new Promise((r) => server.close(r)); });

  it('renders the pending section with DROP COLUMN + backfill SQL when steps are pending', async () => {
    Object.assign(state, {
      dropColPresent: true, indexPresent: true, createdAtNullable: true, fieldKeyIndexPresent: false,
    });
    const res = await fetch(`${base2}/`);
    assert.equal(res.status, 200);
    const body = await res.text();
    assert.match(body, /-- target:\s+3\.2\.579/);
    assert.match(body, /Pending migration steps \(destructive \/ custom/);
    assert.match(body, /ALTER TABLE `mig_api_connectors` DROP COLUMN `allowed_hosts`;/);
    assert.match(body, /ALTER TABLE `mig_user_templates` DROP INDEX `idx_user_templates_user_draft`;/);
    assert.match(body, /ALTER TABLE `mig_user_templates` DROP COLUMN `user_id`;/);
    assert.match(body, /SET `created_at` = NOW\(\) WHERE `created_at` IS NULL;/);
    assert.match(body, /MODIFY COLUMN `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP;/);
    // The unique field-key index has no structural kind the missing-structure
    // comparison can see, so its ALTER reaches a CRUD-only DBA only through
    // this section.
    assert.match(body, /ALTER TABLE `mig_blueprint_fields` ADD UNIQUE KEY `uq_blueprint_field_key` \(blueprint_id, field_key\);/);
    // DROP INDEX must precede DROP COLUMN for the composite-index drop.
    assert.ok(
      body.indexOf('DROP INDEX `idx_user_templates_user_draft`') <
        body.indexOf('DROP COLUMN `user_id`'),
      'DROP INDEX is emitted before DROP COLUMN',
    );
  });

  it('omits the pending section and renders the no-op message when nothing is pending', async () => {
    Object.assign(state, {
      dropColPresent: false, indexPresent: false, createdAtNullable: false, fieldKeyIndexPresent: true,
    });
    const res = await fetch(`${base2}/`);
    assert.equal(res.status, 200);
    const body = await res.text();
    assert.equal(/Pending migration steps/.test(body), false, 'no pending section when nothing is pending');
    assert.match(body, /No missing tables or columns/);
  });
});
