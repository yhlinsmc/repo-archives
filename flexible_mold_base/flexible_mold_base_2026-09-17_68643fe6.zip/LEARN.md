# LEARN.md — Technical Decisions and Best Practices

This active file keeps current, cited operating knowledge. Older entries are preserved in [docs/archive/LEARN_archive.md](docs/archive/LEARN_archive.md).

## Index

| Topic | Section |
|---|---|
| Logger caller file:line | §50 |
| Setup wizard pool-persistence gap + sanitised pool diagnostic | §79 |
| Local LLM agent handoff pattern | §51 |
| Setup wizard same-origin API base invariant | §52 |
| Setup auth-mode truth table | §53 |
| dist-source export policy | §54 |
| Push-as-trigger GitOps | §55 |
| Real-tag deploy pivot | §55.1 |
| export:source mode flag | §56 |
| Shared-infra verify layer | §57 |
| Client adoption checklist | §58 |
| Three-URL responsibility model | §59 |
| RW/RO pool namespace | §60 |
| Boot-banner and Ship Gate retrofit | §61 |
| Local-k3d vs internal-prod cluster | §62 |
| Schema-level privilege semantics | §63 |
| Pool lifecycle and strict prefix | §64 |
| TABLES registry and Step 8 lint | §65 |
| Lazy preflight at DDL | §67 |

## §50 Logger error+ caller file:line via pino hooks (v3.2.3)

The docker-api pino logger now injects a `src: "relative/path.js:line"`
field into every `level >= 50` (error + fatal) record so operators can
jump straight from an error log to the offending source line without
grepping stack traces.

### Why Error.captureStackTrace over pino-caller

`pino-caller` is a pre-built npm package that does the same thing, but
v3.2.3 ships zero new npm dependencies (AIRGAP constraint — Nexus
proxy is manually curated). Building the hook directly on
`Error.captureStackTrace(holder, captureSourceLocation)` is ~10×
cheaper than `new Error().stack` because V8 delays the symbolicator
work until the stack string is actually read, and trimming at the
target function means the resulting frame 0 is already the caller the
hook cares about.

### Dynamic frame search (no hardcoded index)

`parseSourceFromStack` walks the stack for the first frame whose path
contains `[docker-api/]src/` AND is not the logger module itself. The
`docker-api/` segment is OPTIONAL because the production Dockerfile
flattens `COPY docker-api/src ./src`, so the runtime stack trace in the
shipped image reports `/app/src/...` (no `docker-api/` segment).

```js
const tailMatch = filePath.match(/\/(?:docker-api\/)?src\/(.+)$/);
if (!tailMatch) continue;
const rel = tailMatch[1];
if (rel.startsWith('shared/lib/logger')) continue;
return `${rel}:${lineNum}`;
```

This survives uniformly:

- WSL dev paths: `/home/user/projects/flexible_mold_base/docker-api/src/...`
- Production image paths: `/app/src/...` (Dockerfile flattens the prefix)
- Dev image paths: `/app/docker-api/src/...` (alt unflattened layout)
- CI bind mounts: `/builds/.../docker-api/src/...`
- Arbitrarily nested `pino.child({module:'a'}).child({sub:'b'})` chains
- Async / await boundaries (V8 zero-cost async stacks keep the frame
  intact)

No frame index to break when pino re-wraps its proto.

### Phase 8 retrospective — the regex was wrong about production

The first Phase 3 revision hardcoded the regex as
`/\/docker-api\/src\/(.+)$/`. The v3.2.3 unit tests shipped under that
assumption and all 12 passed, including a "production Docker image
path" case that the author WROTE to match the author's assumption —
`/app/docker-api/src/shared/lib/logger.js` — rather than verifying
against a real image. The assumption was wrong: Dockerfile line 151
is `COPY docker-api/src ./src`, so inside the running container every
stack frame is `/app/src/...`. The `src` field silently stayed
`undefined` in production even though the unit tests were green.

Phase 8's dist-core docker boot caught the bug. The first run under
the phony-DB recipe produced log lines like:

```
[2026-04-11 00:29:42] ERROR: [db] auto-configure failed
```

with no `src` suffix. Expected shape was
`... auto-configure failed edge/db.js:518`. Grepping the same logs for
the intended `src:` key returned nothing. The regex got fixed to make
`docker-api/` optional, the unit test was updated to use the real
flat path, a defence-in-depth test for the unflattened layout was
added, the image was rebuilt, and the next run produced:

```
[2026-04-11 00:37:38] ERROR: [remote-client] API-edge request failed: Unexpected end of JSON input infra/lib/remote-client.js:207
```

**Lesson**: unit tests that mirror the author's mental model are not a
substitute for runtime verification of the thing they mirror. Anything
that depends on a path shape, a Dockerfile copy layout, a container
entrypoint, or an environment variable needs at least one actual boot
against the real image. This is the reason Phase 8 exists — every
future plan that touches runtime behaviour (logger, proxy, static
serve, build output) should carry an explicit "boot the real image"
step, not just "run the unit tests".

### DoS amplifier mitigation

Error-path stack capture is a classic log-storm amplifier: one
attacker request → one `logger.error` → one stack walk → pino-pretty
format → I/O pressure. v3.2.3 caps it with a simple per-second budget:

```js
const CAPTURE_WINDOW_MS = 1000;
const CAPTURE_BUDGET = parseInt(process.env.LOGGER_CAPTURE_BUDGET || '500', 10);
```

Over-budget calls return `undefined` with zero overhead (no
`Error.captureStackTrace` invocation). A single stderr throttle
warning per window alerts operators that an error storm is in
progress.

Why a uniform rate limit instead of downgrading hot-path `logger.error`
calls to `logger.warn`: the 105-site audit of existing
`logger.error` / `logger.fatal` calls surfaced no downgrade
candidates — every match in OIDC / S2S / access-check middleware is a
legitimate server error. Downgrading would hide real problems from
alerting. Rate-limiting protects every error path uniformly and
survives new `logger.error` sites added by future code without a
manual audit pass.

### Error message convention

When adding a new `logger.error` call, use the `verb + noun + identifier`
pattern:

```js
// GOOD — the operator can grep for the subject
logger.error({ err, userId }, `Failed to load user_template id=${userId}`);

// BAD — identifier-free, hard to correlate across a storm
logger.error({ err }, 'DB error');
```

Pair the message with bindings that give context: `err` for stack,
`path` for HTTP-layer calls, domain identifiers (`userId`, `templateId`,
`transformerId`) for business logic. The `src` field arrives
automatically via the hook.

### dev `messageFormat`

pino-pretty's `messageFormat` is set to
`[{module}] {msg}{if src} {src}{end}` so dev log tails show:

```
[export] mariadb-sql export error edge/routes/platform/export.js:141
```

Production JSON logs unchanged — `src` is always a top-level field in
the record, the dev formatter just inlines it into the readable line.

### Test strategy

Six `parseSourceFromStack` cases in
`docker-api/tests/unit/logger.test.js` exercise the parser as a pure
function against crafted stack strings (standard, WSL2, `/app`
production, empty, plain at-form, logger-frame skip). Three
integration cases wire a custom pino `Writable` stream to capture
emitted records and assert on the `src` field through nested
`pino.child()` chains, async boundaries, and the level gate (warn /
info skip the hook, error fires it). Two rate-limit cases prove the
budget enforcement.

Internals are exposed via a `_internals` named export for tests only:
`captureSourceLocation`, `parseSourceFromStack`, `checkCaptureBudget`,
`resetCaptureBudget`. Application code must never touch that export —
the hook fires automatically on every `logger.error` call.

## §51 — Local LLM Agent Handoff Pattern (2026-04-11, v3.4.0 plan)

Context: Office-hours session on 2026-04-11 produced a full design for a
local 24/7 AI testing co-pilot (Devstral 24B on RTX 5070 Ti) that hands
off work to Claude Code via a file-based task queue and SessionStart
hook. The plan itself is at `~/.claude/plans/shimmying-percolating-cat.md`
and the design doc is at
`~/.gstack/projects/yhlinsmc-flexible_mold_base/user-feat-v323-framework-hardening-design-20260411-004832.md`.
This section captures the *why* of the non-obvious technical choices so
future reviewers do not have to re-derive them.

### Why Devstral Small 2 24B over Qwen 2.5-Coder 14B

Qwen 2.5-Coder 14B is the safe, well-documented, first-party choice and
sits comfortably in VRAM even with `k3d` and `gitlab-ce` running. We
rejected it because the plan has to live for 12+ months and the project
grows toward integration testing, not away from it. The decision
followed a "technical debt" framing: pick the model whose ceiling
matches where the project will be in six months, not where it is today.

- **Prompt debt**: 14B needs more scaffolding and in-prompt examples to
  write good mocks. Devstral was trained for agent-style tool calling
  and issues cleaner, more consistent JSON/Python, so the prompts stay
  leaner. Migrating 14B prompts to a larger model later means rewriting
  templates.
- **Context debt**: 14B is usefully stretched to ~16K. Devstral's 256K
  native context (we will run 32K by default) means a task spec can
  point the agent at a whole submodule (`src/fmb/components/grid/` —
  four files) instead of one file at a time. Rewriting task splits when
  the model changes is more work than keeping Devstral's bigger window
  from day one.
- **Failure-rate debt**: SWE-bench Verified 68% (Devstral) vs ~50–65%
  Claude-equivalence (14B) on multi-file reasoning means roughly half
  as many `failed/` and `blocked/` tasks for the human to triage.
- **Operational debt trade-off**: Devstral's only downside is that it
  forces `gitlab-ce`, `k3d`, and `keycloak` to stop during agent
  windows. That is 45 lines of `pre-start.sh` / `post-stop.sh`. It is
  paid once. The prompt/context/failure debt from picking 14B would be
  paid on every template, every task, every triage — compounding
  forever.

### Why Qwen 3.5 and Qwen 3.5-Coder were rejected

The user specifically asked about this. Three reasons:

1. **No first-party Qwen 3.5-Coder exists as of April 2026.** Only a
   community port (`mdq100/qwen3.5-coder`) on Ollama; quality and
   future updates are not guaranteed.
2. **General models underperform specialized coder models at coding.**
   Qwen 3.5 27B is strong on SWE-bench Verified (72.4%) but in the
   practical "write Jest/Vitest with idiomatic mocks" domain, the
   5.5T-token code-tuned Qwen 2.5-Coder still wins. Writing code is
   not the same as solving SWE-bench benchmark items.
3. **Qwen 3.5 ships with always-on thinking mode.** A 5–10× inference
   slowdown is catastrophic for 24/7 throughput where the point is to
   burn idle hours writing many small tests, not to solve one hard
   problem.

When Qwen 3.5-Coder first-party ships, the migration is one line in
`fmb-agent-workspace/policy.yaml`: `model: qwen3.5-coder:14b-q4_K_M`.
No other code changes.

### Why Smolagents over a fully custom runner

The initial recommendation was a custom ~500-line Python runner for
maximum policy control. The user asked "how confident are you?" and
surfaced the honest answer: 70%. Rewriting stream parsing, tool-call
repair, OOM recovery, and model reload logic is exactly the kind of
work that frameworks do well and solo maintainers do badly.

Smolagents (HuggingFace, 26K+ stars) is a sweet spot because:

- It is **code-first** rather than JSON-tool-call-first. The model emits
  Python that calls tools directly. For small and local models this has
  been measured at ~30% higher task success than JSON tool calling.
- `@tool` decorators are a natural **policy injection point**. The
  first line of every tool can `raise PermissionError` if the path is
  not in the allowlist, the line count exceeds the commit cap, or the
  content contains `@ts-ignore`. There is no policy bypass path.
- Ollama support is first-class via `LiteLLMModel`.

The custom runner option remains the documented fallback if Devstral's
tool-call schema turns out to be incompatible with Smolagents in
practice — in that case the rebuild is ~500 lines but all the policy
knowledge transfers directly.

### Why a separate `fmb-agent-workspace` repo

The user proposed this in Q10 and it strictly dominates the in-tree
alternatives:

- The main `flexible_mold_base` repo stays business-only. No agent
  runner, no task templates, no historical reports bloating `git log`.
- The agent repo has independent history, so policy changes, template
  tuning, and pattern learning can evolve without noise in the business
  repo.
- Daily reports accumulate in the agent repo indefinitely (tracked,
  searchable), while the live `.tasks/` directory in the main repo
  stays ephemeral and gitignored.
- The agent stack can be forked per project. If Platform is later
  extracted for another Lovable project, that project gets its own
  `<project>-agent-workspace` with zero contamination.
- It is naturally publishable. The agent repo contains no business
  data, no organization names, no credentials — it can become an
  open-source template for "Claude Code + local LLM handoff" without
  any sanitization sweep.

The three discovery paths (this LEARN section, CLAUDE.md §12, the
`project_local_ai_agent.md` memory entry, and symlinks from
`flexible_mold_base/.tasks/` back to the agent repo) make the split
transparent to Claude Code even though the two repos are independent.

### Why handoff tokens are hard-capped at 500

The user's framing was "I should not burn my Claude Code context just
reading the report." That constraint shaped the whole SessionStart
hook design:

- The daily report markdown has two layers separated by a
  `<!-- END_L1 -->` marker. Everything before the marker is the TL;DR
  summary; everything after is full detail.
- The hook uses `awk '/<!-- END_L1 -->/{exit}'` to read only the
  summary and injects it as a `## 🤝 Local Agent Handoff` context
  block.
- Character count is bounded to 2000 (~500 tokens) and truncated with
  a pointer to the full file if the agent ever exceeds it.
- The `write_daily_report` tool on the agent side enforces the same
  limit before writing, so the agent cannot accidentally consume the
  budget.

The cost per Claude Code session is at most ~500 tokens for full
situation awareness, which is cheaper than reading a single source
file. The full detail is available on demand via `cat`.

### Why three layers of access control instead of one

A single layer (for example, only tool-level policy) would be
equivalent to trusting the model. A prompt-injected or
hallucination-driven model can violate policy if the only enforcement
is in code the model itself controls. The defence-in-depth answer is:

1. **Filesystem bind mount** — the kernel never even shows the agent
   container a file that is not in the allowlist. No matter what the
   model writes, it cannot read `.env*` or `~/.ssh`.
2. **Docker network ACL** — the agent can reach the five local
   services it needs and nothing else. No external exfiltration, no
   cross-container lateral movement, no docker socket access.
3. **Tool-level policy** — even inside the sandbox, every `@tool`
   checks the allowlist, commit caps, and banned patterns before
   doing anything. The model cannot bypass this because it only
   interacts with the filesystem through the tools.

Layer 1 is the kernel. Layer 2 is the network stack. Layer 3 is the
application. Each layer is designed assuming the layers above it have
already been breached. None of the layers trusts the model.

### Why schedule windows are explicit calendar time instead of idle-only

The user corrected my initial "22:00–07:00 + idle detection" proposal
with the exact pattern of their life: sleep 02:30–07:00 and work
weekdays 09:00–18:00 with the home PC idle. Idle-only detection would
either fire during morning email-checking (false positive) or miss the
09:00–18:00 work window entirely (Claude Code session still open
because the user never explicitly closes it). Explicit calendar
windows plus Claude SessionStart/Stop hooks plus a 5-minute
tool-use idle timer gives three redundant signals, so the agent is
off during morning routine and evening development but on during
sleep and office hours.

### Why v3.4.0 not v3.2.4

Implementation does not start until v3.2.3 framework hardening ships
(TypeScript strict, DTO mapper, schema audit). Starting mid-sprint
would introduce noise in the agent's diagnostic signals (failures
caused by unrelated type churn, not by the agent's own mistakes). The
plan was tracked at the time as v3.3.0 UNRELEASED (renumbered v3.4.0
by the 2026-09-04 patch-cap rule) so the version gate is unambiguous.

Renumbered 2026-09-04: the patch segment caps at 999, so v3.3.0 is the rollover after v3.2.999 and the planned feature line is v3.4.0.

### §51 Epilogue — /autoplan Pivot (2026-04-11)

Same office-hours session that produced the original plan was
followed by `/autoplan`, which ran three independent reviewers (CEO,
Eng, DX) against the plan file. All three converged on the same
verdict: **reject the plan as written, pivot to an 8-hour Aider-based
MVP (v0.1)**. The full custom Smolagents + supervisor + separate-repo
architecture is deferred to v1, contingent on v0.1 proving value.

This epilogue records what the reviews caught that I missed during the
19-question office-hours pass, because that gap is the most valuable
lesson of the whole exercise.

#### Critical miss #1: Smolagents `CodeAgent` security theater

The original Q7 decision picked Smolagents `CodeAgent` over Aider or a
custom runner specifically because of the **code-first tool calling**
property: the model generates Python that calls the registered `@tool`
functions, which was measured at ~30% higher task success than JSON
tool calling for small local models.

The /autoplan Eng review pointed out that **this is exactly why the
policy enforcement is fiction**. `CodeAgent` runs arbitrary
model-generated Python. The `@tool` decorators only matter if the
model chooses to call them. The model can trivially write:

```python
import os
os.rename(".env", ".env.bak")
open("src/auth/middleware.ts", "w").write("// pwned")
```

and the 30-rule policy at the `@tool` layer never fires because the
`@tool` functions are never called. The Smolagents `LocalPythonExecutor`
has a builtins allowlist but it is bypassable via `__import__`,
`getattr(__builtins__, 'open')`, and similar primitives.

**The fix is either:**
- Switch to Smolagents `ToolCallingAgent` (JSON tool calls, the
  original Q7 rejected option), losing the code-first efficiency
  advantage that was the entire rationale for picking Smolagents in
  the first place.
- Use `CodeAgent(executor_type="docker")` with a second nested
  container, adding operational complexity.

**Either way, the reason Q7 picked Smolagents is gone.** The premise
was not load-bearing the way I thought it was. This is the kind of
reasoning error that outside voices catch and insider reviews don't,
because I had internalized the "code-first = efficiency" frame during
Q7 and never revisited it from a security angle.

**Lesson**: when a tool is picked for a performance property, verify
that property does not conflict with the security property the tool
must also provide. Security and performance trade off constantly; the
Q7 rationale treated them as independent.

#### Critical miss #2: Aider dismissed on wrong technical claim

Q7 rejected Aider with "interactive vs batch mode impedance mismatch"
as the stated reason. This claim is factually wrong. Aider has shipped
`--yes-always`, `--message`, `--test-cmd`, `--auto-test`, `--no-stream`
for over a year. It runs in CI pipelines routinely. The single command:

```bash
aider --yes-always --model ollama/devstral:24b \
  --test-cmd "cd docker-api && node --test tests/unit/grid-range-ops.test.js" \
  --auto-test --message-file tasks/pending/t001.md \
  docker-api/tests/unit/grid-range-ops.test.js
```

does file edit + test run + auto-commit + retry-on-test-fail in one
line, with battle-tested Ollama integration, built-in tokenizer, diff
format auto-selection per model, and two years of production bug-fix
history.

**I dismissed Aider based on a vague recollection of its ergonomics,
not its actual documentation.** The /autoplan CEO and DX reviews both
called this out independently. The Eng review went further and wrote
out the concrete 40-line `run.sh` + 20-line `pre-commit` + 30-line
`handoff.sh` that replace the ~500-line Smolagents runner.

**Lesson**: when rejecting a mature tool, cite the specific feature
that does not work, not a vague category objection. If I had read the
Aider docs for 10 minutes during Q7 before recommending against it,
this entire pivot would have been unnecessary.

#### Critical miss #3: ROI math was never computed

The original plan budgeted 65–90 hours of build time. The value
calculation assumed the agent would write "many tests" over "many
nights". Neither number was ever quantified. The CEO review computed:

- Pre-work (spike + scaffolding): 12–16 h
- `fmb-agent-workspace` skeleton + 7 tools + policy: 20–30 h
- Supervisor + hooks + SessionStart integration: 8–12 h
- Pilot week active monitoring: 10–15 h
- Failed-task triage and policy tuning: ~14 h over 4 weeks
- **Total: 65–90 h of the user's own time**

Against the pilot target of 27 grid inline smoke tests, which Claude
Code can write directly in ~2 hours, the custom runner is **30×
overhead**. The breakeven point is the user writing **~200 tests**
through the runner. There is no evidence the user has sustained
200-test demand; the project has ~450 total existing tests accumulated
over the whole history.

**Lesson**: before committing a multi-week build, compute the
minimum-volume-to-break-even and compare it to observed historical
volume. If the ratio is > 2×, the project is a learning/sovereignty
investment, not an ROI investment. Frame it as such, cap the budget
explicitly, and do not pretend the math works.

#### The pivot (v0.1 Aider MVP)

The corrected approach, accepted 2026-04-11:

- **Single directory** `~/projects/fmb-agent/`, gitignored in main
  repo, no second git repo
- **Aider** as the runner, not Smolagents
- **8 policy rules** in a 20-line git pre-commit hook, not 30 rules
  in a custom `@tool` layer
- **40-line `run.sh`** shell loop, not a supervisor daemon
- **30-line `handoff.sh`** generating the L1 TL;DR, not a write-report
  tool with token enforcement
- **No Docker container isolation** — Aider on WSL2 host, git hook is
  the gate
- **8-hour build budget**, 40-hour total cap including pilot
- **v1 full Smolagents architecture deferred**, contingent on v0.1
  proving (a) Devstral writes useful tests, (b) sustained volume
  exists, (c) handoff delight moment works on first real use

This is a smaller experiment that can prove or disprove the entire
premise without locking in a month of custom code. If the premise
fails, the user loses 8 hours instead of 90. If it succeeds, the v1
refactor becomes additive, not foundational.

#### Meta-lesson: outside voices must run before ExitPlanMode

The user's own memory entry `feedback_outside_voice_catches_groupthink`
stated this rule. The office-hours session did not run /autoplan
before calling ExitPlanMode; the user had to ask "shall we also run
/autoplan?" which triggered the reviews. **The correct workflow is to
run /autoplan automatically at the end of any non-trivial plan**,
not as an optional extra. When the user has explicitly recorded a
preference for outside voices catching blind spots, every plan session
should treat /autoplan as a mandatory step before approval.

The office-hours skill lists /plan-ceo-review and /plan-eng-review as
"Next-skill recommendations" at the end. This framing is too soft. For
future sessions, I should make outside reviews a hard part of the
workflow, not a suggestion.

#### Artifacts

- Plan file with full `## GSTACK REVIEW REPORT` section:
  `~/.claude/plans/shimmying-percolating-cat.md`
- Design doc (original, pre-pivot):
  `~/.gstack/projects/yhlinsmc-flexible_mold_base/user-feat-v323-framework-hardening-design-20260411-004832.md`
- v0.1 recipe (pivot result):
  `~/.gstack/projects/yhlinsmc-flexible_mold_base/v0.1-aider-mvp-recipe-20260411.md`
- Memory: `project_local_ai_agent.md` in the gstack memory dir for
  this project, updated to reflect v0.1 status

## §52 Setup wizard apiBase = same-origin relative URL invariant (2026-04-13, v3.2.12)

The Setup wizard previously used `if (!apiBase) { setChecking(false); return; }`
as a guard before calling `GET /api/setup/status`. In single-container K8s
deployments `Env.API_BASE_URL === ''` is the **correct** value — it means
"fetch with a relative `/api/...` URL", which routes to the same origin
serving the bundle (nginx → infra → edge). The empty-string guard
mistreated this as "unconfigured" and left the wizard stuck at Step 2.

**Invariant (documented in `src/platform/lib/api-base.ts`)**: an empty
`base` is a valid same-origin relative URL. All callers write
`` `${base}/api/foo` ``, which becomes `/api/foo` (relative fetch)
when `base` is empty. A `!base` check is **wrong**; callers must check
profile source instead (`source === 'profile' | 'env' | 'relative'`).

**Shared util**: `resolveApiBase()` returns `{ base, isRelative, source }`.
Both `Setup.tsx` and `SetupStatus.tsx` (plus the new
`EnvironmentDiagnosticPanel`) import it; local `getApiBase(overrideUrl)`
helpers were deleted.

**Why this bit us**: dev in DevContainer always sets
`VITE_API_BASE_URL=https://localhost:3200`, so the empty case never
appeared in dev. Only K8s pods serving bundle + API from same host
triggered it — which is exactly where users hit Step 2 false-positives.

## §53 Step 5 "SSO Config" deletion — 8-case auth_mode truth table (2026-04-13, v3.2.12)

The old Setup wizard Step 5 asked the operator to type a Keycloak
issuer URL and test `/health`. This was dead code: `auth_mode` has
always been resolved by `detectAuthMode()` at edge boot from four
priorities (`AUTH_MODE_OVERRIDE` → `system_settings.auth_mode` →
`KEYCLOAK_ISSUER_BASE_URL` probe → `'local'`). The UI form did not
write any of those four; it just tested connectivity and the operator
clicked "Next". Nothing was persisted.

Before deleting the step, we enumerated the 8 permutations to prove
zero functional loss:

| # | Env var `KEYCLOAK_ISSUER_BASE_URL` | `system_settings.auth_mode` | DB state | Live Keycloak reachable | Resolved `auth_mode` | Step 5 input would change result? |
|---|---|---|---|---|---|---|
| 1 | unset | absent | fresh | — | `local` (P4 default) | no |
| 2 | unset | absent | existing | — | `local` (P4 default) | no |
| 3 | unset | `'local'` | existing | — | `local` (P2 DB) | no |
| 4 | unset | `'keycloak'` | existing | — | `keycloak` (P2 DB) | no |
| 5 | set | absent | fresh | reachable | `keycloak` (P3 probe, auto-seeded to DB) | no |
| 6 | set | absent | fresh | unreachable | `local` (P3 probe fail) | no |
| 7 | set | `'local'` | existing | reachable | `local` (P2 DB overrides env) | no |
| 8 | set | `'keycloak'` | existing | unreachable | `keycloak` cached, `isDegraded()=true` → `local` fallback at middleware | no |

Step 5's `/health` probe did **not** seed `system_settings.auth_mode`
and did **not** alter `KEYCLOAK_ISSUER_BASE_URL` (env is baked into
the pod spec). Deletion is lossless.

**Action path preserved for post-setup stuck-cache**: cases 6→8
transition (boot without Keycloak, Keycloak later reachable) was
previously a silent edge-bug — operator had to restart the edge pod.
v3.2.12 adds `POST /api/setup/re-probe-auth` (admin-only) +
`EnvironmentDiagnosticPanel` Section D Promote button to trigger
`detectAuthMode()` without a restart.

**Tombstone**: `keycloak_config` remains in
`docker-api/src/shared/lib/settings-crypto.js#SENSITIVE_KEYS` to
keep backward-decrypt compatibility for any deployment that wrote
the key pre-v3.2.12. No new writes land there. Cleanup migration is
out of scope (low value, migration risk exceeds the dead-row cost).

---

## §54 dist-source export policy — whitelist + auto-grep + YAML transforms (2026-04-14, v3.2.13a)

v3.2.13a landed four policy shifts for `npm run export:source` (previously
`export:core`; see commit `07ffe55` for the rename). Each shift replaces
an implicit / manual / fragile step with a structural / automated /
composable one.

### Shift 1 — Deny-by-default scripts whitelist (Q7/Q8/B3)

**Before**: `package.transform.cjs` enumerated a handful of scripts to
delete (`dev`, `export:core`). Everything else leaked through to the
dist-source `package.json`. Operators saw `lint`, `test`, `e2e`, etc. in
`npm run` output, even though those tools were not installed.

**After**: exact-match whitelist. Root dist-source keeps ONLY
`{build, schema:audit}`. docker-api keeps ONLY `{start}`. Any script
outside the list is deleted. The whitelist is pinned in **two** places:
`package.transform.cjs` writes it, `verify.sh` B3 asserts it with
`jq -r '.scripts | keys | sort | join(",")' == "<expected>"`. Drift in
either direction fails the export.

**Why two places**: defence-in-depth. If a future edit to
`package.transform.cjs` silently broadens the whitelist, the B3
exact-match assertion catches it. If B3 is weakened, missing scripts
surface at first `npm run <name>` and operators point back to the
whitelist.

### Shift 2 — Enterprise-name grep moves to verify.sh (B4)

**Before**: CLAUDE.md §8.1 enforced a manual grep during Ship Gate
`security-reviewer` pass. Ship Gate theme analysis flagged this as
"verification theater" (see `feedback_ship_gate_enterprise_name_leak_check.md`)
because humans skip grep when the diff is large and the diff always is.

**After**: `verify.sh` assertion B4 runs the `\bkvm\b|\boracle\b|\bhypervis|...`
pattern against `dist-source/` + the `.md` files shipped with the tarball.
Any match fails the build with the offending lines printed. No human ever
decides "did I remember to grep?" Shift-left catches what reviewer
attention cannot.

### Shift 3 — Structured transforms, never sed on YAML/JSON (B5)

**Before**: generate-devcontainer.sh used `sed` to strip the keycloak
block from `.devcontainer/docker-compose.yml`. Any YAML anchor, block
scalar, or multi-line property under `keycloak:` would break the regex.

**After**: `scripts/export-source/compose.transform.cjs` loads the YAML
with `js-yaml`, mutates the parsed object (delete `services.keycloak`,
clean `depends_on` arrays, drop scoped volumes), and dumps back. The
transform is idempotent, preserves indentation canonically, and cannot
produce invalid YAML — the dumper enforces it.

**Rule**: structured format → structured transform. sed is only safe on
flat, line-based text (Dockerfile ARG lines, `.env.example` key
prefixes). JSON / YAML / TOML / XML → use the parser.

### Shift 4 — Declarative include manifest considered and rejected

An "include-what-you-need" manifest (list files to KEEP, not files to
EXCLUDE) was considered during planning. Rejected because:
- rsync `--include` ordering with `--exclude` is notoriously error-prone
  (first-match-wins, leading slash anchoring, trailing slash for dirs)
- every new source file would need a matching include entry or it
  silently drops from the tarball — high maintenance cost
- the existing exclude manifest + assertion coverage already catches
  the class of bug the include would prevent (files that should drop
  but don't)

**When to revisit**: if a future class of bug surfaces where files
silently ship that shouldn't, and the exclude patterns can't scale to
cover them (e.g. third-party generator dropping unexpected artifacts).
Not now.

### Dockerfile drift owner

Per Eng A3, the owner of "keep Dockerfile in sync with dist-source
exclusions" is `scripts/export-source/export-source.sh` step 6b (sed
step). New `VITE_*` or `CLOUD_*` ARGs that land in the root Dockerfile
and must be stripped in dist-source are the responsibility of whoever
adds them, with the sed line in step 6b as the enforcement point.
verify.sh §30 (Supabase SDK imports) + S1 (positive Dockerfile ARG
pair) back-stop.

### Operator recovery

If a dist-source tarball is distributed without `schema-audit.js`
(old export pipeline silently dropped `docker-api/scripts/`), operators
can:
1. `tar xzf <tarball> dist-source/docker-api/scripts/schema-audit.js` —
   re-extract the single file from a fresh tarball
2. Ask Platform for a regenerated tarball (`npm run export:source` on
   a workstation); the verify.sh #15b assertion guards against this
   regression going forward.

### Addendum — strip-marker pattern supersedes line-anchored sed (2026-04-15, PR #49)

After v3.2.13a shipped, a user-selected line in `dist-source/Dockerfile`
surfaced two related leaks:

1. **Multi-line ENV continuation**: root Dockerfile had
   `VITE_SUPABASE_URL=$VITE_SUPABASE_URL` inside a backslash-continuation
   ENV block. Line-anchored sed `/^ENV VITE_SUPABASE_/d` didn't match
   continuation lines (they start with whitespace + identifier, not
   `ENV ...`). Leak survived.
2. **Documentation comments**: any `#` comment mentioning "Supabase" in
   the root Dockerfile survived into dist-source. Broke the
   "zero Supabase references in dist-source" guarantee.

**Fix pattern** — wrap the entire CLOUD-only block (ARG, ENV, comments)
with explicit begin/end markers in the root Dockerfile:

```dockerfile
# >>> STRIP-IN-DIST-SOURCE-BEGIN (CLOUD-only Supabase vars)
ARG VITE_SUPABASE_URL=
ARG VITE_SUPABASE_PUBLISHABLE_KEY=
# <<< STRIP-IN-DIST-SOURCE-END
```

`export-source.sh` step 6b uses a single range-delete:

```bash
sed -i '/# >>> STRIP-IN-DIST-SOURCE-BEGIN/,/# <<< STRIP-IN-DIST-SOURCE-END/d' \
  "$OUTPUT/Dockerfile"
```

One mechanism handles: ARG + ENV + continuation lines + comments + blank
lines inside the block. New CLOUD-only Dockerfile additions just wrap
with the same markers — no new sed pattern per case.

**verify.sh** guards two ways:
- strict zero-tolerance `VITE_SUPABASE_`/`[Ss]upabase` grep on
  `dist-source/Dockerfile` (catches leak if strip failed)
- `STRIP-IN-DIST-SOURCE` marker residue check (catches unbalanced
  BEGIN/END pair, which would leave markers visible in dist-source)

**Generalisation**: prefer **structural markers** over **pattern
matching** when the patterns to strip are heterogeneous (statements,
comments, blank lines, multi-line continuations). Line-anchored sed is
fine only when the target is a single uniform line-type. Markers trade
a small amount of root-file noise for a much more robust strip
mechanism.

---

## §55 Push-as-trigger GitOps — dual-repo separation (2026-04-16, v3.2.14b)

v3.2.14b routed image-tag deploy state **out of github main** into a
separate internal gitlab CD repo. Previously, `.gitlab-ci.yml:deploy-tag`
stage ran `kustomize edit set image` + re-rendered `flat-output/` + `git
commit [skip ci]` + pushed back to the same GitLab repo (which mirrored
github main). Every successful build wrote 1-2 `[skip ci]` commits to
main. Over months, `git log origin/main` became unreadable noise.

### The architecture

```
github CI repo                     gitlab CD repo (NEW)
─────────────────                  ─────────────────────────
src/, docker-api/, .gitlab-ci.yml  flat/{test,a,b}/*.yml
  ↓ (push to main)                   version/latest-sha.txt
6-stage pipeline                     .gitlab-ci.yml (on-push)
  validate → export → test →         ↓
  build → scan →                    deploy-{test,a,b} parallel
  render-push-cd ──(git push)──→    envsubst $IMAGE_TAG |
                                    kubectl apply
```

CI invokes `scripts/cicd/render-to-cd.sh`, which:
1. Runs `render-flat-output.sh --placeholder --out-dir <staging>`
   (new Phase 1 flag — renders kustomize output with `image: */fmb:__IMAGE_TAG__`)
2. Clones CD repo to temp checkout
3. Checks for `version/rollback-lock` file → exits 2 if present (C2 guard)
4. Copies staging flat/ → CD repo flat/
5. Stamps real SHA into `version/latest-sha.txt`
6. `git commit && git push` to CD repo

CD repo's own pipeline then fires on receive, runs
`envsubst '$IMAGE_TAG' | kubectl apply` per zone.

### Why it matters

The trick is the **placeholder tag**. If CI wrote real SHAs into CD repo
YAML, every deploy would be a semantic YAML diff (image tag change). By
keeping the literal string `__IMAGE_TAG__` in the CD repo YAML and only
changing `version/latest-sha.txt`, consecutive deploys look like 1-line
commits to git log. Diffs are trivial to read; rollbacks are
`git revert <commit>` + push (single small commit).

`envsubst '$IMAGE_TAG'` — explicit single-var allowlist — is critical.
Bare `envsubst` expands ALL `$VAR` tokens in YAML values, which silently
corrupts ConfigMap entries that contain literal `$` (e.g. passwords,
templated paths). The allowlist form restricts expansion to exactly one
known variable.

### Two trees, one contract (C3 resolution)

```
CI repo                               CD repo
infrastructure/k8s/flat-output/       flat/
  real-tag: app:abc1234                 placeholder: app:__IMAGE_TAG__
  purpose: dev visibility               purpose: deploy source of truth
  consumer: `--check` drift detect      consumer: ArgoCD + kubectl apply
```

These trees NEVER merge. The developer checks the real-tag tree with
`--check` to catch forgotten `render:flat` runs. The operator inspects
the placeholder tree for deploy history. `render-to-cd.sh` writes ONLY
to the CD repo's placeholder tree — it never modifies `flat-output/`.

### Rollback-lock mechanism (C2 resolution)

Without a guard, an operator's `git revert <bad-sha> && git push` in the
CD repo could be undone minutes later by an unrelated CI push that
re-renders the bad state. The fix is a small file:

```
$CD_REPO/version/rollback-lock
```

`render-to-cd.sh` checks for this file BEFORE pushing. If present, it
exits 2 with a clear message pointing to `fmb-rollback.sh unlock`.

`fmb-rollback.sh` (operator CLI in CD repo) has `lock` / `unlock`
subcommands that atomically create/remove the lock file + commit +
push. Destructive `last-good --confirm` subcommands REFUSE to run
unless the lock is already active — defense-in-depth against an
operator who forgets `lock` before `revert`.

### Operator observability (DX blind-spot 1)

Push-as-trigger is elegant but invisible to humans. `render-to-cd.sh`
emits a block on successful push:

```
[render-to-cd] ──────────────────────────────────────────────
[render-to-cd]  Triggered CD pipeline
[render-to-cd]    CD repo:      gitlab.internal/.../cd-pipeline
[render-to-cd]    CD commit:    1a2b3c4
[render-to-cd]    From CI SHA:  abcd1234
[render-to-cd] ──────────────────────────────────────────────
```

So humans reading CI logs can navigate directly to the triggered CD
pipeline without remembering URLs.

### Pattern applicability

This pattern isn't flexible-mold-specific. Any project where:
- CI noise in main branch is a concern (audit trail readability)
- Deploy state needs an independent git history (incident forensics)
- Operators need rollback-without-rebuild capability

...benefits from this split. The mechanical bits (`render-to-cd.sh`,
`ship-gate-check.sh`, `fmb-rollback.sh`, scope-guard allowlist) are
mostly reusable with s/fmb/<your-app>/ and a handful of path edits.

---

## §55.1 v3.2.14c pivot — placeholder tag abandoned, real tag wins (2026-04-17)

v3.2.14b shipped with `image: */fmb:__IMAGE_TAG__` placeholder in the CD
repo's flat YAML, expecting a downstream CD pipeline to run
`envsubst '$IMAGE_TAG' | kubectl apply`. This elegant separation assumed
the CD pipeline would be the deployer.

During the 2026-04-17 prod-cutover dry-run in local k3d simulation, I
swapped ArgoCD's `repoURL` to the new CD repo + `path: flat/<zone>/`.
Pods immediately hit `ImagePullBackOff` because ArgoCD applies YAML as-is
(no envsubst), so k8s tried to pull `k3d-fmb-registry:5000/fmb:__IMAGE_TAG__`
— a literal image tag that doesn't exist. Design gap logged as DG1 in
`project_v3214b_candidates.md`.

### Four resolution options evaluated

| Option | Shape | Verdict |
|---|---|---|
| A | Disable ArgoCD; CD pipeline becomes sole deployer via `kubectl apply` | Rejected — loses ArgoCD drift detection + self-heal, requires cluster kubeconfig in runner pod |
| B | Install ArgoCD Image Updater controller, watch registry, patch overlays | Rejected — extra controller in AIRGAP (Nexus mirror + CVE surface + Application annotation complexity) |
| C | ArgoCD Config Management Plugin that runs envsubst pre-apply | Rejected — invasive, fragile CMP setup, debugging nightmare |
| **D** | **CD repo holds REAL tag; ArgoCD applies directly (no envsubst layer)** | **Chosen** — smallest diff, works today, no new controllers |

### v3.2.14c implementation

Generalized `render-flat-output.sh --placeholder` into `--image-tag <TAG>`.
`--placeholder` kept as shortcut for `--image-tag __IMAGE_TAG__` (backward
compat for Option A / CD-pipeline-as-deployer setups).

`render-to-cd.sh` default switched from `--placeholder` to
`--image-tag $CI_COMMIT_SHORT_SHA`. CD repo's flat YAML now contains
deployable content directly. ArgoCD reconciles → apply → pods roll with
correct tag. No envsubst layer.

CD repo's `.gitlab-ci.yml` reduced to validate-only:
- `yaml-validate` — Python `yaml.safe_load_all` on every `flat/*/*.yml`
  (catches malformed CI renders before ArgoCD sees them)
- `rollback-lock-guard` — defense-in-depth refusal of non-operator pushes
  while `version/rollback-lock` present
- `readme-freshness-check` — 90d soft tripwire (DX blind-spot 2, unchanged)

### What stayed identical

- github CI → gitlab CD separation (the core value)
- `render-to-cd.sh` C2 rollback-lock guard
- `fmb-rollback.sh` operator CLI — identical UX, same subcommands
- `ship-gate-check.sh` scope-guard + enterprise-name grep
- TOCTOU re-check + PAT redaction + SSH/HTTP split (all v3.2.14b.1 fixes)

### What was dropped

- `envsubst` from CD repo pipeline (no deployer there anymore)
- `__IMAGE_TAG__` as the default placeholder (still opt-in via `--placeholder`)
- Two-tree C3 rationale — becomes "one real-tag tree, dev visibility preserved
  via flat-output/" (unchanged). The CD repo is also real-tag, but owned by CI.
  Not identical trees, just the same tag-resolution strategy.

### The meta-lesson

**Phase 8 "3-env smoke" in the v3.2.14b ship was skipped with flawed reasoning**:
"v3.2.14b touches zero runtime paths (no src/, no Dockerfile, no compose), so
the smoke is effectively N/A". That reasoning was wrong. The DEPLOY PATH itself
changed — that IS runtime, just at the cluster-orchestration layer. Any sprint
that changes the deploy path MUST include an actual e2e deploy-to-cluster
smoke before ship. The v3.2.14c dry-run caught this 1 day after v3.2.14b merged;
if we'd run it pre-merge we'd have shipped v3.2.14 + v3.2.14c as one PR.

See `feedback_phase8_runtime_verify_deploy_path.md` for the standing rule.

---

## §56 export:source mode flag + regex-drift early warning (2026-04-17, v3.2.14d)

**Context**: v3.2.14d ships two loosely-coupled improvements to `npm run export:source`:
PR-1 introduces `--mode=AIRGAP|ONPREM` so a single export pipeline produces both
deploy flavours, and PR-2 closes the regex / binary-lookup / permission paper cuts
that PR-1's runtime verify surfaced.

### The mode flag is not about Keycloak

The visible effect of `--mode=ONPREM` is "keycloak service kept in compose, onprem
devcontainer subconfig included". The real purpose is different: it removes the
cross-repo branch patch that internal teams were maintaining. Before v3.2.14d,
the source-of-truth was AIRGAP-only. ONPREM consumers had to either fork the
export pipeline or hand-edit dist-source after the fact. That drift caused real
bugs (e.g. v3.2.13.1 nested-`.env` leak — the fix only landed in one consumer's
fork until the upstream catch).

The architecture rule: **if a deploy mode produces a different dist-source tree,
the mode must be a first-class flag, not a downstream patch**. Any config the
deployer needs to change should surface as a flag on export, not as a branch
in someone's private fork.

### Regex drift is invisible until it fires

PR-1 F6 added `verify.sh #40`, which greps the final dist-source tree for any
live `SupabaseAuthAdapter(` or `from './supabase-auth'`. If the strip regex ever
stops matching, that assertion fails and the build stops. That's the safety net.

PR-2 P7 added 16 whitespace-variant fixtures to `strip-cloud.test.cjs`. Writing
those tests surfaced a real regex gap: the existing `^import\s+...` pattern did
not match a tab-indented `\timport` line, because `^` anchors to line start and
the tab is before the literal `i`. No existing codebase had that form, but it's
technically legal TypeScript (e.g. if a formatter indents imports inside a
conditional template string, or if a code-gen tool emits with leading tabs).

The fix: widen to `^[\t ]*import` and replace `\s` with `[\t ]` throughout,
so the regex accepts leading tabs/spaces at line start but doesn't accidentally
consume adjacent newlines in `/gm` mode. This is pedestrian — the lesson is
that **regex tests that enumerate whitespace variants catch drift you would
otherwise discover via a runtime white screen**. Verify-script assertions
(`#40`) catch the symptom. Unit-test fixtures catch the cause. Both are
needed; neither alone is enough.

### Fallback ladders are better than binary outcomes

Prettier's role in export is cosmetic (it produces a canonical index.html
layout). Before v3.2.14d PR-2, the code was "if `node_modules/.bin/prettier`
exists, use it; otherwise silently skip and hope verify.sh #31 catches it."
That is neither fail-fast nor fail-safe — it's fail-silent.

The P1 ladder:

1. Local binary (`$ROOT_DIR/node_modules/.bin/prettier`) — works offline
2. `npm exec --no-install prettier` — works if the dep is hoisted but the
   direct path fingerprints changed
3. Fail-fast — unless `--no-format` is set, abort with ERROR/CAUSE/FIX and
   show redacted stderr

Three tiers, one escape hatch. Failures become loud, not silent, and the
escape hatch exists for operators who hit edge cases (missing bin on an
airgapped jump host). Applied principle: **every "silently skip" in a
pipeline is a future support ticket**. Replace with tiered fallback +
documented escape.

### Path redaction belongs in every shared error

Error messages that include `/home/<real-username>/...` leak identity when
pasted into bug reports, pastebins, or GitHub issues. PR-2 redacts every
home path in both the bash stderr capture (`sed 's|/home/[^/]*/|/home/user/|g'`)
and in `compose.transform.cjs`'s `redactHomePath()` helper.

This is cheap (one regex) and prevents a whole class of operational leak.
The rule: **any stderr/error path surfaced to a user should be path-redacted
before echo, even in scripts that "only run in a controlled environment"**.
Controlled environments still get debugged in tickets.

### Source files and dist-source diverge deliberately

PR-2 P2 self-closes every void element in source `index.html`. Prior practice
was mixed — some tags had `/>`, others had `>`. Prettier handles both, but
the mix created noise in diffs and made it harder to assert invariants on
the exported file.

The dist-source pre-sanitize sed additionally strips `</link>`, `</meta>`,
`</br>`, `</img>`, `</input>`, and 9 other HTML5 void-element closing forms
that are illegal but sometimes emitted by template engines or copy-paste.
Source is already clean (L1); export runs pre-sanitize anyway (L2); prettier
is the third layer; verify.sh #31 HTML lint is the fourth. Four layers is
not over-engineering when the failure mode is "white screen on deploy".

### Summary — what to copy from this cycle

- If a deploy mode produces a different artifact, promote it to an explicit
  flag, not a patch.
- Verify-script assertions catch symptoms; unit-test whitespace-variant
  fixtures catch causes. Ship both.
- Replace silent-skip fallback branches with tiered ladders + fail-fast +
  escape hatch.
- Redact home paths in every error surface, not just "public" ones.
- For user-facing artifacts, 3-4 defensive layers is right-sized when the
  failure mode is opaque (white screen, cryptic error).

## §57 Shared-infra verify layer — dist-source devcontainer rename + external network (2026-04-18, v3.2.16)

### Problem

v3.2.14d shipped `dist-source/.devcontainer/` with its own bundled Keycloak
service. Three quiet failures compounded:

1. `.devcontainer/keycloak/realm-export.json` was correctly excluded from the
   tarball (contains OIDC client secret). Docker Compose's bind mount
   auto-created the missing path as an empty directory. Keycloak's
   `--import-realm` silently imported zero realms, leaving the `dev-realm`
   absent. OIDC login returned 404 with no clear error.
2. Both root devcontainer and dist-source used
   `COMPOSE_PROJECT_NAME=flexible_mold_base`. Container names collided.
   When the second `docker compose up` ran, Compose detected volume-path
   divergence (realm-export.json mount) and **silently recreated** some
   containers, partially overriding the first setup.
3. Operators never run Keycloak bundled in `dist-source`. The real
   deployment path always uses internal shared Keycloak. The bundled
   service was a "demo wart" that never matched reality.

### Design — `dist-source` is a verify-only layer, not a self-contained stack

| Aspect | Root (unchanged) | Dist-source (v3.2.16) |
|---|---|---|
| `COMPOSE_PROJECT_NAME` | `flexible_mold_base` | `flexible_mold_base_dist` |
| Service names | `workspace`, `mariadb`, `api-edge`, `keycloak` | `workspace-dist`, `mariadb-dist`, `api-edge-dist` (no keycloak) |
| MariaDB host port | 3306 | 3307 (env-override via `MARIADB_HOST_PORT`) |
| Keycloak | bundled | joins root's via external network |
| Network | own `flexible_mold_base_default` | same, attached as `external: true` |

Keycloak is **shared** between both devcontainers; MariaDB stays separate so
destructive POC tests in `dist-source` don't corrupt the root database. The
compose project name change gives each layer unique container names; the
service rename gives unique DNS names on the shared network.

### Why rename via AST walk, not hardcoded list

Initial sketch had a hardcoded `['workspace', 'mariadb', 'api-edge']`
rename list inside `compose.transform.cjs`. Eng review flagged this as
Crit-C2: the next service added to the source compose file (e.g.
`redis:`) would not be renamed, its DNS name would collide with root's
redis on the shared network, and nothing in the export pipeline would
catch it until runtime.

Fix: `renameServices` walks every top-level key under `services:` and
appends `-dist` unconditionally (minus an empty `RENAME_SKIP_LIST` future-
proofing hook). `depends_on` refs and `${VAR:-<svc>}` env defaults are
rewritten in the same pass so cross-service references follow.

Same shape applies to `attachExternalNetwork` and `injectWorkspaceHealthcheck`
— both walk services generically, with idempotency guards (`if (svc.healthcheck) return doc;`).

### Host port choice — static 3307, not scan or ephemeral

Reviewers proposed two alternatives:

- **Port scan 3306..3315** — pick the first free port at init time. Rejected:
  port changes each boot, breaking saved Windows DBeaver / HeidiSQL
  connection profiles. Plus opaque bash loop for contributors to debug.
- **`127.0.0.1:0` ephemeral** — kernel-assigned random port. Rejected: same
  DBeaver pain, plus no predictable value to log in the banner.

Chose static 3307 with `MARIADB_HOST_PORT` env override. Simple, predictable,
escape hatch for rare collision. Cut P3 scope ~70% vs the scan design.

### `initializeCommand` vs `postStartCommand` split

VS Code devcontainer spec:

- `initializeCommand` — runs on the **host** before container build/start.
- `postStartCommand` — runs **inside the container** after start.

Both are needed. `initialize.sh` runs `docker network inspect` on the host
(container can't reach the host Docker daemon early enough). `banner.sh`
runs inside the workspace-dist container where `curl keycloak:8180/...`
actually resolves via Docker DNS.

Falling back to the correct tool for each side sounds obvious but was a
consistent plan-review gotcha: reviewers initially proposed a single
in-container check that would have tripped on the bootstrap ordering.

### Operator empathy — the unhappy path matters most

`initialize.sh` failure message:

```
ERROR: network 'flexible_mold_base_default' not found
CAUSE: root devcontainer's shared infra (mariadb + keycloak) is not running.
       dist-source joins the root network via 'external: true' — it cannot
       create the network itself.
FIX:   cd to the root repo and run 'npm run infra:up', then reopen dist-source.
```

Three benefits:

1. **First-line tells the operator what failed.** No stack trace, no
   raw Docker error.
2. **CAUSE explains why** — `external: true` is the non-obvious detail.
   Without this line, operators try `docker network create` manually and
   then wonder why Keycloak still isn't reachable.
3. **FIX is one command with context**. Not a pointer to a runbook
   section; the command itself. Time-to-recovery < 30 seconds.

This pattern (ERROR / CAUSE / FIX tripart) is standardized across
v3.2.14d + v3.2.16 error surfaces. Worth re-using whenever a shell
script can fail in a way operators haven't seen before.

### Ship Gate test design lesson — anchor to origin/main, not HEAD

`scripts/cicd/__tests__/ship-gate-check.test.sh` originally used the
current HEAD as sandbox anchor via `git rev-parse HEAD`. Every synthetic
test scenario committed on top, so the diff against `origin/main` included
BOTH feature-branch changes AND the test's synthetic files. Earlier
sprints got away with this because their diffs all landed in the
ship-gate-check allowlist (`scripts/cicd/`, docs, `.gitlab-ci.yml`).
v3.2.16 was the first branch to land cross-scope (in `scripts/export-source/`),
which exposed the test-anchoring bug as 3 cascading failures.

Fix was one line: anchor to `origin/main` so every synthetic scenario
sees a clean diff. The bug shape:

> A test harness that captures state from the current repo (commit, HEAD,
> env) as its baseline WILL silently fail when that state drifts. Either
> make the harness pin a fixed baseline, or make it regenerate state
> deterministically.

Same pattern has bitten us before (v3.2.12 VSO `_raw` leak). The principle
is reusable: **test fixtures should fix their own environment, not inherit
from the caller**.

### Summary — what to copy from this cycle

- For shared infra that always exists, **join it externally** rather than
  bundling a fake copy. Dangling mounts on "secret" files is the worst of
  both worlds.
- When a pipeline renames identifiers, **walk the AST generically** instead
  of hardcoding a name list. The list will fall behind the source; a walk
  keeps up forever.
- Fixed port with env override beats dynamic assignment whenever a GUI
  client on another host needs to connect.
- Use `initializeCommand` for host-side pre-checks; `postStartCommand` for
  container-side runtime state. Don't cram both into one hook.
- ERROR / CAUSE / FIX is the error-message shape worth standardizing
  across every new shell surface.
- Test harnesses must pin their baseline state. Anchoring to HEAD is a
  time bomb.

## §58 Server-side feature requires client adoption checklist (2026-04-19, v3.2.31 Tier-3)

Across the v3.2.30 hotfix cascade we hit the **same shape four times**:

| Sprint | Server-side change | Missed client adoption |
|---|---|---|
| v3.2.12 | SPA wizard added `/healthz` probe | nginx layer that would serve `/healthz` never shipped |
| v3.2.14 | Frontend Express mounted `/config.js` runtime API base inject | only 1 of 5 SPA fetch sites read `window.__API_BASE__` |
| v3.2.30.3 | `/config.js` adoption audit grepped `Env.API_BASE_URL` | missed `Env.SSO_BASE_URL` — 9 auth-adapter call sites still relative |
| v3.2.30.4 | `install-sync-cron.sh` tested via interactive shell | real cron cwd=$HOME → script hit "no .git" silently |

**Root pattern**: a server-side feature ships, the plan author assumes
"clients will pick it up" but never enumerates the clients. Every later
sprint discovers another consumer that didn't migrate.

### Rule (project policy, applied to every new sprint plan)

When a sprint plan adds a new server endpoint, response shape, env var,
config file, or convention that any *client* would consume, the plan
**must** include a "Client adoption checklist" section that:

1. Enumerates every client module / call site that should consume the new
   thing — not just "the SPA" but every concrete file path.
2. Marks each entry as one of:
   - **ADOPT** — plan changes it as part of this sprint
   - **EXPLICIT-OPT-OUT** — plan acknowledges and justifies leaving it
   - **N/A** — clearly not applicable (e.g. test fixtures)
3. Reviewer checks the list before plan locks; missing items block.

### Install-script discipline (v3.2.30.7 lesson, same family)

For any `install-*.sh` / `setup-*.sh` script that emits a command for a
non-interactive context (cron tick, systemd unit, fresh shell):

> Test the emitted command from the actual delivery environment
> (`(cd /tmp && env -i bash -c '<cmd>')` for cron, `systemd-run --user
> --pty <cmd>` for systemd) before calling the script done.

Testing from the install operator's interactive shell preserves $PWD,
$HOME, $PATH, and the loaded shell rc — the cron tick has none of those.

### Why this isn't just "be more careful"

The four instances above each had a careful plan author. The cost shape
is what makes a checklist necessary: a one-call-site miss is a 1-line
fix in a hotfix; the lookup cost (grep all clients, judge each, file the
table) is paid once per plan and would have caught all four.

## §59 Three-URL responsibility model — Keycloak / API base / runtime inject (2026-04-19, v3.2.31)

Every authentication-related URL in the project belongs to **exactly one** of
three categories. Confusing them — especially in code reviews of new auth
adapters or new fetch wrappers — has historically produced silent 404s and
mis-routed traffic (most recently v3.2.30.6).

### A. Keycloak issuer URL — `KEYCLOAK_ISSUER_BASE_URL` (server env)

Identifies the Keycloak realm the OIDC middleware talks to. Two distinct
TCP flows use it:

1. **Server-to-server backchannel** — Express calls Keycloak's token
   endpoint to exchange `code` for tokens. Direct TCP, never via browser.
2. **Browser redirect target** — Express returns a `302 Location:
   <issuer>/protocol/openid-connect/auth?...` and the browser follows it.
   The browser sees the Keycloak URL only at this step.

Read by **server only** (`docker-api/src/infra/middleware/keycloak-oidc.js`).
Never embedded in the SPA bundle.

| Environment | Typical value |
|---|---|
| DevContainer | `http://keycloak:8180/realms/dev-realm` |
| K8s zone-a | `https://keycloak.localhost/realms/<realm>` |
| Production | `https://keycloak.example.com/realms/<realm>` |

### B. Express API base — runtime `window.__API_BASE__` (preferred) / `VITE_API_BASE_URL` (build-time fallback)

The host the SPA fetches `/api/*` from. **Includes ALL Express endpoints**
— data CRUD, auth (login / sso-login / callback / logout / audit-log),
setup wizard, system settings. Express co-locates these in one process;
the SPA always talks to that same host.

Resolution order (`src/platform/lib/api-base.ts:resolveExpressApiBase()`):
1. `window.__API_BASE__` (set by `GET /config.js` from the frontend Express
   role at request time, picked from per-zone `API_BASE` configmap) — wins
   when present, including when explicitly empty (= "same-origin relative")
2. `Env.API_BASE_URL` from build-time `VITE_API_BASE_URL` — fallback for
   DevContainer / Lovable CLOUD where there is no `/config.js` server
3. Empty → relative `/api/...` fetch (single-container deployments)

| Environment | `__API_BASE__` source | Effective base |
|---|---|---|
| DevContainer | build-time env | `https://localhost:3200` |
| K8s zone-a | runtime `/config.js` | `https://zonea-fmb-api.localhost` |
| Lovable CLOUD | (Supabase, no Express) | n/a |

### C. Frontend self-URL — `BASE_URL` (server env) / `FRONTEND_URL` (server env)

Two server-side env vars, both required when Keycloak is configured:

- `BASE_URL` — Express's own self-URL. OIDC middleware uses this to compose
  the redirect_uri sent to Keycloak ("call back to me at this URL"). Must
  be a real URL the browser can reach, not a pod loopback. Validated by
  `infraSchema` cross-field refine — fmb-infra refuses to boot if Keycloak
  is configured and BASE_URL is empty.
- `FRONTEND_URL` — browser-facing SPA origin. Used for post-logout
  redirect, CORS allowlist, cookie domain decisions. Often equal to the
  zone web ingress.

### Decision tree for new auth-adjacent code

When you add a `fetch(...)` or `window.location.href = ...` in a new place:

| You want to talk to | Use |
|---|---|
| Keycloak directly (server-to-server) | `process.env.KEYCLOAK_ISSUER_BASE_URL` |
| Keycloak directly (browser redirect FROM Express) | server emits `302 Location: <issuer>/...` — SPA does not assemble this URL itself |
| Express `/api/*` (data, auth, setup, anything) | `resolveExpressApiBase()` from `@/platform/lib/api-base` |
| The SPA's own origin (post-logout, CORS) | `process.env.FRONTEND_URL` (server-side); `window.location.origin` (browser-side) |

**Anti-pattern**: never hardcode Keycloak's port (8180) into SPA code, and
never hardcode the API base into SPA fetch calls. The first violates the
"SPA never talks to Keycloak directly" rule; the second locks the bundle
to one zone.

### Why this matters

The v3.2.30.6 incident: 9 SPA call sites used a build-time URL constant
that K8s never set (build-time was empty), so they fetched
`/api/auth/...` relatively → wrong pod (frontend instead of API) → 404.
The fix was mechanical (use `resolveExpressApiBase()` everywhere) but the
root cause was conceptual — reviewers thought "this is SSO so use the SSO
URL" rather than "this is Express so use the Express base." Categorising
URLs by **destination protocol layer** (Keycloak vs Express vs browser
self), not by **functional intent** (auth vs data vs profile), prevents
the recurrence.


## §60 RW/RO pool namespace + env dual-read (2026-04-19, v3.2.32a)

**Context.** v3.2.32 introduces a DB-layer GRANT/REVOKE UI whose grant target
needs to be a MariaDB service account (not a human). Separately, the user
roadmap wants the option of a physical read replica in production. Rather
than bolt on both at once, v3.2.32a ships the foundation as a zero-UI,
zero-new-API refactor so PR-2 can focus on the grant feature surface.

**Decision.** The pool grows a `rw` / `ro` namespace (`pool.rw.getConnection()`
/ `pool.ro.getConnection()`). When no separate read endpoint is configured,
`pool.ro` silently falls back to the writer pool — callers never see `null`.
This keeps the call-site diff trivial while letting operators flip a single
pair of env vars to route reads at a replica.

**Env-var rename with soft-break dual-read.** Canonical names are
`DB_RW_HOST`, `DB_RW_PORT`, `DB_RW_USER`, `DB_RW_PASSWORD` plus optional
`DB_RO_HOST`, `DB_RO_PORT`, `DB_RO_USER`, `DB_RO_PASSWORD`. Legacy
`DB_HOST` / `DB_PORT` / `DB_USER` / `DB_PASSWORD` still work in v3.2.32
with a one-shot deprecation warn from `buildEnvConfig()`. v3.2.33 flips to
fail-fast. Autoplan Eng review (E-H6) argued for this over a big-bang cut:
the cost was ~20 lines of dual-read code and one warn log; the benefit
was zero ConfigMap/VaultSecret sync race downtime for in-flight rollouts.

**Both-or-neither read endpoint.** `DB_RO_HOST` and `DB_RO_PORT` are the
primary enable flag. If only one is set, boot fails fast with
`INVALID_READ_CONFIG` so a half-configured replica surface never masks a
silent fallback to the writer. Enforced in three places that all flow
through the same `assertReadConfig()` helper:

1. `db.js:buildEnvConfig()` — env-vars path.
2. `db.js:configurePool()` — config-file / activated-connection path.
3. `docker-api/src/shared/config-schema.js:refineReadEndpoint()` — Zod
   schema refine across infra/edge/frontend roles.

Reader user and password fall back to the writer values when unset, which
matches the common real-world shape of "same host, a second MariaDB user
with `GRANT SELECT` only".

**db_connections grows four nullable columns** — `read_host`, `read_port`,
`read_username`, `read_encrypted_password`. Fresh installs ship them in
the `CREATE TABLE`; existing installs pick them up via an idempotent
`ALTER TABLE ADD COLUMN IF NOT EXISTS` added to the boot-time migration.
CRUD is pass-through and rejects mixed host/port at POST/PUT via the same
both-or-neither invariant. PUT merges the pair with the existing row so
partial updates do not tip the record into an invalid state.

**Migration path.** For operators upgrading from <v3.2.32:
```bash
sed -i 's/^DB_HOST=/DB_RW_HOST=/;s/^DB_PORT=/DB_RW_PORT=/;s/^DB_USER=/DB_RW_USER=/;s/^DB_PASSWORD=/DB_RW_PASSWORD=/' .env
```
The compose surface (`.devcontainer/docker-compose.yml`) ships the
post-rename shape to keep the dev image consistent — operators who do not
migrate see the runtime warn from `buildEnvConfig` but still boot.

**Deferred to v3.2.33** (tracked in `project_v3233_candidates.md`):
codebase-wide sweep of `pool.getConnection()` / `pool.query()` to explicit
`pool.rw` / `pool.ro` call sites, an eslint rule that blocks the shim,
removal of legacy `DB_HOST` accept, and real replica infrastructure if
operational commitment materialises.

## §61 Boot-banner role-branch regression + Ship Gate Step 5b/6/7 retrofit (2026-04-21, v3.2.51a + v3.2.52)

### The incident

v3.2.51 PR-3 (`ef1ca2f`) extended `docker-api/src/shared/lib/boot-banner.js`
`printBootBanner()` so all three roles (FRONTEND / INFRA / EDGE) shared
the same banner emission path. The new `printBootBanner` unconditionally
called `deriveSchemeFromBaseUrl(process.env.BASE_URL)` and
`new URL(baseUrl).host` — both of which throw when `BASE_URL` is absent
or malformed.

EDGE has always been exempt from `BASE_URL`: its `external` banner
column is the string `"internal S2S only"` (not a URL), and per
`infrastructure/docs/ENV_PLACEMENT.md` since v3.2.15 the var lives in
per-zone infra ConfigMaps only. `fmb-config-edge` has never carried it.

The regression shipped because every gate upstream returned green:

- **Unit tests** — `boot-banner.test.js` pinned the EDGE branch of
  `buildBannerLines` (the pure function) but never covered
  `printBootBanner` (the side-effecting wrapper that reads env).
- **Type check** — no type difference; the bug is semantic.
- **Ship Gate Steps 1-5 (pre-v3.2.52)** — scope-guard, enterprise-name
  grep, flat-output drift, rename-audit, pool-facade purity. None of
  these look at runtime behaviour.
- **v3.2.51 PR-3's author-run smoke** — booted INFRA only, which has
  `BASE_URL` in its ConfigMap, so the bug was latent for EDGE only.

### The symptom

User's internal AIRGAP cluster (not ours — under network isolation)
pulled v3.2.51 images. Every edge pod crashed at boot with:

    ERROR: BASE_URL env not set — boot banner cannot derive external scheme

Frontend pods separately rejected a **phantom `API_BASE` env variable**
that the user insisted was never in any ConfigMap. Without an env
snapshot in the log, we couldn't distinguish "validator bug" from
"stale ConfigMap still shipping the env" from "some other ConfigMap
leak into the pod". The user had to do a live shell-to-pod inspection
to rule out schema bug — exactly the debugging loop pod-ops tries to
avoid.

### The fix (PR1, v3.2.51a `333cc14`)

- Role-branch `printBootBanner`: EDGE skips the BASE_URL parse
  entirely; INFRA / FRONTEND keep the fail-fast.
- New `docker-api/src/shared/lib/env-snapshot.js` → `printEnvSnapshot`
  emits pod-annotation-sourced `fmb.io/env-sources` inventory + sorted
  key list at every boot, and a redacted values snapshot on
  `validateConfig` fail. Sensitive-key regex masks password / secret /
  token / cookie / encryption_key / auth_{password,secret,token} /
  credential. K8s downward API (no volume, no RBAC) surfaces the
  annotation via `fieldRef.fieldPath:
  metadata.annotations['fmb.io/env-sources']` — dot in key requires
  single-quote wrap.

### The prevention (PR2, v3.2.52)

Three new Ship Gate steps in `scripts/cicd/ship-gate-check.sh`:

- **Step 5b — structural-invariants**: every-PR ~100ms check. Asserts
  role-branch count ≤ enum size, envFrom components carry the
  annotation, index-*.js files all call printBootBanner. Catches the
  v3.2.51 pattern at scope-guard speed — no docker, no k3d, just grep.
- **Step 6 — docker-role-boot-smoke**: trigger-gated (docker-api /
  Dockerfile / components / compose). Boots all 3 roles via
  `node src/index.js`, pins EDGE with NO BASE_URL (the exact regression
  shape), asserts each emits `[boot-env] keys:` in stdout. Would have
  blocked v3.2.51 PR-3 from merging.
- **Step 7 — k3d-deploy-verify**: trigger-gated (k8s paths / render /
  gitlab-ci). Server-side dry-run by default (`kubectl apply
  --dry-run=server`) against a live local k3d cluster so
  admission-webhook validation (Istio, NetworkPolicy CRDs, etc.)
  actually runs. `K3D_VERIFY_FULL=1` switches to full apply + pod
  readiness + log grep for sandbox clusters.

Step 7's introduction immediately caught a pre-existing v3.2.51 M4
AuthorizationPolicy bug (`notValues: [""]` rejected by
`validation.istio.io`). The AP was silently dropped at cluster-sync
time, leaving the edge VS without its sidecar-level S2S check. Fixed
in the same PR — dogfood result.

### The rule

When a helper is "role-aware" (has any branch keyed on role / tier /
tenant), ship-gate must assert:

1. The branch count can't silently grow past the enum size.
2. A role-minimum env set exists for each role in unit tests (not
   just a happy-path test).
3. A real boot-time smoke covers each role's minimum env.

Boiler-plate unit tests aren't enough. `buildBannerLines` being pure
and tested didn't stop `printBootBanner` from regressing — because the
bug lived in the wrapper that reads env, and the wrapper had no test.
Pin the wrapper on the exact role × minimum-env combo that matters
in production.

Tracked in new memories `feedback_role_aware_boot_invariants.md` and
`feedback_deploy_path_ship_gate_invariants.md`.

---

## §62 Local-k3d vs internal-prod cluster — NODE_ENV + DEV CORS flag (2026-04-22, v3.2.54 PR-2)

### The question that led here

Operator saw `[api-infra] [cors] DEV localhost origins ENABLED (additive)`
with `origins: ["http://localhost:8130", "http://localhost:8230"]` in
ArgoCD pod logs and assumed it meant CORS was misconfigured or leaking
into production. It wasn't — the log is working as intended for one
specific environment. Rather than rewrite the log, document the
mental model so it doesn't re-surface as a question every sprint.

### The model

Both environments use the same ConfigMap source-of-truth
(`components/shared/configmap-shared.yaml`) which sets
`NODE_ENV: "production"`. But local k3d layers on a deliberate override
via `scripts/cluster/setup.sh:570,582`:

```bash
kubectl -n zone-test set env deployment/fmb-infra \
  DEV_LOCALHOST_CORS_ONLY_DO_NOT_SET_IN_PROD=true NODE_ENV=development
```

ArgoCD's `ignoreDifferences` block in `cluster/argocd-apps/fmb-zone-test.yaml`
keeps that `kubectl set env` change alive across sync cycles so the dev
override doesn't get reverted on every pull.

### What each environment actually runs

| Env | NODE_ENV | DEV_LOCALHOST_CORS flag | CORS log emits |
|---|---|---|---|
| Local k3d (zone-test / zone-a) | `development` (setup.sh override) | `true` (setup.sh override) | yes — expected |
| Local k3d (zone-b) | `production` (no override; edge-only zone) | unset | no |
| Internal production cluster | `production` (no setup.sh run there) | unset | no |

### The module-load guard

`docker-api/src/infra/app-setup.js:31-38` throws at module-load time if
the flag is `true` AND `NODE_ENV === 'production'`. So even if the dev
flag leaked into a prod ConfigMap by accident, the pod refuses to boot
with a clear ERROR/CAUSE/FIX instead of silently widening CORS. Belt +
braces: the log is scoped to `NODE_ENV !== 'production'`, and the guard
catches the remaining leak path.

### The `(additive)` keyword

Means the localhost origins are **appended** to the existing CORS
allowlist (built from `FRONTEND_URL`), not replacing it. In zone-a,
allowlist = `[https://zonea-fmb-web.localhost, http://localhost:8130,
http://localhost:8230]`. That's why a local kubectl port-forward to
:8130 can call the zone-a infra pod.

### When to ignore the log, when to act

- ArgoCD pod log shows `[cors] DEV localhost origins ENABLED` → ignore,
  it's local-k3d-only by design
- Internal prod cluster log somehow shows it → NOT possible under
  current code; treat as a CRITICAL indicator that someone added the
  flag to a prod ConfigMap or overrode NODE_ENV. Check
  `configmap-shared.yaml` and any `kubectl set env` audit.

### The rule

`NODE_ENV` is *source-of-truth* about environment class. The CORS log
is *derived* from that. If you want to change the log behaviour, change
the env class — don't try to silence the log directly, because the
module-load guard and the log condition are intentionally coupled.

---

## §63 — Privilege Check Semantics: Schema-level vs Global Scope (v3.2.53b + v3.2.55)

### Decision

`hasGrantOption(grants, schema)` accepts EITHER `*.*` OR `<schema>.*` with
`WITH GRANT OPTION` as evidence that the user can do GRANT/REVOKE. The
strict "only `*.*` counts" reading is wrong for least-privilege deploys.

### Why

A user with `GRANT ALL PRIVILEGES ON \`example_app\`.* TO 'example_app'@'%' WITH GRANT OPTION`
**can** do GRANT/REVOKE on tables inside `example_app.*` (limited to the
privileges they themselves hold). This is standard MariaDB / MySQL
behaviour. v3.2.53a and earlier required `*.*` scope, which forced
operators to elevate to superuser-shape grants — defeating the point of
least-privilege deploys and surfacing as a false "Privileges UI is
read-only" rejection on otherwise-correctly-configured schemas.

The live walkthrough on `https://zonea-fmb-web.localhost/system` with
the example_app-shape config was the trigger: the user had GRANT OPTION
on `example_app.*` but the UI rejected it because the parser only
checked the `*.*` row.

### How to Apply

- Server: `parse-grants.js` `hasGrantOption(grants, schema?)` — when the
  optional `schema` argument is supplied, scope `<schema>.*` with WITH
  GRANT OPTION qualifies.
- Client mirror: `usePrivileges.ts` and `PrivilegesPanel.tsx` MUST pass
  the live `_configFull.database` so the client doesn't drift from the
  server.
- Tests: `parse-grants.test.js` covers schema-level + global with one
  fixture per shape; regression-safe as long as the contract holds.
- Operator-facing copy: when read-only mode is justified (no GRANT
  OPTION at any scope), the UI surfaces the GRANT statement an operator
  can paste into MariaDB to unlock the panel — turns a dead-end into a
  one-step fix (MD7).

---

## §64 — Pool Lifecycle: Pre-Swap Probe + Strict Prefix (v3.2.53b + v3.2.55)

### Decision

`configurePool(config)` is now atomic: it probes the new RW (and
optional RO) endpoint with a temporary connection BEFORE swapping any
module state. If preflight fails, the new pool is closed, the old pool
keeps serving traffic, and `_tablePrefix` / `_configFull` / `_rwPool`
/ `_roPool` stay untouched. `t()` throws `PoolNotConfiguredError`
whenever `_tablePrefix` is null/empty — there is no silent `'fmb_'`
default.

### Why

The "ghost save" symptom on the v3.2.53b live walkthrough was a direct
consequence of "swap first, probe second":

1. Operator submits a new MariaDB endpoint via `/system → Change Server`.
2. configurePool installs the new pool / `_tablePrefix` / `_configFull`.
3. preflight runs against the new pool, fails with PreflightError.
4. HTTP returns 400. Disk file unchanged. **But module state is already
   the new (broken) pool.**
5. Subsequent UI requests hit the broken pool → cascading `preflight
   missing privileges` errors with no obvious cause.

The pre-swap probe (Q2) eliminates step 4 — preflight runs on a single
ad-hoc connection that is closed after the check, so the only state
the failure path can produce is "old pool, no swap, error returned to
caller". Combined with `t()` throwing on null prefix (v3.2.55 Q3 E1),
every illegal state surfaces as a structured error instead of a
wrong-table query.

The `'fmb_'` silent default was a compounding footgun: it let the
example_app-shape repro proceed past the wizard with a wrong prefix
that "looked configured" until the first real query. Forcing
operator-explicit prefix at all three layers (env-config →
configurePool → routes) means a missing prefix can no longer survive
into runtime.

### How to Apply

- `db.js`: `_tablePrefix` initialises to `null`; `t()` throws
  `PoolNotConfiguredError` (code `POOL_NOT_CONFIGURED`) on null/empty.
- `db.js` `configurePool(config)`: rejects empty/missing
  `config.tablePrefix` with code `TABLE_PREFIX_REQUIRED` BEFORE any pool
  work. The pre-swap probe runs on a temporary connection
  (`mariadb.createConnection`) released in `try/finally` — fd-leak safe
  under N consecutive preflight failures (TD1 / MD1).
- `setup/db-connect.js`: validates required + non-empty + regex +
  `prefix !== database` (Eng D2 overlap reject) at the HTTP boundary
  before reaching configurePool.
- Frontend: `<TablePrefixField>` renders required-shape UX (asterisk +
  aria + helper + live preview). Pre-fill with the currently effective
  prefix when one exists (TD9 migration prompt).
- Tests: `db-prefix-config.test.js` (E1 fail-fast + Q6 round-trip);
  `pre-swap-probe.test.js` (Q2/Q5 atomic-swap discipline).
- Operator UX: PreflightError message contract surfaces a copy-paste
  GRANT hint to stderr/pod logs (DBA-actionable) but **not** to the
  HTTP body (LOW security finding from v3.2.53b).


---

## §65 — Structural Defense: TABLES constant + Step 8 lint (v3.2.56)

### Decision

Cross-reference §63 + §64. v3.2.56 adds a Ship Gate Step 8 lint
(`scripts/cicd/no-hardcoded-prefix.sh`) that refuses `'fmb_'` literals
in production code, plus a `TABLES` symbolic registry for incremental
migration of `t('xxx')` callsites to `t(TABLES.XXX)`.

### Why

The v3.2.55 sprint root-caused the silent-default footgun at the entry
points (configurePool + db-connect.js + UI) but the 13 dead
`|| 'fmb_'` fallbacks inside route handlers (sync-schema, privileges,
schema-init, seed-data, export, PrivilegesPanel, Setup) remained as
anti-pattern that future contributors would copy-paste forward. The
sweep + lint together close that loop: existing dead code deleted, new
additions blocked at Ship Gate.

### How to Apply

- New `TABLES.X` constants in `docker-api/src/shared/constants.js`;
  add a row when adding a new table (also update
  `INFRA_TABLE_NAMES`/`ENGINE_TABLE_NAMES` per Class 6 of
  `DUAL_SOURCE_REGISTRY.md`).
- Use `requirePrefix(prefix, callsite)` in routes that touch a prefix
  outside the `t()` helper's reach (e.g., multi-DB `sync-schema.js`).
- The Step 8 lint allows comment-only lines, allowlisted test paths,
  and inline `// lint-allow: no-hardcoded-prefix <reason>` pragmas.
  Use the pragma sparingly — every use is a small debt.

## §66 — Cross-field DB refines must be role-aware: the v3.2.61 L-BC1 frontend crash-loop (v3.2.61 + v3.2.61a)

### Decision

Zod `superRefine` validators that gate on DB env presence (e.g.
"`DB_TABLE_PREFIX` is required when `DB_RW_HOST` is set") must be
applied per role-schema based on the role's actual runtime DB
behavior, not symmetrically across `infraSchema` + `edgeSchema` +
`frontendSchema`. v3.2.61a hotfix dropped
`refineRequiredTablePrefix` from `frontendSchema` and added a
positive-case unit test (frontend role passes when `DB_RW_HOST` is set
without `DB_TABLE_PREFIX`).

### Why

v3.2.61 L-BC1 removed the silent `${DB_NAME}_` fallback for
`DB_TABLE_PREFIX` (continuation of v3.2.55/56 silent-fallback removal)
and added `refineRequiredTablePrefix()` to all three role schemas.
Tests (672/672 docker-api + 461/461 root + 14/14 cicd), Ship Gate (9/9
including Step 6 docker-role-boot-smoke), and codex review all passed.
On real k8s deploy, **zone-a + zone-test frontend pods immediately
crash-looped** with:

```
DB_TABLE_PREFIX is required when DB_RW_HOST is set.
Set DB_TABLE_PREFIX explicitly; silent fallback to DB_NAME_
was removed in v3.2.61.
```

Root cause:

- The shared ConfigMap `cm/fmb-config-shared` carries `DB_RW_HOST`
  (because edge + infra need it).
- `secret/fmb-secrets` carries `DB_TABLE_PREFIX` (per-deployment value).
- Frontend deployment envFrom *only* `cm/fmb-config-shared` +
  `cm/fmb-config-frontend` — **never** `secret/fmb-secrets`, because
  frontend is static-only (`index-frontend.js`) and never opens a DB
  pool. Adding the secret would unnecessarily expose DB credentials
  to a process that doesn't use them.
- Result: frontend role saw `DB_RW_HOST` set + `DB_TABLE_PREFIX`
  unset → `refineRequiredTablePrefix()` rejected → boot fail.

This shape did not appear in any existing test or smoke because:

1. **Unit tests** instantiate `validateConfig('frontend')` with full
   role-aware env, and the v3.2.61 negative test was written for
   `infra` role (line 114 of config-schema.test.js), not frontend.
2. **Ship Gate Step 6 docker-role-boot-smoke** boots all three roles
   under `docker-compose` env, which gives every role the same
   variables (no CM/Secret split). It exercises *role behavior*, not
   *k8s deploy shape*.
3. **Step 7 k3d-deploy-verify** is gated on k8s-manifest changes; the
   v3.2.61 PR only touched `docker-api/src/`, so Step 7 was skipped.

The v3.2.61a hotfix (PR #168) was emergency-merged ~30 min after
v3.2.61, exempting `frontendSchema` from the refine and adding a
positive-case test (frontend role accepts `DB_RW_HOST` set without
`DB_TABLE_PREFIX`). All three zones returned to Healthy on commit
`6e5fd57`.

### How to Apply

- **Adding `superRefine` on DB-shape rules**: ask "does role X
  actually open a DB pool?" before applying the refine to role X's
  schema. `frontend` role never does — exempt it. `infra` is borderline
  (forwards to edge); apply only if `infra` itself queries the DB.
- **Negative-case tests must cover all roles**: when adding a refine
  triggered by `DB_RW_HOST`, write the negative test against `infra`
  *and* `edge` *and* `frontend` to surface role-asymmetric blast
  radius before merge.
- **Ship Gate Step 6 should also exercise k8s shape**: extend
  `docker-role-boot-smoke.sh` to boot frontend role with the actual
  k8s env shape (DB_RW_HOST in shared scope, DB_TABLE_PREFIX absent
  from frontend's envFrom set) as a regression test for this bug
  class. Tracked as a follow-up MED candidate.
- **When a PR doesn't change k8s manifests but changes config-schema
  validation that fires from configmap-supplied env**: manually run
  `kubectl apply --dry-run=server` against the live k3d cluster and,
  ideally, recreate one frontend pod before merge. Step 7 won't catch
  it because it gates on manifest-file changes, not validation-field
  changes.
- **Why local dev didn't catch it**: DevContainer + docker-compose
  use a single flat `.env` so frontend container *does* see
  `DB_TABLE_PREFIX`. The CM/Secret split is a k8s-only shape.
  Cross-environment parity testing (k3d-verify-full or scripted
  configmap-shape smoke) is the only mechanical defense.

## 67. Lazy preflight at DDL

The original smart-gating plan tried to decide at boot whether a DB user
should hold DDL privileges. CEO outside-voice review reframed the problem:
boot is a CRUD path, while schema init and migrations are DDL paths. The
correct UX is therefore not "operator account CrashLoops until a DBA grants
ALTER", but "operator account boots; DDL action returns a GRANT hint when
the admin actually asks for schema changes".

Decision tree:

- Boot / configure DB pool: require `SELECT`, `INSERT`, `UPDATE`, and
  `DELETE` on the prefixed application tables.
- Setup wizard `init-db`: require `CREATE` for missing tables and `ALTER`
  for existing tables before running DDL.
- `runSchemaMigrations()`: require `ALTER` / `CREATE` at function entry;
  in boot context log ERROR/CAUSE/FIX and skip migration instead of exiting,
  while HTTP callers surface a 400.

No env-var escape hatch was added. Privilege bypass flags become parallel
policy surfaces that operators forget to remove, and they weaken the
zero-hardcoding / explicit-configuration posture. Rollback remains the
normal git revert + rebuild path; least-privilege operators keep CRUD
access, while DBAs grant DDL only for setup or migration windows.

Telemetry-first follow-up: when setup reports "DB settings disappeared" or
the wizard enters a retry storm, add observability before changing rate-limit
magnitudes. The status-poll path should have a dedicated bucket and the UI
should surface `Retry-After`, but default limits should stay conservative
until telemetry confirms the pressure pattern.

Audit payload rule for DB connection changes: `feature_audit` may record the
connection label, success/fail status, disk-persist flag, and opaque error
code. It must not record hostnames, service-account usernames, passwords,
DSNs, or raw URLs. Treat this as a regression-test contract, not a reviewer
checklist item.

### v3.2.65 user-override addendum (2026-04-28)

The "wait one week of v3.2.64 telemetry before raising magnitudes" gate was
explicitly waived by the user. v3.2.65 ships the autoplan-approved limit
bumps, the db-status response cache, and the visibility-aware diagnostic
tick without telemetry data to back the numbers.

The risk is bounded by three facts:

- Every magnitude (`RATE_LIMIT_GENERAL_MAX`, `RATE_LIMIT_DIAG_MAX`,
  `RATE_LIMIT_MODE_MAX`, `RATE_LIMIT_STATUS_MAX`) is read from env at
  startup. Production reality can override the autoplan defaults without a
  code change.
- The db-status cache TTL accepts `0` as a disable hatch
  (`DB_STATUS_CACHE_TTL_MS=0` skips the cache on every request) and that
  behaviour is locked by a unit test.
- The visibility-aware tick only changes scheduler behaviour, not network
  behaviour, so it is a strict win regardless of the data.

If post-merge telemetry contradicts the autoplan numbers, fold the
correction into a v3.2.66 sprint rather than amending v3.2.65 retroactively.
Document the tuning rationale in v3.2.66's commit + CHANGELOG, not here, so
this section stays the single record of the override decision.

## §52 — Audit table semantic discipline (v3.2.67)

**Rule**: `feature_audit` rows must represent state-changing actions. Read-only probes that get a "no" answer are operational state, not user actions, and must not be audited under a mutation namespace.

**Trigger**: v3.2.63 added DDL preflight as a `SHOW GRANTS` check. The catch block wrote a row with `event_type='db_privilege.ddl_preflight.fail'`. The Privileges UI filter `event_type LIKE 'db_privilege.%'` then surfaced it in "Recent privilege changes" as if a GRANT/REVOKE had run, even though the entire flow had no SQL mutation. Symptom looked like a real audit gap; root cause was a namespace mistake.

**Why it happened**: when adding a code path that might be useful for forensics, the path of least resistance is to "just write an audit row" using a related event_type prefix. But the prefix encodes meaning (mutation namespace), and the UI filters on prefix. A read-only probe that gets denied is information, not history.

**Discipline**:
1. Before adding `INSERT INTO feature_audit`, ask: did anything in DB state change as a result? If no, log to stderr / structured logger only (pino auto-injects `src` per LEARN §50; that's enough forensics for read-only diagnostics).
2. If forensics is genuinely needed for a non-mutation event (e.g., admin-triggered HTTP failure where the audit log is the only trace), use a clearly distinct namespace (e.g., `db_diag.*`, `system.*`) and grep all UI filters for glob-matches against the mutation namespace before merging.
3. UI filters on `event_type LIKE 'X.%'` are a contract: they must be an enumerable allowlist of mutation events, not a wildcard that catches anything starting with the prefix.

**Where this is enforced**: integration test `docker-api/tests/integration/run-schema-migrations.test.js` asserts zero `db_privilege.%` rows after operator-mode boot. CI gates against reintroducing audit calls in the preflight failure path.

## §68 — Config-driven DB export as a layer, not a replacement

The dist-source export path now lets operators put `database.rw.*` and optional
`database.ro.*` values in `export-config.json`. This is deliberately a final
layer over the staged `--dev-env` and `--api-env` files, not a replacement for
those files.

That shape preserves backward compatibility: the default export still reads the
same `.env` templates, still forces `DB_RW_HOST=mariadb-dist` for compose
routing, and only changes other DB lines when config explicitly provides a
value. It also keeps operator intent visible: staging env files describe the
whole runtime surface, while JSON config carries the handful of values that
need one-shot substitution for a specific AIRGAP tarball.

The reader block remains all-or-null. A partial `database.ro` object creates a
deployment that looks configured but silently falls back in surprising ways, so
the schema rejects it before any export transform runs.

## §69 — Lint vs CLAUDE.md text reconciliation (2026-04-29, v3.2.70)

A post-v3.2.69 audit sweep nearly false-positived 19 hardcoded `'fmb_'` hits
because a parallel scanner read CLAUDE.md §3 Ship Gate Step 8 literally and
treated every comment-line `'fmb_'` as a violation. The actual lint at
`scripts/cicd/no-hardcoded-prefix.sh:116-118` deliberately skips comment-only
lines (`//`, `*`, `/*` prefix), and the file-header allowlist at
`scripts/cicd/no-hardcoded-prefix.sh:19-25` documents this skip explicitly. The
behavior just never propagated back to CLAUDE.md.

Regulation text must mirror lint behavior. When the two diverge, both AI
reviewers and parallel Agent scans regress to over-flagging or under-flagging,
which costs reviewer attention on every subsequent PR. The doc-honesty rule
from CLAUDE.md preamble already covers this case: «若發現 CLAUDE.md 或
CHANGELOG.md 有不明確或衝突，先與使用者討論並優先更新文件». However,
CLAUDE.md is itself gitignored per project §8 #3, so the matching one-line
edit to §3 Step 8 («此外 lint 自動 skip JSDoc/// 註解行...») lives in each
contributor's local CLAUDE.md and does not propagate via the repository
diff. This LEARN.md entry — with the lint-script line-number citations
above — is the tracked, propagating source of truth for the rule
alignment; new contributors should apply the same one-line local edit
to their CLAUDE.md after reading this entry.

Verification protocol going forward: before treating any pattern as a Ship
Gate violation, read the lint script that enforces it. The script is the
source of truth. CLAUDE.md text is a faithful summary; when the two disagree,
file a doc-only PR the same sprint.

## §70 — env-rewrite strict comment skip: operator override beats template completeness (2026-05-01, v3.2.77)

`scripts/export-source/env-rewrite.cjs` previously treated every commented
`# KEY=value` line as an "uncomment me" instruction during dist-source
export. That was the explicit v3.2.49 design: dist `.env` should never have
commented credential lines because the resulting file is meant to be
directly consumable by dotenv without operator intervention.

That intent works for empty-stub placeholders (`# DB_RO_HOST=`) — the
template is documenting the shape, the dist build fills in the value.
It silently breaks the operator's actual workflow for credential
rotation: keep the live primary as `DB_RW_HOST=10.0.0.1`, keep the
backup as `# DB_RW_HOST=20.0.0.2`, and toggle by commenting/uncommenting.
After v3.2.49, that backup line silently got auto-uncommented during
dist export, producing two competing live entries (last-one-wins under
dotenv) and nuking the operator's intended primary.

Resolution adopted in v3.2.77 — value-aware strict skip. Commented lines
that carry a value are preserved verbatim. Empty stubs still fall through
to the existing dist-default substitution. The v3.2.49 placeholder
semantic is preserved exactly where it has utility (templates), and the
operator override wins exactly where it matters (rotation).

Scope choice. The same strict-skip semantic was considered for
`EDGE_API_URL` and `KEYCLOAK_ISSUER_BASE_URL`. Audit against
`docker-api/.env.example` lines 101 and 142 found both keys present in
commented form with values the dist runtime depends on
(`api-edge-dist:3201` for EDGE; `http://keycloak:8180/realms/dev-realm`
for KC). Applying strict skip to those would have left dist `.env`
without live values, broken intra-compose routing for EDGE and silently
disabled Keycloak integration for KC. URL passthrough therefore keeps
v3.2.49 Q1/Q2 semantics. The operator pain (toggle pattern) is
DB-credential-specific; URLs are not toggled.

Trade-off documented. Future contributors who add a new commented
`# KEY=value` to `docker-api/.env.example` and expect it to be
auto-uncommented in dist build must use one of two patterns instead:

1. **Valueless commented stub** (`# KEY=`) — stays in the v3.2.49 fall-through
   path; gets filled by `--config` value or dist default.
2. **Live placeholder value** (`KEY=10.x.x.x`) — uncommented placeholder
   that gets rewritten in place; works with both `--config` and dist
   default substitution.

Anti-pattern: `# KEY=actualvalue` will now stay verbatim in dist `.env`,
which dotenv ignores. If that value matters at runtime, the line must
be uncommented in the source template OR supplied via `--config`.

Why this is a learn-able lesson, not just a fix. The v3.2.49 author
optimized for "dist build is autonomous; no operator hand-holding
needed". The operator workflow that surfaced in v3.2.77 optimizes for
"my live env file is the source of truth, even commented lines." Both
are reasonable goals; they cannot both win on the same line. Picking
"operator override wins" as the default flips the design center
of gravity from "template-driven completeness" to "operator-driven
authorship" for credential blocks. URL blocks stay template-driven
because there's no toggle workflow there.

Code reference: `scripts/export-source/env-rewrite.cjs:rewriteDatabaseLine()`
strict-skip guard at the head of each loop. Test coverage:
`scripts/export-source/__tests__/env-rewrite.test.cjs` fixtures 2 / 2b /
2c / 2d cover hard-fail / toggle preserve / empty-stub fall-through /
trailing in-line comment regression guard respectively.

## §71 — Keycloak realm-export.json is import-on-startup, not watched (2026-05-01, v3.2.77 ship epilogue)

PR #185 shipped clean — code merged, GitLab pipeline 228 green, ArgoCD 3-zone
healthy on `fmb:d416b1e6`. User then tested `https://zonea-fmb-web.localhost`
login + logout in the browser and reported "still failing." Investigation
took 5 minutes; root cause was infrastructure trivia: Keycloak imports
`realm-export.json` only on container startup, and the dev k3d KC container
had been running 3 days. The PR changed the file but the live KC kept the
old realm in memory.

Three lessons.

**1. Config files mounted into long-lived containers can be silently stale
post-merge.** Code reviews + Ship Gate + ArgoCD-sync-healthy all pass while
the runtime behavior is still pre-merge for that file. Generalize: any
file whose only consumer is a one-shot startup importer in a long-running
process is at risk. Realm-export, seed SQL, init scripts, certificate
bundles loaded via `tls.createSecureContext` at boot — all the same
shape. Default mental model "merged means deployed" doesn't hold here.

**2. The dev-mode recreate command is not `docker restart`.** On Docker
Desktop for WSL2, `docker restart flexible_mold_base-keycloak` failed with
`mount src=... no such file or directory` because Docker Desktop's
bind-mount snapshot cache invalidates when the host file is rewritten.
The reliable path is
`docker compose -f .devcontainer/docker-compose.yml -p flexible_mold_base up -d --force-recreate keycloak`,
which re-resolves the mount from the current host path. This is documented
in `infrastructure/docs/KEYCLOAK_REALM_SETUP.md` "Trap" callout so the
next dev who edits `realm-export.json` doesn't hit the same wall.

**3. Verification protocol that doesn't need admin credentials.** KC's
`/realms/<r>/protocol/openid-connect/auth` endpoint is unauthenticated
and returns either the login form (HTML containing `kc-form` / `username`
markers) or an error page containing `Invalid redirect uri`. Crafting a
GET with `redirect_uri=<expected URL>` and grepping the response body is
a quick sanity check on whether the live realm reflects the desired
allowlist — no admin token, no bypass. Same trick works for
`/protocol/openid-connect/logout?post_logout_redirect_uri=<URL>`.
Bash one-liner lives in the runbook trap callout for future reuse.

Production note. The prod KC apply path (per the runbook's curl flow
against KC Admin REST API) does NOT have this trap because it patches the
live realm in memory rather than re-importing a file. Dev k3d's
`realm-export.json` flow is the dev-only convenience that creates the
gap. Future improvement: a `make kc-recreate` target or pre-merge hook
that detects `realm-export.json` changes and reminds the operator.
Tracked as low-priority candidate; not scheduled.

## §72 — null vs '' Y-pattern decision (2026-05-01, v3.2.78)

Decision: API boundary normalization. Backend always returns '' (string) or 0
(number) for nullable cols where null and '' have no semantic difference. TS
interfaces stay non-nullable.

Why: TypeScript strict mode surfaces every `<Input value={null}>` site,
generating React warnings. Two architectural responses:

1. X-pattern: TS types `string | null`; UI uses `?? ''`; null is treated as a
   real semantic state, such as "inherit from parent".
2. Y-pattern: API normalizes; TS stays clean; null and '' are interchangeable
   storage states.

The codebase has no `?? parentField` inheritance pattern; `resolveFieldOptions()`
is a filter, not a resolver in the inheritance sense. Confirmed null and '' are
equivalent. Y-pattern wins on single-point repair, honest type signatures that
match normalized output, and React warning prevention by construction.

Trade-off: Y-pattern does not accommodate future inheritance semantic. If we
ever need "null = use parent's value" for these specific columns, flip to
X-pattern with a mechanical TS type change plus UI `?? ''` insertion.

Defense in depth: 2 NOT NULL migrations close the schema gap for
`user_templates.name` and `blueprint_output_order.sort_order`. Other columns
stay nullable in DB but are normalized at API boundary. Sync-schema import is
also a boundary: it must normalize present legacy nulls before upsert so old
exports still load into fresh NOT NULL tables.

Related: §70 (env-rewrite strict skip) is another case where operator workflow
beats a spec default. Ship Gate Step 13 is deferred to v3.2.82 as a mechanical
lint to catch future TS-DDL mismatch regressions.

## §73 — Public endpoint allowlist hardcoding rationale (2026-05-01, v3.2.79)

`PUBLIC_KEYS_ALLOWLIST` is `Object.freeze(['app_name'])` literal in code, not
env-driven, not prefix-matched, not config-table-driven.

Why hardcoded:
- Adding a new public key is a security-relevant change. Requiring a code edit
  + PR review is the right friction.
- Prefix matching ("any key starting with `public_`") is a footgun: a
  contributor naming a sensitive key with the wrong prefix accidentally
  exposes it.
- Env-driven (`PUBLIC_KEYS=app_name,foo,bar`) shifts the security boundary to
  deployment config, which is harder to audit and easier to misconfigure
  silently than source code.
- `Object.freeze` makes a mistaken `.push()` throw at the write site rather
  than silently expanding the public surface at runtime.

Defense in depth — TWO double-gates at runtime:
1. `isSensitiveKey()` from settings-crypto: exact-match against the project's
   sensitive-key registry. Currently only `keycloak_config` (a tombstone).
   Catches the case where the registry grows but the allowlist is forgotten.
2. `looksSensitive()` heuristic regex covering common key shapes: secret,
   password, token, credential, private_key, api_key, encryption_key, pwd.
   Catches the case where a contributor invents a brand-new sensitive-shape
   key (`db_password`, `oauth_client_secret`, `service_token`, …) without
   updating either registry. Substring match by design — false positives are
   acceptable; false negatives are not.

Why a heuristic and not just an exhaustive list:
- An exhaustive list of sensitive key names is impossible to maintain — every
  new feature can introduce a sensitive key that nobody remembers to register.
  A heuristic catches the common shapes; a structured registry catches the
  one-off names that don't fit the shape (e.g. `keycloak_config`). Both layers
  cost ~one regex check per row, which is free at the audit-log volumes the
  endpoint runs.

Cache strategy:
- ETag = `sha256(maxUpdatedAt || allowlist || values)` (first 16 hex chars).
  Deterministic across replicas because the inputs are pure. Changes whenever
  any allowlisted row's `updated_at` advances, the allowlist is edited, or a
  row appears/disappears. The values map matters because `maxUpdatedAt` alone
  doesn't move when the row count changes (e.g. seed insert with timestamp
  earlier than existing rows).
- 304 path skips the `feature_audit` insert: high volume, low signal — every
  page navigation would write a row otherwise.
- Frontend localStorage cache makes the brand visible synchronously on first
  paint after the second visit, even if the backend is briefly down (deploy
  rolling, network hiccup). Without it, the login page would flash empty
  before the public-endpoint promise resolves.
- No client-blocking rate limit. Per plan: the login page must never fail to
  render the brand. DDoS-grade limiting is acceptable; per-IP throttling
  would create a footgun (legitimate office NAT exits hit the limit during
  morning standup, half the team sees an unbranded login page).

## §74 — Data Clear UX: preflight FK + auto fallback rationale (2026-05-01, v3.2.79)

Three options were on the table for the engine-table Clear button:

A. TRUNCATE → on 1142 catch → ordered DELETE (silent cascade across child
   tables, single audit row).
B. Always DELETE (single code path, no privilege branching).
E. Preflight FK check via INFORMATION_SCHEMA + UI block when parent has
   children with rows + auto TRUNCATE→DELETE fallback for operator no-priv.

Decision: E.

Why E over A:
- A's silent cascade is opaque to the operator. They click Clear on
  `blueprint_fields` and 12 rows in `field_options` also disappear. The
  operator wasn't told that the cascade would touch `field_options`. If
  later the data was needed, the audit trail offers a single
  "truncated blueprint_fields" row — no record that the cascade ran.
- E's UI block forces the operator to consciously clear children first. Each
  Clear is its own audit row. The dependency tree shown in the UI is the
  operator's mental model upgrade.
- E's preflight surfaces dependency relationships visually, not just on
  error. Operators learn the schema through the UI rather than discovering
  it via 409s.

Why E over B:
- B forfeits TRUNCATE's speed advantage for admin-priv users (who are the
  common case during dev/test cycles).
- TRUNCATE resets AUTO_INCREMENT. DELETE does not. For dev workflows that
  expect monotonic IDs starting from 1 after a clear, the reset matters.
- E uses TRUNCATE when possible; falls to DELETE only when the privilege
  forces it. The audit row records `method: 'TRUNCATE'` vs
  `method: 'DELETE'` so the operator knows whether AUTO_INCREMENT was
  preserved or reset.

AUTO_INCREMENT trade-off on operator path:
- DELETE doesn't reset AUTO_INCREMENT. Operator-priv accounts will see PKs
  continue from where they left off after a clear. UI never displays
  AUTO_INCREMENT, so no UX impact. DBA can manually
  `ALTER TABLE ... AUTO_INCREMENT=1` if reset is needed.
- This is a documented limitation, not a bug — the alternative (granting
  TRUNCATE/RELOAD privilege to the operator service account) is worse from
  a least-privilege standpoint.

Two-stage audit (`attempt` → outcome):
- Aligns with the v3.2.67 ddl_preflight pattern. Each clear emits the
  `attempt` row first, then exactly one of `success`, `blocked_by_fk`,
  `fallback_to_delete`, or `fail`.
- Doubles the `feature_audit` write rate but enables operational debugging:
  "we attempted but were blocked" vs "we never attempted" is a different
  signal than just "we cleared" / "we didn't clear". Without the attempt
  row, a clear that fell over due to network mid-flight would leave NO
  audit trace at all.
- The attempt audit is wrapped in its own try/catch — failure to write the
  attempt audit MUST NOT abort the operation, since the outcome audit will
  still record what happened.

Defense in depth at the route boundary:
- Physical table names from INFORMATION_SCHEMA are validated against
  `/^[A-Za-z0-9_]+$/` before being interpolated into `COUNT(*)` queries,
  even though INFORMATION_SCHEMA only ever returns valid identifiers.
  Belt-and-braces against future schema changes that might surface
  weirdly-named tables (e.g. backup tables created with non-standard
  naming).
- `TABLE_SCHEMA = DATABASE()` filter ensures FK lookups never see other
  databases sharing the MariaDB instance — no information leak about
  neighbouring deployments.

## §75 — docs/wiki/ Source Contract for fmb-wiki framework (2026-05-02, v0.3-2)

### What

`docs/wiki/` is the source-of-truth for the fmb-wiki rendering framework's
boss-deck + ops/reference HTML wiki output. v0.3 inverts the v0.2 source-of-truth
boundary: this repo (`flexible_mold_base`) owns 8 numbered MDs (`00-` ~ `07-`)
plus diagram sources under `_diagrams/`; fmb-wiki repo becomes a pure rendering
engine.

### Contract surface

- 8 strict filenames: `00-executive-summary.md` / `01-context-and-goals.md` /
  `02-architecture.md` / `03-data-design.md` / `04-deployment.md` /
  `05-flow-and-interfaces.md` / `06-quality-and-ops.md` / `07-roadmap-and-roi.md`
- Required frontmatter fields: `title` / `audience: boss` / `status` /
  `slide_takeaway` (≤80 chars) / `exec_summary` (3-5 bullets ≤120 chars each)
- `02-architecture.md` MUST also have `diagram: <path-to-svg>`
- `not-applicable` status requires `not_applicable_reason` + `review_after`
  fields. Cannot delete an MD — the 8-MD set IS the table-of-contents contract.
- `_diagrams/` directory must exist (may be empty)

Full normative spec: `fmb-wiki/framework/SOURCE-CONTRACT.md`.

### `{{auto:*}}` placeholders

Body MAY embed `{{auto:NAME}}` placeholders that the framework expands at build:

- v0.3-1 ships 3 minimum extractors: `change-history` (CHANGELOG tail),
  `tech-stack` (multi-manifest dispatch), `diagrams-index` (file enumeration)
- v0.3-4 expands to 7 Tier 1 (adds `component-breakdown` / `environments` /
  `cicd-pipeline` / `containerization`)
- Tier 2 (`db-schema` / `api-routes` / `test-coverage`) deferred to v0.4+
  per autoplan UC2 (gold-plating risk; no real consumer yet)

### Failure mode hard rule (autoplan UC1 + AD1)

Extraction failures MUST surface visibly:
- HTML wiki: red bordered banner block at placeholder location
- PPTX deck: red overlay frame on the affected slide
- `_build/extraction-report.md`: row marked FAILED

The v0.2 silent-skip-with-HTML-comment pattern is **explicitly forbidden** in
v0.3. Same anti-pattern as `feedback_no_fake_green_ci.md` already learned not
to repeat.

### Validation locally

```bash
# Single MD validation
node /path/to/fmb-wiki/framework/lint/validate.js frontmatter docs/wiki/00-executive-summary.md

# Full rebuild against this repo
WIKI_SOURCE_REPO=$(pwd) bash /path/to/fmb-wiki/framework/build/rebuild-all.sh
```

### Why this lives in source repo, not wiki repo

v0.2 had narrative content as hand-curated MDs in the wiki repo's `docs/`. This
created a permanent staleness window: source code shipped without updating the
wiki, no one noticed. v0.3 forces narrative to live next to the code it
describes, so a single PR can update both.

### Migration entry point

For users on v0.2 wiki:
```bash
bash /path/to/fmb-wiki/framework/migrate/inventory.sh $(pwd)
```
Produces `_build/migration-inventory.md` listing what's missing for the v0.3
contract. Detailed steps in `fmb-wiki/framework/MIGRATION.md`.

### CLAUDE.md mirror

CLAUDE.md (gitignored) §7.5 carries a brief mirror of this section for local
quick-reference. Per LEARN §69 (lint-vs-doc reconciliation), each contributor
applies the matching one-line/one-section edit to their local CLAUDE.md.

## §76 — Doc-vs-code drift in security-sensitive subsystems needs mechanical guard (2026-05-05, v3.2.86)

### Context

v3.2.86 ships a CSP relaxation in `docker-api/src/index-frontend.js`:

```diff
- scriptSrc: ["'self'"],
+ scriptSrc: ["'self'", "'unsafe-eval'"],
+ workerSrc: ["'self'", 'blob:'],
```

This **re-instates** a CSP design originally specified in v3.2.0
(`docs/archive/LEARN_archive.md:689` documents the targeted directive set).
The directives were lost during the v3.2.14 frontend-role split (`7add237`)
when Helmet was duplicated into the new `index-frontend.js` without the
worker-src + unsafe-eval pair being carried over.

The bug surfaced as a regression that took **12+ months** to reach a user
report — the transformer Run / data-entry Generate flows fail in K8s prod
(`Creating a worker from 'blob:...' violates CSP "script-src 'self'"`) but
work in dev (Vite, no Helmet).

### Why the drift took 12 months to catch

Three factors compounded:

1. **No CSP unit test on the frontend role.** The existing test file covered
   `/health`, `/config.js` script injection, and SPA fallback — exactly the
   surface a CSP relaxation refactor wouldn't touch. The Helmet middleware
   mounting was untested.
2. **Stale doc trail.** `transformer-sandbox.ts:9` JSDoc claimed
   "Fallback: if Worker creation fails, runs in main thread via new Function()
   with a console warning" — but the actual code at lines 151-159 had been
   refactored to refuse main-thread execution (no sandbox isolation = unsafe).
   A future reviewer reading the JSDoc would assume the main-thread path
   exists, mis-evaluate the CSP threat model, and possibly tighten CSP
   incorrectly.
3. **`docs/archive/LEARN_archive.md:689`** documented the design as
   `Targeted script-src 'unsafe-eval' + worker-src 'self' blob:` — but
   archive is by definition not on the active reading path. New contributors
   referenced LEARN.md (active) instead, where the design contract was no
   longer surfaced.

### The pattern

Any security-sensitive subsystem (CSP, auth middleware, sandbox isolation,
crypto config, encryption-key handling) **must have its design contract
mechanically asserted, not just documented**. Documentation drift is the
default state of a long-lived project; mechanical assertion is the only
durable guard.

### What v3.2.86 ships

1. **Black-box CSP HTTP header test** in the existing `index-frontend.test.js`
   (added under `index-frontend — CSP directives (v3.2.86)` describe block).
   Asserts the actual mounted Helmet response header contains `worker-src
   'self' blob:` and `script-src 'self' 'unsafe-eval'`. Catches future
   regression: someone refactors Helmet config and silently drops
   directives → CI fails immediately, not 12 months later.
2. **`scripts/cicd/forbid-eval-helpers.sh`** — Ship Gate Step 13, exit
   code 13. Diff-aware default; `FULL_SCAN=1` for baseline audit. Forbids
   new `dangerouslySetInnerHTML` / `.innerHTML =` / `insertAdjacentHTML`
   / `new Function` outside an explicit allowlist. Allowlist:
   `src/platform/lib/transformer-sandbox.ts` (intentional `new Function`
   inside the worker — the legitimate use that drives the CSP relaxation)
   + `src/components/ui/chart.tsx` (dormant Lovable component, CSS-only).
   This catches the **future-feature regression risk** that `'unsafe-eval'`
   introduces: any new DOM injection sink now becomes a sandbox-escape
   vector instead of a benign XSS the browser eval-blocker would have caught.
3. **`transformer-sandbox.ts:9` JSDoc fix** — doc now matches the code at
   lines 151-159 (`if Worker creation fails, execution is REFUSED`).
4. **Destructive-ops rate-limiter** (`docker-api/src/infra/limiters.js`
   `destructiveOpsLimiter`) — `'unsafe-eval'` weakens XSS-eval-escalation
   defense. Combined with the pre-existing `bypassGeneralLimiter` skip-on-
   authenticated logic on `/api/sync-schema/{clear,truncate,drop}-table`,
   a stolen admin token would otherwise allow unbounded destructive calls.
   New limiter has NO `skip` function (verified by unit test); 5 req / 15
   min budget; per-user-id keying. Test asserts `destructiveOpsLimiter`
   has `options.skip === undefined` so a future refactor can't silently
   re-introduce the bypass.

### Generalisation

The "doc-vs-code drift in security subsystems" pattern recurs:

| Subsystem | Documented contract | Mechanical guard |
|---|---|---|
| Frontend CSP | LEARN_archive.md:689 (was archived) → §76 (now active) | Black-box CSP HTTP header test + forbid-eval-helpers lint |
| Transformer sandbox | transformer-sandbox.ts JSDoc | forbid-eval-helpers lint catches new `new Function` outside allowlist |
| Engine destructive routes | §76 (this section) | destructiveOpsLimiter tests assert no `skip` function |
| Encrypted system_settings | comment in `system-settings.js` | (encrypt-decrypt round-trip test exists) |

When adding any new security-relevant config or subsystem, ask:
1. What's the design contract? (one sentence)
2. Where does the contract live in code-as-truth? (file:line)
3. What's the mechanical assertion that catches drift? (test or lint)

If you can't answer (3) crisply, the contract is doc-only and will rot.

### Deferred middle alternatives

The autoplan review flagged 4 middle-path alternatives that could let a
future sprint drop `'unsafe-eval'` entirely without the full eval-free
interpreter rewrite:

1. **External worker file** (`/workers/transformer.js` static asset)
   served with its own `Content-Security-Policy` HTTP header (no
   `unsafe-eval`). Still needs `new Function()` for user code wrapping,
   so combine with (3) or (4) below.
2. **Sandboxed iframe runner** — separate document with own CSP, worker
   created from inside the iframe scope. Heavier UX integration.
3. **Capability-restricted transformer API** — replace free-form JS with
   declarative ops (e.g., `pick`, `map`, `filter` primitives). Rewrites
   the transformer authoring contract; major UX change.
4. **AST validation + Function constructor with sandboxed scope chain**
   — parse user code, reject AST nodes that escape the sandbox, then
   compile via `Function`. Still uses `'unsafe-eval'` but narrows attack
   surface significantly.

These were deferred via the v3.2.86 sprint (`project_v3287_followup_candidates.md`
UC2-deferred). Estimated 1-3 days per alternative.

## §77 — `WITH RECURSIVE … UPDATE` is not portable across MariaDB versions (2026-05-09, v3.2.103)

### Context

v3.2.99 introduced a recursive CTE for the hierarchy `node_type` ENUM
backfill. Same shape, two different SQL contexts on the same connection:

```sql
-- SELECT context — works on production MariaDB
WITH RECURSIVE depth_walk AS (...) SELECT MAX(depth) FROM depth_walk;

-- UPDATE context — fails with errno 1064 ER_PARSE_ERROR
WITH RECURSIVE depth_walk AS (...) UPDATE table h JOIN depth_walk d ON ...;
```

The local development MariaDB and the production MariaDB differ on whether
the parser accepts CTE in UPDATE position. Local CI was green. Production
boot logs caught the parse error every time, but `runSchemaMigrations` had
no containment so a single ALTER step would fail and leave the column
VARCHAR forever.

### Why local-vs-prod parser drift is hard to catch

- The SELECT-context CTE works everywhere with WITH RECURSIVE support.
- Drift only surfaces when the same CTE is re-used in UPDATE position
  later in the same migration step.
- MariaDB release notes mark CTE-UPDATE as a feature gated per major
  version; minor and patch versions sometimes regress or gate it
  behind defaults.
- Standard portability tests (run the migration on both versions) only
  catch this if the test fixture exercises a non-empty hierarchy that
  reaches the UPDATE branch.

### The pattern

If a recursive CTE materialises a row set you then want to UPDATE
against:

1. Don't rely on `WITH RECURSIVE … UPDATE` JOIN syntax.
2. Run `WITH RECURSIVE … SELECT` to materialise the (id, …) rows.
3. Group rows in application code by the discriminator (depth in this
   case).
4. Run one targeted UPDATE per group with a placeholder IN clause.
5. Wrap the UPDATEs in a transaction so a mid-flight crash rolls back.

This pattern is portable to older MariaDB and works under MySQL 8 as
well. The only cost is a round trip per group; for hierarchies that fit
in one boot's worth of work the round-trips dominate negligibly compared
to connection establishment.

### What v3.2.103 ships

- `migrateHierarchyNodeTypeEnum` rewritten to the 2-step pattern.
- Per-batch placeholder cap (1000) keeps UPDATE statements safely below
  `max_allowed_packet`.
- BEGIN/COMMIT wrap; ALTER outside the transaction (DDL implicit-commits).
- ROLLBACK on mid-flight failure; rollback failure is logger-only and
  does not mask the original error.
- Closed-enum sanitiser maps the (step, errno) tuple to a structured
  payload — `(hierarchy_node_type_backfill, 1064) → CTE_UPDATE_NOT_SUPPORTED`,
  any other step with errno 1064 → `PARSE_ERROR_OTHER`. errno alone is
  not specific enough; downstream consumers (admin endpoint, audit log)
  rely on the tuple-keyed code, not free-form text.

### Generalisation: portability lint heuristic

Before relying on a CTE in UPDATE/DELETE/INSERT position:

1. ☐ Confirmed both local and production MariaDB versions accept the
   exact statement shape (run a probe query on both).
2. ☐ The probe explicitly exercises non-empty data so the parser
   decides on the real shape, not an empty-table optimisation.
3. ☐ If portability cannot be confirmed, fall back to the materialise +
   per-group UPDATE pattern.

Documented as part of the visibility-surface RFC (`docs/RFC/visibility-surface.md`
§0) and the migration registry (`docker-api/src/edge/migrations-registry.js`)
so future migrations declare a `failure_policy` and pre-mapped errno tuple
when they introduce new SQL shapes.

## §78 — RFC mandates can hide CI infrastructure assumptions; spike before authoring (2026-05-09, v3.2.105)

### What happened

RFC `docs/RFC/visibility-surface.md` §7 mandated a hard-fail capability
check on the operator-mode integration test: every run must execute
`CREATE USER … + DROP USER` before provisioning the fixture, and
failure must throw — explicitly forbidding `t.skip` and any env-flag
bypass. The intent was to prevent the v3.2.99-101 silent-drift class
of bug, where the most important schema-drift coverage passes by
virtue of not running.

When v3.2.105 sat down to author the test, the 30-minute capability
spike found something more upstream than the RFC anticipated:

- DevContainer `mariadb:10.11` root account has CREATE USER + DROP USER
  ✓ (the test fixture works locally)
- GitLab CI has **no MariaDB service at all** — `.gitlab-ci.yml` `test:`
  stage comment explicitly notes: "Ephemeral MariaDB integration is NOT
  included here. … Tracked as a separate v3.2.27+ candidate."

The RFC was written assuming "CI has DB but maybe lacks privileges."
Reality was "CI has no DB period," which is a different category of
problem and a hard prerequisite for the RFC's hard-fail mandate to mean
anything. Without a DB, the test would either silently skip (violating
RFC §7's letter) or hard-fail every CI run (bricking the pipeline).

### Why the spike caught it but RFC review didn't

RFC review focused on the test's **behaviour** (privilege detection
should be loud, not silent). It did not stress-test the test's
**preconditions** (does the CI runner even have a DB the test can
attach to?). Reviewers can confidently sign off on behaviour without
re-validating the substrate the behaviour assumes — especially when the
substrate is documented as "tracked as a separate candidate."

The spike caught it because it physically ran `CREATE USER 'fmb_capability_probe'@'%'`
on the runtime fixture, which forced the spike to enumerate every
fixture environment (DevContainer, GitLab CI, prod). That enumeration
revealed the missing MariaDB service in CI in 30 minutes — versus
finding it the hard way 4 hours into authoring the test, after every
`before()` configurePool call returns "no DB reachable" and `t.skip`
silently kicks in for every assertion.

### The pattern: spike substrate before authoring tests with substrate-coupled mandates

When an RFC §N has the form "the test for behaviour X must do Y
unconditionally," and Y depends on substrate (DB, network, privileged
syscall, external service), pause the implementation and run a
30-minute substrate spike across every test environment:

1. ☐ Local dev (DevContainer / laptop)
2. ☐ CI (every executor / runner / pipeline stage that runs this test)
3. ☐ Pre-prod / staging (if the test runs there)
4. ☐ Prod monitoring (if there's a synthetic / canary equivalent)

The spike's deliverable is not the test, it's the substrate map. It
should answer:

- Is the substrate present at all?
- If present, can the unconditional Y action actually run there?
- If Y fails, what's the user-visible CI failure mode?

Substrate maps surface gaps the RFC did not — including gaps that
look unrelated to the RFC's behavioural focus (a missing MariaDB
service in CI looks like infra plumbing, not a visibility-surface
concern, but it is the hard precondition for §7's mandate).

### What v3.2.105 ships

- `.gitlab-ci.yml` `test:` stage spins up an ephemeral `mariadb:10.11`
  sibling container with random host port, exports `DB_TEST_HOST=127.0.0.1`
  + `DB_TEST_PORT=<random>` + `DB_TEST_ROOT_PASSWORD=ci_test_root`, and
  cleans up via `after_script`. Closes the v3.2.27+ deferred candidate
  in passing.
- `docker-api/tests/integration/schema-status-operator-mode.test.js`
  hard-fails on missing capability per RFC §7; graceful-skips only when
  the DB itself is unreachable AND `REQUIRE_INTEGRATION_DB=1` is unset
  (i.e., a developer's broken DevContainer, not CI). Three outcome
  signals — version stamp not bumped, `migrateHierarchyNodeTypeEnum`
  alter-skipped state, endpoint reports degraded/failed — prove the
  operator-mode chain end-to-end without the brittle pino-via-sonic-boom
  log capture the original literal "WARN log emitted" assertion would
  have required.
- RFC §7 status header updated to "shipped" + RFC §8 prediction table
  audited and locked to the actual `recover/critical` shape (the
  original `terminate/n.a.` prediction conflicted with the v3.2.78
  shipped code path which catches ALTER errors and continues; the
  registry now matches reality rather than aspiration, per the
  `文件誠實守則` rule).

### Generalisation

When an RFC mandate combines a **forbidden silence** ("no t.skip, no
env-flag bypass") with a **substrate-coupled action** ("CREATE USER
must succeed"), the silence and the action interact: failure in the
action without an alternative escape produces the loudest possible
failure (red CI). That is fine when the action is supposed to
succeed everywhere — but if the substrate is missing in even one
environment, the loud failure becomes a hard CI brick. Spike first,
then either provision the missing substrate or amend the mandate.
The conversation about which to do is the value the spike unlocks.

## §79 — Setup wizard pool-persistence gap + sanitised pool diagnostic (2026-05-14, v3.2.114)

### Context

A user reported four bugs on a fresh local-argocd deploy:

1. Keycloak login showed "Db not configured" even though MariaDB was reachable.
2. The Setup Wizard's *Test DB Connection* succeeded but there was "no UI
   to persist a connection" — the next step always behaved as if no
   credentials existed.
3. "Where is the button to build engine tables?"
4. "Edge boots before tables exist — what's the safety net?"

Three of the four were rooted in code structure decisions rather than
a single bug. The fix sprint had to separate "what the user observed"
from "what is actually broken in the architecture."

### What was actually broken

**Bug 1 — pool-gate misattribution.** The 503 + `"Db not configured"`
string emits from the infra role's pool-readiness middleware in
`docker-api/src/index-infra.js:213-220`, fired whenever the module-level
`_rwPool` is `null`. Login flow (`/api/auth/sso-login`,
`/api/auth/callback`) is on the exemption list, but `/api/auth/me` —
called by the frontend immediately after the OIDC callback — is *not*.
Keycloak authentication succeeds, then `/api/auth/me` 503s, and the
frontend `KeycloakAuthAdapter.getSession()` silently returns null,
which the SPA treats as logged-out — visible to the user as an
unexplained "back to login" bounce. Engine tables are not on the
login path; the misattribution was a hypothesis, not a fact.

**Bug 2 — missing `/configure-db` call.** `StepDbConnect.handleTest()`
only ever posted to `/api/setup/test-db`. There was no call to
`/api/setup/configure-db`, which is the endpoint that actually
persists credentials to `/docker-api/data/db-config.json` and invokes
`configurePool()`. The test endpoint uses a dynamic pool and answers
"yes the credentials are valid" without configuring the runtime pool.
So the wizard reported success while the runtime state was unchanged.
The fix is to chain `/configure-db` after `/test-db` on success — and
to surface persistence failure ("Connection works but persistence
failed") as a distinct failure mode rather than the same green tick.

**Bug 3 — present but unreachable.** `StepSchemaInit` has had a working
"Initialize Schema" button since v3.2.1. The user could not reach it
because Bug 1 + Bug 2 chain-blocked navigation past Step 2. Once Bug 2
was fixed, Bug 3 was no longer a bug.

**Bug 4 — observable, not gated.** Edge boot intentionally does not
gate on table existence — gating it on the K8s readiness probe would
prevent the wizard itself from being reached when the pool is null
(chicken-and-egg). The actual gap was *visibility*: operators had no
sanctioned way to ask the running pod "why is the pool null right
now?" without `kubectl exec` + grepping logs.

### What we shipped

**Sanitised diagnostic surface.** A new pure-function module
`docker-api/src/shared/lib/pool-diagnostic.js` exposes four
helpers — `sanitizeConfigureError`, `envKeysPresent`, `hintCodeFor`,
`buildPoolDiagnostic`. Whitelist sanitisation: only `code`, `errno`,
`sqlState` pass through. `err.message` is dropped at the boundary.
This matters because mariadb error strings frequently embed
`host:port`, internal RO hostnames (e.g. `ro-replica-internal.corp`),
usernames, and on parse-errors the failing SQL fragment. The
sanitised body reaches unauthenticated callers of `/health` and
unauth setup users of `/system/diagnostics`, so the boundary has to
be strict by default. `env_keys_present` is a booleans-only map of
the six canonical `DB_RW_*` env vars — never the values themselves,
never the password length.

**Pool-state in `_lastConfigureError`.** `db.js` stashes the sanitised
error in `initializeFromConfig`'s two catches (file-config branch +
env-fallback branch), and clears it on `configurePool` success. The
swap is atomic with the pool swap, so `getPoolDiagnostic()` always
returns a state consistent with what `isPoolReady()` reports.

**`/health` + `/edge/health` tri-state body, status unchanged.** Both
routes now return a `pool: { pool_state, hint_code, ... }` block,
with `pool_state` ∈ `'configured' | 'setup-required' | 'degraded'`.
The HTTP status stays 200 unconditionally per the INVARIANT comments
now in both files — the K8s readiness probe is the K8s probe target,
gating it would make the wizard unreachable. Body degrades, status
doesn't.

**Bounded retry on transient errors.** `_connectWithRetry` retries
the initial `getConnection` probe up to 3 × 2s on a hardcoded
allowlist (`ECONNREFUSED`, `ETIMEDOUT`, `EAI_AGAIN`, `ENOTFOUND`).
Allowlist is by `err.code` only, never message substring — a future
driver release that puts `"ECONNREFUSED"` in `err.message` but with
a different `err.code` must not silently turn into a 6-second sleep
on credential errors.

**`bootstrap_credentials` decision tree.** `POST /api/setup/init-db`
now accepts an optional body field. Three branches: (1) body has
creds → one-shot `mariadb.createPool` runs DDL then `pool.end()` in
finally, credentials never persist to disk; (2) body empty +
`_rwPool` ready → legacy pool.rw path unchanged; (3) body empty +
`_rwPool === null` → new 412 `NEED_BOOTSTRAP_CREDENTIALS` (replaces
the prior generic 500). Bootstrap path threads `target_database` +
`target_prefix` through the body so per-deployment prefixes work
without process.env coupling — internal deployments differ in
prefix (CLAUDE.md §3) and silently inheriting the wrong one would
guarantee "table not found" runtime failures.

**Frontend 503 redirect with sessionStorage guard.**
`KeycloakAuthAdapter.getSession()` now intercepts 503 +
`DB_NOT_CONFIGURED` on `/api/auth/me`, reads the `hint_code` from
the response body, and `window.location.assign('/setup?reason=<hint_code>')`.
Once-per-tab sessionStorage guard prevents a redirect loop if
`/setup` itself 503s. Already on `/setup`, on `/access-denied`, or
non-`DB_NOT_CONFIGURED` 503s — no-op.

### Why this matters

The original framing — "engine tables missing causes the login
failure" — is the kind of plausible misattribution that looks
correct because it preserves the order of events: "tables missing"
→ "login fails." It survives shallow review because nothing
contradicts it. But it sends the fix to the wrong file. The actual
fix is upstream of the engine-table layer entirely.

Two takeaways:

1. **Premise audit before code.** Bug 1's hypothesis was
   architecturally plausible but factually wrong — `/api/auth/me`
   queries `users` + `login_audit` (platform tables, already
   present); engine tables are unreached in the login path. A
   five-minute grep would have ruled this out before any code
   change. The `office-hours` audit phase that ran before
   implementation caught this.

2. **Diagnostic surface goes everywhere "Db not configured" emits.**
   The 503 message stayed identical for years because it was a
   single string in one middleware. Adding the diagnostic
   `details.hint_code` to the same 503 (rather than synthesising a
   new error class) means every existing client that parses 503s
   gets the new information for free; no version-coupling between
   backend and frontend. Sanitisation is upstream so the body never
   leaks per-deployment values, even when accessed unauthenticated.

### Anti-patterns we avoided

- **Status-coding `/health`** to "fail" when the pool is null. This
  would make the K8s probe red, evict the pod, and prevent the
  wizard from ever loading on a fresh deploy. The wizard is the
  recovery path; the recovery path cannot itself be gated on the
  thing it's recovering.
- **Message-substring retry.** Treating "ECONNREFUSED" in
  `err.message` as a retry signal is robust until a driver release
  reuses the substring in a different context — at which point
  credential errors quietly turn into multi-second sleep loops.
  Allowlist on `err.code` only.
- **Echoing `err.message` to `/health` body** — mariadb errors
  frequently embed host:port, internal RO hostnames, usernames,
  and failing SQL fragments. Sanitisation lives at the boundary,
  not at the call site. Operators get the full error in `kubectl
  logs`; the public surface gets the codes only.

### Future work (deferred to v3.2.115+)

The Q3 plan called for a separate `StepRuntimeCredentials` wizard
step that would split bootstrap (one-shot DDL) from runtime
(DML-only). Phase 1a shipped the simpler shape — `StepDbConnect`
calls `/configure-db` with whatever credentials the operator
provides, so local-argocd users can paste root and move on. The
proper bootstrap-vs-runtime split is unblocked but not load-bearing;
it becomes necessary when a deployment policy actually mandates
DML-only runtime accounts (the v3.2.32 Privileges UI work points
toward this future). The backend `bootstrap_credentials` decision
tree is already in place, so when the frontend follow-up lands the
backend is ready.

- `db_source` is a 4-state visibility surface: `env` | `file` | `none` | `memory`. `memory` = a live in-memory configure-db swap (default ephemeral, or persist requested but the disk write failed), distinct from `file` (persisted to disk). Set by the configure-db handler after the persist outcome is known.

## §80 — Boundary lint hardening loop + grandfathering pattern (2026-05-15, v3.2.117)

### Context

The `scalable-wishing-harp` sprint added the HARD RULE
`infra-talks-to-edge-only` (CLAUDE.md §3) along with a Ship Gate
Step 15 lint that mechanically enforces it. The lint went through
five Codex review rounds before landing. Each round caught a
distinct bypass class that the previous regex missed. The loop is
worth recording because future boundary lints (e.g. the v3.2.118+
refactor of the 6 grandfathered sites, or any planned ESLint
plugin replacement) will face the same axes of failure.

### The 6 bypass classes Codex independently surfaced

1. **ESM internal-module imports** (round 2)
   The first cut covered `require('mariadb')` + ESM `import 'mariadb'`
   for the raw drivers, but missed
   `import { pool } from '../../edge/db'` and
   `import db from '../shared/db'`. Easy gap — the regex listed
   alternations only for the driver names, not for the relative
   internal paths the rule actually exists to block.

2. **Extension-suffixed imports** (round 3)
   `import db from '../../edge/db.js'` does not match a regex that
   requires the closing quote immediately after `/db`. ESM relative
   imports almost always include the extension. Adding
   `(\.(js|ts|cjs|mjs))?` between `/db` and the closing quote
   covered all four file types we ship.

3. **`.mjs` / `.cjs` files not scanned** (round 3)
   `find -name '*.js' -o -name '*.ts'` skipped both ESM-only and
   CommonJS-only files. A new `docker-api/src/infra/foo.mjs` could
   import anything with no gate triggering. Extended to all four
   extensions.

4. **Driver subpath imports** (round 3)
   `require('mysql2/promise')` does not match a regex pinned to
   the bare package name. The promise API is the canonical import
   for the mysql2 driver — it would have been the first thing a
   fresh contributor reached for. Extended each driver alternation
   with `([/-][a-z0-9_-]+)*`.

5. **Dynamic ESM imports** (round 4)
   `await import('mariadb')` uses the `import(...)` call expression
   which the regex didn't have an alternation for. Added.

6. **Multi-line statement bypass** (round 5, partially absorbed)
   `import { x } from\n  '../../edge/db'` (formatter linebreak
   between `from` and the module specifier) and
   `require(\n  '../../edge/db'\n)` (3-line require) split across
   physical lines bypass `grep -nE` line-by-line scanning. Solved
   the common from/import 2-line case via an awk-based statement
   collapser; documented the rare 3-line require-paren case as a
   known gap (Prettier auto-formats so prod risk is low).

### Why this loop is healthy, not embarrassing

Each round was Codex finding ONE gap, the patch closing it +
adding a synthetic test fixture, then Codex finding the next.
That is exactly the loop a security-grade boundary lint *should*
go through before shipping. The alternative is shipping a regex
that looks plausible, then discovering bypasses one by one in
incident postmortems.

The cumulative test fixture now covers:
- relative + absolute path imports of `edge/db`, `shared/db`
- `.js` / `.ts` / `.cjs` / `.mjs` file types AND extensions
- bare and subpath driver imports (mariadb / mysql2 / pg)
- static `require()` + ESM `import` + dynamic `await import()`
- single-line + multi-line (from-split, await import) statements
- inline `// lint-allow:` pragma respected on each shape

### The grandfathering pattern (Codex round 4)

Initial implementation kept a `GRANDFATHERED_LINES` array in the
lint script keyed by `<file>:<line>`. Brittle: any unrelated edit
above one of those lines shifts the line number, the allowlist
breaks, the same pre-existing leak fails as a "new" violation.
Codex flagged this on round 4.

The fix was simpler than expected: put the inline pragma directly
on each leak site. The `// lint-allow: infra-talks-to-edge-only
v3.2.118+ refactor target` comment travels with the line. When
the v3.2.118+ refactor lands and the import is removed, the pragma
goes with it — no separate registry to keep in sync.

This pattern generalises: **any "current state is grandfathered"
allowlist should live in the source files, not in a separate
script-level registry.** The script-level approach optimises for
"clean source code" but pays in registry-source drift forever.
The inline-pragma approach makes the violation visible at every
read of the file, which is exactly the right place for a "this
needs refactoring" reminder.

### Scope-trim decision (sprint planning lesson)

The original /autoplan plan called for v3.2.116 to be the full
infra→DB leak removal + new `/edge/internal/auth/identity-resolve`
endpoint with bearer JWKS re-verify + cold-boot contract. Token
budget + complexity drove a mid-sprint scope split:

- v3.2.116 ships only the engine table preflight piece (the
  smaller, lower-risk Q5+Q6 work)
- v3.2.117 ships the rule + lint + grandfathered legacy sites
- The actual leak refactor moves to v3.2.118+

This is a worse outcome than the original plan but a better outcome
than "try to do everything, ship something half-broken at the end
of the session." The scope-trim discipline:

1. Identify the smallest piece that's still net-positive on its own
2. Ship that piece end-to-end (commit + merge + sync + ArgoCD
   verify), then decide whether to keep going
3. Use the rule + grandfathering pattern to "lock state and prevent
   regression" even when the cleanup is deferred

### Anti-patterns we avoided

- **Shipping the lint without grandfathering** would have made the
  6 known leak sites red on every CI run, blocking any PR until
  the refactor landed. That couples completely-unrelated work to
  the refactor schedule. Grandfathering decouples them.
- **Skipping the lint because "we will add it after the refactor"**
  would have left no mechanical check for new leaks during the
  refactor window. Lint-first + grandfathered + refactor later is
  the right ordering when the refactor is a multi-sprint effort.
- **Making the lint Node/AST-based** to handle the multi-line
  bypass would have added a build-step dependency to the Ship
  Gate (currently pure bash). Awk is everywhere; the awk
  collapser handles the common case; the rare 3-line case is a
  documented limitation.

### Future work (deferred to v3.2.118+)

The 6 grandfathered sites all carry an inline pragma
`// lint-allow: infra-talks-to-edge-only v3.2.118+ refactor target`.
Each refactor target is to replace the DB import with an S2S call
to a new `/edge/internal/*` endpoint:

- `infra/middleware/auth.js:2` — DB ops (user lookup / JIT /
  banned audit) → `POST /edge/internal/auth/identity-resolve`
  with bearer token in body; edge re-verifies token via JWKS
- `infra/middleware/access-check.js:32` and
  `infra/routes/auth-session.js:12` — `resolveAuthModeAsync` →
  `GET /edge/internal/system/auth-mode` (or bundled into
  identity-resolve response for the per-request path)
- `index-infra.js:24, 154, 288` — boot pool wiring → S2S
  `GET /edge/health/pool-state` per request, fail-closed for
  protected routes when edge unreachable

Reference design lives in
`~/.claude/plans/scalable-wishing-harp.md` (the autoplan-revised
version, after Eng dual-voice round 4 absorbs).

## §81 — Cache strategy after collapsing the infra→DB leak (2026-05-15, v3.2.118)

v3.2.117 left 6 grandfathered DB imports in `docker-api/src/infra/`.
v3.2.118 removed them and routed each call through edge S2S. The
refactor forced three cache-vs-direct decisions worth recording so
the next person doesn't have to re-derive them.

### Direct S2S vs cache: per call site

Three control-plane reads happen at the infra→edge boundary:

1. **Identity (auth.js — every authenticated request)**: per-request,
   hot path, ~1k QPS worst case in production. Cached `_userCache`
   30s per-`sub`. Decision: keep. The window is the same as v3.2.117;
   the freshly-banned-user revocation latency does not regress.
2. **Auth mode (access-check.js + auth-session.js /diagnostics)**:
   per-request for access-check, per-call for /diagnostics. NOT
   cached. Decision: direct S2S. Auth mode flips rarely (manual
   admin action) and the resolve call inside edge already reads
   `_resolvedAuthMode` in-memory; the round-trip is cheap.
3. **Pool state (pool-gate — every /api/ request)**: per-request,
   blocks every /api/ call until edge responds. Cached 5s positive /
   1s negative in `infra/lib/pool-state-cache.js`. Decision: cache.

The 5s pool-state cache is the only new cache layer. CEO + Eng
dual-voice initially recommended "no cache, prefer direct S2S," but
that recommendation pre-dated the realization that pool-gate runs
on every /api/ request — adding ~5-50ms latency per request to a
control-plane endpoint that flips state once per setup-wizard run
is the wrong trade. The 5s window matches the operator-perceived
latency for setup→ready transitions.

### The `_userCache` (auth.js) is intentionally preserved

Pre-v3.2.118: `_userCache` cached the DB row keyed by `sub`. 30s TTL.
Banned users were intentionally NOT cached (so admin unban
propagates on the next request).

Post-v3.2.118: same cache, same TTL, same key. The CHANGE is what
the cache miss does — it now calls edge S2S instead of querying the
pool directly. Same semantics, same revocation window. Cache hit
metrics (`hits`/`misses`/`evictions`/`size`) are exposed via
`getCacheMetrics()` for the /health diagnostic surface.

### Fail-closed contract for edge unreachable

When edge S2S is unreachable, the infra-side contract is:

- **`/health`**: HTTP 200 with `edge_unreachable: true`,
  `hint: 'edge_unreachable'`, `db: 'unknown'`. K8s readiness probe
  must NOT flap on edge outages — that would cascade infra restarts
  into a stop-the-world.
- **Protected `/api/*` routes (after pool-gate)**: HTTP 503 with
  `code: 'EDGE_UNREACHABLE'` and `details.hint_code: 'edge_unreachable'`.
  Clients retry with backoff; setup wizard surfaces the hint so the
  operator can diagnose the cluster-internal routing.
- **Setup `/api/setup/*` routes**: HTTP 200 always. The wizard MUST
  remain reachable during cold boot so an operator can configure
  the DB before edge is reachable. (Setup endpoints bypass pool-gate
  entirely; they forward directly to edge — if edge is unreachable,
  the underlying forwarding proxy returns its own 502, but the
  pool-gate doesn't get a chance to over-gate them.)

### Cold-boot contract for k8s readiness

Pre-v3.2.118 infra wrapped its entire middleware chain in
`initializeFromConfig().then(...)`, which meant the infra pod would
not call `app.listen()` until the DB pool was either configured or
explicitly null. In setup-mode (no DB credentials yet), this path
ran fast — but it coupled infra startup to edge readiness, since
`initializeFromConfig` lived in the same `edge/db.js` module.

Post-v3.2.118: infra `app.listen()` runs immediately at boot.
Middleware and routes are mounted synchronously at module load.
Edge readiness is NOT a precondition — `detectAuthMode(null, null)`
runs in-process (env-based fallback only) and the pool-state cache
populates on first request.

This means k8s readiness flips green as soon as infra's port is
listening, even if edge is still spinning up. The first /api/
request after boot does an extra S2S round-trip to populate the
pool-state cache (~5-50ms one-time cost), but subsequent requests
within the 5s window hit cache.

### Surface area that did NOT make it into v3.2.118

The original `scalable-wishing-harp` Item 1 spec included
**JWKS-verify-at-edge** as a security MUST — edge would re-verify
the OIDC access token via Keycloak JWKS instead of trusting infra-
supplied claims. This was deferred to v3.2.119+ because:

- The current OIDC flow is session-based (`express-openid-connect`
  middleware verifies the ID token during the OIDC callback and
  stores claims in the session cookie). There is no raw access
  token being passed across the S2S boundary today.
- Adding bearer-mode OIDC would be a separate architectural change
  (session → bearer), not a "just verify the same token at edge"
  refactor.
- The S2S key already provides one trust boundary; pushing JWKS
  to edge is defense-in-depth, not a strict-new-boundary fix.
- AIRGAP constraints forbid new npm deps, so a JWKS client would
  need to be hand-rolled against Node's `crypto.createPublicKey`
  JWK importer + manual `kid`-rotation handling — a non-trivial
  amount of careful code best landed in its own session.

The deferral is tracked in `project_v32118_followup_candidates.md`
under "JWKS-verify-at-edge (v3.2.119+)".

## §82 — Realigning a scope column onto the shared ownership model (2026-05-16, v3.2.119)

**Problem.** `user_templates` carried its own ownership notion through
`user_id`, while every other ownership-bearing table (`hierarchy_nodes`,
`transformers`) used `owner_id` and the shared `applyOwnerChange`
service. Adding an admin "reassign owner" path for templates meant a
choice: bolt a `user_id`-keyed one-off endpoint on (small diff, permanent
two-model split) or realign onto `owner_id` (larger blast radius, zero
debt). The second was chosen — the marginal endpoint would have
entrenched a divergence every future ownership change has to remember.

**Migration shape under operator-mode.** The realign is a column
rename in spirit, but a literal `RENAME COLUMN` is a structural change
with no runtime safety net: an operator account without ALTER skips it
silently and every templates query then references a missing column.
The additive path — `ADD COLUMN owner_id` + idempotent
`UPDATE owner_id = user_id WHERE owner_id IS NULL AND user_id IS NOT
NULL` backfill + new composite index, all wrapped so a skip increments
`skippedSteps` and holds the version bump — is the only shape that keeps
boot alive on a CRUD-only account. `user_id` is left in place
read-only; dropping it is a DBA action, not an app migration. Lesson:
when you "rename" a column the codebase reads on every request, the
safe encoding is always additive + backfill + a DBA-owned drop, never a
single ALTER.

**The residual hard dependency is real, not theoretical.** Because the
scope column itself flips to `owner_id`, an operator-mode boot that
skips the ADD COLUMN leaves the feature 500-ing (errno 1054) with no
user-facing hint. This is *acceptable only because* the
`migrations-registry` entry is `severity:'critical'` and the
`schema_status` surface is the documented detection path (CLAUDE.md
§6.5a). If you realign a scope column, the registry guard column +
guard index entries are not optional polish — they are the only thing
that turns a silent runtime break into an operator-visible `failed`.
Operator runbook: a `failed` `schema_status` naming
`user_templates_owner_id_backfill` means "DBA must run the ADD COLUMN +
backfill + index manually" — there is no serializer net for a missing
column the way there is for a nullable one.

**Reuse assumptions hide correctness bugs.** The plan said "reuse
`TransferOwnerDialog`". It encoded two semantics from its original
domain — owners must be admin/editor, and a Shared(null) option — both
*wrong* for templates (the import-mismatch fix usually reassigns to a
regular user; templates have no shared pool, so null 400s). Direct
reuse would have shipped a dialog that cannot fix the bug it exists
for. Generalising with two defaulted opt props (`allowShared`,
`eligibleRoles`) kept one component and backward compatibility. Lesson:
"reuse component X" in a plan is a hypothesis about X's embedded
semantics; verify them against the new domain before trusting the
reuse, especially for permission/role-shaped props.

Followups (DBA `DROP COLUMN user_id`, import-time owner auto-stamp as
the 治本 to this PR's admin-reassign 治標, CLOUD/Supabase parity moot
under deprecation) tracked in
`project_v32119_followup_candidates.md`.

## §83 — Server-side owner-name enrichment pattern (2026-05-18, v3.2.120)

**Symptom.** Non-admin (editor/user) saw a raw `owner_id` UUID on
`/templates`; admin saw the real name. The frontend resolved the id by
calling the admin-only `/api/users` directory endpoint, ate the 403
silently, and fell back to the UUID.

**Decision — where to resolve.** Not a new endpoint, not the dto-mapper.
A new `createCrudRoutes` opt `resolveOwnerName: '<col>'` enriches each row
*after* `parseRows`, inside the route handler, reusing the handler's
already-leased ro connection. Rationale, in order:

1. **`requireAuth`, not `requireAdmin`.** The data exposed is the display
   name of an owner whose row the caller can *already* see (templates are
   view-all by the v3.2.119 Q3 decision, payload visible by Q4). The
   owner's name is strictly less sensitive than the payload already on
   the wire. The full user *directory* stays admin-only — that boundary
   is untouched; only the names of ids already in the result set are
   resolved.
2. **Bounded, but not zero-signal — be precise about the claim.** The
   `WHERE id IN (...)` list is built from the distinct non-null owner ids
   of rows the query already returned — not fed *directly* from client
   input. But `owner_id` is in `filterableColumns`, so a caller can
   client-*select* indirectly: `?owner_id=<uuid>` returns that user's
   templates (if any) and thus resolves their display name in one
   round-trip. A caller therefore CAN probe "does UUID X own ≥1
   template, and what is their name" — but CANNOT resolve users with
   zero templates, and cannot dump the directory. The exposure is
   bounded to users-with-templates and is exactly as wide as the
   view-all template list (which already returns every `owner_id`).
   The earlier "no enumeration vector" framing was overstated; the
   accurate statement is "bounded to users-with-templates, no wider than
   the pre-existing Q3 view-all surface". Tracked MEDIUM in the v3.2.120
   followup ledger (security-reviewer), folded under the v3.2.119
   Q3/Q4-deferred visibility-policy note.
3. **After `parseRows`, not in the dto-mapper.** `owner_name` is derived,
   cross-table, and async; `mapRowsFromDb` is a pure synchronous
   row-shape transformer with no DB access. Keeping enrichment in the
   handler leaves the dto-mapper registry untouched and the operation
   idempotent (deterministic overwrite of a non-column field — safe under
   React Query refetch and list+detail double-map).
4. **Name only, never email.** Corporate-compliance environment;
   `display_name || kc_username || 'Unknown'`. Email is a separate PII
   tier and is never selected. The opt assumes the column is a
   `users.id` FK — documented so the generalisation target
   (`hierarchy_nodes` / `transformers`, same owner model) is safe but
   intentionally deferred (scope discipline; one reported page).

**Frontend corollary.** Removing the only consumer of an admin-gated
fetch also removed its import — a silent-403 + fallback-to-raw-id
anti-pattern is best deleted at the source, not patched with a
non-admin branch. The CLOUD/Supabase `profiles` path is left intact
(not admin-gated, deprecating) and the row mapper prefers the
server value, then the CLOUD map, never the raw UUID.

Followup (`hierarchy_nodes` / `transformers` owner-name parity) tracked
in the v3.2.120 followup ledger; relates to the existing "transformer
owner badge" MED.

## §84 — k3d-local cross-subdomain self-signed cert: Chrome flag beats CA install (2026-05-27)

### Symptom

`https://zonea-fmb-web.localhost/login` renders the Local Auth password
form even though backend `auth_mode = keycloak`. Hard reload does not
help. Cluster pods all Running, /health 200, cert SAN covers both web +
api hosts (same fingerprint), `/api/auth/mode` returns
`{"data":{"mode":"keycloak"}}` from curl. Istio access log shows zero
`/api/auth/mode` hits from the affected browser session — the fetch is
being silently blocked client-side.

Past occurrences: this is the v3.2.30 LESSON-3 / v3.2.28 port-forward
gotcha recurring after a k3d cluster restart. `auth-mode.ts` defaults
to `local` when the cross-subdomain fetch fails; cross-subdomain fetch
fails when the API host's self-signed cert has not been independently
accepted by the browser (top-level navigation to the web host prompts
a cert warning the user clicks through, but XHR/fetch to the api host
just throws without a UI prompt).

### Root cause shape

- One TLS cert covers `*.localhost` via SAN (web + api + edge).
- Browsers track cert exceptions per-origin, not per-cert-fingerprint.
- Accepting the web host's cert via UI does NOT auto-accept the api
  host for AJAX/fetch — only for top-level navigation.
- Result: `/api/auth/mode` fetch from the SPA silently fails, the
  frontend falls back to `_mode = 'local'`, and the password form
  renders.

### Three operational fixes, ranked by friction

1. **Chrome flag `unsafely-treat-insecure-origin-as-secure`** (current
   recommended). Open `chrome://flags/#unsafely-treat-insecure-origin-as-secure`,
   set Enabled, paste the comma-separated allowlist
   (`https://zonea-fmb-web.localhost,https://zonea-fmb-api.localhost,https://zonea-fmb-edge.localhost,https://zonetest-fmb-web.localhost,https://zonetest-fmb-api.localhost,https://zonetest-fmb-edge.localhost`),
   Relaunch. Survives cluster restarts and cert regenerations. Per
   browser profile, one-time. Edge has the same flag at
   `edge://flags/#unsafely-treat-insecure-origin-as-secure`. Firefox
   has no equivalent — Firefox users must install the CA via
   `scripts/install-istio-ca.sh`.

   Chrome 148+ removed the older `allow-insecure-localhost` flag;
   `unsafely-treat-insecure-origin-as-secure` is the supported
   successor with an explicit per-origin allowlist.

2. **`scripts/install-istio-ca.sh`** (WSL emits PowerShell snippet for
   Windows trust store; native Linux installs into
   `/usr/local/share/ca-certificates/` + Chrome NSS DB
   `~/.pki/nssdb`). Requires admin (UAC on Windows). Must re-run when
   `generate-certs.sh` re-issues the cert (fingerprint drift), which
   `setup.sh` already prints a red drift warning for at v3.2.31 REV-LOW.

3. **Architectural collapse to single-origin** (not done). Move `/api/*`
   under the same host as the SPA via Istio VirtualService path-based
   routing, eliminating the cross-subdomain fetch entirely. Top-level
   navigation prompt then covers all subsequent fetches. Mid-effort;
   defer until pain warrants it.

### Cookie chain caveat

Even after the cert side is solved, `/api/auth/callback` will return
`auth_verification cookie not found` if the user retains a stale tab
with a callback URL from a prior session (the transaction cookie set
during `/api/auth/sso-login` is expired or scoped to a different
context, e.g. after a Chrome relaunch). Fix: close all
`zonea-fmb-*.localhost` tabs, start fresh at `/login`, click SSO
button, complete KC login. If still failing, clear cookies for both
web and api hosts via `chrome://settings/cookies/detail?site=...`.

### Why the Chrome-flag route is preferred over CA install

CA install is the "correct" engineering answer but recurs on every
cert regeneration (`setup.sh` re-runs reissue the cert by default);
the Chrome flag is fingerprint-independent and survives indefinitely
without re-elevation. Idempotency in `generate-certs.sh` would close
the gap on the CA-install side but requires implementation work; the
Chrome-flag route is the zero-touch shortcut while that work is
outstanding.

Related history: see archived `project_v3230_shipped.md`
(LESSON-3 cross-subdomain accept-cert gotcha, original ship-confirm)
and `project_v3228_candidates.md` (port-forward variant).

## §85 — Single-select duplicate-value alias round-trip: label-keyed sidecar column, not payload (2026-06-03, v3.2.126)

### Problem

A single-`select` data-entry field whose options have different labels but
the SAME `option_value` (a legitimate alias — two display names, one stored
code) failed two ways: Radix `<Select>`/`<SelectValue>` keys display by value,
so two same-value items rendered MERGED labels in the trigger and
double-highlighted both rows; and on reload the form could not restore WHICH
alias the user picked, because the form value (`values[field_key]`, saved to
`user_templates.payload`) is just the value string — the label choice was lost
the moment it was stored.

### The information-theoretic floor (the load-bearing insight)

To restore "which of two same-value aliases was chosen," ONE extra bit must be
persisted somewhere. The form value alone cannot carry it. Given the hard
constraints — `payload` byte-frozen (downstream `buildTransformerPayload` /
outputs / export read it), no `localStorage` — that bit has exactly one legal
home: a NEW column. If even that is refused, round-trip is provably impossible
and deterministic first-match is the mathematically optimal answer (and is what
native `<select>` + react-select + MUI all do — none guarantee round-trip on
duplicate values; the industry norm is "values must be unique").

So the design question is never "how do we render it" — it is "where does the
disambiguating bit live, and what is it." Don't argue rendering until that is
settled.

### Decisions

1. **Disambiguator = the LABEL, not the option id.** The aliases differ only by
   label, so the label IS the semantic identity. Storing the option `id` looks
   tighter but a blueprint re-sync that deletes+recreates option rows
   regenerates every id → all stored metadata goes stale for no semantic
   reason. The label survives re-sync; it only "goes stale" when the chosen
   alias genuinely no longer exists, which is exactly when a stale marker
   SHOULD fire. `value` already lives in payload, so the metadata stores only
   the label — lean.

2. **Separate nullable column, never inside payload.** New
   `user_templates.field_option_selection TEXT NULL` holding
   `{field_key: chosen_label}`. payload stays identical → every value consumer
   is untouched. Same row as the template, so load/save add zero queries, no
   join, no N+1.

3. **Sparse: NULL when no aliases.** Only fields whose options actually have
   duplicate values get an entry; a template with no aliased fields stores
   `NULL`, not `{}`. One memoized `hasDuplicateValues` pass (`option-dups.ts`)
   drives three things from a single source: force-combobox in the picker,
   the sparse save filter, and the blueprint-editor annotation.

4. **Render: force the controlled combobox on collision.** When option values
   collide, `SearchableSelect` renders its own combobox branch (own Check, own
   trigger label) regardless of threshold, side-stepping Radix's value-keyed
   `<SelectValue>`/`<SelectItem>` entirely. Identity match uses a composite
   `value‖label` key scoped to the current value-group; metadata is a DISPLAY
   HINT only and can never override the real payload value.

### Gotchas that bit during review (both Codex and security-reviewer caught these)

- **The null-key write trap (the dangerous one).** `JSON.stringify({k: null})`
  KEEPS the key. The generic `createCrudRoutes` turns every body key into an
  INSERT/UPDATE column. So sending `field_option_selection: null` on every save
  means that in operator-mode — where the `ADD COLUMN` migration warn-skipped
  because the DB user lacks DDL grant — EVERY template save 500s with
  `ER_BAD_FIELD_ERROR`, not just aliased ones. Fix: OMIT the key entirely when
  the meta is null (`...(meta != null ? { field_option_selection: meta } : {})`).
  Lesson: an additive nullable column is only safe to send when non-null if the
  write path blindly maps keys→columns and the column may legitimately be absent.

- **First-match must mark exactly one row.** When `selectedKey` is absent
  (legacy template, default/autofill value, or operator-mode without the
  column), the forced combobox must mark only the FIRST value-match
  (`i === firstValueMatchIndex`), not `value === o.value` — the latter
  re-creates the original double-highlight for any aliased field opened without
  metadata, which is the common first-render case.

- **A label can repeat across DIFFERENT values.** Keying identity on bare label
  lets a stale label resolve onto a different value's option (wrong-value
  display). Scope the key to the value-group: composite `value‖label`, and only
  pass `selectedKey` when the label actually resolves for the CURRENT value.

### Cleanup is free if you design for self-heal

No explicit purge needed: `buildSelectionMeta` filters by current
`dupFieldKeys ∩ validKeys` on every save, so renamed/deleted fields and
no-longer-aliased fields drop out automatically the next time the template is
saved. Stale (un-resolvable) entries degrade to first-match + a visible amber
marker, never an error — because the metadata never touches the real value.

### Operator-mode posture

Migration follows the proven additive-column pattern (information_schema probe
→ ALTER → errno-1142 warn-skip; registry entry `recover`/`warning`, not
`critical`, because absence merely degrades to first-match). The risky part is
the WRITE path, not the read — see the null-key trap above.

Full design + plan: `docs/superpowers/specs/2026-06-03-select-alias-roundtrip-design.md`,
`docs/superpowers/plans/2026-06-03-select-alias-roundtrip.md`.

## §86 — Computed field values: structured rules over a formula library, variant-scoped, stale-marker reused (2026-06-04, v3.2.127)

### The decision that shaped everything: no expression engine

The feature is "derive a field's value from other fields" — the textbook
reach for an expression/formula library (`expr-eval`, `mathjs`,
`hyperformula`). We surveyed them and rejected all three:

- `expr-eval` — CVE-2025-12735, a sandbox-escape RCE in the evaluator.
- `mathjs` — documented history of RCE via its evaluation surface.
- `hyperformula` — GPL, license-incompatible with the product.

Any of them would also be a **new npm dependency**, which AIRGAP treats as a
CRITICAL blocking issue. So the engine is a **fixed op-set** instead:
`concat` / `transform` / `arithmetic` / `lookup`, each a pure function over
already-resolved field values, with type-aware coercion. No parser, no
`eval`, no `new Function`, no dynamic code path of any kind — Ship Gate
Step 13 (forbid-eval) stays clean by construction, not by allowlist.

**Lesson:** when the requirement *sounds* like "let users write expressions"
but the real cases are a handful of shapes (join strings, upper/lower, a sum,
a table lookup), enumerate the shapes. A closed op-set is safer, smaller, and
dependency-free than an open evaluator — and you never inherit the evaluator's
CVE stream. Reach for an expression engine only when the op-set genuinely
can't be closed.

### Why the rule lives on the variant, not the blueprint field

First instinct was to add `compute_rule` to `blueprint_fields` (the field
*is* computed, so put it on the field). That's wrong for this product: the
Variant Policy Engine's whole point is that the same field behaves
differently per variant — variant A locks it, variant B autofills it, variant
C computes it. The rule is a **policy on (variant, field)**, exactly like
`lock` / `hide` / `autofill` already are. So `compute` is just the 4th
`action` on `variant_overrides`, and the rule rides on
`variant_overrides.compute_rule`. This also means a field with no override on
a given variant is a plain field there — no special-casing.

**Lesson:** put derived-behavior config where the behavior is *scoped*, not
where the data structurally "belongs". If a sibling feature (here: lock/hide/
autofill) already lives at that scope, match it — the storage, the route, and
the UI all compose for free.

### Degrade, never throw — broken rules are a render state

Sources get renamed, rules form cycles. The interpreter never throws on these:
`compute-graph.ts` does a Kahn topological sort and returns `{order, broken}`
where `broken` carries `cycle` / `missing_source` reasons. A broken field
becomes a **plain editable input** + a "Rule unavailable" marker so the
operator is never blocked — and crucially this must override `isLocked` too
(a non-overridable broken rule would otherwise stay disabled; the broken
branch neutralizes the compute lock but still respects the page-level
read-only mode). Surfaced on both ends: admin sees a cycle/missing badge in
the Variant Policy list + a `field_key`-rename warning in FieldEditor.

### Reusing v3.2.126's sparse-override machinery (and inheriting its one wart)

The "user overrode a computed value" persistence is the same shape as
`field_option_selection` (§85): a sparse `{field_key: true}` map in a nullable
column, omit-the-key-when-empty so operator-mode DBs without the column keep
saving. `buildComputeOverrideMeta` / `restoreComputeOverrideMeta` /
`isComputeStale` mirror the selection helpers one-for-one.

The omit-key choice carries a known trade-off, flagged again by Codex here:
on a patch-style PUT, clearing *all* divergences omits the column, so the old
DB value survives and a reload re-marks the field diverged (visible effect is
mild — field shows editable-with-computed-value instead of locked-Auto; the
value itself is correct, no data loss). The naive fix (always send `null`)
reintroduces the operator-mode column-missing 500 that §85 deliberately
avoided. Both columns share this; a proper fix needs a backend column-exists
gate and should be done for both at once — deferred, not patched piecemeal.

**Lesson:** when you reuse a sibling's persistence pattern, you inherit its
accepted trade-offs too. Name them explicitly in the followup ledger so the
next person sees it's a *shared, conscious* limitation, not a fresh bug.

### The "no half-built UI" discipline

Six end-user render states (Auto / Unlock / unlocked-editable / Outdated+
Recompute / Reset-to-computed / broken-degrade) were specced as a single
contract and reviewed for completeness by a dedicated reviewer subagent
*before* the ship gate — which is how the broken+non-overridable "field stays
disabled" gap (B1) and a latent locked-field tooltip crash got caught. A
state machine with one missing branch reads as "done" in a happy-path demo;
enumerate every state and assert the representative ones.

Full design + plan: `docs/superpowers/specs/2026-06-04-variant-compute-field-design.md`,
`docs/superpowers/plans/2026-06-04-variant-compute-field.md`.

## §87 — Operator-mode-safe sparse-column writes: gate by actual columns, key the cache by database (2026-06-04, v3.2.128)

§85/§86 shipped two sparse nullable columns (`field_option_selection`,
`computed_field_overrides`) with **omit-key-when-null** on save — the cheap
way to keep operator-mode DBs (that skipped the `ADD COLUMN` migration) from
500ing on a write to a non-existent column. The trade-off: a patch-style PUT
never clears the column, so resetting all overrides leaves stale data. The
proper fix needed to *send* the null without bringing back the 500.

### The fix: probe the real columns, drop the absent ones
`createCrudRoutes` now filters write keys against the table's actual column
set (`SELECT COLUMN_NAME FROM information_schema.COLUMNS WHERE TABLE_SCHEMA =
DATABASE() AND TABLE_NAME = ?`). A key for a genuinely-missing column is
dropped (operator-mode degrade); a probe that can't resolve the set keeps
**every** key, so normal-mode writes are byte-identical — the gate only ever
*removes* a column it positively confirmed is missing, never guesses one in.
This generalizes operator-mode write safety to every CRUD table, and lets the
frontend always send the sparse keys (null = clear) without special-casing.

### The bug the first version had: cache key must include the database
The column set is cached (one probe per table, then reused — columns are
stable after boot-time migrations). First version keyed the cache by physical
table name alone. **Codex caught that this is wrong under dynamic pools /
connection-profile switches:** two different databases can share a table name
but sit at different migration states. Table-name-only key →
- probe an upgraded DB first → "column exists" cached → a write to an older
  DB keeps the key → the 500 the gate exists to prevent;
- probe an older DB first → "column missing" cached → a write to an upgraded
  DB silently drops the override column → the stale-data bug comes back.

Fix: key by `${DATABASE()}::${table}`, where the db name is queried off the
**leased connection itself** (`SELECT DATABASE()`), not read from a config
object — so the key reflects the schema the write will actually hit, even
after a `req.body.db` switch.

**Lesson:** any process-wide cache of *schema-shaped* facts is only valid for
one database. The moment the app can point the same code at more than one DB
(dynamic pools, profile switch, per-request `db`), the cache key must carry
the database identity — and that identity must come from the live connection,
not from what you think the connection is bound to. A schema cache keyed
without the DB is a latent cross-tenant correctness bug that only shows up
when two DBs are at different migration states.

## §88 — Cascading dependent options: a "filter B by A" feature has a huge edge-space; let adversarial review converge it (2026-06-04, v3.2.129)

The feature is small to state ("dependent picklist: A's value narrows B's
options") and the happy path is ~20 lines. But it took **3 review rounds and 9
fixed findings** to make correct. The combinatorial surface is the lesson.

### Where the bugs lived (none in the happy path)
- **Operator-mode writes.** Adding `depends_on_field_key` to the admin form
  made every field-edit PUT carry the new column. The custom
  `blueprint_fields` PUT didn't use the v3.2.128 column gate → 500 in
  operator-mode. Then the *fix* (reading the old value to detect a
  parent-change) named the absent column in a `SELECT` → reintroduced the same
  500, this time for **every** field edit. Lesson: when you touch a table that
  has an operator-mode-optional column, every read AND write that names it must
  be gated — and a test that "simulates a missing column" by making it
  *optional* in a regex does NOT catch a DB that *throws* on the unknown column.
  Make the mock throw.
- **`'' ↔ null` mismatch.** The frontend always sends `depends_on_field_key: ''`
  for a never-parented field; the DB stores `null`. `'' !== null` made a
  label-only edit look like a parent change and wiped option tags. Any
  "did this field change?" comparison against a raw DB row must normalize the
  nullable-string Y-pattern (`'' ↔ null`) on BOTH sides first.
- **Stale derived state.** The cascade phase mutates `field.options` to the
  filtered list; a later consumer (live-clear) that read the mutated list
  cleared values that had just become valid. Lesson: if you mutate a derived
  field in place, stash the original (`cascadeAllOptions`) for consumers that
  need the unfiltered truth.
- **Authoring footguns.** Self-as-parent (exclude by **id**, not key, because a
  rename desyncs the key), cycles A→B/B→A (exclude transitive descendants in the
  picker + degrade-don't-deadlock at runtime), stale tags on re-parent (reset
  server-side), orphan config on type-change (clear the parent).
- **Composition with the prior feature.** A computed parent that the operator
  overrode must cascade against the *operator's* value, not the auto value.

### The meta-lesson: convergence via independent adversaries
Each review round found bugs the previous round's *fixes* introduced. That's
not failure — it's the process working. A feature whose correctness lives
entirely in edge cases cannot be one-shot; it needs an adversary that re-reads
the whole diff after each fix. When the primary reviewer (Codex) hit its usage
cap mid-round, escalating to a second independent reviewer (Claude
`code-reviewer`) immediately surfaced a CRITICAL the fixes had introduced. Two
independent review engines beat one run twice. Budget for N rounds on
edge-heavy features; declare convergence only when a fresh full-diff read finds
nothing blocking — not when the happy-path tests pass.

### What kept it cheap despite the churn
Pure resolver (`resolveCascade`) isolated the core logic with exhaustive unit
tests, so every round's fixes were localized to the wiring, never the algorithm.
Blueprint-level + JSON-array-not-join-table + frontend resolution kept the
schema to two additive columns. Design doc: `docs/superpowers/specs/2026-06-04-cascading-dependent-options-design.md`.

## §89 — "Export/import" is never one path; make round-trips schema-driven, not hard-coded (2026-06-04, v3.2.131)

A column-coverage audit (prompted by "does export/import cover the recent
changes?") found the real shape of the problem: **"export/import" is half a
dozen independent paths**, and only the dynamic one was column-complete.

| Path | Mechanism | New column |
|---|---|---|
| MariaDB SQL export/seed | dynamic `SELECT *` | ✅ auto |
| Blueprint JSON/YAML import | **hard-coded INSERT list** | ❌ dropped |
| Frontend blueprint clone | **hard-coded payload** | ❌ dropped |
| Template save | constructs from UI state | ✅ (explicit by nature) |

So v3.2.126/127/129 each added columns that silently vanished on blueprint
import and clone (cascade config gone after a cross-env move; compute rule gone
after a clone) — even though the SQL path and a round-trip test for *it* were
green. The export side used `SELECT *`, so the data was in the file; the
**import** dropped it.

### The fix that generalizes: derive columns from the schema, not from a list
`buildPortableInsert` builds the INSERT from the table's actual
`information_schema` columns. This is simultaneously:
- **drift-proof** — a new column is in the set automatically, no edit;
- **injection-safe** — a crafted import file can only set columns that *really
  exist* on the table (and these tables carry no privilege/owner column;
  structural id/FK are force-remapped, `created_at` excluded). This is *stronger*
  than a hard-coded list, which can itself drift to reference a renamed column.
Frontend clone gets the same property via spread-and-omit (trusted internal row
→ copy all, drop structural; the v3.2.128 CRUD column gate drops strays).

### Lesson 1: a fix must cover EVERY path, and the test must be schema-driven too
We'd already shipped a round-trip test for the SQL path and *thought* export/import
was covered. It wasn't — the test only exercised one of N paths. The durable
guard is a **schema-driven** fidelity test: it enumerates columns from the DDL,
so adding a column auto-covers it and a path that drops one goes red *without a
test edit*. A per-column test you have to remember to write is the same failure
mode as a per-column INSERT list you have to remember to update.

### Lesson 2: when you start persisting a new column, find everything that *fingerprints* the row
Codex caught that the YAML overwrite's optimistic-lock `computeRevision()` didn't
include the cascade columns. Once overwrite *persisted* them, a concurrent
cascade-only edit no longer bumped the revision → it could be silently
clobbered. Persisting a column isn't just "write it" — every hash/diff/revision/
cache that fingerprints that row must include it, or you open a
lost-update hole. Fix: hash *all* data columns (drift-proof), not a hand-picked
subset.

### Lesson 3: behavior-preservation on a mechanical rewrite
Replacing a hard-coded INSERT (which applied `section ?? 'general'` defaults)
with a dynamic one silently changed sparse imports to store NULL. A "carry more
columns" rewrite still has to carry the *old defaults* too. Diff the old explicit
code for every `??`/coercion before deleting it.

Spec/plan: `docs/superpowers/specs/2026-06-04-roundtrip-column-fidelity-design.md`,
`docs/superpowers/plans/2026-06-04-roundtrip-column-fidelity.md`.

## §90 — Referencing a table cell from a compute rule: a value is a vector, not a scalar (2026-06-04, v3.2.132)

Compute rules (`concat`, `arith`) needed to read from table-type fields. The
catch: a table field's value is a **vector** (rows × columns), not a scalar.
"Reference column X" is under-specified — which of N rows? The fix is a
structured `table_cell` source `{table_key, column_key, row}` where `row` is an
explicit `first`/`last` selector, resolved down to a single scalar before the op
runs. Avoid stringly-typed addressing (e.g. `"table.col"`) — a structured shape
keeps the row selector first-class and validates cleanly.

### Separate two failure classes; they degrade differently
- **Structural failure** (referenced table deleted, value isn't an array,
  unknown column) means the rule itself is broken → degrade the whole rule to
  the existing `broken` state. The author must fix the reference.
- **Data-missing** (empty table, empty cell) is normal end-user input state →
  fall through to each op's *existing* missing-value rule: `concat` is lenient
  (treats it as `''`), `arith` is strict (raises an error). Reusing the per-op
  rule keeps table_cell consistent with plain field references.

### A pre-existing silent-overwrite gap in the shared load path
The v3.2.127 compute load path had a latent bug surfaced by this work: a value
the user had **hand-typed** that wasn't recorded in `computed_field_overrides`
was silently replaced by the computed value on load. The fix is
`reconcileComputedField` with three outcomes — *adopt* (no manual value, take
computed), *insync* (manual equals computed), *protect* (manual differs → keep
the manual value, mark it stale). The compare is **normalization-aware** so a
formatting-only difference doesn't false-trigger a stale marker. This hardened
the **shared** load path, so it protects every compute field, not just
`table_cell`.

### Zero schema change again
Like the cascade work, the table-cell reference lives **inside** the existing
`compute_rule` JSON column — no new column, no migration. It round-trips for
free through the schema-driven `buildPortableInsert` path (see §89): because the
ref is data inside an already-carried column, every export/import path that
carries `compute_rule` carries it too.

## §91 — UI beautification: extract a shared presentational unit, reuse the literal palette, reserve slots for the schema-coupled phase (2026-06-06, v3.2.134)

The `/data-entry` form looked flat (plain cards, tiny titles). The refresh is a
SAAS-style section card: cycling left color accent, a numbered circle, cleaner
header, polished table. Several decisions kept it debt-free and zero-risk.

### Split the visual phase from the schema phase
The mockup bundled two things: pure visual styling (cards, accent, table) AND
two features that need persistence — a per-section **icon** and **description**.
The latter need `blueprint_sections` columns + Schema Builder UI + export/import
round-trip, so they belong in their own plan. Phase 1 ships only CSS, and
`SectionCard` exposes **optional** `icon`/`description` props that render nothing
when absent. Phase 2 fills the props with no restructure — the slot is reserved
without any mock/placeholder.

### Extract the shared unit, don't duplicate the markup
Two surfaces (data-entry's `DynamicFormRenderer` and the template detail view)
both wanted the same accent-card header. Rather than copy the JSX, extract a
single presentational `SectionCard` and let each pass its own body via
`children` + a `contentClassName`. Consistency by construction, not by
convention. The header look changing on the template page is the *point*, not a
regression — both pages now share one source of truth.

### Reuse the literal palette — it's also the Lovable/purge-safe pattern
`SECTION_PALETTE` is an array of **full literal** class strings
(`border-l-blue-500`, …). That single fact buys two guarantees at once:
Tailwind's purge keeps them (they appear verbatim in source), and the Lovable
visual editor can round-trip the className. The anti-pattern is constructing
classes (`` `border-l-${color}-500` ``) — purge drops them and Lovable can't
introspect them. Relocated the constant from `admin/SectionHeader.tsx` to
`src/fmb/lib/section-palette.ts` (re-exported for back-compat) so a non-admin
shared component doesn't import an admin file — kills a layering smell while the
file was open.

### Beautify the shared table at the source, but only the visual layer
`EditableDataGrid` is shared by data-entry and the admin column editor. The user
chose consistency over a variant prop, so the polish (header band, column-header
typography, zebra + hover) went on the component body directly — but strictly on
className. Every handler, the `data-grid-cell` data attributes, the inline
box-shadow selection rings, the fill handle, and clipboard/undo logic were left
byte-identical. "Visual-only" has to be literally true for a shared component, or
you regress a second consumer.

### jsdom can't verify any of this
As in §83/v3.2.133, the payoff (accent visible, table polished, click targets
intact) is layout/visual and invisible to jsdom. Unit tests pin the *structural*
facts (`SectionCard` renders the accent class for an index, shows seq vs icon,
renders description only when present); the real acceptance is a browser pass in
both light and dark mode.

## §92 — A two-layer "config map + per-item override", resolved at render time, with a curated allowlist (2026-06-06, v3.2.136)

Section icons (`/data-entry`) needed to be *meaningful* without forcing an editor to
set every one by hand. The shape that fell out is reusable for any "smart default the
user can override" feature.

### Two layers, resolved at render time — not baked at write time
A section's icon = **per-section override** (a stored name) → **keyword→icon map** →
sequence number. The map lives in `system_settings` (`section_icon_map`, plain JSON),
not in each row. Because resolution happens at render (`resolveSectionIconName` runs in
`DynamicFormRenderer`), an admin editing the map updates *every* non-overridden section
live — no migration, no per-row rewrite. The override is the only thing persisted on the
row; the map is config. That split is why the feature is cheap: the expensive surface
(per-section storage) only carries the rare exception, not the common case.

### Curated allowlist beats dynamic lookup — bundle + AIRGAP + security at once
`icon-map.ts` is 47 **explicit named imports** from lucide-react into a static
`ICON_MAP`. No `import *`, no `lucide[name]` dynamic resolution. One decision buys three
guarantees: tree-shaking keeps the bundle bounded, an AIRGAP/Nexus build can't reference
an unbundled name, and `getIcon(name)` returns `null` for anything off the list — so an
arbitrary string (from a crafted blueprint import) can never resolve to a renderable
component. The allowlist *is* the XSS gate. `resolveSectionIconName` was later hardened
to also gate the override (`ICON_MAP[section.icon]`) so an unknown imported name falls
through to keyword matching instead of silently rendering nothing.

### Abbreviation-safe keyword matching: token length is the signal
Naive substring matching makes `os` match `postgres` and `vm` match `vmware`'s
neighbours. The rule that works: tokenize (camelCase + non-alnum split, lowercase), then
**keywords < 4 chars must equal a whole token**, keywords ≥ 4 may substring-match within
a token; longest keyword wins. The cutoff at 4 is a heuristic for IT abbreviations
(`os`/`db`/`vm`/`dns` are exact-token; `maria`/`database`/`network` are substring). A
plan-internal contradiction surfaced here — a fixture `OS Config → Computer` is wrong
under "longest wins" (`config` is longer → `Settings`). The spec's stated rule was
correct; the *fixture* was the bug. Lesson: when a test contradicts the spec's own
explicit rule, fix the fixture and add a test that *pins the surprising-but-correct*
behavior, don't silently re-rank the algorithm.

### Schema-coupled features must ship the round-trip on day one
Adding two columns is the easy 20%. The other 80%: operator-mode-safe migration
(`recover` policy), API-boundary null normalization, the Schema Builder editing surface,
the System Settings map editor, AND export/import. Per §89, the round-trip was made
schema-driven (`buildPortableInsert` at all three section INSERT sites) so the new
columns — and every future one — travel through JSON + YAML without another hard-coded
column list. A boundary-ingest review caught the JSON path (unlike YAML) not coercing
`icon`/`description` to string-or-null; the fix is a shared coercion so the two paths
can't diverge again.

### jsdom still can't see it
As in §83/§91, the payoff (icon glyph shown, description wrapped, light/dark hierarchy)
is visual. Unit tests pin the structural contract (resolver order, allowlist gating,
`SectionCard` renders icon-vs-seq, description wraps not truncates); browser acceptance
in both modes is the real gate.

## §93 — When "smart auto" needs a config table, push the table into code, not the admin UI (2026-06-06, v3.2.137)

§92 shipped section icons with an admin-editable keyword→icon map in `system_settings`
plus a System Settings editor card. Browser use immediately exposed two faults the design
review missed:

1. **The editor was undiscoverable.** It lived in System Settings, far from where you edit
   sections (the Schema Builder). The user literally couldn't find it. An item's icon
   should be editable *where you edit the item*.
2. **The editable lookup table grows unbounded.** A keyword→icon map starts at ~47 rows;
   to cover more terms someone keeps adding rows, and nobody can tell which row is winning
   or stale. A user-maintained mapping table is a maintenance liability, not a feature.

### The industry pattern (Notion / Linear / Slack / GitHub)
Icon is a **direct property of the item**, chosen via a **searchable picker** — the search
box *is* the keyword→icon mapping (type "database", get the Database glyph), so there is no
separate table to maintain. Where "smart defaults" exist they're a **one-shot suggestion or
a code-level heuristic**, never a persistent admin-edited lookup. The trade is deliberate:
*less* cleverness (a good-enough default) for *more* maintainability (no table to rot).

### The fix: keep the heuristic, move it from DB to code
The auto-resolution stays useful — but the map became a **code constant**
(`DEFAULT_SECTION_ICON_MAP`), dev-maintained, invisible to admins. The user-facing lever is
the **per-section override**, set in-context (the Schema Builder dialog), with the picker's
search handling discovery and a live preview showing the resolved glyph before save. The
long tail is handled by overriding the few the heuristic gets wrong — cheaper than growing
and policing a global table. Net change was mostly **deletion** (the card, the hook, the
DB storage, a public-settings exposure), which is the tell that the original design had an
unnecessary moving part.

### Lesson
When a "smart auto" feature seems to need a configuration table, ask whether the table
belongs to *developers* (curate a sane default in code) or to *users* (a real per-install
need). If it's the former masquerading as the latter, you've built an admin chore. Default
to: code heuristic for the common case + direct per-item override for the exceptions. Don't
ship a user-editable lookup table unless installs genuinely diverge in a way only they can
resolve.

## §94 — One filename contract, two runtimes: pin a duplicated impl with a shared parity fixture (2026-06-06, v3.2.141)

Export filenames had drifted across 11 download sites — mixed separators (`_` vs `-`),
timestamps that were sometimes `Date.now()` milliseconds, sometimes an ISO date, sometimes
absent, inconsistent component order, and one name hard-coded with no entity or date
(`privileges-audit.csv`). The fix was a single canonical scheme
`<kind>_<entity>_<YYYYMMDD-HHMMSS>.<ext>` so a download is self-describing (*what / which / when*)
and same-day re-exports never collide.

### The real constraint: the helper must live in two runtimes
The frontend (TS bundle) and the `docker-api` backend (separate Node package) cannot import
each other. A "shared utility" is therefore physically **two implementations**. The naive
outcomes are both tech debt: one impl that only half the sites can call, or two impls that
silently diverge over time.

### The pattern: duplicate the code, single-source the *contract*
- Two thin impls with identical logic: `src/platform/lib/export-filename.ts` and
  `docker-api/src/shared/lib/export-filename.js`.
- One JSON **parity fixture** of `{input → expected}` rows (including edge cases: empty entity,
  leading-dot ext, filesystem-unsafe chars, CJK), read by *both* a vitest test and a `node:test`
  test. The date is passed as explicit local-time constructor args, so the expected stamp is
  identical regardless of the machine's timezone.
- Drift is now a **test failure**, not a latent bug. The fixture, not either impl, is the source
  of truth.

### Two smaller calls worth recording
- **Unicode-aware slug** (`[^\p{L}\p{N}]+` → `-`) instead of ASCII-only — a CJK blueprint name
  survives as itself rather than collapsing to a generic fallback. The one place that needs pure
  ASCII (an HTTP `Content-Disposition` header) keeps its existing RFC 5987 dual encoding (ASCII
  `filename=` + percent-encoded `filename*`), now fed the canonical base name.
- **No global product/install prefix.** Distinguishability across installs comes from the
  `entity` already carrying the DB/schema name (runtime config), so the filename stays §8-safe
  (no hard-coded product name) without an extra config surface.

### Lesson
When a helper must exist in two non-importing runtimes, don't pretend it's one module and don't
let two copies rot. Duplicate the *code*, single-source the *behavior* with a shared fixture both
sides assert against. The test is the contract.

## §95 — UI beautification: CSS token layer, dark sidebar, and status-shared-via-useQueries (2026-06-07, v3.2.143)

### 1. Retuning global CSS-variable tokens has site-wide blast radius

Adjusting `--background`, `--foreground`, `--card`, `--sidebar-*` etc. in `index.css` is the
cheapest lever to shift the whole app's visual character — one file, zero component changes.
But the token layer is site-wide: every page, including admin, setup, and login, picks up the
change. Verify light + dark in all three surfaces (main app, admin/settings, setup wizard) before
shipping. A palette that looks right on Data Entry can still break contrast on the Privileges tab
or the First Setup wizard.

### 2. Dark sidebar in light mode — use `--sidebar-*` tokens, not the global `accent`

A dark sidebar in light mode is achieved by overriding `--sidebar-background`, `--sidebar-foreground`,
`--sidebar-border`, and related tokens in `:root` (not in `.dark`) — no structural JSX change
needed. The critical coupling: nav active and hover classes must reference `sidebar-accent` /
`sidebar-accent-foreground`, not the global `accent` / `accent-foreground`. If they use the global
token the active pill inherits the *light-mode* accent colour and the contrast collapses against the
dark sidebar background. Audit every `bg-accent` / `text-accent-foreground` usage inside the sidebar
component when switching its background.

### 3. Status computed once via `useQueries`, shared by column and filter chips — stable memo dep

When a page both *displays* a derived value per row (Status column) and *counts* by that value
(filter chip badges), compute it once at the page level rather than re-deriving inside each child.
`useQueries` with the exact same `queryKey` array (e.g. `['blueprint_fields', id]`) and fetcher
as `useBlueprintFields` shares the React Query cache — no duplicate network requests and no drift
between what the column shows and what the chip counts. One subtlety: `useQueries` returns a
**fresh array reference** every render even when the underlying data has not changed. A `useMemo`
that lists `fieldQueries` as a dependency will recompute on every render. Use a cheap
content-stable proxy (e.g. map each query's `data.length` to a joined string) as the memo
dependency instead — recompute only when field data actually changes, not on every render cycle.

## §96 — Faceted filters on a flat client-side set; pure-function extraction makes UI logic jsdom-testable (2026-06-07, v3.2.144)

### 1. Multi-select filters + a hierarchy want *faceted* narrowing, not strict cascading

Strict parent→child cascading (hide a child whose parent isn't selected) pairs cleanly with
*single* select. The moment filters become *multi-select*, strict cascading creates an orphan
edge-case: pick a child, then deselect its parent, and the child selection is left dangling — you
either silently drop it or show it in a list that no longer contains it. The industry answer for
multi-select filter bars (Jira / Linear / Amazon) is **faceted** narrowing: filters are
independent, but each dropdown only offers values that exist in the result set narrowed by the
*other* active filters, with a count beside each. No orphan surprise, no empty dropdowns.

For a hierarchy specifically, make faceting **hierarchy-aware**: when computing a facet's options,
skip that level's own selection *and its descendants'* selections, but keep parent selections
applied. So a Generation pick narrows the Release list, but a Release pick does not shrink the
Generation list (which would be jarring). Non-hierarchy filters (search/owner/status/date) always
narrow every facet. The whole thing is a few `Array.filter` passes over the already-fetched rows —
no extra fetch, no hierarchy-tree walk. Derive facet options from the rows themselves
(distinct `id`+`name` per level) rather than from a separate catalog.

### 2. Extract filter/facet/sort into a pure module — then jsdom can actually test it

The recurring blind spot ([[feedback_jsdom_layout_blindspot]]) is that jsdom has no layout engine,
so component tests can't catch visual/interaction bugs. The counter-move that *does* pay off:
push all the decision logic (what's filtered, how facets count, sort order) into a pure module
(`template-filter.ts`) with plain inputs/outputs and no React. That logic — the part most likely to
have off-by-one and mutually-exclusive-count bugs — becomes fully unit-testable without rendering
anything. The component shrinks to wiring. Two bugs caught this way in review: a sort tiebreak that
inverted with direction (a stable tiebreak must be direction-invariant: `cmp !== 0 ? cmp*dir :
id.localeCompare`), and the faceted skip-self-vs-skip-descendants distinction.

### 3. Persist filter state, but fix test isolation at the test, not the feature

Persisting `filterState` to `localStorage` is cheap UX. But a sibling test that doesn't
`localStorage.clear()` in `beforeEach` will leak persisted state across tests — and the wrong fix
is to make one filter (here `statusFilter`) silently *not* persist to dodge the leak, which creates
a surprising asymmetry (everything persists except that one thing). Fix the isolation in the test
(`window.localStorage.clear()` first in `beforeEach`) and keep the feature consistent.

### 4. Extract a shared literal before a second consumer copies it

`TYPE_COLORS` lived inline in the Hierarchy Manager. The templates path badges needed the same
four colors. Extracting to `src/fmb/lib/hierarchy-colors.ts` and re-importing on both sides is a
behavior-preserving refactor that prevents the palette from drifting between the two surfaces —
do it *as* the second consumer appears, not after they've diverged.

## §97 — A borrowed-schema reference needs a guard at every write site, not just the read site (2026-06-07, v3.2.146)

`linked_blueprint_id` made blueprint B "borrow" source A's schema. The read side resolved it
correctly (`COALESCE(linked, self)`), but every *write* and *lifecycle* path ignored it, so the
feature shipped with a cluster of silent-failure bugs: you could open the Schema Builder on a
linked blueprint and edit fields that never render; link A→B→C chains that resolve to a blank
form; delete a source and leave borrowers dangling; import a blueprint and dangle the link across
environments. None of these threw — the form just went blank or the edit just did nothing.

**Lesson: a "reference to another row's data" is a cross-cutting invariant. The read resolver is
the easy half; the hard half is every write/lifecycle site that can violate it.** When you add a
borrow/alias column, enumerate and guard ALL of: schema edits on the alias (block — there's one
canonical place), creating the alias (no chains, no cycles, no self, mutual-exclusion with
siblings), the transition that creates it (clean up now-unreachable data), deleting the target
(block or cascade), and serialization across environments (a UUID alias is meaningless after
import — drop it and warn).

**Mechanics worth reusing:**
- *Single-hop is a feature.* Forbidding "link to an already-linked blueprint" (both directions:
  can't link to a linked node, can't make a source into a linked node) keeps resolution one hop
  and makes chains/cycles structurally unrepresentable — far simpler than a recursive resolver
  with cycle detection at every read site.
- *Guard for every role, not just editors.* The ownership chain only runs for editors; the
  read-only-because-linked guard must run for admins too (editing a linked schema is meaningless
  regardless of who you are).
- *Atomicity dictates where code lives.* The "set link + clear own schema" transition had to be
  one transaction, so it became a small custom handler; everything else stayed validation-only
  middleware that delegates to the generic factory (no ownership-logic duplication = no drift).
- *A new read on a hot write path breaks mocks.* Adding `SELECT linked_blueprint_id` to the
  factory write paths failed ~25 pre-existing unit tests whose scripted conns didn't model it.
  The fix is to default the new probe to a benign value in each mock's fallthrough — the route's
  behavior legitimately changed, so the mocks must model the new query.

## §98 — When the clean fix touches a hot path, "block + explain" beats "make it work" (2026-06-07, v3.2.148)

Followup round to §97. The open question was variant overrides on a linked blueprint: the
variant lives under B but the fields are borrowed from A, so the coherence invariant
(variant.blueprint === field.blueprint) fails and the write is rejected `422` — silently, with no
FE explanation. Two ways out: **(A)** make it read-only and say so; **(B)** re-base coherence on
the *effective* blueprint so B's variants can override A's fields.

**We chose A.** B is the cheaper, more honest fix and it preserves the §97 mental model ("a linked
blueprint has exactly one place to edit its schema — the source"). Option B reopens a per-B
divergence channel and, worse, plants a *new* silent-failure seed: A deleting a field would dangle
B's variant overrides, needing a cross-blueprint cascade — the exact bug class §97 spent a sprint
killing. **Lesson: when "make it work" requires re-defining an invariant you just established and
re-introduces the failure mode you just removed, the feature is a future product decision with its
own spec, not a followup cleanup.** Implementation of A: a `409 LINKED_BLUEPRINT_READONLY` guard
*before* the coherence check (so the message is clear, not a confusing 422) on POST/PUT, plus an FE
lock banner; DELETE stays open for legacy-row cleanup.

**Two concurrency followups (factory-write TOCTOU, POST-create link race) were deferred, not done.**
Both had clean fixes that either touch the generic CRUD factory hot path (the §97 ~25-test churn,
again) or duplicate security-sensitive owner-resolution, for races that are essentially unreachable
in a low-concurrency admin tool (the common reciprocal-link case is already closed by the PUT
transition's `FOR UPDATE`). **Lesson: "MEDIUM, mechanical" in a ledger is not a free yes — when the
clean fix's blast radius dwarfs the bug's reachable consequence, defer it into a focused round and
say why, rather than smuggling factory churn or owner-logic duplication into an unrelated PR.**

**Mechanics worth reusing:**
- *Audit across the rollback boundary.* An audit row written inside the transaction it documents is
  lost when that transaction rolls back. If you want a record of an *attempt* that failed, write it
  on a fresh autocommit connection in the failure/catch paths (best-effort, never throws into the
  caller). Enumerate *all* rollback exits — here there were three (no-updatable-columns, 0-rows,
  exception), not just the obvious one.
- *Operator pre-fix note (rows predating an invariant).* The XOR enforcement (a linked blueprint
  can't also carry a transformer) only guards new writes; rows written before it survive until the
  next PUT touches them. Surface the one-time cleanup query for operators:
  `SELECT id, name FROM <prefix>hierarchy_nodes WHERE linked_blueprint_id IS NOT NULL AND (transformer_id IS NOT NULL OR transformer_version IS NOT NULL);`
  — clear the transformer on the matches. No migration; ONPREM/AIRGAP operator task.

## §99 — A check-then-write TOCTOU is fixed on the WRITE connection, not with a second read (2026-06-07, v3.2.150)

The deferred §98 factory-write TOCTOU, done. The race: the linked-blueprint guard ran
`isBlueprintLinked` on a *separate* autocommit connection, then the factory wrote on its *own*
connection — a concurrent link in the gap landed an orphan schema row on the now-linked blueprint.

**Lesson: when a check and a write must agree, run the check on the write's connection, inside the
write transaction, with `FOR UPDATE` — not as a second autocommit read.** A separate read can never
be atomic with the write; a row-locked read inside the same transaction serialises any concurrent
mutation of that row behind the lock. This was the right tool here precisely because the closest
sibling (the link transition handler) already used it — reach for the in-TX `FOR UPDATE` re-check
before inventing a cross-transaction `NOT EXISTS` predicate (which is subtler to reason about and,
for an UPDATE, fights MariaDB's same-table-subquery 1093).

**Mechanics worth reusing:**
- *Gate the transactional path so the hot path stays autocommit.* Only the four `rejectIfParentLinked`
  mounts enter the `beginTransaction` + `FOR UPDATE` branch (`const guardTx = !!rejectIfParentLinked`);
  every other table writes exactly as before. Prove it: a unit test asserts a NON-guarded POST issues
  **no** `beginTransaction` and **no** `FOR UPDATE`. "No-impact" is a claim you can and should test,
  not just assert in a comment.
- *A shared client that swallows all errors to null conflates 404 with 5xx.* `schemaGet` returned
  `null` on *every* failure, so a data-entry "linked source missing" banner fired on a transient 500
  too. Fix without changing the default: an opt-in `{ nullOn404Only }` that re-throws on non-404.
  The wrappers below it (`ssoFetch`/`customApiFetch`) *strip* `ApiError → Error` for bare-catch
  callers, so the status was lost before the caller saw it — thread a default-false `preserveApiError`
  flag through the thin fetch layer so the opt-in caller gets the raw `ApiError.status` while every
  existing caller is byte-for-byte unchanged.

## §100 — On an opaque-SQL allowlist path, classify the driver errno; don't rewrite the SQL (2026-06-07, v3.2.151)

The seed import (`POST /api/setup/seed`) runs opaque, allowlisted `INSERT`/`REPLACE` statements
inside one transaction. A cross-version dump can name a column or table the target DB lacks
(operator-mode schema drift) — and the batch hard-failed with an opaque `500 SEED_ERROR`, so the
operator could not tell "the seed is malformed" from "my target schema is behind".

**Lesson: a security-critical SQL-execution endpoint can't column-gate like the CRUD path (the
v3.2.128 column gate doesn't reach an opaque allowlist statement), so the honest robustness fix for
schema drift is to classify the driver errno into an actionable 4xx — not to parse or rewrite the
SQL.** errno 1054 (missing column) / 1146 (missing table) → `422 SEED_SCHEMA_MISMATCH` naming the
mismatch; every other errno keeps the existing `500`. Rewriting INSERTs to strip unknown columns,
or a pre-flight full report, both require parsing SQL on the one path where parsing mistakes are
most dangerous — rejected. First-failure 422 with the identifier is actionable enough (fix schema,
re-run; `INSERT IGNORE`/`REPLACE` make the seed idempotent).

**Two corollaries worth reusing:**
- *Echoing the driver message is fine here, and only here.* The seed endpoint is admin-only /
  first-run, so the caller already sees the schema — `db_message` is the actionable payload, not a
  leak. Contrast the public pool-diagnostic surface (§6.5), which must sanitize because it is
  unauthenticated. Same raw string, opposite call: the trust boundary decides, not the value.
- *Before building "add a round-trip test," grep for one.* The spec's Part 2 was "add an
  export→seed-import round-trip test" — but `export-import-legacy-json-roundtrip.test.js` already
  existed and closed it (6 green). The same grep also surfaced two integration tests
  (`export-import-{legacy-json,cascade}-roundtrip`) that *pinned the old opaque-500* for the exact
  1054 scenario this change upgrades — a behavior change ripples into every test that asserted the
  old contract, so grep the codebase for the old status/code before assuming "re-run only."

## §101 — Scope an active-state restyle to the instance; keep the pure state shape stable across a layout reflow (2026-06-07, v3.2.152)

Two pure-FE UI changes, two reusable boundaries.

**Lesson 1: emphasize one widget by overriding at the call site, not by editing the shared
primitive.** The Data Entry "Generated Outputs" tabs needed an active-state look (light = blue
text + underline; dark = filled blue pill + white text). The tabs are shadcn/Radix `Tabs`, shared
by every tab surface in the app and by Lovable's visual editor. Editing `ui/tabs.tsx` would have
restyled all of them. Instead the override rides on the one `TabsTrigger` via
`data-[state=active]:…` + `dark:data-[state=active]:…` utilities (cancelling the default
`bg-background shadow` first). The blast radius is exactly one component; nothing else — and no
Lovable surface — can regress. Default to call-site overrides for "make THIS instance look
different"; only touch the shared primitive when EVERY instance should change.

**Lesson 2: a big toolbar reflow is cheap when the filter STATE shape doesn't move.** The Template
Dashboard toolbar was rebuilt (search relocated, status chips → `All Statuses` dropdown, `Reset`
promoted, `More Filters` made a collapsible toggle, `Sort` promoted to a dropdown, `Status` column
dropped → symbol before the name, `Path` truncated). All of it is render-tree churn over the SAME
`TemplateFilterState` and the SAME pure `template-filter.ts` (`applyFilters`/`sortTemplates`/
`computeFacets`). So the pure-logic test (`template-filter.test.ts`) and the persistence path were
untouched; only the component tests that asserted the OLD controls (status chips as `role=radio`,
the Status column header) needed rewriting. When you keep the data contract stable, a visual
overhaul stays local to the view layer.

**Corollary — test the filter, not the Radix Select.** A Radix `Select` is portal- and
pointer-driven and unreliable to drive in jsdom. The status-filter narrowing is proven by seeding
the persisted `statusFilter` in localStorage and asserting the rendered rows — same
`statusFilter → applyFilters` wiring, no flaky pointer dance. The visual surfaces jsdom can't see
(tab colors, path ellipsis, panel collapse) are deferred to browser-accept, as usual.

## §102 — One secret-bearing table among many: extend the shared factory with a null-default hook, don't fork it (2026-06-08, v3.2.157)

**Context.** API Connectors P1 added `api_connectors` — the *only* engine table that stores
secrets (auth token / api-key value / basic password inside an `auth_config` JSON column). Every
other engine table goes through the generic `createCrudRoutes` factory, which has no place to
encrypt-on-write / mask-on-read. Two ways to add the crypto: (a) write bespoke CRUD routes for this
one table (full control, but duplicates list/filter/sort/owner/operator-gating), or (b) add a hook
to the shared factory.

**Decision — (b), but the hook is generic and null-default.** `createCrudRoutes` gained
`serializeWrite(data, { req, isUpdate, id })` and `serializeRead(row)`. Both default to null, so
the seven existing mounts that pass neither are byte-identical (verified by the full factory test
suite staying green). All secret knowledge lives in a separate `serializer.js`; the factory stays
crypto-agnostic. A bespoke fork would have been *more* tech debt, not less — the user's framing
("don't add tech debt, use the same") is the right lens: "same factory + one reusable extension"
beats "a second parallel CRUD to maintain."

**Why customization existed at all.** Exactly one reason: this table holds secrets. Secrets need
three things normal tables don't — encrypt on write, mask `****` on read, decrypt for use. Surface
that to the user in one sentence instead of hand-waving "it needs custom serialization."

**Mask-preserve is a real data-loss footgun, not polish.** GET returns secrets masked. If the admin
edits a connector without re-typing the secret, a naive full-column write persists `****` over the
real secret. The write serializer must detect the mask sentinel and read the stored ciphertext
back (dropping the leaf entirely when there is no prior secret, so the literal mask is never
stored). Test it: a `****` update keeps the stored ciphertext; a real value overwrites; a `****`
with no prior drops the key.

**New engine table ≠ "the DDL runs at boot."** Engine tables are created by Setup/sync-schema, NOT
by `ensureInfrastructure` (which only re-runs the *infra* DDLs every boot). An existing DB upgrading
the schema version would never get the new table from boot alone. The new table must be created
inside `runSchemaMigrations` under the version gate, single-sourcing the DDL from
`buildEngineTableDDLs` (no inline duplicate), and incrementing `skippedSteps` on `1142` so an
operator-mode boot holds the version bump and retries. The `skippedSteps` counter is declared
mid-function — a step that uses it must be placed *after* that `let`, or it dies in the TDZ.

**Registry severity should match operational reality, not a template.** The plan said
`severity: 'critical'`; the as-built entry is `warning`. An absent optional, env-gated feature
table corrupts no data and breaks no core flow, so `degraded` (amber, flow continues) is the honest
schema-status signal — a `failed` (red, blocks the DB switch) over an optional table is too
aggressive. Match the existing additive-column precedent (`blueprint_sections_icon` is
`recover`+`warning`), not the generic default.

**Env gate lives where the request actually is.** CLOUD runs against Supabase and never reaches the
Express edge, so there is no backend `403` env gate (no existing helper matches, and the route is
unreachable in CLOUD anyway). The gate is frontend: the menu item via build-time `Env.usesExpressApi()`
and the page via runtime `ConnectionManager.isCloud()`; the backend is admin-only. Don't fabricate a
backend gate that mirrors nothing — gate where the traffic is.

**Lockstep reminders that bite a new table.** Adding one engine table touched five count/exhaustiveness
assertions across the suite: `ENGINE_TABLE_NAMES` ↔ `TABLES` ↔ dto-mapper `REGISTRY`, the privileges
`ALLOWED_TABLE_BASE_NAMES` snapshot (15→16), and the schema-status rollup fixture
(`ALIGNED_BY_COLUMN` needed the new guard columns or every "no drift" test failed). Grep the new
table/columns against test fixtures before declaring green.

## §103 — Zero-dep SSRF defense pins the IP via core `http` + custom `lookup`, not `fetch`/`undici` (2026-06-08, v3.2.158)

**Context.** API Connectors P2 makes the edge tier fetch an admin-configured URL. The SSRF defense has to survive **DNS rebinding**: a hostname that passes the IP check at check-time, then resolves to `127.0.0.1` / `169.254.169.254` at connect-time. The only robust fix is to resolve once and *pin* the connection to the validated IP.

**`fetch`/`undici` is the wrong tool; core `http`/`https` is the right one.** Global `fetch` resolves DNS itself and gives you no clean seam to pin the resolved address. `undici.Agent` *can* pin via a custom `connect.lookup`, but `require('undici')` is a transitive dependency — fragile under AIRGAP Nexus curation (it can vanish from the tree). Node **core `http.request(url, { lookup })`** takes a `lookup` option that is called at connect time; a validating lookup that rejects blocked IPs and returns the chosen address makes the socket connect to *that exact IP*. Core modules are always present → zero dependency-tree risk. This is the canonical zero-dep pinned-SSRF pattern here.

**Fail closed.** `isBlockedIp` returns `true` for anything it can't positively classify as safe (empty, malformed, unknown family). RFC1918 + IPv6 ULA are *allowed* on purpose — the target is internal. Normalise IPv4-mapped IPv6 (`::ffff:a.b.c.d`) before the v4 range checks, and compute IPv6 link-local as the `fe80::/10` range (first hextet `0xfe80..0xfebf`), not a string-prefix guess.

**Literal IPs skip `lookup`.** `http.request` only calls `lookup` for hostnames; a literal-IP URL connects directly. So the literal case needs a *separate* pre-check (`net.isIP(host) && isBlockedIp(host)`) or `http://127.0.0.1/` walks straight past the lookup-based guard.

**Inject the guard so http-mechanics tests can use a loopback mock.** The integration test's mock server runs on `127.0.0.1`, which the real guard (correctly) blocks. Rather than weaken the guard, make `executeRequest` take injectable `ipGuard` + `lookup` (default = real). The timeout/size-cap/redirect/body tests pass a permissive guard to reach the loopback mock; a couple of cases use the *real* guard to prove a literal loopback/metadata IP is blocked end-to-end. The guard itself is unit-tested standalone. Same `now`-injection trick keeps the circuit breaker deterministic without `Date.now`.

**Edge is a proxy: an upstream 4xx/5xx is a *successful* dispatch.** Return the raw envelope with `upstream_status`; only transport/guard failures (timeout, size, SSRF, unreachable) map to apiError codes. Mapping a 404-from-upstream to a 404-from-us would lie about who failed.

## §104 — A custom Node `lookup` MUST honor `options.all` (autoSelectFamily), or every real dispatch dies (2026-06-09, v3.2.164)

**The bug.** The pinned-SSRF `lookup` from §103 returned the single-arg form `cb(null, address, family)` and ignored `options.all`. Node ≥ 20 opens sockets with **`autoSelectFamily` ON by default**: `net.connect` calls a custom `lookup` with `{ all: true }` and expects the **array form** `cb(null, [{ address, family }])`. Given the single-arg form, Node reads `undefined` as the address → `ERR_INVALID_IP_ADDRESS` → mapped to `CONNECTOR_UNREACHABLE`. **Every** real connector fetch to a *reachable* upstream failed — edge-origin and infra-origin alike — latent since P2.

**Fix.** Make the lookup `all`-aware: under `{ all: true }` return a **single-element** array `[{ address, family }]` (one validated/pinned IP — the §103 anti-rebinding pin is unchanged; do NOT return all resolved addresses or you reopen the rebinding window); otherwise keep the single-arg form. Same shape at both lookup sites (`makeValidatingLookup`, infra `pinnedLookup`).

**Why it stayed hidden for four versions — a double blind spot, both already noted in §103.** (1) The http-mechanics tests injected the *native* `dns.lookup`, which is itself all-aware — so they never exercised the custom lookup's callback shape. (2) Those tests used *literal-IP* URLs (`127.0.0.1:port`), and literal IPs **skip `lookup` entirely** — so even the injection was a no-op. The two test conveniences that §103 introduced to reach a loopback mock are exactly what blinded the suite to a production-only contract. **Lesson: when a seam exists only so tests can avoid the real component, add at least one test that drives the *real* component's contract** — here, assert `makeValidatingLookup({all:true})` returns the array form directly, and exercise `executeRequest` through a **hostname** URL (`.invalid` TLD, resolved only by the injected lookup) so the lookup is actually called. Bonus gotcha: two same-hostname round-trips reuse a keep-alive socket and skip the second lookup — use distinct hostnames per assertion.

**Meta-lesson.** A guard/adapter that is only ever exercised through injected fakes is effectively untested. The bug surfaced the first time a *reachable* upstream existed in the cluster (the dev-infra `mock-api`) — i.e. the first real end-to-end. Stand up a reachable fixture early; "unit-green + no live target" is not "works".

**Redaction is load-bearing.** The decrypted `auth_config` and the injected auth header must never reach a log line, an audit row, or an error body. Audit carries connector id / host / method / upstream_status / duration / outcome only — never request or response bodies.

## §105 — Editor UX bugs are usually a model mismatch: make the runtime's hidden rule visible, don't paper over it (2026-06-11, v3.2.176)

The API Connectors Request editor drew three disconnected boxes — Body, free-text "input mapping", dropdown "table input columns". Operators couldn't tell which to fill, or what happened if they filled two. The root wasn't styling: the editor's shape **disagreed with the runtime model**. At dispatch, the URL/headers/body are templates whose `{{var}}` tokens are the subject, and each var draws its value from a form field (scalar) **or** a table column (table) — mutually exclusive, decided by `getTableBinding`. The UI hid all three facts (var-is-subject, the two sources, the exclusivity).

**Fix = surface the runtime model, var-first.** A mode selector makes the scalar-XOR-table choice physical (you can't fill both); a single binding table lists every discovered var with one source dropdown per the active mode. The old free-text/dropdown inconsistency vanished because both became dropdowns over the same field/cell catalogs.

**Use the runtime's own rule to drive the editor, never a parallel reimplementation.** Mode inference calls the *same* `getTableBinding` the dispatch uses (wrapped in `connector-vars.inferRequestMode` against a minimal `UsableConnector` probe). If the editor judged mode by a hand-rolled heuristic it could show a mode a fetch wouldn't take — the exact divergence §104 warns about. One rule, two callers.

**Preserve, warn, normalize-on-save — don't silently rewrite on open.** A connector with stale/inconsistent bindings (both sources, or mismatched tables) keeps its raw JSON on open; an amber banner says which mode is active and that saving keeps only that mode's bindings. Normalization happens **only** when the operator saves (`buildRequestConfig` drops the inactive source). Auto-cleaning on open would delete an admin's data behind their back.

**Redesign without touching the persisted shape.** The whole change writes the same `input_mapping` / `input_cells` JSON, so runtime dispatch, the `/usable` projection, and every existing connector are byte-for-byte unaffected — the FE re-presents the same data, it doesn't migrate it. A "big UI redesign" that ships zero schema/contract change is the cheapest kind: pure presentation, fully reversible.

**Preview without a live upstream.** A static preview highlights bound vs unbound vars and offers a client-side `fillTemplate` sample-resolve (the same substituter the backend runs) so an admin sees concrete bytes in AIRGAP where no upstream is reachable. The real fetch stays in the one place that owns it (the Test modal) — don't build a second filled-request form that duplicates it.

## §106 — A login that's served from cache leaves no audit trail; hook the one event that only fires on a real login (2026-06-11, v3.2.178)

"Last Login" in Recent Logins froze at first-bind for every already-bound Keycloak user. The cause wasn't the query — it was that the **write never happened**. The per-request auth path resolves identity, hits a 30s user cache (and even on a miss, `jitProvision` Step 1 returns the bound row and returns early), so a returning user's request writes no `login_audit`. The only rows ever written were the *first* bind (Step 2a/2b) and new-user provisioning (Step 3).

**Find the event that fires exactly once per real login, not once per request.** `express-openid-connect`'s `afterCallback` runs only on the authorization-code exchange — the genuine interactive login — not on the token re-verification that rides every subsequent request. That's the reliable "fresh login" signal. A per-request hook would log on every page load; the cache miss is too rare and the cache hit writes nothing. `afterCallback` is the seam.

**Thread an intent flag end-to-end; default it to no-write.** `freshLogin` rides callback → infra `notifyFreshLogin` → S2S `resolveIdentity` → edge `identity-resolve` → `jitProvision`. Only the callback sets it; every existing call site omits it, so `body.freshLogin === true` (strict) keeps token re-verification silent. Adding a write path to a hot function is safe only when the default is the old behavior.

**The fresh-login row is fire-and-forget and must never gate the redirect.** The audit write is `.catch(warn)` at three layers (jit insert, edge resolve, infra notify) and `notifyFreshLogin` is wrapped so a decode/transport failure can't throw out of `afterCallback` — a logging miss must not cost a user their login. Skip the write for banned users: the banned path already writes its own FALSE row, and a success row for someone who's about to be blocked is a lie.

**Infra purity holds even for a convenience helper.** `oidc-fresh-login` lives in `infra/lib/` and reaches edge over S2S (`edge-state-client`), importing no DB module — the same rule the per-request path follows. `jsonwebtoken.decode` (no verify) is fine because `express-openid-connect` already validated the signature before `afterCallback`; edge trusts infra-supplied claims the same way the per-request OIDC path already does.

**The display bug rode along with the data bug.** Once the data was real, the panel still filtered to `auth_provider='KEYCLOAK' AND success=TRUE`, hiding LOCAL logins and all failures. Dropping the provider filter (group by provider, badge each row) and an opt-in `include_failures=1` branch cost no schema change — `login_audit` already carried `auth_provider` / `reason` / `success`. The frozen-timestamp bug had masked how little the surface actually showed.

## §107 — Per-request observability with zero dependency: two tiny middlewares, finish-time capture, format-guarded correlation (2026-06-11, v3.2.179)

Infra/edge had no per-request log — no request id, no actor, no latency. The reflex is to reach for `pino-http` / `morgan`. AIRGAP forbids new npm deps, and the need is small, so two hand-written middlewares over the existing pino logger cover it.

**Capture the actor at finish, not at entry.** `res.on('finish')` fires after the auth middleware has populated `req.user`, so even a request a guard rejects (401/403) logs *who* attempted it. Logging at entry would miss the actor on every rejected request — the ones you most want to see.

**Log the pathname, never the query string.** `req.path` already excludes the query, but the line defensively `.split('?')[0]` anyway — query strings carry tokens and ids that must not reach the log pipeline. The binding set is a fixed allowlist (`req_id/method/path/status/ms/user_id/role/ip`); the actor is `user_id`, **never** the email (PII). A negative unit test asserts no `email` key and no query substring can appear.

**5xx→error / 4xx→warn / debug-downgrade only for success.** High-frequency internal S2S probes (`identity-resolve`, `auth-mode`) downgrade to debug so they vanish at `LOG_LEVEL=info`, but the level logic checks status *first* — a failure on a downgraded route still warns/errors. Downgrading by route alone would have hidden real failures.

**Correlation id: mint at the front door, adopt-with-a-guard downstream.** Infra mints an 8-char id first in the chain (so even a rejected response carries `X-Request-Id`); edge adopts a well-formed inbound id to share one id across both pods, regex-guarded (`^[a-zA-Z0-9-]{4,64}$`) before adoption so a hostile `x-request-id: foo\ninjected` can't forge log lines. The id rides the existing forwarding headers (`...extraHeaders` already merged into the edge fetch) — no new S2S allowlist entry needed.

**Surface the id to the user, suffix the existing error path.** The frontend reads `X-Request-Id` (CORS `exposedHeaders`) and, on HTTP failure, attaches it to `ApiError.requestId` *and* suffixes the message with `（追蹤碼: <id>）`. Every existing `toast.error({ description: err.message })` then shows the trace code with zero call-site change — the cheapest way to make a code visible is to ride the channel that already renders.

**One config key, two registered sources.** `LOG_LEVEL` is a shared logger setting, so it goes in `configmap-shared` — but that file is a dual-source pair (`base/` = prod, `components/shared/` = local k3d). Editing only the one the local render reads would have silently shipped prod without the key. Re-render flat-output after editing both.

**Bound the logs you just created.** Adding a per-request access log raises log volume, so the same PR bounds it: compose gets a `json-file` 10m×3 driver, and the dist exporter's `compose.transform.cjs` grew an idempotent `ensureLogRotation` so the AIRGAP/ONPREM `.devcontainer` compose gets the same cap (k8s already rotates via kubelet). Don't ship a firehose without a bucket.

## §108 — A new response mode is a new array, not a new union member; keep the lib pure and number the items (2026-06-11, v3.2.181)

API Connectors needed a VLOOKUP-style "filtered single-value lookup" (response is an array; pick the element where `filter_column === filter_value`, take `extract_column`, write it to a field/cell). Three lessons fell out of the build.

**Don't widen a shared union; add a sibling array.** `ResponseMapping` (`{path, field_key?|cell?}`) is consumed by four field-by-field reconstructors and one invariant check (`getTableBinding`'s "all cells share one table_key"). A lookup's shape is fundamentally different, so forcing it into that union would have made every consumer grow a discriminator and taught the invariant about a shape it doesn't own. A separate `lookups?: ResponseLookup[]` is purely additive: old connectors lack the key → `?? []` → zero behavior change, and the seven other engine tables and all existing mappings stay byte-identical. The Ship-Gate-friendly version of "extend a feature" is "add an orthogonal field", not "make the existing field polymorphic".

**Keep the apply lib a pure function; resolve references at the call site.** A lookup's filter value can reference a table cell whose row the *user* picks at fetch time — live grid state the pure `applyConnectorResponse(rawBody, config, currentValues)` must never see. Rather than pass grid shape into the lib, the lib takes an optional `lookupFilterOverrides` map and the modal resolves cell refs to strings before calling. The boundary stays testable with plain objects; the grid coupling lives in the component where it belongs.

**Number the items so a later filter can address them.** The lib drops a lookup whose target field is unknown (stale config), so the *output* array index diverges from the *config* array index. PR2 will key per-lookup row-overrides by position — silent drift would mis-route them. Stamping each outcome with its `configIndex` (the config position, stable across drops) makes the seam correct before PR2 exists. A code reviewer caught this; the cost of fixing it pre-emptively was one field.

**One-key reads need their own getter.** The path-getter tokenizes `a.b[0]` into a traversal, but a lookup column literally named `a.b` is one key, not a nested path. A 5-line `pathGetKey` (same proto-pollution `FORBIDDEN` guard, no tokenization) removes the ambiguity. Reuse the guard, not the parser, when the input grammar differs.

## §109 — A cell-target lookup validates off the column key, so the scalar modal must widen its "known keys" (2026-06-11, v3.2.183)

PR2 let a lookup write to a **table cell**, and three small seams decided whether it worked.

**The drop-guard is keyed by the target's leaf key — so the caller's "known keys" set has to contain that leaf.** The lib drops a lookup whose `targetKey` isn't in `knownFieldKeys` (stale-config guard, shared with mappings). For a scalar field target the leaf is a top-level `field_key`; for a **cell** target it's the table **column key**, which is *not* in the data-entry page's base `knownFieldKeys` (that set is top-level fields only). The table P4 path never hit this because it builds its own column-key set per grid. The scalar "Fetch from API" modal does not — so the page had to pass an **augmented** set (`fields ∪ all table column keys`) plus matching labels, or every cell-target lookup silently vanished as "stale". The lesson: when one validity gate serves two target shapes, the set it checks against must be the **union** of both shapes' namespaces, assembled by whoever owns the broader context (the page), not the lib.

**Resolve-then-call stays pure even when a row override forces a re-run.** A cell-referenced *filter* value depends on a user-chosen row, and changing that row changes which element matches → the lib must re-run. Instead of an effect with fragile deps, the row input's `onChange` builds the next override map and calls the recompute explicitly with it (no stale closure, no `exhaustive-deps` escape hatch). The pure lib is re-invoked against the **cached** body — zero extra network — and the override map is still keyed by the stable `configIndex` from §108.

**A disambiguation picker shows a bounded projection, never the raw element.** PR1's security review had stripped the raw matched object off candidates (it could carry unvetted nested PII/secrets). PR2 needs *something* to tell two matches apart, so the lib attaches a `display` map capped at 6 primitive fields × 80 chars, `__proto__`/`constructor`/`prototype` skipped. Bounded, primitive-only, length-limited — the picker gets discriminators without re-exposing the object the review removed.

**Cell writes reuse the grid's own never-blank/positional contract.** `writeLookupCells` mirrors `buildAppliedRows`: 1-based row, out-of-range row **skipped** (a stale config row never spawns blank rows), empty value **never** clobbers, same-ref return when nothing applies. The page parses/serializes `values[table_key]` with the *same* simple-vs-object rule `TableFieldRenderer` uses, so the write round-trips through the grid's external-change effect and the undo history resets cleanly. One serialization contract, honored on both sides.

## §110 — A shared visual language is a pure classifier + small dumb components, not a copied stylesheet (2026-06-11, v3.2.186)

Three "Fetch from API" review surfaces (data-entry scalar, admin Test, table multi-row) drifted apart because each modal hand-rolled its own table, colours, and footer. The fix is a `connectors/review/` kit, and the part that actually keeps them consistent is the **pure classifier**, not the components.

**Put the meaning in a pure function, the pixels in a dumb component.** `review-status.ts` maps the lib's raw statuses (`ConnectorRow.status` = new/changed/same/not-found; `LookupOutcome.status` = unique/multi/not-found/error) into one `ReviewStatus` enum, and decides `selectable` (only new/changed can be applied). It has zero JSX, so its full state matrix is unit-testable without rendering anything. `ConnectorStatusBadge` then only knows "status → dot + label + tone". A modal that wants to match the others can't accidentally diverge: it imports the classifier and the badge, and there is no second place to define what "changed" means or looks like. The three modals stay consistent *by construction*, not by a reviewer remembering to copy a colour.

**Never signal by colour alone — dot + text, always.** Every status renders an icon-dot *and* a text label; only `changed` adds a faint cell tint, and even then the label is present. Colour-only state fails dark mode, fails colour-blind users, and fails compliance review — three separate reasons that all point the same way. The tint is the exception that proves the rule: it's an *additional* warning ("this overwrites"), never the *only* signal.

**A component defined inside render() is a new type every render — interactive children lose focus.** The first cut defined the lookup detail sub-row as `const LookupDetailRow = (...) => ...` inside the modal body and rendered `<LookupDetailRow/>`. React sees a fresh component identity each render, unmounts the old one, and the number-stepper the user is typing into loses focus on every keystroke. The cheap, total fix is to drop the component boundary: make it a plain render function (`lookupDetailRow(lo)`) called as `{lookupDetailRow(lo)}`. Same closures, same JSX, but no component identity to churn — so no remount, no focus loss. If a nested helper renders interactive inputs, it must not be a component.

**One `<table>` guarantees alignment that two tables can only approximate.** The original bug was a scalar-mappings table and a lookups table stacked with different columns, so headers never lined up and a lookup-only connector showed an orphaned empty header. Merging both into one row list under one `<table>` makes misalignment *structurally impossible* and deletes the empty-header state outright — the alignment is a property of the DOM shape, not of matching two sets of hard-coded widths.

## §111 — Shared visuals, not shared semantics: one badge, two honest status vocabularies (2026-06-11, v3.2.187)

Phase 2 pointed the admin "Test connector" modal at the same review kit. The trap was assuming "consistent UI" means "identical screen". It does not.

**The data-entry diff (new/changed/unchanged) only exists because there is a form to diff against.** A data-entry user fetches into a real form, so "this fills an empty field" (new) vs "this overwrites 5" (changed) is the whole point. The admin Test run fills *nothing* — it is a dry-run to check "does this connector resolve the right fields". There is no current value, so new/changed/unchanged is meaningless there. Forcing the data-entry table onto Test would have shown "new" on every row (because the code would pretend the form is empty) — pretty, but a lie, and it would have dropped the `Source` column (which response path → which field), which is the admin's actual mapping-debug tool.

**Share the visual language, not the semantics.** The fix added one neutral kit status `found` and let Test keep its own honest vocabulary: resolved→`found`, missing→`not-found`, array→`multi-row`. Both modals render the *same* `ConnectorStatusBadge` and `RawResponseDisclosure` (so they look like one product), but Test keeps its `Source` column, its Re-run/Close footer, and no checkbox/apply (it applies nothing, so `ReviewTableShell`'s apply footer is deliberately *not* used). The kit is a palette, not a straitjacket — a status enum and dumb components, additively extended, so a new consumer adds the vocabulary it needs without bending its meaning to fit the first consumer.

**When the spec says "adopt the unified table" but the second consumer has no current value, surface it.** The spec's §2 ("adopts the unified table directly") read as a literal table swap, but §10's own Phase-3 guidance ("keep own structure, adopt shared visual language") is the honest pattern. Rather than silently pick one, the decision (visual-adoption, keep Source/found-semantics) was put to the user — because the wrong call ships a misleading admin screen, not just an ugly one.

## §112 — A shared visual language is tokens, not a shared component — the third consumer proves it (2026-06-11, v3.2.188)

Phase 3 brought the last review surface — the table multi-row fetch — into the family, and it could not use the shared *component* at all. It is a mirror grid (N fetched rows × M target columns); the review "table" the other two modals share is a single-row-per-mapping list. Forcing one into the other was never on the table.

**What actually unifies three different layouts is the smallest shared units: a colour token and a badge.** The changed-cell warning had drifted to `bg-blue-500/15` here while the data-entry modal used amber. Phase 3's headline change is one line — swap it to the shared `CHANGED_TINT` — and now all three modals warn "this overwrites" in the same amber, by importing the same constant. The failed-fetch row swapped its hand-rolled repeated red error text for one `ConnectorStatusBadge status="error"`. The grid stays a grid; the footer keeps its row-semantics wording ("Apply All Fields to N rows", which the shell's field-semantics "Apply N selected" would have mangled); `RawResponseDisclosure` is simply absent because an N-fetch grid has no single raw body to disclose. The kit gave what fit (a tint, a badge) and stayed out of what didn't (the table shell, the raw viewer).

**The three-phase arc is the lesson.** Phase 1 built the kit *and* the canonical consumer together (single-row review table). Phase 2 reused the *visual language* but kept its own read-only structure and added a status word (`found`) the first consumer never needed. Phase 3 reused only *two tokens* and shared no structure at all. Consistency went down a ladder — same component → same language + own structure → same tokens + own everything else — and at every rung the product still looks like one product. A design system that demands all consumers share a component fails the third consumer; one that ships tokens and dumb pieces lets each surface take exactly what fits.

## §113 — Place the action where its *effect* lands, not where its *inputs* come from (2026-06-11, v3.2.190)

The data-entry "Fetch from API" buttons were placed by where a connector reads its **inputs**: a table connector on the grid toolbar (so it could read selected rows), a scalar connector at the form top or an admin-chosen section. Live inspection showed the cost: the button sat far from the fields it fills, so you could not predict what clicking it would do, and two identically-labelled buttons behaved completely differently. The user's reframe was the fix — **anchor the button to the section it writes to (its output), and pull the scattered inputs into the modal instead.** Now location predicts effect: a button in the Specs header fills Specs.

The mechanism is a pure `resolvePrimarySection`: count how many of a connector's response targets (mappings + lookups, cell targets resolved via `table_key`) land in each section, take the max, tie-break by earliest section. No-match falls back to a form-top bucket. This is derivable entirely from existing `/usable` data + a field→section reverse map — no new admin field, no backend change.

**The deeper principle: a control's home should answer "what will this do?", and inputs are a modal's job, not a placement constraint.** The old design let an input dependency (table row selection) dictate where the button lived; once you accept that the modal can gather inputs (even row selection — Phase 2), the input constraint dissolves and you are free to place the button where it is *legible*. Output-driven placement is the legible choice.

## §114 — Unify divergent special-cases into one `from → to` shape, and make the *type removal* drive the cut (2026-06-13, v3.2.209)

The connector response config had grown three special-cased ways to move a JSON value into the form: `mappings[]` (scalar → field/cell), `lookups[]` (filtered list → cell, collapse multi-match), and a planned scalar→table fan-out. Each rejected the others' inputs (mappings refused arrays, lookups forced a single value). Because the feature was not yet live to internal users, there were no locked-in stored configs — the one cheap window to re-found the foundation. We unified all three into one `outputs[]` of `{ id, from, to }` pairs under a `from × to` legality matrix: mapping = value→field/cell, lookup = list→field/cell, fan-out = list→rows. Three concepts collapsed to three legal coordinates in one grid.

**The hard cut was compiler-driven, and that was the safety mechanism, not a hazard.** Removing `mappings`/`lookups` from the `ResponseConfig` type made `tsc` enumerate every consumer (≈27 files) — a worklist no grep could produce as reliably. Each task cleared a cluster, leaving the build intentionally red until the final sweep; the green build at the end *proved* nothing reads the old shape. Behavior was preserved by an explicit parity contract: the apply engine kept its exact `ApplyResult` output (value→`rows[]`, list→`lookups[]`), so the ≈15 downstream preview/test/fetch consumers never knew the internal model changed. `reduce:'pick'` carried the legacy multi-match disambiguation through the conversion — the one landmine that would have silently degraded behavior if it had defaulted to `'first'`.

**Two lockstep + one runtime lesson reinforced here.** (1) A reference walker that exists on both tiers (FE `getConnectorOutputTargets` ⇄ BE `connector-health.js collectTargetKeys`) must be migrated as a pair with a "change-one-change-both" note and a shared fixture, or the two drift the moment one side learns the new shape. (2) A "hard cut with editor-load conversion" is **not** enough on its own: the runtime read path (`/usable`) and the admin-health read path also see stored rows, and an un-migrated row there silently projects to "fills nothing" — caught only because Codex traced an already-stored config through the read path. The fix was a defensive converter applied at *every* read boundary (editor, `/usable`, health), not just on editor load — mirroring the FE converter as a BE twin. The deeper rule: when you drop a stored shape without a DB migration, every code path that *reads* that shape needs the on-the-fly convert, not just the one a developer happens to test through.

## §115 — Fan-out is an additive result field + a provenance model; the editor must validate down to what the runtime actually supports (2026-06-14, v3.2.210)

PR-B turned the forward-compat `to:rows` sink into a working scalar→table fan-out (one list response → N table rows). Two design spines and one process lesson.

**Extend by adding an optional result field, never by mutating the existing one.** The apply engine's `ApplyResult` gained `fanout?: FanoutOutcome[]` — optional and omitted when empty. `value→field/cell` (`rows[]`) and `list→field/cell` (`lookups[]`) stay byte-identical, so every existing consumer (the scalar/table fetch modals, Test, aggregation, chain) keeps working untouched; only the new dedicated modal reads `fanout`. This is the §108 lesson again at the result layer: a new mode is a new field, not a new union member. The corollary surfaced in review — an additive field is invisible to old consumers *by design*, so a consumer that *should* now react (Test reporting "no fields mapped", aggregation silently folding nothing) needs explicit handling or an explicit exclusion. We surfaced fan-out read-only in Test and **excluded fan-out connectors from aggregation/chain bundles** (single-purpose; bundling integration is a separate future feature) so "invisible to old consumers" never becomes "silently does nothing".

**Session provenance for a row-set you don't own: a per-table counted multiset, invalidated on external replacement.** Fan-out can't blindly append on re-run, and the serialized table rows carry no per-row id. The model: the connector remembers the rows it wrote this session as content-signatures, in memory, never persisted. Three corrections from review made it actually safe: (1) a **Set** of signatures deletes *all* rows matching a signature on replace-mine → use a **counted multiset** (string list with duplicates) and remove at most the count this connector wrote, so a manual/foreign row with identical values survives (identical rows are interchangeable, so count-capped removal is correct). (2) Provenance keyed only by connector id goes stale when *another* path replaces the table → key it **per table** and clear a table's provenance on any full-table replacement (another connector's replace-all, the table-fetch modal's `applyTableRows`), so a later replace-mine can't match stale signatures against unrelated rows. (3) After reload, provenance is gone — don't fake it; disable "Replace this connector's rows" and offer Append / Replace-all. The boundary held: persisted cross-session provenance is a table-data-model feature, not a `response_config` change.

**The editor must reject every config the runtime can't honor — Codex found these one read-path at a time.** The fan-out runtime supports things the first editor cut quietly mis-handled, and every gap was a silent save of an unrunnable/garbage-producing config: a cell-source filter the scalar-input modal can't resolve (restrict to literal/field); a multi-rows-output connector the modal only half-runs (enforce **exactly one** rows output); an unfiltered fan-out the completeness check wrongly dropped (make the filter optional for rows); a simple table's implicit `value` column missing from `tableColumns` (offer it, mirroring the cell picker); a stale/renamed column written as `[object Object]` (validate columns against the table's keys, drop+report); a blank-`from` column saved and read as the whole element (prune incomplete columns on save); a table-input fan-out that can't supply per-row inputs (reject table mode). The throughline: a "complete enough to save" check (`outputComplete`) is not the same as "the runtime will produce a correct result" — for a newly-added authoring path, walk each runtime branch and make the save-time validator reject anything that branch can't honor. Eight Codex rounds, fourteen P2s, zero CRIT/HIGH — the findings converged because each one closed an editor↔runtime gap, not because the design was wrong.

## §116 — Locale-pinned formatters, not bare `toLocaleString()`; one util beats five call sites (2026-06-13, v3.2.211)

`new Date(x).toLocaleString()` with no locale argument silently inherits the *browser's* locale, so an English admin UI rendered timestamps as「下午 11:38」on a Chinese-locale client. The fix is not per-site `'en-US'` sprinkling but one shared `formatDateTime` / `formatTime` (`en-US` + `hour12:false`, `''` for null/invalid) applied at all five admin timestamps. Two reusable lessons rode along in the same low-risk PR. **Per-page UI preference = a tiny hook + a dumb toggle, persisted by a namespaced localStorage key, best-effort.** `usePageWidth(pageKey)` reads/writes `fmb:pagewidth:<key>` inside try/catch (private-mode storage throws) and defaults narrow — the in-memory state still flips even if persistence fails. **A display-string rename is not a code rename.** Q11 collapsed page H1s to their nav short-names and changed exactly one *nav label* (`v3.2 Health`→`Platform Health`); the component name, file name, `/v32-health` route, and JSDoc stayed put. Touching only display strings (and the one sidebar test that asserts the visible label) keeps the diff out of Ship Gate's rename-audit and never breaks an existing bookmark — the churn-free way to rename what users *see* without renaming what code *is*.

## §117 — A "hover reflow" bug is fixed correct-by-construction: audit every hover for box-size change, not by reproducing the one instance (2026-06-13, v3.2.212)

The data-entry grid had a "columns jump on hover" report I couldn't reproduce in a browser this session. Instead of guessing, I grepped *every* `hover:` class in the grid and its subcomponents: exactly one changed box size (`FillHandle`'s `hover:h-2 hover:w-2`), every other was color-only (`hover:bg-*`, `hover:text-*`). That turns a "find the reflow" hunt into a closed proof — convert the lone size-hover to a transform (`hover:scale-150`, which composites and never touches layout) and *no* hover anywhere can reflow, whether or not that specific handle was the instance the user saw. A regression test pins the invariant (`className` must not match `/hover:h-/`). The reusable move: for a layout-jitter class of bug, enumerate the whole class of triggers (every hover/focus/active that can change width/height/padding/border-width) and neutralize all of them, rather than reproducing and patching one. Corollary for the *intended* affordance — a reveal-on-hover control (the Excel `↓`/`→` column/row select arrows) must reserve its space permanently: a fixed-width (`w-3.5`) slot that's always in the DOM and only toggles *color* (`text-transparent` → accent), never mount/unmount or width, so showing it is free of layout cost. "Always present, only color changes" is the same discipline as the fix and the affordance.

## §118 — Aligning two list surfaces: reuse the canonical's filter engine + path badge, and delete the columns that diverge (2026-06-13, v3.2.213)

The connector list and the template list had drifted apart (different columns, different toolbar order, a different header word for the same hierarchy path). Bringing them together was mostly *subtraction* plus *reuse*, not new code: drop the columns that only the connector list had (standalone Health, Endpoint, Auth — fold health into the Name cell as an inline icon), rename "Blueprint"→"Hierarchy Path" on *both* (a one-word display change, §116's discipline), and adopt the template's toolbar shape (filter row with New/Import on the right, count on its own meta row below). The reuse already existed from prior PRs — `TemplatePathBadges`, the `template-filter` engine via the `connectorToFilterable` adapter — so consistency was a matter of *calling the same helpers in the same order*, not re-deriving. Two design notes worth keeping: (1) a per-row "is this in a bundle" cell is its own tiny pure helper (`connectorBundleCell`) that mirrors the runtime grouping rule (group_id AND a concrete mode), kept out of the component so it's unit-testable and can't silently disagree with how bundles actually run; (2) making a list column read-only (Active badge instead of a toggle switch) *removes* a write path — the row no longer fires a full PUT — which is strictly safer and defers the edit to where the rest of the connector is edited. When two surfaces should match, the cheapest correct route is "same helpers, same order, delete the extras," not a parallel re-implementation.

## §119 — Owner-gating a new table = reuse the CRUD factory's opts + the ownership service allowlist; the plan's named mechanism may be the wrong one (2026-06-13, v3.2.214)

Opening connectors to the editor role with own-scoped writes turned out to be almost entirely *configuration of existing machinery*, not new permission code — `createCrudRoutes` already had `allowedRoles`, `ownerColumn`, `parentOwnership` (a chain DSL up to the owning blueprint), and `resolveOwnerName`; `applyOwnerChange` already had the `requireCondition` `any`/`self`/`null` discriminator and audit. The work was wiring, plus two corrections. **The plan's named mechanism was wrong, and reading the factory revealed it.** The plan said `writeScopeColumn: 'owner_id'`, but that opt's write-gate is `requireAuth` — it would have let a plain *user* role author connectors. The correct opt was the already-present `ownerColumn: 'owner_id'` (Bug-4 PR-B), whose gate honors `allowedRoles` (editor+admin, user excluded) while still stamping owner-on-create and scoping PUT/DELETE. Same outcome the plan wanted (write-own), opposite role surface — only visible by reading the two opts' gate code, not by trusting the plan's label. **A shared service needs the new table in its allowlist or it throws.** `applyOwnerChange` hard-allowlists tables (hierarchy_nodes/transformers/user_templates); `api_connectors` had to be added or the reassign route 500s on "unsupported table" — a deliberate guardrail (only owner-bearing tables) that's also a one-line gate when extending. **Two free wins fell out of the model:** owner-stamp-on-every-POST means a connector is *never* NULL-owned, so "forbid shared connector" needed no extra code; and relaxing the *template* reassign from admin-only to owner-or-admin was the identical `requireCondition: isAdmin ? 'any' : 'self'` + a `NOT_SELF → 403` branch, so connector and template share one tri-state shape (and one route-level matrix test parametrized over both). The lesson: before writing permission logic, read the factory and the shared service — the mechanism usually exists, and the plan's vocabulary for it may not match the code's.

## §122 — A correct backend permission can stay UI-unreachable because of a sibling admin-only dependency; the fix is a bounded version of that dependency, not a backend change (2026-06-14, v3.2.218)

PR-4 already let an owner self-transfer a connector or template at the backend (`reassign.js` / `schema.js`: `requireCondition: isAdmin ? 'any' : 'self'`). Yet the owner-facing UI stayed admin-only for a non-obvious reason: the transfer **picker** (`TransferOwnerDialog`) populated its target dropdown from the admin-only `GET /users` directory, so a non-admin owner literally couldn't load the candidate list — the Reassign menu was gated `isAdmin` to hide a dialog that would render empty/403 for them. The capability existed; its *prerequisite read* didn't. The fix was not to touch the (already-correct) reassign routes but to add a **bounded** version of the blocked dependency: `GET /users/assignable` — admin+editor, and deliberately a *narrower projection* than `/users` (`id, display_name, role`; no `email`, no `banned`/`created_at`; active only). It grants no new power (the reassign routes still re-validate caller and target); it only unblocks the read the UI needed. Three notes that generalize: (1) when widening who-can-see-a-feature, audit what *data reads* the feature transitively requires — a permission can be reachable in the API and dead in the UI. (2) The bounded endpoint must be a real narrower projection, not the admin one reused — `email` is PII here, so it's excluded at the SELECT, not masked after. (3) One bounded endpoint fixed two surfaces (connector **and** template reassign) because both used the same picker — the shared component was the choke point, so fixing its data source fixed everything downstream. Move banned-exclusion to the server (`WHERE banned = 0`) and the client filter that depended on the now-absent `banned` field simply deletes.

## §121 — Opening a second write path to a role means re-deriving the first path's authz, not just flipping the gate (2026-06-14, v3.2.217)

Relaxing the connector `io.js` routes from `requireAdmin` to `requireAdminOrEditor` was a one-token change for export and health — both are read-only/counts-only, so the gate flip *is* the whole fix. **Import was not**, and the reason is the lesson: import is a second *create* path. The CRUD `POST /` create route enforces, via `parentOwnership`, that an editor binds a connector only to a blueprint they own or that is shared. Import bypasses CRUD entirely (it has its own INSERT), so flipping its gate alone would have handed editors a create path with *weaker* authz than the canonical one — an editor could import a payload bound to a foreign blueprint that `POST /` would reject. The fix re-derives the same rule inline: for a non-admin importer, read `hierarchy_nodes.owner_id` and proceed only if the resolved blueprint is NULL-owner (shared) or === importer; **else reject 403** — never store unbound. The first draft *did* degrade to unbound (mirroring the unknown-blueprint fallback), and review caught why that was wrong: an editor-owned **unbound** connector is unmanageable. CRUD's editor PUT/DELETE ANDs an `EXISTS` ownership-chain that joins via `blueprint_id`, so a NULL blueprint yields zero rows → the editor can never PUT or DELETE it; only an admin could. `checkParentOwnership` already 403s an editor's null/foreign blueprint on create, and `reassign.js` already refuses to transfer an unbound connector to an editor — so degrade-to-unbound would have manufactured exactly the orphan those two guards prevent. Admin import keeps the unbound fallback (admins have no such chain restriction). The general rule: **when you open a role to a route that duplicates an existing guarded operation, mirror the canonical guard's *failure mode too* — not just its check.** The canonical path rejects; the duplicate must reject, not invent a "softer" degrade that drops the caller into a state the rest of the system treats as illegal. Two supporting notes: the missing-owner case (`bpOwner === undefined`) must fall to *not* own-or-shared (→ reject), the safe direction; and the test mock's SQL regex must match the production query string exactly, or the test passes against a query that never runs.

## §120 — A secrets-bearing detail view derives "Set / Not set" from a pure auth-shape map; never render the value, even masked (2026-06-13, v3.2.215)

The connector detail page shows auth config without ever leaking a secret. The discipline: a pure helper (`getConnectorAuthFields`) maps each `auth_type` to its fields and flags which are secret (`bearer:token`, `api_key:header+value`, `basic:username+password`) — the component renders a secret field only as a **Set / Not set** status, never its value, while non-secret fields (header name, username) show normally. Because the API already masks secrets to `****`, "Set" is simply "the masked value is non-empty" — but the helper still refuses to surface the value for secret fields, so even if an un-masked value ever reached the client it would not render. The test pins this directly: feed a plaintext secret and assert it appears nowhere on the page. Two smaller reuse notes: a read-only detail page is mostly *composition of existing display primitives* (`SectionCard`, `JsonViewer`, `TemplatePathBadges`, `connectorToFilterable`, `connectorBundleCell`, `formatDateTime`) — the only new code is the auth-shape map and the page shell. And adding `useNavigate` to a component that a test renders directly **breaks every test in that file** until the test wraps it in a `MemoryRouter` — a router hook is an implicit context dependency, so widening a component's router use is a test-harness change too.

## §123 — A masked-secret detail page can become editable without secret risk: exclude secrets from the editable doc + send a partial PUT, never the masked value (2026-06-14, v3.2.224–226)

The connector detail JSON tab became editable (parity with the template editor) even though connector payloads carry secrets the API masks to `****`. Templates have no secrets, so their JSON editor round-trips the whole doc; copying that naively would have let a user save the `****` masked value back over a real encrypted secret → silent data loss. The fix is two disciplines that compose: **(1)** the editable document (`connectorEditableView`) excludes `auth_*`, bundle membership (`group_*`/`sequence`) and `blueprint_id` — the user never sees a secret (masked or not) in the buffer, so they cannot edit or re-submit one; **(2)** save sends a **partial PUT** of only the editable keys present (`usePatchApiConnector`), relying on the backend PUT being a partial update (SET only body keys) so every omitted column — secrets included — is preserved untouched. The allowlist is enforced at *build* time: `parseConnectorEdit` iterates a fixed `CONNECTOR_EDITABLE_KEYS` set, so even a hand-typed `auth_config`/`owner_id` in the JSON is dropped before the body exists (defense beyond the backend's own non-admin `delete owner_id`/`blueprint_id`). Three traps review surfaced: **(a)** excluding bundle fields broke chain members — the backend's `validateInputFromStep` requires `sequence` whenever `request_config` has `input_from_step`, and its bundle-consistency check NULLs the whole bundle if `sequence` arrives without `group_id`; the fix injects the connector's *current* (unchanged) bundle quartet only when wiring is present, satisfying both checks without letting JSON retarget the bundle. **(b)** the outputs validator treated a present-but-non-array `outputs` as `[]`, which `/usable` would coerce the same way — silently wiping every mapping on a typo; distinguish missing (ok) from present-non-array (reject). **(c)** the backend does **not** re-validate `outputs[]` legality, so the client (`isLegalOutput` + fan-out/filter rules, reused from the structured editor) is the *only* gate — a raw-JSON edit path inherits that responsibility verbatim. General rule: **making a read-only secrets surface editable is safe when the secret never enters the editable representation and the write is additive (partial), not a full replace.**

## §124 — Reversing a leak-prevention default is safe when it is an explicit, labeled, per-field opt-in at the same chokepoint (2026-06-23, v3.2.302)

v3.2.297 fixed an *implicit* leak: a field hidden by a visibility rule or a variant `hide` override kept leaking its value into the generated output / save payload / connector reads, because the `selectVisibleValues` selector subtracted every `isHidden` field at the one consumer boundary. The follow-up request was the apparent opposite — let a designer *keep* a hidden field's value (e.g. an optional add-on sub-section toggled off but not meant to lose its filled values on save). The trap is to treat this as "undo the fix". It is not, and the discriminator is **implicit vs explicit**: the leak was accidental and global; the retention is a **deliberate, per-field, schema-level flag** (`retain_when_hidden`, default false) that a designer sets with a labeled toggle. The implementation is therefore a *one-predicate* change at the same chokepoint — `isHidden` → `isHidden && !retainWhenHidden` — so the default still discards (v3.2.297 preserved verbatim, guarded by a regression test) and the only values that now survive are ones a human explicitly opted in. Three design choices that kept it clean: **(1)** 2 modes, not 3 — "retain = persist in save AND flow to output" (the only real use-case wants both), so no split save-vs-output code paths; the rejected "stash-only" third mode would have needed two selectors. **(2)** the flag is **per-field** (one source of truth on `blueprint_fields`), governing *all* hide paths uniformly — a value can be hidden by the field's own visibility rule OR by a variant `hide`, and can originate from manual entry / default / autofill / compute, so a per-override or per-context flag would fragment the truth. **(3)** the toggle is surfaced in two editors (Field Editor when a visibility rule exists; Variant Policy for *any* override action, since the retained value can come from any of them) but both write the *same* field-level column — the second editor does a cross-entity write to `blueprint_fields` + query invalidation, not a new per-override field. BE cost of a persisted per-field boolean: a DDL column + an additive recover-policy migration + the dto-mapper `booleans` registry entry (auto-handles 0/1↔bool) + one mock-shape (`ALIGNED_BY_COLUMN`) in the schema-status-rollup test that enumerates every registered guard column. A trap caught in review: the instinct to *also* thread the column through clone (`blueprint-export.js`) and cross-env sync (`sync-schema.js`) for "completeness" is wrong — those paths write via a `dynamicPool` to a target DB that may not have run the migration yet, and a static column list there makes every upsert reference a missing column → `syncData` swallows the per-row SQL error → the fields silently vanish from the target. The established `depends_on_field_key` column omits both paths for exactly this reason; an additive column should ride the round-trip CRUD path (DDL+migration+dto-mapper) only, and re-derive to its safe default on any target that predates it. General rule: **a "reverse the safety default" request is safe to grant when you can make it an explicit, per-entity, labeled opt-in evaluated at the *same* boundary as the default — the safety property becomes "nothing leaks unless a human named it", which is strictly stronger than a blanket rule nobody can override.**

## §125 — A path allow-list's security lives in normalization, not in the glob; the URL constructor already clamps `..`, so the real bypass to block is the encoded slash (2026-06-24, v3.2.305)

Upgrading the connector egress allow-list from host-only to host+method+path raised a "do we hand-roll the matcher or use a library" question (picomatch was chosen). The useful lesson is *where the security actually is*. The glob matcher (`*` = one segment, `**` = any depth) only ever sees an **already-canonical** path; it is a benign string comparison and carries no security weight — so the library-vs-handroll debate is a correctness/parity choice, not a security one. All the security is in the **normalization step that runs before** the glob:

1. **`new URL()` already resolves and clamps `..`/`.`** for http(s). `https://h/a/../../etc` → pathname `/etc`; it can never escape *above* root. So a `..` traversal can only ever land the request at a path the allow-list also sees canonically — the gate and the eventual fetch agree. The hand-written dot-segment resolver is defence-in-depth (and unit-testable on raw strings), but for URL-sourced input the constructor has already neutralized the classic `../` escape.
2. **The encoded slash is the bypass that survives.** `new URL()` does NOT turn `%2f`/`%5c` into a path separator — it keeps them encoded in `pathname`. If you naively `decodeURIComponent` first, `/a%2f..%2fb` becomes `/a/../b` and a `..` re-appears *after* you thought you'd canonicalized. The fix is to **reject** a raw path containing `%2f`/`%5c` *before* decoding (a normal API path has no legitimate use for an encoded slash), rather than decode-and-allow. Decode-once-then-resolve-dot-segments after that rejection catches `%2e%2e` encoded-dot traversal too.
3. **Fail-closed everywhere a security setting is unreadable.** Absent/empty list = opt-in allow-all (don't break existing deployments); a present-but-corrupt value throws → 500, never silently collapses to allow-all. The legacy host-only array is auto-upgraded *on read* ("this host, any method, any path") and rewritten on the next save, so the format change needs no migration and has no enforcement window.

Two cross-cutting notes. **Parity:** a frontend live-validation mirror must produce the same allow/deny as the backend gate, so the glob library has to be the *same version* on both sides — picomatch resolved to v2 (root, via tailwind) and v4 (api) transitively; pinning `4.0.4` explicitly in both `package.json`s (and `@types/picomatch` for the TS side) is what makes "byte-compatible" true rather than aspirational. v2 also pulls `path`/`process.version` (browser-hostile); v4 only touches a guarded `process.platform`. **Error surface:** widening the gate from host to host+method+path means the old `HOST_NOT_ALLOWED` code now under-describes a block, so the new `EGRESS_BLOCKED` carries a `reason` (`host`/`method`/`path`/`normalize`) — the dimension that failed is exactly what the operator needs to fix the rule.

## §126 — A nullable "status" whose NULL means "approved" gives grandfathering + no-ALTER tolerance for free; approval state must be server-stamped, never trusted from the body (2026-06-24, v3.2.306)

Adding an admin approval gate to an existing, in-use table (`api_connectors`) has two traps that a single design choice disarms. **Trap 1 — the migration window.** If `status` defaults to `'pending'`, the moment the column lands every pre-existing connector flips to pending and production dispatch dies until an admin clicks each one. The fix is to make the column **nullable with NULL = "approved"** semantically: the dispatch gate blocks only an *explicit* `'pending'`/`'rejected'` (`if (status && status !== 'approved') block`). Pre-existing rows are NULL → keep dispatching; the app stamps an explicit status only on *new* writes. **Trap 2 — the no-ALTER operator DB** (the recurring `timeout_ms`/`retain_when_hidden` hazard): an additive column whose migration is skipped makes any column-enumerating SELECT 500. The same NULL-means-approved rule makes a *missing* column safe too — the dispatch loader keeps a fallback projection that drops `status`, so an absent column reads as `undefined` → approved → dispatch degrades to "no approval gating" instead of failing. One nullable column with a permissive NULL covers BOTH "old rows" and "old schema" with no backfill UPDATE and no version bump (the migration is an idempotent per-boot INFORMATION_SCHEMA-guarded ALTER).

The security core is **approval state is server-owned**. The editor sends the whole connector object on save, so the create/edit middleware MUST strip any client-supplied `status`/`approved_by`/`approved_at` from the body *before* the CRUD factory can persist them — otherwise an editor self-approves by injecting `status:'approved'`. Stamp the real value yourself (admin-create → approved, editor-create → pending) after the strip. Two more judgment calls: **(1)** re-pend on a *sensitive* edit, not any edit, or you punish a rename — and `auth_config` must be *excluded* from the sensitive-field diff even though it is security-relevant, because `serializeRead` masks its secrets, so the body's masked value never equals the stored ciphertext and would re-pend on every single save; `auth_type` (the credential *shape*) is the comparable proxy, and a pure secret rotation within the same shape is an acceptable non-re-pend. **(2)** an admin test-dispatch must *bypass* the approval gate (an admin verifies a connector before approving it), exactly like the existing `is_active`/breaker test bypass. Audit events for approve/reject are written direct (server path), matching the unregistered `connector.fetch.*` precedent — they don't need a feature-audit write-allowlist entry.

## §127 — "Dependency X is too old" is usually a transitive-dep proxy: audit the premise, then upgrade the real owner; a devDep-only runner bump still has two type-graph traps (2026-06-24, v3.2.322)

A backlog item read "evaluate the glob upgrade, 10.5 is too old." The premise did not survive an audit: `glob@10.5.0` was never a direct dependency — it came in transitively via `@vitest/coverage-v8 → test-exclude`, had no advisory and no deprecated `inflight`, and 10.5.0 was simply the latest of the v10 line. There was nothing to "fix" about glob. The only way to advance it was to upgrade its owner, so the task was really **Vitest 3 → 4**, which is the upgrade worth doing on its own merits (Vitest is the standard for a Vite + React + TS + ESM stack; it has no LTS line, so "current" just means the current stable major, 4.x). v4's `test-exclude@8` drops glob from the tree **entirely** — so #8 closed by *removal*, not a bump. General rule: a "package X is too old" ticket is usually a symptom; find who pulls X (`npm ls X`), confirm X is actually a problem (advisory? `inflight`? unmaintained?), and upgrade the *owner* — or close the ticket if the premise is false.

The upgrade is **devDependency-only** (Vitest never enters the production bundle or any container runtime path), so there is no real-image / deploy verification surface — the existing suite is the entire validation source of truth, and CI running it on v4 is the authoritative gate. But "devDep-only" does not mean "config-free": v4 had two type-graph deltas that a pure `npm install` + green-suite spike does not surface, because they live in `tsc`, not in the tests. **(1) Vitest 4 stopped *accidentally* pulling `@types/node` into the type graph** (a documented breaking change). The project's CI type-check `tsc -p tsconfig.app.json --noEmit` covers `*.test.ts` files that use Node APIs (`process`, `node:fs`, `__dirname`, and `Array.at` via @types/node's newer `lib` references), and the tsconfig had a *closed* `types: ["vitest/globals"]` array — under v3 those resolved ambiently through Vitest's type graph, under v4 they became 27 errors that would have turned CI red post-merge. Fix: add `"node"` to the tsconfig `types` array (`@types/node` was already a direct devDep). **(2)** `ReturnType<typeof vi.fn>` no longer satisfies the spy type — import the exported `Mock` type instead. Coverage also shifts: v4's v8 provider switched to AST-based remapping, so thresholds must be *re-measured*, not guessed (here lines/statements jumped up and branches/functions dropped — the code coverage was unchanged, only the measurement). The deferred-but-correct follow-up to the `"node"` fix is a separate `tsconfig.test.json` so node globals are not ambient on browser `src/`.

Process note (subagent-driven execution): the two type deltas above were each **missed or misdiagnosed by a per-task subagent** and only caught by verifying its claim against ground truth. The implementer reported the 27 tsc errors as "pre-existing, not v4-induced" (it checked the wrong signal — a `///` reference in the vitest tarball, when the pull-in is via the package type graph). The reflex to *trust* that, or to trust my own contrary memory ("I ran tsc=0 on main this session"), were both wrong — my earlier checks had read `${PIPESTATUS[1]}` / `$?` after a `| tail` pipe, which is *tail's* exit status, always 0, not tsc's. The truth came only from reproducing cleanly: checkout the BASE commit, re-run, count. The lesson generalizes past Vitest: when a subagent says "pre-existing / not my change," reproduce it on the base before believing it; and `cmd | tail; echo $?` lies about the command's exit — use `${PIPESTATUS[0]}` or `set -o pipefail`.

## §128 — Renaming a depth-derived ENUM value safely: expand→contract across two releases, and the early-return that neutralizes the downgrade re-stamp (2026-06-25, v3.2.323)

Renaming the top hierarchy tier Generation → Category touched a user-facing label, a wire/DB column (`user_templates.generation_id`), and an ENUM literal (`hierarchy_nodes.node_type` 'generation'). The label is free to change; the column and literal are a coordinated FE↔BE↔DB contract that cannot flip atomically across **onprem-then-airgap** deployments. The decision split into three layers and **two releases**: (1) display + FE-internal strings change immediately (zero risk); (2) the **expand** release adds the new column alongside the old + widens the ENUM to a 5-value superset accepting *both* literals + backfills data, retaining the old column/literal; (3) a **separate later contract release** drops the old column, narrows the ENUM, and deletes the dual-read scaffolding — shipped only after every environment, *including air-gapped internal deployments*, has run the expand. The hard rule the operator stated: never bundle the contract with the expand, because onprem verifies first and an airgap env that pulls the new image before its DB migrates would receive code that assumes "generation is gone" against a DB that still has it → boot break.

Three things made the expand robust and the eventual contract clean. **(a) Dual-column via `SELECT *`.** Because the read serializers are `SELECT *`, *adding* `category_id` next to `generation_id` makes the API expose both keys for free — no alias layer — and the FE keeps reading the still-populated `generation_id` during the window, deferring the read-preference flip to the contract. **(b) Top-tier identity is structural, not the literal.** The top tier is uniquely `parent_id IS NULL`, so `useHierarchyNodes` *drops the redundant `node_type` server-filter for the top tier* — that single change makes the fetch tolerant of both `'generation'` and `'category'` at once, which is exactly what a cross-env sync from an un-migrated peer requires (the peer's `'generation'` rows would otherwise be invisible to a `node_type='category'` filter on the migrated env, and the migrated env's boot backfill won't re-run to fix them). **(c) The downgrade re-stamp hazard is neutralized by an existing early-return, not new code.** The top hazard of a both-values-accepted ENUM is that an *old* image redeployed onto an expanded DB re-stamps `category`→`generation`. But the legacy VARCHAR→ENUM backfill (the only depth-derivation path that hard-codes the literal) early-returns `'already-enum'` on any migrated DB and never re-runs its `node_type` UPDATE — so the depth array's literal can't corrupt data on an already-ENUM column. Runtime node *creation* uses the explicit API value, not depth derivation, so the only behavioral change needed was: writes emit `'category'`, reads tolerate both. General rule: when renaming a value that is *derived* from structure (depth, parent chain, position), the structure — not the literal — is the stable key; lean reads on the structure and the dual-write window shrinks to almost nothing. And the schema-status guard's tight `expectedColumnType` string must move to the superset *in the same release as the widen*, or every migrated DB flips to `failed`. Note what the version gate does and does not do here: critical guard drift is surfaced *unconditionally* (it is NOT suppressed for DBs below the target version — only audit-skip entries are), so an un-expanded 4-value DB correctly surfaces `SCHEMA_GUARD_DRIFT` until its boot-time migration widens the ENUM. That is a feature: the drift is the pending-expand alarm, transient on a privileged DB (clears within the boot cycle) and persistent on an operator-mode DB that cannot ALTER (the correct state to flag). Do not write the guard expecting the version gate to hide the transition window — it won't.

## §129 — A "drops at the wrong tier" UI bug is usually mirrored on the server; the client guard is UX, the server guard is the fix; and extracting the drag decision into a pure function makes the testable half testable (2026-06-25, v3.2.338)

The reported bug was visual: in the Hierarchy Manager a Blueprint could be dragged onto a Category and land one tier too high (a sibling of Releases). The instinct is to fix the drop handler. But the same wrong-tier acceptance existed **independently on the backend** — `validateReparent` accepted `category`/`generation`/`release` as a blueprint's new parent, so a crafted `POST /reparent` (or any API caller) could do exactly what the UI bug did, with no drag involved. Lesson: when a client-side validation gap lets a structurally-invalid state through, **grep the server write path for the same rule before declaring the fix done** — a UI guard only stops the mouse, not the API. The real enforcement is the server check (`isValidBlueprintParent(parent.node_type)` → 400); the client `classifyDrop` block is UX courtesy. This is the same shape as the v3.2.333 reparent back-door (a guard that lived in only one of several write paths) — the recurring failure is *trusting a single enforcement point for an invariant that has multiple entry points*.

Two structural choices kept it clean. **(a) One tier rule, two consumers.** A pure `PARENT_TYPE` map + `isValidReparent` lives in `src/fmb/lib/hierarchy-tiers.ts`; the backend mirrors the narrowed form (`BLUEPRINT_PARENT_TYPES=['release']`, since the server only ever reparents blueprints) in `docker-api/src/shared/hierarchy-tiers.js`. Both are unit-tested with an exhaustive child×parent matrix, and each file's comment names the other as its mirror so a future tier change updates both. **(b) Pure decision extracted from the gesture.** The drag handler's branching logic became a pure `classifyDrop(active, over) → reorder | reparent | block` function. That is the dnd-kit testing reality (confirmed by scanning the sister product `pdx-platform`, which does cross-parent reparent with the same dnd-kit): the **gesture** (sensors, collision detection, onDragOver) is e2e-flaky and nobody unit-tests it — pdx tests only its pure reorder/guard helpers. So extract every decision the gesture needs into a pure function, unit-test that to death (own-parent no-op, each wrong-tier block message, the one allowed move), and accept the wiring is verified by manual/deploy smoke. The same pdx scan also settled a scope question: the user wanted destination rows to "make way" (open a gap) on cross-parent drop; pdx — which had every reason to build it — uses `DragOverlay` + a highlighted target, **not** literal child-gap, so the cheaper overlay+ring approach is the proven one, not a compromise. General rule for "reference how the other product did it": the absence of a feature in a mature sibling is itself a design signal.

## §130 — A best-effort guard probe is fine for a non-gating *display* but must NOT drive a *write that gates migrations*; and source the displayed app version from the one file every ship already touches (2026-06-25, v3.2.340)

The migration log/UI showed a stale `3.0.0`. Root cause: `platform_schema_version` is stamped only when **zero** migration steps are skipped, but the supported no-DDL operator topology (DBA applies ALTERs out-of-band; the app account lacks DDL grants) skips *every* step at the preflight early-return, so the stamp is never written and `current_version` reads the `3.0.0` initial fallback. The first instinct — and the approved plan — was "writing the stamp is DML not DDL, so derive alignment from the live schema and stamp it anyway." **Codex outside-voice review killed that**, and the finding was real (verified: `user_templates.category_id`, the just-shipped EXPAND column, has *no* `known_guard_column` in the registry). The trap: the guard probe only proves the *subset* of steps that declared guards. Stamping target from an incomplete proof, then hitting the `currentVersion >= target` early-return, would mark a partially-migrated DB "current" and **skip the missing DDL forever**. The lesson is the dividing line: a probe that proves only a subset is acceptable for a **read-only, non-gating display** (the admin `schema-status` endpoint already drove its aligned/degraded badge off this same probe — extending it to derive `current_version` for display adds no new risk), but it must **never** drive a **persisted write that gates future migrations** — a gating write has to be provably complete, and "best effort over the registered guards" is not. So: derive `current_version` from the live shape only for the endpoint's display (when the stamp row is absent); leave the migration runner's stamp logic untouched. Net structural win kept: the ~200-line probe was factored out of the route into `schema-version-derive.js`. Follow-up: completing the registry guard set (every versioned step) is what would make a derived *stamp* safe — tracked as a candidate, not smuggled in here.

The displayed *program* version had no source of truth (package.json was a stale `0.0.0`, git tags lagged). First attempt: derive it from `CHANGELOG.md` at build time (Vite `define`, hard-fail on parse miss) — appealing because CHANGELOG is the one artifact every ship updates, so "never drift." **That cost more than it looked, surfaced only by running the real artifacts:** (a) a real in-image `docker build` failed `"/CHANGELOG.md": not found` because `.dockerignore`'s blanket `*.md` kept it out of the build context — a local `vite build` can't catch this, which is precisely the Ship-Gate "real image boot" rule's point; and worse (b) Codex flagged that the **dist-source export forbids `*.md` entirely and CHANGELOG trips the enterprise-name leak check** — so CHANGELOG fundamentally *cannot* ship to operators, and the build-time read can't work in the AIRGAP/ONPREM topology without a build-arg plumbing detour. The lesson: "single source of truth" must be weighed against "ships everywhere without leaking" — a doc that can't leave the dev repo is a bad build input. The landing choice keeps both: the version lives in `docker-api/package.json` (a clean string that ships in every topology, read at runtime, surfaced via the schema-status endpoint as `app_version`), and a **mechanical Ship-Gate lint** (`version-sync-check.sh`, Step 18) pins it `== CHANGELOG`'s top shipped entry — so CHANGELOG stays the human source of truth and the package.json copy can never silently drift (forgetting the bump fails the gate, same "never miss" guarantee, without shipping the doc). Parsing gotchas that survived into the lint: skip planned rows (`| v3.3.0 | Planned… |`); and `grep … | head -1` under `set -o pipefail` dies with SIGPIPE (141) — use a one-pass `awk` instead.

## §131 — A self-guarded irreversible migration does NOT license removing read-tolerance in the same release: if the guard can leave a transition state, every reader must still tolerate it (2026-06-26, v3.2.341)

The generation→category CONTRACT (the EXPAND→CONTRACT pairing from §128) drops `user_templates.generation_id` and narrows the `node_type` ENUM to 4 values. The locked design had two halves: (1) an **in-migration self-guard** — before either irreversible DDL, `SELECT COUNT` the rows that still need the legacy shape; if any exist, skip both DDLs, keep the dual shape, hold the version, retry next boot — and (2) "remove dual-read / full rename, no tech debt." Half (1) is genuinely good and worked first try (live-verified on real MariaDB: dirty→skip, clean→drop+narrow, partial-recovery→finish-the-other-half). **The mistake was treating (1) as license for (2).** The self-guard protects the *data on the drop*; it does **not** protect the *new code* from meeting a not-yet-contracted DB — and because the guard can deliberately leave that state (operator-mode can't ALTER; a peer can sync legacy rows; the guard itself skips on dirty data), the new code WILL meet `'generation'` rows and a live `generation_id` column in supported states. Codex outside-voice caught three real consequences of removing tolerance: an **editor-escalation gap** (dropping `'generation'` from the editor `rejectFor` lets an editor create a top-tier node while the ENUM still accepts it), a **cascade-delete orphan** (matching only `category_id` misses templates linked via the retained `generation_id`), and a **divergent-link data-loss** (the guard's `category_id IS NULL` test passes a row whose `category_id` is stale-but-non-null while `generation_id` moved — the drop then discards the newer link; fix: refuse unless `category_id` *exactly* mirrors every non-null `generation_id`, i.e. `category_id IS NULL OR category_id <> generation_id`). The right model: keep tolerance **self-cleaning** — probe-gated dual-read (`['category_id','generation_id'].filter(col-exists)`) becomes `category_id`-only automatically once the column is dropped, so it is transition-safe, not lasting debt; the editor blocklist literal is inert once the ENUM is narrowed; a one-point read-boundary fold (`'generation'`→`'category'` in the fetch hook) keeps the rest of the frontend on the single post-rename literal without a union-wide revert. Verify-each-premise still paid: one Codex "crash" finding was a **false positive** (the icon lookup already had a `|| Default` fallback — degrade, not crash). And shared column lists bite both ways: putting `generation_id` back in the sync `cols` fixed the programmatic colSet-gated path but broke the **raw SQL-dump import** (not colSet-gated) into a contracted target — resolved by syncing `category_id` only and leaning on the EXPAND→CONTRACT operational guarantee (all envs past EXPAND before CONTRACT) for the one residual cross-major-version case. Also: an `alter-skipped` state must classify by errno (only 1142/privilege → the "fix your grants" hint; lock-timeout/disk-full must surface their real errno) or operators chase the wrong fix.

## §132 — Close the registry guard set so a "skipped" never reads as "aligned"; and give a deliberate skip its own audit code so it can't hide among real errors (2026-06-26, v3.2.342)

The §130 follow-up ("complete the registry guard set") is now done. The gap: `db.js`'s migration runner emitted audit rows for three version-gated steps (`owner_id_add`, `role_enum_expand`, `hierarchy_node_type_category_expand`) that had **no** `migrations-registry.js` entry. An unregistered step silently inherits the fail-safe `DEFAULT_FAILURE_POLICY='terminate'` + `DEFAULT_SEVERITY='critical'` — which is the *opposite* of what those steps actually do (all three are try/catch *recover* paths), and, worse, the schema-status visibility surface only probes drift for **registered** guard columns, so a DB missing one of those ALTERs could read falsely "aligned". The fix is mechanical (register each `recover`/`critical` with guard columns matching the post-migration shape), but the durable lesson is the **completeness invariant**: the registry is a parallel source of truth to the emitting code, and a silent gap between them degrades observability without any test going red. So the close included a test that enumerates every `step:` token `db.js` emits and asserts each is registered — a future unregistered step now fails the suite instead of quietly falling back to terminate/critical. (Two guard-set follow-ups stay intentionally open: the contract step has no guard column because column-*absence* is not expressible as an expected shape, and there is no guard for the pre-EXPAND cross-version sync case — both accept-risk, not gaps to close.) This completeness is also the precondition §130 named for a future derived-version *stamp*: a stamp can only be sourced from a probe that proves **every** step, not a subset.

Second, observability of *intentional* skips. The generation→category contract self-guard skips on dirty data and wrote `sanitizeMigrationError({}, step)` → an empty error → code `UNKNOWN`. An operator triaging `feature_audit` then can't tell a *deliberate* data-guard skip from a genuine failure — both read `UNKNOWN`. The fix: a distinct closed-enum code `DATA_GUARD_SKIP` (category `data_guard`), emitted **only** for the `dirty` state at the call site; the `not-enum` and real-error paths keep their real sanitized errno (a lock-timeout on the same step still maps to `LOCK_TIMEOUT`, not `DATA_GUARD_SKIP`). Lesson: a sanitizer's `UNKNOWN` bucket is for *unclassifiable* errors — a code path you control and *expect* (a self-guard refusing on purpose) deserves its own vocabulary entry, distinguished at the call site by state, not lumped into the catch-all where it becomes indistinguishable from a real fault.

## §133 — A client-sequenced DELETE-then-write is not a "save"; it's a half-write waiting to happen. Move multi-row reconciliation behind one server transaction — and remember a non-coalesced nullable column will trip every snapshot validator (2026-06-26, v3.2.345)

Three schema-builder "save" handlers did `schemaDeleteMany(...)` then dependent `schemaCreate`/`schemaUpdate` calls with no atomicity: a later-call failure left the DELETE already committed (section reorder could lose **all** section metadata; field delete orphaned options / broke `order_index`; option save dropped both the deletions and the new rows). The fix is the pattern the codebase already had for `blueprint_output_order` but had never generalized: a server-side `…/replace` endpoint that takes `{ expected, next }`, optimistic-locks `expected` against the live rows (→ `409 STALE_REVISION`), and reconciles to `next` (INSERT/UPDATE/DELETE) inside one `beginTransaction`/`commit`/`rollback`. Key design choices that mattered: key `field_options` reconciliation on the **row id**, not `option_value`, so the duplicate-value-alias rows survive; return the reconciled rows so the client can refresh its `expected` snapshot without a refetch (otherwise a just-inserted row has no id and a rapid second save sends `null` ids the validator rejects); use the **locking** linked-blueprint probe (`isBlueprintLinkedLocked`, FOR UPDATE) inside the write tx so a concurrent link-transition PUT serializes instead of racing.

Two lessons cost the most review rounds. (1) **Optimistic-cache poisoning of the lock baseline.** The section reorder writes the *same* React Query cache that feeds the `expected` snapshot; an effect syncing the baseline from that cache adopted the optimistic order → `expected === next` while the DB still held the old order → every reorder false-409s. The baseline must be advanced from *save success* and gated against the optimistic write — never re-seeded from the optimistically-mutated query. A jsdom unit test can't catch this (the mock doesn't model the shared cache), so it took Codex + live-verify; cache-interaction paths need a real-cluster check, same rationale as untested DnD gestures. (2) **Non-coalesced nullable columns break naive validators.** `blueprint_sections.sort_order` / `field_options.sort_order` / `blueprint_fields.order_index` are `INT NULL` and (unlike `blueprint_output_order.sort_order`) are *not* coalesced by the serializer, so a legacy/imported row sends `null` in `expected`; a `Number.isInteger(x)` guard rejected the whole save with `400 malformed`. Accept `x == null || Number.isInteger(x)`, and renumber with `ORDER BY <col> IS NULL ASC, <col> ASC` so null-ordered rows sort *last* (MariaDB's default puts NULL first, which would silently hoist them to the top on a delete-renormalize). When you replace a generic CRUD path with a typed endpoint, re-derive the column's true nullability from the DDL — don't trust the non-null TypeScript interface, which lies by Y-pattern convention.

## §134 — A MariaDB JSON column is auto-decoded by the driver — read tolerantly, because a unit-test mock conn cannot catch this (2026-06-26, v3.2.346)

### Durable lesson 1: the store-JSON.stringify/read-JSON.parse contract silently breaks for scalar strings when the column is typed JSON

`system_settings.value` is a MariaDB `JSON` column (`CHECK json_valid(value)`). The stamp writer does `JSON.stringify('3.2.341')` → stores `'"3.2.341"'` (JSON text). Fine. The mariadb node driver then **auto-decodes JSON columns** on read — so `rows[0].value` comes back as the bare JS string `'3.2.341'`, already unwrapped. The stamp readers called `JSON.parse('3.2.341')` (bare semver is NOT valid JSON, unlike `'"3.2.341"'`) → threw → the `catch` block returned `null` → schema-status showed `Degraded` with `current_version='3.0.0'` (the default), AND `runSchemaMigrations` re-ran every boot logging `from:3.0.0`. Old plain-LONGTEXT DBs are unaffected because the driver returns the raw JSON text `'"3.2.341"'` and `JSON.parse` succeeds. **The settings endpoint (`settings.js:103`) had already handled this exact case tolerantly (`try { value = JSON.parse(decrypted); } catch { value = decrypted; }`); the two stamp readers were the only strict outliers.** The fix mirrors `settings.js`: on `JSON.parse` failure, fall back to the raw value instead of returning null. Both the `_readCurrentVersion` function in `schema-status.js` and the inline stamp-read block in `runSchemaMigrations` in `db.js` received this fix. A unit test with a hand-fed mock conn feeds both driver shapes (`'"3.2.341"'` and `'3.2.341'`) and asserts both yield `'3.2.341'` — the bare-string case was RED before this fix and GREEN after. **Only a real-DB runtime verify caught this** — the mock conn test with `'"3.2.341"'` was already passing (JSON.parse succeeded), so the suite was green even while the production bug existed. The durable rule: any scalar-value read from a MariaDB JSON column may come back pre-decoded; write the read path to accept both forms. Specifically: a parse-fail on a string value should fall back to the raw string, not silently null it (the `settings.js` pattern is the template).

### Durable lesson 2: grep every generic-client consumer when a table moves routes

A blanket `schemaGet` (or equivalent generic-list endpoint) fetch helper that swallows errors (`404 → null`) obscures broken route choices. In v3.2.346, the sync-outputs flow fetched transformers via the **generic** `/api/schema/` router, which excludes transformers as a list-only-after-crud-checks policy; every 404 (the correct response for "transformer not in this generic list") was silently coalesced into `null` → the UI showed "Linked transformer not found" even when the transformer existed. Transformers have their own dedicated route module (`/edge/app/transformers`, reached via `/api/transformers`); `useSyncOutputs` was the only consumer still using the generic schema client. The fix: grep every consumer of `schemaGet` when the data type gains its own dedicated endpoint, audit whether they should re-route (transformers should, audit logs should not, etc.), and distinguish between "doesn't exist" (genuine 404) and "I can't reach it" (5xx/timeout → honest error toast). Query helpers that default errors to `null` are convenient but hiding — wrap them in domain consumers (one place per data type) where the choice is conscious.


## §135 — A green test suite + clean per-task reviews can still ship a non-functional feature when every test feeds object-shaped mock rows and stubs the outbound; the whole-branch review (capable model) is what catches it (2026-06-27, v3.2.358)

PR3 of the flow-recipes feature added a dispatch brain mirroring the shipped connector brain. It shipped through 8 subagent-driven tasks, each with its own RED→GREEN tests and a per-task code review, plus a full `node:test` suite (2259/0), `tsc` 0, and Ship Gate boot-smoke — all green. The final whole-branch review (opus) caught a **CRITICAL** the entire pipeline missed: the dispatch route loaded a step row with a raw `SELECT` and passed it straight into `decryptRow()` + `resolveRequest()` **without `mapRowsFromDb()`**. MariaDB returns `JSON` columns (`auth_config`, `request_config`, `allowed_hosts`) as **strings**; the connector brain it copied parses them first (`mapRowsFromDb('api_connectors', rows)[0]`), the flow brain didn't. Runtime consequence, all silent (no throw): `decryptAuthConfig` no-ops on a string → no auth header; `resolveRequest` reads `rc.headers`/`rc.body` off a string → `undefined` → no custom headers, empty body, the `{{payload}}` fill never runs. Every real dispatch would go out empty-body and unauthenticated — the headline deliverable non-functional. (Not a secret leak — the ciphertext stayed inert in the string — purely a functional break.)

**Why every gate missed it.** The unit tests stubbed `conn.query` to return rows that were **already JS objects** (the shape the route would have *after* mapping), and the infra test stubbed `forwardToEdge` so the edge `resolveRequest` never ran against a realistic string-typed `request_config`. So the tests asserted the gates (400/404/422) and the happy-path-with-pre-parsed-data, but **nothing exercised the real driver contract** (string columns) end-to-end. The full suite was green because the bug lives exactly in the gap the mocks paper over. This is the same failure family as §134 (a mock conn can't catch a driver auto-decode) and the recurring "verify a subagent's pre-existing claim against ground truth" rule: **a mock that returns the post-transform shape silently asserts the transform you forgot to write.**

## §136 — Persist-first run correlation closes the run_id↔row gap; a single-output-key contract and a best-effort cache write-back are the two other durable invariants of the FE orchestration path (2026-06-27, v3.2.359)

PR4 (FE orchestration) of the flow-recipes feature wired the full render→serialize→dispatch→persist→show-link pipeline entirely in the frontend, calling the existing PR3 backend.

**Persist-first run correlation.** PR3's dispatch audit rows carry a `run_id` field intended to correlate dispatch events with the run row in `flow_recipe_runs`. The gap: the run row didn't exist yet when dispatch happened, so `run_id` was always `null`. The PR4 `run-orchestrator` closes this by reversing the order: **(1)** POST a partial run (`status=partial`, no results yet) → the server assigns and returns the row `id`; **(2)** pass that `id` as `run_id` when calling the dispatch endpoint; **(3)** PUT to finalize the run row (`status=success/error`, `step_results`, `rendered_payload`) after dispatch returns. The server-assigned id from step 1 is always available by the time step 2 runs, so the audit tag and the row id are guaranteed to match. This is "persist-first" — writing the row before the work, then updating it — rather than "persist-last" (write after). The tradeoff: a partial row lingers if the client crashes mid-orchestration, but `status=partial` is a recognized terminal-failure state (no retry ambiguity) and the orphan cost is lower than a run with no matching audit trail.

**Single-output-key contract.** The `render-payload` lib enforces that the transformer output object must have **exactly one key**. A transformer that emits multiple keys is rejected before any dispatch attempt (returned as a user-visible error, not a runtime throw). The motivation: the payload serialization step maps the one output value to the wire body; multiple keys would require an arbitrary selection rule that the recipe has no column to encode. If a transformer is designed for multi-purpose use, the author creates a step-specific wrapper transformer that picks exactly one output.

**Serialize endpoint JSON envelope.** The serialize endpoint (`POST /api/flow-recipes/serialize`) returns `apiOk({text})` — a standard `{ok: true, data: {text: '...'}}` envelope — so the FE `apiInvoke` helper can unwrap it uniformly. The previous bare-text response required a raw `fetch` bypass; the envelope change (a one-line BE edit in PR4) lets `serialize-payload.ts` use the same `apiInvoke` pattern as every other FE → API call.

**Cache write-back is best-effort.** After a successful run, the orchestrator writes the result link and external ID back to `user_templates` cache columns (`flow_link`, `flow_external_id`, `flow_last_run_id`) via a PUT to the template endpoint. This write is **not awaited for the happy path**: the link returned by the dispatch response is shown to the user immediately, and the cache write fires in the background. If it fails, the run history page (`FmbFlowRuns`) still shows the run row (persisted in step 1–3 above), so the link is always recoverable. Making the cache write non-blocking keeps the UI responsive and avoids a scenario where a successful dispatch appears to fail because a secondary write timed out. The test pins that a cache-write failure does not surface as a run-orchestrator error.

**Scope boundary.** PR4 delivers the core author-flow path (generate output → build flow → view link + run history). Full recipe/step authoring UI (create/edit recipes and steps in the product) is deferred to PR5.

**Durable rules.** (1) For any code that consumes a DB row with JSON columns, the happy-path test must feed the row **as the driver delivers it** — JSON columns as strings — not as pre-parsed objects; assert a property that only survives correct parsing (here: the outbound request `body === '<filled payload>'`, which is `''` without the `mapRowsFromDb` call). The regression test added does exactly this and is RED without the fix. (2) When you copy a working sibling path (connector→flow), diff it line-for-line for the **non-obvious transforms** (`mapRowsFromDb` before decrypt) — the parts that don't show up as a compile error or a gate test. (3) Run the whole-branch review on the **most capable model** even after per-task reviews are clean: per-task reviewers see one task's diff against object-shaped mocks; only the cross-cutting reviewer reading the real driver/dto-mapper contract caught it. Per-task green is necessary, not sufficient.

## §137 — Relaxing a frontend visibility gate is not an authorization change: the backend route still decides. And an approval gate that fronts a dispatch path always hides a test-before-approve deadlock (2026-06-28, v3.2.361, PR5)

**Context.** PR5 added the in-product recipe/step authoring UI (blueprint-anchored, mirroring `api_connectors`) and fixed the author-test deadlock. Two durable lessons fell out.

**Lesson 1 — a dropped FE gate ≠ an opened backend.** The plan said "Build flow available to all roles," so the `BuildFlowButton` gate dropped `canEditSchema`. But the two endpoints the modal calls (`GET /flow-recipes`, `GET /flow-recipe-steps`) are `requireAdminOrEditor`, so a plain `user` got a 403 and saw zero recipes — the headline feature was non-functional for its intended audience. **Every unit test stayed green because the hooks mock `apiInvoke`** (same failure class as §135). The whole-branch security reviewer caught it by tracing the real route guards, not the mocks. Rule: when you change who can *see* an action, trace the full request path to who the *server* lets perform it — a client-side role check is UX, never authorization. And opening such a path safely is its own design problem (the shared list endpoint returns all-owner/all-status rows incl. `review_note`; a naive gate-loosen over-exposes it) — it deserves its own PR + security pass, not a tail-of-ship flag flip. We walked it back to admin/editor+owner and deferred the plain-user path.

**Lesson 2 — approval-fronts-dispatch is always a deadlock.** Wherever an approval status gates a dispatch path, the author can't test their pending item (gate blocks it) and the approver won't approve an untested item → stuck. The same admin-only `effectiveTest` one-liner deadlocked BOTH flow recipes and `api_connectors` (its Test button silently 422'd). Fix: widen the test bypass to *exactly* the edit-authority set — reuse the same ownership resolver the CRUD write-gate uses (here: admin, or `role==='editor'` AND (owns the row OR owns/shares its bound blueprint)), add a **role floor** so a `user`-role caller can never flip it, and keep the egress allow-list + SSRF pin firing in test mode as the real boundary. "May test a pending item" must equal "may edit it," enforced independently of the upstream CRUD gate so it can't drift.

## §138 — A "defense-in-depth" fix can silently *widen* the very scope it claims to protect; and a direct INSERT/UPDATE that bypasses the dto-mapper 500s on real MariaDB datetime — both are caught by outside-voice review, not green mocks (2026-06-28, v3.2.362, PR6)

**Context.** PR6 opened "Build flow" to plain `user` accounts: a narrow `requireAuth` `GET /flow-recipes/usable` projection for discovery + an infra-led server-run path (`run-begin` → `dispatchOneStep` loop → `run-finalize`), unifying all roles onto server-run and deleting the browser orchestrator. Built subagent-driven (8 TDD tasks, per-task review). Every task review and the full test suite were green; the whole-branch Claude review + two Codex rounds then found a CRITICAL and four P1/P2 — none visible to the mocked unit tests.

**Lesson 1 — a mitigation can reopen the hole it patches.** The original IDOR fix (cross-user write to `user_templates` via a client-supplied `template_id`) scoped the cache UPDATE to `WHERE id=? AND (owner_id IS NULL OR owner_id=?)`. The two insider reviewers and I reasoned "owner-or-shared, matching the writeScope pattern" — but the *actual* `user_templates` write contract (`schema.js`: non-admin UPDATE appends `AND owner_id = ?`) is **strict self**: a NULL-owner row is NOT writable by non-admins. The `OR owner_id IS NULL` branch I added as "defense in depth" *widened* access — any authenticated user could overwrite a shared template's flow cache. Codex caught it. Rule: before scoping a write "like the existing guard," read the existing guard's actual SQL — don't infer the predicate from the column name or a half-remembered convention. `OR <permissive>` in a security predicate is a smell; the correct fix here was strict `owner_id = actor_id` (+ admin bypass at the gate).

**Lesson 2 — bypassing the dto-mapper breaks real-DB writes that mocks never exercise.** `run-begin`/`run-finalize` did direct `INSERT/UPDATE` binding `new Date().toISOString()` (`…T…Z`) into DATETIME columns. The project's dto-mapper normalizes timestamps to `YYYY-MM-DD HH:mm:ss`; these statements bypassed it, so strict-mode MariaDB rejects the value → 500 *before* dispatch. Same class as the v3.2.360 hotfix and §135: the mocked pool tests can't see a real-schema rejection. Fix: stamp server-clock timestamps with SQL `NOW()` (also kills the null-`mode`-into-NOT-NULL-ENUM 500 by defaulting). **The only thing that proves a persistence path works is running it against the real DB as the real role** — live-verify as plain `testuser` (run own template → 200 persisted, foreign template → 403 `TEMPLATE_FORBIDDEN`, upstream 405 → run honestly `failed`) is what closed PR6, exactly as the feature's recurring lesson predicted.

**Lesson 3 — the unify call was right, and cheapest done now.** The user anchored on "do what `api_connectors` does" — connector has a narrow `usable` projection + server-side dispatch for *all* roles, no browser-run path. Unifying (deleting the browser orchestrator) rather than keeping two paths put the run logic where real-row `node:test` exercises it and removed standing debt while the feature was still single-step MVP (cheapest point to consolidate). Two execution paths for one operation is the debt; "it already works in the browser" is not a reason to keep it.

## §139 — A "green run" can be hollow: assert what actually left the system, not just that the call returned 2xx; and a backlog item written one PR ago may already be stale (2026-06-28, v3.2.364, flow demo)

**Context.** First true end-to-end demo for the flow-recipe feature: a k3d e2e on the windfarm fixture builds a blueprint-bound recipe + a bearer step that POSTs to a dev mock-api, runs it server-side, and asserts the upstream-assigned link/id are extracted and the run row is persisted+masked. The mock-api gained a `/flow-run` route that echoes the received body and returns `{id, link}`. Also a small FE fix surfaced a previously write-only cache column.

**Lesson 1 — a 2xx run is not proof the payload left the system.** The first green run reported `success` and extracted a real `link`/`id` — but the mock-api's container log showed it received `{}` (empty body). The dispatch builds the request body by `fillTemplate(request_config.body, {payload})`; with no `body` template the body resolves empty. The mock returns `{id,link}` regardless of what it receives, so the run *and every DB assertion* passed while nothing meaningful was sent. The hollowness was only visible by reading the upstream's own record of what it got (`docker logs … | grep flow-run`). Rule: for any egress feature, assert the *receiver's* view (echoed body / upstream log), not just the caller's status — a permissive mock makes "it returned 200" worthless. The fix was `request_config.body = '{{payload}}'`.

**Lesson 2 — ordering against side effects: approve AFTER the child write, delete children before parents.** Two real ordering bugs the green run hid: (a) creating a step **re-pends** the parent recipe to `pending` (the `parentRepend` control), so approving at recipe-create time is silently undone by the next step write → the run gate then 422s `RECIPE_NOT_APPROVED`; approval must come after the steps are finalized. (b) e2e cleanup deleted the recipe but `flow_recipe_runs` has no FK cascade (orphan run history), and the transformer hard-delete 409s `REFERENCE_CONFLICT` while its blueprint still references it — so cleanup must delete runs explicitly and delete the transformer *after* the hierarchy cascade. A shared-suite e2e that leaks rows is a slow-burn failure; verify "clean" by querying the real DB for your own artifacts after a run, not by trusting `.catch(()=>{})` best-effort deletes.

**Lesson 3 — re-verify a backlog item's premise before building it; PRs age it.** The plan opened by proposing to fix two "demo-blocking" LOW items from the backlog (finalize-PUT-failure toast; `onComplete` not wired). On inspection of the *current* code both were stale: PR6 had unified onto server-run, so there is no FE finalize-PUT at all (the modal already branches on the server's terminal status); and `onComplete`'s real value wasn't "refresh after build" but exposing a write-only dead cache (`user_templates.flow_link/...` was written by run-finalize, returned to the FE via `SELECT *`, but never read or displayed). Backlog entries are snapshots; a feature that moved underneath them can make a "known gap" obsolete or mis-framed. Read the consume path before implementing the fix — same discipline as [[feedback_verify_review_feedback]] applied to your own backlog.

## §140 — A deadlock-ordering sort must canonicalise to the DB's collation: case-insensitive `CHAR(36)` ids sorted case-sensitively in JS still deadlock (2026-06-28, v3.2.365)

**Context.** `parentRepend` (the flow-recipe-steps → parent-recipe re-pend control) re-pends TWO parents on an admin re-parent (the stored parent + the new destination). The two rows are locked `FOR UPDATE` in sequence, so two concurrent opposite-direction re-parents could acquire them in reverse order and ABBA-deadlock. The fix: sort the two ids before locking, so every transaction acquires them in one global order — the same trick `isLinkedParentLocked` already used.

**Lesson — "sort before locking" is only deadlock-safe if the sort key matches how the DB identifies the row.** The parent ids are `CHAR(36)` UUIDs under MariaDB's default collation, which is **case-insensitive**: `'A1B2…'` and `'a1b2…'` are the *same row* and the same lock resource. But JavaScript `String.sort()` / `Set` are **case-sensitive** (ASCII: `'Z'` < `'a'`). The destination id comes from the client request body (uncontrolled case) while the stored id comes from the DB (whatever case was persisted). So two concurrent re-parents over the same logical pair, one passing the destination uppercase and one lowercase, sort the identical pair of rows into *different* JS orders → reverse lock acquisition → the deadlock the sort was meant to remove survives. A plain `.sort()` passed every unit test (all fixtures used one case) and the first reviewers; only the outside-voice (Codex) flagged it as P2. Fix: de-dupe + sort by a canonical key — `String(id).toLowerCase()` — keeping the original-case value for the query (the DB matches either case). Rule: whenever a language-level ordering or set-membership is used to enforce a DB-level invariant (lock order, dedupe, uniqueness), the key must be normalised to the column's collation/comparison semantics, not the language's default. Same class of bug as comparing trimmed/normalised strings on one side of a boundary but not the other.

**Test shape.** The property is observable in the emitted statement stream, so it's tested deterministically (not via a flaky real-InnoDB deadlock race): drive the real `createCrudRoutes` PUT handler with a statement-capturing connection, capture the `params[0]` of each parent `FOR UPDATE` SELECT, and assert the lock order equals the canonical-sorted order regardless of which id is stored vs destination and regardless of case. RED-verified by reverting the sort (issue-order) and the canonicalisation (case-sensitive sort) independently. A statement-capturing mock is the *right* tool here precisely because the invariant is "what SQL does the handler emit, in what order" — not a runtime semantic the mock would fake away.

## §141 — When one reusable primitive serves three callers, the editor that assumes a single caller becomes a dead-end for the others; author in-context instead of referencing a shared row by id (2026-06-29, v3.2.368, Flow Recipes UX PR1)

**Context.** A single `transformers` table served three roles: blueprint form transforms (linked via `hierarchy_nodes.transformer_id`), connector response transforms (embedded in `api_connectors.response_config`), and flow payload transforms (referenced by `flow_recipes.payload_transformer_id`). But the standalone transformer *editor* assumed every transformer is blueprint-bound — it reads the linked blueprint's live field list to drive autocomplete. A transformer created for flow/connector use therefore had **zero** linking blueprints and tripped the `OrphanGuard` ("This transformer has no linked blueprint"), which *refused to load the editor*. The feature you built the transformer for could not edit it. The UX also forced the user to paste a raw UUID into the recipe form to wire it up.

**Lesson — a shared primitive is fine; a shared *editor* that hard-codes one caller's assumptions is the trap.** The orphan dead-end wasn't a transformer-model problem, it was an editor-context problem: autocomplete needs to know the input shape, and only the blueprint caller had a place to get it. The fix wasn't to make the editor tolerate orphans — it was to recognise that a flow payload transform's input shape is *already known from its own context* (the recipe's blueprint output keys / `consumed_output_keys`), so it should be **authored inline on the recipe** (`payload_transform_code`), not created as a standalone row and referenced by id. Inline authoring dissolves the whole problem at once: no UUID to paste, no orphan state possible, no "manage transformers" surface to get lost in, and one fewer FK + one fewer FE round-trip (`usable` ships the code, not an id to re-fetch). Connectors were never actually victims (they author inline in the connector editor already) — only flow paid the standalone-row tax. Rule: before adding a picker/reference UX for a shared entity, ask whether the consumer's context already determines the entity uniquely; if it does, author it in place — a 1:1 inline field beats a many:1 reference whenever reuse isn't a real requirement (it wasn't here — the user confirmed no cross-recipe reuse).

**Migration note.** The feature was pre-release (zone-test only, no production rows), so this was a clean rename, not an EXPAND→CONTRACT: a single idempotent boot migration (`flow_recipes_inline_transform_code`) ADDs `payload_transform_code` and DROPs the legacy FK columns, gated by bumping `PLATFORM_SCHEMA_VERSION` so the (all-idempotent) migration block re-runs on the one existing DB. The "no prod data" fact is what made "change the DDL directly" safe — the same change against a populated table would have needed a backfill of inline code from the referenced rows first.

## §142 — When the visual system is fixed ("reuse X exactly"), the design risk is information architecture, not style — run an IA gate, not a mockup-variant gate; and the comprehension lever for a code field is a live preview built from a real sample, not better copy (2026-06-29, v3.2.369, Flow Recipes UX PR2)

**Context.** PR2 turned a four-stiff-fields recipe editor (paste a UUID, hand-type a CSV, two raw JSONPath fields) into a single-page builder that a non-engineer can drive without docs. The plan mandated two design gates. The instinct for "design gate" is the mockup-variant flow (generate 3 styles, compare board, pick one). That was the wrong tool here: the hard constraint was "match the Templates/Connectors visual language **exactly**", so style was already decided — generating novel variants would have produced work to *throw away* and, worse, drift from the system it must match.

**Lesson — pick the gate to the actual risk.** A change that reuses a fixed visual system has near-zero style risk and high information-architecture risk: does the layout teach the mental model, are all the non-happy states designed, can a first-timer self-serve? So the gate that pays off is an IA/mental-model critique (an outside design voice reviewing the *layout sketch + state list*), not a pixel-variant board. The IA gate caught the load-bearing gaps that a style board never would have: the "biggest comprehension lever" (a live preview) had **no sample-record selector** specified — the feature depended on an input the layout never provided; the blueprint picker was a hidden "Stage 0" drawn as a peer form field; the preview was implied to live only in the code mode when the *no-coder needs it most*; code-error UX, delete affordance, empty state, and saved-key drift were all unspecified. Fixing those before writing the component is the whole point of a pre-code gate.

**Lesson — make the abstract concrete with real data, not words.** The single highest-leverage move for a "write code here" field aimed at non-coders is a **live preview rendered from a real sample record through the exact runtime path** (here: a chosen template's `generated_outputs` → `renderFlowPayload` → sandbox). It turns "I don't know what this code does" into "I can see the message that will be sent." Two corollaries that fell out: (1) the preview must render in the no-code mode too (the auto-bundle is invisible otherwise), so "Send-as-is" persists a sentinel-marked generated body and runs through the *same* render path as custom code — preview equals reality in both modes with no branching; (2) errors must degrade to plain language while keeping the last-good preview, because a non-coder who breaks the code and sees the page die has no recovery path. Rule: when a field is intimidating, don't explain it better — show its real output.

## §143 — "Mounted-but-hidden to preserve state" breaks the moment a second copy of the same component renders elsewhere: lift the shared state and keep exactly one instance, don't run two (2026-06-29, v3.2.378, Flow Recipes UX PR3)

**Context.** PR3 moves the Prepare-data code editor into a full-screen in-page sub-page. To preserve in-progress stage-③ step edits across the open/close, the builder body is kept mounted and merely hidden (`display:none`) — the same remount-avoidance idea PR2b used for the layout toggle. But the sub-page also needs the live preview, so the obvious move was to render a second `PreparePreview` inside the workbench while the builder's copy stayed mounted-hidden. Three reviewers (and the design's own comment) converged on the same fault.

**Lesson — "hidden ≠ harmless" when the component owns local state or runs work.** A mounted-hidden subtree is still *live*: its hooks still fire. Rendering a second copy of a stateful component alongside the hidden first copy produces (a) **divergent local state** — the workbench's sample selection lived in its own instance and was discarded on close, directly contradicting the "selection survives" claim; (b) **double work** — two `useLivePreview` debounce+sandbox loops ran every keystroke, one for a pane nobody can see; (c) **CodeMirror-in-`display:none`** — CM6 measures geometry lazily, so a hidden editor re-displays blank until a resize forces re-measure. The clean fix is structural, not patch-on-patch: **lift the shared state to the common parent** (here `sampleId` → `FlowRecipeBuilder`, passed controlled to both surfaces) and **guarantee exactly one instance is mounted** (a `previewSuspended` flag unmounts the builder's copy while the workbench owns the sole one). That single decision dissolved all three findings at once. Keep the mounted-hidden trick only for subtrees with *no* sibling copy (the step list).

**Lesson — an in-page view swap is a dialog for accessibility purposes; manage focus both ways.** Swapping the visible region via a `hidden` class silently drops focus to `<body>` (browsers eject focus from a `display:none` subtree), and closing never returns it. Treat open/close like a dialog: focus into the new surface on mount (the Back button), and restore focus to the trigger on close — the trigger stays focusable precisely *because* the body is hidden-not-unmounted, so a ref to it survives. Also: a "reactive" derived value must actually subscribe. The `isDark = useMemo(() => …matchMedia().matches, [theme])` idiom samples the OS preference once and never updates in system mode; extracting a `useIsDark()` hook that listens to the `matchMedia` `change` event *unconditionally* (not only while in system mode) keeps it current the instant the user switches to system.

**Lesson — build the reusable shell thin, with the variant parts as slots.** The workbench is meant to be reused by PR5's per-step JS editors. The reuse held up under review because it was kept a *generic shell* — header + resizable split + left code editor — with the caller-specific parts injected as props: the right pane is a `preview` ReactNode slot, the completions arrive as `editorExtensions`. No PR5-specific logic leaked in (no speculative branches), and no caller-specific preview/completions logic stayed trapped inside it. Extract the shell, slot the specifics.

## §144 — Adding a column is a cross-feature read-path audit, not a one-file edit; and the same sandbox output decodes differently per consumer (2026-06-29, v3.2.379, Flow Recipes UX PR4 — chaining engine)

**Context.** PR4 added the step-chaining engine: per-step before/after JS + a `compute` step (all run in the browser sandbox, zero server eval), named-output context threading, a `runs_on` create/update guard, and an owner-scoped reset. Additive columns `step_type`/`before_code`/`after_code` (steps) + `runs_on` (recipes), schema 3.2.379. Backend reviewed by 4 Claude reviewers + 2 Codex rounds.

**Lesson — an additive column on a read-hot, multi-path table must make EVERY enumerating SELECT tolerant, including sibling features you weren't thinking about.** The v3.2.300_303 rule ("make column-enumerating paths tolerant on no-ALTER DBs or omit") is easy to apply to the obvious paths and easy to miss on the rest. I added a `selectWithLegacyFallback` (try full projection → on errno 1054 retry the legacy projection) to run-begin's recipe + step SELECTs and run-finalize's step SELECT — then Codex R2 caught two I'd missed: (1) the **approval re-pend** middleware's recipe SELECT (a *different feature*) now named `runs_on`, so on a DB where only that ALTER was skipped it 1054'd into the catch that silently `next()`s — letting an editor change an approved recipe's code with no re-review; (2) the **template ownership** SELECT now named `flow_last_run_id` with no fallback → every template-backed run 500'd on a no-ALTER DB, including JS-free recipes that worked before. The fix is mechanical (fallback everywhere) but the *discovery* is the lesson: when you add a column, grep every SELECT that will name it across all features (CRUD, approval lifecycle, cache, status probes), not just the feature you're building.

**Lesson — Codex's second round found only regressions introduced by the first round's fixes.** R1 surfaced 6 issues; fixing them spawned 3 new ones (the incomplete no-ALTER sweep above). After a fix round, re-scan the *same class* of issue across every path the fixes touched plus their siblings before declaring done — a partial application of a cross-cutting rule is its own bug.

**Lesson — the sandbox `{ outputs: { key: jsonString } }` contract is JSON-encoded, so a consumer that feeds string interpolation must re-serialize objects, not pass the parsed value.** ② Prepare-data parses the single output into the whole payload object — correct there. But a step's before-JS produces request fill variables consumed by `fillTemplate` via `String(value)`. Passing the *parsed* value means an object fill (the documented `payload: JSON.stringify(payload)` idiom, decoded back to an object) stringifies to `"[object Object]"` inside `{{payload}}`, corrupting the body. The fix: for fill inputs, re-`JSON.stringify` objects/arrays and pass scalars through for `String()` to coerce. Same sandbox output, two consumers, two decode rules — make the decode match the consumer.

**Lesson — a durable state marker must be a value that is always set on the event, never one that can legitimately be null.** Create/update routing derived "was this record pushed?" from `flow_external_id`. But a successful *update* that returns 204 / omits an id writes `flow_external_id = null` on finalize — so the next run misreads the record as never-pushed and reclassifies it `create`. The durable signal is `flow_last_run_id`, stamped on *every* successful run regardless of response shape. Pick the monotonic always-present marker, not the semantically-meaningful-but-optional one.

**Lesson — a finalize that hard-requires an HTTP 2xx wrongly fails a path that performs no HTTP.** A compute-only chain dispatches nothing, so `upstream_status` is null and `ok && is2xx` is false despite every computation succeeding. For a browser-orchestrated run the client already enforced each step's 2xx and reports the verdict via `ok`; trust it (`ok && (requiresClient || is2xx)`) rather than re-deriving success from a status that path structurally never produces. Re-derive server-side only for the path that actually produces the signal (the legacy server loop).

## §145 — A test surface that can't reuse the production gate needs its own honest orchestrator; and "preserve the side-effect that already happened" is the through-line of the review findings (2026-06-30, v3.2.380, Flow Recipes UX PR5 — step editor + test UI)

PR5 put a connector-grade authoring UI over PR4's chaining engine: a full-screen step editor (Request / Before-JS / After-JS tabs + a per-step test pane) and a whole-chain test runner. FE-only, no backend change. Shipped `bcc0d3a8` (#481), LIVE-verified on zone-test (per-step + whole-chain real dispatch to postman-echo → HTTP 200 / Chain succeeded).

**Lesson — when the production path gates on a state the author doesn't have yet, the test path must be a separate orchestrator, not a reuse.** The obvious move was to reuse `run-chain.ts` (run-begin → dispatch → run-finalize) for the in-builder test. But `run-begin` hard-gates `status === 'approved'`, and an author testing a recipe is by definition still editing an unapproved one. The single gap that *is* open to an owner is `POST /flow-recipe-steps/:id/dispatch` with `test:true` (edge `effectiveTest = test && callerCanManageRecipe`, no run row, SSRF/egress still enforced). So the test surfaces are a **client-side test orchestrator** (`step-exec.ts` `runStepTest`/`runFlowChainTest`) that loops over `dispatch test:true` and threads ctx — bit-for-bit the same per-step JS as production (extract the shared `runStepCode`, don't fork it) but a deliberately *different lifecycle*. Generalise: before reusing a production path for a "try it" affordance, check what the production path gates on; an authoring/test surface frequently lacks exactly that precondition.

**Lesson — every review finding in this PR was a variant of "don't erase or duplicate a real side effect."** Codex (2 rounds, all P1s fixed before ship) kept finding the same shape: (1) after a step *create*, the editor stayed open but kept `stepId === null`, so the next Save called create again → a duplicate step that would later dispatch twice (fix: update the just-minted `savedStep.id`); (2) when the real request *succeeded* but the after-JS threw, the catch returned the empty base result, erasing the upstream status/body — hiding that the external record was already created, inviting a duplicate retry (fix: preserve the dispatch state, report only the extraction error); (3) the chain runner's Back unmounted mid-flight while `runFlowChainTest` kept firing real requests (fix: disable Back while running); (4) running against a steps query still refetching could dispatch stale config (fix: also disable on `isFetching`). The unifying invariant for any test surface with real side effects: **a fired request must be visible and un-repeatable** — never swallow its result on a later error, never let a second trigger fire it again.

**Lesson (process) — verify "this matches production semantics" with a parity test, not by eyeballing the extraction.** The shared `runStepCode` re-serialises object before-outputs to JSON before `{{var}}` filling (§144's per-consumer-decode trap). A test asserting `requestInputs.payload === '{"a":1,"b":"x"}'` (not `[object Object]`) locks the test path to the production path; without it the two drift silently.

**Lesson (live-verify gotcha) — driving a React controlled input from `el.value = x` poisons React's value tracker.** During cold-load verification, setting an input's `.value` directly then dispatching `input` did nothing (button stayed disabled) because React's internal tracker already held that value and suppressed the synthetic `onChange`. The reliable headless pattern is the native setter to a *different* value first, then the target value, each followed by a bubbling `input` event — or just use the browser tool's real keystroke `fill`. (Also: the in-builder test pane requires the step **saved + clean** before testing, so the dispatch always reflects stored config — confirmed live that the gate disables the button until save.)

## §146 — Mirroring a single-entity port to a multi-entity one re-opens fan-out costs the original never had; and "strip the secret" must mean "strip every secret leaf, not just the one for the current type" (2026-06-30, v3.2.381, Flow Recipes UX PR6 — export/import)

PR6 added cross-environment export/import for a flow recipe **and its steps**, mirroring `api-connectors/io.js`. Self-contained JSON bundle (recipe meta + inline code + steps + blueprint lineage path), secrets stripped, blueprint re-bound by lineage (no raw UUID), egress checked per step at import. Backend + FE. Shipped `<sha>` (#<pr>).

**Lesson — a "mirror" of a single-row port is not safe to copy 1:1 when the new entity fans out.** The connector io imports one row; the recipe io imports one recipe + N steps. The single-entity reference had no step loop, so it never needed: (a) a transaction (one INSERT is atomic on its own — the recipe port needed `beginTransaction`/rollback so a mid-step failure can't leave a half-imported recipe), or (b) a count cap (one egress probe per request vs. one *per step* — an unbounded `steps[]` turns into thousands of `system_settings` SELECTs from a single authed request). Both Codex-class reviewers (Claude security + code) independently flagged the unbounded fan-out. Generalise: when porting an established single-entity pattern to a collection, re-audit every per-item cost (DB round-trips, validation passes, transaction scope) — "it mirrors the reference" is exactly why the new fan-out goes unnoticed.

**Lesson — `stripAuthConfigSecrets` only removes the leaf for the *declared* auth_type, so a stale leaf from a since-changed type survives the strip.** Export called `stripAuthConfigSecrets(cfg, 'none')` → `pathsFor('none')` is `[]` → no-op → a lingering `{token: 'enc:v1:…'}` (left when the step's type changed away from bearer) rode out in the bundle. The fix is to run `stripStraySecretLeaves` (drops every leaf not belonging to the current type) **before** `stripAuthConfigSecrets` (drops the sanctioned leaf) — together they guarantee no secret survives even on a row that predates the write-path's own stray-leaf strip. Generalise: "strip the secret" is the wrong mental model for a type-tagged secret bag; the correct one is "remove every leaf that is a secret OR doesn't belong here." Applies to both export and the import clean-pass (a hand-edited bundle can inject a stray leaf too).

**Lesson — the authoritative no-ALTER column split is whatever the *run path* already fences, not what you re-derive from migrations.** The recipe/step tables have several additive columns across two migrations; rather than reason about which a legacy DB might lack, the run path (`flow-recipes-run.js`) already encodes the answer via `selectWithLegacyFallback`: only `runs_on` (recipe) and `step_type`/`before_code`/`after_code` (steps) are peeled; everything else is treated as base once the flow feature exists. The export SELECT and import INSERT mirror that exact split (core INSERT names base columns only; the additive group via best-effort 1054-tolerant UPDATEs). Reusing the live read path's split — instead of re-deriving from the migration registry — keeps the port consistent with how production already degrades and avoids a divergent, over-cautious fallback set (§144's cross-read-path-audit lesson, applied in reverse: read the canonical fence, don't invent a new one).

## §147 — When you generalise a hardening, the sibling paths have edge cases the original never hit; and surgery on a URL belongs to the URL parser, not a string scan (2026-06-30, v3.2.382, portable secret-redaction hardening)

Followed PR6 by lifting its three secret-redaction primitives (`isStorableHttpUrl` reject-userinfo, `sanitizeUrlForExport`, `redactRequestConfigHeaders`) into a shared module and wiring them into the sibling connector io + connector/step CRUD url guards + clone. Shipped `4c926846` (#484).

**Lesson — a `new URL().href` round-trip percent-encodes the path, so any `{{template}}` token gets mangled; but a hand-rolled string scan of the authority is worse.** My first `sanitizeUrlForExport` used `u.href` → `{{id}}` became `%7B%7Bid%7D%7D` and the dispatch engine (which matches literal `{{...}}`) could no longer resolve it. My second attempt scanned for `://` and the last `@` to strip userinfo by string surgery — Codex R2 then found it (a) missed backslash-form authorities (`https:\\user:pass@host`, which WHATWG still parses as credentials) and (b) picked the WRONG host on an embedded-`@` url (`https://u:p@allowed.example\@blocked.example/x` → took `blocked.example`). The robust answer is the smallest one: let WHATWG `new URL()` do ALL the parsing (it normalises backslashes, terminates the authority correctly, picks the real host), clear `username`/`password`, emit `u.href`, then decode back ONLY the `%7B`/`%7D` braces the template engine cares about. Generalise: never re-implement URL authority parsing with `indexOf`/`lastIndexOf` — the lenient WHATWG rules (backslashes, encoded userinfo, embedded `@`) will bite. Parse, mutate the parsed object, re-serialise, and patch only the specific re-encoding you must undo.

**Lesson — an outside-voice-requested enhancement that reaches into dynamic-DB selection or multi-leaf secret semantics is a redesign, not a quick mirror — revert and defer rather than ship half-correct.** Codex R1 asked me to clean stored secrets on an auth-type-only PUT (mirroring the flow-step serializer). I added the `readStored`-and-reclean branch; Codex R2 then found it had two real bugs the flow-step reference ALSO latently shares: `readStored` ignores a dynamic `req.body.db` (cleans the wrong database), and `stripStraySecretLeaves` keeps the destination-type leaf so a bearer→basic flip reactivates a stale password. The correct fix is bigger (dynamic-db-aware readStored + drop ALL leaves on a type-only change + apply the same to the flow-step serializer for parity). The right call mid-PR was to REMOVE the branch, keep the part that is unambiguously correct (the same-type stray-leaf strip that closed a real plaintext-store hole), and write the full redesign to the backlog with its two edge cases named. Shipping a half-correct version of a security cleanup is worse than not shipping it — the residual looks fixed.

## §148 — Sharing "chrome" across near-identical pages: extract the mechanical duplication into a hook + presentational slots, not a render-prop god-component (2026-07-01, v3.2.391, list-UX PR3 — shared list scaffold)

**Context.** Four list pages (connectors / templates / flow-recipes / transformers) looked and behaved almost the same, but three had independently hand-rolled the exact same table-resize wiring and header JSX while the fourth (transformers) was a visual outlier. The ask was "make them visibly the same components."

**Lesson — the safe unit to share is the mechanical duplication, kept behind a hook + thin presentational components, with domain markup passed as slots.** The genuinely-repeated code was ~20 byte-identical lines of container-measure + `fitColumnWidths` + per-column resize handlers (→ `useResizableColumns`) and the sortable header row (→ `ListTableHeaderRow`). Layout shells (`ListToolbar`, `ListPageScaffold`) take the page's own controls as `ReactNode` slots. A single `ResizableListTable` render-prop component owning table + header + body would have needed a dozen props and been hard to test; the hook is unit-testable in isolation and the header row is snapshot-testable. Splitting beats a monolith when the bodies diverge but the mechanics don't.

**Lesson — migrating a live page onto shared chrome is behaviour-preservation, so the win is that its unchanged test suite still passes; delegate the mechanical relocation but verify the premise yourself.** Three parallel agents each relocated one page; all kept their existing suites green (53/42/21 tests). One agent caught that my hand-off premise ("the approval column is admin-only") was wrong — the column is unconditional, only the filter is gated — and built the column list flat to avoid *introducing* a regression the premise would have caused. Because CSS fit can't be measured in jsdom (see the list-table LESSON), the resize mechanics being byte-identical is what makes the refactor safe; the visual chrome still needs cold-load live-verify.

**Lesson — when a page renders `hidden lg:table-cell` on a would-be resizable column, either keep it out of the resizable set or drop the responsive hide.** A display:none column measures 0 and the fit math never leaves "measuring". Transformers' description column dropped the responsive hide to join the resizable set — matching the other pages, which never responsive-hide columns.

## §149 — For a type-specific field attribute on a cross-zone synced table, store it as an additive JSON column, not a dedicated column pair; and a new value class ripples through every read boundary, so route it through one parse helper (2026-07-02, v3.2.392, list-UX PR4 — checkbox multi-select)

**Context.** `checkbox` was redefined from a boolean into a multi-select group needing per-field min/max limits + an array value. `blueprint_fields` is synced across three zones.

**Lesson — a dedicated column for a type-specific, never-SQL-queried attribute is the expensive shape on a synced table; a JSON key is the cheap one.** Min/max limits went into an additive `choice_config JSON` column (mirroring `table_config`), not a `min_selected`/`max_selected` column pair. A dedicated column would have meant an `ALTER` on every zone DB (re-opening the v3.2.300_303 no-`ALTER` scar), plus serializer + TS + fixture churn at each boundary — all for a value that is only ever read back whole and rendered. This is the same split Directus / n8n / JSON Schema use: dedicated columns for cross-type attributes, a JSON blob for type-specific ones. The additive JSON column still owes the full additive-column tax (guarded `ALTER` migration, `information_schema` write-gate tolerance, a column-gated `NULL`-clear on type-change, drift-registry entry) — but that tax is mechanical and already has two precedents (`depends_on_field_key`, `retain_when_hidden`) to copy exactly.

**Lesson — the value channel is string-typed, so a new "array field" is not new plumbing; it is a new parse site at each existing consumer.** A `table` field already lived in the `Record<string,string>` form/payload channel as a JSON-stringified array; checkbox mirrored that exactly (stringified array on the wire, real `string[]` in code), so the `(v: string)` renderer/onChange signature never changed. What did change was every reader: the transformer payload builder (array under `form.<key>`), the visibility evaluator (a `contains` operator + set-aware `eq`/`neq`/`in` when the *subject* is a checkbox), the connector-input mapper (comma-join), and — the bug the audit caught — `validate()`, where a bare `values[key].trim()` non-empty check silently passes an empty `'[]'`. One home for the parse/serialize/validate logic (`choice-values.ts`) kept those sites honest.

**Lesson — a guarded no-op scalarizer covers N callers uniformly where threading type metadata through N call sites would not.** The connector-input read had seven callers, none carrying field types. Rather than thread a checkbox-key set through all seven, `scalarizeIfStringArray` transforms only a genuine JSON string-array (leading `[` + all-string members) and returns everything else untouched — a checkbox value becomes `"r, b"`, a real scalar is provably never corrupted. Type-driven precision was still required for the *visibility* operators (there `eq` vs `contains` semantics genuinely differ), but for a pure array→scalar coercion the guarded heuristic is the smaller, safer surface. **[Superseded in-PR: Codex R1 correctly refuted the premise — "provably never corrupted" was false for a text field literally holding `["a","b"]`. The scalarizer was removed; §150 records the correct shape.]**

## §150 — A redundant security layer earns its removal only after you name the layers that remain; and the cheap place to inject type-awareness is the one hand-off where types are in scope, not the N call sites that lack them (2026-07-02, v3.2.393, list-UX PR5 — connector cleanup)

**Context.** PR5 removed the per-connector / per-flow-step "Allowed hosts" (global egress allow-list becomes the single host control), soft-deprecated connector `transformer_id`, and delivered the checkbox→connector comma-join PR4 had deferred.

**Lesson — removing a security control is an inventory exercise: enumerate what protects the same surface, per layer, before touching anything.** The per-entity allowlist looked load-bearing (an `SSRF_BLOCKED` rejection in the outbound executor), but inventory showed it was the THIRD layer on one surface — beneath it sit the unconditional SSRF guard (blocked-IP classifier + DNS-pinning lookup, in the same function) and the global egress allow-list (host+method+path at prepare/save/import/clone). Its own semantics ("empty = allow-all") made it opt-in narrowing nobody used, while its UI promised protection it only conditionally gave. The removal deletes the field, the pass-throughs and the dead helper — but the two real layers are byte-untouched, and the CHANGELOG/SDD name them explicitly so the next audit doesn't re-derive this. Also: the same cleanup MUST sweep sibling entities (flow steps had cloned the field wholesale) — removing enforcement in the shared executor while leaving a sibling's UI field visible would convert "redundant control" into "visible lie".

**Lesson — when a transform needs type metadata, move the transform to where the types already live instead of threading types to where the transform lives.** PR4's deferral assumed "thread a checkbox-key set through the 8-caller fetch surface". Mapping the actual wiring showed all eight consumers receive `currentValues` from ONE variable in ONE component (`FmbInput.visibleValues` → five JSX props) — and that component already holds `fields` with types. One derived map (`deriveConnectorValues`) substituted at those five props covers resolver, fingerprints, review diffs AND the readiness/chain heuristics (which bypass the resolver and would have been missed by any resolver-local fix), with zero signature changes and the raw map still flowing to save/transformer. The wiring map also proved the substitution can't corrupt anything: the apply path never echoes `currentValues` back into form state. Deferring PR4's version (a value-shape guess at the resolver) was right; the type-driven fix at the values source is both smaller and more complete.

## §151 — Detecting "stale-shape" data by parsing untagged values is a data-loss trap; verify the ON-DISK format before trusting a predicate, and keep a persistent outside reviewer on boundary work (2026-07-03, v3.2.411, field type-mismatch residual detect & review)

**Context.** When a blueprint field's type changes, already-saved `user_templates.payload` values keep the old shape. The backlog wanted auto convert-or-clear; the user reversed it mid-brainstorm to detect + review (an accidental type change must never silently delete data) with payload kept type-tag-free for portability. Shipped as a `type_mismatch` category in the existing field-data scanner, editor-widened + ownership-scoped.

**Lesson — the on-disk value format is ground truth; a test fixture that encodes your assumption validates the assumption, not the code.** The first predicate assumed payload values were native JSON (`Array.isArray(value)`). They are STRINGS: a checkbox persists `'["a","b"]'` (a JSON string), scalars are plain strings. So `Array.isArray('["a"]')` is false → a VALID checkbox value was flagged as a mismatch, and the review tool would offer to DELETE it — the exact data-loss the user feared. Every unit + integration test passed because the fixtures used native arrays (`{colors:['a','b']}`), i.e. they encoded the same wrong assumption. Three Claude reviewers (including a dedicated security pass) missed it; Codex caught it by reading how `FmbInput` actually persists. **Before writing a predicate over stored data, read the write path / query the real column — and make one fixture the real byte shape.** A code-reviewer later proved the fix by mutation-testing (revert predicate → new fixtures fail), which is the bar for "this test actually catches the bug".

**Lesson — you cannot reliably infer a value's ORIGINAL type from an untagged string; detect only the direction that is unambiguous.** With no type tag in the payload and JSON-structure input NOT blocked in text fields (verified — the "text forbids JSON" premise was intent, not enforced), a scalar field holding `'[1,2,3]'` is indistinguishable from a stranded checkbox value from legitimate user text. Parsing it to guess "stranded composite" false-positives and, on the clear path, permanently deletes valid text. Option A: flag ONLY a composite field (checkbox/table) holding a non-composite value (zero false positives — those fields always persist a composite); NEVER flag scalar fields. The original motivating case (checkbox→text) becomes an accepted non-goal — correctly, because catching it safely would require a type signal (rejected for portability) or enforced input validation (not built). **A detector that can delete data must bias to under-detection; a missed residual is a valid string, a false positive is destroyed data.**

**Lesson — a persistent outside reviewer earns its cost on boundary-sensitive work; run it until it goes quiet, not a fixed number of rounds.** Four Codex rounds each surfaced a real issue all Claude reviewers missed: (R1) ownership scoped by the direct blueprint owner, not the EFFECTIVE (linked) owner → cross-owner access — ownership MUST resolve through the same `COALESCE(linked_blueprint_id, blueprint_id)` the data-validity check already uses; (R2) the string-storage inversion above + fail-open on a dangling effective blueprint (a missing LEFT-JOIN row read as "shared" — distinguish "no row" from "owner NULL", fail closed); (R3) the unenforced text-input premise; (R4) an impersonation cache leak (React Query key omitted the effective identity), the read-only scan blocked by impersonation guard, and a non-atomic ownership pre-check (fold the owner check into the locked transaction with `FOR UPDATE` so a concurrent owner-transfer can't race the mutation). The findings narrowed each round (central data-loss → edge-case impersonation), which is the signal to stop — but stopping at "2 rounds by rule" would have shipped the data-loss bug. The Claude reviewers verified internal consistency (scan and clear used the SAME owner); the outside model questioned whether that owner was the RIGHT one. Cross-model agreement is a recommendation; the divergence is where the bugs hide.

**NOTE (2026-07-06, per 07-05 retro):** the 4 Codex rounds this section describes were a documented EXCEPTION for a data-deletion-critical PR — §10's hard cap of 2 rounds remains the standing rule. The exception was accepted knowingly: a hard stop at R2 would have missed 2 real findings on THAT run; it does not license extra rounds elsewhere.

## §152 — Move a resolution the client can't be trusted for onto the server, but keep the one thing only the client can produce as an explicit signal (2026-07-03, v3.2.417, flow pick-to-capture C1 backend follow-up)

**Context.** A client-orchestrated flow recipe (any step carries browser-only before/after JS or a compute step) that relied purely on a picked JSONPath — with no step setting `ctx.link`/`ctx.external_id` — resolved `result_link`/`external_flow_id` to NULL at a real run. The real run caller (`BuildFlowModal`) never passed the extract specs to `runFlowChain`, so the browser's path resolution always yielded null; `run-finalize` merely trusted the client-reported `resolved_link`/`resolved_external_id`. Fix: `run-finalize` now always re-extracts from the final response body it already receives, using the recipe's DB-stored `link_extract`/`external_id_extract` specs (`flow-extract.js` pathGet), for both the server-loop and client paths.

**Lesson — the fix for "the client resolved it wrong" and "the server over-trusts the client" is the same move: pull the deterministic part server-side, and reduce the client's role to the part that is genuinely browser-only.** Path extraction against a response body is deterministic — the server has the body AND the DB specs, so it should do it; trusting a client-resolved value was both a NULL bug (client lacked the specs) and a trust-boundary hole (a lower tier supplying the persisted value). What the server CANNOT reproduce is a step's sandboxed JS output, so that stays client-supplied — but relayed as an explicit *signal* (`link_emitted` + `link_emitted_value`), not folded into a pre-resolved value. Override only when a step actually emitted the key (an emitted null still overrides), never merely because the merged context carried a same-named key. Unifying both paths on server extraction made the server-loop path byte-for-byte unchanged and gave the client path the same guarantee for free.

**Lesson — when a rename moves the guarded value's SOURCE, re-audit every guard that assumed the old source.** The length guard that stopped an oversize `external_id` from wedging the run in `partial` (strict-mode UPDATE error under a terminal-state precondition) had been on the client-supplied field. Once the value can also be server-extracted, the guard must move to the FINAL computed value and cover both origins — and its sibling `link` (TEXT, 65 535 bytes) needed the same guard, which the diff had left unprotected until the security reviewer flagged the asymmetry. A char cap well under the byte limit (`MAX_LINK_LEN` 8192) is safe even for multibyte.

**Lesson — pick the live-verify path that actually exercises the changed branch, and know your tooling's evaluation model.** The existing windfarm e2e dispatches a plain (JS-free) api step → it runs the server-LOOP path, which already worked; it never touches the client-orchestrated branch this fix targets. A faithful live check drove `run-begin → step dispatch → run-finalize` (with NO emit fields) via authed API against the deployed stack, then read the run back — `result_link`/`external_flow_id` resolved from the path where pre-fix they were null. Tooling gotcha: the headless `browse` JS bridge evaluates and prints `.then()` promise chains but silently drops the return value of an `async () => {}` IIFE (its side-effects still fire — several throwaway recipes got created before this was noticed), so write browser verification as promise chains, and clean up any rows a repeated verify created (app DELETE endpoints, not raw SQL — the classifier blocks raw mutation on the shared live DB).

## §153 — A programmatic write path must re-derive EVERY constraint the manual input path enforces, one by one — each unmirrored constraint is a silent fidelity bug (2026-07-04, v3.2.424, color-groups PR-3 matrix copy)

**Context.** PR-3 added matrix copy actions ("apply from previous column" / per-cell copy) with a stated core invariant: a copied write must be indistinguishable from a manual keystroke, routed through the same `onChange`. Three Claude reviewers approved the routing. The security reviewer plus two Codex rounds then found five real gaps — every one a constraint the manual path enforced that the copy path didn't mirror:

1. **Batch staleness** (HIGH): column copy looped `onChange` against a pre-batch snapshot; two related fields in one column could persist a cascade/visibility combo manual input can never produce. The hazard was literally pre-announced in a `SAFETY` comment in `handleFieldChange` ("if batch or programmatic callers are ever introduced…").
2. **Checkbox foreign tokens / maxSelected**: manual toggling can only produce valid tokens and can't exceed the cap; a verbatim copy could do both.
3. **Cross-type copy**: nothing forces a matrix row to align same-typed fields; text→number stored undisplayable values, text→checkbox silently cleared.
4. **Computed-field lock**: a working overridable-but-not-unlocked compute rule renders disabled but reports `isLocked=false`; copy "succeeded" then reconciliation reverted it — worse than a skip because the user saw it apply.
5. **Duplicate-option label identity**: manual select edits call `onOptionSelect(label)` alongside `onChange(value)`; copy wrote only the value, so alias options could resolve to the wrong identity.

**Lessons.**
- "Routes through the same onChange" is necessary, not sufficient. The checklist for any programmatic writer is the full set of per-type/per-state gates the interactive control enforces: option membership, count caps, type compatibility, compute/lock state, secondary identity channels (labels), and batch ordering. Enumerate them from the input component's own render logic (`disabled`, filtered lists, extra callbacks), then mirror each term-for-term in the planner.
- Grep the target write path for `SAFETY`/`INVARIANT` comments before wiring a new caller — one of them may already name your bug.
- When a map keys on user-authorable coordinates (here `group_key`+`matrix_row_key`), the collision branch must be explicit or data silently disappears; the schema editor will not stop authors from creating the collision.
- Pattern held across the epic: insider reviews validated the declared invariant; the outside voice attacked the *undeclared* ones. 4/4 Codex P2 findings were real.

## §154 — Write-side guards must not validate read-side echoes (v3.2.431)

**Context.** Schema Builder PR1 closed every write path that could persist an empty/whitespace-only `field_options` label/value (clone filter, CRUD gate, `/replace` trim, sync skip). Two independent reviews (Claude code-reviewer, then Codex) each caught the same class of defect the initial implementation missed twice.

**Lesson.** `POST /field_options/replace` takes `next` (the state to persist) and `expected` (the client's echo of current server state, used only for the optimistic-lock comparison and never written). Tightening the shared validator rejected dirty values in *both* arrays — so a pre-existing dirty row in the DB made every panel save 400, **including the save that deletes the dirty row**. The product's only self-repair path was dead-ended by the guard meant to protect it. The fix landed in two rounds because tolerance had to cover every legacy form: first whitespace/empty strings (Claude HIGH), then SQL `NULL` (Codex P1 — the serializer does not coalesce these columns, so clients echo literal `null`).

**Rules of thumb.**
1. Classify each request field as *write-side* (persisted) or *echo-side* (compared/discarded) before adding validation. Echo-side fields get shape/bounds checks only — never content rules stricter than what the DB may already hold.
2. A new content rule must be paired with the question: "can data violating this rule already exist, and does every repair path for it still work end-to-end?" Enumerate legacy forms explicitly: `''`, whitespace, `NULL`, wrong type.
3. Present-only validation (skip absent columns) is right for partial UPDATE but is a bypass on CREATE — a create that omits the column persists the DDL default (often NULL). Pair present-only PUT semantics with required-on-create.
4. `String(v).trim()` in a dirty-check silently launders non-strings (`42`, `true`, objects) into "valid". Type-check before trimming: `v == null || typeof v !== 'string' || v.trim() === ''`.

## §155 — Display-only features still carry interaction and a11y surfaces (v3.2.432)

**Context.** PR6 rendered stored whitespace visibly (␣/→ meta-marks + trim quick-action) with a hard "display never mutates stored values" invariant. Unit suite was green throughout; the defects reviews caught were all in the seams AROUND the display.

**Lessons.**
1. "Display-only" narrows the data risk, not the review surface. The a11y pass found the two worst defects: markers conveyed a data-quality signal via aria-hidden glyphs + title only (screen readers heard nothing), and the trim button unmounted itself on click (focus dropped to document.body). A visual feature whose whole point is surfacing hidden information must budget an explicit accessible channel (one sr-only summary per flagged render, role=status for transient confirmations) and a focus target that survives conditional-branch swaps (park focus on the persistent container, not on elements that appear/disappear).
2. In-cell action buttons inside a selection-model grid must update the selection model, not just the DOM. stopPropagation on the button suppressed the cell's mousedown selection update, so visual focus and the grid's active cell diverged — the next Delete/paste targeted the previously-selected cell. Any injected cell affordance needs an explicit `activate(cell)` alongside its action.
3. Branch-precedence bugs hide behind single-cause tests. The "Trimmed" confirmation branch sat after the flagged branch; a cell that stayed flagged for a second reason (interior tab) after trimming masked the confirmation forever. When a state can be true for multiple independent reasons, test the multi-cause combination, not just each cause alone.
4. Marker/status tokens on tinted backgrounds: compute WCAG contrast at review time (slate-500 on slate-500/15 ≈ 3.95:1, fails 4.5:1 at badge sizes). One shade darker costs nothing before merge and a re-ship after.

## §156 — A placeholder object is a lie the type-checker can't catch (v3.2.433)

**Context.** Schema Builder PR2 re-tabbed the field editor and routed the right pane. The plan satisfied a new component's non-null `selectedField` prop by fabricating an `EMPTY_CREATE_FIELD` placeholder (`id: ''`) for create mode instead of threading `null`. Both branch reviews and 44 regression tests stayed green; the whole-branch Review Gate found "Add Field" completely broken: the downstream editor's create-vs-update contract branches on `field` TRUTHINESS, so the always-truthy placeholder dead-ended the create branch and Save issued a PUT to an empty id.

**Lessons.**
1. When a consumer's contract is "null means X", satisfying its type with a fabricated non-null default silently rewrites that contract everywhere downstream. Make the prop nullable and guard the dereferences — deleting the placeholder also deleted both its casts.
2. Task-scoped reviews each validated their own seam; only the whole-branch integration review (and the reviewer's insistence on tracing the REAL page's prop chain) caught it. Integration seams between tasks need at least one un-mocked end-to-end test per user-visible flow (here: create-field through the real component chain, pinning `schemaCreate` vs `schemaUpdate`).
3. Resync-suppression effects need FOUR cases tested, not two: dirty same-id (preserve), clean same-id (adopt server change — Codex R2), own-save dirty→clean transition (don't clobber just-committed values with the pre-refetch prop), genuine id switch (reset). Baselines used by destructive-action guards (`originalParentKeyRef`) must advance at save time once load-time resync is suppressed (Codex R1).
4. Relocating panels off an always-visible surface into a conditional route needs an explicit "route back" check — deselect/close affordances are easy to forget when the mock only shows each view in isolation (Codex R1 P1).

## §157 — Schema Builder PR3 lessons (v3.2.434)

**Context.** PR3 moved field-type glyphs to a token map and reworked the field-list row for keyboard access. Both changes looked like straightforward cleanup/a11y fixes; review found the real risk sat one layer beneath the visible diff.

**Lessons.**
1. Removing a lookup fallback is a blast-radius decision, not cleanup. The plan called for deleting the `?? <FileCode/>` fallback when moving type glyphs to a token map; code review traced the full chain — `field_type` is VARCHAR with no DB constraint, generic CRUD and blueprint-import write it unvalidated, and the only ErrorBoundary wraps the whole app — so one out-of-union row would blank the entire UI with no in-app recovery path. Rule: before removing a "dead" fallback on data-sourced keys, verify the write paths actually enforce the domain; if they don't, replace the fallback with an explicit safe accessor (`resolveFieldTypeToken`) instead of deleting it.
2. "Clickable row" keyboard a11y has one right shape. Evolution in one PR: row div with onClick only (keyboard-inaccessible, HIGH) → row div as role=button+tabIndex+onKeyDown (fixed keyboard, but created nested-interactive: descendant grip/delete semantics get flattened for AT — internal re-review flagged it, Codex independently flagged it P2) → final: row keeps mouse onClick as convenience, the LABEL CELL becomes a native `<button>` carrying selection semantics; grip/delete stay siblings. Native button = free Enter/Space, no custom keydown, no nested-interactive.
3. Synthetic KeyboardEvent dispatch does not exercise native button activation. Live-verify only triggered the label-button via a trusted CDP key event; `element.dispatchEvent(new KeyboardEvent(...))` did nothing. When live-verifying keyboard paths headless, use the browser driver's real key press, not JS dispatch.

## §158 — Schema Builder PR4 lessons (v3.2.435)

**Context.** PR4 added row filtering to the field-options editable grid. Review (4 Claude reviewers + 2 Codex rounds across three fix waves) found the filter multiplied into a data-loss surface everywhere it intersected an index-based feature.

**Lessons.**
1. A display filter multiplies every index-based feature into a data-loss surface. Row filtering intersected with selection (shift-range/Ctrl+A/Ctrl+Space), keyboard nav, delete/fill/paste/cut/clear, clipboard serialization, reorder, and inline-edit advancement — the review chain surfaced 10+ distinct hidden-row mutation paths. Rules that emerged: (a) discriminate "no filter" (`null`) from "filter matches nothing" (empty set) — `.length > 0` guards silently route the empty case to unfiltered behavior; (b) clamp destructive ops at WRITE chokepoints, not per selection gesture; (c) clipboard serialization must exclude hidden rows (Excel AutoFilter semantics) or copy→paste round-trips corrupt visible rows; (d) on ANY context change that invalidates numeric indices (filter query change, row reorder, failed save), clear/prune the stale state at the source instead of hardening every consumer.
2. `readOnly` on a column is a contract across every write path, not a render branch. The first implementation guarded only double-click; paste (both modes), fill, clear, cut, F2, and editor-Tab each needed the same guard, found across three review rounds. When adding a "not editable" flag to a shared component, enumerate write entry points first and test each — the cheap grep is `onChange`-reaching call sites in the grid's keyboard/clipboard modules.
3. Reset-to-baseline must read the owner's committed ref, never a parent prop. The footer Discard's first cut remounted sub-forms via a key nonce, reseeding from ancestor props that are stale during the unawaited post-save refetch window — silently regressing a just-saved value on the next Save. Same lesson as §156's resync matrix, applied to imperative resets: each sub-form reverts from its own advanced baseline ref (registerDiscard pattern).
4. Controller lesson: sliced task briefs must carry the visual-contract file path. A task extracted from a plan lost the mock pointer; the implementer recorded "no mock exists" and shipped without reading it. The dispatch, not the worker, owns making the mock path explicit (CLAUDE.md UI-dispatch rule).

## §159 — Schema Builder PR5a lessons (v3.2.436)

**Context.** PR5a rebuilt the table-column editor as master-detail with a column-type registry. The plan embedded complete component code; execution was mostly transcription, and the Review Gate still found four HIGHs — all in the plan's own code.

**Lessons.**
1. A plan that embeds complete code embeds retired anti-patterns with it. The plan's row markup was `role="button"` wrapping the drag grip and delete button — the exact nested-interactive shape §157.2 retired one PR earlier, and it re-shipped verbatim through implementer + task review before the whole-branch gate caught it (keyboard delete was fully broken: ancestor keydown preventDefaulted before native button activation). Plan authors writing full code must diff their UI shapes against LEARN'd rulings; controllers should name known-shape rules in the plan-author dispatch, not assume the spec's precedent files transfer them.
2. Registry-lookup idioms clone their holes. `resolveTableColumnType` copied `field-type-tokens.ts`'s widening-cast lookup and with it the inherited-property hole (`type: "__proto__"` returns `Object.prototype`, truthy, crashes downstream) — Codex R2 caught the copy, not the original. When a reviewer finds a bug in a copied idiom, grep for the siblings in the same review cycle; the original ships the same crash.
3. A controlled Select that displays a degraded value can never normalize it. Showing `resolveTableColumnType(type).type` while storing the raw legacy value means Radix suppresses `onValueChange` when the user picks the already-displayed option — the invalid value survives every save. Where display degrades opaque stored data, the WRITE path must converge to the displayed value (save-time registry normalization), or the trap is permanent.
4. Visual contracts must name the scroll container they ban. "All 20 columns visible at once" was written against a standalone mock page; live the editor sits in a panel that scrolls as one flow. The real requirement was "no nested scrollbox around the list" — the first implementation added `max-h-[360px] overflow-y-auto` and technically satisfied a plausible reading. Spec the container: "the list must not scroll independently of its panel."

## §160 — Dispatch-shape retro: per-task reviews were near-zero-yield, the one CRITICAL was plan-injected, and thin plans with contract envelopes beat thick transcribed briefs (2026-07-05 retro, PRs #523–#541 vs #492–#522)

**Context.** Two days of commander-dispatch execution (19 PRs) measured against the prior inline era (31 PRs). Merge-gap analysis + subagent context telemetry (n=264) drove permanent dispatch-shape rules (CLAUDE.md §11「派工形狀」; full data in memory `project_model_orchestration`).

**Lessons.**
1. Per-task implement→review serial loops are the dominant slowdown and near-zero-yield: task-scoped reviews returned ~all zero findings, while the only integration CRITICAL of the window was caught by the whole-PR Review Gate — and that CRITICAL was plan-INJECTED (§156), which task review waved through "because the plan said so". Default: no task-level review; whole-PR gate unchanged; add a task review only for auth / data-destructive / cross-file state work.
2. A fresh single-task subagent finishes at median 50% of its context window — half the window is cold-start re-reading. Continuity (reuse the implementer within a PR, rotate at ≥60% used / domain switch / degradation; reviewers always fresh) pays the re-read once. Whole-PR single workers were the fastest per PR in both eras.
3. Thick plans that pre-script red-green choreography inject bugs with authority (§156, §159.1) and their re-transcription into briefs drops load-bearing pointers (§158.4). Thin plan (tasks + acceptance criteria + per-task Contract block) + 5-line dispatch envelope with the Contract pasted verbatim; workers own their own TDD.

## §161 — Suppress-and-delegate must clear the state the suppressed path owned, and every delegated mouse path needs its keyboard twin routed too (2026-07-06, v3.2.437, Schema Builder PR5b)

**Context.** PR5b linked the preview grid's column headers to the master list by suppressing the grid's internal column-select on header click and delegating to a parent callback. Review found two HIGHs in the same seam, then live-verify + pipeline polling produced one ops lesson.

**Lessons.**
1. When a new opt-in branch suppresses an internal behavior and delegates out, it inherits the suppressed branch's CLEANUP obligations, not just its trigger. The old header-click path cleared row selection + active-cell state before painting its own visual; the delegating branch returned early without clearing → a previously-clicked cell's focus ring and row tint survived under the new linkage highlight (repro-confirmed). Audit what the replaced path mutated, and clear the same state before delegating.
2. A delegated mouse interaction has a keyboard twin somewhere — route it too or the feature is mouse-only (WCAG 2.1.1). Header-click delegation lived in the `<th>` onClick; Ctrl+Space dispatched the internal column-select directly from the keyboard module, bypassing the delegation entirely. Grep the keyboard/shortcut module for the same action name whenever a pointer path is intercepted.
3. Ops: polling "the latest pipeline" right after a push can grab the PREVIOUS commit's still-queued pipeline (a doc-only push minutes earlier had queued one). Match the pipeline's `sha` to the merge commit before polling its status — one wrong-PID poll declared success while the real pipeline was still running.

## §162 — Schema Builder polish batch (v3.2.438–444, PR-A…E) — batch-level lessons (2026-07-06)

**Context.** Five polish PRs (PR-A through PR-E) landed across one batch. Reviews across the batch surfaced the same two classes of defect more than once, plus one recurring contrast failure.

**Lessons.**
1. A "floor" requirement must be swept by PROPERTY, not by literal token. PR-A's 12px font floor was verified with a grep for `text-[10px]` and missed the 9px/10.5px/11px variants sitting right beside it — caught as a review HIGH. When the requirement is "no value below N", enumerate every sub-threshold token (or scan computed font sizes), not just the one example value named in the ticket.
2. A visibility gate on an editable value needs `OR(loaded-snapshot, live-value)`, plus the snapshot must advance on save — half of either breaks a different way. Snapshot-only hid a just-typed value after a context switch (Codex P2); live-value-only unmounted the input mid-edit and cleared stale keys (review HIGH). Both were the same underlying bug (PR-C) surfacing from opposite ends: the gate must OR both sources, and the snapshot side must re-baseline once a save commits or it re-diverges on the next switch.
3. `text-muted-foreground` at sub-12px over ANY tint/`bg-muted` fails WCAG AA small-text in at least one theme — this batch confirmed it twice independently (PR-D matrix key line, dark mode 4.17–4.33:1 → fixed in v3.2.442; PR-E cluster header, light mode 4.30–4.43:1 → fixed in v3.2.444). Default remedy: `text-foreground/70` (alpha-composited contrast ≥6.3:1 across all 8 palette tints × light+dark). Design passes must compute contrast for any sub-12px muted text over a non-plain background instead of eyeballing it; remaining instances tracked for a dedicated sweep.

## §163 — Grid interaction fix batch (v3.2.449) — pointerdown-before-blur, stale-async session tokens, fixed columns in resizable panes (2026-07-06)

**Context.** 8-item post-PR7 batch (#554). Three defect classes each surfaced twice independently (two reviewers, or reviewer + live-verify), making them patterns, not one-offs.

**Lessons.**
1. A window `pointerdown` listener that guards on "is editing" can never observe the post-blur state — native order is `pointerdown → blur`, so the guard reads the PRE-click state and the cleanup the blur owes never happens (ring stuck on mid-edit cross-grid click; two reviewers caught it independently). Remedy shape: keep outside/portal detection in the one listener, but stash intent in a ref and consume it on the state transition (`editingCell → null`) instead of acting at pointerdown time. Corollary for tests: the listener's event type is the contract — a synthetic `mousedown`/`click` sequence produced a live-verify false negative; custom low-level dispatch must send `pointerdown` (real `.click()` is fine, it emits the full chain).
2. "Stay on the newly created item" needs guards on BOTH sides of the async resolve: cancel the pending claim on any user navigation (post-resolve window), AND drop stale save callbacks with a monotonic session token compared through a live ref (pre-resolve window). A boolean like `isCreateMode` cannot distinguish abandoned-create-A from newly-started-create-B — the token bump on "start new create" is what closes that handoff.
3. Adding a fixed/auto-width column to a row grid inside an `overflow-hidden` pane: check the pane's REAL minimum — react-resizable-panels `minSize` is a percentage, so the reachable floor can sit well below the row's non-shrinkable content sum (Codex caught clipping ~230px). Collapse the track responsively (existing `useElementWidth`; `width===0` unmeasured convention; `useLayoutEffect` → no first-paint flash) and keep header/row templates in one shared function so they cannot drift. jsdom cannot see any of this — the threshold is a live-verify item by construction.

## §164 — Closeout batch (v3.2.450–456) — pipe-swallowed exit codes, worktree provisioning, parallel-worktree dispatch shape (2026-07-07)

**Context.** 8-PR closeout batch (#555–#562) executed with parallel implementers in isolated git worktrees. Three operational lessons recurred across PRs; none are code-level.

**Lessons.**
1. `$?` after a pipe reads the LAST stage's exit code, not the command under test — `gate.sh | tail` reported tail's success and masked a red gate (bit this batch again, after the earlier k3d-e2e incident). Rule: any gate/test invocation that must be checked programmatically either runs unpiped or is checked via `PIPESTATUS[0]` (bash) immediately after the pipeline. Grep for `| tail` / `| head` around exit-code checks when auditing automation.
2. A fresh `git worktree add` is a CLEAN checkout: every gitignored runtime artifact is absent — `node_modules/` (tests can't run), `docker-api/.env` (docker-role-boot-smoke's `env -i` local-auth fallback needs `JWT_SECRET` → gate false-FAILs). Provisioning is part of the dispatch cost: `cp -al <main>/node_modules <wt>/` (hardlink, fast) + copy `docker-api/.env`. Same class as the CLAUDE.md-anchored repo-root bug fixed in v3.2.450 (#555): anything Ship Gate runs must be clean-worktree safe; root fix for the smoke (hermetic env injection) tracked in backlog. Corollary found 2026-07-07: a dep can be DECLARED (package.json + lockfile) yet absent from the main checkout's `node_modules` on disk (@fontsource after v3.2.456) — hardlink-provisioned worktrees inherit that gap; `npm install --no-save` materializes without touching tracked files.
3. Parallel-worktree dispatch shape that worked: parallelize ONLY task groups with disjoint file sets (plan marks the groups); serial where files overlap; each implementer in its own worktree with a five-line envelope (branch / plan path / task slice / contract verbatim / report format). Landing still serializes through main regardless (every PR bumps docker-api/package.json version + CHANGELOG) — the parallelism buys implementation wall-clock, not merge wall-clock; expect a rebase/renumber step per landing.

## §165 — A drift-guard test that runs the sync before asserting is a tautology (2026-07-07, FOUT root fix v3.2.457)

**Context.** FOUT PR added committed `public/fonts/` copies of @fontsource woff2 files plus a "byte-equality drift guard" vitest. First implementation called `syncFonts()` (copy node_modules → public/fonts) as the test's first line, THEN compared — the assertion compared a just-written copy to its own source: green forever, and every test run silently rewrote tracked binaries in the working tree. Both Claude reviewers caught it independently and proved it empirically (flipped a committed byte → still green → file silently "repaired").

**Lessons.**
1. A guard test must never execute the repair path it guards. Assert on the COMMITTED state directly (read both sides, byte-compare); let the fix command (`fonts:sync`) stay a separate, human-invoked action. Completeness needs the enumeration too: `readdir(dest)` == expected set, or planted/orphaned extra files pass silently.
2. RED-proof a guard in BOTH directions before trusting it: corrupt a guarded byte → must fail; plant an extra file → must fail; restore → green; `git status --porcelain` clean after runs (no side-effect writes). A guard that has never been seen red is unverified.
3. Vitest `setupFiles` run for EVERY test file regardless of a per-file `@vitest-environment node` override — a global setup that touches `window` unguarded crashes the first node-environment test added to the suite. Guard globals in setup files (`typeof window !== 'undefined'`), not in individual tests.

## §166 — Grid structural trio (PR-1, v3.2.463) — two lessons a review pass can't see and a state-shape trap (2026-07-07)

**Context.** The grid fixed-layout structural trio (measure-once-then-pin, scrollbar-gutter, flush fill handle) shipped in PR-1. Two of its lessons are invisible to a normal diff-based review; the third is a React state-shape trap that the re-measure lifecycle is built to avoid. This harness PR (PR-2) automates the acceptance checks so the same class can't regress silently.

**Lessons.**
1. **A NUL byte (0x00) anywhere in a source file makes git classify the whole file as binary, and EVERY diff-based tool then silently skips it** — `git diff` prints "Binary files differ", GitHub/GitLab render nothing, and Codex/Claude review passes see no hunk to review. The change ships completely un-reviewed while every gate reports green (nothing flagged a "binary" file). It is invisible to eyeballing too: the byte doesn't print. The only reliable detector is a byte-level scan — `grep -rPl '\x00' src/` (or a hexdump of a suspect file) — which belongs in the pre-ship sweep whenever a file's diff mysteriously renders as binary. Root cause here was an editor/codegen artifact, not intentional content; the fix is to strip the byte, but the DURABLE lesson is the detection method, because the failure mode is "your review tooling shows you nothing and says everything is fine."
2. **React bails out of a same-value setState, so a single nullable state used as BOTH "unmeasured" and "please re-measure" silently swallows the second signal.** The grid's column widths were briefly modeled as one `widths | null` state: `null` meant "not measured yet" AND setting `null` again was the "invalidate / re-measure" request. But when a measure fails while already `null` (e.g. a panel collapsed to width 0, measured 0s, dropped to `null`), the re-measure request sets `null → null` — React sees no change and skips the effect, so re-expanding never re-pins. The fix is a MONOTONIC tick (`remeasureTick`, `setRemeasureTick((t) => t + 1)`) as the invalidation signal, orthogonal to the nullable measured-value state: a counter always changes, so the effect always re-runs. Rule: never overload one nullable state as both a data value and an event/invalidation signal — the same-value bail-out will eat the event exactly when the value didn't move. Use a separate monotonic counter (or a dedicated event) for "do it again."
3. **Corollary (mechanism, not a trap):** because the commit re-fit re-measures UNCONDITIONALLY on every edit exit, a resize that arrives mid-edit needs no queued pending-flag flush — it is simply DROPPED during the edit and absorbed by the unconditional commit re-fit. A prose comment describing a "deferred/flushed pending ref" is stale against this simpler mechanism (aligned in `EditableDataGrid.remeasureLifecycle.test.tsx` this PR).

## §167 — Two sibling TZ CRITICALs in the Public API P2 keyset path (v3.2.466 emit-side + v3.2.469 bind-side) — the mariadb driver serializes a JS Date in process-local time, unpadded (2026-07-07)

**Context.** Public Integration API P2 (scoped read surface) hit the SAME timezone hazard TWICE, on opposite ends of the keyset-pagination round-trip. Both were CRITICAL data-correctness bugs; both were invisible to the unit/mock test suite (green) and only surfaced against a real MariaDB / a live Asia/Taipei pod. The edge pod runs `TZ=Asia/Taipei` (`Dockerfile ENV TZ`), so the bug is load-bearing in production, not theoretical.

**The hazard (one root, two sites).** `dateStrings:true` + `timezone:'+00:00'` on the pool sets the SERVER session tz only; it does NOT change how the `mariadb` node connector serializes a bound JS `Date` parameter. The connector's `getLocalDate` (`node_modules/mariadb/lib/cmd/encoder/text-encoder.js`) formats a Date with process-LOCAL getters (`getFullYear/getMonth/getDate/getHours…`) and NO zero-padding — e.g. under TZ=Asia/Taipei, `new Date('2026-03-07T14:04:05Z')` goes on the wire as `'2026-3-7 22:4:5'` (shifted +8h AND single-digit fields unpadded).

**Site 1 — emit side (v3.2.466, DB-review CRITICAL).** Reading a `created_at` string back with a bare `new Date(value)` parsed it as local time → every API timestamp shifted −8h, and the shifted value baked into the cursor. Fix: route every driver timestamp through `normalizeTimestamp()` (appends the `Z`) before `new Date()`. Detection: a `TZ=Asia/Taipei` subprocess test — a UTC-only CI never sees it.

**Site 2 — bind side (v3.2.469, live-verify CRITICAL).** The emit fix did NOT cover the reverse direction: `keysetFragment` bound `new Date(cursor.c)` as the SQL keyset param. Combined with `COALESCE(created_at, '<string sentinel>')` (which types the comparison as a lexicographic STRING compare), the unpadded local-TZ wire value `'2026-3-2 8:0:0'` compares wrong against a padded stored `'2026-03-05 08:30:00'` (diverges at the month tens digit `'0'<'3'`) → every single-digit-month/day row sorts before the cursor and is excluded → **page 2+ returns empty, silent data loss**. Fix: bind a zero-padded UTC string `utcSqlDatetime(ms)→'YYYY-MM-DD HH:MM:SS'` (with `utcSqlDatetime(0)===` the NULL sentinel) for both keyset params, so the param matches how the DB stringifies the TIMESTAMP column.

**Durable rules.**
1. **Never bind a JS `Date` as a SQL param to this mariadb driver.** It is TZ-skewed AND unpadded regardless of pool `timezone`. Bind a zero-padded UTC string (`YYYY-MM-DD HH:MM:SS`), or an epoch integer, never a `Date`. Grep for `new Date(` inside any `params:`/query-arg array on this driver.
2. **A `COALESCE(temporal_col, 'string literal')` makes the whole comparison string/lexicographic** — then padding and format of the bound param matter exactly. If you keyset on a COALESCE-with-string-sentinel, the param MUST be a canonically-formatted string, not a temporal type.
3. **A fix on one side of a round-trip (emit) does not cover the other side (bind).** When you fix a serialization hazard, grep for the INVERSE operation and fix it in the same PR — the two sites share the root cause but live in different files.
4. **This class is structurally invisible to mocks/UTC-CI.** Both CRITICALs passed the full green suite. Only a real-MariaDB integration test (throwaway container, single-digit-month dataset, real connector) + a live Asia/Taipei pod verify caught them. Any keyset/timestamp path on this driver needs a real-DB integration test, not just unit coverage — this is why live-verify and the new `public-read-keyset-real-db.test.js` are load-bearing, not ceremonial.

## §168 — Bugfix batch PR-1 (Bugs 1/2/5) — reversing a "frozen" product decision, remapping references with no FK, and the immutable-column strip that changes test semantics (2026-07-10)

**Bug 1 — renaming a "frozen" group key.** Group keys were documented as permanent in three places (`group-key.ts` header, `GroupFormDialog` header, the rename dialog copy). Unlocking the key is a deliberate reversal, so the same PR reverses every doc claim — a "frozen"/"permanent" string surviving anywhere is a doc-lie lint target. The rename is a cascade, not a bare UPDATE: `blueprint_fields` references the key BY STRING in two columns (`group_key` for lane membership + `matrix_row_key` for the matrix lane), so the endpoint updates the group row and both referencing columns in ONE transaction, scoped to the blueprint. `user_templates.payload` never stores group_key (DDL invariant), so saved entries are untouched — no template walk. The uniqueness pre-check on the new key uses the column's own collation, matching `uq_blueprint_group_key`, so a case-variant collision is caught exactly as the index would.

**The immutable-column strip changes existing test semantics.** To force renames through the cascade endpoint, `group_key` is added to the generic CRUD `immutableColumns` — the PUT handler `delete`s it from the body BEFORE the uniqueWithin check. Any pre-existing test that exercised the generic factory's uniqueWithin-on-PUT path by *changing group_key* now sees the key stripped: a group_key-only PUT becomes "no valid fields → 400", and a reparent-and-rename checks the STORED key. Those tests had to be rewritten to assert immutability. Lesson: when you make a column immutable, grep the route's tests for that column in a PUT body — the strip silently changes what the assertion measures.

**Bug 2 — remapping references across a delete/re-insert with NO foreign key.** `overwriteBlueprint` DELETEs then re-INSERTs `blueprint_fields` with fresh UUIDs; `variant_overrides.field_id` has no FK, so the references dangle silently ("Unknown field" is a display fallback, not a bad enum). The targeted fix: capture old `id → field_key` before the delete, build `field_key → new_id` after the re-insert, repoint each override by field_key, and DELETE+count any whose field_key is gone (or whose stored id was already dangling) — non-silent, surfaced through the existing import-warnings pipeline (`...result` spread → `surfaceImportWarnings`), so no new frontend wiring was needed. The real fix (an FK + ON DELETE CASCADE) is a schema migration deferred to candidates; a targeted remap is the right size for a bugfix batch. Probe the additive engine table (`tableExistsInCurrentSchema`) exactly like `blueprint_groups` so a no-ALTER operator DB neither 1146-crashes nor blocks the overwrite.

**Bug 5 — an owner gate already existed one route over.** The version DELETE was `requireAdmin`; the sibling rollback route (same file) already had the canonical editor-owner pattern — `requireAdminOrEditor` + `SELECT owner_id ... FOR UPDATE` + editor-owns-or-shared → 404-not-403. The fix is to mirror it, placing the owner check BEFORE the inherited `VERSION_IS_CURRENT`/`LAST_VERSION` integrity guards (owner first, then integrity). When a gate feels missing, grep the neighbouring routes for the pattern before inventing one.

**Test-harness note.** The `SELECT ... FROM \`fmb_variant_overrides\`` produces `` `table` SET col`` — a backtick sits between the table name and the next keyword. A matcher like `/variant_overrides SET field_id/` (space, no backtick) will silently never match; use `/variant_overrides.*SET field_id/`. This cost one confusing red where the production path was already correct.

## §169 — Bugfix batch PR-3 (Bug 6) — Origin-Agent-Cluster is a browser-session-sticky header, disable it on every helmet instance (2026-07-10)

**Not a code inconsistency.** helmet 8.1 sends `Origin-Agent-Cluster: ?1` by default. The frontend mounts `helmet()` before every document path and edge/infra both mount `createStrictHelmet()`, so the header was already emitted consistently — there was no missing-instance bug to "fix". The console warning came from browser state, not server drift: once a browser records an origin as site-keyed (an earlier visit, a stale cache, a service worker), every later `?1` response conflicts with that record and the browser warns until the browser session resets. A stuck session therefore does NOT clear on redeploy — only on browser restart / cache clear; the code change only prevents recurrence.

**Why disable rather than tune.** There is no ingress/istio layer setting this header uniformly, and this app gains negligible isolation from origin-keying, so the two options were "emit `?1` everywhere and accept the sticky warning" or "emit nothing". Emitting nothing means no page ever requests origin-keying → the warning cannot recur regardless of cache state. `originAgentCluster: false` on EVERY helmet instance (both `createStrictHelmet`/`createDocsHelmet` in `shared/security.js` and the frontend helmet) — a single shared const documents the rationale once and is spread into each config so a future added instance is a one-line copy, not a re-derivation.

**Test the absence, but prove helmet is live.** A test that only asserts `'origin-agent-cluster' in headers === false` also passes against a no-op middleware. The unit test first asserts a baseline helmet header (`x-content-type-options`) is present, THEN asserts the origin-agent-cluster key is absent — so "helmet silently stopped mounting" fails the test instead of masquerading as a pass.

## §170 — Layer-cut PR scheduling beat feature-cut in the capacity UX epic (2026-07-17)

Capacity UX Wave 2 shipped as five PRs cut by architectural layer — #638 placement/bundle fixes, #639 grid layer + catalogue repoint, #640 wizard rework, #641 live-verify polish + settings repair, #642 identity-column width floor (v3.2.528–532) — rather than by user-facing feature slice.

Each PR stayed inside review-size caps; each layer consumed the previous layer's already-reviewed surface instead of re-touching it; defects localized to their layer. For an epic that spans a stack vertically, schedule PRs horizontally (data/routes → grid surface → orchestration/wizard → polish); feature-cut PRs force every PR to touch every layer and re-trigger the full review surface each time.

## §171 — Commander paraphrase drift: verify workers' output against original artifacts, not the commander's restatement (2026-07-17)

In orchestrated (commander/worker) dispatch, a commander that restates a mock/spec/contract in its own words introduces silent semantic drift; the worker builds to the restatement and cannot detect the drift because the brief is its only input. This repo already codified one instance (dispatch briefs must carry the original mock file path, CLAUDE.md UI-dispatch rule); the capacity epic showed the same class again on non-visual semantics.

Briefs carry original artifact paths / verbatim contract blocks, never summaries; review verifies the diff against the original artifact and the code itself; an outside-voice reviewer (independent model/agent reading the code, not the brief) is the reliable catch for drift the originating chain cannot see.

## §172 — The browse daemon is a machine-wide shared singleton; stagger live-verify across sessions (2026-07-17)

The headless browse tooling used for live-verify runs as one shared daemon per machine. Two sessions driving it concurrently corrupt each other's state: element refs go stale mid-flow, actions can land on the other session's active page, verify results become untrustworthy.

Treat the browse daemon like the ship lock — serialize live-verify windows across concurrent sessions; same shared-resource class as the existing "stagger vitest/tsc/npm install across worktrees" rule.

## §173 — A k3d pre-push spec for a NEW feature must version-gate itself against the deployed schema version (2026-08-25)

Live-cluster (k3d pre-push) e2e specs assert DEPLOYED behavior — they run against whatever image ArgoCD has actually rolled out, which lags the local worktree. A spec written for a feature that just shipped locally has no such deployment yet, so an ungated spec goes red on every push (including unrelated ones) until the next rollout lands — blocking the whole team's pre-push hook for a gap that can span hours to days.

Fix: read the deployed version at spec start via `GET /api/platform/schema/status` and skip (with a stated reason, not a silent pass) when it is below the feature's own ship version. Reference implementation: `e2e/header-scroll-allowance.spec.ts` (was `header-condense.spec.ts` — the condense mechanism it gated was reverted per user ruling, fmb-1877; the version-gate SHAPE outlived the feature it first gated). This is the same shape as an API/schema version check, just applied to a browser-driven spec instead of a route.

## §174 — Hoisting a measured value out of a large page component: a ref-backed external store, not a lifted `useState` (2026-08-26)

`DynamicInputPage` (`FmbInput.tsx`) called `useMeasuredHeight()` directly to size a page-end spacer against the sticky header's live height — every header resize (a wrap at a narrower width, a banner mounting) fanned a `setState` through the ENTIRE form tree (every section, every field) just to keep one spacer current, since `useMeasuredHeight`'s height is React state owned by whichever component calls it.

Fix (fmb-1879): extracted the spacer into its own component (`FmbInputPageEndScrollAllowance.tsx`, `PageEndScrollAllowance`), but did NOT simply move the `useMeasuredHeight()` call there — the callback ref it returns still has to attach to the header, which is rendered by the PARENT, not by the spacer sitting at the page's foot; routing that ref through a `forwardRef`/`useImperativeHandle` indirection would race the header's OWN ref attachment (host refs attach during the commit's mutation/layout pass in tree order, before a later sibling's `useImperativeHandle` — itself a layout effect — has run), silently losing the very first measurement. Instead, the height lives in a plain `useRef`-backed pub/sub the parent owns (no `setState` in the parent, ever) and the spacer reads it via `useSyncExternalStore` — the same "no tearing between render and subscribe" primitive `useAuthMode` already uses for its own external-store read. The parent hands the spacer only the `{ subscribe, getHeight }` pair; only the spacer re-renders on resize.

When a value must be threaded through a large stateful parent to a distant descendant purely to avoid a full-tree re-render, and the CSS-custom-property escape hatch (`use-chrome-band.ts`) isn't available because a consumer needs the literal JS number (not just a CSS `calc()` operand), reach for `useSyncExternalStore` over lifting `useState`, and never re-route a callback ref through `useImperativeHandle` across sibling boundaries — the render-vs-commit-order guarantee that makes ref callbacks reliable doesn't survive the indirection.

## §175 — A picker's candidate list is a shared builder, not an inline filter — the lint is the rule (2026-08-31)

fmb-1934 PR-3 found four independently-drifting hand-rolled candidate lists behind "pick a field" pickers in the calculated family (`ValueSourceBlock.tsx`'s `toComputeAvailableFields`, `TableColumnsEditor.tsx`'s `columnAvailableFields`, and two inline `useMemo`s in `OverrideDialogs.tsx`/`FmbVariantPolicy.tsx`) — each one re-deriving "self excluded, table columns attached" slightly differently, including a self-exclusion keyed on `id` at two sites and on `field_key` at the other two. Folding them into one `buildFieldCandidates(allFields, scope)` is the boring half of the fix; the load-bearing half is that a shared builder with no enforcement is a convention, and a convention a picker can silently route around the moment someone reaches for `.filter(` instead of the import is not a fix, it is a slower recurrence of the same defect. Ship-gate Step 39 exists because the four original sites did not agree they were the same bug until a lint said so.

**The lint's own review round supplied the sharper lesson.** The original detector matched only an INLINE `allFields.filter(`/`field_key:` expression on the picker's own JSX attribute; hoisting the identical expression one line up into a `const`/`useMemo` and passing the bare identifier down evaded it — reviewer-reproduced, exit 0, on a shape the lint was explicitly built to catch. The fix resolves a bare identifier or `identifier.prop` attribute expression one hop within the same file before re-running the same patterns. A second, independent finding in the SAME round was a fail-open failure mode one level below the pattern gap: the ast-grep code path's `catch { continue }` around each pattern invocation treated "the binary threw" and "the binary found nothing" as the same outcome, so a killed process or a future flag/grammar break made Step 39 silently believe it had scanned the tree when it had scanned nothing — passing green while blind. The fix is not "catch the error better", it is to make ast-grep failure and ast-grep absence the SAME event: `scanAllFilesAstGrep` returns `{ failed: true }` on any throw or non-JSON output, and the caller discards whatever partial findings that pass collected and re-runs the WHOLE tree through the documented-limitation line/brace fallback scanner — the same path that already runs when the binary is not on `PATH` at all. One failure mode, one recovery path, instead of a silent no-op hiding inside what looked like the recovery path.

**What resolving one hop does not buy, and is not meant to.** The one-hop resolver's own documented ceiling — a second hop, object/array destructuring, same-name shadowing across two functions in one file — is real and left alone on purpose (this repo's other line/text-based gates make the same trade at this scale). The bigger, load-bearing gap is orthogonal to hop count: the file-level `buildFieldCandidates` import allowlist suppresses EVERY flagged expression in a file that imports the function anywhere, not proof that the SPECIFIC flagged picker's candidate list actually derives from that call. Eight sites (`FieldFormBlocks.tsx`, `OptionsSourceBlock.tsx` ×3, `DecisionColumnPicker.tsx`, `FieldDecisionLinkBlock.tsx`, `TableColumnsEditor.tsx` ×2) are pragma'd rather than migrated, tracked under `fmb-1937` — a lint's escape hatch is exactly as strong as the thing it lets through unchecked, and a file-level allowlist on a function-level claim is the shape to watch for the next time a "shared builder + lint" pair gets built here.

## §176 — Cutting a duplicate UI path down to the API's own shape; a predicate that serves two callers still needs a name that survives either one (2026-09-01)

**Why the N-side compare bar and the standalone run-browse entry point were cut.** `GET .../versions` had already merged manual saves and flow runs into ONE timeline server-side (a `run:`-prefixed id keeps the two id spaces from colliding) since fmb-1912 — but the data-entry page kept TWO parallel UI paths on top of that one merged list: a `RunHistoryControl` popover + `CompareBar` doing an N-way compare over `compareSides`/`diffList`/`compareSlotRun0..2`/`compareSlotVersion0..1`, and a separate `Versions` panel with its own per-row `Compare` link, each with its own state shape and its own entry point. Neither path disagreed about data — the API had already done the one merge that mattered — so the duplication was pure presentation debt: one term (a "version," whether manual or flow-projected) deserves one presentation (one panel, one History entry) and one compare mechanism (a two-way `compareOther`, since a reader comparing two points in time is never comparing more than two at once no matter how many rows the panel lists). Retiring the N-side engine and the run-specific popover did not remove a capability — run-vs-run compare still works, addressed as `version`-kind rows the same way manual-vs-manual does.

**The "one predicate, two uses" over-reach, found the other direction.** `run-browsing-guard.ts`'s write lock answers ONE question — "is something being browsed right now" — for two callers (a browsed run, a browsed version) from day one, and that reuse is correct: every call site only ever needs the boolean, never "specifically a run," so a second parallel lock would be a distinction with no reader (the module's own doc makes this argument explicitly, and PR-4 left the design alone). The over-reach was on the NAMING side, not the logic side: `browsingRunId`/`setBrowsingRun`/`isRunBrowsingArmed` baked "run" into an API that was ALREADY serving a second, and eventually dominant, caller — version browsing. A predicate correctly shared between two uses still needs a name that does not silently claim to be about only one of them; the tell was almost cosmetic (a reader scanning `isRunBrowsingArmed()` in a version-browsing code path has to already know the module's own doc to realize it is not a bug) but the fix cost a dozen-plus call-site rename that a browse-neutral name from the start would never have owed. The inverse mistake — ONE predicate quietly serving two uses with genuinely DIFFERENT correctness requirements — showed up in the same batch: `isPlainRecord` (`fmb-input-compare.ts`) was reused to validate a version snapshot's `entered` (which GATES whether the whole side is available) and its `computed`/`outputs` (which only pick a `{}` fallback) with the SAME shallow "is this a plain object" check, never verifying the values inside were actually strings — cheap enough for the fallback use, silently wrong for the gating use, because the shared predicate's contract was written to the weaker of its two callers.

**The page-mount test harness is duplicated wholesale, not shared — so a fixture defect had to be found N times.** Every `FmbInput.*.test.tsx` file (`versionBrowsing`, `browseBaselineDraftResolved`, `versionRestoreSaveFirstLiveDraft`, and others) carries its OWN ~100-line copy of the same `vi.mock()` scaffold (schema client, auth context, resolved-fields, connectors, `DynamicFormRenderer` capture) to mount the real page end-to-end, and each copy declares its OWN fixture constants rather than importing shared ones — three separate files each hardcoded the same absolute `created_at` literal independently, so the "use a clock-relative date, not a fixed one" fix (already the established pattern in `TemplateVersionsPanel.test.tsx`) had to be applied three times rather than once at a shared source. The duplication is not wrong on its own — each file's mocks diverge slightly on which hooks it stubs, which is a real reason to keep them separate — but it means a fixture-hygiene defect in the shared PATTERN (a hardcoded date, a stale prop shape) does not surface as one fix location; it surfaces as however many copies happened to need the same input. Absent a genuine shared harness module, the mitigation available at this size is smaller: when fixing a fixture pattern in one page-mount test file, grep sibling `FmbInput.*.test.tsx` files for the same literal before calling the fix done.

## §177 — Pagination as a visibility stage, not a render slice (2026-09-03)

The grid already derives `visibleRowIndices` / `renderOrder` / `navRowOrder`
for filter and sort. Paging slices `renderOrder` and feeds the slice back
through the same channel, so drag-fill, keyboard navigation and decorations
respect pages with zero per-hook edits. A render-level `rows.slice()` would
have left every index-based hook pointing at hidden rows.

## §178 — One working copy per table in a bundle run (2026-09-03)

Bundle members used to apply against independent pre-run snapshots, so two
writers of one table could only be forbidden outright. A `Map<tableKey,
rows>` initialised once and threaded through members in order makes the
outcome a function of order and write mode; the only configuration that
still cannot compose is `replace` after another writer, and that is the
only one blocked.

## §179 — One read normaliser retires a stored value-source mode without a migration
`copied` was a redundant chooser mode: a stored `copied` row already carries a
one-part mirror rule with `overridable:false`, which is a non-overridable
Calculated field. `readValueSourceForEditor(row)` collapses `copied` →
`calculated` at read time in ONE place, every editor entry point reads through
it, and the chooser drops the option — so the union keeps `'copied'` as a
legacy read-only member, the write boundary still accepts it for import, and no
DDL or migration was needed. The lesson: a stored enum member can be retired
from the UI behind a single read-time normaliser when a surviving member is
byte-equivalent, avoiding a data migration.

## §180 — Four lessons from connector options lists + delegated access (fmb-1976, 2026-09-04)

**A union-member addition is censused by the compiler, not by grep.** Adding
the `to.mode:'options'` sink to `OutputSink` was planned against a grep
census of `to.mode` sites; compiling with the new arm instead found five
property-narrowing consumers grep had missed (`apply-connector-response.ts`'s
`runOutputList`, `connector-config-build.ts`'s `outputComplete`/`trimOutput` —
which would have silently DROPPED an options output on save — `connector-
recap.ts`'s `targetText`, and `ResponseOutputRows.tsx`'s `setExtract`/
`setReduce`). A later round found a sixth (`connector-recap.ts`'s
`actionSummary`) and closed the class with an exhaustive `never` check rather
than one more hand-added branch. The grep still has a place — finding the
SITES a new arm must reach — but whether each site now HANDLES the arm is a
type-narrowing question, and only the compiler answers it for every call
shape at once, including a `Record<T, …>` a grep would read as already
covering `T`.

**A stricter parser's `ok:false` needs a consumer census, not a single fix.**
`output_id` became required on a connector-type options source, so an
old-shape row without it now parses `ok:false`. The scalar field mount
already passed that result through unmodified (a live §2.6 error). The
table-column mount (`table-column-options.ts`'s `parseColumnOptionsSource`)
folded `ok:false` into `undefined` before it reached the column, which read
as "no options source configured" — a silently empty select, not the
required fail-loud message. One parser, two mounts, and only one was ever
checked against the new failure shape it could now produce.

**A "pending intent" gate is one combinator, and a structural test is what
keeps it one.** Choosing a connector with more than one options output holds
a pick as pending until the field/table-column completes it; that pending
state grew across three rounds — `pendingConnectorId`, then an
`onPendingChange` combinator (`OptionsSourceBlock.tsx`, wired into
`FieldEditor.tsx` and `TableColumnsEditor.tsx`'s Save gate), then a fourth
piece of pending state (`pendingBindingTableFieldKey`) that a later round
found missing from the combinator. The design — one combinator, reported once
— was right each time; what was missing was a test that enumerates every
`pending*` `useState` in the block and asserts it is a member the combinator
reports, so a fifth piece of pending state cannot land un-wired the same way.

**An authority widening has two different gaps depending on where the
predicate lives, and each needs its own matrix.** A statement-embedded
predicate — `routes-variant-overrides.js`'s own-owner EXISTS, ANDed into
crud-factory's own UPDATE/DELETE — is a second path a pre-check unit test
cannot see at all, because a mocked driver never evaluates SQL; only a real
schema, seeded and queried (`blueprint-grant-matrix.test.js`,
`delegated-grants-predicate-real-db.test.js`), found its INSERT/UPDATE
two-path bug. `bindings.js`'s home-blueprint arm and
`connector-binding-authority.js`'s `assertBindingTargets` are, by contrast,
ordinary async pre-check helpers (`await checkBlueprintWriteTarget(...)` /
`await callerHasBlueprintGrant(...)`, evaluated before the write rather than
folded into its statement) that the route-level census grep never listed as
a route to cover, and the PR-3 fixture that DID run owned the home blueprint
outright — so the grant arm went unexercised either way; the route-level
matrix must reach every route the spec names, with a fixture where the
grantee reaches the blueprint ONLY through the grant.

## §181 — Control labels never truncate; data cells truncate with title; lint it

`truncate` on an option label, a select trigger, or any other control's
visible text is a different defect class from `truncate` on a read-only data
cell, and the two were being fixed and reviewed as one undifferentiated
class before fmb-2022. A data cell has a fallback: a sighted mouse user can
hover for the full value via `title`. A control label has none — hover is
not a substitute on a touch device, and a truncated option text is a control
whose meaning the user cannot recover no matter how they interact with it.
The rule split in two: control labels wrap (`flex-wrap` / `break-words`,
never `truncate`); data cells truncate and always carry `title` with the
full value. `scripts/cicd/truncate-title-lint.sh` (ship-gate step 41)
enforces this tree-wide on an ast-grep pass over JSX attribute nodes (not a
line-window regex — the first cut used a bash sed window over N lines around
each `truncate` hit, which both false-flagged compliant code whose `title`
attribute fell outside the window and false-negated `truncate` sitting next
to an unrelated `title=` on the same tag) with zero pragmas at ship time.

## §182 — Three lessons from consolidating eight code viewers into one (flow-recipes-batch epic 1, fmb-2034/2035/2045)

**One code-pane mount, many injected extensions.** A second `@uiw/react-
codemirror` mount silently forks the feature set — the pane that gets a new
opt-in (a toolbar button, a resizable height, `{{var}}` highlighting) is
whichever one someone happened to touch, and the other seven quietly fall
behind with no signal that they now differ. `CodeEditorPane` absorbs the
22-feature union the eight prior viewers owned individually as opt-in props;
every other pane threads its own `extensions: Extension[]` in rather than
mounting its own editor. The one-code-pane lint (Ship Gate Step 42,
full-scan, zero baseline beyond three named grandfather pragmas) is what
keeps a ninth mount from reappearing the same way the first eight did —
without it, "consolidate now" decays back into "diverge again" the next time
a pane needs one feature none of the others has yet.

**One `{{var}}` regex source, FE↔BE parity-tested.** The FE already had this
regex duplicated once (`preview-request.ts`'s own `VAR_RE` copy) before the
highlighter extension needed a third consumer — a drifted token grammar on
either FE copy would highlight a token as "known" that the dispatch route
(`connector-dispatch.js`) actually leaves unresolved, or the reverse, and
neither direction fails loudly; it just LOOKS wrong to the author with no
error anywhere. `template-token-extension.ts` imports `connector-vars.ts`'s
`VAR_RE` as the one FE source, and a parity test pins its `.source` against
the BE copy byte-for-byte, so the two can never drift silently again.

**Echoing a resolved request to a browser: resolve from masked sources,
don't mask after the fact (PR-U5, fmb-2045).** `StepTraceCard`'s "Request
sent" section was a client-side RECONSTRUCTION from a frozen pre-dispatch
snapshot — patched twice (a fail-closed context-key list, then a run-start
snapshot) and the family kept returning, because a client snapshot cannot
see what the server actually resolved: three separate routes proved this —
a server-only context token resolved only on the edge, a chain step edited
between run-start and its own dispatch, and a step re-saved after its test
ran. Patching the reconstruction a third time would have been a fourth
route to the same defect. The fix removes the reconstruction: the edge
returns the request it actually resolved and sent (`request_sent`), masked
by the SAME function the run serializer already applies to a persisted row
— never a second masker, never a client rebuild. When the question is "what
did the request actually contain", resolve the ANSWER from an already-
trustworthy (masked) source at the point of truth, rather than computing an
approximation and trying to sanitize it correctly after the fact on every
call site that reads it.

## §183 — Rendered-measure replaces constants: four repeat fixes on the same wrong idea, and what actually broke inside them (grid-measured-width, fmb-2046–2051, 2026-09-08)

**The pattern that kept costing a fix each time.** `EditableDataGrid`'s column-width engine estimated a column's floor from canvas `measureText` plus a table of hand-written per-type/per-decoration px constants — a header padding constant, a gutter arrow-slot constant, an icon-reservation constant, a mirrored-track-width constant. Four separate incidents (fmb-2005, fmb-2018, fmb-2027, fmb-2028) each found ONE wrong constant, fixed that one, and shipped — until the next content shape (a longer header, a badge in a ≤5-column table, a 13-column IP table) proved a DIFFERENT constant wrong. The constants were never the actual content; they were someone's guess at what the actual content would cost, re-derived by hand every time the DOM shape changed under them. The fix this batch took was structural, not another guess: read the real rendered box once (`getBoundingClientRect()` under a one-shot `data-measuring` unlock pass) and freeze THAT. A guessed number and a measured number look identical in a diff until the fifth time the guess is wrong; the tell is the shape of the fix history — the same file, the same kind of off-by-a-constant bug, four times running.

**`inline-flex` is not a smaller `flex` — it removes the free space `justify-*` needs.** `CellValueBox`'s root was `inline-flex` (shrink-to-fit sizing). A centred/right-aligned value inside a wider frozen cell stayed flush-left: `justify-center`/`justify-end` distribute FREE SPACE inside the box, and a shrink-to-fit box's size already equals its content's size, so there is never any free space to distribute. The same shrink-to-fit sizing broke truncation the other direction: with nothing forcing the box narrower than its natural content width, a narrow frozen column let the value's full-width box paint past the `<td>`'s own edge into the next column instead of the inner `truncate` span clamping to the cell. Both symptoms — dead alignment AND leaking overflow — came from the exact same one-word class choice. The lesson generalizes past this component: before trusting a `justify-*`/`text-align` rule on a flex child, check whether the flex CONTAINER's own sizing (`flex` vs `inline-flex`, `w-full` vs none) actually gives it room to move in — an alignment rule with no free space to distribute into is silently inert, and it fails in BOTH directions of the same defect (won't centre, won't clip) rather than one obvious way.

**A stacked decoration and an inline decoration are the SAME wrapper making two different structural promises, and the flex refactor silently kept only one.** Pre-refactor, a value's root was itself `block`/`flex`, and an appended decoration sibling was ALSO block-level by the accident of normal flow — two adjacent block boxes always stack, with no wrapper needed at all. Folding the value onto a shared `CellValueBox` (a `flex` CONTAINER) turned that appended sibling into a flex ITEM instead — flex blockifies then lays out every child along the row regardless of the child's own `display` — so "stacks below" silently became "sits beside" for every column that used to rely on the old accident. The fix (`withStackedDecoration`) does not try to make the decoration "more block" again; it restores the guarantee at the PARENT (an explicit `flex-col` wrapper), because the promise ("this decoration is on its own line") was never actually about the decoration's own display property — it was about what CONTAINER it was laid out inside. Consolidating onto a shared primitive changes what "the same JSX shape" means for every consumer of that primitive at once ([[feedback-consolidating-onto-a-shared-primitive-inherits-its-latent-defects]]); the fix has to restore the invariant structurally, not by trying to recover the old accident.

**A double-count survives exactly where nobody re-derives it by hand.** The header's centred (>5-column) branch mirrored its trailing decoration-cluster width into an empty leading track so the label would sit on the true centre — correct for the label, but a status-badge chip riding INSIDE that trailing cluster got its own width reserved twice: once by the real cluster, once by the leading track's mirror of it. The ≤5-column branch, which has no mirror at all, never had this defect — the same badge, the same component, two different column-count branches, only one of which double-counted. The fix moves the chip OUTSIDE the mirrored 3-track grid instead of trying to special-case the mirror to skip it — removing the shared surface a special case would have needed to know about is more durable than teaching the special case to opt out correctly, especially across a branch boundary the next content shape might reach differently again.

**The Tailwind cwd trap.** A scratch Vite build used for a Chromium geometry check must run with `cwd` set to the worktree itself — Tailwind's JIT scanner resolves its `content` globs relative to that cwd, and an arbitrary-value class like `px-[var(--grid-cell-inset)]` or `min-h-[1.75rem]` (both real classes on the grid header's own title line, `GridHeaderRow.tsx`) is only ever generated if the scanner actually reads the source file containing that literal bracket string; a wrong cwd resolves the globs against the wrong root, silently emits CSS with none of those utilities, and the harness measures a materially different layout with no error of its own — the geometry read still "succeeds", it is just wrong (fmb-2051, PR-Z review batch 1).

## §184 — YAML 1.1 reserved-word quoting comes from the library's OWN schema selection, never a hardcoded list (flow-yaml-dialect epic, fmb-2044/2061/2062)

**The consumer's problem was real and had no clean workaround.** A step's
upstream parses YAML 1.1, whose bool tag resolves
`y|Y|yes|Yes|YES|n|N|no|No|NO|true|True|TRUE|false|False|FALSE|on|On|ON|off|
Off|OFF` (plus octal-looking `010` and sexagesimal `1:30`) — a plain string
`"yes"` serialised under the `yaml` package's default (1.2 core) schema
emits unquoted `yes`, and the consumer reads it back as a boolean. The owner
would not accept a hardcoded yes/no list anywhere in this codebase (a list
drifts from whatever the ACTUAL consumer's parser recognises, and every
future consumer needs its own list).

**The fix is one option, not a list: `yaml` v2's `stringify(value,
{ version: '1.1' })` selects the 1.1 SCHEMA, and the schema owns the
reserved-word set.** The stringifier already knows, for the schema it was
told to target, which plain scalars would round-trip as something other
than a string — and quotes exactly those, nothing hand-enumerated. Adding
`defaultStringType: 'QUOTE_DOUBLE' | 'QUOTE_SINGLE'` force-quotes every
string regardless of schema (a second safety net for a consumer that also
mis-types numeric-looking strings); `defaultKeyType: 'PLAIN'` keeps keys
unquoted UNLESS the key itself would resolve to a non-string in the
selected schema, in which case the library force-quotes the key too (a
`yes:` key emits `"yes":`, independent of the string-quoting option).

**Byte-locked, never re-derived by eye.** `serialize-options.golden.json`
(`docker-api/src/shared/lib/`, mirrored FE-side by the golden test both
runners share) records the exact input object and every expected output
string for all seven `content_type` × `yaml_version` × `yaml_quoting`
combinations, generated once via a read-only `node -e` against the real
`yaml@2.9.0` package and never hand-typed afterwards — the "compare, never
overwrite" rule the fixture's own header states. A future `yaml` package
upgrade that changes quoting behaviour fails this fixture loudly instead of
silently reshaping what ships to an already-integrated consumer.

**A masking pass that re-serialises loses whatever dialect produced the
original bytes, unless it is told the dialect too (fmb-2063, found live,
not fixed in the PR that found it).** `maskSerializedPayload` — built to
redact secret-named keys inside an already-serialised payload before it
reaches a persisted audit column or a masked preview — parses the string
generically and re-emits it with `yaml.stringify(parsed, { lineWidth: 0 })`,
which is the 1.2/plain default (proven byte-equal to the fully-spelled
default options by Y1.5's own equivalence test). Redacting a value inside a
structure and RE-SERIALISING that structure are two different operations,
and only the second one needs to know the dialect the FIRST serialisation
used — a masking pass that round-trips through parse→re-stringify silently
re-derives its OWN default dialect unless the caller's dialect is threaded
through explicitly. This is the same family as §182's third lesson
("resolve from masked sources, don't mask after the fact") one layer
deeper: even a masker that resolves from the correct SOURCE can still lose
information if its own re-serialisation step forgets what made that source
correct in the first place.

## §185 — A log line for a human is a layout problem, not a transport problem (2026-09-07, fmb-2029 PR-1)

Production pods ran `pino-pretty` as a worker transport with its default
multi-line object rendering: one access record printed as ten lines, and
nothing in the layout lined up. The fix is a layout, not a new transport.

**One record, two renderers, same fields.** pino keeps producing one JSON
record per call. `LOG_FORMAT=json` writes it verbatim; `pretty` parses it
in-process and paints fixed-width columns. A parity test walks every key of
a full record and asserts it is either a column or a `key=` pair, so the two
layouts cannot drift.

**Fixed width beats separators.** Spring Boot pads level to 5 and logger to
40 (`%-40.40logger{39}`, truncating from the left so the class name
survives); we pad level 5, svc/kind 17, req 8, src 26 (left-truncated so
`file.js:line` survives). Padding happens before colouring so ANSI bytes
never move a column.

**`src` on every line costs ~6.5 µs.** The §50 `Error.captureStackTrace`
walker moved from error-only to every level under the same 500/s budget;
over budget the column prints `-` rather than disappearing. Measured
6.3–6.7 µs/call across repeat runs on the dev box
(`logger-src-benchmark.test.js`), spec target 20, CI ceiling 50.

**Sync destinations, or the fatal line dies with the process.** pino's
`destination()` is async by default; `process.exit(1)` after a fatal would
drop it. Both destinations open sync; a subprocess test proves the fatal
line arrives in both layouts and that a piped stdout carries no ANSI.

**Why not pino-pretty's `messageFormat`.** Its line builder hard-codes
`[time] LEVEL:`; padded columns cannot be expressed through it, and a
function-form format cannot cross the transport worker. ~120 lines of our
own beat a dependency we could not bend — and AIRGAP curates every package
by hand, so one fewer is a real saving.

## §186 — A bare `.data` ignoreDifferences hides every future key; ignore by key (fmb-2083, 2026-09-10)

ArgoCD `ignoreDifferences` on `fmb-config-shared` was `jqPathExpressions: [.data]`
so `bootstrap-ro-user.sh`'s out-of-band merge-patch of `DB_RO_HOST`/`DB_RO_PORT`
would survive `selfHeal`. But `.data` selects the **whole map**, not those two
keys — every other key's drift (including a brand-new key added in git, e.g.
`LOG_FORMAT` in v3.2.992) was silently ignored too, so it rendered correctly
into the CD repo and never reached the live cluster, with the Application
still reporting Synced/Healthy throughout. The field-manager census
(`--show-managed-fields`) confirmed `kubectl-patch` (the bootstrap script) owns
exactly `f:data.DB_RO_HOST`/`f:data.DB_RO_PORT`; `argocd-controller` owns the
rest — narrowing the ignore to those two exact paths costs the out-of-band
patch nothing and restores git authority over everything else.

**Rule:** an `ignoreDifferences` entry exists to protect one specific
out-of-band writer's specific field(s), never a whole object —
`.data.KEY`/`/data/KEY`, never `.data`/`/data`/bare `managedFieldsManagers`.
A static lint (`argocd-apps-ignore-scope.test.sh`) rejects any
bare/wildcard/piped ConfigMap path under **either** ArgoCD scoping mechanism
(`jqPathExpressions` or `jsonPointers`) in
`infrastructure/k8s/cluster/argocd-apps/*.yaml`, and one scoped only by
`managedFieldsManagers` with no key-level path — checking only the mechanism
this repo happened to adopt first left the other one uncovered. And because
Ship Gate Step 17 runs pre-deploy, `argocd-verify.sh`'s independent key diff
compares each zone's live ConfigMap against the **deployed commit's**
rendered `flat-output/<zone>/configmap.yml` (`git show <sha>` off the
running `fmb-infra`/`fmb-edge`/`fmb-frontend` image tag), not the
checkout's — otherwise a PR that adds a key goes false-red while the cluster
is still on the prior commit; an unresolvable sha or missing rendered source
`warn`s by name and folds into an all-zones-skipped exit 3, never a silent
pass.

**Round 2 (Codex):** a test file is not a gate — `argocd-apps-ignore-scope.test.sh`
was never wired into any `changes:`-gated CI job for an argocd-apps-only diff
nor into Ship Gate's own Step 17 trigger, so the guard shipped advertised but
unexecuted on exactly the diff shape it exists to catch; the checker moved to
a standalone `argocd-apps-ignore-scope-check.sh` both the test and Step 17
(diff-aware) now call, closing that gap. The `.data.<KEY>` bare-selector
regex also had to shrink, not grow: a jq bare selector is only unambiguous
for identifier keys, so `.data.some-key`/`.data.a.b` (dot/hyphen) must use
bracket notation (`.data["key"]`), and `managedFieldsManagers` is now
rejected on a ConfigMap entry unconditionally — ArgoCD applies it
independently of any jqPathExpressions/jsonPointers on the same entry, so a
manager owning the rest of `.data` still hides drift even alongside a
correctly scoped key.
## §187 — Why the gutter samples the max number and why state decorations re-measure (grid-showcase-and-header, fmb-2076–2084, 2026-09-09)

**The painted-page gutter read undercounted before the last page ever mounted.** The gutter column used to size itself from whatever row numbers were actually on screen at measure time — correct on page 1 of a short table, silently wrong the instant a table's row count crossed a digit boundary (10, 100, 1000) and the operator paged forward: the frozen `<col>` was already narrower than the 3-digit number about to render into it. The fix is the same shape as the header/body-height fix one batch earlier (§7.15/§183): stop measuring "whatever happens to be visible" and measure the thing that actually bounds the answer. A hidden `[data-gutter-sample]` cell holding the WIDEST possible row-number glyph (`rows.length`'s own digit count) sits in the same natural measuring pass every other column goes through, so the gutter is sized correctly from the very first mount regardless of which page is painted — evidence: `gutterWidthDelta` measured 0 (or a small positive rounding slack — see below) across all seven showcase tables at both viewports, on page 1 AND after paginating to the true last page, in the same run.

**A data-driven lock changed a column's content without any width term seeing it.** The natural-width pass runs once, at mount or when the COLUMN SET's shape changes — a static per-column flag (a compute rule, a follower binding) is visible to it. A per-ROW state that appears later, driven by data rather than column config (a lock applied to some rows and not others, changeable independent of any column/content-shape change), was invisible to that one-time pass: the column's floor never grew to fit the locked value's own lock-icon + text, and the text silently ran past its own content box with no visual ellipsis to warn anyone — an invisible truncation-equivalent bug, worse than a visible one because nothing LOOKS wrong until the text is compared pixel-for-pixel against the cell's own right edge. The fix is a per-column SIGNATURE (a string derived from which rows in that column currently carry a state decoration) that the engine diffs on every render; a changed signature triggers a re-measure scoped to that ONE column, not a full-table re-measure for what is, by definition, a per-row data change that never touched the column SET.

**Rulings recorded so the next affordance does not have to re-litigate them:** a revert-to-formula mark is visible AT REST because it is the only per-cell signal that a value diverges from its own formula — that is STATE, and state stays visible (the same principle the lock icon above already established); an override-pencil affordance with no state to carry on a non-overridden cell stays transparent at rest and reveals on hover/focus/select — that is pure ACTION; a centred-branch mirror slot is a FIXED spacer sized to the action box, gated on a STATIC per-column flag, never a clone of a data-driven `cellDecoration` return (a follower's or lookup marker's decoration is visible content, not a hidden action, and mirroring it would silently duplicate real information). Every new probe field this batch added states, in its own name or its own comment, which element it reads, what it is subtracted from, and whether that element can move — the discipline that made the fmb-2079 investigation below a same-day close instead of a second design round.

**A "wider than expected" delta needs the two terms it diffs named, or the next reader re-litigates whether it is real slack.** `grid-showcase.spec.ts`'s T6-paged/T7-cap acceptances measure `gutterWidthDelta = +1` at 1600x900 (0 at 900x1440) and accept it — but only because the comment names BOTH sides: `gutterExpectedWidth` is `Math.ceil(sampleGlyphRange.width + 2 * insetPx)` (the hidden `[data-gutter-sample]`'s own text-Range width, rounded UP), diffed against the painted gutter `<td>`'s own `getBoundingClientRect().width` (the engine's real, possibly-fractional assigned width) — `Math.ceil` alone can produce a `+1` even when the engine sized the column exactly right, which is why the assertion is `>= -0.5px` (wider-only) rather than `=== 0` (review batch 1, fmb-2084).

**A probe reading `null` is not automatically the probe's own bug — check WHO is looking before assuming WHAT is broken.** fmb-2079 reported "the showcase has no unlocked/overridable compute column, so the action-reveal fields read null", and the natural first hypothesis was a value-span resolver defect (a read-only computed cell's content is composed differently from an editable one, so a resolver written against the editable shape could plausibly miss it). Measuring directly against the deployed showcase — first against the STANDING template (owned by whichever account first seeded it), then against a fresh copy created and owned by the SAME session doing the measuring — showed the pencil rendering (and the reveal fields resolving cleanly, 0px reflow) on the OWNER's copy and not on the STANDING one. The actual cause was `TableFieldRenderer`'s `disabled` prop: a session that does not own the template being viewed renders read-only, which zeroes EVERY compute decoration (pencil AND revert triangle) unconditionally — a blanket viewer-permission behaviour that has nothing to do with any one cell's resolver logic, and would have produced the exact same "null" symptom on ANY compute column, on ANY template, viewed by ANY non-owner. The card's own premise ("no such column exists") was itself already false — the column existed and was correctly configured the whole time. Two premises were wrong at once; the fix was to stop assuming a null read means the code under test is broken and instead ask who is asking.

## §188 — Three lessons from create/update/compare (flow-recipes-batch epic 3, fmb-2090–2102, 2026-09-11)

**`{{payload}}` follows the current ctx across steps — a compute/merge step re-serialises the next step's body.** The update branch's shape is prepare → GET (captures `remote_refs`) → a Merge-by-key compute step → one PUT whose body template is still `{{payload}}`, unchanged from the create branch. That only works because each step re-serialises its OWN `{{payload}}` fill from whatever the running context currently holds — a compute step returning a new `payload` value becomes the source for every LATER step's default fill, not a one-time constant frozen at run-begin. The reason: a separate merge step exists precisely so the ids it writes reach the later PUT, and the earliest design's `{{payload}}` fill was a fixed string computed once — a merge step's output would then need its own bespoke template wiring instead of reusing the same `{{payload}}` token both branches already share. Re-serialising per step is the smaller, uniform fix; it is epic-2's own fix (PR-Y1 Task Y1.0), consumed here rather than re-implemented (amendment A1) — a dependency, not a re-fix, is itself worth stating: the natural instinct on hitting a familiar-looking gap is to fix it again in the new epic, and doing so would have created a second implementation of a rule one already exists for.

**Merge by key stores both the preset config and the generated code — the code is runtime truth, the config re-drives the UI.** `flow_recipe_steps.preset_config` (`{ kind:'merge_by_key', rules }`) and `before_code` (the generated JS) are BOTH persisted, deliberately redundant. The sandbox only ever runs `before_code` — `preset_config` is never read at dispatch time — so a stale or malformed config can never change what a step actually does. Its only job is letting the editor re-open the rules table pre-filled next time, and letting it DETECT drift: if a hand-edit changes `before_code` so it no longer matches what the stored config would regenerate, the editor shows a "detached" banner and offers "Reset to preset" rather than silently either re-generating over the hand-edit or silently trusting a config that no longer describes the code. Two representations of "the same" value only stay safe together when one is named the runtime truth and the other is read-only UI convenience that can safely be wrong.

**Why a server-signed compare token replaced client-supplied compare context.** The first compare-pass design threaded the client's own `context`/`outputs` through to the per-step dispatch endpoint with `run_id: null` (the same shape an ad-hoc single-step test already used). Codex found two consequences of that shape, not one: (1) no server-authoritative template bag existed for a compare-branch step referencing `{{context.template.*}}`, so any such GET failed `MISSING_INPUT` and blocked the WHOLE update path for that recipe — not a security gap, a correctness gap; (2) separately, a caller who could reach the dispatch endpoint at all could point it at ANY of the recipe's GET steps, not only the compare-branch ones, because nothing at dispatch time re-checked step membership against the compare set. Both traced to the same root: `run_id: null` carries no server-resolved identity for the endpoint to check ANYTHING against. The fix mints a short-lived, purpose-tagged HMAC token at compare-begin — the moment the SAME access predicate `run-begin` uses has already run — binding `(templateId, recipeId, userId)`; the dispatch endpoint re-verifies the token (never trusts a client claim) and re-applies the exact step-membership predicate compare-begin used to select candidates, closing both gaps with one mechanism instead of two patches. General lesson: a `null`-shaped "no real subject here" placeholder is not neutral — everything a real subject would have let a caller *and* a downstream reader check evaporates with it, and both the availability gap and the scope gap were symptoms of the same missing subject.

## §189 — Why value-scanning a stored body was rejected in favour of source-side masking (flow-mask fail-closed, fmb-2074/fmb-2055, 2026-09-11)

An earlier design for closing the `rendered_payload` gap proposed scanning the FINAL stored/displayed text for secret-shaped values (regex patterns, entropy heuristics) as the primary control — the same shape `redactValueLeaks` already runs as defense-in-depth over `error_body`. Rejected as the primary mechanism: every CI/secrets-scanning vendor's own documentation names the same structural limit — a value-scanner only catches a secret in a shape/encoding its pattern set anticipated, and an encoded, transformed, or merely differently-formatted copy of the identical secret (base64, URL-encoding, string concatenation, a different key wrapping the same bytes) defeats it silently, with no signal that anything was missed. n8n's public write-up of its own credential-masking design reaches the identical conclusion from the operational side: "a credential never enters execution data" is enforced by never letting the value reach the general-purpose data path in the first place, not by scrubbing it back out downstream. `flow_recipe_runs` already had a working instance of the structural alternative — PR-U5's `maskRequestSent` (§7.14, SDD.md) resolves `request_sent` FROM masked inputs and a masked `auth_config`, so a TEMPLATED value reads `****` by construction regardless of what format the body ends up serialized in; nothing downstream needs to recognise the secret's shape because the secret was never substituted into the text in the first place. "Masked sources" names that limit precisely: it covers masked inputs and masked `auth_config`, not `request_config`'s own body/header templates, which pass through unmasked — a secret an author hand-types as a literal there is not a substitution this mechanism ever sees, and it survives an opaque body the residual key-name pass cannot parse into. Fix batch 1 (2026-09-11) corrected prose that had overstated this as "already made safe" for every format; the accurate scope is narrower, and the surface it leaves open is test-only and manager-only (a Test-panel dispatch preview), never persisted — a materially smaller exposure than the durable, every-caller-readable `rendered_payload` row this design closed. The residual value-scan (`redactValueLeaks`) still runs, but only as a second layer over an UPSTREAM-CONTROLLED body (`error_body`) this codebase cannot mask at the source at all, because the source is an external server's response. Applied to `rendered_payload`: the fix is not "scan harder", it is "make every writer either produce text from a masked source, or admit it cannot and fail closed to a placeholder" — the same choice, generalised, that closed the URL/header/opaque-body gaps in PR-U5.

## §190 — One selector, one grid: consolidation exposes the naming contract two implementations had been hand-syncing (schema-builder-source-fields epic, fmb-2036–2039/2130/2160, 2026-09-13)

**Extracting a shared component surfaces every place its callers used to disagree on wording, not just on behaviour.** `FieldSourceSelector` (§7.19, SDD.md) replaced four private editors `ComputeRuleBuilder.tsx` had hand-rolled for Calculated, then became the same component `FieldDecisionLinkBlock.tsx` uses for Decided — a genuine consolidation, output shape unchanged (`SourceOperand`, no new persisted union member). `RuleGrid` did the same for the Decided rules table and `OverrideGrid`. Both extractions correctly kept the SHAPE (columns, validation, row policy) as caller-owned — but both also, as a side effect, retired a hand-rolled control (`LinkCell`, `OverrideGrid`'s View/Edit toggle) that had carried an explicit `aria-label` no one had written down as a REQUIREMENT of the shared replacement, only as an incidental property of the old code. `RuleGrid`'s always-editable mode opened a live `type:'select'`/text editor with no name at all until fmb-2135 added `GridColumn.resolveEditorAriaLabel` — a per-column, row-scoped resolver fired only in the editing branch, deliberately separate from `CellPolicy.hint` (which answers "why is this locked", a different cell state, a different question). The general lesson: when a shared primitive replaces N hand-rolled ones, audit what each hand-rolled version rendered that was never expressed as a PROP on the primitive — an accessible name is exactly the kind of property that has no visual diff to catch it in a screenshot-based design pass.

**"Max rows" was mostly wiring, not new grid capability — and its one real correction was to a promise, not to a mechanism.** `EditableDataGrid` already implemented the row cap (`maxRows`, `effectiveMaxRows` in `useClipboardFill.ts`) and the gutter-hide (`showRowNumbers={false}`) before fmb-2037 shipped; the card's actual PR is `table_config.maxRows` plumbing plus the paste-notice fix on the legacy row-append/replace fallback. The one substantive DECISION was correcting the empty-state semantics: an early draft would have let an empty `Max rows` mean "unbounded", when the engine's real floor is the shared 500-row default (`TABLE_FIELD_MAX_ROWS`) — the fix was to change the UI's PROMISE ("Default (500)", not "unlimited") to match a ceiling that already existed, not to build a new no-cap code path. A capability that already exists in the platform is cheaper to expose correctly than to imagine a new one; the audit that catches the "unlimited" claim early is asking whether the code underneath can actually deliver what the copy says, not whether the copy reads well.

**Retiring a legacy code path is a different-sized job than silencing its symptom, and the spec should say which one a PR is scoped to.** fmb-2037/SB-D closed the paste-notice gap on `useClipboardFill.ts`'s legacy row-append/replace fallback (a `toast.warning` + a true landed count, matching what the primary cell-anchor path already did) — genuinely small, because it added a message without touching the write logic underneath. Retiring the fallback itself — routing both legacy modes through the SAME `cellAnchorPaste` primitive the primary path uses, instead of their own independent column-merge logic — was correctly named a SEPARATE, larger unit at spec time (§7, "a larger grid refactor," PR-Z) and stayed correctly out of scope at closeout too (re-carded as fmb-2161 rather than attempted under a ≤3-diff-shape budget): 614 lines of existing test coverage sit on the current two-path shape, and collapsing two independent write-merge implementations into one is an architecture change, not a notice fix. Naming the SIZE difference between "add a warning to an existing path" and "delete a path and rebuild its callers on another" at spec time — rather than discovering it mid-implementation — is what let both PRs land at their own correct size instead of one ballooning to cover both.

## §191 — Dispatch-free derivation feeds both a live view and a save gate; a colourer's tolerance is a config flag, not a second extension (flow-authoring-ux epic, fmb-2166–2170, 2026-09-15)

**One pure derivation, two consumers, is what keeps a "preview" honest with a "check".** The wiring view (a chain rail showing what each step receives/emits, colour-coded green/yellow/red/grey) and the step editor's save-time notices (three findings: an unfilled token, a non-JSON-string hook output, a `parse(...)`-of-object pattern) look like two features but are ONE derivation (`deriveChain` in `wiring-derive.ts`) consumed by two callers (`WiringView` for display, `lintChain` for the findings list) through one hook (`useChainModel`). Building them as two independently-maintained readouts of "what does this step actually receive" would have let the view and the save-time check silently disagree about the same fact — the exact failure mode a `RunStepResultsList`-style second implementation would reproduce (§190 above, same lesson, different surface). The derivation itself stays dispatch-free by running entirely in the SAME sandbox the step editor's live preview already uses (`runStepCode`, `StepRequestPreview`'s own primitive) — no new execution surface, no new place a step's JS can run outside the existing gated environment.

**A stricter validation mode belongs on the existing primitive as a flag, not as a parallel one.** Flow step request fields (url/headers/body) needed a STRICTER token vocabulary than the connector/link-compose fields that share the same CodeMirror extension — a bare `{{link}}` typed into a body field that never receives such a key should colour unknown, where the connector editor's own tolerant defaults (reserved names + `payload.`/`response.` prefixes always known) would wave it through. Rather than fork `template-token-extension.ts` into a stricter sibling, `TemplateTokenConfig` gained one optional `strict?: boolean`: when set, the two blanket fallbacks are skipped and ONLY the caller's own `knownKeys` list decides known/unknown. Every existing caller keeps its old behaviour by simply never setting the flag — the stricter surface opts in, rather than every existing caller needing to opt out of a new default. The same shape recurs across this codebase (D4 in the plan, and see `strict?: boolean` on other per-caller behaviour switches this repo has added elsewhere) precisely because a parallel extension would need to be kept in lock-step with every future change to the shared one, and eventually would not be.

**A loop that `break`s on failure needs an explicit sweep for "what never ran", or those entries just vanish.** Both run producers (`run-chain.ts` browser, `flow-recipe-run.js` server) dispatch a mode-filtered step list in order and stop on the first failure — correct for the dispatch itself (no side effects past a known-bad point), but the ORIGINAL shape simply `break`s out of the loop, so every step after the failed one never gets a `step_results` entry at all. That is invisible until an operator counts: a recipe with 5 selected steps and a failure at step 2 shows a run detail with 2 entries, silently under-reporting the recipe's own step list — indistinguishable, without cross-referencing the recipe definition, from "this recipe only has 2 steps". The fix converts the `for...of` loop to an indexed loop that remembers where it stopped, then sweeps the remainder into `{ skipped: true, skip_reason: 'failed_upstream' }` entries after the loop — deliberately a DIFFERENT `skip_reason` from the pre-existing `'mode'` skip (a step the run's own mode never selected), because "excluded by this run's mode" and "never reached because an earlier step in this same run failed" are different facts an operator needs to tell apart, and folding them into one value would have hidden that difference just as surely as dropping the entries did.

## §192 — A shared casing function does not remove the need for a shape-check; a convergence has to name its own phases (value-pipeline epic, fmb-2175, 2026-09-15)

**One `applyCaseMode` chokepoint stops two layers from disagreeing on "what is upper case"; it does not stop a THIRD layer from never calling it.** `CaseMode` (`src/platform/lib/case-mode.ts`) is shared by a field-level `text_case` attribute, a table-column's `text_case`, and the compute engine's `upper`/`lower`/`title` transforms — the payload-time chokepoint (`build-transformer-payload.ts`) is the fail-closed guarantee, but VP-A's own batch explicitly left the connector-apply write sites (`useFmbConnectors.ts`) un-cased, reasoning "the chokepoint backstops them". That reasoning is correct for CORRECTNESS (the save-time re-apply always wins) but wrong for UX (a connector-fetched value sits visibly un-cased in the grid until the next save) — the two are different claims, and closing the sink item meant re-deriving which of the hook's four internal write sites could safely case WITHOUT corrupting something else the chokepoint does not touch: fan-out provenance. Two of the four write sites (`applyTableRows`/`commitTableRows`'s 'clear' branch, `applyCrossTableRows`) wipe that table's connector provenance in the SAME write, so casing the stored bytes there is inert to anything downstream; the other two (`applyFanoutRows`, `commitTableRows`'s fold/reconcile branch) re-derive a fan-out row's SIGNATURE from the stored/current row and compare it against a signature recorded from the connector's ORIGINAL uncased values — casing the stored bytes there would desync that signature on the connector's own next re-apply, so they stay un-cased on purpose, and the reason is written at the call site, not just in this paragraph.

**A predicate that checks a SHAPE has to be re-audited every time the shape grows a new dimension.** `isSingleFieldMirror` (`field-value-source.js`) decided `value_source='copied'` eligibility by checking op/separator/part-count/part.type/part.key — correct the day it was written, when a concat part had no other properties worth checking. VP-C then gave a concat part its own `transforms` array, and nobody revisited the mirror predicate, because nothing about VP-C touched `field-value-source.js` directly — the two changes were in different files, shipped in different PRs, reviewed by different seats. `upper(a)` and `a` are not the same value, so a part with a transform is not a mirror; the fix is one more field on the same shape-check, but the LESSON is that "does this rule have a copy on another layer" (STANDING-BRIEF §4, question 3) has to be asked again every time the shape UNDER a rule grows, not just when the rule's own file changes.

**`title` and `capitalize` are two different algorithms because they answer two different questions, and naming the split prevents a future "aren't these the same" merge.** `CaseMode`'s `title` capitalises every Unicode WORD boundary in a string ("mary ann smith" → "Mary Ann Smith") — the shape a `text_case` attribute or a `same_table_column` transform needs, because it is shaping an entire field's worth of free text. The compute engine's `capitalize` transform kind capitalises only the string's FIRST letter ("mary ann smith" → "Mary ann smith") — the shape a concat PART needs when it is being joined into a larger assembled string and the author wants "start of this fragment reads as the start of a sentence", not "every word in this fragment is a proper noun". `capitalize` therefore has no `CaseMode` counterpart and lives only in `applyPartTransform` (`compute-rule.ts`) — a deliberate omission, recorded here so a future "why are there two capitalisation functions, let's collapse them" pass does not merge two things that answer different questions into one that answers neither.

**A retirement needs three numbered phases with an explicit gate between them, or "temporary" dual-read becomes permanent by default.** The legacy standalone `transform` op is retired from AUTHORING (the read-side normaliser in `normalize-compute-rule.ts` turns a stored one into a one-part concat on read) but the BE validator still accepts the old shape on write — phase 1 of a three-phase plan tracked on `fmb-2144`: phase 2 (a `custom` migration-steps entry that rewrites every stored row) is owner-triggered only, never auto-scheduled, because a migration that rewrites `compute_rule` JSON across every blueprint needs an explicit "every zone is at least on the phase-1 version" confirmation first; phase 3 (delete the dual-read, make a legacy shape at runtime a surfaced error) is a version after that. Without the card naming all three phases and their gate, "ship the dual-read now, migrate later" reads exactly like "done" the moment phase 1 ships — the same failure mode this repo's Deferred Items Registry rule (CLAUDE.md §5) exists to catch, applied to a migration instead of a code TODO.

## §193 — Two shared leaves replace N hand-rolled copies; "remember per site" is a value-reset REPLACED, not a new option bolted beside it (display-layer epic, fmb-2176–2179, 2026-09-15)

**`ExpandableBlock` and `ValueText` each collapse a family of copies onto one component with one persistence helper underneath — the same "N hand-rolled implementations of one rule" shape §190/§192 already named, applied to layout instead of casing.** Before DL-A, every fixed-height JSON/code/log/body pane (`ReadonlyJsonView`, `JsonViewer`, a handful of hand-rolled `h-[Npx]` wrappers) wired its own collapse/expand toggle and its own `localStorage` try/catch; before DL-B, every read-only/locked/computed/select-display value either truncated silently or grew its own ad-hoc title/popover. Both consolidations kept the UNION of what their call sites needed (`feedback-consolidation-keeps-the-union-of-features`) rather than the lowest common denominator: `ExpandableBlock`'s `collapsedHeightClass` exists only because `BodyEditor`/`CodeEditorPane` need a DEFINITE collapsed height (a percentage-height child resolves against nothing under a `max-height`-only ancestor), while every other caller is content with `collapsedMaxHeightClass`; `ValueText`'s LEAF contract (`value: string`, never `children`) exists only because a composite cell (a lock glyph, a diff annotation) needs its decorations to sit OUTSIDE the measured span, never inside it, or the overflow measurement answers "does this wrapper overflow" instead of "does the text overflow". The 13 raw `localStorage` try/catch copies these two consolidations left behind (`FmbHierarchy`, `FmbTemplates`, `TransformerListPanel`, `TestConnectorModal`, `useTransformerBlueprintFields`, `useConfigSplitter`, `EditableDataGrid`, `useColumnVisibility`, `api-connectors/layout-pref`, `fmb-input-save-with-generate`, `hidden-field-reason-pref`, plus two under `flow/builder/` left for the CV batch's own overlap boundary) all migrated to one home, `src/platform/lib/safe-local-storage.ts` — a preference read/write is now one function call everywhere, not a per-site try/catch shape a reviewer has to re-verify is correct each time it is copied.

**"Remember per site" is a REPLACEMENT of a reset, not an addition beside it — the two behaviours cannot coexist, and naming which one wins at design time avoided a second implementation deciding it differently later.** The pre-DL-A code reset `expanded=false` on every value change (`ReadonlyJsonView.tsx`'s own `useEffect(...,[value])`); DL-A's `ExpandableBlock` persists the choice per `siteId` in `localStorage` instead. A caller whose mount is reused across records with no React `key` (a dialog rendered once, fed a different record) MUST fold the record's own identity into `siteId` (`'run-detail:rendered_payload:' + runId`) — otherwise a reused mount reads the PREVIOUS record's persisted choice, silently reintroducing a cross-record leak the old value-reset behaviour used to prevent for free. The value-reset was not a bug to route around; it was the mechanism doing the isolation job `siteId`-folding now does explicitly and by convention rather than implicitly and by accident — replacing it without carrying that isolation forward would have been a regression wearing a "consolidation" label.

**A shared component's OWN latent defect and its OWN cn()-order contract both need a test, or the merge comment they document is unverified prose.** DL-Z's own sink turned up one of these directly: `ExpandableBlock`'s render comment promised the block's own height-cap class always wins over a caller's conflicting `scrollBoxProps.className`, but the `cn()` call underneath listed the caller's class LAST — `tailwind-merge` keeps the LAST class in a conflict group, so the caller actually won, the opposite of the documented contract. No existing call site passed a conflicting class, so nothing visibly broke; the fix reordered `cn()` to put the block's own classes last and added one test that goes red on the old order — the same `feedback-reasoned-not-measured-ships-false-claims` shape as the grid-leaf read-count verdict alongside it (a 200×6 grid page's `ValueText` leaves measured at 2,400 `scrollWidth`/`clientWidth` reads on mount, kept as one synchronous per-leaf read rather than batched, because every leaf's `useLayoutEffect` belongs to the same commit with no DOM write interleaved between one leaf's read and the next — the shape that would force a reflow per leaf never occurs here).
## §194 — A "retire this view" decision needs a usage signal the server cannot see, so the counter has to live where the preference does (flow-chain-view-v2 CV-Z, fmb-2209, 2026-09-15)

**When a preference is per-browser `localStorage`, the count of how often it changes is per-browser too — there is no fleet-wide number to ask the backend for.** The steps-stage view toggle (D1, `layout-pref.ts` `readStepsView`/`writeStepsView`) decides Chain vs List with no server round-trip at all, which is exactly why it can default open-source-safely and never needs a migration — but it also means "how many authors still switch to List" is a question with NO answer sitting in any database. CV-Z added `readStepsViewSwitches()`/the `fmb.flow-builder.steps-view-switches` key next to the pref it counts, incrementing `{list,chain}` only when a write's new view differs from the PREVIOUSLY STORED one (read before the pref itself is overwritten) — a same-view write is not a switch. It has no UI and is read once, manually, via `localStorage.getItem(...)` in devtools on a browser that has actually been used for authoring. This is a deliberate scope boundary, not a shortcut: a real usage metric would need a server-side event and a decision about who is allowed to see it (privacy, cross-org rollup) that this repo has not made for ANY authoring-UI interaction, and building that pipeline to answer one retirement question would be answering a much bigger question by accident. The counter's `since` timestamp is stamped once, on the first switch a browser ever records, so the eventual read can at least say what window the two numbers cover — the honest scope of a per-browser sample, not a claim of statistical coverage it cannot make.

**A mocked sandbox boundary can agree with a fix by coincidence — only a test that crosses a REAL clone boundary can tell wrapped from unwrapped code apart.** OC-1 fb2's fix (wrapping `render-payload.ts`'s sandbox code through the same `wrapCodeForSandbox` `runStepCode` already uses, so a function/symbol output throws a structured error inside the sandbox instead of surviving to `postMessage`'s structured-clone step) had an existing green test — `executeInSandbox` mocked to hand the function value straight back — that could not have distinguished the fixed code from the broken code, because the mock never crosses a clone boundary at all; `encodeOutputValue`'s own downstream call already produced the same nice message regardless of whether the sandbox code was wrapped. The new test instead genuinely executes the code TEXT sent to `executeInSandbox` (`new Function('payload','context', code)`, the same pattern `step-exec.test.ts`'s template tests already used) and calls Node's real `structuredClone()` on the sandbox's return value — the same operation `postMessage` performs — so it goes red on the raw `DataCloneError` text before the fix and green once the wrap makes the encode throw before the clone ever runs. The general shape: a mock that returns a canned value can validate everything DOWNSTREAM of a boundary while being provably blind to whether the code crossing that boundary is even the code under test.

## §195 — Why "linked by hand" is derived, not stored; why the compare draft has exactly one home (flow-run-data epic, fmb-2198/2199, 2026-09-15)

**A boolean that is a pure function of two columns already on the row is not a third column — storing it invites the two to drift.** "Linked by hand" (an external id pointed at a remote record without ever having run) is `flow_external_id != null && flow_last_run_id == null` — both facts already live on `user_templates`, already written by `link-existing` and every real run's finalize. A stored `linked_by_hand` column would need writing at every one of those sites, in the same statement, forever in lock-step with the two columns it duplicates — and the FIRST time a future write path touched one column without the other (a manual DB fix, a new endpoint, a migration backfill), the flag would read a lie no code path could detect. Deriving it in `useFlowLinkStatus` costs one boolean expression and can never drift, because there is nothing to drift FROM — it is recomputed from the same read every time. The general shape: before adding a column to remember a fact, ask whether the fact is already implied by columns that exist: if REMEMBERING it costs no I/O (a pure function of already-loaded data), a stored copy only adds a second place the same fact can go stale.

**Three review rounds on the same PR (RD-4, fmb-2198) kept re-finding the same defect through a different door — the fix was to remove a state, not add one.** The compare-setup feature (pick a local list and a remote list on a GET step, which then previews a diff before an update) went through three "the pick doesn't stick right" rounds: round 1 made picks live drafts that only committed on the step's own Save; round 2 added a `compareSpecPersistedRef` so an already-saved recipe wouldn't re-PUT an unchanged spec; round 3's confirm found that a DISCARDED pick (Back → Leave without saving) still reached the recipe on some LATER step's unrelated Save, because the parent held its OWN `compareSpec` state that a pick had written into directly, alongside the workbench's own draft — two homes for one value, and every round's fix had been reconciling them harder rather than removing one. The rule that ended it (CLAUDE.md §3 Token 紀律 5's "is this a patch or a design problem" question, answered on the record for round 3): when every fix round adds another piece of coordination state to keep two copies of a value in sync, or the same defect keeps returning by a different route, that is the signal to delete a copy rather than add a third synchronization mechanism. The shipped shape has ONE home: the draft lives only in the step workbench until that step's OWN Save; the parent's `compareSpec` is only ever the LAST-PERSISTED value, read back from the recipe's own PUT response — never written from a pick, never mirrored into a ref. A value with two owners does not get safer with a third piece of code keeping them in sync; it gets safer with one owner.

**A step's own trigger mode is not the same axis as which pass reads its output — conflating them is fixable only by re-deriving the resolution path.** RD-5's fixture work assumed (from the plan's original guess) that the existing `demo-get` step could simply gain `step_runs_on='compare'` and keep doing double duty for both the real update pass and the read-only preview. `step-select.ts`'s `stepRunsInMode` says otherwise, on purpose: `mode==='compare'` selects steps with `runs_on==='compare'` ONLY, and `mode==='create'|'update'` explicitly excludes a `'compare'`-tagged step (`if (on === 'compare') return false`) — a compare step is compare-ONLY by policy, precisely so a compare preview can never smuggle in the write the real pass performs. A step that must run in BOTH the real pass and the preview therefore cannot BE the trigger; it needs a dedicated sibling copy carrying only the trigger. The same investigation surfaced a second axis error one level up: `compare_spec.remotePath` is resolved against the chain's `finalCtx`, which holds only what a step's own before/after code explicitly returns as an output (`step-exec.ts` — there is no engine-provided "the raw response" namespace) — so a path picked directly off a RESPONSE tree node (what the picker UI shows) is a foreign coordinate system from what the resolver reads, and no path string can bridge them without the step's after-code explicitly re-exporting that value under a matching output key. Two different "this doesn't do what picking it implied" defects, same root shape: a control let the author pick a coordinate in one space (a step's mode; a response's shape) while the code that consumes the pick reads a DIFFERENT space (which pass a step runs in; what a step's own code exported) — and the fix in both cases was to make the two spaces the same thing (a dedicated step; an explicit after-code export) rather than to write a translator between them.

## §196 — Why a blocking validation error is a persistent summary, not a toast; why the draft offer is absent on a published record (data-entry-required-gate epic, fmb-2241/2242, 2026-09-16)

**A refusal that vanishes on its own reads as a notice, not as "nothing was saved."** The required-field gate on `/data-entry` (`Generate`, `Generate & save`, the commit button) used to end a blocked press in a single 4-second toast — by the time an operator looked up from typing, the only evidence the press had failed was gone, and nothing on screen said the record was unsaved. The industry baseline for a blocking validation error (GOV.UK's error summary, WCAG 3.3.1) is not a toast at all: a persistent block naming every failing field, inline errors under each one, and focus moved to the block — it stays until the operator either fixes the fields or leaves some other way, so "did this save" is never a question the operator has to remember the answer to. A toast is for an outcome that already happened and needs no action; a refused write is closer to a form of unresolved state, and unresolved state that disappears on a timer is a lost signal, not a kept one.

**Everything the summary shows is derived fresh from a snapshot of WHICH fields failed, never a stored copy of the failure itself** — see LEARN's own recurring shape above (§193, §195): a blocked press stores only the failing field keys plus a counter (`ValidationBlockSnapshot`), and `deriveValidationSummary` (`fmb-input-validate.ts`) recomputes the item list, each item's `scrollable`, the heading, and the count on every render by re-running the SAME `collectFieldErrors` the press itself used, narrowed to the snapshot's keys. Two earlier attempts kept the failure list as its own piece of state and both went stale a different way: one kept a `useEffect` that fired on every keystroke because the derived array's identity changed each render (fixed by keying the focus effect on the snapshot's counter, not on the item array); the other left a resolved field's message on screen after a connector/auto-fill/decision-table write, none of which touch `errors` the way a manual edit does (fixed by deriving straight from live values, which any write path updates). The lesson restated for a third context: a UI surface describing "what is currently wrong" is safest computed from the current truth on every read, not maintained as a second copy that every write path must remember to update.

**One classification feeds two carriers, so a wording rule can never say two different things about the same press.** The gate blocks on more than an empty required field — a checkbox under its `minSelected` floor, a required table column, an invalid stored boolean value — and the legacy "N required field(s) empty" heading misnames any of those. Rather than have the summary heading and the action bar's status row each decide independently whether the blocked set is "all empty" (which a code change to one could silently leave inconsistent with the other), `deriveValidationSummary` computes `allRequiredEmpty` once, against the SAME message string (`REQUIRED_EMPTY_MESSAGE`, shared with `validateChoiceSelection`'s own required branch) both call sites that can produce a plain empty-required failure already use, and both the summary heading and the status row read that one flag. The general rule: when two on-screen surfaces need to agree on a classification of the same underlying data, compute the classification once and hand both surfaces the answer — never the raw data plus a copy of the rule.

**An attribute gated on the wrong condition is invisible until someone clicks the thing it was supposed to enable.** The summary's field links depend on a DOM attribute (`data-field-key`) `FieldRenderer` renders on a field's wrapper so `focusFieldControl` has something to scroll to when the field type (a table, a checkbox group) mints no single focusable control. That attribute existed already — for the compare view's own field-jump — gated on `compareRingActive`, a prop the real data-entry page never sets. The summary's link for exactly those two field types was a button that did nothing, and every test written against the compare view passed, because the compare view was the only caller that ever set the gating prop. The fix was to stop gating a structural lookup target on a feature flag for an unrelated consumer: `data-field-key` now renders unconditionally (only `data-diff`, the compare-only visual ring, stays gated) — a hazard worth naming generally: an attribute two features share is not "owned" by whichever feature's prop happens to gate it, and a green test suite proves only that the caller under test set that prop.

## §197 — One parse/format home per runtime; a formatted string is emitted, never stored (date-field epic, fmb-2236-2239/2255/2257, 2026-09-16)

**The stored value is always ISO; every consumer that wants a different shape gets it from ONE function, never a second parser.** `blueprint_fields.date_config` (`{format?: DateFormat}`, six-member fixed vocabulary) governs display and entry only — the column itself, and the `payload`/`generated_outputs` values every other layer reads, hold `YYYY-MM-DD` or `''`, regardless of the field's configured format. `src/platform/lib/date-format.ts` (FE) and `docker-api/src/shared/date-format.js` (BE) are the two runtimes' sole parse/format implementations, kept in lockstep by a shared fixture (`docker-api/tests/fixtures/date-format-cases.json`) rather than a shared npm package — docker-api carries no date-fns dependency, and giving the two runtimes different date engines would let them disagree on an edge case (a leap-year boundary, a two-digit-year convention) the fixture happens to miss. `list-query.ts`'s existing lexical sort needed no change for the new type: ISO sorts lexically identical to chronologically, so a `date` column is correct under the SAME comparator every other string column already uses — the format only matters at render/entry, never at the sort comparator.

**A formatted display string is emitted at exactly three value-leaving points, and nowhere else stores or forwards it.** `build-transformer-payload.ts`'s `payload.form` (the transformer's own input), concat/compute sources, and connector input values each format a date field's stored ISO through the one shared function at the moment the value leaves the app's own data model — a corrupt/non-ISO stored value fails closed to `''` at every one of the three, never a throw, never the raw garbage string. A date field is refused outright (not silently coerced) as a Decided condition source, a decision-table column, and an import target for another type's config — a date has no ordering-comparable domain the rules grid could offer, so the runtime classify gate that drives all three refusals shares the SAME scalar-only type map the FE's `SCALAR_ONLY_TYPES` uses, rather than three independent "is this a date" checks that could drift.

**`DateCell`'s commit contract: a draft commits only on a REAL change or an explicit "I am done" signal — never on every blur.** Typing edits a local draft; blur or Enter parses it through `parseDateInput`, and `onCommit` fires only when the parsed ISO differs from the last COMMITTED value, OR the operator explicitly completed the edit (Enter, a calendar pick). This matters past "avoid a redundant call": the grid's own editor wrapper treats `onCommit` as "the edit is done" and closes on it — a naive "commit on every blur" would close the editor on the blur the picker BUTTON's own click causes (a click meant to OPEN the calendar), because opening any popover trigger blurs the currently-focused input first. The trigger's own `onMouseDown` `preventDefault` keeps focus in the Input across that click as a first line of defense; the blur/no-op-reparse rule is the second, independent one — belt-and-braces, not one covering for a missing other. A rejected parse never commits at all (right or wrong keystroke, the draft stays local until it either resolves or the operator escapes), which is what makes "type an impossible date, then Save" a no-op against the stored row rather than a corruption path (verified live, `e2e/date-field.spec.ts`).

**A write-boundary rule enforced on the primary write routes is not enforced until the import path and every OTHER writer of the same target are threaded through the SAME function.** Two gates completed the date-field write boundary rather than adding a parallel copy: (1) `blueprint-field-import-guard.js` (the plain-JSON `/blueprint-import` path) now calls the identical per-type config gate (`isPayloadInconsistent`) the create/update write routes already used, so an imported row carrying `date_config` on a non-date field (or `choice_config`/`boolean_config` on the wrong type) is rejected with the same error code regardless of which door it came in — a census of every blueprint-write route was the actual fix, not a hand-added check on the one route a card happened to name. (2) The decision-doc write route (create/update/import, all three) resolves every condition/output key against the blueprint's LIVE fields and rejects the scalar-only set (`table`, `checkbox`, `date` — a domain no rules-grid comparison is meaningful over) reading from the SAME shared fixture the FE's `SCALAR_ONLY_TYPES` reads, so "which types can't be a decision key" has exactly one written-down answer, checked by a parity test that fails if the two ever diverge rather than trusting two hand-maintained lists to stay in sync.

## §198 — Why the reveal popover never takes focus, and why F2 (UI-2235, fmb-2235, 2026-09-16)

**The popover cannot take focus because a grid cell editor's own commit/close cycle is wired to blur, not to a separate "I'm done" event.** `RevealableInput` (`src/fmb/components/common/RevealableInput.tsx`) gives every single-line editable scalar `<Input>` the same one-click "…" reveal `ValueText` already gives read-only values — but a real Radix `Popover.Trigger`/focus-following-open pattern (the one `ValueText` itself uses, since its trigger IS the value) would move DOM focus onto the popover content the instant it opens. For an editable input sitting inside a grid cell editor (`grid-row-cells.tsx`) or a form field with its own `onBlur` commit, that focus move IS a blur of the input — which the caller reads as "the operator is done editing" and closes/commits on. Revealing the full value would silently end the edit it was opened from. The fix mirrors an existing precedent one file over (`DateCell.tsx:229-245`'s trailing calendar button): `onMouseDown` on the glyph and on the whole popover content calls `preventDefault()`, which suppresses ONLY the native focus-follows-mousedown behaviour, not the click that opens the popover — and both of the popover's own auto-focus hooks (`onOpenAutoFocus`/`onCloseAutoFocus`) are explicitly prevented rather than left to a Radix default that assumes a registered `Popover.Trigger` exists (this component drives `open` state itself off a plain button, anchored via `Popover.Anchor`, precisely so there is no trigger ref for Radix to (mis)manage focus around).

**F2, not a second Tab stop, because the glyph is a courtesy affordance on a control that is already reachable.** Every other interactive decoration in this codebase that sits INSIDE an already-focusable control (the grid's own `ValueText` reveal button, `DateCell`'s calendar button) either isolates its own Enter/Space from the grid's roving-focus handler or gets its own `tabIndex`; a NEW tab stop on every overflowing input, multiplied across an entire form or grid page, is a worse cost than the click-only affordance it replaces. F2 is the standard "expand/edit-more" key spreadsheet-shaped UIs already use for exactly this action, so the glyph's button carries `tabIndex={-1}` and the keyboard path is wired directly on the `<input>`'s own `onKeyDown` instead. The one hard rule that follows from sharing a single `onKeyDown` prop with the caller: the CALLER's own handler always runs first and wins on `preventDefault` — a grid cell's Enter/Tab/Escape navigation is the reason `RevealableInput` exists at all, so it can never be shadowed by the very feature layered on top of it. F2 is checked only after confirming the caller did not already veto the keystroke, and only while the value actually overflows (an F2 on a fitting input is not a shortcut to anything).
