// spec 1.5/1.6/1.9: output_id required (no compat branch), filter validated
// by the BE floor in lockstep with the FE strict parser (parse-options-source.ts).
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const { invalidOptionsSourceShape } = require('../../src/shared/options-source-validate');

describe('invalidOptionsSourceShape — output_id + filter', () => {
  it('accepts a connector source with output_id', () => {
    assert.equal(invalidOptionsSourceShape({ type: 'connector', connector_id: 'c', output_id: 'o', input_bindings: {} }), false);
  });
  it('rejects a connector source with no output_id', () => {
    assert.equal(invalidOptionsSourceShape({ type: 'connector', connector_id: 'c', input_bindings: {} }), true);
  });
  it('rejects a connector source with an empty output_id', () => {
    assert.equal(invalidOptionsSourceShape({ type: 'connector', connector_id: 'c', output_id: '', input_bindings: {} }), true);
  });
  it('accepts a valid filter', () => {
    assert.equal(invalidOptionsSourceShape({ type: 'field', source_field_key: 'f', filter: { groups: [{ join: 'and', conditions: [{ target: 'label', op: 'like', pattern: 'x%' }] }] } }), false);
  });
  it('rejects a filter with a bad operator', () => {
    assert.equal(invalidOptionsSourceShape({ type: 'field', source_field_key: 'f', filter: { groups: [{ join: 'and', conditions: [{ target: 'label', op: 'regex', pattern: 'x' }] }] } }), true);
  });
  it('accepts an empty groups array (spec 1.8)', () => {
    assert.equal(invalidOptionsSourceShape({ type: 'field', source_field_key: 'f', filter: { groups: [] } }), false);
  });
  it('accepts an empty-string pattern (spec 1.7)', () => {
    assert.equal(invalidOptionsSourceShape({ type: 'field', source_field_key: 'f', filter: { groups: [{ join: 'or', conditions: [{ target: 'value', op: 'equals', pattern: '' }] }] } }), false);
  });
  it('rejects an invalid join', () => {
    assert.equal(invalidOptionsSourceShape({ type: 'field', source_field_key: 'f', filter: { groups: [{ join: 'xor', conditions: [] }] } }), true);
  });
  it('rejects a filter that is not an object', () => {
    assert.equal(invalidOptionsSourceShape({ type: 'field', source_field_key: 'f', filter: 'nope' }), true);
  });
  it('rejects a filter with an unknown group key', () => {
    assert.equal(invalidOptionsSourceShape({ type: 'field', source_field_key: 'f', filter: { groups: [{ join: 'and', conditions: [], evil: 1 }] } }), true);
  });
  it('rejects a filter condition missing a required key', () => {
    assert.equal(invalidOptionsSourceShape({ type: 'field', source_field_key: 'f', filter: { groups: [{ join: 'and', conditions: [{ target: 'label', op: 'like' }] }] } }), true);
  });
});

// spec D-8/D-12: order_by shape, in lockstep with the FE strict parser
// (parse-options-source.ts's parseOptionsOrderBy, spec 1.9).
describe('invalidOptionsSourceShape — order_by shape', () => {
  it('accepts a valid order_by (label asc)', () => {
    assert.equal(invalidOptionsSourceShape({ type: 'field', source_field_key: 'f', order_by: { target: 'label', direction: 'asc' } }), false);
  });
  it('accepts a valid order_by on a connector source', () => {
    assert.equal(invalidOptionsSourceShape({ type: 'connector', connector_id: 'c', output_id: 'o', input_bindings: {}, order_by: { target: 'value', direction: 'desc' } }), false);
  });
  it('rejects order_by that is not an object', () => {
    assert.equal(invalidOptionsSourceShape({ type: 'field', source_field_key: 'f', order_by: 'label-asc' }), true);
  });
  it('rejects order_by with an unknown key', () => {
    assert.equal(invalidOptionsSourceShape({ type: 'field', source_field_key: 'f', order_by: { target: 'label', direction: 'asc', extra: 1 } }), true);
  });
  it('rejects order_by with an invalid target', () => {
    assert.equal(invalidOptionsSourceShape({ type: 'field', source_field_key: 'f', order_by: { target: 'id', direction: 'asc' } }), true);
  });
  it('rejects order_by with an invalid direction', () => {
    assert.equal(invalidOptionsSourceShape({ type: 'field', source_field_key: 'f', order_by: { target: 'label', direction: 'ascending' } }), true);
  });
});

// fmb-2142: an input_bindings value is now EITHER a non-empty legacy string
// OR an explicit { field_key, column? } ref object — the BE structural floor
// mirrors the FE strict parser's own acceptance/rejection for the same shape.
describe('invalidOptionsSourceShape — input_bindings explicit { field_key, column? } shape (fmb-2142)', () => {
  it('accepts an explicit scalar ref (no column)', () => {
    assert.equal(invalidOptionsSourceShape({
      type: 'connector', connector_id: 'c', output_id: 'o', input_bindings: { region: { field_key: 'region' } },
    }), false);
  });
  it('accepts an explicit table-field ref with column', () => {
    assert.equal(invalidOptionsSourceShape({
      type: 'connector', connector_id: 'c', output_id: 'o',
      input_bindings: { plant: { field_key: 'rows_table', column: 'plant' } },
    }), false);
  });
  it('accepts a legacy bare string alongside an explicit ref on the same source', () => {
    assert.equal(invalidOptionsSourceShape({
      type: 'connector', connector_id: 'c', output_id: 'o',
      input_bindings: { legacy: 'material', explicit: { field_key: 'rows_table', column: 'plant' } },
    }), false);
  });
  it('rejects a ref with an empty field_key', () => {
    assert.equal(invalidOptionsSourceShape({
      type: 'connector', connector_id: 'c', output_id: 'o', input_bindings: { region: { field_key: '' } },
    }), true);
  });
  it('rejects a ref with an empty string column', () => {
    assert.equal(invalidOptionsSourceShape({
      type: 'connector', connector_id: 'c', output_id: 'o',
      input_bindings: { region: { field_key: 'rows_table', column: '' } },
    }), true);
  });
  it('rejects a ref with an unknown key', () => {
    assert.equal(invalidOptionsSourceShape({
      type: 'connector', connector_id: 'c', output_id: 'o',
      input_bindings: { region: { field_key: 'region', evil: true } },
    }), true);
  });
  it('rejects a ref that is an array', () => {
    assert.equal(invalidOptionsSourceShape({
      type: 'connector', connector_id: 'c', output_id: 'o', input_bindings: { region: ['region'] },
    }), true);
  });
  it('rejects a ref that is null', () => {
    assert.equal(invalidOptionsSourceShape({
      type: 'connector', connector_id: 'c', output_id: 'o', input_bindings: { region: null },
    }), true);
  });
});
