/**
 * flow-step-select.test.js — full runs_on × mode table for
 * `docker-api/src/shared/lib/flow-step-select.js` (fmb-2090 PR-C1). The
 * FE/BE agreement itself is covered by the twin
 * `src/fmb/lib/flow/__tests__/step-select.parity.test.ts`; this file pins
 * the BE module's own truth table in isolation.
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { selectStepsForMode, stepRunsInMode } = require('../../src/shared/lib/flow-step-select');

describe('stepRunsInMode — the full runs_on x mode table', () => {
  it('both -> runs in create, update; excluded from compare', () => {
    assert.equal(stepRunsInMode('both', 'create'), true);
    assert.equal(stepRunsInMode('both', 'update'), true);
    assert.equal(stepRunsInMode('both', 'compare'), false);
  });

  it('create -> runs only in create', () => {
    assert.equal(stepRunsInMode('create', 'create'), true);
    assert.equal(stepRunsInMode('create', 'update'), false);
    assert.equal(stepRunsInMode('create', 'compare'), false);
  });

  it('update -> runs only in update', () => {
    assert.equal(stepRunsInMode('update', 'create'), false);
    assert.equal(stepRunsInMode('update', 'update'), true);
    assert.equal(stepRunsInMode('update', 'compare'), false);
  });

  it('compare -> runs only in compare (excluded from create/update, read-only pass policy)', () => {
    assert.equal(stepRunsInMode('compare', 'create'), false);
    assert.equal(stepRunsInMode('compare', 'update'), false);
    assert.equal(stepRunsInMode('compare', 'compare'), true);
  });

  it('null/undefined defaults to both (grandfathered steps)', () => {
    assert.equal(stepRunsInMode(null, 'create'), true);
    assert.equal(stepRunsInMode(undefined, 'update'), true);
    assert.equal(stepRunsInMode(null, 'compare'), false);
  });
});

describe('selectStepsForMode — filters a step array identically to the per-cell table', () => {
  const steps = [
    { id: 'a', runs_on: 'create' },
    { id: 'b', runs_on: 'update' },
    { id: 'c', runs_on: 'both' },
    { id: 'd', runs_on: 'compare' },
    { id: 'e', runs_on: null },
  ];

  it('create mode selects a, c, e', () => {
    assert.deepEqual(selectStepsForMode(steps, 'create').map((s) => s.id), ['a', 'c', 'e']);
  });

  it('update mode selects b, c, e', () => {
    assert.deepEqual(selectStepsForMode(steps, 'update').map((s) => s.id), ['b', 'c', 'e']);
  });

  it('compare mode selects only d', () => {
    assert.deepEqual(selectStepsForMode(steps, 'compare').map((s) => s.id), ['d']);
  });

  it('a non-array input yields an empty array rather than throwing', () => {
    assert.deepEqual(selectStepsForMode(undefined, 'create'), []);
  });
});

// S1/C1 (fmb-2199 RD-5 review batch 1): F2's demo-get/demo-merge/demo-update
// are step_runs_on='update' — a create-mode run of this recipe (a never-run
// template derives pushMode='create') must select none of them, or the GET
// step dispatches with an undefined external_id. Asserted against the real
// fixture file (not a hand-copied shape) so a future edit to it is caught
// here, not only at e2e runtime.
describe('selectStepsForMode against the real demo-windfarm fixture (e2e/fixtures/demo-windfarm/flows.export.json, F2)', () => {
  const fixturePath = path.join(__dirname, '..', '..', '..', 'e2e', 'fixtures', 'demo-windfarm', 'flows.export.json');
  const f2 = JSON.parse(fs.readFileSync(fixturePath, 'utf8')).f2;
  // The module's own contract: a caller aliases its fetched column into a
  // `runs_on` property before calling selectStepsForMode.
  const steps = f2.steps.map((s) => ({ id: s.name, runs_on: s.step_runs_on }));

  it('create mode selects no api step (the create-mode leak this fix closes)', () => {
    assert.deepEqual(selectStepsForMode(steps, 'create'), []);
  });

  it('update mode selects demo-get, demo-merge, demo-update, in fixture order', () => {
    assert.deepEqual(selectStepsForMode(steps, 'update').map((s) => s.id), ['demo-get', 'demo-merge', 'demo-update']);
  });

  it('compare mode selects only demo-compare-get', () => {
    assert.deepEqual(selectStepsForMode(steps, 'compare').map((s) => s.id), ['demo-compare-get']);
  });
});
