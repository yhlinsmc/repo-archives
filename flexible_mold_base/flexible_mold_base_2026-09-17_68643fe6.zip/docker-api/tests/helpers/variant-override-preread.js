'use strict';

/**
 * The variant_overrides PUT pre-read's exact SELECT column list — the ONE
 * home for this fixture, imported by every PUT-mock test instead of each
 * carrying its own copy of the matcher regex.
 *
 * `action.*FROM` (the shape every one of these fixtures had before) matches
 * an EMPTY gap: a real SELECT that silently dropped `override_value` — the
 * exact column the write boundary's "judge on the POST-STATE value"
 * precedence depends on — would still satisfy that pattern, so the fixture
 * would keep returning its mocked row and every one of these tests would
 * stay green through the regression. Pinning the literal column list
 * closes that gap.
 *
 * `cell_targets` is the one ADDITIVE, optionally-absent column (the
 * operator-mode gate in routes-variant-overrides.js) — it rides after this
 * fixed prefix, never inside it.
 */
const PUT_PREREAD_COLUMNS = ['id', 'variant_id', 'field_id', 'action', 'override_value'];

/** The query matcher every PUT-pre-read fixture uses in place of its own
 *  loose regex — same idiom (fixed prefix, optional `, cell_targets`
 *  suffix) at all 11 call sites, so there is exactly one place that decides
 *  what "the pre-read query" looks like. */
const PUT_PREREAD_QUERY = new RegExp(
  `^SELECT ${PUT_PREREAD_COLUMNS.join(', ')}(?:, cell_targets)? FROM \`fmb_variant_overrides\` WHERE id = \\?`,
  'i',
);

module.exports = { PUT_PREREAD_COLUMNS, PUT_PREREAD_QUERY };
