/**
 * nonowner-write-scoping.test.js — item 11 (B1): the write-side guard behind the
 * read-only screen.
 *
 * WHY this file exists: the read-only editing screen is a UI affordance, and a UI
 * affordance is not an authorisation control. Before that screen ships, the
 * server-side refusal it implies has to be proven for every surface it covers —
 * flow recipes, recipe steps, and API connectors (including the NULL-owner
 * connector, whose guard lives outside the CRUD factory).
 *
 * WHY the fake DB evaluates predicates instead of matching SQL text: the
 * established idiom (tests/unit/schema-factory-parent-ownership.test.js) asserts
 * the owner clause appears in the emitted SQL. That passes on the string being
 * present and says nothing about whether the clause is bound to the *caller's*
 * id. Here the fake connection applies whatever predicates the factory actually
 * emitted to an in-memory row and matches the row when there are none — so
 * deleting the owner scoping makes the write succeed, the route answer 200, and
 * these tests fail on behaviour. Any predicate shape the evaluator does not
 * recognise throws, so a future SQL change cannot slip through unasserted.
 *
 * WHY some cases assert 404 and not 403: for a row owned by someone else the CRUD
 * factory answers 404 on purpose (crud-factory.js:1215-1218) so the response
 * cannot be used to probe whether that id exists. 403 is reserved for the cases
 * where existence is already known to the caller — the NULL-owner connector
 * pre-guard (api-connectors/index.js:152-176) and the step read-scope gate. Each
 * case pins its own status so a drift in either direction is caught, and every
 * case additionally asserts the stored row is untouched.
 */
const { test, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../../../src/edge/db');

// ── the world under test ────────────────────────────────────────────────────
const OWNER = 'u-owner';
const INTRUDER = 'u-intruder';

let tables;
function resetWorld() {
  tables = {
    fmb_hierarchy_nodes: [
      { id: 'bp-1', owner_id: OWNER },
      // A shared blueprint: any editor may author against it. It exists here so
      // the row's OWN owner scoping is tested in isolation — on a blueprint only
      // the owner owns, the parent-ownership predicate would refuse the intruder
      // even with the row-level owner scoping deleted, and the fixture would be
      // proving the wrong guard.
      { id: 'bp-shared', owner_id: null },
    ],
    fmb_flow_recipes: [
      // rec-1 carries a step (used by the step cases); rec-2 has none, so the
      // recipe DELETE pre-guard (409 RECIPE_HAS_STEPS) does not mask the result.
      { id: 'rec-1', owner_id: OWNER, blueprint_id: 'bp-1', name: 'rec-1-original', status: 'approved' },
      { id: 'rec-2', owner_id: OWNER, blueprint_id: 'bp-1', name: 'rec-2-original', status: 'approved' },
      { id: 'rec-shared-bp', owner_id: OWNER, blueprint_id: 'bp-shared', name: 'rec-shared-bp-original', status: 'approved' },
    ],
    fmb_flow_recipe_steps: [{ id: 'stp-1', recipe_id: 'rec-1', sequence: 1, name: 'stp-1-original' }],
    // Present so the recipe DELETE's best-effort history cleanup has a table.
    fmb_flow_recipe_code_versions: [],
    fmb_api_connectors: [
      { id: 'con-owned', owner_id: OWNER, blueprint_id: 'bp-1', name: 'con-owned-original', status: 'approved' },
      // A degraded/seeded row with no owner: the generic owner predicate would
      // treat it as shared, so a dedicated pre-guard must make it admin-only.
      { id: 'con-null', owner_id: null, blueprint_id: 'bp-1', name: 'con-null-original', status: 'approved' },
      { id: 'con-shared-bp', owner_id: OWNER, blueprint_id: 'bp-shared', name: 'con-shared-bp-original', status: 'approved' },
    ],
  };
}
resetWorld();

const rowsOf = (name) => tables[name] || [];
const findRow = (name, id) => rowsOf(name).find((r) => r.id === id) || null;

// ── fail-loud WHERE evaluator ───────────────────────────────────────────────
const countPlaceholders = (s) => (s.match(/\?/g) || []).length;

/**
 * Execute an UPDATE/DELETE — or evaluate the delete's entitlement read — emitted
 * by the CRUD factory against the in-memory tables. Understands exactly the
 * predicate forms the factory emits; anything else throws rather than being
 * silently ignored.
 *
 * THE READ AND THE STATEMENT GO THROUGH ONE EVALUATOR, because the production
 * invariant is that they carry the identical predicate: the delete establishes
 * entitlement with a non-locking `SELECT id … <scope>` before it takes any lock,
 * and then deletes with the same scope. A double that answered the read from a
 * separate arm could let the two disagree — which is the one thing this shape
 * must not be able to do.
 */
function execWrite(sql, params) {
  const head0 = sql.match(/^(UPDATE|DELETE FROM|SELECT id FROM) `([^`]+)`/);
  if (!head0) throw new Error(`execWrite: not a write statement: ${sql}`);
  const isUpdate = head0[1] === 'UPDATE';
  const isSelect = head0[1] === 'SELECT id FROM';
  const tableName = head0[2];
  const rows = tables[tableName];
  if (!rows) throw new Error(`execWrite: unknown table ${tableName}`);

  const wIdx = sql.indexOf(' WHERE ');
  if (wIdx < 0) throw new Error(`execWrite: refusing an unscoped write: ${sql}`);
  const head = sql.slice(0, wIdx);
  let rest = sql.slice(wIdx + ' WHERE '.length).trim();

  // SET assignments come first in the parameter list.
  const assignments = [];
  if (isUpdate) {
    const setPart = head.slice(head.indexOf(' SET ') + ' SET '.length);
    let i = 0;
    for (const m of setPart.matchAll(/`([^`]+)` = \?/g)) assignments.push([m[1], params[i++]]);
  }

  let cursor = countPlaceholders(head);
  const nextParam = () => params[cursor++];
  const predicates = [];

  // The leading predicate is either `id = ?` (the row itself) or a quoted FK
  // column (the code-version history cleanup deletes by recipe_id).
  const leadMatch = rest.match(/^(?:id|`([^`]+)`) = \?/);
  if (!leadMatch) throw new Error(`execWrite: unsupported leading predicate: ${rest}`);
  const leadCol = leadMatch[1] || 'id';
  rest = rest.slice(leadMatch[0].length).trim();
  const leadVal = nextParam();
  predicates.push((row) => row[leadCol] === leadVal);

  while (rest.length) {
    let m = rest.match(/^AND \(`([^`]+)` IS NULL OR `\1` = \?\)/);
    if (m) {
      const col = m[1];
      const val = nextParam();
      predicates.push((row) => row[col] == null || row[col] === val);
      rest = rest.slice(m[0].length).trim();
      continue;
    }
    m = rest.match(/^AND `([^`]+)` = \?/);
    if (m) {
      const col = m[1];
      const val = nextParam();
      predicates.push((row) => row[col] === val);
      rest = rest.slice(m[0].length).trim();
      continue;
    }
    if (rest.startsWith('AND EXISTS (')) {
      const open = rest.indexOf('(');
      let depth = 0;
      let end = -1;
      for (let i = open; i < rest.length; i += 1) {
        if (rest[i] === '(') depth += 1;
        else if (rest[i] === ')') { depth -= 1; if (depth === 0) { end = i; break; } }
      }
      if (end < 0) throw new Error(`execWrite: unbalanced EXISTS in: ${rest}`);
      const inner = rest.slice(open + 1, end);
      const em = inner.match(
        /^SELECT 1 FROM `([^`]+)` j0 WHERE j0\.`([^`]+)` = `([^`]+)`\.`([^`]+)` AND \(j0\.`([^`]+)` IS NULL OR j0\.`\5` = \?\)$/,
      );
      if (!em) throw new Error(`execWrite: unsupported EXISTS shape: ${inner}`);
      const [, parentTable, parentMatchCol, childTable, childViaCol, parentOwnerCol] = em;
      if (childTable !== tableName) throw new Error(`execWrite: EXISTS names ${childTable}, statement targets ${tableName}`);
      const ownerVal = nextParam();
      predicates.push((row) => {
        const parent = rowsOf(parentTable).find((p) => p[parentMatchCol] === row[childViaCol]);
        if (!parent) return false; // broken chain denies, as EXISTS does
        return parent[parentOwnerCol] == null || parent[parentOwnerCol] === ownerVal;
      });
      rest = rest.slice(end + 1).trim();
      continue;
    }
    throw new Error(`execWrite: unsupported predicate: ${rest}`);
  }

  if (cursor !== params.length) {
    throw new Error(`execWrite: ${params.length - cursor} parameter(s) left unconsumed for: ${sql}`);
  }

  const matched = rows.filter((row) => predicates.every((p) => p(row)));
  if (isSelect) return matched.map((row) => ({ id: row.id }));
  if (isUpdate) {
    for (const row of matched) for (const [col, val] of assignments) row[col] = val;
  } else {
    for (const row of matched) rows.splice(rows.indexOf(row), 1);
  }
  return { affectedRows: matched.length };
}

// ── the engine's own answer to "are these the same stored value" ────────────
/**
 * `sameStoredValue` (write-value.js) asks the DATABASE whether two spellings are
 * one stored value, in three statements: which schema this connection is on, the
 * column's declared charset/collation, and the comparison itself.
 *
 * MODELLED AS THE COLUMN ANSWERS IT, NOT AS JAVASCRIPT WOULD. Every owner column
 * here is `CHAR(36)` under `utf8mb4_general_ci`, which folds case — and that fold
 * IS the behaviour the helper was introduced for. A double that answered with
 * `===` would quietly re-import the defect into every test that leans on it, and
 * the tests would agree with each other while disagreeing with the engine.
 *
 * Returns `null` for a statement this is not about, so the caller falls through
 * to its own script and an unmodelled query still throws.
 */
function answerEngineIdentity(sql, params) {
  if (/^SELECT DATABASE\(\)/.test(sql)) return [{ db: 'testdb' }];
  // Both the collation probe and the column-set probe read
  // information_schema.COLUMNS; they are told apart by what they project.
  if (/CHARACTER_SET_NAME/.test(sql)) return [{ cs: 'utf8mb4', co: 'utf8mb4_general_ci' }];
  if (/<=>/.test(sql) && / AS same$/.test(sql)) {
    const [a, b] = params;
    const fold = (v) => (typeof v === 'string' ? v.toLowerCase() : v);
    return [{ same: fold(a) === fold(b) ? 1 : 0 }];
  }
  return null;
}

// ── fake connection / pool ──────────────────────────────────────────────────
let lastConn = null;
function makeConn() {
  const queries = [];
  const conn = {
    queries,
    async query(sql, params = []) {
      queries.push({ sql, params });
      const engine = answerEngineIdentity(sql, params);
      if (engine) return engine;
      // Empty column set → the factory applies no column gating.
      if (/information_schema\.COLUMNS/.test(sql)) return [];
      if (/^(UPDATE|DELETE FROM) `/.test(sql)) return execWrite(sql, params);
      let m = sql.match(/^SELECT `([^`]+)` AS via FROM `([^`]+)` WHERE id = \? FOR UPDATE/);
      if (m) {
        const row = findRow(m[2], params[0]);
        return row ? [{ via: row[m[1]] }] : [];
      }
      // parentRepend existence probe: `id` and nothing else. Separate from the
      // owner-gate below because the columns that gate reads are ADDITIVE — an
      // install without them must still have "is the parent there" answered.
      m = sql.match(/^SELECT id FROM `([^`]+)` WHERE id = \? FOR UPDATE$/);
      if (m) {
        const row = findRow(m[1], params[0]);
        return row ? [{ id: row.id }] : [];
      }
      // The delete's entitlement read — the same predicate the DELETE carries,
      // evaluated by the same evaluator so the two cannot disagree.
      if (/^SELECT id FROM `[^`]+` WHERE id = \?/.test(sql)) return execWrite(sql, params);
      // parentRepend owner-gate: reads the parent row's status + owner.
      m = sql.match(/^SELECT `status` AS status, `owner_id` AS owner_id FROM `([^`]+)` WHERE id = \? FOR UPDATE/);
      if (m) {
        const row = findRow(m[1], params[0]);
        return row ? [{ status: row.status, owner_id: row.owner_id }] : [];
      }
      m = sql.match(/^SELECT \* FROM `([^`]+)` WHERE id = \?/);
      if (m) {
        const row = findRow(m[1], params[0]);
        return row ? [{ ...row }] : [];
      }
      // The delete's reference gate: `SELECT 1 FROM <child> WHERE <fk> = ?
      // LIMIT 1 FOR UPDATE`, run on the write connection inside the delete's own
      // transaction (it used to be an unlocked read on pool.ro).
      m = sql.match(/^SELECT 1 FROM `([^`]+)` WHERE `([^`]+)` = \? LIMIT 1 FOR UPDATE/);
      if (m) {
        return rowsOf(m[1]).filter((r) => r[m[2]] === params[0]).slice(0, 1).map(() => ({ 1: 1 }));
      }
      // The self re-pend probe, likewise on the write connection.
      m = sql.match(/^SELECT `status`(?:, `[^`]+`)* FROM `([^`]+)` WHERE id = \? FOR UPDATE/);
      if (m) {
        const row = findRow(m[1], params[0]);
        return row ? [{ ...row }] : [];
      }
      // D9 (fmb-2148): the PUT handler's pre-UPDATE `skipWhenUnchanged`
      // comparison — SELECTs exactly the columns the incoming body is about
      // to SET, FOR UPDATE. Matched last among the FOR-UPDATE arms (every
      // more specific column list above still wins first).
      m = sql.match(/^SELECT .+ FROM `([^`]+)` WHERE id = \? FOR UPDATE$/);
      if (m) {
        const row = findRow(m[1], params[0]);
        return row ? [{ ...row }] : [];
      }
      if (/FROM `fmb_users`/.test(sql)) return [];
      // The connector-bindings enrichment read the CRUD factory now runs on the
      // write RESPONSE too (attachConnectorBindings), so a rename reply carries
      // `bindings` like a GET. No bindings in these fixtures → empty.
      if (/SELECT connector_id, blueprint_id FROM `fmb_api_connector_blueprints`\s+WHERE connector_id IN/.test(sql)) return [];
      throw new Error(`Unscripted rw query: ${sql}`);
    },
    release() {},
    async beginTransaction() {},
    async commit() {},
    async rollback() {},
  };
  lastConn = conn;
  return conn;
}

// pool.ro.query is used directly by the route-level pre-guards.
async function roQuery(sql, params = []) {
  const engine = answerEngineIdentity(sql, params);
  if (engine) return engine;
  let m = sql.match(/^SELECT 1 FROM `fmb_flow_recipe_steps` WHERE recipe_id = \? LIMIT 1/);
  if (m) return rowsOf('fmb_flow_recipe_steps').filter((r) => r.recipe_id === params[0]).slice(0, 1).map(() => ({ 1: 1 }));
  m = sql.match(/^SELECT status, payload_transform_code[\s\S]*FROM `fmb_flow_recipes` WHERE id = \?/);
  if (m) {
    const row = findRow('fmb_flow_recipes', params[0]);
    return row ? [{
      status: row.status, payload_transform_code: null, content_type: null, runs_on: null,
      consumed_output_keys: null, link_extract: null, external_id_extract: null,
    }] : [];
  }
  m = sql.match(/^SELECT recipe_id FROM `fmb_flow_recipe_steps` WHERE id = \?/);
  if (m) {
    const row = findRow('fmb_flow_recipe_steps', params[0]);
    return row ? [{ recipe_id: row.recipe_id }] : [];
  }
  m = sql.match(/^SELECT owner_id FROM `fmb_flow_recipes` WHERE id = \?/);
  if (m) {
    const row = findRow('fmb_flow_recipes', params[0]);
    return row ? [{ owner_id: row.owner_id }] : [];
  }
  m = sql.match(/^SELECT owner_id FROM `fmb_api_connectors` WHERE id = \?/);
  if (m) {
    const row = findRow('fmb_api_connectors', params[0]);
    return row ? [{ owner_id: row.owner_id }] : [];
  }
  m = sql.match(/^SELECT status, url, method, auth_type, dispatch_origin FROM `fmb_api_connectors` WHERE id = \?/);
  if (m) {
    const row = findRow('fmb_api_connectors', params[0]);
    return row ? [{ status: row.status, url: null, method: null, auth_type: null, dispatch_origin: null }] : [];
  }
  throw new Error(`Unscripted ro query: ${sql}`);
}

const poolSpy = {
  rw: { async getConnection() { return makeConn(); }, query: roQuery },
  ro: { async getConnection() { return makeConn(); }, query: roQuery },
};

require.cache[dbKey] = {
  id: dbKey,
  filename: dbKey,
  loaded: true,
  exports: {
    pool: poolSpy,
    t: (name) => `fmb_${name}`,
    getDynamicPool: async () => poolSpy,
  },
};

const recipesRouter = require('../../../../src/edge/routes/app/flow-recipes');
const stepsRouter = require('../../../../src/edge/routes/app/flow-recipe-steps');
const connectorsRouter = require('../../../../src/edge/routes/app/api-connectors');

// ── request helper ──────────────────────────────────────────────────────────
async function call(router, user, method, path, body) {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { req.user = user; next(); });
  app.use('/', router);
  const server = await new Promise((resolve) => {
    const s = app.listen(0, '127.0.0.1', () => resolve(s));
  });
  const port = server.address().port;
  try {
    return await new Promise((resolve, reject) => {
      const data = body !== undefined ? JSON.stringify(body) : '';
      const headers = data
        ? { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(data) }
        : {};
      const req = http.request({ method, host: '127.0.0.1', port, path, headers }, (res) => {
        let raw = '';
        res.on('data', (c) => { raw += c; });
        res.on('end', () => resolve({ status: res.statusCode, body: raw ? JSON.parse(raw) : null }));
      });
      req.on('error', reject);
      if (data) req.write(data);
      req.end();
    });
  } finally {
    await new Promise((resolve) => server.close(resolve));
  }
}

const editor = (id) => ({ id, role: 'editor', email: `${id}@example.test` });

beforeEach(() => { resetWorld(); lastConn = null; });

// ── positive controls ───────────────────────────────────────────────────────
// WHY: without these, a fake DB that never matches anything would make every
// refusal test pass for the wrong reason.

test('control — the owner CAN rename their own flow recipe', async () => {
  const res = await call(recipesRouter, editor(OWNER), 'PUT', '/rec-2', { name: 'renamed-by-owner' });
  assert.equal(res.status, 200);
  assert.equal(findRow('fmb_flow_recipes', 'rec-2').name, 'renamed-by-owner');
});

test('control — the owner CAN delete their own flow recipe', async () => {
  const res = await call(recipesRouter, editor(OWNER), 'DELETE', '/rec-2');
  assert.equal(res.status, 200);
  assert.equal(findRow('fmb_flow_recipes', 'rec-2'), null);
});

test('control — the owner CAN rename a step of their own recipe', async () => {
  const res = await call(stepsRouter, editor(OWNER), 'PUT', '/stp-1', { name: 'renamed-by-owner' });
  assert.equal(res.status, 200);
  assert.equal(findRow('fmb_flow_recipe_steps', 'stp-1').name, 'renamed-by-owner');
});

test('control — the owner CAN rename their own API connector', async () => {
  const res = await call(connectorsRouter, editor(OWNER), 'PUT', '/con-owned', { name: 'renamed-by-owner' });
  assert.equal(res.status, 200);
  assert.equal(findRow('fmb_api_connectors', 'con-owned').name, 'renamed-by-owner');
});

// ── flow recipes ────────────────────────────────────────────────────────────

test("non-owner editor PUT of another owner's flow recipe is refused and changes nothing", async () => {
  const res = await call(recipesRouter, editor(INTRUDER), 'PUT', '/rec-2', { name: 'hijacked' });
  assert.equal(res.status, 404); // existence-leak parity, see file header
  assert.equal(findRow('fmb_flow_recipes', 'rec-2').name, 'rec-2-original');
});

test("non-owner editor DELETE of another owner's flow recipe is refused and the row survives", async () => {
  const res = await call(recipesRouter, editor(INTRUDER), 'DELETE', '/rec-2');
  assert.equal(res.status, 404);
  assert.notEqual(findRow('fmb_flow_recipes', 'rec-2'), null);
});

// WHY these two matter more than the pair above: on a blueprint only the owner
// owns, the parent-ownership predicate already refuses the intruder, so those
// tests would still pass with the row-level owner scoping deleted. On a SHARED
// blueprint — two editors authoring side by side, the realistic case — the row's
// own owner column is the only thing standing between them.
test("non-owner editor PUT of another owner's recipe on a SHARED blueprint is refused", async () => {
  const res = await call(recipesRouter, editor(INTRUDER), 'PUT', '/rec-shared-bp', { name: 'hijacked' });
  assert.equal(res.status, 404);
  assert.equal(findRow('fmb_flow_recipes', 'rec-shared-bp').name, 'rec-shared-bp-original');
});

test("non-owner editor DELETE of another owner's recipe on a SHARED blueprint is refused", async () => {
  const res = await call(recipesRouter, editor(INTRUDER), 'DELETE', '/rec-shared-bp');
  assert.equal(res.status, 404);
  assert.notEqual(findRow('fmb_flow_recipes', 'rec-shared-bp'), null);
});

test("non-owner editor PUT of another owner's connector on a SHARED blueprint is refused", async () => {
  const res = await call(connectorsRouter, editor(INTRUDER), 'PUT', '/con-shared-bp', { name: 'hijacked' });
  assert.equal(res.status, 404);
  assert.equal(findRow('fmb_api_connectors', 'con-shared-bp').name, 'con-shared-bp-original');
});

test("non-owner editor DELETE of another owner's connector on a SHARED blueprint is refused", async () => {
  const res = await call(connectorsRouter, editor(INTRUDER), 'DELETE', '/con-shared-bp');
  assert.equal(res.status, 404);
  assert.notEqual(findRow('fmb_api_connectors', 'con-shared-bp'), null);
});

test('the flow-recipe write binds the owner predicate to the CALLER, not to a constant', async () => {
  // TWO STATEMENTS CARRY THIS PREDICATE, and which one a caller reaches is the
  // point of the pair. The intruder is now refused by the entitlement read the
  // handler takes before anything locks, so their request never reaches the
  // UPDATE — asserting on the UPDATE alone would be asserting on a statement
  // that is not issued, which is how a case stops seeing what it was written to
  // see.
  //
  // THE DISCRIMINATING HALF IS THE FIRST ONE: there the caller is not the row's
  // owner, so a predicate bound to a constant — the row's owner, or anybody's
  // id but the caller's — fails it. The owner's half cannot make that
  // distinction (the two ids are the same request), and is here to hold the
  // clause on the statement a caller who gets that far actually runs.
  await call(recipesRouter, editor(INTRUDER), 'PUT', '/rec-2', { name: 'hijacked' });
  const refusedAt = lastConn.queries.find((q) => /^SELECT id FROM `fmb_flow_recipes`/.test(q.sql));
  assert.ok(refusedAt, 'no scoped read was issued for the refused caller');
  assert.equal(
    lastConn.queries.some((q) => /^UPDATE `fmb_flow_recipes`/.test(q.sql)), false,
    'the refused caller still reached the UPDATE',
  );
  assert.match(refusedAt.sql, /AND \(`owner_id` IS NULL OR `owner_id` = \?\)/);
  assert.ok(refusedAt.params.includes(INTRUDER), 'the caller id is not bound into the scope predicate');
  assert.equal(refusedAt.params.includes(OWNER), false, 'the row owner id must never be bound by the caller');

  await call(recipesRouter, editor(OWNER), 'PUT', '/rec-2', { name: 'renamed-by-owner' });
  const update = lastConn.queries.find((q) => /^UPDATE `fmb_flow_recipes`/.test(q.sql));
  assert.ok(update, 'no UPDATE was issued for the owner');
  assert.match(update.sql, /AND \(`owner_id` IS NULL OR `owner_id` = \?\)/);
  assert.ok(update.params.includes(OWNER), 'the caller id is not bound into the scope predicate');
  assert.equal(
    update.params.includes(INTRUDER), false,
    'a caller id from another request must never be bound by this one',
  );
});

// ── recipe steps (ownership inherited from the parent recipe) ───────────────

test("non-owner editor PUT of a step under another owner's recipe is refused and changes nothing", async () => {
  const res = await call(stepsRouter, editor(INTRUDER), 'PUT', '/stp-1', { name: 'hijacked' });
  assert.equal(res.status, 404);
  assert.equal(findRow('fmb_flow_recipe_steps', 'stp-1').name, 'stp-1-original');
});

test("non-owner editor DELETE of a step under another owner's recipe is refused and the row survives", async () => {
  const res = await call(stepsRouter, editor(INTRUDER), 'DELETE', '/stp-1');
  assert.equal(res.status, 404);
  assert.notEqual(findRow('fmb_flow_recipe_steps', 'stp-1'), null);
});

test('a step whose parent recipe is gone is not writable by any editor (broken chain denies)', async () => {
  tables.fmb_flow_recipe_steps.push({ id: 'stp-orphan', recipe_id: 'rec-gone', sequence: 1, name: 'orphan-original' });
  const res = await call(stepsRouter, editor(INTRUDER), 'PUT', '/stp-orphan', { name: 'hijacked' });
  assert.equal(res.status, 404);
  assert.equal(findRow('fmb_flow_recipe_steps', 'stp-orphan').name, 'orphan-original');
});

test("non-owner editor GET of a step under another owner's recipe is refused with 403", async () => {
  const res = await call(stepsRouter, editor(INTRUDER), 'GET', '/stp-1');
  assert.equal(res.status, 403);
});

// ── API connectors ──────────────────────────────────────────────────────────

test("non-owner editor PUT of another owner's API connector is refused and changes nothing", async () => {
  const res = await call(connectorsRouter, editor(INTRUDER), 'PUT', '/con-owned', { name: 'hijacked' });
  assert.equal(res.status, 404);
  assert.equal(findRow('fmb_api_connectors', 'con-owned').name, 'con-owned-original');
});

test("non-owner editor DELETE of another owner's API connector is refused and the row survives", async () => {
  const res = await call(connectorsRouter, editor(INTRUDER), 'DELETE', '/con-owned');
  assert.equal(res.status, 404);
  assert.notEqual(findRow('fmb_api_connectors', 'con-owned'), null);
});

test('editor PUT of a NULL-owner API connector is refused with 403 and changes nothing', async () => {
  const res = await call(connectorsRouter, editor(INTRUDER), 'PUT', '/con-null', { name: 'hijacked' });
  assert.equal(res.status, 403);
  assert.equal(res.body.error.code, 'FORBIDDEN');
  assert.equal(findRow('fmb_api_connectors', 'con-null').name, 'con-null-original');
});

test('editor DELETE of a NULL-owner API connector is refused with 403 and the row survives', async () => {
  const res = await call(connectorsRouter, editor(INTRUDER), 'DELETE', '/con-null');
  assert.equal(res.status, 403);
  assert.notEqual(findRow('fmb_api_connectors', 'con-null'), null);
});

test('a NULL-owner API connector is admin-only, not shared — no editor may write it', async () => {
  // The owner-or-NULL predicate alone would call this row shared. The pre-guard
  // is what makes it admin-only, so prove it for a second, unrelated editor too.
  const res = await call(connectorsRouter, editor(OWNER), 'PUT', '/con-null', { name: 'hijacked' });
  assert.equal(res.status, 403);
  assert.equal(findRow('fmb_api_connectors', 'con-null').name, 'con-null-original');
});
