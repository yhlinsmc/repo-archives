/**
 * capacity-wizard.test.js — the setup-wizard bulk create endpoint (R3, spec §15).
 *
 * Two layers:
 *   1. PURE buildWizardPlan — payload validation, topology instance-count
 *      re-validation (spec §10.1), structural coherence (standby-only-under-
 *      primary_standby, instances hang off db_host VMs), bounds.
 *   2. Route behaviour against a mock edge/db — happy-path materialization in one
 *      transaction, all-or-nothing (an invalid row / a §17.1a foreign catalogue
 *      reference writes nothing), permission gating, and rollback on a DB error.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const { makeStubReqLog } = require('../../../helpers/stub-req-log');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');
const { logger } = require('../../../../src/shared/lib/logger');

// ── Mock edge/db BEFORE requiring the router ──────────────────────────────────
const dbKey = require.resolve('../../../../src/edge/db');

let state;
function freshState() {
  return {
    queries: [],
    began: 0, committed: 0, rolledBack: 0, released: 0,
    // §17.1a catalogue probe (SELECT id, scenario_id FROM cap_X WHERE id = ? FOR UPDATE):
    //   catalogueFound → does the referenced catalogue row exist?
    //   catalogueScenarioId → the referenced row's scenario_id (null = global, ok).
    catalogueFound: true,
    catalogueScenarioId: null,
    // The class returned by the profile-class probe (SELECT class FROM
    // cap_vm_profiles). null → the row has no class recorded (skip); a value
    // exercises the db_host→DB / ap_host→AP coherence check.
    profileClass: null,
    // A table whose INSERT should throw (simulate a mid-transaction DB failure).
    throwOnInsertInto: null,
    // TA.1/TA.2: server-side sizing derivation + disk-combo allow-list fixtures.
    //   profiles → id: { class, mode, cpu, mem_gb, sga_cap_gb, allowed_disk_combos }
    //   combos   → id: sizes JSON list (summed to disk_gb)
    //   settingsRow → the global cap_settings formula-constants row (null = defaults)
    profiles: {},
    combos: {},
    settingsRow: null,
    // ap-vm-function (PR-2) degraded-schema probe: the physical cap_vms column set
    // the wizard's write-side tableColumnSet reads. null → the full set (column
    // PRESENT, today's behaviour). Set to a set WITHOUT function_name to model a
    // warn-skipped add-column migration (the H1 500 vector).
    vmsColumns: null,
    // F2 degraded-schema probe: the physical cap_databases column set. null →
    // the full set (standby_node_count PRESENT). Set to a set WITHOUT
    // standby_node_count to model the same warn-skipped add-column migration.
    databasesColumns: null,
    // X3/H1: does the LIVE topology ENUM already carry BOTH renamed members
    // (rac_multinode + rac_multinode_standby)? true (default) = renamed
    // (today's fully-migrated behaviour). false models the rename migration
    // step (cap_databases_topology_rac_rename) not having run yet — a
    // narrow-enum degraded schema, gating EITHER renamed member (H1,
    // round 1 review — originally standby-only).
    topologyEnumRenamed: true,
  };
}

// A representative real cap_vms physical column set — the id fail-safe key plus
// the columns the wizard INSERT binds — used when a test does not override it.
const FULL_VMS_COLUMNS = [
  'id', 'scenario_id', 'vm_type', 'hypervisor_id', 'site_id', 'cpu', 'mem_gb',
  'disk_gb', 'sizing_profile_id', 'disk_combo_id', 'team_id', 'database_id',
  'name', 'function_name', 'order_index', 'metadata',
];

// A representative real cap_databases physical column set — used when a test
// does not override it (F2).
const FULL_DATABASES_COLUMNS = [
  'id', 'scenario_id', 'function_name', 'topology', 'node_count', 'standby_node_count',
  'profile_id', 'disk_combo_id', 'team_id', 'primary_sga_gb', 'standby_sga_gb',
  'dc_refs', 'description', 'order_index', 'metadata',
];

/**
 * The JOIN `selectByRequestedId` issues, answered the way the COLUMN answers it.
 *
 * `p.id = w.want` is an engine comparison on a `CHAR(36)` column under a
 * case-folding collation, so a request naming a row by another spelling MATCHES
 * — and the row comes back carrying its OWN id beside the spelling that was
 * asked for. A double that looked its fixture up by exact key could never
 * produce that pair: `requested_id` always equalled `id`, so the input class the
 * change exists for could not occur here at all, and reverting the change left
 * this file green.
 *
 * WHAT THIS CANNOT SETTLE, said here rather than left to be discovered: the
 * wizard now rewrites every catalogue FK in the plan to the id the reference
 * check resolved BEFORE the sizing hydration runs, so by this point the
 * requested spelling and the stored one are the same value and no assertion in
 * this file can separate them. That the derivation survives a respelled profile
 * id is settled on a real database
 * (`tests/integration/capacity-write-identity-real-db.test.js`). What this
 * double is for is keeping the SHAPE honest — the statement really does return
 * both columns, and a fixture resolved by exact key would quietly stop
 * modelling the engine's own comparison.
 *
 * @param {object} fixture rows keyed by their STORED id
 * @param {string[]} asked the spellings the statement bound
 * @param {(value: *) => object} project fixture value → the projected columns
 */
function joinByRequestedId(fixture, asked, project) {
  const byFolded = new Map(Object.keys(fixture).map((k) => [k.toLowerCase(), k]));
  const out = [];
  for (const want of asked) {
    const storedId = byFolded.get(String(want).toLowerCase());
    if (storedId === undefined) continue; // no such row — the JOIN drops it
    out.push({ requested_id: want, id: storedId, ...project(fixture[storedId]) });
  }
  return out;
}

const conn = {
  async beginTransaction() { state.began += 1; },
  async commit() { state.committed += 1; },
  async rollback() { state.rolledBack += 1; },
  release() { state.released += 1; },
  async query(sql, params = []) {
    state.queries.push({ sql, params });

    // X3/H1: the topology ENUM-rename probe (`_topologyEnumHasMember`) —
    // disambiguated from the tableColumnSet probe below by its OWN SELECT
    // clause (`COLUMN_TYPE`, not `COLUMN_NAME`); both query the same
    // information_schema.COLUMNS table so the branch order matters.
    if (/information_schema\.COLUMNS/i.test(sql) && /COLUMN_TYPE/i.test(sql)) {
      return state.topologyEnumRenamed
        ? [{ type: "enum('single','primary','primary_standby','rac_multinode','rac_multinode_standby')" }]
        : [{ type: "enum('single','primary','primary_standby','rac_multinode')" }];
    }
    // Write-side degraded-schema probe (tableColumnSet): cap_vms
    // (ap-vm-function PR-2) and cap_databases (F2), disambiguated by the
    // physical table name `tableColumnSet` binds as its one parameter.
    if (/information_schema\.COLUMNS/i.test(sql)) {
      const physical = params[0];
      if (physical === 'fmb_cap_databases') {
        const cols = state.databasesColumns ?? FULL_DATABASES_COLUMNS;
        return cols.map((name) => ({ name }));
      }
      const cols = state.vmsColumns ?? FULL_VMS_COLUMNS;
      return cols.map((name) => ({ name }));
    }

    // §17.1a reference-integrity probe (with the FOR-UPDATE lock).
    if (/SELECT id, scenario_id(?:, vm_type)?, \(scenario_id = \?\) AS same_scenario[\s\S]*FROM `fmb_cap_[a-z_]+` WHERE id = \?/.test(sql)) {
      if (!state.catalogueFound) return [];
      // (referencing scenario, referenced id): the probe binds the scope FIRST
      // now, because the ENGINE answers whether the referenced row is in this
      // scenario. `same_scenario` is COMPUTED here rather than scripted — a
      // fixture carrying a hand-written verdict would be asserting on itself,
      // and the case-fold is the very thing the JavaScript comparison got wrong.
      const [referencingScenarioId, id] = params;
      const owner = state.catalogueScenarioId;
      const same = owner == null || referencingScenarioId == null
        ? null
        : (String(owner).toLowerCase() === String(referencingScenarioId).toLowerCase() ? 1 : 0);
      return [{ id, scenario_id: owner, same_scenario: same }];
    }

    // Profile-class coherence probe (SELECT class FROM cap_vm_profiles).
    if (/^SELECT class FROM `fmb_cap_vm_profiles` WHERE id = \?/.test(sql)) {
      return state.profileClass == null ? [{ class: null }] : [{ class: state.profileClass }];
    }

    // TA.1/TA.2: profile sizing + allow-list hydration. The statement JOINs the
    // requested ids against the table so the ENGINE decides which requested
    // spelling names which row, and carries the requested one back as
    // `requested_id` — the Maps built from it are read with the BODY's value.
    // The double answers with both, keyed the way the fixtures are keyed.
    if (/JOIN `fmb_cap_vm_profiles` p ON p\.id = w\.want/.test(sql)) {
      return joinByRequestedId(state.profiles, params, (row) => row);
    }
    // TA.1: disk-combo sizes hydration (summed to disk_gb).
    if (/JOIN `fmb_cap_disk_combos` p ON p\.id = w\.want/.test(sql)) {
      return joinByRequestedId(state.combos, params, (sizes) => ({ sizes }));
    }
    // TA.1: global settings formula constants + the scenario-effective standby
    // SGA default (spec §4.3 B5/§6.3) — scenario_id IS NULL singleton.
    if (/SELECT mem_cpu_ratio, sga_factor, sga_divisor, sga_subtract, standby_sga_default_gb FROM `fmb_cap_settings` WHERE scenario_id IS NULL LIMIT 1/.test(sql)) {
      return state.settingsRow ? [state.settingsRow] : [];
    }

    const insertMatch = sql.match(/^INSERT INTO `fmb_(cap_[a-z_]+)`/);
    if (insertMatch) {
      if (state.throwOnInsertInto && insertMatch[1] === state.throwOnInsertInto) {
        const e = new Error('simulated insert failure');
        e.errno = 1213;
        throw e;
      }
      return { affectedRows: 1, insertId: 1 };
    }
    return [];
  },
};

const poolFacade = {
  getConnection: async () => conn,
  query: (sql, params) => conn.query(sql, params),
};
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: { ro: poolFacade, rw: poolFacade }, t: (n) => `fmb_${n}` },
};

const wizard = require('../../../../src/edge/routes/app/capacity/wizard');
const router = require('../../../../src/edge/routes/app/capacity');
// The write-side column probe caches per physical table (60s TTL) — reset between
// cases so a "present" fixture never leaks into a later "absent" case, and back.
const { _resetColumnSetCache, _resetTopologySchemaCache } = require('../../../../src/edge/routes/app/capacity/_shared');
const { buildWizardPlan, expectedInstanceCounts } = wizard;

// ── A canonical valid payload builder (one Single DB + one AP VM + one host) ───
function validPayload(overrides = {}) {
  return {
    name: 'North Sea Alpha',
    description: 'demo scenario',
    sites: [{ ref: 's1', name: 'DC-A' }],
    hypervisors: [{ name: 'hv-a-01', site_ref: 's1', spec_id: 'b4162144-6ecd-4eaf-8bb6-dba7abd6edfd' }],
    databases: [{ ref: 'd1', function_name: 'erp', topology: 'single' }],
    vms: [
      { ref: 'vm-db1', name: 'erp-db-1', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1' },
      { ref: 'vm-ap1', name: 'erp-ap-1', vm_type: 'ap_host', site_ref: 's1' },
    ],
    db_instances: [
      { name: 'erp1', vm_ref: 'vm-db1', database_ref: 'd1', role: 'primary' },
    ],
    ...overrides,
  };
}

// ── Route harness ─────────────────────────────────────────────────────────────
let currentUser; let server; let baseUrl;
before(async () => {
  const app = express();
  app.use((req, _res, next) => { req.log = makeStubReqLog(); next(); }); // TEST-ONLY: production always sets req.log via createRequestId (request-id.js) before any router; this bare app has no such middleware, so a route's req.log.<level>() call would otherwise throw against undefined.
  app.use(express.json({ limit: '10mb' })); // mirror the edge body limit (index-edge.js)
  app.use((req, _res, next) => { req.user = currentUser; next(); });
  app.use('/capacity', router);
  server = http.createServer(app);
  await new Promise((r) => server.listen(0, r));
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});
after(() => server && server.close());
beforeEach(() => {
  state = freshState();
  currentUser = { id: 'u-admin', role: 'admin' };
  _resetColumnSetCache();
  _resetTopologySchemaCache();
});

function request(method, path, body) {
  return new Promise((resolve, reject) => {
    const payload = body === undefined ? '' : JSON.stringify(body);
    const r = http.request(
      `${baseUrl}${path}`,
      { method, headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) } },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          const raw = Buffer.concat(chunks).toString('utf8');
          let json = null;
          try { json = JSON.parse(raw); } catch { /* noop */ }
          resolve({ status: res.statusCode, json, raw });
        });
      },
    );
    r.on('error', reject);
    if (payload) r.write(payload);
    r.end();
  });
}

const insertsInto = (table) =>
  state.queries.filter((q) => new RegExp(`^INSERT INTO \`fmb_${table}\``).test(q.sql));
const anyEntityInsert = () =>
  state.queries.some((q) => /^INSERT INTO `fmb_cap_/.test(q.sql));

// ── 1. PURE plan validation ───────────────────────────────────────────────────
describe('buildWizardPlan — topology instance counts (spec §10.1)', () => {
  it('single = 1 primary instance', () => {
    assert.deepEqual(expectedInstanceCounts('single'), { primary: 1, standby: 0 });
  });
  it('primary = 2 primary, no standby', () => {
    assert.deepEqual(expectedInstanceCounts('primary'), { primary: 2, standby: 0 });
  });
  it('primary_standby = 2 primary + 2 standby (standby fixed 2)', () => {
    assert.deepEqual(expectedInstanceCounts('primary_standby'), { primary: 2, standby: 2 });
  });
  it('rac = node_count primary instances', () => {
    assert.deepEqual(expectedInstanceCounts('rac_multinode', 4), { primary: 4, standby: 0 });
  });
  // spec §7 E1 / Q11: primary N (the SAME node_count RAC uses) + standby S,
  // defaulting to N when omitted.
  it('rac_multinode_standby = node_count primary + standby_node_count standby, S defaults to N', () => {
    assert.deepEqual(expectedInstanceCounts('rac_multinode_standby', 4, 2), { primary: 4, standby: 2 });
    assert.deepEqual(expectedInstanceCounts('rac_multinode_standby', 4), { primary: 4, standby: 4 });
  });

  it('accepts a well-formed single-DB scenario', () => {
    const out = buildWizardPlan(validPayload());
    assert.equal(out.ok, true, JSON.stringify(out.errors));
  });

  it('accepts a full primary_standby cluster (2 primary + 2 standby on 4 VMs)', () => {
    const payload = validPayload({
      databases: [{ ref: 'd1', function_name: 'mes', topology: 'primary_standby' }],
      vms: [
        { ref: 'p1', name: 'mes-db-1', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1' },
        { ref: 'p2', name: 'mes-db-2', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1' },
        { ref: 'sb1', name: 'mes-db-3', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1' },
        { ref: 'sb2', name: 'mes-db-4', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1' },
      ],
      db_instances: [
        // Standby instances SHARE the primary instance names (spec §10.2).
        { name: 'mes1', vm_ref: 'p1', database_ref: 'd1', role: 'primary' },
        { name: 'mes2', vm_ref: 'p2', database_ref: 'd1', role: 'primary' },
        { name: 'mes1', vm_ref: 'sb1', database_ref: 'd1', role: 'standby' },
        { name: 'mes2', vm_ref: 'sb2', database_ref: 'd1', role: 'standby' },
      ],
    });
    const out = buildWizardPlan(payload);
    assert.equal(out.ok, true, JSON.stringify(out.errors));
  });

  it('rejects a Single DB with 2 instances (count mismatch)', () => {
    const payload = validPayload({
      vms: [
        { ref: 'vm-db1', name: 'erp-db-1', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1' },
        { ref: 'vm-db2', name: 'erp-db-2', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1' },
      ],
      db_instances: [
        { name: 'erp1', vm_ref: 'vm-db1', database_ref: 'd1', role: 'primary' },
        { name: 'erp2', vm_ref: 'vm-db2', database_ref: 'd1', role: 'primary' },
      ],
    });
    const out = buildWizardPlan(payload);
    assert.equal(out.ok, false);
    assert.match(out.errors.join('\n'), /expected 1 primary \+ 0 standby/);
  });

  it('rejects a standby instance under a database with no standby side (single)', () => {
    const payload = validPayload({
      db_instances: [
        { name: 'erp1', vm_ref: 'vm-db1', database_ref: 'd1', role: 'standby' },
      ],
    });
    const out = buildWizardPlan(payload);
    assert.equal(out.ok, false);
    assert.match(out.errors.join('\n'), /standby instance is only allowed under a primary_standby or rac_multinode_standby database/);
  });

  it('rejects an instance hanging off an ap_host VM', () => {
    const payload = validPayload({
      db_instances: [
        { name: 'erp1', vm_ref: 'vm-ap1', database_ref: 'd1', role: 'primary' },
      ],
    });
    const out = buildWizardPlan(payload);
    assert.equal(out.ok, false);
    assert.match(out.errors.join('\n'), /vm_ref must reference a db_host VM/);
  });

  it('rejects RAC with node_count < 2', () => {
    const payload = validPayload({
      databases: [{ ref: 'd1', function_name: 'erp', topology: 'rac_multinode', node_count: 1 }],
      db_instances: [{ name: 'erp1', vm_ref: 'vm-db1', database_ref: 'd1', role: 'primary' }],
    });
    const out = buildWizardPlan(payload);
    assert.equal(out.ok, false);
    assert.match(out.errors.join('\n'), /RAC node_count must be an integer >= 2/);
  });

  it('rejects RAC with node_count above the upper bound', () => {
    const payload = validPayload({
      databases: [{ ref: 'd1', function_name: 'erp', topology: 'rac_multinode', node_count: 101 }],
      db_instances: [{ name: 'erp1', vm_ref: 'vm-db1', database_ref: 'd1', role: 'primary' }],
    });
    const out = buildWizardPlan(payload);
    assert.equal(out.ok, false);
    assert.match(out.errors.join('\n'), /RAC node_count must be an integer >= 2 and <= 100/);
  });

  // spec §7 E1 / Q11: primary N (2..100, RAC's own clamp) + standby S (1..100,
  // no clustering floor — S=1 is legal) — both sides share ONE name family,
  // serial per side (same design as primary_standby, generalized to N/S).
  describe('rac_multinode_standby (spec §7 E1 / Q11)', () => {
    it('accepts a well-formed 3 primary + 2 standby cluster, names shared per-index', () => {
      const payload = validPayload({
        databases: [{ ref: 'd1', function_name: 'orcl', topology: 'rac_multinode_standby', node_count: 3, standby_node_count: 2 }],
        vms: [
          { ref: 'p1', name: 'orcl-db-1', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1' },
          { ref: 'p2', name: 'orcl-db-2', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1' },
          { ref: 'p3', name: 'orcl-db-3', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1' },
          { ref: 'sb1', name: 'orcl-db-4', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1' },
          { ref: 'sb2', name: 'orcl-db-5', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1' },
        ],
        db_instances: [
          { name: 'orcl1', vm_ref: 'p1', database_ref: 'd1', role: 'primary' },
          { name: 'orcl2', vm_ref: 'p2', database_ref: 'd1', role: 'primary' },
          { name: 'orcl3', vm_ref: 'p3', database_ref: 'd1', role: 'primary' },
          // Standby instances SHARE the primary instance names (Q11), serial per side.
          { name: 'orcl1', vm_ref: 'sb1', database_ref: 'd1', role: 'standby' },
          { name: 'orcl2', vm_ref: 'sb2', database_ref: 'd1', role: 'standby' },
        ],
      });
      const out = buildWizardPlan(payload);
      assert.equal(out.ok, true, JSON.stringify(out.errors));
    });

    it('S=1 is a legal edge case (no clustering floor on the standby side)', () => {
      const payload = validPayload({
        databases: [{ ref: 'd1', function_name: 'orcl', topology: 'rac_multinode_standby', node_count: 2, standby_node_count: 1 }],
        vms: [
          { ref: 'p1', name: 'orcl-db-1', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1' },
          { ref: 'p2', name: 'orcl-db-2', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1' },
          { ref: 'sb1', name: 'orcl-db-3', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1' },
        ],
        db_instances: [
          { name: 'orcl1', vm_ref: 'p1', database_ref: 'd1', role: 'primary' },
          { name: 'orcl2', vm_ref: 'p2', database_ref: 'd1', role: 'primary' },
          { name: 'orcl1', vm_ref: 'sb1', database_ref: 'd1', role: 'standby' },
        ],
      });
      const out = buildWizardPlan(payload);
      assert.equal(out.ok, true, JSON.stringify(out.errors));
    });

    // F1 fix: an OMITTED standby_node_count no longer errors — it defaults to N,
    // matching the wizard's own "S defaults to N" rule (Q11) and the payload
    // the client now actually sends for an untouched row (buildWizardPayload
    // omits the field entirely rather than always resolving a concrete number).
    it('an omitted standby_node_count defaults to N (3 primary + 3 standby)', () => {
      const payload = validPayload({
        databases: [{ ref: 'd1', function_name: 'orcl', topology: 'rac_multinode_standby', node_count: 3 }],
        vms: [
          { ref: 'p1', name: 'orcl-db-1', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1' },
          { ref: 'p2', name: 'orcl-db-2', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1' },
          { ref: 'p3', name: 'orcl-db-3', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1' },
          { ref: 'sb1', name: 'orcl-db-4', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1' },
          { ref: 'sb2', name: 'orcl-db-5', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1' },
          { ref: 'sb3', name: 'orcl-db-6', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1' },
        ],
        db_instances: [
          { name: 'orcl1', vm_ref: 'p1', database_ref: 'd1', role: 'primary' },
          { name: 'orcl2', vm_ref: 'p2', database_ref: 'd1', role: 'primary' },
          { name: 'orcl3', vm_ref: 'p3', database_ref: 'd1', role: 'primary' },
          { name: 'orcl1', vm_ref: 'sb1', database_ref: 'd1', role: 'standby' },
          { name: 'orcl2', vm_ref: 'sb2', database_ref: 'd1', role: 'standby' },
          { name: 'orcl3', vm_ref: 'sb3', database_ref: 'd1', role: 'standby' },
        ],
      });
      const out = buildWizardPlan(payload);
      assert.equal(out.ok, true, JSON.stringify(out.errors));
    });

    it('rejects an explicit invalid standby_node_count (a present malformed value still 400s)', () => {
      const payload = validPayload({
        databases: [{ ref: 'd1', function_name: 'orcl', topology: 'rac_multinode_standby', node_count: 3, standby_node_count: -1 }],
        db_instances: [{ name: 'orcl1', vm_ref: 'vm-db1', database_ref: 'd1', role: 'primary' }],
      });
      const out = buildWizardPlan(payload);
      assert.equal(out.ok, false);
      assert.match(out.errors.join('\n'), /RAC \+ Standby standby_node_count must be an integer >= 1 and <= 100/);
    });

    it('rejects a standby_node_count above the upper bound', () => {
      const payload = validPayload({
        databases: [{ ref: 'd1', function_name: 'orcl', topology: 'rac_multinode_standby', node_count: 3, standby_node_count: 101 }],
        db_instances: [{ name: 'orcl1', vm_ref: 'vm-db1', database_ref: 'd1', role: 'primary' }],
      });
      const out = buildWizardPlan(payload);
      assert.equal(out.ok, false);
      assert.match(out.errors.join('\n'), /RAC \+ Standby standby_node_count must be an integer >= 1 and <= 100/);
    });

    it('accepts a standby instance under a rac_multinode_standby database (role legality)', () => {
      const payload = validPayload({
        databases: [{ ref: 'd1', function_name: 'orcl', topology: 'rac_multinode_standby', node_count: 2, standby_node_count: 2 }],
        vms: [
          { ref: 'p1', name: 'orcl-db-1', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1' },
          { ref: 'p2', name: 'orcl-db-2', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1' },
          { ref: 'sb1', name: 'orcl-db-3', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1' },
          { ref: 'sb2', name: 'orcl-db-4', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1' },
        ],
        db_instances: [
          { name: 'orcl1', vm_ref: 'p1', database_ref: 'd1', role: 'primary' },
          { name: 'orcl2', vm_ref: 'p2', database_ref: 'd1', role: 'primary' },
          { name: 'orcl1', vm_ref: 'sb1', database_ref: 'd1', role: 'standby' },
          { name: 'orcl2', vm_ref: 'sb2', database_ref: 'd1', role: 'standby' },
        ],
      });
      assert.equal(buildWizardPlan(payload).ok, true);
    });
  });

  it('rejects an oversized vms array as a too-large payload (DoS bound)', () => {
    const vms = Array.from({ length: 2001 }, (_, i) => ({
      ref: `vm-${i}`, name: `vm-${i}`, vm_type: 'ap_host', site_ref: 's1',
    }));
    const out = buildWizardPlan(validPayload({ vms, databases: [], db_instances: [] }));
    assert.equal(out.ok, false);
    assert.equal(out.tooLarge, true);
    assert.match(out.errors.join('\n'), /vms exceeds the maximum of 2000 rows/);
  });

  it('rejects an oversized db_instances array as a too-large payload', () => {
    const dbInstances = Array.from({ length: 4001 }, () => ({ name: 'x', vm_ref: 'vm-db1', database_ref: 'd1', role: 'primary' }));
    const out = buildWizardPlan(validPayload({ db_instances: dbInstances }));
    assert.equal(out.ok, false);
    assert.equal(out.tooLarge, true);
    assert.match(out.errors.join('\n'), /db_instances exceeds the maximum of 4000 rows/);
  });

  it('rejects a per-row metadata blob over the byte cap', () => {
    const big = { blob: 'x'.repeat(9000) };
    const out = buildWizardPlan(validPayload({
      sites: [{ ref: 's1', name: 'DC-A', metadata: big }],
    }));
    assert.equal(out.ok, false);
    assert.match(out.errors.join('\n'), /metadata exceeds 8192 bytes/);
  });

  it('rejects more than 4 sites', () => {
    const payload = validPayload({
      sites: [
        { ref: 's1', name: 'A' }, { ref: 's2', name: 'B' },
        { ref: 's3', name: 'C' }, { ref: 's4', name: 'D' }, { ref: 's5', name: 'E' },
      ],
    });
    const out = buildWizardPlan(payload);
    assert.equal(out.ok, false);
    assert.match(out.errors.join('\n'), /at most 4 sites/);
  });

  it('rejects a description over 120 characters', () => {
    const out = buildWizardPlan(validPayload({ description: 'x'.repeat(121) }));
    assert.equal(out.ok, false);
    assert.match(out.errors.join('\n'), /description exceeds 120/);
  });

  it('rejects a missing name', () => {
    const out = buildWizardPlan(validPayload({ name: '   ' }));
    assert.equal(out.ok, false);
    assert.match(out.errors.join('\n'), /name is required/);
  });

  it('rejects an unresolved site_ref on a VM', () => {
    const out = buildWizardPlan(validPayload({
      vms: [{ ref: 'vm-ap1', name: 'x', vm_type: 'ap_host', site_ref: 'nope' }],
      db_instances: [],
      databases: [],
    }));
    assert.equal(out.ok, false);
    assert.match(out.errors.join('\n'), /site_ref does not match a site/);
  });

  it('rejects an ap_host VM carrying a database_ref', () => {
    const out = buildWizardPlan(validPayload({
      vms: [
        { ref: 'vm-db1', name: 'erp-db-1', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1' },
        { ref: 'vm-ap1', name: 'erp-ap-1', vm_type: 'ap_host', site_ref: 's1', database_ref: 'd1' },
      ],
    }));
    assert.equal(out.ok, false);
    assert.match(out.errors.join('\n'), /an ap_host VM cannot reference a database/);
  });
});

// ── databases[].function_name charset — NO grandfather exemption ─────
// This endpoint always mints a BRAND NEW scenario, so there is never an existing
// row in scope a legacy spelling could already be — every value here is new
// content, so VM_FUNCTION_NAME_RE applies unconditionally (buildWizardPlan is
// pure: no DB read backs this check, unlike the child-mount / bulk-create guards).
describe('buildWizardPlan — databases[].function_name charset (fmb-1705)', () => {
  it('accepts a conforming function_name', () => {
    const out = buildWizardPlan(validPayload({
      databases: [{ ref: 'd1', function_name: 'erp-prod', topology: 'single' }],
    }));
    assert.equal(out.ok, true, JSON.stringify(out.errors));
  });

  it('rejects a function_name carrying an underscore (no legacy exemption on a NEW scenario)', () => {
    const out = buildWizardPlan(validPayload({
      databases: [{ ref: 'd1', function_name: 'erp_prod', topology: 'single' }],
    }));
    assert.equal(out.ok, false);
    assert.match(out.errors.join('\n'), /function_name may only contain letters, digits and hyphens/);
  });

  it('rejects a function_name carrying a brace (security parity with the vms sheet)', () => {
    const out = buildWizardPlan(validPayload({
      databases: [{ ref: 'd1', function_name: 'erp{dc}', topology: 'single' }],
    }));
    assert.equal(out.ok, false);
    assert.match(out.errors.join('\n'), /function_name may only contain letters, digits and hyphens/);
  });

  it('an EMPTY function_name is caught by the required check, not re-flagged by the charset check', () => {
    const out = buildWizardPlan(validPayload({
      databases: [{ ref: 'd1', function_name: '', topology: 'single' }],
    }));
    assert.equal(out.ok, false);
    assert.match(out.errors.join('\n'), /function_name is required/);
    assert.equal(out.errors.some((e) => /may only contain letters/.test(e)), false, 'one error per problem, not two');
  });
});

// ── 2. Route behaviour ────────────────────────────────────────────────────────
describe('POST /capacity/scenarios/wizard', () => {
  it('materializes the whole skeleton in one transaction (admin, shared owner)', async () => {
    const res = await request('POST', '/capacity/scenarios/wizard', validPayload());
    assert.equal(res.status, 201, res.raw);
    assert.equal(res.json.data.counts.sites, 1);
    assert.equal(res.json.data.counts.hypervisors, 1);
    assert.equal(res.json.data.counts.databases, 1);
    assert.equal(res.json.data.counts.vms, 2);
    assert.equal(res.json.data.counts.db_instances, 1);
    assert.equal(insertsInto('cap_scenarios').length, 1);
    assert.equal(insertsInto('cap_sites').length, 1);
    assert.equal(insertsInto('cap_hypervisors').length, 1);
    assert.equal(insertsInto('cap_databases').length, 1);
    assert.equal(insertsInto('cap_vms').length, 2);
    assert.equal(insertsInto('cap_db_instances').length, 1);
    // admin → owner_id NULL (shared). INSERT (id, name, owner_id, note).
    assert.equal(insertsInto('cap_scenarios')[0].params[2], null);
    assert.equal(state.committed, 1);
    assert.equal(state.rolledBack, 0);
    assert.equal(state.released, 1);
  });

  it('C2: a PRIMARY instance co-located on a shared db_host VM persists its vm_ref, 2+2 intact', async () => {
    // A generalized co-location KVM: a db_host VM with NO database_ref that hosts
    // one primary + one standby instance from a P+S database; the database's other
    // two instances stay on their own dedicated VMs. The 2+2 topology count holds.
    const res = await request('POST', '/capacity/scenarios/wizard', validPayload({
      databases: [{ ref: 'd1', function_name: 'mes', topology: 'primary_standby' }],
      vms: [
        { ref: 'shared', name: 'shared-kvm-1', vm_type: 'db_host', site_ref: 's1' }, // co-location KVM, no database_ref
        { ref: 'p2', name: 'mes-db-2', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1' },
        { ref: 's2', name: 'mes-db-4', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1' },
      ],
      db_instances: [
        { name: 'mes1', vm_ref: 'shared', database_ref: 'd1', role: 'primary' }, // primary co-located on the shared VM
        { name: 'mes2', vm_ref: 'p2', database_ref: 'd1', role: 'primary' },
        { name: 'mes1', vm_ref: 'shared', database_ref: 'd1', role: 'standby' }, // standby co-located on the same shared VM
        { name: 'mes2', vm_ref: 's2', database_ref: 'd1', role: 'standby' },
      ],
    }));
    assert.equal(res.status, 201, res.raw);
    // The shared co-location VM was inserted with a NULL database_id (not owned by a DB).
    const sharedVm = insertsInto('cap_vms').find((q) => colVal(q, 'name') === 'shared-kvm-1');
    assert.ok(sharedVm, 'the shared co-location VM was inserted');
    assert.equal(colVal(sharedVm, 'database_id'), null);
    const sharedId = colVal(sharedVm, 'id');
    // A PRIMARY instance points its vm_id at that shared VM — persists, not rejected.
    const onShared = insertsInto('cap_db_instances').filter((q) => colVal(q, 'vm_id') === sharedId);
    assert.equal(onShared.length, 2, 'both the co-located primary + standby persisted on the shared VM');
    assert.ok(onShared.some((q) => colVal(q, 'role') === 'primary'), 'a primary co-located on the shared VM persisted');
    assert.equal(insertsInto('cap_db_instances').length, 4, '2 primary + 2 standby (2+2 topology intact)');
  });

  it('editor-created scenario is owner-stamped', async () => {
    currentUser = { id: 'u-ed', role: 'editor' };
    const res = await request('POST', '/capacity/scenarios/wizard', validPayload());
    assert.equal(res.status, 201, res.raw);
    assert.equal(insertsInto('cap_scenarios')[0].params[2], 'u-ed');
  });

  it('VMs are created host-unplaced (hypervisor_id NULL)', async () => {
    await request('POST', '/capacity/scenarios/wizard', validPayload());
    for (const q of insertsInto('cap_vms')) {
      const cols = q.sql.match(/\(([^)]*)\) VALUES/)[1].split(',').map((c) => c.trim().replace(/`/g, ''));
      const hvIdx = cols.indexOf('hypervisor_id');
      assert.notEqual(hvIdx, -1, 'vm insert must set hypervisor_id explicitly');
      assert.equal(q.params[hvIdx], null, 'wizard VMs are host-unplaced');
    }
  });

  it('writes order_index = array index for each site — the DC order the user typed, not created_at (spec §4.3 B1)', async () => {
    const res = await request('POST', '/capacity/scenarios/wizard', validPayload({
      sites: [
        { ref: 's-zulu', name: 'Zulu DC' },
        { ref: 's-alpha', name: 'Alpha DC' },
        { ref: 's-mike', name: 'Mike DC' },
      ],
      hypervisors: [{ name: 'hv-a-01', site_ref: 's-zulu', spec_id: 'b4162144-6ecd-4eaf-8bb6-dba7abd6edfd' }],
      vms: [
        { ref: 'vm-db1', name: 'erp-db-1', vm_type: 'db_host', site_ref: 's-zulu', database_ref: 'd1' },
        { ref: 'vm-ap1', name: 'erp-ap-1', vm_type: 'ap_host', site_ref: 's-zulu' },
      ],
    }));
    assert.equal(res.status, 201, res.raw);
    const siteInserts = insertsInto('cap_sites');
    assert.equal(siteInserts.length, 3);
    const orderByName = new Map(siteInserts.map((q) => [colVal(q, 'name'), colVal(q, 'order_index')]));
    // Alphabetically Alpha < Mike < Zulu — proves the persisted order is the
    // SUBMITTED array position, not a name/created_at re-sort.
    assert.equal(orderByName.get('Zulu DC'), 0);
    assert.equal(orderByName.get('Alpha DC'), 1);
    assert.equal(orderByName.get('Mike DC'), 2);
  });

  it('writes order_index = array index for hypervisors / VMs / DB instances (phase-4 §6)', async () => {
    // Multiple rows per table so a tie at DEFAULT 0 would be visible: each insert
    // must carry its array position, mirroring sites — otherwise the new
    // ?sort=order_index reads make wizard-created rows order-random (UUID PK
    // tie-break).
    const res = await request('POST', '/capacity/scenarios/wizard', validPayload({
      hypervisors: [
        { name: 'hv-a-01', site_ref: 's1', spec_id: 'b4162144-6ecd-4eaf-8bb6-dba7abd6edfd' },
        { name: 'hv-a-02', site_ref: 's1', spec_id: 'b4162144-6ecd-4eaf-8bb6-dba7abd6edfd' },
      ],
      databases: [{ ref: 'd1', function_name: 'mes', topology: 'primary_standby' }],
      vms: [
        { ref: 'p1', name: 'mes-db-1', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1' },
        { ref: 'p2', name: 'mes-db-2', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1' },
        { ref: 'sb1', name: 'mes-db-3', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1' },
        { ref: 'sb2', name: 'mes-db-4', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1' },
      ],
      db_instances: [
        { name: 'mes1', vm_ref: 'p1', database_ref: 'd1', role: 'primary' },
        { name: 'mes2', vm_ref: 'p2', database_ref: 'd1', role: 'primary' },
        { name: 'mes1', vm_ref: 'sb1', database_ref: 'd1', role: 'standby' },
        { name: 'mes2', vm_ref: 'sb2', database_ref: 'd1', role: 'standby' },
      ],
    }));
    assert.equal(res.status, 201, res.raw);
    for (const table of ['cap_hypervisors', 'cap_vms', 'cap_db_instances']) {
      const inserts = insertsInto(table);
      assert.ok(inserts.length >= 2, `${table} needs multiple rows to prove ordering`);
      inserts.forEach((q, i) => {
        assert.equal(colVal(q, 'order_index'), i, `${table}[${i}] order_index`);
      });
    }
  });

  it('does not persist bundle_id (stamping records no membership, §7.2)', async () => {
    const res = await request('POST', '/capacity/scenarios/wizard', validPayload({ bundle_id: 'bundle-xyz' }));
    assert.equal(res.status, 201, res.raw);
    const bundleLeak = state.queries.some((q) => Array.isArray(q.params) && q.params.includes('bundle-xyz'));
    assert.equal(bundleLeak, false, 'bundle_id must never be written to any row');
  });

  it('a plain user is refused (403) and nothing is written', async () => {
    currentUser = { id: 'u-user', role: 'user' };
    const res = await request('POST', '/capacity/scenarios/wizard', validPayload());
    assert.equal(res.status, 403, res.raw);
    assert.equal(anyEntityInsert(), false);
  });

  it('an invalid row rejects the whole request (400) and writes nothing', async () => {
    const res = await request('POST', '/capacity/scenarios/wizard', validPayload({
      db_instances: [{ name: 'erp1', vm_ref: 'vm-ap1', database_ref: 'd1', role: 'primary' }],
    }));
    assert.equal(res.status, 400, res.raw);
    assert.ok(Array.isArray(res.json.error.details));
    assert.equal(anyEntityInsert(), false);
    assert.equal(state.began, 0, 'must fail before opening a transaction');
  });

  it('an oversized array is rejected 413 and writes nothing', async () => {
    const vms = Array.from({ length: 2001 }, (_, i) => ({
      ref: `vm-${i}`, name: `vm-${i}`, vm_type: 'ap_host', site_ref: 's1',
    }));
    const res = await request('POST', '/capacity/scenarios/wizard', validPayload({ vms, databases: [], db_instances: [] }));
    assert.equal(res.status, 413, res.raw);
    assert.equal(res.json.error.code, 'PAYLOAD_TOO_LARGE');
    assert.equal(anyEntityInsert(), false);
    assert.equal(state.began, 0, 'must fail before opening a transaction');
  });

  it('§17.1a: a foreign-scenario catalogue reference is rejected (400), nothing written', async () => {
    state.catalogueScenarioId = 'other-scenario'; // spec_id points at another scenario's local row
    const res = await request('POST', '/capacity/scenarios/wizard', validPayload());
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'INVALID_REFERENCE');
    assert.equal(anyEntityInsert(), false, 'no rows inserted when a catalogue ref is invalid');
    assert.equal(state.rolledBack, 1, 'the read/lock transaction is rolled back');
    assert.equal(state.committed, 0);
  });

  it('§17.1a: a missing catalogue row is rejected (400)', async () => {
    state.catalogueFound = false;
    const res = await request('POST', '/capacity/scenarios/wizard', validPayload());
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'INVALID_REFERENCE');
    assert.equal(anyEntityInsert(), false);
  });

  it('probes catalogue references under a FOR UPDATE lock', async () => {
    await request('POST', '/capacity/scenarios/wizard', validPayload());
    const probe = state.queries.find((q) => /SELECT id, scenario_id, \(scenario_id = \?\) AS same_scenario[\s\S]*FROM `fmb_cap_/.test(q.sql));
    assert.ok(probe, 'a catalogue reference probe must run');
    assert.match(probe.sql, /FOR UPDATE/, 'the §17.1a probe must lock the referenced row');
  });

  it('rejects a db_host VM referencing an AP-class profile (400), nothing written', async () => {
    state.profileClass = 'AP';
    const res = await request('POST', '/capacity/scenarios/wizard', validPayload({
      vms: [
        { ref: 'vm-db1', name: 'erp-db-1', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1', sizing_profile_id: '7b7ec4b0-3f9c-4f7f-8f9e-8573da43a688' },
        { ref: 'vm-ap1', name: 'erp-ap-1', vm_type: 'ap_host', site_ref: 's1' },
      ],
    }));
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'INVALID_REFERENCE');
    assert.match(res.json.error.message, /must reference a DB-class profile/);
    assert.equal(anyEntityInsert(), false);
    assert.equal(state.rolledBack, 1);
    assert.equal(state.committed, 0);
  });

  it('rejects an ap_host VM referencing a DB-class profile (400)', async () => {
    state.profileClass = 'DB';
    const res = await request('POST', '/capacity/scenarios/wizard', validPayload({
      vms: [
        { ref: 'vm-db1', name: 'erp-db-1', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1' },
        { ref: 'vm-ap1', name: 'erp-ap-1', vm_type: 'ap_host', site_ref: 's1', sizing_profile_id: 'ebe50b0b-d6a3-489e-8db1-3b5033d7d0ee' },
      ],
    }));
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'INVALID_REFERENCE');
    assert.match(res.json.error.message, /must reference a AP-class profile/);
    assert.equal(anyEntityInsert(), false);
  });

  it('accepts matching profile classes (db_host + database → DB)', async () => {
    state.profileClass = 'DB';
    const res = await request('POST', '/capacity/scenarios/wizard', validPayload({
      databases: [{ ref: 'd1', function_name: 'erp', topology: 'single', profile_id: 'a4979cf3-c3ff-408a-8922-609bfcee749c' }],
      vms: [
        { ref: 'vm-db1', name: 'erp-db-1', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1', sizing_profile_id: 'a4979cf3-c3ff-408a-8922-609bfcee749c' },
        { ref: 'vm-ap1', name: 'erp-ap-1', vm_type: 'ap_host', site_ref: 's1' },
      ],
    }));
    assert.equal(res.status, 201, res.raw);
  });

  it('rolls back and 500s when a mid-transaction insert fails', async () => {
    state.throwOnInsertInto = 'cap_db_instances';
    const res = await request('POST', '/capacity/scenarios/wizard', validPayload());
    assert.equal(res.status, 500, res.raw);
    assert.equal(state.rolledBack, 1);
    assert.equal(state.committed, 0);
    assert.equal(state.released, 1);
  });
});

// ── 3. TA.1: server-side sizing derivation (spec §3.1.6 / §5.2) ─────────────────
// Read a single INSERT's value for `col` by matching the column list to params.
function colVal(insert, col) {
  const cols = insert.sql.match(/\(([^)]*)\) VALUES/)[1].split(',').map((c) => c.trim().replace(/`/g, ''));
  const idx = cols.indexOf(col);
  return idx === -1 ? undefined : insert.params[idx];
}

describe('TA.1: wizard derives persisted sizing server-side', () => {
  it('a formula-mode profiled VM gets profile cpu + derived mem_gb (client cpu/mem ignored)', async () => {
    state.profileClass = 'AP';
    state.profiles['3e7ca1cb-cc56-4b15-8e27-83ed1e00b74d'] = { class: 'AP', mode: 'formula', cpu: 8, mem_gb: null, sga_cap_gb: null, allowed_disk_combos: null };
    const res = await request('POST', '/capacity/scenarios/wizard', validPayload({
      databases: [], db_instances: [],
      vms: [{ ref: 'vm-ap1', name: 'ap-1', vm_type: 'ap_host', site_ref: 's1', sizing_profile_id: '3e7ca1cb-cc56-4b15-8e27-83ed1e00b74d', cpu: 999, mem_gb: 999 }],
    }));
    assert.equal(res.status, 201, res.raw);
    const vm = insertsInto('cap_vms')[0];
    assert.equal(colVal(vm, 'cpu'), 8, 'cpu = profile cpu (client 999 ignored)');
    assert.equal(colVal(vm, 'mem_gb'), 160, 'mem_gb = cpu × mem_cpu_ratio (8 × 20)');
  });

  it('a custom-mode profiled VM uses the profile hand-set cpu/mem_gb', async () => {
    state.profileClass = 'AP';
    state.profiles['087fab42-e712-480b-841c-d2bbea0103e0'] = { class: 'AP', mode: 'custom', cpu: 6, mem_gb: 48, sga_cap_gb: null, allowed_disk_combos: null };
    const res = await request('POST', '/capacity/scenarios/wizard', validPayload({
      databases: [], db_instances: [],
      vms: [{ ref: 'vm-ap1', name: 'ap-1', vm_type: 'ap_host', site_ref: 's1', sizing_profile_id: '087fab42-e712-480b-841c-d2bbea0103e0' }],
    }));
    assert.equal(res.status, 201, res.raw);
    const vm = insertsInto('cap_vms')[0];
    assert.equal(colVal(vm, 'cpu'), 6);
    assert.equal(colVal(vm, 'mem_gb'), 48);
  });

  it('disk_gb is the sum of the chosen disk combo sizes (client omits disk_gb)', async () => {
    state.profileClass = 'AP';
    state.profiles['3e7ca1cb-cc56-4b15-8e27-83ed1e00b74d'] = { class: 'AP', mode: 'formula', cpu: 8, mem_gb: null, sga_cap_gb: null, allowed_disk_combos: ['d591e4cf-5f3f-4299-852c-5753e9a900e0'] };
    state.combos['d591e4cf-5f3f-4299-852c-5753e9a900e0'] = [512, 1024];
    const res = await request('POST', '/capacity/scenarios/wizard', validPayload({
      databases: [], db_instances: [],
      vms: [{ ref: 'vm-ap1', name: 'ap-1', vm_type: 'ap_host', site_ref: 's1', sizing_profile_id: '3e7ca1cb-cc56-4b15-8e27-83ed1e00b74d', disk_combo_id: 'd591e4cf-5f3f-4299-852c-5753e9a900e0' }],
    }));
    assert.equal(res.status, 201, res.raw);
    assert.equal(colVal(insertsInto('cap_vms')[0], 'disk_gb'), 1536, 'disk_gb = 512 + 1024');
  });

  it('a no-profile (Custom) VM keeps client cpu/mem_gb', async () => {
    const res = await request('POST', '/capacity/scenarios/wizard', validPayload({
      databases: [], db_instances: [],
      vms: [{ ref: 'vm-ap1', name: 'ap-1', vm_type: 'ap_host', site_ref: 's1', cpu: 4, mem_gb: 8 }],
    }));
    assert.equal(res.status, 201, res.raw);
    const vm = insertsInto('cap_vms')[0];
    assert.equal(colVal(vm, 'cpu'), 4);
    assert.equal(colVal(vm, 'mem_gb'), 8);
  });
});

describe('ap-vm-function (PR-2): the wizard persists an AP VM function to cap_vms.function_name', () => {
  it('an ap_host VM with function_name lands it on the inserted cap_vms row', async () => {
    const res = await request('POST', '/capacity/scenarios/wizard', validPayload({
      databases: [], db_instances: [],
      vms: [{ ref: 'vm-ap1', name: 'ap-1', vm_type: 'ap_host', site_ref: 's1', cpu: 4, mem_gb: 8, function_name: 'erp' }],
    }));
    assert.equal(res.status, 201, res.raw);
    assert.equal(colVal(insertsInto('cap_vms')[0], 'function_name'), 'erp');
  });

  it('an ap_host VM without a function_name inserts NULL (→ ap fallback at renumber)', async () => {
    const res = await request('POST', '/capacity/scenarios/wizard', validPayload({
      databases: [], db_instances: [],
      vms: [{ ref: 'vm-ap1', name: 'ap-1', vm_type: 'ap_host', site_ref: 's1', cpu: 4, mem_gb: 8 }],
    }));
    assert.equal(res.status, 201, res.raw);
    const vm = insertsInto('cap_vms')[0];
    assert.equal(colVal(vm, 'function_name'), null);
  });

  it('a db_host VM carrying function_name is rejected 400 (its function comes from the database)', async () => {
    const res = await request('POST', '/capacity/scenarios/wizard', validPayload({
      vms: [
        { ref: 'vm-db1', name: 'erp-db-1', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1', function_name: 'erp' },
        { ref: 'vm-ap1', name: 'erp-ap-1', vm_type: 'ap_host', site_ref: 's1' },
      ],
    }));
    assert.equal(res.status, 400, res.raw);
    assert.match(res.raw, /db_host VM cannot carry function_name/);
  });

  it('an over-length function_name (>255) is rejected 400', async () => {
    const res = await request('POST', '/capacity/scenarios/wizard', validPayload({
      databases: [], db_instances: [],
      vms: [{ ref: 'vm-ap1', name: 'ap-1', vm_type: 'ap_host', site_ref: 's1', cpu: 4, mem_gb: 8, function_name: 'x'.repeat(256) }],
    }));
    assert.equal(res.status, 400, res.raw);
    assert.match(res.raw, /function_name exceeds 255/);
  });

  // M4 (PR-2 review, security): function_name feeds the {function} hostname token,
  // so a value carrying a control char / brace / whitespace is rejected 400 — only
  // the hostname-safe alphabet (letters, digits, hyphen) may persist.
  for (const [desc, value] of [
    ['a newline', 'erp\nweb'],
    ['a brace (template-injection shape)', 'erp{dc}'],
    ['a space', 'erp web'],
    ['a tab control char', 'erp\tweb'],
  ]) {
    it(`rejects a function_name carrying ${desc} (400)`, async () => {
      const res = await request('POST', '/capacity/scenarios/wizard', validPayload({
        databases: [], db_instances: [],
        vms: [{ ref: 'vm-ap1', name: 'ap-1', vm_type: 'ap_host', site_ref: 's1', cpu: 4, mem_gb: 8, function_name: value }],
      }));
      assert.equal(res.status, 400, res.raw);
      assert.match(res.raw, /function_name may only contain letters, digits and hyphens/);
    });
  }

  it('accepts a hyphenated hostname-safe function_name', async () => {
    const res = await request('POST', '/capacity/scenarios/wizard', validPayload({
      databases: [], db_instances: [],
      vms: [{ ref: 'vm-ap1', name: 'ap-1', vm_type: 'ap_host', site_ref: 's1', cpu: 4, mem_gb: 8, function_name: 'erp-web-01' }],
    }));
    assert.equal(res.status, 201, res.raw);
    assert.equal(colVal(insertsInto('cap_vms')[0], 'function_name'), 'erp-web-01');
  });
});

// ── H1 (PR-2 review): write-side degraded-schema guard on the cap_vms INSERT ────
// This is the M5 PINNED test the closure test's interpolation blind-spot note
// points at: the wizard builds the INSERT column list as an interpolated
// `${names}`, so `function_name` never appears in an SQL-verb string the family
// closure scans — the write-side degradation has to be proven directly here.
describe('ap-vm-function (PR-2, H1): degrades the cap_vms INSERT when function_name is physically absent', () => {
  it('a schema WITHOUT function_name still creates the scenario, omitting the column (no ER_BAD_FIELD_ERROR)', async () => {
    // A warn-skipped add-column migration leaves the column absent (id present).
    state.vmsColumns = FULL_VMS_COLUMNS.filter((c) => c !== 'function_name');
    const res = await request('POST', '/capacity/scenarios/wizard', validPayload({
      databases: [], db_instances: [],
      vms: [{ ref: 'vm-ap1', name: 'ap-1', vm_type: 'ap_host', site_ref: 's1', cpu: 4, mem_gb: 8, function_name: 'erp' }],
    }));
    assert.equal(res.status, 201, res.raw);
    const vm = insertsInto('cap_vms')[0];
    const cols = vm.sql.match(/\(([^)]*)\) VALUES/)[1].split(',').map((c) => c.trim().replace(/`/g, ''));
    assert.ok(!cols.includes('function_name'), `function_name must be omitted on a degraded schema, got: ${cols.join(', ')}`);
    assert.equal(state.committed, 1, 'the transaction must commit, not roll back');
  });

  it('the id fail-safe: an empty/odd probe (no id column) assumes present and still names the column', async () => {
    state.vmsColumns = []; // empty probe → dropAbsentColumns fail-safe → assume present
    const res = await request('POST', '/capacity/scenarios/wizard', validPayload({
      databases: [], db_instances: [],
      vms: [{ ref: 'vm-ap1', name: 'ap-1', vm_type: 'ap_host', site_ref: 's1', cpu: 4, mem_gb: 8, function_name: 'erp' }],
    }));
    assert.equal(res.status, 201, res.raw);
    assert.equal(colVal(insertsInto('cap_vms')[0], 'function_name'), 'erp');
  });

  it('a present-column schema names function_name as before (no regression)', async () => {
    const res = await request('POST', '/capacity/scenarios/wizard', validPayload({
      databases: [], db_instances: [],
      vms: [{ ref: 'vm-ap1', name: 'ap-1', vm_type: 'ap_host', site_ref: 's1', cpu: 4, mem_gb: 8, function_name: 'erp' }],
    }));
    assert.equal(res.status, 201, res.raw);
    assert.equal(colVal(insertsInto('cap_vms')[0], 'function_name'), 'erp');
  });
});

// ── F2 (review round-2 finding): write-side degraded-schema guard on the
// cap_databases INSERT's standby_node_count column ──────────────────────────
// standby_node_count is a NEW column (this task) named UNCONDITIONALLY in the
// INSERT, unlike its sibling cap_vms.function_name above — a warn-skipped
// add-column migration used to 500 EVERY scenario create (not just a
// rac_multinode_standby one, since this is one INSERT statement per database row).
// Hoisted to module scope (not just the F2 describe block below) so the X3
// describe block further down can reuse the SAME rac_multinode_standby fixture shape.
function racStandbyWizardPayload() {
  return validPayload({
    databases: [{ ref: 'd1', function_name: 'orcl', topology: 'rac_multinode_standby', node_count: 3, standby_node_count: 2 }],
    vms: [
      { ref: 'p1', name: 'orcl-db-1', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1' },
      { ref: 'p2', name: 'orcl-db-2', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1' },
      { ref: 'p3', name: 'orcl-db-3', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1' },
      { ref: 'sb1', name: 'orcl-db-4', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1' },
      { ref: 'sb2', name: 'orcl-db-5', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1' },
    ],
    db_instances: [
      { name: 'orcl1', vm_ref: 'p1', database_ref: 'd1', role: 'primary' },
      { name: 'orcl2', vm_ref: 'p2', database_ref: 'd1', role: 'primary' },
      { name: 'orcl3', vm_ref: 'p3', database_ref: 'd1', role: 'primary' },
      { name: 'orcl1', vm_ref: 'sb1', database_ref: 'd1', role: 'standby' },
      { name: 'orcl2', vm_ref: 'sb2', database_ref: 'd1', role: 'standby' },
    ],
  });
}

// H1 (round 1 review): the BASE rac_multinode member, no standby half —
// exercises the guard's other branch (ENUM-only, no standby_node_count column
// requirement).
function racMultinodeWizardPayload() {
  return validPayload({
    databases: [{ ref: 'd1', function_name: 'orcl', topology: 'rac_multinode', node_count: 2 }],
    vms: [
      { ref: 'p1', name: 'orcl-db-1', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1' },
      { ref: 'p2', name: 'orcl-db-2', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1' },
    ],
    db_instances: [
      { name: 'orcl1', vm_ref: 'p1', database_ref: 'd1', role: 'primary' },
      { name: 'orcl2', vm_ref: 'p2', database_ref: 'd1', role: 'primary' },
    ],
  });
}

describe('F2: degrades the cap_databases INSERT when standby_node_count is physically absent', () => {
  const racStandbyPayload = racStandbyWizardPayload;

  // X3 supersedes this scenario for a rac_multinode_standby row: with the schema-
  // capability gate in place, a rac_multinode_standby submission on a schema missing the
  // standby_node_count COLUMN is now rejected upfront (409) rather than
  // silently degrading via column omission — see the X3 describe block below.
  // The column-omission mechanic itself is still exercised by the
  // NON-rac_multinode_standby test right below (X3 never gates those).
  it('a degraded schema does not regress a NON-rac_multinode_standby (single) database create', async () => {
    // Every scenario create probes cap_databases now, not just a rac_multinode_standby
    // one — this proves a degraded schema never blocks the common case.
    state.databasesColumns = FULL_DATABASES_COLUMNS.filter((c) => c !== 'standby_node_count');
    const res = await request('POST', '/capacity/scenarios/wizard', validPayload());
    assert.equal(res.status, 201, res.raw);
    assert.equal(state.committed, 1);
  });

  it('the id fail-safe: an empty/odd probe (no id column) assumes present and still names the column', async () => {
    state.databasesColumns = []; // empty probe → fail-safe → assume present
    const res = await request('POST', '/capacity/scenarios/wizard', racStandbyPayload());
    assert.equal(res.status, 201, res.raw);
    assert.equal(colVal(insertsInto('cap_databases')[0], 'standby_node_count'), 2);
  });

  it('a present-column schema names standby_node_count as before (no regression)', async () => {
    const res = await request('POST', '/capacity/scenarios/wizard', racStandbyPayload());
    assert.equal(res.status, 201, res.raw);
    assert.equal(colVal(insertsInto('cap_databases')[0], 'standby_node_count'), 2);
  });
});

// X3 (Codex round 2, P2 — degraded-schema family, F2 was member 1): F2's
// per-column INSERT omission alone does not stop a rac_multinode_standby row from
// reaching the INSERT on a schema whose `topology` ENUM is still narrow (a
// SEPARATE migration step from the standby_node_count column add) — MariaDB
// rejects the ENUM value itself, an opaque 500. This gate rejects
// topology=rac_multinode_standby with a clean 4xx (409) at validation time, before any
// INSERT, whenever EITHER half of "does the schema support rac_multinode_standby" is
// missing (narrow enum OR absent column) — never reaching MariaDB's own error.
describe('X3: rejects rac_multinode_standby with a clean 4xx when the schema does not support it', () => {
  it('narrow topology ENUM (not yet widened) -> 409, nothing written', async () => {
    state.topologyEnumRenamed = false;
    const res = await request('POST', '/capacity/scenarios/wizard', racStandbyWizardPayload());
    assert.equal(res.status, 409, res.raw);
    assert.equal(res.json.error.code, 'TOPOLOGY_SCHEMA_UNSUPPORTED');
    assert.equal(anyEntityInsert(), false, 'nothing must be written');
    assert.equal(state.committed, 0);
  });

  it('standby_node_count column absent (enum widened) -> 409, nothing written', async () => {
    // The column-only degradation used to be silently handled by F2's per-row
    // omission (see the superseded F2 test above) — X3 unifies the class:
    // rac_multinode_standby is either FULLY supported or cleanly rejected, never
    // partially degraded (a partial write could never round-trip an explicit
    // S override the operator asked for).
    state.databasesColumns = FULL_DATABASES_COLUMNS.filter((c) => c !== 'standby_node_count');
    const res = await request('POST', '/capacity/scenarios/wizard', racStandbyWizardPayload());
    assert.equal(res.status, 409, res.raw);
    assert.equal(res.json.error.code, 'TOPOLOGY_SCHEMA_UNSUPPORTED');
    assert.equal(anyEntityInsert(), false);
  });

  it('both narrow enum AND absent column -> still one clean 409, not a 500', async () => {
    state.topologyEnumRenamed = false;
    state.databasesColumns = FULL_DATABASES_COLUMNS.filter((c) => c !== 'standby_node_count');
    const res = await request('POST', '/capacity/scenarios/wizard', racStandbyWizardPayload());
    assert.equal(res.status, 409, res.raw);
    assert.equal(res.json.error.code, 'TOPOLOGY_SCHEMA_UNSUPPORTED');
  });

  it('a full schema (enum widened AND column present) is unchanged -> 201', async () => {
    const res = await request('POST', '/capacity/scenarios/wizard', racStandbyWizardPayload());
    assert.equal(res.status, 201, res.raw);
    assert.equal(colVal(insertsInto('cap_databases')[0], 'standby_node_count'), 2);
  });

  it('a narrow enum never blocks a NON-rac_multinode_standby create (the gate is topology-scoped)', async () => {
    state.topologyEnumRenamed = false;
    const res = await request('POST', '/capacity/scenarios/wizard', validPayload());
    assert.equal(res.status, 201, res.raw);
    assert.equal(state.committed, 1);
  });
});

// H1 (round 1 review): the base rac_multinode member is EQUALLY exposed
// to the narrow-ENUM gap — a no-DDL-privilege deployment that skipped the rename
// migration must reject a plain RAC multi-node create the same clean way it
// already rejects a +Standby one, not 500 on MariaDB's own ENUM domain check.
describe('H1: rejects rac_multinode (base, no standby) with a clean 4xx when the schema does not support it', () => {
  it('narrow topology ENUM (not yet renamed) -> 409, nothing written', async () => {
    state.topologyEnumRenamed = false;
    const res = await request('POST', '/capacity/scenarios/wizard', racMultinodeWizardPayload());
    assert.equal(res.status, 409, res.raw);
    assert.equal(res.json.error.code, 'TOPOLOGY_SCHEMA_UNSUPPORTED');
    assert.equal(anyEntityInsert(), false, 'nothing must be written');
    assert.equal(state.committed, 0);
  });

  it('a renamed schema is unchanged -> 201 (base value needs no standby_node_count column)', async () => {
    const res = await request('POST', '/capacity/scenarios/wizard', racMultinodeWizardPayload());
    assert.equal(res.status, 201, res.raw);
    assert.equal(state.committed, 1);
  });

  it('absent standby_node_count column alone never blocks the base value (no standby half to gate)', async () => {
    state.databasesColumns = FULL_DATABASES_COLUMNS.filter((c) => c !== 'standby_node_count');
    const res = await request('POST', '/capacity/scenarios/wizard', racMultinodeWizardPayload());
    assert.equal(res.status, 201, res.raw);
    assert.equal(state.committed, 1);
  });
});

describe('TA.1: wizard derives persisted SGA server-side', () => {
  it('a primary DB instance defaults SGA to its database profile SGA cap', async () => {
    state.profileClass = 'DB';
    state.profiles['a4979cf3-c3ff-408a-8922-609bfcee749c'] = { class: 'DB', mode: 'formula', cpu: 16, mem_gb: null, sga_cap_gb: null, allowed_disk_combos: null };
    const res = await request('POST', '/capacity/scenarios/wizard', validPayload({
      databases: [{ ref: 'd1', function_name: 'erp', topology: 'single', profile_id: 'a4979cf3-c3ff-408a-8922-609bfcee749c' }],
      vms: [
        { ref: 'vm-db1', name: 'erp-db-1', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1', sizing_profile_id: 'a4979cf3-c3ff-408a-8922-609bfcee749c' },
        { ref: 'vm-ap1', name: 'erp-ap-1', vm_type: 'ap_host', site_ref: 's1' },
      ],
      db_instances: [{ name: 'erp1', vm_ref: 'vm-db1', database_ref: 'd1', role: 'primary' }],
    }));
    assert.equal(res.status, 201, res.raw);
    // sga cap = floor(mem × factor / divisor − subtract) = floor(320 × 0.982 / 2 − 2) = 155.
    assert.equal(colVal(insertsInto('cap_db_instances')[0], 'sga_gb'), 155);
  });

  it('a per-instance client-supplied sga_gb is ignored — the derived value always wins (spec §4.3 B5)', async () => {
    state.profileClass = 'DB';
    state.profiles['a4979cf3-c3ff-408a-8922-609bfcee749c'] = { class: 'DB', mode: 'formula', cpu: 16, mem_gb: null, sga_cap_gb: null, allowed_disk_combos: null };
    const res = await request('POST', '/capacity/scenarios/wizard', validPayload({
      databases: [{ ref: 'd1', function_name: 'erp', topology: 'single', profile_id: 'a4979cf3-c3ff-408a-8922-609bfcee749c' }],
      vms: [
        { ref: 'vm-db1', name: 'erp-db-1', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1', sizing_profile_id: 'a4979cf3-c3ff-408a-8922-609bfcee749c' },
        { ref: 'vm-ap1', name: 'erp-ap-1', vm_type: 'ap_host', site_ref: 's1' },
      ],
      db_instances: [{ name: 'erp1', vm_ref: 'vm-db1', database_ref: 'd1', role: 'primary', sga_gb: 42 }],
    }));
    assert.equal(res.status, 201, res.raw);
    assert.equal(colVal(insertsInto('cap_db_instances')[0], 'sga_gb'), 155, 'derived profile cap, NOT the client-supplied 42');
  });

  it('uses NON-default global settings formula constants (settings-read path, not the fallback)', async () => {
    state.profileClass = 'DB';
    state.profiles['a4979cf3-c3ff-408a-8922-609bfcee749c'] = { class: 'DB', mode: 'formula', cpu: 16, mem_gb: null, sga_cap_gb: null, allowed_disk_combos: null };
    // Non-default constants: mem = cpu × 10 (not × 20); sga = floor(mem × 0.9 / 3 − 1).
    state.settingsRow = { mem_cpu_ratio: 10, sga_factor: 0.9, sga_divisor: 3, sga_subtract: 1 };
    const res = await request('POST', '/capacity/scenarios/wizard', validPayload({
      databases: [{ ref: 'd1', function_name: 'erp', topology: 'single', profile_id: 'a4979cf3-c3ff-408a-8922-609bfcee749c' }],
      vms: [
        { ref: 'vm-db1', name: 'erp-db-1', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1', sizing_profile_id: 'a4979cf3-c3ff-408a-8922-609bfcee749c' },
        { ref: 'vm-ap1', name: 'erp-ap-1', vm_type: 'ap_host', site_ref: 's1' },
      ],
      db_instances: [{ name: 'erp1', vm_ref: 'vm-db1', database_ref: 'd1', role: 'primary' }],
    }));
    assert.equal(res.status, 201, res.raw);
    const vm = insertsInto('cap_vms').find((q) => colVal(q, 'sizing_profile_id') === 'a4979cf3-c3ff-408a-8922-609bfcee749c');
    assert.equal(colVal(vm, 'mem_gb'), 160, 'mem = cpu × 10 (non-default ratio), not 320');
    assert.equal(colVal(insertsInto('cap_db_instances')[0], 'sga_gb'), 47, 'sga = floor(160 × 0.9 / 3 − 1) = 47');
  });

  it('a standby instance defaults SGA to the scenario-effective standby setting, NOT its primary (mirroring removed, spec §4.3 B5)', async () => {
    state.profileClass = 'DB';
    state.profiles['a4979cf3-c3ff-408a-8922-609bfcee749c'] = { class: 'DB', mode: 'formula', cpu: 16, mem_gb: null, sga_cap_gb: null, allowed_disk_combos: null };
    const res = await request('POST', '/capacity/scenarios/wizard', validPayload({
      databases: [{ ref: 'd1', function_name: 'mes', topology: 'primary_standby', profile_id: 'a4979cf3-c3ff-408a-8922-609bfcee749c' }],
      vms: [
        { ref: 'p1', name: 'mes-db-1', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1', sizing_profile_id: 'a4979cf3-c3ff-408a-8922-609bfcee749c' },
        { ref: 'p2', name: 'mes-db-2', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1', sizing_profile_id: 'a4979cf3-c3ff-408a-8922-609bfcee749c' },
        { ref: 'sb1', name: 'mes-db-3', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1', sizing_profile_id: 'a4979cf3-c3ff-408a-8922-609bfcee749c' },
        { ref: 'sb2', name: 'mes-db-4', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1', sizing_profile_id: 'a4979cf3-c3ff-408a-8922-609bfcee749c' },
      ],
      db_instances: [
        { name: 'mes1', vm_ref: 'p1', database_ref: 'd1', role: 'primary' },
        { name: 'mes2', vm_ref: 'p2', database_ref: 'd1', role: 'primary' },
        { name: 'mes1', vm_ref: 'sb1', database_ref: 'd1', role: 'standby' },
        { name: 'mes2', vm_ref: 'sb2', database_ref: 'd1', role: 'standby' },
      ],
    }));
    assert.equal(res.status, 201, res.raw);
    const find = (role, name) => insertsInto('cap_db_instances')
      .find((q) => colVal(q, 'role') === role && colVal(q, 'name') === name);
    assert.equal(colVal(find('primary', 'mes1'), 'sga_gb'), 155, 'primary defaults to the profile cap');
    assert.equal(colVal(find('primary', 'mes2'), 'sga_gb'), 155);
    assert.equal(colVal(find('standby', 'mes1'), 'sga_gb'), 32, 'standby falls to the DB seed default (no cap_settings row in this fixture) — NOT its primary\'s 155');
    assert.equal(colVal(find('standby', 'mes2'), 'sga_gb'), 32);
  });

  it('a standby SGA no longer mirrors its primary — both derive independently even when the primary is hand-tuned (mirroring removed, spec §4.3 B5)', async () => {
    state.profileClass = 'DB';
    state.profiles['a4979cf3-c3ff-408a-8922-609bfcee749c'] = { class: 'DB', mode: 'formula', cpu: 16, mem_gb: null, sga_cap_gb: null, allowed_disk_combos: null };
    const res = await request('POST', '/capacity/scenarios/wizard', validPayload({
      databases: [{ ref: 'd1', function_name: 'mes', topology: 'primary_standby', profile_id: 'a4979cf3-c3ff-408a-8922-609bfcee749c' }],
      vms: [
        { ref: 'p1', name: 'mes-db-1', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1', sizing_profile_id: 'a4979cf3-c3ff-408a-8922-609bfcee749c' },
        { ref: 'p2', name: 'mes-db-2', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1', sizing_profile_id: 'a4979cf3-c3ff-408a-8922-609bfcee749c' },
        { ref: 'sb1', name: 'mes-db-3', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1', sizing_profile_id: 'a4979cf3-c3ff-408a-8922-609bfcee749c' },
        { ref: 'sb2', name: 'mes-db-4', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1', sizing_profile_id: 'a4979cf3-c3ff-408a-8922-609bfcee749c' },
      ],
      db_instances: [
        { name: 'mes1', vm_ref: 'p1', database_ref: 'd1', role: 'primary', sga_gb: 42 }, // legacy client value — now ignored
        { name: 'mes2', vm_ref: 'p2', database_ref: 'd1', role: 'primary' },
        { name: 'mes1', vm_ref: 'sb1', database_ref: 'd1', role: 'standby' },            // must NOT inherit 42 anymore
        { name: 'mes2', vm_ref: 'sb2', database_ref: 'd1', role: 'standby' },
      ],
    }));
    assert.equal(res.status, 201, res.raw);
    const find = (role, name) => insertsInto('cap_db_instances')
      .find((q) => colVal(q, 'role') === role && colVal(q, 'name') === name);
    assert.equal(colVal(find('primary', 'mes1'), 'sga_gb'), 155, 'the legacy client sga_gb (42) is ignored — derived profile cap wins');
    assert.equal(colVal(find('primary', 'mes2'), 'sga_gb'), 155);
    assert.equal(colVal(find('standby', 'mes1'), 'sga_gb'), 32, 'standby falls to the default — no more mirroring its (now-irrelevant) primary override');
    assert.equal(colVal(find('standby', 'mes2'), 'sga_gb'), 32);
  });

  it('a client-supplied standby sga_gb is ignored too — every instance sga_gb is server-derived (spec §4.3 B5)', async () => {
    state.profileClass = 'DB';
    state.profiles['a4979cf3-c3ff-408a-8922-609bfcee749c'] = { class: 'DB', mode: 'formula', cpu: 16, mem_gb: null, sga_cap_gb: null, allowed_disk_combos: null };
    const res = await request('POST', '/capacity/scenarios/wizard', validPayload({
      databases: [{ ref: 'd1', function_name: 'mes', topology: 'primary_standby', profile_id: 'a4979cf3-c3ff-408a-8922-609bfcee749c' }],
      vms: [
        { ref: 'p1', name: 'mes-db-1', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1', sizing_profile_id: 'a4979cf3-c3ff-408a-8922-609bfcee749c' },
        { ref: 'p2', name: 'mes-db-2', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1', sizing_profile_id: 'a4979cf3-c3ff-408a-8922-609bfcee749c' },
        { ref: 'sb1', name: 'mes-db-3', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1', sizing_profile_id: 'a4979cf3-c3ff-408a-8922-609bfcee749c' },
        { ref: 'sb2', name: 'mes-db-4', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1', sizing_profile_id: 'a4979cf3-c3ff-408a-8922-609bfcee749c' },
      ],
      db_instances: [
        { name: 'mes1', vm_ref: 'p1', database_ref: 'd1', role: 'primary', sga_gb: 42 },
        { name: 'mes2', vm_ref: 'p2', database_ref: 'd1', role: 'primary' },
        { name: 'mes1', vm_ref: 'sb1', database_ref: 'd1', role: 'standby', sga_gb: 7 },
        { name: 'mes2', vm_ref: 'sb2', database_ref: 'd1', role: 'standby' },
      ],
    }));
    assert.equal(res.status, 201, res.raw);
    const find = (role, name) => insertsInto('cap_db_instances')
      .find((q) => colVal(q, 'role') === role && colVal(q, 'name') === name);
    assert.equal(colVal(find('standby', 'mes1'), 'sga_gb'), 32, 'the client-supplied 7 is ignored — falls to the standby default');
    assert.equal(colVal(find('standby', 'mes2'), 'sga_gb'), 32);
  });

  it('a standby instance uses the scenario-effective cap_settings.standby_sga_default_gb when set (spec §4.3 B5/§6.3)', async () => {
    state.profileClass = 'DB';
    state.profiles['a4979cf3-c3ff-408a-8922-609bfcee749c'] = { class: 'DB', mode: 'formula', cpu: 16, mem_gb: null, sga_cap_gb: null, allowed_disk_combos: null };
    state.settingsRow = { mem_cpu_ratio: 20, sga_factor: 0.982, sga_divisor: 2, sga_subtract: 2, standby_sga_default_gb: 64 };
    const res = await request('POST', '/capacity/scenarios/wizard', validPayload({
      databases: [{ ref: 'd1', function_name: 'mes', topology: 'primary_standby', profile_id: 'a4979cf3-c3ff-408a-8922-609bfcee749c' }],
      vms: [
        { ref: 'p1', name: 'mes-db-1', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1', sizing_profile_id: 'a4979cf3-c3ff-408a-8922-609bfcee749c' },
        { ref: 'p2', name: 'mes-db-2', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1', sizing_profile_id: 'a4979cf3-c3ff-408a-8922-609bfcee749c' },
        { ref: 'sb1', name: 'mes-db-3', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1', sizing_profile_id: 'a4979cf3-c3ff-408a-8922-609bfcee749c' },
        { ref: 'sb2', name: 'mes-db-4', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1', sizing_profile_id: 'a4979cf3-c3ff-408a-8922-609bfcee749c' },
      ],
      db_instances: [
        { name: 'mes1', vm_ref: 'p1', database_ref: 'd1', role: 'primary' },
        { name: 'mes2', vm_ref: 'p2', database_ref: 'd1', role: 'primary' },
        { name: 'mes1', vm_ref: 'sb1', database_ref: 'd1', role: 'standby' },
        { name: 'mes2', vm_ref: 'sb2', database_ref: 'd1', role: 'standby' },
      ],
    }));
    assert.equal(res.status, 201, res.raw);
    const find = (role, name) => insertsInto('cap_db_instances')
      .find((q) => colVal(q, 'role') === role && colVal(q, 'name') === name);
    assert.equal(colVal(find('standby', 'mes1'), 'sga_gb'), 64, 'reads the scenario-effective standby default, not the 32 seed');
    assert.equal(colVal(find('standby', 'mes2'), 'sga_gb'), 64);
  });

  // ── C1: row-level SGA seeds persist + drive the derivation (spec §5.3/§6.3) ──
  it('persists the database-level primary_sga_gb/standby_sga_gb onto cap_databases (C1)', async () => {
    const res = await request('POST', '/capacity/scenarios/wizard', validPayload({
      databases: [{ ref: 'd1', function_name: 'erp', topology: 'single', primary_sga_gb: 96, standby_sga_gb: 48 }],
    }));
    assert.equal(res.status, 201, res.raw);
    const db = insertsInto('cap_databases')[0];
    assert.equal(colVal(db, 'primary_sga_gb'), 96);
    assert.equal(colVal(db, 'standby_sga_gb'), 48);
  });

  it('persists explicit nulls for the SGA seeds when unset (inheritance-semantic, not coalesced)', async () => {
    const res = await request('POST', '/capacity/scenarios/wizard', validPayload());
    assert.equal(res.status, 201, res.raw);
    const db = insertsInto('cap_databases')[0];
    assert.equal(colVal(db, 'primary_sga_gb'), null);
    assert.equal(colVal(db, 'standby_sga_gb'), null);
  });

  it('a database-level primary_sga_gb wins over the profile cap for the primary instance (C1)', async () => {
    state.profileClass = 'DB';
    state.profiles['a4979cf3-c3ff-408a-8922-609bfcee749c'] = { class: 'DB', mode: 'formula', cpu: 16, mem_gb: null, sga_cap_gb: null, allowed_disk_combos: null };
    const res = await request('POST', '/capacity/scenarios/wizard', validPayload({
      databases: [{ ref: 'd1', function_name: 'erp', topology: 'single', profile_id: 'a4979cf3-c3ff-408a-8922-609bfcee749c', primary_sga_gb: 200 }],
      vms: [
        { ref: 'vm-db1', name: 'erp-db-1', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1', sizing_profile_id: 'a4979cf3-c3ff-408a-8922-609bfcee749c' },
        { ref: 'vm-ap1', name: 'erp-ap-1', vm_type: 'ap_host', site_ref: 's1' },
      ],
      db_instances: [{ name: 'erp1', vm_ref: 'vm-db1', database_ref: 'd1', role: 'primary' }],
    }));
    assert.equal(res.status, 201, res.raw);
    assert.equal(colVal(insertsInto('cap_db_instances')[0], 'sga_gb'), 200, 'the row-level 200 wins over the derived profile cap 155');
  });

  it('a database-level standby_sga_gb wins over the scenario standby default for standby instances (C1)', async () => {
    state.settingsRow = { mem_cpu_ratio: 20, sga_factor: 0.982, sga_divisor: 2, sga_subtract: 2, standby_sga_default_gb: 64 };
    const res = await request('POST', '/capacity/scenarios/wizard', validPayload({
      databases: [{ ref: 'd1', function_name: 'mes', topology: 'primary_standby', standby_sga_gb: 111 }],
      vms: [
        { ref: 'p1', name: 'mes-db-1', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1' },
        { ref: 'p2', name: 'mes-db-2', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1' },
        { ref: 'sb1', name: 'mes-db-3', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1' },
        { ref: 'sb2', name: 'mes-db-4', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1' },
      ],
      db_instances: [
        { name: 'mes1', vm_ref: 'p1', database_ref: 'd1', role: 'primary' },
        { name: 'mes2', vm_ref: 'p2', database_ref: 'd1', role: 'primary' },
        { name: 'mes1', vm_ref: 'sb1', database_ref: 'd1', role: 'standby' },
        { name: 'mes2', vm_ref: 'sb2', database_ref: 'd1', role: 'standby' },
      ],
    }));
    assert.equal(res.status, 201, res.raw);
    const standby = insertsInto('cap_db_instances').filter((q) => colVal(q, 'role') === 'standby');
    assert.equal(standby.length, 2);
    assert.ok(standby.every((q) => colVal(q, 'sga_gb') === 111), 'the row-level 111 wins over the scenario default 64');
  });

  // ── C3: dc_refs restriction persists (mapped to minted site ids) ──
  it('persists dc_refs mapped from client site refs to the minted site ids (C3)', async () => {
    const res = await request('POST', '/capacity/scenarios/wizard', validPayload({
      sites: [{ ref: 's1', name: 'DC-A' }, { ref: 's2', name: 'DC-B' }],
      databases: [{ ref: 'd1', function_name: 'erp', topology: 'single', dc_refs: ['s1', 's2'] }],
    }));
    assert.equal(res.status, 201, res.raw);
    // The two site inserts mint the ids; dc_refs must reference THOSE ids, not the refs.
    const siteIdByName = new Map(insertsInto('cap_sites').map((q) => [colVal(q, 'name'), colVal(q, 'id')]));
    const db = insertsInto('cap_databases')[0];
    const stored = JSON.parse(colVal(db, 'dc_refs'));
    assert.deepEqual(stored, [siteIdByName.get('DC-A'), siteIdByName.get('DC-B')]);
  });

  it('persists dc_refs = NULL when unset (all DCs, inheritance-semantic)', async () => {
    const res = await request('POST', '/capacity/scenarios/wizard', validPayload());
    assert.equal(res.status, 201, res.raw);
    assert.equal(colVal(insertsInto('cap_databases')[0], 'dc_refs'), null);
  });

  it('buildWizardPlan rejects a dc_refs entry that does not resolve to a site (C3 validation)', () => {
    const out = buildWizardPlan(validPayload({
      databases: [{ ref: 'd1', function_name: 'erp', topology: 'single', dc_refs: ['s1', 'ghost'] }],
    }));
    assert.equal(out.ok, false);
    assert.match(out.errors.join('\n'), /dc_refs\[1\] does not match a site/);
  });

  it('buildWizardPlan rejects a non-array dc_refs (C3 validation)', () => {
    const out = buildWizardPlan(validPayload({
      databases: [{ ref: 'd1', function_name: 'erp', topology: 'single', dc_refs: 's1' }],
    }));
    assert.equal(out.ok, false);
    assert.match(out.errors.join('\n'), /dc_refs must be an array/);
  });

  it('buildWizardPlan rejects a negative primary_sga_gb (C1 validation)', () => {
    const out = buildWizardPlan(validPayload({
      databases: [{ ref: 'd1', function_name: 'erp', topology: 'single', primary_sga_gb: -1 }],
    }));
    assert.equal(out.ok, false);
    assert.match(out.errors.join('\n'), /primary_sga_gb must be a non-negative number/);
  });

  it('buildWizardPlan rejects a non-numeric standby_sga_gb (C1 validation)', () => {
    const out = buildWizardPlan(validPayload({
      databases: [{ ref: 'd1', function_name: 'erp', topology: 'single', standby_sga_gb: 'big' }],
    }));
    assert.equal(out.ok, false);
    assert.match(out.errors.join('\n'), /standby_sga_gb must be a non-negative number/);
  });

  it('warns when a referenced disk combo derives zero disk_gb (silent-zero guard)', async () => {
    state.combos['a9e90540-9d85-41d9-8179-ac172873d42c'] = []; // empty sizes → sum 0 (the silent-zero class)
    const warned = [];
    const origWarn = logger.warn;
    logger.warn = (obj) => { warned.push(obj); };
    try {
      const res = await request('POST', '/capacity/scenarios/wizard', validPayload({
        databases: [], db_instances: [],
        vms: [{ ref: 'vm-ap1', name: 'ap-1', vm_type: 'ap_host', site_ref: 's1', disk_combo_id: 'a9e90540-9d85-41d9-8179-ac172873d42c' }],
      }));
      assert.equal(res.status, 201, res.raw);
      assert.equal(colVal(insertsInto('cap_vms')[0], 'disk_gb'), 0, 'the 0 still persists (derivation unchanged)');
    } finally {
      logger.warn = origWarn;
    }
    assert.ok(
      warned.some((o) => o && o.combo_id === 'a9e90540-9d85-41d9-8179-ac172873d42c'),
      'a zero-derive warn identifying the combo was emitted',
    );
  });
});

// ── 4. TA.2: disk-combo allow-list enforcement on wizard create (spec §5.3) ─────
describe('TA.2: wizard disk-combo allow-list', () => {
  const profiledVmPayload = (extra) => validPayload({
    databases: [], db_instances: [],
    vms: [{ ref: 'vm-ap1', name: 'ap-1', vm_type: 'ap_host', site_ref: 's1', sizing_profile_id: '3e7ca1cb-cc56-4b15-8e27-83ed1e00b74d', disk_combo_id: 'd591e4cf-5f3f-4299-852c-5753e9a900e0', ...extra }],
  });

  it('accepts a VM whose combo is in the profile allow-list', async () => {
    state.profileClass = 'AP';
    state.profiles['3e7ca1cb-cc56-4b15-8e27-83ed1e00b74d'] = { class: 'AP', mode: 'formula', cpu: 8, mem_gb: null, sga_cap_gb: null, allowed_disk_combos: ['d591e4cf-5f3f-4299-852c-5753e9a900e0', 'a16fd8ad-525c-4ba2-8ebe-57f1e4d25a54'] };
    state.combos['d591e4cf-5f3f-4299-852c-5753e9a900e0'] = [512];
    const res = await request('POST', '/capacity/scenarios/wizard', profiledVmPayload());
    assert.equal(res.status, 201, res.raw);
    assert.equal(insertsInto('cap_vms').length, 1);
  });

  it('rejects a VM whose combo is NOT in the profile allow-list (400), nothing written', async () => {
    state.profileClass = 'AP';
    state.profiles['3e7ca1cb-cc56-4b15-8e27-83ed1e00b74d'] = { class: 'AP', mode: 'formula', cpu: 8, mem_gb: null, sga_cap_gb: null, allowed_disk_combos: ['a16fd8ad-525c-4ba2-8ebe-57f1e4d25a54'] };
    const res = await request('POST', '/capacity/scenarios/wizard', profiledVmPayload());
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'DISK_COMBO_NOT_ALLOWED');
    assert.equal(anyEntityInsert(), false);
    assert.equal(state.rolledBack, 1);
    assert.equal(state.committed, 0);
  });

  it('rejects a database whose combo is NOT in its profile allow-list (400)', async () => {
    state.profileClass = 'DB';
    state.profiles['a4979cf3-c3ff-408a-8922-609bfcee749c'] = { class: 'DB', mode: 'formula', cpu: 16, mem_gb: null, sga_cap_gb: null, allowed_disk_combos: ['88b82b69-a7ca-4093-8fca-c9675a81e9d7'] };
    const res = await request('POST', '/capacity/scenarios/wizard', validPayload({
      databases: [{ ref: 'd1', function_name: 'erp', topology: 'single', profile_id: 'a4979cf3-c3ff-408a-8922-609bfcee749c', disk_combo_id: 'b3e304da-29c6-4114-806d-8d345e557767' }],
      vms: [
        { ref: 'vm-db1', name: 'erp-db-1', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1', sizing_profile_id: 'a4979cf3-c3ff-408a-8922-609bfcee749c' },
        { ref: 'vm-ap1', name: 'erp-ap-1', vm_type: 'ap_host', site_ref: 's1' },
      ],
      db_instances: [{ name: 'erp1', vm_ref: 'vm-db1', database_ref: 'd1', role: 'primary' }],
    }));
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'DISK_COMBO_NOT_ALLOWED');
    assert.equal(anyEntityInsert(), false);
  });

  it('accepts a Custom (no-profile) VM carrying any disk combo', async () => {
    const res = await request('POST', '/capacity/scenarios/wizard', validPayload({
      databases: [], db_instances: [],
      vms: [{ ref: 'vm-ap1', name: 'ap-1', vm_type: 'ap_host', site_ref: 's1', disk_combo_id: 'a136b43f-473e-4de1-8923-98e6a869ae59' }],
    }));
    assert.equal(res.status, 201, res.raw);
    assert.equal(insertsInto('cap_vms').length, 1);
  });

  it('accepts when the profile has no allow-list defined (soft-list parity)', async () => {
    state.profileClass = 'AP';
    state.profiles['3e7ca1cb-cc56-4b15-8e27-83ed1e00b74d'] = { class: 'AP', mode: 'formula', cpu: 8, mem_gb: null, sga_cap_gb: null, allowed_disk_combos: null };
    const res = await request('POST', '/capacity/scenarios/wizard', profiledVmPayload());
    assert.equal(res.status, 201, res.raw);
    assert.equal(insertsInto('cap_vms').length, 1);
  });
});

// ── the wizard-create SGA seed is a whole number ────────────────────
//
// This is the ONLY guard on this path. The wizard's own grid floors the cell
// before it sends, so nothing in the browser reaches this branch — which is
// exactly why it needs a test of its own: the raw endpoint is reachable without
// the wizard, `cap_databases.primary_sga_gb` is a DOUBLE the schema never
// constrained, and this seed is copied into every derived instance sga_gb. With
// the guard deleted these payloads would be accepted and a fraction would be
// INSERTed, so the assertions below are on the write, not only on the status.
describe('POST /capacity/scenarios/wizard — SGA seeds are whole numbers', () => {
  const withSga = (seed) => validPayload({
    databases: [{ ref: 'd1', function_name: 'erp', topology: 'single', ...seed }],
  });

  it('refuses a fractional primary_sga_gb with 400 and writes nothing', async () => {
    const res = await request('POST', '/capacity/scenarios/wizard', withSga({ primary_sga_gb: 96.5 }));
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'BAD_REQUEST');
    assert.ok(
      res.json.error.details.some((d) => /primary_sga_gb must be a whole number/.test(d)),
      JSON.stringify(res.json.error.details),
    );
    assert.equal(anyEntityInsert(), false, 'the whole scenario is refused, not just the column');
    assert.equal(state.began, 0, 'refused before the transaction opens');
  });

  it('refuses a fractional standby_sga_gb the same way', async () => {
    const res = await request('POST', '/capacity/scenarios/wizard', validPayload({
      databases: [{ ref: 'd1', function_name: 'mes', topology: 'primary_standby', standby_sga_gb: 48.25 }],
      vms: [
        { ref: 'p1', name: 'mes-db-1', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1' },
        { ref: 'p2', name: 'mes-db-2', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1' },
        { ref: 'sb1', name: 'mes-db-3', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1' },
        { ref: 'sb2', name: 'mes-db-4', vm_type: 'db_host', site_ref: 's1', database_ref: 'd1' },
      ],
      db_instances: [
        { name: 'mes1', vm_ref: 'p1', database_ref: 'd1', role: 'primary' },
        { name: 'mes2', vm_ref: 'p2', database_ref: 'd1', role: 'primary' },
        { name: 'mes1', vm_ref: 'sb1', database_ref: 'd1', role: 'standby' },
        { name: 'mes2', vm_ref: 'sb2', database_ref: 'd1', role: 'standby' },
      ],
    }));
    assert.equal(res.status, 400, res.raw);
    assert.ok(
      res.json.error.details.some((d) => /standby_sga_gb must be a whole number/.test(d)),
      JSON.stringify(res.json.error.details),
    );
    assert.equal(anyEntityInsert(), false);
  });

  it('a whole seed is written to cap_databases unchanged', async () => {
    const res = await request('POST', '/capacity/scenarios/wizard', withSga({ primary_sga_gb: 96 }));
    assert.equal(res.status, 201, res.raw);
    assert.equal(colVal(insertsInto('cap_databases')[0], 'primary_sga_gb'), 96);
  });

  it('an absent seed still means "derive" — the guard did not turn null into a number', async () => {
    const res = await request('POST', '/capacity/scenarios/wizard', validPayload());
    assert.equal(res.status, 201, res.raw);
    assert.equal(colVal(insertsInto('cap_databases')[0], 'primary_sga_gb'), null);
    assert.equal(colVal(insertsInto('cap_databases')[0], 'standby_sga_gb'), null);
  });

  it('a negative seed keeps its own message — the whole-number branch did not swallow it', async () => {
    const res = await request('POST', '/capacity/scenarios/wizard', withSga({ primary_sga_gb: -5 }));
    assert.equal(res.status, 400, res.raw);
    assert.ok(
      res.json.error.details.some((d) => /primary_sga_gb must be a non-negative number/.test(d)),
      JSON.stringify(res.json.error.details),
    );
  });
});
