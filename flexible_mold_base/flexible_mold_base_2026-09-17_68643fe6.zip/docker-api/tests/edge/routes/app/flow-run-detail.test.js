// docker-api/tests/edge/routes/app/flow-run-detail.test.js
//
// One run in full: what it carries, what it deliberately does not, and the
// visibility rule it reads under — which has to be the SAME rule the list it was
// opened from used, or a run visible in the list would 404 when opened.
const { test } = require('node:test');
const assert = require('node:assert');
const express = require('express');

let issued = [];
let responder = () => [];

require.cache[require.resolve('../../../../src/edge/db')] = {
  exports: {
    pool: {
      ro: {
        getConnection: async () => ({
          query: async (sql, params) => {
            issued.push({ sql, params });
            const out = responder(sql, params);
            if (out instanceof Error) throw out;
            return out;
          },
          release: () => {},
        }),
      },
      rw: { getConnection: async () => ({ query: async () => [], release: () => {} }) },
    },
    t: (x) => x,
  },
};

const { router } = require('../../../../src/edge/routes/app/flow-recipe-runs/aggregate');
const { buildRunDetailSql } = require('../../../../src/edge/routes/app/flow-recipe-runs/run-queries');

function app(user) {
  const a = express();
  a.use(express.json());
  a.use((req, _res, next) => { if (user) req.user = user; next(); });
  a.use('/', router);
  return a;
}

async function get(a, path) {
  const server = a.listen(0);
  try {
    const { port } = server.address();
    const res = await fetch(`http://127.0.0.1:${port}${path}`);
    const json = await res.json().catch(() => ({}));
    return { status: res.status, json };
  } finally {
    // Closed on the throwing path too. With the close reachable only where
    // nothing threw, a failed assertion leaks this handle, the runner never
    // exits, and the job reports a timeout instead of the assertion that failed.
    server.close();
  }
}

const ADMIN = { id: 'aaaaaaaa-0000-0000-0000-000000000001', role: 'admin' };
const PLAIN = { id: 'bbbbbbbb-0000-0000-0000-000000000002', role: 'user' };
const RUN = 'cccccccc-0000-0000-0000-000000000003';

function detailRow(over) {
  return {
    id: RUN,
    recipe_id: 'dddddddd-0000-0000-0000-000000000004',
    recipe_name: 'Submit build',
    template_id: 'eeeeeeee-0000-0000-0000-000000000005',
    blueprint_id: 'ffffffff-0000-0000-0000-000000000006',
    actor_id: PLAIN.id,
    mode: 'create',
    code_version: 3,
    status: 'success',
    result_link: 'https://example.invalid/run/1',
    external_flow_id: 'X-1',
    error_summary: null,
    started_at: '2026-07-20 09:30:00',
    finished_at: '2026-07-20 09:30:12',
    created_at: '2026-07-20 09:30:00',
    rendered_payload: '{"size":"10"}',
    output_snapshot: '{"text":"out"}',
    step_results: null,
    input_snapshot: JSON.stringify({
      entered: { size: '10' }, computed: {}, fields: {}, blueprint_id: null, variant_id: null,
    }),
    remote_refs: { tasks: [{ id: 't1' }] },
    ...over,
  };
}

// remote_refs is a LATER additive column than code_version/input_snapshot
// (three-tier readRunDetail): the widest query names all three, a middle tier
// names code_version/input_snapshot but not remote_refs, and the narrowest
// names none of them. `failRemoteRefsOnly` pins the middle tier — a DB that
// warn-skipped only the newest ALTER must not lose the two older columns too.
function stub({
  rows = [], users = [], failAdditive = false, failRemoteRefsOnly = false,
} = {}) {
  return (sql) => {
    if (sql.includes('SELECT id, display_name, kc_username')) return users;
    if (sql.includes('remote_refs')) {
      if (failAdditive || failRemoteRefsOnly) {
        const e = new Error("Unknown column 'remote_refs'");
        e.errno = 1054;
        return e;
      }
      return rows;
    }
    if (sql.includes('input_snapshot')) {
      if (failAdditive) {
        const e = new Error("Unknown column 'input_snapshot'");
        e.errno = 1054;
        return e;
      }
      // Middle tier: code_version/input_snapshot present, remote_refs absent.
      return rows.map((row) => {
        const copy = { ...row };
        delete copy.remote_refs;
        return copy;
      });
    }
    if (sql.includes('FROM `flow_recipe_runs`')) {
      return rows.map((row) => {
        const copy = { ...row };
        delete copy.input_snapshot;
        delete copy.code_version;
        delete copy.remote_refs;
        return copy;
      });
    }
    return [];
  };
}

test.beforeEach(() => { issued = []; responder = stub(); });

test('a run carries its execution detail, its payload and its outputs', async () => {
  responder = stub({
    rows: [detailRow()],
    users: [{ id: PLAIN.id, display_name: 'Ada', kc_username: 'ada' }],
  });
  const { status, json } = await get(app(ADMIN), `/runs/${RUN}`);
  assert.strictEqual(status, 200);
  assert.strictEqual(json.data.recipe_name, 'Submit build');
  assert.strictEqual(json.data.mode, 'create');
  assert.strictEqual(json.data.code_version, 3);
  assert.strictEqual(json.data.actor_name, 'Ada');
  assert.strictEqual(json.data.rendered_payload, '{"size":"10"}');
  assert.strictEqual(json.data.output_snapshot, '{"text":"out"}');
  // Timestamps arrive pinned to UTC, not in the driver's spelling.
  assert.strictEqual(json.data.started_at, '2026-07-20T09:30:00Z');
});

test('the recorded answers are reported as a state, and never returned', async () => {
  responder = stub({ rows: [detailRow()] });
  const { json } = await get(app(ADMIN), `/runs/${RUN}`);
  assert.strictEqual(json.data.input_capture, 'captured');
  assert.ok(!('input_snapshot' in json.data));
});

test('a run whose capture was dropped is not reported as one that recorded nothing', async () => {
  responder = stub({
    rows: [detailRow({ input_snapshot: JSON.stringify({ not_captured: 'too_large' }) })],
  });
  const { json } = await get(app(ADMIN), `/runs/${RUN}`);
  assert.strictEqual(json.data.input_capture, 'dropped');
});

test('a run recorded before the column existed reports nothing recorded', async () => {
  responder = stub({ rows: [detailRow({ input_snapshot: null })] });
  const { json } = await get(app(ADMIN), `/runs/${RUN}`);
  assert.strictEqual(json.data.input_capture, 'absent');
});

test('a database without the additive columns still serves the run', async () => {
  responder = stub({ rows: [detailRow()], failAdditive: true });
  const { status, json } = await get(app(ADMIN), `/runs/${RUN}`);
  assert.strictEqual(status, 200);
  assert.strictEqual(json.data.input_capture, 'absent');
  assert.strictEqual(json.data.id, RUN);
});

test('a database missing ONLY remote_refs still serves code_version and input_capture', async () => {
  responder = stub({ rows: [detailRow()], failRemoteRefsOnly: true });
  const { status, json } = await get(app(ADMIN), `/runs/${RUN}`);
  assert.strictEqual(status, 200);
  assert.strictEqual(json.data.code_version, 3, 'code_version must survive a remote_refs-only 1054');
  assert.strictEqual(json.data.input_capture, 'captured', 'input_snapshot must survive a remote_refs-only 1054');
  assert.strictEqual(json.data.remote_refs, null, 'remote_refs itself is absent on this tier');
});

test('the read carries the same rule as the list it was opened from', async () => {
  // Which is now no restriction at all: the detail binds the run id and nothing
  // else. It matters that this is the SAME rule rather than the same outcome —
  // the detail is built through the shared predicate, so a narrowing reaches the
  // detail and the list together and the two cannot disagree about what exists.
  responder = stub({ rows: [detailRow()] });
  await get(app(PLAIN), `/runs/${RUN}`);
  const [{ sql, params }] = issued;
  assert.ok(!/r\.`actor_id` = \?/.test(sql));
  assert.ok(!/hierarchy_nodes/.test(sql));
  assert.deepStrictEqual(params, [RUN]);
});

test('an administrator reads it the same way — the role decides nothing here', async () => {
  responder = stub({ rows: [detailRow()] });
  await get(app(ADMIN), `/runs/${RUN}`);
  const [{ sql, params }] = issued;
  assert.ok(!sql.includes('actor_id` = ?'));
  assert.deepStrictEqual(params, [RUN]);
});

// step_results crosses the boundary as RAW JSON TEXT, not a parsed
// object, so a 16+-digit integer survives the ENVELOPE round trip. This harness
// mocks the DB layer and hands the route a STRING, so it pins the route +
// envelope + client-parse hops GIVEN a string arrives — it is deliberately
// BLIND to whether the driver returns step_results as a string or as a
// pre-rounded object (autoJsonMap parses JSON columns). The CAST-presence
// assertion below and flow-run-step-results-precision-real-db.test.js are what
// pin the driver hop; this one must not be read as covering it.
test('step_results survives a 17-digit integer byte-exact through the envelope', async () => {
  const digits = '98765432109876543'; // 17 digits, above Number.MAX_SAFE_INTEGER
  const rawStepResults = `[{"external_ref":${digits}}]`;
  responder = stub({ rows: [detailRow({ step_results: rawStepResults })] });
  const { status, json } = await get(app(ADMIN), `/runs/${RUN}`);
  assert.strictEqual(status, 200);
  // Arrives as the raw JSON TEXT (a string), never a parsed array whose number
  // has already been rounded.
  assert.strictEqual(typeof json.data.step_results, 'string');
  assert.ok(
    json.data.step_results.includes(digits),
    `expected the exact digits ${digits} in ${json.data.step_results}`,
  );
  assert.strictEqual(json.data.step_results, rawStepResults);
});

// UX-3 (fmb-2168, D6/D7): readRunDetail never field-parses step_results (see
// the module doc above) — the new additive entry fields (sequence, skipped,
// skip_reason, merge_stats) therefore need no code change here, only this
// pin that the raw-text passthrough still carries them verbatim.
test('step_results with the UX-3 additive entry fields (sequence/skipped/skip_reason/merge_stats) survives verbatim', async () => {
  const rawStepResults = JSON.stringify([
    { step_id: 's1', step_name: 'a', ok: true, sequence: 1 },
    { step_id: 's2', step_name: 'b', ok: true, skipped: true, skip_reason: 'mode', sequence: 2 },
    { step_id: 's3', step_name: 'c', ok: true, sequence: 3, merge_stats: { matched: 4, unmatched: 0 } },
  ]);
  responder = stub({ rows: [detailRow({ step_results: rawStepResults })] });
  const { status, json } = await get(app(ADMIN), `/runs/${RUN}`);
  assert.strictEqual(status, 200);
  assert.strictEqual(json.data.step_results, rawStepResults);
});

// The mechanical tripwire for the driver hop that a mocked DB cannot exercise:
// the detail statement MUST cast step_results to CHAR so the mariadb driver
// returns a string instead of an autoJsonMap-parsed (pre-rounded) object.
// Removing the CAST goes red here without needing a database — the real-DB test
// proves the CAST actually preserves the digits on the live server.
test('the detail statement casts step_results to CHAR so the driver returns a string, both tiers', () => {
  for (const withAdditive of [true, false]) {
    const sql = buildRunDetailSql('', { withAdditive });
    assert.match(sql, /CAST\(r\.`step_results` AS CHAR\) AS step_results/,
      `withAdditive=${withAdditive}: step_results is not cast to CHAR`);
    // Exactly one reference to the column, and it is the cast one — a second,
    // bare `r.`step_results`` select would re-introduce the parsed-object hop.
    const refs = sql.match(/r\.`step_results`/g) || [];
    assert.equal(refs.length, 1,
      `withAdditive=${withAdditive}: expected one step_results reference, got ${refs.length}`);
  }
});

test('an absent step_results crosses the boundary as an empty string, not null', async () => {
  // Y-pattern (SDD §8.3): the column is nullable JSON while the FE interface
  // types it non-nullable string, so a NULL row coalesces to '' — one spelling
  // for the viewer's absence gate, matching result_link / error_summary here.
  responder = stub({ rows: [detailRow({ step_results: null })] });
  const { json } = await get(app(ADMIN), `/runs/${RUN}`);
  assert.strictEqual(json.data.step_results, '');
});

test('a run the caller may not read is absent, not refused', async () => {
  // "Not yours" over an id confirms the run exists.
  responder = stub({ rows: [] });
  const { status, json } = await get(app(PLAIN), `/runs/${RUN}`);
  assert.strictEqual(status, 404);
  assert.strictEqual(json.error.code, 'NOT_FOUND');
});

test('a segment that is not an identifier never reaches the database', async () => {
  const { status } = await get(app(ADMIN), '/runs/not-an-id');
  assert.strictEqual(status, 404);
  assert.strictEqual(issued.length, 0);
});

test('an unauthenticated caller is refused', async () => {
  const { status } = await get(app(null), `/runs/${RUN}`);
  assert.strictEqual(status, 401);
  assert.strictEqual(issued.length, 0);
});
