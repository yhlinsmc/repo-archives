/**
 * text-case-validate.test.js — VP-1 (fmb-2171): `text_case`'s write-boundary
 * type-scope gate. `isPayloadInconsistent` is the ONE function the custom PUT
 * (update) and the generic create's `serializeWrite` both call
 * (routes-blueprint-fields.js) — a unit test against the function itself
 * covers BOTH verbs, same reasoning as the boolean_config/choice_config
 * sibling gates' own tests.
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');

const { isPayloadInconsistent } = require('../../../../src/edge/routes/app/schema/routes-blueprint-fields');

describe('isPayloadInconsistent — text_case type-scope gate (create AND update)', () => {
  it('rejects text_case:"upper" on a number field', () => {
    const result = isPayloadInconsistent('number', { text_case: 'upper' });
    assert.equal(result.ok, false);
    assert.equal(result.code, 'INCONSISTENT_FIELD_PAYLOAD');
    assert.match(result.detail, /text_case/);
  });

  it('rejects text_case:"upper" on a select field', () => {
    const result = isPayloadInconsistent('select', { text_case: 'upper' });
    assert.equal(result.ok, false);
  });

  it('accepts text_case:"upper" on a text field', () => {
    assert.deepEqual(isPayloadInconsistent('text', { text_case: 'upper' }), { ok: true });
  });

  it('accepts text_case:"title" on a textarea field', () => {
    assert.deepEqual(isPayloadInconsistent('textarea', { text_case: 'title' }), { ok: true });
  });

  it('rejects an out-of-domain text_case value on any type', () => {
    const onText = isPayloadInconsistent('text', { text_case: 'sideways' });
    assert.equal(onText.ok, false);
    assert.equal(onText.code, 'INVALID_TEXT_CASE');

    const onNumber = isPayloadInconsistent('number', { text_case: 'sideways' });
    assert.equal(onNumber.ok, false);
    assert.equal(onNumber.code, 'INVALID_TEXT_CASE');
  });

  it('accepts null text_case on any field type', () => {
    assert.deepEqual(isPayloadInconsistent('number', { text_case: null }), { ok: true });
    assert.deepEqual(isPayloadInconsistent('text', { text_case: null }), { ok: true });
  });

  it('accepts text_case:"none" on any field type (the explicit unset spelling)', () => {
    assert.deepEqual(isPayloadInconsistent('number', { text_case: 'none' }), { ok: true });
    assert.deepEqual(isPayloadInconsistent('text', { text_case: 'none' }), { ok: true });
  });

  it('accepts an absent text_case key on any field type', () => {
    assert.deepEqual(isPayloadInconsistent('number', {}), { ok: true });
  });
});
