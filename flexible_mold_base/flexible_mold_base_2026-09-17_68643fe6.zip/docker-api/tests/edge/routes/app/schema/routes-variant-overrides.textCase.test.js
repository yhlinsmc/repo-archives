'use strict';

/**
 * routes-variant-overrides.textCase.test.js — VP-B (fmb-2173).
 *
 * The `text_case` override action carries a `CaseMode` in `override_value`
 * but writes no cell value, so it needs a DEDICATED value-domain gate
 * (`override_value ∈ CASE_MODES` AND the target field is free-text) rather
 * than `VALUE_WRITING_ACTIONS`/`checkBlueprintCellLock` (D4) — that gate
 * refuses a cell write over a blueprint lock, and a `text_case` override
 * must coexist with a lock, never be refused by it.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../../../../src/edge/db');

let conn;
function makeConn(scripts) {
  const queries = [];
  return {
    queries,
    async query(sql, params) {
      queries.push({ sql, params });
      for (const [matcher, response] of scripts) {
        if (matcher.test(sql)) {
          return typeof response === 'function' ? response(sql, params) : response;
        }
      }
      // Linked-blueprint guard probes — these fixtures model no linked blueprint.
      if (/SELECT parent_id FROM `fmb_hierarchy_nodes` WHERE id = \? AND node_type = 'variant'/.test(sql)) return [];
      if (/SELECT linked_blueprint_id FROM `fmb_hierarchy_nodes`\s+WHERE id = \? AND node_type = 'blueprint'/.test(sql)) return [];
      throw new Error(`Unmatched query: ${sql.slice(0, 160)}`);
    },
    release() {},
  };
}

const poolSpy = {
  rw: { async getConnection() { return conn; } },
  ro: { async getConnection() { return conn; } },
};

require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: poolSpy, t: (name) => `fmb_${name}`, getDynamicPool: async () => poolSpy },
};

const router = require('../../../../../src/edge/routes/app/schema');
const { VALUE_WRITING_ACTIONS } = require('../../../../../src/edge/lib/blueprint-cell-lock');

let server;
let port;

before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { req.user = { id: 'admin-1', role: 'admin' }; next(); });
  app.use('/edge/app/schema', router);
  await new Promise((resolve) => {
    server = app.listen(0, '127.0.0.1', () => { port = server.address().port; resolve(); });
  });
});

after(async () => {
  await new Promise((resolve) => server.close(resolve));
  delete require.cache[dbKey];
});

beforeEach(() => { conn = null; });

function request(method, path, body) {
  return new Promise((resolve, reject) => {
    const data = JSON.stringify(body);
    const r = http.request({
      method, host: '127.0.0.1', port, path,
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(data) },
    }, (res) => {
      let raw = '';
      res.on('data', (c) => { raw += c; });
      res.on('end', () => resolve({ status: res.statusCode, body: raw ? JSON.parse(raw) : null }));
    });
    r.on('error', reject);
    r.write(data);
    r.end();
  });
}
const post = (path, body) => request('POST', path, body);
const put = (path, body) => request('PUT', path, body);

const wrote = (queries, verb) => queries.some((q) => new RegExp(`^${verb} `, 'i').test(q.sql.trim()));

const COHERENCE_QUERY = /SELECT v\.parent_id AS variant_blueprint_id/i;
function fieldCtx(field_type) {
  return [{
    variant_blueprint_id: 'bp-1',
    variant_node_type: 'variant',
    field_blueprint_id: 'bp-1',
    blueprint_exists: 'bp-1',
    blueprint_owner_id: 'admin-1',
    field_type,
    // A whole-field blueprint lock, present on every fixture: proves a
    // `text_case` override is not refused by it (D4), since only
    // VALUE_WRITING_ACTIONS is ever checked against a blueprint lock and
    // `text_case` is deliberately not one of them.
    field_value_source: 'entered',
    is_required: false,
    retain_when_hidden: false,
  }];
}

// PUT's pre-read now also selects `override_value` (VP-B) so a PATCH-style
// PUT that changes only `action` is judged on the POST-STATE value, not on
// nothing. The exact column list is pinned in the shared
// fixture, not a `.*` gap that would still match a SELECT that silently
// dropped `override_value`.
const { PUT_PREREAD_QUERY: OLD_ROW_QUERY } = require('../../../../helpers/variant-override-preread');

function scripts({ ctx = fieldCtx('text'), storedRow = null } = {}) {
  return [
    [COHERENCE_QUERY, ctx],
    [OLD_ROW_QUERY, () => [storedRow ?? {
      id: 'vo-1', variant_id: 'v-1', field_id: 'f-1', action: 'lock', override_value: '',
    }]],
    [/^INSERT INTO `fmb_variant_overrides`/i, { affectedRows: 1 }],
    [/^UPDATE `fmb_variant_overrides`/i, { affectedRows: 1 }],
    [/^SELECT \* FROM `fmb_variant_overrides`/i,
      [{ id: 'vo-1', variant_id: 'v-1', field_id: 'f-1', action: 'text_case', override_value: 'upper' }]],
  ];
}

describe('D4 — text_case is exempt from VALUE_WRITING_ACTIONS', () => {
  it('the allowlist checkBlueprintCellLock gates on does not include text_case', () => {
    assert.equal(VALUE_WRITING_ACTIONS.includes('text_case'), false);
  });
});

describe('POST /variant_overrides — text_case value-domain gate', () => {
  it('accepts a valid CaseMode on a free-text field', async () => {
    conn = makeConn(scripts({ ctx: fieldCtx('text') }));
    const res = await post('/edge/app/schema/variant_overrides', {
      variant_id: 'v-1', field_id: 'f-1', action: 'text_case', override_value: 'upper',
    });
    assert.equal(res.status, 200);
    assert.equal(wrote(conn.queries, 'INSERT'), true);
  });

  it("accepts 'none' — the explicit release value", async () => {
    conn = makeConn(scripts({ ctx: fieldCtx('text') }));
    const res = await post('/edge/app/schema/variant_overrides', {
      variant_id: 'v-1', field_id: 'f-1', action: 'text_case', override_value: 'none',
    });
    assert.equal(res.status, 200);
  });

  it('refuses an override_value outside CASE_MODES', async () => {
    conn = makeConn(scripts({ ctx: fieldCtx('text') }));
    const res = await post('/edge/app/schema/variant_overrides', {
      variant_id: 'v-1', field_id: 'f-1', action: 'text_case', override_value: 'sideways',
    });
    assert.equal(res.status, 400);
    assert.equal(res.body.error.code, 'INVALID_TEXT_CASE');
    assert.equal(wrote(conn.queries, 'INSERT'), false);
  });

  it('refuses text_case on a non-free-text field (number)', async () => {
    conn = makeConn(scripts({ ctx: fieldCtx('number') }));
    const res = await post('/edge/app/schema/variant_overrides', {
      variant_id: 'v-1', field_id: 'f-1', action: 'text_case', override_value: 'upper',
    });
    assert.equal(res.status, 400);
    assert.equal(res.body.error.code, 'INVALID_TEXT_CASE');
    assert.equal(wrote(conn.queries, 'INSERT'), false);
  });

  it('an unknown action is still refused by the allowlist, unaffected by the new gate', async () => {
    conn = makeConn(scripts({ ctx: fieldCtx('text') }));
    const res = await post('/edge/app/schema/variant_overrides', {
      variant_id: 'v-1', field_id: 'f-1', action: 'sideways_action', override_value: 'upper',
    });
    assert.equal(res.status, 400);
    assert.equal(res.body.error.code, 'BAD_REQUEST');
  });

  it('a text_case override is not refused merely because the field is blueprint-locked (D4 — coexists with lock)', async () => {
    const ctx = fieldCtx('text');
    ctx[0].field_value_source = 'locked';
    conn = makeConn(scripts({ ctx }));
    const res = await post('/edge/app/schema/variant_overrides', {
      variant_id: 'v-1', field_id: 'f-1', action: 'text_case', override_value: 'title',
    });
    assert.equal(res.status, 200);
    assert.equal(wrote(conn.queries, 'INSERT'), true);
  });
});

describe('PUT /variant_overrides/:id — text_case value-domain gate', () => {
  it('accepts a valid CaseMode when action flips to text_case', async () => {
    conn = makeConn(scripts({
      ctx: fieldCtx('text'),
      storedRow: { id: 'vo-1', variant_id: 'v-1', field_id: 'f-1', action: 'lock', override_value: '' },
    }));
    const res = await put('/edge/app/schema/variant_overrides/vo-1', {
      action: 'text_case', override_value: 'lower',
    });
    assert.equal(res.status, 200);
    assert.equal(wrote(conn.queries, 'UPDATE'), true);
  });

  it('refuses an out-of-domain override_value', async () => {
    conn = makeConn(scripts({
      ctx: fieldCtx('text'),
      storedRow: { id: 'vo-1', variant_id: 'v-1', field_id: 'f-1', action: 'text_case', override_value: 'upper' },
    }));
    const res = await put('/edge/app/schema/variant_overrides/vo-1', { override_value: 'sideways' });
    assert.equal(res.status, 400);
    assert.equal(res.body.error.code, 'INVALID_TEXT_CASE');
    assert.equal(wrote(conn.queries, 'UPDATE'), false);
  });

  it('judges the POST-STATE override_value: an action-only PATCH inherits the stored value, and refuses it if invalid', async () => {
    // The stored row is a `lock` row whose `override_value` is '' (never a
    // valid CaseMode) — flipping only `action` to `text_case` without also
    // sending a fresh override_value must be judged on that inherited value,
    // not accepted on the strength of the action alone.
    conn = makeConn(scripts({
      ctx: fieldCtx('text'),
      storedRow: { id: 'vo-1', variant_id: 'v-1', field_id: 'f-1', action: 'lock', override_value: '' },
    }));
    const res = await put('/edge/app/schema/variant_overrides/vo-1', { action: 'text_case' });
    assert.equal(res.status, 400);
    assert.equal(res.body.error.code, 'INVALID_TEXT_CASE');
    assert.equal(wrote(conn.queries, 'UPDATE'), false);
  });

  it('refuses text_case on a non-free-text field (number)', async () => {
    conn = makeConn(scripts({
      ctx: fieldCtx('number'),
      storedRow: { id: 'vo-1', variant_id: 'v-1', field_id: 'f-1', action: 'lock', override_value: '' },
    }));
    const res = await put('/edge/app/schema/variant_overrides/vo-1', {
      action: 'text_case', override_value: 'upper',
    });
    assert.equal(res.status, 400);
    assert.equal(res.body.error.code, 'INVALID_TEXT_CASE');
  });

  // Moving AWAY from text_case with no fresh
  // override_value in the body must not leave the STORED casing mode
  // ('upper') persisted under the new action — an autofill row would
  // silently "autofill" the literal string 'upper'.
  it('clears the stale text_case override_value when the action moves to something else', async () => {
    conn = makeConn(scripts({
      ctx: fieldCtx('text'),
      storedRow: { id: 'vo-1', variant_id: 'v-1', field_id: 'f-1', action: 'text_case', override_value: 'upper' },
    }));
    const res = await put('/edge/app/schema/variant_overrides/vo-1', { action: 'autofill' });
    assert.equal(res.status, 200);
    const updateQuery = conn.queries.find((q) => /^UPDATE/i.test(q.sql.trim()));
    assert.ok(updateQuery, 'expected an UPDATE query');
    const setClauseColumns = [...updateQuery.sql.matchAll(/`(\w+)` = \?/g)].map((m) => m[1]);
    const overrideValueIndex = setClauseColumns.indexOf('override_value');
    assert.notEqual(overrideValueIndex, -1, 'override_value must be part of the SET clause');
    assert.equal(updateQuery.params[overrideValueIndex], '');
  });
});
