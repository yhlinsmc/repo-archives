/**
 * blueprint-fields-date-config.test.js — the `date` field type's
 * `date_config` write-boundary gate (mirrors the `boolean_config` type-scope
 * gate, minus the required-exclusion — a date has no when-empty concept) and
 * its export->import round-trip.
 *
 * `isPayloadInconsistent` is the ONE function the custom PUT (update) and the
 * generic create's `serializeWrite` both call (routes-blueprint-fields.js /
 * schema/index.js) — a unit test against the function itself covers BOTH
 * verbs, same reasoning blueprint-fields-boolean-config.test.js documents.
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');

const { isPayloadInconsistent } = require('../../../../../src/edge/routes/app/schema/routes-blueprint-fields');
const { fieldTypeViolation } = require('../../../../../src/edge/routes/app/schema/field-type-domain');
const serialization = require('../../../../../src/edge/lib/blueprint-serialization');
const { normalizeDateConfigForWrite } = require('../../../../../src/edge/lib/date-config-validate');

describe('isPayloadInconsistent — date_config type-scope gate (create AND update)', () => {
  it('rejects date_config on a text field', () => {
    const result = isPayloadInconsistent('text', { date_config: { format: 'DD/MM/YYYY' } });
    assert.equal(result.ok, false);
    assert.equal(result.code, 'INCONSISTENT_FIELD_PAYLOAD');
    assert.match(result.detail, /date_config/);
  });

  it('rejects a malformed date_config on a date field (not an object)', () => {
    const result = isPayloadInconsistent('date', { date_config: 'null' });
    assert.equal(result.ok, false);
    assert.equal(result.code, 'INCONSISTENT_FIELD_PAYLOAD');
  });

  it('rejects a date_config carrying an out-of-vocabulary format', () => {
    const result = isPayloadInconsistent('date', { date_config: { format: 'DD.MM.YYYY' } });
    assert.equal(result.ok, false);
  });

  it('rejects a date_config carrying an unknown key', () => {
    const result = isPayloadInconsistent('date', { date_config: { format: 'YYYY-MM-DD', extra: 1 } });
    assert.equal(result.ok, false);
  });

  it('accepts a date field with no date_config (the YYYY-MM-DD default)', () => {
    assert.deepEqual(isPayloadInconsistent('date', {}), { ok: true });
  });

  it('accepts a well-formed date_config on a date field', () => {
    assert.deepEqual(
      isPayloadInconsistent('date', { date_config: { format: 'DD/MM/YYYY' } }),
      { ok: true },
    );
  });

  it('accepts null date_config on a non-date field', () => {
    assert.deepEqual(isPayloadInconsistent('text', { date_config: null }), { ok: true });
  });

  it('accepts a date_config on a REQUIRED date field — no when-empty concept to exclude', () => {
    assert.deepEqual(
      isPayloadInconsistent('date', { is_required: true, date_config: { format: 'YYYY/MM/DD' } }),
      { ok: true },
    );
  });
});

describe('isPayloadInconsistent — date default_value domain', () => {
  it('rejects a date field whose default_value is not ISO', () => {
    const result = isPayloadInconsistent('date', { default_value: '15/09/2026' });
    assert.equal(result.ok, false);
    assert.equal(result.code, 'INCONSISTENT_FIELD_PAYLOAD');
    assert.match(result.detail, /default_value/);
  });

  it('rejects a date field whose default_value is a calendar-impossible ISO string', () => {
    const result = isPayloadInconsistent('date', { default_value: '2023-02-29' });
    assert.equal(result.ok, false);
  });

  it('accepts a date field with default_value "" (unset)', () => {
    assert.deepEqual(isPayloadInconsistent('date', { default_value: '' }), { ok: true });
  });

  it('accepts a date field with a valid ISO default_value', () => {
    assert.deepEqual(isPayloadInconsistent('date', { default_value: '2026-09-15' }), { ok: true });
  });

  it('accepts a date field with no default_value named (statement silent on the column)', () => {
    assert.deepEqual(isPayloadInconsistent('date', {}), { ok: true });
  });

  it('accepts a non-ISO default_value on a non-date field', () => {
    assert.deepEqual(isPayloadInconsistent('text', { default_value: '15/09/2026' }), { ok: true });
  });
});

describe('normalizeDateConfigForWrite — boundary collapse', () => {
  it('collapses the explicit default format to null', () => {
    assert.equal(normalizeDateConfigForWrite({ format: 'YYYY-MM-DD' }), null);
  });

  it('collapses an empty object to null (format is optional, so {} means the same default)', () => {
    assert.equal(normalizeDateConfigForWrite({}), null);
  });

  it('collapses null/undefined to null', () => {
    assert.equal(normalizeDateConfigForWrite(null), null);
    assert.equal(normalizeDateConfigForWrite(undefined), null);
  });

  it('collapses the explicit default already serialized as a JSON string', () => {
    assert.equal(normalizeDateConfigForWrite('{"format":"YYYY-MM-DD"}'), null);
  });

  it('leaves a non-default format untouched', () => {
    const cfg = { format: 'DD/MM/YYYY' };
    assert.equal(normalizeDateConfigForWrite(cfg), cfg);
  });

  it('leaves a malformed value untouched (shape validation, not this collapse, refuses it)', () => {
    assert.equal(normalizeDateConfigForWrite('not-json'), 'not-json');
    const malformed = { format: 'YYYY-MM-DD', extra: 1 };
    assert.equal(normalizeDateConfigForWrite(malformed), malformed);
  });
});

describe('fieldFingerprint — date_config null and the explicit default compare equal', () => {
  const base = {
    field_label: 'Start Date', field_type: 'date', is_required: 0, default_value: '',
    placeholder: '', tooltip: '', section: 'general', order_index: 0,
    table_config: null, visibility_rule: null, depends_on_field_key: null,
    retain_when_hidden: 0, choice_config: null, group_key: null, matrix_row_key: null,
    value_source: 'entered', value_scope: null, compute_rule: null, options_source: null,
    boolean_config: null, text_case: null,
  };

  it('a row with date_config: null and a row with the explicit default fingerprint identically', () => {
    const withNull = serialization.fieldFingerprint({ ...base, date_config: null });
    const withExplicitDefault = serialization.fieldFingerprint({ ...base, date_config: { format: 'YYYY-MM-DD' } });
    assert.equal(withNull, withExplicitDefault);
  });

  it('a genuinely different format still fingerprints as a change', () => {
    const withNull = serialization.fieldFingerprint({ ...base, date_config: null });
    const withOther = serialization.fieldFingerprint({ ...base, date_config: { format: 'DD/MM/YYYY' } });
    assert.notEqual(withNull, withOther);
  });
});

describe('field-type-domain — date is accepted', () => {
  it('fieldTypeViolation is null for a date field_type', () => {
    assert.equal(fieldTypeViolation({ field_type: 'date' }), null);
  });
});

describe('date_config export -> import round-trip', () => {
  function rawFixture(dateConfig, defaultValue = '') {
    return {
      import_version: 1,
      hierarchy_node: {
        id: 'bp-uuid-1', parent_id: 'release-uuid-1', name: 'BP',
        description: '', node_type: 'blueprint', sort_order: 0, is_active: 1,
        transformer_id: null, transformer_version: null, linked_blueprint_id: null,
      },
      blueprint_fields: [{
        id: 'fld-1', blueprint_id: 'bp-uuid-1', field_key: 'start_date', field_label: 'Start Date',
        field_type: 'date', is_required: 0, default_value: defaultValue, placeholder: '', tooltip: '',
        section: 'general', order_index: 0,
        table_config: null, choice_config: null, options_source: null, visibility_rule: null,
        value_scope: null, compute_rule: null, boolean_config: null,
        date_config: dateConfig != null ? JSON.stringify(dateConfig) : null,
      }],
      field_options: [],
      blueprint_sections: [],
      blueprint_output_order: [],
    };
  }

  it('a stored { format: "DD/MM/YYYY" } round-trips unchanged', () => {
    const parsed = serialization.parseYaml(serialization.serializeYaml(rawFixture({ format: 'DD/MM/YYYY' })));
    const field = parsed.blueprint_fields.find((f) => f.field_key === 'start_date');
    assert.deepEqual(JSON.parse(field.date_config), { format: 'DD/MM/YYYY' });
  });

  it('a null date_config (the YYYY-MM-DD default) round-trips as null', () => {
    const parsed = serialization.parseYaml(serialization.serializeYaml(rawFixture(null)));
    const field = parsed.blueprint_fields.find((f) => f.field_key === 'start_date');
    assert.equal(field.date_config, null);
  });

  it('an authored explicit default { format: "YYYY-MM-DD" } imports as null, not the literal object', () => {
    const parsed = serialization.parseYaml(serialization.serializeYaml(rawFixture({ format: 'YYYY-MM-DD' })));
    const field = parsed.blueprint_fields.find((f) => f.field_key === 'start_date');
    assert.equal(field.date_config, null);
  });

  it('a valid ISO default_value round-trips unchanged', () => {
    const parsed = serialization.parseYaml(serialization.serializeYaml(rawFixture(null, '2026-09-15')));
    const field = parsed.blueprint_fields.find((f) => f.field_key === 'start_date');
    assert.equal(field.default_value, '2026-09-15');
  });

  it('import rejects date_config on a non-date field', () => {
    const raw = rawFixture({ format: 'DD/MM/YYYY' });
    raw.blueprint_fields[0].field_type = 'text';
    assert.throws(
      () => serialization.parseYaml(serialization.serializeYaml(raw)),
      /date_config is only valid on a date field/,
    );
  });

  it('import rejects a malformed date_config on a date field', () => {
    const yamlText = [
      'import_version: 1',
      'blueprint:',
      '  name: BP',
      'fields:',
      '  - key: start_date',
      '    type: date',
      '    date_config:',
      '      format: DD.MM.YYYY',
    ].join('\n');
    assert.throws(
      () => serialization.parseYaml(yamlText),
      /date_config\.format must be one of/,
    );
  });

  it('import rejects a non-ISO default on a date field', () => {
    const yamlText = [
      'import_version: 1',
      'blueprint:',
      '  name: BP',
      'fields:',
      '  - key: start_date',
      '    type: date',
      '    default: 15/09/2026',
    ].join('\n');
    assert.throws(
      () => serialization.parseYaml(yamlText),
      /default_value must be an ISO YYYY-MM-DD date or empty/,
    );
  });

  it('import accepts a valid ISO/absent default on a date field', () => {
    for (const yamlText of [
      ['import_version: 1', 'blueprint:', '  name: BP', 'fields:', '  - key: start_date', '    type: date', '    default: "2026-09-15"'].join('\n'),
      ['import_version: 1', 'blueprint:', '  name: BP', 'fields:', '  - key: start_date', '    type: date'].join('\n'),
    ]) {
      assert.doesNotThrow(() => serialization.parseYaml(yamlText));
    }
  });
});
