/**
 * boolean-config-schema-parity.test.js — validates the new `boolean_config`
 * column against the ACTUAL table DDL and the migration registry, WITHOUT a
 * live DB. Mirrors capacity-delete-preview-schema-parity.test.js's approach
 * (parse table-ddls.js, assert against the parsed manifest) so a drift
 * between the DDL, the migration entry's `ddl` fragment, and the shared
 * JSON-columns list is caught here rather than at a real migration run.
 */
const { describe, it, before } = require('node:test');
const assert = require('node:assert/strict');

const { buildSchemaManifest, ddlFragmentFor } = require('../../../../../src/edge/lib/schema-manifest');
const { MIGRATION_STEPS, PLATFORM_SCHEMA_VERSION } = require('../../../../../src/edge/migration-steps');
const { BLUEPRINT_FIELDS_JSON_COLUMNS } = require('../../../../../src/edge/lib/blueprint-fields-json-columns');
const { TABLES } = require('../../../../../src/shared/constants');
// H2 (VP-A fix batch 1, fmb-2171): a lexical `>=` on version strings ranks
// "3.3.9" above "3.3.10" — reuse the shared numeric comparator, never a
// second hand-maintained copy of it.
const { compareVersions } = require('../../../../../src/edge/lib/schema-version-derive');

const TABLE = 'blueprint_fields';
const COLUMN = 'boolean_config';

let manifestEntry;

before(() => {
  manifestEntry = buildSchemaManifest((base) => base).get(TABLE);
});

describe('blueprint_fields.boolean_config schema parity', () => {
  it('table-ddls.js declares the column', () => {
    assert.ok(manifestEntry, `table-ddls.js declares no table '${TABLE}'`);
    assert.ok(manifestEntry.columns.includes(COLUMN), `${TABLE} is missing ${COLUMN}`);
  });

  it('the migration registry carries a matching add-column entry', () => {
    const entry = MIGRATION_STEPS.find(
      (s) => s.kind === 'add-column' && s.table === TABLES.BLUEPRINT_FIELDS && s.column === COLUMN,
    );
    assert.ok(entry, `no add-column migration entry for ${TABLE}.${COLUMN}`);
    const fragment = ddlFragmentFor(TABLE, COLUMN);
    assert.equal(
      fragment.replace(/\s+/g, ' ').trim(),
      entry.ddl.replace(/\s+/g, ' ').trim(),
      `registry ddl "${entry.ddl}" does not match table-ddls.js fragment "${fragment}"`,
    );
  });

  it('PLATFORM_SCHEMA_VERSION is at least the entry version that added this column', () => {
    const entry = MIGRATION_STEPS.find(
      (s) => s.kind === 'add-column' && s.table === TABLES.BLUEPRINT_FIELDS && s.column === COLUMN,
    );
    assert.ok(entry.version, 'entry carries no version');
    // WHY >=, not ===: the previous form was a self-referential ternary that
    // only ever passed because this entry happened to be the latest one at
    // the time it was written. A LATER entry (e.g. VP-1's text_case,
    // fmb-2171) advancing PLATFORM_SCHEMA_VERSION past this one is the
    // expected, permanent shape once a second migration ships — not a
    // regression this test should ever catch again.
    assert.ok(
      compareVersions(PLATFORM_SCHEMA_VERSION, entry.version) >= 0,
      `PLATFORM_SCHEMA_VERSION (${PLATFORM_SCHEMA_VERSION}) is behind this entry's version (${entry.version})`,
    );
  });

  it('boolean_config is on the shared JSON-columns list (export/import/dto-mapper serialization)', () => {
    assert.ok(
      BLUEPRINT_FIELDS_JSON_COLUMNS.includes(COLUMN),
      `${COLUMN} is JSON in table-ddls.js but missing from BLUEPRINT_FIELDS_JSON_COLUMNS`,
    );
  });
});
