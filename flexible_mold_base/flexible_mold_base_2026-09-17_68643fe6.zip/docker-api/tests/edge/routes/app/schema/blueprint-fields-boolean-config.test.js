/**
 * blueprint-fields-boolean-config.test.js — SB-E (fmb-2039): the boolean
 * tri-state field's `boolean_config` write-boundary gate (mirrors the
 * `choice_config` type-scope gate) and its export->import round-trip.
 *
 * `isPayloadInconsistent` is the ONE function the custom PUT (update) and the
 * generic create's `serializeWrite` both call (routes-blueprint-fields.js /
 * schema/index.js) — a unit test against the function itself covers BOTH
 * verbs, the same reasoning routes-blueprint-fields-table-config-options-
 * source.test.js documents for its own sibling gate.
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');

const { isPayloadInconsistent } = require('../../../../../src/edge/routes/app/schema/routes-blueprint-fields');
const { fieldTypeViolation } = require('../../../../../src/edge/routes/app/schema/field-type-domain');
const serialization = require('../../../../../src/edge/lib/blueprint-serialization');

describe('isPayloadInconsistent — boolean_config type-scope gate (create AND update)', () => {
  it('rejects boolean_config on a text field', () => {
    const result = isPayloadInconsistent('text', { boolean_config: { whenEmpty: 'null' } });
    assert.equal(result.ok, false);
    assert.equal(result.code, 'INCONSISTENT_FIELD_PAYLOAD');
    assert.match(result.detail, /boolean_config/);
  });

  it('rejects a malformed boolean_config on a boolean field (not an object)', () => {
    const result = isPayloadInconsistent('boolean', { boolean_config: 'null' });
    assert.equal(result.ok, false);
    assert.equal(result.code, 'INCONSISTENT_FIELD_PAYLOAD');
  });

  it('rejects a boolean_config carrying an unknown whenEmpty value', () => {
    const result = isPayloadInconsistent('boolean', { boolean_config: { whenEmpty: 'clear' } });
    assert.equal(result.ok, false);
  });

  it('accepts a boolean field with no boolean_config (the omit default)', () => {
    assert.deepEqual(isPayloadInconsistent('boolean', {}), { ok: true });
  });

  it('accepts a well-formed boolean_config on a boolean field', () => {
    assert.deepEqual(
      isPayloadInconsistent('boolean', { boolean_config: { whenEmpty: 'null' } }),
      { ok: true },
    );
  });

  it('accepts null boolean_config on a non-boolean field', () => {
    assert.deepEqual(isPayloadInconsistent('text', { boolean_config: null }), { ok: true });
  });
});

describe('isPayloadInconsistent — boolean_config × is_required:true (fix batch M1)', () => {
  it('rejects a boolean_config carried alongside is_required:true', () => {
    const result = isPayloadInconsistent('boolean', {
      is_required: true,
      boolean_config: { whenEmpty: 'null' },
    });
    assert.equal(result.ok, false);
    assert.equal(result.code, 'INCONSISTENT_FIELD_PAYLOAD');
  });

  it('accepts is_required:true with boolean_config explicitly nulled', () => {
    assert.deepEqual(
      isPayloadInconsistent('boolean', { is_required: true, boolean_config: null }),
      { ok: true },
    );
  });

  it('accepts a boolean_config on an OPTIONAL boolean (is_required:false)', () => {
    assert.deepEqual(
      isPayloadInconsistent('boolean', { is_required: false, boolean_config: { whenEmpty: 'null' } }),
      { ok: true },
    );
  });
});

describe('isPayloadInconsistent — boolean default_value domain (fix batch 2, P1a)', () => {
  it('rejects a boolean field whose default_value is free text', () => {
    const result = isPayloadInconsistent('boolean', { default_value: 'yes' });
    assert.equal(result.ok, false);
    assert.equal(result.code, 'INCONSISTENT_FIELD_PAYLOAD');
    assert.match(result.detail, /default_value/);
  });

  it('accepts a boolean field with default_value "" (unset)', () => {
    assert.deepEqual(isPayloadInconsistent('boolean', { default_value: '' }), { ok: true });
  });

  it('accepts a boolean field with default_value "true"', () => {
    assert.deepEqual(isPayloadInconsistent('boolean', { default_value: 'true' }), { ok: true });
  });

  it('accepts a boolean field with default_value "false"', () => {
    assert.deepEqual(isPayloadInconsistent('boolean', { default_value: 'false' }), { ok: true });
  });

  it('accepts a boolean field with no default_value named (statement silent on the column)', () => {
    assert.deepEqual(isPayloadInconsistent('boolean', {}), { ok: true });
  });

  it('accepts free-text default_value on a non-boolean field', () => {
    assert.deepEqual(isPayloadInconsistent('text', { default_value: 'yes' }), { ok: true });
  });
});

describe('field-type-domain — boolean is accepted', () => {
  it('fieldTypeViolation is null for a boolean field_type', () => {
    assert.equal(fieldTypeViolation({ field_type: 'boolean' }), null);
  });
});

describe('boolean_config export -> import round-trip', () => {
  function rawFixture(booleanConfig) {
    return {
      import_version: 1,
      hierarchy_node: {
        id: 'bp-uuid-1', parent_id: 'release-uuid-1', name: 'BP',
        description: '', node_type: 'blueprint', sort_order: 0, is_active: 1,
        transformer_id: null, transformer_version: null, linked_blueprint_id: null,
      },
      blueprint_fields: [{
        id: 'fld-1', blueprint_id: 'bp-uuid-1', field_key: 'active', field_label: 'Active',
        field_type: 'boolean', is_required: 0, default_value: '', placeholder: '', tooltip: '',
        section: 'general', order_index: 0,
        table_config: null, choice_config: null, options_source: null, visibility_rule: null,
        value_scope: null, compute_rule: null,
        boolean_config: booleanConfig != null ? JSON.stringify(booleanConfig) : null,
      }],
      field_options: [],
      blueprint_sections: [],
      blueprint_output_order: [],
    };
  }

  it('a stored { whenEmpty: "null" } round-trips unchanged', () => {
    const parsed = serialization.parseYaml(serialization.serializeYaml(rawFixture({ whenEmpty: 'null' })));
    const field = parsed.blueprint_fields.find((f) => f.field_key === 'active');
    assert.deepEqual(JSON.parse(field.boolean_config), { whenEmpty: 'null' });
  });

  it('a null boolean_config (the omit default) round-trips as null', () => {
    const parsed = serialization.parseYaml(serialization.serializeYaml(rawFixture(null)));
    const field = parsed.blueprint_fields.find((f) => f.field_key === 'active');
    assert.equal(field.boolean_config, null);
  });

  it('import rejects boolean_config on a non-boolean field', () => {
    const raw = rawFixture({ whenEmpty: 'null' });
    raw.blueprint_fields[0].field_type = 'text';
    assert.throws(
      () => serialization.parseYaml(serialization.serializeYaml(raw)),
      /boolean_config is only valid on a boolean field/,
    );
  });

  it('import rejects boolean_config on a REQUIRED boolean field (fix batch M1)', () => {
    const raw = rawFixture({ whenEmpty: 'null' });
    raw.blueprint_fields[0].is_required = 1;
    assert.throws(
      () => serialization.parseYaml(serialization.serializeYaml(raw)),
      /boolean_config is only valid on an optional boolean field/,
    );
  });

  it('import rejects a malformed boolean_config on a boolean field', () => {
    // Hand-craft YAML text directly: serializeYaml would never emit this
    // shape itself, but an authored/edited YAML file can carry anything.
    const yamlText = [
      'import_version: 1',
      'blueprint:',
      '  name: BP',
      'fields:',
      '  - key: active',
      '    type: boolean',
      '    boolean_config:',
      '      whenEmpty: sometimes',
    ].join('\n');
    assert.throws(
      () => serialization.parseYaml(yamlText),
      /boolean_config must be/,
    );
  });

  it('import rejects a free-text default on a boolean field (fix batch 2, P1a)', () => {
    const yamlText = [
      'import_version: 1',
      'blueprint:',
      '  name: BP',
      'fields:',
      '  - key: active',
      '    type: boolean',
      '    default: yes',
    ].join('\n');
    assert.throws(
      () => serialization.parseYaml(yamlText),
      /default must be .* for a boolean field/,
    );
  });

  it('import accepts a "true"/"false"/absent default on a boolean field (fix batch 2, P1a)', () => {
    for (const yamlText of [
      ['import_version: 1', 'blueprint:', '  name: BP', 'fields:', '  - key: active', '    type: boolean', '    default: "true"'].join('\n'),
      ['import_version: 1', 'blueprint:', '  name: BP', 'fields:', '  - key: active', '    type: boolean', '    default: "false"'].join('\n'),
      ['import_version: 1', 'blueprint:', '  name: BP', 'fields:', '  - key: active', '    type: boolean'].join('\n'),
    ]) {
      assert.doesNotThrow(() => serialization.parseYaml(yamlText));
    }
  });
});
