/**
 * flow-recipe-runs-immutable-actor.test.js
 *
 * What a run row may be changed into after it exists, and what it may not.
 *
 * The finalize write-back trusts the run row instead of re-asking who may reach
 * the record it names, so the columns that row is TRUSTED FOR have to be fixed
 * at creation: actor_id (who), template_id (which record), blueprint_id and
 * recipe_id (what ran), status (whether the write-back may still fire), and
 * input_snapshot (what was entered) — plus remote_refs (the captured-refs
 * snapshot, written only by finalize and link-existing through
 * validateRemoteRefs). The mount declares all seven immutable; the generic PUT
 * strips them for every role before building the SET clause. This file pins the
 * wiring statement by statement.
 *
 * IT DRIVES THE REAL flow-recipe-runs ROUTER, not a fresh factory mount, so it
 * proves the wiring and not merely that the factory CAN strip. What it CANNOT
 * show is the consequence — which rows the write-back then matches — because the
 * driver here is a fixture that answers whatever it was told to. That is in
 * tests/integration/flow-run-forged-row-real-db.test.js, on a real database,
 * driving these routes and the run routes together.
 */
const { test } = require('node:test');
const { makeStubReqLog } = require('../../../helpers/stub-req-log');
const assert = require('node:assert');
const express = require('express');

const dbKey = require.resolve('../../../../src/edge/db');

let capturedUpdateSql = null;
let capturedUpdateParams = null;
let capturedInsertSql = null;

const conn = {
  beginTransaction: async () => {},
  commit: async () => {},
  rollback: async () => {},
  release: () => {},
  query: async (sql, params) => {
    const norm = sql.replace(/\s+/g, ' ').trim();
    if (/information_schema/i.test(sql)) {
      return [{ COLUMN_NAME: 'id' }, { COLUMN_NAME: 'actor_id' }, { COLUMN_NAME: 'recipe_id' },
        { COLUMN_NAME: 'template_id' }, { COLUMN_NAME: 'blueprint_id' },
        { COLUMN_NAME: 'status' }, { COLUMN_NAME: 'result_link' },
        { COLUMN_NAME: 'error_summary' }, { COLUMN_NAME: 'input_snapshot' },
        { COLUMN_NAME: 'remote_refs' },
        // created_at is listed because the operator-mode column gate would
        // otherwise drop it for being absent here, and a strip test that passes
        // because the column was never offered pins nothing.
        { COLUMN_NAME: 'created_at' }];
    }
    if (/SELECT DATABASE\(\)/i.test(sql)) return [{ db: 'testdb' }];
    if (/^INSERT INTO `flow_recipe_runs`/i.test(norm)) {
      capturedInsertSql = norm;
      return { affectedRows: 1 };
    }
    if (/^UPDATE `flow_recipe_runs`/i.test(norm)) {
      capturedUpdateSql = norm;
      capturedUpdateParams = params;
      return { affectedRows: 1 };
    }
    if (/^SELECT \* FROM `flow_recipe_runs`/i.test(norm)) {
      return [{ id: '5b38f3eb-678d-4b05-8fea-72f9c807341b', actor_id: '405279b5-48c7-4bd5-8427-69d6ff5556a7', recipe_id: '110095e1-0ac0-43a2-8777-9449936efcdd', status: 'success' }];
    }
    return { affectedRows: 1 };
  },
};

require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: {
    pool: { rw: { getConnection: async () => conn, query: conn.query }, ro: { getConnection: async () => conn, query: conn.query } },
    t: (x) => x,
    getDynamicPool: async () => ({ rw: { getConnection: async () => conn, query: conn.query }, ro: { query: conn.query } }),
  },
};

const runsRouter = require('../../../../src/edge/routes/app/flow-recipe-runs');

function app(user) {
  const a = express();
  a.use((req, _res, next) => { req.log = makeStubReqLog(); next(); }); // TEST-ONLY: production always sets req.log via createRequestId (request-id.js) before any router; this bare app has no such middleware, so a route's req.log.<level>() call would otherwise throw against undefined.
  a.use(express.json());
  a.use((req, _res, next) => { req.user = user; next(); });
  a.use('/', runsRouter);
  return a;
}

async function request(a, method, path, body) {
  const server = a.listen(0);
  const port = server.address().port;
  try {
    const res = await fetch(`http://127.0.0.1:${port}${path}`, {
      method, headers: { 'content-type': 'application/json' }, body: JSON.stringify(body),
    });
    let parsed = null;
    try { parsed = await res.json(); } catch { parsed = null; }
    return { status: res.status, body: parsed, allow: res.headers.get('allow') };
  } finally { server.close(); }
}

const put = (a, path, body) => request(a, 'PUT', path, body);
const post = (a, path, body) => request(a, 'POST', path, body);

// Isolate the SET clause (between SET and WHERE) so an `actor_id` appearing in
// the WHERE write-scope is not mistaken for a SET assignment.
function setClause(sql) {
  const m = sql.match(/SET (.*?) WHERE /i);
  return m ? m[1] : sql;
}

/**
 * PUT the given body as an editor and report what reached the statement.
 * Every case below asserts against BOTH halves — the column absent from the SET
 * list, and the value absent from the bound parameters — because a column name
 * can be stripped while its value still rides along on another placeholder.
 */
async function putAs(user, body) {
  capturedUpdateSql = null; capturedUpdateParams = null;
  const res = await put(app(user), '/5b38f3eb-678d-4b05-8fea-72f9c807341b', body);
  return { ...res, set: capturedUpdateSql ? setClause(capturedUpdateSql) : null, params: capturedUpdateParams || [] };
}

const EDITOR = { id: '405279b5-48c7-4bd5-8427-69d6ff5556a7', role: 'editor' };
const ADMIN = { id: '5b729f1e-5c0b-447c-8144-3210469bc62c', role: 'admin' };

// Non-regression: the editor path was already protected by the writeScopeColumn
// strip (non-admins never carry actor_id into the SET), so this case stays GREEN
// with or without immutableColumns. It is the admin case below that the option
// actually flips. Kept to lock the editor path against future regression.
test('editor PUT with actor_id in body → actor_id stripped from UPDATE SET', async () => {
  const { status, set, params } = await putAs(EDITOR, { error_summary: 'noted', actor_id: 'ac571a57-1877-4c78-8034-c65a061bf29b' });
  assert.equal(status, 200);
  assert.ok(set, 'an UPDATE was issued');
  assert.doesNotMatch(set, /`actor_id` = \?/, 'actor_id must not be in the SET clause');
  assert.equal(params.includes('ac571a57-1877-4c78-8034-c65a061bf29b'), false, 'the foreign actor_id must not be bound as a param');
  assert.match(set, /`error_summary` = \?/, 'a legitimate field still updates');
});

test('admin PUT with actor_id in body → actor_id also stripped (role-agnostic)', async () => {
  const { status, set, params } = await putAs(ADMIN, { error_summary: 'noted', actor_id: 'ac571a57-1877-4c78-8034-c65a061bf29b' });
  assert.equal(status, 200);
  assert.doesNotMatch(set, /`actor_id` = \?/, 'admin must also have actor_id stripped');
  assert.equal(params.includes('ac571a57-1877-4c78-8034-c65a061bf29b'), false);
});

test('PUT cannot rewrite input_snapshot (update path only — the run\'s INSERT writes it)', async () => {
  // The run row is created with the snapshot at run-begin. If the generic PUT
  // could set it, the record of what the operator entered would be editable by
  // its own author afterwards, which is the one property it is kept for.
  const forged = JSON.stringify({ entered: { site: 'somewhere else' }, computed: {} });
  const { status, set, params } = await putAs(EDITOR, { error_summary: 'noted', input_snapshot: forged });
  assert.equal(status, 200);
  assert.doesNotMatch(set, /`input_snapshot` = \?/, 'input_snapshot must not be in the SET clause');
  assert.equal(params.includes(forged), false, 'the forged snapshot must not be bound as a param');
  assert.match(set, /`error_summary` = \?/, 'a legitimate field still updates');
});

test('PUT cannot write remote_refs (masking a forged value is not the same as refusing one)', async () => {
  // remote_refs is JSON on this table exactly like step_results, and the
  // generic PUT's dto-mapper stringifies whatever a body sends under either
  // name; the only writers that may ever set it are finalize and
  // link-existing, both through validateRemoteRefs. Without the strip a
  // caller could forge or unmask the run's captured-refs snapshot straight
  // through this route.
  const forged = JSON.stringify({ tasks: [{ id: 'x', access_token: 'sk-1' }] });
  const { status, set, params } = await putAs(EDITOR, { error_summary: 'noted', remote_refs: forged });
  assert.equal(status, 200);
  assert.doesNotMatch(set, /`remote_refs` = \?/, 'remote_refs must not be in the SET clause');
  assert.equal(params.includes(forged), false, 'the forged remote_refs must not be bound as a param');
  assert.match(set, /`error_summary` = \?/, 'a legitimate field still updates');
});

// The four columns the finalize write-back and the step-dispatch context read as
// answers. Each is asserted for both roles: an admin PUT is the permissive case,
// and a strip that only fired for non-admins would leave it open.
for (const [column, forged] of [
  ['template_id', 'e4aa5b78-93ac-4f81-8bfc-14d00f544f45'],
  ['blueprint_id', 'another-blueprint'],
  ['recipe_id', 'another-recipe'],
  ['status', 'partial'],
]) {
  for (const user of [EDITOR, ADMIN]) {
    test(`${user.role} PUT cannot move ${column}`, async () => {
      const { status, set, params } = await putAs(user, { error_summary: 'noted', [column]: forged });
      assert.equal(status, 200);
      assert.doesNotMatch(
        set, new RegExp('`' + column + '` = \\?'),
        `${column} must not be in the SET clause`,
      );
      assert.equal(params.includes(forged), false, `the forged ${column} must not be bound as a param`);
      assert.match(set, /`error_summary` = \?/, 'a legitimate field still updates');
    });
  }
}

test('PUT cannot move created_at — three history surfaces read it as "which run is the last one"', async () => {
  // created_at is the sole ORDER BY term (id breaks the tie) behind the group's
  // last run, the head of a group's history list, and the baseline the
  // pre-dispatch diff is taken against. A caller who may write their own run
  // could otherwise decide which run those three surfaces answer with. It is
  // stamped by the row's own INSERT and nothing in this repository writes it
  // through the generic route.
  const { status, set, params } = await putAs(EDITOR, { error_summary: 'noted', created_at: '2001-01-01 00:00:00' });
  assert.equal(status, 200);
  assert.doesNotMatch(set, /`created_at` = \?/, 'created_at must not be in the SET clause');
  assert.equal(params.includes('2001-01-01 00:00:00'), false);
  assert.match(set, /`error_summary` = \?/, 'a legitimate field still updates');
});

// THE SAME COLUMNS, SPELLED WITH A CAPITAL. A column identifier is
// case-insensitive to MariaDB, so `Template_Id` IS the column `template_id` —
// while every strip above is `delete data['template_id']` and never sees it.
// Each title above states a property of the ROW ("cannot be retargeted"); one
// spelling of one key is not that property, and the gap is precisely where the
// bypass sat.
for (const [column, forged] of [
  ['actor_id', 'ac571a57-1877-4c78-8034-c65a061bf29b'],
  ['template_id', 'e4aa5b78-93ac-4f81-8bfc-14d00f544f45'],
  ['blueprint_id', 'another-blueprint'],
  ['recipe_id', 'another-recipe'],
  ['status', 'partial'],
  ['input_snapshot', '{"entered":{},"computed":{}}'],
  ['remote_refs', '{"tasks":[{"id":"x"}]}'],
  ['created_at', '2001-01-01 00:00:00'],
  ['id', 'hijacked-id'],
]) {
  const cased = column.replace(/(^|_)([a-z])/g, (_m, sep, ch) => sep + ch.toUpperCase());
  for (const user of [EDITOR, ADMIN]) {
    test(`${user.role} PUT cannot move ${column} by spelling it ${cased}`, async () => {
      const { status, set, params } = await putAs(user, { error_summary: 'noted', [cased]: forged });
      assert.equal(status, 400, `expected a refusal, got ${status}`);
      assert.equal(set, null, 'a body naming a column in another case still issued an UPDATE');
      assert.equal(params.includes(forged), false, `the forged ${column} must not be bound as a param`);
    });
  }
}

test('a PUT carrying only immutable columns writes nothing at all', async () => {
  // The strip must not degrade into "update everything else": with nothing left
  // the factory refuses rather than issuing a statement, so a caller cannot use
  // an all-immutable body to touch the row's updated_at either.
  const { status, set } = await putAs(EDITOR, { template_id: 'e4aa5b78-93ac-4f81-8bfc-14d00f544f45', status: 'partial' });
  assert.equal(status, 400);
  assert.equal(set, null, 'an UPDATE was issued for a body that stripped to nothing');
});

test('POST on the collection creates nothing — runs come from the dispatch path', async () => {
  // The other half of the same rule. The write-back trusts the run row because
  // run-begin's own INSERT carried the dispatch permission; a generic create
  // here would mint a row that satisfies every binding finalize checks while
  // standing for a permission nobody asked about.
  capturedInsertSql = null;
  const res = await post(app(EDITOR), '/', {
    recipe_id: '110095e1-0ac0-43a2-8777-9449936efcdd', template_id: 'e4aa5b78-93ac-4f81-8bfc-14d00f544f45', status: 'partial',
  });
  assert.equal(res.status, 405, `expected a refusal, got ${JSON.stringify(res.body)}`);
  assert.equal(res.body.error.code, 'METHOD_NOT_ALLOWED');
  assert.equal(res.allow, 'GET', 'the refusal must say what the collection does answer');
  assert.equal(capturedInsertSql, null, 'a refused create issued an INSERT');
});

test('an administrator gets the same refusal', async () => {
  // Admin write-scope skips the actor stamp on this mount, so an open create
  // route is at its most permissive here.
  capturedInsertSql = null;
  const res = await post(app(ADMIN), '/', {
    recipe_id: '110095e1-0ac0-43a2-8777-9449936efcdd', template_id: 'e4aa5b78-93ac-4f81-8bfc-14d00f544f45', actor_id: 'ac571a57-1877-4c78-8034-c65a061bf29b', status: 'partial',
  });
  assert.equal(res.status, 405);
  assert.equal(capturedInsertSql, null, 'a refused create issued an INSERT');
});

test('an unauthenticated POST is still answered by the authentication gate', async () => {
  // The refusal is mounted behind the mount's own auth middleware on purpose:
  // an anonymous caller must not learn from it which verbs the collection
  // offers, and must keep getting the answer it got before.
  const res = await post(app(undefined), '/', { recipe_id: '110095e1-0ac0-43a2-8777-9449936efcdd' });
  assert.equal(res.status, 401, `expected 401, got ${res.status}`);
});
