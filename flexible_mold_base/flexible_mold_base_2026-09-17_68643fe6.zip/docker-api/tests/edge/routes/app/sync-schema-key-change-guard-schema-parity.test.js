/**
 * sync-schema-key-change-guard-schema-parity.test.js — validates every column
 * fmb-1522's field-key-change guard names LITERALLY against the ACTUAL table
 * DDL, without a live DB — per repo rule, new SQL ships with a schema-parity
 * test (docker-api/tests/edge/routes/app/capacity-delete-preview-schema-parity
 * .test.js is the template). A wrong column name here stays green under every
 * mocked runner (the mock answers whatever the fixture supplies) and 500s the
 * whole sync in production.
 *
 * The DB-survivor SELECT's reference-site columns (depends_on_field_key,
 * visibility_rule) are read out of BLUEPRINT_FIELD_KEY_REFERENCES rather than
 * hand-listed here — that declaration already has its own parity test
 * (blueprint-field-key-references-parity.test.js) against every column on
 * blueprint_fields that COULD hold a key reference; this file only has to
 * confirm the guard's SQL actually spells those same names.
 */
const { describe, it, before } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const dbKey = require.resolve('../../../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: {}, t: (n) => n, getDynamicPool: async () => ({}) },
};

const { buildEngineTableDDLs } = require('../../../../src/table-ddls');
const { BLUEPRINT_FIELD_KEY_REFERENCE_COLUMNS } = require('../../../../src/edge/lib/blueprint-field-key-references');

let columnsByTable;
before(() => {
  columnsByTable = new Map();
  const SQL_TYPES = /^`?([a-z_]+)`?\s+(?:CHAR|VARCHAR|INT|DOUBLE|TIMESTAMP|JSON|TEXT|ENUM|BOOLEAN|TINYINT|BIGINT|DATETIME|DECIMAL|FLOAT|BLOB)\b/i;
  for (const ddl of buildEngineTableDDLs((n) => n)) {
    const m = ddl.match(/CREATE TABLE IF NOT EXISTS `([^`]+)`/);
    if (!m) continue;
    const cols = new Set();
    for (const rawLine of ddl.split('\n')) {
      const line = rawLine.trim();
      if (!line || line.startsWith('--') || line.startsWith('/*')) continue;
      const cm = line.match(SQL_TYPES);
      if (cm) cols.add(cm[1]);
    }
    columnsByTable.set(m[1], cols);
  }
});

const SYNC_SCHEMA_SRC = fs.readFileSync(
  path.resolve(__dirname, '../../../../src/edge/routes/app/sync-schema.js'), 'utf8',
);

describe('sync-schema field-key-change guard (fmb-1522) — schema parity', () => {
  it('parses columns for blueprint_fields', () => {
    assert.ok(columnsByTable.get('blueprint_fields')?.size > 0, 'no columns parsed for blueprint_fields');
  });

  it('loadExistingFieldRows names real blueprint_fields columns (id, blueprint_id, field_key)', () => {
    assert.match(
      SYNC_SCHEMA_SRC,
      /SELECT \\`id\\`, \\`blueprint_id\\`, \\`field_key\\` FROM \\`\$\{physical\}\\` WHERE \\`id\\` IN/,
    );
    const cols = columnsByTable.get('blueprint_fields');
    assert.ok(cols.has('id'), 'blueprint_fields has no id');
    assert.ok(cols.has('blueprint_id'), 'blueprint_fields has no blueprint_id');
    assert.ok(cols.has('field_key'), 'blueprint_fields has no field_key');
  });

  it('the DB-survivor SELECT names real id/blueprint_id columns (one query per reference column)', () => {
    assert.match(
      SYNC_SCHEMA_SRC,
      /SELECT \\`id\\`, \\`blueprint_id\\`, \$\{selectCol\}\s*\n\s*FROM \$\{physical\}\s*\n\s*WHERE \\`blueprint_id\\` IN/,
    );
    const cols = columnsByTable.get('blueprint_fields');
    assert.ok(cols.has('id') && cols.has('blueprint_id'));
  });

  it('the DB-survivor SELECT is built from the shared field-key-reference declaration, not a hand-typed list', () => {
    assert.match(SYNC_SCHEMA_SRC, /fieldKeyReferencesPresentIn\(colSet\)/);
    // Whatever that declaration names must actually exist on blueprint_fields —
    // its own parity test pins the declaration; this pins the guard reads it.
    const cols = columnsByTable.get('blueprint_fields');
    for (const col of BLUEPRINT_FIELD_KEY_REFERENCE_COLUMNS) {
      assert.ok(cols.has(col), `blueprint_fields has no column '${col}' named by BLUEPRINT_FIELD_KEY_REFERENCES`);
    }
  });

  it('reads reference values off an incoming packet row via the shared getReferencedKey, not a second parser', () => {
    assert.match(SYNC_SCHEMA_SRC, /getReferencedKey\(row, site\)/);
  });

  it('per-column exclusion is built per site, not one shared list for every reference column', () => {
    // The partial-row fix (a row can supply one reference column and omit
    // another) only holds if each site gets its OWN excludeIds/query — a
    // single shared exclusion list can only express one column's coverage.
    assert.match(SYNC_SCHEMA_SRC, /suppliedIdsBySite\.get\(site\.column\)/);
    // probeFieldKeyRefSurvivors (fmb-1522 r3) is the shared query builder both
    // the preflight probe AND the post-write verification probes call — its
    // per-site exclusion list is parameterized as `excludeIdsBySite` so the
    // post-write callers can pass none (there is no packet value left to
    // trust once the write already happened) while the preflight still
    // passes suppliedIdsBySite.
    assert.match(SYNC_SCHEMA_SRC, /const excludeIds = \[\.\.\.\(excludeIdsBySite\?\.get\(site\.column\) \|\| \[\]\)\];/);
  });

  it('the post-write field-existence check (fmb-1522 r3, P1 part 2 reverse direction) names real blueprint_id/field_key columns', () => {
    assert.match(
      SYNC_SCHEMA_SRC,
      /SELECT \\`blueprint_id\\`, \\`field_key\\`\s*\n\s*FROM \$\{fieldKeyChangeGuard\.physical\}\s*\n\s*WHERE \\`blueprint_id\\` IN/,
    );
    const cols = columnsByTable.get('blueprint_fields');
    assert.ok(cols.has('blueprint_id') && cols.has('field_key'));
  });

  it("siteValueReachesUpdate's coerced-null exception reads TABLE_DEFS.blueprint_fields.nullableStrings, the same declaration buildUpsert itself reads", () => {
    // depends_on_field_key IS in nullableStrings (an explicit null coerces
    // away, so the ON DUPLICATE KEY UPDATE clause drops it — the stored value
    // survives); visibility_rule is NOT. A hand-typed copy of that list here
    // would silently drift from buildUpsert's own exclusion the day either
    // set changes.
    assert.match(SYNC_SCHEMA_SRC, /TABLE_DEFS\.blueprint_fields\.nullableStrings\?\.includes\(site\.column\)/);
    assert.match(
      SYNC_SCHEMA_SRC,
      /nullableStrings: \['field_label', 'default_value', 'placeholder', 'tooltip', 'section', 'depends_on_field_key', 'group_key', 'matrix_row_key'\],/,
    );
  });
});
