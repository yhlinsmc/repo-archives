/**
 * load-blueprint-field-key-sets-schema-parity.test.js — validate.js's
 * `loadBlueprintFieldKeySets` SELECT (blueprint_id, field_key, field_type,
 * table_config off blueprint_fields), checked against the ACTUAL DDL without
 * a live database — same contract as health-options-census-schema-parity.
 * test.js (its twin query). A mock reading a wrong column name is exactly
 * what this test exists to catch — the rule is every new SQL query ships
 * with a schema-parity test that checks its referenced columns against
 * table-ddls.js.
 */
const { describe, it, before } = require('node:test');
const assert = require('node:assert/strict');

const { buildEngineTableDDLs } = require('../../../../../src/table-ddls');

let cols;
before(() => {
  cols = new Set();
  for (const ddl of buildEngineTableDDLs((n) => n)) {
    if (!/CREATE TABLE IF NOT EXISTS `blueprint_fields`/.test(ddl)) continue;
    for (const line of ddl.split('\n')) {
      const m = line.trim().match(/^`?([a-z_]+)`?\s+(?:CHAR|VARCHAR|INT|DOUBLE|TIMESTAMP|JSON|TEXT|ENUM|BOOLEAN|TINYINT|BIGINT|DATETIME|DECIMAL|FLOAT|BLOB)\b/i);
      if (m) cols.add(m[1]);
    }
  }
});

describe('loadBlueprintFieldKeySets SELECT — schema parity', () => {
  for (const c of ['blueprint_id', 'field_key', 'field_type', 'table_config']) {
    it(`blueprint_fields has ${c}`, () => assert.ok(cols.has(c), `missing ${c}`));
  }
});
