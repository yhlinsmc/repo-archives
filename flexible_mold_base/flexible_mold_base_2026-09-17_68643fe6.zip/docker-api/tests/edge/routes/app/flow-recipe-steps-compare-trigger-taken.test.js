// docker-api/tests/edge/routes/app/flow-recipe-steps-compare-trigger-taken.test.js
//
// I4 (compare-trigger uniqueness) has ONE decision point — the
// in-tx FOR UPDATE sibling read in assertStepInvariantsInTx, on the primary.
// The router-level pre-tx sibling read this file used to pin was DELETED:
// pool.ro is a real, independently-lagging replica (db.js), so an unlocked
// read there could refuse a save the race-free in-tx check would have
// allowed (the RD-4 save chain — demote step 1, then set step 2 to compare —
// is exactly this shape; a lagging replica still answering "step 1 still
// holds compare" after that demotion committed on the primary).
//
// This file now proves the NEGATIVE: a stale/colliding sibling row on
// pool.ro no longer refuses the request pre-tx — every case reaches CRUD
// (this file's CRUD stub does not run transformCreateInTx/postUpdateInTx, so
// it cannot exercise the in-tx refusal itself). The actual I4 enforcement —
// the 400 FLOW_COMPARE_TRIGGER_TAKEN refusal, with real stored-row/row-count
// evidence — lives entirely in flow-compare-trigger-taken-real-db.test.js
// (REQUIRE_INTEGRATION_DB=1), which exercises the real in-tx FOR UPDATE path
// this mock cannot reach.
const { test, beforeEach } = require('node:test');
const assert = require('node:assert');
const express = require('express');
const { makeStubReqLog } = require('../../../helpers/stub-req-log');

// Mutable per-test fixtures the mock answers from — set in each test, reset
// in beforeEach so a case that declares none starts from "nothing stored".
let storedStepRow = null; // the row every `flow_recipe_steps ... WHERE id = ?` read answers with
let recipeRow = null; // the row every `flow_recipes ... WHERE id = ?` read answers with
// A colliding sibling row, kept only to prove the pre-tx gate no longer
// queries for it (see the assertion in `poolRoQueriedSiblings` below) — this
// mock's `flow_recipe_steps ... WHERE recipe_id = ?` branch would answer with
// it if any pre-tx code still asked, and every test here proves none does.
let staleSiblingRows = [{ id: 'other-step', name: 'The existing preview', step_runs_on: 'compare' }];
let poolRoQueriedSiblings = false;

require.cache[require.resolve('../../../../src/edge/db')] = {
  exports: {
    pool: {
      ro: {
        query: async (sql) => {
          if (/flow_recipe_steps/i.test(sql) && /recipe_id\s*=\s*\?/.test(sql)) {
            poolRoQueriedSiblings = true;
            return staleSiblingRows;
          }
          if (/flow_recipe_steps/i.test(sql) && /WHERE id = \?/.test(sql)) {
            return storedStepRow ? [storedStepRow] : [];
          }
          if (/flow_recipes/i.test(sql)) {
            return recipeRow ? [recipeRow] : [];
          }
          return [];
        },
      },
      rw: { getConnection: async () => ({ query: async () => [], release: () => {} }) },
    },
    t: (x) => x,
  },
};
require.cache[require.resolve('../../../../src/edge/routes/app/schema')] = {
  exports: { createCrudRoutes: () => (req, res) => res.json({ ok: true, reached: 'crud' }) },
};
const router = require('../../../../src/edge/routes/app/flow-recipe-steps');

function app(user) {
  const a = express(); a.use(express.json());
  a.use((req, _res, next) => { req.user = user; req.log = makeStubReqLog(); next(); }); // TEST-ONLY: production always sets req.log via createRequestId (request-id.js) before any router; this bare app has no such middleware.
  a.use('/', router);
  return a;
}
async function send(a, method, path, body) {
  const server = a.listen(0);
  try {
    const port = server.address().port;
    const res = await fetch(`http://127.0.0.1:${port}${path}`, {
      method, headers: { 'content-type': 'application/json' }, body: JSON.stringify(body || {}),
    });
    const json = await res.json().catch(() => ({}));
    return { status: res.status, json };
  } finally {
    server.close();
  }
}

const EDITOR = { id: 'u1', role: 'editor' };
const RECIPE_ID = 'aaaa0000-0000-0000-0000-000000000001';
const OTHER_RECIPE_ID = 'aaaa0000-0000-0000-0000-000000000099';
const STEP_ID = 'bbbb0000-0000-0000-0000-000000000002';

beforeEach(() => {
  storedStepRow = null;
  recipeRow = { owner_id: null, runs_on: 'both' };
  staleSiblingRows = [{ id: 'other-step', name: 'The existing preview', step_runs_on: 'compare' }];
  poolRoQueriedSiblings = false;
});

// Before this fix this returned 400 FLOW_COMPARE_TRIGGER_TAKEN; now that
// the pre-tx sibling read is gone, a STALE
// replica row (however it answers) can no longer refuse this request — the
// in-tx FOR UPDATE recheck (real DB, no mock) is the only place that can.
test('POST step_runs_on=compare reaches CRUD even when pool.ro answers with a colliding sibling', async () => {
  const { json } = await send(app(EDITOR), 'POST', '/', {
    recipe_id: RECIPE_ID, step_runs_on: 'compare', name: 'S', url: 'https://x/', method: 'GET',
  });
  assert.strictEqual(json.reached, 'crud');
  assert.strictEqual(poolRoQueriedSiblings, false, 'the pre-tx gate must not query for siblings at all');
});

test('POST with step_runs_on other than compare never resolves siblings', async () => {
  const { json } = await send(app(EDITOR), 'POST', '/', {
    recipe_id: RECIPE_ID, step_runs_on: 'update', name: 'S', url: 'https://x/', method: 'POST',
  });
  assert.strictEqual(json.reached, 'crud');
  assert.strictEqual(poolRoQueriedSiblings, false);
});

// RED on 3f3b4d39: this returned 400 FLOW_COMPARE_TRIGGER_TAKEN.
test('PUT /:id step_runs_on=compare reaches CRUD even when pool.ro answers with a colliding sibling', async () => {
  storedStepRow = { recipe_id: RECIPE_ID, method: 'GET', step_type: 'api', step_runs_on: 'both' };
  const { json } = await send(app(EDITOR), 'PUT', `/${STEP_ID}`, { step_runs_on: 'compare' });
  assert.strictEqual(json.reached, 'crud');
  assert.strictEqual(poolRoQueriedSiblings, false);
});

test('PUT /:id step_runs_on=compare on the step that already IS the trigger reaches CRUD (no self-collision)', async () => {
  storedStepRow = { recipe_id: RECIPE_ID, method: 'GET', step_type: 'api', step_runs_on: 'compare' };
  const { json } = await send(app(EDITOR), 'PUT', `/${STEP_ID}`, { step_runs_on: 'compare' });
  assert.strictEqual(json.reached, 'crud');
});

// RED on 3f3b4d39: this returned 400 FLOW_COMPARE_TRIGGER_TAKEN. This is the
// exact RD-4 save-chain shape (a reparent PUT into a recipe pool.ro still
// shows as holding a compare trigger) the pre-tx replica read could false-
// refuse under lag; now it reaches CRUD unconditionally.
test('PUT reparent-only (no step_runs_on named) into a recipe pool.ro shows as already holding a compare trigger reaches CRUD', async () => {
  storedStepRow = { recipe_id: RECIPE_ID, step_runs_on: 'compare' };
  recipeRow = { owner_id: null, runs_on: 'both' }; // the NEW parent (OTHER_RECIPE_ID)
  const { json } = await send(app(EDITOR), 'PUT', `/${STEP_ID}`, { recipe_id: OTHER_RECIPE_ID });
  assert.strictEqual(json.reached, 'crud');
  assert.strictEqual(poolRoQueriedSiblings, false);
});
