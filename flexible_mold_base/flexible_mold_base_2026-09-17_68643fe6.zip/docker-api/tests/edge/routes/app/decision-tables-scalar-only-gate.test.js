/**
 * decision-tables-scalar-only-gate.test.js — the `decision_tables`
 * write route refuses a `table`/`checkbox`/`date` field named as a
 * condition/output, through the real route (`refuseScalarOnlyDecisionKeys`
 * composed with `refuseDuplicateDecisionOutput` in
 * `edge/routes/app/schema/index.js`). Same mocked-pool harness as
 * `decision-output-claim-guard.test.js` (its sibling in-tx guard).
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const { answerParentIdProbe } = require('../../../helpers/parent-id-probe');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../../../src/edge/db');

const DECISION_COLUMNS = ['id', 'blueprint_id', 'name', 'doc', 'created_at'];

const doc = (conditions, outputs, rows = []) => ({
  conditions: conditions.map((field_key) => ({ field_key })),
  outputs: outputs.map((field_key) => ({ field_key })),
  rows,
});

const BLUEPRINT_ID = 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26';

let conn;
let dbSeq = 0;
const ADMIN = { id: '5b729f1e-5c0b-447c-8144-3210469bc62c', role: 'admin' };
let currentUser = ADMIN;

/**
 * @param {{stored?: object[], fields?: object[], tableExists?: boolean}} opts
 *   `fields` is the blueprint's live `blueprint_fields` rows (field_key,
 *   field_type) the scalar-only gate resolves keys against.
 */
function makeConn({ stored = [], fields = [], tableExists = true } = {}) {
  const dbName = `db_${dbSeq += 1}`;
  const queries = [];
  let committed = false;
  let rolledBack = false;
  return {
    queries,
    committed: () => committed,
    rolledBack: () => rolledBack,
    async beginTransaction() {},
    async commit() { committed = true; },
    async rollback() { rolledBack = true; },
    async query(sql, params) {
      queries.push({ sql, params });
      if (/^SELECT DATABASE\(\)/i.test(sql)) return [{ db: dbName }];
      if (/information_schema\.TABLES/i.test(sql)) return tableExists ? [{ c: 1 }] : [];
      if (/information_schema\.COLUMNS/i.test(sql)) {
        return DECISION_COLUMNS.map((c) => ({ COLUMN_NAME: c }));
      }
      if (/SELECT `blueprint_id` AS parent_value FROM `fmb_decision_tables`/i.test(sql)) {
        const row = stored.find((r) => r.id === params[0]);
        return row ? [{ parent_value: row.blueprint_id }] : [];
      }
      const parentId = answerParentIdProbe(sql, params);
      if (parentId) return parentId;
      if (/FROM `fmb_hierarchy_nodes`/i.test(sql)) return [{ owner_id: null }];
      // refuseDuplicateDecisionOutput's own reads — no sibling claims in any
      // of these fixtures, so it never fires and the scalar-only gate is the
      // one under test.
      if (/SELECT blueprint_id, doc FROM `fmb_decision_tables`/i.test(sql)) {
        const row = stored.find((r) => r.id === params[0]);
        return row ? [{ blueprint_id: row.blueprint_id, doc: JSON.stringify(row.doc) }] : [];
      }
      if (/SELECT name, doc FROM `fmb_decision_tables`/i.test(sql)) return [];
      // refuseScalarOnlyDecisionKeys's own reads.
      if (/SELECT blueprint_id FROM `fmb_decision_tables`/i.test(sql)) {
        const row = stored.find((r) => r.id === params[0]);
        return row ? [{ blueprint_id: row.blueprint_id }] : [];
      }
      if (/SELECT field_key, field_type FROM `fmb_blueprint_fields`/i.test(sql)) {
        const [blueprintId, ...keys] = params;
        return fields.filter((f) => f.blueprint_id === blueprintId && keys.includes(f.field_key));
      }
      if (/SELECT id FROM `fmb_decision_tables`/i.test(sql)) return [];
      if (/SELECT linked_blueprint_id FROM/i.test(sql)) return [];
      if (/ AS bid FROM/i.test(sql) || / AS fk FROM/i.test(sql)) return [];
      if (/^SELECT/i.test(sql) && /FOR UPDATE/i.test(sql)) return [{ id: params[0] }];
      if (/^INSERT INTO/i.test(sql) || /^UPDATE /i.test(sql)) return { affectedRows: 1, insertId: 1 };
      if (/^SELECT \* FROM `fmb_decision_tables`/i.test(sql)) {
        return [{ id: 'cda3af10-a915-465c-8461-01c5ce8b3bd1', blueprint_id: BLUEPRINT_ID, name: 'x', doc: '{}' }];
      }
      return [];
    },
    release() {},
  };
}

const poolSpy = {
  rw: { async getConnection() { return conn; } },
  ro: { async getConnection() { return conn; } },
};

require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: poolSpy, t: (name) => `fmb_${name}`, getDynamicPool: async () => poolSpy },
};

const router = require('../../../../src/edge/routes/app/schema');

let server;
let port;

before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { req.user = currentUser; next(); });
  app.use('/edge/app/schema', router);
  await new Promise((resolve) => {
    server = app.listen(0, '127.0.0.1', () => { port = server.address().port; resolve(); });
  });
});

after(async () => {
  await new Promise((resolve) => server.close(resolve));
  delete require.cache[dbKey];
});

beforeEach(() => { conn = null; currentUser = ADMIN; });

function send(method, path, body) {
  return new Promise((resolve, reject) => {
    const data = JSON.stringify(body);
    const r = http.request({
      method, host: '127.0.0.1', port, path,
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(data) },
    }, (res) => {
      let raw = '';
      res.on('data', (c) => { raw += c; });
      res.on('end', () => resolve({ status: res.statusCode, body: raw ? JSON.parse(raw) : null }));
    });
    r.on('error', reject);
    r.write(data);
    r.end();
  });
}

const wrote = (queries) => queries.some((q) => /^(INSERT INTO|UPDATE) `fmb_decision_tables`/i.test(q.sql.trim()));

describe('the API refuses a decision-table key naming a scalar-only-typed field', () => {
  it('refuses a CREATE naming a table field as a condition', async () => {
    conn = makeConn({ fields: [{ blueprint_id: BLUEPRINT_ID, field_key: 'turbines', field_type: 'table' }] });
    const res = await send('POST', '/edge/app/schema/decision_tables', {
      blueprint_id: BLUEPRINT_ID, name: 'T', doc: doc(['turbines'], ['cavity_count']),
    });
    assert.equal(res.status, 400, JSON.stringify(res.body));
    assert.equal(res.body.error.code, 'INVALID_DECISION_FIELD_TYPE');
    assert.match(res.body.error.message, /'turbines' is a table field/);
    assert.equal(wrote(conn.queries), false);
    assert.equal(conn.rolledBack(), true);
  });

  it('refuses a CREATE naming a checkbox field as an output', async () => {
    conn = makeConn({ fields: [{ blueprint_id: BLUEPRINT_ID, field_key: 'options', field_type: 'checkbox' }] });
    const res = await send('POST', '/edge/app/schema/decision_tables', {
      blueprint_id: BLUEPRINT_ID, name: 'T', doc: doc(['region'], ['options']),
    });
    assert.equal(res.status, 400, JSON.stringify(res.body));
    assert.equal(res.body.error.code, 'INVALID_DECISION_FIELD_TYPE');
    assert.equal(wrote(conn.queries), false);
  });

  it('refuses a CREATE naming a date field as a condition', async () => {
    conn = makeConn({ fields: [{ blueprint_id: BLUEPRINT_ID, field_key: 'start', field_type: 'date' }] });
    const res = await send('POST', '/edge/app/schema/decision_tables', {
      blueprint_id: BLUEPRINT_ID, name: 'T', doc: doc(['start'], ['cavity_count']),
    });
    assert.equal(res.status, 400, JSON.stringify(res.body));
    assert.equal(res.body.error.code, 'INVALID_DECISION_FIELD_TYPE');
    assert.equal(wrote(conn.queries), false);
  });

  it('allows an ordinary scalar field (select) as a condition', async () => {
    conn = makeConn({ fields: [{ blueprint_id: BLUEPRINT_ID, field_key: 'material', field_type: 'select' }] });
    const res = await send('POST', '/edge/app/schema/decision_tables', {
      blueprint_id: BLUEPRINT_ID, name: 'T', doc: doc(['material'], ['cavity_count']),
    });
    assert.equal(res.status, 200, JSON.stringify(res.body));
    assert.equal(wrote(conn.queries), true);
  });

  it('does not refuse a stale key naming no live field — no-FK philosophy unchanged', async () => {
    conn = makeConn({ fields: [] });
    const res = await send('POST', '/edge/app/schema/decision_tables', {
      blueprint_id: BLUEPRINT_ID, name: 'T', doc: doc(['deleted_field'], ['cavity_count']),
    });
    assert.equal(res.status, 200, JSON.stringify(res.body));
  });

  it('refuses an UPDATE that omits blueprint_id, resolving it from the stored row', async () => {
    const ROW_ID = 'e4e219c5-4d4b-4c5a-8b02-d30cc6057641';
    conn = makeConn({
      stored: [{ id: ROW_ID, blueprint_id: BLUEPRINT_ID, name: 'T', doc: doc([], []) }],
      fields: [{ blueprint_id: BLUEPRINT_ID, field_key: 'turbines', field_type: 'table' }],
    });
    const res = await send('PUT', `/edge/app/schema/decision_tables/${ROW_ID}`, {
      doc: doc(['turbines'], ['cavity_count']),
    });
    assert.equal(res.status, 400, JSON.stringify(res.body));
    assert.equal(res.body.error.code, 'INVALID_DECISION_FIELD_TYPE');
  });

  it('passes a body that carries no doc — no key reference changes', async () => {
    const ROW_ID = 'e4e219c5-4d4b-4c5a-8b02-d30cc6057641';
    conn = makeConn({
      stored: [{ id: ROW_ID, blueprint_id: BLUEPRINT_ID, name: 'T', doc: doc(['turbines'], []) }],
      fields: [{ blueprint_id: BLUEPRINT_ID, field_key: 'turbines', field_type: 'table' }],
    });
    const res = await send('PUT', `/edge/app/schema/decision_tables/${ROW_ID}`, { name: 'Renamed' });
    assert.equal(res.status, 200, JSON.stringify(res.body));
    assert.equal(
      conn.queries.some((q) => /SELECT field_key, field_type FROM `fmb_blueprint_fields`/i.test(q.sql)),
      false,
      'a write that does not name doc must not run the field-type scan',
    );
  });

  // A PUT that repoints blueprint_id and carries no `doc` moves the STORED
  // document's key references into the new blueprint's field list without
  // ever stating a new doc — the reparent gap this fix batch item closes.
  const OTHER_BLUEPRINT_ID = 'f13c9a2e-2b6a-4e4d-9a9a-7e6f7c2c9a11';

  it('refuses a reparent PUT (no doc) whose stored keys resolve to a scalar-only field on the target blueprint', async () => {
    const ROW_ID = 'e4e219c5-4d4b-4c5a-8b02-d30cc6057641';
    conn = makeConn({
      stored: [{ id: ROW_ID, blueprint_id: BLUEPRINT_ID, name: 'T', doc: doc(['start'], ['cavity_count']) }],
      fields: [
        { blueprint_id: BLUEPRINT_ID, field_key: 'start', field_type: 'select' },
        { blueprint_id: OTHER_BLUEPRINT_ID, field_key: 'start', field_type: 'date' },
        { blueprint_id: OTHER_BLUEPRINT_ID, field_key: 'cavity_count', field_type: 'number' },
      ],
    });
    const res = await send('PUT', `/edge/app/schema/decision_tables/${ROW_ID}`, {
      blueprint_id: OTHER_BLUEPRINT_ID,
    });
    assert.equal(res.status, 400, JSON.stringify(res.body));
    assert.equal(res.body.error.code, 'INVALID_DECISION_FIELD_TYPE');
    assert.match(res.body.error.message, /'start' is a date field/);
    assert.equal(wrote(conn.queries), false);
    assert.equal(conn.rolledBack(), true);
  });

  it('allows a reparent PUT (no doc) whose stored keys resolve to ordinary scalar fields on the target blueprint', async () => {
    const ROW_ID = 'e4e219c5-4d4b-4c5a-8b02-d30cc6057641';
    conn = makeConn({
      stored: [{ id: ROW_ID, blueprint_id: BLUEPRINT_ID, name: 'T', doc: doc(['start'], ['cavity_count']) }],
      fields: [
        { blueprint_id: BLUEPRINT_ID, field_key: 'start', field_type: 'select' },
        { blueprint_id: OTHER_BLUEPRINT_ID, field_key: 'start', field_type: 'select' },
        { blueprint_id: OTHER_BLUEPRINT_ID, field_key: 'cavity_count', field_type: 'number' },
      ],
    });
    const res = await send('PUT', `/edge/app/schema/decision_tables/${ROW_ID}`, {
      blueprint_id: OTHER_BLUEPRINT_ID,
    });
    assert.equal(res.status, 200, JSON.stringify(res.body));
    assert.equal(wrote(conn.queries), true);
  });
});
