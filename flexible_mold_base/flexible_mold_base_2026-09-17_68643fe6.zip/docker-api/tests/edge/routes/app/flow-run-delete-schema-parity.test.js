// docker-api/tests/edge/routes/app/flow-run-delete-schema-parity.test.js
//
// The atomic run-DELETE JOIN (flow-recipe-runs/index.js), checked against the
// actual DDL WITHOUT a live database. The route's own tests stub the driver,
// so a wrong column name on either side of the JOIN passes both runners and
// 500s a real database mid-delete — the shape this file exists to catch.
'use strict';

const { describe, it, before } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const dbKey = require.resolve('../../../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: {}, t: (n) => n },
};

const { buildEngineTableDDLs, buildInfraTableDDLs } = require('../../../../src/table-ddls');
const { TABLES } = require('../../../../src/shared/constants');

const SQL_TYPES = /^`?([a-z_]+)`?\s+(?:CHAR|VARCHAR|INT|DOUBLE|TIMESTAMP|JSON|TEXT|LONGTEXT|ENUM|BOOLEAN|TINYINT|BIGINT|DATETIME|DECIMAL|FLOAT|BLOB)\b/i;
let columnsByTable;

before(() => {
  columnsByTable = new Map();
  for (const ddl of [...buildInfraTableDDLs((n) => n), ...buildEngineTableDDLs((n) => n)]) {
    const m = ddl.match(/CREATE TABLE IF NOT EXISTS `([^`]+)`/);
    if (!m) continue;
    const cols = new Set();
    for (const rawLine of ddl.split('\n')) {
      const line = rawLine.trim();
      if (!line || line.startsWith('--') || line.startsWith('/*')) continue;
      const cm = line.match(SQL_TYPES);
      if (cm) cols.add(cm[1]);
    }
    columnsByTable.set(m[1], cols);
  }
});

// Read out of the source rather than restated here — a hand-copied column list
// can agree with the DDL while the statement itself does not, the exact
// failure mode this file exists to catch.
const SRC = fs.readFileSync(
  path.resolve(__dirname, '../../../../src/edge/routes/app/flow-recipe-runs/index.js'), 'utf8',
);

describe('run DELETE — atomic template-access JOIN, schema parity', () => {
  it('still binds the template-access predicate into the DELETE (not a separate pre-check)', () => {
    // Pins the shape of the fix itself: an editor's DELETE must join to
    // user_templates and gate on it in the SAME statement that deletes, not a
    // SELECT that ran and was trusted beforehand.
    assert.match(SRC, /DELETE r FROM \\`\$\{t\(TABLES\.FLOW_RECIPE_RUNS\)\}\\` r/);
    assert.match(SRC, /JOIN \\`\$\{t\(TABLES\.USER_TEMPLATES\)\}\\` ut ON ut\.\\`id\\` = r\.\\`template_id\\`/);
    assert.match(SRC, /ut\.\\`owner_id\\` IS NOT NULL AND \(ut\.\\`owner_id\\`=\? OR \$\{access\.sql\}\)/);
  });

  it('every column the JOIN and its WHERE name exists on the table it names it on', () => {
    const runs = columnsByTable.get(String(TABLES.FLOW_RECIPE_RUNS));
    const templates = columnsByTable.get(String(TABLES.USER_TEMPLATES));
    assert.ok(runs && runs.size > 0, 'flow_recipe_runs has no parsed columns');
    assert.ok(templates && templates.size > 0, 'user_templates has no parsed columns');
    for (const col of ['id', 'actor_id', 'template_id']) {
      assert.ok(runs.has(col), `flow_recipe_runs is missing '${col}' (the DELETE names it)`);
    }
    for (const col of ['id', 'owner_id']) {
      assert.ok(templates.has(col), `user_templates is missing '${col}' (the JOIN/WHERE names it)`);
    }
  });
});
