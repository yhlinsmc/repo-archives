/**
 * flow-recipe-runs-generic-get-excludes-step-results.test.js
 *
 * The generic CRUD mount (GET /, GET /:id) is not the browser's read port
 * for step_results — aggregate.js's `GET /runs/:runId` is, and reads the
 * column via CAST(... AS CHAR) specifically to avoid the round the DTO
 * mapper's JSON.parse otherwise inflicts on a large integer inside it. This
 * file pins that the generic mount's `serializeRead` drops the field rather
 * than leaving a second, un-hardened read port open on the same data.
 *
 * remote_refs is pinned here for the SAME reason: it is registered JSON on
 * this table exactly like step_results, and aggregate.js's `readRunDetail` is
 * meant to stay its only read port — a caller reading the run's captured-refs
 * snapshot through the generic mount instead would bypass that route entirely.
 */
const { test } = require('node:test');
const assert = require('node:assert');
const express = require('express');

const dbKey = require.resolve('../../../../src/edge/db');

const RUN_ID = '5b38f3eb-678d-4b05-8fea-72f9c807341b';
const ACTOR_ID = '405279b5-48c7-4bd5-8427-69d6ff5556a7';
const STORED_STEP_RESULTS = JSON.stringify([{ step_id: 's1', status: 'ok' }]);
const STORED_REMOTE_REFS = JSON.stringify({ tasks: [{ id: 't1' }] });

const conn = {
  beginTransaction: async () => {},
  commit: async () => {},
  rollback: async () => {},
  release: () => {},
  query: async (sql, params) => {
    const norm = sql.replace(/\s+/g, ' ').trim();
    if (/information_schema/i.test(sql)) {
      return [{ COLUMN_NAME: 'id' }, { COLUMN_NAME: 'actor_id' }, { COLUMN_NAME: 'recipe_id' },
        { COLUMN_NAME: 'status' }, { COLUMN_NAME: 'error_summary' }, { COLUMN_NAME: 'step_results' },
        { COLUMN_NAME: 'remote_refs' }, { COLUMN_NAME: 'created_at' }];
    }
    if (/SELECT DATABASE\(\)/i.test(sql)) return [{ db: 'testdb' }];
    if (/^SELECT COUNT\(\*\)/i.test(norm)) return [{ cnt: 1 }];
    if (/^UPDATE `flow_recipe_runs`/i.test(norm)) return { affectedRows: 1 };
    if (/^SELECT \* FROM `flow_recipe_runs`/i.test(norm)) {
      return [{
        id: RUN_ID, actor_id: ACTOR_ID, recipe_id: '110095e1-0ac0-43a2-8777-9449936efcdd',
        status: 'success', error_summary: null, step_results: STORED_STEP_RESULTS,
        remote_refs: STORED_REMOTE_REFS,
        created_at: '2026-01-01 00:00:00',
      }];
    }
    return { affectedRows: 1 };
  },
};

require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: {
    pool: { rw: { getConnection: async () => conn, query: conn.query }, ro: { getConnection: async () => conn, query: conn.query } },
    t: (x) => x,
    getDynamicPool: async () => ({ rw: { getConnection: async () => conn, query: conn.query }, ro: { query: conn.query } }),
  },
};

const runsRouter = require('../../../../src/edge/routes/app/flow-recipe-runs');

function app(user) {
  const a = express();
  a.use(express.json());
  a.use((req, _res, next) => { req.user = user; next(); });
  a.use('/', runsRouter);
  return a;
}

async function get(a, path) {
  const server = a.listen(0);
  const port = server.address().port;
  try {
    const res = await fetch(`http://127.0.0.1:${port}${path}`);
    return { status: res.status, body: await res.json() };
  } finally { server.close(); }
}

const EDITOR = { id: ACTOR_ID, role: 'editor' };

test('generic GET /:id omits step_results from the response row', async () => {
  const { status, body } = await get(app(EDITOR), `/${RUN_ID}`);
  assert.equal(status, 200);
  assert.equal(Object.prototype.hasOwnProperty.call(body.data, 'step_results'), false,
    'the generic detail route must not carry step_results — only the hardened runs/:runId route may');
  assert.equal(body.data.id, RUN_ID, 'the rest of the row still comes through');
});

test('generic GET / (list) omits step_results from every row', async () => {
  const { status, body } = await get(app(EDITOR), '/');
  assert.equal(status, 200);
  assert.ok(Array.isArray(body.data) && body.data.length > 0, 'the fixture row is present');
  for (const row of body.data) {
    assert.equal(Object.prototype.hasOwnProperty.call(row, 'step_results'), false,
      'the generic list route must not carry step_results');
  }
});

test('generic GET /:id omits remote_refs from the response row', async () => {
  const { status, body } = await get(app(EDITOR), `/${RUN_ID}`);
  assert.equal(status, 200);
  assert.equal(Object.prototype.hasOwnProperty.call(body.data, 'remote_refs'), false,
    'the generic detail route must not carry remote_refs — only aggregate.js readRunDetail may');
  assert.equal(body.data.id, RUN_ID, 'the rest of the row still comes through');
});

test('generic GET / (list) omits remote_refs from every row', async () => {
  const { status, body } = await get(app(EDITOR), '/');
  assert.equal(status, 200);
  assert.ok(Array.isArray(body.data) && body.data.length > 0, 'the fixture row is present');
  for (const row of body.data) {
    assert.equal(Object.prototype.hasOwnProperty.call(row, 'remote_refs'), false,
      'the generic list route must not carry remote_refs');
  }
});
