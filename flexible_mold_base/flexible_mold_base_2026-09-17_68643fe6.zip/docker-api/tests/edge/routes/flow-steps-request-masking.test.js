// docker-api/tests/edge/routes/flow-steps-request-masking.test.js
//
// The dispatched-step `request` field attached to
// EVERY /prepare response (test or not) is relayed unmasked to a browser
// that only needs to be authenticated (POST /api/flow-recipe-steps/:id/
// dispatch has no manage-authority gate — /prepare's own gate is the only
// one on the path). `request` must therefore come from the SAME masked
// re-resolution `request_sent` already uses (`resolveMaskedDisplay`,
// serializer.js), never from the real (unmasked) dispatch's own `resolved`.
// Harness mirrors flow-steps-request-sent.test.js.
const { test, beforeEach } = require('node:test');
const assert = require('node:assert');
const express = require('express');

process.env.SETTINGS_ENCRYPTION_KEY = 'unit-test-key-do-not-use-in-prod';

const fakeRows = { step: null, recipe: null, blueprint: null, run: null, template: null, nodes: null, owner: null, blueprintNode: null };
const conn = {
  query: async (sql) => {
    if (/FROM `flow_recipe_steps`/.test(sql)) return fakeRows.step ? [fakeRows.step] : [];
    if (/FROM `flow_recipe_runs`/.test(sql)) return fakeRows.run ? [fakeRows.run] : [];
    if (/FROM `flow_recipes`/.test(sql)) return fakeRows.recipe ? [fakeRows.recipe] : [];
    if (/FROM `user_templates`/.test(sql)) return fakeRows.template ? [fakeRows.template] : [];
    if (/FROM `hierarchy_nodes`/.test(sql)) {
      if (/SELECT id, name/.test(sql)) return fakeRows.nodes || [];
      if (/SELECT name FROM/.test(sql)) return fakeRows.blueprintNode ? [fakeRows.blueprintNode] : [];
      return fakeRows.blueprint ? [fakeRows.blueprint] : [];
    }
    if (/FROM `users`/.test(sql)) return fakeRows.owner ? [fakeRows.owner] : [];
    if (/INSERT INTO `feature_audit`/.test(sql)) return { affectedRows: 1 };
    return [];
  },
  release: () => {},
};
require.cache[require.resolve('../../../src/edge/db')] = {
  exports: {
    pool: { rw: { getConnection: async () => conn }, ro: { query: async () => [] } },
    t: (x) => x,
  },
};

const router = require('../../../src/edge/routes/internal/flow-steps');

function appWith(user) {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { req.user = user; next(); });
  app.use('/edge/internal/flow-steps', router);
  return app;
}
async function post(app, path, body) {
  const server = app.listen(0);
  try {
    const port = server.address().port;
    const res = await fetch(`http://127.0.0.1:${port}${path}`, {
      method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body),
    });
    const json = await res.json();
    return { status: res.status, json };
  } finally {
    server.close();
  }
}

beforeEach(() => {
  fakeRows.step = null; fakeRows.recipe = null; fakeRows.blueprint = null;
  fakeRows.run = null; fakeRows.template = null; fakeRows.nodes = null; fakeRows.owner = null;
  fakeRows.blueprintNode = null;
});

test('edge-mode /prepare: envelope.request.url masks a templated secret input on a PRODUCTION (non-test) dispatch', async () => {
  const connDispatch = require('../../../src/edge/lib/connector-dispatch');
  const origExecute = connDispatch.executeRequest;
  connDispatch.executeRequest = async () => ({ upstream_status: 200, headers: {}, body: '{"ok":true}', duration_ms: 3 });
  try {
    const REAL_SECRET = 'sk-REAL-URL-DISTINCT-9c2a';
    fakeRows.step = {
      id: 's_f1_url', recipe_id: 'r_f1_url', name: 'f1-request-url',
      method: 'GET', url: 'https://vendor.example/api?api_key={{payload.api_key}}',
      auth_type: 'none', auth_config: null,
      request_config: '{}', response_config: '{}',
      input_from_step: null, timeout_ms: null,
      dispatch_origin: 'edge',
    };
    fakeRows.recipe = { is_active: 1, status: 'approved' };

    // No `test: true` — `request` is attached on EVERY dispatch, not just test.
    const { status, json } = await post(
      appWith({ id: 'u1', role: 'editor' }),
      '/edge/internal/flow-steps/prepare',
      { step_id: 's_f1_url', inputs: { api_key: REAL_SECRET } },
    );

    assert.strictEqual(status, 200, `expected 200, got ${status}: ${JSON.stringify(json)}`);
    assert.strictEqual(json.data.test, false);
    const req = json.data.envelope.request;
    assert.ok(req, 'envelope.request must be present on a production dispatch too');
    assert.ok(!req.url.includes(REAL_SECRET), `request.url leaked the secret: ${req.url}`);
    assert.ok(!('request_sent' in json.data.envelope), 'a production dispatch must carry no request_sent key at all');
    // S-1 style whole-response check: the real secret must not survive anywhere
    // in the object actually sent to the browser.
    assert.ok(!JSON.stringify(json).includes(REAL_SECRET),
      `the real secret leaked into the response sent to the browser: ${JSON.stringify(json)}`);
  } finally {
    connDispatch.executeRequest = origExecute;
  }
});

test('edge-mode /prepare: envelope.request.body masks a secret-shaped JSON key filled from a dispatch input', async () => {
  const connDispatch = require('../../../src/edge/lib/connector-dispatch');
  const origExecute = connDispatch.executeRequest;
  connDispatch.executeRequest = async () => ({ upstream_status: 200, headers: {}, body: '{"ok":true}', duration_ms: 3 });
  try {
    const REAL_SECRET = 'sk-REAL-BODY-DISTINCT-7e1f';
    fakeRows.step = {
      id: 's_f1_body', recipe_id: 'r_f1_body', name: 'f1-request-body',
      method: 'POST', url: 'https://vendor.example/tasks',
      auth_type: 'none', auth_config: null,
      request_config: JSON.stringify({ body: '{"client_secret":"{{payload.client_secret}}"}' }),
      response_config: '{}',
      input_from_step: null, timeout_ms: null,
      dispatch_origin: 'edge',
    };
    fakeRows.recipe = { is_active: 1, status: 'approved' };

    const { status, json } = await post(
      appWith({ id: 'u1', role: 'editor' }),
      '/edge/internal/flow-steps/prepare',
      { step_id: 's_f1_body', inputs: { client_secret: REAL_SECRET } },
    );

    assert.strictEqual(status, 200, `expected 200, got ${status}: ${JSON.stringify(json)}`);
    const req = json.data.envelope.request;
    assert.strictEqual(req.body, '{"client_secret":"****"}');
    assert.ok(!JSON.stringify(json).includes(REAL_SECRET),
      `the real secret leaked into the response sent to the browser: ${JSON.stringify(json)}`);
  } finally {
    connDispatch.executeRequest = origExecute;
  }
});

// resolveAndPin is not stubbed — an RFC1918 IP literal resolves synchronously
// without DNS (matches the infra-mode multipart test in flow-steps.test.js).
test('infra-mode /prepare: data.request.url is masked while data.prepared.url (S2S-only) keeps the real value', async () => {
  const REAL_SECRET = 'sk-REAL-INFRA-DISTINCT-4b8d';
  fakeRows.step = {
    id: 's_f1_infra', recipe_id: 'r_f1_infra', name: 'f1-request-infra',
    method: 'GET', url: 'https://192.168.1.100/api?access_token={{payload.access_token}}',
    auth_type: 'none', auth_config: null,
    request_config: '{}', response_config: '{}',
    input_from_step: null, timeout_ms: null,
    dispatch_origin: 'infra',
  };
  fakeRows.recipe = { is_active: 1, status: 'approved', owner_id: 'editor1', blueprint_id: null };

  const { status, json } = await post(
    appWith({ id: 'editor1', role: 'editor' }),
    '/edge/internal/flow-steps/prepare',
    { step_id: 's_f1_infra', inputs: { access_token: REAL_SECRET } },
  );

  assert.strictEqual(status, 200, `expected 200, got ${status}: ${JSON.stringify(json)}`);
  assert.strictEqual(json.data.mode, 'infra');
  assert.ok(json.data.request, 'data.request must be present');
  assert.ok(!json.data.request.url.includes(REAL_SECRET), `data.request.url leaked the secret: ${json.data.request.url}`);
  assert.ok(json.data.prepared.url.includes(REAL_SECRET), 'data.prepared.url (S2S-only, real secret) must still carry the real value');
});

test('edge-mode /prepare: envelope.request.body (multipart) is the FILE PART\'S TEXT from the masked resolution, secret masked', async () => {
  const connDispatch = require('../../../src/edge/lib/connector-dispatch');
  const origExecute = connDispatch.executeRequest;
  connDispatch.executeRequest = async () => ({ upstream_status: 200, headers: {}, body: '{"ok":true}', duration_ms: 3 });
  try {
    const REAL_SECRET = 'sk-REAL-MULTIPART-DISTINCT-2a6e';
    fakeRows.step = {
      id: 's_f1_mp', recipe_id: 'r_f1_mp', name: 'f1-request-multipart',
      method: 'POST', url: 'https://vendor.example/upload',
      auth_type: 'none', auth_config: null,
      request_config: JSON.stringify({
        headers: {}, body: '{"token":"{{payload.token}}"}',
        body_type: 'multipart', file_field: 'upload', file_name: 'payload.json',
        file_content_type: 'application/json',
      }),
      response_config: '{}',
      input_from_step: null, timeout_ms: null,
      dispatch_origin: 'edge',
    };
    fakeRows.recipe = { is_active: 1, status: 'approved' };

    const { status, json } = await post(
      appWith({ id: 'u1', role: 'editor' }),
      '/edge/internal/flow-steps/prepare',
      { step_id: 's_f1_mp', inputs: { token: REAL_SECRET } },
    );

    assert.strictEqual(status, 200, `expected 200, got ${status}: ${JSON.stringify(json)}`);
    const req = json.data.envelope.request;
    assert.strictEqual(req.content_type, 'application/json');
    assert.strictEqual(req.body, '{"token":"****"}');
    assert.ok(!JSON.stringify(json).includes(REAL_SECRET),
      `the real secret leaked into the response sent to the browser: ${JSON.stringify(json)}`);
  } finally {
    connDispatch.executeRequest = origExecute;
  }
});

// A secret hand-typed as a
// LITERAL straight into the connector's own url/body template (no `{{}}`)
// is never touched by the masked RESOLUTION (there is no template slot for
// it to substitute) — only the residual maskRequestUrl / maskSerializedPayload
// passes catch it, and requestForEntry used to skip those passes entirely.
test('edge-mode /prepare: envelope.request masks a LITERAL secret baked into the connector url/body template (no {{}})', async () => {
  const connDispatch = require('../../../src/edge/lib/connector-dispatch');
  const origExecute = connDispatch.executeRequest;
  connDispatch.executeRequest = async () => ({ upstream_status: 200, headers: {}, body: '{"ok":true}', duration_ms: 3 });
  try {
    const REAL_SECRET = 'sk-LITERAL-TEMPLATE-DISTINCT-3f9c';
    fakeRows.step = {
      id: 's_f11_literal', recipe_id: 'r_f11_literal', name: 'f11-request-literal',
      method: 'POST', url: `https://vendor.example/api?api_key=${REAL_SECRET}`,
      auth_type: 'none', auth_config: null,
      request_config: JSON.stringify({ body: `{"client_secret":"${REAL_SECRET}"}` }),
      response_config: '{}',
      input_from_step: null, timeout_ms: null,
      dispatch_origin: 'edge',
    };
    fakeRows.recipe = { is_active: 1, status: 'approved' };

    const { status, json } = await post(
      appWith({ id: 'u1', role: 'editor' }),
      '/edge/internal/flow-steps/prepare',
      { step_id: 's_f11_literal', inputs: {} },
    );

    assert.strictEqual(status, 200, `expected 200, got ${status}: ${JSON.stringify(json)}`);
    const req = json.data.envelope.request;
    assert.ok(req, 'envelope.request must be present');
    assert.ok(req.url.includes('api_key=****'), `request.url leaked the literal secret: ${req.url}`);
    assert.ok(req.body.includes('"client_secret":"****"'), `request.body leaked the literal secret: ${req.body}`);
    assert.ok(!JSON.stringify(json).includes(REAL_SECRET),
      `the real literal secret leaked into the response sent to the browser: ${JSON.stringify(json)}`);
  } finally {
    connDispatch.executeRequest = origExecute;
  }
});

// An edge-origin execute throw (runEdgeExecute rejecting after /prepare
// had already built the masked request) must still relay that request via
// error.details.request — the same shape the infra-origin failure path
// already gives — so a one-shot or browser dispatch persists the attempted
// request on a timeout/unreachable failure, not just on success.
test('edge-mode /prepare: an execute throw AFTER the request was built relays it via error.details.request, masked', async () => {
  const connDispatch = require('../../../src/edge/lib/connector-dispatch');
  const origExecute = connDispatch.executeRequest;
  connDispatch.executeRequest = async () => { const e = new Error('boom'); e.code = 'CONNECTOR_UNREACHABLE'; throw e; };
  try {
    const REAL_SECRET = 'sk-REAL-EXECFAIL-DISTINCT-6d1a';
    fakeRows.step = {
      id: 's_f12', recipe_id: 'r_f12', name: 'f12-request-on-failure',
      method: 'POST', url: 'https://vendor.example/tasks',
      auth_type: 'none', auth_config: null,
      request_config: JSON.stringify({ body: '{"client_secret":"{{payload.client_secret}}"}' }),
      response_config: '{}',
      input_from_step: null, timeout_ms: null,
      dispatch_origin: 'edge',
    };
    fakeRows.recipe = { is_active: 1, status: 'approved' };

    const { status, json } = await post(
      appWith({ id: 'u1', role: 'editor' }),
      '/edge/internal/flow-steps/prepare',
      { step_id: 's_f12', inputs: { client_secret: REAL_SECRET } },
    );

    assert.strictEqual(status, 502, `expected 502, got ${status}: ${JSON.stringify(json)}`);
    assert.strictEqual(json.error.code, 'CONNECTOR_UNREACHABLE');
    const req = json.error.details && json.error.details.request;
    assert.ok(req, 'error.details.request must be present on an edge-origin execute failure');
    assert.strictEqual(req.method, 'POST');
    assert.strictEqual(req.body, '{"client_secret":"****"}');
    assert.ok(!JSON.stringify(json).includes(REAL_SECRET),
      `the real secret leaked into the failure response: ${JSON.stringify(json)}`);
  } finally {
    connDispatch.executeRequest = origExecute;
  }
});
