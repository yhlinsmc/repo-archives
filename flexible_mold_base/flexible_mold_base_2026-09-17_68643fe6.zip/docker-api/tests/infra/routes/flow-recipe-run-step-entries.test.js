// docker-api/tests/infra/routes/flow-recipe-run-step-entries.test.js
//
// Unit tests for the step_results entry shape produced by POST
// /api/flow-recipes/:id/run (infra server-run orchestrator): step_name +
// failed-step error_body (PR-2 Task 4). Harness mirrors
// tests/unit/flow-recipe-run-route.test.js: mocks injected via require.cache
// before requiring the module under test; each test resets mutable mock state.
//
// Run:
//   cd docker-api && NODE_ENV=test node --test tests/infra/routes/flow-recipe-run-step-entries.test.js
const { test } = require('node:test');
const assert = require('node:assert');
const express = require('express');
const { stubLoggerModule } = require('../../helpers/stub-logger-module');

// ── Mutable mock state — reset per test ──────────────────────────────────────
const edgeCalls = [];
const dispatchCalls = [];
let forwardToEdgeImpl = async () => ({ status: 200, data: { ok: true } });
let dispatchOneStepImpl = async () => ({
  ok: true, status: 200,
  envelope: { upstream_status: 200, body: '{}' },
});

// ── Cache injection (before any require of the module under test) ─────────────
require.cache[require.resolve('../../../src/infra/lib/remote-client')] = {
  exports: {
    forwardToEdge: async (opts) => {
      edgeCalls.push(opts);
      return forwardToEdgeImpl(opts);
    },
    passthroughResponse: (_req, res, result) => {
      res.status(result.status).json(result.data);
    },
  },
};

require.cache[require.resolve('../../../src/infra/lib/flow-dispatch-step')] = {
  exports: {
    dispatchOneStep: async (opts) => {
      dispatchCalls.push(opts);
      return dispatchOneStepImpl(opts);
    },
  },
};

// Derives from the real module so every other export (e.g. captureCallerSrc)
// stays present for sendError.
stubLoggerModule(require.resolve('../../../src/shared/lib/logger'), {
  logger: { child: () => ({ warn: () => {}, error: () => {}, info: () => {} }) },
});

const mountFlowRecipeRun = require('../../../src/infra/routes/flow-recipe-run');

// ── Test helpers ──────────────────────────────────────────────────────────────

function makeApp({ user } = {}) {
  const a = express();
  a.use(express.json());
  if (user) {
    a.use((req, _res, next) => { req.user = user; req.id = 'test-req-id'; next(); });
  }
  mountFlowRecipeRun(a);
  return a;
}

async function post(app, path, body) {
  const server = app.listen(0);
  const port = server.address().port;
  try {
    const res = await fetch(`http://127.0.0.1:${port}${path}`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(body),
    });
    const json = await res.json();
    return { status: res.status, body: json };
  } finally {
    server.close();
  }
}

function runBeginOk(steps, skippedSteps, mode) {
  return {
    status: 200,
    data: {
      data: {
        run_id: 'run1',
        steps,
        skipped_steps: skippedSteps ?? [],
        serialized_payload: '{"a":1}',
        // Edge's own EFFECTIVE mode (template-driven push mode, or the
        // omitted-mode default) — the route reads this, never the raw
        // `mode` it forwarded in the run-begin request body.
        mode: mode ?? 'create',
      },
    },
  };
}

const RUN_FINALIZE_FAILED = {
  status: 200,
  data: { data: { runId: 'run1', status: 'failed', link: null, externalId: null } },
};

const RUN_FINALIZE_SUCCESS = {
  status: 200,
  data: { data: { runId: 'run1', status: 'success', link: null, externalId: null } },
};

async function runStepEntries({ steps, dispatchImpl, finalize }) {
  edgeCalls.length = 0;
  dispatchCalls.length = 0;
  forwardToEdgeImpl = async (opts) => {
    if (opts.path.endsWith('/run-begin')) return runBeginOk(steps);
    if (opts.path.endsWith('/run-finalize')) return finalize;
    return { status: 200, data: { ok: true } };
  };
  dispatchOneStepImpl = dispatchImpl;

  const app = makeApp({ user: { id: 'u', role: 'user' } });
  await post(app, '/api/flow-recipes/r1/run', { payload: { a: 1 } });

  const finalizeCall = edgeCalls.find((c) => c.path.endsWith('/run-finalize'));
  assert.ok(finalizeCall, 'run-finalize must be called');
  return JSON.parse(finalizeCall.body.step_results);
}

// ── Tests ─────────────────────────────────────────────────────────────────────

test('(a) success entry carries step_name, no error_body key', async () => {
  const parsed = await runStepEntries({
    steps: [{ id: 's1', sequence: 1, name: 'Push data' }],
    dispatchImpl: async () => ({ ok: true, status: 200, envelope: { upstream_status: 200, body: '{}' } }),
    finalize: RUN_FINALIZE_SUCCESS,
  });

  assert.equal(parsed.length, 1);
  assert.deepEqual(parsed[0], { step_id: 's1', step_name: 'Push data', ok: true, upstream_status: 200, sequence: 1 });
  assert.ok(!('error_body' in parsed[0]), 'a successful step entry must not carry error_body');
});

// D6 (UX-3, fmb-2168): run-begin's `skipped_steps` (the complement under this
// run's mode) merges into this loop's own step_results, sorted by sequence
// with the dispatched entries — so this producer's run detail lists every
// step, not only the ones it actually dispatched.
//
// F1 (UX-3a fix batch, fmb-2168): every skipped entry also carries `run_mode`
// — the run's own effective mode, never inferred from `skip_reason:'mode'`
// alone (that value alone cannot tell an operator WHICH mode excluded the
// step). This is the FE↔infra parity point on the skipped-entry key set —
// `src/fmb/lib/flow/__tests__/run-chain.test.ts`'s matching assertion
// carries the identical key set for the browser-chain producer.
async function runSkippedMergeCase(mode) {
  edgeCalls.length = 0;
  dispatchCalls.length = 0;
  forwardToEdgeImpl = async (opts) => {
    if (opts.path.endsWith('/run-begin')) {
      return runBeginOk(
        [
          { id: 's1', sequence: 1, name: 'Both' },
          { id: 's3', sequence: 3, name: 'Also both' },
        ],
        [
          { id: 's2', sequence: 2, name: 'Create only', step_runs_on: 'create' },
          { id: 's4', sequence: 4, name: 'Update only', step_runs_on: 'update' },
        ],
        mode,
      );
    }
    if (opts.path.endsWith('/run-finalize')) return RUN_FINALIZE_SUCCESS;
    return { status: 200, data: { ok: true } };
  };
  dispatchOneStepImpl = async () => ({ ok: true, status: 200, envelope: { upstream_status: 200, body: '{}' } });

  const app = makeApp({ user: { id: 'u', role: 'user' } });
  await post(app, '/api/flow-recipes/r1/run', { payload: { a: 1 } });

  const finalizeCall = edgeCalls.find((c) => c.path.endsWith('/run-finalize'));
  return JSON.parse(finalizeCall.body.step_results);
}

test('(UX-3) skipped_steps merge into step_results, sorted by sequence with dispatched entries', async () => {
  const parsed = await runSkippedMergeCase('create');
  assert.deepEqual(parsed, [
    { step_id: 's1', step_name: 'Both', ok: true, upstream_status: 200, sequence: 1 },
    { step_id: 's2', step_name: 'Create only', ok: true, skipped: true, skip_reason: 'mode', sequence: 2, run_mode: 'create' },
    { step_id: 's3', step_name: 'Also both', ok: true, upstream_status: 200, sequence: 3 },
    { step_id: 's4', step_name: 'Update only', ok: true, skipped: true, skip_reason: 'mode', sequence: 4, run_mode: 'create' },
  ]);
});

// F1: an UPDATE-mode run's skipped entries must carry `run_mode: 'update'`
// — the bug this batch closes hardcoded "create mode" in the chip regardless
// of the run's actual mode, so a red case here is the one that pins it.
test('(UX-3a F1) an update-mode run stamps run_mode: "update" on every skipped entry', async () => {
  const parsed = await runSkippedMergeCase('update');
  const skipped = parsed.filter((e) => e.skipped);
  assert.equal(skipped.length, 2);
  for (const e of skipped) assert.equal(e.run_mode, 'update');
});

// PR-2 review F1: infra never slices a raw upstream body — it relays
// it INTACT up to the transport cap (32768) or replaces it with a placeholder
// that carries none of the upstream bytes. Slicing raw bytes before the edge
// masker sees them is the defect this batch closes (empirically reproduced:
// a body sliced mid-token failed both the masker's JSON and YAML parse and
// stored the truncated-but-still-raw text, secrets included).
test('(b) a body under the transport cap is relayed INTACT, not truncated to the old 8192 storage cap', async () => {
  const body = 'X'.repeat(9000); // over the old 8192 storage cap, well under the 32768 transport cap
  const parsed = await runStepEntries({
    steps: [{ id: 's1', sequence: 1, name: 'Push data' }],
    dispatchImpl: async () => ({ ok: true, status: 200, envelope: { upstream_status: 502, body } }),
    finalize: RUN_FINALIZE_FAILED,
  });

  assert.equal(parsed.length, 1);
  assert.equal(parsed[0].step_id, 's1');
  assert.equal(parsed[0].step_name, 'Push data');
  assert.equal(parsed[0].ok, false);
  assert.equal(parsed[0].upstream_status, 502);
  assert.equal(parsed[0].error_body, body, 'a body under the transport cap must reach edge byte-for-byte, not sliced');
});

test('(c) transport failure entry carries error_body = transport message', async () => {
  const parsed = await runStepEntries({
    steps: [{ id: 's1', sequence: 1, name: 'Push data' }],
    dispatchImpl: async () => ({
      ok: false, status: 502, errorCode: 'CONNECTOR_UNREACHABLE', message: 'Connection refused',
    }),
    finalize: RUN_FINALIZE_FAILED,
  });

  assert.equal(parsed.length, 1);
  assert.equal(parsed[0].step_id, 's1');
  assert.equal(parsed[0].step_name, 'Push data');
  assert.equal(parsed[0].ok, false);
  // `status: 502` here is dispatchOneStep's OWN classification of a
  // transport failure, never a reply from the dispatch target — recording
  // it as upstream_status made a trace reader treat "nothing was sent" as
  // "dispatched, body not recorded" (the same fix `content_type` already
  // had above it via relayContentType).
  assert.equal(parsed[0].upstream_status, null);
  assert.equal(parsed[0].error_body, 'Connection refused');
});

test('(d) a body exactly at the transport cap is relayed intact, whole', async () => {
  const atCapBody = 'Y'.repeat(32768);
  const parsed = await runStepEntries({
    steps: [{ id: 's1', sequence: 1, name: 'Push data' }],
    dispatchImpl: async () => ({ ok: true, status: 200, envelope: { upstream_status: 500, body: atCapBody } }),
    finalize: RUN_FINALIZE_FAILED,
  });

  assert.equal(parsed[0].error_body.length, 32768, 'a body exactly at the transport cap must not be shortened');
  assert.equal(parsed[0].error_body, atCapBody);
});

// PR-2 review round 2 (F1-follow-up): a body over the transport cap
// used to send a placeholder STRING as error_body — which reproduced its own
// bug (a `[`-leading placeholder parses as a YAML flow sequence at the edge
// masker's structured-parse gate). Now it sets error_body_omitted (a char
// count) and sends NO error_body at all, so there is no text for the masker
// to mis-parse in the first place.
test('(F1) a body OVER the transport cap sets error_body_omitted, never error_body', async () => {
  const overCapBody = `{"access_token":"s3cret-token","padding":"${'Z'.repeat(33000)}"}`;
  const parsed = await runStepEntries({
    steps: [{ id: 's1', sequence: 1, name: 'Push data' }],
    dispatchImpl: async () => ({ ok: true, status: 200, envelope: { upstream_status: 500, body: overCapBody } }),
    finalize: RUN_FINALIZE_FAILED,
  });

  assert.ok(!('error_body' in parsed[0]),
    'an over-cap entry must carry no error_body at all — nothing of the raw body, not even a placeholder string');
  assert.equal(parsed[0].error_body_omitted, overCapBody.length);
});

// content_type threads through onto a failed entry only when the step
// round-tripped to a real HTTP response (an envelope with headers).
test('(e) a failed entry with an upstream Content-Type header records content_type verbatim', async () => {
  const parsed = await runStepEntries({
    steps: [{ id: 's1', sequence: 1, name: 'Push data' }],
    dispatchImpl: async () => ({
      ok: true, status: 200,
      envelope: { upstream_status: 500, body: '{"error":"boom"}', headers: { 'content-type': 'application/json; charset=utf-8' } },
    }),
    finalize: RUN_FINALIZE_FAILED,
  });

  assert.equal(parsed[0].content_type, 'application/json; charset=utf-8');
});

test('(f) a failed entry whose envelope carries no headers omits content_type', async () => {
  const parsed = await runStepEntries({
    steps: [{ id: 's1', sequence: 1, name: 'Push data' }],
    dispatchImpl: async () => ({
      ok: true, status: 200,
      envelope: { upstream_status: 500, body: 'boom' }, // no headers key at all
    }),
    finalize: RUN_FINALIZE_FAILED,
  });

  assert.ok(!('content_type' in parsed[0]), 'no headers on the envelope → no fabricated content_type');
});

// Network-error path (dispatchOneStep ok:false) never round-trips to an HTTP
// response, so there is no Content-Type to read — content_type must stay
// absent, never a fabricated/empty value.
test('(g) a transport failure entry (no HTTP response) omits content_type', async () => {
  const parsed = await runStepEntries({
    steps: [{ id: 's1', sequence: 1, name: 'Push data' }],
    dispatchImpl: async () => ({
      ok: false, status: 502, errorCode: 'CONNECTOR_UNREACHABLE', message: 'Connection refused',
    }),
    finalize: RUN_FINALIZE_FAILED,
  });

  assert.ok(!('content_type' in parsed[0]), 'a network-error entry has no HTTP response to read Content-Type from');
});

test('legacy step (no name from recipe lookup) omits step_name, still records error_body', async () => {
  const parsed = await runStepEntries({
    steps: [{ id: 's1', sequence: 1 }], // no `name` field — legacy fallback SELECT variant
    dispatchImpl: async () => ({ ok: true, status: 200, envelope: { upstream_status: 500, body: 'boom' } }),
    finalize: RUN_FINALIZE_FAILED,
  });

  assert.equal(parsed.length, 1);
  assert.ok(!('step_name' in parsed[0]), 'a step without a recorded name must omit step_name, not null/empty it');
  assert.equal(parsed[0].error_body, 'boom');
});

// flow-yaml-dialect PR-Y2 (fmb-2061): the server-orchestrated (no-JS) loop
// never changes the underlying payload value between steps, but two steps can
// still declare DIFFERENT dialects — each dispatch must carry ITS OWN step's
// bytes, not a single value computed once (previously from the recipe's
// retired content_type, then from run-begin's audit-only serialized_payload).
test('two steps with different dialects each dispatch with their OWN content_type/yaml_version', async () => {
  edgeCalls.length = 0;
  dispatchCalls.length = 0;
  forwardToEdgeImpl = async (opts) => {
    if (opts.path.endsWith('/run-begin')) {
      return runBeginOk([
        { id: 's1', sequence: 1, name: 'JSON step', content_type: 'application/json' },
        { id: 's2', sequence: 2, name: 'YAML step', content_type: 'application/yaml', yaml_version: '1.1' },
      ]);
    }
    if (opts.path.endsWith('/run-finalize')) return RUN_FINALIZE_SUCCESS;
    return { status: 200, data: { ok: true } };
  };
  dispatchOneStepImpl = async () => ({ ok: true, status: 200, envelope: { upstream_status: 200, body: '{}' } });

  const app = makeApp({ user: { id: 'u', role: 'user' } });
  await post(app, '/api/flow-recipes/r1/run', { payload: { flag: 'yes' } });

  assert.equal(dispatchCalls.length, 2);
  assert.equal(dispatchCalls[0].inputs.payload, '{"flag":"yes"}', 's1 (JSON) dispatches compact JSON');
  // 1.1 quotes yes/no/on/off — plain JSON (or 1.2's default) would send it unquoted.
  assert.equal(dispatchCalls[1].inputs.payload, 'flag: "yes"\n', 's2 (YAML 1.1) dispatches quoted YAML, not s1\'s JSON');
});

// UX-5 (fmb-2170, UX-3a sink): a step FAILING (as opposed to a mode-excluded
// step, D6 above) used to silently drop every later SELECTED step from
// step_results entirely — this run's detail then under-counted the
// recipe's own step list. Every step after the failed one must now carry
// its own entry, distinct from a mode skip (`skip_reason: 'failed_upstream'`
// never `'mode'`), and must never actually be dispatched.
test('(UX-5) a step that fails mid-chain marks every later SELECTED step failed_upstream, never dispatching it', async () => {
  const parsed = await runStepEntries({
    steps: [
      { id: 's1', sequence: 1, name: 'First' },
      { id: 's2', sequence: 2, name: 'Second (fails)' },
      { id: 's3', sequence: 3, name: 'Third (never reached)' },
    ],
    dispatchImpl: async (opts) => (
      opts.stepId === 's2'
        ? { ok: true, status: 200, envelope: { upstream_status: 500, body: 'boom' } }
        : { ok: true, status: 200, envelope: { upstream_status: 200, body: '{}' } }
    ),
    finalize: RUN_FINALIZE_FAILED,
  });

  assert.equal(parsed.length, 3, 'the failed step and the never-reached step must both still get an entry');
  assert.equal(parsed[0].step_id, 's1');
  assert.equal(parsed[0].ok, true);
  assert.equal(parsed[1].step_id, 's2');
  assert.equal(parsed[1].ok, false);
  assert.deepEqual(parsed[2], {
    step_id: 's3', step_name: 'Third (never reached)', sequence: 3,
    ok: true, skipped: true, skip_reason: 'failed_upstream',
  });
  assert.ok(!dispatchCalls.some((c) => c.stepId === 's3'), 's3 must never actually be dispatched once s2 failed');
});
