// docker-api/tests/infra/flow-dispatch-step-request-sent.test.js
//
// fmb-2045 (PR-U5): dispatchOneStep threads request_sent (the masked resolved
// request the edge built) onto the envelope it returns — unchanged in edge
// mode (already folded into the envelope by edge), copied verbatim in infra
// mode (never masked by infra — infra owns no masker; infra-talks-to-edge-only).
// Mocks: forwardToEdge, executeRequest, isBlockedIp — same harness as
// tests/unit/flow-dispatch-step.test.js.
const { test } = require('node:test');
const assert = require('node:assert');
const fs = require('node:fs');
const path = require('node:path');
const { stubLoggerModule } = require('../helpers/stub-logger-module');

let forwardToEdgeImpl = async () => ({ status: 200, data: { ok: true } });
let executeRequestImpl = async () => ({ upstream_status: 200, headers: {}, body: '{}', duration_ms: 5 });
let isBlockedIpImpl = () => false;
const edgeCalls = [];

require.cache[require.resolve('../../src/infra/lib/remote-client')] = {
  exports: {
    forwardToEdge: async (opts) => { edgeCalls.push(opts); return forwardToEdgeImpl(opts); },
  },
};
require.cache[require.resolve('../../src/shared/lib/connector-http')] = {
  exports: { executeRequest: async (req, opts) => executeRequestImpl(req, opts) },
};
require.cache[require.resolve('../../src/shared/lib/ssrf-guard')] = {
  exports: { isBlockedIp: (ip) => isBlockedIpImpl(ip) },
};
// Derives from the real module so every other export (e.g. captureCallerSrc)
// stays present for sendError.
stubLoggerModule(require.resolve('../../src/shared/lib/logger'), {
  logger: { child: () => ({ warn: () => {}, error: () => {}, info: () => {} }) },
});

const { dispatchOneStep } = require('../../src/infra/lib/flow-dispatch-step');

const USER = { id: 'u1', role: 'editor' };

test('edge-mode: envelope.request_sent passes through unchanged from the mocked prepare envelope', async () => {
  edgeCalls.length = 0;
  const requestSent = { method: 'POST', url: 'https://ok.test/x', headers: { Authorization: '****' }, body: '{}' };
  forwardToEdgeImpl = async (opts) => {
    if (opts.path.endsWith('/prepare')) {
      return { status: 200, data: { data: { mode: 'edge', envelope: { upstream_status: 201, body: '{"id":1}', request_sent: requestSent } } } };
    }
    return { status: 200, data: { ok: true } };
  };

  const r = await dispatchOneStep({ stepId: 's1', inputs: { payload: '{}' }, runId: null, test: false, user: USER, reqId: 'r1' });

  assert.strictEqual(r.ok, true);
  assert.deepStrictEqual(r.envelope.request_sent, requestSent);
  // S-1 (fmb-2045 PR-U5 fix batch 1): edge mode's envelope is a straight
  // passthrough of data.envelope — pin its exact shape so a stray merge from
  // some OTHER field of the prepare response (there is no data.prepared in
  // edge mode, but the shape a future refactor could introduce) cannot slip
  // an extra key in unnoticed.
  assert.deepStrictEqual(Object.keys(r.envelope).sort(), ['body', 'request_sent', 'upstream_status']);
});

test('infra-mode: envelope.request_sent equals the masked data.request_sent, never data.prepared.headers', async () => {
  edgeCalls.length = 0;
  const maskedRequestSent = { method: 'POST', url: 'https://ok.test/x', headers: { Authorization: '****' }, body: '{}' };
  // S-1: a distinctive literal, not reused by any other test in this file, so
  // a JSON.stringify(envelope).includes() check cannot pass by accident on a
  // substring some other fixture also happens to contain.
  const REAL_SECRET = 'sk-REAL-S1-DISTINCT-9f3c';
  forwardToEdgeImpl = async (opts) => {
    if (opts.path.endsWith('/prepare')) {
      return {
        status: 200,
        data: {
          data: {
            mode: 'infra', dispatch_id: 'd1', recipe_id: 'rc1',
            request_sent: maskedRequestSent,
            prepared: {
              method: 'POST', url: 'https://ok.test/x', headers: { Authorization: `Bearer ${REAL_SECRET}` }, body: '{}',
              pinned_ip: '93.184.216.34', family: 4, timeout_ms: 10000, max_bytes: 1000000,
            },
          },
        },
      };
    }
    return { status: 200, data: { ok: true } };
  };
  executeRequestImpl = async () => ({ upstream_status: 200, headers: {}, body: '{"ok":true}', duration_ms: 7 });
  isBlockedIpImpl = () => false;

  const r = await dispatchOneStep({ stepId: 's1', inputs: {}, runId: 'run1', test: false, user: USER, reqId: 'r1' });

  assert.strictEqual(r.ok, true);
  assert.deepStrictEqual(r.envelope.request_sent, maskedRequestSent);
  assert.notDeepStrictEqual(r.envelope.request_sent.headers, { Authorization: `Bearer ${REAL_SECRET}` });
  // S-1: the whole-envelope assertion the per-field checks above cannot give —
  // a spread of data.prepared onto the envelope (the reviewed mutation at
  // flow-dispatch-step.js's infra-mode return) would leak the real secret
  // through headers/method/url/body even if request_sent itself stayed correct.
  assert.ok(!JSON.stringify(r.envelope).includes(REAL_SECRET),
    `the real secret leaked into the envelope sent to the browser: ${JSON.stringify(r.envelope)}`);
  // Pin the exact envelope key set: executeRequest's own result keys plus
  // request_sent, nothing from data.prepared. This also adds `request`
  // (edge-resolved, no secret — see the module's own doc comment) alongside
  // request_sent, relayed on every dispatch regardless of test mode.
  assert.deepStrictEqual(Object.keys(r.envelope).sort(), ['body', 'duration_ms', 'headers', 'request', 'request_sent', 'upstream_status']);
});

test('infra-mode: a prepare response with no request_sent yields envelope.request_sent === null', async () => {
  edgeCalls.length = 0;
  forwardToEdgeImpl = async (opts) => {
    if (opts.path.endsWith('/prepare')) {
      return {
        status: 200,
        data: {
          data: {
            mode: 'infra', dispatch_id: 'd1', recipe_id: 'rc1',
            prepared: { method: 'POST', url: 'https://ok.test/x', headers: {}, body: '{}', pinned_ip: '93.184.216.34', family: 4, timeout_ms: 10000, max_bytes: 1000000 },
          },
        },
      };
    }
    return { status: 200, data: { ok: true } };
  };
  executeRequestImpl = async () => ({ upstream_status: 200, headers: {}, body: '{"ok":true}', duration_ms: 7 });
  isBlockedIpImpl = () => false;

  const r = await dispatchOneStep({ stepId: 's1', inputs: {}, runId: 'run1', test: false, user: USER, reqId: 'r1' });

  assert.strictEqual(r.ok, true);
  assert.strictEqual(r.envelope.request_sent, null);
});

test('infra owns no masker: flow-dispatch-step.js source imports no serializer/masker module', () => {
  const src = fs.readFileSync(path.resolve(__dirname, '../../src/infra/lib/flow-dispatch-step.js'), 'utf8');
  assert.doesNotMatch(src, /serializer|maskDeep/, 'infra must copy request_sent verbatim, never mask it itself (infra-talks-to-edge-only)');
});
