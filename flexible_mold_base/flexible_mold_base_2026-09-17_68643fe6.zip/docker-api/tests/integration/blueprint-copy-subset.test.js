/**
 * blueprint-copy-subset.test.js — POST /edge/app/schema/blueprint-copy-subset,
 * end to end against a mocked connection (mirrors blueprint-import-roundtrip's
 * probe-answering idiom). Covers the spec-named cases: subset round-trip with
 * rules re-pointed, both dependency-break choices, collision suggestion +
 * rejection of a still-colliding manual key, transactionality (an injected
 * write failure leaves the target unchanged — nothing commits), snapshot
 * consistency abort, and a loose field landing under its chosen target
 * section. Also pins that the route sits behind requireAdminOrEditor.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const { makeStubReqLog } = require('../helpers/stub-req-log');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../src/edge/db');
const { __clearPortableColumnCache } = require('../../src/edge/lib/portable-insert');
const {
  fieldSnapshotFingerprint, sectionSnapshotFingerprint, copyBlueprintFieldSubset,
} = require('../../src/edge/lib/blueprint-copy-subset');
const { TABLES } = require('../../src/shared/constants');
const { uuidv4 } = require('../../src/shared/helpers');

const PREFIX = 'fmb_';
const DB_NAME = 'testdb';

const COLUMN_META = {
  blueprint_fields: [
    'id', 'blueprint_id', 'field_key', 'field_label', 'field_type', 'is_required',
    'default_value', 'placeholder', 'tooltip', 'section', 'group_key', 'matrix_row_key',
    'order_index', 'table_config', 'visibility_rule', 'depends_on_field_key', 'created_at',
    'retain_when_hidden', 'choice_config', 'value_source', 'value_scope', 'compute_rule',
  ],
  field_options: ['id', 'field_id', 'option_label', 'option_value', 'sort_order', 'valid_parent_values', 'created_at'],
  blueprint_sections: ['id', 'blueprint_id', 'section_key', 'display_label', 'icon', 'description', 'layout_mode', 'matrix_copy', 'sort_order', 'created_at'],
};

function tableSuffix(physical) {
  return physical.startsWith(PREFIX) ? physical.slice(PREFIX.length) : physical;
}

const SOURCE_ID = '11111111-1111-4111-8111-111111111111';
const TARGET_ID = '22222222-2222-4222-8222-222222222222';

function fieldRow(overrides) {
  return {
    id: 'src-field-1', blueprint_id: SOURCE_ID, field_key: 'name', field_label: 'Name',
    field_type: 'text', is_required: 0, default_value: '', placeholder: '', tooltip: '',
    section: 'general', group_key: null, matrix_row_key: null, order_index: 0,
    table_config: null, visibility_rule: null, depends_on_field_key: null,
    retain_when_hidden: 0, choice_config: null,
    value_source: 'entered', value_scope: null, compute_rule: null,
    created_at: '2024-01-01 00:00:00',
    ...overrides,
  };
}

// Per-test state the mock connection reads from / writes into.
let state;

function makeConn() {
  const inserts = [];
  const queries = [];
  return {
    inserts,
    async query(sql, params = []) {
      queries.push(sql);
      if (/^SELECT DATABASE\(\)/i.test(sql)) return [{ db: DB_NAME }];
      if (/information_schema\.COLUMNS/i.test(sql)) {
        const physical = params[0];
        const cols = COLUMN_META[tableSuffix(physical)] || [];
        return cols.map((c) => ({ COLUMN_NAME: c }));
      }
      // Route: isBlueprintLinkedLocked probe (checked BEFORE the generic
      // FOR UPDATE branch below, which would otherwise swallow it).
      if (/SELECT linked_blueprint_id FROM `fmb_hierarchy_nodes`/i.test(sql)) {
        return params[0] === TARGET_ID ? [{ linked_blueprint_id: state.linkedBlueprintId ?? null }] : [];
      }
      // Route: lock the target row.
      if (/FOR UPDATE/i.test(sql)) {
        return params[0] === TARGET_ID ? [{ id: TARGET_ID, owner_id: null }] : [];
      }
      // Route: source blueprint existence.
      if (/SELECT id FROM `fmb_hierarchy_nodes` WHERE id = \? AND node_type = 'blueprint'/i.test(sql)) {
        return params[0] === SOURCE_ID || params[0] === TARGET_ID ? [{ id: params[0] }] : [];
      }
      // copyBlueprintFieldSubset: source field rows.
      if (/SELECT \* FROM `fmb_blueprint_fields`\s+WHERE blueprint_id = \? AND id IN/i.test(sql)) {
        return state.sourceFields.filter((f) => f.blueprint_id === params[0] && params.slice(1).includes(f.id));
      }
      // Target existing field_keys.
      if (/SELECT field_key FROM `fmb_blueprint_fields` WHERE blueprint_id = \?/i.test(sql)) {
        return state.targetFields.filter((f) => f.blueprint_id === params[0]).map((f) => ({ field_key: f.field_key }));
      }
      // loadBlueprintComputeState (target).
      if (/SELECT field_key, field_type, table_config, compute_rule FROM `fmb_blueprint_fields`/i.test(sql)) {
        return state.targetFields.filter((f) => f.blueprint_id === params[0]);
      }
      // loadBlueprintFieldScopes (target).
      if (/SELECT field_key, value_scope FROM `fmb_blueprint_fields`/i.test(sql)) {
        return state.targetFields.filter((f) => f.blueprint_id === params[0]).map((f) => ({ field_key: f.field_key, value_scope: f.value_scope ?? null }));
      }
      // Source sections (whole-session copies).
      if (/SELECT \* FROM `fmb_blueprint_sections`\s+WHERE blueprint_id = \? AND section_key IN/i.test(sql)) {
        return (state.sourceSections || []).filter((s) => s.blueprint_id === params[0] && params.slice(1).includes(s.section_key));
      }
      // Target existing section_keys.
      if (/SELECT section_key FROM `fmb_blueprint_sections` WHERE blueprint_id = \?/i.test(sql)) {
        return (state.targetSections || []).filter((s) => s.blueprint_id === params[0]).map((s) => ({ section_key: s.section_key }));
      }
      // loadVariantComputeRulesByVariant (target).
      if (/SELECT vo\.variant_id, bf\.field_key, vo\.compute_rule/i.test(sql)) {
        return state.variantComputeRules || [];
      }
      // loadVariantCellTargetsByVariant (target).
      if (/SELECT vo\.variant_id, bf\.field_key, vo\.cell_targets/i.test(sql)) {
        return state.variantCellTargets || [];
      }
      // Source field_options.
      if (/SELECT \* FROM `fmb_field_options` WHERE field_id IN/i.test(sql)) {
        return (state.sourceOptions || []).filter((o) => params.includes(o.field_id));
      }
      if (/^INSERT INTO/i.test(sql)) {
        if (state.failInsertTable) {
          const m = sql.match(/INSERT INTO `([^`]+)`/i);
          if (m && tableSuffix(m[1]) === state.failInsertTable) {
            const err = new Error('injected failure');
            throw err;
          }
        }
        const m = sql.match(/INSERT INTO `([^`]+)`/i);
        inserts.push({ table: m ? tableSuffix(m[1]) : '', sql, params });
        return { affectedRows: 1 };
      }
      return [];
    },
    async beginTransaction() { this._tx = true; },
    async commit() { this._committed = true; },
    async rollback() { this._rolledBack = true; },
    release() {},
  };
}

let lastConn;
const poolSpy = {
  rw: { async getConnection() { lastConn = makeConn(); return lastConn; } },
};

require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: poolSpy, t: (n) => `${PREFIX}${n}`, getDynamicPool: async () => poolSpy },
};

const router = require('../../src/edge/routes/app/schema');
// Required only AFTER the require.cache[dbKey] mock above is installed — see
// blueprint-copy-subset.js's own doc-block on why helpers.js (and
// request-pool.js beneath it) may not load before that mock is in place.
const { MAX_COPY_FIELDS, MAX_COPY_SECTIONS } = require('../../src/edge/routes/app/schema/helpers');

let server;
let port;
let currentUser = { id: 'admin-1', role: 'admin' };

before(async () => {
  const app = express();
  app.use((req, _res, next) => { req.log = makeStubReqLog(); next(); }); // TEST-ONLY: production always sets req.log via createRequestId (request-id.js) before any router; this bare app has no such middleware, so a route's req.log.<level>() call would otherwise throw against undefined.
  app.use(express.json());
  app.use((req, _res, next) => { req.user = currentUser; next(); });
  app.use('/edge/app/schema', router);
  await new Promise((resolve) => {
    server = app.listen(0, '127.0.0.1', () => { port = server.address().port; resolve(); });
  });
});

after(async () => {
  await new Promise((resolve) => server.close(resolve));
  delete require.cache[dbKey];
});

beforeEach(() => {
  __clearPortableColumnCache();
  currentUser = { id: 'admin-1', role: 'admin' };
  state = {
    sourceFields: [], targetFields: [], sourceSections: [], targetSections: [], sourceOptions: [],
    failInsertTable: null, linkedBlueprintId: null, variantComputeRules: [], variantCellTargets: [],
  };
});

function request(method, path, body) {
  return new Promise((resolve, reject) => {
    const data = body !== undefined ? JSON.stringify(body) : '';
    const headers = data ? { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(data) } : {};
    const req = http.request({ method, host: '127.0.0.1', port, path, headers }, (res) => {
      let raw = '';
      res.on('data', (c) => { raw += c; });
      res.on('end', () => {
        let json = null;
        try { json = raw ? JSON.parse(raw) : null; } catch { /* noop */ }
        resolve({ status: res.statusCode, raw, json });
      });
    });
    req.on('error', reject);
    if (data) req.write(data);
    req.end();
  });
}

const PATH = '/edge/app/schema/blueprint-copy-subset';

describe('auth', () => {
  it('refuses a plain user (requireAdminOrEditor gate)', async () => {
    currentUser = { id: 'u1', role: 'user' };
    const res = await request('POST', PATH, {
      source_blueprint_id: SOURCE_ID, target_blueprint_id: TARGET_ID,
      fields: [{ source_field_id: 'src-field-1', new_key: 'name', label: 'Name' }],
    });
    assert.equal(res.status, 403);
  });
});

describe('body shape — source/target must differ (case-insensitive)', () => {
  it('rejects source and target naming the same blueprint spelled with different case', async () => {
    const res = await request('POST', PATH, {
      source_blueprint_id: 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa', target_blueprint_id: 'AAAAAAAA-AAAA-4AAA-8AAA-AAAAAAAAAAAA',
      fields: [{ source_field_id: 'src-field-1', new_key: 'name', label: 'Name' }],
    });
    assert.equal(res.status, 400, res.raw);
    assert.ok(res.json.validation_errors.some((m) => /must differ/.test(m)), res.raw);
  });
});

describe('subset round-trip', () => {
  it('copies a field with a rule re-pointed to the copied counterpart', async () => {
    const trim = fieldRow({ id: 'src-field-2', field_key: 'trim', field_label: 'Trim' });
    const series = fieldRow({
      id: 'src-field-1', field_key: 'series', field_label: 'Series',
      value_source: 'calculated',
      compute_rule: JSON.stringify({ op: 'transform', overridable: true, output_type: 'string', config: { source: 'trim', transform: 'upper' } }),
    });
    state.sourceFields = [series, trim];

    const snapshot = {
      [series.id]: fieldSnapshotFingerprint(series),
      [trim.id]: fieldSnapshotFingerprint(trim),
    };

    const res = await request('POST', PATH, {
      source_blueprint_id: SOURCE_ID, target_blueprint_id: TARGET_ID,
      fields: [
        { source_field_id: series.id, new_key: 'series', label: 'Series', section_key: 'general' },
        { source_field_id: trim.id, new_key: 'trim', label: 'Trim', section_key: 'general' },
      ],
      source_snapshot: snapshot,
    });
    assert.equal(res.status, 200, res.raw);
    assert.equal(res.json.data.fields_copied, 2);

    const bfInserts = lastConn.inserts.filter((i) => i.table === 'blueprint_fields');
    assert.equal(bfInserts.length, 2);
    const seriesInsert = bfInserts.find((i) => {
      const idx = i.sql.match(/\(([\s\S]*?)\)/)[1].split(',').map((c) => c.trim().replace(/`/g, '')).indexOf('field_key');
      return i.params[idx] === 'series';
    });
    assert.ok(seriesInsert, 'the copied series field must be inserted');
    const cols = seriesInsert.sql.match(/\(([\s\S]*?)\)/)[1].split(',').map((c) => c.trim().replace(/`/g, ''));
    const ruleIdx = cols.indexOf('compute_rule');
    const rule = JSON.parse(seriesInsert.params[ruleIdx]);
    assert.equal(rule.config.source, 'trim', 'the rule still points at trim (no rename here)');
  });

  it('rewrites the rule source to the RENAMED key when the referenced field collided', async () => {
    // Target already has a field named 'trim' — the copy must suggest trim_2
    // and the series rule must follow the rename.
    state.targetFields = [fieldRow({ id: 'existing-trim', blueprint_id: TARGET_ID, field_key: 'trim' })];
    const trim = fieldRow({ id: 'src-field-2', field_key: 'trim', field_label: 'Trim' });
    const series = fieldRow({
      id: 'src-field-1', field_key: 'series', field_label: 'Series',
      value_source: 'calculated',
      compute_rule: JSON.stringify({ op: 'transform', overridable: true, output_type: 'string', config: { source: 'trim', transform: 'upper' } }),
    });
    state.sourceFields = [series, trim];

    const res = await request('POST', PATH, {
      source_blueprint_id: SOURCE_ID, target_blueprint_id: TARGET_ID,
      fields: [
        { source_field_id: series.id, new_key: 'series', label: 'Series', section_key: 'general' },
        { source_field_id: trim.id, new_key: 'trim_2', label: 'Trim', section_key: 'general' },
      ],
      source_snapshot: { [series.id]: fieldSnapshotFingerprint(series), [trim.id]: fieldSnapshotFingerprint(trim) },
    });
    assert.equal(res.status, 200, res.raw);
    const bfInserts = lastConn.inserts.filter((i) => i.table === 'blueprint_fields');
    const seriesInsert = bfInserts.find((i) => {
      const cols = i.sql.match(/\(([\s\S]*?)\)/)[1].split(',').map((c) => c.trim().replace(/`/g, ''));
      return i.params[cols.indexOf('field_key')] === 'series';
    });
    const cols = seriesInsert.sql.match(/\(([\s\S]*?)\)/)[1].split(',').map((c) => c.trim().replace(/`/g, ''));
    const rule = JSON.parse(seriesInsert.params[cols.indexOf('compute_rule')]);
    assert.equal(rule.config.source, 'trim_2', 'the rule must follow the collision-suffixed rename');
  });
});

describe('column-level rule rewrite on copy (fmb-1946)', () => {
  const lookupRule = (lookupRef) => ({
    op: 'concat', overridable: true, output_type: 'string',
    config: { parts: [{ type: 'table_column_lookup', lookupRef }] },
  });

  it('rewrites a table_config column rule\'s lookupRef.table_key to the collision-renamed key of the OTHER copied field', async () => {
    // Target already has an UNRELATED field named 'trim' whose own columns do
    // NOT include 'sku' — if the copied `items.price` column rule survived
    // pointing at the bare 'trim' key (the unrewritten reading), it would
    // structurally fail against THIS row's column set (bad_table_column_lookup),
    // not silently cross-wire into it. So a 200 here can only mean the rule
    // was rewritten to the NEW key the collision suffixed the copied 'trim'
    // field to ('trim_2'), whose OWN table_config (copied alongside it) does
    // declare 'sku'.
    state.targetFields = [fieldRow({
      id: 'existing-trim', blueprint_id: TARGET_ID, field_key: 'trim', field_type: 'table',
      table_config: JSON.stringify({ columns: [{ key: 'different_col' }] }),
    })];
    const trim = fieldRow({
      id: 'src-field-2', field_key: 'trim', field_label: 'Trim', field_type: 'table',
      table_config: JSON.stringify({ columns: [{ key: 'sku' }] }),
    });
    const items = fieldRow({
      id: 'src-field-1', field_key: 'items', field_label: 'Items', field_type: 'table',
      table_config: JSON.stringify({
        columns: [
          { key: 'own_sku' },
          {
            key: 'price',
            rules: {
              compute_rule: lookupRule({ table_key: 'trim', matchKeyColumn: 'sku', ownKeyColumn: 'own_sku', valueColumn: 'sku' }),
            },
          },
        ],
      }),
    });
    state.sourceFields = [items, trim];

    const res = await request('POST', PATH, {
      source_blueprint_id: SOURCE_ID, target_blueprint_id: TARGET_ID,
      fields: [
        { source_field_id: items.id, new_key: 'items', label: 'Items', section_key: 'general' },
        { source_field_id: trim.id, new_key: 'trim_2', label: 'Trim', section_key: 'general' },
      ],
      source_snapshot: { [items.id]: fieldSnapshotFingerprint(items), [trim.id]: fieldSnapshotFingerprint(trim) },
    });
    assert.equal(res.status, 200, res.raw);
    const bfInserts = lastConn.inserts.filter((i) => i.table === 'blueprint_fields');
    const itemsInsert = bfInserts.find((i) => {
      const cols = i.sql.match(/\(([\s\S]*?)\)/)[1].split(',').map((c) => c.trim().replace(/`/g, ''));
      return i.params[cols.indexOf('field_key')] === 'items';
    });
    assert.ok(itemsInsert, 'the copied items field must be inserted');
    const cols = itemsInsert.sql.match(/\(([\s\S]*?)\)/)[1].split(',').map((c) => c.trim().replace(/`/g, ''));
    const tableConfig = JSON.parse(itemsInsert.params[cols.indexOf('table_config')]);
    const priceRule = tableConfig.columns.find((c) => c.key === 'price').rules.compute_rule;
    assert.equal(priceRule.config.parts[0].lookupRef.table_key, 'trim_2',
      'the column rule must follow the collision-suffixed rename of the field it looks up');
  });

  it('rejects the copy when the SAME shape is NOT rewritten (still points at a stale/unrelated key)', async () => {
    // Control: 'trim' is copied unchanged (new_key: 'trim'), so no rewrite is
    // needed either way — the column rule survives verbatim and is judged
    // against the SAME target 'trim' the wizard's mapping step chose. This
    // pins that the write-time gate this test's sibling relies on (no silent
    // cross-wire) is still live, not merely bypassed by construction.
    state.targetFields = [];
    const trim = fieldRow({
      id: 'src-field-2', field_key: 'trim', field_label: 'Trim', field_type: 'table',
      table_config: JSON.stringify({ columns: [{ key: 'not_sku' }] }),
    });
    const items = fieldRow({
      id: 'src-field-1', field_key: 'items', field_label: 'Items', field_type: 'table',
      table_config: JSON.stringify({
        columns: [
          { key: 'own_sku' },
          {
            key: 'price',
            rules: {
              compute_rule: lookupRule({ table_key: 'trim', matchKeyColumn: 'sku', ownKeyColumn: 'own_sku', valueColumn: 'sku' }),
            },
          },
        ],
      }),
    });
    state.sourceFields = [items, trim];

    const res = await request('POST', PATH, {
      source_blueprint_id: SOURCE_ID, target_blueprint_id: TARGET_ID,
      fields: [
        { source_field_id: items.id, new_key: 'items', label: 'Items', section_key: 'general' },
        { source_field_id: trim.id, new_key: 'trim', label: 'Trim', section_key: 'general' },
      ],
      source_snapshot: { [items.id]: fieldSnapshotFingerprint(items), [trim.id]: fieldSnapshotFingerprint(trim) },
    });
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'INVALID_COMPUTE_RULE');
  });
});

describe('dependency break — both user choices', () => {
  function makeSeriesWithExternalRule() {
    return fieldRow({
      id: 'src-field-1', field_key: 'series', field_label: 'Series',
      value_source: 'calculated',
      compute_rule: JSON.stringify({ op: 'transform', overridable: true, output_type: 'string', config: { source: 'not_selected', transform: 'upper' } }),
    });
  }

  it('rejects an unresolved break (source outside the selection, not dropped)', async () => {
    const series = makeSeriesWithExternalRule();
    state.sourceFields = [series];
    const res = await request('POST', PATH, {
      source_blueprint_id: SOURCE_ID, target_blueprint_id: TARGET_ID,
      fields: [{ source_field_id: series.id, new_key: 'series', label: 'Series', section_key: 'general' }],
      source_snapshot: { [series.id]: fieldSnapshotFingerprint(series) },
    });
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'INVALID_SELECTION');
  });

  it('bring-in: including the referenced field in the selection resolves the break', async () => {
    const notSelected = fieldRow({ id: 'src-field-2', field_key: 'not_selected', field_label: 'External' });
    const series = fieldRow({
      id: 'src-field-1', field_key: 'series', field_label: 'Series',
      value_source: 'calculated',
      compute_rule: JSON.stringify({ op: 'transform', overridable: true, output_type: 'string', config: { source: 'not_selected', transform: 'upper' } }),
    });
    state.sourceFields = [series, notSelected];
    const res = await request('POST', PATH, {
      source_blueprint_id: SOURCE_ID, target_blueprint_id: TARGET_ID,
      fields: [
        { source_field_id: series.id, new_key: 'series', label: 'Series', section_key: 'general' },
        { source_field_id: notSelected.id, new_key: 'not_selected', label: 'External', section_key: 'general' },
      ],
      source_snapshot: { [series.id]: fieldSnapshotFingerprint(series), [notSelected.id]: fieldSnapshotFingerprint(notSelected) },
    });
    assert.equal(res.status, 200, res.raw);
    assert.equal(res.json.data.fields_copied, 2);
  });

  it('drop: drop_rule strips the rule instead of failing', async () => {
    const series = makeSeriesWithExternalRule();
    state.sourceFields = [series];
    const res = await request('POST', PATH, {
      source_blueprint_id: SOURCE_ID, target_blueprint_id: TARGET_ID,
      fields: [{ source_field_id: series.id, new_key: 'series', label: 'Series', section_key: 'general', drop_rule: true }],
      source_snapshot: { [series.id]: fieldSnapshotFingerprint(series) },
    });
    assert.equal(res.status, 200, res.raw);
    const bfInsert = lastConn.inserts.find((i) => i.table === 'blueprint_fields');
    const cols = bfInsert.sql.match(/\(([\s\S]*?)\)/)[1].split(',').map((c) => c.trim().replace(/`/g, ''));
    assert.equal(bfInsert.params[cols.indexOf('compute_rule')], null, 'the dropped rule must not be written');
    assert.equal(bfInsert.params[cols.indexOf('value_source')], 'entered', 'the mode must fall back to entered beside the dropped rule');
  });

  // fmb-1945 R5 (adv B L2): the precheck above only ever walked the field's
  // OWN `compute_rule` — a table_config COLUMN rule referencing a field
  // outside the selection reached the LATER, less specific
  // INVALID_COMPUTE_RULE stage (missing_source) instead of this same
  // INVALID_SELECTION stage a field-level break gets. `drop_rule` must NOT
  // silence this — it only ever gated the field's own compute_rule (see
  // `rewriteTableConfigColumnRuleSources`'s own doc-block: it rewrites every
  // column rule unconditionally), so this case deliberately omits it.
  it('rejects a table_config column rule that references a field outside the selection, at the SAME INVALID_SELECTION stage as a field-level break', async () => {
    const items = fieldRow({
      id: 'src-field-1', field_key: 'items', field_type: 'table',
      table_config: {
        columns: [{
          key: 'label',
          rules: {
            compute_rule: {
              op: 'concat', overridable: true, output_type: 'string',
              config: { parts: [{ type: 'field', key: 'not_selected' }] },
            },
          },
        }],
      },
    });
    state.sourceFields = [items];
    const res = await request('POST', PATH, {
      source_blueprint_id: SOURCE_ID, target_blueprint_id: TARGET_ID,
      fields: [{ source_field_id: items.id, new_key: 'items', label: 'Items', section_key: 'general' }],
      source_snapshot: { [items.id]: fieldSnapshotFingerprint(items) },
    });
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'INVALID_SELECTION');
    assert.match(res.raw, /label/, "the refusal must name the column key ('label')");
    assert.equal(lastConn.inserts.length, 0, 'no row may be written when a copied column rule references an unresolved field');
  });
});

describe('key collision', () => {
  it('rejects a still-colliding manual key against the target', async () => {
    state.targetFields = [fieldRow({ id: 'existing-1', blueprint_id: TARGET_ID, field_key: 'name' })];
    const src = fieldRow({ id: 'src-field-1', field_key: 'name' });
    state.sourceFields = [src];
    const res = await request('POST', PATH, {
      source_blueprint_id: SOURCE_ID, target_blueprint_id: TARGET_ID,
      fields: [{ source_field_id: src.id, new_key: 'name', label: 'Name', section_key: 'general' }],
      source_snapshot: { [src.id]: fieldSnapshotFingerprint(src) },
    });
    assert.equal(res.status, 400, res.raw);
    assert.match(res.raw, /already exists in the target/);
    assert.equal(lastConn.inserts.length, 0, 'no row may be written when a key collision is unresolved');
  });

  it('accepts a suggested non-colliding key (e.g. name_2)', async () => {
    state.targetFields = [fieldRow({ id: 'existing-1', blueprint_id: TARGET_ID, field_key: 'name' })];
    const src = fieldRow({ id: 'src-field-1', field_key: 'name' });
    state.sourceFields = [src];
    const res = await request('POST', PATH, {
      source_blueprint_id: SOURCE_ID, target_blueprint_id: TARGET_ID,
      fields: [{ source_field_id: src.id, new_key: 'name_2', label: 'Name', section_key: 'general' }],
      source_snapshot: { [src.id]: fieldSnapshotFingerprint(src) },
    });
    assert.equal(res.status, 200, res.raw);
  });

  // LOW-1: the section block already covers "identical spelling collides
  // within the batch" — the field block had no test for the same case.
  it('duplicate new_key within the batch is rejected (field twin of the section case), zero inserts', async () => {
    const a = fieldRow({ id: 'src-field-1', field_key: 'name' });
    const b = fieldRow({ id: 'src-field-2', field_key: 'title' });
    state.sourceFields = [a, b];
    const res = await request('POST', PATH, {
      source_blueprint_id: SOURCE_ID, target_blueprint_id: TARGET_ID,
      fields: [
        { source_field_id: a.id, new_key: 'same_key', label: 'A', section_key: 'general' },
        { source_field_id: b.id, new_key: 'same_key', label: 'B', section_key: 'general' },
      ],
      source_snapshot: { [a.id]: fieldSnapshotFingerprint(a), [b.id]: fieldSnapshotFingerprint(b) },
    });
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'INVALID_SELECTION');
    assert.match(res.raw, /collides with another copied field in this batch/);
    assert.equal(lastConn.inserts.length, 0);
  });
});

describe('transactionality', () => {
  it('an injected failure on field_options leaves nothing committed and rolls back', async () => {
    const src = fieldRow({ id: 'src-field-1', field_key: 'name' });
    state.sourceFields = [src];
    state.sourceOptions = [{ id: 'opt-1', field_id: src.id, option_label: 'A', option_value: 'a', sort_order: 0, valid_parent_values: null }];
    state.failInsertTable = 'field_options';
    const res = await request('POST', PATH, {
      source_blueprint_id: SOURCE_ID, target_blueprint_id: TARGET_ID,
      fields: [{ source_field_id: src.id, new_key: 'name', label: 'Name', section_key: 'general' }],
      source_snapshot: { [src.id]: fieldSnapshotFingerprint(src, state.sourceOptions) },
    });
    assert.equal(res.status, 500, res.raw);
    assert.equal(lastConn._committed, undefined, 'commit must never be called after an injected write failure');
    assert.equal(lastConn._rolledBack, true, 'the connection must be rolled back');
  });
});

describe('snapshot consistency', () => {
  it('aborts with no write when the source field changed since the wizard loaded it', async () => {
    const src = fieldRow({ id: 'src-field-1', field_key: 'name' });
    state.sourceFields = [src];
    const res = await request('POST', PATH, {
      source_blueprint_id: SOURCE_ID, target_blueprint_id: TARGET_ID,
      fields: [{ source_field_id: src.id, new_key: 'name', label: 'Name', section_key: 'general' }],
      // A stale fingerprint, as if the wizard captured it before a label edit.
      source_snapshot: { [src.id]: 'stale::fingerprint' },
    });
    assert.equal(res.status, 409, res.raw);
    assert.equal(res.json.error.code, 'SOURCE_CHANGED');
    assert.equal(lastConn.inserts.length, 0);
  });

  it('aborts when a selected source field was deleted mid-wizard', async () => {
    state.sourceFields = []; // the field the payload names no longer exists
    const res = await request('POST', PATH, {
      source_blueprint_id: SOURCE_ID, target_blueprint_id: TARGET_ID,
      fields: [{ source_field_id: 'gone', new_key: 'name', label: 'Name', section_key: 'general' }],
      source_snapshot: { gone: 'anything' },
    });
    assert.equal(res.status, 409, res.raw);
    assert.equal(res.json.error.code, 'SOURCE_CHANGED');
  });
});

describe('loose field default section', () => {
  it('a field copied without its section lands under the section_key the wizard chose', async () => {
    const src = fieldRow({ id: 'src-field-1', field_key: 'name', section: 'from_section' });
    state.sourceFields = [src];
    const res = await request('POST', PATH, {
      source_blueprint_id: SOURCE_ID, target_blueprint_id: TARGET_ID,
      fields: [{ source_field_id: src.id, new_key: 'name', label: 'Name', section_key: 'existing_target_section' }],
      source_snapshot: { [src.id]: fieldSnapshotFingerprint(src) },
    });
    assert.equal(res.status, 200, res.raw);
    const bfInsert = lastConn.inserts.find((i) => i.table === 'blueprint_fields');
    const cols = bfInsert.sql.match(/\(([\s\S]*?)\)/)[1].split(',').map((c) => c.trim().replace(/`/g, ''));
    assert.equal(bfInsert.params[cols.indexOf('section')], 'existing_target_section');
  });
});

// Helper shared by the field_label / visibility / cascade tests below: pulls
// one named param out of an insert by its column list, the same idiom every
// prior describe block in this file already uses.
function paramOf(insert, column) {
  const cols = insert.sql.match(/\(([\s\S]*?)\)/)[1].split(',').map((c) => c.trim().replace(/`/g, ''));
  return insert.params[cols.indexOf(column)];
}

describe('field_label (C1 — every copied field must carry the mapping label, not NULL)', () => {
  it('writes the mapping-step label, which the fixture deliberately differs from the source label', async () => {
    // The fixture's own field_label ("Name") must differ from the mapping
    // label ("Renamed On Copy") — an equal-value fixture would still pass
    // even if the column silently went NULL, which is exactly how this bug
    // survived the original test suite.
    const src = fieldRow({ id: 'src-field-1', field_key: 'name', field_label: 'Name' });
    state.sourceFields = [src];
    const res = await request('POST', PATH, {
      source_blueprint_id: SOURCE_ID, target_blueprint_id: TARGET_ID,
      fields: [{ source_field_id: src.id, new_key: 'name', label: 'Renamed On Copy', section_key: 'general' }],
      source_snapshot: { [src.id]: fieldSnapshotFingerprint(src) },
    });
    assert.equal(res.status, 200, res.raw);
    const bfInsert = lastConn.inserts.find((i) => i.table === 'blueprint_fields');
    assert.equal(paramOf(bfInsert, 'field_label'), 'Renamed On Copy');
  });

  // The mapping step omits `label` when the field is not being renamed — the
  // remap's own field_label had no fallback to the source row for that case,
  // so a legacy NULL-label source column reached buildPortableInsert as
  // `undefined` and wrote NULL again on the copy. The HTTP route itself
  // requires `fields[i].label` (routes-blueprint-copy.js), which the wizard
  // UI always satisfies — so this calls the lib function directly, the same
  // way the route does after its own validation passes, to prove the write
  // primitive is correct on its own rather than only behind today's one
  // caller's stricter gate.
  it('a NULL-label source, copied without a rename, writes an empty string, not NULL', async () => {
    const src = fieldRow({ id: 'src-field-1', field_key: 'name', field_label: null });
    state.sourceFields = [src];
    const conn = makeConn();
    const t = (n) => `${PREFIX}${n}`;
    const result = await copyBlueprintFieldSubset(conn, { t, TABLES, uuidv4 }, {
      sourceId: SOURCE_ID,
      targetId: TARGET_ID,
      fields: [{ source_field_id: src.id, new_key: 'name', section_key: 'general' }],
      sourceSnapshot: { [src.id]: fieldSnapshotFingerprint(src) },
    });
    assert.equal(result.fields_copied, 1);
    const bfInsert = conn.inserts.find((i) => i.table === 'blueprint_fields');
    assert.equal(paramOf(bfInsert, 'field_label'), '');
  });
});

describe('cross-field key references (C2 — visibility_rule / depends_on_field_key)', () => {
  it('bring-in: a re-keyed controller is followed by BOTH visibility_rule and depends_on_field_key', async () => {
    // Target already holds a field named 'mode' — the copied controller
    // collides and is re-keyed to 'mode_2'; the dependent's references must
    // follow the RENAME, not the original 'mode'.
    state.targetFields = [fieldRow({ id: 'existing-mode', blueprint_id: TARGET_ID, field_key: 'mode' })];
    const controller = fieldRow({ id: 'src-field-1', field_key: 'mode', field_type: 'checkbox' });
    const dependent = fieldRow({
      id: 'src-field-2', field_key: 'extra', field_label: 'Extra',
      visibility_rule: { field_key: 'mode', operator: 'eq', value: 'true' },
      depends_on_field_key: 'mode',
    });
    state.sourceFields = [controller, dependent];
    const res = await request('POST', PATH, {
      source_blueprint_id: SOURCE_ID, target_blueprint_id: TARGET_ID,
      fields: [
        { source_field_id: controller.id, new_key: 'mode_2', label: 'Mode', section_key: 'general' },
        { source_field_id: dependent.id, new_key: 'extra', label: 'Extra', section_key: 'general' },
      ],
      source_snapshot: { [controller.id]: fieldSnapshotFingerprint(controller), [dependent.id]: fieldSnapshotFingerprint(dependent) },
    });
    assert.equal(res.status, 200, res.raw);
    const dependentInsert = lastConn.inserts.filter((i) => i.table === 'blueprint_fields')
      .find((i) => paramOf(i, 'field_key') === 'extra');
    assert.equal(paramOf(dependentInsert, 'depends_on_field_key'), 'mode_2', 'cascade parent must follow the rename');
    const vr = JSON.parse(paramOf(dependentInsert, 'visibility_rule'));
    assert.equal(vr.field_key, 'mode_2', 'visibility subject must follow the rename');
    assert.equal(vr.operator, 'eq', 'the rest of the visibility document must survive untouched');
  });

  it('drop: copying the dependent alone with an explicit drop nulls both columns', async () => {
    const dependent = fieldRow({
      id: 'src-field-1', field_key: 'extra', field_label: 'Extra',
      visibility_rule: { field_key: 'mode', operator: 'eq', value: 'true' },
      depends_on_field_key: 'mode',
    });
    state.sourceFields = [dependent];
    const res = await request('POST', PATH, {
      source_blueprint_id: SOURCE_ID, target_blueprint_id: TARGET_ID,
      fields: [{
        source_field_id: dependent.id, new_key: 'extra', label: 'Extra', section_key: 'general',
        drop_refs: ['visibility_rule', 'depends_on_field_key'],
      }],
      source_snapshot: { [dependent.id]: fieldSnapshotFingerprint(dependent) },
    });
    assert.equal(res.status, 200, res.raw);
    const bfInsert = lastConn.inserts.find((i) => i.table === 'blueprint_fields');
    assert.equal(paramOf(bfInsert, 'depends_on_field_key'), null);
    assert.equal(paramOf(bfInsert, 'visibility_rule'), null);
  });

  it('no choice: copying the dependent alone with neither bring-in nor drop is rejected, zero inserts', async () => {
    const dependent = fieldRow({
      id: 'src-field-1', field_key: 'extra', field_label: 'Extra',
      visibility_rule: { field_key: 'mode', operator: 'eq', value: 'true' },
      depends_on_field_key: 'mode',
    });
    state.sourceFields = [dependent];
    const res = await request('POST', PATH, {
      source_blueprint_id: SOURCE_ID, target_blueprint_id: TARGET_ID,
      fields: [{ source_field_id: dependent.id, new_key: 'extra', label: 'Extra', section_key: 'general' }],
      source_snapshot: { [dependent.id]: fieldSnapshotFingerprint(dependent) },
    });
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'INVALID_SELECTION');
    assert.equal(lastConn.inserts.length, 0);
  });

  it('a coincidentally same-named target field is never cross-wired: dropped means null, not a guess', async () => {
    // Target ALREADY has an UNRELATED field named 'mode' (not part of this
    // copy). The dependent's reference to 'mode' must never resolve to that
    // unrelated row — the copy either brings the controller in (its own
    // test above) or nulls the reference; it must not silently verbatim-
    // copy 'mode' and let it happen to resolve against the coincidental row.
    state.targetFields = [fieldRow({ id: 'unrelated-mode', blueprint_id: TARGET_ID, field_key: 'mode' })];
    const dependent = fieldRow({
      id: 'src-field-1', field_key: 'extra', field_label: 'Extra',
      visibility_rule: { field_key: 'mode', operator: 'eq', value: 'true' },
      depends_on_field_key: 'mode',
    });
    state.sourceFields = [dependent];
    const res = await request('POST', PATH, {
      source_blueprint_id: SOURCE_ID, target_blueprint_id: TARGET_ID,
      fields: [{
        source_field_id: dependent.id, new_key: 'extra', label: 'Extra', section_key: 'general',
        drop_refs: ['visibility_rule', 'depends_on_field_key'],
      }],
      source_snapshot: { [dependent.id]: fieldSnapshotFingerprint(dependent) },
    });
    assert.equal(res.status, 200, res.raw);
    const bfInsert = lastConn.inserts.find((i) => i.table === 'blueprint_fields');
    assert.equal(paramOf(bfInsert, 'depends_on_field_key'), null, 'must never resolve to the coincidental unrelated row');
    assert.equal(paramOf(bfInsert, 'visibility_rule'), null);
  });
});

describe('linked blueprint guard (H1)', () => {
  it('rejects a copy into a linked target with 409, zero inserts', async () => {
    state.linkedBlueprintId = SOURCE_ID;
    const src = fieldRow({ id: 'src-field-1', field_key: 'name' });
    state.sourceFields = [src];
    const res = await request('POST', PATH, {
      source_blueprint_id: SOURCE_ID, target_blueprint_id: TARGET_ID,
      fields: [{ source_field_id: src.id, new_key: 'name', label: 'Name', section_key: 'general' }],
      source_snapshot: { [src.id]: fieldSnapshotFingerprint(src) },
    });
    assert.equal(res.status, 409, res.raw);
    assert.equal(res.json.error.code, 'LINKED_BLUEPRINT_READONLY');
    assert.equal(lastConn.inserts.length, 0, 'no row may be written into a linked blueprint');
  });
});

describe('sections (H2)', () => {
  function sectionRow(overrides) {
    return {
      id: 'src-section-1', blueprint_id: SOURCE_ID, section_key: 'options', display_label: 'Options',
      icon: null, description: null, layout_mode: null, matrix_copy: 0, sort_order: 0,
      created_at: '2024-01-01 00:00:00',
      ...overrides,
    };
  }

  it('happy path: copies the section and resolves a loose field into the SECTION\'s rewritten key', async () => {
    state.sourceSections = [sectionRow()];
    const src = fieldRow({ id: 'src-field-1', field_key: 'name', section: 'options' });
    state.sourceFields = [src];
    const res = await request('POST', PATH, {
      source_blueprint_id: SOURCE_ID, target_blueprint_id: TARGET_ID,
      sections: [{ source_section_key: 'options', new_key: 'options_2', display_label: 'Options' }],
      fields: [{ source_field_id: src.id, new_key: 'name', label: 'Name', section_key: 'options' }],
      source_snapshot: { [src.id]: fieldSnapshotFingerprint(src) },
      source_section_snapshot: { options: sectionSnapshotFingerprint(sectionRow()) },
    });
    assert.equal(res.status, 200, res.raw);
    assert.equal(res.json.data.sections_copied, 1);
    const sectionInsert = lastConn.inserts.find((i) => i.table === 'blueprint_sections');
    assert.equal(paramOf(sectionInsert, 'section_key'), 'options_2');
    const fieldInsert = lastConn.inserts.find((i) => i.table === 'blueprint_fields');
    assert.equal(paramOf(fieldInsert, 'section'), 'options_2', "the field must land under the section's rewritten key, not the source key");
  });

  it('duplicate new_key within the batch is rejected, zero inserts', async () => {
    state.sourceSections = [sectionRow({ id: 's1', section_key: 'options' }), sectionRow({ id: 's2', section_key: 'extras' })];
    const src = fieldRow({ id: 'src-field-1', field_key: 'name' });
    state.sourceFields = [src];
    const res = await request('POST', PATH, {
      source_blueprint_id: SOURCE_ID, target_blueprint_id: TARGET_ID,
      sections: [
        { source_section_key: 'options', new_key: 'same_key' },
        { source_section_key: 'extras', new_key: 'same_key' },
      ],
      fields: [{ source_field_id: src.id, new_key: 'name', label: 'Name', section_key: 'general' }],
      source_snapshot: { [src.id]: fieldSnapshotFingerprint(src) },
      source_section_snapshot: {
        options: sectionSnapshotFingerprint(sectionRow({ id: 's1', section_key: 'options' })),
        extras: sectionSnapshotFingerprint(sectionRow({ id: 's2', section_key: 'extras' })),
      },
    });
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'INVALID_SELECTION');
    assert.equal(lastConn.inserts.length, 0);
  });

  it('collision with an existing target section is rejected, zero inserts', async () => {
    state.targetSections = [sectionRow({ id: 'existing', blueprint_id: TARGET_ID, section_key: 'options' })];
    state.sourceSections = [sectionRow()];
    const src = fieldRow({ id: 'src-field-1', field_key: 'name' });
    state.sourceFields = [src];
    const res = await request('POST', PATH, {
      source_blueprint_id: SOURCE_ID, target_blueprint_id: TARGET_ID,
      sections: [{ source_section_key: 'options', new_key: 'options' }],
      fields: [{ source_field_id: src.id, new_key: 'name', label: 'Name', section_key: 'general' }],
      source_snapshot: { [src.id]: fieldSnapshotFingerprint(src) },
      source_section_snapshot: { options: sectionSnapshotFingerprint(sectionRow()) },
    });
    assert.equal(res.status, 400, res.raw);
    assert.match(res.raw, /already exists in the target/);
    assert.equal(lastConn.inserts.length, 0);
  });

  it('a malformed new_key (illegal section_key shape) is refused, not written verbatim', async () => {
    state.sourceSections = [sectionRow()];
    const src = fieldRow({ id: 'src-field-1', field_key: 'name' });
    state.sourceFields = [src];
    const res = await request('POST', PATH, {
      source_blueprint_id: SOURCE_ID, target_blueprint_id: TARGET_ID,
      sections: [{ source_section_key: 'options', new_key: 'Bad Key!' }],
      fields: [{ source_field_id: src.id, new_key: 'name', label: 'Name', section_key: 'general' }],
      source_snapshot: { [src.id]: fieldSnapshotFingerprint(src) },
      source_section_snapshot: { options: sectionSnapshotFingerprint(sectionRow()) },
    });
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'INVALID_SELECTION');
    assert.equal(lastConn.inserts.length, 0);
  });

  it('a malformed item shape (missing source_section_key) is a named 400, never a silent skip', async () => {
    const src = fieldRow({ id: 'src-field-1', field_key: 'name' });
    state.sourceFields = [src];
    const res = await request('POST', PATH, {
      source_blueprint_id: SOURCE_ID, target_blueprint_id: TARGET_ID,
      sections: [{ new_key: 'options' }],
      fields: [{ source_field_id: src.id, new_key: 'name', label: 'Name', section_key: 'general' }],
      source_snapshot: { [src.id]: fieldSnapshotFingerprint(src) },
    });
    assert.equal(res.status, 400, res.raw);
    assert.ok(res.json.validation_errors.some((e) => e.includes('source_section_key')), res.raw);
  });
});

describe('cross-variant compute cycle (H3)', () => {
  function ruleReferencing(key) {
    return JSON.stringify({ op: 'transform', overridable: true, output_type: 'string', config: { source: key, transform: 'upper' } });
  }

  // NOTE ON REACHABILITY — both directions, precisely (a prior version of
  // this comment only covered the first and called the whole shape
  // unreachable):
  //
  // FORWARD (this test's shape) — a COPIED field's OWN rule naming a
  // pre-existing target field it was never selected to bring in: blocked
  // before this check ever runs. The dependency-break gate above refuses any
  // copied rule whose source is not `rewriteMap`-resolved (bring-in or
  // drop), and a pre-existing target field is never in `rewriteMap` (that
  // map holds only THIS batch's source keys). So a real `variant_overrides`
  // row can never join, front-door, to a field_key this copy is CREATING via
  // that field's own rule — this test therefore drives the check at its own
  // input boundary (the mocked query layer, which does not enforce that
  // precondition) to prove the function correctly rejects a cycle IN THE
  // DATA IT IS GIVEN, not to claim a front-door trigger for THIS shape.
  //
  // REVERSE (IS reachable, guarded by the same check, not by anything
  // direction-specific) — an EXISTING target `variant_overrides` row can
  // already dangle: its rule names a field_key that USED to exist in the
  // target and was since deleted (nothing purges a variant rule when its
  // subject field is dropped — the module doc-block's "dangling reference"
  // hazard applies to variant rows exactly as it does to
  // `depends_on_field_key`/`visibility_rule`). The new-key collision check
  // above only refuses a `new_key` that collides with a LIVE target
  // `field_key`, not with a dangling variant-rule reference — so a copy
  // whose `new_key` happens to spell that same, no-longer-live key lands a
  // brand new field the dangling rule now resolves onto. `loadVariant
  // ComputeRulesByVariant` reads the target's CURRENT variant rules fresh at
  // write time regardless of how they got there, so the cross-variant check
  // below still catches a cycle this reverse route closes — no separate
  // guard is needed for it, but the risk is real and this comment
  // previously said otherwise.
  it('a variant override that shadows a copied field with a cycle-closing rule is rejected, naming the variant', async () => {
    state.variantComputeRules = [{ variant_id: 'variant-1', field_key: 'b', compute_rule: ruleReferencing('c') }];
    const b = fieldRow({ id: 'src-field-1', field_key: 'b', value_source: 'calculated', compute_rule: null });
    const c = fieldRow({ id: 'src-field-2', field_key: 'c', value_source: 'calculated', compute_rule: ruleReferencing('b') });
    state.sourceFields = [b, c];
    const res = await request('POST', PATH, {
      source_blueprint_id: SOURCE_ID, target_blueprint_id: TARGET_ID,
      fields: [
        { source_field_id: b.id, new_key: 'b', label: 'B', section_key: 'general' },
        { source_field_id: c.id, new_key: 'c', label: 'C', section_key: 'general' },
      ],
      source_snapshot: { [b.id]: fieldSnapshotFingerprint(b), [c.id]: fieldSnapshotFingerprint(c) },
    });
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'INVALID_COMPUTE_RULE');
    assert.match(res.raw, /variant-1/, 'the refusal must name the variant it would break');
    assert.equal(lastConn.inserts.length, 0, 'no row may be written when a variant-only cycle is detected');
  });

  it('the identical copy succeeds against a target carrying no variant overrides', async () => {
    state.variantComputeRules = [];
    const b = fieldRow({ id: 'src-field-1', field_key: 'b', value_source: 'calculated', compute_rule: null });
    const c = fieldRow({ id: 'src-field-2', field_key: 'c', value_source: 'calculated', compute_rule: ruleReferencing('b') });
    state.sourceFields = [b, c];
    const res = await request('POST', PATH, {
      source_blueprint_id: SOURCE_ID, target_blueprint_id: TARGET_ID,
      fields: [
        { source_field_id: b.id, new_key: 'b', label: 'B', section_key: 'general' },
        { source_field_id: c.id, new_key: 'c', label: 'C', section_key: 'general' },
      ],
      source_snapshot: { [b.id]: fieldSnapshotFingerprint(b), [c.id]: fieldSnapshotFingerprint(c) },
    });
    assert.equal(res.status, 200, res.raw);
  });
});

describe('snapshot consistency — missing entry (L1)', () => {
  it('a source_field_id with no fingerprint in source_snapshot is refused, not fail-open', async () => {
    const src = fieldRow({ id: 'src-field-1', field_key: 'name' });
    state.sourceFields = [src];
    const res = await request('POST', PATH, {
      source_blueprint_id: SOURCE_ID, target_blueprint_id: TARGET_ID,
      fields: [{ source_field_id: src.id, new_key: 'name', label: 'Name', section_key: 'general' }],
      source_snapshot: {}, // omits src.id entirely
    });
    assert.equal(res.status, 409, res.raw);
    assert.equal(res.json.error.code, 'SOURCE_CHANGED');
    assert.equal(lastConn.inserts.length, 0);
  });
});

describe('snapshot consistency — options / sections (P2-1)', () => {
  function sectionRow(overrides) {
    return {
      id: 'src-section-1', blueprint_id: SOURCE_ID, section_key: 'options', display_label: 'Options',
      icon: null, description: null, layout_mode: null, matrix_copy: 0, sort_order: 0,
      created_at: '2024-01-01 00:00:00',
      ...overrides,
    };
  }

  it('aborts with no write when a field\'s option row changed since the wizard loaded it', async () => {
    const src = fieldRow({ id: 'src-field-1', field_key: 'name' });
    state.sourceFields = [src];
    const original = { id: 'opt-1', field_id: src.id, option_label: 'A', option_value: 'a', sort_order: 0, valid_parent_values: null };
    // The snapshot was captured against the ORIGINAL option; the DB row read
    // at write time (state.sourceOptions) now carries a relabelled option —
    // the copy must abort rather than silently carry the stale label through.
    state.sourceOptions = [{ ...original, option_label: 'Changed' }];
    const res = await request('POST', PATH, {
      source_blueprint_id: SOURCE_ID, target_blueprint_id: TARGET_ID,
      fields: [{ source_field_id: src.id, new_key: 'name', label: 'Name', section_key: 'general' }],
      source_snapshot: { [src.id]: fieldSnapshotFingerprint(src, [original]) },
    });
    assert.equal(res.status, 409, res.raw);
    assert.equal(res.json.error.code, 'SOURCE_CHANGED');
    assert.deepEqual(res.json.changed, [src.id]);
    assert.equal(lastConn.inserts.length, 0);
  });

  it('aborts with no write when a whole-section copy\'s metadata changed since the wizard loaded it', async () => {
    const original = sectionRow();
    state.sourceSections = [{ ...original, icon: 'car' }]; // icon edited after step-2 load
    const src = fieldRow({ id: 'src-field-1', field_key: 'name', section: 'options' });
    state.sourceFields = [src];
    const res = await request('POST', PATH, {
      source_blueprint_id: SOURCE_ID, target_blueprint_id: TARGET_ID,
      sections: [{ source_section_key: 'options', new_key: 'options_2', display_label: 'Options' }],
      fields: [{ source_field_id: src.id, new_key: 'name', label: 'Name', section_key: 'options' }],
      source_snapshot: { [src.id]: fieldSnapshotFingerprint(src) },
      source_section_snapshot: { options: sectionSnapshotFingerprint(original) },
    });
    assert.equal(res.status, 409, res.raw);
    assert.equal(res.json.error.code, 'SOURCE_CHANGED');
    assert.deepEqual(res.json.sections_changed, ['options']);
    assert.equal(lastConn.inserts.length, 0);
  });

  it('a whole-section copy with no source_section_snapshot entry is refused, not fail-open (L1 parity)', async () => {
    state.sourceSections = [sectionRow()];
    const src = fieldRow({ id: 'src-field-1', field_key: 'name', section: 'options' });
    state.sourceFields = [src];
    const res = await request('POST', PATH, {
      source_blueprint_id: SOURCE_ID, target_blueprint_id: TARGET_ID,
      sections: [{ source_section_key: 'options', new_key: 'options_2', display_label: 'Options' }],
      fields: [{ source_field_id: src.id, new_key: 'name', label: 'Name', section_key: 'options' }],
      source_snapshot: { [src.id]: fieldSnapshotFingerprint(src) },
      source_section_snapshot: {}, // omits the 'options' entry entirely
    });
    assert.equal(res.status, 409, res.raw);
    assert.equal(res.json.error.code, 'SOURCE_CHANGED');
    assert.equal(lastConn.inserts.length, 0);
  });
});

describe('batch bounds (P2-2)', () => {
  it(`rejects a fields batch over the ${MAX_COPY_FIELDS}-item limit, before any query is issued`, async () => {
    const connBefore = lastConn; // reassigned only when poolSpy.rw.getConnection() is called
    const fields = Array.from({ length: MAX_COPY_FIELDS + 1 }, (_, i) => ({
      source_field_id: `f${i}`, new_key: `k${i}`, label: `K${i}`, section_key: 'general',
    }));
    const res = await request('POST', PATH, {
      source_blueprint_id: SOURCE_ID, target_blueprint_id: TARGET_ID, fields,
    });
    assert.equal(res.status, 400, res.raw);
    assert.ok(res.json.validation_errors.some((e) => e.includes(`${MAX_COPY_FIELDS}-item limit`)), res.raw);
    assert.equal(lastConn, connBefore, 'the shape-check limit must reject before a connection is even opened');
  });

  it(`rejects a sections batch over the ${MAX_COPY_SECTIONS}-item limit, before any query is issued`, async () => {
    const connBefore = lastConn;
    const sections = Array.from({ length: MAX_COPY_SECTIONS + 1 }, (_, i) => ({
      source_section_key: `s${i}`, new_key: `sk${i}`,
    }));
    const res = await request('POST', PATH, {
      source_blueprint_id: SOURCE_ID, target_blueprint_id: TARGET_ID,
      fields: [{ source_field_id: 'f1', new_key: 'k1', label: 'K1', section_key: 'general' }],
      sections,
    });
    assert.equal(res.status, 400, res.raw);
    assert.ok(res.json.validation_errors.some((e) => e.includes(`${MAX_COPY_SECTIONS}-item limit`)), res.raw);
    assert.equal(lastConn, connBefore, 'the shape-check limit must reject before a connection is even opened');
  });
});

describe('duplicate source ids in one batch (P2-3, round 3)', () => {
  // A repeated source_field_id passes every per-item shape check (each item
  // is independently well-formed) but downstream `new_field_ids` is keyed by
  // source id, so the second copy would silently overwrite the first entry
  // in that map — caught here, before the shape check even opens a
  // connection, same discipline as the batch-bound tests above.
  it('the same source_field_id twice with distinct new_key is rejected, before any query is issued', async () => {
    const connBefore = lastConn;
    const res = await request('POST', PATH, {
      source_blueprint_id: SOURCE_ID, target_blueprint_id: TARGET_ID,
      fields: [
        { source_field_id: 'src-field-1', new_key: 'name_a', label: 'A', section_key: 'general' },
        { source_field_id: 'src-field-1', new_key: 'name_b', label: 'B', section_key: 'general' },
      ],
    });
    assert.equal(res.status, 400, res.raw);
    assert.ok(res.json.validation_errors.some((e) => e.includes('source_field_id') && e.includes('duplicated')), res.raw);
    assert.equal(lastConn, connBefore, 'the shape-check duplicate rejection must reject before a connection is even opened');
  });

  it('the same source_section_key twice with distinct new_key is rejected, before any query is issued', async () => {
    const connBefore = lastConn;
    const res = await request('POST', PATH, {
      source_blueprint_id: SOURCE_ID, target_blueprint_id: TARGET_ID,
      fields: [{ source_field_id: 'src-field-1', new_key: 'name', label: 'Name', section_key: 'general' }],
      sections: [
        { source_section_key: 'general', new_key: 'general_a' },
        { source_section_key: 'general', new_key: 'general_b' },
      ],
    });
    assert.equal(res.status, 400, res.raw);
    assert.ok(res.json.validation_errors.some((e) => e.includes('source_section_key') && e.includes('duplicated')), res.raw);
    assert.equal(lastConn, connBefore, 'the shape-check duplicate rejection must reject before a connection is even opened');
  });
});

// fmb-1942: table_config.columns[].rules.compute_rule is copied VERBATIM
// (column keys never need rewriting), and is judged against the TARGET's
// merged post-copy field context the same way the field-level rule above it
// already is.
describe('column-level compute rules (table_config.columns[].rules.compute_rule)', () => {
  it('rejects a copied column rule whose sibling-column reference does not resolve, naming the column', async () => {
    const items = fieldRow({
      id: 'src-field-1', field_key: 'items', field_type: 'table',
      table_config: {
        columns: [
          { key: 'part' },
          {
            key: 'label',
            rules: {
              compute_rule: {
                op: 'concat', overridable: true, output_type: 'string',
                config: { parts: [{ type: 'same_table_column', column_key: 'ghost' }] },
              },
            },
          },
        ],
      },
    });
    state.sourceFields = [items];
    const res = await request('POST', PATH, {
      source_blueprint_id: SOURCE_ID, target_blueprint_id: TARGET_ID,
      fields: [{ source_field_id: items.id, new_key: 'items', label: 'Items', section_key: 'general' }],
      source_snapshot: { [items.id]: fieldSnapshotFingerprint(items) },
    });
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'INVALID_COMPUTE_RULE');
    assert.match(res.raw, /label/, "the refusal must name the column key ('label')");
    assert.equal(lastConn.inserts.length, 0, 'no row may be written when a copied column rule fails validation');
  });

  it('accepts a copied column rule that reads a valid sibling column', async () => {
    const items = fieldRow({
      id: 'src-field-1', field_key: 'items', field_type: 'table',
      table_config: {
        columns: [
          { key: 'part' },
          {
            key: 'label',
            rules: {
              compute_rule: {
                op: 'concat', overridable: true, output_type: 'string',
                config: { parts: [{ type: 'same_table_column', column_key: 'part' }] },
              },
            },
          },
        ],
      },
    });
    state.sourceFields = [items];
    const res = await request('POST', PATH, {
      source_blueprint_id: SOURCE_ID, target_blueprint_id: TARGET_ID,
      fields: [{ source_field_id: items.id, new_key: 'items', label: 'Items', section_key: 'general' }],
      source_snapshot: { [items.id]: fieldSnapshotFingerprint(items) },
    });
    assert.equal(res.status, 200, res.raw);
    assert.equal(lastConn.inserts.filter((i) => i.table === 'blueprint_fields').length, 1);
  });
});

// fmb-1964 PR-D: a stored `copied` value_source is a retired mode — it must
// never be re-minted by a subset copy (only the write boundary that accepts
// it on import is exempt, and this path does not go through that boundary).
// `normalizeLegacyValueSource` (docker-api/src/shared/field-value-source.js)
// is the one place both shapes below collapse it.
describe('legacy `copied` value_source collapses to `calculated` on copy (fmb-1964 PR-D)', () => {
  function mirrorRule(key) {
    return JSON.stringify({ op: 'concat', overridable: false, output_type: 'string', config: { separator: '', parts: [{ type: 'field', key }] } });
  }

  it('a field-level stored `copied` field inserts `calculated`', async () => {
    const base = fieldRow({ id: 'src-field-1', field_key: 'base', field_label: 'Base' });
    const mirror = fieldRow({
      id: 'src-field-2', field_key: 'mirror', field_label: 'Mirror',
      value_source: 'copied', compute_rule: mirrorRule('base'),
    });
    state.sourceFields = [base, mirror];
    const res = await request('POST', PATH, {
      source_blueprint_id: SOURCE_ID, target_blueprint_id: TARGET_ID,
      fields: [
        { source_field_id: base.id, new_key: 'base', label: 'Base', section_key: 'general' },
        { source_field_id: mirror.id, new_key: 'mirror', label: 'Mirror', section_key: 'general' },
      ],
      source_snapshot: { [base.id]: fieldSnapshotFingerprint(base), [mirror.id]: fieldSnapshotFingerprint(mirror) },
    });
    assert.equal(res.status, 200, res.raw);
    const bfInserts = lastConn.inserts.filter((i) => i.table === 'blueprint_fields');
    const mirrorInsert = bfInserts.find((i) => {
      const cols = i.sql.match(/\(([\s\S]*?)\)/)[1].split(',').map((c) => c.trim().replace(/`/g, ''));
      return i.params[cols.indexOf('field_key')] === 'mirror';
    });
    const cols = mirrorInsert.sql.match(/\(([\s\S]*?)\)/)[1].split(',').map((c) => c.trim().replace(/`/g, ''));
    assert.equal(mirrorInsert.params[cols.indexOf('value_source')], 'calculated', 'a stored `copied` field must never be re-minted on copy');
    // Revert probe: with the normaliser bypassed this assertion is the one
    // that goes red — `value_source` would insert as the raw stored 'copied'.
  });

  it('a table field whose column rules carry a stored `copied` value_source inserts `calculated`', async () => {
    const items = fieldRow({
      id: 'src-field-1', field_key: 'items', field_type: 'table',
      table_config: {
        columns: [
          { key: 'part' },
          {
            key: 'label',
            rules: {
              value_source: 'copied',
              compute_rule: {
                op: 'concat', overridable: false, output_type: 'string',
                config: { separator: '', parts: [{ type: 'same_table_column', column_key: 'part' }] },
              },
            },
          },
        ],
      },
    });
    state.sourceFields = [items];
    const res = await request('POST', PATH, {
      source_blueprint_id: SOURCE_ID, target_blueprint_id: TARGET_ID,
      fields: [{ source_field_id: items.id, new_key: 'items', label: 'Items', section_key: 'general' }],
      source_snapshot: { [items.id]: fieldSnapshotFingerprint(items) },
    });
    assert.equal(res.status, 200, res.raw);
    const bfInsert = lastConn.inserts.find((i) => i.table === 'blueprint_fields');
    const cols = bfInsert.sql.match(/\(([\s\S]*?)\)/)[1].split(',').map((c) => c.trim().replace(/`/g, ''));
    const rawTableConfig = bfInsert.params[cols.indexOf('table_config')];
    const insertedTableConfig = typeof rawTableConfig === 'string' ? JSON.parse(rawTableConfig) : rawTableConfig;
    const labelColumn = insertedTableConfig.columns.find((c) => c.key === 'label');
    assert.equal(labelColumn.rules.value_source, 'calculated', 'a stored `copied` column rule must never be re-minted on copy');
    // Revert probe: with the normaliser bypassed this assertion is the one
    // that goes red — the column's rules.value_source would insert as 'copied'.
  });
});
