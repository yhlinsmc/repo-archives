'use strict';

/**
 * flow-run-writeback-preserve-real-db.test.js — a run that extracts NEITHER
 * link nor external_id must not erase a value the cache already held.
 *
 * WHY A REAL DATABASE. The thing under test is which value lands in the
 * column after the write-back UPDATE runs — COALESCE(?, column) vs a plain
 * bind is a difference the engine resolves, not the fixture: a stubbed driver
 * answers with whatever params it was handed and cannot show whether the
 * SECOND argument was ever consulted.
 *
 * Skips with a stated reason when no database is reachable, and fails instead
 * of skipping when REQUIRE_INTEGRATION_DB=1.
 */
const { test, describe, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const net = require('node:net');
const http = require('node:http');
const express = require('express');
const mariadb = require('mariadb');

const TEST_PREFIX = 'fwp_';
const tbl = (name) => `${TEST_PREFIX}${name}`;

let pool = null;
const lease = () => pool.getConnection();
const dbKey = require.resolve('../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: {
    pool: { ro: { getConnection: lease }, rw: { getConnection: lease } },
    t: tbl,
    getDynamicPool: async () => ({ ro: { getConnection: lease }, rw: { getConnection: lease } }),
  },
};

const { buildEngineTableDDLs, buildInfraTableDDLs } = require('../../src/table-ddls');
const { TABLES } = require('../../src/shared/constants');
const { _resetGrantsTableCache } = require('../../src/edge/lib/delegated-grants');
const router = require('../../src/edge/routes/internal/flow-recipes-run');

function parseEnvFile(filePath) {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    const out = {};
    for (const line of content.split('\n')) {
      const m = line.match(/^\s*([A-Z_][A-Z0-9_]*)\s*=\s*(.*)\s*$/);
      if (!m) continue;
      let value = m[2];
      if ((value.startsWith('"') && value.endsWith('"'))
        || (value.startsWith("'") && value.endsWith("'"))) value = value.slice(1, -1);
      out[m[1]] = value;
    }
    return out;
  } catch { return null; }
}

function probePort(host, port, timeoutMs = 2000) {
  return new Promise((resolve) => {
    const socket = new net.Socket();
    let done = false;
    const finish = (ok) => { if (done) return; done = true; socket.destroy(); resolve(ok); };
    socket.setTimeout(timeoutMs);
    socket.once('connect', () => finish(true));
    socket.once('timeout', () => finish(false));
    socket.once('error', () => finish(false));
    socket.connect(port, host);
  });
}

async function resolveMariaDbConfig() {
  if (process.env.DB_TEST_HOST && process.env.DB_TEST_ROOT_PASSWORD) {
    return {
      host: process.env.DB_TEST_HOST,
      port: parseInt(process.env.DB_TEST_PORT || '3306', 10),
      user: 'root', password: process.env.DB_TEST_ROOT_PASSWORD,
    };
  }
  const envPath = path.resolve(__dirname, '../../../.devcontainer/.env');
  const env = parseEnvFile(envPath);
  if (!env || !env.DB_ROOT_PASSWORD) return null;
  const port = parseInt(env.DB_PORT || '3306', 10);
  for (const host of ['127.0.0.1', 'mariadb', 'localhost']) {
    if (await probePort(host, port, 2000)) {
      return { host, port, user: 'root', password: env.DB_ROOT_PASSWORD };
    }
  }
  return null;
}

const OWNER = { id: 'u-owner', role: 'user' };
const BP1 = 'bp-1';
const T1 = 'tpl-1';
// Extracts both link and external_id from the upstream body.
const RECIPE_EXTRACT = 'r-extract';
// Extracts neither — a compute-only / no-JSONPath recipe, the shape a run
// that "says nothing" about link/external_id actually takes.
const RECIPE_NO_EXTRACT = 'r-no-extract';
let dbReady = false;
let skipReason = null;
let testDbName = null;
let server = null;
let baseUrl = null;
let currentUser = OWNER;

function ddlFor(...tables) {
  const wanted = new Set(tables.map((n) => tbl(n)));
  return [...buildInfraTableDDLs(tbl), ...buildEngineTableDDLs(tbl)].filter((sql) => {
    const m = sql.match(/CREATE TABLE IF NOT EXISTS `([^`]+)`/);
    return m && wanted.has(m[1]);
  });
}

before(async () => {
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) {
    skipReason = 'no MariaDB reachable via .devcontainer/.env or env vars';
    if (process.env.REQUIRE_INTEGRATION_DB === '1') throw new Error(`REQUIRE_INTEGRATION_DB=1 set but ${skipReason}.`);
    return;
  }
  testDbName = `flow_wb_preserve_test_${process.pid}_${Date.now()}`;
  let admin = null;
  try {
    admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`CREATE DATABASE \`${testDbName}\``);
    await admin.query(`USE \`${testDbName}\``);
    for (const sql of ddlFor(
      TABLES.HIERARCHY_NODES, TABLES.USER_TEMPLATES, TABLES.DELEGATED_GRANTS,
      TABLES.FLOW_RECIPES, TABLES.FLOW_RECIPE_STEPS, TABLES.FLOW_RECIPE_RUNS,
      TABLES.TEMPLATE_ACTIVITY, TABLES.FEATURE_AUDIT,
    )) await admin.query(sql);
    await admin.query(
      `INSERT INTO \`${tbl('hierarchy_nodes')}\` (id, name, node_type, owner_id) VALUES (?, 'BP1', 'blueprint', ?)`,
      [BP1, OWNER.id],
    );
    await admin.query(
      `INSERT INTO \`${tbl('user_templates')}\` (id, name, blueprint_id, owner_id) VALUES (?, 'one', ?, ?)`,
      [T1, BP1, OWNER.id],
    );
    await admin.query(
      `INSERT INTO \`${tbl('flow_recipes')}\`
         (id, name, is_active, blueprint_id, link_extract, external_id_extract, runs_on, status)
       VALUES (?, 'extracts', 1, ?, ?, ?, 'both', 'approved')`,
      [RECIPE_EXTRACT, BP1, JSON.stringify({ path: 'url' }), JSON.stringify({ path: 'id' })],
    );
    await admin.query(
      `INSERT INTO \`${tbl('flow_recipes')}\`
         (id, name, is_active, blueprint_id, link_extract, external_id_extract, runs_on, status)
       VALUES (?, 'no extract', 1, ?, NULL, NULL, 'both', 'approved')`,
      [RECIPE_NO_EXTRACT, BP1],
    );
    for (const [id, recipeId] of [['s-1', RECIPE_EXTRACT], ['s-2', RECIPE_NO_EXTRACT]]) {
      await admin.query(
        `INSERT INTO \`${tbl('flow_recipe_steps')}\` (id, recipe_id, \`sequence\`, name, method, url)
         VALUES (?, ?, 1, 'step one', 'POST', 'https://upstream.invalid/create')`,
        [id, recipeId],
      );
    }
    await admin.end();
    admin = null;

    pool = mariadb.createPool({ ...dbConfig, database: testDbName, connectionLimit: 4, connectTimeout: 5000 });
    _resetGrantsTableCache();

    const app = express();
    app.use(express.json({ limit: '2mb' }));
    app.use((req, _res, next) => { req.user = currentUser; next(); });
    app.use('/edge/internal/flow-recipes', router);
    server = http.createServer(app);
    await new Promise((r) => server.listen(0, r));
    baseUrl = `http://127.0.0.1:${server.address().port}`;
    dbReady = true;
  } catch (err) {
    skipReason = `setup failed: ${err.message}`;
    if (admin) { try { await admin.end(); } catch { /* best effort */ } }
    if (process.env.REQUIRE_INTEGRATION_DB === '1') throw err;
  }
});

after(async () => {
  if (server) { try { server.close(); } catch { /* best effort */ } }
  if (pool) { try { await pool.end(); } catch { /* best effort */ } }
  if (!testDbName) return;
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) return;
  try {
    const admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`DROP DATABASE IF EXISTS \`${testDbName}\``);
    await admin.end();
  } catch { /* best effort */ }
});

async function post(pathname, body, user) {
  currentUser = user;
  const res = await fetch(`${baseUrl}/edge/internal/flow-recipes/${pathname}`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
  });
  return { status: res.status, body: await res.json() };
}

const begin = (recipeId, user = OWNER) => post('run-begin', {
  recipe_id: recipeId, payload: { a: 1 }, template_id: T1,
}, user);

const finalize = (runId, recipeId, upstreamBody, user = OWNER) => post('run-finalize', {
  run_id: runId,
  recipe_id: recipeId,
  ok: true,
  upstream_status: 200,
  body: JSON.stringify(upstreamBody),
}, user);

async function runRecipe(recipeId, upstreamBody) {
  const began = await begin(recipeId);
  assert.equal(began.status, 200, `run-begin: ${JSON.stringify(began.body)}`);
  const runId = began.body.data.run_id;
  const ended = await finalize(runId, recipeId, upstreamBody);
  assert.equal(ended.status, 200, `run-finalize: ${JSON.stringify(ended.body)}`);
  return { runId, ended };
}

async function templateRow() {
  const rows = await pool.query(
    `SELECT flow_external_id, flow_link, flow_last_run_id FROM \`${tbl('user_templates')}\` WHERE id = ?`,
    [T1],
  );
  return rows[0];
}

async function linkExisting(externalId) {
  currentUser = OWNER;
  const res = await fetch(`${baseUrl}/edge/internal/flow-recipes/flow-templates/${T1}/link-existing`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ external_id: externalId }),
  });
  return { status: res.status, body: await res.json() };
}

const guard = (t) => { if (!dbReady) { t.skip(skipReason || 'database not ready'); return true; } return false; };

beforeEach(async () => {
  if (!dbReady) return;
  await pool.query(`DELETE FROM \`${tbl('flow_recipe_runs')}\``);
  await pool.query(
    `UPDATE \`${tbl('user_templates')}\`
        SET flow_external_id = NULL, flow_link = NULL, flow_last_run_id = NULL
      WHERE id = ?`, [T1],
  );
});

describe('the write-back preserves a value a run did not extract', () => {
  test('a hand-linked external_id survives a run with no external_id_extract and no emit; a run that DOES extract still overwrites it', async (t) => {
    if (guard(t)) return;
    const linked = await linkExisting('1021');
    assert.equal(linked.status, 200, JSON.stringify(linked.body));

    const first = await runRecipe(RECIPE_NO_EXTRACT, { url: 'https://upstream.invalid/x', id: 'IGNORED' });
    const afterFirst = await templateRow();
    assert.equal(afterFirst.flow_external_id, '1021', 'a run extracting nothing must not NULL the hand-linked id');
    assert.equal(afterFirst.flow_last_run_id, first.runId, 'flow_last_run_id must still stamp to the new run');

    const second = await runRecipe(RECIPE_EXTRACT, { url: 'https://upstream.invalid/y', id: 'EXT-NEW' });
    const afterSecond = await templateRow();
    assert.equal(afterSecond.flow_external_id, 'EXT-NEW', 'a run that DOES extract must still overwrite');
    assert.equal(afterSecond.flow_last_run_id, second.runId);
  });

  test('a second, organic run that extracts nothing does not wipe the first run\'s recorded external_id/link', async (t) => {
    if (guard(t)) return;
    const first = await runRecipe(RECIPE_EXTRACT, { url: 'https://upstream.invalid/a', id: 'EXT-A' });
    const afterFirst = await templateRow();
    assert.equal(afterFirst.flow_external_id, 'EXT-A');
    assert.equal(afterFirst.flow_link, 'https://upstream.invalid/a');

    const second = await runRecipe(RECIPE_NO_EXTRACT, { anything: 'else' });
    const afterSecond = await templateRow();
    assert.equal(afterSecond.flow_external_id, 'EXT-A', 'the second flow wiped the first run\'s external_id');
    assert.equal(afterSecond.flow_link, 'https://upstream.invalid/a', 'the second flow wiped the first run\'s link');
    assert.equal(afterSecond.flow_last_run_id, second.runId, 'flow_last_run_id must still advance to the newer run');
  });
});
