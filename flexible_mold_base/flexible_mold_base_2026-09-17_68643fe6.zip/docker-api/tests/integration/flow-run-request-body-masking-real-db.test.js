'use strict';

/**
 * flow-run-request-body-masking-real-db.test.js — pins
 * `maskEntryRequestBodies`' content-type-dispatched masking through the REAL
 * run-finalize write path (JSON column write + read-back), not a mocked pool.
 * A mock cannot show whether the driver's own JSON column handling (autoJsonMap
 * on write, CAST AS CHAR on the detail read) round-trips the masked text intact
 * — the precision sibling test (flow-run-step-results-precision-real-db.test.js)
 * exists for the identical reason on a different column value.
 *
 * Skips with a stated reason when no database is reachable, and fails instead of
 * skipping when REQUIRE_INTEGRATION_DB=1.
 */
const { test, describe, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const net = require('node:net');
const http = require('node:http');
const express = require('express');
const mariadb = require('mariadb');
const { makeStubReqLog } = require('../helpers/stub-req-log');

const TEST_PREFIX = 'frbm_';
const tbl = (name) => `${TEST_PREFIX}${name}`;

let pool = null;
const lease = () => pool.getConnection();

const dbKey = require.resolve('../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey,
  filename: dbKey,
  loaded: true,
  exports: {
    pool: { ro: { getConnection: lease }, rw: { getConnection: lease } },
    t: tbl,
    getDynamicPool: async () => ({ ro: { getConnection: lease }, rw: { getConnection: lease } }),
  },
};

const { buildEngineTableDDLs, buildInfraTableDDLs } = require('../../src/table-ddls');
const { TABLES } = require('../../src/shared/constants');
const router = require('../../src/edge/routes/internal/flow-recipes-run');

// ── Config auto-detection (same shape as the sibling integration tests) ──────
function parseEnvFile(filePath) {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    const out = {};
    for (const line of content.split('\n')) {
      const m = line.match(/^\s*([A-Z_][A-Z0-9_]*)\s*=\s*(.*)\s*$/);
      if (!m) continue;
      let value = m[2];
      if ((value.startsWith('"') && value.endsWith('"'))
        || (value.startsWith("'") && value.endsWith("'"))) value = value.slice(1, -1);
      out[m[1]] = value;
    }
    return out;
  } catch { return null; }
}

function probePort(host, port, timeoutMs = 2000) {
  return new Promise((resolve) => {
    const socket = new net.Socket();
    let done = false;
    const finish = (ok) => { if (done) return; done = true; socket.destroy(); resolve(ok); };
    socket.setTimeout(timeoutMs);
    socket.once('connect', () => finish(true));
    socket.once('timeout', () => finish(false));
    socket.once('error', () => finish(false));
    socket.connect(port, host);
  });
}

async function resolveMariaDbConfig() {
  if (process.env.DB_TEST_HOST && process.env.DB_TEST_ROOT_PASSWORD) {
    return {
      host: process.env.DB_TEST_HOST,
      port: parseInt(process.env.DB_TEST_PORT || '3306', 10),
      user: 'root', password: process.env.DB_TEST_ROOT_PASSWORD,
    };
  }
  const envPath = path.resolve(__dirname, '../../../.devcontainer/.env');
  const env = parseEnvFile(envPath);
  if (!env || !env.DB_ROOT_PASSWORD) return null;
  const port = parseInt(env.DB_PORT || '3306', 10);
  for (const host of ['127.0.0.1', 'mariadb', 'localhost']) {
    if (await probePort(host, port, 2000)) {
      return { host, port, user: 'root', password: env.DB_ROOT_PASSWORD };
    }
  }
  return null;
}

// ── Fixture ─────────────────────────────────────────────────────────────────
const ADMIN = { id: '22222222-2222-2222-2222-222222222222', role: 'admin' };
const RECIPE_ID = '33333333-3333-3333-3333-333333333333';

let dbReady = false;
let skipReason = null;
let testDbName = null;
let server = null;
let baseUrl = null;
let runCounter = 0;

before(async () => {
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) {
    skipReason = 'no MariaDB reachable via .devcontainer/.env or env vars';
    if (process.env.REQUIRE_INTEGRATION_DB === '1') throw new Error(`REQUIRE_INTEGRATION_DB=1 set but ${skipReason}.`);
    return;
  }
  testDbName = `frbm_test_${process.pid}_${Date.now()}`;
  let admin = null;
  try {
    admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`CREATE DATABASE \`${testDbName}\``);
    await admin.query(`USE \`${testDbName}\``);
    for (const sql of [...buildInfraTableDDLs(tbl), ...buildEngineTableDDLs(tbl)]) await admin.query(sql);
    await admin.end();
    admin = null;

    pool = mariadb.createPool({ ...dbConfig, database: testDbName, connectionLimit: 4, connectTimeout: 5000 });

    await pool.query(
      `INSERT INTO \`${tbl(TABLES.FLOW_RECIPES)}\` (id, name, link_extract, external_id_extract) VALUES (?, ?, NULL, NULL)`,
      [RECIPE_ID, 'request-body real-db masking fixture'],
    );

    const app = express();
    app.use((req, _res, next) => { req.log = makeStubReqLog(); next(); });
    app.use(express.json());
    app.use((req, _res, next) => { req.user = ADMIN; next(); });
    app.use('/', router);
    server = http.createServer(app);
    await new Promise((r) => server.listen(0, r));
    baseUrl = `http://127.0.0.1:${server.address().port}`;
    dbReady = true;
  } catch (err) {
    skipReason = `setup failed: ${err.message}`;
    if (admin) { try { await admin.end(); } catch { /* best effort */ } }
    if (process.env.REQUIRE_INTEGRATION_DB === '1') throw err;
  }
});

after(async () => {
  if (server) { try { server.close(); } catch { /* best effort */ } }
  if (pool) { try { await pool.end(); } catch { /* best effort */ } }
  if (!testDbName) return;
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) return;
  try {
    const admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`DROP DATABASE IF EXISTS \`${testDbName}\``);
    await admin.end();
  } catch { /* best effort */ }
});

const guard = (t) => { if (!dbReady) { t.skip(skipReason || 'database not ready'); return true; } return false; };

let currentRunId = null;
beforeEach(async () => {
  if (!dbReady) return;
  runCounter += 1;
  currentRunId = `44444444-4444-4444-4444-${String(runCounter).padStart(12, '0')}`;
  await pool.query(
    `INSERT INTO \`${tbl(TABLES.FLOW_RECIPE_RUNS)}\` (id, recipe_id, actor_id, mode, status) VALUES (?, ?, ?, 'create', 'partial')`,
    [currentRunId, RECIPE_ID, ADMIN.id],
  );
});

async function finalizeOneRequest(request) {
  const res = await fetch(`${baseUrl}/run-finalize`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({
      run_id: currentRunId, recipe_id: RECIPE_ID, ok: true, upstream_status: 200,
      body: JSON.stringify({ url: 'https://x', id: 'Y' }),
      step_results: [{ step_id: 's1', ok: true, sequence: 1, request }],
    }),
  });
  const json = await res.json();
  assert.equal(res.status, 200, `run-finalize failed: ${JSON.stringify(json)}`);
  const raw = await pool.query(
    `SELECT CAST(step_results AS CHAR) AS sr FROM \`${tbl(TABLES.FLOW_RECIPE_RUNS)}\` WHERE id = ?`,
    [currentRunId],
  );
  return JSON.parse(raw[0].sr)[0].request;
}

describe('run-finalize request-body storage masking on a real database', () => {
  test('a form-urlencoded body: client_secret=abc is stored client_secret=****', async (t) => {
    if (guard(t)) return;
    const req = await finalizeOneRequest({
      method: 'POST', url: 'https://vendor.example/tasks',
      body: 'client_secret=abc&note=hello', content_type: 'application/x-www-form-urlencoded',
    });
    assert.equal(req.body, 'client_secret=****&note=hello');
  });

  test('a JSON body: {"token":"abc"} is stored with token masked', async (t) => {
    if (guard(t)) return;
    const req = await finalizeOneRequest({
      method: 'POST', url: 'https://vendor.example/tasks',
      body: JSON.stringify({ token: 'abc' }), content_type: 'application/json',
    });
    assert.equal(req.body, JSON.stringify({ token: '****' }));
  });

  test('a short secret-shaped query value: ?access_token=abc is stored masked', async (t) => {
    if (guard(t)) return;
    const req = await finalizeOneRequest({ method: 'GET', url: 'https://vendor.example/api?access_token=abc' });
    assert.ok(!req.url.includes('=abc'), `short secret value survived: ${req.url}`);
    assert.ok(req.url.includes('****'), `url must carry the mask: ${req.url}`);
  });

  test('an XML body is stored as the withheld placeholder, never the raw upstream text', async (t) => {
    if (guard(t)) return;
    const req = await finalizeOneRequest({
      method: 'POST', url: 'https://vendor.example/tasks',
      body: '<root><token>abc</token></root>', content_type: 'application/xml',
    });
    assert.equal(req.body, '[unstructured request body withheld]');
  });
});
