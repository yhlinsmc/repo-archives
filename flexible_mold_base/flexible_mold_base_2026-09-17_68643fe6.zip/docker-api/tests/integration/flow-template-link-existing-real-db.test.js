'use strict';

/**
 * flow-template-link-existing-real-db.test.js — pointing a template at a remote
 * record that already exists, by hand, under the same access boundary the reset
 * endpoint uses.
 *
 * WHY A REAL DATABASE. The guard is a predicate ANDed into the UPDATE's WHERE,
 * so "who may link" is decided by which rows MariaDB matches — a stubbed driver
 * answers with the fixture, not the engine. The 403/200 split, the trimmed
 * columns, the untouched flow_last_run_id and the audit row are all the engine's
 * answer here.
 *
 * Skips with a stated reason when no database is reachable, and fails instead of
 * skipping when REQUIRE_INTEGRATION_DB=1.
 */
const { test, describe, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const net = require('node:net');
const http = require('node:http');
const express = require('express');
const mariadb = require('mariadb');

const TEST_PREFIX = 'ftl_';
const tbl = (name) => `${TEST_PREFIX}${name}`;

let pool = null;
const lease = () => pool.getConnection();
const dbKey = require.resolve('../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: {
    pool: { ro: { getConnection: lease }, rw: { getConnection: lease } },
    t: tbl,
    getDynamicPool: async () => ({ ro: { getConnection: lease }, rw: { getConnection: lease } }),
  },
};

const { buildEngineTableDDLs, buildInfraTableDDLs } = require('../../src/table-ddls');
const { TABLES } = require('../../src/shared/constants');
const { _resetGrantsTableCache } = require('../../src/edge/lib/delegated-grants');
const router = require('../../src/edge/routes/internal/flow-recipes-run');

function parseEnvFile(filePath) {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    const out = {};
    for (const line of content.split('\n')) {
      const m = line.match(/^\s*([A-Z_][A-Z0-9_]*)\s*=\s*(.*)\s*$/);
      if (!m) continue;
      let value = m[2];
      if ((value.startsWith('"') && value.endsWith('"'))
        || (value.startsWith("'") && value.endsWith("'"))) value = value.slice(1, -1);
      out[m[1]] = value;
    }
    return out;
  } catch { return null; }
}

function probePort(host, port, timeoutMs = 2000) {
  return new Promise((resolve) => {
    const socket = new net.Socket();
    let done = false;
    const finish = (ok) => { if (done) return; done = true; socket.destroy(); resolve(ok); };
    socket.setTimeout(timeoutMs);
    socket.once('connect', () => finish(true));
    socket.once('timeout', () => finish(false));
    socket.once('error', () => finish(false));
    socket.connect(port, host);
  });
}

async function resolveMariaDbConfig() {
  if (process.env.DB_TEST_HOST && process.env.DB_TEST_ROOT_PASSWORD) {
    return {
      host: process.env.DB_TEST_HOST,
      port: parseInt(process.env.DB_TEST_PORT || '3306', 10),
      user: 'root', password: process.env.DB_TEST_ROOT_PASSWORD,
    };
  }
  const envPath = path.resolve(__dirname, '../../../.devcontainer/.env');
  const env = parseEnvFile(envPath);
  if (!env || !env.DB_ROOT_PASSWORD) return null;
  const port = parseInt(env.DB_PORT || '3306', 10);
  for (const host of ['127.0.0.1', 'mariadb', 'localhost']) {
    if (await probePort(host, port, 2000)) {
      return { host, port, user: 'root', password: env.DB_ROOT_PASSWORD };
    }
  }
  return null;
}

const OWNER = { id: 'u-owner', role: 'user' };
const EDITOR = { id: 'u-editor', role: 'editor' };
const ADMIN = { id: 'u-admin', role: 'admin' };
const BP1 = 'bp-1';
const T1 = 'tpl-1';
let dbReady = false;
let skipReason = null;
let testDbName = null;
let server = null;
let baseUrl = null;
let currentUser = OWNER;

function ddlFor(...tables) {
  const wanted = new Set(tables.map((n) => tbl(n)));
  return [...buildInfraTableDDLs(tbl), ...buildEngineTableDDLs(tbl)].filter((sql) => {
    const m = sql.match(/CREATE TABLE IF NOT EXISTS `([^`]+)`/);
    return m && wanted.has(m[1]);
  });
}

before(async () => {
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) {
    skipReason = 'no MariaDB reachable via .devcontainer/.env or env vars';
    if (process.env.REQUIRE_INTEGRATION_DB === '1') throw new Error(`REQUIRE_INTEGRATION_DB=1 set but ${skipReason}.`);
    return;
  }
  testDbName = `flow_link_existing_test_${process.pid}_${Date.now()}`;
  let admin = null;
  try {
    admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`CREATE DATABASE \`${testDbName}\``);
    await admin.query(`USE \`${testDbName}\``);
    for (const sql of ddlFor(
      TABLES.HIERARCHY_NODES, TABLES.USER_TEMPLATES, TABLES.DELEGATED_GRANTS,
      TABLES.FEATURE_AUDIT,
    )) await admin.query(sql);
    await admin.query(
      `INSERT INTO \`${tbl('hierarchy_nodes')}\` (id, name, node_type, owner_id) VALUES (?, 'BP1', 'blueprint', ?)`,
      [BP1, OWNER.id],
    );
    await admin.query(
      `INSERT INTO \`${tbl('user_templates')}\` (id, name, blueprint_id, owner_id) VALUES (?, 'one', ?, ?)`,
      [T1, BP1, OWNER.id],
    );
    await admin.end();
    admin = null;

    pool = mariadb.createPool({ ...dbConfig, database: testDbName, connectionLimit: 4, connectTimeout: 5000 });
    _resetGrantsTableCache();

    const app = express();
    app.use(express.json({ limit: '2mb' }));
    app.use((req, _res, next) => { req.user = currentUser; next(); });
    app.use('/edge/internal/flow-recipes', router);
    server = http.createServer(app);
    await new Promise((r) => server.listen(0, r));
    baseUrl = `http://127.0.0.1:${server.address().port}`;
    dbReady = true;
  } catch (err) {
    skipReason = `setup failed: ${err.message}`;
    if (admin) { try { await admin.end(); } catch { /* best effort */ } }
    if (process.env.REQUIRE_INTEGRATION_DB === '1') throw err;
  }
});

after(async () => {
  if (server) { try { server.close(); } catch { /* best effort */ } }
  if (pool) { try { await pool.end(); } catch { /* best effort */ } }
  if (!testDbName) return;
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) return;
  try {
    const admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`DROP DATABASE IF EXISTS \`${testDbName}\``);
    await admin.end();
  } catch { /* best effort */ }
});

async function linkExisting(user, body) {
  currentUser = user;
  const res = await fetch(`${baseUrl}/edge/internal/flow-recipes/flow-templates/${T1}/link-existing`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
  });
  let json = null; try { json = await res.json(); } catch { json = null; }
  return { status: res.status, body: json };
}

async function templateRow() {
  const rows = await pool.query(
    `SELECT flow_external_id, flow_link, flow_remote_refs, flow_last_run_id
       FROM \`${tbl('user_templates')}\` WHERE id = ?`, [T1],
  );
  const r = rows[0];
  return {
    ...r,
    flow_remote_refs: r.flow_remote_refs == null
      ? null
      : (typeof r.flow_remote_refs === 'string' ? JSON.parse(r.flow_remote_refs) : r.flow_remote_refs),
  };
}

async function auditCount(eventType) {
  const rows = await pool.query(
    `SELECT COUNT(*) AS n FROM \`${tbl('feature_audit')}\` WHERE event_type = ?`, [eventType],
  );
  return Number(rows[0].n);
}

const guard = (t) => { if (!dbReady) { t.skip(skipReason || 'database not ready'); return true; } return false; };

beforeEach(async () => {
  if (!dbReady) return;
  await pool.query(
    `UPDATE \`${tbl('user_templates')}\`
        SET flow_external_id = NULL, flow_link = NULL, flow_remote_refs = NULL, flow_last_run_id = NULL
      WHERE id = ?`, [T1],
  );
  await pool.query(`DELETE FROM \`${tbl('delegated_grants')}\``);
  await pool.query(`DELETE FROM \`${tbl('feature_audit')}\``);
});

describe('link a template to an existing remote record', () => {
  test('an editor without a grant is refused, existence-neutral, and writes nothing', async (t) => {
    if (guard(t)) return;
    const res = await linkExisting(EDITOR, { external_id: '1021' });
    assert.equal(res.status, 403, JSON.stringify(res.body));
    assert.equal(res.body.error.code, 'TEMPLATE_FORBIDDEN');
    const row = await templateRow();
    assert.equal(row.flow_external_id, null);
    assert.equal(row.flow_link, null);
    assert.equal(row.flow_remote_refs, null);
    assert.equal(await auditCount('flow.template.link_existing'), 0);
  });

  test('the owner links: three columns written (trimmed), run id untouched, one audit row', async (t) => {
    if (guard(t)) return;
    const res = await linkExisting(OWNER, { external_id: ' 1021 ', link: 'https://x/1021', remote_refs: { tasks: [] } });
    assert.equal(res.status, 200, JSON.stringify(res.body));
    const row = await templateRow();
    assert.equal(row.flow_external_id, '1021');
    assert.equal(row.flow_link, 'https://x/1021');
    assert.deepEqual(row.flow_remote_refs, { tasks: [] });
    assert.equal(row.flow_last_run_id, null, 'link-existing must leave flow_last_run_id as it was');
    assert.equal(await auditCount('flow.template.link_existing'), 1);
  });

  test('a secret-named leaf in remote_refs is masked on write; a captured id is not', async (t) => {
    if (guard(t)) return;
    const res = await linkExisting(OWNER, {
      external_id: '1021',
      remote_refs: { tasks: [{ id: 't1', access_token: 'sk-abc' }] },
    });
    assert.equal(res.status, 200, JSON.stringify(res.body));
    const row = await templateRow();
    assert.equal(row.flow_remote_refs.tasks[0].access_token, '****', 'access_token must be masked');
    assert.equal(row.flow_remote_refs.tasks[0].id, 't1', 'a captured id is not a secret and must survive intact');
  });

  test('an oversized remote_refs is refused 413 and writes nothing', async (t) => {
    if (guard(t)) return;
    const huge = { tasks: [{ id: 'x'.repeat(70 * 1024) }] };
    const res = await linkExisting(ADMIN, { external_id: '1021', remote_refs: huge });
    assert.equal(res.status, 413, JSON.stringify(res.body));
    assert.equal(res.body.error.code, 'REMOTE_REFS_TOO_LARGE');
    const row = await templateRow();
    assert.equal(row.flow_external_id, null);
    assert.equal(row.flow_remote_refs, null);
  });

  test('link at the MAX_LINK_LEN boundary (8192 chars) is accepted', async (t) => {
    if (guard(t)) return;
    const link = 'https://x/' + 'a'.repeat(8192 - 'https://x/'.length);
    assert.equal(link.length, 8192);
    const res = await linkExisting(OWNER, { external_id: '1021', link });
    assert.equal(res.status, 200, JSON.stringify(res.body));
    const row = await templateRow();
    assert.equal(row.flow_link, link);
  });

  test('link one over MAX_LINK_LEN is refused 400 naming link, no column change', async (t) => {
    if (guard(t)) return;
    const link = 'https://x/' + 'a'.repeat(8192 - 'https://x/'.length + 1);
    assert.equal(link.length, 8193);
    const res = await linkExisting(OWNER, { external_id: '1021', link });
    assert.equal(res.status, 400, JSON.stringify(res.body));
    assert.equal(res.body.error.code, 'VALIDATION');
    assert.match(res.body.error.message, /link/);
    const row = await templateRow();
    assert.equal(row.flow_external_id, null, 'an over-cap link must write nothing');
    assert.equal(row.flow_link, null);
  });

  test('an empty external_id is a 400', async (t) => {
    if (guard(t)) return;
    const res = await linkExisting(OWNER, { external_id: '' });
    assert.equal(res.status, 400, JSON.stringify(res.body));
    assert.equal(res.body.error.code, 'VALIDATION');
  });

  test('an unknown body key is refused fail-closed (400)', async (t) => {
    if (guard(t)) return;
    const res = await linkExisting(OWNER, { external_id: '1', foo: 1 });
    assert.equal(res.status, 400, JSON.stringify(res.body));
    assert.equal(res.body.error.code, 'VALIDATION');
    const row = await templateRow();
    assert.equal(row.flow_external_id, null, 'a rejected body must write nothing');
  });
});
