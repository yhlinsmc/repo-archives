'use strict';

/**
 * flow-compare-trigger-taken-real-db.test.js — at most one step per recipe
 * may hold `step_runs_on: 'compare'` (I4). Enforced on POST and PUT inside
 * the SAME transaction the parent recipe is locked in (FOR UPDATE) —
 * `assertStepInvariantsInTx`'s sibling read is itself a FOR UPDATE, race-free
 * with a concurrent write on another step of the same recipe.
 *
 * WHY REAL DB. The invariant's outcome is a row count and a stored column —
 * a mocked pool answers whatever a fixture is told to and cannot show what
 * the SECOND write actually persisted.
 *
 * Skips with a stated reason when no database is reachable, and FAILS instead
 * of skipping when REQUIRE_INTEGRATION_DB=1 — a silent skip is the failure
 * mode this whole line of work exists to end.
 */
const {
  test, describe, before, after, beforeEach,
} = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const net = require('node:net');
const http = require('node:http');
const express = require('express');
const mariadb = require('mariadb');

const TEST_PREFIX = 'fctt_';
const tbl = (name) => `${TEST_PREFIX}${name}`;

let pool = null;
const lease = () => pool.getConnection();
// Both halves of the real pool object: the CRUD factory leases a connection for
// its write transaction AND the pre-tx gates call `pool.ro.query` directly.
const handle = () => ({ getConnection: lease, query: (sql, params) => pool.query(sql, params) });

const dbKey = require.resolve('../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey,
  filename: dbKey,
  loaded: true,
  exports: {
    pool: { ro: handle(), rw: handle() },
    t: tbl,
    getDynamicPool: async () => ({ ro: handle(), rw: handle() }),
  },
};

const { buildEngineTableDDLs, buildInfraTableDDLs } = require('../../src/table-ddls');
const stepsRouter = require('../../src/edge/routes/app/flow-recipe-steps');

// ── Config auto-detection (same shape as the sibling integration tests) ──────

function parseEnvFile(filePath) {
  try {
    const out = {};
    for (const line of fs.readFileSync(filePath, 'utf-8').split('\n')) {
      const m = line.match(/^\s*([A-Z_][A-Z0-9_]*)\s*=\s*(.*)\s*$/);
      if (!m) continue;
      let value = m[2];
      if ((value.startsWith('"') && value.endsWith('"'))
        || (value.startsWith("'") && value.endsWith("'"))) {
        value = value.slice(1, -1);
      }
      out[m[1]] = value;
    }
    return out;
  } catch {
    return null;
  }
}

function probePort(host, port, timeoutMs = 2000) {
  return new Promise((resolve) => {
    const socket = new net.Socket();
    let done = false;
    const finish = (ok) => {
      if (done) return;
      done = true;
      socket.destroy();
      resolve(ok);
    };
    socket.setTimeout(timeoutMs);
    socket.once('connect', () => finish(true));
    socket.once('timeout', () => finish(false));
    socket.once('error', () => finish(false));
    socket.connect(port, host);
  });
}

async function resolveMariaDbConfig() {
  if (process.env.DB_TEST_HOST && process.env.DB_TEST_ROOT_PASSWORD) {
    return {
      host: process.env.DB_TEST_HOST,
      port: parseInt(process.env.DB_TEST_PORT || '3306', 10),
      user: 'root',
      password: process.env.DB_TEST_ROOT_PASSWORD,
    };
  }
  const env = parseEnvFile(path.resolve(__dirname, '../../../.devcontainer/.env'));
  if (!env || !env.DB_ROOT_PASSWORD) return null;
  const port = parseInt(env.DB_PORT || '3306', 10);
  for (const host of ['127.0.0.1', 'mariadb', 'localhost']) {
    if (await probePort(host, port, 2000)) {
      return { host, port, user: 'root', password: env.DB_ROOT_PASSWORD };
    }
  }
  return null;
}

// ── Fixture ─────────────────────────────────────────────────────────────────

const EDITOR_ID = 'aaaaaaa1-1111-4111-8111-111111111111';
const RECIPE_ID = 'bbbbbbb2-2222-4222-8222-222222222222';
const BLUEPRINT_ID = 'ccccccc3-3333-4333-8333-333333333333';
const RELEASE_ID = 'ddddddd4-4444-4444-8444-444444444444';
const TRIGGER_STEP_ID = 'eeeeeee5-5555-4555-8555-555555555555';
const OTHER_STEP_ID = 'fffffff6-6666-4666-8666-666666666666';

const EDITOR = { id: EDITOR_ID, role: 'editor' };

let dbReady = false;
let skipReason = null;
let testDbName = null;
let server = null;
let baseUrl = null;
let currentUser = EDITOR;

before(async () => {
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) {
    skipReason = 'no MariaDB reachable via .devcontainer/.env or env vars';
    if (process.env.REQUIRE_INTEGRATION_DB === '1') {
      throw new Error(`REQUIRE_INTEGRATION_DB=1 set but ${skipReason}.`);
    }
    return;
  }
  testDbName = `flow_compare_trigger_taken_${process.pid}_${Date.now()}`;
  let admin = null;
  try {
    admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`CREATE DATABASE \`${testDbName}\``);
    await admin.query(`USE \`${testDbName}\``);
    // Every table, built from the DDL that creates the real ones — a
    // hand-picked subset drops a table some guard probes and turns its
    // refusal into a degrade nobody asked for.
    for (const sql of [...buildInfraTableDDLs(tbl), ...buildEngineTableDDLs(tbl)]) {
      await admin.query(sql);
    }
    await admin.end();
    admin = null;

    pool = mariadb.createPool({
      ...dbConfig, database: testDbName, connectionLimit: 6, connectTimeout: 5000,
    });

    const app = express();
    app.use(express.json());
    app.use((req, _res, next) => { req.user = currentUser; next(); });
    app.use('/edge/app/flow-recipe-steps', stepsRouter);
    server = http.createServer(app);
    await new Promise((r) => server.listen(0, r));
    baseUrl = `http://127.0.0.1:${server.address().port}`;
    dbReady = true;
  } catch (err) {
    skipReason = `setup failed: ${err.message}`;
    if (admin) { try { await admin.end(); } catch { /* best effort */ } }
    if (process.env.REQUIRE_INTEGRATION_DB === '1') throw err;
  }
});

after(async () => {
  if (server) { try { server.close(); } catch { /* best effort */ } }
  if (pool) { try { await pool.end(); } catch { /* best effort */ } }
  if (!testDbName) return;
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) return;
  try {
    const admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`DROP DATABASE IF EXISTS \`${testDbName}\``);
    await admin.end();
  } catch { /* best effort */ }
});

async function call(method, url, body) {
  const res = await fetch(`${baseUrl}${url}`, {
    method,
    headers: { 'content-type': 'application/json' },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const text = await res.text();
  let parsed = null;
  try { parsed = JSON.parse(text); } catch { parsed = { raw: text }; }
  return { status: res.status, body: parsed };
}

const q = (sql, params) => pool.query(sql, params);
const one = async (sql, params) => (await pool.query(sql, params))[0];
const countOf = async (sql, params) => Number((await one(sql, params)).n);

const guard = (t) => {
  if (dbReady) return false;
  t.skip(skipReason || 'database not ready');
  return true;
};

const stepCount = () => countOf(
  `SELECT COUNT(*) AS n FROM \`${tbl('flow_recipe_steps')}\` WHERE recipe_id = ?`, [RECIPE_ID],
);

const runsOnOf = async (id) => (await one(
  `SELECT step_runs_on FROM \`${tbl('flow_recipe_steps')}\` WHERE id = ?`, [id],
)).step_runs_on;

beforeEach(async () => {
  if (!dbReady) return;
  for (const name of ['flow_recipe_steps', 'flow_recipes', 'hierarchy_nodes', 'users']) {
    await q(`DELETE FROM \`${tbl(name)}\``);
  }
  await q(
    `INSERT INTO \`${tbl('users')}\` (id, email, role, banned) VALUES (?,?,?,0)`,
    [EDITOR_ID, 'editor@test.local', 'editor'],
  );
  await q(
    `INSERT INTO \`${tbl('hierarchy_nodes')}\` (id, parent_id, name, node_type) VALUES (?,?,?,?)`,
    [RELEASE_ID, null, 'release', 'release'],
  );
  // Shared blueprint (owner NULL) — this file is about the compare-trigger
  // invariant, not ownership, so nothing here should route through it.
  await q(
    `INSERT INTO \`${tbl('hierarchy_nodes')}\` (id, parent_id, name, node_type, owner_id) VALUES (?,?,?,?,?)`,
    [BLUEPRINT_ID, RELEASE_ID, 'a blueprint', 'blueprint', null],
  );
  await q(
    `INSERT INTO \`${tbl('flow_recipes')}\` (id, name, owner_id, blueprint_id, status) VALUES (?,?,?,?,'pending')`,
    [RECIPE_ID, 'a recipe', null, BLUEPRINT_ID],
  );
  // The existing compare trigger, seeded directly (bypassing the write path
  // under test) so every case starts from the same "one trigger already
  // exists" state.
  await q(
    `INSERT INTO \`${tbl('flow_recipe_steps')}\`
       (id, recipe_id, \`sequence\`, name, method, url, step_runs_on)
     VALUES (?,?,0,?,?,?, 'compare')`,
    [TRIGGER_STEP_ID, RECIPE_ID, 'the trigger', 'GET', 'https://example.invalid/trigger'],
  );
});

describe('POST a second compare step under a recipe that already has one', () => {
  test('is refused 400 FLOW_COMPARE_TRIGGER_TAKEN, naming the existing trigger, and no row is inserted', async (t) => {
    if (guard(t)) return;
    const before2 = await stepCount();
    const res = await call('POST', '/edge/app/flow-recipe-steps/', {
      recipe_id: RECIPE_ID, name: 'a second preview', method: 'GET',
      url: 'https://example.invalid/second', step_runs_on: 'compare',
    });
    assert.equal(res.status, 400);
    assert.equal(res.body?.error?.code, 'FLOW_COMPARE_TRIGGER_TAKEN');
    assert.match(res.body?.error?.message, /the trigger/);
    assert.equal(await stepCount(), before2, 'row count must be unchanged — nothing was inserted');
  });

  test('POST with step_runs_on other than compare is unaffected (control)', async (t) => {
    if (guard(t)) return;
    const res = await call('POST', '/edge/app/flow-recipe-steps/', {
      recipe_id: RECIPE_ID, name: 'an ordinary step', method: 'POST',
      url: 'https://example.invalid/ordinary', step_runs_on: 'both',
    });
    assert.equal(res.status, 200);
    assert.equal(await stepCount(), 2);
  });
});

describe('PUT an existing step to compare when another step already holds it', () => {
  beforeEach(async () => {
    if (!dbReady) return;
    await q(
      `INSERT INTO \`${tbl('flow_recipe_steps')}\`
         (id, recipe_id, \`sequence\`, name, method, url, step_runs_on)
       VALUES (?,?,1,?,?,?, 'both')`,
      [OTHER_STEP_ID, RECIPE_ID, 'the other step', 'GET', 'https://example.invalid/other'],
    );
  });

  test('is refused 400 FLOW_COMPARE_TRIGGER_TAKEN and the stored row is unchanged', async (t) => {
    if (guard(t)) return;
    const res = await call('PUT', `/edge/app/flow-recipe-steps/${OTHER_STEP_ID}`, {
      step_runs_on: 'compare',
    });
    assert.equal(res.status, 400);
    assert.equal(res.body?.error?.code, 'FLOW_COMPARE_TRIGGER_TAKEN');
    assert.equal(await runsOnOf(OTHER_STEP_ID), 'both', 'the PUT must not have persisted');
    assert.equal(await stepCount(), 2, 'row count must be unchanged');
  });

  test('PUTting the CURRENT trigger step itself to compare (a no-op re-save) still succeeds', async (t) => {
    if (guard(t)) return;
    // Self-exclusion: the sibling read must exclude the step being written,
    // or a step re-saving its own already-held trigger would collide with
    // itself.
    const res = await call('PUT', `/edge/app/flow-recipe-steps/${TRIGGER_STEP_ID}`, {
      step_runs_on: 'compare', name: 'renamed trigger',
    });
    assert.equal(res.status, 200);
    assert.equal(await runsOnOf(TRIGGER_STEP_ID), 'compare');
  });
});
