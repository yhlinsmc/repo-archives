'use strict';

/**
 * flow-run-delete-real-db.test.js — who may delete a run row, and what a delete
 * leaves behind.
 *
 * WHY A REAL DATABASE. Editor scope is the actor id bound into the DELETE plus
 * the "may write this template" predicate — which rows MariaDB matches is the
 * answer, not the fixture's. The 204/403 split, the row-count change, the
 * untouched template flow columns and the audit row are all the engine's here.
 *
 * A deleted run leaves user_templates.flow_last_run_id dangling on purpose (it
 * is a marker, not a foreign key), asserted below.
 *
 * Skips with a stated reason when no database is reachable, and fails instead of
 * skipping when REQUIRE_INTEGRATION_DB=1.
 */
const { test, describe, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const net = require('node:net');
const http = require('node:http');
const express = require('express');
const mariadb = require('mariadb');
const { makeStubReqLog } = require('../helpers/stub-req-log');

const TEST_PREFIX = 'frd_';
const tbl = (name) => `${TEST_PREFIX}${name}`;

let pool = null;
const lease = () => pool.getConnection();
const dbKey = require.resolve('../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: {
    pool: { ro: { getConnection: lease }, rw: { getConnection: lease } },
    t: tbl,
    getDynamicPool: async () => ({ ro: { getConnection: lease }, rw: { getConnection: lease } }),
  },
};

const { buildEngineTableDDLs, buildInfraTableDDLs } = require('../../src/table-ddls');
const { TABLES } = require('../../src/shared/constants');
const { _resetGrantsTableCache } = require('../../src/edge/lib/delegated-grants');
const runsRouter = require('../../src/edge/routes/app/flow-recipe-runs');

function parseEnvFile(filePath) {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    const out = {};
    for (const line of content.split('\n')) {
      const m = line.match(/^\s*([A-Z_][A-Z0-9_]*)\s*=\s*(.*)\s*$/);
      if (!m) continue;
      let value = m[2];
      if ((value.startsWith('"') && value.endsWith('"'))
        || (value.startsWith("'") && value.endsWith("'"))) value = value.slice(1, -1);
      out[m[1]] = value;
    }
    return out;
  } catch { return null; }
}

function probePort(host, port, timeoutMs = 2000) {
  return new Promise((resolve) => {
    const socket = new net.Socket();
    let done = false;
    const finish = (ok) => { if (done) return; done = true; socket.destroy(); resolve(ok); };
    socket.setTimeout(timeoutMs);
    socket.once('connect', () => finish(true));
    socket.once('timeout', () => finish(false));
    socket.once('error', () => finish(false));
    socket.connect(port, host);
  });
}

async function resolveMariaDbConfig() {
  if (process.env.DB_TEST_HOST && process.env.DB_TEST_ROOT_PASSWORD) {
    return {
      host: process.env.DB_TEST_HOST,
      port: parseInt(process.env.DB_TEST_PORT || '3306', 10),
      user: 'root', password: process.env.DB_TEST_ROOT_PASSWORD,
    };
  }
  const envPath = path.resolve(__dirname, '../../../.devcontainer/.env');
  const env = parseEnvFile(envPath);
  if (!env || !env.DB_ROOT_PASSWORD) return null;
  const port = parseInt(env.DB_PORT || '3306', 10);
  for (const host of ['127.0.0.1', 'mariadb', 'localhost']) {
    if (await probePort(host, port, 2000)) {
      return { host, port, user: 'root', password: env.DB_ROOT_PASSWORD };
    }
  }
  return null;
}

const OWNER = { id: 'u-owner', role: 'user' };
const EDITOR = { id: 'u-editor', role: 'editor' };
const ADMIN = { id: 'u-admin', role: 'admin' };
const PLAIN = { id: 'u-plain', role: 'user' };
const BP1 = 'bp-1';
const T1 = 'tpl-1'; // writable by EDITOR via grant
const T2 = 'tpl-2'; // EDITOR cannot write
const R1 = 'aaaa1111-0000-0000-0000-000000000001';
const R2 = 'aaaa1111-0000-0000-0000-000000000002';
const R3 = 'aaaa1111-0000-0000-0000-000000000003';
const RECIPE = '33333333-3333-3333-3333-333333333333';
let dbReady = false;
let skipReason = null;
let testDbName = null;
let server = null;
let baseUrl = null;
let currentUser = OWNER;

function ddlFor(...tables) {
  const wanted = new Set(tables.map((n) => tbl(n)));
  return [...buildInfraTableDDLs(tbl), ...buildEngineTableDDLs(tbl)].filter((sql) => {
    const m = sql.match(/CREATE TABLE IF NOT EXISTS `([^`]+)`/);
    return m && wanted.has(m[1]);
  });
}

async function seedRuns() {
  const runs = tbl('flow_recipe_runs');
  for (const [id, actor, tmpl] of [[R1, EDITOR.id, T1], [R2, OWNER.id, T1], [R3, EDITOR.id, T2]]) {
    await pool.query(
      `INSERT INTO \`${runs}\` (id, recipe_id, template_id, actor_id, mode, status) VALUES (?, ?, ?, ?, 'create', 'success')`,
      [id, RECIPE, tmpl, actor],
    );
  }
  // A prior push cache on T1 whose flow_last_run_id names R2 — a delete must not
  // touch it (the marker stays dangling by design).
  await pool.query(
    `UPDATE \`${tbl('user_templates')}\`
        SET flow_external_id = 'EXT-1', flow_link = 'https://x/1', flow_last_run_id = ?
      WHERE id = ?`, [R2, T1],
  );
}

before(async () => {
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) {
    skipReason = 'no MariaDB reachable via .devcontainer/.env or env vars';
    if (process.env.REQUIRE_INTEGRATION_DB === '1') throw new Error(`REQUIRE_INTEGRATION_DB=1 set but ${skipReason}.`);
    return;
  }
  testDbName = `flow_run_delete_test_${process.pid}_${Date.now()}`;
  let admin = null;
  try {
    admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`CREATE DATABASE \`${testDbName}\``);
    await admin.query(`USE \`${testDbName}\``);
    for (const sql of ddlFor(
      TABLES.HIERARCHY_NODES, TABLES.USER_TEMPLATES, TABLES.DELEGATED_GRANTS,
      TABLES.FLOW_RECIPE_RUNS, TABLES.FLOW_RECIPES, TABLES.FEATURE_AUDIT,
    )) await admin.query(sql);
    await admin.query(
      `INSERT INTO \`${tbl('hierarchy_nodes')}\` (id, name, node_type, owner_id) VALUES (?, 'BP1', 'blueprint', ?)`,
      [BP1, OWNER.id],
    );
    await admin.query(
      `INSERT INTO \`${tbl('user_templates')}\` (id, name, blueprint_id, owner_id) VALUES (?, 'one', ?, ?), (?, 'two', ?, ?)`,
      [T1, BP1, OWNER.id, T2, BP1, OWNER.id],
    );
    // The grant that makes T1 writable by EDITOR; T2 has none.
    await admin.query(
      `INSERT INTO \`${tbl('delegated_grants')}\` (id, scope_type, scope_id, grantee_id, granted_by)
       VALUES ('g-1', 'template', ?, ?, ?)`,
      [T1, EDITOR.id, OWNER.id],
    );
    await admin.end();
    admin = null;

    pool = mariadb.createPool({ ...dbConfig, database: testDbName, connectionLimit: 4, connectTimeout: 5000 });
    _resetGrantsTableCache();

    const app = express();
    app.use((req, _res, next) => { req.log = makeStubReqLog(); next(); });
    app.use(express.json());
    app.use((req, _res, next) => { req.user = currentUser; next(); });
    app.use('/edge/app/flow-recipe-runs', runsRouter);
    server = http.createServer(app);
    await new Promise((r) => server.listen(0, r));
    baseUrl = `http://127.0.0.1:${server.address().port}`;
    dbReady = true;
  } catch (err) {
    skipReason = `setup failed: ${err.message}`;
    if (admin) { try { await admin.end(); } catch { /* best effort */ } }
    if (process.env.REQUIRE_INTEGRATION_DB === '1') throw err;
  }
});

after(async () => {
  if (server) { try { server.close(); } catch { /* best effort */ } }
  if (pool) { try { await pool.end(); } catch { /* best effort */ } }
  if (!testDbName) return;
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) return;
  try {
    const admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`DROP DATABASE IF EXISTS \`${testDbName}\``);
    await admin.end();
  } catch { /* best effort */ }
});

async function del(user, runId) {
  currentUser = user;
  const res = await fetch(`${baseUrl}/edge/app/flow-recipe-runs/${runId}`, { method: 'DELETE' });
  let json = null; try { json = await res.json(); } catch { json = null; }
  return { status: res.status, body: json };
}

async function runExists(id) {
  const rows = await pool.query(`SELECT 1 AS n FROM \`${tbl('flow_recipe_runs')}\` WHERE id = ?`, [id]);
  return rows.length > 0;
}
async function runCount() {
  const rows = await pool.query(`SELECT COUNT(*) AS n FROM \`${tbl('flow_recipe_runs')}\``);
  return Number(rows[0].n);
}
async function templateFlow(id) {
  const rows = await pool.query(
    `SELECT flow_external_id, flow_link, flow_last_run_id FROM \`${tbl('user_templates')}\` WHERE id = ?`, [id],
  );
  return rows[0];
}
async function auditCount(eventType) {
  const rows = await pool.query(
    `SELECT COUNT(*) AS n FROM \`${tbl('feature_audit')}\` WHERE event_type = ?`, [eventType],
  );
  return Number(rows[0].n);
}

const guard = (t) => { if (!dbReady) { t.skip(skipReason || 'database not ready'); return true; } return false; };

beforeEach(async () => {
  if (!dbReady) return;
  await pool.query(`DELETE FROM \`${tbl('flow_recipe_runs')}\``);
  await pool.query(`DELETE FROM \`${tbl('feature_audit')}\``);
  await seedRuns();
});

describe('delete a run: admin, or its actor with template write', () => {
  test('an editor deletes their own run on a writable template: 204, row gone, template cache untouched, audit', async (t) => {
    if (guard(t)) return;
    const res = await del(EDITOR, R1);
    assert.equal(res.status, 204, JSON.stringify(res.body));
    assert.equal(await runExists(R1), false, 'the run row was not deleted');
    const flow = await templateFlow(T1);
    assert.equal(flow.flow_external_id, 'EXT-1', 'a run delete must not touch the template cache');
    assert.equal(flow.flow_last_run_id, R2, 'the marker to another run must stay');
    assert.equal(await auditCount('flow.run.delete'), 1);
  });

  test('an editor cannot delete another actor\'s run: 403, row count unchanged', async (t) => {
    if (guard(t)) return;
    const before = await runCount();
    const res = await del(EDITOR, R2);
    assert.equal(res.status, 403, JSON.stringify(res.body));
    assert.equal(res.body.error.code, 'RUN_FORBIDDEN');
    assert.equal(await runCount(), before);
    assert.equal(await runExists(R2), true);
  });

  test('an editor cannot delete their run on a template they cannot write: 403', async (t) => {
    if (guard(t)) return;
    const res = await del(EDITOR, R3);
    assert.equal(res.status, 403, JSON.stringify(res.body));
    assert.equal(res.body.error.code, 'RUN_FORBIDDEN');
    assert.equal(await runExists(R3), true);
  });

  test('a grant revoked between the run lookup and the DELETE still denies atomically: 403, row count unchanged', async (t) => {
    if (guard(t)) return;
    // Simulates the TOCTOU window a separate access-check SELECT would leave
    // open: revoke the grant right after the handler's own pre-read resolves,
    // before the DELETE that follows it runs. The atomic predicate (bound INTO
    // the DELETE's JOIN, evaluated by MariaDB at the moment the statement
    // executes) must see the revoked grant and refuse — a stale answer taken
    // earlier and trusted at write time would not.
    const dbExports = require.cache[dbKey].exports;
    const originalGetConnection = dbExports.pool.rw.getConnection;
    dbExports.pool.rw.getConnection = async () => {
      const conn = await pool.getConnection();
      const originalQuery = conn.query.bind(conn);
      let triggered = false;
      conn.query = async (sql, params) => {
        const result = await originalQuery(sql, params);
        if (!triggered && /SELECT actor_id, template_id FROM/.test(sql)) {
          triggered = true;
          await pool.query(`DELETE FROM \`${tbl('delegated_grants')}\` WHERE id = 'g-1'`);
        }
        return result;
      };
      return conn;
    };
    try {
      const before = await runCount();
      const res = await del(EDITOR, R1);
      assert.equal(res.status, 403, JSON.stringify(res.body));
      assert.equal(res.body.error.code, 'RUN_FORBIDDEN');
      assert.equal(await runCount(), before, 'a mid-request revoke must not let the delete through');
      assert.equal(await runExists(R1), true);
    } finally {
      dbExports.pool.rw.getConnection = originalGetConnection;
      await pool.query(
        `INSERT INTO \`${tbl('delegated_grants')}\` (id, scope_type, scope_id, grantee_id, granted_by)
         VALUES ('g-1', 'template', ?, ?, ?)`,
        [T1, EDITOR.id, OWNER.id],
      );
    }
  });

  test('an admin deletes any run: 204, row gone', async (t) => {
    if (guard(t)) return;
    const res = await del(ADMIN, R2);
    assert.equal(res.status, 204, JSON.stringify(res.body));
    assert.equal(await runExists(R2), false);
  });

  test('a plain user is refused by the role gate: 403', async (t) => {
    if (guard(t)) return;
    const res = await del(PLAIN, R1);
    assert.equal(res.status, 403, JSON.stringify(res.body));
    assert.equal(await runExists(R1), true);
  });

  test('deleting a run that does not exist: 404', async (t) => {
    if (guard(t)) return;
    const res = await del(ADMIN, 'aaaa1111-0000-0000-0000-0000000000ff');
    assert.equal(res.status, 404, JSON.stringify(res.body));
  });
});
