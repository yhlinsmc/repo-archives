'use strict';

/**
 * flow-run-remote-refs-snapshot-real-db.test.js — what a run keeps of the refs
 * it captured, on the run row itself and not only as the template's latest cache.
 *
 * WHY A REAL DATABASE. The thing under test is what the finalize UPDATE writes
 * into a JSON column and, for the oversized case, what it deliberately does NOT
 * write — a stubbed driver answers with whatever the fixture said, so the row
 * and its NULL are MariaDB's answer here, produced by running the shipped route
 * against the shipped DDL.
 *
 * Skips with a stated reason when no database is reachable, and fails instead of
 * skipping when REQUIRE_INTEGRATION_DB=1.
 */
const { test, describe, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const net = require('node:net');
const http = require('node:http');
const express = require('express');
const mariadb = require('mariadb');

const TEST_PREFIX = 'frs_';
const tbl = (name) => `${TEST_PREFIX}${name}`;

let pool = null;
const lease = () => pool.getConnection();
const dbKey = require.resolve('../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey,
  filename: dbKey,
  loaded: true,
  exports: {
    pool: { ro: { getConnection: lease }, rw: { getConnection: lease } },
    t: tbl,
    getDynamicPool: async () => ({ ro: { getConnection: lease }, rw: { getConnection: lease } }),
  },
};

const { buildEngineTableDDLs } = require('../../src/table-ddls');
const { TABLES } = require('../../src/shared/constants');
const { _resetGrantsTableCache } = require('../../src/edge/lib/delegated-grants');
const router = require('../../src/edge/routes/internal/flow-recipes-run');

function parseEnvFile(filePath) {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    const out = {};
    for (const line of content.split('\n')) {
      const m = line.match(/^\s*([A-Z_][A-Z0-9_]*)\s*=\s*(.*)\s*$/);
      if (!m) continue;
      let value = m[2];
      if ((value.startsWith('"') && value.endsWith('"'))
        || (value.startsWith("'") && value.endsWith("'"))) value = value.slice(1, -1);
      out[m[1]] = value;
    }
    return out;
  } catch { return null; }
}

function probePort(host, port, timeoutMs = 2000) {
  return new Promise((resolve) => {
    const socket = new net.Socket();
    let done = false;
    const finish = (ok) => { if (done) return; done = true; socket.destroy(); resolve(ok); };
    socket.setTimeout(timeoutMs);
    socket.once('connect', () => finish(true));
    socket.once('timeout', () => finish(false));
    socket.once('error', () => finish(false));
    socket.connect(port, host);
  });
}

async function resolveMariaDbConfig() {
  if (process.env.DB_TEST_HOST && process.env.DB_TEST_ROOT_PASSWORD) {
    return {
      host: process.env.DB_TEST_HOST,
      port: parseInt(process.env.DB_TEST_PORT || '3306', 10),
      user: 'root', password: process.env.DB_TEST_ROOT_PASSWORD,
    };
  }
  const envPath = path.resolve(__dirname, '../../../.devcontainer/.env');
  const env = parseEnvFile(envPath);
  if (!env || !env.DB_ROOT_PASSWORD) return null;
  const port = parseInt(env.DB_PORT || '3306', 10);
  for (const host of ['127.0.0.1', 'mariadb', 'localhost']) {
    if (await probePort(host, port, 2000)) {
      return { host, port, user: 'root', password: env.DB_ROOT_PASSWORD };
    }
  }
  return null;
}

const OWNER = 'u-owner';
const BP1 = 'bp-1';
const T1 = 'tpl-1';
const RECIPE = 'r-1';
let dbReady = false;
let skipReason = null;
let testDbName = null;
let server = null;
let baseUrl = null;
let currentUser = { id: OWNER, role: 'user' };

function ddlFor(...tables) {
  const wanted = new Set(tables.map((n) => tbl(n)));
  return buildEngineTableDDLs(tbl).filter((sql) => {
    const m = sql.match(/CREATE TABLE IF NOT EXISTS `([^`]+)`/);
    return m && wanted.has(m[1]);
  });
}

before(async () => {
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) {
    skipReason = 'no MariaDB reachable via .devcontainer/.env or env vars';
    if (process.env.REQUIRE_INTEGRATION_DB === '1') throw new Error(`REQUIRE_INTEGRATION_DB=1 set but ${skipReason}.`);
    return;
  }
  testDbName = `flow_refs_snap_test_${process.pid}_${Date.now()}`;
  let admin = null;
  try {
    admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`CREATE DATABASE \`${testDbName}\``);
    await admin.query(`USE \`${testDbName}\``);
    const statements = ddlFor(
      TABLES.HIERARCHY_NODES, TABLES.USER_TEMPLATES, TABLES.DELEGATED_GRANTS,
      TABLES.FLOW_RECIPES, TABLES.FLOW_RECIPE_STEPS, TABLES.FLOW_RECIPE_RUNS,
      TABLES.TEMPLATE_ACTIVITY, TABLES.FEATURE_AUDIT,
    );
    for (const sql of statements) await admin.query(sql);
    await admin.query(
      `INSERT INTO \`${tbl('hierarchy_nodes')}\` (id, name, node_type, owner_id) VALUES (?, 'BP1', 'blueprint', ?)`,
      [BP1, OWNER],
    );
    await admin.query(
      `INSERT INTO \`${tbl('user_templates')}\` (id, name, blueprint_id, owner_id) VALUES (?, 'one', ?, ?)`,
      [T1, BP1, OWNER],
    );
    await admin.query(
      `INSERT INTO \`${tbl('flow_recipes')}\`
         (id, name, is_active, blueprint_id, link_extract, external_id_extract, runs_on, status)
       VALUES (?, 'recipe', 1, ?, ?, ?, 'both', 'approved')`,
      [RECIPE, BP1, JSON.stringify({ path: 'url' }), JSON.stringify({ path: 'id' })],
    );
    await admin.query(
      `INSERT INTO \`${tbl('flow_recipe_steps')}\` (id, recipe_id, \`sequence\`, name, method, url)
       VALUES ('s-1', ?, 1, 'step one', 'POST', 'https://upstream.invalid/create')`,
      [RECIPE],
    );
    await admin.end();
    admin = null;

    pool = mariadb.createPool({ ...dbConfig, database: testDbName, connectionLimit: 4, connectTimeout: 5000 });
    _resetGrantsTableCache();

    const app = express();
    app.use(express.json({ limit: '2mb' }));
    app.use((req, _res, next) => { req.user = currentUser; next(); });
    app.use('/edge/internal/flow-recipes', router);
    server = http.createServer(app);
    await new Promise((r) => server.listen(0, r));
    baseUrl = `http://127.0.0.1:${server.address().port}`;
    dbReady = true;
  } catch (err) {
    skipReason = `setup failed: ${err.message}`;
    if (admin) { try { await admin.end(); } catch { /* best effort */ } }
    if (process.env.REQUIRE_INTEGRATION_DB === '1') throw err;
  }
});

after(async () => {
  if (server) { try { server.close(); } catch { /* best effort */ } }
  if (pool) { try { await pool.end(); } catch { /* best effort */ } }
  if (!testDbName) return;
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) return;
  try {
    const admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`DROP DATABASE IF EXISTS \`${testDbName}\``);
    await admin.end();
  } catch { /* best effort */ }
});

async function post(pathname, body, user) {
  currentUser = user;
  const res = await fetch(`${baseUrl}/edge/internal/flow-recipes/${pathname}`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
  });
  return { status: res.status, body: await res.json() };
}

const begin = (user, over = {}) => post('run-begin', {
  recipe_id: RECIPE, payload: { a: 1 }, template_id: T1, ...over,
}, user);

const finalize = (user, runId, over = {}) => post('run-finalize', {
  run_id: runId,
  recipe_id: RECIPE,
  ok: true,
  upstream_status: 200,
  body: JSON.stringify({ url: 'https://upstream.invalid/RUN', id: 'EXT-1' }),
  ...over,
}, user);

async function runRefs(runId) {
  const rows = await pool.query(
    `SELECT remote_refs FROM \`${tbl('flow_recipe_runs')}\` WHERE id = ?`, [runId],
  );
  const v = rows[0].remote_refs;
  return typeof v === 'string' ? JSON.parse(v) : v;
}

async function templateRefs() {
  const rows = await pool.query(
    `SELECT flow_remote_refs FROM \`${tbl('user_templates')}\` WHERE id = ?`, [T1],
  );
  const v = rows[0].flow_remote_refs;
  return v == null ? null : (typeof v === 'string' ? JSON.parse(v) : v);
}

const guard = (t) => { if (!dbReady) { t.skip(skipReason || 'database not ready'); return true; } return false; };

beforeEach(async () => {
  if (!dbReady) return;
  await pool.query(`DELETE FROM \`${tbl('flow_recipe_runs')}\``);
  await pool.query(
    `UPDATE \`${tbl('user_templates')}\`
        SET flow_external_id = NULL, flow_link = NULL, flow_last_run_id = NULL, flow_remote_refs = NULL
      WHERE id = ?`, [T1],
  );
});

describe('a run snapshots the refs it captured', () => {
  test('finalize writes remote_refs on the run row and the template cache alike', async (t) => {
    if (guard(t)) return;
    const refs = { tasks: [{ id: 't1' }] };
    const began = await begin({ id: OWNER, role: 'user' });
    assert.equal(began.status, 200, `run-begin: ${JSON.stringify(began.body)}`);
    const runId = began.body.data.run_id;
    const ended = await finalize({ id: OWNER, role: 'user' }, runId, { remote_refs: refs });
    assert.equal(ended.status, 200, `run-finalize: ${JSON.stringify(ended.body)}`);
    assert.equal(ended.body.data.remote_refs_notice, null);

    assert.deepEqual(await runRefs(runId), refs, 'the run row did not snapshot the refs it captured');
    assert.deepEqual(await templateRefs(), refs, 'the template cache disagrees with the run snapshot');
  });

  test('a secret-named leaf in remote_refs is masked on BOTH the run row and the template cache; a captured id is not', async (t) => {
    if (guard(t)) return;
    const refs = { tasks: [{ id: 't1', access_token: 'sk-abc' }] };
    const began = await begin({ id: OWNER, role: 'user' });
    assert.equal(began.status, 200, `run-begin: ${JSON.stringify(began.body)}`);
    const runId = began.body.data.run_id;
    const ended = await finalize({ id: OWNER, role: 'user' }, runId, { remote_refs: refs });
    assert.equal(ended.status, 200, `run-finalize: ${JSON.stringify(ended.body)}`);
    assert.equal(ended.body.data.remote_refs_notice, null);

    const storedRun = await runRefs(runId);
    const storedTemplate = await templateRefs();
    assert.equal(storedRun.tasks[0].access_token, '****', 'access_token must be masked on the run row');
    assert.equal(storedRun.tasks[0].id, 't1', 'a captured id is not a secret and must survive intact');
    assert.equal(storedTemplate.tasks[0].access_token, '****', 'access_token must be masked on the template cache');
    assert.equal(storedTemplate.tasks[0].id, 't1');
  });

  test('an oversized refs object drops to NULL on the run and leaves the template cache as it was', async (t) => {
    if (guard(t)) return;
    // Seed a prior good cache the drop must not erase.
    const prior = { tasks: [{ id: 'prior' }] };
    await pool.query(
      `UPDATE \`${tbl('user_templates')}\` SET flow_remote_refs = ? WHERE id = ?`,
      [JSON.stringify(prior), T1],
    );
    const huge = { tasks: [{ id: 'x'.repeat(70 * 1024) }] };
    const began = await begin({ id: OWNER, role: 'user' });
    assert.equal(began.status, 200);
    const runId = began.body.data.run_id;
    const ended = await finalize({ id: OWNER, role: 'user' }, runId, { remote_refs: huge });
    assert.equal(ended.status, 200, `run-finalize: ${JSON.stringify(ended.body)}`);
    assert.equal(ended.body.data.remote_refs_notice, 'remote_refs_dropped');

    assert.equal(await runRefs(runId), null, 'an over-cap refs object must write NULL to the run, not the object');
    assert.deepEqual(await templateRefs(), prior, 'a dropped refs write erased the prior good template cache');
  });
});
