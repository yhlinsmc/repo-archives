/**
 * public-read.js — Public Integration API scoped read projections (edge-only,
 * S2S). Namespace mount: /edge/internal/public-read (infra forwards here on the
 * machine-principal S2S contract; never publicly routed).
 *
 * SECURITY [C1][H1]: every read is fail-closed. The granted roots arrive as the
 * reconstructed machine principal (`req.user.scope.roots`, rebuilt by s2s-verify
 * from the trusted forwarded headers — client-supplied scope is never trusted).
 * `computeInScopeNodeIds` derives the exact visible node set; anything outside it
 * is invisible:
 *   - list endpoints return only in-scope rows (empty grant → empty list)
 *   - a detail/path lookup outside scope → 404 not_found (NOT 403 — anti-enumeration)
 *   - a run with NULL blueprint_id is hidden (fail-closed)
 * Owner columns are never client-FILTERABLE (client-supplied owner_id / user_id /
 * actor_id is always dropped; ?owner_id= is not honoured). The template
 * projections name the owner by USERNAME only (via the shared
 * never-return-email enrichment); the raw owner_id is read from the DB to
 * resolve that username and then dropped by the serializer, no other projection
 * returns any owner column, and an owner's EMAIL is never returned anywhere.
 * These bespoke projections DO NOT reuse the generic CRUD list path.
 */
const router = require('express').Router();
const { pool, t } = require('../../db');
const { TABLES } = require('../../../shared/constants');
const { isNonEmptyScope } = require('../../../shared/lib/machine-scope');
const { sendPublicError } = require('../../../shared/lib/public-errors');
const {
  computeInScopeNodeIds,
  encodeCursor,
  decodeCursor,
  clampLimit,
  paginateInMemory,
  chunkIds,
  mergeKeysetPages,
  tsMs,
  utcSqlDatetime,
} = require('../../lib/public-scope');
const { resolveBlueprintByNamePath } = require('../../lib/name-path-resolve');
const { normalizeTimestamp, mapRowsFromDb } = require('../../lib/dto-mapper');
const {
  buildPublicTemplatePath,
  serializePublicTemplate,
  serializePublicTemplateDetail,
} = require('../../../shared/serializers/public-template');
const { attachOwnerNames } = require('../../lib/owner-name-enrichment');
const { logger: rootLogger } = require('../../../shared/lib/logger');

const logger = rootLogger.child({ module: 'public-read' });

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
// Cap the encoded name-path param (base64url JSON array) before decoding so it
// can never feed an oversized array into the resolver.
const MAX_P_LEN = 4096;
// COALESCE sentinel so a NULL created_at orders identically in SQL and in the
// in-memory blueprint path (tsMs(null) === 0 === epoch 1970-01-01). Without this
// a NULL-created_at row diverges between the two pagination paths [M2].
const NULL_TS_SENTINEL = '1970-01-01 00:00:00';

// ── Node cache [M4] ──────────────────────────────────────────────────────────
// Hierarchy nodes are admin-mutated design-time metadata read on every public
// request across six endpoints. A short-TTL in-process cache removes that
// per-request full SELECT; invalidation-free is acceptable because a
// newly-created blueprint becoming visible up to NODE_CACHE_TTL_MS late is fine
// for an integration read (and every write path still flows through the UI/edge).
// SECURITY: the staleness cuts BOTH ways — an admin re-parenting a node out of a
// granted subtree (or deleting it) stays readable to that service account for up
// to NODE_CACHE_TTL_MS after the change (the pre-cache code read the DB fresh, so
// a scope revocation took effect immediately). 10s is the deliberate ceiling on
// that revocation lag; scope changes are eventually-consistent within it, matching
// the token-revocation TTL posture (spec §4.8). Do not raise it without re-review.
const NODE_CACHE_TTL_MS = 10_000;
let _nodeCache = null;
let _nodeCacheAt = 0;

async function loadAllNodes() {
  const now = Date.now();
  if (_nodeCache && now - _nodeCacheAt < NODE_CACHE_TTL_MS) return _nodeCache;
  const conn = await pool.ro.getConnection();
  try {
    const rows = await conn.query(
      `SELECT id, parent_id, name, node_type, created_at
       FROM \`${t(TABLES.HIERARCHY_NODES)}\``,
    );
    _nodeCache = rows;
    _nodeCacheAt = now;
    return rows;
  } finally {
    conn.release();
  }
}

// ── Scope context (single fail-closed source for every handler) [L6] ─────────

/**
 * Resolve the request's machine scope + node graph once. Responds 401 and
 * returns null when the caller is not a valid machine principal with a non-empty
 * grant (defense-in-depth past the already-gated infra hop). On success returns
 * `{ roots, nodes, byId, inScope }`.
 * @returns {Promise<{ roots: string[], nodes: object[], byId: Map<string,object>, inScope: Set<string> }|null>}
 */
async function loadScopeContext(req, res) {
  const user = req.user;
  if (!user || user.type !== 'service_account' || !isNonEmptyScope(user.scope)) {
    sendPublicError(res, 401, 'invalid_token');
    return null;
  }
  const roots = Array.isArray(user.scope.roots) ? user.scope.roots : [];
  const nodes = await loadAllNodes();
  const byId = new Map(nodes.map((n) => [n.id, n]));
  const inScope = computeInScopeNodeIds(nodes, roots);
  return { roots, nodes, byId, inScope };
}

// Wrap loadScopeContext so a pool/DB failure surfaces as edge_unreachable (not an
// unhandled rejection — Express 4 does not route async throws). Returns null when
// the response has already been sent (401 or 503).
async function scopeContextOr503(req, res, label) {
  try {
    return await loadScopeContext(req, res);
  } catch (err) {
    unavailable(res, err, label);
    return null;
  }
}

// ── Serializers (public projections — no owner cols, no internal meta) ───────

// CORRECTNESS: driver timestamps are naive UTC strings (dateStrings:true, UTC
// session) — normalizeTimestamp appends the `Z` so `new Date` parses them as UTC,
// not the deployed process TZ (Asia/Taipei). Without it every emitted timestamp
// is −8h wrong. Same convention every mapRowsFromDb route uses.
function iso(value) {
  if (value == null) return null;
  const d = value instanceof Date ? value : new Date(normalizeTimestamp(value));
  return Number.isNaN(d.getTime()) ? null : d.toISOString();
}

/**
 * The in-scope name-path for a blueprint: the ancestor chain truncated at the
 * scope boundary so an out-of-scope ancestor name is never disclosed, while the
 * customer still gets enough of the path to disambiguate a name-path lookup.
 * Uses the shared `byId` map (built once per request) — no per-call Map build.
 */
function inScopePath(byId, inScope, blueprintId) {
  const idChain = [];
  const seen = new Set();
  let cur = byId.get(blueprintId);
  while (cur && !seen.has(cur.id)) {
    seen.add(cur.id);
    idChain.push(cur.id);
    cur = cur.parent_id != null ? byId.get(cur.parent_id) : undefined;
  }
  idChain.reverse(); // root → self
  const firstInScope = idChain.findIndex((id) => inScope.has(id));
  const visible = firstInScope === -1 ? [] : idChain.slice(firstInScope);
  return visible.map((id) => byId.get(id)?.name).filter((n) => typeof n === 'string');
}

function serializeBlueprintSummary(node, byId, inScope) {
  return {
    id: node.id,
    name: node.name,
    node_type: node.node_type,
    path: inScopePath(byId, inScope, node.id),
    created_at: iso(node.created_at),
  };
}

// ── Cursor + limit parsing (malformed cursor → validation_failed) ────────────

/**
 * @returns {{ ok: true, cursor: object|null, limit: number } | { ok: false }}
 */
function parsePageParams(req, res) {
  const limit = clampLimit(req.query.limit);
  const rawCursor = req.query.cursor;
  if (rawCursor === undefined || rawCursor === '') return { ok: true, cursor: null, limit };
  const cursor = decodeCursor(rawCursor);
  if (!cursor) {
    sendPublicError(res, 400, 'validation_failed');
    return { ok: false };
  }
  return { ok: true, cursor, limit };
}

// Keyset WHERE fragment for an ascending (created_at, id) continuation, with the
// NULL-created_at sentinel [M2]. Empty fragment for page 1.
function keysetFragment(cursor) {
  if (!cursor) return { clause: '', params: [] };
  // CORRECTNESS: bind a canonical zero-padded UTC datetime STRING (not a JS
  // Date). A bound Date is serialised by the mariadb text protocol via the
  // process-local TZ and WITHOUT zero-padding, which both skews and lexically
  // mis-orders the comparison against the string-typed COALESCE — dropping
  // every row past page 1. See utcSqlDatetime() for the full rationale.
  const boundary = utcSqlDatetime(cursor.c);
  return {
    clause:
      ` AND (COALESCE(created_at, '${NULL_TS_SENTINEL}') > ?`
      + ` OR (COALESCE(created_at, '${NULL_TS_SENTINEL}') = ? AND id > ?))`,
    params: [boundary, boundary, cursor.i],
  };
}

const ORDER_BY = `ORDER BY COALESCE(created_at, '${NULL_TS_SENTINEL}') ASC, id ASC`;

function unavailable(res, err, msg) {
  logger.error({ err }, msg);
  return sendPublicError(res, 503, 'edge_unreachable');
}

// ── GET /blueprints ──────────────────────────────────────────────────────────
router.get('/blueprints', async (req, res) => {
  const ctx = await scopeContextOr503(req, res, 'public /blueprints scope load failed');
  if (!ctx) return;
  const pageParams = parsePageParams(req, res);
  if (!pageParams.ok) return;

  const blueprints = ctx.nodes
    .filter((n) => n.node_type === 'blueprint' && ctx.inScope.has(n.id))
    .sort((a, b) => tsMs(a.created_at) - tsMs(b.created_at)
      || (String(a.id) < String(b.id) ? -1 : String(a.id) > String(b.id) ? 1 : 0));
  const { page, nextCursor } = paginateInMemory(blueprints, pageParams.cursor, pageParams.limit);
  res.json({
    data: page.map((n) => serializeBlueprintSummary(n, ctx.byId, ctx.inScope)),
    meta: { next_cursor: nextCursor },
  });
});

// ── GET /blueprint-by-path?p=<base64url(JSON string[])> ───────────────────────
// Infra captures the /blueprints/{name-path} tail, splits it, and forwards the
// segments as a base64url-encoded JSON array so a name containing '/' survives.
router.get('/blueprint-by-path', async (req, res) => {
  const rawP = String(req.query.p || '');
  // [L2] length cap before decode so an oversized array never reaches the resolver.
  if (rawP.length === 0 || rawP.length > MAX_P_LEN) return sendPublicError(res, 400, 'validation_failed');

  let segments;
  try {
    const decoded = JSON.parse(Buffer.from(rawP, 'base64url').toString('utf8'));
    segments = Array.isArray(decoded) ? decoded.filter((s) => typeof s === 'string' && s.trim().length > 0) : [];
  } catch {
    return sendPublicError(res, 400, 'validation_failed');
  }
  if (segments.length === 0) return sendPublicError(res, 400, 'validation_failed');

  const ctx = await scopeContextOr503(req, res, 'public /blueprint-by-path scope load failed');
  if (!ctx) return;

  try {
    // Resolution restricted to in-scope blueprints, matching against the
    // scope-truncated path [P1-b]: an out-of-scope duplicate (or a hidden ancestor
    // name) is invisible, so 0 in-scope matches → path_not_found (indistinguishable
    // from truly-nonexistent) and out-of-scope collapses into the same 404.
    const resolved = resolveBlueprintByNamePath(ctx.nodes, segments, ctx.inScope);
    if (resolved.status === 'not_found') return sendPublicError(res, 404, 'path_not_found');
    if (resolved.status === 'ambiguous') return sendPublicError(res, 409, 'path_ambiguous');

    const node = ctx.byId.get(resolved.id);
    const detail = await loadBlueprintShape(node, ctx.byId, ctx.inScope);
    res.json({ data: detail });
  } catch (err) {
    return unavailable(res, err, 'public /blueprint-by-path read failed');
  }
});

/**
 * Load a blueprint's public field/section shape. Never exposes owner_id,
 * transformer_id, or any transformer/flow code body.
 */
async function loadBlueprintShape(node, byId, inScope) {
  const conn = await pool.ro.getConnection();
  let fields;
  let sections;
  let options;
  try {
    fields = await conn.query(
      `SELECT id, field_key, field_label, field_type, is_required, section, order_index
       FROM \`${t(TABLES.BLUEPRINT_FIELDS)}\` WHERE blueprint_id = ?
       ORDER BY order_index IS NULL, order_index, field_key`,
      [node.id],
    );
    // This route builds its own DTO shape rather than sharing the generic CRUD
    // response path, but it must still see the same coalesced field_label a
    // schema-builder GET would (dto-mapper.js's Y-pattern) — external
    // consumers of `label` deserve the same non-null contract our own FE does.
    fields = mapRowsFromDb(TABLES.BLUEPRINT_FIELDS, fields);
    sections = await conn.query(
      `SELECT section_key, display_label, sort_order
       FROM \`${t(TABLES.BLUEPRINT_SECTIONS)}\` WHERE blueprint_id = ?
       ORDER BY sort_order IS NULL, sort_order, section_key`,
      [node.id],
    );
    const fieldIds = fields.map((f) => f.id);
    if (fieldIds.length) {
      const placeholders = fieldIds.map(() => '?').join(',');
      options = await conn.query(
        `SELECT field_id, option_label, option_value, sort_order
         FROM \`${t(TABLES.FIELD_OPTIONS)}\` WHERE field_id IN (${placeholders})
         ORDER BY sort_order IS NULL, sort_order, option_label`,
        fieldIds,
      );
    } else {
      options = [];
    }
  } finally {
    conn.release();
  }

  const optionsByField = new Map();
  for (const o of options) {
    if (!optionsByField.has(o.field_id)) optionsByField.set(o.field_id, []);
    optionsByField.get(o.field_id).push({ label: o.option_label, value: o.option_value });
  }

  return {
    id: node.id,
    name: node.name,
    node_type: node.node_type,
    path: inScopePath(byId, inScope, node.id),
    created_at: iso(node.created_at),
    sections: sections.map((s) => ({ key: s.section_key, label: s.display_label })),
    fields: fields.map((f) => ({
      key: f.field_key,
      label: f.field_label,
      type: f.field_type,
      required: f.is_required === 1 || f.is_required === true,
      section: f.section || null,
      options: optionsByField.get(f.id) || [],
    })),
  };
}

// ── GET /templates ───────────────────────────────────────────────────────────
router.get('/templates', async (req, res) => {
  const ctx = await scopeContextOr503(req, res, 'public /templates scope load failed');
  if (!ctx) return;
  const pageParams = parsePageParams(req, res);
  if (!pageParams.ok) return;

  try {
    const scopeIds = [...ctx.inScope];
    if (scopeIds.length === 0) return res.json({ data: [], meta: { next_cursor: null } });

    const { clause: ks, params: ksParams } = keysetFragment(pageParams.cursor);
    const conn = await pool.ro.getConnection();
    let pages;
    try {
      // Chunk the scope ids so no single IN (...) exceeds the placeholder cap
      // [H2]; each chunk fetches its own keyset page and they are k-way merged.
      pages = [];
      for (const chunk of chunkIds(scopeIds)) {
        const ph = chunk.map(() => '?').join(',');
        // A template is visible when ANY of its four hierarchy FK columns resolves
        // to an in-scope node (§5.1). owner_id / user_id are never
        // client-filterable; owner_id is selected only to resolve the owner's
        // username and never reaches the response.
        const scopeClause =
          `(blueprint_id IN (${ph}) OR category_id IN (${ph}) OR release_id IN (${ph}) OR variant_id IN (${ph}))`;
        // The four hierarchy FK columns are selected (not just blueprint_id)
        // because the public projection returns the resolved name-path, which
        // needs every tier's node id to look up — and to truncate at the scope
        // boundary.
        const rows = await conn.query(
          `SELECT id, name, category_id, release_id, blueprint_id, variant_id,
                  is_draft, schema_version, created_at, updated_at, owner_id
           FROM \`${t(TABLES.USER_TEMPLATES)}\`
           WHERE ${scopeClause}${ks}
           ${ORDER_BY}
           LIMIT ?`,
          [...chunk, ...chunk, ...chunk, ...chunk, ...ksParams, pageParams.limit + 1],
        );
        pages.push(rows);
      }
    } finally {
      conn.release();
    }
    const { page, nextCursor } = mergeKeysetPages(pages, pageParams.limit);
    // SECURITY: resolve owner_id → owner_username via the shared bounded,
    // never-return-email enrichment (only ids present in `page` are queried;
    // any '@'-shaped value is reduced to its local part). Only user_templates
    // exposes owner; the enrichment never touches an email column.
    const ownerConn = await pool.ro.getConnection();
    try {
      await attachOwnerNames(ownerConn, page, 'owner_id', `\`${t(TABLES.USERS)}\``);
    } finally {
      ownerConn.release();
    }
    res.json({
      data: page.map((r) => serializePublicTemplate(
        r,
        buildPublicTemplatePath(ctx.byId, ctx.inScope, r),
      )),
      meta: { next_cursor: nextCursor },
    });
  } catch (err) {
    return unavailable(res, err, 'public /templates read failed');
  }
});

// ── GET /templates/{id} ──────────────────────────────────────────────────────
router.get('/templates/:id', async (req, res) => {
  const ctx = await scopeContextOr503(req, res, 'public /templates/:id scope load failed');
  if (!ctx) return;
  const id = req.params.id;
  // Malformed id → 404 (uniform with not-found / out-of-scope: never a distinct
  // existence signal).
  if (!UUID_RE.test(id)) return sendPublicError(res, 404, 'not_found');

  try {
    const conn = await pool.ro.getConnection();
    let row;
    try {
      const rows = await conn.query(
        `SELECT id, name, category_id, release_id, blueprint_id, variant_id,
                payload, generated_outputs, schema_version, is_draft, created_at, updated_at, owner_id
         FROM \`${t(TABLES.USER_TEMPLATES)}\` WHERE id = ?`,
        [id],
      );
      row = rows[0];
      // SECURITY: owner_id → owner_username via the shared never-return-email
      // enrichment (reuses this connection; single-id bounded query).
      if (row) await attachOwnerNames(conn, [row], 'owner_id', `\`${t(TABLES.USERS)}\``);
    } finally {
      conn.release();
    }
    if (!row) return sendPublicError(res, 404, 'not_found');

    const anchors = [row.blueprint_id, row.variant_id, row.release_id, row.category_id];
    const visible = anchors.some((a) => a && ctx.inScope.has(a));
    if (!visible) return sendPublicError(res, 404, 'not_found');

    res.json({
      data: serializePublicTemplateDetail(
        row,
        buildPublicTemplatePath(ctx.byId, ctx.inScope, row),
      ),
    });
  } catch (err) {
    return unavailable(res, err, 'public /templates/:id read failed');
  }
});

// ── Run projection (never exposes actor_id / rendered_payload / step_results) ─
function serializeRun(r, inScope) {
  return {
    id: r.id,
    status: r.status,
    mode: r.mode,
    result_link: r.result_link || null,
    external_flow_id: r.external_flow_id || null,
    blueprint_id: r.blueprint_id && inScope.has(r.blueprint_id) ? r.blueprint_id : null,
    started_at: iso(r.started_at),
    finished_at: iso(r.finished_at),
    created_at: iso(r.created_at),
  };
}

const RUN_COLUMNS =
  'id, status, mode, result_link, external_flow_id, blueprint_id, started_at, finished_at, created_at';

// ── GET /runs ────────────────────────────────────────────────────────────────
router.get('/runs', async (req, res) => {
  const ctx = await scopeContextOr503(req, res, 'public /runs scope load failed');
  if (!ctx) return;
  const pageParams = parsePageParams(req, res);
  if (!pageParams.ok) return;

  try {
    const scopeIds = [...ctx.inScope];
    if (scopeIds.length === 0) return res.json({ data: [], meta: { next_cursor: null } });

    const { clause: ks, params: ksParams } = keysetFragment(pageParams.cursor);
    const conn = await pool.ro.getConnection();
    let pages;
    try {
      pages = [];
      for (const chunk of chunkIds(scopeIds)) {
        const ph = chunk.map(() => '?').join(',');
        // Direct blueprint_id predicate (§5.1). NULL blueprint_id is excluded by
        // IN (...) → runs with no blueprint are fail-closed hidden.
        const rows = await conn.query(
          `SELECT ${RUN_COLUMNS} FROM \`${t(TABLES.FLOW_RECIPE_RUNS)}\`
           WHERE blueprint_id IN (${ph})${ks}
           ${ORDER_BY}
           LIMIT ?`,
          [...chunk, ...ksParams, pageParams.limit + 1],
        );
        pages.push(rows);
      }
    } finally {
      conn.release();
    }
    const { page, nextCursor } = mergeKeysetPages(pages, pageParams.limit);
    res.json({
      data: page.map((r) => serializeRun(r, ctx.inScope)),
      meta: { next_cursor: nextCursor },
    });
  } catch (err) {
    return unavailable(res, err, 'public /runs read failed');
  }
});

// ── GET /runs/{id} ───────────────────────────────────────────────────────────
router.get('/runs/:id', async (req, res) => {
  const ctx = await scopeContextOr503(req, res, 'public /runs/:id scope load failed');
  if (!ctx) return;
  const id = req.params.id;
  if (!UUID_RE.test(id)) return sendPublicError(res, 404, 'not_found');

  try {
    const conn = await pool.ro.getConnection();
    let row;
    try {
      const rows = await conn.query(
        `SELECT ${RUN_COLUMNS} FROM \`${t(TABLES.FLOW_RECIPE_RUNS)}\` WHERE id = ?`,
        [id],
      );
      row = rows[0];
    } finally {
      conn.release();
    }
    if (!row) return sendPublicError(res, 404, 'not_found');
    // Fail-closed: NULL blueprint_id or out-of-scope blueprint → invisible.
    if (!row.blueprint_id || !ctx.inScope.has(row.blueprint_id)) {
      return sendPublicError(res, 404, 'not_found');
    }
    res.json({ data: serializeRun(row, ctx.inScope) });
  } catch (err) {
    return unavailable(res, err, 'public /runs/:id read failed');
  }
});

// Catch-all: any unmatched public-read path is a public 404 (never the default
// Express HTML 404 body). Pool-not-ready surfaces per-handler via the pool.ro
// catch → edge_unreachable, so it is not re-checked here.
router.use((_req, res) => sendPublicError(res, 404, 'not_found'));

module.exports = router;
// Exposed for tests — reset the in-process node cache between fixtures.
module.exports._resetNodeCache = () => { _nodeCache = null; _nodeCacheAt = 0; };
// Exposed for tests — the timestamp serializer (TZ-correctness proof).
module.exports._iso = iso;
// Exposed for tests — the keyset WHERE fragment + ORDER BY, so the real-mariadb
// integration test drives the exact param-binding path the routes use.
module.exports._keysetFragment = keysetFragment;
module.exports._ORDER_BY = ORDER_BY;
