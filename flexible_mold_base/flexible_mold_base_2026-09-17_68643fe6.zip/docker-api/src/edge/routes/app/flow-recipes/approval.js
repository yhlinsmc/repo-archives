/**
 * flow-recipes/approval.js — the admin approval lifecycle for flow recipes.
 *
 * Mirrors api-connectors/approval.js exactly; the differences are:
 *   - Table target: FLOW_RECIPES (not API_CONNECTORS).
 *   - SENSITIVE_SCALAR: payload_transform_code, runs_on (the recipe-level
 *     scalar fields whose change must re-pend an approved recipe). content_type
 * retired here (flow-yaml-dialect) — it moved to the step, and any
 *     step write already re-pends the parent recipe via its OWN gate
 *     (flow-recipe-steps' unconditional parentRepend, not this file's list).
 *   - JSON re-pend triggers: consumed_output_keys, link_extract,
 *     external_id_extract (canonical-JSON compared). NOTE: the connector
 *     lifecycle no longer re-pends on request_config edits; this flow-recipe
 *     mirror intentionally stays strict on its own JSON trigger set above.
 *   - Audit event strings: flow_recipe.approval.granted / .rejected.
 *
 * status: pending → approved (admin) | rejected (admin, with note) → (edit) pending.
 * A NULL status is grandfathered = treated as approved at the dispatch gate, so
 * pre-existing recipes and no-ALTER operator DBs keep running.
 *
 * Two surfaces, both registered BEFORE the generic CRUD `/:id`:
 *   - a write middleware that stamps status on create and re-pends on a
 *     sensitive edit (and strips any client-supplied approval fields);
 *   - PATCH /:id/approve and PATCH /:id/reject (admin only).
 *
 * approved_by / approved_at / review_note are additive nullable columns; a
 * no-ALTER DB without them degrades gracefully (writes silently drop the unknown
 * keys; the PATCH routes return APPROVAL_UNAVAILABLE on ER_BAD_FIELD).
 */
const { pool, t } = require('../../../db');
const { sendError } = require('../../../../shared/lib/send-error');
const { apiError, requireAdmin, uuidv4, UUID_RE } = require('../../../../shared/helpers');
const { TABLES } = require('../../../../shared/constants');
const { logger } = require('../../../../shared/lib/logger');

// Server-controlled — a client may never set these directly.
const APPROVAL_FIELDS = ['status', 'approved_by', 'approved_at', 'review_note'];
// Write-side cap on the inline payload-shaping code. The column is TEXT (~64 KB)
// and `/usable` ships the code to every authenticated user who can see the
// blueprint, so an unbounded body is both a storage and a fan-out concern. The
// real authored code is a few hundred bytes; 32 KB is a generous ceiling that
// still rejects a runaway paste before it reaches the row.
const MAX_CODE_BYTES = 32 * 1024;
// Scalar fields whose change must re-pend an approved recipe.
const SENSITIVE_SCALAR = Object.freeze(['payload_transform_code', 'runs_on']);
// JSON config columns that also trigger re-pend on canonical-content change.
const JSON_SENSITIVE = Object.freeze(['consumed_output_keys', 'link_extract', 'external_id_extract']);
const MAX_NOTE = 2000;

async function writeApprovalAudit(conn, eventType, userId, recipeId) {
  try {
    await conn.query(
      `INSERT INTO \`${t(TABLES.FEATURE_AUDIT)}\` (id, event_type, user_id, metadata) VALUES (?, ?, ?, ?)`,
      [uuidv4(), eventType, userId || null, JSON.stringify({ recipe_id: recipeId })],
    );
  } catch (e) { logger.warn({ err: e }, 'flow_recipe approval audit write failed eventType=' + eventType); }
}

module.exports = function registerApproval(router) {
  // Write middleware: stamp status on create, re-pend on a sensitive/rejected edit.
  router.use(async (req, res, next) => {
    if ((req.method !== 'POST' && req.method !== 'PUT') || req.path === '/import') return next();
    if (!req.body || typeof req.body !== 'object') return next();
    // Validate the payload-transform body before it reaches the row (and before
    // /usable would later fan it out to every authed reader). A non-string,
    // non-null value would be JSON-serialised by the driver into the TEXT column
    // and could slip past a string-only size check, so reject it outright.
    const ptc = req.body.payload_transform_code;
    if (ptc != null && typeof ptc !== 'string') {
      return sendError(req, res, null, { status: 400, code: 'CODE_INVALID', reason: 'Payload code must be a string' });
    }
    if (typeof ptc === 'string' && Buffer.byteLength(ptc, 'utf8') > MAX_CODE_BYTES) {
      return sendError(req, res, null, { status: 400, code: 'CODE_TOO_LARGE', reason: `Payload code exceeds the ${Math.floor(MAX_CODE_BYTES / 1024)} KB limit` });
    }
    // SECURITY: approval state is server-owned — drop any client-supplied value so
    // an editor cannot self-approve via the body.
    for (const f of APPROVAL_FIELDS) delete req.body[f];

    const isAdmin = req.user?.role === 'admin';
    if (req.method === 'POST') {
      // admin-created → auto-approved (admin is the approver); editor → pending.
      if (isAdmin) {
        req.body.status = 'approved';
        req.body.approved_by = req.user?.id ?? null;
        req.body.approved_at = new Date();
      } else {
        req.body.status = 'pending';
      }
      return next();
    }

    // PUT: THE RE-PEND IS NOT HERE ANY MORE.
    //
    // It is a `repandOnSensitiveChange` declaration on the mount, so the probe
    // runs inside the factory's write transaction with the row locked and the
    // verdict folded into the same UPDATE — where it read `pool.ro` while the
    // approve/reject PATCHes below write `pool.rw`, with nothing holding the row
    // in between. The hand-written "try the full SELECT, catch errno 1054, try a
    // shorter one" is gone with it: the factory builds the probe from the
    // columns the table actually has, so a database missing ANY additive column
    // degrades, not only the one column somebody thought of.
    //
    // What stays on this verb is the strip above, which must happen before the
    // factory sees the body — it is why an editor cannot self-approve.
    return next();
  });

  // ACCEPT-RISK: a step swap that lands between the admin's review and this
  // approve can leave the recipe approved with content the admin never saw —
  // the swap re-pends the recipe to 'pending', then this approve flips it back
  // to 'approved'. The only sound fix is a revision-token optimistic guard (the
  // approve carries the steps-revision the admin reviewed; a mismatch → 409),
  // which is the optimistic-lock mechanism the operator declined. The residual
  // window is narrow (admin approving the very instant an editor swaps a step on
  // the same recipe) and the common ordering — approve first, swap second — is
  // already covered: the swap's atomic FOR-UPDATE re-pend re-pends the recipe
  // back to pending afterwards. Documented, not guarded. Note: when the race
  // does occur the audit trail records only flow_recipe.approval.granted — the
  // intermediate re-pend writes no audit row — so the log cannot distinguish a
  // raced approval from a clean one.
  router.patch('/:id/approve', async (req, res) => {
    if (!requireAdmin(req, res)) return;
    if (!UUID_RE.test(req.params.id)) { return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'Invalid recipe id' }); }
    let conn;
    try {
      conn = await pool.rw.getConnection();
      const r = await conn.query(
        `UPDATE \`${t(TABLES.FLOW_RECIPES)}\`
            SET status='approved', approved_by=?, approved_at=NOW(), review_note=NULL
          WHERE id = ?`,
        [req.user?.id ?? null, req.params.id],
      );
      if (!r.affectedRows) { return sendError(req, res, null, { status: 404, code: 'NOT_FOUND', reason: 'Recipe not found' }); }
      await writeApprovalAudit(conn, 'flow_recipe.approval.granted', req.user?.id, req.params.id);
      return res.json({ ok: true });
    } catch (err) {
      if (err?.code === 'ER_BAD_FIELD_ERROR' || err?.errno === 1054) {
        return sendError(req, res, err, { status: 409, code: 'APPROVAL_UNAVAILABLE', reason: 'Approval is unavailable until the database migration adds the approval columns' });
      }
      return sendError(req, res, err, { status: 500, code: 'INTERNAL_ERROR', reason: 'Database operation failed', fields: { id: req.params.id } });
    } finally { if (conn) conn.release(); }
  });

  router.patch('/:id/reject', async (req, res) => {
    if (!requireAdmin(req, res)) return;
    if (!UUID_RE.test(req.params.id)) { return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'Invalid recipe id' }); }
    const note = typeof req.body?.review_note === 'string' ? req.body.review_note.trim() : '';
    if (!note) { return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'A review note is required to reject a recipe' }); }
    let conn;
    try {
      conn = await pool.rw.getConnection();
      const r = await conn.query(
        `UPDATE \`${t(TABLES.FLOW_RECIPES)}\`
            SET status='rejected', approved_by=NULL, approved_at=NULL, review_note=?
          WHERE id = ?`,
        [note.slice(0, MAX_NOTE), req.params.id],
      );
      if (!r.affectedRows) { return sendError(req, res, null, { status: 404, code: 'NOT_FOUND', reason: 'Recipe not found' }); }
      await writeApprovalAudit(conn, 'flow_recipe.approval.rejected', req.user?.id, req.params.id);
      return res.json({ ok: true });
    } catch (err) {
      if (err?.code === 'ER_BAD_FIELD_ERROR' || err?.errno === 1054) {
        return sendError(req, res, err, { status: 409, code: 'APPROVAL_UNAVAILABLE', reason: 'Approval is unavailable until the database migration adds the approval columns' });
      }
      return sendError(req, res, err, { status: 500, code: 'INTERNAL_ERROR', reason: 'Database operation failed', fields: { id: req.params.id } });
    } finally { if (conn) conn.release(); }
  });
};

// The mount reads these to declare its `repandOnSensitiveChange` columns — one
// list, so what re-pends a recipe cannot drift from what this file documents.
module.exports.SENSITIVE_SCALAR = SENSITIVE_SCALAR;
module.exports.JSON_SENSITIVE = JSON_SENSITIVE;
