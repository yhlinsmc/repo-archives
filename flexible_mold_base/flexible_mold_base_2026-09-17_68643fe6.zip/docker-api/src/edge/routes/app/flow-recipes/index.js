/**
 * flow-recipes/index.js — router assembly for the Flow Recipes feature.
 *
 * Route registration order matters — all named sub-routes must be registered
 * BEFORE the generic CRUD catch-all so paths like /serialize, /approve, and
 * /reject are not swallowed by the /:id handler.
 *
 *   POST /serialize       — YAML conversion (admin/editor only, gated)
 *   PATCH /:id/approve    — admin approval (registered by approval.js)
 *   PATCH /:id/reject     — admin rejection (registered by approval.js)
 *   GET|POST|PUT|DELETE / — CRUD factory (owner-scoped, editor + admin)
 *
 * serializeRead strips approved_by/approved_at from every read response so
 * clients never learn who approved a recipe or when.
 */
const express = require('express');
const { sendError } = require('../../../../shared/lib/send-error');
// This file imports neither the pool nor the prefix helper any more: the "recipe
// still has steps" probe moved into the factory's own transaction, so the mount
// names its child table through TABLES and the factory resolves the prefix and
// picks the connection.
const { createCrudRoutes } = require('../schema');
const { enumColumnsFor, enumMembersFor } = require('../../../lib/schema-manifest');
const { requireAdminOrEditor, apiError } = require('../../../../shared/helpers');
const { TABLES } = require('../../../../shared/constants');
const { pool, t } = require('../../../db');
const { logger: rootLogger } = require('../../../../shared/lib/logger');
const { serializeRead } = require('./serializer');
const { findReservedConsumedKey, RESERVED_KEY } = require('./consumed-keys-guard');
// The ONE primitive that decides the step invariants (used here for I2, the
// mode-divergence half): the reverse gate — narrowing a recipe while a step
// still pins a diverging mode — asks the same predicate the step mount and the
// import path do, so it cannot drift from them.
const { assertStepInvariants } = require('../../../../shared/lib/flow-step-invariants');
// The one predicate the step read gate and both conflict gates decide recipe
// access by — reused here so the reverse gate cannot drift from the others.
const { callerMayReadRecipe } = require('./recipe-access');

const logger = rootLogger.child({ module: 'flow-recipes:index' });

const router = express.Router();

// Usable projection for data-entry users (requireAuth only, narrow projection)
// — mounted BEFORE the admin/editor gate so plain users can discover runnable
// recipes for a blueprint without seeing owner/status/config/secrets.
// Mirrors api-connectors/usable.js.
require('./usable')(router);

// Everything below is admin-or-editor only.
router.use((req, res, next) => {
  if (!requireAdminOrEditor(req, res)) return;
  next();
});

// THE "RECIPE STILL HAS STEPS" GATE IS NOT HERE ANY MORE.
//
// It is a `refuseDeleteWhenReferenced` declaration on the mount, so the probe
// runs inside the transaction the DELETE already opens, on the write connection
// and FOR UPDATE. Here it was an unlocked `SELECT 1 … LIMIT 1` on `pool.ro`
// taken before that transaction existed, so a step inserted in the window
// between the probe and the DELETE was orphaned — and an orphan step row
// carries an encrypted credential and is unreachable to editors thereafter,
// because the ownership chain needs the parent that no longer exists.

// /serialize must be registered before the CRUD /:id catch-all so the path
// resolves correctly. It is gated by the requireAdminOrEditor above.
require('./serialize-endpoint')(router);

// Approval lifecycle (PATCH /:id/approve, /:id/reject + status stamp on
// create/edit) — registered before the CRUD /:id so PATCH routes are not
// shadowed by the factory's generic /:id handler.
require('./approval')(router);
// The columns whose change re-pends this recipe are declared beside the
// approval lifecycle they belong to, and read here — one list, not two.
const { SENSITIVE_SCALAR, JSON_SENSITIVE } = require('./approval');

// Cross-environment export (no secrets) / import (+ steps, lineage re-bind),
// registered before the CRUD catch-all so /import and /:id/export match ahead
// of the generic /:id handler (same ordering rule as /serialize, /approve).
require('./io')(router);

// Reserved-key guard for consumed_output_keys on the generic CRUD create/update
// path. Registered AFTER the named sub-routes (io/approve/serialize) so it only
// gates POST / and PUT /:id; the import path validates its own nested payload in
// io.js. Absent key = no-op; a reserved key = 400 before the factory writes.
router.use((req, res, next) => {
  if (req.method !== 'POST' && req.method !== 'PUT') return next();
  const keys = req.body && req.body.consumed_output_keys;
  if (keys == null) return next();
  const bad = findReservedConsumedKey(keys);
  if (bad) {
    return sendError(req, res, null, { status: 400, code: 'RESERVED_OUTPUT_KEY', reason: `consumed_output_keys entry "${bad}" is reserved: keys equal to "${RESERVED_KEY}" or starting with "${RESERVED_KEY}." collide with the dispatch data vocabulary` });
  }
  next();
});

// compare_spec / link_extract / external_id_extract shape guard, via the one
// write primitive (I3). Registered alongside the reserved-key guard for the
// same reason: it only needs to gate the generic CRUD create/update path
// (POST / and PUT /:id) — the import path (io.js) calls the same primitive
// on its own raw-SQL create. A whole JSON column is always replaced (never
// merged), so a body naming a field carries the complete new value; no
// stored-row read is needed.
router.use((req, res, next) => {
  if (req.method !== 'POST' && req.method !== 'PUT') return next();
  const body = req.body;
  if (!body || typeof body !== 'object') return next();
  const namesCompareSpec = Object.prototype.hasOwnProperty.call(body, 'compare_spec');
  const namesLinkExtract = Object.prototype.hasOwnProperty.call(body, 'link_extract');
  const namesExternalIdExtract = Object.prototype.hasOwnProperty.call(body, 'external_id_extract');
  if (!namesCompareSpec && !namesLinkExtract && !namesExternalIdExtract) return next();
  const shapeVerdict = assertStepInvariants({
    recipe: {
      ...(namesCompareSpec ? { compare_spec: body.compare_spec } : {}),
      ...(namesLinkExtract ? { link_extract: body.link_extract } : {}),
      ...(namesExternalIdExtract ? { external_id_extract: body.external_id_extract } : {}),
    },
    step: {},
  });
  if (shapeVerdict) {
    return sendError(req, res, null, { status: 400, code: shapeVerdict.code, reason: shapeVerdict.message });
  }
  next();
});

// runs_on conflict gate, reverse direction: narrowing a recipe from 'both' to
// a single mode X while any of its existing steps carries a step_runs_on that
// DIVERGES from X (a different single mode, e.g. 'update' when narrowing to
// 'create') would leave that step's own trigger meaningless (its recipe no
// longer runs the mode the step differentiated against) — reject rather than
// silently orphan it. A step already 'both' or already equal to X is not a
// conflict and does not block the narrow.
// Only a PUT can narrow an EXISTING recipe with EXISTING steps; a POST create
// has no steps yet, so this only ever fires on PUT /:id.
router.use(async (req, res, next) => {
  if (req.method !== 'PUT') return next();
  const body = req.body;
  if (!body || typeof body !== 'object'
    || !Object.prototype.hasOwnProperty.call(body, 'runs_on')
    || body.runs_on === 'both') return next();

  // Validate runs_on against the column's own DDL domain BEFORE probing. A value
  // the column does not accept is not a mode conflict, so running the probe on it
  // reports a misleading FLOW_STEP_MODE_CONFLICT for what is really a bad enum.
  // An unrecognised value is handed to the CRUD factory, whose enumColumns check
  // (the same DDL domain, read the same way) answers with the standard
  // invalid-enum error; the probe never runs on it (never fall-open).
  const runsOnDomain = enumMembersFor(TABLES.FLOW_RECIPES, 'runs_on');
  if (runsOnDomain && !runsOnDomain.includes(body.runs_on)) return next();

  const singleIdMatch = req.path.match(/^\/([^/]+)\/?$/);
  const recipeId = singleIdMatch ? singleIdMatch[1] : null;
  if (!recipeId) return next();

  try {
    // Resolve the caller's access to the recipe BEFORE the steps probe. The probe
    // names the recipe's diverging steps in its 400, so a caller who cannot read
    // the recipe must never reach it — they fall through to the CRUD factory,
    // which answers a foreign id with its usual 404 (existence-leak parity) and
    // no step names, adding no new signal here. Admin sees every recipe.
    if (req.user?.role !== 'admin') {
      const ownerRows = await pool.ro.query(
        `SELECT owner_id FROM \`${t(TABLES.FLOW_RECIPES)}\` WHERE id = ?`,
        [recipeId],
      );
      if (ownerRows.length && !(await callerMayReadRecipe(ownerRows[0].owner_id, req))) {
        return next();
      }
    }

    const stepRows = await pool.ro.query(
      `SELECT id, name, step_runs_on FROM \`${t(TABLES.FLOW_RECIPE_STEPS)}\` WHERE recipe_id = ?`,
      [recipeId],
    );
    // ANY non-null verdict blocks the narrow, not only MODE_CONFLICT. A stored
    // step carrying an unrecognised step_runs_on (legacy/corrupt) makes the
    // primitive return FLOW_STEP_TRIGGER_INVALID, and treating only
    // MODE_CONFLICT as offending would let the narrow commit over a step the
    // primitive would fail closed at run time — the gate must surface it now,
    // naming the code per step so the operator can see which fault each is.
    const offending = stepRows
      .map((s) => ({ s, v: assertStepInvariants({ recipe: { runs_on: body.runs_on }, step: { step_runs_on: s.step_runs_on } }) }))
      .filter((x) => x.v != null);
    if (offending.length) {
      const names = offending.map((x) => `${x.s.name || x.s.id} (${x.v.code})`).join(', ');
      return sendError(req, res, null, { status: 400, code: 'FLOW_STEP_MODE_CONFLICT', reason: `Cannot narrow "Runs for" while these steps still conflict: ${names}. Set them back to Both first.` });
    }
  } catch (err) {
    // A no-ALTER DB missing step_runs_on has no per-step divergence possible —
    // degrade to "no conflict" rather than blocking every recipe save.
    if (err && (err.errno === 1054 || err.code === 'ER_BAD_FIELD_ERROR')) return next();
    if (err && err.errno === 1146) return next(); // steps table absent — nothing to conflict with
    return sendError(req, res, err, { status: 500, code: 'INTERNAL_ERROR', reason: 'Database operation failed', fields: { recipeId } });
  }
  next();
});

// In-tx re-check for the reverse runs_on conflict gate above — same race, same
// close, opposite direction: this write's own pre-transaction probe read the
// steps via pool.ro before a write transaction existed, so a concurrent step
// write (the forward gate's own in-tx re-check, flow-recipe-steps/index.js)
// can set a step's own trigger between that read and this commit. FOR UPDATE
// on every step row this recipe owns forces that concurrent step write — which
// must itself lock its own row to commit. INVARIANT: a divergent recipe/step
// pair never commits — the FOR UPDATE re-check either sees the counterpart's
// committed state or the inverted lock order deadlocks (1213) and InnoDB rolls
// one side back; the loser gets a 500, never a partial write.
//
// Wired as `postUpdateInTx`, NOT `preWriteInTx`, though the invariant is the
// same shape as the step mount's forward re-check: `preWriteInTx` on THIS
// mount unconditionally turns on an editor-only ownership pre-check
// (crud-factory's own `if (preWriteInTx && parentOwnership && … role ===
// 'editor')` block) that re-probes the blueprint chain on every editor PUT —
// including one that never touches blueprint_id, which the ownership
// pre-check on an unchanged parent makes redundant. `postUpdateInTx` runs after the ownership-scoped UPDATE has
// already matched (so an unauthorized PUT still 404s first, unaffected) and
// carries no such side effect. The trade-off the brief accepts explicitly
// ("keep the pre-transaction gate for the friendly 400 message; the
// in-transaction check is the invariant"): a hook here cannot return a
// shaped 400 — the factory's PUT catch does not read a thrown error's
// status/body the way POST's does — so a conflict THROWS and surfaces as a
// generic 500 (rolling the transaction back). The pre-transaction gate above
// still answers the common, non-race case with the friendly 400; this is
// only reached when that gate's unlocked read was already stale.
async function recheckRecipeRunsOnAfterUpdate(conn, req, data) {
  if (!Object.prototype.hasOwnProperty.call(data, 'runs_on') || data.runs_on === 'both') return;
  // Same enum-domain guard as the pre-transaction gate: an unrecognised value
  // is not a mode conflict — the factory's own enumColumns check (same DDL
  // domain) already answered it before this UPDATE could even reach here.
  const runsOnDomain = enumMembersFor(TABLES.FLOW_RECIPES, 'runs_on');
  if (runsOnDomain && !runsOnDomain.includes(data.runs_on)) return;
  let stepRows;
  try {
    stepRows = await conn.query(
      `SELECT id, name, step_runs_on FROM \`${t(TABLES.FLOW_RECIPE_STEPS)}\` WHERE recipe_id = ? FOR UPDATE`,
      [req.params.id],
    );
  } catch (err) {
    // Same degrade as the router-level gate: a no-ALTER target missing
    // step_runs_on, or an absent steps table, has no divergence to detect.
    if (err && (err.errno === 1054 || err.code === 'ER_BAD_FIELD_ERROR')) return;
    if (err && err.errno === 1146) return;
    throw err;
  }
  // ANY non-null verdict blocks (see the router-level gate above): a stored
  // step with an unrecognised step_runs_on returns FLOW_STEP_TRIGGER_INVALID,
  // and the locked re-read must roll the narrow back rather than commit over it.
  const offending = stepRows
    .map((s) => ({ s, v: assertStepInvariants({ recipe: { runs_on: data.runs_on }, step: { step_runs_on: s.step_runs_on } }) }))
    .filter((x) => x.v != null);
  if (offending.length) {
    const names = offending.map((x) => `${x.s.name || x.s.id} (${x.v.code})`).join(', ');
    throw new Error(
      `FLOW_STEP_MODE_CONFLICT: cannot narrow "Runs for" while these steps still conflict: ${names}`,
    );
  }
}

router.use('/', createCrudRoutes('flow_recipes', {
  // owner_id is stamped to the creator on POST.
  ownerColumn: 'owner_id',
  // Editors may author recipes; plain users cannot (gate above).
  allowedRoles: ['admin', 'editor'],
  // Editor create/edit must bind to a blueprint they own or that is shared
  // (NULL owner). Admin bypasses; a null blueprint_id from an editor is
  // rejected (recipes are blueprint-bound). Mirrors the connector mount.
  parentOwnership: {
    via: 'blueprint_id',
    chain: [{ table: TABLES.HIERARCHY_NODES, match: 'id', readOwner: 'owner_id' }],
  },
  filterableColumns: ['blueprint_id', 'is_active'],
  resolveOwnerName: 'owner_id',
  // TOCTOU close: see recheckRecipeRunsOnAfterUpdate above (postUpdateInTx,
  // not preWriteInTx — the doc-block on that function says why).
  postUpdateInTx: recheckRecipeRunsOnAfterUpdate,
  // THE DOMAIN IS THE TABLE'S, ASKED OF THE DDL — the same declaration the two
  // sibling mounts carry, and the same reason for asking the whole table rather
  // than listing columns here. This mount had none at all, while one of the two
  // scalars its re-pend watches (`runs_on`) is an ENUM (content_type moved to the
  // step, flow-yaml-dialect): the re-pend's own comment says the byte
  // compare is sound because a domain gate has already proved the written value
  // is identically a member, and on this mount nothing had. `PUT
  // {"runs_on":"CREATE"}` reached the statement with the caller's spelling; the
  // engine folded it and the compare called it a change.
  //
  // CLIENT-VISIBLE, and stated rather than described as a tidy-up: a case variant
  // that used to store correctly (the engine folds ENUM case on write) is now a
  // stable 400. The browser sends the member; scripts and integrations may not.
  enumColumns: enumColumnsFor(TABLES.FLOW_RECIPES),
  serializeRead,
  // Belt-and-braces: code_version is server-computed. The factory strips it from
  // every codeVersioning write, and this PUT-path immutable guard is a second
  // layer documenting the invariant at the mount.
  immutableColumns: ['code_version'],
  // Append an immutable history row + bump code_version whenever the inline
  // payload_transform_code changes on create/update, all in the write's own
  // transaction. Import (io.js) writes its own v1 'import' row; export stays
  // version-ignorant.
  // SECURITY: a recipe with steps cannot be deleted, and that is decided inside
  // the delete's own transaction — there is no FK cascade, so the rows this
  // protects would otherwise become orphans carrying encrypted credentials that
  // no editor can reach.
  refuseDeleteWhenReferenced: [{
    table: TABLES.FLOW_RECIPE_STEPS,
    fk: 'recipe_id',
    code: 'RECIPE_HAS_STEPS',
    message: 'This recipe still has steps; delete them first',
  }],
  codeVersioning: {
    watchColumn: 'payload_transform_code',
    versionColumn: 'code_version',
    historyTable: TABLES.FLOW_RECIPE_CODE_VERSIONS,
    historyFkColumn: 'recipe_id',
  },
  // SECURITY: the mirror of the connector mount's declaration. A change to what
  // this recipe sends, or to the shape it sends it in, clears its approval —
  // inside the same transaction and the same statement as the change. NULL is
  // among the states this fires from: a grandfathered recipe's steps DO
  // dispatch, so an unreviewed edit to one must stop that. Which states re-pend
  // is review-status.js's answer.
  repandOnSensitiveChange: {
    statusCol: 'status',
    clearCols: ['approved_by', 'approved_at'],
    columns: SENSITIVE_SCALAR,
    jsonColumns: JSON_SENSITIVE,
  },
}));

module.exports = router;
