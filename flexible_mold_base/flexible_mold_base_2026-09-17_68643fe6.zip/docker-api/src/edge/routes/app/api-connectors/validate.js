/**
 * validate.js — shared write-shape validators for api_connectors.
 *
 * The chain-wiring check lives here so every write path (create, update, import)
 * holds a payload to the exact same shape contract — a malformed
 * input_from_step would otherwise be stored and surface as a confusing runtime
 * chain break instead of a friendly 400 at the boundary.
 */

/**
 * Validate request_config.input_from_step against the chain-wiring contract.
 *
 * @param {unknown} requestConfig - the connector's request_config (parsed object or null)
 * @param {unknown} sequence - the connector's own sequence (integer, or undefined/null)
 * @returns {string|null} an error message when invalid, or null when OK / absent
 */
function validateInputFromStep(requestConfig, sequence) {
  if (!requestConfig || typeof requestConfig !== 'object') return null;
  const ifs = requestConfig.input_from_step;
  if (ifs == null) return null;
  if (!Array.isArray(ifs)) return 'request_config.input_from_step must be an array';
  for (const e of ifs) {
    if (!e || typeof e !== 'object') return 'input_from_step entries must be objects';
    if (typeof e.var !== 'string' || !e.var.trim()) return 'input_from_step var must be a non-empty string';
    if (!Number.isInteger(e.from_sequence) || e.from_sequence < 1) return 'input_from_step from_sequence must be a positive integer';
    if (typeof e.path !== 'string' || !e.path.trim()) return 'input_from_step path must be a non-empty string';
    if (Number.isInteger(sequence) && e.from_sequence >= sequence) {
      return 'input_from_step from_sequence must reference an earlier step (smaller than this connector\'s sequence)';
    }
  }
  // INVARIANT: declaring step wiring requires declaring your own step position
  // in the same write — otherwise the earlier-step check above is skipped and a
  // self/future from_sequence reaches the DB, surfacing as a runtime chain
  // failure instead of this friendly 400. Empty array / null still pass without
  // a sequence so clearing wiring stays easy.
  if (ifs.length > 0 && !Number.isInteger(sequence)) {
    return 'sequence is required when declaring input_from_step';
  }
  return null;
}

// List-filter comparison operators, mirrored from the FE FilterOp union
// (src/fmb/hooks/useApiConnectors.ts). Kept in lockstep with the apply engine's
// accepted ops; a rows-sink join key may compare with any of these.
const FILTER_OPS = new Set(['eq', 'neq', 'contains', 'gt', 'lt', 'gte', 'lte', 'in']);

/**
 * Validate response_config.outputs[] rows-sink `match` blocks against the
 * enrich-by-key contract. A `to:rows` sink may carry an optional `match`
 * ({row_column, element_field, op?}) to enrich existing rows by key instead of
 * creating one row per element; a PARTIAL match (one join key missing) is a
 * malformed config that would silently degrade at runtime, so reject it here
 * with a friendly 400.
 *
 * @param {unknown} responseConfig - the connector's response_config (parsed object or null)
 * @returns {string|null} an error message when invalid, or null when OK / absent
 */
function validateResponseOutputs(responseConfig) {
  if (!responseConfig || typeof responseConfig !== 'object') return null;
  const outputs = responseConfig.outputs;
  if (outputs == null) return null;
  if (!Array.isArray(outputs)) return 'response_config.outputs must be an array';
  // spec §1.3 scopes id uniqueness to to.mode:'options' outputs only — an
  // options output's id doubles as the output_id a field/column references,
  // so it must never collide with ANY other output's id (options or not).
  // Two non-options outputs sharing an id is pre-existing, unenforced
  // behaviour (nothing reads a field/rows/cell output by id); widening the
  // check to them would 400 an already-stored connector on its next save.
  const idCounts = new Map();
  for (const o of outputs) {
    if (o && typeof o === 'object' && typeof o.id === 'string' && o.id) {
      idCounts.set(o.id, (idCounts.get(o.id) || 0) + 1);
    }
  }
  for (const o of outputs) {
    if (!o || typeof o !== 'object') continue;
    const to = o.to;
    if (to && typeof to === 'object' && to.mode === 'options') {
      // spec §1.3: id non-empty + unique across outputs[], from.mode === 'list',
      // value_path non-empty string, label_path (when present) non-empty string.
      if (typeof o.id !== 'string' || !o.id) return 'options output requires a non-empty string id';
      if ((idCounts.get(o.id) || 0) > 1) return `output id '${o.id}' is not unique across outputs`;
      if (!o.from || typeof o.from !== 'object' || o.from.mode !== 'list') return "options output requires from.mode 'list'";
      // Trimmed, mirroring the rows-sink match key checks (row_column/element_field
      // above) — an untrimmed whitespace-only path would pass this check, get
      // stored, and then silently vanish on the next editor save (the FE
      // completeness check trims before deciding an output is actionable).
      if (typeof to.value_path !== 'string' || !to.value_path.trim()) return 'options output value_path must be a non-empty string';
      if (to.label_path !== undefined && (typeof to.label_path !== 'string' || !to.label_path.trim())) return 'options output label_path, when present, must be a non-empty string';
      // spec §5, D-13: from.where IS a real filter on an options output —
      // it filters the RAW elements before value/label
      // extraction, same as every other list output. Its SHAPE (match:'all'
      // only, single-condition for a cell-kind value) is validated below by
      // validateConnectorCoherence, which already applies to any
      // from.mode:'list' output regardless of to.mode — no options-specific
      // branch (D-14), so nothing else is added here.
      // Fail-closed on the sink shape: an options `to` carries only mode,
      // value_path, label_path (spec §1.3). A stray key (e.g. a leftover
      // field_key/table_key from switching sink mode in a hand-edited import)
      // would otherwise be stored inert and silently ignored at fetch time.
      const allowedToKeys = new Set(['mode', 'value_path', 'label_path']);
      const strayToKey = Object.keys(to).find((k) => !allowedToKeys.has(k));
      if (strayToKey) return `options output 'to' has an unknown key '${strayToKey}'`;
      continue;
    }
    if (!to || typeof to !== 'object' || to.mode !== 'rows') continue;
    if (to.order_by != null) {
      if (!Array.isArray(to.order_by)) return 'rows-sink order_by must be an array';
      for (const k of to.order_by) {
        if (!k || typeof k !== 'object') return 'rows-sink order_by entry must be an object';
        if (typeof k.column !== 'string' || !k.column.trim()) return 'rows-sink order_by entry must have a non-empty string column';
        if (k.dir !== 'asc' && k.dir !== 'desc') return "rows-sink order_by entry dir must be 'asc' or 'desc'";
      }
      // Defense in depth (Fix 3): order_by is meaningless on a join sink — the
      // apply engine skips the join fan-out path and the FE editor hides the
      // control for mergeRows. Reject the combination at the write boundary so
      // a hand-edited import can't store an incoherent config that silently does
      // nothing at runtime.
      if (to.match != null) {
        return 'rows-sink order_by cannot be combined with match (join); order_by only applies to create-rows fan-out';
      }
    }
    // A replace output clears the WHOLE table before writing — match keys
    // (enrich-by-key) are meaningless on it. Mirrors the FE save guard
    // (connector-save-guards.ts validateRowsSinkOutput).
    if (to.write_mode === 'replace' && to.match != null) {
      return "rows-sink write_mode 'replace' cannot declare match keys";
    }
    // A replace clears the WHOLE table before writing — on_no_match (join
    // upsert) is meaningless on it, same as match keys above. Reject ANY
    // on_no_match (including 'skip') when write_mode is 'replace', regardless
    // of whether match is present — mirrors the FE save guard exactly
    // (connector-save-guards.ts validateRowsSinkOutput), which the generic
    // match==null branch below does not (it only rejects non-'skip' values).
    if (to.write_mode === 'replace' && to.on_no_match !== undefined) {
      return "rows-sink write_mode 'replace' cannot set on_no_match";
    }
    if (to.match == null) {
      // An explicit merge with NO match block can never converge: a routed reader
      // classifies it as a join (which errors "no match keys") and the engine
      // throws. Reject it here (X2 — mirrors the FE save guard) so it can never be
      // stored, whether the keys were dropped by the editor trim or never
      // supplied. A merge WITH a match but empty/unusable keys is caught below by
      // the keys[] and per-key checks; this branch only sees the no-match case.
      if (to.write_mode === 'merge') return 'A merge output must declare at least one usable match key.';
      // No join key declared = create-rows fan-out; on_no_match is meaningless
      // without a match, so a stray value here is a malformed config.
      if (to.on_no_match != null && to.on_no_match !== 'skip') return "rows-sink on_no_match must be 'skip' when present";
      continue;
    }
    if (typeof to.match !== 'object') return 'rows-sink match must be an object';
    // The match may be the legacy single-pair shape ({row_column, element_field,
    // op?}) or the composite keys[] shape; a row matches an element iff EVERY key
    // matches. Validate each key (accepting either shape via the legacy fallback).
    const rawKeys = Array.isArray(to.match.keys) ? to.match.keys : [to.match];
    if (rawKeys.length === 0) return 'rows-sink match must declare at least one key';
    let allEq = true;
    for (const m of rawKeys) {
      if (!m || typeof m !== 'object') return 'rows-sink match key must be an object';
      if (typeof m.row_column !== 'string' || !m.row_column.trim()) return 'rows-sink match.row_column must be a non-empty string';
      if (m.element_field != null && typeof m.element_field !== 'string') return 'rows-sink match.element_field must be a string';
      if (m.source_cell != null && typeof m.source_cell !== 'string') return 'rows-sink match.source_cell must be a string';
      // A key draws its value from the response element (element_field) OR the
      // triggering source row's column (source_cell, Q19). At least one must be
      // present — a source-cell-only key has a blank element_field by design and
      // must be accepted (it is the cross-table composite-key case).
      const hasElementField = typeof m.element_field === 'string' && m.element_field.trim() !== '';
      const hasSourceCell = typeof m.source_cell === 'string' && m.source_cell.trim() !== '';
      if (!hasElementField && !hasSourceCell) return 'rows-sink match key must have a non-empty element_field or source_cell';
      if (m.op != null && !FILTER_OPS.has(m.op)) return `rows-sink match.op must be one of: ${[...FILTER_OPS].join(', ')}`;
      if ((m.op ?? 'eq') !== 'eq') allEq = false;
    }
    // A join may skip unmatched elements or create a row for each (upsert).
    if (to.on_no_match != null && to.on_no_match !== 'skip' && to.on_no_match !== 'create') {
      return "rows-sink on_no_match must be 'skip' or 'create' when present";
    }
    // Upsert-by-key is only well-defined under equality on EVERY key (the FE
    // guards this too); a non-eq key has no unique-row identity to create against.
    if (to.on_no_match === 'create' && !allEq) {
      return "rows-sink on_no_match 'create' requires every match key op to be 'eq'";
    }
  }
  return null;
}

/**
 * Validate request_config.input_cells[] row indices. A 1-based `row` marks a
 * fixed single-cell input (resolved once); when present it must be a positive
 * integer, else the runtime cell binding silently breaks.
 *
 * @param {unknown} requestConfig - the connector's request_config (parsed object or null)
 * @returns {string|null} an error message when invalid, or null when OK / absent
 */
function validateInputCells(requestConfig) {
  if (!requestConfig || typeof requestConfig !== 'object') return null;
  const cells = requestConfig.input_cells;
  if (cells == null) return null;
  if (!Array.isArray(cells)) return 'request_config.input_cells must be an array';
  for (const c of cells) {
    if (!c || typeof c !== 'object') continue;
    if (c.row != null && (!Number.isInteger(c.row) || c.row < 1)) {
      return 'input_cells row must be a positive integer when present';
    }
  }
  return null;
}

/**
 * Normalize a rows-sink `match` to the composite keys[] shape, mirroring the FE
 * twin (src/fmb/lib/connectors/row-match.ts). Accepts the legacy single-pair
 * shape ({row_column, element_field, op?}) and the keys[] shape; drops a
 * fully-blank key and an invalid op. Returns undefined when no key survives.
 *
 * @param {unknown} raw - the stored/parsed match block
 * @returns {{keys: Array<{row_column: string, element_field: string, op?: string}>}|undefined}
 */
function normalizeRowMatch(raw) {
  if (!raw || typeof raw !== 'object') return undefined;
  const rawKeys = Array.isArray(raw.keys) ? raw.keys : [raw];
  const keys = [];
  for (const k of rawKeys) {
    if (!k || typeof k !== 'object') continue;
    const row_column = typeof k.row_column === 'string' ? k.row_column : '';
    const element_field = typeof k.element_field === 'string' ? k.element_field : '';
    if (!row_column && !element_field) continue;
    const op = (typeof k.op === 'string' && FILTER_OPS.has(k.op)) ? k.op : undefined;
    // Preserve the Q19 provenance redirect (source-row column) — mirrors the FE
    // twin so the normalized shape does not silently drop cross-table merge keys.
    const source_cell = (typeof k.source_cell === 'string' && k.source_cell) ? k.source_cell : undefined;
    keys.push({ row_column, element_field, ...(op ? { op } : {}), ...(source_cell ? { source_cell } : {}) });
  }
  return keys.length ? { keys } : undefined;
}

/**
 * Validate cross-field connector coherence, mirroring the editor's save-time
 * guards (src/fmb/components/admin/api-connectors/connector-save-guards.ts) so a
 * hand-edited import or a raw API write is held to the same contract the editor
 * enforces — otherwise an incoherent connector reaches the DB and degrades
 * silently at runtime (getTableBinding picks one table, the fan-out modal drops
 * a mixed output) instead of surfacing as a friendly 400.
 *
 * Kept in lockstep with the FE module; the error strings are byte-identical so
 * the same message surfaces whichever boundary rejects.
 *
 * @param {unknown} requestConfig - the connector's request_config (parsed object or null)
 * @param {unknown} responseConfig - the connector's response_config (parsed object or null)
 * @returns {string|null} an error message when incoherent, or null when OK / absent
 */
function validateConnectorCoherence(requestConfig, responseConfig) {
  const outputs = responseConfig && typeof responseConfig === 'object' && Array.isArray(responseConfig.outputs)
    ? responseConfig.outputs
    : [];

  // Fan-out (Table rows) is single-purpose: a rows output cannot mix with
  // field/cell outputs, and there can be only one. Mixed/multiple rows outputs
  // are silently dropped at apply time. An options-list output is neither a
  // fill nor a fan-out (spec §1.4), so it is excluded from both totals before
  // comparing — it may coexist with a rows output or stand alone.
  const isOptions = (o) => o && o.to && typeof o.to === 'object' && o.to.mode === 'options';
  const nonOptions = outputs.filter((o) => !isOptions(o));
  const rowsCount = nonOptions.filter((o) => o && o.to && typeof o.to === 'object' && o.to.mode === 'rows').length;
  if (rowsCount > 0) {
    if (rowsCount !== nonOptions.length) return 'A fan-out connector can only have Table rows outputs.';
    if (rowsCount > 1) return 'A fan-out connector can have only one Table rows output.';
  }

  // Aggregate the rows-sink target table(s). A rows sink (same-table fan-out OR
  // cross-table append/merge/replace) writes to the table it names, so a raw import /
  // API write that stores a rows output with a blank target — a shape the editor
  // never produces — must be rejected before it reaches a writeless run. Unlike
  // the same-row coherence set below (input cells + cell sinks, which must all
  // stay on ONE bound table), a rows sink's target is allowed to DIFFER from the
  // bound table (that is the cross-table capability), so it is validated here on
  // its own rather than folded into that set. FE twin: connector-save-guards.ts.
  for (const o of outputs) {
    if (o && o.to && o.to.mode === 'rows' && (typeof o.to.table_key !== 'string' || !o.to.table_key.trim())) {
      return 'A Table rows output must target a table field.';
    }
  }

  // Only AND (match:'all') filters are implemented; a cell-sourced filter value
  // resolves via a single per-output override, so it is valid only in a
  // single-condition filter.
  for (const o of outputs) {
    if (!o || !o.from || typeof o.from !== 'object' || o.from.mode !== 'list' || !o.from.where) continue;
    const where = o.from.where;
    if (where.match !== 'all') {
      return 'Filter match must be "all" (AND); "any" (OR) is not supported.';
    }
    if (Array.isArray(where.conditions) && where.conditions.length > 1
      && where.conditions.some((c) => c && c.value && c.value.kind === 'cell')) {
      return 'A cell-sourced filter value is only allowed in a single-condition filter.';
    }
  }

  const cells = requestConfig && typeof requestConfig === 'object' && Array.isArray(requestConfig.input_cells)
    ? requestConfig.input_cells
    : [];
  const isValidCell = (c) => Boolean(
    c && typeof c === 'object' && c.table_key && typeof c.var === 'string' && c.var.trim()
      && (c.source === 'manual' || c.column_key),
  );
  // A per-row cell is a valid cell with no numeric `row` (a fixed cell pins a row
  // and single-fetches). Runtime per-row dispatch keys off this, not the stored
  // mode — a create-rows fan-out (rows output WITHOUT a match) is scalar-input
  // only, so it can never run bound to a per-row cell.
  const hasPerRowCell = cells.some((c) => isValidCell(c) && typeof c.row !== 'number');
  // The write mode routes through the write_mode toggle (falling back to match
  // presence) so an explicit write_mode wins — mirrors the FE resolveRowsWriteMode.
  const rowsWriteMode = (to) => (to.write_mode === 'append' || to.write_mode === 'merge' || to.write_mode === 'replace'
    ? to.write_mode
    : (to.match ? 'merge' : 'append'));
  // A SAME-TABLE create-rows (append) fan-out is scalar-input only. A cross-table
  // rows sink (target ≠ the bound input table) is the opposite: it REQUIRES the
  // per-row input to drive its aggregation, so it is exempt (items 2/3).
  const inputTableKeys = new Set(cells.filter(isValidCell).map((c) => c.table_key));

  // Cross-table provenance / op boundary (F1 twin of the FE validateRowsSinkOutput).
  // The bound per-row source table is the single table a PER-ROW cell binds (a
  // fixed cell single-fetches and cannot drive cross-table aggregation); a sink
  // writing to a DIFFERENT table is cross-table. Provenance (Q19 source_cell /
  // from_source_cell) only resolves against a triggering source row, and a non-eq
  // merge op is only meaningful on the same-table engine — so reject the wrong-
  // side shape here too, so a raw import / API write cannot store what the editor
  // normalizes away. Ordered BEFORE the scalar-input guard so a same-table sink
  // wrongly carrying provenance reports the sink-shape fault, not the input one.
  // Messages byte-identical to the FE twin. Blank targets were already rejected
  // above, so every rows sink here has a real target_key.
  const perRowTables = new Set(cells.filter((c) => isValidCell(c) && typeof c.row !== 'number').map((c) => c.table_key));
  const sourceTableKey = perRowTables.size === 1 ? [...perRowTables][0] : undefined;
  for (const o of outputs) {
    if (!o || !o.to || o.to.mode !== 'rows') continue;
    const to = o.to;
    const keys = to.match && Array.isArray(to.match.keys) ? to.match.keys : (to.match ? [to.match] : []);
    const cols = Array.isArray(to.columns) ? to.columns : [];
    const isCross = sourceTableKey !== undefined && typeof to.table_key === 'string' && to.table_key !== sourceTableKey;
    const hasProvenance =
      keys.some((k) => k && typeof k.source_cell === 'string' && k.source_cell.trim() !== '')
      || cols.some((c) => c && typeof c.from_source_cell === 'string' && c.from_source_cell.trim() !== '');
    if (hasProvenance && !isCross) return 'Source-row values require a cross-table target table.';
    // The eq-only rule is a MERGE constraint: an append IGNORES match at runtime,
    // so a stale non-eq match on an append is inert and must not block import/update
    // (X1). Gate on the EFFECTIVE write mode via the shared resolver, not on match
    // presence.
    if (isCross && rowsWriteMode(to) === 'merge' && keys.some((k) => k && (k.op == null ? 'eq' : k.op) !== 'eq')) {
      return 'A cross-table merge key must use the "equals" operator.';
    }
    // CN-REPL: whole-table replace is now legal cross-table too — the FE's
    // staged build + one atomic swap (base = empty array, never a streaming
    // per-row clear) makes "clear then write" coherent for it. Mirrors the FE
    // guard (connector-save-guards.ts validateRowsSinkOutput no longer rejects
    // this combination either).
  }

  if (
    hasPerRowCell &&
    outputs.some(
      (o) =>
        o && o.to && o.to.mode === 'rows' &&
        (rowsWriteMode(o.to) === 'append' || rowsWriteMode(o.to) === 'replace') &&
        (!o.to.table_key || inputTableKeys.has(o.to.table_key)),
    )
  ) {
    return 'A fan-out (Table rows) connector must use scalar inputs — it cannot bind table-cell inputs.';
  }

  // Table-coherence: a connector with a table input cell must reference exactly
  // one table (across input cells + cell outputs) and bind a single input cell —
  // the per-row dispatch sends one variable per row, so a second table/cell is
  // silently dropped. Triggered by a valid input cell (mirrors the FE
  // requestMode==='table' on normalized stored data); a scalar connector that
  // writes a fixed cell output but has no table input is left untouched.
  if (cells.some(isValidCell)) {
    const tableKeys = new Set();
    cells.forEach((c) => { if (c && c.table_key) tableKeys.add(c.table_key); });
    outputs.forEach((o) => { if (o && o.to && o.to.mode === 'cell' && o.to.table_key) tableKeys.add(o.to.table_key); });
    if (tableKeys.size > 1) return 'All table cells must reference one table field.';
    // Count only column cells (not manual cells) toward the "only one table input column" limit
    const columnCells = cells.filter((c) => isValidCell(c) && c.column_key);
    if (columnCells.length > 1) return 'A table connector supports only one table input column.';
  }

  return null;
}

/**
 * A table_config JSON column's `.columns` array, tolerant of every untrusted
 * shape D1's review named (a driver that hands back the raw string instead
 * of an already-parsed object, `columns` absent/non-array, a `null`/scalar
 * element in the array). No cross-package import from `src/` exists (docker-
 * api has no dependency on the FE bundle) — this is a fresh, minimal read of
 * the same JSON, not a port of `parseTableFieldColumns`.
 *
 * @param {unknown} raw - one row's `table_config` column value
 * @returns {unknown[]}
 */
function parseTableConfigColumns(raw) {
  let cfg = raw;
  if (typeof cfg === 'string') {
    try { cfg = JSON.parse(cfg); } catch { return []; }
  }
  if (!cfg || typeof cfg !== 'object' || !Array.isArray(cfg.columns)) return [];
  return cfg.columns;
}

/**
 * True for a "simple" single implicit `value`-column table — no columns
 * configured, or exactly one column keyed `value` — the SAME decision the FE
 * twin `isSimpleTableField` (src/fmb/lib/table-field-rows.ts) makes off the
 * raw (unfiltered) columns array, so a tolerated-malformed `columns:[null]`
 * (one raw entry, not keyed `value`) agrees with the FE: NOT simple, no
 * implicit column (naming-rule.test.ts:303 pins the FE side of this nuance).
 *
 * @param {unknown} rawTableConfig
 * @returns {boolean}
 */
function isSimpleTableConfig(rawTableConfig) {
  const cols = parseTableConfigColumns(rawTableConfig);
  if (cols.length === 0) return true;
  if (cols.length !== 1) return false;
  const only = cols[0];
  return !!only && typeof only === 'object' && !Array.isArray(only) && String(only.key ?? '') === 'value';
}

/**
 * ONE extraction of a table field's resolved sink-column keys, shared by
 * every reader of `table_config.columns` that decides whether a Value→Field
 * output naming this key is a legitimate write-back-to-this-row target
 * (health.js's own-column fallback, `loadBlueprintFieldKeySets` below).
 *
 * String-coerces every key (H1 sharp: `typeof col.key === 'string'` silently
 * dropped an authored `{key: 5}` — a number that survives an authoring
 * round-trip without ever being stringified — producing a broken-no-op
 * instead of a match; `String(c.key ?? '')` is the SAME coercion
 * `loadFollowerColumnKeys` above already applies per-column for the same
 * reason). `loadFollowerColumnKeys` is NOT ported onto this helper — it
 * needs the raw column object to read `linked_source` and build a
 * `field_key::key` compound key, a different shape this Set cannot carry.
 *
 * Also resolves the implicit `value` column for a simple table (P2 Codex
 * round-1: `apply-connector-response.ts`'s `entry.size > 0 ? entry :
 * {'value'}` fallback is the same rule, re-derived here so the BE health
 * path grants the SAME write-back idiom without a duplicate predicate) — via
 * `isSimpleTableConfig` above, never a bare `keys.size === 0` check (that
 * would also implicit-value a malformed `columns:[null]` table, which the FE
 * twin explicitly does not).
 *
 * @param {unknown} tableConfig - one row's `table_config` column value (parsed object or raw string)
 * @returns {Set<string>}
 */
function tableSinkColumnKeys(tableConfig) {
  const keys = new Set();
  for (const c of parseTableConfigColumns(tableConfig)) {
    if (!c || typeof c !== 'object' || Array.isArray(c)) continue;
    const key = String(c.key ?? '');
    if (key) keys.add(key);
  }
  if (keys.size === 0 && isSimpleTableConfig(tableConfig)) keys.add('value');
  return keys;
}

/**
 * `${table_key}::${column_key}` for every follower column (Q9, `linked_source`
 * present) in one blueprint — the BE twin of the FE's `followerColumnKeys`
 * memo (ApiConnectorEditor.tsx). Reads on the SAME connection/pool the caller
 * passes (the write pool the request's write is about — a request may name a
 * Custom API connection via `db`, and asking the wrong database is exactly
 * the defect class `request-pool.js` exists to prevent), so callers pass
 * `pool.rw`, `await resolveRwPool(req)`, or an open transaction `conn` —
 * anything exposing `.query(sql, params)`.
 *
 * @param {{query:(sql:string, params:unknown[])=>Promise<unknown[]>}} queryable
 * @param {(name:string)=>string} t
 * @param {string} blueprintId
 * @returns {Promise<Set<string>>}
 */
async function loadFollowerColumnKeys(queryable, t, blueprintId) {
  const keys = new Set();
  if (!blueprintId) return keys;
  const { TABLES } = require('../../../../shared/constants');
  const rows = await queryable.query(
    `SELECT field_key, table_config FROM \`${t(TABLES.BLUEPRINT_FIELDS)}\` WHERE blueprint_id = ? AND field_type = 'table'`,
    [blueprintId],
  );
  for (const row of rows) {
    for (const c of parseTableConfigColumns(row.table_config)) {
      if (!c || typeof c !== 'object' || Array.isArray(c) || !c.linked_source) continue;
      // Coerced, not type-checked (Codex round-1 P2) — the same normalization
      // the FE's own single parse layer applies (table-column-options.ts
      // `parseTableFieldColumns`, F12: "key" is opaque DB JSON, and a
      // numeric-looking key (`key: 5` instead of `"5"`) survives an authoring
      // round-trip that never stringifies it). A `typeof c.key === 'string'`
      // check here left this guard blind to exactly the column the runtime
      // mirror sync (which reads through that FE layer) still overwrites.
      const key = String(c.key ?? '');
      if (!key) continue;
      keys.add(`${row.field_key}::${key}`);
    }
  }
  return keys;
}

/**
 * A DB-read `response_config` column, tolerant of the same parsed-object-or-
 * raw-string driver ambiguity `parseTableConfigColumns` above handles for
 * `table_config` — the follower-target guard below needs the object shape
 * (`.outputs`), never a string. Shared by every write path that re-reads a
 * STORED `response_config` to judge it (the CRUD PUT middleware's effective-
 * pair load in index.js, and clone's copy-forward guard) so the tolerance
 * lives in one place, not one private copy per caller.
 *
 * @param {unknown} value - one row's `response_config` column value
 * @returns {unknown}
 */
function parseResponseConfigForGuard(value) {
  if (value == null) return null;
  if (typeof value === 'object') return value;
  if (typeof value === 'string') {
    try { return JSON.parse(value); } catch { return null; }
  }
  return null;
}

// Generic alias: the tolerance above is column-agnostic (parsed-object-or-
// raw-string DB driver ambiguity), not response_config-specific — a caller
// reading `request_config` through the same shape (the CRUD PUT write-guard's
// effective-pair load in index.js) uses THIS name so the call site names what
// it actually parses instead of borrowing the response-config-specific one.
const parseJsonConfigForGuard = parseResponseConfigForGuard;

/**
 * Interaction guard, config-time (Q9/spec §6 item 3, D2 amendment A4): a
 * connector output may not target a follower column — its value is owned
 * entirely by the D2 mirror sync, which always runs after a connector apply
 * and overwrites whatever the connector just wrote. Messages byte-identical
 * to the FE twin (connector-save-guards.ts `validateNoFollowerColumnTarget`).
 *
 * @param {unknown} responseConfig - the connector's response_config (parsed object or null)
 * @param {Set<string>} followerColumnKeys - from `loadFollowerColumnKeys`
 * @returns {string|null}
 */
function validateNoFollowerColumnTarget(responseConfig, followerColumnKeys) {
  if (!followerColumnKeys || followerColumnKeys.size === 0) return null;
  const outputs = responseConfig && typeof responseConfig === 'object' && Array.isArray(responseConfig.outputs)
    ? responseConfig.outputs
    : [];
  for (const o of outputs) {
    if (!o || !o.to || typeof o.to !== 'object') continue;
    if (o.to.mode === 'cell' && typeof o.to.table_key === 'string' && typeof o.to.column_key === 'string') {
      if (followerColumnKeys.has(`${o.to.table_key}::${o.to.column_key}`)) {
        return 'This output targets a column that mirrors another table and cannot be a connector target.';
      }
    } else if (o.to.mode === 'rows' && typeof o.to.table_key === 'string' && Array.isArray(o.to.columns)) {
      const hit = o.to.columns.find(
        (c) => c && typeof c.column_key === 'string' && followerColumnKeys.has(`${o.to.table_key}::${c.column_key}`),
      );
      if (hit) return `Column "${hit.column_key}" mirrors another table and cannot be a connector target.`;
    }
  }
  return null;
}

/**
 * Every field_key (scalar + table) per blueprint, for a set of blueprint ids —
 * the twin of health.js's inline load, extracted so the bindings completeness
 * check and health agree on one query shape. Reads on the caller's queryable
 * (the write pool the request's write is about; same reasoning as
 * loadFollowerColumnKeys), so callers pass an open transaction `conn`,
 * `pool.rw`, or `await resolveRwPool(req)`.
 *
 * Also returns each table field's own column keys (HEALTH-2181: the
 * own-column fallback source for `computeConnectorHealth` — a Value→Field
 * sink naming a column of the connector's own bound table is a legitimate
 * write-back-to-this-row target). Reuses this SAME query (adds `field_type`
 * + `table_config` to the SELECT) rather than a second round-trip.
 *
 * @param {{query:(sql:string, params:unknown[])=>Promise<unknown[]>}} queryable
 * @param {(name:string)=>string} t
 * @param {string[]} blueprintIds
 * @returns {Promise<{ fieldKeys: Map<string, Set<string>>, tableColumns: Map<string, Map<string, Set<string>>> }>}
 */
async function loadBlueprintFieldKeySets(queryable, t, blueprintIds) {
  const fieldKeys = new Map();
  const tableColumns = new Map();
  const ids = [...new Set((blueprintIds || []).filter((id) => typeof id === 'string' && id))];
  if (ids.length === 0) return { fieldKeys, tableColumns };
  const { TABLES } = require('../../../../shared/constants');
  const rows = await queryable.query(
    `SELECT blueprint_id, field_key, field_type, table_config FROM \`${t(TABLES.BLUEPRINT_FIELDS)}\`
      WHERE blueprint_id IN (${ids.map(() => '?').join(', ')})`,
    ids,
  );
  for (const row of rows) {
    let set = fieldKeys.get(row.blueprint_id);
    if (!set) { set = new Set(); fieldKeys.set(row.blueprint_id, set); }
    if (row.field_key) set.add(row.field_key);
    // table_config.columns is only a live column source for a field_type:
    // 'table' row (mirrors health.js's own guard for the same reason).
    if (row.field_type !== 'table') continue;
    let colByTable = tableColumns.get(row.blueprint_id);
    if (!colByTable) { colByTable = new Map(); tableColumns.set(row.blueprint_id, colByTable); }
    colByTable.set(row.field_key, tableSinkColumnKeys(row.table_config));
  }
  return { fieldKeys, tableColumns };
}

module.exports = {
  validateInputFromStep, validateResponseOutputs, validateInputCells, validateConnectorCoherence, normalizeRowMatch, FILTER_OPS,
  loadFollowerColumnKeys, validateNoFollowerColumnTarget, parseResponseConfigForGuard, parseJsonConfigForGuard,
  loadBlueprintFieldKeySets, tableSinkColumnKeys,
};
