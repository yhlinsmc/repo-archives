/**
 * capacity/index.js — Capacity Planner router assembly (spec §7 / §9.2).
 *
 * Mounted at /edge/app/capacity (see index-edge.js) and reached from the
 * frontend via /api/app/capacity (infra forwarding proxy). Composition:
 *
 *   /config/{group}                         → config.js  (template rows,
 *                                              scenario_id IS NULL; admin+editor)
 *   /config/{group}/propagation-{preview,apply} → catalogue-propagation.js (E4,
 *                                              spec §7 E4 / Q12: stale-VM-sizing
 *                                              detection + batch apply; admin+
 *                                              editor, apply also owner+admin per
 *                                              scenario)
 *   /config/bundles (+ /:id/items)          → bundles.js (global bundle
 *                                              templates, §7; admin+editor)
 *   /scenarios/:id/local-catalogues/{cat}    → local-catalogues.js (scenario-local
 *                                              catalogue additions §2.4; owner+admin)
 *   /scenarios/:scenarioId/{export,import}   → io.js (snapshot-shaped export;
 * validate/commit import)
 *   /scenarios/wizard                        → wizard.js (setup-wizard bulk
 *                                              scenario create, R3 §15)
 *   /scenarios/:scenarioId/sites/reorder     → sites-reorder.js (bulk
 *                                              order_index rewrite, owner+admin,
 *                                              phase-2 spec §4.3 B2)
 *   /scenarios/:scenarioId/violations       → violations.js (computed rule
 *                                              violations, read-only, all authenticated)
 *   /scenarios/:scenarioId/settings         → settings.js (singleton row,
 *                                              owner+admin; GET/PUT only)
 *   /scenarios/:scenarioId/{entity}         → children.js (scenario-scoped CRUD,
 *                                              owner+admin via parentOwnership)
 *   /scenarios                              → scenarios.js (CRUD + deep-copy POST)
 *
 * Child mounts (violations + settings + children) are registered before
 * /scenarios so the nested paths are matched ahead of the scenario factory's
 * own routes.
 */
const express = require('express');
const configRouter = require('./config');
const configImportRouter = require('./config-import');
const bundlesRouter = require('./bundles');
const catalogueReorderRouter = require('./catalogue-reorder');
const { router: cataloguePropagationRouter } = require('./catalogue-propagation');
const scenariosRouter = require('./scenarios');
const settingsRouter = require('./settings');
const versionsRouter = require('./versions');
const ioRouter = require('./io');
const wizardRouter = require('./wizard');
const sitesReorderRouter = require('./sites-reorder');
const reorderRouter = require('./reorder');
const renumberRouter = require('./renumber');
const placementApplyRouter = require('./placement-apply');
const deletePreviewRouter = require('./delete-preview');
const databaseBulkCreateRouter = require('./database-bulk-create');
const { mountChildren } = require('./children');
const { mountViolations } = require('./violations');
const { mountCatalogueReads } = require('./catalogue-reads');
const { mountLocalCatalogues } = require('./local-catalogues');

const router = express.Router();

// Fail-closed delete-impact previews (spec §10): /scenarios/:id/delete-preview,
// /scenarios/:scenarioId/:segment/:id/delete-preview (T3, per-child) and
// /config/:group/:id/delete-preview. Registered FIRST so its /config/:group/:id
// path wins over the generic /config catalogue router's /:group/:id, the
// scenario-level /scenarios/:id/delete-preview wins over the scenario factory,
// and the per-child /delete-preview wins over the generic children mount below
// (its five-segment path does not clash with the child factory's /:id, and the
// /delete-preview suffix shadows no real endpoint). Read-only (ro pool).
router.use('/', deletePreviewRouter);

// Bundles (global config templates, spec §7) mount on the more-specific
// /config/bundles prefix BEFORE the generic /config catalogue router so a
// /config/bundles* path is served here, not by config.js's /:group loop.
router.use('/config/bundles', bundlesRouter);
// catalogue-reorder.js (phase-6 spec §D3 global-catalogue order_index rewrite for
// hardware_specs / disk_combos / teams / vm_profiles) mounts BEFORE the generic
// /config catalogue router so a /config/<group>/reorder path wins over config.js's
// own PUT /:group/:id (which would otherwise treat "reorder" as a row id).
router.use('/config', catalogueReorderRouter);
// catalogue-propagation.js (E4, spec §7 E4 / Q12: /config/<group>/propagation-preview
// GET + /propagation-apply POST) mounts BEFORE the generic /config catalogue router
// for the same reason as catalogue-reorder.js above — "propagation-preview" and
// "propagation-apply" must not be read as a row id by config.js's own /:group/:id.
router.use('/config', cataloguePropagationRouter);
// The gated first-instance config import (/config/import/{validate,commit}) mounts
// before the generic /config catalogue router; 'import' is not a catalogue group,
// so there is no path clash, but the specific mount is declared first for clarity.
router.use('/config', configImportRouter);
router.use('/config', configRouter);
// The read-only violations endpoint is registered before the child and
// scenario mounts so its two-segment path (/scenarios/:id/violations) wins over
// the scenario factory's /:id route.
mountViolations(router);
// Read-only global-or-same-scenario catalogue reads (reference model): the
// two-segment /scenarios/:id/{specs,profiles} paths are registered before the
// generic child + scenario mounts so they win over the scenario factory's /:id.
mountCatalogueReads(router);
// reorder.js (phase-4 spec §6 bulk order_index rewrite for Hypervisors / KVMs /
// DB Instances + the scenario-LOCAL Hardware Specs catalogue) registered BEFORE
// the local-catalogue + child + scenario mounts so its three-/four-segment
// /scenarios/:id/<entity>/reorder paths win over those factories' own PUT /:id
// (which would otherwise treat "reorder" as a row id).
router.use('/', reorderRouter);
// renumber.js (spec B5b) — POST /scenarios/:id/renumber-preview and /renumber,
// registered before the generic child + scenario mounts so its two-segment paths
// are not shadowed by the scenario factory's own /:id routes.
router.use('/', renumberRouter);
// Scenario-local catalogue write mounts (spec §2.4) — two-segment
// /scenarios/:id/local-catalogues/<catalogue> paths, registered before the
// generic child + scenario mounts so they win over the scenario factory's /:id.
mountLocalCatalogues(router);
router.use('/', settingsRouter);
// versions.js (bespoke, server-computed snapshots + clone) is registered before
// the generic child + scenario mounts so its /scenarios/:id/versions* paths win.
router.use('/', versionsRouter);
// io.js (bespoke import/export) registered before the generic child + scenario
// mounts so its two-segment /scenarios/:id/{export,import} paths win.
router.use('/', ioRouter);
// wizard.js (bespoke bulk scenario create) registered before the generic child +
// scenario mounts so /scenarios/wizard is not shadowed by the scenario factory.
router.use('/', wizardRouter);
// sites-reorder.js (bespoke bulk order_index rewrite, spec §4.3 B2) registered
// before the generic child + scenario mounts so its three-segment
// /scenarios/:id/sites/reorder path wins over the sites factory's own PUT /:id
// (which would otherwise treat "reorder" as a row id).
router.use('/', sitesReorderRouter);
// placement-apply.js (bespoke batch staged-placement persist, spec §4.4)
// registered before the generic child + scenario mounts so its three-segment
// /scenarios/:id/placement/apply path is not shadowed by the scenario factory.
router.use('/', placementApplyRouter);
// database-bulk-create.js (Add-Database wizard's transactional persist, spec §3/
// §11) registered before the generic child mount so its three-segment
// /scenarios/:scenarioId/databases/bulk-create path wins over the databases child
// factory's POST /databases (which would otherwise treat "bulk-create" as a row
// id on a GET-by-id, and never reaches a POST body at all).
router.use('/', databaseBulkCreateRouter);
mountChildren(router);
router.use('/scenarios', scenariosRouter);

module.exports = router;
