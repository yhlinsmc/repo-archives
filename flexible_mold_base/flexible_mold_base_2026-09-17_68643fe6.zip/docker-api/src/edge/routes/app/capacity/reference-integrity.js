/**
 * capacity/reference-integrity.js — the §17.1a shared reference-integrity write
 * validator.
 *
 * INVARIANT: every catalogue-FK write path must run this SAME check (spec
 * §17.1a) — a divergent copy would let the paths disagree on what a legal
 * reference is. A nullable `scenario_id` + a plain FK cannot stop a scenario
 * row from referencing ANOTHER scenario's local catalogue row, nor a global
 * bundle from referencing a scenario-local row.
 * This closes that gap at the WRITE side (a 400 gate), never at eval time — it
 * is orthogonal to the never-block invariant (that is about the evaluator's
 * markers; this is about referential integrity of a write).
 *
 * The three reference modes (spec §17.1a):
 *   'catalogue' — a scenario-scoped row's catalogue FK (cap_hypervisors.spec_id,
 *                 cap_vms.{sizing_profile_id,disk_combo_id,team_id},
 *                 cap_databases.{profile_id,disk_combo_id,team_id}, …): the
 *                 referenced row must be GLOBAL (scenario_id IS NULL) OR owned by
 *                 the SAME scenario. A different scenario's local row → reject.
 *   'scenario'  — a scenario-internal placement FK (cap_db_instances.vm_id,
 *                 cap_vms.database_id, cap_vms.hypervisor_id, cap_vms.site_id):
 *                 the referenced row must belong to the SAME scenario (a global
 *                 row is NOT valid here — these are scenario-internal objects).
 *   'global'    — a GLOBAL bundle / bundle-item FK (cap_bundle_items.profile_id,
 *                 disk_combo_id, team_id): the referenced row must be GLOBAL
 *                 (scenario_id IS NULL) — a bundle is global config and cannot
 *                 reference any scenario-local row.
 *   'global-row' — a scenario override row's overrides_rule_id
 *                 (cap_rules.overrides_rule_id): the referenced TARGET rule must
 *                 be a GLOBAL template rule (scenario_id IS NULL) — an override
 *                 re-parameterises a global rule, never a scenario-local one
 *                 (spec §13.4 / §17.1). Same predicate as 'global', distinct
 *                 rejection message.
 *
 * `requireVmType` layers a parent-type check on top of a 'scenario' ref (the
 * cap_db_instances.vm_id → db_host VM guard, precedent).
 */
'use strict';

const { t } = require('../../../db');
const { identifierFloorViolation } = require('../schema/identifier-floor');

/**
 * Canonical table-ordering comparator for the FOR-UPDATE lock protocol. Every
 * commit path that locks catalogue rows (checkReferences lock mode below, AND
 * io.js lockReferencedGlobals for the import commit) MUST acquire per-table locks
 * in THIS same order, so two concurrent lockers can never form a circular wait
 * (InnoDB deadlock). Compares the LOGICAL table name (the TABLES constant value);
 * the physical prefix is uniform so logical order == physical order. Single source
 * of truth — do not inline a second table comparator anywhere.
 */
function compareCatalogueTable(a, b) {
  if (a === b) return 0;
  return String(a) < String(b) ? -1 : 1;
}

// The alias `checkReferences` projects the engine's own "is this row in the
// referencing scenario" verdict under. Named once so the predicate below and
// the statement that answers it cannot drift apart.
const SAME_SCENARIO_COLUMN = 'same_scenario';

/**
 * PURE predicate over an already-fetched referenced row. No I/O — unit-testable
 * in isolation. A row is "global" when its scenario_id is null/undefined.
 *
 * IT NO LONGER DECIDES WHETHER TWO SCENARIO IDS ARE THE SAME, and that is the
 * point rather than a simplification. `scenario_id` is `CHAR(36)` under a
 * case-folding collation, so `String(owner) === String(referencingScenarioId)`
 * was a third, narrower opinion about scenario identity than the two SQL
 * predicates on either side of it — and the one that refused a sibling
 * reference to a row every `WHERE scenario_id = ?` in the system resolves. The
 * verdict now arrives ON THE ROW, computed by the same engine that will answer
 * every later question about it.
 *
 * FAIL-CLOSED WHEN THE VERDICT IS ABSENT: a caller that fetched a row without
 * projecting the column gets `undefined`, which reads as "not the same
 * scenario" — a scenario-mode reference is refused and a catalogue-mode one
 * falls back to "global rows only". Neither direction admits a cross-scenario
 * reference.
 *
 * @param {{scenario_id?: string|null, same_scenario?: number|null}|null|undefined} row
 *   the referenced row, or null if not found
 * @param {object} opts
 * @param {'catalogue'|'scenario'|'global'|'global-row'} [opts.mode='catalogue']
 * @returns {boolean} whether the reference is allowed
 */
function referenceOk(row, { mode = 'catalogue' } = {}) {
  if (!row) return false; // missing reference → always reject
  const owner = row.scenario_id;
  const isGlobal = owner === null || owner === undefined;
  if (mode === 'global' || mode === 'global-row') return isGlobal;
  const sameScenario = Number(row[SAME_SCENARIO_COLUMN]) === 1;
  if (mode === 'scenario') {
    return !isGlobal && sameScenario;
  }
  // 'catalogue': a global row is fine, else it must be the same scenario.
  return isGlobal || sameScenario;
}

/**
 * Human-readable rejection message per mode (kept out of referenceOk so the
 * predicate stays a pure boolean).
 */
function messageForMode(column, mode) {
  if (mode === 'global-row') {
    return `${column} must reference a global template rule (an override targets a global rule, not a scenario-local one)`;
  }
  if (mode === 'global') {
    return `${column} must reference a global catalogue row (a bundle cannot reference a scenario-local row)`;
  }
  if (mode === 'scenario') {
    return `${column} does not reference a row in this scenario`;
  }
  return `${column} must reference a global or same-scenario catalogue row`;
}

/**
 * The key a canonical id is filed under: the table the reference points into and
 * the spelling the caller asked with. Not the column — one statement can carry
 * two references to the same table (a wizard payload has a `spec_id` per
 * hypervisor), and a caller rebinding by column alone would give them all one
 * answer.
 */
const canonicalKey = (table, value) => `${table}\u0000${String(value)}`;

/**
 * Validate a set of reference specs against `dbHandle` (a pool.rw / pool.ro
 * handle or a transaction connection). Each spec:
 *   { column, value, table, mode?, requireVmType? }
 * A null/undefined value is a legitimate "unset" nullable FK and is skipped.
 * Returns `{ ok: true, canonical }` or the FIRST failure
 * `{ ok:false, column, code, message }`.
 *
 * WHAT `canonical` IS FOR, AND WHY IT IS THIS FUNCTION'S JOB. Every FK column
 * here is `CHAR(36)` under a case-folding collation, so `WHERE id = ?` resolves
 * the referenced row for ANY spelling of its id — which is what makes this check
 * pass for a spelling the row does not hold. Answering "yes, that reference is
 * legal" and letting the caller go on to bind its own spelling is only half an
 * identity check, and it is the half that hides the other: the statement stores
 * a value the column resolves and no JavaScript reader does. `.find(n => n.id
 * === row.spec_id)` in the front end, a Map keyed on the stored id, the sizing
 * hydration two lines later — none of them resolve it, while every SQL reader
 * still does, so nothing reports a problem.
 *
 * This is the one place every catalogue-FK write path meets (the wizard, the
 * child mounts, bundles, placement), and it has already read the row. So it
 * hands back the STORED id per (table, requested spelling) and the callers bind
 * that. `canonicalKey` builds the key; a caller that ignores the map is
 * byte-identical to before.
 * Fetches only the columns the check needs (scenario_id always; vm_type only
 * for a requireVmType spec — vm_type exists only on cap_vms).
 *
 * @param {{query: Function}} dbHandle
 * @param {string|undefined} referencingScenarioId
 * @param {Array<{column:string,value:any,table:string,mode?:string,requireVmType?:string}>} specs
 * @param {object} [opts]
 * @param {boolean} [opts.lock=false]  when true, probe each referenced row
 *   `FOR UPDATE` so a concurrent DELETE of that row cannot commit between this
 *   check and the caller's own INSERT/UPDATE, for callers with no DB-level FK
 *   to fall back on. Only meaningful when `dbHandle` is a transaction
 *   connection.
 */
async function checkReferences(dbHandle, referencingScenarioId, specs, { lock = false } = {}) {
  // On the LOCK path, probe in a canonical (table, then value) order so concurrent
  // writers acquire the FOR-UPDATE locks in the SAME sequence — two creates
  // locking the same catalogue rows in different orders can otherwise deadlock.
  // The spec order is caller-/payload-dependent (wizard.js collectCatalogueSpecs
  // walks hypervisors→databases→vms; bundles.js walks its item FK list), so the
  // sort here is the single shared fix for every locking caller. Because the lock
  // path must hold ALL the row locks anyway, it probes every spec and reports the
  // FIRST-DECLARED failing reference (lowest original index) so the surfaced
  // column is stable across the sort. The read path (no lock, no deadlock risk)
  // keeps the caller's order and short-circuits on the first failure exactly as
  // before. A null value is a cleared nullable FK and is skipped.
  const indexed = specs.map((spec, index) => ({ spec, index }));
  const probeOrder = lock
    ? [...indexed].sort((a, b) => {
        const tcmp = compareCatalogueTable(a.spec.table, b.spec.table);
        if (tcmp !== 0) return tcmp;
        const av = String(a.spec.value);
        const bv = String(b.spec.value);
        if (av !== bv) return av < bv ? -1 : 1;
        return a.index - b.index;
      })
    : indexed;

  let firstFailure = null; // { index, result } — the lowest-original-index failure
  const canonical = new Map();
  for (const { spec, index } of probeOrder) {
    const { column, value, table, mode = 'catalogue', requireVmType } = spec;
    if (value == null) continue;
    // THE IDENTIFIER FLOOR, HERE BECAUSE THIS IS WHERE EVERY FK PATH MEETS.
    // MariaDB compares a CHAR column against a NUMBER in numeric context, so
    // `WHERE id = 0` converts the column side with leading-digit semantics and
    // matches every id starting `0` or `a`–`f` — measured, about 44% of a uuid
    // table. A numeric FK therefore took its reference-legality answer from an
    // ARBITRARY catalogue row, and for the ordinary case (a global row) the
    // answer is "allowed", while the statement went on to store the literal `0`
    // — a value nothing can ever resolve. `findCatalogueReferenceBlocker` never
    // sees it either (string against string), so the row it "referenced" stays
    // deletable, and the scenario health read counts it as a broken reference.
    //
    // Refused BEFORE the probe rather than after it, because the probe is the
    // thing that misbehaves. The three write paths that reach here — the
    // wizard, the child mounts and bundles — each had no shape check of their
    // own; a floor at any one of them would have left the other two.
    const floorViolation = identifierFloorViolation([column], { [column]: value });
    if (floorViolation) {
      const result = {
        ok: false, column, code: floorViolation.code, message: floorViolation.message,
      };
      if (!lock) return result;
      if (firstFailure === null || index < firstFailure.index) firstFailure = { index, result };
      continue;
    }
    // Select `id` first so the probe SQL is distinguishable from the PUT
    // row-scenario binding's `SELECT scenario_id ... WHERE id = ?` (the predicate
    // only reads scenario_id / vm_type; id is along for disambiguation).
    const selectCols = requireVmType ? 'id, scenario_id, vm_type' : 'id, scenario_id';
    // The scope comparison rides along as a projected column so the ENGINE
    // decides whether the referenced row is in the referencing scenario, under
    // the same collation as every `WHERE scenario_id = ?` that will read it
    // later. `=` rather than `<=>` deliberately: a NULL on either side yields
    // NULL, which is not 1, and "this row is global" is a separate question
    // `referenceOk` answers from `scenario_id` itself.
    const rows = await dbHandle.query(
      `SELECT ${selectCols}, (scenario_id = ?) AS ${SAME_SCENARIO_COLUMN}
         FROM \`${t(table)}\` WHERE id = ?${lock ? ' FOR UPDATE' : ''}`,
      [referencingScenarioId === undefined ? null : referencingScenarioId, value],
    );
    const row = rows[0] || null;
    let result = null;
    if (!referenceOk(row, { mode })) {
      result = { ok: false, column, code: 'INVALID_REFERENCE', message: messageForMode(column, mode) };
    } else if (requireVmType && row.vm_type !== requireVmType) {
      result = { ok: false, column, code: 'INVALID_PARENT_TYPE', message: `${column} must reference a ${requireVmType} VM` };
    }
    if (result) {
      if (!lock) return result; // read path: original early-return on first failure
      if (firstFailure === null || index < firstFailure.index) firstFailure = { index, result };
    } else if (row && row.id != null) {
      // The row this reference really names, under the column's own collation.
      // Recorded only for a reference that PASSED: a rejected one is not a
      // value any statement goes on to bind.
      canonical.set(canonicalKey(table, value), row.id);
    }
  }
  return firstFailure ? firstFailure.result : { ok: true, canonical };
}

module.exports = {
  referenceOk,
  messageForMode,
  checkReferences,
  compareCatalogueTable,
  canonicalKey,
};
