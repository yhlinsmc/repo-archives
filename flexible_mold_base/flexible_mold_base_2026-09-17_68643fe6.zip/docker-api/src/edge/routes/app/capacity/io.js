/**
 * @openapi
 * /edge/app/capacity/scenarios/{scenarioId}/export:
 *   get:
 *     tags: [App - Capacity]
 *     summary: Export a scenario as a snapshot-shaped projection (all authenticated).
 *     description: >
 *       Returns the same `{ schema_rev, tables }` document a version freeze
 *       produces, computed from the scenario's live rows PLUS the referenced
 *       global-catalogue closure (§17.4). The frontend maps the id-keyed rows to
 *       a name-keyed workbook (xlsx/CSV); this endpoint itself is format-agnostic
 *       JSON.
 *     parameters:
 *       - { name: scenarioId, in: path, required: true, schema: { type: string } }
 *     responses:
 *       200: { description: The scenario snapshot projection }
 * /edge/app/capacity/scenarios/{scenarioId}/import:
 *   post:
 *     tags: [App - Capacity]
 *     summary: Validate or commit a name-keyed sheet import into a scenario (owner+admin).
 *     description: >
 *       `mode:'validate'` returns a structural validation report and writes
 *       nothing. `mode:'commit'` re-validates and, only when the report is clean,
 *       REPLACES every content row of the scenario in one transaction. ANY
 *       structural error aborts the commit (422 + report, nothing written).
 *       Rule violations NEVER fail an import — the report is structural only.
 *       Catalogue references resolve ref-first then name-fallback against the
 *       existing global catalogues; an unmatched closure row is created
 *       scenario-local, never global (§17.4). A global-config sheet in the upload
 *       (bundles / bundle_items / field_defs) is reported as an ignored notice —
 *       config import is out of scope (§19).
 *     parameters:
 *       - { name: scenarioId, in: path, required: true, schema: { type: string } }
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [mode, sheets]
 *             properties:
 *               mode: { type: string, enum: [validate, commit] }
 *               sheets: { type: object }
 *     responses:
 *       200: { description: Validation report (validate) or commit result }
 *       403: { description: Not the scenario owner (and not admin) }
 *       404: { description: Scenario not found }
 *       413: { description: Import payload exceeds the size cap }
 *       422: { description: Commit rejected — structural errors, nothing written }
 */

/**
 * capacity/io.js — Import / Export (config-rewrite §17.4, spec §6).
 *
 * ARCHITECTURE (browser-side parse): the xlsx/CSV file never touches the
 * backend. The frontend parses a workbook into name-keyed JSON rows and posts
 * them here; this module validates them (name→id resolution, duplicates,
 * structural checks), and on commit REPLACES the scenario's content in one
 * all-or-nothing transaction. Export is the inverse: this returns the live
 * scenario as a snapshot-shaped projection (own rows + the referenced global
 * closure) and the frontend builds the workbook.
 *
 * REFERENCE MODEL round-trip (§17.4): a scenario import is scenario-scoped. Each
 * catalogue reference (hardware spec / disk combo / team / VM profile / an
 * overridden global rule) resolves ref-first, then name-fallback, against the
 * EXISTING global catalogues; any closure row that matches nothing is created as
 * a SCENARIO-LOCAL row (`scenario_id` = the importing scenario), NEVER as a new
 * global row (config import is out of scope, §19). This keeps the §17.1a
 * reference-integrity contract satisfied — every imported reference ends up
 * either global or scenario-owned — and lets export→import reproduce a scenario
 * on a wiped/different target with no unresolved FKs. `cap_versions` is history,
 * never touched by an import.
 *
 * SHEET_SPECS MIRROR: this registry is mirrored column-for-column in the FE
 * (`src/fmb/capacity/lib/xlsx-io.ts`). A change here MUST land in both, with the
 * paired column-set tests updated (BE: capacity-io.test.js; FE: xlsx-io.test.ts).
 *
 * NEVER-BLOCK (spec §1.2): a rule violation can never fail an import. The
 * validation report covers STRUCTURAL problems ONLY — malformed rows, unresolved
 * name references (0 or ≥2 matches), duplicate names, bad enums/numbers/JSON. A
 * rule-violating placement imports cleanly.
 */
const express = require('express');
const { sendError } = require('../../../../shared/lib/send-error');
const { pool, t } = require('../../../db');
const {
  requireAuth, requireAdminOrEditor, apiOk, uuidv4,
} = require('../../../../shared/helpers');
const { logger } = require('../../../../shared/lib/logger');
const { TABLES } = require('../../../../shared/constants');
const { objectSetKey } = require('../../../../shared/capacity/evaluator');
const { floorGb } = require('../../../../shared/capacity/whole-numbers');
const { RULE_TYPES, RELATIONAL_GROUP_BYS } = require('../../../../shared/capacity/rule-types');
const {
  TOPOLOGY, TOPOLOGY_VALUES, BUNDLE_ITEM_TOPOLOGIES, normalizeLegacyTopology,
} = require('../../../../shared/capacity/topology');
const { compareCatalogueTable } = require('./reference-integrity');
const { buildSchemaManifest } = require('../../../lib/schema-manifest');
// F4: reuse the SAME RAC node-count domain the write paths (wizard.js /
// database-bulk-create.js) already enforce, rather than a fourth hand-copied
// [min, max] pair.
const { RAC_MIN_NODES, RAC_MAX_NODES, isPositiveInt } = require('./wizard');
const {
  SNAPSHOT_TABLES, buildScenarioSnapshotDoc, resolveScenarioWriteAccess, safeRollback,
  validateRuleWritePayload, validateGroupMemberXor, RESERVED_META_KEYS, diskComboAllowed,
  CONFIG_MOUNTS, syncVmSiteCache, dropAbsentColumns, sitesMetadataPlacementLayoutError,
  MAX_VM_FUNCTION_NAME, VM_FUNCTION_NAME_RE, VM_FUNCTION_NAME_CHARSET_MSG, VM_FUNCTION_DB_HOST_MSG,
  DATABASE_FUNCTION_NAME_IMPORT_RE,
  isRenamedTopologySchemaSupported, TOPOLOGY_SCHEMA_UNSUPPORTED_MSG,
} = require('./_shared');

const router = express.Router();

// Import payload cap (versions.js SNAPSHOT_MAX_BYTES precedent). At the design
// scale ceiling (~250 objects, spec §8) a full sheet set is a few hundred KB; 4
// MB is a generous DoS backstop. The global edge body parser accepts up to 10
// MB, so this guard is the one that trips first for a 4–10 MB payload.
const MAX_IMPORT_BYTES = 4 * 1024 * 1024;

// Per-sheet row cap (structural error, not a 500). A single adversarial sheet
// with millions of rows would make the O(rows) validate/resolve passes and the
// per-row INSERT loop pathological even under the 4 MB byte cap. 10,000 rows sits
// comfortably above the wizard's own generation ceilings (hv 500 / vm 2000 / db
// 500 / instance 4000, §8) so a legal full-scale export is never rejected.
const MAX_ROWS_PER_SHEET = 10000;

// Server-managed columns tolerated (silently ignored) if a lightly-edited
// export file still carries them — they are never taken from the client.
const SERVER_MANAGED_COLUMNS = new Set(['id', 'scenario_id', 'created_at', 'updated_at']);

// RESERVED_META_KEYS (imported from _shared.js — the single source shared with the
// child-CRUD / config / wizard metadata guard) blocks JS prototype-accessor keys:
// via the `metadata[key] = value` build below such a key would pollute
// Object.prototype instead of setting an own property. The accumulator is also built
// with a null prototype; rejecting the key outright is the reject-at-the-source half.

// A subject of a rule violation (and therefore of an Exception's object set) is
// any of these entity kinds — object_names resolve against their combined name
// space (spec §3.3 / evaluator emit sites).
const WAIVER_SUBJECT_KEYS = Object.freeze(['sites', 'hardware_specs', 'hypervisors', 'vms', 'db_instances']);

// The subset of the settings columns the DDL declares JSON: compared as
// canonical text rather than by value, because the driver hands one back as an
// object or as a string depending on how it was written.
// (SETTINGS_VALUE_COLS itself is derived below, once the sheet specs exist.)
const SETTINGS_JSON_COLS = new Set(CONFIG_MOUNTS.settings.json);

// WHOLE_NUMBER_IMPORT_RULE — `spec.integers` names the columns that
// hold a whole number: a derived capacity quantity (the memory a profile sizes a
// VM to, an SGA cap, a per-instance SGA). A fraction in one of those cells is
// FLOORED and the report carries a notice naming the row, the column and both
// values. It is never a hard error here.
//
// The GRID refuses the same fraction with a 400. The asymmetry is deliberate,
// not an oversight: the two surfaces differ in who authored the number and in
// what the operator can do about it.
//   - A grid cell is a number the operator is typing right now, one field at a
//     time, with the offending cell in front of them — refusing it teaches the
//     rule at the moment it is broken and costs one keystroke.
//   - An import is all-or-nothing over a whole workbook, and these columns are
//     ones the APP derived and wrote. Refusing them would mean this release
//     cannot import the workbook the previous release exported (a custom profile
//     frozen at mem_gb 61.5), with a fresh instance's config import — the only
//     supported bootstrap — as the casualty. The operator did not author the
//     fraction and has nothing to correct.
// Floor-and-report keeps the file loadable while leaving a record, so nothing is
// changed silently.
const WHOLE_NUMBER_NOTICE_CODE = 'FLOORED_TO_WHOLE';

// databases.function_name charset notice code — see the `databases`
// spec's `databaseFunctionNameCharsetNotice` comment for why the measured
// legacy (underscore) shape is a notice, never a `push` error. One aggregate
// notice per sheet (a count, not one per row) so a workbook with many legacy
// rows does not bury the report in repeats of the identical fact; no raw
// function_name value is named in the message, matching the vms sheet's own
// charset message (VM_FUNCTION_NAME_CHARSET_MSG), which likewise names no
// value.
const DATABASE_FUNCTION_NAME_CHARSET_NOTICE_CODE = 'LEGACY_FUNCTION_NAME_CHARSET';
// A databases-sheet function_name outside even DATABASE_FUNCTION_NAME_IMPORT_RE
// (the measured legacy shape) IS a blocking structural error — same shape as
// the vms sheet's VM_FUNCTION_NAME_CHARSET_MSG, widened by one word to name the
// extra character this sheet also tolerates.
const DATABASE_FUNCTION_NAME_IMPORT_CHARSET_MSG = 'function_name may only contain letters, digits, hyphens and underscores';

/**
 * Per-sheet import contract. Scenario sheets are processed by buildImportPlan in
 * SNAPSHOT_TABLES parent-before-child order (so a commit inserts parents first);
 * the config-only sheets (field_defs / bundles / bundle_items) are exportable but
 * NOT scenario-importable (config import is out of scope, §19). Each spec:
 *   nameCol    — the display-name column (used for FK-by-name resolution).
 *   required   — columns that must be present + non-empty.
 *   strings    — free-text columns (stored as-is).
 *   enums      — { col: [legal values] } (case-sensitive, DDL-canonical).
 *   numbers    — numeric columns (number or numeric string).
 *   integers   — the WHOLE-NUMBER subset of `numbers` (WHOLE_NUMBER_IMPORT_RULE).
 *   booleans   — boolean columns (bool / 0|1 / 'true'|'false').
 *   jsonCols   — JSON columns (object or JSON string).
 *   hasMetadata— accepts `cf:<key>` columns folded into metadata JSON.
 *   fk         — { fileCol: { idCol, target, nullable?, requireVmType?, refCol,
 *                  globalRow? } } name→id. `globalRow` means the resolved target
 *                  must be a global-matched row (an override targets a global
 *                  rule only, §17.1a mode 'global-row').
 *   catalogue  — a global catalogue sheet: each row resolves to an existing
 *                global row (ref-first, name-fallback) or is created
 *                scenario-local when unmatched (§17.4).
 *   inScenario — appears in the scenario snapshot / import (SNAPSHOT_TABLES).
 *   inConfig   — appears in the global config export.
 */
const SHEET_SPECS = Object.freeze([
  // ── Catalogues (global; scenario-local when unmatched on import) ──
  {
    key: 'hardware_specs', table: TABLES.CAP_HARDWARE_SPECS, nameCol: 'name', resolvable: true,
    catalogue: true, inScenario: true, inConfig: true,
    required: ['name'], strings: ['name'], enums: {},
    numbers: ['cpu_total', 'mem_total_gb', 'disk_total_gb', 'cpu_reserved', 'mem_reserved_pct', 'disk_reserved_gb'],
    booleans: [], jsonCols: ['metadata'], hasMetadata: true, fk: {},
  },
  {
    key: 'disk_combos', table: TABLES.CAP_DISK_COMBOS, nameCol: 'name', resolvable: true,
    catalogue: true, inScenario: true, inConfig: true,
    required: ['name'], strings: ['name'], enums: {},
    numbers: [], booleans: [], jsonCols: ['sizes'], hasMetadata: false, fk: {},
  },
  {
    key: 'teams', table: TABLES.CAP_TEAMS, nameCol: 'name', resolvable: true,
    catalogue: true, inScenario: true, inConfig: true,
    required: ['name'], strings: ['name', 'color'], enums: {},
    numbers: [], booleans: [], jsonCols: [], hasMetadata: false, fk: {},
  },
  {
    key: 'vm_profiles', table: TABLES.CAP_VM_PROFILES, nameCol: 'name', resolvable: true,
    catalogue: true, inScenario: true, inConfig: true,
    required: ['class', 'name'], strings: ['name'],
    enums: { class: ['DB', 'AP'], mode: ['formula', 'custom'] },
    numbers: ['cpu', 'mem_gb', 'sga_cap_gb'],
    // A custom-mode profile's MEM and SGA cap are whole numbers.
    // See WHOLE_NUMBER_IMPORT_RULE: floored on the way in, and reported.
    integers: ['mem_gb', 'sga_cap_gb'],
    booleans: [],
    jsonCols: ['allowed_disk_combos', 'metadata'], hasMetadata: true, fk: {},
  },
  // ── Global config that a scenario evaluates against (rules / settings) ──
  {
    key: 'settings', table: TABLES.CAP_SETTINGS, nameCol: null, resolvable: false,
    singleton: true, settingsMatch: true, inScenario: true, inConfig: true,
    required: [], strings: [], enums: {},
    numbers: ['mem_cpu_ratio', 'sga_factor', 'sga_divisor', 'sga_subtract', 'util_amber_pct', 'util_red_pct'],
    booleans: ['overcommit_default_enabled'], jsonCols: ['layer_defaults'], hasMetadata: false, fk: {},
  },
  {
    key: 'rules', table: TABLES.CAP_RULES, nameCol: 'name', resolvable: true,
    ruleMatch: true, inScenario: true, inConfig: true,
    required: ['type', 'name', 'level'], strings: ['name'],
    enums: {
      type: RULE_TYPES,
      level: ['hypervisor', 'vm', 'db_instance'],
      group_by: RELATIONAL_GROUP_BYS,
      severity: ['hard', 'soft'],
    },
    numbers: [], booleans: ['enabled'], jsonCols: ['filters', 'params'], hasMetadata: false,
    fk: {
      custom_group_name: { idCol: 'custom_group_id', target: 'custom_groups', nullable: true, refCol: 'custom_group_ref' },
      overrides_rule_name: { idCol: 'overrides_rule_id', target: 'rules', nullable: true, refCol: 'overrides_rule_ref', globalRow: true },
    },
  },
  // ── Pure scenario placement entities ──
  {
    key: 'sites', table: TABLES.CAP_SITES, nameCol: 'name', resolvable: true, inScenario: true,
    required: ['name'], strings: ['name'], enums: { topology: ['site'] },
    numbers: [], booleans: [], jsonCols: ['metadata'], hasMetadata: true, fk: {},
  },
  {
    key: 'hypervisors', table: TABLES.CAP_HYPERVISORS, nameCol: 'name', resolvable: true, inScenario: true,
    required: ['name'], strings: ['name'], enums: {},
    // name_locked (cap-renumber-lock, spec D1): the sheet DECLARES it so the
    // commit's replace-all round-trips a locked host's flag rather than
    // silently resetting it to the DEFAULT 0 (see allowedColumnsOf's own
    // comment on what an undeclared column suffers on commit).
    numbers: [], booleans: ['name_locked'], jsonCols: ['metadata'], hasMetadata: true,
    fk: {
      site_name: { idCol: 'site_id', target: 'sites', refCol: 'site_ref' },
      spec_name: { idCol: 'spec_id', target: 'hardware_specs', refCol: 'spec_ref' },
    },
  },
  {
    key: 'databases', table: TABLES.CAP_DATABASES, nameCol: 'function_name', resolvable: true, inScenario: true,
    required: ['function_name', 'topology'], strings: ['function_name', 'description'],
    // rac_multinode_standby (spec §7 E1 / Q11): a SCENARIO-
    // importable topology. AR2-Q8 also brought bundle_items' topology enum to
    // the full 5-member domain (see that sheet below — bundles now template
    // rac_multinode_standby too). standby_node_count (S) joins node_count (N) in
    // `numbers` so a rac_multinode_standby row's standby count round-trips
    // through export -> re-import instead of silently dropping (the sheet
    // only carries columns declared here — see the vms sheet's function_name
    // comment on what an undeclared column suffers). Enum values derive from
    // the canonical topology module (D11) — a workbook exported
    // before the D12d rename still imports via the legacy alias applied at
    // the parse boundary below, before this legality check runs.
    enums: { topology: TOPOLOGY_VALUES },
    // F4: node_count/standby_node_count are whole node counts (WHOLE_NUMBER_
    // IMPORT_RULE) — a fractional value is floored + reported, not
    // refused, same as mem_gb/sga_gb elsewhere. The topology-gated RANGE check
    // (RAC_MIN_NODES/RAC_MAX_NODES) runs separately below, after flooring.
    numbers: ['node_count', 'standby_node_count'], integers: ['node_count', 'standby_node_count'],
    booleans: [], jsonCols: ['metadata'], hasMetadata: true,
    // function_name charset is deliberately NOT a `push` structural
    // error here for the measured legacy shape, unlike the vms sheet's
    // `vmFunctionName` check below — an import is a ROUND-TRIP of this
    // scenario's own EXPORT, and a measured census found legacy rows (underscore
    // only) in the live cap_databases table whose function_name fails
    // VM_FUNCTION_NAME_RE. A hard reject on that shape here would mean the very
    // next export of an unchanged database this release shipped no longer
    // imports — turning a read-only migration gap into a write-time one. So
    // `databaseFunctionNameCharsetNotice` marks the sheet for a NON-BLOCKING
    // aggregate notice on that one widened character (see buildImportPlan's
    // per-sheet count below); the value is imported as-is. Anything WIDER than
    // that measured shape (whitespace, braces, control chars) is still a
    // blocking structural error — see DATABASE_FUNCTION_NAME_IMPORT_RE.
    databaseFunctionNameCharsetNotice: true,
    fk: {
      profile_name: { idCol: 'profile_id', target: 'vm_profiles', nullable: true, refCol: 'profile_ref' },
      disk_combo_name: { idCol: 'disk_combo_id', target: 'disk_combos', nullable: true, refCol: 'disk_combo_ref' },
      team_name: { idCol: 'team_id', target: 'teams', nullable: true, refCol: 'team_ref' },
    },
  },
  {
    key: 'vms', table: TABLES.CAP_VMS, nameCol: 'name', resolvable: true, inScenario: true,
    // function_name (ap-vm-function) is a DECLARED string so an export that
    // now carries it (SELECT * snapshot) re-imports instead of tripping
    // UNKNOWN_COLUMN — and so a replace-all takes the sheet's value rather than
    // silently preserving the old one. Its ap_host-only / charset / width contract
    // is enforced by `vmFunctionName` below (this write path bypasses the child-
    // mount guards, so the same contract is re-stated at the import boundary).
    required: ['name', 'vm_type'], strings: ['name', 'function_name'], enums: { vm_type: ['db_host', 'ap_host'] },
    vmFunctionName: true,
    // name_locked (cap-renumber-lock, spec D1) — see the hypervisors sheet's
    // comment; same round-trip requirement applies to db_host/ap_host VMs.
    numbers: ['cpu', 'mem_gb', 'disk_gb'], booleans: ['name_locked'], jsonCols: ['metadata'], hasMetadata: true,
    fk: {
      hypervisor_name: { idCol: 'hypervisor_id', target: 'hypervisors', nullable: true, refCol: 'hypervisor_ref' },
      site_name: { idCol: 'site_id', target: 'sites', nullable: true, refCol: 'site_ref' },
      profile_name: { idCol: 'sizing_profile_id', target: 'vm_profiles', nullable: true, refCol: 'profile_ref' },
      disk_combo_name: { idCol: 'disk_combo_id', target: 'disk_combos', nullable: true, refCol: 'disk_combo_ref' },
      team_name: { idCol: 'team_id', target: 'teams', nullable: true, refCol: 'team_ref' },
      database_name: { idCol: 'database_id', target: 'databases', nullable: true, refCol: 'database_ref' },
    },
  },
  {
    key: 'db_instances', table: TABLES.CAP_DB_INSTANCES, nameCol: 'name', resolvable: true, inScenario: true,
    required: ['name', 'role'], strings: ['name'],
    enums: { role: ['primary', 'standby'] }, numbers: ['sga_gb'],
    // The per-instance SGA is one of the four columns exists to make
    // whole — it is what the SGA-cap check sums, and it is DERIVED (the wizard
    // and the database cascade write it; no operator types it here). An import
    // that took it raw would re-introduce the defect at its source.
    // See WHOLE_NUMBER_IMPORT_RULE.
    integers: ['sga_gb'],
    booleans: [],
    jsonCols: ['metadata'], hasMetadata: true,
    fk: {
      vm_name: { idCol: 'vm_id', target: 'vms', requireVmType: 'db_host', refCol: 'vm_ref' },
      database_name: { idCol: 'database_id', target: 'databases', nullable: true, refCol: 'database_ref' },
    },
  },
  {
    key: 'custom_groups', table: TABLES.CAP_CUSTOM_GROUPS, nameCol: 'name', resolvable: true, inScenario: true,
    required: ['name'], strings: ['name'], enums: {}, numbers: [], booleans: [],
    jsonCols: [], hasMetadata: false,
    fk: { team_name: { idCol: 'team_id', target: 'teams', nullable: true, refCol: 'team_ref' } },
  },
  {
    key: 'custom_group_members', table: TABLES.CAP_CUSTOM_GROUP_MEMBERS, nameCol: null, resolvable: false,
    memberXor: true, inScenario: true,
    required: [], strings: [], enums: {}, numbers: [], booleans: [], jsonCols: [], hasMetadata: false,
    fk: {
      group_name: { idCol: 'group_id', target: 'custom_groups', refCol: 'group_ref' },
      member_vm_name: { idCol: 'member_vm_id', target: 'vms', nullable: true, refCol: 'member_vm_ref' },
      member_instance_name: { idCol: 'member_instance_id', target: 'db_instances', nullable: true, refCol: 'member_instance_ref' },
    },
  },
  {
    key: 'waivers', table: TABLES.CAP_WAIVERS, nameCol: null, resolvable: false, waiver: true, inScenario: true,
    required: [], strings: ['note'], enums: {},
    numbers: [], booleans: [], jsonCols: [], hasMetadata: false,
    fk: { rule_name: { idCol: 'rule_id', target: 'rules', refCol: 'rule_ref' } },
  },
  // ── Config-only sheets (exportable; NOT scenario-importable, §19) ──
  {
    key: 'field_defs', table: TABLES.CAP_FIELD_DEFS, nameCol: null, resolvable: false, inConfig: true,
    required: ['entity_type', 'field_key', 'data_type'], strings: ['field_key', 'label', 'default_value'],
    enums: {
      entity_type: ['scenario', 'site', 'hardware_spec', 'hypervisor', 'vm', 'db_instance', 'database'],
      data_type: ['text', 'number', 'bool', 'enum'],
    },
    numbers: [], booleans: ['required'], jsonCols: ['options'], hasMetadata: false, fk: {},
  },
  {
    key: 'bundles', table: TABLES.CAP_BUNDLES, nameCol: 'name', resolvable: true, inConfig: true,
    required: ['name'], strings: ['name'], enums: {}, numbers: ['serial'], booleans: [],
    jsonCols: [], hasMetadata: false, fk: {},
  },
  {
    key: 'bundle_items', table: TABLES.CAP_BUNDLE_ITEMS, nameCol: null, resolvable: false, inConfig: true,
    required: ['type'], strings: ['function_name', 'prefill_custom_group'],
    enums: { type: ['DB', 'AP'], topology: BUNDLE_ITEM_TOPOLOGIES },
    numbers: ['order_index', 'qty', 'node_count', 'standby_node_count'], booleans: [], jsonCols: [], hasMetadata: false,
    fk: {
      bundle_name: { idCol: 'bundle_id', target: 'bundles', refCol: 'bundle_ref' },
      profile_name: { idCol: 'profile_id', target: 'vm_profiles', nullable: true, refCol: 'profile_ref' },
      disk_combo_name: { idCol: 'disk_combo_id', target: 'disk_combos', nullable: true, refCol: 'disk_combo_ref' },
      team_name: { idCol: 'team_id', target: 'teams', nullable: true, refCol: 'team_ref' },
    },
  },
]);

// The scenario-import subset (SNAPSHOT_TABLES order, parent-before-child).
const SCENARIO_SPECS = Object.freeze(SHEET_SPECS.filter((s) => s.inScenario));

// Columns the COMMIT itself supplies, so they are neither the sheet's to carry
// nor the previous row's to keep: identity and scope are minted, the timestamps
// are the engine's, and `order_index` is re-seeded from sheet row position.
const COMMIT_OWNED_COLUMNS = new Set(['id', 'scenario_id', 'created_at', 'updated_at', 'order_index']);

/**
 * Per scenario sheet, the columns of its table that the SHEET DOES NOT DECLARE
 * — derived from `table-ddls.js` minus what the spec names and what the commit
 * supplies itself.
 *
 * Derived rather than listed, because the list is the thing that goes wrong: a
 * column added to a table without being added to its sheet is invisible to
 * everything except the replace-all that then clears it. `allowedColumnsOf`
 * reads the spec the same way `isAllowedColumn` does, so the two halves of
 * "what does this sheet carry" cannot answer differently.
 */
function allowedColumnsOf(spec) {
  const declared = new Set([
    ...(spec.strings || []), ...(spec.numbers || []), ...(spec.integers || []),
    ...(spec.booleans || []), ...(spec.jsonCols || []), ...Object.keys(spec.enums || {}),
  ]);
  for (const fk of Object.values(spec.fk || {})) declared.add(fk.idCol);
  if (spec.nameCol) declared.add(spec.nameCol);
  return declared;
}

/**
 * The value columns compared when deciding whether an imported settings row is
 * merely a re-export of the global singleton (skip) versus a genuine scenario
 * override (write scenario-local).
 *
 * THE MOUNT'S EDITABLE SET, NARROWED TO WHAT THIS SHEET CAN CARRY, and both
 * halves are derived rather than restated. The hand-written list this replaces
 * claimed to mirror `cap_settings`' editable columns; taking the mount's set
 * whole then over-corrected, because one of those columns is deliberately not
 * on the scenario settings sheet at all. `standby_sga_default_gb` is a GLOBAL
 * operator setting: the front end marks it config-only (`xlsx-io.ts`) precisely
 * because emitting it on a scenario settings sheet would make a re-import here
 * fail with UNKNOWN_COLUMN, and `buildImportPlan` only ever writes declared
 * columns.
 *
 * So the imported row's value for it is ALWAYS `undefined` while the global
 * row's is always a number (`NOT NULL DEFAULT 32`) — and the diff's own
 * "a null on one side alone is a difference" rule then answered `false` for
 * every row, on every scenario, permanently. A settings row with a blank scope
 * and an unresolved `ref` — a hand-filled template, or a workbook from another
 * instance — was therefore judged a scenario OVERRIDE, written scenario-local
 * with that column falling to the DDL default, and the scenario stopped
 * tracking the operator's global value. Silently.
 *
 * A diff may only compare a column the import path can populate; a column
 * outside that set is not a difference the answer can be taken from.
 */
const SETTINGS_SHEET_SPEC = SHEET_SPECS.find((s) => s.key === 'settings');
const SETTINGS_VALUE_COLS = Object.freeze(
  CONFIG_MOUNTS.settings.cols.filter((c) => allowedColumnsOf(SETTINGS_SHEET_SPEC).has(c)),
);

const UNDECLARED_COLUMNS = Object.freeze(new Map(SCENARIO_SPECS.map((spec) => {
  const manifest = buildSchemaManifest((base) => base).get(spec.table);
  const declared = allowedColumnsOf(spec);
  const columns = (manifest ? manifest.columns : [])
    .filter((c) => !declared.has(c) && !COMMIT_OWNED_COLUMNS.has(c));
  return [spec.key, Object.freeze(columns)];
})));

// The importer resolves every other reference by NAME, so the row a replace-all
// row replaces is found the same way. Folded, because the column that stores
// the name folds — and a match that disagreed with the column would carry one
// row's values onto another.
const nameKeyOf = (name) => (name == null ? null : String(name).trim().toLowerCase());

/**
 * The undeclared columns of the scenario's CURRENT rows, keyed by name, read
 * before the replace-all deletes them.
 *
 * A NAME THAT IS NOT UNIQUE CARRIES NOTHING, deliberately: two rows sharing a
 * name make "which row does this replace" unanswerable, and guessing would move
 * one row's SGA seeds onto another. That degrades to the old behaviour (the
 * columns fall to their defaults) for exactly the rows nobody can match, rather
 * than inventing an answer.
 */
async function readUndeclaredColumns(conn, scenarioId) {
  const out = new Map();
  for (const spec of SCENARIO_SPECS) {
    const columns = UNDECLARED_COLUMNS.get(spec.key) || [];
    if (!columns.length || !spec.nameCol) continue;
    const projection = [spec.nameCol, ...columns].map((c) => `\`${c}\``).join(', ');
    const rows = await conn.query(
      `SELECT ${projection} FROM \`${t(spec.table)}\` WHERE scenario_id = ?`, [scenarioId],
    );
    const byName = new Map();
    const ambiguous = new Set();
    for (const row of rows) {
      const key = nameKeyOf(row[spec.nameCol]);
      if (key == null) continue;
      if (byName.has(key)) { ambiguous.add(key); continue; }
      byName.set(key, row);
    }
    for (const key of ambiguous) byName.delete(key);
    out.set(spec.key, { columns, byName });
  }
  return out;
}

// An id, folded. Ids are `CHAR(36)` under a case-folding collation, so two
// spellings of one id name one row to every statement in this file; a
// byte-keyed map would answer "not one of ours" for a reference the engine
// resolves. The fold is only ever used to RECOGNISE a reference into the set
// this commit re-mints — never to decide what gets written, which is always a
// stored spelling — so widening is the safe direction here.
const idKeyOf = (id) => (id == null ? null : String(id).trim().toLowerCase());

/**
 * Every scenario row this replace-all is about to delete, as
 * `folded id → { key, nameKey }`.
 *
 * READ BEFORE THE DELETE, because afterwards nothing connects an old id to the
 * row that replaces it. This is the half that makes carrying an undeclared
 * column safe: the commit DELETEs every scenario row and re-INSERTs it under a
 * FRESH uuid, so any id a carried value holds names a row that no longer
 * exists. Recognising those is a question about the VALUE, not about the column
 * name — an exclusion list keyed on `dc_refs` would be exactly the hand-kept
 * list this path exists to remove, and would say nothing about the next
 * reference-shaped column somebody adds.
 *
 * Tables with no name column are included and map to a null `nameKey`: they
 * cannot be matched to their replacement, so a reference to one is DROPPED
 * rather than carried dangling.
 */
async function readReplacedRowIdentity(conn, scenarioId) {
  const out = new Map();
  for (const spec of SCENARIO_SPECS) {
    const projection = spec.nameCol ? `id, \`${spec.nameCol}\` AS name` : 'id';
    const rows = await conn.query(
      `SELECT ${projection} FROM \`${t(spec.table)}\` WHERE scenario_id = ?`, [scenarioId],
    );
    for (const row of rows) {
      const key = idKeyOf(row.id);
      if (key == null) continue;
      out.set(key, { key: spec.key, nameKey: spec.nameCol ? nameKeyOf(row.name) : null });
    }
  }
  return out;
}

// A carried value that names a deleted row nothing replaces. Distinct from
// `null`, which is a value a column may legitimately hold: this one means the
// column cannot be carried at all.
const UNMAPPABLE = Symbol('unmappable-reference');

/**
 * Rewrite every reference inside a carried value to the id its row now holds.
 *
 * REF-FIRST, THEN NAME — the same order, from the same maps, that the importer
 * resolves every DECLARED reference by. An exported row carries its own id in
 * the `ref` column, so an ordinary round trip resolves exactly, through a
 * rename included; a hand-filled workbook with no `ref` falls back to the name,
 * and a reference nothing matches is dropped.
 *
 * Dropping is what the domain already does with such an entry: the front end
 * normalises a `dc_refs` restriction to its LIVE-site subset
 * (`capacity-wizard-model.ts` effDcRefs), and an empty list means "unrestricted".
 * Carrying the dead id instead is the state that cannot be read at all —
 * `filterDcCandidates` returns no candidate site and every placed VM reports
 * itself outside its own restriction.
 *
 * Walks arrays and objects so a reference at any depth of a JSON document is
 * reached; a non-string leaf (a number, a boolean) is returned untouched.
 */
function remapCarriedValue(value, replacedIdentity, resolvedRowIds, onDrop = () => {}) {
  if (typeof value === 'string') {
    const wasDeleted = replacedIdentity.get(idKeyOf(value));
    if (!wasDeleted) return value; // not a reference into the re-minted set
    const resolved = resolvedRowIds ? resolvedRowIds[wasDeleted.key] : null;
    const byRef = resolved && resolved.byRef.get(idKeyOf(value));
    if (byRef != null) return byRef;
    const byName = wasDeleted.nameKey != null && resolved
      ? resolved.byName.get(wasDeleted.nameKey)
      : undefined;
    if (byName != null) return byName;
    onDrop();
    return UNMAPPABLE;
  }
  if (Array.isArray(value)) {
    const out = [];
    for (const item of value) {
      const mapped = remapCarriedValue(item, replacedIdentity, resolvedRowIds, onDrop);
      if (mapped !== UNMAPPABLE) out.push(mapped);
    }
    return out;
  }
  if (value !== null && typeof value === 'object') {
    const out = {};
    for (const [k, v] of Object.entries(value)) {
      const mapped = remapCarriedValue(v, replacedIdentity, resolvedRowIds, onDrop);
      out[k] = mapped === UNMAPPABLE ? null : mapped;
    }
    return out;
  }
  return value;
}

const SCENARIO_KEYS = new Set(SCENARIO_SPECS.map((s) => s.key));
// Known config-only sheet keys: recognised but ignored on a scenario import (a
// friendly notice, not an UNKNOWN_SHEET error) — config import is out of scope.
const CONFIG_ONLY_KEYS = new Set(SHEET_SPECS.filter((s) => s.inConfig && !s.inScenario).map((s) => s.key));

// The drag-reorderable entities (phase-4 spec §6). A workbook carries NO
// order_index column (a deliberate choice — the sheet contract stays name-based),
// so ROW POSITION is the carrier for the persisted drag order: the export emits
// these sheets in order_index order, and the import re-seeds order_index from
// sheet row position. Together they round-trip the drag order without an extra
// column. Every other snapshot table has no order_index. sites is included: its
// order_index (phase-2) has the same round-trip hole otherwise.
const ORDER_CARRYING_KEYS = new Set(['sites', 'hardware_specs', 'hypervisors', 'vms', 'db_instances']);

// order_index-then-id comparator (id break keeps ties stable across a round-trip).
// A global closure hardware_spec (scenario_id NULL, never reordered → order_index
// 0) sorts among the zeros; it is a reference target, not scenario-local content,
// so import matches it away and never re-seeds it — only the relative order of the
// scenario-LOCAL rows matters, and this preserves it.
function byOrderIndex(a, b) {
  const ao = Number.isFinite(a.order_index) ? a.order_index : 0;
  const bo = Number.isFinite(b.order_index) ? b.order_index : 0;
  if (ao !== bo) return ao - bo;
  return String(a.id).localeCompare(String(b.id));
}

// ── Cell coercion (tolerate spreadsheet string cells) ─────────────────────────

function coerceNumber(v) {
  if (typeof v === 'number' && Number.isFinite(v)) return { ok: true, value: v };
  if (typeof v === 'string' && v.trim() !== '') {
    const n = Number(v);
    if (Number.isFinite(n)) return { ok: true, value: n };
  }
  return { ok: false };
}

function coerceBoolean(v) {
  if (typeof v === 'boolean') return { ok: true, value: v };
  if (v === 0 || v === 1) return { ok: true, value: v === 1 };
  if (typeof v === 'string') {
    const s = v.trim().toLowerCase();
    if (s === 'true' || s === '1') return { ok: true, value: true };
    if (s === 'false' || s === '0') return { ok: true, value: false };
  }
  return { ok: false };
}

// A JSON column: an object/array passes through (re-stringified for storage); a
// string must parse. Returns { ok, value } where value is a JSON string (or null).
function coerceJson(v) {
  if (v == null) return { ok: true, value: null };
  if (typeof v === 'object') {
    try { return { ok: true, value: JSON.stringify(v) }; } catch { return { ok: false }; }
  }
  if (typeof v === 'string') {
    if (v.trim() === '') return { ok: true, value: null };
    try { JSON.parse(v); return { ok: true, value: v }; } catch { return { ok: false }; }
  }
  return { ok: false };
}

function isEmpty(v) {
  return v == null || (typeof v === 'string' && v.trim() === '');
}

// ── Pure validate + resolve pipeline (no I/O — unit-testable) ─────────────────

/**
 * Whether a serialized `sheets` object exceeds the import size cap. Exported for
 * a direct boundary unit test (a 4 MB payload cannot be sent through the test
 * harness's default body parser).
 */
function importPayloadTooLarge(sheets) {
  let serialized;
  try { serialized = JSON.stringify(sheets ?? {}); } catch { return true; }
  return Buffer.byteLength(serialized, 'utf8') > MAX_IMPORT_BYTES;
}

// A sheet whose rows can be EITHER a global catalogue row (scenario_id NULL) OR
// a scenario-local row (scenario_id set) carries a `scope` marker column
// ('global'|'local') on export so import can tell reference-resolution targets
// (global closure) apart from scenario CONTENT (a local row that must always be
// re-inserted, never name-matched to a global). §17.4.
function hasScopeCol(spec) {
  return !!(spec.catalogue || spec.ruleMatch || spec.settingsMatch);
}

// Normalizes a `scope` cell for both the exact-match lookup (scopeOf) and the
// INVALID_SCOPE validation check below: trim whitespace + lowercase, then
// treat an empty result as absent (null). Trimming/lowercasing before the
// exact-match is deliberately forgiving of stray whitespace/case on a
// hand-edited sheet ('Local', ' local ') while still requiring an exact match
// against the two legal tokens after normalization — anything else is a
// structural error, never a silent fallback (Codex R2 finding, §17.4).
function normalizeScope(v) {
  if (isEmpty(v)) return null;
  return String(v).trim().toLowerCase();
}

// The declared scope of a row: 'local' | 'global' | null. null covers BOTH an
// absent/empty cell (a hand-authored workbook — the existing assumed-global
// fallback applies) and a present-but-invalid cell; callers that need to tell
// those two null-causes apart (Phase 1.5's match-fallback, which must NOT run
// for an invalid value) use `scopeIsInvalid` alongside this.
function scopeOf(raw) {
  const v = normalizeScope(raw && raw.scope);
  return v === 'local' || v === 'global' ? v : null;
}

// True when a row's `scope` cell is present (non-empty) but fails to
// normalize to a legal token. Phase 1 already reports this as a per-row
// INVALID_SCOPE structural error (blocking commit); Phase 1.5 additionally
// uses this to skip global name-matching entirely for such a row — a
// malformed value must never fall through to the same "absent → try to
// match a global" path as a truly-empty cell (Codex R2 finding, §17.4).
function scopeIsInvalid(raw) {
  const v = raw && raw.scope;
  if (isEmpty(v)) return false;
  const n = normalizeScope(v);
  return n !== 'local' && n !== 'global';
}

function isAllowedColumn(spec, col) {
  if (SERVER_MANAGED_COLUMNS.has(col)) return true;
  if (col === spec.nameCol) return true;
  if (spec.required.includes(col)) return true;
  if (spec.strings.includes(col)) return true;
  if (spec.numbers.includes(col)) return true;
  if (spec.booleans.includes(col)) return true;
  if (spec.jsonCols.includes(col)) return true;
  if (Object.prototype.hasOwnProperty.call(spec.enums, col)) return true;
  if (Object.prototype.hasOwnProperty.call(spec.fk, col)) return true;
  // The optional stable-ref token (every sheet), the per-FK ref columns, and the
  // waiver name/ref multi-value columns.
  if (col === 'ref') return true;
  if (hasScopeCol(spec) && col === 'scope') return true;
  for (const def of Object.values(spec.fk)) if (def.refCol === col) return true;
  if (spec.waiver && (col === 'object_names' || col === 'object_refs')) return true;
  if (spec.hasMetadata && col === 'metadata') return true;
  if (spec.hasMetadata && col.startsWith('cf:')) return true;
  return false;
}

/**
 * Fold a row's `cf:<key>` columns (+ any explicit `metadata`) into a single
 * metadata JSON string, or return null when the row carries no custom values.
 * Uses a null-prototype accumulator so a `cf:__proto__` cell cannot pollute
 * Object.prototype; a reserved key is reported as an error instead.
 */
function buildMetadata(spec, row, push) {
  if (!spec.hasMetadata) return null;
  const acc = Object.create(null);
  let touched = false;

  // A reserved prototype key in an EXPLICIT metadata object/string must be rejected
  // the same way the cf: loop rejects one — otherwise it lands verbatim in the
  // stored JSON and re-opens the pollution risk wherever the row's metadata is later
  // spread onto a normal-prototype object. `acc` is null-prototype so the assignment
  // itself is safe; the reject is about not persisting the reserved key at all.
  let reservedHit = false;
  const base = row.metadata;
  if (base && typeof base === 'object') {
    for (const [k, val] of Object.entries(base)) {
      if (RESERVED_META_KEYS.has(k)) { push('metadata', 'RESERVED_FIELD_KEY', `metadata key "${k}" is reserved`); reservedHit = true; continue; }
      acc[k] = val; touched = true;
    }
  } else if (typeof base === 'string' && base.trim() !== '') {
    let parsed = null;
    try { parsed = JSON.parse(base); } catch { push('metadata', 'INVALID_JSON', 'metadata is not valid JSON'); return null; }
    if (parsed && typeof parsed === 'object') {
      for (const [k, val] of Object.entries(parsed)) {
        if (RESERVED_META_KEYS.has(k)) { push('metadata', 'RESERVED_FIELD_KEY', `metadata key "${k}" is reserved`); reservedHit = true; continue; }
        acc[k] = val; touched = true;
      }
    }
  }
  if (reservedHit) return null;

  for (const col of Object.keys(row)) {
    if (!col.startsWith('cf:')) continue;
    const fieldKey = col.slice(3);
    if (RESERVED_META_KEYS.has(fieldKey)) {
      push(col, 'RESERVED_FIELD_KEY', `custom field key "${fieldKey}" is reserved`);
      continue;
    }
    acc[fieldKey] = row[col];
    touched = true;
  }

  if (!touched) return null;
  return JSON.stringify(acc);
}

/**
 * Resolve a '|'-joined Exception subject list (names OR ref tokens) against a
 * combined Map(token → [id]). Pushes an error per token matching 0 or ≥2
 * subjects and returns null in that case; otherwise returns the resolved id
 * list. `column` is the report column; `label==='ref'` phrases the message for a
 * ref token.
 */
function resolveObjectSet(raw, tokenToIds, column, label, push) {
  const tokens = raw.split('|').map((s) => s.trim()).filter((s) => s !== '');
  const noun = label === 'ref' ? 'object ref' : 'object';
  const resolved = [];
  let bad = false;
  for (const tok of tokens) {
    const ids = tokenToIds.get(tok) || [];
    if (ids.length === 0) { push(column, 'UNRESOLVED_REF', `${noun} "${tok}" matches no entity`); bad = true; }
    else if (ids.length >= 2) { push(column, 'UNRESOLVED_REF', `${noun} "${tok}" matches ${ids.length} entities`); bad = true; }
    else resolved.push(ids[0]);
  }
  return bad ? null : resolved;
}

/**
 * Index the existing GLOBAL rows of one catalogue for match-first resolution:
 * an id Set (ref-first) + a name → [id] map (name-fallback). `rows` come from
 * the route (scenario_id IS NULL); in a pure unit test an absent key yields an
 * empty index → every row is unmatched → created scenario-local.
 */
function indexGlobalRows(rows, nameCol) {
  const ids = new Set();
  const byName = new Map();
  for (const r of rows || []) {
    const id = r && r.id != null ? String(r.id) : null;
    if (id) ids.add(id);
    if (nameCol && r && r[nameCol] != null && id) {
      const list = byName.get(String(r[nameCol])) || [];
      list.push(id);
      byName.set(String(r[nameCol]), list);
    }
  }
  return { ids, byName };
}

/**
 * Resolve a catalogue/global row to an EXISTING global id (§17.4): ref-first (the
 * row's `ref` token IS a global id), then name-fallback (a UNIQUELY-named global
 * row). Returns the global id, or null when nothing matches (caller creates the
 * row scenario-local). A name matching ≥2 globals is treated as unmatched
 * (ambiguous → create scenario-local; duplicate display names are legal, §17.4).
 */
function matchGlobalId(index, refToken, name) {
  if (refToken != null && index.ids.has(String(refToken))) return String(refToken);
  if (name != null) {
    const ids = index.byName.get(String(name)) || [];
    if (ids.length === 1) return ids[0];
  }
  return null;
}

// Whether an imported settings row is merely the re-exported global singleton
// (skip — a scenario tracks global settings) vs a genuine scenario override
// (write scenario-local). Scope marker wins when present ('local' → override,
// 'global' → skip); otherwise ref-first (the row's `ref` = the global settings
// id), then a full value-equality check so a wiped/reseeded target (fresh global
// id) does not spuriously turn the global row into a redundant scenario override.
function settingsIsGlobal(dbRow, refToken, scope, globalSettingsRows) {
  if (scope === 'local') return false;
  if (scope === 'global') return true;
  const rows = globalSettingsRows || [];
  if (refToken != null && rows.some((r) => r && String(r.id) === String(refToken))) return true;
  const g = rows[0];
  if (!g) return false;
  return SETTINGS_VALUE_COLS.every((col) => {
    const a = dbRow[col];
    const b = g[col];
    if (SETTINGS_JSON_COLS.has(col)) {
      const aj = a == null ? null : (typeof a === 'string' ? a : JSON.stringify(a));
      const bj = b == null ? null : (typeof b === 'string' ? b : JSON.stringify(b));
      return aj === bj;
    }
    if (a == null && b == null) return true;
    if (a == null || b == null) return false;
    return Number(a) === Number(b) || String(a) === String(b);
  });
}

/**
 * Validate every scenario sheet's rows, mint a fresh id per row, coerce native
 * columns, resolve name/ref FK columns, and resolve catalogue/rule/settings rows
 * against the EXISTING global catalogues (`existingGlobals`) — matched → the
 * global id; unmatched → created scenario-local (§17.4). PURE: no DB, no side
 * effects, deterministic. Returns:
 *   { ok, errors:[{sheet,row,column?,code,message}], notices:[{sheet,row?,column?,code,message}],
 *     stats:{perSheet}, plan:{ <key>: [{id,dbRow}] } }
 *   plan[key] holds ONLY the rows to INSERT scenario-local (a matched global
 *   catalogue/rule row contributes its id to FK resolution but is NOT inserted).
 * `actorId` stamps waiver.created_by (never taken from the file). `existingGlobals`
 * is `{ hardware_specs, disk_combos, teams, vm_profiles, rules, settings }` global
 * rows (empty maps in a pure unit test → everything unmatched → scenario-local).
 */
function buildImportPlan(sheets, actorId, existingGlobals = {}) {
  const errors = [];
  const notices = [];
  const stats = { perSheet: {} };
  const input = sheets && typeof sheets === 'object' ? sheets : {};

  // Unknown vs known-config-only top-level sheet keys.
  for (const key of Object.keys(input)) {
    if (SCENARIO_KEYS.has(key)) continue;
    if (CONFIG_ONLY_KEYS.has(key)) {
      notices.push({
        sheet: key, code: 'IGNORED_SHEET',
        message: `sheet "${key}" is global config and is not imported into a scenario (config import is out of scope)`,
      });
    } else {
      errors.push({ sheet: key, row: 0, code: 'UNKNOWN_SHEET', message: `unknown sheet "${key}"` });
    }
  }

  // Pre-index the existing global catalogues for match-first resolution.
  const globalIndex = {
    hardware_specs: indexGlobalRows(existingGlobals.hardware_specs, 'name'),
    disk_combos: indexGlobalRows(existingGlobals.disk_combos, 'name'),
    teams: indexGlobalRows(existingGlobals.teams, 'name'),
    vm_profiles: indexGlobalRows(existingGlobals.vm_profiles, 'name'),
    rules: indexGlobalRows(existingGlobals.rules, 'name'),
  };
  const globalSettingsRows = existingGlobals.settings || [];

  // Phase 1 — per-row native validation + id minting; collect built rows.
  const built = {};          // key → [{ rowNum, id, name, dbRow, raw, refToken, matched?, resolvedId? }]
  for (const spec of SCENARIO_SPECS) {
    const rows = Array.isArray(input[spec.key]) ? input[spec.key] : [];
    if (input[spec.key] !== undefined && !Array.isArray(input[spec.key])) {
      errors.push({ sheet: spec.key, row: 0, code: 'BAD_SHEET', message: `sheet "${spec.key}" must be an array of rows` });
    }
    stats.perSheet[spec.key] = { rows: rows.length, errors: 0 };
    built[spec.key] = [];

    // Per-sheet row cap (DoS backstop) — a single structural error, not a 500.
    // The sheet's rows are left unprocessed (built stays empty); a dependent FK
    // resolving against it will surface its own UNRESOLVED_REF, but ok is already
    // false so nothing commits.
    if (rows.length > MAX_ROWS_PER_SHEET) {
      errors.push({ sheet: spec.key, row: 0, code: 'TOO_MANY_ROWS', message: `sheet "${spec.key}" has ${rows.length} rows (max ${MAX_ROWS_PER_SHEET})` });
      continue;
    }

    const seenRef = new Set(); // ref tokens seen in this sheet (must be unique)
    // databases: count of function_name values outside VM_FUNCTION_NAME_RE,
    // reported as ONE aggregate notice after the loop rather than a
    // per-row push — see `databaseFunctionNameCharsetNotice` above.
    let legacyFunctionNameCharsetCount = 0;
    rows.forEach((row, i) => {
      const rowNum = i + 2; // 1-based file row (header occupies row 1)
      const push = (column, code, message) => errors.push(column
        ? { sheet: spec.key, row: rowNum, column, code, message }
        : { sheet: spec.key, row: rowNum, code, message });
      const noteFloored = (column, was, now) => notices.push({
        sheet: spec.key, row: rowNum, column, code: WHOLE_NUMBER_NOTICE_CODE,
        message: `${column} ${was} was imported as ${now} — a derived capacity quantity is stored as a whole number`,
      });

      if (!row || typeof row !== 'object' || Array.isArray(row)) {
        push(undefined, 'BAD_ROW', 'row must be an object');
        return;
      }

      // Unknown columns (excluding server-managed / cf: / declared columns).
      for (const col of Object.keys(row)) {
        if (!isAllowedColumn(spec, col)) push(col, 'UNKNOWN_COLUMN', `unknown column "${col}"`);
      }

      // Required present + non-empty.
      for (const col of spec.required) {
        if (isEmpty(row[col])) push(col, 'MISSING_FIELD', `${col} is required`);
      }

      const dbRow = {};

      // Strings (stored as-is; coerced to string for a stray numeric cell).
      for (const col of spec.strings) {
        if (Object.prototype.hasOwnProperty.call(row, col) && !isEmpty(row[col])) {
          dbRow[col] = String(row[col]);
        }
      }
      // databases: width guard, THEN a two-tier charset check on a value
      // outside the hostname-safe alphabet (follow-up, Codex r2). The
      // width limit is cap_databases.function_name's column width
      // (VARCHAR(255), table-ddls.js) — MAX_VM_FUNCTION_NAME is the SAME
      // constant the interactive path reuses for this column
      // (makeDatabaseFunctionNameGuard, _shared.js), not a new one, since
      // cap_vms.function_name and cap_databases.function_name share the same
      // DDL width. Checked BEFORE charset, same ordering as the vms sheet's
      // vmFunctionName check below, so an overlong value gets ONE error
      // (VALUE_TOO_LONG) instead of also tripping the charset branch — and,
      // load-bearingly, never reaches the commit INSERT to throw a DB
      // out-of-range error instead of a clean validation error.
      // Charset: a value within the MEASURED legacy shape
      // (DATABASE_FUNCTION_NAME_IMPORT_RE — underscore, the entirety of what the
      // census found) is tallied, never rejected — round-trip permissive, see
      // `databaseFunctionNameCharsetNotice`. A value wider than that (whitespace,
      // braces, control chars — the hostname-corruption class the SECURITY note
      // on VM_FUNCTION_NAME_RE names) is a blocking structural error, same shape
      // as the vms sheet's vmFunctionName check below.
      if (spec.databaseFunctionNameCharsetNotice
        && Object.prototype.hasOwnProperty.call(dbRow, 'function_name')) {
        if (dbRow.function_name.length > MAX_VM_FUNCTION_NAME) {
          push('function_name', 'VALUE_TOO_LONG', `function_name exceeds ${MAX_VM_FUNCTION_NAME} characters`);
        } else if (!VM_FUNCTION_NAME_RE.test(dbRow.function_name)) {
          if (DATABASE_FUNCTION_NAME_IMPORT_RE.test(dbRow.function_name)) {
            legacyFunctionNameCharsetCount += 1;
          } else {
            push('function_name', 'INVALID_VALUE', DATABASE_FUNCTION_NAME_IMPORT_CHARSET_MSG);
          }
        }
      }
      // Enums. D12d: `topology` gets the PERMANENT legacy alias (rac/rac_standby
      // -> rac_multinode/rac_multinode_standby) applied at THIS parse boundary,
      // before the legality check below — so a workbook exported by an older
      // release keeps importing, and only ever lands the NEW value in dbRow (a
      // re-export of this row always writes the new spelling, never the old).
      for (const [col, legal] of Object.entries(spec.enums)) {
        if (isEmpty(row[col])) continue;
        const val = col === 'topology' ? normalizeLegacyTopology(String(row[col])) : String(row[col]);
        if (!legal.includes(val)) push(col, 'INVALID_ENUM', `${col} "${val}" is not one of ${legal.join(', ')}`);
        else dbRow[col] = val;
      }
      // Scope marker (catalogue/rule/settings sheets only, §17.4). Absent/empty
      // is the existing assumed-global fallback (ASSUMED_GLOBAL_SCOPE notice,
      // Phase 1.5, unchanged) — but a PRESENT value that fails to normalize to
      // exactly 'local'/'global' (trim + lowercase) is a structural error, never
      // a silent fallback to global name-matching on a name-colliding row
      // (Codex R2 finding).
      if (hasScopeCol(spec) && !isEmpty(row.scope)) {
        const norm = normalizeScope(row.scope);
        if (norm !== 'local' && norm !== 'global') {
          push('scope', 'INVALID_SCOPE', `scope "${row.scope}" is not one of local, global`);
        }
      }
      // Numbers. A `spec.integers` column is floored and reported rather than
      // refused — WHOLE_NUMBER_IMPORT_RULE carries the why.
      for (const col of spec.numbers) {
        if (isEmpty(row[col])) continue;
        const c = coerceNumber(row[col]);
        if (!c.ok) { push(col, 'INVALID_NUMBER', `${col} must be a number`); continue; }
        if ((spec.integers || []).includes(col) && !Number.isInteger(c.value)) {
          dbRow[col] = floorGb(c.value);
          noteFloored(col, c.value, dbRow[col]);
        } else dbRow[col] = c.value;
      }
      // F4: databases sheet — topology-gated RAC node/standby-node bound check,
      // reusing the SAME isPositiveInt + RAC_MIN_NODES/RAC_MAX_NODES the write
      // paths (wizard.js / database-bulk-create.js) already enforce. Runs on
      // dbRow[col] (post-floor), not the raw cell, so a fractional value that
      // WHOLE_NUMBER_IMPORT_RULE already floored is checked at its floored
      // value — consistent with that rule's "floor, don't refuse" contract. A
      // malformed value (negative, zero, oversized, non-numeric already caught
      // above) now fails clean HERE (a structural error, same class as an
      // invalid enum) instead of silently persisting a domain-invalid node
      // count that only crashes later when a read path (nodePlan /
      // expectedInstanceCounts) tries to build N/S nodes from it.
      if (spec.key === 'databases') {
        const topology = dbRow.topology;
        // X4 fix (Codex round 2, P2 — io.js-validation-weaker-than-siblings
        // family, F4 was member 1): node_count REQUIREDNESS is topology-gated,
        // mirroring wizard.js's own rule (rac_multinode/rac_multinode_standby
        // REQUIRE node_count 2-100 — buildWizardPlan's `isPositiveInt(r.node_count)`
        // check has no "if present" guard). io.js used to skip this column's
        // validation ENTIRELY when the cell was blank/omitted — the Numbers
        // loop above only checks a column that IS present (`isEmpty(row[col])`
        // -> skip, `continue`), so an omitted OR blank node_count on a
        // rac_multinode/rac_multinode_standby row imported with node_count
        // NULL, bypassing the 2-100 requiredness the wizard/bulk-create write
        // paths enforce. Checked on `topology` (already alias-normalized by
        // the enum loop above), not the raw cell — a legacy-spelled row is
        // gated the same as a current-spelled one.
        if ((topology === TOPOLOGY.RAC_MULTINODE || topology === TOPOLOGY.RAC_MULTINODE_STANDBY) && isEmpty(row.node_count)) {
          push('node_count', 'MISSING_FIELD', `node_count is required for ${topology}`);
        } else if ((topology === TOPOLOGY.RAC_MULTINODE || topology === TOPOLOGY.RAC_MULTINODE_STANDBY)
          && Object.prototype.hasOwnProperty.call(dbRow, 'node_count')
          && (!isPositiveInt(dbRow.node_count) || dbRow.node_count < RAC_MIN_NODES || dbRow.node_count > RAC_MAX_NODES)) {
          push('node_count', 'INVALID_VALUE', `node_count must be an integer >= ${RAC_MIN_NODES} and <= ${RAC_MAX_NODES}`);
        }
        // standby_node_count stays OPTIONAL (default-to-N, Q11/F1) — no
        // requiredness gate added here, matching both write paths' own rule.
        if (topology === TOPOLOGY.RAC_MULTINODE_STANDBY
          && Object.prototype.hasOwnProperty.call(dbRow, 'standby_node_count')
          && (!isPositiveInt(dbRow.standby_node_count) || dbRow.standby_node_count > RAC_MAX_NODES)) {
          push('standby_node_count', 'INVALID_VALUE', `standby_node_count must be an integer >= 1 and <= ${RAC_MAX_NODES}`);
        }
      }
      // Booleans.
      for (const col of spec.booleans) {
        if (isEmpty(row[col])) continue;
        const c = coerceBoolean(row[col]);
        if (!c.ok) push(col, 'INVALID_BOOLEAN', `${col} must be true or false`);
        else dbRow[col] = c.value ? 1 : 0;
      }
      // JSON columns.
      for (const col of spec.jsonCols) {
        if (!Object.prototype.hasOwnProperty.call(row, col)) continue;
        const c = coerceJson(row[col]);
        if (!c.ok) push(col, 'INVALID_JSON', `${col} is not valid JSON`);
        else if (c.value !== null) dbRow[col] = c.value;
      }
      // Custom fields → metadata JSON.
      if (spec.hasMetadata) {
        const meta = buildMetadata(spec, row, push);
        if (meta !== null) dbRow.metadata = meta;
        // sites (Q16): reject a metadata.placement_layout carrying an unknown
        // key or an out-of-bounds value — the import path's own input-boundary
        // gate, matching the sites child-CRUD/wizard write paths.
        if (spec.key === 'sites' && meta !== null) {
          const layoutErr = sitesMetadataPlacementLayoutError(meta);
          if (layoutErr) push('metadata', 'INVALID_VALUE', layoutErr.message);
        }
      }
      // ap-vm-function: re-state the cap_vms.function_name contract at the
      // import trust boundary. The scenario-import commit writes its rows through a
      // replace-all INSERT, NOT the child-mount CRUD guards
      // (makeVmFunctionNameGuard / makeVmFunctionTypeGuard), so an import must not
      // be a way around the SAME rules: a value belongs to an ap_host only (a
      // db_host's {function} is derived from its child database), must fit the
      // column width, and must be the hostname-safe alphabet the renumber engine
      // interpolates. `dbRow.function_name` is only present when non-empty (the
      // strings loop skips an empty cell → unset → 'ap' fallback), so this is a
      // present-value check. vm_type is validated + set above (a required enum).
      if (spec.vmFunctionName && Object.prototype.hasOwnProperty.call(dbRow, 'function_name')) {
        const fn = dbRow.function_name;
        if (dbRow.vm_type === 'db_host') push('function_name', 'INVALID_VALUE', VM_FUNCTION_DB_HOST_MSG);
        else if (fn.length > MAX_VM_FUNCTION_NAME) push('function_name', 'VALUE_TOO_LONG', `function_name exceeds ${MAX_VM_FUNCTION_NAME} characters`);
        else if (!VM_FUNCTION_NAME_RE.test(fn)) push('function_name', 'INVALID_VALUE', VM_FUNCTION_NAME_CHARSET_MSG);
      }
      // A rule row carries the SAME target-model + DoS bounds the direct write
      // path enforces (six-keeper type allowlist, per-type level/group_by
      // legality, filters/params ≤ MAX_RULE_JSON_BYTES, ≤ MAX_RULE_CONDITIONS) —
      // strictType ON (config-rewrite R5): an import must not be a way around
      // them. Reuse the single source (_shared.validateRuleWritePayload).
      if (spec.ruleMatch) {
        const bad = validateRuleWritePayload(
          { type: dbRow.type, level: dbRow.level, group_by: dbRow.group_by, filters: row.filters, params: row.params },
          { strictType: true },
        );
        if (bad) push(undefined, bad.code, bad.message);
      }

      const id = uuidv4();
      const name = spec.nameCol && !isEmpty(row[spec.nameCol]) ? String(row[spec.nameCol]) : null;
      const refToken = !isEmpty(row.ref) ? String(row.ref) : null;
      if (refToken != null) {
        if (seenRef.has(refToken)) push('ref', 'DUPLICATE_REF', `duplicate ref "${refToken}"`);
        else seenRef.add(refToken);
      }

      built[spec.key].push({ rowNum, id, name, dbRow, raw: row, refToken });
    });
    if (legacyFunctionNameCharsetCount > 0) {
      notices.push({
        sheet: spec.key, code: DATABASE_FUNCTION_NAME_CHARSET_NOTICE_CODE,
        message: `function_name: ${legacyFunctionNameCharsetCount} row(s) use a character outside letters, digits and hyphens — imported as-is (existing values keep working)`,
      });
    }
  }

  // Phase 1.5 — resolve each row to its FINAL id: a catalogue / plain-rule row
  // matched to an EXISTING global row resolves to the global id (not inserted);
  // an unmatched row resolves to its minted id (created scenario-local, §17.4).
  // Build ref→id and name→[id] maps of RESOLVED ids so scenario FK columns land
  // on the right (global or scenario-local) target.
  const globalResolvedIds = new Set(); // resolved ids that are EXISTING global rows
  const refToResolved = {};            // key → Map(refToken → resolvedId)
  const nameToResolved = {};           // key → Map(name → [resolvedId])
  for (const spec of SCENARIO_SPECS) { refToResolved[spec.key] = new Map(); nameToResolved[spec.key] = new Map(); }
  // Sheets where a row without an explicit scope was treated as a GLOBAL
  // reference (a name/ref match to an existing global reused it). A one-per-sheet
  // notice tells a hand-editor to add scope='local' if that row was meant as
  // scenario-local content — never a silent data-loss surprise (§17.4 / P1).
  const assumedGlobalSheets = new Set();

  for (const spec of SCENARIO_SPECS) {
    for (const b of built[spec.key]) {
      let resolvedId = b.id;
      let matched = false;
      const scope = hasScopeCol(spec) ? scopeOf(b.raw) : null;
      const invalidScope = hasScopeCol(spec) && scopeIsInvalid(b.raw);
      // A row explicitly marked scenario-local is CONTENT — always inserted
      // scenario-local, NEVER name-matched to a global (P1: a local spec/profile/
      // combo/team/rule whose name collides with a global must not be dropped).
      // A row with an INVALID scope value gets the same treatment (no fallback
      // matching) — Phase 1 already flagged it as a blocking INVALID_SCOPE
      // error; it must not also silently repoint to a name-colliding global.
      if (scope !== 'local' && !invalidScope) {
        if (spec.catalogue) {
          const gid = matchGlobalId(globalIndex[spec.key], b.refToken, b.name);
          if (gid) { resolvedId = gid; matched = true; }
        } else if (spec.ruleMatch) {
          // An override row (overrides_rule_* set) is inherently scenario-local —
          // never matched to a global row. A plain rule row matches the global
          // template (ref-first, then unique-name), else becomes scenario-local.
          const isOverride = !isEmpty(b.raw.overrides_rule_name) || !isEmpty(b.raw.overrides_rule_ref);
          if (!isOverride) {
            const gid = matchGlobalId(globalIndex.rules, b.refToken, b.name);
            if (gid) { resolvedId = gid; matched = true; }
          }
        }
        if (matched && scope == null) assumedGlobalSheets.add(spec.key);
      }
      b.resolvedId = resolvedId;
      b.matched = matched;
      if (matched) globalResolvedIds.add(resolvedId);
      if (b.refToken != null) refToResolved[spec.key].set(b.refToken, resolvedId);
      if (spec.resolvable && b.name != null) {
        const list = nameToResolved[spec.key].get(b.name) || [];
        list.push(resolvedId);
        nameToResolved[spec.key].set(b.name, list);
      }
    }
  }
  for (const key of assumedGlobalSheets) {
    notices.push({
      sheet: key, code: 'ASSUMED_GLOBAL_SCOPE',
      message: `sheet "${key}" has rows without a scope column that matched an existing global row by name — mark them scope="local" if they were meant as scenario-local content`,
    });
  }

  // Combined subject name/ref space for Exception object sets (a subject can be
  // any of the five entity kinds; a name/ref colliding across them is ambiguous).
  const subjectNameToIds = new Map();
  const subjectRefToIds = new Map();
  for (const key of WAIVER_SUBJECT_KEYS) {
    for (const [name, ids] of nameToResolved[key]) {
      subjectNameToIds.set(name, (subjectNameToIds.get(name) || []).concat(ids));
    }
    for (const [ref, id] of refToResolved[key]) {
      subjectRefToIds.set(ref, (subjectRefToIds.get(ref) || []).concat([id]));
    }
  }
  // vm_type by resolved vm id (for the db_instance requireVmType check). VMs are
  // pure-scenario, so resolvedId === minted id.
  const vmTypeById = new Map();
  for (const b of built.vms) if (b.dbRow.vm_type) vmTypeById.set(b.resolvedId, b.dbRow.vm_type);

  // Existing global ids that an inserted scenario row now references, keyed by
  // catalogue sheet key — the COMMIT path locks exactly these FOR UPDATE so a
  // concurrent global-catalogue delete cannot slip between the match and the
  // scenario-local FK insert (§17.1a / security M-1, TOCTOU).
  const referencedGlobals = {}; // key → Set(id)
  // Resolved global-rule ids already targeted by an override row this import —
  // uq_cap_rules_override is UNIQUE(scenario_id, overrides_rule_id); a second
  // row overriding the SAME global rule would 500 on the UNIQUE at INSERT, so it
  // is caught here as a clean structural error (mirrors the settings singleton).
  const seenOverrideTargets = new Set();

  // Rule pins whose target site is not present in this import, cleared and
  // reported once (see the params.site_id remap block below).
  let clearedRulePins = 0;

  // Phase 2 — resolve FK-by-name/ref columns + Exception object sets.
  for (const spec of SCENARIO_SPECS) {
    for (const b of built[spec.key]) {
      const push = (column, code, message) => errors.push({ sheet: spec.key, row: b.rowNum, column, code, message });

      for (const [fileCol, def] of Object.entries(spec.fk)) {
        let resolvedFk = null;
        const rawRef = def.refCol ? b.raw[def.refCol] : undefined;
        if (!isEmpty(rawRef)) {
          const id = refToResolved[def.target].get(String(rawRef));
          if (!id) { push(def.refCol, 'UNRESOLVED_REF', `${def.refCol} "${rawRef}" matches no ${def.target} ref`); continue; }
          resolvedFk = id;
        } else {
          const rawName = b.raw[fileCol];
          if (isEmpty(rawName)) {
            if (!def.nullable) push(fileCol, 'MISSING_FIELD', `${fileCol} (or ${def.refCol}) is required`);
            continue; // nullable unset → leave the id column absent (DB NULL/default)
          }
          const ids = nameToResolved[def.target].get(String(rawName)) || [];
          if (ids.length === 0) { push(fileCol, 'UNRESOLVED_REF', `${fileCol} "${rawName}" matches no ${def.target} row`); continue; }
          if (ids.length >= 2) { push(fileCol, 'UNRESOLVED_REF', `${fileCol} "${rawName}" matches ${ids.length} ${def.target} rows; use ${def.refCol} to disambiguate`); continue; }
          resolvedFk = ids[0];
        }
        // Parent-type guard (db_instances.vm_id → db_host).
        if (def.requireVmType && vmTypeById.get(resolvedFk) !== def.requireVmType) {
          const shown = !isEmpty(rawRef) ? rawRef : b.raw[fileCol];
          push(!isEmpty(rawRef) ? def.refCol : fileCol, 'INVALID_REF_TYPE', `"${shown}" must reference a ${def.requireVmType} VM`);
          continue;
        }
        // §17.1a mode 'global-row': an override targets a GLOBAL template rule.
        if (def.globalRow && !globalResolvedIds.has(resolvedFk)) {
          const shown = !isEmpty(rawRef) ? rawRef : b.raw[fileCol];
          push(!isEmpty(rawRef) ? def.refCol : fileCol, 'INVALID_REFERENCE',
            `${fileCol} "${shown}" must reference a global template rule (an override targets a global rule, not a scenario-local one)`);
          continue;
        }
        // At most one override per (scenario, global rule) — reject a second row
        // overriding the same global before it 500s on uq_cap_rules_override.
        if (def.globalRow) {
          if (seenOverrideTargets.has(resolvedFk)) {
            const shown = !isEmpty(rawRef) ? rawRef : b.raw[fileCol];
            push(!isEmpty(rawRef) ? def.refCol : fileCol, 'DUPLICATE_OVERRIDE',
              `two rules override the same global rule "${shown}" — at most one override per rule is allowed`);
            continue;
          }
          seenOverrideTargets.add(resolvedFk);
        }
        // Record a referenced EXISTING global row so the commit path can lock it.
        if (globalResolvedIds.has(resolvedFk)) {
          (referencedGlobals[def.target] || (referencedGlobals[def.target] = new Set())).add(resolvedFk);
        }
        b.dbRow[def.idCol] = resolvedFk;
      }

      // A custom group member references EXACTLY ONE of a VM / a DB instance.
      if (spec.memberXor) {
        const xorErr = validateGroupMemberXor(b.dbRow.member_vm_id ?? null, b.dbRow.member_instance_id ?? null);
        if (xorErr) push(undefined, xorErr.code, xorErr.message);
      }

      // A scenario-local VM profile's allowed_disk_combos is a JSON list of
      // disk-combo IDS — remap each through the SAME disk-combo resolution the FK
      // columns use (P2), so a target with regenerated ids does not silently
      // break the allow-list. Only for INSERTED (scenario-local) profiles — a
      // matched-global profile keeps its own global list. An id not present in
      // the workbook's disk_combos sheet is a readable structural error, not a
      // silent drop (the closure builder pulls allow-list-only combos, §17.4).
      if (spec.key === 'vm_profiles' && !b.matched && b.dbRow.allowed_disk_combos != null) {
        let list = null;
        try { list = JSON.parse(b.dbRow.allowed_disk_combos); } catch { list = null; }
        if (Array.isArray(list)) {
          const remapped = [];
          let bad = false;
          for (const rawId of list) {
            const resolved = refToResolved.disk_combos.get(String(rawId));
            if (!resolved) { push('allowed_disk_combos', 'UNRESOLVED_REF', `allowed_disk_combos references disk combo "${rawId}" not present in the import`); bad = true; break; }
            remapped.push(resolved);
          }
          if (!bad) b.dbRow.allowed_disk_combos = JSON.stringify(remapped);
        }
      }

      // A scenario-local keep-in-one-site rule pins the evaluator to a specific
      // cap_sites id at TOP-LEVEL params.site_id (evaluator.js — the exact
      // location rulePinnedSiteId reads and the site-delete sweep matches with
      // JSON_CONTAINS(params, JSON_QUOTE(?), '$.site_id')). The commit re-mints
      // every scenario site under a fresh uuid, so a pin carried verbatim from
      // the export names a site that no longer exists — an unsatisfiable rule no
      // health check reports (site-references.js top note), the params
      // counterpart of the dc_refs re-mint hole. Remap it through the SAME site
      // resolution the FK columns use: on a round trip each imported site carries
      // its original id as its `ref`, so `refToResolved.sites` maps the pinned
      // original id to the site's minted id (the allowed_disk_combos pattern
      // above). A pin resolving to no site in this import is CLEARED to the empty
      // string — the domain's "any single site" (RuleEditor `__any__`) — never
      // stored dead: the dc_refs / remapCarriedValue convention for a dangling
      // reference (drop + a per-column notice), and NEVER-BLOCK (§1.2) so a
      // round trip of a scenario that already held a broken pin still loads. Only
      // matched-global rules are excluded (not inserted); a global rule cannot
      // pin a site at all. The delete sweep is BYTE-EXACT, so remapping to the
      // stored spelling keeps every stored pin one the sweep can see.
      if (spec.ruleMatch && !b.matched && b.dbRow.params != null) {
        let paramsObj = null;
        try { paramsObj = JSON.parse(b.dbRow.params); } catch { paramsObj = null; }
        if (paramsObj !== null && typeof paramsObj === 'object' && !Array.isArray(paramsObj)
          && typeof paramsObj.site_id === 'string' && paramsObj.site_id !== '') {
          const resolved = refToResolved.sites.get(paramsObj.site_id);
          if (resolved != null) {
            paramsObj.site_id = resolved;
          } else {
            paramsObj.site_id = '';
            clearedRulePins += 1;
          }
          b.dbRow.params = JSON.stringify(paramsObj);
        }
      }

      if (spec.waiver) {
        const rawRefs = b.raw.object_refs;
        const rawNames = b.raw.object_names;
        let resolved = null;
        if (!isEmpty(rawRefs)) {
          resolved = resolveObjectSet(String(rawRefs), subjectRefToIds, 'object_refs', 'ref', push);
        } else if (!isEmpty(rawNames)) {
          resolved = resolveObjectSet(String(rawNames), subjectNameToIds, 'object_names', '', push);
        } else {
          push('object_names', 'MISSING_FIELD', 'object_names or object_refs is required');
        }
        if (resolved) b.dbRow.object_set_key = objectSetKey(resolved);
        b.dbRow.created_by = actorId ?? null;
      }
    }
  }

  // One notice per import for the cleared pins (the dc_refs DROPPED_STALE_REFERENCE
  // shape). Emitted from the PURE plan, so validate reports it too — a dry run
  // warns that a pin will be cleared, which the DB-dependent dc_refs drop notice
  // (commit-only) cannot.
  if (clearedRulePins > 0) {
    notices.push({
      sheet: 'rules', column: 'params', code: 'DROPPED_STALE_REFERENCE',
      message: `${clearedRulePins} rule(s) pinned a site not present in this import; the pin was cleared`,
    });
  }

  // Phase 2b — disk-combo allow-list on the RESULTING scenario rows (spec §5.3,
  // item D). The import commit is a profile+disk-pair write path (raw INSERT loop),
  // so it must honor the SAME allow-list invariant the wizard / child writes do —
  // else it is a live bypass. Built as a structural validation error (not a
  // commit-only 400) so validate/dry-run predicts commit exactly, and so a
  // same-workbook LOCAL profile (not yet in the DB at commit time) is covered from
  // the plan, not a not-yet-inserted row read. Allow-list source per resolved
  // profile id: a matched-global profile → existingGlobals; a scenario-local
  // profile → its remapped dbRow.allowed_disk_combos (Phase 2 above).
  const profileAllowById = new Map();
  for (const p of existingGlobals.vm_profiles || []) {
    if (p && p.id != null) profileAllowById.set(String(p.id), p.allowed_disk_combos);
  }
  for (const b of built.vm_profiles || []) {
    if (!b.matched && b.id != null) profileAllowById.set(String(b.id), b.dbRow.allowed_disk_combos);
  }
  const validatePairSheet = (key, profileCol) => {
    for (const b of built[key] || []) {
      const profileId = b.dbRow[profileCol];
      const comboId = b.dbRow.disk_combo_id;
      if (profileId == null || comboId == null) continue; // Custom / no-profile / no-disk
      if (!profileAllowById.has(String(profileId))) continue; // unresolved profile owns its own error
      if (!diskComboAllowed(profileAllowById.get(String(profileId)), comboId)) {
        errors.push({
          sheet: key, row: b.rowNum, column: 'disk_combo_name', code: 'DISK_COMBO_NOT_ALLOWED',
          message: 'disk combo is not in the chosen profile\'s allowed disk combos',
        });
      }
    }
  };
  validatePairSheet('vms', 'sizing_profile_id');
  validatePairSheet('databases', 'profile_id');

  // Phase 3 — settings: a matched global row is skipped (a scenario tracks the
  // global singleton, never rewrites it); a genuine override row is written
  // scenario-local. At most ONE override per scenario (singleton).
  const settingsBuilt = built.settings || [];
  const overrideSettings = [];
  for (const b of settingsBuilt) {
    // An invalid scope value (Phase 1 already raised INVALID_SCOPE, blocking
    // commit) never falls through to the global value-equality match either —
    // same "no fallback matching" rule as the catalogue/rule sheets above.
    if (!scopeIsInvalid(b.raw) && settingsIsGlobal(b.dbRow, b.refToken, scopeOf(b.raw), globalSettingsRows)) {
      b.matched = true; continue;
    }
    overrideSettings.push(b);
  }
  overrideSettings.slice(1).forEach((b) => {
    errors.push({ sheet: 'settings', row: b.rowNum, code: 'DUPLICATE', message: 'only one settings override row is allowed' });
  });

  // Tally per-sheet error counts.
  for (const e of errors) {
    if (stats.perSheet[e.sheet]) stats.perSheet[e.sheet].errors += 1;
  }

  // Plan: only the rows to INSERT scenario-local. A matched catalogue/rule row
  // (b.matched) is excluded — it contributes its global id to FK resolution but
  // is not re-created. Settings uses the resolved override rows.
  const plan = {};
  for (const spec of SCENARIO_SPECS) {
    if (spec.key === 'settings') {
      plan.settings = overrideSettings.map((b) => ({ id: b.id, dbRow: b.dbRow }));
    } else {
      plan[spec.key] = built[spec.key].filter((b) => !b.matched).map((b) => ({ id: b.id, dbRow: b.dbRow }));
    }
  }

  // Referenced existing-global ids per catalogue key (Sets → arrays) for the
  // commit lock pass.
  const referencedGlobalIds = {};
  for (const [key, set] of Object.entries(referencedGlobals)) referencedGlobalIds[key] = [...set];

  // Where each sheet's rows ENDED UP, by the two keys the importer resolves a
  // reference with: the row's own `ref` token and its folded name. Built from
  // the RESOLVED id, so a catalogue row matched to an existing global answers
  // with the global's id exactly as a declared FK to it does.
  //
  // Its consumer is the undeclared-column carry-over on the commit path, which
  // has to rewrite a reference the replace-all just re-minted. A name two rows
  // share resolves to nothing — the same refusal to guess `readUndeclaredColumns`
  // makes about which row replaces which.
  const resolvedRowIds = {};
  for (const spec of SCENARIO_SPECS) {
    const byRef = new Map();
    const byName = new Map();
    const ambiguousNames = new Set();
    for (const b of built[spec.key] || []) {
      const refKey = idKeyOf(b.refToken);
      if (refKey != null) byRef.set(refKey, b.resolvedId);
      const nameKey = nameKeyOf(b.name);
      if (nameKey == null) continue;
      if (byName.has(nameKey)) { ambiguousNames.add(nameKey); continue; }
      byName.set(nameKey, b.resolvedId);
    }
    for (const nameKey of ambiguousNames) byName.delete(nameKey);
    resolvedRowIds[spec.key] = { byRef, byName };
  }

  return {
    ok: errors.length === 0, errors, notices, stats, plan, referencedGlobalIds, resolvedRowIds,
  };
}

// Catalogue sheet key → table, for the commit lock pass (only the FK-target
// catalogues a scenario row can reference an EXISTING global row of).
const CATALOGUE_KEY_TABLE = Object.freeze({
  hardware_specs: TABLES.CAP_HARDWARE_SPECS,
  disk_combos: TABLES.CAP_DISK_COMBOS,
  teams: TABLES.CAP_TEAMS,
  vm_profiles: TABLES.CAP_VM_PROFILES,
  rules: TABLES.CAP_RULES,
});

/**
 * Lock the EXISTING global catalogue rows a commit is about to reference
 * (`referencedGlobalIds` from buildImportPlan) FOR UPDATE, in the SHARED canonical
 * table order (compareCatalogueTable) + sorted-id order within each table. Every
 * FOR-UPDATE-locking commit path (checkReferences lock mode, this import commit)
 * MUST use the same table order or two concurrent lockers touching the same global
 * rows can circular-wait (a Setup-Wizard commit and a scenario import racing the
 * same shared hardware-spec / disk-combo rows would otherwise deadlock, since
 * CATALOGUE_KEY_TABLE's declaration order reverses three pairs vs the canonical
 * order). Returns the first key whose referenced row vanished (a concurrent
 * global-catalogue delete), or null when every referenced global is still present.
 * Closes the TOCTOU window between fetchExistingGlobals's unlocked read and the
 * scenario-local FK INSERT (security M-1): while these rows are locked a concurrent
 * delete blocks, and once the scenario rows are committed the delete's own
 * reference guard (findCatalogueReferenceBlocker) sees the new reference and refuses.
 */
async function lockReferencedGlobals(conn, referencedGlobalIds) {
  const orderedKeys = Object.keys(CATALOGUE_KEY_TABLE)
    .sort((a, b) => compareCatalogueTable(CATALOGUE_KEY_TABLE[a], CATALOGUE_KEY_TABLE[b]));
  for (const key of orderedKeys) {
    const ids = (referencedGlobalIds && referencedGlobalIds[key]) || [];
    if (!ids.length) continue;
    const sorted = [...ids].map(String).sort();
    const placeholders = sorted.map(() => '?').join(', ');
    const rows = await conn.query(
      `SELECT id FROM \`${t(CATALOGUE_KEY_TABLE[key])}\` WHERE scenario_id IS NULL AND id IN (${placeholders}) FOR UPDATE`,
      sorted,
    );
    if (rows.length !== sorted.length) return key;
  }
  return null;
}

/**
 * Read the existing GLOBAL catalogue rows (scenario_id IS NULL) used for
 * match-first import resolution (§17.4). Only the columns the matcher needs
 * (id + name for catalogues/rules; the value columns for settings).
 */
async function fetchExistingGlobals(conn) {
  const nameRows = (table) => conn.query(`SELECT id, name FROM \`${t(table)}\` WHERE scenario_id IS NULL`);
  return {
    hardware_specs: await nameRows(TABLES.CAP_HARDWARE_SPECS),
    disk_combos: await nameRows(TABLES.CAP_DISK_COMBOS),
    teams: await nameRows(TABLES.CAP_TEAMS),
    // allowed_disk_combos rides along so buildImportPlan can validate a scenario
    // row's profile+disk pair against a MATCHED-global profile's allow-list (§5.3).
    vm_profiles: await conn.query(
      `SELECT id, name, allowed_disk_combos FROM \`${t(TABLES.CAP_VM_PROFILES)}\` WHERE scenario_id IS NULL`,
    ),
    rules: await nameRows(TABLES.CAP_RULES),
    settings: await conn.query(
      `SELECT id, mem_cpu_ratio, sga_factor, sga_divisor, sga_subtract, util_amber_pct, util_red_pct, `
      + `overcommit_default_enabled, layer_defaults FROM \`${t(TABLES.CAP_SETTINGS)}\` WHERE scenario_id IS NULL`,
    ),
  };
}

// ── Routes ────────────────────────────────────────────────────────────────────

const dbError = (req, res, err, fields) => sendError(req, res, err, { status: 500, code: 'INTERNAL_ERROR', reason: 'Database operation failed', fields });
const notFound = (req, res, message = 'Scenario not found') => sendError(req, res, null, { status: 404, code: 'NOT_FOUND', reason: message });
const forbidden = (req, res) => sendError(req, res, null, { status: 403, code: 'FORBIDDEN', reason: 'Not allowed: you do not own this scenario' });

// GET /scenarios/:scenarioId/export — snapshot-shaped projection (all authenticated).
router.get('/scenarios/:scenarioId/export', async (req, res) => {
  if (!requireAuth(req, res)) return;
  const scenarioId = req.params.scenarioId;
  let conn;
  try {
    conn = await pool.ro.getConnection();
    const rows = await conn.query(
      `SELECT 1 AS ok FROM \`${t(TABLES.CAP_SCENARIOS)}\` WHERE id = ?`, [scenarioId],
    );
    if (!rows.length) return notFound(req, res);
    const doc = await buildScenarioSnapshotDoc(conn, scenarioId);
    // Emit the reorderable sheets in persisted order_index order so a workbook's
    // ROW POSITION carries the drag-reorder (spec §6) — import re-seeds
    // order_index from row position, round-tripping the order. Scoped to the
    // export path only: the shared snapshot reader (version freeze / clone) is
    // untouched (a clone copies order_index verbatim; a freeze needs no ordering).
    for (const key of ORDER_CARRYING_KEYS) {
      if (Array.isArray(doc.tables[key])) doc.tables[key].sort(byOrderIndex);
    }
    res.json(apiOk(doc));
  } catch (err) {
    dbError(req, res, err, { scenarioId });
  } finally {
    if (conn) conn.release();
  }
});

// POST /scenarios/:scenarioId/import — validate | commit (owner+admin).
router.post('/scenarios/:scenarioId/import', async (req, res) => {
  if (!requireAdminOrEditor(req, res)) return;
  const scenarioId = req.params.scenarioId;
  const body = req.body || {};
  const mode = body.mode;
  if (mode !== 'validate' && mode !== 'commit') {
    return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: "mode must be 'validate' or 'commit'" });
  }
  const sheets = body.sheets;
  if (!sheets || typeof sheets !== 'object' || Array.isArray(sheets)) {
    return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'sheets must be an object keyed by sheet name' });
  }
  if (importPayloadTooLarge(sheets)) {
    return sendError(req, res, null, { status: 413, code: 'PAYLOAD_TOO_LARGE', reason: 'Import payload is too large' });
  }

  const actorId = req.user && req.user.id ? req.user.id : null;
  let conn;
  try {
    conn = await pool.rw.getConnection();
    await conn.beginTransaction();

    const access = await resolveScenarioWriteAccess(conn, scenarioId, req.user);
    if (!access.found) { await safeRollback(conn); return notFound(req, res); }
    if (!access.allowed) { await safeRollback(conn); return forbidden(req, res); }
    // The scenario's OWN id, from the gate that just resolved it, is the scope
    // for everything below. `WHERE id = ?` admits any spelling of it, so
    // stamping the URL segment into every re-inserted child row would leave the
    // whole scenario's content carrying a `scenario_id` no scenario's `id`
    // holds — found by every SQL reader, resolved by no JavaScript one. The
    // single-row write paths bind the stored id for this reason; a replace-all
    // does it for the entire scenario at once.
    const storedScenarioId = access.scenarioId;

    const existingGlobals = await fetchExistingGlobals(conn);
    const report = buildImportPlan(sheets, actorId, existingGlobals);

    if (mode === 'validate') {
      // Zero writes — always roll back the read-and-lock transaction.
      await safeRollback(conn);
      return res.json({ ok: report.ok, errors: report.errors, notices: report.notices, stats: report.stats });
    }

    // commit: NOTHING is written when the report has any structural error.
    if (!report.ok) {
      await safeRollback(conn);
      return res.status(422).json({ ok: false, errors: report.errors, notices: report.notices, stats: report.stats });
    }

    // X3 fix (degraded-schema family, F2 was member 1): a structurally-valid
    // renamed-RAC-member database row (the topology enum in this sheet's own
    // spec already accepts it, concern-2 fix) still reaches this commit's
    // INSERT on a schema whose `topology` COLUMN ENUM is physically narrow —
    // MariaDB rejects the value, an opaque 500. Gate here, before any write,
    // same check/message as the wizard/bulk-create write paths. H1
    // (round 1): checks BOTH renamed members — the base
    // `rac_multinode` value is exposed to this same gap, not only
    // `rac_multinode_standby`.
    const importedTopologies = new Set(
      report.plan.databases.filter((d) => d.dbRow).map((d) => d.dbRow.topology),
    );
    const renamedTopologiesImported = [TOPOLOGY.RAC_MULTINODE, TOPOLOGY.RAC_MULTINODE_STANDBY]
      .filter((topology) => importedTopologies.has(topology));
    for (const topology of renamedTopologiesImported) {
      if (await isRenamedTopologySchemaSupported(conn, topology, { cache: false })) continue;
      await safeRollback(conn);
      return sendError(req, res, null, { status: 409, code: 'TOPOLOGY_SCHEMA_UNSUPPORTED', reason: TOPOLOGY_SCHEMA_UNSUPPORTED_MSG });
    }

    // Lock the EXISTING global catalogue rows this commit references FOR UPDATE
    // before writing the scenario-local FKs (security M-1, TOCTOU): a concurrent
    // global-catalogue delete cannot slip in between the (unlocked) match read
    // and these INSERTs and leave a dangling reference. If a referenced global
    // vanished since the match, abort cleanly (409, nothing written).
    const vanishedKey = await lockReferencedGlobals(conn, report.referencedGlobalIds);
    if (vanishedKey) {
      await safeRollback(conn);
      return sendError(req, res, null, { status: 409, code: 'CONFLICT', reason: `A referenced global ${vanishedKey} was deleted during the import; re-export and try again` });
    }

    // Replace-all: drop every CONTENT row of the scenario (the 14 SNAPSHOT
    // tables — cap_versions is history, NOT content, and is deliberately left
    // untouched; global catalogue rows are scenario_id IS NULL and untouched by
    // the WHERE scenario_id = ? scope), then insert the resolved scenario-local
    // rows. The DELETE set (SNAPSHOT_TABLES) equals the INSERT set
    // (SCENARIO_SPECS) so no scenario-scoped table is wiped without being
    // re-populatable — a regression test asserts this.
    // What the sheet does not describe is READ BEFORE THE DELETE, because a
    // replace-all replaces what the workbook is about and must not silently
    // clear what it is silent about. Clearing looked like nothing at all: a
    // database's Primary/Standby SGA seeds simply became derived values and its
    // DC restriction disappeared, with no error and no notice. The child
    // instances' own `sga_gb` IS carried by the sheet, so after such an import
    // the parent said "derive" while the children held the old explicit numbers,
    // until the next database edit cascaded over them.
    //
    // TWO OF THOSE THREE COLUMNS ARE VALUES AND ONE IS A REFERENCE, and carrying
    // a reference is not the same act as carrying a value. `dc_refs` is a JSON
    // list of `cap_sites` ids, and the commit below re-mints every scenario row
    // under a fresh uuid — so the same carry that preserves an SGA seed writes a
    // restriction naming sites that no longer exist. Left dangling that is worse
    // than the clearing it replaced: NULL read as "all DCs" and was merely lossy,
    // while a list of dead ids admits NO site, so `filterDcCandidates` offers the
    // database nowhere to go and every already-placed VM reports itself outside
    // its own restriction. Each carried value therefore goes through
    // `remapCarriedValue`, which rewrites a reference to the id its row now holds
    // — by VALUE, so the rule covers whatever reference-shaped column is added
    // next rather than the one that was noticed.
    const preserved = await readUndeclaredColumns(conn, storedScenarioId);
    const carriesAnything = [...preserved.values()]
      .some((entry) => entry.columns.length && entry.byName.size);
    // Only paid for when something is actually carried: a scenario with no rows
    // on a sheet that has undeclared columns issues none of these reads.
    const replacedIdentity = carriesAnything
      ? await readReplacedRowIdentity(conn, storedScenarioId)
      : new Map();
    // Dropped references, tallied per sheet+column so the operator is told, once
    // per column, that part of a restriction did not survive — the same file
    // that reports an ignored sheet reports this.
    const droppedRefs = new Map();
    for (const { table } of SNAPSHOT_TABLES) {
      await conn.query(`DELETE FROM \`${t(table)}\` WHERE scenario_id = ?`, [storedScenarioId]);
    }
    for (const spec of SCENARIO_SPECS) {
      const carriesOrder = ORDER_CARRYING_KEYS.has(spec.key);
      let position = 0;
      for (const { id, dbRow } of report.plan[spec.key]) {
        const cols = [];
        const placeholders = [];
        const values = [];
        // Degraded schema: a warn-skipped add-column migration leaves a DECLARED
        // column (cap_vms.function_name) PHYSICALLY ABSENT, yet an export from an
        // upgraded instance round-trips a value for it. This replace-all INSERT
        // bypasses the CRUD factory's physical-column gate, so naming the absent
        // column would ER_BAD_FIELD_ERROR 500 and roll back the WHOLE import. Drop
        // any column the physical table lacks — the SAME filter config-import.js and
        // the direct write paths use, on the SAME writer connection (pool.rw) the
        // INSERT runs on. A non-empty carried value is silently omitted, matching
        // every other degraded write path (wizard / config / config-import /
        // settings): the column does not exist to store into, and a re-import once
        // the migration lands restores it. An empty/failed probe never drops a real
        // write (dropAbsentColumns' `id` fail-safe).
        const rawCols = Object.keys(dbRow);
        const filtered = await dropAbsentColumns(conn, spec.table, rawCols, rawCols.map((c) => dbRow[c]));
        filtered.cols.forEach((col, i) => {
          cols.push(`\`${col}\``);
          placeholders.push('?');
          values.push(filtered.values[i]);
        });
        // Carry the undeclared columns of the row this one replaces, matched by
        // the same NAME the importer resolves every other reference by. A row
        // the sheet introduces has nothing to carry and falls to the DDL's own
        // defaults, which is the right answer for a row nobody had yet.
        const carried = preserved.get(spec.key);
        const priorRow = carried && carried.byName.get(nameKeyOf(dbRow[spec.nameCol]));
        for (const col of (carried ? carried.columns : [])) {
          if (Object.prototype.hasOwnProperty.call(dbRow, col)) continue;
          if (!priorRow || !Object.prototype.hasOwnProperty.call(priorRow, col)) continue;
          // Every reference inside the value is rewritten to the id its row
          // holds after the re-mint; one that resolves to no row is dropped from
          // the list rather than stored dead, and a scalar column that IS such a
          // reference is not carried at all (it falls to the DDL default, which
          // is the coherent state this carry-over replaced).
          const noticeKey = `${spec.key}.${col}`;
          const carriedValue = remapCarriedValue(
            priorRow[col], replacedIdentity, report.resolvedRowIds,
            () => droppedRefs.set(noticeKey, (droppedRefs.get(noticeKey) || 0) + 1),
          );
          if (carriedValue === UNMAPPABLE) continue;
          cols.push(`\`${col}\``);
          placeholders.push('?');
          // A JSON column comes back from the driver as a parsed object; bound
          // straight back it stringifies as `[object Object]` and the column's
          // own json_valid CHECK refuses it. Re-serialised, it is the same
          // document it was — the same rule the clone path applies for the same
          // reason.
          values.push(carriedValue !== null && typeof carriedValue === 'object'
            ? JSON.stringify(carriedValue) : carriedValue);
        }
        cols.push('`id`', '`scenario_id`');
        placeholders.push('?', '?');
        values.push(id, storedScenarioId);
        // Re-seed order_index from sheet ROW POSITION (the export emitted these
        // in order_index order) so a drag-reorder survives an export→import
        // round-trip. The workbook has no order_index column, so dbRow never
        // carries one (buildImportPlan only reads declared columns) — no clash.
        if (carriesOrder) {
          cols.push('`order_index`');
          placeholders.push('?');
          values.push(position);
        }
        position += 1;
        await conn.query(
          `INSERT INTO \`${t(spec.table)}\` (${cols.join(', ')}) VALUES (${placeholders.join(', ')})`,
          values,
        );
      }
    }
    // A carried reference the workbook no longer contains is dropped rather than
    // stored dead, and saying so is half the fix: the state this replaces was a
    // silent one, and a restriction that quietly narrows is the same kind of
    // silence.
    for (const [noticeKey, count] of droppedRefs) {
      const [sheet, column] = noticeKey.split('.');
      report.notices.push({
        sheet,
        column,
        code: 'DROPPED_STALE_REFERENCE',
        message: `${count} reference(s) in the preserved "${column}" of sheet "${sheet}" named a row this import no longer contains and were dropped`,
      });
    }
    // The VMs sheet carries a host column AND a site column, and a workbook can
    // name two data centres for one KVM — the site column is resolved
    // independently of the host and neither is checked against the other. A
    // placed VM's DC IS its host's, so the derived value replaces whatever the
    // sheet said, in this same transaction: an import cannot be a door that
    // reintroduces the contradiction every other write path now closes. An
    // UNPLACED row keeps the sheet's site, which is its intended one.
    await syncVmSiteCache(conn, storedScenarioId);
    await conn.commit();
    return res.json({ ok: true, errors: [], notices: report.notices, stats: report.stats });
  } catch (err) {
    await safeRollback(conn);
    dbError(req, res, err, { scenarioId, mode });
  } finally {
    if (conn) conn.release();
  }
});

module.exports = router;
module.exports.buildImportPlan = buildImportPlan;
module.exports.importPayloadTooLarge = importPayloadTooLarge;
module.exports.MAX_IMPORT_BYTES = MAX_IMPORT_BYTES;
module.exports.SHEET_SPECS = SHEET_SPECS;
module.exports.SCENARIO_SPECS = SCENARIO_SPECS;
// Exposed for the lock-order regression test (io.js import commit vs the
// reference-integrity canonical order must agree — deadlock guard).
module.exports.lockReferencedGlobals = lockReferencedGlobals;
module.exports.CATALOGUE_KEY_TABLE = CATALOGUE_KEY_TABLE;
// Exposed so the carry-over's reference rewrite can be pinned without a DB: it
// is a pure function of the value, the rows the replace-all deleted and where
// the sheet's rows resolved to.
module.exports.remapCarriedValue = remapCarriedValue;
module.exports.UNMAPPABLE_CARRIED_REFERENCE = UNMAPPABLE;
module.exports.UNDECLARED_COLUMNS = UNDECLARED_COLUMNS;
// Exposed for the settings-diff schema-parity test: the claim these make is
// about a COLUMN SET, and a behavioural test cannot see a column that is
// missing from both the code and its fixture.
module.exports.SETTINGS_VALUE_COLS = SETTINGS_VALUE_COLS;
module.exports.SETTINGS_JSON_COLS = SETTINGS_JSON_COLS;
