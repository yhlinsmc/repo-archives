/**
 * decision-doc-scalar-only-gate — the server side of "a decision table
 * cannot condition on or fill a scalar-only-typed field".
 *
 * `decision-doc.js`'s `validateDecisionDoc` says explicitly that a
 * condition/output `field_key` is NOT checked against the blueprint's live
 * field list (the no-FK philosophy shared with `variant_overrides`), and
 * that is still true here for EXISTENCE — a stale key (the field was
 * deleted) is untouched by this gate, exactly as before. What was missing is
 * the FE runtime's own type refusal (`evaluate.ts` `scalarOnlyRefusal` /
 * `scalarOnlyConditionRefusal`, `SCALAR_ONLY_FIELD_TYPES`): a `table`,
 * `checkbox` or `date` field can be named as a condition or output through a
 * direct POST/PUT even though the FE never offers one and would silently
 * refuse to match or fill it — the write reports success while the runtime
 * never does what the document claims.
 *
 * SCALAR_ONLY_FIELD_TYPES is a hand-declared CJS twin of the FE's
 * `evaluate.ts` export of the same name, pinned byte-for-byte by
 * `docker-api/tests/unit/scalar-only-field-types-parity.test.js` against
 * the shared fixture both runtimes' parity tests read (same idiom as
 * `text-case-validate.js`'s `FREE_TEXT_FIELD_TYPES`) — never imported at
 * runtime (docker-api has no access to the FE's TS module), so drift is
 * caught by the test, not prevented by a shared import.
 */

const { TABLES, t } = require('./helpers');
const { parseDoc, keysOf } = require('./decision-output-claims');

// See the module doc above: kept in lockstep with the FE's
// `evaluate.ts` `SCALAR_ONLY_FIELD_TYPES` by
// `scalar-only-field-types-parity.test.js`, not by a shared import.
const SCALAR_ONLY_FIELD_TYPES = new Set(['table', 'checkbox', 'date']);

/**
 * The in-transaction guard for the `decision_tables` CRUD mount, composed
 * alongside `refuseDuplicateDecisionOutput` (see `index.js`'s wiring).
 *
 * Runs on both POST and PUT. JUDGED ON THE POST-STATE, not on the body alone
 * — mirrors `refuseDuplicateDecisionOutput`'s own `docInWrite`/`movesRow`
 * split for the identical reason: a write that names neither `doc` nor
 * `blueprint_id` changes no key reference and nothing new to check, but a PUT
 * that REPOINTS `blueprint_id` with no `doc` in the body carries the STORED
 * document's key references into a new blueprint's field list — a type
 * judgement nobody wrote down, the same gap that column's sibling guard next
 * door closes for the duplicate-output claim.
 *
 * @returns {Promise<{message: string, code: string, status: number}|null>}
 */
async function refuseScalarOnlyDecisionKeys(conn, req, data, ctx) {
  const write = data || {};
  const rowId = ctx && ctx.isUpdate ? (ctx.id || null) : null;
  const docInWrite = write.doc !== undefined;
  // A create names its blueprint but has no stored row to move.
  const movesRow = rowId !== null && write.blueprint_id != null;
  if (!docInWrite && !movesRow) return null;

  let doc = null;
  if (docInWrite) {
    doc = parseDoc(write.doc);
    if (!doc) return null; // malformed JSON — validateDecisionDoc's own floor already refuses this write
  }

  // The blueprint this write's keys resolve against: the body's own
  // blueprint_id on create, or on a PUT that repoints it; otherwise the
  // row's STORED blueprint_id, the same "post-state, not the body" reasoning
  // `refuseDuplicateDecisionOutput` documents for the identical column. The
  // same stored-row read supplies the doc when the write omits it (a
  // reparent-only PUT with no `doc` key) — `refuseDuplicateDecisionOutput`
  // runs first in this same mount's guard chain (index.js) and already took
  // this row's `FOR UPDATE` lock when `!docInWrite`, so this SELECT reads
  // that same locked, current row rather than an earlier snapshot; FOR UPDATE
  // repeated here anyway so this function is correct in isolation too and a
  // future reorder of the guard chain cannot silently reintroduce the gap.
  let blueprintId = write.blueprint_id;
  if (rowId && (!docInWrite || blueprintId == null)) {
    const table = t(TABLES.DECISION_TABLES);
    const rows = await conn.query(`SELECT blueprint_id, doc FROM \`${table}\` WHERE id = ? FOR UPDATE`, [rowId]);
    const stored = rows.length ? rows[0] : null;
    if (blueprintId == null) blueprintId = stored ? stored.blueprint_id : null;
    if (!docInWrite) doc = stored ? parseDoc(stored.doc) : null;
  }
  if (!doc) return null;
  if (blueprintId == null) return null;

  const keys = new Set([...keysOf(doc.conditions), ...keysOf(doc.outputs)]);
  if (keys.size === 0) return null;

  // Expanded placeholders, not a single `?` bound to the array: the mariadb
  // driver does not expand an array parameter across an `IN (?)` clause
  // (same convention as every other dynamic-length IN clause in this repo,
  // e.g. `routes-replace.js`'s deletedKeys IN clause).
  const keyList = [...keys];
  const placeholders = keyList.map(() => '?').join(', ');
  // FOR UPDATE: without this lock a concurrent field-type edit (e.g. text ->
  // date) can commit between this read and the decision-table INSERT/UPDATE
  // below, so the row this gate approved as scalar-only is no longer scalar
  // by the time it lands — lock the matched rows so the type check
  // serialises with any in-flight type change.
  const fieldRows = await conn.query(
    `SELECT field_key, field_type FROM \`${t(TABLES.BLUEPRINT_FIELDS)}\` WHERE blueprint_id = ? AND field_key IN (${placeholders}) FOR UPDATE`,
    [blueprintId, ...keyList],
  );
  for (const row of fieldRows) {
    if (!SCALAR_ONLY_FIELD_TYPES.has(row.field_type)) continue;
    return {
      status: 400,
      code: 'INVALID_DECISION_FIELD_TYPE',
      message: `'${row.field_key}' is a ${row.field_type} field, which a decision table cannot use `
        + 'as a condition or an output.',
    };
  }
  return null;
}

module.exports = {
  refuseScalarOnlyDecisionKeys,
  __test__: { SCALAR_ONLY_FIELD_TYPES },
};
