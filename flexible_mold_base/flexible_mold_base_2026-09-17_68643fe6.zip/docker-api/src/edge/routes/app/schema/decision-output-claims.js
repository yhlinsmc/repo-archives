/**
 * decision-output-claims — the server side of "a field can be filled by only
 * one decision table in this blueprint".
 *
 * The authoring UI has refused a second claim since the feature shipped. The
 * API never did, so a second tab, a retry after a timeout, an import, or any
 * non-UI client could store the state the UI exists to prevent — and the
 * runtime's answer to two live tables filling one field is to fill it from
 * NEITHER, so the field silently stops being filled and every surface reports
 * the tables as healthy.
 *
 * TWO CARVE-OUTS, BOTH LOAD-BEARING, both already decided:
 *
 * 1. A TABLE MAY ALWAYS RE-SELECT AN OUTPUT IT ALREADY OWNS. Without this an
 *    existing duplicate could never be repaired: the picker that would fix it
 *    refuses to open, and every save of the offending table is rejected for a
 *    column it is not adding.
 * 2. A TABLE WITH NO CONDITIONS BLOCKS NOBODY. It fills nothing at runtime, and
 *    "choose the output column first, add the condition after" is the ordinary
 *    authoring order — blocking on it would refuse the second step of a normal
 *    flow. The symmetric half is what keeps this enforceable rather than merely
 *    polite: an INERT incoming document is not refused either, and the write
 *    that later makes it live is itself checked, so the loop closes on the write
 *    that would actually create the collision.
 *
 * WHAT "LIVE" MEANS is the runtime's own definition, restated here because the
 * frontend copy of it (`isLiveDecisionDoc`) is across a boundary this file may
 * not import: a table with at least one condition, at least one output, and no
 * field on both sides. A field on both sides would re-trigger its own match, so
 * the engine ignores such a table entirely.
 */

const { TABLES, t, tableExistsInCurrentSchema } = require('./helpers');

/** Read a `doc` column, which the driver may hand back as text or as an object. */
function parseDoc(raw) {
  let doc = raw;
  if (typeof doc === 'string') {
    try { doc = JSON.parse(doc); } catch { return null; }
  }
  return doc && typeof doc === 'object' && !Array.isArray(doc) ? doc : null;
}

function keysOf(list) {
  if (!Array.isArray(list)) return [];
  return list
    .map((column) => (column && typeof column === 'object' ? column.field_key : null))
    .filter((key) => typeof key === 'string' && key !== '');
}

/**
 * Would this document fill anything at runtime? Mirrors `isLiveDecisionDoc`.
 * @param {object|null} doc
 */
function isLiveDoc(doc) {
  if (!doc) return false;
  const conditions = keysOf(doc.conditions);
  const outputs = keysOf(doc.outputs);
  if (conditions.length === 0 || outputs.length === 0) return false;
  const conditionSet = new Set(conditions);
  return !outputs.some((key) => conditionSet.has(key));
}

/**
 * The in-transaction guard for the `decision_tables` CRUD mount.
 *
 * Runs on both POST and PUT, before the write, on the write connection. The
 * `FOR UPDATE` is what makes it a guard rather than a suggestion: it holds the
 * blueprint's other tables until this write commits, so two clients claiming
 * the same output at the same time cannot both read "nobody owns it".
 *
 * JUDGED ON THE POST-STATE, not on the body. A body carrying no `doc` normally
 * changes no claim — but a PUT that repoints `blueprint_id` carries the STORED
 * document into a new set of siblings, which is a new claim nobody wrote down.
 * Reading only the body let that through with one call, and the sibling guard
 * next door already resolves its own post-state for the same reason
 * (routes-variant-overrides.js: "field_id is repointable and the stored document
 * survives a PATCH-style PUT").
 *
 * AND "THE POST-STATE" IS `data`, NOT `req.body`. The factory strips
 * `blueprint_id` from every non-administrator's update — that is what stops an
 * editor moving a row into a blueprint they do not own — so a guard reading the
 * BODY resolved a blueprint the UPDATE was never going to write. Both directions
 * were live: the stored row's own siblings were never read (its duplicate claim
 * landed unchecked, and the runtime's answer to two live tables filling one field
 * is to fill it from NEITHER), and the caller could be handed a 409 naming a
 * decision table in a blueprint they cannot see, with FOR UPDATE locks taken on
 * its rows.
 *
 * WHAT STILL PASSES WITHOUT A READ: a body that neither writes a document nor
 * moves the row, an incoming document that is inert, and a DB whose operator
 * account never got the table created.
 *
 * WHAT IS STILL NOT COVERED: a claim that becomes a duplicate without any write
 * to this table at all — the other table being moved IN, for instance, is
 * checked as that table's own write, but a blueprint merged by any path that
 * does not go through this mount is not re-judged.
 *
 * @returns {Promise<{message: string, code: string, status: number}|null>}
 */
async function refuseDuplicateDecisionOutput(conn, req, data, ctx) {
  const write = data || {};
  const rowId = ctx && ctx.isUpdate ? (ctx.id || null) : null;
  const docInWrite = write.doc !== undefined;
  // A create names its blueprint but has no stored row to move.
  const movesRow = rowId !== null && write.blueprint_id != null;
  if (!docInWrite && !movesRow) return null;

  let incoming = null;
  if (docInWrite) {
    incoming = parseDoc(write.doc);
    // Carve-out 2, incoming half: an inert document fills nothing, so it takes
    // nothing from anyone. The write that makes it live is checked on its own.
    // Checked before any read, and safe to: a body carrying `doc` states the
    // whole post-state document, move or no move.
    if (!isLiveDoc(incoming)) return null;
  }

  const table = t(TABLES.DECISION_TABLES);
  if (!(await tableExistsInCurrentSchema(conn, table))) return null;

  // Resolve the blueprint the same way the write will: from the write body when
  // it is there (create, or a PUT that moves the row), otherwise from the stored
  // row. The same read supplies the stored document when the write omits it.
  let blueprintId = write.blueprint_id;
  if (rowId && (!docInWrite || blueprintId == null)) {
    const current = await conn.query(
      `SELECT blueprint_id, doc FROM \`${table}\` WHERE id = ? FOR UPDATE`,
      [rowId],
    );
    const stored = current.length ? current[0] : null;
    if (blueprintId == null) blueprintId = stored ? stored.blueprint_id : null;
    if (!docInWrite) incoming = stored ? parseDoc(stored.doc) : null;
  }
  // Carve-out 2 again, for the document this row is CARRYING rather than
  // writing: an inert stored document claims nothing wherever it is moved.
  if (!isLiveDoc(incoming)) return null;
  if (blueprintId == null) return null;

  // Carve-out 1 is this WHERE clause: the row being written is not one of its
  // own competitors, so re-selecting an output it already owns is never a second
  // claim.
  //
  // DELIBERATELY UNBOUNDED, and the bound that matters is elsewhere. Every
  // sibling table in the blueprint is read and locked for the length of this
  // transaction. A LIMIT would not make that cheaper in any way worth having —
  // it would make the guard WRONG, because the table it skipped is exactly the
  // one that may hold the colliding claim, and a duplicate-output check that
  // sometimes looks is not a check. The real bound is the data: one row per
  // decision table per blueprint, authored by hand, and a blueprint cannot have
  // more of them than it has fields. The query is a single round trip on
  // `idx_decision_tables_blueprint`, so what scales is the lock's width, not the
  // work. If a blueprint ever holds enough tables for that to bite, the answer
  // is a UNIQUE index on the claim itself, not a partial read.
  const others = rowId
    ? await conn.query(
      `SELECT name, doc FROM \`${table}\` WHERE blueprint_id = ? AND id <> ? FOR UPDATE`,
      [blueprintId, rowId],
    )
    : await conn.query(
      `SELECT name, doc FROM \`${table}\` WHERE blueprint_id = ? FOR UPDATE`,
      [blueprintId],
    );

  const claimed = new Map();
  for (const row of others) {
    const doc = parseDoc(row.doc);
    // Carve-out 2, stored half.
    if (!isLiveDoc(doc)) continue;
    for (const key of keysOf(doc.outputs)) {
      if (!claimed.has(key)) claimed.set(key, row.name);
    }
  }

  for (const key of keysOf(incoming.outputs)) {
    if (!claimed.has(key)) continue;
    const owner = String(claimed.get(key) || '').trim();
    return {
      status: 409,
      code: 'DUPLICATE_DECISION_OUTPUT',
      message: `'${key}' is already filled by ${owner ? `the decision table '${owner}'` : 'another decision table'}. `
        + 'A field can be filled by only one decision table in this blueprint.',
    };
  }
  return null;
}

module.exports = {
  refuseDuplicateDecisionOutput,
  // `parseDoc`/`keysOf` promoted to real exports: the sibling scalar-only-
  // type gate (decision-doc-scalar-only-gate.js) needs the SAME
  // "the driver may hand doc back as text or as an object" tolerance and the
  // same condition/output key extraction this file already owns for the
  // identical `decision_tables.doc` column — a second copy of either is the
  // defect the owner rule (CLAUDE.md §4c) exists to prevent. Kept under
  // `__test__` too so no existing test import path changes.
  parseDoc,
  keysOf,
  __test__: { isLiveDoc, parseDoc, keysOf },
};
