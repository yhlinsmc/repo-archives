import { describe, it, expect } from 'vitest';

const { MIGRATION_STEPS } = require('../migration-steps');
const { findDoubleEncodedOutputKeys } = require('../lib/outputs-double-encode');

const identityT = (base) => base;
const STEP = MIGRATION_STEPS.find((s) => s.step === 'flow_outputs_contract_v2_unwrap');

// A stateful fake connection over three code columns, faithful to the two queries
// the migration issues: the information_schema existence probe, the LIKE prefilter
// SELECT, and the per-row UPDATE. No real DB — the rewrite correctness lives in
// outputs-double-encode.test.js; this pins the SELECT→rewrite→UPDATE wiring and
// that the probe re-reads the updated rows.
function makeConn(store) {
  return {
    updates: [],
    async query(sql, params) {
      if (/information_schema\.TABLES/.test(sql)) {
        // The probe/run ask which of the target tables exist, in one IN(...) query.
        return (params || []).map((name) => ({ TABLE_NAME: name }));
      }
      const sel = /SELECT id, `(\w+)` AS code FROM `(\w+)`/.exec(sql);
      if (sel) {
        const [, column, table] = sel;
        return (store[`${table}.${column}`] || [])
          .filter((r) => r.code.includes('JSON.stringify'))
          .map((r) => ({ id: r.id, code: r.code }));
      }
      const upd = /UPDATE `(\w+)` SET `(\w+)` = \? WHERE id = \?/.exec(sql);
      if (upd) {
        const [, table, column] = upd;
        const [code, id] = params;
        this.updates.push({ table, column, id, code });
        const rows = store[`${table}.${column}`] || [];
        const row = rows.find((r) => r.id === id);
        if (row) row.code = code;
        return { affectedRows: 1 };
      }
      throw new Error(`unexpected query: ${sql}`);
    },
  };
}

describe('flow_outputs_contract_v2_unwrap migration step', () => {
  // Keys are `<physical table>.<column>` — identityT leaves TABLES values
  // unprefixed (flow_recipe_steps / flow_recipes), matching the SELECT text.
  const seed = () => ({
    'flow_recipe_steps.before_code': [
      { id: 's1', code: 'return { outputs: { external_id: JSON.stringify(String(payload.external_id)) } };' },
      { id: 's2', code: 'return { outputs: { external_id: String(payload.external_id) } };' }, // already bare
    ],
    'flow_recipe_steps.after_code': [
      { id: 's3', code: 'return { outputs: { remote_refs: JSON.stringify(Object.fromEntries(x)) } };' },
    ],
    'flow_recipes.payload_transform_code': [
      { id: 'r1', code: 'return { outputs: { workflow: JSON.stringify({ a: 1 }) } };' },
    ],
  });

  it('the registry entry carries probe + run + remediationSql', () => {
    expect(typeof STEP.run).toBe('function');
    expect(typeof STEP.probe).toBe('function');
    expect(typeof STEP.remediationSql).toBe('function');
  });

  it('probe reports pending while any column holds a double-encoded value, satisfied once none do', async () => {
    const store = seed();
    const conn = makeConn(store);
    expect(await STEP.probe(conn, identityT)).toBe(false);
    await STEP.run({ conn, t: identityT, TABLES: {}, logger: null });
    expect(await STEP.probe(conn, identityT)).toBe(true);
  });

  it('run() unwraps only the double-encoded rows and stores the bare value', async () => {
    const store = seed();
    const conn = makeConn(store);
    await STEP.run({ conn, t: identityT, TABLES: {}, logger: null });
    // Three double-encoded rows updated; the already-bare s2 is not touched.
    expect(conn.updates.map((u) => u.id).sort()).toEqual(['r1', 's1', 's3']);
    for (const u of conn.updates) {
      expect(u.code).not.toContain('JSON.stringify');
      expect(findDoubleEncodedOutputKeys(u.code)).toEqual([]);
    }
    const s1 = conn.updates.find((u) => u.id === 's1');
    expect(s1.code).toBe('return { outputs: { external_id: String(payload.external_id) } };');
  });

  it('run() is idempotent — a second run issues no further updates', async () => {
    const store = seed();
    const conn = makeConn(store);
    await STEP.run({ conn, t: identityT, TABLES: {}, logger: null });
    const first = conn.updates.length;
    await STEP.run({ conn, t: identityT, TABLES: {}, logger: null });
    expect(conn.updates.length).toBe(first);
  });

  // Every shape the rewriter may meet in a stored column, each asserting whether
  // run() rewrites it, leaves it, and/or reports it — and that a SECOND run over
  // the same store issues zero further updates (idempotence for EVERY shape, not
  // only the clean ones).
  it('run() rewrites clean shapes, leaves adversarial ones, and is idempotent across all of them', async () => {
    const store = {
      'flow_recipe_steps.before_code': [
        { id: 'clean', code: 'return { outputs: { external_id: JSON.stringify(String(payload.id)) } };' },
        { id: 'bare', code: 'return { outputs: { external_id: String(payload.id) } };' },
        { id: 'quoted', code: 'return { outputs: { "api-key": JSON.stringify(payload.k) } };' },
        { id: 'multi', code: 'return { outputs: { a: JSON.stringify(x), b: payload.b, c: JSON.stringify(y) } };' },
        { id: 'extra-args', code: 'return { outputs: { a: JSON.stringify(x, null, 2) } };' },
        { id: 'nested', code: 'return { outputs: { a: JSON.stringify(JSON.stringify(x)) } };' },
        { id: 'in-string', code: 'var s = "outputs: { a: JSON.stringify(x) }"; return { outputs: { b: payload.b } };' },
        { id: 'in-comment', code: '// outputs: { a: JSON.stringify(x) }\nreturn { outputs: { b: payload.b } };' },
        { id: 'not-a-literal', code: 'var o = build(); o.a = JSON.stringify(x); return { outputs: o };' },
      ],
    };
    const conn = makeConn(store);
    await STEP.run({ conn, t: identityT, TABLES: {}, logger: null });
    // Only rows with a clean, mechanically unwrappable value are updated.
    expect(conn.updates.map((u) => u.id).sort()).toEqual(['clean', 'multi', 'quoted']);
    const codeOf = (id) => store['flow_recipe_steps.before_code'].find((r) => r.id === id).code;
    expect(codeOf('clean')).toBe('return { outputs: { external_id: String(payload.id) } };');
    expect(codeOf('quoted')).toBe('return { outputs: { "api-key": payload.k } };');
    expect(codeOf('multi')).toBe('return { outputs: { a: x, b: payload.b, c: y } };');
    // Adversarial shapes are LEFT byte-for-byte — never a partial or one-level unwrap.
    expect(codeOf('extra-args')).toBe('return { outputs: { a: JSON.stringify(x, null, 2) } };');
    expect(codeOf('nested')).toBe('return { outputs: { a: JSON.stringify(JSON.stringify(x)) } };');
    expect(codeOf('in-string')).toContain('"outputs: { a: JSON.stringify(x) }"');
    expect(codeOf('not-a-literal')).toContain('o.a = JSON.stringify(x)');
    // A second run over the SAME store issues no further updates for any shape.
    const first = conn.updates.length;
    await STEP.run({ conn, t: identityT, TABLES: {}, logger: null });
    expect(conn.updates.length).toBe(first);
  });

  it('remediationSql surfaces one SELECT per stored code column, all non-empty via t(TABLES.X)', () => {
    const sql = STEP.remediationSql(identityT);
    expect(sql).toHaveLength(3);
    for (const stmt of sql) {
      expect(typeof stmt).toBe('string');
      expect(stmt.trim().length).toBeGreaterThan(0);
      expect(stmt).toMatch(/^SELECT id FROM/);
    }
  });
});
