const { TABLES } = require('./shared/constants');

/**
 * table-ddls.js — Centralized DDL definitions for all MariaDB tables.
 *
 * Three builders let callers create exactly the tables they need:
 *   buildInfraTableDDLs(t)    — 8 infra tables: users, login_audit, system_settings, db_connections,
 *                               access_rules, feature_audit, service_accounts, service_account_idempotency
 *   buildEngineTableDDLs(t)  — 38 engine tables: the 19 core engine tables (hierarchy_nodes,
 *                               blueprint_fields, field_options, blueprint_sections, blueprint_groups,
 *                               blueprint_output_order, variant_overrides, user_templates, transformers,
 *                               transformer_versions, api_connectors, flow_recipes, flow_recipe_steps,
 *                               flow_recipe_runs, flow_recipe_code_versions, decision_tables,
 *                               delegated_grants, template_activity, template_snapshots) plus the 19 `cap_*`
 *                               Capacity Planner app-tier tables
 *   buildAllTableDDLs(t)      — all 46 tables (infra + engine)
 *
 * Each builder accepts the t() prefix function as its argument so the prefix
 * is evaluated at call time (not at module load time). This allows callers to
 * pass a custom prefix function for dynamic pool routing.
 *
 * Usage:
 *   const { buildEngineTableDDLs } = require('./table-ddls');
 *   const { t } = require('./db');
 *   for (const ddl of buildEngineTableDDLs(t)) await conn.query(ddl);
 *
 */

function buildInfraTableDDLs(t) {
  return [
    // NOTE: optional read-endpoint columns mirror the writer set so an
    // operator can point pool.ro at a physical replica or a read-only user
    // on the same host. All four NULL → pool.ro falls back to the writer
    // (see pool-manager.js:getInfraReadPool). read_* appear here for fresh
    // installs; existing deployments pick them up via the idempotent ALTER
    // in runSchemaMigrations() (db.js) at boot.
    `CREATE TABLE IF NOT EXISTS \`${t(TABLES.DB_CONNECTIONS)}\` (
      id                      CHAR(36)     PRIMARY KEY DEFAULT (UUID()),
      name                    VARCHAR(255) NOT NULL,
      db_type                 VARCHAR(50)  NOT NULL DEFAULT 'mariadb',
      host                    VARCHAR(255) NOT NULL,
      port                    INT          NOT NULL DEFAULT 3306,
      database_name           VARCHAR(255),
      username                VARCHAR(255),
      encrypted_password      TEXT,
      read_host               VARCHAR(255) NULL,
      read_port               INT          NULL,
      read_username           VARCHAR(255) NULL,
      read_encrypted_password TEXT         NULL,
      extra_config            JSON,
      is_active               BOOLEAN      NOT NULL DEFAULT FALSE,
      created_by              CHAR(36),
      created_at              TIMESTAMP    DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

    `CREATE TABLE IF NOT EXISTS \`${t(TABLES.LOGIN_AUDIT)}\` (
      id            CHAR(36)     PRIMARY KEY DEFAULT (UUID()),
      username      VARCHAR(255) NOT NULL,
      auth_provider ENUM('LOCAL','KEYCLOAK','SUPABASE','client_credentials','machine_token') NOT NULL DEFAULT 'LOCAL',
      deptid        VARCHAR(255),
      reason        VARCHAR(255) NULL,
      login_at      TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
      ip_address    VARCHAR(45),
      user_agent    TEXT,
      success       BOOLEAN      DEFAULT TRUE,
      INDEX idx_login_audit_user_time (username, login_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

    `CREATE TABLE IF NOT EXISTS \`${t(TABLES.SYSTEM_SETTINGS)}\` (
      id          CHAR(36)      PRIMARY KEY DEFAULT (UUID()),
      \`key\`     VARCHAR(255)  NOT NULL UNIQUE,
      value       JSON,
      description TEXT,
      updated_by  VARCHAR(255),
      created_at  TIMESTAMP     DEFAULT CURRENT_TIMESTAMP,
      updated_at  TIMESTAMP     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

    `CREATE TABLE IF NOT EXISTS \`${t(TABLES.USERS)}\` (
      id            CHAR(36)      PRIMARY KEY,
      email         VARCHAR(255)  NOT NULL UNIQUE,
      password_hash VARCHAR(255)  NULL,
      display_name  VARCHAR(255),
      role          ENUM('admin','editor','user') NOT NULL DEFAULT 'user',
      banned        BOOLEAN       NOT NULL DEFAULT FALSE,
      keycloak_sub  VARCHAR(128)  NULL UNIQUE,
      deptid        VARCHAR(255)  NULL,
      kc_username   VARCHAR(255)  NULL,
      user_id       INT           NULL,
      created_at    TIMESTAMP     DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

    `CREATE TABLE IF NOT EXISTS \`${t(TABLES.ACCESS_RULES)}\` (
      id          CHAR(36)      PRIMARY KEY DEFAULT (UUID()),
      rule_type   ENUM('deptid','user') NOT NULL,
      rule_value  VARCHAR(255)  NOT NULL,
      role        ENUM('admin','editor','user') NOT NULL DEFAULT 'user',
      enabled     BOOLEAN       NOT NULL DEFAULT TRUE,
      created_by  CHAR(36),
      created_at  TIMESTAMP     DEFAULT CURRENT_TIMESTAMP,
      updated_at  TIMESTAMP     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      UNIQUE KEY uq_rule (rule_type, rule_value)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

    // NOTE: lightweight feature audit log mirroring the login_audit pattern.
    // Recorded events: transformer.execute.success/fail, grid.paste.event,
    // migration.ran, draft.saved, zero-cleanup.ran.
    `CREATE TABLE IF NOT EXISTS \`${t(TABLES.FEATURE_AUDIT)}\` (
      id          CHAR(36)      PRIMARY KEY DEFAULT (UUID()),
      event_type  VARCHAR(64)   NOT NULL,
      user_id     CHAR(36)      NULL,
      metadata    JSON          NULL,
      created_at  TIMESTAMP     DEFAULT CURRENT_TIMESTAMP,
      INDEX idx_feature_audit_event_time (event_type, created_at),
      INDEX idx_feature_audit_user_time (user_id, created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

    // Public Integration API (Auth v2.1): registered machine keys. token_hash is
    // SHA-256 hex of the app-issued API key, never the key itself — compared via
    // crypto.timingSafeEqual, never `===`. token_prefix is a short non-secret
    // display fragment for the admin surface.
    `CREATE TABLE IF NOT EXISTS \`${t(TABLES.SERVICE_ACCOUNTS)}\` (
      id            CHAR(36)     PRIMARY KEY DEFAULT (UUID()),
      token_hash    CHAR(64)     NOT NULL UNIQUE,
      token_prefix  VARCHAR(12)  NOT NULL DEFAULT '',
      scope         JSON         NOT NULL,
      label         VARCHAR(255) NOT NULL DEFAULT '',
      is_active     TINYINT(1)   NOT NULL DEFAULT 1,
      owner_id      CHAR(36)     NULL,
      created_at    DATETIME     DEFAULT CURRENT_TIMESTAMP,
      last_used_at  DATETIME     NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

    // Public Integration API (P3): idempotency-key replay cache for machine
    // write requests. Table ships now (P1) so the DDL/sync-exclusion contract
    // is settled before any route reads/writes it; unused until P3.
    `CREATE TABLE IF NOT EXISTS \`${t(TABLES.SERVICE_ACCOUNT_IDEMPOTENCY)}\` (
      id                  CHAR(36)     PRIMARY KEY DEFAULT (UUID()),
      service_account_id  CHAR(36)     NOT NULL,
      idempotency_key     VARCHAR(128) NOT NULL,
      body_fingerprint    CHAR(64)     NOT NULL,
      response_status     SMALLINT     NOT NULL,
      response_body       JSON         NULL,
      created_at          DATETIME     DEFAULT CURRENT_TIMESTAMP,
      expires_at          DATETIME     NOT NULL,
      UNIQUE KEY uq_sa_idem (service_account_id, idempotency_key)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

    // NOTE: sentinel row for admin-recovery promote-first-admin lock.
    // Route handler does `SELECT ... FOR UPDATE` on this row to serialize
    // mode-reachability check + UPDATE under concurrent recovery attempts.
    // INSERT IGNORE makes this idempotent across re-runs of ensureInfrastructure.
    `INSERT IGNORE INTO \`${t(TABLES.SYSTEM_SETTINGS)}\` (\`key\`, value, description)
     VALUES ('_promote_lock', JSON_OBJECT(), 'Sentinel row for admin-recovery promotion lock — do not modify')`,
  ];
}

function buildEngineTableDDLs(t) {
  return [
    `CREATE TABLE IF NOT EXISTS \`${t(TABLES.HIERARCHY_NODES)}\` (
      id                   CHAR(36)     PRIMARY KEY DEFAULT (UUID()),
      parent_id            CHAR(36),
      name                 VARCHAR(255) NOT NULL,
      -- v3.2.99 ENUM enforces the four-level hierarchy convention
      -- (Generation L1 → Release L2 → Blueprint L3 → Variant L4). Existing
      -- VARCHAR columns are migrated by runSchemaMigrations()'s v3.2.99
      -- block. CRUD-only operator accounts that lack ALTER fall back to
      -- runtime convention; boot-banner warns when the DDL is still
      -- VARCHAR so a DBA notices the gap.
      -- CONTRACT phase (Generation→Category): ENUM narrowed to the 4-value
      -- category-only set. A DB still carrying transition-era 'generation' rows
      -- is narrowed by runSchemaMigrations' self-guarded contract step once the
      -- data is clean (it refuses the narrow while 'generation' rows remain).
      node_type            ENUM('category','release','blueprint','variant') NOT NULL,
      description          TEXT,
      -- v3.2.0 Q7: nullable so the user can leave "no preference" instead of forcing 0
      sort_order           INT          NULL     DEFAULT NULL,
      is_active            BOOLEAN      NOT NULL DEFAULT TRUE,
      transformer_id       CHAR(36),
      transformer_version  VARCHAR(50),
      linked_blueprint_id  CHAR(36),
      -- v3.2.99 (Bug-4): owner-on-create per-row scoping. NULL means
      -- "shared (no owner)" — admin-created blueprints default to NULL so
      -- any editor can pick them up; editor-created blueprints get their
      -- creator's id. Only admins may PATCH this column post-create.
      owner_id             CHAR(36)     NULL     DEFAULT NULL,
      -- Per-blueprint auto-naming template: a free-text string carrying
      -- {{field_key}} tokens (the connector token grammar, connector-vars.ts) a
      -- record's name is composed from. NULL = no rule (no auto-name affordance).
      -- Meaningful on blueprint rows only by convention; variants and structural
      -- nodes leave it NULL. Y-pattern (SDD §8.3): the API boundary coalesces
      -- NULL -> '' (dto-mapper hierarchy_nodes.nullableStrings) so the TS
      -- interface types it a non-nullable string. TEXT (not VARCHAR) matches the
      -- free-text sibling description and leaves the template length unbounded.
      naming_rule          TEXT         NULL     DEFAULT NULL,
      created_at           TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
      updated_at           TIMESTAMP    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      -- Every reader that asks "which blueprints link to this one" —
      -- resolveEffectiveBlueprintIds (routes-field-ops.js) and its FOR UPDATE
      -- lock over the same predicate chief among them — filters on this column
      -- directly; without the index each call full-scans hierarchy_nodes, and
      -- the locking variant would need to examine (and therefore risk locking)
      -- every row rather than only the ones the predicate matches.
      INDEX idx_hierarchy_nodes_linked_blueprint (linked_blueprint_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

    `CREATE TABLE IF NOT EXISTS \`${t(TABLES.BLUEPRINT_FIELDS)}\` (
      id               CHAR(36)     PRIMARY KEY DEFAULT (UUID()),
      blueprint_id     CHAR(36),
      field_key        VARCHAR(255) NOT NULL,
      field_label      VARCHAR(255),
      -- The member list is NOT here: this is a VARCHAR rather than an ENUM, so
      -- the domain is declared once in
      -- edge/routes/app/schema/field-type-domain.js and read from there by both
      -- write paths. Nullability IS stated, because the write-time domain gate
      -- derives "may a null be written" from this line and refuses to guess when
      -- the line does not say (crud-factory.js, enumNotNullColumns). No change
      -- to any existing database: a VARCHAR declared without NOT NULL is
      -- already exactly this.
      field_type       VARCHAR(100) NULL     DEFAULT NULL,
      is_required      BOOLEAN      DEFAULT FALSE,
      default_value    TEXT,
      placeholder      TEXT,
      tooltip          TEXT,
      section          VARCHAR(255),
      -- Key reference into blueprint_groups.group_key, mirroring how
      -- section references blueprint_sections.section_key. NULL = field
      -- is not assigned to an identity lane.
      group_key        VARCHAR(255) NULL DEFAULT NULL,
      -- Key reference into blueprint_groups.group_key identifying which lane a
      -- field occupies as a matrix row, mirroring group_key. NULL = field is
      -- not placed as a matrix row.
      matrix_row_key   VARCHAR(255) NULL DEFAULT NULL,
      -- v3.2.0 Q7: nullable so a blank input distinguishes "unset" from "0"
      order_index      INT          NULL     DEFAULT NULL,
      table_config     JSON,
      visibility_rule  JSON,
      depends_on_field_key VARCHAR(255) NULL DEFAULT NULL,
      retain_when_hidden BOOLEAN    DEFAULT FALSE,
      -- Additive JSON column: checkbox (multi-select) selection limits
      -- { minSelected, maxSelected }. NULL for every other field type. An
      -- existing DB gets it via the guarded ALTER migration in db.js.
      choice_config    JSON,
      -- Blueprint-level policy, applying across every variant of the blueprint.
      -- A variant override of the same action replaces it outright for that
      -- variant; there is no "unlock" action.
      --
      -- value_source names WHICH of the four field-owned modes fills this
      -- field, and is the only column a reader consults to find that out.
      -- Vocabulary + the mode/payload agreement rules live in
      -- docker-api/src/shared/field-value-source.js; the write boundary refuses
      -- a mode whose payload columns say something else (a 'calculated' row
      -- with no compute_rule, an 'entered' row carrying one).
      --
      -- THE DEFAULT IS NOT A MIGRATION. 'entered' reproduces a pre-existing row
      -- only when that row carried neither a compute_rule nor is_locked=1; for
      -- any other row it silently stops the rule applying and leaves a
      -- combination the boundary above refuses on the next save. Carrying the
      -- legacy state across is a separate registry step
      -- (blueprint_fields_value_source_translate_legacy), ordered before the
      -- is_locked drop. An earlier version of this sentence read "no backfill",
      -- which is how the step came to be missing in the first place.
      --
      -- Discrete columns rather than one JSON policy bag, so a write names the
      -- columns it changes and leaves the rest alone; a bag would turn every
      -- write into a read-modify-write that clobbers keys the client did not
      -- send. Note this is NOT a statement that a payload column may be PATCHed
      -- on its own — MODE_OWNED_COLUMNS refuses exactly that, and the field
      -- editor PUTs the whole form. It was, before the mode column existed.
      value_source     VARCHAR(32)  NOT NULL DEFAULT 'entered',
      -- Cell-level scope for value_source on a table-type field:
      -- { rows: number[] | null, columns: string[] | null }, the same document
      -- variant_overrides.cell_targets holds. NULL / absent / empty means the
      -- mode applies to the whole field. Only the modes that a table field can
      -- carry ('copied', 'calculated', 'locked') may set it; the write boundary
      -- refuses it on any other field type, exactly as it does for table_config.
      value_scope      JSON         NULL,
      -- VARCHAR rather than an ENUM (mirrors the field_type comment above):
      -- the domain (none | upper | lower | title) is declared once in
      -- src/fmb/lib/compute/case-mode.ts and read from there by the write
      -- boundary (docker-api/src/edge/lib/text-case-validate.js). NULL = free
      -- text, today's behaviour — offered only on text/textarea fields.
      text_case        VARCHAR(16)  NULL     DEFAULT NULL,
      compute_rule     JSON         NULL,
      -- Dynamic option source (Q1-Q8, dynamic-field-options design): NULL =
      -- today's behaviour, options come from field_options rows. Non-null
      -- names another field of this blueprint or an API connector fetch as
      -- the live option list; mutually exclusive with depends_on_field_key
      -- (enforced by the parser in src/fmb/lib/option-source/, not by SQL).
      -- Purely additive — an existing DB gets it via the guarded ALTER
      -- migration in db.js.
      options_source   JSON         NULL,
      -- Holds the tri-state boolean's per-field "when empty" policy: omit the
      -- key or send null; only meaningful on an optional boolean field (the
      -- write boundary refuses it on any other field type, exactly as it does
      -- for choice_config). NULL = the 'omit' default. Purely additive — an
      -- existing DB gets it via the guarded ALTER migration.
      boolean_config   JSON         NULL     DEFAULT NULL,
      -- Per-field date display/payload format (date-field design spec §3):
      -- shape { format: DateFormat }, DateFormat from the fixed six-member
      -- vocabulary in src/platform/lib/date-format.ts. NULL = the default
      -- 'YYYY-MM-DD'. The stored VALUE is always the ISO string regardless
      -- of this config -- a date has no when-empty concept, unlike
      -- boolean_config, so this column carries only the display/payload
      -- format.
      date_config      JSON         NULL     DEFAULT NULL,
      created_at       TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
      -- Every dedup/repair migration + cascade delete resolves fields by
      -- blueprint_id; without this each pass full-scans blueprint_fields.
      INDEX idx_blueprint_fields_blueprint (blueprint_id),
      -- A field_key identifies one field within a blueprint: a record stores its
      -- answers under that key and the compute graph resolves sources by it, so
      -- two rows with the same (blueprint_id, field_key) are an ambiguous
      -- duplicate — and the key-migration endpoint, aimed at such a key, copies
      -- one field's answers over the other's in every record of the blueprint.
      -- UNIQUE backstops the write-path probe (field-key.js), which is the guard
      -- on every database; the index is what closes the window between that
      -- probe and the statement. An existing DB gets it via the guarded
      -- migration entry, which skips (visibly) rather than failing boot when the
      -- database already holds duplicates.
      UNIQUE KEY uq_blueprint_field_key (blueprint_id, field_key)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

    `CREATE TABLE IF NOT EXISTS \`${t(TABLES.FIELD_OPTIONS)}\` (
      id           CHAR(36)     PRIMARY KEY DEFAULT (UUID()),
      field_id     CHAR(36),
      option_label VARCHAR(255),
      option_value VARCHAR(255),
      -- v3.2.0 Q7: nullable optional ordering
      sort_order   INT          NULL     DEFAULT NULL,
      valid_parent_values  TEXT         NULL     DEFAULT NULL,
      created_at   TIMESTAMP    DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

    `CREATE TABLE IF NOT EXISTS \`${t(TABLES.BLUEPRINT_SECTIONS)}\` (
      id            CHAR(36)     PRIMARY KEY DEFAULT (UUID()),
      blueprint_id  CHAR(36),
      section_key   VARCHAR(255) NOT NULL,
      display_label VARCHAR(255),
      icon          VARCHAR(255) NULL     DEFAULT NULL,
      description   TEXT         NULL     DEFAULT NULL,
      -- v3.2.0 Q7: nullable optional ordering
      sort_order    INT          NULL     DEFAULT NULL,
      -- Which layout renderer a section uses (e.g. 'cards' | 'matrix').
      -- NULL = default field-list rendering, unaffected by group coloring.
      layout_mode   VARCHAR(255) NULL     DEFAULT NULL,
      -- Whether the editable matrix exposes copy affordances for this section.
      -- NULL/''/'enabled' = copy shown (default); 'disabled' = copy hidden. NULL
      -- deliberately reads as enabled so pre-existing rows keep today's behavior.
      matrix_copy   VARCHAR(255) NULL     DEFAULT NULL,
      created_at    TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
      -- A section_key identifies one section within a blueprint; a field joins
      -- it by string (blueprint_fields.section), so two rows with the same
      -- (blueprint_id, section_key) are an ambiguous duplicate. UNIQUE backstops
      -- the write-path guard (schema.js uniqueWithin) — an existing DB gets it
      -- via the guarded dedup+ALTER migration in db.js.
      UNIQUE KEY uq_blueprint_section_key (blueprint_id, section_key)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

    // Identity-lane definitions for a blueprint's group-aware form layouts.
    // Blueprint-scoped and shared across sections; a field joins a lane via
    // blueprint_fields.group_key (a key reference, mirroring section/section_key).
    // INVARIANT: never referenced by user_templates.payload — design-time only.
    `CREATE TABLE IF NOT EXISTS \`${t(TABLES.BLUEPRINT_GROUPS)}\` (
      id            CHAR(36)     PRIMARY KEY DEFAULT (UUID()),
      blueprint_id  CHAR(36),
      group_key     VARCHAR(255) NOT NULL,
      display_label VARCHAR(255),
      color_key     VARCHAR(255),
      sort_order    INT          NULL     DEFAULT NULL,
      created_at    TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
      -- A group_key identifies one identity lane within a blueprint; a field
      -- joins it by string (blueprint_fields.group_key), so two rows with the
      -- same (blueprint_id, group_key) are an ambiguous duplicate. UNIQUE
      -- backstops the write-path guard (schema.js uniqueWithin) — an existing DB
      -- gets it via the guarded dedup+ALTER migration in db.js.
      UNIQUE KEY uq_blueprint_group_key (blueprint_id, group_key)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

    `CREATE TABLE IF NOT EXISTS \`${t(TABLES.BLUEPRINT_OUTPUT_ORDER)}\` (
      id           CHAR(36)     PRIMARY KEY DEFAULT (UUID()),
      blueprint_id CHAR(36),
      output_key   VARCHAR(255) NOT NULL,
      -- Normalized API contract uses 0 for missing output order.
      sort_order   INT          NOT NULL DEFAULT 0,
      -- Per-output rendering declaration (fmb-1723, Q7): 'json' (default) or
      -- 'table'. Plain VARCHAR (not SQL ENUM) to match this table set's
      -- convention (e.g. blueprint_sections.layout_mode) — app-layer
      -- validates the two legal values, keeping ALTER-free future additions.
      format       VARCHAR(16)  NOT NULL DEFAULT 'json',
      created_at   TIMESTAMP    DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

    `CREATE TABLE IF NOT EXISTS \`${t(TABLES.VARIANT_OVERRIDES)}\` (
      id             CHAR(36)     PRIMARY KEY DEFAULT (UUID()),
      variant_id     CHAR(36),
      field_id       CHAR(36),
      action         VARCHAR(100) NOT NULL DEFAULT '',
      override_value TEXT,
      compute_rule   JSON,
      -- Cell-level scoping for an override on a table-type field:
      -- { rows: number[] | null, columns: string[] | null } (0-based row
      -- indices x table-column keys). NULL / absent / empty object means the
      -- override applies to the whole field, so an existing row keeps its
      -- meaning without a backfill. INVARIANT: scoping lives INSIDE the row —
      -- uq_variant_override_triple below is unchanged, so a field still carries
      -- at most one override per action.
      cell_targets   JSON         NULL,
      created_at     TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
      UNIQUE KEY uq_variant_override_triple (variant_id, field_id, action),
      -- The UNIQUE has field_id as its second column, so a field-scoped lookup
      -- (delete-path cleanup + orphan-sweep NOT EXISTS) cannot use it. Index
      -- field_id directly.
      INDEX idx_variant_overrides_field (field_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

    `CREATE TABLE IF NOT EXISTS \`${t(TABLES.USER_TEMPLATES)}\` (
      id               CHAR(36)     PRIMARY KEY DEFAULT (UUID()),
      name             VARCHAR(255) NOT NULL DEFAULT '(unnamed)',
      -- CONTRACT phase (Generation→Category): category_id is the sole top-tier
      -- FK-by-convention. The legacy generation_id column was dropped; a DB
      -- still carrying it is dropped by runSchemaMigrations' self-guarded
      -- contract step once every generation_id is backfilled into category_id.
      category_id      CHAR(36),
      release_id       CHAR(36),
      blueprint_id     CHAR(36),
      variant_id       CHAR(36),
      payload          JSON,
      generated_outputs JSON,
      field_option_selection TEXT NULL DEFAULT NULL,
      computed_field_overrides TEXT NULL DEFAULT NULL,
      -- Which fields the operator emptied on purpose, each keyed to the option
      -- set / decision-table match it was emptied under. NULL means nothing was
      -- emptied: without it a deliberate blank and a never-filled field look
      -- identical on reload, and the auto-fill pass puts the value back.
      cleared_auto_fills TEXT NULL DEFAULT NULL,
      parent_id        CHAR(36),
      schema_version   VARCHAR(50),
      -- v3.2.0 QW3: distinguishes saved drafts from published templates
      is_draft         BOOLEAN      NOT NULL DEFAULT FALSE,
      -- Ownership column aligned with hierarchy_nodes / transformers so the
      -- shared applyOwnerChange path can reassign templates. NULL = unowned
      -- (typical for rows seeded across environments where the source user
      -- id has no match here). Backfilled from the legacy user_id column
      -- (dropped fmb-1329 T9, closes fmb-0757) on migration.
      owner_id         CHAR(36)     NULL     DEFAULT NULL,
      -- cache of the latest authored flow link + create-vs-update handle;
      -- independent of the PDX bridge's external_ref.
      flow_external_id VARCHAR(255) NULL     DEFAULT NULL,
      flow_link        TEXT         NULL     DEFAULT NULL,
      -- Marker, not a foreign key: a run named here can be deleted (admin, or
      -- its actor with template write) and this id is left dangling on purpose
      -- so the record still reads as pushed — a later successful run restamps it.
      flow_last_run_id CHAR(36)     NULL     DEFAULT NULL,
      -- Sub-item ids captured from the remote workflow (e.g. task id per row) so
      -- an update can re-address deep tasks; independent of flow_external_id,
      -- which only names the workflow itself. Author-defined shape (whatever the
      -- after/extract JS returns under the reserved remote_refs key), so this
      -- is JSON rather than a scalar.
      flow_remote_refs JSON         NULL     DEFAULT NULL,
      -- fmb-1329 T11 (closes fmb-0533): NOT NULL — a real row always has a
      -- creation instant; nullable was an unintentional gap (no code path
      -- ever wrote NULL here). registry backfill step MODIFYs a legacy DB.
      created_at       TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at       TIMESTAMP    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      INDEX idx_user_templates_owner_draft (owner_id, is_draft),
      -- Public Integration API P2 scope filter: /templates matches ANY of the
      -- four hierarchy FK columns against the granted-root set (index-merge
      -- union). Single-column indexes so an OR-across-columns predicate can use
      -- them; a composite would only serve one column.
      INDEX idx_user_templates_blueprint (blueprint_id),
      INDEX idx_user_templates_category (category_id),
      INDEX idx_user_templates_release (release_id),
      INDEX idx_user_templates_variant (variant_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

    `CREATE TABLE IF NOT EXISTS \`${t(TABLES.TRANSFORMERS)}\` (
      id              CHAR(36)     PRIMARY KEY DEFAULT (UUID()),
      name            VARCHAR(255) NOT NULL,
      description     TEXT,
      code            TEXT         NOT NULL,
      input_schema    JSON,
      output_keys     JSON,
      test_cases      JSON,
      is_active       BOOLEAN      NOT NULL DEFAULT TRUE,
      version         INT          NOT NULL DEFAULT 1,
      code_size       INT          NOT NULL DEFAULT 0,
      created_by      VARCHAR(255),
      updated_by      VARCHAR(255),
      -- v3.2.99 (Bug-4): owner-on-create scoping mirroring
      -- hierarchy_nodes. NULL = shared (any editor can edit); set to
      -- creator id when an editor creates the row. Only admin may PATCH.
      owner_id        CHAR(36)     NULL     DEFAULT NULL,
      created_at      TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
      updated_at      TIMESTAMP    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

    `CREATE TABLE IF NOT EXISTS \`${t(TABLES.TRANSFORMER_VERSIONS)}\` (
      id              CHAR(36)     PRIMARY KEY DEFAULT (UUID()),
      transformer_id  CHAR(36)     NOT NULL,
      version         INT          NOT NULL,
      code            TEXT         NOT NULL,
      input_schema    JSON,
      output_keys     JSON,
      test_cases      JSON,
      change_note     TEXT,
      action          VARCHAR(50)  NOT NULL DEFAULT 'update',
      created_by      VARCHAR(255),
      created_at      TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
      UNIQUE INDEX idx_transformer_version (\`transformer_id\`, \`version\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

    `CREATE TABLE IF NOT EXISTS \`${t(TABLES.API_CONNECTORS)}\` (
      id              CHAR(36)     PRIMARY KEY DEFAULT (UUID()),
      name            VARCHAR(255) NOT NULL,
      description     TEXT,
      is_active       BOOLEAN      NOT NULL DEFAULT TRUE,
      -- Ownership column aligned with hierarchy_nodes / transformers so the
      -- shared applyOwnerChange path can reassign connectors. NULL = unowned.
      owner_id        CHAR(36)     NULL     DEFAULT NULL,
      -- blueprint_id stays nullable on purpose: a connector imported from
      -- another environment whose blueprint id has no local match is stored
      -- "unbound" (NULL) rather than rejected — the operator re-binds it.
      blueprint_id    CHAR(36)     NULL     DEFAULT NULL,
      section_key     VARCHAR(255) NULL     DEFAULT NULL,
      method          VARCHAR(10)  NOT NULL DEFAULT 'GET',
      url             TEXT         NOT NULL,
      auth_type       ENUM('none','bearer','api_key','basic') NOT NULL DEFAULT 'none',
      -- auth_config holds the auth secrets; sensitive subvalues (bearer token,
      -- api_key.value, basic.pass) are AES-256-GCM encrypted at the serializer
      -- boundary, never stored or logged in plaintext.
      auth_config     JSON,
      request_config  JSON,
      response_config JSON,
      -- Source of this connector's response. 'http' (default) dispatches the
      -- url; 'template' resolves another user_template in-process; 'static'
      -- returns a fixed JSON body. Non-http rows keep url='' and ignore
      -- method/auth/dispatch_origin (normalised on write).
      source_kind     ENUM('http','template','static') NOT NULL DEFAULT 'http',
      -- Shape depends on source_kind (see source-config.js): template →
      -- { blueprint_id, mode, select?, parts }, static → { body }. NULL for http.
      source_config   JSON         NULL     DEFAULT NULL,
      dispatch_origin ENUM('infra','edge') NOT NULL DEFAULT 'infra',
      group_id        CHAR(36)     NULL     DEFAULT NULL,
      group_label     VARCHAR(255) NULL     DEFAULT NULL,
      group_mode      ENUM('aggregation','chain') NULL DEFAULT NULL,
      \`sequence\`    INT          NULL     DEFAULT NULL,
      -- Per-connector request timeout in milliseconds. NULL = use the system
      -- default (DEFAULT_TIMEOUT_MS, 10s). Applied per outbound call, so a
      -- table per-row fan-out times each row independently.
      timeout_ms      INT          NULL     DEFAULT NULL,
      -- Admin approval lifecycle. status NULL = grandfathered = treated as
      -- approved at the dispatch gate (pre-existing rows + no-ALTER DBs keep
      -- dispatching); new rows are stamped pending/approved by the app. Only an
      -- 'approved' connector dispatches; editing a sensitive field re-pends it.
      status          ENUM('pending','approved','rejected') NULL DEFAULT NULL,
      approved_by     CHAR(36)     NULL     DEFAULT NULL,
      approved_at     TIMESTAMP    NULL     DEFAULT NULL,
      review_note     TEXT         NULL     DEFAULT NULL,
      created_at      TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
      updated_at      TIMESTAMP    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      INDEX idx_api_connectors_blueprint (blueprint_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

    `CREATE TABLE IF NOT EXISTS \`${t(TABLES.API_CONNECTOR_BLUEPRINTS)}\` (
      id            CHAR(36)  PRIMARY KEY DEFAULT (UUID()),
      -- The connector this "also usable in" binding belongs to. No FK (repo
      -- convention, see variant_overrides): a connector deleted while its join
      -- rows survive would leave orphans, so the connector DELETE path and the
      -- hierarchy-node cascade both clean this table explicitly.
      connector_id  CHAR(36)  NOT NULL,
      -- An EXTRA blueprint the connector is listed as usable in. INVARIANT: the
      -- home blueprint (api_connectors.blueprint_id) is never duplicated here —
      -- the bindings validator rejects it, so ownership/edit/exec authority read
      -- one column and one column only.
      blueprint_id  CHAR(36)  NOT NULL,
      created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      UNIQUE KEY uq_connector_blueprint (connector_id, blueprint_id),
      -- The usable-list read (usable.js) and the node-delete cascade both filter
      -- by blueprint_id; the UNIQUE above leads with connector_id, so a
      -- blueprint-scoped lookup cannot use it. Index blueprint_id directly.
      INDEX idx_acb_blueprint (blueprint_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

    `CREATE TABLE IF NOT EXISTS \`${t(TABLES.FLOW_RECIPES)}\` (
      id                     CHAR(36)     PRIMARY KEY DEFAULT (UUID()),
      name                   VARCHAR(255) NOT NULL,
      description            TEXT,
      is_active              BOOLEAN      NOT NULL DEFAULT TRUE,
      -- Ownership aligned with hierarchy_nodes / transformers / api_connectors
      -- so the shared applyOwnerChange path can reassign recipes. NULL = unowned.
      owner_id               CHAR(36)     NULL     DEFAULT NULL,
      -- blueprint_id reserved for future pre-binding; unbound (NULL) is valid.
      blueprint_id           CHAR(36)     NULL     DEFAULT NULL,
      -- Inline payload-shaping code, authored 1:1 with the recipe (no shared
      -- transformer row). Runs in the browser sandbox at dispatch time; NULL =
      -- not yet authored (recipe not runnable until non-empty).
      payload_transform_code TEXT         NULL     DEFAULT NULL,
      consumed_output_keys   JSON,
      link_extract           JSON,
      external_id_extract    JSON,
      -- Read-only compare pass (epic 3, spec Q19/Q20): { localPath, remotePath }
      -- JSON-path pair the compare stage resolves against the prepared payload
      -- (local) and the compare branch's post-run ctx (remote). NULL = compare
      -- not yet authored for this recipe — the Build modal's compare stage has
      -- nothing to resolve and shows no summary.
      compare_spec           JSON         NULL     DEFAULT NULL,
      -- create/update routing: the dispatcher derives the effective mode from the
      -- record's prior-push signal and refuses a run whose recipe declares a
      -- conflicting trigger. 'both' (default) never refuses — grandfathered recipes
      -- keep running unchanged.
      runs_on                ENUM('create','update','both') NOT NULL DEFAULT 'both',
      -- Admin approval lifecycle mirrors api_connectors: status NULL =
      -- grandfathered; only an 'approved' recipe runs; editing a sensitive
      -- field re-pends it.
      status                 ENUM('pending','approved','rejected') NULL DEFAULT NULL,
      approved_by            CHAR(36)     NULL     DEFAULT NULL,
      approved_at            TIMESTAMP    NULL     DEFAULT NULL,
      review_note            TEXT         NULL     DEFAULT NULL,
      -- Current code-version counter, mirroring transformers.version. Bumped
      -- 1→2→… each time payload_transform_code changes on the CRUD write path;
      -- every bump appends a flow_recipe_code_versions history row. NOT NULL so a
      -- fresh recipe starts at 1 and a run always has a concrete version to snapshot.
      code_version           INT          NOT NULL DEFAULT 1,
      created_at             TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
      updated_at             TIMESTAMP    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      INDEX idx_flow_recipes_owner (owner_id),
      INDEX idx_flow_recipes_blueprint (blueprint_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

    `CREATE TABLE IF NOT EXISTS \`${t(TABLES.FLOW_RECIPE_STEPS)}\` (
      id              CHAR(36)     PRIMARY KEY DEFAULT (UUID()),
      recipe_id       CHAR(36)     NOT NULL,
      \`sequence\`    INT          NOT NULL DEFAULT 0,
      name            VARCHAR(255) NOT NULL,
      method          VARCHAR(10)  NOT NULL DEFAULT 'POST',
      url             TEXT         NOT NULL,
      auth_type       ENUM('none','bearer','api_key','basic') NOT NULL DEFAULT 'none',
      -- auth_config holds the per-step secret (bearer token / api_key.value /
      -- basic.pass); sensitive subvalues are AES-256-GCM encrypted at the
      -- serializer boundary (a later PR), never stored or logged in plaintext.
      auth_config     JSON,
      request_config  JSON,
      response_config JSON,
      input_from_step JSON         NULL     DEFAULT NULL,
      -- 'api' = HTTP dispatch step; 'compute' = no dispatch, runs only its JS slot
      -- to derive named outputs (e.g. assemble a value the API does not return).
      step_type       ENUM('api','compute') NOT NULL DEFAULT 'api',
      -- Step-level create/update/compare trigger (epic 3). NOT named runs_on
      -- like the recipe-level column of the same meaning: column-domains.ts /
      -- column-domains.parity.test.ts key a shared enum domain by literal column
      -- name and require every table declaring that name to agree on its exact
      -- member set — this column's domain adds 'compare' and legitimately
      -- diverges from flow_recipes.runs_on's {create,update,both}, so a shared
      -- name would fail that invariant the moment both existed. Only meaningful
      -- (settable to non-'both') while the parent recipe's own runs_on is
      -- 'both' — enforced at the write boundary (FLOW_STEP_MODE_CONFLICT), not
      -- by this DDL — because a recipe narrowed to a single mode already
      -- decides the question for every one of its steps. 'compare' = read-only
      -- compare-pass-only step (method must be GET; validated on save).
      step_runs_on    ENUM('create','update','both','compare') NOT NULL DEFAULT 'both',
      -- Optional JS slots, executed in the browser sandbox (never server-side).
      -- before_code shapes the request inputs from the running context; after_code
      -- extracts named outputs from the response. For a compute step before_code is
      -- the sole slot and after_code is unused. Both capped + non-string-rejected at
      -- the write boundary, same as payload_transform_code.
      before_code     TEXT         NULL     DEFAULT NULL,
      after_code      TEXT         NULL     DEFAULT NULL,
      -- The Merge-by-key preset config that GENERATED before_code, kept so the
      -- preset UI can re-drive the rules table. before_code is the runtime truth
      -- (the sandbox runs it, not this column); editing the code by hand detaches
      -- the preset and this config is frozen until "Reset to preset" regenerates.
      -- Shape: { kind:'merge_by_key', rules: MergeRule[] }. NULL = a plain
      -- custom-code compute step or an api step (no preset).
      preset_config   JSON         NULL     DEFAULT NULL,
      dispatch_origin ENUM('infra','edge') NOT NULL DEFAULT 'infra',
      timeout_ms      INT          NULL     DEFAULT NULL,
      -- content_type/yaml_version/yaml_quoting hold the flow-recipe body dialect
      -- per step, so a consumer that parses YAML 1.1 can be quoted correctly per
      -- endpoint. Defaults reproduce exactly what a step means today (JSON; a
      -- YAML step's dialect was lineWidth:0 == 1.2/plain, byte-proven equal).
      -- flow_recipes.content_type (the pre-Y1 recipe-level dialect this group
      -- replaced) is dropped from this DDL Task Z.0 (fmb-2062) wherever
      -- the drop's precondition holds; a permanently no-ALTER install (fmb-1329
      -- Q9) keeps it and reads it forever as every one of its steps' dialect
      -- (Y2.6c) — see migration-steps.js flow_recipes_content_type_drop.
      content_type    ENUM('application/json','application/yaml') NOT NULL DEFAULT 'application/json',
      yaml_version    ENUM('1.2','1.1') NOT NULL DEFAULT '1.2',
      yaml_quoting    ENUM('plain','double','single') NOT NULL DEFAULT 'plain',
      created_at      TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
      updated_at      TIMESTAMP    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      INDEX idx_flow_recipe_steps_recipe (recipe_id, \`sequence\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

    `CREATE TABLE IF NOT EXISTS \`${t(TABLES.FLOW_RECIPE_RUNS)}\` (
      id                     CHAR(36)     PRIMARY KEY DEFAULT (UUID()),
      recipe_id              CHAR(36)     NOT NULL,
      template_id            CHAR(36)     NULL     DEFAULT NULL,
      blueprint_id           CHAR(36)     NULL     DEFAULT NULL,
      -- write-scope: every run is initiated by an authenticated user; actor_id = req.user.id is required (a user lists only their own runs).
      actor_id               CHAR(36)     NOT NULL,
      mode                   ENUM('create','update') NOT NULL DEFAULT 'create',
      -- Which flow_recipes.code_version was in force when this run began. NULL =
      -- legacy/pre-feature run (recorded before code-versioning shipped, or on a
      -- no-ALTER DB). Kept nullable through the API on purpose — do NOT
      -- Y-pattern-coalesce to 0; 0 is not a real version and would be a lie.
      code_version           INT          NULL     DEFAULT NULL,
      -- Terminal state written once at completion (dispatch is synchronous,
      -- FE-orchestrated) — no in-flight 'running' value by design.
      status                 ENUM('success','partial','failed') NOT NULL,
      result_link            TEXT         NULL     DEFAULT NULL,
      external_flow_id       VARCHAR(255) NULL     DEFAULT NULL,
      -- INVARIANT: rendered_payload is secret-masked before persist — secrets
      -- are injected only as headers at dispatch, never into this snapshot.
      output_snapshot        LONGTEXT     NULL     DEFAULT NULL,
      rendered_payload       LONGTEXT     NULL     DEFAULT NULL,
      -- Neither column above is the operator's input: rendered_payload is the
      -- transformed outbound body and output_snapshot is the generated output
      -- text, so what was typed was recorded nowhere and a run could not be read
      -- back to the answers that produced it. The capture paths write this one
      -- with the run's INSERT rather than by a later update, so a run that fails
      -- mid-chain still carries it; and they keep the entered values and the
      -- values the form computed from them under separate keys of one document,
      -- because both are taken at the same instant and neither is interpretable
      -- without the other.
      -- THREE STATES, and a reader has to tell them apart: a captured document
      -- ({entered, computed, fields, blueprint_id, variant_id}); a document
      -- stating that a capture was attempted and dropped ({not_captured, …},
      -- e.g. too large to record, or generated outputs older than the form); and
      -- NULL, which means no capture was ever attempted — a run recorded before
      -- this column existed, or on a database that warn-skipped its ALTER.
      -- INVARIANT: secret-masked before persist by the same serializer as the
      -- two columns above, and bounded there — a LONGTEXT's own ceiling is far
      -- past any size an operator could be told about.
      input_snapshot         LONGTEXT     NULL     DEFAULT NULL,
      -- SECURITY: persist only status/timing/non-secret response fields here;
      -- raw bodies from credential-vending endpoints must be filtered before
      -- insert (token/key values omitted), same masking discipline as rendered_payload.
      step_results           JSON         NULL     DEFAULT NULL,
      -- The chain context's remote_refs at finalize, snapshotted alongside
      -- step_results so a run reads back the sub-item ids it captured and not
      -- only the template's latest cache (flow_remote_refs there is overwritten
      -- by the next run). Author-defined free JSON, same shape and 64KB cap as
      -- the template column. NULL means the run reported none, or its refs were
      -- over the cap / unencodable and dropped (the finalize response carries the
      -- notice), or the run predates this column on a warn-skipped ALTER.
      remote_refs            JSON         NULL     DEFAULT NULL,
      error_summary          TEXT         NULL     DEFAULT NULL,
      started_at             TIMESTAMP    NULL     DEFAULT NULL,
      finished_at            TIMESTAMP    NULL     DEFAULT NULL,
      -- fmb-1329 T11 (closes fmb-0533): NOT NULL — a real run row always has
      -- a creation instant; nullable was an unintentional gap. registry
      -- backfill step MODIFYs a legacy DB.
      created_at             TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
      INDEX idx_flow_recipe_runs_recipe_time (recipe_id, created_at),
      INDEX idx_flow_recipe_runs_actor_time (actor_id, created_at),
      INDEX idx_flow_recipe_runs_template (template_id),
      -- Public Integration API P2 scope filter: /runs pages by
      -- (blueprint_id IN scope) ORDER BY created_at on this append-only,
      -- execution-scale table. The blueprint_id prefix kills the full scan; the
      -- created_at part does NOT serve the keyset order because the consuming
      -- query (public-read.js) still wraps it in COALESCE(created_at,sentinel)
      -- for pre-backfill rows — created_at is NOT NULL now (fmb-0533 closed),
      -- so dropping the COALESCE is a safe follow-up, not done here (T11 scope
      -- is the backfill only).
      INDEX idx_flow_recipe_runs_blueprint (blueprint_id, created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

    // Immutable code-version history for a recipe's inline payload_transform_code,
    // mirroring transformer_versions (minus input_schema/output_keys/test_cases/
    // change_note — a flow recipe has none of those). One row per code change on
    // the CRUD write path; append-only, never updated. `code` is nullable because
    // payload_transform_code itself is nullable — a NULL→code or code→NULL
    // transition is a recorded change. History is environment-local audit and is
    // deliberately excluded from cross-env sync (see sync-schema.js NOTE) — its
    // UNIQUE(recipe_id, version) would otherwise collide against versions the
    // target environment accrued independently.
    `CREATE TABLE IF NOT EXISTS \`${t(TABLES.FLOW_RECIPE_CODE_VERSIONS)}\` (
      id           CHAR(36)     PRIMARY KEY DEFAULT (UUID()),
      recipe_id    CHAR(36)     NOT NULL,
      version      INT          NOT NULL,
      code         TEXT         NULL,
      action       VARCHAR(50)  NOT NULL DEFAULT 'update',
      created_by   VARCHAR(255) NULL,
      created_at   TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
      UNIQUE INDEX idx_flow_recipe_code_version (\`recipe_id\`, \`version\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

    // Shared multi-condition lookup ("decision table"): N condition fields
    // filter rows, one matching row auto-fills M output fields at data-entry
    // time. One row per authored table; the whole table lives in a single JSON
    // document rather than condition/output/cell child tables, because every
    // read and every write is whole-document (the authoring grid saves the grid,
    // the evaluator loads the grid) — child tables would buy nothing but N+1
    // reads and partial-write states.
    //
    // INVARIANT: `doc` is bounded at the route (MAX_DECISION_DOC_BYTES), NOT by
    // the column type — MariaDB JSON is LONGTEXT (4 GB), so the column itself is
    // no guard at all.
    // FK-by-convention (no DB-level FOREIGN KEY), matching every engine table
    // above: blueprint_id points at a hierarchy_nodes blueprint row and the
    // cascade-delete service is what keeps it from rotting; doc.conditions[] /
    // doc.outputs[] reference blueprint_fields BY KEY (field_key), so a deleted
    // field surfaces as a repair-style authoring flag rather than a hard error.
    `CREATE TABLE IF NOT EXISTS \`${t(TABLES.DECISION_TABLES)}\` (
      id           CHAR(36)     PRIMARY KEY DEFAULT (UUID()),
      blueprint_id CHAR(36),
      name         VARCHAR(255) NOT NULL,
      doc          JSON,
      created_at   TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
      updated_at   TIMESTAMP    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      -- Every read is blueprint-scoped (the authoring panel lists one
      -- blueprint's tables; the evaluator loads them per blueprint), and the
      -- cascade delete resolves rows the same way.
      INDEX idx_decision_tables_blueprint (blueprint_id),
      -- A name is the only handle a human has on a table within a blueprint; a
      -- second row with the same (blueprint_id, name) is an ambiguous
      -- duplicate. UNIQUE backstops the write-path guard (schema/index.js
      -- uniqueWithin) the same way uq_blueprint_section_key /
      -- uq_blueprint_group_key close the race for their sibling tables — this
      -- table is new (never shipped pre-key), so the create-table migration
      -- step lays the index down directly; no dedup+ALTER path is needed.
      UNIQUE KEY uq_decision_table_name (blueprint_id, name)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

    // Delegated access. One row is one person allowed to work on a record they
    // do not own: to change the answers a run is built from, and to dispatch it.
    //
    // THERE IS ONE LEVEL, ON PURPOSE. The right to press the button and the
    // right to change what the button sends were described as one permission, so
    // there is no `level` column. A column carrying a single legal value would
    // invent the taxonomy this design deliberately does not have, and every
    // reader would then have to guess what a second value was supposed to mean.
    //
    // WHY ONE TABLE FOR TWO SUBJECTS. A blueprint's owner delegates every
    // template under that blueprint; a template's owner delegates that one
    // template. Those are the same permission over different subjects, so this
    // is one shape that states its subject rather than two mechanisms that would
    // have to be kept in step with each other.
    //
    // FK-by-convention (no DB-level FOREIGN KEY), matching every engine table
    // above: `scope_id` may name a blueprint or a template that has since been
    // deleted, and `grantee_id` a user who has since been removed. Every read of
    // this table is EXISTS-shaped and joins the subject, so a grant whose
    // subject no longer resolves matches nothing and the caller falls back to
    // plain ownership — a dangling row can only ever grant less, never more.
    `CREATE TABLE IF NOT EXISTS \`${t(TABLES.DELEGATED_GRANTS)}\` (
      id          CHAR(36)    PRIMARY KEY DEFAULT (UUID()),
      scope_type  ENUM('blueprint','template') NOT NULL,
      scope_id    CHAR(36)    NOT NULL,
      grantee_id  CHAR(36)    NOT NULL,
      granted_by  CHAR(36)    NULL     DEFAULT NULL,
      created_at  TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP,
      -- Granting the same person the same subject twice is one grant, not two:
      -- the UNIQUE key makes a repeated grant idempotent at the storage layer,
      -- so a double-submit cannot produce a pair of rows that revocation would
      -- then have to remove one at a time.
      UNIQUE KEY uq_delegated_grant (scope_type, scope_id, grantee_id),
      -- The write gate asks "does this caller hold a grant over this subject",
      -- so the grantee leads the index the enforcement path uses.
      INDEX idx_delegated_grants_grantee (grantee_id, scope_type, scope_id),
      -- The granting screen asks the opposite question: who holds a grant over
      -- this subject.
      INDEX idx_delegated_grants_scope (scope_type, scope_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

    // Who did what to one record, and when.
    //
    // WHY THIS IS NOT `feature_audit`. That table is INFRA: it never crosses
    // environments with the engine rows it would be describing, its read route
    // is admin-only while this list must be readable by a record's owner and by
    // the people they delegated to, and it carries no column a per-record read
    // could be indexed on — the record's id would live inside its JSON metadata,
    // which is a full scan of a table that also holds every migration event ever
    // recorded. The reasoning is set out in full in the PR that added this
    // table; the short form is that the two have different tiers, different
    // readers and different access patterns.
    //
    // FK-by-convention: `template_id` may name a template that has since been
    // deleted. The read route resolves the template to decide who may read the
    // list, so a row whose template is gone is simply unreachable rather than
    // orphaned into visibility.
    `CREATE TABLE IF NOT EXISTS \`${t(TABLES.TEMPLATE_ACTIVITY)}\` (
      id           CHAR(36)     PRIMARY KEY DEFAULT (UUID()),
      template_id  CHAR(36)     NOT NULL,
      actor_id     CHAR(36)     NULL     DEFAULT NULL,
      action       VARCHAR(64)  NOT NULL,
      metadata     JSON         NULL,
      created_at   TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
      -- Every read is one template's trail, newest first, and it is paged: the
      -- composite index serves the filter and the order together so a long trail
      -- costs a range scan rather than a sort of the whole table.
      INDEX idx_template_activity_template_time (template_id, created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

    // A named, manual save of a record's form values — never executed, never a
    // run (U10). WHY A NEW TABLE rather than a JSON array column on
    // user_templates: a snapshot list is read far less often than the template
    // row itself, and folding it onto that row would bloat the hot per-form-load
    // read and turn a single delete into a read-modify-write of the whole array.
    //
    // FK-by-convention (no DB-level FOREIGN KEY), matching every table above:
    // `template_id` may name a template since deleted, and `blueprint_id` /
    // `variant_id` a blueprint/variant since removed — the read route resolves
    // the template to decide who may see the list, so an orphaned snapshot is
    // simply unreachable rather than visible with nothing to restore it onto.
    //
    // `snapshot` freezes exactly the four documents the compare model reads
    // (`{entered, computed, outputs, fields}`) at save time — the same shape a
    // flow run's `input_snapshot` freezes, so both feed the same compare model
    // without a translation step.
    `CREATE TABLE IF NOT EXISTS \`${t(TABLES.TEMPLATE_SNAPSHOTS)}\` (
      id           CHAR(36)     PRIMARY KEY DEFAULT (UUID()),
      template_id  CHAR(36)     NOT NULL,
      name         VARCHAR(255) NOT NULL,
      note         TEXT         NULL     DEFAULT NULL,
      blueprint_id CHAR(36)     NULL     DEFAULT NULL,
      variant_id   CHAR(36)     NULL     DEFAULT NULL,
      snapshot     LONGTEXT     NOT NULL,
      actor_id     CHAR(36)     NULL     DEFAULT NULL,
      created_at   TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
      -- Every read is one template's snapshot list, newest first — same shape
      -- as template_activity's own index, for the same reason.
      INDEX idx_template_snapshots_template_time (template_id, created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

    // Template versioning: a named, manual save of a template's
    // data-entry state that never runs the build flow — shape mirrors
    // cap_versions. `kind` separates operator saves from flow-produced rows
    // so ONE timeline can badge them; flow rows keep provenance via
    // flow_run_id but the snapshot is self-contained (the merged GET reads
    // flow rows straight off flow_recipe_runs — never duplicated in here).
    `CREATE TABLE IF NOT EXISTS \`${t(TABLES.TEMPLATE_VERSIONS)}\` (
      id           CHAR(36)     PRIMARY KEY DEFAULT (UUID()),
      template_id  CHAR(36)     NOT NULL,
      name         VARCHAR(255) NOT NULL,
      note         TEXT         NULL     DEFAULT NULL,
      kind         VARCHAR(16)  NOT NULL DEFAULT 'manual',
      flow_run_id  CHAR(36)     NULL     DEFAULT NULL,
      blueprint_id CHAR(36)     NULL     DEFAULT NULL,
      variant_id   CHAR(36)     NULL     DEFAULT NULL,
      snapshot     LONGTEXT     NOT NULL,
      actor_id     CHAR(36)     NULL     DEFAULT NULL,
      created_at   TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
      INDEX idx_template_versions_template_time (template_id, created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

    // ── Capacity Planner (App-tier; spec docs/superpowers/specs/2026-07-11-capacity-planner-design.md §2) ──
    // All FK columns are id references without DB-level FOREIGN KEY constraints
    // (FK-by-convention, matching every engine table above); indexes back the
    // scenario-scope + parent lookups the CRUD layer issues. Derived values
    // (used / free / utilization%) are NEVER stored — only raw inputs persist.

    // A named plan: the ownership + scoping root. owner_id NULL = shared
    // (admin-created); editor-created rows stamp the actor (owner-scope pattern,
    // mirrors hierarchy_nodes / api_connectors).
    `CREATE TABLE IF NOT EXISTS \`${t(TABLES.CAP_SCENARIOS)}\` (
      id           CHAR(36)     PRIMARY KEY DEFAULT (UUID()),
      name         VARCHAR(255) NOT NULL,
      owner_id     CHAR(36)     NULL     DEFAULT NULL,
      note         TEXT         NULL     DEFAULT NULL,
      created_at   TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
      updated_at   TIMESTAMP    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      INDEX idx_cap_scenarios_owner (owner_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

    // A DC / site (flat; topology reserved single value 'site' — a future
    // 'rack' value + cap_racks table is the additive extension path).
    // order_index (phase-2 spec §6.1): the wizard-authored DC display order
    // (array index at create time); every DC-ordered read sorts by it so the
    // grid/placement/PNG surfaces agree on DC1/DC2/DC3 order.
    `CREATE TABLE IF NOT EXISTS \`${t(TABLES.CAP_SITES)}\` (
      id           CHAR(36)     PRIMARY KEY DEFAULT (UUID()),
      scenario_id  CHAR(36)     NOT NULL,
      name         VARCHAR(255) NOT NULL,
      topology     ENUM('site') NOT NULL DEFAULT 'site',
      order_index  INT          NOT NULL DEFAULT 0,
      metadata     JSON,
      created_at   TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
      updated_at   TIMESTAMP    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      INDEX idx_cap_sites_scenario (scenario_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

    // A hardware generation: raw totals + reserved overhead. Usable is computed
    // (usable = raw − reserved), never stored. cpu in cores (INT); mem/disk in
    // GB and the reserve percent as DOUBLE (summed for rollups; precision beyond
    // planning granularity is unnecessary).
    // Global catalogue (rewrite spec §5): scenario_id NULL = global (shared),
    // X = scenario-local. Reference-integrity is write-validated (spec §17.1a).
    `CREATE TABLE IF NOT EXISTS \`${t(TABLES.CAP_HARDWARE_SPECS)}\` (
      id               CHAR(36)     PRIMARY KEY DEFAULT (UUID()),
      scenario_id      CHAR(36)     NULL     DEFAULT NULL,
      name             VARCHAR(255) NOT NULL,
      cpu_total        INT          NOT NULL DEFAULT 0,
      mem_total_gb     DOUBLE       NOT NULL DEFAULT 0,
      disk_total_gb    DOUBLE       NOT NULL DEFAULT 0,
      cpu_reserved     INT          NOT NULL DEFAULT 0,
      mem_reserved_pct DOUBLE       NOT NULL DEFAULT 0,
      disk_reserved_gb DOUBLE       NOT NULL DEFAULT 0,
      -- phase-4 spec §6: persisted drag-reorder order for a scenario's LOCAL
      -- rows (the /local-catalogues/hardware_specs/reorder endpoint rewrites it).
      -- Global rows (scenario_id NULL) are never reordered. New column joins the
      -- fmb-1329 auto-column debt (no migration code; capacity is no-migration).
      order_index      INT          NOT NULL DEFAULT 0,
      metadata         JSON,
      created_at       TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
      updated_at       TIMESTAMP    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      INDEX idx_cap_hardware_specs_scenario (scenario_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

    // A named multi-disk combination (rewrite spec §4). Global catalogue:
    // scenario_id NULL = global, X = scenario-local. sizes = JSON list of GB
    // sizes (512-based). VM Profiles reference allowed combos; VMs/databases
    // store the chosen combo id.
    `CREATE TABLE IF NOT EXISTS \`${t(TABLES.CAP_DISK_COMBOS)}\` (
      id           CHAR(36)     PRIMARY KEY DEFAULT (UUID()),
      scenario_id  CHAR(36)     NULL     DEFAULT NULL,
      name         VARCHAR(255) NOT NULL,
      sizes        JSON,
      -- phase-6 spec §D3: persisted drag-reorder order on the global config page
      -- (the /config/disk_combos/reorder endpoint rewrites the global rows). New
      -- column joins the fmb-1329 auto-column debt (no migration code).
      order_index  INT          NOT NULL DEFAULT 0,
      created_at   TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
      updated_at   TIMESTAMP    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      INDEX idx_cap_disk_combos_scenario (scenario_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

    // A team = name + color ONLY, no member lists (rewrite spec §6). Global
    // catalogue: scenario_id NULL = global, X = scenario-local. Membership is
    // bound where the item lives (bundle rows, scenario items, custom groups)
    // via a nullable team_id.
    `CREATE TABLE IF NOT EXISTS \`${t(TABLES.CAP_TEAMS)}\` (
      id           CHAR(36)     PRIMARY KEY DEFAULT (UUID()),
      scenario_id  CHAR(36)     NULL     DEFAULT NULL,
      name         VARCHAR(255) NOT NULL,
      color        VARCHAR(32)  NOT NULL DEFAULT '',
      -- phase-6 spec §D3: persisted drag-reorder order on the global config page
      -- (the /config/teams/reorder endpoint rewrites the global rows). New column
      -- joins the fmb-1329 auto-column debt (no migration code).
      order_index  INT          NOT NULL DEFAULT 0,
      created_at   TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
      updated_at   TIMESTAMP    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      INDEX idx_cap_teams_scenario (scenario_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

    // A physical host bound to one spec, placed at one site.
    `CREATE TABLE IF NOT EXISTS \`${t(TABLES.CAP_HYPERVISORS)}\` (
      id           CHAR(36)     PRIMARY KEY DEFAULT (UUID()),
      scenario_id  CHAR(36)     NOT NULL,
      site_id      CHAR(36)     NOT NULL,
      spec_id      CHAR(36)     NOT NULL,
      name         VARCHAR(255) NOT NULL,
      -- cap-renumber-lock (spec D1/D5): a locked host is never renamed by
      -- renumber. Registered migration entry (fmb-1329 contract). If a DB
      -- never runs the ALTER, the column is absent and renumber's read-side
      -- degraded-schema guard (readTableRows, capacity/renumber.js) treats
      -- every host as unlocked — safe, since with no column there is nowhere
      -- a lock could ever have been stored.
      name_locked  TINYINT(1)   NOT NULL DEFAULT 0,
      -- phase-4 spec §6: persisted drag-reorder order (the
      -- /hypervisors/reorder endpoint rewrites it). New column joins the
      -- fmb-1329 auto-column debt (no migration code; capacity is no-migration).
      order_index  INT          NOT NULL DEFAULT 0,
      metadata     JSON,
      created_at   TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
      updated_at   TIMESTAMP    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      INDEX idx_cap_hypervisors_scenario (scenario_id),
      INDEX idx_cap_hypervisors_site (site_id),
      INDEX idx_cap_hypervisors_spec (spec_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

    // A KVM guest. vm_type lives on the VM itself (no separate workload entity).
    // hypervisor_id NULL = unplaced (lives in the unplaced tray).
    // Rewrite: sizing_profile_id references the GLOBAL cap_vm_profiles catalogue;
    // site_id pins the wizard site (host placement is advisory within it);
    // disk_combo_id / team_id reference global catalogues; database_id is a
    // db_host-only NON-NORMATIVE generation/display hint — structural cluster
    // membership derives from the instances' (database_id, role) (spec §10.3),
    // never from this column.
    `CREATE TABLE IF NOT EXISTS \`${t(TABLES.CAP_VMS)}\` (
      id                CHAR(36)     PRIMARY KEY DEFAULT (UUID()),
      scenario_id       CHAR(36)     NOT NULL,
      vm_type           ENUM('db_host','ap_host') NOT NULL,
      hypervisor_id     CHAR(36)     NULL     DEFAULT NULL,
      site_id           CHAR(36)     NULL     DEFAULT NULL,
      cpu               INT          NOT NULL DEFAULT 0,
      mem_gb            DOUBLE       NOT NULL DEFAULT 0,
      disk_gb           DOUBLE       NOT NULL DEFAULT 0,
      sizing_profile_id CHAR(36)     NULL     DEFAULT NULL,
      disk_combo_id     CHAR(36)     NULL     DEFAULT NULL,
      team_id           CHAR(36)     NULL     DEFAULT NULL,
      database_id       CHAR(36)     NULL     DEFAULT NULL,
      name              VARCHAR(255) NOT NULL,
      -- ap_host function identity (fmb-1329 add-column): the renumber {function}
      -- token for an AP VM resolves from here (empty/NULL falls back to 'ap',
      -- resolveFunctionToken). Nullable with no backfill (decision Q13) — existing
      -- rows read NULL and the user fills them via edit; the API serializer
      -- coalesces NULL to '' (Y-pattern, dto-mapper cap_vms.nullableStrings). A
      -- db_host never reads it: its function comes from the child database
      -- (readHostFunctionRoles), so it stays NULL there.
      function_name     VARCHAR(255) NULL     DEFAULT NULL,
      -- cap-renumber-lock (spec D1/D5): a locked host is never renamed by
      -- renumber. Registered migration entry (fmb-1329 contract). If a DB
      -- never runs the ALTER, the column is absent and renumber's read-side
      -- degraded-schema guard (readTableRows, capacity/renumber.js) treats
      -- every host as unlocked — safe, since with no column there is nowhere
      -- a lock could ever have been stored.
      name_locked       TINYINT(1)   NOT NULL DEFAULT 0,
      -- phase-4 spec §6: persisted drag-reorder order (the /vms/reorder endpoint
      -- rewrites it). New column joins the fmb-1329 auto-column debt (no
      -- migration code; capacity is no-migration).
      order_index       INT          NOT NULL DEFAULT 0,
      metadata          JSON,
      created_at        TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
      updated_at        TIMESTAMP    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      INDEX idx_cap_vms_scenario (scenario_id),
      INDEX idx_cap_vms_hypervisor (hypervisor_id),
      INDEX idx_cap_vms_site (site_id),
      INDEX idx_cap_vms_database (database_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

    // A database instance; only a child of a db_host VM (validated at the CRUD
    // layer). Rewrite: cluster_key is DROPPED — cluster membership derives from
    // (database_id, role) (spec §11). database_id references the first-class
    // cap_databases entity; role tells primary vs standby (never the name).
    `CREATE TABLE IF NOT EXISTS \`${t(TABLES.CAP_DB_INSTANCES)}\` (
      id           CHAR(36)     PRIMARY KEY DEFAULT (UUID()),
      scenario_id  CHAR(36)     NOT NULL,
      vm_id        CHAR(36)     NOT NULL,
      database_id  CHAR(36)     NULL     DEFAULT NULL,
      name         VARCHAR(255) NOT NULL,
      role         ENUM('primary','standby') NOT NULL,
      sga_gb       DOUBLE       NOT NULL DEFAULT 0,
      -- phase-4 spec §6: persisted drag-reorder order (the /db_instances/reorder
      -- endpoint rewrites it). New column joins the fmb-1329 auto-column debt (no
      -- migration code; capacity is no-migration).
      order_index  INT          NOT NULL DEFAULT 0,
      metadata     JSON,
      created_at   TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
      updated_at   TIMESTAMP    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      INDEX idx_cap_db_instances_scenario (scenario_id),
      INDEX idx_cap_db_instances_vm (vm_id),
      INDEX idx_cap_db_instances_database (database_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

    // A first-class Database (rewrite spec §10): function_name is the display +
    // grouping identity; topology drives node/cluster generation; profile/disk/
    // team are global-catalogue references. node_count carries the RAC custom
    // count (primary/standby counts are implied by topology).
    // primary_sga_gb / standby_sga_gb / dc_refs (phase-2 spec §6.1): all three
    // are inheritance-semantic NULLs (Y-pattern note) — NULL means "derive"
    // (profile cap / cap_settings.standby_sga_default_gb) or "all DCs", so the
    // serializer must NOT coalesce them. dc_refs is a JSON list of cap_sites ids.
    `CREATE TABLE IF NOT EXISTS \`${t(TABLES.CAP_DATABASES)}\` (
      id              CHAR(36)     PRIMARY KEY DEFAULT (UUID()),
      scenario_id     CHAR(36)     NOT NULL,
      function_name   VARCHAR(255) NOT NULL,
      -- rac_multinode_standby (spec §7 E1 / Q11) joins the ENUM domain: primary
      -- N nodes (node_count, same field rac_multinode uses) + standby S nodes
      -- (standby_node_count, below) — both sides share ONE name family, serial
      -- per side (Q11), unlike the fixed-2+2 primary_standby (standing NO
      -- fmb-0342, untouched). D12d (fmb-1767): rac_multinode/
      -- rac_multinode_standby are the STORED-VALUE renames of what shipped
      -- as rac/rac_standby through 3.2.783 — see migration-steps.js's
      -- cap_databases_topology_rac_rename entry for the live-row conversion
      -- this DDL literal alone does not perform.
      topology        ENUM('single','primary','primary_standby','rac_multinode','rac_multinode_standby') NOT NULL,
      node_count      INT          NULL     DEFAULT NULL,
      -- rac_multinode_standby's independently-overridable standby node count
      -- (S); NULL for every other topology (primary_standby's standby count
      -- stays the fixed 2 implied by topology, per fmb-0342 — it does not use
      -- this column). Joins the fmb-1329 auto-column debt (no migration code;
      -- capacity is no-migration).
      standby_node_count INT       NULL     DEFAULT NULL,
      profile_id      CHAR(36)     NULL     DEFAULT NULL,
      disk_combo_id   CHAR(36)     NULL     DEFAULT NULL,
      team_id         CHAR(36)     NULL     DEFAULT NULL,
      primary_sga_gb  DOUBLE       NULL     DEFAULT NULL,
      standby_sga_gb  DOUBLE       NULL     DEFAULT NULL,
      dc_refs         JSON         NULL     DEFAULT NULL,
      description     TEXT         NULL     DEFAULT NULL,
      -- phase-6 spec §D8: persisted drag-reorder order for the Databases tab (the
      -- /databases/reorder endpoint rewrites it). New column joins the fmb-1329
      -- auto-column debt (no migration code; capacity is no-migration).
      order_index     INT          NOT NULL DEFAULT 0,
      metadata        JSON,
      created_at    TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
      updated_at    TIMESTAMP    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      INDEX idx_cap_databases_scenario (scenario_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

    // A named explicit-member group (rewrite spec §11.3): the escape hatch for
    // rule targeting when structure does not cover the case. Scenario-level only
    // (global config defines no membership). team_id optional coloring.
    `CREATE TABLE IF NOT EXISTS \`${t(TABLES.CAP_CUSTOM_GROUPS)}\` (
      id           CHAR(36)     PRIMARY KEY DEFAULT (UUID()),
      scenario_id  CHAR(36)     NOT NULL,
      name         VARCHAR(255) NOT NULL,
      team_id      CHAR(36)     NULL     DEFAULT NULL,
      created_at   TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
      updated_at   TIMESTAMP    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      INDEX idx_cap_custom_groups_scenario (scenario_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

    // Explicit membership for a custom group (join table — chosen over a JSON
    // list for referential integrity + queryability as a rule target, spec §17.1).
    // Exactly one of member_vm_id / member_instance_id is set per row.
    `CREATE TABLE IF NOT EXISTS \`${t(TABLES.CAP_CUSTOM_GROUP_MEMBERS)}\` (
      id                 CHAR(36)  PRIMARY KEY DEFAULT (UUID()),
      scenario_id        CHAR(36)  NOT NULL,
      group_id           CHAR(36)  NOT NULL,
      member_vm_id       CHAR(36)  NULL     DEFAULT NULL,
      member_instance_id CHAR(36)  NULL     DEFAULT NULL,
      created_at         TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      INDEX idx_cap_custom_group_members_scenario (scenario_id),
      INDEX idx_cap_custom_group_members_group (group_id),
      -- At most ONE membership per (group, VM) and per (group, DB instance) — the
      -- race backstop for a duplicate-member write (a 1062 maps to 409, not 500).
      -- InnoDB treats NULLs as distinct in a UNIQUE index, and the XOR guard makes
      -- member_vm_id / member_instance_id mutually-exclusive-NULL, so uq_cap_cgm_vm
      -- constrains only VM-member rows and uq_cap_cgm_instance only instance-member
      -- rows (both indexes are needed together to close both duplicate shapes —
      -- uq_cap_rules_override precedent above).
      UNIQUE KEY uq_cap_cgm_vm (group_id, member_vm_id),
      UNIQUE KEY uq_cap_cgm_instance (group_id, member_instance_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

    // A rule instance (rewrite spec §13). Five keeper families = six types.
    // Target is level + structural group_by + built-in-attribute filters (§13.4).
    // Three row kinds by (scenario_id, overrides_rule_id):
    //   global template   = scenario_id NULL,  overrides_rule_id NULL
    //   scenario-local     = scenario_id X,     overrides_rule_id NULL
    //   scenario override  = scenario_id X,     overrides_rule_id <global row id>
    // An override row carries that scenario's enabled/params/severity for the
    // referenced global rule and wins over it in-scenario (never mutates the
    // template). severity is marker weight only — rules never block (§1.2).
    `CREATE TABLE IF NOT EXISTS \`${t(TABLES.CAP_RULES)}\` (
      id                CHAR(36)     PRIMARY KEY DEFAULT (UUID()),
      scenario_id       CHAR(36)     NULL     DEFAULT NULL,
      overrides_rule_id CHAR(36)     NULL     DEFAULT NULL,
      type              ENUM('no-oversell','max-vms-per-host','max-instances-per-vm','keep-apart','spread-across-sites','keep-in-one-site') NOT NULL,
      name              VARCHAR(255) NOT NULL,
      level             ENUM('hypervisor','vm','db_instance') NOT NULL,
      group_by          ENUM('each_database','each_primary_cluster','each_standby_cluster','all_of_type','custom_group') NULL DEFAULT NULL,
      custom_group_id   CHAR(36)     NULL     DEFAULT NULL,
      filters           JSON,
      params            JSON,
      severity          ENUM('hard','soft') NOT NULL DEFAULT 'hard',
      enabled           BOOLEAN      NOT NULL DEFAULT TRUE,
      created_at        TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
      updated_at        TIMESTAMP    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      INDEX idx_cap_rules_scenario (scenario_id),
      INDEX idx_cap_rules_overrides (overrides_rule_id),
      -- At most ONE override per (scenario, global rule) — the race backstop for
      -- the friendly pre-check (a 1062 on this key maps to 409, not 500). InnoDB
      -- treats NULLs as distinct in a UNIQUE index, so global-template rows
      -- (scenario_id NULL) and scenario-local rows (overrides_rule_id NULL) are
      -- unconstrained; only override rows (both columns non-NULL) are unique.
      UNIQUE KEY uq_cap_rules_override (scenario_id, overrides_rule_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

    // The merged VM Profiles catalogue (rewrite spec §3 — cap_sizing_tiers is
    // DROPPED, merged in here). Global: scenario_id NULL = global, X = local.
    // class DB owns an SGA cap; class AP has no SGA. mode formula stores ONLY cpu
    // (mem_gb / sga_cap_gb are computed at read time from the settings formula —
    // derived-never-stored); mode custom stores hand-set cpu/mem_gb/sga_cap_gb.
    // allowed_disk_combos = JSON list of cap_disk_combos ids the profile permits.
    `CREATE TABLE IF NOT EXISTS \`${t(TABLES.CAP_VM_PROFILES)}\` (
      id                  CHAR(36)     PRIMARY KEY DEFAULT (UUID()),
      scenario_id         CHAR(36)     NULL     DEFAULT NULL,
      class               ENUM('DB','AP') NOT NULL,
      name                VARCHAR(255) NOT NULL,
      mode                ENUM('formula','custom') NOT NULL DEFAULT 'formula',
      cpu                 INT          NOT NULL DEFAULT 0,
      mem_gb              DOUBLE       NULL     DEFAULT NULL,
      sga_cap_gb          DOUBLE       NULL     DEFAULT NULL,
      allowed_disk_combos JSON,
      -- phase-6 spec §D3: persisted drag-reorder order on the global config page
      -- (the /config/vm_profiles/reorder endpoint rewrites the global rows). New
      -- column joins the fmb-1329 auto-column debt (no migration code).
      order_index         INT          NOT NULL DEFAULT 0,
      metadata            JSON,
      created_at          TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
      updated_at          TIMESTAMP    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      INDEX idx_cap_vm_profiles_scenario (scenario_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

    // A bundle = a pure global-config template (rewrite spec §7). Stamping drops
    // independent, fully-editable items into a scenario and records NO membership
    // back (no stack concept). serial = display number (#1, #2…).
    `CREATE TABLE IF NOT EXISTS \`${t(TABLES.CAP_BUNDLES)}\` (
      id           CHAR(36)     PRIMARY KEY DEFAULT (UUID()),
      serial       INT          NOT NULL DEFAULT 0,
      name         VARCHAR(255) NOT NULL,
      -- phase-6 spec §D3 (1.5b): persisted drag/move order for the Bundles rail
      -- (the /config/bundles/reorder endpoint rewrites it). serial is now purely a
      -- user-edited label; order_index is the display-order driver. New column
      -- joins the fmb-1329 auto-column debt (no migration code).
      order_index  INT          NOT NULL DEFAULT 0,
      created_at   TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
      updated_at   TIMESTAMP    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      -- serial is a user-edited label (#1, #2…) — UNIQUE so two bundles never share
      -- one. Backstops the friendly duplicate-serial pre-check (a 1062 maps to 409);
      -- serial is NOT NULL so there is no NULL-distinct complication.
      UNIQUE KEY uq_cap_bundles_serial (serial)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

    // One prepared row inside a bundle (spec §7.3). function_name + team_id are
    // per row. Global-config table: profile/disk/team refs must be GLOBAL rows
    // (write-validated, spec §17.1a). prefill_custom_group = an ordinary item
    // setting pre-fill, NOT a link back to the bundle. primary_sga_gb /
    // standby_sga_gb (phase-2 spec §6.1): nullable seed values a stamp carries
    // into the wizard's SGA fields (NULL = inherit the derive chain, same
    // inheritance-semantic Y-pattern as cap_databases' own SGA columns).
    // topology carries the FULL 5-member domain (AR2-Q8): a bundle item can
    // template rac_multinode_standby, so standby_node_count joins node_count as
    // the independently-overridable standby count S (NULL = derive the default
    // S=N from the topology's node semantics, resolveNodeCounts) — the same
    // inheritance-semantic Y-pattern cap_databases.standby_node_count uses.
    `CREATE TABLE IF NOT EXISTS \`${t(TABLES.CAP_BUNDLE_ITEMS)}\` (
      id                   CHAR(36)     PRIMARY KEY DEFAULT (UUID()),
      bundle_id            CHAR(36)     NOT NULL,
      order_index          INT          NULL     DEFAULT NULL,
      type                 ENUM('DB','AP') NOT NULL,
      qty                  INT          NOT NULL DEFAULT 1,
      profile_id           CHAR(36)     NULL     DEFAULT NULL,
      function_name        VARCHAR(255) NOT NULL DEFAULT '',
      topology             ENUM('single','primary','primary_standby','rac_multinode','rac_multinode_standby') NULL DEFAULT NULL,
      node_count           INT          NULL     DEFAULT NULL,
      standby_node_count   INT          NULL     DEFAULT NULL,
      disk_combo_id        CHAR(36)     NULL     DEFAULT NULL,
      team_id              CHAR(36)     NULL     DEFAULT NULL,
      primary_sga_gb       DOUBLE       NULL     DEFAULT NULL,
      standby_sga_gb       DOUBLE       NULL     DEFAULT NULL,
      prefill_custom_group VARCHAR(255) NULL     DEFAULT NULL,
      created_at           TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
      updated_at           TIMESTAMP    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      INDEX idx_cap_bundle_items_bundle (bundle_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

    // Custom-field definitions per entity type; values live in each entity's
    // metadata JSON under field_key. Rewrite (spec §8): GLOBAL-ONLY (scenario_id
    // always NULL — no scenario-local defs); +required +default_value; order_index
    // DROPPED; entity_type gains 'database' (the first-class entity). (Column named
    // field_key, not the spec's `key`, to avoid the SQL reserved word.)
    // uq_cap_field_defs_identity: two defs sharing (scenario_id, entity_type,
    // field_key) would both own the identical metadata JSON key on their entity —
    // the second save silently shadows the first. The app layer rejects this
    // (config.js); this UNIQUE index is the DB backstop.
    // INVARIANT/LIMITATION: MariaDB treats each NULL as distinct in a UNIQUE
    // index, so for the current global-only rows (scenario_id NULL) it fires only
    // for scenario-scoped rows; the app-layer check remains the global enforcer.
    `CREATE TABLE IF NOT EXISTS \`${t(TABLES.CAP_FIELD_DEFS)}\` (
      id            CHAR(36)     PRIMARY KEY DEFAULT (UUID()),
      scenario_id   CHAR(36)     NULL     DEFAULT NULL,
      entity_type   ENUM('scenario','site','hardware_spec','hypervisor','vm','db_instance','database') NOT NULL,
      field_key     VARCHAR(255) NOT NULL,
      label         VARCHAR(255),
      data_type     ENUM('text','number','bool','enum') NOT NULL,
      required      BOOLEAN      NOT NULL DEFAULT FALSE,
      default_value VARCHAR(255) NULL     DEFAULT NULL,
      options       JSON,
      created_at    TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
      updated_at    TIMESTAMP    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      INDEX idx_cap_field_defs_scenario (scenario_id),
      UNIQUE KEY uq_cap_field_defs_identity (scenario_id, entity_type, field_key)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

    // Formula constants + display settings (rewrite spec §9.3). A default global
    // row (scenario_id NULL) is SEEDED at schema creation (spec §9.2 guard 1) so
    // the "never configured" state ceases to exist. Constants drive
    // MEM = CPU × mem_cpu_ratio and SGA cap = floor(MEM × sga_factor / sga_divisor
    // − sga_subtract) (§3.4). Only the numbers are editable; structure is fixed.
    // A scenario may hold a local override row.
    // standby_sga_default_gb (phase-2 spec §6.1/§6.3, Q1 DECIDED): the
    // operator-editable global standby-SGA fallback every standby-default
    // resolution reads (bundle-item seed, wizard default, per-instance
    // derivation) when cap_databases.standby_sga_gb is unset.
    `CREATE TABLE IF NOT EXISTS \`${t(TABLES.CAP_SETTINGS)}\` (
      id                         CHAR(36)  PRIMARY KEY DEFAULT (UUID()),
      scenario_id                CHAR(36)  NULL     DEFAULT NULL,
      mem_cpu_ratio              DOUBLE    NOT NULL DEFAULT 20,
      sga_factor                 DOUBLE    NOT NULL DEFAULT 0.982,
      sga_divisor                DOUBLE    NOT NULL DEFAULT 2,
      sga_subtract               DOUBLE    NOT NULL DEFAULT 2,
      standby_sga_default_gb     DOUBLE    NOT NULL DEFAULT 32,
      util_amber_pct             DOUBLE    NOT NULL DEFAULT 80,
      util_red_pct               DOUBLE    NOT NULL DEFAULT 90,
      overcommit_default_enabled BOOLEAN   NOT NULL DEFAULT FALSE,
      layer_defaults             JSON,
      -- Per-entity-type hostname patterns (spec B5a, cap-pattern-function D2/D8):
      -- a whole-set override object { hypervisor, kvm_host_primary,
      -- kvm_host_standby, ap_vm } of {dc}/{function}/{seq} templates. NULL =
      -- inherited (a scenario row falls back to the global row; the global row
      -- NULL falls back to the built-in DEFAULT_NAME_PATTERNS). Nullable so an
      -- existing row keeps today's built-in names with nothing to backfill.
      name_patterns              JSON     NULL,
      -- Dense-placement layout config (post-ar2-residuals P6; later extended
      -- with dense_fill_strategy/dense_flow): a per-key override object
      -- { dense_threshold?, dense_columns?, dense_hosts_per_column?,
      -- dense_fill_strategy?, dense_flow? }. NULL = inherit (a scenario row
      -- falls back to the global row; the global row NULL falls back to the
      -- built-in defaults). Per-KEY merge, unlike
      -- name_patterns' whole-set override — a present key overrides, an absent
      -- key still inherits from the next tier up.
      placement_layout           JSON     NULL,
      created_at                 TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at                 TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      INDEX idx_cap_settings_scenario (scenario_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

    // A frozen snapshot of a scenario (full deep copy of every scenario-scoped
    // row at freeze time, JSON). The `snapshot` column is append-only and never
    // updated — that is the guarantee the whole feature rests on. `name` and
    // `note` are labels and ARE editable through the versions PUT route, which
    // is a whitelist of exactly those two columns and refuses a request that
    // mentions any other.
    `CREATE TABLE IF NOT EXISTS \`${t(TABLES.CAP_VERSIONS)}\` (
      id           CHAR(36)     PRIMARY KEY DEFAULT (UUID()),
      scenario_id  CHAR(36)     NOT NULL,
      name         VARCHAR(255) NOT NULL,
      note         TEXT         NULL     DEFAULT NULL,
      snapshot     JSON,
      created_at   TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
      created_by   CHAR(36)     NULL     DEFAULT NULL,
      INDEX idx_cap_versions_scenario (scenario_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

    // A per-occurrence accepted exception for one computed violation.
    // object_set_key is a deterministic serialization over the sorted subject-id
    // set — a waiver re-matches on recompute when the subject set is unchanged.
    `CREATE TABLE IF NOT EXISTS \`${t(TABLES.CAP_WAIVERS)}\` (
      id             CHAR(36)     PRIMARY KEY DEFAULT (UUID()),
      scenario_id    CHAR(36)     NOT NULL,
      rule_id        CHAR(36)     NOT NULL,
      object_set_key VARCHAR(512) NOT NULL,
      note           TEXT         NULL     DEFAULT NULL,
      created_at     TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
      created_by     CHAR(36)     NULL     DEFAULT NULL,
      INDEX idx_cap_waivers_scenario (scenario_id),
      INDEX idx_cap_waivers_rule (rule_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  ];
}

function buildAllTableDDLs(t) {
  return [...buildInfraTableDDLs(t), ...buildEngineTableDDLs(t)];
}

/** Infrastructure table base names (without prefix) for admin operations */
const INFRA_TABLE_NAMES = [
  'users',
  'login_audit',
  'system_settings',
  'db_connections',
  'access_rules',
  'feature_audit',
  'service_accounts',
  'service_account_idempotency',
];

/**
 * Infra tables that admin UI MUST NOT clear via destructive endpoints
 * (truncate-table OR drop-table). The audit log itself goes here:
 * an admin who can wipe `feature_audit` can erase their own
 * destructive-operation trail including the wipe itself, breaking
 * forensic recovery. Direct DBA access via MariaDB CLI remains the
 * supported path for retention cleanup.
 *
 * INVARIANT: every entry MUST also appear in INFRA_TABLE_NAMES — an
 * orphan entry would silently pass the allowlist check and never
 * reach the denylist check at runtime. Enforced by the assertion
 * below at module load.
 *
 * service_accounts + service_account_idempotency join this denylist because
 * they hold auth material (token_hash / scope) an admin must not be able to
 * wipe via the destructive table-clear endpoints. `users` joins for the same
 * reason: it holds the platform's password hashes, whose loss is unrecoverable
 * and would lock every account (including the only admin) out of the platform.
 */
const INFRA_TRUNCATE_DENYLIST = Object.freeze(['feature_audit', 'service_accounts', 'service_account_idempotency', 'users']);

// Structural drift guard — see INVARIANT above.
for (const denied of INFRA_TRUNCATE_DENYLIST) {
  if (!INFRA_TABLE_NAMES.includes(denied)) {
    throw new Error(
      `INFRA_TRUNCATE_DENYLIST entry '${denied}' is not in INFRA_TABLE_NAMES. ` +
      `Orphan denylist entries silently pass the allowlist check at runtime.`,
    );
  }
}

/** Engine table base names (without prefix) for export/seed operations */
const ENGINE_TABLE_NAMES = [
  'hierarchy_nodes',
  'blueprint_fields',
  'field_options',
  'blueprint_sections',
  'blueprint_groups',
  'blueprint_output_order',
  'variant_overrides',
  'user_templates',
  'transformers',
  'transformer_versions',
  'api_connectors',
  'flow_recipes',
  'flow_recipe_steps',
  'flow_recipe_runs',
  'flow_recipe_code_versions',
  'decision_tables',
  'delegated_grants',
  'template_activity',
  'template_snapshots',
  'template_versions',
  'api_connector_blueprints',
  // Capacity Planner (App-tier) — config-rewrite table set (spec §17.1).
  // cap_sizing_tiers DROPPED (merged into cap_vm_profiles); 7 new tables added.
  'cap_scenarios',
  'cap_sites',
  'cap_hardware_specs',
  'cap_disk_combos',
  'cap_teams',
  'cap_hypervisors',
  'cap_databases',
  'cap_vms',
  'cap_db_instances',
  'cap_custom_groups',
  'cap_custom_group_members',
  'cap_bundles',
  'cap_bundle_items',
  'cap_rules',
  'cap_vm_profiles',
  'cap_field_defs',
  'cap_settings',
  'cap_versions',
  'cap_waivers',
];

module.exports = {
  buildInfraTableDDLs,
  buildEngineTableDDLs,
  buildAllTableDDLs,
  INFRA_TABLE_NAMES,
  INFRA_TRUNCATE_DENYLIST,
  ENGINE_TABLE_NAMES,
};
