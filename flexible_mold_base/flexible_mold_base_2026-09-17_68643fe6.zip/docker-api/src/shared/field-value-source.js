/**
 * field-value-source — the vocabulary of `blueprint_fields.value_source`, and
 * the one place that decides whether a mode and the payload columns beside it
 * are saying the same thing.
 *
 * WHY A STORED MODE AT ALL. Before this column the mode was read back OUT of
 * the payload: a row with a compute_rule was computed, a row with is_locked was
 * locked, and a row with neither was typed in by hand. That is an inference, and
 * two of those columns could be populated at once, so the authoring surfaces and
 * the runtime resolver each had to pick a winner and could disagree about it.
 * The mode is now stated, and the payload columns are the mode's arguments.
 *
 * WHAT KEEPS THE STATEMENT TRUE, AND EXACTLY HOW FAR IT REACHES.
 * `checkValueSourcePayload` reads a REQUEST BODY, and a body is only the whole
 * row on the paths where it is the whole row. Stated as the four combinations
 * of "does the body name the mode / does it name the payload", because three
 * are covered here and the fourth is not, and an earlier version of this
 * paragraph said "every incoherent combination":
 *
 *   mode + payload   both present   refused when they disagree — the ordinary case
 *   payload, no mode                refused outright (`MODE_OWNED_COLUMNS`): a
 *                                   payload column written alone would repurpose
 *                                   the stored mode, and an explicit null is the
 *                                   dangerous half, not the harmless one
 *   neither                         nothing to judge
 *   MODE, NO PAYLOAD                INVISIBLE HERE. The absent key reads as
 *                                   null, so 'entered' with no compute_rule key
 *                                   looks coherent — while a partial UPDATE
 *                                   leaves the stored rule exactly where it was
 *
 * That fourth quadrant is not a hole this function can close: it cannot see the
 * row. On a CREATE or an IMPORT the body IS the row, so the quadrant cannot
 * arise; on the partial PUT it is caught by `postStateInconsistent` in
 * routes-blueprint-fields.js, which runs this same predicate against the
 * refreshed row inside the transaction. A new partial-write path that does not
 * do likewise reopens it.
 *
 * IT ALSO DOES NOT COVER A WRITE THE SERVER ISSUES ITSELF. A route that clears
 * a payload column in its own UPDATE never passes a body through this function,
 * and one such write manufactured exactly the row the boundary refuses (the
 * type-change rule clear in routes-blueprint-fields.js). Those writes are the
 * caller's responsibility, and `modeAfterPayloadClear` below is the one answer
 * to "which mode must move with the payload I am about to clear?". Nothing
 * mechanically forces a new server-side clear to ask it: this module can only
 * offer the answer, not detect the question.
 *
 * WHAT IS NOT IN HERE, and deliberately. A decision table filling a field is
 * NOT one of these values. A decision table lives in its own row, is authored on
 * its own tab, and can be deleted without this table being written at all — a
 * value_source saying "a decision table fills this" would be a claim this
 * boundary cannot keep true, which is the exact failure this column exists to
 * avoid. 'entered' therefore means "no column of this row fills the field", and
 * whether a decision table does is answered by reading the decision tables.
 */

const { invalidCellTargetsShape, scopeNarrows } = require('./cell-targets-validate');

/** No column of this row fills the field. Also the state a decision table needs. */
const VALUE_SOURCE_ENTERED = 'entered';
/** Mirrors another field's value. Stored as its single-source compute rule. */
const VALUE_SOURCE_COPIED = 'copied';
/** A compute rule derives the value. */
const VALUE_SOURCE_CALCULATED = 'calculated';
/** Read-only in every variant, with no value of its own. */
const VALUE_SOURCE_LOCKED = 'locked';

const FIELD_VALUE_SOURCES = Object.freeze([
  VALUE_SOURCE_ENTERED,
  VALUE_SOURCE_COPIED,
  VALUE_SOURCE_CALCULATED,
  VALUE_SOURCE_LOCKED,
]);

const DEFAULT_VALUE_SOURCE = VALUE_SOURCE_ENTERED;

/** The modes whose payload is a compute rule. */
const COMPUTE_BACKED_SOURCES = Object.freeze([VALUE_SOURCE_COPIED, VALUE_SOURCE_CALCULATED]);

/**
 * Columns that only mean anything as an argument to a mode. Present in a write
 * body without `value_source`, they would change what the row does while the
 * stored mode kept describing the previous arrangement.
 *
 * PRESENCE IS THE TEST, NOT THE VALUE. An explicit `null` is the most dangerous
 * of the two shapes, not the harmless one: `{compute_rule: null}` alone strips
 * the rule that a stored 'copied'/'calculated' row IS, leaving a mode label over
 * nothing — the read-only mirror silently becomes an ordinary editable field.
 * Clearing a payload is therefore a mode change like any other and has to say so.
 */
const MODE_OWNED_COLUMNS = Object.freeze(['compute_rule', 'value_scope']);

/**
 * THE MIRROR OF THE ABOVE, and the reason it is written down rather than left
 * implicit. `MODE_OWNED_COLUMNS` names the payload, so every sweep it invites is
 * a sweep for "a payload written without its mode". The same incoherent row is
 * produced by the other direction — a MODE written without its payload — and
 * both defects this branch shipped were that direction. A sweep that only asks
 * this module's question will miss them again.
 *
 * Every path that can set `value_source`, and what covers the mirror case:
 *   PUT /blueprint_fields/:id (custom)  `postStateInconsistent` re-reads the row
 *   POST /blueprint_fields (factory)    body is the row; nothing stored to strand
 *   PUT via the factory                 unreachable — the custom handler is
 *                                       registered first (schema/index.js)
 *   ALTER … ADD value_source            the translation registry step, ordered
 *                                       before the is_locked drop
 *   the type-change rule clear          `modeAfterPayloadClear`, below
 *   YAML / JSON import                  rows arrive whole; the import guard judges
 *   blueprint export / clone            whole-row INSERTs, both columns together
 */

const CODE = 'INCONSISTENT_VALUE_SOURCE';

function isValueSource(value) {
  return FIELD_VALUE_SOURCES.includes(value);
}

/**
 * `copied` is a retired mode: a stored `copied` row already carries a
 * one-part mirror rule with `overridable: false`, byte-equivalent to a
 * non-overridable `calculated` field (see `readValueSourceForEditor`, the FE
 * twin of this collapse, field-value-source.ts). Every BE site that writes a
 * NEW row from an existing one (subset copy, both fingerprints) must land on
 * `calculated`, never re-mint `copied` — the write boundary
 * (`checkValueSourcePayload` above) still accepts `copied` on import, so this
 * is a one-directional collapse, not a ban on the stored value.
 */
function normalizeLegacyValueSource(value) {
  return value === VALUE_SOURCE_COPIED ? VALUE_SOURCE_CALCULATED : value;
}

/**
 * The same collapse, applied to a TABLE field's per-column rules
 * (`table_config.columns[].rules.value_source`) instead of the field-level
 * column above. A field-level `copied` can never reach a NEW row through the
 * write boundary (`checkValueSourcePayload`), but the JSON `table_config`
 * column has no such boundary, so every site that fingerprints or re-mints a
 * `table_config` from an existing one (subset copy, both fingerprint ports)
 * must apply this collapse first or it will re-mint / re-hash a retired
 * stored value the field-level column can never carry.
 */
function normalizeTableConfigColumnsValueSource(tableConfig) {
  let cfg = tableConfig;
  if (typeof cfg === 'string') {
    try { cfg = JSON.parse(cfg); } catch { return tableConfig; }
  }
  if (!cfg || typeof cfg !== 'object' || Array.isArray(cfg) || !Array.isArray(cfg.columns)) return tableConfig;
  let changed = false;
  const columns = cfg.columns.map((col) => {
    if (!col || typeof col !== 'object' || Array.isArray(col)) return col;
    const rules = col.rules;
    if (!rules || typeof rules !== 'object' || Array.isArray(rules)) return col;
    const normalized = normalizeLegacyValueSource(rules.value_source);
    if (normalized === rules.value_source) return col;
    changed = true;
    return { ...col, rules: { ...rules, value_source: normalized } };
  });
  return changed ? { ...cfg, columns } : tableConfig;
}

/** True when the mode's value is produced by a compute rule. */
function isComputeBacked(valueSource) {
  return COMPUTE_BACKED_SOURCES.includes(valueSource);
}

/**
 * Is this rule the "just mirror another field" shape?
 *
 * 'copied' and 'calculated' share one payload column, so the mode is the only
 * thing telling them apart — and a mode that can say "copied" over an
 * eight-operand arithmetic rule is a label, not a fact. The shape is therefore
 * checked rather than trusted: one `concat` part naming one field, no separator
 * to speak of, and no per-part `transforms` — a concat part can carry its
 * own `transforms`, and this predicate must reject one that does. A part
 * with a transform is a DERIVED value, not a mirror —
 * `upper(a)` is not "just" `a` — so it now fails the shape check and falls to
 * 'calculated' like any other non-trivial rule. The authoring surface writes
 * the untransformed shape exactly and shows the author no rule builder for
 * it.
 */
function isSingleFieldMirror(rule) {
  if (!rule || typeof rule !== 'object' || rule.op !== 'concat') return false;
  const config = rule.config;
  if (!config || typeof config !== 'object') return false;
  if (config.separator !== undefined && config.separator !== '') return false;
  const parts = config.parts;
  if (!Array.isArray(parts) || parts.length !== 1) return false;
  const [part] = parts;
  if (!part || typeof part !== 'object' || part.type !== 'field'
    || typeof part.key !== 'string' || part.key === '') return false;
  if (Array.isArray(part.transforms) && part.transforms.length > 0) return false;
  return true;
}

/**
 * Does a write body's mode agree with the payload columns in the same body?
 *
 * Reads the BODY, never the stored row, and that is what makes it enforceable
 * on one connection with no read: `MODE_OWNED_COLUMNS` forces a caller changing
 * a payload to restate the mode, so the body always carries the whole
 * arrangement and the post-state is decidable from it alone.
 *
 * `fieldType` is the effective type of the row after the write (the caller
 * resolves it against the stored row on a partial update), because a cell scope
 * is only addressable on a `table` field.
 *
 * @param {object} body            the write body, already DTO-mapped
 * @param {object} opts
 * @param {string} opts.fieldType  effective field_type after this write
 * @param {(v: unknown) => object|null} [opts.parseRule] parses a stored/incoming
 *        rule into an object, defaulting to "already an object"
 * @param {(v: unknown) => boolean} [opts.hasScope] reads a scope document as
 *        "narrows something". Defaults to `scopeNarrows`, the resolver's own
 *        reading, which also accepts the SERIALIZED form — every caller had
 *        hand-written this predicate, and the YAML import path's copy accepted
 *        objects only while that path stores the column as a string, so both of
 *        its scope refusals were unreachable. Override only to answer a
 *        different question, not to re-state this one.
 * @returns {{code: string, detail: string}|null} null when coherent
 */
function checkValueSourcePayload(body, opts) {
  const {
    fieldType,
    parseRule = (v) => (v && typeof v === 'object' ? v : null),
    hasScope = scopeNarrows,
  } = opts || {};
  const has = (key) => Object.prototype.hasOwnProperty.call(body, key);

  if (!has('value_source')) {
    // A payload column arriving alone would silently repurpose the stored mode —
    // including, and especially, when it arrives as an explicit null. See
    // MODE_OWNED_COLUMNS.
    const orphan = MODE_OWNED_COLUMNS.find((column) => has(column));
    if (orphan) {
      return {
        code: CODE,
        detail: `${orphan} must be written together with value_source`,
      };
    }
    return null;
  }

  const source = body.value_source;
  if (!isValueSource(source)) {
    return {
      code: CODE,
      detail: `value_source must be one of: ${FIELD_VALUE_SOURCES.join(', ')}`,
    };
  }

  const rawRule = has('compute_rule') ? body.compute_rule : null;
  const rule = rawRule == null ? null : parseRule(rawRule);
  if (isComputeBacked(source)) {
    if (rule === null) {
      return { code: CODE, detail: `value_source='${source}' requires a compute_rule` };
    }
    if (source === VALUE_SOURCE_COPIED && !isSingleFieldMirror(rule)) {
      return {
        code: CODE,
        detail: "value_source='copied' requires a compute_rule that reads exactly one field",
      };
    }
  } else if (rawRule != null) {
    return { code: CODE, detail: `value_source='${source}' must not carry a compute_rule` };
  }

  const rawScope = has('value_scope') ? body.value_scope : null;
  if (rawScope != null) {
    // SECURITY: the write routes build their SET/INSERT column list from the
    // request body, so an unchecked document is persisted verbatim and then
    // re-parsed by every render of every affected form. The sibling column
    // (`variant_overrides.cell_targets`) has been shape-checked since it
    // shipped; this is the same document and gets the same check, from the same
    // function, so the two columns cannot drift apart on what they accept.
    const badShape = invalidCellTargetsShape(rawScope, { label: 'value_scope' });
    if (badShape) return { code: CODE, detail: badShape };
  }
  if (rawScope != null && hasScope(rawScope)) {
    if (source === VALUE_SOURCE_ENTERED) {
      return { code: CODE, detail: "value_source='entered' must not carry a value_scope" };
    }
    if (fieldType !== 'table') {
      return { code: CODE, detail: `field_type='${fieldType}' must not carry a value_scope` };
    }
  }

  return null;
}

/**
 * Which mode a row must carry once the SERVER clears a payload column on its
 * own — the shape `checkValueSourcePayload` cannot judge, because there is no
 * request body stating the pair.
 *
 * WHAT IT ENFORCES: 'copied' and 'calculated' ARE their rule. Clear the rule and
 * the mode names a payload that is not there, which is the row every request
 * path is refused for — and the row the field editor can then never save,
 * because it spreads the whole form back and gets its own stored state rejected.
 * So the mode drops to 'entered' with the rule.
 *
 * WHAT IT DOES NOT: it does not decide whether clearing was right, and it does
 * not report a change in MEANING. Clearing a `value_scope` returns null — no
 * mode is left describing an absent payload — even though the setting's reach
 * silently widens from named cells to the whole field. That widening is real and
 * this function is not where it is announced.
 *
 * A mode of null (a DB with no `value_source` column) returns null too: there is
 * no stored mode to keep true, and writing one would name a column the caller
 * has already established does not exist.
 *
 * @param {string|null|undefined} storedSource the row's mode before the clear
 * @param {readonly string[]} clearedColumns which MODE_OWNED_COLUMNS go to NULL
 * @returns {string|null} the value_source to write alongside, or null when the
 *   stored mode still describes the row truthfully
 */
function modeAfterPayloadClear(storedSource, clearedColumns) {
  if (!Array.isArray(clearedColumns) || !clearedColumns.includes('compute_rule')) return null;
  return isComputeBacked(storedSource) ? VALUE_SOURCE_ENTERED : null;
}

module.exports = {
  FIELD_VALUE_SOURCES,
  DEFAULT_VALUE_SOURCE,
  COMPUTE_BACKED_SOURCES,
  MODE_OWNED_COLUMNS,
  VALUE_SOURCE_ENTERED,
  VALUE_SOURCE_COPIED,
  VALUE_SOURCE_CALCULATED,
  VALUE_SOURCE_LOCKED,
  isValueSource,
  normalizeLegacyValueSource,
  normalizeTableConfigColumnsValueSource,
  isComputeBacked,
  isSingleFieldMirror,
  checkValueSourcePayload,
  modeAfterPayloadClear,
};
