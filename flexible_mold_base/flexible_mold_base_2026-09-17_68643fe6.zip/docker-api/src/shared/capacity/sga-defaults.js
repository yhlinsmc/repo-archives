/**
 * sga-defaults.js — the shared, pure SGA derivation-by-role fallback chain
 * (phase-2 spec §6.3). Both a primary and a standby instance's persisted
 * `sga_gb` derive from exactly this chain so there is one authoring locus;
 * the shared constant `STANDBY_SGA_DEFAULT_GB` survives only as the DB seed
 * value (`cap_settings.standby_sga_default_gb DEFAULT 32`), never a
 * competing runtime default (spec §6.1 "the 32 default" note).
 *
 * Pure (no I/O) so it is unit-testable without a DOM or a DB connection; the
 * write-path caller (wizard.js) resolves `database`/`settings`/
 * `profile` from its own queries and passes plain rows/values in.
 */
'use strict';

const { floorGb } = require('./whole-numbers');

/** The DB DEFAULT 32 seed value — the last link in the standby-default
 *  resolution chain (bundle-item seed -> cap_settings row -> this seed) when
 *  a caller cannot otherwise supply a settings row. */
const STANDBY_SGA_DEFAULT_GB = 32;

/**
 * The scenario-effective standby SGA default: the settings row's own value
 * when present, else the DB seed constant. A settings row is expected to
 * always carry a value once the DDL default lands (no data backfill needed),
 * but a defensive fallback keeps this helper safe to call before
 * that row exists (e.g. a test fixture with no settings row at all).
 *
 * @param {{ standby_sga_default_gb?: number | null } | null | undefined} settings
 * @returns {number}
 */
function resolveStandbyDefault(settings) {
  if (settings && settings.standby_sga_default_gb != null) return settings.standby_sga_default_gb;
  return STANDBY_SGA_DEFAULT_GB;
}

/**
 * Derive a DB instance's persisted `sga_gb` by role (spec §6.3):
 *   - primary -> `database.primary_sga_gb` if set, else the profile-derived
 *     cap (0 when no profile / not derivable).
 *   - standby -> `database.standby_sga_gb` if set, else the scenario-effective
 *     `cap_settings.standby_sga_default_gb` (falling all the way back to the
 *     seed 32 when no settings row is available).
 *
 * @param {'primary' | 'standby'} role
 * @param {{ primary_sga_gb?: number | null, standby_sga_gb?: number | null } | null | undefined} database
 * @param {{ standby_sga_default_gb?: number | null } | null | undefined} settings
 * @param {{ sgaCapGb?: number | null } | null | undefined} profile - the
 *   already-resolved DB-class profile sizing for a primary instance (null/
 *   undefined when no profile or a not-derivable class, e.g. AP)
 * @returns {number}
 */
function deriveInstanceSga(role, database, settings, profile) {
  return floorGb(resolveInstanceSgaRaw(role, database, settings, profile));
}

/** The chain itself, before the whole-number rule is applied. Every branch reads
 *  a nullable DOUBLE the schema never migrated, so a row written before
 *  can still carry a fraction — `deriveInstanceSga` floors the winner
 *  once, at the single exit, rather than each branch flooring its own. */
function resolveInstanceSgaRaw(role, database, settings, profile) {
  if (role === 'standby') {
    if (database && database.standby_sga_gb != null) return database.standby_sga_gb;
    return resolveStandbyDefault(settings);
  }
  if (database && database.primary_sga_gb != null) return database.primary_sga_gb;
  return profile && profile.sgaCapGb != null ? profile.sgaCapGb : 0;
}

module.exports = {
  STANDBY_SGA_DEFAULT_GB,
  resolveStandbyDefault,
  deriveInstanceSga,
};
