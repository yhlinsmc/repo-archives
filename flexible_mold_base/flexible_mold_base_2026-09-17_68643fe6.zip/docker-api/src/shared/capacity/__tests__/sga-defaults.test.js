/**
 * sga-defaults.test.js — the shared SGA derivation-by-role helper (spec §6.3).
 * Guards the fallback chain both the wizard write path and any
 * future recompute path read, so primary/standby SGA derivation has exactly
 * one authoring locus.
 *
 * Runner: vitest (root suite picks up docker-api/src/**\/__tests__).
 */
import { describe, it, expect } from 'vitest';
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
const {
  deriveInstanceSga, resolveStandbyDefault, STANDBY_SGA_DEFAULT_GB,
} = require('../sga-defaults');

describe('sga-defaults', () => {
  describe('STANDBY_SGA_DEFAULT_GB', () => {
    it('is the DB DEFAULT 32 seed value (spec §6.1)', () => {
      expect(STANDBY_SGA_DEFAULT_GB).toBe(32);
    });
  });

  describe('resolveStandbyDefault (bundle-item -> setting -> seed chain, setting half)', () => {
    it('reads cap_settings.standby_sga_default_gb when the row carries one', () => {
      expect(resolveStandbyDefault({ standby_sga_default_gb: 48 })).toBe(48);
    });

    it('falls back to the seed 32 when the settings row is missing', () => {
      expect(resolveStandbyDefault(null)).toBe(32);
      expect(resolveStandbyDefault(undefined)).toBe(32);
    });

    it('falls back to the seed 32 when the settings row has no value set', () => {
      expect(resolveStandbyDefault({})).toBe(32);
      expect(resolveStandbyDefault({ standby_sga_default_gb: null })).toBe(32);
    });
  });

  describe('deriveInstanceSga — primary (spec §6.3: primary_sga_gb ?? profileCap)', () => {
    it('uses the database explicit primary_sga_gb when set', () => {
      const database = { primary_sga_gb: 64, standby_sga_gb: null };
      const profile = { sgaCapGb: 100 };
      expect(deriveInstanceSga('primary', database, {}, profile)).toBe(64);
    });

    it('falls back to the profile-derived cap when primary_sga_gb is unset', () => {
      const database = { primary_sga_gb: null, standby_sga_gb: null };
      const profile = { sgaCapGb: 88 };
      expect(deriveInstanceSga('primary', database, {}, profile)).toBe(88);
    });

    it('falls back to 0 when neither the database value nor a profile cap is available', () => {
      expect(deriveInstanceSga('primary', null, {}, null)).toBe(0);
      expect(deriveInstanceSga('primary', { primary_sga_gb: null }, {}, { sgaCapGb: null })).toBe(0);
    });
  });

  describe('deriveInstanceSga — standby (spec §6.3: standby_sga_gb ?? cap_settings.standby_sga_default_gb)', () => {
    it('uses the database explicit standby_sga_gb when set', () => {
      const database = { primary_sga_gb: null, standby_sga_gb: 40 };
      expect(deriveInstanceSga('standby', database, { standby_sga_default_gb: 32 }, null)).toBe(40);
    });

    it('falls back to the scenario-effective settings default when standby_sga_gb is unset', () => {
      const database = { primary_sga_gb: null, standby_sga_gb: null };
      expect(deriveInstanceSga('standby', database, { standby_sga_default_gb: 48 }, null)).toBe(48);
    });

    it('falls back all the way to the seed 32 when both the database value and the settings row are absent', () => {
      expect(deriveInstanceSga('standby', null, null, null)).toBe(32);
      expect(deriveInstanceSga('standby', { standby_sga_gb: null }, {}, null)).toBe(32);
    });

    it('ignores the profile cap entirely for a standby (that fallback is primary-only)', () => {
      const database = { primary_sga_gb: null, standby_sga_gb: null };
      const profile = { sgaCapGb: 999 };
      expect(deriveInstanceSga('standby', database, { standby_sga_default_gb: 32 }, profile)).toBe(32);
    });
  });
});
