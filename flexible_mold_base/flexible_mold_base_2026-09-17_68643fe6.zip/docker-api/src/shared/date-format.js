'use strict';

// BE mirror of src/platform/lib/date-format.ts (owner rule 2026-09-13, §4c:
// ONE home per runtime). docker-api has no date-fns dependency (checked
// package.json before writing this), so this is the same plain
// string/Date-arithmetic algorithm as the FE file rather than a date-fns
// port — running two different date engines could disagree on an edge case
// the shared fixture (docker-api/tests/fixtures/date-format-cases.json)
// happens not to cover. The BE never formats for output (§4 of the spec);
// formatDate exists here only for the serialization/import round-trip.

const DATE_FORMATS = ['YYYY-MM-DD', 'YYYY/MM/DD', 'DD/MM/YYYY', 'MM/DD/YYYY', 'YYYYMMDD', 'DD-MMM-YYYY'];

const DEFAULT_DATE_FORMAT = 'YYYY-MM-DD';

const MONTH_ABBR = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

function pad2(n) {
  return String(n).padStart(2, '0');
}

function pad4(n) {
  return String(n).padStart(4, '0');
}

// One rule for the year domain, in both runtimes: the
// domain is 0001-9999, constructed via `setUTCFullYear` rather than
// `Date.UTC(y, ...)` — `Date.UTC` (and the multi-arg `Date` constructor) maps
// a year 0-99 to 1900+year per spec (a two-digit-year convenience meant for
// `new Date(99, 0, 1)`), which silently turned every year below 100 into an
// 1900s one and made every such year fail this round-trip as 'impossible'.
// `setUTCFullYear` carries no such special case.
function isValidYmd(y, m, d) {
  if (!Number.isInteger(y) || !Number.isInteger(m) || !Number.isInteger(d)) return false;
  if (y < 1 || y > 9999) return false;
  if (m < 1 || m > 12 || d < 1 || d > 31) return false;
  const dt = new Date(0);
  dt.setUTCFullYear(y, m - 1, d);
  return dt.getUTCFullYear() === y && dt.getUTCMonth() === m - 1 && dt.getUTCDate() === d;
}

function isIsoDate(s) {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s);
  if (!m) return false;
  return isValidYmd(Number(m[1]), Number(m[2]), Number(m[3]));
}

function isDateFormat(x) {
  return typeof x === 'string' && DATE_FORMATS.includes(x);
}

const FORMAT_SPECS = {
  'YYYY-MM-DD': {
    re: /^(\d{4})-(\d{2})-(\d{2})$/,
    toYmd: (m) => [Number(m[1]), Number(m[2]), Number(m[3])],
    render: (y, m, d) => `${pad4(y)}-${pad2(m)}-${pad2(d)}`,
  },
  'YYYY/MM/DD': {
    re: /^(\d{4})\/(\d{2})\/(\d{2})$/,
    toYmd: (m) => [Number(m[1]), Number(m[2]), Number(m[3])],
    render: (y, m, d) => `${pad4(y)}/${pad2(m)}/${pad2(d)}`,
  },
  'DD/MM/YYYY': {
    re: /^(\d{2})\/(\d{2})\/(\d{4})$/,
    toYmd: (m) => [Number(m[3]), Number(m[2]), Number(m[1])],
    render: (y, m, d) => `${pad2(d)}/${pad2(m)}/${pad4(y)}`,
  },
  'MM/DD/YYYY': {
    re: /^(\d{2})\/(\d{2})\/(\d{4})$/,
    toYmd: (m) => [Number(m[3]), Number(m[1]), Number(m[2])],
    render: (y, m, d) => `${pad2(m)}/${pad2(d)}/${pad4(y)}`,
  },
  YYYYMMDD: {
    re: /^(\d{4})(\d{2})(\d{2})$/,
    toYmd: (m) => [Number(m[1]), Number(m[2]), Number(m[3])],
    render: (y, m, d) => `${pad4(y)}${pad2(m)}${pad2(d)}`,
  },
  'DD-MMM-YYYY': {
    re: /^(\d{2})-([A-Za-z]{3})-(\d{4})$/,
    toYmd: (m) => {
      const idx = MONTH_ABBR.findIndex((a) => a.toLowerCase() === m[2].toLowerCase());
      return idx < 0 ? null : [Number(m[3]), idx + 1, Number(m[1])];
    },
    render: (y, m, d) => `${pad2(d)}-${MONTH_ABBR[m - 1]}-${pad4(y)}`,
  },
};

function formatDate(iso, format) {
  if (iso === '') return '';
  if (!isIsoDate(iso)) throw new Error(`formatDate: '${iso}' is not a calendar-valid ISO date`);
  const y = Number(iso.slice(0, 4));
  const m = Number(iso.slice(5, 7));
  const d = Number(iso.slice(8, 10));
  return FORMAT_SPECS[format].render(y, m, d);
}

// null = text does not match this format's shape at all. A non-null result
// is this format's definitive verdict (see FE twin for the reasoning).
function tryFormat(fmt, trimmed) {
  const spec = FORMAT_SPECS[fmt];
  const m = spec.re.exec(trimmed);
  if (!m) return null;
  const ymd = spec.toYmd(m);
  if (!ymd) return { ok: false, reason: 'format' };
  const [y, mo, d] = ymd;
  if (!isValidYmd(y, mo, d)) return { ok: false, reason: 'impossible' };
  const iso = `${String(y).padStart(4, '0')}-${pad2(mo)}-${pad2(d)}`;
  return { ok: true, iso, matchedText: spec.render(y, mo, d) };
}

function parseDateInput(text, format) {
  const trimmed = text.trim();
  if (trimmed === '') return { ok: false, reason: 'empty' };

  if (/^\d{5,6}$/.test(trimmed)) return { ok: false, reason: 'serial' };

  let hit = tryFormat(format, trimmed);
  let matchedFormat = format;
  if (hit === null && format !== 'YYYY-MM-DD') {
    const isoHit = tryFormat('YYYY-MM-DD', trimmed);
    if (isoHit !== null) {
      hit = isoHit;
      matchedFormat = 'YYYY-MM-DD';
    }
  }
  if (hit === null) return { ok: false, reason: 'format' };
  if (!hit.ok) return { ok: false, reason: hit.reason };

  const canonicalInput =
    matchedFormat === 'DD-MMM-YYYY'
      ? trimmed.replace(/[A-Za-z]{3}/, (a) => a[0].toUpperCase() + a.slice(1, 3).toLowerCase())
      : trimmed;
  if (hit.matchedText !== canonicalInput) return { ok: false, reason: 'format' };

  return { ok: true, iso: hit.iso };
}

module.exports = {
  DATE_FORMATS,
  DEFAULT_DATE_FORMAT,
  isIsoDate,
  isDateFormat,
  parseDateInput,
  formatDate,
};
