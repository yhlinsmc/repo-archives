/**
 * flow-step-dispatch.js — infra-side handler for POST /api/flow-recipe-steps/:id/dispatch.
 *
 * Delegates to dispatchOneStep (infra/lib/flow-dispatch-step) for the core
 * prepare→socket→result logic. This file owns only HTTP request parsing,
 * auth checking, and HTTP response serialisation.
 *
 * BOUNDARY: imports only from shared/lib + infra/lib — never edge/, no DB.
 * SECURITY: prepared.headers carries the injected auth secret; it is used to
 * build the outbound request and is never logged.
 */
const { passthroughResponse } = require('../lib/remote-client');
const { sendError } = require('../../shared/lib/send-error');
const { dispatchOneStep } = require('../lib/flow-dispatch-step');
const { apiOk, apiError, requireAuth } = require('../../shared/helpers');
const { logger: rootLogger } = require('../../shared/lib/logger');

const logger = rootLogger.child({ module: 'infra-flow-step-dispatch' });

function mountFlowStepDispatch(app) {
  app.post('/api/flow-recipe-steps/:id/dispatch', async (req, res) => {
    if (!requireAuth(req, res)) return;
    // Step-level authorization is enforced by edge /prepare (it loads and
    // validates the step and recipe); this tier only requires an authenticated caller.
    const inputs = (req.body && req.body.inputs) || {};
    const runId = (req.body && req.body.run_id) || null;
    const test = (req.body && req.body.test) === true;
    // Forwarded verbatim like any other body field; edge re-verifies it.
    const compareToken = (req.body && req.body.compare_token) || null;
    try {
      const r = await dispatchOneStep({
        stepId: req.params.id, inputs, runId, test, compareToken,
        user: req.user, reqId: req.id, reqPath: req.originalUrl, req,
      });
      if (r.prep) return passthroughResponse(req, res, r.prep);
      if (r.ok) return res.json(apiOk(r.envelope));
      // `r.request` (already masked/capped by the shared masked re-
      // resolution — this is `data.request` echoed verbatim by
      // `dispatchOneStep`'s own catch branch) is response-visible via
      // `error.details`, the SAME generic pass-through `apiError`/
      // `apiInvoke` already carry for every other error detail payload — so
      // a transport failure and a successful dispatch agree on where the
      // browser-chain producer (`run-chain.ts`) reads the step's request
      // from, instead of a failed step losing it entirely.
      return sendError(req, res, null, {
        status: r.status, code: r.errorCode || 'INTERNAL_ERROR', reason: r.message || 'Step request failed',
        ...(r.request ? { details: { request: r.request } } : {}),
      });
    } catch (err) {
      sendError(req, res, err, { status: 500, code: 'INTERNAL_ERROR', reason: 'Dispatch failed', fields: { stepId: req.params.id } });
    }
  });
}

module.exports = mountFlowStepDispatch;
