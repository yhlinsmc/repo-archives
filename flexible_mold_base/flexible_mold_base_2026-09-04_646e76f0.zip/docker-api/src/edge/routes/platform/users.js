const { TABLES } = require('../../../shared/constants');

const router = require('express').Router();
const bcrypt = require('bcryptjs');
const { pool, t } = require('../../db');
const { apiOk, apiError, requireAdmin, requireAdminOrEditor, uuidv4 } = require('../../../shared/helpers');
const { logger: rootLogger } = require('../../../shared/lib/logger');
const { validatePassword } = require('../../../shared/password-validator');
const { normalizeRows } = require('../../../shared/serializers/normalize-nullable');
const { parsePage } = require('../../../shared/lib/parse-page');
const { stripEmailDomain } = require('../../lib/owner-name-enrichment');
const logger = rootLogger.child({ module: 'users' });

// deptid/kc_username are optional identity fields (LOCAL accounts and
// non-Keycloak deployments leave them NULL) — Y-pattern normalizes both
// SELECT sites the same way so the frontend never has to distinguish
// "empty" from "unset".
const NULLABLE_STRING_FIELDS = ['deptid', 'kc_username'];

// Pagination for the two full-table list reads below (GET / and POST
// action=list). DEFAULT_LIMIT mirrors the platform's other paged
// reads (privileges audit's 50); a request with no params must still get a
// bounded page, never the full table. MAX_LIMIT is enforced by CLAMPING
// rather than rejecting (feature-audit.js / auth-sessions.js / privileges
// router.js all clamp their own over-cap `limit` the same way) — an
// over-large ask still gets a response instead of a 400 the client has no
// obvious way to recover from.
const DEFAULT_LIMIT = 50;
const MAX_LIMIT = 200;
// An admin-triggerable OFFSET this deep is an expensive scan on the shared
// read pool with no legitimate page an admin UI would ever page to by
// clicking Next — rejected with 400 (not clamped, like MAX_LIMIT) since a
// caller asking for offset 500000 almost certainly built the wrong URL/body
// rather than genuinely wanting "the last bounded page" (review).
const MAX_OFFSET = 100000;

/**
 * Validate `limit`/`offset` off a plain object — `req.query` for GET, and
 * `req.body` for the POST action=list branch (the FE sends them alongside
 * `action`, the same way every other action= param arrives). Absent params
 * fall back to the default page; a malformed value is refused with a
 * message rather than silently coerced, so a caller sees why the page it
 * asked for was not the page it got. Thin wrapper over the shared
 * `parsePage` in 'reject' mode — see parse-page.js for the shared algorithm.
 * @param {Record<string, unknown>} src
 * @returns {{ limit: number, offset: number, error?: undefined } | { error: string }}
 */
function parseUsersPage(src) {
  return parsePage(src, { defaultLimit: DEFAULT_LIMIT, maxLimit: MAX_LIMIT, maxOffset: MAX_OFFSET, mode: 'reject' });
}

/**
 * @openapi
 * /edge/platform/users:
 *   get:
 *     summary: List users (paginated)
 *     tags: [Platform - Users]
 *     parameters:
 *       - { name: limit, in: query, schema: { type: integer, default: 50, maximum: 200 } }
 *       - { name: offset, in: query, schema: { type: integer, default: 0 } }
 *     responses:
 *       200:
 *         description: "{ rows, total, limit, offset }"
 *         content: { application/json: { schema: { $ref: '#/components/schemas/ApiResponse' } } }
 *       400: { description: Malformed limit/offset }
 *       401: { description: Unauthorized }
 *       403: { description: Admin required }
 *   post:
 *     summary: Create user or dispatch action (list, ban, unban, updateRole, delete, resetPassword). action=list accepts limit/offset in the body and returns { rows, total, limit, offset }.
 *     tags: [Platform - Users]
 *     requestBody:
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               action: { type: string, enum: [list, ban, unban, updateRole, delete, resetPassword, create] }
 *               email: { type: string }
 *               password: { type: string }
 *               display_name: { type: string }
 *               userId: { type: string }
 *               role: { type: string, enum: [admin, user] }
 *     responses:
 *       200: { description: Action completed }
 *       400: { description: Validation error }
 *       401: { description: Unauthorized }
 *       403: { description: Admin required }
 */
router.get('/', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  // Parsed before a connection is taken: a malformed page is a client error
  // and must not cost a pool slot.
  const page = parseUsersPage(req.query);
  if (page.error) {
    const e = apiError(page.error, 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }
  try {
    // NOTE: Idempotent read → pool.ro. Falls back to the writer when no
    // separate read endpoint is configured, so the code path is identical
    // for local dev and for the full RW/RO deployment.
    const conn = await pool.ro.getConnection();
    try {
      // ORDER BY created_at DESC, id DESC — `created_at` alone is not a total
      // order (TIMESTAMP is second-resolution; two rows created the same
      // second tie), so a tie can land on either side of a LIMIT/OFFSET page
      // boundary depending on unspecified tie-break order, duplicating or
      // skipping a row between two page requests. `id` is unique, so adding
      // it as a secondary key makes the order total and pages stable (Codex r1).
      const rows = await conn.query(
        `SELECT id, display_name, email, created_at, role, banned, deptid, kc_username FROM \`${t(TABLES.USERS)}\` ORDER BY created_at DESC, id DESC LIMIT ? OFFSET ?`,
        [page.limit, page.offset]
      );
      const totalRows = await conn.query(`SELECT COUNT(*) AS cnt FROM \`${t(TABLES.USERS)}\``);
      res.json(apiOk({
        rows: normalizeRows(rows, NULLABLE_STRING_FIELDS),
        total: Number(totalRows[0].cnt) || 0,
        limit: page.limit,
        offset: page.offset,
      }));
    } finally {
      conn.release();
    }
  } catch (err) {
    logger.error({ err }, 'Failed to list users');
    const e = apiError('Database operation failed', 'INTERNAL_ERROR');
    res.status(e.status).json(e.body);
  }
});

// GET /assignable — bounded directory for owner self-reassign pickers.
// Admin+editor only; returns id + display_name + role + kc_username, never
// email (PII/compliance), active (non-banned) users. kc_username is a
// username, not the email, and is domain-stripped the same way the
// delegation person picker strips it (spec §8.2 D-4), so the never-return-
// email rule holds for this route too. Feeds the transfer-owner picker so a
// non-admin owner can choose a transferee; grants no transfer power itself
// (the reassign routes re-validate caller + target).
router.get('/assignable', async (req, res) => {
  if (!requireAdminOrEditor(req, res)) return;
  try {
    const conn = await pool.ro.getConnection();
    try {
      const rows = await conn.query(
        `SELECT id, display_name, role, kc_username FROM \`${t(TABLES.USERS)}\`
         WHERE banned = 0 ORDER BY display_name IS NULL, display_name`
      );
      // Explicit map rather than passing rows straight to apiOk: display_name
      // is free text (a LOCAL account can be seeded with an address, same as
      // kc_username), so it gets the identical never-return-email guarantee
      // /people already applies to its own display_name — this route used to
      // strip kc_username only and let display_name reach the wire raw.
      res.json(apiOk(rows.map((r) => ({
        id: r.id,
        display_name: stripEmailDomain(r.display_name || '') || '',
        role: r.role,
        kc_username: stripEmailDomain(r.kc_username || '') || '',
      }))));
    } finally {
      conn.release();
    }
  } catch (err) {
    logger.error({ err }, 'Failed to list assignable users');
    const e = apiError('Database operation failed', 'INTERNAL_ERROR');
    res.status(e.status).json(e.body);
  }
});

// GET /impersonation-targets — the admin-only "View as" picker.
// Split off from GET / rather than pointed at pagination: it is not the
// full-table read GET / used to be (banned=0 narrows it, the same way
// /assignable is already narrowed) and adding a hard cap here would
// silently drop targets from a picker with no page control to reach them.
// Cannot reuse /assignable itself — that route is editor-callable and
// deliberately withholds email (PII), while this one carries email because
// AuthContext swaps it into the effective identity while impersonating
// (UserManagement's own admin-only list already exposes every user's
// email, so this is not new exposure, only a differently-shaped read of it).
router.get('/impersonation-targets', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  try {
    const conn = await pool.ro.getConnection();
    try {
      const rows = await conn.query(
        `SELECT id, display_name, email, role FROM \`${t(TABLES.USERS)}\`
         WHERE banned = 0 ORDER BY display_name IS NULL, display_name`
      );
      res.json(apiOk(rows));
    } finally {
      conn.release();
    }
  } catch (err) {
    logger.error({ err }, 'Failed to list impersonation targets');
    const e = apiError('Database operation failed', 'INTERNAL_ERROR');
    res.status(e.status).json(e.body);
  }
});

// POST /edge/platform/users — action dispatch
router.post('/', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  const { action } = req.body || {};

  if (action === 'list') {
    // Parsed before a connection is taken: a malformed page is a client error
    // and must not cost a pool slot.
    const page = parseUsersPage(req.body);
    if (page.error) {
      const e = apiError(page.error, 'BAD_REQUEST', 400);
      return res.status(e.status).json(e.body);
    }
    try {
      // NOTE: POST-with-action=list is the same idempotent read as GET /;
      // route to pool.ro.
      const conn = await pool.ro.getConnection();
      try {
        // ORDER BY created_at DESC, id DESC — see the matching comment on
        // GET / above; same tie-breaker, same reason (Codex r1).
        const rows = await conn.query(
          `SELECT id, display_name, email, created_at, role, banned, deptid, kc_username FROM \`${t(TABLES.USERS)}\` ORDER BY created_at DESC, id DESC LIMIT ? OFFSET ?`,
          [page.limit, page.offset]
        );
        const totalRows = await conn.query(`SELECT COUNT(*) AS cnt FROM \`${t(TABLES.USERS)}\``);
        res.json(apiOk({
          rows: normalizeRows(rows, NULLABLE_STRING_FIELDS),
          total: Number(totalRows[0].cnt) || 0,
          limit: page.limit,
          offset: page.offset,
        }));
      } finally { conn.release(); }
    } catch (err) {
      logger.error({ err }, 'Failed to list users');
      const e = apiError('Database operation failed', 'INTERNAL_ERROR');
      res.status(e.status).json(e.body);
    }
    return;
  }

  if (action === 'ban' || action === 'unban') {
    const { userId } = req.body;
    if (!userId) { const e = apiError('userId required', 'BAD_REQUEST', 400); return res.status(e.status).json(e.body); }
    try {
      const conn = await pool.rw.getConnection();
      try {
        await conn.query(`UPDATE \`${t(TABLES.USERS)}\` SET banned = ? WHERE id = ?`, [action === 'ban', userId]);
        res.json(apiOk(null));
      } finally { conn.release(); }
    } catch (err) {
      logger.error({ err, userId, action }, 'Failed to update user ban state userId=' + userId + ' action=' + action);
      const e = apiError('Database operation failed', 'INTERNAL_ERROR');
      res.status(e.status).json(e.body);
    }
    return;
  }

  if (action === 'updateRole') {
    const { userId, role } = req.body;
    if (!userId || !role || !['admin', 'editor', 'user'].includes(role)) {
      const e = apiError('userId and valid role required', 'BAD_REQUEST', 400);
      return res.status(e.status).json(e.body);
    }
    try {
      const conn = await pool.rw.getConnection();
      try {
        await conn.query(`UPDATE \`${t(TABLES.USERS)}\` SET role = ? WHERE id = ?`, [role, userId]);
        res.json(apiOk(null));
      } finally { conn.release(); }
    } catch (err) {
      logger.error({ err, userId, role }, 'Failed to update user role userId=' + userId + ' role=' + role);
      const e = apiError('Database operation failed', 'INTERNAL_ERROR');
      res.status(e.status).json(e.body);
    }
    return;
  }

  if (action === 'delete') {
    const { userId } = req.body;
    if (!userId) { const e = apiError('userId required', 'BAD_REQUEST', 400); return res.status(e.status).json(e.body); }
    try {
      const conn = await pool.rw.getConnection();
      try {
        await conn.query(`DELETE FROM \`${t(TABLES.USERS)}\` WHERE id = ?`, [userId]);
        res.json(apiOk(null));
      } finally { conn.release(); }
    } catch (err) {
      logger.error({ err, userId }, 'Failed to delete user userId=' + userId);
      const e = apiError('Database operation failed', 'INTERNAL_ERROR');
      res.status(e.status).json(e.body);
    }
    return;
  }

  if (action === 'resetPassword') {
    const { userId: targetId, password: newPw } = req.body;
    if (!targetId) { const e = apiError('userId required', 'BAD_REQUEST', 400); return res.status(e.status).json(e.body); }
    const pwErr = validatePassword(newPw);
    if (pwErr) { const e = apiError(pwErr, 'BAD_REQUEST', 400); return res.status(e.status).json(e.body); }
    try {
      // SELECT + UPDATE + audit INSERT all on the same conn → pool.rw.
      const conn = await pool.rw.getConnection();
      try {
        const userRows = await conn.query(
          `SELECT keycloak_sub, email FROM \`${t(TABLES.USERS)}\` WHERE id = ?`, [targetId]
        );
        if (!userRows.length) { const e = apiError('User not found', 'NOT_FOUND', 404); return res.status(e.status).json(e.body); }
        const targetUser = userRows[0];
        if (targetUser.keycloak_sub) {
          logger.warn({ targetUserId: targetId, adminId: req.user?.id }, 'local password set for Keycloak account');
        }
        const hash = await bcrypt.hash(newPw, 10);
        await conn.query(`UPDATE \`${t(TABLES.USERS)}\` SET password_hash = ? WHERE id = ?`, [hash, targetId]);
        const auditReason = targetUser.keycloak_sub ? 'admin_set_local_password_for_keycloak_account' : 'password_reset';
        try {
          await conn.query(
            `INSERT INTO \`${t(TABLES.LOGIN_AUDIT)}\` (username, auth_provider, reason, success) VALUES (?, 'LOCAL', ?, TRUE)`,
            [targetUser.email, auditReason]
          );
        } catch (auditErr) {
          logger.warn({ err: auditErr }, 'audit log failed for password reset');
        }
        res.json(apiOk({
          message: targetUser.keycloak_sub
            ? `Local password set for ${targetUser.email}. This does NOT change their Keycloak SSO password.`
            : 'Password reset successfully',
        }));
      } finally { conn.release(); }
    } catch (err) {
      logger.error({ err, userId: targetId }, 'Failed to reset user password userId=' + targetId);
      const e = apiError('Database error', 'DB_ERROR');
      res.status(e.status).json(e.body);
    }
    return;
  }

  // Default: action "create"
  const { email, password, display_name } = req.body;
  if (!email || !password) {
    const e = apiError('email and password required', 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }
  const pwError = validatePassword(password);
  if (pwError) {
    const e = apiError(pwError, 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }
  try {
    const id = uuidv4();
    const hash = await bcrypt.hash(password, 10);
    const conn = await pool.rw.getConnection();
    try {
      await conn.query(
        `INSERT INTO \`${t(TABLES.USERS)}\` (id, email, password_hash, display_name) VALUES (?, ?, ?, ?)`,
        [id, email, hash, display_name || email.split('@')[0]]
      );
      res.json(apiOk({ id, email }));
    } finally {
      conn.release();
    }
  } catch (err) {
    // Email lives in the structured binding (redactable via pino redact.paths
    // at a future framework-boundary PR) but is NOT concatenated into the
    // pino `msg` string because pino redact covers structured fields only.
    logger.error({ err, email }, 'Failed to create user');
    const e = apiError('Database operation failed', 'INTERNAL_ERROR');
    res.status(e.status).json(e.body);
  }
});

// POST /edge/platform/users/:id/ban
router.post('/:id/ban', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  try {
    const conn = await pool.rw.getConnection();
    try {
      await conn.query(`UPDATE \`${t(TABLES.USERS)}\` SET banned = ? WHERE id = ?`, [!!req.body.banned, req.params.id]);
      res.json(apiOk(null));
    } finally {
      conn.release();
    }
  } catch (err) {
    logger.error({ err, userId: req.params.id }, 'Failed to update user ban state userId=' + req.params.id);
    const e = apiError('Database operation failed', 'INTERNAL_ERROR');
    res.status(e.status).json(e.body);
  }
});

// PUT /edge/platform/users/:id/role
router.put('/:id/role', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  const { role } = req.body;
  if (!role || !['admin', 'editor', 'user'].includes(role)) {
    const e = apiError('role must be "admin", "editor", or "user"', 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }
  try {
    const conn = await pool.rw.getConnection();
    try {
      await conn.query(`UPDATE \`${t(TABLES.USERS)}\` SET role = ? WHERE id = ?`, [role, req.params.id]);
      res.json(apiOk(null));
    } finally {
      conn.release();
    }
  } catch (err) {
    logger.error({ err, userId: req.params.id, role }, 'Failed to update user role userId=' + req.params.id + ' role=' + role);
    const e = apiError('Database operation failed', 'INTERNAL_ERROR');
    res.status(e.status).json(e.body);
  }
});

// PUT /edge/platform/users/:id/reset-password
router.put('/:id/reset-password', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  const { password } = req.body;
  if (!password) {
    const e = apiError('password is required', 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }
  const pwError = validatePassword(password);
  if (pwError) {
    const e = apiError(pwError, 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }
  try {
    // SELECT + UPDATE + audit INSERT all on same conn → pool.rw.
    const conn = await pool.rw.getConnection();
    try {
      const userRows = await conn.query(
        `SELECT keycloak_sub, password_hash, email FROM \`${t(TABLES.USERS)}\` WHERE id = ?`,
        [req.params.id]
      );
      if (!userRows.length) {
        const e = apiError('User not found', 'NOT_FOUND', 404);
        return res.status(e.status).json(e.body);
      }
      const targetUser = userRows[0];
      const isKeycloakAccount = !!targetUser.keycloak_sub;

      if (isKeycloakAccount) {
        logger.warn(
          { targetUserId: req.params.id, adminId: req.user?.id },
          'local password set for Keycloak account'
        );
      }

      const hash = await bcrypt.hash(password, 10);
      await conn.query(
        `UPDATE \`${t(TABLES.USERS)}\` SET password_hash = ? WHERE id = ?`,
        [hash, req.params.id]
      );
      const auditReason = isKeycloakAccount
        ? 'admin_set_local_password_for_keycloak_account'
        : 'password_reset';
      try {
        await conn.query(
          `INSERT INTO \`${t(TABLES.LOGIN_AUDIT)}\` (username, auth_provider, reason, success)
           VALUES (?, 'LOCAL', ?, TRUE)`,
          [targetUser.email, auditReason]
        );
      } catch (auditErr) {
        logger.warn({ err: auditErr }, 'audit log failed for password reset');
      }
      res.json(apiOk({
        message: isKeycloakAccount
          ? `Local password set for ${targetUser.email}. This does NOT change their Keycloak SSO password.`
          : 'Password reset successfully',
      }));
    } finally {
      conn.release();
    }
  } catch (err) {
    logger.error({ err, userId: req.params.id }, 'Failed to reset user password userId=' + req.params.id);
    const e = apiError('Database error', 'DB_ERROR');
    res.status(e.status).json(e.body);
  }
});

module.exports = router;
module.exports.validatePassword = validatePassword;
