/**
 * connectors.js — edge-side connector dispatch brain (S2S-only).
 *
 * /prepare is the SOLE dispatch entry point. It loads + decrypts the connector,
 * resolves the request (template fill + auth header), checks the breaker, writes
 * a PENDING audit, then routes by dispatch_origin:
 *   edge  → execute inline (runEdgeExecute) → { mode:'edge', envelope }
 *   infra → SSRF resolve-and-pin → { mode:'infra', dispatch_id, prepared }
 *
 * SECURITY: prepared.headers carries the assembled auth header (the decrypted
 * secret). It is returned over the S2S channel only; it MUST never be logged or
 * placed in an audit row. The pending/closing audit rows carry id/host/method/
 * status only.
 */
const router = require('express').Router();
const { pool, t } = require('../../db');
const { apiOk, apiError, uuidv4 } = require('../../../shared/helpers');
const { TABLES } = require('../../../shared/constants');
const { mapRowsFromDb } = require('../../lib/dto-mapper');
const { logger: rootLogger } = require('../../../shared/lib/logger');
const { decryptRow } = require('../app/api-connectors/serializer');
const { DecryptError } = require('../../../shared/lib/decrypt-error');
const { resolveRequest, runEdgeExecute, breaker, resolveAndPin, DEFAULT_TIMEOUT_MS, DEFAULT_MAX_BYTES } = require('../../lib/connector-dispatch');
const { resolveTemplateSource, buildStaticEnvelope } = require('../../lib/template-source');
const { egressAllowedForUrl } = require('../../../shared/lib/egress-policy');
const { callerCanManageConnector } = require('../../lib/connector-manage-authority');
// What a NULL status means is one module's answer, read by every gate on this
// column — see review-status.js. Here it means grandfathered: a row that
// predates review, or a database whose operator cannot add the column, keeps
// dispatching.
const { dispatchAllowed } = require('../../lib/review-status');

const logger = rootLogger.child({ module: 'edge-connectors-internal' });

const EVENT = { pending: 'connector.fetch.pending', success: 'connector.fetch.success', failed: 'connector.fetch.failed' };
const EVENT_TEST = { pending: 'connector.test.pending', success: 'connector.test.success', failed: 'connector.test.failed' };
const ERROR_STATUS = { SSRF_BLOCKED: 422, CONNECTOR_TIMEOUT: 504, CONNECTOR_RESPONSE_TOO_LARGE: 502, CONNECTOR_UNREACHABLE: 502, BAD_CONNECTOR_URL: 422 };

function hostOf(url) { try { return new URL(url).host; } catch { return null; } }

async function writeAudit(conn, id, eventType, userId, metadata) {
  try {
    await conn.query(
      `INSERT INTO \`${t(TABLES.FEATURE_AUDIT)}\` (id, event_type, user_id, metadata) VALUES (?, ?, ?, ?)`,
      [id, eventType, userId || null, JSON.stringify(metadata)],
    );
  } catch (e) { logger.warn({ err: e }, 'connector audit write failed eventType=' + eventType); }
}

// Fix C: validate connector_id before touching DB — a missing or non-string id
// is a caller error, not a server error, so 400 is the correct response.
// Fix B: explicit column list — SELECT * was replaced so the query surface is
// locked to the columns dispatch actually consumes and the dto-mapper /
// decryptRow still receive every field they need. The legacy section_key column
// still exists on the table but no code reads it, so it is intentionally left
// out (DBA-drop pending).
const CONNECTOR_COLS = [
  'id', 'name', 'description', 'is_active', 'owner_id', 'blueprint_id',
  'method', 'url', 'auth_type', 'auth_config',
  'request_config', 'response_config', 'dispatch_origin',
  'timeout_ms', 'status', 'source_kind', 'source_config', 'created_at', 'updated_at',
];
const CONNECTOR_SELECT = CONNECTOR_COLS.map((c) => `\`${c}\``).join(', ');
// timeout_ms, status, source_kind and source_config are additive columns; on a
// no-ALTER operator DB their migration may be skipped, so a hard SELECT would
// 500 every dispatch with ER_BAD_FIELD_ERROR. Keep a fallback projection
// dropping all four and degrade to it on that error so dispatch still works:
// a missing timeout_ms → the system default; a missing status → undefined →
// treated as approved (the gate only blocks an EXPLICIT pending/rejected); a
// missing source_kind → undefined; this /prepare route does not yet branch on
// it (that lands with the source-kind dispatch resolution), so every row here
// still dispatches through the existing http-only path unchanged either way.
// The write-path guard (api-connectors/index.js) already coalesces the same
// undefined to 'http' before it validates a save.
//
// SELF-HEAL: the degraded flag is NOT a process-life latch — it re-arms after a
// TTL so an operator who runs the migration on a live pod recovers the columns
// (per-connector timeout, approval gating AND source kind) within one TTL
// window, no restart. On a genuinely no-ALTER DB the periodic retry just
// re-flips off — a cheap primary-key SELECT once per TTL.
const ADDITIVE_COLS = ['timeout_ms', 'status', 'source_kind', 'source_config'];
const CONNECTOR_SELECT_FALLBACK = CONNECTOR_COLS.filter((c) => !ADDITIVE_COLS.includes(c)).map((c) => `\`${c}\``).join(', ');
const ADDITIVE_REPROBE_TTL_MS = 60_000;
let _additiveColsPresent = true;
let _additiveDegradedAt = 0;
let _nowFn = Date.now; // injectable clock for deterministic TTL tests

async function loadConnectorRow(conn, id) {
  const now = _nowFn();
  const tryFull = _additiveColsPresent || (now - _additiveDegradedAt) >= ADDITIVE_REPROBE_TTL_MS;
  const sel = tryFull ? CONNECTOR_SELECT : CONNECTOR_SELECT_FALLBACK;
  try {
    const rows = await conn.query(`SELECT ${sel} FROM \`${t(TABLES.API_CONNECTORS)}\` WHERE id = ?`, [id]);
    if (tryFull && !_additiveColsPresent) _additiveColsPresent = true; // migration applied → healed
    return rows;
  } catch (e) {
    if (tryFull && (e?.code === 'ER_BAD_FIELD_ERROR' || e?.errno === 1054)) {
      _additiveColsPresent = false;
      _additiveDegradedAt = now; // (re)start the re-probe window
      return conn.query(`SELECT ${CONNECTOR_SELECT_FALLBACK} FROM \`${t(TABLES.API_CONNECTORS)}\` WHERE id = ?`, [id]);
    }
    throw e;
  }
}

router.post('/prepare', async (req, res) => {
  const { connector_id: connectorId, inputs = {}, source_template_id: sourceTemplateId } = req.body || {};
  // Fix D: coerce a non-plain-object inputs to {} so resolveRequest always
  // receives a safe map and never an array or primitive.
  const safeInputs = (inputs && typeof inputs === 'object' && !Array.isArray(inputs)) ? inputs : {};

  // Fix C: guard before opening a DB connection.
  if (!connectorId || typeof connectorId !== 'string') {
    const e = apiError('connector_id required', 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }

  let conn;
  try {
    conn = await pool.rw.getConnection();
    const rows = await loadConnectorRow(conn, connectorId);
    if (!rows.length) { const e = apiError('Connector not found', 'NOT_FOUND', 404); return res.status(e.status).json(e.body); }
    // Map without decrypting first so gates run on plain metadata fields
    // (is_active, dispatch_origin, breaker state) before the secret is touched.
    // SECURITY: decryptRow is deferred until just before resolveRequest, which is
    // the sole consumer of the decrypted auth header. An inactive or circuit-open
    // connector must return 409/503, not a decrypt error, even when its secret
    // was encrypted with a different or absent SETTINGS_ENCRYPTION_KEY.
    const connector = mapRowsFromDb('api_connectors', rows)[0];

    // SECURITY: test-authority == CRUD edit-authority CONJUNCTION — see
    // connector-manage-authority.js for the shared rule (admin, or an editor
    // owning both the connector row and its bound blueprint). source-candidates.js
    // applies the SAME rule for its own test-only bypass — one function, both
    // call sites, so the two can never drift on who may test an unapproved
    // connector.
    const canManage = await callerCanManageConnector(conn, t, req.user, connector);
    const effectiveTest = (req.body || {}).test === true && canManage;
    const evt = effectiveTest ? EVENT_TEST : EVENT;

    if (!connector.is_active && !effectiveTest) { const e = apiError('Connector is inactive', 'CONNECTOR_INACTIVE', 409); return res.status(e.status).json(e.body); }
    // SECURITY: only an admin-approved connector may dispatch. status NULL/absent
    // = grandfathered = approved (so pre-existing connectors and no-ALTER DBs are
    // never blocked); an EXPLICIT pending/rejected is blocked. Gated after
    // is_active and before the breaker probe — an unapproved connector should not
    // touch breaker state. effectiveTest bypasses it only for callers with edit
    // authority (admin or connector/blueprint owner), so they can verify before
    // an admin approves. Test-authority equals edit-authority — no wider bypass.
    if (!effectiveTest && !dispatchAllowed(connector.status)) {
      const e = apiError('Connector is awaiting admin approval', 'CONNECTOR_NOT_APPROVED', 422);
      return res.status(e.status).json(e.body);
    }
    if (!effectiveTest && !breaker.canDispatch(connector.id)) { const e = apiError('Connector temporarily unavailable', 'CONNECTOR_CIRCUIT_OPEN', 503); return res.status(e.status).json(e.body); }

    // Source branch (spec §6.3). template/static resolve in-process and return
    // the existing edge envelope; neither consults egress or SSRF (no network
    // call), but both have already passed the approval + breaker gates above. A
    // no-DDL DB drops source_kind from the fallback SELECT (undefined) — the
    // `|| 'http'` below is the same degrade-to-http contract the write-path
    // guard (source-config.js normalizeForSourceKind) already applies.
    const sourceKind = connector.source_kind || 'http';
    // static and template both resolve in-process to the same {envelope} |
    // {error} union (T15-R3b) — one result, one error check, one response,
    // so an over-cap static body (defense-in-depth only; write-time
    // validation already bounds it far below DEFAULT_MAX_BYTES) surfaces as
    // the same HTTP 502 CONNECTOR_RESPONSE_TOO_LARGE the template path uses,
    // never a raw envelope carrying a 502 inside its own body.
    if (sourceKind === 'static' || sourceKind === 'template') {
      let result;
      if (sourceKind === 'static') {
        const started = Date.now();
        result = buildStaticEnvelope(connector, Date.now() - started);
      } else {
        try {
          result = await resolveTemplateSource(conn, t, connector, safeInputs, typeof sourceTemplateId === 'string' ? sourceTemplateId : undefined);
        } catch (re) {
          if (re.code === 'MISSING_INPUT') { const e = apiError(`Missing input(s): ${re.missing.join(', ')}`, 'MISSING_INPUT', 400); return res.status(e.status).json(e.body); }
          throw re;
        }
      }
      if (result.error) {
        await writeAudit(conn, uuidv4(), evt.failed, req.user?.id, { connector_id: connector.id, source_kind: sourceKind, error_code: result.error.code });
        const message = sourceKind === 'template' ? 'Template source selection failed' : 'Static source response too large';
        const e = apiError(message, result.error.code, result.error.status);
        return res.status(e.status).json(e.body);
      }
      await writeAudit(conn, uuidv4(), evt.success, req.user?.id, { connector_id: connector.id, source_kind: sourceKind, upstream_status: result.envelope.upstream_status });
      return res.json(apiOk({ mode: 'edge', envelope: result.envelope, test: effectiveTest }));
    }
    // sourceKind === 'http' → existing decrypt/resolve/egress/dispatch path below.

    // Fix A: reject unknown dispatch_origin values before writing a pending
    // audit row — a corrupt enum must never produce a prepared-headers response
    // or leave a phantom pending row in the audit log.
    if (connector.dispatch_origin !== 'edge' && connector.dispatch_origin !== 'infra') {
      const e = apiError('Unsupported dispatch origin', 'NOT_IMPLEMENTED', 501);
      return res.status(e.status).json(e.body);
    }

    // Decrypt only now — gates above have already accepted this connector.
    // A config-level failure (wrong/absent key) returns 422; retrying won't help.
    let decrypted;
    try {
      decrypted = decryptRow(connector);
    } catch (de) {
      if (de instanceof DecryptError) {
        const e = apiError(de.message, de.code, 422);
        return res.status(e.status).json(e.body);
      }
      throw de;
    }

    let resolved;
    try { resolved = resolveRequest(decrypted, safeInputs); }
    catch (re) {
      if (re.code === 'MISSING_INPUT') { const e = apiError(`Missing input(s): ${re.missing.join(', ')}`, 'MISSING_INPUT', 400); return res.status(e.status).json(e.body); }
      throw re;
    }

    const host = hostOf(resolved.url);

    // SECURITY: global egress allow-list (host + method + path). /prepare is the
    // SOLE dispatch entry for BOTH edge- and infra-origin connectors, so enforcing
    // here gates every outbound call before any fetch (and before resolveAndPin
    // hands a request to infra). Empty list = allow-all (opt-in). A blocked request
    // writes a failed audit and 422s, mirroring the SSRF block — no pending row is
    // left behind. The path is normalized (traversal-hardened) before matching; a
    // corrupt list THROWS → outer catch → fail-closed 500, never allow-all.
    const egress = await egressAllowedForUrl(resolved.url, resolved.method, (sql, params) => conn.query(sql, params), t, { applyDefaultDeny: true });
    if (!egress.ok) {
      await writeAudit(conn, uuidv4(), evt.failed, req.user?.id, { connector_id: connector.id, host, method: resolved.method, error_code: 'EGRESS_BLOCKED', reason: egress.reason });
      const e = apiError('Connector request is not on the admin egress allow-list', 'EGRESS_BLOCKED', 422);
      return res.status(e.status).json(e.body);
    }

    const pendingId = uuidv4();
    await writeAudit(conn, pendingId, evt.pending, req.user?.id, { connector_id: connector.id, host, method: resolved.method });

    if (connector.dispatch_origin === 'edge') {
      // Release the rw lease BEFORE the inline outbound call: an edge-origin
      // connector executes here and can run up to its timeout_ms (≤120s), so
      // holding the pooled connection across that network wait would let a few
      // slow connectors exhaust the pool and block unrelated edge DB work. The
      // closing audit re-acquires its own short-lived connection.
      conn.release();
      conn = null;
      // Best-effort, like writeAudit on the held conn was: a failure to lease the
      // short-lived audit connection (e.g. pool saturated) must NOT turn a
      // successful outbound into a dispatch failure / false breaker trip.
      const audit = async (kind, meta) => {
        let ac;
        try { ac = await pool.rw.getConnection(); }
        catch (acqErr) { logger.warn({ err: acqErr, connectorId }, 'edge closing audit: lease failed (best-effort)'); return; }
        try { await writeAudit(ac, uuidv4(), kind === 'success' ? evt.success : evt.failed, req.user?.id, meta); }
        finally { ac.release(); }
      };
      try {
        const out = await runEdgeExecute(connector, resolved, host, audit, { skipBreaker: effectiveTest });
        return res.json(apiOk({ mode: 'edge', envelope: out, test: effectiveTest }));
      } catch (de) {
        const status = ERROR_STATUS[de.code] || 502;
        const e = apiError('Connector request failed', de.code || 'CONNECTOR_ERROR', status);
        return res.status(e.status).json(e.body);
      }
    }

    // infra-origin: resolve+pin here, hand the assembled request to infra.
    let pin;
    try { pin = await resolveAndPin(new URL(resolved.url).hostname); }
    catch (pe) {
      if (!effectiveTest) breaker.recordFailure(connector.id);
      await writeAudit(conn, uuidv4(), evt.failed, req.user?.id, { connector_id: connector.id, host, method: resolved.method, error_code: 'SSRF_BLOCKED' });
      const e = apiError('Connector request failed', 'SSRF_BLOCKED', 422);
      return res.status(e.status).json(e.body);
    }
    return res.json(apiOk({
      mode: 'infra',
      test: effectiveTest,
      dispatch_id: pendingId,
      prepared: {
        method: resolved.method, url: resolved.url, headers: resolved.headers, body: resolved.body,
        pinned_ip: pin.address, family: pin.family,
        timeout_ms: connector.timeout_ms || DEFAULT_TIMEOUT_MS, max_bytes: DEFAULT_MAX_BYTES,
        // allowed_hosts is never sent: the per-connector allowlist was dropped
        // (T8). An older infra reading the absent key treats it as
        // allow-all, which matches the enforced policy (global egress governs).
      },
    }));
  } catch (err) {
    logger.error({ err, connectorId }, 'connector prepare failed id=' + connectorId);
    const e = apiError('Dispatch failed', 'INTERNAL_ERROR', 500);
    res.status(e.status).json(e.body);
  } finally {
    if (conn) conn.release();
  }
});

// Idempotency: best-effort in-memory set of settled dispatch ids (admin-rate;
// a bounded cap keeps it from growing unbounded across a long-lived process).
const _settled = new Set();
const _SETTLED_CAP = 5000;

// connector_id is trusted here without a DB existence check: /result is S2S-only
// (s2sVerify), and the caller supplies the same id it received from /prepare,
// which already validated existence. Re-reading the row would add latency on the
// hot path for no security gain inside the S2S trust boundary.
router.post('/result', async (req, res) => {
  const { dispatch_id: rawDispatchId, connector_id: connectorId, success, upstream_status: upstreamStatus, duration_ms: durationMs, error_code: errorCode, host, method, test } = req.body || {};
  const isTest = test === true;
  const evt = isTest ? EVENT_TEST : EVENT;
  if (!connectorId || typeof connectorId !== 'string') { const e = apiError('connector_id required', 'BAD_REQUEST', 400); return res.status(e.status).json(e.body); }
  // Only a string id participates in idempotency; a non-string is ignored so a
  // malformed id can never poison the settled-set key space.
  const dispatchId = typeof rawDispatchId === 'string' ? rawDispatchId : null;
  if (dispatchId && _settled.has(dispatchId)) return res.json(apiOk({ recorded: false, reason: 'duplicate' }));
  let conn;
  try {
    conn = await pool.rw.getConnection();
    if (success) {
      if (!isTest) breaker.recordSuccess(connectorId);
      await writeAudit(conn, uuidv4(), evt.success, req.user?.id, { connector_id: connectorId, host: host || null, method: method || null, upstream_status: upstreamStatus ?? null, duration_ms: durationMs ?? null });
    } else {
      if (!isTest) breaker.recordFailure(connectorId);
      await writeAudit(conn, uuidv4(), evt.failed, req.user?.id, { connector_id: connectorId, host: host || null, method: method || null, error_code: errorCode || 'CONNECTOR_ERROR' });
    }
    if (dispatchId) {
      if (_settled.size >= _SETTLED_CAP) _settled.clear();
      _settled.add(dispatchId);
    }
    return res.json(apiOk({ recorded: true }));
  } catch (err) {
    logger.error({ err, connectorId }, 'connector result failed id=' + connectorId);
    const e = apiError('Result record failed', 'INTERNAL_ERROR', 500);
    res.status(e.status).json(e.body);
  } finally {
    if (conn) conn.release();
  }
});

module.exports = router;

// Test-only hooks for the additive-column self-heal latch: deterministic TTL
// control and per-test latch isolation. Production paths never reference these.
module.exports.__resetAdditiveColsLatch = () => { _additiveColsPresent = true; _additiveDegradedAt = 0; _nowFn = Date.now; };
module.exports.__setClock = (fn) => { _nowFn = typeof fn === 'function' ? fn : Date.now; };
module.exports.__additiveReprobeTtlMs = ADDITIVE_REPROBE_TTL_MS;
