/**
 * flow-recipes-run.js — edge-side run lifecycle for plain-user flow dispatch (S2S-only).
 *
 * POST /run-begin
 *   Gates the recipe (approved + active + bound), serializes the rendered payload,
 *   creates a flow_recipe_runs row with status='partial', and returns the ordered
 *   step list (ids + sequence only) together with the serialized payload for the
 *   infra orchestrator to dispatch.
 *
 * SECURITY: actor_id is always stamped server-side from req.user.id — it is never
 * read from the request body. This preserves the v3.2.360 invariant for every role
 * including admin (admin write-scope in the CRUD route would otherwise skip the stamp).
 *
 * No owner check on the recipe itself: the admin egress allow-list is the security
 * boundary for which recipes callers may run. Any authenticated caller (including role
 * 'user') may run an approved, active, bound recipe.
 *
 * THE TEMPLATE IS THE GUARDED SUBJECT, and this route is one of the two places
 * that guards it. A non-administrator must either own the template
 * (owner_id = req.user.id) or hold delegated access reaching it — a grant on the
 * template itself, a grant on the blueprint it belongs to, or ownership of that
 * blueprint (`edge/lib/delegated-grants.js`). Shared (owner_id IS NULL)
 * templates are still NOT dispatchable by non-admins, and no arm of delegated
 * access changes that: nobody can delegate a record nobody owns, and the
 * run-finalize cache write-back would otherwise let a delegated caller overwrite
 * a shared template's flow cache columns (IDOR). Admins bypass the check
 * entirely.
 *
 * THE QUESTION IS ASKED TWICE HERE, AND ONLY THE SECOND ONE DECIDES. The first
 * is an early refusal on a row this route has to read anyway; the second is
 * ANDed into the statement that creates the run, so the permission and the
 * write cannot be separated by anything. Both are in run-begin below, next to
 * the statements they belong to.
 *
 * Reading a run is not guarded at all — that rule, and what it exposes, is in
 * `app/flow-recipe-runs/visibility.js`. Dispatching is the guarded action.
 */
const router = require('express').Router();
const { pool, t } = require('../../db');
const { apiOk, apiError, uuidv4 } = require('../../../shared/helpers');
const { TABLES } = require('../../../shared/constants');
const { mapRowsFromDb } = require('../../lib/dto-mapper');
const { serializeWrite, maskDeep } = require('../app/flow-recipe-runs/serializer');
const { insertRunRow } = require('../../lib/flow-run-insert');
const {
  notCapturedDocument,
  snapshotDroppedNotice,
  snapshotIdentityDroppedNotice,
  INVALID_IDENTITY_CODE,
} = require('../../lib/flow-run-input-snapshot');
const { extractFlowResult } = require('../../../shared/lib/flow-extract');
const { serializeFlowPayload } = require('../../../shared/lib/flow-payload-serialize');
const { writeFlowAudit } = require('../../lib/flow-dispatch');
const {
  callerHasTemplateAccess, buildTemplateAccessExists, grantsTableAvailable,
} = require('../../lib/delegated-grants');
const {
  recordTemplateActivity, ACTIVITY_ACTIONS,
} = require('../../lib/template-activity');
const { logger: rootLogger } = require('../../../shared/lib/logger');
const { reviewRecorded } = require('../../lib/review-status');

const logger = rootLogger.child({ module: 'edge-flow-recipes-run-internal' });

// A recipe is browser-orchestrated when any step carries JS or is a compute step.
const hasCode = (v) => typeof v === 'string' && v.trim() !== '';

// Run a query that references the additive chaining columns; on a supported
// operator-mode DB where the ALTER was skipped (ER_BAD_FIELD_ERROR / errno 1054)
// fall back to the legacy column set so a JS-free recipe keeps running — only
// chaining is unavailable, never the whole feature (v3.2.300_303 LESSON).
async function selectWithLegacyFallback(conn, fullSql, legacySql, params) {
  try {
    return await conn.query(fullSql, params);
  } catch (err) {
    if (err && (err.errno === 1054 || err.code === 'ER_BAD_FIELD_ERROR')) {
      return conn.query(legacySql, params);
    }
    throw err;
  }
}

// external_flow_id (flow_recipe_runs) and the user_templates cache mirror are
// VARCHAR(255); a longer value — whether server-extracted from the response body
// or supplied via a step emit override — would error under strict-mode and wedge
// the run permanently in 'partial'. Reject at the boundary instead.
const MAX_EXTERNAL_ID_LEN = 255;
// result_link (flow_recipe_runs) and its user_templates.flow_link mirror are TEXT
// (65,535 BYTES). Cap the char length well under that so a multibyte value can never
// exceed the byte limit and trip the same strict-mode wedge as the external_id path.
// 8192 chars is generous for any real result URL yet safe even at 4 bytes/char.
const MAX_LINK_LEN = 8192;

router.post('/run-begin', async (req, res) => {
  const { recipe_id: recipeId, payload, output_snapshot: outputSnapshot, input_snapshot: inputSnapshot, template_id: templateId, mode: rawMode, client_orchestration: clientOrchestration } = req.body || {};
  // P2: default mode to 'create' when omitted — prevents null into NOT-NULL ENUM col.
  const rawModeNorm = (rawMode === 'update') ? 'update' : 'create';

  if (!recipeId || typeof recipeId !== 'string') {
    const e = apiError('recipe_id required', 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }

  let conn;
  try {
    conn = await pool.rw.getConnection();

    // Load recipe — select only the columns needed for gating + serialization.
    // runs_on is additive; fall back to the legacy set on a no-ALTER DB (recipe
    // then defaults to runs_on='both', i.e. the guard is inert).
    const rawRows = await selectWithLegacyFallback(
      conn,
      `SELECT id, status, is_active, blueprint_id, content_type, link_extract, external_id_extract, runs_on FROM \`${t(TABLES.FLOW_RECIPES)}\` WHERE id = ?`,
      `SELECT id, status, is_active, blueprint_id, content_type, link_extract, external_id_extract FROM \`${t(TABLES.FLOW_RECIPES)}\` WHERE id = ?`,
      [recipeId],
    );

    if (!rawRows.length) {
      const e = apiError('Recipe not found', 'RECIPE_NOT_FOUND', 404);
      return res.status(e.status).json(e.body);
    }

    // mapRowsFromDb JSON-decodes link_extract / external_id_extract / consumed_output_keys
    // and coerces is_active (TINYINT) → boolean.
    const recipe = mapRowsFromDb('flow_recipes', rawRows)[0];

    // Snapshot the recipe's current code_version onto the run. Additive column,
    // read via the legacy-fallback helper: on a no-ALTER DB where the column is
    // absent the fallback tier omits it → codeVersion stays null (= a legacy/
    // pre-feature run). Kept separate from the gating SELECT above so a DB that
    // has runs_on but not code_version does not lose its runs_on tier.
    const cvRows = await selectWithLegacyFallback(
      conn,
      `SELECT code_version FROM \`${t(TABLES.FLOW_RECIPES)}\` WHERE id = ?`,
      `SELECT id FROM \`${t(TABLES.FLOW_RECIPES)}\` WHERE id = ?`,
      [recipeId],
    );
    const codeVersion = cvRows.length && cvRows[0].code_version != null ? cvRows[0].code_version : null;

    // Gate: recipe must be bound to a blueprint (null = authored but not yet configured).
    if (recipe.blueprint_id == null) {
      const e = apiError('Recipe is not bound to a blueprint', 'RECIPE_UNBOUND', 422);
      return res.status(e.status).json(e.body);
    }

    // Gate: recipe must be active.
    if (!recipe.is_active) {
      const e = apiError('Recipe is inactive', 'RECIPE_INACTIVE', 409);
      return res.status(e.status).json(e.body);
    }

    // Gate: a recorded approval, strictly. BEGINNING a run is not continuing a
    // capability the deployment already had, so the grandfather clause that lets
    // an unreviewed row keep dispatching does not extend to it — the distinction
    // is stated once, in review-status.js.
    if (!reviewRecorded(recipe.status)) {
      const e = apiError('Recipe is awaiting admin approval', 'RECIPE_NOT_APPROVED', 422);
      return res.status(e.status).json(e.body);
    }

    // SECURITY: gate on template ownership before creating the run.
    // A non-admin caller must strictly own the template (owner_id = req.user.id).
    // Shared templates (owner_id IS NULL) are NOT accessible to non-admins here:
    // including IS NULL would allow any authenticated user to write through to the
    // finalize cache write-back path, overwriting shared template rows (IDOR bypass).
    // Admins bypass the ownership check entirely.
    // Effective mode: derive from the record's prior-push signal when a template
    // is supplied. flow_last_run_id is the DURABLE pushed marker — it is stamped on
    // every successful run, whereas flow_external_id can legitimately be null after a
    // successful update that returned 204 / no id, which would otherwise misclassify
    // the next run as 'create'. Without a template the signal is unknowable, so fall
    // back to the caller-supplied hint.
    let priorPushed = false;
    if (templateId) {
      // flow_last_run_id is additive (the flow-cache migration); fall back to
      // owner_id alone on a no-ALTER DB so a template-backed run still works
      // (priorPushed then stays false → mode='create').
      const tmplRows = await selectWithLegacyFallback(
        conn,
        `SELECT owner_id, blueprint_id, flow_last_run_id FROM \`${t(TABLES.USER_TEMPLATES)}\` WHERE id = ?`,
        `SELECT owner_id, blueprint_id FROM \`${t(TABLES.USER_TEMPLATES)}\` WHERE id = ?`,
        [templateId],
      );
      const tmplRow = tmplRows[0];
      // A caller who neither owns the template nor holds delegated access
      // reaching it is refused here, before any run row exists. Delegated
      // access is asked for only when ownership has already failed, so the
      // common path costs no extra statement and an administrator costs none
      // either. A record with no owner is refused inside that call, which is
      // where the rule is stated once for every enforcement point.
      //
      // THIS IS THE EARLY ANSWER, NOT THE DECISION. The row has to be read
      // anyway — the run's mode comes from it — and refusing here costs the
      // caller nothing further and this server no serialization work. What
      // actually decides whether a run exists is the same question asked as
      // part of the INSERT, further down, because everything between here and
      // there is time in which the answer can change.
      const mayDispatch = !!tmplRow && (
        req.user.role === 'admin'
        || (tmplRow.owner_id != null && tmplRow.owner_id === req.user.id)
        || await callerHasTemplateAccess(conn, req.user.id, {
          templateId,
          ownerId: tmplRow.owner_id ?? null,
          blueprintId: tmplRow.blueprint_id ?? null,
        }, req.user.role)
      );
      if (!mayDispatch) {
        const e = apiError('Template not found or not yours', 'TEMPLATE_FORBIDDEN', 403);
        return res.status(e.status).json(e.body);
      }
      priorPushed = tmplRow.flow_last_run_id != null && tmplRow.flow_last_run_id !== '';
    }
    const mode = templateId ? (priorPushed ? 'update' : 'create') : rawModeNorm;

    // runs_on trigger guard: a recipe declaring a single trigger refuses a run whose
    // mode conflicts. 'both' (default) never refuses — grandfathered recipes run
    // unchanged. Applied to the effective mode regardless of how it was derived
    // (template signal or caller hint) so the contract holds for template-less
    // callers too. The prior-push signal is reset via the template reset endpoint.
    const runsOn = recipe.runs_on || 'both';
    if (runsOn !== 'both' && runsOn !== mode) {
      const e = apiError(
        runsOn === 'create'
          ? 'This recipe only runs for records that have not been pushed yet'
          : 'This recipe only runs for records that were already pushed',
        'FLOW_MODE_MISMATCH',
        409,
      );
      return res.status(e.status).json(e.body);
    }

    // Serialize payload — YAML or JSON per the recipe's content_type. Nested
    // JSON-string members are expanded first (deepJsonExpand) so the dispatched
    // bytes carry real nested structure, not escaped `\n` / quoted-JSON scalars,
    // and the read-only preview matches what is sent. Expansion also strips
    // prototype-pollution keys and turns nested secrets-in-strings into real
    // keys that the downstream rendered_payload masking then catches.
    const serializedPayload = serializeFlowPayload(payload, recipe.content_type);

    // Load ordered steps. before_code/after_code/step_type are user-authored JS +
    // a closed enum — non-secret, safe to relay; auth_config (the only secret
    // column) is intentionally never selected here.
    const stepRows = await selectWithLegacyFallback(
      conn,
      `SELECT id, sequence, name, step_type, before_code, after_code FROM \`${t(TABLES.FLOW_RECIPE_STEPS)}\` WHERE recipe_id = ? ORDER BY sequence`,
      `SELECT id, sequence, name FROM \`${t(TABLES.FLOW_RECIPE_STEPS)}\` WHERE recipe_id = ? ORDER BY sequence`,
      [recipeId],
    );
    const steps = stepRows.map((r) => ({
      id: r.id,
      sequence: r.sequence,
      name: r.name || null,
      step_type: r.step_type || 'api',
      before_code: r.before_code || null,
      after_code: r.after_code || null,
    }));

    // A recipe needs the browser to orchestrate when any step carries JS or is a
    // compute step — the JS runs only in the browser sandbox, never server-side.
    const requiresClientOrchestration = steps.some(
      (s) => s.step_type === 'compute' || hasCode(s.before_code) || hasCode(s.after_code),
    );

    // Fail closed: the legacy server-side orchestrator (client_orchestration falsey)
    // cannot run a recipe whose steps have JS — it would dispatch them WITHOUT the
    // before/after transforms, producing a dishonest half-run. Reject before any run
    // row is created (no orphan 'partial' row) and point the caller at the client path.
    if (requiresClientOrchestration && clientOrchestration !== true) {
      const e = apiError('This recipe must be run from the builder (it has per-step code)', 'USE_CLIENT_ORCHESTRATION', 422);
      return res.status(e.status).json(e.body);
    }

    // Build the run insert data, then run it through serializeWrite:
    //   - stamps actor_id = req.user.id (server-authoritative, v3.2.360 invariant)
    //   - deep-masks secret-named keys in rendered_payload, output_snapshot and
    //     input_snapshot, and refuses an oversized input_snapshot
    const runId = uuidv4();
    const rawInsert = {
      id: runId,
      recipe_id: recipeId,
      template_id: templateId || null,
      // SECURITY: stamp blueprint_id from the DB record, not from the request body,
      // so the audit row always reflects the recipe's authoritative binding.
      blueprint_id: recipe.blueprint_id,
      mode,
      status: 'partial',
      output_snapshot: outputSnapshot || null,
      rendered_payload: serializedPayload,
      // What the operator entered. Travels with THIS insert rather than a later
      // update: a run that fails mid-chain never reaches finalize, and it must
      // still carry what was entered.
      //
      // NULL IS RESERVED FOR "NOT SUPPLIED", and nothing else reaches it here.
      // Anything a caller did send goes through serializeWrite even when it is
      // the wrong type or an empty string. The previous guard coerced those to
      // null, so a malformed snapshot got a 200 with no capture and no notice —
      // the write boundary the column is defended by never ran, on the one route
      // where the operator would never learn it did not. This keeps the column's
      // three states distinguishable: NULL never attempted, a not-captured
      // marker attempted and dropped, and a bad shape refused rather than
      // quietly becoming the first.
      //
      // WHICH THE CALLER SEES, and why they are not all the same. A document
      // this server cannot READ is reported (400, below); an oversized document
      // and one whose identity values are not identifier-shaped both degrade to
      // a not-captured row plus a notice. The line is what the failure says
      // about the caller: a long answer or an id this server does not recognise
      // are conditions a legitimate client can be in, and their dispatch is
      // worth more than the capture, whereas a body that is not the declared
      // document at all is not something any client of this server produces, so
      // there is nothing to record and nothing is served by dispatching as if
      // there were. Confidentiality is identical on all three paths: no refused
      // value ever reaches the column.
      input_snapshot: inputSnapshot ?? null,
    };

    // serializeWrite stamps actor_id and masks secrets.
    // ctx.isUpdate=false triggers the actor_id stamp.
    let masked;
    // Set when the run proceeds without its capture, so the operator learns it
    // from the run's own response rather than from silence.
    let snapshotNotice = null;
    try {
      masked = await serializeWrite(rawInsert, { isUpdate: false, req });
    } catch (err) {
      if (err && err.code === 'RUN_INPUT_SNAPSHOT_TOO_LARGE') {
        // THE RUN PROCEEDS; THE CAPTURE IS WHAT GETS DROPPED. flow-run-insert.js
        // states the rule for the missing-column case — losing the capture is
        // degraded, losing the run is not — and it applies no less here:
        // refusing the whole request would block a dispatch that worked before
        // this column existed, in order to protect an audit row that two
        // uncapped columns ride along on anyway. Nothing is truncated and
        // nothing is silent: the row records that a capture was attempted and
        // dropped, and the operator is told in the same response.
        //
        // The direct create route deliberately does NOT degrade this way. The
        // snapshot is the whole request there, so there is no dispatch to save
        // and refusing costs nothing.
        snapshotNotice = snapshotDroppedNotice(err.bytes, err.limit);
        masked = await serializeWrite({ ...rawInsert, input_snapshot: null }, { isUpdate: false, req });
        masked.input_snapshot = notCapturedDocument('too_large', { bytes: err.bytes, limit: err.limit });
      } else if (err && err.code === INVALID_IDENTITY_CODE) {
        // THE CAPTURE IS DROPPED, THE RUN PROCEEDS — same rule as the size case
        // above, for the same reason, and the confidentiality property is
        // untouched either way because the offending value never reaches the
        // column.
        //
        // This branch exists because the refusal below asserts more than it
        // knows. Its premise is that a value that is not identifier-shaped was
        // not produced by this application, and nothing enforces that: CHAR(36)
        // constrains only length, there is no CHECK constraint, and
        // `POST /api/sync-schema` upserts caller-supplied ids unvalidated (see
        // flow-run-input-snapshot.js). If a malformed id ever did land in a
        // blueprint, refusing here would fail EVERY dispatch from it with no
        // operator lever and no retry-without-capture — the exact failure the
        // degrade path two functions away was built to eliminate.
        //
        // The row records the reason and NOT the offending entry name: that name
        // is client text, and putting it on a durable, admin-readable row is the
        // shape of the problem this whole boundary exists to prevent. The
        // operator gets the detail in the response instead.
        snapshotNotice = snapshotIdentityDroppedNotice();
        masked = await serializeWrite({ ...rawInsert, input_snapshot: null }, { isUpdate: false, req });
        masked.input_snapshot = notCapturedDocument('unreadable_identity');
      } else if (err && typeof err.status === 'number' && typeof err.code === 'string') {
        // A shape refusal states its own status + code (the pair the CRUD
        // factory's runSerializeWrite honours) and is surfaced verbatim rather
        // than as the generic 500 the catch-all below would report. It is NOT
        // degraded the way the two cases above are: this is a document the
        // server cannot read at all — not JSON, or not the declared shape — so
        // there is nothing to record and no operator condition to be lenient
        // about. The browser sends either the captured shape or the one
        // permitted not-captured marker, so no UI path in this repository
        // produces one; unlike the identity case, that is a statement about a
        // document's syntax rather than about a value's provenance, and nothing
        // outside this server writes it.
        const e = apiError(err.message, err.code, err.status);
        return res.status(e.status).json(e.body);
      } else {
        throw err;
      }
    }

    // THE DISPATCH PERMISSION, ASKED AS PART OF THE WRITE IT GUARDS.
    //
    // The gate above answered before the payload was serialized and the steps
    // were loaded. Access can be withdrawn in that time — a grant deleted, a
    // record handed to somebody else — and a run row created afterwards would
    // be a dispatch that went out on a permission that no longer existed.
    // Worse, it would be a durable one: run-finalize does not re-ask, by
    // design, because the run row IS the authorisation (the long form is at the
    // write-back). That trust is only honest if the row cannot come into
    // existence after the answer changed.
    //
    // WHY A CONDITIONAL INSERT RATHER THAN A TRANSACTION HOLDING A LOCK. The
    // rule is written once, as a predicate, and every other point that enforces
    // it — the shared update path, reset-flow-link — ANDs that same predicate
    // into its own statement (`edge/lib/delegated-grants.js` states why). A
    // transaction would have to hold locks across the serialization and the
    // step read, and would have to lock the ABSENCE of a grant row across three
    // tables, one of which is optional. A row source costs neither: the
    // statement evaluates the predicate and writes in one, so no commit of
    // ours can be observed between them, and a revocation that lands before it
    // is seen by it. Nothing here is a second spelling of the rule.
    //
    // An administrator is not gated: their permission is not a row another
    // statement can delete, and the predicate would refuse them the unowned
    // records they are the only party allowed to dispatch. A run with no
    // template names nothing to guard — and the write-back that trusts the run
    // row does nothing without one.
    let runGate = null;
    if (templateId && req.user.role !== 'admin') {
      // A plain user dispatching their OWN template still matches on the
      // `owner_id = ?` half of the OR, untouched by callerRole — that arm is
      // outside this predicate entirely. callerRole floors the predicate's
      // OWN arms (grants AND the blueprint-owner arm): a blueprint owned while
      // an editor still names that owner_id after a demotion to plain user,
      // and this is the delegated reach a demoted owner must not keep.
      const access = buildTemplateAccessExists('ut', {
        includeGrants: await grantsTableAvailable(conn),
        callerRole: req.user.role,
      });
      runGate = {
        sql: `FROM \`${t(TABLES.USER_TEMPLATES)}\` ut`
          + ` WHERE ut.\`id\` = ? AND (ut.\`owner_id\` = ? OR ${access.sql})`,
        params: [templateId, req.user.id, ...Array(access.paramCount).fill(req.user.id)],
      };
    }

    const inserted = await insertRunRow(conn, t(TABLES.FLOW_RECIPE_RUNS), {
      id: masked.id,
      recipe_id: masked.recipe_id,
      actor_id: masked.actor_id,
      template_id: masked.template_id,
      blueprint_id: masked.blueprint_id,
      mode: masked.mode,
      status: masked.status,
      output_snapshot: masked.output_snapshot,
      rendered_payload: masked.rendered_payload,
      code_version: codeVersion,
      input_snapshot: masked.input_snapshot,
    }, runGate);

    // Nothing was written, so nothing was authorised: the access the request
    // began with is gone, or the record is. Answered exactly as the gate above
    // answers, because it is the same refusal one statement later — and with no
    // partial run left behind and no payload handed out to be dispatched.
    if (!inserted) {
      const e = apiError('Template not found or not yours', 'TEMPLATE_FORBIDDEN', 403);
      return res.status(e.status).json(e.body);
    }

    // Who dispatched this record, and when. Written after the run row exists so
    // the trail never names a dispatch that did not happen, and never fails one
    // that did — the writer logs a dropped row rather than raising it.
    //
    // A dispatch with no template records nothing HERE, because the trail is
    // per-record and there is no record to attach it to. That is not a gap in
    // coverage: the dispatch trail for those is feature_audit, which is
    // server-written and append-only by design and covers every dispatch
    // whether or not a record was involved.
    if (templateId) {
      await recordTemplateActivity(conn, {
        templateId,
        actorId: req.user && req.user.id,
        action: ACTIVITY_ACTIONS.FLOW_DISPATCHED,
        // Which run, so the trail entry can be followed to what it produced.
        // The payload itself is on the run row; it is not copied here.
        metadata: { run_id: runId, recipe_id: recipeId, mode },
      });
    }

    // Return the run_id, ordered steps, and the UNMASKED serialized payload so the
    // infra orchestrator has the actual values to dispatch. link_extract and
    // external_id_extract are intentionally omitted — finalize re-reads them from
    // the DB so infra never needs to cache or relay them.
    return res.json(apiOk({
      run_id: runId,
      steps,
      serialized_payload: serializedPayload,
      requires_client_orchestration: requiresClientOrchestration,
      mode,
      // Null on the ordinary path. Non-null means the run was created without
      // its capture; the caller relays it so the operator is told once, beside
      // the run's own result.
      input_snapshot_notice: snapshotNotice,
    }));

  } catch (err) {
    logger.error({ err, recipeId }, 'flow-recipes run-begin failed id=' + recipeId);
    const e = apiError('Run begin failed', 'INTERNAL_ERROR', 500);
    return res.status(e.status).json(e.body);
  } finally {
    if (conn) conn.release();
  }
});

/**
 * POST /run-finalize
 *
 * Finalizes a flow_recipe_runs row after the infra orchestrator has received
 * the upstream response. Extracts result_link / external_flow_id from the
 * upstream body using the recipe's stored specs, updates the run row, and
 * performs a best-effort cache write-back to the user_templates table.
 *
 * Body: { run_id, recipe_id, ok, upstream_status, body, error_summary?, step_results?,
 *         link_emitted?, link_emitted_value?, external_id_emitted?, external_id_emitted_value? }
 *
 * SECURITY:
 *   - link_extract / external_id_extract are ALWAYS re-read from the DB by
 *     recipe_id. They must NOT be taken from the request body — infra is a
 *     lower-trust tier and may not be trusted to supply extract specs.
 *   - step_results and error_summary are masked via maskDeep before persisting
 *     so secret-named keys in upstream response data are redacted in the audit row.
 *   - Cache write-back failure (user_templates UPDATE) must NOT fail this call.
 *     The run is already finalized by the time the cache write is attempted.
 *   - Cache UPDATE is scoped to the template THIS RUN names, which run-begin
 *     already gated, plus the standing rule that no write reaches a record
 *     nobody owns (WHERE id=? AND owner_id IS NOT NULL). The actor is not
 *     re-authorised here — the run row is the authorisation, and the actor
 *     binding above is what makes it one. The long form is at the statement.
 */
router.post('/run-finalize', async (req, res) => {
  const {
    run_id: runId,
    recipe_id: recipeId,
    ok,
    upstream_status: upstreamStatus,
    body: upstreamBody,
    error_summary: errorSummary,
    step_results: stepResults,
    // Step-emit signal (v3.2.417): the browser reports whether a step's before/after
    // JS EXPLICITLY produced a link / external_id output, plus the emitted value. The
    // server never trusts a client-resolved path value — it re-extracts from the body
    // itself (see the resolution block below) and only honours the emit as an override.
    link_emitted: linkEmitted,
    link_emitted_value: linkEmittedValue,
    external_id_emitted: externalIdEmitted,
    external_id_emitted_value: externalIdEmittedValue,
  } = req.body || {};

  if (!runId || typeof runId !== 'string') {
    const e = apiError('run_id required', 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }
  if (!recipeId || typeof recipeId !== 'string') {
    const e = apiError('recipe_id required', 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }

  let conn;
  try {
    conn = await pool.rw.getConnection();

    // SECURITY: re-read extract specs from DB — never trust request body for this.
    const recipeRaw = await conn.query(
      `SELECT id, link_extract, external_id_extract FROM \`${t(TABLES.FLOW_RECIPES)}\` WHERE id = ?`,
      [recipeId],
    );
    if (!recipeRaw.length) {
      const e = apiError('Recipe not found', 'RECIPE_NOT_FOUND', 404);
      return res.status(e.status).json(e.body);
    }
    const recipe = mapRowsFromDb('flow_recipes', recipeRaw)[0];

    // Load the run row for template_id + actor_id (cache write-back scoping) and
    // recipe_id (binding check).
    const runRaw = await conn.query(
      `SELECT id, recipe_id, template_id, actor_id FROM \`${t(TABLES.FLOW_RECIPE_RUNS)}\` WHERE id = ?`,
      [runId],
    );
    if (!runRaw.length) {
      const e = apiError('Run not found', 'RUN_NOT_FOUND', 404);
      return res.status(e.status).json(e.body);
    }
    const run = runRaw[0];

    // SECURITY: the run must belong to the supplied recipe. Without this a caller
    // could finalize run A's row using recipe B's extract paths.
    if (run.recipe_id !== recipeId) {
      const e = apiError('Run does not belong to the supplied recipe', 'RUN_RECIPE_MISMATCH', 400);
      return res.status(e.status).json(e.body);
    }

    // SECURITY: only the run's actor (or an admin) may finalize it. run_id is a
    // server-generated UUID returned solely to the run-begin caller, but binding
    // finalize to the actor closes the gap where a leaked id lets another user
    // write the run's result_link / external_flow_id.
    if (req.user.role !== 'admin' && run.actor_id !== req.user.id) {
      const e = apiError('Run does not belong to you', 'RUN_FORBIDDEN', 403);
      return res.status(e.status).json(e.body);
    }

    // Determine whether this recipe is browser-orchestrated: any step carrying JS
    // or a compute step. Re-read from the DB (never trust the request body) so the
    // decision to accept browser-resolved link/externalId is server-authoritative.
    // Tolerant of a no-ALTER DB missing the chaining columns (→ not client).
    const stepCodeRows = await selectWithLegacyFallback(
      conn,
      `SELECT step_type, before_code, after_code FROM \`${t(TABLES.FLOW_RECIPE_STEPS)}\` WHERE recipe_id = ?`,
      `SELECT id FROM \`${t(TABLES.FLOW_RECIPE_STEPS)}\` WHERE recipe_id = ? LIMIT 0`,
      [recipeId],
    );
    const requiresClient = stepCodeRows.some(
      (r) => r.step_type === 'compute' || hasCode(r.before_code) || hasCode(r.after_code),
    );

    // Determine success. A browser-orchestrated run already enforced each step's 2xx
    // client-side and reports the verdict via `ok`; a compute-only chain performs no
    // HTTP at all, so requiring a numeric 2xx here would wrongly fail it. Trust `ok`
    // for client-orchestrated runs; the legacy server-loop path still requires 2xx.
    const is2xx = typeof upstreamStatus === 'number' && upstreamStatus >= 200 && upstreamStatus < 300;
    const isSuccess = ok === true && (requiresClient || is2xx);

    // Extract link / externalId — only on success. The server is authoritative for
    // both the server-loop and browser-orchestrated paths: apply the recipe's stored
    // JSONPath specs to the final response body (the same path the legacy server-loop
    // always used, now unified). This closes a trust-boundary gap — a client-resolved
    // path value is never trusted; the server re-derives it from the body it received.
    //
    // Step-emit override: a step's before/after JS is the ONE thing the server cannot
    // reproduce. When (and only when) a step EXPLICITLY emitted link / external_id
    // (link_emitted / external_id_emitted true — a step produced the key, not merely
    // that the merged ctx carried a same-named key), the emitted value overrides the
    // server extraction, even when the emitted value is null. Applied only for a
    // browser-orchestrated (requiresClient) run; the server-loop never emits.
    let link = null;
    let externalId = null;
    if (isSuccess) {
      const extracted = extractFlowResult(upstreamBody || '', {
        link_extract: recipe.link_extract,
        external_id_extract: recipe.external_id_extract,
      });
      link = extracted.link;
      externalId = extracted.externalId;
      if (requiresClient) {
        if (linkEmitted === true) {
          link = typeof linkEmittedValue === 'string' ? linkEmittedValue : null;
        }
        if (externalIdEmitted === true) {
          externalId = typeof externalIdEmittedValue === 'string' ? externalIdEmittedValue : null;
        }
      }
    }

    // SECURITY: the resolved link/external_id — whether server-extracted from the
    // response body or supplied via a step emit — must fit their DB columns. A longer
    // value errors under strict-mode; because the finalize UPDATE is gated by a
    // terminal-state precondition, that error would wedge the run permanently in
    // 'partial'. Reject at the boundary, before the UPDATE. external_flow_id is
    // VARCHAR(255); result_link is TEXT (guarded by MAX_LINK_LEN, char-capped well
    // under the byte limit).
    if (typeof externalId === 'string' && externalId.length > MAX_EXTERNAL_ID_LEN) {
      const e = apiError('external ID exceeds the 255-character limit', 'PAYLOAD_TOO_LARGE', 400);
      return res.status(e.status).json(e.body);
    }
    if (typeof link === 'string' && link.length > MAX_LINK_LEN) {
      const e = apiError('result link exceeds the ' + MAX_LINK_LEN + '-character limit', 'PAYLOAD_TOO_LARGE', 400);
      return res.status(e.status).json(e.body);
    }

    // Mask step_results via serializeWrite and error_summary via maskDeep before
    // persisting — upstream response data may contain secret-named keys.
    const maskedWritable = await serializeWrite({ step_results: stepResults }, { isUpdate: true });
    // INVARIANT: exactly ONE JSON encode reaches this column. serializeWrite has
    // already PARSED the infra-supplied step_results string into a masked
    // object/array (serializer.js step_results branch), so this stringify is the
    // sole encode. Never wrap an already-encoded string here — that is what
    // produced the legacy double-encoded rows the run viewer now has to tolerate.
    const maskedStepResults = maskedWritable.step_results != null
      ? JSON.stringify(maskedWritable.step_results)
      : null;
    // The FE contract sends error_summary as string|null; an authed run actor
    // could POST an object. Only a string is persisted (masked) — any non-string
    // coalesces to null so the audit column keeps a clean, predictable shape.
    const maskedErrorSummary = typeof errorSummary === 'string' ? maskDeep(errorSummary) : null;

    const status = isSuccess ? 'success' : 'failed';

    // SECURITY/correctness: the finalize UPDATE is scoped with a terminal-state
    // precondition so a replayed call cannot flip an already-finalized run
    // (success→failed) or re-trigger the cache write-back. affectedRows===0 means
    // the run was already finalized (or vanished) → 409, idempotent-safe.
    // P1: finished_at uses SQL NOW() (server clock) — binding a JS ISO string bypasses
    // the DTO mapper's DATETIME normalization and 500s on strict-mode MariaDB.
    let updateResult;
    if (isSuccess) {
      updateResult = await conn.query(
        `UPDATE \`${t(TABLES.FLOW_RECIPE_RUNS)}\` SET status=?, result_link=?, external_flow_id=?, step_results=?, finished_at=NOW() WHERE id=? AND status NOT IN ('success', 'failed')`,
        [status, link, externalId, maskedStepResults, runId],
      );
    } else {
      updateResult = await conn.query(
        `UPDATE \`${t(TABLES.FLOW_RECIPE_RUNS)}\` SET status=?, error_summary=?, step_results=?, finished_at=NOW() WHERE id=? AND status NOT IN ('success', 'failed')`,
        [status, maskedErrorSummary, maskedStepResults, runId],
      );
    }

    if (!updateResult || updateResult.affectedRows === 0) {
      const e = apiError('Run is already finalized', 'RUN_ALREADY_FINALIZED', 409);
      return res.status(e.status).json(e.body);
    }

    // Best-effort cache write-back — a failure here must NOT roll back the run finalization.
    //
    // SECURITY: scoped to the record THIS RUN NAMES, and to nothing else. The
    // authorisation is the run row: it exists only because run-begin asked, for
    // this actor and this template, the one question that decides who may
    // dispatch — ownership, delegated access reaching it, or being an
    // administrator — AS PART OF THE STATEMENT THAT CREATED IT, so there is no
    // moment at which the row could have been written after the answer changed.
    // Finalize adds the two bindings that keep the row from being a bearer
    // token: the run must belong to the supplied recipe, and the caller must be
    // the run's own actor (or an administrator). A caller who never began a run
    // has no run id that names a template, so there is nothing here for them to
    // aim at.
    //
    // WHY THE QUESTION IS NOT ASKED AGAIN HERE, which is the whole point of the
    // shape. Access can be withdrawn while a dispatch is in flight. Re-asking at
    // finalize made a revocation land between the dispatch and the record of it:
    // the run finalized as a success and the write matched zero rows, so the
    // record still read as never pushed and the OWNER's next dispatch was
    // derived as a create — repeating upstream work that cannot be taken back.
    // A revocation must stop the next dispatch, which it does at run-begin; it
    // must not erase the one that already happened. Recording a completed act is
    // not the act, and the only two values this writes are the run's own result.
    //
    // The unowned exclusion stays, and is now the only thing the predicate says.
    // Writing a record nobody owns has always been an administrator's business
    // (`edge/lib/delegated-grants.js` states the rule once for every enforcement
    // point), and it is the only row a run could name that no dispatch check
    // ever approved: run-begin refuses non-admins there, so a null-owner
    // template on a run means an admin ran it, and that case no-ops here exactly
    // as it did before.
    if (isSuccess && run.template_id) {
      try {
        await conn.query(
          `UPDATE \`${t(TABLES.USER_TEMPLATES)}\` SET flow_external_id=?, flow_link=?, flow_last_run_id=? WHERE id=? AND owner_id IS NOT NULL`,
          [externalId, link, runId, run.template_id],
        );
      } catch (cacheErr) {
        // WORKAROUND: cache write-back is best-effort; the run is already finalized.
        logger.warn({ err: cacheErr, runId, templateId: run.template_id },
          'flow-recipes run-finalize cache write-back failed (best-effort, run already finalized)');
      }
    }

    return res.json(apiOk({ runId, status, link, externalId }));

  } catch (err) {
    logger.error({ err, runId, recipeId }, 'flow-recipes run-finalize failed id=' + runId);
    const e = apiError('Run finalize failed', 'INTERNAL_ERROR', 500);
    return res.status(e.status).json(e.body);
  } finally {
    if (conn) conn.release();
  }
});

/**
 * POST /reset-flow-link
 *
 * Clears the prior-push signal on a template (flow_external_id / flow_link /
 * flow_last_run_id) so a record that was already pushed can re-run a create-flow.
 * This is the escape hatch for the runs_on create/update guard.
 *
 * SECURITY: scoped for non-admins to exactly the rows the caller may dispatch —
 * ownership, or delegated access reaching the template — which is the same
 * boundary run-begin applies, and literally the same predicate builder. It has
 * to be: this endpoint clears the marker that decides whether the next dispatch
 * CREATES or UPDATES upstream, so a caller who may dispatch and may not reset
 * would be stuck with whichever of the two the record last did, and a caller who
 * may reset but not dispatch could turn somebody else's next update into a
 * duplicate. Admins may reset any template (mirrors run-begin's admin bypass).
 * A no-match silently clears 0 rows and returns cleared:false rather than
 * leaking whether the id exists.
 *
 * WHY THIS ASKS NOW AND THE FINALIZE WRITE-BACK DOES NOT. This is an act being
 * taken, so the permission for it is the one that holds at the moment it is
 * taken; the write-back is the record of an act already authorised and already
 * dispatched, and re-asking there would let a revocation erase the evidence of
 * something that cannot be un-done. Same rule, different tense.
 *
 * THE THREE COLUMNS ARE NOT REACHABLE ANY OTHER WAY. They are declared immutable
 * on the shared user_templates mount, for every role, so this endpoint — with
 * its audit row — is the only way to clear them. Before that they could be
 * cleared through an ordinary record update, which is the same act with no
 * boundary and no trail.
 */
router.post('/reset-flow-link', async (req, res) => {
  const { template_id: templateId } = req.body || {};
  if (!templateId || typeof templateId !== 'string') {
    const e = apiError('template_id required', 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }

  let conn;
  try {
    conn = await pool.rw.getConnection();
    const isAdmin = req.user.role === 'admin';
    const clear = `UPDATE \`${t(TABLES.USER_TEMPLATES)}\` SET flow_external_id=NULL, flow_link=NULL, flow_last_run_id=NULL`;
    let sql;
    let params;
    if (isAdmin) {
      sql = `${clear} WHERE id=?`;
      params = [templateId];
    } else {
      // Same floor as run-begin's INSERT gate above — a plain user's own reset
      // still matches on `owner_id=?`, outside this predicate; callerRole
      // floors the predicate's own arms (grants and the blueprint-owner arm).
      const access = buildTemplateAccessExists(
        `\`${t(TABLES.USER_TEMPLATES)}\``,
        { includeGrants: await grantsTableAvailable(conn), callerRole: req.user.role },
      );
      sql = `${clear} WHERE id=? AND (owner_id=? OR ${access.sql})`;
      params = [templateId, req.user.id, ...Array(access.paramCount).fill(req.user.id)];
    }
    const result = await conn.query(sql, params);
    const cleared = !!result && result.affectedRows > 0;
    if (cleared) {
      await writeFlowAudit(conn, null, 'flow.template.reset_link', req.user.id, { template_id: templateId });
    }
    return res.json(apiOk({ cleared }));
  } catch (err) {
    logger.error({ err, templateId }, 'flow-recipes reset-flow-link failed id=' + templateId);
    const e = apiError('Reset failed', 'INTERNAL_ERROR', 500);
    return res.status(e.status).json(e.body);
  } finally {
    if (conn) conn.release();
  }
});

module.exports = router;
