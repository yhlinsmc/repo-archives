'use strict';
/**
 * source-candidates.js — GET /:id/source-candidates?q= — templates of a
 * template-source connector's configured blueprint whose name contains q,
 * newest first, capped. Backs the pick-at-fetch disambiguation UI (spec §6.3)
 * with the same shape a 300 "ambiguous match" envelope already returns:
 * { id, name, updated_at } only — never payload/outputs, never url/auth.
 */
const { pool, t } = require('../../../db');
const { apiOk, apiError, requireAuth } = require('../../../../shared/helpers');
const { TABLES } = require('../../../../shared/constants');
const { isMissingTableOrColumn } = require('../schema/helpers');
const { dispatchAllowed } = require('../../../lib/review-status');
const { callerCanManageConnector } = require('../../../lib/connector-manage-authority');
const {
  SOURCE_CANDIDATES_MAX, SOURCE_CANDIDATES_QUERY_MAX_LEN,
} = require('../../../../shared/connector-source-limits');
const { logger: rootLogger } = require('../../../../shared/lib/logger');
const { parseJsonColumn } = require('../../../../shared/serializers/parse-json-column');

const logger = rootLogger.child({ module: 'api-connectors:source-candidates' });

// Escape a LIKE contains-match: %, _ and the escape char itself must all be
// literal before parameterising, else a caller-typed % or _ becomes a
// wildcard instead of a literal character to search for.
function escapeLike(q) {
  return q.replace(/[\\%_]/g, (m) => `\\${m}`);
}

// Bounds the ESCAPED pattern, not the raw q: escapeLike can double a run of
// %, _ or \, so truncating the raw string first would still let the escaped
// form (and the query log line) exceed SOURCE_CANDIDATES_QUERY_MAX_LEN. A cut
// can land between a backslash and the character it escapes — every unit
// escapeLike produces is exactly two characters (\\, \% or \_) — leaving a
// lone trailing backslash that would escape the closing `%` wildcard the
// caller appends and turn it into a literal-match anchor instead. Drop a
// dangling trailing backslash (odd run) so the pattern's ESCAPE sequence
// never has a missing target.
function boundEscapedLike(qRaw) {
  let escaped = escapeLike(qRaw).slice(0, SOURCE_CANDIDATES_QUERY_MAX_LEN);
  let trailingBackslashes = 0;
  for (let i = escaped.length - 1; i >= 0 && escaped[i] === '\\'; i -= 1) trailingBackslashes += 1;
  if (trailingBackslashes % 2 === 1) escaped = escaped.slice(0, -1);
  return escaped;
}

// AUTHORISATION: mirrors the connector gates /prepare (internal/connectors.js)
// applies before it would dispatch this connector — requireAuth, is_active
// and the same approval gate (dispatchAllowed on `status`; spec §6 line 155:
// "same as /prepare"). /prepare has no blueprint-scope check on this surface,
// so neither does this endpoint. A connector either gate excludes must
// 404/422 here exactly as /prepare would refuse it — the caller must not be
// able to tell "inactive" or "unapproved" apart from "does not exist" any
// more than /prepare lets it.
//
// `?test=1` is the SAME bypass /prepare's `test:true` grants, judged by the
// SAME shared rule (connector-manage-authority.js) — an editor testing their
// own pending/rejected OR inactive pick-mode connector must be able to
// search its candidates before an admin approves/reactivates it, exactly as
// they may dispatch it. Without `?test=1` both gates are unchanged.
//
// R6-D3: is_active is SELECTed, not filtered into the WHERE clause — judged
// (like `status`) only after effectiveTest resolves, mirroring /prepare's own
// ordering. A WHERE-clause filter would exclude the row before
// callerCanManageConnector ever ran, so `?test=1` could never reach the
// bypass it names for an inactive connector, unlike the identical pending/
// rejected case just above it.
function register(router) {
  router.get('/:id/source-candidates', async (req, res) => {
    if (!requireAuth(req, res)) return;
    const qRaw = typeof req.query.q === 'string' ? req.query.q : '';
    const wantsTest = req.query.test === '1' || req.query.test === 'true';
    let conn;
    try {
      conn = await pool.ro.getConnection();
      let connRows;
      // probe-exempt: source_kind/source_config/status degrade via
      // isMissingTableOrColumn (schema/helpers.js), the shared
      // ER_BAD_FIELD_ERROR/errno-1054 wrapper the schema routes use — same
      // reactive-fallback mechanism, called through the shared helper rather
      // than re-inlined here. owner_id/blueprint_id are core (non-additive)
      // columns — see internal/connectors.js's CONNECTOR_COLS/ADDITIVE_COLS
      // split — so they need no separate fallback.
      try {
        connRows = await conn.query(
          `SELECT is_active, source_kind, source_config, status, owner_id, blueprint_id
             FROM \`${t(TABLES.API_CONNECTORS)}\` WHERE id = ?`,
          [req.params.id],
        );
      } catch (err) {
        // source_kind/source_config/status are additive columns (no-DDL
        // fallback, same posture as internal/connectors.js's ADDITIVE_COLS):
        // on an operator DB where that ALTER was warn-skipped,
        // every connector reads as source_kind='http' (D-F5 semantics) and
        // status is grandfathered-approved — there is no template source to
        // disambiguate, so this is the same outcome as the non-template 400
        // below, not a 500.
        if (!isMissingTableOrColumn(err)) throw err;
        const e = apiError('Connector is not a template source', 'SOURCE_KIND_NOT_TEMPLATE', 400);
        return res.status(e.status).json(e.body);
      }
      if (!connRows.length) { const e = apiError('Connector not found', 'NOT_FOUND', 404); return res.status(e.status).json(e.body); }
      // Same gate and same error shape /prepare uses (internal/connectors.js):
      // dispatchAllowed(status) — NULL/absent is grandfathered-approved. A
      // caller passing test=1 who can manage this connector (same rule as
      // /prepare's test:true) bypasses the approval gate exactly as /prepare
      // does; without test=1 the gate is unchanged.
      const effectiveTest = wantsTest && await callerCanManageConnector(conn, t, req.user, connRows[0]);
      // R6-D3: is_active is judged AFTER effectiveTest (mirrors /prepare's own
      // ordering — internal/connectors.js) rather than filtered into the WHERE
      // clause: the old `AND is_active = 1` filtered an inactive row out of
      // the result set before effectiveTest could ever run, so `?test=1`
      // could never reach the row it was meant to bypass the gate for. Same
      // 404 NOT_FOUND (never a 409) — the caller must still not be able to
      // tell "inactive" apart from "does not exist" without test authority.
      const isActiveRow = connRows[0].is_active === 1 || connRows[0].is_active === true;
      if (!isActiveRow && !effectiveTest) {
        const e = apiError('Connector not found', 'NOT_FOUND', 404);
        return res.status(e.status).json(e.body);
      }
      if (!effectiveTest && !dispatchAllowed(connRows[0].status)) {
        const e = apiError('Connector is awaiting admin approval', 'CONNECTOR_NOT_APPROVED', 422);
        return res.status(e.status).json(e.body);
      }
      if (connRows[0].source_kind !== 'template') {
        const e = apiError('Connector is not a template source', 'SOURCE_KIND_NOT_TEMPLATE', 400);
        return res.status(e.status).json(e.body);
      }
      const cfg = parseJsonColumn(connRows[0].source_config);
      if (!cfg || !cfg.blueprint_id) {
        return res.json(apiOk({ items: [] })); // template kind, not yet configured with a source blueprint
      }
      const like = `%${boundEscapedLike(qRaw)}%`;
      const rows = await conn.query(
        `SELECT id, name, updated_at FROM \`${t(TABLES.USER_TEMPLATES)}\`
          WHERE blueprint_id = ? AND name LIKE ? ESCAPE '\\\\'
          ORDER BY updated_at DESC, id ASC
          LIMIT ?`,
        [cfg.blueprint_id, like, SOURCE_CANDIDATES_MAX],
      );
      return res.json(apiOk({ items: rows.map((r) => ({ id: r.id, name: r.name, updated_at: r.updated_at })) }));
    } catch (err) {
      logger.error({ err, id: req.params.id }, 'source-candidates query failed id=' + req.params.id);
      const e = apiError('Database operation failed', 'INTERNAL_ERROR', 500);
      return res.status(e.status).json(e.body);
    } finally {
      if (conn) conn.release();
    }
  });
}

module.exports = register;
