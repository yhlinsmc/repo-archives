/**
 * api-connectors/approval.js — the admin approval lifecycle for connectors.
 *
 * status: pending → approved (admin) | rejected (admin, with note) → (edit) pending.
 * A NULL status is grandfathered = treated as approved at the dispatch gate, so
 * pre-existing connectors and no-ALTER operator DBs keep dispatching.
 *
 * Two surfaces, both registered BEFORE the generic CRUD `/:id` so they are not
 * shadowed by the factory's PUT/DELETE:
 *   - a write middleware that stamps status on create and re-pends on a
 *     sensitive edit (and strips any client-supplied approval fields, so an
 *     editor cannot self-approve by injecting status into the body);
 *   - PATCH /:id/approve and PATCH /:id/reject (admin only).
 *
 * approved_by / approved_at / review_note are additive nullable columns; a
 * no-ALTER DB without them degrades to no approval gating (writes silently drop
 * the unknown keys; the PATCH routes return APPROVAL_UNAVAILABLE on ER_BAD_FIELD).
 */
const { pool, t } = require('../../../db');
const { apiError, requireAdmin, uuidv4, UUID_RE } = require('../../../../shared/helpers');
const { TABLES } = require('../../../../shared/constants');
const { logger } = require('../../../../shared/lib/logger');

// Server-controlled — a client may never set these directly.
const APPROVAL_FIELDS = ['status', 'approved_by', 'approved_at', 'review_note'];
// A change to any of these connection-shape scalars re-pends a connector that
// would otherwise still dispatch. Declared here and CONSUMED BY THE MOUNT's
// `repandOnSensitiveChange` option, so the comparison happens inside the write
// transaction against the locked row rather than against a snapshot taken on
// another pool. Two deliberate exclusions:
//   - auth_config: serializeRead masks its secrets, so the body's masked value
//     never equals the stored ciphertext and would spuriously re-pend every save;
//     auth_type (a credential-shape change) is the comparable proxy.
//   - request_config: request headers/body are routine, high-churn author edits
//     (adding a header, tweaking a body template) that do not change WHERE or HOW
//     the connector connects; re-pending on them made every ordinary edit require
//     re-approval, so they are intentionally NOT triggers. The scalars capture
//     the security-relevant surface (endpoint, verb, credential shape, egress,
//     and WHICH KIND of source this connector dispatches: an approved http
//     connector repointed at a template/static source is exactly as much a
//     destination change as a url edit, and must not keep dispatching
//     unreviewed).
const SENSITIVE_SCALAR = Object.freeze(['url', 'method', 'auth_type', 'dispatch_origin', 'source_kind']);
// source_config is a JSON column (the flow-recipes mirror of this file has the
// same split): the mount's `jsonColumns` option compares it by parsed content
// (crud-factory.js's canonicalJsonValue), not `!==`, so a re-serialisation that
// changes nothing about the document does not spuriously re-pend. It is NOT
// key-order-insensitive — canonicalJsonValue parses then re-stringifies without
// sorting keys, so a same-content payload submitted with a different key order
// still reads as changed and still re-pends; only a byte-identical-after-parse
// document is treated as unchanged.
const SENSITIVE_JSON = Object.freeze(['source_config']);
const MAX_NOTE = 2000;

async function writeApprovalAudit(conn, eventType, userId, connectorId) {
  try {
    await conn.query(
      `INSERT INTO \`${t(TABLES.FEATURE_AUDIT)}\` (id, event_type, user_id, metadata) VALUES (?, ?, ?, ?)`,
      [uuidv4(), eventType, userId || null, JSON.stringify({ connector_id: connectorId })],
    );
  } catch (e) { logger.warn({ err: e }, 'connector approval audit write failed eventType=' + eventType); }
}

module.exports = function registerApproval(router) {
  // Write middleware: strip client-supplied approval state, and stamp status on
  // create. The sensitive-edit re-pend is the mount's, inside the transaction.
  router.use(async (req, res, next) => {
    if ((req.method !== 'POST' && req.method !== 'PUT') || req.path === '/import') return next();
    if (!req.body || typeof req.body !== 'object') return next();
    // SECURITY: approval state is server-owned — drop any client-supplied value so
    // an editor cannot self-approve via the body.
    for (const f of APPROVAL_FIELDS) delete req.body[f];

    const isAdmin = req.user?.role === 'admin';
    if (req.method === 'POST') {
      // admin-created → auto-approved (admin is the approver); editor → pending.
      if (isAdmin) {
        req.body.status = 'approved';
        req.body.approved_by = req.user?.id ?? null;
        req.body.approved_at = new Date();
      } else {
        req.body.status = 'pending';
      }
      return next();
    }

    // PUT: THE RE-PEND IS NOT HERE ANY MORE.
    //
    // It is a `repandOnSensitiveChange` declaration on the mount, so the probe
    // runs inside the factory's write transaction with the row locked and the
    // verdict folded into the same UPDATE. Here it read `pool.ro` while the
    // approve/reject PATCHes below write `pool.rw`, with nothing holding the row
    // between the probe and the statement it informed.
    //
    // What is left on this verb is the one thing that must happen BEFORE the
    // factory sees the body: the strip above, which is why an editor cannot
    // self-approve by putting `status` in it.
    return next();
  });

  router.patch('/:id/approve', async (req, res) => {
    if (!requireAdmin(req, res)) return;
    if (!UUID_RE.test(req.params.id)) { const e = apiError('Invalid connector id', 'BAD_REQUEST', 400); return res.status(e.status).json(e.body); }
    let conn;
    try {
      conn = await pool.rw.getConnection();
      const r = await conn.query(
        `UPDATE \`${t(TABLES.API_CONNECTORS)}\`
            SET status='approved', approved_by=?, approved_at=NOW(), review_note=NULL
          WHERE id = ?`,
        [req.user?.id ?? null, req.params.id],
      );
      if (!r.affectedRows) { const e = apiError('Connector not found', 'NOT_FOUND', 404); return res.status(e.status).json(e.body); }
      await writeApprovalAudit(conn, 'connector.approval.granted', req.user?.id, req.params.id);
      return res.json({ ok: true });
    } catch (err) {
      if (err?.code === 'ER_BAD_FIELD_ERROR' || err?.errno === 1054) {
        const e = apiError('Approval is unavailable until the database migration adds the approval columns', 'APPROVAL_UNAVAILABLE', 409);
        return res.status(e.status).json(e.body);
      }
      logger.error({ err, id: req.params.id }, 'connector approve failed');
      const e = apiError('Database operation failed', 'INTERNAL_ERROR', 500);
      return res.status(e.status).json(e.body);
    } finally { if (conn) conn.release(); }
  });

  router.patch('/:id/reject', async (req, res) => {
    if (!requireAdmin(req, res)) return;
    if (!UUID_RE.test(req.params.id)) { const e = apiError('Invalid connector id', 'BAD_REQUEST', 400); return res.status(e.status).json(e.body); }
    const note = typeof req.body?.review_note === 'string' ? req.body.review_note.trim() : '';
    if (!note) { const e = apiError('A review note is required to reject a connector', 'BAD_REQUEST', 400); return res.status(e.status).json(e.body); }
    let conn;
    try {
      conn = await pool.rw.getConnection();
      const r = await conn.query(
        `UPDATE \`${t(TABLES.API_CONNECTORS)}\`
            SET status='rejected', approved_by=NULL, approved_at=NULL, review_note=?
          WHERE id = ?`,
        [note.slice(0, MAX_NOTE), req.params.id],
      );
      if (!r.affectedRows) { const e = apiError('Connector not found', 'NOT_FOUND', 404); return res.status(e.status).json(e.body); }
      await writeApprovalAudit(conn, 'connector.approval.rejected', req.user?.id, req.params.id);
      return res.json({ ok: true });
    } catch (err) {
      if (err?.code === 'ER_BAD_FIELD_ERROR' || err?.errno === 1054) {
        const e = apiError('Approval is unavailable until the database migration adds the approval columns', 'APPROVAL_UNAVAILABLE', 409);
        return res.status(e.status).json(e.body);
      }
      logger.error({ err, id: req.params.id }, 'connector reject failed');
      const e = apiError('Database operation failed', 'INTERNAL_ERROR', 500);
      return res.status(e.status).json(e.body);
    } finally { if (conn) conn.release(); }
  });
};

// The mount reads these to declare its `repandOnSensitiveChange` columns — one
// scalar list and one JSON list, so what re-pends a connector cannot drift from
// what this file documents.
module.exports.SENSITIVE_SCALAR = SENSITIVE_SCALAR;
module.exports.SENSITIVE_JSON = SENSITIVE_JSON;
