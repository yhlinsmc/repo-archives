/**
 * bindings.js — PUT /:id/bindings { blueprint_ids } — replace a connector's
 * "also usable in" set. Authority: admin any; an editor must own the connector
 * (the connector-ownership rule connector-manage-authority.js also applies for
 * editing/test-dispatching the connector itself — a grant does not reach
 * connector ownership, only the blueprint subtree) AND may write the connector's
 * HOME blueprint (owner OR admin OR a blueprint-scope grant on it —
 * `checkBlueprintWriteTarget`, the same resolver every other blueprint-subtree
 * write uses, since a connector-blueprint binding is one of the writes spec
 * §6.1 names). Every TARGET blueprint is authorised the same way, inside
 * `assertBindingTargets`. The home blueprint (api_connectors.blueprint_id) is
 * never a valid member — it is the ownership column, read by one and only one
 * code path. Every bound blueprint is checked for field_key completeness (the
 * shared check) and follower-column safety.
 *
 * The binding set is a GROUP property. A bundle (aggregation/chain group) is a
 * set of connectors that all share ONE home blueprint and co-execute for one
 * blueprint's data entry, so its members must resolve to the same usable-in
 * set or data entry would list a partially available bundle. A PUT on a
 * bundled connector therefore replaces the extra set for EVERY member of the
 * group in one transaction (an ungrouped connector is a group of one). Applying
 * it per member is what makes the set reachable at all: a per-connector write
 * would leave every sibling on its old set and trip the coherence invariant on
 * the very first edit.
 */
const { t } = require('../../../db');
const { resolveRwPool } = require('../schema/request-pool');
const { isMissingTable, checkBlueprintWriteTarget } = require('../schema/helpers');
const { requireAdminOrEditor, apiError } = require('../../../../shared/helpers');
const { TABLES } = require('../../../../shared/constants');
const { logger: rootLogger } = require('../../../../shared/lib/logger');
const { mapRowsFromDb } = require('../../../lib/dto-mapper');
const { sameStoredId } = require('../../../lib/connector-binding-keys');
// The ONE binding-target decision (existence + node_type + authority +
// completeness + follower) shared with the import path and the CRUD PUT
// bundle-join guard — no second copy of any of those four rules lives here.
const { assertBindingTargets } = require('../../../lib/connector-binding-authority');

const logger = rootLogger.child({ module: 'api-connectors:bindings' });

// Bound the set so a single request cannot fan a delete+insert loop across an
// unbounded id list (per member, in a group).
const MAX_BINDINGS = 64;

// One member's usable-in signature = the SORTED union of {home ∪ extras}. Order
// insensitive on purpose: the home is not privileged over an extra when
// comparing two members' sets, and the extras arrive in DB row order. Two
// members are coherent iff their signatures are equal.
function bindingSignature(homeBlueprintId, extraIds) {
  return [homeBlueprintId, ...extraIds].sort().join('|');
}

// Defensive post-write invariant: after the group write set every member to the
// same set this MUST already hold, so a hit means a member appeared mid-flight
// (a new row joined the group between the member load and the write). Fail
// closed — the caller rolls back rather than commit a half-coherent bundle.
// Runs inside the transaction so it sees the rows just written. Returns the
// first offending member ({id,name}) or null.
async function findGroupBindingMismatch(conn, groupId, homeBlueprintId) {
  // group_id is not blueprint-unique: an import can copy a group_id onto another
  // blueprint, so a bundle is the members sharing group_id AND this home. A
  // NULL-home connector is a group of one — nothing to check.
  if (!groupId || homeBlueprintId == null) return null;
  const members = await conn.query(
    `SELECT id, name, blueprint_id FROM \`${t(TABLES.API_CONNECTORS)}\` WHERE group_id = ? AND blueprint_id = ?`,
    [groupId, homeBlueprintId],
  );
  if (members.length < 2) return null;
  const extras = await conn.query(
    `SELECT connector_id, blueprint_id FROM \`${t(TABLES.API_CONNECTOR_BLUEPRINTS)}\`
      WHERE connector_id IN (${members.map(() => '?').join(', ')})`,
    members.map((m) => m.id),
  );
  const extraByConnector = new Map();
  for (const row of extras) {
    let set = extraByConnector.get(row.connector_id);
    if (!set) { set = new Set(); extraByConnector.set(row.connector_id, set); }
    set.add(row.blueprint_id);
  }
  const sig = (m) => bindingSignature(m.blueprint_id, [...(extraByConnector.get(m.id) || new Set())]);
  const first = sig(members[0]);
  for (const m of members) if (sig(m) !== first) return { id: m.id, name: m.name };
  return null;
}

function register(router) {
  router.put('/:id/bindings', async (req, res) => {
    if (!requireAdminOrEditor(req, res)) return;
    const ids = req.body && Array.isArray(req.body.blueprint_ids) ? req.body.blueprint_ids : null;
    if (!ids || ids.some((v) => typeof v !== 'string' || !v)) {
      const e = apiError('blueprint_ids must be an array of blueprint ids', 'BAD_REQUEST', 400);
      return res.status(e.status).json(e.body);
    }
    const wanted = [...new Set(ids)];
    if (wanted.length > MAX_BINDINGS) {
      const e = apiError(`blueprint_ids cannot exceed ${MAX_BINDINGS} entries`, 'BAD_REQUEST', 400);
      return res.status(e.status).json(e.body);
    }
    let conn;
    try {
      // SAFETY: pool resolution + connection acquisition are inside the try —
      // a rejection here (pool down / db override unresolvable) must become a
      // 500 from the outer catch, not an unhandled rejection that kills the
      // process. Mirrors the sibling routes (io.js / usable.js / health.js).
      const rwFacade = await resolveRwPool(req);
      conn = await rwFacade.getConnection();

      const rows = await conn.query(`SELECT * FROM \`${t(TABLES.API_CONNECTORS)}\` WHERE id = ?`, [req.params.id]);
      if (!rows.length) { const e = apiError('Not found', 'NOT_FOUND', 404); return res.status(e.status).json(e.body); }
      const connector = mapRowsFromDb('api_connectors', rows)[0];

      // The home blueprint is the ownership column, never an extra binding. Every
      // member of a bundle shares this home, so one check covers the whole group.
      if (wanted.includes(connector.blueprint_id)) {
        const e = apiError('The home blueprint cannot also be an extra binding.', 'BINDING_HOME_BLUEPRINT', 400);
        return res.status(e.status).json(e.body);
      }

      // An extra is "also usable in": it presupposes a home the connector is
      // primarily usable in. A NULL-home connector reached through /usable via
      // its extras answers 'unbound' in health, an incoherent state — so refuse
      // adding extras until a home is set. An empty set (a clear) is allowed so
      // an already-broken row can be emptied.
      if (connector.blueprint_id == null && wanted.length) {
        const e = apiError('Set a home blueprint before adding other blueprints.', 'BINDING_HOME_BLUEPRINT', 400);
        return res.status(e.status).json(e.body);
      }

      // The write set is a group property: a bundled connector's PUT applies to
      // every member sharing the home. group_id alone is not blueprint-unique,
      // so scope by group_id AND home; a NULL-home connector is a group of one.
      const isAdmin = req.user.role === 'admin';
      let members;
      if (connector.group_id && connector.blueprint_id != null) {
        const memberRows = await conn.query(
          `SELECT * FROM \`${t(TABLES.API_CONNECTORS)}\` WHERE group_id = ? AND blueprint_id = ?`,
          [connector.group_id, connector.blueprint_id],
        );
        members = memberRows.length ? mapRowsFromDb('api_connectors', memberRows) : [connector];
      } else {
        members = [connector];
      }

      // Editor authority CONJUNCTION: own EVERY member row (a blueprint grant
      // covers the blueprint SUBTREE, not connector ownership — connector
      // ownership stays its own rule, mirroring connector-manage-authority.js's
      // edit/test-dispatch gate) AND may write the shared HOME blueprint. 403
      // names the first member not owned. Fail-closed when the home row is
      // absent.
      if (!isAdmin) {
        const notOwned = members.find((m) => !(m.owner_id == null || sameStoredId(m.owner_id, req.user.id)));
        if (notOwned) {
          const e = apiError('You do not own every connector in this bundle.', 'FORBIDDEN', 403, { details: { member_id: notOwned.id } });
          return res.status(e.status).json(e.body);
        }
        if (connector.blueprint_id != null) {
          // spec §6.1: a connector-blueprint binding is a blueprint-subtree
          // write, so the home blueprint's authority goes through the SAME
          // resolver every other subtree write uses (owner OR admin OR a
          // blueprint-scope grant) instead of a second, grant-blind ownership
          // copy — a grantee editor who owns this connector was refused here
          // even though the shared resolver would have let them write every
          // other object under this same blueprint.
          const mayWriteHome = await checkBlueprintWriteTarget(conn, req, connector.blueprint_id);
          if (!mayWriteHome) { const e = apiError('You do not own the home blueprint of this connector.', 'FORBIDDEN', 403); return res.status(e.status).json(e.body); }
        }
      }

      // Target existence + node_type + authority + completeness + follower — the
      // ONE shared decision, asked PER MEMBER: existence/node_type/authority of
      // the targets are member-independent, but completeness and follower are
      // judged against each member's own config (two members of a bundle carry
      // different configs, so a blueprint complete for one may be missing a field
      // the other fills). On any member's failure the whole group write is
      // refused and nothing is applied, with the offending target/member named in
      // details. (An empty `wanted` short-circuits to a pass — a clear.)
      for (const m of members) {
        const failure = await assertBindingTargets({ req, connector: m, targetIds: wanted, conn });
        if (failure) {
          const e = apiError(failure.message, failure.code, failure.status, { details: failure.details });
          return res.status(e.status).json(e.body);
        }
      }

      // Replace the set for every member inside one transaction, then verify
      // group coherence.
      await conn.beginTransaction();
      try {
        for (const m of members) {
          await conn.query(`DELETE FROM \`${t(TABLES.API_CONNECTOR_BLUEPRINTS)}\` WHERE connector_id = ?`, [m.id]);
          for (const id of wanted) {
            await conn.query(
              `INSERT INTO \`${t(TABLES.API_CONNECTOR_BLUEPRINTS)}\` (id, connector_id, blueprint_id) VALUES (UUID(), ?, ?)`,
              [m.id, id],
            );
          }
        }
        const mismatch = await findGroupBindingMismatch(conn, connector.group_id, connector.blueprint_id);
        if (mismatch) {
          await conn.rollback();
          // INVARIANT should never fire (every member was just set to the same
          // set); a hit means a row joined the group mid-flight. Fail-closed.
          logger.error({ groupId: connector.group_id, memberId: mismatch.id }, 'bundle binding coherence violated after group write');
          const e = apiError('The bundle binding set could not be applied coherently; no change was made.', 'BINDING_GROUP_MISMATCH', 500, { details: { member_id: mismatch.id } });
          return res.status(e.status).json(e.body);
        }
        await conn.commit();
      } catch (txErr) {
        try { await conn.rollback(); } catch (rbErr) { logger.warn({ err: rbErr }, 'bindings rollback failed'); }
        // The join table is additive (its create-table migration is
        // warning-severity), so a no-DDL target may lack it. An empty set has
        // nothing to persist → 200; a non-empty set cannot be honoured → 409 so
        // the editor surfaces it rather than looping on a 500 every save.
        if (isMissingTable(txErr)) {
          if (wanted.length === 0) return res.json({ ok: true, data: { bindings: [] } });
          const e = apiError('Connector bindings are unavailable until the schema migration is applied.', 'BINDING_TABLE_MISSING', 409);
          return res.status(e.status).json(e.body);
        }
        throw txErr;
      }
      const applied = [...wanted].sort();
      const data = { bindings: applied };
      if (connector.group_id) {
        data.group_members = members.map((m) => ({ connector_id: m.id, bindings: applied }));
      }
      return res.json({ ok: true, data });
    } catch (err) {
      logger.error({ err, connectorId: req.params.id }, 'Failed to set connector bindings id=' + req.params.id);
      const e = apiError('Database operation failed', 'INTERNAL_ERROR');
      return res.status(e.status).json(e.body);
    } finally {
      if (conn) conn.release();
    }
  });
}

module.exports = register;
// Exported for a symmetry unit test — a pure helper, no DB, mirrors usable.js's
// practice of exporting its internal projection functions for direct testing.
module.exports.bindingSignature = bindingSignature;
