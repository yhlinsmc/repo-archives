/**
 * usable.js — GET /usable?blueprint_id=<id> — a minimal, non-admin projection of
 * the active connectors bound to a blueprint, for the data-entry "Fetch from
 * API" UI. End users never see url/auth/headers/body templates; they receive
 * only the response outputs[] + the derived input-variable list. The outputs
 * (paths/keys/literal business values only) carry no secrets.
 */
const { pool, t } = require('../../../db');
const { apiOk, apiError, requireAuth } = require('../../../../shared/helpers');
const { TABLES } = require('../../../../shared/constants');
const { isMissingTable } = require('../schema/helpers');
const { mapRowsFromDb } = require('../../../lib/dto-mapper');
const { VAR_RE } = require('../../../lib/connector-dispatch');
const { normalizeResponseOutputs } = require('../../../lib/legacy-response-to-outputs');
const { FILTER_OPS, normalizeRowMatch } = require('./validate');
const { effectiveSelectKind } = require('./source-config');
const { logger: rootLogger } = require('../../../../shared/lib/logger');
const { ACTIVE_ROW_SQL } = require('../../../lib/active-row');

const logger = rootLogger.child({ module: 'api-connectors:usable' });

function collectVars(connector) {
  const rc = connector.request_config || {};
  const seen = new Set();
  // VAR_RE is a shared /g regex; build a fresh one per scan so lastIndex state
  // never leaks between calls.
  const scan = (s) => {
    if (typeof s !== 'string') return;
    const re = new RegExp(VAR_RE.source, 'g');
    let m;
    while ((m = re.exec(s)) !== null) seen.add(m[1]);
  };
  scan(connector.url);
  for (const v of Object.values(rc.headers || {})) scan(v);
  scan(rc.body);
  // A template match select's value is a {{var}}-templated string the
  // resolver fills from the SAME inputs map (template-source.js's
  // resolveTemplateSource calls fillTemplate on sel.value) — this projection
  // must advertise that var too, or a new template connector with no
  // request_config (its Request section is hidden entirely) exposes zero
  // inputs and every fetch 400s MISSING_INPUT with no input the data-entry
  // UI ever asked for.
  const sel = connector.source_kind === 'template' && connector.source_config
    ? connector.source_config.select
    : null;
  if (sel && sel.kind === 'match') scan(sel.value);
  return [...seen];
}

function deriveInputSpec(connector) {
  const rc = connector.request_config || {};
  const im = rc.input_mapping || {}; // field_key -> var
  const varToField = {};
  for (const [fieldKey, varName] of Object.entries(im)) {
    if (!(varName in varToField)) varToField[varName] = fieldKey;
  }
  const varToCell = {};
  for (const c of rc.input_cells || []) {
    if (c && c.var && !(c.var in varToCell)) {
      if (c.source === 'manual') {
        // Manual per-row: table_key drives row iteration + output target; value
        // is typed per row at fetch time. No column_key. Emit source: 'manual'
        // so the FE can distinguish from column-bound per-row vars.
        varToCell[c.var] = { table_key: c.table_key, column_key: '', source: 'manual' };
        continue;
      }
      // Column or fixed cell: byte-identical to prior shape (no source field).
      // Absence of source means column for the FE (which only checks === 'manual').
      const cell = { table_key: c.table_key, column_key: c.column_key };
      // A positive-integer row marks a fixed single-cell input (resolved once);
      // absent = per-row binding. Whitelist it so the FE runtime's
      // isFixedCellSpec/getTableBinding can distinguish the two.
      if (Number.isInteger(c.row) && c.row > 0) cell.row = c.row;
      varToCell[c.var] = cell;
    }
  }
  return collectVars(connector).map((v) => {
    const spec = { var: v, source_field_key: varToField[v] || null };
    if (varToCell[v]) spec.source_cell = varToCell[v];
    return spec;
  });
}

/**
 * Normalize a transformers.output_keys DB value to the projection contract:
 * non-empty array of non-empty strings, else null. null = "undeclared" —
 * the badge layer treats it exactly like the pre-feature state, so every
 * malformed/legacy value safely degrades to "no output badges".
 *
 * Projection contract for buildUsableProjection:
 *   id, name, description,
 *   source_kind  — 'http' | 'template' | 'static', defaults to 'http' when the
 *                   column is absent (no-DDL) or unset (grandfathered row)
 *   source_select_kind  — source_config.select.kind ('pick' | 'match'), null
 *                          when unset/inapplicable; the picker (spec §6.5)
 *                          needs this to know whether a run resolves a source
 *                          template automatically or needs a candidate pick
 *   group_id, group_label, group_mode, sequence  — bundle metadata, null when ungrouped
 *   input_from_step  — chain wiring (var/from_sequence/path), null when unchained
 *   response_config.{outputs, transformer_id, transformer_output_keys}
 *   input_spec  — derived var list, never secrets
 *   EXCLUDED: url, auth_type, auth_config, headers, body templates, and the
 *   REST of source_config (blueprint_id/parts/select.value/select.field would
 *   name a template internals a data-entry user has no reason to see)
 */
function parseOutputKeys(raw) {
  let parsed = raw;
  if (typeof raw === 'string') {
    try {
      parsed = JSON.parse(raw);
    } catch {
      return null;
    }
  }
  if (!Array.isArray(parsed)) return null;
  const keys = parsed.filter((k) => typeof k === 'string' && k.length > 0);
  return keys.length > 0 ? keys : null;
}

// Chain wiring projection: rebuilt field-by-field (never passthrough) so a
// future secret-bearing key in the stored shape can't leak. var names,
// integers, JSON paths — all non-secret.
function projectInputFromStep(connector) {
  const raw = (connector.request_config || {}).input_from_step;
  if (!Array.isArray(raw)) return null;
  const entries = raw
    .filter((e) => e && typeof e === 'object'
      && typeof e.var === 'string' && e.var.length > 0
      && Number.isInteger(e.from_sequence) && e.from_sequence >= 1
      && typeof e.path === 'string' && e.path.length > 0)
    .map((e) => ({ var: e.var, from_sequence: e.from_sequence, path: e.path }));
  return entries.length > 0 ? entries : null;
}

// SECURITY: Rebuild a filter condition's value-ref field-by-field per kind so a
// malformed/imported config with extra sibling keys under `value` can't leak to
// the data-entry projection (the rest of projectOutput whitelists, so this must
// too). Every field here is non-secret: enum kind, admin-typed literal business
// value, flat field/column keys, integer row. Unknown/missing kind → drop (null).
function projectValueRef(v) {
  if (!v || typeof v !== 'object') return null;
  if (v.kind === 'literal') return { kind: 'literal', value: v.value };
  if (v.kind === 'field') return { kind: 'field', field_key: v.field_key };
  if (v.kind === 'cell') {
    const cell = v.cell || {};
    return { kind: 'cell', cell: { table_key: cell.table_key, column_key: cell.column_key, row: cell.row } };
  }
  return null; // unknown kind → drop (whitelist)
}

// SECURITY: Rebuild one response output field-by-field (never passthrough) so a
// future secret-bearing key added to the stored shape can't leak to the
// data-entry projection. Every field here is non-secret: JSON paths, flat
// column/field keys, admin-typed literal business values, integer rows, and the
// enum modes/ops/reduce/match. A malformed output (missing from/to) is dropped.
// Filter condition values are rebuilt via projectValueRef (same whitelist rule).
// NOTE: outputs[] reconstruction mirrors src/fmb/lib/connectors/output-config-read.ts;
// keep both in lockstep if the outputs[] shape changes.
function projectOutput(o) {
  if (!o || typeof o !== 'object' || !o.from || !o.to) return null;
  const from = o.from;
  let projectedFrom;
  if (from.mode === 'list') {
    const where = from.where && Array.isArray(from.where.conditions)
      ? {
          match: from.where.match,
          conditions: from.where.conditions.map((c) => ({
            field: c.field,
            op: c.op,
            value: projectValueRef(c.value),
          })),
        }
      : undefined;
    projectedFrom = where ? { mode: 'list', path: from.path, where } : { mode: 'list', path: from.path };
  } else {
    projectedFrom = { mode: 'value', path: from.path };
  }
  const to = o.to;
  let projectedTo;
  if (to.mode === 'field') {
    projectedTo = { mode: 'field', field_key: to.field_key };
    if (to.extract !== undefined) projectedTo.extract = to.extract;
    if (to.reduce !== undefined) projectedTo.reduce = to.reduce;
  } else if (to.mode === 'cell') {
    projectedTo = { mode: 'cell', table_key: to.table_key, column_key: to.column_key, row: to.row };
    if (to.extract !== undefined) projectedTo.extract = to.extract;
    if (to.reduce !== undefined) projectedTo.reduce = to.reduce;
  } else if (to.mode === 'rows') {
    projectedTo = {
      mode: 'rows',
      table_key: to.table_key,
      columns: (Array.isArray(to.columns) ? to.columns : []).map((cm) => ({
        column_key: cm.column_key,
        from: cm.from,
        // Q19 provenance: a column value redirected to the triggering source
        // row's column. Dropping it would silently strip cross-table column
        // provenance before the FE runtime ever sees it.
        ...(cm.from_source_cell ? { from_source_cell: cm.from_source_cell } : {}),
      })),
    };
    // The explicit write-mode toggle (only the three literals reach the FE
    // runtime; a garbage value falls back to match inference identically).
    if (to.write_mode === 'append' || to.write_mode === 'merge' || to.write_mode === 'replace') projectedTo.write_mode = to.write_mode;
    // Optional enrich-by-key join (single or composite key). Normalized to the
    // keys[] shape (legacy single-pair accepted), then rebuilt key-by-key
    // (whitelist) — a key missing either field is dropped by normalizeRowMatch,
    // and a match with no surviving key degrades to a plain create-rows sink
    // rather than reaching the FE runtime as a half-formed join.
    // Defense in depth: a replace clears the WHOLE table before writing, so
    // match/on_no_match are meaningless on it (validate.js rejects them at
    // write time, but this projection also feeds the FE runtime for rows
    // written before that guard existed — skip the join projection entirely
    // for replace rather than let a stale match reach the runtime).
    const normalized = to.write_mode === 'replace' ? undefined : normalizeRowMatch(to.match);
    if (normalized) {
      const keys = normalized.keys
        // A key value comes from the response element (element_field) OR the
        // triggering source row's column (source_cell, Q19). A source-cell key
        // needs no element_field, so it survives on row_column alone — the old
        // `&& element_field` filter deleted it, silently turning a cross-table
        // merge into an append (duplicate rows on every re-run).
        .filter((k) => k.row_column && (k.element_field || k.source_cell))
        .map((k) => ({
          row_column: k.row_column,
          element_field: k.element_field,
          // Constrain to the known FilterOp set; never forward an arbitrary
          // stored string to the FE runtime.
          op: (k.op && FILTER_OPS.has(k.op)) ? k.op : 'eq',
          ...(k.source_cell ? { source_cell: k.source_cell } : {}),
        }));
      if (keys.length > 0) {
        projectedTo.match = { keys };
        // Forward the unmatched-element policy: 'skip' (default) or 'create'
        // (upsert). Upsert is eq-only on every key, so only project 'create'
        // when all projected keys are eq.
        const allEq = keys.every((k) => k.op === 'eq');
        if (to.on_no_match === 'skip') projectedTo.on_no_match = 'skip';
        else if (to.on_no_match === 'create' && allEq) projectedTo.on_no_match = 'create';
      }
    }
    // Fix 1 (BE): carry sort keys for the fetch runtime, but only for columns
    // that survived the projection (stale column keys are dropped). Sanitize:
    // only {column:string, dir:'asc'|'desc'} keys survive — guards against
    // stale/corrupt stored data.
    if (Array.isArray(to.order_by)) {
      const projectedColumnKeys = new Set(projectedTo.columns.map((cm) => cm.column_key));
      const sanitized = to.order_by.filter(
        (k) => k && typeof k.column === 'string' && k.column.length > 0 &&
               (k.dir === 'asc' || k.dir === 'desc') &&
               projectedColumnKeys.has(k.column),
      );
      if (sanitized.length > 0) {
        projectedTo.order_by = sanitized.map((k) => ({ column: k.column, dir: k.dir }));
      }
    }
  } else if (to.mode === 'options') {
    // spec §1.1/§4.2: an options-list output writes nowhere — value_path and
    // an optional label_path are the only non-secret facts a field's options
    // picker needs. from is already the generic `list` rebuild above (path,
    // no where — validate.js rejects from.where on an options output).
    projectedTo = { mode: 'options', value_path: String(to.value_path || '') };
    if (to.label_path) projectedTo.label_path = String(to.label_path);
  } else {
    return null;
  }
  return { id: o.id, from: projectedFrom, to: projectedTo };
}

function buildUsableProjection(connector, transformerOutputKeysById) {
  const rc = connector.response_config || {};
  // A row stored before the outputs[] unification carries legacy
  // {mappings,lookups}; convert at the read boundary (no DB migration exists)
  // so projectOutput rebuilds the same secret-safe outputs the editor produces.
  const outputs = normalizeResponseOutputs(rc).map(projectOutput).filter(Boolean);
  const transformerId = rc.transformer_id || null;
  const lookup = transformerOutputKeysById || new Map();
  // D-F5: undefined (column absent, no-DDL) and NULL (grandfathered row) both
  // read as 'http', same coalesce the write guard and health.js apply.
  const sourceKind = connector.source_kind || 'http';
  // ONLY the effective select strategy — never the rest of source_config
  // (blueprint_id, parts, select.value/select.field are template internals,
  // not a data-entry concern). Delegates to the same helper the resolver
  // uses for its default so an omitted `select` on a mode-one template still
  // reads as 'pick' here (R-C5) instead of null.
  const sourceSelectKind = effectiveSelectKind(sourceKind, connector.source_config);
  return {
    id: connector.id,
    name: connector.name,
    description: connector.description ?? null,
    source_kind: sourceKind,
    source_select_kind: sourceSelectKind,
    response_config: {
      outputs,
      transformer_id: transformerId,
      // Declared output keys of the bound transformer (admin-confirmed in
      // the transformer editor). null = undeclared → badge layer keeps the
      // inputs-only behavior. Field-key names only — non-secret.
      transformer_output_keys: transformerId ? (lookup.get(transformerId) ?? null) : null,
    },
    // Bundle membership — null when the connector is ungrouped. Carried so the
    // FE can co-execute parallel/chained groups without an extra query.
    group_id: connector.group_id ?? null,
    group_label: connector.group_label ?? null,
    group_mode: connector.group_mode ?? null,
    sequence: connector.sequence ?? null,
    input_from_step: projectInputFromStep(connector),
    input_spec: deriveInputSpec(connector),
  };
}

function register(router) {
  router.get('/usable', async (req, res) => {
    if (!requireAuth(req, res)) return;
    const blueprintId = req.query.blueprint_id;
    if (!blueprintId || typeof blueprintId !== 'string') {
      const e = apiError('blueprint_id is required', 'BAD_REQUEST', 400);
      return res.status(e.status).json(e.body);
    }
    let conn;
    try {
      conn = await pool.ro.getConnection();
      // Select only the columns the projection needs (url is consumed to derive
      // the input-variable list, then dropped). The encrypted auth_config and
      // the other sensitive columns are never hydrated into this process.
      // Also lists a connector "also usable in" this blueprint via the join
      // table, not only its home blueprint. source_kind/source_config are
      // additive (same as the join table) so their absence degrades
      // independently — up to two retries, never a 500 for either gap alone.
      const SOURCE_COLS = ', source_kind, source_config';
      const usableSqlJoin = `SELECT id, name, description, url, request_config, response_config,
                group_id, group_label, group_mode, \`sequence\`${SOURCE_COLS}
           FROM \`${t(TABLES.API_CONNECTORS)}\`
          WHERE (blueprint_id = ?
                 OR id IN (SELECT connector_id FROM \`${t(TABLES.API_CONNECTOR_BLUEPRINTS)}\` WHERE blueprint_id = ?))
            AND ${ACTIVE_ROW_SQL}`;
      const usableSqlHomeOnly = `SELECT id, name, description, url, request_config, response_config,
                  group_id, group_label, group_mode, \`sequence\`${SOURCE_COLS}
             FROM \`${t(TABLES.API_CONNECTORS)}\` WHERE blueprint_id = ? AND ${ACTIVE_ROW_SQL}`;
      // Same ER_BAD_FIELD_ERROR/1054 idiom health.js's own retry uses for the
      // same two columns — mirrored, not extracted, since extracting would
      // touch health.js's own working query for a two-site helper.
      const isMissingColumn = (err) => !!err && (err.code === 'ER_BAD_FIELD_ERROR' || err.errno === 1054);
      const withoutSourceCols = (sql) => sql.replace(SOURCE_COLS, '');
      let rows;
      try {
        rows = await conn.query(usableSqlJoin, [blueprintId, blueprintId]);
      } catch (err) {
        if (isMissingColumn(err)) {
          try {
            rows = await conn.query(withoutSourceCols(usableSqlJoin), [blueprintId, blueprintId]);
          } catch (err2) {
            if (!isMissingTable(err2)) throw err2;
            rows = await conn.query(withoutSourceCols(usableSqlHomeOnly), [blueprintId]);
          }
        } else if (isMissingTable(err)) {
          // A no-DDL DB may lack the additive join table (its migration is
          // severity 'warning'); degrade to "home-blueprint connectors only"
          // rather than 500ing every data-entry fetch surface.
          try {
            rows = await conn.query(usableSqlHomeOnly, [blueprintId]);
          } catch (err2) {
            if (!isMissingColumn(err2)) throw err2;
            rows = await conn.query(withoutSourceCols(usableSqlHomeOnly), [blueprintId]);
          }
        } else {
          throw err;
        }
      }
      const connectors = mapRowsFromDb('api_connectors', rows);
      // Transformer-mode connectors carry their transformer's declared
      // output keys so data-entry badges can mark outputs. One deduped
      // PK-IN lookup, skipped entirely when no connector uses a transformer.
      const transformerIds = [
        ...new Set(
          connectors
            .map((c) => (c.response_config || {}).transformer_id)
            .filter(Boolean),
        ),
      ];
      let outputKeysById = null;
      if (transformerIds.length > 0) {
        const tRows = await conn.query(
          `SELECT id, output_keys FROM \`${t(TABLES.TRANSFORMERS)}\`
            WHERE id IN (${transformerIds.map(() => '?').join(', ')})`,
          transformerIds,
        );
        outputKeysById = new Map(tRows.map((r) => [r.id, parseOutputKeys(r.output_keys)]));
      }
      return res.json(apiOk(connectors.map((c) => buildUsableProjection(c, outputKeysById))));
    } catch (err) {
      logger.error({ err, blueprintId }, 'usable connectors query failed blueprintId=' + blueprintId);
      const e = apiError('Failed to load connectors', 'INTERNAL_ERROR', 500);
      res.status(e.status).json(e.body);
    } finally {
      if (conn) conn.release();
    }
  });
}

module.exports = register;
module.exports.buildUsableProjection = buildUsableProjection;
module.exports.deriveInputSpec = deriveInputSpec;
module.exports.parseOutputKeys = parseOutputKeys;
module.exports.projectInputFromStep = projectInputFromStep;
