/**
 * api-connectors/index.js — router assembly for the API Connectors feature.
 *
 * End-user (non-admin) routes are registered FIRST so they are not subject to
 * the blanket admin gate that follows:
 *   GET /usable     — minimal projection for data-entry users (requireAuth)
 *
 * Dispatch (POST /:id/fetch) is now handled by infra via the edge-internal
 * /edge/internal/connectors/prepare endpoint. This router no longer registers
 * a fetch route.
 *
 * Admin-only routes (CRUD + io) are registered after the gate:
 *   serializeWrite / serializeRead: encrypt secrets on write, mask on read.
 *   io.js: cross-environment export (no secrets) / import (unbound fallback),
 *   registered before the CRUD router so /import and /:id/export match ahead of
 *   the generic /:id handler. blueprint_id / is_active are the filterable columns.
 */
const express = require('express');
const { pool, t } = require('../../../db');
const { createCrudRoutes } = require('../schema');
// The one resolver for "which database is this request about" — the same one the
// factory this guard is mounted beside uses to pick the pool it writes to.
const { resolveRwPool } = require('../schema/request-pool');
const { isMissingTable, ensureColumnsInCachedSet } = require('../schema/helpers');
const { enumColumnsFor } = require('../../../lib/schema-manifest');
const { requireAdminOrEditor, apiError } = require('../../../../shared/helpers');
const { TABLES } = require('../../../../shared/constants');
const { logger } = require('../../../../shared/lib/logger');
const { serializeWrite, serializeRead } = require('./serializer');
const {
  validateInputFromStep, validateResponseOutputs, validateInputCells, validateConnectorCoherence,
  loadFollowerColumnKeys, validateNoFollowerColumnTarget, parseResponseConfigForGuard, parseJsonConfigForGuard,
  loadBlueprintFieldKeySets,
} = require('./validate');
// The single completeness check shared with the bindings PUT route — a save
// must never leave an already-bound extra blueprint incomplete, judged the
// identical way a bind-time check would judge it. (This "don't break an
// existing binding on a config change" guard is a distinct invariant from the
// bind-decision below: it re-runs completeness + follower against the extras
// ALREADY bound, without re-asking authority, so a config fix is never refused
// because a bound extra's ownership later drifted.)
const { findMissingFieldKeysForBindings } = require('../../../lib/connector-binding-keys');
// The ONE binding-target decision — existence + node_type + authority +
// completeness + follower — asked by every path that binds: the bindings PUT,
// the import path, and the bundle-join guard below.
const { assertBindingTargets } = require('../../../lib/connector-binding-authority');
const { egressAllowedForUrl } = require('../../../../shared/lib/egress-policy');
// Shared url guard: absolute http(s) with NO embedded credentials (userinfo in a
// url is never legit — auth belongs in auth_config; a stored userinfo url leaks a
// Basic-auth secret in the plaintext url column + on export).
const { isStorableHttpUrl } = require('../../../../shared/lib/portable-url-redaction');
const { validateSourceConfig, normalizeForSourceKind, probeSourceColumns, SOURCE_KINDS } = require('./source-config');
const { parseJsonColumn } = require('../../../../shared/serializers/parse-json-column');

const router = express.Router();

// Shared 400 envelope for the write-shape guards below — one definition so the
// code/shape can't drift between the bundle-fields and chain-wiring checks.
const badRequest = (res, message) =>
  res.status(400).json({ ok: false, error: { code: 'BAD_REQUEST', message } });

// End-user (non-admin) routes MUST be registered BEFORE the blanket admin gate
// below. Data-entry users read a minimal projection (usable.js enforces it) and
// fire a connector; they never see url/auth/templates.
require('./usable')(router);     // GET /usable        (requireAuth, projection)
// A nested path (/:id/source-candidates), not the bare /:id GET the CRUD
// catch-all owns below — mounting it here is enough to avoid shadowing (same
// rule the comment above documents for /usable), and it must sit ahead of the
// admin-OR-editor gate so a data-entry user reaches it.
require('./source-candidates')(router); // GET /:id/source-candidates (requireAuth)

// Everything below is admin-OR-editor: secrets stay masked (serializeRead),
// and writes are owner-scoped by the CRUD factory (ownerColumn + parentOwnership).
// Editors see every connector's metadata (endpoint, auth-header names) by design
// — the same view-all contract as user_templates. Plain users never reach here
// (they get the minimal /usable projection above).
router.use((req, res, next) => {
  if (!requireAdminOrEditor(req, res)) return;
  next();
});

// PUT /:id/bindings — replace a connector's "also usable in" set. Registered
// before the write-shape guards below (url / egress / bundle / follower /
// timeout / null-owner), which key off body columns this route never carries;
// bindings runs its own authority + completeness + group-coherence checks
// (target authority/completeness/follower all via the shared
// assertBindingTargets, so the bundle-join guard below and the import path
// judge a binding identically).
require('./bindings')(router);

// Source-kind guard: normalise the http-only columns for a non-http connector,
// then validate the source_config against the DB. Runs ahead of the url-shape
// and egress guards below: those two are http-only checks and must not run
// against a template/static payload's inert url/method — they read the stamp
// this guard leaves on res.locals, never re-deriving the kind from the body
// themselves. Scoped to body-bearing writes that name either half; /import
// validates its own payload (io.js).
router.use(async (req, res, next) => {
  if ((req.method !== 'POST' && req.method !== 'PUT') || req.path === '/import' || !req.body) return next();
  const touchesKind = Object.prototype.hasOwnProperty.call(req.body, 'source_kind');
  const touchesConfig = Object.prototype.hasOwnProperty.call(req.body, 'source_config');
  if (!touchesKind && !touchesConfig) return next();
  try {
    let sourceKind = touchesKind ? req.body.source_kind : undefined;
    let sourceConfig = touchesConfig ? req.body.source_config : undefined;
    const rowIdMatch = req.path.match(/^\/([^/]+)$/);
    const sourceGuardPool = await resolveRwPool(req);
    // Set only when the stored-row probe just below actually ran and answered
    // this question (its SELECT succeeding means the columns exist; its own
    // 1054 means they don't) — left undefined when no such probe ran, so the
    // columns-exist check further down knows whether it still needs to ask.
    let columnsExist;
    if ((!touchesKind || !touchesConfig) && req.method === 'PUT' && rowIdMatch) {
      let rows;
      try {
        rows = await sourceGuardPool.query(
          `SELECT source_kind, source_config FROM \`${t(TABLES.API_CONNECTORS)}\` WHERE id = ?`,
          [rowIdMatch[1]],
        );
        columnsExist = true;
      } catch (probeErr) {
        // A no-ALTER operator DB: both columns are physically absent, same
        // degradation posture as internal/connectors.js's ADDITIVE_COLS
        // fallback. Leave sourceKind/sourceConfig at whatever the body itself
        // named (possibly still undefined) — the coalesce below reads that as
        // 'http', matching the grandfathered-row behaviour everywhere else.
        if (probeErr?.code !== 'ER_BAD_FIELD_ERROR' && probeErr?.errno !== 1054) throw probeErr;
        rows = null;
        columnsExist = false;
      }
      if (rows) {
        if (!rows.length) return next(); // absent row → CRUD answers 404
        if (!touchesKind) sourceKind = rows[0].source_kind;
        if (!touchesConfig) sourceConfig = parseJsonColumn(rows[0].source_config);
      }
    }
    if (sourceKind === undefined) sourceKind = 'http'; // grandfathered / no-DDL row
    // An unknown kind is a caller error on EVERY database, DDL-applied or not —
    // it must never fall through to the columns-exist gate below, which only
    // answers "can this (valid) non-http kind be stored", not "is this a kind
    // at all". Checked before that gate so a no-ALTER DB still 400s instead of
    // reporting SOURCE_KIND_UNAVAILABLE for a value no migration would fix.
    if (!SOURCE_KINDS.includes(sourceKind)) {
      return badRequest(res, `source_kind must be one of ${SOURCE_KINDS.join(', ')}`);
    }
    // A resolved non-http kind needs the two columns to physically exist,
    // independent of which half of the body named it and for POST too — else
    // a no-ALTER DB silently drops source_kind/source_config from the CRUD
    // write while the inert http-only columns below still overwrite a working
    // connector's url/method/auth. Reuse the stored-row probe's answer above
    // when it already ran; only ask again when it didn't.
    if (sourceKind !== 'http' && columnsExist === undefined) {
      columnsExist = await probeSourceColumns(sourceGuardPool, t);
    }
    if (sourceKind !== 'http' && columnsExist === false) {
      const e = apiError(
        'Template and static sources are unavailable until the schema migration is applied.',
        'SOURCE_KIND_UNAVAILABLE', 409,
      );
      return res.status(e.status).json(e.body);
    }
    // columnsExist is true here for a non-http kind (the 409 above returns on
    // false). R-G1: the CRUD factory's own column-set cache (schema/helpers.js,
    // no TTL) may have been primed BEFORE a live, no-restart migration added
    // these two columns — this guard's own probe just above is a live SELECT
    // and already reflects reality, but the factory's cache would otherwise go
    // on answering from its stale snapshot and silently drop source_kind/
    // source_config from the INSERT/UPDATE column list even though this guard
    // just approved the write. Reconcile it before next() so the write this
    // guard is about to allow through actually lands.
    if (sourceKind !== 'http') {
      await ensureColumnsInCachedSet(sourceGuardPool, t(TABLES.API_CONNECTORS), ['source_kind', 'source_config']);
    }
    // Normalise BEFORE the CRUD write so the stored http-only columns are inert.
    req.body = normalizeForSourceKind({ ...req.body, source_kind: sourceKind });
    const msg = await validateSourceConfig(sourceGuardPool, t, sourceKind, sourceConfig);
    if (msg) return badRequest(res, msg);
    // Stamped so the url-shape and egress guards below (this guard now runs
    // ahead of both) can skip a non-http kind without re-deriving it.
    res.locals.resolvedSourceKind = sourceKind;
    return next();
  } catch (err) {
    logger.error({ err }, 'connector source-config guard probe failed');
    const e = apiError('Database operation failed', 'INTERNAL_ERROR');
    return res.status(e.status).json(e.body);
  }
});

// SECURITY: pin the stored url to an absolute http(s) URL (no userinfo) at the
// write boundary (dispatch executes it). The shared CRUD factory has no per-field
// 400 hook, so validate POST/PUT here (the /import path validates its own payload).
// Skipped for a resolved non-http kind: the source-kind guard above already
// normalised url to the inert '' for template/static, and this is an
// http-only shape check — it reads the stamp, never re-derives the kind.
router.use((req, res, next) => {
  if (res.locals.resolvedSourceKind === 'template' || res.locals.resolvedSourceKind === 'static') return next();
  if ((req.method === 'POST' || req.method === 'PUT') && req.path !== '/import'
      && req.body && Object.prototype.hasOwnProperty.call(req.body, 'url')) {
    if (!isStorableHttpUrl(req.body.url)) {
      return res.status(400).json({ ok: false, error: { code: 'BAD_REQUEST', message: 'url must be an absolute http(s) URL' } });
    }
  }
  next();
});

// SECURITY: save-time mirror of the dispatch-time global egress allow-list gate
// (edge /prepare). Reject a create/update whose url+method+path is off the admin
// allow-list, so the operator gets a fast 422 at save instead of a silent
// EGRESS_BLOCKED only when they later try to fetch. Empty list = allow-all
// (opt-in). Only fires when `url` is present (a partial PUT not touching the url
// is unaffected). Method defaults to the connector default (GET) when a partial
// PUT omits it; the dispatch gate re-checks with the stored method as the
// backstop. /import carries the url in its own payload and clone reads it
// server-side from the source row, so neither passes through this body-`url`
// guard; both run the same egressAllowedForUrl gate inline in their handlers.
// A resolved non-http kind is also skipped: its url is the source-kind
// guard's inert '', which is not an egress question at all.
router.use(async (req, res, next) => {
  if (res.locals.resolvedSourceKind === 'template' || res.locals.resolvedSourceKind === 'static') return next();
  if ((req.method !== 'POST' && req.method !== 'PUT') || req.path === '/import') return next();
  if (!req.body || !Object.prototype.hasOwnProperty.call(req.body, 'url')) return next();
  try {
    const egress = await egressAllowedForUrl(req.body.url, req.body.method || 'GET', (sql, params) => pool.ro.query(sql, params), t);
    if (!egress.ok) {
      return res.status(422).json({ ok: false, error: { code: 'EGRESS_BLOCKED', message: 'Connector request is not on the admin egress allow-list', reason: egress.reason } });
    }
  } catch (err) {
    logger.error({ err }, 'connector egress allow-list save check failed');
    return res.status(500).json({ ok: false, error: { code: 'INTERNAL_ERROR', message: 'Database operation failed' } });
  }
  return next();
});

// Bundle-field consistency: group metadata is all-or-nothing. Without a
// group_id the other three are forced NULL (no orphan label/mode/sequence);
// with one, mode+sequence are required and shape-checked here so a bad value
// gets a friendly 400 instead of a DB enum/type 500.
//
// A PARTIAL UPDATE THAT OMITS `group_id` HAS SAID NOTHING ABOUT IT. This guard
// used to fire on "any of the four keys is present", then find `group_id`
// ABSENT — `undefined == null` — and read that as "the caller means ungrouped",
// writing four NULLs. So `PUT {"group_label":"New label"}`, a label rename and
// the most ordinary edit there is, silently removed the connector from its
// bundle; on a chain group that also broke every sibling's `input_from_step`
// wiring, which references members by sequence. The all-or-nothing invariant is
// unchanged — what changes is which fact establishes the bundle: the body's
// `group_id` when the body names it, and otherwise the STORED one, exactly as
// the import path reasons about the same fields.
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const GROUP_FIELDS = ['group_id', 'group_label', 'group_mode', 'sequence'];
router.use(async (req, res, next) => {
  if ((req.method !== 'POST' && req.method !== 'PUT') || req.path === '/import' || !req.body) return next();
  const b = req.body;
  const touched = GROUP_FIELDS.some((k) => Object.prototype.hasOwnProperty.call(b, k));
  if (!touched) return next();
  const bad = (msg) => badRequest(res, msg);
  const namesGroupId = Object.prototype.hasOwnProperty.call(b, 'group_id');

  // The body does not name the bundle, so the row's own bundle is the effective
  // one. Only reachable on a PUT: a create has no stored row, and its absent
  // `group_id` genuinely does mean ungrouped.
  const rowIdMatch = req.path.match(/^\/([^/]+)$/);
  if (!namesGroupId && req.method === 'PUT' && rowIdMatch) {
    let storedGroupId = null;
    try {
      // Read on the write pool: the question is what the row this statement is
      // about to update belongs to, and a replica's answer is a different row's.
      //
      // AND ON THE WRITE POOL THIS REQUEST IS ABOUT. A request may carry `db`,
      // naming a Custom API connection; the factory resolves it and writes there,
      // while the static `pool.rw` this used to read asked the DEFAULT database.
      // Both of its answers were wrong and both were 200s: no row there, so the
      // four bundle fields fell through UNVALIDATED — the orphan state this
      // branch exists to prevent — or a same-id row there, so the decision was
      // taken about a different record entirely.
      const rows = await (await resolveRwPool(req)).query(
        `SELECT group_id FROM \`${t(TABLES.API_CONNECTORS)}\` WHERE id = ?`,
        [rowIdMatch[1]],
      );
      if (!rows.length) return next(); // absent row → the CRUD path answers 404
      storedGroupId = rows[0].group_id;
    } catch (err) {
      // Fail-closed: an unverifiable bundle state must not be written past.
      logger.error({ err, id: rowIdMatch[1] }, 'connector bundle-state probe failed');
      const e = apiError('Database operation failed', 'INTERNAL_ERROR');
      return res.status(e.status).json(e.body);
    }
    if (storedGroupId == null) {
      // Ungrouped, and the body did not say otherwise — the three remaining
      // fields have no bundle to belong to. Degraded to NULL rather than
      // refused, matching how the import path treats the same incoherence: they
      // would otherwise be orphan values that /usable and the chain runner read
      // as membership.
      b.group_label = null; b.group_mode = null; b.sequence = null;
      return next();
    }
    // Grouped. The present fields are judged against that bundle; the absent
    // ones keep what the row holds.
    if (Object.prototype.hasOwnProperty.call(b, 'group_mode')
      && b.group_mode !== 'aggregation' && b.group_mode !== 'chain') {
      return bad("group_mode must be 'aggregation' or 'chain' when group_id is set");
    }
    if (Object.prototype.hasOwnProperty.call(b, 'sequence')
      && (!Number.isInteger(b.sequence) || b.sequence < 1)) {
      return bad('sequence must be a positive integer when group_id is set');
    }
    if (b.group_label != null && (typeof b.group_label !== 'string' || b.group_label.length > 255)) {
      return bad('group_label must be a string ≤ 255 characters');
    }
    return next();
  }

  if (b.group_id == null || b.group_id === '') {
    b.group_id = null; b.group_label = null; b.group_mode = null; b.sequence = null;
    return next();
  }
  if (typeof b.group_id !== 'string' || !UUID_RE.test(b.group_id)) return bad('group_id must be a UUID');
  if (b.group_mode !== 'aggregation' && b.group_mode !== 'chain') return bad("group_mode must be 'aggregation' or 'chain' when group_id is set");
  if (!Number.isInteger(b.sequence) || b.sequence < 1) return bad('sequence must be a positive integer when group_id is set');
  if (b.group_label != null && (typeof b.group_label !== 'string' || b.group_label.length > 255)) return bad('group_label must be a string ≤ 255 characters');
  return next();
});

// Chain-wiring shape check: request_config.input_from_step is consumed by the
// data-entry chain runner; a malformed entry would surface as a confusing
// runtime chain break, so reject it at the write boundary with a friendly 400.
// NOTE: shape-only by design — input_from_step on a non-chain connector is
// accepted and stored (the chain runner only reads it for chain-mode groups,
// and the admin editor normalizes it away on non-chain saves). Rejecting by
// mode here would break the opaque round-trip contract for imports/exports.
router.use((req, res, next) => {
  if ((req.method !== 'POST' && req.method !== 'PUT') || req.path === '/import' || !req.body) return next();
  const msg = validateInputFromStep(req.body.request_config, req.body.sequence)
    || validateInputCells(req.body.request_config)
    || validateResponseOutputs(req.body.response_config)
    || validateConnectorCoherence(req.body.request_config, req.body.response_config);
  if (msg) return badRequest(res, msg);
  return next();
});

// Q9 (D2 amendment A4): no output may target a follower column. Async (a DB
// read against the connector's OWN blueprint's fields), so it is its own
// middleware rather than folded into the sync shape-check above. Skipped
// only when the body touches NEITHER half of (blueprint_id, response_config)
// — nothing about the pair this row carries has changed, so the last write
// that touched either half already judged it.
//
// COMPLETENESS INVARIANT (Codex round-1 P2), not a second special case: this
// guard validates the EFFECTIVE post-write pair, never just the half the
// caller happened to send. A PUT touching only ONE half still changes the
// pair the OTHER half is judged against — e.g. a rebind-only PUT
// (`{"blueprint_id":"new-bp"}`) used to skip this guard entirely (it never
// named `response_config`), and the row's STORED response_config could go on
// targeting a follower column of the NEW blueprint with no check at all. Any
// future write path that changes either half is covered by construction: it
// needs no bespoke wiring here, only to leave the other half omitted for the
// same DB-load branch to fill in.
router.use(async (req, res, next) => {
  if ((req.method !== 'POST' && req.method !== 'PUT') || req.path === '/import' || !req.body) return next();
  const touchesBlueprint = Object.prototype.hasOwnProperty.call(req.body, 'blueprint_id');
  const touchesResponseConfig = Object.prototype.hasOwnProperty.call(req.body, 'response_config');
  if (!touchesBlueprint && !touchesResponseConfig) return next();
  try {
    // The body's own value for each half when it names one (every create; a
    // PUT touching that half); otherwise loaded below from the STORED row —
    // the same "partial update says nothing" reasoning the bundle-group
    // guard above this file already documents.
    let blueprintId = typeof req.body.blueprint_id === 'string' ? req.body.blueprint_id : null;
    let responseConfig = touchesResponseConfig ? req.body.response_config : undefined;
    const rowIdMatch = req.path.match(/^\/([^/]+)$/);
    if ((!touchesBlueprint || !touchesResponseConfig) && req.method === 'PUT' && rowIdMatch) {
      const rwFacade = await resolveRwPool(req);
      const rows = await rwFacade.query(
        `SELECT blueprint_id, response_config FROM \`${t(TABLES.API_CONNECTORS)}\` WHERE id = ?`,
        [rowIdMatch[1]],
      );
      if (!rows.length) return next(); // absent row → the CRUD path answers 404
      if (!touchesBlueprint) blueprintId = rows[0].blueprint_id;
      if (!touchesResponseConfig) responseConfig = parseResponseConfigForGuard(rows[0].response_config);
    }
    if (!blueprintId) return next(); // unbound connector — no schema to judge outputs against
    const followerColumnKeys = await loadFollowerColumnKeys(await resolveRwPool(req), t, blueprintId);
    const msg = validateNoFollowerColumnTarget(responseConfig, followerColumnKeys);
    if (msg) return badRequest(res, msg);
    return next();
  } catch (err) {
    // Fail-closed, same posture as the bundle-group guard above: an
    // unverifiable follower-column set must not be written past silently.
    logger.error({ err }, 'follower-column guard probe failed');
    const e = apiError('Database operation failed', 'INTERNAL_ERROR');
    return res.status(e.status).json(e.body);
  }
});

// A save that would break an ALREADY-BOUND extra blueprint's
// completeness is rejected, not silently unbound — the same check
// (connector-binding-keys.js) the bindings PUT route itself runs, so a
// connector-config save can never leave a bound extra in a state the
// bindings route would have refused to create in the first place.
//
// Scoped to a save that could change what is referenced (request_config or
// response_config) — a bare rebind/rename cannot change completeness against
// an UNCHANGED reference set, and a create has no row id to carry prior join
// rows against. Only reached on a PUT to an existing row that already has
// join rows (bindings.js is the only writer of them); a connector with no
// extra bindings pays no probe cost at all.
router.use(async (req, res, next) => {
  if (req.method !== 'PUT' || req.path === '/import' || !req.body) return next();
  const touchesRequestConfig = Object.prototype.hasOwnProperty.call(req.body, 'request_config');
  const touchesResponseConfig = Object.prototype.hasOwnProperty.call(req.body, 'response_config');
  if (!touchesRequestConfig && !touchesResponseConfig) return next();
  const rowIdMatch = req.path.match(/^\/([^/]+)$/);
  if (!rowIdMatch) return next();
  try {
    const rwFacade = await resolveRwPool(req);
    let extraBlueprintIds;
    try {
      const joinRows = await rwFacade.query(
        `SELECT blueprint_id FROM \`${t(TABLES.API_CONNECTOR_BLUEPRINTS)}\` WHERE connector_id = ?`,
        [rowIdMatch[1]],
      );
      extraBlueprintIds = joinRows.map((r) => r.blueprint_id);
    } catch (err) {
      // A no-DDL DB may lack the additive join table; nothing is bound, so
      // there is nothing this guard could break — degrade to a no-op.
      if (!isMissingTable(err)) throw err;
      extraBlueprintIds = [];
    }
    if (!extraBlueprintIds.length) return next();

    const rows = await rwFacade.query(
      `SELECT request_config, response_config FROM \`${t(TABLES.API_CONNECTORS)}\` WHERE id = ?`,
      [rowIdMatch[1]],
    );
    if (!rows.length) return next(); // absent row → the CRUD path answers 404
    const requestConfig = touchesRequestConfig ? req.body.request_config : parseJsonConfigForGuard(rows[0].request_config);
    const responseConfig = touchesResponseConfig ? req.body.response_config : parseResponseConfigForGuard(rows[0].response_config);

    const rc = responseConfig && typeof responseConfig === 'object' ? responseConfig : {};
    let transformerOutputKeys = null;
    if (rc.transformer_id) {
      const tRows = await rwFacade.query(`SELECT output_keys FROM \`${t(TABLES.TRANSFORMERS)}\` WHERE id = ?`, [rc.transformer_id]);
      if (tRows.length) {
        const raw = tRows[0].output_keys;
        const parsed = typeof raw === 'string' ? (() => { try { return JSON.parse(raw); } catch { return null; } })() : raw;
        transformerOutputKeys = Array.isArray(parsed) ? parsed : null;
      }
    }
    const keySets = await loadBlueprintFieldKeySets(rwFacade, t, extraBlueprintIds);
    const missingResults = findMissingFieldKeysForBindings({
      requestConfig, responseConfig, transformerOutputKeys, blueprintIds: extraBlueprintIds, keySetsByBlueprint: keySets,
    });
    if (missingResults.length) {
      const first = missingResults[0];
      const e = apiError(
        'This save would break an existing binding: the blueprint is missing fields this connector fills.',
        'BINDING_FIELD_KEYS_MISSING', 400,
        { details: { blueprint_id: first.blueprint_id, missing: first.missing } },
      );
      return res.status(e.status).json(e.body);
    }
    // A save must not leave a bound extra targeting one of ITS follower columns
    // either — the bindings PUT runs this guard per target, so a config-save
    // that re-points an output at a follower column of an already-bound extra
    // has to be refused the same way, not silently left in a state the PUT
    // would have rejected. Per bound extra, through the same loader the PUT
    // uses; naming the offending blueprint.
    for (const extraId of extraBlueprintIds) {
      const followerColumnKeys = await loadFollowerColumnKeys(rwFacade, t, extraId);
      const followerMsg = validateNoFollowerColumnTarget(responseConfig, followerColumnKeys);
      if (followerMsg) {
        const e = apiError(followerMsg, 'BINDING_FOLLOWER_COLUMN', 400, { details: { blueprint_id: extraId } });
        return res.status(e.status).json(e.body);
      }
    }
    return next();
  } catch (err) {
    // Fail-closed, same posture as the guards above: an unverifiable binding
    // set must not be written past silently.
    logger.error({ err, id: rowIdMatch[1] }, 'connector bindings write-guard probe failed');
    const e = apiError('Database operation failed', 'INTERNAL_ERROR');
    return res.status(e.status).json(e.body);
  }
});

// Per-connector timeout bounds. NULL/absent = system default. Otherwise an
// integer in [1000, 120000] ms (1–120 s). Defense-in-depth behind the editor's
// own clamp so a raw API call can't store a 0 / negative / connection-wedging
// value. Scoped to POST/PUT (the only body-bearing writes of timeout_ms);
// PATCH /:id/owner carries no connector columns, so it is intentionally outside.
const TIMEOUT_MIN_MS = 1000;
const TIMEOUT_MAX_MS = 120000;
router.use((req, res, next) => {
  if ((req.method !== 'POST' && req.method !== 'PUT') || req.path === '/import' || !req.body) return next();
  if (!Object.prototype.hasOwnProperty.call(req.body, 'timeout_ms')) return next();
  const v = req.body.timeout_ms;
  if (v == null) { req.body.timeout_ms = null; return next(); }
  if (!Number.isInteger(v) || v < TIMEOUT_MIN_MS || v > TIMEOUT_MAX_MS) {
    return badRequest(res, `timeout_ms must be an integer between ${TIMEOUT_MIN_MS} and ${TIMEOUT_MAX_MS} (ms), or null`);
  }
  return next();
});

// SECURITY: connectors are never shared (owner_id is stamped on every POST),
// but the generic CRUD owner predicate treats a NULL owner_id as a shared row
// any editor may write. A degraded/seeded NULL-owned connector must therefore
// be admin-only to modify — reject non-admin PUT/DELETE on such a row here
// (admin bypasses; the CRUD factory still enforces owner-or-NULL for the rest).
// Fail-closed on probe error: an unverifiable owner state must not be mutated.
//
// ASKED OF THE DATABASE THIS REQUEST IS ABOUT, and on the pool the write lands
// on. This guard predates the bundle probe below it and had the same two faults,
// on the same rows and the same verbs: the static pool ignores a request's `db`
// override, so it asked the DEFAULT database about an id living in another and
// admitted the write on "no such row"; and `ro` may address a replica, so a
// gate about the row a statement is about to write could be decided from a
// stale copy of it.
router.use(async (req, res, next) => {
  if (req.method !== 'PUT' && req.method !== 'DELETE') return next();
  if (!req.user || req.user.role === 'admin') return next();
  const m = req.path.match(/^\/([^/]+)$/); // the row id, not a nested path
  if (!m) return next();
  try {
    const rows = await (await resolveRwPool(req)).query(
      `SELECT owner_id FROM \`${t(TABLES.API_CONNECTORS)}\` WHERE id = ?`,
      [m[1]],
    );
    if (rows.length && rows[0].owner_id == null) {
      const e = apiError('This connector has no owner; only an admin can modify it', 'FORBIDDEN', 403);
      return res.status(e.status).json(e.body);
    }
    return next();
  } catch (err) {
    logger.error({ err, id: m[1] }, 'connector null-owner guard probe failed');
    const e = apiError('Database operation failed', 'INTERNAL_ERROR');
    return res.status(e.status).json(e.body);
  }
});

require('./io')(router);

// Admin/editor health derive, registered before the CRUD catch-all so `/health`
// is not captured by the generic `/:id` GET (same ordering rule as io's
// `/import`).
require('./health')(router);

// Admin/editor allow-list read, registered before the CRUD catch-all so
// `/host-allowlist` is not captured by the generic `/:id` GET.
require('./host-allowlist')(router);

// Owner reassign (PATCH /:id/owner) — registered before the CRUD `/:id` so it
// is not shadowed by the factory's PUT/DELETE. Admin transfers any connector;
// the current owner transfers their own.
require('./reassign')(router);

// Clone (POST /:id/clone) — registered before the CRUD `/:id` so it is not
// shadowed by the factory's catch-all. Copies the source connector (encrypted
// secrets included, server-side) into a new owner-stamped row.
require('./clone')(router);

// Approval lifecycle (PATCH /:id/approve, /:id/reject) + the create/edit status
// middleware — registered before the CRUD `/:id` so the PATCH routes are not
// shadowed and the status stamp runs ahead of the factory's INSERT/UPDATE.
require('./approval')(router);
// The columns whose change re-pends this connector are declared beside the
// approval lifecycle they belong to, and read here — one list, not two.
const { SENSITIVE_SCALAR, SENSITIVE_JSON } = require('./approval');

// Attach `bindings: string[]` (the extra blueprint ids, sorted) to every
// list/detail connector row in one batched IN read. The per-row serializeRead
// has no connection, so the join lookup lives here (the attachOwnerNames
// precedent). A missing join table (an additive table the migration may have
// warn-skipped) yields `bindings: []`, never a 500.
async function attachConnectorBindings(conn, rows) {
  if (!rows.length) return;
  const ids = rows.map((r) => r.id).filter(Boolean);
  if (!ids.length) { for (const r of rows) r.bindings = []; return; }
  let joins = [];
  try {
    joins = await conn.query(
      `SELECT connector_id, blueprint_id FROM \`${t(TABLES.API_CONNECTOR_BLUEPRINTS)}\`
        WHERE connector_id IN (${ids.map(() => '?').join(', ')})`,
      ids,
    );
  } catch (err) {
    if (isMissingTable(err)) { for (const r of rows) r.bindings = []; return; }
    throw err;
  }
  const byConnector = new Map();
  for (const j of joins) {
    let arr = byConnector.get(j.connector_id);
    if (!arr) { arr = []; byConnector.set(j.connector_id, arr); }
    arr.push(j.blueprint_id);
  }
  for (const r of rows) r.bindings = (byConnector.get(r.id) || []).sort();
}

// Clearing the home while extras are still bound is refused, not silently
// written. An extra join row is meaningless without a home (a bundle member's
// "also usable in" set hangs off the home blueprint), so a PUT setting
// blueprint_id := null on a connector that still has extras would leave orphan
// join rows /usable would go on serving. Read-only pre-check: it only counts
// rows and refuses, so it is safe ahead of the ownership-scoped UPDATE — no
// write happens here. The rebind-to-an-existing-extra reconcile is NOT a
// pre-check: it is a DELETE, and a write must never precede the ownership gate,
// so it lives in the crud factory's postUpdateInTx hook (on the mount below),
// which runs only after the scoped UPDATE has matched a row and inside the same
// transaction. Tolerant of a missing join table (nothing bound → nothing to
// orphan).
router.use(async (req, res, next) => {
  if (req.method !== 'PUT' || req.path === '/import' || !req.body) return next();
  if (!Object.prototype.hasOwnProperty.call(req.body, 'blueprint_id')) return next();
  if (req.body.blueprint_id !== null && req.body.blueprint_id !== '') return next(); // an empty string clears the home the same as null
  const rowIdMatch = req.path.match(/^\/([^/]+)$/);
  if (!rowIdMatch) return next();
  try {
    // The write pool THIS request is about (a `db` override resolves to a Custom
    // API connection), matching where the CRUD update would write.
    const rwFacade = await resolveRwPool(req);
    let extraCount;
    try {
      const rows = await rwFacade.query(
        `SELECT COUNT(*) AS n FROM \`${t(TABLES.API_CONNECTOR_BLUEPRINTS)}\` WHERE connector_id = ?`,
        [rowIdMatch[1]],
      );
      extraCount = Number(rows[0] && rows[0].n) || 0;
    } catch (err) {
      // No join table on a no-DDL target → nothing is bound → nothing to orphan.
      if (isMissingTable(err)) return next();
      throw err;
    }
    if (extraCount > 0) {
      const e = apiError('Remove the other blueprints before clearing the home blueprint.', 'BINDING_HOME_BLUEPRINT', 400);
      return res.status(e.status).json(e.body);
    }
    return next();
  } catch (err) {
    // Fail-closed: an unverifiable binding state must not be written past.
    logger.error({ err, id: rowIdMatch[1] }, 'connector home-clear binding guard probe failed');
    const e = apiError('Database operation failed', 'INTERNAL_ERROR');
    return res.status(e.status).json(e.body);
  }
});

// A connector JOINING (or staying in) a bundle inherits the bundle's shared
// "also usable in" set — a bundle is coherent only if every member resolves to
// the same set. This read-only guard judges THIS connector's resulting config
// against that inherited set through the ONE shared binding-target decision
// (assertBindingTargets), so a join is held to the exact rules a bindings PUT
// or an import is: each inherited target must exist as a blueprint node, the
// caller must own or share it, and this connector's config must be complete for
// it and target no follower column. The row sync itself is a write and lives in
// the crud factory's postUpdateInTx hook (below), after the ownership-scoped
// UPDATE — nothing is written here, so this pre-check is safe ahead of the
// ownership gate. Fires when the body sets a non-empty group_id (a join or an
// in-group edit); missing join table → nothing is bound anywhere → next().
//
// The validated set is stashed on res.locals so the in-tx sync writes exactly
// what was judged here: between this read-only guard and the in-tx sync another
// writer could change the group's extras, and syncing that later, unvalidated
// set is the wider-set-than-the-gate-approved defect. postUpdateInTx re-reads
// the live set under the tx and refuses if it has moved.
router.use(async (req, res, next) => {
  if (req.method !== 'PUT' || req.path === '/import' || !req.body) return next();
  const groupId = req.body.group_id;
  if (typeof groupId !== 'string' || groupId === '') return next();
  const rowIdMatch = req.path.match(/^\/([^/]+)$/);
  if (!rowIdMatch) return next();
  const connectorId = rowIdMatch[1];
  // Committed to a group PUT: default the validated set to empty so a home-null
  // or missing-table early return still leaves the in-tx sync a set to match
  // against (both resolve to an empty live set, so an empty validated set is the
  // correct, safe answer).
  res.locals.validatedGroupSet = [];
  try {
    const rwFacade = await resolveRwPool(req);
    // Resulting home + configs: the body's value where it carries one, else the
    // stored row's — the same "a partial PUT says nothing about the halves it
    // omits" reasoning the bundle/follower guards above use.
    const stored = await rwFacade.query(
      `SELECT blueprint_id, request_config, response_config FROM \`${t(TABLES.API_CONNECTORS)}\` WHERE id = ?`,
      [connectorId],
    );
    if (!stored.length) return next(); // absent row → the CRUD path answers 404
    const home = (Object.prototype.hasOwnProperty.call(req.body, 'blueprint_id')
      && typeof req.body.blueprint_id === 'string' && req.body.blueprint_id !== '')
      ? req.body.blueprint_id
      : stored[0].blueprint_id;
    // A NULL-home connector is a group of one — no shared set to inherit.
    if (home == null) return next();

    // The group's binding set = the extras of the OTHER members sharing this
    // group_id AND this home (group_id is not blueprint-unique, so the home
    // scopes the bundle). This connector is excluded — it is synced TO the set,
    // not read FROM it — and the home is never itself in the set.
    let groupSet;
    try {
      const setRows = await rwFacade.query(
        `SELECT DISTINCT b.blueprint_id AS blueprint_id
           FROM \`${t(TABLES.API_CONNECTOR_BLUEPRINTS)}\` b
           JOIN \`${t(TABLES.API_CONNECTORS)}\` c ON c.id = b.connector_id
          WHERE c.group_id = ? AND c.blueprint_id = ? AND c.id <> ? AND b.blueprint_id <> ?`,
        [groupId, home, connectorId, home],
      );
      groupSet = setRows.map((r) => r.blueprint_id);
    } catch (err) {
      if (isMissingTable(err)) return next();
      throw err;
    }
    // Record the exact set that will be validated (sorted), so the in-tx sync
    // can prove the live set has not moved.
    res.locals.validatedGroupSet = [...groupSet].sort();
    if (!groupSet.length) return next();

    // THIS connector's resulting config, body overriding stored, judged against
    // each inherited target through the shared binding-target decision.
    const requestConfig = Object.prototype.hasOwnProperty.call(req.body, 'request_config')
      ? req.body.request_config
      : parseJsonConfigForGuard(stored[0].request_config);
    const responseConfig = Object.prototype.hasOwnProperty.call(req.body, 'response_config')
      ? req.body.response_config
      : stored[0].response_config;
    const member = { id: connectorId, request_config: requestConfig, response_config: responseConfig };

    const failure = await assertBindingTargets({ req, connector: member, targetIds: groupSet, conn: rwFacade });
    if (failure) {
      const e = apiError(failure.message, failure.code, failure.status, { details: failure.details });
      return res.status(e.status).json(e.body);
    }
    return next();
  } catch (err) {
    // Fail-closed, same posture as the guards above: an unverifiable bundle
    // join must not be written past silently.
    logger.error({ err, id: connectorId }, 'connector bundle-join binding guard probe failed');
    const e = apiError('Database operation failed', 'INTERNAL_ERROR');
    return res.status(e.status).json(e.body);
  }
});

// CREATE into a bundle that already carries extras is refused. A POST cannot
// run the postUpdateInTx group sync (that hook is update-only), so a create
// naming a group_id would land WITHOUT the bundle's shared extras — an
// incoherent member the coherence invariant would trip on the first edit.
// Read-only, fail-closed: resulting home = the body's blueprint_id; if the
// (group_id, home) group already has a non-empty shared extra set, refuse and
// tell the operator to create first, then add to the bundle (a PUT, which does
// sync). Group with no extras (a fresh bundle) or a no-DDL DB → next().
router.use(async (req, res, next) => {
  if (req.method !== 'POST' || req.path === '/import' || !req.body) return next();
  const groupId = req.body.group_id;
  if (typeof groupId !== 'string' || groupId === '') return next();
  // Resulting home is the create body's blueprint_id; an unbound create (no
  // home) is a group of one with no set to inherit.
  const home = (typeof req.body.blueprint_id === 'string' && req.body.blueprint_id !== '')
    ? req.body.blueprint_id : null;
  if (home == null) return next();
  try {
    const rwFacade = await resolveRwPool(req);
    let extras;
    try {
      const setRows = await rwFacade.query(
        `SELECT DISTINCT b.blueprint_id AS blueprint_id
           FROM \`${t(TABLES.API_CONNECTOR_BLUEPRINTS)}\` b
           JOIN \`${t(TABLES.API_CONNECTORS)}\` c ON c.id = b.connector_id
          WHERE c.group_id = ? AND c.blueprint_id = ? AND b.blueprint_id <> ?`,
        [groupId, home, home],
      );
      extras = setRows.map((r) => r.blueprint_id);
    } catch (err) {
      // No join table on a no-DDL target → nothing is bound → nothing to inherit.
      if (isMissingTable(err)) return next();
      throw err;
    }
    if (extras.length) {
      const e = apiError('Create the connector first, then add it to the bundle.', 'BINDING_GROUP_MISMATCH', 400);
      return res.status(e.status).json(e.body);
    }
    return next();
  } catch (err) {
    // Fail-closed: an unverifiable bundle state must not be written past.
    logger.error({ err, groupId }, 'connector bundle-create binding guard probe failed');
    const e = apiError('Database operation failed', 'INTERNAL_ERROR');
    return res.status(e.status).json(e.body);
  }
});

router.use('/', createCrudRoutes('api_connectors', {
  // owner_id is stamped to the creator on POST (every role, never NULL — so a
  // connector is never "shared"); editor PUT/DELETE is scoped to their own row.
  // `ownerColumn` strips owner_id from a NON-admin body only, so an
  // administrator's generic PUT could still hand this record to anybody —
  // through the CRUD factory, with none of what makes the dedicated transfer
  // endpoint safe: no check that the target exists, no check that they may hold
  // it, no resolution of the id to the spelling the column stores, and no audit
  // line, which is the only record a transfer happened at all. `immutableColumns`
  // is role-agnostic — the property this needs and the one `ownerColumn` does
  // not have — so a transfer has exactly one route.
  //
  // Scoped to the mounts that HAVE that route rather than made a property of
  // `ownerColumn` in the factory: flow_recipes declares `ownerColumn` and has no
  // dedicated owner endpoint, so a role-agnostic strip in the shared layer would
  // remove its only way to change a recipe's owner.
  //
  // AND WHAT THAT SCOPING THEREFORE LEAVES flow_recipes DOING, said out loud
  // because the sentence above named it as the reason without saying so: its
  // generic PUT IS a transfer route. The shared binding was given the other two
  // facts this endpoint establishes rather than left with only the first — it
  // resolves the target, refuses one whose role the mount would not let act on
  // the record, and writes a `feature_audit` row once the scoped UPDATE has
  // matched. So the difference between a mount with a dedicated endpoint and one
  // without is now the shape of the request, not what is checked or recorded.
  immutableColumns: ['owner_id'],
  ownerColumn: 'owner_id',
  // Editors may author connectors; plain users cannot (blanket gate above).
  allowedRoles: ['admin', 'editor'],
  // Editor create must bind to a blueprint they own or that is shared (NULL
  // owner). Admin bypasses; a null blueprint_id from an editor is rejected
  // (must bind on create). Mirrors blueprint_fields' single-hop chain.
  parentOwnership: {
    via: 'blueprint_id',
    chain: [{ table: TABLES.HIERARCHY_NODES, match: 'id', readOwner: 'owner_id' }],
  },
  // SECURITY: owner_id is deliberately NOT filterable — an editor must not be
  // able to enumerate "all connectors owned by user X" via ?owner_id=<uuid>.
  filterableColumns: ['blueprint_id', 'is_active'],
  resolveOwnerName: 'owner_id',
  // A deleted connector must not leave orphan "also usable in" rows. Runs in
  // the same delete transaction, keyed on the deleted connector id. Tolerant:
  // the join table is additive (its migration is severity 'warning'), so a
  // target DB that lacks it has nothing to orphan rather than a failed delete.
  tolerantDependentCleanup: [
    { table: TABLES.API_CONNECTOR_BLUEPRINTS, fk: 'connector_id' },
  ],
  // Batched read enrichment: every served connector row carries `bindings`.
  enrichRows: attachConnectorBindings,
  // A home rebind reconciles the extra set with the NEW home, INSIDE the update
  // transaction and only after the ownership-scoped UPDATE has matched a row — so
  // a PUT the factory refuses (a non-owner's, an invalid enum value) deletes
  // nothing at all, and the reconcile and the home change commit or roll back as
  // one. The editor points the connector at home B and its multi-select already
  // excludes the home, so if B was already an extra the row would carry B twice
  // (once as home, once as a join row); after this UPDATE the home IS B, so any
  // join row equal to B is invalid by the one-home invariant — delete it with no
  // stored-vs-new compare. `gatedData` holds only the columns actually persisted,
  // so on a lagging schema that dropped blueprint_id the key is simply absent and
  // the reconcile skips. A missing join table (additive, migration severity
  // 'warning') means nothing is bound → nothing to reconcile; any other error
  // throws and the factory rolls the whole update back.
  //
  // A group join additionally SYNCS this connector's join rows to the bundle's
  // shared set (validated read-only by the bundle-join guard above), inside the
  // same transaction. The set is the OTHER members' extras (this row excluded —
  // it is synced TO them) and never contains the home, so the order is: reconcile
  // the home first, then replace this row's set with the group's. `group_id` is
  // read from `gatedData` (the persisted columns), so a body that did not set it
  // leaves the group sync inert. Missing join table → skip both; any other error
  // rolls the whole update back.
  postUpdateInTx: async (conn, req, gatedData) => {
    const homeIsSet = typeof gatedData.blueprint_id === 'string' && gatedData.blueprint_id !== '';
    const groupIsSet = typeof gatedData.group_id === 'string' && gatedData.group_id !== '';
    if (!homeIsSet && !groupIsSet) return;
    try {
      // Home reconcile: after the UPDATE the home IS gatedData.blueprint_id, so
      // any join row equal to it is invalid by the one-home invariant.
      if (homeIsSet) {
        await conn.query(
          `DELETE FROM \`${t(TABLES.API_CONNECTOR_BLUEPRINTS)}\` WHERE connector_id = ? AND blueprint_id = ?`,
          [req.params.id, gatedData.blueprint_id],
        );
      }
      // Group sync: replace this connector's set with the bundle's shared set.
      if (groupIsSet) {
        // The committed home scopes the bundle (group_id is not blueprint-unique).
        let home = homeIsSet ? gatedData.blueprint_id : null;
        if (home == null) {
          const hr = await conn.query(
            `SELECT blueprint_id FROM \`${t(TABLES.API_CONNECTORS)}\` WHERE id = ?`,
            [req.params.id],
          );
          home = hr.length ? hr[0].blueprint_id : null;
        }
        // A NULL-home connector is a group of one — nothing to sync to.
        let groupSet = [];
        if (home != null) {
          const setRows = await conn.query(
            `SELECT DISTINCT b.blueprint_id AS blueprint_id
               FROM \`${t(TABLES.API_CONNECTOR_BLUEPRINTS)}\` b
               JOIN \`${t(TABLES.API_CONNECTORS)}\` c ON c.id = b.connector_id
              WHERE c.group_id = ? AND c.blueprint_id = ? AND c.id <> ? AND b.blueprint_id <> ?`,
            [gatedData.group_id, home, req.params.id, home],
          );
          groupSet = setRows.map((r) => r.blueprint_id);
        }
        // The set must be the one the read-only bundle-join guard validated
        // THIS connector's config against. Between that guard and this in-tx
        // read another writer could have changed the group's shared extras;
        // syncing that later set now would persist a set this connector was
        // never judged against — the wider-set-than-the-gate-approved defect.
        // Compare the live set (sorted) to the validated set and refuse on any
        // difference. Throwing propagates to the crud factory's outer catch,
        // which rolls the whole update back — no INSERT, no home change. NOTE:
        // the factory does not preserve a thrown error's status (its catch maps
        // everything but a 1062/1213/1205 driver code to INTERNAL_ERROR), so
        // this rare conflict window surfaces as 500, not 409 — an honest 500
        // rather than a 409 dressed up as a deadlock.
        const liveSorted = [...groupSet].sort();
        const validated = req.res && req.res.locals && Array.isArray(req.res.locals.validatedGroupSet)
          ? req.res.locals.validatedGroupSet : [];
        if (liveSorted.length !== validated.length || liveSorted.some((id, i) => id !== validated[i])) {
          const mismatch = new Error('bundle group set changed between validation and in-tx sync');
          mismatch.code = 'BINDING_GROUP_MISMATCH';
          throw mismatch;
        }
        // Replace: drop this row's set, then insert the group's (empty set — a
        // group of one, or a brand-new group — just clears it).
        await conn.query(
          `DELETE FROM \`${t(TABLES.API_CONNECTOR_BLUEPRINTS)}\` WHERE connector_id = ?`,
          [req.params.id],
        );
        for (const bpId of groupSet) {
          await conn.query(
            `INSERT INTO \`${t(TABLES.API_CONNECTOR_BLUEPRINTS)}\` (id, connector_id, blueprint_id) VALUES (UUID(), ?, ?)`,
            [req.params.id, bpId],
          );
        }
      }
    } catch (err) {
      if (isMissingTable(err)) return;
      throw err;
    }
  },
  // THE DOMAIN IS THE TABLE'S, ASKED OF THE DDL — not a list of columns kept
  // here. `enumColumnsFor` answers for EVERY ENUM column the table declares, so
  // this mount cannot be missing one: the failure a per-column list produces is
  // not a wrong value but an omitted column, and `auth_type` was exactly that
  // omission. Without a domain, `PUT {"auth_type":"Bearer"}` reached the
  // serializer, which resolved no sensitive leaf for that spelling, stripped the
  // token the column was about to keep as `'bearer'`, and wrote `{}` over the
  // stored ciphertext with a 200.
  //
  // REFUSING THE SPELLING IS STRICTLY BETTER THAN FOLDING IT. The engine stores
  // `'Bearer'`, `'BEARER'`, `'bearer '` and the ordinal `2` as the one member
  // `'bearer'`; canonicalising them here would make this request work and leave
  // every later reader still comparing against a value the caller chose. The
  // caller sends what the column stores.
  enumColumns: enumColumnsFor(TABLES.API_CONNECTORS),
  serializeWrite,
  // The serializer resolves "a `****` leaf means unchanged" by reading the
  // stored ciphertext back and binding it — a decision about the row this
  // statement is about to update, which was being taken on `pool.ro`: another
  // pool, another connection, no transaction and no lock. It now runs inside the
  // update transaction and takes the row `FOR UPDATE`.
  serializeWriteInTx: true,
  // SECURITY: a change to where, how or with what credential shape this
  // connector connects clears its approval, inside the same transaction and the
  // same statement as the change itself. NULL is on the list of states this
  // fires from, and that is the row it closes: NULL means grandfathered =
  // dispatches, so an editor could re-point a grandfathered connector at a new
  // endpoint and it went on dispatching with no review at all. Which states
  // re-pend is review-status.js's answer, not this mount's.
  repandOnSensitiveChange: {
    statusCol: 'status',
    clearCols: ['approved_by', 'approved_at'],
    columns: SENSITIVE_SCALAR,
    jsonColumns: SENSITIVE_JSON,
  },
  serializeRead,
}));

module.exports = router;
