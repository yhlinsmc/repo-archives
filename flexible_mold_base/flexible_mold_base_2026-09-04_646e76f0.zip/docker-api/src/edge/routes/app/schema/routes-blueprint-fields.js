const {
  TABLES,
  VARIANT_OVERRIDE_ACTIONS,
  pool,
  t,
  getDynamicPool,
  apiOk,
  apiError,
  requireAuth,
  requireAdmin,
  requireAdminOrEditor,
  isOwnerOrAdmin,
  uuidv4,
  UUID_RE,
  mapRowFromDb,
  mapRowsFromDb,
  mapRowToDb,
  previewCascade,
  cascadeDeleteNode,
  collectDescendantIds,
  tableExistsInCurrentSchema,
  buildVariantOverrideUpdateExistsClause,
  buildVariantOverrideInsertExistsClause,
  buildDuplicateActionTripleNotExistsClause,
  applyOwnerChange,
  enrichOwnerNames,
  validateComputeRule,
  validateTableColumnComputeRules,
  parseStoredRule,
  canonicalRuleJson,
  judgeComputeRulePostState,
  loadBlueprintComputeState,
  loadBlueprintFieldScopes,
  loadVariantComputeRulesByVariant,
  loadVariantCellTargetsByVariant,
  blueprintRuleClosesCycle,
  hasRowContextSource,
  invalidChoiceConfigShape,
  scopeNamesSingleColumn,
  resolveAncestors,
  restampTemplates,
  countAffectedTemplates,
  isValidBlueprintParent,
  logger,
  HIERARCHY_OWNER_AUDIT_EVENT,
  USER_TEMPLATE_OWNER_AUDIT_EVENT,
  resolveOwnershipRwPool,
  cascadeBlueprintOwnerToVariants,
  SAFE_COL_RE,
  isSafeColumnName,
  SLUG_KEY_PATTERN,
  isValidSlugKey,
  isBlueprintLinked,
  isBlueprintLinkedLocked,
  isLinkedParentLocked,
  linkTargetOf,
  storedNodeId,
  refuseLinkColumnShape,
  effectiveLinkValue,
  auditSchemaClearFailed,
  validateLinkConstraints,
  resolveLinkCheckBlueprintId,
  _columnSetCache,
  getConnDatabaseName,
  getActualColumnSet,
  _historyTableCache,
  isCodeVersionHistoryAvailable,
  gateKeysByColumnSet,
  TABLE_VALUES,
  validateCodeVersioning,
  isMissingTableOrColumn,
  _codeVersioningDegraded,
  warnCodeVersioningDegradedOnce,
  validateAndPrepareParentOwnership,
  validateAndPrepareParentRepend,
  buildChainSelectSql,
  buildChainExistsForRow,
  ENCRYPTION_GATE_422,
  runSerializeWrite,
  editorMayWriteBlueprint,
  checkBlueprintWriteTarget,
  storedRowId,
  MAX_BATCH_FIELD_IDS,
  MAX_BATCH_BLUEPRINT_IDS,
} = require('./helpers');
const {
  checkValueSourcePayload, modeAfterPayloadClear, MODE_OWNED_COLUMNS,
} = require('../../../../shared/field-value-source');
const {
  invalidOptionsSourceShape, invalidTableConfigColumnOptionsSourceShape, optionsSourceDependsOnFieldKeyConflict,
} = require('../../../../shared/options-source-validate');
const { deriveWritten, sameStoredValue } = require('./write-value');
const { fieldTypeViolation, resolveStoredFieldType } = require('./field-type-domain');
const { fieldKeyViolation, fieldKeyTaken, FIELD_KEY_TAKEN } = require('./field-key');
const { UUID_CHAR_LENGTH, identifierFloorViolation } = require('./identifier-floor');
const { charColumnsFor } = require('../../../lib/schema-manifest');
const {
  SAFE_JSON_PATH_RE, fieldKeyReferencesPresentIn, UNREWRITABLE_KEY_REFERENCE_SITES,
} = require('../../../lib/blueprint-field-key-references');
const { writeConflictError } = require('./crud-factory');

// The identifier columns of this table, read from the DDL at require time the
// way the factory reads its own — a hand-kept list here would be a second source
// of truth about which columns hold identifiers, and the first FK column added
// to blueprint_fields would be admitted with no shape check and nothing would
// say so.
const FIELD_IDENTIFIER_COLUMNS = charColumnsFor(TABLES.BLUEPRINT_FIELDS, UUID_CHAR_LENGTH);
if (FIELD_IDENTIFIER_COLUMNS === null) {
  // Same failure mode the factory takes: a gate that cannot read its own domain
  // must not serve a request, so the module does not load.
  throw new Error(
    `[identifierColumns]: table-ddls.js declares no table '${TABLES.BLUEPRINT_FIELDS}', so which `
    + 'of its columns hold identifiers cannot be derived — this gate does not guess',
  );
}


/**
 * One statement per reference site: repoint every OTHER field's reference to
 * the field being renamed, scoped to the blueprint.
 *
 * MATCHED WITH `BINARY`, NOT UNDER THE COLUMN'S COLLATION, and the sibling
 * cascade on `blueprint_groups` matches the other way for a reason that does not
 * carry over. There, a case-only rename is a thing an operator deliberately asks
 * for — normalising a legacy `Lane_A` to `lane_a` — so every field sitting in
 * the lane has to come along whatever case its own column holds. Here the
 * question is different: what resolves one of these references is a JavaScript
 * reader doing an exact string lookup against the field list, so a reference
 * spelling the key with different capitalisation already resolves to nothing.
 * Rewriting it under a case-insensitive comparison would not repair a broken
 * reference — it would create a link the form never had. (The uniqueness probe
 * this handler runs earlier asks the INDEX's question about the same column and
 * therefore compares the index's way, on purpose.)
 *
 * The JSON form's `JSON_VALID` guard is the same one the orphan repair uses: a
 * JSON function applied to text MariaDB cannot parse answers NULL, which would
 * replace an unreadable rule with no rule at all. The `JSON_EXTRACT ... =`
 * predicate also keeps `JSON_SET` off every row that holds no such reference —
 * without it JSON_SET would CREATE the path, giving every field in the
 * blueprint a visibility rule nobody wrote.
 *
 * NEITHER THROW BELOW IS REACHABLE FROM A REQUEST, and that is why they are
 * cheap: `site` only ever comes from the frozen declaration in
 * blueprint-field-key-references.js, never from a caller. They guard a
 * DECLARATION EDIT, not an injection: only `${table}` and `${col}` are
 * interpolated, and the JSON path is BOUND like any other parameter — MariaDB
 * accepts a bound path, which is why the statement works at all. So the column
 * whitelist is the injection barrier and `SAFE_JSON_PATH_RE` is a shape check:
 * a path declared in some other form still reaches the engine safely, it simply
 * matches nothing, and a cascade that silently repairs nothing is the failure
 * mode this whole module exists to end. Failing at the first call is how that
 * edit is noticed. Do not go looking for the test that covers them; there is
 * none to write without editing the declaration.
 *
 * THE ADDRESSED ROW IS EXCLUDED ONLY AT A SITE THIS REQUEST WROTE, and the
 * narrowness is the whole point of the predicate. The rule is that a statement
 * must not overrule a value its own request wrote: the UPDATE above the call
 * runs first, so on a body that sets this field's own reference to the key it is
 * renaming away from, the repair would replace what the operator just sent —
 * they write `old_key` and the column ends up holding `new_key`.
 *
 * A SITE THE REQUEST DID NOT NAME IS A REFERENCE LIKE ANY OTHER AND FOLLOWS THE
 * RENAME. Skipping it there is not caution, it breaks the row: the field's own
 * reference resolved before the rename and would not after, and the two sites do
 * not degrade the same way when a reference resolves to nothing.
 *
 *   depends_on_field_key  a parent that is gone is IGNORED — the select shows
 *                         every option, which an operator can act on.
 *   visibility_rule       a subject that is gone is not ignored. The evaluator
 *                         reads the absent key as `''`, the condition compares
 *                         false, and the field joins the hidden set — with no
 *                         key anywhere to give it a value, permanently.
 *
 * So leaving the addressed row alone at a site nobody asked about can hide a
 * field for good. `exceptFieldId` is therefore null at such a site, and the
 * CLAUSE IS OMITTED rather than bound with null: `id <> NULL` is UNKNOWN for
 * every row, so a bound null would match nothing at all and silently turn the
 * whole statement off — the same trap the field-key clash probe documents.
 */
function buildReferenceRenameUpdate(site, oldKey, newKey, blueprintId, exceptFieldId) {
  if (!isSafeColumnName(site.column)) {
    throw new Error(`[rename]: ${site.column} fails column whitelist`);
  }
  const table = `\`${t(TABLES.BLUEPRINT_FIELDS)}\``;
  const col = `\`${site.column}\``;
  const excludes = exceptFieldId != null;
  const exclusion = excludes ? '\n           AND id <> ?' : '';
  const exclusionParam = excludes ? [exceptFieldId] : [];
  if (site.path === null) {
    return {
      sql: `UPDATE ${table}
           SET ${col} = ?
         WHERE blueprint_id = ?${exclusion}
           AND ${col} = BINARY ?`,
      params: [newKey, blueprintId, ...exclusionParam, oldKey],
    };
  }
  if (!SAFE_JSON_PATH_RE.test(site.path)) {
    throw new Error(`[rename]: ${site.column} declares an unusable JSON path`);
  }
  return {
    sql: `UPDATE ${table}
         SET ${col} = JSON_SET(${col}, ?, ?)
       WHERE blueprint_id = ?${exclusion}
         AND JSON_VALID(${col})
         AND JSON_UNQUOTE(JSON_EXTRACT(${col}, ?)) = BINARY ?`,
    params: [site.path, newKey, blueprintId, ...exclusionParam, site.path, oldKey],
  };
}


// ── blueprint_fields type-change cleanup ───────────────────────────────
//
// Custom PUT handler for `/blueprint_fields/:id` that runs BEFORE the
// generic CRUD factory mount below. When the user changes a field's
// `field_type`, the row's type-specific side-data must be cleared in the
// same transaction or it leaks into the new type's surface area:
//
//   select → field_options rows (separate table)   → DELETE
//   table  → table_config JSON column on this row  → UPDATE NULL
//
// Inconsistent payloads (e.g. `field_type=text` + non-null `table_config`)
// are rejected 400 INCONSISTENT_FIELD_PAYLOAD so import / direct API
// calls cannot bypass the cleanup. Audit row blueprint.field.type_changed
// records the cleanup so silent data-loss has a forensic trail.
//
// Frontend (FieldEditor.tsx) confirms the destructive change via Radix
// AlertDialog with the count of options that will be deleted.
// SECURITY: blueprint_fields writes build their column list from the request
// body, so a blueprint-level compute_rule would otherwise be persisted verbatim.
// This is the structural floor — the value must be a JSON object at all — that
// holds on every write path including the generic create; rule semantics (op,
// operand types, source existence, dependency cycles) are validated where the
// blueprint context needed to judge them is available.
// Accepts the serialized form too: the custom PUT below validates AFTER
// mapRowToDb has stringified the JSON columns (mirrors invalidChoiceConfigShape).
function invalidComputeRuleShape(rule) {
  if (rule == null) return false;
  let parsed = rule;
  if (typeof parsed === 'string') {
    try { parsed = JSON.parse(parsed); } catch { return true; }
    if (parsed == null) return false;
  }
  return typeof parsed !== 'object' || Array.isArray(parsed);
}

// `options_source` structural floor (shape + input_bindings + the Q1
// mutual-exclusion rule against depends_on_field_key) now lives in
// `shared/options-source-validate.js` — imported above — because the JSON
// import guard judges the same document under the same rules and must not
// carry a second copy of this logic.

/**
 * Read a JSON column that may already have been stringified by mapRowToDb.
 * Returns null for anything that is not an object — the shape floors above and
 * below report those; this one only has to decide "is there a document here".
 */
function parseJsonColumn(value) {
  let parsed = value;
  if (typeof parsed === 'string') {
    try { parsed = JSON.parse(parsed); } catch { return null; }
  }
  return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : null;
}

/**
 * Is the row this write is about to leave behind incoherent?
 *
 * WHY A SECOND CHECK, after the write rather than before it. `isPayloadInconsistent`
 * reads the request BODY, and on a partial PUT the body is not the row. A body of
 * `{value_source: 'entered'}` says nothing about `compute_rule`, so the body-level
 * check reads the absent column as null and passes — while the UPDATE names only
 * `value_source` and leaves the stored rule exactly where it was. The row then
 * says 'entered' over a rule the resolver will not run, and the next full save is
 * refused for a state no request ever asked for. That is the same defect as the
 * type-change clear, arrived at from the other side, and patching each shape as
 * it is found is how it keeps coming back.
 *
 * So the thing that is validated is the ROW. Reading it back is not an extra
 * round trip: the handler already refreshes it for the response, and this runs on
 * that read, inside the transaction, so a refusal rolls back. Every column is
 * present in a row, which is what makes the body-shaped checks exact here — there
 * is no absent key to interpret.
 *
 * WHAT IT DOES NOT DO: it does not run when the row is missing a mode-owned
 * column. On a DB whose operator could not add one, that column is gated out of
 * every write, so a row can hold a mode whose payload column does not exist to
 * carry its argument — refusing that would make the field permanently unsaveable
 * on exactly the DB that can least afford it. It also does not say WHICH write
 * produced the incoherence, only that the result is one, and it cannot see a row
 * some other statement made incoherent without touching this one.
 *
 * @param {object|undefined} row the refreshed row, straight from the DB
 * @returns {{code: string, detail: string}|null}
 */
function postStateInconsistent(row) {
  if (!row || typeof row !== 'object') return null;
  const has = (key) => Object.prototype.hasOwnProperty.call(row, key);
  if (!has('value_source') || !MODE_OWNED_COLUMNS.every(has)) return null;
  return checkValueSourcePayload(row, {
    fieldType: row.field_type,
    parseRule: parseJsonColumn,
  });
}

/**
 * @param {string} newType effective field_type after this write
 * @param {object} payload the columns this write will actually name
 * @param {{modeColumnPresent?: boolean, mergedOptionsSource?: unknown,
 *   mergedDependsOnFieldKey?: unknown}} [opts] `modeColumnPresent: false` on a
 *   database whose operator could not add `value_source`. The mode/payload
 *   agreement rule is then not merely unenforceable but INAPPLICABLE — there is
 *   no mode column for a payload to be orphaned from — and applying it anyway
 *   would refuse every compute rule on exactly the databases that cannot repair
 *   themselves. `value_scope` shipped in the same migration entry as
 *   `value_source`, so a database missing one is missing both and no scope
 *   document goes unjudged by the skip.
 *   `mergedOptionsSource`/`mergedDependsOnFieldKey` default to the BODY value
 *   (`payload.options_source`/`payload.depends_on_field_key`) — correct for
 *   the generic create path, where there is no stored row to merge against
 *   and the body IS the row-to-be. The custom PUT passes its own merge (see
 *   the call site) because there a partial body can leave one side of Q1
 *   entirely to the stored row.
 */
function isPayloadInconsistent(newType, payload, {
  modeColumnPresent = true,
  mergedOptionsSource = payload.options_source,
  mergedDependsOnFieldKey = payload.depends_on_field_key,
} = {}) {
  if (invalidComputeRuleShape(payload.compute_rule)) {
    return { ok: false, code: 'INCONSISTENT_FIELD_PAYLOAD', detail: 'compute_rule must be a rule object or null' };
  }
  // options_source structural floor — mirrors invalidComputeRuleShape above:
  // proves the value is a well-formed field/connector source object, never
  // WHAT it points at (does source_field_key name a live field? does
  // connector_id name a live connector? — that needs the blueprint context
  // this body-shaped floor does not have, so it stays OPT-E2, same split as
  // validateComputeRuleBeforeWrite below). Unknown top-level keys fall
  // closed rather than being ignored, so a config an operator believes is
  // active is never silently narrowed by a typo'd key.
  if (invalidOptionsSourceShape(payload.options_source)) {
    return {
      ok: false,
      code: 'INCONSISTENT_FIELD_PAYLOAD',
      detail: "options_source must be null or an object of shape { type: 'field', source_field_key, column?, filter? } "
        + "or { type: 'connector', connector_id, output_id, input_bindings?, filter? } with no other keys",
    };
  }
  // Q1 mutual exclusion (parse-options-source.ts `validateOptionsSourceAgainstField`):
  // a field cannot carry both a dynamic source and a static cascade parent.
  // Judged on the MERGED written state, not the raw body: a partial PUT that
  // only names one of the two columns still produces a real row, and if the
  // STORED other side is already the opposite non-null value, this write
  // creates the forbidden combo just as surely as a body naming both would.
  // The caller supplies the merge (`mergedOptionsSource`/
  // `mergedDependsOnFieldKey` — default to the body value, which is exactly
  // right on the generic create path where there is no stored row).
  if (optionsSourceDependsOnFieldKeyConflict(mergedOptionsSource, mergedDependsOnFieldKey)) {
    return {
      ok: false,
      code: 'INCONSISTENT_FIELD_PAYLOAD',
      detail: 'a field cannot carry both options_source and depends_on_field_key',
    };
  }
  // The mode and the columns it is the mode OF have to be written together, or
  // a stored 'calculated' outlives the rule it was calculated by. Checked on the
  // body alone (see the module doc on field-value-source.js), so it holds
  // identically on the generic create and on this partial PUT.
  // `hasScope` is deliberately NOT overridden: the default reading already
  // accepts the serialized form this payload arrives in, and a second
  // hand-written copy of "does this scope narrow anything" is the drift the
  // stored-mode model exists to remove.
  const sourceIssue = modeColumnPresent
    ? checkValueSourcePayload(payload, {
      fieldType: newType,
      parseRule: parseJsonColumn,
    })
    : null;
  if (sourceIssue) {
    return { ok: false, code: sourceIssue.code, detail: sourceIssue.detail };
  }
  if (newType !== 'table' && payload.table_config != null) {
    return { ok: false, code: 'INCONSISTENT_FIELD_PAYLOAD', detail: `field_type='${newType}' must not carry table_config` };
  }
  // Codex P2 (round 2, OPT-E3): the column-level twin of the options_source
  // shape check above, for a `table`-type field's own `table_config.columns
  // [i].options_source`. This function is shared by the custom PUT AND the
  // generic create's `serializeWrite` (see the caller-site comment), so one
  // check guards both write paths — a direct table-field write (either
  // route) previously persisted a malformed column source unchecked; only
  // the YAML parse path (fix-batch L2) caught it.
  if (invalidTableConfigColumnOptionsSourceShape(payload.table_config)) {
    return {
      ok: false,
      code: 'INCONSISTENT_FIELD_PAYLOAD',
      detail: "table_config.columns[].options_source must be null or an object of shape "
        + "{ type: 'field', source_field_key, column?, filter? } or { type: 'connector', connector_id, output_id, input_bindings?, filter? } "
        + 'with no other keys',
    };
  }
  if (newType !== 'checkbox' && payload.choice_config != null) {
    return { ok: false, code: 'INCONSISTENT_FIELD_PAYLOAD', detail: `field_type='${newType}' must not carry choice_config` };
  }
  if (newType === 'checkbox' && invalidChoiceConfigShape(payload.choice_config)) {
    return { ok: false, code: 'INCONSISTENT_FIELD_PAYLOAD', detail: 'choice_config must be { minSelected?, maxSelected? } integers with 0 <= min <= max and max >= 1' };
  }
  return { ok: true };
}

/**
 * SECURITY: the semantic half of compute_rule validation for the generic CRUD
 * create, wired in as the factory's in-transaction pre-write hook.
 *
 * `isPayloadInconsistent` (the mount's serializeWrite) is only a structural
 * floor — it proves the value is a rule object. Everything that makes a rule
 * MEAN something (a known op, operands of the right shape, sources that exist,
 * no dependency cycle) needs the blueprint's other fields to judge, which is
 * exactly what this hook has a connection for. Without it a rule the custom PUT
 * would reject — a self-reference is enough — lands in the column in one
 * request, and the next legitimate write anywhere in that blueprint loads it,
 * detects the cycle, and refuses an edit that has nothing wrong with it.
 *
 * Runs inside the factory's write transaction and AFTER its ownership gate, so
 * a rejection rolls back cleanly and never reveals the shape of a blueprint the
 * caller may not read. The factory calls the same hook on its generic PUT; for
 * this table that PUT is shadowed by the custom handler above, and a
 * PATCH-style body without blueprint_id has no graph to be judged against, so
 * the hook simply passes.
 *
 * @returns {Promise<{message: string, code: string, status: number}|null>}
 */
async function validateComputeRuleBeforeWrite(conn, req, data) {
  // THE RULE THIS JUDGES IS THE ONE THE STATEMENT WILL STORE, and the blueprint
  // it is judged against is the one the statement will store it under. `data`
  // is that object. Reading `req.body` instead would resolve a blueprint the
  // write may not carry — the factory strips the parent FK from a non-admin
  // update — and validate a graph the row will never join. That the two happen
  // to coincide on this mount today (its PUT is shadowed by the custom handler
  // above, and nothing strips these columns on create) is a fact about today's
  // wiring, not a property of the guard.
  const write = data || {};
  // Only a write that actually carries a rule — the field-level compute_rule,
  // or a table_config with per-column rules inside it — needs judging:
  // clearing either removes edges and can never close a cycle or reference
  // something missing.
  if (write.compute_rule == null && write.table_config == null) return null;
  const blueprintId = write.blueprint_id;
  const targetFieldKey = write.field_key;
  if (!blueprintId || typeof targetFieldKey !== 'string' || !targetFieldKey) return null;
  // A DB that warn-skipped the additive column gates compute_rule out of the
  // INSERT the factory is about to build, so the FIELD-level half below has
  // nothing to validate on such a DB — and rejecting here would make create
  // stricter than update on that same DB. table_config carries no such gate
  // (it predates the additive compute_rule column), so the column-rule half
  // further down is judged regardless of this probe.
  const colSet = await getActualColumnSet(conn, t(TABLES.BLUEPRINT_FIELDS));
  const computeRuleColumnPresent = colSet === null || colSet.has('compute_rule');
  // The DTO mapper stringifies this JSON column on the way to the statement, so
  // the value here can be either shape; parseStoredRule takes both.
  const incomingRule = computeRuleColumnPresent ? parseStoredRule(write.compute_rule) : null;
  // Nothing left to judge: the field-level half is gated out by the missing
  // column, and there is no table_config either. Bail before opening the
  // blueprint scan — the same "on a DB that warn-skipped the additive
  // column, create must not be stricter than update" reasoning above, now
  // also covering the case the original top-of-function guard used to catch
  // on its own before this function had a second thing to judge.
  if (!computeRuleColumnPresent && write.table_config == null) return null;

  const { fieldKeys, tableColumns, rules } = await loadBlueprintComputeState(
    conn, blueprintId, { t, TABLES },
  );
  // The row does not exist yet, so its key is new to the graph; a rule naming it
  // is a self-reference, which is a cycle rather than a missing source.
  fieldKeys.add(targetFieldKey);

  // Column-level rules (table_config.columns[].rules.compute_rule) are judged
  // independently of the field-level rule below — a 'table' field's own
  // compute_rule (narrowed to one column via value_scope) and its per-column
  // rules are two different mechanisms occupying two different columns, and
  // a create can carry either without the other. The owner table's own
  // columns come from THIS incoming table_config, not any stored row —
  // there is no stored row yet, so `tableColumns` (built by the scan above)
  // has no entry for `targetFieldKey` to be stale against, but
  // `validateTableColumnComputeRules` sets one from `write.table_config`
  // regardless, for the same reason the update-path call does.
  if (write.table_config != null) {
    const columnRuleResult = validateTableColumnComputeRules(write.table_config, {
      fieldKeys, tableColumns, ownerFieldKey: targetFieldKey,
    });
    if (!columnRuleResult.ok) {
      return {
        message: `table_config column '${columnRuleResult.columnKey}': ${columnRuleResult.detail || columnRuleResult.code}`,
        code: columnRuleResult.code,
        status: 400,
      };
    }
  }

  if (!incomingRule) return null; // no field-level rule to judge; structural floor already rejected a malformed one
  // NOTE: only 'number' fields are numeric; every other field_type maps to
  // 'string'. A new numeric field_type must be added here explicitly.
  // C1: a `same_table_column` term is only ever runnable on a write narrowed
  // to a column of this row's OWN `value_scope` — the same document this
  // create is about to store, read straight off `write` (the row the
  // statement will write, per the doc-block above `data` is bound from).
  // P2: EXACTLY one column, not merely "names a column" — see
  // `scopeNamesSingleColumn`'s doc-block.
  const ruleResult = validateComputeRule(incomingRule, {
    fieldKeys,
    targetType: write.field_type === 'number' ? 'number' : 'string',
    tableColumns,
    ownerFieldKey: targetFieldKey,
    narrowedToColumn: scopeNamesSingleColumn(write.value_scope),
  });
  if (!ruleResult.ok) {
    return { message: ruleResult.detail || ruleResult.code, code: ruleResult.code, status: 400 };
  }
  // P1b: the blueprint-wide narrowing context the column-cycle check needs —
  // every OTHER field's stored `value_scope`, with this new row's own
  // (about-to-be-written) scope standing in for a field the scan cannot see
  // yet. Only fetched when a column-level cycle is even POSSIBLE — this
  // incoming rule reads a same-table column, or some other field in the
  // blueprint already does — the same short-circuit `blueprintRuleClosesCycle`
  // applies to its own per-variant pass, one layer up: a blueprint with no
  // `same_table_column` rule anywhere can never close a column cycle, so
  // every ordinary (field-level-only) write pays nothing extra.
  const mayHaveColumnCycle = hasRowContextSource(incomingRule)
    || [...rules.values()].some(hasRowContextSource);
  let narrowingByFieldKey = null;
  if (mayHaveColumnCycle) {
    const scopesByFieldKey = await loadBlueprintFieldScopes(conn, blueprintId, { t, TABLES });
    narrowingByFieldKey = new Map(scopesByFieldKey ?? []);
    narrowingByFieldKey.set(targetFieldKey, write.value_scope);
  }
  const cycleResult = await blueprintRuleClosesCycle(conn, {
    blueprintId, targetFieldKey, incomingRule, blueprintRules: rules, narrowingByFieldKey, t, TABLES,
  });
  if (cycleResult.fieldCycle) {
    return { message: 'compute_rule introduces a dependency cycle', code: 'cycle', status: 400 };
  }
  if (cycleResult.columnCycle) {
    return {
      message: 'compute_rule introduces a same-table column dependency cycle',
      code: 'same_table_column_cycle',
      status: 400,
    };
  }
  return null;
}

function register(router) {

router.put('/blueprint_fields/:id', async (req, res) => {
  if (!requireAdminOrEditor(req, res)) return;
  const fieldId = req.params.id;
  // A blueprint_fields row belongs to its parent blueprint; editor may
  // only PUT the field if the parent blueprint's owner_id is NULL or
  // matches them. Admin always passes.
  // Implemented with an extra SELECT below the existing old-row read.
  let data = { ...req.body };
  // Capture the per-request `db` override before stripping it from the
  // column list, so multi-schema CUSTOM_API requests hit the schema
  // selected by the middleware instead of the module-default `pool.rw`.
  const dynamicDb = data.db;
  delete data.id;
  delete data.db;

  // Coerce via DTO mapper (same path the generic factory uses).
  data = mapRowToDb('blueprint_fields', data);

  const updateKeys = Object.keys(data).filter(isSafeColumnName);
  if (!updateKeys.length) {
    const e = apiError('No valid fields to update', 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }

  let conn;
  try {
    if (dynamicDb) {
      const dynamicPool = await getDynamicPool(dynamicDb);
      conn = await dynamicPool.rw.getConnection();
    } else {
      conn = await pool.rw.getConnection();
    }
    await conn.beginTransaction();

    // Probe the actual column set BEFORE building the old-row SELECT.
    // In operator-mode the `ADD COLUMN depends_on_field_key` migration may
    // have been warn-skipped (privilege errno 1142); naming an absent column
    // in the SELECT throws ER_BAD_FIELD_ERROR (1054) and 500s the route.
    // probe-null (unknown set) keeps the column so normal-mode SELECTs are
    // byte-identical. The same colSet is reused for the UPDATE gate — no
    // second probe.
    const colSet = await getActualColumnSet(conn, t(TABLES.BLUEPRINT_FIELDS));
    const hasDependsCol = colSet === null || colSet.has('depends_on_field_key');
    // The stored mode is read for one reason: the post-write cleanup below can
    // clear this row's compute_rule, and a payload column cleared without its
    // mode is the incoherent row the write boundary refuses on every other path
    // (see modeAfterPayloadClear). Same additive-column gate as the rest.
    const hasModeCol = colSet === null || colSet.has('value_source');
    // P1a: the row's PRE-write value_scope — the post-state pass needs it to
    // judge the WRITTEN field's own "before" state on its own actual scope,
    // not the post-write one every OTHER field's row reuses (see
    // `judgeComputeRulePostState`'s `writtenFieldPreScope`).
    const hasScopeCol = colSet === null || colSet.has('value_scope');
    // Q1's merged-state check (below, at the `isPayloadInconsistent` call site)
    // needs the STORED options_source when a partial PUT only names the
    // sibling column — same additive-column gate as the rest, since a DB that
    // warn-skipped this column has no stored value for it to conflict with.
    const hasOptionsSourceCol = colSet === null || colSet.has('options_source');

    // field_key identifies this field inside the blueprint's compute-rule graph,
    // so a blueprint-level compute_rule write can be placed in it.
    const oldRowCols = [
      'id', 'blueprint_id', 'field_type', 'field_key',
      ...(hasDependsCol ? ['depends_on_field_key'] : []),
      ...(hasModeCol ? ['value_source'] : []),
      ...(hasScopeCol ? ['value_scope'] : []),
      ...(hasOptionsSourceCol ? ['options_source'] : []),
    ].join(', ');
    const oldRows = await conn.query(
      `SELECT ${oldRowCols} FROM \`${t(TABLES.BLUEPRINT_FIELDS)}\` WHERE id = ?`,
      [fieldId],
    );
    if (!oldRows.length) {
      await conn.rollback();
      const e = apiError('Not found', 'NOT_FOUND', 404);
      return res.status(e.status).json(e.body);
    }
    const oldRow = oldRows[0];

    // Operator-mode gate: this custom PUT bypasses the generic CRUD factory,
    // so the column-existence gate has to be applied here too. The client
    // payload always carries depends_on_field_key (FieldEditor spreads the
    // whole form); on a DB where that ADD COLUMN was warn-skipped, naming the
    // missing column in the UPDATE would 500 instead of degrading. Reuse the
    // colSet probed before the old-row SELECT (probe-null keeps every key so
    // normal-mode writes are byte-identical).
    //
    // IT RUNS BEFORE EVERY GATE BELOW, and that order is the point: a gate that
    // judges a column the statement will not name has decided about a write
    // nobody made.
    const gatedKeys = gateKeysByColumnSet(data, colSet);
    if (!gatedKeys.length) {
      await conn.rollback();
      const e = apiError('No valid fields to update', 'BAD_REQUEST', 400);
      return res.status(e.status).json(e.body);
    }

    // THE ONE DERIVATION, asked twice because a write raises two questions, and
    // never re-derived by hand below. Both come from `deriveWritten` off the
    // GATED key list and the body verbatim — including `null`, which names the
    // column and asks for NULL to be written, and is a different act from
    // leaving the column out.
    //
    //   `statementWrites` — the columns the UPDATE will name, and nothing else.
    //   `written`         — the row the UPDATE leaves behind: those values over
    //                       the stored ones.
    //
    // The body-shaped check below takes `statementWrites` ON PURPOSE:
    // `checkValueSourcePayload` decides by which columns the write NAMES
    // (MODE_OWNED_COLUMNS forces a payload column to arrive beside its mode),
    // so merging the stored row in would make every column look named and
    // retire that rule.
    const statementWrites = deriveWritten(gatedKeys, data);
    const written = deriveWritten(gatedKeys, data, oldRow);
    const newType = written.field_type;

    // THE FLOOR RUNS BEFORE ANY LOOKUP USES ONE OF THESE VALUES, which is the
    // whole of its point on this handler: the linked-blueprint probe, the
    // ownership check and the destination check below all resolve a row with
    // `WHERE id = ?`, and a number bound there matches an arbitrary set of rows
    // (identifier-floor.js). This handler shadows the factory's PUT, so the
    // factory's floor never runs for it.
    const identifierIssue = identifierFloorViolation(FIELD_IDENTIFIER_COLUMNS, statementWrites);
    if (identifierIssue) {
      await conn.rollback();
      const e = apiError(identifierIssue.message, identifierIssue.code, identifierIssue.status);
      return res.status(e.status).json(e.body);
    }

    // THE PRECONDITION THE DESTRUCTIVE BLOCK BELOW RESTS ON. Its three branches
    // compare the stored type against a literal, and a comparison by identity
    // can only be trusted on a value already known to be identically a member of
    // the column's domain — which this column, a plain VARCHAR, does not declare
    // for itself (see field-type-domain.js). Refused before anything is written,
    // and before the engine is asked whether the type moved, so an undeclared
    // spelling can neither trigger the block nor reach the column.
    const typeViolation = fieldTypeViolation(statementWrites);
    if (typeViolation) {
      await conn.rollback();
      const e = apiError(typeViolation.message, typeViolation.code, typeViolation.status);
      return res.status(e.status).json(e.body);
    }

    // The same rule the endpoint that MIGRATES a key has always applied, now
    // applied by the endpoint that WRITES one. A key outside this shape cannot
    // be migrated afterwards, because every statement that moves a record's
    // answers builds a JSON path out of it.
    const keyViolation = fieldKeyViolation(statementWrites);
    if (keyViolation) {
      await conn.rollback();
      const e = apiError(keyViolation.message, keyViolation.code, keyViolation.status);
      return res.status(e.status).json(e.body);
    }

    // ── The three "did this move" questions, each asked of the party that
    //    resolves the value afterwards ────────────────────────────────────────
    const fieldsTable = t(TABLES.BLUEPRINT_FIELDS);
    // collation-compare: "is the field still under the same blueprint" is a
    // question about a COLUMN — every reader resolves the parent with
    // `WHERE id = ?`, which the engine answers under the column's collation, so
    // the engine is what answers it here too. Measured (db-semantics §Q1): the
    // engine does NOT absorb a respelling, it stores the new one — so when it
    // says the two spellings are one stored value, the STORED spelling is what
    // the statement binds. Otherwise the field would come to name its blueprint
    // in bytes no JavaScript reader (the export fingerprint, the reparent
    // re-stamp, every Map keyed by blueprint_id) resolves to that blueprint.
    const blueprintMoved = !(await sameStoredValue(
      conn, fieldsTable, 'blueprint_id', written.blueprint_id, oldRow.blueprint_id,
    ));
    if (!blueprintMoved) written.blueprint_id = oldRow.blueprint_id;
    // byte-compare: a stored `field_key` is resolved by a JAVASCRIPT reader —
    // the compute-rule graph keys its maps by it and the rename endpoint builds
    // a JSON path out of it — so two spellings the column folds into one are
    // still two keys to the party that reads them. Folding here would call two
    // different keys one key and skip the re-judgement the rename needs.
    const keyRenamed = written.field_key !== oldRow.field_key;
    // collation-compare: the same question about the same kind of column, and
    // the destructive block below turns on the answer.
    const typeChanged = !(await sameStoredValue(
      conn, fieldsTable, 'field_type', newType, oldRow.field_type,
    ));


    // S1/S2: a linked blueprint borrows the source's fields, so editing this
    // field would never render — block it for every role (this custom PUT
    // bypasses the factory's rejectLinkedParent, so the check lives here too).
    // Check the field's current blueprint AND any incoming blueprint_id in the
    // body (a reparent must not move the field into a linked blueprint).
    if (await isBlueprintLinkedLocked(conn, oldRow.blueprint_id)
        || (blueprintMoved && written.blueprint_id != null
            && await isBlueprintLinkedLocked(conn, written.blueprint_id))) {
      await conn.rollback();
      const e = apiError(
        'Cannot edit the schema of a linked blueprint; edit the source blueprint instead',
        'LINKED_BLUEPRINT_READONLY', 409,
      );
      return res.status(e.status).json(e.body);
    }

    // Editor must own the parent blueprint (or it must be shared) — the shared
    // spelling of that question, so this handler cannot drift from the eight
    // other places that ask it.
    if (!(await editorMayWriteBlueprint(conn, req, oldRow.blueprint_id))) {
      await conn.rollback();
      const e = apiError('Not found', 'NOT_FOUND', 404);
      return res.status(e.status).json(e.body);
    }

    // AND THE BLUEPRINT THE STATEMENT WILL WRITE, which is a different row from
    // the one it read whenever this write moves the field. Only the source was
    // ever checked, so an editor who owned the blueprint a field was LEAVING
    // could name any blueprint at all as its destination — including one they
    // cannot read — and the column carries no foreign key to refuse an id that
    // names nothing at all. Existence and node_type are asked of every role;
    // ownership of an editor. 404 rather than 403 keeps the existence-leak
    // parity every row-scoped answer on this path holds to.
    if (blueprintMoved && !(await checkBlueprintWriteTarget(conn, req, written.blueprint_id))) {
      await conn.rollback();
      const e = apiError('Not found', 'NOT_FOUND', 404);
      return res.status(e.status).json(e.body);
    }
    // collation-compare, second half: the "did it move" question above rebinds
    // the OLD blueprint's stored spelling when the answer is no. When the answer
    // is YES the destination is a different row, and the check that just admitted
    // it resolved it through the same case-folding `WHERE id = ?` — so the
    // destination's own spelling has to be bound too, or a genuine move leaves
    // the field naming its new blueprint in bytes the export fingerprint, the
    // reparent re-stamp and every Map keyed by blueprint_id do not resolve.
    if (blueprintMoved) {
      const storedTarget = await storedRowId(conn, TABLES.HIERARCHY_NODES, written.blueprint_id);
      if (storedTarget != null) written.blueprint_id = storedTarget;
    }

    const consistency = isPayloadInconsistent(newType, statementWrites, {
      modeColumnPresent: hasModeCol,
      // Q1 (options_source × depends_on_field_key) is judged on the MERGED
      // written row, not the body alone: a partial PUT that names only one
      // side reads as consistent against the body while the STORED other
      // side is what actually lands beside it. `written` is that merge
      // (`deriveWritten(gatedKeys, data, oldRow)` above); every other check
      // in `isPayloadInconsistent` stays body-shaped on purpose (see the
      // comment at `statementWrites`'s definition), so this is passed
      // separately rather than switching the whole call to `written`.
      mergedOptionsSource: written.options_source,
      mergedDependsOnFieldKey: written.depends_on_field_key,
    });
    if (!consistency.ok) {
      await conn.rollback();
      return res.status(400).json({
        ok: false,
        error: { message: consistency.detail, code: consistency.code },
      });
    }

    // The pair (blueprint, key) is what identifies a field to every reader of a
    // record's answers, so a write that changes EITHER half asks whether the
    // pair it produces is already taken. In this transaction, before the
    // statement that would create the duplicate — and therefore before the
    // migration endpoint could be aimed at it and copy one field's answers over
    // the other's in every record of the blueprint.
    if ((keyRenamed || blueprintMoved)
        && await fieldKeyTaken(conn, written.blueprint_id, written.field_key, fieldId)) {
      await conn.rollback();
      const e = apiError(FIELD_KEY_TAKEN.message, FIELD_KEY_TAKEN.code, FIELD_KEY_TAKEN.status);
      return res.status(e.status).json(e.body);
    }

    // A rule is only meaningful against the field context around it, so a write
    // that changes that context — this field's type or key, the blueprint it
    // belongs to, or a table's column set — has to be judged on the state it
    // produces, not only on what it carries. Gated on the additive column: with
    // no compute_rule column no blueprint-level rule can exist, so there is
    // nothing a post-write scan could find.
    const ruleColumnPresent = colSet === null || colSet.has('compute_rule');
    const targetBlueprintId = written.blueprint_id;
    const targetFieldKey = written.field_key;
    // P1a: a write that narrows or widens `value_scope` WITHOUT touching
    // compute_rule can turn an already-stored `same_table_column` rule
    // un-runnable (narrows→whole-field) or runnable again (whole-field→
    // narrowed) without ever setting `ruleAuthored` — the post-state pass is
    // the only place that re-judges a rule the request did not author, so it
    // has to run whenever the narrowing itself moved, not only when the rule
    // did.
    const graphAffecting = ruleColumnPresent && (
      typeChanged
      || keyRenamed
      || blueprintMoved
      || gatedKeys.includes('table_config')
      || gatedKeys.includes('value_scope')
    );
    // One scan per blueprint, shared by the pre-write guard and the post-write
    // baseline: `fieldRows` is the same row set whatever the guard excludes from
    // its rule map, so nothing is read twice.
    const preScans = new Map();
    const preScan = async (blueprintId) => {
      if (!preScans.has(blueprintId)) {
        preScans.set(blueprintId, await loadBlueprintComputeState(
          conn, blueprintId, { t, TABLES, excludeFieldKey: oldRow.field_key },
        ));
      }
      return preScans.get(blueprintId);
    };

    const ruleInBody = gatedKeys.includes('compute_rule') && written.compute_rule != null;
    // Did this request AUTHOR a rule, or is it carrying the stored one back?
    // The field editor spreads the whole form, so a type change arrives with the
    // existing rule attached. Judging that passenger as an authored write would
    // refuse a change the operator explicitly asked for; it is instead the
    // post-write pass that decides what happens to the stale rule.
    let ruleAuthored = false;
    if (ruleInBody) {
      const storedRow = (await preScan(oldRow.blueprint_id)).fieldRows
        .find((r) => r.field_key === oldRow.field_key);
      ruleAuthored = canonicalRuleJson(written.compute_rule)
        !== canonicalRuleJson(storedRow && storedRow.compute_rule);
    }

    // Baselines for the post-write judgement. A reparent concerns two
    // blueprints: the one the field joins, and the one it leaves — whose rules
    // may name a key that just walked out of it.
    //
    // CONSOLIDATION (the "column-cycle check missed on some write path" family
    // has recurred three times): a request that AUTHORS a rule now runs the
    // post-write judgement too, not only `graphAffecting`'s context-changing
    // triggers. That is what lets the column-cycle check live SOLELY in
    // `judgeComputeRulePostState` — see the direct pre-write block below,
    // which used to run its own separate column-cycle check and no longer
    // does, because every request that reaches it also reaches here.
    const graphChecks = [];
    if (graphAffecting || (ruleInBody && ruleAuthored)) {
      graphChecks.push({ blueprintId: targetBlueprintId, writtenFieldKey: targetFieldKey });
      if (blueprintMoved) {
        graphChecks.push({ blueprintId: oldRow.blueprint_id, writtenFieldKey: null });
      }
      for (const check of graphChecks) {
        check.preRows = (await preScan(check.blueprintId)).fieldRows;
      }
    }

    // SECURITY/SAFETY: a blueprint-level compute rule applies to every variant
    // of the blueprint, so it must clear the same two gates a variant-level rule
    // clears before it may be persisted. The structural floor above only proves
    // the value is an object at all; a rule whose op the source extractor cannot
    // read contributes no edges, so an unvalidated rule in the column would also
    // blind the cycle guard that runs right after it.
    // Only a rule this request actually authors needs judging here: clearing one
    // removes edges and can never close a cycle, a rule gated out by the column
    // set is never written at all, and a rule that is already in the column is
    // judged by the post-write pass against the state this write produces.
    if (ruleInBody && ruleAuthored) {
      const ruleBlueprintId = targetBlueprintId;
      const incomingRule = parseStoredRule(written.compute_rule);
      // One scan yields the field context AND the blueprint-level rules, and the
      // rules exclude the row being written — which is stored under its CURRENT
      // key, not the one this write may be renaming it to. Excluding by the new
      // key would leave the stored rule in the graph under the old key while the
      // incoming rule enters under the new one: one field, two nodes.
      const scan = await preScan(ruleBlueprintId);
      const { tableColumns, rules } = scan;
      // A rename in the same write leaves the stored rows carrying the old key;
      // the field can always reference itself, and doing so is a cycle rather
      // than a missing source. Copied so the shared scan keeps describing the
      // blueprint as it is stored.
      const fieldKeys = new Set(scan.fieldKeys);
      // The key the field is leaving behind names nothing once the write lands,
      // so a rule that references it is a missing source — judging it against
      // the pre-write key set would accept a rule the post-write state refuses.
      if (keyRenamed) fieldKeys.delete(oldRow.field_key);
      fieldKeys.add(targetFieldKey);
      // NOTE: only 'number' fields are numeric; every other field_type maps to
      // 'string'. A new numeric field_type must be added here explicitly.
      // C1: judged on `written.value_scope` — the POST-write value, which is
      // the body's when this PUT's gated key set includes `value_scope`, and
      // the stored row's otherwise (`deriveWritten`'s fallback; `oldRowCols`
      // above DOES select `value_scope` whenever `hasScopeCol` is true — a
      // stale claim here once said it never did). Only a schema that predates
      // the `value_scope` column (`hasScopeCol` false, so `stored.value_scope`
      // was never fetched to fall back to) leaves it undefined here —
      // unknown, not narrowed, fail-closed like every other context this
      // validator refuses on.
      // P2: EXACTLY one column, not merely "names a column" — see
      // `scopeNamesSingleColumn`'s doc-block.
      const ruleResult = validateComputeRule(incomingRule, {
        fieldKeys,
        targetType: newType === 'number' ? 'number' : 'string',
        tableColumns,
        ownerFieldKey: targetFieldKey,
        narrowedToColumn: scopeNamesSingleColumn(written.value_scope),
      });
      if (!ruleResult.ok) {
        await conn.rollback();
        // `detail` is present when the reason needs a number to be actionable
        // (a size limit); otherwise the code is the message, as before.
        const e = apiError(ruleResult.detail || ruleResult.code, ruleResult.code, 400);
        return res.status(e.status).json(e.body);
      }
      // FIELD-level cycle only — checked here, pre-write, so an obviously
      // broken rule is refused before the UPDATE and the rest of this
      // handler's cleanup run at all. The COLUMN-level check used to run here
      // too (P1b, round 2), but `ruleInBody && ruleAuthored` now also
      // qualifies for the post-write judgement below (`graphChecks`), which
      // re-scans this exact rule against the exact post-state — running the
      // column check a second time here would be the parallel mechanism the
      // consolidation retired, not a safety margin. See the comment above
      // `graphChecks`.
      const cycleResult = await blueprintRuleClosesCycle(conn, {
        blueprintId: ruleBlueprintId,
        targetFieldKey,
        storedFieldKey: oldRow.field_key,
        incomingRule,
        blueprintRules: rules,
        t,
        TABLES,
      });
      if (cycleResult.fieldCycle) {
        await conn.rollback();
        const e = apiError('compute_rule introduces a dependency cycle', 'cycle', 400);
        return res.status(e.status).json(e.body);
      }
    }

    // Column-level rules (table_config.columns[].rules.compute_rule) are
    // judged on every write that persists table_config, independently of
    // whether this same request ALSO authors the field's own compute_rule
    // (the block above) — the two are separate mechanisms in separate
    // columns, and a table_config-only edit (no compute_rule in the body at
    // all) is judged exactly the same as one that touches both. STRICT, no
    // "only the columns this write touched" leniency (2026-09-01 decision):
    // re-saving an already-bad column is refused just like authoring one.
    if (gatedKeys.includes('table_config') && written.table_config != null) {
      const scan = await preScan(targetBlueprintId);
      const { tableColumns } = scan;
      // Same rename handling as the field-level block above: the field can
      // always reference itself in a same-table term, and the shared scan's
      // fieldKeys still carries the row under its PRE-write key.
      const fieldKeys = new Set(scan.fieldKeys);
      if (keyRenamed) fieldKeys.delete(oldRow.field_key);
      fieldKeys.add(targetFieldKey);
      const columnRuleResult = validateTableColumnComputeRules(written.table_config, {
        fieldKeys, tableColumns, ownerFieldKey: targetFieldKey,
      });
      if (!columnRuleResult.ok) {
        await conn.rollback();
        const e = apiError(
          `table_config column '${columnRuleResult.columnKey}': ${columnRuleResult.detail || columnRuleResult.code}`,
          columnRuleResult.code, 400,
        );
        return res.status(e.status).json(e.body);
      }
    }

    // INSERT-then-UPDATE pattern from the factory: build SETs from the
    // gated safe keys. UUIDs are not in gatedKeys.
    //
    // THE STATEMENT BINDS `written`, NOT THE BODY. For a gated key the two hold
    // the same value by construction — which is the point: there is no second
    // object for a later edit to diverge from, and the one place a value is
    // corrected (the blueprint respelling above) corrects what the column gets.
    const sets = gatedKeys.map((k) => `\`${k}\` = ?`).join(', ');
    const updateSql = `UPDATE \`${t(TABLES.BLUEPRINT_FIELDS)}\` SET ${sets} WHERE id = ?`;
    const updateParams = [...gatedKeys.map((k) => written[k]), fieldId];
    await conn.query(updateSql, updateParams);

    // A field key is stored rather than an id, so another field naming this one
    // holds a string that stops resolving the moment the key moves. The reader
    // does not error — the cascading picker finds no parent and offers nothing,
    // the visibility condition finds no subject and never holds — so a rename
    // that moved the field and not the references looks like it worked and reads
    // as a design choice afterwards.
    //
    // HERE, IN THE STATEMENT THAT WRITES THE KEY, and not in the POST /rename
    // this call accompanies. There the references would name a key no field
    // holds until this request landed, and if it never landed and the operator
    // saved under a third key instead, they would be stranded permanently: a
    // later repoint matches on the field's STORED key, which by then is neither
    // the key they were moved from nor the one they were moved to.
    //
    // WHAT THIS COVERS, AND THE ONE PATH IT DOES NOT. A create cannot strand a
    // reference — nothing names a key that did not exist a moment ago. The
    // blueprint import cannot either: it DELETEs the blueprint's whole field set
    // and re-inserts it, so a sibling's reference arrives from the same payload
    // rather than surviving from before.
    //
    // The cross-environment sync CAN, and this cascade does not reach it.
    // `syncData` upserts the rows it was handed and nothing else — no delete, no
    // whole-set replace — so a `data_only` or `full_sync` payload carrying an
    // existing field with a changed `field_key`, while simply omitting a sibling
    // that references it, leaves that sibling naming the old key. Measured on a
    // real engine: the sync reports `upserted: 1` and the omitted sibling keeps
    // both `depends_on_field_key` and its rule subject pointing at a key no
    // field holds.
    //
    // NOT FIXED HERE, DELIBERATELY, and the reason is a property of that path
    // rather than effort: the cascade needs the key the row held BEFORE the
    // write, and the sync path never reads it — its only pre-read of existing
    // rows fetches `blueprint_id`, conditionally. It also runs no transaction at
    // all, so a repair issued there would commit separately from the rename it
    // repairs. Both are sync-path design questions with their own reporting
    // contract, tracked separately. An export-shaped payload (the normal one)
    // carries the whole blueprint and its siblings' references with it.
    //
    // NOT RUN WHEN THE FIELD ALSO CHANGES BLUEPRINT. The references sit in the
    // blueprint the field is LEAVING, and it will not be there to be referenced;
    // repointing them at the new key would strand them on a key no field in that
    // blueprint holds — the same failure, made by the repair. Read from
    // `blueprintMoved`, which is the engine's answer about the value this
    // statement wrote, so a destination spelled in another capitalisation is the
    // ordinary rename it really is rather than a move that skips the cascade.
    //
    // Reuses the column probe this handler already took: `depends_on_field_key`
    // arrived by an additive ALTER a no-privilege operator database may have
    // warn-skipped, and naming an absent column would 1054 the whole write. A
    // null probe means "could not tell", which keeps every site.
    const repointed = {};
    if (keyRenamed && !blueprintMoved) {
      for (const site of fieldKeyReferencesPresentIn(colSet)) {
        // Excluded from THIS site only if the statement above named THIS column:
        // that is the value the request wrote and the repair may not overrule
        // it. At any other site the addressed row's own reference is a reference
        // like the rest and has to follow the key, or it stops resolving.
        const requestWroteThisSite = gatedKeys.includes(site.column);
        const { sql, params } = buildReferenceRenameUpdate(
          site, oldRow.field_key, written.field_key, oldRow.blueprint_id,
          requestWroteThisSite ? fieldId : null,
        );
        const result = await conn.query(sql, params);
        repointed[site.column] = (repointed[site.column] || 0) + (result.affectedRows || 0);
      }
    }

    // P2-6 — reset per-option cascade tags when the parent changes. The
    // field_options.valid_parent_values tags reference the OLD parent's option
    // values; after re-parenting they would be misread against the new parent
    // (and values not in the new parent's list become invisible in the editor,
    // so they can't be removed). Clearing them on a parent change gives the
    // admin a clean slate to re-tag. Only fires when the STATEMENT names
    // depends_on_field_key (so a label-only edit never touches tags, and neither
    // does a body naming a column this database does not have — the parent
    // cannot have changed if nothing wrote it) AND its written value differs
    // from the stored one. Both sides normalize "no parent" to null first:
    // FieldEditor always spreads the full form so a never-parented field arrives
    // as '' while the stored value is null — without this normalization
    // '' !== null fires on every label-only edit and wipes any tags an admin
    // pre-set. Gated on the valid_parent_values column existing so operator-mode
    // (column warn-skipped) degrades instead of 500'ing.
    const noParent = (v) => ((v ?? '') === '' ? null : v);
    const incomingParent = noParent(written.depends_on_field_key);
    const storedParent = noParent(oldRow.depends_on_field_key);
    if (gatedKeys.includes('depends_on_field_key') && incomingParent !== storedParent) {
      const optColSet = await getActualColumnSet(conn, t(TABLES.FIELD_OPTIONS));
      if (optColSet === null || optColSet.has('valid_parent_values')) {
        await conn.query(
          `UPDATE \`${t(TABLES.FIELD_OPTIONS)}\` SET valid_parent_values = NULL WHERE field_id = ?`,
          [fieldId],
        );
      }
    }

    // Type-aware cleanup. Skip if type unchanged.
    let deletedOptionsCount = 0;
    let clearedChoiceConfig = false;
    let clearedCellTargetsCount = 0;
    let clearedValueScope = false;
    if (typeChanged) {
      // WHICH MEMBER OF THE DOMAIN THE OLD ROW HELD, asked of the column rather
      // than compared byte-for-byte against a literal. `fieldTypeViolation`
      // above makes identity a precondition of the value being WRITTEN, which
      // is what lets these three comparisons be plain literals — but it says
      // nothing about the value already STORED, and these three judge the old
      // row. A stored `'Table'` is the same value as `'table'` to the engine, so
      // the type change is detected, and `=== 'table'` then answers false and
      // the cleanup that belongs to the change does not run. Rows that predate
      // the write gate and rows the import paths insert are both still in the
      // table (see resolveStoredFieldType).
      const oldType = await resolveStoredFieldType(conn, fieldsTable, oldRow.field_type);
      // select AND checkbox own field_options rows.
      if (oldType === 'select' || oldType === 'checkbox') {
        const result = await conn.query(
          `DELETE FROM \`${t(TABLES.FIELD_OPTIONS)}\` WHERE field_id = ?`,
          [fieldId],
        );
        deletedOptionsCount = Number(result?.affectedRows ?? 0);
      }
      if (oldType === 'checkbox') {
        // choice_config is an additive column — gate the NULL-clear on it
        // existing so an operator-mode DB that skipped the migration degrades
        // instead of 500'ing on ER_BAD_FIELD_ERROR.
        const bfColSet = await getActualColumnSet(conn, t(TABLES.BLUEPRINT_FIELDS));
        if (bfColSet === null || bfColSet.has('choice_config')) {
          await conn.query(
            `UPDATE \`${t(TABLES.BLUEPRINT_FIELDS)}\` SET choice_config = NULL WHERE id = ?`,
            [fieldId],
          );
          clearedChoiceConfig = true;
        }
      }
      if (oldType === 'table') {
        // table_config might also be in updateKeys (client sent null).
        // Idempotent: NULL → NULL is a no-op.
        await conn.query(
          `UPDATE \`${t(TABLES.BLUEPRINT_FIELDS)}\` SET table_config = NULL WHERE id = ?`,
          [fieldId],
        );
        // The field's OWN cell scope goes with the table_config, in the SAME
        // transaction and on the SAME trigger.
        //
        // WHAT THE CLEAR ACHIEVES: a scope that is not cleared stays in the
        // column, inert (the resolver reads a scope only on a `table` field),
        // and comes back to life the moment the field is changed BACK to
        // `table` — at which point a setting the author states as whole-field
        // is silently narrowed to cells nobody picked.
        //
        // WHAT IT DOES NOT ACHIEVE, and the earlier comment here claimed
        // otherwise: it does not prevent the widening. A two-cell lock becomes
        // a field-wide lock the instant the field stops being a table, cleared
        // column or not, because the resolver drops the scope for a non-table
        // field either way. Nothing tells the author the reach just grew; the
        // audit row below records only that the document went.
        //
        // No mode is written beside this clear: `modeAfterPayloadClear` returns
        // none for a scope, because no mode is left naming a payload that is
        // absent. Widening the reach is a change in meaning, not an incoherent
        // row.
        // Gated on the additive column existing, like every other clear here.
        // `colSet` is the blueprint_fields probe this handler already took at
        // the top; the checkbox branch above re-takes it under its own name.
        if (colSet === null || colSet.has('value_scope')) {
          try {
            // IS NOT NULL keeps affectedRows honest: 1 only when there really
            // was a scope that would have widened.
            const clearedScope = await conn.query(
              `UPDATE \`${t(TABLES.BLUEPRINT_FIELDS)}\` SET value_scope = NULL
                WHERE id = ? AND value_scope IS NOT NULL`,
              [fieldId],
            );
            clearedValueScope = Number(clearedScope?.affectedRows ?? 0) > 0;
          } catch (clearErr) {
            // Probe was blind (unknown column set) and the column really is
            // absent. A statement-level 1054 does not roll the transaction back,
            // so the type change still completes — there was no scope to widen.
            if (!isMissingTableOrColumn(clearErr)) throw clearErr;
          }
        }
        // A variant override's cell_targets addresses rows x columns of a TABLE
        // field. With the field no longer a table the resolver finds no cells to
        // match and hands the raw override to the whole-field path, so a scope
        // the author wrote to NARROW an override silently WIDENS it: a
        // one-column `hide` becomes a field-wide hide, which strips the field's
        // value out of the saved payload. Clearing the now-meaningless document
        // keeps the stored row and its meaning in agreement (NULL is the
        // documented whole-field value) and puts the widening in the audit row
        // instead of leaving it silent. Same transaction as the rest of the
        // cleanup: a half-applied type change is what this handler exists to
        // prevent.
        // Gated on the additive cell_targets column existing so an operator-mode
        // DB that warn-skipped the ALTER degrades instead of failing the type
        // change on ER_BAD_FIELD_ERROR.
        const voColSet = await getActualColumnSet(conn, t(TABLES.VARIANT_OVERRIDES));
        if (voColSet === null || voColSet.has('cell_targets')) {
          try {
            // IS NOT NULL keeps affectedRows an honest count of the overrides
            // that would have widened, and leaves untargeted rows unlocked.
            const cleared = await conn.query(
              `UPDATE \`${t(TABLES.VARIANT_OVERRIDES)}\` SET cell_targets = NULL
                WHERE field_id = ? AND cell_targets IS NOT NULL`,
              [fieldId],
            );
            clearedCellTargetsCount = Number(cleared?.affectedRows ?? 0);
          } catch (clearErr) {
            // Probe was blind (unknown column set) and the column really is
            // absent. A statement-level 1054 does not roll the transaction back,
            // so the type change still completes — there was no scope to widen.
            if (!isMissingTableOrColumn(clearErr)) throw clearErr;
          }
        }
      }
      // Audit row — metadata captures what cleanup actually fired so a
      // future investigation can reconstruct silent data-loss claims.
      await conn.query(
        `INSERT INTO \`${t(TABLES.FEATURE_AUDIT)}\` (id, event_type, user_id, metadata)
         VALUES (?, 'blueprint.field.type_changed', ?, ?)`,
        [
          uuidv4(),
          // lint-allow: write-path-shapes the feature_audit user_id column: a
          // row written from the provider's subject claim names an actor no reader of
          // users.id resolves. Deferred with the rest of the audit-line family.
          req.user?.id || req.user?.sub || null,
          JSON.stringify({
            field_id: fieldId,
            blueprint_id: oldRow.blueprint_id,
            old_type: oldRow.field_type,
            new_type: newType,
            deleted_options_count: deletedOptionsCount,
            // The literal the column holds, and the member the column says it
            // is — the two differ exactly on the rows this cleanup used to miss.
            old_type_resolved: oldType,
            cleared_table_config: oldType === 'table',
            cleared_choice_config: clearedChoiceConfig,
            cleared_cell_targets_count: clearedCellTargetsCount,
            cleared_value_scope: clearedValueScope,
          }),
        ],
      );
    }

    // Judge the rule set this write actually produced. Runs after the
    // type-change cleanup because that cleanup is part of the post-state (a
    // table that stopped being one has no columns left for another field's
    // table_cell source to name), and inside the same transaction so a verdict
    // of "refuse" leaves the row exactly as it was.
    for (const check of graphChecks) {
      const postScan = await loadBlueprintComputeState(conn, check.blueprintId, { t, TABLES });
      const postRows = postScan.fieldRows;
      // C1: same_table_column narrowing for every OTHER field's already-stored
      // rule — this write's own field is judged above, against `written`
      // directly; a stray `same_table_column` term surviving on a field this
      // request never touched degrades the same way any other already-invalid
      // legacy rule does (never blocks an unrelated write — see the doc-block).
      const scopesByFieldKey = await loadBlueprintFieldScopes(conn, check.blueprintId, { t, TABLES });
      // Column-cycle input for `judgeComputeRulePostState`: this blueprint's
      // variants, POST-state. `variant_overrides` is not written by this
      // route, so there is no rename to thread through here (contrast
      // `blueprintRuleClosesCycle`'s pre-write callers, which read before the
      // UPDATE and do need one) — the field_key a variant's override is filed
      // under already reflects whatever this transaction just committed.
      const byVariant = await loadVariantComputeRulesByVariant(conn, check.blueprintId, { t, TABLES });
      // cell_targets is a second query; only paid for when a column cycle is
      // even POSSIBLE, same short-circuit `blueprintRuleClosesCycle` applies.
      const anyRowContext = [...postScan.rules.values()].some(hasRowContextSource)
        || [...byVariant.values()].some((vr) => [...vr.values()].some(hasRowContextSource));
      const variantCellTargetsByVariant = anyRowContext
        ? await loadVariantCellTargetsByVariant(conn, check.blueprintId, { t, TABLES })
        : null;
      const verdict = judgeComputeRulePostState({
        preRows: check.preRows,
        postRows,
        storedFieldKey: oldRow.field_key,
        writtenFieldKey: check.writtenFieldKey,
        ruleAuthored,
        scopesByFieldKey,
        // P1a: this row's ACTUAL pre-write scope — without it, the "before"
        // judgement reuses the POST-write scope for the written field too,
        // and a narrows→whole-field write reads as "already invalid before"
        // (masking the transition this whole pass exists to catch).
        writtenFieldPreScope: oldRow.value_scope,
        byVariant,
        variantCellTargetsByVariant,
      });
      if (verdict.reject) {
        await conn.rollback();
        const e = apiError(verdict.reject.message, verdict.reject.code, verdict.reject.status);
        return res.status(e.status).json(e.body);
      }
      if (verdict.clearWrittenRule) {
        // THE MODE MOVES WITH ITS PAYLOAD, and this is the write that used to
        // prove it does not. Clearing the rule under a stored 'copied' /
        // 'calculated' leaves a mode naming a payload that is gone: the field
        // editor spreads that row straight back on the next save and the write
        // boundary refuses its own stored state, so an ordinary type change
        // made the field permanently unsaveable and its blueprint unimportable.
        // The post-state mode is the one derivation's answer for the column —
        // the body's when this write names it, the stored one otherwise;
        // `modeAfterPayloadClear` is the single answer to which mode that leaves
        // valid. Gated on the column, like every other clear here — with no
        // `value_source` column there is no mode to correct, and `postMode` is
        // then undefined, which the helper reads as "none".
        const postMode = written.value_source;
        const modeAfter = hasModeCol
          ? modeAfterPayloadClear(postMode, ['compute_rule'])
          : null;
        await conn.query(
          modeAfter === null
            ? `UPDATE \`${t(TABLES.BLUEPRINT_FIELDS)}\` SET compute_rule = NULL WHERE id = ?`
            : `UPDATE \`${t(TABLES.BLUEPRINT_FIELDS)}\` SET compute_rule = NULL, value_source = ? WHERE id = ?`,
          modeAfter === null ? [fieldId] : [modeAfter, fieldId],
        );
        // The operator asked for the schema change, not for the rule to
        // disappear with it, so the loss gets its own forensic record rather
        // than riding along in whatever other audit this request happened to
        // write. The mode change is recorded beside it: "the rule went" and
        // "the field stopped being a copy" are two different things to be told.
        // The refreshed row in the response shows the cleared state.
        await conn.query(
          `INSERT INTO \`${t(TABLES.FEATURE_AUDIT)}\` (id, event_type, user_id, metadata)
           VALUES (?, 'blueprint.field.compute_rule_cleared', ?, ?)`,
          [
            uuidv4(),
            // lint-allow: write-path-shapes the same feature_audit user_id
            // column as the type-change trail above, deferred with it.
            req.user?.id || req.user?.sub || null,
            JSON.stringify({
              field_id: fieldId,
              blueprint_id: check.blueprintId,
              field_key: check.writtenFieldKey,
              old_type: oldRow.field_type,
              new_type: newType,
              cleared_value_source: modeAfter !== null ? postMode : null,
            }),
          ],
        );
      }
    }

    const refreshed = await conn.query(
      `SELECT * FROM \`${t(TABLES.BLUEPRINT_FIELDS)}\` WHERE id = ?`,
      [fieldId],
    );
    // The row, not the body. See postStateInconsistent — a partial PUT can name
    // a mode without naming the payload it is the mode of, and only the row
    // knows what was left behind.
    const postState = postStateInconsistent(refreshed[0]);
    if (postState) {
      await conn.rollback();
      return res.status(400).json({
        ok: false,
        error: {
          // Named as a result rather than as a bad field: the offending column
          // may be one the caller never sent.
          message: `This change would leave the field inconsistent: ${postState.detail}`,
          code: postState.code,
        },
      });
    }
    await conn.commit();
    // The only record anywhere that this request wrote rows OTHER than the one
    // it addressed: the response carries the edited field alone, and the impact
    // preview the client shows beforehand counts records, not references.
    //
    // TWO LINES, GATED ON THE CONDITION THE CASCADE ACTUALLY RAN UNDER. One line
    // fired on the rename alone, so a rename that also moved the field announced
    // that it had repointed the references at the very moment it deliberately
    // did not — with an empty `repointed` object as the only tell, and that is
    // not distinguishable at a glance from `{depends_on_field_key: 0, ...}`,
    // which is what a cascade that ran and matched nothing emits.
    //
    // THE SENTENCE NAMES THE COLUMNS AND NOT "the references", because it is not
    // all of them. A field key is also named inside `compute_rule`, inside
    // `decision_tables.doc` and inside a connector's mappings, none of which
    // this cascade can rewrite in one statement — declared, with the reasons, in
    // blueprint-field-key-references.js. The exclusion was honest there and not
    // in the one sentence an operator actually reads, and an operator who trusts
    // a completeness claim stops looking at the place the stale key is.
    if (keyRenamed && !blueprintMoved) {
      logger.info(
        {
          fieldId,
          blueprint_id: oldRow.blueprint_id,
          old_key: oldRow.field_key,
          new_key: written.field_key,
          repointed,
          not_repointed: UNREWRITABLE_KEY_REFERENCE_SITES,
        },
        'Renamed a field key and repointed the cascade parents and visibility-rule '
        + 'subjects other fields held; see not_repointed for the places a key is '
        + 'named that this does not follow',
      );
    } else if (keyRenamed) {
      logger.info(
        {
          fieldId,
          blueprint_id: oldRow.blueprint_id,
          new_blueprint_id: written.blueprint_id,
          old_key: oldRow.field_key,
          new_key: written.field_key,
        },
        'Renamed a field key and left every reference to it in the blueprint the '
        + 'field left, where they still name the key it had there',
      );
    }
    res.json(apiOk(mapRowFromDb('blueprint_fields', refreshed[0])));
  } catch (err) {
    if (conn) {
      try { await conn.rollback(); } catch (rbErr) {
        logger.warn({ err: rbErr }, 'rollback after blueprint_fields PUT failed');
      }
    }
    // The race the in-transaction probe above cannot close: two writes claiming
    // one key, both past their probe. On a database carrying the UNIQUE index
    // the loser arrives here, and it gets the SAME answer the probe gives —
    // otherwise the operator is told "server error" for a state the other
    // spelling of this refusal explains.
    if (err && err.errno === 1062) {
      const e = apiError(FIELD_KEY_TAKEN.message, FIELD_KEY_TAKEN.code, FIELD_KEY_TAKEN.status);
      return res.status(e.status).json(e.body);
    }
    // A write the engine gave up on rather than a write this server got wrong,
    // answered here with the sentence every other verb in this schema already
    // answers it with. This handler needs the arm now because the reference
    // cascade widened what it locks: the JSON predicate is not indexable, so the
    // statement examines every field row of the blueprint and takes next-key
    // locks across that whole range, where a rename previously locked one row
    // and could not join a deadlock cycle at all. Reported as a 500 it is
    // indistinguishable from a server fault, and a client has no way to know
    // that retrying is the correct response.
    const conflict = writeConflictError(err);
    if (conflict) {
      logger.warn({ err, fieldId }, 'blueprint_fields PUT lost a lock race');
      return res.status(conflict.status).json(conflict.body);
    }
    logger.error({ err, fieldId }, 'Failed to update blueprint_fields with type-change cleanup');
    const e = apiError('Database operation failed', 'INTERNAL_ERROR');
    res.status(e.status).json(e.body);
  } finally {
    if (conn) conn.release();
  }
});


// Mount sub-routes for each schema table.
// Logical names are passed here; t() resolves the prefix at request time.
//
// B1/B2/B5 link integrity (create). Validation-only middleware registered
// BEFORE the factory mount: it rejects an invalid link/transformer combination,
// then calls next() so the factory performs the actual insert with its full
// ownership / owner-stamping / operator-mode logic intact. A brand-new node has
// no own schema yet, so there is no auto-clear on create.
router.post('/hierarchy_nodes', async (req, res, next) => {
  if (!requireAdminOrEditor(req, res)) return;
  const body = req.body || {};
  // A value that names no row is refused rather than folded into "absent": the
  // fold decided this guard about a value the statement did not write, and the
  // column then held the empty string every later reader takes for a link.
  const blank = refuseLinkColumnShape(body);
  if (blank) {
    const e = apiError(blank.message, blank.code, blank.status);
    return res.status(e.status).json(e.body);
  }
  const effLinked = effectiveLinkValue(body, null, 'linked_blueprint_id');
  // transformer_version without transformer_id is still transformer metadata —
  // a linked blueprint must carry neither, so the XOR check considers both.
  //
  // PICKED BY PRESENCE, NOT BY TRUTHINESS, which is the rule this module's own
  // header states and which the `||` here was breaking: `{"transformer_id": 0}`
  // is transformer metadata the statement WILL write, and `0 || x` read it as
  // "no transformer" — so a create naming both a link and a numeric transformer
  // passed the exclusivity guard and stored the pair B5 exists to forbid.
  const effTransformerId = effectiveLinkValue(body, null, 'transformer_id');
  const effTransformerVersion = effectiveLinkValue(body, null, 'transformer_version');
  const effTransformer = effTransformerId != null ? effTransformerId : effTransformerVersion;
  // Only blueprints carry link/transformer semantics; a non-blueprint with no
  // link passes straight through. A non-blueprint that DOES carry a link must
  // still be validated (and rejected) — don't let a variant smuggle a link in.
  if (effLinked == null && effTransformer == null) return next();
  let conn;
  try {
    const poolRef = body.db ? (await getDynamicPool(body.db)).rw : pool.rw;
    conn = await poolRef.getConnection();
    // lint-allow: write-path-shapes the fold reaches a VALIDATOR argument, not
    // a column: this is the create path, where the row has no id yet, and the validator's
    // own contract is that a null id means "not yet stored". Nothing is written from it.
    const err = await validateLinkConstraints(conn, body.id || null, body.node_type, effLinked, effTransformer);
    if (err) {
      const e = apiError(err.message, err.code, err.status);
      return res.status(e.status).json(e.body);
    }
    // AND THE ROW THE GUARDS RESOLVED IS THE ROW THE INSERT NAMES. This
    // middleware hands the body on to the factory, which binds
    // `linked_blueprint_id` exactly as it arrived — so an id sent in another
    // case passed every check against the right row and was stored in bytes the
    // column resolves and JavaScript does not (see `storedNodeId`). The factory
    // reads `req.body`, so that is the object normalised.
    if (effLinked != null) {
      const targetId = await storedNodeId(conn, effLinked);
      if (targetId != null) req.body.linked_blueprint_id = targetId;
    }
  } catch (e) {
    logger.error({ err: e }, 'Failed to validate link constraints on hierarchy_node create');
    const er = apiError('Database operation failed', 'INTERNAL_ERROR');
    return res.status(er.status).json(er.body);
  } finally {
    if (conn) conn.release();
  }
  return next();
});


// B1/B2/B5 link integrity + Q3 auto-clear (update). Reads the stored row to
// compute the effective post-write link/transformer, validates, then:
//   - non-transition writes → next() (factory does the update untouched);
//   - a null→linked transition → handled fully here in ONE transaction
//     (clear the blueprint's now-unreachable own schema + set the link +
//     audit), because the clear and the link-set must be atomic — a partial
//     apply would leave the blueprint empty AND independent (data loss).
router.put('/hierarchy_nodes/:id', async (req, res, next) => {
  if (!requireAdminOrEditor(req, res)) return;
  const rowId = req.params.id;
  const body = { ...req.body };
  // Same refusal as the create path, and for the same reason — this verb also
  // decides whether the write is the link TRANSITION that clears the
  // blueprint's own schema. And unlike the create path it does NOT hand the
  // body on to the factory when it takes that decision, so the factory's floor
  // never runs for the one write that destroys something: this call is the only
  // thing standing in front of it.
  const blank = refuseLinkColumnShape(body);
  if (blank) {
    const e = apiError(blank.message, blank.code, blank.status);
    return res.status(e.status).json(e.body);
  }
  let conn;
  let poolRef = null;
  let effLinkedForAudit = null;
  let clearAttempted = false;
  let committed = false;
  try {
    poolRef = body.db ? (await getDynamicPool(body.db)).rw : pool.rw;
    conn = await poolRef.getConnection();
    const storedRows = await conn.query(
      `SELECT node_type, owner_id, linked_blueprint_id, transformer_id, transformer_version
         FROM \`${t(TABLES.HIERARCHY_NODES)}\` WHERE id = ?`,
      [rowId],
    );
    // Unknown row → let the factory produce the 404.
    if (!storedRows.length) {
      conn.release(); conn = null;
      return next();
    }
    const stored = storedRows[0];
    // A non-blueprint never carries a link. Block a PUT that tries to introduce
    // one (a variant could otherwise smuggle linked_blueprint_id past the
    // factory); a PUT that doesn't touch the link passes straight through.
    if (stored.node_type !== 'blueprint') {
      const bodySetsLink = Object.prototype.hasOwnProperty.call(body, 'linked_blueprint_id')
        && linkTargetOf(body.linked_blueprint_id) != null;
      conn.release(); conn = null;
      if (bodySetsLink) {
        const e = apiError('Only blueprint nodes can be linked.', 'INVALID_LINK_TARGET', 400);
        return res.status(e.status).json(e.body);
      }
      return next();
    }
    // The post-write value of each column, decided by whether the body NAMES it.
    // A stored empty string names no row either (see linkTargetOf), which is
    // what lets a row this defect already produced be repaired rather than
    // permanently read as linked.
    let effLinked = effectiveLinkValue(body, stored, 'linked_blueprint_id');
    effLinkedForAudit = effLinked;
    const effTransformerId = effectiveLinkValue(body, stored, 'transformer_id');
    const effTransformerVersion = effectiveLinkValue(body, stored, 'transformer_version');
    // transformer_version without transformer_id is still transformer metadata.
    // Picked by presence, not by truthiness — see the create path above for the
    // pair a `||` here lets through.
    const effTransformer = effTransformerId != null ? effTransformerId : effTransformerVersion;

    // Grandfather a row that was ALREADY both-set in storage so the XOR guard
    // does not hard-block it — but ONLY for a write that does not actively
    // mutate the forbidden pair. Saving an unrelated field (or re-sending the
    // same values) is allowed; changing the transformer or link to a NEW value
    // while the other side stays set is still rejected (that keeps editing the
    // invalid combination rather than repairing it). Clearing one side needs no
    // grandfather — the cleared side makes `effTransformer`/`effLinked` null, so
    // the XOR condition below is simply not met. A write that newly introduces
    // the conflict on a previously-clean row is rejected (storedBothSet=false).
    const storedBothSet = linkTargetOf(stored.linked_blueprint_id) != null
      && (linkTargetOf(stored.transformer_id) != null
        || linkTargetOf(stored.transformer_version) != null);
    //
    // "DID THIS WRITE MOVE WHAT THE COLUMN NAMES" IS ASKED OF THE PARTY THAT
    // RESOLVES EACH COLUMN AFTERWARDS, which is not the same party for all
    // three of them.
    const names = (column) => Object.prototype.hasOwnProperty.call(body, column);
    // collation-compare: `linked_blueprint_id` names a ROW, and every reader of
    // it resolves that row with `WHERE id = ?`, which the engine answers under
    // the column's collation. A JavaScript `!==` called a case-variant resend of
    // the SAME id a change — so `allowExistingBothSet` flipped off and the save
    // was refused although it moved nothing. Measured: a legacy both-set row
    // could not be saved at all by a client echoing back the id it had been
    // given in another case, which is the one case the grandfather exists for.
    const linkChanged = names('linked_blueprint_id') && !(await sameStoredValue(
      conn, t(TABLES.HIERARCHY_NODES), 'linked_blueprint_id',
      linkTargetOf(body.linked_blueprint_id), linkTargetOf(stored.linked_blueprint_id),
    ));
    // byte-compare, and deliberately NOT the engine's answer — the RC-1 question
    // asked of a different party. A transformer is named by VALUE, not by row:
    // the file half of the registry is keyed by an author-chosen string that a
    // JavaScript lookup resolves exactly, and the picker matches the same way. A
    // respelling is not absorbed by the engine (it stores the new one), so a
    // resend in another case really does change which registry entry this row
    // names — which is the forbidden pair being mutated, not left alone.
    const transformerChanged = (names('transformer_id')
        && linkTargetOf(body.transformer_id) !== linkTargetOf(stored.transformer_id))
      || (names('transformer_version')
        && linkTargetOf(body.transformer_version) !== linkTargetOf(stored.transformer_version));
    const allowExistingBothSet = storedBothSet && !linkChanged && !transformerChanged;
    const err = await validateLinkConstraints(conn, rowId, 'blueprint', effLinked, effTransformer, allowExistingBothSet);
    if (err) {
      const e = apiError(err.message, err.code, err.status);
      return res.status(e.status).json(e.body);
    }

    const isTransition = linkTargetOf(stored.linked_blueprint_id) == null && effLinked != null;
    if (!isTransition) {
      // AND THE ANSWER IS BOUND TO WHAT THE STATEMENT WRITES, which is the half
      // the compare above did not carry. The engine calling two spellings one
      // stored value settles WHICH ROW is named; it does not settle WHICH BYTES
      // the column keeps, and it stores the new ones. This branch hands the body
      // to the factory, which binds `req.body`'s value verbatim, so that is the
      // object pointed at the row's own id. What the byte-wise readers of this
      // column do with the caller's spelling is stated on `storedNodeId`.
      //
      // When the engine says the write moves nothing the stored spelling is
      // already in hand and no lookup is needed; when it moves, the named row is
      // read for its id. The sibling column on this file's own PUT does the same
      // step ("if (!blueprintMoved) written.blueprint_id = oldRow.blueprint_id").
      // The transition branch below takes its own answer from the row it LOCKS,
      // so it adds no round trip here.
      if (names('linked_blueprint_id') && effLinked != null) {
        const targetId = linkChanged
          ? await storedNodeId(conn, effLinked)
          : linkTargetOf(stored.linked_blueprint_id);
        if (targetId != null) req.body.linked_blueprint_id = targetId;
      }
      conn.release(); conn = null;
      return next();
    }

    // Editor must own the blueprint (or it's shared). Mirrors the factory's
    // owner-scoped UPDATE; 404 on a foreign row (existence-leak parity).
    if (req.user.role === 'editor'
        && !(stored.owner_id == null || stored.owner_id === req.user.id)) {
      const e = apiError('Not found', 'NOT_FOUND', 404);
      return res.status(e.status).json(e.body);
    }

    await conn.beginTransaction();
    // Concurrency: re-assert the link invariant against the target INSIDE the
    // transaction with a row lock, so two reciprocal link writes (A→B and B→A)
    // can't both pass the pre-transaction validation and persist a cycle. The
    // lock serialises the reciprocal pair; the survivor sees the other's
    // committed link and is rejected here.
    const targetLock = await conn.query(
      `SELECT id, node_type, linked_blueprint_id FROM \`${t(TABLES.HIERARCHY_NODES)}\`
         WHERE id = ? FOR UPDATE`,
      [effLinked],
    );
    if (!targetLock.length || targetLock[0].node_type !== 'blueprint') {
      await conn.rollback();
      const e = apiError('Link target must be an existing blueprint.', 'INVALID_LINK_TARGET', 400);
      return res.status(e.status).json(e.body);
    }
    if (linkTargetOf(targetLock[0].linked_blueprint_id) != null) {
      await conn.rollback();
      const e = apiError(
        'Cannot link to a blueprint that is itself linked; link to its source instead.',
        'LINK_TO_LINKED', 409,
      );
      return res.status(e.status).json(e.body);
    }
    // THE ROW THE LOCK RESOLVED IS THE ROW THIS WRITE LINKS TO, so its own id is
    // what the UPDATE and the audit below bind — read here inside the
    // transaction and under the lock, rather than relying on the unlocked
    // normalisation above.
    effLinked = targetLock[0].id;
    effLinkedForAudit = effLinked;
    // Clear the now-unreachable own schema, leaf-first (mirrors overwriteBlueprint).
    // variant_overrides first — they reference this blueprint's variants + fields,
    // so leaving them would orphan against the about-to-be-deleted fields.
    await conn.query(
      `DELETE FROM \`${t(TABLES.VARIANT_OVERRIDES)}\`
         WHERE variant_id IN (
           SELECT id FROM \`${t(TABLES.HIERARCHY_NODES)}\`
             WHERE parent_id = ? AND node_type = 'variant'
         )`,
      [rowId],
    );
    await conn.query(
      `DELETE FROM \`${t(TABLES.FIELD_OPTIONS)}\`
         WHERE field_id IN (SELECT id FROM \`${t(TABLES.BLUEPRINT_FIELDS)}\` WHERE blueprint_id = ?)`,
      [rowId],
    );
    await conn.query(`DELETE FROM \`${t(TABLES.BLUEPRINT_FIELDS)}\` WHERE blueprint_id = ?`, [rowId]);
    await conn.query(`DELETE FROM \`${t(TABLES.BLUEPRINT_SECTIONS)}\` WHERE blueprint_id = ?`, [rowId]);
    // blueprint_groups is an additive engine table; skip on a pre-migration
    // target that lacks it (mirrors overwriteBlueprint). Without this the
    // now-unreachable own schema leaves orphan color-group rows behind.
    if (await tableExistsInCurrentSchema(conn, t(TABLES.BLUEPRINT_GROUPS))) {
      await conn.query(`DELETE FROM \`${t(TABLES.BLUEPRINT_GROUPS)}\` WHERE blueprint_id = ?`, [rowId]);
    }
    // decision_tables is likewise additive, and its rows are rules written
    // against THIS blueprint's field keys — which the DELETEs above just
    // removed. Leaving them behind strands them: the panel still lists them
    // (it filters on blueprint_id alone), every write is refused because the
    // parent is linked (409 for every role, so not even an admin can delete
    // them), and unlinking later revives them as live rules over a schema that
    // no longer exists. Probe-gated exactly like the groups step above.
    let decisionTablesCleared = 0;
    if (await tableExistsInCurrentSchema(conn, t(TABLES.DECISION_TABLES))) {
      const decisionRes = await conn.query(
        `DELETE FROM \`${t(TABLES.DECISION_TABLES)}\` WHERE blueprint_id = ?`,
        [rowId],
      );
      decisionTablesCleared = Number(decisionRes && decisionRes.affectedRows) || 0;
    }
    await conn.query(`DELETE FROM \`${t(TABLES.BLUEPRINT_OUTPUT_ORDER)}\` WHERE blueprint_id = ?`, [rowId]);

    const safeRole = ['admin', 'editor', 'user'].includes(req.user.role) ? req.user.role : 'unknown';
    await conn.query(
      `INSERT INTO \`${t(TABLES.FEATURE_AUDIT)}\` (id, event_type, user_id, metadata) VALUES (?, ?, ?, ?)`,
      [
        uuidv4(),
        'blueprint.linked.schema_cleared',
        req.user.id || null,
        JSON.stringify({
          blueprint_id: rowId,
          linked_blueprint_id: effLinked,
          actor_role: safeRole,
          decision_tables_cleared: decisionTablesCleared,
        }),
      ],
    );
    // From here a rollback would drop the schema_cleared row above; any rollback
    // path past this point re-records the attempt via auditSchemaClearFailed on a
    // fresh connection.
    clearAttempted = true;

    // Metadata update. Force transformer null (B5), strip server-authoritative
    // / non-editable keys, then gate by the actual column set (operator-mode).
    let data = { ...body };
    delete data.id;
    delete data.db;
    delete data.node_type;
    // parent_id is mutable only via the dedicated /reparent endpoint (cycle
    // guard + re-stamp + audit); a link-transition PUT must not smuggle a
    // reparent through this self-built UPDATE.
    delete data.parent_id;
    if (req.user.role !== 'admin') delete data.owner_id;
    data.linked_blueprint_id = effLinked;
    data.transformer_id = null;
    data.transformer_version = null;
    data = mapRowToDb('hierarchy_nodes', data);
    const colSet = await getActualColumnSet(conn, t(TABLES.HIERARCHY_NODES));
    const keys = gateKeysByColumnSet(data, colSet);
    if (!keys.length) {
      await conn.rollback();
      await auditSchemaClearFailed(poolRef, {
        userId: req.user && req.user.id, blueprintId: rowId,
        linkedBlueprintId: effLinked, reason: 'no_updatable_columns',
      });
      const e = apiError('No valid fields to update', 'BAD_REQUEST', 400);
      return res.status(e.status).json(e.body);
    }
    const sets = keys.map((k) => `\`${k}\` = ?`).join(', ');
    let updSql = `UPDATE \`${t(TABLES.HIERARCHY_NODES)}\` SET ${sets} WHERE id = ?`;
    const updParams = [...keys.map((k) => data[k]), rowId];
    if (req.user.role === 'editor') {
      updSql += ' AND (owner_id IS NULL OR owner_id = ?)';
      updParams.push(req.user.id);
    }
    const result = await conn.query(updSql, updParams);
    if (result.affectedRows === 0) {
      await conn.rollback();
      await auditSchemaClearFailed(poolRef, {
        userId: req.user && req.user.id, blueprintId: rowId,
        linkedBlueprintId: effLinked, reason: 'update_affected_zero_rows',
      });
      const e = apiError('Not found', 'NOT_FOUND', 404);
      return res.status(e.status).json(e.body);
    }
    await conn.commit();
    // The clear + link are durable past this point; a post-commit failure
    // (SELECT / mapping) must NOT write a schema_clear.failed audit.
    committed = true;
    const rows = await conn.query(`SELECT * FROM \`${t(TABLES.HIERARCHY_NODES)}\` WHERE id = ?`, [rowId]);
    return res.json(apiOk(mapRowsFromDb('hierarchy_nodes', rows)[0]));
  } catch (e) {
    if (conn) {
      try { await conn.rollback(); } catch (rbErr) {
        logger.warn({ err: rbErr }, 'rollback after hierarchy_node link transition failed');
      }
    }
    if (clearAttempted && !committed && poolRef) {
      await auditSchemaClearFailed(poolRef, {
        userId: req.user && req.user.id, blueprintId: rowId,
        linkedBlueprintId: effLinkedForAudit, reason: 'exception',
      });
    }
    logger.error({ err: e, rowId }, 'Failed link transition on hierarchy_node update');
    const er = apiError('Database operation failed', 'INTERNAL_ERROR');
    return res.status(er.status).json(er.body);
  } finally {
    if (conn) conn.release();
  }
});
}

module.exports = { register, isPayloadInconsistent, validateComputeRuleBeforeWrite };
