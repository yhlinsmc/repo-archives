const {
  TABLES,
  VARIANT_OVERRIDE_ACTIONS,
  pool,
  t,
  getDynamicPool,
  apiOk,
  apiError,
  requireAuth,
  requireAdmin,
  requireAdminOrEditor,
  isOwnerOrAdmin,
  uuidv4,
  UUID_RE,
  mapRowFromDb,
  mapRowsFromDb,
  mapRowToDb,
  previewCascade,
  cascadeDeleteNode,
  collectDescendantIds,
  tableExistsInCurrentSchema,
  buildVariantOverrideUpdateExistsClause,
  buildVariantOverrideInsertExistsClause,
  buildDuplicateActionTripleNotExistsClause,
  buildVariantOverrideContextSql,
  applyOwnerChange,
  enrichOwnerNames,
  validateComputeRule,
  detectCycle,
  parseStoredRule,
  extractComputeSources,
  buildEffectiveRules,
  loadBlueprintComputeState,
  loadBlueprintFieldMode,
  loadBlueprintFieldScopes,
  loadBlueprintFieldComputeRule,
  buildColumnComputeNodes,
  hasColumnCycle,
  hasRowContextSource,
  invalidChoiceConfigShape,
  invalidCellTargetsShape,
  hasCellScope,
  scopeNamesSingleColumn,
  resolveAncestors,
  restampTemplates,
  countAffectedTemplates,
  isValidBlueprintParent,
  logger,
  HIERARCHY_OWNER_AUDIT_EVENT,
  USER_TEMPLATE_OWNER_AUDIT_EVENT,
  resolveOwnershipRwPool,
  cascadeBlueprintOwnerToVariants,
  SAFE_COL_RE,
  isSafeColumnName,
  SLUG_KEY_PATTERN,
  isValidSlugKey,
  isBlueprintLinked,
  isBlueprintLinkedLocked,
  isLinkedParentLocked,
  auditSchemaClearFailed,
  validateLinkConstraints,
  resolveLinkCheckBlueprintId,
  _columnSetCache,
  getConnDatabaseName,
  getActualColumnSet,
  _historyTableCache,
  isCodeVersionHistoryAvailable,
  gateKeysByColumnSet,
  TABLE_VALUES,
  validateCodeVersioning,
  isMissingTableOrColumn,
  _codeVersioningDegraded,
  warnCodeVersioningDegradedOnce,
  validateAndPrepareParentOwnership,
  validateAndPrepareParentRepend,
  buildChainSelectSql,
  buildChainExistsForRow,
  ENCRYPTION_GATE_422,
  runSerializeWrite,
  editorMayWriteBlueprint,
  MAX_BATCH_FIELD_IDS,
  MAX_BATCH_BLUEPRINT_IDS,
} = require('./helpers');
const {
  VALUE_WRITING_ACTIONS, refuseCellWriteOverBlueprintLock,
} = require('../../../lib/blueprint-cell-lock');
const { overrideConflictWarnings } = require('../../../../shared/override-conflicts');
const { callerHasBlueprintGrant, grantsTableAvailable } = require('../../../lib/delegated-grants');


// Variant overrides require both FKs to resolve to the same blueprint before
// any write. Inline POST/PUT because two-FK coherence is not expressible in
// the chain DSL's single-FK shape; admin bypasses ownership only, not
// coherence. DELETE falls through to the factory chain DSL (variant_id 2-hop
// self-join) — no coherence check on deletion since cleanup of incoherent
// legacy rows is the correct cleanup action.
//
// `action` is an enum the UI's policy renderer depends on; editor writes
// must whitelist to prevent ACTION_ICONS crashes from arbitrary strings.
// 'compute' is validated separately: it requires a well-formed compute_rule
// and passes validateComputeRule + detectCycle before reaching the DB.
// Canonical set lives in shared/constants.js so the boot-time cleanup in
// edge/db.js derives the same allowlist (no drift → no silent row deletion).

async function loadVariantOverrideContext(conn, variantId, fieldId) {
  if (!variantId || !fieldId) return null;
  let rows;
  try {
    rows = await conn.query(
      buildVariantOverrideContextSql({ t, TABLES }),
      [fieldId, variantId],
    );
  } catch (err) {
    // `value_source` is an additive warn-severity column (migration-steps.js
    // blueprint_fields_value_source_add) and can be physically absent on a DB
    // whose operator lacked DDL privilege for that ALTER. ER_BAD_FIELD_ERROR
    // 500s every override write unless retried without it; the caller's
    // conflict check already treats an absent `field_value_source` as "no
    // signal" the same way a stored NULL would read.
    if (!isMissingTableOrColumn(err)) throw err;
    rows = await conn.query(
      buildVariantOverrideContextSql({ t, TABLES, includeValueSource: false }),
      [fieldId, variantId],
    );
  }
  return rows[0] || null;
}


// Cell scoping addresses rows x columns of a table field. On any other field
// type the document is structurally valid but inert, which makes it a silent
// authoring mistake rather than a narrower override — the same class of mistake
// blueprint_fields already rejects for table_config on a non-table field.
// Returns null on pass, or { status, error } on fail.
function validateCellTargetsFieldType(cellTargets, ctx) {
  if (!hasCellScope(cellTargets)) return null;
  if (ctx.field_type === 'table') return null;
  return {
    status: 400,
    error: `field_type='${ctx.field_type}' must not carry cell_targets`,
  };
}


// A cell-scoped override that WRITES A VALUE may not reach into cells the
// field's own setting holds read-only. Both halves of that sentence — which
// cells the setting covers, and which actions write a value — live in
// edge/lib/blueprint-cell-lock.js, with the reasoning; this is the one place
// that asks. Only the narrowed, value-writing shapes pay the extra single-row
// read: `hasCellScope` is deliberately the looser of the two readings (it counts
// an empty `rows: []` as a scope, which the resolver reads as whole-field), so
// using it as the pre-filter can waste a read but can never skip a refusal.
// Returns null on pass, or { status, error } on fail.
async function checkBlueprintCellLock(conn, action, cellTargets, fieldId) {
  if (!VALUE_WRITING_ACTIONS.includes(action) || !hasCellScope(cellTargets)) return null;
  const blueprintMode = await loadBlueprintFieldMode(conn, fieldId, { t, TABLES });
  return refuseCellWriteOverBlueprintLock(action, cellTargets, blueprintMode);
}


// Shared validator: returns null on pass, or { status, error } on fail.
// Coherence is a data-integrity invariant; admin must obey it. Ownership
// is a permission invariant; admin bypasses.
function validateVariantOverrideContext(ctx, role, userId, opts = {}) {
  if (!ctx || ctx.variant_node_type !== 'variant') {
    return { status: 404, error: 'parent_not_found' };
  }
  if (ctx.field_blueprint_id == null) {
    return { status: 404, error: 'parent_not_found' };
  }
  // Broken parent chain: variant.parent_id points at a row that no longer
  // exists. The factory chain DSL denies this branch outright; mirror that
  // semantic. Without this, an orphan-chain editor write would slip through
  // because the LEFT JOIN'd `blueprint_owner_id` is NULL (no row), which
  // the next branch would otherwise treat as a shared blueprint.
  if (ctx.blueprint_exists == null) {
    return { status: 404, error: 'parent_not_found' };
  }
  if (ctx.variant_blueprint_id !== ctx.field_blueprint_id) {
    return { status: 422, error: 'cross_blueprint_coherence_violation' };
  }
  // Shared blueprints (owner_id NULL on a row that DOES exist) are
  // editor-writable; mirrors the checkParentOwnership semantic on sibling
  // child tables. Editor-owned blueprints match by id. Admin bypasses.
  if (role === 'editor'
      && ctx.blueprint_owner_id != null
      && ctx.blueprint_owner_id !== userId
      && !opts.hasBlueprintGrant) {          // spec §6.1: owner OR admin OR grant
    return { status: 403, error: 'not_owner' };
  }
  return null;
}


// Loads the data needed to validate a compute_rule for a given field within
// a blueprint+variant. Called from POST and PUT when action==='compute'.
// Returns { fieldKeys, targetType, targetFieldKey, existingRulesMap,
//           tableColumns, columnSourcesBase, targetBlueprintRule,
//           targetBlueprintScope }
// or null if the field cannot be resolved (caller should 404).
// existingRulesMap is the EFFECTIVE rule set this variant evaluates: blueprint-
// level rules with the variant's own compute overrides laid on top (field-
// level: variant REPLACES blueprint for the field it overrides).
//
// P1b's column-cycle check does NOT use that same replacement — a table
// field's blueprint mode and a variant's own override on the SAME field can
// be simultaneously ACTIVE, each governing the cells the OTHER does not name
// (`cell-targets.ts`'s `cellVerdict`), so `columnSourcesBase` is the UNION of
// every OTHER field's blueprint-level AND variant-level row-context
// candidates (`buildColumnComputeNodes`'s doc-block has the full reasoning).
// `targetBlueprintRule`/`targetBlueprintScope` are the ONE thing that map
// excludes: the field THIS request is about, read un-excluded so the caller
// can add it back as its OWN candidate alongside the incoming rule — the
// literal P1b repro (an existing blueprint rule on column A survives a NEW
// variant override narrowed to column B of the SAME field).
//
// `incomingRuleIsRowContext` (caller-supplied — `hasRowContextSource` on the
// write's own compute_rule, known before this function ever runs) gates
// whether the column-cycle context is built AT ALL: with it false and no
// ALREADY-STORED rule in this graph row-context either, a column cycle is
// structurally impossible and every one of the extra reads below is skipped.
async function loadComputeValidationContext(conn, variantId, fieldId, blueprintId, incomingRuleIsRowContext = false) {
  // Target field's own key + type — queried by id for exact match.
  const targetFieldRows = await conn.query(
    `SELECT field_key, field_type FROM \`${t(TABLES.BLUEPRINT_FIELDS)}\` WHERE id = ?`,
    [fieldId],
  );
  if (!targetFieldRows.length) return null;
  const { field_key: targetFieldKey, field_type: rawType } = targetFieldRows[0];
  // NOTE: only 'number' fields are numeric; every other field_type (text,
  // select, textarea, checkbox, table — and any future addition) maps to
  // 'string'. A new numeric field_type must be added here explicitly.
  const targetType = rawType === 'number' ? 'number' : 'string';

  // One scan of the blueprint's fields answers both halves: all field_keys (for
  // the source-exists check) with the per-table column allowlist, and the
  // blueprint-level rules the cycle graph starts from.
  // INVARIANT (precedence): a variant-level compute override REPLACES the
  // blueprint-level rule for that field in this variant. A replaced rule never
  // evaluates here, so it must contribute no edges — otherwise a graph that is
  // actually acyclic would be rejected. The target field's blueprint rule is
  // replaced too: the incoming rule is about to take its place for this variant.
  const {
    fieldRows, fieldKeys, tableColumns, rules: blueprintRulesMap,
  } = await loadBlueprintComputeState(conn, blueprintId, {
    t, TABLES, excludeFieldKey: targetFieldKey,
  });
  if (!fieldRows.length) return null;

  // This variant's own compute overrides in the same blueprint (for cycle
  // detection), WITH their cell_targets (P1b's column-narrowing counterpart).
  // Excludes the target field's own key so the incoming rule/scope can
  // replace it on PUT without incorrectly including the stale version in the
  // cycle graph. cell_targets is an additive column read the same
  // operator-mode-tolerant way every other read of it is: probe first, fall
  // back to a query that never names it so 1054 cannot take the whole guard
  // down.
  const voColSet = await getActualColumnSet(conn, t(TABLES.VARIANT_OVERRIDES));
  const hasCellTargetsCol = voColSet === null || voColSet.has('cell_targets');
  const existingRows = await conn.query(
    `SELECT bf.field_key, vo.compute_rule${hasCellTargetsCol ? ', vo.cell_targets' : ''}
       FROM \`${t(TABLES.VARIANT_OVERRIDES)}\` vo
       JOIN \`${t(TABLES.BLUEPRINT_FIELDS)}\`  bf ON bf.id = vo.field_id
      WHERE vo.variant_id = ?
        AND bf.blueprint_id = ?
        AND vo.action = 'compute'
        AND vo.compute_rule IS NOT NULL`,
    [variantId, blueprintId],
  );
  const variantRulesMap = new Map();
  const variantCellTargets = new Map();
  for (const row of existingRows) {
    if (row.field_key === targetFieldKey) continue; // excluded — replaced by incoming rule
    const rule = parseStoredRule(row.compute_rule);
    if (rule) variantRulesMap.set(row.field_key, rule);
    if (hasCellTargetsCol) variantCellTargets.set(row.field_key, row.cell_targets ?? null);
  }

  // A blueprint-level compute rule applies to every variant that does not carry
  // its own compute override on the same field, so a cycle can span both levels
  // and the guard is blind to it if it only reads variant_overrides.
  const existingRulesMap = buildEffectiveRules(blueprintRulesMap, variantRulesMap);

  // P1b: only worth asking when a column-level cycle is even POSSIBLE — the
  // incoming rule reads a same-table column, or some rule already stored in
  // THIS graph (blueprint-level or this variant's own overrides) already
  // does. A graph with no `same_table_column` rule anywhere can never close
  // a column cycle, so an ordinary (field-level-only) write pays nothing
  // extra for any of this — no scan, no per-field read.
  const mayHaveColumnCycle = incomingRuleIsRowContext
    || [...blueprintRulesMap.values()].some(hasRowContextSource)
    || [...variantRulesMap.values()].some(hasRowContextSource);

  let columnSourcesBase = [];
  let targetBlueprintRule = null;
  let targetBlueprintScope = null;
  if (mayHaveColumnCycle) {
    // Every OTHER field's stored `value_scope` — `null` (column unreadable)
    // reads as "narrows nothing anywhere", the same fail-closed reading
    // `judgeRuleRows` already gives it.
    const scopesByFieldKey = await loadBlueprintFieldScopes(conn, blueprintId, { t, TABLES });
    // UNION (not replace) — every OTHER field's blueprint-level candidate
    // AND its variant-level candidate (when one exists) both enter the pool;
    // `buildColumnComputeNodes` decides per-candidate whether it is really
    // row-context and single-column-linkable.
    columnSourcesBase = [
      ...[...blueprintRulesMap].map(([fieldKey, rule]) => ({
        node: `${fieldKey}::blueprint`, tableKey: fieldKey, rule, columns: scopesByFieldKey?.get(fieldKey) ?? null,
      })),
      ...(hasCellTargetsCol
        ? [...variantRulesMap].map(([fieldKey, rule]) => ({
            node: `${fieldKey}::variant`, tableKey: fieldKey, rule, columns: variantCellTargets.get(fieldKey) ?? null,
          }))
        : []),
    ];
    // The target field's OWN blueprint rule, un-excluded — the caller adds
    // it back alongside the incoming rule so an existing blueprint-level
    // column formula on this same field is not dropped from the graph just
    // because this request is about to add (or replace) the variant's own.
    targetBlueprintRule = await loadBlueprintFieldComputeRule(conn, fieldId, { t, TABLES });
    targetBlueprintScope = scopesByFieldKey?.get(targetFieldKey) ?? null;
  }

  return {
    fieldKeys, targetType, targetFieldKey, existingRulesMap, tableColumns,
    columnSourcesBase, targetBlueprintRule, targetBlueprintScope,
  };
}

function register(router) {

// Batch read of variant_overrides for many variant ids. Replaces a repeated
// `?variant_id=a&variant_id=b` GET filter, which matches ZERO rows on a real
// deployment: the infra->edge proxy folds repeated query parameters into one
// comma-joined scalar, and the generic list handler then runs an equality match
// against `'a,b'`. That failure is silent — no error, just an empty result —
// so the id list rides in the POST body, exactly as the sibling
// `field_options/by-fields` and `blueprint_fields/by-blueprints` batches do.
//
// Read-only (requireAuth, RO pool) — the same access contract as the generic
// `/variant_overrides` list, whose allowedRoles gates writes only. Rows are
// ordered by variant_id so a caller can regroup deterministically.
//
// Registered BEFORE the `/variant_overrides` CRUD mount so `by-variants` is not
// parsed as `/variant_overrides/:id`.
router.post('/variant_overrides/by-variants', async (req, res) => {
  if (!requireAuth(req, res)) return;
  const { variant_ids: variantIds } = req.body || {};
  if (!Array.isArray(variantIds)) {
    const e = apiError('variant_ids must be an array', 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }
  if (variantIds.length === 0) return res.json(apiOk([]));
  if (variantIds.length > MAX_BATCH_BLUEPRINT_IDS) {
    const e = apiError(`variant_ids exceeds ${MAX_BATCH_BLUEPRINT_IDS} limit`, 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }
  if (!variantIds.every((id) => typeof id === 'string' && id.length > 0)) {
    const e = apiError('variant_ids must be non-empty strings', 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }

  const tableName = t(TABLES.VARIANT_OVERRIDES);
  const dynamicDb = req.body && req.body.db;
  let conn;
  try {
    conn = dynamicDb
      ? await (await getDynamicPool(dynamicDb)).ro.getConnection()
      : await pool.ro.getConnection();
    const placeholders = variantIds.map(() => '?').join(', ');
    // Operator-mode gate: compute_rule and cell_targets are additive columns
    // whose migration entries are severity 'warning', so a DB whose account could
    // not run the ALTER keeps working with them absent. Naming an absent column in
    // this SELECT throws ER_BAD_FIELD_ERROR (1054), which the generic catch below
    // would surface as a blanket 500 instead of degrading — the same read-side
    // gap the sibling PUT handler already closes. Drop only the columns the
    // physical table lacks; probe-null (unknown set) keeps both, so a normal-mode
    // read is byte-identical, and the 1054 fallback covers the compound case
    // (probe blind AND a column really absent). mapRowsFromDb defaults an omitted
    // optional column to what the column's own default means.
    const colSet = await getActualColumnSet(conn, tableName);
    const hasComputeRule = colSet === null || colSet.has('compute_rule');
    const hasCellTargets = colSet === null || colSet.has('cell_targets');
    const optionalCols = `${hasComputeRule ? ', compute_rule' : ''}${hasCellTargets ? ', cell_targets' : ''}`;
    let rows;
    try {
      rows = await conn.query(
        `SELECT id, variant_id, field_id, action, override_value${optionalCols}, created_at
           FROM \`${tableName}\`
          WHERE variant_id IN (${placeholders})
          ORDER BY variant_id`,
        variantIds,
      );
    } catch (readErr) {
      // Only fall back if we DID name an optional column and the DB rejected it;
      // otherwise the 1054 is about something else and must surface.
      if ((!hasComputeRule && !hasCellTargets) || !isMissingTableOrColumn(readErr)) throw readErr;
      rows = await conn.query(
        `SELECT id, variant_id, field_id, action, override_value, created_at
           FROM \`${tableName}\`
          WHERE variant_id IN (${placeholders})
          ORDER BY variant_id`,
        variantIds,
      );
    }
    res.json(apiOk(mapRowsFromDb(TABLES.VARIANT_OVERRIDES, rows)));
  } catch (err) {
    logger.error({ err }, 'Failed to batch-read variant_overrides by variant ids');
    const e = apiError('Database operation failed', 'INTERNAL_ERROR');
    res.status(e.status).json(e.body);
  } finally {
    if (conn) conn.release();
  }
});

router.post('/variant_overrides', async (req, res) => {
  if (!requireAdminOrEditor(req, res)) return;
  try {
    const data = { ...req.body };
    // SECURITY: always server-generate the id; never trust a client-supplied
    // one (see the generic create handler for the rationale).
    delete data.id;
    data.id = uuidv4();
    delete data.db;

    const { variant_id, field_id, action } = data;
    if (!variant_id || !field_id) {
      const e = apiError('variant_id and field_id are required', 'BAD_REQUEST', 400);
      return res.status(e.status).json(e.body);
    }
    // SAFETY: action is a closed enum that the UI policy renderer indexes
    // by value; an arbitrary string (or null) crashes ACTION_ICONS and
    // breaks the apply-time switch in useResolvedFields.ts (NULL silently
    // becomes "no override" — inert dead data). All roles must provide
    // exactly one of the allowlist values; admin had no guard before
    // because it was never a designed feature, only a missed validator.
    if (action === undefined || action === null) {
      const e = apiError(
        `action is required; allowed values: ${VARIANT_OVERRIDE_ACTIONS.join(', ')}`,
        'BAD_REQUEST', 400,
      );
      return res.status(e.status).json(e.body);
    }
    if (!VARIANT_OVERRIDE_ACTIONS.includes(action)) {
      const e = apiError(
        `action='${action}' is not allowed; allowed values: ${VARIANT_OVERRIDE_ACTIONS.join(', ')}`,
        'BAD_REQUEST', 400,
      );
      return res.status(e.status).json(e.body);
    }
    // SECURITY: the INSERT column list below is built from the request body, so
    // an unvalidated cell_targets document would be persisted verbatim and then
    // consumed by the apply layer. Shape-check before anything reaches the DB.
    const badCellTargets = invalidCellTargetsShape(data.cell_targets);
    if (badCellTargets) {
      const e = apiError(badCellTargets, 'INVALID_CELL_TARGETS', 400);
      return res.status(e.status).json(e.body);
    }

    const conn = await ((req.body && req.body.db) ? (await getDynamicPool(req.body.db)).rw : pool.rw).getConnection();
    try {
      const ctx = await loadVariantOverrideContext(conn, variant_id, field_id);
      // S3-A: a linked blueprint borrows the source's schema, so its variants'
      // overrides are read-only here — create them on the source. 409 before
      // coherence so the cross-blueprint case surfaces as a clear READONLY
      // message instead of a confusing 422.
      // SAFETY: ctx == null (unknown variant) or variant_blueprint_id == null
      // (orphaned variant) means "not linked" here — those cases are still
      // blocked downstream by validateVariantOverrideContext (404), so the only
      // effect of this guard is to upgrade the linked case to a clearer 409.
      if (ctx && ctx.variant_blueprint_id != null
          && await isBlueprintLinked(conn, ctx.variant_blueprint_id)) {
        const e = apiError(
          'Cannot add a variant override on a linked blueprint; add it on the source blueprint instead',
          'LINKED_BLUEPRINT_READONLY', 409,
        );
        return res.status(e.status).json(e.body);
      }
      // spec §6.1: an editor who is not the owner may still write under a
      // blueprint they hold a grant on. Resolved by the engine (the grant
      // EXISTS) rather than a JavaScript owner compare — the owner arm inside
      // validateVariantOverrideContext still admits the owner, so computing the
      // grant for an owner too costs one empty SELECT and adds no JS owner gate.
      const hasBlueprintGrant = req.user.role === 'editor' && ctx && ctx.field_blueprint_id != null
        ? await callerHasBlueprintGrant(conn, req.user.id, ctx.field_blueprint_id, req.user.role)
        : false;
      const fail = validateVariantOverrideContext(ctx, req.user.role, req.user.id, { hasBlueprintGrant });
      if (fail) {
        const e = apiError(fail.error, fail.error.toUpperCase(), fail.status);
        return res.status(e.status).json(e.body);
      }

      // Field-type gate for cell_targets — needs the resolved field, so it runs
      // after coherence; the cheap shape check above already ran before any DB
      // work was done.
      const badFieldType = validateCellTargetsFieldType(data.cell_targets, ctx);
      if (badFieldType) {
        const e = apiError(badFieldType.error, 'INVALID_CELL_TARGETS', badFieldType.status);
        return res.status(e.status).json(e.body);
      }

      // A narrowed override that writes a value may not reach cells the field's
      // own setting holds read-only — for `autofill` as much as for `compute`,
      // so the check sits outside the compute-only block below.
      const badLock = await checkBlueprintCellLock(conn, action, data.cell_targets, field_id);
      if (badLock) {
        const e = apiError(badLock.error, 'BLUEPRINT_COMPUTE_LOCK', badLock.status);
        return res.status(e.status).json(e.body);
      }

      // SAFETY: compute_rule validation — runs after coherence so blueprintId
      // is known-good. Operator-supplied compute_rule must NEVER reach the DB
      // without passing validateComputeRule + detectCycle.
      if (action === 'compute') {
        const computeCtx = await loadComputeValidationContext(
          conn, variant_id, field_id, ctx.variant_blueprint_id, hasRowContextSource(data.compute_rule),
        );
        if (!computeCtx) {
          const e = apiError('field_id could not be resolved', 'BAD_REQUEST', 400);
          return res.status(e.status).json(e.body);
        }
        // C1: a `same_table_column` term is only runnable on a write narrowed
        // to a column of THIS override's own `cell_targets` — already shape-
        // checked above, before any DB work, so it is safe to read verbatim.
        // P2: EXACTLY one column — see `scopeNamesSingleColumn`'s doc-block.
        const ruleResult = validateComputeRule(data.compute_rule, {
          fieldKeys: computeCtx.fieldKeys,
          targetType: computeCtx.targetType,
          tableColumns: computeCtx.tableColumns,
          ownerFieldKey: computeCtx.targetFieldKey,
          narrowedToColumn: scopeNamesSingleColumn(data.cell_targets),
        });
        if (!ruleResult.ok) {
          // Use the validator code as the stable HTTP code (e.g. 'unknown_op',
          // 'missing_source', 'output_type_mismatch'). Clients key on error.code.
          // `detail` is present when the reason needs a number to be actionable
          // (a size limit); otherwise the code is the message, as before.
          const e = apiError(ruleResult.detail || ruleResult.code, ruleResult.code, 400);
          return res.status(e.status).json(e.body);
        }
        // Cycle detection: add incoming rule to the existing map, then check.
        computeCtx.existingRulesMap.set(computeCtx.targetFieldKey, data.compute_rule);
        const cycleResult = detectCycle(computeCtx.existingRulesMap, extractComputeSources);
        if (!cycleResult.ok) {
          const e = apiError(cycleResult.code, cycleResult.code, 400);
          return res.status(e.status).json(e.body);
        }
        // P1b: column-level cycle over the UNION of every candidate (see
        // `loadComputeValidationContext`'s doc-block) plus THIS write's own
        // incoming rule/cell_targets AND — separately — the target field's
        // existing blueprint-level rule, which stays active for whatever
        // cells this write's own cell_targets does not name.
        const columnSources = [
          ...computeCtx.columnSourcesBase,
          ...(computeCtx.targetBlueprintRule ? [{
            node: `${computeCtx.targetFieldKey}::blueprint`,
            tableKey: computeCtx.targetFieldKey,
            rule: computeCtx.targetBlueprintRule,
            columns: computeCtx.targetBlueprintScope,
          }] : []),
          {
            node: `${computeCtx.targetFieldKey}::variant`,
            tableKey: computeCtx.targetFieldKey,
            rule: data.compute_rule,
            columns: data.cell_targets,
          },
        ];
        const columnNodes = buildColumnComputeNodes(columnSources);
        if (hasColumnCycle(computeCtx.existingRulesMap, columnNodes, extractComputeSources)) {
          const e = apiError('same_table_column_cycle', 'same_table_column_cycle', 400);
          return res.status(e.status).json(e.body);
        }
        // compute rows store the rule in compute_rule; override_value is empty.
        data.override_value = '';
      } else {
        // SECURITY: a non-compute action must never persist an unvalidated
        // compute_rule. Strip any stray rule the client sent so it cannot
        // bypass validateComputeRule by piggybacking on a lock/hide/autofill write.
        delete data.compute_rule;
      }

      const mapped = mapRowToDb('variant_overrides', data);
      // Operator-mode gate: cell_targets is an additive column whose migration
      // entry is severity 'warning', so a DB whose account could not run the
      // ALTER keeps working with the column absent. Naming an absent column here
      // throws ER_BAD_FIELD_ERROR (1054), which nothing below special-cases —
      // it would surface as a 500 instead of degrading to whole-field scope.
      // probe-null (unknown set) keeps every key, so a normal-mode INSERT is
      // byte-identical.
      const colSet = await getActualColumnSet(conn, t(TABLES.VARIANT_OVERRIDES));
      const keys = gateKeysByColumnSet(mapped, colSet);
      if (!keys.length) {
        const e = apiError('No valid fields provided', 'BAD_REQUEST', 400);
        return res.status(e.status).json(e.body);
      }
      const placeholders = keys.map(() => '?').join(', ');
      const cols = keys.map((k) => `\`${k}\``).join(', ');

      // SAFETY: TOCTOU race-only INSERT guard. Two AND-joined predicates:
      //   (a) post-state coherence — same invariants as
      //       validateVariantOverrideContext, evaluated at INSERT time so a
      //       concurrent owner-transfer / parent flip / node_type flip
      //       between the pre-INSERT load and this INSERT cannot slip a
      //       write through.
      //   (b) triple uniqueness — best-effort guard against double-insert
      //       of the same (variant_id, field_id, action). Without UNIQUE,
      //       two microsecond-concurrent racers can both pass NOT EXISTS;
      //       Phase B is the structural fix, this is the typical-case net.
      // The NOT EXISTS subquery wraps the target-table read in a derived
      // subquery to side-step MariaDB ER_UPDATE_TABLE_USED 1093 on
      // INSERT...SELECT self-reference. FROM (SELECT 1) AS insert_src
      // replaces FROM dual for portability. Pre-INSERT context check
      // above retains the clean 404/403/422 user-facing UX; this clause
      // exists only to close the race window.
      // spec §6.1/§6.4a: the INSERT is the second write path — widen its editor
      // owner predicate to "owner OR blueprint grant" so a grantee's INSERT is
      // not refused (0 rows → 409) after passing the pre-check. Gated on the
      // grants table being present; on a DB without it the clause is unchanged.
      const insertIncludesGrant = req.user.role === 'editor' && await grantsTableAvailable(conn);
      const post = buildVariantOverrideInsertExistsClause({
        role: req.user.role,
        variantId: variant_id,
        fieldId: field_id,
        userId: req.user.id,
        includeGrant: insertIncludesGrant,
        t,
        TABLES,
      });
      const triple = buildDuplicateActionTripleNotExistsClause({
        variantId: variant_id,
        fieldId: field_id,
        action,
        t,
        TABLES,
      });
      const result = await conn.query(
        `INSERT INTO \`${t(TABLES.VARIANT_OVERRIDES)}\` (${cols})
         SELECT ${placeholders} FROM (SELECT 1) AS insert_src
         WHERE ${post.clause} AND ${triple.clause}`,
        [...keys.map((k) => mapped[k]), ...post.params, ...triple.params],
      );

      if (result.affectedRows === 0) {
        // Disambiguate: triple already exists (409 duplicate_exists) vs
        // coherence raced (409 race_detected). Re-query under autocommit
        // (each conn.query is its own statement; fresh read view).
        const dupExists = await conn.query(
          `SELECT 1 FROM \`${t(TABLES.VARIANT_OVERRIDES)}\`
           WHERE variant_id <=> ? AND field_id <=> ? AND action <=> ? LIMIT 1`,
          [variant_id, field_id, action],
        );
        if (dupExists.length > 0) {
          const e = apiError('duplicate_exists', 'DUPLICATE_EXISTS', 409);
          return res.status(e.status).json(e.body);
        }
        const e = apiError('race_detected', 'RACE_DETECTED', 409);
        return res.status(e.status).json(e.body);
      }

      const rows = await conn.query(
        `SELECT * FROM \`${t(TABLES.VARIANT_OVERRIDES)}\` WHERE id = ?`,
        [mapped.id],
      );
      const created = mapRowsFromDb('variant_overrides', rows)[0];
      // Warn-but-allow (spec §5): the two conflict shapes are legal writes
      // that just do less than they look like they do, so they surface on
      // this 200 rather than blocking it. `retain_when_hidden` defaults
      // false — a missing read (degraded schema, unknown field) must fail
      // loud into the warned state, not silently suppress the warning.
      const warnings = overrideConflictWarnings({
        action,
        blueprintValueSource: ctx.field_value_source ?? null,
        isRequired: !!ctx.is_required,
        retainWhenHidden: !!ctx.retain_when_hidden,
      });
      res.json(warnings.length ? apiOk({ ...created, warnings }) : apiOk(created));
    } finally {
      conn.release();
    }
  } catch (err) {
    // SAFETY: the uq_variant_override_triple UNIQUE constraint throws
    // ER_DUP_ENTRY 1062 from the INSERT itself when a microsecond race
    // slips past the application-layer NOT EXISTS pre-flight. The
    // happy-path affectedRows===0 disambiguation only fires for the
    // pre-existing-row case; a true race where two parallel transactions
    // both pass NOT EXISTS surfaces here. Map 1062 to the same 409
    // duplicate_exists response so race semantics are role-agnostic and
    // tested via SQL-level integration coverage.
    if (err && err.errno === 1062) {
      const e = apiError('duplicate_exists', 'DUPLICATE_EXISTS', 409);
      return res.status(e.status).json(e.body);
    }
    logger.error({ err }, 'Failed to create variant_override');
    const e = apiError('Database operation failed', 'INTERNAL_ERROR');
    res.status(e.status).json(e.body);
  }
});


router.put('/variant_overrides/:id', async (req, res) => {
  if (!requireAdminOrEditor(req, res)) return;
  try {
    const body = { ...req.body };
    delete body.id;
    delete body.db;

    // SAFETY: PATCH-style PUT — action is optional in the body, but when
    // present it must be a valid allowlist value for any role. Explicit
    // null is rejected (an admin attempt to clear action would leave an
    // inert no-override row that the apply layer silently ignores).
    if (Object.prototype.hasOwnProperty.call(body, 'action')) {
      if (body.action === null) {
        const e = apiError('action may not be null', 'BAD_REQUEST', 400);
        return res.status(e.status).json(e.body);
      }
      if (!VARIANT_OVERRIDE_ACTIONS.includes(body.action)) {
        const e = apiError(
          `action='${body.action}' is not allowed; allowed values: ${VARIANT_OVERRIDE_ACTIONS.join(', ')}`,
          'BAD_REQUEST', 400,
        );
        return res.status(e.status).json(e.body);
      }
    }

    // SECURITY: same guard as POST — the UPDATE SET list is built from the body.
    // Key-presence gated so a PATCH-style PUT that omits cell_targets leaves the
    // stored scope untouched, while an explicit null clears it back to
    // whole-field.
    if (Object.prototype.hasOwnProperty.call(body, 'cell_targets')) {
      const badCellTargets = invalidCellTargetsShape(body.cell_targets);
      if (badCellTargets) {
        const e = apiError(badCellTargets, 'INVALID_CELL_TARGETS', 400);
        return res.status(e.status).json(e.body);
      }
    }

    const conn = await ((req.body && req.body.db) ? (await getDynamicPool(req.body.db)).rw : pool.rw).getConnection();
    try {
      // Probe the actual column set BEFORE the old-row read. The post-state
      // field-type gate below has to judge the STORED cell_targets (a PUT that
      // only repoints field_id carries none of its own), but cell_targets is an
      // additive column whose migration entry is severity 'warning': on a DB that
      // could not run the ALTER, naming it here throws ER_BAD_FIELD_ERROR (1054)
      // and would 500 every override edit. probe-null (unknown set) keeps the
      // column so a normal-mode read still carries it, and the 1054 fallback
      // covers the compound case (probe blind AND column really absent). The same
      // colSet is reused for the UPDATE gate below — no second probe.
      const colSet = await getActualColumnSet(conn, t(TABLES.VARIANT_OVERRIDES));
      const hasCellTargetsCol = colSet === null || colSet.has('cell_targets');
      let oldRows;
      try {
        oldRows = await conn.query(
          `SELECT id, variant_id, field_id, action${hasCellTargetsCol ? ', cell_targets' : ''} FROM \`${t(TABLES.VARIANT_OVERRIDES)}\` WHERE id = ?`,
          [req.params.id],
        );
      } catch (readErr) {
        if (!hasCellTargetsCol || !isMissingTableOrColumn(readErr)) throw readErr;
        // The column really is absent, so this DB cannot hold a stored scope at
        // all: read without it and let the gate below degrade to the incoming
        // keys, which is the same degrade a successful probe would have produced.
        oldRows = await conn.query(
          `SELECT id, variant_id, field_id, action FROM \`${t(TABLES.VARIANT_OVERRIDES)}\` WHERE id = ?`,
          [req.params.id],
        );
      }
      if (!oldRows.length) {
        const e = apiError('Not found', 'NOT_FOUND', 404);
        return res.status(e.status).json(e.body);
      }
      const old = oldRows[0];

      // S3-A: variant overrides on a linked blueprint are read-only — edit them
      // on the source. Block when the override's CURRENT variant is under a
      // linked blueprint (edit-in-place) OR a PUT tries to MOVE the override onto
      // a variant under a linked blueprint (incoming body variant_id). 409 before
      // ownership/coherence so every role gets a clear message. DELETE falls
      // through (legacy-row cleanup stays allowed).
      const variantIdsToCheck = new Set([old.variant_id]);
      if (req.body && req.body.variant_id != null) variantIdsToCheck.add(req.body.variant_id);
      for (const vid of variantIdsToCheck) {
        const vrows = await conn.query(
          `SELECT parent_id FROM \`${t(TABLES.HIERARCHY_NODES)}\` WHERE id = ? AND node_type = 'variant'`,
          [vid],
        );
        const vbid = vrows.length ? vrows[0].parent_id : null;
        if (vbid != null && await isBlueprintLinked(conn, vbid)) {
          const e = apiError(
            'Cannot edit or move a variant override on a linked blueprint; edit the source blueprint instead',
            'LINKED_BLUEPRINT_READONLY', 409,
          );
          return res.status(e.status).json(e.body);
        }
      }

      // Explicit null on either FK is an attempt to break coherence by
      // clearing the link — reject before the ?? fallback hides it.
      // Distinguish "key not in body" (use old) from "key present and
      // null" (rejected). Both POST and the schema's NOT NULL guard
      // would otherwise let this slip through PATCH-style PUT.
      if (Object.prototype.hasOwnProperty.call(body, 'variant_id') && body.variant_id == null) {
        const e = apiError('variant_id may not be null', 'BAD_REQUEST', 400);
        return res.status(e.status).json(e.body);
      }
      if (Object.prototype.hasOwnProperty.call(body, 'field_id') && body.field_id == null) {
        const e = apiError('field_id may not be null', 'BAD_REQUEST', 400);
        return res.status(e.status).json(e.body);
      }

      const newVariantId = body.variant_id ?? old.variant_id;
      const newFieldId = body.field_id ?? old.field_id;
      const fkChanged = newVariantId !== old.variant_id || newFieldId !== old.field_id;

      // Editor: validate OLD context fully (anti-hijack ownership AND
      // coherence). The coherence check on OLD applies even when FKs
      // change — legacy incoherent rows are write-locked regardless of
      // body (the only legal action is DELETE). For admin, OLD ownership
      // is irrelevant; OLD coherence is enforced via the resolvedCtx
      // path below when fkChanged=false (resolvedCtx === oldCtx) and
      // when fkChanged=true via the NEW pair check.
      let oldCtx = null;
      if (req.user.role === 'editor') {
        oldCtx = await loadVariantOverrideContext(conn, old.variant_id, old.field_id);
        if (!oldCtx || oldCtx.blueprint_exists == null) {
          const e = apiError('not_owner_of_existing', 'NOT_OWNER_OF_EXISTING', 403);
          return res.status(e.status).json(e.body);
        }
        // OLD-pair coherence FIRST: applies to BOTH no-FK-change AND
        // FK-change editor PUTs. A legacy incoherent row must be DELETE'd,
        // never PUT'd to a coherent target — and it must reject before the
        // ownership/grant gate below ever runs, because on an incoherent
        // row `blueprint_owner_id` (joined off variant_blueprint_id, see
        // below) and field_blueprint_id can name two different blueprints;
        // consulting a grant at that point would ask the wrong question.
        if (oldCtx.variant_node_type !== 'variant'
            || oldCtx.field_blueprint_id == null
            || oldCtx.variant_blueprint_id !== oldCtx.field_blueprint_id) {
          const e = apiError('cross_blueprint_coherence_violation', 'CROSS_BLUEPRINT_COHERENCE_VIOLATION', 422);
          return res.status(e.status).json(e.body);
        }
        // spec §6.1: this is the SECOND authority gate on the PUT path — it
        // judges the EXISTING row's blueprint, a distinct question from the
        // resolved-target check below. A blueprint grant must widen BOTH or a
        // grantee editing an override they may write would be refused here on
        // the same blueprint the target check would then allow. Keyed off
        // variant_blueprint_id, not field_blueprint_id: `blueprint_owner_id`
        // is joined via `v.parent_id` (the variant's blueprint) in
        // buildVariantOverrideContextSql, so that is the id the grant must
        // be checked against — coherence above guarantees the two ids are
        // equal by this point, but the id named here is the one that is
        // actually correct, not merely the one that happens to match.
        if (oldCtx.blueprint_owner_id != null
            && oldCtx.blueprint_owner_id !== req.user.id
            && !(oldCtx.variant_blueprint_id != null
              && await callerHasBlueprintGrant(conn, req.user.id, oldCtx.variant_blueprint_id, req.user.role))) {
          const e = apiError('not_owner_of_existing', 'NOT_OWNER_OF_EXISTING', 403);
          return res.status(e.status).json(e.body);
        }
      }

      // Resolved-pair check (NEW or OLD-when-no-FK-change). Editor reuses
      // oldCtx when fkChanged=false to avoid a redundant round trip.
      const resolvedCtx = (!fkChanged && oldCtx)
        ? oldCtx
        : await loadVariantOverrideContext(conn, newVariantId, newFieldId);
      // spec §6.1: the resolved-target gate — a grant on the target blueprint
      // authorises an editor who is not its owner. Resolved by the engine, like
      // the POST path; the owner arm in the verdict still admits the owner.
      const hasBlueprintGrant = req.user.role === 'editor' && resolvedCtx && resolvedCtx.field_blueprint_id != null
        ? await callerHasBlueprintGrant(conn, req.user.id, resolvedCtx.field_blueprint_id, req.user.role)
        : false;
      const fail = validateVariantOverrideContext(resolvedCtx, req.user.role, req.user.id, { hasBlueprintGrant });
      if (fail) {
        const code = fkChanged && fail.error === 'not_owner' ? 'not_owner_of_target' : fail.error;
        const e = apiError(code, code.toUpperCase(), fail.status);
        return res.status(e.status).json(e.body);
      }

      // Field-type gate for cell_targets, judged on the POST-STATE: the document
      // the row will CARRY after this write, against the field it will POINT AT
      // after this write. Key presence is not enough on its own — field_id is
      // repointable, so a body of nothing but field_id moves an already-stored
      // cell scope onto another field, and if that field is not a table the
      // override silently widens from a few cells to the whole field. That is the
      // very state this gate exists to forbid, reached through the gate's own
      // route. A PATCH-style PUT that omits the key is still judged on the stored
      // document rather than on nothing.
      // When the stored document could not be read (column absent, or a blind
      // probe over a DB that lacks it) old.cell_targets is undefined, so the
      // check degrades to the incoming keys — all such a DB can persist anyway.
      const bodyHasCellTargets = Object.prototype.hasOwnProperty.call(body, 'cell_targets');
      const postCellTargets = bodyHasCellTargets ? body.cell_targets : old.cell_targets;
      const badFieldType = validateCellTargetsFieldType(postCellTargets, resolvedCtx);
      if (badFieldType) {
        // The stored-document case is not something the caller sent, so the
        // message has to name the way out; otherwise a row already in this state
        // would be uneditable with no hint why.
        const message = bodyHasCellTargets
          ? badFieldType.error
          : `${badFieldType.error}; clear cell_targets in the same request to move this override`;
        const e = apiError(message, 'INVALID_CELL_TARGETS', badFieldType.status);
        return res.status(e.status).json(e.body);
      }

      const resolvedAction = Object.prototype.hasOwnProperty.call(body, 'action')
        ? body.action
        : old.action;

      // Warn-but-allow (spec §5), judged on the same POST-STATE action the
      // lock/field-type gates above use — computed once here and attached to
      // whichever 200 this PUT ends up taking (no-op or a real UPDATE), so
      // the two paths cannot drift. `retain_when_hidden` defaults false — a
      // missing read fails loud into the warned state, not a silent pass.
      const warnings = overrideConflictWarnings({
        action: resolvedAction,
        blueprintValueSource: resolvedCtx.field_value_source ?? null,
        isRequired: !!resolvedCtx.is_required,
        retainWhenHidden: !!resolvedCtx.retain_when_hidden,
      });

      // Judged on the POST-STATE action and scope, for the same reason the
      // field-type gate above is: field_id is repointable and the stored
      // document survives a PATCH-style PUT, so the shape this row ends up in is
      // the only one worth judging.
      const badLock = await checkBlueprintCellLock(
        conn, resolvedAction, postCellTargets, newFieldId,
      );
      if (badLock) {
        // The stored-scope case is not something the caller sent, so the message
        // has to say where the scope came from.
        const message = bodyHasCellTargets
          ? badLock.error
          : `${badLock.error} (this row already carries a cell scope)`;
        const e = apiError(message, 'BLUEPRINT_COMPUTE_LOCK', badLock.status);
        return res.status(e.status).json(e.body);
      }

      // SAFETY: compute_rule validation for PUT — runs after coherence so
      // blueprintId is known-good. Triggered when the resulting action (body
      // override or existing) is 'compute'. Operator-supplied compute_rule
      // must NEVER reach the DB without passing validateComputeRule + detectCycle.
      if (resolvedAction === 'compute') {
        // compute_rule to validate: body override (incoming update) or absent
        // (action-only transition without a new rule — reject: caller must
        // supply the rule when action is compute).
        const ruleKeyPresent = Object.prototype.hasOwnProperty.call(body, 'compute_rule');
        const incomingRule = ruleKeyPresent ? body.compute_rule : undefined;
        if (incomingRule === null || incomingRule === undefined) {
          // Distinguish the two caller mistakes so the API consumer can tell
          // which they did: omitting the rule entirely vs sending it as null.
          const message = ruleKeyPresent && incomingRule === null
            ? 'compute_rule cannot be null for compute action'
            : 'compute action requires a compute_rule';
          const e = apiError(message, 'BAD_REQUEST', 400);
          return res.status(e.status).json(e.body);
        }
        const computeCtx = await loadComputeValidationContext(
          conn, newVariantId, newFieldId, resolvedCtx.variant_blueprint_id, hasRowContextSource(incomingRule),
        );
        if (!computeCtx) {
          const e = apiError('field_id could not be resolved', 'BAD_REQUEST', 400);
          return res.status(e.status).json(e.body);
        }
        // C1: judged on `postCellTargets` — the POST-write document, computed
        // above for the field-type gate (body's when this PUT names the key,
        // stored otherwise). Same narrowing question, same answer, one read.
        // P2: EXACTLY one column — see `scopeNamesSingleColumn`'s doc-block.
        const ruleResult = validateComputeRule(incomingRule, {
          fieldKeys: computeCtx.fieldKeys,
          targetType: computeCtx.targetType,
          tableColumns: computeCtx.tableColumns,
          ownerFieldKey: computeCtx.targetFieldKey,
          narrowedToColumn: scopeNamesSingleColumn(postCellTargets),
        });
        if (!ruleResult.ok) {
          const e = apiError(ruleResult.detail || ruleResult.code, ruleResult.code, 400);
          return res.status(e.status).json(e.body);
        }
        // Cycle detection: add incoming rule to the existing map, then check.
        computeCtx.existingRulesMap.set(computeCtx.targetFieldKey, incomingRule);
        const cycleResult = detectCycle(computeCtx.existingRulesMap, extractComputeSources);
        if (!cycleResult.ok) {
          const e = apiError(cycleResult.code, cycleResult.code, 400);
          return res.status(e.status).json(e.body);
        }
        // P1b: column-level cycle over the UNION of every candidate (see
        // `loadComputeValidationContext`'s doc-block) plus `postCellTargets`
        // (the same post-write document the rule itself was just judged
        // against) AND — separately — the target field's existing
        // blueprint-level rule, which stays active for whatever cells this
        // write's own narrowing does not name.
        const columnSources = [
          ...computeCtx.columnSourcesBase,
          ...(computeCtx.targetBlueprintRule ? [{
            node: `${computeCtx.targetFieldKey}::blueprint`,
            tableKey: computeCtx.targetFieldKey,
            rule: computeCtx.targetBlueprintRule,
            columns: computeCtx.targetBlueprintScope,
          }] : []),
          {
            node: `${computeCtx.targetFieldKey}::variant`,
            tableKey: computeCtx.targetFieldKey,
            rule: incomingRule,
            columns: postCellTargets,
          },
        ];
        const columnNodes = buildColumnComputeNodes(columnSources);
        if (hasColumnCycle(computeCtx.existingRulesMap, columnNodes, extractComputeSources)) {
          const e = apiError('same_table_column_cycle', 'same_table_column_cycle', 400);
          return res.status(e.status).json(e.body);
        }
        // compute rows store the rule in compute_rule; override_value is empty.
        body.override_value = '';
      } else if (Object.prototype.hasOwnProperty.call(body, 'compute_rule')) {
        // SECURITY: a non-compute action must never persist an unvalidated
        // compute_rule. Strip any stray rule so it cannot bypass
        // validateComputeRule by piggybacking on a lock/hide/autofill update.
        delete body.compute_rule;
      }

      const mapped = mapRowToDb('variant_overrides', body);
      // Operator-mode gate — same reason as the POST above: a DB that
      // warn-skipped the additive cell_targets ALTER must degrade to whole-field
      // scope, not 500 on 1054. Reuses the colSet probed before the old-row read.
      const keys = gateKeysByColumnSet(mapped, colSet);
      if (!keys.length) {
        // No-op PUT (e.g. body identical to existing): treat as success.
        const rows = await conn.query(
          `SELECT * FROM \`${t(TABLES.VARIANT_OVERRIDES)}\` WHERE id = ?`,
          [req.params.id],
        );
        const unchanged = mapRowsFromDb('variant_overrides', rows)[0];
        return res.json(warnings.length ? apiOk({ ...unchanged, warnings }) : apiOk(unchanged));
      }
      const sets = keys.map((k) => `\`${k}\` = ?`).join(', ');
      // TOCTOU race-only safety net: AND-EXISTS predicate at UPDATE time
      // mirrors validateVariantOverrideContext invariants, so a concurrent
      // owner_id transfer / parent_id flip / node_type flip / FK mutation
      // on the row itself between the pre-UPDATE SELECT and the UPDATE
      // cannot slip a write through.
      // SAFETY: pre-UPDATE checks above retain the clean 404/403/422 user-
      // facing error UX; this clause exists only to close the race window.
      // spec §6.1/§6.4a: as with the INSERT, widen the UPDATE's editor owner
      // predicate (both the post-state and the anti-hijack old-state EXISTS) to
      // "owner OR blueprint grant"; otherwise a grantee's UPDATE matches 0 rows
      // and disambiguates to 409 race_detected. Gated on the grants table.
      const updateIncludesGrant = req.user.role === 'editor' && await grantsTableAvailable(conn);
      const guard = buildVariantOverrideUpdateExistsClause({
        role: req.user.role,
        setIncludesVariantId: keys.includes('variant_id'),
        setIncludesFieldId: keys.includes('field_id'),
        newVariantId,
        newFieldId,
        userId: req.user.id,
        includeGrant: updateIncludesGrant,
        t,
        TABLES,
      });
      const result = await conn.query(
        `UPDATE \`${t(TABLES.VARIANT_OVERRIDES)}\` AS vo SET ${sets} WHERE vo.id = ? AND ${guard.clause}`,
        [...keys.map((k) => mapped[k]), req.params.id, ...guard.params],
      );
      if (result.affectedRows === 0) {
        // Disambiguate: row genuinely missing (404) vs EXISTS guard rejected
        // because of mid-flight ownership/coherence change (409 race_detected).
        const stillThere = await conn.query(
          `SELECT 1 FROM \`${t(TABLES.VARIANT_OVERRIDES)}\` WHERE id = ? LIMIT 1`,
          [req.params.id],
        );
        if (stillThere.length === 0) {
          const e = apiError('Not found', 'NOT_FOUND', 404);
          return res.status(e.status).json(e.body);
        }
        const e = apiError('race_detected', 'CONFLICT', 409);
        return res.status(e.status).json(e.body);
      }
      const rows = await conn.query(
        `SELECT * FROM \`${t(TABLES.VARIANT_OVERRIDES)}\` WHERE id = ?`,
        [req.params.id],
      );
      const updated = mapRowsFromDb('variant_overrides', rows)[0];
      res.json(warnings.length ? apiOk({ ...updated, warnings }) : apiOk(updated));
    } finally {
      conn.release();
    }
  } catch (err) {
    // SAFETY: a PUT that moves variant_id / field_id / action onto an
    // already-occupied triple throws ER_DUP_ENTRY 1062. Map to 409
    // duplicate_exists so admins editing a row to a colliding triple get
    // the same labelled response as the POST race path. Same role-agnostic
    // contract as POST.
    if (err && err.errno === 1062) {
      const e = apiError('duplicate_exists', 'DUPLICATE_EXISTS', 409);
      return res.status(e.status).json(e.body);
    }
    logger.error({ err, rowId: req.params.id }, 'Failed to update variant_override');
    const e = apiError('Database operation failed', 'INTERNAL_ERROR');
    res.status(e.status).json(e.body);
  }
});
}

module.exports = { register, extractComputeSources, validateVariantOverrideContext };
