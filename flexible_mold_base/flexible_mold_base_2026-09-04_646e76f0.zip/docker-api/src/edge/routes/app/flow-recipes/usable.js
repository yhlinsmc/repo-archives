/**
 * usable.js — GET /usable?blueprint_id=<id> — minimal projection of approved,
 * active flow recipes bound to a blueprint, for the data-entry "Build flow" UI.
 * End users never see owner/status/review_note or any step config/secret; they
 * receive only what the FE needs to shape the payload and trigger a
 * server-side run: id, name, description, payload_transform_code,
 * consumed_output_keys.
 */
const { pool, t } = require('../../../db');
const { apiOk, apiError, requireAuth, UUID_RE } = require('../../../../shared/helpers');
const { TABLES } = require('../../../../shared/constants');
const { mapRowsFromDb } = require('../../../lib/dto-mapper');
const { logger: rootLogger } = require('../../../../shared/lib/logger');
// The SQL form of the same predicate the run gate applies in JavaScript. A
// semantic changed in one language and left alone in the other is two answers
// again, and the SQL half is the one no JavaScript test can see.
const { reviewRecordedSql } = require('../../../lib/review-status');
const { ACTIVE_ROW_SQL } = require('../../../lib/active-row');

const logger = rootLogger.child({ module: 'flow-recipes:usable' });

function project(r) {
  return {
    id: r.id,
    name: r.name,
    description: r.description ?? '',
    payload_transform_code: r.payload_transform_code ?? '',
    consumed_output_keys: Array.isArray(r.consumed_output_keys) ? r.consumed_output_keys : [],
  };
}

module.exports = function register(router) {
  router.get('/usable', async (req, res) => {
    if (!requireAuth(req, res)) return;
    const blueprintId = req.query.blueprint_id;
    if (!blueprintId || typeof blueprintId !== 'string') {
      const e = apiError('blueprint_id is required', 'BAD_REQUEST', 400);
      return res.status(e.status).json(e.body);
    }
    if (!UUID_RE.test(blueprintId)) {
      const e = apiError('blueprint_id must be a valid id', 'BAD_REQUEST', 400);
      return res.status(e.status).json(e.body);
    }
    let conn;
    try {
      conn = await pool.ro.getConnection();
      const rows = await conn.query(
        `SELECT id, name, description, payload_transform_code, consumed_output_keys
           FROM \`${t(TABLES.FLOW_RECIPES)}\`
          WHERE blueprint_id = ? AND ${reviewRecordedSql('status')} AND ${ACTIVE_ROW_SQL}
                AND payload_transform_code IS NOT NULL AND payload_transform_code <> ''`,
        [blueprintId],
      );
      const recipes = mapRowsFromDb('flow_recipes', rows);
      return res.json(apiOk(recipes.map(project)));
    } catch (err) {
      logger.error({ err, blueprintId }, 'flow-recipes usable query failed');
      const e = apiError('Failed to load recipes', 'INTERNAL_ERROR', 500);
      res.status(e.status).json(e.body);
    } finally {
      if (conn) conn.release();
    }
  });
};
