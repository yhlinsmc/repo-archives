/**
 * blueprint-fields-put-type-cleanup.test.js — v3.2.99 PR-3 Bug-2
 *
 * Exercises the custom PUT handler for /edge/app/schema/blueprint_fields/:id
 * that runs BEFORE the generic createCrudRoutes mount and applies type-
 * change cleanup atomically inside a transaction.
 *
 * Verifies:
 *   - select → text: DELETE field_options + audit row + commit
 *   - table  → text: NULL table_config + audit row + commit
 *   - text   → text (no type change): no DELETE / no audit, normal UPDATE
 *   - text   + table_config in payload → 400 INCONSISTENT_FIELD_PAYLOAD
 *   - 404 when field row missing
 *   - rollback when any query throws
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../src/edge/db');
const routeKey = require.resolve('../../src/edge/routes/app/schema');

let conn;
let calls;

const DATABASE_PROBE = /^SELECT DATABASE\(\)/i;
const COLUMN_PROBE = /SELECT COLUMN_NAME FROM information_schema\.COLUMNS/i;

// Default present columns for the blueprint_fields probe so the operator-mode
// column gate (added in v3.2.129) sees every key as present and leaves the
// type-cleanup behaviour byte-identical. Tests that exercise a degraded schema
// script COLUMN_PROBE explicitly.
// `choice_config`/`options_source` are in the list because the table declares
// them: the payload checks now judge the columns the STATEMENT will name, so a
// column missing from this fixture is a column the write would drop — and a
// check about a value nothing stores is a check about nothing.
const DEFAULT_BF_COLUMNS = [
  'id', 'blueprint_id', 'field_type', 'field_key', 'field_label',
  'table_config', 'choice_config', 'options_source', 'depends_on_field_key', 'value_source', 'value_scope',
].map((c) => ({ COLUMN_NAME: c }));
const BF_COLUMNS_NO_VALUE_SCOPE = DEFAULT_BF_COLUMNS
  .filter((c) => c.COLUMN_NAME !== 'value_scope');
const BF_COLUMNS_NO_CHOICE_CONFIG = DEFAULT_BF_COLUMNS
  .filter((c) => c.COLUMN_NAME !== 'choice_config');

// field_options probe — used by the P2-6 parent-change tag-reset gate. By
// default the valid_parent_values column is present so the reset can fire.
const FIELD_OPTIONS_COLUMNS = [
  'id', 'field_id', 'option_value', 'option_label', 'valid_parent_values',
].map((c) => ({ COLUMN_NAME: c }));

function makeConn(rowsByMatcher) {
  let inTx = false;
  let rolledBack = false;
  let committed = false;
  const queries = [];
  // Auto-answer the gate's probes unless the caller scripted them explicitly.
  const fullScripts = [...rowsByMatcher];
  if (!fullScripts.some(([m]) => m.source === DATABASE_PROBE.source)) {
    fullScripts.unshift([DATABASE_PROBE, [{ db: 'db_default' }]]);
  }
  if (!fullScripts.some(([m]) => m.source === COLUMN_PROBE.source)) {
    // Param-aware default probe: the column gate probes each physical table by
    // name, so the response must depend on the bound TABLE_NAME param rather
    // than the (shared) SQL text.
    fullScripts.unshift([COLUMN_PROBE, (_sql, params) => {
      const table = Array.isArray(params) ? params[0] : undefined;
      if (table === 'fmb_field_options') return FIELD_OPTIONS_COLUMNS;
      return DEFAULT_BF_COLUMNS;
    }]);
  }
  // C1's narrowing-scope scan for the post-state judgement, auto-answered like
  // DATABASE_PROBE/COLUMN_PROBE above unless a test scripts it explicitly: none
  // of this suite's fixture rules carry a `same_table_column` term, so an empty
  // scope map changes nothing about the type-cleanup verdicts these tests pin.
  const FIELD_SCOPES = /SELECT field_key, value_scope FROM `fmb_blueprint_fields`/i;
  if (!fullScripts.some(([m]) => m.source === FIELD_SCOPES.source)) {
    fullScripts.unshift([FIELD_SCOPES, []]);
  }
  rowsByMatcher = fullScripts;
  return {
    queries,
    inTx: () => inTx,
    rolledBack: () => rolledBack,
    committed: () => committed,
    async beginTransaction() { inTx = true; },
    async commit() { committed = true; inTx = false; },
    async rollback() { rolledBack = true; inTx = false; },
    async query(sql, params) {
      queries.push({ sql, params });
      for (const [matcher, response] of rowsByMatcher) {
        if (matcher.test(sql)) {
          if (response instanceof Error) throw response;
          return typeof response === 'function' ? response(sql, params) : response;
        }
      }
      // Linked-blueprint write guard (S1/S2) probes; default to "not linked"
      // so these pre-existing write tests are unaffected.
      if (/SELECT linked_blueprint_id FROM/.test(sql)) return [];
      // The reference cascade that rides along with a key move. It addresses
      // OTHER rows, by the old key's VALUE (hence the BINARY predicate these
      // fixtures recognise it by) — never the row under test — so it answers
      // "nothing to move" and leaves the cleanup assertions alone.
      if (/^UPDATE `fmb_blueprint_fields`[\s\S]*BINARY \?/i.test(sql)) return { affectedRows: 0 };
      if (/ AS bid FROM/.test(sql) || / AS fk FROM/.test(sql)) return [];
      // The identity question the write path now asks the ENGINE (write-value.js
      // `sameStoredValue`): are these two spellings one stored value? Answered
      // here the way the column's collation answers it — case-folded, trailing
      // space padded — so this double cannot disagree with the database about
      // whether a write moved a value. The instrument that settles it for real
      // is tests/integration/blueprint-field-write-real-db.test.js.
      if (/CHARACTER_SET_NAME AS cs/.test(sql)) return [{ cs: 'utf8mb4', co: 'utf8mb4_general_ci' }];
      if (/<=>/.test(sql) && / AS same/.test(sql)) {
        const fold = (v) => String(v).toLowerCase().replace(/\s+$/, '');
        return [{ same: fold((params || [])[0]) === fold((params || [])[1]) ? 1 : 0 }];
      }
      // The (blueprint, key) clash probe both write paths now run before they can
      // create the duplicate the migration endpoint would turn into a merge.
      // Nothing collides in these fixtures; the case that does is settled on a
      // real database (tests/integration/blueprint-field-write-real-db.test.js).
      if (/FROM `fmb_blueprint_fields`/i.test(sql) && /`?field_key`? = \?/i.test(sql)
          && /LIMIT 1/i.test(sql)) {
        return [];
      }
      throw new Error(`Unmatched query in test: ${sql.slice(0, 80)}`);
    },
    release() { /* noop */ },
  };
}

const poolSpy = {
  rw: {
    async getConnection() { return conn; },
  },
  ro: {
    async getConnection() { throw new Error('test error: PUT should use pool.rw'); },
  },
};

require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: {
    pool: poolSpy,
    t: (name) => `fmb_${name}`,
    getDynamicPool: async () => poolSpy,
  },
};

const router = require('../../src/edge/routes/app/schema');
const { __clearColumnSetCache } = router.__test__;

let server;
let port;

before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { req.user = { id: 'admin-1', role: 'admin' }; next(); });
  app.use('/edge/app/schema', router);
  await new Promise((resolve) => {
    server = app.listen(0, '127.0.0.1', () => {
      port = server.address().port;
      resolve();
    });
  });
});

after(async () => {
  await new Promise((resolve) => server.close(resolve));
  delete require.cache[dbKey];
  delete require.cache[routeKey];
});

beforeEach(() => {
  calls = { rw: 0 };
  // Per-test probe results must not leak across the shared column-set cache.
  __clearColumnSetCache();
});

function req(method, path, body) {
  return new Promise((resolve, reject) => {
    const data = JSON.stringify(body);
    const r = http.request({
      method,
      host: '127.0.0.1',
      port,
      path,
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(data) },
    }, (res) => {
      let raw = '';
      res.on('data', (chunk) => { raw += chunk; });
      res.on('end', () => resolve({ status: res.statusCode, body: raw ? JSON.parse(raw) : null }));
    });
    r.on('error', reject);
    r.write(data);
    r.end();
  });
}
const put = (path, body) => req('PUT', path, body);
const post = (path, body) => req('POST', path, body);

describe('PUT /blueprint_fields/:id type-change cleanup', () => {
  it('select → text: DELETEs field_options, writes audit row, commits', async () => {
    conn = makeConn([
      [/SELECT id, blueprint_id, field_type(?:, field_key)?(?:, depends_on_field_key)?(?:, value_source)?(?:, value_scope)?(?:, options_source)? FROM `fmb_blueprint_fields`/i, [{ id: 'f-1', blueprint_id: 'bp-1', field_type: 'select' }]],
      [/^UPDATE `fmb_blueprint_fields` SET/i, { affectedRows: 1 }],
      [/^DELETE FROM `fmb_field_options`/i, { affectedRows: 5 }],
      [/^INSERT INTO `fmb_feature_audit`/i, { affectedRows: 1 }],
      [/SELECT \* FROM `fmb_blueprint_fields` WHERE id/i, [{ id: 'f-1', field_type: 'text', blueprint_id: 'bp-1' }]],
    ]);
    const res = await put('/edge/app/schema/blueprint_fields/f-1', { field_type: 'text' });
    assert.equal(res.status, 200);
    assert.equal(conn.committed(), true);
    assert.equal(conn.rolledBack(), false);
    const auditCall = conn.queries.find((q) => /feature_audit/i.test(q.sql));
    assert.ok(auditCall, 'audit row should be inserted');
    const meta = JSON.parse(auditCall.params[2]);
    assert.equal(meta.old_type, 'select');
    assert.equal(meta.new_type, 'text');
    assert.equal(meta.deleted_options_count, 5);
  });

  it('table → text: NULLs table_config, writes audit, no DELETE field_options', async () => {
    conn = makeConn([
      [/SELECT id, blueprint_id, field_type(?:, field_key)?(?:, depends_on_field_key)?(?:, value_source)?(?:, value_scope)?(?:, options_source)? FROM `fmb_blueprint_fields`/i, [{ id: 'f-1', blueprint_id: 'bp-1', field_type: 'table' }]],
      [/^UPDATE `fmb_blueprint_fields` SET[\s\S]+ WHERE id/i, { affectedRows: 1 }],
      [/^UPDATE `fmb_blueprint_fields` SET table_config = NULL/i, { affectedRows: 1 }],
      [/^INSERT INTO `fmb_feature_audit`/i, { affectedRows: 1 }],
      [/SELECT \* FROM `fmb_blueprint_fields` WHERE id/i, [{ id: 'f-1', field_type: 'text' }]],
    ]);
    const res = await put('/edge/app/schema/blueprint_fields/f-1', { field_type: 'text' });
    assert.equal(res.status, 200);
    assert.equal(conn.committed(), true);
    const hasDelete = conn.queries.some((q) => /DELETE FROM `fmb_field_options`/i.test(q.sql));
    assert.equal(hasDelete, false, 'should not DELETE field_options when old type was table');
    const hasNullClear = conn.queries.some((q) => /SET table_config = NULL/i.test(q.sql));
    assert.equal(hasNullClear, true);
  });

  it('checkbox → text: DELETEs field_options, NULLs choice_config, audits cleared_choice_config', async () => {
    conn = makeConn([
      // choice_config present in the live schema → the clear must fire.
      [COLUMN_PROBE, (_sql, params) => {
        const table = Array.isArray(params) ? params[0] : undefined;
        if (table === 'fmb_field_options') return FIELD_OPTIONS_COLUMNS;
        return [...DEFAULT_BF_COLUMNS, { COLUMN_NAME: 'choice_config' }];
      }],
      [/SELECT id, blueprint_id, field_type(?:, field_key)?(?:, depends_on_field_key)?(?:, value_source)?(?:, value_scope)?(?:, options_source)? FROM `fmb_blueprint_fields`/i, [{ id: 'f-1', blueprint_id: 'bp-1', field_type: 'checkbox' }]],
      [/^UPDATE `fmb_blueprint_fields` SET[\s\S]+ WHERE id/i, { affectedRows: 1 }],
      [/^DELETE FROM `fmb_field_options`/i, { affectedRows: 3 }],
      [/^UPDATE `fmb_blueprint_fields` SET choice_config = NULL/i, { affectedRows: 1 }],
      [/^INSERT INTO `fmb_feature_audit`/i, { affectedRows: 1 }],
      [/SELECT \* FROM `fmb_blueprint_fields` WHERE id/i, [{ id: 'f-1', field_type: 'text', blueprint_id: 'bp-1' }]],
    ]);
    const res = await put('/edge/app/schema/blueprint_fields/f-1', { field_type: 'text' });
    assert.equal(res.status, 200);
    assert.equal(conn.committed(), true);
    assert.equal(conn.queries.some((q) => /DELETE FROM `fmb_field_options`/i.test(q.sql)), true, 'checkbox owns field_options → must DELETE');
    assert.equal(conn.queries.some((q) => /SET choice_config = NULL/i.test(q.sql)), true);
    const meta = JSON.parse(conn.queries.find((q) => /feature_audit/i.test(q.sql)).params[2]);
    assert.equal(meta.old_type, 'checkbox');
    assert.equal(meta.deleted_options_count, 3);
    assert.equal(meta.cleared_choice_config, true);
  });

  it('checkbox → text: skips choice_config clear when the column is ABSENT (operator-mode, no 500)', async () => {
    conn = makeConn([
      // This case IS the absent column, so it states its own probe answer
      // rather than relying on what the default list happens to omit.
      [COLUMN_PROBE, (_sql, params) => (Array.isArray(params) && params[0] === 'fmb_field_options'
        ? FIELD_OPTIONS_COLUMNS
        : BF_COLUMNS_NO_CHOICE_CONFIG)],
      [/SELECT id, blueprint_id, field_type(?:, field_key)?(?:, depends_on_field_key)?(?:, value_source)?(?:, value_scope)?(?:, options_source)? FROM `fmb_blueprint_fields`/i, [{ id: 'f-1', blueprint_id: 'bp-1', field_type: 'checkbox' }]],
      [/^UPDATE `fmb_blueprint_fields` SET[\s\S]+ WHERE id/i, { affectedRows: 1 }],
      [/^DELETE FROM `fmb_field_options`/i, { affectedRows: 2 }],
      [/^INSERT INTO `fmb_feature_audit`/i, { affectedRows: 1 }],
      [/SELECT \* FROM `fmb_blueprint_fields` WHERE id/i, [{ id: 'f-1', field_type: 'text', blueprint_id: 'bp-1' }]],
    ]);
    const res = await put('/edge/app/schema/blueprint_fields/f-1', { field_type: 'text' });
    assert.equal(res.status, 200);
    assert.equal(conn.queries.some((q) => /SET choice_config = NULL/i.test(q.sql)), false, 'must skip clear (and not 500) when column absent');
    const meta = JSON.parse(conn.queries.find((q) => /feature_audit/i.test(q.sql)).params[2]);
    assert.equal(meta.cleared_choice_config, false);
  });

  it('text → text (no type change): no DELETE, no audit row', async () => {
    conn = makeConn([
      [/SELECT id, blueprint_id, field_type(?:, field_key)?(?:, depends_on_field_key)?(?:, value_source)?(?:, value_scope)?(?:, options_source)? FROM `fmb_blueprint_fields`/i, [{ id: 'f-1', blueprint_id: 'bp-1', field_type: 'text' }]],
      [/^UPDATE `fmb_blueprint_fields` SET/i, { affectedRows: 1 }],
      [/SELECT \* FROM `fmb_blueprint_fields` WHERE id/i, [{ id: 'f-1', field_type: 'text' }]],
    ]);
    const res = await put('/edge/app/schema/blueprint_fields/f-1', { field_label: 'New label' });
    assert.equal(res.status, 200);
    const hasDelete = conn.queries.some((q) => /DELETE FROM/i.test(q.sql));
    assert.equal(hasDelete, false);
    const hasAudit = conn.queries.some((q) => /feature_audit/i.test(q.sql));
    assert.equal(hasAudit, false);
  });

  it('text + table_config (non-null) → 400 INCONSISTENT_FIELD_PAYLOAD', async () => {
    conn = makeConn([
      [/SELECT id, blueprint_id, field_type(?:, field_key)?(?:, depends_on_field_key)?(?:, value_source)?(?:, value_scope)?(?:, options_source)? FROM `fmb_blueprint_fields`/i, [{ id: 'f-1', blueprint_id: 'bp-1', field_type: 'select' }]],
    ]);
    const res = await put('/edge/app/schema/blueprint_fields/f-1', {
      field_type: 'text',
      table_config: { columns: [{ key: 'a', label: 'A' }] },
    });
    assert.equal(res.status, 400);
    assert.equal(res.body.error.code, 'INCONSISTENT_FIELD_PAYLOAD');
    assert.equal(conn.rolledBack(), true);
  });

  it('non-checkbox + choice_config (non-null) → 400 INCONSISTENT_FIELD_PAYLOAD', async () => {
    conn = makeConn([
      [/SELECT id, blueprint_id, field_type(?:, field_key)?(?:, depends_on_field_key)?(?:, value_source)?(?:, value_scope)?(?:, options_source)? FROM `fmb_blueprint_fields`/i, [{ id: 'f-1', blueprint_id: 'bp-1', field_type: 'checkbox' }]],
    ]);
    const res = await put('/edge/app/schema/blueprint_fields/f-1', {
      field_type: 'text',
      choice_config: { minSelected: 1 },
    });
    assert.equal(res.status, 400);
    assert.equal(res.body.error.code, 'INCONSISTENT_FIELD_PAYLOAD');
    assert.equal(conn.rolledBack(), true);
  });

  it('checkbox + choice_config with min>max → 400 INCONSISTENT_FIELD_PAYLOAD', async () => {
    conn = makeConn([
      [/SELECT id, blueprint_id, field_type(?:, field_key)?(?:, depends_on_field_key)?(?:, value_source)?(?:, value_scope)?(?:, options_source)? FROM `fmb_blueprint_fields`/i, [{ id: 'f-1', blueprint_id: 'bp-1', field_type: 'checkbox' }]],
    ]);
    const res = await put('/edge/app/schema/blueprint_fields/f-1', {
      field_type: 'checkbox',
      choice_config: { minSelected: 5, maxSelected: 2 },
    });
    assert.equal(res.status, 400);
    assert.equal(res.body.error.code, 'INCONSISTENT_FIELD_PAYLOAD');
    assert.equal(conn.rolledBack(), true);
  });

  it('checkbox + well-formed choice_config is accepted', async () => {
    conn = makeConn([
      [/SELECT id, blueprint_id, field_type(?:, field_key)?(?:, depends_on_field_key)?(?:, value_source)?(?:, value_scope)?(?:, options_source)? FROM `fmb_blueprint_fields`/i, [{ id: 'f-1', blueprint_id: 'bp-1', field_type: 'checkbox' }]],
      [/^UPDATE `fmb_blueprint_fields` SET/i, { affectedRows: 1 }],
      [/SELECT \* FROM `fmb_blueprint_fields` WHERE id/i, [{ id: 'f-1', field_type: 'checkbox', blueprint_id: 'bp-1' }]],
    ]);
    const res = await put('/edge/app/schema/blueprint_fields/f-1', {
      field_type: 'checkbox',
      choice_config: { minSelected: 1, maxSelected: 3 },
    });
    assert.equal(res.status, 200);
    assert.equal(conn.committed(), true);
  });

  // The generic CREATE path (factory POST, not the custom PUT) is guarded by a
  // serializeWrite validator so a direct API create can't bypass the invariants.
  it('POST create: checkbox + min>max choice_config → 400 INCONSISTENT_FIELD_PAYLOAD', async () => {
    conn = makeConn([]); // serializeWrite rejects before any DB write
    const res = await post('/edge/app/schema/blueprint_fields', {
      field_key: 'k', field_label: 'L', field_type: 'checkbox',
      choice_config: { minSelected: 5, maxSelected: 2 },
    });
    assert.equal(res.status, 400);
    assert.equal(res.body.error.code, 'INCONSISTENT_FIELD_PAYLOAD');
  });

  it('POST create: choice_config on a non-checkbox field → 400 INCONSISTENT_FIELD_PAYLOAD', async () => {
    conn = makeConn([]);
    const res = await post('/edge/app/schema/blueprint_fields', {
      field_key: 'k', field_label: 'L', field_type: 'text',
      choice_config: { minSelected: 1 },
    });
    assert.equal(res.status, 400);
    assert.equal(res.body.error.code, 'INCONSISTENT_FIELD_PAYLOAD');
  });

  // options_source structural floor (isPayloadInconsistent) — the server-side
  // copy of parse-options-source.ts's shape rules, proven independently here
  // because a request never runs the TS parser.
  describe('options_source structural floor', () => {
    const oldRowSelect = [
      /SELECT id, blueprint_id, field_type(?:, field_key)?(?:, depends_on_field_key)?(?:, value_source)?(?:, value_scope)?(?:, options_source)? FROM `fmb_blueprint_fields`/i,
      [{ id: 'f-1', blueprint_id: 'bp-1', field_type: 'select' }],
    ];

    it('PUT: options_source not an object (bare string) → 400 INCONSISTENT_FIELD_PAYLOAD', async () => {
      conn = makeConn([oldRowSelect]);
      const res = await put('/edge/app/schema/blueprint_fields/f-1', {
        field_type: 'select', options_source: 'field',
      });
      assert.equal(res.status, 400);
      assert.equal(res.body.error.code, 'INCONSISTENT_FIELD_PAYLOAD');
      assert.equal(conn.rolledBack(), true);
    });

    it('PUT: options_source unknown type → 400 INCONSISTENT_FIELD_PAYLOAD', async () => {
      conn = makeConn([oldRowSelect]);
      const res = await put('/edge/app/schema/blueprint_fields/f-1', {
        field_type: 'select', options_source: { type: 'sql_query', query: 'SELECT 1' },
      });
      assert.equal(res.status, 400);
      assert.equal(res.body.error.code, 'INCONSISTENT_FIELD_PAYLOAD');
    });

    it('PUT: options_source type field, missing source_field_key → 400 INCONSISTENT_FIELD_PAYLOAD', async () => {
      conn = makeConn([oldRowSelect]);
      const res = await put('/edge/app/schema/blueprint_fields/f-1', {
        field_type: 'select', options_source: { type: 'field' },
      });
      assert.equal(res.status, 400);
      assert.equal(res.body.error.code, 'INCONSISTENT_FIELD_PAYLOAD');
    });

    it('PUT: options_source type connector, missing connector_id → 400 INCONSISTENT_FIELD_PAYLOAD', async () => {
      conn = makeConn([oldRowSelect]);
      const res = await put('/edge/app/schema/blueprint_fields/f-1', {
        field_type: 'select', options_source: { type: 'connector', input_bindings: {} },
      });
      assert.equal(res.status, 400);
      assert.equal(res.body.error.code, 'INCONSISTENT_FIELD_PAYLOAD');
    });

    it('PUT: options_source with unknown top-level key → 400 INCONSISTENT_FIELD_PAYLOAD (fall closed)', async () => {
      conn = makeConn([oldRowSelect]);
      const res = await put('/edge/app/schema/blueprint_fields/f-1', {
        field_type: 'select', options_source: { type: 'field', source_field_key: 'x', evil: true },
      });
      assert.equal(res.status, 400);
      assert.equal(res.body.error.code, 'INCONSISTENT_FIELD_PAYLOAD');
    });

    it('PUT: options_source set + depends_on_field_key set → 400 INCONSISTENT_FIELD_PAYLOAD (Q1)', async () => {
      conn = makeConn([oldRowSelect]);
      const res = await put('/edge/app/schema/blueprint_fields/f-1', {
        field_type: 'select',
        options_source: { type: 'field', source_field_key: 'material' },
        depends_on_field_key: 'parent_field',
      });
      assert.equal(res.status, 400);
      assert.equal(res.body.error.code, 'INCONSISTENT_FIELD_PAYLOAD');
    });

    it('PUT: well-formed options_source type field is accepted', async () => {
      conn = makeConn([
        oldRowSelect,
        [/^UPDATE `fmb_blueprint_fields` SET/i, { affectedRows: 1 }],
        [/SELECT \* FROM `fmb_blueprint_fields` WHERE id/i, [{ id: 'f-1', field_type: 'select', blueprint_id: 'bp-1' }]],
      ]);
      const res = await put('/edge/app/schema/blueprint_fields/f-1', {
        field_type: 'select', options_source: { type: 'field', source_field_key: 'material' },
      });
      assert.equal(res.status, 200);
      assert.equal(conn.committed(), true);
    });

    it('PUT: well-formed options_source type field with an explicit column is accepted', async () => {
      conn = makeConn([
        oldRowSelect,
        [/^UPDATE `fmb_blueprint_fields` SET/i, { affectedRows: 1 }],
        [/SELECT \* FROM `fmb_blueprint_fields` WHERE id/i, [{ id: 'f-1', field_type: 'select', blueprint_id: 'bp-1' }]],
      ]);
      const res = await put('/edge/app/schema/blueprint_fields/f-1', {
        field_type: 'select', options_source: { type: 'field', source_field_key: 'line_items', column: 'part_no' },
      });
      assert.equal(res.status, 200);
      assert.equal(conn.committed(), true);
    });

    it('PUT: options_source type field with an empty-string column → 400 INCONSISTENT_FIELD_PAYLOAD', async () => {
      conn = makeConn([oldRowSelect]);
      const res = await put('/edge/app/schema/blueprint_fields/f-1', {
        field_type: 'select', options_source: { type: 'field', source_field_key: 'line_items', column: '' },
      });
      assert.equal(res.status, 400);
      assert.equal(res.body.error.code, 'INCONSISTENT_FIELD_PAYLOAD');
    });

    it('PUT: well-formed options_source type connector is accepted', async () => {
      conn = makeConn([
        oldRowSelect,
        [/^UPDATE `fmb_blueprint_fields` SET/i, { affectedRows: 1 }],
        [/SELECT \* FROM `fmb_blueprint_fields` WHERE id/i, [{ id: 'f-1', field_type: 'select', blueprint_id: 'bp-1' }]],
      ]);
      const res = await put('/edge/app/schema/blueprint_fields/f-1', {
        field_type: 'select',
        options_source: { type: 'connector', connector_id: 'conn-1', output_id: 'out-1', input_bindings: { region: 'plant' } },
      });
      assert.equal(res.status, 200);
      assert.equal(conn.committed(), true);
    });

    // Q1 merged-state coverage (OPT-E1 Codex P2): a partial PUT that names only
    // ONE side of options_source/depends_on_field_key must still be judged
    // against what the row will actually hold — the STORED other side, not an
    // absent body key read as "no conflict".
    it('PUT: partial body sets options_source only, stored row already has depends_on_field_key → 400 (Q1 merged-state)', async () => {
      conn = makeConn([
        [/SELECT id, blueprint_id, field_type(?:, field_key)?(?:, depends_on_field_key)?(?:, value_source)?(?:, value_scope)?(?:, options_source)? FROM `fmb_blueprint_fields`/i,
          [{
            id: 'f-1', blueprint_id: 'bp-1', field_type: 'select', depends_on_field_key: 'parent_field',
          }]],
      ]);
      const res = await put('/edge/app/schema/blueprint_fields/f-1', {
        options_source: { type: 'field', source_field_key: 'material' },
      });
      assert.equal(res.status, 400);
      assert.equal(res.body.error.code, 'INCONSISTENT_FIELD_PAYLOAD');
      assert.equal(conn.rolledBack(), true);
    });

    it('PUT: partial body sets depends_on_field_key only, stored row already has options_source → 400 (Q1 merged-state, reverse)', async () => {
      conn = makeConn([
        [/SELECT id, blueprint_id, field_type(?:, field_key)?(?:, depends_on_field_key)?(?:, value_source)?(?:, value_scope)?(?:, options_source)? FROM `fmb_blueprint_fields`/i,
          [{
            id: 'f-1',
            blueprint_id: 'bp-1',
            field_type: 'select',
            options_source: { type: 'field', source_field_key: 'material' },
          }]],
      ]);
      const res = await put('/edge/app/schema/blueprint_fields/f-1', {
        depends_on_field_key: 'parent_field',
      });
      assert.equal(res.status, 400);
      assert.equal(res.body.error.code, 'INCONSISTENT_FIELD_PAYLOAD');
      assert.equal(conn.rolledBack(), true);
    });

    it('PUT: partial body sets options_source AND explicitly clears the stored depends_on_field_key → 200 (Q1 merged-state, sibling cleared)', async () => {
      conn = makeConn([
        [/SELECT id, blueprint_id, field_type(?:, field_key)?(?:, depends_on_field_key)?(?:, value_source)?(?:, value_scope)?(?:, options_source)? FROM `fmb_blueprint_fields`/i,
          [{
            id: 'f-1', blueprint_id: 'bp-1', field_type: 'select', depends_on_field_key: 'parent_field',
          }]],
        [/^UPDATE `fmb_blueprint_fields` SET/i, { affectedRows: 1 }],
        [/^UPDATE `fmb_field_options` SET valid_parent_values = NULL/i, { affectedRows: 0 }],
        [/SELECT \* FROM `fmb_blueprint_fields` WHERE id/i, [{ id: 'f-1', field_type: 'select', blueprint_id: 'bp-1' }]],
      ]);
      const res = await put('/edge/app/schema/blueprint_fields/f-1', {
        options_source: { type: 'field', source_field_key: 'material' },
        depends_on_field_key: null,
      });
      assert.equal(res.status, 200);
      assert.equal(conn.committed(), true);
    });

    // input_bindings structural floor (OPT-E1 Codex P2): `input_bindings` must
    // be present and a plain string->string map (empty object legal) — an
    // absent key, an array, or a wrong-typed value parses per the outer
    // allow-list but is dead config the frontend parser (parse-options-source.ts,
    // 'connector-invalid-input-bindings') already refuses to resolve.
    it('PUT: connector options_source with input_bindings as an array → 400 INCONSISTENT_FIELD_PAYLOAD', async () => {
      conn = makeConn([oldRowSelect]);
      const res = await put('/edge/app/schema/blueprint_fields/f-1', {
        field_type: 'select',
        options_source: { type: 'connector', connector_id: 'c', output_id: 'out-1', input_bindings: [] },
      });
      assert.equal(res.status, 400);
      assert.equal(res.body.error.code, 'INCONSISTENT_FIELD_PAYLOAD');
    });

    it('PUT: connector options_source with a non-string input_bindings value → 400 INCONSISTENT_FIELD_PAYLOAD', async () => {
      conn = makeConn([oldRowSelect]);
      const res = await put('/edge/app/schema/blueprint_fields/f-1', {
        field_type: 'select',
        options_source: { type: 'connector', connector_id: 'c', output_id: 'out-1', input_bindings: { region: 5 } },
      });
      assert.equal(res.status, 400);
      assert.equal(res.body.error.code, 'INCONSISTENT_FIELD_PAYLOAD');
    });

    it("PUT: connector options_source with a '__proto__' input_bindings key → 400 INCONSISTENT_FIELD_PAYLOAD", async () => {
      conn = makeConn([oldRowSelect]);
      const optionsSource = JSON.parse(
        '{"type":"connector","connector_id":"c","output_id":"out-1","input_bindings":{"__proto__":"plant"}}',
      );
      const res = await put('/edge/app/schema/blueprint_fields/f-1', {
        field_type: 'select', options_source: optionsSource,
      });
      assert.equal(res.status, 400);
      assert.equal(res.body.error.code, 'INCONSISTENT_FIELD_PAYLOAD');
    });

    it('PUT: connector options_source with a blank input_bindings key → 400 INCONSISTENT_FIELD_PAYLOAD', async () => {
      conn = makeConn([oldRowSelect]);
      const optionsSource = JSON.parse(
        '{"type":"connector","connector_id":"c","output_id":"out-1","input_bindings":{"":"plant"}}',
      );
      const res = await put('/edge/app/schema/blueprint_fields/f-1', {
        field_type: 'select', options_source: optionsSource,
      });
      assert.equal(res.status, 400);
      assert.equal(res.body.error.code, 'INCONSISTENT_FIELD_PAYLOAD');
    });

    it('PUT: connector options_source with a blank input_bindings value → 400 INCONSISTENT_FIELD_PAYLOAD', async () => {
      conn = makeConn([oldRowSelect]);
      const res = await put('/edge/app/schema/blueprint_fields/f-1', {
        field_type: 'select',
        options_source: { type: 'connector', connector_id: 'c', output_id: 'out-1', input_bindings: { region: '' } },
      });
      assert.equal(res.status, 400);
      assert.equal(res.body.error.code, 'INCONSISTENT_FIELD_PAYLOAD');
    });

    it('PUT: connector options_source with a valid string input_bindings map is accepted', async () => {
      conn = makeConn([
        oldRowSelect,
        [/^UPDATE `fmb_blueprint_fields` SET/i, { affectedRows: 1 }],
        [/SELECT \* FROM `fmb_blueprint_fields` WHERE id/i, [{ id: 'f-1', field_type: 'select', blueprint_id: 'bp-1' }]],
      ]);
      const res = await put('/edge/app/schema/blueprint_fields/f-1', {
        field_type: 'select',
        options_source: { type: 'connector', connector_id: 'c', output_id: 'out-1', input_bindings: { region: 'plant_code' } },
      });
      assert.equal(res.status, 200);
      assert.equal(conn.committed(), true);
    });

    it('PUT: connector options_source with input_bindings absent → 400 INCONSISTENT_FIELD_PAYLOAD (frontend parser rejects absent bindings)', async () => {
      conn = makeConn([oldRowSelect]);
      const res = await put('/edge/app/schema/blueprint_fields/f-1', {
        field_type: 'select',
        options_source: { type: 'connector', connector_id: 'c', output_id: 'out-1' },
      });
      assert.equal(res.status, 400);
      assert.equal(res.body.error.code, 'INCONSISTENT_FIELD_PAYLOAD');
    });

    it('PUT: connector options_source with input_bindings as an empty object is accepted', async () => {
      conn = makeConn([
        oldRowSelect,
        [/^UPDATE `fmb_blueprint_fields` SET/i, { affectedRows: 1 }],
        [/SELECT \* FROM `fmb_blueprint_fields` WHERE id/i, [{ id: 'f-1', field_type: 'select', blueprint_id: 'bp-1' }]],
      ]);
      const res = await put('/edge/app/schema/blueprint_fields/f-1', {
        field_type: 'select',
        options_source: { type: 'connector', connector_id: 'c', output_id: 'out-1', input_bindings: {} },
      });
      assert.equal(res.status, 200);
      assert.equal(conn.committed(), true);
    });

    // The generic CREATE path (factory POST) is guarded by the same
    // serializeWrite validator as the choice_config/compute_rule floors above.
    it('POST create: options_source unknown type → 400 INCONSISTENT_FIELD_PAYLOAD', async () => {
      conn = makeConn([]);
      const res = await post('/edge/app/schema/blueprint_fields', {
        field_key: 'k', field_label: 'L', field_type: 'select',
        options_source: { type: 'sql_query', query: 'SELECT 1' },
      });
      assert.equal(res.status, 400);
      assert.equal(res.body.error.code, 'INCONSISTENT_FIELD_PAYLOAD');
    });

    it('POST create: options_source set + depends_on_field_key set → 400 INCONSISTENT_FIELD_PAYLOAD (Q1)', async () => {
      conn = makeConn([]);
      const res = await post('/edge/app/schema/blueprint_fields', {
        field_key: 'k', field_label: 'L', field_type: 'select',
        options_source: { type: 'field', source_field_key: 'material' },
        depends_on_field_key: 'parent_field',
      });
      assert.equal(res.status, 400);
      assert.equal(res.body.error.code, 'INCONSISTENT_FIELD_PAYLOAD');
    });
  });

  it('returns 404 when field row missing', async () => {
    conn = makeConn([
      [/SELECT id, blueprint_id, field_type(?:, field_key)?(?:, depends_on_field_key)?(?:, value_source)?(?:, value_scope)?(?:, options_source)? FROM `fmb_blueprint_fields`/i, []],
    ]);
    const res = await put('/edge/app/schema/blueprint_fields/missing', { field_type: 'text' });
    assert.equal(res.status, 404);
    assert.equal(conn.rolledBack(), true);
  });

  it('rolls back transaction when DELETE field_options throws', async () => {
    conn = makeConn([
      [/SELECT id, blueprint_id, field_type(?:, field_key)?(?:, depends_on_field_key)?(?:, value_source)?(?:, value_scope)?(?:, options_source)? FROM `fmb_blueprint_fields`/i, [{ id: 'f-1', blueprint_id: 'bp-1', field_type: 'select' }]],
      [/^UPDATE `fmb_blueprint_fields` SET/i, { affectedRows: 1 }],
      [/^DELETE FROM `fmb_field_options`/i, new Error('connection lost')],
    ]);
    const res = await put('/edge/app/schema/blueprint_fields/f-1', { field_type: 'text' });
    assert.equal(res.status, 500);
    assert.equal(conn.rolledBack(), true);
    assert.equal(conn.committed(), false);
  });
});

describe('PUT /blueprint_fields/:id — a field leaving table type clears cell scopes', () => {
  // cell_targets addresses rows x columns of a TABLE field. Once the field is
  // not a table there are no cells to match, so a variant override the author
  // NARROWED to one column starts applying to the whole field — a `hide` then
  // strips the field's value from the saved payload. The scope must be cleared
  // in the same transaction as the rest of the type-change cleanup.
  const VO_COLUMNS = ['id', 'variant_id', 'field_id', 'action', 'override_value', 'cell_targets']
    .map((c) => ({ COLUMN_NAME: c }));
  const VO_COLUMNS_PRE_MIGRATION = VO_COLUMNS.filter((c) => c.COLUMN_NAME !== 'cell_targets');

  // Param-aware probe: each physical table reports its own column set.
  const probe = (voColumns) => [COLUMN_PROBE, (_sql, params) => {
    const table = Array.isArray(params) ? params[0] : undefined;
    if (table === 'fmb_field_options') return FIELD_OPTIONS_COLUMNS;
    if (table === 'fmb_variant_overrides') return voColumns;
    return DEFAULT_BF_COLUMNS;
  }];

  const CLEAR_SCOPES = /^UPDATE `fmb_variant_overrides` SET cell_targets = NULL/i;

  it('table → text: clears cell_targets on the field\'s overrides and audits the count', async () => {
    let clearParams = null;
    conn = makeConn([
      probe(VO_COLUMNS),
      [/SELECT id, blueprint_id, field_type(?:, field_key)?(?:, depends_on_field_key)?(?:, value_source)?(?:, value_scope)?(?:, options_source)? FROM `fmb_blueprint_fields`/i, [{ id: 'f-1', blueprint_id: 'bp-1', field_type: 'table' }]],
      [/^UPDATE `fmb_blueprint_fields` SET[\s\S]+ WHERE id/i, { affectedRows: 1 }],
      [/^UPDATE `fmb_blueprint_fields` SET table_config = NULL/i, { affectedRows: 1 }],
      [CLEAR_SCOPES, (_sql, params) => { clearParams = params; return { affectedRows: 2 }; }],
      [/^INSERT INTO `fmb_feature_audit`/i, { affectedRows: 1 }],
      [/SELECT \* FROM `fmb_blueprint_fields` WHERE id/i, [{ id: 'f-1', field_type: 'text', blueprint_id: 'bp-1' }]],
    ]);
    const res = await put('/edge/app/schema/blueprint_fields/f-1', { field_type: 'text' });
    assert.equal(res.status, 200);
    assert.equal(conn.committed(), true);
    assert.deepEqual(clearParams, ['f-1'], 'the clear must be scoped to this field');
    const meta = JSON.parse(conn.queries.find((q) => /feature_audit/i.test(q.sql)).params[2]);
    assert.equal(meta.cleared_cell_targets_count, 2,
      'the number of overrides that widened must be in the audit trail');
  });

  const CLEAR_VALUE_SCOPE = /^UPDATE `fmb_blueprint_fields` SET value_scope = NULL/i;

  it('table → text: clears BOTH scopes, in one transaction', async () => {
    // The two levels widen identically and for the same reason, so they have to
    // be cleared on the same trigger and committed together — a type change that
    // cleared one and not the other would leave the field half-protected in a
    // way no surface reports.
    let bothPresent = null;
    conn = makeConn([
      probe(VO_COLUMNS),
      [/SELECT id, blueprint_id, field_type(?:, field_key)?(?:, depends_on_field_key)?(?:, value_source)?(?:, value_scope)?(?:, options_source)? FROM `fmb_blueprint_fields`/i, [{ id: 'f-1', blueprint_id: 'bp-1', field_type: 'table' }]],
      // Listed BEFORE the catch-all UPDATE matcher: scripts are tried in order
      // and the catch-all matches this statement too.
      [CLEAR_VALUE_SCOPE, (_sql, params) => { bothPresent = params; return { affectedRows: 1 }; }],
      [/^UPDATE `fmb_blueprint_fields` SET table_config = NULL/i, { affectedRows: 1 }],
      [/^UPDATE `fmb_blueprint_fields` SET[\s\S]+ WHERE id/i, { affectedRows: 1 }],
      [CLEAR_SCOPES, { affectedRows: 2 }],
      [/^INSERT INTO `fmb_feature_audit`/i, { affectedRows: 1 }],
      [/SELECT \* FROM `fmb_blueprint_fields` WHERE id/i, [{ id: 'f-1', field_type: 'text', blueprint_id: 'bp-1' }]],
    ]);
    const res = await put('/edge/app/schema/blueprint_fields/f-1', { field_type: 'text' });
    assert.equal(res.status, 200);
    assert.equal(conn.committed(), true, 'both clears commit together or not at all');
    assert.deepEqual(bothPresent, ['f-1'], 'the blueprint clear must be scoped to this field');
    assert.equal(conn.queries.some((q) => CLEAR_SCOPES.test(q.sql)), true,
      'the variant scopes must be cleared too');
    const meta = JSON.parse(conn.queries.find((q) => /feature_audit/i.test(q.sql)).params[2]);
    assert.equal(meta.cleared_value_scope, true);
    assert.equal(meta.cleared_cell_targets_count, 2);
  });

  it('table → text: accepts the WHOLE-FORM body the editor actually sends', async () => {
    // Every case above PATCHes `{ field_type }` alone, which the field editor
    // never does — it PUTs the whole form. So the cleanup below was only ever
    // tested against a body that omits the column, while the body the UI sends
    // carries `value_scope` and meets the coherence gate FIRST. The editor now
    // clears the scope on the type change; this pins that the shape it produces
    // is accepted, and that the server-side clear still runs behind it.
    let clearedBlueprintScope = false;
    conn = makeConn([
      probe(VO_COLUMNS),
      [/SELECT id, blueprint_id, field_type(?:, field_key)?(?:, depends_on_field_key)?(?:, value_source)?(?:, value_scope)?(?:, options_source)? FROM `fmb_blueprint_fields`/i, [{ id: 'f-1', blueprint_id: 'bp-1', field_type: 'table' }]],
      [CLEAR_VALUE_SCOPE, () => { clearedBlueprintScope = true; return { affectedRows: 0 }; }],
      [/^UPDATE `fmb_blueprint_fields` SET table_config = NULL/i, { affectedRows: 1 }],
      [/^UPDATE `fmb_blueprint_fields` SET[\s\S]+ WHERE id/i, { affectedRows: 1 }],
      [CLEAR_SCOPES, { affectedRows: 0 }],
      [/^INSERT INTO `fmb_feature_audit`/i, { affectedRows: 1 }],
      [/SELECT \* FROM `fmb_blueprint_fields` WHERE id/i, [{ id: 'f-1', field_type: 'text', blueprint_id: 'bp-1' }]],
    ]);
    const res = await put('/edge/app/schema/blueprint_fields/f-1', {
      field_key: 'nodes', field_label: 'Nodes', field_type: 'text', section: 'general',
      is_required: false, default_value: '', placeholder: '', tooltip: '',
      value_source: 'locked', value_scope: null, compute_rule: null,
    });
    assert.equal(res.status, 200, JSON.stringify(res.body));
    assert.equal(clearedBlueprintScope, true, 'the server-side clear still runs behind the form');
  });

  it('table → text: REFUSES the same body with the scope still on it', async () => {
    // What the editor sent before it cleared the scope: rejected outright, with
    // a message naming a control the type change has taken off the screen.
    conn = makeConn([
      probe(VO_COLUMNS),
      [/SELECT id, blueprint_id, field_type(?:, field_key)?(?:, depends_on_field_key)?(?:, value_source)?(?:, value_scope)?(?:, options_source)? FROM `fmb_blueprint_fields`/i, [{ id: 'f-1', blueprint_id: 'bp-1', field_type: 'table' }]],
    ]);
    const res = await put('/edge/app/schema/blueprint_fields/f-1', {
      field_key: 'nodes', field_label: 'Nodes', field_type: 'text', section: 'general',
      value_source: 'locked', value_scope: { columns: ['host'] }, compute_rule: null,
    });
    assert.equal(res.status, 400);
    assert.equal(res.body.error.code, 'INCONSISTENT_VALUE_SOURCE');
    assert.match(res.body.error.message, /must not carry a value_scope/);
  });

  it('table → text: records no blueprint clear when there was no scope to widen', async () => {
    conn = makeConn([
      probe(VO_COLUMNS),
      [/SELECT id, blueprint_id, field_type(?:, field_key)?(?:, depends_on_field_key)?(?:, value_source)?(?:, value_scope)?(?:, options_source)? FROM `fmb_blueprint_fields`/i, [{ id: 'f-1', blueprint_id: 'bp-1', field_type: 'table' }]],
      // IS NOT NULL in the statement means an unscoped field matches no rows.
      // Listed before the catch-all UPDATE matcher, which matches it too.
      [CLEAR_VALUE_SCOPE, { affectedRows: 0 }],
      [/^UPDATE `fmb_blueprint_fields` SET table_config = NULL/i, { affectedRows: 1 }],
      [/^UPDATE `fmb_blueprint_fields` SET[\s\S]+ WHERE id/i, { affectedRows: 1 }],
      [CLEAR_SCOPES, { affectedRows: 0 }],
      [/^INSERT INTO `fmb_feature_audit`/i, { affectedRows: 1 }],
      [/SELECT \* FROM `fmb_blueprint_fields` WHERE id/i, [{ id: 'f-1', field_type: 'text', blueprint_id: 'bp-1' }]],
    ]);
    await put('/edge/app/schema/blueprint_fields/f-1', { field_type: 'text' });
    const meta = JSON.parse(conn.queries.find((q) => /feature_audit/i.test(q.sql)).params[2]);
    assert.equal(meta.cleared_value_scope, false);
  });

  it('table → text: skips the blueprint clear when value_scope is ABSENT (operator-mode, no 500)', async () => {
    conn = makeConn([
      [COLUMN_PROBE, (_sql, params) => {
        const table = Array.isArray(params) ? params[0] : undefined;
        if (table === 'fmb_field_options') return FIELD_OPTIONS_COLUMNS;
        if (table === 'fmb_variant_overrides') return VO_COLUMNS;
        return BF_COLUMNS_NO_VALUE_SCOPE;
      }],
      [/SELECT id, blueprint_id, field_type(?:, field_key)?(?:, depends_on_field_key)?(?:, value_source)?(?:, value_scope)?(?:, options_source)? FROM `fmb_blueprint_fields`/i, [{ id: 'f-1', blueprint_id: 'bp-1', field_type: 'table' }]],
      [/^UPDATE `fmb_blueprint_fields` SET[\s\S]+ WHERE id/i, { affectedRows: 1 }],
      [/^UPDATE `fmb_blueprint_fields` SET table_config = NULL/i, { affectedRows: 1 }],
      [CLEAR_SCOPES, { affectedRows: 0 }],
      [/^INSERT INTO `fmb_feature_audit`/i, { affectedRows: 1 }],
      [/SELECT \* FROM `fmb_blueprint_fields` WHERE id/i, [{ id: 'f-1', field_type: 'text', blueprint_id: 'bp-1' }]],
    ]);
    const res = await put('/edge/app/schema/blueprint_fields/f-1', { field_type: 'text' });
    assert.equal(res.status, 200);
    assert.equal(conn.queries.some((q) => CLEAR_VALUE_SCOPE.test(q.sql)), false,
      'naming an absent column would 1054 and roll the whole type change back');
  });

  it('table → text: a blind probe over a DB that really lacks value_scope still completes', async () => {
    conn = makeConn([
      [COLUMN_PROBE, (_sql, params) => {
        const table = Array.isArray(params) ? params[0] : undefined;
        if (table === 'fmb_field_options') return FIELD_OPTIONS_COLUMNS;
        if (table === 'fmb_variant_overrides') return VO_COLUMNS;
        return [];
      }],
      [/SELECT id, blueprint_id, field_type(?:, field_key)?(?:, depends_on_field_key)?(?:, value_source)?(?:, value_scope)?(?:, options_source)? FROM `fmb_blueprint_fields`/i, [{ id: 'f-1', blueprint_id: 'bp-1', field_type: 'table' }]],
      // Listed before the catch-all UPDATE matcher, which matches it too.
      [CLEAR_VALUE_SCOPE, Object.assign(new Error("Unknown column 'value_scope' in 'field list'"), {
        errno: 1054, code: 'ER_BAD_FIELD_ERROR',
      })],
      // A blind probe also widens the compute pre-scan's own SELECT.
      [/^SELECT field_key, field_type, table_config(, compute_rule)? FROM `fmb_blueprint_fields`/i, []],
      [/SELECT vo\.variant_id, bf\.field_key, vo\.compute_rule/i, []],
      [/^UPDATE `fmb_blueprint_fields` SET table_config = NULL/i, { affectedRows: 1 }],
      [/^UPDATE `fmb_blueprint_fields` SET[\s\S]+ WHERE id/i, { affectedRows: 1 }],
      [CLEAR_SCOPES, { affectedRows: 0 }],
      [/^INSERT INTO `fmb_feature_audit`/i, { affectedRows: 1 }],
      [/SELECT \* FROM `fmb_blueprint_fields` WHERE id/i, [{ id: 'f-1', field_type: 'text', blueprint_id: 'bp-1' }]],
    ]);
    const res = await put('/edge/app/schema/blueprint_fields/f-1', { field_type: 'text' });
    assert.equal(res.status, 200, 'a missing-column error must not fail the type change');
    assert.equal(conn.rolledBack(), false);
  });

  it('table → text: a real failure of the blueprint clear rolls the type change back', async () => {
    conn = makeConn([
      probe(VO_COLUMNS),
      [/SELECT id, blueprint_id, field_type(?:, field_key)?(?:, depends_on_field_key)?(?:, value_source)?(?:, value_scope)?(?:, options_source)? FROM `fmb_blueprint_fields`/i, [{ id: 'f-1', blueprint_id: 'bp-1', field_type: 'table' }]],
      // Listed before the catch-all UPDATE matcher, which matches it too.
      [CLEAR_VALUE_SCOPE, new Error('connection lost')],
      [/^UPDATE `fmb_blueprint_fields` SET table_config = NULL/i, { affectedRows: 1 }],
      [/^UPDATE `fmb_blueprint_fields` SET[\s\S]+ WHERE id/i, { affectedRows: 1 }],
    ]);
    const res = await put('/edge/app/schema/blueprint_fields/f-1', { field_type: 'text' });
    assert.equal(res.status, 500);
    assert.equal(conn.rolledBack(), true);
    assert.equal(conn.committed(), false);
  });

  it('table → text: skips the clear when the cell_targets column is ABSENT (operator-mode, no 500)', async () => {
    conn = makeConn([
      probe(VO_COLUMNS_PRE_MIGRATION),
      [/SELECT id, blueprint_id, field_type(?:, field_key)?(?:, depends_on_field_key)?(?:, value_source)?(?:, value_scope)?(?:, options_source)? FROM `fmb_blueprint_fields`/i, [{ id: 'f-1', blueprint_id: 'bp-1', field_type: 'table' }]],
      [/^UPDATE `fmb_blueprint_fields` SET[\s\S]+ WHERE id/i, { affectedRows: 1 }],
      [/^UPDATE `fmb_blueprint_fields` SET table_config = NULL/i, { affectedRows: 1 }],
      [/^INSERT INTO `fmb_feature_audit`/i, { affectedRows: 1 }],
      [/SELECT \* FROM `fmb_blueprint_fields` WHERE id/i, [{ id: 'f-1', field_type: 'text', blueprint_id: 'bp-1' }]],
    ]);
    const res = await put('/edge/app/schema/blueprint_fields/f-1', { field_type: 'text' });
    assert.equal(res.status, 200);
    assert.equal(conn.committed(), true);
    assert.equal(conn.queries.some((q) => CLEAR_SCOPES.test(q.sql)), false,
      'naming an absent column would 1054 and roll the whole type change back');
    const meta = JSON.parse(conn.queries.find((q) => /feature_audit/i.test(q.sql)).params[2]);
    assert.equal(meta.cleared_cell_targets_count, 0);
  });

  it('table → text: a blind probe over a DB that really lacks the column still completes the type change', async () => {
    conn = makeConn([
      // Probe comes back empty (unknown set) → the clear is attempted and 1054s.
      [COLUMN_PROBE, (_sql, params) => {
        const table = Array.isArray(params) ? params[0] : undefined;
        if (table === 'fmb_field_options') return FIELD_OPTIONS_COLUMNS;
        if (table === 'fmb_variant_overrides') return [];
        return DEFAULT_BF_COLUMNS;
      }],
      [/SELECT id, blueprint_id, field_type(?:, field_key)?(?:, depends_on_field_key)?(?:, value_source)?(?:, value_scope)?(?:, options_source)? FROM `fmb_blueprint_fields`/i, [{ id: 'f-1', blueprint_id: 'bp-1', field_type: 'table' }]],
      [/^UPDATE `fmb_blueprint_fields` SET[\s\S]+ WHERE id/i, { affectedRows: 1 }],
      [/^UPDATE `fmb_blueprint_fields` SET table_config = NULL/i, { affectedRows: 1 }],
      [CLEAR_SCOPES, Object.assign(new Error("Unknown column 'cell_targets' in 'field list'"), {
        errno: 1054, code: 'ER_BAD_FIELD_ERROR',
      })],
      [/^INSERT INTO `fmb_feature_audit`/i, { affectedRows: 1 }],
      [/SELECT \* FROM `fmb_blueprint_fields` WHERE id/i, [{ id: 'f-1', field_type: 'text', blueprint_id: 'bp-1' }]],
    ]);
    const res = await put('/edge/app/schema/blueprint_fields/f-1', { field_type: 'text' });
    assert.equal(res.status, 200, 'a missing-column error must not fail the type change');
    assert.equal(conn.committed(), true);
    assert.equal(conn.rolledBack(), false);
  });

  it('table → text: any other failure of the clear rolls the whole type change back', async () => {
    conn = makeConn([
      probe(VO_COLUMNS),
      [/SELECT id, blueprint_id, field_type(?:, field_key)?(?:, depends_on_field_key)?(?:, value_source)?(?:, value_scope)?(?:, options_source)? FROM `fmb_blueprint_fields`/i, [{ id: 'f-1', blueprint_id: 'bp-1', field_type: 'table' }]],
      [/^UPDATE `fmb_blueprint_fields` SET[\s\S]+ WHERE id/i, { affectedRows: 1 }],
      [/^UPDATE `fmb_blueprint_fields` SET table_config = NULL/i, { affectedRows: 1 }],
      [CLEAR_SCOPES, new Error('connection lost')],
    ]);
    const res = await put('/edge/app/schema/blueprint_fields/f-1', { field_type: 'text' });
    assert.equal(res.status, 500);
    assert.equal(conn.rolledBack(), true);
    assert.equal(conn.committed(), false);
  });

  it('select → text: leaves variant_overrides alone (only a field LEAVING table type widens a scope)', async () => {
    conn = makeConn([
      probe(VO_COLUMNS),
      [/SELECT id, blueprint_id, field_type(?:, field_key)?(?:, depends_on_field_key)?(?:, value_source)?(?:, value_scope)?(?:, options_source)? FROM `fmb_blueprint_fields`/i, [{ id: 'f-1', blueprint_id: 'bp-1', field_type: 'select' }]],
      [/^UPDATE `fmb_blueprint_fields` SET/i, { affectedRows: 1 }],
      [/^DELETE FROM `fmb_field_options`/i, { affectedRows: 1 }],
      [/^INSERT INTO `fmb_feature_audit`/i, { affectedRows: 1 }],
      [/SELECT \* FROM `fmb_blueprint_fields` WHERE id/i, [{ id: 'f-1', field_type: 'text', blueprint_id: 'bp-1' }]],
    ]);
    const res = await put('/edge/app/schema/blueprint_fields/f-1', { field_type: 'text' });
    assert.equal(res.status, 200);
    assert.equal(conn.queries.some((q) => /fmb_variant_overrides/i.test(q.sql)), false);
  });

  it('table → table (no type change): leaves every stored scope untouched', async () => {
    conn = makeConn([
      probe(VO_COLUMNS),
      [/SELECT id, blueprint_id, field_type(?:, field_key)?(?:, depends_on_field_key)?(?:, value_source)?(?:, value_scope)?(?:, options_source)? FROM `fmb_blueprint_fields`/i, [{ id: 'f-1', blueprint_id: 'bp-1', field_type: 'table' }]],
      [/^UPDATE `fmb_blueprint_fields` SET/i, { affectedRows: 1 }],
      [/SELECT \* FROM `fmb_blueprint_fields` WHERE id/i, [{ id: 'f-1', field_type: 'table', blueprint_id: 'bp-1' }]],
    ]);
    const res = await put('/edge/app/schema/blueprint_fields/f-1', { field_label: 'Renamed' });
    assert.equal(res.status, 200);
    assert.equal(conn.queries.some((q) => CLEAR_SCOPES.test(q.sql)), false);
  });
});

describe('PUT /blueprint_fields/:id — operator-mode column gate (P2-1)', () => {
  it('drops depends_on_field_key when the column is ABSENT (no 500)', async () => {
    let updateSql = null;
    conn = makeConn([
      // Degraded schema: depends_on_field_key (v3.2.129 ADD COLUMN) was warn-skipped.
      [COLUMN_PROBE, [
        { COLUMN_NAME: 'id' }, { COLUMN_NAME: 'blueprint_id' },
        { COLUMN_NAME: 'field_type' }, { COLUMN_NAME: 'field_key' },
        { COLUMN_NAME: 'field_label' },
      ]],
      [/SELECT id, blueprint_id, field_type(?:, field_key)?(?:, depends_on_field_key)?(?:, value_source)?(?:, value_scope)?(?:, options_source)? FROM `fmb_blueprint_fields`/i, [{ id: 'f-1', blueprint_id: 'bp-1', field_type: 'select' }]],
      [/^UPDATE `fmb_blueprint_fields` SET/i, (sql) => { updateSql = sql; return { affectedRows: 1 }; }],
      [/SELECT \* FROM `fmb_blueprint_fields` WHERE id/i, [{ id: 'f-1', field_type: 'select', blueprint_id: 'bp-1' }]],
    ]);
    const res = await put('/edge/app/schema/blueprint_fields/f-1', {
      field_label: 'Renamed',
      depends_on_field_key: 'parent_key',
    });
    assert.equal(res.status, 200);
    assert.equal(conn.committed(), true);
    // The absent cascade column must not appear in the SET clause.
    assert.doesNotMatch(updateSql, /`depends_on_field_key`/);
    // The present column still updates.
    assert.match(updateSql, /`field_label` = \?/);
  });

  it('keeps depends_on_field_key when the column EXISTS', async () => {
    let updateSql = null;
    conn = makeConn([
      [COLUMN_PROBE, [
        { COLUMN_NAME: 'id' }, { COLUMN_NAME: 'blueprint_id' },
        { COLUMN_NAME: 'field_type' }, { COLUMN_NAME: 'field_label' },
        { COLUMN_NAME: 'depends_on_field_key' },
      ]],
      [/SELECT id, blueprint_id, field_type(?:, field_key)?(?:, depends_on_field_key)?(?:, value_source)?(?:, value_scope)?(?:, options_source)? FROM `fmb_blueprint_fields`/i, [{ id: 'f-1', blueprint_id: 'bp-1', field_type: 'select' }]],
      [/^UPDATE `fmb_blueprint_fields` SET/i, (sql) => { updateSql = sql; return { affectedRows: 1 }; }],
      [/SELECT \* FROM `fmb_blueprint_fields` WHERE id/i, [{ id: 'f-1', field_type: 'select', blueprint_id: 'bp-1' }]],
    ]);
    const res = await put('/edge/app/schema/blueprint_fields/f-1', {
      field_label: 'Renamed',
      depends_on_field_key: 'parent_key',
    });
    assert.equal(res.status, 200);
    assert.match(updateSql, /`depends_on_field_key` = \?/);
  });
});

describe('PUT /blueprint_fields/:id — reset option tags on parent change (P2-6)', () => {
  // The old row's stored depends_on_field_key is returned by the field SELECT so
  // the handler can compare it to the incoming value.
  function fieldSelectRow(currentDepends) {
    return [{ id: 'f-1', blueprint_id: 'bp-1', field_type: 'select', depends_on_field_key: currentDepends }];
  }

  it('resets field_options.valid_parent_values when depends_on_field_key CHANGES', async () => {
    let resetParams = null;
    conn = makeConn([
      [/SELECT id, blueprint_id, field_type(?:, field_key)?(?:, depends_on_field_key)?(?:, value_source)?(?:, value_scope)?(?:, options_source)? FROM `fmb_blueprint_fields`/i, fieldSelectRow('series')],
      [/^UPDATE `fmb_blueprint_fields` SET/i, { affectedRows: 1 }],
      [/^UPDATE `fmb_field_options` SET valid_parent_values = NULL WHERE field_id = \?/i,
        (_sql, params) => { resetParams = params; return { affectedRows: 3 }; }],
      [/SELECT \* FROM `fmb_blueprint_fields` WHERE id/i, [{ id: 'f-1', field_type: 'select', blueprint_id: 'bp-1' }]],
    ]);
    const res = await put('/edge/app/schema/blueprint_fields/f-1', {
      depends_on_field_key: 'engine',
    });
    assert.equal(res.status, 200);
    assert.equal(conn.committed(), true);
    const resetCall = conn.queries.find((q) => /UPDATE `fmb_field_options` SET valid_parent_values = NULL/i.test(q.sql));
    assert.ok(resetCall, 'tag reset UPDATE should fire on parent change');
    assert.deepEqual(resetParams, ['f-1']);
  });

  it('does NOT reset tags when depends_on_field_key is UNCHANGED', async () => {
    conn = makeConn([
      [/SELECT id, blueprint_id, field_type(?:, field_key)?(?:, depends_on_field_key)?(?:, value_source)?(?:, value_scope)?(?:, options_source)? FROM `fmb_blueprint_fields`/i, fieldSelectRow('series')],
      [/^UPDATE `fmb_blueprint_fields` SET/i, { affectedRows: 1 }],
      [/SELECT \* FROM `fmb_blueprint_fields` WHERE id/i, [{ id: 'f-1', field_type: 'select', blueprint_id: 'bp-1' }]],
    ]);
    const res = await put('/edge/app/schema/blueprint_fields/f-1', {
      depends_on_field_key: 'series',
      field_label: 'Same parent',
    });
    assert.equal(res.status, 200);
    const hasReset = conn.queries.some((q) => /UPDATE `fmb_field_options` SET valid_parent_values = NULL/i.test(q.sql));
    assert.equal(hasReset, false, 'must not reset tags when parent is unchanged');
  });

  it('does NOT reset tags when the request omits depends_on_field_key entirely', async () => {
    conn = makeConn([
      [/SELECT id, blueprint_id, field_type(?:, field_key)?(?:, depends_on_field_key)?(?:, value_source)?(?:, value_scope)?(?:, options_source)? FROM `fmb_blueprint_fields`/i, fieldSelectRow('series')],
      [/^UPDATE `fmb_blueprint_fields` SET/i, { affectedRows: 1 }],
      [/SELECT \* FROM `fmb_blueprint_fields` WHERE id/i, [{ id: 'f-1', field_type: 'select', blueprint_id: 'bp-1' }]],
    ]);
    const res = await put('/edge/app/schema/blueprint_fields/f-1', {
      field_label: 'Only a label change',
    });
    assert.equal(res.status, 200);
    const hasReset = conn.queries.some((q) => /UPDATE `fmb_field_options` SET valid_parent_values = NULL/i.test(q.sql));
    assert.equal(hasReset, false);
  });

  it('operator-mode: skips reset when field_options.valid_parent_values column is ABSENT (no 500)', async () => {
    conn = makeConn([
      // field_options probe returns a schema WITHOUT valid_parent_values.
      [COLUMN_PROBE, (_sql, params) => {
        const table = Array.isArray(params) ? params[0] : undefined;
        if (table === 'fmb_field_options') {
          return [{ COLUMN_NAME: 'id' }, { COLUMN_NAME: 'field_id' }, { COLUMN_NAME: 'option_value' }];
        }
        return DEFAULT_BF_COLUMNS;
      }],
      [/SELECT id, blueprint_id, field_type(?:, field_key)?(?:, depends_on_field_key)?(?:, value_source)?(?:, value_scope)?(?:, options_source)? FROM `fmb_blueprint_fields`/i, fieldSelectRow('series')],
      [/^UPDATE `fmb_blueprint_fields` SET/i, { affectedRows: 1 }],
      [/SELECT \* FROM `fmb_blueprint_fields` WHERE id/i, [{ id: 'f-1', field_type: 'select', blueprint_id: 'bp-1' }]],
    ]);
    const res = await put('/edge/app/schema/blueprint_fields/f-1', {
      depends_on_field_key: 'engine',
    });
    assert.equal(res.status, 200);
    assert.equal(conn.committed(), true);
    const hasReset = conn.queries.some((q) => /UPDATE `fmb_field_options` SET valid_parent_values = NULL/i.test(q.sql));
    assert.equal(hasReset, false, 'must skip reset (and not 500) when column absent');
  });

  it('resets tags when re-parenting from NULL (previously no parent) to a real parent', async () => {
    conn = makeConn([
      [/SELECT id, blueprint_id, field_type(?:, field_key)?(?:, depends_on_field_key)?(?:, value_source)?(?:, value_scope)?(?:, options_source)? FROM `fmb_blueprint_fields`/i, fieldSelectRow(null)],
      [/^UPDATE `fmb_blueprint_fields` SET/i, { affectedRows: 1 }],
      [/^UPDATE `fmb_field_options` SET valid_parent_values = NULL WHERE field_id = \?/i, { affectedRows: 0 }],
      [/SELECT \* FROM `fmb_blueprint_fields` WHERE id/i, [{ id: 'f-1', field_type: 'select', blueprint_id: 'bp-1' }]],
    ]);
    const res = await put('/edge/app/schema/blueprint_fields/f-1', {
      depends_on_field_key: 'engine',
    });
    assert.equal(res.status, 200);
    const hasReset = conn.queries.some((q) => /UPDATE `fmb_field_options` SET valid_parent_values = NULL/i.test(q.sql));
    assert.equal(hasReset, true, 'NULL → real parent is a change → reset');
  });
});

describe('PUT /blueprint_fields/:id — CRITICAL: operator-mode old-row SELECT must not name an absent column', () => {
  // Operator-mode: the v3.2.129 `ADD COLUMN depends_on_field_key` was warn-skipped
  // (privilege errno 1142). The old-row SELECT must probe the column set FIRST and
  // omit depends_on_field_key from the SELECT list when it is absent — otherwise the
  // SELECT itself throws ER_BAD_FIELD_ERROR (1054) and 500s every FieldEditor save.
  it('does not 500 when depends_on_field_key is ABSENT (probe-then-branch SELECT)', async () => {
    let oldRowSelectSql = null;
    conn = makeConn([
      // Degraded schema: column absent from blueprint_fields.
      [COLUMN_PROBE, (_sql, params) => {
        const table = Array.isArray(params) ? params[0] : undefined;
        if (table === 'fmb_field_options') return FIELD_OPTIONS_COLUMNS;
        return [
          { COLUMN_NAME: 'id' }, { COLUMN_NAME: 'blueprint_id' },
          { COLUMN_NAME: 'field_type' }, { COLUMN_NAME: 'field_key' },
          { COLUMN_NAME: 'field_label' },
        ];
      }],
      // A SELECT that actually names depends_on_field_key THROWS like MariaDB would.
      [/SELECT id, blueprint_id, field_type(?:, field_key)?, depends_on_field_key FROM `fmb_blueprint_fields`/i,
        Object.assign(new Error("Unknown column 'depends_on_field_key' in 'field list'"), {
          errno: 1054, code: 'ER_BAD_FIELD_ERROR',
        })],
      // The safe SELECT (no cascade column) is what the handler MUST issue instead.
      [/SELECT id, blueprint_id, field_type(?:, field_key)? FROM `fmb_blueprint_fields`/i, (sql) => {
        oldRowSelectSql = sql;
        return [{ id: 'f-1', blueprint_id: 'bp-1', field_type: 'select', field_key: 'k' }];
      }],
      [/^UPDATE `fmb_blueprint_fields` SET/i, { affectedRows: 1 }],
      [/SELECT \* FROM `fmb_blueprint_fields` WHERE id/i, [{ id: 'f-1', field_type: 'select', blueprint_id: 'bp-1' }]],
    ]);
    // Ordinary field edit (no cascade involved) must succeed in operator-mode.
    const res = await put('/edge/app/schema/blueprint_fields/f-1', { field_label: 'Renamed' });
    assert.equal(res.status, 200, 'operator-mode field edit must return 200, not 500');
    assert.equal(conn.committed(), true);
    // The handler must have used the safe SELECT (column omitted), not the throwing one.
    assert.ok(oldRowSelectSql, 'safe SELECT (without depends_on_field_key) should be issued');
    assert.doesNotMatch(oldRowSelectSql, /depends_on_field_key/);
  });
});

describe('PUT /blueprint_fields/:id — HIGH: empty-string parent must not wipe pre-set tags', () => {
  // FieldEditor always spreads the full form, so a never-parented field is sent as
  // depends_on_field_key: '' while the stored DB value is null. '' must normalize to
  // null so a label-only edit is treated as "no parent change" — otherwise it wrongly
  // wipes any tags an admin pre-set.
  it('does NOT reset tags when stored=null and incoming=empty-string (label-only edit)', async () => {
    conn = makeConn([
      [/SELECT id, blueprint_id, field_type(?:, field_key)?(?:, depends_on_field_key)?(?:, value_source)?(?:, value_scope)?(?:, options_source)? FROM `fmb_blueprint_fields`/i,
        [{ id: 'f-1', blueprint_id: 'bp-1', field_type: 'select', depends_on_field_key: null }]],
      [/^UPDATE `fmb_blueprint_fields` SET/i, { affectedRows: 1 }],
      [/SELECT \* FROM `fmb_blueprint_fields` WHERE id/i, [{ id: 'f-1', field_type: 'select', blueprint_id: 'bp-1' }]],
    ]);
    const res = await put('/edge/app/schema/blueprint_fields/f-1', {
      field_label: 'Renamed only',
      depends_on_field_key: '',
    });
    assert.equal(res.status, 200);
    const hasReset = conn.queries.some((q) => /UPDATE `fmb_field_options` SET valid_parent_values = NULL/i.test(q.sql));
    assert.equal(hasReset, false, "'' ↔ null is no change → must not wipe tags");
  });
});
