/**
 * blueprint-fields-create-table-column-compute-rule.test.js (fmb-1942) —
 * `validateComputeRuleBeforeWrite` (the generic POST /blueprint_fields
 * preWriteInTx hook) must judge table_config.columns[].rules.compute_rule
 * the same way it judges the field's own compute_rule, and MUST NOT skip
 * that judgement when the create carries no field-level compute_rule at all
 * (the hook's original early-return was `if (write.compute_rule == null)
 * return null`, which would have skipped table_config entirely).
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');

const dbKey = require.resolve('../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey,
  filename: dbKey,
  loaded: true,
  exports: {
    pool: { rw: { async query() { return []; } }, ro: { async query() { return []; } } },
    t: (name) => `fmb_${name}`,
    getDynamicPool: async () => ({ rw: { async query() { return []; } } }),
  },
};

const { validateComputeRuleBeforeWrite } = require('../../src/edge/routes/app/schema/routes-blueprint-fields');

const BLUEPRINT_ID = '99999999-9999-4999-8999-999999999999';

const sameCol = (columnKey) => ({
  op: 'concat',
  overridable: true,
  output_type: 'string',
  config: { parts: [{ type: 'same_table_column', column_key: columnKey }] },
});

/** A connection that answers the compute_rule column as present and the
 * blueprint compute-state scan with `existingRows`. */
function makeConn(existingRows = []) {
  const seen = [];
  return {
    seen,
    async query(sql, params) {
      seen.push({ sql: String(sql).replace(/\s+/g, ' ').trim(), params: params || [] });
      if (/information_schema/i.test(sql)) return [{ COLUMN_NAME: 'compute_rule' }];
      if (/SELECT field_key, field_type, table_config, compute_rule FROM/i.test(sql)) return existingRows;
      return [];
    },
  };
}

describe('validateComputeRuleBeforeWrite — table_config column-level compute_rule (fmb-1942)', () => {
  it('accepts a create carrying a valid column rule and NO field-level compute_rule', async () => {
    const conn = makeConn();
    const err = await validateComputeRuleBeforeWrite(conn, { body: {} }, {
      blueprint_id: BLUEPRINT_ID,
      field_key: 'items',
      field_type: 'table',
      compute_rule: null,
      table_config: JSON.stringify({
        columns: [{ key: 'part' }, { key: 'label', rules: { compute_rule: sameCol('part') } }],
      }),
    });
    assert.equal(err, null, JSON.stringify(err));
  });

  it('rejects a create carrying a column rule with a self-referencing same_table_column term, naming the column', async () => {
    const conn = makeConn();
    const err = await validateComputeRuleBeforeWrite(conn, { body: {} }, {
      blueprint_id: BLUEPRINT_ID,
      field_key: 'items',
      field_type: 'table',
      compute_rule: null,
      table_config: JSON.stringify({
        columns: [{ key: 'part' }, { key: 'label', rules: { compute_rule: sameCol('label') } }],
      }),
    });
    assert.ok(err, 'a self-referencing column rule must be refused');
    assert.equal(err.status, 400);
    assert.equal(err.code, 'same_table_column_cycle');
    assert.match(err.message, /label/, "the refusal must name the column key ('label')");
  });

  it('rejects a create whose column rule reads a non-existent sibling column', async () => {
    const conn = makeConn();
    const err = await validateComputeRuleBeforeWrite(conn, { body: {} }, {
      blueprint_id: BLUEPRINT_ID,
      field_key: 'items',
      field_type: 'table',
      compute_rule: null,
      table_config: JSON.stringify({
        columns: [{ key: 'part' }, { key: 'label', rules: { compute_rule: sameCol('ghost') } }],
      }),
    });
    assert.ok(err);
    assert.equal(err.status, 400);
    assert.equal(err.code, 'bad_same_table_column');
  });

  it('does nothing when the create carries neither compute_rule nor table_config', async () => {
    const conn = makeConn();
    const err = await validateComputeRuleBeforeWrite(conn, { body: {} }, {
      blueprint_id: BLUEPRINT_ID, field_key: 'plain', field_type: 'text',
    });
    assert.equal(err, null);
    assert.equal(conn.seen.length, 0, 'a write carrying neither must never open the blueprint scan');
  });
});
