// api-connectors-bindings-missing-table.test.js — the join table
// (fmb_api_connector_blueprints) is additive; its create-table migration is
// severity 'warning', so a target DB may legitimately lack it. Both the read
// enrichment (bindings projection) and the connector-delete cleanup must
// tolerate a missing table (errno 1146): the read yields bindings: [] rather
// than a 500, and the delete succeeds rather than 1146-failing. Exercised
// through the real api-connectors router so the enrichRows hook and the
// tolerantDependentCleanup wiring are the code under test, not a stand-in.
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../src/edge/db');

let conn;
let joinErrno; // the error the join-table query raises (1146 missing table / 1054 missing column)
function makeConn() {
  const queries = [];
  return {
    queries,
    async query(sql) {
      queries.push(sql);
      // The additive join table raises the configured error on this target.
      if (/`fmb_api_connector_blueprints`/.test(sql)) {
        const e = joinErrno === 1054
          ? Object.assign(new Error("Unknown column 'connector_id'"), { errno: 1054, code: 'ER_BAD_FIELD_ERROR' })
          : Object.assign(new Error("Table 'fmb_api_connector_blueprints' doesn't exist"), { errno: 1146, code: 'ER_NO_SUCH_TABLE' });
        throw e;
      }
      if (/SELECT \* FROM `fmb_api_connectors` WHERE id = \?/.test(sql)) {
        return [{ id: 'c1', owner_id: 'admin-1', blueprint_id: 'home', auth_config: null, request_config: null, response_config: null }];
      }
      if (/FROM `fmb_users`/.test(sql)) return [];
      if (/^DELETE FROM `fmb_api_connectors`/.test(sql)) return { affectedRows: 1 };
      if (/^SELECT/i.test(sql)) return [];
      if (/^(DELETE|UPDATE|INSERT)/i.test(sql)) return { affectedRows: 1 };
      return [];
    },
    async beginTransaction() {}, async commit() {}, async rollback() {}, release() {},
  };
}

const poolSpy = { rw: { async getConnection() { return conn; } }, ro: { async getConnection() { return conn; } } };
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: poolSpy, t: (name) => `fmb_${name}`, getDynamicPool: async () => poolSpy },
};

const connectorsRouter = require('../../src/edge/routes/app/api-connectors');

let server; let port;
before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { req.user = { id: 'admin-1', email: 'admin@test', role: 'admin' }; next(); });
  app.use('/api-connectors', connectorsRouter);
  await new Promise((resolve) => { server = app.listen(0, '127.0.0.1', () => { port = server.address().port; resolve(); }); });
});
after(async () => { await new Promise((resolve) => server.close(resolve)); delete require.cache[dbKey]; });
beforeEach(() => { joinErrno = 1146; conn = makeConn(); });

function send(method, path) {
  return new Promise((resolve, reject) => {
    const req = http.request({ method, host: '127.0.0.1', port, path, headers: { 'content-type': 'application/json' } }, (res) => {
      let d = ''; res.on('data', (c) => { d += c; }); res.on('end', () => resolve({ status: res.statusCode, body: d ? JSON.parse(d) : null })); });
    req.on('error', reject); req.end();
  });
}

describe('connector reads/deletes tolerate a missing join table', () => {
  it('detail GET yields bindings: [] instead of a 500 when the join table is absent', async () => {
    const r = await send('GET', '/api-connectors/c1');
    assert.equal(r.status, 200);
    assert.deepEqual(r.body.data.bindings, []);
    assert.ok(conn.queries.some((q) => /`fmb_api_connector_blueprints`/.test(q)), 'the enrichment SELECT was attempted');
  });

  it('DELETE succeeds when the join-row cleanup hits a missing join table', async () => {
    const r = await send('DELETE', '/api-connectors/c1');
    assert.equal(r.status, 200);
    assert.ok(conn.queries.some((q) => /^DELETE FROM `fmb_api_connector_blueprints`/.test(q)), 'the tolerant cleanup DELETE was attempted');
  });

  it('DELETE does NOT swallow a missing-COLUMN error (1054) from the join cleanup', async () => {
    // F7 tolerance is missing-TABLE only; a 1054 is a schema-parity defect and
    // must surface as a 500, not be silently absorbed as "nothing to clean".
    joinErrno = 1054; conn = makeConn();
    const r = await send('DELETE', '/api-connectors/c1');
    assert.equal(r.status, 500);
  });
});
