/**
 * blueprint-field-import-guard-table-column-compute-rule.test.js (fmb-1942) —
 * `checkImportedBlueprintFields` must judge table_config.columns[].rules.
 * compute_rule the SAME way it judges the field-level compute_rule, and
 * independently of it: an imported row can carry per-column rules with no
 * field-level compute_rule at all (the field's OWN value_source stays
 * 'entered'), and the field-level early-return in the guard's per-row loop
 * must not skip them.
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');

const { checkImportedBlueprintFields } = require('../../src/edge/lib/blueprint-field-import-guard');

const sameCol = (columnKey) => ({
  op: 'concat',
  overridable: true,
  output_type: 'string',
  config: { parts: [{ type: 'same_table_column', column_key: columnKey }] },
});

const itemsField = (columns, overrides = {}) => ({
  field_key: 'items',
  field_type: 'table',
  value_source: 'entered',
  table_config: { columns },
  ...overrides,
});

describe('checkImportedBlueprintFields — table_config column-level compute_rule (fmb-1942)', () => {
  it('accepts a valid column rule reading a sibling column, field-level compute_rule absent', () => {
    const { errors } = checkImportedBlueprintFields([
      itemsField([{ key: 'part' }, { key: 'label', rules: { compute_rule: sameCol('part') } }]),
    ]);
    assert.deepEqual(errors, []);
  });

  it('rejects a column rule naming a non-existent sibling column, naming the column key', () => {
    const { errors } = checkImportedBlueprintFields([
      itemsField([{ key: 'part' }, { key: 'label', rules: { compute_rule: sameCol('ghost') } }]),
    ]);
    assert.ok(
      errors.some((e) => e.includes('label') && e.includes('bad_same_table_column')),
      `expected a bad_same_table_column error naming 'label', got: ${JSON.stringify(errors)}`,
    );
  });

  it('rejects a self-referencing column rule as a cycle', () => {
    const { errors } = checkImportedBlueprintFields([
      itemsField([{ key: 'part' }, { key: 'label', rules: { compute_rule: sameCol('label') } }]),
    ]);
    assert.ok(
      errors.some((e) => e.includes('label') && e.includes('same_table_column_cycle')),
      `expected a self-reference cycle error naming 'label', got: ${JSON.stringify(errors)}`,
    );
  });

  it('rejects a column rule referencing a field that is not part of the imported payload', () => {
    const rule = {
      op: 'transform', overridable: true, output_type: 'string',
      config: { source: { type: 'field', key: 'ghost_field' }, transform: 'upper' },
    };
    const { errors } = checkImportedBlueprintFields([
      itemsField([{ key: 'part', rules: { compute_rule: rule } }]),
    ]);
    assert.ok(
      errors.some((e) => e.includes('part') && e.includes('missing_source')),
      `expected a missing_source error naming 'part', got: ${JSON.stringify(errors)}`,
    );
  });

  it('accepts a column rule reading a scalar field from the same payload', () => {
    const rule = {
      op: 'transform', overridable: true, output_type: 'string',
      config: { source: { type: 'field', key: 'prefix' }, transform: 'upper' },
    };
    const { errors } = checkImportedBlueprintFields([
      { field_key: 'prefix', field_type: 'text', value_source: 'entered' },
      itemsField([{ key: 'part', rules: { compute_rule: rule } }]),
    ]);
    assert.deepEqual(errors, []);
  });
});
