/**
 * blueprint-serialization-legacy-value-source-fingerprint.test.js
 *
 * `copied` is a retired mode, byte-equivalent to `calculated` carrying the
 * same rule (readValueSourceForEditor, the FE twin of this collapse). The
 * import-diff and the copy-subset staleness check both derive from
 * `fieldFingerprint` (blueprint-serialization.js), so a stored `copied` row
 * must fingerprint identically to the same row saved as `calculated` —
 * otherwise PR-B's read-time collapse on one side of a comparison and a
 * still-`copied` source on the other reads as a content change that never
 * happened.
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');

const { fieldFingerprint } = require('../../src/edge/lib/blueprint-serialization');

function baseField(overrides) {
  return {
    field_label: 'Trim', field_type: 'text', is_required: 0, default_value: '',
    placeholder: '', tooltip: '', section: 'general', order_index: 0,
    table_config: null, visibility_rule: null, depends_on_field_key: null,
    retain_when_hidden: 0, choice_config: null, group_key: null, matrix_row_key: null,
    value_source: 'entered', value_scope: null, compute_rule: null, options_source: null,
    ...overrides,
  };
}

describe('fieldFingerprint — legacy `copied` collapses to `calculated`', () => {
  const rule = {
    op: 'concat', overridable: false, output_type: 'string',
    config: { separator: '', parts: [{ type: 'field', key: 'base' }] },
  };

  it('a stored `copied` field fingerprints identically to the same field as `calculated`', () => {
    const copied = baseField({ value_source: 'copied', compute_rule: rule });
    const calculated = baseField({ value_source: 'calculated', compute_rule: rule });
    assert.equal(fieldFingerprint(copied), fieldFingerprint(calculated));
    // Revert probe: with the normaliser bypassed this is the assertion that
    // goes red — the two strings differ only in the value_source token.
  });

  it('an `entered` field still fingerprints differently from a `calculated` one (the collapse is not a blanket equality)', () => {
    const entered = baseField({ value_source: 'entered', compute_rule: null });
    const calculated = baseField({ value_source: 'calculated', compute_rule: rule });
    assert.notEqual(fieldFingerprint(entered), fieldFingerprint(calculated));
  });

  // R-D-C2: the same collapse, one level deeper — a TABLE field's per-column
  // rules (table_config.columns[].rules.value_source) carry their own
  // `copied`, independent of the field-level column above.
  it('a stored `copied` table column fingerprints identically to the same column as `calculated`', () => {
    const copiedTableConfig = {
      columns: [
        { key: 'c1', label: 'C1', rules: { value_source: 'copied', compute_rule: rule } },
        { key: 'c2', label: 'C2' },
      ],
    };
    const calculatedTableConfig = {
      columns: [
        { key: 'c1', label: 'C1', rules: { value_source: 'calculated', compute_rule: rule } },
        { key: 'c2', label: 'C2' },
      ],
    };
    const copied = baseField({ field_type: 'table', table_config: copiedTableConfig });
    const calculated = baseField({ field_type: 'table', table_config: calculatedTableConfig });
    assert.equal(fieldFingerprint(copied), fieldFingerprint(calculated));
    // Revert probe: with the table_config normalisation bypassed this is the
    // assertion that goes red — the two strings differ only in the nested
    // column's value_source token.
  });
});
