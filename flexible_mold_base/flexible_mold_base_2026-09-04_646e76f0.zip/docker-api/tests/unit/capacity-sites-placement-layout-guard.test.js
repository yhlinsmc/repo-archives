/**
 * capacity-sites-placement-layout-guard.test.js — the per-DC (Q16) write-
 * boundary gate on cap_sites.metadata.placement_layout: unknown key or
 * out-of-bounds value -> 400 (or a validation error string on the pure
 * helper), across every censused write path that can persist site metadata
 * (children.js generic CRUD `sites` mount, wizard.js bulk create, io.js
 * scenario-import commit) — all three route modules import and apply the
 * SAME `sitesMetadataPlacementLayoutError` from `_shared.js` (guard-on-one-
 * path is a known failure family in this repo; this file is the shared-guard
 * regression net for all three call sites at once).
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');

// _shared.js destructures { t } from ../../../db at load (never calls it at
// load time) and requires ../../../db (pool, t) — stub it so the require is
// side-effect-free (no pool), matching capacity-delete-preview-schema-parity.test.js.
const dbKey = require.resolve('../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: {}, t: (n) => n },
};

const {
  sitesMetadataPlacementLayoutError, rejectInvalidSitesPlacementLayout,
} = require('../../src/edge/routes/app/capacity/_shared');
const { buildWizardPlan } = require('../../src/edge/routes/app/capacity/wizard');
const { buildImportPlan } = require('../../src/edge/routes/app/capacity/io');

describe('sitesMetadataPlacementLayoutError — the pure per-DC validator (Q16)', () => {
  it('null/absent metadata is valid (no placement_layout to judge)', () => {
    assert.equal(sitesMetadataPlacementLayoutError(null), null);
    assert.equal(sitesMetadataPlacementLayoutError(undefined), null);
  });
  it('metadata with no placement_layout key is valid — other metadata keys stay free-form', () => {
    assert.equal(sitesMetadataPlacementLayoutError({ some_other_key: 'x' }), null);
  });
  it('a null placement_layout (inherit) is valid', () => {
    assert.equal(sitesMetadataPlacementLayoutError({ placement_layout: null }), null);
  });
  it('a valid per-DC override (dense_columns/dense_hosts_per_column only) is valid', () => {
    assert.equal(sitesMetadataPlacementLayoutError({ placement_layout: { dense_columns: 2 } }), null);
    assert.equal(
      sitesMetadataPlacementLayoutError({ placement_layout: { dense_hosts_per_column: 8, dense_columns: 3 } }),
      null,
    );
  });
  it('dense_threshold in a site\'s placement_layout is REJECTED (400-equivalent) — Q16 scenario-wide only', () => {
    const err = sitesMetadataPlacementLayoutError({ placement_layout: { dense_threshold: 25 } });
    assert.ok(err);
    assert.equal(err.code, 'BAD_REQUEST');
    assert.match(err.message, /dense_threshold/);
  });
  it('an out-of-bounds dense_columns is REJECTED', () => {
    const err = sitesMetadataPlacementLayoutError({ placement_layout: { dense_columns: 9 } });
    assert.ok(err);
    assert.match(err.message, /between 1 and 8/);
  });
  it('a metadata JSON STRING (the wire shape a raw import row may carry) is judged the same as a parsed object', () => {
    const err = sitesMetadataPlacementLayoutError(JSON.stringify({ placement_layout: { dense_threshold: 99 } }));
    assert.ok(err);
    assert.match(err.message, /dense_threshold/);
  });
});

describe('rejectInvalidSitesPlacementLayout — the children.js sites-mount pre-middleware (route site 1/3)', () => {
  function mockReq(method, body) { return { method, body }; }
  function mockRes() {
    const res = { status(code) { this.statusCode = code; return this; }, json(body) { this.body = body; return this; } };
    return res;
  }

  it('GET is a no-op (only POST/PUT are write methods)', () => {
    const req = mockReq('GET', { metadata: { placement_layout: { dense_threshold: 999 } } });
    const res = mockRes();
    let nextCalled = false;
    rejectInvalidSitesPlacementLayout(req, res, () => { nextCalled = true; });
    assert.equal(nextCalled, true);
    assert.equal(res.statusCode, undefined);
  });

  it('POST with a valid per-DC override calls next()', () => {
    const req = mockReq('POST', { name: 'DC-1', metadata: { placement_layout: { dense_columns: 2 } } });
    const res = mockRes();
    let nextCalled = false;
    rejectInvalidSitesPlacementLayout(req, res, () => { nextCalled = true; });
    assert.equal(nextCalled, true);
  });

  it('POST with an unknown key inside metadata.placement_layout 400s, never reaching next()', () => {
    const req = mockReq('POST', { name: 'DC-1', metadata: { placement_layout: { bogus_key: 1 } } });
    const res = mockRes();
    let nextCalled = false;
    rejectInvalidSitesPlacementLayout(req, res, () => { nextCalled = true; });
    assert.equal(nextCalled, false);
    assert.equal(res.statusCode, 400);
  });

  it('PUT with dense_threshold in metadata.placement_layout 400s (Q16)', () => {
    const req = mockReq('PUT', { metadata: { placement_layout: { dense_threshold: 25 } } });
    const res = mockRes();
    let nextCalled = false;
    rejectInvalidSitesPlacementLayout(req, res, () => { nextCalled = true; });
    assert.equal(nextCalled, false);
    assert.equal(res.statusCode, 400);
  });

  it('a body with no metadata at all calls next() (nothing to judge)', () => {
    const req = mockReq('POST', { name: 'DC-1' });
    const res = mockRes();
    let nextCalled = false;
    rejectInvalidSitesPlacementLayout(req, res, () => { nextCalled = true; });
    assert.equal(nextCalled, true);
  });
});

describe('buildWizardPlan — the wizard bulk-create sites path (route site 2/3)', () => {
  const minimalWizardBody = (siteOverrides) => ({
    name: 'scenario-x',
    sites: [{ ref: 's1', name: 'DC1', ...siteOverrides }],
    hypervisors: [], databases: [], vms: [], db_instances: [],
  });

  it('a valid per-DC override plans ok', () => {
    const plan = buildWizardPlan(minimalWizardBody({ metadata: { placement_layout: { dense_columns: 2 } } }));
    assert.equal(plan.ok, true);
  });
  it('dense_threshold in a wizard site row is rejected (Q16)', () => {
    const plan = buildWizardPlan(minimalWizardBody({ metadata: { placement_layout: { dense_threshold: 25 } } }));
    assert.equal(plan.ok, false);
    assert.ok(plan.errors.some((e) => /dense_threshold/.test(e)));
  });
  it('an out-of-bounds dense_hosts_per_column in a wizard site row is rejected', () => {
    const plan = buildWizardPlan(minimalWizardBody({ metadata: { placement_layout: { dense_hosts_per_column: 999 } } }));
    assert.equal(plan.ok, false);
    assert.ok(plan.errors.some((e) => /dense_hosts_per_column/.test(e)));
  });
});

describe('buildImportPlan — the scenario-import sites sheet path (route site 3/3)', () => {
  it('a valid per-DC override plans with no errors', () => {
    const plan = buildImportPlan(
      { sites: [{ ref: 's1', name: 'DC1', metadata: { placement_layout: { dense_columns: 2 } } }] },
      'actor-1', {},
    );
    assert.deepEqual(plan.errors, []);
  });
  it('dense_threshold in an imported site row\'s metadata is rejected (Q16)', () => {
    const plan = buildImportPlan(
      { sites: [{ ref: 's1', name: 'DC1', metadata: { placement_layout: { dense_threshold: 25 } } }] },
      'actor-1', {},
    );
    assert.equal(plan.errors.length, 1);
    assert.equal(plan.errors[0].sheet, 'sites');
    assert.equal(plan.errors[0].column, 'metadata');
    assert.match(plan.errors[0].message, /dense_threshold/);
  });
  it('an out-of-bounds dense_columns in an imported site row is rejected', () => {
    const plan = buildImportPlan(
      { sites: [{ ref: 's1', name: 'DC1', metadata: { placement_layout: { dense_columns: 99 } } }] },
      'actor-1', {},
    );
    assert.equal(plan.errors.length, 1);
    assert.match(plan.errors[0].message, /between 1 and 8/);
  });
});
