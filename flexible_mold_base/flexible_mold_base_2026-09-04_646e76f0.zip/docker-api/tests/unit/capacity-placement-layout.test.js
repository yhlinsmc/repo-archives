/**
 * capacity-placement-layout.test.js — the server-side dense-placement layout
 * config contract (post-ar2-residuals P6, Q12/Q13/Q15/Q16): the all-or-nothing
 * per-key write validation and the built-in defaults, mirroring
 * capacity-name-patterns.test.js's own structure for the sibling
 * name_patterns feature.
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const {
  DENSE_LAYOUT_DEFAULTS, PLACEMENT_LAYOUT_BOUNDS, PLACEMENT_LAYOUT_ENUMS,
  PLACEMENT_LAYOUT_KEYS_SETTINGS, PLACEMENT_LAYOUT_KEYS_SITE,
  validatePlacementLayoutValue, validatePlacementLayoutWrite,
} = require('../../src/shared/capacity/placement-layout');

describe('DENSE_LAYOUT_DEFAULTS — the built-in pin', () => {
  it('is 20 threshold / 4 columns / 12 hosts per column / even fill / vertical flow', () => {
    assert.deepEqual(DENSE_LAYOUT_DEFAULTS, {
      dense_threshold: 20, dense_columns: 4, dense_hosts_per_column: 12,
      dense_fill_strategy: 'even', dense_flow: 'vertical',
    });
  });
});

describe('PLACEMENT_LAYOUT_ENUMS — the enum-key whitelists (fmb-1913)', () => {
  it('dense_fill_strategy: even/fill', () => {
    assert.deepEqual(PLACEMENT_LAYOUT_ENUMS.dense_fill_strategy, ['even', 'fill']);
  });
  it('dense_flow: vertical/horizontal', () => {
    assert.deepEqual(PLACEMENT_LAYOUT_ENUMS.dense_flow, ['vertical', 'horizontal']);
  });
});

describe('PLACEMENT_LAYOUT_BOUNDS — the write-boundary integer ranges', () => {
  it('dense_threshold: 9..999 (the INVARIANT lower bound — MID_HOST_MAX+1)', () => {
    assert.deepEqual(PLACEMENT_LAYOUT_BOUNDS.dense_threshold, { min: 9, max: 999 });
  });
  it('dense_columns: 1..8 (Q12 hard cap, fmb-1913 raised from 4)', () => {
    assert.deepEqual(PLACEMENT_LAYOUT_BOUNDS.dense_columns, { min: 1, max: 8 });
  });
  it('dense_hosts_per_column: 1..64 (Q12 balancing target)', () => {
    assert.deepEqual(PLACEMENT_LAYOUT_BOUNDS.dense_hosts_per_column, { min: 1, max: 64 });
  });
});

describe('validatePlacementLayoutValue — per-key bounds', () => {
  it('accepts every key at its in-bounds edges', () => {
    assert.equal(validatePlacementLayoutValue('dense_threshold', 9), null);
    assert.equal(validatePlacementLayoutValue('dense_threshold', 999), null);
    assert.equal(validatePlacementLayoutValue('dense_columns', 1), null);
    assert.equal(validatePlacementLayoutValue('dense_columns', 8), null);
    assert.equal(validatePlacementLayoutValue('dense_hosts_per_column', 1), null);
    assert.equal(validatePlacementLayoutValue('dense_hosts_per_column', 64), null);
  });
  it('rejects one below and one above each key\'s bound', () => {
    assert.match(validatePlacementLayoutValue('dense_threshold', 8), /between 9 and 999/);
    assert.match(validatePlacementLayoutValue('dense_threshold', 1000), /between 9 and 999/);
    assert.match(validatePlacementLayoutValue('dense_columns', 0), /between 1 and 8/);
    assert.match(validatePlacementLayoutValue('dense_columns', 9), /between 1 and 8/);
    assert.match(validatePlacementLayoutValue('dense_hosts_per_column', 0), /between 1 and 64/);
    assert.match(validatePlacementLayoutValue('dense_hosts_per_column', 65), /between 1 and 64/);
  });
  it('rejects a non-integer, never silently floors/clamps it', () => {
    assert.match(validatePlacementLayoutValue('dense_columns', 2.5), /whole number/);
    assert.match(validatePlacementLayoutValue('dense_columns', '3'), /whole number/);
    assert.match(validatePlacementLayoutValue('dense_columns', null), /whole number/);
  });
  it('rejects an unknown key', () => {
    assert.match(validatePlacementLayoutValue('bogus_key', 1), /unknown placement_layout key/);
  });
});

describe('validatePlacementLayoutValue — dense_fill_strategy/dense_flow enum keys (fmb-1913)', () => {
  it('accepts every declared enum value', () => {
    assert.equal(validatePlacementLayoutValue('dense_fill_strategy', 'even'), null);
    assert.equal(validatePlacementLayoutValue('dense_fill_strategy', 'fill'), null);
    assert.equal(validatePlacementLayoutValue('dense_flow', 'vertical'), null);
    assert.equal(validatePlacementLayoutValue('dense_flow', 'horizontal'), null);
  });
  it('rejects a string outside the declared set, naming the allowed values', () => {
    assert.match(validatePlacementLayoutValue('dense_fill_strategy', 'bogus'), /must be one of: even, fill/);
    assert.match(validatePlacementLayoutValue('dense_flow', 'diagonal'), /must be one of: vertical, horizontal/);
  });
  it('rejects a non-string, never coerced', () => {
    assert.match(validatePlacementLayoutValue('dense_fill_strategy', 1), /must be one of/);
    assert.match(validatePlacementLayoutValue('dense_flow', null), /must be one of/);
  });
});

describe('validatePlacementLayoutWrite — all-or-nothing, per-key optional (unlike name_patterns\' exact key-set)', () => {
  it('null/undefined is valid (inherited)', () => {
    assert.equal(validatePlacementLayoutWrite(null), null);
    assert.equal(validatePlacementLayoutWrite(undefined), null);
  });
  it('a JSON-string null/empty is treated as inherited (import-path tolerance, matches validateNamePatternsWrite)', () => {
    assert.equal(validatePlacementLayoutWrite(''), null);
    assert.equal(validatePlacementLayoutWrite('null'), null);
  });
  it('an empty object, or a PARTIAL object, is valid — a present subset inherits the rest', () => {
    assert.equal(validatePlacementLayoutWrite({}), null);
    assert.equal(validatePlacementLayoutWrite({ dense_columns: 3 }), null);
  });
  it('a full valid object at the settings tier is valid', () => {
    assert.equal(validatePlacementLayoutWrite(
      { dense_threshold: 25, dense_columns: 3, dense_hosts_per_column: 10 },
      PLACEMENT_LAYOUT_KEYS_SETTINGS,
    ), null);
  });
  it('a JSON-string object is accepted the same as a parsed object (import-path parity)', () => {
    assert.equal(validatePlacementLayoutWrite(JSON.stringify({ dense_columns: 2 })), null);
  });
  it('malformed JSON string is rejected', () => {
    assert.notEqual(validatePlacementLayoutWrite('{not json'), null);
  });
  it('an unknown key rejects the WHOLE write, naming the offending key', () => {
    assert.match(validatePlacementLayoutWrite({ bogus_key: 1 }), /bogus_key/);
  });
  it('an out-of-bounds value inside an otherwise-valid object rejects the whole write', () => {
    assert.match(
      validatePlacementLayoutWrite({ dense_columns: 3, dense_hosts_per_column: 999 }),
      /dense_hosts_per_column/,
    );
  });
  it('a non-object (array/number) is rejected', () => {
    assert.notEqual(validatePlacementLayoutWrite(['x']), null);
    assert.notEqual(validatePlacementLayoutWrite(42), null);
  });

  describe('Q16 — the per-DC site tier only allows dense_columns/dense_hosts_per_column', () => {
    it('dense_threshold is REJECTED at the site tier — scenario-wide only, never per-DC', () => {
      assert.match(
        validatePlacementLayoutWrite({ dense_threshold: 25 }, PLACEMENT_LAYOUT_KEYS_SITE),
        /dense_threshold.*not allowed/,
      );
    });
    it('dense_columns / dense_hosts_per_column are accepted at the site tier', () => {
      assert.equal(validatePlacementLayoutWrite({ dense_columns: 2 }, PLACEMENT_LAYOUT_KEYS_SITE), null);
      assert.equal(validatePlacementLayoutWrite({ dense_hosts_per_column: 8 }, PLACEMENT_LAYOUT_KEYS_SITE), null);
    });
    it('a site-tier write naming dense_threshold ALONGSIDE valid keys still rejects the whole write', () => {
      assert.notEqual(
        validatePlacementLayoutWrite({ dense_columns: 2, dense_threshold: 25 }, PLACEMENT_LAYOUT_KEYS_SITE),
        null,
      );
    });
    it('fmb-1913: dense_fill_strategy/dense_flow are accepted at the site tier too', () => {
      assert.equal(validatePlacementLayoutWrite({ dense_fill_strategy: 'fill' }, PLACEMENT_LAYOUT_KEYS_SITE), null);
      assert.equal(validatePlacementLayoutWrite({ dense_flow: 'horizontal' }, PLACEMENT_LAYOUT_KEYS_SITE), null);
    });
  });
});
