/**
 * blueprint-fields-put-table-column-compute-rule.test.js (fmb-1942) —
 * PUT /blueprint_fields/:id must judge table_config.columns[].rules.
 * compute_rule on every write that persists table_config, whether or not the
 * SAME request also authors the field's own compute_rule — a table_config-
 * only edit (no compute_rule key in the body at all) must be judged exactly
 * the same as one that touches both.
 *
 * Scaffolding mirrors blueprint-fields-put-poststate-rules.test.js's
 * makeConn (same route, same query shapes); trimmed to what this suite's
 * fixtures actually exercise.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../src/edge/db');

const DATABASE_PROBE = /^SELECT DATABASE\(\)/i;
const COLUMN_PROBE = /SELECT COLUMN_NAME FROM information_schema\.COLUMNS/i;
const COMPUTE_STATE = /SELECT field_key, field_type, table_config, compute_rule FROM `fmb_blueprint_fields`/i;
const FIELD_SCOPES = /SELECT field_key, value_scope FROM `fmb_blueprint_fields`/i;
const FIELD_UPDATE = /^UPDATE `fmb_blueprint_fields` SET/i;

const BF_COLUMNS = [
  'id', 'blueprint_id', 'field_type', 'field_key', 'field_label',
  'table_config', 'depends_on_field_key', 'value_source', 'value_scope', 'compute_rule',
];

const sameCol = (columnKey) => ({
  op: 'concat',
  overridable: true,
  output_type: 'string',
  config: { parts: [{ type: 'same_table_column', column_key: columnKey }] },
});

let conn;
let dbSeq = 0;

function applySets(row, sql, params) {
  const set = /SET\s+([\s\S]*?)\s+WHERE\s/i.exec(sql);
  if (!set) return row;
  const next = { ...row };
  let i = 0;
  for (const clause of set[1].split(',')) {
    const m = /^\s*`?([a-z_]+)`?\s*=\s*(\?|NULL)\s*$/i.exec(clause);
    if (!m) continue;
    next[m[1]] = m[2] === '?' ? params[i += 1, i - 1] : null;
  }
  return next;
}

function makeConn({ oldRow, preRows, postRows, columns = BF_COLUMNS }) {
  const dbName = `db_${dbSeq += 1}`;
  const queries = [];
  let committed = false;
  let rolledBack = false;
  let written = false;
  let row = Object.fromEntries(Object.entries(
    { value_source: 'entered', value_scope: null, compute_rule: null, ...oldRow },
  ).filter(([k]) => !['value_source', 'value_scope', 'compute_rule'].includes(k)
    || columns.includes(k)));
  return {
    queries,
    committed: () => committed,
    rolledBack: () => rolledBack,
    storedRow: () => row,
    async beginTransaction() {},
    async commit() { committed = true; },
    async rollback() { rolledBack = true; },
    async query(sql, params) {
      queries.push({ sql, params });
      if (DATABASE_PROBE.test(sql)) return [{ db: dbName }];
      if (COLUMN_PROBE.test(sql)) {
        const table = Array.isArray(params) ? params[0] : undefined;
        if (table === 'fmb_field_options') {
          return ['id', 'field_id', 'option_value', 'valid_parent_values'].map((c) => ({ COLUMN_NAME: c }));
        }
        if (table === 'fmb_variant_overrides') {
          return ['id', 'variant_id', 'field_id', 'action', 'cell_targets'].map((c) => ({ COLUMN_NAME: c }));
        }
        return columns.map((c) => ({ COLUMN_NAME: c }));
      }
      if (/SELECT id, blueprint_id, field_type/.test(sql)) return [oldRow];
      if (COMPUTE_STATE.test(sql)) return written ? postRows : preRows;
      if (FIELD_SCOPES.test(sql)) return [];
      if (/SELECT vo\.variant_id, bf\.field_key, vo\.compute_rule/i.test(sql)) return [];
      if (/SELECT vo\.variant_id, bf\.field_key, vo\.cell_targets/i.test(sql)) return [];
      if (/^UPDATE `fmb_blueprint_fields`[\s\S]*BINARY \?/i.test(sql)) return { affectedRows: 0 };
      if (FIELD_UPDATE.test(sql.trim())) {
        written = true;
        row = applySets(row, sql, params);
        return { affectedRows: 1 };
      }
      if (/^UPDATE `fmb_variant_overrides`/i.test(sql)) return { affectedRows: 0 };
      if (/^DELETE FROM `fmb_field_options`/i.test(sql)) return { affectedRows: 0 };
      if (/^INSERT INTO `fmb_feature_audit`/i.test(sql)) return { affectedRows: 1 };
      if (/^SELECT \* FROM `fmb_blueprint_fields`/i.test(sql)) return [row];
      if (/SELECT linked_blueprint_id FROM/.test(sql)) return [];
      if (/ AS bid FROM/.test(sql) || / AS fk FROM/.test(sql)) return [];
      if (/CHARACTER_SET_NAME AS cs/.test(sql)) return [{ cs: 'utf8mb4', co: 'utf8mb4_general_ci' }];
      if (/<=>/.test(sql) && / AS same/.test(sql)) {
        const fold = (v) => String(v).toLowerCase().replace(/\s+$/, '');
        return [{ same: fold((params || [])[0]) === fold((params || [])[1]) ? 1 : 0 }];
      }
      if (/FROM `fmb_blueprint_fields`/i.test(sql) && /`?field_key`? = \?/i.test(sql)
          && /LIMIT 1/i.test(sql)) {
        return [];
      }
      throw new Error(`Unmatched query in test: ${sql.slice(0, 110)}`);
    },
    release() {},
  };
}

const poolSpy = {
  rw: { async getConnection() { return conn; } },
  ro: { async getConnection() { throw new Error('test error: PUT should use pool.rw'); } },
};

require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: poolSpy, t: (name) => `fmb_${name}`, getDynamicPool: async () => poolSpy },
};

const router = require('../../src/edge/routes/app/schema');

let server;
let port;

before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { req.user = { id: 'admin-1', role: 'admin' }; next(); });
  app.use('/edge/app/schema', router);
  await new Promise((resolve) => {
    server = app.listen(0, '127.0.0.1', () => { port = server.address().port; resolve(); });
  });
});

after(async () => {
  await new Promise((resolve) => server.close(resolve));
  delete require.cache[dbKey];
});

beforeEach(() => { conn = null; });

function put(path, body) {
  return new Promise((resolve, reject) => {
    const data = JSON.stringify(body);
    const r = http.request({
      method: 'PUT', host: '127.0.0.1', port, path,
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(data) },
    }, (res) => {
      let raw = '';
      res.on('data', (c) => { raw += c; });
      res.on('end', () => resolve({ status: res.statusCode, body: raw ? JSON.parse(raw) : null }));
    });
    r.on('error', reject);
    r.write(data);
    r.end();
  });
}

const ITEMS = {
  id: 'f-items', blueprint_id: 'bp-1', field_type: 'table', field_key: 'items',
  depends_on_field_key: null,
};

describe('PUT /blueprint_fields/:id — table_config column-level compute_rule (fmb-1942)', () => {
  it('accepts a valid column rule with NO field-level compute_rule in the body at all', async () => {
    conn = makeConn({
      oldRow: ITEMS,
      preRows: [{ field_key: 'items', field_type: 'table', table_config: null, compute_rule: null }],
      postRows: [{
        field_key: 'items', field_type: 'table',
        table_config: JSON.stringify({ columns: [{ key: 'part' }, { key: 'label' }] }), compute_rule: null,
      }],
    });
    const res = await put('/edge/app/schema/blueprint_fields/f-items', {
      table_config: {
        columns: [{ key: 'part' }, { key: 'label', rules: { compute_rule: sameCol('part') } }],
      },
    });
    assert.equal(res.status, 200, JSON.stringify(res.body));
    assert.equal(conn.committed(), true);
  });

  it('rejects a self-referencing column rule with 400, naming the column key', async () => {
    conn = makeConn({
      oldRow: ITEMS,
      preRows: [{ field_key: 'items', field_type: 'table', table_config: null, compute_rule: null }],
      postRows: [{ field_key: 'items', field_type: 'table', table_config: null, compute_rule: null }],
    });
    const res = await put('/edge/app/schema/blueprint_fields/f-items', {
      table_config: {
        columns: [{ key: 'part' }, { key: 'label', rules: { compute_rule: sameCol('label') } }],
      },
    });
    assert.equal(res.status, 400, JSON.stringify(res.body));
    assert.equal(res.body.error.code, 'same_table_column_cycle');
    assert.match(res.body.error.message, /label/, "the refusal must name the column key ('label')");
    assert.equal(conn.rolledBack(), true);
  });

  it('rejects a column rule naming a non-existent sibling column', async () => {
    conn = makeConn({
      oldRow: ITEMS,
      preRows: [{ field_key: 'items', field_type: 'table', table_config: null, compute_rule: null }],
      postRows: [{ field_key: 'items', field_type: 'table', table_config: null, compute_rule: null }],
    });
    const res = await put('/edge/app/schema/blueprint_fields/f-items', {
      table_config: {
        columns: [{ key: 'part' }, { key: 'label', rules: { compute_rule: sameCol('ghost') } }],
      },
    });
    assert.equal(res.status, 400, JSON.stringify(res.body));
    assert.equal(res.body.error.code, 'bad_same_table_column');
    assert.equal(conn.rolledBack(), true);
  });
});
