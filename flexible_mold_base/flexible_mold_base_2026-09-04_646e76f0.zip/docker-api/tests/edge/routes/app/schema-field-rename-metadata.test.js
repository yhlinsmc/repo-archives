/**
 * schema-field-rename-metadata.test.js — POST /rename/:fieldId must move the
 * renamed field key in EVERY document that is indexed by it, not just `payload`.
 *
 * Stub-connection tests (no live DB), so every assertion targets the SQL and the
 * BOUND JSON PATHS the route actually issues: a mocked UPDATE reports rows
 * migrated whether or not the statement named the column it claims to have
 * moved, which is precisely how the three metadata columns went unmoved for
 * three releases. The paths matter as much as the column names — field keys sit
 * at the root of two documents and one level down, under a channel, in the
 * third; a statement built for the wrong depth matches nothing and reports
 * success.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');
const { answerCollationProbe } = require('../../../helpers/collation-probe');

const dbKey = require.resolve('../../../../src/edge/db');
const {
  USER_TEMPLATE_METADATA_COLUMN_NAMES,
  userTemplateMetadataKeySites,
} = require('../../../../src/edge/lib/user-template-metadata');

const DATABASE_PROBE = /^SELECT DATABASE\(\)/i;
const COLUMN_PROBE = /SELECT COLUMN_NAME FROM information_schema\.COLUMNS/i;
const FIELD_LOOKUP = /^SELECT blueprint_id, field_key FROM `fmb_blueprint_fields`/i;
const OWNER_LOOKUP = /^SELECT owner_id FROM `fmb_hierarchy_nodes`/i;
const LINKERS_LOOKUP = /^SELECT id FROM `fmb_hierarchy_nodes`\s+WHERE id = \? OR linked_blueprint_id = \?( FOR UPDATE)?/i;

const BASE_TEMPLATE_COLS = [
  'id', 'name', 'blueprint_id', 'payload', 'generated_outputs', 'created_at', 'updated_at',
];

let targetColumns;
let conn;
let failingColumn;
// The blueprint the renamed field belongs to, as the ownership check sees it.
// `[]` = no such blueprint row.
let blueprintOwnerRows;
let currentUser;

function makeConn() {
  const queries = [];
  const tx = [];
  return {
    queries,
    tx,
    async query(sql, params) {
      if (DATABASE_PROBE.test(sql)) return [{ db: 'db_default' }];
      if (COLUMN_PROBE.test(sql)) return targetColumns.map((c) => ({ COLUMN_NAME: c }));
      // The owner check asks the COLUMN whether the blueprint is the caller's,
      // so the double answers as the column would (tests/helpers/collation-probe.js).
      // After this file's own two probes, which project different columns and
      // must keep their own answers. Kept out of `queries` because every
      // assertion here is about the STATEMENTS the rename issues.
      const probed = answerCollationProbe(sql, params);
      if (probed !== undefined) return probed;
      queries.push({ sql, params });
      if (FIELD_LOOKUP.test(sql)) return [{ blueprint_id: 'bp-1', field_key: 'old_key' }];
      if (OWNER_LOOKUP.test(sql)) return blueprintOwnerRows;
      // No other blueprint links to 'bp-1' in this fixture — the linked-scope
      // case is covered separately by schema-field-rename-follows-links.test.js.
      if (LINKERS_LOOKUP.test(sql)) return [];
      if (/^UPDATE `fmb_user_templates`/i.test(sql)) {
        if (failingColumn && sql.includes(`\`${failingColumn}\``)) {
          throw Object.assign(new Error('Unknown column'), { errno: 1054 });
        }
        return { affectedRows: sql.includes('`payload`') ? 3 : 1 };
      }
      // The (blueprint, key) clash probe both write paths now run before they can
      // create the duplicate the migration endpoint would turn into a merge.
      // Nothing collides in these fixtures; the case that does is settled on a
      // real database (tests/integration/blueprint-field-write-real-db.test.js).
      if (/FROM `fmb_blueprint_fields`/i.test(sql) && /`?field_key`? = \?/i.test(sql)
          && /LIMIT 1/i.test(sql)) {
        return [];
      }
      throw new Error(`Unmatched query: ${sql.slice(0, 160)}`);
    },
    release() { /* noop */ },
    async beginTransaction() { tx.push('begin'); },
    async commit() { tx.push('commit'); },
    async rollback() { tx.push('rollback'); },
  };
}

const poolSpy = {
  rw: { async getConnection() { return conn; } },
  ro: { async getConnection() { return conn; } },
};

require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: {
    pool: poolSpy,
    t: (name) => `fmb_${name}`,
    getDynamicPool: async () => poolSpy,
  },
};

const router = require('../../../../src/edge/routes/app/schema');
const { __clearColumnSetCache } = router.__test__;

let server;
let port;

before(async () => {
  const app = express();
  app.use(express.json({ limit: '10mb' }));
  app.use((req, _res, next) => { req.user = currentUser; next(); });
  app.use('/edge/app/schema', router);
  await new Promise((resolve) => {
    server = app.listen(0, '127.0.0.1', () => { port = server.address().port; resolve(); });
  });
});

after(async () => {
  await new Promise((resolve) => server.close(resolve));
  delete require.cache[dbKey];
});

beforeEach(() => {
  targetColumns = [...BASE_TEMPLATE_COLS, ...USER_TEMPLATE_METADATA_COLUMN_NAMES];
  failingColumn = null;
  blueprintOwnerRows = [{ owner_id: 'someone-else' }];
  currentUser = { id: 'admin-1', role: 'admin' };
  conn = makeConn();
  __clearColumnSetCache();
});

function postJson(path_, body) {
  return new Promise((resolve, reject) => {
    const payload = JSON.stringify(body);
    const req = http.request(
      {
        host: '127.0.0.1', port, path: path_, method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) },
      },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          const raw = Buffer.concat(chunks).toString('utf-8');
          let json = null;
          try { json = JSON.parse(raw); } catch { /* noop */ }
          resolve({ status: res.statusCode, raw, json });
        });
      },
    );
    req.on('error', reject);
    req.write(payload);
    req.end();
  });
}

const rename = () => postJson('/edge/app/schema/rename/fld-1', { old_key: 'old_key', new_key: 'new_key' });

const templateUpdates = () => conn.queries.filter((q) => /^UPDATE `fmb_user_templates`/i.test(q.sql));

describe('field rename — every field-key-indexed document', () => {
  it('moves the key in payload and in all three metadata columns', async () => {
    const res = await rename();
    assert.equal(res.status, 200, res.raw);

    const updates = templateUpdates();
    // payload plus one statement per declared key site.
    assert.equal(updates.length, 1 + userTemplateMetadataKeySites().length);

    for (const column of ['payload', ...USER_TEMPLATE_METADATA_COLUMN_NAMES]) {
      assert.ok(
        updates.some((u) => u.sql.includes(`\`${column}\` = JSON_SET(`)),
        `no UPDATE moves the key inside ${column}`,
      );
    }
  });

  it('addresses each site at the depth its field keys actually sit', async () => {
    await rename();
    const paths = templateUpdates().map((u) => ({ sql: u.sql, params: u.params }));

    const pathsFor = (column) => paths
      .filter((p) => p.sql.includes(`\`${column}\` = JSON_SET(`))
      .map((p) => p.params[0]);

    assert.deepEqual(pathsFor('payload'), ['$."old_key"']);
    assert.deepEqual(pathsFor('field_option_selection'), ['$."old_key"']);
    assert.deepEqual(pathsFor('computed_field_overrides'), ['$."old_key"']);
    // Both channels, or the half that is not covered silently keeps a marker
    // pointing at a key nothing will ever ask for again.
    assert.deepEqual(
      pathsFor('cleared_auto_fills').sort(),
      ['$."decision"."old_key"', '$."single_option"."old_key"'],
    );
  });

  it('binds the new key and the blueprint scope on every statement', async () => {
    await rename();
    for (const update of templateUpdates()) {
      const [removePath, setPath, extractPath, blueprintId, wherePath] = update.params;
      assert.equal(setPath, removePath.replace('old_key', 'new_key'));
      assert.equal(extractPath, removePath);
      assert.equal(wherePath, removePath);
      assert.equal(blueprintId, 'bp-1');
      // The guard that keeps the statement a no-op on a row whose document has
      // no such key: without it JSON_EXTRACT returns NULL and JSON_SET writes a
      // null-valued new key into every row of the blueprint.
      assert.match(update.sql, /AND JSON_EXTRACT\(`[a-z_]+`, \?\) IS NOT NULL/);
    }
  });

  it('reports migrated_count from the payload statement, as it always has', async () => {
    const res = await rename();
    assert.equal(res.json.data.migrated_count, 3);
  });

  it('commits the whole rename as one transaction', async () => {
    await rename();
    assert.deepEqual(conn.tx, ['begin', 'commit']);
  });

  it('rolls back and 500s when one document cannot be migrated', async () => {
    failingColumn = 'cleared_auto_fills';
    const res = await rename();
    assert.equal(res.status, 500);
    assert.deepEqual(conn.tx, ['begin', 'rollback']);
  });

  it('skips a metadata column the target DB does not have, without failing', async () => {
    targetColumns = BASE_TEMPLATE_COLS;
    const res = await rename();
    assert.equal(res.status, 200, res.raw);

    const updates = templateUpdates();
    assert.equal(updates.length, 1);
    assert.ok(updates[0].sql.includes('`payload`'));
    assert.equal(res.json.data.migrated_count, 3);
  });

  it('leaves the metadata columns alone when the key format is refused', async () => {
    const res = await postJson('/edge/app/schema/rename/fld-1', { old_key: 'old_key', new_key: 'New Key' });
    assert.equal(res.status, 400);
    assert.equal(templateUpdates().length, 0);
  });
});

describe('field rename — who may rewrite a blueprint\'s records', () => {
  // The endpoint gates on role alone, and its own comment calls the ownership
  // check "implicit because the rename drives a PUT that verifies it" — an
  // assumption about the caller's sequencing, not something this route enforces.
  // Nothing stops an editor naming a fieldId under a blueprint they do not own,
  // and this PR widened what that rewrites from one document to four.
  it('refuses an editor who does not own the blueprint, touching nothing', async () => {
    currentUser = { id: 'editor-1', role: 'editor' };
    blueprintOwnerRows = [{ owner_id: 'someone-else' }];

    const res = await rename();
    assert.equal(res.status, 403, res.raw);
    assert.equal(res.json.error.code, 'FORBIDDEN');
    assert.deepEqual(templateUpdates(), []);
    assert.deepEqual(conn.tx, ['begin', 'rollback']);
  });

  it('refuses an editor when the blueprint row is gone', async () => {
    currentUser = { id: 'editor-1', role: 'editor' };
    blueprintOwnerRows = [];

    const res = await rename();
    assert.equal(res.status, 403, res.raw);
    assert.deepEqual(templateUpdates(), []);
  });

  it('allows the editor who owns the blueprint', async () => {
    currentUser = { id: 'editor-1', role: 'editor' };
    blueprintOwnerRows = [{ owner_id: 'editor-1' }];

    const res = await rename();
    assert.equal(res.status, 200, res.raw);
    assert.equal(templateUpdates().length, 1 + userTemplateMetadataKeySites().length);
  });

  it('allows an editor on a shared blueprint', async () => {
    currentUser = { id: 'editor-1', role: 'editor' };
    blueprintOwnerRows = [{ owner_id: null }];

    const res = await rename();
    assert.equal(res.status, 200, res.raw);
    assert.equal(templateUpdates().length, 1 + userTemplateMetadataKeySites().length);
  });

  it('does not lock out an admin on a blueprint owned by someone else', async () => {
    currentUser = { id: 'admin-1', role: 'admin' };
    blueprintOwnerRows = [{ owner_id: 'someone-else' }];

    const res = await rename();
    assert.equal(res.status, 200, res.raw);
    assert.equal(templateUpdates().length, 1 + userTemplateMetadataKeySites().length);
  });
});
