'use strict';

/**
 * blueprint-grant-matrix.test.js — the cross-owner deny/allow matrix (spec §6.7)
 * run against the REAL schema. For a blueprint owned by user A:
 *   - editor grantee B WITH a blueprint grant: blueprint_fields PUT, variant
 *     override POST + PUT, connector-binding PUT, AND variant_overrides DELETE
 *     (the factory path, §6.4a) → all 200.
 *   - editor B with NO grant: all of the above → 403/404 (the deny premise is
 *     asserted FIRST, so a matrix that passes because everything is allowed is
 *     caught — feedback_destructive_verify_premise_first).
 *   - plain-user B with a grant: still refused by the route role gate
 *     (requireAdminOrEditor, spec §6.4 D-3).
 *   - grantee B attempts delete-blueprint / transfer-ownership: refused
 *     (owner/admin only, spec §6.2).
 *   - admin: 200 everywhere.
 *
 * A mocked driver cannot evaluate the grant EXISTS, so the tables are built from
 * the real DDL and the shipped routes run the shipped statements. Skips with a
 * stated reason when no database is reachable, and FAILS instead of skipping
 * when REQUIRE_INTEGRATION_DB=1 — a silent skip is the failure mode this line of
 * work exists to end.
 */
const { test, describe, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const net = require('node:net');
const http = require('node:http');
const express = require('express');
const mariadb = require('mariadb');

const TEST_PREFIX = 'bgm_';
const tbl = (name) => `${TEST_PREFIX}${name}`;

let pool = null;
const lease = () => pool.getConnection();

const dbKey = require.resolve('../../../../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey,
  filename: dbKey,
  loaded: true,
  exports: {
    pool: { ro: { getConnection: lease }, rw: { getConnection: lease } },
    t: tbl,
    getDynamicPool: async () => ({ ro: { getConnection: lease }, rw: { getConnection: lease } }),
  },
};

const { buildEngineTableDDLs, buildInfraTableDDLs } = require('../../../../../src/table-ddls');
const schemaRouter = require('../../../../../src/edge/routes/app/schema');
const connectorsRouter = require('../../../../../src/edge/routes/app/api-connectors');
const { _resetGrantsTableCache } = require('../../../../../src/edge/lib/delegated-grants');

// ── Config auto-detection (same shape as the sibling integration tests) ──────
function parseEnvFile(filePath) {
  try {
    const out = {};
    for (const line of fs.readFileSync(filePath, 'utf-8').split('\n')) {
      const m = line.match(/^\s*([A-Z_][A-Z0-9_]*)\s*=\s*(.*)\s*$/);
      if (!m) continue;
      let value = m[2];
      if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) {
        value = value.slice(1, -1);
      }
      out[m[1]] = value;
    }
    return out;
  } catch { return null; }
}
function probePort(host, port, timeoutMs = 2000) {
  return new Promise((resolve) => {
    const socket = new net.Socket();
    let done = false;
    const finish = (ok) => { if (done) return; done = true; socket.destroy(); resolve(ok); };
    socket.setTimeout(timeoutMs);
    socket.once('connect', () => finish(true));
    socket.once('timeout', () => finish(false));
    socket.once('error', () => finish(false));
    socket.connect(port, host);
  });
}
async function resolveMariaDbConfig() {
  if (process.env.DB_TEST_HOST && process.env.DB_TEST_ROOT_PASSWORD) {
    return {
      host: process.env.DB_TEST_HOST,
      port: parseInt(process.env.DB_TEST_PORT || '3306', 10),
      user: 'root', password: process.env.DB_TEST_ROOT_PASSWORD,
    };
  }
  const env = parseEnvFile(path.resolve(__dirname, '../../../../../../.devcontainer/.env'));
  if (!env || !env.DB_ROOT_PASSWORD) return null;
  const port = parseInt(env.DB_PORT || '3306', 10);
  for (const host of ['127.0.0.1', 'mariadb', 'localhost']) {
    if (await probePort(host, port, 2000)) return { host, port, user: 'root', password: env.DB_ROOT_PASSWORD };
  }
  return null;
}

// ── Fixture ids ──────────────────────────────────────────────────────────────
const A = { id: 'aaaaaaaa-1111-4222-8333-000000000001', role: 'editor' };   // subject owner
const B = { id: 'bbbbbbbb-1111-4222-8333-000000000002', role: 'editor' };   // grantee
const ADMIN = { id: 'dddddddd-1111-4222-8333-000000000004', role: 'admin' };
const BP_A = 'a0b0c0d0-1111-4222-8333-0000000000a1';   // owned by A — the grant subject
const BP_B = 'a0b0c0d0-1111-4222-8333-0000000000b1';   // owned by B — connector home
const VARIANT = 'a0b0c0d0-1111-4222-8333-0000000000v1'; // variant under BP_A
const FIELD_PUT = 'f0000000-1111-4222-8333-0000000000f1'; // field under BP_A (PUT/override)
const FIELD_POST = 'f0000000-1111-4222-8333-0000000000f2'; // field under BP_A (POST override)
const OVERRIDE = 'ce000000-1111-4222-8333-0000000000e1'; // override on (VARIANT, FIELD_PUT)
const CONNECTOR = 'c0000000-1111-4222-8333-0000000000c1'; // owned by B, home BP_B
// R-4-8: CONNECTOR's home (BP_B) is owned by B outright, so it can never
// exercise the home-blueprint arm reached only through a grant — B already
// owns that blueprint before any grant exists. These two connectors have
// their HOME on BP_A, which only A owns, so the grant on BP_A is the only
// route to the home-blueprint check for them.
const CONNECTOR_HOME_VIA_GRANT = 'c0000000-1111-4222-8333-0000000000c2'; // owned by B, home BP_A
const CONNECTOR_NOT_OWNED_BY_B = 'c0000000-1111-4222-8333-0000000000c3'; // owned by A, home BP_A

let dbReady = false;
let skipReason = null;
let testDbName = null;
let server = null;
let baseUrl = null;
let currentUser = ADMIN;

before(async () => {
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) {
    skipReason = 'no MariaDB reachable via .devcontainer/.env or env vars';
    if (process.env.REQUIRE_INTEGRATION_DB === '1') throw new Error(`REQUIRE_INTEGRATION_DB=1 set but ${skipReason}.`);
    return;
  }
  testDbName = `bgm_test_${process.pid}_${Date.now()}`;
  let admin = null;
  try {
    admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`CREATE DATABASE \`${testDbName}\``);
    await admin.query(`USE \`${testDbName}\``);
    for (const sql of [...buildInfraTableDDLs(tbl), ...buildEngineTableDDLs(tbl)]) await admin.query(sql);
    await admin.end();
    admin = null;
    pool = mariadb.createPool({ ...dbConfig, database: testDbName, connectionLimit: 6, connectTimeout: 5000 });
    const app = express();
    app.use(express.json());
    app.use((req, _res, next) => { req.user = currentUser; next(); });
    app.use('/edge/app/schema', schemaRouter);
    app.use('/edge/app/api-connectors', connectorsRouter);
    server = http.createServer(app);
    await new Promise((r) => server.listen(0, r));
    baseUrl = `http://127.0.0.1:${server.address().port}`;
    dbReady = true;
  } catch (err) {
    skipReason = `setup failed: ${err.message}`;
    if (admin) { try { await admin.end(); } catch { /* best effort */ } }
    if (process.env.REQUIRE_INTEGRATION_DB === '1') throw err;
  }
});

after(async () => {
  if (server) { try { server.close(); } catch { /* best effort */ } }
  if (pool) { try { await pool.end(); } catch { /* best effort */ } }
  if (!testDbName) return;
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) return;
  try {
    const admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`DROP DATABASE IF EXISTS \`${testDbName}\``);
    await admin.end();
  } catch { /* best effort */ }
});

async function call(user, method, url, body) {
  currentUser = user;
  const res = await fetch(`${baseUrl}${url}`, {
    method,
    headers: { 'content-type': 'application/json' },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const text = await res.text();
  let parsed = null;
  try { parsed = JSON.parse(text); } catch { parsed = { raw: text }; }
  return { status: res.status, body: parsed };
}

const guard = (t) => {
  if (!dbReady) { t.skip(skipReason || 'database not ready'); return true; }
  return false;
};

const q = (sql, params) => pool.query(sql, params);
const overrideCount = async (id = OVERRIDE) =>
  Number((await q(`SELECT COUNT(*) AS n FROM \`${tbl('variant_overrides')}\` WHERE id = ?`, [id]))[0].n);
const bindingCount = async (connectorId = CONNECTOR) =>
  Number((await q(`SELECT COUNT(*) AS n FROM \`${tbl('api_connector_blueprints')}\` WHERE connector_id = ?`, [connectorId]))[0].n);

async function grantB() {
  await q(
    `INSERT INTO \`${tbl('delegated_grants')}\` (id, scope_type, scope_id, grantee_id, granted_by)
     VALUES (UUID(), 'blueprint', ?, ?, ?)`,
    [BP_A, B.id, A.id],
  );
}

/** Rebuild the whole fixture with NO grant present, before each case. */
beforeEach(async () => {
  if (!dbReady) return;
  _resetGrantsTableCache();
  for (const name of ['delegated_grants', 'api_connector_blueprints', 'api_connectors',
    'variant_overrides', 'blueprint_fields', 'hierarchy_nodes', 'users']) {
    await q(`DELETE FROM \`${tbl(name)}\``);
  }
  // Real user rows: the owner-transfer route resolves new_owner_id against the
  // users table (resolveCanonicalUserId), so the admin-transfer case needs B to
  // exist as a user.
  for (const [uid, role] of [[A.id, 'editor'], [B.id, 'editor']]) {
    await q(`INSERT INTO \`${tbl('users')}\` (id, email, role) VALUES (?, ?, ?)`, [uid, `${uid}@t.local`, role]);
  }
  // Blueprints: BP_A owned by A (grant subject), BP_B owned by B (connector home).
  await q(`INSERT INTO \`${tbl('hierarchy_nodes')}\` (id, name, node_type, owner_id) VALUES (?, 'bp-A', 'blueprint', ?)`, [BP_A, A.id]);
  await q(`INSERT INTO \`${tbl('hierarchy_nodes')}\` (id, name, node_type, owner_id) VALUES (?, 'bp-B', 'blueprint', ?)`, [BP_B, B.id]);
  // Variant under BP_A.
  await q(`INSERT INTO \`${tbl('hierarchy_nodes')}\` (id, name, node_type, parent_id, owner_id) VALUES (?, 'var', 'variant', ?, ?)`, [VARIANT, BP_A, A.id]);
  // Two fields under BP_A: one carries an existing override (PUT/DELETE), one free (POST).
  for (const [fid, key] of [[FIELD_PUT, 'city'], [FIELD_POST, 'zone']]) {
    await q(`INSERT INTO \`${tbl('blueprint_fields')}\` (id, blueprint_id, field_key, field_label, field_type) VALUES (?, ?, ?, ?, 'text')`, [fid, BP_A, key, key]);
  }
  await q(`INSERT INTO \`${tbl('variant_overrides')}\` (id, variant_id, field_id, action) VALUES (?, ?, ?, 'lock')`, [OVERRIDE, VARIANT, FIELD_PUT]);
  // Connector owned by B, home BP_B (so B manages it; the binding target is BP_A).
  await q(`INSERT INTO \`${tbl('api_connectors')}\` (id, name, url, owner_id, blueprint_id) VALUES (?, 'c', '', ?, ?)`, [CONNECTOR, B.id, BP_B]);
  // R-4-8: home BP_A, owned by A — B can reach it only through a grant.
  await q(`INSERT INTO \`${tbl('api_connectors')}\` (id, name, url, owner_id, blueprint_id) VALUES (?, 'c2', '', ?, ?)`, [CONNECTOR_HOME_VIA_GRANT, B.id, BP_A]);
  await q(`INSERT INTO \`${tbl('api_connectors')}\` (id, name, url, owner_id, blueprint_id) VALUES (?, 'c3', '', ?, ?)`, [CONNECTOR_NOT_OWNED_BY_B, A.id, BP_A]);
});

// helpers per surface
const putField = (user) => call(user, 'PUT', `/edge/app/schema/blueprint_fields/${FIELD_PUT}`, { field_label: `L${Date.now()}` });
const postOverride = (user) => call(user, 'POST', '/edge/app/schema/variant_overrides', { variant_id: VARIANT, field_id: FIELD_POST, action: 'lock' });
const putOverride = (user) => call(user, 'PUT', `/edge/app/schema/variant_overrides/${OVERRIDE}`, { action: 'lock' });
// FK-change PUT: repoints the OVERRIDE row from FIELD_PUT to FIELD_POST,
// both under BP_A — exercises the dual-EXISTS branch (old-row anti-hijack +
// new-pair post-state), each carrying its own grant arm (fmb-1976 PR-3 G-3B-5).
const putOverrideFkChange = (user) => call(user, 'PUT', `/edge/app/schema/variant_overrides/${OVERRIDE}`, { field_id: FIELD_POST, action: 'lock' });
const delOverride = (user) => call(user, 'DELETE', `/edge/app/schema/variant_overrides/${OVERRIDE}`);
const putBinding = (user) => call(user, 'PUT', `/edge/app/api-connectors/${CONNECTOR}/bindings`, { blueprint_ids: [BP_A] });
// R-4-8: BP_B is B's own blueprint, so targeting it exercises ONLY the home-
// blueprint arm (the connector's home is BP_A) — the target-side authority
// (assertBindingTargets) is already grant-aware and not what these pin.
const putBindingHomeViaGrant = (user) => call(user, 'PUT', `/edge/app/api-connectors/${CONNECTOR_HOME_VIA_GRANT}/bindings`, { blueprint_ids: [BP_B] });
const putBindingNotOwnedByB = (user) => call(user, 'PUT', `/edge/app/api-connectors/${CONNECTOR_NOT_OWNED_BY_B}/bindings`, { blueprint_ids: [BP_B] });
const delBlueprint = (user) => call(user, 'DELETE', `/edge/app/schema/hierarchy_nodes/${BP_A}`);
const transferBlueprint = (user) => call(user, 'PATCH', `/edge/app/schema/hierarchy_nodes/${BP_A}/owner`, { new_owner_id: B.id });

const denied = (s) => s === 403 || s === 404;

describe('blueprint-grant cross-owner matrix (spec §6.7)', () => {
  // ── Deny premise FIRST: editor B with NO grant is refused on every surface. ──
  test('editor B with NO grant: blueprint_fields PUT is denied', async (t) => {
    if (guard(t)) return;
    assert.ok(denied((await putField(B)).status));
  });
  test('editor B with NO grant: variant override POST is denied', async (t) => {
    if (guard(t)) return;
    assert.ok(denied((await postOverride(B)).status));
  });
  test('editor B with NO grant: variant override PUT is denied', async (t) => {
    if (guard(t)) return;
    assert.ok(denied((await putOverride(B)).status));
  });
  test('editor B with NO grant: variant_overrides DELETE is denied and the row survives', async (t) => {
    if (guard(t)) return;
    assert.ok(denied((await delOverride(B)).status));
    assert.equal(await overrideCount(), 1, 'the override row must still exist');
  });
  test('editor B with NO grant: connector-binding PUT is denied and no binding is written', async (t) => {
    if (guard(t)) return;
    assert.equal((await putBinding(B)).status, 403);
    assert.equal(await bindingCount(), 0);
  });

  // ── Allow: editor B WITH a grant is permitted on every §6.1 surface. ─────────
  test('editor B WITH a grant: blueprint_fields PUT → 200', async (t) => {
    if (guard(t)) return;
    await grantB();
    assert.equal((await putField(B)).status, 200);
  });
  test('editor B WITH a grant: variant override POST → 200', async (t) => {
    if (guard(t)) return;
    await grantB();
    assert.equal((await postOverride(B)).status, 200);
  });
  test('editor B WITH a grant: variant override PUT → 200', async (t) => {
    if (guard(t)) return;
    await grantB();
    assert.equal((await putOverride(B)).status, 200);
  });
  test('editor B WITH a grant: variant override PUT with a CHANGED field_id → 200 and the new FK is stored', async (t) => {
    if (guard(t)) return;
    await grantB();
    const res = await putOverrideFkChange(B);
    assert.equal(res.status, 200);
    const row = (await q(`SELECT field_id FROM \`${tbl('variant_overrides')}\` WHERE id = ?`, [OVERRIDE]))[0];
    assert.equal(row.field_id, FIELD_POST, 'the row must carry the NEW field_id after the FK-change PUT');
  });
  test('editor B WITH a grant: variant_overrides DELETE → 200 and the row is gone', async (t) => {
    if (guard(t)) return;
    await grantB();
    assert.equal((await delOverride(B)).status, 200);
    assert.equal(await overrideCount(), 0, 'the grantee DELETE must remove the row');
  });
  test('editor B WITH a grant: connector-binding PUT → 200 and the binding is written', async (t) => {
    if (guard(t)) return;
    await grantB();
    assert.equal((await putBinding(B)).status, 200);
    assert.equal(await bindingCount(), 1);
  });

  // ── R-4-8: the connector-binding PUT's home-blueprint arm, isolated from the
  //    already-grant-aware target-blueprint arm (assertBindingTargets). ────────
  test('R-4-8: editor B with NO grant, owning a connector whose home only A owns: denied with the home-blueprint message', async (t) => {
    if (guard(t)) return;
    const res = await putBindingHomeViaGrant(B);
    assert.equal(res.status, 403);
    assert.equal(res.body.error.message, 'You do not own the home blueprint of this connector.');
    assert.equal(await bindingCount(CONNECTOR_HOME_VIA_GRANT), 0);
  });
  test('R-4-8: editor B WITH a grant on the connector\'s home blueprint → 200 (grantee owns the connector)', async (t) => {
    if (guard(t)) return;
    await grantB();
    assert.equal((await putBindingHomeViaGrant(B)).status, 200);
    assert.equal(await bindingCount(CONNECTOR_HOME_VIA_GRANT), 1);
  });
  test('R-4-8: a grant on the home blueprint does not extend to connector ownership — a grantee who does not own the connector is still refused', async (t) => {
    if (guard(t)) return;
    await grantB();
    const res = await putBindingNotOwnedByB(B);
    assert.equal(res.status, 403);
    assert.equal(res.body.error.message, 'You do not own every connector in this bundle.');
    assert.equal(await bindingCount(CONNECTOR_NOT_OWNED_BY_B), 0);
  });

  // ── §6.2: a grant does NOT reach delete-blueprint or transfer-ownership. ─────
  test('grantee B may NOT delete the blueprint (owner/admin only)', async (t) => {
    if (guard(t)) return;
    await grantB();
    assert.ok(denied((await delBlueprint(B)).status));
    assert.equal(
      Number((await q(`SELECT COUNT(*) AS n FROM \`${tbl('hierarchy_nodes')}\` WHERE id = ?`, [BP_A]))[0].n),
      1, 'the blueprint must survive',
    );
  });
  test('grantee B may NOT transfer ownership (admin only)', async (t) => {
    if (guard(t)) return;
    await grantB();
    assert.ok(denied((await transferBlueprint(B)).status));
    assert.equal(
      (await q(`SELECT owner_id FROM \`${tbl('hierarchy_nodes')}\` WHERE id = ?`, [BP_A]))[0].owner_id,
      A.id, 'ownership must be unchanged',
    );
  });

  // ── §6.4 D-3: a grant is effective only for role ≥ editor. ───────────────────
  test('plain-user B WITH a grant is still refused by the route role gate', async (t) => {
    if (guard(t)) return;
    await grantB();
    const plainB = { id: B.id, role: 'user' };
    assert.equal((await putField(plainB)).status, 403);
    assert.equal((await postOverride(plainB)).status, 403);
    assert.equal((await delOverride(plainB)).status, 403);
    assert.equal((await putBindingHomeViaGrant(plainB)).status, 403);
    assert.equal(await overrideCount(), 1, 'the plain-user DELETE must not have removed the row');
    assert.equal(await bindingCount(CONNECTOR_HOME_VIA_GRANT), 0);
  });

  // ── Admin: 200 everywhere (unchanged). ───────────────────────────────────────
  test('admin: writes, delete and transfer all succeed', async (t) => {
    if (guard(t)) return;
    assert.equal((await putField(ADMIN)).status, 200);
    assert.equal((await postOverride(ADMIN)).status, 200);
    assert.equal((await putBinding(ADMIN)).status, 200);
    assert.equal((await delOverride(ADMIN)).status, 200);
    assert.equal(await overrideCount(), 0);
    assert.equal((await transferBlueprint(ADMIN)).status, 200);
  });
});
