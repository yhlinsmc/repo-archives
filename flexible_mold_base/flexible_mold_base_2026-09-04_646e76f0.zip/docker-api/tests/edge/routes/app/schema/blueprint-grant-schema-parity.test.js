'use strict';

/**
 * blueprint-grant-schema-parity.test.js — the columns the PR-3 blueprint-grant
 * SQL references, checked against the ACTUAL DDL without a live database. The
 * behaviour tests stub the driver, so a query naming a column that does not
 * exist stays green in both runners and only fails against a real database. The
 * new statements are:
 *   - callerHasBlueprintGrant   (lib/delegated-grants.js): delegated_grants
 *     {scope_type, scope_id, grantee_id} JOIN hierarchy_nodes {id, node_type}.
 *   - buildChainBlueprintGrantExistsForRow (schema/helpers.js): the DELETE arm —
 *     hierarchy_nodes {id, parent_id, node_type} JOIN delegated_grants
 *     {scope_type, scope_id, grantee_id}.
 * Every column below is asserted present in the DDL those statements will hit.
 */
const { describe, it, before } = require('node:test');
const assert = require('node:assert/strict');

const { buildEngineTableDDLs } = require('../../../../../src/table-ddls');
const { TABLES } = require('../../../../../src/shared/constants');

const SQL_TYPES = /^`?([a-z_]+)`?\s+(?:CHAR|VARCHAR|INT|DOUBLE|TIMESTAMP|JSON|TEXT|ENUM|BOOLEAN|TINYINT|BIGINT|DATETIME|DECIMAL|FLOAT|BLOB)\b/i;

let columnsByTable;
before(() => {
  columnsByTable = new Map();
  for (const ddl of buildEngineTableDDLs((n) => n)) {
    const m = ddl.match(/CREATE TABLE IF NOT EXISTS `([^`]+)`/);
    if (!m) continue;
    const cols = new Set();
    for (const rawLine of ddl.split('\n')) {
      const line = rawLine.trim();
      if (!line || line.startsWith('--') || line.startsWith('/*')) continue;
      const cm = line.match(SQL_TYPES);
      if (cm) cols.add(cm[1]);
    }
    columnsByTable.set(m[1], cols);
  }
});

describe('blueprint-grant SQL — every referenced column exists in the DDL', () => {
  it('hierarchy_nodes carries id, parent_id, node_type, owner_id', () => {
    const cols = columnsByTable.get(TABLES.HIERARCHY_NODES);
    assert.ok(cols, 'no DDL parsed for hierarchy_nodes');
    for (const c of ['id', 'parent_id', 'node_type', 'owner_id']) {
      assert.ok(cols.has(c), `hierarchy_nodes is missing ${c}`);
    }
  });

  it('delegated_grants carries the columns the grant EXISTS reads', () => {
    const cols = columnsByTable.get(TABLES.DELEGATED_GRANTS);
    assert.ok(cols, 'no DDL parsed for delegated_grants');
    for (const c of ['scope_type', 'scope_id', 'grantee_id', 'id']) {
      assert.ok(cols.has(c), `delegated_grants is missing ${c}`);
    }
  });
});
