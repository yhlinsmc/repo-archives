/**
 * source-candidates-schema-parity.test.js — validates every column
 * source-candidates.js's SQL references against the ACTUAL table DDL, without
 * a live DB (see capacity-delete-preview-schema-parity.test.js for the
 * pattern this mirrors).
 */
const { describe, it, before } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { buildEngineTableDDLs } = require('../../../../../src/table-ddls');

const SQL_TYPES = /^`?([a-z_]+)`?\s+(?:CHAR|VARCHAR|INT|DOUBLE|TIMESTAMP|JSON|TEXT|ENUM|BOOLEAN|TINYINT|BIGINT|DATETIME|DECIMAL|FLOAT|BLOB)\b/i;
let byTable;
before(() => {
  byTable = new Map();
  for (const ddl of buildEngineTableDDLs((n) => n)) {
    const m = ddl.match(/CREATE TABLE IF NOT EXISTS `([^`]+)`/);
    if (!m) continue;
    const cols = new Set();
    for (const raw of ddl.split('\n')) { const l = raw.trim(); const cm = l.match(SQL_TYPES); if (cm) cols.add(cm[1]); }
    byTable.set(m[1], cols);
  }
});
const SRC = fs.readFileSync(path.resolve(__dirname, '../../../../../src/edge/routes/app/api-connectors/source-candidates.js'), 'utf8');

describe('source-candidates — schema parity', () => {
  it('reads real columns on user_templates', () => {
    assert.match(SRC, /SELECT id, name, updated_at FROM/);
    const c = byTable.get('user_templates');
    assert.ok(c.has('id') && c.has('name') && c.has('updated_at') && c.has('blueprint_id'));
  });
  it('reads real source + approval-gate + manage-authority columns on api_connectors', () => {
    // R6-C2: owner_id/blueprint_id were added so `?test=1` can run the SAME
    // manage-authority rule /prepare applies (connector-manage-authority.js).
    // R6-D3: is_active moved from the WHERE clause into the SELECT list so it
    // can be judged AFTER effectiveTest resolves, same as `status`.
    assert.match(SRC, /SELECT is_active, source_kind, source_config, status, owner_id, blueprint_id\s+FROM/);
    const c = byTable.get('api_connectors');
    assert.ok(
      c.has('source_kind') && c.has('source_config') && c.has('is_active') && c.has('status')
      && c.has('owner_id') && c.has('blueprint_id'),
    );
  });
});
