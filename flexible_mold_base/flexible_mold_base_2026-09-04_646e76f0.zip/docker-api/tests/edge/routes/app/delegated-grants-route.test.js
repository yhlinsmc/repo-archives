'use strict';

/**
 * delegated-grants-route.test.js — the granting surface.
 *
 * The rule this file exists to hold: only the SUBJECT'S OWNER and an
 * administrator may grant or revoke, a grantee may not hand their access on,
 * and a caller who owns nothing learns nothing — a foreign subject answers 404,
 * not 403, so an identifier cannot be used to confirm a record exists.
 *
 * The driver is a stub, so what is established here is which question each
 * handler asks, what it binds, and what it answers. The answers themselves are
 * driven by the fixture: `subjectOwner` is what the database would report for
 * the subject named, which is how a caller can be made an owner or a stranger
 * without a database.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../../../src/edge/db');

let queries;
let grantsTablePresent;
let subjectOwner;       // owner_id the subject row reports, or undefined for "no such row"
let subjectNodeType;    // what the hierarchy row is, when the subject is a blueprint
let grantRows;          // rows the grants SELECT returns
let peopleRows;         // rows the users SELECT returns
let ownedBlueprintRows; // blueprints the caller owns, as the hierarchy reports them
let insertError;        // an error the INSERT should throw

function makeConn() {
  return {
    async query(sql, params = []) {
      queries.push({ sql, params });
      if (/information_schema\.TABLES/i.test(sql)) {
        const [name] = params;
        return grantsTablePresent && String(name).endsWith('delegated_grants') ? [{ 1: 1 }] : [];
      }
      if (/^SELECT id FROM `fmb_hierarchy_nodes`/.test(sql)) return ownedBlueprintRows;
      if (/^SELECT owner_id FROM `fmb_hierarchy_nodes`/.test(sql)) {
        if (subjectOwner === undefined || subjectNodeType !== 'blueprint') return [];
        return [{ owner_id: subjectOwner }];
      }
      if (/^SELECT owner_id FROM `fmb_user_templates`/.test(sql)) {
        return subjectOwner === undefined ? [] : [{ owner_id: subjectOwner }];
      }
      // Ordered before the SELECT match: a DELETE also says FROM.
      if (/^INSERT INTO `fmb_delegated_grants`/.test(sql)) {
        if (insertError) throw insertError;
        return { affectedRows: 1 };
      }
      if (/^DELETE FROM `fmb_delegated_grants`/.test(sql)) return { affectedRows: 1 };
      if (/FROM `fmb_delegated_grants`/.test(sql)) return grantRows;
      if (/FROM `fmb_users`/.test(sql)) return peopleRows;
      return [];
    },
    release() {},
  };
}

const poolFacade = { async getConnection() { return makeConn(); } };

require.cache[dbKey] = {
  id: dbKey,
  filename: dbKey,
  loaded: true,
  exports: {
    pool: { ro: poolFacade, rw: poolFacade },
    t: (n) => `fmb_${n}`,
    getDynamicPool: async () => ({ ro: poolFacade, rw: poolFacade }),
  },
};

const router = require('../../../../src/edge/routes/app/delegated-grants');
const { _resetGrantsTableCache } = require('../../../../src/edge/lib/delegated-grants');

// spec §7.1: an owner may grant only when their role is editor or above, so the
// subject owner these cases exercise is an editor. A plain-user owner being
// refused is held in delegated-grants-role-floor.test.js.
const OWNER = { id: '11111111-1111-1111-1111-111111111111', role: 'editor' };
const GRANTEE = { id: '22222222-2222-2222-2222-222222222222', role: 'user' };
const STRANGER = { id: '33333333-3333-3333-3333-333333333333', role: 'user' };
const ADMIN = { id: '44444444-4444-4444-4444-444444444444', role: 'admin' };
const BLUEPRINT = 'aaaaaaaa-0000-0000-0000-00000000000a';
const TEMPLATE = 'bbbbbbbb-0000-0000-0000-00000000000b';
const GRANT_ID = 'cccccccc-0000-0000-0000-00000000000c';

let currentUser;
let server;
let baseUrl;

before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { if (currentUser) req.user = currentUser; next(); });
  app.use('/edge/app/delegated-grants', router);
  server = http.createServer(app);
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});

after(async () => { await new Promise((r) => server.close(r)); });

beforeEach(() => {
  queries = [];
  grantsTablePresent = true;
  subjectOwner = OWNER.id;
  subjectNodeType = 'blueprint';
  grantRows = [];
  // spec §13 D-3 (fmb-1976 PR-3 G-3B-8): the DB row's OWN role decides POST
  // /'s grantee-eligibility gate, independent of the GRANTEE constant's role
  // (which is 'user' for its OTHER job, acting as `currentUser` in "a grantee
  // may not hand their access on" below). Most of this suite tests who may
  // GRANT, not who may be a GRANTEE, so the default target here is eligible;
  // the D-3 rejection itself has its own describe block further down.
  peopleRows = [{ id: GRANTEE.id, display_name: 'A Person', role: 'editor' }];
  ownedBlueprintRows = [];
  insertError = null;
  currentUser = OWNER;
  _resetGrantsTableCache();
});

async function call(method, path, body) {
  const res = await fetch(`${baseUrl}/edge/app/delegated-grants${path}`, {
    method,
    headers: { 'content-type': 'application/json' },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const json = await res.json().catch(() => ({}));
  return { status: res.status, json };
}

const grantBody = (over = {}) => ({
  scope_type: 'blueprint', scope_id: BLUEPRINT, grantee_id: GRANTEE.id, ...over,
});

describe('who may grant', () => {
  it('the subject\'s owner may', async () => {
    const res = await call('POST', '/', grantBody());
    assert.equal(res.status, 201);
    assert.equal(res.json.data.already_granted, false);
  });

  it('an administrator may, without owning it', async () => {
    currentUser = ADMIN;
    subjectOwner = OWNER.id;
    const res = await call('POST', '/', grantBody());
    assert.equal(res.status, 201);
  });

  it('a stranger may not, and is told the subject is not there', async () => {
    currentUser = STRANGER;
    const res = await call('POST', '/', grantBody());
    assert.equal(res.status, 404);
    assert.equal(res.json.error.code, 'NOT_FOUND');
    assert.equal(queries.filter((q) => /^INSERT/.test(q.sql)).length, 0);
  });

  it('a grantee may not hand their access on', async () => {
    // The check is ownership of the subject, and a grant does not confer that.
    // Asserted through the surface rather than argued from the code: this is
    // the escalation the whole feature would be undone by.
    currentUser = GRANTEE;
    grantRows = [{ id: GRANT_ID, scope_type: 'blueprint', scope_id: BLUEPRINT }];
    const res = await call('POST', '/', grantBody({ grantee_id: STRANGER.id }));
    assert.equal(res.status, 404);
    assert.equal(queries.filter((q) => /^INSERT/.test(q.sql)).length, 0);
  });

  it('nobody may grant on a record nobody owns', async () => {
    subjectOwner = null;
    const res = await call('POST', '/', grantBody());
    assert.equal(res.status, 404);
  });

  it('an administrator may not either, and is told why rather than 404', async () => {
    // Not a restriction on administrators — a refusal to store a promise
    // nothing would keep. Every enforcement point requires the record to have
    // an owner, so this grant would appear in the list, be revocable, and
    // convey nothing. The administrator can see the record, so they get the
    // cause instead of the existence-hiding 404 a stranger gets.
    currentUser = ADMIN;
    subjectOwner = null;
    const res = await call('POST', '/', grantBody({ scope_type: 'template', scope_id: TEMPLATE }));
    assert.equal(res.status, 400);
    assert.equal(res.json.error.code, 'UNOWNED_SUBJECT');
    assert.equal(queries.filter((q) => /^INSERT/.test(q.sql)).length, 0);
  });

  it('an administrator may not grant over a subject that does not exist', async () => {
    // The row would be a grant over nothing, which nobody could ever see or
    // revoke: the list is read per subject, and there is no subject.
    currentUser = ADMIN;
    subjectOwner = undefined;
    const res = await call('POST', '/', grantBody());
    assert.equal(res.status, 404);
    assert.equal(queries.filter((q) => /^INSERT/.test(q.sql)).length, 0);
  });

  it('a blueprint id that names a different tier is not a subject', async () => {
    subjectNodeType = 'category';
    const res = await call('POST', '/', grantBody());
    assert.equal(res.status, 404);
  });

  it('an anonymous caller reaches no statement at all', async () => {
    currentUser = null;
    const res = await call('POST', '/', grantBody());
    assert.equal(res.status, 401);
    assert.equal(queries.length, 0);
  });
});

describe('what may be granted, and to whom', () => {
  it('refuses a subject kind it does not know', async () => {
    const res = await call('POST', '/', grantBody({ scope_type: 'variant' }));
    assert.equal(res.status, 400);
  });

  it('refuses a person who cannot sign in', async () => {
    peopleRows = [];
    const res = await call('POST', '/', grantBody());
    assert.equal(res.status, 400);
    assert.equal(res.json.error.code, 'UNKNOWN_GRANTEE');
  });

  it('refuses granting to yourself rather than storing an access nobody needs', async () => {
    // role: 'editor' — OWNER's actual declared role — so this exercises the
    // self-grant refusal specifically, not the D-3 eligibility gate (which
    // runs first and would otherwise mask this with the wrong reason).
    peopleRows = [{ id: OWNER.id, display_name: 'The Owner', role: 'editor' }];
    const res = await call('POST', '/', grantBody({ grantee_id: OWNER.id }));
    assert.equal(res.status, 400);
    assert.equal(res.json.error.code, 'ALREADY_HAS_ACCESS');
  });

  it('refuses a grantee whose role is user (spec §13 D-3)', async () => {
    peopleRows = [{ id: GRANTEE.id, display_name: 'A Person', role: 'user' }];
    const res = await call('POST', '/', grantBody());
    assert.equal(res.status, 400);
    assert.equal(res.json.error.code, 'GRANTEE_NOT_ELIGIBLE');
    assert.equal(res.json.error.message, 'Grants apply to editors and admins only.');
    assert.equal(queries.filter((q) => /^INSERT/.test(q.sql)).length, 0, 'no row was written');
  });

  it('grants to an admin, same as an editor (spec §13 D-3)', async () => {
    peopleRows = [{ id: GRANTEE.id, display_name: 'A Person', role: 'admin' }];
    const res = await call('POST', '/', grantBody());
    assert.equal(res.status, 201);
  });

  it('answers a repeated grant as the success it effectively is', async () => {
    insertError = Object.assign(new Error('duplicate'), { errno: 1062 });
    const res = await call('POST', '/', grantBody());
    assert.equal(res.status, 200);
    assert.equal(res.json.data.already_granted, true);
  });

  it('records who granted it', async () => {
    await call('POST', '/', grantBody());
    const insert = queries.find((q) => /^INSERT INTO `fmb_delegated_grants`/.test(q.sql));
    assert.deepEqual(insert.params.slice(1), ['blueprint', BLUEPRINT, GRANTEE.id, OWNER.id]);
  });
});

describe('revoking', () => {
  it('is gated exactly as granting is, not more loosely', async () => {
    currentUser = STRANGER;
    grantRows = [{ scope_type: 'blueprint', scope_id: BLUEPRINT }];
    const res = await call('DELETE', `/${GRANT_ID}`);
    assert.equal(res.status, 404);
    assert.equal(queries.filter((q) => /^DELETE/.test(q.sql)).length, 0);
  });

  it('removes the grant for its subject\'s owner', async () => {
    grantRows = [{ scope_type: 'blueprint', scope_id: BLUEPRINT }];
    const res = await call('DELETE', `/${GRANT_ID}`);
    assert.equal(res.status, 200);
    assert.equal(res.json.data.revoked, true);
  });

  it('answers a grant that is not there as absent', async () => {
    grantRows = [];
    const res = await call('DELETE', `/${GRANT_ID}`);
    assert.equal(res.status, 404);
  });
});

describe('reading one subject\'s grants', () => {
  it('is refused to a stranger as absent', async () => {
    currentUser = STRANGER;
    const res = await call('GET', `/?scope_type=blueprint&scope_id=${BLUEPRINT}`);
    assert.equal(res.status, 404);
  });

  it('says when a listed account has been deleted, rather than naming it', async () => {
    // The users lookup finds nothing for either id. The shared enrichment's
    // default for that is the WORD "Unknown", which a screen cannot tell from a
    // display name — so the row rendered as an ordinary person who has access.
    peopleRows = [];
    grantRows = [{
      id: GRANT_ID, scope_type: 'blueprint', scope_id: BLUEPRINT,
      grantee_id: GRANTEE.id, granted_by: OWNER.id, created_at: new Date(0),
    }];
    const res = await call('GET', `/?scope_type=blueprint&scope_id=${BLUEPRINT}`);
    const [row] = res.json.data.grants;
    assert.equal(row.grantee_removed, true);
    assert.equal(row.granter_removed, true);
    assert.equal(row.grantee_name, '', 'a deleted account was given a name to render');
    assert.ok(!JSON.stringify(res.json).includes('Unknown'), 'the placeholder word reached the wire');
  });

  it('returns names for both people and never an address', async () => {
    grantRows = [{
      id: GRANT_ID, scope_type: 'blueprint', scope_id: BLUEPRINT,
      grantee_id: GRANTEE.id, granted_by: OWNER.id, created_at: new Date(0),
    }];
    const res = await call('GET', `/?scope_type=blueprint&scope_id=${BLUEPRINT}`);
    assert.equal(res.status, 200);
    const [row] = res.json.data.grants;
    assert.ok('grantee_name' in row && 'granter_name' in row);
    assert.ok(!('owner_name' in row), 'the enrichment\'s own field name leaked through');
    assert.ok(!JSON.stringify(res.json).includes('@'), 'an address reached the response');
  });
});

describe('the person picker', () => {
  it('returns identity, display name, kc_username and role — no address (spec §8.2)', async () => {
    peopleRows = [{
      id: GRANTEE.id, display_name: 'A Person', kc_username: 'aperson', role: 'user',
    }];
    const res = await call('GET', '/people');
    assert.deepEqual(res.json.data.people, [{
      id: GRANTEE.id, display_name: 'A Person', kc_username: 'aperson', role: 'user',
    }]);
    const select = queries.find((q) => /FROM `fmb_users`/.test(q.sql));
    assert.ok(!/email/.test(select.sql), `the picker selected an address: ${select.sql}`);
    assert.match(select.sql, /\brole\b/, `the picker no longer selects role: ${select.sql}`);
  });

  it('matches the same text it shows, so an address can never be confirmed by typing it', async () => {
    // Both sides of the comparison are the domain-stripped form: the caller
    // reads a name in the list, types it, and finds that person — and typing an
    // address matches nothing, which is the never-return-email rule holding on
    // the way in as well as out.
    await call('GET', '/people?q=ann');
    const select = queries.find((q) => /FROM `fmb_users`/.test(q.sql));
    assert.match(select.sql, /SUBSTRING_INDEX\(display_name, '@', 1\) LIKE \?/);
    assert.match(select.sql, /SUBSTRING_INDEX\(kc_username, '@', 1\) LIKE \?/);
    assert.ok(!/[^_]\bdisplay_name LIKE/.test(select.sql), `an unstripped name was matched: ${select.sql}`);
  });

  it('sends the caller\'s search term to the database rather than filtering a fixed page', async () => {
    // Without this the term never leaves the browser: the server returns the
    // first page by name and the picker says "no matching person" about
    // everyone after it.
    await call('GET', '/people?q=ann');
    const select = queries.find((q) => /FROM `fmb_users`/.test(q.sql));
    assert.ok(select.params.some((p) => String(p).includes('ann')), 'the term never reached the statement');
  });

  it('is bounded, and says when there are more people than it returned', async () => {
    // It asks for one row past the ceiling so "there are more" is a fact rather
    // than a guess, and returns the ceiling.
    peopleRows = Array.from({ length: 201 }, (_, i) => ({ id: `u-${i}`, display_name: `P${i}` }));
    const res = await call('GET', '/people');
    const select = queries.find((q) => /FROM `fmb_users`/.test(q.sql));
    assert.equal(select.params[select.params.length - 1], 201);
    assert.equal(res.json.data.people.length, 200);
    assert.equal(res.json.data.limit, 200);
    assert.equal(res.json.data.truncated, true);
  });

  it('says nothing was truncated when nothing was', async () => {
    peopleRows = [{ id: GRANTEE.id, display_name: 'A Person' }];
    const res = await call('GET', '/people');
    assert.equal(res.json.data.truncated, false);
  });

  it('names a person with no display name the way every other surface does', async () => {
    // The same person was picked from the list as one thing and shown in the
    // row as another, because the two paths resolved names differently. Both
    // now run the same coalescing chain, stripped.
    peopleRows = [{
      id: GRANTEE.id, display_name: null, kc_username: 'jdoe@corp.example', role: 'user',
    }];
    const res = await call('GET', '/people');
    assert.deepEqual(res.json.data.people, [{
      id: GRANTEE.id, display_name: 'jdoe', kc_username: 'jdoe', role: 'user',
    }]);
  });

  it('never puts an address on the wire, even when the display name is one', async () => {
    // The leak this closes is not the email COLUMN — that is never selected.
    // It is that `display_name` is not guaranteed to be anything else: the
    // token mapper sets it from the account name when no display name is
    // mapped, which is the shape of this project's own development realm. A
    // fixture whose display name is a person's name cannot see it.
    peopleRows = [{
      id: GRANTEE.id, display_name: 'jane.doe@corp.example', kc_username: null, role: 'editor',
    }];
    const res = await call('GET', '/people');
    assert.equal(res.status, 200);
    assert.ok(
      !JSON.stringify(res.json).includes('@'),
      `an address reached the picker: ${JSON.stringify(res.json)}`,
    );
    assert.deepEqual(res.json.data.people, [{
      id: GRANTEE.id, display_name: 'jane.doe', kc_username: '', role: 'editor',
    }]);
  });

  it('excludes people who cannot sign in', async () => {
    await call('GET', '/people');
    const select = queries.find((q) => /FROM `fmb_users`/.test(q.sql));
    assert.match(select.sql, /banned = 0/);
  });

  it('R-3-P2: filters to editor/admin at the source, not merely by what the fixture returns', async () => {
    await call('GET', '/people');
    const select = queries.find((q) => /FROM `fmb_users`/.test(q.sql));
    assert.match(select.sql, /role IN \('editor', 'admin'\)/);
  });

  it('R-3-P4: refused to a plain user (403), allowed to an editor (200)', async () => {
    currentUser = { ...GRANTEE, role: 'user' };
    const denied = await call('GET', '/people');
    assert.equal(denied.status, 403);
    currentUser = { ...GRANTEE, role: 'editor' };
    const allowed = await call('GET', '/people');
    assert.equal(allowed.status, 200);
  });
});

describe('the caller\'s own access', () => {
  it('is read for the caller and nobody else', async () => {
    // R-3-P1: /mine only ever reads the grants table for an editor or admin
    // caller (a plain user's grants, if any survive from before the D-3
    // floor, are never honoured) — GRANTEE (role: 'user') is exercised
    // separately below.
    currentUser = { ...GRANTEE, role: 'editor' };
    grantRows = [
      { scope_type: 'blueprint', scope_id: BLUEPRINT },
      { scope_type: 'template', scope_id: TEMPLATE },
    ];
    const res = await call('GET', '/mine');
    assert.deepEqual(res.json.data, {
      blueprint_ids: [BLUEPRINT], template_ids: [TEMPLATE], owned_blueprint_ids: [],
    });
    const select = queries.find((q) => /FROM `fmb_delegated_grants`/.test(q.sql));
    assert.match(select.sql, /WHERE grantee_id = \?/);
    assert.equal(select.params[0], GRANTEE.id);
  });

  it('R-3-P1: a plain user sees an empty list even though grant rows name them, and the table is never queried', async () => {
    currentUser = GRANTEE; // role: 'user'
    grantRows = [
      { scope_type: 'blueprint', scope_id: BLUEPRINT },
      { scope_type: 'template', scope_id: TEMPLATE },
    ];
    const res = await call('GET', '/mine');
    assert.deepEqual(res.json.data, {
      blueprint_ids: [], template_ids: [], owned_blueprint_ids: [],
    });
    assert.equal(queries.some((q) => /FROM `fmb_delegated_grants`/.test(q.sql)), false);
  });

  it('carries the blueprints the caller owns, which no grant row records', async () => {
    // A blueprint's owner reaches every record under it without a grant
    // existing. Read from the hierarchy, or the screen would offer editing to
    // everyone the grants table knows about and to nobody else — including not
    // to the person who hands that access out.
    currentUser = OWNER;
    ownedBlueprintRows = [{ id: BLUEPRINT }];
    const res = await call('GET', '/mine');
    assert.deepEqual(res.json.data.owned_blueprint_ids, [BLUEPRINT]);
    const select = queries.find((q) => /^SELECT id FROM `fmb_hierarchy_nodes`/.test(q.sql));
    assert.match(select.sql, /node_type = 'blueprint' AND owner_id = \?/);
    assert.equal(select.params[0], OWNER.id);
  });

  it('a plain-user owner sees no owned blueprints even though the hierarchy names them, same floor as the grants list', async () => {
    // R-3-P1's floor applies to this arm too (spec §7.13): the hierarchy row
    // itself does not know the caller has since been demoted, so `eligible`
    // is what keeps a plain user's owner_id match from being honoured.
    currentUser = { ...OWNER, role: 'user' };
    ownedBlueprintRows = [{ id: BLUEPRINT }];
    const res = await call('GET', '/mine');
    assert.deepEqual(res.json.data.owned_blueprint_ids, []);
  });
});

describe('a database with no grants table', () => {
  it('refuses a write with a cause an operator can act on', async () => {
    grantsTablePresent = false;
    const res = await call('POST', '/', grantBody());
    assert.equal(res.status, 503);
    assert.equal(res.json.error.code, 'GRANTS_UNAVAILABLE');
  });

  it('answers the caller\'s own access as empty rather than failing', async () => {
    // This one is read on every data-entry screen. A 503 there would turn a
    // missing optional table into a broken page.
    grantsTablePresent = false;
    const res = await call('GET', '/mine');
    assert.equal(res.status, 200);
    assert.deepEqual(res.json.data, {
      blueprint_ids: [], template_ids: [], owned_blueprint_ids: [],
    });
  });

  it('still reports the blueprints the caller owns, which need no grants table', async () => {
    grantsTablePresent = false;
    ownedBlueprintRows = [{ id: BLUEPRINT }];
    const res = await call('GET', '/mine');
    assert.equal(res.status, 200);
    assert.deepEqual(res.json.data.owned_blueprint_ids, [BLUEPRINT]);
  });
});
