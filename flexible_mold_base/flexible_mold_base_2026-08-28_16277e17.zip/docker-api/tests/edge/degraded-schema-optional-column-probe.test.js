/**
 * degraded-schema-optional-column-probe.test.js — structural closure of the
 * degraded-schema family. Pure static analysis, NO live DB.
 *
 * THE INVARIANT: a warn-skipped `add-column` migration (operator lacks DDL
 * privilege, severity 'warning') leaves the column PHYSICALLY ABSENT. Any SQL
 * that names such a column — read OR write — 500s with ER_BAD_FIELD_ERROR (1054)
 * on that database. Five sites of this family were fixed one review round at a
 * time; this test replaces whack-a-mole with a mechanical assertion: EVERY SQL
 * string naming an optional column must have a degraded-mode probe in scope.
 *
 * The optional-column list is DERIVED from the migration registry (add-column +
 * severity 'warning'), never hand-written — a new warn-severity column is picked
 * up automatically, and a site added for it without a probe fails this test.
 *
 * Recognised probe mechanisms (file-level, matching the brief's granularity):
 *   - tableColumnSet / dropAbsentColumns  — capacity _shared writer-probing helpers
 *   - getActualColumnSet                  — schema helpers' information_schema probe,
 *                                           called by the schema routes
 *   - information_schema (a COLUMNS probe the file runs itself)
 *   - reactive missing-column fallback    — the statement is wrapped in a catch that
 *                                           degrades on ER_BAD_FIELD_ERROR / errno 1054
 *                                           (blueprint compute-rule / serialization libs)
 *   - // probe-exempt: <reason>           — explicit opt-out; the reason is MANDATORY
 *                                           and must NAME the mechanism that handles
 *                                           degradation. Grep-able; currently unused.
 * Mechanism tokens are matched against COMMENT-STRIPPED source, so a token named
 * only in prose does not count as evidence (the pragma is the one exception — it
 * IS a comment by design, and is matched against the raw source).
 *
 * The matcher is deliberately over-inclusive on WHAT it flags (any SQL-looking
 * string naming the column) and coarse on evidence (file-level).
 *
 * KNOWN BLIND SPOTS — this test claims family coverage at FILE granularity, not
 * proof that every statement is guarded:
 *   - File-level evidence, not statement-level. A file that probes SOMEWHERE
 *     passes for ALL its optional-column SQL. A single unprobed statement inside
 *     an otherwise-probing file is NOT caught — the routes-variant-overrides.js
 *     `by-variants` batch read was exactly that (getActualColumnSet in sibling
 *     handlers, none on that one) and it took a human reviewer, not this test.
 *   - Dynamic / split column names. A column list assembled from payload keys
 *     (the capacity settings/config writers), a `SELECT ${column}`, or the name
 *     held in a separate string const outside the SQL-verb span, is invisible to
 *     a literal-name matcher — the same blind spot the census has. These sites
 *     carry their own probe (dropAbsentColumns / a per-column tableColumnSet
 *     gate), but THIS test cannot SEE that they do — its evidence is "the file
 *     mentions a probe token somewhere", not "this interpolated statement is
 *     guarded". The wizard's cap_vms INSERT (capacity/wizard.js) was exactly this
 *     shape: it builds the column list as an interpolated `${names}` inside
 *     insertRow, so `function_name` never appears in an SQL-verb string here, and
 *     the write-side degradation went UNGUARDED for a review round even though a
 *     read-side sibling (renumber.js) was flagged-and-guarded. The fix is pinned
 *     directly, not left to this file's file-level heuristic: capacity-wizard.test.js
 *     ("degrades the cap_vms INSERT when function_name is physically absent")
 *     asserts the wizard omits the column and still commits when the schema lacks
 *     it. A future interpolated-write site of a warn-column needs the same kind of
 *     pinned test — this closure will not catch it.
 *   - Only `.js` under docker-api/src is scanned; a `.sql` file (none today) is not.
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');

const SRC = path.resolve(__dirname, '../../src');
const { MIGRATION_STEPS } = require('../../src/edge/migration-steps');

// ── optional-column list, derived mechanically from the migration registry ──
function deriveOptionalColumns() {
  const cols = new Set();
  for (const step of MIGRATION_STEPS) {
    if (step && step.kind === 'add-column' && step.severity === 'warning' && step.column) {
      cols.add(String(step.column));
    }
  }
  return cols;
}

// ── comment-safe scanning ────────────────────────────────────────────────────
// A single char-state machine underlies both helpers. Comment-exclusion is the
// point: this codebase's prose comments are full of apostrophes, example SQL, and
// mechanism names, which a raw regex would mis-read.

// Every string / template-literal span found in CODE (comments excluded), each
// with its 1-based start line.
function extractCodeStrings(src) {
  const out = [];
  const n = src.length;
  let i = 0;
  let line = 1;
  const S = { NORMAL: 0, LINE: 1, BLOCK: 2, SINGLE: 3, DOUBLE: 4, TMPL: 5 };
  let state = S.NORMAL;
  let buf = '';
  let startLine = 0;
  while (i < n) {
    const c = src[i];
    const c2 = src[i + 1];
    if (c === '\n') line += 1;
    switch (state) {
      case S.NORMAL:
        if (c === '/' && c2 === '/') { state = S.LINE; i += 2; break; }
        if (c === '/' && c2 === '*') { state = S.BLOCK; i += 2; break; }
        if (c === "'") { state = S.SINGLE; buf = ''; startLine = line; i += 1; break; }
        if (c === '"') { state = S.DOUBLE; buf = ''; startLine = line; i += 1; break; }
        if (c === '`') { state = S.TMPL; buf = ''; startLine = line; i += 1; break; }
        i += 1; break;
      case S.LINE:
        if (c === '\n') state = S.NORMAL;
        i += 1; break;
      case S.BLOCK:
        if (c === '*' && c2 === '/') { state = S.NORMAL; i += 2; break; }
        i += 1; break;
      case S.SINGLE:
        if (c === '\\') { buf += c + (c2 ?? ''); i += 2; break; }
        if (c === "'") { out.push({ text: buf, line: startLine }); state = S.NORMAL; i += 1; break; }
        buf += c; i += 1; break;
      case S.DOUBLE:
        if (c === '\\') { buf += c + (c2 ?? ''); i += 2; break; }
        if (c === '"') { out.push({ text: buf, line: startLine }); state = S.NORMAL; i += 1; break; }
        buf += c; i += 1; break;
      case S.TMPL:
        // Naive to the next unescaped backtick — SQL template literals never carry
        // a nested backtick, so `${t(TABLES.X)}` interpolations are kept as text.
        if (c === '\\') { buf += c + (c2 ?? ''); i += 2; break; }
        if (c === '`') { out.push({ text: buf, line: startLine }); state = S.NORMAL; i += 1; break; }
        buf += c; i += 1; break;
      default: i += 1;
    }
  }
  return out;
}

// The source with comments blanked but strings/templates preserved verbatim, so a
// probe-mechanism token mentioned only in prose is not read as evidence.
function stripComments(src) {
  const n = src.length;
  let i = 0;
  let out = '';
  const S = { NORMAL: 0, LINE: 1, BLOCK: 2, SINGLE: 3, DOUBLE: 4, TMPL: 5 };
  let state = S.NORMAL;
  while (i < n) {
    const c = src[i];
    const c2 = src[i + 1];
    switch (state) {
      case S.NORMAL:
        if (c === '/' && c2 === '/') { state = S.LINE; i += 2; break; }
        if (c === '/' && c2 === '*') { state = S.BLOCK; i += 2; break; }
        if (c === "'") { state = S.SINGLE; out += c; i += 1; break; }
        if (c === '"') { state = S.DOUBLE; out += c; i += 1; break; }
        if (c === '`') { state = S.TMPL; out += c; i += 1; break; }
        out += c; i += 1; break;
      case S.LINE:
        if (c === '\n') { state = S.NORMAL; out += c; }
        i += 1; break;
      case S.BLOCK:
        if (c === '*' && c2 === '/') { state = S.NORMAL; i += 2; break; }
        if (c === '\n') out += c;
        i += 1; break;
      case S.SINGLE:
        out += c;
        if (c === '\\') { out += (c2 ?? ''); i += 2; break; }
        if (c === "'") state = S.NORMAL;
        i += 1; break;
      case S.DOUBLE:
        out += c;
        if (c === '\\') { out += (c2 ?? ''); i += 2; break; }
        if (c === '"') state = S.NORMAL;
        i += 1; break;
      case S.TMPL:
        out += c;
        if (c === '\\') { out += (c2 ?? ''); i += 2; break; }
        if (c === '`') state = S.NORMAL;
        i += 1; break;
      default: i += 1;
    }
  }
  return out;
}

const SQL_RE = /\b(SELECT|INSERT|UPDATE|DELETE)\b/i;

// Every optional-column reference inside an SQL-looking code string in one file.
function scanSource(src, cols) {
  const hits = [];
  for (const s of extractCodeStrings(src)) {
    if (!SQL_RE.test(s.text)) continue;
    for (const col of cols) {
      if (new RegExp(`\\b${col}\\b`, 'i').test(s.text)) hits.push({ col, line: s.line });
    }
  }
  return hits;
}

// Mechanism tokens are checked against comment-stripped code; the pragma is a
// comment by design, so it is checked against the raw source.
const PROBE_CODE_TOKENS = [
  /\btableColumnSet\b/,
  /\bdropAbsentColumns\b/,
  /\bgetActualColumnSet\b/,
  /information_schema/i,
  /\bER_BAD_FIELD_ERROR\b/,
  /errno\s*===?\s*1054/,
];
const PRAGMA_RE = /\/\/\s*probe-exempt:\s*\S/; // reason mandatory
function hasProbeEvidence(src) {
  if (PRAGMA_RE.test(src)) return true;
  const code = stripComments(src);
  return PROBE_CODE_TOKENS.some((re) => re.test(code));
}

// ── file walk ───────────────────────────────────────────────────────────────
const EXCLUDE = new Set([
  path.join(SRC, 'edge/migration-steps.js'), // the registry itself
  path.join(SRC, 'edge/migrations.js'), // the executor's own probes/DDL
  path.join(SRC, 'table-ddls.js'), // the schema authority (column DEFINITIONS)
  path.join(SRC, 'edge/db.js'), // DDL preflight
]);
function walk(dir, out = []) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, e.name);
    if (e.isDirectory()) {
      if (e.name === '__tests__' || e.name === 'node_modules') continue;
      walk(full, out);
    } else if (e.name.endsWith('.js') && !EXCLUDE.has(full)) {
      out.push(full);
    }
  }
  return out;
}

describe('degraded-schema optional-column probe closure (fmb-1645)', () => {
  const cols = deriveOptionalColumns();

  // Instrument check on the DERIVATION, as an EXACT tripwire, not a floor: a
  // silent shrink — a warn add-column dropped from the registry or its severity
  // flipped — is the regression this guards. Update this number DELIBERATELY when
  // the registry gains or loses a warn-severity add-column (and add the new site's
  // probe in the same change). name_patterns is the B5a column this closure exists
  // for; its membership proves the registry parse ran.
  //
  // standby_node_count (spec §7 E1 / Q11): 10th member. Its writes
  // (wizard.js, database-bulk-create.js) build the INSERT column list via the
  // SAME interpolated-array `insertRow` shape as cap_vms.function_name (the
  // KNOWN BLIND SPOT this file's own header names) — invisible to the literal-
  // name matcher, covered instead by the file-level probe token those same
  // files already carry from the function_name/name_locked degraded-schema
  // work. The mechanical "every SQL string ... has a probe in scope" check
  // below stays green with no new probe code, exactly as it did for
  // function_name's own wizard.js INSERT site.
  //
  // blueprint_output_order.format (spec §5 C2 / Q7): 11th member.
  // Its two literal-INSERT sites (blueprint-export.js JSON import, mode=new
  // and overwrite) now build the row through buildPortableInsert — an
  // unrecognised mechanism token, so both carry a `// probe-exempt:` pragma
  // naming it (the file has no OTHER call to a recognised token itself).
  //
  // cap_settings.placement_layout (post-ar2-residuals P6): 12th member. Its
  // one literal-SQL reference (_shared.js isGlobalConfigEmpty's SELECT,
  // conditionally interpolated behind its own tableColumnSet probe) sits in
  // the SAME file that defines tableColumnSet/dropAbsentColumns themselves,
  // so the file-level closure below is already satisfied with no new pragma;
  // every write path (config.js/settings.js) reaches it only through the
  // generic column-list writers (WRITABLE_COLUMNS/CONFIG_MOUNTS.settings.cols
  // + dropAbsentColumns), never a literal column name in an SQL string.
  //
  // hierarchy_nodes.naming_rule (per-blueprint auto-naming template): 13th
  // member. Its CRUD-factory read/write is generic (SELECT * / gateKeysByColumnSet,
  // same shape as placement_layout). It ALSO has literal-SQL references — the
  // hierarchy_node re-INSERT (blueprint-export.js, JSON import + YAML mode=new)
  // and the root-metadata UPDATE (blueprint-serialization.js overwriteBlueprint)
  // are hand-written statements that can't use buildPortableInsert/gateKeysByColumnSet
  // directly (forced values / non-row params), so each names naming_rule behind
  // its own actualColumns() probe (fmb-1890 NAME-E2 r2). blueprint-export.js
  // already carries a `// probe-exempt:` pragma (from the format/blueprint_output_order
  // work) that satisfies this file-level closure; blueprint-serialization.js is
  // already recognised via its ER_BAD_FIELD_ERROR/errno-1054 reactive fallback
  // elsewhere in the same file. Both are also pinned at STATEMENT granularity by
  // the pre/post-migration naming_rule tests in blueprint-import-roundtrip.test.js.
  //
  // blueprint_fields.options_source (dynamic-field-options design): 14th member.
  // No file names it in a literal SQL string anywhere in docker-api/src — every
  // read/write path is generic (gateKeysByColumnSet for the field-editor route,
  // buildPortableInsert/actualColumns for export/import, `SELECT *` for the raw
  // JSON export), the same shape placement_layout already satisfies with no new
  // pragma. It carries no hand-written re-INSERT the way naming_rule's
  // hierarchy_node copy does, so it needs no probe-exempt pragma either.
  it('derives the exact warn-severity add-column set from the migration registry', () => {
    assert.equal(
      cols.size, 14,
      `expected 14 warn-severity add-columns, got ${cols.size}: ${[...cols].join(', ')}`,
    );
    assert.ok(cols.has('name_patterns'), 'derivation must include name_patterns (fmb B5a)');
    assert.ok(cols.has('name_locked'), 'derivation must include name_locked (cap-renumber-lock)');
    // ap-vm-function (PR-2): renumber.js SELECTs cap_vms.function_name behind the
    // same tableColumnSet probe as name_locked — the closure assertion below
    // proves the probe is in scope.
    assert.ok(cols.has('function_name'), 'derivation must include function_name (ap-vm-function)');
    assert.ok(cols.has('naming_rule'), 'derivation must include naming_rule (per-blueprint auto-naming template)');
    assert.ok(cols.has('options_source'), 'derivation must include options_source (dynamic-field-options design)');
  });

  // Instrument check on the MATCHER + RECOGNISER, independent of any real file —
  // the "case proving the instrument works" an absence-shaped assertion needs.
  it('matcher flags an SQL string naming an optional column, and ignores comments', () => {
    assert.equal(scanSource('const q = `SELECT name_patterns FROM x WHERE id = ?`;', cols).length, 1);
    // A column named only in a comment must NOT be flagged (comment exclusion).
    assert.equal(scanSource('// SELECT name_patterns FROM x -- example\nconst q = 1;', cols).length, 0);
    // A non-SQL string naming the column must NOT be flagged.
    assert.equal(scanSource("const label = 'name_patterns column';", cols).length, 0);
  });
  it('probe recogniser accepts each mechanism, in code only, and rejects prose', () => {
    assert.equal(hasProbeEvidence('await dropAbsentColumns(pool.rw, T, c, v);'), true);
    assert.equal(hasProbeEvidence('await tableColumnSet(pool.rw, T);'), true);
    assert.equal(hasProbeEvidence('await getActualColumnSet(conn, phys);'), true);
    assert.equal(hasProbeEvidence("if (err.code === 'ER_BAD_FIELD_ERROR') return null;"), true);
    assert.equal(hasProbeEvidence('if (err.errno === 1054) return null;'), true);
    assert.equal(hasProbeEvidence('// probe-exempt: handled by X'), true);
    // The mechanism named only in PROSE is not evidence.
    assert.equal(hasProbeEvidence('// this used to throw ER_BAD_FIELD_ERROR before\nconst x = 1;'), false);
    assert.equal(hasProbeEvidence('const rows = await conn.query(`SELECT name_patterns FROM x`);'), false);
  });

  // ── the closure assertion ──────────────────────────────────────────────────
  it('every SQL string naming an optional column has a probe in scope', () => {
    const files = walk(SRC);
    // Instrument check: a broken walk() that reached near-zero files would pass the
    // closure vacuously. Coarse floor well under the real corpus (~271 today).
    assert.ok(files.length > 200, `walk() reached only ${files.length} .js files — coverage broken`);

    const unguarded = [];
    const flagged = new Set();
    let flaggedPairs = 0;
    for (const f of files) {
      const src = fs.readFileSync(f, 'utf8');
      const hits = scanSource(src, cols);
      if (!hits.length) continue;
      flagged.add(f);
      flaggedPairs += hits.length;
      if (hasProbeEvidence(src)) continue;
      const rel = path.relative(path.resolve(SRC, '..'), f);
      for (const h of hits) unguarded.push(`${rel}:${h.line} [${h.col}]`);
    }

    // Instrument check: the scan must reach real SQL sites — a zero means the walk
    // or the matcher broke, not that the codebase is clean.
    assert.ok(flaggedPairs > 0, 'scanner reached no optional-column SQL — instrument broken');

    // Sentinel files that MUST stay flagged: if the matcher silently stops seeing
    // these known optional-column sites, it has rotted. Each is flagged-and-guarded.
    for (const sentinel of [
      'capacity/renumber.js',
      'schema/routes-blueprint-fields.js',
      'schema/routes-variant-overrides.js',
    ]) {
      assert.ok(
        [...flagged].some((f) => f.endsWith(sentinel)),
        `sentinel no longer flagged (matcher rot?): ${sentinel}`,
      );
    }

    assert.deepEqual(
      unguarded, [],
      `SQL naming an optional column with no degraded-mode probe in scope:\n  ${unguarded.join('\n  ')}\n`
      + 'Add a probe (dropAbsentColumns / getActualColumnSet / information_schema / catch ER_BAD_FIELD_ERROR) '
      + 'or a "// probe-exempt: <reason>" pragma naming the mechanism that handles the column being absent.',
    );
  });
});

// ── statement-level closure for cap_vms.function_name (PR-2 codex r2) ──────────
//
// The file-level closure above accepts a probe token ANYWHERE in the file. That is
// its documented first blind spot, and it is exactly what let TWO cap_vms.function_name
// sites ship unguarded across a review round: the vm_type-flip guard's FOR UPDATE
// read in _shared.js (which DEFINES tableColumnSet / dropAbsentColumns, so the file
// trivially "has a probe token") and the scenario-import INSERT in io.js (which
// builds its column list dynamically, so function_name never appears in an SQL-verb
// string there at all). This closes the class for THIS ONE column at STATEMENT
// granularity: every SQL literal that names function_name against cap_vms must BE
// one of the allowlisted degraded-aware sites, and its own text must carry the
// evidence of the degradation. A new literal spelling function_name against cap_vms
// anywhere else, or an allowlisted one that loses its evidence, is red.
//
// Dynamic writers (io.js import, wizard.js create) never spell the column in an
// SQL-verb string, so they are invisible to a literal matcher HERE by construction
// — the same blind spot the census has. They are pinned by behaviour tests instead
// (capacity-wizard.test.js and capacity-import-degraded-*.test.js assert the write
// omits the column and still commits when the schema lacks it), which is the remedy
// this repo already uses for interpolated write sites. This static test guards the
// one shape it CAN see reliably: a hard-coded SELECT/DML literal naming the column.
describe('cap_vms.function_name degraded-schema statement closure (PR-2 codex r2)', () => {
  // file suffix → regex the flagged SQL literal's OWN text must match, proving that
  // statement degrades. The vm_type-flip guard names function_name only inside a
  // conditional column list gated on a same-connection tableColumnSet({cache:false})
  // probe, so a degraded DB reads vm_type alone.
  const ALLOWLIST = [
    {
      suffix: 'edge/routes/app/capacity/_shared.js',
      evidence: /\?\s*'vm_type,\s*function_name'\s*:\s*'vm_type'/,
      note: 'vm_type-flip guard FOR UPDATE read',
    },
  ];

  // A cap_vms.function_name SQL literal = an SQL-verb string that names function_name
  // AND targets cap_vms (a CAP_VMS table reference in the same string). The cap_vms
  // qualifier is what keeps cap_databases.function_name (renumber.js `d.function_name`,
  // an always-present required column) out of scope.
  function scanCapVmsFn(src) {
    const hits = [];
    for (const s of extractCodeStrings(src)) {
      if (!SQL_RE.test(s.text)) continue;
      if (!/\bfunction_name\b/.test(s.text)) continue;
      if (!/CAP_VMS\b/.test(s.text)) continue;
      hits.push({ line: s.line, text: s.text });
    }
    return hits;
  }

  it('matcher flags a cap_vms function_name literal and ignores comments / other tables / non-SQL', () => {
    assert.equal(
      scanCapVmsFn('const q = `SELECT vm_type, function_name FROM ${t(TABLES.CAP_VMS)}`;').length, 1,
    );
    // cap_databases.function_name (no CAP_VMS reference) is out of scope.
    assert.equal(
      scanCapVmsFn('const q = `SELECT d.function_name FROM ${t(TABLES.CAP_DATABASES)} d`;').length, 0,
    );
    // Comment-only mention is not flagged.
    assert.equal(scanCapVmsFn('// SELECT function_name FROM CAP_VMS\nconst x = 1;').length, 0);
    // Non-SQL string is not flagged.
    assert.equal(scanCapVmsFn("const label = 'function_name on CAP_VMS';").length, 0);
    // The evidence regex accepts the guard's conditional and rejects an unconditional read.
    assert.match("SELECT ${h ? 'vm_type, function_name' : 'vm_type'} FROM", ALLOWLIST[0].evidence);
    assert.doesNotMatch('SELECT vm_type, function_name FROM', ALLOWLIST[0].evidence);
  });

  it('every hard-coded cap_vms.function_name SQL literal is an allowlisted degraded-aware site', () => {
    const files = walk(SRC);
    assert.ok(files.length > 200, `walk() reached only ${files.length} .js files — coverage broken`);

    const offenders = [];
    const seenSuffixes = new Set();
    let totalHits = 0;
    for (const f of files) {
      const hits = scanCapVmsFn(fs.readFileSync(f, 'utf8'));
      if (!hits.length) continue;
      const rel = path.relative(path.resolve(SRC, '..'), f);
      const entry = ALLOWLIST.find((a) => f.endsWith(a.suffix));
      for (const h of hits) {
        totalHits += 1;
        if (!entry) {
          offenders.push(`${rel}:${h.line} — new cap_vms.function_name SQL literal, not allowlisted`);
        } else if (!entry.evidence.test(h.text)) {
          offenders.push(`${rel}:${h.line} — allowlisted site lost its degraded-mode evidence (${entry.note})`);
        } else {
          seenSuffixes.add(entry.suffix);
        }
      }
    }

    // Sentinel: the guard read MUST still be found and matched. A zero here means
    // the matcher rotted (e.g. the literal was refactored out of an SQL-verb string)
    // — not that the codebase is clean.
    assert.ok(totalHits > 0, 'scanner reached no cap_vms.function_name SQL literal — instrument broken');
    assert.ok(
      seenSuffixes.has(ALLOWLIST[0].suffix),
      'the vm_type-flip guard read is no longer flagged-and-matched — matcher rot?',
    );

    assert.deepEqual(
      offenders, [],
      `cap_vms.function_name SQL literal(s) that are not degraded-aware:\n  ${offenders.join('\n  ')}\n`
      + 'Spell the column behind a same-connection tableColumnSet(conn, TABLES.CAP_VMS, {cache:false}) '
      + 'probe with a CONDITIONAL column list (see the vm_type-flip guard), or build the column list '
      + 'dynamically through dropAbsentColumns (wizard / scenario-import). If you add a new degraded-aware '
      + 'literal site, list it in ALLOWLIST with a regex proving THAT statement degrades.',
    );
  });
});
