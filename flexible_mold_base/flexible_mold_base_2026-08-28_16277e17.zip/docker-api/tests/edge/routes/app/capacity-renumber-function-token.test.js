/**
 * capacity-renumber-function-token.test.js — cap-pattern-function (spec D2/D7):
 * renumber resolves the {function} token and the primary/standby pattern split
 * per db_host VM. Same mocked-pool harness as capacity-renumber-lock.test.js,
 * extended with cap_db_instances LEFT JOIN cap_databases (the {function}/role
 * resolution source).
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../../../src/edge/db');

let state;
function freshState() {
  return {
    queries: [],
    began: 0, committed: 0, rolledBack: 0, released: 0,
    scenarioExists: true,
    scenarioOwner: null,
    settingsColumns: ['id', 'scenario_id', 'name_patterns', 'mem_cpu_ratio'],
    // function_name (ap-vm-function PR-2): present in cap_vms' physical columns
    // so readTableRows' degraded-schema guard SELECTs it for the ap_vm {function}.
    entityColumns: ['id', 'name', 'order_index', 'site_id', 'vm_type', 'name_locked', 'function_name'],
    scenarioSettings: null,
    globalPatterns: null,
    sites: [{ id: 's1', name: 'DC' }],
    hypervisors: [],
    vms: [],
    // cap_db_instances rows: { vm_id, role, database_id }.
    dbInstances: [],
    // cap_databases rows: { id, function_name, order_index }.
    databases: [],
    // spec §7 E2: readDbInstanceRows' OWN fixture set — deliberately separate
    // from `dbInstances` above (role-only stubs with no id/name; feeding them
    // into the renumber recompute would fabricate spurious renames in these
    // {function}/role tests, which are not about the renumber-instance-name
    // feature). Default empty.
    dbInstanceRows: [],
  };
}

function sortForSql(rows, sql) {
  const out = [...rows];
  if (/ORDER BY order_index/.test(sql)) {
    out.sort((a, b) => (a.order_index - b.order_index) || (a.id < b.id ? -1 : 1));
  } else if (/ORDER BY id FOR UPDATE/.test(sql)) {
    out.sort((a, b) => (a.id < b.id ? -1 : a.id > b.id ? 1 : 0));
  }
  return out;
}

function makeConn() {
  return {
    async beginTransaction() { state.began += 1; },
    async commit() { state.committed += 1; },
    async rollback() { state.rolledBack += 1; },
    release() { state.released += 1; },
    async query(sql, params = []) {
      state.queries.push({ sql, params });

      if (/information_schema\.COLUMNS/.test(sql)) {
        if (params[0] === 'fmb_cap_settings') return state.settingsColumns.map((name) => ({ name }));
        return state.entityColumns.map((name) => ({ name }));
      }
      if (/SELECT id, owner_id FROM `fmb_cap_scenarios` WHERE id = \?/.test(sql)) {
        return state.scenarioExists ? [{ id: params[0], owner_id: state.scenarioOwner }] : [];
      }
      if (/SELECT scenario_id, name_patterns FROM `fmb_cap_settings` WHERE scenario_id = \?/.test(sql)) {
        return state.scenarioSettings
          ? [{ scenario_id: params[0], name_patterns: state.scenarioSettings.name_patterns }]
          : [];
      }
      if (/SELECT scenario_id, name_patterns FROM `fmb_cap_settings` WHERE scenario_id IS NULL/.test(sql)) {
        return [{ scenario_id: null, name_patterns: state.globalPatterns }];
      }
      if (/SELECT id, name FROM `fmb_cap_sites` WHERE scenario_id = \?/.test(sql)) {
        return state.sites.map((s) => ({ id: s.id, name: s.name }));
      }
      if (/FROM `fmb_cap_hypervisors` WHERE scenario_id = \?/.test(sql)) {
        return sortForSql(state.hypervisors, sql).map((r) => ({ ...r }));
      }
      if (/FROM `fmb_cap_vms` WHERE scenario_id = \?/.test(sql)) {
        return sortForSql(state.vms, sql).map((r) => ({ ...r }));
      }
      // readDbInstanceRows LOCK path (spec §7 E2, F2): cap_db_instances ALONE,
      // no join — cap_databases must never be locked by this route.
      if (/SELECT id, name, database_id AS databaseId, role, order_index AS orderIndex/.test(sql)
        && /FROM `fmb_cap_db_instances`/.test(sql) && /FOR UPDATE/.test(sql)) {
        return state.dbInstanceRows.map((inst) => ({
          id: inst.id,
          name: inst.name,
          databaseId: inst.database_id ?? null,
          role: inst.role,
          orderIndex: inst.order_index,
        }));
      }
      // readDbInstanceRows LOCK path's cap_databases companion read (F2): a
      // plain (non-locking) read, one row per distinct database_id.
      if (/SELECT id, function_name AS functionName, topology/.test(sql) && /FROM `fmb_cap_databases`/.test(sql)) {
        const byDbId = new Map();
        for (const inst of state.dbInstanceRows) {
          if (inst.database_id && !byDbId.has(inst.database_id)) {
            byDbId.set(inst.database_id, { id: inst.database_id, functionName: inst.function_name ?? null, topology: inst.topology ?? null });
          }
        }
        return [...byDbId.values()];
      }
      // readDbInstanceRows PREVIEW path (spec §7 E2): cap_db_instances LEFT
      // JOIN cap_databases, keyed by di.id — checked FIRST (same FROM/JOIN
      // shape as the query below, discriminated by the SELECT list).
      if (/SELECT di\.id AS id/.test(sql) && /FROM `fmb_cap_db_instances` di/.test(sql)) {
        return state.dbInstanceRows.map((inst) => ({
          id: inst.id,
          name: inst.name,
          databaseId: inst.database_id ?? null,
          role: inst.role,
          orderIndex: inst.order_index,
          functionName: inst.function_name ?? null,
          topology: inst.topology ?? null,
        }));
      }
      // The {function}/role resolution source (Task 2.3): cap_db_instances LEFT
      // JOIN cap_databases. Emulate the LEFT JOIN in JS — an instance with no
      // resolvable database still returns a row (nulls for the joined columns).
      // instanceId/instanceOrderIndex (U4, Q7 db_seq source): default
      // to the fixture's own array position when a case does not care to set
      // them explicitly — fixture order already IS this query's intended
      // (order_index, id) order in every existing case in this file.
      if (/FROM `fmb_cap_db_instances` di/.test(sql) && /LEFT JOIN `fmb_cap_databases` d/.test(sql)) {
        return state.dbInstances.map((inst, idx) => {
          const db = state.databases.find((d) => d.id === inst.database_id) || null;
          return {
            instanceId: inst.id ?? `di-${idx}`,
            vmId: inst.vm_id,
            instanceName: inst.name, // PR-3 contents pill name (absent in these fixtures)
            role: inst.role,
            instanceOrderIndex: inst.order_index ?? idx,
            functionName: db ? db.function_name : null,
            dbOrderIndex: db ? db.order_index : null,
            dbId: db ? db.id : null,
          };
        });
      }
      if (/^UPDATE `fmb_cap_\w+` SET name = \? WHERE id = \? AND scenario_id = \?/.test(sql)) {
        return { affectedRows: 1 };
      }
      return [];
    },
  };
}

const conn = makeConn();
const poolFacade = {
  getConnection: async () => conn,
  query: (sql, params) => conn.query(sql, params),
};
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: { ro: poolFacade, rw: poolFacade }, t: (n) => `fmb_${n}` },
};

const router = require('../../../../src/edge/routes/app/capacity');
const { _resetColumnSetCache } = require('../../../../src/edge/routes/app/capacity/_shared');
// Same resolved module renumber.js already loaded (via the aggregate router
// above) — the cached export carries the test-only shape-assertion hook.
const renumberRouter = require('../../../../src/edge/routes/app/capacity/renumber');

let currentUser; let server; let baseUrl;
before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { req.user = currentUser; next(); });
  app.use('/capacity', router);
  server = http.createServer(app);
  await new Promise((r) => server.listen(0, r));
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});
after(() => server && server.close());
beforeEach(() => {
  state = freshState();
  currentUser = { id: 'u-admin', role: 'admin' };
  _resetColumnSetCache();
});

function request(method, path, body) {
  return new Promise((resolve, reject) => {
    const payload = body === undefined ? '' : JSON.stringify(body);
    const r = http.request(
      `${baseUrl}${path}`,
      { method, headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) } },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          const raw = Buffer.concat(chunks).toString('utf8');
          let json = null;
          try { json = JSON.parse(raw); } catch { /* noop */ }
          resolve({ status: res.statusCode, json, raw });
        });
      },
    );
    r.on('error', reject);
    if (payload) r.write(payload);
    r.end();
  });
}

const PREVIEW = '/capacity/scenarios/scn-1/renumber-preview';
const APPLY = '/capacity/scenarios/scn-1/renumber';

describe('renumber {function} resolution + role pattern (cap-pattern-function D2/D7)', () => {
  it('a host with instances of two DBs picks the FIRST by display order (order_index), not insertion order', async () => {
    state.vms = [{ id: 'k1', name: 'old-k1', order_index: 0, site_id: 's1', vm_type: 'db_host', name_locked: 0 }];
    state.databases = [
      { id: 'db-crm', function_name: 'crm', order_index: 2 },
      { id: 'db-erp', function_name: 'erp', order_index: 1 },
    ];
    state.dbInstances = [
      { vm_id: 'k1', role: 'primary', database_id: 'db-crm' },
      { vm_id: 'k1', role: 'primary', database_id: 'db-erp' },
    ];
    const res = await request('POST', PREVIEW, {});
    assert.equal(res.status, 200, res.raw);
    const k1 = res.json.data.rows.find((p) => p.id === 'k1');
    assert.equal(k1.newName, 'erp-01'); // erp (order_index 1) wins over crm (order_index 2)
  });

  it('a host with ONLY standby instances uses the standby pattern (stdby-style, unaffected by {function})', async () => {
    state.vms = [{ id: 'k1', name: 'old-k1', order_index: 0, site_id: 's1', vm_type: 'db_host', name_locked: 0 }];
    state.databases = [{ id: 'db-fin', function_name: 'fin', order_index: 0 }];
    state.dbInstances = [{ vm_id: 'k1', role: 'standby', database_id: 'db-fin' }];
    const res = await request('POST', PREVIEW, {});
    const k1 = res.json.data.rows.find((p) => p.id === 'k1');
    assert.equal(k1.newName, 'stdby-01');
  });

  it('a host with at least one primary instance uses the primary pattern, even if it also has a standby', async () => {
    state.vms = [{ id: 'k1', name: 'old-k1', order_index: 0, site_id: 's1', vm_type: 'db_host', name_locked: 0 }];
    state.databases = [{ id: 'db-hrm', function_name: 'hrm', order_index: 0 }];
    state.dbInstances = [
      { vm_id: 'k1', role: 'standby', database_id: 'db-hrm' },
      { vm_id: 'k1', role: 'primary', database_id: 'db-hrm' },
    ];
    const res = await request('POST', PREVIEW, {});
    const k1 = res.json.data.rows.find((p) => p.id === 'k1');
    assert.equal(k1.newName, 'hrm-01');
  });

  it('an empty db_host (no instances at all) uses the primary pattern, {function} falls back to kvm (D7)', async () => {
    state.vms = [{ id: 'k1', name: 'old-k1', order_index: 0, site_id: 's1', vm_type: 'db_host', name_locked: 0 }];
    // No dbInstances rows reference k1.
    const res = await request('POST', PREVIEW, {});
    const k1 = res.json.data.rows.find((p) => p.id === 'k1');
    assert.equal(k1.newName, 'kvm-01');
  });

  it('primary and standby hosts form INDEPENDENT seq streams, reassembled into original display order', async () => {
    state.vms = [
      { id: 'k1', name: 'old-k1', order_index: 0, site_id: 's1', vm_type: 'db_host', name_locked: 0 }, // primary
      { id: 'k2', name: 'old-k2', order_index: 1, site_id: 's1', vm_type: 'db_host', name_locked: 0 }, // standby
      { id: 'k3', name: 'old-k3', order_index: 2, site_id: 's1', vm_type: 'db_host', name_locked: 0 }, // primary (empty, fallback)
    ];
    state.databases = [{ id: 'db-erp', function_name: 'erp', order_index: 0 }];
    state.dbInstances = [
      { vm_id: 'k1', role: 'primary', database_id: 'db-erp' },
      { vm_id: 'k2', role: 'standby', database_id: 'db-erp' },
    ];
    const res = await request('POST', PREVIEW, {});
    assert.equal(res.status, 200, res.raw);
    const byId = Object.fromEntries(res.json.data.rows.map((p) => [p.id, p]));
    // U4 (Q7): k1's db_seq is its OWN real instance number (1, sole
    // member of the db-erp/primary group) — {db_seq} wins over the group's
    // {seq} counter, so the pattern-key primary/standby split still holds but
    // the digit is instance-derived, not a position-in-group count. k2 uses
    // the standby default (2026-08-22: plain {seq}, group-wide across standby
    // hosts, not {db_seq}) — sole standby-typed host in this plan → 1.
    assert.equal(byId.k1.newName, 'erp-01'); // real db_seq (its own db-erp/primary rank)
    assert.equal(byId.k2.newName, 'stdby-01'); // sole standby-typed host (group-wide {seq})
    assert.equal(byId.k3.newName, 'kvm-02'); // empty host — falls back to its group's seq (2nd primary-group member)
    // Original display order preserved in the response (k1, k2, k3 — not
    // primary-group-then-standby-group).
    assert.deepEqual(res.json.data.rows.filter((p) => p.entityType === 'kvm_host').map((p) => p.id), ['k1', 'k2', 'k3']);
  });

  it('an ap_vm with function_name set resolves {function} from its own cap_vms.function_name (ap-vm-function PR-2)', async () => {
    state.vms = [{ id: 'a1', name: 'old-a1', order_index: 0, site_id: null, vm_type: 'ap_host', name_locked: 0, function_name: 'erp' }];
    const res = await request('POST', PREVIEW, {});
    const a1 = res.json.data.rows.find((p) => p.id === 'a1');
    assert.equal(a1.newName, 'erp-01');
  });

  it('an ap_vm with an empty function_name falls back to ap (ap-vm-function PR-2)', async () => {
    state.vms = [{ id: 'a1', name: 'old-a1', order_index: 0, site_id: null, vm_type: 'ap_host', name_locked: 0, function_name: '' }];
    const res = await request('POST', PREVIEW, {});
    const a1 = res.json.data.rows.find((p) => p.id === 'a1');
    assert.equal(a1.newName, 'ap-01');
  });

  it('an ap_vm with no function_name column value (NULL) falls back to ap', async () => {
    state.vms = [{ id: 'a1', name: 'old-a1', order_index: 0, site_id: null, vm_type: 'ap_host', name_locked: 0, function_name: null }];
    const res = await request('POST', PREVIEW, {});
    const a1 = res.json.data.rows.find((p) => p.id === 'a1');
    assert.equal(a1.newName, 'ap-01');
  });

  it('apply recomputes {function}/role the same way as preview and writes the resolved names', async () => {
    state.vms = [{ id: 'k1', name: 'old-k1', order_index: 0, site_id: 's1', vm_type: 'db_host', name_locked: 0 }];
    state.databases = [{ id: 'db-erp', function_name: 'erp', order_index: 0 }];
    state.dbInstances = [{ vm_id: 'k1', role: 'primary', database_id: 'db-erp' }];
    const res = await request('POST', APPLY, {});
    assert.equal(res.status, 200, res.raw);
    const renamed = res.json.data.renamed.find((r) => r.id === 'k1');
    assert.equal(renamed.newName, 'erp-01');
  });

  // H1/P1b/P1a below pin the reservedSeed cross-role-group collision-avoidance
  // MECHANISM itself (H1's doc, name-patterns.js) — a general property of
  // computeRenumberPlan, independent of which pattern shape a scenario uses.
  // U4 (Q5-Q7) intentionally decouples the KVM entity types' BUILT-IN
  // defaults from {dc}/{seq} (dropping both in favor of {db_seq}), so these
  // three tests set an EXPLICIT legacy-shaped global override to keep
  // exercising that mechanism unaffected by the default swap — see the U4
  // combination-table tests below for what a REAL db_seq-based collision now
  // does (blessed by the brief: "collision risk shifts to the renumber
  // duplicate check").
  const LEGACY_DC_SEQ_PATTERNS = {
    kvm_host_primary: '{function}-{dc}-{seq:2}', kvm_host_standby: 'kvm-{dc}-{seq:2}',
  };

  it('H1: an empty (primary-fallback) host and a standby-only host at the SAME dc never collide, deterministic regardless of row order', async () => {
    // Under the legacy {dc}/{seq} shape BOTH groups fall back to the identical
    // literal "kvm-{dc}-{seq:2}" for their first member: the empty primary
    // host has no {function} to resolve (D7 fallback = kvm), and
    // kvm_host_standby is kvm-style regardless of {function}. Two independent
    // computeRenumberPlan calls, each starting its own seq at 1, would both
    // propose "kvm-dc-01".
    state.globalPatterns = LEGACY_DC_SEQ_PATTERNS;
    state.vms = [
      { id: 'k1', name: 'old-k1', order_index: 0, site_id: 's1', vm_type: 'db_host', name_locked: 0 }, // empty -> primary fallback
      { id: 'k2', name: 'old-k2', order_index: 1, site_id: 's1', vm_type: 'db_host', name_locked: 0 }, // standby-only
    ];
    state.databases = [{ id: 'db-fin', function_name: 'fin', order_index: 0 }];
    state.dbInstances = [{ vm_id: 'k2', role: 'standby', database_id: 'db-fin' }];
    const preview = await request('POST', PREVIEW, {});
    assert.equal(preview.status, 200, preview.raw);
    const byId = Object.fromEntries(preview.json.data.rows.map((p) => [p.id, p]));
    // Primary group is resolved first regardless of row order (deterministic).
    assert.equal(byId.k1.newName, 'kvm-dc-01');
    assert.equal(byId.k2.newName, 'kvm-dc-02');
    assert.equal(byId.k1.duplicate, false);
    assert.equal(byId.k2.duplicate, false);

    const apply = await request('POST', APPLY, {});
    assert.equal(apply.status, 200, apply.raw); // no 409 — apply succeeds, not blocked
    assert.equal(apply.json.data.applied, 2);
  });

  it('P1b (Codex r1): a LOCKED standby host is reserved for the PRIMARY group too, even though primary runs first with no seed', async () => {
    // k2 (standby) holds the locked name the primary group would otherwise
    // fall back to first (kvm-dc-01). k1 (empty -> primary fallback) must skip
    // it, not collide with it.
    state.globalPatterns = LEGACY_DC_SEQ_PATTERNS;
    state.vms = [
      { id: 'k1', name: 'old-k1', order_index: 0, site_id: 's1', vm_type: 'db_host', name_locked: 0 }, // empty -> primary fallback
      { id: 'k2', name: 'kvm-dc-01', order_index: 1, site_id: 's1', vm_type: 'db_host', name_locked: 1 }, // locked standby
    ];
    state.databases = [{ id: 'db-fin', function_name: 'fin', order_index: 0 }];
    state.dbInstances = [{ vm_id: 'k2', role: 'standby', database_id: 'db-fin' }];
    const preview = await request('POST', PREVIEW, {});
    assert.equal(preview.status, 200, preview.raw);
    const byId = Object.fromEntries(preview.json.data.rows.map((p) => [p.id, p]));
    assert.equal(byId.k1.newName, 'kvm-dc-02'); // skips the locked standby's name
    assert.equal(byId.k2.newName, 'kvm-dc-01'); // locked, unchanged
    assert.equal(byId.k1.duplicate, false);
    assert.equal(byId.k2.duplicate, false);

    const apply = await request('POST', APPLY, {});
    assert.equal(apply.status, 200, apply.raw); // no 409
    assert.equal(apply.json.data.applied, 1); // only k1 renumbers; k2 is locked
  });

  it('P1a (Codex r1): 3 empty primary hosts (kvm-dc-01..03 fallback) push a same-dc standby host to kvm-dc-04, not a duplicate', async () => {
    state.globalPatterns = LEGACY_DC_SEQ_PATTERNS;
    state.vms = [
      { id: 'k1', name: 'old-k1', order_index: 0, site_id: 's1', vm_type: 'db_host', name_locked: 0 }, // empty -> primary
      { id: 'k2', name: 'old-k2', order_index: 1, site_id: 's1', vm_type: 'db_host', name_locked: 0 }, // empty -> primary
      { id: 'k3', name: 'old-k3', order_index: 2, site_id: 's1', vm_type: 'db_host', name_locked: 0 }, // empty -> primary
      { id: 'k4', name: 'old-k4', order_index: 3, site_id: 's1', vm_type: 'db_host', name_locked: 0 }, // standby
    ];
    state.databases = [{ id: 'db-fin', function_name: 'fin', order_index: 0 }];
    state.dbInstances = [{ vm_id: 'k4', role: 'standby', database_id: 'db-fin' }];
    const preview = await request('POST', PREVIEW, {});
    assert.equal(preview.status, 200, preview.raw);
    const byId = Object.fromEntries(preview.json.data.rows.map((p) => [p.id, p]));
    assert.equal(byId.k1.newName, 'kvm-dc-01');
    assert.equal(byId.k2.newName, 'kvm-dc-02');
    assert.equal(byId.k3.newName, 'kvm-dc-03');
    assert.equal(byId.k4.newName, 'kvm-dc-04'); // standby group's own seq, past the 3 seeded names
    assert.equal(byId.k4.duplicate, false);

    const apply = await request('POST', APPLY, {});
    assert.equal(apply.status, 200, apply.raw); // no 409
    assert.equal(apply.json.data.applied, 4);
  });

  it('an instance whose database_id is dangling/null still counts toward role, just not toward {function}', async () => {
    state.vms = [{ id: 'k1', name: 'old-k1', order_index: 0, site_id: 's1', vm_type: 'db_host', name_locked: 0 }];
    state.dbInstances = [{ vm_id: 'k1', role: 'primary', database_id: null }]; // no matching database row
    const res = await request('POST', PREVIEW, {});
    const k1 = res.json.data.rows.find((p) => p.id === 'k1');
    // Still primary (an instance exists), function falls back since no database
    // resolved — and db_seq falls back too (a dangling instance has no
    // resolvable clusterIndex, U4 Q7), all the way to {seq}.
    assert.equal(k1.newName, 'kvm-01');
  });
});

// U4 (Q5-Q7): {db_seq}/{ap_seq} threaded through the renumber path —
// a combination table over primary/standby/pure-empty/multi-instance-cluster,
// not just the one blessed path.
describe('U4: {db_seq}/{ap_seq} renumber combination table (fmb-1827 Q5-Q7)', () => {
  it('a primary host with 2 instances of the SAME database ranks db_seq by (order_index, id), not row count', async () => {
    state.vms = [
      { id: 'k1', name: 'old-k1', order_index: 0, site_id: 's1', vm_type: 'db_host', name_locked: 0 },
      { id: 'k2', name: 'old-k2', order_index: 1, site_id: 's1', vm_type: 'db_host', name_locked: 0 },
    ];
    state.databases = [{ id: 'db-rac', function_name: 'rac', order_index: 0 }];
    // Two nodes of the SAME rac database, on DIFFERENT hosts — clusterIndex is
    // scenario-wide, not per-host (computeInstanceClusterIndexes' own doc).
    state.dbInstances = [
      { id: 'i1', vm_id: 'k1', role: 'primary', database_id: 'db-rac', order_index: 0 },
      { id: 'i2', vm_id: 'k2', role: 'primary', database_id: 'db-rac', order_index: 1 },
    ];
    const res = await request('POST', PREVIEW, {});
    assert.equal(res.status, 200, res.raw);
    const byId = Object.fromEntries(res.json.data.rows.map((p) => [p.id, p]));
    assert.equal(byId.k1.newName, 'rac-01');
    assert.equal(byId.k2.newName, 'rac-02');
  });

  it('a standby host takes its OWN standby instance number, independent of the primary side\'s numbering (Q7)', async () => {
    state.vms = [
      { id: 'k1', name: 'old-k1', order_index: 0, site_id: 's1', vm_type: 'db_host', name_locked: 0 }, // primary node 1
      { id: 'k2', name: 'old-k2', order_index: 1, site_id: 's1', vm_type: 'db_host', name_locked: 0 }, // primary node 2
      { id: 'k3', name: 'old-k3', order_index: 2, site_id: 's1', vm_type: 'db_host', name_locked: 0 }, // standby node 1 (its OWN rank)
    ];
    state.databases = [{ id: 'db-rac', function_name: 'rac', order_index: 0 }];
    state.dbInstances = [
      { id: 'i1', vm_id: 'k1', role: 'primary', database_id: 'db-rac', order_index: 0 },
      { id: 'i2', vm_id: 'k2', role: 'primary', database_id: 'db-rac', order_index: 1 },
      { id: 'i3', vm_id: 'k3', role: 'standby', database_id: 'db-rac', order_index: 2 },
    ];
    const res = await request('POST', PREVIEW, {});
    assert.equal(res.status, 200, res.raw);
    const byId = Object.fromEntries(res.json.data.rows.map((p) => [p.id, p]));
    assert.equal(byId.k1.newName, 'rac-01');
    assert.equal(byId.k2.newName, 'rac-02');
    // k3 ranks 1 as the sole standby-typed host in this plan — kvm_host_standby
    // is 'stdby-{seq:2}', a group-wide running serial across standby hosts
    // (function- and db_seq-free), not the primary side's row count.
    assert.equal(byId.k3.newName, 'stdby-01');
  });

  it('a host whose smallest instance is orphaned (no owning database) has no db_seq, falls to {seq}', async () => {
    state.vms = [{ id: 'k1', name: 'old-k1', order_index: 0, site_id: 's1', vm_type: 'db_host', name_locked: 0 }];
    // The (order_index,id)-smallest instance on k1 is orphaned (order_index 1);
    // a SECOND, resolvable instance ('real') exists on k1 and must NOT be
    // substituted in. 'i0' — on a PHANTOM host id ('k9') that owns no cap_vms
    // row, so it never enters the renumber plan itself and cannot consume a
    // {seq} slot — shares real's (database_id, role) group with an EARLIER
    // order_index, so real's OWN clusterIndex is 2, not 1. That is what makes
    // first-row-wins (correct: falls to k1's own {seq} counter, sole member of
    // its group → 1) and last-row-wins (bug: leaks real's clusterIndex → 2)
    // render DIFFERENT digits instead of coincidentally agreeing on 1.
    state.dbInstances = [
      { id: 'i0', vm_id: 'k9', role: 'primary', database_id: 'db-fin', order_index: 0 },
      { id: 'orphan', vm_id: 'k1', role: 'primary', database_id: null, order_index: 1 },
      { id: 'real', vm_id: 'k1', role: 'primary', database_id: 'db-fin', order_index: 2 },
    ];
    state.databases = [{ id: 'db-fin', function_name: 'fin', order_index: 0 }];
    const res = await request('POST', PREVIEW, {});
    assert.equal(res.status, 200, res.raw);
    const k1 = res.json.data.rows.find((p) => p.id === 'k1');
    // function resolves off the joined database (fin), db_seq falls to k1's own
    // {seq} (sole primary-group member in the plan → 1) since the SMALLEST
    // instance is orphaned; real's own clusterIndex (2) must NOT leak in.
    assert.equal(k1.newName, 'fin-01');
  });

  // U4 default collision story (2026-08-22 decision): kvm_host_primary keeps
  // {function}-{db_seq:2}, so its uniqueness rests on function+rank, NOT a
  // group-wide serial — two databases sharing a function_name each rank #1
  // within their OWN (database, role) group and collide on the SAME name.
  // Accepted: surfaced by the duplicate check, not prevented by the pattern.
  it('two primary hosts on same-function-name DIFFERENT databases collide and flag duplicate:true', async () => {
    state.vms = [
      { id: 'k1', name: 'old-k1', order_index: 0, site_id: 's1', vm_type: 'db_host', name_locked: 0 },
      { id: 'k2', name: 'old-k2', order_index: 1, site_id: 's1', vm_type: 'db_host', name_locked: 0 },
    ];
    state.databases = [
      { id: 'db-crm-a', function_name: 'crm', order_index: 0 },
      { id: 'db-crm-b', function_name: 'crm', order_index: 1 },
    ];
    state.dbInstances = [
      { id: 'i1', vm_id: 'k1', role: 'primary', database_id: 'db-crm-a', order_index: 0 },
      { id: 'i2', vm_id: 'k2', role: 'primary', database_id: 'db-crm-b', order_index: 1 },
    ];
    const res = await request('POST', PREVIEW, {});
    assert.equal(res.status, 200, res.raw);
    const byId = Object.fromEntries(res.json.data.rows.map((p) => [p.id, p]));
    assert.equal(byId.k1.newName, 'crm-01');
    assert.equal(byId.k2.newName, 'crm-01');
    assert.equal(byId.k1.duplicate, true);
    assert.equal(byId.k2.duplicate, true);
  });
});

describe('RENUMBER_TABLES entity shape (L3)', () => {
  it('accepts an entity with roleAware:true and no patternKey', () => {
    assert.doesNotThrow(() => renumberRouter._assertRenumberEntitiesShape([
      { entities: [{ entityType: 'kvm_host', roleAware: true }] },
    ]));
  });
  it('accepts an entity with a string patternKey and no roleAware', () => {
    assert.doesNotThrow(() => renumberRouter._assertRenumberEntitiesShape([
      { entities: [{ entityType: 'ap_vm', patternKey: 'ap_vm' }] },
    ]));
  });
  it('rejects an entity with NEITHER roleAware nor patternKey (the undefined-name hazard)', () => {
    assert.throws(() => renumberRouter._assertRenumberEntitiesShape([
      { entities: [{ entityType: 'future_entity' }] },
    ]), /future_entity/);
  });
  it('rejects an entity with BOTH roleAware:true and a patternKey (ambiguous)', () => {
    assert.throws(() => renumberRouter._assertRenumberEntitiesShape([
      { entities: [{ entityType: 'ambiguous', roleAware: true, patternKey: 'x' }] },
    ]), /ambiguous/);
  });
  it('the real RENUMBER_TABLES already passed this assertion at module load (no throw)', () => {
    // If it hadn't, requiring renumber.js above would already have thrown.
    assert.ok(renumberRouter, 'module loaded');
  });
});
