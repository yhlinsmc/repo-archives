/**
 * capacity-database-function-name-charset-schema-parity.test.js — validates the
 * columns the grandfather lookup names against the ACTUAL cap_databases
 * DDL, WITHOUT a live DB. Two call sites issue the identical statement (the
 * generic child mount's in-tx guard, `_shared.js` makeDatabaseFunctionNameGuard;
 * and the Add-Database wizard's own transactional endpoint,
 * `database-bulk-create.js` checkDatabaseFunctionNameCharset) — both mocked
 * route-test runners stub the query result, so a wrong column name here would
 * stay green in every test yet 500 the write it is meant to gate. This test
 * reads the statement TEXT out of each source file (never a hand-copied list)
 * and asserts the columns it names exist on cap_databases.
 */
const { describe, it, before } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

// _shared.js / database-bulk-create.js destructure { t } from ../../../db at
// load (never call it at load time); stub the db module so the require chain
// is side-effect-free (no pool).
const dbKey = require.resolve('../../../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: {}, t: (n) => n },
};

const { buildEngineTableDDLs } = require('../../../../src/table-ddls');

const SQL_TYPES = /^`?([a-z_]+)`?\s+(?:CHAR|VARCHAR|INT|DOUBLE|TIMESTAMP|JSON|TEXT|ENUM|BOOLEAN|TINYINT|BIGINT|DATETIME|DECIMAL|FLOAT|BLOB)\b/i;
let columnsByTable;

before(() => {
  columnsByTable = new Map();
  for (const ddl of buildEngineTableDDLs((n) => n)) {
    const m = ddl.match(/CREATE TABLE IF NOT EXISTS `([^`]+)`/);
    if (!m) continue;
    const cols = new Set();
    for (const rawLine of ddl.split('\n')) {
      const line = rawLine.trim();
      if (!line || line.startsWith('--') || line.startsWith('/*')) continue;
      const cm = line.match(SQL_TYPES);
      if (cm) cols.add(cm[1]);
    }
    columnsByTable.set(m[1], cols);
  }
});

// The exact statement text both call sites issue. Read out of the
// SOURCE, not hand-copied, so a rewrite of either statement is what this test
// checks, never a description of it that could quietly go stale.
const GRANDFATHER_SELECT = 'SELECT 1 FROM \\`${t(TABLES.CAP_DATABASES)}\\` WHERE scenario_id = ? AND function_name = ? LIMIT 1';

const SOURCES = {
  '_shared.js (generic child-mount guard)': path.resolve(__dirname, '../../../../src/edge/routes/app/capacity/_shared.js'),
  'database-bulk-create.js (Add-Database wizard endpoint)': path.resolve(__dirname, '../../../../src/edge/routes/app/capacity/database-bulk-create.js'),
};

describe('fmb-1705 database function_name charset grandfather lookup — schema parity', () => {
  it('every call site issues the SAME literal statement, sourced (not restated)', () => {
    for (const [label, file] of Object.entries(SOURCES)) {
      const src = fs.readFileSync(file, 'utf8');
      assert.ok(
        src.includes(GRANDFATHER_SELECT),
        `${label} (${file}) no longer issues the expected grandfather-lookup statement`,
      );
    }
  });

  it('cap_databases has both columns the lookup names', () => {
    const cols = columnsByTable.get('cap_databases');
    assert.ok(cols && cols.size > 0, 'no columns parsed for cap_databases');
    assert.ok(cols.has('scenario_id'), 'cap_databases is missing scenario_id — the lookup would 500');
    assert.ok(cols.has('function_name'), 'cap_databases is missing function_name — the lookup would 500');
  });
});
