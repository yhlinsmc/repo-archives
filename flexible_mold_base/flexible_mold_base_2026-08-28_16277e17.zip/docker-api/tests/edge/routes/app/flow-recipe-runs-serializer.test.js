// docker-api/tests/edge/routes/app/flow-recipe-runs-serializer.test.js
const { test } = require('node:test');
const assert = require('node:assert');
const { serializeWrite, maskDeep, keySegments, MAX_RUN_INPUT_SNAPSHOT_BYTES } = require('../../../../src/edge/routes/app/flow-recipe-runs/serializer');
const { parseInputSnapshot } = require('../../../../src/edge/lib/flow-run-input-snapshot');

test('maskDeep redacts secret-keyed leaves at any depth', () => {
  const out = maskDeep({ id: 1, token: 'abc', nested: { api_key: 'k', label: 'ok' }, list: [{ password: 'p' }] });
  assert.strictEqual(out.id, 1);
  assert.strictEqual(out.token, '****');
  assert.strictEqual(out.nested.api_key, '****');
  assert.strictEqual(out.nested.label, 'ok');
  assert.strictEqual(out.list[0].password, '****');
});

test('serializeWrite masks step_results object', async () => {
  const out = await serializeWrite({ actor_id: 'u1', step_results: [{ name: 's1', response: { authorization: 'Bearer x', flow_id: 9 } }] });
  assert.strictEqual(out.step_results[0].response.authorization, '****');
  assert.strictEqual(out.step_results[0].response.flow_id, 9);
});

test('serializeWrite masks JSON rendered_payload', async () => {
  const json = await serializeWrite({ rendered_payload: JSON.stringify({ name: 'wf', secret: 's' }) });
  assert.deepStrictEqual(JSON.parse(json.rendered_payload), { name: 'wf', secret: '****' });
});

test('serializeWrite masks YAML rendered_payload (secret not stored verbatim in the audit row)', async () => {
  const out = await serializeWrite({ rendered_payload: 'name: wf\nsecret: s\n' });
  const parsed = require('yaml').parse(out.rendered_payload);
  assert.strictEqual(parsed.name, 'wf');
  assert.strictEqual(parsed.secret, '****');
});

test('serializeWrite leaves an opaque (non-JSON, non-YAML-mapping) rendered_payload verbatim', async () => {
  const out = await serializeWrite({ rendered_payload: 'just a plain string' });
  assert.strictEqual(out.rendered_payload, 'just a plain string');
});

test('serializeWrite redacts secret inside JSON-encoded string body in step_results', async () => {
  const out = await serializeWrite({
    actor_id: 'u1',
    step_results: [{ name: 'step1', response: { body: '{"access_token":"sk-1","ok":true}' } }],
  });
  const parsedBody = JSON.parse(out.step_results[0].response.body);
  assert.strictEqual(parsedBody.access_token, '****');
  assert.strictEqual(parsedBody.ok, true);
});

test('serializeWrite masks JSON output_snapshot but leaves non-JSON as-is', async () => {
  const json = await serializeWrite({ output_snapshot: JSON.stringify({ field: 'value', api_key: 'sk-x' }) });
  assert.deepStrictEqual(JSON.parse(json.output_snapshot), { field: 'value', api_key: '****' });
  const plain = await serializeWrite({ output_snapshot: 'plain-text-snapshot' });
  assert.strictEqual(plain.output_snapshot, 'plain-text-snapshot');
});

test('maskDeep fail-closed: over-depth subtree returns mask sentinel not raw secret', () => {
  // Build an object nested MAX_DEPTH+2 levels deep with a secret at the bottom.
  // The subtree beyond depth 64 must come back as '****', not the raw value.
  let inner = { access_token: 'leak' };
  for (let i = 0; i < 66; i++) inner = { child: inner };
  const result = maskDeep(inner);
  // Walk down until we hit '****' — it must occur before we see the raw secret.
  let node = result;
  let sawMask = false;
  for (let i = 0; i < 70; i++) {
    if (node === '****') { sawMask = true; break; }
    if (typeof node !== 'object' || node === null) break;
    node = node.child;
  }
  assert.ok(sawMask, 'expected mask sentinel at depth cap, but walked past without hitting it');
});

test('maskDeep drops prototype-pollution keys at every level (defense-in-depth, mirrors deepJsonExpand)', () => {
  // Built via JSON.parse so __proto__/constructor/prototype are OWN enumerable
  // keys — exactly how a crafted upstream response body / error_summary arrives.
  const malicious = JSON.parse(
    '{"__proto__":{"polluted":"yes"},"constructor":{"c":1},"prototype":{"p":1},"safe":"ok","token":"sk"}',
  );
  const out = maskDeep(malicious);
  // __proto__ key must be dropped, not fed to out[k] (which would swap out's prototype).
  assert.strictEqual(out.polluted, undefined, '__proto__ must be dropped, not applied to the result prototype');
  assert.strictEqual(Object.prototype.hasOwnProperty.call(out, 'constructor'), false);
  assert.strictEqual(Object.prototype.hasOwnProperty.call(out, 'prototype'), false);
  // Global prototype must stay clean.
  assert.strictEqual({}.polluted, undefined, 'Object.prototype must not be polluted');
  // Non-dangerous keys still pass through; secrets still masked.
  assert.strictEqual(out.safe, 'ok');
  assert.strictEqual(out.token, '****');
});

test('maskDeep drops prototype-pollution keys inside a JSON-encoded string leaf', () => {
  // The step-body / error_summary path: a JSON-encoded string re-parsed by maskDeep.
  // Include constructor/prototype (not just __proto__): a bare __proto__ swaps the
  // object's [[Prototype]] and never survives the re-JSON.stringify, so it does not
  // discriminate on this path; constructor/prototype are plain own keys that DO
  // survive without the guard — they make this a genuine RED for the string leaf.
  const out = maskDeep({ body: '{"__proto__":{"polluted":"yes"},"constructor":{"c":1},"prototype":{"p":1},"api_key":"sk","ok":true}' });
  const parsed = JSON.parse(out.body);
  assert.strictEqual(parsed.polluted, undefined);
  assert.strictEqual(Object.prototype.hasOwnProperty.call(parsed, '__proto__'), false);
  assert.strictEqual(Object.prototype.hasOwnProperty.call(parsed, 'constructor'), false);
  assert.strictEqual(Object.prototype.hasOwnProperty.call(parsed, 'prototype'), false);
  assert.strictEqual({}.polluted, undefined, 'Object.prototype must not be polluted');
  assert.strictEqual(parsed.api_key, '****');
  assert.strictEqual(parsed.ok, true);
});

test('serializeWrite stamps actor_id from the authenticated user on create (admin path included)', async () => {
  // Admin POSTs without actor_id (generic write-scope stamp skips admins) — the
  // serializer must stamp it, otherwise the NOT NULL actor_id column rejects the insert.
  const out = await serializeWrite({ recipe_id: 'r1', status: 'partial' }, { isUpdate: false, req: { user: { id: 'admin-1' } } });
  assert.strictEqual(out.actor_id, 'admin-1');
});

test('serializeWrite does not stamp actor_id on update', async () => {
  const out = await serializeWrite({ status: 'success' }, { isUpdate: true, req: { user: { id: 'admin-1' } } });
  assert.strictEqual('actor_id' in out, false);
});

test('serializeWrite without ctx leaves actor_id untouched (back-compat)', async () => {
  const out = await serializeWrite({ actor_id: 'preset', status: 'partial' });
  assert.strictEqual(out.actor_id, 'preset');
});

// ── secret-key matching is by whole key SEGMENT, not by substring ────────────

test('a key whose ordinary English happens to contain a secret word is NOT masked', () => {
  // The exact list the review executed against the previous unanchored pattern,
  // which replaced six of these eight with the mask. `input_snapshot` is keyed by
  // blueprint field_key, authored by domain users, so these are the vocabulary —
  // and the loss was silent and permanent.
  const domainKeys = [
    'passenger_count', 'bypass_valve', 'pass_rate', 'passive_cooling',
    'tokenizer_mode', 'credentialing_body', 'total_passes', 'site_name',
    // The boundary the widening below is NOT allowed to cross. `passcode` and
    // `passkey` are masked as one segment, but split across a separator they
    // name a physical pass in this same vocabulary, so the pair rule
    // deliberately stops short of them.
    'boarding_pass_code', 'gate_pass_key', 'boarding_pass_count',
    // `pass` is the English word when another word FOLLOWS it: that word is the
    // head noun and it says what the value is — a rate, a count, a code — and
    // none of those is a password.
    'pass_rate', 'pass_count', 'first_pass_yield', 'total_pass_count',
    // The plural stays stored: a map of credentials is named after the term
    // (`api_keys`, `tokens`, `passwords`) and `passwords` is already masked, so
    // masking `passes` would buy nothing and cost an everyday English plural.
    'passes', 'boarding_passes', 'weld_passes',
  ];
  const out = maskDeep(Object.fromEntries(domainKeys.map((k) => [k, 'kept'])));
  for (const k of domainKeys) {
    assert.strictEqual(out[k], 'kept', `${k} must survive masking`);
  }
});

test('the secret-key spellings this codebase uses are all still masked', () => {
  const secretKeys = [
    'password', 'passwd', 'pass', 'secret', 'clientSecret', 'secret_key',
    'token', 'tokens', 'access_token', 'auth_token',
    'authorization', 'Authorization', 'bearer',
    'credential', 'credentials',
    'api_key', 'API_KEY', 'apiKey', 'api-key', 'apikey', 'APIKey', 'X-Api-Key', 'XApiKey',
    'private_key', 'privateKey', 'privatekey',
  ];
  const out = maskDeep(Object.fromEntries(secretKeys.map((k) => [k, 'sk-live-1'])));
  for (const k of secretKeys) {
    assert.strictEqual(out[k], '****', `${k} must still be masked`);
  }
});

// The whole-segment rule is a TIGHTENING, and a tightening's own failure mode is
// a genuine secret the loose pattern caught and the tight one drops. These two
// tests are the families that were dropped and are now caught again; each is a
// family rather than the examples that exposed it, because closing the named
// examples and not the family is how the matcher regressed the first time.

test('every spelling of the pass-prefixed credential vocabulary is masked', () => {
  // Masked by the old substring pattern via a bare `pass`, then silently stored
  // once matching became segment-based. A passphrase is the standard key name
  // for an SSH / PEM / PKCS#12 key's own secret — exactly what a domain author
  // would name a blueprint field `key_passphrase`.
  const keys = [
    'passphrase', 'passphrases', 'pass_phrase', 'pass-phrase', 'passPhrase',
    'PassPhrase', 'pass phrase', 'pass_phrases', 'key_passphrase', 'pem_passphrase',
    'sshPassphrase', 'SSHPassphrase', 'ssh_pass_phrase', 'keyPassphrase',
    'PEM_PASS_PHRASE', 'passphrase2', 'pass_phrase2',
    'passcode', 'passcodes', 'passkey', 'passkeys',
  ];
  const out = maskDeep(Object.fromEntries(keys.map((k) => [k, 'sk-live-1'])));
  for (const k of keys) assert.strictEqual(out[k], '****', `${k} must be masked`);
});

test('a counted credential is masked whether or not a separator precedes the digit', () => {
  // `keySegments` glued a trailing digit to its word, so `password2` segmented
  // as one unknown word and was stored while `password_2` was masked — an
  // outcome nobody authored, turning on punctuation. Paired live/backup
  // credential naming is a live pattern in this project.
  const keys = [
    'password2', 'password_2', 'token2', 'token_2', 'secret2', 'db_password1',
    'api_key2', 'apiKey2', 'apikey2', 'private_key2', 'passcode2',
    // ...and the mirror boundary, digit-then-letter.
    'v2token', 'v2_token', 's3_secret', 'x2_password', 'token2fa',
  ];
  const out = maskDeep(Object.fromEntries(keys.map((k) => [k, 'sk-live-1'])));
  for (const k of keys) assert.strictEqual(out[k], '****', `${k} must be masked`);
});

test('an unmodified `pass` is masked, whatever precedes it and however it is spelled', () => {
  // The fourth defect in this matcher's history. `pass` was a credential only as
  // the WHOLE key, so every `<something>_pass` — the standard abbreviation for a
  // password, and an entirely ordinary key in an upstream response body or an
  // outbound payload, neither of which this project names — was stored verbatim
  // on a durable, admin-readable row. The old substring pattern masked all of
  // these; this file's own "what it gives up" test did not name them, and the
  // generated corpus could not see them, because nothing in it ever put a word
  // NEXT TO a term.
  //
  // `unheard_of_pass` is here deliberately: the rule is positional, not a list
  // of the prefixes someone thought of, and a prefix list would pass every other
  // entry here and fail that one.
  const keys = [
    'pass', 'PASS', 'db_pass', 'user_pass', 'smtp_pass', 'sftp_pass', 'ftp_pass',
    'admin_pass', 'root_pass', 'mysql_pass', 'svc_pass', 'unheard_of_pass',
    'DB_PASS', 'db-pass', 'db.pass', 'db pass', 'dbPass', 'DbPass', 'myPass',
    // A counted credential is the same credential: a digit is not the word that
    // would make `pass` ordinary. This is the same rule the counted-credential
    // test below applies to `password2` / `token2`, and applying it to `pass`
    // REVERSES an earlier round, which stored `pass2` as "the second pass".
    'pass2', 'pass_2', '2_pass', 'db_pass2', 'db_pass_2', 'dbPass2',
  ];
  const out = maskDeep(Object.fromEntries(keys.map((k) => [k, 'sk-live-1'])));
  for (const k of keys) assert.strictEqual(out[k], '****', `${k} must be masked`);
});

test('what the unmodified-`pass` rule costs is listed here, not discovered later', () => {
  // The other direction, and the one no differential against the old pattern can
  // show: the old pattern masked these too, so they never appear in the corpus
  // residual. A `pass` with no word after it is read as a password even when it
  // names a physical pass or a machining pass. That is the deliberate price of
  // not having a hand-written list of credential prefixes, and it is pinned here
  // so that changing the rule has to come and change the sentence too.
  //
  // WHY THIS IS THE RIGHT WAY TO FAIL, and not a claim that the cost is zero:
  // by shape alone `db_pass` and `boarding_pass` are the same key, and a matcher
  // that reads names cannot separate them. Not masking loses a credential into a
  // durable row, permanently and invisibly; masking loses a domain value to
  // `****`, which is on the screen for someone to notice and report. The
  // `_count` / `_code` / `_key` / `_rate` forms of the same words survive — see
  // the domain-vocabulary test above — because there the following word is the
  // head of the compound. That is NOT a claim that a credential is never named
  // with something after `pass`: `db_pass_backup` is one and is stored. The
  // test below pins that half.
  //
  // These are invented names chosen to be ordinary, not names taken from
  // anywhere: what a key is called at runtime is authored by whoever uses the
  // system, so no snapshot of that could justify a rule meant to hold for names
  // nobody has written yet.
  const masked = [
    'boarding_pass', 'gate_pass', 'first_pass', 'second_pass', 'day_pass',
    // …and the counted spellings, which read as "the second pass" as readily as
    // "the second password".
    'pass2', '2_pass',
  ];
  const out = maskDeep(Object.fromEntries(masked.map((k) => [k, 'kept'])));
  for (const k of masked) {
    assert.strictEqual(out[k], '****',
      `${k} is documented as masked — if that changed, update the CHANGELOG and the module header`);
  }
});

test('a credential QUALIFIED after `pass` is documented as stored — the other half of that trade', () => {
  // The half that was missing. The cost test above pins the ordinary words this
  // rule started masking; nothing pinned the credentials it stops masking, so
  // the trade could move on one side only — which is how family 3's stated
  // reason came to cover a subclass it was false for.
  //
  // `pass` followed by a QUALIFIER rather than a head noun is still a password:
  // `db_pass_backup` is not "a pass that is a backup". It is stored anyway,
  // because nothing in the shape separates it from `pass_rate`, and the only two
  // fixes are a hand-written qualifier list — the completeness claim this module
  // refuses, having been broken by one twice — or masking on any following word,
  // which re-breaks `pass_rate` and reverses the retightening.
  const stored = [
    'db_pass_old', 'db_pass_new', 'db_pass_backup', 'smtp_pass_new',
    'db_pass_hash', 'db_pass_prod', 'db_pass_v2',
  ];
  const out = maskDeep(Object.fromEntries(stored.map((k) => [k, 'sk-live-1'])));
  for (const k of stored) {
    assert.strictEqual(out[k], 'sk-live-1',
      `${k} is documented as STORED — if that changed, update the CHANGELOG and the module header`);
  }
  // And the boundary this leaves behind, asserted so it is impossible to read
  // the loss as wider than it is: the same key spelled with the full word is
  // masked, so what is given up belongs to the abbreviation.
  const stillMasked = ['password_backup', 'db_password_old', 'db_passwd_backup'];
  const out2 = maskDeep(Object.fromEntries(stillMasked.map((k) => [k, 'sk-live-1'])));
  for (const k of stillMasked) {
    assert.strictEqual(out2[k], '****',
      `${k} is masked by the full word — the outcome turns on 'pass' versus 'password'`);
  }
});

test('a two-segment credential term is masked in the plural too', () => {
  // The pair list was hand-written in the singular while the single-word list
  // carried both numbers, so `api_keys` — an ordinary name for a map of
  // credentials — was stored. Plurals are generated from the pair list now.
  const keys = ['api_keys', 'apiKeys', 'X-Api-Keys', 'private_keys', 'privateKeys'];
  const out = maskDeep(Object.fromEntries(keys.map((k) => [k, 'sk-live-1'])));
  for (const k of keys) assert.strictEqual(out[k], '****', `${k} must be masked`);
});

test('the widened matcher reaches the two sibling columns as well', async () => {
  // The three columns share one matcher, so a spelling restored for
  // `input_snapshot` must be restored for the columns that carry upstream
  // response bodies too — that is where a vended credential actually echoes.
  const out = await serializeWrite({
    output_snapshot: JSON.stringify({ key_passphrase: 'sk-live-1', pass_rate: '0.98' }),
    step_results: { one: { body: { api_keys: { primary: 'sk-live-1' }, password2: 'sk-live-1' } } },
  });
  const snap = JSON.parse(out.output_snapshot);
  assert.strictEqual(snap.key_passphrase, '****');
  assert.strictEqual(snap.pass_rate, '0.98');
  assert.strictEqual(out.step_results.one.body.api_keys, '****');
  assert.strictEqual(out.step_results.one.body.password2, '****');
});

test('what whole-segment matching gives up is listed here, not discovered later', () => {
  // The CHANGELOG entry and the module header both state what this matcher
  // costs. The first draft of that text claimed it cost nothing — it said the
  // tightening kept "every genuine credential name it caught before", which was
  // false when it was written. Prose cannot be checked; this can. A later change
  // that starts catching these must come here and change the sentence too, and
  // nothing may claim the list is empty while it is not.
  const givenUp = ['mypassword', 'secretsmanager', 'apikeyv2'];
  const out = maskDeep(Object.fromEntries(givenUp.map((k) => [k, 'sk-live-1'])));
  for (const k of givenUp) {
    assert.strictEqual(out[k], 'sk-live-1',
      `${k} is documented as stored, not masked — if that changed, update the CHANGELOG and the module header`);
  }
});

test('segment splitting handles separators, camel case, acronym runs and digits', () => {
  assert.deepStrictEqual(keySegments('api_key'), ['api', 'key']);
  assert.deepStrictEqual(keySegments('apiKey'), ['api', 'key']);
  assert.deepStrictEqual(keySegments('XApiKey'), ['x', 'api', 'key']);
  assert.deepStrictEqual(keySegments('X-Api-Key'), ['x', 'api', 'key']);
  assert.deepStrictEqual(keySegments('total_passes'), ['total', 'passes']);
  assert.deepStrictEqual(keySegments('password2'), ['password', '2']);
  assert.deepStrictEqual(keySegments('v2token'), ['v', '2', 'token']);
});

// ── input_snapshot: a declared shape, then masking, then a size bound ────────

// Identity values are `blueprint_fields.id` / `hierarchy_nodes.id` — CHAR(36),
// UUID-defaulted — and the write boundary checks the shape, because that half of
// the document is stored unmasked. A readable stand-in that is still a UUID.
const id = (n) => `${String(n).padStart(8, '0')}-0000-4000-8000-000000000000`;
const FIELD_ID = { site_name: id(1), api_key: id(2), db_password1: id(3), total_kw: id(4), access_token: id(5) };
const BLUEPRINT_ID = id(90);

const snapshotDocObject = (over = {}) => ({
  entered: { site_name: 'north' },
  computed: {},
  fields: { site_name: FIELD_ID.site_name },
  blueprint_id: BLUEPRINT_ID,
  variant_id: null,
  ...over,
});
const snapshotDoc = (over = {}) => JSON.stringify(snapshotDocObject(over));

test('serializeWrite masks a secret-named field inside input_snapshot', async () => {
  const out = await serializeWrite({
    input_snapshot: snapshotDoc({
      entered: { site_name: 'north', api_key: 'sk-live-1' },
      computed: { total_kw: '4200' },
      fields: { site_name: FIELD_ID.site_name, api_key: FIELD_ID.api_key, total_kw: FIELD_ID.total_kw },
    }),
  });
  const parsed = JSON.parse(out.input_snapshot);
  assert.strictEqual(parsed.entered.site_name, 'north');
  assert.strictEqual(parsed.entered.api_key, '****');
  assert.strictEqual(parsed.computed.total_kw, '4200');
});

test('masking redacts the value maps and leaves the identity map alone', async () => {
  // The check that was missing. Masking ran over the whole document, so for a
  // field named `api_key` the stable field id became '****' — destroying, for
  // precisely the fields most worth auditing, the mechanism that distinguishes
  // "the same field, renamed" from "a different field wearing the old key".
  // Two reviews read that change without noticing, because every assertion
  // looked at `entered` and none looked at `fields`.
  const doc = snapshotDocObject({
    entered: { site_name: 'north', api_key: 'sk-live-1', db_password1: 'sk-live-2' },
    computed: { total_kw: '4200', access_token: 'sk-live-3' },
    fields: {
      site_name: FIELD_ID.site_name,
      api_key: FIELD_ID.api_key,
      db_password1: FIELD_ID.db_password1,
      total_kw: FIELD_ID.total_kw,
      access_token: FIELD_ID.access_token,
    },
  });
  const out = await serializeWrite({ input_snapshot: JSON.stringify(doc) });
  const stored = JSON.parse(out.input_snapshot);

  // Values: masked wherever the name says secret.
  assert.strictEqual(stored.entered.api_key, '****');
  assert.strictEqual(stored.entered.db_password1, '****');
  assert.strictEqual(stored.computed.access_token, '****');
  assert.strictEqual(stored.entered.site_name, 'north');
  assert.strictEqual(stored.computed.total_kw, '4200');

  // Identity: untouched, byte for byte, INCLUDING the secret-named keys. A field
  // id names a row, never its contents.
  assert.deepStrictEqual(stored.fields, doc.fields);
  assert.strictEqual(stored.blueprint_id, BLUEPRINT_ID);
  assert.strictEqual(stored.variant_id, null);
  // …and the document still carries exactly its five declared keys.
  assert.deepStrictEqual(Object.keys(stored),
    ['entered', 'computed', 'fields', 'blueprint_id', 'variant_id']);
});

test('the identity half may hold nothing but identifiers, which is what makes leaving it unmasked safe', async () => {
  // The hole the exemption above opened. `fields` was validated as "a map of
  // strings", so a caller could park a credential in it under an innocuous name
  // and this branch would deliberately store it unmasked, in a durable,
  // admin-readable row, from a create route open to any authenticated user. The
  // fix is not to start masking it again — that re-breaks the field ids — but to
  // bound the half to what it claims to hold.
  await assert.rejects(
    () => serializeWrite({ input_snapshot: snapshotDoc({ fields: { note: 'sk-live-SECRET' } }) }),
    (e) => {
      // A DISTINCT CODE from the document-shape refusals. The value is refused
      // either way and nothing unmasked reaches the column either way; the code
      // is what lets the dispatch path degrade instead of failing the run, since
      // the id shape is a convention every writer happens to keep rather than an
      // invariant anything enforces. The direct create route, which this call
      // is, still refuses — the snapshot is the whole request there, so there is
      // no dispatch to save.
      assert.strictEqual(e.code, 'INVALID_RUN_INPUT_SNAPSHOT_IDENTITY');
      assert.strictEqual(e.status, 400);
      assert.match(e.message, /the field reference for fields\.note must be an identifier/);
      // The refusal reaches an operator verbatim and is logged. It names the
      // entry, never the value it refused, or the refusal is its own leak.
      assert.doesNotMatch(e.message, /sk-live-SECRET/);
      return true;
    },
  );
  // A number is refused by the same check — the old one would have refused this
  // and accepted the string above, which is the wrong way round.
  await assert.rejects(
    () => serializeWrite({ input_snapshot: snapshotDoc({ fields: { site_name: 7 } }) }),
    (e) => { assert.strictEqual(e.code, 'INVALID_RUN_INPUT_SNAPSHOT_IDENTITY'); return true; },
  );
  // …but a `fields` that is not a map at all is a malformed DOCUMENT, not an
  // unrecognised id, and keeps the undegradable code. The two must not collapse
  // into one: the degrade path is justified by the id shape being a convention,
  // and that argument says nothing about a document of the wrong shape.
  await assert.rejects(
    () => serializeWrite({ input_snapshot: snapshotDoc({ fields: 'not a map' }) }),
    (e) => { assert.strictEqual(e.code, 'INVALID_RUN_INPUT_SNAPSHOT'); return true; },
  );
});

test('the two scope ids are identifiers or nothing, for the same reason', async () => {
  // blueprint_id and variant_id travel unmasked beside `fields`, so 'any string'
  // left two more unmasked slots on the same row. Null still means "no
  // blueprint / no variant was selected" and is untouched.
  for (const over of [{ blueprint_id: 'sk-live-SECRET' }, { variant_id: 'sk-live-SECRET' }]) {
    await assert.rejects(
      () => serializeWrite({ input_snapshot: snapshotDoc(over) }),
      (e) => {
        // Same distinct code as the `fields` half — one identity rule, one
        // degrade decision, so the dispatch path cannot treat the two halves
        // differently by accident.
        assert.strictEqual(e.code, 'INVALID_RUN_INPUT_SNAPSHOT_IDENTITY');
        assert.match(e.message, /must be an identifier or empty/);
        assert.doesNotMatch(e.message, /sk-live-SECRET/);
        return true;
      },
    );
  }
  const out = await serializeWrite({ input_snapshot: snapshotDoc({ blueprint_id: null, variant_id: null }) });
  const stored = JSON.parse(out.input_snapshot);
  assert.strictEqual(stored.blueprint_id, null);
  assert.strictEqual(stored.variant_id, null);
});

// CHANGED BEHAVIOUR: this column used to store an unparseable value verbatim,
// exactly as its two siblings still do. It refuses now — the masking guarantee
// held only for the one shape a cooperative client sends, and the create route
// it also serves is open to any authenticated user.
test('serializeWrite refuses a non-JSON input_snapshot instead of storing it verbatim', async () => {
  await assert.rejects(
    () => serializeWrite({ input_snapshot: 'api_key=sk-live-1, site=north' }),
    (err) => {
      assert.strictEqual(err.code, 'INVALID_RUN_INPUT_SNAPSHOT');
      assert.strictEqual(err.status, 400);
      return true;
    },
  );
});

test('serializeWrite refuses an input_snapshot sent as an object, which would skip masking entirely', async () => {
  // The reviewer's live exploit: nothing downstream stringifies this column, so
  // a plain object was serialised by the driver on the wire with the secret
  // intact and the size bound never run.
  await assert.rejects(
    () => serializeWrite({ input_snapshot: { entered: { api_key: 'sk-live-SECRET' }, computed: {} } }),
    (err) => {
      assert.strictEqual(err.code, 'INVALID_RUN_INPUT_SNAPSHOT');
      assert.strictEqual(err.status, 400);
      return true;
    },
  );
});

test('serializeWrite refuses a document missing a declared key, or carrying an undeclared one', async () => {
  const missing = JSON.stringify({ entered: {}, computed: {} });
  await assert.rejects(() => serializeWrite({ input_snapshot: missing }), (e) => {
    assert.strictEqual(e.code, 'INVALID_RUN_INPUT_SNAPSHOT');
    assert.match(e.message, /incomplete, missing: fields, blueprint_id, variant_id/);
    return true;
  });
  await assert.rejects(
    () => serializeWrite({ input_snapshot: snapshotDoc({ surprise: 1 }) }),
    (e) => {
      assert.strictEqual(e.code, 'INVALID_RUN_INPUT_SNAPSHOT');
      assert.match(e.message, /unrecognised entries: surprise/);
      return true;
    },
  );
});

test('serializeWrite refuses a half whose values are not strings', async () => {
  await assert.rejects(
    () => serializeWrite({ input_snapshot: snapshotDoc({ entered: { n: 12 } }) }),
    (e) => { assert.strictEqual(e.code, 'INVALID_RUN_INPUT_SNAPSHOT'); return true; },
  );
});

test('serializeWrite accepts a stated non-capture, and only for a reason a client may state', async () => {
  const out = await serializeWrite({ input_snapshot: JSON.stringify({ not_captured: 'outputs_stale' }) });
  assert.deepStrictEqual(JSON.parse(out.input_snapshot), { not_captured: 'outputs_stale' });

  // 'too_large' is the server's to write, never a client's to claim.
  await assert.rejects(
    () => serializeWrite({ input_snapshot: JSON.stringify({ not_captured: 'too_large' }) }),
    (e) => { assert.strictEqual(e.code, 'INVALID_RUN_INPUT_SNAPSHOT'); return true; },
  );
  // …and it may not be smuggled alongside a capture.
  await assert.rejects(
    () => serializeWrite({ input_snapshot: snapshotDoc({ not_captured: 'outputs_stale' }) }),
    (e) => { assert.strictEqual(e.code, 'INVALID_RUN_INPUT_SNAPSHOT'); return true; },
  );
});

test('serializeWrite refuses an oversized input_snapshot rather than truncating it', async () => {
  const oversized = snapshotDoc({
    entered: { notes: 'x'.repeat(MAX_RUN_INPUT_SNAPSHOT_BYTES + 1) },
  });
  await assert.rejects(
    () => serializeWrite({ input_snapshot: oversized }),
    (err) => {
      assert.strictEqual(err.code, 'RUN_INPUT_SNAPSHOT_TOO_LARGE');
      assert.strictEqual(err.status, 413);
      // The operator is told a size, not a schema: no column name in the text.
      assert.match(err.message, /the entered values are \d+ bytes; the limit is \d+ bytes/);
      assert.doesNotMatch(err.message, /input_snapshot/);
      // The numbers ride on the error so a caller that degrades instead of
      // refusing can restate them without parsing the sentence.
      assert.strictEqual(typeof err.bytes, 'number');
      assert.strictEqual(err.limit, MAX_RUN_INPUT_SNAPSHOT_BYTES);
      return true;
    },
  );
});

test('the size bound is applied to the masked bytes, not the bytes that arrived', async () => {
  // Built to exceed the limit BEFORE masking and to sit under it after, so the
  // two measurements disagree and only the post-mask one lets this through.
  const secret = 'y'.repeat(MAX_RUN_INPUT_SNAPSHOT_BYTES);
  const doc = snapshotDoc({ entered: { site_name: 'north', access_token: secret } });
  const arrivedBytes = Buffer.byteLength(doc, 'utf8');
  assert.ok(arrivedBytes > MAX_RUN_INPUT_SNAPSHOT_BYTES,
    'fixture must arrive oversized, or this proves nothing');

  const out = await serializeWrite({ input_snapshot: doc });

  const storedBytes = Buffer.byteLength(out.input_snapshot, 'utf8');
  assert.ok(storedBytes <= MAX_RUN_INPUT_SNAPSHOT_BYTES, 'the stored document is within the bound');
  assert.ok(storedBytes < arrivedBytes, 'masking is what brought it under');
  assert.strictEqual(JSON.parse(out.input_snapshot).entered.access_token, '****');
});

test('a snapshot exactly at the limit is accepted (the bound is a maximum, not a margin)', async () => {
  // Grown to the byte, so an off-by-one in the comparison shows up here.
  const pad = MAX_RUN_INPUT_SNAPSHOT_BYTES - Buffer.byteLength(snapshotDoc({ entered: { n: '' } }), 'utf8');
  const doc = snapshotDoc({ entered: { n: 'z'.repeat(pad) } });
  assert.strictEqual(Buffer.byteLength(doc, 'utf8'), MAX_RUN_INPUT_SNAPSHOT_BYTES);
  const out = await serializeWrite({ input_snapshot: doc });
  assert.strictEqual(Buffer.byteLength(out.input_snapshot, 'utf8'), MAX_RUN_INPUT_SNAPSHOT_BYTES);
});

test('no refusal this module can produce names a database column', async () => {
  // A property over the whole family, not over the messages that exist today.
  // The size message was reworded to drop `input_snapshot` and the shape
  // refusals, written afterwards in the same batch, put it back — the run modal
  // renders these verbatim into a role="alert". Enumerating every input shape
  // that can be refused is what stops the next refusal reopening it again.
  const rejected = [
    42, null, ['a'], '', 'not json at all', '"a string"', '[]',
    JSON.stringify({ not_captured: 'outputs_stale', entered: {} }),
    JSON.stringify({ not_captured: 'too_large' }),
    JSON.stringify({ not_captured: 'invented_reason' }),
    JSON.stringify({ entered: {}, computed: {} }),
    JSON.stringify(snapshotDocObject({ surprise: 1 })),
    JSON.stringify(snapshotDocObject({ entered: 'not an object' })),
    JSON.stringify(snapshotDocObject({ entered: { n: 12 } })),
    JSON.stringify(snapshotDocObject({ entered: JSON.parse('{"__proto__":"x"}') })),
    JSON.stringify(snapshotDocObject({ blueprint_id: 7 })),
    // The identity-half branches, which are refusals like any other and reach
    // the same role="alert" — enumerated here so a reworded one cannot reopen
    // the column-name rule this test exists for.
    JSON.stringify(snapshotDocObject({ blueprint_id: 'bp1' })),
    JSON.stringify(snapshotDocObject({ variant_id: 'v1' })),
    JSON.stringify(snapshotDocObject({ fields: { site_name: 'f1' } })),
    JSON.stringify(snapshotDocObject({ fields: { site_name: 7 } })),
  ];
  const seen = new Set();
  for (const value of rejected) {
    let message = null;
    try { parseInputSnapshot(value); } catch (e) { message = e.message; }
    assert.notStrictEqual(message, null, `${JSON.stringify(value)} should have been refused`);
    assert.doesNotMatch(message, /input_snapshot/,
      `an operator sees this text; it must not name a column: "${message}"`);
    assert.match(message, /^the entered values could not be recorded: /,
      `every refusal leads with the same operator sentence: "${message}"`);
    seen.add(message.replace(/:.*$/, (m) => m.split(':').slice(0, 2).join(':')));
  }
  // Distinct wordings, not one message reached sixteen ways.
  assert.ok(seen.size >= 8, `expected the fixtures to reach most refusal branches, reached ${seen.size}`);
});

// ── PR-2 Task 4 Step 4: step_results entry.error_body masking gap ──

test('serializeWrite masks a secret-named key inside a JSON error_body string leaf', async () => {
  const out = await serializeWrite({
    step_results: JSON.stringify([
      { step_id: 's1', step_name: 'push', ok: false, upstream_status: 502, error_body: JSON.stringify({ api_key: 's3cret', ok: false }) },
    ]),
  });
  const entry = out.step_results[0];
  const parsedBody = JSON.parse(entry.error_body);
  assert.strictEqual(parsedBody.api_key, '****');
  assert.strictEqual(parsedBody.ok, false);
});

test('serializeWrite masks a secret-named key inside a YAML-shaped error_body string leaf', async () => {
  // maskDeep's own string-leaf recursion only attempts a JSON parse (checks for a
  // leading `{`/`[`), so a plain "key: value" upstream body — which parses as a
  // YAML mapping — reaches maskDeep unmasked. Only maskSerializedPayload (used
  // for rendered_payload) also tries YAML, which is the gap Step 4 closes.
  const out = await serializeWrite({
    step_results: JSON.stringify([
      { step_id: 's1', step_name: 'push', ok: false, upstream_status: 502, error_body: 'api_key: s3cret\nmsg: failed\n' },
    ]),
  });
  const entry = out.step_results[0];
  const parsed = require('yaml').parse(entry.error_body);
  assert.strictEqual(parsed.api_key, '****');
  assert.strictEqual(parsed.msg, 'failed');
});

// CHANGED BEHAVIOUR (PR-2 review F2): an opaque (non-JSON,
// non-YAML-object) error_body used to be stored verbatim — fail OPEN, on a
// column upstream fully controls and every authenticated user can read.
// It now fails CLOSED: nothing of the raw body is stored.
test('serializeWrite withholds an opaque (non-JSON, non-YAML-object) error_body — F2 fail-closed', async () => {
  const out = await serializeWrite({
    step_results: JSON.stringify([
      { step_id: 's1', step_name: 'push', ok: false, upstream_status: 502, error_body: 'plain text failure' },
    ]),
  });
  assert.strictEqual(out.step_results[0].error_body, '[unstructured upstream response withheld]');
  assert.doesNotMatch(out.step_results[0].error_body, /plain text failure/);
});

test('serializeWrite withholds an HTML error_body (F2 — the reproduced fail-open bug)', async () => {
  const out = await serializeWrite({
    step_results: JSON.stringify([
      { step_id: 's1', ok: false, upstream_status: 500, error_body: '<html><body>Internal Server Error</body></html>' },
    ]),
  });
  assert.strictEqual(out.step_results[0].error_body, '[unstructured upstream response withheld]');
});

test('serializeWrite withholds a bare base64 error_body (F2)', async () => {
  const out = await serializeWrite({
    step_results: JSON.stringify([
      { step_id: 's1', ok: false, upstream_status: 500, error_body: 'QWxhZGRpbjpvcGVuIHNlc2FtZQ==' },
    ]),
  });
  assert.strictEqual(out.step_results[0].error_body, '[unstructured upstream response withheld]');
});

test('serializeWrite withholds a bare scalar JSON error_body (a quoted string is not a JSON object/array)', async () => {
  const out = await serializeWrite({
    step_results: JSON.stringify([
      { step_id: 's1', ok: false, upstream_status: 500, error_body: JSON.stringify('just a string') },
    ]),
  });
  assert.strictEqual(out.step_results[0].error_body, '[unstructured upstream response withheld]');
});

// A JSON ARRAY body (not an object) is still structured — F2's rule is
// "object or array", not "object only" (matches maskDeep/maskSerializedPayload's
// existing typeof==='object' gate, which JS gives arrays too).
test('serializeWrite masks a JSON ARRAY error_body (structured, not withheld)', async () => {
  const out = await serializeWrite({
    step_results: JSON.stringify([
      { step_id: 's1', ok: false, upstream_status: 500, error_body: JSON.stringify([{ api_key: 's3cret' }, { ok: true }]) },
    ]),
  });
  const parsed = JSON.parse(out.step_results[0].error_body);
  assert.deepStrictEqual(parsed, [{ api_key: '****' }, { ok: true }]);
});

test('serializeWrite leaves a successful entry (no error_body) unaffected', async () => {
  const out = await serializeWrite({
    step_results: JSON.stringify([{ step_id: 's1', step_name: 'push', ok: true, upstream_status: 200 }]),
  });
  assert.deepStrictEqual(out.step_results[0], { step_id: 's1', step_name: 'push', ok: true, upstream_status: 200 });
});

test('serializeWrite still masks a legacy-shape step_results entry with no error_body key', async () => {
  const out = await serializeWrite({
    step_results: JSON.stringify([{ step_id: 's1', ok: false, upstream_status: 502 }]),
  });
  assert.deepStrictEqual(out.step_results[0], { step_id: 's1', ok: false, upstream_status: 502 });
});

// ── error_body_chars — pre-mask size, always visible ────────────────────────

test('serializeWrite stamps error_body_chars = pre-mask length for a masked (structured) error_body', async () => {
  const rawBody = JSON.stringify({ api_key: 's3cret', ok: false });
  const out = await serializeWrite({
    step_results: JSON.stringify([
      { step_id: 's1', ok: false, upstream_status: 502, error_body: rawBody },
    ]),
  });
  assert.strictEqual(out.step_results[0].error_body_chars, rawBody.length);
});

test('serializeWrite stamps error_body_chars = pre-mask length even when the body is withheld (unstructured)', async () => {
  const rawBody = 'plain text failure';
  const out = await serializeWrite({
    step_results: JSON.stringify([
      { step_id: 's1', ok: false, upstream_status: 502, error_body: rawBody },
    ]),
  });
  assert.strictEqual(out.step_results[0].error_body, '[unstructured upstream response withheld]');
  assert.strictEqual(out.step_results[0].error_body_chars, rawBody.length,
    'a size must stay visible even when the text underneath is withheld');
});

test('serializeWrite stamps error_body_chars = the PRE-mask length for a capped body, not the post-cap length', async () => {
  const padding = 'x'.repeat(8300);
  const rawBody = JSON.stringify({ padding, ok: false });
  const out = await serializeWrite({
    step_results: JSON.stringify([{ step_id: 's1', ok: false, upstream_status: 500, error_body: rawBody }]),
  });
  const entry = out.step_results[0];
  assert.ok(entry.error_body.length <= 8192, 'storage cap must still apply to the stored text');
  assert.strictEqual(entry.error_body_chars, rawBody.length,
    'the recorded size is the ORIGINAL length, not the length of the text that got cut');
  assert.notStrictEqual(entry.error_body_chars, entry.error_body.length);
});

test('serializeWrite does not stamp error_body_chars on a successful entry (no error_body)', async () => {
  const out = await serializeWrite({
    step_results: JSON.stringify([{ step_id: 's1', ok: true, upstream_status: 200 }]),
  });
  assert.strictEqual('error_body_chars' in out.step_results[0], false);
});

test('serializeWrite does not stamp error_body_chars on an entry with only error_body_omitted', async () => {
  const out = await serializeWrite({
    step_results: JSON.stringify([
      { step_id: 's1', ok: false, upstream_status: 502, error_body_omitted: 33042 },
    ]),
  });
  assert.strictEqual('error_body_chars' in out.step_results[0], false,
    'error_body_omitted already carries a char count; error_body_chars is only for entries that had error_body');
});

// ── content_type parse-and-allowlist at the mask boundary ───────────────────
//
// `content_type` is upstream-controlled (an HTTP response header echoed into
// this durable, admin-readable row), unlike `step_id`/`ok`/`upstream_status`,
// which are server-derived. It is normalized by PARSING the media-type grammar
// and reconstructing the stored value from ONLY `type/subtype`; ALL parameters
// (charset included) are dropped, and any non-media-type value withholds the
// field. This replaces the old value-leak scrub, which was an enumerated
// blocklist a VALID media type with a secret parameter bypassed (Codex
// P1; the charset slot was later removed too — round-2 P1c).

// Parameters are dropped entirely — a charset is NOT retained (round-2 ruling:
// the charset value is itself a token slot a secret fits). Only type/subtype is
// stored; the accompanying error_body is still masked by key name.
test('serializeWrite drops the charset parameter, storing only type/subtype, alongside a masked error_body', async () => {
  const out = await serializeWrite({
    step_results: JSON.stringify([
      {
        step_id: 's1', ok: false, upstream_status: 500, content_type: 'application/json; charset=utf-8',
        error_body: JSON.stringify({ api_key: 's3cret' }),
      },
    ]),
  });
  const entry = out.step_results[0];
  assert.strictEqual(entry.content_type, 'application/json');
  assert.strictEqual(JSON.parse(entry.error_body).api_key, '****');
});

// A hostile parameter on an OTHERWISE-VALID media type is dropped, not scrubbed
// — the value is reconstructed from parsed tokens, so the parameter is never
// copied into the row at all. This is the Codex P1 case.
test('serializeWrite drops a hostile parameter on a valid media type, storing only type/subtype', async () => {
  const out = await serializeWrite({
    step_results: JSON.stringify([
      { step_id: 's1', ok: false, upstream_status: 401, content_type: 'text/plain; authorization="short-secret"' },
    ]),
  });
  assert.strictEqual(out.step_results[0].content_type, 'text/plain');
});

// An exotic-but-valid media type (structured-suffix subtype) is kept.
test('serializeWrite keeps an exotic-but-valid media type (application/problem+json)', async () => {
  const out = await serializeWrite({
    step_results: JSON.stringify([
      { step_id: 's1', ok: false, upstream_status: 400, content_type: 'application/problem+json' },
    ]),
  });
  assert.strictEqual(out.step_results[0].content_type, 'application/problem+json');
});

// A quoted charset parameter is dropped like any other parameter.
test('serializeWrite drops a quoted charset parameter', async () => {
  const out = await serializeWrite({
    step_results: JSON.stringify([
      { step_id: 's1', ok: false, upstream_status: 500, content_type: 'text/html; charset="UTF-8"' },
    ]),
  });
  assert.strictEqual(out.step_results[0].content_type, 'text/html');
});

// Codex round-2 reproduction (P1c): a secret in the charset VALUE is dropped
// with the whole parameter — the charset slot no longer exists as a channel.
test('serializeWrite drops a token-shaped charset value entirely (charset=ghp_…), storing only type/subtype', async () => {
  const out = await serializeWrite({
    step_results: JSON.stringify([
      { step_id: 's1', ok: false, upstream_status: 401, content_type: 'text/plain; charset=ghp_abcdefghijklmnopqrstuvwxyz012345' },
    ]),
  });
  assert.strictEqual(out.step_results[0].content_type, 'text/plain');
});

// A value that does not parse as a media type at all withholds the field
// entirely (fail-closed, F2 philosophy): a stray auth header, garbage, and the
// empty string all remove `content_type`.
for (const [label, value] of [
  ['a Bearer-token-shaped header', 'Bearer ghp_abcdefghijklmnopqrstuvwxyz012345'],
  ['an empty string', ''],
  ['arbitrary garbage', 'not a media type @@@'],
]) {
  test(`serializeWrite withholds content_type entirely for ${label}`, async () => {
    const out = await serializeWrite({
      step_results: JSON.stringify([
        { step_id: 's1', ok: false, upstream_status: 401, content_type: value },
      ]),
    });
    assert.strictEqual('content_type' in out.step_results[0], false);
    // The rest of the entry is untouched.
    assert.strictEqual(out.step_results[0].step_id, 's1');
  });
}

// ── content_type: type-enum + subtype grammar (confirm-seat P1b) ───
//
// The RFC 7230 token charset still admits a secret-shaped SUBTYPE (`ghp_…`) or
// a secret-shaped TYPE. The type slot is a closed IANA enum; the subtype slot
// is a tighter grammar (no underscore) plus a value-leak backstop.

// A token-shaped subtype carrying an underscore-prefixed secret is withheld —
// the subtype grammar drops underscore, so `ghp_…` cannot be a subtype.
test('serializeWrite withholds a content_type whose SUBTYPE is a token-shaped secret (application/ghp_…)', async () => {
  const out = await serializeWrite({
    step_results: JSON.stringify([
      { step_id: 's1', ok: false, upstream_status: 401, content_type: 'application/ghp_abcdefghijklmnopqrstuvwxyz012345' },
    ]),
  });
  assert.strictEqual('content_type' in out.step_results[0], false);
});

// An AKIA-shaped subtype survives the grammar (alnum, no underscore) but is
// caught by the ORIGINAL-CASE value-leak backstop and withheld — never stored
// as a ****-mangled subtype.
test('serializeWrite withholds an AKIA-shaped subtype via the original-case value-leak backstop', async () => {
  const out = await serializeWrite({
    step_results: JSON.stringify([
      { step_id: 's1', ok: false, upstream_status: 403, content_type: 'application/AKIAIOSFODNN7EXAMPLE' },
    ]),
  });
  assert.strictEqual('content_type' in out.step_results[0], false);
});

// A legitimate long vendor-tree subtype (dots, hyphens, well under 100 chars) is
// kept — the grammar tightening does not cost real media types.
test('serializeWrite keeps a legitimate long vendor-tree subtype (OOXML wordprocessing)', async () => {
  const ct = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';
  const out = await serializeWrite({
    step_results: JSON.stringify([
      { step_id: 's1', ok: false, upstream_status: 500, content_type: ct },
    ]),
  });
  assert.strictEqual(out.step_results[0].content_type, ct);
});

// A non-IANA top-level type is withheld by the closed enum, even though its
// subtype is clean — the type slot is closed by construction.
test('serializeWrite withholds a non-IANA top-level type (chemical/x-pdb)', async () => {
  const out = await serializeWrite({
    step_results: JSON.stringify([
      { step_id: 's1', ok: false, upstream_status: 500, content_type: 'chemical/x-pdb' },
    ]),
  });
  assert.strictEqual('content_type' in out.step_results[0], false);
});

// The pre-parse cap bounds the parser's input; an oversized value with a huge
// boundary parameter still parses to just its (short) media type, and the
// stored value is far under the input cap by construction.
test('serializeWrite bounds an oversized content_type and stores only the parsed media type', async () => {
  const { STEP_CONTENT_TYPE_MAX } = require('../../../../src/edge/routes/app/flow-recipe-runs/serializer');
  const oversized = `application/json; boundary=${'A'.repeat(STEP_CONTENT_TYPE_MAX * 2)}`;
  assert.ok(oversized.length > STEP_CONTENT_TYPE_MAX);
  const out = await serializeWrite({
    step_results: JSON.stringify([
      { step_id: 's1', ok: false, upstream_status: 500, content_type: oversized },
    ]),
  });
  // boundary dropped; only the media type survives, well under the input cap.
  assert.strictEqual(out.step_results[0].content_type, 'application/json');
  assert.ok(out.step_results[0].content_type.length <= STEP_CONTENT_TYPE_MAX);
});

// ── error_body_chars / placeholder idempotency under re-serialization ───────
//
// A row can reach serializeWrite a second time — an admin PUT that
// round-trips an already-masked row unchanged. Neither the stamped size nor
// the withheld placeholder may be corrupted by that second pass.

test('serializeWrite does not overwrite error_body_chars on a second write over an already-masked row', async () => {
  const rawBody = JSON.stringify({ ok: false, detail: 'upstream refused' });
  const first = await serializeWrite({
    step_results: JSON.stringify([
      { step_id: 's1', ok: false, upstream_status: 500, error_body: rawBody },
    ]),
  });
  const firstChars = first.step_results[0].error_body_chars;
  assert.strictEqual(firstChars, rawBody.length);

  // Re-serialize the row exactly as an admin PUT would receive it back —
  // step_results already carries the masked error_body and the stamped size.
  const second = await serializeWrite({ step_results: first.step_results });
  assert.strictEqual(second.step_results[0].error_body_chars, firstChars,
    'the second pass must not overwrite the true pre-mask size with the masked text\'s own (shorter) length');
});

test('serializeWrite leaves the withheld placeholder byte-identical on a second write (idempotency guard)', async () => {
  const first = await serializeWrite({
    step_results: JSON.stringify([
      { step_id: 's1', ok: false, upstream_status: 500, error_body: 'plain text failure, not JSON/YAML' },
    ]),
  });
  const placeholder = first.step_results[0].error_body;
  assert.strictEqual(placeholder, '[unstructured upstream response withheld]');

  // Revert probe: without the idempotency guard, the placeholder (`[`-leading)
  // parses as a one-item YAML flow sequence and re-stringifies to
  // "- unstructured upstream response withheld\n" on this second pass —
  // reproduced directly against the exported maskErrorBody below.
  const second = await serializeWrite({ step_results: first.step_results });
  assert.strictEqual(second.step_results[0].error_body, placeholder,
    're-masking an already-withheld placeholder must be a byte-identical no-op');
});

// ── F1 — mask BEFORE cap, so a cut can only ever cut MASKED text ────────────

test('(F1) a secret past the 8192 storage cap is masked before the cut, never stored raw', async () => {
  // Revert probe: with the OLD (pre-batch) order — truncate the raw body to
  // 8192 chars, then try to mask/store the (now possibly-invalid) prefix —
  // this exact fixture is what empirically reproduced the bug: a 502-byte
  // JSON document whose `access_token` key sits past byte 8192 was cut
  // mid-string, both JSON.parse and yaml.parse threw on the truncated text,
  // and the (still-raw) prefix — token included — was stored verbatim.
  const padding = 'x'.repeat(8300); // pushes access_token well past the storage cap
  const bigBody = JSON.stringify({ padding, access_token: 'sk-live-VERY-SECRET-VALUE' });
  assert.ok(bigBody.length > 8192, 'fixture must exceed the storage cap, or this proves nothing');
  assert.ok(bigBody.indexOf('access_token') > 8192, 'the secret key must sit PAST the cap, or a naive cut before it would hide the bug');

  const out = await serializeWrite({
    step_results: JSON.stringify([{ step_id: 's1', ok: false, upstream_status: 500, error_body: bigBody }]),
  });
  const stored = out.step_results[0].error_body;

  assert.strictEqual(stored.includes('VERY-SECRET-VALUE'), false, 'the raw secret must never reach storage');
  assert.ok(stored.length <= 8192, 'storage cap must still apply to the masked output');
  // The cut lands inside already-masked text (JSON.stringify of a masked,
  // capped object is itself not guaranteed to stay valid JSON once sliced —
  // that is expected and safe: what matters is nothing of the raw secret
  // survives, asserted above).
});

test('(F1) a secret WELL UNDER the storage cap is masked and stored whole (no unnecessary withholding)', async () => {
  const out = await serializeWrite({
    step_results: JSON.stringify([
      { step_id: 's1', ok: false, upstream_status: 500, error_body: JSON.stringify({ access_token: 'sk-live-1', ok: false }) },
    ]),
  });
  const parsed = JSON.parse(out.step_results[0].error_body);
  assert.strictEqual(parsed.access_token, '****');
  assert.strictEqual(parsed.ok, false);
});

// ── F3 — value-shaped-leak scrub (defense-in-depth, over an innocuous key) ──

test('(F3) a Bearer-token-shaped value under an innocuous key is redacted', async () => {
  const out = await serializeWrite({
    step_results: JSON.stringify([
      { step_id: 's1', ok: false, upstream_status: 500, error_body: JSON.stringify({ message: 'try Bearer abc123XYZ.def456 again' }) },
    ]),
  });
  const parsed = JSON.parse(out.step_results[0].error_body);
  assert.doesNotMatch(parsed.message, /abc123XYZ/);
  assert.match(parsed.message, /\*\*\*\*/);
});

test('(F3) a JWT-shaped value under an innocuous key is redacted', async () => {
  const jwt = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMjM0NTY3ODkwIn0.dozjgNryP4J3jVmNHl0w5N_XgL0n3I9PlFUP0THsR8U';
  const out = await serializeWrite({
    step_results: JSON.stringify([
      { step_id: 's1', ok: false, upstream_status: 500, error_body: JSON.stringify({ note: jwt }) },
    ]),
  });
  const parsed = JSON.parse(out.step_results[0].error_body);
  assert.doesNotMatch(parsed.note, /eyJ/);
});

test('(F3) sk_live_/sk_test_/ghp_/gho_/AKIA-prefixed values are redacted', async () => {
  const cases = [
    ['sk_live_', 'sk_live_4eC39HqLyjWDarjtT1zdp7dc'],
    ['sk_test_', 'sk_test_4eC39HqLyjWDarjtT1zdp7dc'],
    ['ghp_', 'ghp_16C7e42F292c6912E7710c838347Ae178B4a'],
    ['gho_', 'gho_16C7e42F292c6912E7710c838347Ae178B4a'],
    ['AKIA', 'AKIAIOSFODNN7EXAMPLE'],
  ];
  for (const [label, token] of cases) {
    const out = await serializeWrite({
      step_results: JSON.stringify([
        { step_id: 's1', ok: false, upstream_status: 500, error_body: JSON.stringify({ note: `key=${token}` }) },
      ]),
    });
    const parsed = JSON.parse(out.step_results[0].error_body);
    assert.doesNotMatch(parsed.note, new RegExp(token), `${label}-prefixed token must be redacted`);
  }
});

test('(F3) a contiguous hex run >= 32 chars under an innocuous key is redacted', async () => {
  const hex = 'a'.repeat(40);
  const out = await serializeWrite({
    step_results: JSON.stringify([
      { step_id: 's1', ok: false, upstream_status: 500, error_body: JSON.stringify({ note: `id=${hex}` }) },
    ]),
  });
  const parsed = JSON.parse(out.step_results[0].error_body);
  assert.doesNotMatch(parsed.note, new RegExp(hex));
});

test('(F3) a contiguous base64 run >= 32 chars under an innocuous key is redacted', async () => {
  const b64 = Buffer.from('a-secret-value-that-is-long-enough-to-trip-the-scrub').toString('base64');
  assert.ok(b64.length >= 32, 'fixture must be long enough to trip the pattern');
  const out = await serializeWrite({
    step_results: JSON.stringify([
      { step_id: 's1', ok: false, upstream_status: 500, error_body: JSON.stringify({ note: `blob=${b64}` }) },
    ]),
  });
  const parsed = JSON.parse(out.step_results[0].error_body);
  assert.doesNotMatch(parsed.note, new RegExp(b64.replace(/[+/=]/g, '\\$&')));
});

test('(F3) an ordinary short value under an innocuous key survives untouched (no over-redaction)', async () => {
  const out = await serializeWrite({
    step_results: JSON.stringify([
      { step_id: 's1', ok: false, upstream_status: 500, error_body: JSON.stringify({ note: 'connection refused', code: 'ECONNREFUSED' }) },
    ]),
  });
  const parsed = JSON.parse(out.step_results[0].error_body);
  assert.strictEqual(parsed.note, 'connection refused');
  assert.strictEqual(parsed.code, 'ECONNREFUSED');
});

// ── F7 — the error_body pass must not skip a non-array step_results shape ──

test('(F7) a malformed step_results write (a single object, not an array) still masks its own error_body', async () => {
  const out = await serializeWrite({
    step_results: JSON.stringify({ step_id: 's1', ok: false, upstream_status: 500, error_body: 'not structured' }),
  });
  // The malformed shape survives (this module does not reshape it), but its
  // error_body must not reopen the fail-open gap just because it is not
  // wrapped in an array.
  assert.strictEqual(out.step_results.error_body, '[unstructured upstream response withheld]');
});

test('(F7) a malformed non-array step_results with a JSON-object error_body is masked, not left raw', async () => {
  const out = await serializeWrite({
    step_results: JSON.stringify({ step_id: 's1', ok: false, error_body: JSON.stringify({ api_key: 's3cret' }) }),
  });
  const parsed = JSON.parse(out.step_results.error_body);
  assert.strictEqual(parsed.api_key, '****');
});

// ── PR-2 review round 2 (F1-follow-up): error_body_omitted ─────────
//
// A first attempt at the transport cap sent a placeholder STRING as
// error_body when a body exceeded it (e.g.
// `[response body omitted: exceeds transport cap (33042 chars)]`) — and
// reproduced its own bug: a `[`-leading placeholder parses as a YAML flow
// sequence, so maskErrorBody's structured-parse gate accepted it as real
// structure instead of failing closed. Both producers now send NO error_body
// at all for an over-cap body — only a sibling `error_body_omitted` NUMBER —
// so there is no text on this path for the masker to parse as anything.

test('serializeWrite passes error_body_omitted through untouched (a number, not text the masker inspects)', async () => {
  const out = await serializeWrite({
    step_results: JSON.stringify([
      { step_id: 's1', step_name: 'push', ok: false, upstream_status: 502, error_body_omitted: 33042 },
    ]),
  });
  assert.deepStrictEqual(out.step_results[0], {
    step_id: 's1', step_name: 'push', ok: false, upstream_status: 502, error_body_omitted: 33042,
  });
});

test('an entry with error_body_omitted carries no error_body key at all (mutually exclusive)', async () => {
  const out = await serializeWrite({
    step_results: JSON.stringify([
      { step_id: 's1', ok: false, upstream_status: 502, error_body_omitted: 100 },
    ]),
  });
  assert.strictEqual('error_body' in out.step_results[0], false);
});

// REVERT PROBE, kept as a permanent regression pin rather than a one-off
// script: reproduces the exact reported defect (a `[`-leading placeholder
// string sent AS error_body, the shape the field approach replaced) and
// asserts it is NOT withheld as unstructured — it is misread as YAML
// structure and stored mangled — which is why no producer sends this shape
// any more. Documents the reasoning so a future "simplification" back to a
// placeholder string cannot reopen it silently.
test('a `[`-leading placeholder string sent as error_body (the REVERTED shape) is misread as YAML, not withheld — why the field approach replaced it', async () => {
  const out = await serializeWrite({
    step_results: JSON.stringify([
      { step_id: 's1', ok: false, error_body: '[response body omitted: exceeds transport cap (33042 chars)]' },
    ]),
  });
  const stored = out.step_results[0].error_body;
  // NOT the fail-closed placeholder — proof the bracket text fooled the
  // structured-parse gate into treating it as real YAML structure.
  assert.notStrictEqual(stored, '[unstructured upstream response withheld]');
  assert.strictEqual(stored, '- response body omitted: exceeds transport cap (33042 chars)\n',
    'pins the exact mangled shape the reported defect produced');
});

test('the two sibling snapshot columns keep their store-verbatim behaviour', async () => {
  // Only the new column is strict. Changing the siblings is a separate piece of
  // work, and this pins that this change did not quietly do it.
  const out = await serializeWrite({
    output_snapshot: 'plain-text-snapshot',
    rendered_payload: 'just a plain string',
  });
  assert.strictEqual(out.output_snapshot, 'plain-text-snapshot');
  assert.strictEqual(out.rendered_payload, 'just a plain string');
});
