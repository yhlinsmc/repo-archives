/**
 * capacity-renumber-lock.test.js — cap-renumber-lock (spec D1/D3/D4/D5): a
 * locked host is never renamed by renumber, consumes no sequence number, and
 * a generated name colliding with a locked name auto-skips to the next seq.
 * Apply re-reads lock state fresh from the DB every time (never trusts a
 * stale preview). Same mocked-pool harness as capacity-renumber.test.js.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../../../src/edge/db');

let state;
function freshState() {
  return {
    queries: [],
    began: 0, committed: 0, rolledBack: 0, released: 0,
    // M1: counts pool.ro.getConnection() acquisitions — the single-connection
    // invariant preview must hold across the pattern-resolution probe AND the
    // row SELECTs (same shape as the RW transaction conn apply already uses).
    roGetConnectionCalls: 0,
    scenarioExists: true,
    scenarioOwner: null,
    settingsColumns: ['id', 'scenario_id', 'name_patterns', 'mem_cpu_ratio'],
    // cap_hypervisors / cap_vms physical columns (the name_locked probe).
    entityColumns: ['id', 'name', 'order_index', 'site_id', 'vm_type', 'name_locked'],
    // Set to an array to make the RO connection's information_schema answer
    // diverge from `entityColumns` (the RW answer) — replica DDL lag (Codex r2).
    roEntityColumns: null,
    // Same divergence mechanism for the cap_settings probe (name_patterns —
    // resolveEffectivePatterns' probe, PR-2 confirm-seat directed fix).
    roSettingsColumns: null,
    scenarioSettings: null,
    globalPatterns: null,
    sites: [{ id: 's1', name: 'DC' }],
    hypervisors: [],
    // 3 db_host KVMs at the same site (one dc group), middle one locked with a
    // hand-picked name. order_index preserves display order.
    vms: [
      { id: 'k1', name: 'old-k1', order_index: 0, site_id: 's1', vm_type: 'db_host', name_locked: 0 },
      { id: 'k2', name: 'erp-db', order_index: 1, site_id: 's1', vm_type: 'db_host', name_locked: 1 },
      { id: 'k3', name: 'old-k3', order_index: 2, site_id: 's1', vm_type: 'db_host', name_locked: 0 },
    ],
  };
}

function sortForSql(rows, sql) {
  const out = [...rows];
  if (/ORDER BY order_index/.test(sql)) {
    out.sort((a, b) => (a.order_index - b.order_index) || (a.id < b.id ? -1 : 1));
  } else if (/ORDER BY id FOR UPDATE/.test(sql)) {
    out.sort((a, b) => (a.id < b.id ? -1 : a.id > b.id ? 1 : 0));
  }
  return out;
}

// `role` distinguishes the RO and RW connections so a test can make them
// disagree on the entity tables' physical column set (replica DDL lag,
// Codex r2) — everything else (rows, settings, sites) reads off the SAME
// shared `state`, only the information_schema.COLUMNS answer for
// cap_hypervisors/cap_vms can diverge per role via `state.roEntityColumns`.
function makeConn(role) {
  return {
    async beginTransaction() { state.began += 1; },
    async commit() { state.committed += 1; },
    async rollback() { state.rolledBack += 1; },
    release() { state.released += 1; },
    async query(sql, params = []) {
      state.queries.push({ sql, params, role });

      if (/information_schema\.COLUMNS/.test(sql)) {
        // The physical table name is bound as the query param — discriminate so
        // the cap_hypervisors/cap_vms name_locked probe (readTableRows) does not
        // get handed cap_settings's column list back.
        if (params[0] === 'fmb_cap_settings') {
          const settingsCols = (role === 'ro' && state.roSettingsColumns) ? state.roSettingsColumns : state.settingsColumns;
          return settingsCols.map((name) => ({ name }));
        }
        const cols = (role === 'ro' && state.roEntityColumns) ? state.roEntityColumns : state.entityColumns;
        return cols.map((name) => ({ name }));
      }
      if (/SELECT id, owner_id FROM `fmb_cap_scenarios` WHERE id = \?/.test(sql)) {
        return state.scenarioExists ? [{ id: params[0], owner_id: state.scenarioOwner }] : [];
      }
      if (/SELECT scenario_id, name_patterns FROM `fmb_cap_settings` WHERE scenario_id = \?/.test(sql)) {
        return state.scenarioSettings
          ? [{ scenario_id: params[0], name_patterns: state.scenarioSettings.name_patterns }]
          : [];
      }
      if (/SELECT scenario_id, name_patterns FROM `fmb_cap_settings` WHERE scenario_id IS NULL/.test(sql)) {
        return [{ scenario_id: null, name_patterns: state.globalPatterns }];
      }
      if (/SELECT id, name FROM `fmb_cap_sites` WHERE scenario_id = \?/.test(sql)) {
        return state.sites.map((s) => ({ id: s.id, name: s.name }));
      }
      if (/FROM `fmb_cap_hypervisors` WHERE scenario_id = \?/.test(sql)) {
        return sortForSql(state.hypervisors, sql).map((r) => ({ ...r }));
      }
      if (/FROM `fmb_cap_vms` WHERE scenario_id = \?/.test(sql)) {
        return sortForSql(state.vms, sql).map((r) => ({ ...r }));
      }
      if (/^UPDATE `fmb_cap_\w+` SET name = \? WHERE id = \? AND scenario_id = \?/.test(sql)) {
        return { affectedRows: 1 };
      }
      return [];
    },
  };
}

const connRW = makeConn('rw');
const connRO = makeConn('ro');

const poolFacade = {
  getConnection: async () => connRW,
  query: (sql, params) => connRW.query(sql, params),
};
const poolFacadeRO = {
  getConnection: async () => { state.roGetConnectionCalls += 1; return connRO; },
  query: (sql, params) => connRO.query(sql, params),
};
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: { ro: poolFacadeRO, rw: poolFacade }, t: (n) => `fmb_${n}` },
};

const router = require('../../../../src/edge/routes/app/capacity');
const { _resetColumnSetCache } = require('../../../../src/edge/routes/app/capacity/_shared');

let currentUser; let server; let baseUrl;
before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { req.user = currentUser; next(); });
  app.use('/capacity', router);
  server = http.createServer(app);
  await new Promise((r) => server.listen(0, r));
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});
after(() => server && server.close());
beforeEach(() => {
  state = freshState();
  currentUser = { id: 'u-admin', role: 'admin' };
  _resetColumnSetCache();
});

function request(method, path, body) {
  return new Promise((resolve, reject) => {
    const payload = body === undefined ? '' : JSON.stringify(body);
    const r = http.request(
      `${baseUrl}${path}`,
      { method, headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) } },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          const raw = Buffer.concat(chunks).toString('utf8');
          let json = null;
          try { json = JSON.parse(raw); } catch { /* noop */ }
          resolve({ status: res.statusCode, json, raw });
        });
      },
    );
    r.on('error', reject);
    if (payload) r.write(payload);
    r.end();
  });
}

const updates = () => state.queries.filter((q) => /^UPDATE `fmb_cap_\w+` SET name/.test(q.sql));
const PREVIEW = '/capacity/scenarios/scn-1/renumber-preview';
const APPLY = '/capacity/scenarios/scn-1/renumber';

describe('renumber lock — preview', () => {
  it('locked hosts are excluded from renaming and consume no seq (D1/D3)', async () => {
    const res = await request('POST', PREVIEW, {});
    assert.equal(res.status, 200, res.raw);
    const byId = Object.fromEntries(res.json.data.rows.map((p) => [p.id, p]));
    assert.equal(byId.k2.newName, 'erp-db'); // locked row untouched
    assert.equal(byId.k2.locked, true);
    // the other two renumber contiguously 01/02, not 01/03. U4 (
    // Q5-Q7): all 3 hosts are empty (no dbInstances fixture in this file), so
    // {db_seq} falls back to the group's {seq} counter — {dc} is dropped from
    // the default, so 'kvm-01'/'kvm-02', not 'kvm-dc-01'/'kvm-dc-02'.
    assert.equal(byId.k1.newName, 'kvm-01');
    assert.equal(byId.k3.newName, 'kvm-02');
  });

  it('locked row appears with locked:true and newName===oldName', async () => {
    const res = await request('POST', PREVIEW, {});
    const byId = Object.fromEntries(res.json.data.rows.map((p) => [p.id, p]));
    assert.equal(byId.k2.oldName, 'erp-db');
    assert.equal(byId.k2.newName, byId.k2.oldName);
    assert.equal(byId.k1.locked, false);
    assert.equal(byId.k3.locked, false);
  });

  it('a generated name colliding with a locked name auto-skips to the next seq (D4), zero red rows', async () => {
    state.vms[1].name = 'kvm-01'; // locked row reserves the FIRST generated slot (U4: no {dc} in the default)
    const res = await request('POST', PREVIEW, {});
    assert.equal(res.status, 200, res.raw);
    const byId = Object.fromEntries(res.json.data.rows.map((p) => [p.id, p]));
    assert.equal(byId.k1.newName, 'kvm-02');
    assert.equal(byId.k3.newName, 'kvm-03');
    // zero red rows: no duplicate flag anywhere in this entity type's plan
    assert.equal(byId.k1.duplicate, false);
    assert.equal(byId.k3.duplicate, false);
    assert.equal(byId.k2.duplicate, false);
  });
});

describe('renumber lock — apply', () => {
  it('apply never writes a locked row and reports skippedLocked', async () => {
    const res = await request('POST', APPLY, {});
    assert.equal(res.status, 200, res.raw);
    assert.equal(res.json.data.skippedLocked, 1);
    assert.equal(updates().some((q) => q.params[1] === 'k2'), false);
    // the other two are renamed
    assert.equal(res.json.data.applied, 2);
  });

  it('apply re-checks lock state fresh: a row locked AFTER preview is skipped, not renamed', async () => {
    const preview = await request('POST', PREVIEW, {});
    const beforeById = Object.fromEntries(preview.json.data.rows.map((p) => [p.id, p]));
    assert.equal(beforeById.k1.locked, false); // preview saw it unlocked

    state.vms[0].name_locked = 1; // locked between preview and apply

    const res = await request('POST', APPLY, {});
    assert.equal(res.status, 200, res.raw);
    assert.equal(res.json.data.skippedLocked, 2); // k1 (newly locked) + k2
    assert.equal(updates().some((q) => q.params[1] === 'k1'), false, 'k1 must not be renamed');
    const k1AfterName = state.vms.find((v) => v.id === 'k1').name;
    assert.equal(k1AfterName, 'old-k1', 'k1 row is untouched');
  });
});

describe('locked-vs-locked duplicate remedy (item 2)', () => {
  it('two locked same-name rows → 409 message names the unlock remedy, not "adjust the pattern"', async () => {
    // k2 (locked) and k3 (also locked, case-folded match) already share a name.
    // Renumber never renames a locked host (spec D1), so no naming-pattern edit
    // could ever resolve this — the message must point at unlocking instead.
    state.vms[2].name_locked = 1;
    state.vms[2].name = 'ERP-DB'; // case-folded collision with k2's 'erp-db'
    const res = await request('POST', APPLY, {});
    assert.equal(res.status, 409, res.raw);
    assert.match(res.json.error.message, /unlock/i);
    assert.doesNotMatch(res.json.error.message, /adjust the .*naming pattern/i);
    assert.equal(state.committed, 0);
    assert.equal(state.rolledBack, 1);
    assert.equal(updates().length, 0);
  });

  it('preview marks a locked-vs-locked collision with lockedDuplicate, not just duplicate', async () => {
    state.vms[2].name_locked = 1;
    state.vms[2].name = 'ERP-DB';
    const res = await request('POST', PREVIEW, {});
    assert.equal(res.status, 200, res.raw);
    const byId = Object.fromEntries(res.json.data.rows.map((p) => [p.id, p]));
    assert.equal(byId.k2.duplicate, true);
    assert.equal(byId.k2.lockedDuplicate, true);
    assert.equal(byId.k3.duplicate, true);
    assert.equal(byId.k3.lockedDuplicate, true);
    // k1 is unlocked and not part of the collision at all.
    assert.ok(!byId.k1.duplicate);
  });

  it('a duplicate with at least one renumerable side keeps the pattern-adjust 409 message', async () => {
    // A malformed (seq-less) override renders every renumerable k1/k3 candidate
    // as the literal locked name "erp-db" (collision-avoidance exhausts its
    // retry bound, spec D4) — k1/k3 are UNLOCKED, so a pattern edit could still
    // resolve this even though it also touches k2's (locked) name.
    state.scenarioSettings = { name_patterns: { hypervisor: 'hv-{dc}-{seq:2}', kvm_host: 'erp-db', ap_vm: 'ap-{seq:2}' } };
    const res = await request('POST', APPLY, {});
    assert.equal(res.status, 409, res.raw);
    assert.match(res.json.error.message, /adjust the .*naming pattern/i);
    assert.doesNotMatch(res.json.error.message, /unlock one/i);
  });
});

describe('degraded schema (name_locked column absent)', () => {
  it('preview + apply degrade to "every host unlocked" instead of 500ing', async () => {
    // Warn-skipped migration: the column is gone from cap_vms. Even a row the
    // fixture marks name_locked=1 must be read as unlocked (no column to read
    // it from) — degraded, not failed.
    state.entityColumns = ['id', 'name', 'order_index', 'site_id', 'vm_type'];
    const prev = await request('POST', PREVIEW, {});
    assert.equal(prev.status, 200, prev.raw);
    const byId = Object.fromEntries(prev.json.data.rows.map((p) => [p.id, p]));
    assert.equal(byId.k2.locked, false);
    assert.equal(byId.k2.newName, 'kvm-02'); // renumbered like any other row

    const res = await request('POST', APPLY, {});
    assert.equal(res.status, 200, res.raw);
    assert.equal(res.json.data.skippedLocked, 0);
    assert.equal(res.json.data.applied, 3);
  });
});

describe('replica DDL lag (RO probe disagrees with RW probe, Codex r2)', () => {
  it('preview degrades on the RO connection\'s OWN column set even though RW already has name_locked', async () => {
    // The writer just ran the name_locked migration (RW's information_schema
    // reports it present); the RO replica has not caught up yet (its
    // information_schema still reports it absent). The probe MUST ride the
    // same connection preview's SELECT uses (pool.ro), so it agrees with what
    // that SELECT can actually ask for — degrading to "unlocked", never 500ing.
    state.entityColumns = ['id', 'name', 'order_index', 'site_id', 'vm_type', 'name_locked']; // RW: present
    state.roEntityColumns = ['id', 'name', 'order_index', 'site_id', 'vm_type']; // RO: absent (lagging)

    const res = await request('POST', PREVIEW, {});
    assert.equal(res.status, 200, res.raw);
    const byId = Object.fromEntries(res.json.data.rows.map((p) => [p.id, p]));
    // Degraded: k2's fixture name_locked=1 is invisible to the RO probe, so it
    // reads as unlocked and renumbers like any other row — the OLD bug (probe
    // via pool.rw) would instead see RW's "present" answer and report k2 as
    // still locked ('erp-db', locked:true) here.
    assert.equal(byId.k2.locked, false);
    assert.equal(byId.k2.newName, 'kvm-02');

    const roColumnProbes = state.queries.filter(
      (q) => q.role === 'ro' && /information_schema\.COLUMNS/.test(q.sql) && q.params[0] === 'fmb_cap_vms',
    );
    assert.ok(roColumnProbes.length > 0, 'the name_locked probe must run on the RO connection during preview');
  });

  it('apply is unaffected: the transaction conn IS the RW connection, so probe and SELECT already agree', async () => {
    state.entityColumns = ['id', 'name', 'order_index', 'site_id', 'vm_type', 'name_locked'];
    state.roEntityColumns = ['id', 'name', 'order_index', 'site_id', 'vm_type'];

    const res = await request('POST', APPLY, {});
    assert.equal(res.status, 200, res.raw);
    assert.equal(res.json.data.skippedLocked, 1); // k2 correctly seen as locked via RW
    assert.equal(updates().some((q) => q.params[1] === 'k2'), false);
  });

  // PR-2 confirm-seat directed fix: resolveEffectivePatterns' settings-column
  // probe (name_patterns) used to hardcode pool.rw regardless of which
  // connection the caller's SELECT actually runs on — the SAME bug shape the
  // readTableRows tests above already cover for the name_locked probe, on a
  // second probe site in the same file.
  it('preview degrades to built-in default patterns when the RO settings probe lags, even though RW already has name_patterns', async () => {
    // The writer just ran the name_patterns migration (RW: present); the RO
    // replica has not caught up yet (RO: absent). resolveEffectivePatterns'
    // probe MUST ride the SAME connection preview's SELECT uses (pool.ro).
    state.settingsColumns = ['id', 'scenario_id', 'name_patterns', 'mem_cpu_ratio']; // RW: present
    state.roSettingsColumns = ['id', 'scenario_id', 'mem_cpu_ratio']; // RO: absent (lagging)
    state.globalPatterns = {
      hypervisor: 'custom-hv-{dc}-{seq:2}', kvm_host_primary: 'custom-kvm-{dc}-{seq:2}',
      kvm_host_standby: 'custom-kvms-{dc}-{seq:2}', ap_vm: 'custom-ap-{seq:2}',
    };

    const res = await request('POST', PREVIEW, {});
    assert.equal(res.status, 200, res.raw);
    const byId = Object.fromEntries(res.json.data.rows.map((p) => [p.id, p]));
    // Degraded to the BUILT-IN default pattern (kvm-NN, U4: no {dc}), not the
    // stored custom global — the OLD bug (probe via pool.rw) would instead see
    // RW's "present" answer and read the custom global pattern here.
    assert.equal(byId.k1.newName, 'kvm-01');

    const roSettingsProbes = state.queries.filter(
      (q) => q.role === 'ro' && /information_schema\.COLUMNS/.test(q.sql) && q.params[0] === 'fmb_cap_settings',
    );
    assert.ok(roSettingsProbes.length > 0, 'the name_patterns probe must run on the RO connection during preview');
  });

  // M1: preview used to call `pool.ro` directly for the pattern-resolution
  // probe AND every row SELECT — each `.query()` on a pool facade may hand
  // back a DIFFERENT physical replica connection, so the probe and the SELECT
  // it is meant to agree with could still observe different schemas even
  // though both nominally went through `pool.ro`. Preview must acquire ONE
  // connection up front and thread it through both spans, exactly like apply
  // already does with its RW transaction connection.
  it('preview acquires exactly ONE pool.ro connection for the whole pattern-resolution + row-read span', async () => {
    const res = await request('POST', PREVIEW, {});
    assert.equal(res.status, 200, res.raw);
    assert.equal(state.roGetConnectionCalls, 1, 'preview must acquire the RO connection exactly once');
  });

  it('apply is unaffected for the settings probe too: the transaction conn IS the RW connection', async () => {
    state.settingsColumns = ['id', 'scenario_id', 'name_patterns', 'mem_cpu_ratio'];
    state.roSettingsColumns = ['id', 'scenario_id', 'mem_cpu_ratio'];
    state.globalPatterns = {
      hypervisor: 'custom-hv-{dc}-{seq:2}', kvm_host_primary: 'custom-kvm-{dc}-{seq:2}',
      kvm_host_standby: 'custom-kvms-{dc}-{seq:2}', ap_vm: 'custom-ap-{seq:2}',
    };

    const res = await request('POST', APPLY, {});
    assert.equal(res.status, 200, res.raw);
    // Apply's conn IS pool.rw, so the probe sees name_patterns present and
    // correctly reads the custom global pattern.
    const k1Renamed = res.json.data.renamed.find((r) => r.id === 'k1');
    assert.equal(k1Renamed.newName, 'custom-kvm-dc-01');
  });
});
