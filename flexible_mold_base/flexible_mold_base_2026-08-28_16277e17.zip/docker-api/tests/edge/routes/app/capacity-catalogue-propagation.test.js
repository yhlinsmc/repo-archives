/**
 * capacity-catalogue-propagation.test.js — E4 (spec §7 E4 / Q12):
 *   GET  /config/:group/propagation-preview  (admin+editor, read-only)
 *   POST /config/:group/propagation-apply    (admin+editor; per-scenario owner+admin)
 * Auth, batch apply, and partial-failure semantics (one scenario forbidden/
 * missing/erroring must not sink the rest of the batch).
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../../../src/edge/db');

let state;
function freshState() {
  return {
    queries: [],
    began: 0, committed: 0, rolledBack: 0, released: 0,
    // GLOBAL vm_profiles catalogue: p1 is formula-mode cpu=16 → derived mem_gb
    // 320 under the DEFAULT_FORMULA (memCpuRatio 20) this fixture's cap_settings
    // resolve to (no scenario override row).
    profiles: [{ id: 'p1', name: 'DB-Large', class: 'DB', mode: 'formula', cpu: 16, mem_gb: null, sga_cap_gb: null }],
    // GLOBAL disk_combos catalogue: c1 sums to 2560.
    combos: [{ id: 'c1', name: 'OS + Data L', sizes: [512, 2048] }],
    // Scenario-scoped VMs referencing the GLOBAL catalogue rows above.
    // v1 (scenario s1): stale on BOTH cpu and mem_gb.
    // v2 (scenario s2): already matches the current profile (not stale).
    // v3 (scenario s1): disk_gb stale against c1.
    vms: [
      { id: 'v1', scenario_id: 's1', name: 'db01', cpu: 8, mem_gb: 160, sizing_profile_id: 'p1', disk_combo_id: null, disk_gb: 0 },
      { id: 'v2', scenario_id: 's2', name: 'db02', cpu: 16, mem_gb: 320, sizing_profile_id: 'p1', disk_combo_id: null, disk_gb: 0 },
      { id: 'v3', scenario_id: 's1', name: 'ap01', cpu: 0, mem_gb: 0, sizing_profile_id: null, disk_combo_id: 'c1', disk_gb: 512 },
    ],
    scenarios: { s1: { name: 'Alpha', owner_id: null }, s2: { name: 'Beta', owner_id: null } },
    settings: [], // no per-scenario override rows — every scenario resolves DEFAULT_FORMULA
  };
}

// Case-insensitive comparison — mirrors the DB column's case-insensitive
// collation (round 3 Y2): a case-variant caller-supplied scenario id still
// matches rows stored under a different casing.
function ciEq(a, b) { return String(a).toLowerCase() === String(b).toLowerCase(); }

const conn = {
  async beginTransaction() { state.began += 1; },
  async commit() { state.committed += 1; },
  async rollback() { state.rolledBack += 1; },
  release() { state.released += 1; },
  async query(sql, params = []) {
    state.queries.push({ sql, params });

    // resolveScenarioWriteAccess — case-insensitive lookup (mirrors the DB
    // column's case-insensitive collation, round 3 Y2): a case-variant
    // caller-supplied id still matches the stored row, and the row's OWN
    // (stored-casing) id is what a real `SELECT ... WHERE id = ?` echoes back
    // — never the request's spelling.
    if (/SELECT id, owner_id FROM `fmb_cap_scenarios` WHERE id = \? FOR UPDATE/.test(sql)) {
      const requested = String(params[0]);
      const canonicalId = Object.keys(state.scenarios)
        .find((k) => k.toLowerCase() === requested.toLowerCase());
      const s = canonicalId ? state.scenarios[canonicalId] : null;
      return s ? [{ id: canonicalId, owner_id: s.owner_id }] : [];
    }
    // preview: scenario names
    if (/SELECT id, name FROM `fmb_cap_scenarios` WHERE id IN/.test(sql)) {
      return params.filter((id) => state.scenarios[id])
        .map((id) => ({ id, name: state.scenarios[id].name }));
    }
    // preview: candidate VMs joined to the GLOBAL vm_profiles catalogue
    if (/FROM `fmb_cap_vms` v\s+JOIN `fmb_cap_vm_profiles` p ON p\.id = v\.sizing_profile_id\s+WHERE p\.scenario_id IS NULL/.test(sql)) {
      const profileIds = new Set(state.profiles.map((p) => p.id));
      return state.vms.filter((v) => v.sizing_profile_id && profileIds.has(v.sizing_profile_id));
    }
    // preview: candidate VMs joined to the GLOBAL disk_combos catalogue
    if (/FROM `fmb_cap_vms` v\s+JOIN `fmb_cap_disk_combos` c ON c\.id = v\.disk_combo_id\s+WHERE c\.scenario_id IS NULL/.test(sql)) {
      const comboIds = new Set(state.combos.map((c) => c.id));
      return state.vms.filter((v) => v.disk_combo_id && comboIds.has(v.disk_combo_id));
    }
    // apply: UNLOCKED candidate probe — which profile ids this scenario's VMs
    // reference (round 3 lock-order fix: runs BEFORE the catalogue lock, so it
    // carries no alias and no FOR UPDATE, unlike the locked read below).
    if (/^SELECT sizing_profile_id FROM `fmb_cap_vms`\s+WHERE scenario_id = \? AND sizing_profile_id IS NOT NULL$/.test(sql)) {
      return state.vms
        .filter((v) => ciEq(v.scenario_id, params[0]) && v.sizing_profile_id)
        .map((v) => ({ sizing_profile_id: v.sizing_profile_id }));
    }
    // apply: UNLOCKED candidate probe — which combo ids this scenario's VMs reference.
    if (/^SELECT disk_combo_id FROM `fmb_cap_vms`\s+WHERE scenario_id = \? AND disk_combo_id IS NOT NULL$/.test(sql)) {
      return state.vms
        .filter((v) => ciEq(v.scenario_id, params[0]) && v.disk_combo_id)
        .map((v) => ({ disk_combo_id: v.disk_combo_id }));
    }
    // apply: lock a scenario's profiled VMs (AFTER the catalogue lock — round 3).
    // Returned rows carry their OWN stored-casing scenario_id — a real
    // `SELECT` never echoes the query PARAMETER's casing back.
    if (/FROM `fmb_cap_vms` v\s+WHERE v\.scenario_id = \? AND v\.sizing_profile_id IS NOT NULL FOR UPDATE/.test(sql)) {
      return state.vms.filter((v) => ciEq(v.scenario_id, params[0]) && v.sizing_profile_id);
    }
    // apply: lock a scenario's combo-referencing VMs (AFTER the catalogue lock — round 3)
    if (/FROM `fmb_cap_vms` v\s+WHERE v\.scenario_id = \? AND v\.disk_combo_id IS NOT NULL FOR UPDATE/.test(sql)) {
      return state.vms.filter((v) => ciEq(v.scenario_id, params[0]) && v.disk_combo_id);
    }
    // profile lookups (preview: bare id IN; apply: scenario_id IS NULL AND id IN)
    if (/FROM `fmb_cap_vm_profiles` WHERE (?:scenario_id IS NULL AND )?id IN/.test(sql)) {
      const wanted = new Set(params);
      return state.profiles.filter((p) => wanted.has(p.id));
    }
    // combo lookups
    if (/FROM `fmb_cap_disk_combos` WHERE (?:scenario_id IS NULL AND )?id IN/.test(sql)) {
      const wanted = new Set(params);
      return state.combos.filter((c) => wanted.has(c.id));
    }
    // formula constants — preview (multi-scenario) or apply (single-scenario)
    if (/FROM `fmb_cap_settings` WHERE scenario_id IN/.test(sql)) return state.settings;
    if (/FROM `fmb_cap_settings` WHERE scenario_id = \? OR scenario_id IS NULL/.test(sql)) {
      return state.settings.filter((s) => ciEq(s.scenario_id, params[0]));
    }
    // apply writes
    if (/^UPDATE `fmb_cap_vms` SET .+ WHERE id = \? AND scenario_id = \?/.test(sql)) {
      const vm = state.vms.find(
        (v) => v.id === params[params.length - 2] && ciEq(v.scenario_id, params[params.length - 1]),
      );
      if (vm) {
        if (sql.includes('cpu = ?') && sql.includes('mem_gb = ?')) { [vm.cpu, vm.mem_gb] = params; }
        else if (sql.includes('cpu = ?')) { [vm.cpu] = params; }
        else if (sql.includes('mem_gb = ?')) { [vm.mem_gb] = params; }
        else if (sql.includes('disk_gb = ?')) { [vm.disk_gb] = params; }
      }
      return { affectedRows: vm ? 1 : 0 };
    }
    return [];
  },
};

// X1 (review round 2): preview must read from pool.rw (writer), never pool.ro,
// so a read-after-write global PUT is never answered from a lagging replica.
// DISTINCT ro/rw facades — same underlying `conn.query` (the fixture logic
// stays in one place), but each tracks its OWN direct-query call count so a
// regression back to pool.ro is a mock-level pin, not just a behavior guess.
let roDirectQueries; let rwDirectQueries;
const roPoolFacade = {
  getConnection: async () => conn,
  query: (sql, params) => { roDirectQueries.push(sql); return conn.query(sql, params); },
};
const rwPoolFacade = {
  getConnection: async () => conn,
  query: (sql, params) => { rwDirectQueries.push(sql); return conn.query(sql, params); },
};
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: { ro: roPoolFacade, rw: rwPoolFacade }, t: (n) => `fmb_${n}` },
};

const router = require('../../../../src/edge/routes/app/capacity');

let currentUser; let server; let baseUrl;
before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { req.user = currentUser; next(); });
  app.use('/capacity', router);
  server = http.createServer(app);
  await new Promise((r) => server.listen(0, r));
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});
after(() => server && server.close());
beforeEach(() => {
  state = freshState();
  currentUser = { id: 'u-admin', role: 'admin' };
  roDirectQueries = []; rwDirectQueries = [];
});

function request(method, path, body) {
  return new Promise((resolve, reject) => {
    const payload = body === undefined ? '' : JSON.stringify(body);
    const r = http.request(
      `${baseUrl}${path}`,
      { method, headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) } },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          const raw = Buffer.concat(chunks).toString('utf8');
          let json = null;
          try { json = JSON.parse(raw); } catch { /* noop */ }
          resolve({ status: res.statusCode, json, raw });
        });
      },
    );
    r.on('error', reject);
    if (payload) r.write(payload);
    r.end();
  });
}

describe('GET /capacity/config/:group/propagation-preview', () => {
  it('vm_profiles: groups drift into one row per affected scenario', async () => {
    const res = await request('GET', '/capacity/config/vm_profiles/propagation-preview');
    assert.equal(res.status, 200, res.raw);
    const { scenarios } = res.json.data;
    assert.equal(scenarios.length, 1); // only s1 (v1) drifted; s2 (v2) already matched
    assert.equal(scenarios[0].scenarioId, 's1');
    assert.equal(scenarios[0].scenarioName, 'Alpha');
    assert.equal(scenarios[0].vmCount, 1);
    assert.deepEqual(scenarios[0].items.map((i) => i.field).sort(), ['cpu', 'mem_gb']);
  });

  it('disk_combos: groups drift into one row per affected scenario', async () => {
    const res = await request('GET', '/capacity/config/disk_combos/propagation-preview');
    assert.equal(res.status, 200, res.raw);
    const { scenarios } = res.json.data;
    assert.equal(scenarios.length, 1);
    assert.equal(scenarios[0].scenarioId, 's1');
    assert.equal(scenarios[0].items[0], scenarios[0].items.find((i) => i.field === 'disk_gb'));
    assert.equal(scenarios[0].items[0].oldValue, 512);
    assert.equal(scenarios[0].items[0].newValue, 2560);
  });

  it('hardware_specs: always empty — no materialized local copy exists to drift', async () => {
    const res = await request('GET', '/capacity/config/hardware_specs/propagation-preview');
    assert.equal(res.status, 200, res.raw);
    assert.deepEqual(res.json.data.scenarios, []);
    // No DB round trip for a group with nothing to detect.
    assert.equal(state.queries.length, 0);
  });

  it('a plain user (not editor/admin) is refused 403', async () => {
    currentUser = { id: 'u-user', role: 'user' };
    const res = await request('GET', '/capacity/config/vm_profiles/propagation-preview');
    assert.equal(res.status, 403, res.raw);
  });

  it('empty when nothing has drifted', async () => {
    state.vms = state.vms.map((v) => ({ ...v, cpu: 16, mem_gb: 320 }));
    const res = await request('GET', '/capacity/config/vm_profiles/propagation-preview');
    assert.equal(res.status, 200, res.raw);
    assert.deepEqual(res.json.data.scenarios, []);
  });

  it('reports truncated: false when the drifted scenario count is within bounds', async () => {
    const res = await request('GET', '/capacity/config/vm_profiles/propagation-preview');
    assert.equal(res.status, 200, res.raw);
    assert.equal(res.json.data.truncated, false);
  });

  // X1 (review round 2): both cards call preview immediately after their own
  // global-catalogue PUT commits (read-after-write). A pool.ro read could hit
  // a lagging replica, see the OLD catalogue row, and report no drift — the
  // save silently fails to propagate with no error anywhere.
  it('reads exclusively from the writer pool (read-after-write), never pool.ro', async () => {
    const res = await request('GET', '/capacity/config/vm_profiles/propagation-preview');
    assert.equal(res.status, 200, res.raw);
    assert.equal(roDirectQueries.length, 0, `pool.ro must not answer the preview; saw: ${roDirectQueries.join(' | ')}`);
    assert.ok(rwDirectQueries.length > 0, 'pool.rw must answer the preview');
  });

  it('disk_combos preview also reads exclusively from the writer pool', async () => {
    const res = await request('GET', '/capacity/config/disk_combos/propagation-preview');
    assert.equal(res.status, 200, res.raw);
    assert.equal(roDirectQueries.length, 0, `pool.ro must not answer the preview; saw: ${roDirectQueries.join(' | ')}`);
    assert.ok(rwDirectQueries.length > 0, 'pool.rw must answer the preview');
  });

  // F5 (review): the preview's own JOIN carries no scenario filter
  // (unlike apply, which is always scoped to the caller's scenarioIds), so
  // it is the one unbounded side of the pair. Bound it symmetrically to
  // apply's MAX_PROPAGATION_SCENARIOS (2000) and say so in the payload.
  it('caps the response at 2000 scenarios and reports truncated: true beyond that', async () => {
    const extra = Array.from({ length: 2005 }, (_, i) => ({
      id: `vx${i}`, scenario_id: `sx${i}`, name: `vx${i}`, cpu: 8, mem_gb: 160,
      sizing_profile_id: 'p1', disk_combo_id: null, disk_gb: 0,
    }));
    state.vms = [...state.vms, ...extra];
    const res = await request('GET', '/capacity/config/vm_profiles/propagation-preview');
    assert.equal(res.status, 200, res.raw);
    const { scenarios, truncated } = res.json.data;
    assert.equal(truncated, true);
    assert.equal(scenarios.length, 2000);
  });
});

describe('POST /capacity/config/:group/propagation-apply', () => {
  it('applies the current global profile sizing to every stale VM in the selected scenario', async () => {
    const res = await request('POST', '/capacity/config/vm_profiles/propagation-apply', { scenarioIds: ['s1'] });
    assert.equal(res.status, 200, res.raw);
    assert.deepEqual(res.json.data.results, [{ scenarioId: 's1', status: 'applied', vmsUpdated: 1 }]);
    const v1 = state.vms.find((v) => v.id === 'v1');
    assert.equal(v1.cpu, 16);
    assert.equal(v1.mem_gb, 320);
    assert.equal(state.began, 1);
    assert.equal(state.committed, 1);
    assert.equal(state.rolledBack, 0);
  });

  it('applies disk_gb from the current global combo', async () => {
    const res = await request('POST', '/capacity/config/disk_combos/propagation-apply', { scenarioIds: ['s1'] });
    assert.equal(res.status, 200, res.raw);
    assert.deepEqual(res.json.data.results, [{ scenarioId: 's1', status: 'applied', vmsUpdated: 1 }]);
    assert.equal(state.vms.find((v) => v.id === 'v3').disk_gb, 2560);
  });

  it('a scenario already at the current values applies zero — idempotent re-run, not an error', async () => {
    const res = await request('POST', '/capacity/config/vm_profiles/propagation-apply', { scenarioIds: ['s2'] });
    assert.equal(res.status, 200, res.raw);
    assert.deepEqual(res.json.data.results, [{ scenarioId: 's2', status: 'applied', vmsUpdated: 0 }]);
  });

  it('PARTIAL FAILURE: one forbidden scenario does not block the others in the same batch', async () => {
    currentUser = { id: 'u-other-editor', role: 'editor' };
    state.scenarios.s1.owner_id = 'u-owner'; // caller does not own s1
    // s2 is shared (owner_id null) — this editor may write it.
    const res = await request('POST', '/capacity/config/vm_profiles/propagation-apply', { scenarioIds: ['s1', 's2'] });
    assert.equal(res.status, 200, res.raw);
    assert.deepEqual(res.json.data.results, [
      { scenarioId: 's1', status: 'forbidden', vmsUpdated: 0 },
      { scenarioId: 's2', status: 'applied', vmsUpdated: 0 },
    ]);
    // s1's VM must be untouched — the forbidden scenario's transaction rolled back.
    assert.equal(state.vms.find((v) => v.id === 'v1').cpu, 8);
    assert.equal(state.rolledBack, 1);
    assert.equal(state.committed, 1);
  });

  // Y2 (P2, review round 3): a case-variant caller-supplied scenario id still
  // matches the row under the column's case-insensitive collation, but the
  // apply helper's formula-by-scenario map must be keyed by the STORED
  // casing (same as the VM rows it reads back), not the request's spelling —
  // otherwise the lookup misses and silently falls back to DEFAULT_FORMULA.
  it('canonicalizes a case-variant scenario id before deriving — writes the SCENARIO formula, not DEFAULT_FORMULA', async () => {
    // s1's own settings override: memCpuRatio 10, not DEFAULT_FORMULA's 20 —
    // so a formula-lookup MISS (falling back to DEFAULT_FORMULA) writes a
    // DIFFERENT, provably wrong mem_gb, not a value that happens to coincide.
    state.settings = [{
      scenario_id: 's1', mem_cpu_ratio: 10, sga_factor: null, sga_divisor: null, sga_subtract: null,
    }];
    const res = await request('POST', '/capacity/config/vm_profiles/propagation-apply', { scenarioIds: ['S1'] });
    assert.equal(res.status, 200, res.raw);
    // p1 is formula-mode cpu=16: mem_gb = 16 * 10 = 160 under s1's OWN formula,
    // vs 16 * 20 = 320 under DEFAULT_FORMULA (the pre-fix wrong value).
    const v1 = state.vms.find((v) => v.id === 'v1');
    assert.equal(v1.mem_gb, 160);
    // The result entry echoes the CANONICAL (stored-casing) id, not the
    // request's 'S1' spelling.
    assert.deepEqual(res.json.data.results, [{ scenarioId: 's1', status: 'applied', vmsUpdated: 1 }]);
  });

  it('PARTIAL FAILURE: a missing scenario id reports not_found and the batch continues', async () => {
    const res = await request('POST', '/capacity/config/vm_profiles/propagation-apply', { scenarioIds: ['nope', 's1'] });
    assert.equal(res.status, 200, res.raw);
    assert.deepEqual(res.json.data.results, [
      { scenarioId: 'nope', status: 'not_found', vmsUpdated: 0 },
      { scenarioId: 's1', status: 'applied', vmsUpdated: 1 },
    ]);
  });

  it('a plain user (not editor/admin) is refused 403, nothing applied', async () => {
    currentUser = { id: 'u-user', role: 'user' };
    const res = await request('POST', '/capacity/config/vm_profiles/propagation-apply', { scenarioIds: ['s1'] });
    assert.equal(res.status, 403, res.raw);
    assert.equal(state.vms.find((v) => v.id === 'v1').cpu, 8);
  });

  it('rejects a missing/empty scenarioIds (400)', async () => {
    const res = await request('POST', '/capacity/config/vm_profiles/propagation-apply', {});
    assert.equal(res.status, 400, res.raw);
  });

  it('rejects an unpropagatable group (hardware_specs) — 400, distinct from an empty preview', async () => {
    const res = await request('POST', '/capacity/config/hardware_specs/propagation-apply', { scenarioIds: ['s1'] });
    assert.equal(res.status, 400, res.raw);
  });

  it('rejects an oversized scenarioIds array (400, defense-in-depth bound)', async () => {
    const scenarioIds = Array.from({ length: 2001 }, (_, i) => `s${i}`);
    const res = await request('POST', '/capacity/config/vm_profiles/propagation-apply', { scenarioIds });
    assert.equal(res.status, 400, res.raw);
    assert.equal(state.began, 0);
  });
});

