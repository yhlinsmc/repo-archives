'use strict';

/**
 * template-snapshots.test.js — who may read/write a record's snapshots, that
 * a snapshot never becomes a run, and that the write path is bounded.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../../../src/edge/db');

let queries;
let templateRow;      // the record the snapshots belong to, or null
let grantRows;        // what the grant lookup finds
let grantsTablePresent; // whether the grants table probe finds the table
let snapshotsTablePresent; // whether the snapshots table probe finds the table
let snapshotRows;      // what the list read returns
let deleteExisting;    // what the delete's ownership probe finds

function makeConn() {
  return {
    async query(sql, params = []) {
      queries.push({ sql, params });
      if (/information_schema\.TABLES/i.test(sql)) {
        const [name] = params;
        if (String(name).endsWith('delegated_grants')) return grantsTablePresent ? [{ 1: 1 }] : [];
        if (String(name).endsWith('template_snapshots')) return snapshotsTablePresent ? [{ 1: 1 }] : [];
        return [];
      }
      if (/^INSERT INTO `fmb_template_snapshots`/.test(sql)) return { affectedRows: 1 };
      if (/^DELETE FROM `fmb_template_snapshots`/.test(sql)) return { affectedRows: 1 };
      if (/FROM `fmb_template_snapshots`.*FOR UPDATE/is.test(sql)) return deleteExisting;
      if (/FROM `fmb_user_templates`/.test(sql)) return templateRow ? [templateRow] : [];
      if (/FROM `fmb_hierarchy_nodes`/.test(sql)) return [];
      if (/FROM `fmb_delegated_grants`/.test(sql)) return grantRows;
      if (/FROM `fmb_template_snapshots`/.test(sql)) return snapshotRows;
      return [];
    },
    release() {},
  };
}

const poolFacade = { async getConnection() { return makeConn(); } };

require.cache[dbKey] = {
  id: dbKey,
  filename: dbKey,
  loaded: true,
  exports: {
    pool: { ro: poolFacade, rw: poolFacade },
    t: (n) => `fmb_${n}`,
    getDynamicPool: async () => ({ ro: poolFacade, rw: poolFacade }),
  },
};

const router = require('../../../../src/edge/routes/app/template-snapshots');
const { _resetGrantsTableCache } = require('../../../../src/edge/lib/delegated-grants');

const OWNER = { id: '11111111-1111-1111-1111-111111111111', role: 'user' };
const GRANTEE = { id: '22222222-2222-2222-2222-222222222222', role: 'user' };
const STRANGER = { id: '33333333-3333-3333-3333-333333333333', role: 'user' };
const ADMIN = { id: '44444444-4444-4444-4444-444444444444', role: 'admin' };
const TEMPLATE = 'bbbbbbbb-0000-0000-0000-00000000000b';
const SNAPSHOT = 'cccccccc-0000-0000-0000-00000000000c';

let currentUser;
let server;
let baseUrl;

before(async () => {
  const app = express();
  // Same limit index-edge.js configures in production (ARCH-5) — the default
  // express.json() 100kb cap would 413 a well-under-MAX_SNAPSHOT_BYTES body
  // before the route's own size check ever runs.
  app.use(express.json({ limit: '10mb' }));
  app.use((req, _res, next) => { if (currentUser) req.user = currentUser; next(); });
  app.use('/edge/app/templates', router);
  server = http.createServer(app);
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});

after(async () => { await new Promise((r) => server.close(r)); });

beforeEach(() => {
  queries = [];
  templateRow = { id: TEMPLATE, owner_id: OWNER.id, blueprint_id: 'bp-1' };
  grantRows = [];
  grantsTablePresent = true;
  snapshotsTablePresent = true;
  snapshotRows = [];
  deleteExisting = [{ id: SNAPSHOT }];
  currentUser = OWNER;
  _resetGrantsTableCache();
});

async function call(method, path, body) {
  const res = await fetch(`${baseUrl}/edge/app/templates${path}`, {
    method,
    headers: { 'content-type': 'application/json' },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const json = await res.json().catch(() => ({}));
  return { status: res.status, json };
}

const validSnapshot = { entered: { a: '1' }, computed: {}, outputs: {}, fields: [] };

describe('who may read and write a record\'s snapshots', () => {
  it('its owner may list', async () => {
    const res = await call('GET', `/${TEMPLATE}/snapshots`);
    assert.equal(res.status, 200);
  });

  it('an administrator may list', async () => {
    currentUser = ADMIN;
    const res = await call('GET', `/${TEMPLATE}/snapshots`);
    assert.equal(res.status, 200);
  });

  it('someone the owner delegated to may list', async () => {
    currentUser = GRANTEE;
    grantRows = [{ granted: 1 }];
    const res = await call('GET', `/${TEMPLATE}/snapshots`);
    assert.equal(res.status, 200);
  });

  it('everyone else is answered as though the record were not there', async () => {
    currentUser = STRANGER;
    const res = await call('GET', `/${TEMPLATE}/snapshots`);
    assert.equal(res.status, 404);
  });

  it('a record that does not exist is the same answer', async () => {
    templateRow = null;
    const res = await call('GET', `/${TEMPLATE}/snapshots`);
    assert.equal(res.status, 404);
  });

  it('an anonymous caller reaches no statement at all', async () => {
    currentUser = null;
    const res = await call('GET', `/${TEMPLATE}/snapshots`);
    assert.equal(res.status, 401);
    assert.equal(queries.length, 0);
  });

  it('a stranger may not save a snapshot', async () => {
    currentUser = STRANGER;
    const res = await call('POST', `/${TEMPLATE}/snapshots`, { name: 'x', snapshot: validSnapshot });
    assert.equal(res.status, 404);
    assert.equal(queries.filter((q) => /^INSERT/.test(q.sql)).length, 0);
  });

  it('a stranger may not delete a snapshot', async () => {
    currentUser = STRANGER;
    const res = await call('DELETE', `/${TEMPLATE}/snapshots/${SNAPSHOT}`);
    assert.equal(res.status, 404);
    assert.equal(queries.filter((q) => /^DELETE/.test(q.sql)).length, 0);
  });
});

describe('saving a snapshot', () => {
  it('requires a name', async () => {
    const res = await call('POST', `/${TEMPLATE}/snapshots`, { snapshot: validSnapshot });
    assert.equal(res.status, 400);
  });

  it('requires an object snapshot document', async () => {
    const res = await call('POST', `/${TEMPLATE}/snapshots`, { name: 'x', snapshot: 'not-an-object' });
    assert.equal(res.status, 400);
  });

  it('refuses an oversized snapshot document', async () => {
    const huge = { entered: { blob: 'x'.repeat(3 * 1024 * 1024) } };
    const res = await call('POST', `/${TEMPLATE}/snapshots`, { name: 'x', snapshot: huge });
    assert.equal(res.status, 400);
  });

  it('stamps the actor from the session, never from the body', async () => {
    const res = await call('POST', `/${TEMPLATE}/snapshots`, {
      name: 'Pre-dispatch check', snapshot: validSnapshot, actor_id: 'somebody-else',
    });
    assert.equal(res.status, 201);
    const insert = queries.find((q) => /^INSERT INTO `fmb_template_snapshots`/.test(q.sql));
    const [, templateId, name, , , , , actorId] = insert.params;
    assert.equal(templateId, TEMPLATE);
    assert.equal(name, 'Pre-dispatch check');
    assert.equal(actorId, OWNER.id, 'the actor was read from the body rather than the session');
  });

  it('never writes flow_recipe_runs', async () => {
    await call('POST', `/${TEMPLATE}/snapshots`, { name: 'x', snapshot: validSnapshot });
    assert.equal(queries.filter((q) => /flow_recipe_runs/i.test(q.sql)).length, 0);
  });
});

describe('M6 (review r1) — the list is bounded, never unbounded', () => {
  it('binds the default page size when the caller supplies no query at all', async () => {
    const res = await call('GET', `/${TEMPLATE}/snapshots`);
    assert.equal(res.status, 200);
    const select = queries.find((q) => /^\s*SELECT .* FROM `fmb_template_snapshots`/is.test(q.sql) && /LIMIT/i.test(q.sql));
    assert.ok(select, 'the list read must bind a LIMIT');
    assert.deepEqual(select.params, [TEMPLATE, 50, 0]);
  });

  it('respects an explicit limit/offset', async () => {
    const res = await call('GET', `/${TEMPLATE}/snapshots?limit=5&offset=10`);
    assert.equal(res.status, 200);
    const select = queries.find((q) => /^\s*SELECT .* FROM `fmb_template_snapshots`/is.test(q.sql) && /LIMIT/i.test(q.sql));
    assert.deepEqual(select.params, [TEMPLATE, 5, 10]);
  });

  it('rejects a limit above the shared MAX_PAGE_SIZE ceiling rather than silently truncating it', async () => {
    const res = await call('GET', `/${TEMPLATE}/snapshots?limit=999999&offset=0`);
    assert.equal(res.status, 400);
    assert.equal(queries.filter((q) => /^\s*SELECT .* FROM `fmb_template_snapshots`/is.test(q.sql)).length, 0);
  });

  it('rejects a non-numeric limit', async () => {
    const res = await call('GET', `/${TEMPLATE}/snapshots?limit=abc&offset=0`);
    assert.equal(res.status, 400);
  });
});

describe('P2-1 (review r2) — the snapshots table can be absent on a degraded schema', () => {
  it('GET answers 200 with an empty, flagged list rather than 500', async () => {
    snapshotsTablePresent = false;
    const res = await call('GET', `/${TEMPLATE}/snapshots`);
    assert.equal(res.status, 200);
    assert.deepEqual(res.json.data.items, []);
    assert.equal(res.json.data.unavailable, true);
    assert.equal(typeof res.json.data.reason, 'string');
    assert.equal(
      queries.filter((q) => /^\s*SELECT .* FROM `fmb_template_snapshots`\s+WHERE template_id/is.test(q.sql)).length,
      0,
      'the bounded list read is never issued once the table is known absent',
    );
  });

  it('a present table answers unavailable: false, not just an empty list', async () => {
    const res = await call('GET', `/${TEMPLATE}/snapshots`);
    assert.equal(res.status, 200);
    assert.equal(res.json.data.unavailable, false);
    assert.deepEqual(res.json.data.items, []);
  });

  it('POST is refused with a non-500 status and a clear code, never an INSERT attempt', async () => {
    snapshotsTablePresent = false;
    const res = await call('POST', `/${TEMPLATE}/snapshots`, { name: 'x', snapshot: validSnapshot });
    assert.notEqual(res.status, 500);
    assert.equal(res.status, 503);
    assert.equal(res.json.error.code, 'SNAPSHOTS_UNAVAILABLE');
    assert.equal(queries.filter((q) => /^INSERT INTO `fmb_template_snapshots`/.test(q.sql)).length, 0);
  });

  it('DELETE is refused with a non-500 status and a clear code, never a DELETE attempt', async () => {
    snapshotsTablePresent = false;
    const res = await call('DELETE', `/${TEMPLATE}/snapshots/${SNAPSHOT}`);
    assert.notEqual(res.status, 500);
    assert.equal(res.status, 503);
    assert.equal(res.json.error.code, 'SNAPSHOTS_UNAVAILABLE');
    assert.equal(queries.filter((q) => /^DELETE FROM `fmb_template_snapshots`/.test(q.sql)).length, 0);
  });
});

describe('deleting a snapshot', () => {
  it('is scoped to the named template — a snapshot of another template 404s', async () => {
    deleteExisting = [];
    const res = await call('DELETE', `/${TEMPLATE}/snapshots/${SNAPSHOT}`);
    assert.equal(res.status, 404);
  });

  it('deletes the row bound to both ids', async () => {
    const res = await call('DELETE', `/${TEMPLATE}/snapshots/${SNAPSHOT}`);
    assert.equal(res.status, 200);
    const del = queries.find((q) => /^DELETE FROM `fmb_template_snapshots`/.test(q.sql));
    assert.deepEqual(del.params, [SNAPSHOT, TEMPLATE]);
  });
});
