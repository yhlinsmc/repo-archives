'use strict';

/**
 * template-snapshots-schema-parity.test.js — the columns the snapshot route
 * (template-snapshots.js) reads and writes, checked against the ACTUAL table
 * DDL in table-ddls.js, without a live DB. A mocked-query test alone would
 * stay green even if a column name here drifted from the DDL (the mock never
 * checks the SQL against a real schema) — this test closes that gap.
 */
const { describe, it, before } = require('node:test');
const assert = require('node:assert/strict');

const dbKey = require.resolve('../../../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: {}, t: (n) => n },
};

const { buildEngineTableDDLs, ENGINE_TABLE_NAMES } = require('../../../../src/table-ddls');

const SQL_TYPES = /^`?([a-z_]+)`?\s+(?:CHAR|VARCHAR|INT|DOUBLE|TIMESTAMP|JSON|TEXT|ENUM|BOOLEAN|TINYINT|BIGINT|DATETIME|DECIMAL|FLOAT|BLOB|LONGTEXT)\b/i;
let columns;

before(() => {
  columns = null;
  for (const ddl of buildEngineTableDDLs((n) => n)) {
    const m = ddl.match(/CREATE TABLE IF NOT EXISTS `([^`]+)`/);
    if (!m || m[1] !== 'template_snapshots') continue;
    const cols = new Set();
    for (const rawLine of ddl.split('\n')) {
      const line = rawLine.trim();
      if (!line || line.startsWith('--') || line.startsWith('/*')) continue;
      const cm = line.match(SQL_TYPES);
      if (cm) cols.add(cm[1]);
    }
    columns = cols;
  }
});

describe('template_snapshots schema parity', () => {
  it('the table exists in the engine DDL set', () => {
    assert.ok(columns, 'template_snapshots was not found in buildEngineTableDDLs()');
  });

  it('is registered in ENGINE_TABLE_NAMES (export/seed table list)', () => {
    assert.ok(ENGINE_TABLE_NAMES.includes('template_snapshots'));
  });

  // Every column template-snapshots.js's route SQL references — the route
  // file's own SELECT/INSERT column lists, restated here as a literal check
  // against the parsed DDL rather than re-imported, so a rename on one side
  // without the other fails this test instead of 500ing in production.
  it('has every column the route reads and writes', () => {
    const expected = [
      'id', 'template_id', 'name', 'note', 'blueprint_id', 'variant_id',
      'snapshot', 'actor_id', 'created_at',
    ];
    for (const col of expected) {
      assert.ok(columns.has(col), `template_snapshots is missing column '${col}'`);
    }
  });

  it('snapshot is LONGTEXT (unbounded-enough for a full form document)', () => {
    const ddl = buildEngineTableDDLs((n) => n).find((d) => d.includes('CREATE TABLE IF NOT EXISTS `template_snapshots`'));
    assert.match(ddl, /snapshot\s+LONGTEXT\s+NOT NULL/);
  });

  it('carries the template_id + created_at composite index the list route sorts on', () => {
    const ddl = buildEngineTableDDLs((n) => n).find((d) => d.includes('CREATE TABLE IF NOT EXISTS `template_snapshots`'));
    assert.match(ddl, /INDEX idx_template_snapshots_template_time \(template_id, created_at\)/);
  });
});
