/**
 * capacity-renumber.test.js — the B5b Renumber routes: a read-only preview and a
 * transactional apply (spec B5 Q18/Q20). Drag reorder never renames; this action
 * is the only path that re-sequences hostnames. Same ownership contract as the
 * reorder routes (admin+editor, owner-or-shared), same FOR UPDATE lock discipline
 * on apply. Numbering is fork-2 wizard-consistent: group by resolved {dc} slug,
 * seq 1..k per group in order_index order, pad width grows with the group.
 *
 * The pool is mocked; the mock SIMULATES the DB's ORDER BY so preview order and
 * the apply's id-order FOR UPDATE scan (re-sorted in JS to display order) are both
 * exercised faithfully.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../../../src/edge/db');

let state;
function freshState() {
  return {
    queries: [],
    began: 0, committed: 0, rolledBack: 0, released: 0,
    scenarioExists: true,
    scenarioOwner: null,
    // cap_settings physical columns (the information_schema probe). Present state
    // carries name_patterns; the degraded case drops it to exercise the READ-side
    // fallback to built-in defaults.
    settingsColumns: ['id', 'scenario_id', 'name_patterns', 'mem_cpu_ratio'],
    // cap_hypervisors / cap_vms physical columns (the name_locked probe,
    // cap-renumber-lock). Present by default; degraded-schema absence is not
    // exercised by this file (see capacity-renumber-lock.test.js).
    entityColumns: ['id', 'name', 'order_index', 'site_id', 'vm_type', 'name_locked', 'function_name'],
    // cap_settings: a scenario override row (null = no row) + the global row's
    // name_patterns (null = built-in defaults).
    scenarioSettings: null,
    globalPatterns: null,
    sites: [{ id: 's1', name: 'DC-1' }, { id: 's2', name: 'DC-2' }],
    // Default fixture: 3 hypervisors (2 at s1, 1 at s2), 2 db_host KVMs, 2 unplaced
    // ap_host VMs — oldNames deliberately NON-sequential so every name changes.
    hypervisors: [
      { id: 'h1', name: 'old-h1', order_index: 0, site_id: 's1' },
      { id: 'h2', name: 'old-h2', order_index: 1, site_id: 's1' },
      { id: 'h3', name: 'old-h3', order_index: 2, site_id: 's2' },
    ],
    vms: [
      { id: 'k1', name: 'old-k1', order_index: 0, site_id: 's1', vm_type: 'db_host' },
      { id: 'k2', name: 'old-k2', order_index: 1, site_id: 's2', vm_type: 'db_host' },
      { id: 'a1', name: 'old-a1', order_index: 0, site_id: null, vm_type: 'ap_host' },
      { id: 'a2', name: 'old-a2', order_index: 1, site_id: null, vm_type: 'ap_host' },
    ],
    // cap_db_instances / cap_databases (PR-3 contents + role/function source).
    // Default empty — the base fixtures exercise the no-instances path; the
    // contents cases below populate them.
    dbInstances: [],
    databases: [],
    // spec §7 E2: readDbInstanceRows' OWN fixture set, deliberately separate
    // from `dbInstances` above (that one feeds readHostFunctionRoles, whose
    // fixtures are role-only stubs with no `id`/`name` — feeding them into the
    // renumber recompute too would fabricate spurious renames). Default empty.
    dbInstanceRows: [],
    // X1/X2 (Codex round-1 outside voice): an OPTIONAL explicit relational
    // fixture — [{ id, function_name, topology, scenario_id }] — modelling
    // cap_databases rows directly. When set (non-null), BOTH the preview
    // join AND the apply lock path resolve a dbInstanceRows entry's
    // `database_id` against THIS table (case-insensitive id fold + scenario_id
    // match, mirroring the real SQL), instead of the simpler denormalized
    // function_name/topology fields on dbInstanceRows itself — the only way
    // to model a database whose id differs in CASE from the instance's
    // stored database_id (X1), or that belongs to a DIFFERENT scenario (X2),
    // without touching every other dbInstanceRows fixture in this file. null
    // (default) preserves the pre-existing denormalized-fixture behavior for
    // every test that does not care about this distinction.
    dbInstanceDatabases: null,
  };
}

/** X1/X2 mock helper: resolve one `database_id` against `state.dbInstanceDatabases`
 *  (when set) — case-folded id match (ASCII hex + hyphens, the same CHAR(36)
 *  collation reasoning the route's own comment carries) AND an exact
 *  scenario_id match, mirroring the real SQL join/WHERE. Returns the matching
 *  fixture row (with its OWN canonical `id` spelling) or null. */
function resolveDbInstanceDatabase(state, databaseId, scenarioId) {
  if (!databaseId || !state.dbInstanceDatabases) return null;
  return state.dbInstanceDatabases.find(
    (d) => d.scenario_id === scenarioId && String(d.id).toLowerCase() === String(databaseId).toLowerCase(),
  ) || null;
}

function sortForSql(rows, sql) {
  const out = [...rows];
  if (/ORDER BY order_index/.test(sql)) {
    out.sort((a, b) => (a.order_index - b.order_index) || (a.id < b.id ? -1 : 1));
  } else if (/ORDER BY id FOR UPDATE/.test(sql)) {
    out.sort((a, b) => (a.id < b.id ? -1 : a.id > b.id ? 1 : 0));
  }
  return out;
}

const conn = {
  async beginTransaction() { state.began += 1; },
  async commit() { state.committed += 1; },
  async rollback() { state.rolledBack += 1; },
  release() { state.released += 1; },
  async query(sql, params = []) {
    state.queries.push({ sql, params });

    if (/information_schema\.COLUMNS/.test(sql)) {
      // The degraded-schema column probe (tableColumnSet). Discriminate by the
      // physical table name bound as the query param: cap_settings's probe
      // (name_patterns) must not be handed cap_hypervisors/cap_vms's column
      // list (name_locked) and vice versa.
      if (params[0] === 'fmb_cap_settings') return state.settingsColumns.map((name) => ({ name }));
      return state.entityColumns.map((name) => ({ name }));
    }
    if (/SELECT id, owner_id FROM `fmb_cap_scenarios` WHERE id = \?/.test(sql)) {
      return state.scenarioExists ? [{ id: params[0], owner_id: state.scenarioOwner }] : [];
    }
    if (/SELECT scenario_id, name_patterns FROM `fmb_cap_settings` WHERE scenario_id = \?/.test(sql)) {
      return state.scenarioSettings
        ? [{ scenario_id: params[0], name_patterns: state.scenarioSettings.name_patterns }]
        : [];
    }
    if (/SELECT scenario_id, name_patterns FROM `fmb_cap_settings` WHERE scenario_id IS NULL/.test(sql)) {
      return [{ scenario_id: null, name_patterns: state.globalPatterns }];
    }
    if (/SELECT id, name FROM `fmb_cap_sites` WHERE scenario_id = \?/.test(sql)) {
      return state.sites.map((s) => ({ id: s.id, name: s.name }));
    }
    if (/FROM `fmb_cap_hypervisors` WHERE scenario_id = \?/.test(sql)) {
      return sortForSql(state.hypervisors, sql).map((r) => ({ ...r }));
    }
    if (/FROM `fmb_cap_vms` WHERE scenario_id = \?/.test(sql)) {
      // Unfiltered single pass — the route splits db_host / ap_host in JS.
      return sortForSql(state.vms, sql).map((r) => ({ ...r }));
    }
    // readDbInstanceRows LOCK path (spec §7 E2, F2): cap_db_instances ALONE,
    // no join — cap_databases must never be locked by this route (see the
    // route's own file-header note), so the lock scan is split from the
    // (separate, non-locking) cap_databases read just below.
    if (/SELECT id, name, database_id AS databaseId, role, order_index AS orderIndex/.test(sql)
      && /FROM `fmb_cap_db_instances`/.test(sql) && /FOR UPDATE/.test(sql)) {
      return state.dbInstanceRows.map((inst) => ({
        id: inst.id,
        name: inst.name,
        databaseId: inst.database_id ?? null,
        role: inst.role,
        orderIndex: inst.order_index,
      }));
    }
    // readDbInstanceRows LOCK path's cap_databases companion read (F2): a
    // PLAIN (no FOR UPDATE) scenario-scoped read. X1/X2: when
    // `state.dbInstanceDatabases` is set, return THAT table (scenario-
    // filtered, own canonical id spelling) instead of the denormalized
    // per-instance derivation — the real code's own case-fold Map lookup
    // (readDbInstanceRows) is what gets exercised against it.
    if (/SELECT id, function_name AS functionName, topology/.test(sql) && /FROM `fmb_cap_databases`/.test(sql)) {
      if (state.dbInstanceDatabases) {
        return state.dbInstanceDatabases
          .filter((d) => d.scenario_id === params[0])
          .map((d) => ({ id: d.id, functionName: d.function_name ?? null, topology: d.topology ?? null }));
      }
      const byDbId = new Map();
      for (const inst of state.dbInstanceRows) {
        if (inst.database_id && !byDbId.has(inst.database_id)) {
          byDbId.set(inst.database_id, { id: inst.database_id, functionName: inst.function_name ?? null, topology: inst.topology ?? null });
        }
      }
      return [...byDbId.values()];
    }
    // readDbInstanceRows PREVIEW path (spec §7 E2): cap_db_instances LEFT JOIN
    // cap_databases, keyed by di.id — read-only, no lock, so the single joined
    // query is fine here (only the LOCK path above needs the split, F2).
    // Shares the same FROM/JOIN shape as readHostFunctionRoles' query below
    // (keyed by di.vm_id instead), so this branch is checked FIRST and
    // discriminated by the SELECT list (`di.id AS id`, unique to this query).
    // computeDbInstanceRenumberPlan does its own (databaseId, role) grouping +
    // (order_index, id) ranking in JS, so the array order returned here does
    // not need to match any ORDER BY — fixture order is fine.
    // X1/X2: when `state.dbInstanceDatabases` is set, resolve each instance's
    // `database_id` against it (case-folded id + scenario_id match — the SQL
    // join's own `ON di.database_id = d.id AND d.scenario_id = di.scenario_id`
    // semantics under the CHAR(36) case-folding collation), and report the
    // matched row's OWN `id` (mirrors `COALESCE(d.id, di.database_id)`).
    if (/SELECT di\.id AS id/.test(sql) && /FROM `fmb_cap_db_instances` di/.test(sql)) {
      if (state.dbInstanceDatabases) {
        return state.dbInstanceRows.map((inst) => {
          const db = resolveDbInstanceDatabase(state, inst.database_id, params[0]);
          return {
            id: inst.id,
            name: inst.name,
            databaseId: db ? db.id : (inst.database_id ?? null),
            role: inst.role,
            orderIndex: inst.order_index,
            functionName: db ? (db.function_name ?? null) : null,
            topology: db ? (db.topology ?? null) : null,
          };
        });
      }
      return state.dbInstanceRows.map((inst) => ({
        id: inst.id,
        name: inst.name,
        databaseId: inst.database_id ?? null,
        role: inst.role,
        orderIndex: inst.order_index,
        functionName: inst.function_name ?? null,
        topology: inst.topology ?? null,
      }));
    }
    // readHostFunctionRoles: cap_db_instances LEFT JOIN cap_databases. The route
    // ORDER BYs (order_index, id); the mock preserves fixture order (each test's
    // fixture is already in the order it asserts). instanceName carries the pill
    // name (PR-3 contents).
    // instanceId/instanceOrderIndex (U4, Q7 db_seq source): default to
    // the fixture's own array position — fixture order already IS this query's
    // intended (order_index, id) order in every existing case in this file.
    if (/FROM `fmb_cap_db_instances` di/.test(sql) && /LEFT JOIN `fmb_cap_databases` d/.test(sql)) {
      return state.dbInstances.map((inst, idx) => {
        const db = state.databases.find((d) => d.id === inst.database_id) || null;
        return {
          instanceId: inst.id ?? `di-${idx}`,
          vmId: inst.vm_id,
          instanceName: inst.name,
          role: inst.role,
          instanceOrderIndex: inst.order_index ?? idx,
          functionName: db ? db.function_name : null,
          dbOrderIndex: db ? db.order_index : null,
          dbId: db ? db.id : null,
        };
      });
    }
    if (/^UPDATE `fmb_cap_\w+` SET name = \? WHERE id = \? AND scenario_id = \?/.test(sql)) {
      return { affectedRows: 1 };
    }
    return [];
  },
};

const poolFacade = {
  getConnection: async () => conn,
  query: (sql, params) => conn.query(sql, params),
};
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: { ro: poolFacade, rw: poolFacade }, t: (n) => `fmb_${n}` },
};

const router = require('../../../../src/edge/routes/app/capacity');
// The column-set probe caches per process; reset between cases that flip schema shape.
const { _resetColumnSetCache } = require('../../../../src/edge/routes/app/capacity/_shared');

let currentUser; let server; let baseUrl;
before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { req.user = currentUser; next(); });
  app.use('/capacity', router);
  server = http.createServer(app);
  await new Promise((r) => server.listen(0, r));
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});
after(() => server && server.close());
beforeEach(() => {
  state = freshState();
  currentUser = { id: 'u-admin', role: 'admin' };
  _resetColumnSetCache();
});

function request(method, path, body) {
  return new Promise((resolve, reject) => {
    const payload = body === undefined ? '' : JSON.stringify(body);
    const r = http.request(
      `${baseUrl}${path}`,
      { method, headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) } },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          const raw = Buffer.concat(chunks).toString('utf8');
          let json = null;
          try { json = JSON.parse(raw); } catch { /* noop */ }
          resolve({ status: res.statusCode, json, raw });
        });
      },
    );
    r.on('error', reject);
    if (payload) r.write(payload);
    r.end();
  });
}

const updates = () => state.queries.filter((q) => /^UPDATE `fmb_cap_\w+` SET name/.test(q.sql));
const PREVIEW = '/capacity/scenarios/scn-1/renumber-preview';
const APPLY = '/capacity/scenarios/scn-1/renumber';

describe('POST renumber-preview', () => {
  it('returns the full old→new plan per entity type in display order, no writes', async () => {
    const res = await request('POST', PREVIEW, {});
    assert.equal(res.status, 200, res.raw);
    const plan = res.json.data.rows;
    // 3 hypervisors + 2 db_host + 2 ap_host = 7 rows
    assert.equal(plan.length, 7);
    const byId = Object.fromEntries(plan.map((p) => [p.id, p]));
    assert.deepEqual(
      [byId.h1.newName, byId.h2.newName, byId.h3.newName],
      ['hv-dc1-01', 'hv-dc1-02', 'hv-dc2-01'],
    );
    // U4 (Q5-Q7): the kvm_host defaults drop {dc}, so both empty
    // db_hosts fall to the ONE scenario-wide primary group's {seq} counter
    // (not a per-dc group) — k1/k2 number 01/02 in order_index order.
    assert.deepEqual([byId.k1.newName, byId.k2.newName], ['kvm-01', 'kvm-02']);
    assert.deepEqual([byId.a1.newName, byId.a2.newName], ['ap-01', 'ap-02']);
    assert.equal(byId.h1.entityType, 'hypervisor');
    assert.equal(byId.k1.entityType, 'kvm_host');
    assert.equal(byId.a1.entityType, 'ap_vm');
    assert.equal(byId.h1.oldName, 'old-h1');
    // read-only: never opened a transaction, never wrote
    assert.equal(state.began, 0);
    assert.equal(updates().length, 0);
  });

  it('a plain user is refused 403, nothing computed', async () => {
    currentUser = { id: 'u-user', role: 'user' };
    const res = await request('POST', PREVIEW, {});
    assert.equal(res.status, 403, res.raw);
  });

  it('404s when the scenario does not exist', async () => {
    state.scenarioExists = false;
    const res = await request('POST', PREVIEW, {});
    assert.equal(res.status, 404, res.raw);
  });
});

describe('preview contents + active patterns (PR-3)', () => {
  it('carries each db_host row its own instances (name + per-instance P/S role) in input order', async () => {
    state.vms = [{ id: 'k1', name: 'old-k1', order_index: 0, site_id: 's1', vm_type: 'db_host' }];
    state.databases = [{ id: 'db-erp', function_name: 'erp', order_index: 0 }];
    // Two instances on k1: a primary and a standby — order_index fixes pill order.
    state.dbInstances = [
      { vm_id: 'k1', name: 'erp1', role: 'primary', database_id: 'db-erp', order_index: 0 },
      { vm_id: 'k1', name: 'erp2', role: 'standby', database_id: 'db-erp', order_index: 1 },
    ];
    const res = await request('POST', PREVIEW, {});
    assert.equal(res.status, 200, res.raw);
    const byId = Object.fromEntries(res.json.data.rows.map((p) => [p.id, p]));
    assert.deepEqual(byId.k1.contents, [
      { name: 'erp1', role: 'primary' },
      { name: 'erp2', role: 'standby' },
    ]);
    // A hypervisor never carries contents.
    assert.deepEqual(byId.h1.contents, []);
  });

  it('an ap_vm carries functionName (Y-pattern "" when unset) and empty contents', async () => {
    state.vms = [
      { id: 'a1', name: 'old-a1', order_index: 0, site_id: null, vm_type: 'ap_host', function_name: 'billing' },
      { id: 'a2', name: 'old-a2', order_index: 1, site_id: null, vm_type: 'ap_host', function_name: null },
    ];
    const res = await request('POST', PREVIEW, {});
    const byId = Object.fromEntries(res.json.data.rows.map((p) => [p.id, p]));
    assert.equal(byId.a1.functionName, 'billing');
    assert.equal(byId.a2.functionName, ''); // null → '' (never null on the wire)
    assert.deepEqual(byId.a1.contents, []);
  });

  it('returns the active pattern string + source per entity key (global tier by default)', async () => {
    const res = await request('POST', PREVIEW, {});
    const { patterns } = res.json.data;
    assert.deepEqual(patterns.hypervisor, { pattern: 'hv-{dc}-{seq:2}', source: 'global' });
    assert.deepEqual(patterns.kvm_host_primary, { pattern: '{function}-{db_seq:2}', source: 'global' });
    assert.deepEqual(patterns.kvm_host_standby, { pattern: 'stdby-{seq:2}', source: 'global' });
    assert.deepEqual(patterns.ap_vm, { pattern: '{function}-{seq:2}', source: 'global' });
  });

  it('flags source: override when the scenario carries its own name_patterns', async () => {
    state.scenarioSettings = {
      name_patterns: {
        hypervisor: 'esx-{dc}-{seq:2}',
        kvm_host_primary: '{function}-{dc}-{seq:2}',
        kvm_host_standby: 'kvm-{dc}-{seq:2}',
        ap_vm: 'ap-{seq:2}',
      },
    };
    const res = await request('POST', PREVIEW, {});
    const { patterns } = res.json.data;
    assert.equal(patterns.hypervisor.source, 'override');
    assert.equal(patterns.hypervisor.pattern, 'esx-{dc}-{seq:2}');
    assert.equal(patterns.ap_vm.source, 'override');
  });
});

describe('POST renumber (apply)', () => {
  it('writes every CHANGED name in one transaction and returns the applied count', async () => {
    const res = await request('POST', APPLY, {});
    assert.equal(res.status, 200, res.raw);
    assert.equal(res.json.data.applied, 7);
    assert.equal(state.began, 1);
    assert.equal(state.committed, 1);
    assert.equal(state.rolledBack, 0);
    assert.equal(updates().length, 7);
    // recomputed server-side: the write carries the computed name, not any client input
    const h1Update = updates().find((q) => q.params[1] === 'h1');
    assert.equal(h1Update.params[0], 'hv-dc1-01');
  });

  it('skips rows whose name is already correct (no needless write / updated_at churn)', async () => {
    state.hypervisors[0].name = 'hv-dc1-01'; // already sequential
    const res = await request('POST', APPLY, {});
    assert.equal(res.status, 200, res.raw);
    assert.equal(updates().some((q) => q.params[1] === 'h1'), false);
    assert.equal(res.json.data.applied, 6);
  });

  it('locks cap_vms in ONE unfiltered ascending-id pass (deadlock-order invariant)', async () => {
    await request('POST', APPLY, {});
    // cap_hypervisors: a single id-order lock scan.
    const hvScans = state.queries.filter((q) => /FROM `fmb_cap_hypervisors` WHERE scenario_id = \? ORDER BY id FOR UPDATE$/.test(q.sql));
    assert.equal(hvScans.length, 1, 'expected exactly one cap_hypervisors id-order lock scan');
    // cap_vms carries BOTH vm_types — it MUST be locked once, UNFILTERED, so both
    // sets are taken in a single ascending-id pass (a per-vm_type filtered scan
    // would take locks in two interleaved passes, breaking id-order).
    const vmForUpdate = state.queries.filter((q) => /FROM `fmb_cap_vms`.*FOR UPDATE/.test(q.sql));
    assert.equal(vmForUpdate.length, 1, `expected exactly one cap_vms FOR UPDATE scan, got ${vmForUpdate.length}`);
    assert.match(vmForUpdate[0].sql, /FROM `fmb_cap_vms` WHERE scenario_id = \? ORDER BY id FOR UPDATE$/);
    // vm_type is read in the SELECT list (split in JS) but must NEVER be a WHERE
    // filter — a filtered scan is the two-pass regression this pins against.
    assert.doesNotMatch(vmForUpdate[0].sql, /AND vm_type/);
  });

  it('locks the global cap_settings row before reading name_patterns (fmb-1685)', async () => {
    // resolveEffectivePatterns reads the GLOBAL name_patterns row a no-override
    // scenario inherits from; the global config writers take lockGlobalConfig and
    // NO scenario lock, so apply must take the same lock or it renames from a
    // stale pattern a concurrent global edit committed mid-apply.
    await request('POST', APPLY, {});
    const lockIdx = state.queries.findIndex((q) => /^SELECT id FROM `fmb_cap_settings` FOR UPDATE$/.test(q.sql));
    const readIdx = state.queries.findIndex(
      (q) => /SELECT scenario_id, name_patterns FROM `fmb_cap_settings`/.test(q.sql),
    );
    assert.ok(lockIdx !== -1, 'apply must lock the global cap_settings row FOR UPDATE');
    assert.ok(readIdx !== -1, 'apply must read the effective name_patterns');
    assert.ok(lockIdx < readIdx, 'the global-settings lock must precede the pattern read');
    // ORDER: the scenario row is locked first (resolveScenarioWriteAccess), then
    // cap_settings — the consistent cap_scenarios → cap_settings order, no invert.
    const scenLockIdx = state.queries.findIndex((q) => /SELECT id, owner_id FROM `fmb_cap_scenarios` WHERE id = \? FOR UPDATE/.test(q.sql));
    assert.ok(scenLockIdx !== -1 && scenLockIdx < lockIdx, 'cap_scenarios is locked before cap_settings');
  });

  it('preview takes NO settings lock (read-only, RO connection)', async () => {
    await request('POST', PREVIEW, {});
    assert.equal(state.began, 0, 'preview never opens a transaction');
    assert.equal(
      state.queries.some((q) => /FOR UPDATE/.test(q.sql)), false,
      'a RO preview must not take any FOR UPDATE lock',
    );
  });

  it('rolls the WHOLE apply back on a duplicate name, nothing written (409)', async () => {
    // A scenario override sets a {seq}-less KVM pattern; with two db_host KVMs in
    // the SAME dc group both render "kvm-dc1" → a duplicate the apply must refuse.
    state.vms[1].site_id = 's1'; // both db_host now at s1 (dc1)
    state.scenarioSettings = {
      name_patterns: { hypervisor: 'hv-{dc}-{seq:2}', kvm_host: 'kvm-{dc}', ap_vm: 'ap-{seq:2}' },
    };
    const res = await request('POST', APPLY, {});
    assert.equal(res.status, 409, res.raw);
    assert.match(res.json.error.message, /duplicate/i);
    assert.equal(state.committed, 0);
    assert.equal(state.rolledBack, 1);
    assert.equal(updates().length, 0); // conflict caught in phase 1, before any write
  });

  it('a scenario override pattern wins over the global/default (recomputed server-side)', async () => {
    state.scenarioSettings = {
      name_patterns: { hypervisor: 'esx-{dc}-{seq:2}', kvm_host: 'kvm-{dc}-{seq:2}', ap_vm: 'ap-{seq:2}' },
    };
    const res = await request('POST', APPLY, {});
    assert.equal(res.status, 200, res.raw);
    const h1Update = updates().find((q) => q.params[1] === 'h1');
    assert.equal(h1Update.params[0], 'esx-dc1-01');
  });

  it('a plain user is refused 403, nothing written', async () => {
    currentUser = { id: 'u-user', role: 'user' };
    const res = await request('POST', APPLY, {});
    assert.equal(res.status, 403, res.raw);
    assert.equal(updates().length, 0);
  });

  it('an editor who does not own a private scenario is refused 403', async () => {
    currentUser = { id: 'u-other', role: 'editor' };
    state.scenarioOwner = 'u-owner';
    const res = await request('POST', APPLY, {});
    assert.equal(res.status, 403, res.raw);
    assert.equal(updates().length, 0);
  });

  it('the owning editor may renumber their own scenario', async () => {
    currentUser = { id: 'u-owner', role: 'editor' };
    state.scenarioOwner = 'u-owner';
    const res = await request('POST', APPLY, {});
    assert.equal(res.status, 200, res.raw);
  });

  it('404s when the scenario does not exist, nothing written', async () => {
    state.scenarioExists = false;
    const res = await request('POST', APPLY, {});
    assert.equal(res.status, 404, res.raw);
    assert.equal(updates().length, 0);
  });
});

describe('degraded schema (name_patterns column absent)', () => {
  it('preview + apply fall back to built-in defaults, ignoring any (unreadable) override', async () => {
    // Warn-skipped migration: the column is gone. A stored override cannot exist,
    // and even a phantom one must be ignored — the route short-circuits to defaults.
    state.settingsColumns = ['id', 'scenario_id', 'mem_cpu_ratio'];
    state.scenarioSettings = {
      name_patterns: { hypervisor: 'zzz-{dc}-{seq:2}', kvm_host: 'kvm-{dc}-{seq:2}', ap_vm: 'ap-{seq:2}' },
    };
    const prev = await request('POST', PREVIEW, {});
    assert.equal(prev.status, 200, prev.raw);
    const byId = Object.fromEntries(prev.json.data.rows.map((p) => [p.id, p]));
    assert.equal(byId.h1.newName, 'hv-dc1-01'); // built-in default, NOT the zzz override

    const res = await request('POST', APPLY, {});
    assert.equal(res.status, 200, res.raw);
    const h1Update = updates().find((q) => q.params[1] === 'h1');
    assert.equal(h1Update.params[0], 'hv-dc1-01');
  });
});

describe('preview duplicate flag (fmb-1649 — parity with apply firstDuplicateName)', () => {
  it('flags EVERY colliding row within one entity type, not just the second', async () => {
    // Same setup as the apply-side "rolls whole apply back" case: both db_host
    // KVMs land in the same {dc} group and a {seq}-less override renders them
    // identically — the preview must catch this BEFORE the user hits apply's
    // deterministic 409.
    state.vms[1].site_id = 's1'; // both db_host now at s1 (dc1)
    state.scenarioSettings = {
      name_patterns: { hypervisor: 'hv-{dc}-{seq:2}', kvm_host: 'kvm-{dc}', ap_vm: 'ap-{seq:2}' },
    };
    const res = await request('POST', PREVIEW, {});
    assert.equal(res.status, 200, res.raw);
    const byId = Object.fromEntries(res.json.data.rows.map((p) => [p.id, p]));
    assert.equal(byId.k1.newName, 'kvm-dc1');
    assert.equal(byId.k2.newName, 'kvm-dc1');
    assert.equal(byId.k1.duplicate, true, 'first colliding kvm_host row must be flagged');
    assert.equal(byId.k2.duplicate, true, 'second colliding kvm_host row must be flagged too');
    // Read-only: no writes, no transaction, regardless of the flagged collision.
    assert.equal(state.began, 0);
    assert.equal(updates().length, 0);
    // Untouched entity types are not flagged.
    assert.ok(!byId.h1.duplicate);
    assert.ok(!byId.a1.duplicate);
  });

  it('does NOT flag a collision across entity types (naming contract is per entity type)', async () => {
    // hypervisor and kvm_host share the SAME dc-free literal pattern, so their
    // first computed name is the identical string "shared-01" — but scope is
    // per entity type's own plan (apply's firstDuplicateName scope), so neither
    // is flagged.
    state.scenarioSettings = {
      name_patterns: { hypervisor: 'shared-{seq:2}', kvm_host: 'shared-{seq:2}', ap_vm: 'ap-{seq:2}' },
    };
    const res = await request('POST', PREVIEW, {});
    assert.equal(res.status, 200, res.raw);
    const byId = Object.fromEntries(res.json.data.rows.map((p) => [p.id, p]));
    assert.equal(byId.h1.newName, 'shared-01');
    assert.equal(byId.k1.newName, 'shared-01');
    assert.ok(!byId.h1.duplicate, 'cross-entity-type collision must be tolerated');
    assert.ok(!byId.k1.duplicate, 'cross-entity-type collision must be tolerated');
  });
});

describe('name length guard (VARCHAR(255))', () => {
  it('preview flags an over-limit computed name (tooLong) so the user learns before apply', async () => {
    state.sites = [{ id: 's1', name: 'd'.repeat(300) }];
    state.vms = [];
    const res = await request('POST', PREVIEW, {});
    assert.equal(res.status, 200, res.raw);
    const byId = Object.fromEntries(res.json.data.rows.map((p) => [p.id, p]));
    assert.equal(byId.h1.tooLong, true);
    assert.ok(byId.h1.newName.length > 255);
  });

  it('apply rolls the WHOLE thing back on an over-limit name (409), nothing written', async () => {
    state.sites = [{ id: 's1', name: 'd'.repeat(300) }];
    state.vms = [];
    const res = await request('POST', APPLY, {});
    assert.equal(res.status, 409, res.raw);
    assert.match(res.json.error.message, /longer than 255/i);
    assert.equal(state.committed, 0);
    assert.equal(state.rolledBack, 1);
    assert.equal(updates().length, 0);
  });

  it('accepts a name at the 255-character boundary (inclusive)', async () => {
    // 'hv-' + slug(249) + '-01' = 3 + 249 + 3 = 255 exactly. A single hypervisor
    // keeps the group pad at {seq:2}; no VMs so no other entity trips the guard.
    state.sites = [{ id: 's1', name: 'd'.repeat(249) }];
    state.hypervisors = [{ id: 'h1', name: 'old', order_index: 0, site_id: 's1' }];
    state.vms = [];
    const res = await request('POST', APPLY, {});
    assert.equal(res.status, 200, res.raw);
    const h1Update = updates().find((q) => q.params[1] === 'h1');
    assert.equal(h1Update.params[0].length, 255);
    assert.equal(h1Update.params[0], `hv-${'d'.repeat(249)}-01`);
  });
});

// spec §7 E2 / Q18 route B: the renumber DB-instance-name extension. Isolated to
// its own describe with hypervisors/vms cleared so `applied`/`updates()` counts
// reflect ONLY the db_instance rows under test.
describe('POST renumber — DB instance names (spec §7 E2)', () => {
  const clearHostFixtures = () => { state.hypervisors = []; state.vms = []; };

  it('preview: single→bare conversion — a single-topology instance drops its stored serial', async () => {
    clearHostFixtures();
    state.dbInstanceRows = [
      { id: 'i1', name: 'orcl1', database_id: 'd1', role: 'primary', order_index: 0, function_name: 'orcl', topology: 'single' },
    ];
    const res = await request('POST', PREVIEW, {});
    assert.equal(res.status, 200, res.raw);
    const row = res.json.data.rows.find((p) => p.id === 'i1');
    assert.equal(row.entityType, 'db_instance');
    assert.equal(row.oldName, 'orcl1');
    assert.equal(row.newName, 'orcl');
    assert.equal(row.duplicate, false);
    assert.equal(row.locked, false);
  });

  it('apply: single→bare conversion writes the bare name', async () => {
    clearHostFixtures();
    state.dbInstanceRows = [
      { id: 'i1', name: 'orcl1', database_id: 'd1', role: 'primary', order_index: 0, function_name: 'orcl', topology: 'single' },
    ];
    const res = await request('POST', APPLY, {});
    assert.equal(res.status, 200, res.raw);
    assert.equal(res.json.data.applied, 1);
    const renamed = res.json.data.renamed.find((r) => r.id === 'i1');
    assert.equal(renamed.entityType, 'db_instance');
    assert.equal(renamed.newName, 'orcl');
    const upd = updates().find((q) => q.params[1] === 'i1');
    assert.equal(upd.params[0], 'orcl');
  });

  it('non-single topology is untouched by the rule change: {fn}{clusterIndex}, primary+standby sharing a name, no duplicate flag', async () => {
    clearHostFixtures();
    state.dbInstanceRows = [
      { id: 'p1', name: 'x', database_id: 'd1', role: 'primary', order_index: 0, function_name: 'core', topology: 'primary_standby' },
      { id: 'p2', name: 'y', database_id: 'd1', role: 'primary', order_index: 1, function_name: 'core', topology: 'primary_standby' },
      { id: 's1', name: 'z', database_id: 'd1', role: 'standby', order_index: 2, function_name: 'core', topology: 'primary_standby' },
      { id: 's2', name: 'w', database_id: 'd1', role: 'standby', order_index: 3, function_name: 'core', topology: 'primary_standby' },
    ];
    const res = await request('POST', PREVIEW, {});
    assert.equal(res.status, 200, res.raw);
    const byId = Object.fromEntries(res.json.data.rows.map((p) => [p.id, p]));
    assert.equal(byId.p1.newName, 'core1');
    assert.equal(byId.p2.newName, 'core2');
    assert.equal(byId.s1.newName, 'core1'); // shares p1's name — BY DESIGN
    assert.equal(byId.s2.newName, 'core2');
    // Primary+standby sharing a name is intentional, not a collision.
    assert.equal(byId.p1.duplicate, false);
    assert.equal(byId.s1.duplicate, false);
  });

  it('idempotent re-run: an already-correctly-named instance is a no-op, not written', async () => {
    clearHostFixtures();
    state.dbInstanceRows = [
      { id: 'i1', name: 'orcl', database_id: 'd1', role: 'primary', order_index: 0, function_name: 'orcl', topology: 'single' },
    ];
    const preview = await request('POST', PREVIEW, {});
    const row = preview.json.data.rows.find((p) => p.id === 'i1');
    assert.equal(row.oldName, row.newName);

    const apply = await request('POST', APPLY, {});
    assert.equal(apply.status, 200, apply.raw);
    assert.equal(apply.json.data.applied, 0);
    assert.equal(updates().some((q) => q.params[1] === 'i1'), false, 'an already-correct name must not be written');
  });

  it('unchecked (unchanged) rows are not applied — only the CHANGED instance is written, mixed with an unchanged one', async () => {
    clearHostFixtures();
    state.dbInstanceRows = [
      { id: 'stale', name: 'app1', database_id: 'd1', role: 'primary', order_index: 0, function_name: 'app', topology: 'single' },
      { id: 'fresh', name: 'crm', database_id: 'd2', role: 'primary', order_index: 1, function_name: 'crm', topology: 'single' },
    ];
    const res = await request('POST', APPLY, {});
    assert.equal(res.status, 200, res.raw);
    assert.equal(res.json.data.applied, 1);
    assert.equal(updates().some((q) => q.params[1] === 'fresh'), false, 'the already-correct row must not be written');
    const staleUpdate = updates().find((q) => q.params[1] === 'stale');
    assert.equal(staleUpdate.params[0], 'app');
  });

  it('an orphaned instance (no owning database) is a passthrough — preview and apply leave it unchanged', async () => {
    clearHostFixtures();
    state.dbInstanceRows = [
      { id: 'i1', name: 'stray', database_id: null, role: 'primary', order_index: 0, function_name: null, topology: null },
    ];
    const preview = await request('POST', PREVIEW, {});
    const row = preview.json.data.rows.find((p) => p.id === 'i1');
    assert.equal(row.newName, 'stray');

    const apply = await request('POST', APPLY, {});
    assert.equal(apply.json.data.applied, 0);
  });

  it('a too-long computed DB instance name rolls the whole apply back (409), nothing written', async () => {
    clearHostFixtures();
    state.dbInstanceRows = [
      { id: 'i1', name: 'old', database_id: 'd1', role: 'primary', order_index: 0, function_name: 'x'.repeat(260), topology: 'single' },
    ];
    const res = await request('POST', APPLY, {});
    assert.equal(res.status, 409, res.raw);
    assert.match(res.json.error.message, /DB instance name longer than 255/i);
    assert.equal(state.committed, 0);
    assert.equal(state.rolledBack, 1);
    assert.equal(updates().length, 0);
  });

  // F2: apply must lock ONLY cap_db_instances, never cap_databases — a single
  // locking JOIN across both would lock cap_databases too, which children.js's
  // SGA cascade locks in the OPPOSITE order (parent UPDATE first, then
  // cap_db_instances FOR UPDATE).
  it('F2: apply locks cap_db_instances alone — no FOR UPDATE query ever names cap_databases', async () => {
    clearHostFixtures();
    state.dbInstanceRows = [
      { id: 'i1', name: 'orcl1', database_id: 'd1', role: 'primary', order_index: 0, function_name: 'orcl', topology: 'single' },
    ];
    const res = await request('POST', APPLY, {});
    assert.equal(res.status, 200, res.raw);
    const diLockScans = state.queries.filter((q) => /FROM `fmb_cap_db_instances`/.test(q.sql) && /FOR UPDATE/.test(q.sql));
    assert.equal(diLockScans.length, 1, 'expected exactly one cap_db_instances lock scan');
    assert.doesNotMatch(diLockScans[0].sql, /cap_databases/, 'the cap_db_instances lock scan must not join cap_databases');
    const anyDatabasesForUpdate = state.queries.some((q) => /cap_databases/.test(q.sql) && /FOR UPDATE/.test(q.sql));
    assert.equal(anyDatabasesForUpdate, false, 'no query naming cap_databases may carry FOR UPDATE');
    // The companion cap_databases read still happens — just not locked.
    const dbRead = state.queries.find((q) => /FROM `fmb_cap_databases`/.test(q.sql) && /function_name AS functionName/.test(q.sql));
    assert.ok(dbRead, 'expected the plain (non-locking) cap_databases companion read');
  });

  // X1 (Codex round-1 outside voice): cap_databases.id is CHAR(36) under a
  // case-folding collation — preview's SQL join resolves a case-differing
  // database_id, but a raw JS Map.get in the apply/lock path would miss it.
  // Both paths must resolve (and rename) IDENTICALLY.
  it('X1: a database_id differing only by case from cap_databases.id renames identically in preview and apply', async () => {
    clearHostFixtures();
    state.dbInstanceRows = [
      { id: 'i1', name: 'orcl-old', database_id: 'D1-UPPER', role: 'primary', order_index: 0 },
    ];
    state.dbInstanceDatabases = [
      { id: 'd1-upper', function_name: 'orcl', topology: 'single', scenario_id: 'scn-1' },
    ];
    const preview = await request('POST', PREVIEW, {});
    assert.equal(preview.status, 200, preview.raw);
    const previewRow = preview.json.data.rows.find((p) => p.id === 'i1');
    assert.equal(previewRow.newName, 'orcl');

    const apply = await request('POST', APPLY, {});
    assert.equal(apply.status, 200, apply.raw);
    assert.equal(apply.json.data.applied, 1);
    const renamed = apply.json.data.renamed.find((r) => r.id === 'i1');
    assert.equal(renamed.newName, 'orcl'); // preview == apply
    const upd = updates().find((q) => q.params[1] === 'i1');
    assert.equal(upd.params[0], 'orcl');
  });

  it('X1: two instances referencing the SAME database via differently-cased ids rank together (1,2), in BOTH paths', async () => {
    clearHostFixtures();
    state.dbInstanceRows = [
      { id: 'p1', name: 'x', database_id: 'D1', role: 'primary', order_index: 0 },
      { id: 'p2', name: 'y', database_id: 'd1', role: 'primary', order_index: 1 }, // same database, different case
    ];
    state.dbInstanceDatabases = [
      { id: 'd1', function_name: 'core', topology: 'primary', scenario_id: 'scn-1' },
    ];
    const preview = await request('POST', PREVIEW, {});
    const byId = Object.fromEntries(preview.json.data.rows.map((p) => [p.id, p]));
    assert.equal(byId.p1.newName, 'core1');
    assert.equal(byId.p2.newName, 'core2'); // ranked TOGETHER — not two separate 1-member groups

    const apply = await request('POST', APPLY, {});
    assert.equal(apply.status, 200, apply.raw);
    const applyById = Object.fromEntries(apply.json.data.renamed.map((r) => [r.id, r]));
    assert.equal(applyById.p1.newName, 'core1');
    assert.equal(applyById.p2.newName, 'core2'); // preview == apply
  });

  // X2 (Codex round-1 outside voice): the preview join was not scenario-scoped
  // — a database_id that happens to name ANOTHER scenario's database resolved
  // there but never in apply (which only ever reads this scenario's
  // cap_databases). Both paths must now agree: passthrough.
  it('X2: a database_id belonging to ANOTHER scenario is a passthrough in BOTH preview and apply', async () => {
    clearHostFixtures();
    state.dbInstanceRows = [
      { id: 'i1', name: 'kept-name', database_id: 'd-foreign', role: 'primary', order_index: 0 },
    ];
    state.dbInstanceDatabases = [
      { id: 'd-foreign', function_name: 'orcl', topology: 'single', scenario_id: 'scn-OTHER' },
    ];
    const preview = await request('POST', PREVIEW, {});
    assert.equal(preview.status, 200, preview.raw);
    const previewRow = preview.json.data.rows.find((p) => p.id === 'i1');
    assert.equal(previewRow.newName, 'kept-name'); // NOT 'orcl' — the foreign row must not resolve

    const apply = await request('POST', APPLY, {});
    assert.equal(apply.status, 200, apply.raw);
    assert.equal(apply.json.data.applied, 0);
    assert.equal(updates().some((q) => q.params[1] === 'i1'), false);
  });

  // X3 (Codex round-1 outside voice): a BLANK (empty/whitespace) function_name
  // — reachable via the generic database CRUD, not just a dangling FK — must
  // be the SAME passthrough as a null one, in BOTH paths ("same for the
  // lock-path map").
  it('X3: a blank function_name is a passthrough in BOTH preview and apply, never written as \'\'', async () => {
    clearHostFixtures();
    state.dbInstanceRows = [
      { id: 'i1', name: 'kept-name', database_id: 'd1', role: 'primary', order_index: 0 },
    ];
    state.dbInstanceDatabases = [
      { id: 'd1', function_name: '   ', topology: 'single', scenario_id: 'scn-1' },
    ];
    const preview = await request('POST', PREVIEW, {});
    assert.equal(preview.status, 200, preview.raw);
    const previewRow = preview.json.data.rows.find((p) => p.id === 'i1');
    assert.equal(previewRow.newName, 'kept-name');

    const apply = await request('POST', APPLY, {});
    assert.equal(apply.status, 200, apply.raw);
    assert.equal(apply.json.data.applied, 0);
    assert.equal(updates().some((q) => q.params[1] === 'i1'), false, 'a blank function_name must never be written as an empty name');
  });

  // F3: a dangling database_id (set, but the join finds no matching
  // cap_databases row — functionName null) is a passthrough, not a bare
  // integer name.
  it('F3: a dangling database_id is a passthrough in both preview and apply, not renamed to a bare integer', async () => {
    clearHostFixtures();
    state.dbInstanceRows = [
      { id: 'i1', name: 'kept-name', database_id: 'd-ghost', role: 'primary', order_index: 0, function_name: null, topology: null },
    ];
    const preview = await request('POST', PREVIEW, {});
    assert.equal(preview.status, 200, preview.raw);
    const row = preview.json.data.rows.find((p) => p.id === 'i1');
    assert.equal(row.newName, 'kept-name');
    assert.notEqual(row.newName, '1');

    const apply = await request('POST', APPLY, {});
    assert.equal(apply.status, 200, apply.raw);
    assert.equal(apply.json.data.applied, 0);
    assert.equal(updates().some((q) => q.params[1] === 'i1'), false);
  });

  // F4: a single-topology database with >1 instance rows sharing a role would
  // otherwise collapse them all onto the identical bare name — flag in
  // preview, refuse apply (409), same shape as the tooLong guard.
  describe('F4: oversized single-topology group', () => {
    it('preview flags every row in the oversized group as duplicate', async () => {
      clearHostFixtures();
      state.dbInstanceRows = [
        { id: 'i1', name: 'orcl-a', database_id: 'd1', role: 'primary', order_index: 0, function_name: 'orcl', topology: 'single' },
        { id: 'i2', name: 'orcl-b', database_id: 'd1', role: 'primary', order_index: 1, function_name: 'orcl', topology: 'single' },
      ];
      const res = await request('POST', PREVIEW, {});
      assert.equal(res.status, 200, res.raw);
      const byId = Object.fromEntries(res.json.data.rows.map((p) => [p.id, p]));
      assert.equal(byId.i1.duplicate, true);
      assert.equal(byId.i2.duplicate, true);
    });

    it('apply rolls the WHOLE thing back on an oversized single-topology group (409), nothing written', async () => {
      clearHostFixtures();
      state.dbInstanceRows = [
        { id: 'i1', name: 'orcl-a', database_id: 'd1', role: 'primary', order_index: 0, function_name: 'orcl', topology: 'single' },
        { id: 'i2', name: 'orcl-b', database_id: 'd1', role: 'primary', order_index: 1, function_name: 'orcl', topology: 'single' },
      ];
      const res = await request('POST', APPLY, {});
      assert.equal(res.status, 409, res.raw);
      assert.match(res.json.error.message, /would compute this identical name/i);
      assert.equal(state.committed, 0);
      assert.equal(state.rolledBack, 1);
      assert.equal(updates().length, 0);
    });

    it('a non-single-topology database with >1 rows sharing a role is unaffected — no 409', async () => {
      clearHostFixtures();
      state.dbInstanceRows = [
        { id: 'p1', name: 'x', database_id: 'd1', role: 'primary', order_index: 0, function_name: 'core', topology: 'primary' },
        { id: 'p2', name: 'y', database_id: 'd1', role: 'primary', order_index: 1, function_name: 'core', topology: 'primary' },
      ];
      const res = await request('POST', APPLY, {});
      assert.equal(res.status, 200, res.raw);
      assert.equal(res.json.data.applied, 2);
    });
  });

  // Y1 (Codex round-2): same class as F4 (two rows, one database, one
  // computed name, no design reason to share it), reached via a DIFFERENT
  // shape — a topology illegally carrying BOTH a primary and a standby row.
  // F4's (databaseId, role)-separated grouping ranked each role
  // independently and never saw the cross-role repeat; the class-closing
  // within-database check (grouped ACROSS roles) catches it.
  describe('Y1: cross-role name collision within one database (class-closing, generalizes F4)', () => {
    it('preview flags BOTH rows when a `primary`-topology database illegally has a primary AND a standby instance', async () => {
      clearHostFixtures();
      state.dbInstanceRows = [
        { id: 'p1', name: 'x', database_id: 'd1', role: 'primary', order_index: 0, function_name: 'orcl', topology: 'primary' },
        { id: 's1', name: 'y', database_id: 'd1', role: 'standby', order_index: 1, function_name: 'orcl', topology: 'primary' },
      ];
      const res = await request('POST', PREVIEW, {});
      assert.equal(res.status, 200, res.raw);
      const byId = Object.fromEntries(res.json.data.rows.map((p) => [p.id, p]));
      assert.equal(byId.p1.newName, 'orcl1');
      assert.equal(byId.s1.newName, 'orcl1');
      assert.equal(byId.p1.duplicate, true);
      assert.equal(byId.s1.duplicate, true);
    });

    it('apply rolls the WHOLE thing back (409) for a `primary`-topology database with a primary+standby collision, nothing written', async () => {
      clearHostFixtures();
      state.dbInstanceRows = [
        { id: 'p1', name: 'x', database_id: 'd1', role: 'primary', order_index: 0, function_name: 'orcl', topology: 'primary' },
        { id: 's1', name: 'y', database_id: 'd1', role: 'standby', order_index: 1, function_name: 'orcl', topology: 'primary' },
      ];
      const res = await request('POST', APPLY, {});
      assert.equal(res.status, 409, res.raw);
      assert.match(res.json.error.message, /would compute this identical name/i);
      assert.equal(state.committed, 0);
      assert.equal(state.rolledBack, 1);
      assert.equal(updates().length, 0);
    });

    it('a `single`-topology database with one primary row and one standby row is flagged too (bare name collides across roles)', async () => {
      clearHostFixtures();
      state.dbInstanceRows = [
        { id: 'p1', name: 'x', database_id: 'd1', role: 'primary', order_index: 0, function_name: 'orcl', topology: 'single' },
        { id: 's1', name: 'y', database_id: 'd1', role: 'standby', order_index: 1, function_name: 'orcl', topology: 'single' },
      ];
      const res = await request('POST', APPLY, {});
      assert.equal(res.status, 409, res.raw);
    });

    it('`primary_standby` with a legitimate primary+standby pair sharing fn1/fn1 is NOT flagged — the sharing-topology exemption', async () => {
      clearHostFixtures();
      state.dbInstanceRows = [
        { id: 'p1', name: 'x', database_id: 'd1', role: 'primary', order_index: 0, function_name: 'orcl', topology: 'primary_standby' },
        { id: 's1', name: 'y', database_id: 'd1', role: 'standby', order_index: 1, function_name: 'orcl', topology: 'primary_standby' },
      ];
      const preview = await request('POST', PREVIEW, {});
      assert.equal(preview.status, 200, preview.raw);
      const byId = Object.fromEntries(preview.json.data.rows.map((p) => [p.id, p]));
      assert.equal(byId.p1.newName, 'orcl1');
      assert.equal(byId.s1.newName, 'orcl1'); // BY DESIGN
      assert.equal(byId.p1.duplicate, false);
      assert.equal(byId.s1.duplicate, false);

      const apply = await request('POST', APPLY, {});
      assert.equal(apply.status, 200, apply.raw); // no 409 — legitimate sharing
    });
  });
});
