/**
 * capacity-violations.test.js — GET /scenarios/:id/violations (PR-C).
 *
 * Seeded fixture → expected violations; a waiver marks the item waived (not
 * hidden, spec §3.3); read-only (no INSERT/UPDATE/DELETE); 404 on a missing
 * scenario; 401 unauthenticated. Runs against a mock edge/db.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../../../src/edge/db');

// Per-test seed: table base-name → rows. The handler SELECTs `SELECT * FROM
// fmb_cap_X WHERE scenario_id = ?`; the mock returns seed[X] for a match.
let seed;
let scenarioExists;
let writeQueries;

function freshSeed() {
  return {
    cap_sites: [{ id: 'site-1', scenario_id: 'scn-1', name: 'DC-1' }],
    cap_hardware_specs: [{
      id: 'spec-a', scenario_id: 'scn-1', name: 'A',
      cpu_total: 16, mem_total_gb: 100, disk_total_gb: 100,
      cpu_reserved: 0, mem_reserved_pct: 0, disk_reserved_gb: 0, metadata: null,
    }],
    cap_hypervisors: [{ id: 'h1', scenario_id: 'scn-1', site_id: 'site-1', spec_id: 'spec-a', name: 'h1', metadata: null }],
    // One VM oversells CPU (20 > usable 16).
    cap_vms: [{
      id: 'v1', scenario_id: 'scn-1', vm_type: 'db_host', hypervisor_id: 'h1',
      cpu: 20, mem_gb: 50, disk_gb: 50, sizing_profile_id: null, name: 'v1', metadata: null,
    }],
    cap_db_instances: [],
    cap_rules: [{
      id: 'r-cap', scenario_id: 'scn-1', type: 'no-oversell', name: 'No oversell',
      level: 'hypervisor', group_by: 'all_of_type', filters: null, params: null, severity: 'hard', enabled: 1,
    }],
    cap_waivers: [],
    cap_databases: [],
    cap_custom_groups: [],
    cap_custom_group_members: [],
    cap_vm_profiles: [],
    cap_settings: [{ id: 'st-1', scenario_id: 'scn-1', util_amber_pct: 80, util_red_pct: 90, overcommit_default_enabled: 0 }],
  };
}

const conn = {
  async query(sql, params = []) {
    if (/^\s*(INSERT|UPDATE|DELETE)/i.test(sql)) {
      writeQueries.push(sql);
      return { affectedRows: 1 };
    }
    // Scenario row load (existence + level:'scenario' population).
    if (/SELECT \* FROM `fmb_cap_scenarios` WHERE id = \?/.test(sql)) {
      return scenarioExists ? [{ id: 'scn-1', name: 'Scenario 1', metadata: seed.cap_scenarios_metadata ?? null }] : [];
    }
    // Matches the scenario-scoped read AND the global-or-same-scenario catalogue
    // read (`WHERE scenario_id IS NULL OR scenario_id = ?`) + the settings
    // fallback (`WHERE scenario_id = ? OR scenario_id IS NULL ORDER BY … LIMIT 1`).
    const m = sql.match(/SELECT \* FROM `fmb_(cap_[a-z_]+)` WHERE scenario_id/);
    if (m) return seed[m[1]] || [];
    return [];
  },
};
const poolFacade = { getConnection: async () => conn, query: (s, p) => conn.query(s, p) };
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: { ro: poolFacade, rw: poolFacade }, t: (n) => `fmb_${n}` },
};

const router = require('../../../../src/edge/routes/app/capacity');
const { loadSnapshot } = require('../../../../src/edge/routes/app/capacity/violations');

let currentUser; let server; let baseUrl;
before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { req.user = currentUser; next(); });
  app.use('/capacity', router);
  server = http.createServer(app);
  await new Promise((r) => server.listen(0, r));
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});
after(() => server && server.close());
beforeEach(() => {
  seed = freshSeed();
  scenarioExists = true;
  writeQueries = [];
  currentUser = { id: 'u-user', role: 'user' };
});

function get(path) {
  return new Promise((resolve, reject) => {
    const r = http.request(`${baseUrl}${path}`, { method: 'GET' }, (res) => {
      const chunks = [];
      res.on('data', (c) => chunks.push(c));
      res.on('end', () => {
        let json = null;
        try { json = JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch { /* noop */ }
        resolve({ status: res.statusCode, json });
      });
    });
    r.on('error', reject);
    r.end();
  });
}

describe('GET /scenarios/:id/violations', () => {
  it('computes violations from the seeded snapshot (all authenticated read)', async () => {
    const res = await get('/capacity/scenarios/scn-1/violations');
    assert.equal(res.status, 200);
    assert.equal(res.json.data.violations.length, 1);
    const v = res.json.data.violations[0];
    assert.equal(v.rule_id, 'r-cap');
    assert.equal(v.severity, 'hard');
    assert.deepEqual(v.subject_ids, ['h1']);
    assert.equal(v.waived, false);
    assert.deepEqual(res.json.data.summary, { hard: 1, soft: 0, waived: 0, total: 1 });
  });

  it('a matching waiver marks the violation waived (kept, not hidden)', async () => {
    seed.cap_waivers = [{ id: 'w1', scenario_id: 'scn-1', rule_id: 'r-cap', object_set_key: 'h1' }];
    const res = await get('/capacity/scenarios/scn-1/violations');
    assert.equal(res.status, 200);
    assert.equal(res.json.data.violations.length, 1);
    assert.equal(res.json.data.violations[0].waived, true);
    assert.deepEqual(res.json.data.summary, { hard: 0, soft: 0, waived: 1, total: 1 });
  });

  it('exposes per-hypervisor rollups', async () => {
    const res = await get('/capacity/scenarios/scn-1/violations');
    assert.equal(res.status, 200);
    const roll = res.json.data.rollups.hypervisors.h1;
    assert.equal(roll.used.cpu, 20);
    assert.equal(roll.usable.cpu, 16);
  });

  it('is read-only — issues no write query', async () => {
    await get('/capacity/scenarios/scn-1/violations');
    assert.equal(writeQueries.length, 0);
  });

  it('loadSnapshot carries the structural collections and drops the retired sizing_tiers', async () => {
    seed.cap_databases = [{ id: 'db-1', scenario_id: 'scn-1', function_name: 'erp', topology: 'primary' }];
    seed.cap_custom_groups = [{ id: 'cg-1', scenario_id: 'scn-1', name: 'g', team_id: null }];
    seed.cap_custom_group_members = [{ id: 'm1', scenario_id: 'scn-1', group_id: 'cg-1', member_instance_id: null, member_vm_id: null }];
    const state = await loadSnapshot('scn-1');
    assert.ok(Array.isArray(state.databases) && state.databases.length === 1);
    assert.ok(Array.isArray(state.custom_groups) && state.custom_groups.length === 1);
    assert.ok(Array.isArray(state.custom_group_members) && state.custom_group_members.length === 1);
    assert.equal(state.sizing_tiers, undefined); // dropped table is no longer read
  });

  it('a keep-apart rule emits a relational violation through the route', async () => {
    // Two primary instances of one database share host h1 (both on VM v1).
    seed.cap_vms = [{
      id: 'v1', scenario_id: 'scn-1', vm_type: 'db_host', hypervisor_id: 'h1',
      cpu: 8, mem_gb: 160, disk_gb: 200, sizing_profile_id: null, name: 'v1', metadata: null,
    }];
    seed.cap_databases = [{ id: 'db-1', scenario_id: 'scn-1', function_name: 'erp', topology: 'primary' }];
    seed.cap_db_instances = [
      { id: 'i1', scenario_id: 'scn-1', vm_id: 'v1', database_id: 'db-1', name: 'i1', role: 'primary', sga_gb: 0, metadata: null },
      { id: 'i2', scenario_id: 'scn-1', vm_id: 'v1', database_id: 'db-1', name: 'i2', role: 'primary', sga_gb: 0, metadata: null },
    ];
    seed.cap_rules = [{
      id: 'r-anti', scenario_id: 'scn-1', type: 'keep-apart', name: 'Keep apart',
      level: 'db_instance', group_by: 'each_primary_cluster', filters: null, params: null, severity: 'hard', enabled: 1,
    }];
    const res = await get('/capacity/scenarios/scn-1/violations');
    assert.equal(res.status, 200);
    const v = res.json.data.violations;
    assert.equal(v.length, 1);
    assert.equal(v[0].rule_type, 'keep-apart');
    assert.deepEqual([...v[0].subject_ids].sort(), ['i1', 'i2']);
  });

  it('resolves GLOBAL catalogue rows (spec + profile) for usable capacity + SGA-cap', async () => {
    // A reference-model scenario: its hypervisor points at a GLOBAL hardware spec
    // and its db_host VM at a GLOBAL vm_profile (scenario_id: null on both). The
    // snapshot must load these global-or-same-scenario, else usable = 0 (false
    // oversell) and the SGA cap can't resolve.
    seed.cap_hardware_specs = [{
      id: 'gspec', scenario_id: null, name: 'G',
      cpu_total: 16, mem_total_gb: 100, disk_total_gb: 100,
      cpu_reserved: 0, mem_reserved_pct: 0, disk_reserved_gb: 0, metadata: null,
    }];
    seed.cap_hypervisors = [{ id: 'h1', scenario_id: 'scn-1', site_id: 'site-1', spec_id: 'gspec', name: 'h1', metadata: null }];
    seed.cap_vm_profiles = [{
      id: 'gprof', scenario_id: null, class: 'DB', name: 'DB-16C', mode: 'formula',
      cpu: 16, mem_gb: null, sga_cap_gb: null, allowed_disk_combos: null, metadata: null,
    }];
    seed.cap_vms = [{
      id: 'v1', scenario_id: 'scn-1', vm_type: 'db_host', hypervisor_id: 'h1',
      cpu: 8, mem_gb: 50, disk_gb: 50, sizing_profile_id: 'gprof', name: 'v1', metadata: null,
    }];
    seed.cap_databases = [{ id: 'db-1', scenario_id: 'scn-1', function_name: 'erp', topology: 'single' }];
    seed.cap_db_instances = [{ id: 'i1', scenario_id: 'scn-1', vm_id: 'v1', database_id: 'db-1', name: 'i1', role: 'primary', sga_gb: 200, metadata: null }];
    seed.cap_rules = [{
      id: 'r-cap', scenario_id: 'scn-1', type: 'no-oversell', name: 'No oversell',
      level: 'hypervisor', group_by: 'all_of_type', filters: null, params: null, severity: 'hard', enabled: 1,
    }];
    const res = await get('/capacity/scenarios/scn-1/violations');
    assert.equal(res.status, 200);
    // usable resolves from the GLOBAL spec (cpu 16), so v1 cpu 8 is NOT oversold.
    assert.equal(res.json.data.rollups.hypervisors.h1.usable.cpu, 16);
    assert.equal(res.json.data.violations.some((x) => x.rule_id === 'r-cap'), false);
    // The GLOBAL DB-16C profile's formula cap = 155; v1 hosts 200 GB SGA → over cap.
    const sga = res.json.data.violations.find((x) => x.rule_type === 'sga-cap');
    assert.ok(sga, 'SGA-cap violation should fire off the GLOBAL profile cap');
    assert.deepEqual(sga.subject_ids, ['v1']);
  });

  it('H2: a GLOBAL seeded rule (scenario_id NULL) evaluates for a scenario with no local rules', async () => {
    // No scenario-local rule — only the global template row. The oversold host
    // must still be flagged (the 6 seeded global rules are the default template).
    seed.cap_rules = [{
      id: 'g-cap', scenario_id: null, type: 'no-oversell', name: 'No oversell',
      level: 'hypervisor', group_by: 'all_of_type', filters: null, params: null, severity: 'hard', enabled: 1,
    }];
    const res = await get('/capacity/scenarios/scn-1/violations');
    assert.equal(res.status, 200);
    assert.equal(res.json.data.violations.length, 1);
    assert.equal(res.json.data.violations[0].rule_id, 'g-cap');
  });

  it('H2: a scenario override row (enabled=false) suppresses its global template rule', async () => {
    seed.cap_rules = [
      { id: 'g-cap', scenario_id: null, type: 'no-oversell', name: 'No oversell', level: 'hypervisor', group_by: 'all_of_type', filters: null, params: null, severity: 'hard', enabled: 1 },
      { id: 'o-cap', scenario_id: 'scn-1', overrides_rule_id: 'g-cap', enabled: 0, filters: null, params: null },
    ];
    const res = await get('/capacity/scenarios/scn-1/violations');
    assert.equal(res.status, 200);
    assert.equal(res.json.data.violations.length, 0);
  });

  it('H2: an override row with tweaked params wins over the global template', async () => {
    // Global max-VMs-per-host = 8 (h1 carries 1 VM → OK); the scenario override
    // tightens it to 0 → the same host now violates. The effective rule keeps the
    // global identity + hard severity.
    seed.cap_rules = [
      { id: 'g-max', scenario_id: null, type: 'max-vms-per-host', name: 'Max VMs', level: 'hypervisor', group_by: 'all_of_type', filters: null, params: { max: 8 }, severity: 'hard', enabled: 1 },
      { id: 'o-max', scenario_id: 'scn-1', overrides_rule_id: 'g-max', enabled: 1, params: { max: 0 } },
    ];
    const res = await get('/capacity/scenarios/scn-1/violations');
    assert.equal(res.status, 200);
    assert.equal(res.json.data.violations.length, 1);
    assert.equal(res.json.data.violations[0].rule_id, 'g-max');
    assert.equal(res.json.data.violations[0].severity, 'hard');
  });

  it('reports budget_exceeded=false under normal load', async () => {
    const res = await get('/capacity/scenarios/scn-1/violations');
    assert.equal(res.json.data.budget_exceeded, false);
  });

  it('404 when the scenario does not exist', async () => {
    scenarioExists = false;
    const res = await get('/capacity/scenarios/nope/violations');
    assert.equal(res.status, 404);
  });

  it('401 when unauthenticated', async () => {
    currentUser = undefined;
    const res = await get('/capacity/scenarios/scn-1/violations');
    assert.equal(res.status, 401);
  });
});

// ── the oversell message prints through the SHARED formatting rule ──
//
// The frontend re-evaluates this same state live in the browser (the ISOMORPHIC
// OBLIGATION at the top of shared/capacity/evaluator.js), so the two copies must
// produce the same STRING, not merely the same violation. A local rounding rule
// on either side breaks that silently: the operator sees one number on the
// placement canvas and a different one in the report.
//
// `cap_vms.mem_gb` is deliberately free-form (the operator ruled on it), so a
// `used` value with more decimals than a local 2-decimal round can carry is
// reachable, not theoretical.
const { formatQuantity } = require('../../../../src/shared/capacity/quantity');

describe('GET /scenarios/:id/violations — the oversell message formatting (fmb-1433)', () => {
  const oversellingVm = (memGb) => ([{
    id: 'v1', scenario_id: 'scn-1', vm_type: 'db_host', hypervisor_id: 'h1',
    cpu: 4, mem_gb: memGb, disk_gb: 50, sizing_profile_id: null, name: 'v1', metadata: null,
  }]);

  it('prints a used value with more decimals than a 2-decimal rounding could carry', async () => {
    seed.cap_vms = oversellingVm(100.456789); // usable mem is 100
    const res = await get('/capacity/scenarios/scn-1/violations');
    assert.equal(res.status, 200);
    const messages = res.json.data.violations.map((v) => v.message);
    assert.deepEqual(messages, ['Host h1 is oversold: MEM 100.456789/100.']);
  });

  it('asserts the shared rule rather than a literal, so a change to the rule moves both together', async () => {
    seed.cap_vms = oversellingVm(100.456789);
    const res = await get('/capacity/scenarios/scn-1/violations');
    assert.equal(
      res.json.data.violations[0].message,
      `Host h1 is oversold: MEM ${formatQuantity(100.456789)}/${formatQuantity(100)}.`,
    );
  });

  it('removes float summation residue from the used side without touching a typed value', async () => {
    // 24.1 + 24.1 + 29.1 + 29.1 sums to 106.39999999999999 in binary floating
    // point. The operator typed four ordinary one-decimal numbers and must not be
    // shown eighteen glyphs of residue.
    seed.cap_vms = [24.1, 24.1, 29.1, 29.1].map((mem, i) => ({
      id: `v${i}`, scenario_id: 'scn-1', vm_type: 'db_host', hypervisor_id: 'h1',
      cpu: 1, mem_gb: mem, disk_gb: 1, sizing_profile_id: null, name: `v${i}`, metadata: null,
    }));
    const res = await get('/capacity/scenarios/scn-1/violations');
    assert.equal(res.json.data.violations[0].message, 'Host h1 is oversold: MEM 106.4/100.');
  });

  it('keeps the used/usable asymmetry — usable is floored, used is NOT (item 9 is intended)', async () => {
    // 250 GB at 12.5 % leaves 218.75 usable → floored to 218; a VM asking 218.5
    // is genuinely over it. Flooring the USED side too would print 218/218 and
    // hide a real half-gigabyte of oversell.
    seed.cap_hardware_specs = [{
      id: 'spec-a', scenario_id: 'scn-1', name: 'A',
      cpu_total: 16, mem_total_gb: 250, disk_total_gb: 1000,
      cpu_reserved: 0, mem_reserved_pct: 12.5, disk_reserved_gb: 0, metadata: null,
    }];
    seed.cap_vms = oversellingVm(218.5);
    const res = await get('/capacity/scenarios/scn-1/violations');
    assert.equal(res.json.data.violations[0].message, 'Host h1 is oversold: MEM 218.5/218.');
  });
});

// ── the instance SGA a pre-rule row still holds is floored on READ ──
//
// `cap_db_instances.sga_gb` is one of the four columns the rule names whole, but
// no migration ran and `/versions/:id/restore` replays a frozen version verbatim
// by design — so a 96.5 written before the rule reaches this evaluator. It is
// floored per VALUE as it is read, never on the sum, which reproduces exactly
// what every writer would store today.
describe('GET /scenarios/:id/violations — a pre-rule instance SGA (fmb-1433)', () => {
  beforeEach(() => {
    // Isolate the built-in SGA-cap check: no rules at all, and a host big enough
    // that nothing else is oversold.
    seed.cap_rules = [];
    seed.cap_hardware_specs = [{
      id: 'spec-a', scenario_id: 'scn-1', name: 'A',
      cpu_total: 64, mem_total_gb: 1000, disk_total_gb: 1000,
      cpu_reserved: 0, mem_reserved_pct: 0, disk_reserved_gb: 0, metadata: null,
    }];
    seed.cap_vm_profiles = [{
      id: 'p1', scenario_id: 'scn-1', class: 'DB', mode: 'formula', cpu: 8,
      name: 'DB-8C', mem_gb: null, sga_cap_gb: null, allowed_disk_combos: null, metadata: null,
    }];
    seed.cap_vms = [{
      id: 'v1', scenario_id: 'scn-1', vm_type: 'db_host', hypervisor_id: 'h1',
      cpu: 8, mem_gb: 160, disk_gb: 50, sizing_profile_id: 'p1', name: 'v1', metadata: null,
    }];
    seed.cap_databases = [{ id: 'db-1', scenario_id: 'scn-1', function_name: 'erp', topology: 'primary_standby' }];
    seed.cap_db_instances = [
      { id: 'i1', scenario_id: 'scn-1', vm_id: 'v1', database_id: 'db-1', name: 'i1', role: 'primary', sga_gb: 96.5, metadata: null },
      { id: 'i2', scenario_id: 'scn-1', vm_id: 'v1', database_id: 'db-1', name: 'i2', role: 'standby', sga_gb: 48.25, metadata: null },
    ];
  });

  it('rolls the fractions up to a whole number and says so in the violation text', async () => {
    const res = await get('/capacity/scenarios/scn-1/violations');
    assert.equal(res.status, 200);
    const v = res.json.data.violations;
    assert.equal(v.length, 1);
    assert.equal(v[0].rule_id, '__sga_cap__');
    assert.equal(v[0].message, 'VM v1 hosts 144 GB of SGA — over its profile cap of 76 GB.');
  });

  it('floors each value, not the sum — 96.5 + 48.25 is 144, not 145', async () => {
    // The distinction is visible precisely here: flooring the SUM of 144.75 also
    // gives 144, but 96.5 + 48.5 would give 145 one way and 144 the other. This
    // pair separates them.
    seed.cap_db_instances[1].sga_gb = 48.5;
    const res = await get('/capacity/scenarios/scn-1/violations');
    assert.equal(res.json.data.rollups.vms.v1.used_sga, 144, 'floor(96.5) + floor(48.5) = 144; floor(96.5 + 48.5) would be 145');
  });

  it('leaves a whole stored value exactly as it is', async () => {
    seed.cap_db_instances = [{ id: 'i1', scenario_id: 'scn-1', vm_id: 'v1', database_id: 'db-1', name: 'i1', role: 'primary', sga_gb: 96, metadata: null }];
    const res = await get('/capacity/scenarios/scn-1/violations');
    assert.equal(res.json.data.rollups.vms.v1.used_sga, 96);
  });
});
