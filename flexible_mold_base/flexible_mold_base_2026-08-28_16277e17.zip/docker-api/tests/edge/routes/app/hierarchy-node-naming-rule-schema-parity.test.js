/**
 * hierarchy-node-naming-rule-schema-parity.test.js — the per-blueprint
 * auto-naming template column, checked against the ACTUAL DDL and against the
 * read serializer that is supposed to normalize it, WITHOUT a live DB.
 *
 * The column is read and written through the generic CRUD factory (SELECT * +
 * mapRowsFromDb), so no hand-written SQL names it — which is exactly why a mock
 * would paint every read green while the Y-pattern coalescing never fires. This
 * pins two facts a mock cannot: (1) `naming_rule` is a nullable column of
 * hierarchy_nodes in table-ddls.js (the single schema truth), and (2)
 * dto-mapper actually coalesces its NULL to '' on read, so the non-nullable TS
 * type the frontend relies on is honoured rather than merely asserted.
 */
const { describe, it, before } = require('node:test');
const assert = require('node:assert/strict');

// table-ddls / dto-mapper never call the pool at load, but db.js destructures a
// pool at require time elsewhere in the tree — stub it so any transitive require
// stays side-effect-free.
const dbKey = require.resolve('../../../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: {}, t: (n) => n },
};

const { buildEngineTableDDLs } = require('../../../../src/table-ddls');
const { mapRowFromDb } = require('../../../../src/edge/lib/dto-mapper');

const COLUMN = 'naming_rule';
const SQL_TYPES = /^`?([a-z_]+)`?\s+(CHAR|VARCHAR|INT|DOUBLE|TIMESTAMP|JSON|TEXT|ENUM|BOOLEAN|TINYINT|BIGINT|DATETIME|DECIMAL|FLOAT|BLOB)\b/i;

let hierarchyDdl = null;

before(() => {
  for (const ddl of buildEngineTableDDLs((n) => n)) {
    if (ddl.includes('CREATE TABLE IF NOT EXISTS `hierarchy_nodes`')) {
      hierarchyDdl = ddl;
      break;
    }
  }
  assert.ok(hierarchyDdl, 'the DDL list no longer defines hierarchy_nodes');
});

describe('hierarchy_nodes.naming_rule — DDL parity', () => {
  it('is a declared column of hierarchy_nodes', () => {
    const cols = new Map();
    for (const rawLine of hierarchyDdl.split('\n')) {
      const line = rawLine.trim();
      if (!line || line.startsWith('--') || line.startsWith('/*')) continue;
      const m = line.match(SQL_TYPES);
      if (m) cols.set(m[1], line);
    }
    assert.ok(cols.has(COLUMN), 'hierarchy_nodes has no naming_rule column');
  });

  it('is nullable (a pre-existing row and a blueprint with no rule are both NULL)', () => {
    const line = hierarchyDdl
      .split('\n')
      .map((l) => l.trim())
      .find((l) => l.match(SQL_TYPES) && l.match(SQL_TYPES)[1] === COLUMN);
    assert.ok(line, 'could not locate the naming_rule column line');
    assert.ok(!/\bNOT\s+NULL\b/i.test(line), `naming_rule is declared NOT NULL: ${line}`);
  });
});

describe('hierarchy_nodes.naming_rule — read-serializer parity (Y-pattern)', () => {
  it('coalesces a stored NULL to the empty string', () => {
    const out = mapRowFromDb('hierarchy_nodes', { id: 'x', naming_rule: null });
    assert.equal(out.naming_rule, '', 'a NULL naming_rule was not coalesced to ""');
  });

  it('coalesces an ABSENT key (a DB predating the migration) to the empty string', () => {
    const out = mapRowFromDb('hierarchy_nodes', { id: 'x' });
    assert.equal(out.naming_rule, '', 'an absent naming_rule was not coalesced to ""');
  });

  it('passes a stored template through verbatim', () => {
    const rule = '{{part_no}}-{{rev}}';
    const out = mapRowFromDb('hierarchy_nodes', { id: 'x', naming_rule: rule });
    assert.equal(out.naming_rule, rule, 'a stored naming_rule was altered on read');
  });
});
