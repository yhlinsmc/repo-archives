/**
 * capacity-vm-site-backfill-schema-parity.test.js — validates every column the
 * cap_vms.site_id backfill migration references against the ACTUAL table DDL,
 * WITHOUT a live DB.
 *
 * The backfill is a boot-time UPDATE that repins a placed VM's stale data-centre
 * cache to its host (migration-steps.js `cap_vms_site_id_backfill_from_host`).
 * It names its columns literally, so a wrong column name is an unknown-column
 * error at boot on exactly the databases that carry legacy rows — and no mocked
 * runner reaches it. This test parses table-ddls.js and asserts the statement's
 * referenced columns exist, reading the REAL statement out of the registry's
 * own `remediationSql` rather than restating a hand-copied column list (a second
 * list can agree with the DDL while the first does not — the failure this guards).
 */
const { describe, it, before } = require('node:test');
const assert = require('node:assert/strict');

const { buildEngineTableDDLs } = require('../../../../src/table-ddls');
const { MIGRATION_STEPS } = require('../../../../src/edge/migration-steps');

const SQL_TYPES = /^`?([a-z_]+)`?\s+(?:CHAR|VARCHAR|INT|DOUBLE|TIMESTAMP|JSON|TEXT|ENUM|BOOLEAN|TINYINT|BIGINT|DATETIME|DECIMAL|FLOAT|BLOB)\b/i;
let columnsByTable;

before(() => {
  columnsByTable = new Map();
  for (const ddl of buildEngineTableDDLs((n) => n)) {
    const m = ddl.match(/CREATE TABLE IF NOT EXISTS `([^`]+)`/);
    if (!m) continue;
    const cols = new Set();
    for (const rawLine of ddl.split('\n')) {
      const line = rawLine.trim();
      if (!line || line.startsWith('--') || line.startsWith('/*')) continue;
      const cm = line.match(SQL_TYPES);
      if (cm) cols.add(cm[1]);
    }
    columnsByTable.set(m[1], cols);
  }
});

// alias → physical table, taken from the statement's own UPDATE/JOIN clauses.
function aliasesOf(statement) {
  const map = new Map();
  for (const m of statement.matchAll(/(?:UPDATE|JOIN)\s+`([a-z_]+)`\s+(\w+)\b/g)) {
    map.set(m[2], m[1]);
  }
  return map;
}

describe('cap_vms.site_id backfill — schema parity', () => {
  const entry = MIGRATION_STEPS.find((s) => s.step === 'cap_vms_site_id_backfill_from_host');
  const statements = entry ? entry.remediationSql((n) => n) : [];
  const statement = statements[0] || '';
  const aliasTable = aliasesOf(statement);

  it('the registry still carries the backfill entry', () => {
    assert.ok(entry, 'migration-steps.js no longer declares cap_vms_site_id_backfill_from_host');
    assert.equal(entry.kind, 'custom');
  });

  it('reads cap_vms and cap_hypervisors under an alias, so there is something to check', () => {
    assert.deepEqual([...aliasTable.values()].sort(), ['cap_hypervisors', 'cap_vms']);
  });

  it('every aliased column the statement names exists on the table it names it on', () => {
    const refs = [...statement.matchAll(/\b(\w+)\.(\w+)\b/g)]
      .filter(([, alias]) => aliasTable.has(alias))
      .map(([, alias, column]) => ({ table: aliasTable.get(alias), column }));
    // Guard the parse itself: v.hypervisor_id, h.id, v.site_id, h.site_id at least.
    assert.ok(refs.length >= 4, `only ${refs.length} column references found — the parse has stopped working`);
    for (const { table, column } of refs) {
      const cols = columnsByTable.get(table);
      assert.ok(cols, `statement names unknown table ${table}`);
      assert.ok(
        cols.has(column),
        `${table} has no column '${column}' — the backfill would 500 at boot while every mocked test stayed green`,
      );
    }
  });

  it('touches only placed VMs and compares the cache CASE-SENSITIVELY and null-aware', () => {
    // A placed VM (hypervisor_id NOT NULL) is the only one whose site_id the host
    // owns; an unplaced VM's site_id is operator intent and must be left alone.
    // The compare is BINARY <=> BINARY, byte-for-byte with syncVmSiteCache: the
    // CHAR(36) collation folds case, so a bare `<=>` reads a case-respelled legacy
    // id (the shape) as already-equal and skips it while the exact-case
    // readers flag it — a row the backfill must repair, not step over. `<=>` (not
    // `=`) keeps a never-written NULL cache counted as a disagreement to repair.
    assert.match(statement, /v\.hypervisor_id IS NOT NULL/);
    assert.match(statement, /NOT \(BINARY v\.site_id <=> BINARY h\.site_id\)/);
    // Guard against a silent regression back to the case-folding form.
    assert.equal(/NOT \(v\.site_id <=> h\.site_id\)/.test(statement), false,
      'the compare dropped BINARY — a case-respelled legacy id would be skipped');
  });

  it('scopes the host join to the same scenario, so a foreign-scenario host is not copied', () => {
    // Byte-for-byte with syncVmSiteCache's JOIN: without this a legacy VM whose
    // hypervisor_id names another scenario's host would be repinned to that host's
    // data centre, which the write path refuses.
    assert.match(statement, /h\.scenario_id = v\.scenario_id/);
  });
});
