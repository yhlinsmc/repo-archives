/**
 * capacity-database-bulk-create.test.js — the Add-Database wizard's transactional
 * persist endpoint (placement-hub spec §3/§11).
 *
 * Two layers:
 *   1. PURE buildDatabaseBulkPlan — payload validation, topology cardinality
 *      (spec §10.1, single/primary_standby/rac), placement shape (exactly one of
 *      vm_id | new_vm), standby-only-under-primary_standby, bounds.
 *   2. Route behaviour against a mock edge/db — happy-path materialization in ONE
 *      transaction (database + instances + new db_host VMs), all-or-nothing (a
 *      mid-transaction failure rolls back everything), reference-integrity 400,
 *      permission gating (plain user 403, missing scenario 404).
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

// ── Mock edge/db BEFORE requiring the router ──────────────────────────────────
const dbKey = require.resolve('../../../../src/edge/db');

let state;
function freshState() {
  return {
    queries: [],
    began: 0, committed: 0, rolledBack: 0, released: 0,
    // resolveScenarioWriteAccess: SELECT id, owner_id FROM cap_scenarios.
    scenarioFound: true,
    scenarioOwnerId: null, // null = shared (any editor/admin may write)
    // §17.1a reference probe knobs.
    refFound: true,          // does every referenced row exist?
    refForeignScenario: false, // force a scenario-mode ref to a foreign scenario
    vmType: 'db_host',       // vm_type a cap_vms reference probe reports
    // Sizing hydration fixtures.
    profiles: {},            // id → { class, mode, cpu, mem_gb, sga_cap_gb, allowed_disk_combos }
    combos: {},              // id → sizes JSON
    settingsRow: null,
    hypervisorSiteId: 'site-1',
    // A table whose INSERT throws (simulate a mid-transaction DB failure).
    throwOnInsertInto: null,
    // does checkDatabaseFunctionNameCharset's per-scenario lookup find
    // this exact function_name spelling already stored?
    databaseFunctionNameGrandfathered: false,
    // F2 degraded-schema probe: the physical cap_databases column set the
    // write-side tableColumnSet reads. null → the full set (standby_node_count
    // PRESENT, today's behaviour). Set to a set WITHOUT standby_node_count to
    // model a warn-skipped add-column migration.
    databasesColumns: null,
    // X3/H1: does the LIVE topology ENUM already carry BOTH renamed members
    // (rac_multinode + rac_multinode_standby)? true (default) = renamed.
    // false models the rename migration step not having run yet — a
    // narrow-enum degraded schema, gating EITHER renamed member (H1,
    // round 1 review — originally standby-only).
    topologyEnumRenamed: true,
  };
}

// A representative real cap_databases physical column set — used when a test
// does not override it (F2).
const FULL_DATABASES_COLUMNS = [
  'id', 'scenario_id', 'function_name', 'topology', 'node_count', 'standby_node_count',
  'profile_id', 'disk_combo_id', 'team_id', 'primary_sga_gb', 'standby_sga_gb',
  'description', 'order_index', 'metadata',
];

const conn = {
  async beginTransaction() { state.began += 1; },
  async commit() { state.committed += 1; },
  async rollback() { state.rolledBack += 1; },
  release() { state.released += 1; },
  async query(sql, params = []) {
    state.queries.push({ sql, params });

    // resolveScenarioWriteAccess.
    if (/^SELECT id, owner_id FROM `fmb_cap_scenarios` WHERE id = \?/.test(sql)) {
      if (!state.scenarioFound) return [];
      return [{ id: params[0], owner_id: state.scenarioOwnerId }];
    }

    // §17.1a reference-integrity probe (with the FOR-UPDATE lock).
    if (/SELECT id, scenario_id(?:, vm_type)?, \(scenario_id = \?\) AS same_scenario[\s\S]*FROM `fmb_(cap_[a-z_]+)` WHERE id = \?/.test(sql)) {
      if (!state.refFound) return [];
      const table = RegExp.$1;
      const [referencingScenarioId, id] = params;
      // Catalogue tables answer global (scenario_id NULL); scenario-internal
      // tables answer same-scenario unless a foreign-scenario ref is forced.
      const isCatalogue = /vm_profiles|disk_combos|teams|hardware_specs/.test(table);
      const owner = isCatalogue ? null
        : (state.refForeignScenario ? 'other-scenario' : referencingScenarioId);
      const same = owner == null || referencingScenarioId == null
        ? null
        : (String(owner).toLowerCase() === String(referencingScenarioId).toLowerCase() ? 1 : 0);
      const row = { id, scenario_id: owner, same_scenario: same };
      if (/vm_type/.test(sql)) row.vm_type = state.vmType;
      return [row];
    }

    // loadSizingContext: profiles IN (...).
    if (/^SELECT id, class, mode, cpu, mem_gb, sga_cap_gb, allowed_disk_combos FROM `fmb_cap_vm_profiles` WHERE id IN/.test(sql)) {
      return params.filter((id) => state.profiles[id]).map((id) => ({ id, ...state.profiles[id] }));
    }
    // loadSizingContext: disk combos IN (...).
    if (/^SELECT id, sizes FROM `fmb_cap_disk_combos` WHERE id IN/.test(sql)) {
      return params.filter((id) => state.combos[id] != null).map((id) => ({ id, sizes: state.combos[id] }));
    }
    // loadSizingContext: scenario-effective settings.
    if (/FROM `fmb_cap_settings` WHERE scenario_id = \? OR scenario_id IS NULL/.test(sql)) {
      return state.settingsRow ? [state.settingsRow] : [];
    }
    // New-VM site derivation from its host.
    if (/^SELECT site_id FROM `fmb_cap_hypervisors` WHERE id = \? LIMIT 1 FOR UPDATE/.test(sql)) {
      return [{ site_id: state.hypervisorSiteId }];
    }
    // nextOrderIndex.
    if (/COALESCE\(MAX\(order_index\), -1\) \+ 1 AS next/.test(sql)) {
      return [{ next: 0 }];
    }
    // checkDatabaseFunctionNameCharset's per-scenario grandfather lookup.
    if (/^SELECT 1 FROM `fmb_cap_databases` WHERE scenario_id = \? AND function_name = \? LIMIT 1/.test(sql)) {
      return state.databaseFunctionNameGrandfathered ? [{ 1: 1 }] : [];
    }
    // X3/H1: the topology ENUM-rename probe (`_topologyEnumHasMember`) —
    // disambiguated from the tableColumnSet probe below by its OWN SELECT
    // clause (`COLUMN_TYPE`, not `COLUMN_NAME`).
    if (/information_schema\.COLUMNS/i.test(sql) && /COLUMN_TYPE/i.test(sql)) {
      return state.topologyEnumRenamed
        ? [{ type: "enum('single','primary','primary_standby','rac_multinode','rac_multinode_standby')" }]
        : [{ type: "enum('single','primary','primary_standby','rac_multinode')" }];
    }
    // F2 write-side degraded-schema probe (tableColumnSet): cap_databases.
    if (/information_schema\.COLUMNS/i.test(sql)) {
      const cols = state.databasesColumns ?? FULL_DATABASES_COLUMNS;
      return cols.map((name) => ({ name }));
    }

    const insertMatch = sql.match(/^INSERT INTO `fmb_(cap_[a-z_]+)`/);
    if (insertMatch) {
      if (state.throwOnInsertInto && insertMatch[1] === state.throwOnInsertInto) {
        const e = new Error('simulated insert failure');
        e.errno = 1213;
        throw e;
      }
      return { affectedRows: 1, insertId: 1 };
    }
    return [];
  },
};

const poolFacade = {
  getConnection: async () => conn,
  query: (sql, params) => conn.query(sql, params),
};
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: { ro: poolFacade, rw: poolFacade }, t: (n) => `fmb_${n}` },
};

const bulk = require('../../../../src/edge/routes/app/capacity/database-bulk-create');
const router = require('../../../../src/edge/routes/app/capacity');
const { buildDatabaseBulkPlan } = bulk;
// The write-side column probe caches per physical table (60s TTL) — reset
// between cases so a "present" fixture never leaks into a later "absent" case.
const { _resetColumnSetCache, _resetTopologySchemaCache } = require('../../../../src/edge/routes/app/capacity/_shared');

const SCENARIO = '11111111-1111-1111-1111-111111111111';
const HV = '22222222-2222-2222-2222-222222222222';
const EXISTING_VM = '33333333-3333-3333-3333-333333333333';
const PROF_DB = '44444444-4444-4444-4444-444444444444';
const PROF_AP = '55555555-5555-5555-5555-555555555555';
const COMBO_OK = '66666666-6666-6666-6666-666666666666';
const COMBO_BAD = '77777777-7777-7777-7777-777777777777';

// New-VM placement onto a hypervisor (the common step-3 choice). Every FK value
// must be UUID-shaped — the endpoint runs the identifier floor via checkReferences.
const placed = (name, hv = HV) => ({ new_vm: { name, hypervisor_id: hv } });

// Every default payload names a database profile_id — it is REQUIRED (this
// finding: a null/absent profile_id used to persist a zero-sized VM/instance
// chain via a direct POST, bypassing the wizard's client-only gate). Tests that
// exercise the missing-profile 400 override `database` explicitly.
function singlePayload(overrides = {}) {
  return {
    database: { function_name: 'erp', topology: 'single', profile_id: PROF_DB },
    instances: [{ name: 'erp1', role: 'primary', placement: placed('erp-db-1') }],
    ...overrides,
  };
}

function primaryStandbyPayload() {
  return {
    database: { function_name: 'mes', topology: 'primary_standby', profile_id: PROF_DB },
    instances: [
      { name: 'mes1', role: 'primary', placement: placed('mes-db-1') },
      { name: 'mes2', role: 'primary', placement: placed('mes-db-2') },
      { name: 'mes1', role: 'standby', placement: placed('mes-db-3') },
      { name: 'mes2', role: 'standby', placement: placed('mes-db-4') },
    ],
  };
}

function racPayload(nodeCount = 3) {
  const instances = [];
  for (let i = 1; i <= nodeCount; i += 1) {
    instances.push({ name: `rac${i}`, role: 'primary', placement: placed(`rac-db-${i}`) });
  }
  return { database: { function_name: 'rac', topology: 'rac_multinode', node_count: nodeCount, profile_id: PROF_DB }, instances };
}

// spec §7 E1 / Q11: primary N + standby S — both sides share ONE name family,
// serial per side (same design as primary_standby's mes1/mes2 sharing above).
function racStandbyPayload(nodeCount = 3, standbyNodeCount = nodeCount) {
  const instances = [];
  for (let i = 1; i <= nodeCount; i += 1) {
    instances.push({ name: `orcl${i}`, role: 'primary', placement: placed(`orcl-p-${i}`) });
  }
  for (let i = 1; i <= standbyNodeCount; i += 1) {
    instances.push({ name: `orcl${i}`, role: 'standby', placement: placed(`orcl-s-${i}`) });
  }
  return {
    database: {
      function_name: 'orcl', topology: 'rac_multinode_standby', node_count: nodeCount,
      standby_node_count: standbyNodeCount, profile_id: PROF_DB,
    },
    instances,
  };
}

// ── Route harness ─────────────────────────────────────────────────────────────
let currentUser; let server; let baseUrl;
before(async () => {
  const app = express();
  app.use(express.json({ limit: '10mb' }));
  app.use((req, _res, next) => { req.user = currentUser; next(); });
  app.use('/capacity', router);
  server = http.createServer(app);
  await new Promise((r) => server.listen(0, r));
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});
after(() => server && server.close());
beforeEach(() => {
  state = freshState();
  currentUser = { id: 'u-admin', role: 'admin' };
  _resetColumnSetCache();
  _resetTopologySchemaCache();
});

function request(method, path, body) {
  return new Promise((resolve, reject) => {
    const payload = body === undefined ? '' : JSON.stringify(body);
    const r = http.request(
      `${baseUrl}${path}`,
      { method, headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) } },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          const raw = Buffer.concat(chunks).toString('utf8');
          let json = null;
          try { json = JSON.parse(raw); } catch { /* noop */ }
          resolve({ status: res.statusCode, json, raw });
        });
      },
    );
    r.on('error', reject);
    if (payload) r.write(payload);
    r.end();
  });
}

const post = (body) => request('POST', `/capacity/scenarios/${SCENARIO}/databases/bulk-create`, body);
const insertsInto = (table) => state.queries.filter((q) => new RegExp(`^INSERT INTO \`fmb_${table}\``).test(q.sql));
const anyEntityInsert = () => state.queries.some((q) => /^INSERT INTO `fmb_cap_/.test(q.sql));

// ── 1. PURE plan validation ───────────────────────────────────────────────────
describe('buildDatabaseBulkPlan — topology cardinality (spec §10.1)', () => {
  it('accepts a well-formed single database', () => {
    const out = buildDatabaseBulkPlan(singlePayload());
    assert.equal(out.ok, true, JSON.stringify(out.errors));
    assert.equal(out.plan.instances.length, 1);
    assert.equal(out.plan.newVms.length, 1);
  });

  it('accepts a full primary_standby cluster (2 primary + 2 standby)', () => {
    const out = buildDatabaseBulkPlan(primaryStandbyPayload());
    assert.equal(out.ok, true, JSON.stringify(out.errors));
    assert.equal(out.plan.instances.length, 4);
  });

  it('accepts a RAC cluster of node_count primary instances', () => {
    const out = buildDatabaseBulkPlan(racPayload(3));
    assert.equal(out.ok, true, JSON.stringify(out.errors));
    assert.equal(out.plan.instances.filter((i) => i.role === 'primary').length, 3);
  });

  it('rejects the wrong instance count for a topology', () => {
    const out = buildDatabaseBulkPlan(singlePayload({
      instances: [
        { name: 'a', role: 'primary', placement: placed('a') },
        { name: 'b', role: 'primary', placement: placed('b') },
      ],
    }));
    assert.equal(out.ok, false);
    assert.ok(out.errors.some((e) => /expected 1 primary/.test(e)), JSON.stringify(out.errors));
  });

  it('rejects a standby under a non-primary_standby topology', () => {
    const out = buildDatabaseBulkPlan(singlePayload({
      instances: [{ name: 'a', role: 'standby', placement: placed('a') }],
    }));
    assert.equal(out.ok, false);
    assert.ok(out.errors.some((e) => /standby instance is only allowed/.test(e)));
  });

  it('rejects a placement that names both vm_id and new_vm', () => {
    const out = buildDatabaseBulkPlan(singlePayload({
      instances: [{ name: 'a', role: 'primary', placement: { vm_id: 'v', new_vm: { name: 'n' } } }],
    }));
    assert.equal(out.ok, false);
    assert.ok(out.errors.some((e) => /exactly one of vm_id or new_vm/.test(e)));
  });

  it('rejects a missing placement (an instance must attach to a db_host VM)', () => {
    const out = buildDatabaseBulkPlan(singlePayload({
      instances: [{ name: 'a', role: 'primary' }],
    }));
    assert.equal(out.ok, false);
    assert.ok(out.errors.some((e) => /placement is required/.test(e)));
  });

  it('413-shapes an oversized instances array', () => {
    const instances = Array.from({ length: 200 }, (_, i) => ({ name: `n${i}`, role: 'primary', placement: placed(`n${i}`) }));
    const out = buildDatabaseBulkPlan(singlePayload({ instances }));
    assert.equal(out.ok, false);
    assert.equal(out.tooLarge, true);
  });

  it('accepts an existing-VM placement (no new VM minted)', () => {
    const out = buildDatabaseBulkPlan(singlePayload({
      instances: [{ name: 'a', role: 'primary', placement: { vm_id: EXISTING_VM } }],
    }));
    assert.equal(out.ok, true, JSON.stringify(out.errors));
    assert.equal(out.plan.newVms.length, 0);
    assert.equal(out.plan.instances[0].placement.existingVmId, EXISTING_VM);
  });

  it('rejects a rac node_count out of range', () => {
    assert.equal(buildDatabaseBulkPlan(racPayload(1)).ok, false);
    assert.equal(buildDatabaseBulkPlan(racPayload(101)).ok, false);
  });

  describe('rac_multinode_standby (spec §7 E1 / Q11)', () => {
    it('accepts N primary + S standby, S≠N, names shared per-index', () => {
      const out = buildDatabaseBulkPlan(racStandbyPayload(4, 2));
      assert.equal(out.ok, true, JSON.stringify(out.errors));
      assert.equal(out.plan.instances.filter((i) => i.role === 'primary').length, 4);
      assert.equal(out.plan.instances.filter((i) => i.role === 'standby').length, 2);
    });
    it('S=1 is a legal edge case (no clustering floor on the standby side)', () => {
      const out = buildDatabaseBulkPlan(racStandbyPayload(3, 1));
      assert.equal(out.ok, true, JSON.stringify(out.errors));
    });
    // F1 fix: an OMITTED standby_node_count no longer errors — it defaults to N
    // (nodeCount), matching wizard.js's own copy of this rule (Q11: "S defaults
    // to N"). racStandbyPayload(3, 3) already generates 3+3 instances, which is
    // exactly what N=3 defaults S to once the field is deleted.
    it('an omitted standby_node_count defaults to N', () => {
      const p = racStandbyPayload(3, 3);
      delete p.database.standby_node_count;
      const out = buildDatabaseBulkPlan(p);
      assert.equal(out.ok, true, JSON.stringify(out.errors));
      assert.equal(out.plan.database.standby_node_count, 3);
    });
    it('rejects an explicit invalid standby_node_count (a present malformed value still 400s)', () => {
      const p = racStandbyPayload(3, 3);
      p.database.standby_node_count = -1;
      const out = buildDatabaseBulkPlan(p);
      assert.equal(out.ok, false);
      assert.ok(out.errors.some((e) => /RAC \+ Standby standby_node_count must be an integer/.test(e)), JSON.stringify(out.errors));
    });
    it('rejects a standby_node_count out of range', () => {
      assert.equal(buildDatabaseBulkPlan(racStandbyPayload(3, 0)).ok, false);
      assert.equal(buildDatabaseBulkPlan(racStandbyPayload(3, 101)).ok, false);
    });
    it('rejects a standby instance count mismatch (N ok, S wrong)', () => {
      const p = racStandbyPayload(3, 2);
      p.instances.pop(); // drop one standby instance → 3 primary + 1 standby, expected 3+2
      const out = buildDatabaseBulkPlan(p);
      assert.equal(out.ok, false);
      assert.ok(out.errors.some((e) => /expected 3 primary \+ 2 standby/.test(e)), JSON.stringify(out.errors));
    });
  });

  it('rejects a null database.profile_id (COLUMN_REQUIRED)', () => {
    const out = buildDatabaseBulkPlan(singlePayload({
      database: { function_name: 'erp', topology: 'single', profile_id: null },
    }));
    assert.equal(out.ok, false);
    assert.equal(out.columnRequiredMessage, 'database: profile_id is required');
    assert.ok(out.errors.some((e) => /profile_id is required/.test(e)), JSON.stringify(out.errors));
  });

  it('rejects an absent database.profile_id the same way as an explicit null', () => {
    const out = buildDatabaseBulkPlan(singlePayload({
      database: { function_name: 'erp', topology: 'single' },
    }));
    assert.equal(out.ok, false);
    assert.equal(out.columnRequiredMessage, 'database: profile_id is required');
  });
});

// ── 2. Route behaviour ────────────────────────────────────────────────────────
describe('POST .../databases/bulk-create — one transaction', () => {
  it('materializes a single database + instance + new VM and returns their ids', async () => {
    const res = await post(singlePayload());
    assert.equal(res.status, 201, res.raw);
    const data = res.json.data;
    assert.ok(data.database.id);
    assert.equal(data.instances.length, 1);
    assert.equal(data.vms.length, 1);
    assert.equal(data.instances[0].vm_id, data.vms[0].id, 'instance attaches to the created VM');
    assert.equal(state.committed, 1);
    assert.equal(state.rolledBack, 0);
    assert.equal(insertsInto('cap_databases').length, 1);
    assert.equal(insertsInto('cap_vms').length, 1);
    assert.equal(insertsInto('cap_db_instances').length, 1);
  });

  it('materializes a primary_standby cluster: 1 db + 4 instances + 4 VMs', async () => {
    const res = await post(primaryStandbyPayload());
    assert.equal(res.status, 201, res.raw);
    assert.equal(insertsInto('cap_databases').length, 1);
    assert.equal(insertsInto('cap_vms').length, 4);
    assert.equal(insertsInto('cap_db_instances').length, 4);
    assert.equal(state.committed, 1);
  });

  it('materializes a RAC cluster of 3 nodes', async () => {
    const res = await post(racPayload(3));
    assert.equal(res.status, 201, res.raw);
    assert.equal(insertsInto('cap_db_instances').length, 3);
    assert.equal(insertsInto('cap_vms').length, 3);
  });

  // spec §7 E1 / Q11: materializes N primary + S standby, persisting BOTH
  // node_count (N) and standby_node_count (S) onto cap_databases.
  it('materializes a rac_multinode_standby cluster of 4 primary + 2 standby, persisting node_count + standby_node_count', async () => {
    const res = await post(racStandbyPayload(4, 2));
    assert.equal(res.status, 201, res.raw);
    assert.equal(insertsInto('cap_db_instances').length, 6);
    assert.equal(insertsInto('cap_vms').length, 6);
    // INSERT_COLUMNS[CAP_DATABASES] order: id, scenario_id, function_name,
    // topology, node_count, standby_node_count, ... — params[4]/[5].
    const dbInsert = insertsInto('cap_databases')[0];
    assert.equal(dbInsert.params[4], 4, 'node_count (N)');
    assert.equal(dbInsert.params[5], 2, 'standby_node_count (S)');
  });

  // F2 (review round-2 finding): standby_node_count is a NEW column named
  // UNCONDITIONALLY in the INSERT — a warn-skipped add-column migration used
  // to 500 EVERY database create (not just rac_multinode_standby, since this is one
  // INSERT statement per row).
  describe('F2: degrades the cap_databases INSERT when standby_node_count is physically absent', () => {
    // X3 supersedes the column-only-degraded rac_multinode_standby scenario (see the X3
    // describe block below) — a rac_multinode_standby row on a schema missing the
    // standby_node_count column is now cleanly rejected upfront rather than
    // silently degrading via column omission. The omission mechanic itself is
    // still exercised by the NON-rac_multinode_standby test right below.
    it('a degraded schema does not regress a NON-rac_multinode_standby (single) database create', async () => {
      state.databasesColumns = FULL_DATABASES_COLUMNS.filter((c) => c !== 'standby_node_count');
      const res = await post(singlePayload());
      assert.equal(res.status, 201, res.raw);
      assert.equal(state.committed, 1);
    });

    it('the id fail-safe: an empty/odd probe (no id column) assumes present and still names the column', async () => {
      state.databasesColumns = []; // empty probe → fail-safe → assume present
      const res = await post(racStandbyPayload(4, 2));
      assert.equal(res.status, 201, res.raw);
      const dbInsert = insertsInto('cap_databases')[0];
      assert.equal(dbInsert.params[5], 2, 'standby_node_count (S) still named');
    });

    it('a present-column schema names standby_node_count as before (no regression)', async () => {
      const res = await post(racStandbyPayload(4, 2));
      assert.equal(res.status, 201, res.raw);
      const dbInsert = insertsInto('cap_databases')[0];
      assert.equal(dbInsert.params[5], 2);
    });
  });

  // X3 (Codex round 2, P2 — degraded-schema family, F2 was member 1): reject
  // topology=rac_multinode_standby with a clean 4xx (409) at validation time whenever
  // EITHER half of "does the schema support rac_multinode_standby" is missing (narrow
  // enum OR absent column) — never reaching MariaDB's own ENUM domain error.
  describe('X3: rejects rac_multinode_standby with a clean 4xx when the schema does not support it', () => {
    it('narrow topology ENUM (not yet widened) -> 409, nothing written', async () => {
      state.topologyEnumRenamed = false;
      const res = await post(racStandbyPayload(4, 2));
      assert.equal(res.status, 409, res.raw);
      assert.equal(res.json.error.code, 'TOPOLOGY_SCHEMA_UNSUPPORTED');
      assert.equal(insertsInto('cap_databases').length, 0);
    });

    it('standby_node_count column absent (enum widened) -> 409, nothing written', async () => {
      state.databasesColumns = FULL_DATABASES_COLUMNS.filter((c) => c !== 'standby_node_count');
      const res = await post(racStandbyPayload(4, 2));
      assert.equal(res.status, 409, res.raw);
      assert.equal(res.json.error.code, 'TOPOLOGY_SCHEMA_UNSUPPORTED');
      assert.equal(insertsInto('cap_databases').length, 0);
    });

    it('both narrow enum AND absent column -> still one clean 409, not a 500', async () => {
      state.topologyEnumRenamed = false;
      state.databasesColumns = FULL_DATABASES_COLUMNS.filter((c) => c !== 'standby_node_count');
      const res = await post(racStandbyPayload(4, 2));
      assert.equal(res.status, 409, res.raw);
      assert.equal(res.json.error.code, 'TOPOLOGY_SCHEMA_UNSUPPORTED');
    });

    it('a full schema (enum widened AND column present) is unchanged -> 201', async () => {
      const res = await post(racStandbyPayload(4, 2));
      assert.equal(res.status, 201, res.raw);
      const dbInsert = insertsInto('cap_databases')[0];
      assert.equal(dbInsert.params[5], 2);
    });

    it('a narrow enum never blocks a NON-rac_multinode_standby create (the gate is topology-scoped)', async () => {
      state.topologyEnumRenamed = false;
      const res = await post(singlePayload());
      assert.equal(res.status, 201, res.raw);
      assert.equal(state.committed, 1);
    });
  });

  // H1 (round 1 review): the base rac_multinode member is EQUALLY
  // exposed to the narrow-ENUM gap — a no-DDL-privilege deployment that
  // skipped the rename migration must reject a plain RAC multi-node create
  // the same clean way it already rejects a +Standby one.
  describe('H1: rejects rac_multinode (base, no standby) with a clean 4xx when the schema does not support it', () => {
    it('narrow topology ENUM (not yet renamed) -> 409, nothing written', async () => {
      state.topologyEnumRenamed = false;
      const res = await post(racPayload(3));
      assert.equal(res.status, 409, res.raw);
      assert.equal(res.json.error.code, 'TOPOLOGY_SCHEMA_UNSUPPORTED');
      assert.equal(insertsInto('cap_databases').length, 0);
    });

    it('a renamed schema is unchanged -> 201 (base value needs no standby_node_count column)', async () => {
      const res = await post(racPayload(3));
      assert.equal(res.status, 201, res.raw);
      assert.equal(state.committed, 1);
    });

    it('absent standby_node_count column alone never blocks the base value (no standby half to gate)', async () => {
      state.databasesColumns = FULL_DATABASES_COLUMNS.filter((c) => c !== 'standby_node_count');
      const res = await post(racPayload(3));
      assert.equal(res.status, 201, res.raw);
      assert.equal(state.committed, 1);
    });
  });

  it('400s the wrong instance count and writes nothing', async () => {
    const res = await post(singlePayload({
      instances: [
        { name: 'a', role: 'primary', placement: placed('a') },
        { name: 'b', role: 'primary', placement: placed('b') },
      ],
    }));
    assert.equal(res.status, 400, res.raw);
    assert.equal(anyEntityInsert(), false);
    assert.equal(state.began, 0, 'validation fails before the transaction opens');
  });

  it('rolls back everything on a mid-transaction lock-race failure (409 WRITE_CONFLICT, zero rows committed)', async () => {
    state.throwOnInsertInto = 'cap_db_instances'; // fail on the LAST insert, errno 1213 (deadlock victim)
    const res = await post(singlePayload());
    assert.equal(res.status, 409, res.raw);
    assert.equal(res.json.error.code, 'WRITE_CONFLICT');
    assert.equal(insertsInto('cap_databases').length, 1, 'the failure is genuinely mid-transaction');
    assert.equal(insertsInto('cap_vms').length, 1);
    assert.equal(state.committed, 0, 'nothing is committed');
    assert.equal(state.rolledBack, 1, 'the whole transaction rolls back');
  });

  it('403s a plain (non-editor) user before opening a transaction', async () => {
    currentUser = { id: 'u1', role: 'user' };
    const res = await post(singlePayload());
    assert.equal(res.status, 403, res.raw);
    assert.equal(state.began, 0);
    assert.equal(anyEntityInsert(), false);
  });

  it('404s a missing scenario and writes nothing', async () => {
    state.scenarioFound = false;
    const res = await post(singlePayload());
    assert.equal(res.status, 404, res.raw);
    assert.equal(anyEntityInsert(), false);
    assert.equal(state.rolledBack, 1);
  });

  it('201s an editor who IS the scenario owner', async () => {
    // owner_id byte-identical to the actor → owner.
    currentUser = { id: 'editor-a', role: 'editor' };
    state.scenarioOwnerId = 'editor-a';
    const own = await post(singlePayload());
    assert.equal(own.status, 201, own.raw);
  });

  it('403s an editor who is NOT the scenario owner', async () => {
    // owner_id a different byte string than the actor → not the owner, not shared.
    currentUser = { id: 'editor-a', role: 'editor' };
    state.scenarioOwnerId = 'editor-b';
    const res = await post(singlePayload());
    assert.equal(res.status, 403, res.raw);
    assert.equal(anyEntityInsert(), false);
    assert.equal(state.rolledBack, 1, 'the FOR-UPDATE-locked authz gate rolls back before any insert');
  });

  it('400s a foreign / missing reference and writes nothing', async () => {
    state.refFound = false; // the hypervisor reference does not resolve
    const res = await post(singlePayload());
    assert.equal(res.status, 400, res.raw);
    assert.equal(anyEntityInsert(), false);
    assert.equal(state.rolledBack, 1);
  });

  it('400s a disk combo outside the profile allow-list and writes nothing', async () => {
    state.profiles = { [PROF_DB]: { class: 'DB', mode: 'formula', cpu: 4, mem_gb: 80, sga_cap_gb: 30, allowed_disk_combos: JSON.stringify([COMBO_OK]) } };
    const res = await post(singlePayload({
      database: { function_name: 'erp', topology: 'single', profile_id: PROF_DB, disk_combo_id: COMBO_BAD },
    }));
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'DISK_COMBO_NOT_ALLOWED');
    assert.equal(anyEntityInsert(), false);
  });

  it('400s an AP-class database profile (class coherence)', async () => {
    state.profiles = { [PROF_AP]: { class: 'AP', mode: 'formula', cpu: 4, mem_gb: 80, sga_cap_gb: null, allowed_disk_combos: null } };
    const res = await post(singlePayload({
      database: { function_name: 'erp', topology: 'single', profile_id: PROF_AP },
    }));
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'INVALID_REFERENCE');
    assert.equal(anyEntityInsert(), false);
  });

  it('400s COLUMN_REQUIRED when database.profile_id is null and writes nothing', async () => {
    const res = await post(singlePayload({
      database: { function_name: 'erp', topology: 'single', profile_id: null },
    }));
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'COLUMN_REQUIRED');
    assert.match(res.json.error.message, /profile_id is required/);
    assert.equal(anyEntityInsert(), false);
    assert.equal(state.began, 0, 'validation fails before the transaction opens');
  });

  it('400s COLUMN_REQUIRED when database.profile_id is absent and writes nothing', async () => {
    const res = await post(singlePayload({
      database: { function_name: 'erp', topology: 'single' },
    }));
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'COLUMN_REQUIRED');
    assert.equal(anyEntityInsert(), false);
  });

  it('an absent new_vm.sizing_profile_id inherits database.profile_id and derives non-zero sizing', async () => {
    state.profiles = {
      [PROF_DB]: { class: 'DB', mode: 'formula', cpu: 4, mem_gb: 80, sga_cap_gb: 30, allowed_disk_combos: null },
    };
    const res = await post(singlePayload({
      instances: [{ name: 'erp1', role: 'primary', placement: { new_vm: { name: 'erp-db-1', hypervisor_id: HV } } }],
    }));
    assert.equal(res.status, 201, res.raw);
    const vmInsert = insertsInto('cap_vms')[0];
    const cols = bulk.INSERT_COLUMNS.cap_vms;
    const byCol = Object.fromEntries(cols.map((c, i) => [c, vmInsert.params[i]]));
    assert.equal(byCol.sizing_profile_id, PROF_DB, 'the new VM inherits the database profile_id');
    assert.ok(byCol.cpu > 0, `expected non-zero derived cpu, got ${byCol.cpu}`);
    assert.ok(byCol.mem_gb > 0, `expected non-zero derived mem_gb, got ${byCol.mem_gb}`);
  });

  it('an explicit new_vm.sizing_profile_id is NOT overridden by inheritance and still runs the class check', async () => {
    state.profiles = {
      [PROF_AP]: { class: 'AP', mode: 'formula', cpu: 4, mem_gb: 80, sga_cap_gb: null, allowed_disk_combos: null },
    };
    const res = await post(singlePayload({
      instances: [{
        name: 'erp1',
        role: 'primary',
        placement: { new_vm: { name: 'erp-db-1', hypervisor_id: HV, sizing_profile_id: PROF_AP } },
      }],
    }));
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'INVALID_REFERENCE');
    assert.equal(anyEntityInsert(), false);
  });
});

// ── database.function_name charset, grandfathered per-scenario ───────
// The SAME contract makeDatabaseFunctionNameGuard enforces on the generic child
// mount (capacity-routes.test.js), re-stated here because this endpoint's own
// transactional INSERT bypasses that mount entirely.
describe('POST .../databases/bulk-create — function_name charset guard (fmb-1705)', () => {
  const GRANDFATHER_LOOKUP = /^SELECT 1 FROM `fmb_cap_databases` WHERE scenario_id = \? AND function_name = \? LIMIT 1/;

  it('a conforming function_name creates the database, no grandfather lookup needed', async () => {
    const res = await post(singlePayload({
      database: { function_name: 'erp-prod', topology: 'single', profile_id: PROF_DB },
    }));
    assert.equal(res.status, 201, res.raw);
    assert.equal(insertsInto('cap_databases').length, 1);
    assert.equal(state.queries.some((q) => GRANDFATHER_LOOKUP.test(q.sql)), false);
  });

  it('a NEW non-conforming function_name (not grandfathered) → 400, nothing written', async () => {
    state.databaseFunctionNameGrandfathered = false;
    const res = await post(singlePayload({
      database: { function_name: 'erp_prod', topology: 'single', profile_id: PROF_DB },
    }));
    assert.equal(res.status, 400, res.raw);
    assert.match(res.raw, /function_name may only contain letters, digits and hyphens/);
    assert.equal(anyEntityInsert(), false);
    assert.equal(state.rolledBack, 1);
  });

  it('a non-conforming function_name already stored in THIS scenario → 201 (grandfathered)', async () => {
    state.databaseFunctionNameGrandfathered = true;
    const res = await post(singlePayload({
      database: { function_name: 'erp_prod', topology: 'single', profile_id: PROF_DB },
    }));
    assert.equal(res.status, 201, res.raw);
    assert.equal(insertsInto('cap_databases').length, 1);
    const lookup = state.queries.find((q) => GRANDFATHER_LOOKUP.test(q.sql));
    assert.ok(lookup, 'the grandfather lookup ran');
    assert.equal(lookup.params[0], SCENARIO, 'scoped to THIS scenario');
    assert.equal(lookup.params[1], 'erp_prod', 'the exact value insertRow ends up writing');
  });

  it('the charset check runs BEFORE §17.1a reference-integrity (cheap, lock-free work first)', async () => {
    state.databaseFunctionNameGrandfathered = false;
    state.refFound = false; // would ALSO 400 on the reference check if reached
    const res = await post(singlePayload({
      database: { function_name: 'erp_prod', topology: 'single', profile_id: PROF_DB },
    }));
    assert.equal(res.status, 400, res.raw);
    assert.match(res.raw, /function_name may only contain letters, digits and hyphens/, 'the charset rejection fired, not a reference error');
  });

  // codex r1: TOCTOU — checkDatabaseFunctionNameCharset takes no lock
  // of its own, but this route already locks the scenario row FOR UPDATE
  // (resolveScenarioWriteAccess, `lock: true`) BEFORE reaching it, so the
  // lookup runs INSIDE that lock rather than ahead of it. A concurrent tx
  // deleting/renaming the legacy row this lookup finds must wait on the same
  // cap_scenarios row, so nothing can commit between the lookup and this
  // transaction's INSERT. Deterministic proof: the scenario lock precedes the
  // lookup in the request's own query trace.
  it('the scenario row is locked BEFORE the grandfather lookup runs', async () => {
    const SCENARIO_LOCK = /^SELECT id, owner_id FROM `fmb_cap_scenarios` WHERE id = \?/;
    state.databaseFunctionNameGrandfathered = true;
    const res = await post(singlePayload({
      database: { function_name: 'erp_prod', topology: 'single', profile_id: PROF_DB },
    }));
    assert.equal(res.status, 201, res.raw);
    const lockIdx = state.queries.findIndex((q) => SCENARIO_LOCK.test(q.sql));
    const lookupIdx = state.queries.findIndex((q) => GRANDFATHER_LOOKUP.test(q.sql));
    assert.ok(lockIdx !== -1, 'scenario row must be locked FOR UPDATE');
    assert.ok(lookupIdx !== -1, 'the grandfather lookup must run');
    assert.ok(lockIdx < lookupIdx, 'the scenario lock must precede the lookup — no TOCTOU window on this endpoint');
  });
});
