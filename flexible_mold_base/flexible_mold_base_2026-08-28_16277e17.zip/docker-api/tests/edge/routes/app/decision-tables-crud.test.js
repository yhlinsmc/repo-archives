/**
 * decision-tables-crud.test.js — the /decision_tables CRUD mount.
 *
 * Stub-connection tests (no live DB), so the assertions deliberately target the
 * SQL + BOUND PARAMETERS the route actually issues rather than the stubbed
 * response: a mocked write that only checks the HTTP status stays green even
 * when the payload never reaches the column it claims to. Every write test here
 * inspects the real INSERT/UPDATE the factory built.
 *
 * Covers: JSON document round-trip through the DTO mapper, the write-boundary
 * document guards (shape + 1 MB cap), the blueprint-scoped ownership + linked-
 * blueprint contract, and the read coalescing that keeps `doc` non-null.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const { answerCollationProbe } = require('../../../helpers/collation-probe');
const { answerParentIdProbe } = require('../../../helpers/parent-id-probe');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../../../src/edge/db');

const DATABASE_PROBE = /^SELECT DATABASE\(\)/i;
const COLUMN_PROBE = /SELECT COLUMN_NAME FROM information_schema\.COLUMNS/i;
// The one-table-per-output guard runs in the same transaction: it probes
// that the table exists, then reads the blueprint's OTHER tables. Neither is
// what this file is about, so both answer "nothing in the way" by default and a
// test that cares scripts its own.
const TABLE_EXISTS_PROBE = /SELECT 1 FROM information_schema\.TABLES/i;
const OUTPUT_CLAIM_SCAN = /^SELECT name, doc FROM `fmb_decision_tables`/i;
// The guard's post-state lookup. It reads `doc` as well as `blueprint_id`,
// because a PUT that repoints blueprint_id carries the STORED document into a
// new set of siblings and the body says nothing about it. Matched loosely on
// the column list for that reason: this file is not about the guard, and a
// pattern pinned to one column list turns a widened SELECT into an "Unmatched
// query" throw — a 500 out of every unrelated update test, which is exactly
// what it did.
const CLAIM_BLUEPRINT_LOOKUP = /^SELECT blueprint_id(?:, \w+)* FROM `fmb_decision_tables`/i;
const OWNER_CHAIN = /^SELECT j0\.`owner_id` AS owner_id/i;
const LINK_PROBE = /SELECT linked_blueprint_id FROM/i;
const STORED_FK = /AS bid FROM `fmb_decision_tables`/i;
// The blueprint-scoped name-uniqueness guard: one probe for the row's stored
// (scope, name) pair on PUT, one for a sibling already holding the pair.
const NAME_SCOPE_PROBE = /^SELECT `blueprint_id` AS scope/i;
const NAME_DUP_PROBE = /^SELECT id FROM `fmb_decision_tables`/i;

const DECISION_COLUMNS = ['id', 'blueprint_id', 'name', 'doc', 'created_at', 'updated_at'];

let conn;
function makeConn(scripts, { dbName = 'db_default' } = {}) {
  const queries = [];
  const fullScripts = [
    [DATABASE_PROBE, [{ db: dbName }]],
    [COLUMN_PROBE, DECISION_COLUMNS.map((c) => ({ COLUMN_NAME: c }))],
    [TABLE_EXISTS_PROBE, [{ c: 1 }]],
    [OUTPUT_CLAIM_SCAN, []],
    [CLAIM_BLUEPRINT_LOOKUP, [{ blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26' }]],
    // Default: the target blueprint is not linked, the stored-FK lookup finds
    // nothing, and no sibling holds the name. Individual tests override by
    // scripting first.
    [LINK_PROBE, []],
    [STORED_FK, []],
    [NAME_SCOPE_PROBE, [{ scope: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', keyval: 'Part lookup' }]],
    [NAME_DUP_PROBE, []],
    ...scripts,
  ];
  return {
    queries,
    async query(sql, params) {
      queries.push({ sql, params });
      // Scripted matchers win over the defaults above, so a test can shadow a
      // default by listing its own matcher for the same shape.
      for (const [matcher, response] of [...scripts, ...fullScripts]) {
        if (matcher.test(sql)) {
          return typeof response === 'function' ? response(sql, params) : response;
        }
      }
      // The factory asks which spelling the parent row really carries before it
      // binds one. Answered rather than thrown on — see tests/helpers.
      const parentId = answerParentIdProbe(sql, params);
      if (parentId) return parentId;
      // "Does this column name the caller" is asked of the engine now, so the
      // double sees the three probe statements — answered the way the column's
      // collation answers them, never waved through.
      const probed = answerCollationProbe(sql, params);
      if (probed) return probed;
      throw new Error(`Unmatched query: ${sql.slice(0, 160)}`);
    },
    release() { /* noop */ },
    async beginTransaction() {},
    async commit() {},
    async rollback() {},
  };
}

const poolSpy = {
  rw: { async getConnection() { return conn; } },
  ro: { async getConnection() { return conn; } },
};

require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: {
    pool: poolSpy,
    t: (name) => `fmb_${name}`,
    getDynamicPool: async () => poolSpy,
  },
};

const router = require('../../../../src/edge/routes/app/schema');
const { __clearColumnSetCache } = router.__test__;

let server;
let port;
// Mutable so a single server can answer as admin, editor, or anonymous.
let currentUser = { id: '5b729f1e-5c0b-447c-8144-3210469bc62c', role: 'admin' };

before(async () => {
  const app = express();
  app.use(express.json({ limit: '10mb' }));
  app.use((req, _res, next) => {
    if (currentUser) req.user = currentUser;
    next();
  });
  app.use('/edge/app/schema', router);
  await new Promise((resolve) => {
    server = app.listen(0, '127.0.0.1', () => {
      port = server.address().port;
      resolve();
    });
  });
});

after(async () => {
  await new Promise((resolve) => server.close(resolve));
  delete require.cache[dbKey];
});

beforeEach(() => {
  conn = null;
  currentUser = { id: '5b729f1e-5c0b-447c-8144-3210469bc62c', role: 'admin' };
  __clearColumnSetCache();
});

function request(method, path, body) {
  return new Promise((resolve, reject) => {
    const data = body !== undefined ? JSON.stringify(body) : '';
    const headers = data
      ? { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(data) }
      : {};
    const req = http.request({ method, host: '127.0.0.1', port, path, headers }, (res) => {
      let raw = '';
      res.on('data', (c) => { raw += c; });
      res.on('end', () => {
        let parsed = null;
        try { parsed = raw ? JSON.parse(raw) : null; } catch { parsed = raw; }
        resolve({ status: res.statusCode, body: parsed });
      });
    });
    req.on('error', reject);
    if (data) req.write(data);
    req.end();
  });
}

const get = (p) => request('GET', p);
const post = (p, b) => request('POST', p, b);
const put = (p, b) => request('PUT', p, b);
const del = (p) => request('DELETE', p);

const BASE = '/edge/app/schema/decision_tables';

const SAMPLE_DOC = {
  conditions: [{ field_key: 'material' }, { field_key: 'size' }],
  outputs: [{ field_key: 'part_no' }],
  rows: [{ when: { material: 'steel', size: 'M' }, then: { part_no: 'P-1' } }],
};

function storedRow(overrides = {}) {
  return {
    id: '99325195-6d2a-42af-8c5b-331b20b19eec',
    blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26',
    name: 'Part lookup',
    doc: JSON.stringify(SAMPLE_DOC),
    created_at: '2026-07-26 10:00:00',
    updated_at: '2026-07-26 10:00:00',
    ...overrides,
  };
}

describe('decision_tables — create', () => {
  it('persists the document as JSON text and returns it parsed', async () => {
    let insertSql = null;
    let insertParams = null;
    conn = makeConn([
      [/^INSERT INTO `fmb_decision_tables`/i, (sql, params) => {
        insertSql = sql; insertParams = params; return { affectedRows: 1 };
      }],
      [/^SELECT \* FROM `fmb_decision_tables`/i, [storedRow()]],
    ]);
    const res = await post(BASE, { blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', name: 'Part lookup', doc: SAMPLE_DOC });
    assert.equal(res.status, 200);

    // The write actually carried the document: the INSERT names `doc` and the
    // bound value is the serialised document, not "[object Object]".
    assert.match(insertSql, /`doc`/);
    const docParam = insertParams[insertSql.match(/\(([^)]*)\) VALUES/)[1].split(', ').indexOf('`doc`')];
    assert.equal(typeof docParam, 'string');
    assert.deepEqual(JSON.parse(docParam), SAMPLE_DOC);

    // ...and the read path hands the caller a parsed object with ISO timestamps.
    assert.deepEqual(res.body.data.doc, SAMPLE_DOC);
    assert.equal(res.body.data.created_at, '2026-07-26T10:00:00Z');
  });

  it('starts a table with no document as a well-formed empty one', async () => {
    let insertSql = null;
    let insertParams = null;
    conn = makeConn([
      [/^INSERT INTO `fmb_decision_tables`/i, (sql, params) => {
        insertSql = sql; insertParams = params; return { affectedRows: 1 };
      }],
      [/^SELECT \* FROM `fmb_decision_tables`/i, [storedRow({ doc: null })]],
    ]);
    const res = await post(BASE, { blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', name: 'Empty' });
    assert.equal(res.status, 200);
    const docParam = insertParams[insertSql.match(/\(([^)]*)\) VALUES/)[1].split(', ').indexOf('`doc`')];
    assert.deepEqual(JSON.parse(docParam), { conditions: [], outputs: [], rows: [] });
  });

  it('rejects a missing name (the DDL column is NOT NULL)', async () => {
    conn = makeConn([]);
    const res = await post(BASE, { blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', doc: SAMPLE_DOC });
    assert.equal(res.status, 400);
    assert.equal(res.body.error.code, 'EMPTY_NOT_ALLOWED');
  });
});

describe('decision_tables — name uniqueness within a blueprint', () => {
  // The name is the only handle a human has on a table. The authoring UI
  // refuses a duplicate, but a second tab, a retry after a timeout, or any
  // non-UI client would otherwise create one.
  it('refuses a create whose name a sibling in the same blueprint already holds', async () => {
    conn = makeConn([
      [NAME_DUP_PROBE, [{ id: '74aa4849-3bf6-46c9-85fa-681309029e13' }]],
    ]);
    const res = await post(BASE, { blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', name: 'Part lookup', doc: SAMPLE_DOC });
    assert.equal(res.status, 409);
    assert.equal(res.body.error.code, 'DUPLICATE_DECISION_TABLE_NAME');
    const inserts = conn.queries.filter((q) => /^INSERT/i.test(q.sql));
    assert.deepEqual(inserts, []);
  });

  it('refuses a rename onto a name a sibling already holds', async () => {
    conn = makeConn([
      [NAME_DUP_PROBE, [{ id: 'e737d265-a5c6-407f-866e-bbe109b5fa4e' }]],
    ]);
    const res = await put(`${BASE}/99325195-6d2a-42af-8c5b-331b20b19eec`, { name: 'Part lookup' });
    assert.equal(res.status, 409);
    assert.equal(res.body.error.code, 'DUPLICATE_DECISION_TABLE_NAME');
    const updates = conn.queries.filter((q) => /^UPDATE/i.test(q.sql));
    assert.deepEqual(updates, []);
  });

  it('maps errno 1062 from the UNIQUE index to the same 409 the pre-check returns (race backstop)', async () => {
    // The pre-check probe finds nothing (no sibling holds the name yet), but the
    // INSERT itself hits the concurrent create — the other request's row landed
    // between the probe and this one's write. Without the UNIQUE index this would
    // 500; with it, the driver reports 1062 and the route must translate that to
    // the same status/code a synchronous duplicate gets, not a raw 500.
    conn = makeConn([
      [NAME_DUP_PROBE, []],
      [/^INSERT INTO `fmb_decision_tables`/i, () => { const e = new Error('dup'); e.errno = 1062; throw e; }],
    ]);
    const res = await post(BASE, { blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', name: 'Part lookup', doc: SAMPLE_DOC });
    assert.equal(res.status, 409);
    assert.equal(res.body.error.code, 'DUPLICATE_DECISION_TABLE_NAME');
  });

  it('maps errno 1062 on a racing rename to the same 409 the pre-check returns', async () => {
    conn = makeConn([
      [NAME_DUP_PROBE, []],
      [/^UPDATE `fmb_decision_tables`/i, () => { const e = new Error('dup'); e.errno = 1062; throw e; }],
    ]);
    const res = await put(`${BASE}/99325195-6d2a-42af-8c5b-331b20b19eec`, { name: 'Part lookup' });
    assert.equal(res.status, 409);
    assert.equal(res.body.error.code, 'DUPLICATE_DECISION_TABLE_NAME');
  });

  it('scopes the check to the blueprint — the same name under another one is fine', async () => {
    let dupParams = null;
    conn = makeConn([
      [NAME_DUP_PROBE, (_sql, params) => { dupParams = params; return []; }],
      [/^INSERT INTO `fmb_decision_tables`/i, { affectedRows: 1 }],
      [/^SELECT \* FROM `fmb_decision_tables`/i, [storedRow()]],
    ]);
    const res = await post(BASE, { blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', name: 'Part lookup', doc: SAMPLE_DOC });
    assert.equal(res.status, 200);
    assert.deepEqual(dupParams.slice(0, 2), ['a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', 'Part lookup']);
  });

  it('leaves a document-only update alone — it carries no name to collide', async () => {
    conn = makeConn([
      // Scripted to FAIL the test if it is ever consulted: a doc-only PUT does
      // not send the name, so the route must not run the uniqueness probe, and
      // an author whose table arrived already duplicated must still be able to
      // save a rule change.
      [NAME_DUP_PROBE, [{ id: 'e737d265-a5c6-407f-866e-bbe109b5fa4e' }]],
      [/^UPDATE `fmb_decision_tables`/i, { affectedRows: 1 }],
      [/^SELECT \* FROM `fmb_decision_tables`/i, [storedRow()]],
    ]);
    const res = await put(`${BASE}/99325195-6d2a-42af-8c5b-331b20b19eec`, { doc: SAMPLE_DOC });
    assert.equal(res.status, 200);
    assert.deepEqual(conn.queries.filter((q) => NAME_DUP_PROBE.test(q.sql)), []);
  });
});

describe('decision_tables — document guards', () => {
  it('rejects a malformed document with 400 and never opens a connection', async () => {
    conn = makeConn([]);
    const res = await post(BASE, {
      blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26',
      name: 'Bad',
      doc: { conditions: [{ field_key: 'a' }], outputs: [], rows: [{ when: { zzz: 1 }, then: {} }] },
    });
    assert.equal(res.status, 400);
    assert.equal(res.body.error.code, 'INVALID_DECISION_DOC');
    // The guard runs before any DB work — a rejected write must cost nothing.
    assert.deepEqual(conn.queries, []);
  });

  it('rejects a pre-serialised (string) document instead of storing it verbatim', async () => {
    conn = makeConn([]);
    const res = await post(BASE, {
      blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', name: 'Stringified', doc: JSON.stringify(SAMPLE_DOC),
    });
    assert.equal(res.status, 400);
    assert.equal(res.body.error.code, 'INVALID_DECISION_DOC');
    // The MESSAGE pins WHICH guard refused it. Without this the test passes even
    // with the is-it-an-object guard deleted — a string trips the unknown-key
    // check three lines later, because Object.keys('…') yields index keys. That
    // would be the same code for an unrelated reason, and the guard this test is
    // named for could be removed unnoticed.
    assert.match(res.body.error.message, /doc must be an object/);
  });

  it('rejects an array document, which is not the shape the evaluator reads', async () => {
    conn = makeConn([]);
    const res = await post(BASE, { blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', name: 'Arrayed', doc: [] });
    assert.equal(res.status, 400);
    assert.equal(res.body.error.code, 'INVALID_DECISION_DOC');
    assert.match(res.body.error.message, /doc must be an object/);
    assert.deepEqual(conn.queries, []);
  });

  it('rejects a document over the 1 MB cap with 413', async () => {
    conn = makeConn([]);
    const doc = {
      conditions: [{ field_key: 'a' }],
      outputs: [],
      rows: [{ when: { a: 'x'.repeat(1024 * 1024 + 1) }, then: {} }],
    };
    const res = await post(BASE, { blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', name: 'Huge', doc });
    assert.equal(res.status, 413);
    assert.equal(res.body.error.code, 'DECISION_DOC_TOO_LARGE');
    assert.deepEqual(conn.queries, []);
  });

  it('applies the same guards on update', async () => {
    conn = makeConn([]);
    const res = await put(`${BASE}/99325195-6d2a-42af-8c5b-331b20b19eec`, { doc: { conditions: 'nope', outputs: [], rows: [] } });
    assert.equal(res.status, 400);
    assert.equal(res.body.error.code, 'INVALID_DECISION_DOC');
  });
});

describe('decision_tables — read', () => {
  it('filters the list by blueprint_id and parses each document', async () => {
    let listSql = null;
    let listParams = null;
    conn = makeConn([
      [/^SELECT \* FROM `fmb_decision_tables`/i, (sql, params) => {
        listSql = sql; listParams = params; return [storedRow()];
      }],
    ]);
    const res = await get(`${BASE}?blueprint_id=a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26`);
    assert.equal(res.status, 200);
    assert.match(listSql, /WHERE `blueprint_id` = \?/);
    assert.deepEqual(listParams, ['a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26']);
    assert.deepEqual(res.body.data[0].doc, SAMPLE_DOC);
  });

  it('ignores an undeclared filter column', async () => {
    let listSql = null;
    conn = makeConn([
      [/^SELECT \* FROM `fmb_decision_tables`/i, (sql) => { listSql = sql; return []; }],
    ]);
    const res = await get(`${BASE}?name=Part%20lookup`);
    assert.equal(res.status, 200);
    assert.doesNotMatch(listSql, /WHERE/);
  });

  it('coalesces a NULL stored document to an empty one (never null at the boundary)', async () => {
    conn = makeConn([
      [/^SELECT \* FROM `fmb_decision_tables`/i, [storedRow({ doc: null })]],
    ]);
    const res = await get(`${BASE}/99325195-6d2a-42af-8c5b-331b20b19eec`);
    assert.equal(res.status, 200);
    assert.deepEqual(res.body.data.doc, { conditions: [], outputs: [], rows: [] });
  });

  it('degrades to an empty list when the additive table is absent', async () => {
    conn = makeConn([
      [/^SELECT \* FROM `fmb_decision_tables`/i, () => {
        throw Object.assign(new Error("Table 'fmb_decision_tables' doesn't exist"), { errno: 1146 });
      }],
    ]);
    const res = await get(BASE);
    assert.equal(res.status, 200);
    assert.deepEqual(res.body.data, []);
  });
});

describe('decision_tables — update + delete', () => {
  it('binds the serialised document on update', async () => {
    let updateSql = null;
    let updateParams = null;
    conn = makeConn([
      [/^UPDATE `fmb_decision_tables`/i, (sql, params) => {
        updateSql = sql; updateParams = params; return { affectedRows: 1 };
      }],
      [/^SELECT \* FROM `fmb_decision_tables`/i, [storedRow()]],
    ]);
    const res = await put(`${BASE}/99325195-6d2a-42af-8c5b-331b20b19eec`, { name: 'Renamed', doc: SAMPLE_DOC });
    assert.equal(res.status, 200);
    assert.match(updateSql, /`doc` = \?/);
    assert.ok(
      updateParams.some((p) => typeof p === 'string' && p.includes('"field_key":"material"')),
      'the UPDATE must bind the serialised document',
    );
  });

  it('leaves the stored document untouched when the update omits it', async () => {
    let updateSql = null;
    conn = makeConn([
      [/^UPDATE `fmb_decision_tables`/i, (sql) => { updateSql = sql; return { affectedRows: 1 }; }],
      [/^SELECT \* FROM `fmb_decision_tables`/i, [storedRow()]],
    ]);
    const res = await put(`${BASE}/99325195-6d2a-42af-8c5b-331b20b19eec`, { name: 'Renamed only' });
    assert.equal(res.status, 200);
    assert.doesNotMatch(updateSql, /`doc`/);
  });

  it('deletes by id', async () => {
    let deleteParams = null;
    conn = makeConn([
      [/^DELETE FROM `fmb_decision_tables`/i, (_sql, params) => {
        deleteParams = params; return { affectedRows: 1 };
      }],
    ]);
    const res = await del(`${BASE}/99325195-6d2a-42af-8c5b-331b20b19eec`);
    assert.equal(res.status, 200);
    assert.deepEqual(deleteParams, ['99325195-6d2a-42af-8c5b-331b20b19eec']);
  });
});

describe('decision_tables — access control', () => {
  it('rejects an unauthenticated write', async () => {
    currentUser = null;
    conn = makeConn([]);
    const res = await post(BASE, { blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', name: 'Anon', doc: SAMPLE_DOC });
    assert.ok(res.status === 401 || res.status === 403, `expected 401/403, got ${res.status}`);
    assert.deepEqual(conn.queries, []);
  });

  it('rejects an unauthenticated read', async () => {
    currentUser = null;
    conn = makeConn([]);
    const res = await get(BASE);
    assert.ok(res.status === 401 || res.status === 403, `expected 401/403, got ${res.status}`);
  });

  it("lets an editor author under a blueprint they own", async () => {
    currentUser = { id: '405279b5-48c7-4bd5-8427-69d6ff5556a7', role: 'editor' };
    conn = makeConn([
      [OWNER_CHAIN, [{ owner_id: '405279b5-48c7-4bd5-8427-69d6ff5556a7' }]],
      [/^INSERT INTO `fmb_decision_tables`/i, { affectedRows: 1 }],
      [/^SELECT \* FROM `fmb_decision_tables`/i, [storedRow()]],
    ]);
    const res = await post(BASE, { blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', name: 'Mine', doc: SAMPLE_DOC });
    assert.equal(res.status, 200);
  });

  it("refuses an editor authoring under another editor's blueprint", async () => {
    currentUser = { id: '405279b5-48c7-4bd5-8427-69d6ff5556a7', role: 'editor' };
    conn = makeConn([
      [OWNER_CHAIN, [{ owner_id: '2af146d0-081f-4869-8a8f-3bf248676df8' }]],
    ]);
    const res = await post(BASE, { blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', name: 'Theirs', doc: SAMPLE_DOC });
    assert.equal(res.status, 403);
    const inserts = conn.queries.filter((q) => /^INSERT/i.test(q.sql));
    assert.deepEqual(inserts, []);
  });

  it('refuses every write from a plain user, who may read but never author', async () => {
    currentUser = { id: 'adeb723a-494c-4e33-8cdf-2374d0c68779', role: 'user' };
    for (const attempt of [
      () => post(BASE, { blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', name: 'Theirs', doc: SAMPLE_DOC }),
      () => put(`${BASE}/99325195-6d2a-42af-8c5b-331b20b19eec`, { name: 'Renamed' }),
      () => del(`${BASE}/99325195-6d2a-42af-8c5b-331b20b19eec`),
    ]) {
      conn = makeConn([]);
      const res = await attempt();
      assert.equal(res.status, 403);
      const writes = conn.queries.filter((q) => /^(INSERT|UPDATE|DELETE)/i.test(q.sql));
      assert.deepEqual(writes, []);
    }
  });

  it('refuses a write under a linked (borrowed-schema) blueprint', async () => {
    conn = makeConn([
      [LINK_PROBE, [{ linked_blueprint_id: 'e9dc633a-d9e5-44b6-8baa-1fa26eb88ab8' }]],
    ]);
    const res = await post(BASE, { blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', name: 'Linked', doc: SAMPLE_DOC });
    assert.equal(res.status, 409);
    assert.equal(res.body.error.code, 'LINKED_BLUEPRINT_READONLY');
    const inserts = conn.queries.filter((q) => /^INSERT/i.test(q.sql));
    assert.deepEqual(inserts, []);
  });
});
