/**
 * blueprint-copy-subset-schema-parity.test.js — validates every column the
 * copy-subset write path names LITERALLY (the FOR UPDATE lock, the source/
 * target lookups, and the collision/rename SELECTs) against the ACTUAL
 * table DDL, without a live DB — per repo rule, new SQL ships with a
 * schema-parity test (docker-api/tests/edge/routes/app/
 * capacity-delete-preview-schema-parity.test.js is the template). The
 * per-row INSERTs go through `buildPortableInsert` (schema-driven from
 * information_schema, not a literal column list), so this file only checks
 * the columns spelled out by hand.
 */
const { describe, it, before } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const dbKey = require.resolve('../../../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: {}, t: (n) => n, getDynamicPool: async () => ({}) },
};

const { buildEngineTableDDLs } = require('../../../../src/table-ddls');

let columnsByTable;
before(() => {
  columnsByTable = new Map();
  const SQL_TYPES = /^`?([a-z_]+)`?\s+(?:CHAR|VARCHAR|INT|DOUBLE|TIMESTAMP|JSON|TEXT|ENUM|BOOLEAN|TINYINT|BIGINT|DATETIME|DECIMAL|FLOAT|BLOB)\b/i;
  for (const ddl of buildEngineTableDDLs((n) => n)) {
    const m = ddl.match(/CREATE TABLE IF NOT EXISTS `([^`]+)`/);
    if (!m) continue;
    const cols = new Set();
    for (const rawLine of ddl.split('\n')) {
      const line = rawLine.trim();
      if (!line || line.startsWith('--') || line.startsWith('/*')) continue;
      const cm = line.match(SQL_TYPES);
      if (cm) cols.add(cm[1]);
    }
    columnsByTable.set(m[1], cols);
  }
});

const LIB_SRC = fs.readFileSync(
  path.resolve(__dirname, '../../../../src/edge/lib/blueprint-copy-subset.js'), 'utf8',
);
const ROUTE_SRC = fs.readFileSync(
  path.resolve(__dirname, '../../../../src/edge/routes/app/schema/routes-blueprint-copy.js'), 'utf8',
);

describe('blueprint-copy-subset literal SQL — schema parity', () => {
  it('parses columns for every table the write path touches', () => {
    for (const table of ['blueprint_fields', 'blueprint_sections', 'field_options', 'hierarchy_nodes']) {
      assert.ok(columnsByTable.get(table)?.size > 0, `no columns parsed for ${table}`);
    }
  });

  it('the FOR UPDATE lock names real hierarchy_nodes columns', () => {
    assert.match(ROUTE_SRC, /SELECT id, owner_id FROM/);
    const cols = columnsByTable.get('hierarchy_nodes');
    assert.ok(cols.has('id') && cols.has('owner_id') && cols.has('node_type'));
  });

  it('the source-field SELECT names real blueprint_fields columns (blueprint_id, id)', () => {
    assert.match(LIB_SRC, /SELECT \* FROM \\`\$\{t\(TABLES\.BLUEPRINT_FIELDS\)\}\\`\s*\n\s*WHERE blueprint_id = \? AND id IN/);
    const cols = columnsByTable.get('blueprint_fields');
    assert.ok(cols.has('blueprint_id') && cols.has('id'));
  });

  it('the target field_key SELECT names a real column', () => {
    assert.match(LIB_SRC, /SELECT field_key FROM \\`\$\{t\(TABLES\.BLUEPRINT_FIELDS\)\}\\` WHERE blueprint_id = \?/);
    assert.ok(columnsByTable.get('blueprint_fields').has('field_key'));
  });

  it('the source-section SELECT names real blueprint_sections columns', () => {
    assert.match(LIB_SRC, /SELECT \* FROM \\`\$\{t\(TABLES\.BLUEPRINT_SECTIONS\)\}\\`\s*\n\s*WHERE blueprint_id = \? AND section_key IN/);
    const cols = columnsByTable.get('blueprint_sections');
    assert.ok(cols.has('blueprint_id') && cols.has('section_key'));
  });

  it('the target section_key SELECT names a real column', () => {
    assert.match(LIB_SRC, /SELECT section_key FROM \\`\$\{t\(TABLES\.BLUEPRINT_SECTIONS\)\}\\` WHERE blueprint_id = \?/);
    assert.ok(columnsByTable.get('blueprint_sections').has('section_key'));
  });

  it('the source-options SELECT names a real field_options column', () => {
    assert.match(LIB_SRC, /SELECT \* FROM \\`\$\{t\(TABLES\.FIELD_OPTIONS\)\}\\` WHERE field_id IN/);
    assert.ok(columnsByTable.get('field_options').has('field_id'));
  });

  it('the source-blueprint existence check names a real hierarchy_nodes column', () => {
    assert.match(ROUTE_SRC, /SELECT id FROM \\`\$\{t\(TABLES\.HIERARCHY_NODES\)\}\\` WHERE id = \? AND node_type = 'blueprint'/);
  });
});
