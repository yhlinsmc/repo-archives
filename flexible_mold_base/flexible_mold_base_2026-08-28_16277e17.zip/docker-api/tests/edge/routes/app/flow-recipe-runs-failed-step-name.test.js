// docker-api/tests/edge/routes/app/flow-recipe-runs-failed-step-name.test.js
//
// PR-2 Task 5: the runs LIST derives `failed_step_name` server-side —
// the first failed step's recorded name, else null — and never ships the full
// step_results document to get there.
const { test } = require('node:test');
const assert = require('node:assert');
const express = require('express');

const { deriveFailedStepName } = require('../../../../src/edge/routes/app/flow-recipe-runs/failed-step-name');

// ── pure helper ────────────────────────────────────────────────────────────

test('deriveFailedStepName: first ok:false entry\'s step_name for a failed run with named entries', () => {
  const raw = JSON.stringify([
    { step_id: 's1', step_name: 'Fetch data', ok: true, upstream_status: 200 },
    { step_id: 's2', step_name: 'Push to target', ok: false, upstream_status: 502, error_body: 'boom' },
  ]);
  assert.strictEqual(deriveFailedStepName(raw), 'Push to target');
});

test('deriveFailedStepName: null for a legacy blob entry with no step_name', () => {
  const raw = JSON.stringify([{ step_id: 'x', ok: false, upstream_status: 502 }]);
  assert.strictEqual(deriveFailedStepName(raw), null);
});

test('deriveFailedStepName: null for a succeeded run', () => {
  const raw = JSON.stringify([{ step_id: 's1', step_name: 'Fetch', ok: true, upstream_status: 200 }]);
  assert.strictEqual(deriveFailedStepName(raw), null);
});

test('deriveFailedStepName: null for unparseable step_results, never throws', () => {
  assert.strictEqual(deriveFailedStepName('not json at all'), null);
  assert.strictEqual(deriveFailedStepName('{"not":"an array"}'), null);
  assert.strictEqual(deriveFailedStepName(''), null);
  assert.strictEqual(deriveFailedStepName(null), null);
  assert.strictEqual(deriveFailedStepName(undefined), null);
  assert.strictEqual(deriveFailedStepName('[]'), null);
});

test('deriveFailedStepName: an empty-string step_name on the failed entry answers null, not ""', () => {
  const raw = JSON.stringify([{ step_id: 's1', step_name: '', ok: false, upstream_status: 502 }]);
  assert.strictEqual(deriveFailedStepName(raw), null);
});

// ── the runs LIST route ──────────────────────────────────────────────────────

let issued = [];
let responder = () => [];

require.cache[require.resolve('../../../../src/edge/db')] = {
  exports: {
    pool: {
      ro: {
        getConnection: async () => ({
          query: async (sql, params) => {
            issued.push({ sql, params });
            const out = responder(sql, params);
            if (out instanceof Error) throw out;
            return out;
          },
          release: () => {},
        }),
      },
      rw: { getConnection: async () => ({ query: async () => [], release: () => {} }) },
    },
    t: (x) => x,
  },
};

const { router } = require('../../../../src/edge/routes/app/flow-recipe-runs/aggregate');
const { TEMPLATE_GROUP_PREFIX } = require('../../../../src/edge/routes/app/flow-recipe-runs/group-id');

function app(user) {
  const a = express();
  a.use(express.json());
  a.use((req, _res, next) => { if (user) req.user = user; next(); });
  a.use('/', router);
  return a;
}

async function get(a, path) {
  const server = a.listen(0);
  try {
    const { port } = server.address();
    const res = await fetch(`http://127.0.0.1:${port}${path}`);
    const json = await res.json().catch(() => ({}));
    return { status: res.status, json };
  } finally {
    server.close();
  }
}

const ADMIN = { id: 'aaaaaaaa-0000-0000-0000-000000000001', role: 'admin' };
const TEMPLATE = '11111111-1111-1111-1111-111111111111';
const ACTOR = 'bbbbbbbb-0000-0000-0000-000000000002';
const segment = (templateId) => `${TEMPLATE_GROUP_PREFIX}${encodeURIComponent(templateId)}`;
const GROUP = segment(TEMPLATE);

function runRow(over) {
  return {
    id: 'cccccccc-0000-0000-0000-000000000003',
    created_at: '2026-07-20 09:30:00',
    started_at: '2026-07-20 09:30:00',
    finished_at: '2026-07-20 09:30:02',
    status: 'failed',
    actor_id: ACTOR,
    result_link: null,
    external_flow_id: null,
    error_summary: 'Upstream returned 502',
    blueprint_id: null,
    input_snapshot: null,
    step_results_raw: JSON.stringify([{ step_id: 's1', step_name: 'Push to target', ok: false, upstream_status: 502 }]),
    ...over,
  };
}

function stub({ runs = [], total = 0, templates = [], users = [] } = {}) {
  return (sql) => {
    if (sql.includes('input_snapshot')) return runs;
    if (sql.includes('COUNT(*) AS cnt')) return [{ cnt: total }];
    if (sql.includes('user_templates')) return templates;
    if (sql.includes('kc_username')) return users;
    if (sql.includes('FROM `flow_recipe_runs`')) {
      return runs.map(({ input_snapshot: _drop, ...rest }) => rest);
    }
    return [];
  };
}

test.beforeEach(() => { issued = []; responder = stub(); });

test('the runs list SELECT reads step_results only as CAST(... AS CHAR)', async () => {
  responder = stub({ runs: [runRow()], total: 1 });
  await get(app(ADMIN), `/groups/${GROUP}/runs`);
  assert.match(issued[0].sql, /CAST\(r\.`step_results` AS CHAR\)/,
    'a raw JSON-typed select would round large integers before failed_step_name is derived');
});

test('a failed run with named entries carries failed_step_name in the list response', async () => {
  responder = stub({ runs: [runRow()], total: 1 });
  const { json } = await get(app(ADMIN), `/groups/${GROUP}/runs`);
  assert.strictEqual(json.data.rows[0].failed_step_name, 'Push to target');
});

test('a failed run with a legacy blob (no step_name) carries failed_step_name: null', async () => {
  responder = stub({
    runs: [runRow({ step_results_raw: JSON.stringify([{ step_id: 'x', ok: false, upstream_status: 502 }]) })],
    total: 1,
  });
  const { json } = await get(app(ADMIN), `/groups/${GROUP}/runs`);
  assert.strictEqual(json.data.rows[0].failed_step_name, null);
});

test('a succeeded run carries failed_step_name: null', async () => {
  responder = stub({
    runs: [runRow({
      status: 'success',
      step_results_raw: JSON.stringify([{ step_id: 's1', step_name: 'Push', ok: true, upstream_status: 200 }]),
    })],
    total: 1,
  });
  const { json } = await get(app(ADMIN), `/groups/${GROUP}/runs`);
  assert.strictEqual(json.data.rows[0].failed_step_name, null);
});

test('unparseable step_results answers failed_step_name: null rather than 500ing the list', async () => {
  responder = stub({ runs: [runRow({ step_results_raw: 'not json' })], total: 1 });
  const { status, json } = await get(app(ADMIN), `/groups/${GROUP}/runs`);
  assert.strictEqual(status, 200);
  assert.strictEqual(json.data.rows[0].failed_step_name, null);
});

test('the full step_results document never reaches the list response', async () => {
  responder = stub({ runs: [runRow()], total: 1 });
  const { json } = await get(app(ADMIN), `/groups/${GROUP}/runs`);
  assert.ok(!('step_results' in json.data.rows[0]));
  assert.ok(!('step_results_raw' in json.data.rows[0]));
});
