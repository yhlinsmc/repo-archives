/**
 * flow-recipes-run-step-select-schema-parity.test.js — validates the columns
 * the run-begin step SELECT (both the full and legacy-fallback variants)
 * references against the ACTUAL flow_recipe_steps table DDL, WITHOUT a live
 * DB. A wrong/renamed column stays green under every mocked node:test yet
 * 500s (or silently falls to the legacy variant) in production. PR-2
 * Task 4 added `name` to both SELECT variants — this test closes the gap
 * that change is exempt from the schema-migration gate (no DDL, existing
 * column) but is NOT exempt from a typo.
 */
const { describe, it, before } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

// flow-recipes-run.js destructures { pool, t } from ../../db at load time —
// stub it so requiring the source text (via readFileSync below we don't even
// require the module) is unnecessary; this file only parses the SQL text.
const { buildEngineTableDDLs } = require('../../../../src/table-ddls');

let columnsByTable;

before(() => {
  columnsByTable = new Map();
  for (const ddl of buildEngineTableDDLs((n) => n)) {
    const m = ddl.match(/CREATE TABLE IF NOT EXISTS `([^`]+)`/);
    if (!m) continue;
    const table = m[1];
    const cols = new Set();
    for (const rawLine of ddl.split('\n')) {
      const line = rawLine.trim();
      if (!line || line.startsWith('--') || line.startsWith('/*')) continue;
      const cm = line.match(/^`?([a-z_]+)`?\s+(?:CHAR|VARCHAR|INT|DOUBLE|TIMESTAMP|JSON|TEXT|ENUM|BOOLEAN|TINYINT|BIGINT|DATETIME|DECIMAL|FLOAT|BLOB)\b/i);
      if (cm) cols.add(cm[1]);
    }
    columnsByTable.set(table, cols);
  }
});

const SRC = fs.readFileSync(
  path.resolve(__dirname, '../../../../src/edge/routes/internal/flow-recipes-run.js'), 'utf8',
);

/**
 * Pull the two `SELECT <cols> FROM \`${t(TABLES.FLOW_RECIPE_STEPS)}\`` statements
 * that back the run-begin step load (identified by the anchoring comment —
 * flow_recipe_steps is also queried elsewhere in this file for an unrelated
 * code-only reload, which this helper must NOT pick up).
 */
function stepSelectColumnLists() {
  const anchor = SRC.indexOf('Load ordered steps.');
  assert.notEqual(anchor, -1, 'the run-begin step-load comment is gone or reworded');
  const window = SRC.slice(anchor, anchor + 1000);
  const re = /SELECT ([a-z_, ]+) FROM \\`\$\{t\(TABLES\.FLOW_RECIPE_STEPS\)\}\\`/g;
  const lists = [];
  let m;
  while ((m = re.exec(window))) {
    lists.push(m[1].split(',').map((c) => c.trim()).filter(Boolean));
  }
  return lists;
}

describe('flow-recipes-run.js run-begin step SELECT — schema parity', () => {
  it('finds both the full and the legacy-fallback SELECT variants', () => {
    const lists = stepSelectColumnLists();
    assert.equal(lists.length, 2, 'expected exactly 2 flow_recipe_steps SELECT statements (full + legacy fallback)');
  });

  it('every selected column exists on flow_recipe_steps', () => {
    const cols = columnsByTable.get('flow_recipe_steps');
    assert.ok(cols && cols.size > 0, 'no columns parsed for flow_recipe_steps');
    for (const list of stepSelectColumnLists()) {
      for (const col of list) {
        assert.ok(cols.has(col), `flow_recipe_steps has no column '${col}' referenced by the run-begin SELECT`);
      }
    }
  });

  it('the full variant selects name (fmb-1741 step_name enrichment)', () => {
    const lists = stepSelectColumnLists();
    assert.ok(lists.some((list) => list.includes('name')),
      'the full SELECT must include `name` so infra can record step_name in step_results');
  });

  it('the legacy-fallback variant also selects name (older schema still has this column since table creation)', () => {
    const lists = stepSelectColumnLists();
    assert.ok(lists[1] && lists[1].includes('name'),
      'the legacy-fallback SELECT must also include `name` — flow_recipe_steps.name is NOT NULL since table creation, not a later migration');
  });
});
