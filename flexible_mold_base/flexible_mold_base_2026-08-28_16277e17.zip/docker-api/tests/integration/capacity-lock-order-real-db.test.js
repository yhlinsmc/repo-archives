'use strict';

/**
 * capacity-lock-order-real-db.test.js — two writers, two tables, one order.
 *
 * `reference-integrity.js` compareCatalogueTable is the single statement of the
 * FOR-UPDATE lock protocol: per table, by logical name, so `cap_hypervisors`
 * before `cap_vms`. A writer that claims them the other way round can form a
 * circular wait with one that does not, and InnoDB resolves that by killing a
 * transaction — errno 1213.
 *
 * WHY A REAL DATABASE. There is nothing to assert about a deadlock except that
 * the engine raised one. A stubbed driver has no lock manager, so it can neither
 * produce the cycle nor prove it is gone; the premise under test is what InnoDB
 * does with two transactions that disagree about the order.
 *
 * WHY THE ERRNO AND NOT THE STATUS. `crud-factory.js` maps errno 1213 (deadlock)
 * AND errno 1205 (lock wait timeout) to the same 409 WRITE_CONFLICT, and both
 * halves of this file's subject look identical through that mapping: a pair that
 * merely BLOCKS is correct behaviour and a pair that CYCLES is the defect. So
 * each request's connection is wrapped and the driver's own errno is recorded.
 * A status-code assertion here would pass on the defect.
 *
 * THE INTERLEAVING IS FORCED, NOT RACED. A repeat-until-it-happens loop is a
 * flaky test that also cannot prove absence. Instead one external transaction
 * holds the hypervisor row both writers want; the first request is fired and
 * parked on its claim of that row, the second is fired and parked on its own
 * claim — by which point it holds everything it takes BEFORE the hypervisor —
 * and the blocker is then released. Whichever request queued first is GRANTED
 * the host row and then reaches for whatever the other is holding.
 *
 * THE GRANT ORDER IS PART OF THE CONDITION, NOT A DETAIL OF THE HARNESS, and an
 * earlier version of this file missed that. Two writers disagreeing about the
 * order only cycle when the one that takes the host FIRST is the one that wants
 * the VMs SECOND; grant the row to the out-of-order writer instead and it takes
 * everything it needs in one go and commits. So a pair is not "safe" because one
 * arrangement of it came back clean — every pair below is therefore driven in
 * BOTH grant orders, and the ones that cycle in one of them say so in their
 * name and assert the deadlock rather than its absence.
 *
 * Skips with a stated reason when no database is reachable, and fails instead
 * of skipping when REQUIRE_INTEGRATION_DB=1.
 */
const {
  test, describe, before, after, beforeEach,
} = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const net = require('node:net');
const http = require('node:http');
const express = require('express');
const mariadb = require('mariadb');

const TEST_PREFIX = 'clo_';
const tbl = (name) => `${TEST_PREFIX}${name}`;

let pool = null;

// Every statement a request issues, so a barrier can tell when one is PARKED on
// a lock: the entry is pushed before the driver call and marked done after it
// settles, and every driver error is recorded with its errno.
const pending = [];
const driverErrors = [];

// A HOLD POINT INSIDE A REQUEST'S TRANSACTION, for a pair whose interleaving no
// lock can force.
//
// `racePair` below parks a request by making it QUEUE for a row another
// transaction holds, which only works when the request actually claims that row.
// The staleness measured further down is about a NON-locking read: nothing waits
// for anything, so there is no lock to park on and no observable moment at which
// the transaction is open but has not yet read. The gate stops the connection
// just before a named statement instead — the same kind of forcing, still
// deterministic rather than a repeat-until-it-happens loop.
let gate = null;

/** Hold the next statement matching `re` until the returned `release` is called. */
function armGate(re) {
  let onReach;
  let onRelease;
  const reached = new Promise((r) => { onReach = r; });
  const hold = new Promise((r) => { onRelease = r; });
  gate = { re, tripped: false, onReach, hold };
  return {
    reached,
    release: () => { gate = null; onRelease(); },
  };
}

// A ONE-SHOT DRIVER FAULT, for the case no interleaving can force: placement-
// apply's lock-order fix means a genuine InnoDB deadlock/lock-wait no longer
// arises through the handler's own two-writer contention, so proving the
// catch-branch's ERRNO MAPPING (as opposed to the lock order itself, which the
// rest of this file measures) needs the driver to raise one on demand instead.
let injectedFault = null;

function instrument(conn) {
  const original = conn.query.bind(conn);
  conn.query = async (sql, params) => {
    const flat = String(sql).replace(/\s+/g, ' ').trim();
    if (gate && !gate.tripped && gate.re.test(flat)) {
      gate.tripped = true;
      gate.onReach();
      await gate.hold;
    }
    // The PARAMETERS ride along with the statement, so a case can re-run what
    // the handler issued (an EXPLAIN of it, below) instead of writing a copy of
    // the statement into the test — a copy stops describing the handler the
    // moment the handler changes, and nothing goes red when it does.
    const entry = { sql: flat, params, done: false };
    pending.push(entry);
    try {
      if (injectedFault && !injectedFault.tripped && injectedFault.re.test(flat)) {
        injectedFault.tripped = true;
        const err = new Error('injected fault (test)');
        err.errno = injectedFault.errno;
        throw err;
      }
      return await original(sql, params);
    } catch (err) {
      driverErrors.push({ errno: err.errno, code: err.code, sql: entry.sql.slice(0, 120) });
      throw err;
    } finally {
      entry.done = true;
    }
  };
  return conn;
}

const lease = async () => instrument(await pool.getConnection());
// The capacity guards use BOTH halves of the real pool object — `pool.rw.query`
// for the pre-middleware probes and `pool.rw.getConnection` for the write
// transactions — so the stand-in has to offer both or a guard becomes a 500
// that looks like a refusal.
const handle = () => ({ getConnection: lease, query: (sql, params) => pool.query(sql, params) });

const dbKey = require.resolve('../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey,
  filename: dbKey,
  loaded: true,
  exports: {
    pool: { ro: handle(), rw: handle() },
    t: tbl,
    getDynamicPool: async () => ({ ro: handle(), rw: handle() }),
  },
};

const { buildEngineTableDDLs, buildInfraTableDDLs } = require('../../src/table-ddls');
const capacityRouter = require('../../src/edge/routes/app/capacity');
const { writeConflictError } = require('../../src/edge/routes/app/schema/crud-factory');

// ── Config auto-detection (same shape as the sibling integration tests) ──────

function parseEnvFile(filePath) {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    const out = {};
    for (const line of content.split('\n')) {
      const m = line.match(/^\s*([A-Z_][A-Z0-9_]*)\s*=\s*(.*)\s*$/);
      if (!m) continue;
      let value = m[2];
      if ((value.startsWith('"') && value.endsWith('"'))
        || (value.startsWith("'") && value.endsWith("'"))) {
        value = value.slice(1, -1);
      }
      out[m[1]] = value;
    }
    return out;
  } catch {
    return null;
  }
}

function probePort(host, port, timeoutMs = 2000) {
  return new Promise((resolve) => {
    const socket = new net.Socket();
    let done = false;
    const finish = (ok) => {
      if (done) return;
      done = true;
      socket.destroy();
      resolve(ok);
    };
    socket.setTimeout(timeoutMs);
    socket.once('connect', () => finish(true));
    socket.once('timeout', () => finish(false));
    socket.once('error', () => finish(false));
    socket.connect(port, host);
  });
}

async function resolveMariaDbConfig() {
  if (process.env.DB_TEST_HOST && process.env.DB_TEST_ROOT_PASSWORD) {
    return {
      host: process.env.DB_TEST_HOST,
      port: parseInt(process.env.DB_TEST_PORT || '3306', 10),
      user: 'root',
      password: process.env.DB_TEST_ROOT_PASSWORD,
    };
  }
  const envPath = path.resolve(__dirname, '../../../.devcontainer/.env');
  const env = parseEnvFile(envPath);
  if (!env || !env.DB_ROOT_PASSWORD) return null;
  const port = parseInt(env.DB_PORT || '3306', 10);
  for (const host of ['127.0.0.1', 'mariadb', 'localhost']) {
    if (await probePort(host, port, 2000)) {
      return { host, port, user: 'root', password: env.DB_ROOT_PASSWORD };
    }
  }
  return null;
}

// ── Fixture ─────────────────────────────────────────────────────────────────

const ADMIN_ID = 'cdefab03-4567-89ab-cdef-ab0123456789';
const ADMIN = { id: ADMIN_ID, role: 'admin' };
// The other role this mount admits (`allowedRoles: ['admin', 'editor']`). Its
// PUT takes reads an administrator's does not, and those reads are the subject
// of one case below — so the identity is chosen per REQUEST from a header
// rather than from a module variable, which two concurrent requests would
// race over.
const EDITOR_ID = 'bbccdd04-5678-49ab-8def-ab0123456780';
const EDITOR = { id: EDITOR_ID, role: 'editor' };
const SCENARIO_ID = 'abcabc11-2222-4333-8444-555566667777';

let dbReady = false;
let skipReason = null;
let testDbName = null;
let server = null;
let baseUrl = null;

before(async () => {
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) {
    skipReason = 'no MariaDB reachable via .devcontainer/.env or env vars';
    if (process.env.REQUIRE_INTEGRATION_DB === '1') {
      throw new Error(`REQUIRE_INTEGRATION_DB=1 set but ${skipReason}.`);
    }
    return;
  }
  testDbName = `cap_lock_order_test_${process.pid}_${Date.now()}`;
  let admin = null;
  try {
    admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`CREATE DATABASE \`${testDbName}\``);
    await admin.query(`USE \`${testDbName}\``);
    for (const sql of [...buildInfraTableDDLs(tbl), ...buildEngineTableDDLs(tbl)]) {
      await admin.query(sql);
    }
    await admin.end();
    admin = null;

    pool = mariadb.createPool({
      ...dbConfig,
      database: testDbName,
      connectionLimit: 12,
      connectTimeout: 5000,
      // A pair that blocks without cycling must RESOLVE rather than sit out the
      // server default (50s). It is not a correctness knob: the assertions read
      // the errno, and 1205 is not 1213.
      initSql: 'SET SESSION innodb_lock_wait_timeout = 20',
    });

    const app = express();
    app.use(express.json());
    app.use((req, _res, next) => {
      req.user = req.headers['x-test-as'] === 'editor' ? EDITOR : ADMIN;
      next();
    });
    app.use('/edge/app/capacity', capacityRouter);
    server = http.createServer(app);
    await new Promise((r) => server.listen(0, r));
    baseUrl = `http://127.0.0.1:${server.address().port}`;
    dbReady = true;
  } catch (err) {
    skipReason = `setup failed: ${err.message}`;
    if (admin) { try { await admin.end(); } catch { /* best effort */ } }
    if (process.env.REQUIRE_INTEGRATION_DB === '1') throw err;
  }
});

after(async () => {
  if (server) { try { server.close(); } catch { /* best effort */ } }
  if (pool) { try { await pool.end(); } catch { /* best effort */ } }
  if (!testDbName) return;
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) return;
  try {
    const admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`DROP DATABASE IF EXISTS \`${testDbName}\``);
    await admin.end();
  } catch { /* best effort */ }
});

async function call(method, url, body, as) {
  const res = await fetch(`${baseUrl}${url}`, {
    method,
    headers: { 'content-type': 'application/json', ...(as ? { 'x-test-as': as } : {}) },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const text = await res.text();
  let parsed = null;
  try { parsed = JSON.parse(text); } catch { parsed = { raw: text }; }
  return { status: res.status, body: parsed };
}

const q = (sql, params) => pool.query(sql, params);
const one = async (sql, params) => (await pool.query(sql, params))[0];

const CAPACITY_TABLES = [
  'cap_waivers', 'cap_rules', 'cap_custom_group_members', 'cap_custom_groups',
  'cap_db_instances', 'cap_vms', 'cap_databases', 'cap_hypervisors', 'cap_sites',
  'cap_versions', 'cap_bundle_items', 'cap_bundles', 'cap_field_defs',
  'cap_vm_profiles', 'cap_disk_combos', 'cap_teams', 'cap_hardware_specs',
  'cap_settings', 'cap_scenarios',
];

const guard = (t) => {
  if (dbReady) return false;
  t.skip(skipReason || 'database not ready');
  return true;
};

beforeEach(async () => {
  if (!dbReady) return;
  pending.length = 0;
  driverErrors.length = 0;
  gate = null;
  injectedFault = null;
  for (const name of [...CAPACITY_TABLES, 'feature_audit', 'users']) {
    await q(`DELETE FROM \`${tbl(name)}\``);
  }
  await q(
    `INSERT INTO \`${tbl('users')}\` (id, email, role, banned) VALUES (?,?,?,0)`,
    [ADMIN_ID, 'admin@test.local', 'admin'],
  );
  await q(
    `INSERT INTO \`${tbl('users')}\` (id, email, role, banned) VALUES (?,?,?,0)`,
    [EDITOR_ID, 'editor@test.local', 'editor'],
  );
  await q(
    `INSERT INTO \`${tbl('cap_scenarios')}\` (id, name, owner_id) VALUES (?,?,?)`,
    [SCENARIO_ID, 'a scenario', null],
  );
});

const base = `/edge/app/capacity/scenarios/${SCENARIO_ID}`;

async function seedTwoDataCentres() {
  const spec = await call('POST', '/edge/app/capacity/config/hardware_specs',
    { name: 'spec', cpu_total: 64, mem_total_gb: 512, disk_total_gb: 4096 });
  const siteA = await call('POST', `${base}/sites`, { name: 'DC-A' });
  const siteB = await call('POST', `${base}/sites`, { name: 'DC-B' });
  const hvA = await call('POST', `${base}/hypervisors`,
    { name: 'host-a', site_id: siteA.body.data.id, spec_id: spec.body.data.id });
  const hvB = await call('POST', `${base}/hypervisors`,
    { name: 'host-b', site_id: siteB.body.data.id, spec_id: spec.body.data.id });
  for (const [what, res] of [['spec', spec], ['DC-A', siteA], ['DC-B', siteB], ['host-a', hvA], ['host-b', hvB]]) {
    assert.ok(res.status === 200 || res.status === 201, `the ${what} fixture was refused: ${JSON.stringify(res.body)}`);
  }
  return {
    siteA: siteA.body.data.id,
    siteB: siteB.body.data.id,
    hvA: hvA.body.data.id,
    hvB: hvB.body.data.id,
  };
}

async function mkVm(name, hypervisorId) {
  const res = await call('POST', `${base}/vms`, { name, vm_type: 'ap_host', hypervisor_id: hypervisorId });
  assert.equal(res.status, 200, `the VM fixture was refused: ${JSON.stringify(res.body)}`);
  return res.body.data.id;
}

// A `db_host` KVM — the only vm_type a `cap_db_instances.vm_id` may reference
// (CONTAINER_REF.instance's requireVmType in placement-apply.js).
async function mkDbHostVm(name, hypervisorId) {
  const res = await call('POST', `${base}/vms`, { name, vm_type: 'db_host', hypervisor_id: hypervisorId });
  assert.equal(res.status, 200, `the db_host VM fixture was refused: ${JSON.stringify(res.body)}`);
  return res.body.data.id;
}

const storedVm = (vmId) => one(
  `SELECT hypervisor_id, site_id FROM \`${tbl('cap_vms')}\` WHERE id = ?`, [vmId],
);

// A database with a set Primary SGA and NO profile, so a primary instance's
// derived `sga_gb` is exactly `primary_sga_gb` (deriveInstanceSga's first branch,
// no profile cap in play) — which is what makes the stale-vs-fresh read legible
// as a single number below.
async function mkDatabase(name, primarySgaGb) {
  const res = await call('POST', `${base}/databases`,
    { function_name: name, topology: 'single', primary_sga_gb: primarySgaGb });
  assert.ok(res.status === 200 || res.status === 201, `the database fixture was refused: ${JSON.stringify(res.body)}`);
  return res.body.data.id;
}

const storedInstanceSga = async (instanceId) => Number(
  (await one(`SELECT sga_gb FROM \`${tbl('cap_db_instances')}\` WHERE id = ?`, [instanceId])).sga_gb,
);

// ── The forced interleaving ─────────────────────────────────────────────────

/** Wait until some request connection is parked on a statement matching `re`. */
async function waitParked(re, ms = 15000) {
  const t0 = Date.now();
  for (;;) {
    if (pending.some((p) => !p.done && re.test(p.sql))) return true;
    if (Date.now() - t0 > ms) return false;
    await new Promise((r) => setTimeout(r, 20));
  }
}

// The two points a request can be parked at while it waits for a hypervisor
// row: the reference check's FOR UPDATE probe, or the factory's own UPDATE.
//
// Anchored on `SELECT id, scenario_id` — the §17.1a probe's own shape
// (reference-integrity.js) — rather than on the bare `FROM ... WHERE id = ?
// FOR UPDATE` tail. That tail also matches `deriveVmSiteFromHost`'s locking
// read (`SELECT site_id FROM cap_hypervisors WHERE id = ? LIMIT 1 FOR
// UPDATE`, children.js): it happened not to match only because `LIMIT 1`
// sits between the `?` and `FOR UPDATE` there and not here, so dropping that
// `LIMIT 1` would make this pattern park on the derive read instead of the FK
// probe and the forced interleaving below would stop being forced without the
// suite ever going red.
const PARK_ON_FK_LOCK = new RegExp(`^SELECT id, scenario_id.*FROM \`${tbl('cap_hypervisors')}\` WHERE id = \\? FOR UPDATE`);
const PARK_ON_HV_UPDATE = new RegExp(`^UPDATE \`${tbl('cap_hypervisors')}\``);
// The placement Save's canonical lock-order anchor: it takes the move-target
// hypervisor rows FOR UPDATE before any `cap_vms` row, so a Save contending for
// a host now parks HERE — holding nothing in cap_vms — instead of on the §17.1a
// FK probe with a moved-row lock already in hand. This park point is what
// distinguishes the fix from the pre-anchor handler in the cases below.
const PARK_ON_HV_ANCHOR = new RegExp(`^SELECT id FROM \`${tbl('cap_hypervisors')}\` FORCE INDEX`);

/**
 * Run two requests against each other with the interleaving forced, and answer
 * with what the DRIVER saw.
 *
 * `blockerHost` is the hypervisor row both requests need. `first` is fired and
 * queues for it ahead of `second`, which by the time it parks is holding
 * everything it claims BEFORE that row. Releasing the blocker hands the row to
 * `first`, which then wants what `second` holds.
 *
 * SO `first` IS THE ONE GRANTED THE HOST ROW, and swapping the two arguments is
 * a different test rather than the same one written twice — it decides which
 * writer is holding VMs when the other comes looking for them. Every pair here
 * is run both ways round for that reason.
 */
async function racePair({
  blockerHost, first, second, firstParksOn = PARK_ON_FK_LOCK, secondParksOn = PARK_ON_HV_UPDATE,
}) {
  pending.length = 0;
  driverErrors.length = 0;
  const blocker = await pool.getConnection();
  try {
    await blocker.beginTransaction();
    await blocker.query(
      `SELECT id FROM \`${tbl('cap_hypervisors')}\` WHERE id = ? FOR UPDATE`, [blockerHost],
    );

    const pFirst = first();
    const parkedFirst = await waitParked(firstParksOn);
    const pSecond = second();
    const parkedSecond = await waitParked(secondParksOn);
    // Both are queued on the blocker; let them settle onto the wait list before
    // the row is handed over.
    await new Promise((r) => setTimeout(r, 300));
    await blocker.rollback();

    const [firstRes, secondRes] = await Promise.all([pFirst, pSecond]);
    return {
      firstRes,
      secondRes,
      parkedFirst,
      parkedSecond,
      deadlocks: driverErrors.filter((e) => e.errno === 1213),
      lockWaits: driverErrors.filter((e) => e.errno === 1205),
    };
  } finally {
    blocker.release();
  }
}

/** Both requests reached their wait, no cycle formed, and both landed. */
function assertNoCycle(outcome, label) {
  assert.ok(outcome.parkedFirst, `${label}: the first request never parked — the interleaving was not forced`);
  assert.ok(outcome.parkedSecond, `${label}: the second request never parked — the interleaving was not forced`);
  assert.deepEqual(
    outcome.deadlocks.map((e) => e.sql), [],
    `${label}: InnoDB raised errno 1213 — the two writers claim cap_hypervisors and cap_vms in opposite orders`,
  );
  assert.deepEqual(
    outcome.lockWaits.map((e) => e.sql), [],
    `${label}: errno 1205 — a writer waited out the lock timeout instead of proceeding once the blocker released`,
  );
  for (const [which, res] of [['first', outcome.firstRes], ['second', outcome.secondRes]]) {
    assert.ok(
      res.status === 200 || res.status === 201,
      `${label}: the ${which} request was refused ${res.status} — ${JSON.stringify(res.body)}`,
    );
  }
}

describe('a host edit and a KVM write take the same order, in either grant order', () => {
  // Both of these mounts lock the referenced hypervisor through the §17.1a
  // check before they touch the vm row, which is the order the comparator
  // states. Two writers that agree cannot cycle whichever of them is granted
  // the host first — but that is the claim, so both ways round are driven.

  test('a KVM moved through the grid, against a host changing its data centre', async (t) => {
    if (guard(t)) return;
    // The everyday pair: an operator edits a KVM's Hypervisor while another
    // saves that host's Site. Both are ordinary edits of unrelated fields and
    // neither is wrong, so a refusal here is a 409 the caller can do nothing
    // about but retry.
    const { siteA, siteB, hvA } = await seedTwoDataCentres();
    const vmId = await mkVm('kvm1', hvA);

    const outcome = await racePair({
      blockerHost: hvA,
      first: () => call('PUT', `${base}/vms/${vmId}`, { hypervisor_id: hvA }),
      second: () => call('PUT', `${base}/hypervisors/${hvA}`, { site_id: siteB }),
    });
    assertNoCycle(outcome, 'vms PUT granted the host first');

    // And the data both writes were about: the host moved, and the KVM standing
    // on it moved with it. Asserted on the stored row, because a pair that
    // deadlocked would leave one of the two writes missing entirely.
    const row = await storedVm(vmId);
    assert.equal(row.hypervisor_id, hvA);
    assert.equal(row.site_id, siteB, 'the KVM was left in the data centre its host has left');
    assert.notEqual(siteA, siteB);
  });

  test('…and with the host edit granted the row first instead', async (t) => {
    if (guard(t)) return;
    // The arrangement that catches the placement Save below. It is harmless
    // here for a reason worth stating: the KVM write is still parked on the
    // §17.1a probe when the host edit takes the row, so it is holding nothing
    // in cap_vms for the cascade to wait on.
    const { siteB, hvA } = await seedTwoDataCentres();
    const vmId = await mkVm('kvm1', hvA);

    const outcome = await racePair({
      blockerHost: hvA,
      first: () => call('PUT', `${base}/hypervisors/${hvA}`, { site_id: siteB }),
      firstParksOn: PARK_ON_HV_UPDATE,
      second: () => call('PUT', `${base}/vms/${vmId}`, { hypervisor_id: hvA }),
      secondParksOn: PARK_ON_FK_LOCK,
    });
    assertNoCycle(outcome, 'hypervisor PUT granted the host first');

    const row = await storedVm(vmId);
    assert.equal(row.hypervisor_id, hvA);
    assert.equal(row.site_id, siteB);
  });

  test('a KVM created on a host that has none yet, against that host changing its data centre', async (t) => {
    if (guard(t)) return;
    // The empty-host case, and the one a range lock makes counter-intuitive: a
    // `WHERE hypervisor_id = ?` claim over a host with NO KVMs still holds the
    // index range, so an INSERT into it waits even though the claim selected
    // nothing.
    const { siteB, hvA } = await seedTwoDataCentres();
    assert.equal(
      Number((await one(`SELECT COUNT(*) AS n FROM \`${tbl('cap_vms')}\` WHERE hypervisor_id = ?`, [hvA])).n), 0,
      'the fixture must start with an EMPTY host or this case is not the one it names',
    );

    const outcome = await racePair({
      blockerHost: hvA,
      first: () => call('POST', `${base}/vms`, { name: 'kvm-new', vm_type: 'ap_host', hypervisor_id: hvA }),
      second: () => call('PUT', `${base}/hypervisors/${hvA}`, { site_id: siteB }),
    });
    assertNoCycle(outcome, 'vms POST granted the host first');

    const created = await one(`SELECT id, hypervisor_id, site_id FROM \`${tbl('cap_vms')}\``);
    assert.ok(created, 'the create was rolled back');
    assert.equal(created.hypervisor_id, hvA);
    assert.equal(created.site_id, siteB, 'the new KVM was left in the data centre its host has left');
  });

  test('…and with the host edit granted the row first: the create derives the NEW data centre', async (t) => {
    if (guard(t)) return;
    // THIS ARRANGEMENT IS THE ONE THAT CAUGHT A STALE READ, and the assertion
    // that matters here is the stored value rather than the absence of a cycle.
    //
    // The host edit commits its new Site while the create is still parked on the
    // §17.1a probe. The create then derives the host's data centre — and a
    // non-locking SELECT under REPEATABLE READ answers from the read view this
    // transaction took at its FIRST consistent read, which on the create path is
    // `bindStoredParentIds`'s lookup of the stored `cap_scenarios` id (the first
    // read on the write connection), before the FK lock. So it derived the data
    // centre the host had just LEFT, and the cascade that would have repaired it
    // had already run against a row that did not exist yet. The row landed
    // permanently contradicting its host: exactly the state this whole unit
    // exists to make unreachable, reached by two ordinary concurrent edits.
    //
    // The update path did not have it — its read view is taken after the FK lock
    // — which is why only one verb was wrong and why this case is here.
    const { siteA, siteB, hvA } = await seedTwoDataCentres();

    const outcome = await racePair({
      blockerHost: hvA,
      first: () => call('PUT', `${base}/hypervisors/${hvA}`, { site_id: siteB }),
      firstParksOn: PARK_ON_HV_UPDATE,
      second: () => call('POST', `${base}/vms`, { name: 'kvm-new', vm_type: 'ap_host', hypervisor_id: hvA }),
      secondParksOn: PARK_ON_FK_LOCK,
    });
    assertNoCycle(outcome, 'hypervisor PUT granted the host first, against a create');

    const created = await one(`SELECT id, hypervisor_id, site_id FROM \`${tbl('cap_vms')}\``);
    assert.ok(created, 'the create was rolled back');
    assert.equal(created.hypervisor_id, hvA);
    assert.equal(
      created.site_id, siteB,
      'the create stored the data centre its host had already left — the derive read a snapshot, not the row',
    );
    // And the contradiction is stated directly, in the terms the health check
    // uses, so this cannot pass on a fixture where both sites coincide.
    assert.notEqual(siteA, siteB);
    const host = await one(`SELECT site_id FROM \`${tbl('cap_hypervisors')}\` WHERE id = ?`, [hvA]);
    assert.equal(created.site_id, host.site_id, 'the stored KVM contradicts the host it stands on');
  });
});

/**
 * THE SAME RULE, THE THIRD DERIVATION: a db_instance's `sga_gb` derived from its
 * database's Primary SGA at create time (children.js deriveDbInstanceSgaOnCreate).
 *
 * The §17.1a FK validator locks the database_id row FOR UPDATE, which stops
 * anyone changing its SGA from here to commit — but the derive read used to be a
 * NON-locking SELECT, so under REPEATABLE READ it answered from the create tx's
 * read view (opened at its scenario read, before the FK lock). A Primary SGA edit
 * committing in that window was read as the OLD value and derived into the NEW
 * instance's `sga_gb` permanently, with no cascade to repair a row that did not
 * exist when cascadeDbSgaToInstances ran. The locking read answers from the
 * latest committed version instead, so the new instance carries the value the
 * database holds AT COMMIT.
 *
 * STRENGTHENS this: the db_instances create and the databases edit now
 * BOTH take the scenario row FOR UPDATE first (makeScenarioRowLock), so the two
 * writers serialise on cap_scenarios before either touches cap_databases. The
 * create therefore parks on the SCENARIO row (held by the concurrent edit), not
 * on the cap_databases FK probe it used to reach first — and once the edit
 * commits and frees the scenario row, the create runs its FK-locked derive
 * against the already-committed database. Same committed-value guarantee, reached
 * one lock earlier, and the outcome asserts what matters: no deadlock, no
 * lock-wait timeout, and the derived SGA equals the value the database holds.
 */
const PARK_ON_DB_UPDATE = new RegExp(`^UPDATE \`${tbl('cap_databases')}\``);
// the create's FIRST lock is now the scenario row, so that is where the
// concurrent edit parks it (it never reaches the cap_databases FK probe until the
// edit commits and releases the scenario row).
const PARK_ON_SCENARIO_LOCK = new RegExp(`^SELECT id FROM \`${tbl('cap_scenarios')}\` WHERE id = \\? FOR UPDATE`);

describe('a db_instance create derives its SGA from the database as it stands at commit', () => {
  test('a Primary SGA edit granted the database row first: the create derives the NEW value', async (t) => {
    if (guard(t)) return;
    // The edit commits its new Primary SGA while the create is still parked on
    // the scenario row (both writers serialise there first). The create
    // then runs its FK-locked derive against the committed database and carries
    // 200; pre-derive-fix it read the snapshot and carried the value the database
    // had already left.
    const { hvA } = await seedTwoDataCentres();
    const dbHost = await mkDbHostVm('db-host', hvA);
    const dbId = await mkDatabase('ORCL', 100);

    pending.length = 0;
    driverErrors.length = 0;
    const blocker = await pool.getConnection();
    let outcome;
    try {
      await blocker.beginTransaction();
      await blocker.query(`SELECT id FROM \`${tbl('cap_databases')}\` WHERE id = ? FOR UPDATE`, [dbId]);

      // The concurrent Primary SGA edit queues FIRST and parks on its UPDATE.
      const pEdit = call('PUT', `${base}/databases/${dbId}`, { primary_sga_gb: 200 });
      const parkedEdit = await waitParked(PARK_ON_DB_UPDATE);
      // The create queues SECOND and parks on the SCENARIO row FOR UPDATE
      // (makeScenarioRowLock, its first lock) — the edit is holding it,
      // so the create never reaches the cap_databases FK probe until the edit
      // commits and frees the scenario row.
      const pCreate = call('POST', `${base}/db_instances`,
        { name: 'inst-primary', role: 'primary', vm_id: dbHost, database_id: dbId });
      const parkedCreate = await waitParked(PARK_ON_SCENARIO_LOCK);
      await new Promise((r) => setTimeout(r, 300));
      await blocker.rollback();

      const [editRes, createRes] = await Promise.all([pEdit, pCreate]);
      outcome = {
        editRes, createRes, parkedEdit, parkedCreate,
        deadlocks: driverErrors.filter((e) => e.errno === 1213),
        lockWaits: driverErrors.filter((e) => e.errno === 1205),
      };
    } finally {
      blocker.release();
    }

    assert.ok(outcome.parkedEdit, 'the SGA edit never parked — the interleaving was not forced');
    assert.ok(outcome.parkedCreate, 'the create never parked on the scenario row — the interleaving was not forced');
    assert.deepEqual(outcome.deadlocks.map((e) => e.sql), [], 'InnoDB raised errno 1213');
    assert.deepEqual(outcome.lockWaits.map((e) => e.sql), [], 'errno 1205 — a writer waited out the lock timeout');
    assert.equal(outcome.editRes.status, 200, `the SGA edit was refused: ${JSON.stringify(outcome.editRes.body)}`);
    assert.ok(outcome.createRes.status === 200 || outcome.createRes.status === 201,
      `the create was refused: ${JSON.stringify(outcome.createRes.body)}`);

    const instanceId = outcome.createRes.body.data.id;
    assert.equal(
      await storedInstanceSga(instanceId), 200,
      'the new instance carried the Primary SGA the database had already left — the derive read a snapshot, not the row',
    );
    // Stated in the DB's own terms so this cannot pass on a fixture where the two
    // SGA values coincide.
    const db = await one(`SELECT primary_sga_gb FROM \`${tbl('cap_databases')}\` WHERE id = ?`, [dbId]);
    assert.equal(Number(db.primary_sga_gb), 200, 'the edit did not commit its new Primary SGA');
    assert.equal(await storedInstanceSga(instanceId), Number(db.primary_sga_gb),
      'the stored instance SGA contradicts the database it derives from');
  });
});

/**
 * THE SAME DEFECT ON THE OTHER BRANCH OF THE SAME STATEMENT.
 *
 * The create above was made fresh by reading the host's row with `FOR UPDATE` —
 * a locking read answers from the latest committed version rather than from the
 * transaction's read view. The hook takes that lock only when the write NAMES
 * the host. A partial PUT that names only the data centre reaches the same read
 * with no lock, so it is answered from the read view, and whether that view was
 * already open decides whether the value is current.
 *
 * WHICH IS WHY THE ROLE IS PART OF THE CASE, not a detail of the fixture. An
 * administrator's PUT of this shape takes no consistent read before the hook, so
 * the hook's own read opens the view and sees the latest commit. An editor's
 * takes three — the entitlement probe and the two ownership reads — and every
 * one of them fixes the view before the hook runs. A claim measured as admin is
 * therefore not a claim about this mount, whose `allowedRoles` are both.
 *
 * FORCED WITH A GATE RATHER THAN A LOCK: at the point that matters this request
 * holds nothing and waits for nothing, so there is no lock to park it on.
 */
describe('a partial PUT naming only the data centre, against the host moving to another', () => {
  // The hook's read of the row's own placement, which is the last statement
  // before the derived value is decided. Written to match whether or not the
  // projection carries more than one column, so adding one cannot make this
  // gate silently stop firing — a barrier that never fires leaves the case
  // measuring nothing while still passing.
  const GATE_ON_PLACEMENT_READ = new RegExp(
    `^SELECT hypervisor_id[a-z_, ]* FROM \`${tbl('cap_vms')}\` WHERE id = \\? FOR UPDATE`,
  );

  /**
   * Hold the PUT just before it derives, commit the host's move to another data
   * centre underneath it, then let it finish. Answers with what the row holds.
   */
  async function measure(as) {
    const { siteA, siteB, hvA } = await seedTwoDataCentres();
    // A THIRD data centre, named by the PUT and by nothing else, so the three
    // possible outcomes are told apart by the stored value alone: the host's
    // OLD site means the derive read a stale snapshot, the host's NEW site
    // means it read the row, and this one means the caller's hand-set value was
    // stored over the host's.
    const dcC = await call('POST', `${base}/sites`, { name: 'DC-C' });
    assert.equal(dcC.status, 200, `the DC-C fixture was refused: ${JSON.stringify(dcC.body)}`);
    const askedFor = dcC.body.data.id;
    const vmId = await mkVm('kvm1', hvA);
    assert.equal(
      (await storedVm(vmId)).site_id, siteA,
      'the premise: the KVM starts in the data centre its host stands in',
    );

    const g = armGate(GATE_ON_PLACEMENT_READ);
    const pPut = call('PUT', `${base}/vms/${vmId}`, { site_id: askedFor }, as);
    const forced = await Promise.race([g.reached.then(() => true), pPut.then(() => false)]);
    assert.ok(forced, `the ${as} PUT finished without reaching the derive read — nothing was forced`);

    const edit = await call('PUT', `${base}/hypervisors/${hvA}`, { site_id: siteB });
    assert.equal(edit.status, 200, `the host edit was refused: ${JSON.stringify(edit.body)}`);
    assert.equal(
      (await storedVm(vmId)).site_id, siteB,
      'the host cascade did not repin the KVM, so the case below would measure the wrong thing',
    );

    g.release();
    const putRes = await pPut;
    return {
      putRes, stored: (await storedVm(vmId)).site_id, siteA, siteB, askedFor,
    };
  }

  test('an EDITOR\'s PUT stores the data centre the host is in, not the one it has left', async (t) => {
    if (guard(t)) return;
    const {
      putRes, stored, siteA, siteB, askedFor,
    } = await measure('editor');
    assert.equal(putRes.status, 200, `the editor's PUT was refused: ${JSON.stringify(putRes.body)}`);
    assert.notEqual(siteA, siteB);
    assert.notEqual(askedFor, siteB);
    assert.notEqual(
      stored, askedFor,
      'the caller\'s hand-set data centre was stored — the per-row gate did not hold',
    );
    assert.equal(
      stored, siteB,
      'the editor\'s PUT stored the data centre its host had already left: the derive answered from '
      + 'the read view its entitlement and ownership probes had already opened',
    );
  });

  test('…and an administrator\'s does too, whose probes never open that view', async (t) => {
    if (guard(t)) return;
    // The control. It passed before the editor case did, and it is what made the
    // defect look absent: the same handler, the same interleaving, a different
    // number of reads before the hook.
    const {
      putRes, stored, siteA, siteB, askedFor,
    } = await measure(undefined);
    assert.equal(putRes.status, 200, `the admin PUT was refused: ${JSON.stringify(putRes.body)}`);
    assert.notEqual(siteA, siteB);
    assert.notEqual(stored, askedFor, 'the caller\'s hand-set data centre was stored');
    assert.equal(stored, siteB, 'the admin PUT stored the data centre its host had already left');
  });
});

/**
 * THE THIRD SITE OF THE SAME RULE, in the other handler that derives this value.
 *
 * The staged Save resolves each moved KVM's new data centre from the hosts it is
 * moving them onto. Those host rows are already held FOR UPDATE by this
 * transaction's reference check — but holding a row and SEEING its current
 * version are different guarantees, and the argument beside that read only
 * established the first. A consistent read answers from the read view whatever
 * locks the transaction holds, so the derived value is as old as whichever
 * statement opened that view.
 *
 * WHICH ONE THAT IS DEPENDS ON THE BATCH. A Save carrying `hostOrders` resolves
 * each named host with a plain lookup before it locks anything, and that lookup
 * opens the view; a batch of bare moves takes only locking reads until the
 * derive itself, so the derive opens the view and is current. The ordering half
 * of a canvas Save is the ordinary shape, not a corner of the API.
 */
describe('the staged Save derives each moved KVM\'s data centre from the host it lands on', () => {
  // The canonical lock-order anchor: the Save's FIRST claim on `cap_hypervisors`.
  // Gating just BEFORE it holds the target host is what lets the concurrent host
  // edit through — a `hostOrders` batch has already run its plain host lookup, so
  // the read view is open, but no row is locked yet. Once the anchor releases,
  // BOTH it and the derive read the host FOR UPDATE, so a locking derive answers
  // from the edit that committed in this window and a consistent one (the D1
  // regression) still answers from the stale read view.
  const GATE_ON_HV_ANCHOR = new RegExp(
    `^SELECT id FROM \`${tbl('cap_hypervisors')}\` FORCE INDEX`,
  );

  test('a batch that also reorders a host lands the KVM in the data centre that host is in', async (t) => {
    if (guard(t)) return;
    const {
      siteA, siteB, hvA, hvB,
    } = await seedTwoDataCentres();
    const vmId = await mkVm('kvm1', hvB);

    const g = armGate(GATE_ON_HV_ANCHOR);
    const pSave = call('POST', `${base}/placement/apply`, {
      moves: [{ kind: 'vm', id: vmId, from: hvB, to: hvA }],
      hostOrders: [{ hostId: hvA, vmIds: [vmId] }],
    });
    const forced = await Promise.race([g.reached.then(() => true), pSave.then(() => false)]);
    assert.ok(forced, 'the Save finished without reaching its host anchor — nothing was forced');

    const edit = await call('PUT', `${base}/hypervisors/${hvA}`, { site_id: siteB });
    assert.equal(edit.status, 200, `the host edit was refused: ${JSON.stringify(edit.body)}`);

    g.release();
    const saveRes = await pSave;
    assert.equal(saveRes.status, 200, `the Save was refused: ${JSON.stringify(saveRes.body)}`);

    const row = await storedVm(vmId);
    assert.equal(row.hypervisor_id, hvA, 'the move did not land');
    assert.notEqual(siteA, siteB);
    assert.equal(
      row.site_id, siteB,
      'the Save stored the data centre its destination host had already left — the derive answered from '
      + 'the read view the hostOrders lookup had already opened, not from the rows it holds',
    );
    const host = await one(`SELECT site_id FROM \`${tbl('cap_hypervisors')}\` WHERE id = ?`, [hvA]);
    assert.equal(row.site_id, host.site_id, 'the stored KVM contradicts the host it now stands on');
  });
});

/**
 * WHAT THAT LOCKING READ CLAIMS, AND FROM WHOM.
 *
 * `FOR UPDATE` locks the rows the chosen PLAN visits, not the rows the WHERE
 * clause finally admits. The derive above names its destination hosts by
 * primary key and the reference check has already taken exactly those rows, so
 * it is meant to acquire nothing new — but that only holds while the id list is
 * the WHOLE of its predicate. A second predicate on `scenario_id` hands the
 * optimizer an index to choose instead, and a full scan to fall back on; under
 * `FOR UPDATE` a full scan claims every hypervisor row in the table, including
 * hosts this Save never names and scenarios it does not touch.
 *
 * MEASURED, NOT REASONED: MariaDB 10.11, eight hosts in one scenario and two in
 * another. Three ids planned `ref` and blocked nothing — a secondary index
 * carries the primary key, so the id list is pushed into it — and six or more
 * planned `ALL` and blocked both an unlisted host and another scenario's. Which
 * is why the batch below moves onto SIX hosts: at three this measures nothing.
 *
 * What the widening costs is the bound stated in children.js beside the
 * KNOWN-OPEN cycle — that the Save contends only for the host its reference
 * probe targets. A read that locks the table contends with every host edit on
 * the estate, in every scenario.
 */
describe('the staged Save claims only the hosts it is moving onto', () => {
  // The first per-move write. By the time a statement of this shape is offered,
  // the data-centre derive has run and whatever it locked is held to commit.
  const GATE_ON_MOVE_UPDATE = new RegExp(`^UPDATE \`${tbl('cap_vms')}\` SET \`hypervisor_id\``);

  const SCENARIO_B_ID = 'dddddddd-1111-4222-8333-444455556666';

  /**
   * Eight hosts in this scenario and two in another, which is the fixture the
   * plan measurement above was taken on: enough rows that a scan is cheaper
   * than six index dives, and a second scenario to be blocked out of.
   */
  async function seedCrowdedEstate() {
    const spec = await call('POST', '/edge/app/capacity/config/hardware_specs',
      { name: 'spec', cpu_total: 64, mem_total_gb: 512, disk_total_gb: 4096 });
    assert.ok(spec.status === 200 || spec.status === 201, `the spec fixture was refused: ${JSON.stringify(spec.body)}`);
    const specId = spec.body.data.id;

    // THREE data centres, so a derive that wrote one site over every moved KVM
    // would fail the stored-value assertions rather than pass them.
    const sites = [];
    for (const name of ['DC-A', 'DC-B', 'DC-C']) {
      const res = await call('POST', `${base}/sites`, { name });
      assert.equal(res.status, 200, `the ${name} fixture was refused: ${JSON.stringify(res.body)}`);
      sites.push(res.body.data.id);
    }
    const hosts = [];
    for (let i = 0; i < 8; i += 1) {
      const res = await call('POST', `${base}/hypervisors`,
        { name: `host-${i}`, site_id: sites[i % sites.length], spec_id: specId });
      assert.equal(res.status, 200, `the host-${i} fixture was refused: ${JSON.stringify(res.body)}`);
      hosts.push(res.body.data.id);
    }

    // The other scenario, and the writer this Save has no business with.
    await q(
      `INSERT INTO \`${tbl('cap_scenarios')}\` (id, name, owner_id) VALUES (?,?,?)`,
      [SCENARIO_B_ID, 'another scenario', null],
    );
    const otherBase = `/edge/app/capacity/scenarios/${SCENARIO_B_ID}`;
    const otherSite = await call('POST', `${otherBase}/sites`, { name: 'DC-far' });
    assert.equal(otherSite.status, 200, `the far DC fixture was refused: ${JSON.stringify(otherSite.body)}`);
    const otherHosts = [];
    for (const name of ['far-0', 'far-1']) {
      const res = await call('POST', `${otherBase}/hypervisors`,
        { name, site_id: otherSite.body.data.id, spec_id: specId });
      assert.equal(res.status, 200, `the ${name} fixture was refused: ${JSON.stringify(res.body)}`);
      otherHosts.push(res.body.data.id);
    }

    // Six KVMs parked on host-0, each with a different host to move onto.
    const vms = [];
    for (let i = 1; i <= 6; i += 1) vms.push(await mkVm(`kvm-${i}`, hosts[0]));

    // THE OPTIMIZER DECIDES WHAT A `FOR UPDATE` CLAIMS, and it decides from the
    // statistics. A fixture whose stats are stale can plan the narrow way and
    // measure nothing while passing.
    await q(`ANALYZE TABLE \`${tbl('cap_hypervisors')}\``);
    return {
      specId, sites, hosts, otherHosts, otherSite: otherSite.body.data.id, vms,
    };
  }

  /**
   * A writer with a short patience, on a connection of its own. The pool's
   * connections carry `innodb_lock_wait_timeout = 20` and are handed to the
   * next test that borrows them, so the patience is set here rather than there;
   * and a blocked probe must cost seconds to observe, not twenty.
   */
  async function withImpatientWriter(body) {
    const dbConfig = await resolveMariaDbConfig();
    const conn = await mariadb.createConnection({ ...dbConfig, database: testDbName, connectTimeout: 5000 });
    try {
      await conn.query('SET SESSION innodb_lock_wait_timeout = 2');
      const attempt = async (sql, params) => {
        await conn.beginTransaction();
        try {
          await conn.query(sql, params);
          await conn.commit();
          return 'granted';
        } catch (err) {
          try { await conn.rollback(); } catch { /* the victim is already rolled back */ }
          return `errno ${err.errno}`;
        }
      };
      return await body(attempt);
    } finally {
      try { await conn.end(); } catch { /* best effort */ }
    }
  }

  const SET_HOST_SITE = `UPDATE \`${tbl('cap_hypervisors')}\` SET site_id = ? WHERE id = ? AND scenario_id = ?`;

  test('a six-destination Save blocks neither an unlisted host nor another scenario\'s', async (t) => {
    if (guard(t)) return;
    const estate = await seedCrowdedEstate();
    const destinations = estate.hosts.slice(1, 7);
    const unlisted = estate.hosts[7];
    const foreign = estate.otherHosts[0];
    assert.equal(new Set(destinations).size, 6, 'the premise: six DISTINCT destination hosts');
    assert.ok(!destinations.includes(unlisted), 'the premise: the unlisted host is not one of the destinations');
    assert.ok(!destinations.includes(foreign), 'the premise: the foreign host is not one of the destinations');

    const g = armGate(GATE_ON_MOVE_UPDATE);
    const pSave = call('POST', `${base}/placement/apply`, {
      moves: estate.vms.map((id, i) => ({
        kind: 'vm', id, from: estate.hosts[0], to: destinations[i],
      })),
    });
    const forced = await Promise.race([g.reached.then(() => true), pSave.then(() => false)]);
    assert.ok(forced, 'the Save finished without reaching its first move UPDATE — nothing was forced');

    // Held here: the derive has run, so whatever it claimed is claimed.
    const outcome = await withImpatientWriter(async (attempt) => ({
      foreign: await attempt(SET_HOST_SITE, [estate.otherSite, foreign, SCENARIO_B_ID]),
      unlisted: await attempt(SET_HOST_SITE, [estate.sites[0], unlisted, SCENARIO_ID]),
    }));

    // Released BEFORE the assertions: a failing one must not leave the Save
    // parked on a gate nobody will open.
    g.release();
    const saveRes = await pSave;

    assert.equal(
      outcome.foreign, 'granted',
      'a Save in one scenario blocked a host edit in ANOTHER (errno 1205 is the wait): the derive\'s '
      + 'FOR UPDATE locked rows outside the set the reference check claimed',
    );
    assert.equal(
      outcome.unlisted, 'granted',
      'a Save blocked an edit of a host it never names: the derive\'s FOR UPDATE locked rows outside '
      + 'the set the reference check claimed',
    );

    // AND THE DERIVE STILL DERIVES. Narrowing what the read locks must not cost
    // the freshness the read exists for, so every moved KVM is checked against
    // the data centre of the host it landed on — three different ones here.
    assert.equal(saveRes.status, 200, `the Save was refused: ${JSON.stringify(saveRes.body)}`);
    for (let i = 0; i < destinations.length; i += 1) {
      const row = await storedVm(estate.vms[i]);
      const host = await one(`SELECT site_id FROM \`${tbl('cap_hypervisors')}\` WHERE id = ?`, [destinations[i]]);
      assert.equal(row.hypervisor_id, destinations[i], `kvm-${i + 1} did not land on its destination`);
      assert.equal(row.site_id, host.site_id, `kvm-${i + 1} stored a data centre its new host does not stand in`);
    }
  });

  test('and the locking read it takes is planned on the primary key', async (t) => {
    if (guard(t)) return;
    // THE MECHANISM BEHIND THE CASE ABOVE, measured on the statement the handler
    // ACTUALLY ISSUED — the recorder keeps every statement with its parameters,
    // so this cannot drift from the handler the way a copy written out here
    // would. `type`/`key` is what decides the lock set: an `ALL` row claims the
    // table.
    const estate = await seedCrowdedEstate();
    const destinations = estate.hosts.slice(1, 7);
    const res = await call('POST', `${base}/placement/apply`, {
      moves: estate.vms.map((id, i) => ({
        kind: 'vm', id, from: estate.hosts[0], to: destinations[i],
      })),
    });
    assert.equal(res.status, 200, `the Save was refused: ${JSON.stringify(res.body)}`);

    const read = pending.find((p) => /^SELECT id, site_id/.test(p.sql)
      && p.sql.includes(`\`${tbl('cap_hypervisors')}\``) && / FOR UPDATE$/.test(p.sql));
    assert.ok(read, 'the derive issued no locking read of cap_hypervisors — this case measures nothing');
    const plan = await q(`EXPLAIN ${read.sql}`, read.params);
    assert.equal(
      plan[0].key, 'PRIMARY',
      `the derive's locking read is planned ${plan[0].type}/${plan[0].key}: FOR UPDATE claims what the `
      + 'plan visits, so anything but a primary-key lookup locks rows the reference check never claimed',
    );
  });

  test('the premise: unpinned, this read does NOT plan on the primary key', async (t) => {
    if (guard(t)) return;
    // The only statement in this file written out by hand, and it is a
    // MEASUREMENT OF THE OPTIMIZER rather than an expected value: the derive's
    // own predicate, on the fixture the cases above use, with the index hint
    // taken off. Both unpinned shapes were measured planning a scan here — the
    // scenario predicate `ALL`, the id list alone `index` over the site index —
    // and either locks the table. If the optimizer ever reaches the primary key
    // unaided, the case above stops being able to fail and this one says so out
    // loud rather than leaving a green test measuring nothing.
    const estate = await seedCrowdedEstate();
    const destinations = estate.hosts.slice(1, 7);
    const placeholders = destinations.map(() => '?').join(', ');
    const unpinned = await q(
      `EXPLAIN SELECT id, site_id FROM \`${tbl('cap_hypervisors')}\``
      + ` WHERE scenario_id = ? AND id IN (${placeholders}) FOR UPDATE`,
      [SCENARIO_ID, ...destinations],
    );
    assert.notEqual(
      unpinned[0].key, 'PRIMARY',
      'the derive\'s predicate now reaches the primary key unaided on this fixture, so the lock case '
      + 'above would pass with the hint removed — give the fixture more hosts, or retire the case',
    );
    const idsOnly = await q(
      `EXPLAIN SELECT id, site_id FROM \`${tbl('cap_hypervisors')}\` WHERE id IN (${placeholders}) FOR UPDATE`,
      destinations,
    );
    assert.notEqual(
      idsOnly[0].key, 'PRIMARY',
      'dropping the scenario predicate would reach the primary key on its own here — if that becomes '
      + 'true in general the hint is no longer what is holding the lock set',
    );
  });
});

/**
 * The residual, now closed. `placement-apply.js` USED to claim the moved
 * `cap_vms` rows first and the hypervisors they move onto second — the opposite
 * order to the comparator and to every child mount — so this pair could cycle
 * whenever the host edit was granted the host row first. It now acquires the
 * target hypervisors FOR UPDATE before any `cap_vms` row (its canonical
 * lock-order anchor), so both writers take the two tables in one order and the
 * pair no longer cycles in EITHER grant order.
 *
 * ONE CONDITION was all it ever took: the Save's reference probe targeting the
 * host being edited AND that host edit granted the row first. Both grant orders
 * are still driven below, plus the within-host-reorder variant (the Save holding
 * more of `cap_vms`, which the anchor makes moot) and the off-host case that
 * never contended — so a regression that reopened the inversion would go red
 * here rather than becoming a sentence.
 */
describe('a host edit and the staged placement Save disagree, and the grant order decides', () => {
  test('the Save granted the host row first: it takes both tables at once, so no cycle', async (t) => {
    if (guard(t)) return;
    const { siteB, hvA, hvB } = await seedTwoDataCentres();
    const vmId = await mkVm('kvm1', hvB);

    const outcome = await racePair({
      blockerHost: hvA,
      first: () => call('POST', `${base}/placement/apply`, {
        moves: [{ kind: 'vm', id: vmId, from: hvB, to: hvA }],
      }),
      firstParksOn: PARK_ON_HV_ANCHOR,
      second: () => call('PUT', `${base}/hypervisors/${hvA}`, { site_id: siteB }),
    });
    assertNoCycle(outcome, 'placement Save granted the host first');

    const row = await storedVm(vmId);
    assert.equal(row.hypervisor_id, hvA);
    assert.equal(row.site_id, siteB);
  });

  test('the same, onto the other host', async (t) => {
    if (guard(t)) return;
    // Same shape, different host on both sides — the pair is about the ORDER two
    // writers take, not about which row they happen to name, and a fix that only
    // held for one host would pass the case above.
    const { siteA, hvA, hvB } = await seedTwoDataCentres();
    const vmId = await mkVm('kvm1', hvA);

    const outcome = await racePair({
      blockerHost: hvB,
      first: () => call('POST', `${base}/placement/apply`, {
        moves: [{ kind: 'vm', id: vmId, from: hvA, to: hvB }],
      }),
      firstParksOn: PARK_ON_HV_ANCHOR,
      second: () => call('PUT', `${base}/hypervisors/${hvB}`, { site_id: siteA }),
    });
    assertNoCycle(outcome, 'placement Save granted the other host first');

    const row = await storedVm(vmId);
    assert.equal(row.hypervisor_id, hvB);
    assert.equal(row.site_id, siteA);
  });

  test('the host edit granted the row first: the Save parks on the host anchor, so no cycle', async (t) => {
    if (guard(t)) return;
    // Identical requests to the first case; only the grant order differs, and it
    // is the arrangement that USED to cycle. The host edit takes the host row,
    // applies its UPDATE and then reaches for the VMs standing on it through the
    // cascade — but the Save is now parked on its canonical lock-order anchor
    // (the target hypervisor FOR UPDATE), holding NOTHING in cap_vms for the
    // cascade to wait on. So the edit runs straight through, commits, releases
    // the host row, and the Save proceeds. The exact lock pair this file is
    // about, taken in one order by both writers.
    const { siteB, hvA, hvB } = await seedTwoDataCentres();
    const vmId = await mkVm('kvm1', hvB);

    const outcome = await racePair({
      blockerHost: hvA,
      first: () => call('PUT', `${base}/hypervisors/${hvA}`, { site_id: siteB }),
      firstParksOn: PARK_ON_HV_UPDATE,
      second: () => call('POST', `${base}/placement/apply`, {
        moves: [{ kind: 'vm', id: vmId, from: hvB, to: hvA }],
      }),
      secondParksOn: PARK_ON_HV_ANCHOR,
    });
    assertNoCycle(outcome, 'hypervisor PUT granted the host first, against a Save');

    // Both writes landed: the host moved data centre, and the KVM the Save moved
    // onto it derived that same, committed data centre.
    const row = await storedVm(vmId);
    assert.equal(row.hypervisor_id, hvA);
    assert.equal(row.site_id, siteB);
  });

  test('the same condition, with a within-host reorder in the batch: still no cycle', async (t) => {
    if (guard(t)) return;
    // The variant that once made the Save hold MORE of cap_vms: `hostOrders`
    // claims the host's whole membership range too. It is still no cycle, because
    // the Save reaches none of those cap_vms locks until it has been granted the
    // host anchor — and while the host edit holds that row, the Save is parked on
    // the anchor holding nothing.
    const { siteB, hvA, hvB } = await seedTwoDataCentres();
    const moving = await mkVm('kvm-moving', hvB);
    const sitting = await mkVm('kvm-sitting', hvA);

    const outcome = await racePair({
      blockerHost: hvA,
      first: () => call('PUT', `${base}/hypervisors/${hvA}`, { site_id: siteB }),
      firstParksOn: PARK_ON_HV_UPDATE,
      second: () => call('POST', `${base}/placement/apply`, {
        moves: [{ kind: 'vm', id: moving, from: hvB, to: hvA }],
        hostOrders: [{ hostId: hvA, vmIds: [sitting, moving] }],
      }),
      secondParksOn: PARK_ON_HV_ANCHOR,
    });
    assertNoCycle(outcome, 'hypervisor PUT granted the host first, against a reordering Save');

    const row = await storedVm(moving);
    assert.equal(row.hypervisor_id, hvA);
    assert.equal(row.site_id, siteB);
  });

  test('a Save that moves a KVM OFF the edited host does not contend at all', async (t) => {
    if (guard(t)) return;
    // THE BOUND ON THE RESIDUAL, and the reason it is one condition rather than
    // "the placement Save is unsafe". The Save's reference probe targets the
    // host it is moving ONTO; when that is not the host being edited, the two
    // writers never want the same row and the Save runs straight through while
    // the edit is still blocked.
    const { siteB, hvA, hvB } = await seedTwoDataCentres();
    const vmId = await mkVm('kvm1', hvA);

    pending.length = 0;
    driverErrors.length = 0;
    const blocker = await pool.getConnection();
    let editRes;
    let saveRes;
    try {
      await blocker.beginTransaction();
      await blocker.query(`SELECT id FROM \`${tbl('cap_hypervisors')}\` WHERE id = ? FOR UPDATE`, [hvA]);
      const pEdit = call('PUT', `${base}/hypervisors/${hvA}`, { site_id: siteB });
      assert.ok(await waitParked(PARK_ON_HV_UPDATE), 'the host edit never parked');
      // Awaited to completion BEFORE the blocker releases: if it needed anything
      // the edit is holding, this would not return.
      saveRes = await call('POST', `${base}/placement/apply`, {
        moves: [{ kind: 'vm', id: vmId, from: hvA, to: hvB }],
      });
      await blocker.rollback();
      editRes = await pEdit;
    } finally {
      blocker.release();
    }
    assert.equal(saveRes.status, 200, `the Save was refused: ${JSON.stringify(saveRes.body)}`);
    assert.equal(editRes.status, 200, `the host edit was refused: ${JSON.stringify(editRes.body)}`);
    assert.deepEqual(driverErrors.filter((e) => e.errno === 1213), [], 'a cycle formed on a pair that shares no row');

    const row = await storedVm(vmId);
    assert.equal(row.hypervisor_id, hvB, 'the KVM did not move');
  });
});

describe('a mixed vm+instance batch takes cap_hypervisors, cap_db_instances and cap_vms in one Save', () => {
  // F2: the lock-order fix anchors `cap_hypervisors` ahead of the moved-row
  // loop, and a `cap_db_instances` move is locked further below, IN that loop
  // — the one pair (db_instances, hypervisors) the anchor takes out of
  // reference-integrity.js's full canonical order (see the INVARIANT comment
  // in placement-apply.js). No prior case in this file drove both move kinds
  // in the SAME batch; this pins that the pairing is safe today.
  test('completes without 1213/1205 and writes both moves', async (t) => {
    if (guard(t)) return;
    const { hvA, hvB } = await seedTwoDataCentres();
    const vmId = await mkVm('kvm-1', hvA);
    const dbHostA = await mkDbHostVm('db-host-a', hvA);
    const dbHostB = await mkDbHostVm('db-host-b', hvB);
    const instanceId = crypto.randomUUID();
    await q(
      `INSERT INTO \`${tbl('cap_db_instances')}\` (id, scenario_id, vm_id, name, role) VALUES (?,?,?,?,?)`,
      [instanceId, SCENARIO_ID, dbHostA, 'orders-db', 'primary'],
    );

    pending.length = 0;
    driverErrors.length = 0;
    const res = await call('POST', `${base}/placement/apply`, {
      moves: [
        { kind: 'vm', id: vmId, from: hvA, to: hvB },
        { kind: 'instance', id: instanceId, from: dbHostA, to: dbHostB },
      ],
    });

    assert.equal(res.status, 200, `the mixed Save was refused: ${JSON.stringify(res.body)}`);
    assert.deepEqual(driverErrors.filter((e) => e.errno === 1213), [], 'a cycle formed on the mixed batch');
    assert.deepEqual(driverErrors.filter((e) => e.errno === 1205), [], 'a lock wait formed on the mixed batch');

    const vmRow = await storedVm(vmId);
    assert.equal(vmRow.hypervisor_id, hvB, 'the KVM did not move');
    const instRow = await one(`SELECT vm_id FROM \`${tbl('cap_db_instances')}\` WHERE id = ?`, [instanceId]);
    assert.equal(instRow.vm_id, dbHostB, 'the database instance did not move');
  });
});

test('the two handlers price a lost lock race the same way', async (t) => {
  if (guard(t)) return;
  // F1: the old version of this test grepped both files for the errno
  // condition and the string 'WRITE_CONFLICT' — a copy of the SHAPE, not the
  // VALUE, so a message edit on one side could drift from the other and this
  // test would still pass. placement-apply.js now imports and calls
  // crud-factory's writeConflictError directly (no re-declared errno set),
  // so this drives a REAL request through the router with the driver forced
  // to raise errno 1213 at the moved-row lock, and compares the handler's
  // actual JSON response against the SAME live function's own output — a
  // change to the factory's status/code/message is inherited here, not
  // hand-copied, and going stale here is therefore impossible by construction.
  const { hvA } = await seedTwoDataCentres();
  const vmId = await mkVm('kvm1', hvA);
  const movedRowLock = new RegExp(`^SELECT id AS stored_id.*FROM \`${tbl('cap_vms')}\` WHERE id = \\? FOR UPDATE`);
  injectedFault = { re: movedRowLock, errno: 1213, tripped: false };
  let res;
  try {
    res = await call('POST', `${base}/placement/apply`, {
      moves: [{ kind: 'vm', id: vmId, from: hvA, to: null }],
    });
  } finally {
    injectedFault = null;
  }
  assert.ok(driverErrors.some((e) => e.errno === 1213), 'the injected fault never reached the driver call');

  const expected = writeConflictError({ errno: 1213 });
  assert.equal(res.status, expected.status, `expected the factory's 409, got ${res.status}: ${JSON.stringify(res.body)}`);
  // `meta.timestamp` is generated fresh by each call (apiError's own
  // `new Date().toISOString()`), so it is the one field this comparison must
  // NOT hold two independently-generated responses to — everything else in
  // the body must be byte-identical to what the factory itself produces.
  const strip = (body) => ({ ...body, meta: { ...body.meta, timestamp: undefined } });
  assert.deepEqual(
    strip(res.body), strip(expected.body),
    'placement-apply must answer the SAME body writeConflictError produces, not a hand-copied one',
  );
});

describe('the harness itself', () => {
  test('can see a deadlock when there is one', async (t) => {
    if (guard(t)) return;
    // WITHOUT THIS THE no-cycle CASES ARE UNFALSIFIABLE. They assert that no
    // errno 1213 was recorded, which is also what an instrument that records
    // nothing would report. Two plain transactions taking one row each and then
    // reaching for the other's is a guaranteed cycle; the recorder must catch
    // it, on the same pool and through the same wrapper.
    const { hvA, hvB } = await seedTwoDataCentres();
    pending.length = 0;
    driverErrors.length = 0;
    const a = instrument(await pool.getConnection());
    const b = instrument(await pool.getConnection());
    try {
      await a.beginTransaction();
      await b.beginTransaction();
      await a.query(`SELECT id FROM \`${tbl('cap_hypervisors')}\` WHERE id = ? FOR UPDATE`, [hvA]);
      await b.query(`SELECT id FROM \`${tbl('cap_hypervisors')}\` WHERE id = ? FOR UPDATE`, [hvB]);
      const wantB = a.query(`SELECT id FROM \`${tbl('cap_hypervisors')}\` WHERE id = ? FOR UPDATE`, [hvB])
        .catch(() => null);
      const wantA = b.query(`SELECT id FROM \`${tbl('cap_hypervisors')}\` WHERE id = ? FOR UPDATE`, [hvA])
        .catch(() => null);
      await Promise.all([wantB, wantA]);
    } finally {
      try { await a.rollback(); } catch { /* the victim is already rolled back */ }
      try { await b.rollback(); } catch { /* the victim is already rolled back */ }
      a.release();
      b.release();
    }
    assert.equal(
      driverErrors.filter((e) => e.errno === 1213).length, 1,
      'the instrument recorded no deadlock for a cycle that is guaranteed to produce one',
    );
  });
});

// ── A pin write vs the deletion of the site it pins ─────────────────────────
//
// site-references.js refuses to delete a site while a rule pins to it, but a pin
// COMMITTED after the delete's reference sweep has read cap_rules yet before the
// site row is removed would slip past — the exact window makeRuleSitePinLockValidator
// (children.js) closes by taking the pinned cap_sites row FOR UPDATE, the SAME row
// the delete already holds. The pin probe and the delete's row lock contend, so the
// two serialise.

// The pin write's FOR UPDATE probe of the site row (reference-integrity.js's own
// projection shape — `SELECT id, scenario_id, (scenario_id = ?) AS same_scenario`),
// anchored on that head rather than the bare `WHERE id = ? FOR UPDATE` tail so it
// cannot be confused with the delete's own row-lock read (`SELECT id, name AS
// entity_name ... WHERE id = ? AND scenario_id = ? FOR UPDATE`), which carries a
// different projection and a two-column predicate.
const PARK_ON_SITE_PIN_LOCK = new RegExp(
  `^SELECT id, scenario_id.*FROM \`${tbl('cap_sites')}\` WHERE id = \\? FOR UPDATE`,
);
// The delete's LAST statement before commit — reached only after it holds the
// cap_sites row (its own FOR UPDATE read) and its reference sweep has passed.
const GATE_ON_SITE_DELETE = new RegExp(
  `^DELETE FROM \`${tbl('cap_sites')}\` WHERE id = \\? AND scenario_id = \\?`,
);

describe('a rule pinning a site, against that site being deleted', () => {
  test('the pin write serialises on the site row and never lands a dangling reference', async (t) => {
    if (guard(t)) return;
    // A bare site, no placements, so the delete has nothing to cascade and reaches
    // its final DELETE directly — the gate holds it there, holding the cap_sites
    // row FOR UPDATE with the reference sweep already passed (no pin seen).
    //
    // REVERT PROBE (run for real): remove makeRuleSitePinLockValidator from the
    // rules mount and the pin write takes NO cap_sites lock — it never parks, so
    // `parked` is false and this test goes red; were the assert skipped, the write
    // would commit its pin and the delete would commit too, leaving the dangling
    // pin the final assertion refuses.
    const site = await call('POST', `${base}/sites`, { name: 'DC-PIN' });
    assert.ok(site.status === 200 || site.status === 201, `the site fixture was refused: ${JSON.stringify(site.body)}`);
    const siteId = site.body.data.id;

    pending.length = 0;
    driverErrors.length = 0;
    const g = armGate(GATE_ON_SITE_DELETE);
    const pDelete = call('DELETE', `${base}/sites/${siteId}`);
    let pWrite = null;
    let delRes; let writeRes;
    try {
      const parkedDelete = await Promise.race([g.reached.then(() => true), pDelete.then(() => false)]);
      assert.ok(parkedDelete, 'the delete finished without reaching its final DELETE — nothing was forced');

      pWrite = call('POST', `${base}/rules`, {
        type: 'keep-in-one-site', name: 'RACE-PIN', level: 'db_instance',
        group_by: 'each_primary_cluster', params: { site_id: siteId }, severity: 'hard',
      });
      // The write must PARK on the site row (it takes the FOR UPDATE lock the
      // delete holds). A false here is the revert-probe signal that the pin took no
      // lock; the finally releases the gate either way, so a failure cannot hang the
      // parked delete.
      const parked = await waitParked(PARK_ON_SITE_PIN_LOCK);
      assert.ok(parked,
        'the pin write never parked on the site row — it took no FOR UPDATE lock, so the pin-vs-delete race is open');
    } finally {
      g.release();
      delRes = await pDelete;
      if (pWrite) writeRes = await pWrite;
    }

    assert.deepEqual(driverErrors.filter((e) => e.errno === 1213).map((e) => e.sql), [],
      'InnoDB raised errno 1213 — the pin write and the delete claim the row in opposite orders');
    assert.deepEqual(driverErrors.filter((e) => e.errno === 1205).map((e) => e.sql), [],
      'errno 1205 — a writer waited out the lock timeout instead of proceeding once the delete committed');
    // The delete holds the row and commits first; the pin write, unblocked onto a
    // now-deleted site, is refused. Never both-succeed.
    assert.equal(delRes.status, 200, `the delete was refused: ${JSON.stringify(delRes.body)}`);
    assert.equal(writeRes.status, 400, `the pin write was not refused onto the deleted site: ${JSON.stringify(writeRes.body)}`);

    // Stated as the DB's own state so this cannot pass on a coincidence: the site
    // is gone AND nothing pins to it.
    const sites = await one(`SELECT COUNT(*) AS c FROM \`${tbl('cap_sites')}\` WHERE id = ?`, [siteId]);
    assert.equal(Number(sites.c), 0, 'the delete did not remove the site');
    const pins = await one(
      `SELECT COUNT(*) AS c FROM \`${tbl('cap_rules')}\` WHERE JSON_VALID(params) AND JSON_CONTAINS(params, JSON_QUOTE(?), '$.site_id')`,
      [siteId],
    );
    assert.equal(Number(pins.c), 0, 'a pin survived pointing at the deleted site — the race left a dangling reference');
  });
});
