/**
 * blueprint-import-roundtrip.test.js
 *
 * Proves the blueprint IMPORT routes carry ALL real columns of
 * blueprint_fields / field_options via buildPortableInsert, instead of the
 * old hard-coded column list that silently dropped any column added later
 * (e.g. the v3.2.129 cascade columns depends_on_field_key /
 * valid_parent_values).
 *
 * Covers BOTH import surfaces:
 *   - JSON import: POST /edge/app/schema/blueprint-import (mode=new path)
 *   - YAML import: POST /edge/app/schema/blueprint-import-yaml (mode=new path)
 *   - YAML import: POST /edge/app/schema/blueprint-import-yaml (mode=overwrite path)
 *
 * The mock connection answers the helper's SELECT DATABASE() + the
 * information_schema.COLUMNS probe (returning the real column set including the
 * cascade columns), captures every issued INSERT, and stubs the validate /
 * parent-check / audit queries each route needs. Probe-answering idiom is
 * modelled on schema-crud-column-gate.test.js.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../src/edge/db');
const { __clearPortableColumnCache } = require('../../src/edge/lib/portable-insert');
const { computeRevision, parseYaml } = require('../../src/edge/lib/blueprint-serialization');

const PREFIX = 'fmb_';
const DB_NAME = 'testdb';

// The real columns the probe reports for each physical table — includes the
// v3.2.129 cascade columns so the portable INSERT must carry them through.
const COLUMN_META = {
  blueprint_fields: [
    'id', 'blueprint_id', 'field_key', 'field_label', 'field_type', 'is_required',
    'default_value', 'placeholder', 'tooltip', 'section', 'group_key', 'matrix_row_key', 'order_index',
    'table_config', 'visibility_rule', 'depends_on_field_key', 'created_at',
    // Blueprint-level policy columns — an import that does not carry them
    // deletes them from the target on every overwrite.
    'value_source', 'value_scope', 'compute_rule',
  ],
  field_options: [
    'id', 'field_id', 'option_label', 'option_value', 'sort_order',
    'valid_parent_values', 'created_at',
  ],
  blueprint_sections: [
    'id', 'blueprint_id', 'section_key', 'display_label', 'icon', 'description',
    'layout_mode', 'matrix_copy', 'sort_order', 'created_at',
  ],
  blueprint_groups: [
    'id', 'blueprint_id', 'group_key', 'display_label', 'color_key', 'sort_order', 'created_at',
  ],
};

// Per-test capture of every INSERT the route hands the driver.
let inserts;

function tableSuffix(physical) {
  return physical.startsWith(PREFIX) ? physical.slice(PREFIX.length) : physical;
}

function makeRwConn() {
  return {
    async query(sql, params) {
      // Helper's database-identity probe.
      if (/^SELECT DATABASE\(\)/i.test(sql)) return [{ db: DB_NAME }];
      // Table-existence probe (tableExistsInCurrentSchema) — this mocked target
      // has the additive blueprint_groups table.
      if (/information_schema\.TABLES/i.test(sql)) return [{ '1': 1 }];
      // Helper's column probe — TABLE_SCHEMA = DATABASE() (no param),
      // TABLE_NAME = ? so params = [physicalTable].
      if (/information_schema\.COLUMNS/i.test(sql)) {
        const physical = params[0];
        const cols = COLUMN_META[tableSuffix(physical)] || [];
        return cols.map((c) => ({ COLUMN_NAME: c }));
      }
      // YAML import: identity-match scan (findIdentityMatches) returns no
      // candidates → drives the mode=new path. Matched first because its query
      // also has `WHERE ... id = ?` in tier 1.
      if (/FROM `fmb_hierarchy_nodes`/i.test(sql) && /node_type = 'blueprint'/i.test(sql)) {
        return [];
      }
      // Parent-validation lookup (validateBlueprintParent): the route checks the
      // target_parent_id resolves to a Release node. Answer with one.
      if (/FROM `fmb_hierarchy_nodes`/i.test(sql) && /WHERE id = \?/i.test(sql)) {
        return [{ id: params[0], node_type: 'release', parent_id: null }];
      }
      // Capture INSERTs; everything else (audit, hierarchy_node, sections,
      // output_order) just succeeds.
      if (/^INSERT INTO/i.test(sql)) {
        const m = sql.match(/INSERT INTO `([^`]+)`/i);
        inserts.push({ table: m ? tableSuffix(m[1]) : '', sql, params });
        return { affectedRows: 1 };
      }
      return [];
    },
    async beginTransaction() {},
    async commit() {},
    async rollback() {},
    release() {},
  };
}

const poolSpy = {
  rw: { async getConnection() { return makeRwConn(); } },
  ro: { async getConnection() { return makeRwConn(); } },
};

require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: {
    pool: poolSpy,
    t: (name) => `${PREFIX}${name}`,
    getDynamicPool: async () => poolSpy,
  },
};

const router = require('../../src/edge/routes/app/blueprint-export');

let server;
let port;

before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { req.user = { id: 'admin-1', role: 'admin' }; next(); });
  app.use('/edge/app/schema', router);
  await new Promise((resolve) => {
    server = app.listen(0, '127.0.0.1', () => { port = server.address().port; resolve(); });
  });
});

after(async () => {
  await new Promise((resolve) => server.close(resolve));
  delete require.cache[dbKey];
});

beforeEach(() => {
  inserts = [];
  __clearPortableColumnCache();
});

function request(method, path, body, contentType) {
  return new Promise((resolve, reject) => {
    const data = typeof body === 'string' ? body : (body !== undefined ? JSON.stringify(body) : '');
    const headers = data
      ? { 'Content-Type': contentType || 'application/json', 'Content-Length': Buffer.byteLength(data) }
      : {};
    const req = http.request({ method, host: '127.0.0.1', port, path, headers }, (res) => {
      let raw = '';
      res.on('data', (chunk) => { raw += chunk; });
      res.on('end', () => {
        let json = null;
        try { json = raw ? JSON.parse(raw) : null; } catch { /* noop */ }
        resolve({ status: res.statusCode, raw, json });
      });
    });
    req.on('error', reject);
    if (data) req.write(data);
    req.end();
  });
}

// A blueprint payload whose cascade columns must survive the import.
function makePayload() {
  return {
    import_version: 1,
    hierarchy_node: { id: 'node-1', name: 'My Blueprint', node_type: 'blueprint' },
    blueprint_fields: [{
      id: 'f1', blueprint_id: 'node-1', field_key: 'trim', field_label: 'Trim',
      field_type: 'select', is_required: 0, section: 'general',
      depends_on_field_key: 'series',
    }],
    field_options: [{
      id: 'o1', field_id: 'f1', option_label: 'Sedan', option_value: 'sedan',
      sort_order: 0, valid_parent_values: ['sedan'],
    }],
    blueprint_sections: [],
    blueprint_output_order: [],
  };
}

// A sparse field payload: the field row omits section/default_value/etc., so the
// portable INSERT must supply the route defaults (section='general') rather than
// leaving the column out → NULL.
function makeSparsePayload() {
  return {
    import_version: 1,
    hierarchy_node: { id: 'node-1', name: 'My Blueprint', node_type: 'blueprint' },
    blueprint_fields: [{
      id: 'f1', blueprint_id: 'node-1', field_key: 'trim', field_label: 'Trim',
      field_type: 'select',
      // intentionally NO section / default_value / placeholder / tooltip / is_required / order_index
    }],
    field_options: [],
    blueprint_sections: [],
    blueprint_output_order: [],
  };
}

// A payload exercising the color-group columns: a group row, a field assigned
// to that group (group_key), and a section with a layout_mode.
function makeGroupPayload() {
  return {
    import_version: 1,
    hierarchy_node: { id: 'node-1', name: 'My Blueprint', node_type: 'blueprint' },
    blueprint_fields: [{
      id: 'f1', blueprint_id: 'node-1', field_key: 'trim', field_label: 'Trim',
      field_type: 'select', is_required: 0, section: 'general', group_key: 'lane_a',
      matrix_row_key: 'row_a',
    }],
    field_options: [],
    blueprint_sections: [{
      id: 's1', blueprint_id: 'node-1', section_key: 'general', display_label: 'General',
      sort_order: 0, layout_mode: 'cards', matrix_copy: 'disabled',
    }],
    blueprint_groups: [{
      id: 'g1', blueprint_id: 'node-1', group_key: 'lane_a', display_label: 'Lane A',
      color_key: 'blue', sort_order: 0,
    }],
    blueprint_output_order: [],
  };
}

function findInsert(table) {
  return inserts.find((i) => i.table === table);
}

function columnIndex(sql, col) {
  const m = sql.match(/INSERT INTO `[^`]+`\s*\(([\s\S]*?)\)/i);
  assert.ok(m, `INSERT must have a column list: ${sql}`);
  const cols = m[1].split(',').map((c) => c.trim().replace(/`/g, ''));
  return cols.indexOf(col);
}

describe('JSON import carries all real columns', () => {
  it('blueprint_fields INSERT names depends_on_field_key with its value', async () => {
    const res = await request(
      'POST',
      '/edge/app/schema/blueprint-import?target_parent_id=rel-1',
      makePayload(),
    );
    assert.equal(res.status, 200, res.raw);

    const bf = findInsert('blueprint_fields');
    assert.ok(bf, 'blueprint_fields INSERT must reach the driver');
    const idx = columnIndex(bf.sql, 'depends_on_field_key');
    assert.notEqual(idx, -1, 'depends_on_field_key must be in the column list');
    assert.equal(bf.params[idx], 'series');
  });

  it('field_options INSERT names valid_parent_values as a JSON string', async () => {
    const res = await request(
      'POST',
      '/edge/app/schema/blueprint-import?target_parent_id=rel-1',
      makePayload(),
    );
    assert.equal(res.status, 200, res.raw);

    const fo = findInsert('field_options');
    assert.ok(fo, 'field_options INSERT must reach the driver');
    const idx = columnIndex(fo.sql, 'valid_parent_values');
    assert.notEqual(idx, -1, 'valid_parent_values must be in the column list');
    assert.equal(fo.params[idx], '["sedan"]');
  });

  it('sparse blueprint_fields row gets section=general from route defaults', async () => {
    const res = await request(
      'POST',
      '/edge/app/schema/blueprint-import?target_parent_id=rel-1',
      makeSparsePayload(),
    );
    assert.equal(res.status, 200, res.raw);

    const bf = findInsert('blueprint_fields');
    assert.ok(bf, 'blueprint_fields INSERT must reach the driver');
    const idx = columnIndex(bf.sql, 'section');
    assert.notEqual(idx, -1, 'section must be in the column list (filled from defaults)');
    assert.equal(bf.params[idx], 'general',
      'a sparse field with no section must default to general, not NULL');
  });

  // Codex P1 (#1004): the hierarchy_node re-insert is a hand-written literal
  // INSERT (not buildPortableInsert), so a new column added elsewhere on the
  // row does not automatically reach it. naming_rule must be named explicitly.
  it('hierarchy_node INSERT carries naming_rule from the payload (five-item-batch NAME-E2)', async () => {
    const payload = makePayload();
    payload.hierarchy_node.naming_rule = '{{trim}}-widget';
    const res = await request(
      'POST',
      '/edge/app/schema/blueprint-import?target_parent_id=rel-1',
      payload,
    );
    assert.equal(res.status, 200, res.raw);

    const hn = findInsert('hierarchy_nodes');
    assert.ok(hn, 'hierarchy_nodes INSERT must reach the driver');
    const idx = columnIndex(hn.sql, 'naming_rule');
    assert.notEqual(idx, -1, 'naming_rule must be in the column list');
    assert.equal(hn.params[idx], '{{trim}}-widget');
  });

  // COLUMN_META has no entry for blueprint_output_order — the probe answers
  // "no columns", so buildPortableInsert returns null and every one of these
  // three sites falls to its literal INSERT. Pins the ER_BAD_FIELD_ERROR
  // regression: a target that predates the `format` column would 500 on this
  // literal if it still named `format` (C2 round-1 X1).
  it('fallback blueprint_output_order INSERT omits format (probe-unavailable path)', async () => {
    const payload = makePayload();
    payload.blueprint_output_order = [{ output_key: 'summary', sort_order: 0, format: 'table' }];
    const res = await request(
      'POST',
      '/edge/app/schema/blueprint-import?target_parent_id=rel-1',
      payload,
    );
    assert.equal(res.status, 200, res.raw);

    const oo = findInsert('blueprint_output_order');
    assert.ok(oo, 'blueprint_output_order INSERT must reach the driver');
    assert.equal(columnIndex(oo.sql, 'format'), -1,
      'fallback literal must not name format when the probe could not confirm the column exists');
    assert.notEqual(columnIndex(oo.sql, 'output_key'), -1);
  });
});

describe('import hands every JSON column to the driver as text', () => {
  // A column listed in the DDL as JSON but not in the caller's jsonColumns list
  // travels as whatever the payload holds. The uploaded JSON document holds an
  // OBJECT, so the driver is handed one where it expects text: the import either
  // fails outright or stores something no reader can parse. `compute_rule` was
  // listed from the day it shipped; `value_scope` arrived beside it and was not,
  // so a cell-scoped field was exactly the payload that broke.
  //
  // The YAML route cannot reach that state — parseYaml stringifies value_scope
  // before the guard ever runs — so the YAML case below pins the contract rather
  // than reproducing the defect. The JSON route is where the object arrives.
  const SCOPE = { rows: [0], columns: ['width'] };

  function makeScopedPayload() {
    return {
      import_version: 1,
      hierarchy_node: { id: 'node-1', name: 'My Blueprint', node_type: 'blueprint' },
      blueprint_fields: [{
        id: 'f1', blueprint_id: 'node-1', field_key: 'grid', field_label: 'Grid',
        field_type: 'table', is_required: 0, section: 'general',
        // The whole point: a JSON column carrying a real object, as a file
        // written by anything other than a MariaDB row dump does.
        value_source: 'locked', value_scope: SCOPE,
      }],
      field_options: [],
      blueprint_sections: [],
      blueprint_output_order: [],
    };
  }

  const SCOPED_YAML = `
import_version: 1
blueprint:
  name: My Blueprint
fields:
  - key: grid
    label: Grid
    type: table
    value_source: locked
    value_scope:
      rows:
        - 0
      columns:
        - width
`;

  it('JSON import stringifies value_scope instead of handing over the object', async () => {
    const res = await request(
      'POST',
      '/edge/app/schema/blueprint-import?target_parent_id=rel-1',
      makeScopedPayload(),
    );
    assert.equal(res.status, 200, res.raw);

    const bf = findInsert('blueprint_fields');
    assert.ok(bf, 'blueprint_fields INSERT must reach the driver');
    const idx = columnIndex(bf.sql, 'value_scope');
    assert.notEqual(idx, -1, 'value_scope must be in the column list');
    assert.equal(typeof bf.params[idx], 'string',
      'MariaDB must receive JSON text, never a JavaScript object');
    assert.deepEqual(JSON.parse(bf.params[idx]), SCOPE, 'and the scope must survive intact');
  });

  it('JSON import keeps the mode beside the scope it narrows', async () => {
    const res = await request(
      'POST',
      '/edge/app/schema/blueprint-import?target_parent_id=rel-1',
      makeScopedPayload(),
    );
    assert.equal(res.status, 200, res.raw);

    const bf = findInsert('blueprint_fields');
    assert.equal(bf.params[columnIndex(bf.sql, 'value_source')], 'locked',
      'a scope stored under a lost mode is the row the write boundary refuses');
  });

  it('YAML mode=new import stores value_scope as text too', async () => {
    const res = await request(
      'POST',
      '/edge/app/schema/blueprint-import-yaml?mode=new&target_parent_id=rel-1',
      SCOPED_YAML,
      'text/yaml',
    );
    assert.equal(res.status, 200, res.raw);

    const bf = findInsert('blueprint_fields');
    assert.ok(bf, 'blueprint_fields INSERT must reach the driver');
    const idx = columnIndex(bf.sql, 'value_scope');
    assert.notEqual(idx, -1, 'value_scope must be in the column list');
    assert.equal(typeof bf.params[idx], 'string');
    assert.deepEqual(JSON.parse(bf.params[idx]), SCOPE);
  });
});

describe('JSON import carries blueprint_groups + field group_key + section layout_mode', () => {
  it('blueprint_groups INSERT carries group_key/display_label/color_key with fresh id + remapped blueprint_id', async () => {
    const res = await request(
      'POST',
      '/edge/app/schema/blueprint-import?target_parent_id=rel-1',
      makeGroupPayload(),
    );
    assert.equal(res.status, 200, res.raw);

    const bg = findInsert('blueprint_groups');
    assert.ok(bg, 'blueprint_groups INSERT must reach the driver');
    assert.equal(bg.params[columnIndex(bg.sql, 'group_key')], 'lane_a');
    assert.equal(bg.params[columnIndex(bg.sql, 'display_label')], 'Lane A');
    assert.equal(bg.params[columnIndex(bg.sql, 'color_key')], 'blue');
    // Fresh id (not the source 'g1') + remapped blueprint_id (not 'node-1').
    assert.notEqual(bg.params[columnIndex(bg.sql, 'id')], 'g1');
    assert.notEqual(bg.params[columnIndex(bg.sql, 'blueprint_id')], 'node-1');
  });

  it('blueprint_fields INSERT carries the field group_key', async () => {
    const res = await request(
      'POST',
      '/edge/app/schema/blueprint-import?target_parent_id=rel-1',
      makeGroupPayload(),
    );
    assert.equal(res.status, 200, res.raw);

    const bf = findInsert('blueprint_fields');
    assert.ok(bf, 'blueprint_fields INSERT must reach the driver');
    const idx = columnIndex(bf.sql, 'group_key');
    assert.notEqual(idx, -1, 'group_key must be in the field column list');
    assert.equal(bf.params[idx], 'lane_a');
  });

  it('blueprint_fields INSERT carries the field matrix_row_key', async () => {
    const res = await request(
      'POST',
      '/edge/app/schema/blueprint-import?target_parent_id=rel-1',
      makeGroupPayload(),
    );
    assert.equal(res.status, 200, res.raw);

    const bf = findInsert('blueprint_fields');
    assert.ok(bf, 'blueprint_fields INSERT must reach the driver');
    const idx = columnIndex(bf.sql, 'matrix_row_key');
    assert.notEqual(idx, -1, 'matrix_row_key must be in the field column list');
    assert.equal(bf.params[idx], 'row_a');
  });

  it('blueprint_sections INSERT carries the section layout_mode', async () => {
    const res = await request(
      'POST',
      '/edge/app/schema/blueprint-import?target_parent_id=rel-1',
      makeGroupPayload(),
    );
    assert.equal(res.status, 200, res.raw);

    const bs = findInsert('blueprint_sections');
    assert.ok(bs, 'blueprint_sections INSERT must reach the driver');
    const idx = columnIndex(bs.sql, 'layout_mode');
    assert.notEqual(idx, -1, 'layout_mode must be in the section column list');
    assert.equal(bs.params[idx], 'cards');
  });

  it('blueprint_sections INSERT carries the section matrix_copy toggle', async () => {
    const res = await request(
      'POST',
      '/edge/app/schema/blueprint-import?target_parent_id=rel-1',
      makeGroupPayload(),
    );
    assert.equal(res.status, 200, res.raw);

    const bs = findInsert('blueprint_sections');
    assert.ok(bs, 'blueprint_sections INSERT must reach the driver');
    const idx = columnIndex(bs.sql, 'matrix_copy');
    assert.notEqual(idx, -1, 'matrix_copy must be in the section column list');
    assert.equal(bs.params[idx], 'disabled');
  });
});

describe('JSON import tolerates a missing blueprint_groups table', () => {
  // This target predates the additive table: the information_schema.TABLES
  // probe answers "absent". A payload carrying groups must skip them silently
  // while the rest of the import still succeeds — never a 1146 crash.
  let savedPool;
  before(() => {
    savedPool = poolSpy.rw;
    poolSpy.rw = {
      async getConnection() {
        const c = makeRwConn();
        const origQuery = c.query;
        c.query = async (sql, params) => {
          if (/information_schema\.TABLES/i.test(sql)) return [];
          return origQuery(sql, params);
        };
        return c;
      },
    };
  });
  after(() => { poolSpy.rw = savedPool; });

  it('skips group rows but still imports fields + sections (no crash)', async () => {
    const res = await request(
      'POST',
      '/edge/app/schema/blueprint-import?target_parent_id=rel-1',
      makeGroupPayload(),
    );
    assert.equal(res.status, 200, res.raw);
    assert.ok(findInsert('blueprint_fields'), 'fields must still import');
    assert.ok(findInsert('blueprint_sections'), 'sections must still import');
    assert.equal(
      findInsert('blueprint_groups'), undefined,
      'no blueprint_groups INSERT may be issued when the table is absent',
    );
  });
});

describe('YAML import carries all real columns', () => {
  // The YAML route uses the friendly nested YAML schema (blueprint/fields/
  // options) which parseYaml transforms into the internal payload. The cascade
  // keys must survive both the parse transform AND the portable INSERT.
  const YAML_BODY = `
import_version: 1
blueprint:
  name: My Blueprint
fields:
  - key: trim
    label: Trim
    type: select
    depends_on_field_key: series
    options:
      - value: sedan
        label: Sedan
        valid_parent_values:
          - sedan
`;

  it('blueprint_fields INSERT names depends_on_field_key with its value', async () => {
    const res = await request(
      'POST',
      '/edge/app/schema/blueprint-import-yaml?mode=new&target_parent_id=rel-1',
      YAML_BODY,
      'text/yaml',
    );
    assert.equal(res.status, 200, res.raw);

    const bf = findInsert('blueprint_fields');
    assert.ok(bf, 'blueprint_fields INSERT must reach the driver');
    const idx = columnIndex(bf.sql, 'depends_on_field_key');
    assert.notEqual(idx, -1, 'depends_on_field_key must be in the column list');
    assert.equal(bf.params[idx], 'series');
  });

  it('field_options INSERT names valid_parent_values as a JSON string', async () => {
    const res = await request(
      'POST',
      '/edge/app/schema/blueprint-import-yaml?mode=new&target_parent_id=rel-1',
      YAML_BODY,
      'text/yaml',
    );
    assert.equal(res.status, 200, res.raw);

    const fo = findInsert('field_options');
    assert.ok(fo, 'field_options INSERT must reach the driver');
    const idx = columnIndex(fo.sql, 'valid_parent_values');
    assert.notEqual(idx, -1, 'valid_parent_values must be in the column list');
    assert.equal(fo.params[idx], '["sedan"]');
  });

  // Codex P1 (#1004): same hand-written hierarchy_node literal INSERT as the
  // JSON route above, on the YAML mode=new path's own copy of it.
  it('hierarchy_node INSERT carries naming_rule from the YAML blueprint block (five-item-batch NAME-E2)', async () => {
    const yamlWithRule = YAML_BODY.replace(
      'blueprint:\n  name: My Blueprint\n',
      'blueprint:\n  name: My Blueprint\n  naming_rule: "{{trim}}-widget"\n',
    );
    const res = await request(
      'POST',
      '/edge/app/schema/blueprint-import-yaml?mode=new&target_parent_id=rel-1',
      yamlWithRule,
      'text/yaml',
    );
    assert.equal(res.status, 200, res.raw);

    const hn = findInsert('hierarchy_nodes');
    assert.ok(hn, 'hierarchy_nodes INSERT must reach the driver');
    const idx = columnIndex(hn.sql, 'naming_rule');
    assert.notEqual(idx, -1, 'naming_rule must be in the column list');
    assert.equal(hn.params[idx], '{{trim}}-widget');
  });

  // Same probe-unavailable fallback as the JSON mode=new site above, on the
  // YAML mode=new route's own literal INSERT (C2 round-1 X1).
  it('fallback blueprint_output_order INSERT omits format (probe-unavailable path)', async () => {
    const yamlWithOutput = YAML_BODY + `
output_order:
  - key: summary
    format: table
`;
    const res = await request(
      'POST',
      '/edge/app/schema/blueprint-import-yaml?mode=new&target_parent_id=rel-1',
      yamlWithOutput,
      'text/yaml',
    );
    assert.equal(res.status, 200, res.raw);

    const oo = findInsert('blueprint_output_order');
    assert.ok(oo, 'blueprint_output_order INSERT must reach the driver');
    assert.equal(columnIndex(oo.sql, 'format'), -1,
      'fallback literal must not name format when the probe could not confirm the column exists');
  });
});

describe('YAML overwrite-import carries all real columns and reuses existing blueprint id', () => {
  // The overwrite path in overwriteBlueprint() uses buildPortableInsert with
  // remap: { blueprint_id: existingId } — the remap differs from mode=new
  // (which generates a fresh uuid). This describe block pins both the cascade
  // column preservation AND the overwrite-remap semantics, so a regression
  // that drops depends_on_field_key / valid_parent_values on overwrites (or
  // accidentally replaces existingId with a fresh uuid) is caught immediately.
  //
  // Route params: mode=overwrite & target_id=<existingId> & expected_revision=<rev>
  //
  // The mock conn must answer every query the overwrite path issues:
  //   findIdentityMatches (Tier 2 name+parent query)
  //   loadRawExport (SELECT * from hierarchy_nodes, blueprint_fields,
  //                  field_options, blueprint_sections, blueprint_output_order)
  //   FOR UPDATE lock on hierarchy_nodes  [inside overwriteBlueprint]
  //   loadRawExport again                 [inside overwriteBlueprint]
  //   INSERT feature_audit (attempt)
  //   SELECT id FROM blueprint_fields     [fetch existing field ids for DELETE]
  //   DELETE field_options WHERE field_id IN (...)
  //   DELETE blueprint_fields WHERE blueprint_id
  //   DELETE blueprint_sections WHERE blueprint_id
  //   DELETE blueprint_output_order WHERE blueprint_id
  //   UPDATE hierarchy_nodes WHERE id = existingId
  //   INSERT blueprint_fields             [via buildPortableInsert — captured]
  //   INSERT field_options                [via buildPortableInsert — captured]
  //   INSERT feature_audit (success)

  const EXISTING_ID = 'existing-bp-uuid-1';
  const EXISTING_FIELD_ID = 'existing-field-uuid-1';

  // The "current" raw export that the mock returns for loadRawExport calls.
  // It must be a valid rawExport so computeRevision() produces a stable hash.
  const CURRENT_RAW = {
    import_version: 1,
    hierarchy_node: {
      id: EXISTING_ID,
      name: 'My Blueprint',
      node_type: 'blueprint',
      parent_id: 'rel-1',
      description: null,
      is_active: 1,
      transformer_id: null,
      transformer_version: null,
      linked_blueprint_id: null,
    },
    blueprint_fields: [{
      id: EXISTING_FIELD_ID,
      blueprint_id: EXISTING_ID,
      field_key: 'trim',
      field_label: 'Trim',
      field_type: 'select',
      is_required: 0,
      default_value: '',
      placeholder: '',
      tooltip: '',
      section: 'general',
      order_index: null,
      table_config: null,
      visibility_rule: null,
      depends_on_field_key: null,
    }],
    field_options: [{
      id: 'existing-opt-uuid-1',
      field_id: EXISTING_FIELD_ID,
      option_label: 'Old Sedan',
      option_value: 'sedan',
      sort_order: 0,
      valid_parent_values: null,
    }],
    blueprint_sections: [],
    blueprint_output_order: [],
    _extensions: {},
  };

  // Pre-compute the revision so it passes the optimistic-lock check.
  const EXPECTED_REVISION = computeRevision(CURRENT_RAW);

  // YAML body with cascade columns that must survive the overwrite.
  const YAML_BODY = `
import_version: 1
blueprint:
  name: My Blueprint
fields:
  - key: trim
    label: Trim
    type: select
    depends_on_field_key: series
    options:
      - value: sedan
        label: Sedan
        valid_parent_values:
          - sedan
`;

  function makeOverwriteConn() {
    return {
      async query(sql, params) {
        // Portable-insert: SELECT DATABASE()
        if (/^SELECT DATABASE\(\)/i.test(sql)) return [{ db: DB_NAME }];
        // Portable-insert: information_schema.COLUMNS probe
        if (/information_schema\.COLUMNS/i.test(sql)) {
          const physical = params[0];
          const cols = COLUMN_META[tableSuffix(physical)] || [];
          return cols.map((c) => ({ COLUMN_NAME: c }));
        }
        // FOR UPDATE lock probe must be matched FIRST (before the wildcard
        // SELECT * queries) — SELECT id FROM hierarchy_nodes ... FOR UPDATE
        if (/FOR UPDATE/i.test(sql)) {
          return [{ id: EXISTING_ID }];
        }
        // loadRawExport: SELECT * FROM hierarchy_nodes WHERE id = ? AND node_type = 'blueprint'
        // Must be checked before Tier-1 (which also has WHERE id = ? AND node_type)
        // because SELECT * is the raw-export probe; SELECT id, parent_id, ... is identity-match.
        if (/SELECT \* FROM `fmb_hierarchy_nodes`/i.test(sql)) {
          return [CURRENT_RAW.hierarchy_node];
        }
        // findIdentityMatches Tier 1 (original_id exact — SELECT id, parent_id, name, created_at)
        if (/WHERE id = \?/i.test(sql) && /node_type = 'blueprint'/i.test(sql)) {
          return [];
        }
        // findIdentityMatches Tier 2 (name + parent_id <=>)
        if (/node_type = 'blueprint'.*name = \?/i.test(sql) || /name = \?.*node_type = 'blueprint'/i.test(sql)) {
          return [{ id: EXISTING_ID, parent_id: 'rel-1', name: 'My Blueprint', created_at: '2024-01-01', match_tier: 'name_parent' }];
        }
        // overwriteBlueprint step 3: SELECT id FROM blueprint_fields WHERE blueprint_id = ?
        // (must be before SELECT * FROM blueprint_fields)
        if (/SELECT id FROM `fmb_blueprint_fields`/i.test(sql)) {
          return [{ id: EXISTING_FIELD_ID }];
        }
        // loadRawExport: SELECT * FROM blueprint_fields WHERE blueprint_id = ?
        if (/SELECT \* FROM `fmb_blueprint_fields`/i.test(sql)) {
          return CURRENT_RAW.blueprint_fields;
        }
        // loadRawExport: SELECT * FROM field_options WHERE field_id IN (...)
        if (/SELECT \* FROM `fmb_field_options`/i.test(sql)) {
          return CURRENT_RAW.field_options;
        }
        // loadRawExport: SELECT * FROM blueprint_sections WHERE blueprint_id = ?
        if (/SELECT \* FROM `fmb_blueprint_sections`/i.test(sql)) {
          return [];
        }
        // loadRawExport: SELECT * FROM blueprint_output_order WHERE blueprint_id = ?
        if (/SELECT \* FROM `fmb_blueprint_output_order`/i.test(sql)) {
          return [];
        }
        // DELETE and UPDATE bookkeeping queries — just succeed
        if (/^DELETE FROM/i.test(sql) || /^UPDATE `fmb_hierarchy_nodes`/i.test(sql)) {
          return { affectedRows: 1 };
        }
        // Capture INSERTs (audit rows + blueprint_fields + field_options)
        if (/^INSERT INTO/i.test(sql)) {
          const m = sql.match(/INSERT INTO `([^`]+)`/i);
          inserts.push({ table: m ? tableSuffix(m[1]) : '', sql, params });
          return { affectedRows: 1 };
        }
        return [];
      },
      async beginTransaction() {},
      async commit() {},
      async rollback() {},
      release() {},
    };
  }

  // Override the pool for the overwrite tests to use the richer mock conn.
  let savedPool;
  before(() => {
    savedPool = poolSpy.rw;
    poolSpy.rw = { async getConnection() { return makeOverwriteConn(); } };
  });
  after(() => {
    poolSpy.rw = savedPool;
  });

  it('blueprint_fields INSERT names depends_on_field_key with its value', async () => {
    const res = await request(
      'POST',
      `/edge/app/schema/blueprint-import-yaml?mode=overwrite&target_id=${EXISTING_ID}&expected_revision=${EXPECTED_REVISION}`,
      YAML_BODY,
      'text/yaml',
    );
    assert.equal(res.status, 200, res.raw);

    const bf = findInsert('blueprint_fields');
    assert.ok(bf, 'blueprint_fields INSERT must reach the driver');
    const idx = columnIndex(bf.sql, 'depends_on_field_key');
    assert.notEqual(idx, -1, 'depends_on_field_key must be in the column list');
    assert.equal(bf.params[idx], 'series');
  });

  it('field_options INSERT names valid_parent_values as a JSON string', async () => {
    const res = await request(
      'POST',
      `/edge/app/schema/blueprint-import-yaml?mode=overwrite&target_id=${EXISTING_ID}&expected_revision=${EXPECTED_REVISION}`,
      YAML_BODY,
      'text/yaml',
    );
    assert.equal(res.status, 200, res.raw);

    const fo = findInsert('field_options');
    assert.ok(fo, 'field_options INSERT must reach the driver');
    const idx = columnIndex(fo.sql, 'valid_parent_values');
    assert.notEqual(idx, -1, 'valid_parent_values must be in the column list');
    assert.equal(fo.params[idx], '["sedan"]');
  });

  // Same probe-unavailable fallback as the two mode=new sites above, on the
  // overwrite path's own literal INSERT (C2 round-1 X1).
  it('fallback blueprint_output_order INSERT omits format (probe-unavailable path)', async () => {
    const yamlWithOutput = YAML_BODY + `
output_order:
  - key: summary
    format: table
`;
    const res = await request(
      'POST',
      `/edge/app/schema/blueprint-import-yaml?mode=overwrite&target_id=${EXISTING_ID}&expected_revision=${EXPECTED_REVISION}`,
      yamlWithOutput,
      'text/yaml',
    );
    assert.equal(res.status, 200, res.raw);

    const oo = findInsert('blueprint_output_order');
    assert.ok(oo, 'blueprint_output_order INSERT must reach the driver');
    assert.equal(columnIndex(oo.sql, 'format'), -1,
      'fallback literal must not name format when the probe could not confirm the column exists');
  });

  it('blueprint_fields INSERT uses the EXISTING blueprint id (overwrite remap)', async () => {
    const res = await request(
      'POST',
      `/edge/app/schema/blueprint-import-yaml?mode=overwrite&target_id=${EXISTING_ID}&expected_revision=${EXPECTED_REVISION}`,
      YAML_BODY,
      'text/yaml',
    );
    assert.equal(res.status, 200, res.raw);

    const bf = findInsert('blueprint_fields');
    assert.ok(bf, 'blueprint_fields INSERT must reach the driver');
    const bpIdx = columnIndex(bf.sql, 'blueprint_id');
    assert.notEqual(bpIdx, -1, 'blueprint_id must be in the column list');
    assert.equal(bf.params[bpIdx], EXISTING_ID,
      'overwrite remap must reuse the existing blueprint id, not a fresh uuid');
  });
});

describe('YAML export → import round trip carries the blueprint policy columns', () => {
  // Codex P1: the export/import pair is the only way an operator moves a
  // blueprint between environments, and mode=overwrite DELETEs every field row
  // and re-INSERTs it from the file. A policy column the file does not carry is
  // therefore not "missing from the export" — it is deleted from the target on
  // every round trip. This block drives both real routes end to end: GET the
  // YAML the export route emits, POST that exact text back as an overwrite, and
  // assert the two policy columns arrive in the re-INSERT with their values.
  const EXISTING_ID = 'policy-bp-uuid-1';
  const SERIES_FIELD_ID = 'policy-field-uuid-1';
  const TRIM_FIELD_ID = 'policy-field-uuid-2';

  const RULE = {
    op: 'transform',
    overridable: false,
    output_type: 'string',
    config: { source: 'series', transform: 'upper' },
  };

  const CURRENT_RAW = {
    import_version: 1,
    hierarchy_node: {
      id: EXISTING_ID,
      name: 'Policy Blueprint',
      node_type: 'blueprint',
      parent_id: 'rel-1',
      description: null,
      is_active: 1,
      transformer_id: null,
      transformer_version: null,
      linked_blueprint_id: null,
    },
    blueprint_fields: [
      {
        id: SERIES_FIELD_ID, blueprint_id: EXISTING_ID,
        field_key: 'series', field_label: 'Series', field_type: 'text',
        is_required: 0, default_value: '', placeholder: '', tooltip: '',
        section: 'general', order_index: 0,
        table_config: null, visibility_rule: null, depends_on_field_key: null,
        // The locked field: the operator's "nobody may override this" decision.
        value_source: 'locked', value_scope: null, compute_rule: null,
      },
      {
        id: TRIM_FIELD_ID, blueprint_id: EXISTING_ID,
        field_key: 'trim', field_label: 'Trim', field_type: 'text',
        is_required: 0, default_value: '', placeholder: '', tooltip: '',
        section: 'general', order_index: 1,
        table_config: null, visibility_rule: null, depends_on_field_key: null,
        value_source: 'calculated', value_scope: null, compute_rule: JSON.stringify(RULE),
      },
    ],
    field_options: [],
    blueprint_sections: [],
    blueprint_output_order: [],
    _extensions: {},
  };

  const EXPECTED_REVISION = computeRevision(CURRENT_RAW);

  function makePolicyConn() {
    return {
      async query(sql, params) {
        if (/^SELECT DATABASE\(\)/i.test(sql)) return [{ db: DB_NAME }];
        if (/information_schema\.COLUMNS/i.test(sql)) {
          const physical = params[0];
          const cols = COLUMN_META[tableSuffix(physical)] || [];
          return cols.map((c) => ({ COLUMN_NAME: c }));
        }
        if (/FOR UPDATE/i.test(sql)) return [{ id: EXISTING_ID }];
        if (/SELECT \* FROM `fmb_hierarchy_nodes`/i.test(sql)) return [CURRENT_RAW.hierarchy_node];
        if (/WHERE id = \?/i.test(sql) && /node_type = 'blueprint'/i.test(sql)) return [];
        if (/node_type = 'blueprint'.*name = \?/i.test(sql) || /name = \?.*node_type = 'blueprint'/i.test(sql)) {
          return [{ id: EXISTING_ID, parent_id: 'rel-1', name: 'Policy Blueprint', created_at: '2024-01-01' }];
        }
        // validateBlueprintParent (mode=new): target_parent_id must resolve to
        // a Release node.
        if (/FROM `fmb_hierarchy_nodes`/i.test(sql) && /WHERE id = \?/i.test(sql)) {
          return [{ id: params[0], node_type: 'release', parent_id: null }];
        }
        if (/SELECT id FROM `fmb_blueprint_fields`/i.test(sql)) {
          return CURRENT_RAW.blueprint_fields.map((f) => ({ id: f.id }));
        }
        if (/SELECT \* FROM `fmb_blueprint_fields`/i.test(sql)) return CURRENT_RAW.blueprint_fields;
        if (/SELECT \* FROM `fmb_field_options`/i.test(sql)) return [];
        if (/SELECT \* FROM `fmb_blueprint_sections`/i.test(sql)) return [];
        if (/SELECT \* FROM `fmb_blueprint_output_order`/i.test(sql)) return [];
        if (/^DELETE FROM/i.test(sql) || /^UPDATE `fmb_hierarchy_nodes`/i.test(sql)) {
          return { affectedRows: 1 };
        }
        if (/^INSERT INTO/i.test(sql)) {
          const m = sql.match(/INSERT INTO `([^`]+)`/i);
          inserts.push({ table: m ? tableSuffix(m[1]) : '', sql, params });
          return { affectedRows: 1 };
        }
        return [];
      },
      async beginTransaction() {},
      async commit() {},
      async rollback() {},
      release() {},
    };
  }

  let savedRw;
  let savedRo;
  before(() => {
    savedRw = poolSpy.rw;
    savedRo = poolSpy.ro;
    poolSpy.rw = { async getConnection() { return makePolicyConn(); } };
    poolSpy.ro = { async getConnection() { return makePolicyConn(); } };
  });
  after(() => {
    poolSpy.rw = savedRw;
    poolSpy.ro = savedRo;
  });

  function fieldInsertFor(key) {
    return inserts.filter((i) => i.table === 'blueprint_fields').find((i) => {
      const idx = columnIndex(i.sql, 'field_key');
      return idx !== -1 && i.params[idx] === key;
    });
  }

  async function exportYaml() {
    const res = await request('GET', `/edge/app/schema/blueprint-export-yaml/${EXISTING_ID}`);
    assert.equal(res.status, 200, res.raw);
    return res.raw;
  }

  it('the exported YAML names both policies', async () => {
    const yamlText = await exportYaml();
    assert.match(yamlText, /value_source:\s*locked/, 'a locked field must export its mode');
    assert.match(yamlText, /compute_rule:/, 'a computed field must export its rule');
  });

  it('overwrite re-INSERT carries value_source and compute_rule from the file', async () => {
    const yamlText = await exportYaml();
    const res = await request(
      'POST',
      `/edge/app/schema/blueprint-import-yaml?mode=overwrite&target_id=${EXISTING_ID}&expected_revision=${EXPECTED_REVISION}`,
      yamlText,
      'text/yaml',
    );
    assert.equal(res.status, 200, res.raw);

    const series = fieldInsertFor('series');
    assert.ok(series, 'the locked field must be re-inserted');
    const lockIdx = columnIndex(series.sql, 'value_source');
    assert.notEqual(lockIdx, -1, 'value_source must be in the overwrite column list');
    assert.equal(series.params[lockIdx], 'locked', 'overwrite must not silently unlock the field');

    const trim = fieldInsertFor('trim');
    assert.ok(trim, 'the computed field must be re-inserted');
    const ruleIdx = columnIndex(trim.sql, 'compute_rule');
    assert.notEqual(ruleIdx, -1, 'compute_rule must be in the overwrite column list');
    assert.deepEqual(JSON.parse(trim.params[ruleIdx]), RULE,
      'overwrite must not silently drop the stored compute rule');
  });

  it('mode=new import carries both policies too', async () => {
    const yamlText = await exportYaml();
    const res = await request(
      'POST',
      '/edge/app/schema/blueprint-import-yaml?mode=new&target_parent_id=rel-1',
      yamlText,
      'text/yaml',
    );
    assert.equal(res.status, 200, res.raw);
    const series = fieldInsertFor('series');
    assert.equal(series.params[columnIndex(series.sql, 'value_source')], 'locked');
    const trim = fieldInsertFor('trim');
    assert.deepEqual(JSON.parse(trim.params[columnIndex(trim.sql, 'compute_rule')]), RULE);
  });

  it('a compute rule arriving through YAML is validated, not waved through', async () => {
    const yamlText = (await exportYaml()).replace('source: series', 'source: no_such_field');
    const res = await request(
      'POST',
      `/edge/app/schema/blueprint-import-yaml?mode=overwrite&target_id=${EXISTING_ID}&expected_revision=${EXPECTED_REVISION}`,
      yamlText,
      'text/yaml',
    );
    assert.equal(res.status, 400, res.raw);
    assert.match(JSON.stringify(res.json.validation_errors || []), /missing_source/);
    assert.equal(inserts.filter((i) => i.table === 'blueprint_fields').length, 0,
      'a rejected import must not write any field row');
  });
});

describe('hierarchy_node naming_rule degrades on a pre-migration target (Codex r2 fmb-1890)', () => {
  // The warn-severity naming_rule migration is skipped when the operator has
  // no DDL grants — the column is then PHYSICALLY ABSENT, and a hand-written
  // SQL string naming it unconditionally 500s with ER_BAD_FIELD_ERROR. These
  // real columns mirror table-ddls.js hierarchy_nodes MINUS naming_rule, i.e.
  // exactly what a pre-migration target's information_schema probe reports.
  const HN_COLS_WITH_RULE = [
    'id', 'parent_id', 'name', 'description', 'node_type', 'sort_order', 'is_active',
    'transformer_id', 'transformer_version', 'linked_blueprint_id', 'naming_rule',
    'created_at', 'updated_at',
  ];
  const HN_COLS_WITHOUT_RULE = HN_COLS_WITH_RULE.filter((c) => c !== 'naming_rule');

  function makeRwConnWithHnCols(hnCols) {
    const c = makeRwConn();
    const orig = c.query;
    c.query = async (sql, params) => {
      if (/information_schema\.COLUMNS/i.test(sql) && tableSuffix(params[0]) === 'hierarchy_nodes') {
        return hnCols.map((col) => ({ COLUMN_NAME: col }));
      }
      return orig(sql, params);
    };
    return c;
  }

  describe('JSON import (mode=new)', () => {
    it('post-migration: naming_rule is carried in the hierarchy_nodes INSERT', async () => {
      const savedRw = poolSpy.rw;
      poolSpy.rw = { async getConnection() { return makeRwConnWithHnCols(HN_COLS_WITH_RULE); } };
      try {
        const payload = makePayload();
        payload.hierarchy_node.naming_rule = '{{trim}}-widget';
        const res = await request('POST', '/edge/app/schema/blueprint-import?target_parent_id=rel-1', payload);
        assert.equal(res.status, 200, res.raw);
        const hn = findInsert('hierarchy_nodes');
        assert.ok(hn, 'hierarchy_nodes INSERT must reach the driver');
        const idx = columnIndex(hn.sql, 'naming_rule');
        assert.notEqual(idx, -1, 'naming_rule must be in the column list when the target has the column');
        assert.equal(hn.params[idx], '{{trim}}-widget');
      } finally {
        poolSpy.rw = savedRw;
      }
    });

    it('pre-migration: naming_rule is omitted from the hierarchy_nodes INSERT and the import still succeeds', async () => {
      const savedRw = poolSpy.rw;
      poolSpy.rw = { async getConnection() { return makeRwConnWithHnCols(HN_COLS_WITHOUT_RULE); } };
      try {
        const payload = makePayload();
        payload.hierarchy_node.naming_rule = '{{trim}}-widget';
        const res = await request('POST', '/edge/app/schema/blueprint-import?target_parent_id=rel-1', payload);
        assert.equal(res.status, 200, res.raw);
        const hn = findInsert('hierarchy_nodes');
        assert.ok(hn, 'hierarchy_nodes INSERT must still reach the driver');
        assert.equal(columnIndex(hn.sql, 'naming_rule'), -1,
          'naming_rule must be omitted when the target column is physically absent');
      } finally {
        poolSpy.rw = savedRw;
      }
    });
  });

  describe('YAML mode=new', () => {
    const YAML_WITH_RULE = `
import_version: 1
blueprint:
  name: My Blueprint
  naming_rule: "{{trim}}-widget"
`;

    it('post-migration: naming_rule is carried in the hierarchy_nodes INSERT', async () => {
      const savedRw = poolSpy.rw;
      poolSpy.rw = { async getConnection() { return makeRwConnWithHnCols(HN_COLS_WITH_RULE); } };
      try {
        const res = await request(
          'POST',
          '/edge/app/schema/blueprint-import-yaml?mode=new&target_parent_id=rel-1',
          YAML_WITH_RULE,
          'text/yaml',
        );
        assert.equal(res.status, 200, res.raw);
        const hn = findInsert('hierarchy_nodes');
        assert.ok(hn, 'hierarchy_nodes INSERT must reach the driver');
        const idx = columnIndex(hn.sql, 'naming_rule');
        assert.notEqual(idx, -1, 'naming_rule must be in the column list when the target has the column');
        assert.equal(hn.params[idx], '{{trim}}-widget');
      } finally {
        poolSpy.rw = savedRw;
      }
    });

    it('pre-migration: naming_rule is omitted from the hierarchy_nodes INSERT and the import still succeeds', async () => {
      const savedRw = poolSpy.rw;
      poolSpy.rw = { async getConnection() { return makeRwConnWithHnCols(HN_COLS_WITHOUT_RULE); } };
      try {
        const res = await request(
          'POST',
          '/edge/app/schema/blueprint-import-yaml?mode=new&target_parent_id=rel-1',
          YAML_WITH_RULE,
          'text/yaml',
        );
        assert.equal(res.status, 200, res.raw);
        const hn = findInsert('hierarchy_nodes');
        assert.ok(hn, 'hierarchy_nodes INSERT must still reach the driver');
        assert.equal(columnIndex(hn.sql, 'naming_rule'), -1,
          'naming_rule must be omitted when the target column is physically absent');
      } finally {
        poolSpy.rw = savedRw;
      }
    });
  });

  describe('YAML mode=overwrite', () => {
    // A minimal overwrite fixture: no fields, so the mock only has to answer
    // the hierarchy_node identity/lock/raw-export queries and the root UPDATE.
    const EXISTING_ID = 'naming-rule-overwrite-uuid-1';
    const CURRENT_RAW = {
      import_version: 1,
      hierarchy_node: {
        id: EXISTING_ID, name: 'My Blueprint', node_type: 'blueprint', parent_id: 'rel-1',
        description: null, is_active: 1, transformer_id: null, transformer_version: null,
        linked_blueprint_id: null, naming_rule: null,
      },
      blueprint_fields: [], field_options: [], blueprint_sections: [], blueprint_output_order: [],
      _extensions: {},
    };
    const EXPECTED_REVISION = computeRevision(CURRENT_RAW);
    const YAML_WITH_RULE = `
import_version: 1
blueprint:
  name: My Blueprint
  naming_rule: "{{trim}}-widget"
`;

    function makeOverwriteConnWithHnCols(hnCols) {
      const updates = [];
      const conn = {
        async query(sql, params) {
          if (/^SELECT DATABASE\(\)/i.test(sql)) return [{ db: DB_NAME }];
          if (/information_schema\.COLUMNS/i.test(sql)) {
            const physical = params[0];
            if (tableSuffix(physical) === 'hierarchy_nodes') {
              return hnCols.map((c) => ({ COLUMN_NAME: c }));
            }
            const cols = COLUMN_META[tableSuffix(physical)] || [];
            return cols.map((c) => ({ COLUMN_NAME: c }));
          }
          if (/FOR UPDATE/i.test(sql)) return [{ id: EXISTING_ID }];
          if (/SELECT \* FROM `fmb_hierarchy_nodes`/i.test(sql)) return [CURRENT_RAW.hierarchy_node];
          // The root UPDATE also contains "WHERE id = ?" and "node_type = 'blueprint'",
          // so it must be matched (and captured) BEFORE the identity-match Tier-1
          // probe below, which would otherwise swallow it silently.
          if (/^UPDATE `fmb_hierarchy_nodes`/i.test(sql)) {
            updates.push({ sql, params });
            return { affectedRows: 1 };
          }
          if (/WHERE id = \?/i.test(sql) && /node_type = 'blueprint'/i.test(sql)) return [];
          if (/node_type = 'blueprint'.*name = \?/i.test(sql) || /name = \?.*node_type = 'blueprint'/i.test(sql)) {
            return [{ id: EXISTING_ID, parent_id: 'rel-1', name: 'My Blueprint', created_at: '2024-01-01' }];
          }
          if (/SELECT id FROM `fmb_blueprint_fields`/i.test(sql)) return [];
          if (/SELECT \* FROM `fmb_blueprint_fields`/i.test(sql)) return [];
          if (/SELECT \* FROM `fmb_field_options`/i.test(sql)) return [];
          if (/SELECT \* FROM `fmb_blueprint_sections`/i.test(sql)) return [];
          if (/SELECT \* FROM `fmb_blueprint_output_order`/i.test(sql)) return [];
          if (/^DELETE FROM/i.test(sql)) return { affectedRows: 0 };
          if (/^INSERT INTO/i.test(sql)) return { affectedRows: 1 };
          return [];
        },
        async beginTransaction() {},
        async commit() {},
        async rollback() {},
        release() {},
      };
      return { conn, updates };
    }

    it('post-migration: naming_rule is carried in the root UPDATE', async () => {
      const savedRw = poolSpy.rw;
      const { conn, updates } = makeOverwriteConnWithHnCols(HN_COLS_WITH_RULE);
      poolSpy.rw = { async getConnection() { return conn; } };
      try {
        const res = await request(
          'POST',
          `/edge/app/schema/blueprint-import-yaml?mode=overwrite&target_id=${EXISTING_ID}&expected_revision=${EXPECTED_REVISION}`,
          YAML_WITH_RULE,
          'text/yaml',
        );
        assert.equal(res.status, 200, res.raw);
        assert.equal(updates.length, 1, 'exactly one root UPDATE must be issued');
        assert.match(updates[0].sql, /naming_rule\s*=\s*\?/, 'SET clause must name naming_rule when the target has the column');
        assert.equal(updates[0].params[updates[0].params.length - 2], '{{trim}}-widget',
          'naming_rule value must be bound second-to-last (before the WHERE id param)');
      } finally {
        poolSpy.rw = savedRw;
      }
    });

    it('pre-migration: naming_rule is omitted from the root UPDATE and the overwrite still succeeds', async () => {
      const savedRw = poolSpy.rw;
      const { conn, updates } = makeOverwriteConnWithHnCols(HN_COLS_WITHOUT_RULE);
      poolSpy.rw = { async getConnection() { return conn; } };
      try {
        const res = await request(
          'POST',
          `/edge/app/schema/blueprint-import-yaml?mode=overwrite&target_id=${EXISTING_ID}&expected_revision=${EXPECTED_REVISION}`,
          YAML_WITH_RULE,
          'text/yaml',
        );
        assert.equal(res.status, 200, res.raw);
        assert.equal(updates.length, 1, 'exactly one root UPDATE must be issued');
        assert.doesNotMatch(updates[0].sql, /naming_rule\s*=\s*\?/,
          'SET clause must not name naming_rule when the target column is physically absent');
      } finally {
        poolSpy.rw = savedRw;
      }
    });
  });
});

describe('parseYaml / JSON import reject a non-string naming_rule (Codex P2 fmb-1890)', () => {
  const BASE_YAML = 'import_version: 1\nblueprint:\n  name: My Blueprint\n';

  it('parseYaml rejects an array', () => {
    assert.throws(
      () => parseYaml(`${BASE_YAML}  naming_rule:\n    - a\n    - b\n`),
      /naming_rule must be a string/,
    );
  });
  it('parseYaml rejects an object', () => {
    assert.throws(
      () => parseYaml(`${BASE_YAML}  naming_rule:\n    x: y\n`),
      /naming_rule must be a string/,
    );
  });
  it('parseYaml rejects a number', () => {
    assert.throws(() => parseYaml(`${BASE_YAML}  naming_rule: 42\n`), /naming_rule must be a string/);
  });
  it('parseYaml accepts null, empty string and a real string', () => {
    assert.equal(parseYaml(`${BASE_YAML}  naming_rule: null\n`).hierarchy_node.naming_rule, '');
    assert.equal(parseYaml(`${BASE_YAML}  naming_rule: ""\n`).hierarchy_node.naming_rule, '');
    assert.equal(parseYaml(`${BASE_YAML}  naming_rule: "{{x}}"\n`).hierarchy_node.naming_rule, '{{x}}');
    assert.equal(parseYaml(BASE_YAML).hierarchy_node.naming_rule, '', 'omitted stays legal, defaults to empty');
  });

  it('YAML import: a non-string naming_rule is a visible 400, not a silent coercion', async () => {
    const res = await request(
      'POST',
      '/edge/app/schema/blueprint-import-yaml?mode=new&target_parent_id=rel-1',
      `${BASE_YAML}  naming_rule:\n    - a\n`,
      'text/yaml',
    );
    assert.equal(res.status, 400, res.raw);
    assert.match(JSON.stringify(res.json), /naming_rule must be a string/);
  });

  it('JSON import: an object naming_rule is rejected with a visible validation error', async () => {
    const payload = makePayload();
    payload.hierarchy_node.naming_rule = { x: 'y' };
    const res = await request('POST', '/edge/app/schema/blueprint-import?target_parent_id=rel-1', payload);
    assert.equal(res.status, 400, res.raw);
    assert.match(JSON.stringify(res.json.validation_errors || []), /naming_rule must be a string/);
    assert.equal(inserts.length, 0, 'a rejected import must not write anything');
  });

  it('JSON import: an array naming_rule is rejected', async () => {
    const payload = makePayload();
    payload.hierarchy_node.naming_rule = ['a', 'b'];
    const res = await request('POST', '/edge/app/schema/blueprint-import?target_parent_id=rel-1', payload);
    assert.equal(res.status, 400, res.raw);
    assert.match(JSON.stringify(res.json.validation_errors || []), /naming_rule must be a string/);
  });

  it('JSON import: a number naming_rule is rejected', async () => {
    const payload = makePayload();
    payload.hierarchy_node.naming_rule = 42;
    const res = await request('POST', '/edge/app/schema/blueprint-import?target_parent_id=rel-1', payload);
    assert.equal(res.status, 400, res.raw);
    assert.match(JSON.stringify(res.json.validation_errors || []), /naming_rule must be a string/);
  });

  it('JSON import: null and a real string naming_rule are accepted', async () => {
    const nullPayload = makePayload();
    nullPayload.hierarchy_node.naming_rule = null;
    const res1 = await request('POST', '/edge/app/schema/blueprint-import?target_parent_id=rel-1', nullPayload);
    assert.equal(res1.status, 200, res1.raw);

    const strPayload = makePayload();
    strPayload.hierarchy_node.naming_rule = '{{trim}}-x';
    const res2 = await request('POST', '/edge/app/schema/blueprint-import?target_parent_id=rel-1', strPayload);
    assert.equal(res2.status, 200, res2.raw);
  });
});
