/**
 * roundtrip-fidelity.test.js
 *
 * SCHEMA-DRIVEN round-trip fidelity guard for blueprint_fields / field_options.
 *
 * Unlike blueprint-import-roundtrip.test.js (which pins specific cascade
 * columns by name), this test derives the column list FROM THE DDL
 * (buildEngineTableDDLs) at runtime. The flow:
 *
 *   1. Parse the generated CREATE TABLE string for each table to get its
 *      real column names (engineTableColumns).
 *   2. Build a source row with a deterministic probe value for EVERY data
 *      column (= all columns minus the STRUCTURAL ones the import path
 *      remaps/excludes).
 *   3. Drive the JSON blueprint-import route (the Task-2 path) so the
 *      portable INSERT is built from the schema-derived probe column set.
 *   4. Assert EVERY data column appears in the issued INSERT — any column
 *      the round-trip path drops fails the test, naming the column.
 *
 * WHY THIS IS DRIFT-PROOF / AUTO-COVERS FUTURE COLUMNS:
 *   The probe column list is parsed from the engine DDL, not hard-coded.
 *   When a developer adds a column to buildEngineTableDDLs (e.g. a new
 *   blueprint_fields column), this test AUTOMATICALLY starts probing for it
 *   — no edit here is needed. If a round-trip path (import wiring, portable
 *   INSERT, or a future refactor) drops that column, this test goes red and
 *   names the missing column. Conversely a path that carries everything
 *   stays green for free as the schema grows.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../src/edge/db');
const { __clearPortableColumnCache } = require('../../src/edge/lib/portable-insert');
const { buildEngineTableDDLs } = require('../../src/table-ddls');

const PREFIX = 'fmb_';
const DB_NAME = 'testdb';

// Columns the import path legitimately remaps or excludes (not "data" the
// caller supplies): primary key, the FK the route rewrites, and the
// server-assigned timestamp. Everything else is a data column that MUST
// round-trip.
const STRUCTURAL = {
  blueprint_fields: ['id', 'blueprint_id', 'created_at'],
  field_options: ['id', 'field_id', 'created_at'],
  blueprint_sections: ['id', 'blueprint_id', 'created_at'],
};

/**
 * Parse the generated engine DDL and return the column-name list for a table.
 *
 * Mechanism: call buildEngineTableDDLs with an identity prefix fn so the
 * physical names equal the base names, find the CREATE TABLE block for the
 * target table, then walk the lines between the first `(` and the matching
 * closing `)` collecting the leading identifier of each column-definition
 * line. Lines that start with a SQL keyword (PRIMARY/UNIQUE/INDEX/KEY/
 * CONSTRAINT/FOREIGN/ENGINE) or a comment are skipped — those are table
 * constraints, not columns. Backtick-quoted names are unwrapped.
 *
 * @param {string} tableName base (unprefixed) table name
 * @returns {string[]} ordered list of column names as written in the DDL
 */
function engineTableColumns(tableName) {
  const ddls = buildEngineTableDDLs((n) => n);
  const re = new RegExp(`CREATE TABLE IF NOT EXISTS \`${tableName}\` \\(`, 'i');
  const ddl = ddls.find((d) => re.test(d));
  assert.ok(ddl, `no DDL found for table ${tableName}`);

  // Slice from the first '(' to the LAST ')' (closes the column list).
  const open = ddl.indexOf('(');
  const close = ddl.lastIndexOf(')');
  const body = ddl.slice(open + 1, close);

  const NON_COLUMN = /^(PRIMARY|UNIQUE|INDEX|KEY|CONSTRAINT|FOREIGN|ENGINE|CHECK)\b/i;
  const cols = [];
  for (const rawLine of body.split('\n')) {
    const line = rawLine.trim();
    if (!line) continue;
    if (line.startsWith('--')) continue; // SQL comment line
    if (NON_COLUMN.test(line)) continue; // table-level constraint, not a column
    // Leading token: optionally backtick-quoted identifier.
    const m = line.match(/^`?([A-Za-z_][A-Za-z0-9_]*)`?\s+/);
    if (!m) continue;
    const name = m[1];
    if (NON_COLUMN.test(name)) continue;
    if (!cols.includes(name)) cols.push(name);
  }
  return cols;
}

/** Data columns = all DDL columns minus the structural ones for that table. */
function dataColumns(tableName) {
  const structural = new Set(STRUCTURAL[tableName]);
  return engineTableColumns(tableName).filter((c) => !structural.has(c));
}

// Probe column sets derived from the DDL — these drive both the mock
// information_schema.COLUMNS answer AND the source-row probe values.
const BF_DDL_COLS = engineTableColumns('blueprint_fields');
const FO_DDL_COLS = engineTableColumns('field_options');
const BS_DDL_COLS = engineTableColumns('blueprint_sections');
const BF_DATA = dataColumns('blueprint_fields');
const FO_DATA = dataColumns('field_options');
const BS_DATA = dataColumns('blueprint_sections');

// JSON columns the route stringifies (must match the route's jsonColumns opt
// so the probe values are shaped sensibly; the assertion below does not depend
// on this list — it only checks column PRESENCE plus the two cascade values).
const JSON_COLS = new Set(['table_config', 'visibility_rule', 'valid_parent_values', 'compute_rule']);

/**
 * Deterministic, type-sane probe value for a column. The exact value rarely
 * matters (we assert presence, not value, for most columns) — but it must be
 * non-undefined so buildPortableInsert keeps the column.
 */
function probeValue(col) {
  if (col === 'is_required') return 1;
  // Columns the import path judges rather than merely copying need a value that
  // passes that judgement, or this probe payload is rejected before any INSERT
  // is issued and the fidelity assertions have nothing to look at.
  if (col === 'value_source') return 'calculated';
  // Shape-faithful but NARROWING NOTHING: the probe field's type is a synthetic
  // string, and a scope that actually addressed cells would be refused on a
  // field that is not a table.
  if (col === 'value_scope') return { columns: [] };
  if (col === 'compute_rule') {
    return {
      op: 'concat', overridable: true, output_type: 'string',
      config: { parts: [{ type: 'literal', text: 'probe' }] },
    };
  }
  // Structurally judged like compute_rule/value_scope, but this fixture
  // ALSO probes depends_on_field_key on the same row — and options_source
  // is mutually exclusive with it (Q1). null still satisfies "column
  // present in the issued INSERT" (the only thing this suite checks for
  // this column) without tripping that refusal.
  if (col === 'options_source') return null;
  if (col === 'order_index' || col === 'sort_order') return 7;
  if (col === 'depends_on_field_key') return 'probe_series';
  if (col === 'valid_parent_values') return ['probe_a'];
  if (col === 'table_config' || col === 'visibility_rule') return { probe: col };
  // Non-default values so the round-trip is observable, not the column default.
  if (col === 'icon') return 'Database';
  if (col === 'description') return 'host params';
  return `probe_${col}`;
}

function makeFieldRow() {
  const row = { id: 'f1', blueprint_id: 'node-1' };
  for (const c of BF_DATA) row[c] = probeValue(c);
  return row;
}

function makeOptionRow() {
  const row = { id: 'o1', field_id: 'f1' };
  for (const c of FO_DATA) row[c] = probeValue(c);
  return row;
}

function makeSectionRow() {
  const row = { id: 's1', blueprint_id: 'node-1' };
  for (const c of BS_DATA) row[c] = probeValue(c);
  return row;
}

let inserts;

function tableSuffix(physical) {
  return physical.startsWith(PREFIX) ? physical.slice(PREFIX.length) : physical;
}

// Probe answers come from the DDL-derived column sets so the portable INSERT
// is allowed to write every schema column.
const PROBE_COLS = {
  blueprint_fields: BF_DDL_COLS,
  field_options: FO_DDL_COLS,
  blueprint_sections: BS_DDL_COLS,
};

function makeRwConn() {
  return {
    async query(sql, params) {
      if (/^SELECT DATABASE\(\)/i.test(sql)) return [{ db: DB_NAME }];
      if (/information_schema\.COLUMNS/i.test(sql)) {
        const physical = params[0];
        const cols = PROBE_COLS[tableSuffix(physical)] || [];
        return cols.map((c) => ({ COLUMN_NAME: c }));
      }
      if (/FROM `fmb_hierarchy_nodes`/i.test(sql) && /node_type = 'blueprint'/i.test(sql)) {
        return [];
      }
      if (/FROM `fmb_hierarchy_nodes`/i.test(sql) && /WHERE id = \?/i.test(sql)) {
        return [{ id: params[0], node_type: 'release', parent_id: null }];
      }
      if (/^INSERT INTO/i.test(sql)) {
        const m = sql.match(/INSERT INTO `([^`]+)`/i);
        inserts.push({ table: m ? tableSuffix(m[1]) : '', sql, params });
        return { affectedRows: 1 };
      }
      return [];
    },
    async beginTransaction() {},
    async commit() {},
    async rollback() {},
    release() {},
  };
}

const poolSpy = {
  rw: { async getConnection() { return makeRwConn(); } },
  ro: { async getConnection() { return makeRwConn(); } },
};

require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: {
    pool: poolSpy,
    t: (name) => `${PREFIX}${name}`,
    getDynamicPool: async () => poolSpy,
  },
};

const router = require('../../src/edge/routes/app/blueprint-export');

let server;
let port;

before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { req.user = { id: 'admin-1', role: 'admin' }; next(); });
  app.use('/edge/app/schema', router);
  await new Promise((resolve) => {
    server = app.listen(0, '127.0.0.1', () => { port = server.address().port; resolve(); });
  });
});

after(async () => {
  await new Promise((resolve) => server.close(resolve));
  delete require.cache[dbKey];
});

beforeEach(() => {
  inserts = [];
  __clearPortableColumnCache();
});

function request(method, path, body) {
  return new Promise((resolve, reject) => {
    const data = body !== undefined ? JSON.stringify(body) : '';
    const headers = data
      ? { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(data) }
      : {};
    const req = http.request({ method, host: '127.0.0.1', port, path, headers }, (res) => {
      let raw = '';
      res.on('data', (chunk) => { raw += chunk; });
      res.on('end', () => {
        let json = null;
        try { json = raw ? JSON.parse(raw) : null; } catch { /* noop */ }
        resolve({ status: res.statusCode, raw, json });
      });
    });
    req.on('error', reject);
    if (data) req.write(data);
    req.end();
  });
}

function makePayload() {
  return {
    import_version: 1,
    hierarchy_node: { id: 'node-1', name: 'My Blueprint', node_type: 'blueprint' },
    blueprint_fields: [makeFieldRow()],
    field_options: [makeOptionRow()],
    blueprint_sections: [makeSectionRow()],
    blueprint_output_order: [],
  };
}

function insertColumns(sql) {
  // Tolerate whitespace/newlines between the table name and the column list so
  // both single-line (portable) and multi-line (fallback) INSERTs parse.
  const m = sql.match(/INSERT INTO `[^`]+`\s*\(([\s\S]*?)\)\s*VALUES/i);
  assert.ok(m, `INSERT must have a column list: ${sql}`);
  return m[1].split(',').map((c) => c.trim().replace(/`/g, ''));
}

function valueOf(insert, col) {
  const idx = insertColumns(insert.sql).indexOf(col);
  return idx === -1 ? undefined : insert.params[idx];
}

describe('schema-driven round-trip fidelity (blueprint import, mode=new)', () => {
  it('blueprint_fields INSERT carries EVERY data column from the DDL', async () => {
    const res = await request(
      'POST',
      '/edge/app/schema/blueprint-import?target_parent_id=rel-1',
      makePayload(),
    );
    assert.equal(res.status, 200, res.raw);

    const bf = inserts.find((i) => i.table === 'blueprint_fields');
    assert.ok(bf, 'blueprint_fields INSERT must reach the driver');
    const written = new Set(insertColumns(bf.sql));

    for (const col of BF_DATA) {
      assert.ok(
        written.has(col),
        `blueprint_fields round-trip DROPPED column "${col}". ` +
        `It exists in the engine DDL but is missing from the issued INSERT ` +
        `(${[...written].join(', ')}). A round-trip path lost a column — fix the ` +
        `import wiring / portable INSERT, do not delete this assertion.`,
      );
    }
  });

  it('field_options INSERT carries EVERY data column from the DDL', async () => {
    const res = await request(
      'POST',
      '/edge/app/schema/blueprint-import?target_parent_id=rel-1',
      makePayload(),
    );
    assert.equal(res.status, 200, res.raw);

    const fo = inserts.find((i) => i.table === 'field_options');
    assert.ok(fo, 'field_options INSERT must reach the driver');
    const written = new Set(insertColumns(fo.sql));

    for (const col of FO_DATA) {
      assert.ok(
        written.has(col),
        `field_options round-trip DROPPED column "${col}". ` +
        `It exists in the engine DDL but is missing from the issued INSERT ` +
        `(${[...written].join(', ')}). A round-trip path lost a column — fix the ` +
        `import wiring / portable INSERT, do not delete this assertion.`,
      );
    }
  });

  it('blueprint_sections INSERT carries EVERY data column from the DDL', async () => {
    const res = await request(
      'POST',
      '/edge/app/schema/blueprint-import?target_parent_id=rel-1',
      makePayload(),
    );
    assert.equal(res.status, 200, res.raw);

    const bs = inserts.find((i) => i.table === 'blueprint_sections');
    assert.ok(bs, 'blueprint_sections INSERT must reach the driver');
    const written = new Set(insertColumns(bs.sql));

    for (const col of BS_DATA) {
      assert.ok(
        written.has(col),
        `blueprint_sections round-trip DROPPED column "${col}". ` +
        `It exists in the engine DDL but is missing from the issued INSERT ` +
        `(${[...written].join(', ')}). A round-trip path lost a column — fix the ` +
        `import wiring / portable INSERT, do not delete this assertion.`,
      );
    }
  });

  it('blueprint_sections icon + description carry their probe VALUES', async () => {
    const res = await request(
      'POST',
      '/edge/app/schema/blueprint-import?target_parent_id=rel-1',
      makePayload(),
    );
    assert.equal(res.status, 200, res.raw);

    const bs = inserts.find((i) => i.table === 'blueprint_sections');
    assert.ok(bs, 'blueprint_sections INSERT must reach the driver');

    assert.equal(
      valueOf(bs, 'icon'), 'Database',
      'icon must carry its probe value through the import',
    );
    assert.equal(
      valueOf(bs, 'description'), 'host params',
      'description must carry its probe value through the import',
    );
  });

  it('field group_key + section layout_mode carry their probe VALUES', async () => {
    const res = await request(
      'POST',
      '/edge/app/schema/blueprint-import?target_parent_id=rel-1',
      makePayload(),
    );
    assert.equal(res.status, 200, res.raw);

    const bf = inserts.find((i) => i.table === 'blueprint_fields');
    const bs = inserts.find((i) => i.table === 'blueprint_sections');
    assert.ok(bf && bs, 'both INSERTs must reach the driver');

    // Additive color-group columns on the parent rows travel like any other
    // schema column via the portable INSERT.
    assert.equal(
      valueOf(bf, 'group_key'), 'probe_group_key',
      'field group_key must carry its probe value through the import',
    );
    assert.equal(
      valueOf(bf, 'matrix_row_key'), 'probe_matrix_row_key',
      'field matrix_row_key must carry its probe value through the import',
    );
    assert.equal(
      valueOf(bs, 'layout_mode'), 'probe_layout_mode',
      'section layout_mode must carry its probe value through the import',
    );
    assert.equal(
      valueOf(bs, 'matrix_copy'), 'probe_matrix_copy',
      'section matrix_copy must carry its probe value through the import',
    );
  });

  it('cascade columns carry their probe VALUES (not just presence)', async () => {
    const res = await request(
      'POST',
      '/edge/app/schema/blueprint-import?target_parent_id=rel-1',
      makePayload(),
    );
    assert.equal(res.status, 200, res.raw);

    const bf = inserts.find((i) => i.table === 'blueprint_fields');
    const fo = inserts.find((i) => i.table === 'field_options');
    assert.ok(bf && fo, 'both INSERTs must reach the driver');

    // depends_on_field_key is a plain string column — value travels verbatim.
    assert.equal(
      valueOf(bf, 'depends_on_field_key'), 'probe_series',
      'depends_on_field_key must carry its probe value through the import',
    );
    // valid_parent_values is a JSON column — route stringifies the array.
    assert.equal(
      valueOf(fo, 'valid_parent_values'), JSON.stringify(['probe_a']),
      'valid_parent_values must carry its probe value (JSON-stringified) through the import',
    );
  });

  it('sanity: DDL parse found a plausible column set', () => {
    // Guards against the DDL-parse silently returning [] (which would make the
    // per-column loops vacuously pass and hide drift). These are intentionally
    // loose lower bounds, not a hard-coded full list.
    assert.ok(BF_DATA.includes('field_key'), 'blueprint_fields data cols must include field_key');
    assert.ok(BF_DATA.includes('depends_on_field_key'), 'blueprint_fields data cols must include depends_on_field_key');
    assert.ok(FO_DATA.includes('option_value'), 'field_options data cols must include option_value');
    assert.ok(FO_DATA.includes('valid_parent_values'), 'field_options data cols must include valid_parent_values');
    assert.ok(BF_DATA.includes('group_key'), 'blueprint_fields data cols must include group_key');
    assert.ok(BF_DATA.includes('matrix_row_key'), 'blueprint_fields data cols must include matrix_row_key');
    assert.ok(BS_DATA.includes('section_key'), 'blueprint_sections data cols must include section_key');
    assert.ok(BS_DATA.includes('icon'), 'blueprint_sections data cols must include icon');
    assert.ok(BS_DATA.includes('description'), 'blueprint_sections data cols must include description');
    assert.ok(BS_DATA.includes('layout_mode'), 'blueprint_sections data cols must include layout_mode');
    assert.ok(BS_DATA.includes('matrix_copy'), 'blueprint_sections data cols must include matrix_copy');
    assert.ok(BF_DATA.length >= 8, `expected >=8 blueprint_fields data cols, got ${BF_DATA.length}`);
    assert.ok(FO_DATA.length >= 3, `expected >=3 field_options data cols, got ${FO_DATA.length}`);
    assert.ok(BS_DATA.length >= 4, `expected >=4 blueprint_sections data cols, got ${BS_DATA.length}`);
  });
});
