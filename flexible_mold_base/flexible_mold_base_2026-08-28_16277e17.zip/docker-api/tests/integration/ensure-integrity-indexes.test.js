/**
 * ensure-integrity-indexes.test.js
 *
 * Integration coverage for the every-boot, OUTSIDE-the-version-gate self-heal
 * paths that survived the baseline reset:
 *   - _ensureIntegrityIndexes / _ensurePublicReadIndexes add missing scope
 *     indexes on an existing DB (idx_blueprint_fields_blueprint,
 *     idx_variant_overrides_field).
 *   - operator-mode (CRUD-only) boot skips DDL cleanly and writes no
 *     db_privilege audit rows.
 *
 * Ported verbatim from the now-deleted run-schema-migrations.test.js (whose
 * legacy-migration describes were obsoleted by the baseline guard). The version-
 * stamp assertion was dropped: the baseline guard now refuses to stamp a
 * no-stamp engine-table fixture, so stamping is exercised by the executor unit
 * tests + Task 7 docker e2e, not here. Auto-detects a reachable MariaDB and
 * t.skip()s gracefully when none is available.
 */
const { test, describe, before, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const net = require('node:net');
const mariadb = require('mariadb');

const {
  configurePool,
  shutdown,
  pool,
  t: tbl,
  ensureInfrastructure,
  runSchemaMigrations,
} = require('../../src/edge/db');

const TEST_PREFIX = 'mig_';

// ── Config auto-detection ────────────────────────────────────────────────────

function parseEnvFile(filePath) {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    const out = {};
    for (const line of content.split('\n')) {
      const m = line.match(/^\s*([A-Z_][A-Z0-9_]*)\s*=\s*(.*)\s*$/);
      if (!m) continue;
      let value = m[2];
      if ((value.startsWith('"') && value.endsWith('"')) ||
          (value.startsWith("'") && value.endsWith("'"))) {
        value = value.slice(1, -1);
      }
      out[m[1]] = value;
    }
    return out;
  } catch {
    return null;
  }
}

function probePort(host, port, timeoutMs = 2000) {
  return new Promise((resolve) => {
    const socket = new net.Socket();
    let done = false;
    const finish = (ok) => {
      if (done) return;
      done = true;
      socket.destroy();
      resolve(ok);
    };
    socket.setTimeout(timeoutMs);
    socket.once('connect', () => finish(true));
    socket.once('timeout', () => finish(false));
    socket.once('error', () => finish(false));
    socket.connect(port, host);
  });
}

async function resolveMariaDbConfig() {
  if (process.env.DB_TEST_HOST && process.env.DB_TEST_ROOT_PASSWORD) {
    return {
      host: process.env.DB_TEST_HOST,
      port: parseInt(process.env.DB_TEST_PORT || '3306', 10),
      user: 'root',
      password: process.env.DB_TEST_ROOT_PASSWORD,
    };
  }
  const envPath = path.resolve(__dirname, '../../../.devcontainer/.env');
  const env = parseEnvFile(envPath);
  if (!env || !env.DB_ROOT_PASSWORD) return null;
  const port = parseInt(env.DB_PORT || '3306', 10);
  const password = env.DB_ROOT_PASSWORD;
  const candidates = ['127.0.0.1', 'mariadb', 'localhost'];
  for (const host of candidates) {
    if (await probePort(host, port, 2000)) {
      return { host, port, user: 'root', password };
    }
  }
  return null;
}

// ── Fixture ──────────────────────────────────────────────────────────────────
// Minimal engine table carrying the real blueprint_id column the integrity
// index targets. Engine tables are not created by ensureInfrastructure (infra
// DDLs only), so seeding it is what lets the index self-heal path run.
function blueprintFieldsDDL() {
  return `CREATE TABLE \`${TEST_PREFIX}blueprint_fields\` (
    id           CHAR(36)  PRIMARY KEY,
    name         VARCHAR(255) NOT NULL,
    blueprint_id CHAR(36),
    order_index  INT NOT NULL DEFAULT 0,
    created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`;
}

async function indexExists(conn, tableName, indexName) {
  const rows = await conn.query(
    `SELECT 1 FROM information_schema.STATISTICS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = ?
        AND INDEX_NAME = ?`,
    [tableName, indexName],
  );
  return rows.length > 0;
}

let dbReady = false;
let dbConfig = null;
let testDbName = null;
let skipReason = null;

before(async () => {
  dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) {
    skipReason = 'no reachable MariaDB (set DB_TEST_HOST/DB_TEST_ROOT_PASSWORD or run in DevContainer)';
    // The flag is honoured on this branch too, not only in the `catch` below.
    // This is the branch a checkout without `.devcontainer/.env` reaches, so it
    // is the one that turned "no database at all" into a green run.
    if (process.env.REQUIRE_INTEGRATION_DB === '1') {
      throw new Error(`REQUIRE_INTEGRATION_DB=1 set but ${skipReason}.`);
    }
    return;
  }
  testDbName = `integ_idx_${process.pid}_${Date.now()}`;
  let adminConn = null;
  try {
    adminConn = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await adminConn.query(`CREATE DATABASE \`${testDbName}\``);
    await adminConn.query(`USE \`${testDbName}\``);
    await adminConn.query(blueprintFieldsDDL());
    await adminConn.end();
    adminConn = null;

    // configurePool → ensureInfrastructure runs the boot infra path (creates
    // infra tables + the integrity/public-read index self-heal) against the DB.
    await configurePool({
      host: dbConfig.host,
      port: dbConfig.port,
      user: dbConfig.user,
      password: dbConfig.password,
      database: testDbName,
      tablePrefix: TEST_PREFIX,
    });
    dbReady = true;
  } catch (err) {
    skipReason = `setup failed: ${err.message}`;
    if (adminConn) { try { await adminConn.end(); } catch {} }
    if (testDbName) {
      try {
        const cleanup = await mariadb.createConnection(dbConfig);
        await cleanup.query(`DROP DATABASE IF EXISTS \`${testDbName}\``);
        await cleanup.end();
      } catch {}
      testDbName = null;
    }
    if (process.env.REQUIRE_INTEGRATION_DB === '1') throw err;
  }
});

after(async () => {
  try { await shutdown(); } catch {}
  if (testDbName && dbConfig) {
    try {
      const cleanup = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
      await cleanup.query(`DROP DATABASE IF EXISTS \`${testDbName}\``);
      await cleanup.end();
    } catch (err) {
      console.error(`[teardown] failed to drop ${testDbName}: ${err.message}`);
    }
  }
});

describe('ensureInfrastructure — integrity scope indexes', () => {
  test('blueprint_fields(blueprint_id) index present after boot', async (t) => {
    if (!dbReady) { t.skip(skipReason); return; }
    const conn = await pool.rw.getConnection();
    try {
      // The before() boot ran _ensureIntegrityIndexes against the seeded
      // blueprint_fields (which had no index), so the ADD must have landed.
      assert.equal(
        await indexExists(conn, tbl('blueprint_fields'), 'idx_blueprint_fields_blueprint'),
        true,
        'idx_blueprint_fields_blueprint should exist on the existing DB after boot',
      );
    } finally {
      conn.release();
    }
  });

  test('variant_overrides(field_id) index added to an existing DB lacking it', async (t) => {
    if (!dbReady) { t.skip(skipReason); return; }
    const conn = await pool.rw.getConnection();
    const vo = tbl('variant_overrides');
    try {
      // Recreate variant_overrides WITHOUT the field_id index (an upgraded DB),
      // then re-run the boot infra path. The best-effort integrity-index ensure
      // (outside the version gate) must add it.
      await conn.query(`DROP TABLE IF EXISTS \`${vo}\``);
      await conn.query(
        `CREATE TABLE \`${vo}\` (
          id CHAR(36) PRIMARY KEY, variant_id CHAR(36), field_id CHAR(36),
          action VARCHAR(100) NOT NULL DEFAULT '', override_value TEXT,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
      );
      assert.equal(
        await indexExists(conn, vo, 'idx_variant_overrides_field'), false,
        'precondition: field_id index absent on the recreated table',
      );

      await ensureInfrastructure({ skipPreflight: true });

      assert.equal(
        await indexExists(conn, vo, 'idx_variant_overrides_field'), true,
        'the boot infra path should have added idx_variant_overrides_field',
      );
    } finally {
      conn.release();
    }
  });
});

describe('operator-mode preflight audit discipline', () => {
  test('runSchemaMigrations on CRUD-only operator account leaves zero db_privilege audit rows', async (t) => {
    if (!dbReady) { t.skip(skipReason); return; }

    const operatorUser = `integ_operator_${process.pid}_${Date.now()}`;
    const operatorPassword = `pw_${Math.random().toString(36).slice(2)}_${Date.now()}`;
    let adminConn = null;
    let operatorConn = null;

    try {
      adminConn = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
      await adminConn.query(`CREATE USER ?@'%' IDENTIFIED BY ?`, [operatorUser, operatorPassword]);
      await adminConn.query(
        `GRANT SELECT, INSERT, UPDATE, DELETE ON \`${testDbName}\`.* TO ?@'%'`,
        [operatorUser],
      );
      await adminConn.query('FLUSH PRIVILEGES');

      await configurePool({
        host: dbConfig.host,
        port: dbConfig.port,
        user: operatorUser,
        password: operatorPassword,
        database: testDbName,
        tablePrefix: TEST_PREFIX,
      });

      await assert.doesNotReject(
        ensureInfrastructure({ context: 'boot' }),
        'CRUD-only operator boot should skip DDL work without throwing',
      );

      operatorConn = await pool.rw.getConnection();
      await assert.doesNotReject(
        runSchemaMigrations(operatorConn, { context: 'boot' }),
        'CRUD-only operator migration path should skip DDL work without throwing',
      );

      const rows = await operatorConn.query(
        `SELECT COUNT(*) AS cnt
           FROM \`${tbl('feature_audit')}\`
          WHERE event_type LIKE 'db_privilege.%'`,
      );
      assert.equal(Number(rows[0].cnt), 0);
    } finally {
      if (operatorConn) operatorConn.release();
      if (adminConn) {
        try { await adminConn.query(`DROP USER IF EXISTS ?@'%'`, [operatorUser]); } catch {}
        try { await adminConn.end(); } catch {}
      }
    }
  });
});
