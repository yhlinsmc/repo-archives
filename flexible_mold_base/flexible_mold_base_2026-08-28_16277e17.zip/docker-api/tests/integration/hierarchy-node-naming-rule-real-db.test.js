'use strict';

/**
 * hierarchy-node-naming-rule-real-db.test.js — the per-blueprint auto-naming
 * template stored on hierarchy_nodes, written and read through the SAME generic
 * CRUD routes the Hierarchy Manager uses, against a REAL database.
 *
 * The column has no hand-written SQL of its own (SELECT * + the factory's
 * column-set-gated INSERT/UPDATE), so a mocked driver returns whatever the
 * fixture was told to and can neither prove the value was actually stored nor
 * that the read serializer coalesces a stored NULL to ''. This exercises both
 * verbs and both the value and the empty cases on a real MariaDB.
 *
 * Skips with a stated reason when no database is reachable, and fails instead of
 * skipping when REQUIRE_INTEGRATION_DB=1.
 */
const { test, describe, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const net = require('node:net');
const http = require('node:http');
const express = require('express');
const mariadb = require('mariadb');

const TEST_PREFIX = 'hnr_';
const tbl = (name) => `${TEST_PREFIX}${name}`;

let pool = null;
const lease = () => pool.getConnection();

const dbKey = require.resolve('../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey,
  filename: dbKey,
  loaded: true,
  exports: {
    pool: { ro: { getConnection: lease }, rw: { getConnection: lease } },
    t: tbl,
    getDynamicPool: async () => ({ ro: { getConnection: lease }, rw: { getConnection: lease } }),
  },
};

const { buildEngineTableDDLs } = require('../../src/table-ddls');
const { TABLES } = require('../../src/shared/constants');
const schemaRouter = require('../../src/edge/routes/app/schema');

const { fixtureUserId } = require('../helpers/fixture-ids');

function parseEnvFile(filePath) {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    const out = {};
    for (const line of content.split('\n')) {
      const m = line.match(/^\s*([A-Z_][A-Z0-9_]*)\s*=\s*(.*)\s*$/);
      if (!m) continue;
      let value = m[2];
      if ((value.startsWith('"') && value.endsWith('"'))
        || (value.startsWith("'") && value.endsWith("'"))) {
        value = value.slice(1, -1);
      }
      out[m[1]] = value;
    }
    return out;
  } catch {
    return null;
  }
}

function probePort(host, port, timeoutMs = 2000) {
  return new Promise((resolve) => {
    const socket = new net.Socket();
    let done = false;
    const finish = (ok) => {
      if (done) return;
      done = true;
      socket.destroy();
      resolve(ok);
    };
    socket.setTimeout(timeoutMs);
    socket.once('connect', () => finish(true));
    socket.once('timeout', () => finish(false));
    socket.once('error', () => finish(false));
    socket.connect(port, host);
  });
}

async function resolveMariaDbConfig() {
  if (process.env.DB_TEST_HOST && process.env.DB_TEST_ROOT_PASSWORD) {
    return {
      host: process.env.DB_TEST_HOST,
      port: parseInt(process.env.DB_TEST_PORT || '3306', 10),
      user: 'root',
      password: process.env.DB_TEST_ROOT_PASSWORD,
    };
  }
  const envPath = path.resolve(__dirname, '../../../.devcontainer/.env');
  const env = parseEnvFile(envPath);
  if (!env || !env.DB_ROOT_PASSWORD) return null;
  const port = parseInt(env.DB_PORT || '3306', 10);
  for (const host of ['127.0.0.1', 'mariadb', 'localhost']) {
    if (await probePort(host, port, 2000)) {
      return { host, port, user: 'root', password: env.DB_ROOT_PASSWORD };
    }
  }
  return null;
}

const ADMIN = { id: fixtureUserId('admin'), role: 'admin' };

let dbReady = false;
let skipReason = null;
let testDbName = null;
let server = null;
let baseUrl = null;
let currentUser = ADMIN;

before(async () => {
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) {
    skipReason = 'no MariaDB reachable via .devcontainer/.env or env vars';
    if (process.env.REQUIRE_INTEGRATION_DB === '1') {
      throw new Error(`REQUIRE_INTEGRATION_DB=1 set but ${skipReason}.`);
    }
    return;
  }
  testDbName = `hier_name_test_${process.pid}_${Date.now()}`;
  let admin = null;
  try {
    admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`CREATE DATABASE \`${testDbName}\``);
    await admin.query(`USE \`${testDbName}\``);
    const wanted = tbl(TABLES.HIERARCHY_NODES);
    const statements = buildEngineTableDDLs(tbl).filter((sql) => {
      const m = sql.match(/CREATE TABLE IF NOT EXISTS `([^`]+)`/);
      return m && m[1] === wanted;
    });
    assert.equal(statements.length, 1, 'the DDL list no longer defines hierarchy_nodes');
    for (const sql of statements) await admin.query(sql);
    await admin.end();
    admin = null;

    pool = mariadb.createPool({
      ...dbConfig, database: testDbName, connectionLimit: 4, connectTimeout: 5000,
    });

    const app = express();
    app.use(express.json());
    app.use((req, _res, next) => { req.user = currentUser; next(); });
    app.use('/edge/app/schema', schemaRouter);
    server = http.createServer(app);
    await new Promise((r) => server.listen(0, r));
    baseUrl = `http://127.0.0.1:${server.address().port}`;
    dbReady = true;
  } catch (err) {
    skipReason = `setup failed: ${err.message}`;
    if (admin) { try { await admin.end(); } catch { /* best effort */ } }
    if (process.env.REQUIRE_INTEGRATION_DB === '1') throw err;
  }
});

after(async () => {
  if (server) { try { server.close(); } catch { /* best effort */ } }
  if (pool) { try { await pool.end(); } catch { /* best effort */ } }
  if (!testDbName) return;
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) return;
  try {
    const admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`DROP DATABASE IF EXISTS \`${testDbName}\``);
    await admin.end();
  } catch { /* best effort */ }
});

async function createNode(body) {
  currentUser = ADMIN;
  const res = await fetch(`${baseUrl}/edge/app/schema/hierarchy_nodes`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
  });
  const text = await res.text();
  let parsed = null;
  try { parsed = JSON.parse(text); } catch { parsed = { raw: text }; }
  return { status: res.status, body: parsed };
}

async function updateNode(id, body) {
  currentUser = ADMIN;
  const res = await fetch(`${baseUrl}/edge/app/schema/hierarchy_nodes/${id}`, {
    method: 'PUT',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
  });
  const text = await res.text();
  let parsed = null;
  try { parsed = JSON.parse(text); } catch { parsed = { raw: text }; }
  return { status: res.status, body: parsed };
}

async function storedRule(id) {
  const rows = await pool.query(
    `SELECT naming_rule FROM \`${tbl('hierarchy_nodes')}\` WHERE id = ?`,
    [id],
  );
  return rows.length ? rows[0].naming_rule : undefined;
}

const guard = (t) => {
  if (!dbReady) { t.skip(skipReason || 'database not ready'); return true; }
  return false;
};

beforeEach(async () => {
  if (!dbReady) return;
  await pool.query(`DELETE FROM \`${tbl('hierarchy_nodes')}\``);
});

describe('naming_rule round-trip through the generic CRUD routes', () => {
  test('create stores the template and reads it back verbatim', async (t) => {
    if (guard(t)) return;
    const rule = '{{part_no}}-{{rev}}';
    const created = await createNode({ name: 'bp', node_type: 'blueprint', naming_rule: rule });
    assert.equal(created.status, 200, `create refused: ${JSON.stringify(created.body)}`);
    assert.equal(created.body.data.naming_rule, rule, 'the create response dropped the template');
    assert.equal(await storedRule(created.body.data.id), rule, 'the template was not stored');
  });

  test('a create that names no rule stores NULL and reads back as ""', async (t) => {
    if (guard(t)) return;
    // The Y-pattern case: the column is absent from the body, the DDL default
    // writes NULL, and the read serializer must coalesce that to '' so the
    // non-nullable TS type holds.
    const created = await createNode({ name: 'bp-no-rule', node_type: 'blueprint' });
    assert.equal(created.status, 200, `create refused: ${JSON.stringify(created.body)}`);
    assert.equal(created.body.data.naming_rule, '', 'an unset naming_rule did not read back as ""');
    assert.equal(await storedRule(created.body.data.id), null, 'an unset naming_rule was not stored as NULL');
  });

  test('update changes the stored template (the UPDATE verb, not only create)', async (t) => {
    if (guard(t)) return;
    const created = await createNode({ name: 'bp', node_type: 'blueprint', naming_rule: '{{a}}' });
    assert.equal(created.status, 200, `create refused: ${JSON.stringify(created.body)}`);
    const id = created.body.data.id;

    const next = '{{a}}/{{b}}';
    const updated = await updateNode(id, { naming_rule: next });
    assert.equal(updated.status, 200, `update refused: ${JSON.stringify(updated.body)}`);
    assert.equal(updated.body.data.naming_rule, next, 'the update response did not reflect the new template');
    assert.equal(await storedRule(id), next, 'the update did not change the stored template');
  });

  test('update can clear the template back to empty', async (t) => {
    if (guard(t)) return;
    const created = await createNode({ name: 'bp', node_type: 'blueprint', naming_rule: '{{a}}' });
    assert.equal(created.status, 200, `create refused: ${JSON.stringify(created.body)}`);
    const id = created.body.data.id;

    const updated = await updateNode(id, { naming_rule: '' });
    assert.equal(updated.status, 200, `update refused: ${JSON.stringify(updated.body)}`);
    assert.equal(updated.body.data.naming_rule, '', 'clearing the template did not read back as ""');
    assert.equal(await storedRule(id), '', 'clearing the template did not store ""');
  });
});
