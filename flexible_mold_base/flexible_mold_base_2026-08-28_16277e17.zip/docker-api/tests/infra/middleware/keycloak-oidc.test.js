/**
 * Unit tests for keycloak-oidc.js — _isSafeRedirectUrl logic
 *
 * The function is not exported, so we replicate its logic here for
 * regression testing. If the implementation changes, update this test.
 */
const { describe, it, beforeEach, afterEach } = require('node:test');
const assert = require('node:assert/strict');

// Replicate _isSafeRedirectUrl logic for testing (same algorithm as keycloak-oidc.js)
function isSafeRedirectUrl(url, env = {}) {
  if (!url) return false;
  if (url.startsWith('/') && !url.startsWith('//')) return true;
  try {
    const parsed = new URL(url);
    if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') return false;
    const origins = [
      env.FRONTEND_URL,
      env.BASE_URL,
    ];
    if (env.NODE_ENV !== 'production') {
      origins.push(`http://localhost:${env.PORT || 3200}`);
      origins.push('http://localhost:3000');
    }
    const allowedOrigins = origins
      .filter(Boolean)
      .map(u => { try { return new URL(u).origin; } catch { return null; } })
      .filter(Boolean);
    return allowedOrigins.includes(parsed.origin);
  } catch {
    return false;
  }
}

describe('isSafeRedirectUrl', () => {
  const devEnv = { FRONTEND_URL: 'http://localhost:3000', BASE_URL: 'http://localhost:3200', NODE_ENV: 'development' };
  const prodEnv = { FRONTEND_URL: 'https://app.example.com', BASE_URL: 'https://api.example.com', NODE_ENV: 'production' };

  describe('relative paths', () => {
    it('allows simple relative path', () => {
      assert.strictEqual(isSafeRedirectUrl('/login', devEnv), true);
    });

    it('allows nested relative path', () => {
      assert.strictEqual(isSafeRedirectUrl('/app/dashboard', devEnv), true);
    });

    it('rejects protocol-relative URL (//evil.com)', () => {
      assert.strictEqual(isSafeRedirectUrl('//evil.com', devEnv), false);
    });
  });

  describe('protocol validation', () => {
    it('rejects javascript: protocol', () => {
      assert.strictEqual(isSafeRedirectUrl('javascript:alert(1)', devEnv), false);
    });

    it('rejects data: protocol', () => {
      assert.strictEqual(isSafeRedirectUrl('data:text/html,<h1>pwned</h1>', devEnv), false);
    });

    it('rejects ftp: protocol', () => {
      assert.strictEqual(isSafeRedirectUrl('ftp://evil.com', devEnv), false);
    });
  });

  describe('origin matching', () => {
    it('allows FRONTEND_URL origin', () => {
      assert.strictEqual(isSafeRedirectUrl('https://app.example.com/login', prodEnv), true);
    });

    it('allows BASE_URL origin', () => {
      assert.strictEqual(isSafeRedirectUrl('https://api.example.com/callback', prodEnv), true);
    });

    it('rejects unknown origin', () => {
      assert.strictEqual(isSafeRedirectUrl('https://evil.com/phish', prodEnv), false);
    });

    it('rejects origin with matching hostname but different port', () => {
      assert.strictEqual(isSafeRedirectUrl('https://app.example.com:8443/login', prodEnv), false);
    });
  });

  describe('production vs development', () => {
    it('allows localhost:3000 in development', () => {
      assert.strictEqual(isSafeRedirectUrl('http://localhost:3000/login', devEnv), true);
    });

    it('rejects localhost:3000 in production', () => {
      assert.strictEqual(isSafeRedirectUrl('http://localhost:3000/login', prodEnv), false);
    });

    it('allows localhost:PORT in development', () => {
      const env = { ...devEnv, PORT: '4000' };
      assert.strictEqual(isSafeRedirectUrl('http://localhost:4000/login', env), true);
    });
  });

  describe('edge cases', () => {
    it('rejects null', () => {
      assert.strictEqual(isSafeRedirectUrl(null, devEnv), false);
    });

    it('rejects undefined', () => {
      assert.strictEqual(isSafeRedirectUrl(undefined, devEnv), false);
    });

    it('rejects empty string', () => {
      assert.strictEqual(isSafeRedirectUrl('', devEnv), false);
    });

    it('rejects malformed URL', () => {
      assert.strictEqual(isSafeRedirectUrl('not-a-url', devEnv), false);
    });

    it('handles missing FRONTEND_URL gracefully', () => {
      const env = { NODE_ENV: 'production' };
      assert.strictEqual(isSafeRedirectUrl('https://evil.com', env), false);
    });
  });
});
