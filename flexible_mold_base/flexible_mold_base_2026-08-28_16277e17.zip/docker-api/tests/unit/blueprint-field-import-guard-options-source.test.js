/**
 * blueprint-field-import-guard-options-source.test.js — the raw JSON
 * blueprint import/overwrite path's shared guard (`checkImportedBlueprintFields`)
 * must apply the SAME `options_source` structural + Q1 mutual-exclusion floor
 * the write routes enforce (routes-blueprint-fields.js `isPayloadInconsistent`).
 * Before this fix an imported row's `options_source` was never validated —
 * a malformed shape, or a row carrying both `options_source` and
 * `depends_on_field_key`, would reach the INSERT untouched.
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');

const { checkImportedBlueprintFields } = require('../../src/edge/lib/blueprint-field-import-guard');

const selectField = (overrides = {}) => ({
  field_key: 'material',
  field_type: 'select',
  ...overrides,
});

describe('checkImportedBlueprintFields — options_source structural floor', () => {
  it('rejects an imported field whose options_source is not an object', () => {
    const { errors } = checkImportedBlueprintFields([
      selectField({ options_source: 'field' }),
    ]);
    assert.ok(
      errors.some((e) => /options_source must be null or an object/.test(e)),
      `expected an options_source shape error, got: ${JSON.stringify(errors)}`,
    );
  });

  it('rejects an imported field with an unknown options_source type', () => {
    const { errors } = checkImportedBlueprintFields([
      selectField({ options_source: { type: 'sql_query', query: 'SELECT 1' } }),
    ]);
    assert.ok(
      errors.some((e) => /options_source must be null or an object/.test(e)),
      `expected an options_source shape error, got: ${JSON.stringify(errors)}`,
    );
  });

  it('rejects an imported connector options_source with a blank input_bindings key', () => {
    const { errors } = checkImportedBlueprintFields([
      selectField({
        options_source: {
          type: 'connector', connector_id: 'c', input_bindings: { '': 'plant' },
        },
      }),
    ]);
    assert.ok(
      errors.some((e) => /options_source must be null or an object/.test(e)),
      `expected an options_source shape error, got: ${JSON.stringify(errors)}`,
    );
  });

  it('rejects an imported connector options_source with a blank input_bindings value', () => {
    const { errors } = checkImportedBlueprintFields([
      selectField({
        options_source: {
          type: 'connector', connector_id: 'c', input_bindings: { region: '' },
        },
      }),
    ]);
    assert.ok(
      errors.some((e) => /options_source must be null or an object/.test(e)),
      `expected an options_source shape error, got: ${JSON.stringify(errors)}`,
    );
  });

  it('rejects an imported field carrying both options_source and depends_on_field_key (Q1)', () => {
    const { errors } = checkImportedBlueprintFields([
      selectField({
        options_source: { type: 'field', source_field_key: 'other_field' },
        depends_on_field_key: 'parent_field',
      }),
    ]);
    assert.ok(
      errors.some((e) => /cannot carry both options_source and depends_on_field_key/.test(e)),
      `expected the Q1 mutual-exclusion error, got: ${JSON.stringify(errors)}`,
    );
  });

  it('accepts a well-formed field-type options_source with no depends_on_field_key', () => {
    const { errors } = checkImportedBlueprintFields([
      selectField({ options_source: { type: 'field', source_field_key: 'other_field' } }),
    ]);
    assert.deepEqual(errors, []);
  });

  it('accepts a well-formed field-type options_source with an explicit column', () => {
    const { errors } = checkImportedBlueprintFields([
      selectField({ options_source: { type: 'field', source_field_key: 'line_items', column: 'part_no' } }),
    ]);
    assert.deepEqual(errors, []);
  });

  it('rejects an imported field-type options_source with an empty-string column', () => {
    const { errors } = checkImportedBlueprintFields([
      selectField({ options_source: { type: 'field', source_field_key: 'line_items', column: '' } }),
    ]);
    assert.ok(
      errors.some((e) => /options_source must be null or an object/.test(e)),
      `expected an options_source shape error, got: ${JSON.stringify(errors)}`,
    );
  });

  it('accepts a well-formed connector-type options_source with a valid input_bindings map', () => {
    const { errors } = checkImportedBlueprintFields([
      selectField({
        options_source: {
          type: 'connector', connector_id: 'conn-1', input_bindings: { region: 'plant_code' },
        },
      }),
    ]);
    assert.deepEqual(errors, []);
  });

  it('accepts a field carrying only depends_on_field_key, no options_source', () => {
    const { errors } = checkImportedBlueprintFields([
      selectField({ depends_on_field_key: 'parent_field' }),
    ]);
    assert.deepEqual(errors, []);
  });
});

// Codex P2 (round 2, OPT-E3): the column-level twin of the field-level
// floor above, for `table_config.columns[i].options_source` — a JSON
// blueprint import (and an overwrite reaching this same guard) is a write
// path the YAML parse-time check (fix-batch L2) never runs on.
const tableField = (columns, overrides = {}) => ({
  field_key: 'line_items',
  field_type: 'table',
  table_config: { columns },
  ...overrides,
});

describe('checkImportedBlueprintFields — table_config column-level options_source structural floor', () => {
  it('rejects an imported table column with an options_source of unknown shape', () => {
    const { errors } = checkImportedBlueprintFields([
      tableField([{ key: 'category', options_source: { type: 'sql_query', query: 'SELECT 1' } }]),
    ]);
    assert.ok(
      errors.some((e) => /table_config\.columns\[\]\.options_source must be null or an object/.test(e)),
      `expected a column options_source shape error, got: ${JSON.stringify(errors)}`,
    );
  });

  it('rejects an imported table column with a connector options_source missing connector_id', () => {
    const { errors } = checkImportedBlueprintFields([
      tableField([{ key: 'category', options_source: { type: 'connector', input_bindings: {} } }]),
    ]);
    assert.ok(
      errors.some((e) => /table_config\.columns\[\]\.options_source must be null or an object/.test(e)),
      `expected a column options_source shape error, got: ${JSON.stringify(errors)}`,
    );
  });

  it('accepts a well-formed field-type column options_source', () => {
    const { errors } = checkImportedBlueprintFields([
      tableField([{ key: 'category', options_source: { type: 'field', source_field_key: 'src' } }]),
    ]);
    assert.deepEqual(errors, []);
  });

  it('accepts a well-formed connector-type column options_source with input_bindings', () => {
    const { errors } = checkImportedBlueprintFields([
      tableField([{
        key: 'category',
        options_source: { type: 'connector', connector_id: 'conn-1', input_bindings: { region: 'plant_code' } },
      }]),
    ]);
    assert.deepEqual(errors, []);
  });

  it('accepts a table field with no table_config at all', () => {
    const { errors } = checkImportedBlueprintFields([
      { field_key: 'line_items', field_type: 'table', table_config: null },
    ]);
    assert.deepEqual(errors, []);
  });

  it('accepts a table field whose columns carry no options_source', () => {
    const { errors } = checkImportedBlueprintFields([
      tableField([{ key: 'category', label: 'Category' }]),
    ]);
    assert.deepEqual(errors, []);
  });
});
