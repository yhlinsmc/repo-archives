/**
 * capacity-placement-layout-schema-parity.test.js — the schema migration
 * triple contract for cap_settings.placement_layout (post-ar2-residuals P6):
 * table-ddls.js declares the column, migration-steps.js carries a matching
 * add-column entry at the release version, PLATFORM_SCHEMA_VERSION was
 * bumped to that same version, and every write/read surface that names the
 * column (SETTINGS_COLUMN_TYPES, CONFIG_MOUNTS.settings, the scenario
 * settings.js route, the dto-mapper JSON-column list) actually carries it —
 * mechanically checked against table-ddls.js rather than hand-restated, so a
 * column added to the DDL but forgotten on a reader/writer surface fails
 * here instead of 500ing (or silently dropping) in production.
 */
const { describe, it, before } = require('node:test');
const assert = require('node:assert/strict');

const dbKey = require.resolve('../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: {}, t: (n) => n },
};

const { buildEngineTableDDLs } = require('../../src/table-ddls');
const { MIGRATION_STEPS, PLATFORM_SCHEMA_VERSION } = require('../../src/edge/migration-steps');
const { TABLES } = require('../../src/shared/constants');
const { SETTINGS_COLUMN_TYPES, CONFIG_MOUNTS } = require('../../src/edge/routes/app/capacity/_shared');

const RELEASE_VERSION = '3.2.827';

let cols;
before(() => {
  cols = new Map();
  for (const ddl of buildEngineTableDDLs((n) => n)) {
    const m = ddl.match(/CREATE TABLE IF NOT EXISTS `([^`]+)`/);
    if (!m) continue;
    const set = new Set();
    for (const rawLine of ddl.split('\n')) {
      const line = rawLine.trim();
      const cm = line.match(/^`?([a-z_]+)`?\s+(?:CHAR|VARCHAR|INT|DOUBLE|TIMESTAMP|JSON|TEXT|ENUM|BOOLEAN|TINYINT|BIGINT|DATETIME|DECIMAL|FLOAT|BLOB)\b/i);
      if (cm) set.add(cm[1]);
    }
    cols.set(m[1], set);
  }
});

describe('cap_settings.placement_layout — table-ddls.js is the single source of truth', () => {
  it('the column is declared on cap_settings', () => {
    assert.ok(cols.get('cap_settings').has('placement_layout'), 'table-ddls.js cap_settings is missing placement_layout');
  });
});

describe('cap_settings.placement_layout — migration registry agreement', () => {
  it('an add-column entry exists for cap_settings.placement_layout', () => {
    const entry = MIGRATION_STEPS.find(
      (s) => s.kind === 'add-column' && s.table === TABLES.CAP_SETTINGS && s.column === 'placement_layout',
    );
    assert.ok(entry, 'no add-column migration entry for cap_settings.placement_layout');
    assert.equal(entry.version, RELEASE_VERSION);
    assert.equal(entry.severity, 'warning'); // purely-additive/nullable, same posture as every sibling JSON column
  });
  it('PLATFORM_SCHEMA_VERSION was bumped to at least the release version', () => {
    // NOT strict equality: this was the newest entry when this test was
    // written, but the registry keeps growing (U10, added a later
    // entry) — the invariant this test protects is "the version was reached
    // on the way up", not "nothing shipped after it".
    assert.ok(
      PLATFORM_SCHEMA_VERSION.localeCompare(RELEASE_VERSION, undefined, { numeric: true }) >= 0,
      `PLATFORM_SCHEMA_VERSION (${PLATFORM_SCHEMA_VERSION}) regressed below ${RELEASE_VERSION}`,
    );
  });
});

describe('cap_settings.placement_layout — every write/read surface that names the column', () => {
  it('SETTINGS_COLUMN_TYPES declares it as a nullable jsonObject', () => {
    assert.deepEqual(SETTINGS_COLUMN_TYPES.placement_layout, { kind: 'jsonObject', nullable: true });
  });
  it('CONFIG_MOUNTS.settings (the global template route) writes + JSON-parses it', () => {
    assert.ok(CONFIG_MOUNTS.settings.cols.includes('placement_layout'));
    assert.ok(CONFIG_MOUNTS.settings.json.includes('placement_layout'));
  });
  it('settings.js (the scenario override route) declares it writable + JSON', () => {
    const settingsRouteSrc = require('node:fs').readFileSync(
      require.resolve('../../src/edge/routes/app/capacity/settings.js'), 'utf8',
    );
    assert.match(settingsRouteSrc, /WRITABLE_COLUMNS = \[[\s\S]*?'placement_layout'[\s\S]*?\];/);
    assert.match(settingsRouteSrc, /JSON_COLUMNS = new Set\(\[[\s\S]*?'placement_layout'[\s\S]*?\]\);/);
  });
  it('dto-mapper.js (the read-path JSON-column list) parses it on every cap_settings read', () => {
    const dtoMapperSrc = require('node:fs').readFileSync(
      require.resolve('../../src/edge/lib/dto-mapper.js'), 'utf8',
    );
    // Scoped to the cap_settings registry entry, not a bare substring search —
    // a match anywhere in the file would not prove it is on THIS table's list.
    const capSettingsBlock = dtoMapperSrc.match(/cap_settings: \{[\s\S]*?\n {2}\},/);
    assert.ok(capSettingsBlock, 'dto-mapper.js no longer declares a cap_settings registry entry');
    assert.match(capSettingsBlock[0], /json: \[[\s\S]*?'placement_layout'[\s\S]*?\]/);
  });
});
