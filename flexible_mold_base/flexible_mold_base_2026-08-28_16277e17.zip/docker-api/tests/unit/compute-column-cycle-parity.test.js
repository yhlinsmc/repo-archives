/**
 * compute-column-cycle-parity.test.js — column-level cycle verdicts must
 * agree between the backend guard (compute-rule-graph.js, P1b) and the
 * frontend authoring/eval graph (compute-graph.ts) for the SAME input.
 *
 * Both sides read the single fixture file at
 * src/fmb/lib/compute/__fixtures__/compute-column-cycle.fixtures.json so a
 * divergence between the two implementations is caught here rather than
 * drifting silently — the round-1 gap this closes (compute-sources-parity
 * only ever covered field-level `extractSources`, never the column graph).
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const path = require('path');

const { buildColumnComputeNodes, hasColumnCycle } = require('../../src/edge/lib/compute-rule-graph');
const fixtures = require(
  path.resolve(__dirname, '../../../src/fmb/lib/compute/__fixtures__/compute-column-cycle.fixtures.json'),
);

describe('column-cycle verdict parity — backend JS vs shared fixture', () => {
  for (const { description, sources, expectCycle } of fixtures) {
    it(description, () => {
      // The backend side reads `columns` verbatim — it is already the raw
      // scope DOCUMENT `singleScopedColumn` expects, the same shape
      // `value_scope`/`cell_targets` arrive in from storage.
      const columnNodes = buildColumnComputeNodes(sources);
      assert.equal(hasColumnCycle(new Map(), columnNodes), expectCycle);
    });
  }
});
