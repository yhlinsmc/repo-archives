const test = require('node:test');
const assert = require('node:assert/strict');
const {
  validateComputeRule,
  MAX_CONCAT_PARTS,
  MAX_ARITH_OPERANDS,
  MAX_LOOKUP_ROWS,
} = require('../../src/edge/lib/compute-rule-validate');

const fieldKeys = new Set(['model', 'qty', 'price', 'part_no']);

test('accepts a valid concat rule', () => {
  const rule = { op: 'concat', overridable: true, output_type: 'string',
    config: { parts: [{ type: 'field', key: 'model' }, { type: 'literal', text: '-US' }] } };
  assert.deepEqual(validateComputeRule(rule, { fieldKeys, targetType: 'string' }), { ok: true });
});

test('rejects unknown op', () => {
  const r = validateComputeRule({ op: 'danger', overridable: true, output_type: 'string', config: {} },
    { fieldKeys, targetType: 'string' });
  assert.equal(r.ok, false);
  assert.equal(r.code, 'unknown_op');
});

test('rejects output_type mismatch with target field', () => {
  const rule = { op: 'concat', overridable: true, output_type: 'string', config: { parts: [] } };
  const r = validateComputeRule(rule, { fieldKeys, targetType: 'number' });
  assert.equal(r.ok, false);
  assert.equal(r.code, 'output_type_mismatch');
});

test('rejects a source field that does not exist', () => {
  const rule = { op: 'transform', overridable: true, output_type: 'string',
    config: { source: 'ghost', transform: 'upper' } };
  const r = validateComputeRule(rule, { fieldKeys, targetType: 'string' });
  assert.equal(r.ok, false);
  assert.equal(r.code, 'missing_source');
});

test('rejects unknown transform kind', () => {
  const rule = { op: 'transform', overridable: true, output_type: 'string',
    config: { source: 'model', transform: 'explode' } };
  const r = validateComputeRule(rule, { fieldKeys, targetType: 'string' });
  assert.equal(r.ok, false);
  assert.equal(r.code, 'unknown_transform');
});

test('rejects non-boolean overridable', () => {
  const rule = { op: 'concat', overridable: 'yes', output_type: 'string', config: { parts: [] } };
  const r = validateComputeRule(rule, { fieldKeys, targetType: 'string' });
  assert.equal(r.ok, false);
  assert.equal(r.code, 'bad_overridable');
});

const cellCtx = {
  fieldKeys: new Set(['prefix', 'items', 'pn']),
  targetType: 'string',
  tableColumns: new Map([['items', new Set(['part', 'qty'])]]),
};
const cellRule = (cell) => ({
  op: 'concat', overridable: true, output_type: 'string',
  config: { parts: [{ type: 'table_cell', cell }] },
});

test('accepts a valid table_cell', () => {
  const r = validateComputeRule(cellRule({ table_key: 'items', column_key: 'part', row: 'first' }), cellCtx);
  assert.equal(r.ok, true);
});

test('rejects an unknown table_key', () => {
  const r = validateComputeRule(cellRule({ table_key: 'nope', column_key: 'part', row: 'first' }), cellCtx);
  assert.equal(r.code, 'bad_table_cell');
});

test('rejects an unknown column_key', () => {
  const r = validateComputeRule(cellRule({ table_key: 'items', column_key: 'nope', row: 'first' }), cellCtx);
  assert.equal(r.code, 'bad_table_cell');
});

test('rejects a bad row selector', () => {
  const r = validateComputeRule(cellRule({ table_key: 'items', column_key: 'part', row: 'third' }), cellCtx);
  assert.equal(r.code, 'bad_table_cell');
});

test('rejects a non-table field used as table_key', () => {
  const r = validateComputeRule(cellRule({ table_key: 'prefix', column_key: 'part', row: 'first' }), cellCtx);
  assert.equal(r.code, 'bad_table_cell');
});

test("accepts a 'value' column_key for a simple (no-columns) table", () => {
  // A table field with no explicit columns resolves to a single 'value'
  // column; loadComputeValidationContext seeds tableColumns with that key.
  const ctx = {
    fieldKeys: new Set(['simple', 'pn']),
    targetType: 'string',
    tableColumns: new Map([['simple', new Set(['value'])]]),
  };
  const r = validateComputeRule(
    cellRule({ table_key: 'simple', column_key: 'value', row: 'first' }),
    ctx,
  );
  assert.equal(r.ok, true);
});

test('accepts a valid arith table_cell operand', () => {
  const r = { op: 'arith', overridable: true, output_type: 'number',
    config: { operator: 'add', operands: [
      { type: 'literal', value: 1 },
      { type: 'table_cell', cell: { table_key: 'items', column_key: 'qty', row: 'last' } },
    ] } };
  assert.equal(validateComputeRule(r, { ...cellCtx, targetType: 'number' }).ok, true);
});

// ── same_table_column (same-table relative column) ─────────────────────────
// Legal ONLY when tableColumns carries an entry for `ownerFieldKey` itself
// (the rule's own field is a table field) and the named column is one of
// that table's own declared columns — the owner table is implicit, so
// `ownerFieldKey` is the only thing a term can be checked against — AND
// ONLY when the write is narrowed to a column: the row-context evaluator
// carries no per-row context on the whole-field path, so an unnarrowed rule
// is structurally un-runnable however valid the term itself looks.

const sameColRule = (columnKey) => ({
  op: 'concat', overridable: true, output_type: 'string',
  config: { parts: [{ type: 'same_table_column', column_key: columnKey }] },
});

test('accepts a same_table_column term when the owner field is itself a table field and the write is column-narrowed', () => {
  const r = validateComputeRule(sameColRule('part'), { ...cellCtx, ownerFieldKey: 'items', narrowedToColumn: true });
  assert.equal(r.ok, true);
});

test('rejects a same_table_column term when ownerFieldKey is not offered (never fall-open)', () => {
  const r = validateComputeRule(sameColRule('part'), { ...cellCtx, narrowedToColumn: true });
  assert.equal(r.code, 'bad_same_table_column');
});

test('rejects a same_table_column term when the owner field is NOT a table field', () => {
  const r = validateComputeRule(sameColRule('part'), { ...cellCtx, ownerFieldKey: 'prefix', narrowedToColumn: true });
  assert.equal(r.code, 'bad_same_table_column');
});

test('rejects a same_table_column term naming a column the owner table does not declare', () => {
  const r = validateComputeRule(sameColRule('ghost'), { ...cellCtx, ownerFieldKey: 'items', narrowedToColumn: true });
  assert.equal(r.code, 'bad_same_table_column');
});

test('rejects a same_table_column term with a non-string / empty column_key', () => {
  for (const columnKey of [undefined, null, 42, '']) {
    const r = validateComputeRule(sameColRule(columnKey), { ...cellCtx, ownerFieldKey: 'items', narrowedToColumn: true });
    assert.equal(r.code, 'bad_same_table_column', `expected rejection for column_key=${JSON.stringify(columnKey)}`);
  }
});

test('accepts a same_table_column arith operand under the same rule', () => {
  const r = { op: 'arith', overridable: true, output_type: 'number',
    config: { operator: 'add', operands: [
      { type: 'same_table_column', column_key: 'qty' },
      { type: 'literal', value: 1 },
    ] } };
  assert.equal(
    validateComputeRule(r, { ...cellCtx, targetType: 'number', ownerFieldKey: 'items', narrowedToColumn: true }).ok,
    true,
  );
});

test("accepts a 'value' same_table_column on a simple (no-columns) owner table", () => {
  const ctx = {
    fieldKeys: new Set(['simple']),
    targetType: 'string',
    tableColumns: new Map([['simple', new Set(['value'])]]),
    ownerFieldKey: 'simple',
    narrowedToColumn: true,
  };
  assert.equal(validateComputeRule(sameColRule('value'), ctx).ok, true);
});

test('a same_table_column term contributes no field-level source (missing_source never fires for it)', () => {
  // The column is not a field key, so it must not be checked against
  // fieldKeys the way a `field` term's key is.
  const r = validateComputeRule(sameColRule('part'), {
    fieldKeys: new Set(), targetType: 'string', tableColumns: cellCtx.tableColumns,
    ownerFieldKey: 'items', narrowedToColumn: true,
  });
  assert.equal(r.ok, true);
});

// ── C1: the un-narrowed whole-field default (structurally un-runnable) ─────
// Default `narrowedToColumn` is false — the fail-closed default every other
// context flag in this validator already holds (see `ownerFieldKey` above).

test('rejects a same_table_column term when narrowedToColumn is not passed at all (the authoring default)', () => {
  const r = validateComputeRule(sameColRule('part'), { ...cellCtx, ownerFieldKey: 'items' });
  assert.equal(r.code, 'same_table_column_requires_column_scope');
});

test('rejects a same_table_column term when narrowedToColumn is explicitly false', () => {
  const r = validateComputeRule(sameColRule('part'), { ...cellCtx, ownerFieldKey: 'items', narrowedToColumn: false });
  assert.equal(r.code, 'same_table_column_requires_column_scope');
});

test('the narrowing gate is checked before the column-validity gate', () => {
  // An unnarrowed write naming a column the owner table does not even declare
  // still reports the runnability reason first — that is what the author has
  // to fix before the column choice matters at all.
  const r = validateComputeRule(sameColRule('ghost'), { ...cellCtx, ownerFieldKey: 'items' });
  assert.equal(r.code, 'same_table_column_requires_column_scope');
});

test('an arith same_table_column operand is gated the same way', () => {
  const r = { op: 'arith', overridable: true, output_type: 'number',
    config: { operator: 'add', operands: [{ type: 'same_table_column', column_key: 'qty' }] } };
  assert.equal(
    validateComputeRule(r, { ...cellCtx, targetType: 'number', ownerFieldKey: 'items' }).code,
    'same_table_column_requires_column_scope',
  );
});

test('a plain field/literal/table_cell rule is unaffected by narrowedToColumn (no same_table_column term to gate)', () => {
  const rule = { op: 'concat', overridable: true, output_type: 'string',
    config: { parts: [{ type: 'field', key: 'model' }] } };
  assert.equal(validateComputeRule(rule, { fieldKeys, targetType: 'string' }).ok, true);
});

// ── table_column_lookup (by-key lookup into another table) ─────────────────
// Names FOUR things: the TARGET table field + its two columns (matchKeyColumn,
// valueColumn — checked against `tableColumns.get(lookupRef.table_key)`, the
// same map `isValidCell` reads), plus `ownKeyColumn` — a same-table read of
// the OWNER's own table, checked exactly like `same_table_column` (same
// `ownerFieldKey`/`narrowedToColumn` gate).

const lookupCtx = {
  fieldKeys: new Set(['items', 'catalog', 'prefix']),
  targetType: 'string',
  tableColumns: new Map([
    ['items', new Set(['sku', 'label'])],
    ['catalog', new Set(['sku', 'price'])],
  ]),
};
const lookupRule = (lookupRef) => ({
  op: 'concat', overridable: true, output_type: 'string',
  config: { parts: [{ type: 'table_column_lookup', lookupRef }] },
});
const validLookupRef = { table_key: 'catalog', matchKeyColumn: 'sku', ownKeyColumn: 'sku', valueColumn: 'price' };

test('accepts a valid table_column_lookup term when the write is column-narrowed', () => {
  const r = validateComputeRule(lookupRule(validLookupRef), {
    ...lookupCtx, ownerFieldKey: 'items', narrowedToColumn: true,
  });
  assert.equal(r.ok, true);
});

test('rejects a table_column_lookup term when the write is not column-scoped (same gate as same_table_column)', () => {
  const r = validateComputeRule(lookupRule(validLookupRef), { ...lookupCtx, ownerFieldKey: 'items' });
  assert.equal(r.code, 'same_table_column_requires_column_scope');
});

// M1 (fix batch, adv A MED): `narrowedToColumn` is not a hand-picked boolean
// at the real write boundary — every route call site derives it from the
// request's cell_targets/value_scope document via
// `scopeNamesSingleColumn` (EXACTLY one column; a 2+-column scope reads as
// "not narrowed"). Exercised here through the real predicate, not a
// hand-passed `true`, to close the gap a hand-passed boolean cannot catch:
// a caller wiring `scopeNamesColumn` (accepts ANY count ≥1) by mistake in
// place of `scopeNamesSingleColumn` would still pass every OTHER test in
// this file (which only ever sets `narrowedToColumn` directly) while
// silently admitting a multi-column table_column_lookup write.
test('a scope narrowed to TWO columns computes narrowedToColumn=false via scopeNamesSingleColumn — table_column_lookup is rejected, same as same_table_column', () => {
  const { scopeNamesSingleColumn } = require('../../src/shared/cell-targets-validate');
  const twoColumnScope = { columns: ['sku', 'label'] };
  const narrowedToColumn = scopeNamesSingleColumn(twoColumnScope);
  assert.equal(narrowedToColumn, false);
  const r = validateComputeRule(lookupRule(validLookupRef), { ...lookupCtx, ownerFieldKey: 'items', narrowedToColumn });
  assert.equal(r.code, 'same_table_column_requires_column_scope');
});

test('a scope narrowed to exactly ONE column computes narrowedToColumn=true via scopeNamesSingleColumn — table_column_lookup is accepted', () => {
  const { scopeNamesSingleColumn } = require('../../src/shared/cell-targets-validate');
  const oneColumnScope = { columns: ['sku'] };
  const narrowedToColumn = scopeNamesSingleColumn(oneColumnScope);
  assert.equal(narrowedToColumn, true);
  const r = validateComputeRule(lookupRule(validLookupRef), { ...lookupCtx, ownerFieldKey: 'items', narrowedToColumn });
  assert.equal(r.ok, true);
});

test('rejects an unknown TARGET table_key', () => {
  const r = validateComputeRule(
    lookupRule({ ...validLookupRef, table_key: 'ghost' }),
    { ...lookupCtx, ownerFieldKey: 'items', narrowedToColumn: true },
  );
  assert.equal(r.code, 'bad_table_column_lookup');
});

test('rejects a TARGET table_key that is not a table field', () => {
  const r = validateComputeRule(
    lookupRule({ ...validLookupRef, table_key: 'prefix' }),
    { ...lookupCtx, ownerFieldKey: 'items', narrowedToColumn: true },
  );
  assert.equal(r.code, 'bad_table_column_lookup');
});

test('rejects a matchKeyColumn the TARGET table does not declare', () => {
  const r = validateComputeRule(
    lookupRule({ ...validLookupRef, matchKeyColumn: 'ghost' }),
    { ...lookupCtx, ownerFieldKey: 'items', narrowedToColumn: true },
  );
  assert.equal(r.code, 'bad_table_column_lookup');
});

test('rejects a valueColumn the TARGET table does not declare', () => {
  const r = validateComputeRule(
    lookupRule({ ...validLookupRef, valueColumn: 'ghost' }),
    { ...lookupCtx, ownerFieldKey: 'items', narrowedToColumn: true },
  );
  assert.equal(r.code, 'bad_table_column_lookup');
});

test('rejects an ownKeyColumn the OWNER table does not declare', () => {
  const r = validateComputeRule(
    lookupRule({ ...validLookupRef, ownKeyColumn: 'ghost' }),
    { ...lookupCtx, ownerFieldKey: 'items', narrowedToColumn: true },
  );
  assert.equal(r.code, 'bad_table_column_lookup');
});

test('rejects an ownKeyColumn when ownerFieldKey is not offered (never fall-open)', () => {
  const r = validateComputeRule(lookupRule(validLookupRef), { ...lookupCtx, narrowedToColumn: true });
  assert.equal(r.code, 'bad_table_column_lookup');
});

test('rejects an ownKeyColumn when the owner field is NOT a table field', () => {
  const r = validateComputeRule(
    lookupRule(validLookupRef), { ...lookupCtx, ownerFieldKey: 'prefix', narrowedToColumn: true },
  );
  assert.equal(r.code, 'bad_table_column_lookup');
});

test('rejects a malformed/missing lookupRef', () => {
  for (const bad of [undefined, null, {}, { table_key: 'catalog' }]) {
    const r = validateComputeRule(
      { op: 'concat', overridable: true, output_type: 'string',
        config: { parts: [{ type: 'table_column_lookup', lookupRef: bad }] } },
      { ...lookupCtx, ownerFieldKey: 'items', narrowedToColumn: true },
    );
    assert.equal(r.code, 'bad_table_column_lookup', `expected rejection for lookupRef=${JSON.stringify(bad)}`);
  }
});

test('accepts a table_column_lookup arith operand under the same rule', () => {
  const r = { op: 'arith', overridable: true, output_type: 'number',
    config: { operator: 'add', operands: [
      { type: 'table_column_lookup', lookupRef: validLookupRef },
      { type: 'literal', value: 1 },
    ] } };
  assert.equal(
    validateComputeRule(r, { ...lookupCtx, targetType: 'number', ownerFieldKey: 'items', narrowedToColumn: true }).ok,
    true,
  );
});

test("accepts 'value' columns on column-less simple tables (both sides)", () => {
  const ctx = {
    fieldKeys: new Set(['simple_owner', 'simple_target']),
    targetType: 'string',
    tableColumns: new Map([
      ['simple_owner', new Set(['value'])],
      ['simple_target', new Set(['value'])],
    ]),
    ownerFieldKey: 'simple_owner',
    narrowedToColumn: true,
  };
  const ref = { table_key: 'simple_target', matchKeyColumn: 'value', ownKeyColumn: 'value', valueColumn: 'value' };
  assert.equal(validateComputeRule(lookupRule(ref), ctx).ok, true);
});

// ── Size bounds ─────────────────────────────────────────────────────────────
// Every one of these arrays is walked once per validation and again once per
// cycle-guard pass, and the guard runs one pass per variant carrying a compute
// override. Unbounded, a single accepted rule sets the CPU cost of an
// authenticated write. The rejection has to name the limit — the author needs
// to know what to trim to.

const parts = (n) => ({
  op: 'concat', overridable: true, output_type: 'string',
  config: { parts: Array.from({ length: n }, () => ({ type: 'literal', text: 'x' })) },
});
const operands = (n) => ({
  op: 'arith', overridable: true, output_type: 'number',
  config: { operator: 'add', operands: Array.from({ length: n }, () => ({ type: 'literal', value: 1 })) },
});
const lookupRows = (n) => ({
  op: 'lookup', overridable: true, output_type: 'string',
  config: { source: 'model', table: Array.from({ length: n }, (_, i) => ({ in: `i${i}`, out: 'o' })) },
});

test('accepts concat.parts at the limit and rejects one past it', () => {
  assert.equal(validateComputeRule(parts(MAX_CONCAT_PARTS), { fieldKeys, targetType: 'string' }).ok, true);
  const r = validateComputeRule(parts(MAX_CONCAT_PARTS + 1), { fieldKeys, targetType: 'string' });
  assert.equal(r.ok, false);
  assert.equal(r.code, 'too_many_parts');
  assert.match(r.detail, new RegExp(String(MAX_CONCAT_PARTS)));
});

test('accepts arith.operands at the limit and rejects one past it', () => {
  assert.equal(validateComputeRule(operands(MAX_ARITH_OPERANDS), { fieldKeys, targetType: 'number' }).ok, true);
  const r = validateComputeRule(operands(MAX_ARITH_OPERANDS + 1), { fieldKeys, targetType: 'number' });
  assert.equal(r.ok, false);
  assert.equal(r.code, 'too_many_operands');
  assert.match(r.detail, new RegExp(String(MAX_ARITH_OPERANDS)));
});

test('accepts lookup.table at the limit and rejects one past it', () => {
  assert.equal(validateComputeRule(lookupRows(MAX_LOOKUP_ROWS), { fieldKeys, targetType: 'string' }).ok, true);
  const r = validateComputeRule(lookupRows(MAX_LOOKUP_ROWS + 1), { fieldKeys, targetType: 'string' });
  assert.equal(r.ok, false);
  assert.equal(r.code, 'too_many_lookup_rows');
  assert.match(r.detail, new RegExp(String(MAX_LOOKUP_ROWS)));
});

// ── Malformed entries ───────────────────────────────────────────────────────
// Every caller is written against the {ok:false, code} contract and several of
// them run before their route opens a transaction, outside its try/catch. A
// throw from here is therefore not a 500 — it escapes an async handler as an
// unhandled rejection and takes the process down. The entries arrive straight
// from an uploaded payload, so anything JSON can express has to land on a
// rejection instead of a property read.
const MALFORMED_ENTRIES = [
  ['null', null],
  ['a number', 42],
  ['a string', 'x'],
  ['an array', []],
  ['a boolean', true],
];

for (const [label, entry] of MALFORMED_ENTRIES) {
  test(`rejects ${label} in concat.parts without throwing`, () => {
    const rule = { op: 'concat', overridable: true, output_type: 'string',
      config: { parts: [{ type: 'field', key: 'model' }, entry] } };
    const r = validateComputeRule(rule, { fieldKeys, targetType: 'string' });
    assert.equal(r.ok, false);
    assert.equal(r.code, 'bad_config');
  });

  test(`rejects ${label} in arith.operands without throwing`, () => {
    const rule = { op: 'arith', overridable: true, output_type: 'number',
      config: { operator: 'add', operands: [{ type: 'literal', value: 1 }, entry] } };
    const r = validateComputeRule(rule, { fieldKeys, targetType: 'number' });
    assert.equal(r.ok, false);
    assert.equal(r.code, 'bad_config');
  });

  test(`rejects ${label} in lookup.table without throwing`, () => {
    const rule = { op: 'lookup', overridable: true, output_type: 'string',
      config: { source: 'model', table: [{ in: 'a', out: 'b' }, entry] } };
    const r = validateComputeRule(rule, { fieldKeys, targetType: 'string' });
    assert.equal(r.ok, false);
    assert.equal(r.code, 'bad_config');
  });
}

test('a malformed entry is rejected wherever it sits in the array', () => {
  const rule = { op: 'concat', overridable: true, output_type: 'string',
    config: { parts: [null, { type: 'field', key: 'model' }] } };
  assert.equal(validateComputeRule(rule, { fieldKeys, targetType: 'string' }).code, 'bad_config');
});

test('the oversize check runs before the per-entry walk', () => {
  // An oversize array must be rejected on its length alone; walking it first
  // would pay exactly the cost the bound exists to prevent.
  const rule = parts(MAX_CONCAT_PARTS + 1);
  let touched = 0;
  const counted = rule.config.parts.map((p) => new Proxy(p, {
    get(target, prop) { touched += 1; return target[prop]; },
  }));
  const r = validateComputeRule(
    { ...rule, config: { parts: counted } },
    { fieldKeys, targetType: 'string' },
  );
  assert.equal(r.code, 'too_many_parts');
  assert.equal(touched, 0);
});
