/**
 * blueprint-copy-subset-helpers.test.js — the pure functions behind the copy
 * wizard's write path: the key-suggestion suffix generator, the compute-rule
 * source rewriter, and the snapshot fingerprint. No DB, no transaction —
 * `blueprint-copy-subset.test.js` (integration) covers the route + write.
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');

const dbKey = require.resolve('../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: {}, t: (n) => n, getDynamicPool: async () => ({ rw: {}, ro: {} }) },
};

const {
  suggestUniqueKey,
  rewriteRuleSources,
  fieldSnapshotFingerprint,
} = require('../../src/edge/lib/blueprint-copy-subset');

describe('suggestUniqueKey', () => {
  it('proposes the base key unchanged when it is free', () => {
    assert.equal(suggestUniqueKey('name', new Set(['other'])), 'name');
  });

  it('appends _2 on a single collision', () => {
    assert.equal(suggestUniqueKey('name', new Set(['name'])), 'name_2');
  });

  it('walks past consecutive taken suffixes: name_2, name_3, ...', () => {
    const taken = new Set(['name', 'name_2', 'name_3']);
    assert.equal(suggestUniqueKey('name', taken), 'name_4');
  });

  it('is case-insensitive, matching the field_key index collation (caller lower-cases takenLower)', () => {
    const taken = new Set(['name']);
    assert.equal(suggestUniqueKey('NAME', taken), 'NAME_2');
    const taken2 = new Set(['name', 'name_2']);
    assert.equal(suggestUniqueKey('NAME', taken2), 'NAME_3');
  });
});

describe('rewriteRuleSources', () => {
  const keyMap = new Map([['old_field', 'old_field_2'], ['other_table', 'other_table_2']]);

  it('rewrites a transform rule\'s single field source', () => {
    const rule = { op: 'transform', overridable: true, output_type: 'string', config: { source: 'old_field', transform: 'upper' } };
    const out = rewriteRuleSources(rule, keyMap);
    assert.equal(out.config.source, 'old_field_2');
    assert.equal(rule.config.source, 'old_field', 'the input rule must not be mutated');
  });

  it('rewrites a concat rule\'s field/table_cell/table_column_lookup terms', () => {
    const rule = {
      op: 'concat', overridable: true, output_type: 'string',
      config: {
        parts: [
          { type: 'field', key: 'old_field' },
          { type: 'literal', value: '-' },
          { type: 'table_cell', cell: { table_key: 'other_table', column_key: 'value', row: 'first' } },
          { type: 'table_column_lookup', lookupRef: { table_key: 'other_table', matchKeyColumn: 'k', ownKeyColumn: 'own', valueColumn: 'v' } },
        ],
      },
    };
    const out = rewriteRuleSources(rule, keyMap);
    assert.equal(out.config.parts[0].key, 'old_field_2');
    assert.equal(out.config.parts[2].cell.table_key, 'other_table_2');
    assert.equal(out.config.parts[3].lookupRef.table_key, 'other_table_2');
  });

  it('does NOT rewrite same_table_column or a lookup\'s matchKeyColumn/valueColumn/ownKeyColumn', () => {
    const rule = {
      op: 'arith', overridable: true, output_type: 'number',
      config: {
        operator: 'add',
        operands: [
          { type: 'same_table_column', column_key: 'old_field' },
          { type: 'table_column_lookup', lookupRef: { table_key: 'other_table', matchKeyColumn: 'old_field', ownKeyColumn: 'old_field', valueColumn: 'old_field' } },
        ],
      },
    };
    const out = rewriteRuleSources(rule, keyMap);
    assert.equal(out.config.operands[0].column_key, 'old_field', 'same_table_column names an internal column, not a field_key');
    assert.equal(out.config.operands[1].lookupRef.matchKeyColumn, 'old_field');
    assert.equal(out.config.operands[1].lookupRef.ownKeyColumn, 'old_field');
    assert.equal(out.config.operands[1].lookupRef.valueColumn, 'old_field');
    assert.equal(out.config.operands[1].lookupRef.table_key, 'other_table_2', 'the OTHER table\'s table_key is still rewritten');
  });

  it('leaves a source outside keyMap untouched', () => {
    const rule = { op: 'transform', overridable: true, output_type: 'string', config: { source: 'untouched_field', transform: 'upper' } };
    const out = rewriteRuleSources(rule, keyMap);
    assert.equal(out.config.source, 'untouched_field');
  });
});

describe('fieldSnapshotFingerprint', () => {
  function baseRow(overrides = {}) {
    return {
      field_key: 'trim', field_label: 'Trim', field_type: 'text', is_required: 0,
      default_value: '', placeholder: '', tooltip: '', section: 'general',
      order_index: 0, table_config: null, visibility_rule: null,
      depends_on_field_key: null, retain_when_hidden: 0, choice_config: null,
      value_source: 'entered', value_scope: null, compute_rule: null,
      ...overrides,
    };
  }

  it('is stable for an unchanged row', () => {
    assert.equal(fieldSnapshotFingerprint(baseRow()), fieldSnapshotFingerprint(baseRow()));
  });

  it('changes when the field_key (rename) changes', () => {
    assert.notEqual(fieldSnapshotFingerprint(baseRow()), fieldSnapshotFingerprint(baseRow({ field_key: 'trim2' })));
  });

  it('changes when the label changes', () => {
    assert.notEqual(fieldSnapshotFingerprint(baseRow()), fieldSnapshotFingerprint(baseRow({ field_label: 'Trim Level' })));
  });

  it('changes when the compute_rule changes', () => {
    const rule = JSON.stringify({ op: 'transform', config: { source: 'x', transform: 'upper' } });
    assert.notEqual(fieldSnapshotFingerprint(baseRow()), fieldSnapshotFingerprint(baseRow({ compute_rule: rule })));
  });

  it('is representation-independent: an object-shaped JSON column and its equivalent stored string fingerprint the same', () => {
    const asObject = baseRow({ table_config: { columns: [{ key: 'a' }] } });
    const asString = baseRow({ table_config: '{"columns":[{"key":"a"}]}' });
    assert.equal(fieldSnapshotFingerprint(asObject), fieldSnapshotFingerprint(asString));
  });
});
