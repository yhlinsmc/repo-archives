/**
 * capacity-config-import.test.js — the PURE config-import engine (spec §3.3 A2 /
 * §9). buildConfigImportPlan does no I/O, so the security-critical parse/validate/
 * resolve logic is unit-testable without a DB: sheet + column allow-list, cell
 * coercion, FK ref/name resolution with minted ids, the allowed_disk_combos
 * remap, the global-rule guard, and the size cap.
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const {
  buildConfigImportPlan, configImportPayloadTooLarge, MAX_IMPORT_BYTES,
} = require('../../src/edge/routes/app/capacity/config-import');

const codes = (report) => report.errors.map((e) => e.code);
const noticeCodes = (report) => report.notices.map((n) => n.code);

describe('buildConfigImportPlan — happy path', () => {
  it('an empty payload is ok with a zero summary', () => {
    const r = buildConfigImportPlan({ schema_rev: 1, tables: {} });
    assert.equal(r.ok, true);
    assert.equal(r.summary.hardware_specs, 0);
    assert.equal(r.schemaRevMatch, true);
  });

  it('round-trips a catalogue set, minting ids and resolving FK-by-ref', () => {
    const r = buildConfigImportPlan({
      schema_rev: 1,
      tables: {
        disk_combos: [{ ref: 'd-1', name: 'OS + Data', sizes: '[512,2048]' }],
        teams: [{ ref: 't-1', name: 'Payments', color: '#36f' }],
        vm_profiles: [{ ref: 'p-1', name: 'DB-16C', class: 'DB', mode: 'formula', cpu: 16, allowed_disk_combos: '["d-1"]' }],
        bundles: [{ ref: 'b-1', name: 'Core', serial: 1 }],
        bundle_items: [{ ref: 'bi-1', bundle_ref: 'b-1', profile_ref: 'p-1', disk_combo_ref: 'd-1', team_ref: 't-1', type: 'DB', qty: 1, topology: 'primary_standby', primary_sga_gb: 96, standby_sga_gb: 48 }],
      },
    });
    assert.deepEqual(r.errors, [], JSON.stringify(r.errors));
    assert.equal(r.ok, true);
    // Minted ids: the item's bundle_id points at the minted bundle id (not 'b-1').
    const combo = r.plan.disk_combos[0];
    const profile = r.plan.vm_profiles[0];
    const bundle = r.plan.bundles[0];
    const item = r.plan.bundle_items[0];
    assert.notEqual(bundle.id, 'b-1');
    assert.equal(item.dbRow.bundle_id, bundle.id);
    assert.equal(item.dbRow.profile_id, profile.id);
    assert.equal(item.dbRow.disk_combo_id, combo.id);
    assert.equal(item.dbRow.primary_sga_gb, 96);
    // allowed_disk_combos is remapped to the minted disk-combo id.
    assert.equal(profile.dbRow.allowed_disk_combos, JSON.stringify([combo.id]));
    assert.equal(r.summary.bundle_items, 1);
  });

  it('resolves FK-by-name when no ref twin is present', () => {
    const r = buildConfigImportPlan({
      tables: {
        bundles: [{ name: 'Core', serial: 1 }],
        bundle_items: [{ bundle_name: 'Core', type: 'AP', qty: 2 }],
      },
    });
    assert.deepEqual(r.errors, [], JSON.stringify(r.errors));
    assert.equal(r.plan.bundle_items[0].dbRow.bundle_id, r.plan.bundles[0].id);
  });
});

describe('buildConfigImportPlan — allow-list + hardening', () => {
  it('rejects an unknown sheet key', () => {
    const r = buildConfigImportPlan({ tables: { secrets: [{ token: 'x' }] } });
    assert.equal(r.ok, false);
    assert.ok(codes(r).includes('UNKNOWN_SHEET'));
  });

  it('drops an unknown column with a warning but keeps the row valid', () => {
    const r = buildConfigImportPlan({ tables: { teams: [{ name: 'Ops', color: '#111', evil_col: 'DROP TABLE' }] } });
    assert.equal(r.ok, true);
    assert.ok(noticeCodes(r).includes('DROPPED_COLUMN'));
    assert.equal(r.plan.teams[0].dbRow.evil_col, undefined);
  });

  it('never carries a client id as the primary key (id is minted)', () => {
    const r = buildConfigImportPlan({ tables: { teams: [{ id: 'attacker-chosen', name: 'Ops', color: '#111' }] } });
    assert.equal(r.ok, true);
    assert.notEqual(r.plan.teams[0].id, 'attacker-chosen');
    assert.equal(r.plan.teams[0].dbRow.id, undefined);
    assert.equal(r.plan.teams[0].dbRow.scenario_id, undefined);
  });

  it('flags a missing required field', () => {
    const r = buildConfigImportPlan({ tables: { hardware_specs: [{ cpu_total: 8 }] } });
    assert.equal(r.ok, false);
    assert.ok(codes(r).includes('MISSING_FIELD'));
  });

  it('flags a bad number / enum / json', () => {
    const r = buildConfigImportPlan({
      tables: {
        hardware_specs: [{ name: 'H', cpu_total: 'lots' }],
        vm_profiles: [{ name: 'P', class: 'ZZ', mode: 'formula', cpu: 4 }],
        disk_combos: [{ name: 'D', sizes: '{not json' }],
      },
    });
    assert.equal(r.ok, false);
    assert.ok(codes(r).includes('INVALID_NUMBER'));
    assert.ok(codes(r).includes('INVALID_ENUM'));
    assert.ok(codes(r).includes('INVALID_JSON'));
  });

  it('does not evaluate a formula-looking string cell (treated as literal data)', () => {
    const r = buildConfigImportPlan({ tables: { teams: [{ name: '=1+2', color: '@SUM(A1)' }] } });
    assert.equal(r.ok, true);
    assert.equal(r.plan.teams[0].dbRow.name, '=1+2');
    assert.equal(r.plan.teams[0].dbRow.color, '@SUM(A1)');
  });

  it('rejects an unresolved bundle-item FK', () => {
    const r = buildConfigImportPlan({ tables: { bundle_items: [{ bundle_ref: 'ghost', type: 'DB', qty: 1 }] } });
    assert.equal(r.ok, false);
    assert.ok(codes(r).includes('UNRESOLVED_REF'));
  });

  it('rejects an allowed_disk_combos id not present in the import', () => {
    const r = buildConfigImportPlan({
      tables: { vm_profiles: [{ name: 'P', class: 'DB', mode: 'formula', cpu: 8, allowed_disk_combos: '["missing"]' }] },
    });
    assert.equal(r.ok, false);
    assert.ok(codes(r).includes('UNRESOLVED_REF'));
  });

  it('rejects a global rule carrying an override / custom-group reference', () => {
    const r = buildConfigImportPlan({
      tables: { rules: [{ name: 'R', type: 'keep-apart', level: 'db_instance', group_by: 'each_primary_cluster', overrides_rule_name: 'other' }] },
    });
    assert.equal(r.ok, false);
    assert.ok(codes(r).includes('INVALID_GLOBAL_RULE'));
  });

  it('rejects a rule with an illegal type/level combination (reuses the write-path guard)', () => {
    const r = buildConfigImportPlan({
      tables: { rules: [{ name: 'R', type: 'no-oversell', level: 'db_instance' }] },
    });
    assert.equal(r.ok, false);
  });

  it('rejects more than one settings row (singleton)', () => {
    const r = buildConfigImportPlan({ tables: { settings: [{ mem_cpu_ratio: 20 }, { mem_cpu_ratio: 24 }] } });
    assert.equal(r.ok, false);
    assert.ok(codes(r).includes('DUPLICATE'));
  });

  it('rejects a reserved metadata custom-field key (prototype pollution guard)', () => {
    const r = buildConfigImportPlan({ tables: { teams: [{ name: 'X', color: '#111' }], hardware_specs: [{ name: 'H', 'cf:__proto__': 'x' }] } });
    assert.equal(r.ok, false);
    assert.ok(codes(r).includes('RESERVED_FIELD_KEY'));
  });

  it('flags a schema_rev mismatch without failing (advisory)', () => {
    const r = buildConfigImportPlan({ schema_rev: 999, tables: { teams: [{ name: 'X', color: '#111' }] } });
    assert.equal(r.schemaRevMatch, false);
    assert.equal(r.ok, true);
  });

  it('caps a too-many-rows sheet', () => {
    const rows = Array.from({ length: 10001 }, (_, i) => ({ name: `t${i}`, color: '#111' }));
    const r = buildConfigImportPlan({ tables: { teams: rows } });
    assert.equal(r.ok, false);
    assert.ok(codes(r).includes('TOO_MANY_ROWS'));
  });
});

describe('buildConfigImportPlan — bundle items obey the direct-write validation (Fix 3)', () => {
  it('rejects an AP item carrying SGA (DB-only, reuses sgaDbOnlyError)', () => {
    const r = buildConfigImportPlan({
      tables: {
        bundles: [{ ref: 'b-1', name: 'Core', serial: 1 }],
        bundle_items: [{ bundle_ref: 'b-1', type: 'AP', qty: 1, primary_sga_gb: 16 }],
      },
    });
    assert.equal(r.ok, false);
    assert.ok(codes(r).includes('INVALID_ITEM_SGA'), JSON.stringify(r.errors));
  });

  it('rejects a RAC item without a node_count (reuses topologyNodeCountError)', () => {
    const r = buildConfigImportPlan({
      tables: {
        bundles: [{ ref: 'b-1', name: 'Core', serial: 1 }],
        bundle_items: [{ bundle_ref: 'b-1', type: 'DB', qty: 1, topology: 'rac' }],
      },
    });
    assert.equal(r.ok, false);
    assert.ok(codes(r).includes('INVALID_ITEM_TOPOLOGY'), JSON.stringify(r.errors));
  });

  it('rejects an item.type that mismatches the referenced profile class (reuses itemProfileClassError)', () => {
    const r = buildConfigImportPlan({
      tables: {
        bundles: [{ ref: 'b-1', name: 'Core', serial: 1 }],
        vm_profiles: [{ ref: 'p-ap', name: 'AP-4C', class: 'AP', mode: 'formula', cpu: 4 }],
        bundle_items: [{ bundle_ref: 'b-1', profile_ref: 'p-ap', type: 'DB', qty: 1, topology: 'single' }],
      },
    });
    assert.equal(r.ok, false);
    assert.ok(codes(r).includes('INVALID_REFERENCE'), JSON.stringify(r.errors));
  });

  it('rejects a disk combo not in the profile allow-list (reuses diskComboAllowed)', () => {
    const r = buildConfigImportPlan({
      tables: {
        bundles: [{ ref: 'b-1', name: 'Core', serial: 1 }],
        disk_combos: [
          { ref: 'd-ok', name: 'Allowed', sizes: '[512]' },
          { ref: 'd-bad', name: 'Forbidden', sizes: '[1024]' },
        ],
        // The profile's allow-list is non-empty and excludes d-bad.
        vm_profiles: [{ ref: 'p-1', name: 'DB-8C', class: 'DB', mode: 'formula', cpu: 8, allowed_disk_combos: '["d-ok"]' }],
        bundle_items: [{ bundle_ref: 'b-1', profile_ref: 'p-1', disk_combo_ref: 'd-bad', type: 'DB', qty: 1, topology: 'single' }],
      },
    });
    assert.equal(r.ok, false);
    assert.ok(codes(r).includes('DISK_COMBO_NOT_ALLOWED'), JSON.stringify(r.errors));
  });

  it('accepts a DB item whose combo IS in the profile allow-list', () => {
    const r = buildConfigImportPlan({
      tables: {
        bundles: [{ ref: 'b-1', name: 'Core', serial: 1 }],
        disk_combos: [{ ref: 'd-ok', name: 'Allowed', sizes: '[512]' }],
        vm_profiles: [{ ref: 'p-1', name: 'DB-8C', class: 'DB', mode: 'formula', cpu: 8, allowed_disk_combos: '["d-ok"]' }],
        bundle_items: [{ bundle_ref: 'b-1', profile_ref: 'p-1', disk_combo_ref: 'd-ok', type: 'DB', qty: 1, topology: 'primary_standby' }],
      },
    });
    assert.deepEqual(r.errors, [], JSON.stringify(r.errors));
    assert.equal(r.ok, true);
  });
});

// D12d + AR2-Q8: the PERMANENT legacy alias applies to config import
// too — an old-spelled `rac`/`rac_standby` bundle_items.topology cell keeps
// importing, storing only the new `rac_multinode`/`rac_multinode_standby` value.
// AR2-Q8 widened bundle items to the full domain, so `rac_standby` is now an
// accepted (aliased) bundle-item topology, not a rejected one.
describe('buildConfigImportPlan — D12d legacy topology alias (old workbook, new stored value)', () => {
  it('an old-spelled `rac` cell imports cleanly and stores the NEW `rac_multinode` value', () => {
    const r = buildConfigImportPlan({
      tables: {
        bundles: [{ ref: 'b-1', name: 'Core', serial: 1 }],
        bundle_items: [{ bundle_ref: 'b-1', type: 'DB', qty: 1, topology: 'rac', node_count: 3 }],
      },
    });
    assert.equal(r.ok, true, JSON.stringify(r.errors));
    const item = r.plan.bundle_items[0];
    assert.equal(item.dbRow.topology, 'rac_multinode');
  });

  it('a value with no legacy mapping (single/primary/primary_standby) is untouched by the alias', () => {
    const r = buildConfigImportPlan({
      tables: {
        bundles: [{ ref: 'b-1', name: 'Core', serial: 1 }],
        bundle_items: [{ bundle_ref: 'b-1', type: 'DB', qty: 1, topology: 'primary_standby' }],
      },
    });
    assert.equal(r.ok, true, JSON.stringify(r.errors));
    assert.equal(r.plan.bundle_items[0].dbRow.topology, 'primary_standby');
  });

  it('AR2-Q8: the OLD `rac_standby` cell now imports cleanly and stores the NEW `rac_multinode_standby` value', () => {
    const r = buildConfigImportPlan({
      tables: {
        bundles: [{ ref: 'b-1', name: 'Core', serial: 1 }],
        bundle_items: [{ bundle_ref: 'b-1', type: 'DB', qty: 1, topology: 'rac_standby', node_count: 3, standby_node_count: 2 }],
      },
    });
    assert.equal(r.ok, true, JSON.stringify(r.errors));
    const item = r.plan.bundle_items[0];
    assert.equal(item.dbRow.topology, 'rac_multinode_standby');
    assert.equal(item.dbRow.standby_node_count, 2);
  });

  it('AR2-Q8 round-trip: an EXPORTED rac_multinode_standby bundle item (new spelling + S) re-imports with both counts intact', () => {
    // Mirrors what a config export emits (io.js bundle_items sheet: numbers now
    // include standby_node_count) — the re-import must preserve topology, N and S.
    const r = buildConfigImportPlan({
      tables: {
        bundles: [{ ref: 'b-1', name: 'Core', serial: 1 }],
        bundle_items: [{ bundle_ref: 'b-1', type: 'DB', qty: 1, topology: 'rac_multinode_standby', node_count: 5, standby_node_count: 3 }],
      },
    });
    assert.equal(r.ok, true, JSON.stringify(r.errors));
    const item = r.plan.bundle_items[0];
    assert.equal(item.dbRow.topology, 'rac_multinode_standby');
    assert.equal(item.dbRow.node_count, 5);
    assert.equal(item.dbRow.standby_node_count, 3);
  });

  it('AR2-Q8: a standby_node_count on a NON-standby bundle topology is rejected (coupling)', () => {
    const r = buildConfigImportPlan({
      tables: {
        bundles: [{ ref: 'b-1', name: 'Core', serial: 1 }],
        bundle_items: [{ bundle_ref: 'b-1', type: 'DB', qty: 1, topology: 'rac_multinode', node_count: 3, standby_node_count: 2 }],
      },
    });
    assert.equal(r.ok, false);
    assert.ok(codes(r).includes('INVALID_ITEM_TOPOLOGY'), JSON.stringify(r.errors));
  });

  // M4 (TOPO-R2 fix batch): a rac_multinode_standby member with the
  // standby_node_count CELL ABSENT (not present, not empty-string — the key
  // itself is missing from the row object, as an older workbook predating the
  // column would produce) — `isEmpty(row[col])` skips it, so dbRow never gets
  // the key at all; topologyNodeCountError reads that as NULL (optional,
  // derives S=N downstream) and the import passes clean.
  it('AR2-Q8: a rac_multinode_standby member with standby_node_count ABSENT derives NULL, imports clean', () => {
    const r = buildConfigImportPlan({
      tables: {
        bundles: [{ ref: 'b-1', name: 'Core', serial: 1 }],
        bundle_items: [{ bundle_ref: 'b-1', type: 'DB', qty: 1, topology: 'rac_multinode_standby', node_count: 4 }],
      },
    });
    assert.equal(r.ok, true, JSON.stringify(r.errors));
    const item = r.plan.bundle_items[0];
    assert.equal(item.dbRow.topology, 'rac_multinode_standby');
    assert.equal(item.dbRow.node_count, 4);
    assert.equal(item.dbRow.standby_node_count, undefined, 'the cell was absent — dbRow carries no key, never a stray null/0');
  });

  // M4: a legacy 4-value export (predating the AR2-Q8 widen entirely — the
  // sheet's row object carries no standby_node_count key AT ALL, same as a
  // pre-widen `rac_multinode` bundle item) still imports clean through
  // buildConfigImportPlan.
  it('a legacy 4-value bundle_items export shape (no standby_node_count key) imports clean', () => {
    const r = buildConfigImportPlan({
      tables: {
        bundles: [{ ref: 'b-1', name: 'Core', serial: 1 }],
        bundle_items: [{ bundle_ref: 'b-1', type: 'DB', qty: 1, topology: 'rac_multinode', node_count: 3 }],
      },
    });
    assert.equal(r.ok, true, JSON.stringify(r.errors));
    const item = r.plan.bundle_items[0];
    assert.equal(item.dbRow.topology, 'rac_multinode');
    assert.equal(item.dbRow.node_count, 3);
    assert.equal(item.dbRow.standby_node_count, undefined);
  });
});

describe('buildConfigImportPlan — bundle/settings/field_defs numeric + uniqueness (Codex r2 P2)', () => {
  it('P2-1: rejects a non-integer / <1 bundle serial (reuses validateBundleHeader)', () => {
    const r = buildConfigImportPlan({ tables: { bundles: [{ name: 'Core', serial: 0 }] } });
    assert.equal(r.ok, false);
    assert.ok(codes(r).includes('INVALID_BUNDLE'), JSON.stringify(r.errors));
  });

  it('P2-1: rejects a duplicate serial WITHIN the import', () => {
    const r = buildConfigImportPlan({ tables: { bundles: [
      { ref: 'b1', name: 'A', serial: 1 },
      { ref: 'b2', name: 'B', serial: 1 },
    ] } });
    assert.equal(r.ok, false);
    assert.ok(codes(r).includes('DUPLICATE_SERIAL'), JSON.stringify(r.errors));
  });

  it('P2-1: rejects a bundle-item qty below 1 (reuses validateItemBody)', () => {
    const r = buildConfigImportPlan({ tables: {
      bundles: [{ ref: 'b1', name: 'A', serial: 1 }],
      bundle_items: [{ bundle_ref: 'b1', type: 'AP', qty: 0 }],
    } });
    assert.equal(r.ok, false);
    assert.ok(codes(r).includes('INVALID_ITEM'), JSON.stringify(r.errors));
  });

  it('P2-1: rejects a RAC node_count below 2 (reuses validateItemBody)', () => {
    const r = buildConfigImportPlan({ tables: {
      bundles: [{ ref: 'b1', name: 'A', serial: 1 }],
      bundle_items: [{ bundle_ref: 'b1', type: 'DB', topology: 'rac', node_count: 1 }],
    } });
    assert.equal(r.ok, false);
    assert.ok(codes(r).includes('INVALID_ITEM'), JSON.stringify(r.errors));
  });

  it('P2-2: rejects a negative standby_sga_default_gb (reuses validateSettingsWrite)', () => {
    const r = buildConfigImportPlan({ tables: { settings: [{ mem_cpu_ratio: 20, standby_sga_default_gb: -8 }] } });
    assert.equal(r.ok, false);
    assert.ok(codes(r).includes('INVALID_SETTINGS'), JSON.stringify(r.errors));
  });

  it('P2-3: rejects a duplicate (entity_type, field_key) among imported field_defs', () => {
    const r = buildConfigImportPlan({ tables: { field_defs: [
      { entity_type: 'vm', field_key: 'owner', data_type: 'text' },
      { entity_type: 'vm', field_key: 'owner', data_type: 'text' },
    ] } });
    assert.equal(r.ok, false);
    assert.ok(codes(r).includes('DUPLICATE_FIELD_DEF'), JSON.stringify(r.errors));
  });

  it('accepts distinct field_defs and distinct bundle serials', () => {
    const r = buildConfigImportPlan({ tables: {
      bundles: [{ ref: 'b1', name: 'A', serial: 1 }, { ref: 'b2', name: 'B', serial: 2 }],
      field_defs: [
        { entity_type: 'vm', field_key: 'owner', data_type: 'text' },
        { entity_type: 'db_instance', field_key: 'owner', data_type: 'text' },
      ],
    } });
    assert.deepEqual(r.errors, [], JSON.stringify(r.errors));
    assert.equal(r.ok, true);
  });

  // review wave: the direct-write route (_shared.js validateFieldDefWrite)
  // refuses a field_key colliding with its entity_type's own native column, but
  // this import path never consulted the same guard.
  it('rejects a field_def whose field_key collides with a native column of its entity_type, and writes nothing', () => {
    const r = buildConfigImportPlan({ tables: { field_defs: [
      { entity_type: 'database', field_key: 'primary_sga_gb', data_type: 'number' },
    ] } });
    assert.equal(r.ok, false);
    assert.ok(codes(r).includes('NATIVE_KEY_COLLISION'), JSON.stringify(r.errors));
    // buildConfigImportPlan is pure and always returns a dry-run plan (even for
    // an invalid one, for the validate-mode report) — the "nothing written"
    // guarantee lives in the commit route, which checks report.ok before
    // touching the DB (config-import.js: `if (!report.ok) return res.status(422)`).
    // r.ok === false is what that check reads.
  });

  it('accepts a field_def whose field_key does NOT collide, even for an entity_type that has other native columns', () => {
    const r = buildConfigImportPlan({ tables: { field_defs: [
      { entity_type: 'database', field_key: 'rack_units', data_type: 'number' },
    ] } });
    assert.equal(r.ok, true, JSON.stringify(r.errors));
    assert.equal(codes(r).includes('NATIVE_KEY_COLLISION'), false);
  });
});

describe('buildConfigImportPlan — disk-combo name validation (fmb-1342 #13, mirrors DiskCombosCard)', () => {
  it('rejects a disk-combo name containing a comma (would corrupt the CSV allow-list encoding)', () => {
    const r = buildConfigImportPlan({ tables: { disk_combos: [{ name: 'OS, Data', sizes: '[512]' }] } });
    assert.equal(r.ok, false);
    assert.ok(codes(r).includes('INVALID_DISK_COMBO_NAME'), JSON.stringify(r.errors));
    // No partial insert: the commit route short-circuits to 422 on !ok before any
    // writeConfigPlan call, so nothing reaches the DB.
  });

  it('rejects duplicate disk-combo names within the import (case-insensitive, like the grid)', () => {
    const r = buildConfigImportPlan({ tables: { disk_combos: [
      { ref: 'd1', name: 'OS + Data', sizes: '[512]' },
      { ref: 'd2', name: 'os + data', sizes: '[1024]' },
    ] } });
    assert.equal(r.ok, false);
    assert.ok(codes(r).includes('DUPLICATE_DISK_COMBO_NAME'), JSON.stringify(r.errors));
  });

  it('trims before the case-insensitive duplicate check (` os ` collides with `OS`, like the grid)', () => {
    const r = buildConfigImportPlan({ tables: { disk_combos: [
      { ref: 'd1', name: 'OS', sizes: '[512]' },
      { ref: 'd2', name: ' os ', sizes: '[1024]' },
    ] } });
    assert.equal(r.ok, false);
    assert.ok(codes(r).includes('DUPLICATE_DISK_COMBO_NAME'), JSON.stringify(r.errors));
  });

  it('accepts distinct comma-free disk-combo names', () => {
    const r = buildConfigImportPlan({ tables: { disk_combos: [
      { ref: 'd1', name: 'OS + Data', sizes: '[512]' },
      { ref: 'd2', name: 'OS + Redo', sizes: '[1024]' },
    ] } });
    assert.deepEqual(r.errors, [], JSON.stringify(r.errors));
    assert.equal(r.ok, true);
  });
});

describe('configImportPayloadTooLarge', () => {
  it('accepts a small payload and rejects an oversized one', () => {
    assert.equal(configImportPayloadTooLarge({ teams: [{ name: 'x' }] }), false);
    const big = { teams: [{ name: 'x'.repeat(MAX_IMPORT_BYTES) }] };
    assert.equal(configImportPayloadTooLarge(big), true);
  });
});

// codex r2 P2: export includes order_index (a plain SELECT * column) for the
// reorderable global catalogues, but import previously dropped it as an unknown
// column and reinserted every row at the DEFAULT 0 — an export→import round
// trip silently lost the persisted drag order. buildConfigImportPlan is the
// PURE engine writeConfigPlan consumes verbatim, so asserting on r.plan here
// proves the round trip end-to-end without a DB.
describe('buildConfigImportPlan — order_index round-trip (codex r2 P2)', () => {
  it('a re-imported export with a non-default drag order is preserved verbatim (teams)', () => {
    // Simulates re-importing an export of a catalogue the user already
    // drag-reordered: row 0 in the sheet now carries order_index 2, not 0.
    const r = buildConfigImportPlan({
      tables: {
        teams: [
          { ref: 't-c', name: 'Charlie', color: '#111', order_index: 2 },
          { ref: 't-a', name: 'Alpha', color: '#222', order_index: 0 },
          { ref: 't-b', name: 'Bravo', color: '#333', order_index: 1 },
        ],
      },
    });
    assert.deepEqual(r.errors, [], JSON.stringify(r.errors));
    assert.equal(r.plan.teams[0].dbRow.order_index, 2);
    assert.equal(r.plan.teams[1].dbRow.order_index, 0);
    assert.equal(r.plan.teams[2].dbRow.order_index, 1);
  });

  it('an older export with no order_index column seeds sequential indices from row position (hardware_specs)', () => {
    const r = buildConfigImportPlan({
      tables: {
        hardware_specs: [
          { ref: 'h1', name: 'Standard' },
          { ref: 'h2', name: 'Large' },
          { ref: 'h3', name: 'XL' },
        ],
      },
    });
    assert.deepEqual(r.errors, [], JSON.stringify(r.errors));
    assert.deepEqual(r.plan.hardware_specs.map((b) => b.dbRow.order_index), [0, 1, 2]);
  });

  it('round-trips a non-default order for disk_combos, vm_profiles and bundles too', () => {
    const r = buildConfigImportPlan({
      tables: {
        disk_combos: [{ ref: 'd1', name: 'OS', sizes: '[512]', order_index: 5 }],
        vm_profiles: [{ ref: 'p1', name: 'DB-16C', class: 'DB', mode: 'formula', cpu: 16, order_index: 3 }],
        bundles: [{ ref: 'b1', name: 'Core', serial: 1, order_index: 7 }],
      },
    });
    assert.deepEqual(r.errors, [], JSON.stringify(r.errors));
    assert.equal(r.plan.disk_combos[0].dbRow.order_index, 5);
    assert.equal(r.plan.vm_profiles[0].dbRow.order_index, 3);
    assert.equal(r.plan.bundles[0].dbRow.order_index, 7);
  });

  it('a bad order_index cell is rejected the same as any other numeric column', () => {
    const r = buildConfigImportPlan({ tables: { teams: [{ name: 'Ops', color: '#111', order_index: 'not-a-number' }] } });
    assert.equal(r.ok, false);
    assert.ok(codes(r).includes('INVALID_NUMBER'), JSON.stringify(r.errors));
  });

  it('bundle_items (out of this fix\'s scope) is untouched: an absent order_index stays absent, not sequentially seeded', () => {
    const r = buildConfigImportPlan({
      tables: { bundle_items: [{ bundle_name: 'Core', type: 'AP', qty: 2 }] },
    });
    assert.equal(Object.prototype.hasOwnProperty.call(r.plan.bundle_items[0].dbRow, 'order_index'), false);
  });
});

describe('buildConfigImportPlan — name_patterns (C3)', () => {
  const baseSettings = {
    mem_cpu_ratio: 20, sga_factor: 0.982, sga_divisor: 2, sga_subtract: 2,
    standby_sga_default_gb: 32, util_amber_pct: 80, util_red_pct: 90,
    overcommit_default_enabled: false,
  };

  it('retains a valid name_patterns override as a JSON column (round-trip)', () => {
    const patterns = {
      hypervisor: 'hv-{dc}-{seq:2}', kvm_host_primary: 'kvm-{dc}-{seq:2}', kvm_host_standby: 'kvms-{dc}-{seq:2}', ap_vm: 'ap-{seq:2}',
    };
    const r = buildConfigImportPlan({
      schema_rev: 1,
      tables: { settings: [{ ...baseSettings, name_patterns: patterns }] },
    });
    assert.deepEqual(codes(r), []);
    assert.equal(r.plan.settings[0].dbRow.name_patterns, JSON.stringify(patterns));
  });

  it('rejects an imported name_patterns set that breaks the boundary rules', () => {
    const r = buildConfigImportPlan({
      schema_rev: 1,
      tables: {
        settings: [{
          ...baseSettings,
          name_patterns: { hypervisor: 'hv-{nn}', kvm_host_primary: 'kvm-{seq:2}', kvm_host_standby: 'kvm-{seq:2}', ap_vm: 'ap-{seq:2}' },
        }],
      },
    });
    assert.ok(codes(r).includes('INVALID_SETTINGS'));
  });

  it('rejects an imported name_patterns with an extra key', () => {
    const r = buildConfigImportPlan({
      schema_rev: 1,
      tables: {
        settings: [{
          ...baseSettings,
          name_patterns: {
            hypervisor: 'hv-{seq:2}', kvm_host_primary: 'kvm-{seq:2}', kvm_host_standby: 'kvm-{seq:2}', ap_vm: 'ap-{seq:2}', evil: 'x-{seq}',
          },
        }],
      },
    });
    assert.ok(codes(r).includes('INVALID_SETTINGS'));
  });

  // cap-pattern-function (Task 2.2): an import carrying the pre-split legacy
  // single kvm_host key is rejected post-migration, same as a live settings
  // write — no separate leniency for the import boundary.
  it('rejects an imported name_patterns still carrying the legacy single kvm_host key', () => {
    const r = buildConfigImportPlan({
      schema_rev: 1,
      tables: {
        settings: [{
          ...baseSettings,
          name_patterns: { hypervisor: 'hv-{dc}-{seq:2}', kvm_host: 'kvm-{dc}-{seq:2}', ap_vm: 'ap-{seq:2}' },
        }],
      },
    });
    assert.ok(codes(r).includes('INVALID_SETTINGS'));
  });
});
