/**
 * blueprint-field-import-guard-column-cycle.test.js — P1b/P2 for the import
 * guard's pure validator: an imported blueprint is a SELF-CONTAINED payload
 * (every field arrives in the same array), so a cross-field or self-
 * referencing `same_table_column` cycle is fully expressible within one call
 * to `checkImportedBlueprintFields` — no DB, no HTTP.
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');

const { checkImportedBlueprintFields } = require('../../src/edge/lib/blueprint-field-import-guard');

const sameCol = (columnKey) => ({
  op: 'concat',
  overridable: true,
  output_type: 'string',
  config: { parts: [{ type: 'same_table_column', column_key: columnKey }] },
});

const itemsField = (overrides = {}) => ({
  field_key: 'items',
  field_type: 'table',
  table_config: { columns: [{ key: 'part' }, { key: 'sku' }] },
  value_source: 'calculated',
  ...overrides,
});

describe('checkImportedBlueprintFields — column-level cycle (P1b)', () => {
  it('rejects a same-table SELF-cycle: narrowed to a column that reads itself', () => {
    const { errors } = checkImportedBlueprintFields([
      itemsField({ value_scope: { columns: ['part'] }, compute_rule: sameCol('part') }),
    ]);
    assert.ok(
      errors.some((e) => /same-table column dependency cycle/.test(e)),
      `expected a same-table column cycle error, got: ${JSON.stringify(errors)}`,
    );
  });

  it('accepts a valid narrowed same_table_column rule reading a DIFFERENT column, no cycle', () => {
    const { errors, rules } = checkImportedBlueprintFields([
      itemsField({ value_scope: { columns: ['part'] }, compute_rule: sameCol('sku') }),
    ]);
    assert.deepEqual(errors, []);
    assert.equal(rules.size, 1);
  });

  it('rejects same_table_column with a 2-column scope — P2: EXACTLY one column', () => {
    const { errors } = checkImportedBlueprintFields([
      itemsField({ value_scope: { columns: ['part', 'sku'] }, compute_rule: sameCol('sku') }),
    ]);
    assert.ok(
      errors.some((e) => /same_table_column_requires_column_scope/.test(e)),
      `expected the scope-narrowing rejection, got: ${JSON.stringify(errors)}`,
    );
  });

  it('does not over-fire across two DIFFERENT table fields that each self-narrow the same way', () => {
    // 'itemsA'.p reads row.q of the SAME table (itemsA); 'itemsB'.p reads
    // row.q of ITS OWN table (itemsB). Two independent, non-crossing same-
    // table sub-graphs — same_table_column never crosses tables (a genuine
    // cross-field cycle needs a bridging 'field' reference, which neither
    // rule here carries) — so this pair must NOT be flagged.
    const { errors } = checkImportedBlueprintFields([
      {
        field_key: 'itemsA', field_type: 'table', value_source: 'calculated',
        table_config: { columns: [{ key: 'p' }, { key: 'q' }] },
        value_scope: { columns: ['p'] },
        compute_rule: sameCol('q'),
      },
      {
        field_key: 'itemsB', field_type: 'table', value_source: 'calculated',
        table_config: { columns: [{ key: 'p' }, { key: 'q' }] },
        value_scope: { columns: ['q'] },
        compute_rule: sameCol('p'),
      },
    ]);
    assert.deepEqual(errors, []);
  });
});
