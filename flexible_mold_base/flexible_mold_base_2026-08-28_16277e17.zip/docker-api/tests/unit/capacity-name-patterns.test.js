/**
 * capacity-name-patterns.test.js — the server-side hostname-pattern contract
 * (spec B5a): the all-or-nothing write validation, and PARITY of the server
 * DEFAULT_NAME_PATTERNS with the FE single formatter (hostname-pattern.ts). The
 * two defaults must stay byte-identical or a scenario that inherits would resolve
 * different names on the server than the client proposed.
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const {
  DEFAULT_NAME_PATTERNS, validateNamePatternsWrite, validatePattern,
  siteSlug, formatHostname, withBatchSeqWidth, resolveEffectiveNamePatterns,
  computeRenumberPlan, firstDuplicateName, duplicateNameFlags, firstOverlengthName,
  duplicateAllLockedFlags, computeInstanceClusterIndexes, dbInstanceName, computeDbInstanceRenumberPlan,
} = require('../../src/shared/capacity/name-patterns');

describe('validatePattern — all-or-nothing single pattern', () => {
  it('accepts {dc}/{seq}/{seq:N} patterns', () => {
    assert.equal(validatePattern('hv-{dc}-{seq:2}'), null);
    assert.equal(validatePattern('ap-{seq}'), null);
  });
  it('rejects empty, {nn}, unknown tokens, bad width, unbalanced braces', () => {
    assert.notEqual(validatePattern(''), null);
    assert.notEqual(validatePattern('hv-{dc}-{nn}'), null);
    assert.notEqual(validatePattern('hv-{index}'), null);
    assert.notEqual(validatePattern('hv-{seq:0}'), null);
    assert.notEqual(validatePattern('hv-{seq'), null);
  });
  // FIX-3 (lockstep with the FE): a pattern with no sequence token is rejected.
  it('rejects a pattern with no {seq} token', () => {
    assert.match(validatePattern('hv-{dc}'), /\{seq\}/);
    assert.notEqual(validatePattern('fixed'), null);
  });
  // FIX-1 (lockstep): length + token-count caps against nextSeq ReDoS.
  it('caps length at 64 and token groups at 8', () => {
    const at64 = `${'a'.repeat(64 - '-{seq}'.length)}-{seq}`;
    assert.equal(at64.length, 64);
    assert.equal(validatePattern(at64), null);
    assert.notEqual(validatePattern(`x${at64}`), null);
    assert.equal(validatePattern(`{seq}${'{dc}'.repeat(7)}`), null);
    assert.notEqual(validatePattern(`{seq}${'{dc}'.repeat(8)}`), null);
    assert.notEqual(validatePattern('{seq}'.repeat(300)), null);
  });

  // U4 (Q5-Q7): {db_seq}/{ap_seq}, with/without :N.
  describe('U4: {db_seq}/{ap_seq} tokens', () => {
    it('accepts {db_seq}/{ap_seq} alone — each satisfies require-a-sequencing-token on its own', () => {
      assert.equal(validatePattern('kvm-{db_seq}'), null);
      assert.equal(validatePattern('kvm-{db_seq:2}'), null);
      assert.equal(validatePattern('{function}-{ap_seq:3}'), null);
      assert.equal(validatePattern('kvm-{db_seq:2}-{ap_seq:2}'), null);
    });
    it('rejects a pad width out of 1..12 for db_seq/ap_seq, same as seq', () => {
      assert.notEqual(validatePattern('kvm-{db_seq:0}'), null);
      assert.notEqual(validatePattern('kvm-{db_seq:13}'), null);
      assert.notEqual(validatePattern('kvm-{ap_seq:0}'), null);
    });
    it('{dc} does not accept a :N width, unlike seq/db_seq/ap_seq', () => {
      assert.notEqual(validatePattern('kvm-{dc:2}-{seq}'), null);
    });
  });
});

describe('validateNamePatternsWrite — whole-set write guard', () => {
  it('null/undefined (inherited) is valid', () => {
    assert.equal(validateNamePatternsWrite(null), null);
    assert.equal(validateNamePatternsWrite(undefined), null);
  });
  it('a full valid set is valid', () => {
    assert.equal(validateNamePatternsWrite({ ...DEFAULT_NAME_PATTERNS }), null);
  });
  it('rejects a non-object (array / string)', () => {
    assert.notEqual(validateNamePatternsWrite(['x']), null);
    assert.notEqual(validateNamePatternsWrite('hv-{seq:2}'), null);
  });
  it('one bad entry rejects the WHOLE set, naming the offending key', () => {
    const err = validateNamePatternsWrite({
      hypervisor: 'hv-{seq:2}', kvm_host_primary: 'kvm-{nn}', kvm_host_standby: 'kvm-{seq:2}', ap_vm: 'ap-{seq:2}',
    });
    assert.match(err, /kvm_host_primary/);
  });
  // cap-pattern-function (Task 2.2): the pre-split legacy key set is rejected
  // post-migration — it is neither the exact new key set nor a partial one.
  it('rejects the legacy single kvm_host key set', () => {
    const err = validateNamePatternsWrite({
      hypervisor: DEFAULT_NAME_PATTERNS.hypervisor, kvm_host: 'kvm-{dc}-{seq:2}', ap_vm: DEFAULT_NAME_PATTERNS.ap_vm,
    });
    assert.match(err, /exactly/);
  });
  it('a missing entry is rejected (whole set required)', () => {
    assert.notEqual(validateNamePatternsWrite({ hypervisor: 'hv-{seq:2}' }), null);
  });
  // FIX-6 (lockstep): an extra key would persist verbatim into the JSON column.
  it('rejects a payload with an extra key', () => {
    const err = validateNamePatternsWrite({ ...DEFAULT_NAME_PATTERNS, evil: 'x-{seq}' });
    assert.match(err, /exactly/);
  });
});

// ── B5b renumber primitives (server mirror) ──────────────────────────────────

describe('siteSlug / formatHostname / withBatchSeqWidth (server mirror)', () => {
  it('siteSlug lowercases and strips non-alphanumerics', () => {
    assert.equal(siteSlug('DC-1'), 'dc1');
    assert.equal(siteSlug('Site A 2'), 'sitea2');
    assert.equal(siteSlug(null), '');
  });
  it('formatHostname interpolates {dc}/{seq} and leaves unknown tokens verbatim', () => {
    assert.equal(formatHostname('hv-{dc}-{seq:2}', { dc: 'dc1', seq: 7 }), 'hv-dc1-07');
    assert.equal(formatHostname('ap-{seq:2}', { dc: '', seq: 100 }), 'ap-100');
    assert.equal(formatHostname('x-{zzz}-{seq}', { dc: 'd', seq: 3 }), 'x-{zzz}-3');
  });

  // U4 (Q5-Q7): {db_seq}/{ap_seq} — a real value on either token, and
  // all three fallback shapes.
  describe('formatHostname — {db_seq}/{ap_seq} (U4)', () => {
    it('renders a real dbSeq/apSeq value, zero-padded', () => {
      assert.equal(formatHostname('kvm-{db_seq:2}', { dc: '', seq: 9, dbSeq: 3 }), 'kvm-03');
      assert.equal(formatHostname('{function}-{ap_seq:2}', { dc: '', seq: 9, function: 'ap', apSeq: 5 }), 'ap-05');
    });
    it('db_seq falls back to apSeq when dbSeq is absent', () => {
      assert.equal(formatHostname('kvm-{db_seq:2}', { dc: '', seq: 9, apSeq: 4 }), 'kvm-04');
    });
    it('ap_seq falls back to dbSeq when apSeq is absent', () => {
      assert.equal(formatHostname('kvm-{ap_seq:2}', { dc: '', seq: 9, dbSeq: 4 }), 'kvm-04');
    });
    it('both fall back to {seq} when neither dbSeq nor apSeq is supplied', () => {
      assert.equal(formatHostname('kvm-{db_seq:2}-{ap_seq:2}', { dc: '', seq: 9 }), 'kvm-09-09');
    });
    it('{seq:N} width applies independently to each token (no shared state)', () => {
      assert.equal(formatHostname('{db_seq:3}-{ap_seq}', { dc: '', seq: 5, dbSeq: 7, apSeq: 2 }), '007-2');
    });
  });
  it('withBatchSeqWidth widens seq pad to the batch digit count', () => {
    assert.equal(withBatchSeqWidth('ap-{seq:2}', 100), 'ap-{seq:3}');
    assert.equal(withBatchSeqWidth('ap-{seq:2}', 9), 'ap-{seq:2}');
    assert.equal(withBatchSeqWidth('ap-{seq}', 12), 'ap-{seq:2}');
  });
  // U4 (Q5-Q7): {db_seq}/{ap_seq} widen the same way {seq} does — the
  // built-in KVM defaults carry {db_seq} with no {seq} at all, so limiting the
  // widen to {seq} would leave a 100+-host batch's KVM names 2-digit forever.
  it('withBatchSeqWidth widens {db_seq}/{ap_seq} pads the same way as {seq}', () => {
    assert.equal(withBatchSeqWidth('kvm-{db_seq:2}', 120), 'kvm-{db_seq:3}');
    assert.equal(withBatchSeqWidth('{function}-{ap_seq}', 15), '{function}-{ap_seq:2}');
  });
});

describe('resolveEffectiveNamePatterns (server mirror of the FE tier chain)', () => {
  const OVERRIDE = {
    hypervisor: 'h-{dc}-{seq:2}', kvm_host_primary: 'k-{dc}-{seq:2}', kvm_host_standby: 'ks-{dc}-{seq:2}', ap_vm: 'a-{seq:2}',
  };
  const GLOBAL = {
    hypervisor: 'g-{dc}-{seq:2}', kvm_host_primary: 'gk-{dc}-{seq:2}', kvm_host_standby: 'gks-{dc}-{seq:2}', ap_vm: 'ga-{seq:2}',
  };

  it('a scenario override (own non-null scenario_id) wins over global and defaults', () => {
    const eff = resolveEffectiveNamePatterns(
      { scenario_id: 's1', name_patterns: OVERRIDE },
      { scenario_id: null, name_patterns: GLOBAL },
    );
    assert.deepEqual(eff, OVERRIDE);
  });
  it('a scenario row with NULL name_patterns inherits the global patterns', () => {
    const eff = resolveEffectiveNamePatterns(
      { scenario_id: 's1', name_patterns: null },
      { scenario_id: null, name_patterns: GLOBAL },
    );
    assert.deepEqual(eff, GLOBAL);
  });
  it('no scenario row + no global override falls back to built-in defaults', () => {
    const eff = resolveEffectiveNamePatterns(null, { scenario_id: null, name_patterns: null });
    assert.deepEqual(eff, DEFAULT_NAME_PATTERNS);
  });
});

describe('computeRenumberPlan (fork-2 wizard-consistent numbering)', () => {
  it('groups by {dc} slug; seq 1..k per group in the given order', () => {
    const rows = [
      { id: 'a', name: 'old-a', dcSlug: 'dc1' },
      { id: 'b', name: 'old-b', dcSlug: 'dc1' },
      { id: 'c', name: 'old-c', dcSlug: 'dc2' },
    ];
    const plan = computeRenumberPlan(rows, 'hv-{dc}-{seq:2}');
    assert.deepEqual(plan.map((p) => p.newName), ['hv-dc1-01', 'hv-dc1-02', 'hv-dc2-01']);
    assert.deepEqual(plan.map((p) => p.id), ['a', 'b', 'c']); // display order preserved
    assert.equal(plan[0].oldName, 'old-a');
  });
  it('a {dc}-free pattern is ONE scenario-wide group', () => {
    const rows = ['a', 'b', 'c'].map((id) => ({ id, name: `x-${id}`, dcSlug: 'ignored' }));
    const plan = computeRenumberPlan(rows, 'ap-{seq:2}');
    assert.deepEqual(plan.map((p) => p.newName), ['ap-01', 'ap-02', 'ap-03']);
  });
  it('an UNPLACED entity (empty slug) with a {dc} pattern drops {dc} — no dangling separator', () => {
    const rows = [
      { id: 'a', name: 'old', dcSlug: 'dc1' },
      { id: 'b', name: 'old', dcSlug: '' },
      { id: 'c', name: 'old', dcSlug: '' },
    ];
    const plan = computeRenumberPlan(rows, 'kvm-{dc}-{seq:2}');
    assert.deepEqual(plan.map((p) => p.newName), ['kvm-dc1-01', 'kvm-01', 'kvm-02']);
  });
  it('width grows with group count: a group of 100 renders 3-wide', () => {
    const rows = Array.from({ length: 100 }, (_, i) => ({ id: `r${i}`, name: 'x', dcSlug: '' }));
    const plan = computeRenumberPlan(rows, 'ap-{seq:2}');
    assert.equal(plan[0].newName, 'ap-001');
    assert.equal(plan[99].newName, 'ap-100');
  });
  it('hand-edited names are renumbered like any other (oldName is irrelevant to newName)', () => {
    const rows = [
      { id: 'a', name: 'my-special-host', dcSlug: 'dc1' },
      { id: 'b', name: 'renamed-by-hand', dcSlug: 'dc1' },
    ];
    const plan = computeRenumberPlan(rows, 'hv-{dc}-{seq:2}');
    assert.deepEqual(plan.map((p) => p.newName), ['hv-dc1-01', 'hv-dc1-02']);
  });
  // H1 (cross-role-group collision, renumber.js plansForTable's kvm_host split):
  // `reservedSeed` folds an external name list into the collision set BEFORE
  // generation, same fold as a locked row's own name — the mechanism the
  // renumber route uses to make the primary group's plan off-limits to the
  // independently-computed standby group.
  it('reservedSeed advances the seq past an externally-reserved name, case-insensitively', () => {
    const rows = [{ id: 'a', name: 'old-a', dcSlug: 'dc' }];
    const plan = computeRenumberPlan(rows, 'kvm-{dc}-{seq:2}', ['KVM-DC-01']);
    assert.deepEqual(plan.map((p) => p.newName), ['kvm-dc-02']);
  });
  it('an empty/absent reservedSeed behaves exactly as today (no third param)', () => {
    const rows = [{ id: 'a', name: 'old-a', dcSlug: 'dc' }];
    assert.deepEqual(
      computeRenumberPlan(rows, 'kvm-{dc}-{seq:2}').map((p) => p.newName),
      computeRenumberPlan(rows, 'kvm-{dc}-{seq:2}', []).map((p) => p.newName),
    );
  });
  // P1a (Codex r1): a reservedSeed larger than this group's own row count must
  // not exhaust the retry bound before an unreserved candidate is found — the
  // bound must grow with the seed, not just with rows.length.
  it('a reservedSeed bigger than rows.length still advances to an unreserved name', () => {
    const rows = [{ id: 'a', name: 'old-a', dcSlug: 'dc' }];
    const plan = computeRenumberPlan(
      rows,
      'kvm-{dc}-{seq:2}',
      ['kvm-dc-01', 'kvm-dc-02', 'kvm-dc-03'],
    );
    assert.deepEqual(plan.map((p) => p.newName), ['kvm-dc-04']);
  });

  // U4 (Q5-Q7): row.dbSeq/row.apSeq thread into formatHostname's ctx.
  describe('U4: row.dbSeq/row.apSeq threading', () => {
    it('a {db_seq}-only pattern (no {seq}, the new kvm_host_primary default shape) renders each row\'s real dbSeq', () => {
      const rows = [
        { id: 'a', name: 'old-a', dcSlug: '', dbSeq: 3 },
        { id: 'b', name: 'old-b', dcSlug: '', dbSeq: 1 },
      ];
      const plan = computeRenumberPlan(rows, 'kvm-{db_seq:2}');
      assert.deepEqual(plan.map((p) => p.newName), ['kvm-03', 'kvm-01']);
    });
    it('a row with no dbSeq (empty host) falls back to the group seq counter', () => {
      const rows = [
        { id: 'a', name: 'old-a', dcSlug: '' }, // no dbSeq — empty host
        { id: 'b', name: 'old-b', dcSlug: '' },
      ];
      const plan = computeRenumberPlan(rows, 'kvm-{db_seq:2}');
      assert.deepEqual(plan.map((p) => p.newName), ['kvm-01', 'kvm-02']);
    });
    it('apSeq threads the same way for an {ap_seq}-only pattern', () => {
      const rows = [{ id: 'a', name: 'old-a', dcSlug: '', apSeq: 7 }];
      const plan = computeRenumberPlan(rows, 'ap-{ap_seq:2}');
      assert.deepEqual(plan.map((p) => p.newName), ['ap-07']);
    });
  });
});

describe('firstDuplicateName (apply uniqueness gate)', () => {
  it('returns null when every name is unique', () => {
    assert.equal(firstDuplicateName(['hv-dc1-01', 'hv-dc1-02', 'hv-dc2-01']), null);
  });
  it('detects a case-insensitive duplicate (matching the DB collation)', () => {
    assert.equal(firstDuplicateName(['HV-DC1-01', 'hv-dc1-01']), 'hv-dc1-01');
  });
  it('catches a malformed {seq}-less pattern that renders every name identically', () => {
    // A legacy stored override the lenient formatter would render the same for all
    // rows — the guarantee that a duplicate can never persist regardless of cause.
    const rows = [{ id: 'a', name: 'x', dcSlug: 'dc1' }, { id: 'b', name: 'y', dcSlug: 'dc1' }];
    const plan = computeRenumberPlan(rows, 'kvm-{dc}');
    assert.notEqual(firstDuplicateName(plan.map((p) => p.newName)), null);
  });
});

describe('duplicateNameFlags (fmb-1649 preview gate — marks EVERY colliding row)', () => {
  it('returns all-false when every name is unique', () => {
    assert.deepEqual(duplicateNameFlags(['hv-dc1-01', 'hv-dc1-02', 'hv-dc2-01']), [false, false, false]);
  });
  it('flags a case-insensitive duplicate on BOTH sides (same fold as firstDuplicateName)', () => {
    // Case-differing to prove the fold — String(name).trim().toLowerCase(), the
    // exact fold firstDuplicateName / the DB collation use — not just an exact
    // string match.
    assert.deepEqual(duplicateNameFlags(['HV-DC1-01', 'hv-dc1-01', 'hv-dc2-01']), [true, true, false]);
  });
  it('flags every member of a 3-way collision, not just the second', () => {
    assert.deepEqual(duplicateNameFlags(['kvm-dc1', 'kvm-dc1', 'kvm-dc1']), [true, true, true]);
  });
});

describe('duplicateAllLockedFlags (locked-vs-locked duplicate remedy)', () => {
  it('returns all-false when nothing collides', () => {
    const items = [{ name: 'hv-dc1-01', locked: false }, { name: 'hv-dc1-02', locked: true }];
    assert.deepEqual(duplicateAllLockedFlags(items), [false, false]);
  });
  it('flags false when a collision has at least one renumerable (unlocked) side', () => {
    // A naming-pattern edit can still resolve this: the unlocked side would
    // compute a different name.
    const items = [{ name: 'kvm-dc1-01', locked: true }, { name: 'kvm-dc1-01', locked: false }];
    assert.deepEqual(duplicateAllLockedFlags(items), [false, false]);
  });
  it('flags true when every member of the colliding group is locked', () => {
    // Both names are frozen (spec D1) — no naming-pattern edit can change
    // either one; the only remedy is unlocking one of them.
    const items = [
      { name: 'erp-db', locked: true },
      { name: 'ERP-DB', locked: true }, // case-folded match, same fold as duplicateNameFlags
      { name: 'kvm-dc1-01', locked: false },
    ];
    assert.deepEqual(duplicateAllLockedFlags(items), [true, true, false]);
  });
});

describe('firstOverlengthName (apply length gate)', () => {
  it('returns null when every name is within the limit, and the boundary is inclusive', () => {
    assert.equal(firstOverlengthName(['hv-dc1-01', 'a'.repeat(255)], 255), null);
  });
  it('returns the first name that exceeds the limit', () => {
    assert.equal(firstOverlengthName(['ok', 'b'.repeat(256)], 255), 'b'.repeat(256));
  });
});

describe('dbInstanceName — per-topology naming rule (spec §7 E2 / Q18)', () => {
  it('single drops the serial — bare function name', () => {
    assert.equal(dbInstanceName('orcl', 'single', 1), 'orcl');
  });
  it('primary / primary_standby / rac / rac_multinode_standby keep {fn}{clusterIndex}', () => {
    assert.equal(dbInstanceName('orcl', 'primary', 1), 'orcl1');
    assert.equal(dbInstanceName('orcl', 'primary_standby', 2), 'orcl2');
    assert.equal(dbInstanceName('orcl', 'rac_multinode', 3), 'orcl3');
    assert.equal(dbInstanceName('orcl', 'rac_multinode_standby', 3), 'orcl3');
  });
});

// U4 (Q7): the {db_seq} ranking source — the same per-(databaseId,
// role) rank dbInstanceName/computeDbInstanceRenumberPlan compute, returned as
// a plain id→rank map instead of a computed name.
describe('computeInstanceClusterIndexes (U4, fmb-1827 Q7 db_seq source)', () => {
  it('ranks a single-instance group to 1', () => {
    const rows = [{ id: 'i1', databaseId: 'd1', role: 'primary', order_index: 0 }];
    const map = computeInstanceClusterIndexes(rows);
    assert.equal(map.get('i1'), 1);
  });
  it('ranks multiple instances of the SAME (databaseId, role) group by (order_index, id)', () => {
    const rows = [
      { id: 'i3', databaseId: 'd1', role: 'primary', order_index: 2 },
      { id: 'i1', databaseId: 'd1', role: 'primary', order_index: 0 },
      { id: 'i2', databaseId: 'd1', role: 'primary', order_index: 1 },
    ];
    const map = computeInstanceClusterIndexes(rows);
    assert.equal(map.get('i1'), 1);
    assert.equal(map.get('i2'), 2);
    assert.equal(map.get('i3'), 3);
  });
  it('a database\'s nodes spread across DIFFERENT hosts still rank against each other (scenario-wide, not per-host)', () => {
    // computeInstanceClusterIndexes takes no host/vm_id at all — this is the
    // load-bearing property renumber.js's readHostFunctionRoles relies on.
    const rows = [
      { id: 'p1', databaseId: 'd1', role: 'primary', order_index: 0 },
      { id: 'p2', databaseId: 'd1', role: 'primary', order_index: 1 },
    ];
    const map = computeInstanceClusterIndexes(rows);
    assert.equal(map.get('p1'), 1);
    assert.equal(map.get('p2'), 2);
  });
  it('DIFFERENT databases (or roles) form independent groups, each ranking from 1', () => {
    const rows = [
      { id: 'a1', databaseId: 'd1', role: 'primary', order_index: 0 },
      { id: 'b1', databaseId: 'd2', role: 'primary', order_index: 1 },
      { id: 'a2-standby', databaseId: 'd1', role: 'standby', order_index: 2 },
    ];
    const map = computeInstanceClusterIndexes(rows);
    assert.equal(map.get('a1'), 1);
    assert.equal(map.get('b1'), 1);
    assert.equal(map.get('a2-standby'), 1);
  });
  it('an orphaned instance (no databaseId) is left OUT of the map entirely — not ranked 1', () => {
    const rows = [{ id: 'stray', databaseId: null, role: 'primary', order_index: 0 }];
    const map = computeInstanceClusterIndexes(rows);
    assert.equal(map.has('stray'), false);
  });
});

describe('computeDbInstanceRenumberPlan (spec §7 E2 renumber extension)', () => {
  it('single→bare: a single-topology database renumbers its one instance to the bare function name', () => {
    const rows = [
      { id: 'i1', name: 'orcl-old', databaseId: 'd1', role: 'primary', order_index: 0, functionName: 'orcl', topology: 'single' },
    ];
    const plan = computeDbInstanceRenumberPlan(rows);
    assert.deepEqual(plan, [{ id: 'i1', oldName: 'orcl-old', newName: 'orcl', duplicate: false }]);
  });

  it('non-single topology stays untouched by the rule change: {fn}{clusterIndex}, primary+standby sharing a name', () => {
    const rows = [
      { id: 'p1', name: 'x', databaseId: 'd1', role: 'primary', order_index: 0, functionName: 'core', topology: 'primary_standby' },
      { id: 'p2', name: 'y', databaseId: 'd1', role: 'primary', order_index: 1, functionName: 'core', topology: 'primary_standby' },
      { id: 's1', name: 'z', databaseId: 'd1', role: 'standby', order_index: 2, functionName: 'core', topology: 'primary_standby' },
      { id: 's2', name: 'w', databaseId: 'd1', role: 'standby', order_index: 3, functionName: 'core', topology: 'primary_standby' },
    ];
    const plan = computeDbInstanceRenumberPlan(rows);
    assert.deepEqual(plan.map((p) => p.newName), ['core1', 'core2', 'core1', 'core2']);
  });

  it('idempotent re-run: renaming an already-correct name is a no-op (newName === oldName)', () => {
    const rows = [
      { id: 'i1', name: 'orcl', databaseId: 'd1', role: 'primary', order_index: 0, functionName: 'orcl', topology: 'single' },
    ];
    const plan = computeDbInstanceRenumberPlan(rows);
    assert.equal(plan[0].newName, plan[0].oldName);
  });

  it('ranks within (databaseId, role) by (order_index, id) — scenario-wide order_index, filtered per group', () => {
    // order_index is scenario-wide (not reset per database) — two databases'
    // instances interleave in the input, but each still ranks 1..k within its
    // OWN group.
    const rows = [
      { id: 'a1', name: 'x', databaseId: 'db-a', role: 'primary', order_index: 0, functionName: 'appA', topology: 'primary' },
      { id: 'b1', name: 'x', databaseId: 'db-b', role: 'primary', order_index: 1, functionName: 'appB', topology: 'primary' },
      { id: 'a2', name: 'x', databaseId: 'db-a', role: 'primary', order_index: 2, functionName: 'appA', topology: 'primary' },
      { id: 'b2', name: 'x', databaseId: 'db-b', role: 'primary', order_index: 3, functionName: 'appB', topology: 'primary' },
    ];
    const plan = computeDbInstanceRenumberPlan(rows);
    const byId = Object.fromEntries(plan.map((p) => [p.id, p.newName]));
    assert.deepEqual(byId, { a1: 'appA1', b1: 'appB1', a2: 'appA2', b2: 'appB2' });
  });

  it('an orphaned instance (no owning database) is a passthrough — unchanged', () => {
    const rows = [
      { id: 'i1', name: 'stray', databaseId: null, role: 'primary', order_index: 0, functionName: null, topology: null },
    ];
    const plan = computeDbInstanceRenumberPlan(rows);
    assert.deepEqual(plan, [{ id: 'i1', oldName: 'stray', newName: 'stray', duplicate: false }]);
  });

  it('preserves the input row order in the output', () => {
    const rows = [
      { id: 'z', name: 'z', databaseId: 'd1', role: 'primary', order_index: 5, functionName: 'z', topology: 'single' },
      { id: 'a', name: 'a', databaseId: 'd2', role: 'primary', order_index: 0, functionName: 'a', topology: 'single' },
    ];
    const plan = computeDbInstanceRenumberPlan(rows);
    assert.deepEqual(plan.map((p) => p.id), ['z', 'a']);
  });

  // F3: a dangling database_id (set, but no matching cap_databases row — the
  // join MISSED) must be a passthrough too, matching the doc's own contract —
  // NOT dbInstanceName('', null, 1) = '1', a bogus integer name.
  it('F3: a dangling database_id (join miss — functionName null) is a passthrough, not a bare-integer name', () => {
    const rows = [
      { id: 'i1', name: 'kept-name', databaseId: 'd-deleted', role: 'primary', order_index: 0, functionName: null, topology: null },
    ];
    const plan = computeDbInstanceRenumberPlan(rows);
    assert.deepEqual(plan, [{ id: 'i1', oldName: 'kept-name', newName: 'kept-name', duplicate: false }]);
    assert.notEqual(plan[0].newName, '1');
  });

  // X3 (Codex round 1): an EMPTY-STRING/whitespace-only function_name (reachable
  // via generic database CRUD — no NOT-blank constraint on the column) must be
  // the SAME passthrough as `functionName == null`, not '' (single) or '1'/'2'
  // (non-single).
  describe('X3: blank function_name is a passthrough, not null-only', () => {
    it('empty-string functionName, single topology — passthrough, never a blank name', () => {
      const rows = [
        { id: 'i1', name: 'kept', databaseId: 'd1', role: 'primary', order_index: 0, functionName: '', topology: 'single' },
      ];
      const plan = computeDbInstanceRenumberPlan(rows);
      assert.deepEqual(plan, [{ id: 'i1', oldName: 'kept', newName: 'kept', duplicate: false }]);
      assert.notEqual(plan[0].newName, '');
    });

    it('whitespace-only functionName, non-single topology — passthrough, never a bare-integer name', () => {
      const rows = [
        { id: 'i1', name: 'kept', databaseId: 'd1', role: 'primary', order_index: 0, functionName: '   ', topology: 'primary' },
      ];
      const plan = computeDbInstanceRenumberPlan(rows);
      assert.equal(plan[0].newName, 'kept');
      assert.notEqual(plan[0].newName, '1');
    });
  });

  // F4: a `single`-topology (databaseId, role) group with MORE than one row
  // would otherwise all collapse onto the identical bare name — flag every
  // member instead of silently discarding the rank that used to keep them
  // apart.
  describe('F4: oversized single-topology group', () => {
    it('flags every row when a single-topology database has 2 instance rows sharing a role', () => {
      const rows = [
        { id: 'i1', name: 'orcl-a', databaseId: 'd1', role: 'primary', order_index: 0, functionName: 'orcl', topology: 'single' },
        { id: 'i2', name: 'orcl-b', databaseId: 'd1', role: 'primary', order_index: 1, functionName: 'orcl', topology: 'single' },
      ];
      const plan = computeDbInstanceRenumberPlan(rows);
      assert.deepEqual(plan.map((p) => p.duplicate), [true, true]);
      // Still computed (both collapse to the same bare name) — the CALLER
      // (renumber.js apply) is what refuses to write it.
      assert.deepEqual(plan.map((p) => p.newName), ['orcl', 'orcl']);
    });

    it('non-single topology is unaffected — 2 primary rows under `primary` are never flagged', () => {
      const rows = [
        { id: 'p1', name: 'x', databaseId: 'd1', role: 'primary', order_index: 0, functionName: 'core', topology: 'primary' },
        { id: 'p2', name: 'y', databaseId: 'd1', role: 'primary', order_index: 1, functionName: 'core', topology: 'primary' },
      ];
      const plan = computeDbInstanceRenumberPlan(rows);
      assert.deepEqual(plan.map((p) => p.duplicate), [false, false]);
      assert.deepEqual(plan.map((p) => p.newName), ['core1', 'core2']);
    });

    it('a single-topology group of exactly 1 (the normal case) is never flagged', () => {
      const rows = [
        { id: 'i1', name: 'orcl-old', databaseId: 'd1', role: 'primary', order_index: 0, functionName: 'orcl', topology: 'single' },
      ];
      const plan = computeDbInstanceRenumberPlan(rows);
      assert.equal(plan[0].duplicate, false);
    });

    it('two DIFFERENT single-topology databases are unaffected — each is its own 1-member group', () => {
      const rows = [
        { id: 'i1', name: 'a-old', databaseId: 'd1', role: 'primary', order_index: 0, functionName: 'a', topology: 'single' },
        { id: 'i2', name: 'b-old', databaseId: 'd2', role: 'primary', order_index: 1, functionName: 'b', topology: 'single' },
      ];
      const plan = computeDbInstanceRenumberPlan(rows);
      assert.deepEqual(plan.map((p) => p.duplicate), [false, false]);
    });
  });

  // Y1 (Codex round-2): the SAME "two rows, one database, one computed name,
  // no design reason to share it" class as F4 above, but reached via a
  // DIFFERENT shape — a topology that illegally carries BOTH a primary and a
  // standby row (generic CRUD enforces no role cardinality). F4's grouping
  // was (databaseId, role)-separated, so these landed in TWO different
  // groups and each ranked to 1 independently — same name, no flag. The
  // class-closing WITHIN-DATABASE check (grouped ACROSS roles) catches this
  // shape with the exact same mechanism F4 now routes through.
  describe('Y1: cross-role name collision within one database (class-closing, generalizes F4)', () => {
    it('a `primary`-topology database illegally carrying a primary AND a standby row — both flagged', () => {
      const rows = [
        { id: 'p1', name: 'x', databaseId: 'd1', role: 'primary', order_index: 0, functionName: 'orcl', topology: 'primary' },
        { id: 's1', name: 'y', databaseId: 'd1', role: 'standby', order_index: 1, functionName: 'orcl', topology: 'primary' },
      ];
      const plan = computeDbInstanceRenumberPlan(rows);
      assert.deepEqual(plan.map((p) => p.newName), ['orcl1', 'orcl1']); // both rank 1 in their own role group
      assert.deepEqual(plan.map((p) => p.duplicate), [true, true]);
    });

    it('a `single`-topology database with one primary row and one standby row — both flagged (bare name collides too)', () => {
      const rows = [
        { id: 'p1', name: 'x', databaseId: 'd1', role: 'primary', order_index: 0, functionName: 'orcl', topology: 'single' },
        { id: 's1', name: 'y', databaseId: 'd1', role: 'standby', order_index: 1, functionName: 'orcl', topology: 'single' },
      ];
      const plan = computeDbInstanceRenumberPlan(rows);
      assert.deepEqual(plan.map((p) => p.newName), ['orcl', 'orcl']);
      assert.deepEqual(plan.map((p) => p.duplicate), [true, true]);
    });

    it('a `rac_multinode`-topology database illegally carrying a standby row — both flagged', () => {
      const rows = [
        { id: 'p1', name: 'x', databaseId: 'd1', role: 'primary', order_index: 0, functionName: 'orcl', topology: 'rac_multinode' },
        { id: 's1', name: 'y', databaseId: 'd1', role: 'standby', order_index: 1, functionName: 'orcl', topology: 'rac_multinode' },
      ];
      const plan = computeDbInstanceRenumberPlan(rows);
      assert.deepEqual(plan.map((p) => p.duplicate), [true, true]);
    });

    it('`primary_standby` with LEGITIMATE fn1/fn1 across sides is NOT flagged — the sharing-topology exemption', () => {
      const rows = [
        { id: 'p1', name: 'x', databaseId: 'd1', role: 'primary', order_index: 0, functionName: 'orcl', topology: 'primary_standby' },
        { id: 's1', name: 'y', databaseId: 'd1', role: 'standby', order_index: 1, functionName: 'orcl', topology: 'primary_standby' },
      ];
      const plan = computeDbInstanceRenumberPlan(rows);
      assert.deepEqual(plan.map((p) => p.newName), ['orcl1', 'orcl1']); // BY DESIGN
      assert.deepEqual(plan.map((p) => p.duplicate), [false, false]);
    });

    // spec §7 E1 / Q11: rac_multinode_standby joins the sharing-topology exemption too —
    // generalizes primary_standby's fixed 2+2 to variable N/S, ranked
    // independently per (databaseId, role) and sharing names serial-per-side.
    it('`rac_multinode_standby` with LEGITIMATE N=3 primary / S=2 standby sharing per-index is NOT flagged', () => {
      const rows = [
        { id: 'p1', name: 'a', databaseId: 'd1', role: 'primary', order_index: 0, functionName: 'orcl', topology: 'rac_multinode_standby' },
        { id: 'p2', name: 'b', databaseId: 'd1', role: 'primary', order_index: 1, functionName: 'orcl', topology: 'rac_multinode_standby' },
        { id: 'p3', name: 'c', databaseId: 'd1', role: 'primary', order_index: 2, functionName: 'orcl', topology: 'rac_multinode_standby' },
        { id: 's1', name: 'd', databaseId: 'd1', role: 'standby', order_index: 3, functionName: 'orcl', topology: 'rac_multinode_standby' },
        { id: 's2', name: 'e', databaseId: 'd1', role: 'standby', order_index: 4, functionName: 'orcl', topology: 'rac_multinode_standby' },
      ];
      const plan = computeDbInstanceRenumberPlan(rows);
      // Primary ranks 1..3 = orcl1..orcl3; Standby ranks 1..2 SHARE orcl1/orcl2.
      assert.deepEqual(plan.map((p) => p.newName), ['orcl1', 'orcl2', 'orcl3', 'orcl1', 'orcl2']);
      assert.deepEqual(plan.map((p) => p.duplicate), [false, false, false, false, false]);
    });

    it('a `primary` database with a primary+standby collision AND an unrelated non-colliding row on another database — only the colliding pair is flagged', () => {
      const rows = [
        { id: 'p1', name: 'x', databaseId: 'd1', role: 'primary', order_index: 0, functionName: 'orcl', topology: 'primary' },
        { id: 's1', name: 'y', databaseId: 'd1', role: 'standby', order_index: 1, functionName: 'orcl', topology: 'primary' },
        { id: 'p2', name: 'z', databaseId: 'd2', role: 'primary', order_index: 2, functionName: 'crm', topology: 'primary' },
      ];
      const plan = computeDbInstanceRenumberPlan(rows);
      const byId = Object.fromEntries(plan.map((p) => [p.id, p]));
      assert.equal(byId.p1.duplicate, true);
      assert.equal(byId.s1.duplicate, true);
      assert.equal(byId.p2.duplicate, false);
      assert.equal(byId.p2.newName, 'crm1');
    });
  });
});

describe('parity with the FE single formatter', () => {
  it('server DEFAULT_NAME_PATTERNS matches hostname-pattern.ts DEFAULT_NAME_PATTERNS', () => {
    const feSource = fs.readFileSync(
      path.join(__dirname, '../../../src/fmb/capacity/lib/hostname-pattern.ts'),
      'utf8',
    );
    // Each entity key's quoted default literal appears exactly once in the FE
    // source (the DEFAULT_NAME_PATTERNS object); a value may itself contain `}`
    // (e.g. {seq:2}), so match the whole quoted string, not a brace-bounded block.
    const feFor = (key) => {
      const m = feSource.match(new RegExp(`${key}\\s*:\\s*'([^']+)'`));
      assert.ok(m, `FE default for ${key} not found`);
      return m[1];
    };
    assert.equal(DEFAULT_NAME_PATTERNS.hypervisor, feFor('hypervisor'));
    assert.equal(DEFAULT_NAME_PATTERNS.kvm_host_primary, feFor('kvm_host_primary'));
    assert.equal(DEFAULT_NAME_PATTERNS.kvm_host_standby, feFor('kvm_host_standby'));
    assert.equal(DEFAULT_NAME_PATTERNS.ap_vm, feFor('ap_vm'));
  });
});
