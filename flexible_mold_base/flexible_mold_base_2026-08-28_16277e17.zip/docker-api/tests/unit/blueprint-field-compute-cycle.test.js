/**
 * blueprint-field-compute-cycle.test.js
 *
 * A blueprint-level compute rule applies to every variant of the blueprint that
 * does not carry its own compute override on that field, so one blueprint-field
 * write can close a dependency cycle in several variants at once — and in
 * variants that do not exist yet. The write path therefore checks the
 * blueprint-only graph plus one graph per variant that carries compute
 * overrides.
 *
 * The rule is also validated the same way a variant-level rule is: a malformed
 * rule that reached the column would blind the cycle guard, because a rule whose
 * op the extractor cannot read contributes no edges at all.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const { answerParentIdProbe } = require('../helpers/parent-id-probe');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../src/edge/db');
const { MAX_CONCAT_PARTS } = require('../../src/edge/lib/compute-rule-validate');

const DATABASE_PROBE = /^SELECT DATABASE\(\)/i;
const COLUMN_PROBE = /SELECT COLUMN_NAME FROM information_schema\.COLUMNS/i;

const BF_COLUMNS = [
  'id', 'blueprint_id', 'field_type', 'field_key', 'field_label',
  'table_config', 'depends_on_field_key', 'is_locked', 'compute_rule',
];
const BF_COLUMNS_PRE_MIGRATION = BF_COLUMNS.filter((c) => c !== 'compute_rule' && c !== 'is_locked');

// The column-set probe is memoised per (database, table), so each fixture
// reports its own database name.
let dbSeq = 0;
let conn;

function makeConn({ columns = BF_COLUMNS, scripts = [] } = {}) {
  const dbName = `bfc_${dbSeq += 1}`;
  const queries = [];
  let committed = false;
  let rolledBack = false;
  return {
    queries,
    committed: () => committed,
    rolledBack: () => rolledBack,
    async beginTransaction() {},
    async commit() { committed = true; },
    async rollback() { rolledBack = true; },
    async query(sql, params) {
      queries.push({ sql, params });
      for (const [matcher, response] of scripts) {
        if (matcher.test(sql)) return typeof response === 'function' ? response(sql, params) : response;
      }
      if (DATABASE_PROBE.test(sql)) return [{ db: dbName }];
      if (COLUMN_PROBE.test(sql)) {
        const table = Array.isArray(params) ? params[0] : undefined;
        if (table === 'fmb_field_options') {
          return ['id', 'field_id', 'option_value', 'valid_parent_values'].map((c) => ({ COLUMN_NAME: c }));
        }
        return columns.map((c) => ({ COLUMN_NAME: c }));
      }
      if (/SELECT id, blueprint_id, field_type/.test(sql)) {
        return [{
          id: '2ce8ba8e-83f5-41ee-8246-a2265095b549', blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', field_type: 'text',
          field_key: 'cyc_b', depends_on_field_key: null,
        }];
      }
      if (/^UPDATE `fmb_blueprint_fields`/i.test(sql)) return { affectedRows: 1 };
      if (/^SELECT \* FROM `fmb_blueprint_fields`/i.test(sql)) {
        return [{ id: '2ce8ba8e-83f5-41ee-8246-a2265095b549', blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', field_key: 'cyc_b', field_type: 'text' }];
      }
      // C1's narrowing-scope scan for the post-state judgement — none of this
      // suite's fixture rules carry a `same_table_column` term, so an empty
      // scope map changes nothing about the verdicts these tests pin.
      if (/SELECT field_key, value_scope FROM `fmb_blueprint_fields`/i.test(sql)) return [];
      // Linked-blueprint guard probes: not linked in these fixtures.
      if (/SELECT linked_blueprint_id FROM/.test(sql)) return [];
      if (/ AS bid FROM/.test(sql) || / AS fk FROM/.test(sql)) return [];
      // The identity question the write path now asks the ENGINE (write-value.js
      // `sameStoredValue`): are these two spellings one stored value? Answered
      // here the way the column's collation answers it — case-folded, trailing
      // space padded — so this double cannot disagree with the database about
      // whether a write moved a value. The instrument that settles it for real
      // is tests/integration/blueprint-field-write-real-db.test.js.
      if (/CHARACTER_SET_NAME AS cs/.test(sql)) return [{ cs: 'utf8mb4', co: 'utf8mb4_general_ci' }];
      if (/<=>/.test(sql) && / AS same/.test(sql)) {
        const fold = (v) => String(v).toLowerCase().replace(/\s+$/, '');
        return [{ same: fold((params || [])[0]) === fold((params || [])[1]) ? 1 : 0 }];
      }
      // The (blueprint, key) clash probe both write paths now run before they can
      // create the duplicate the migration endpoint would turn into a merge.
      // Nothing collides in these fixtures; the case that does is settled on a
      // real database (tests/integration/blueprint-field-write-real-db.test.js).
      if (/FROM `fmb_blueprint_fields`/i.test(sql) && /`?field_key`? = \?/i.test(sql)
          && /LIMIT 1/i.test(sql)) {
        return [];
      }
      // The factory asks which spelling the parent row really carries before it
      // binds one. Answered rather than thrown on — see tests/helpers.
      const parentId = answerParentIdProbe(sql, params);
      if (parentId) return parentId;
      throw new Error(`Unmatched query in test: ${sql.slice(0, 140)}`);
    },
    release() {},
  };
}

const poolSpy = {
  rw: { async getConnection() { return conn; } },
  ro: { async getConnection() { throw new Error('test error: PUT should use pool.rw'); } },
};

require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: poolSpy, t: (name) => `fmb_${name}`, getDynamicPool: async () => poolSpy },
};

const router = require('../../src/edge/routes/app/schema');

let server;
let port;

before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { req.user = { id: '5b729f1e-5c0b-447c-8144-3210469bc62c', role: 'admin' }; next(); });
  app.use('/edge/app/schema', router);
  await new Promise((resolve) => {
    server = app.listen(0, '127.0.0.1', () => { port = server.address().port; resolve(); });
  });
});

after(async () => {
  await new Promise((resolve) => server.close(resolve));
  delete require.cache[dbKey];
});

beforeEach(() => { conn = null; });

const put = (path, body) => request('PUT', path, body);
const post = (path, body) => request('POST', path, body);

function request(method, path, body) {
  return new Promise((resolve, reject) => {
    const data = JSON.stringify(body);
    const r = http.request({
      method, host: '127.0.0.1', port, path,
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(data) },
    }, (res) => {
      let raw = '';
      res.on('data', (c) => { raw += c; });
      res.on('end', () => resolve({ status: res.statusCode, body: raw ? JSON.parse(raw) : null }));
    });
    r.on('error', reject);
    r.write(data);
    r.end();
  });
}

const concat = (...keys) => ({
  op: 'concat',
  overridable: false,
  output_type: 'string',
  config: { parts: keys.map((key) => ({ type: 'field', key })) },
});

const BLUEPRINT_FIELDS = [
  { field_key: 'cyc_a', field_type: 'text', table_config: null },
  { field_key: 'cyc_b', field_type: 'text', table_config: null },
  { field_key: 'plain', field_type: 'text', table_config: null },
];

// One scan carries the field context and the blueprint-level rules together, so
// the fixture merges the scripted rules into the field rows the same way a real
// row set does. A rule named for a field that is not in BLUEPRINT_FIELDS is
// still returned, so a fixture can describe a rule on a field the base list
// omits.
function scripts({ blueprintRules = [], variantRules = [], fields = BLUEPRINT_FIELDS, extra = [] } = {}) {
  const byKey = new Map(blueprintRules.map((r) => [r.field_key, r.compute_rule]));
  const rows = fields.map((f) => ({ ...f, compute_rule: byKey.get(f.field_key) ?? null }));
  for (const r of blueprintRules) {
    if (!rows.some((row) => row.field_key === r.field_key)) {
      rows.push({ field_key: r.field_key, field_type: 'text', table_config: null, compute_rule: r.compute_rule });
    }
  }
  return [
    [/SELECT field_key, field_type, table_config, compute_rule FROM `fmb_blueprint_fields`/i, rows],
    [/SELECT vo\.variant_id, bf\.field_key, vo\.compute_rule/i, variantRules],
    ...extra,
  ];
}

const fieldUpdate = (queries) => queries.find((q) => /^UPDATE `fmb_blueprint_fields` SET/i.test(q.sql.trim()));
const ruleRow = (variantId, fieldKey, rule) => ({
  variant_id: variantId, field_key: fieldKey, compute_rule: JSON.stringify(rule),
});

describe('POST /blueprint_fields — the generic create runs the same guards', () => {
  // The field editor's policy block renders for create as well as edit and the
  // save hook sends the whole form, so a first save carries compute_rule. A rule
  // that lands unvalidated poisons the blueprint: the next legitimate write
  // anywhere in it loads the bad rule, finds a cycle, and refuses an edit that
  // has nothing wrong with it.
  const createBody = (rule) => ({
    blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', field_key: 'new_field', field_label: 'New', field_type: 'text',
    value_source: 'calculated', compute_rule: rule,
  });
  const insertScript = [/^INSERT INTO `fmb_blueprint_fields`/i, { affectedRows: 1 }];

  it('rejects a rule that references a field that does not exist', async () => {
    conn = makeConn({ scripts: scripts({ extra: [insertScript] }) });
    const res = await post('/edge/app/schema/blueprint_fields', createBody(concat('ghost')));
    assert.equal(res.status, 400);
    assert.equal(res.body.error.code, 'missing_source');
    assert.equal(conn.queries.some((q) => /^INSERT/i.test(q.sql.trim())), false);
  });

  it('rejects a rule that points at the field being created', async () => {
    conn = makeConn({ scripts: scripts({ extra: [insertScript] }) });
    const res = await post('/edge/app/schema/blueprint_fields', createBody(concat('new_field')));
    assert.equal(res.status, 400);
    assert.equal(res.body.error.code, 'cycle');
    assert.equal(conn.queries.some((q) => /^INSERT/i.test(q.sql.trim())), false);
  });

  it('rejects a rule that closes a cycle with a stored blueprint rule', async () => {
    conn = makeConn({ scripts: scripts({
      blueprintRules: [{ field_key: 'cyc_a', compute_rule: JSON.stringify(concat('new_field')) }],
      extra: [insertScript],
    }) });
    const res = await post('/edge/app/schema/blueprint_fields', createBody(concat('cyc_a')));
    assert.equal(res.status, 400);
    assert.equal(res.body.error.code, 'cycle');
  });

  it('rejects an oversize rule', async () => {
    conn = makeConn({ scripts: scripts({ extra: [insertScript] }) });
    const res = await post('/edge/app/schema/blueprint_fields', createBody({
      op: 'concat', overridable: false, output_type: 'string',
      config: { parts: Array.from({ length: MAX_CONCAT_PARTS + 1 }, () => ({ type: 'literal', text: 'x' })) },
    }));
    assert.equal(res.status, 400);
    assert.equal(res.body.error.code, 'too_many_parts');
  });

  it('creates the field when the rule is sound', async () => {
    conn = makeConn({ scripts: scripts({ extra: [insertScript] }) });
    const res = await post('/edge/app/schema/blueprint_fields', createBody(concat('plain')));
    assert.equal(res.status, 200);
    const insert = conn.queries.find((q) => /^INSERT INTO `fmb_blueprint_fields`/i.test(q.sql.trim()));
    assert.ok(insert, 'a sound rule must still create the row');
    assert.ok(/`compute_rule`/.test(insert.sql));
  });

  it('does not scan when the create carries no rule', async () => {
    conn = makeConn({ scripts: scripts({ extra: [insertScript] }) });
    const res = await post('/edge/app/schema/blueprint_fields', {
      blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', field_key: 'new_field', field_label: 'New', field_type: 'text',
    });
    assert.equal(res.status, 200);
    assert.equal(conn.queries.some((q) => /compute_rule FROM/i.test(q.sql)), false);
  });

  it('does not scan on a DB whose compute_rule column was never created', async () => {
    // The column is gated out of the INSERT, so rejecting here would make create
    // stricter than update on the very same DB.
    conn = makeConn({ columns: BF_COLUMNS_PRE_MIGRATION, scripts: scripts({ extra: [insertScript] }) });
    const res = await post('/edge/app/schema/blueprint_fields', createBody(concat('ghost')));
    assert.equal(res.status, 200);
    assert.equal(conn.queries.some((q) => /compute_rule FROM/i.test(q.sql)), false);
  });
});

describe('PUT /blueprint_fields/:id — blueprint-level compute cycle detection', () => {
  it('rejects a rule that closes a cycle with another blueprint-level rule', async () => {
    conn = makeConn({ scripts: scripts({
      blueprintRules: [{ field_key: 'cyc_a', compute_rule: JSON.stringify(concat('cyc_b')) }],
    }) });
    const res = await put('/edge/app/schema/blueprint_fields/2ce8ba8e-83f5-41ee-8246-a2265095b549', { value_source: 'calculated', compute_rule: concat('cyc_a') });
    assert.equal(res.status, 400);
    assert.equal(res.body.error.code, 'cycle');
    assert.equal(fieldUpdate(conn.queries), undefined);
    assert.equal(conn.rolledBack(), true);
    assert.equal(conn.committed(), false);
  });

  it('rejects a rule that closes a cycle with a VARIANT-level rule', async () => {
    conn = makeConn({ scripts: scripts({
      variantRules: [ruleRow('v-1', 'cyc_a', concat('cyc_b'))],
    }) });
    const res = await put('/edge/app/schema/blueprint_fields/2ce8ba8e-83f5-41ee-8246-a2265095b549', { value_source: 'calculated', compute_rule: concat('cyc_a') });
    assert.equal(res.status, 400);
    assert.equal(res.body.error.code, 'cycle');
    assert.equal(fieldUpdate(conn.queries), undefined);
  });

  it('rejects when only ONE of several variants cycles', async () => {
    conn = makeConn({ scripts: scripts({
      variantRules: [
        ruleRow('v-1', 'cyc_a', concat('plain')), // this variant is fine
        ruleRow('v-2', 'cyc_a', concat('cyc_b')), // this one closes the loop
      ],
    }) });
    const res = await put('/edge/app/schema/blueprint_fields/2ce8ba8e-83f5-41ee-8246-a2265095b549', { value_source: 'calculated', compute_rule: concat('cyc_a') });
    assert.equal(res.status, 400);
    assert.equal(res.body.error.code, 'cycle');
  });

  it('accepts when the only cycling variant SHADOWS the incoming rule with its own', async () => {
    conn = makeConn({ scripts: scripts({
      variantRules: [
        ruleRow('v-1', 'cyc_a', concat('cyc_b')), // would close the loop...
        ruleRow('v-1', 'cyc_b', concat('plain')), // ...but cyc_b is overridden here
      ],
    }) });
    const res = await put('/edge/app/schema/blueprint_fields/2ce8ba8e-83f5-41ee-8246-a2265095b549', { value_source: 'calculated', compute_rule: concat('cyc_a') });
    assert.equal(res.status, 200);
    assert.ok(/`compute_rule` = \?/.test(fieldUpdate(conn.queries).sql));
  });

  it('accepts a rule with no cycle anywhere', async () => {
    conn = makeConn({ scripts: scripts({
      blueprintRules: [{ field_key: 'cyc_a', compute_rule: JSON.stringify(concat('plain')) }],
      variantRules: [ruleRow('v-1', 'cyc_b', concat('plain'))],
    }) });
    const res = await put('/edge/app/schema/blueprint_fields/2ce8ba8e-83f5-41ee-8246-a2265095b549', { value_source: 'calculated', compute_rule: concat('plain') });
    assert.equal(res.status, 200);
    assert.equal(conn.committed(), true);
  });

  it('replaces, not adds to, the stored blueprint rule for the field being written', async () => {
    // The stored rule for cyc_b closes a loop with cyc_a; the incoming rule
    // replaces it outright, so the loop is gone.
    conn = makeConn({ scripts: scripts({
      blueprintRules: [
        { field_key: 'cyc_a', compute_rule: JSON.stringify(concat('cyc_b')) },
        { field_key: 'cyc_b', compute_rule: JSON.stringify(concat('cyc_a')) },
      ],
    }) });
    const res = await put('/edge/app/schema/blueprint_fields/2ce8ba8e-83f5-41ee-8246-a2265095b549', { value_source: 'calculated', compute_rule: concat('plain') });
    assert.equal(res.status, 200);
  });
});

describe('PUT /blueprint_fields/:id — rename and compute_rule in one write', () => {
  // The field editor submits the whole form, so a rename and a rule edit arrive
  // together. Every stored row is filed under the key the field has RIGHT NOW,
  // while the incoming rule belongs to the key it will have after the write.
  // Matching stored rows by the new key leaves the field in the graph twice.

  it('drops the stored rule of the field being renamed — its old key is a missing source, not a loop', async () => {
    // Stored: this field (cyc_b) computes from the name it is about to take.
    // The incoming rule points back at the key the field is LEAVING, and after
    // the write nothing carries that key: the honest answer is a missing
    // source. Reading 'cycle' here would mean the stored rule had been left in
    // the graph under the old key while the incoming one entered under the new
    // one — one field, two nodes.
    conn = makeConn({ scripts: scripts({
      blueprintRules: [{ field_key: 'cyc_b', compute_rule: JSON.stringify(concat('renamed_b')) }],
    }) });
    const res = await put('/edge/app/schema/blueprint_fields/2ce8ba8e-83f5-41ee-8246-a2265095b549', {
      field_key: 'renamed_b', value_source: 'calculated', compute_rule: concat('cyc_b'),
    });
    assert.equal(res.status, 400);
    assert.equal(res.body.error.code, 'missing_source');
    assert.equal(fieldUpdate(conn.queries), undefined, 'nothing may be written');
  });

  it("graphs a variant's override on the renamed field under its new key", async () => {
    // v-1 overrides the field being renamed, so post-write that override shadows
    // the incoming blueprint rule in v-1 — and the loop v-1 would otherwise have
    // (cyc_a → renamed_b → cyc_a) never forms.
    conn = makeConn({ scripts: scripts({
      variantRules: [
        ruleRow('v-1', 'cyc_b', concat('plain')),
        ruleRow('v-1', 'cyc_a', concat('renamed_b')),
      ],
    }) });
    const res = await put('/edge/app/schema/blueprint_fields/2ce8ba8e-83f5-41ee-8246-a2265095b549', {
      field_key: 'renamed_b', value_source: 'calculated', compute_rule: concat('cyc_a'),
    });
    assert.equal(res.status, 200);
    assert.equal(conn.committed(), true);
  });

  it('still rejects a cycle that the rename does not break', async () => {
    conn = makeConn({ scripts: scripts({
      blueprintRules: [{ field_key: 'cyc_a', compute_rule: JSON.stringify(concat('renamed_b')) }],
    }) });
    const res = await put('/edge/app/schema/blueprint_fields/2ce8ba8e-83f5-41ee-8246-a2265095b549', {
      field_key: 'renamed_b', value_source: 'calculated', compute_rule: concat('cyc_a'),
    });
    assert.equal(res.status, 400);
    assert.equal(res.body.error.code, 'cycle');
  });
});

describe('PUT /blueprint_fields/:id — blueprint-level compute rule validation', () => {
  it('rejects a rule whose source field does not exist', async () => {
    conn = makeConn({ scripts: scripts() });
    const res = await put('/edge/app/schema/blueprint_fields/2ce8ba8e-83f5-41ee-8246-a2265095b549', { value_source: 'calculated', compute_rule: concat('ghost') });
    assert.equal(res.status, 400);
    assert.equal(res.body.error.code, 'missing_source');
    assert.equal(fieldUpdate(conn.queries), undefined);
  });

  it('rejects a rule whose output type does not match the field type', async () => {
    conn = makeConn({ scripts: scripts() });
    const res = await put('/edge/app/schema/blueprint_fields/2ce8ba8e-83f5-41ee-8246-a2265095b549', {
      value_source: 'calculated',
      compute_rule: {
        op: 'arith',
        overridable: false,
        output_type: 'number',
        config: { operator: 'add', operands: [{ type: 'literal', value: 1 }] },
      },
    });
    assert.equal(res.status, 400);
    assert.equal(res.body.error.code, 'output_type_mismatch');
  });

  it('rejects an unknown op', async () => {
    conn = makeConn({ scripts: scripts() });
    const res = await put('/edge/app/schema/blueprint_fields/2ce8ba8e-83f5-41ee-8246-a2265095b549', {
      value_source: 'calculated',
      compute_rule: { op: 'danger', overridable: false, output_type: 'string', config: {} },
    });
    assert.equal(res.status, 400);
    assert.equal(res.body.error.code, 'unknown_op');
  });

  it('rejects an oversize rule and says what the limit is', async () => {
    conn = makeConn({ scripts: scripts() });
    const res = await put('/edge/app/schema/blueprint_fields/2ce8ba8e-83f5-41ee-8246-a2265095b549', {
      value_source: 'calculated',
      compute_rule: {
        op: 'concat', overridable: false, output_type: 'string',
        config: { parts: Array.from({ length: MAX_CONCAT_PARTS + 1 }, () => ({ type: 'literal', text: 'x' })) },
      },
    });
    assert.equal(res.status, 400);
    assert.equal(res.body.error.code, 'too_many_parts');
    assert.match(res.body.error.message, new RegExp(String(MAX_CONCAT_PARTS)));
    assert.equal(fieldUpdate(conn.queries), undefined);
  });
});

describe('PUT /blueprint_fields/:id — when the scan is skipped', () => {
  it('does not scan when the rule is being cleared', async () => {
    conn = makeConn({ scripts: scripts() });
    // The mode travels with the clear: dropping the rule is a mode change, and
    // the write boundary refuses a payload column arriving without its mode —
    // an explicit null included, since that is the shape that strips the rule a
    // stored 'copied'/'calculated' field IS.
    const res = await put('/edge/app/schema/blueprint_fields/2ce8ba8e-83f5-41ee-8246-a2265095b549', {
      value_source: 'entered', compute_rule: null,
    });
    assert.equal(res.status, 200);
    assert.equal(conn.queries.some((q) => /compute_rule FROM/i.test(q.sql)), false,
      'clearing a rule removes an edge; it can never close a cycle');
  });

  it('does not scan when the write does not touch compute_rule', async () => {
    conn = makeConn({ scripts: scripts() });
    const res = await put('/edge/app/schema/blueprint_fields/2ce8ba8e-83f5-41ee-8246-a2265095b549', { field_label: 'PN' });
    assert.equal(res.status, 200);
    assert.equal(conn.queries.some((q) => /compute_rule FROM/i.test(q.sql)), false);
  });

  it('does not scan on a DB whose compute_rule column was never created', async () => {
    // The column is gated out of the UPDATE, so there is nothing to validate.
    conn = makeConn({ columns: BF_COLUMNS_PRE_MIGRATION, scripts: scripts() });
    const res = await put('/edge/app/schema/blueprint_fields/2ce8ba8e-83f5-41ee-8246-a2265095b549', { field_label: 'PN', value_source: 'calculated', compute_rule: concat('cyc_a'),
    });
    assert.equal(res.status, 200);
    assert.ok(!/compute_rule/.test(fieldUpdate(conn.queries).sql));
  });
});
