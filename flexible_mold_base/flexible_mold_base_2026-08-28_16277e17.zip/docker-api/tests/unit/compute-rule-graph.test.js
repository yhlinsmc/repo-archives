/**
 * compute-rule-graph.test.js — the precedence arithmetic that the two-level
 * cycle guard rests on, with no DB and no HTTP.
 *
 * A compute rule can live on `blueprint_fields.compute_rule` (every variant) or
 * on a variant_overrides row with action='compute' (one variant). The graph the
 * guard checks is therefore per variant, and the only interesting question is
 * which of the two levels supplies the edges for a given field. Getting that
 * wrong is silent in both directions: keeping a shadowed blueprint rule rejects
 * writes that are safe, dropping an unshadowed one persists a cycle.
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');

const {
  parseStoredRule,
  extractComputeSources,
  extractSameTableColumnRefs,
  extractLookupSourceColumnRefs,
  hasRowContextSource,
  buildColumnComputeNodes,
  hasColumnCycle,
  buildEffectiveRules,
  buildFieldContext,
  hasCycle,
  makeSourceCache,
  distinctVariantRuleSets,
} = require('../../src/edge/lib/compute-rule-graph');

const concat = (...keys) => ({
  op: 'concat',
  overridable: false,
  output_type: 'string',
  config: { parts: keys.map((key) => ({ type: 'field', key })) },
});

describe('parseStoredRule', () => {
  it('accepts a parsed object and a serialized one alike', () => {
    const rule = concat('a');
    assert.deepEqual(parseStoredRule(rule), rule);
    assert.deepEqual(parseStoredRule(JSON.stringify(rule)), rule);
  });

  it('returns null for anything that is not a rule object', () => {
    for (const bad of [null, undefined, 'not json', '[]', '"str"', '42', [1, 2], 7]) {
      assert.equal(parseStoredRule(bad), null, `expected ${JSON.stringify(bad)} to parse to null`);
    }
  });
});

describe('buildEffectiveRules — variant level replaces blueprint level', () => {
  it('keeps a blueprint rule on a field the variant does not override', () => {
    const blueprint = new Map([['a', concat('b')]]);
    const effective = buildEffectiveRules(blueprint, new Map());
    assert.deepEqual(effective.get('a'), concat('b'));
  });

  it('replaces (never merges) the blueprint rule when the variant overrides the field', () => {
    const blueprint = new Map([['a', concat('b')]]);
    const variant = new Map([['a', concat('c')]]);
    const effective = buildEffectiveRules(blueprint, variant);
    assert.deepEqual(effective.get('a'), concat('c'));
    assert.equal(effective.size, 1);
  });

  it('does not mutate the blueprint map it was given', () => {
    const blueprint = new Map([['a', concat('b')]]);
    buildEffectiveRules(blueprint, new Map([['z', concat('a')]]));
    assert.deepEqual([...blueprint.keys()], ['a']);
  });
});

describe('hasCycle over the effective graph', () => {
  it('sees a cycle that spans one blueprint rule and one variant rule', () => {
    const blueprint = new Map([['a', concat('b')]]);
    const variant = new Map([['b', concat('a')]]);
    assert.equal(hasCycle(buildEffectiveRules(blueprint, variant)), true);
  });

  it('does not see a cycle when the variant SHADOWS the blueprint rule that closed it', () => {
    // Blueprint: a <- b. Variant: b <- a would close the loop, but the variant
    // also replaces a with a rule that references nothing, so the blueprint's
    // a <- b edge never evaluates here.
    const blueprint = new Map([['a', concat('b')]]);
    const variant = new Map([['b', concat('a')], ['a', concat('standalone')]]);
    assert.equal(hasCycle(buildEffectiveRules(blueprint, variant)), false);
  });

  it('sees a self-referencing rule as a cycle', () => {
    assert.equal(hasCycle(new Map([['a', concat('a')]])), true);
  });

  it('accepts a chain that never closes', () => {
    const rules = new Map([['a', concat('b')], ['b', concat('c')]]);
    assert.equal(hasCycle(rules), false);
  });
});

describe('extractComputeSources', () => {
  it('reads field keys out of every op the validator accepts', () => {
    assert.deepEqual(extractComputeSources(concat('a', 'b')), ['a', 'b']);
    assert.deepEqual(
      extractComputeSources({ op: 'transform', config: { source: 'a', transform: 'upper' } }),
      ['a'],
    );
    assert.deepEqual(
      extractComputeSources({
        op: 'arith',
        config: { operator: 'add', operands: [{ type: 'field', key: 'a' }, { type: 'literal', value: 1 }] },
      }),
      ['a'],
    );
    assert.deepEqual(extractComputeSources({ op: 'lookup', config: { source: 'a', table: [] } }), ['a']);
  });

  it('yields nothing for a rule shape it cannot read', () => {
    for (const bad of [null, {}, { op: 'nope', config: {} }]) {
      assert.deepEqual(extractComputeSources(bad), []);
    }
  });

  // same_table_column names a COLUMN of the rule's own
  // owner table, not a field — it must not be read as a field-level source.
  // The column-level dimension (P1b) is a SEPARATE graph over SEPARATE
  // nodes — see hasColumnCycle / extractSameTableColumnRefs below — not an
  // addition to this extractor, which stays field-level-only on purpose.
  it('yields nothing for a same_table_column term, same as a literal', () => {
    const concatWithCol = {
      op: 'concat',
      config: { parts: [{ type: 'field', key: 'a' }, { type: 'same_table_column', column_key: 'part' }] },
    };
    assert.deepEqual(extractComputeSources(concatWithCol), ['a']);
    const arithWithCol = {
      op: 'arith',
      config: { operator: 'add', operands: [{ type: 'same_table_column', column_key: 'qty' }, { type: 'literal', value: 1 }] },
    };
    assert.deepEqual(extractComputeSources(arithWithCol), []);
  });
});

describe('buildFieldContext', () => {
  it('collects every field key and the column allowlist of each table field', () => {
    const { fieldKeys, tableColumns } = buildFieldContext([
      { field_key: 'pn', field_type: 'text', table_config: null },
      { field_key: 'items', field_type: 'table', table_config: JSON.stringify({ columns: [{ key: 'part' }] }) },
    ]);
    assert.deepEqual([...fieldKeys].sort(), ['items', 'pn']);
    assert.deepEqual([...tableColumns.get('items')], ['part']);
    assert.equal(tableColumns.has('pn'), false);
  });

  it("falls back to the implicit 'value' column for a table with no columns config", () => {
    const { tableColumns } = buildFieldContext([
      { field_key: 'items', field_type: 'table', table_config: JSON.stringify({}) },
    ]);
    assert.deepEqual([...tableColumns.get('items')], ['value']);
  });
});

// ── Per-request reuse ───────────────────────────────────────────────────────
// The guard runs one topological sort per variant carrying compute overrides,
// and every sort re-reads the sources of every blueprint-level rule. Both the
// per-rule source walk and the whole sort are pure functions of their input, so
// neither has to be repeated.

describe('makeSourceCache', () => {
  it('walks a given rule object once, however often it is asked', () => {
    let reads = 0;
    const rule = new Proxy(concat('a'), {
      get(target, prop) { if (prop === 'config') reads += 1; return target[prop]; },
    });
    const extract = makeSourceCache();
    assert.deepEqual(extract(rule), ['a']);
    const afterFirstWalk = reads;
    assert.ok(afterFirstWalk > 0, 'the first call must actually walk the rule');
    assert.deepEqual(extract(rule), ['a']);
    assert.deepEqual(extract(rule), ['a']);
    assert.equal(reads, afterFirstWalk, 'later calls must not touch the rule again');
  });

  it('is per-cache, so two caches do not share state', () => {
    const rule = concat('a');
    assert.deepEqual(makeSourceCache()(rule), makeSourceCache()(rule));
  });

  it('feeds hasCycle without changing its verdict', () => {
    const rules = new Map([['a', concat('b')], ['b', concat('a')]]);
    assert.equal(hasCycle(rules, makeSourceCache()), true);
    assert.equal(hasCycle(new Map([['a', concat('b')]]), makeSourceCache()), false);
  });
});

describe('distinctVariantRuleSets', () => {
  it('collapses variants whose override sets carry the same edges', () => {
    // Two variants configured identically are two DB rows, so their rule objects
    // are never identical — only their content is. Laid over the same blueprint
    // rules they produce the same graph, so one sort answers for both.
    const byVariant = new Map([
      ['v-1', new Map([['a', concat('b')]])],
      ['v-2', new Map([['a', concat('b')]])],
      ['v-3', new Map([['a', concat('c')]])],
    ]);
    const sets = distinctVariantRuleSets(byVariant, makeSourceCache());
    assert.equal(sets.length, 2);
  });

  it('keeps variants apart when the same field carries different sources', () => {
    const byVariant = new Map([
      ['v-1', new Map([['a', concat('b')], ['x', concat('y')]])],
      ['v-2', new Map([['a', concat('b')]])],
    ]);
    assert.equal(distinctVariantRuleSets(byVariant, makeSourceCache()).length, 2);
  });

  it('ignores the order the fields arrive in', () => {
    const byVariant = new Map([
      ['v-1', new Map([['a', concat('b')], ['x', concat('y')]])],
      ['v-2', new Map([['x', concat('y')], ['a', concat('b')]])],
    ]);
    assert.equal(distinctVariantRuleSets(byVariant, makeSourceCache()).length, 1);
  });
});

// A column formula: `columnKey = <same-table column(s)> [+ field refs]` — the
// BE mirror of compute-graph.test.ts's own `columnRule` helper, kept in sync
// by the shared fixture below rather than by eyeballing the two.
const columnRule = (sameTableCols, fieldKeys = []) => ({
  op: 'concat',
  overridable: true,
  output_type: 'string',
  config: {
    parts: [
      ...sameTableCols.map((c) => ({ type: 'same_table_column', column_key: c })),
      ...fieldKeys.map((k) => ({ type: 'field', key: k })),
    ],
  },
});

describe('extractSameTableColumnRefs / hasRowContextSource (P1b)', () => {
  it('reads column keys out of concat and arith same_table_column terms, and nothing else', () => {
    assert.deepEqual(extractSameTableColumnRefs(columnRule(['a', 'b'])), ['a', 'b']);
    assert.deepEqual(extractSameTableColumnRefs(concat('x')), []);
    assert.deepEqual(extractSameTableColumnRefs(null), []);
  });

  it('is true only for a rule carrying at least one same_table_column term, regardless of column_key content', () => {
    assert.equal(hasRowContextSource(columnRule(['a'])), true);
    assert.equal(hasRowContextSource(concat('a')), false);
    assert.equal(hasRowContextSource({ op: 'concat', config: { parts: [{ type: 'same_table_column' }] } }), true);
  });
});

// A by-key lookup term: 4 names (table_key, matchKeyColumn, ownKeyColumn,
// valueColumn). Unlike same_table_column, its TARGET table_key IS a
// field-level source (extractComputeSources); its ownKeyColumn is the
// same-table-implicit half (extractSameTableColumnRefs), same as
// same_table_column's own column_key.
const lookupRule = (lookupRef) => ({
  op: 'concat',
  overridable: true,
  output_type: 'string',
  config: { parts: [{ type: 'table_column_lookup', lookupRef }] },
});
const validLookupRef = { table_key: 'catalog', matchKeyColumn: 'sku', ownKeyColumn: 'q', valueColumn: 'price' };

describe('table_column_lookup extraction (extractComputeSources / extractSameTableColumnRefs / extractLookupSourceColumnRefs / hasRowContextSource)', () => {
  it('extractComputeSources: the TARGET table_key IS a field-level source, unlike same_table_column', () => {
    assert.deepEqual(extractComputeSources(lookupRule(validLookupRef)), ['catalog']);
    const arithRule = { op: 'arith', overridable: true, output_type: 'number',
      config: { operator: 'add', operands: [{ type: 'table_column_lookup', lookupRef: validLookupRef }] } };
    assert.deepEqual(extractComputeSources(arithRule), ['catalog']);
  });

  it('extractSameTableColumnRefs: ownKeyColumn is the same-table-implicit half, same as same_table_column', () => {
    assert.deepEqual(extractSameTableColumnRefs(lookupRule(validLookupRef)), ['q']);
  });

  it('extractLookupSourceColumnRefs: matchKeyColumn and valueColumn, both on the TARGET table', () => {
    assert.deepEqual(extractLookupSourceColumnRefs(lookupRule(validLookupRef)), [
      { table_key: 'catalog', column_key: 'sku' },
      { table_key: 'catalog', column_key: 'price' },
    ]);
    assert.deepEqual(extractLookupSourceColumnRefs(columnRule(['a'])), []);
    assert.deepEqual(extractLookupSourceColumnRefs(null), []);
  });

  it('hasRowContextSource is true for a table_column_lookup term', () => {
    assert.equal(hasRowContextSource(lookupRule(validLookupRef)), true);
  });
});

describe('buildColumnComputeNodes (P1b / P2)', () => {
  it('drops a candidate that is not row-context', () => {
    const nodes = buildColumnComputeNodes([
      { node: 'n', tableKey: 'items', rule: concat('a'), columns: { columns: ['p'] } },
    ]);
    assert.deepEqual(nodes, []);
  });

  it('drops a candidate narrowed to zero or 2+ columns — P2: EXACTLY one', () => {
    const rowContext = columnRule(['sibling']);
    assert.deepEqual(buildColumnComputeNodes([{ node: 'n', tableKey: 'items', rule: rowContext, columns: null }]), []);
    assert.deepEqual(
      buildColumnComputeNodes([{ node: 'n', tableKey: 'items', rule: rowContext, columns: { columns: ['p', 'q'] } }]),
      [],
    );
  });

  it('keeps a row-context candidate narrowed to exactly one column', () => {
    const rule = columnRule(['sibling']);
    const nodes = buildColumnComputeNodes([{ node: 'n', tableKey: 'items', rule, columns: { columns: ['p'] } }]);
    assert.deepEqual(nodes, [{ node: 'n', table_key: 'items', column_key: 'p', rule }]);
  });

  // M1 (fix batch, adv A MED): the SAME "P2: EXACTLY one column" filter above
  // gates a `table_column_lookup` candidate too — `hasRowContextSource` and
  // `singleScopedColumn` never branch on the term TYPE, so a lookup rule
  // narrowed to 2+ columns escapes column-node registration (and therefore
  // cross-table cycle detection) exactly like a same_table_column one would.
  // Pinned explicitly here rather than left to the shared-code-path
  // inference above, since this is the escape the finding named.
  it('drops a table_column_lookup candidate narrowed to 2+ columns — same P2 gate as same_table_column', () => {
    const rule = lookupRule(validLookupRef);
    assert.deepEqual(
      buildColumnComputeNodes([{ node: 'n', tableKey: 'items', rule, columns: { columns: ['p', 'q'] } }]),
      [],
    );
  });

  it('keeps a table_column_lookup candidate narrowed to exactly one column', () => {
    const rule = lookupRule(validLookupRef);
    const nodes = buildColumnComputeNodes([{ node: 'n', tableKey: 'items', rule, columns: { columns: ['p'] } }]);
    assert.deepEqual(nodes, [{ node: 'n', table_key: 'items', column_key: 'p', rule }]);
  });
});

describe('hasColumnCycle (P1b)', () => {
  it('is false with no column nodes', () => {
    assert.equal(hasColumnCycle(new Map(), []), false);
  });

  it('flags a same-table SELF-cycle: a column formula reading its own narrowed column', () => {
    const rule = columnRule(['p']); // reads column 'p' ...
    const nodes = buildColumnComputeNodes([{ node: 'n', tableKey: 'items', rule, columns: { columns: ['p'] } }]); // ... and is narrowed to 'p'
    assert.equal(hasColumnCycle(new Map(), nodes), true);
  });

  it('does not flag a column formula reading a DIFFERENT column of the same table', () => {
    const rule = columnRule(['other']);
    const nodes = buildColumnComputeNodes([{ node: 'n', tableKey: 'items', rule, columns: { columns: ['p'] } }]);
    assert.equal(hasColumnCycle(new Map(), nodes), false);
  });

  it('flags a cross-field cycle spanning two levels: field A (blueprint) reads B, field B (variant) reads A', () => {
    // The literal P1b repro: field A's blueprint-level column formula reads
    // row.B, a NEW variant override on field B reads row.A — same shape as
    // FE's own cross-level authoring/eval graphs, expressed here as two
    // distinct table fields each narrowed to their own single column.
    const sourcesDisjointTables = [
      { node: 'fieldA::blueprint', tableKey: 'fieldA', rule: columnRule(['colB']), columns: { columns: ['colA'] } },
      { node: 'fieldB::variant', tableKey: 'fieldB', rule: columnRule(['colA']), columns: { columns: ['colB'] } },
    ];
    // A same_table_column term only ever addresses its OWN table's columns —
    // so this fixture puts the "reads B" / "reads A" edges on ONE shared
    // table (both fields ARE that table's two column formulas) to actually
    // close a graph cycle; two genuinely different tables can never cross-
    // reference via same_table_column alone (see the module doc-block).
    const sourcesSameTable = [
      { node: 'items::colA', tableKey: 'items', rule: columnRule(['colB']), columns: { columns: ['colA'] } },
      { node: 'items::colB', tableKey: 'items', rule: columnRule(['colA']), columns: { columns: ['colB'] } },
    ];
    assert.equal(hasColumnCycle(new Map(), buildColumnComputeNodes(sourcesSameTable)), true);
    // Sanity: the two-different-tables fixture above is NOT a cycle —
    // confirms the guard does not over-fire across unrelated tables.
    assert.equal(hasColumnCycle(new Map(), buildColumnComputeNodes(sourcesDisjointTables)), false);
  });

  it('links a column node to a whole-field compute node via an ordinary field reference', () => {
    // field 'summary' (whole-field) depends on column 'items::p'; column
    // 'items::p' depends on field 'label' — one combined graph, no cycle.
    const rules = new Map([['summary', columnRule([], ['proxy'])]]);
    const colNode = { node: 'items::p', tableKey: 'items', rule: columnRule([], ['summary']), columns: null };
    // Not narrowed (columns: null) drops out of buildColumnComputeNodes, so
    // build it directly as a ColumnComputeNode-shaped object instead — this
    // test exercises hasColumnCycle's edge wiring, not the node filter.
    const columnNodes = [{ node: 'items::p', table_key: 'items', column_key: 'p', rule: colNode.rule }];
    assert.equal(hasColumnCycle(rules, columnNodes), false);
  });

  it('links a lookup column node to the TARGET table column it reads — cross-table, via extractLookupSourceColumnRefs', () => {
    // table A's column 'total' looks up table B's column 'price'; B's
    // 'price' is itself a column-narrowed rule, so the two must be one
    // graph — no cycle, but B::price is a real dependency A::total sits
    // behind.
    const bPrice = { node: 'B::price', table_key: 'B', column_key: 'price', rule: columnRule(['unit_price']) };
    const aTotal = {
      node: 'A::total', table_key: 'A', column_key: 'total',
      rule: lookupRule({ table_key: 'B', matchKeyColumn: 'sku', ownKeyColumn: 'sku', valueColumn: 'price' }),
    };
    assert.equal(hasColumnCycle(new Map(), [bPrice, aTotal]), false);
  });

  it('flags a cross-table 2-cycle formed entirely through table_column_lookup TARGET columns', () => {
    const aX = {
      node: 'A::x', table_key: 'A', column_key: 'x',
      rule: lookupRule({ table_key: 'B', matchKeyColumn: 'key', ownKeyColumn: 'key', valueColumn: 'y' }),
    };
    const bY = {
      node: 'B::y', table_key: 'B', column_key: 'y',
      rule: lookupRule({ table_key: 'A', matchKeyColumn: 'key', ownKeyColumn: 'key', valueColumn: 'x' }),
    };
    assert.equal(hasColumnCycle(new Map(), [aX, bY]), true);
  });

  it('flags a UNION collision: same field, two levels, SAME single column — order-dependent but still resolvable, never silently dropped', () => {
    // Both levels narrow to column 'p'; per real precedence the variant wins
    // ownership of that cell, but the guard's job here is only "is there a
    // cycle", and a same-column collision where each side reads the OTHER
    // is still a cycle under either resolution.
    const blueprintNode = { node: 'items::blueprint', table_key: 'items', column_key: 'p', rule: columnRule(['q']) };
    const variantNode = { node: 'items::variant', table_key: 'items', column_key: 'p', rule: columnRule(['q']) };
    const qNode = { node: 'items::q', table_key: 'items', column_key: 'q', rule: columnRule(['p']) };
    assert.equal(hasColumnCycle(new Map(), [blueprintNode, variantNode, qNode]), true);
  });
});
