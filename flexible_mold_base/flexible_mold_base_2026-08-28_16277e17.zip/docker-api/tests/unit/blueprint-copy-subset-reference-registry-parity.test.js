/**
 * blueprint-copy-subset-reference-registry-parity.test.js — the copy path's
 * remap/break-detection surface must be DERIVED from
 * `blueprint-field-key-references.js`, never a second hand-kept list. This
 * iterates every registry entry and drives `getReferencedKey` /
 * `withReferencedKeyRewritten` through it generically (via `site.path`, never
 * a column name hardcoded per-site) — a future registry entry with a
 * different path shape is exercised by this same loop with no edit here,
 * which is the property this test exists to hold.
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');

const dbKey = require.resolve('../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: {}, t: (n) => n, getDynamicPool: async () => ({ rw: {}, ro: {} }) },
};

const { getReferencedKey, withReferencedKeyRewritten } = require('../../src/edge/lib/blueprint-copy-subset');
const { BLUEPRINT_FIELD_KEY_REFERENCES } = require('../../src/edge/lib/blueprint-field-key-references');

// Builds a row carrying `refKey` at `site`'s location — a plain string for a
// null path, a JSON document holding it at the declared path otherwise.
function rowNaming(site, refKey) {
  if (site.path === null) return { [site.column]: refKey };
  const keys = [...site.path.matchAll(/\."([a-z][a-z0-9_]*)"/g)].map((m) => m[1]);
  let doc = refKey;
  for (let i = keys.length - 1; i >= 0; i -= 1) doc = { [keys[i]]: doc };
  return { [site.column]: doc };
}

describe('registry parity — every BLUEPRINT_FIELD_KEY_REFERENCES site', () => {
  for (const site of BLUEPRINT_FIELD_KEY_REFERENCES) {
    describe(`site: ${site.column}${site.path ? ` (${site.path})` : ''}`, () => {
      it('getReferencedKey extracts the named key', () => {
        const row = rowNaming(site, 'parent_field');
        assert.equal(getReferencedKey(row, site), 'parent_field');
      });

      it('getReferencedKey returns null when the row carries no reference', () => {
        assert.equal(getReferencedKey({ [site.column]: null }, site), null);
      });

      it('withReferencedKeyRewritten rewrites in place, preserving the rest of the document', () => {
        const raw = site.path === null ? 'old_key' : { ...rowNaming(site, 'old_key')[site.column], operator: 'eq', value: 'x' };
        const rewritten = withReferencedKeyRewritten(raw, site, 'new_key');
        assert.equal(getReferencedKey({ [site.column]: rewritten }, site), 'new_key');
        if (site.path !== null) {
          assert.equal(rewritten.operator, 'eq', 'sibling document keys must survive the rewrite');
          assert.equal(rewritten.value, 'x', 'sibling document keys must survive the rewrite');
        }
      });

      it('withReferencedKeyRewritten(null) drops the reference (whole column goes null)', () => {
        const row = rowNaming(site, 'old_key');
        assert.equal(withReferencedKeyRewritten(row[site.column], site, null), null);
      });
    });
  }

  it('the registry is non-empty — an empty list would make every test above vacuous', () => {
    assert.ok(BLUEPRINT_FIELD_KEY_REFERENCES.length > 0);
  });
});
