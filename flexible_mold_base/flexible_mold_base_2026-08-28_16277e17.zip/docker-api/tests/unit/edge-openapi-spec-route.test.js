/**
 * edge-openapi-spec-route.test.js — the login-gated internal (edge) OpenAPI
 * spec route (GET /edge/openapi.json).
 *
 * Posture change (v3.2.484): the edge spec was previously served with NO auth
 * in ALL environments (exempt from s2sVerify). It is now an operator surface —
 * in production s2sVerify rejects any un-verified direct hit with the standard
 * S2S 401, and this inner gate additionally requires a forwarded HUMAN identity
 * (req.user present, role !== 'service_account'). A machine principal gets 401.
 *
 * s2sVerify reconstructs req.user from the forwarded identity headers; this test
 * fakes that step with a middleware that copies a controllable currentUser onto
 * req.user (mirrors public-docs-route.test.js) so it isolates the human-only
 * gate that mountEdgeInternalSpec owns.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const { mountEdgeInternalSpec } = require('../../src/edge/openapi-spec');

let currentUser;

function buildServer() {
  const app = express();
  app.use((req, _res, next) => { if (currentUser) req.user = currentUser; next(); });
  mountEdgeInternalSpec(app);
  return app;
}

function request(path_, headers = {}) {
  return new Promise((resolve, reject) => {
    const req = http.request(
      { host: '127.0.0.1', port, path: path_, method: 'GET', headers },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          const raw = Buffer.concat(chunks).toString('utf-8');
          let json = null; try { json = JSON.parse(raw); } catch { /* non-json */ }
          resolve({ status: res.statusCode, headers: res.headers, raw, json });
        });
      },
    );
    req.on('error', reject);
    req.end();
  });
}

let server;
let port;

before(async () => {
  const app = buildServer();
  await new Promise((resolve) => { server = app.listen(0, '127.0.0.1', () => { port = server.address().port; resolve(); }); });
});

after(async () => { await new Promise((resolve) => server.close(resolve)); });

beforeEach(() => { currentUser = null; });

describe('GET /edge/openapi.json (login-gated internal spec)', () => {
  it('401 when no identity was resolved (req.user unset)', async () => {
    const res = await request('/edge/openapi.json');
    assert.equal(res.status, 401);
    assert.equal(res.json?.error?.code, 'UNAUTHORIZED');
  });

  it('401 for a machine principal (service_account) — machine tokens get no access', async () => {
    currentUser = { id: 'sa-1', role: 'service_account', type: 'service_account', scope: { blueprint: ['b-1'] } };
    const res = await request('/edge/openapi.json', { Authorization: 'Bearer sa-opaque-machine-token' });
    assert.equal(res.status, 401);
    assert.equal(res.json?.error?.code, 'UNAUTHORIZED');
  });

  it('200 for a forwarded human identity and serves an OpenAPI document', async () => {
    currentUser = { id: 'u-1', role: 'user', email: 'u@x' };
    const res = await request('/edge/openapi.json');
    assert.equal(res.status, 200);
    assert.equal(typeof res.json?.openapi, 'string');
    assert.ok(res.json?.paths && Object.keys(res.json.paths).length > 0, 'expected a non-empty paths object');
  });

  // Regression guard for the schema.js -> schema/ folder split: the
  // generic schema CRUD @openapi block moved into schema/helpers.js, so
  // EDGE_ROUTE_FILES must point at the new location. If it silently reverts to
  // the old flat path (now a directory), buildPaths' fs.existsSync skips it and
  // these paths vanish from the spec with no error.
  it('includes the generic schema table CRUD paths (EDGE_ROUTE_FILES covers schema/ folder)', async () => {
    currentUser = { id: 'u-1', role: 'user', email: 'u@x' };
    const res = await request('/edge/openapi.json');
    assert.equal(res.status, 200);
    assert.ok(res.json?.paths?.['/edge/app/schema/{table}'], 'spec must expose /edge/app/schema/{table}');
    assert.ok(res.json?.paths?.['/edge/app/schema/{table}/{id}'], 'spec must expose /edge/app/schema/{table}/{id}');
  });
});
