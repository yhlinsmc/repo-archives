/**
 * decision-output-claim-guard.test.js.
 *
 * The UI has refused a second decision table claiming an output field since the
 * feature shipped; the API accepted it, and the runtime's answer to two live
 * tables filling one field is to fill it from NEITHER. These pin the server-side
 * refusal and both of its carve-outs, through the real route.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const { answerParentIdProbe } = require('../helpers/parent-id-probe');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../src/edge/db');

const DECISION_COLUMNS = ['id', 'blueprint_id', 'name', 'doc', 'created_at'];

const doc = (conditions, outputs, rows = []) => ({
  conditions: conditions.map((field_key) => ({ field_key })),
  outputs: outputs.map((field_key) => ({ field_key })),
  rows,
});

let conn;
let dbSeq = 0;
const ADMIN = { id: '5b729f1e-5c0b-447c-8144-3210469bc62c', role: 'admin' };
let currentUser = ADMIN;

/** @param {{stored?: object[]}} opts stored rows the blueprint already has */
function makeConn({ stored = [], tableExists = true, blueprintOwnerId = null } = {}) {
  const dbName = `db_${dbSeq += 1}`;
  const queries = [];
  let committed = false;
  let rolledBack = false;
  return {
    queries,
    committed: () => committed,
    rolledBack: () => rolledBack,
    async beginTransaction() {},
    async commit() { committed = true; },
    async rollback() { rolledBack = true; },
    async query(sql, params) {
      queries.push({ sql, params });
      if (/^SELECT DATABASE\(\)/i.test(sql)) return [{ db: dbName }];
      if (/information_schema\.TABLES/i.test(sql)) return tableExists ? [{ c: 1 }] : [];
      if (/information_schema\.COLUMNS/i.test(sql)) {
        return DECISION_COLUMNS.map((c) => ({ COLUMN_NAME: c }));
      }
      // The ownership pre-read the factory takes before the pre-write hook on a
      // PATCH-style PUT, and the owner chain it feeds.
      if (/SELECT `blueprint_id` AS parent_value FROM `fmb_decision_tables`/i.test(sql)) {
        const row = stored.find((r) => r.id === params[0]);
        return row ? [{ parent_value: row.blueprint_id }] : [];
      }
      // The parent-id resolution the write takes before binding a reference —
      // ahead of the owner-chain read below, which matches the same table and
      // answers with a row carrying no id at all.
      const parentId = answerParentIdProbe(sql, params);
      if (parentId) return parentId;
      if (/FROM `fmb_hierarchy_nodes`/i.test(sql)) {
        return [{ owner_id: blueprintOwnerId }];
      }
      // The guard's post-state read: the blueprint the row sits in today, and
      // the document it is carrying when the body does not restate one.
      if (/SELECT blueprint_id, doc FROM `fmb_decision_tables`/i.test(sql)) {
        const row = stored.find((r) => r.id === params[0]);
        return row ? [{ blueprint_id: row.blueprint_id, doc: JSON.stringify(row.doc) }] : [];
      }
      if (/SELECT name, doc FROM `fmb_decision_tables`/i.test(sql)) {
        const [blueprintId, excludeId] = params;
        return stored
          .filter((r) => r.blueprint_id === blueprintId && r.id !== excludeId)
          .map((r) => ({ name: r.name, doc: JSON.stringify(r.doc) }));
      }
      // Blueprint-scoped name uniqueness (uniqueWithin) and the linked-parent
      // probe: nothing conflicting in these fixtures.
      if (/SELECT id FROM `fmb_decision_tables`/i.test(sql)) return [];
      if (/SELECT linked_blueprint_id FROM/i.test(sql)) return [];
      if (/ AS bid FROM/i.test(sql) || / AS fk FROM/i.test(sql)) return [];
      if (/^SELECT/i.test(sql) && /FOR UPDATE/i.test(sql)) return [{ id: params[0] }];
      if (/^INSERT INTO/i.test(sql) || /^UPDATE /i.test(sql)) return { affectedRows: 1, insertId: 1 };
      if (/^SELECT \* FROM `fmb_decision_tables`/i.test(sql)) {
        return [{ id: 'cda3af10-a915-465c-8461-01c5ce8b3bd1', blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', name: 'x', doc: '{}' }];
      }
      return [];
    },
    release() {},
  };
}

const poolSpy = {
  rw: { async getConnection() { return conn; } },
  ro: { async getConnection() { return conn; } },
};

require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: poolSpy, t: (name) => `fmb_${name}`, getDynamicPool: async () => poolSpy },
};

const router = require('../../src/edge/routes/app/schema');

let server;
let port;

before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { req.user = currentUser; next(); });
  app.use('/edge/app/schema', router);
  await new Promise((resolve) => {
    server = app.listen(0, '127.0.0.1', () => { port = server.address().port; resolve(); });
  });
});

after(async () => {
  await new Promise((resolve) => server.close(resolve));
  delete require.cache[dbKey];
});

beforeEach(() => { conn = null; currentUser = ADMIN; });

function send(method, path, body) {
  return new Promise((resolve, reject) => {
    const data = JSON.stringify(body);
    const r = http.request({
      method, host: '127.0.0.1', port, path,
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(data) },
    }, (res) => {
      let raw = '';
      res.on('data', (c) => { raw += c; });
      res.on('end', () => resolve({ status: res.statusCode, body: raw ? JSON.parse(raw) : null }));
    });
    r.on('error', reject);
    r.write(data);
    r.end();
  });
}

const wrote = (queries) => queries.some((q) => /^(INSERT INTO|UPDATE) `fmb_decision_tables`/i.test(q.sql.trim()));

const SIZING = {
  id: '99325195-6d2a-42af-8c5b-331b20b19eec', blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', name: 'Sizing',
  doc: doc(['mold_type'], ['cavity_count']),
};

describe('the API refuses a second decision table claiming an output field', () => {
  it('refuses a CREATE that claims a field another live table already fills', async () => {
    conn = makeConn({ stored: [SIZING] });
    const res = await send('POST', '/edge/app/schema/decision_tables', {
      blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', name: 'Second', doc: doc(['region'], ['cavity_count']),
    });
    assert.equal(res.status, 409, JSON.stringify(res.body));
    assert.equal(res.body.error.code, 'DUPLICATE_DECISION_OUTPUT');
    assert.match(res.body.error.message, /Sizing/);
    assert.equal(wrote(conn.queries), false, 'nothing may be written');
    assert.equal(conn.rolledBack(), true);
  });

  it('refuses an UPDATE that adds the claim', async () => {
    conn = makeConn({
      stored: [SIZING, { id: 'e4e219c5-4d4b-4c5a-8b02-d30cc6057641', blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', name: 'Second', doc: doc(['region'], ['lead_time']) }],
    });
    const res = await send('PUT', '/edge/app/schema/decision_tables/e4e219c5-4d4b-4c5a-8b02-d30cc6057641', {
      doc: doc(['region'], ['lead_time', 'cavity_count']),
    });
    assert.equal(res.status, 409, JSON.stringify(res.body));
    assert.equal(res.body.error.code, 'DUPLICATE_DECISION_OUTPUT');
    assert.equal(wrote(conn.queries), false);
  });

  it('allows a claim nobody else makes', async () => {
    conn = makeConn({ stored: [SIZING] });
    const res = await send('POST', '/edge/app/schema/decision_tables', {
      blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', name: 'Second', doc: doc(['region'], ['lead_time']),
    });
    assert.equal(res.status, 200, JSON.stringify(res.body));
    assert.equal(wrote(conn.queries), true);
  });

  it('does not look across blueprints — the rule is per blueprint', async () => {
    conn = makeConn({ stored: [{ ...SIZING, blueprint_id: '34f32e3b-f2c8-4f2a-8edc-0d080eba667f' }] });
    const res = await send('POST', '/edge/app/schema/decision_tables', {
      blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', name: 'Second', doc: doc(['region'], ['cavity_count']),
    });
    assert.equal(res.status, 200, JSON.stringify(res.body));
  });
});

describe('carve-out 1 — a table may always re-select an output it already owns', () => {
  it('lets the owning table save the same output again', async () => {
    // Without this an existing duplicate could never be repaired: every save of
    // the offending table would be refused for a column it is not adding.
    conn = makeConn({ stored: [SIZING] });
    const res = await send('PUT', '/edge/app/schema/decision_tables/99325195-6d2a-42af-8c5b-331b20b19eec', {
      doc: doc(['mold_type'], ['cavity_count'], [{ when: { mold_type: 'steel' }, then: { cavity_count: '4' } }]),
    });
    assert.equal(res.status, 200, JSON.stringify(res.body));
    assert.equal(wrote(conn.queries), true);
  });

  it('lets the owning table save even while a STORED duplicate exists elsewhere', async () => {
    // The state this carve-out exists for: two tables already claim the field,
    // and one of them has to be editable for the repair to be possible.
    conn = makeConn({
      stored: [SIZING, { id: 'e4e219c5-4d4b-4c5a-8b02-d30cc6057641', blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', name: 'Older', doc: doc(['region'], ['lead_time']) }],
    });
    const res = await send('PUT', '/edge/app/schema/decision_tables/99325195-6d2a-42af-8c5b-331b20b19eec', {
      doc: doc(['mold_type'], ['cavity_count']),
    });
    assert.equal(res.status, 200, JSON.stringify(res.body));
  });
});

describe('carve-out 2 — a table with no conditions blocks nobody', () => {
  it('a conditionless STORED table does not refuse a new claim', async () => {
    conn = makeConn({
      stored: [{ id: 'bc1e6597-b51e-4168-866f-6724a5d42b9e', blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', name: 'Half built', doc: doc([], ['cavity_count']) }],
    });
    const res = await send('POST', '/edge/app/schema/decision_tables', {
      blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', name: 'Real', doc: doc(['mold_type'], ['cavity_count']),
    });
    assert.equal(res.status, 200, JSON.stringify(res.body));
    assert.equal(wrote(conn.queries), true);
  });

  it('a conditionless INCOMING table is not refused either — it fills nothing', async () => {
    // "Choose the output column first, add the condition after" is the ordinary
    // authoring order, and refusing its first step would break it.
    conn = makeConn({ stored: [SIZING] });
    const res = await send('POST', '/edge/app/schema/decision_tables', {
      blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', name: 'Half built', doc: doc([], ['cavity_count']),
    });
    assert.equal(res.status, 200, JSON.stringify(res.body));
  });

  it('but the write that MAKES it live is refused — the loop closes', async () => {
    // This is what keeps the carve-out from being a way around the rule.
    conn = makeConn({
      stored: [SIZING, { id: 'bc1e6597-b51e-4168-866f-6724a5d42b9e', blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', name: 'Half built', doc: doc([], ['cavity_count']) }],
    });
    const res = await send('PUT', '/edge/app/schema/decision_tables/bc1e6597-b51e-4168-866f-6724a5d42b9e', {
      doc: doc(['region'], ['cavity_count']),
    });
    assert.equal(res.status, 409, JSON.stringify(res.body));
    assert.equal(res.body.error.code, 'DUPLICATE_DECISION_OUTPUT');
    assert.equal(wrote(conn.queries), false);
  });

  it('a table whose output is also a condition is inert and blocks nobody', async () => {
    conn = makeConn({
      stored: [{ id: 'd6490451-cfe9-41db-8e5f-8fb4b42db09d', blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', name: 'Self', doc: doc(['cavity_count'], ['cavity_count']) }],
    });
    const res = await send('POST', '/edge/app/schema/decision_tables', {
      blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', name: 'Real', doc: doc(['mold_type'], ['cavity_count']),
    });
    assert.equal(res.status, 200, JSON.stringify(res.body));
  });
});

describe('a PUT that MOVES the row carries its claim with it', () => {
  // The row's document is the claim. Repointing `blueprint_id` hands that
  // document to a new set of siblings without the body saying a word about it,
  // and judging the body alone let one curl produce the two-live-tables state
  // the guard exists to make impossible — from which the runtime fills the
  // field from NEITHER table while every surface reports both as healthy.
  const OTHER = {
    id: 'e4e219c5-4d4b-4c5a-8b02-d30cc6057641', blueprint_id: '07cbb7a8-0535-464f-80c7-81559ef886e3', name: 'Moved',
    doc: doc(['region'], ['cavity_count']),
  };

  it('refuses a move that lands a live claim on a field already filled there', async () => {
    conn = makeConn({ stored: [SIZING, OTHER] });
    const res = await send('PUT', '/edge/app/schema/decision_tables/e4e219c5-4d4b-4c5a-8b02-d30cc6057641', { blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26' });
    assert.equal(res.status, 409, JSON.stringify(res.body));
    assert.equal(res.body.error.code, 'DUPLICATE_DECISION_OUTPUT');
    assert.match(res.body.error.message, /Sizing/);
    assert.equal(wrote(conn.queries), false, 'nothing may be written');
  });

  it('allows the same move into a blueprint where nobody claims the field', async () => {
    conn = makeConn({ stored: [{ ...SIZING, blueprint_id: '50c5f111-fcb3-4639-866b-20b943e4acd7' }, OTHER] });
    const res = await send('PUT', '/edge/app/schema/decision_tables/e4e219c5-4d4b-4c5a-8b02-d30cc6057641', { blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26' });
    assert.equal(res.status, 200, JSON.stringify(res.body));
    assert.equal(wrote(conn.queries), true);
  });

  it('allows a move whose carried document is inert — it claims nothing anywhere', async () => {
    conn = makeConn({
      stored: [SIZING, { ...OTHER, doc: doc([], ['cavity_count']) }],
    });
    const res = await send('PUT', '/edge/app/schema/decision_tables/e4e219c5-4d4b-4c5a-8b02-d30cc6057641', { blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26' });
    assert.equal(res.status, 200, JSON.stringify(res.body));
  });

  it('re-states the blueprint without moving the row, and is still judged', async () => {
    // Same blueprint_id as the stored row: not a move, but the body names it,
    // so the guard runs — and finds only the row's own claim, which carve-out 1
    // exempts.
    conn = makeConn({ stored: [SIZING] });
    const res = await send('PUT', '/edge/app/schema/decision_tables/99325195-6d2a-42af-8c5b-331b20b19eec', { blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26' });
    assert.equal(res.status, 200, JSON.stringify(res.body));
  });
});

describe('the guard degrades rather than failing', () => {
  it('passes a body that carries no doc — no claim changes', async () => {
    conn = makeConn({ stored: [SIZING] });
    const res = await send('PUT', '/edge/app/schema/decision_tables/99325195-6d2a-42af-8c5b-331b20b19eec', { name: 'Renamed' });
    assert.equal(res.status, 200, JSON.stringify(res.body));
    assert.equal(
      conn.queries.some((q) => /SELECT name, doc FROM/i.test(q.sql)),
      false,
      'a rename must not read the blueprint\'s other tables at all',
    );
  });

  it('passes on a DB whose operator account never got the table created', async () => {
    conn = makeConn({ stored: [SIZING], tableExists: false });
    const res = await send('POST', '/edge/app/schema/decision_tables', {
      blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', name: 'Second', doc: doc(['region'], ['cavity_count']),
    });
    assert.notEqual(res.status, 409);
  });
});

describe('the guard holds its read until the write commits', () => {
  it('reads the blueprint\'s other tables FOR UPDATE', async () => {
    // Without the lock two clients claiming the same output at the same time
    // both read "nobody owns it" and both write.
    conn = makeConn({ stored: [SIZING] });
    await send('POST', '/edge/app/schema/decision_tables', {
      blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', name: 'Second', doc: doc(['region'], ['lead_time']),
    });
    const read = conn.queries.find((q) => /SELECT name, doc FROM `fmb_decision_tables`/i.test(q.sql));
    assert.ok(read, 'the guard must read the blueprint\'s other tables');
    assert.match(read.sql, /FOR UPDATE/i);
  });
});

describe('ownership is settled before the guard reads anything', () => {
  const OTHER_OWNER = 'someone-else';
  const EDITOR = { id: '405279b5-48c7-4bd5-8427-69d6ff5556a7', role: 'editor' };
  // The row being edited: it hangs off the same blueprint, and carries no live
  // claim of its own so only ownership and the sibling read decide the outcome.
  const SUBJECT = { id: 'e737d265-a5c6-407f-866e-bbe109b5fa4e', blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', name: 'Other', doc: doc([], []) };

  it('refuses a non-owning editor\'s PUT before the sibling tables are read', async () => {
    // The pre-write guard reads (and FOR UPDATEs) every other decision table in
    // the blueprint, and its 409 names one of them. Ownership on this path used
    // to be enforced only by the EXISTS clause on the UPDATE that runs after —
    // so a caller who owns nothing in that blueprint reached the read, took the
    // locks, and could be told what is in there.
    currentUser = EDITOR;
    conn = makeConn({ stored: [SIZING, SUBJECT], blueprintOwnerId: OTHER_OWNER });
    const res = await send('PUT', '/edge/app/schema/decision_tables/e737d265-a5c6-407f-866e-bbe109b5fa4e', {
      doc: doc(['region'], ['cavity_count']),
    });
    assert.equal(res.status, 404);
    assert.equal(
      conn.queries.some((q) => /SELECT name, doc FROM `fmb_decision_tables`/i.test(q.sql)),
      false,
      'the duplicate-output read must not run for a caller who owns nothing here',
    );
    assert.equal(conn.rolledBack(), true);
  });

  it('lets the owning editor through to the same guard', async () => {
    currentUser = EDITOR;
    conn = makeConn({ stored: [SIZING, SUBJECT], blueprintOwnerId: EDITOR.id });
    const res = await send('PUT', '/edge/app/schema/decision_tables/e737d265-a5c6-407f-866e-bbe109b5fa4e', {
      doc: doc(['region'], ['cavity_count']),
    });
    assert.equal(res.status, 409);
    assert.equal(res.body.error.code, 'DUPLICATE_DECISION_OUTPUT');
  });

  it('lets an editor through on a SHARED blueprint (owner NULL)', async () => {
    currentUser = EDITOR;
    conn = makeConn({ stored: [SIZING, SUBJECT], blueprintOwnerId: null });
    const res = await send('PUT', '/edge/app/schema/decision_tables/e737d265-a5c6-407f-866e-bbe109b5fa4e', {
      doc: doc(['region'], ['lead_time']),
    });
    assert.equal(res.status, 200, JSON.stringify(res.body));
  });
});
