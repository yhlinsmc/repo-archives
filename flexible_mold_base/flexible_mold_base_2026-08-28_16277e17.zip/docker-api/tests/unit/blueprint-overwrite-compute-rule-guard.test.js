/**
 * blueprint-overwrite-compute-rule-guard.test.js
 *
 * overwriteBlueprint re-INSERTs every field from the payload with a column list
 * taken from the payload's own keys, so a compute rule travels into the column
 * verbatim. Overwrite is the most dangerous of the three import paths: it is a
 * destructive cascade, and an editor is allowed to run it against a blueprint
 * that is shared (owner_id NULL), so a bad rule lands in a blueprint other
 * tenants use.
 *
 * Two properties are pinned here: the payload is judged before the first DELETE
 * (a rejected import leaves the target untouched), and the judgement covers the
 * target's existing variants, whose compute overrides survive the overwrite.
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');

const lib = require('../../src/edge/lib/blueprint-serialization');

const FAKE_TABLES = {
  HIERARCHY_NODES: 'hierarchy_nodes',
  BLUEPRINT_FIELDS: 'blueprint_fields',
  FIELD_OPTIONS: 'field_options',
  BLUEPRINT_SECTIONS: 'blueprint_sections',
  BLUEPRINT_OUTPUT_ORDER: 'blueprint_output_order',
  BLUEPRINT_GROUPS: 'blueprint_groups',
  VARIANT_OVERRIDES: 'variant_overrides',
  FEATURE_AUDIT: 'feature_audit',
};
const fakeT = (name) => `fmb_${name}`;
let counter = 0;
const fakeUuid = () => `fake-uuid-${counter++}`;

const concat = (...keys) => ({
  op: 'concat',
  overridable: false,
  output_type: 'string',
  config: { parts: keys.map((key) => ({ type: 'field', key })) },
});

const fld = (id, key, extra = {}) => ({
  id, blueprint_id: 'bp-1', field_key: key, field_label: key, field_type: 'text',
  is_required: 0, default_value: '', placeholder: '', tooltip: '', section: 'general',
  order_index: 0, table_config: null, visibility_rule: null, ...extra,
});

function currentFixture() {
  return {
    import_version: 1,
    hierarchy_node: {
      id: 'bp-1', parent_id: 'release-1', name: 'BP', description: '',
      node_type: 'blueprint', sort_order: 0, is_active: 1,
      transformer_id: null, transformer_version: null, linked_blueprint_id: null,
    },
    blueprint_fields: [fld('old-a', 'a'), fld('old-b', 'b')],
    field_options: [],
    blueprint_sections: [],
    blueprint_groups: [],
    blueprint_output_order: [],
  };
}

function payloadWith(fields) {
  return {
    import_version: 1,
    hierarchy_node: { name: 'BP', description: '', is_active: 1, transformer_id: null, transformer_version: null },
    blueprint_fields: fields,
    field_options: [],
    blueprint_sections: [],
    blueprint_groups: [],
    blueprint_output_order: [],
  };
}

// variantComputeRows: rows of the variant-level compute-rule join.
// variantCellTargetsRows: rows of the variant-level cell_targets join — the
// column-narrowing counterpart, read by the round-3 column-cycle pass.
function makeFakeConn(current, { variantComputeRows = [], variantCellTargetsRows = [] } = {}) {
  const queries = [];
  return {
    queries,
    async query(sql, params) {
      queries.push({ sql, params });
      if (/information_schema\.TABLES/i.test(sql)) {
        return params && params[0] === 'fmb_variant_overrides' ? [{ n: 1 }] : [];
      }
      if (/SELECT DATABASE\(\) AS db/i.test(sql)) return [{ db: '' }];
      if (/information_schema\.COLUMNS/i.test(sql)) return [];
      if (/SELECT vo\.variant_id, bf\.field_key, vo\.compute_rule/i.test(sql)) return variantComputeRows;
      if (/SELECT vo\.variant_id, bf\.field_key, vo\.cell_targets/i.test(sql)) return variantCellTargetsRows;
      if (/^SELECT id, field_key FROM .*blueprint_fields/i.test(sql)) {
        return current.blueprint_fields.map((f) => ({ id: f.id, field_key: f.field_key }));
      }
      if (/^SELECT id, field_id FROM .*variant_overrides/i.test(sql)) return [];
      if (/^SELECT \* FROM .*hierarchy_nodes/i.test(sql)) return [current.hierarchy_node];
      if (/^SELECT \* FROM .*blueprint_fields/i.test(sql)) return current.blueprint_fields;
      if (/^SELECT \* FROM .*field_options/i.test(sql)) return current.field_options;
      if (/^SELECT \* FROM .*blueprint_sections/i.test(sql)) return current.blueprint_sections;
      if (/^SELECT \* FROM .*blueprint_output_order/i.test(sql)) return current.blueprint_output_order;
      if (/^SELECT id FROM .*hierarchy_nodes/i.test(sql)) return [{ id: current.hierarchy_node.id }];
      return [];
    },
  };
}

function overwrite(conn, current, payload) {
  return lib.overwriteBlueprint({
    conn, t: fakeT, TABLES: FAKE_TABLES, uuidv4: fakeUuid,
    existingId: 'bp-1', payload, userId: 'editor-1', userRole: 'editor',
    expectedRevision: lib.computeRevision(current),
  });
}

const wrote = (conn) => conn.queries.some((q) => /^(DELETE|UPDATE|INSERT)/i.test(q.sql.trim()));

describe('overwriteBlueprint validates the payload before it destroys anything', () => {
  it('rejects a rule whose source is not in the payload, leaving the target untouched', async () => {
    const current = currentFixture();
    const conn = makeFakeConn(current);
    await assert.rejects(
      overwrite(conn, current, payloadWith([fld('p-a', 'a', { compute_rule: concat('ghost') })])),
      (e) => e.code === 'INVALID_COMPUTE_RULE'
        && e.details.errors.some((m) => /missing_source/.test(m)),
    );
    assert.equal(wrote(conn), false, 'nothing may be written when the payload is rejected');
  });

  it('rejects a payload whose rules cycle', async () => {
    const current = currentFixture();
    const conn = makeFakeConn(current);
    await assert.rejects(
      overwrite(conn, current, payloadWith([
        fld('p-a', 'a', { compute_rule: concat('b') }),
        fld('p-b', 'b', { compute_rule: concat('a') }),
      ])),
      (e) => e.code === 'INVALID_COMPUTE_RULE',
    );
    assert.equal(wrote(conn), false);
  });

  it('rejects a rule that closes a cycle inside an existing variant', async () => {
    // The payload alone is acyclic (a ← b). Variant v-1 overrides b with a rule
    // that reads a, and that override survives the overwrite because field_key
    // 'b' still exists — so v-1 would evaluate a ← b ← a.
    const current = currentFixture();
    const conn = makeFakeConn(current, {
      variantComputeRows: [{ variant_id: 'v-1', field_key: 'b', compute_rule: JSON.stringify(concat('a')) }],
    });
    await assert.rejects(
      overwrite(conn, current, payloadWith([
        fld('p-a', 'a', { compute_rule: concat('b') }),
        fld('p-b', 'b'),
      ])),
      (e) => e.code === 'INVALID_COMPUTE_RULE',
    );
    assert.equal(wrote(conn), false);
  });

  it('accepts the same payload when the overriding variant loses that field', async () => {
    // 'b' is not in the payload, so the remap drops v-1's override with it —
    // there is no surviving edge to close the loop.
    const current = currentFixture();
    const conn = makeFakeConn(current, {
      variantComputeRows: [{ variant_id: 'v-1', field_key: 'b', compute_rule: JSON.stringify(concat('a')) }],
    });
    const result = await overwrite(conn, current, payloadWith([fld('p-a', 'a')]));
    assert.equal(result.ok, true);
  });

  it('writes a sound rule through', async () => {
    const current = currentFixture();
    const conn = makeFakeConn(current);
    const result = await overwrite(conn, current, payloadWith([
      // A rule travels with the mode it is the rule OF. An imported row is not
      // a partial PATCH — every column is stated — so a rule arriving without
      // its mode would land under the column default and be ignored by the
      // resolver: a rule that silently does nothing, through the one write path
      // that never came from the UI.
      fld('p-a', 'a', { value_source: 'calculated', compute_rule: concat('b') }),
      fld('p-b', 'b'),
    ]));
    assert.equal(result.ok, true);
    assert.ok(wrote(conn));
  });

  it('refuses a mode and a payload that disagree, before it destroys anything', async () => {
    // Same ordering guarantee this file exists for, reached by a new route: the
    // import boundary is where a row saying 'calculated' over no rule shows up,
    // because no other write path can produce one.
    const current = currentFixture();
    const conn = makeFakeConn(current);
    await assert.rejects(
      () => overwrite(conn, current, payloadWith([fld('p-a', 'a', { value_source: 'calculated' })])),
      (err) => err.code === 'INVALID_COMPUTE_RULE'
        && err.details.errors.some((e) => /requires a compute_rule/.test(e)),
    );
    assert.equal(wrote(conn), false, 'nothing may be written');
  });

  it('does not read variant rules at all when the payload carries none', async () => {
    const current = currentFixture();
    const conn = makeFakeConn(current);
    await overwrite(conn, current, payloadWith([fld('p-a', 'a'), fld('p-b', 'b')]));
    assert.equal(
      conn.queries.some((q) => /vo\.compute_rule/i.test(q.sql)), false,
      'an import with no rules must not pay for the cross-level scan',
    );
  });
});

// Round 3 (Codex r2 P1 #3): `importedRulesCycleInVariants` used to be
// field-level only — `extractComputeSources` ignores `same_table_column`
// terms entirely, so an imported blueprint formula on column A of a table
// field, plus a PRESERVED variant override formula on column B of the SAME
// field, formed an undetected A<->B cycle after the remap. Round 2's report
// called this shape "same_table_column never crosses tables" and out of
// scope — true for two DIFFERENT fields' tables, wrong for two column
// formulas on the SAME field (the blueprint's rule and the variant's
// override are two DIFFERENT column nodes on the one table).
describe('overwriteBlueprint — column-level cycle against an existing variant (round 3)', () => {
  const itemsTable = (extra = {}) => fld('p-items', 'items', {
    field_type: 'table',
    table_config: JSON.stringify({ columns: [{ key: 'a' }, { key: 'b' }] }),
    value_source: 'calculated',
    ...extra,
  });

  it('rejects an imported column-A formula that closes a loop with a preserved variant column-B override', async () => {
    const current = currentFixture();
    const conn = makeFakeConn(current, {
      // v-1's override on 'items', narrowed to column 'b', reads column 'a'.
      // field_key 'items' survives the overwrite (the payload still defines
      // it), so this override's edges carry into the post-import graph.
      variantComputeRows: [{
        variant_id: 'v-1',
        field_key: 'items',
        compute_rule: JSON.stringify({
          op: 'concat', overridable: true, output_type: 'string',
          config: { parts: [{ type: 'same_table_column', column_key: 'a' }] },
        }),
      }],
      variantCellTargetsRows: [{
        variant_id: 'v-1', field_key: 'items', cell_targets: JSON.stringify({ columns: ['b'] }),
      }],
    });
    // The payload's OWN rule for 'items' reads column 'b', narrowed to
    // column 'a' — the blueprint half of the A<->B loop.
    await assert.rejects(
      overwrite(conn, current, payloadWith([itemsTable({
        value_scope: { columns: ['a'] },
        compute_rule: {
          op: 'concat', overridable: true, output_type: 'string',
          config: { parts: [{ type: 'same_table_column', column_key: 'b' }] },
        },
      })])),
      (e) => e.code === 'INVALID_COMPUTE_RULE',
    );
    assert.equal(wrote(conn), false, 'nothing may be written when the payload is rejected');
  });

  it('accepts the SAME variant override when the payload imports no rule at all (control)', async () => {
    // Control: identical variant fixture (v-1's column-'b' override still
    // reads column 'a'), but the payload imports 'items' with NO compute_rule
    // — nothing on the blueprint side ever forms a column node on 'a', so
    // there is nothing for the variant's column-'b' node to close a loop
    // with (its own read of 'a' resolves to a missing edge, not a cycle).
    const current = currentFixture();
    const conn = makeFakeConn(current, {
      variantComputeRows: [{
        variant_id: 'v-1',
        field_key: 'items',
        compute_rule: JSON.stringify({
          op: 'concat', overridable: true, output_type: 'string',
          config: { parts: [{ type: 'same_table_column', column_key: 'a' }] },
        }),
      }],
      variantCellTargetsRows: [{
        variant_id: 'v-1', field_key: 'items', cell_targets: JSON.stringify({ columns: ['b'] }),
      }],
    });
    const result = await overwrite(conn, current, payloadWith([itemsTable({ value_source: 'entered' })]));
    assert.equal(result.ok, true);
  });
});
