/**
 * dto-mapper.test.js — v3.2.2 B2-2 — real test suite for the v3.2.0 PR-B2
 * DTO mapper. Transcribes the 19 inline smoke tests from commit 40da0a7
 * and adds a handful of regression cases for the security-review findings
 * that landed during the ship-gate review.
 *
 * Covers:
 *   - mapRowFromDb read path (boolean / timestamp / JSON)
 *   - mapRowToDb write path (inverse of the above)
 *   - normalizeTimestamp / denormalizeTimestamp pure helpers, including
 *     the +08:00 HIGH regression that was patched inline during PR-B2
 *   - describeRowMapping diagnostic output
 *   - isBooleanColumn / getRegistry surface
 *   - idempotency: read(read(x)) === read(x), write(write(x)) === write(x)
 *   - unknown-table / null / undefined passthrough
 *
 * Pure-function tests: no DB, no network, no env touching. Safe to run in
 * any environment, including CI without a database.
 */
const { test, describe } = require('node:test');
const assert = require('node:assert/strict');

const {
  mapRowFromDb,
  mapRowsFromDb,
  mapRowToDb,
  describeRowMapping,
  normalizeTimestamp,
  denormalizeTimestamp,
  isBooleanColumn,
  getRegistry,
} = require('../../src/edge/lib/dto-mapper');

// ── mapRowFromDb: read path ──────────────────────────────────────────────────

describe('mapRowFromDb — boolean columns', () => {
  test('users.banned: MariaDB 0 becomes JS false', () => {
    const row = { id: 'u1', email: 'a@b.c', banned: 0 };
    const out = mapRowFromDb('users', row);
    assert.equal(out.banned, false);
  });

  test('users.banned: MariaDB 1 becomes JS true', () => {
    const row = { id: 'u1', email: 'a@b.c', banned: 1 };
    const out = mapRowFromDb('users', row);
    assert.equal(out.banned, true);
  });

  test('users.banned: string "1" also becomes true (driver variance)', () => {
    const row = { banned: '1' };
    const out = mapRowFromDb('users', row);
    assert.equal(out.banned, true);
  });

  test('users.banned: already-true stays true (idempotent)', () => {
    const row = { banned: true };
    const out = mapRowFromDb('users', row);
    assert.equal(out.banned, true);
  });

  test('users.banned: null passes through unchanged', () => {
    const row = { banned: null };
    const out = mapRowFromDb('users', row);
    assert.equal(out.banned, null);
  });

  test('users.banned: missing key stays missing (no injection)', () => {
    const row = { id: 'u1' };
    const out = mapRowFromDb('users', row);
    assert.equal('banned' in out, false);
  });

  test('blueprint_fields.retain_when_hidden: MariaDB 0/1 round-trips to JS false/true', () => {
    assert.equal(mapRowFromDb('blueprint_fields', { retain_when_hidden: 0 }).retain_when_hidden, false);
    assert.equal(mapRowFromDb('blueprint_fields', { retain_when_hidden: 1 }).retain_when_hidden, true);
    // write path coerces JS boolean back to 1/0 for the DB
    assert.equal(mapRowToDb('blueprint_fields', { retain_when_hidden: true }).retain_when_hidden, 1);
    assert.equal(mapRowToDb('blueprint_fields', { retain_when_hidden: false }).retain_when_hidden, 0);
  });
});

describe('mapRowFromDb — timestamp columns', () => {
  test('users.created_at: MariaDB shape becomes ISO 8601 with Z', () => {
    const row = { created_at: '2026-04-10 00:23:45' };
    const out = mapRowFromDb('users', row);
    assert.equal(out.created_at, '2026-04-10T00:23:45Z');
  });

  test('users.created_at: fractional seconds preserved', () => {
    const row = { created_at: '2026-04-10 00:23:45.123' };
    const out = mapRowFromDb('users', row);
    assert.equal(out.created_at, '2026-04-10T00:23:45.123Z');
  });

  test('users.created_at: already-ISO passes through (idempotent)', () => {
    const row = { created_at: '2026-04-10T00:23:45Z' };
    const out = mapRowFromDb('users', row);
    assert.equal(out.created_at, '2026-04-10T00:23:45Z');
  });

  test('users.created_at: empty string passes through', () => {
    const row = { created_at: '' };
    const out = mapRowFromDb('users', row);
    assert.equal(out.created_at, '');
  });
});

describe('mapRowFromDb — JSON columns', () => {
  test('feature_audit.metadata: raw JSON string becomes parsed object', () => {
    const row = { metadata: '{"event":"login","user_id":"u1"}' };
    const out = mapRowFromDb('feature_audit', row);
    assert.deepEqual(out.metadata, { event: 'login', user_id: 'u1' });
  });

  test('feature_audit.metadata: invalid JSON keeps raw string (no throw)', () => {
    const row = { metadata: 'not json at all' };
    const out = mapRowFromDb('feature_audit', row);
    assert.equal(out.metadata, 'not json at all');
  });

  test('system_settings.value: parses JSON column', () => {
    const row = { key: 'theme', value: '{"dark":true}' };
    const out = mapRowFromDb('system_settings', row);
    assert.deepEqual(out.value, { dark: true });
  });

  test('cap_databases.dc_refs: raw JSON string becomes a parsed array (spec §6.1)', () => {
    const row = { dc_refs: '["s1","s2"]' };
    const out = mapRowFromDb('cap_databases', row);
    assert.deepEqual(out.dc_refs, ['s1', 's2']);
  });

  test('cap_databases.dc_refs: null stays null (inheritance-semantic "all DCs")', () => {
    const out = mapRowFromDb('cap_databases', { dc_refs: null });
    assert.equal(out.dc_refs, null);
  });
});

// ── cap_settings.name_patterns legacy hydration at the read choke
// point. This is the SINGLE place every cap_settings read passes through
// (mapRowFromDb / mapRowsFromDb), so a legacy 3-key stored override is
// hydrated to the 4-key split shape here rather than at each of the five
// route-level read surfaces individually.
describe('mapRowFromDb — cap_settings.name_patterns legacy hydration (jsonHydrate, fmb-1686)', () => {
  test('a raw JSON-string legacy 3-key value is parsed AND hydrated to 4-key', () => {
    const row = { name_patterns: '{"hypervisor":"hv-{dc}-{seq:2}","kvm_host":"kvm-{dc}-{seq:2}","ap_vm":"ap-{seq:2}"}' };
    const out = mapRowFromDb('cap_settings', row);
    assert.deepEqual(Object.keys(out.name_patterns).sort(), ['ap_vm', 'hypervisor', 'kvm_host_primary', 'kvm_host_standby']);
    assert.equal(out.name_patterns.kvm_host_primary, 'kvm-{dc}-{seq:2}');
    assert.equal(out.name_patterns.kvm_host_standby, 'kvm-{dc}-{seq:2}');
  });

  test('a pre-parsed object legacy 3-key value (driver autoJsonMap) is hydrated to 4-key', () => {
    const row = { name_patterns: { hypervisor: 'hv-{dc}-{seq:2}', kvm_host: 'kvm-{dc}-{seq:2}', ap_vm: 'ap-{seq:2}' } };
    const out = mapRowFromDb('cap_settings', row);
    assert.equal(out.name_patterns.kvm_host_primary, 'kvm-{dc}-{seq:2}');
    assert.equal(out.name_patterns.kvm_host_standby, 'kvm-{dc}-{seq:2}');
  });

  test('an already-4-key value passes through unchanged (idempotent)', () => {
    const patterns = {
      hypervisor: 'hv-{seq:2}', kvm_host_primary: 'kp-{seq:2}', kvm_host_standby: 'ks-{seq:2}', ap_vm: 'ap-{seq:2}',
    };
    const out = mapRowFromDb('cap_settings', { name_patterns: { ...patterns } });
    assert.deepEqual(out.name_patterns, patterns);
  });

  test('null stays null — hydration never manufactures a default set for an untouched row', () => {
    const out = mapRowFromDb('cap_settings', { name_patterns: null });
    assert.equal(out.name_patterns, null);
  });

  test('missing key stays missing (no injection)', () => {
    const out = mapRowFromDb('cap_settings', { id: 's1' });
    assert.equal('name_patterns' in out, false);
  });

  test('a value that failed JSON.parse (still a string) is left untouched, not hydrated', () => {
    const out = mapRowFromDb('cap_settings', { name_patterns: 'not json at all' });
    assert.equal(out.name_patterns, 'not json at all');
  });

  // (TS seat): the hydrate call is guarded like the def.json parse loop
  // — a hook that throws must leave the parsed value raw, never turn a successful
  // read into a 500.
  test('a hydrate hook that throws leaves the parsed value raw and does not propagate', () => {
    const raw = {};
    // resolveNamePatterns reads name_patterns.hypervisor while building its
    // result; a throwing getter forces the hydrate to throw on an otherwise
    // object-shaped value.
    Object.defineProperty(raw, 'hypervisor', {
      enumerable: true, get() { throw new Error('hydrate boom'); },
    });
    let out;
    assert.doesNotThrow(() => {
      out = mapRowFromDb('cap_settings', { id: 's1', scenario_id: 'scn-1', name_patterns: raw });
    });
    assert.equal(out.name_patterns, raw, 'the raw value is left untouched when the hydrate throws');
  });

  test('layer_defaults (the sibling JSON column) is unaffected by the name_patterns hydration', () => {
    const out = mapRowFromDb('cap_settings', {
      layer_defaults: '{"foo":"bar"}',
      name_patterns: null,
    });
    assert.deepEqual(out.layer_defaults, { foo: 'bar' });
    assert.equal(out.name_patterns, null);
  });

  test('double hydration is a no-op (mapRowFromDb(mapRowFromDb(x)) === mapRowFromDb(x))', () => {
    const row = { name_patterns: { hypervisor: 'hv-{seq:2}', kvm_host: 'kvm-{seq:2}', ap_vm: 'ap-{seq:2}' } };
    const once = mapRowFromDb('cap_settings', row);
    const twice = mapRowFromDb('cap_settings', once);
    assert.deepEqual(twice.name_patterns, once.name_patterns);
  });
});

describe('mapRowFromDb — table / row edge cases', () => {
  test('unknown table passes row through unchanged', () => {
    const row = { some: 'value', banned: 1 };
    const out = mapRowFromDb('no_such_table', row);
    // banned stays 1 because no registry entry applies
    assert.equal(out.banned, 1);
    assert.equal(out.some, 'value');
  });

  test('null row passes through', () => {
    assert.equal(mapRowFromDb('users', null), null);
  });

  test('undefined row passes through', () => {
    assert.equal(mapRowFromDb('users', undefined), undefined);
  });

  test('does not mutate the input row', () => {
    const row = { banned: 0, created_at: '2026-04-10 00:00:00' };
    const snapshot = { ...row };
    mapRowFromDb('users', row);
    assert.deepEqual(row, snapshot);
  });
});

describe('mapRowsFromDb — array wrapper', () => {
  test('maps every row in the array', () => {
    const rows = [
      { banned: 0 },
      { banned: 1 },
      { banned: null },
    ];
    const out = mapRowsFromDb('users', rows);
    assert.deepEqual(out.map((r) => r.banned), [false, true, null]);
  });

  test('non-array input passes through', () => {
    assert.equal(mapRowsFromDb('users', null), null);
    assert.equal(mapRowsFromDb('users', undefined), undefined);
    const obj = { banned: 1 };
    assert.equal(mapRowsFromDb('users', obj), obj);
  });
});

describe('mapRowFromDb — v3.2.78 nullable API normalization', () => {
  test('blueprint_fields nullable strings become empty strings', () => {
    const out = mapRowFromDb('blueprint_fields', {
      default_value: null,
      placeholder: null,
      tooltip: null,
      section: null,
    });
    assert.deepEqual(
      {
        default_value: out.default_value,
        placeholder: out.placeholder,
        tooltip: out.tooltip,
        section: out.section,
      },
      {
        default_value: '',
        placeholder: '',
        tooltip: '',
        section: '',
      },
    );
  });

  test('hierarchy_nodes.description becomes an empty string', () => {
    const out = mapRowFromDb('hierarchy_nodes', { description: null });
    assert.equal(out.description, '');
  });

  test('blueprint_sections.display_label becomes an empty string', () => {
    const out = mapRowFromDb('blueprint_sections', { display_label: null });
    assert.equal(out.display_label, '');
  });

  test('user_templates.name and schema_version become empty strings', () => {
    const out = mapRowFromDb('user_templates', { name: null, schema_version: null });
    assert.equal(out.name, '');
    assert.equal(out.schema_version, '');
  });

  test('blueprint_output_order.sort_order becomes 0', () => {
    const out = mapRowFromDb('blueprint_output_order', { sort_order: null });
    assert.equal(out.sort_order, 0);
  });

  // blueprint_groups.sort_order is DELIBERATELY the opposite of
  // blueprint_output_order's — the DDL column is INT NULL (Y-pattern
  // inheritance-semantic carve-out, same class as hierarchy_nodes.parent_id
  // / blueprint_fields.order_index), so a genuine null must survive the read
  // serializer verbatim. Coalescing it to 0 would make the FE echo 0 as
  // `expected` on the optimistic-lock replace (which strict-compares against
  // the raw stored value), false-409ing every save on a legacy
  // null-sort_order row forever.
  test('blueprint_groups.sort_order survives as null (not coalesced)', () => {
    const out = mapRowFromDb('blueprint_groups', { sort_order: null });
    assert.equal(out.sort_order, null);
  });

  test('blueprint_groups.sort_order passes a real number through unchanged', () => {
    const out = mapRowFromDb('blueprint_groups', { sort_order: 3 });
    assert.equal(out.sort_order, 3);
  });
});

// ── mapRowToDb: write path ───────────────────────────────────────────────────

describe('mapRowToDb — boolean columns', () => {
  test('users.banned: JS true becomes 1', () => {
    const out = mapRowToDb('users', { banned: true });
    assert.equal(out.banned, 1);
  });

  test('users.banned: JS false becomes 0', () => {
    const out = mapRowToDb('users', { banned: false });
    assert.equal(out.banned, 0);
  });

  test('users.banned: numeric 1 stays 1 (idempotent)', () => {
    const out = mapRowToDb('users', { banned: 1 });
    assert.equal(out.banned, 1);
  });

  test('users.banned: null passes through unchanged', () => {
    const out = mapRowToDb('users', { banned: null });
    assert.equal(out.banned, null);
  });
});

describe('mapRowToDb — timestamp columns', () => {
  test('users.created_at: ISO with Z becomes MariaDB shape', () => {
    const out = mapRowToDb('users', { created_at: '2026-04-10T00:23:45Z' });
    assert.equal(out.created_at, '2026-04-10 00:23:45');
  });

  test('users.created_at: already-MariaDB shape stays put', () => {
    const out = mapRowToDb('users', { created_at: '2026-04-10 00:23:45' });
    assert.equal(out.created_at, '2026-04-10 00:23:45');
  });
});

describe('mapRowToDb — JSON columns', () => {
  test('transformers.input_schema: object becomes JSON string', () => {
    const out = mapRowToDb('transformers', {
      input_schema: { fields: [{ key: 'name' }] },
    });
    assert.equal(typeof out.input_schema, 'string');
    assert.deepEqual(JSON.parse(out.input_schema), { fields: [{ key: 'name' }] });
  });

  test('transformers.input_schema: already-stringified passes through', () => {
    const out = mapRowToDb('transformers', { input_schema: '{"fields":[]}' });
    assert.equal(out.input_schema, '{"fields":[]}');
  });

  test('transformers.input_schema: null stays null', () => {
    const out = mapRowToDb('transformers', { input_schema: null });
    assert.equal(out.input_schema, null);
  });

  test('cap_databases.dc_refs: array becomes a JSON string (spec §6.1)', () => {
    const out = mapRowToDb('cap_databases', { dc_refs: ['s1', 's2'] });
    assert.equal(typeof out.dc_refs, 'string');
    assert.deepEqual(JSON.parse(out.dc_refs), ['s1', 's2']);
  });

  test('cap_databases.dc_refs: null stays null on write', () => {
    const out = mapRowToDb('cap_databases', { dc_refs: null });
    assert.equal(out.dc_refs, null);
  });
});

// ── normalizeTimestamp: MariaDB → ISO ────────────────────────────────────────

describe('normalizeTimestamp', () => {
  test('MariaDB "YYYY-MM-DD HH:mm:ss" becomes ISO with Z', () => {
    assert.equal(
      normalizeTimestamp('2026-04-10 00:23:45'),
      '2026-04-10T00:23:45Z',
    );
  });

  test('MariaDB with T separator also becomes ISO with Z', () => {
    // The regex accepts either space or T between date and time
    assert.equal(
      normalizeTimestamp('2026-04-10T00:23:45'),
      '2026-04-10T00:23:45Z',
    );
  });

  test('fractional seconds up to 6 digits preserved', () => {
    assert.equal(
      normalizeTimestamp('2026-04-10 00:23:45.123456'),
      '2026-04-10T00:23:45.123456Z',
    );
  });

  test('already ISO with Z passes through (idempotent)', () => {
    assert.equal(
      normalizeTimestamp('2026-04-10T00:23:45Z'),
      '2026-04-10T00:23:45Z',
    );
  });

  test('already ISO with +08:00 offset passes through (idempotent)', () => {
    assert.equal(
      normalizeTimestamp('2026-04-10T08:23:45+08:00'),
      '2026-04-10T08:23:45+08:00',
    );
  });

  test('date-only string passes through', () => {
    assert.equal(normalizeTimestamp('2026-04-10'), '2026-04-10');
  });

  test('empty string passes through', () => {
    assert.equal(normalizeTimestamp(''), '');
  });

  test('non-string passes through', () => {
    assert.equal(normalizeTimestamp(null), null);
    assert.equal(normalizeTimestamp(undefined), undefined);
    assert.equal(normalizeTimestamp(42), 42);
  });
});

// ── denormalizeTimestamp: ISO → MariaDB ──────────────────────────────────────

describe('denormalizeTimestamp', () => {
  test('ISO with Z becomes MariaDB shape', () => {
    assert.equal(
      denormalizeTimestamp('2026-04-10T00:23:45Z'),
      '2026-04-10 00:23:45',
    );
  });

  test('ISO with Z + fractional seconds preserved', () => {
    assert.equal(
      denormalizeTimestamp('2026-04-10T00:23:45.500Z'),
      '2026-04-10 00:23:45.500',
    );
  });

  test('already-MariaDB shape passes through (idempotent)', () => {
    assert.equal(
      denormalizeTimestamp('2026-04-10 00:23:45'),
      '2026-04-10 00:23:45',
    );
  });

  test('+08:00 offset converts to UTC (PR-B2 HIGH regression)', () => {
    // 08:23:45 Asia/Taipei = 00:23:45 UTC. Pre-fix code stripped the
    // offset without converting, which silently shifted events by 8h.
    // The .000 suffix comes from Date.toISOString() always emitting
    // milliseconds — harmless for MariaDB which accepts the fractional
    // part as a sub-second TIMESTAMP component. Assert on the full shape
    // rather than trimming, so a future refactor that preserves precision
    // doesn't silently break this test.
    assert.equal(
      denormalizeTimestamp('2026-04-10T08:23:45+08:00'),
      '2026-04-10 00:23:45.000',
    );
  });

  test('+08:00 offset with date rollover still converts correctly', () => {
    // 01:00 Asia/Taipei = 17:00 UTC of the previous day
    assert.equal(
      denormalizeTimestamp('2026-04-10T01:00:00+08:00'),
      '2026-04-09 17:00:00.000',
    );
  });

  test('-05:00 (EST) offset converts to UTC', () => {
    // 19:30 EST = 00:30 UTC of the next day
    assert.equal(
      denormalizeTimestamp('2026-04-09T19:30:00-05:00'),
      '2026-04-10 00:30:00.000',
    );
  });

  test('offset with no colon (+0800) also converts to UTC', () => {
    assert.equal(
      denormalizeTimestamp('2026-04-10T08:23:45+0800'),
      '2026-04-10 00:23:45.000',
    );
  });

  test('naive ISO (no tz) is treated as UTC and separator rewritten', () => {
    assert.equal(
      denormalizeTimestamp('2026-04-10T00:23:45'),
      '2026-04-10 00:23:45',
    );
  });

  test('non-string passes through', () => {
    assert.equal(denormalizeTimestamp(null), null);
    assert.equal(denormalizeTimestamp(undefined), undefined);
    assert.equal(denormalizeTimestamp(42), 42);
  });
});

// ── describeRowMapping: diagnostic output for DX3 endpoint ───────────────────

describe('describeRowMapping', () => {
  test('reports boolean transforms with before/after', () => {
    const report = describeRowMapping('users', { banned: 0 });
    const booleanRow = report.find((r) => r.column === 'banned');
    assert.ok(booleanRow, 'should report banned column');
    assert.equal(booleanRow.rule, 'boolean');
    assert.equal(booleanRow.before, 0);
    assert.equal(booleanRow.after, false);
  });

  test('reports timestamp transforms with before/after', () => {
    const report = describeRowMapping('users', {
      created_at: '2026-04-10 00:23:45',
    });
    const tsRow = report.find((r) => r.column === 'created_at');
    assert.ok(tsRow);
    assert.equal(tsRow.rule, 'timestamp');
    assert.equal(tsRow.before, '2026-04-10 00:23:45');
    assert.equal(tsRow.after, '2026-04-10T00:23:45Z');
  });

  test('reports JSON transforms with parsed after', () => {
    const report = describeRowMapping('feature_audit', {
      metadata: '{"k":"v"}',
    });
    const jsonRow = report.find((r) => r.column === 'metadata');
    assert.ok(jsonRow);
    assert.equal(jsonRow.rule, 'json');
    assert.deepEqual(jsonRow.after, { k: 'v' });
  });

  test('JSON parse error gets sentinel string, not a throw', () => {
    const report = describeRowMapping('feature_audit', {
      metadata: 'not json',
    });
    const jsonRow = report.find((r) => r.column === 'metadata');
    assert.ok(jsonRow);
    assert.equal(jsonRow.after, '<<parse error, kept as string>>');
  });

  test('unknown table returns empty report', () => {
    assert.deepEqual(describeRowMapping('no_such_table', { x: 1 }), []);
  });

  test('null row returns empty report', () => {
    assert.deepEqual(describeRowMapping('users', null), []);
  });

  test('columns not in registry are not reported', () => {
    const report = describeRowMapping('users', { email: 'a@b.c', id: 'u1' });
    // email and id are not boolean/timestamp/json in users, so nothing to report
    assert.equal(report.length, 0);
  });
});

// ── isBooleanColumn + getRegistry surface ────────────────────────────────────

describe('isBooleanColumn', () => {
  test('users.banned is a boolean column', () => {
    assert.equal(isBooleanColumn('users', 'banned'), true);
  });

  test('users.email is NOT a boolean column', () => {
    assert.equal(isBooleanColumn('users', 'email'), false);
  });

  test('unknown table → false', () => {
    assert.equal(isBooleanColumn('nope', 'anything'), false);
  });

  test('table with no booleans entry → false', () => {
    // field_options has timestamps but no booleans
    assert.equal(isBooleanColumn('field_options', 'sort_order'), false);
  });
});

describe('getRegistry', () => {
  test('returns an object keyed by table name', () => {
    const registry = getRegistry();
    assert.equal(typeof registry, 'object');
    assert.ok('users' in registry);
    assert.ok('feature_audit' in registry);
    assert.ok('user_templates' in registry);
  });

  test('registry is frozen (immutable)', () => {
    const registry = getRegistry();
    assert.equal(Object.isFrozen(registry), true);
  });

  test('users entry declares banned as a boolean column', () => {
    const registry = getRegistry();
    assert.deepEqual(registry.users.booleans, ['banned']);
  });

  test('feature_audit entry declares metadata as a JSON column', () => {
    const registry = getRegistry();
    assert.ok(registry.feature_audit.json.includes('metadata'));
  });
});

// ── Round-trip: write → read should return the original JS value ─────────────

describe('round-trip: JS value → db shape → JS value', () => {
  test('boolean round-trip: true → 1 → true', () => {
    const original = { banned: true };
    const toDb = mapRowToDb('users', original);
    const backToJs = mapRowFromDb('users', toDb);
    assert.equal(backToJs.banned, true);
  });

  test('boolean round-trip: false → 0 → false', () => {
    const original = { banned: false };
    const toDb = mapRowToDb('users', original);
    const backToJs = mapRowFromDb('users', toDb);
    assert.equal(backToJs.banned, false);
  });

  test('timestamp round-trip preserves the UTC instant', () => {
    const original = { created_at: '2026-04-10T00:23:45Z' };
    const toDb = mapRowToDb('users', original);
    const backToJs = mapRowFromDb('users', toDb);
    assert.equal(backToJs.created_at, '2026-04-10T00:23:45Z');
  });

  test('JSON round-trip: object → string → object', () => {
    const original = { input_schema: { fields: [{ key: 'name', type: 'text' }] } };
    const toDb = mapRowToDb('transformers', original);
    const backToJs = mapRowFromDb('transformers', toDb);
    assert.deepEqual(backToJs.input_schema, original.input_schema);
  });

  test('timestamp round-trip from +08:00 offset lands the correct UTC instant', () => {
    // 08:23:45 Asia/Taipei is the same instant as 00:23:45 UTC.
    // Write path converts to UTC-stripped shape with .000 ms (Date.toISOString
    // artifact), read path re-adds Z and preserves the fractional seconds.
    const toDb = mapRowToDb('users', { created_at: '2026-04-10T08:23:45+08:00' });
    const backToJs = mapRowFromDb('users', toDb);
    assert.equal(backToJs.created_at, '2026-04-10T00:23:45.000Z');
  });

  test('user_templates.computed_field_overrides: object round-trips through JSON string', () => {
    // Write path: JS object → JSON string stored in TEXT column
    const original = { computed_field_overrides: { part_no: true } };
    const toDb = mapRowToDb('user_templates', original);
    // After write path the value must be a JSON string (as stored in DB TEXT col)
    assert.equal(typeof toDb.computed_field_overrides, 'string', 'write path must stringify');
    // Read path: JSON string from DB → JS object
    const backToJs = mapRowFromDb('user_templates', toDb);
    assert.deepEqual(backToJs.computed_field_overrides, original.computed_field_overrides);
  });

  test('user_templates.computed_field_overrides: null persists as null (read path)', () => {
    // DB TEXT column is NULL → read path must leave it null
    const row = { computed_field_overrides: null };
    const backToJs = mapRowFromDb('user_templates', row);
    assert.equal(backToJs.computed_field_overrides, null);
  });
});

describe('mapRowFromDb — flow_recipes family', () => {
  test('flow_recipes: is_active 0/1 → false/true and JSON cols parse', () => {
    const out = mapRowFromDb('flow_recipes', {
      is_active: 1,
      consumed_output_keys: '["payload"]',
      link_extract: '{"path":"data.url"}',
    });
    assert.equal(out.is_active, true);
    assert.deepEqual(out.consumed_output_keys, ['payload']);
    assert.deepEqual(out.link_extract, { path: 'data.url' });
  });

  test('flow_recipe_steps: config JSON cols parse, no boolean coercion', () => {
    const out = mapRowFromDb('flow_recipe_steps', {
      auth_config: '{"token":"x"}',
      request_config: '{"headers":{}}',
      input_from_step: 'null',
    });
    assert.deepEqual(out.auth_config, { token: 'x' });
    assert.deepEqual(out.request_config, { headers: {} });
    assert.equal(out.input_from_step, null);
  });

  test('flow_recipe_runs: step_results JSON parses; created_at normalizes', () => {
    const out = mapRowFromDb('flow_recipe_runs', {
      step_results: '[{"ok":true}]',
      created_at: '2026-06-27 10:00:00',
    });
    assert.deepEqual(out.step_results, [{ ok: true }]);
    assert.equal(typeof out.created_at, 'string');
  });
});
