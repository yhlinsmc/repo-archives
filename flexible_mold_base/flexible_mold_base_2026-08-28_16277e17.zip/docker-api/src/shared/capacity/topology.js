/**
 * topology.js — the single BE source for the `cap_databases.topology` /
 * `cap_bundle_items.topology` value domain (spec §4 D11). Every
 * server list that used to hand-copy the member set (io.js SHEET_SPECS enum,
 * config-import.js CONFIG_SPECS enum, wizard.js/database-bulk-create.js
 * TOPOLOGIES, _shared.js BUNDLE_ITEM_TOPOLOGIES) now derives from
 * `TOPOLOGY_VALUES`/`BUNDLE_ITEM_TOPOLOGIES` here instead of carrying an
 * independent array literal — that drift (`BundleTopology` and `topologyLabel`
 * on the FE side both silently missing `rac_standby`) is the bug D11 exists to
 * close structurally, not just patch once more.
 *
 * CJS/TS cannot share a module (docker-api is plain JS, the FE topology
 * source — `src/fmb/capacity/lib/topology.ts` — is TypeScript); the two are
 * held together by `src/fmb/capacity/lib/__tests__/topology-mirror-parity.test.ts`,
 * the same cross-runtime mirror discipline `name-patterns.js` already uses
 * (see that file's own doc).
 *
 * D12d RENAME (contract): the stored values `rac` / `rac_standby` are
 * renamed to `rac_multinode` / `rac_multinode_standby` in this release —
 * `single` / `primary` / `primary_standby` are untouched. `LEGACY_TOPOLOGY_
 * ALIAS` is the PERMANENT (not a one-release shim) old→new map every import
 * parse boundary applies before validation, so a workbook exported by an
 * older release keeps importing (io.js `buildImportPlan`, config-import.js
 * `buildConfigImportPlan`) — new exports only ever write the new values.
 *
 * NOT THE SAME AXIS: the rule-scope vocabulary `apply_scope: 'rac_multi_node'`
 * (evaluator.ts:810, RuleEditor.tsx:401 — a keep-in-one-site DEFAULT SCOPE
 * selector, not a topology value) is a different, independently-spelled enum
 * that predates this module and is NOT renamed by it.
 *
 * NODE SEMANTICS (AR2-Q10, TOPO-R1): `TOPOLOGY_NODE_DEFS` + `resolveNodeCounts`
 * are the BE mirror of the FE's `TOPOLOGY_DEFS[value].nodes` / `resolveNodeCounts`
 * (topology.ts) — wizard.js's `expectedInstanceCounts` (the ONLY other caller,
 * database-bulk-create.js, imports it rather than carrying a 2nd copy) and
 * both files' `RAC_MIN_NODES`/`RAC_MAX_NODES` now derive from this table
 * instead of each hand-declaring `2`/`100`. `topology-mirror-parity.test.ts`
 * extends its coverage to these fields too.
 */

const TOPOLOGY = Object.freeze({
  SINGLE: 'single',
  PRIMARY: 'primary',
  PRIMARY_STANDBY: 'primary_standby',
  RAC_MULTINODE: 'rac_multinode',
  RAC_MULTINODE_STANDBY: 'rac_multinode_standby',
});

// Per-topology node/instance-count semantics (AR2-Q10, TOPO-R1) — the FE
// mirror is `TOPOLOGY_DEFS[value].nodes` in `src/fmb/capacity/lib/topology.ts`
// (same shape: `primary` fixed-or-range, `standby` absent/fixed/overridable-
// with-default); `topology-mirror-parity.test.ts` holds the two byte-identical.
// wizard.js's `expectedInstanceCounts` (+ database-bulk-create.js, the ONLY
// other caller) derive from `resolveNodeCounts` below instead of each
// carrying its own switch statement.
const TOPOLOGY_NODE_DEFS = Object.freeze({
  [TOPOLOGY.SINGLE]: Object.freeze({ primary: Object.freeze({ fixed: 1 }) }),
  [TOPOLOGY.PRIMARY]: Object.freeze({ primary: Object.freeze({ fixed: 2 }) }),
  [TOPOLOGY.PRIMARY_STANDBY]: Object.freeze({
    primary: Object.freeze({ fixed: 2 }), standby: Object.freeze({ fixed: 2 }),
  }),
  [TOPOLOGY.RAC_MULTINODE]: Object.freeze({ primary: Object.freeze({ min: 2, max: 100 }) }),
  [TOPOLOGY.RAC_MULTINODE_STANDBY]: Object.freeze({
    primary: Object.freeze({ min: 2, max: 100 }), standby: Object.freeze({ default: 'primary', floor: 1 }),
  }),
});

// The RAC primary-side bound (spec §10.1) — wizard.js/database-bulk-create.js
// read these instead of each hand-declaring `RAC_MIN_NODES = 2` / `= 100`.
// Fail-fast import-time shape guard (byte-parity with the FE mirror's own
// `if (!('min' in RAC_PRIMARY_SPEC)) throw` in topology.ts) — a future edit
// that turns `rac_multinode`'s primary spec into a `{fixed}` shape must crash
// loudly at require() time instead of silently landing `undefined` in
// RAC_MIN_NODES/RAC_MAX_NODES and disabling every wizard bound check.
const RAC_PRIMARY_SPEC = TOPOLOGY_NODE_DEFS[TOPOLOGY.RAC_MULTINODE].primary;
if (!('min' in RAC_PRIMARY_SPEC)) {
  throw new Error('topology.js: rac_multinode primary spec must be a min/max range');
}
const RAC_MIN_NODES = RAC_PRIMARY_SPEC.min;
const RAC_MAX_NODES = RAC_PRIMARY_SPEC.max;

/**
 * @typedef {{ fixed: number } | { min: number, max: number }} NodeSideSpec
 *   A topology's primary side: either a topology-fixed instance count, or an
 *   adjustable [min,max] range (RAC family) — byte-parity with the FE's
 *   `TopologyNodeSpec['primary']` (topology.ts).
 * @typedef {{ fixed: number } | { default: number | 'primary', floor: number }} StandbySideSpec
 *   A topology's standby side: topology-fixed, or independently overridable
 *   with a `default` (a literal, or `'primary'` meaning "equal to whatever
 *   the primary side resolves to") and a `floor` (the minimum legal count
 *   regardless of default) — byte-parity with the FE's
 *   `TopologyNodeSpec['standby']` (topology.ts).
 * @typedef {{ primary: NodeSideSpec, standby?: StandbySideSpec }} TopologyNodeSpec
 */

/** Resolved primary/standby instance counts for a topology (spec §10.1),
 *  derived purely from `TOPOLOGY_NODE_DEFS` — byte-parity with the FE's own
 *  `resolveNodeCounts` (topology.ts). Returns `null` for an unrecognized
 *  value (byte-parity with wizard.js's old `default: return null` case —
 *  every real caller already validates `TOPOLOGIES.has(topology)` first).
 * @param {string} value one of `TOPOLOGY_VALUES`
 * @param {number | null | undefined} [nodeCount] raw primary node-count input
 *   (ignored for a topology whose primary side is `fixed`)
 * @param {number | null | undefined} [standbyNodeCount] raw standby node-
 *   count input (ignored unless the topology's standby side is overridable)
 * @returns {{ primary: number, standby: number } | null}
 */
function resolveNodeCounts(value, nodeCount, standbyNodeCount) {
  const spec = TOPOLOGY_NODE_DEFS[value];
  if (!spec) return null;
  const primary = 'fixed' in spec.primary
    ? spec.primary.fixed
    : Math.max(spec.primary.min, Math.floor(nodeCount ?? spec.primary.min) || spec.primary.min);
  if (!spec.standby) return { primary, standby: 0 };
  if ('fixed' in spec.standby) return { primary, standby: spec.standby.fixed };
  const defaultValue = spec.standby.default === 'primary' ? primary : spec.standby.default;
  const sRaw = standbyNodeCount == null ? defaultValue : Math.floor(standbyNodeCount);
  return { primary, standby: Math.max(spec.standby.floor, sRaw || defaultValue) };
}

// Canonical order every derived list/UI enumeration follows.
const TOPOLOGY_VALUES = Object.freeze([
  TOPOLOGY.SINGLE,
  TOPOLOGY.PRIMARY,
  TOPOLOGY.PRIMARY_STANDBY,
  TOPOLOGY.RAC_MULTINODE,
  TOPOLOGY.RAC_MULTINODE_STANDBY,
]);

// Bundle items (prepared-item templates, spec §7 E1 scope) now template the
// FULL topology domain (AR2-Q8): `cap_bundle_items` gained the standby-node-
// count field a `rac_multinode_standby` row needs, so the prior 4-member
// narrowing is retired — this is the full canonical list, not a subset. Kept
// as a named alias so every derived consumer's import stays stable while the
// value can no longer drift from the single source.
const BUNDLE_ITEM_TOPOLOGIES = TOPOLOGY_VALUES;

// The permanent parse-boundary alias (D12d): applied to a raw imported cell
// BEFORE the enum-legality check, so an old-value workbook (`rac`/`rac_standby`)
// keeps importing and only ever lands the NEW value in the database — never
// re-exported as the old spelling.
const LEGACY_TOPOLOGY_ALIAS = Object.freeze({
  rac: TOPOLOGY.RAC_MULTINODE,
  rac_standby: TOPOLOGY.RAC_MULTINODE_STANDBY,
});

/** Old value → new value; a value with no legacy mapping passes through
 *  unchanged (already-current spellings, or a value that will fail the
 *  caller's own enum-legality check either way). */
function normalizeLegacyTopology(value) {
  return Object.prototype.hasOwnProperty.call(LEGACY_TOPOLOGY_ALIAS, value)
    ? LEGACY_TOPOLOGY_ALIAS[value] : value;
}

/** RAC multi-node detection (evaluator.js/evaluator.ts convention): either RAC
 *  member, primary-only or +standby. */
function isRacMultiNodeValue(value) {
  return value === TOPOLOGY.RAC_MULTINODE || value === TOPOLOGY.RAC_MULTINODE_STANDBY;
}

/** The +standby RAC member only (the one that carries an independent
 *  standby_node_count / standby db_instance role). */
function isRacMultiNodeStandbyValue(value) {
  return value === TOPOLOGY.RAC_MULTINODE_STANDBY;
}

module.exports = {
  TOPOLOGY,
  TOPOLOGY_VALUES,
  BUNDLE_ITEM_TOPOLOGIES,
  LEGACY_TOPOLOGY_ALIAS,
  normalizeLegacyTopology,
  isRacMultiNodeValue,
  isRacMultiNodeStandbyValue,
  TOPOLOGY_NODE_DEFS,
  RAC_MIN_NODES,
  RAC_MAX_NODES,
  resolveNodeCounts,
};
