/**
 * capacity/evaluator.js — the pure, typed Capacity Planner rule evaluator
 * (config-rewrite, spec §13 + §3.4 + §11–12).
 *
 * `evaluate(state)` turns a full scenario snapshot into a list of computed
 * violation markers plus per-object rollups. It is a PURE function: no I/O, no
 * DB, no `req`, no `Date`, no randomness — the same input always yields the same
 * output. This is the correctness core: the backend violations endpoint and the
 * client-side live re-evaluation (placement canvas) run this exact logic.
 *
 * THE SIX KEEPER RULE TYPES (five families, spec §13.1) — imported from
 * ./rule-types (the single authoritative registry; this module no longer keeps
 * its own type map):
 *   1. no-oversell          (hypervisor)  — used > usable per resource
 *   2. max-vms-per-host     (hypervisor)  — a host carries > params.max VMs
 *   3. max-instances-per-vm (vm)          — a db_host VM carries > params.max instances
 *   4. keep-apart           (db_instance) — ≥2 members of the target group share a host
 *   5. spread-across-sites  (db_instance) — the target group spans < params.min_sites sites
 *   6. keep-in-one-site     (db_instance) — the target group spans > 1 site (or off a pinned DC)
 * Plus a built-in SGA-cap capacity check (spec §3.4) that is NOT a rule type.
 * The retired 10-type library (max-children-count, capacity-no-oversell,
 * overcommit-factor, resource-ratio, field-min-max, cross-site-spread,
 * same-site-affinity, anti-colocation, co-location, sizing-table-conformance)
 * and the free-text cluster_key grouping are DELETED.
 *
 * STRUCTURAL GROUPING (spec §11–12): a relational rule's target is
 * level + structural group_by + built-in-attribute filters. Groups are derived
 * from the data — each database, its primary cluster, its standby cluster, all
 * of a type, or an explicit custom group — never from a grouping FIELD. Cluster
 * membership derives from an instance's (database_id, role) (spec §10.3);
 * cap_vms.database_id is a non-normative display hint and is NEVER read here.
 *
 * ISOMORPHIC OBLIGATION: the frontend needs the same evaluation live in the
 * browser, and the src/** Vite bundle may not import docker-api/**, so the
 * frontend MIRRORS this file at src/fmb/capacity/lib/evaluator.ts. The two
 * copies MUST stay behaviourally identical; this file is the reference and its
 * unit suite is the conformance spec. A lockstep guard
 * (src/fmb/capacity/lib/__tests__/evaluator.lockstep.test.ts) requires BOTH
 * copies from vitest and asserts the shared registry constants byte-parity plus
 * identical output on shared fixtures.
 *
 * NEVER-BLOCK INVARIANT (spec §3.1 / §13): this module only COMPUTES markers.
 * Nothing here can prevent an edit, reject a save, or fail an import. `severity`
 * decides marker weight (`hard` = red, `soft` = amber) and report grouping only;
 * a same-level rule clash is surfaced as an advisory flag, never a block.
 */
'use strict';

const {
  RULE_LEGAL_LEVELS,
  RULE_LEGAL_GROUP_BYS,
} = require('./rule-types');
// AR2-Q11 (spec §7 E1): the keep-in-one-site RAC default scope must match
// BOTH RAC variants (plain and +standby) — the FE mirror imports its own copy
// of the same helper (see ./topology for the shared spelling rule).
const { isRacMultiNodeValue } = require('./topology');
// A derived capacity result is always floored to a whole number ; the
// FE mirror carries its own copy of this helper.
const { floorGb } = require('./whole-numbers');
// A derived quantity reaching a person prints through ONE rule, shared with the
// FE mirror — a second local rounding here is a mirror break by construction.
const { formatQuantity } = require('./quantity');
// "Which data centre is this VM in" has ONE answer, and it is not this file's
// to have an opinion about; the FE mirror imports its own copy of the same
// module (see ./vm-site for the rule and the parity guard).
const { resolveVmSite, resolveHypervisorSiteId } = require('./vm-site');

// ── Value coercion helpers (isomorphic-safe: tolerate string inputs) ──────────

function num(v, dflt = 0) {
  if (v === null || v === undefined || v === '') return dflt;
  const n = typeof v === 'number' ? v : Number(v);
  return Number.isFinite(n) ? n : dflt;
}

// A rule row is enabled unless it is EXPLICITLY off. MariaDB BOOLEAN arrives as
// 0/1, the DTO mapper turns it into a real boolean, and a client may send
// either — so a missing/undefined flag defaults to ENABLED (a rule with no flag
// set is treated as active), and only a concrete falsy value disables it.
function isEnabled(v) {
  if (v === undefined || v === null) return true;
  return !(v === false || v === 0 || v === '0' || v === 'false');
}

// ── Operator normalisation + comparison (built-in-attribute filters, §13.4) ────

const OP_ALIASES = Object.freeze({
  '=': 'eq', '==': 'eq', 'eq': 'eq',
  '!=': 'ne', '≠': 'ne', '<>': 'ne', 'ne': 'ne',
  '<': 'lt', 'lt': 'lt',
  '<=': 'lte', '≤': 'lte', 'lte': 'lte',
  '>': 'gt', 'gt': 'gt',
  '>=': 'gte', '≥': 'gte', 'gte': 'gte',
  'in': 'in',
  'contains': 'contains',
});

function normalizeOp(op) {
  return OP_ALIASES[String(op == null ? '' : op).trim()] || 'eq';
}

// Compare `a OP b`. Numeric comparison when both operands read as finite
// numbers; otherwise string comparison. `in` accepts an array or a
// comma-delimited string on the right; `contains` does substring (string) or
// membership (array) on the left.
function compareValues(a, op, b) {
  const canon = normalizeOp(op);

  if (canon === 'in') {
    const set = Array.isArray(b)
      ? b.map((x) => String(x))
      : String(b == null ? '' : b).split(',').map((x) => x.trim());
    return set.includes(String(a));
  }
  if (canon === 'contains') {
    if (Array.isArray(a)) return a.map((x) => String(x)).includes(String(b));
    return String(a == null ? '' : a).includes(String(b == null ? '' : b));
  }

  const an = Number(a);
  const bn = Number(b);
  const numeric = a !== '' && b !== '' && a != null && b != null
    && Number.isFinite(an) && Number.isFinite(bn);

  if (numeric) {
    switch (canon) {
      case 'eq': return an === bn;
      case 'ne': return an !== bn;
      case 'lt': return an < bn;
      case 'lte': return an <= bn;
      case 'gt': return an > bn;
      case 'gte': return an >= bn;
      default: return false;
    }
  }

  const as = String(a == null ? '' : a);
  const bs = String(b == null ? '' : b);
  switch (canon) {
    case 'eq': return as === bs;
    case 'ne': return as !== bs;
    case 'lt': return as < bs;
    case 'lte': return as <= bs;
    case 'gt': return as > bs;
    case 'gte': return as >= bs;
    default: return false;
  }
}

// Read a field off an entity: a built-in column wins; otherwise fall to the
// entity's parsed `metadata` JSON (custom fields live there, spec §8). A
// metadata value that is still a JSON string (mapper disabled) is parsed once.
function getField(entity, field) {
  if (!entity || field == null) return undefined;
  if (Object.prototype.hasOwnProperty.call(entity, field) && field !== 'metadata') {
    return entity[field];
  }
  let meta = entity.metadata;
  if (typeof meta === 'string') {
    try { meta = JSON.parse(meta); } catch { meta = null; }
  }
  if (meta && typeof meta === 'object' && Object.prototype.hasOwnProperty.call(meta, field)) {
    return meta[field];
  }
  return undefined;
}

// AND-list of filter conditions (spec §13.4): every condition must hold. An
// empty/absent filter list matches everything (the rule targets its whole
// structural group with no attribute narrowing).
function matchConditions(entity, conditions) {
  if (!Array.isArray(conditions) || conditions.length === 0) return true;
  for (const cond of conditions) {
    if (!cond || cond.field == null) continue;
    const actual = getField(entity, cond.field);
    if (!compareValues(actual, cond.op, cond.value)) return false;
  }
  return true;
}

// A rule's built-in-attribute filters arrive as a bare array of
// { field, op, value } OR a { conditions: [...] } wrapper (the write validator
// tolerates both, _shared.js). Normalise to the bare array.
function normalizeFilters(filters) {
  if (Array.isArray(filters)) return filters;
  if (filters && typeof filters === 'object' && Array.isArray(filters.conditions)) {
    return filters.conditions;
  }
  return [];
}

// ── object_set_key — the stable Exception re-match key (spec §3.3) ────────────
//
// An Exception (renamed from waiver, §13.2) re-matches a violation iff their
// rule_id AND object_set_key agree. The key is the sorted subject-id set joined
// by '|'. Sorting makes it order-independent; '|' never appears in a CHAR(36)
// UUID so it cannot collide across different id sets. THIS SERIALIZATION IS
// BYTE-STABLE FOREVER — a stored Exception silently stops matching if it drifts.
// The frontend mirror and the Exception POST body both derive the key from here.
function objectSetKey(subjectIds) {
  return (subjectIds || []).map((x) => String(x)).sort().join('|');
}

// ── Level → snapshot collection resolution ────────────────────────────────────

const LEVEL_COLLECTION = Object.freeze({
  hypervisor: 'hypervisors',
  vm: 'vms',
  db_instance: 'db_instances',
});

// Coarse iteration budget (spec: DoS back-pressure). At the design scale ceiling
// (~250 objects, modest rule count) real work is tiny; this ceiling only trips
// on a pathological rule/filter set that slipped the write validator.
const DEFAULT_EVAL_BUDGET = 5_000_000;

function collectionForLevel(state, level) {
  const key = LEVEL_COLLECTION[level];
  return key && Array.isArray(state[key]) ? state[key] : [];
}

// ── Rollups: usable per spec, used per hypervisor, SGA per db_host VM ──────────

function usableForSpec(spec) {
  if (!spec) return { cpu: 0, mem: 0, disk: 0 };
  return {
    cpu: num(spec.cpu_total) - num(spec.cpu_reserved),
    // Usable memory is a DERIVED result, so it is floored. Down is the
    // intended direction: the solver may under-promise a host, never over-promise it.
    mem: floorGb(num(spec.mem_total_gb) * (1 - num(spec.mem_reserved_pct) / 100)),
    disk: num(spec.disk_total_gb) - num(spec.disk_reserved_gb),
  };
}

function computeRollups(state) {
  const specById = new Map((state.specs || []).map((s) => [s.id, s]));
  const hypervisors = state.hypervisors || [];
  const vms = state.vms || [];
  const dbInstances = state.db_instances || [];

  // Used per hypervisor = Σ of the VMs placed on it.
  const usedByHv = new Map();
  for (const vm of vms) {
    if (vm.hypervisor_id == null) continue;
    const acc = usedByHv.get(vm.hypervisor_id) || { cpu: 0, mem: 0, disk: 0, vmCount: 0 };
    acc.cpu += num(vm.cpu);
    acc.mem += num(vm.mem_gb);
    acc.disk += num(vm.disk_gb);
    acc.vmCount += 1;
    usedByHv.set(vm.hypervisor_id, acc);
  }

  const hypervisorRollups = {};
  for (const hv of hypervisors) {
    const usable = usableForSpec(specById.get(hv.spec_id));
    const used = usedByHv.get(hv.id) || { cpu: 0, mem: 0, disk: 0, vmCount: 0 };
    hypervisorRollups[hv.id] = {
      used: { cpu: used.cpu, mem: used.mem, disk: used.disk },
      usable,
      // The overcommit modifier retired with its rule type (spec §13.5 — now a
      // spec/settings property, not evaluated here). effectiveUsable is kept in
      // the rollup shape for the placement consumer and simply equals usable.
      effectiveUsable: { cpu: usable.cpu, mem: usable.mem, disk: usable.disk },
      utilization: {
        cpu: usable.cpu > 0 ? used.cpu / usable.cpu : 0,
        mem: usable.mem > 0 ? used.mem / usable.mem : 0,
        disk: usable.disk > 0 ? used.disk / usable.disk : 0,
      },
      vmCount: used.vmCount,
      site_id: hv.site_id,
    };
  }

  // Secondary rollup: a db_host VM's SGA budget consumed by its instances (spec
  // §3.4 — the sum compared against the VM profile's SGA cap).
  //
  // Each instance's stored SGA is floored as it is READ, per value and not on the
  // sum. `cap_db_instances.sga_gb` is one of the four columns the rule
  // names whole, and every writer now floors it — but no migration ran, and
  // `/versions/:id/restore` replays a frozen version's rows verbatim by design, so
  // a pre-rule 96.5 is still reachable and reaches this line. Flooring per value
  // reproduces exactly what the write path would store today; flooring the sum
  // would leave each instance fractional wherever it is shown on its own.
  //
  // NOT the same case as MEM used, which is deliberately left unfloored: that one
  // sums `cap_vms.mem_gb`, which the operator owns and may legitimately type as
  // 3.5. This column is derived by the app and has no such freedom.
  const usedSgaByVm = new Map();
  for (const inst of dbInstances) {
    if (inst.vm_id == null) continue;
    usedSgaByVm.set(inst.vm_id, (usedSgaByVm.get(inst.vm_id) || 0) + floorGb(num(inst.sga_gb)));
  }
  const vmRollups = {};
  for (const vm of vms) {
    if (vm.vm_type === 'db_host') vmRollups[vm.id] = { used_sga: usedSgaByVm.get(vm.id) || 0 };
  }

  // Site level = Σ of its hypervisors' used/usable, with derived utilization
  // (spec §8 site aggregate). Feeds the DC-group headers in the diagram.
  const siteRollups = {};
  for (const hv of hypervisors) {
    const sid = resolveHypervisorSiteId(hv);
    if (sid == null) continue;
    const roll = hypervisorRollups[hv.id];
    const acc = siteRollups[sid] || { used: { cpu: 0, mem: 0, disk: 0 }, usable: { cpu: 0, mem: 0, disk: 0 } };
    acc.used.cpu += roll.used.cpu; acc.used.mem += roll.used.mem; acc.used.disk += roll.used.disk;
    acc.usable.cpu += roll.usable.cpu; acc.usable.mem += roll.usable.mem; acc.usable.disk += roll.usable.disk;
    siteRollups[sid] = acc;
  }
  for (const sid of Object.keys(siteRollups)) {
    const a = siteRollups[sid];
    a.utilization = {
      cpu: a.usable.cpu > 0 ? a.used.cpu / a.usable.cpu : 0,
      mem: a.usable.mem > 0 ? a.used.mem / a.usable.mem : 0,
      disk: a.usable.disk > 0 ? a.used.disk / a.usable.disk : 0,
    };
  }

  // `overcommit` retired but kept as an always-empty map for shape parity with
  // the placement consumer's Rollups type.
  return { hypervisors: hypervisorRollups, vms: vmRollups, sites: siteRollups, overcommit: new Map() };
}

// ── Entity → placement resolution (for relational rules) ──────────────────────

function makeResolvers(state) {
  const vmById = new Map((state.vms || []).map((v) => [v.id, v]));
  const hvById = new Map((state.hypervisors || []).map((h) => [h.id, h]));

  // The hypervisor an entity is placed on (its container), or null when unplaced.
  // A db_instance is placed via the db_host VM it lives on (§10.3).
  function hypervisorIdOf(entity, level) {
    if (level === 'vm') return entity.hypervisor_id != null ? entity.hypervisor_id : null;
    if (level === 'db_instance') {
      const vm = vmById.get(entity.vm_id);
      return vm && vm.hypervisor_id != null ? vm.hypervisor_id : null;
    }
    if (level === 'hypervisor') return entity.id;
    return null;
  }

  const hypervisorSiteOf = (hvId) => resolveHypervisorSiteId(hvById.get(hvId));

  // WHICH SITE DOES THIS ENTITY OCCUPY. The shared derivation answers the wider
  // question — a VM's data centre, which for an UNPLACED VM is the intended
  // site its `site_id` names — and this resolver takes only the `host` branch of
  // it. An intended site is not an occupied one: `sitesOfMembers` counts the
  // sites a group physically spans, so an unplaced member must go on
  // contributing nothing to that count.
  function siteIdOf(entity, level) {
    if (level === 'hypervisor') return resolveHypervisorSiteId(hvById.get(entity.id));
    const vm = level === 'vm' ? entity
      : (level === 'db_instance' ? vmById.get(entity.vm_id) : null);
    const site = resolveVmSite(vm, hypervisorSiteOf);
    return site.source === 'host' ? site.siteId : null;
  }

  return { vmById, hvById, hypervisorIdOf, siteIdOf };
}

// ── Structural grouping (spec §11–12) ─────────────────────────────────────────
//
// A relational rule (keep-apart / spread-across-sites / keep-in-one-site) targets
// db_instances resolved into structural groups. Membership derives from an
// instance's (database_id, role); nothing reads a grouping field.

// A db_instance filter can reference a built-in attribute that lives on the
// PARENT database (function / profile / team) or on the instance's PLACEMENT
// (site). Augment the instance with those so getField/matchConditions resolve
// them uniformly (built-in own-props win over metadata, spec §8).
function augmentInstanceForFilter(inst, ctx) {
  const db = ctx.dbById.get(inst.database_id);
  return {
    ...inst,
    function: db ? db.function_name : inst.function,
    profile_id: db ? db.profile_id : inst.profile_id,
    team_id: db ? db.team_id : inst.team_id,
    site_id: ctx.resolvers.siteIdOf(inst, 'db_instance'),
  };
}

// The database's structural attributes for precedence matching (spec §13.3):
// exceptions are authored by function / profile / team.
function augmentDatabaseForFilter(db) {
  return { ...db, function: db.function_name };
}

// Distinct cluster roles a database actually has, from its FULL instance set
// (spec §10.3): { primary } for Single/Primary/RAC (one placement cluster),
// { primary, standby } for Primary+Standby (two placement clusters). Drives the
// spread arity-skip (§13.1a) so a single-cluster database is never flagged.
function databaseClusterRoles(state) {
  const roles = new Map(); // database_id -> Set(role)
  for (const inst of state.db_instances || []) {
    if (inst.database_id == null) continue;
    const role = inst.role === 'standby' ? 'standby' : 'primary';
    if (!roles.has(inst.database_id)) roles.set(inst.database_id, new Set());
    roles.get(inst.database_id).add(role);
  }
  return roles;
}

// Resolve a relational rule (db_instance level) into its target groups. Each
// group is { key, databaseId, members } where members are the db_instances the
// rule constrains. `filters` has already been applied to the population.
function resolveInstanceGroups(rule, population, ctx) {
  const groupBy = rule.group_by;

  if (groupBy === 'all_of_type') {
    // The whole class as one group (spec §11.2: target a type with no grouping).
    return population.length ? [{ key: 'all', databaseId: null, members: population }] : [];
  }

  if (groupBy === 'custom_group') {
    // Explicit member list (spec §11.3). A member is a PLACEABLE UNIT: a
    // db_instance (unit id = instance id; placed via its db_host VM) OR a VM
    // (unit id = vm id; placed on its own hypervisor). AP VMs — which carry no
    // db_instances — are reachable ONLY this way (spec §12). Each unit carries
    // its own __unitLevel so the shared resolvers read the right placement. The
    // rule's nominal level stays 'db_instance' (RULE_LEGAL_LEVELS unchanged) —
    // the unit model transcends it — and the db_instance `population`/filters arg
    // is intentionally NOT applied here (an explicit member list is the escape
    // hatch; membership is by the list, not by a field, spec §11.5).
    const groupId = rule.custom_group_id;
    if (groupId == null) return [];
    const members = [];
    const seen = new Set();
    for (const m of ctx.customGroupMembers) {
      if (String(m.group_id) !== String(groupId)) continue;
      if (m.member_instance_id != null) {
        const inst = ctx.instById.get(m.member_instance_id);
        const uk = `i:${String(m.member_instance_id)}`;
        if (inst && !seen.has(uk)) { seen.add(uk); members.push({ ...inst, __unitLevel: 'db_instance' }); }
      } else if (m.member_vm_id != null) {
        const vm = ctx.resolvers.vmById.get(m.member_vm_id);
        const uk = `v:${String(m.member_vm_id)}`;
        if (vm && !seen.has(uk)) { seen.add(uk); members.push({ ...vm, __unitLevel: 'vm' }); }
      }
    }
    return members.length
      ? [{ key: `custom:${groupId}`, databaseId: null, customGroupId: groupId, members }] : [];
  }

  // Database-derived groups: each_database / each_primary_cluster / each_standby_cluster.
  const byDb = new Map();
  for (const e of population) {
    if (e.database_id == null) continue; // an instance with no database is standalone
    if (!byDb.has(e.database_id)) byDb.set(e.database_id, []);
    byDb.get(e.database_id).push(e);
  }

  const groups = [];
  for (const [databaseId, instances] of byDb) {
    let members = instances;
    let key = `db:${databaseId}`;
    if (groupBy === 'each_primary_cluster') {
      members = instances.filter((e) => e.role !== 'standby');
      key = `primary:${databaseId}`;
    } else if (groupBy === 'each_standby_cluster') {
      members = instances.filter((e) => e.role === 'standby');
      key = `standby:${databaseId}`;
    }
    if (members.length) groups.push({ key, databaseId, members });
  }
  return groups;
}

// The placement level for a group member: a custom_group unit carries its own
// __unitLevel ('vm' | 'db_instance'); every structural group member is a
// db_instance (the default), so the resolvers read the right container/site.
function unitLevelOf(member) {
  return typeof member.__unitLevel === 'string' ? member.__unitLevel : 'db_instance';
}

// The distinct placed sites a group's members occupy.
function sitesOfMembers(members, ctx) {
  const sites = new Set();
  for (const m of members) {
    const s = ctx.resolvers.siteIdOf(m, unitLevelOf(m));
    if (s != null) sites.add(s);
  }
  return sites;
}

// RAC multi-node detection (capacity-config-model.ts convention): topology
// 'rac_multinode' OR 'rac_multinode_standby' with node_count >= 2. Drives the
// keep-in-one-site default scope (R1) — only a RAC cluster's nodes are
// force-kept in one site unless the rule widens to 'all'. A missing/low
// node_count reads as NOT multi-node, matching that convention. NOT the
// rule-scope vocabulary 'rac_multi_node' (apply_scope, below) — the two
// spellings name different axes and are not interchangeable.
//
// AR2-Q11 (spec §7 E1, supersedes the deliberate rac_multinode_standby
// exclusion pinned at D12d/AR1): the default keep-in-one-site row is
// each_primary_cluster (rule-types.js), so widening this predicate to the
// +standby variant only ever pulls that variant's PRIMARY cluster into the
// default scope — the standby cluster is a disjoint group_by
// (each_standby_cluster) this predicate never touches. Composed with the new
// each_standby_cluster keep-in-one-site default row and the pre-existing
// each_database spread, this delivers "primary set in one DC, standby set
// together in a different DC" without any new rule type (see rule-types.js
// DEFAULT_RULE_TEMPLATE's own comment).
function isRacMultiNodeDatabase(db) {
  return !!db && isRacMultiNodeValue(db.topology) && num(db.node_count) >= 2;
}

// ── Default + exception precedence (spec §13.3) ───────────────────────────────
//
// Spread-across-sites and keep-in-one-site directly contradict (≥N sites vs ≤1
// site). A MORE-SPECIFIC exception (a rule with strictly more filters, whose
// filter set is a superset) WINS over the broader default on the groups it
// matches; the default governs the rest. Two contradictory rules at the SAME
// specificity on the SAME structural target are a clash — flagged, not resolved.

const OPPOSITE_TYPE = Object.freeze({
  'spread-across-sites': 'keep-in-one-site',
  'keep-in-one-site': 'spread-across-sites',
});

function sameFilter(a, b) {
  return String(a.field) === String(b.field)
    && normalizeOp(a.op) === normalizeOp(b.op)
    && String(a.value) === String(b.value);
}
// Every filter in `sub` appears in `sup` (sub targets a superset population).
function filtersSubset(sub, sup) {
  return sub.every((f) => sup.some((g) => sameFilter(f, g)));
}
function filtersEqual(a, b) {
  return a.length === b.length && filtersSubset(a, b) && filtersSubset(b, a);
}

// Is `rule` suppressed on database `databaseId` by a strictly-more-specific
// opposing exception rule (spec §13.3 "specific overrides default")?
function isSuppressedOnDatabase(rule, databaseId, ctx) {
  const opp = OPPOSITE_TYPE[rule.type];
  if (!opp || databaseId == null) return false;
  const db = ctx.dbById.get(databaseId);
  if (!db) return false;
  const myFilters = ctx.filtersOf(rule);
  const augDb = augmentDatabaseForFilter(db);
  for (const other of ctx.enabledRules) {
    if (other === rule || other.type !== opp) continue;
    const otherFilters = ctx.filtersOf(other);
    if (otherFilters.length <= myFilters.length) continue; // must be strictly more specific
    if (!filtersSubset(myFilters, otherFilters)) continue; // and a proper narrowing of mine
    if (matchConditions(augDb, otherFilters)) return true; // and it covers this database
  }
  return false;
}

/**
 * Detect same-level, same-target rule clashes (spec §13.3 author-time flag):
 * two enabled rules of the contradictory pair (spread ↔ keep-in-one-site) with
 * the same level, the same structural group_by, and an identical filter set
 * cannot both hold — flag BOTH (no silent winner). A default/exception pair
 * (different filter specificity) is NOT a clash; precedence resolves it.
 * @param {Array} rules the effective (post-override) rule rows.
 * @returns {Array<{ rule_ids: string[], level: string, message: string }>}
 */
function detectRuleClashes(rules) {
  const enabled = (rules || []).filter((r) => r && isEnabled(r.enabled) && OPPOSITE_TYPE[r.type]);
  const clashes = [];
  for (let i = 0; i < enabled.length; i += 1) {
    for (let j = i + 1; j < enabled.length; j += 1) {
      const a = enabled[i];
      const b = enabled[j];
      if (OPPOSITE_TYPE[a.type] !== b.type) continue;
      if (String(a.level) !== String(b.level)) continue;
      if (String(a.group_by) !== String(b.group_by)) continue;
      if (!filtersEqual(normalizeFilters(safeJson(a.filters)), normalizeFilters(safeJson(b.filters)))) continue;
      clashes.push({
        rule_ids: [String(a.id), String(b.id)].sort(),
        level: a.level,
        message: `Rules "${a.name || a.id}" and "${b.name || b.id}" contradict on the same target and are both flagged.`,
      });
    }
  }
  return clashes;
}

// ── Per-type evaluators. Each pushes { level, subject_ids, message } markers ───
// via the shared `emit` closure that stamps rule identity + severity + Exception.

const TYPE_EVALUATORS = {
  // Built-in capacity: a hypervisor's used exceeds its usable on a resource.
  'no-oversell'(rule, state, ctx, emit) {
    const params = rule.params || {};
    const resources = Array.isArray(params.resources) && params.resources.length
      ? params.resources.filter((r) => r === 'cpu' || r === 'mem' || r === 'disk')
      : ['cpu', 'mem', 'disk'];
    const hypervisors = collectionForLevel(state, 'hypervisor')
      .filter((h) => matchConditions(h, ctx.filtersOf(rule)));
    for (const hv of hypervisors) {
      const roll = ctx.rollups.hypervisors[hv.id];
      if (!roll) continue;
      const offenders = [];
      for (const r of resources) {
        // DELIBERATE ASYMMETRY — DO NOT "FIX" THIS BY FLOORING `used`.
        // `usable` is floored (usableForSpec) and `used` is not, so a
        // message can read `MEM 218.5/218`. That is the conservative direction
        // the operator chose explicitly: flooring the used side would hide up to
        // a gigabyte of GENUINE oversell, while flooring only the usable side can
        // at worst surface a marker slightly early. `cap_vms.mem_gb` stays
        // free-form by the same ruling, so a fractional `used` is a real number
        // an operator typed, not residue.
        //
        // What IS shared is the FORMATTING: both operands print through the one
        // rule (quantity.js / its capacity-quantity.ts mirror), so the two
        // evaluator copies emit the same string. A second local rounding here is
        // what made them diverge — a 2-decimal round turned a typed 100.456789
        // into `100.46` on this side only.
        if (num(roll.used[r]) > num(roll.usable[r])) {
          offenders.push(`${r.toUpperCase()} ${formatQuantity(num(roll.used[r]))}/${formatQuantity(num(roll.usable[r]))}`);
        }
      }
      if (offenders.length) {
        emit('hypervisor', [hv.id], `Host ${hv.name || hv.id} is oversold: ${offenders.join(' · ')}.`);
      }
    }
  },

  // Density: a hypervisor carries more than params.max VMs.
  'max-vms-per-host'(rule, state, ctx, emit) {
    const max = num((rule.params || {}).max, Infinity);
    const hypervisors = collectionForLevel(state, 'hypervisor')
      .filter((h) => matchConditions(h, ctx.filtersOf(rule)));
    for (const hv of hypervisors) {
      const roll = ctx.rollups.hypervisors[hv.id];
      const count = roll ? roll.vmCount : 0;
      if (count > max) emit('hypervisor', [hv.id], `Host ${hv.name || hv.id} carries ${count} VMs — the limit is ${max}.`);
    }
  },

  // Density: a db_host VM carries more than params.max DB instances.
  'max-instances-per-vm'(rule, state, ctx, emit) {
    const max = num((rule.params || {}).max, Infinity);
    const countByVm = new Map();
    for (const inst of state.db_instances || []) {
      if (inst.vm_id == null) continue;
      countByVm.set(inst.vm_id, (countByVm.get(inst.vm_id) || 0) + 1);
    }
    const vms = collectionForLevel(state, 'vm')
      .filter((v) => matchConditions(v, ctx.filtersOf(rule)));
    for (const vm of vms) {
      const count = countByVm.get(vm.id) || 0;
      if (count > max) emit('vm', [vm.id], `VM ${vm.name || vm.id} carries ${count} database instances — the limit is ${max}.`);
    }
  },

  // Anti-affinity: ≥2 members of the target group share a host.
  'keep-apart'(rule, state, ctx, emit) {
    const population = collectionForLevel(state, 'db_instance')
      .map((e) => augmentInstanceForFilter(e, ctx))
      .filter((e) => matchConditions(e, ctx.filtersOf(rule)));
    for (const group of resolveInstanceGroups(rule, population, ctx)) {
      // Arity skip (§13.1a): a group with < 2 members cannot share a host.
      if (group.members.length < 2) continue;
      const byHost = new Map();
      for (const m of group.members) {
        const c = ctx.resolvers.hypervisorIdOf(m, unitLevelOf(m));
        if (c == null) continue;
        if (!byHost.has(c)) byHost.set(c, []);
        byHost.get(c).push(m);
      }
      for (const [hostId, sharers] of byHost) {
        if (sharers.length >= 2) {
          const hv = ctx.resolvers.hvById.get(hostId);
          emit('db_instance', sharers.map((m) => m.id),
            `${sharers.map((m) => m.name || m.id).join(' and ')} share host ${hv ? (hv.name || hv.id) : hostId}.`);
        }
      }
    }
  },

  // Spread: the target group must span at least params.min_sites sites.
  'spread-across-sites'(rule, state, ctx, emit) {
    const minSites = num((rule.params || {}).min_sites, 2);
    const population = collectionForLevel(state, 'db_instance')
      .map((e) => augmentInstanceForFilter(e, ctx))
      .filter((e) => matchConditions(e, ctx.filtersOf(rule)));
    for (const group of resolveInstanceGroups(rule, population, ctx)) {
      if (isSuppressedOnDatabase(rule, group.databaseId, ctx)) continue;
      // Arity skip (§13.1a): the group must be able to occupy min_sites distinct
      // sites. For each_database the placeable unit is the CLUSTER (a single-
      // cluster database is kept whole, so it can never span N sites); for every
      // other group_by the unit is the member. Too few units ⇒ skip, not flag.
      const units = rule.group_by === 'each_database'
        ? (ctx.clusterRoles.get(group.databaseId) || new Set()).size
        : group.members.length;
      if (units < minSites) continue;
      const sites = sitesOfMembers(group.members, ctx);
      if (sites.size < minSites) {
        emit('db_instance', group.members.map((m) => m.id),
          `${labelGroup(group, ctx)} occupies ${sites.size} site(s) — the rule requires at least ${minSites}.`);
      }
    }
  },

  // Keep-in-one-site: the target group must stay in one site (or on a pinned DC).
  'keep-in-one-site'(rule, state, ctx, emit) {
    const params = rule.params || {};
    // Scope (R1, engine-level): by default keep-in-one-site flags ONLY RAC
    // multi-node databases (a RAC cluster's nodes must co-locate); 'all' widens it
    // to every targeted database. An absent param reads as the RAC-multi-node
    // default, so rules stored before this param change behaviour by design.
    const applyScope = String(params.apply_scope) === 'all' ? 'all' : 'rac_multi_node';
    const pinned = params.site_id != null && params.site_id !== '' ? String(params.site_id) : null;
    const population = collectionForLevel(state, 'db_instance')
      .map((e) => augmentInstanceForFilter(e, ctx))
      .filter((e) => matchConditions(e, ctx.filtersOf(rule)));
    for (const group of resolveInstanceGroups(rule, population, ctx)) {
      if (isSuppressedOnDatabase(rule, group.databaseId, ctx)) continue;
      // Default scope skips any group that is not a RAC multi-node database. A
      // group with no single database (all_of_type / custom_group) is outside the
      // RAC default scope; widen to 'all' to flag it.
      if (applyScope !== 'all'
        && !isRacMultiNodeDatabase(group.databaseId != null ? ctx.dbById.get(group.databaseId) : null)) {
        continue;
      }
      const sites = sitesOfMembers(group.members, ctx);
      if (pinned) {
        // Off the pinned DC: any placed member not on the pin (or spanning it).
        const offPin = [...sites].some((s) => String(s) !== pinned);
        if (offPin) {
          emit('db_instance', group.members.map((m) => m.id),
            `${labelGroup(group, ctx)} must stay on the pinned site but occupies ${sites.size} site(s).`);
        }
      } else if (sites.size > 1) {
        emit('db_instance', group.members.map((m) => m.id),
          `${labelGroup(group, ctx)} spans ${sites.size} sites — the rule requires one.`);
      }
    }
  },
};

// Small formatting helpers kept pure + locale-free.
function round(n) {
  const v = num(n);
  return Math.round(v * 100) / 100;
}
// Human-readable group label for a violation message (spec §7 / E8: visible
// text never carries a raw database id). Resolves the group's underlying
// database (or custom group) NAME via ctx — never the id embedded in `key`.
function labelGroup(group, ctx) {
  if (group.customGroupId != null) {
    const cg = ctx.customGroupById.get(group.customGroupId);
    return cg ? String(cg.name || 'This group') : 'This group';
  }
  if (group.databaseId != null) {
    const db = ctx.dbById.get(group.databaseId);
    const dbName = db ? String(db.function_name || 'This group') : 'This group';
    if (group.key.startsWith('primary:')) return `${dbName} primary cluster`;
    if (group.key.startsWith('standby:')) return `${dbName} standby cluster`;
    return dbName;
  }
  return 'This group';
}

// Parse a JSON-ish value without throwing: an object/array/null passes through;
// a string is parsed (a failure returns null). Used for the precedence + clash
// lookups over OTHER rules, where a genuine parse error is surfaced separately
// when that rule is itself evaluated.
function safeJson(v) {
  if (v == null || typeof v !== 'string') return v;
  try { return JSON.parse(v); } catch { return null; }
}

// Normalize a JSON-ish rule field: an object (or null) passes through; a string
// is parsed; a parse failure returns { ok: false }. The DTO mapper normally
// parses filters/params, but a client-supplied or mapper-disabled string must
// not crash the engine — and a genuinely malformed blob is surfaced, not silenced.
//
// An EMPTY / whitespace-only string is "no config", NOT malformed JSON: NULL and
// '{}' both read as empty here, so '' must too, or a rule whose params/filters
// column holds '' would be the one representation that raises a false
// config-error and gets skipped. safeJson('') here and canonicalRuleParams('')
// (_shared.js) — the sibling coalescers reading the SAME columns — pick
// different empty-token values (null here, {} there); both are equivalent
// downstream under the `|| {}` guards their callers already apply, which is
// the branch none of them agreed on before this fix.
function parseMaybeJson(v) {
  if (v == null || typeof v !== 'string') return { ok: true, value: v };
  const s = v.trim();
  if (s === '') return { ok: true, value: null };
  try { return { ok: true, value: JSON.parse(s) }; } catch { return { ok: false, value: null }; }
}

// ── Override-row resolution (spec §13.4 / §17.1) ──────────────────────────────
//
// A scenario override row (scenario_id = X, overrides_rule_id = <global row id>)
// replaces its global template row's enabled/params/severity IN THAT SCENARIO,
// without mutating the global row. At most one override per (scenario, global
// rule). Resolve before evaluation: the override row itself is never evaluated
// standalone — it re-parameterises the global rule it points at.
function resolveEffectiveRules(rules) {
  const all = Array.isArray(rules) ? rules : [];
  const overrideByTarget = new Map(); // global rule id -> override row
  for (const r of all) {
    if (r && r.overrides_rule_id != null) overrideByTarget.set(String(r.overrides_rule_id), r);
  }
  const effective = [];
  for (const r of all) {
    if (!r || r.overrides_rule_id != null) continue; // override rows resolved into their target
    const ov = overrideByTarget.get(String(r.id));
    if (ov) {
      effective.push({
        ...r,
        enabled: ov.enabled,
        params: ov.params !== undefined && ov.params !== null ? ov.params : r.params,
        severity: ov.severity !== undefined && ov.severity !== null ? ov.severity : r.severity,
      });
    } else {
      effective.push(r);
    }
  }
  return effective;
}

// ── SGA-cap capacity check (spec §3.4) — a built-in, NOT a rule type ──────────
//
// SGA cap on a DB profile is the VM-level HARD CAP for the SUM of all DB
// instances' SGA hosted on that VM. Formula mode derives it from the profile's
// CPU: MEM = CPU × mem_cpu_ratio; SGA cap = floor(MEM × sga_factor / sga_divisor
// − sga_subtract). Custom mode uses the hand-set sga_cap_gb. The check emits on
// the sizing surface when Σ instance SGA exceeds the cap.
//
// INVARIANT: this is the SECOND producer of the same number. The sizing surface
// derives the cap through `resolveProfileSizing`
// (edge/routes/app/capacity/_shared.js) and its FE twin, and one screen shows
// both — the KVM SGA-ref column against this cap's violation marker. So the
// arithmetic here must match that one STEP FOR STEP, not merely round the same
// way: the memory is floored BEFORE the cap is derived from it (a fractional
// ratio otherwise carries 0.5 GB into the cap and yields 28 where the sizing
// surface shows 27), and a custom-mode row floors too (the column is a DOUBLE
// that was never migrated, so a row authored before that ruling can still hold
// 27.9 — which would otherwise reach an operator as "over its profile cap of
// 27.9 GB"). Pinned producer-against-producer by capacity-whole-numbers.test.js.
function computeSgaCap(profile, settings) {
  if (!profile || String(profile.class) !== 'DB') return null;
  if (String(profile.mode) === 'custom') {
    const raw = profile.sga_cap_gb;
    return raw == null || raw === '' ? null : floorGb(num(raw));
  }
  const ratio = num(settings.mem_cpu_ratio, 20);
  const factor = num(settings.sga_factor, 0.982);
  const divisor = num(settings.sga_divisor, 2);
  const subtract = num(settings.sga_subtract, 2);
  if (divisor === 0) return null;
  const mem = floorGb(num(profile.cpu) * ratio);
  return Math.floor((mem * factor) / divisor - subtract);
}

const SGA_CAP_RULE_ID = '__sga_cap__';

function evaluateSgaCap(state, ctx, emit) {
  const settings = state.settings && typeof state.settings === 'object' ? state.settings : {};
  const profileById = new Map((state.vm_profiles || []).map((p) => [p.id, p]));
  for (const vm of state.vms || []) {
    if (vm.vm_type !== 'db_host') continue;
    const roll = ctx.rollups.vms[vm.id];
    const usedSga = roll ? roll.used_sga : 0;
    if (usedSga <= 0) continue;
    const profile = profileById.get(vm.sizing_profile_id);
    const cap = computeSgaCap(profile, settings);
    if (cap == null) continue;
    if (usedSga > cap) {
      emit('vm', [vm.id],
        `VM ${vm.name || vm.id} hosts ${round(usedSga)} GB of SGA — over its profile cap of ${cap} GB.`,
        'hard');
    }
  }
}

// ── Public entry point ────────────────────────────────────────────────────────

/**
 * @param {object} state Full scenario snapshot: { scenarios, sites, specs,
 *   hypervisors, vms, db_instances, databases, custom_groups,
 *   custom_group_members, rules, waivers, settings, vm_profiles }. Every
 *   collection defaults to [] when absent. Numbers may arrive as strings; JSON
 *   columns (filters/params/metadata) may be objects or JSON strings.
 * @param {{ budget?: number }} [opts] Optional coarse iteration ceiling.
 * @returns {{ violations: Violation[], rollups: object, budget_exceeded: boolean,
 *   clashes: Array<{ rule_ids: string[], level: string, message: string }> }}
 */
function evaluate(state, opts) {
  const s = state || {};
  const budget = opts && typeof opts.budget === 'number' && opts.budget >= 0
    ? opts.budget : DEFAULT_EVAL_BUDGET;
  const rollups = computeRollups(s);
  const resolvers = makeResolvers(s);
  const waivers = Array.isArray(s.waivers) ? s.waivers : [];

  const effectiveRules = resolveEffectiveRules(s.rules);
  const enabledRules = effectiveRules.filter((r) => r && isEnabled(r.enabled));
  const clashes = detectRuleClashes(effectiveRules);

  // Pre-parse each enabled rule's filters once (for precedence lookups over OTHER
  // rules); a genuine parse error is surfaced when that rule is itself evaluated.
  const filtersCache = new Map();
  const filtersOf = (rule) => {
    if (!filtersCache.has(rule)) filtersCache.set(rule, normalizeFilters(safeJson(rule.filters)));
    return filtersCache.get(rule);
  };

  const ctx = {
    rollups,
    resolvers,
    dbById: new Map((s.databases || []).map((d) => [d.id, d])),
    instById: new Map((s.db_instances || []).map((i) => [i.id, i])),
    customGroupById: new Map((s.custom_groups || []).map((g) => [g.id, g])),
    customGroupMembers: Array.isArray(s.custom_group_members) ? s.custom_group_members : [],
    clusterRoles: databaseClusterRoles(s),
    enabledRules,
    filtersOf,
  };

  const violations = [];
  const makeEmit = (rule, severity) => (level, subjectIds, message, extra) => {
    const key = objectSetKey(subjectIds);
    const waived = waivers.some((w) => w && String(w.rule_id) === String(rule.id) && w.object_set_key === key);
    violations.push({
      rule_id: rule.id,
      rule_type: rule.type,
      severity,
      level,
      subject_ids: [...subjectIds],
      object_set_key: key,
      message,
      waived,
      ...(extra && typeof extra === 'object' ? extra : {}),
    });
  };

  // Built-in SGA-cap check (spec §3.4) — always runs (bounded by #vms), matches
  // an Exception by the synthetic SGA_CAP_RULE_ID + object_set_key.
  evaluateSgaCap(s, ctx, (level, subjectIds, message, severity) => {
    const key = objectSetKey(subjectIds);
    const waived = waivers.some((w) => w && String(w.rule_id) === SGA_CAP_RULE_ID && w.object_set_key === key);
    violations.push({
      rule_id: SGA_CAP_RULE_ID,
      rule_type: 'sga-cap',
      severity: severity === 'soft' ? 'soft' : 'hard',
      level,
      subject_ids: [...subjectIds],
      object_set_key: key,
      message,
      waived,
    });
  });

  const entityCount = (s.hypervisors ? s.hypervisors.length : 0)
    + (s.vms ? s.vms.length : 0) + (s.db_instances ? s.db_instances.length : 0);

  let spent = 0;
  let budgetExceeded = false;
  for (const rule of enabledRules) {
    const fn = TYPE_EVALUATORS[rule.type];
    if (!fn) continue; // unknown type ⇒ no marker (forward-compatible)
    const severity = rule.severity === 'hard' ? 'hard' : 'soft';
    // Tolerate a still-serialized filters/params (mapper disabled / client
    // string); a genuine parse failure becomes a VISIBLE config-error marker.
    const filtersParse = parseMaybeJson(rule.filters);
    const paramsParse = parseMaybeJson(rule.params);
    if (!filtersParse.ok || !paramsParse.ok) {
      makeEmit(rule, severity)('scenario', [rule.id],
        `Rule "${rule.name || rule.id}" has invalid ${!filtersParse.ok ? 'filters' : 'params'} JSON and was skipped.`,
        { config_error: true });
      continue;
    }
    const normRule = { ...rule, filters: filtersParse.value, params: paramsParse.value };
    filtersCache.set(normRule, normalizeFilters(filtersParse.value));
    // Coarse budget: each rule scans ~entityCount rows once per filter. Bail with
    // partial results + a flag rather than letting a pathological rule/filter set
    // burn unbounded CPU. Advisory back-pressure — never a correctness gate.
    const conds = filtersCache.get(normRule).length;
    spent += Math.max(1, entityCount) * (conds + 1);
    if (spent > budget) { budgetExceeded = true; break; }
    fn(normRule, s, ctx, makeEmit(normRule, severity));
  }

  return { violations, rollups, budget_exceeded: budgetExceeded, clashes };
}

/**
 * Roll a violation list up to the report counts (spec §3.1/§3.3): a waived
 * (Exception-matched) violation drops out of the active hard/soft tallies but is
 * counted as waived.
 */
function summarize(violations) {
  let hard = 0; let soft = 0; let waived = 0;
  for (const v of violations || []) {
    if (v.waived) { waived += 1; continue; }
    if (v.severity === 'hard') hard += 1;
    else soft += 1;
  }
  return { hard, soft, waived, total: (violations || []).length };
}

module.exports = {
  evaluate,
  summarize,
  objectSetKey,
  detectRuleClashes,
  computeSgaCap,
  RULE_LEGAL_LEVELS,
  RULE_LEGAL_GROUP_BYS,
  DEFAULT_EVAL_BUDGET,
  SGA_CAP_RULE_ID,
  // Exported for the unit suite + reuse (pure, side-effect-free):
  compareValues,
  normalizeOp,
  getField,
  matchConditions,
  normalizeFilters,
  usableForSpec,
  computeRollups,
};

/**
 * @typedef {object} Violation
 * @property {string} rule_id
 * @property {string} rule_type
 * @property {'hard'|'soft'} severity
 * @property {string} level
 * @property {string[]} subject_ids
 * @property {string} object_set_key
 * @property {string} message
 * @property {boolean} waived
 */
