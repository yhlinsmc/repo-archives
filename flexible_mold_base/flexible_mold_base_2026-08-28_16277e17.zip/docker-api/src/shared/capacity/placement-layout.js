/**
 * placement-layout.js — server-side mirror of the FE dense-placement layout
 * config contract (post-ar2-residuals P6). The FE
 * (src/fmb/capacity/components/placement/placement-dense-columns.ts) is the
 * single ENGINE that consumes the resolved config; this module carries only
 * what the server needs to validate a write — the bounds + built-in defaults
 * + the all-or-nothing-per-key validation — so a settings/site write can
 * reject a malformed value with a 400 (the input-boundary gate). CJS/TS
 * cannot share a module, so the bounds are duplicated here and held to the
 * FE copy by a parity test (the repo's standard cross-runtime mirror
 * discipline, same as name-patterns.js).
 */

/** Built-in defaults — MUST stay byte-identical to the FE DENSE_LAYOUT_DEFAULTS
 *  (placement-dense-columns.ts): 4 columns (hard cap) x 12 hosts/column
 *  (balancing target), dense mode triggers above 20 hosts. */
const DENSE_LAYOUT_DEFAULTS = Object.freeze({
  dense_threshold: 20,
  dense_columns: 4,
  dense_hosts_per_column: 12,
});

// INVARIANT: 9 is MID_HOST_MAX (8, placement-scale.ts) + 1. `computeTypeScale`
// only leaves the base type-scale band (k = TYPE_SCALE_BASE) at host counts
// ABOVE MID_HOST_MAX, and the DENSE_RESERVE_SCALE_HI/LO chord
// (placement-scale.ts DENSE_RESERVE_SCALE_HI doc) is only exact because a
// dense region's density k is ALWAYS TYPE_SCALE_BASE — which holds only
// because the dense threshold stays strictly above MID_HOST_MAX. A threshold
// at or below 8 would let a dense region's k rise above TYPE_SCALE_BASE,
// invalidating that chord's LOWER endpoint. Lowering this bound requires
// re-deriving DENSE_RESERVE_SCALE_HI/LO first.
const PLACEMENT_LAYOUT_BOUNDS = Object.freeze({
  dense_threshold: { min: 9, max: 999 },
  dense_columns: { min: 1, max: 4 },
  dense_hosts_per_column: { min: 1, max: 64 },
});

/** Keys writable at the global template / scenario override tier (cap_settings
 *  .placement_layout). */
const PLACEMENT_LAYOUT_KEYS_SETTINGS = Object.freeze([
  'dense_threshold', 'dense_columns', 'dense_hosts_per_column',
]);

/** Keys writable at the per-DC tier (cap_sites.metadata.placement_layout,
 *  Q16): threshold stays scenario-wide, never per-DC. */
const PLACEMENT_LAYOUT_KEYS_SITE = Object.freeze(['dense_columns', 'dense_hosts_per_column']);

/**
 * Validate ONE key's value against its bound. Returns an error message or
 * null.
 * @param {string} key
 * @param {unknown} value
 * @returns {string|null}
 */
function validatePlacementLayoutValue(key, value) {
  const bound = PLACEMENT_LAYOUT_BOUNDS[key];
  if (!bound) return `unknown placement_layout key "${key}"`;
  if (typeof value !== 'number' || !Number.isInteger(value)) return `placement_layout.${key} must be a whole number`;
  if (value < bound.min || value > bound.max) {
    return `placement_layout.${key} must be between ${bound.min} and ${bound.max}`;
  }
  return null;
}

/**
 * Validate a whole placement_layout write value (all-or-nothing, fail
 * closed): null/absent = inherit (valid). A non-null value MUST be a plain
 * object; every key present must be one of `allowedKeys`, an integer, and
 * within its bound — a single bad key rejects the WHOLE object (never
 * silently dropped or clamped). Unlike name_patterns' EXACT key-set
 * requirement, this is PARTIAL: a present subset of `allowedKeys` is legal
 * (the keys omitted inherit from the next tier up).
 * @param {unknown} value
 * @param {readonly string[]} allowedKeys
 * @returns {string|null}
 */
function validatePlacementLayoutWrite(value, allowedKeys = PLACEMENT_LAYOUT_KEYS_SETTINGS) {
  if (value === null || value === undefined) return null;
  // The settings/sites routes send a parsed object; an import path may send
  // the JSON column as a string. Accept both, same as validateNamePatternsWrite.
  let obj = value;
  if (typeof obj === 'string') {
    const trimmed = obj.trim();
    if (trimmed === '' || trimmed === 'null') return null;
    try { obj = JSON.parse(trimmed); } catch { return 'placement_layout must be a valid JSON object or null'; }
    if (obj === null) return null;
  }
  if (typeof obj !== 'object' || Array.isArray(obj)) {
    return 'placement_layout must be an object or null';
  }
  const allowed = new Set(allowedKeys);
  for (const key of Object.keys(obj)) {
    if (!allowed.has(key)) {
      return `placement_layout key "${key}" is not allowed here (allowed: ${allowedKeys.join(', ')})`;
    }
    const err = validatePlacementLayoutValue(key, obj[key]);
    if (err) return err;
  }
  return null;
}

module.exports = {
  DENSE_LAYOUT_DEFAULTS,
  PLACEMENT_LAYOUT_BOUNDS,
  PLACEMENT_LAYOUT_KEYS_SETTINGS,
  PLACEMENT_LAYOUT_KEYS_SITE,
  validatePlacementLayoutValue,
  validatePlacementLayoutWrite,
};
