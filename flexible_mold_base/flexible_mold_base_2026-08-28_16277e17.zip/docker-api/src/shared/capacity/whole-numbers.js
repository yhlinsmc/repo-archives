/**
 * whole-numbers.js — the one place capacity turns a derived quantity into the
 * whole number the operator's ruling requires ("a derived result is
 * always floored; SGA accepts integers only").
 *
 * Pure (no I/O) and dependency-free so both the edge routes and the shared
 * evaluator can use it. The frontend cannot import docker-api/**, so it mirrors
 * this function at `src/fmb/capacity/lib/capacity-config-model.ts` (`floorGb`)
 * and, for the evaluator mirror pair, inline in
 * `src/fmb/capacity/lib/evaluator.ts`. All copies must stay behaviourally
 * identical.
 */
'use strict';

/**
 * The snap window, in the unit being floored (GB / cores).
 *
 * SAFETY: the error this must absorb is relative to the OPERANDS, not to the
 * result. `mem_total_gb × (1 − pct/100)` cancels most of its magnitude away, so
 * a tolerance scaled to the RESULT is too small at a large reserve — measured,
 * `250 × (1 − 96.4/100)` lands on 8.99999999999998 and a result-relative
 * tolerance floored it to 8 rather than 9, losing a whole gigabyte. An ABSOLUTE
 * window in the floored unit does not have that failure mode.
 *
 * The value is bounded from BOTH sides, and neither bound is a matter of taste:
 *   - FLOOR: the largest below-integer residue measured by exhaustive search over
 *     the realistic domain (mem_total_gb 1–8192 × mem_reserved_pct at two
 *     decimals) is 9.1e-13, at 5625 × (1 − 25.12/100). A narrower window loses a
 *     gigabyte again.
 *   - CEILING: a value one part in 1e10 below a whole number must STAY below it —
 *     the helper floors, it never rounds up. A wider window turns 0.9999999999
 *     into 1.
 * 1e-11 sits an order of magnitude inside each bound. Both edges are pinned by
 * test, so widening this to chase some new residue fails the pin side rather
 * than silently changing what "floor" means.
 */
const SNAP_EPSILON = 1e-11;

/**
 * Floor a capacity quantity (GB, cores) to a whole number.
 *
 * A bare `Math.floor` over binary floating point silently loses a whole unit on
 * a value that is mathematically an integer — `Math.floor(90 * 0.7)` is 62
 * rather than 63 — taking away a gigabyte the host really has. A value within
 * `SNAP_EPSILON` below an integer IS that integer.
 *
 * A non-finite input passes through exactly as `Math.floor` would (NaN → NaN,
 * ±Infinity → ±Infinity): the caller's own coercion owns that case.
 *
 * @param {number} value
 * @returns {number}
 */
function floorGb(value) {
  return Math.floor(value + SNAP_EPSILON);
}

/**
 * The canonical input set for the THREE-COPY PARITY CHECK.
 *
 * INVARIANT: `floorGb` exists in three copies — here (the reference),
 * `src/fmb/capacity/lib/capacity-config-model.ts` and
 * `src/fmb/capacity/lib/evaluator.ts` — because the Vite bundle may not import
 * docker-api/**. Hand-matched expectations in three separate suites cannot hold
 * them together: each suite stays green while the copies drift apart. So the
 * input set lives HERE, beside the reference implementation, and the parity test
 * (vitest, the only runner that can load all three) drives every copy over this
 * exact array and asserts identical output — a machine comparison with no
 * hand-written number in it.
 *
 * Ordered: float-noise cases that must snap UP to the integer they stand for,
 * then real fractions that must floor DOWN, then the pass-through cases.
 */
const FLOOR_GB_PARITY_INPUTS = Object.freeze([
  // Mathematically-integer products that binary floating point puts just below.
  90 * 0.7,                    // 62.99999999999999 → 63
  10 * (1 - 80 / 100),         // 1.9999999999999996 → 2
  250 * (1 - 96.4 / 100),      // 8.99999999999998  → 9
  500 * (1 - 96.2 / 100),      // 18.99999999999996 → 19
  2000 * (1 - 93.65 / 100),    // 126.99999999999977 → 127
  5625 * (1 - 25.12 / 100),    // 4211.999999999999 → 4212 (the worst measured residue)
  // Real fractions: floored DOWN, never rounded up.
  66.7, 61.5, 27.9, 96.5, 48.9, 0.5, 0.99, 0.9999999999,
  // Whole values, and both edges of the window: 1e-12 below 1 is inside it and
  // reads as 1; 1e-10 and 1e-9 below 1 are outside it and stay 0.
  0, 1, 2, 63, 256, 1 - 1e-12, 1 - 1e-10, 1 - 1e-9, 1 + 1e-11,
  // Sign and pass-through cases (a caller's coercion owns non-finite input).
  -0.5, -1, -66.7, NaN, Infinity, -Infinity,
]);

module.exports = { floorGb, SNAP_EPSILON, FLOOR_GB_PARITY_INPUTS };
