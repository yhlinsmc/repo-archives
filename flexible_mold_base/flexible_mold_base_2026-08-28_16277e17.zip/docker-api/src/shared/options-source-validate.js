/**
 * options-source-validate — the structural floor for `blueprint_fields.options_source`
 * and its mutual-exclusion rule against `depends_on_field_key`.
 *
 * MULTIPLE WRITE PATHS NOW HOLD THIS COLUMN (field-level) AND ITS COLUMN-LEVEL
 * TWIN (`table_config.columns[i].options_source`, `invalidTableConfigColumn
 * OptionsSourceShape` below). The custom PUT / generic create in
 * `routes-blueprint-fields.js` judge a request body; the generic create's
 * `serializeWrite` shares the SAME `isPayloadInconsistent` function the
 * custom PUT calls, so one call site guards both; the JSON import guard
 * (`blueprint-field-import-guard.js`) judges an uploaded document that IS the
 * row being created, reused for both the JSON blueprint import and a YAML
 * mode=overwrite (`assertImportedBlueprintFields`); and the YAML parse path
 * (`blueprint-serialization.js` `parseYaml`) checks the column-level shape at
 * parse/preview time as well (fix-batch L2), ahead of ever reaching the
 * import guard. Every one of those is the same document under the same
 * rules, so all are checked by the same functions — hence this module living
 * in `shared/` rather than beside any one write path, mirroring
 * `cell-targets-validate.js`'s reason for being here.
 *
 * WHAT THIS DELIBERATELY DOES NOT JUDGE: whether the value POINTS at anything
 * real (does `source_field_key` name a live field? does `connector_id` name a
 * live connector?) — that needs blueprint context this shape-only floor does
 * not have, and stays with each write path's own semantic validation.
 */

// `options_source` shapes accepted by parseJsonColumn's already-parsed
// document — kept in step with parse-options-source.ts's FIELD_KEYS /
// CONNECTOR_KEYS (that module is the full parser; this Set pair is only
// the structural floor's copy of the same allow-list).
// `column`, when present, names the column key within the `source_field_key`
// table field's OWN `table_config.columns` — the explicit, unambiguous
// two-level shape (parse-options-source.ts's `types.ts` doc). Absent ⇒ the
// legacy shape, where `source_field_key` alone may be a bare column key
// resolved by walking every table field for one that declares it.
const OPTIONS_SOURCE_FIELD_KEYS = new Set(['type', 'source_field_key', 'column']);
const OPTIONS_SOURCE_CONNECTOR_KEYS = new Set(['type', 'connector_id', 'input_bindings']);

// Mirrors parse-options-source.ts `UNSAFE_BINDING_KEYS`: a binding name comes
// off a connector's stored definition, never typed by a caller at request
// time, so a name shaped like `__proto__`/`constructor` is a config error to
// refuse rather than a value to store. A plain object's bracket-assign to
// `__proto__` is a no-op reassignment of its prototype rather than an own
// property — `constructor` DOES create a shadowing own property — so both are
// refused by name before either could reach a consumer that assigns off them.
const UNSAFE_BINDING_KEYS = new Set(['__proto__', 'constructor']);

/**
 * Structural floor for `input_bindings`, the one key `options_source`'s
 * shape check below does not otherwise look inside. Required once
 * `type === 'connector'` — the frontend parser (`parseOptionsSource` /
 * `connector-invalid-input-bindings`) refuses an absent key at that layer,
 * so accepting it here would persist config the client can never resolve.
 * An empty object is legal on both sides. Once present it has to be an
 * object the connector runner can actually iterate — an array or a
 * non-string value passes the parent allow-list check (it's still "a key
 * named input_bindings") but is dead config the frontend parser already
 * refuses to resolve. A blank binding name or a blank bound value is the
 * same dead config by a different route — the parser refuses both, so this
 * floor rejects them too rather than persisting a binding that resolves to
 * nothing.
 * @param {unknown} value `parsed.input_bindings`, already object-or-primitive
 *   (the JSON.parse, if any, happened one level up in `parseJsonColumn`).
 */
function invalidInputBindingsShape(value) {
  if (value === undefined) return true;
  if (value === null || typeof value !== 'object' || Array.isArray(value)) return true;
  return Object.entries(value).some(
    ([key, v]) => UNSAFE_BINDING_KEYS.has(key) || key.length === 0 || typeof v !== 'string' || v === '',
  );
}

/**
 * Read a JSON column that may already have been stringified by mapRowToDb, or
 * arrive as a plain object from an uploaded import document.
 * Returns null for anything that is not an object — the shape floor below
 * reports those; this one only has to decide "is there a document here".
 */
function parseJsonColumn(value) {
  let parsed = value;
  if (typeof parsed === 'string') {
    try { parsed = JSON.parse(parsed); } catch { return null; }
  }
  return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : null;
}

/**
 * Structural floor for `options_source` — see the module doc for what this
 * deliberately does not judge.
 * @param {unknown} raw the request body's value verbatim, an imported
 *   document's field verbatim, or the same value after mapRowToDb has
 *   stringified it (custom PUT) — `parseJsonColumn` accepts any of these.
 */
function invalidOptionsSourceShape(raw) {
  if (raw == null) return false;
  const parsed = parseJsonColumn(raw);
  if (parsed === null) return true;
  const { type } = parsed;
  if (type !== 'field' && type !== 'connector') return true;
  const allowedKeys = type === 'field' ? OPTIONS_SOURCE_FIELD_KEYS : OPTIONS_SOURCE_CONNECTOR_KEYS;
  if (Object.keys(parsed).some((k) => !allowedKeys.has(k))) return true;
  const requiredKey = type === 'field' ? 'source_field_key' : 'connector_id';
  const requiredValue = parsed[requiredKey];
  if (typeof requiredValue !== 'string' || requiredValue === '') return true;
  if (type === 'field' && parsed.column !== undefined && (typeof parsed.column !== 'string' || parsed.column === '')) {
    return true;
  }
  return type === 'connector' && invalidInputBindingsShape(parsed.input_bindings);
}

/**
 * Q1 mutual exclusion (parse-options-source.ts `validateOptionsSourceAgainstField`):
 * a field cannot carry both a dynamic source and a static cascade parent.
 * @param {unknown} mergedOptionsSource the written `options_source` (merged
 *   with the stored row where the caller is judging a partial write)
 * @param {unknown} mergedDependsOnFieldKey the written `depends_on_field_key`,
 *   same merge convention
 * @returns {boolean}
 */
function optionsSourceDependsOnFieldKeyConflict(mergedOptionsSource, mergedDependsOnFieldKey) {
  return mergedOptionsSource != null
    && mergedDependsOnFieldKey != null && mergedDependsOnFieldKey !== '';
}

/**
 * Codex P2 (round 2, OPT-E3): the column-level twin of
 * `invalidOptionsSourceShape`, for `table_config.columns[i].options_source`
 * (the third render surface, spec §2: "selects embedded as table columns...
 * gain dynamic option sources"). Before this, the shared structural floor
 * guarded a field's own `options_source` on every server write path, but a
 * column's `options_source` nested inside `table_config` was only ever
 * checked on the YAML parse path (`blueprint-serialization.js` `parseYaml`,
 * fix-batch L2) — the JSON blueprint import and a direct table-field write
 * (custom PUT / generic create) persisted a malformed column source
 * unchecked, and the client parser (`table-column-options.ts`) silently
 * degrades an unparseable one to `undefined` (falls back to the column's
 * static `options`), so the misconfiguration was swallowed rather than
 * surfaced. Reuses `invalidOptionsSourceShape` per column rather than a
 * parallel copy of its rules, for the same one-function-many-callers reason
 * the module doc above gives for the field-level floor.
 * @param {unknown} rawTableConfig `payload.table_config` verbatim, an
 *   imported document's field verbatim, or the same value after
 *   `mapRowToDb` has stringified it — `parseJsonColumn` accepts any of
 *   these, mirroring `invalidOptionsSourceShape`'s own contract.
 * @returns {boolean} true when ANY column's `options_source` fails the
 *   shared shape floor. `table_config` being absent, not an object, or
 *   having no `columns` array is NOT this function's concern (a separate,
 *   pre-existing check owns "is this a well-formed table_config" — mirrors
 *   the YAML path's own `f.table_config && typeof === 'object' && Array
 *   .isArray(columns)` guard before it iterates).
 */
function invalidTableConfigColumnOptionsSourceShape(rawTableConfig) {
  if (rawTableConfig == null) return false;
  const parsed = parseJsonColumn(rawTableConfig);
  if (parsed === null || !Array.isArray(parsed.columns)) return false;
  return parsed.columns.some(
    (col) => col && typeof col === 'object' && !Array.isArray(col) && invalidOptionsSourceShape(col.options_source),
  );
}

module.exports = {
  OPTIONS_SOURCE_FIELD_KEYS,
  OPTIONS_SOURCE_CONNECTOR_KEYS,
  UNSAFE_BINDING_KEYS,
  invalidInputBindingsShape,
  invalidOptionsSourceShape,
  invalidTableConfigColumnOptionsSourceShape,
  optionsSourceDependsOnFieldKeyConflict,
};
