/**
 * openapi.js — OpenAPI 3.0 specification builder.
 *
 * Replaces swagger-jsdoc with a minimal comment-parser + yaml approach.
 * Scans JSDoc @openapi annotations in route files to build the spec.
 * Served by Scalar UI at /api/docs (infra) and /edge/docs (edge).
 *
 * Each route file's @openapi blocks are parsed independently with try-catch,
 * so a YAML indent error in one file doesn't crash the entire spec.
 */
const fs = require('fs');
const path = require('path');
const { parse: parseComments } = require('comment-parser');
const YAML = require('yaml');
const { logger: rootLogger } = require('./lib/logger');
const logger = rootLogger.child({ module: 'openapi' });

const platformTables = require('./platform-tables.json');

// ── Route file lists (explicit, no glob) ────────────────────────────────────

const EDGE_ROUTE_FILES = [
  // The generic schema CRUD @openapi block (/edge/app/schema/{table} +
  // /{table}/{id}) lives in schema/helpers.js after the schema.js -> schema/
  // folder split ; it was originally interleaved with the shared
  // chain-SQL helpers, so the partition kept it in helpers.js. A new @openapi
  // block added to any other schema/ file must be added here too (explicit
  // list, no glob) — the edge-openapi-spec-route regression test guards the
  // {table} paths against silent drop.
  'src/edge/routes/app/schema/helpers.js',
  'src/edge/routes/app/sync-schema.js',
  'src/edge/routes/app/transformers/index.js',
  'src/edge/routes/platform/access-rules.js',
  'src/edge/routes/platform/audit.js',
  'src/edge/routes/platform/auth-password.js',
  'src/edge/routes/platform/auth-sessions.js',
  'src/edge/routes/platform/connections.js',
  'src/edge/routes/platform/export.js',
  'src/edge/routes/platform/query.js',
  'src/edge/routes/platform/settings.js',
  'src/edge/routes/platform/users.js',
  'src/edge/routes/platform/setup/index.js',
];

const INFRA_ROUTE_FILES = [
  'src/index-infra.js',
  'src/infra/forwarding.js',
];

// PUBLIC_ROUTE_FILES is intentionally its OWN list — never a superset/subset
// derived from EDGE_ROUTE_FILES/INFRA_ROUTE_FILES. Mixing lists would risk an
// internal path leaking into the customer-facing public spec (P4 doc portal,
// spec §7). Keep this list to exactly the two public-tier route files.
const PUBLIC_ROUTE_FILES = [
  'src/infra/routes/public-read.js',
  'src/infra/routes/public-write.js',
];

/**
 * Extract @openapi blocks from a JS file's JSDoc comments.
 * Returns an array of parsed YAML objects (OpenAPI path definitions).
 */
function extractOpenApiBlocks(filePath) {
  const content = fs.readFileSync(filePath, 'utf-8');
  const comments = parseComments(content, { spacing: 'preserve' });
  const blocks = [];

  for (const comment of comments) {
    const hasOpenApi = comment.tags.some(t => t.tag === 'openapi');
    if (!hasOpenApi) continue;

    // The @openapi content is everything after the @openapi tag line
    // in the JSDoc block. comment-parser gives us the description which
    // contains the YAML content before the @openapi tag, and the tag's
    // description contains the content after it.
    //
    // For swagger-jsdoc compatible format, the YAML is in the comment
    // description (lines before @openapi are empty, lines after are YAML).
    // We need to extract the raw YAML from the source.

    // Find the @openapi tag and get all subsequent lines as YAML
    const lines = content.split('\n');
    const startLine = comment.source[0].number;
    const endLine = comment.source[comment.source.length - 1].number;

    let yamlLines = [];
    let foundOpenApi = false;

    for (let i = startLine; i <= endLine; i++) {
      const line = lines[i];
      if (!line) continue;

      // Strip comment markers: leading * or /** or */
      let stripped = line.replace(/^\s*\/?\*+\/?/, '').replace(/\*\/\s*$/, '');

      if (!foundOpenApi) {
        if (stripped.trim() === '@openapi') {
          foundOpenApi = true;
          continue;
        }
      } else {
        // Remove leading single space that JSDoc adds after *
        if (stripped.startsWith(' ')) stripped = stripped.substring(1);
        yamlLines.push(stripped);
      }
    }

    if (yamlLines.length === 0) continue;

    const yamlText = yamlLines.join('\n');
    try {
      const parsed = YAML.parse(yamlText);
      if (parsed && typeof parsed === 'object') {
        blocks.push(parsed);
      }
    } catch (err) {
      logger.warn({ file: filePath, err: err.message }, 'failed to parse @openapi YAML block — skipping');
    }
  }

  return blocks;
}

/**
 * Build paths object from route files.
 */
function buildPaths(routeFiles, baseDir) {
  const paths = {};
  let fileCount = 0;

  for (const relPath of routeFiles) {
    const fullPath = path.join(baseDir, relPath);
    if (!fs.existsSync(fullPath)) {
      logger.warn({ file: relPath }, 'route file not found — skipping');
      continue;
    }

    try {
      const blocks = extractOpenApiBlocks(fullPath);
      for (const block of blocks) {
        // Each block is { "/path": { get: {...}, post: {...} } }
        for (const [pathKey, methods] of Object.entries(block)) {
          if (!paths[pathKey]) paths[pathKey] = {};
          Object.assign(paths[pathKey], methods);
        }
      }
      fileCount++;
    } catch (err) {
      logger.warn({ file: relPath, err: err.message }, 'failed to extract @openapi blocks — skipping file');
    }
  }

  logger.info({ fileCount, pathCount: Object.keys(paths).length }, 'OpenAPI paths built');
  return paths;
}

/**
 * Build OpenAPI spec for API-edge routes.
 */
function buildEdgeSpec() {
  const baseDir = path.resolve(__dirname, '../..');
  const paths = buildPaths(EDGE_ROUTE_FILES, baseDir);

  const pathCount = Object.keys(paths).length;
  if (pathCount < 40) {
    logger.warn({ pathCount, expected: '>=40' }, 'edge spec has fewer paths than expected — some route files may have parse errors');
  }

  return {
    openapi: '3.0.0',
    info: {
      title: 'API-edge (DB-facing)',
      version: '3.0.0',
      description: [
        'Direct database access service. Accepts only S2S-authenticated requests from API-infra.',
        '',
        `**Infrastructure tables** (${platformTables.infra.length}): ${platformTables.infra.join(', ')}`,
        `**Engine tables** (${platformTables.engine.length}): ${platformTables.engine.join(', ')}`,
      ].join('\n'),
    },
    servers: [
      { url: 'http://localhost:3201', description: 'Local development (edge)' },
    ],
    components: {
      securitySchemes: {
        s2s: {
          type: 'apiKey',
          in: 'header',
          name: 'X-S2S-Key',
          description: 'Service-to-service shared secret',
        },
      },
      schemas: {
        ApiResponse: {
          type: 'object',
          properties: {
            data: { nullable: true },
            error: {
              nullable: true,
              type: 'object',
              properties: {
                message: { type: 'string' },
                code: { type: 'string' },
                hint: { type: 'string' },
              },
            },
            meta: {
              type: 'object',
              properties: {
                timestamp: { type: 'string', format: 'date-time' },
                db_type: { type: 'string' },
                provider: { type: 'string' },
              },
            },
          },
        },
      },
    },
    security: [{ s2s: [] }],
    paths,
  };
}

/**
 * Build OpenAPI spec for API-infra routes.
 */
function buildInfraSpec() {
  const baseDir = path.resolve(__dirname, '../..');
  const paths = buildPaths(INFRA_ROUTE_FILES, baseDir);

  const pathCount = Object.keys(paths).length;
  if (pathCount < 5) {
    logger.warn({ pathCount, expected: '>=5' }, 'infra spec has fewer paths than expected');
  }

  return {
    openapi: '3.0.0',
    info: {
      title: 'API-infra (Frontend-facing)',
      version: '3.0.0',
      description: [
        'Frontend-facing service. Handles authentication (OIDC, JWT, access-check) and forwards DB requests to API-edge.',
        '',
        'All `/api/*` endpoints are forwarding proxies to API-edge.',
        'Auth endpoints (`/api/auth/*`) are handled directly by API-infra.',
      ].join('\n'),
    },
    servers: [
      { url: 'https://localhost:3200', description: 'Local development (infra)' },
    ],
    components: {
      securitySchemes: {
        bearer: {
          type: 'http',
          scheme: 'bearer',
          bearerFormat: 'JWT',
        },
        oidc: {
          type: 'openIdConnect',
          openIdConnectUrl: 'http://localhost:8180/realms/dev-realm/.well-known/openid-configuration',
        },
      },
      schemas: {
        ApiResponse: {
          type: 'object',
          properties: {
            data: { nullable: true },
            error: { nullable: true, type: 'object', properties: { message: { type: 'string' }, code: { type: 'string' } } },
            meta: { type: 'object', properties: { timestamp: { type: 'string', format: 'date-time' } } },
          },
        },
      },
    },
    paths,
  };
}

// Reuse the single source of truth for the namespace boundary (also backs the
// pool-readiness/RBAC gate-skip in index-infra.js) rather than redeclaring the
// literal here — a future API version bump edited in only one place would
// otherwise silently desync this guard from the actual security boundary it's
// meant to protect.
const { PUBLIC_API_PREFIX } = require('./lib/public-api-path');

/**
 * Defense-in-depth invariant: every key in `paths` must start with
 * PUBLIC_API_PREFIX. Throws at build time so a leak is caught before the spec
 * is served — NOTE: this "fail loudly" guarantee is only guaranteed-loud in
 * the unit test path (which calls buildPublicSpec()/this guard directly).
 * At runtime, getPublicSpec() catches this throw and substitutes an empty-
 * paths stub (mirrors the pre-existing getEdgeSpec/getInfraSpec fallback
 * pattern) — a misconfigured PUBLIC_ROUTE_FILES in production degrades
 * silently to a "paths: {}" portal, visible only via logger.error(), not a
 * boot crash or alert.
 * @param {Record<string, unknown>} paths
 */
function assertOnlyPublicPaths(paths) {
  const leaked = Object.keys(paths).filter((p) => !p.startsWith(PUBLIC_API_PREFIX));
  if (leaked.length > 0) {
    throw new Error(`Internal route leak into public OpenAPI spec: ${leaked.join(', ')}`);
  }
}

// ── Inline-script safety of the assembled spec ──────────────────────────────
//
// Scalar's client-side renderer serialises the whole configuration with
// JSON.stringify and interpolates the result RAW into an inline
// <script type="text/javascript">. Its HTML escaper covers only the page title,
// never the configuration, and there is no size limit or truncation.
//
// WHICH DOCUMENTS THIS STILL DECIDES ANYTHING FOR: the dev pages /api/docs and
// /edge/docs, which put their spec in that configuration. The public portal
// fetches its document instead (public-docs.js), so a breaker in a public
// annotation reaches the browser as JSON and cannot terminate anything — the
// public document stays covered below because "the portal embeds it" is a
// property that a later edit could restore without noticing this note.
//
// JSON escaping does not neutralise HTML. A `</script` anywhere in a string
// closes that tag early: the rest of the configuration lands in the document as
// markup instead of data. That is a broken page, and on this route — whose CSP
// is deliberately relaxed to 'unsafe-inline' so Scalar can bootstrap at all —
// it is also a script-injection sink. `<!--` starts an HTML comment inside the
// script element and swallows the code after it; U+2028/U+2029 are line
// terminators that JSON.stringify emits raw.
//
// The offending interpolation lives in a third-party file, which we do not
// patch. What we control is what we hand it, so the assembled document is
// escaped on its way there, and the same list is asserted against in the tests.
const INLINE_SCRIPT_BREAKERS = [
  // Case-insensitive: the HTML parser ends a script element on `</SCRIPT` too.
  { label: '</script', matches: (s) => /<\/script/i.test(s) },
  { label: '<!--', matches: (s) => s.includes('<!--') },
  { label: 'U+2028 (line separator)', matches: (s) => s.includes('\u2028') },
  { label: 'U+2029 (paragraph separator)', matches: (s) => s.includes('\u2029') },
];

/**
 * Walk an assembled spec and collect every string — property name or value —
 * that would terminate or corrupt the inline <script> it gets rendered into.
 * Reports the property path so the author of the text is the one who fixes it.
 * @param {unknown} node
 * @param {string[]} [path]
 * @param {Array<{ path: string, token: string, sample: string }>} [found]
 * @returns {Array<{ path: string, token: string, sample: string }>}
 */
function findInlineScriptBreakers(node, path = [], found = []) {
  const label = path.length ? path.join('.') : '<root>';
  if (typeof node === 'string') {
    for (const breaker of INLINE_SCRIPT_BREAKERS) {
      if (breaker.matches(node)) {
        found.push({ path: label, token: breaker.label, sample: node.slice(0, 80) });
      }
    }
    return found;
  }
  if (!node || typeof node !== 'object') return found;
  if (Array.isArray(node)) {
    node.forEach((item, i) => findInlineScriptBreakers(item, [...path, String(i)], found));
    return found;
  }
  for (const [key, value] of Object.entries(node)) {
    // A property NAME is serialised into the same script text as its value.
    for (const breaker of INLINE_SCRIPT_BREAKERS) {
      if (breaker.matches(key)) {
        found.push({ path: [...path, '<key>'].join('.') || '<key>', token: breaker.label, sample: key.slice(0, 80) });
      }
    }
    findInlineScriptBreakers(value, [...path, key], found);
  }
  return found;
}

/**
 * Throw when the assembled document carries text that would break out of the
 * inline script tag. Names the property and the source files whose @openapi
 * blocks the text can only have come from.
 * @param {unknown} spec
 * @param {string[]} [sourceFiles]
 */
function assertNoInlineScriptBreakers(spec, sourceFiles = PUBLIC_ROUTE_FILES) {
  const found = findInlineScriptBreakers(spec);
  if (found.length === 0) return;
  const detail = found
    .map((f) => `  ${f.path} contains ${f.token} — text begins: ${JSON.stringify(f.sample)}`)
    .join('\n');
  throw new Error(
    'OpenAPI spec carries text that would terminate an inline <script> the document is rendered into. '
    + 'Which tier that is live for depends on the document: /api/docs and /edge/docs still embed theirs '
    + 'in the bootstrap configuration, so there it is a broken page and an injection sink under those '
    + 'routes\' unsafe-inline CSP. The public portal FETCHES its document (public-docs.js), so the text '
    + 'travels as JSON and terminates nothing today — the refusal is kept for it as a tripwire, because '
    + '"the portal does not embed it" is a property a later edit can undo without touching this file:\n'
    + `${detail}\n`
    + `Fix the @openapi description/summary that defines it — assembled from: ${sourceFiles.join(', ')}`,
  );
}

/**
 * Neutralise every breaker in one string.
 *
 * `</script` and `<!--` get a backslash inserted: JSON.stringify then emits
 * `<\\/script` / `<\\!--`, neither of which the HTML parser reads as an end tag
 * or a comment opener, and the reader sees one stray backslash instead of a
 * truncated page. U+2028/U+2029 take a different treatment because a backslash
 * would not help — JSON.stringify emits them raw whatever precedes them — and
 * they ARE line breaks, so an ASCII newline carries the same meaning and
 * serialises as `\n`.
 *
 * Idempotent: the output contains none of the sequences this rewrites.
 * @param {string} text
 * @returns {string}
 */
function escapeInlineScriptString(text) {
  return text
    .replace(/<\/(?=script)/gi, '<\\/')
    .replace(/<!--/g, '<\\!--')
    .replace(/\u2028/g, '\n')
    .replace(/\u2029/g, '\n\n');
}

/**
 * Deep copy of `node` with every string — property NAMES included — rewritten
 * so it cannot terminate or corrupt the inline <script> the docs portal renders
 * it into.
 *
 * WHY a rewrite and not a throw: throwing from the builder turned a
 * documentation typo into an empty PUBLISHED contract — getPublicSpec() caches
 * an empty-paths stub, so the portal rendered "no document" and
 * /api/public-docs/openapi.json answered 200 with zero paths, which is the same
 * blank page this work exists to remove. Rewriting the handful of characters
 * that matter keeps every path and every description on the page. Only the copy
 * handed to the inline renderer is escaped; the raw JSON endpoint keeps serving
 * the unmodified contract. The hard failure still exists, in
 * validatePublicSpec() / validateServedSpecs(), where it is a red test at build
 * time rather than an emptied API at read time.
 * @template T
 * @param {T} node
 * @returns {T}
 */
function escapeForInlineScript(node) {
  if (typeof node === 'string') return /** @type {any} */ (escapeInlineScriptString(node));
  if (!node || typeof node !== 'object') return node;
  if (Array.isArray(node)) return /** @type {any} */ (node.map((item) => escapeForInlineScript(item)));
  /** @type {Record<string, unknown>} */
  const out = {};
  for (const [key, value] of Object.entries(node)) {
    out[escapeInlineScriptString(key)] = escapeForInlineScript(value);
  }
  return /** @type {any} */ (out);
}

// The preamble answers three questions and stops: where the key comes from, how
// to send it, and what a first request looks like. Everything a reader used to
// scroll past here now sits on the thing it describes — paging on the `cursor`
// parameter, retry rules on the `Idempotency-Key` parameter, the error table on
// the PublicError schema, budgets on each 429 response — so a reader who jumps
// straight to an operation is not missing half the contract.
const GETTING_STARTED_DESCRIPTION = [
  '# Public Integration API',
  '',
  'A machine-to-machine API for the blueprints, templates, and flow runs your',
  'integration has been granted. Every endpoint lives under `/api/public/v1`,',
  'separate from the internal browser API.',
  '',
  '## 1. Where the key comes from',
  '',
  'An administrator creates a service account for the integration in the admin UI.',
  'The key is displayed **exactly once, at creation** — capture it then, because it',
  'cannot be retrieved again (a lost key is replaced, not recovered). There is **no',
  'exchange or login step** and nothing to refresh: the same key goes on every call',
  'until an administrator deactivates it.',
  '',
  '## 2. How to send it',
  '',
  'Two carriers, one key, verified the same way:',
  '',
  '- **Direct** — `Authorization: Bearer <key>`',
  '- **Gateway** — `api_key: <key>`, the header an API gateway injects onto the',
  '  request it forwards. Authenticate to the gateway with the gateway credentials;',
  '  it never needs the key in `Authorization` form.',
  '',
  'When both headers are present, `api_key` wins. A missing, unknown, or',
  'deactivated key returns `401 invalid_token`, which never reveals whether a key',
  'exists. Deactivation takes effect on the next request, on either carrier.',
  '',
  '## 3. A first request',
  '',
  'Set the two variables and run it unchanged:',
  '',
  '```bash',
  'API_BASE="https://your-app-host"        # the host serving this portal',
  'API_KEY="paste-the-key-shown-once-at-creation"',
  '',
  'curl -sS "$API_BASE/api/public/v1/blueprints?limit=5" \\',
  '  -H "Authorization: Bearer $API_KEY"',
  '```',
  '',
  'A `200` returns `{ "data": [ … ], "meta": { … } }`; a `401` means',
  'the key was not accepted. Every operation below carries the same request ready',
  'to copy, for both carriers. Field meanings, paging, retry rules, budgets, and',
  'the error codes are documented on the operations themselves.',
].join('\n');

// The full error contract lives on the schema every error response references,
// so it is one click from any operation instead of a scroll away in the preamble.
const PUBLIC_ERROR_DESCRIPTION = [
  'Every error body is exactly `{ "error": "<code>" }` — never internal detail such',
  'as a database type or connection provider.',
  '',
  '| Status | `error` | Meaning |',
  '|---|---|---|',
  '| 400 | `validation_failed` | Malformed request: bad JSON, an unknown or invalid'
    + ' body field, a malformed `Idempotency-Key`, a malformed cursor, or a malformed'
    + ' path segment. |',
  '| 400 | `owner_not_found` | `owner_username` (on create) matches no user who has'
    + ' signed in at least once. |',
  '| 401 | `invalid_token` | Missing, unknown, or deactivated token. Uniform — never'
    + ' reveals whether a token exists. |',
  '| 404 | `not_found` | The resource does not exist, or exists outside the granted'
    + ' scope (the two are indistinguishable on purpose). |',
  '| 404 | `path_not_found` | The hierarchy name-path matches no node the token is'
    + ' allowed to see. |',
  '| 409 | `path_ambiguous` | The name-path matches more than one node — add ancestor'
    + ' names to disambiguate. |',
  '| 409 | `owner_ambiguous` | `owner_username` matches more than one user. |',
  '| 409 | `idempotency_conflict` | The `Idempotency-Key` was reused with a different'
    + ' body, or a create with the same key is still in flight (check `Retry-After`). |',
  '| 415 | `validation_failed` | A write request sent a `Content-Type` other than'
    + ' `application/json`. |',
  '| 429 | `rate_limited` | Per-account budget exceeded. Honour `Retry-After`. |',
  '| 503 | `edge_unreachable` | Temporary backend problem — safe to retry (writes with'
    + ' the same `Idempotency-Key`). |',
].join('\n');

/**
 * Build OpenAPI spec for the customer-facing Public Integration API
 * (`/api/public/v1/*` only). Distinct from buildEdgeSpec/buildInfraSpec —
 * served by the documentation portal (spec §7), never mixes internal routes.
 *
 * `routeFiles` is a parameter for one reason: a test needs to assemble this
 * exact document from a fixture route file carrying the text that used to empty
 * it. Production callers pass nothing — PUBLIC_ROUTE_FILES stays the only list
 * the running service can build from.
 * @param {string[]} [routeFiles]
 */
function buildPublicSpec(routeFiles = PUBLIC_ROUTE_FILES) {
  const baseDir = path.resolve(__dirname, '../..');
  const paths = buildPaths(routeFiles, baseDir);
  assertOnlyPublicPaths(paths);

  // Operation count (not path-key count): /templates carries both GET and
  // POST under one path key, so the 7 public operations map to 6 unique paths.
  const operationCount = Object.values(paths)
    .reduce((sum, methods) => sum + Object.keys(methods).length, 0);
  if (operationCount < 7) {
    logger.warn({ operationCount, expected: '>=7' }, 'public spec has fewer operations than expected — some route files may have parse errors');
  }

  const { version } = require('../../package.json');

  const spec = {
    openapi: '3.0.0',
    info: {
      title: 'Public Integration API',
      version,
      description: GETTING_STARTED_DESCRIPTION,
    },
    // Relative server URL: no deployment-specific hostname committed to git
    // (CLAUDE.md §8 / feedback_no_deployment_specific_in_git). The portal is
    // always served from the same origin it documents.
    servers: [{ url: '/' }],
    components: {
      securitySchemes: {
        bearerAuth: {
          type: 'http',
          scheme: 'bearer',
          description: 'The app-issued API key for your service account, sent as Authorization: Bearer on the direct path. No exchange step.',
        },
        // Both carriers verify the SAME key the same way (public-gate.js checks
        // the api_key header first, then Authorization). Modelling the gateway
        // carrier as a scheme rather than prose keeps the two documented at the
        // same level of detail, so a gateway integrator is not left inferring
        // the header name from a paragraph.
        apiKeyAuth: {
          type: 'apiKey',
          in: 'header',
          name: 'api_key',
          description: 'The same app-issued API key, sent as an api_key header. This is the carrier an API gateway injects on the request it forwards. When both carriers are present, api_key wins.',
        },
      },
      schemas: {
        PublicError: {
          type: 'object',
          description: PUBLIC_ERROR_DESCRIPTION,
          properties: {
            error: {
              type: 'string',
              description: 'The machine-readable error code. The table above gives the meaning of each.',
              example: 'invalid_token',
              enum: [
                'invalid_token', 'not_found', 'path_not_found', 'path_ambiguous',
                'validation_failed', 'rate_limited', 'edge_unreachable',
                'idempotency_conflict', 'owner_not_found', 'owner_ambiguous',
              ],
            },
          },
          required: ['error'],
        },
      },
    },
    // Two alternatives, not two requirements: either carrier alone authenticates.
    security: [{ bearerAuth: [] }, { apiKeyAuth: [] }],
    paths,
  };

  // NOT checked here. The inline-script property is enforced two ways, neither
  // of them a runtime throw: escapeForInlineScript() on the copy handed to the
  // renderer (so a typo cannot break the page), and validatePublicSpec() in the
  // test suite (so a typo is still fixed at its source). A throw on this line
  // reached getPublicSpec()'s catch and cached an empty-paths stub, which
  // published an API with no operations over a description typo.
  return spec;
}

// ── Test-time validation ────────────────────────────────────────────────────
//
// The loud failure the runtime no longer performs. These build the real
// documents from the real route files and throw on the first breaker, naming
// the property and the files it can have come from. All three specs are covered
// because all three are rendered by the same inline-script mechanism —
// /api/public-docs, /api/docs and /edge/docs — so a violation in an edge or
// infra annotation is caught by the suite rather than by whoever happens to
// open that page.

/** @throws if the assembled public spec carries inline-script breaker text. */
function validatePublicSpec() {
  assertNoInlineScriptBreakers(buildPublicSpec(), PUBLIC_ROUTE_FILES);
}

/** @throws if any served spec carries inline-script breaker text. */
function validateServedSpecs() {
  validatePublicSpec();
  assertNoInlineScriptBreakers(buildEdgeSpec(), EDGE_ROUTE_FILES);
  assertNoInlineScriptBreakers(buildInfraSpec(), INFRA_ROUTE_FILES);
}

/**
 * Build once, keep the result, and degrade to an empty-paths stub if the build
 * throws. WHAT CAN STILL THROW here is a packaging or filesystem fault (a route
 * file that cannot be read, a leaked internal path) — for those, an empty
 * document is the safe direction. A documentation typo is deliberately NOT in
 * that set any more; it is escaped on the way to the renderer instead.
 * @param {() => Record<string, unknown>} build
 * @param {string} failureMessage
 * @returns {() => Record<string, unknown>}
 */
function memoizeSpec(build, failureMessage) {
  let cached = null;
  return () => {
    if (!cached) {
      try {
        cached = build();
      } catch (err) {
        logger.error({ err }, failureMessage);
        cached = { openapi: '3.0.0', info: { title: 'Error', version: '0' }, paths: {} };
      }
    }
    return cached;
  };
}

const getEdgeSpec = memoizeSpec(buildEdgeSpec, 'Failed to build edge OpenAPI spec');
const getInfraSpec = memoizeSpec(buildInfraSpec, 'Failed to build infra OpenAPI spec');
const getPublicSpec = memoizeSpec(buildPublicSpec, 'Failed to build public OpenAPI spec');

module.exports = { getEdgeSpec, getInfraSpec, getPublicSpec, escapeForInlineScript };
// Exposed for tests only — the mutation-style internal-leak invariant test
// builds paths from a deliberately-mutated file list (a real internal route
// file appended) and asserts assertOnlyPublicPaths rejects it, proving the
// invariant would catch a future accidental PUBLIC_ROUTE_FILES edit.
module.exports._test = {
  buildPaths,
  assertOnlyPublicPaths,
  PUBLIC_ROUTE_FILES,
  PUBLIC_API_PREFIX,
  // The inline-script guard is exercised against fixtures as well as the real
  // spec — a guard only proven on data that already passes is not proven.
  assertNoInlineScriptBreakers,
  findInlineScriptBreakers,
  escapeInlineScriptString,
  validatePublicSpec,
  validateServedSpecs,
  // Uncached and unswallowed: getPublicSpec() turns a build failure into an
  // empty stub, which would pass any content check and lose the message naming
  // the offending property.
  buildPublicSpec,
  // Lets a test reproduce the exact accessor semantics — memoised, with a build
  // failure becoming the empty stub — over a fixture-built spec, which is how
  // the "a typo must not empty the contract" proof stays honest.
  memoizeSpec,
};
