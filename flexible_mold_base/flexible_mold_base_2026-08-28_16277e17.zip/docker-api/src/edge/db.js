/**
 * db.js — Lazy-initialized MariaDB connection pool with RW/RO namespace.
 *
 * The pool exposes two explicit namespaces:
 *   pool.rw — writer pool (always present once configured)
 *   pool.ro — reader pool (falls back to pool.rw when no separate RO host)
 *
 * The deprecated `pool.getConnection()` / `pool.query()` shims have been
 * removed. All call sites now go through `pool.rw.*` / `pool.ro.*` explicitly,
 * and ship-gate Step 5 (`scripts/cicd/ship-gate-check.sh`) fails the build
 * on any regression that reintroduces a bare `pool.getConnection` call.
 *
 * Environment variables:
 *   DB_RW_HOST / DB_RW_PORT / DB_RW_USER / DB_RW_PASSWORD   (canonical names)
 *   DB_RO_HOST / DB_RO_PORT (optional — both-or-neither; fail-fast if one is set alone)
 *   DB_RO_USER / DB_RO_PASSWORD (optional; fall back to DB_RW_USER / DB_RW_PASSWORD)
 *
 * Pool lifecycle — see configurePool() / initializeFromConfig().
 */
const mariadb = require('mariadb');
const fs = require('fs');
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const { setInfraPool, setInfraReadPool, getDynamicPool, cleanupIdlePools, shutdownDynamicPools } = require('./pool-manager');
const { buildInfraTableDDLs, buildEngineTableDDLs, INFRA_TABLE_NAMES, ENGINE_TABLE_NAMES } = require('../table-ddls');
const { TABLES, VARIANT_OVERRIDE_ACTIONS } = require('../shared/constants');
const {
  assertPreflightOrThrow,
  assertReadPreflightOrThrow,
  PreflightError,
  DdlPrivilegeError,
  preflightDdlGrants,
  summarizeCrudDegrade,
  mergeDegrade,
} = require('../shared/lib/preflight-grants');
// NOTE: structured error classes replace the silent `|| 'fmb_'` fallback
// that hid mis-configurations until a route ran a query against the wrong
// schema. See LEARN.md §64.
const { PoolNotConfiguredError, MigrationError } = require('../shared/lib/db-errors');
const { sanitizeMigrationError } = require('../shared/lib/migration-sanitizer');
const { tableExistsInCurrentSchema } = require('./lib/table-exists');
const {
  sanitizeConfigureError,
  envKeysPresent,
  buildPoolDiagnostic,
} = require('../shared/lib/pool-diagnostic');
const { SQL_MODE_STATE, normalizeSqlModeState, probeSqlMode, sqlModeWarning } = require('../shared/lib/sql-mode');
const { isEncryptionKeyConfigured } = require('../shared/lib/settings-crypto');
const { encryptConfigSecrets, decryptConfigSecrets } = require('../shared/lib/db-config-crypto');
const { logger: rootLogger } = require('../shared/lib/logger');
const logger = rootLogger.child({ module: 'db' });
const { createMigrationsModule } = require('./migrations');
// PLATFORM_SCHEMA_VERSION now lives next to the declarative registry
// (migration-steps.js). Re-exported below so existing importers (schema-status,
// tests) that read it from './db' keep working.
const { PLATFORM_SCHEMA_VERSION } = require('./migration-steps');

const CONFIG_DIR = path.join(__dirname, '..', '..', 'data');
const CONFIG_PATH = path.join(CONFIG_DIR, 'db-config.json');
const APP_TABLE_NAMES = INFRA_TABLE_NAMES.concat(ENGINE_TABLE_NAMES);

// Loopback addresses that indicate a likely Docker networking misconfiguration
// when the process is running inside a container (/.dockerenv exists).
const LOOPBACK_HOSTS = ['localhost', '127.0.0.1', '::1'];

let _rwPool = null;
let _roPool = null;   // null → fallback to _rwPool via pool.ro proxy
// NOTE: null until configurePool() commits a real prefix; t() throws
// PoolNotConfiguredError in the meantime so a missing setup surfaces
// immediately. The old silent `'fmb_'` default was removed to prevent
// mis-configured deployments silently querying the wrong schema.
let _tablePrefix = null;
let _configSource = 'none'; // 'env' | 'file' | 'none' | 'memory'
let _configFull = null;     // full config including password (internal use only)
// NOTE: last configurePool() error, sanitised (code/errno/sqlState only —
// see pool-diagnostic.sanitizeConfigureError). Cleared on successful configure.
// Surfaced via getPoolDiagnostic() to /health and the pool-gate apiError body
// so admins can tell which failure mode produced _rwPool=null.
let _lastConfigureError = null;
// Structured degrade record when the pool is live but the configured account
// is missing CRUD on some tables (see summarizeCrudDegrade). null when healthy.
// Surfaced via getPoolDiagnostic().degraded_grants; never blocks the swap.
let _degradedGrants = null;
// Whether this deployment's engine REFUSES a value it cannot store, read off
// the pool that will do the writing. Re-read on every configure, because a
// pool pointed at a different database is a different answer. Three-valued:
// 'unknown' is what the probe reports when it could not read, and it is never
// folded into either of the others — see shared/lib/sql-mode.js for why the
// distinction is the whole point.
let _sqlModeState = SQL_MODE_STATE.UNKNOWN;

// ── Pool facade ──────────────────────────────────────────────────────────────
// Routes hold a reference to `pool` imported once; we keep the facade stable
// and swap the underlying mariadb pools inside configurePool().
//
// NOTE: the rw/ro namespaces are plain object properties set once at module
// load. Each method closes over the module-level `_rwPool` / `_roPool` `let`
// bindings and re-reads them at call time, so configurePool() can still swap
// the underlying pools atomically. Identity holds:
//   pool.rw === pool.rw  // true
//   const rw = pool.rw; rw === pool.rw  // true
// This matches the _dynamicFacade pattern in pool-manager.js.

function _assertConfigured(which) {
  const underlying = which === 'ro' ? (_roPool || _rwPool) : _rwPool;
  if (!underlying) {
    throw Object.assign(
      new Error('Database not configured. Please complete setup first.'),
      { code: 'DB_NOT_CONFIGURED' }
    );
  }
  return underlying;
}

// All facade methods are async so a "pool not configured yet" error surfaces
// as a rejected promise (consistent with mariadb's native async API).
// Tests use assert.rejects to verify.
const _rwFacade = {
  async getConnection() { return _assertConfigured('rw').getConnection(); },
  async query(sql, params) { return _assertConfigured('rw').query(sql, params); },
  async end() {
    if (_rwPool) return _rwPool.end();
  },
};

const _roFacade = {
  async getConnection() { return _assertConfigured('ro').getConnection(); },
  async query(sql, params) { return _assertConfigured('ro').query(sql, params); },
  async end() {
    if (_roPool) return _roPool.end();
  },
};

const pool = {
  rw: _rwFacade,
  ro: _roFacade,
  async end() {
    if (_rwPool) { try { await _rwPool.end(); } catch {} }
    if (_roPool) { try { await _roPool.end(); } catch {} }
  },
};

/**
 * Returns the full table name with the configured prefix.
 *
 * NOTE: throws PoolNotConfiguredError when no prefix is configured.
 * The previous implementation used a hard-coded `'fmb_'` default that
 * silently mis-routed queries on deployments with a different prefix
 * (e.g., an `example_app_*` deployment). Callers must now ensure
 * configurePool() has run, or handle the structured error explicitly.
 *
 * e.g. with `_tablePrefix='example_app_'`: t('users') → 'example_app_users'
 *
 * @throws {PoolNotConfiguredError} when _tablePrefix is null or empty
 */
function t(tableName) {
  if (!_tablePrefix) {
    throw new PoolNotConfiguredError(`t(${JSON.stringify(tableName)})`);
  }
  return `${_tablePrefix}${tableName}`;
}

/** Check if the writer pool is ready for use */
function isPoolReady() {
  return _rwPool !== null;
}

// NOTE: bounded retry on transient DB connection errors. Allowlist is
// keyed on err.code (NOT message substring) so a future driver wording
// change can't silently turn an access-denied error into a 6-second sleep loop.
const _TRANSIENT_CONNECT_CODES = new Set([
  'ECONNREFUSED', // mariadb container not yet listening
  'ETIMEDOUT',    // network slow path; cluster DNS warming up
  'EAI_AGAIN',    // DNS resolver throttled (Kubernetes coredns hiccup)
  'ENOTFOUND',    // DNS not yet propagated for newly-created service
]);

async function _connectWithRetry(pool, opts = {}) {
  const maxAttempts = Number(opts.maxAttempts ?? 3);
  const baseDelayMs = Number(opts.baseDelayMs ?? 2000);
  let lastErr = null;
  for (let attempt = 1; attempt <= maxAttempts; attempt += 1) {
    try {
      const conn = await pool.getConnection();
      conn.release();
      return;
    } catch (err) {
      lastErr = err;
      if (!_TRANSIENT_CONNECT_CODES.has(err?.code)) {
        // Credential / DB / config error → no point retrying. Surface
        // the structured failure code so getPoolDiagnostic / hint_code
        // can branch correctly.
        throw err;
      }
      if (attempt === maxAttempts) break;
      // Linear backoff is fine here: total budget ≤ 6s on the
      // default (3 attempts × 2s) which keeps the boot path honest.
      // Exponential would push past the K8s readiness probe window
      // for no real gain on these specific error classes.
      await new Promise((r) => setTimeout(r, baseDelayMs));
    }
  }
  throw lastErr;
}

/**
 * Surface pool readiness + sanitised last error for /health and pool-gate.
 *
 * SECURITY: this is callable from unauthenticated callers of /health. The
 * sanitisation happens upstream (sanitizeConfigureError); this function
 * never returns `err.message` or raw env values.
 */
function getPoolDiagnostic() {
  return buildPoolDiagnostic({
    poolReady: _rwPool !== null,
    lastError: _lastConfigureError,
    // SECURITY: public health surface must not carry table names or GRANT-SQL hint
    // (those are already emitted in boot stderr / logger at degrade time).
    degradedGrants: _degradedGrants
      ? {
          reason: _degradedGrants.reason,
          severity: _degradedGrants.severity,
          missing_table_count: Array.isArray(_degradedGrants.missingTables)
            ? _degradedGrants.missingTables.length
            : 0,
        }
      : null,
    envPresence: envKeysPresent(process.env),
    dbConfigJsonPresent: (() => {
      try { return fs.existsSync(CONFIG_PATH); } catch { return false; }
    })(),
    tablePrefixSet: typeof _tablePrefix === 'string' && _tablePrefix.length > 0,
    encryptionKeyPresent: isEncryptionKeyConfigured(),
  });
}

/**
 * Whether the engine behind the CONFIGURED pool refuses a value it cannot
 * store, or substitutes one.
 *
 * SECURITY — DELIBERATELY NOT PART OF getPoolDiagnostic(). That object is a
 * health body, and both health endpoints are unauthenticated: infra's `/health`
 * is mounted ahead of every auth middleware, and `/edge/health` is exempt from
 * s2s-verify AND, on any overlay carrying the `edge-exposed` component, from the
 * Istio header requirement as well. This reading answers "is an over-long
 * string, an out-of-range integer or a non-member ENUM value worth writing at
 * this host", which is a stranger's question, not an operator's. Withholding it
 * from ONE of the two health bodies would leave the same answer readable through
 * the other, so it is not in the body at all. It travels S2S
 * (/edge/internal/system/auth-mode) to the ADMIN tier of /api/auth/diagnostics,
 * and it is on the boot banner and the structured log.
 *
 * The scope is in the name because it is narrower than "this deployment": a
 * request carrying `db` writes through a pool built for that connection, which
 * this reading never touched.
 *
 * @returns {'strict'|'lax'|'unknown'}
 */
function getConfiguredPoolStrictWrites() {
  return normalizeSqlModeState(_sqlModeState);
}

/** Get current DB config (safe for frontend — no password) */
function getDbConfig() {
  if (!_rwPool) return null;
  const readConfigured = !!(_configFull?.readHost && _configFull?.readPort);
  return {
    host: _configFull?.host || '(unknown)',
    port: _configFull?.port || 3306,
    user: _configFull?.user || '(unknown)',
    database: _configFull?.database || '(unknown)',
    tablePrefix: _tablePrefix,
    source: _configSource,
    configured: true,
    readEndpoint: readConfigured
      ? {
          host: _configFull.readHost,
          port: _configFull.readPort,
          user: _configFull.readUser || _configFull.user,
        }
      : null,
  };
}

// SECURITY/INVARIANT: 'memory' is set only by the live configure-db handler for
// a non-persisted (in-memory) swap, so the visibility surface stops reporting a
// stale 'file'/'none'. Boot (env/file load) and reset still drive _configSource
// through their own paths.
function setConfigSource(src) {
  _configSource = src;
}

/** Get full DB config including password (internal use — X-Database middleware only) */
function getDbConfigFull() {
  return _configFull;
}

// ── Infrastructure DDL ────────────────────────────────────────────────────────

function buildInfraTablesDDL() {
  return buildInfraTableDDLs(t);
}

// ── Config validation ─────────────────────────────────────────────────────────

/**
 * Validate read-endpoint config consistency (both-or-neither).
 * Throws a boot-time error if only one of readHost / readPort is present,
 * or if readHost is set but its value is obviously invalid.
 *
 * This is called from both buildEnvConfig() and configurePool() so that a
 * config file written via POST /api/setup/configure-db is held to the same
 * contract as one derived from env vars.
 */
function assertReadConfig(cfg) {
  const hasHost = cfg.readHost != null && cfg.readHost !== '';
  const hasPort = cfg.readPort != null && cfg.readPort !== '';
  if (hasHost !== hasPort) {
    const err = new Error(
      'DB_RO_HOST and DB_RO_PORT must be set together (both-or-neither). ' +
      `Got readHost=${hasHost ? JSON.stringify(cfg.readHost) : '<unset>'} ` +
      `readPort=${hasPort ? JSON.stringify(cfg.readPort) : '<unset>'}. ` +
      'Either configure a separate read endpoint by setting both, or unset both ' +
      'to fall back to the writer pool for reads.'
    );
    err.code = 'INVALID_READ_CONFIG';
    throw err;
  }
}

// ── Pool lifecycle ────────────────────────────────────────────────────────────

/**
 * Common mariadb.createPool options shared by both RW and RO pools.
 */
function _poolOpts(host, port, user, password, database) {
  return {
    host,
    port: parseInt(String(port || '3306'), 10),
    user,
    password: password || '',
    database,
    connectionLimit: 10,
    connectTimeout: 5000,
    acquireTimeout: 8000,
    idleTimeout: 60000,
    // Cap command execution at 30s so a stalled/hung query (lock contention, an
    // unresponsive server) can't pin a request for the server's default
    // net_read_timeout. TRADEOFF: this is a hard ceiling on a single statement,
    // so a genuinely large bulk op on the main pool (sync-schema DDL/import,
    // engine-data export SELECT, wipe DELETE) over a big dataset would be aborted
    // at 30s. Chosen as the safe blanket value because normal request queries run
    // sub-second; the dynamic cross-env sync pools (pool-manager) are deliberately
    // left uncapped since they carry the heaviest legitimately-long bulk work.
    queryTimeout: 30000,
    // NOTE: hand back ISO-8601-shaped strings for TIMESTAMP/DATE columns and
    // pin the session timezone to UTC. The dto-mapper layer then normalises
    // and re-emits them as full ISO 8601. We deliberately do NOT set typeCast
    // (TINYINT(1) heuristic is unreliable) or decimalNumbers (precision risk
    // for DECIMAL(p>15)). Boolean and decimal coercion happens explicitly in
    // the per-column DTO mapper instead.
    dateStrings: true,
    timezone: '+00:00',
  };
}

/**
 * Run SHOW GRANTS + information_schema preflight on a probe connection
 * acquired from the *new* pool, before any module state swap. Throws
 * PreflightError if the new credentials lack CREATE/ALTER on infra tables.
 *
 * NOTE: probe connection is always released via try/finally, even when
 * preflight throws or when release itself errors — otherwise a repeat
 * /configure-db failure could leak fds up to ulimit.
 *
 * Caller is responsible for emitting the stderr banner in boot context.
 */
async function _runPreflightOnNewPool(newPool, config, probePrefix) {
  let probeConn = null;
  try {
    probeConn = await newPool.getConnection();
    const prefixFn = (n) => `${probePrefix}${n}`;
    await assertPreflightOrThrow(
      probeConn,
      config.database,
      APP_TABLE_NAMES,
      prefixFn,
      { user: config.user, tablePrefix: probePrefix },
    );
  } finally {
    if (probeConn) {
      try { await probeConn.release(); } catch {}
    }
  }
}

/**
 * SELECT preflight for the RO pool. Same MD1 try/finally cleanup as
 * _runPreflightOnNewPool. Caller (configurePool) emits banner on boot context.
 *
 * @param {object} newRoPool - mariadb pool instance for the RO endpoint
 * @param {object} config - DB config; reads `database` for the probe target
 * @param {string} probePrefix - table-prefix to assert presence of (e.g., 'fmb_')
 */
async function _runReadPreflightOnNewPool(newRoPool, config, probePrefix) {
  let probeConn = null;
  try {
    probeConn = await newRoPool.getConnection();
    const prefixFn = (n) => `${probePrefix}${n}`;
    await assertReadPreflightOrThrow(
      probeConn,
      config.database,
      APP_TABLE_NAMES,
      prefixFn,
      { user: config.user, tablePrefix: probePrefix },
    );
  } finally {
    if (probeConn) {
      try { await probeConn.release(); } catch {}
    }
  }
}

/**
 * Create the real MariaDB pool(s) from config and ensure infra tables exist.
 *
 * INVARIANT: pool swap is gated on a pre-swap preflight probe. TCP-reachable
 * probe + SHOW GRANTS check run on a connection from the new pool BEFORE any
 * module state changes. If the probe fails, the new pool is closed and the
 * existing pools continue to serve traffic — no "ghost save" where
 * `_configFull` points at the new pool but disk + live queries disagree.
 *
 * INVARIANT: when a separate read endpoint is configured, SELECT preflight
 * runs on the RO pool too. Either side failing aborts the swap.
 */
async function configurePool(config) {
  // Validate RO consistency before touching any existing pool
  assertReadConfig(config);

  // Discriminator for boot-vs-reconfigure error rendering. Captured BEFORE
  // any pool work so the decision is stable across async boundaries.
  const isBoot = !_rwPool;

  // INVARIANT: do NOT null out _rwPool/_roPool before the probe. Concurrent
  // requests arriving during the probe would otherwise see DB_NOT_CONFIGURED —
  // keep the old pools live until both probes pass, then swap in the new ones,
  // then close the old ones.

  // Detect common Docker networking misconfiguration: localhost inside a
  // container points to the container itself, not to sibling services.
  if (LOOPBACK_HOSTS.includes(config.host) && fs.existsSync('/.dockerenv')) {
    logger.warn(
      { host: config.host },
      'DB_RW_HOST is a loopback address inside a Docker container. ' +
      '"localhost" refers to the container itself, not sibling services. ' +
      'Set DB_RW_HOST to the Compose service name (e.g. "mariadb").'
    );
  }

  // NOTE: tablePrefix is required end-to-end. The previous fallback chain
  // (explicit → `<database>_` → 'fmb_') let mis-configured setups silently
  // route queries against `fmb_*` even when the actual schema lived under a
  // different prefix. The caller is now responsible for populating tablePrefix;
  // buildEnvConfig() reads it from DB_TABLE_PREFIX and the setup wizard
  // enforces non-empty in db-connect.js. Empty/missing here is a programmer
  // error — fail loudly so the regression surfaces in tests/CI.
  if (typeof config.tablePrefix !== 'string' || !config.tablePrefix) {
    throw Object.assign(
      new Error(
        'configurePool: tablePrefix is required and must be a non-empty string. ' +
          'Set DB_TABLE_PREFIX (env) or send tablePrefix in the /api/setup/db-connect body. ' +
          'See LEARN.md §63.',
      ),
      { code: 'TABLE_PREFIX_REQUIRED' },
    );
  }
  const probePrefix = config.tablePrefix;

  const newRw = mariadb.createPool(
    _poolOpts(config.host, config.port, config.user, config.password, config.database)
  );

  // Verify RW connection works BEFORE committing. Bounded retry only on
  // transient err.code values — DNS not-yet-resolved (EAI_AGAIN/ENOTFOUND),
  // connection refused (mariadb not yet bound), and timeout. Credential /
  // DB-not-found errors fail fast because retrying won't help and the admin
  // needs the error surfaced now.
  try {
    await _connectWithRetry(newRw);
  } catch (err) {
    try { await newRw.end(); } catch {}
    // Old pools are still live — nothing to restore.
    throw err;
  }

  // INVARIANT: preflight on RW BEFORE swap. Connectivity already passed above.
  // A missing-CRUD PreflightError is NON-FATAL: we can connect, so a degraded
  // pool is strictly more useful than setup-required. Record + log the gap and
  // proceed with the swap; the DBA can grant the listed privileges live and the
  // next reconfigure/restart self-heals. Mirrors the DDL preflight's existing
  // graceful-degrade. Any non-PreflightError is genuinely unexpected → keep the
  // old pool and propagate.
  let degradedInfo = null;
  try {
    await _runPreflightOnNewPool(newRw, config, probePrefix);
  } catch (err) {
    if (!(err instanceof PreflightError)) {
      try { await newRw.end(); } catch {}
      throw err;
    }
    degradedInfo = summarizeCrudDegrade(err, {
      infraTableNames: INFRA_TABLE_NAMES,
      engineTableNames: ENGINE_TABLE_NAMES,
    });
    // Bind to the logger — pino methods lose `this` (writeSym) when detached.
    const logFn = degradedInfo.severity === 'critical'
      ? logger.error.bind(logger)
      : logger.warn.bind(logger);
    logFn(
      { severity: degradedInfo.severity, tables: degradedInfo.missingTables },
      'DB pool configured with missing CRUD privileges — running degraded; grant the listed privileges to clear',
    );
    if (isBoot) {
      process.stderr.write(
        `WARN:  ${err.message}\n` +
          `CAUSE: ${probePrefix}* tables cannot be fully read/written without the listed privileges — running DEGRADED\n` +
          `FIX:   ask the DBA to run (paste verbatim):\n${err.grantSqlHint || '  (no hint — grants probe failed; check user@host ACL)'}\n`,
      );
    }
  }

  let newRo = null;
  if (config.readHost && config.readPort) {
    const roUser = config.readUser || config.user;
    const roPassword = config.readPassword != null ? config.readPassword : config.password;
    const roDatabase = config.database;
    newRo = mariadb.createPool(_poolOpts(config.readHost, config.readPort, roUser, roPassword, roDatabase));

    try {
      const conn = await newRo.getConnection();
      conn.release();
    } catch (err) {
      try { await newRo.end(); } catch {}
      try { await newRw.end(); } catch {}
      // Old pools still live — nothing to restore.
      err.message = `Read-endpoint connection failed (${config.readHost}:${config.readPort}): ${err.message}`;
      throw err;
    }

    // NOTE: RO user SELECT preflight. Least-privilege deploys often give the
    // RO user SELECT-only; verify that grant is present so a missing privilege
    // surfaces at configure time instead of at first read.
    // RO missing SELECT is non-fatal — reads degrade. (RO *connection* failure
    // above stays fatal.) Record + continue the swap; do NOT tear down pools.
    try {
      await _runReadPreflightOnNewPool(newRo, { ...config, user: roUser }, probePrefix);
    } catch (err) {
      if (!(err instanceof PreflightError)) {
        // SAFETY: RO must be released before RW. Inner try/catch swallows RO
        // failure so RW close still runs. Do not refactor to a single try.
        try { await newRo.end(); } catch {}
        try { await newRw.end(); } catch {}
        throw err;
      }
      const roDegrade = summarizeCrudDegrade(err, {
        infraTableNames: INFRA_TABLE_NAMES,
        engineTableNames: ENGINE_TABLE_NAMES,
      });
      degradedInfo = mergeDegrade(degradedInfo, roDegrade);
      logger.warn(
        { endpoint: 'read', tables: roDegrade.missingTables },
        'RO pool configured with missing SELECT privileges — degraded reads',
      );
      if (isBoot) {
        process.stderr.write(
          `WARN:  ${err.message} (read endpoint) — running DEGRADED\n` +
            `FIX:   ask the DBA to run:\n${err.grantSqlHint || '  (no hint — grants probe failed)'}\n`,
        );
      }
    }
  }

  // Snapshot prev for cleanup after successful swap.
  const prevRwPool = _rwPool;
  const prevRoPool = _roPool;

  // Commit: swap module state FIRST, then close the previous pools. A
  // concurrent request that landed between the probe and the swap sees
  // the old live pool; after the swap it sees the new one.
  _tablePrefix = probePrefix;
  _configFull = { ...config, tablePrefix: _tablePrefix };
  if (config._source) _configSource = config._source;
  _rwPool = newRw;
  _roPool = newRo;

  // Expose infra pool to pool-manager so routes can access it via getInfraPool()
  setInfraPool(_rwPool);
  setInfraReadPool(_roPool); // null when no separate RO endpoint → getInfraReadPool falls back

  // NOTE: pool is live — clear the staged failure record.
  _lastConfigureError = null;
  // Record (or clear) the degrade state alongside the successful swap.
  _degradedGrants = degradedInfo;

  // WHETHER THIS ENGINE REFUSES A VALUE IT CANNOT STORE, asked of the pool that
  // will do the writing and answered on every configure.
  //
  // This is the one fact in this family that no repository rule can see: the
  // same code against the same schema either fails a bad write or silently
  // stores a different value, depending on a server setting. It changes the
  // SEVERITY of a whole class of ranked defects — an omitted NOT NULL column, an
  // over-range integer, a non-member written to an ENUM — from "the request
  // 500s" to "the row is quietly wrong", which is the difference between a
  // defect an operator hears about and one they do not.
  //
  // REPORTED, NEVER ENFORCED. A server that refuses to start because it
  // disagrees with a DBA about a session variable is a worse outcome than one
  // that says so on every health check, and the probe can fail for reasons that
  // are not the setting. So it cannot throw, it cannot block the swap, and its
  // "unknown" is a value rather than an assumption.
  try {
    const modeConn = await _rwPool.getConnection();
    try {
      const reading = await probeSqlMode(modeConn);
      _sqlModeState = reading.state;
      if (reading.state !== SQL_MODE_STATE.STRICT) {
        const warning = sqlModeWarning(reading.state);
        logger.warn({ sql_mode: reading.mode, state: reading.state }, `sql_mode: ${warning}`);
        if (isBoot) {
          process.stderr.write(`WARN:  sql_mode ${reading.state} — ${warning}\n`);
        }
      }
    } finally {
      // SAFETY: a failing release must not cost a reading that was already
      // taken. Unwrapped, a synchronous throw here reaches the outer catch and
      // overwrites a good answer with 'unknown', and a rejected promise escapes
      // as an unhandled rejection — both for a reason that has nothing to do
      // with the value. Same shape as the preflight probe's release.
      try { await modeConn.release(); } catch {}
    }
  } catch {
    // Leasing the connection is itself part of what can fail. The reading stays
    // unknown and the server serves; nothing here is worth a boot failure.
    _sqlModeState = SQL_MODE_STATE.UNKNOWN;
  }

  // Close the previous pools only after the swap is visible.
  if (prevRwPool) { try { await prevRwPool.end(); } catch {} }
  if (prevRoPool) { try { await prevRoPool.end(); } catch {} }

  // NOTE: preflight already ran pre-swap; ensureInfrastructure skips it to
  // avoid re-probing (SHOW GRANTS is cheap but pointless to repeat). It still
  // runs DDL + login_audit ENUM migration + runSchemaMigrations.
  await ensureInfrastructure({ skipPreflight: true });

  logger.info(
    {
      host: config.host,
      port: config.port,
      database: config.database,
      prefix: _tablePrefix,
      readEndpoint: newRo ? `${config.readHost}:${config.readPort}` : 'fallback-to-writer',
    },
    'pool configured'
  );
}

/**
 * Persist DB config to a file so the pool survives a pod restart.
 *
 * NOTE: persistence is opt-in. The common path (temporarily pointing the pool
 * at an admin DB account) does NOT persist — it returns false without touching
 * the filesystem, so read-only-rootfs pods produce no misleading EROFS warning.
 *
 * @param {object} config
 * @param {{ persist?: boolean }} [opts]
 * @returns {boolean} true if a file was written, false if persistence was skipped
 */
function saveConfig(config, opts = {}) {
  return _saveConfigToPath(config, CONFIG_PATH, opts);
}

// Path-parameterised core of saveConfig. The configPath seam exists only so
// tests can write to a temp file; production callers go through saveConfig
// (CONFIG_PATH-bound) and never pass a path. Exposed via _internalsForTest.
function _saveConfigToPath(config, configPath, opts = {}) {
  const { persist = false } = opts;
  if (!persist) return false;

  const dir = path.dirname(configPath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
  }
  // SECURITY: chmod after write — fs mode option only applies on create,
  // so existing inodes from prior installs keep their old (e.g. 0o644) bits
  // and would leak the DB password file on upgrade paths.
  fs.chmodSync(dir, 0o700);
  const { _source, ...rest } = config;
  // SECURITY: secrets are encrypted at rest; plaintext only ever lives in
  // process memory. encryptConfigSecrets is fail-closed without a key.
  const persistable = encryptConfigSecrets(rest);
  fs.writeFileSync(configPath, JSON.stringify(persistable, null, 2), { mode: 0o600 });
  fs.chmodSync(configPath, 0o600);
  _configSource = 'file';
  logger.info({ configPath }, 'config saved');
  return true;
}

/**
 * Build config object from environment variables.
 *
 * NOTE: canonical DB_RW_* / DB_RO_* names only. Legacy DB_HOST / DB_PORT /
 * DB_USER / DB_PASSWORD have been removed after a deprecation window.
 * Deployments stuck on legacy names must rotate before upgrading or config
 * validation will reject the boot.
 *   - Require DB_RW_HOST.
 *   - DB_RO_HOST + DB_RO_PORT are both-or-neither (assertReadConfig).
 *
 * Returns null when no writer host is configured (setup-required mode).
 */
// NOTE: identifier shape allowlist mirrors the same regex used in the
// db-connect.js HTTP path, blocking newline / ANSI / shell metacharacter
// injection into the boot stderr banner via env.
const ENV_IDENTIFIER_RE = /^[a-zA-Z0-9_]+$/;

function buildEnvConfig() {
  const dbName = process.env.DB_NAME;
  if (!dbName) {
    logger.error('Failed to build env config: DB_NAME is required. Set DB_NAME in env or configure via Setup Wizard.');
    return null;
  }
  if (!ENV_IDENTIFIER_RE.test(dbName)) {
    logger.error({ dbName: '<rejected>' }, 'Failed to build env config: DB_NAME must match [a-zA-Z0-9_]+');
    return null;
  }

  const tablePrefix = process.env.DB_TABLE_PREFIX;
  if (!tablePrefix) {
    logger.error('Failed to build env config: DB_TABLE_PREFIX is required. Set DB_TABLE_PREFIX explicitly in env or configure via Setup Wizard. Silent fallback to ${DB_NAME}_ was removed in v3.2.61.');
    return null;
  }
  if (!ENV_IDENTIFIER_RE.test(tablePrefix)) {
    logger.error({ tablePrefix: '<rejected>' }, 'Failed to build env config: DB_TABLE_PREFIX must match [a-zA-Z0-9_]+');
    return null;
  }

  const rwHost = process.env.DB_RW_HOST;
  const rwPort = process.env.DB_RW_PORT;
  const rwUser = process.env.DB_RW_USER || 'root';
  const rwPassword = process.env.DB_RW_PASSWORD;

  if (!rwHost) return null;

  const readHost = process.env.DB_RO_HOST;
  const readPort = process.env.DB_RO_PORT;
  const readUser = process.env.DB_RO_USER;        // optional — fallback RW in configurePool
  const readPassword = process.env.DB_RO_PASSWORD; // optional — fallback RW in configurePool

  const cfg = {
    host: rwHost,
    port: parseInt(String(rwPort || '3306'), 10),
    user: rwUser,
    password: rwPassword || '',
    database: dbName,
    tablePrefix,
    _source: 'env',
  };

  if (readHost || readPort) {
    cfg.readHost = readHost || null;
    cfg.readPort = readPort ? parseInt(String(readPort), 10) : null;
    cfg.readUser = readUser || null;
    // WORKAROUND: '' for the RO password is a valid MariaDB credential
    // when the RO user is explicit (passwordless replica). Only when the
    // RO user falls back to null (vault-init seeds DB_RO_USER='' too) do
    // we coerce the password to null so it falls back symmetrically —
    // otherwise the previous asymmetric `!= null` check kept '' and
    // produced (RW user, '' password) → "using password: NO".
    cfg.readPassword = cfg.readUser == null
      ? (readPassword || null)
      : (readPassword != null ? readPassword : null);
  }

  // On the boot path a half-set DB_RO_* pair degrades to setup-required (null),
  // consistent with the DB_NAME / DB_TABLE_PREFIX cases above — never a throw
  // that would crash-loop the pod. assertReadConfig itself stays strict for the
  // Setup-Wizard write path (configurePool), which must reject a bad pair loudly.
  try {
    assertReadConfig(cfg);
  } catch (err) {
    if (err && err.code === 'INVALID_READ_CONFIG') {
      logger.error('Failed to build env config: DB_RO_HOST and DB_RO_PORT must be set together (both-or-neither). Treating as setup-required.');
      return null;
    }
    throw err;
  }

  return cfg;
}

/**
 * Load config from file or env vars. Returns null if neither exists.
 */
function loadConfig() {
  return _loadConfigFromPath(CONFIG_PATH);
}

// Path-parameterised core of loadConfig. The configPath seam exists only so
// tests can point at a temp file; production callers go through loadConfig
// (CONFIG_PATH-bound). Exposed via _internalsForTest.
function _loadConfigFromPath(configPath) {
  // Priority 1: config file (written by frontend Setup)
  try {
    if (fs.existsSync(configPath)) {
      const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
      let decrypted;
      try {
        decrypted = decryptConfigSecrets(config);
      } catch (err) {
        // SECURITY: an encrypted file with no key resolves to unconfigured
        // rather than feeding ciphertext to the pool as a password.
        logger.error({ code: err.code }, 'Cannot decrypt DB config file; treating as unconfigured');
        return null;
      }
      logger.info('DB config source resolved — file: used; source=file');
      return { ...decrypted, _source: 'file' };
    }
  } catch (err) {
    logger.error({ err, configPath }, 'Failed to read DB config file');
  }

  // Priority 2: environment variables (deployment fallback). Log the per-source
  // OUTCOME (not intent) so a misconfigured deployment is legible in the boot log
  // rather than the old contradictory "config loaded from env vars" → "no DB
  // config found". buildEnvConfig() already logs the specific missing-field
  // reason (DB_NAME / DB_TABLE_PREFIX / RO pair); this states the resolved source.
  if (process.env.DB_RW_HOST) {
    const cfg = buildEnvConfig();
    if (cfg) {
      logger.info('DB config source resolved — file: absent; env: used; source=env');
      return cfg;
    }
    logger.info('DB config source resolved — file: absent; env: DB_RW_HOST set but config incomplete (see reason above); source=none → setup-required');
    return null;
  }

  logger.info('DB config source resolved — file: absent; env: DB_RW_HOST unset; source=none → setup-required');
  return null;
}

/**
 * Delete the saved config file and reset pool state.
 */
async function resetConfig() {
  if (fs.existsSync(CONFIG_PATH)) {
    fs.unlinkSync(CONFIG_PATH);
    logger.info('config file deleted');
  }
  if (_rwPool) { try { await _rwPool.end(); } catch {} _rwPool = null; }
  if (_roPool) { try { await _roPool.end(); } catch {} _roPool = null; }
  _configFull = null;
  // NOTE: also reset _tablePrefix so a stale value can't outlive the pool.
  // t() throws on null prefix, so any code path that calls t() between
  // resetConfig and the next configurePool will fail loudly instead of
  // querying the wrong tables.
  _tablePrefix = null;
  // INVARIANT: every reading that DESCRIBES a pool dies with that pool. These
  // three are answers about a database this process is no longer connected to,
  // and each of them renders on the health surface an operator uses to decide
  // what to do next: a stale strict/lax reading says writes are safe on a
  // server that is gone, a stale configure error reports pool_state 'degraded'
  // for a teardown that was deliberate, and stale degraded_grants describes an
  // account no longer in use. A pool is torn down here, so its readings are
  // cleared here — the next configurePool takes fresh ones. t() got this
  // treatment above for the same reason; these are the rest of the family.
  _sqlModeState = SQL_MODE_STATE.UNKNOWN;
  _lastConfigureError = null;
  _degradedGrants = null;
  setInfraPool(null);
  setInfraReadPool(null);

  // Fall back to env vars if available
  if (process.env.DB_RW_HOST) {
    const envConfig = buildEnvConfig();
    if (envConfig) {
      try {
        await configurePool(envConfig);
        logger.info('reset complete — reconnected from env vars');
        return;
      } catch (err) {
        logger.error({ err }, 'Failed to configure DB pool from env var fallback');
      }
    }
  }

  _configSource = 'none';
  logger.info('pool reset — waiting for new configuration');
}

/**
 * Ensure the Public Integration API P2 scope indexes exist (best-effort).
 *
 * These back the /templates + /runs public read predicates — hierarchy FK
 * columns that were previously unindexed → full scans at customer scale. Fresh
 * installs get them inline in table-ddls.js; this adds them to existing DBs.
 *
 * INVARIANT (why this is NOT inside runSchemaMigrations): runSchemaMigrations
 * short-circuits at the top once platform_schema_version >= target, so anything
 * behind that gate runs at most once per version bump. A scope-index ALTER can
 * fail transiently (lock timeout, or an online-DDL edge case the engine cannot
 * honour). If this loop lived behind the version gate, a transiently-failed
 * index would stay missing until the NEXT PLATFORM_SCHEMA_VERSION bump. Running
 * it here — every boot, unconditionally, OUTSIDE the version gate — lets a
 * transient failure self-heal on the next boot. The version stamp is never
 * involved (this touches no skippedSteps counter).
 *
 * INVARIANT (degrade, never throw): a scope index is a PURE PERFORMANCE
 * optimization. A missing target table is a non-event (the index ships inline
 * with the table's CREATE DDL, so there is no deferred work), and an un-addable
 * index on an existing table degrades to a slower query, never a correctness
 * gap — it must NEVER surface as a 500 on a public read. Every branch is a
 * no-op/warn-continue; the loop never throws out. The caller in
 * ensureInfrastructure additionally wraps this in a defensive try/catch so an
 * unexpected exception can never abort boot.
 *
 * NOTE: the flow_recipe_runs (blueprint_id, created_at) composite serves the
 * predicate prefix only; the /runs keyset order wraps created_at in COALESCE
 * (NULL correctness) so the filtered subset still filesorts. Full fix =
 * created_at NOT NULL backfill, deferred to candidates.
 *
 * @param {import('mariadb').PoolConnection} conn
 */
async function _ensurePublicReadIndexes(conn) {
  const PUBLIC_READ_INDEXES = [
    { table: TABLES.FLOW_RECIPE_RUNS, name: 'idx_flow_recipe_runs_blueprint', def: '(blueprint_id, created_at)' },
    { table: TABLES.USER_TEMPLATES,   name: 'idx_user_templates_blueprint',   def: '(blueprint_id)' },
    { table: TABLES.USER_TEMPLATES,   name: 'idx_user_templates_category',    def: '(category_id)' },
    { table: TABLES.USER_TEMPLATES,   name: 'idx_user_templates_release',     def: '(release_id)' },
    { table: TABLES.USER_TEMPLATES,   name: 'idx_user_templates_variant',     def: '(variant_id)' },
  ];
  for (const { table, name, def } of PUBLIC_READ_INDEXES) {
    const logical = t(table);
    try {
      // Missing table → no-op (index ships with the table's CREATE DDL on fresh
      // installs); no deferred work.
      if (!(await tableExistsInCurrentSchema(conn, logical))) continue;
      const existing = await conn.query(
        `SELECT 1 FROM information_schema.STATISTICS
          WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND INDEX_NAME = ? LIMIT 1`,
        [logical, name],
      );
      if (existing.length) continue;
      // Index name is a fixed literal from PUBLIC_READ_INDEXES (never user input).
      // ALGORITHM=INPLACE, LOCK=NONE: build online so an execution-scale table is
      // not blocking-rebuilt; if the engine cannot honour it (unsupported edge
      // case) MariaDB errors loudly INTO the catch below → warn + slower query.
      await conn.query(
        `ALTER TABLE \`${logical}\` ADD INDEX \`${name}\` ${def}, ALGORITHM=INPLACE, LOCK=NONE`,
      );
      logger.info({ table: logical, index: name }, 'added public-read scope index');
    } catch (err) {
      // Optional optimization: warn-and-continue. Degrades to a slower query on
      // a no-ALTER DB; a transient failure (lock timeout) self-heals next boot
      // because this runs outside the version gate.
      logger.warn(
        { err, table: logical, index: name },
        'public-read scope index ADD skipped (slower query only); DBA may add it manually if operating without ALTER privileges',
      );
    }
  }
}

/**
 * Ensure integrity/repair scope indexes exist (best-effort).
 *
 * Shares every invariant with _ensurePublicReadIndexes — runs every boot,
 * OUTSIDE runSchemaMigrations' version gate (so a transient failure self-heals
 * next boot), touches no skippedSteps counter (never gates the schema-version
 * stamp), and degrades to a slower query rather than a boot-blocker (every
 * branch is a no-op/warn-continue; the loop never throws out).
 *
 * Backs the repair/dedup migrations + cascade/field-delete cleanup paths:
 *   - blueprint_fields(blueprint_id) — every dedup/repair pass + cascade delete
 *     resolves a blueprint's fields by blueprint_id.
 *   - variant_overrides(field_id) — the field-delete cleanup + orphan-sweep
 *     NOT EXISTS filter on field_id; the UNIQUE (variant_id, field_id, action)
 *     cannot serve a field-scoped lookup (field_id is not its leftmost column).
 *
 * @param {import('mariadb').PoolConnection} conn
 */
async function _ensureIntegrityIndexes(conn) {
  const INTEGRITY_INDEXES = [
    { table: TABLES.BLUEPRINT_FIELDS,  name: 'idx_blueprint_fields_blueprint', def: '(blueprint_id)' },
    { table: TABLES.VARIANT_OVERRIDES, name: 'idx_variant_overrides_field',    def: '(field_id)' },
  ];
  for (const { table, name, def } of INTEGRITY_INDEXES) {
    const logical = t(table);
    try {
      // Missing table → no-op (index ships with the table's CREATE DDL on fresh
      // installs); no deferred work.
      if (!(await tableExistsInCurrentSchema(conn, logical))) continue;
      const existing = await conn.query(
        `SELECT 1 FROM information_schema.STATISTICS
          WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND INDEX_NAME = ? LIMIT 1`,
        [logical, name],
      );
      if (existing.length) continue;
      // Index name is a fixed literal (never user input). ALGORITHM=INPLACE,
      // LOCK=NONE builds online; an engine that cannot honour it errors loudly
      // INTO the catch below → warn + slower query.
      await conn.query(
        `ALTER TABLE \`${logical}\` ADD INDEX \`${name}\` ${def}, ALGORITHM=INPLACE, LOCK=NONE`,
      );
      logger.info({ table: logical, index: name }, 'added integrity scope index');
    } catch (err) {
      logger.warn(
        { err, table: logical, index: name },
        'integrity scope index ADD skipped (slower query only); DBA may add it manually if operating without ALTER privileges',
      );
    }
  }
}

/**
 * Ensure infrastructure tables exist (uses the already-configured writer pool).
 *
 * @param {Object} [opts]
 * @param {'boot'|'reconfigure'} [opts.context='boot']
 *   'boot' — called from startup path. A preflight-grants failure emits a
 *            three-line ERROR/CAUSE/FIX banner to stderr and re-throws so
 *            the caller can `process.exit(1)`; the pod will then show
 *            the banner in `kubectl logs` before rolling into
 *            CrashLoopBackOff, which is strictly better than crashing
 *            on the first CREATE TABLE with `ER_DBACCESS_DENIED_ERROR`
 *            in a mariadb driver stack trace nobody can read.
 *   'reconfigure' — called from `configurePool` after a live-swap. A
 *            preflight failure throws without touching stderr so the
 *            reconfigure route can map the PreflightError to a 400.
 *            NOTE: superseded by the pre-swap probe in configurePool, which
 *            now calls with `{skipPreflight: true}` so this branch is no
 *            longer reached from the production path. Kept for future direct
 *            callers / tests that exercise the legacy
 *            preflight-inside-ensureInfrastructure flow.
 * @param {boolean} [opts.skipPreflight=false]
 *   When true, bypass the SHOW GRANTS + information_schema probe block and go
 *   straight to DDL + login_audit ENUM migration + runSchemaMigrations.
 *   configurePool sets this after running its pre-swap probe, so production
 *   never re-probes. The `context` arg is irrelevant when this is true
 *   (preflight is the only branch that reads context — banner emission lives
 *   there). Asserted below to prevent a future direct caller from passing both
 *   with intent to alter banner behaviour: the combination is silently
 *   consistent today (banner skipped because preflight skipped), but the assert
 *   makes the intent explicit.
 */
async function ensureInfrastructure(opts = {}) {
  // NOTE: configurePool runs preflight pre-swap, so its callers pass
  // skipPreflight=true to avoid duplicate SHOW GRANTS. Direct callers
  // (none in production but kept for tests / potential future uses) can
  // still trigger the full preflight+DDL sequence.
  const context = opts.context === 'reconfigure' ? 'reconfigure' : 'boot';
  const skipPreflight = opts.skipPreflight === true;
  // NOTE: skipPreflight bypasses the entire preflight + banner block, so
  // context becomes meaningless when both are set. Asserting here (rather than
  // silently ignoring) signals intent to any future caller that combines them —
  // they almost certainly mean to exercise the legacy preflight branch and
  // should drop skipPreflight.
  if (skipPreflight && opts.context === 'reconfigure') {
    throw new Error(
      'ensureInfrastructure: skipPreflight=true conflicts with context=reconfigure ' +
      '(banner only fires inside the preflight branch which skipPreflight bypasses). ' +
      'Drop one — see db.js JSDoc.',
    );
  }
  const conn = await _rwPool.getConnection();
  try {
    // NOTE: SHOW GRANTS + information_schema probe before any DDL converts a
    // later "CREATE command denied" crash into a pre-emptive structured error
    // the operator can act on. Skipped when configurePool already ran the probe.
    if (_configFull && !skipPreflight) {
      // NOTE: ensureInfrastructure runs after configurePool commits the swap,
      // so _tablePrefix is guaranteed non-null here. The `|| 'fmb_'` fallback
      // was removed to surface prefix-leak bugs early.
      const prefix = _tablePrefix;
      const prefixFn = (n) => `${prefix}${n}`;
      try {
        await assertPreflightOrThrow(
          conn,
          _configFull.database,
          INFRA_TABLE_NAMES,
          prefixFn,
          { user: _configFull.user, tablePrefix: prefix },
        );
      } catch (err) {
        if (err instanceof PreflightError && context === 'boot') {
          process.stderr.write(
            `ERROR: ${err.message}\n` +
              `CAUSE: ${prefix}* infrastructure tables cannot be read or written without the listed privileges\n` +
              `FIX:   ask the DBA to run (paste verbatim):\n${err.grantSqlHint || '  (no hint — grants probe failed; check user@host ACL)'}\n`,
          );
        }
        // Re-throw so the caller decides whether to exit(1) (boot) or
        // return a 400 (reconfigure). configurePool's ensureInfrastructure()
        // call wraps this in a catch that restores the previous pool on
        // reconfigure failure so no traffic routes through an under-privileged
        // swap.
        throw err;
      }
    }

    if (_configFull) {
      const prefix = _tablePrefix;
      try {
        await preflightDdlGrants(
          conn,
          _configFull.database,
          APP_TABLE_NAMES,
          (name) => `${prefix}${name}`,
          { user: _configFull.user, tablePrefix: prefix },
        );
      } catch (err) {
        if (err instanceof DdlPrivilegeError && context === 'boot') {
          // INVARIANT: operator-mode boot with no DDL privileges is a supported
          // deployment topology, but the gap MUST be visible to operators —
          // silent skip masked schema drift until users hit missing-column
          // runtime errors. Hence WARN, not INFO. Schema visibility is surfaced
          // via the admin schema-status endpoint.
          logger.warn(
            {
              user: _configFull.user,
              schema: _configFull.database,
              missingCreate: err.missingCreate,
              missingAlter: err.missingAlter,
            },
            '[ddl_preflight] schema migration skipped — operator account lacks DDL privileges; DBA must run pending ALTERs manually before relying on new columns. Live schema state is visible to admins at GET /api/platform/schema/status.',
          );
          return;
        }
        throw err;
      }
    }

    const ddls = buildInfraTablesDDL();
    for (const ddl of ddls) {
      await conn.query(ddl);
    }

    // NOTE: idempotent schema version migration. Reads
    // `platform_schema_version` from system_settings, applies any missing
    // ALTER TABLE statements, then bumps the version.
    // ddlPreflightAlreadyRun: the APP-table DDL-grants preflight above (this same
    // boot, same conn/prefix) already validated grants and returned early on
    // failure, so the migration runner must not repeat the identical SHOW GRANTS
    // probe. Callers reaching migrations without this preflight (init-db) omit
    // the flag and preflight themselves.
    await runSchemaMigrations(conn, { context, ddlPreflightAlreadyRun: true });

    // Public Integration API P2 scope indexes — runs UNCONDITIONALLY every boot,
    // OUTSIDE runSchemaMigrations' version gate (which short-circuits once the
    // version is stamped). This is what lets a transiently-failed index ALTER
    // (lock timeout etc.) self-heal on the next boot instead of staying missing
    // until the next PLATFORM_SCHEMA_VERSION bump. The loop is already
    // idempotent and never throws out, but wrap defensively so an unexpected
    // exception can never abort boot — a missing performance index is only a
    // slower query, never a boot-blocker.
    try {
      await _ensurePublicReadIndexes(conn);
    } catch (err) {
      logger.warn({ err: err && err.message }, 'public-read scope index ensure failed unexpectedly — continuing boot; retry next boot');
    }

    // Integrity/repair scope indexes — same every-boot, outside-version-gate,
    // degrade-never-throw contract as _ensurePublicReadIndexes. These back the
    // dedup/repair migrations + cascade/field-delete cleanup paths that resolve
    // fields by blueprint_id and overrides by field_id.
    try {
      await _ensureIntegrityIndexes(conn);
    } catch (err) {
      logger.warn({ err: err && err.message }, 'integrity scope index ensure failed unexpectedly — continuing boot; retry next boot');
    }

    logger.info({ count: ddls.length }, 'infrastructure tables ensured');
  } finally {
    conn.release();
  }
}

/**
 * Idempotent schema migration runner.
 *
 * Reads the current `platform_schema_version` from `system_settings`. If
 * it is below the target version, runs the migration steps in order and
 * bumps the version. Each step is wrapped in a pre-flight check against
 * `INFORMATION_SCHEMA.COLUMNS` so re-running is a no-op.
 *
 * Why this lives in the startup path (not behind an HTTP endpoint):
 *   - A `POST /api/setup/migrate-schema` endpoint would have to be guarded
 *     by `requireAdmin`, but the schema must also be valid during the very
 *     first POST that creates the admin user. Running
 *     it from `ensureInfrastructure` lets the same code path serve both
 *     fresh installs and existing deployments without an HTTP surface.
 *   - The migration is idempotent and side-effect-free when already
 *     applied, so booting `n` replicas in parallel converges safely.
 *
 * Migration history
 *   3.0.0  → seed marker for the very first installs (set on bootstrap)
 *   3.1.0  → no schema changes (k8s + CI work only)
 *   3.2.0  → optional number columns become NULLABLE; user_templates gains
 *            is_draft; feature_audit table appears
 *   3.2.32 → db_connections gains read_host / read_port / read_username /
 *            read_encrypted_password for the optional RW/RO topology.
 *   current → user_templates.name and blueprint_output_order.sort_order
 *            become NOT NULL after backfill.
 */
// Jumps 3.2.136 → 3.2.157 (the app versions in between were schema-neutral
// pure-FE releases): the schema stamp tracks the app version that introduced
// the change, not a contiguous counter.
// 3.2.200 → api_connectors gains group_id/group_label/group_mode/sequence
// 3.2.201 → Generation→Category EXPAND: user_templates.category_id added +
//   backfilled from generation_id; hierarchy_nodes.node_type ENUM widened to
//   the 5-value superset (category added) + backfilled generation→category.
//   Both old columns/literals retained until the later CONTRACT release.
// 3.2.341 → Generation→Category CONTRACT: self-guarded drop of
//   user_templates.generation_id + narrow of hierarchy_nodes.node_type back to
//   the 4-value category-only ENUM. The irreversible DDLs run only when the
//   data is provably clean (see migrateGenerationToCategoryContract).
// 3.2.421 → Data-entry color groups: new blueprint_groups engine table +
//   additive nullable columns blueprint_sections.layout_mode and
//   blueprint_fields.group_key.
// 3.2.424 → Data-entry color groups PR-3: additive nullable column
//   blueprint_fields.matrix_row_key (must bump so the guarded ALTER runs on DBs
//   already stamped at 3.2.421).
// 3.2.428 → Color-groups integrity batch: UNIQUE KEY on blueprint_groups
//   (blueprint_id, group_key) with a preceding dedup step (keep lowest id).
//   Must bump so the guarded dedup+ALTER runs on DBs already stamped at 3.2.424.
// 3.2.452 → Backend integrity closeout: UNIQUE KEY on blueprint_sections
//   (blueprint_id, section_key) with a preceding dedup step (keep lowest id),
//   mirroring the blueprint_groups pattern. Must bump so the guarded dedup+ALTER
//   runs on DBs already stamped at 3.2.428.
// (3.2.453 was an app-only a11y release with no schema change — the schema
//   stamp skips it, tracking the app version that introduced the change.)
// 3.2.454 → blueprint_groups dedup gains the (a0) forward canonicalization
//   (repoint blueprint_fields.group_key + .matrix_row_key onto the survivor
//   spelling before the loser row is deleted) + a one-time repair for DBs already
//   damaged by the 3.2.428 dedup (which lacked (a0), orphaning those refs). Must
//   bump so the version-gated repair runs once on DBs stamped at 3.2.428–3.2.453.
//   (package.json / CHANGELOG bumped at ship time — version-sync-check gates that
//   pairing there, not this schema stamp.)
// 3.2.513 → Capacity Planner config-rewrite table set (spec §17.1): cap_sizing_tiers
//   dropped + 7 new tables (cap_disk_combos/cap_teams/cap_databases/
//   cap_custom_groups/cap_custom_group_members/cap_bundles/cap_bundle_items) +
//   reshaped cap_vm_profiles/cap_vms/cap_db_instances/cap_rules/cap_field_defs/
//   cap_settings/cap_hardware_specs. Must bump so the version-gated capacity CREATE
//   loop re-fires on the wiped zone-test DB (Step 0.5) and creates the new schema
//   fresh. STRICTLY GREATER than the prior stamp 3.2.497 (the wipe leaves the old
//   stamp in place). Realign to the final R1 ship version if it lands above 3.2.513.
// 3.2.520 → Capacity schema hardening (stamp RETAINED, migration REMOVED at
//   3.2.541). This stamp originally gated two runtime ALTER backstops that added
//   uq_cap_cgm_vm/uq_cap_cgm_instance on cap_custom_group_members and
//   uq_cap_bundles_serial on cap_bundles. Per the no-migration ruling (Capacity
// stays migration-free until internal deploy) those ALTER backstops
//   were removed from runSchemaMigrations; the three UNIQUE constraints are now
//   carried by the fresh-install DDL only (table-ddls.js), so new deployments keep
//   the guard and the write-path 1062→409 mapping still holds. The stamp is NOT
//   lowered — DBs already at 3.2.520 must not regress — but it no longer drives any
//   capacity ALTER. Auto-column-fill / index-add-on-existing-DB deferred to
// internal-deploy time.
// PLATFORM_SCHEMA_VERSION is imported from ./migration-steps near the top of this
// file (single source of truth alongside the declarative registry).

// ── Schema migrations (extracted to ./migrations.js) ───────────────
// The migration logic moved verbatim into a lazy factory in ./migrations.js
// (which MUST NOT require db.js — no cycle). db.js owns the state; each symbol
// below is a thin wrapper that instantiates the factory per call with the
// CURRENT live deps via _migrationDeps(), so reassigned state (_configFull,
// _tablePrefix) is read fresh at call time and never captured stale at module
// load. Per-call instantiation is cheap (migrations run once at boot) and keeps
// _internalsForTest._redactAuditTableNames resolving against the current prefix.
function _migrationDeps() {
  return { t, PLATFORM_SCHEMA_VERSION, _configFull, _tablePrefix, APP_TABLE_NAMES };
}
const runSchemaMigrations = (...args) => createMigrationsModule(_migrationDeps()).runSchemaMigrations(...args);
const _redactAuditTableNames = (...args) => createMigrationsModule(_migrationDeps())._redactAuditTableNames(...args);


/**
 * Called once at startup from index.js / index-edge.js.
 *
 * NOTE: `SKIP_DB_INIT=1` bypasses both file/env config loading and pool.rw
 * creation, returning immediately. This is strictly for Ship Gate
 * docker-role-boot-smoke.sh so the 3-role boot test doesn't hang on MariaDB
 * connect retries when no DB is reachable from the smoke environment.
 * Production deployments must never set it — the check below throws
 * fail-fast when `NODE_ENV === 'production'`.
 */
async function initializeFromConfig() {
  if (process.env.SKIP_DB_INIT === '1') {
    // SECURITY: block production use. Without this guard a misconfigured
    // ConfigMap that leaks SKIP_DB_INIT from a smoke-env template would
    // silently boot edge without a DB pool, leaving all DB-dependent routes
    // to fail at first request rather than at boot.
    if (String(process.env.NODE_ENV || '').toLowerCase() === 'production') {
      const guardErr = new Error(
        'SKIP_DB_INIT=1 is not allowed in NODE_ENV=production. ' +
        'Remove this env var from the ConfigMap; it exists only for ' +
        'Ship Gate smoke tests.'
      );
      // INVARIANT: this is the ONLY rejection initializeFromConfig still emits —
      // every recoverable config problem degrades to a null pool below and
      // resolves. fatalBoot marks it non-recoverable so the boot guard crashes
      // the pod on it rather than degrading to setup-required, which would
      // silently defeat this production fail-fast.
      guardErr.fatalBoot = true;
      throw guardErr;
    }
    logger.warn('SKIP_DB_INIT=1 — bypassing DB pool init (Ship Gate smoke only; never set in production)');
    return;
  }
  let config;
  try {
    config = loadConfig();
  } catch (err) {
    // A synchronous throw while building config (defense-in-depth — the
    // buildEnvConfig degrade above already turns the known half-set-RO case into
    // a null return) must degrade to setup-required, NOT reject the boot promise
    // and crash-loop the pod. Stash the sanitised reason for /health.
    _lastConfigureError = sanitizeConfigureError(err);
    logger.error({ err }, 'Failed to load DB config at boot — starting in setup-required mode');
    return;
  }
  if (!config) {
    logger.info('no DB config found — waiting for frontend setup (POST /api/setup/configure-db)');
    return;
  }
  try {
    await configurePool(config);
  } catch (err) {
    // NOTE: stash sanitised failure so /health + pool-gate apiError can tell
    // admins why _rwPool is null. err.message NEVER reaches this state;
    // sanitizeConfigureError drops everything except code/errno/sqlState.
    _lastConfigureError = sanitizeConfigureError(err);
    logger.error({ err, source: config._source }, 'Failed to auto-configure DB pool source=' + config._source);

    if (config._source === 'file' && process.env.DB_RW_HOST) {
      logger.info('file config failed — falling back to env vars');
      try {
        if (fs.existsSync(CONFIG_PATH)) {
          fs.unlinkSync(CONFIG_PATH);
          logger.info('stale config file removed');
        }
        const envConfig = buildEnvConfig();
        if (!envConfig) throw new Error('DB_NAME not set');
        await configurePool(envConfig);
        logger.info('connected via env var fallback');
        return;
      } catch (err2) {
        _lastConfigureError = sanitizeConfigureError(err2);
        logger.error({ err: err2 }, 'Failed to configure DB pool from env var fallback (after file config also failed)');
      }
    }

    logger.info('started in setup-required mode — reconfigure via POST /api/setup/configure-db');
  }
}

/**
 * Activate a stored DB connection by ID.
 */
async function activateConnection(id) {
  const conn = await _rwPool.getConnection();
  let cfg;
  let connName;
  try {
    const rows = await conn.query(
      `SELECT name, host, port, username, encrypted_password, database_name,
              read_host, read_port, read_username, read_encrypted_password
         FROM \`${t(TABLES.DB_CONNECTIONS)}\`
        WHERE id = ?`,
      [id]
    );
    if (!rows.length) throw new Error(`Connection ${id} not found`);
    const row = rows[0];
    connName = row.name;

    cfg = {
      host: row.host,
      port: row.port || 3306,
      user: row.username,
      password: row.encrypted_password || '',
      database: row.database_name || '',
      tablePrefix: _tablePrefix,
    };

    if (row.read_host && row.read_port) {
      cfg.readHost = row.read_host;
      cfg.readPort = row.read_port;
      cfg.readUser = row.read_username || null;
      cfg.readPassword = row.read_encrypted_password || null;
    }
  } finally {
    conn.release();
  }

  await configurePool(cfg);
  logger.info(
    {
      name: connName,
      host: cfg.host,
      port: cfg.port,
      database: cfg.database,
      readEndpoint: cfg.readHost ? `${cfg.readHost}:${cfg.readPort}` : 'fallback-to-writer',
    },
    'activated connection'
  );
}

/** Shutdown all dynamic pools */
async function shutdown() {
  await shutdownDynamicPools();
  if (_rwPool) { try { await _rwPool.end(); } catch {} }
  if (_roPool) { try { await _roPool.end(); } catch {} }
}

module.exports = {
  pool,
  t,
  isPoolReady,
  getPoolDiagnostic,
  getConfiguredPoolStrictWrites,
  getDbConfig,
  getDbConfigFull,
  setConfigSource,
  configurePool,
  saveConfig,
  loadConfig,
  resetConfig,
  initializeFromConfig,
  activateConnection,
  getDynamicPool,
  cleanupIdlePools,
  shutdown,
  runSchemaMigrations,
  PLATFORM_SCHEMA_VERSION,
  // NOTE: re-exported so callers can distinguish the structured preflight
  // rejection from generic connection errors (e.g. /configure-db route maps
  // this to a 400 with grantSqlHint body).
  PreflightError,
  // NOTE: re-exported pool-state error classes so HTTP handlers and tests
  // can branch on `err.code` instead of regex-matching.
  PoolNotConfiguredError,
  MigrationError,
  // Exported for unit tests
  assertReadConfig,
  buildEnvConfig,
  ensureInfrastructure,
  _connectWithRetry,
  // Path-parameterised save/load cores — the configPath seam lives here, off
  // the public saveConfig/loadConfig signatures, so only tests can target a
  // temp file.
  _internalsForTest: {
    _saveConfigToPath,
    _loadConfigFromPath,
    CONFIG_PATH,
    _poolOpts,
    _redactAuditTableNames,
  },
};
