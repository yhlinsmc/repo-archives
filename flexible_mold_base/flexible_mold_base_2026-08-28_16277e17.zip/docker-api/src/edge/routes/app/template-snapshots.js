'use strict';

/**
 * template-snapshots.js — fmb_template_snapshots mount (U10).
 *
 *   GET    /:templateId/snapshots              list, newest first
 *   POST   /:templateId/snapshots               save the CALLER-SUPPLIED form
 *                                                 state as a new named snapshot
 *   DELETE /:templateId/snapshots/:snapshotId    delete one snapshot
 *
 * WHY THIS IS NOT A RUN. A snapshot is a manual, unexecuted checkpoint of the
 * form's own values — dispatch, `flow_recipe_runs`, and the flow engine are
 * never touched by any route below. Restoring a snapshot into the live form is
 * entirely a client-side act (the client already holds the snapshot document
 * once it has read it back from GET) — there is no server-side "restore"
 * endpoint, because restoring writes nothing durable until the operator saves
 * the template through the ordinary save route, same as typing over a field.
 *
 * WHO MAY READ AND WRITE. Same rule as `template-activity.js`'s trail: the
 * record's owner, anyone they delegated to, and an administrator. Unlike the
 * trail, a snapshot can hold the form's answers verbatim, so — unlike the
 * trail's public dispatch-history baseline — there is no wider public read
 * here at all; every route is gated by the same caller check.
 *
 * UNLIKE `cap_versions`, THE SNAPSHOT BODY IS CLIENT-SUPPLIED, NOT SERVER-
 * COMPUTED. A capacity version freezes rows the server can already read; a
 * data-entry snapshot freezes the LIVE, UNSAVED draft sitting in the
 * operator's browser, which the server has no other way to see. The body is
 * still bounded (MAX_SNAPSHOT_BYTES) so an unbounded client payload cannot
 * grow the table without limit.
 */
const router = require('express').Router();
const { pool, t } = require('../../db');
const {
  apiOk, apiError, requireAuth, uuidv4, UUID_RE,
} = require('../../../shared/helpers');
const { TABLES } = require('../../../shared/constants');
const { normalizeTimestamp } = require('../../lib/dto-mapper');
const { callerMayWriteTemplate } = require('../../lib/delegated-grants');
const { tableExistsInCurrentSchema } = require('../../lib/table-exists');
const { isKnownPresent, rememberPresent } = require('../../lib/table-presence-cache');
const { parsePageRequest } = require('./schema/list-query');
const { logger: rootLogger } = require('../../../shared/lib/logger');

const logger = rootLogger.child({ module: 'template-snapshots-route' });

// SECURITY: authentication for the whole router, so a route added later
// inherits it rather than having to remember it.
router.use((req, res, next) => { if (requireAuth(req, res)) next(); });

// M6 (review r1): the page a caller gets when they ask for no particular
// page — same `resolvePage`/`DEFAULT_PAGE_SIZE` contract
// `template-activity.js` uses, so this list (an operator's saved checkpoints
// on ONE record, not the whole table, but still unbounded before this fix)
// cannot grow into an unbounded response. The FE picker renders a flat list,
// not a pager, so the size is chosen generously (50) rather than paged.
const DEFAULT_PAGE_SIZE = 50;

const MAX_NAME = 255;
const MAX_NOTE = 10000;
// The snapshot document is client-supplied (see module doc) and LONGTEXT has
// no MariaDB-side cap worth relying on; this is a generous multiple of what a
// real form document measures (the flow-run inspection unit's own JSON-diff guard rail uses the
// same "generous multiple of a measured baseline" reasoning), not a tight fit.
const MAX_SNAPSHOT_BYTES = 2 * 1024 * 1024;

const dbError = (res) => {
  const e = apiError('Database operation failed', 'INTERNAL_ERROR', 500);
  res.status(e.status).json(e.body);
};
const notFound = (res, message = 'Not found') => {
  const e = apiError(message, 'NOT_FOUND', 404);
  res.status(e.status).json(e.body);
};
const badRequest = (res, message) => {
  const e = apiError(message, 'BAD_REQUEST', 400);
  res.status(e.status).json(e.body);
};

/**
 * May this caller read and write this record's snapshots?
 *
 * Reuses `callerMayWriteTemplate` — the SAME rule the template's own write
 * path enforces (ownership, a grant, ownership of the blueprint, or being an
 * administrator) — rather than restating it, so this route cannot drift from
 * what "may edit this record" already means everywhere else. A snapshot can
 * hold the form's answers verbatim, so — unlike `template-activity.js`'s
 * trail, which has a public dispatch-history baseline — there is no wider
 * public read here at all: every route below is gated by this same check.
 */
async function callerMaySeeSnapshots(conn, user, templateId) {
  const rows = await conn.query(
    `SELECT id, owner_id, blueprint_id FROM \`${t(TABLES.USER_TEMPLATES)}\` WHERE id = ?`,
    [templateId],
  );
  if (!rows.length) return false;
  return callerMayWriteTemplate(conn, user, rows[0]);
}

/**
 * Is the snapshots table there to be read or written? The 3.2.856 CREATE is
 * severity 'warning' (an operator account without DDL privilege may never
 * run it), so the table can be legitimately absent while the rest of the app
 * boots and runs fine. Only the positive is remembered, and it is remembered
 * per DATABASE — both properties, and the reasons for them, live in
 * `table-presence-cache.js` (the same cache `delegated-grants.js`'s
 * `grantsTableAvailable` and `template-activity.js`'s `activityTableAvailable`
 * use for their own optional tables).
 */
async function snapshotsTableAvailable(conn) {
  const physical = t(TABLES.TEMPLATE_SNAPSHOTS);
  if (isKnownPresent(conn, physical)) return true;
  try {
    const present = await tableExistsInCurrentSchema(conn, physical);
    if (present) rememberPresent(conn, physical);
    return present;
  } catch (err) {
    logger.warn({ err }, 'could not probe for the template snapshots table — snapshots are reported unavailable');
    return false;
  }
}

/**
 * Refuses the write in progress and writes the response itself when the
 * table is not there — same contract `delegated-grants.js`'s
 * `requireGrantsTable` uses, so a caller need only check the return value.
 */
async function requireSnapshotsTable(conn, res) {
  if (await snapshotsTableAvailable(conn)) return true;
  const e = apiError(
    'Snapshots are not available on this database schema: the snapshots table has not been created. '
    + 'An administrator can see the outstanding schema steps under schema status.',
    'SNAPSHOTS_UNAVAILABLE', 503,
  );
  res.status(e.status).json(e.body);
  return false;
}

const LIST_COLUMNS = 'id, template_id, name, note, blueprint_id, variant_id, snapshot, actor_id, created_at';

/** Same shape `template-activity.js`'s own `resolvePage` returns — a
 *  request with no page bound gets the first (bounded) page rather than
 *  everything, an explicit `limit`/`offset` is validated (and a
 *  too-large `limit` is REJECTED — `parsePageRequest`'s own contract, not
 *  silently clamped) before it can reach the driver. */
function resolvePage(query) {
  const q = query || {};
  if (q.offset === undefined && q.limit === undefined) {
    return { paginated: true, limit: DEFAULT_PAGE_SIZE, offset: 0 };
  }
  return parsePageRequest({ ...q, offset: q.offset === undefined ? '0' : q.offset });
}

function presentRow(row) {
  if (!row) return row;
  let snapshot = row.snapshot;
  // The driver may hand back the JSON-shaped LONGTEXT column as a string or
  // (depending on driver settings) an already-parsed value; hand the caller a
  // parsed document either way, same convention `capacity/versions.js` reads
  // its own snapshot column through.
  if (typeof snapshot === 'string') {
    try { snapshot = JSON.parse(snapshot); } catch { /* leave raw — a corrupt row still lists */ }
  }
  return {
    id: row.id,
    template_id: row.template_id,
    name: row.name,
    note: row.note ?? null,
    blueprint_id: row.blueprint_id ?? null,
    variant_id: row.variant_id ?? null,
    snapshot,
    actor_id: row.actor_id ?? null,
    created_at: normalizeTimestamp(row.created_at),
  };
}

/**
 * @openapi
 * /edge/app/templates/{templateId}/snapshots:
 *   get:
 *     tags: [App - Template Snapshots]
 *     summary: List a record's saved snapshots, newest first (owner/delegate/admin).
 *     parameters:
 *       - { name: templateId, in: path, required: true, schema: { type: string } }
 *     responses:
 *       200: { description: "Snapshot list — `{ items, unavailable }`; `items` is empty and `unavailable` is true on a schema where the table was never created" }
 *       404: { description: No such record, or not the caller's to see }
 *   post:
 *     tags: [App - Template Snapshots]
 *     summary: Save the caller-supplied form state as a new named snapshot (owner/delegate/admin).
 *     description: >
 *       Never dispatches anything and never writes flow_recipe_runs — a
 *       snapshot is a checkpoint of the form's own values, not an execution.
 *     responses:
 *       201: { description: Created snapshot }
 *       400: { description: name missing/too long, note too long, or snapshot document too large }
 *       404: { description: No such record, or not the caller's to write }
 *       503: { description: The snapshots table has not been created on this schema }
 * /edge/app/templates/{templateId}/snapshots/{snapshotId}:
 *   delete:
 *     tags: [App - Template Snapshots]
 *     summary: Delete one snapshot (owner/delegate/admin).
 *     responses:
 *       200: { description: Deleted }
 *       404: { description: No such record/snapshot, or not the caller's to delete }
 *       503: { description: The snapshots table has not been created on this schema }
 */
router.get('/:templateId/snapshots', async (req, res) => {
  const templateId = String(req.params.templateId);
  if (!UUID_RE.test(templateId)) return notFound(res);
  const page = resolvePage(req.query);
  if (page.error) {
    const e = apiError(page.error.message, page.error.code, 400);
    return res.status(e.status).json(e.body);
  }
  let conn;
  try {
    conn = await pool.ro.getConnection();
    if (!(await callerMaySeeSnapshots(conn, req.user, templateId))) return notFound(res);
    // A database whose operator account could not create the table has no
    // snapshots. An empty list is the truth there — `unavailable` is what
    // tells the caller (and the FE picker) that apart from "nothing saved
    // yet", same distinction `template-activity.js`'s own `available` flag
    // draws for its trail.
    if (!(await snapshotsTableAvailable(conn))) {
      return res.json(apiOk({
        items: [],
        unavailable: true,
        reason: 'Snapshots are not available on this database schema: the snapshots table has not been created.',
      }));
    }
    const rows = await conn.query(
      `SELECT ${LIST_COLUMNS} FROM \`${t(TABLES.TEMPLATE_SNAPSHOTS)}\`
        WHERE template_id = ? ORDER BY created_at DESC, id DESC
        LIMIT ? OFFSET ?`,
      [templateId, page.limit, page.offset],
    );
    return res.json(apiOk({ items: rows.map(presentRow), unavailable: false }));
  } catch (err) {
    logger.error({ err, templateId }, 'Failed to list template snapshots');
    return dbError(res);
  } finally {
    if (conn) conn.release();
  }
});

router.post('/:templateId/snapshots', async (req, res) => {
  const templateId = String(req.params.templateId);
  if (!UUID_RE.test(templateId)) return notFound(res);
  const body = req.body && typeof req.body === 'object' ? req.body : {};

  const name = typeof body.name === 'string' ? body.name.trim() : '';
  if (!name) return badRequest(res, 'name is required');
  if (name.length > MAX_NAME) return badRequest(res, `name exceeds ${MAX_NAME} characters`);

  const note = body.note ?? null;
  if (note !== null && (typeof note !== 'string' || note.length > MAX_NOTE)) {
    return badRequest(res, `note must be a string up to ${MAX_NOTE} characters`);
  }

  // The snapshot body is the one thing this route trusts the client for (see
  // module doc) — still shape-checked (a plain object, not an array/scalar)
  // and size-bounded, never executed and never read back into anything but
  // this row.
  const snapshotDoc = body.snapshot;
  if (snapshotDoc === undefined || snapshotDoc === null || typeof snapshotDoc !== 'object' || Array.isArray(snapshotDoc)) {
    return badRequest(res, 'snapshot must be an object');
  }
  const serialized = JSON.stringify(snapshotDoc);
  if (Buffer.byteLength(serialized, 'utf8') > MAX_SNAPSHOT_BYTES) {
    return badRequest(res, 'snapshot document is too large to save');
  }

  const blueprintId = typeof body.blueprint_id === 'string' && body.blueprint_id ? body.blueprint_id : null;
  const variantId = typeof body.variant_id === 'string' && body.variant_id ? body.variant_id : null;

  let conn;
  try {
    conn = await pool.rw.getConnection();
    if (!(await callerMaySeeSnapshots(conn, req.user, templateId))) return notFound(res);
    if (!(await requireSnapshotsTable(conn, res))) return undefined;

    const id = uuidv4();
    // SECURITY: the actor is the sole authority on who saved this — a
    // client-supplied actor_id is never trusted.
    const actorId = req.user && req.user.id ? req.user.id : null;
    await conn.query(
      `INSERT INTO \`${t(TABLES.TEMPLATE_SNAPSHOTS)}\`
         (id, template_id, name, note, blueprint_id, variant_id, snapshot, actor_id)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [id, templateId, name, note, blueprintId, variantId, serialized, actorId],
    );
    const rows = await conn.query(
      `SELECT ${LIST_COLUMNS} FROM \`${t(TABLES.TEMPLATE_SNAPSHOTS)}\` WHERE id = ?`,
      [id],
    );
    return res.status(201).json(apiOk(presentRow(rows[0]) ?? {
      id, template_id: templateId, name, note, blueprint_id: blueprintId, variant_id: variantId,
      snapshot: snapshotDoc, actor_id: actorId, created_at: null,
    }));
  } catch (err) {
    logger.error({ err, templateId }, 'Failed to save a template snapshot');
    return dbError(res);
  } finally {
    if (conn) conn.release();
  }
});

router.delete('/:templateId/snapshots/:snapshotId', async (req, res) => {
  const templateId = String(req.params.templateId);
  const snapshotId = String(req.params.snapshotId);
  if (!UUID_RE.test(templateId) || !UUID_RE.test(snapshotId)) return notFound(res);

  let conn;
  try {
    conn = await pool.rw.getConnection();
    if (!(await callerMaySeeSnapshots(conn, req.user, templateId))) return notFound(res);
    if (!(await requireSnapshotsTable(conn, res))) return undefined;

    const existing = await conn.query(
      `SELECT id FROM \`${t(TABLES.TEMPLATE_SNAPSHOTS)}\` WHERE id = ? AND template_id = ? FOR UPDATE`,
      [snapshotId, templateId],
    );
    if (!existing.length) return notFound(res, 'Snapshot not found');

    await conn.query(
      `DELETE FROM \`${t(TABLES.TEMPLATE_SNAPSHOTS)}\` WHERE id = ? AND template_id = ?`,
      [snapshotId, templateId],
    );
    return res.json(apiOk({ id: snapshotId, deleted: true }));
  } catch (err) {
    logger.error({ err, templateId, snapshotId }, 'Failed to delete a template snapshot');
    return dbError(res);
  } finally {
    if (conn) conn.release();
  }
});

module.exports = router;
module.exports.__test__ = {
  callerMaySeeSnapshots, presentRow, MAX_SNAPSHOT_BYTES, resolvePage, DEFAULT_PAGE_SIZE, snapshotsTableAvailable,
};
