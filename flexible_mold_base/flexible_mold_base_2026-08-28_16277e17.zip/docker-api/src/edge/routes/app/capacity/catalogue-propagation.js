/**
 * @openapi
 * /edge/app/capacity/config/{group}/propagation-preview:
 *   get:
 *     tags: [App - Capacity]
 *     summary: Detect scenarios whose VMs carry a stale sizing snapshot of a GLOBAL catalogue row (admin+editor).
 *     parameters:
 *       - { name: group, in: path, required: true, schema: { type: string, enum: [hardware_specs, disk_combos, teams, vm_profiles] } }
 *     responses:
 *       200: { description: Affected-scenario rows, empty when the group carries no local sizing copy or nothing has drifted }
 * /edge/app/capacity/config/{group}/propagation-apply:
 *   post:
 *     tags: [App - Capacity]
 *     summary: Batch-apply the current GLOBAL catalogue values onto the selected scenarios' drifted VMs (admin+editor; per-scenario owner+admin).
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [scenarioIds]
 *             properties:
 *               scenarioIds: { type: array, items: { type: string } }
 *     responses:
 *       200: { description: Per-scenario apply results (never fails the whole batch for one scenario's outcome) }
 */

/**
 * capacity/catalogue-propagation.js — E4 (spec §7 E4 / Q12): a scenario's VMs
 * carry cpu/mem_gb (from a GLOBAL `cap_vm_profiles` row) or disk_gb (from a
 * GLOBAL `cap_disk_combos` row) as a PREFILL-ONLY snapshot, taken once at
 * create time (wizard.js / database-bulk-create.js `deriveVmSizing`) and never
 * re-derived afterwards — children.js's own comment calls this out explicitly
 * ("vm_profile delete → cap_vms.sizing_profile_id = NULL (profile = prefill-only)").
 * Editing the global row therefore leaves every already-created VM showing its
 * OLD sizing (the KVMs grid even locks the cell with a "From profile X" hint
 * while displaying the stale stored value — capacity-field-defs.ts
 * `kvmProfileLockPolicy`). This mount finds those VMs and, on confirm, batch-
 * rewrites their stored cpu/mem_gb (or disk_gb) to match the CURRENT global
 * row. Nothing downstream needs a second sync engine: every reader of
 * cap_vms.cpu/mem_gb/disk_gb (evaluator.js, exports, the grid itself) already
 * reads the stored column, so writing it is the whole propagation.
 *
 * `hardware_specs` is deliberately NOT propagated: cap_hypervisors carries no
 * materialized copy of a spec's cpu_total/mem_total_gb/disk_total_gb — the
 * evaluator joins `specById.get(hv.spec_id)` LIVE (evaluator.js `usableForSpec`)
 * on every read, so a global hardware-spec edit is already visible everywhere
 * with nothing to detect or apply. `propagation-preview` answers `{ scenarios: [] }`
 * for it rather than 400ing, so a caller that wires the trigger uniformly for
 * all three catalogue kinds gets a harmless empty result instead of a special
 * case to branch on.
 *
 * Auth: both routes are admin+editor (only that tier reaches the global config
 * page that triggers this dialog — `childWriteRoleGate`'s tier). `apply`
 * ADDITIONALLY re-checks per-scenario write access (`resolveScenarioWriteAccess`,
 * owner+admin) inside each scenario's own transaction: a batch may cross many
 * scenarios the caller does not own, and one scenario's 403 must not sink the
 * rest — see the per-scenario result loop below (partial-failure semantics).
 *
 * Every write re-derives from the CURRENT database state inside its own
 * scenario-locked transaction — the request body never carries a value to
 * trust, only which scenarios to look at. This is CONVERGENCE-TO-CURRENT, not
 * "replay the preview's new column": if nothing has changed since preview,
 * apply finds nothing left to do (`applied: 0`); if the global catalogue row
 * changes AGAIN between preview and confirm (a third edit, by anyone), apply
 * writes THAT newest value — always the correct convergent result, but a
 * value that matches neither the "old" nor the "new" the user saw in the
 * dialog. There is no way to write a stale or wrong number, but the dialog's
 * own diff columns are a snapshot, not a promise of what gets written.
 */
const express = require('express');
const { pool, t } = require('../../../db');
const { requireAdminOrEditor, apiOk, apiError } = require('../../../../shared/helpers');
const { logger } = require('../../../../shared/lib/logger');
const { TABLES } = require('../../../../shared/constants');
const {
  DEFAULT_FORMULA, readFormulaConstants, resolveProfileSizing, sumDiskComboSizes,
  resolveScenarioWriteAccess, safeRollback,
} = require('./_shared');

// Upper bound on one apply batch's scenarioIds — mirrors catalogue-reorder.js's
// MAX_CATALOGUE_REORDER_ROWS guard (a legal "every affected scenario" selection
// must never be able to exceed this, but an unbounded/forged body must not
// walk an unbounded loop of transactions either).
const MAX_PROPAGATION_SCENARIOS = 2000;

// F4 (review round 1, adv LOW — closes A.1's own rationale): a
// LENGTH check alone still let a JUNK-ONLY array (e.g. `['bad']`, no finite
// numeric entry) through as "has sizes" — `sumDiskComboSizes` then reduces it
// to 0 exactly the same way it reduces a TRULY empty array to 0, so a combo
// full of junk was the SAME drift-to-0 hole this guard exists to close, via a
// different empty-CANDIDATE shape. "Has sizes" now means "has at least one
// element `sumDiskComboSizes` would actually SUM" — same parse tolerance
// (string-encoded JSON), same `Number()`/`Number.isFinite` coercion for a
// counted element, DELIBERATELY excluding `null`/`undefined`/`''` before that
// coercion even though `Number(null) === 0` is itself finite: that 0 is a
// coercion ARTIFACT of the value's absence, not a size anyone authored, and
// counting it would silently readmit the exact "empty candidate reads as a
// real 0" bug one guard up.
function diskComboHasSizes(sizesRaw) {
  let sizes = sizesRaw;
  if (typeof sizes === 'string') {
    try { sizes = JSON.parse(sizes); } catch { return false; }
  }
  if (!Array.isArray(sizes)) return false;
  return sizes.some((v) => {
    if (v === null || v === undefined || v === '') return false;
    const n = typeof v === 'number' ? v : Number(v);
    return Number.isFinite(n);
  });
}

// ── Pure detection (no DB) ──────────────────────────────────────────────────

/**
 * One VM's stale cpu or mem_gb against its GLOBAL profile's CURRENT sizing.
 * `vmRows`: [{ id, scenario_id, name, cpu, mem_gb, sizing_profile_id }].
 * `profileById`: Map<id, { id, name, class, mode, cpu, mem_gb, sga_cap_gb }>
 *   (GLOBAL rows only — the caller is responsible for that scope).
 * `formulaByScenario`: Map<scenarioId, formula constants> (scenario-effective —
 *   a formula-mode profile's derived mem_gb depends on the READING scenario's
 *   own sga/mem-ratio settings, not just the profile).
 * Pure and DB-free: every field is already-fetched plain data.
 */
function detectVmProfileDrift(vmRows, profileById, formulaByScenario) {
  const drift = [];
  for (const vm of vmRows) {
    const profile = profileById.get(String(vm.sizing_profile_id));
    if (!profile) continue; // dangling/removed ref — not this feature's concern
    const formula = formulaByScenario.get(String(vm.scenario_id)) || DEFAULT_FORMULA;
    const sizing = resolveProfileSizing(profile, formula);
    if (!sizing) continue;
    const storedCpu = Number(vm.cpu);
    const storedMem = Number(vm.mem_gb);
    if (storedCpu !== sizing.cpu) {
      drift.push({
        scenarioId: String(vm.scenario_id), vmId: vm.id, vmName: vm.name,
        catalogueId: profile.id, catalogueName: profile.name,
        field: 'cpu', oldValue: storedCpu, newValue: sizing.cpu,
      });
    }
    if (storedMem !== sizing.memGb) {
      drift.push({
        scenarioId: String(vm.scenario_id), vmId: vm.id, vmName: vm.name,
        catalogueId: profile.id, catalogueName: profile.name,
        field: 'mem_gb', oldValue: storedMem, newValue: sizing.memGb,
      });
    }
  }
  return drift;
}

/**
 * One VM's stale disk_gb against its GLOBAL disk combo's CURRENT summed sizes.
 * `vmRows`: [{ id, scenario_id, name, disk_gb, disk_combo_id }].
 * `comboById`: Map<id, { id, name, sizes }> (GLOBAL rows only).
 *
 * Unlike cpu/mem_gb, disk_gb is NOT grid-locked while a combo is chosen
 * (capacity-field-defs.ts leaves it a plain editable `number` column — spec
 * §3.1.6, "profiles have no disk association" at the FE prefill-lock level) —
 * a user may have deliberately hand-edited it independent of the combo. This
 * function still flags it as drift (the stored value no longer matches the
 * combo it references), because that is the same "local copy fell behind the
 * catalogue" condition Q12 targets; the checkbox select in the dialog is where
 * the user keeps or discards that override per scenario, not here.
 *
 * A combo whose `sizes` array is EMPTY (no disks configured on the global row,
 * a legal intermediate authoring state — e.g. every size just removed but the
 * combo not yet re-populated or deleted) is an EMPTY CANDIDATE SET, not "the
 * true size is 0" — the same "empty allow-list = unrestricted, never the
 * narrowest possible restriction" semantics established for a
 * different empty-array field. Treating it as a real 0 would flag every VM
 * referencing that combo as drifted and, on apply, silently shrink its stored
 * disk_gb to 0 — a destructive rewrite from a transient authoring gap, not
 * from any global value someone actually set. So this row is a no-op: skipped
 * before the sum, regardless of what disk_gb currently holds.
 */
function detectDiskComboDrift(vmRows, comboById) {
  const drift = [];
  for (const vm of vmRows) {
    const combo = comboById.get(String(vm.disk_combo_id));
    if (!combo) continue;
    if (!diskComboHasSizes(combo.sizes)) continue;
    const newDisk = sumDiskComboSizes(combo.sizes);
    const storedDisk = Number(vm.disk_gb);
    if (storedDisk !== newDisk) {
      drift.push({
        scenarioId: String(vm.scenario_id), vmId: vm.id, vmName: vm.name,
        catalogueId: combo.id, catalogueName: combo.name,
        field: 'disk_gb', oldValue: storedDisk, newValue: newDisk,
      });
    }
  }
  return drift;
}

/**
 * Fold a flat drift list (one entry per VM per changed field) into ONE row per
 * scenario (Q12: "scenario-level granularity") — the dialog's grid contract
 * (spec §7 E4 item 2). Items are deduped by (catalogue row, field, old→new) so
 * "40 VMs on the same profile, same old value" renders as one diff line with a
 * count, not 40 identical rows; a scenario with a genuinely mixed old value
 * (a hand-edited outlier before this feature existed) gets a second line for
 * that field rather than silently merging into the majority's number.
 */
function groupDriftByScenario(drift, scenarioNameById) {
  const byScenario = new Map();
  for (const d of drift) {
    let entry = byScenario.get(d.scenarioId);
    if (!entry) {
      entry = {
        scenarioId: d.scenarioId,
        scenarioName: scenarioNameById.get(d.scenarioId) ?? d.scenarioId,
        vmIds: new Set(),
        items: new Map(),
      };
      byScenario.set(d.scenarioId, entry);
    }
    entry.vmIds.add(d.vmId);
    const itemKey = `${d.catalogueId}|${d.field}|${d.oldValue}|${d.newValue}`;
    let item = entry.items.get(itemKey);
    if (!item) {
      item = {
        catalogueId: d.catalogueId, catalogueName: d.catalogueName,
        field: d.field, oldValue: d.oldValue, newValue: d.newValue, vmCount: 0,
      };
      entry.items.set(itemKey, item);
    }
    item.vmCount += 1;
  }
  return [...byScenario.values()]
    .map((e) => ({
      scenarioId: e.scenarioId, scenarioName: e.scenarioName,
      vmCount: e.vmIds.size, items: [...e.items.values()],
    }))
    // Stable, readable order — the FE grid re-sorts on user request, but the
    // first paint should not depend on SQL row order across two joined tables.
    .sort((a, b) => a.scenarioName.localeCompare(b.scenarioName));
}

// ── Group → table wiring ────────────────────────────────────────────────────

const PROPAGATABLE_GROUPS = new Set(['vm_profiles', 'disk_combos']);

async function loadScenarioNames(dbHandle, scenarioIds) {
  if (scenarioIds.length === 0) return new Map();
  const rows = await dbHandle.query(
    `SELECT id, name FROM \`${t(TABLES.CAP_SCENARIOS)}\` WHERE id IN (${scenarioIds.map(() => '?').join(',')})`,
    scenarioIds,
  );
  return new Map(rows.map((r) => [String(r.id), r.name]));
}

async function loadFormulaByScenario(dbHandle, scenarioIds) {
  if (scenarioIds.length === 0) return new Map();
  const rows = await dbHandle.query(
    `SELECT * FROM \`${t(TABLES.CAP_SETTINGS)}\` WHERE scenario_id IN (${scenarioIds.map(() => '?').join(',')}) OR scenario_id IS NULL`,
    scenarioIds,
  );
  // scenario-effective: the scenario's OWN override row wins over the global
  // (scenario_id NULL) seed — same resolution `loadScenarioEffectiveSettings`
  // (children.js) applies per-scenario, folded here across every scenario in
  // one query since the preview spans all of them.
  const globalRow = rows.find((r) => r.scenario_id === null) || null;
  const byScenario = new Map();
  for (const id of scenarioIds) {
    const own = rows.find((r) => String(r.scenario_id) === id);
    byScenario.set(id, readFormulaConstants(own || globalRow));
  }
  return byScenario;
}

async function previewVmProfileDrift(dbHandle) {
  const vmRows = await dbHandle.query(
    `SELECT v.id, v.scenario_id, v.name, v.cpu, v.mem_gb, v.sizing_profile_id
       FROM \`${t(TABLES.CAP_VMS)}\` v
       JOIN \`${t(TABLES.CAP_VM_PROFILES)}\` p ON p.id = v.sizing_profile_id
      WHERE p.scenario_id IS NULL`,
  );
  if (vmRows.length === 0) return [];
  const profileIds = [...new Set(vmRows.map((r) => String(r.sizing_profile_id)))];
  const profileRows = await dbHandle.query(
    `SELECT id, name, class, mode, cpu, mem_gb, sga_cap_gb FROM \`${t(TABLES.CAP_VM_PROFILES)}\` WHERE id IN (${profileIds.map(() => '?').join(',')})`,
    profileIds,
  );
  const profileById = new Map(profileRows.map((r) => [String(r.id), r]));
  const scenarioIds = [...new Set(vmRows.map((r) => String(r.scenario_id)))];
  const formulaByScenario = await loadFormulaByScenario(dbHandle, scenarioIds);
  return detectVmProfileDrift(vmRows, profileById, formulaByScenario);
}

async function previewDiskComboDrift(dbHandle) {
  const vmRows = await dbHandle.query(
    `SELECT v.id, v.scenario_id, v.name, v.disk_gb, v.disk_combo_id
       FROM \`${t(TABLES.CAP_VMS)}\` v
       JOIN \`${t(TABLES.CAP_DISK_COMBOS)}\` c ON c.id = v.disk_combo_id
      WHERE c.scenario_id IS NULL`,
  );
  if (vmRows.length === 0) return [];
  const comboIds = [...new Set(vmRows.map((r) => String(r.disk_combo_id)))];
  const comboRows = await dbHandle.query(
    `SELECT id, name, sizes FROM \`${t(TABLES.CAP_DISK_COMBOS)}\` WHERE id IN (${comboIds.map(() => '?').join(',')})`,
    comboIds,
  );
  const comboById = new Map(comboRows.map((r) => [String(r.id), r]));
  return detectDiskComboDrift(vmRows, comboById);
}

// ── Apply (per-scenario transaction, partial-failure tolerant) ─────────────

async function applyVmProfileDriftForScenario(conn, scenarioId) {
  // Unlocked probe to learn which GLOBAL vm_profiles rows this scenario's VMs
  // currently reference — no lock taken here, so it cannot itself invert
  // against anything. The referenced rows are locked FIRST below (see the
  // ordering comment on that FOR UPDATE), and the VM rows are re-read LOCKED
  // afterwards, so the values actually diffed/written are read fresh under
  // that later lock, not this probe.
  const candidateRows = await conn.query(
    `SELECT sizing_profile_id FROM \`${t(TABLES.CAP_VMS)}\`
      WHERE scenario_id = ? AND sizing_profile_id IS NOT NULL`,
    [scenarioId],
  );
  if (candidateRows.length === 0) return 0;
  const profileIds = [...new Set(candidateRows.map((r) => String(r.sizing_profile_id)))];
  // LOCK ORDER (P2, review round 3): catalogue row BEFORE the VM row that
  // references it — matching the codebase's other two writers of this same
  // pair, not the reverse (round-2's fix locked the VM row first). cap_scenarios
  // is taken FIRST by resolveScenarioWriteAccess (called before this function),
  // same as every same-scenario writer (_shared.js `makeScenarioRowLock` doc).
  // Then, on the generic child PUT for `vms` (crud-factory.js's guarded-PUT
  // path), the §17.1a catalogue-FK hook (`makeScenarioFkLockValidator`, wired
  // in children.js's `preWriteInTx` for every FK-bearing mount) locks the
  // REFERENCED vm_profiles row before the VM row's own UPDATE runs — the
  // crud-factory.js comment at the PUT path states this explicitly: moving a
  // row's own lock earlier "would take this row's own FOR UPDATE before the
  // hook's locks on the rows it REFERENCES, reordering how every guarded PUT
  // acquires its locks" (crud-factory.js ~line 2596-2601). config.js's global
  // vm_profiles PUT only ever locks its own catalogue row (config.js
  // ~line 575-589), so it never contends against a VM row and adds no order
  // constraint of its own. Locking VM rows first here (as round 2 did) would
  // therefore be the ONE writer in this trio taking the pair in reverse,
  // which is exactly the deadlock shape: writer A (child PUT) holds catalogue,
  // wants VM; writer B (this apply) holds VM, wants catalogue. Locking
  // catalogue-then-VM here removes that inversion.
  const profileRows = await conn.query(
    `SELECT id, name, class, mode, cpu, mem_gb, sga_cap_gb FROM \`${t(TABLES.CAP_VM_PROFILES)}\` WHERE scenario_id IS NULL AND id IN (${profileIds.map(() => '?').join(',')}) FOR UPDATE`,
    profileIds,
  );
  const profileById = new Map(profileRows.map((r) => [String(r.id), r]));
  const vmRows = await conn.query(
    `SELECT v.id, v.scenario_id, v.name, v.cpu, v.mem_gb, v.sizing_profile_id
       FROM \`${t(TABLES.CAP_VMS)}\` v
      WHERE v.scenario_id = ? AND v.sizing_profile_id IS NOT NULL FOR UPDATE`,
    [scenarioId],
  );
  if (vmRows.length === 0) return 0;
  const settingsRows = await conn.query(
    `SELECT * FROM \`${t(TABLES.CAP_SETTINGS)}\` WHERE scenario_id = ? OR scenario_id IS NULL ORDER BY scenario_id IS NULL LIMIT 1`,
    [scenarioId],
  );
  const formula = readFormulaConstants(settingsRows[0] || null);
  const formulaByScenario = new Map([[scenarioId, formula]]);
  const drift = detectVmProfileDrift(vmRows, profileById, formulaByScenario);
  const byVm = new Map();
  for (const d of drift) {
    const cur = byVm.get(d.vmId) || {};
    cur[d.field] = d.newValue;
    byVm.set(d.vmId, cur);
  }
  for (const [vmId, changed] of byVm) {
    const sets = [];
    const params = [];
    if ('cpu' in changed) { sets.push('cpu = ?'); params.push(changed.cpu); }
    if ('mem_gb' in changed) { sets.push('mem_gb = ?'); params.push(changed.mem_gb); }
    params.push(vmId, scenarioId);
    await conn.query(
      `UPDATE \`${t(TABLES.CAP_VMS)}\` SET ${sets.join(', ')} WHERE id = ? AND scenario_id = ?`,
      params,
    );
  }
  return byVm.size;
}

async function applyDiskComboDriftForScenario(conn, scenarioId) {
  // Unlocked probe — same two-step pattern as applyVmProfileDriftForScenario
  // above (see its lock-order comment for the full reasoning): learn the
  // referenced disk_combo_id set without a lock, lock those catalogue rows
  // FIRST, then lock the VM rows that reference them.
  const candidateRows = await conn.query(
    `SELECT disk_combo_id FROM \`${t(TABLES.CAP_VMS)}\`
      WHERE scenario_id = ? AND disk_combo_id IS NOT NULL`,
    [scenarioId],
  );
  if (candidateRows.length === 0) return 0;
  const comboIds = [...new Set(candidateRows.map((r) => String(r.disk_combo_id)))];
  // LOCK ORDER (P2, review round 3) — catalogue row BEFORE the VM row that
  // references it, matching CHILD_FK_VALIDATIONS' `vms.disk_combo_id` entry
  // (_shared.js ~line 1267) which the same §17.1a `preWriteInTx` hook locks
  // before the VM row's own UPDATE on the generic child PUT path
  // (crud-factory.js ~line 2596-2601, children.js ~line 46-50).
  const comboRows = await conn.query(
    `SELECT id, name, sizes FROM \`${t(TABLES.CAP_DISK_COMBOS)}\` WHERE scenario_id IS NULL AND id IN (${comboIds.map(() => '?').join(',')}) FOR UPDATE`,
    comboIds,
  );
  const comboById = new Map(comboRows.map((r) => [String(r.id), r]));
  const vmRows = await conn.query(
    `SELECT v.id, v.scenario_id, v.name, v.disk_gb, v.disk_combo_id
       FROM \`${t(TABLES.CAP_VMS)}\` v
      WHERE v.scenario_id = ? AND v.disk_combo_id IS NOT NULL FOR UPDATE`,
    [scenarioId],
  );
  if (vmRows.length === 0) return 0;
  const drift = detectDiskComboDrift(vmRows, comboById);
  for (const d of drift) {
    await conn.query(
      `UPDATE \`${t(TABLES.CAP_VMS)}\` SET disk_gb = ? WHERE id = ? AND scenario_id = ?`,
      [d.newValue, d.vmId, scenarioId],
    );
  }
  return new Set(drift.map((d) => d.vmId)).size;
}

const APPLY_BY_GROUP = Object.freeze({
  vm_profiles: applyVmProfileDriftForScenario,
  disk_combos: applyDiskComboDriftForScenario,
});

// ── Routes ───────────────────────────────────────────────────────────────────

const router = express.Router();

router.get('/:group/propagation-preview', async (req, res) => {
  if (!requireAdminOrEditor(req, res)) return;
  const group = req.params.group;
  if (!PROPAGATABLE_GROUPS.has(group)) {
    // hardware_specs (and any other config group): no materialized local copy
    // exists to drift — see the module doc. Empty, not an error, so a caller
    // that wires the trigger uniformly needs no special case.
    return res.json(apiOk({ scenarios: [], truncated: false, total: 0 }));
  }
  // Writer pool, not pool.ro (X1, review round 2): both cards that trigger this
  // preview call it IMMEDIATELY after their own global-catalogue PUT commits —
  // a read-after-write flow. On an RO-replica topology a lagging replica would
  // answer the preview from the OLD catalogue row, report no drift, and the
  // dialog would never open — the save silently fails to propagate with no
  // error surfaced anywhere. Same convention as config.js's own read-after-write
  // comment ("Write + confirming read on the SAME primary connection").
  try {
    const drift = group === 'vm_profiles'
      ? await previewVmProfileDrift(pool.rw)
      : await previewDiskComboDrift(pool.rw);
    if (drift.length === 0) return res.json(apiOk({ scenarios: [], truncated: false, total: 0 }));
    const scenarioIds = [...new Set(drift.map((d) => d.scenarioId))];
    const scenarioNameById = await loadScenarioNames(pool.rw, scenarioIds);
    const allScenarios = groupDriftByScenario(drift, scenarioNameById);
    // Symmetric to apply's MAX_PROPAGATION_SCENARIOS cap (F5): the
    // JOIN behind previewVmProfileDrift/previewDiskComboDrift has no scenario
    // filter (unlike apply, which is always scoped to the caller's selected
    // scenarioIds), so this response is the one unbounded side of the pair.
    // Bound it the SAME way apply bounds its own input, and say so in the
    // payload rather than silently handing back a shorter list that looks
    // complete — a caller (or the dialog's own "N scenarios" copy) that reads
    // `scenarios.length` as the full count would otherwise have no way to
    // tell a truncated result from a genuinely small one.
    const truncated = allScenarios.length > MAX_PROPAGATION_SCENARIOS;
    const scenarios = truncated ? allScenarios.slice(0, MAX_PROPAGATION_SCENARIOS) : allScenarios;
    // `total` is the PRE-slice count (A.2) — lets the dialog's banner
    // say "first 2000 of 2347" instead of just naming the cap, the same
    // "showing first N of M" convention FetchFromFanoutModal already uses for
    // its own capped result. Plain `{total}` interpolation (no
    // `.toLocaleString()`), same as that convention's own template string —
    // no thousands separator, by design as much as by omission.
    res.json(apiOk({ scenarios, truncated, total: allScenarios.length }));
  } catch (err) {
    logger.error({ err, group }, `Failed to preview capacity catalogue propagation for group=${group}`);
    const e = apiError('Database operation failed', 'INTERNAL_ERROR', 500);
    res.status(e.status).json(e.body);
  }
});

router.post('/:group/propagation-apply', async (req, res) => {
  if (!requireAdminOrEditor(req, res)) return;
  const group = req.params.group;
  const applyForScenario = APPLY_BY_GROUP[group];
  if (!applyForScenario) {
    const e = apiError(`${group} has no catalogue propagation to apply`, 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }
  const { scenarioIds } = req.body || {};
  if (
    !Array.isArray(scenarioIds)
    || scenarioIds.length === 0
    || !scenarioIds.every((id) => typeof id === 'string' && id.length > 0)
  ) {
    const e = apiError('scenarioIds must be a non-empty array of scenario ids', 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }
  if (scenarioIds.length > MAX_PROPAGATION_SCENARIOS) {
    const e = apiError(`scenarioIds exceeds ${MAX_PROPAGATION_SCENARIOS} limit`, 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }

  // ONE connection, one transaction PER scenario (not one transaction for the
  // whole batch): a scenario this caller cannot write, or one whose lock the
  // caller loses a race for, must not roll back every OTHER scenario's already-
  // applied update — the dialog's own contract is per-scenario checkbox select,
  // so the apply outcome is per-scenario too.
  let conn;
  const results = [];
  try {
    conn = await pool.rw.getConnection();
    for (const scenarioId of scenarioIds) {
      await conn.beginTransaction();
      try {
        const access = await resolveScenarioWriteAccess(conn, scenarioId, req.user);
        if (!access.found) {
          await safeRollback(conn);
          results.push({ scenarioId, status: 'not_found', vmsUpdated: 0 });
          continue;
        }
        // CANONICALIZE (P2, review round 3): `access.scenarioId` is the row's
        // STORED casing, echoed back by resolveScenarioWriteAccess's own
        // SELECT — the request may have supplied a case-variant id that still
        // matched under the column's case-insensitive collation. Every
        // downstream use of "this scenario's id" must switch to that SAME
        // casing from here on, not the request spelling: applyForScenario's
        // own formula-by-scenario map is keyed by the id it is CALLED with,
        // while the VM rows it reads back carry the DB's stored casing — a
        // request-cased key that does not match the stored-cased VM rows
        // misses the map lookup and silently falls back to DEFAULT_FORMULA,
        // writing the wrong mem_gb for a formula-mode profile (same defect
        // family as this repo's other case-insensitive-collation lessons).
        const canonicalScenarioId = access.scenarioId;
        if (!access.allowed) {
          await safeRollback(conn);
          results.push({ scenarioId: canonicalScenarioId, status: 'forbidden', vmsUpdated: 0 });
          continue;
        }
        const vmsUpdated = await applyForScenario(conn, canonicalScenarioId);
        await conn.commit();
        results.push({ scenarioId: canonicalScenarioId, status: 'applied', vmsUpdated });
      } catch (err) {
        await safeRollback(conn);
        logger.error({ err, scenarioId, group }, `Failed to apply capacity catalogue propagation for scenario id=${scenarioId}`);
        results.push({ scenarioId, status: 'error', vmsUpdated: 0 });
      }
    }
    res.json(apiOk({ results }));
  } catch (err) {
    logger.error({ err, group }, `Failed to apply capacity catalogue propagation for group=${group}`);
    const e = apiError('Database operation failed', 'INTERNAL_ERROR', 500);
    res.status(e.status).json(e.body);
  } finally {
    if (conn) conn.release();
  }
});

module.exports = {
  router,
  detectVmProfileDrift,
  detectDiskComboDrift,
  groupDriftByScenario,
};
