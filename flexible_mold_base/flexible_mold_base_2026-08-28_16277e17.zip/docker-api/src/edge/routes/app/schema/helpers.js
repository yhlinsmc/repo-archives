const { TABLES, VARIANT_OVERRIDE_ACTIONS } = require('../../../../shared/constants');
const { pool, t, getDynamicPool } = require('../../../db');
const { apiOk, apiError, requireAuth, requireAdmin, requireAdminOrEditor, uuidv4, UUID_RE } = require('../../../../shared/helpers');
const { logger: rootLogger } = require('../../../../shared/lib/logger');
const { mapRowFromDb, mapRowsFromDb, mapRowToDb } = require('../../../lib/dto-mapper');
const { previewCascade, cascadeDeleteNode, collectDescendantIds } = require('../../../lib/hierarchy-cascade');
const { tableExistsInCurrentSchema } = require('../../../lib/table-exists');
const {
  buildVariantOverrideUpdateExistsClause,
  buildVariantOverrideInsertExistsClause,
  buildDuplicateActionTripleNotExistsClause,
  buildVariantOverrideContextSql,
} = require('../../../lib/variant-override-helpers');
const logger = rootLogger.child({ module: 'schema' });
const { applyOwnerChange } = require('../../../services/ownership');
const { attachOwnerNames: enrichOwnerNames } = require('../../../lib/owner-name-enrichment');
const { validateComputeRule, detectCycle } = require('../../../lib/compute-rule-validate');
const {
  parseStoredRule,
  extractComputeSources,
  buildEffectiveRules,
  buildFieldContext,
  canonicalRuleJson,
  judgeComputeRulePostState,
  loadBlueprintComputeState,
  loadBlueprintFieldScopes,
  loadBlueprintFieldComputeRule,
  loadBlueprintFieldMode,
  loadVariantComputeRulesByVariant,
  loadVariantCellTargetsByVariant,
  blueprintRuleClosesCycle,
  buildColumnComputeNodes,
  hasColumnCycle,
  hasRowContextSource,
} = require('../../../lib/compute-rule-graph');
const { invalidChoiceConfigShape } = require('../../../lib/choice-config-validate');
const {
  invalidCellTargetsShape, hasCellScope, scopeNamesColumn, scopeNamesSingleColumn,
} = require('../../../../shared/cell-targets-validate');
const { resolveAncestors, restampTemplates, countAffectedTemplates } = require('../../../lib/blueprint-reparent');
const { isValidBlueprintParent } = require('../../../../shared/hierarchy-tiers');
const { sameStoredValue } = require('./write-value');
const { resolveRwPool: resolveRequestRwPool } = require('./request-pool');
const { UUID_CHAR_LENGTH, identifierFloorViolation } = require('./identifier-floor');
const { charColumnsFor } = require('../../../lib/schema-manifest');


// NOTE: event_type is fixed at 'blueprint.owner.transfer' (NOT
// 'hierarchy_node.owner.transfer') for backward compat with audit consumers
// keyed on this string. Action discriminator lives in metadata.
const HIERARCHY_OWNER_AUDIT_EVENT = 'blueprint.owner.transfer';
const USER_TEMPLATE_OWNER_AUDIT_EVENT = 'user_template.owner.transfer';

// The RW resolver the top-level ownership routes (PATCH owner + POST claim +
// POST release) use, so they respect the same Custom API / per-request `db`
// override the rest of the schema CRUD honours. It no longer MIRRORS the CRUD
// factory's resolver — it IS the same function; see request-pool.js for why a
// second copy of "which database is this request about" is a silent failure.
const resolveOwnershipRwPool = resolveRequestRwPool;

// INVARIANT: cascade owner change from a blueprint row to all its variants.
// Variants inherit ownership from the parent blueprint via parent_id; without
// this cascade an editor who claims a shared blueprint would find the parent
// owned but the children still NULL (any editor could mutate them), and a
// release would orphan variants as the previous owner's even though the
// blueprint went back to shared. Returns affectedRows so the route can log
// how many cascaded. One summary audit row per cascade keeps the trail
// complete without spamming N rows when a blueprint has many variants.
// NOTE: lock every variant row before the UPDATE so a concurrent editor PUT
// cannot snapshot stale owner_id between this transaction's commits.
async function cascadeBlueprintOwnerToVariants(conn, blueprintId, newOwnerId, opts) {
  const { actor, action } = opts;
  await conn.query(
    `SELECT id FROM \`${t(TABLES.HIERARCHY_NODES)}\`
       WHERE parent_id = ? AND node_type = 'variant' FOR UPDATE`,
    [blueprintId],
  );
  const result = await conn.query(
    `UPDATE \`${t(TABLES.HIERARCHY_NODES)}\` SET owner_id = ?
       WHERE parent_id = ? AND node_type = 'variant'`,
    [newOwnerId, blueprintId],
  );
  const affected = Number(result.affectedRows || 0);
  if (affected > 0) {
    // SECURITY: allowlist actor.role so a spoofed JWT/middleware cannot
    // persist an arbitrary string into feature_audit. Known roles plus
    // 'unknown' fallback.
    const safeRole = ['admin', 'editor', 'user'].includes(actor.role) ? actor.role : 'unknown';
    await conn.query(
      `INSERT INTO \`${t(TABLES.FEATURE_AUDIT)}\` (id, event_type, user_id, metadata)
       VALUES (?, ?, ?, ?)`,
      [
        uuidv4(),
        HIERARCHY_OWNER_AUDIT_EVENT,
        actor.id || null,
        JSON.stringify({
          parent_blueprint_id: blueprintId,
          action: `${action}.cascade`,
          new_owner_id: newOwnerId,
          actor_role: safeRole,
          variant_count: affected,
        }),
      ],
    );
  }
  return affected;
}

// CSO Finding #1: Validate column names to prevent SQL injection via
// backtick-breaking in identifier interpolation. Only alphanumeric + underscore allowed.
const SAFE_COL_RE = /^[a-zA-Z_][a-zA-Z0-9_]*$/;
function isSafeColumnName(name) { return typeof name === 'string' && SAFE_COL_RE.test(name); }

// Identity-key slug shape shared by blueprint_sections.section_key and
// blueprint_groups.group_key. Mirrors the client-side rule the Schema Builder
// enforces (SchemaSidebar / GroupsManagerPanel): must start with a lowercase
// letter, then only lowercase letters, digits, and underscores. Bounded to the
// VARCHAR(255) column width. The server enforces the same shape so a direct API
// caller cannot persist a key the UI would refuse — closing the gap where the
// server previously accepted any non-empty <=255 string.
const SLUG_KEY_PATTERN = /^[a-z][a-z0-9_]*$/;
function isValidSlugKey(v) {
  return typeof v === 'string' && v.length > 0 && v.length <= 255 && SLUG_KEY_PATTERN.test(v);
}

// ── What counts as a link, and what a write may say about one ───────────────
//
// ABSENCE IS DECIDED BY PRESENCE, NEVER BY TRUTHINESS. `''` is not "no link":
// measured live, an empty string really does reach `linked_blueprint_id`, is
// really stored, and `IS NULL` really answers 0 for it — while every reader of
// the column tested `!= null` and therefore read the row as a blueprint
// borrowing a schema from nowhere. That row's schema routes then answered 409
// for EVERY role including an administrator, so the row could not be repaired
// through any surface that would have to write to it.
//
// The two halves of the fix, and why each is where it is:
//   - a value that arrives EMPTY is refused (`refuseBlankLinkColumn`), because
//     coercing it to NULL would silently change what the caller asked for and a
//     caller asking for `''` is always a bug;
//   - a value already STORED empty names no row and is read as absent
//     (`linkTargetOf`), because that is the only reading under which the rows
//     this defect already created can be repaired.
//
// AND THE OTHER HALF OF "NEVER BY TRUTHINESS", WHICH THE FIRST VERSION OF THIS
// BLOCK LEFT OPEN. The refusal above only ever looked at STRINGS, so a JSON
// number walked through it: `{"linked_blueprint_id": 0}` reached
// `linkTargetOf`, which maps only `null` and `''` to absent, and every gate
// afterwards was decided about `0`. `WHERE id = 0` is a CHAR-vs-number
// comparison MariaDB resolves in NUMERIC context, so it matched an arbitrary
// set of uuid rows (measured on this schema: all three fixture rows), the
// self-link refusal answered "not the same row" from its non-string fail-safe,
// and the null→linked transition fired — DELETING the blueprint's own fields,
// options, sections, groups, decision tables and output order before storing
// `'0'`, after which the emptied blueprint read as LINKED and every schema
// route answered 409 for every role. That is `identifier-floor.js`'s rule
// exactly, so it is that module which is applied here rather than a second
// hand-rolled one beside it.
const LINK_COLUMNS = Object.freeze(['linked_blueprint_id', 'transformer_id', 'transformer_version']);

// The CHAR(36) columns of hierarchy_nodes that legitimately hold something
// other than a row id, declared ONCE for both readers: the factory mount
// (index.js `nonUuidCharColumns`, which states the reason in full) and the link
// routes below. `transformer_id` names an entry in a registry whose file half
// is an author-chosen short string, not a row — so the floor's premise does not
// hold for it, and a copy of that judgement per reader is how one of them comes
// to be wrong in silence.
const HIERARCHY_NON_UUID_CHAR_COLUMNS = Object.freeze(['transformer_id']);

// THE BLANK RULE IS COMMON TO ALL THREE; THE SHAPE RULE IS THE EXTRA ONE. A
// link column the DDL declares CHAR(36) and the mount does not exempt is also
// judged by the identifier floor, which covers numbers, booleans and any
// spelling outside the canonical form. Derived from the DDL, so a column whose
// type moves changes what judges it without anyone editing a list.
//
// The two are asked in that order, and the order is the rule's whole point for a
// reader: the floor's sentence is about a shape, and `''` is not a shape mistake
// an operator can act on — it is an empty picker, whose answer is "send null".
// Ordered floor-first, that sentence was lost on the one column most likely to
// receive it.
const LINK_IDENTIFIER_COLUMNS = Object.freeze(
  (charColumnsFor(TABLES.HIERARCHY_NODES, UUID_CHAR_LENGTH) || [])
    .filter((c) => LINK_COLUMNS.includes(c) && !HIERARCHY_NON_UUID_CHAR_COLUMNS.includes(c)),
);

/** The row this value names, or null when it names none. */
function linkTargetOf(value) {
  return value == null || value === '' ? null : value;
}

/**
 * `linkTargetOf` FOR A READER THAT IS THE ENGINE — the SQL expression naming
 * the row a stored link column names, or NULL when it names none.
 *
 * IT EXISTS BECAUSE THE RULE ABOVE HAS TWO READERS AND ONLY ONE OF THEM IS
 * JAVASCRIPT. `linkTargetOf` made a stored `''` read as absent, which is what
 * makes an already-bricked row repairable; but the orphan scanner and its
 * delete re-check resolve the same column in SQL, and `COALESCE` replaces only
 * NULL. A stored `''` is a value, so `COALESCE(hn.linked_blueprint_id,
 * ut.blueprint_id)` resolved the effective blueprint to `''`, which is the id of
 * no row — measured on this schema, the scanner then reported EVERY payload key
 * on such a template as an orphan and the delete re-check, asking the same
 * expression, agreed and removed them. Two valid answers, gone.
 *
 * SO THE TWO SPELLINGS OF ONE RULE LIVE HERE TOGETHER, one line apart, rather
 * than one of them living in whichever query happened to need it. A query that
 * builds its own `COALESCE` is the defect returning under a new alias, so the
 * old spelling is refused mechanically as well
 * (`tests/unit/effective-blueprint-sql-single-source.test.js`).
 *
 * `NULLIF(col, '')` and not `IF(col IS NULL OR col = '', …)`: the column is
 * declared CHAR(36), so MariaDB strips trailing spaces on retrieval and a row
 * holding only spaces comes back to JavaScript as `''` too — the same value both
 * readers must call absent. `NULLIF` compares under the column's collation,
 * which is that same PAD SPACE rule, so the two agree on that row without either
 * being told about it (measured, not assumed: see the real-DB test).
 *
 * @param {string} columnExpr qualified column, e.g. `hn.linked_blueprint_id`
 */
function linkTargetSql(columnExpr) {
  return `NULLIF(${columnExpr}, '')`;
}

/**
 * The blueprint whose `blueprint_fields` a template's payload keys belong to.
 *
 * A blueprint may declare `linked_blueprint_id` — schema-sharing sugar where
 * blueprint A reuses blueprint B's fields. Templates store `blueprint_id` (the
 * blueprint the operator selected) but their payload keys are the LINKED
 * blueprint's when there is a link, so every query that judges a payload key
 * must resolve the link first or it judges the keys against the wrong field set.
 *
 * @param {string} nodeAlias     alias of the joined `hierarchy_nodes` row
 * @param {string} templateAlias alias of the `user_templates` row
 */
function effectiveBlueprintIdSql(nodeAlias, templateAlias) {
  return `COALESCE(${linkTargetSql(`${nodeAlias}.linked_blueprint_id`)}, ${templateAlias}.blueprint_id)`;
}

/**
 * The id the NAMED ROW carries, for a value that names a `hierarchy_nodes` row.
 * Null when it names none.
 *
 * WHICH ROW IS NAMED AND WHICH BYTES ARE STORED ARE TWO ANSWERS, and asking the
 * engine the first does not settle the second. `WHERE id = ?` resolves under the
 * column's collation, so an id sent in another case finds its row and passes
 * every guard — and the statement then writes the caller's spelling, because
 * measured (db-semantics §Q1) the engine stores the new bytes rather than
 * absorbing them. SQL readers keep resolving such a link; JavaScript readers do
 * not, and the link column has several: the read-only banner names its source
 * with `allNodes.find(n => n.id === linkedSourceId)` and the link picker matches
 * its `Select` value byte-wise, so a blueprint that IS linked renders an empty
 * picker and an unnamed source. So the row's OWN id comes back with it and that
 * is what the write binds.
 *
 * A non-string operand is answered null without a query — the same fail-safe the
 * rest of this module keeps, and for the same reason: `WHERE id = 0` on a
 * CHAR(36) column is resolved in numeric context and matches an arbitrary set of
 * rows. Callers refuse such a value at the floor; this is the second lock.
 */
async function storedNodeId(conn, value) {
  if (typeof value !== 'string' || value === '') return null;
  const rows = await conn.query(
    `SELECT id FROM \`${t(TABLES.HIERARCHY_NODES)}\` WHERE id = ?`,
    [value],
  );
  return rows.length ? rows[0].id : null;
}

/**
 * The first link column this body names with a value that can name no row.
 * Returns a ready-made refusal, or null.
 *
 * Every link column, not only the ones the identifier floor leaves alone: the
 * floor would refuse a blank on the others too, but with a sentence about a
 * canonical form rather than the one an operator who cleared a picker needs.
 *
 * @param {object} body the request body
 * @returns {{status: number, code: string, message: string}|null}
 */
function refuseBlankLinkColumn(body) {
  if (!body || typeof body !== 'object') return null;
  for (const column of LINK_COLUMNS) {
    if (!Object.prototype.hasOwnProperty.call(body, column)) continue;
    const value = body[column];
    if (typeof value === 'string' && value.trim() === '' && value !== '') {
      return {
        status: 400,
        code: 'INVALID_LINK_TARGET',
        message: `${column} must name a row or be null; whitespace names nothing.`,
      };
    }
    if (value === '') {
      return {
        status: 400,
        code: 'INVALID_LINK_TARGET',
        message: `${column} must name a row or be null; an empty value names nothing. `
          + 'Send null to clear it.',
      };
    }
  }
  return null;
}

/**
 * May this body's link columns be read at all?
 *
 * THE ONE ENTRY POINT BOTH VERBS CALL, and it runs BEFORE `effectiveLinkValue`
 * on each of them — before any value from these columns has been used to
 * resolve a row, decide a transition, or reach a statement. The create path
 * survived without it only because it hands the body on to the factory, whose
 * own floor refuses the value at the end; the update path never reaches the
 * factory when the write is the transition, which is the one write that
 * destroys something.
 *
 * @param {object} body the request body
 * @returns {{status: number, code: string, message: string}|null}
 */
function refuseLinkColumnShape(body) {
  if (!body || typeof body !== 'object') return null;
  // Blank first, then shape — see the ordering note on LINK_IDENTIFIER_COLUMNS.
  // Neither weakens the other: the blank rule answers only `''` and whitespace,
  // and every other value the floor judges falls straight through to it.
  const blankIssue = refuseBlankLinkColumn(body);
  if (blankIssue) return blankIssue;
  const floorIssue = identifierFloorViolation(LINK_IDENTIFIER_COLUMNS, body);
  if (floorIssue) {
    return { status: floorIssue.status, code: floorIssue.code, message: floorIssue.message };
  }
  return null;
}

/**
 * What `column` holds after this write: the body's value when the body NAMES the
 * column, the stored value otherwise. Verbatim on both sides apart from the
 * empty string, which names no row either way (see linkTargetOf).
 */
function effectiveLinkValue(body, stored, column) {
  return Object.prototype.hasOwnProperty.call(body || {}, column)
    ? linkTargetOf(body[column])
    : linkTargetOf(stored ? stored[column] : null);
}

// Linked-blueprint schema guard (S1/S2). A blueprint that borrows another's
// schema via linked_blueprint_id must be read-only for schema edits: data
// entry renders the SOURCE blueprint's fields (COALESCE(linked, self)), so a
// write to a linked blueprint's own fields/sections/options/output-order would
// never surface and would accumulate orphan rows. The check runs for EVERY
// role (admin included) on write paths only — editing a linked blueprint's
// schema is meaningless regardless of ownership.
async function isBlueprintLinked(conn, blueprintId) {
  if (!blueprintId) return false;
  const rows = await conn.query(
    `SELECT linked_blueprint_id FROM \`${t(TABLES.HIERARCHY_NODES)}\`
       WHERE id = ? AND node_type = 'blueprint'`,
    [blueprintId],
  );
  return rows.length > 0 && linkTargetOf(rows[0].linked_blueprint_id) != null;
}

// Same as isBlueprintLinked but takes a FOR UPDATE row lock — use inside a
// transaction that is about to write schema rows onto the blueprint, so a
// concurrent PUT that links the blueprint serialises behind this lock (closes
// the check-conn/write-conn TOCTOU).
async function isBlueprintLinkedLocked(conn, blueprintId) {
  if (!blueprintId) return false;
  const rows = await conn.query(
    `SELECT linked_blueprint_id FROM \`${t(TABLES.HIERARCHY_NODES)}\`
       WHERE id = ? AND node_type = 'blueprint' FOR UPDATE`,
    [blueprintId],
  );
  return rows.length > 0 && linkTargetOf(rows[0].linked_blueprint_id) != null;
}

// Factory-path guard: resolve the blueprint id(s) a write targets (stored row
// FK for update + incoming body FK for create/reparent) and lock-check each on
// the write transaction's connection. Returns true when any target blueprint is
// linked (caller must rollback + 409).
async function isLinkedParentLocked(conn, logicalName, cfg, data, rowId) {
  const ids = new Set();
  if (rowId != null) {
    const sid = await resolveLinkCheckBlueprintId(conn, logicalName, cfg, undefined, rowId);
    if (sid) ids.add(sid);
  }
  const bid = await resolveLinkCheckBlueprintId(conn, logicalName, cfg, data, null);
  if (bid) ids.add(bid);
  // SAFETY: a reparent write can resolve two distinct blueprint ids (stored +
  // incoming). Lock them in a deterministic (sorted) order so two concurrent
  // reparents can never acquire the two row locks in opposite order and deadlock.
  for (const id of [...ids].sort()) {
    if (await isBlueprintLinkedLocked(conn, id)) return true;
  }
  return false;
}

// Audit a failed link transition on a FRESH autocommit connection so the row
// survives the transition transaction's rollback (the in-TX schema_cleared row
// is lost when the final UPDATE affects 0 rows). Best-effort: never throws into
// the caller.
async function auditSchemaClearFailed(poolRef, { userId, blueprintId, linkedBlueprintId, reason }) {
  let c;
  try {
    c = await poolRef.getConnection();
    await c.query(
      `INSERT INTO \`${t(TABLES.FEATURE_AUDIT)}\` (id, event_type, user_id, metadata) VALUES (?, ?, ?, ?)`,
      [uuidv4(), 'blueprint.linked.schema_clear.failed', userId || null,
        JSON.stringify({ blueprint_id: blueprintId, linked_blueprint_id: linkedBlueprintId, reason })],
    );
  } catch (auditErr) {
    logger.warn({ err: auditErr }, 'failed to write blueprint.linked.schema_clear.failed audit');
  } finally {
    if (c) c.release();
  }
}

// B1/B2/B5 link integrity. Validate a blueprint's effective post-write link +
// transformer against the single-hop / no-cycle / mutual-exclusion invariants.
// Returns { status, code, message } on violation, else null. `rowId` is the
// node being written (null for create when no id supplied). `effectiveLinked`
// and `effectiveTransformer` are the values AFTER the write (body merged over
// the stored row by the caller).
async function validateLinkConstraints(conn, rowId, nodeType, effectiveLinked, effectiveTransformer, allowExistingBothSet = false) {
  // B5: a blueprint borrows the source's transformer when linked, so it must
  // never carry one of its own. Reject only when the write would CREATE a new
  // both-set state. `allowExistingBothSet` grandfathers a row that was already
  // both-set in storage so an admin can still PUT it (to update an unrelated
  // field, or to clear one side and repair it) — otherwise such a legacy row
  // could never be saved at all. Create (POST) always passes false, so a fresh
  // both-set row is still rejected at the source.
  if (effectiveLinked != null && effectiveTransformer != null && !allowExistingBothSet) {
    return {
      status: 400, code: 'TRANSFORMER_LINK_EXCLUSIVE',
      message: 'A blueprint cannot have both a transformer and a linked source; choose one.',
    };
  }
  if (effectiveLinked == null) return null;
  if (nodeType !== 'blueprint') {
    return { status: 400, code: 'INVALID_LINK_TARGET', message: 'Only blueprint nodes can be linked.' };
  }
  // THE OPERAND IS VALIDATED HERE BECAUSE THIS CALL SITE READS THE ANSWER
  // BACKWARDS. `sameStoredValue` answers `false` for a non-string operand and
  // documents that as the SAFE direction — its callers use it to mean "the
  // write MOVES the record", and "it moved" is what keeps a guard running. On
  // this line the polarity is inverted: `true` is what REFUSES, so the same
  // fail-safe reads as "not the same row, carry on" and hands `WHERE id = ?` a
  // number, which MariaDB resolves in numeric context against CHAR(36) and
  // matches an arbitrary set of rows. Every operand reaching here is already
  // floor-checked by both verbs, so this is the second lock on that door — and
  // it answers with the floor's own refusal rather than throwing, because the
  // caller is a request and a 400 is what a bad shape deserves.
  if (effectiveLinked != null && typeof effectiveLinked !== 'string') {
    return {
      status: 400,
      code: 'INVALID_ID_FORMAT',
      message: `linked_blueprint_id must be an identifier in the canonical ${UUID_CHAR_LENGTH}-character form`,
    };
  }
  // AND THE OTHER OPERAND OF THE SAME COMPARISON, which the first version of
  // this lock left out. `rowId` is the row the questions below are ABOUT: it is
  // the second operand of the self-link probe and the SOLE bind of
  // `WHERE linked_blueprint_id = ?` in the B1 referrer query at the end. The
  // update path takes it from the URL, but the create path takes it from the
  // body (`body.id || null`), which passes `true`, a number, an object — and a
  // number bound against a CHAR(36) column is resolved in NUMERIC context, so
  // the referrer query answers about every stored value with the same leading
  // digit-run. Measured: a create naming `"id": 1` was refused
  // SOURCE_CANNOT_BE_LINKED on the strength of a link row belonging to another
  // blueprint entirely. Non-string only, deliberately: a spelling this schema
  // did not generate is still a string the engine compares as one, and refusing
  // those would stop a legacy row being saved at all.
  if (rowId != null && typeof rowId !== 'string') {
    return {
      status: 400,
      code: 'INVALID_ID_FORMAT',
      message: `id must be an identifier in the canonical ${UUID_CHAR_LENGTH}-character form`,
    };
  }
  // collation-compare: "is this row the row the caller named" is a question
  // about a column — the lookup two lines below resolves the target with
  // `WHERE id = ?`, which the engine answers under the column's collation. A
  // JavaScript `===` here answered "not itself" for the same id in another
  // spelling, the lookup then resolved the row itself, and the transition
  // handler did what a transition does: deleted the blueprint's own fields,
  // sections, groups, options and output order, because a linked blueprint's own
  // schema is unreachable. The blueprint was left linked to itself with nothing
  // in it.
  if (rowId != null && await sameStoredValue(
    conn, t(TABLES.HIERARCHY_NODES), 'id', effectiveLinked, rowId,
  )) {
    return { status: 400, code: 'SELF_LINK', message: 'A blueprint cannot link to itself.' };
  }
  const targetRows = await conn.query(
    `SELECT node_type, linked_blueprint_id FROM \`${t(TABLES.HIERARCHY_NODES)}\` WHERE id = ?`,
    [effectiveLinked],
  );
  if (!targetRows.length || targetRows[0].node_type !== 'blueprint') {
    return { status: 400, code: 'INVALID_LINK_TARGET', message: 'Link target must be an existing blueprint.' };
  }
  // B1: keep resolution single-hop — never link to a blueprint that is itself
  // linked (that is what would create an A→B→C chain).
  if (linkTargetOf(targetRows[0].linked_blueprint_id) != null) {
    return {
      status: 409, code: 'LINK_TO_LINKED',
      message: 'Cannot link to a blueprint that is itself linked; link to its source instead.',
    };
  }
  // B2: a direct A↔B cycle is already unrepresentable here — LINK_TO_LINKED
  // above rejects linking to any blueprint that is itself linked, so the target
  // is always unlinked at this point. The concurrent-write case (both sides
  // racing) is closed by the FOR UPDATE re-check in the PUT transition handler.
  // B1 (other direction): a blueprint that is itself a link source for others
  // cannot become linked — that would turn its referrers into A→B→C chains.
  if (rowId != null) {
    const referrers = await conn.query(
      `SELECT id FROM \`${t(TABLES.HIERARCHY_NODES)}\`
         WHERE linked_blueprint_id = ? AND node_type = 'blueprint' LIMIT 1`,
      [rowId],
    );
    if (referrers.length) {
      return {
        status: 409, code: 'SOURCE_CANNOT_BE_LINKED',
        message: 'This blueprint is a link source for other blueprints; it cannot itself be linked.',
      };
    }
  }
  return null;
}

// Resolve the blueprint id a write to `logicalName` targets, from the request
// body (create) or the existing row (update/delete). `cfg` is the mount's
// rejectIfParentLinked opt: { column } for tables with a direct blueprint_id
// FK, or { fk, lookupTable, lookupIdCol, blueprintCol } for a one-hop lookup
// (field_options → blueprint_fields). All column names are static opts,
// whitelisted at registration. Returns null when the target can't be resolved
// (orphan / missing fk) — callers treat null as "not linked" so other
// validation (NOT NULL, ownership) handles the missing parent.
// NOTE (2a): for the one-hop form the intermediate lookup row (blueprint_fields)
// is read WITHOUT a lock; only the resolved blueprint row is FOR UPDATE'd by the
// caller. A concurrent delete of the intermediate row between this read and the
// lock just drops the FK → the write becomes an orphan that other validation
// catches, so the null→not-linked fallback stays the safe behavior. Do not
// remove that fallback in a future refactor.
async function resolveLinkCheckBlueprintId(conn, logicalName, cfg, data, rowId) {
  // SECURITY: when a row id is present (update/delete) the STORED row is
  // authoritative — never trust a body-supplied FK. An editor could otherwise
  // send a `blueprint_id`/`field_id` pointing at an unlinked parent to pass the
  // guard, after which the factory strips the FK and updates the row by id
  // alone, mutating a row that actually belongs to a linked blueprint.
  if (cfg.column) {
    if (rowId != null) {
      const rows = await conn.query(
        `SELECT \`${cfg.column}\` AS bid FROM \`${t(logicalName)}\` WHERE id = ?`,
        [rowId],
      );
      return rows.length ? rows[0].bid : null;
    }
    if (data && data[cfg.column] != null) return data[cfg.column];
    return null;
  }
  let fkVal = null;
  if (rowId != null) {
    const rows = await conn.query(
      `SELECT \`${cfg.fk}\` AS fk FROM \`${t(logicalName)}\` WHERE id = ?`,
      [rowId],
    );
    fkVal = rows.length ? rows[0].fk : null;
  } else if (data && data[cfg.fk] != null) {
    fkVal = data[cfg.fk];
  }
  if (fkVal == null) return null;
  const rows = await conn.query(
    `SELECT \`${cfg.blueprintCol}\` AS bid FROM \`${t(cfg.lookupTable)}\`
       WHERE \`${cfg.lookupIdCol}\` = ?`,
    [fkVal],
  );
  return rows.length ? rows[0].bid : null;
}

// Operator-mode column gate. Sparse override columns are always sent by the
// frontend (null when empty) so the patch-style PUT actually clears them. On a
// DB whose schema predates a column (manual operator migrations), naming a
// missing column in INSERT/UPDATE would 500 with ER_BAD_FIELD_ERROR. This probe
// returns the set of physically-present, lowercased column names so the write
// path can drop only known-missing columns.
//
// INVARIANT: columns are stable after boot-time migrations, so the result is
// cached for the process lifetime. The cache key is (current database identity
// + physical table name), NOT the table name alone: this app switches DB pools
// at runtime (dynamic connection profiles, per-request `req.body.db`), and two
// distinct databases can share a physical table name with DIFFERENT migration
// states. Keying by table name alone would let a probe of one DB poison writes
// to another — a stale "column exists" entry 500s an older DB, and a stale
// "column missing" entry silently DROPS the override column on an upgraded DB.
// The db name is read from the leased conn via DATABASE() so the key reflects
// the actual schema the write will hit (never a config guess across the pool
// facade).
//
// On probe failure or an empty result the gate caches null for that (db,table)
// key — callers MUST treat null as "unknown" and keep ALL safe keys, so
// normal-mode writes stay byte-identical and nothing is ever silently dropped.
const _columnSetCache = new Map();

// Resolve the database the leased connection is actually bound to. Cheap
// server-local scalar (no table access). Returns '' on failure so the composite
// key still isolates by table name (worst case: no cross-table sharing, never
// cross-db sharing of a known result — a failed DATABASE() also fails the
// subsequent probe and caches null=unknown).
async function getConnDatabaseName(conn) {
  try {
    const rows = await conn.query('SELECT DATABASE() AS db');
    const name = Array.isArray(rows) && rows.length
      ? (rows[0].db ?? rows[0].DATABASE ?? rows[0]['DATABASE()'])
      : null;
    return typeof name === 'string' ? name : '';
  } catch {
    return '';
  }
}

async function getActualColumnSet(conn, physicalTableName) {
  const dbName = await getConnDatabaseName(conn);
  const cacheKey = `${dbName}::${physicalTableName}`;
  if (_columnSetCache.has(cacheKey)) {
    return _columnSetCache.get(cacheKey);
  }
  let result = null;
  try {
    const rows = await conn.query(
      `SELECT COLUMN_NAME FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?`,
      [physicalTableName],
    );
    if (Array.isArray(rows) && rows.length) {
      const set = new Set();
      for (const row of rows) {
        const name = row.COLUMN_NAME ?? row.column_name;
        if (typeof name === 'string') set.add(name.toLowerCase());
      }
      result = set.size ? set : null;
    }
  } catch {
    result = null;
  }
  _columnSetCache.set(cacheKey, result);
  return result;
}

// Per-process cache of "is the code-version history table present in this DB".
// Same lifetime assumption as _columnSetCache: schema is stable after boot-time
// migrations. This lets a codeVersioning PUT decide whether versioning is active
// BEFORE folding the version bump into the UPDATE, so the counter never moves
// without its history row landing in the SAME transaction (coherence invariant).
// Keyed by (db, physical history table). A transient/privilege probe failure is
// treated as "unavailable" for this write and NOT cached, so it re-probes.
const _historyTableCache = new Map();
async function isCodeVersionHistoryAvailable(conn, physicalHistoryTable) {
  const dbName = await getConnDatabaseName(conn);
  const key = `${dbName}::${physicalHistoryTable}`;
  if (_historyTableCache.has(key)) return _historyTableCache.get(key);
  let ok;
  try {
    ok = await tableExistsInCurrentSchema(conn, physicalHistoryTable);
  } catch {
    return false;
  }
  _historyTableCache.set(key, ok);
  return ok;
}

// A write key names a column exactly as the column is declared, or it is not a
// write key at all.
//
// SECURITY: a MariaDB column identifier resolves case-insensitively, so
// `` `Template_Id` = ? `` writes `template_id`. Everything upstream that decides
// whether a column MAY be written reads it by its canonical name — `delete
// data[col]` for the id/owner/immutable/scope strips, `data[col] === undefined`
// for the value and enum guards, `data.compute_rule` for the rule validator, and
// the serializers that mask secrets — and a JavaScript property lookup is
// case-sensitive. So a body key spelled with a capital is inspected by NOTHING
// and lands on the real column all the same: the guard reads "column absent,
// nothing to check" about a column the statement then writes.
//
// Every column this repository declares is lower case (mechanically: 221
// distinct columns over all 46 DDLs, none with an upper-case letter), so a
// cased spelling is never a legitimate write, only a way to name a column
// without being seen naming it.
//
// This is dropped HERE, in the shared gate, rather than at each write handler,
// because the same key is emitted into backtick-quoted SQL by six call sites
// across four files — and by whatever the seventh turns out to be. The contract
// of this function is now: A KEY IT RETURNS IS SPELLED EXACTLY AS THE COLUMN IT
// NAMES. Every caller already refuses (or no-ops) an empty key list, so a body
// that consists only of such keys writes nothing rather than writing part of
// itself.
function isCanonicalColumnKey(k) {
  return k === k.toLowerCase();
}

// Filter the write keys against the probed column set. When colSet is null
// (probe unknown) keep every safe key — only a successfully-probed missing
// column is dropped.
function gateKeysByColumnSet(data, colSet) {
  return Object.keys(data)
    .filter(isSafeColumnName)
    .filter(isCanonicalColumnKey)
    .filter((k) => colSet === null ? true : colSet.has(k.toLowerCase()));
}

// The write-handler half of the same rule: the keys a body would have had to
// smuggle past the guards. Returned rather than dropped so the caller can
// answer 400 — a body that is partly ignored is a body whose author was told
// their write landed. Two spellings of one column are refused by the same
// answer rather than merged: a merge is itself the attack shape, the canonical
// key carrying a benign value for whatever reads the body first while the cased
// key carries the real one.
//
// Only the body's OWN top-level keys are examined. Keys nested inside a
// JSON-valued column are values, not identifiers, and are left untouched.
function findNonCanonicalWriteKeys(body) {
  if (!body || typeof body !== 'object' || Array.isArray(body)) return [];
  return Object.keys(body).filter((k) => !isCanonicalColumnKey(k));
}

// Declarative chain DSL for parentOwnership two-hop checks. Validates the
// spec at registration time so a typo fails fast at startup rather than
// 500'ing on the first request.
const TABLE_VALUES = new Set(Object.values(TABLES));

// Opt-in code-versioning spec validator. Fails fast at registration on a bad
// shape (mirrors the parentOwnership validator). Every column name is pinned to
// the identifier whitelist and the history table to the TABLES allowlist because
// all four are interpolated into SQL.
function validateCodeVersioning(spec) {
  if (!spec || typeof spec !== 'object') {
    throw new Error('[codeVersioning]: spec must be an object');
  }
  for (const k of ['watchColumn', 'versionColumn', 'historyFkColumn']) {
    if (!isSafeColumnName(spec[k])) {
      throw new Error(`[codeVersioning]: ${k}=${spec[k]} fails column whitelist`);
    }
  }
  if (!TABLE_VALUES.has(spec.historyTable)) {
    throw new Error(`[codeVersioning]: historyTable=${spec.historyTable} must be a TABLES constant value`);
  }
  return {
    watchColumn: spec.watchColumn,
    versionColumn: spec.versionColumn,
    historyTable: spec.historyTable,
    historyFkColumn: spec.historyFkColumn,
  };
}

// A no-ALTER DB may lack the history table (1146) or the version column (1054).
// Versioning degrades silently in that case; the core CRUD write must still land.
function isMissingTableOrColumn(err) {
  return !!err && (
    err.errno === 1054 || err.errno === 1146
    || err.code === 'ER_BAD_FIELD_ERROR' || err.code === 'ER_NO_SUCH_TABLE'
  );
}

// Warn once per (table) per process so a persistently-degraded DB does not spam
// the log on every write, while a human/log-scraper still sees the gap once.
const _codeVersioningDegraded = new Set();
function warnCodeVersioningDegradedOnce(logicalName, phase) {
  if (_codeVersioningDegraded.has(logicalName)) return;
  _codeVersioningDegraded.add(logicalName);
  logger.warn(
    { table: logicalName, phase },
    'code versioning unavailable (history table or version column missing) — writes proceed without version history; DBA must run the schema migration',
  );
}

function validateAndPrepareParentOwnership(spec, logicalName) {
  if (!spec || typeof spec !== 'object') {
    throw new Error('[parentOwnership]: spec must be an object');
  }
  if (!isSafeColumnName(spec.via)) {
    throw new Error(`[parentOwnership]: via=${spec.via} fails column whitelist`);
  }
  if (!Array.isArray(spec.chain) || spec.chain.length === 0) {
    throw new Error('[parentOwnership]: chain must be a non-empty array of hops');
  }
  for (let i = 0; i < spec.chain.length; i++) {
    const hop = spec.chain[i];
    if (!hop || typeof hop !== 'object') {
      throw new Error(`[parentOwnership]: hop[${i}] must be an object`);
    }
    if (!TABLE_VALUES.has(hop.table)) {
      throw new Error(`[parentOwnership]: hop[${i}].table=${hop.table} must be a TABLES constant value`);
    }
    if (!isSafeColumnName(hop.match)) {
      throw new Error(`[parentOwnership]: hop[${i}].match=${hop.match} fails column whitelist`);
    }
    if (i === 0 && hop.from !== undefined) {
      throw new Error(`[parentOwnership]: hop[0] must not have 'from' field`);
    }
    if (i > 0 && !isSafeColumnName(hop.from)) {
      throw new Error(`[parentOwnership]: hop[${i}].from is required and must be a safe column name`);
    }
    const isTerminal = (i === spec.chain.length - 1);
    if (isTerminal && !isSafeColumnName(hop.readOwner)) {
      throw new Error(`[parentOwnership]: terminal hop must have safe readOwner column (got ${hop.readOwner})`);
    }
    if (!isTerminal && hop.readOwner !== undefined) {
      throw new Error(`[parentOwnership]: non-terminal hop[${i}] must not have 'readOwner' field`);
    }
  }
  // Note: SELECT SQL is rebuilt per request (not at registration time) so
  // runtime prefix changes (e.g. configurePool() after module init) are
  // honoured. Per-request cost is microseconds — string concat only.
  return {
    via: spec.via,
    chain: spec.chain.map((hop) => ({ ...hop })),
    logicalName,
  };
}

// Validate the opt-in parentRepend spec at registration time (mirrors
// validateAndPrepareParentOwnership). A typo in a column/table name fails fast
// at startup rather than 500'ing — and, more importantly, no client-controlled
// value ever reaches the interpolated identifiers below: table is pinned to the
// TABLES allowlist, every column to isSafeColumnName.
function validateAndPrepareParentRepend(spec) {
  if (!spec || typeof spec !== 'object') {
    throw new Error('[parentRepend]: spec must be an object');
  }
  if (!TABLE_VALUES.has(spec.table)) {
    throw new Error(`[parentRepend]: table=${spec.table} must be a TABLES constant value`);
  }
  if (!isSafeColumnName(spec.via)) {
    throw new Error(`[parentRepend]: via=${spec.via} fails column whitelist`);
  }
  if (!isSafeColumnName(spec.statusCol)) {
    throw new Error(`[parentRepend]: statusCol=${spec.statusCol} fails column whitelist`);
  }
  // ownerCol — the parent table's owner column consulted by the non-admin
  // re-pend owner-gate. Defaults to 'owner_id'. Validated at registration so a
  // second adopter whose parent owns rows under a differently-named column opts
  // in explicitly, rather than have the owner-gate SELECT silently fail with
  // errno-1054 (which repandParentInTx swallows as the degraded-DB case → the
  // parent would then never re-pend, leaving an approved parent carrying a
  // swapped child). A bad name fails fast at boot instead.
  const ownerCol = spec.ownerCol === undefined ? 'owner_id' : spec.ownerCol;
  if (!isSafeColumnName(ownerCol)) {
    throw new Error(`[parentRepend]: ownerCol=${spec.ownerCol} fails column whitelist`);
  }
  if (!Array.isArray(spec.clearCols) || !spec.clearCols.every(isSafeColumnName)) {
    throw new Error('[parentRepend]: clearCols must be an array of safe column names');
  }
  // NULL IS AN ADMISSIBLE ENTRY, and the validator says so rather than the
  // caller working around it. A parent whose status is NULL is grandfathered —
  // it still dispatches — so a child write under it is exactly the case a
  // re-pend exists for; requiring every entry to be a non-empty string made the
  // one state that most needs re-pending the one state that could not be named.
  // Anything else non-string is still refused.
  if (!Array.isArray(spec.repandFrom) || spec.repandFrom.length === 0
      || !spec.repandFrom.every((s) => s === null || (typeof s === 'string' && s.length > 0))) {
    throw new Error(
      '[parentRepend]: repandFrom must be a non-empty array of status strings (null allowed, '
      + 'for a grandfathered parent that still dispatches)',
    );
  }
  return {
    table: spec.table,
    via: spec.via,
    statusCol: spec.statusCol,
    ownerCol,
    clearCols: spec.clearCols.slice(),
    repandFrom: spec.repandFrom.slice(),
  };
}

// Build a parameterised SELECT for POST-time owner lookup.
// Emits: SELECT j_LAST.<readOwner> FROM <t0> j0 [JOIN <ti> ji ON ji.match=j(i-1).from] WHERE j0.match = ?
// Caller binds the via-value (e.g. body.field_id) as the only parameter.
function buildChainSelectSql(chain) {
  const last = chain.length - 1;
  let sql = `SELECT j${last}.\`${chain[last].readOwner}\` AS owner_id `
          + `FROM \`${t(chain[0].table)}\` j0`;
  for (let i = 1; i < chain.length; i++) {
    sql += ` JOIN \`${t(chain[i].table)}\` j${i} `
        +  `ON j${i}.\`${chain[i].match}\` = j${i - 1}.\`${chain[i].from}\``;
  }
  sql += ` WHERE j0.\`${chain[0].match}\` = ?`;
  return sql;
}

// Build an EXISTS predicate used in PUT/DELETE WHERE clauses. Combines
// chain-existence + owner-check into a single subquery so editor mutations
// only succeed when (a) the FK chain fully resolves AND (b) the terminal
// owner is NULL (shared) OR equals the caller (req.user.id, bound by the
// caller as a placeholder).
//
// Why EXISTS not a scalar SELECT? A scalar subquery on a broken chain
// (orphan FK row) returns SQL NULL, which the previous shape conflated
// with "shared parent (owner_id IS NULL)" — letting any editor mutate
// orphan child rows just by knowing the row id. EXISTS is unambiguous:
// it returns 0 rows for broken chains, the predicate evaluates false,
// and the UPDATE/DELETE matches no rows. POST already had this property
// via checkParentOwnership's `if (!rows.length) return false` guard;
// PUT/DELETE now match that contract.
function buildChainExistsForRow(chain, logicalName, via) {
  const last = chain.length - 1;
  let sql = `EXISTS (SELECT 1 FROM \`${t(chain[0].table)}\` j0`;
  for (let i = 1; i < chain.length; i++) {
    sql += ` JOIN \`${t(chain[i].table)}\` j${i} `
        +  `ON j${i}.\`${chain[i].match}\` = j${i - 1}.\`${chain[i].from}\``;
  }
  sql += ` WHERE j0.\`${chain[0].match}\` = \`${t(logicalName)}\`.\`${via}\``;
  sql += ` AND (j${last}.\`${chain[last].readOwner}\` IS NULL `
       +  `OR j${last}.\`${chain[last].readOwner}\` = ?))`;
  return sql;
}

/**
 * @openapi
 * /edge/app/schema/{table}:
 *   get:
 *     summary: List records from an engine table
 *     tags: [App - Schema CRUD]
 *     parameters:
 *       - { name: table, in: path, required: true, schema: { type: string }, description: 'Logical table name (e.g. hierarchy_nodes)' }
 *       - { name: sort, in: query, schema: { type: string }, description: 'Column to sort by' }
 *       - { name: order, in: query, schema: { type: string, enum: [asc, desc] } }
 *       - { name: limit, in: query, schema: { type: integer } }
 *     responses:
 *       200: { description: Record list, content: { application/json: { schema: { $ref: '#/components/schemas/ApiResponse' } } } }
 *   post:
 *     summary: Create a record
 *     tags: [App - Schema CRUD]
 *     parameters:
 *       - { name: table, in: path, required: true, schema: { type: string } }
 *     requestBody:
 *       required: true
 *       content: { application/json: { schema: { type: object } } }
 *     responses:
 *       201: { description: Created }
 *       403: { description: Admin required }
 * /edge/app/schema/{table}/{id}:
 *   get:
 *     summary: Get a record by ID
 *     tags: [App - Schema CRUD]
 *     parameters:
 *       - { name: table, in: path, required: true, schema: { type: string } }
 *       - { name: id, in: path, required: true, schema: { type: string } }
 *     responses:
 *       200: { description: Record found }
 *       404: { description: Not found }
 *   put:
 *     summary: Update a record
 *     tags: [App - Schema CRUD]
 *     parameters:
 *       - { name: table, in: path, required: true, schema: { type: string } }
 *       - { name: id, in: path, required: true, schema: { type: string } }
 *     responses:
 *       200: { description: Updated }
 *   delete:
 *     summary: Delete a record
 *     tags: [App - Schema CRUD]
 *     parameters:
 *       - { name: table, in: path, required: true, schema: { type: string } }
 *       - { name: id, in: path, required: true, schema: { type: string } }
 *     responses:
 *       200: { description: Deleted }
 */

/**
 * Generic CRUD factory for schema tables.
 * Read = authenticated, Write = admin only.
 *
 * @param {string} logicalName - The logical table name (WITHOUT prefix). Prefix is resolved
 *   at request time via t() so that runtime prefix changes (e.g. from env vars loaded after
 *   module initialization) are respected.
 * @param {object} opts mount options; see the destructuring at the top of
 *   createCrudRoutes for the set actually read. JSON columns are NOT among them
 *   — those come from the DTO mapper's registry, keyed by table.
 */
// Run an optional write serializer, mapping a fail-closed throw (e.g. the
// connector secret encryptor refusing to persist plaintext when
// SETTINGS_ENCRYPTION_KEY is unset) to a 422 with a clear cause. Returns the
// serialized data, or sends the 422 and returns a sentinel so the caller stops.
const ENCRYPTION_GATE_422 = Symbol('encryption-gate-422');
async function runSerializeWrite(serializeWrite, data, ctx, res) {
  try {
    return await serializeWrite(data, ctx);
  } catch (err) {
    if (err && err.code === 'ENCRYPTION_KEY_MISSING') {
      const e = apiError(
        'Server is missing SETTINGS_ENCRYPTION_KEY; refusing to store this secret unencrypted. Set the key and retry.',
        'ENCRYPTION_KEY_MISSING',
        422,
      );
      res.status(e.status).json(e.body);
      return ENCRYPTION_GATE_422;
    }
    // A serializeWrite validator (e.g. blueprint_fields choice_config shape)
    // rejects a bad payload on the generic create/update path with a 400.
    if (err && err.code === 'INCONSISTENT_FIELD_PAYLOAD') {
      const e = apiError(err.message, 'INCONSISTENT_FIELD_PAYLOAD', 400);
      res.status(e.status).json(e.body);
      return ENCRYPTION_GATE_422;
    }
    // Generic form of the two branches above: a validator states its own HTTP
    // status by tagging the error with BOTH `status` (number) and `code`.
    // Without this, a caller's malformed payload reaches the factory's
    // catch-all and is reported as a 500 server fault. Both tags are required
    // so a driver error (which carries a string `code` like ER_DUP_ENTRY but no
    // `status`) still propagates to the catch-all untouched.
    if (err && typeof err.status === 'number' && typeof err.code === 'string') {
      const e = apiError(err.message, err.code, err.status);
      res.status(e.status).json(e.body);
      return ENCRYPTION_GATE_422;
    }
    throw err;
  }
}


/**
 * May this request attach a row to `blueprintId`?
 *
 * AUTHORIZATION IS DECIDED ABOUT THE ROW THE STATEMENT WILL WRITE, not the row
 * it read. A move resolves TWO blueprints — the one the field leaves and the one
 * it joins — and only the destination is the one the write puts the row under.
 *
 * Existence and node_type are asked of EVERY role, ownership only of an editor.
 * The column carries no foreign key, so an id nobody checked leaves the row
 * unreachable from the hierarchy every schema surface walks, and an
 * administrator's write is no more able to make a variant into a blueprint than
 * an editor's.
 *
 * One SELECT, shared with `editorMayWriteBlueprint` below, so "may this caller
 * write this blueprint" has one spelling rather than the fifth.
 */
async function checkBlueprintWriteTarget(conn, req, blueprintId) {
  if (blueprintId == null) return false;
  const rows = await conn.query(
    `SELECT owner_id FROM \`${t(TABLES.HIERARCHY_NODES)}\`
       WHERE id = ? AND node_type = 'blueprint'`,
    [blueprintId],
  );
  if (!rows.length) return false;
  return isOwnerOrAdmin(conn, TABLES.HIERARCHY_NODES, req, rows[0]);
}

/**
 * May this caller act on a row that carries an owner? Administrator always; a
 * NULL owner means the row is shared and an editor may act; otherwise the row
 * has to be theirs. A plain user reaches here only behind a role gate that has
 * already refused them.
 *
 * ASKED OF THE COLUMN, NOT OF JAVASCRIPT, and that is the whole of this
 * function's move out of shared/helpers.js. `owner_id` is `CHAR(36)` under a
 * case-folding collation, so every SQL-side enforcement point on the same row —
 * the CRUD write scope's `AND (owner_id IS NULL OR owner_id = ?)`, the
 * delegated-grant EXISTS, an index — resolves the true owner for any spelling
 * of their id. A `===` here resolved nobody, and the failure was in the
 * direction that refuses the GENUINE owner: a row whose column holds another
 * spelling of their id was theirs to every statement in the system and nobody's
 * to this check. Rows in that state exist and this PR does not rewrite them, so
 * the reader is what has to answer for them.
 *
 * FAIL-CLOSED: `sameStoredValue` answers `false` for an operand it cannot ask
 * the engine about, and a probe that throws leaves the caller's own catch to
 * refuse. Neither direction admits a stranger.
 *
 * @param {{query: Function}} conn open connection — the caller's own, so the
 *   answer belongs to the same transaction as the write it gates
 * @param {string} table LOGICAL table name (a TABLES constant); prefixed here
 * @param {{user?: {id?: string, role?: string}}} req
 * @param {{owner_id?: string|null}|null|undefined} row the already-fetched row
 * @returns {Promise<boolean>}
 */
async function isOwnerOrAdmin(conn, table, req, row) {
  if (!req.user) return false;
  if (req.user.role === 'admin') return true;
  if (!row) return false;
  if (row.owner_id == null) return true;
  // collation-compare: the question is "does this column name the caller", and
  // the statements that enforce the same answer are all `WHERE owner_id = ?`.
  return sameStoredValue(conn, t(table), 'owner_id', row.owner_id, req.user.id);
}

/**
 * The spelling a row's `id` column actually carries, for a caller that only has
 * the spelling a request named it with.
 *
 * ONE DEFINITION, BECAUSE THE MISTAKE IS ONE MISTAKE. Every gate on a row
 * reference asks SQL, and these columns are `CHAR(36)` under a case-folding
 * collation, so `WHERE id = ?` resolves the row for ANY spelling of its id and
 * the gate passes. A statement that then binds the REQUEST's spelling stores a
 * value every SQL reader resolves and no JavaScript reader does — the front
 * end's `.find(n => n.id === row.parent_id)`, every Map keyed on the stored id,
 * the export fingerprint. So "which spelling does this row carry" is asked once
 * and the answer is what gets bound.
 *
 * Returns null for anything it cannot answer for — a non-string (the identifier
 * floor's business, and a numeric operand reaching a CHAR comparison is the
 * defect that floor exists for), or an id naming no row. A null leaves the
 * caller's value untouched, so this can never become a second opinion about
 * whether a reference is legal.
 *
 * @param {{query: Function}} conn open connection — the caller's own, so the
 *   answer belongs to the same transaction as the statement that binds it
 * @param {string} table LOGICAL table name (a TABLES constant); prefixed here
 * @param {*} id the spelling the request named
 * @returns {Promise<string|null>}
 */
async function storedRowId(conn, table, id) {
  if (typeof id !== 'string' || id.length === 0) return null;
  const rows = await conn.query(
    `SELECT id FROM \`${t(table)}\` WHERE id = ?`, [id],
  );
  // `id` is a PRIMARY KEY, so more than one row is unreachable through this
  // predicate; the shape check is the second lock, because binding `undefined`
  // writes SQL NULL and would detach the row from the parent the caller named.
  const stored = rows.length === 1 ? rows[0].id : null;
  return typeof stored === 'string' && stored.length > 0 ? stored : null;
}

// An editor may only write structural rows under a blueprint they own or
// that is shared (owner_id NULL); admin already passed requireAdminOrEditor
// and bypasses ownership. Returns false so the caller can rollback + 403.
//
// Deliberately NOT the existence check above for a non-editor: this helper's
// nine call sites judge the blueprint a row already sits under, and making an
// administrator's write conditional on that row still existing would turn an
// orphan row from editable into unreachable — a different decision, with its own
// row on the ledger.
async function editorMayWriteBlueprint(conn, req, blueprintId) {
  if (req.user?.role !== 'editor') return true;
  return checkBlueprintWriteTarget(conn, req, blueprintId);
}


// Bound the batch IN-list so a malformed or hostile body can't build an
// unbounded query. A blueprint's select-field count is far below this.
const MAX_BATCH_FIELD_IDS = 1000;
// Same bound for the blueprint_fields batch read; a templates list's unique
// blueprint count is far below this.
const MAX_BATCH_BLUEPRINT_IDS = 1000;
// And the same bound on the option list a single save may carry, for a reason
// that only became true when the duplicate-value guard started asking the
// COLUMN: that probe builds one `UNION ALL` branch per distinct value, so the
// SIZE OF A QUERY now scales with the size of a request body — previously the
// check was an in-process `Set` and the array length never reached the
// database. Bounded only by the 10MB body limit, a save of ~20k options really
// does build a 20k-branch statement and take seconds (measured); at the body
// limit it is several times that.
//
// The number is what an option list plausibly holds with an order of magnitude
// to spare: the largest real ones an operator authors are country (~250) and
// currency (~180) lists, and a checkbox a person actually ticks is far smaller.
// Stated as the same 1000 the two batch bounds above use so there is one number
// to remember rather than three.
const MAX_REPLACE_OPTIONS = 1000;

// Bound the wizard's one-shot copy batch so a malformed or hostile body
// cannot make blueprint-copy-subset.js's per-field/per-section legality and
// cycle checks (each O(n) or worse over the batch) do unbounded work inside
// one open transaction. A field/section list a person actually selects
// through the wizard's tree is far below either number — these are ceilings,
// not realistic sizes, chosen an order of magnitude over a blueprint most
// operators would ever build (a few dozen fields, a handful of sections).
const MAX_COPY_FIELDS = 500;
const MAX_COPY_SECTIONS = 100;

module.exports = {
  TABLES,
  VARIANT_OVERRIDE_ACTIONS,
  pool,
  t,
  getDynamicPool,
  apiOk,
  apiError,
  requireAuth,
  requireAdmin,
  requireAdminOrEditor,
  isOwnerOrAdmin,
  storedRowId,
  uuidv4,
  UUID_RE,
  mapRowFromDb,
  mapRowsFromDb,
  mapRowToDb,
  previewCascade,
  cascadeDeleteNode,
  collectDescendantIds,
  tableExistsInCurrentSchema,
  buildVariantOverrideUpdateExistsClause,
  buildVariantOverrideInsertExistsClause,
  buildDuplicateActionTripleNotExistsClause,
  buildVariantOverrideContextSql,
  applyOwnerChange,
  enrichOwnerNames,
  validateComputeRule,
  detectCycle,
  parseStoredRule,
  extractComputeSources,
  buildEffectiveRules,
  buildFieldContext,
  canonicalRuleJson,
  judgeComputeRulePostState,
  loadBlueprintComputeState,
  loadBlueprintFieldScopes,
  loadBlueprintFieldComputeRule,
  loadBlueprintFieldMode,
  loadVariantComputeRulesByVariant,
  loadVariantCellTargetsByVariant,
  blueprintRuleClosesCycle,
  buildColumnComputeNodes,
  hasColumnCycle,
  hasRowContextSource,
  invalidChoiceConfigShape,
  invalidCellTargetsShape,
  hasCellScope,
  scopeNamesColumn,
  scopeNamesSingleColumn,
  resolveAncestors,
  restampTemplates,
  countAffectedTemplates,
  isValidBlueprintParent,
  logger,
  HIERARCHY_OWNER_AUDIT_EVENT,
  USER_TEMPLATE_OWNER_AUDIT_EVENT,
  resolveOwnershipRwPool,
  cascadeBlueprintOwnerToVariants,
  SAFE_COL_RE,
  isSafeColumnName,
  SLUG_KEY_PATTERN,
  isValidSlugKey,
  isBlueprintLinked,
  isBlueprintLinkedLocked,
  isLinkedParentLocked,
  HIERARCHY_NON_UUID_CHAR_COLUMNS,
  linkTargetOf,
  linkTargetSql,
  effectiveBlueprintIdSql,
  storedNodeId,
  refuseLinkColumnShape,
  effectiveLinkValue,
  auditSchemaClearFailed,
  validateLinkConstraints,
  resolveLinkCheckBlueprintId,
  _columnSetCache,
  getConnDatabaseName,
  getActualColumnSet,
  _historyTableCache,
  isCodeVersionHistoryAvailable,
  gateKeysByColumnSet,
  isCanonicalColumnKey,
  findNonCanonicalWriteKeys,
  TABLE_VALUES,
  validateCodeVersioning,
  isMissingTableOrColumn,
  _codeVersioningDegraded,
  warnCodeVersioningDegradedOnce,
  validateAndPrepareParentOwnership,
  validateAndPrepareParentRepend,
  buildChainSelectSql,
  buildChainExistsForRow,
  ENCRYPTION_GATE_422,
  runSerializeWrite,
  editorMayWriteBlueprint,
  checkBlueprintWriteTarget,
  MAX_BATCH_FIELD_IDS,
  MAX_BATCH_BLUEPRINT_IDS,
  MAX_REPLACE_OPTIONS,
  MAX_COPY_FIELDS,
  MAX_COPY_SECTIONS,
};
