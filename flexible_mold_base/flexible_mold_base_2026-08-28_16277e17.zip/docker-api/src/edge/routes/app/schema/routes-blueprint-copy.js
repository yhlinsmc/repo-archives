'use strict';

/**
 * routes-blueprint-copy.js — POST /blueprint-copy-subset, the wizard's one
 * write. Everything the copy decides (key collisions, dependency breaks,
 * compute-rule legality against the TARGET's own graph, snapshot
 * consistency) is judged and written on one connection inside one
 * transaction by `copyBlueprintFieldSubset` — this file is the HTTP shell:
 * auth, shape-check the body, map the module's error codes to responses.
 */
const {
  TABLES,
  t,
  apiOk,
  apiError,
  requireAdminOrEditor,
  editorMayWriteBlueprint,
  isBlueprintLinkedLocked,
  uuidv4,
  UUID_RE,
  logger,
  MAX_COPY_FIELDS,
  MAX_COPY_SECTIONS,
} = require('./helpers');
const { resolveRwPool } = require('./request-pool');
const { copyBlueprintFieldSubset, CopySubsetError } = require('../../../lib/blueprint-copy-subset');
const { BLUEPRINT_FIELD_KEY_REFERENCE_COLUMNS } = require('../../../lib/blueprint-field-key-references');

function isPlainObject(v) {
  return !!v && typeof v === 'object' && !Array.isArray(v);
}

/** Shallow shape-check of the body — DB-dependent judgement (keys, cycles,
 *  snapshot) is `copyBlueprintFieldSubset`'s job, not this gate's. */
function bodyShapeErrors(body) {
  const errors = [];
  if (!UUID_RE.test(body.source_blueprint_id || '')) errors.push('source_blueprint_id must be a UUID');
  if (!UUID_RE.test(body.target_blueprint_id || '')) errors.push('target_blueprint_id must be a UUID');
  if (body.source_blueprint_id === body.target_blueprint_id) errors.push('source and target must differ');
  if (!Array.isArray(body.fields) || body.fields.length === 0) {
    errors.push('fields must be a non-empty array');
  } else if (body.fields.length > MAX_COPY_FIELDS) {
    // Bounded here, before the per-item walk and before the DB-layer batch
    // lookup, same discipline as MAX_REPLACE_OPTIONS (routes-field-options.js):
    // a hostile or malformed body must not make blueprint-copy-subset.js's
    // per-item legality/cycle checks do unbounded work inside an open
    // transaction.
    errors.push(`fields exceeds the ${MAX_COPY_FIELDS}-item limit (sent ${body.fields.length})`);
  } else {
    body.fields.forEach((f, i) => {
      if (!isPlainObject(f)) { errors.push(`fields[${i}] must be an object`); return; }
      if (typeof f.source_field_id !== 'string' || !f.source_field_id) errors.push(`fields[${i}].source_field_id is required`);
      if (typeof f.new_key !== 'string' || !f.new_key) errors.push(`fields[${i}].new_key is required`);
      if (typeof f.label !== 'string' || !f.label) errors.push(`fields[${i}].label is required`);
      if (f.drop_refs !== undefined) {
        if (!Array.isArray(f.drop_refs) || !f.drop_refs.every((c) => BLUEPRINT_FIELD_KEY_REFERENCE_COLUMNS.includes(c))) {
          errors.push(`fields[${i}].drop_refs must be an array drawn from: ${BLUEPRINT_FIELD_KEY_REFERENCE_COLUMNS.join(', ')}`);
        }
      }
    });
    // P2-3 (round 3): a repeated source_field_id passes every per-item check
    // above (each item is independently well-shaped) but downstream
    // `new_field_ids` is keyed by source id, so the second copy silently
    // overwrites the first entry in that map, and the option-copy loop
    // attaches the source's options only to the LAST inserted field — the
    // first copy is left without its options. Caught here, before the
    // transaction opens, same discipline as the length caps above.
    const seenSourceFieldIds = new Set();
    body.fields.forEach((f, i) => {
      if (typeof f.source_field_id !== 'string' || !f.source_field_id) return; // already errored above
      if (seenSourceFieldIds.has(f.source_field_id)) {
        errors.push(`fields[${i}].source_field_id '${f.source_field_id}' is duplicated in this request`);
      }
      seenSourceFieldIds.add(f.source_field_id);
    });
  }
  // Per-item shape, same discipline as `fields` above — a malformed item must
  // fail here with a named error, never resolve to `undefined` and be
  // silently skipped by the DB-layer lookup that follows.
  if (body.sections !== undefined) {
    if (!Array.isArray(body.sections)) {
      errors.push('sections must be an array');
    } else if (body.sections.length > MAX_COPY_SECTIONS) {
      errors.push(`sections exceeds the ${MAX_COPY_SECTIONS}-item limit (sent ${body.sections.length})`);
    } else {
      body.sections.forEach((s, i) => {
        if (!isPlainObject(s)) { errors.push(`sections[${i}] must be an object`); return; }
        if (typeof s.source_section_key !== 'string' || !s.source_section_key) errors.push(`sections[${i}].source_section_key is required`);
        if (typeof s.new_key !== 'string' || !s.new_key) errors.push(`sections[${i}].new_key is required`);
        if (s.display_label !== undefined && typeof s.display_label !== 'string') errors.push(`sections[${i}].display_label must be a string`);
      });
      // P2-3, same shape as the fields duplicate check above: a repeated
      // source_section_key would leave sectionRewriteMap
      // (blueprint-copy-subset.js) keyed by the LAST item only, silently
      // dropping the earlier item's mapping.
      const seenSourceSectionKeys = new Set();
      body.sections.forEach((s, i) => {
        if (typeof s.source_section_key !== 'string' || !s.source_section_key) return; // already errored above
        if (seenSourceSectionKeys.has(s.source_section_key)) {
          errors.push(`sections[${i}].source_section_key '${s.source_section_key}' is duplicated in this request`);
        }
        seenSourceSectionKeys.add(s.source_section_key);
      });
    }
  }
  if (body.source_snapshot !== undefined && !isPlainObject(body.source_snapshot)) errors.push('source_snapshot must be an object');
  if (body.source_section_snapshot !== undefined && !isPlainObject(body.source_section_snapshot)) errors.push('source_section_snapshot must be an object');
  return errors;
}

const ERROR_STATUS = {
  EMPTY_SELECTION: 400,
  INVALID_SELECTION: 400,
  INVALID_COMPUTE_RULE: 400,
  SOURCE_CHANGED: 409,
  DUPLICATE_FIELD_KEY: 409,
  DUPLICATE_SECTION_KEY: 409,
  NOT_FOUND: 404,
  FORBIDDEN: 403,
  INTERNAL: 500,
};

function register(router) {

router.post('/blueprint-copy-subset', async (req, res) => {
  if (!requireAdminOrEditor(req, res)) return;
  const body = req.body || {};
  const shapeErrors = bodyShapeErrors(body);
  if (shapeErrors.length) {
    const e = apiError('Validation failed', 'BAD_REQUEST', 400);
    return res.status(e.status).json({ ...e.body, validation_errors: shapeErrors });
  }

  const { source_blueprint_id: sourceId, target_blueprint_id: targetId } = body;
  let conn;
  try {
    conn = await (await resolveRwPool(req)).getConnection();
    await conn.beginTransaction();

    // Lock the target row FOR UPDATE for the whole write — mirrors
    // overwriteBlueprint's own first step, same reason: two concurrent
    // copies into the same target must not interleave their key-collision
    // reads with each other's INSERTs.
    const targetRows = await conn.query(
      `SELECT id, owner_id FROM \`${t(TABLES.HIERARCHY_NODES)}\`
        WHERE id = ? AND node_type = 'blueprint' FOR UPDATE`,
      [targetId],
    );
    if (!targetRows.length) {
      await conn.rollback();
      return res.status(404).json(apiError('Target blueprint not found', 'NOT_FOUND', 404).body);
    }
    if (!(await editorMayWriteBlueprint(conn, req, targetId))) {
      await conn.rollback();
      return res.status(403).json(apiError('Not allowed: blueprint is not owned by you and is not shared', 'FORBIDDEN', 403).body);
    }
    // Same guard every sibling schema-write mount carries
    // (`rejectIfParentLinked:{column:'blueprint_id'}` in schema/index.js) —
    // a linked blueprint's schema is a read-only mirror of its source, and
    // this route inserts rows exactly like those mounts do.
    if (await isBlueprintLinkedLocked(conn, targetId)) {
      await conn.rollback();
      const e = apiError(
        'Cannot edit the schema of a linked blueprint; edit the source blueprint instead',
        'LINKED_BLUEPRINT_READONLY', 409,
      );
      return res.status(e.status).json(e.body);
    }
    const sourceRows = await conn.query(
      `SELECT id FROM \`${t(TABLES.HIERARCHY_NODES)}\` WHERE id = ? AND node_type = 'blueprint'`,
      [sourceId],
    );
    if (!sourceRows.length) {
      await conn.rollback();
      return res.status(404).json(apiError('Source blueprint not found', 'NOT_FOUND', 404).body);
    }

    const result = await copyBlueprintFieldSubset(conn, { t, TABLES, uuidv4 }, {
      sourceId,
      targetId,
      sections: Array.isArray(body.sections) ? body.sections : [],
      fields: body.fields,
      sourceSnapshot: isPlainObject(body.source_snapshot) ? body.source_snapshot : {},
      sourceSectionSnapshot: isPlainObject(body.source_section_snapshot) ? body.source_section_snapshot : {},
    });
    await conn.commit();
    return res.json(apiOk({ ok: true, ...result }));
  } catch (err) {
    try { if (conn) await conn.rollback(); } catch (rbErr) {
      logger.warn({ err: rbErr }, 'rollback after blueprint-copy-subset failed');
    }
    if (err instanceof CopySubsetError) {
      const status = ERROR_STATUS[err.code] || 400;
      const e = apiError(err.message, err.code, status);
      return res.status(e.status).json({ ...e.body, ...(err.details || {}) });
    }
    logger.error({ err }, 'Failed to copy blueprint subset');
    const e = apiError('Copy failed', 'INTERNAL_ERROR');
    return res.status(e.status).json(e.body);
  } finally {
    if (conn) conn.release();
  }
});

}

module.exports = { register };
