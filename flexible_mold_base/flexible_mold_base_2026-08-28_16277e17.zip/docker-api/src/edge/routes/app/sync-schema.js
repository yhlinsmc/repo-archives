const express = require('express');
const router = express.Router();
const { pool, t, getDbConfigFull, getDynamicPool } = require('../../db');
const { buildEngineTableDDLs, ENGINE_TABLE_NAMES } = require('../../../table-ddls');
const { apiOk, apiError, requireAdmin, uuidv4 } = require('../../../shared/helpers');
const { TABLES } = require('../../../shared/constants');
const { escapeString, splitSqlStatements } = require('../../../sql-utils');
const { logger: rootLogger } = require('../../../shared/lib/logger');
// NOTE: requirePrefix() replaces the silent `|| 'fmb_'` fallback.
// Routes here operate against a target connection profile, not the
// in-memory pool, so they can't always go through `t()` — but they
// still need a non-empty prefix or the resulting table identifier is
// nonsense. requirePrefix throws PoolNotConfiguredError instead.
const { requirePrefix, PoolNotConfiguredError } = require('../../../shared/lib/db-errors');
const { signWipeToken, verifyWipeToken } = require('../../../shared/lib/wipe-token');
const { buildEngineSeedSql } = require('../../lib/engine-seed-sql');
const { buildExportFilename, contentDispositionAttachment } = require('../../../shared/lib/export-filename');
const { actualColumns } = require('../../lib/portable-insert');
const { USER_TEMPLATE_METADATA_COLUMN_NAMES } = require('../../lib/user-template-metadata');

// NOTE: PoolNotConfiguredError is a setup-state condition (operator hasn't
// configured the target prefix), not a mid-operation DB failure. Surface it
// as 503 + POOL_NOT_CONFIGURED so the client can distinguish "needs setup"
// from "DB hiccup".
function maybeHandlePoolNotConfigured(err, res) {
  if (err instanceof PoolNotConfiguredError) {
    const e = apiError(err.message, err.code || 'POOL_NOT_CONFIGURED', err.status || 503);
    res.status(e.status).json(e.body);
    return true;
  }
  return false;
}
const logger = rootLogger.child({ module: 'sync-schema' });

// Hoisted regex for ISO 8601 timestamp detection (used in hot-path buildUpsert)
const ISO_DATETIME_RE = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}/;
const ISO_FRACTIONAL_TZ_RE = /\.\d+([+-]\d{2}:\d{2}|Z)$/;

/**
 * POST /api/sync-schema
 * Receives full schema + seed data from the source environment and upserts into MariaDB.
 *
 * Body: {
 *   action: 'full_sync' | 'schema_only' | 'data_only',
 *   tables: {
 *     system_settings: [...rows],
 *     hierarchy_nodes: [...rows],
 *     blueprint_fields: [...rows],
 *     field_options: [...rows],
 *     blueprint_sections: [...rows],
 *     blueprint_groups: [...rows],
 *     blueprint_output_order: [...rows],
 *     variant_overrides: [...rows],
 *     user_templates: [...rows],   // optional
 *   }
 * }
 */

/**
 * @openapi
 *
 * /edge/app/sync-schema:
 *   post:
 *     tags: [App - Sync Schema]
 *     summary: Upsert full schema + seed data from Cloud into MariaDB.
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [action]
 *             properties:
 *               action:
 *                 type: string
 *                 enum: [full_sync, schema_only, data_only]
 *               tables:
 *                 type: object
 *                 description: Map of logical table name → row array.
 *               db:
 *                 type: object
 *                 description: Optional target DB config (injected by X-Database middleware).
 *     responses:
 *       200:
 *         description: Sync report.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *       400:
 *         description: Invalid action.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *
 * /edge/app/sync-schema/status:
 *   get:
 *     tags: [App - Sync Schema]
 *     summary: Return row counts for all engine tables.
 *     responses:
 *       200:
 *         description: Table row counts (−1 means table does not exist).
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *
 * /edge/app/sync-schema/export-sql:
 *   get:
 *     tags: [App - Sync Schema]
 *     summary: Export engine table DDL + data as SQL with __PREFIX__ placeholders.
 *     responses:
 *       200:
 *         description: SQL string and per-table row counts.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *
 * /edge/app/sync-schema/import-sql:
 *   post:
 *     tags: [App - Sync Schema]
 *     summary: Execute a SQL file, replacing __PREFIX__ with the configured table prefix.
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [sql]
 *             properties:
 *               sql:
 *                 type: string
 *                 description: Raw SQL with __PREFIX__ placeholders.
 *               db:
 *                 type: object
 *                 description: Optional target DB config.
 *     responses:
 *       200:
 *         description: Number of executed statements and any errors.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *       400:
 *         description: Missing sql field.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *
 * /edge/app/sync-schema/truncate-table:
 *   post:
 *     tags: [App - Sync Schema]
 *     summary: Truncate (clear all rows from) an engine table.
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [table]
 *             properties:
 *               table:
 *                 type: string
 *                 description: Logical table name, e.g. blueprint_fields.
 *               db:
 *                 type: object
 *                 description: Optional target DB config.
 *     responses:
 *       200:
 *         description: Truncation confirmation.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *       400:
 *         description: Invalid table name.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *
 * /edge/app/sync-schema/drop-table:
 *   post:
 *     tags: [App - Sync Schema]
 *     summary: Drop an engine table (IF EXISTS).
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [table]
 *             properties:
 *               table:
 *                 type: string
 *                 description: Logical table name, e.g. blueprint_fields.
 *               db:
 *                 type: object
 *                 description: Optional target DB config.
 *     responses:
 *       200:
 *         description: Drop confirmation.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *       400:
 *         description: Invalid table name.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 */

// Table definitions: logical name → { prefixed name, cols, json cols }
const TABLE_DEFS = {
  system_settings: {
    cols: ['id', 'key', 'value', 'description', 'updated_by', 'created_at', 'updated_at'],
    json: ['value'],
  },
  hierarchy_nodes: {
    // naming_rule is additive (colSet-gated at write time, same tolerance as
    // the other additive columns in this file), so a pre-migration target
    // drops it instead of 500ing.
    cols: ['id', 'parent_id', 'name', 'node_type', 'description', 'naming_rule', 'sort_order', 'is_active',
           'transformer_id', 'transformer_version', 'linked_blueprint_id', 'created_at', 'updated_at'],
    json: [],
    nullableStrings: ['description', 'naming_rule'],
  },
  blueprint_fields: {
    // retain_when_hidden / depends_on_field_key / choice_config / group_key /
    // matrix_row_key are additive columns gated at write time against the
    // target's real column set (see buildUpsert colSet), so a target DB that
    // predates their migration drops them instead of 500ing.
    cols: ['id', 'blueprint_id', 'field_key', 'field_label', 'field_type', 'is_required',
           'default_value', 'placeholder', 'tooltip', 'section', 'group_key', 'matrix_row_key', 'order_index',
           'table_config', 'visibility_rule', 'depends_on_field_key', 'retain_when_hidden',
           'choice_config', 'created_at'],
    json: ['table_config', 'visibility_rule', 'choice_config'],
    // depends_on_field_key / group_key / matrix_row_key are nullable key
    // references the DTO mapper coalesces to '' on read (dto-mapper.js
    // blueprint_fields.nullableStrings); list them here so the cross-environment
    // sync UPSERT coerces an incoming null to '' too, keeping the synced row
    // byte-identical to what the API serves (parity with the existing `section`
    // sibling).
    nullableStrings: ['default_value', 'placeholder', 'tooltip', 'section', 'depends_on_field_key', 'group_key', 'matrix_row_key'],
  },
  field_options: {
    cols: ['id', 'field_id', 'option_label', 'option_value', 'sort_order', 'created_at'],
    json: [],
  },
  blueprint_sections: {
    // layout_mode / matrix_copy are additive (colSet-gated, same tolerance as above).
    cols: ['id', 'blueprint_id', 'section_key', 'display_label', 'sort_order', 'layout_mode', 'matrix_copy', 'created_at'],
    json: [],
    nullableStrings: ['display_label'],
    // Blueprint-scoped unique (blueprint_id, section_key). Drives the sync
    // collision guard so an incoming row whose key already belongs to a
    // different id is skipped + reported instead of silently overwriting it.
    blueprintScopedUnique: { scope: 'blueprint_id', key: 'section_key' },
  },
  blueprint_groups: {
    cols: ['id', 'blueprint_id', 'group_key', 'display_label', 'color_key', 'sort_order', 'created_at'],
    json: [],
    nullableStrings: ['display_label', 'color_key'],
    nullableNumbers: { sort_order: 0 },
    blueprintScopedUnique: { scope: 'blueprint_id', key: 'group_key' },
  },
  blueprint_output_order: {
    cols: ['id', 'blueprint_id', 'output_key', 'sort_order', 'format', 'created_at'],
    json: [],
    nullableNumbers: { sort_order: 0 },
    // format is NOT NULL DEFAULT 'json' at the DDL — a source row always
    // carries a real value, and a target that has not yet migrated simply
    // drops the column via the colSet probe (buildUpsert), same as any other
    // purely-additive column here.
  },
  variant_overrides: {
    cols: ['id', 'variant_id', 'field_id', 'action', 'override_value', 'created_at'],
    json: [],
  },
  user_templates: {
    // generation_id and user_id are intentionally NOT synced — both are
    // legacy columns dropped from the schema (generation_id in an earlier
    // cleanup; user_id in a later cleanup, T9; category_id/owner_id are the
    // authoritative replacements). Listing either would make the raw SQL-dump
    // export emit it in INSERTs, which then fail with an unknown-column error
    // when imported into a target that has already dropped the column (the
    // SQL-text import path is not column-probe-gated, unlike buildUpsert).
    // The only thing not carried is a pre-drop peer's now-gone-column-only
    // link — that cross-version sync gap is accepted the same way the
    // generation_id EXPAND→CONTRACT phasing already accepted it.
    //
    // The field-key-indexed metadata columns are spread from their shared
    // declaration, on both lines. They are additive (colSet-gated at write time,
    // same tolerance as blueprint_fields' above), and carrying them is the point
    // rather than a nicety: each records a choice the operator made ABOUT AN
    // ABSENCE — an alias picked, a computed value overridden, a field emptied
    // deliberately. A record that arrives without them looks like a record
    // nobody has touched, so the target re-fills the very blanks that were left
    // on purpose. They are NOT in nullableStrings: NULL means "nothing recorded"
    // and coalescing it to '' would store a document that parses as neither.
    cols: ['id', 'name', 'category_id', 'release_id', 'blueprint_id', 'variant_id',
           'payload', 'generated_outputs', 'parent_id', 'schema_version', 'created_at', 'updated_at',
           ...USER_TEMPLATE_METADATA_COLUMN_NAMES],
    json: ['payload', 'generated_outputs', ...USER_TEMPLATE_METADATA_COLUMN_NAMES],
    nullableStrings: ['name', 'schema_version'],
  },
};

// NOTE: flow_recipe_* are intentionally absent here (like api_connectors):
// flow_recipe_steps.auth_config holds AES-256-GCM secrets that must not be
// carried across environments by generic SQL data-sync (the target env has a
// different SETTINGS_ENCRYPTION_KEY and would store unusable ciphertext). A
// secret-aware flow export is separate future work.

// NOTE: transformers / transformer_versions are likewise intentionally absent.
// Their `code` column holds executable JS transformer source; a generic
// cross-env SQL data-sync would silently propagate code between environments,
// which must be an explicit, reviewed action rather than a side effect of a
// schema/data sync. transformer_versions history also diverges per environment,
// so its UNIQUE(transformer_id, version) would collide against version rows the
// target already accrued independently. A dedicated, explicit transformer
// export is separate future work.

// NOTE: cap_* (Capacity Planner) engine tables are intentionally absent from
// SYNC_ORDER / TABLE_DEFS as a STAGED decision (not a secret/history reason):
// PR-A ships the tables + CRUD foundation. Capacity cross-env data-sync carries
// scenario-self-containment semantics (template scenario_id-IS-NULL rows vs
// deep-copied scenario rows; FK-order over the site→spec→hypervisor→vm→
// db_instance chain) that belong with the usable data model in a later capacity
// PR — wiring them here with half-defined TABLE_DEFS would ship untested sync.
// The drift guard (table-registry-drift-guard.test.js) records the matching
// exclusion; flip to SYNC_ORDER when capacity sync ships.

// NOTE: flow_recipe_code_versions is likewise intentionally absent — it is
// per-environment audit of recipe payload_transform_code changes, and its
// UNIQUE(recipe_id, version) would collide against version rows the target
// accrued independently. The recipe export/import path (flow-recipes/io.js)
// carries only the current code and starts a fresh version chain on import.

// NOTE: decision_tables is intentionally absent as a STAGED decision (same
// class as cap_*, not a secret/history reason): PR 5-A ships the table + CRUD
// foundation. Its `doc` references blueprint fields BY KEY (field_key) and
// option VALUES, so a cross-env sync has to interact with the same key-flip /
// collision-withhold machinery blueprint_fields and blueprint_groups already
// need — wiring that with half-defined TABLE_DEFS would ship untested sync. The
// drift guard (table-registry-drift-guard.test.js) records the matching
// exclusion; flip to SYNC_ORDER when decision-table sync ships.
//
// SECOND, RELATED GAP — blueprint export/import does not carry decision_tables
// either (blueprint-serialization.js loadRawExport builds the payload from
// blueprint_fields / field_options / blueprint_sections / blueprint_groups /
// blueprint_output_order only). So until decision-table sync ships there is NO
// supported way to move a decision table between environments, by sync or by
// export; the two gaps stand or fall together and are recorded together so the
// sync note is not read as "sync is the only gap". An overwrite-import DELETEs
// the target's decision tables and reports the count, rather than leaving rules
// silently re-bound by key onto a replaced schema.

// NOTE: delegated_grants and template_activity are intentionally absent, and
// for a reason of their own rather than the staged one above. Both name USERS —
// a grantee, a granter, an actor — and a user id is environment-local: the same
// person has a different row in each environment (and may have no row at all in
// the target). Copying either table across would hand a permission to whichever
// account happens to hold that id in the target, or attribute an action to
// nobody. The activity trail is additionally a record of what happened HERE, and
// a trail that arrives by copy from another environment is not that.
// The drift guard (table-registry-drift-guard.test.js) records the matching
// exclusion. Moving grants between environments is a per-environment granting
// decision, not a sync.

// NOTE: template_snapshots is intentionally absent, same
// reason as delegated_grants/template_activity directly above: it names a
// USER (actor_id, environment-local) and it is a per-operator checkpoint of a
// specific record's draft, not blueprint-authoring content meant to travel
// between environments. A copied snapshot would attribute a save to whichever
// account happens to hold that actor id in the target, or to nobody.
// The drift guard (table-registry-drift-guard.test.js) records the matching
// exclusion.

// Order matters: parents first to satisfy foreign-key-like semantics
const SYNC_ORDER = [
  'system_settings',
  'hierarchy_nodes',
  'blueprint_fields',
  'field_options',
  'blueprint_sections',
  'blueprint_groups',
  'blueprint_output_order',
  'variant_overrides',
  'user_templates',
];

// A field_options row is "dirty" when a required option string is null,
// non-string, or whitespace-only. Such a row can never be a Radix Select
// item and gates connector-ready off, so sync skips it rather than
// persisting it — non-blocking, mirroring table-column-options' defensive
// skip.
const isEmptyOptionStr = (v) => v == null || typeof v !== 'string' || v.trim() === '';

/**
 * Build UPSERT SQL: INSERT ... ON DUPLICATE KEY UPDATE ...
 * Uses prefixFn (defaults to t()) to resolve the physical table name.
 */
function buildUpsert(logicalName, def, row, prefixFn, colSet, withholdCols) {
  const physicalTable = (prefixFn || t)(logicalName);
  // colSet null = probe unavailable → keep every defined col (tolerant unknown);
  // a successfully-probed missing column is dropped so the INSERT never names a
  // column the target DB lacks.
  // withholdCols (optional per-row set) must drop a column from BOTH the INSERT
  // column list AND the ON DUPLICATE KEY UPDATE clause for this row: dropping it
  // from only the INSERT would still let the duplicate-key path overwrite the
  // target's existing value with VALUES(col), so the column has to be absent
  // from usedCols entirely to be truly held back.
  const usedCols = def.cols.filter((c) =>
    row[c] !== undefined
    && (colSet == null || colSet.has(c.toLowerCase()))
    && !(withholdCols && withholdCols.has(c)));
  const colList = usedCols.map((c) => `\`${c}\``).join(', ');
  const placeholders = usedCols.map(() => '?').join(', ');

  // Columns whose incoming explicit-null was coerced to a default ('' / 0) for
  // the INSERT. Tracked so they can be excluded from the ON DUPLICATE KEY
  // UPDATE set below.
  const coercedDefaults = new Set();

  const values = usedCols.map((c) => {
    let v = row[c];
    if (v === undefined || v === null) {
      if (def.nullableNumbers && Object.prototype.hasOwnProperty.call(def.nullableNumbers, c)) {
        coercedDefaults.add(c);
        return def.nullableNumbers[c];
      }
      if (def.nullableStrings?.includes(c)) {
        coercedDefaults.add(c);
        return '';
      }
      return null;
    }
    if (def.json.includes(c) && typeof v !== 'string') return JSON.stringify(v);
    if (typeof v === 'boolean') return v ? 1 : 0;
    // Convert ISO 8601 timestamps to MariaDB DATETIME format.
    // e.g. '2026-03-08T14:38:00.926066+00:00' → '2026-03-08 14:38:00'.
    if (typeof v === 'string' && ISO_DATETIME_RE.test(v)) {
      return v.replace('T', ' ').replace(ISO_FRACTIONAL_TZ_RE, '').replace(/Z$/, '');
    }
    return v;
  });

  // DATA-INTEGRITY: exclude coerced-default columns from the UPDATE set so a
  // replayed legacy payload carrying explicit nulls cannot overwrite an
  // existing row's real value with '' / 0. New rows still receive the default
  // via INSERT; existing rows keep their data on the duplicate-key path.
  const updates = usedCols
    .filter((c) => c !== 'id' && !coercedDefaults.has(c))
    .map((c) => `\`${c}\` = VALUES(\`${c}\`)`)
    .join(', ');

  // If every non-id column was a coerced default, fall back to a no-op id
  // self-assign so the statement stays a valid idempotent upsert rather than
  // erroring on the duplicate key.
  const hasNonIdCols = usedCols.some((c) => c !== 'id');
  const updateClause = updates || (hasNonIdCols ? '`id` = `id`' : '');

  const sql = `INSERT INTO \`${physicalTable}\` (${colList}) VALUES (${placeholders})` +
    (updateClause ? ` ON DUPLICATE KEY UPDATE ${updateClause}` : '');
  return { sql, values };
}

// ── DDL: ensure engine tables exist (schema_only / full_sync) ──────────────
// Use buildEngineTableDDLs(t) instead of sql/init.sql so only the
// engine tables are created with the correct prefix.
async function applyDDL(conn, prefixFn) {
  const fn = prefixFn || t;
  for (const ddl of buildEngineTableDDLs(fn)) {
    try {
      await conn.query(ddl);
    } catch (e) {
      if (!e.message.includes('Duplicate') && !e.message.toLowerCase().includes('already exists')) {
        logger.warn({ err: e }, 'DDL warning');
      }
    }
  }
}

// ── Engine table names (logical) — single source of truth from table-ddls.js
const ENGINE_TABLES = ENGINE_TABLE_NAMES;

// ── Data sync ────────────────────────────────────────────────────────────────
// Cap the surfaced collision-key sample so the API response stays bounded even
// if a pathological payload collides on thousands of rows (the count is exact;
// only the key list is capped).
const COLLISION_KEYS_CAP = 50;

// Composite map key for a blueprint-scoped unique pair. NUL joins the two parts
// so distinct (scope, key) pairs cannot alias via string concatenation.
// Case is folded to lower on both parts because the live column collation is
// utf8mb4_general_ci (case-INSENSITIVE): the DB UNIQUE index and the migration
// dedupe self-join both treat a key and its case variant as the same value, so
// the JS pre-check must too or a case-variant slips past it and ODKU silently
// clobbers the existing row. toLowerCase() suits the slug alphabet.
function scopedUniqueMapKey(scopeVal, keyVal) {
  return `${String(scopeVal).toLowerCase()}\x00${String(keyVal).toLowerCase()}`;
}

// blueprint_fields columns that carry a blueprint_groups.group_key reference.
// This is the exact referrer set the db.js dedup migration repairs (group_key
// added 3.2.421, matrix_row_key 3.2.424); fields.section is deliberately NOT
// here because the codebase models no fields→blueprint_sections referrer repair.
const FIELD_GROUP_KEYREF_COLS = ['group_key', 'matrix_row_key'];

// Load the target's existing (scope, key) owners for a blueprint-scoped-unique
// table. Returns { rows, degraded }. In both fallback cases (scope/key column
// absent on the target, or the probe throws) the intra-payload claim logic
// still runs and the DB UNIQUE remains the final backstop, but the two cases
// differ in visibility: a missing column is a legit pre-migration operator DB
// state (log only), whereas a probe FAILURE means the pre-existing-owner half
// of the guard could not run at all → degraded:true so the report can say so.
async function loadScopedOwnerRows(conn, logicalName, def, prefixFn, colSet) {
  const scopedUnique = def.blueprintScopedUnique;
  if (!(colSet == null || (colSet.has(scopedUnique.scope) && colSet.has(scopedUnique.key)))) {
    logger.warn(
      { table: logicalName },
      'blueprint-scoped unique guard skipped: target missing scope/key column',
    );
    return { rows: [], degraded: false };
  }
  try {
    const existing = await conn.query(
      `SELECT id, \`${scopedUnique.scope}\` AS scopeVal, \`${scopedUnique.key}\` AS keyVal FROM \`${prefixFn(logicalName)}\``,
    );
    return { rows: Array.isArray(existing) ? existing : [], degraded: false };
  } catch (e) {
    logger.warn({ table: logicalName, err: e }, 'blueprint-scoped unique pre-load skipped');
    return { rows: [], degraded: true };
  }
}

// Load the target's existing blueprint_id per incoming blueprint_fields id.
// Only called when at least one group key was collision-skipped (so a withhold
// is possible); used to detect a field being MOVED to a different blueprint
// while its group refs are withheld — that row is skipped whole, because
// keeping the old-scope keys and still moving blueprint_id would drag them into
// a blueprint that has no such group. Returns { map, degraded }: map is a
// Map(id -> blueprint_id) on success (null when the probe failed), degraded:true
// on failure so the caller can surface the fallback (column-withhold only, the
// cross-blueprint move can no longer be detected) instead of silently reverting.
async function loadExistingFieldBlueprints(conn, fieldRows, prefixFn) {
  const ids = [...new Set(fieldRows.map((r) => r.id).filter((id) => id != null))];
  if (!ids.length) return { map: new Map(), degraded: false };
  const physical = prefixFn('blueprint_fields');
  const CHUNK = 500; // bound the IN-list / placeholder count per statement
  const map = new Map();
  try {
    for (let i = 0; i < ids.length; i += CHUNK) {
      const chunk = ids.slice(i, i + CHUNK);
      const placeholders = chunk.map(() => '?').join(', ');
      const existing = await conn.query(
        `SELECT \`id\`, \`blueprint_id\` FROM \`${physical}\` WHERE \`id\` IN (${placeholders})`,
        chunk,
      );
      if (Array.isArray(existing)) {
        for (const r of existing) map.set(r.id, r.blueprint_id);
      }
    }
    return { map, degraded: false };
  } catch (e) {
    logger.warn(
      { table: 'blueprint_fields', err: e },
      'existing-blueprint pre-load skipped; cross-blueprint field-move guard degraded',
    );
    return { map: null, degraded: true };
  }
}

// Decide, for one blueprint-scoped-unique table, which incoming rows collide
// (their (scope, key) already belongs to a DIFFERENT id — either a pre-existing
// target row or an earlier same-payload claim). Pure over the loaded owners so
// the same decision drives BOTH the row skip (for this table) and the field
// key-flip withholding (for blueprint_fields, computed before the main loop
// because blueprint_fields is synced ahead of blueprint_groups in SYNC_ORDER).
function computeScopedUniqueCollisions(ownerRows, def, rows) {
  const scopedUnique = def.blueprintScopedUnique;
  const uniqueOwners = new Map(); // scopedUniqueMapKey(scope, key) -> owning id
  for (const r of ownerRows) {
    // A NULL scope/key never collides (UNIQUE treats NULLs as distinct).
    if (r.scopeVal == null || r.keyVal == null) continue;
    uniqueOwners.set(scopedUniqueMapKey(r.scopeVal, r.keyVal), r.id);
  }
  const skippedRows = new Set(); // row object refs to skip in the main loop
  const skippedScopedKeys = new Set(); // scopedUniqueMapKey values that lost the flip
  const collisionKeys = [];
  let collisionSkipped = 0;
  for (const row of rows) {
    if (row[scopedUnique.scope] == null || row[scopedUnique.key] == null) continue;
    const uk = scopedUniqueMapKey(row[scopedUnique.scope], row[scopedUnique.key]);
    const owner = uniqueOwners.get(uk);
    if (owner !== undefined && owner !== row.id) {
      // Another row already owns this (scope, key). Upserting would silently
      // overwrite it, so skip and surface which incoming row collided.
      collisionSkipped += 1;
      if (collisionKeys.length < COLLISION_KEYS_CAP) collisionKeys.push(row.id);
      skippedRows.add(row);
      skippedScopedKeys.add(uk);
      continue;
    }
    // Claim the pair so an intra-payload duplicate (same key, different id)
    // arriving later in this run is caught against this row.
    // LIMITATION: the map is a static snapshot — a claim is never RELEASED.
    // A same-batch rename+reuse (row A renamed away from key `k`, row B then
    // assigned `k`) still sees A's stale claim on `k` and skips B. This is a
    // deliberate false-positive on the SAFE side (skip + report, never
    // clobber); releasing claims would require ordering guarantees the sync
    // payload does not provide. The DB UNIQUE is the final backstop.
    if (owner === undefined) uniqueOwners.set(uk, row.id);
  }
  return { skippedRows, skippedScopedKeys, collisionSkipped, collisionKeys };
}

// For one blueprint_fields row, return the set of key-reference columns to
// withhold because the blueprint_groups row that owns the target key was
// collision-skipped this run. Withholding leaves the rest of the field row to
// sync while preventing the group_key/matrix_row_key from flipping onto a key
// now owned by an unrelated group (or by nothing). blueprint_id is the shared
// scope for both blueprint_fields and blueprint_groups.
// colSet gates out a column the target DB lacks (e.g. a pre-migration target
// without matrix_row_key): buildUpsert already drops it, so no flip was ever
// possible — counting it as a withheld flip would be a false operator signal.
// colSet == null (probe unavailable) keeps all columns, matching buildUpsert.
function fieldGroupKeyWithhold(row, groupSkippedScopedKeys, colSet) {
  if (!groupSkippedScopedKeys || groupSkippedScopedKeys.size === 0) return null;
  const scopeVal = row.blueprint_id;
  if (scopeVal == null) return null;
  let withhold = null;
  for (const col of FIELD_GROUP_KEYREF_COLS) {
    if (colSet != null && !colSet.has(col.toLowerCase())) continue;
    const v = row[col];
    if (v == null || v === '') continue;
    if (groupSkippedScopedKeys.has(scopedUniqueMapKey(scopeVal, v))) {
      (withhold || (withhold = new Set())).add(col);
    }
  }
  return withhold;
}

// SECURITY: surface only the driver's error CLASS/code for a failed upsert,
// never the SQL text or bound values (which can carry payload data). mariadb
// populates .code (e.g. ER_DUP_ENTRY) and .errno; fall back to the error name.
function classifyUpsertError(e) {
  if (e && typeof e.code === 'string' && e.code) return e.code;
  if (e && e.errno != null) return `errno_${e.errno}`;
  return (e && e.name) || 'Error';
}

async function syncData(conn, tables, prefixFn) {
  const results = {};

  // Pre-pass: resolve blueprint-scoped-unique collisions for every scoped table
  // in the payload BEFORE the main upsert loop. blueprint_fields is synced ahead
  // of blueprint_groups in SYNC_ORDER, so the field key-flip guard needs the
  // group collision decision computed up front (rather than reordering
  // SYNC_ORDER, which other tables' FK-like ordering depends on).
  const collisionPlans = new Map(); // logicalName -> { skippedRows, skippedScopedKeys, ... }
  for (const logicalName of SYNC_ORDER) {
    const def = TABLE_DEFS[logicalName];
    if (!def?.blueprintScopedUnique) continue;
    const rows = tables[logicalName];
    if (!rows || !Array.isArray(rows) || !rows.length) continue;
    const colSet = await actualColumns(conn, prefixFn(logicalName));
    const { rows: ownerRows, degraded } = await loadScopedOwnerRows(conn, logicalName, def, prefixFn, colSet);
    const plan = computeScopedUniqueCollisions(ownerRows, def, rows);
    // degraded = the pre-existing-owner probe threw, so this table's collision
    // guard (and, for blueprint_groups, the field key-flip guard it feeds) ran
    // on intra-payload claims only. Carried into the report as guardDegraded.
    plan.degraded = degraded;
    collisionPlans.set(logicalName, plan);
  }
  // group_key / matrix_row_key both reference blueprint_groups.group_key.
  const groupPlan = collisionPlans.get('blueprint_groups');
  const groupSkippedScopedKeys = groupPlan?.skippedScopedKeys || null;

  // Only when a group key was actually skipped can a field both withhold its
  // group refs AND be moved to a different blueprint — the one combination that
  // must skip the whole field row (see loadExistingFieldBlueprints). Skip the
  // probe entirely otherwise so the common no-collision path adds no query.
  let fieldExistingBlueprintById = null; // Map | null (null when the probe failed)
  let fieldMoveProbeDegraded = false;
  if (groupSkippedScopedKeys && groupSkippedScopedKeys.size > 0) {
    const fieldRows = tables['blueprint_fields'];
    if (fieldRows && Array.isArray(fieldRows) && fieldRows.length) {
      const probe = await loadExistingFieldBlueprints(conn, fieldRows, prefixFn);
      fieldExistingBlueprintById = probe.map;
      fieldMoveProbeDegraded = probe.degraded;
    }
  }

  for (const logicalName of SYNC_ORDER) {
    const rows = tables[logicalName];
    if (!rows || !Array.isArray(rows) || !rows.length) {
      // `skippedTable` (boolean) is a DISTINCT signal from the numeric per-table
      // `skipped` count below: the table was absent/empty in the payload, not a
      // row-level skip. Keeping the two keys separate avoids overloading
      // `skipped` with both a boolean and a number in the same report position.
      results[logicalName] = { skippedTable: true };
      continue;
    }

    const def = TABLE_DEFS[logicalName];
    if (!def) {
      results[logicalName] = { error: 'Unknown table' };
      continue;
    }

    // Probe the target's real columns once per table so additive columns
    // (e.g. retain_when_hidden) are written only when the target has them.
    const colSet = await actualColumns(conn, prefixFn(logicalName));

    // Blueprint-scoped unique collisions were resolved in the pre-pass so an
    // incoming row whose (scope, key) already belongs to a DIFFERENT id is
    // skipped + reported instead of silently overwriting that other row. ON
    // DUPLICATE KEY UPDATE resolves a secondary-unique collision (new PK,
    // colliding unique) as a last-write-wins UPDATE of the OTHER row — no error
    // — so without this guard a staged duplicate section/group would silently
    // clobber a sibling.
    const plan = collisionPlans.get(logicalName); // undefined for non-scoped tables

    let upserted = 0;
    let skipped = 0;
    let keyFlipWithheld = 0;
    const keyFlipWithheldRefs = [];
    // A field whose group refs are withheld AND whose id already lives under a
    // different blueprint_id on the target is skipped whole (moving blueprint_id
    // while preserving old-scope keys would carry them into a blueprint that has
    // no such group). Distinct bucket from keyFlipWithheld — the row never wrote.
    let crossBlueprintSkipped = 0;
    const crossBlueprintSkippedRefs = [];
    let failed = 0;
    const failedRefs = [];
    // blueprint_groups only: the scoped keys of rows the pre-pass judged safe
    // but whose write then FAILED. This is the dangling-ref danger case — fields
    // may have already flipped to a key whose group row never landed — so it is
    // surfaced explicitly rather than buried in the generic failed count.
    const groupUpsertFailedKeys = [];
    for (const row of rows) {
      if (logicalName === 'field_options'
          && (isEmptyOptionStr(row.option_label) || isEmptyOptionStr(row.option_value))) {
        skipped += 1;
        continue;
      }
      if (plan && plan.skippedRows.has(row)) {
        // Collided on the blueprint-scoped unique pair (counted in the plan).
        continue;
      }
      // DATA-INTEGRITY: withhold a field's group_key/matrix_row_key when the
      // owning blueprint_groups row was collision-skipped this run, so the field
      // never flips onto a key owned by an unrelated group (or by nothing). The
      // rest of the field row still syncs.
      let withholdCols = null;
      if (logicalName === 'blueprint_fields') {
        withholdCols = fieldGroupKeyWithhold(row, groupSkippedScopedKeys, colSet);
        if (withholdCols) {
          const existingBp = fieldExistingBlueprintById
            ? fieldExistingBlueprintById.get(row.id) : undefined;
          // existingBp undefined = the id is new on the target (a plain insert
          // into the incoming blueprint), so withhold-in-place is correct; only
          // an EXISTING row moving to a different blueprint is unsafe.
          if (existingBp !== undefined && existingBp !== row.blueprint_id) {
            crossBlueprintSkipped += 1;
            if (crossBlueprintSkippedRefs.length < COLLISION_KEYS_CAP) {
              crossBlueprintSkippedRefs.push({ id: row.id });
            }
            continue; // do not upsert the row at all
          }
          keyFlipWithheld += 1;
          if (keyFlipWithheldRefs.length < COLLISION_KEYS_CAP) {
            keyFlipWithheldRefs.push({ id: row.id, cols: [...withholdCols] });
          }
        }
      }
      const { sql, values } = buildUpsert(logicalName, def, row, prefixFn, colSet, withholdCols);
      try {
        await conn.query(sql, values);
        upserted++;
      } catch (e) {
        failed += 1;
        const underCap = failedRefs.length < COLLISION_KEYS_CAP;
        if (underCap) failedRefs.push({ id: row.id, error: classifyUpsertError(e) });
        if (logicalName === 'blueprint_groups' && underCap
            && row.blueprint_id != null && row.group_key != null) {
          groupUpsertFailedKeys.push(scopedUniqueMapKey(row.blueprint_id, row.group_key));
        }
        logger.error({ table: logicalName, err: e }, 'Failed to upsert row into ' + logicalName);
      }
    }
    const report = { upserted, skipped, total: rows.length };
    if (plan && plan.collisionSkipped > 0) {
      report.collisionSkipped = plan.collisionSkipped;
      report.collisionKeys = plan.collisionKeys;
    }
    if (keyFlipWithheld > 0) {
      report.keyFlipWithheld = keyFlipWithheld;
      report.keyFlipWithheldRefs = keyFlipWithheldRefs;
      report.keyFlipWithheldRefsCapped = keyFlipWithheldRefs.length < keyFlipWithheld;
    }
    if (crossBlueprintSkipped > 0) {
      report.crossBlueprintSkipped = crossBlueprintSkipped;
      report.crossBlueprintSkippedRefs = crossBlueprintSkippedRefs;
      report.crossBlueprintSkippedRefsCapped = crossBlueprintSkippedRefs.length < crossBlueprintSkipped;
    }
    if (failed > 0) {
      report.failed = failed;
      report.failedRefs = failedRefs;
      report.failedRefsCapped = failedRefs.length < failed;
      if (groupUpsertFailedKeys.length > 0) {
        report.groupUpsertFailedKeys = groupUpsertFailedKeys;
      }
    }
    // guardDegraded: the pre-existing-owner probe for this table threw, so its
    // collision guard ran on intra-payload claims only. For blueprint_fields the
    // key-flip guard depends on blueprint_groups' probe AND the cross-blueprint
    // move probe, so mark it degraded when either upstream probe degraded.
    if (plan?.degraded) report.guardDegraded = true;
    else if (logicalName === 'blueprint_fields' && (groupPlan?.degraded || fieldMoveProbeDegraded)) {
      report.guardDegraded = true;
    }
    results[logicalName] = report;
    if (skipped > 0) {
      logger.warn({ table: logicalName, skipped }, 'sync skipped empty-option rows');
    }
    if (plan && plan.collisionSkipped > 0) {
      logger.warn(
        { table: logicalName, collisionSkipped: plan.collisionSkipped },
        'sync skipped rows colliding on a blueprint-scoped unique key',
      );
    }
    if (keyFlipWithheld > 0) {
      logger.warn(
        { table: logicalName, keyFlipWithheld },
        'sync withheld field key-flips onto collision-skipped blueprint_groups keys',
      );
    }
    if (crossBlueprintSkipped > 0) {
      logger.warn(
        { table: logicalName, crossBlueprintSkipped },
        'sync skipped cross-blueprint field moves whose group refs were withheld',
      );
    }
    if (failed > 0) {
      logger.warn(
        { table: logicalName, failed, groupUpsertFailedKeys: groupUpsertFailedKeys.length || undefined },
        'sync had per-row upsert failures',
      );
    }
  }

  return results;
}

// ── POST /api/sync-schema ────────────────────────────────────────────────────
// Supports optional req.body.db (set by X-Database middleware) to route
// engine table DDL and data to a different database (schema).
// Note: system_settings is an infra table — its data always writes to infra pool.
router.post('/', async (req, res) => {
  if (!requireAdmin(req, res)) return;

  const { action = 'full_sync', tables = {}, db: targetDb } = req.body;

  if (!['full_sync', 'schema_only', 'data_only'].includes(action)) {
    const e = apiError('Invalid action. Use: full_sync, schema_only, data_only', 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }

  let conn;
  let infraConn; // separate connection for system_settings (always infra pool)
  try {
    let prefixFn = t;
    if (targetDb) {
      // Route engine tables to the target schema via dynamic pool
      const dynPool = await getDynamicPool(targetDb);
      conn = await dynPool.rw.getConnection();
      const prefix = requirePrefix(targetDb.tablePrefix || getDbConfigFull()?.tablePrefix, 'sync-schema:prefix');
      prefixFn = (name) => `${prefix}${name}`;
    } else {
      // Sync does DDL (applyDDL) + upserts (syncData) → pool.rw.
      conn = await pool.rw.getConnection();
    }

    const report = { action, ddl: null, data: null };

    // Schema DDL (engine tables only — infra tables managed by configurePool)
    if (action === 'full_sync' || action === 'schema_only') {
      await applyDDL(conn, prefixFn);
      report.ddl = 'applied';
    }

    // Data upsert
    if (action === 'full_sync' || action === 'data_only') {
      // system_settings is an infra table — always write to infra pool (rw).
      if (targetDb && tables.system_settings?.length) {
        infraConn = await pool.rw.getConnection();
        const infraTables = { system_settings: tables.system_settings };
        const infraResult = await syncData(infraConn, infraTables);
        const engineTables = { ...tables };
        delete engineTables.system_settings;
        const engineResult = await syncData(conn, engineTables, prefixFn);
        report.data = { ...infraResult, ...engineResult };
      } else {
        report.data = await syncData(conn, tables, prefixFn);
      }
    }

    res.json(apiOk(report));
  } catch (err) {
    logger.error({ err }, 'Failed to execute sync-schema sync operation');
    if (maybeHandlePoolNotConfigured(err, res)) return;
    const e = apiError('Database operation failed', 'SYNC_ERROR');
    res.status(e.status).json(e.body);
  } finally {
    if (conn) conn.release();
    if (infraConn) infraConn.release();
  }
});

// ── GET /api/sync-schema/status ──────────────────────────────────────────────
// Supports X-Database header (via middleware) to check status in a target schema.
router.get('/status', async (req, res) => {
  if (!requireAdmin(req, res)) return;

  const targetDb = req.body?.db;
  let conn;
  try {
    let prefixFn = t;
    if (targetDb) {
      const dynPool = await getDynamicPool(targetDb);
      conn = await dynPool.ro.getConnection();
      const prefix = requirePrefix(targetDb.tablePrefix || getDbConfigFull()?.tablePrefix, 'sync-schema:prefix');
      prefixFn = (name) => `${prefix}${name}`;
    } else {
      // Pure COUNT(*) → pool.ro.
      conn = await pool.ro.getConnection();
    }

    // Count only engine tables (status checks are per-schema)
    const counts = {};
    for (const logicalName of ENGINE_TABLES) {
      try {
        const rows = await conn.query(`SELECT COUNT(*) AS cnt FROM \`${prefixFn(logicalName)}\``);
        counts[logicalName] = Number(rows[0].cnt);
      } catch {
        counts[logicalName] = -1; // table doesn't exist
      }
    }
    res.json(apiOk({ tables: counts }));
  } catch (err) {
    logger.error({ err }, 'Failed to fetch sync-schema status');
    const e = apiError('Database operation failed', 'INTERNAL_ERROR');
    if (maybeHandlePoolNotConfigured(err, res)) return;
    res.status(e.status).json(e.body);
  } finally {
    if (conn) conn.release();
  }
});

// ── GET /api/sync-schema/export-sql ─────────────────────────────────────────
// Exports engine table schemas + data as SQL with __PREFIX__ placeholders.
// Supports X-Database header to target a specific schema.
router.get('/export-sql', async (req, res) => {
  if (!requireAdmin(req, res)) return;

  const targetDb = req.body?.db;
  let conn;
  try {
    // actualPrefix is unconditionally re-assigned by one of the two branches
    // below (both go through requirePrefix). Initialised as empty string to
    // satisfy the linter's definite-assignment check for the prefixFn closure.
    let prefixFn = t;
    let actualPrefix = '';
    if (targetDb) {
      const dynPool = await getDynamicPool(targetDb);
      conn = await dynPool.ro.getConnection();
      actualPrefix = requirePrefix(targetDb.tablePrefix || getDbConfigFull()?.tablePrefix, 'sync-schema:actualPrefix');
      prefixFn = (name) => `${actualPrefix}${name}`;
    } else {
      // SHOW CREATE + SELECT * for export → pool.ro.
      conn = await pool.ro.getConnection();
      actualPrefix = requirePrefix(getDbConfigFull()?.tablePrefix, 'sync-schema:actualPrefix');
    }

    const lines = [
      '-- Exported by flexible_mold_base',
      `-- Prefix placeholder: __PREFIX__ (replace with your table prefix, e.g. ${actualPrefix})`,
      `-- Generated: ${new Date().toISOString()}`,
      '',
    ];

    const rowCounts = {};

    for (const logicalName of ENGINE_TABLES) {
      const physicalName = prefixFn(logicalName);
      const placeholderName = `__PREFIX__${logicalName}`;

      // Generate CREATE TABLE DDL with placeholder name
      try {
        const rows = await conn.query(`SHOW CREATE TABLE \`${physicalName}\``);
        if (rows.length) {
          let createSql = rows[0]['Create Table'];
          // Replace actual prefixed name with placeholder
          createSql = createSql.replaceAll(`\`${physicalName}\``, `\`${placeholderName}\``);
          createSql = createSql.replace('CREATE TABLE', 'CREATE TABLE IF NOT EXISTS');
          lines.push(`-- Table: ${logicalName}`);
          lines.push(createSql + ';');
          lines.push('');
        }
      } catch {
        lines.push(`-- Table ${logicalName} not found, skipping`);
        lines.push('');
        rowCounts[logicalName] = -1;
        continue;
      }

      // Generate INSERT statements
      try {
        const def = TABLE_DEFS[logicalName];
        const dataRows = await conn.query(`SELECT * FROM \`${physicalName}\``);
        rowCounts[logicalName] = dataRows.length;

        if (dataRows.length && def) {
          for (const row of dataRows) {
            const cols = def.cols.filter(c => row[c] !== undefined && row[c] !== null);
            const colList = cols.map(c => `\`${c}\``).join(', ');
            const vals = cols.map(c => {
              const v = row[c];
              if (v === null || v === undefined) return 'NULL';
              if (def.json.includes(c) && typeof v === 'object') return `'${escapeString(JSON.stringify(v))}'`;
              if (def.json.includes(c) && typeof v === 'string') return `'${escapeString(v)}'`;
              if (typeof v === 'boolean' || v === 0 || v === 1) return v ? 1 : 0;
              if (v instanceof Date) return `'${v.toISOString().replace('T', ' ').replace(/\.\d+Z$/, '')}'`;
              return `'${escapeString(String(v))}'`;
            }).join(', ');
            lines.push(`INSERT INTO \`${placeholderName}\` (${colList}) VALUES (${vals}) ON DUPLICATE KEY UPDATE id=id;`);
          }
          lines.push('');
        }
      } catch (e) {
        logger.warn({ table: logicalName, err: e }, 'export data warning');
        rowCounts[logicalName] = -1;
      }
    }

    const sql = lines.join('\n');
    res.json(apiOk({ sql, tables: ENGINE_TABLES, rowCounts }));
  } catch (err) {
    logger.error({ err }, 'Failed to export engine schema SQL');
    const e = apiError('Database operation failed', 'EXPORT_ERROR');
    if (maybeHandlePoolNotConfigured(err, res)) return;
    res.status(e.status).json(e.body);
  } finally {
    if (conn) conn.release();
  }
});

// ── POST /api/sync-schema/import-sql ────────────────────────────────────────
// Imports a SQL file with __PREFIX__ placeholders, replacing them with the
// configured table prefix before execution.
// Supports X-Database header to target a specific schema.
router.post('/import-sql', async (req, res) => {
  if (!requireAdmin(req, res)) return;

  const { sql: rawSql } = req.body;
  if (!rawSql || typeof rawSql !== 'string') {
    const e = apiError('sql field is required', 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }

  // SQL allowlist: only safe DML/DDL statements permitted
  const SQL_ALLOWLIST = /^\s*(INSERT|REPLACE|CREATE\s+TABLE|ALTER\s+TABLE|SET|START\s+TRANSACTION|COMMIT|ROLLBACK)\b/i;
  const SQL_DENYLIST = /^\s*(DROP|DELETE|TRUNCATE|UPDATE|GRANT|REVOKE|RENAME|LOAD|CALL|EXECUTE)\b/i;

  // Strip SQL comments before validation
  const stripComments = (sql) =>
    sql.replace(/--[^\n]*/g, '').replace(/\/\*[\s\S]*?\*\//g, '');

  const targetDb = req.body?.db;
  let conn;
  try {
    let actualPrefix;
    if (targetDb) {
      const dynPool = await getDynamicPool(targetDb);
      conn = await dynPool.rw.getConnection();
      actualPrefix = requirePrefix(targetDb.tablePrefix || getDbConfigFull()?.tablePrefix, 'sync-schema:actualPrefix');
    } else {
      // SQL import runs INSERT/REPLACE/CREATE/ALTER (allowlist) → pool.rw.
      conn = await pool.rw.getConnection();
      actualPrefix = requirePrefix(getDbConfigFull()?.tablePrefix, 'sync-schema:actualPrefix');
    }

    const transformed = rawSql.replaceAll('__PREFIX__', actualPrefix);

    // SQL-aware split: respects string literals containing semicolons
    const statements = splitSqlStatements(transformed);

    // Validate each statement against allowlist
    const rejected = [];
    for (const stmt of statements) {
      const stripped = stripComments(stmt).trim();
      if (!stripped) continue;
      if (SQL_DENYLIST.test(stripped)) {
        rejected.push(stripped.substring(0, 80));
      } else if (!SQL_ALLOWLIST.test(stripped)) {
        rejected.push(stripped.substring(0, 80));
      }
    }
    if (rejected.length > 0) {
      const e = apiError(
        `Rejected ${rejected.length} statement(s) not in SQL allowlist (INSERT, REPLACE, CREATE TABLE, ALTER TABLE). First: ${rejected[0]}`,
        'SQL_NOT_ALLOWED', 400
      );
      return res.status(e.status).json(e.body);
    }

    let executed = 0;
    const errors = [];
    for (const stmt of statements) {
      try {
        await conn.query(stmt);
        executed++;
      } catch (e) {
        errors.push(e.message.substring(0, 120));
      }
    }

    res.json(apiOk({ executed, errors, prefix_used: actualPrefix }));
  } catch (err) {
    logger.error({ err }, 'Failed to import schema SQL');
    const e = apiError('Database operation failed', 'IMPORT_ERROR');
    if (maybeHandlePoolNotConfigured(err, res)) return;
    res.status(e.status).json(e.body);
  } finally {
    if (conn) conn.release();
  }
});

// Engine table logical names for truncate/drop validation.
// Uses ENGINE_TABLE_NAMES (not SYNC_ORDER) because system_settings is an infra
// table that appears in SYNC_ORDER for data-sync purposes only.
const ENGINE_TABLES_SET = new Set(ENGINE_TABLE_NAMES);

// ── Data clear helpers ───────────────────────────────────────────────────────
//
// Preflight FK check + UI block for parent-with-children + auto
// TRUNCATE→DELETE fallback for operator accounts. Two-stage audit
// (attempt → outcome) lets the operations team distinguish "we attempted but
// were blocked" from "we never attempted".

const PHYSICAL_TABLE_NAME_RE = /^[A-Za-z0-9_]+$/;

// Shared TRUNCATE → DELETE fallback core lives in `edge/lib/clear-table.js`.
// Engine route owns the FK preflight (engine-only); helper owns the audit
// + errno fallback flow.
const {
  insertClearAudit,
  safeInsertAudit,
  truncateOrDeleteWithFallback,
  failAuditMeta,
  ENGINE_FALLBACK_ERRNOS,
} = require('../../lib/clear-table');

/**
 * Resolve the physical table name + connection for a given engine table.
 * Honours the optional `db` body param for cross-schema targeting (matches
 * the existing truncate-table contract).
 *
 * SAFETY: rw and ro connections are acquired sequentially with a try/release
 * around the second await. A naive `return { conn: await rw, roConn: await ro }`
 * would leak the rw connection if the ro acquisition threw — the resolved rw
 * value would never be assigned to anything callers could release.
 */
async function resolveTableConn(targetDb, logicalTable) {
  if (targetDb) {
    const dynPool = await getDynamicPool(targetDb);
    const actualPrefix = requirePrefix(
      targetDb.tablePrefix || getDbConfigFull()?.tablePrefix,
      'sync-schema:actualPrefix',
    );
    const conn = await dynPool.rw.getConnection();
    try {
      const roConn = await dynPool.ro.getConnection();
      return {
        conn,
        roConn,
        physicalTable: `${actualPrefix}${logicalTable}`,
        prefix: actualPrefix,
      };
    } catch (err) {
      conn.release();
      throw err;
    }
  }
  const prefix = requirePrefix(getDbConfigFull()?.tablePrefix, 'sync-schema:defaultPrefix');
  const conn = await pool.rw.getConnection();
  try {
    const roConn = await pool.ro.getConnection();
    return {
      conn,
      roConn,
      physicalTable: t(logicalTable),
      prefix,
    };
  } catch (err) {
    conn.release();
    throw err;
  }
}

/**
 * Look up FK referrers for the given parent physical table and report each
 * child's row count. Restricted to current schema via TABLE_SCHEMA filter so
 * we cannot leak counts from neighbouring databases.
 */
// SECURITY: the table prefix is an internal deployment detail (CLAUDE.md §8.1 /
// LEARN §60) and must not leak to clients. Reverse the deterministic
// physical = prefix + logical mapping for the names returned to admin payloads.
// Leaves the name untouched if it does not carry the expected prefix (defensive
// — INFORMATION_SCHEMA could in theory return an unprefixed name).
function stripTablePrefix(physical, prefix) {
  if (prefix && physical.startsWith(prefix)) return physical.slice(prefix.length);
  return physical;
}

async function getChildTablesWithRowCount(roConn, parentPhysical, prefix) {
  // SECURITY: parentPhysical is already validated against PHYSICAL_TABLE_NAME_RE
  // by the caller; this is belt-and-suspenders.
  if (!PHYSICAL_TABLE_NAME_RE.test(parentPhysical)) {
    throw new Error(`refusing dependency lookup for malformed table name: ${parentPhysical}`);
  }
  const fkRows = await roConn.query(
    `SELECT TABLE_NAME AS child_table, COLUMN_NAME AS child_col,
            CONSTRAINT_NAME AS constraint_name,
            REFERENCED_TABLE_NAME AS parent_table,
            REFERENCED_COLUMN_NAME AS parent_col
       FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE
      WHERE REFERENCED_TABLE_SCHEMA = DATABASE()
        AND REFERENCED_TABLE_NAME = ?`,
    [parentPhysical],
  );
  // KEY_COLUMN_USAGE returns one row PER COLUMN in a composite FK, so a
  // 2-column constraint produces 2 rows for the same child_table. Dedupe by
  // child_table — UI displays "↳ N child tables", not "↳ N FK columns".
  const seenTables = new Map();
  for (const fk of fkRows) {
    if (!PHYSICAL_TABLE_NAME_RE.test(fk.child_table)) {
      // Defensive: skip names we can't safely interpolate. Should never happen
      // because INFORMATION_SCHEMA only returns valid identifiers.
      continue;
    }
    if (seenTables.has(fk.child_table)) continue;
    const countRows = await roConn.query(
      `SELECT COUNT(*) AS cnt FROM \`${fk.child_table}\``,
    );
    seenTables.set(fk.child_table, {
      // Logical name only — never leak the deployment table prefix to clients.
      child_table: stripTablePrefix(fk.child_table, prefix),
      child_col: fk.child_col,
      constraint_name: fk.constraint_name,
      row_count: Number(countRows[0]?.cnt ?? 0),
    });
  }
  return [...seenTables.values()];
}

// ── POST /api/sync-schema/clear-table ───────────────────────────────────────
// Replaces /truncate-table. FK preflight + auto TRUNCATE→DELETE fallback for
// operator accounts (1142/1227). 409 with suggested clear order if blocked.
router.post('/clear-table', async (req, res) => {
  if (!requireAdmin(req, res)) return;

  const { table } = req.body || {};
  if (!table || !ENGINE_TABLES_SET.has(table)) {
    const e = apiError(
      `Invalid table name. Allowed: ${ENGINE_TABLE_NAMES.join(', ')}`,
      'BAD_REQUEST', 400
    );
    return res.status(e.status).json(e.body);
  }

  const targetDb = req.body?.db;
  let resolved;
  try {
    resolved = await resolveTableConn(targetDb, table);
  } catch (err) {
    if (maybeHandlePoolNotConfigured(err, res)) return;
    logger.error({ err, table }, 'clear-table: failed to acquire DB connection');
    const e = apiError('Database operation failed', 'INTERNAL_ERROR');
    return res.status(e.status).json(e.body);
  }

  const { conn, roConn, physicalTable, prefix: tablePrefix } = resolved;
  const userId = req.user?.id || null;
  const auditMeta = { table_class: 'engine', table, physicalTable };

  await safeInsertAudit(conn, {
    eventType: 'data_clear.attempt',
    userId,
    metadata: auditMeta,
  }, logger);

  try {
    // FK preflight stays in the engine route — infra tables carry no
    // FOREIGN KEY declarations, so the helper does not concern itself
    // with this branch. Engine-only.
    const childTables = await getChildTablesWithRowCount(roConn, physicalTable, tablePrefix);
    const blockedBy = childTables.filter((c) => c.row_count > 0);
    if (blockedBy.length > 0) {
      await safeInsertAudit(conn, {
        eventType: 'data_clear.blocked_by_fk',
        userId,
        metadata: { ...auditMeta, blocked_by: blockedBy },
      }, logger);
      return res.status(409).json({
        error: 'has_dependent_rows',
        blocked_by: blockedBy,
        // Children listed in arbitrary order (FK declaration order); operator
        // can clear them in any order since each has independent FK refs.
        suggested_clear_first: blockedBy.map((c) => c.child_table),
      });
    }

    const result = await truncateOrDeleteWithFallback(conn, {
      physicalTable,
      logicalTable: table,
      tableClass: 'engine',
      errnoSet: ENGINE_FALLBACK_ERRNOS,
      userId,
      extraMeta: { physicalTable },
      logger,
    });

    if (result.method === 'TRUNCATE') {
      return res.json(apiOk({ table, action: 'cleared', method: 'TRUNCATE' }));
    }
    const fallbackReason = result.reasonErrno === 1701
      ? 'FK reference blocks TRUNCATE (constraint declared)'
      : 'operator-mode (no TRUNCATE privilege)';
    return res.json(apiOk({
      table,
      action: 'cleared',
      method: 'DELETE',
      note: `AUTO_INCREMENT not reset — ${fallbackReason}`,
    }));
  } catch (err) {
    await safeInsertAudit(conn, {
      eventType: 'data_clear.fail',
      userId,
      metadata: { ...auditMeta, ...failAuditMeta(err) },
    }, logger);
    if (maybeHandlePoolNotConfigured(err, res)) return;
    logger.error({ err, table }, 'clear-table failed');
    const e = apiError('Database operation failed', 'CLEAR_ERROR');
    res.status(e.status).json(e.body);
  } finally {
    if (conn) conn.release();
    if (roConn) roConn.release();
  }
});

// ── POST /api/sync-schema/prepare-wipe ──────────────────────────────────────
// Builds the full engine-data SQL backup, streams it, and returns a signed
// X-Wipe-Token. execute-wipe requires that token, so a wipe is impossible
// without first pulling this backup. Scoped to the active (default) schema.
router.post('/prepare-wipe', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  const cfg = getDbConfigFull();
  const schema = cfg?.database;
  // lint-allow: write-path-shapes the operator recorded against a backup,
  // same as the wipe below and deferred with it.
  const userId = req.user?.id || req.user?.sub;

  let conn;
  try {
    // requirePrefix + signWipeToken can throw; keep them inside the try so a
    // PoolNotConfiguredError / missing-key surfaces as a clean response rather
    // than an unhandled async rejection under Express 4.
    const prefix = requirePrefix(cfg?.tablePrefix, 'sync-schema:prepare-wipe');
    const token = signWipeToken({ userId, schema }, Date.now());
    conn = await pool.ro.getConnection();
    const sql = await buildEngineSeedSql(conn, { database: schema, tablePrefix: prefix });
    const filename = buildExportFilename({ kind: 'engine-backup', entity: schema || 'export', ext: 'sql' });
    res.setHeader('Content-Type', 'application/sql; charset=utf-8');
    res.setHeader('Content-Disposition', contentDispositionAttachment(filename));
    res.setHeader('X-Wipe-Token', token);
    res.send(sql);
  } catch (err) {
    if (maybeHandlePoolNotConfigured(err, res)) return;
    logger.error({ err }, 'prepare-wipe failed');
    const e = apiError('Failed to prepare wipe backup', 'PREPARE_WIPE_ERROR');
    res.status(e.status).json(e.body);
  } finally {
    if (conn) conn.release();
  }
});

/**
 * Children-first delete order over the live FK graph of the engine tables.
 * A table is emitted only after every table that references it. Falls back to
 * a DDL-derived leaf-first order if the FK query fails or is incomplete.
 */
async function computeEngineDeleteOrder(roConn, prefix) {
  // hierarchy_nodes is the root parent → deleted last; leaves first.
  const FALLBACK = [
    // Capacity Planner leaves-first (cap_scenarios is the capacity root → last of
    // the group). No DB-level FKs exist, so intra-group order is convention only;
    // the group precedes the blueprint tree and hierarchy_nodes stays absolute last.
    'cap_waivers', 'cap_custom_group_members', 'cap_custom_groups',
    'cap_db_instances', 'cap_vms', 'cap_databases', 'cap_hypervisors', 'cap_sites',
    'cap_teams', 'cap_disk_combos', 'cap_hardware_specs', 'cap_versions',
    'cap_rules', 'cap_bundle_items', 'cap_bundles', 'cap_vm_profiles',
    'cap_field_defs', 'cap_settings', 'cap_scenarios',
    'flow_recipe_code_versions', 'flow_recipe_runs', 'flow_recipe_steps', 'flow_recipes',
    'field_options', 'variant_overrides', 'decision_tables', 'blueprint_output_order',
    'blueprint_sections', 'blueprint_groups', 'blueprint_fields', 'transformer_versions',
    // Both reference a template or a blueprint and nothing references them, so
    // they are leaves and precede the rows they point at. template_snapshots
    // (U10) is the same shape — references template_id and nothing
    // references it.
    'template_activity', 'delegated_grants', 'template_snapshots',
    'user_templates', 'transformers', 'api_connectors', 'hierarchy_nodes',
  ].filter((t) => ENGINE_TABLE_NAMES.includes(t));
  try {
    const edges = await roConn.query(
      `SELECT TABLE_NAME AS child, REFERENCED_TABLE_NAME AS parent
         FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE
        WHERE REFERENCED_TABLE_SCHEMA = DATABASE()
          AND REFERENCED_TABLE_NAME IS NOT NULL`,
    );
    const toLogical = (physical) => ENGINE_TABLE_NAMES.find((n) => `${prefix}${n}` === physical);
    const children = new Map(ENGINE_TABLE_NAMES.map((t) => [t, new Set()]));
    for (const e of edges) {
      const parent = toLogical(e.parent);
      const child = toLogical(e.child);
      if (parent && child && parent !== child) children.get(parent).add(child);
    }
    // Kahn: emit a table only once all tables referencing it are emitted.
    const order = [];
    const emitted = new Set();
    let guard = 0;
    while (order.length < ENGINE_TABLE_NAMES.length && guard++ < 100) {
      for (const t of ENGINE_TABLE_NAMES) {
        if (emitted.has(t)) continue;
        const pending = [...children.get(t)].filter((c) => !emitted.has(c));
        if (pending.length === 0) { order.push(t); emitted.add(t); }
      }
    }
    if (order.length !== ENGINE_TABLE_NAMES.length) return FALLBACK;
    return order;
  } catch (err) {
    logger.warn({ err }, 'execute-wipe: FK order query failed; using fallback order');
    return FALLBACK;
  }
}

// SECURITY: single-use wipe tokens. A verified token is consumed on its first
// execute so the same backup cannot drive a second wipe within the TTL — this
// is the "one fresh backup = one wipe" guarantee. Per-process (in-memory):
// edge is the only writer of this path; cross-replica one-shot would need a
// shared store and is tracked as a follow-up. Lazily evicted by expiry.
const consumedWipeTokens = new Map(); // token → expiryMs
function consumeWipeTokenOnce(token, nowMs, ttlMs) {
  for (const [k, exp] of consumedWipeTokens) {
    if (exp <= nowMs) consumedWipeTokens.delete(k);
  }
  if (consumedWipeTokens.has(token)) return false;
  consumedWipeTokens.set(token, nowMs + ttlMs);
  return true;
}

// ── POST /api/sync-schema/execute-wipe ──────────────────────────────────────
// NOT mounted under destructiveOpsLimiter (single-use token + type-to-confirm
// + a dedicated wipeExecuteLimiter are the throttle). Verifies the X-Wipe-Token,
// consumes it (one-shot), then DELETEs every engine table in FK-safe
// (children-first) order. Operator account lands on DELETE.
router.post('/execute-wipe', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  const cfg = getDbConfigFull();
  const schema = cfg?.database;
  // lint-allow: write-path-shapes the operator recorded against a wipe.
  // Deferred with the rest of the family; the wipe itself is admin-gated and token-gated,
  // so what a second spelling costs here is a trail naming somebody unresolvable.
  const userId = req.user?.id || req.user?.sub;
  const ttlMs = Number(process.env.WIPE_TOKEN_TTL_MS) || 600000;

  const token = req.body?.token;
  const v = verifyWipeToken(token, { userId, schema }, Date.now(), ttlMs);
  if (!v.ok) {
    const e = apiError(`Wipe token rejected: ${v.reason}`, 'WIPE_TOKEN_INVALID', 422);
    return res.status(e.status).json(e.body);
  }
  // One-shot: reject a token that already drove a wipe (replay within TTL).
  if (!consumeWipeTokenOnce(token, Date.now(), ttlMs)) {
    const e = apiError('Wipe token already used — prepare a fresh backup', 'WIPE_TOKEN_USED', 422);
    return res.status(e.status).json(e.body);
  }

  let conn, roConn;
  try {
    const prefix = requirePrefix(cfg?.tablePrefix, 'sync-schema:execute-wipe');
    conn = await pool.rw.getConnection();
    roConn = await pool.ro.getConnection();
    await safeInsertAudit(conn, {
      eventType: 'wipe_all.attempt',
      userId,
      metadata: { schema, table_class: 'engine' },
    }, logger);
    const order = await computeEngineDeleteOrder(roConn, prefix);
    const wiped = [];
    let total = 0;
    for (const table of order) {
      const physicalTable = `${prefix}${table}`;
      const cntRows = await roConn
        .query(`SELECT COUNT(*) AS cnt FROM \`${physicalTable}\``)
        .catch(() => [{ cnt: 0 }]);
      const before = Number(cntRows[0]?.cnt ?? 0);
      const result = await truncateOrDeleteWithFallback(conn, {
        physicalTable,
        logicalTable: table,
        tableClass: 'engine',
        errnoSet: ENGINE_FALLBACK_ERRNOS,
        userId,
        extraMeta: { physicalTable, batch: 'wipe-all' },
        logger,
      });
      wiped.push({ table, deleted_rows: before, method: result.method });
      total += before;
    }
    await safeInsertAudit(conn, {
      eventType: 'wipe_all.complete',
      userId,
      metadata: { schema, table_class: 'engine', total_rows: total, tables: wiped.length },
    }, logger);
    return res.json(apiOk({ wiped, total_rows: total }));
  } catch (err) {
    if (maybeHandlePoolNotConfigured(err, res)) return;
    logger.error({ err }, 'execute-wipe failed');
    const e = apiError('Wipe failed; some tables may remain. Prepare a fresh backup and retry.', 'WIPE_ERROR');
    res.status(e.status).json(e.body);
  } finally {
    if (conn) conn.release();
    if (roConn) roConn.release();
  }
});

// ── GET /api/sync-schema/dependency-summary ──────────────────────────────────
// Returns per-engine-table list of FK children with current row counts. Used
// by the Data Management UI to disable Clear buttons and show dependency
// trees. RW pool is not touched (read-only).
router.get('/dependency-summary', async (req, res) => {
  if (!requireAdmin(req, res)) return;

  let roConn;
  try {
    const prefix = requirePrefix(getDbConfigFull()?.tablePrefix, 'sync-schema:dependency-summary');
    roConn = await pool.ro.getConnection();
    const summary = {};
    for (const tableName of ENGINE_TABLE_NAMES) {
      const physical = `${prefix}${tableName}`;
      summary[tableName] = await getChildTablesWithRowCount(roConn, physical, prefix);
    }
    res.json(apiOk(summary));
  } catch (err) {
    if (maybeHandlePoolNotConfigured(err, res)) return;
    logger.error({ err }, 'dependency-summary failed');
    const e = apiError('Database operation failed', 'DEPENDENCY_SUMMARY_ERROR');
    res.status(e.status).json(e.body);
  } finally {
    if (roConn) roConn.release();
  }
});

// ── POST /api/sync-schema/truncate-table (DEPRECATED) ───────────────────────
// Kept for backward compatibility so any in-flight client / external script
// gets a graceful redirect. Logs a deprecation warning per call.
router.post('/truncate-table', async (req, res) => {
  logger.warn(
    { table: req.body?.table, ip: req.ip },
    'truncate-table is deprecated; clients should call /clear-table for FK preflight',
  );
  // Re-dispatch to clear-table semantics by delegating internally. We can't
  // simply call the handler here without re-reading Express plumbing, so we
  // duplicate the auth + validation to keep response shape compatible.
  if (!requireAdmin(req, res)) return;
  const { table } = req.body || {};
  if (!table || !ENGINE_TABLES_SET.has(table)) {
    const e = apiError(
      `Invalid table name. Allowed: ${ENGINE_TABLE_NAMES.join(', ')}`,
      'BAD_REQUEST', 400
    );
    return res.status(e.status).json(e.body);
  }
  const targetDb = req.body?.db;
  let conn;
  try {
    let prefixFn = t;
    if (targetDb) {
      const dynPool = await getDynamicPool(targetDb);
      conn = await dynPool.rw.getConnection();
      const actualPrefix = requirePrefix(targetDb.tablePrefix || getDbConfigFull()?.tablePrefix, 'sync-schema:actualPrefix');
      prefixFn = (name) => `${actualPrefix}${name}`;
    } else {
      conn = await pool.rw.getConnection();
    }
    const physicalTable = prefixFn(table);
    await conn.query(`TRUNCATE TABLE \`${physicalTable}\``);
    res.json(apiOk({ table, action: 'truncated', deprecated: 'use /clear-table' }));
  } catch (err) {
    logger.error({ err, table }, 'Failed to truncate engine table ' + table);
    const e = apiError('Database operation failed', 'TRUNCATE_ERROR');
    if (maybeHandlePoolNotConfigured(err, res)) return;
    res.status(e.status).json(e.body);
  } finally {
    if (conn) conn.release();
  }
});

// ── POST /api/sync-schema/drop-table ────────────────────────────────────────
// Drops an engine table. Requires admin auth.
// Body: { table: string } — logical name, e.g. "blueprint_fields"
// Supports X-Database header for schema targeting.
router.post('/drop-table', async (req, res) => {
  if (!requireAdmin(req, res)) return;

  const { table } = req.body;
  if (!table || !ENGINE_TABLES_SET.has(table)) {
    const e = apiError(
      `Invalid table name. Allowed: ${ENGINE_TABLE_NAMES.join(', ')}`,
      'BAD_REQUEST', 400
    );
    return res.status(e.status).json(e.body);
  }

  const targetDb = req.body?.db;
  let conn;
  try {
    let prefixFn = t;
    if (targetDb) {
      const dynPool = await getDynamicPool(targetDb);
      conn = await dynPool.rw.getConnection();
      const actualPrefix = requirePrefix(targetDb.tablePrefix || getDbConfigFull()?.tablePrefix, 'sync-schema:actualPrefix');
      prefixFn = (name) => `${actualPrefix}${name}`;
    } else {
      // DROP TABLE → pool.rw.
      conn = await pool.rw.getConnection();
    }

    const physicalTable = prefixFn(table);
    await conn.query(`DROP TABLE IF EXISTS \`${physicalTable}\``);
    res.json(apiOk({ table, action: 'dropped' }));
  } catch (err) {
    logger.error({ err, table }, 'Failed to drop engine table ' + table);
    const e = apiError('Database operation failed', 'DROP_ERROR');
    if (maybeHandlePoolNotConfigured(err, res)) return;
    res.status(e.status).json(e.body);
  } finally {
    if (conn) conn.release();
  }
});

module.exports = router;
// SYNC_ORDER exposed for tests only (router remains the same callable Express
// function; this attaches a property, it doesn't change how app.use() mounts
// it). Verifies service_accounts / service_account_idempotency stay excluded
// from generic cross-env data sync (P1-T1 contract — sync exclusion is by
// omission from this array, not a denylist check).
module.exports.SYNC_ORDER = SYNC_ORDER;
