'use strict';

/**
 * failed-step-name.js — which step a failed run failed on, derived server-side
 * so the runs LIST never has to ship the full `step_results` document to answer
 * it (PR-2 Task 5).
 *
 * `deriveFailedStepName` never throws: a malformed or legacy-era step_results
 * text (not JSON, not an array, an entry with no step_name) all answer `null`
 * rather than 500ing a list read over one bad row.
 */

/**
 * @param {unknown} rawStepResultsText the run's step_results column, read via
 *   `CAST(... AS CHAR)` (see run-queries.js's RUN_DETAIL_COLUMNS comment for why
 *   — a raw JSON-typed select rounds large integers before this function sees
 *   the bytes). Callers must never re-ship this text; it is read only to derive
 *   the name below.
 * @returns {string|null} the first failed step's recorded name, or null when
 *   the run succeeded, step_results is unparseable/legacy-shaped, or the failed
 *   entry carries no step_name (legacy-era runs).
 */
function deriveFailedStepName(rawStepResultsText) {
  if (typeof rawStepResultsText !== 'string' || rawStepResultsText === '') return null;
  let parsed;
  try {
    parsed = JSON.parse(rawStepResultsText);
  } catch {
    return null;
  }
  if (!Array.isArray(parsed)) return null;
  const failedEntry = parsed.find((entry) => entry && typeof entry === 'object' && entry.ok === false);
  if (!failedEntry) return null;
  return typeof failedEntry.step_name === 'string' && failedEntry.step_name.length > 0
    ? failedEntry.step_name
    : null;
}

/**
 * Replace each row's raw step_results text (selected under `rawKey`) with the
 * derived `failed_step_name` — the raw text never survives past this call, so a
 * caller cannot forward it by forgetting to strip it.
 */
function attachFailedStepName(rows, rawKey = 'step_results_raw') {
  return rows.map((row) => {
    const { [rawKey]: rawStepResultsText, ...rest } = row;
    return { ...rest, failed_step_name: deriveFailedStepName(rawStepResultsText) };
  });
}

module.exports = { deriveFailedStepName, attachFailedStepName };
