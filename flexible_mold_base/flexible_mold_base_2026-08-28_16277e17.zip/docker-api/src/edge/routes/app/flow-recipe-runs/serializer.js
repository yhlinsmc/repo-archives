/**
 * serializer.js — secret masking for flow_recipe_runs snapshots.
 *
 * SECURITY: a run record is a durable, admin-searchable history row. Secrets are
 * injected only as outbound headers at dispatch — never into a payload — but a
 * credential-vending upstream can echo a token in its response body. This
 * serializer deep-redacts any secret-named leaf in five fields before persist:
 *   - step_results   — upstream response data (headers, body) per step
 *   - rendered_payload — the serialized outbound payload (JSON or YAML per the
 *     recipe's content_type)
 *   - output_snapshot  — the FE template output values written at run-create time
 *   - input_snapshot   — what the operator entered, plus what the form computed
 *     from it, written at run-create time
 *   - error_summary    — an upstream failure body, which is exactly where a
 *     credential-vending service echoes a token back. The finalize path has
 *     always masked it; this path is the one that did not.
 * The first three keep a value they cannot parse verbatim — including
 * `step_results` AS A WHOLE, whose unparseable string is left as it arrived
 * rather than replaced. `input_snapshot` is the exception and is REFUSED
 * instead — see `edge/lib/flow-run-input-snapshot.js` for why that column
 * alone is strict.
 *
 * ONE FIELD INSIDE `step_results` IS NOT PART OF THAT "keep it verbatim" RULE:
 * a failed step's `error_body`. It is an UPSTREAM-CONTROLLED response body —
 * readable, via the run detail, by every authenticated user — so unlike the
 * rest of this column (client-authored or server-derived) it can carry
 * anything an upstream chooses to answer with. `maskErrorBody` below fails
 * CLOSED on it: parse success on a JSON/YAML object or array → masked and
 * stored; anything else (HTML, plain text, base64, a bare scalar) → withheld
 * entirely, never stored raw (PR-2 review F2).
 *
 * THE MASKER ONLY EVER SEES INTACT STRUCTURE. `error_body` reaches this
 * module UNTRUNCATED — both producers (`docker-api/src/infra/routes/
 * flow-recipe-run.js`, `src/fmb/lib/flow/run-chain.ts`) relay the upstream
 * body whole, or send NO `error_body` at all (a sibling `error_body_omitted`
 * NUMBER instead — see `FlowStepResultEntry` in types.ts), never a sliced
 * prefix. Cutting a raw body before masking can land mid-token, turn valid
 * JSON/YAML into invalid text, and make the mask's own parser throw — the
 * (still-raw) text then has no masked form to fall back to. That defect was
 * empirically reproduced (PR-2 review F1): a 10 KB body containing
 * `access_token`, sliced to 8192 chars, failed both parsers, and the token
 * landed in the durable audit row verbatim. A first fix sent a PLACEHOLDER
 * STRING as `error_body` for an over-cap body instead of slicing it —
 * review round 2 found that a `[`-leading placeholder parses as a YAML flow
 * sequence, so it passed the structured-parse gate and was stored mangled
 * rather than withheld; `error_body_omitted` removes the whole class by
 * putting the omission on a field the masker never inspects at all.
 * `STEP_ERROR_BODY_MAX` below is a STORAGE cap applied to the MASKED
 * `error_body` text only — a cut can then only ever cut into `****` or the
 * withheld placeholder, never a secret.
 *
 * Masking keys on the FIELD NAME. A value that looks like a secret under a name
 * that does not is stored as typed; that is inherent to keyword masking and is
 * not a gap this module closes.
 */
const yaml = require('yaml');
const {
  MAX_RUN_INPUT_SNAPSHOT_BYTES,
  parseInputSnapshot,
  tooLargeInputSnapshotError,
} = require('../../../lib/flow-run-input-snapshot');

// WHICH KEYS NAME A SECRET — matched by whole key SEGMENT, not by substring.
//
// The previous pattern was an unanchored regex whose `pass(word|wd)?` group made
// the bare substring `pass` a match, so `passenger_count`, `bypass_valve`,
// `pass_rate`, `passive_cooling`, `tokenizer_mode`, `credentialing_body` and
// `total_passes` were all replaced with the mask. That was survivable while the
// only keys it ever saw were transformer output names and outbound payload keys
// — small, protocol-shaped sets. It stopped being survivable when
// `input_snapshot` arrived, because that document is keyed by blueprint
// `field_key`, which is free text authored by whoever uses the system and can
// carry any English word that contains those letters. The loss is silent,
// permanent (the run row is the only copy) and lands on the one column whose
// entire justification is fidelity.
//
// Note what that argument does and does not license. A key CONTAINING `pass`
// inside a longer word is not a credential under any naming convention, so
// `passenger_count` and `bypass_valve` are kept. A key whose own last word IS
// `pass` is a different case entirely and is masked — see SECRET_BARE_WORDS.
//
// The two sibling columns share this matcher and stop masking those words too.
// That is intended: they were false positives there as well.
//
// WHAT TIGHTENING COSTS, DERIVED RATHER THAN REMEMBERED. The corpus test crosses
// every term either matcher names with every separator, casing, plural and digit
// position, AND with a neighbouring word on each side, then runs both matchers
// over the ~62,000 spellings that produces. Every spelling the old pattern masked
// and this one stores has to fall into one of the families listed below, so a
// term added here, a spelling this matcher stops seeing, or a family that stops
// costing anything moves that derived list and fails the test rather than aging
// quietly into prose.
// See tests/edge/routes/app/flow-recipe-runs-secret-matcher-corpus.test.js.
//
// THE NEIGHBOUR AXIS IS WHY THIS PARAGRAPH IS BEING REWRITTEN A FOURTH TIME. The
// corpus previously generated each term alone, and claimed from that a residual
// of "exactly two families". Segment matching is neighbour-insensitive for every
// rule except the bare-word rule below — and nothing generated a neighbour, so
// `db_pass`, `user_pass` and `smtp_pass` were stored in plaintext by a release
// whose header said the residual was closed. A corpus that cannot vary the
// dimension a rule turns on establishes nothing about that rule.
//
// THE FAMILIES, each with the reason it is given up:
//   1. A term run into its neighbour with no boundary at all — `mypassword`,
//      `secretsmanager`, `apikeyv2`, `credentialing`, `tokenized`. Segment
//      matching cannot see these at all. The last two are the false positives
//      this change exists to remove; the rest are a real, accepted loss.
//   2. `pass` + `code` / `pass` + `key` split across a boundary — see the pair
//      list below for why those two pairs are deliberately not declared.
//   3. `pass` with another word after it. TWO KINDS OF KEY LAND HERE and only
//      one of them is an ordinary word, so the family is stated as both:
//        - the following word is the HEAD of the compound — `pass_rate`,
//          `pass_count`. The key names a rate or a count. This is the loss the
//          whole retightening exists to take.
//        - the following word is a QUALIFIER — `db_pass_old`, `db_pass_backup`,
//          `smtp_pass_new`, `db_pass_hash`. These ARE credentials, and they are
//          given up anyway. Nothing in the SHAPE separates a qualifier from a
//          head noun; only a list of qualifier words would, and that is the
//          hand-written completeness claim this module refuses, because it is
//          what broke rounds two and three. Masking on any following word
//          instead would re-break `pass_rate` and reverse the retightening
//          entirely. So the outcome turns on whether the author wrote `pass` or
//          `password`: `password_backup` and `db_password_old` stay masked by
//          the `password` segment.
//      Both halves are pinned in the serializer test — the ordinary words as
//      must-survive, the qualifier spellings as documented-and-stored, opposite
//      the documented-and-masked list — so neither side of the trade can move
//      on its own.
//   4. the plural `passes`, wherever it appears — `passes`, `total_passes`.
//
// Each word also matches its plural. Generated rather than hand-listed so that
// adding a term cannot silently omit one of its two spellings — the pair list
// below was hand-listed and lost `api_keys` exactly that way.
const SECRET_SEGMENT_WORDS = Object.freeze([
  'password', 'passwd',
  // The rest of the `pass*` credential vocabulary, which the substring pattern
  // caught for free and a segment matcher has to name: a passphrase is the
  // standard key name for an SSH / PEM / PKCS#12 key's own secret, a passcode
  // unlocks a device or completes an MFA step, a passkey is a WebAuthn
  // credential. None of the three is an English word this domain uses.
  'passphrase', 'passcode', 'passkey',
  'secret', 'token', 'authorization', 'bearer', 'credential',
  // Separator-free spellings, which segment as one word and so cannot be caught
  // by the adjacent-pair rule below.
  'apikey', 'privatekey',
]);
const SECRET_SEGMENTS = new Set(SECRET_SEGMENT_WORDS.flatMap((w) => [w, `${w}s`]));
// Terms spelled as two segments (`api_key`, `apiKey`, `X-Api-Key`, `private key`,
// `pass_phrase`). Plurals are generated for the same reason as above: `api_keys`
// and `private_keys` are ordinary credential names and were being stored.
//
// `pass`+`word` and `pass`+`wd` are here because `password` and `passwd` are the
// two spellings the OLD pattern named outright, and a segment matcher that took
// only the run-together spelling stored `pass_word`, `pass-word`, `passWord`,
// `pass_wd` and `passWd` in plaintext. Neither `word` nor `wd` occurs as a
// standalone segment of any key in this codebase (`keyword` is one segment, not
// two), so the pair costs no domain vocabulary.
//
// `pass`+`phrase` is here but `pass`+`code` and `pass`+`key` deliberately are
// not, even though `passcode` and `passkey` are secrets as one segment. Split
// across a separator those two are the shape `<physical pass>_<head noun>` —
// `boarding_pass_code`, `gate_pass_key` — where the head noun says the value is
// a code or a key belonging to a pass, whereas `pass phrase` attaches to nothing
// but the credential.
const SECRET_SEGMENT_PAIR_WORDS = Object.freeze([
  ['api', 'key'], ['private', 'key'],
  ['pass', 'phrase'], ['pass', 'word'], ['pass', 'wd'],
]);
const SECRET_SEGMENT_PAIRS = Object.freeze(
  SECRET_SEGMENT_PAIR_WORDS.flatMap(([first, second]) => [[first, second], [first, `${second}s`]]),
);
// `pass` names a credential UNLESS ANOTHER WORD FOLLOWS IT. `pass`, `db_pass`,
// `smtp_pass`, `pass2` are masked; `pass_rate`, `boarding_pass_count` and
// `gate_pass_key` are stored, because there the following word is the head noun
// and it says what the value is — a rate, a count, a code — and none of those is
// a password. A trailing digit is not such a word: `db_pass2` is the same
// credential as `db_pass`, on the rule this module already applies to
// `password2` / `token2`.
//
// WHY POSITION, AND NOT A LIST OF THE WORDS THAT PRECEDE A CREDENTIAL. Naming
// `db`, `user`, `smtp`, … is a completeness claim typed out by hand, and this
// matcher has now produced a defect in four consecutive rounds, two of them from
// exactly that: the next prefix nobody listed leaks silently, and no corpus can
// refute it, because a generator can only cross the prefixes someone already
// declared. Position is a property the corpus CAN vary — it generates a
// neighbouring word on each side — so the rule is checked over the dimension it
// turns on rather than over its own examples.
//
// A BARE `pass` CANNOT BE TOLD FROM AN ORDINARY WORD BY SHAPE, so the rule says
// which way to fail rather than pretending to decide. `db_pass` and
// `boarding_pass` are the same shape; nothing in the name separates them, and
// nothing can, because this matcher sees names and only names. The two failures
// are not equally bad:
//   - Not masking writes a credential verbatim into a durable, admin-readable
//     row that is the only copy of it. Nobody sees that it happened.
//   - Masking a domain value writes `****`, which is visible on the surface that
//     reads the row. Someone can see it and say so.
// An unrecoverable silent loss outweighs a visible reversible one, so the
// ambiguous shape masks. This is a decision about consequences, not about what
// any particular deployment happens to call its fields — field keys are runtime
// data authored by whoever uses the system, so a rule derived from today's
// names is wrong the moment somebody adds one.
//
// WHERE A FOLLOWING WORD DECIDES, and what that decision does NOT cover. When
// another WORD follows `pass`, the key is stored. The reason that is right for
// `pass_rate` and `boarding_pass_count` is that the following word is the head
// of the compound and says what the value is — a rate, a count — and a
// credential key names the credential, so the credential reading needs `pass` to
// be last. That reason holds for compounds nobody has written yet, which is what
// a list of allowed prefixes or allowed domain words could not do.
//
// It does NOT hold when the following word is a qualifier rather than a head:
// `db_pass_old`, `db_pass_backup`, `smtp_pass_new` are credentials and they are
// stored. Nothing in the shape tells a qualifier from a head noun. The only two
// fixes are a hand-written qualifier list — the completeness claim this module
// refuses, having been broken by one twice — or masking on any following word,
// which re-breaks `pass_rate` and reverses the retightening. So this is a
// declared loss rather than an oversight, and it is pinned as one; note that it
// makes the outcome turn on `pass` versus `password`, since `password_backup`
// stays masked.
//
// A trailing digit is not a following word at all: `db_pass2` is `db_pass`,
// counted, on the same rule this module already applies to `password2` and
// `token2`.
//
// THE PLURAL `passes` IS NOT MASKED, on a convention argument about how
// credentials are named. A map of credentials is named after the term
// — `api_keys`, `tokens`, `passwords` — and `passwords` is already masked, by
// the plural this module generates for every declared term. No credential naming
// convention produces `passes` that is not already covered by `passwords`, so
// masking it would buy nothing and would cost the plural of an everyday English
// word, which is where this matcher's first defect came from.
//
// WHAT IT COSTS, stated rather than discovered later, and pinned AS MASKED in
// the serializer test beside the domain words that survive, so the trade cannot
// be moved without editing both lists:
//   - any key whose last word is a bare `pass` — a physical pass, a machining
//     pass, an inspection pass — is masked;
//   - so are its counted forms, `pass2` / `pass_2` / `2_pass`. An earlier round
//     stored those, reading them as "the second pass"; that is reversed here,
//     because storing `pass2` while masking `pass` made the outcome turn on a
//     digit, which is exactly the outcome-nobody-authored this module already
//     refuses for `password2`.
const SECRET_BARE_WORDS = new Set(['pass']);
const MASK = '****';

// Split a key into lower-cased words: on any non-alphanumeric separator, on
// camelCase boundaries including an acronym run followed by a word
// (`XApiKey` → x, api, key), and on either direction of a letter/digit boundary.
//
// The digit boundaries are what keep a counted credential in the set. Without
// them a trailing digit stays glued to the word, so `password2` segments as one
// unknown word and is stored — while `password_2` is masked, turning the
// outcome on whether a separator happens to precede the digit. Counted pairs
// are a live naming pattern here (a live credential beside a `#backup` one).
function keySegments(key) {
  return String(key)
    .replace(/([A-Z]+)([A-Z][a-z])/g, '$1 $2')
    .replace(/([a-z0-9])([A-Z])/g, '$1 $2')
    .replace(/([A-Za-z])([0-9])/g, '$1 $2')
    .replace(/([0-9])([A-Za-z])/g, '$1 $2')
    .split(/[^A-Za-z0-9]+/)
    .filter(Boolean)
    .map((s) => s.toLowerCase());
}

// A segment carrying at least one letter. `keySegments` splits letter/digit
// boundaries, so a trailing count arrives as its own segment and must not be
// mistaken for the word that would make `pass` ordinary.
const isWordSegment = (s) => /[a-z]/.test(s);

// A bare credential word with no word after it — see the block above
// SECRET_BARE_WORDS for why position is the rule and what it costs. A word
// AFTER it makes it the English word (`pass_rate`,
// `gate_pass_key`); a digit does not (`db_pass2` is `db_pass`, counted).
function unmodifiedBareWordIsSecret(segments) {
  return segments.some((s, i) => (
    SECRET_BARE_WORDS.has(s) && !segments.slice(i + 1).some(isWordSegment)
  ));
}

function isSecretKey(key) {
  const segments = keySegments(key);
  if (segments.some((s) => SECRET_SEGMENTS.has(s))) return true;
  if (SECRET_SEGMENT_PAIRS.some(([first, second]) =>
    segments.some((s, i) => s === first && segments[i + 1] === second))) return true;
  return unmodifiedBareWordIsSecret(segments);
}
const MAX_DEPTH = 64;
// SECURITY: drop prototype-pollution keys at every level (mirrors the sibling
// `deepJsonExpand` in shared/lib/flow-payload-serialize.js). A crafted upstream
// response body or error_summary can carry an own `__proto__`/`constructor`/
// `prototype` key (JSON.parse makes them own-enumerable); assigning `out[k]`
// would swap the result's prototype or shadow `constructor`. Skip them so the
// masked audit row cannot smuggle a pollution vector.
const DANGEROUS_KEYS = new Set(['__proto__', 'constructor', 'prototype']);

function maskDeep(v, depth = 0) {
  // SECURITY: fail-closed at MAX_DEPTH — discard the subtree rather than
  // passing it through, so a pathologically deep structure cannot smuggle
  // secret-named keys below the cap into the audit row verbatim.
  if (depth > MAX_DEPTH) return MASK;
  if (Array.isArray(v)) return v.map((item) => maskDeep(item, depth + 1));
  if (v && typeof v === 'object') {
    const out = {};
    for (const [k, val] of Object.entries(v)) {
      if (DANGEROUS_KEYS.has(k)) continue;
      out[k] = isSecretKey(k) ? MASK : maskDeep(val, depth + 1);
    }
    return out;
  }
  if (typeof v === 'string') {
    // SECURITY: an upstream response body may arrive as a JSON-encoded string
    // (e.g. a credential-vending service echoes {"access_token":"…"}). Parse,
    // mask recursively, and re-stringify so secret-named keys inside it are
    // redacted before the value reaches the audit row.
    const s = v.trim();
    if (s && (s[0] === '{' || s[0] === '[')) {
      try { return JSON.stringify(maskDeep(JSON.parse(v), depth + 1)); } catch { /* not JSON — fall through */ }
    }
    return v;
  }
  return v;
}

/**
 * Mask a serialized outbound payload. The rendered_payload is JSON or YAML per
 * the recipe's content_type; try JSON first (so a JSON payload re-emits as JSON)
 * then fall back to YAML so a YAML-content recipe's secret-named keys are also
 * redacted before the value reaches the durable audit row. A value that is
 * neither (opaque) is left verbatim.
 */
function maskSerializedPayload(text) {
  try { return JSON.stringify(maskDeep(JSON.parse(text))); }
  catch { /* not JSON — try YAML */ }
  try {
    const parsed = yaml.parse(text);
    if (parsed && typeof parsed === 'object') {
      return yaml.stringify(maskDeep(parsed), { lineWidth: 0 });
    }
  } catch { /* not YAML either */ }
  return text;
}

// ── error_body: fail-closed structured masking (F2) + value-leak scrub (F3) ──

// Chars. STORAGE cap, applied to the MASKED text only — see the module header
// INVARIANT. Not the transport cap (STEP_ERROR_BODY_TRANSPORT_MAX, 32768,
// duplicated in the two producers) — that one bounds what reaches this
// function at all; this one bounds what a masked, already-safe string takes
// up in the row.
const STEP_ERROR_BODY_MAX = 8192;

// F2: an error_body that is not a JSON/YAML object or array is stored as
// NOTHING of the upstream body — never truncated-but-raw, never re-encoded
// verbatim. HTML, plain text, base64 and any other opaque shape all land here.
const UNSTRUCTURED_ERROR_BODY_PLACEHOLDER = '[unstructured upstream response withheld]';

// F3: defense-in-depth value-leak patterns, run over STRING LEAVES after
// key-name masking (maskDeep) has already run. THIS IS NOT A COMPLETENESS
// PROOF — an upstream can echo a credential in a shape none of these five
// patterns match, under a key name `isSecretKey` does not recognise either.
// The controls this module actually relies on are (a) F2's fail-closed rule,
// which withholds anything that is not structured at all, and (b) key-name
// masking above; this pass only catches a token-SHAPED value sitting under an
// innocuous key inside an otherwise-legitimate structured body.
const VALUE_LEAK_PATTERNS = [
  /Bearer\s+[A-Za-z0-9\-_.=]+/g,                          // `Authorization: Bearer <token>`-shaped text
  /eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]*/g,    // JWT (header.payload.signature)
  /\bsk_live_[A-Za-z0-9]+/g,                               // Stripe live secret key
  /\bsk_test_[A-Za-z0-9]+/g,                               // Stripe test secret key
  /\bghp_[A-Za-z0-9]+/g,                                   // GitHub personal access token
  /\bgho_[A-Za-z0-9]+/g,                                   // GitHub OAuth token
  /\bAKIA[A-Za-z0-9]{12,}/g,                                // AWS access key id
  /\b[a-fA-F0-9]{32,}\b/g,                                  // a bare hex run this long is a key/hash/token, not prose
  /\b[A-Za-z0-9+/]{32,}={0,2}\b/g,                          // ditto for base64
];

function redactValueLeaks(v, depth = 0) {
  // SECURITY: same fail-closed depth cap as maskDeep — a pathologically deep
  // structure must not smuggle an unscrubbed leaf below it.
  if (depth > MAX_DEPTH) return MASK;
  if (Array.isArray(v)) return v.map((item) => redactValueLeaks(item, depth + 1));
  if (v && typeof v === 'object') {
    const out = {};
    for (const [k, val] of Object.entries(v)) {
      if (DANGEROUS_KEYS.has(k)) continue;
      out[k] = redactValueLeaks(val, depth + 1);
    }
    return out;
  }
  if (typeof v === 'string') {
    let out = v;
    for (const pattern of VALUE_LEAK_PATTERNS) out = out.replace(pattern, MASK);
    return out;
  }
  return v;
}

/**
 * Mask ONE step's error_body. Unlike `maskSerializedPayload` (rendered_payload
 * — operator-authored, kept verbatim when unparseable, per the module header),
 * this fails CLOSED: only a JSON/YAML object or array is masked and stored;
 * anything else is replaced with {@link UNSTRUCTURED_ERROR_BODY_PLACEHOLDER}.
 * Storage-caps the MASKED result only — see the module header INVARIANT.
 */
function maskErrorBody(text) {
  if (typeof text !== 'string' || text === '') return text;
  // IDEMPOTENCY: a row can reach serializeWrite a second time (an admin PUT
  // that round-trips an already-masked row). The placeholder starts with `[`,
  // which the YAML branch below parses as a one-item flow sequence and would
  // re-stringify as "- unstructured upstream response withheld\n" — no longer
  // byte-identical to UNSTRUCTURED_ERROR_BODY_PLACEHOLDER, which breaks the
  // FE's exact-string withheld-chip check on the second write. Short-circuit
  // before either parser sees it.
  if (text === UNSTRUCTURED_ERROR_BODY_PLACEHOLDER) return text;
  let masked;
  try {
    const parsed = JSON.parse(text);
    if (parsed && typeof parsed === 'object') {
      masked = JSON.stringify(redactValueLeaks(maskDeep(parsed)));
    }
  } catch { /* not JSON — try YAML */ }
  if (masked === undefined) {
    try {
      const parsed = yaml.parse(text);
      if (parsed && typeof parsed === 'object') {
        masked = yaml.stringify(redactValueLeaks(maskDeep(parsed)), { lineWidth: 0 });
      }
    } catch { /* not YAML either */ }
  }
  if (masked === undefined) masked = UNSTRUCTURED_ERROR_BODY_PLACEHOLDER;
  return masked.length > STEP_ERROR_BODY_MAX ? masked.slice(0, STEP_ERROR_BODY_MAX) : masked;
}

// Pre-parse input bound for `content_type`. A header value longer than this is
// truncated BEFORE the media-type parse below even looks at it, so the parser
// never walks an unbounded string. No legitimate `Content-Type: <type>;
// charset=<c>; boundary=<b>` value approaches 256 chars, and the reconstructed
// stored value is bounded far tighter than this by construction (only a parsed
// `type/subtype` plus an optional short `charset` survives) — this cap only
// bounds the parser's input, not the output.
const STEP_CONTENT_TYPE_MAX = 256;

// RFC 7230 token charset. A media type's `type` and `subtype` are each exactly
// one token — the same grammar the HTTP spec uses. Anything with a space, a
// control char, a quote, `@`, `:` etc. is not a token and therefore not a media
// type at all. Used only for the coarse `type "/" subtype` structural split;
// the type and subtype slots are each constrained FURTHER below (a closed enum /
// a tighter grammar), because the token charset alone still admits a
// secret-shaped subtype like `ghp_…` (confirm-seat counterexample).
const RFC7230_TOKEN = "[A-Za-z0-9!#$%&'*+.^_`|~-]+";
// `type "/" subtype`, whole-string. Both sides are tokens.
const MEDIA_TYPE_RE = new RegExp(`^(${RFC7230_TOKEN})/(${RFC7230_TOKEN})$`);

// TYPE slot: the closed set of IANA top-level media types (RFC 6838 §4.2 plus
// `font`, RFC 8081). This is a completeness claim that CANNOT age — the IANA
// top-level registry is closed by policy, not extended per-vendor (vendor
// variation lives in the SUBTYPE tree). Constraining the type to this enum
// closes the type slot by construction: a secret-shaped `type` (`ghp_…/…`,
// `AKIA…/…`) is not one of the nine and withholds the field.
const MEDIA_TOP_LEVEL_TYPES = new Set([
  'application', 'text', 'image', 'audio', 'video', 'multipart', 'message', 'font', 'model',
]);

// SUBTYPE slot grammar, applied to the LOWERCASED subtype. Deliberately TIGHTER
// than an RFC 7230 token: no underscore. Standards-tree and vendor-tree subtypes
// use `.`, `+` (structured suffix) and `-`, never `_`; every common leaked-token
// prefix does require `_` (`ghp_`, `sk_live_`, `sk_test_`, `gho_`), so dropping
// underscore removes that whole shape from the subtype slot. Capped at 100 chars
// (the longest real subtype, the OOXML wordprocessing one, is ~65).
const SUBTYPE_RE = /^[a-z0-9][a-z0-9.+-]{0,99}$/;

/**
 * Sanitize one entry's `content_type` by PARSE-AND-ALLOWLIST, not by pattern
 * scrub. `content_type` is upstream-controlled (an HTTP response header echoed
 * back into this durable, admin-readable row), unlike `step_id`/`ok`/
 * `upstream_status`, which are server-derived.
 *
 * WHY NOT `redactValueLeaks` AS THE PRIMARY CONTROL. A scrub pass is an
 * enumerated blocklist: a hostile upstream can return a media type that is VALID
 * by the HTTP grammar yet carries a secret — in a parameter (`text/plain;
 * authorization="short-secret"`), in the subtype slot (`application/ghp_abc…`),
 * or even in an allowlisted parameter value (`text/plain; charset=ghp_abc…`,
 * since the RFC 7230 token charset includes `_`) — that matches none of the
 * value-leak patterns, so it survived verbatim into the row (Codex P1,
 * confirm-seat P1b, then round-2 P1c on the charset value). The stored value is
 * reconstructed from ONLY the parsed pieces, so it is closed by construction
 * rather than filtered:
 *
 *   - PARAMETERS — DROPPED ENTIRELY, no exceptions. Nothing after the first `;`
 *     is ever read. An earlier version kept an allowlisted `charset`; round 2
 *     proved a charset VALUE is itself a token slot a secret fits (`charset=
 *     ghp_…`). A charset (or boundary, or any parameter) carries near-zero
 *     diagnostic value for a FAILED upstream call — not worth keeping a leak
 *     channel open for — so the whole parameter section is discarded. There is
 *     no parameter channel left at all, not a pattern list to keep complete.
 *   - TYPE — closed enum. The lowercased type must be one of the nine IANA
 *     top-level types (`MEDIA_TOP_LEVEL_TYPES`); the registry is closed by
 *     policy, so this is a completeness claim that cannot age. A secret-shaped
 *     type is not one of the nine.
 *   - SUBTYPE — grammar-constrained (`SUBTYPE_RE`, no underscore, ≤100 chars)
 *     PLUS a value-leak backstop run over the ORIGINAL-CASE subtype (so the
 *     upper-case-anchored `AKIA…` pattern still fires): any pattern hit
 *     WITHHOLDS the whole field rather than storing a `****`-mangled subtype.
 *
 * THE ONLY SURVIVING FREE SLOT is the subtype — it is the one part a real media
 * type structurally needs to be free text (the vendor tree is open-ended). What
 * can still pass is a lower-case alphanumeric string, ≤100 chars, containing no
 * underscore and matching none of the value-leak patterns. That is exactly the
 * residual class F3 already documents for structured bodies (see
 * VALUE_LEAK_PATTERNS' header: a token-shaped value under an innocuous slot that
 * no pattern names). It is bounded, visible on the surface that reads the row,
 * reversible, and no worse than the body case this module already lives with;
 * parameters (charset included) and the type slot are now both closed entirely.
 *
 * HOW NARROW, PRECISELY: "matching none of the value-leak patterns"
 * undersells itself — VALUE_LEAK_PATTERNS' generic
 * base64/hex entries (`[A-Za-z0-9+/]{32,}`, `[a-fA-F0-9]{32,}`) sweep ANY
 * contiguous 32+-char alphanumeric run regardless of case or shape, and
 * `SUBTYPE_RE` already forbids `/`. So the only subtype text that can still
 * pass through is a run SHORTER than 32 chars, or one deliberately broken up
 * by `.`/`+`/`-` (the three punctuation characters `SUBTYPE_RE` allows) —
 * not "an alphanumeric string up to 100 chars" in general.
 *
 * FAIL-CLOSED on anything that is not a well-formed, enum-typed, grammar-clean
 * media type: the whole `content_type` field is REMOVED from the entry —
 * mirroring maskErrorBody's F2 withholding rule rather than storing a guess.
 */
function sanitizeEntryContentType(entry) {
  if (typeof entry.content_type !== 'string') return entry;
  // Withhold the field entirely (F2 philosophy) — used at every fail-closed gate
  // below so a rejected value never reaches the row in any form.
  const withhold = () => {
    const { content_type, ...rest } = entry;
    return rest;
  };
  // Pre-parse bound: never parse more than STEP_CONTENT_TYPE_MAX chars.
  const capped = entry.content_type.length > STEP_CONTENT_TYPE_MAX
    ? entry.content_type.slice(0, STEP_CONTENT_TYPE_MAX)
    : entry.content_type;
  // The media type is everything before the first `;`; parameters are discarded
  // wholesale (see below), so only this leading segment is ever parsed.
  const mediaMatch = MEDIA_TYPE_RE.exec(capped.split(';', 1)[0].trim());
  // Not even `token/token` in shape → not a media type at all.
  if (!mediaMatch) return withhold();
  const type = mediaMatch[1].toLowerCase();
  const rawSubtype = mediaMatch[2];
  const subtype = rawSubtype.toLowerCase();
  // TYPE: closed enum. Anything outside the nine IANA top-level types withholds.
  if (!MEDIA_TOP_LEVEL_TYPES.has(type)) return withhold();
  // SUBTYPE: tighter-than-token grammar (no underscore, ≤100 chars).
  if (!SUBTYPE_RE.test(subtype)) return withhold();
  // SUBTYPE backstop: run the value-leak scrub over the ORIGINAL-CASE subtype
  // (AKIA… and other patterns are case-anchored). A hit means it is token-shaped
  // rather than a media subtype → withhold, never store a ****-mangled value.
  if (redactValueLeaks(rawSubtype) !== rawSubtype) return withhold();
  // Store ONLY `type/subtype`. Every parameter — charset, boundary,
  // authorization, anything — is dropped by construction: only the two parsed
  // media-type tokens are re-emitted, nothing after the first `;` is read. See
  // the block comment for why the charset slot was removed rather than
  // allowlisted (it was the last surviving leak channel and carries near-zero
  // diagnostic value for a failed call).
  return { ...entry, content_type: `${type}/${subtype}` };
}

/**
 * Apply {@link maskErrorBody} to every entry's `error_body` and
 * {@link sanitizeEntryContentType} to every entry's `content_type`,
 * tolerating a malformed step_results shape (F7): the documented shape is an
 * array of entries, but a write that is a single object carrying its own
 * `error_body` must not skip this pass just because `Array.isArray` does not
 * match it — that would reopen the exact YAML/unstructured gap F1/F2 close,
 * on the one path least likely to be covered by a shape-specific test.
 *
 * Also stamps `error_body_chars` = the PRE-mask character count, read off the
 * intact string before maskErrorBody replaces it with a placeholder/capped/
 * masked value. This is additive only — it does not change what maskErrorBody
 * itself decides to store — and is the one place a size can still be shown to
 * an operator even when the body underneath is withheld or truncated.
 * Stamped ONLY when the entry does not already carry the field: a second
 * serializeWrite pass over an already-masked row (an admin PUT round-tripping
 * it) must not overwrite the true pre-mask size with the masked/placeholder
 * text's own (shorter, and now meaningless) length.
 */
function maskEntryErrorBodies(sr) {
  const maskEntry = (entry) => {
    if (!entry || typeof entry !== 'object') return entry;
    let out = sanitizeEntryContentType(entry);
    if (typeof entry.error_body === 'string' && entry.error_body !== '') {
      out = {
        ...out,
        error_body: maskErrorBody(entry.error_body),
        ...(Object.prototype.hasOwnProperty.call(entry, 'error_body_chars')
          ? {}
          : { error_body_chars: entry.error_body.length }),
      };
    }
    return out;
  };
  if (Array.isArray(sr)) return sr.map(maskEntry);
  if (sr && typeof sr === 'object') return maskEntry(sr);
  return sr;
}

// SECURITY: the generic CRUD mount's GET / and GET /:id (crud-factory.js) parse
// every row through the DTO mapper's registered JSON columns, which rounds any
// step_results integer past IEEE-754's 53-bit safe range the instant JSON.parse
// touches it (dto-mapper.js flow_recipe_runs entry). The hardened detail route
// (aggregate.js) reads step_results as CAST(... AS CHAR) and ships it as raw
// text specifically to avoid that round; this generic mount has no such CAST
// and no reason to reproduce it, since nothing in the browser reads step_results
// through here (see index.js's route-ordering comment). Dropping the field
// closes the parse+round read rather than hardening it: the dedicated route
// stays the only step_results read port.
function serializeRead(row) {
  if (!row || typeof row !== 'object' || !('step_results' in row)) return row;
  const { step_results, ...rest } = row;
  return rest;
}

async function serializeWrite(data, ctx) {
  if (!data || typeof data !== 'object') return data;
  const out = { ...data };
  // SECURITY: actor_id is the authenticated initiator, never client-trusted.
  // The generic write-scope stamp only fires for non-admins (admins may write
  // rows for other users on other tables); a run is always self-initiated, so
  // stamp it here for every role on create. Without this an admin POST omits
  // actor_id and the NOT NULL column rejects the insert.
  if (ctx && ctx.isUpdate === false && ctx.req && ctx.req.user && ctx.req.user.id) {
    out.actor_id = ctx.req.user.id;
  }
  if (out.step_results != null) {
    let sr = out.step_results;
    if (typeof sr === 'string') { try { sr = JSON.parse(sr); } catch { sr = null; } }
    if (sr != null) {
      // A failed step's error_body is masked FIRST, on the INTACT string —
      // maskErrorBody fails closed (F2), scrubs value-shaped leaks (F3), and
      // storage-caps its own masked output (F1) — before the generic
      // key-name pass below walks the rest of the entry (step_id, ok,
      // upstream_status, step_name — none of which need this treatment).
      // maskDeep DOES also revisit the now-masked error_body string as part
      // of its normal recursion; that second pass is a no-op-or-safer-still
      // on already-masked/placeholder/capped text (idempotent when it is
      // valid JSON, a silent no-change via its own catch when capping made it
      // invalid JSON) — never a route back to the raw upstream bytes, which
      // this function never sees again after maskErrorBody has replaced them.
      sr = maskEntryErrorBodies(sr);
      out.step_results = maskDeep(sr);
    }
  }
  if (typeof out.rendered_payload === 'string' && out.rendered_payload.length) {
    out.rendered_payload = maskSerializedPayload(out.rendered_payload);
  }
  // TWO WRITE PATHS TO ONE COLUMN AGREED ABOUT WHAT ELSE IT CAN CARRY, AND NOT
  // ABOUT THIS. The finalize path masks `error_summary` before persisting it,
  // because an upstream failure body is exactly where a credential-vending
  // service echoes a token back. The generic PUT — open to the run's own actor
  // and to any admin — wrote the same column raw into a row every authenticated
  // caller reads. The enumeration of four fields above read as deliberate; the
  // finalize path's own masking says otherwise.
  //
  // A non-string is left alone rather than coalesced: the shape of this column
  // is the finalize path's contract, and rewriting a value here would be this
  // hook deciding a question the write gates own.
  if (typeof out.error_summary === 'string' && out.error_summary.length) {
    out.error_summary = maskDeep(out.error_summary);
  }
  if (typeof out.output_snapshot === 'string' && out.output_snapshot.length) {
    try { out.output_snapshot = JSON.stringify(maskDeep(JSON.parse(out.output_snapshot))); }
    catch { /* not JSON — leave verbatim */ }
  }
  if (out.input_snapshot != null) {
    // Unlike its two siblings this column REFUSES what it cannot read, rather
    // than storing it verbatim — see flow-run-input-snapshot.js for why the
    // three are treated differently. Validating first is also what closes the
    // hole the type guard used to leave: a non-string value skipped masking and
    // the size bound entirely and was serialised by the driver on the wire.
    const { kind, document } = parseInputSnapshot(out.input_snapshot);
    // Masked by key name, exactly as the two snapshots above are. That redacts a
    // field NAMED like a secret; it cannot redact a secret pasted into a field
    // named something else, because nothing here inspects values. The earlier
    // wording here claimed the stronger guarantee and the code never made it.
    //
    // ONLY THE VALUE MAPS ARE MASKED. `fields` maps each key to its stable
    // blueprint_fields.id, and an id is not a secret. Masking the whole document
    // turned the id of a field named `api_key` into '****', which destroyed —
    // for exactly the fields most worth auditing — the only thing CAPABLE of
    // telling "the same field, renamed" from "a different field wearing the old
    // key". Capable, not doing: no reader joins on this half yet. The replay
    // matches on field_key and the comparison is not handed the half at all, so
    // today it is a record kept intact for a reader that does not exist. That is
    // the reason to keep it readable rather than a description of a mechanism
    // this file participates in.
    //
    // WHAT MAKES LEAVING THEM SAFE is that the shape validator has proved every
    // one of these values IS an id, not merely that it is a string. "A flat map
    // of strings" — which is what the first version of this exemption relied on
    // — left the identity half as an unmasked slot on a durable, admin-readable
    // row, fillable with `{"note":"<a real secret>"}` from a create route open to
    // any authenticated user. The masking is unchanged and the exemption stands;
    // the half is now bounded to what it claims to hold instead.
    out.input_snapshot = JSON.stringify(kind === 'captured'
      ? { ...document, entered: maskDeep(document.entered), computed: maskDeep(document.computed) }
      : document);
    // Measured AFTER masking, because that is the string that reaches the
    // column: a document whose secrets collapse to '****' is stored at the size
    // it is stored at, not the size it arrived at.
    const size = Buffer.byteLength(out.input_snapshot, 'utf8');
    if (size > MAX_RUN_INPUT_SNAPSHOT_BYTES) {
      throw tooLargeInputSnapshotError(size, MAX_RUN_INPUT_SNAPSHOT_BYTES);
    }
  }
  return out;
}

module.exports = {
  serializeWrite,
  serializeRead,
  maskDeep,
  isSecretKey,
  keySegments,
  MAX_RUN_INPUT_SNAPSHOT_BYTES,
  // Exported for the corpus test only. It generates spellings from these, so a
  // term added here without a corpus entry fails rather than going untested —
  // which is what makes the cost list above derived instead of remembered.
  SECRET_SEGMENT_WORDS,
  SECRET_SEGMENT_PAIR_WORDS,
  SECRET_BARE_WORDS,
  // PR-2 review fix batch (F1-F3, F6, F7) — exported for direct unit
  // testing of the error_body pipeline in isolation from the full step_results
  // write path.
  maskErrorBody,
  redactValueLeaks,
  maskEntryErrorBodies,
  STEP_ERROR_BODY_MAX,
  UNSTRUCTURED_ERROR_BODY_PLACEHOLDER,
  STEP_CONTENT_TYPE_MAX,
};
