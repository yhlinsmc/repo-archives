/**
 * connector-replace-mode.test.js — backend parity for write_mode:'replace'
 * (D3/D4 + CN-REPL): validate.js accepts a bare replace output
 * (same-table OR cross-table — CN-REPL made whole-table replace legal
 * cross-table too), rejects it combined with match/on_no_match, and
 * usable.js projects write_mode:'replace' through to the data-entry runtime
 * (it was previously stripped by the append/merge-only whitelist). Mirrors
 * the FE twins (output-verbs.ts resolveRowsWriteMode, connector-save-guards.ts
 * validateRowsSinkOutput) — messages are not required to be byte-identical to
 * the FE here (different wording is fine as long as both reject/accept the
 * same shapes), but this suite pins the BE side of the contract on its own.
 */
import { describe, it, expect } from 'vitest';

const { validateResponseOutputs, validateConnectorCoherence } = require('../validate');
const { buildUsableProjection } = require('../usable');

const replaceRowsOutput = (extra = {}) => ({
  outputs: [{
    id: 'o1',
    from: { mode: 'list', path: 'items' },
    to: {
      mode: 'rows', table_key: 'parts',
      columns: [{ column_key: 'qty', from: 'qty' }],
      write_mode: 'replace',
      ...extra,
    },
  }],
});

describe('validateResponseOutputs — write_mode:replace', () => {
  it('accepts a bare replace output (no match, no on_no_match)', () => {
    expect(validateResponseOutputs(replaceRowsOutput())).toBeNull();
  });

  it('rejects a replace output carrying match keys', () => {
    const cfg = replaceRowsOutput({ match: { keys: [{ row_column: 'part_no', element_field: 'name', op: 'eq' }] } });
    expect(validateResponseOutputs(cfg)).toMatch(/write_mode 'replace' cannot declare match keys/);
  });

  it('rejects a replace output carrying a legacy single-pair match too', () => {
    const cfg = replaceRowsOutput({ match: { row_column: 'part_no', element_field: 'name' } });
    expect(validateResponseOutputs(cfg)).toMatch(/write_mode 'replace' cannot declare match keys/);
  });

  it('rejects a replace output carrying a stray on_no_match (no match block)', () => {
    const cfg = replaceRowsOutput({ on_no_match: 'create' });
    expect(validateResponseOutputs(cfg)).toMatch(/write_mode 'replace' cannot set on_no_match/);
  });

  // F1 (review fix batch): a bare 'skip' with no match block used to
  // fall through the generic "on_no_match must be 'skip' when present" check
  // (it IS 'skip'), reaching the DB — mirrors the FE guard rejecting ANY
  // on_no_match on replace, not just a non-'skip' value.
  it("rejects a replace output carrying on_no_match:'skip' (no match block) — was accepted before the F1 fix", () => {
    const cfg = replaceRowsOutput({ on_no_match: 'skip' });
    expect(validateResponseOutputs(cfg)).toMatch(/write_mode 'replace' cannot set on_no_match/);
  });
});

describe('validateConnectorCoherence — write_mode:replace', () => {
  const req = (cells) => (cells === undefined ? {} : { input_cells: cells });
  const perRowCell = (table_key, column_key, v) => ({ table_key, column_key, var: v });

  // CN-REPL: a replace output targeting a DIFFERENT table than the per-row
  // bound source is now a legal cross-table replace (no match keys — the
  // guard above already rejects those on ANY replace, same-table or cross).
  // It is exempt from the scalar-input-only fan-out check below too — a
  // cross-table rows sink REQUIRES the per-row input to drive its aggregation.
  it('accepts a replace output targeting a DIFFERENT table than the per-row bound source (cross-table replace)', () => {
    const err = validateConnectorCoherence(
      req([perRowCell('source_t', 'c', 'q')]),
      replaceRowsOutput({ table_key: 'target_t' }),
    );
    expect(err).toBeNull();
  });

  it('rejects a same-table replace paired with a per-row table cell — replace is scalar-input only, same as append', () => {
    // A replace output's row-building is identical to append's (scalar-input,
    // create-rows fan-out) — it cannot be paired with a per-row table cell.
    const err = validateConnectorCoherence(
      req([perRowCell('parts', 'c', 'q')]),
      replaceRowsOutput({ table_key: 'parts' }),
    );
    expect(err).toMatch(/must use scalar inputs/i);
  });

  it('accepts a scalar-input (no table input cells) replace output', () => {
    const err = validateConnectorCoherence(req(), replaceRowsOutput());
    expect(err).toBeNull();
  });
});

describe('buildUsableProjection — write_mode:replace passthrough', () => {
  it('preserves write_mode:replace in the data-entry projection (previously stripped by the append/merge whitelist)', () => {
    const connector = { id: 'c1', name: 'C', description: null, response_config: replaceRowsOutput() };
    const to = buildUsableProjection(connector, new Map()).response_config.outputs[0].to;
    expect(to.write_mode).toBe('replace');
  });

  it('never carries a match block through for a replace output (no match was stored)', () => {
    const connector = { id: 'c1', name: 'C', description: null, response_config: replaceRowsOutput() };
    const to = buildUsableProjection(connector, new Map()).response_config.outputs[0].to;
    expect(to.match).toBeUndefined();
  });

  // F2 (review fix batch): defense-in-depth for a row written before
  // validate.js rejected replace+match/on_no_match — the projection must strip
  // them rather than forward a stale join config to the runtime, even though
  // this shape can no longer be SAVED going forward.
  it('strips a legacy stored match+on_no_match on a replace output rather than forwarding it to the runtime', () => {
    const legacyConfig = replaceRowsOutput({
      match: { keys: [{ row_column: 'part_no', element_field: 'name', op: 'eq' }] },
      on_no_match: 'create',
    });
    const connector = { id: 'c1', name: 'C', description: null, response_config: legacyConfig };
    const to = buildUsableProjection(connector, new Map()).response_config.outputs[0].to;
    expect(to.write_mode).toBe('replace');
    expect(to.match).toBeUndefined();
    expect(to.on_no_match).toBeUndefined();
  });
});
