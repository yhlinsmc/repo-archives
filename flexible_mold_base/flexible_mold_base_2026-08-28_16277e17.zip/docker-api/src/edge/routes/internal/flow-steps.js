/**
 * flow-steps.js — edge-side flow-step dispatch brain (S2S-only).
 *
 * /prepare is the SOLE dispatch entry. It loads the step, gates on the parent
 * recipe's approval, decrypts auth_config, resolves the request, enforces the
 * egress allow-list + breaker, writes a pending audit, then routes by the
 * step's dispatch_origin (edge → inline execute; infra → SSRF pin + prepared).
 *
 * SECURITY: prepared.headers carries the decrypted secret over the S2S channel
 * only; it is never logged or written to an audit row. Audit rows carry
 * step_id/recipe_id/run_id/host/method/status.
 */
const router = require('express').Router();
const { pool } = require('../../db');
const { apiOk, apiError, uuidv4 } = require('../../../shared/helpers');
const { DecryptError } = require('../../../shared/lib/decrypt-error');
const { decryptRow } = require('../app/flow-recipe-steps/serializer');
const { egressAllowedForUrl } = require('../../../shared/lib/egress-policy');
const { t } = require('../../db');
const { mapRowsFromDb } = require('../../lib/dto-mapper');
const {
  FLOW_EVENT, FLOW_ERROR_STATUS, loadStepRow, loadRecipeGate, writeFlowAudit,
  resolveRequest, runEdgeExecute, breaker, resolveAndPin, DEFAULT_TIMEOUT_MS, DEFAULT_MAX_BYTES,
} = require('../../lib/flow-dispatch');
const { TABLES } = require('../../../shared/constants');
const { buildTemplateContext, resolveCallerDisplayName, resolveHierarchyNodeName } = require('../../lib/flow-template-context');
const { logger: rootLogger } = require('../../../shared/lib/logger');
// The same reading of the same column as the connector dispatch gate — one
// module, so the two cannot drift. See review-status.js.
const { dispatchAllowed } = require('../../lib/review-status');

const logger = rootLogger.child({ module: 'edge-flow-steps-internal' });

// SECURITY: clamp per-step dispatch timeouts to the fixed S2S proxy budget
// (125 s). An unbounded timeout lets an editor-stored value hold an outbound
// socket open far past the proxy window → proxy aborts while work continues,
// producing phantom retries and resource exhaustion on the target.
const MAX_STEP_TIMEOUT_MS = 120_000;

function hostOf(url) { try { return new URL(url).host; } catch { return null; } }

router.post('/prepare', async (req, res) => {
  const { step_id: stepId, inputs = {}, run_id: runId = null } = req.body || {};
  const safeInputs = (inputs && typeof inputs === 'object' && !Array.isArray(inputs)) ? inputs : {};
  const isAdmin = req.user?.role === 'admin';

  if (!stepId || typeof stepId !== 'string') {
    const e = apiError('step_id required', 'BAD_REQUEST', 400);
    return res.status(e.status).json(e.body);
  }

  let conn;
  try {
    conn = await pool.rw.getConnection();
    const rawStep = await loadStepRow(conn, stepId);
    if (!rawStep) { const e = apiError('Step not found', 'NOT_FOUND', 404); return res.status(e.status).json(e.body); }
    // SAFETY: the MariaDB driver returns JSON columns (auth_config, request_config,
    // …) as raw strings. Map through the dto-mapper here so every
    // downstream consumer — decryptRow, resolveRequest, runEdgeExecute — receives
    // parsed objects, not strings. Without this, resolveRequest reads rc.headers /
    // rc.body off a string (undefined) so custom headers and {{payload}} fills are
    // silently dropped, and decryptAuthConfig's leaf-walk is a no-op on a string.
    const step = mapRowsFromDb('flow_recipe_steps', [rawStep])[0];

    // SECURITY: server-resolved template context (spec 2026-07-11-flow-recipe-
    // template-context). run_id is optional (test-mode /prepare omits it). When
    // present it is a server-minted UUID that binds this dispatch to one run; it
    // is NOT trusted until re-verified here. Mirror run-finalize's binding
    // (flow-recipes-run.js): the run must belong to THIS step's recipe AND to the
    // caller (or an admin). Any mismatch — including a run_id that resolves to no
    // row — is a forbidden cross-run reference → 403 with no bag, so a leaked or
    // guessed id can never pull another run's (or template's) metadata into the
    // outbound request. Only after the binding holds is the context.template.*
    // bag built from the run's server-verified template_id.
    let verifiedRun = null;
    if (runId) {
      const runRows = await conn.query(
        `SELECT id, recipe_id, template_id, blueprint_id, actor_id FROM \`${t(TABLES.FLOW_RECIPE_RUNS)}\` WHERE id = ?`,
        [runId],
      );
      const run = runRows[0];
      if (!run || run.recipe_id !== step.recipe_id || (!isAdmin && run.actor_id !== req.user?.id)) {
        const e = apiError('Run does not belong to you', 'RUN_FORBIDDEN', 403);
        return res.status(e.status).json(e.body);
      }
      // Bind only here (security ordering). The run's blueprint/variant NAMES are
      // resolved later at the single context fan-out, after all early-return gates.
      verifiedRun = run;
    }

    const gate = await loadRecipeGate(conn, step.recipe_id);
    if (!gate.found) { const e = apiError('Recipe not found', 'NOT_FOUND', 404); return res.status(e.status).json(e.body); }

    // SECURITY: test-authority == CRUD edit-authority CONJUNCTION — the editor must own
    // the recipe row (owner_id IS NULL or equals caller) AND own/share its bound blueprint
    // (blueprint owner IS NULL or equals caller). A blueprint-owner who does NOT own the
    // recipe row cannot test it; the CRUD write-gate requires both conditions ANDed.
    // The role floor is defense-in-depth: user-role callers never enter the ownership
    // branches, so a should-never-exist user-role owner is still denied.
    let callerCanManageRecipe = isAdmin;
    if (!callerCanManageRecipe && req.user?.role === 'editor') {
      const ownerOk = gate.owner_id == null || gate.owner_id === req.user?.id;
      if (ownerOk) {
        if (gate.blueprint_id != null) {
          const bpRows = await conn.query(
            `SELECT owner_id FROM \`${t(TABLES.HIERARCHY_NODES)}\` WHERE id = ?`,
            [gate.blueprint_id],
          );
          if (bpRows.length) {
            const bpOwner = bpRows[0].owner_id;
            callerCanManageRecipe = bpOwner == null || bpOwner === req.user?.id;
          }
        } else {
          callerCanManageRecipe = true;
        }
      }
    }
    const effectiveTest = (req.body || {}).test === true && callerCanManageRecipe;

    if (!gate.is_active && !effectiveTest) { const e = apiError('Recipe is inactive', 'RECIPE_INACTIVE', 409); return res.status(e.status).json(e.body); }
    if (!effectiveTest && !dispatchAllowed(gate.status)) {
      const e = apiError('Recipe is awaiting admin approval', 'RECIPE_NOT_APPROVED', 422);
      return res.status(e.status).json(e.body);
    }

    if (step.dispatch_origin !== 'edge' && step.dispatch_origin !== 'infra') {
      const e = apiError('Unsupported dispatch origin', 'NOT_IMPLEMENTED', 501);
      return res.status(e.status).json(e.body);
    }

    // Gate the breaker before touching the decrypted secret: an open circuit
    // must not cause a decrypt attempt on a connector that won't be dispatched.
    if (!effectiveTest && !breaker.canDispatch(step.id)) {
      const e = apiError('Step temporarily unavailable', 'CONNECTOR_CIRCUIT_OPEN', 503);
      return res.status(e.status).json(e.body);
    }

    let decrypted;
    try { decrypted = decryptRow(step); }
    catch (de) {
      if (de instanceof DecryptError) { const e = apiError(de.message, de.code, 422); return res.status(e.status).json(e.body); }
      throw de;
    }

    // Single fan-out of the three SELECT-only context lookups on the one `conn`
    // (the mariadb driver serialises commands per connection, so Promise.all here
    // is safe and collapses three sequential round-trips into one). Deliberately
    // placed AFTER every early-return path (run-binding 403, recipe gate, decrypt)
    // so no promise is ever started before a branch that could abandon it — the
    // sole await point keeps unhandled rejections impossible.
    // Vocabulary rule: template-scoped run data is emitted as human-readable
    // NAMES, not raw ids (the sole id exception is context.template.id):
    //   - context.blueprintName ← verifiedRun.blueprint_id → hierarchy-node name.
    //   - context.variantName   ← the bound template's variant_id, resolved inside
    //     buildTemplateContext (no extra round-trip).
    //   - context.displayName   ← the caller's own users row.
    // An absent/unresolvable value is OMITTED → the token fails closed through the
    // MISSING_INPUT gate rather than filling an empty string.
    const [displayName, runBlueprintName, tc] = await Promise.all([
      req.user?.id ? resolveCallerDisplayName(conn, req.user.id) : null,
      verifiedRun ? resolveHierarchyNodeName(conn, verifiedRun.blueprint_id) : null,
      verifiedRun?.template_id ? buildTemplateContext(conn, verifiedRun.template_id) : null,
    ]);
    const templateBag = tc ? tc.bag : null;
    const runVariantName = tc ? tc.variantName : null;

    // SECURITY: the dispatch fill bag has two provenance classes in DISJOINT key
    // namespaces by construction, so no strip list / alias table is needed:
    //   - client input → renamed to `payload.<k>`, EXCEPT the literal key
    //     `payload` (the whole stage-② message token) which passes through
    //     unchanged. A client key can therefore NEVER produce a `context.*` key.
    //   - server bag (`context.template.*` + context scalars) → the ONLY source
    //     of `context.*` keys, spread LAST.
    // Because client input is structurally unable to fill any `context.*` token,
    // `context.*` is server-authoritative by construction — a spoofed client
    // `context.userId` becomes the harmless `payload.context.userId` and can never
    // shadow the server value (spec: v3.2.417 C1 "client may only relay a signal").
    const dispatchInputs = {};
    for (const key of Object.keys(safeInputs)) {
      const renamed = key === 'payload' ? 'payload' : `payload.${key}`;
      dispatchInputs[renamed] = safeInputs[key];
    }
    // Server context bag, spread last. An absent source ⇒ key absent ⇒
    // MISSING_INPUT on use (fail-closed).
    if (templateBag) Object.assign(dispatchInputs, templateBag);
    if (req.user?.id) {
      dispatchInputs['context.userId'] = req.user.id;
      // context.displayName came from the caller's own users row via the context
      // fan-out above (edge req.user carries id/email/role only). Email-safe
      // (stripEmailDomain) and OMITTED when the row has no display_name/kc_username
      // → fails closed.
      if (displayName != null) dispatchInputs['context.displayName'] = displayName;
    }
    if (runBlueprintName != null) dispatchInputs['context.blueprintName'] = runBlueprintName;
    if (runVariantName != null) dispatchInputs['context.variantName'] = runVariantName;

    let resolved;
    try { resolved = resolveRequest(decrypted, dispatchInputs); }
    catch (re) {
      if (re.code === 'MISSING_INPUT') { const e = apiError(`Missing input(s): ${re.missing.join(', ')}`, 'MISSING_INPUT', 400); return res.status(e.status).json(e.body); }
      throw re;
    }

    const host = hostOf(resolved.url);

    const egress = await egressAllowedForUrl(resolved.url, resolved.method, (sql, params) => conn.query(sql, params), t, { applyDefaultDeny: true });
    if (!egress.ok) {
      await writeFlowAudit(conn, uuidv4(), FLOW_EVENT.failed, req.user?.id, { step_id: step.id, recipe_id: step.recipe_id, run_id: runId, host, method: resolved.method, error_code: 'EGRESS_BLOCKED', reason: egress.reason });
      const e = apiError('Step request is not on the admin egress allow-list', 'EGRESS_BLOCKED', 422);
      return res.status(e.status).json(e.body);
    }

    const pendingId = uuidv4();
    await writeFlowAudit(conn, pendingId, FLOW_EVENT.pending, req.user?.id, { step_id: step.id, recipe_id: step.recipe_id, run_id: runId, host, method: resolved.method });

    if (step.dispatch_origin === 'edge') {
      // Release the rw lease BEFORE the inline outbound call so a slow step
      // cannot exhaust the pool across its timeout window.
      conn.release(); conn = null;
      // Best-effort closing audit: a pool-saturation failure on the short-lived
      // audit lease must NOT turn a successful step execution into a failure.
      const audit = async (kind, meta) => {
        let ac;
        try { ac = await pool.rw.getConnection(); }
        catch (acqErr) { logger.warn({ err: acqErr, stepId }, 'edge closing audit: lease failed (best-effort)'); return; }
        try {
          // runEdgeExecute labels its metadata key connector_id (shared primitive);
          // the flow audit contract uses step_id — rename before writing.
          const m = { ...meta };
          if ('connector_id' in m) { m.step_id = m.connector_id; delete m.connector_id; }
          await writeFlowAudit(ac, uuidv4(), kind === 'success' ? FLOW_EVENT.success : FLOW_EVENT.failed, req.user?.id, { ...m, recipe_id: step.recipe_id, run_id: runId });
        } finally { ac.release(); }
      };
      try {
        const out = await runEdgeExecute({ id: step.id, timeout_ms: step.timeout_ms ? Math.min(step.timeout_ms, MAX_STEP_TIMEOUT_MS) : undefined }, resolved, host, audit, { skipBreaker: effectiveTest });
        return res.json(apiOk({ mode: 'edge', envelope: out, test: effectiveTest }));
      } catch (de) {
        const status = FLOW_ERROR_STATUS[de.code] || 502;
        const e = apiError('Step request failed', de.code || 'CONNECTOR_ERROR', status);
        return res.status(e.status).json(e.body);
      }
    }

    let pin;
    try { pin = await resolveAndPin(new URL(resolved.url).hostname); }
    catch (pe) {
      if (!effectiveTest) breaker.recordFailure(step.id);
      await writeFlowAudit(conn, uuidv4(), FLOW_EVENT.failed, req.user?.id, { step_id: step.id, recipe_id: step.recipe_id, run_id: runId, host, method: resolved.method, error_code: 'SSRF_BLOCKED' });
      const e = apiError('Step request failed', 'SSRF_BLOCKED', 422);
      return res.status(e.status).json(e.body);
    }
    return res.json(apiOk({
      mode: 'infra', test: effectiveTest, dispatch_id: pendingId, step_id: step.id, recipe_id: step.recipe_id, run_id: runId,
      prepared: {
        method: resolved.method, url: resolved.url, headers: resolved.headers, body: resolved.body,
        pinned_ip: pin.address, family: pin.family,
        timeout_ms: Math.min(step.timeout_ms || DEFAULT_TIMEOUT_MS, MAX_STEP_TIMEOUT_MS), max_bytes: DEFAULT_MAX_BYTES,
        // allowed_hosts is never sent (dropped T8); an older infra
        // treats the absent key as allow-all — matches the enforced policy.
      },
    }));
  } catch (err) {
    logger.error({ err, stepId }, 'flow step prepare failed id=' + stepId);
    const e = apiError('Dispatch failed', 'INTERNAL_ERROR', 500);
    res.status(e.status).json(e.body);
  } finally {
    if (conn) conn.release();
  }
});

const _settled = new Set();
const _SETTLED_CAP = 5000;

router.post('/result', async (req, res) => {
  const { dispatch_id: rawDispatchId, step_id: stepId, recipe_id: recipeId, run_id: runId, success, upstream_status: upstreamStatus, duration_ms: durationMs, error_code: errorCode, host, method, test } = req.body || {};
  const isTest = test === true;
  if (!stepId || typeof stepId !== 'string') { const e = apiError('step_id required', 'BAD_REQUEST', 400); return res.status(e.status).json(e.body); }
  const dispatchId = typeof rawDispatchId === 'string' ? rawDispatchId : null;
  if (dispatchId && _settled.has(dispatchId)) return res.json(apiOk({ recorded: false, reason: 'duplicate' }));
  let conn;
  try {
    conn = await pool.rw.getConnection();
    if (success) {
      if (!isTest) breaker.recordSuccess(stepId);
      await writeFlowAudit(conn, uuidv4(), FLOW_EVENT.success, req.user?.id, { step_id: stepId, recipe_id: recipeId || null, run_id: runId || null, host: host || null, method: method || null, upstream_status: upstreamStatus ?? null, duration_ms: durationMs ?? null });
    } else {
      if (!isTest) breaker.recordFailure(stepId);
      await writeFlowAudit(conn, uuidv4(), FLOW_EVENT.failed, req.user?.id, { step_id: stepId, recipe_id: recipeId || null, run_id: runId || null, host: host || null, method: method || null, error_code: errorCode || 'CONNECTOR_ERROR' });
    }
    if (dispatchId) { if (_settled.size >= _SETTLED_CAP) _settled.clear(); _settled.add(dispatchId); }
    return res.json(apiOk({ recorded: true }));
  } catch (err) {
    logger.error({ err, stepId }, 'flow step result failed id=' + stepId);
    const e = apiError('Result record failed', 'INTERNAL_ERROR', 500);
    res.status(e.status).json(e.body);
  } finally { if (conn) conn.release(); }
});

module.exports = router;
