/**
 * migration-steps-topology-rac-rename.test.js — M1 (round 1 review).
 *
 * The `cap_databases_topology_rac_rename` / `cap_bundle_items_topology_rac_rename`
 * custom steps rely on statement ORDER (widen -> UPDATE -> narrow), not a row
 * lock spanning them, so a still-live old-release pod (rolling deploy) can
 * INSERT an old topology value between the UPDATE and the NARROW. `run()`
 * re-checks the row count right before the destructive NARROW, re-runs the
 * UPDATE once, and throws (never narrows over live data) if rows still hold
 * an old value. This file exercises that guard directly against a mocked
 * `conn` — no real DB (matches migration-executor.test.js's own idiom for
 * exercising a custom step's `run()` in isolation).
 *
 * M1 round 2: the guard is now bracketed by `LOCK TABLES <phys>
 * WRITE` / `UNLOCK TABLES` (so concurrent old-pod writers block instead of
 * racing the final COUNT->NARROW window) and the NARROW runs under
 * STRICT_ALL_TABLES (fail-loud backstop). These tests assert the LOCK is
 * acquired before the first COUNT, the NARROW runs under strict sql_mode, and
 * UNLOCK runs on both the success AND the throw path (the conn must never
 * return to the pool holding a lock).
 */
import { describe, it, expect } from 'vitest';

const { MIGRATION_STEPS } = require('../migration-steps');
const { TABLES } = require('../../shared/constants');

const t = (table) => `fmb_${table}`;

function findStep(stepName) {
  const step = MIGRATION_STEPS.find((s) => s.step === stepName);
  if (!step) throw new Error(`migration step not found in registry: ${stepName}`);
  return step;
}

// A mock `conn` for the widen/UPDATE/narrow custom-step shape: answers the
// probe's own information_schema reads with a NOT-YET-RENAMED (old ENUM)
// state so `run()` proceeds past its own short-circuit into the ALTER/UPDATE
// body, records every UPDATE/ALTER, and answers the guard's row-count SELECTs
// from a scripted queue (so a test can simulate "still 1 row after the first
// UPDATE, 0 after the retry" or "still 1 row even after the retry").
function makeConn({ oldEnumType, countQueue }) {
  const queries = [];
  const remainingCounts = [...countQueue];
  return {
    queries,
    async query(sql, params = []) {
      queries.push({ sql, params });
      if (/information_schema\.TABLES/i.test(sql)) return [{ 1: 1 }]; // table exists
      if (/information_schema\.COLUMNS/i.test(sql)) return [{ COLUMN_TYPE: oldEnumType }];
      if (/@@SESSION\.sql_mode AS sqlMode/i.test(sql)) {
        // the pre-lock capture of the session sql_mode (restored in finally)
        return [{ sqlMode: 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' }];
      }
      if (/^SELECT COUNT\(\*\) AS n FROM/.test(sql)) {
        if (!remainingCounts.length) throw new Error('test setup: countQueue exhausted');
        return [{ n: remainingCounts.shift() }];
      }
      return {}; // ALTER / UPDATE / LOCK TABLES / UNLOCK TABLES / SET SESSION
    },
  };
}

describe('M1: cap_databases_topology_rac_rename — pre-narrow row-count guard', () => {
  const step = findStep('cap_databases_topology_rac_rename');

  it('no race (0 rows still old after the first UPDATE pass) -> narrows normally, one COUNT check', async () => {
    const conn = makeConn({
      oldEnumType: "enum('single','primary','primary_standby','rac','rac_standby')",
      countQueue: [0],
    });
    await step.run({ conn, t });
    const narrowAlter = conn.queries.filter((q) => /ALTER TABLE/.test(q.sql) && /rac_multinode_standby'\) NOT NULL/.test(q.sql) && !/'rac',/.test(q.sql));
    expect(narrowAlter.length).toBe(1);
    const updateCount = conn.queries.filter((q) => /^UPDATE/.test(q.sql)).length;
    expect(updateCount).toBe(2); // exactly the two planned UPDATEs, no retry
  });

  it('a single race window (rows still old after the first UPDATE, 0 after the retry) -> recovers and narrows', async () => {
    const conn = makeConn({
      oldEnumType: "enum('single','primary','primary_standby','rac','rac_standby')",
      countQueue: [1, 0],
    });
    await step.run({ conn, t });
    const narrowAlter = conn.queries.filter((q) => /ALTER TABLE/.test(q.sql) && /rac_multinode_standby'\) NOT NULL/.test(q.sql) && !/'rac',/.test(q.sql));
    expect(narrowAlter.length, 'the retry recovered — the narrow still runs').toBe(1);
    const updateCount = conn.queries.filter((q) => /^UPDATE/.test(q.sql)).length;
    expect(updateCount).toBe(4); // the two planned UPDATEs + one retry pass of two
  });

  it('rows still old after the retry too -> throws, never narrows', async () => {
    const conn = makeConn({
      oldEnumType: "enum('single','primary','primary_standby','rac','rac_standby')",
      countQueue: [1, 1],
    });
    await expect(step.run({ conn, t })).rejects.toThrow(/refusing to narrow/);
    const narrowAlter = conn.queries.filter((q) => /ALTER TABLE/.test(q.sql) && /rac_multinode_standby'\) NOT NULL/.test(q.sql) && !/'rac',/.test(q.sql));
    expect(narrowAlter.length, 'the narrow must never run over live old-value rows').toBe(0);
  });
});

describe('M1: cap_bundle_items_topology_rac_rename — pre-narrow row-count guard', () => {
  const step = findStep('cap_bundle_items_topology_rac_rename');

  it('no race -> narrows normally, one COUNT check', async () => {
    const conn = makeConn({
      oldEnumType: "enum('single','primary','primary_standby','rac')",
      countQueue: [0],
    });
    await step.run({ conn, t });
    const narrowAlter = conn.queries.filter((q) => /ALTER TABLE/.test(q.sql) && /'rac_multinode'\) NULL DEFAULT NULL/.test(q.sql) && !/'rac',/.test(q.sql));
    expect(narrowAlter.length).toBe(1);
    const updateCount = conn.queries.filter((q) => /^UPDATE/.test(q.sql)).length;
    expect(updateCount).toBe(1);
  });

  it('a single race window -> recovers and narrows', async () => {
    const conn = makeConn({
      oldEnumType: "enum('single','primary','primary_standby','rac')",
      countQueue: [1, 0],
    });
    await step.run({ conn, t });
    const narrowAlter = conn.queries.filter((q) => /ALTER TABLE/.test(q.sql) && /'rac_multinode'\) NULL DEFAULT NULL/.test(q.sql) && !/'rac',/.test(q.sql));
    expect(narrowAlter.length).toBe(1);
    const updateCount = conn.queries.filter((q) => /^UPDATE/.test(q.sql)).length;
    expect(updateCount).toBe(2);
  });

  it('rows still old after the retry -> throws, never narrows', async () => {
    const conn = makeConn({
      oldEnumType: "enum('single','primary','primary_standby','rac')",
      countQueue: [1, 1],
    });
    await expect(step.run({ conn, t })).rejects.toThrow(/refusing to narrow/);
    const narrowAlter = conn.queries.filter((q) => /ALTER TABLE/.test(q.sql) && /'rac_multinode'\) NULL DEFAULT NULL/.test(q.sql) && !/'rac',/.test(q.sql));
    expect(narrowAlter.length).toBe(0);
  });
});

// TOPO-R2 fix batch (Codex r1 P1): the standby widen's target ENUM omits the
// pre-rename 'rac' member. If the rename step warn-skipped (missing LOCK TABLES
// privilege) or a rolling old pod re-inserted a 'rac' row, a lingering 'rac'
// value would be coerced to '' by this ALTER under a non-STRICT session. run()
// now guards on a `topology = 'rac'` COUNT and throws (accounted a skip; the
// version stamp is held) instead of altering over live data.
describe('P1: cap_bundle_items_topology_standby_widen — lingering-rac guard', () => {
  const step = findStep('cap_bundle_items_topology_standby_widen');
  // The widen ALTER: 5-member set that DROPS 'rac' and ADDS rac_multinode_standby.
  const widenAlter = /ALTER TABLE.*'primary_standby','rac_multinode','rac_multinode_standby'\) NULL DEFAULT NULL/;

  it('a lingering rac row + narrow enum -> throws, never runs the widen ALTER', async () => {
    // Post-(skipped-)rename COLUMN_TYPE still lacks rac_multinode_standby so the
    // probe short-circuit does NOT fire and run() reaches the guard; the guard's
    // COUNT reports one surviving 'rac' row.
    const conn = makeConn({
      oldEnumType: "enum('single','primary','primary_standby','rac','rac_multinode')",
      countQueue: [1],
    });
    await expect(step.run({ conn, t })).rejects.toThrow(/refusing to widen/);
    const alters = conn.queries.filter((q) => widenAlter.test(q.sql));
    expect(alters.length, 'the widen must never alter over a live rac row').toBe(0);
  });

  it('after the rename applies (0 rac rows) -> the widen ALTER proceeds', async () => {
    const conn = makeConn({
      oldEnumType: "enum('single','primary','primary_standby','rac_multinode')",
      countQueue: [0],
    });
    await step.run({ conn, t });
    const alters = conn.queries.filter((q) => widenAlter.test(q.sql));
    expect(alters.length, 'no rac rows survive -> widen runs').toBe(1);
  });

  it('a schema already carrying rac_multinode_standby -> probe short-circuits, no COUNT, no ALTER', async () => {
    // countQueue empty: if run() reached the guard COUNT the mock would throw
    // ("countQueue exhausted"), proving the probe short-circuit fired first.
    const conn = makeConn({
      oldEnumType: "enum('single','primary','primary_standby','rac_multinode','rac_multinode_standby')",
      countQueue: [],
    });
    await step.run({ conn, t });
    const counts = conn.queries.filter((q) => /^SELECT COUNT\(\*\) AS n FROM/.test(q.sql));
    expect(counts.length, 'satisfied probe skips the guard COUNT entirely').toBe(0);
    const alters = conn.queries.filter((q) => widenAlter.test(q.sql));
    expect(alters.length, 'already widened -> no re-ALTER').toBe(0);
  });
});

// Index of the first query whose SQL matches `re`, or -1. Used to assert the
// ORDER of LOCK / COUNT / SET-strict / NARROW / UNLOCK against a real run.
function firstIdx(conn, re) {
  return conn.queries.findIndex((q) => re.test(q.sql));
}

describe('M1 round 2: LOCK TABLES bracketing + strict-mode narrow', () => {
  const dbStep = findStep('cap_databases_topology_rac_rename');
  const biStep = findStep('cap_bundle_items_topology_rac_rename');
  const dbOldEnum = "enum('single','primary','primary_standby','rac','rac_standby')";
  const biOldEnum = "enum('single','primary','primary_standby','rac')";
  // Match ONLY the narrow ALTER, not the widen: the widen keeps `'rac',` /
  // `'rac_standby',` before the new members, the narrow drops them.
  const dbNarrow = /ALTER TABLE.*primary_standby','rac_multinode','rac_multinode_standby'\) NOT NULL/;
  const biNarrow = /ALTER TABLE.*primary_standby','rac_multinode'\) NULL DEFAULT NULL/;

  it('cap_databases: LOCK before first COUNT, strict sql_mode set before NARROW, UNLOCK after NARROW', async () => {
    const conn = makeConn({ oldEnumType: dbOldEnum, countQueue: [0] });
    await dbStep.run({ conn, t });
    const lockIdx = firstIdx(conn, /^LOCK TABLES `[^`]+` WRITE$/);
    const countIdx = firstIdx(conn, /^SELECT COUNT\(\*\) AS n FROM/);
    const strictIdx = firstIdx(conn, /SET SESSION sql_mode = CONCAT_WS.*STRICT_ALL_TABLES/);
    const narrowIdx = firstIdx(conn, dbNarrow);
    const unlockIdx = firstIdx(conn, /^UNLOCK TABLES$/);
    expect(lockIdx, 'LOCK TABLES issued').toBeGreaterThanOrEqual(0);
    expect(lockIdx, 'LOCK before the first pre-narrow COUNT').toBeLessThan(countIdx);
    expect(strictIdx, 'strict sql_mode set before the NARROW').toBeLessThan(narrowIdx);
    expect(narrowIdx, 'NARROW runs while still under the WRITE lock').toBeLessThan(unlockIdx);
    // the information_schema probe (rename check) stays OUTSIDE the lock
    const colsIdx = firstIdx(conn, /information_schema\.COLUMNS/i);
    expect(colsIdx, 'the renamed-probe COLUMNS read precedes LOCK TABLES').toBeLessThan(lockIdx);
  });

  it('cap_databases: UNLOCK still runs on the throw path (never strands a lock)', async () => {
    const conn = makeConn({ oldEnumType: dbOldEnum, countQueue: [1, 1] });
    await expect(dbStep.run({ conn, t })).rejects.toThrow(/refusing to narrow/);
    const lockIdx = firstIdx(conn, /^LOCK TABLES `[^`]+` WRITE$/);
    const unlockIdx = firstIdx(conn, /^UNLOCK TABLES$/);
    expect(lockIdx, 'LOCK acquired').toBeGreaterThanOrEqual(0);
    expect(unlockIdx, 'UNLOCK runs even though the guard threw').toBeGreaterThan(lockIdx);
    // sql_mode is restored on the throw path too (SET SESSION ... = ? with the captured mode)
    const restore = conn.queries.filter((q) => /^SET SESSION sql_mode = \?$/.test(q.sql));
    expect(restore.length, 'sql_mode restored in finally').toBe(1);
    // and the NARROW never ran
    expect(firstIdx(conn, dbNarrow)).toBe(-1);
  });

  it('cap_bundle_items: LOCK before first COUNT, strict before NARROW, UNLOCK after NARROW', async () => {
    const conn = makeConn({ oldEnumType: biOldEnum, countQueue: [0] });
    await biStep.run({ conn, t });
    const lockIdx = firstIdx(conn, /^LOCK TABLES `[^`]+` WRITE$/);
    const countIdx = firstIdx(conn, /^SELECT COUNT\(\*\) AS n FROM/);
    const strictIdx = firstIdx(conn, /SET SESSION sql_mode = CONCAT_WS.*STRICT_ALL_TABLES/);
    const narrowIdx = firstIdx(conn, biNarrow);
    const unlockIdx = firstIdx(conn, /^UNLOCK TABLES$/);
    expect(lockIdx).toBeGreaterThanOrEqual(0);
    expect(lockIdx).toBeLessThan(countIdx);
    expect(strictIdx).toBeLessThan(narrowIdx);
    expect(narrowIdx).toBeLessThan(unlockIdx);
  });

  it('cap_bundle_items: UNLOCK still runs on the throw path', async () => {
    const conn = makeConn({ oldEnumType: biOldEnum, countQueue: [1, 1] });
    await expect(biStep.run({ conn, t })).rejects.toThrow(/refusing to narrow/);
    const lockIdx = firstIdx(conn, /^LOCK TABLES `[^`]+` WRITE$/);
    const unlockIdx = firstIdx(conn, /^UNLOCK TABLES$/);
    expect(unlockIdx, 'UNLOCK runs even though the guard threw').toBeGreaterThan(lockIdx);
    expect(firstIdx(conn, biNarrow)).toBe(-1);
    // sql_mode is restored on the throw path too (SET SESSION ... = ? with the captured mode)
    const restore = conn.queries.filter((q) => /^SET SESSION sql_mode = \?$/.test(q.sql));
    expect(restore.length, 'sql_mode restored in finally').toBe(1);
  });
});
