/**
 * pending-steps.test.js — PR2 (Codex R2).
 *
 * Unit tests for the read-only pending-step derivation shared by schema-status
 * (step names) and schema-export-sql (remediation SQL). Stub-based regex-script
 * mock connection (mirrors migration-executor.test.js) — no real DB.
 */
import { describe, it, expect } from 'vitest';

const { isStepPending, derivePendingStepNames, derivePendingStepsSql } = require('../lib/pending-steps');

const PREFIX = 'mig_';
const t = (name) => `${PREFIX}${name}`;

/** scripts: Array<[RegExp, response | (sql, params) => any]>; unmatched throws. */
function makeConn(scripts) {
  const queries = [];
  return {
    queries,
    query: async function (sql, params) {
      queries.push({ sql, params });
      for (const [matcher, response] of scripts) {
        if (matcher.test(sql)) {
          return typeof response === 'function' ? response(sql, params) : response;
        }
      }
      throw new Error(`Unmatched query in test mock: ${sql.replace(/\s+/g, ' ').slice(0, 90)}`);
    },
  };
}

const COL_PRESENT = [{ 1: 1 }];
const COL_ABSENT = [];

describe('isStepPending', () => {
  it('drop-column is pending when the column still exists', async () => {
    const conn = makeConn([[/information_schema\.COLUMNS/i, COL_PRESENT]]);
    const step = { kind: 'drop-column', table: 'user_templates', column: 'user_id', step: 'x' };
    expect(await isStepPending(conn, t, step)).toBe(true);
  });

  it('drop-column is NOT pending when the column is already gone', async () => {
    const conn = makeConn([[/information_schema\.COLUMNS/i, COL_ABSENT]]);
    const step = { kind: 'drop-column', table: 'user_templates', column: 'user_id', step: 'x' };
    expect(await isStepPending(conn, t, step)).toBe(false);
  });

  it('custom is pending when its probe reports unsatisfied (false)', async () => {
    const conn = makeConn([]);
    const step = { kind: 'custom', step: 'x', probe: async () => false };
    expect(await isStepPending(conn, t, step)).toBe(true);
  });

  it('custom is NOT pending when its probe reports satisfied (true)', async () => {
    const conn = makeConn([]);
    const step = { kind: 'custom', step: 'x', probe: async () => true };
    expect(await isStepPending(conn, t, step)).toBe(false);
  });

  it('custom without a probe is never pending (underivable read-only)', async () => {
    const conn = makeConn([]);
    const step = { kind: 'custom', step: 'x' };
    expect(await isStepPending(conn, t, step)).toBe(false);
  });

  it('add-column / create-table are never pending (surfaced by missing-structure)', async () => {
    const conn = makeConn([]);
    expect(await isStepPending(conn, t, { kind: 'add-column', step: 'a' })).toBe(false);
    expect(await isStepPending(conn, t, { kind: 'create-table', step: 'c' })).toBe(false);
  });
});

describe('derivePendingStepNames', () => {
  it('lists only unsatisfied steps by name', async () => {
    const conn = makeConn([
      [/information_schema\.COLUMNS/i, COL_PRESENT],
    ]);
    const steps = [
      { kind: 'drop-column', table: 'user_templates', column: 'user_id', step: 'drop_pending' },
      { kind: 'custom', step: 'custom_satisfied', probe: async () => true },
      { kind: 'custom', step: 'custom_pending', probe: async () => false },
    ];
    expect(await derivePendingStepNames(conn, t, steps)).toEqual(['drop_pending', 'custom_pending']);
  });
});

describe('derivePendingStepsSql', () => {
  it('emits DROP INDEX (when present) then DROP COLUMN for a pending drop-column', async () => {
    const conn = makeConn([
      [/information_schema\.COLUMNS/i, COL_PRESENT],
      [/information_schema\.STATISTICS/i, [{ 1: 1 }]],
    ]);
    const steps = [
      {
        kind: 'drop-column',
        table: 'user_templates',
        column: 'user_id',
        step: 'x',
        alsoDropIndexes: ['idx_user_templates_user_draft'],
      },
    ];
    const sql = await derivePendingStepsSql(conn, t, steps);
    expect(sql).toEqual([
      'ALTER TABLE `mig_user_templates` DROP INDEX `idx_user_templates_user_draft`;',
      'ALTER TABLE `mig_user_templates` DROP COLUMN `user_id`;',
    ]);
  });

  it('omits the DROP INDEX when the companion index no longer exists', async () => {
    const conn = makeConn([
      [/information_schema\.COLUMNS/i, COL_PRESENT],
      [/information_schema\.STATISTICS/i, []],
    ]);
    const steps = [
      { kind: 'drop-column', table: 'user_templates', column: 'user_id', step: 'x', alsoDropIndexes: ['gone'] },
    ];
    const sql = await derivePendingStepsSql(conn, t, steps);
    expect(sql).toEqual(['ALTER TABLE `mig_user_templates` DROP COLUMN `user_id`;']);
  });

  it('emits a custom step\'s remediationSql(tableFn) when pending, skips it when satisfied', async () => {
    const conn = makeConn([]);
    const pending = {
      kind: 'custom',
      step: 'p',
      probe: async () => false,
      remediationSql: (tableFn) => [`UPDATE \`${tableFn('foo')}\` SET x = 1;`],
    };
    const satisfied = {
      kind: 'custom',
      step: 's',
      probe: async () => true,
      remediationSql: () => ['SHOULD NOT APPEAR;'],
    };
    const sql = await derivePendingStepsSql(conn, t, [pending, satisfied]);
    expect(sql).toEqual(['UPDATE `mig_foo` SET x = 1;']);
  });
});
