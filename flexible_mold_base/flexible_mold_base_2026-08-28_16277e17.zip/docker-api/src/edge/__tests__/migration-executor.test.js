/**
 * migration-executor.test.js — Task 3.
 *
 * Unit tests for the declarative migration executor, baseline guard, and the
 * GET_LOCK boot wrapper in migrations.js. Stub-based: a tiny regex-script mock
 * connection stands in for MariaDB so the probe → conditional DDL → catch →
 * audit → skip flow runs without a real database.
 *
 * Covers:
 *   - each entry kind's probe / skip / apply branch (add-column, create-table,
 *     drop-column, custom)
 *   - skippedSteps accounting + privilege (errno 1142) → alter_skipped audit
 *   - baseline-guard truth table (Codex R2: stamp<baseline any-context → unsupported;
 *     no-stamp proves schema-complete before stamping — full engine-table probe)
 *   - lock-timeout branch (GET_LOCK → 0): at-target continues, behind skips,
 *     migration body never runs; acquired path releases the lock
 */
import { describe, it, expect, vi } from 'vitest';

const { createMigrationsModule } = require('../migrations');
const { TABLES } = require('../../shared/constants');
const { buildSchemaManifest } = require('../lib/schema-manifest');

const PREFIX = 'mig_';
const t = (name) => `${PREFIX}${name}`;

function makeModule(overrides = {}) {
  return createMigrationsModule({
    t,
    PLATFORM_SCHEMA_VERSION: '3.2.520',
    _configFull: { database: 'testdb', user: 'app' },
    _tablePrefix: PREFIX,
    APP_TABLE_NAMES: [],
    ...overrides,
  });
}

/**
 * makeConn(scripts)
 *   scripts: Array<[RegExp, response | Error | (sql, params) => any]>
 * The first matching entry wins; unmatched queries throw so a test that forgets
 * a branch fails loudly instead of silently returning [].
 */
function makeConn(scripts) {
  const queries = [];
  return {
    queries,
    query: async function (sql, params) {
      queries.push({ sql, params });
      for (const [matcher, response] of scripts) {
        if (matcher.test(sql)) {
          if (response instanceof Error) throw response;
          return typeof response === 'function' ? response(sql, params) : response;
        }
      }
      throw new Error(`Unmatched query in test mock: ${sql.replace(/\s+/g, ' ').slice(0, 90)}`);
    },
  };
}

const TABLE_EXISTS = [{ 1: 1 }];
const AUDIT_INSERT = [/INSERT INTO .*feature_audit/i, []];
const auditEvents = (conn) =>
  conn.queries.filter((q) => /INSERT INTO .*feature_audit/i.test(q.sql)).map((q) => q.params[1]);

describe('_runMigrationSteps — add-column', () => {
  it('applies the ALTER when table exists and column is absent', async () => {
    const m = makeModule();
    const conn = makeConn([
      [/information_schema\.TABLES/i, TABLE_EXISTS],
      [/information_schema\.COLUMNS/i, []],
      [/ALTER TABLE .*ADD COLUMN/i, []],
    ]);
    const step = { kind: 'add-column', table: TABLES.USER_TEMPLATES, column: 'foo', ddl: '`foo` VARCHAR(255) NULL DEFAULT NULL', step: 'ut_foo_add', severity: 'warning' };
    const res = await m._runMigrationSteps(conn, [step]);
    expect(res.skippedSteps).toBe(0);
    expect(conn.queries.some((q) => /ALTER TABLE .*ADD COLUMN/i.test(q.sql))).toBe(true);
  });

  it('skips the ALTER when the column already exists (idempotent)', async () => {
    const m = makeModule();
    const conn = makeConn([
      [/information_schema\.TABLES/i, TABLE_EXISTS],
      [/information_schema\.COLUMNS/i, [{ 1: 1 }]],
    ]);
    const step = { kind: 'add-column', table: TABLES.USER_TEMPLATES, column: 'foo', ddl: '`foo` INT NULL', step: 'ut_foo_add' };
    const res = await m._runMigrationSteps(conn, [step]);
    expect(res.skippedSteps).toBe(0);
    expect(conn.queries.some((q) => /ALTER TABLE/i.test(q.sql))).toBe(false);
  });

  it('skips silently when the target table is absent', async () => {
    const m = makeModule();
    const conn = makeConn([[/information_schema\.TABLES/i, []]]);
    const step = { kind: 'add-column', table: TABLES.USER_TEMPLATES, column: 'foo', ddl: '`foo` INT NULL', step: 'ut_foo_add' };
    const res = await m._runMigrationSteps(conn, [step]);
    expect(res.skippedSteps).toBe(0);
    expect(conn.queries.some((q) => /ALTER TABLE/i.test(q.sql))).toBe(false);
  });

  it('accounts a privilege failure (errno 1142) as an alter_skipped audit', async () => {
    const m = makeModule();
    const denied = Object.assign(new Error('access denied'), { errno: 1142 });
    const conn = makeConn([
      [/information_schema\.TABLES/i, TABLE_EXISTS],
      [/information_schema\.COLUMNS/i, []],
      [/ALTER TABLE .*ADD COLUMN/i, denied],
      AUDIT_INSERT,
    ]);
    const step = { kind: 'add-column', table: TABLES.USER_TEMPLATES, column: 'foo', ddl: '`foo` INT NULL', step: 'ut_foo_add' };
    const res = await m._runMigrationSteps(conn, [step]);
    expect(res.skippedSteps).toBe(1);
    expect(auditEvents(conn)).toEqual(['schema_migration.alter_skipped']);
  });

  it('accounts a non-privilege failure as a plain skipped audit', async () => {
    const m = makeModule();
    const boom = Object.assign(new Error('lock timeout'), { errno: 1205 });
    const conn = makeConn([
      [/information_schema\.TABLES/i, TABLE_EXISTS],
      [/information_schema\.COLUMNS/i, []],
      [/ALTER TABLE .*ADD COLUMN/i, boom],
      AUDIT_INSERT,
    ]);
    const step = { kind: 'add-column', table: TABLES.USER_TEMPLATES, column: 'foo', ddl: '`foo` INT NULL', step: 'ut_foo_add' };
    const res = await m._runMigrationSteps(conn, [step]);
    expect(res.skippedSteps).toBe(1);
    expect(auditEvents(conn)).toEqual(['schema_migration.skipped']);
  });
});

describe('_runMigrationSteps — create-table', () => {
  it('creates the table from the DDL builders when absent', async () => {
    const m = makeModule();
    const physical = t(TABLES.API_CONNECTORS);
    const conn = makeConn([
      [/information_schema\.TABLES/i, []],
      [new RegExp(`CREATE TABLE[\\s\\S]*\`${physical}\``, 'i'), []],
    ]);
    const step = { kind: 'create-table', table: TABLES.API_CONNECTORS, step: 'api_connectors_table_create', severity: 'warning' };
    const res = await m._runMigrationSteps(conn, [step]);
    expect(res.skippedSteps).toBe(0);
    expect(conn.queries.some((q) => new RegExp(`CREATE TABLE[\\s\\S]*\`${physical}\``, 'i').test(q.sql))).toBe(true);
  });

  it('skips creation when the table already exists', async () => {
    const m = makeModule();
    const conn = makeConn([[/information_schema\.TABLES/i, TABLE_EXISTS]]);
    const step = { kind: 'create-table', table: TABLES.API_CONNECTORS, step: 'api_connectors_table_create' };
    const res = await m._runMigrationSteps(conn, [step]);
    expect(res.skippedSteps).toBe(0);
    expect(conn.queries.some((q) => /CREATE TABLE/i.test(q.sql))).toBe(false);
  });
});

describe('_runMigrationSteps — drop-column', () => {
  it('drops companion indexes then the column when present', async () => {
    const m = makeModule();
    const conn = makeConn([
      [/information_schema\.TABLES/i, TABLE_EXISTS],
      [/information_schema\.COLUMNS/i, [{ 1: 1 }]],
      [/DROP INDEX/i, []],
      [/DROP COLUMN/i, []],
    ]);
    const step = { kind: 'drop-column', table: TABLES.USER_TEMPLATES, column: 'user_id', step: 'ut_user_id_drop', alsoDropIndexes: ['idx_user_templates_user_draft'] };
    const res = await m._runMigrationSteps(conn, [step]);
    expect(res.skippedSteps).toBe(0);
    const order = conn.queries.map((q) => q.sql).filter((s) => /DROP (INDEX|COLUMN)/i.test(s));
    expect(/DROP INDEX/i.test(order[0])).toBe(true);
    expect(/DROP COLUMN/i.test(order[1])).toBe(true);
  });

  it('is a no-op when the column is already absent (idempotent re-run)', async () => {
    const m = makeModule();
    const conn = makeConn([
      [/information_schema\.TABLES/i, TABLE_EXISTS],
      [/information_schema\.COLUMNS/i, []],
    ]);
    const step = { kind: 'drop-column', table: TABLES.USER_TEMPLATES, column: 'user_id', step: 'ut_user_id_drop' };
    const res = await m._runMigrationSteps(conn, [step]);
    expect(res.skippedSteps).toBe(0);
    expect(conn.queries.some((q) => /DROP COLUMN/i.test(q.sql))).toBe(false);
  });

  it('tolerates an already-absent companion index (errno 1091) and still drops the column', async () => {
    const m = makeModule();
    const noKey = Object.assign(new Error('cant drop key'), { errno: 1091 });
    const conn = makeConn([
      [/information_schema\.TABLES/i, TABLE_EXISTS],
      [/information_schema\.COLUMNS/i, [{ 1: 1 }]],
      [/DROP INDEX/i, noKey],
      [/DROP COLUMN/i, []],
    ]);
    const step = { kind: 'drop-column', table: TABLES.USER_TEMPLATES, column: 'user_id', step: 'ut_user_id_drop', alsoDropIndexes: ['idx_gone'] };
    const res = await m._runMigrationSteps(conn, [step]);
    expect(res.skippedSteps).toBe(0);
    expect(conn.queries.some((q) => /DROP COLUMN/i.test(q.sql))).toBe(true);
  });
});

describe('_runMigrationSteps — custom', () => {
  it('invokes run() with the executor context', async () => {
    const m = makeModule();
    const conn = makeConn([]);
    const run = vi.fn(async (ctx) => {
      expect(ctx.conn).toBe(conn);
      expect(typeof ctx.t).toBe('function');
      expect(ctx.TABLES).toBe(TABLES);
    });
    const res = await m._runMigrationSteps(conn, [{ kind: 'custom', step: 'x', run }]);
    expect(res.skippedSteps).toBe(0);
    expect(run).toHaveBeenCalledOnce();
  });

  it('accounts a throwing custom step as skipped', async () => {
    const m = makeModule();
    const conn = makeConn([AUDIT_INSERT]);
    const step = { kind: 'custom', step: 'x', run: async () => { throw new Error('boom'); } };
    const res = await m._runMigrationSteps(conn, [step]);
    expect(res.skippedSteps).toBe(1);
    expect(auditEvents(conn)).toEqual(['schema_migration.skipped']);
  });
});

describe('_runMigrationSteps — accounting + unknown kind', () => {
  it('sums skips across a mixed batch and applies the good steps', async () => {
    const m = makeModule();
    const denied = Object.assign(new Error('access denied'), { errno: 1142 });
    const conn = makeConn([
      [/information_schema\.TABLES/i, TABLE_EXISTS],
      [/information_schema\.COLUMNS/i, []],
      [/ALTER TABLE .*`ok`/i, []],
      [/ALTER TABLE .*`bad`/i, denied],
      AUDIT_INSERT,
    ]);
    const steps = [
      { kind: 'add-column', table: TABLES.USER_TEMPLATES, column: 'ok', ddl: '`ok` INT NULL', step: 's_ok' },
      { kind: 'add-column', table: TABLES.USER_TEMPLATES, column: 'bad', ddl: '`bad` INT NULL', step: 's_bad' },
    ];
    const res = await m._runMigrationSteps(conn, steps);
    expect(res.skippedSteps).toBe(1);
  });

  it('treats an unrecognised kind as a skip rather than crashing', async () => {
    const m = makeModule();
    const conn = makeConn([AUDIT_INSERT]);
    const res = await m._runMigrationSteps(conn, [{ kind: 'nope', step: 'weird' }]);
    expect(res.skippedSteps).toBe(1);
  });

  it('returns zero skips for the production registry when its target tables are absent', async () => {
    // T8: the registry now carries the PR2 drop-column batch. Each
    // entry's table-existence guard is the first probe — on a target lacking
    // the table (e.g. a fresh/degraded DB) the step no-ops with no skip, same
    // as the PR1-empty-registry invariant this test used to pin.
    //
    // create-table is the one kind for which "table absent" is the WORK, not
    // the no-op: it issues the CREATE after the probe (one extra query) and
    // must likewise not count as a skip. The counts below are derived from the
    // registry so a future entry of either kind stays covered.
    const m = makeModule();
    const conn = makeConn([
      [/information_schema\.TABLES/, []],
      [/^CREATE TABLE IF NOT EXISTS/i, []],
    ]);
    const { MIGRATION_STEPS } = require('../migration-steps');
    const createSteps = MIGRATION_STEPS.filter((s) => s.kind === 'create-table');
    const res = await m._runMigrationSteps(conn, MIGRATION_STEPS);
    expect(res.skippedSteps).toBe(0);
    expect(conn.queries.length).toBe(MIGRATION_STEPS.length + createSteps.length);
    for (const step of createSteps) {
      const created = conn.queries.some((q) =>
        q.sql.includes(`CREATE TABLE IF NOT EXISTS \`${PREFIX}${step.table}\``));
      expect(created, `${step.step} did not create ${step.table}`).toBe(true);
    }
  });
});

describe('_isUnsupportedBaseline — truth table (Codex R2 semantics)', () => {
  // The no-stamp branch dumps information_schema.COLUMNS and runs the full
  // manifest comparison. Build the live-columns rows from the real manifest so a
  // "complete" case has zero missing and a "partial" case (one engine table,
  // truncated columns) has real missing structure.
  const manifest = buildSchemaManifest((b) => b);
  function columnRows(tables /* Set<baseName> | null=all */, columnCap) {
    const rows = [];
    for (const [base, { columns }] of manifest) {
      if (tables && !tables.has(base)) continue;
      const cols = columnCap ? columns.slice(0, columnCap) : columns;
      for (const c of cols) rows.push({ TABLE_NAME: t(base), COLUMN_NAME: c });
    }
    return rows;
  }
  const columnsConn = (rows) => makeConn([[/information_schema\.COLUMNS/i, rows]]);

  it('stamp < baseline → unsupported (every context — no boot gate)', async () => {
    const m = makeModule();
    // hadStamp path returns before any query — context-independent.
    expect(await m._isUnsupportedBaseline(makeConn([]), '3.2.400', true)).toBe(true);
  });

  it('stamp >= baseline → supported', async () => {
    const m = makeModule();
    expect(await m._isUnsupportedBaseline(makeConn([]), '3.2.520', true)).toBe(false);
  });

  it('no stamp + zero engine tables → fresh install (supported)', async () => {
    const m = makeModule();
    // Only infra tables present (no engine tables) → fresh.
    expect(await m._isUnsupportedBaseline(columnsConn([]), '3.0.0', false)).toBe(false);
  });

  it('no stamp + partial engine subset (only api_connectors, truncated) → unsupported', async () => {
    const m = makeModule();
    const rows = columnRows(new Set(['api_connectors']), 2); // present but incomplete
    expect(await m._isUnsupportedBaseline(columnsConn(rows), '3.0.0', false)).toBe(true);
  });

  it('no stamp + complete schema (Setup Wizard just-created-everything) → supported', async () => {
    const m = makeModule();
    expect(await m._isUnsupportedBaseline(columnsConn(columnRows(null)), '3.0.0', false)).toBe(false);
  });
});

describe('runSchemaMigrations — GET_LOCK wrapper (spec §4.7)', () => {
  const STAMP_AT_TARGET = [/system_settings/i, [{ value: '"3.2.520"' }]];
  const STAMP_BEHIND = [/system_settings/i, [{ value: '"3.2.100"' }]];

  it('on lock timeout with schema already at target → continues boot, body never runs', async () => {
    const m = makeModule();
    const conn = makeConn([
      [/SELECT DATABASE\(\)/i, [{ db: 'testdb' }]],
      [/GET_LOCK/i, [{ locked: 0 }]],
      STAMP_AT_TARGET,
    ]);
    await m.runSchemaMigrations(conn, { context: 'boot' });
    expect(conn.queries.some((q) => /RELEASE_LOCK/i.test(q.sql))).toBe(false);
    expect(conn.queries.some((q) => /ALTER TABLE|preflight|feature_audit/i.test(q.sql))).toBe(false);
  });

  it('on lock timeout still behind target → skips this boot, body never runs', async () => {
    const m = makeModule();
    const conn = makeConn([
      [/SELECT DATABASE\(\)/i, [{ db: 'testdb' }]],
      [/GET_LOCK/i, [{ locked: 0 }]],
      STAMP_BEHIND,
    ]);
    await m.runSchemaMigrations(conn, { context: 'boot' });
    expect(conn.queries.some((q) => /ALTER TABLE|feature_audit/i.test(q.sql))).toBe(false);
  });

  it('runs the DDL-grants preflight (SHOW GRANTS) when the caller does not signal it already ran', async () => {
    // the migration path preflights itself when entered WITHOUT
    // ensureInfrastructure (the Setup Wizard init-db path). Full privileges +
    // stamp at target → preflight passes, body short-circuits before any step.
    const m = makeModule({ _configFull: { database: 'testdb', user: 'app' }, _tablePrefix: PREFIX, APP_TABLE_NAMES: ['users'] });
    const conn = makeConn([
      [/SELECT DATABASE\(\)/i, [{ db: 'testdb' }]],
      [/GET_LOCK/i, [{ locked: 1 }]],
      [/SHOW GRANTS/i, [{ 'Grants for app@%': "GRANT ALL PRIVILEGES ON `testdb`.* TO 'app'@'%'" }]],
      [/information_schema\.TABLES/i, [{ TABLE_NAME: 'mig_users' }]],
      STAMP_AT_TARGET,
      [/RELEASE_LOCK/i, []],
    ]);
    await m.runSchemaMigrations(conn, { context: 'boot' });
    expect(conn.queries.some((q) => /SHOW GRANTS/i.test(q.sql))).toBe(true);
  });

  it('SKIPS the DDL-grants preflight when the caller signals ddlPreflightAlreadyRun (boot dedup)', async () => {
    // ensureInfrastructure already ran the identical preflight this
    // boot, so the migration runner must not issue a second SHOW GRANTS. The
    // mock has no SHOW GRANTS / information_schema.TABLES matcher, so a stray
    // preflight probe would throw "Unmatched query" and fail loudly.
    const m = makeModule({ _configFull: { database: 'testdb', user: 'app' }, _tablePrefix: PREFIX, APP_TABLE_NAMES: ['users'] });
    const conn = makeConn([
      [/SELECT DATABASE\(\)/i, [{ db: 'testdb' }]],
      [/GET_LOCK/i, [{ locked: 1 }]],
      STAMP_AT_TARGET,
      [/RELEASE_LOCK/i, []],
    ]);
    await m.runSchemaMigrations(conn, { context: 'boot', ddlPreflightAlreadyRun: true });
    expect(conn.queries.some((q) => /SHOW GRANTS/i.test(q.sql))).toBe(false);
  });

  it('on lock acquired → runs the locked body and releases the lock in finally', async () => {
    // _configFull=null skips the preflight-grant branch so the locked body runs
    // straight to the stamp read; at-target short-circuits before any DDL.
    const m = makeModule({ _configFull: null });
    const conn = makeConn([
      [/SELECT DATABASE\(\)/i, [{ db: 'testdb' }]],
      [/GET_LOCK/i, [{ locked: 1 }]],
      STAMP_AT_TARGET,
      [/RELEASE_LOCK/i, []],
    ]);
    await m.runSchemaMigrations(conn, { context: 'boot' });
    expect(conn.queries.some((q) => /GET_LOCK/i.test(q.sql))).toBe(true);
    expect(conn.queries.some((q) => /RELEASE_LOCK/i.test(q.sql))).toBe(true);
  });
});
