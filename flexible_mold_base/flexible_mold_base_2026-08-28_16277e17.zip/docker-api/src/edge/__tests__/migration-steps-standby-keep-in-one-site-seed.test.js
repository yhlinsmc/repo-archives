/**
 * migration-steps-standby-keep-in-one-site-seed.test.js — AR2-Q11 (spec §7 E1).
 *
 * `cap_rules_seed_standby_keep_in_one_site` inserts the 8th
 * DEFAULT_RULE_TEMPLATE row (rule-types.js) into any deployment's global
 * cap_rules set that has not already been seeded, tracked by a
 * `system_settings` marker (CONN-... redesign: replaces an earlier
 * frozen-7-row byte-match eligibility) — mirrors `migration-steps-topology-
 * rac-rename.test.js`'s own idiom for exercising a custom step's `run()`/
 * `probe()` against a mocked `conn`, no real DB.
 */
import { describe, it, expect } from 'vitest';

const { MIGRATION_STEPS } = require('../migration-steps');
const { DEFAULT_RULE_TEMPLATE } = require('../../shared/capacity/rule-types');

const t = (table) => `fmb_${table}`;

function findStep(stepName) {
  const step = MIGRATION_STEPS.find((s) => s.step === stepName);
  if (!step) throw new Error(`migration step not found in registry: ${stepName}`);
  return step;
}

// The untouched pre-AR2-Q11 7-row global rule set, as the probe's own SELECT
// would read it back — only `type`/`group_by` are read by the step now (the
// eligibility rule no longer byte-matches name/level/params/severity/enabled).
const PRE_Q11_ROWS = [
  { type: 'no-oversell', group_by: 'all_of_type' },
  { type: 'max-vms-per-host', group_by: 'all_of_type' },
  { type: 'max-instances-per-vm', group_by: 'all_of_type' },
  { type: 'keep-apart', group_by: 'each_primary_cluster' },
  { type: 'keep-apart', group_by: 'each_standby_cluster' },
  { type: 'keep-in-one-site', group_by: 'each_primary_cluster' },
  { type: 'spread-across-sites', group_by: 'each_database' },
];

const STANDBY_ROW = { type: 'keep-in-one-site', group_by: 'each_standby_cluster' };

const MARKER_KEY = 'migration_seed_ar2q11_standby_rule';

// A mock `conn`: answers the probe's own information_schema TABLES existence
// read, the marker SELECT from `system_settings`, the global cap_rules SELECT
// from a scripted row set, and records every INSERT so a test can assert
// whether run() actually wrote (and to which table).
function makeConn({ tableExists = true, rows = [], markerPresent = false }) {
  const queries = [];
  return {
    queries,
    async query(sql, params = []) {
      queries.push({ sql, params });
      if (/information_schema\.TABLES/i.test(sql)) return tableExists ? [{ 1: 1 }] : [];
      if (/FROM `fmb_system_settings`\s+WHERE `key` = \?/.test(sql)) {
        return markerPresent ? [{ value: '"1"' }] : [];
      }
      if (/^SELECT type, group_by\s+FROM/.test(sql)) {
        return rows;
      }
      return {}; // INSERT
    },
  };
}

function insertsIn(conn, table) {
  return conn.queries.filter((q) => /^INSERT INTO/.test(q.sql) && (!table || q.sql.includes(`\`${table}\``)));
}

function capRuleInserts(conn) {
  return insertsIn(conn, 'fmb_cap_rules');
}

function markerInserts(conn) {
  return insertsIn(conn, 'fmb_system_settings').filter((q) => q.params.includes(MARKER_KEY));
}

describe('cap_rules_seed_standby_keep_in_one_site', () => {
  const step = findStep('cap_rules_seed_standby_keep_in_one_site');

  it('registry entry carries a probe() and a remediationSql() (fmb-1329 contract)', () => {
    expect(typeof step.probe).toBe('function');
    expect(typeof step.remediationSql).toBe('function');
    expect(step.version).toBe('3.2.807');
  });

  it('table absent (fresh install) -> probe satisfied, run is a no-op', async () => {
    const conn = makeConn({ tableExists: false, rows: [] });
    expect(await step.probe(conn, t)).toBe(true);
    await step.run({ conn, t });
    expect(capRuleInserts(conn).length).toBe(0);
  });

  it('never-seeded + empty global set -> probe NOT satisfied, run seeds the FULL 8-row template + marker', async () => {
    const conn = makeConn({ rows: [] });
    expect(await step.probe(conn, t)).toBe(false);
    await step.run({ conn, t });
    // Atomicity pin (P1 fix): the 8 rows travel in a SINGLE INSERT statement
    // (one VALUES list, 8 tuples) — a transient failure mid-seed can no
    // longer commit a partial set, because the whole statement is
    // per-statement atomic (all 8 rows or none).
    const inserts = capRuleInserts(conn);
    expect(inserts.length).toBe(1);
    expect(inserts[0].params.length).toBe(8 * 7);
    expect(markerInserts(conn).length).toBe(1);
  });

  it('never-seeded + untouched pre-AR2-Q11 7-row set -> probe NOT satisfied, run seeds ONLY the new row + marker', async () => {
    const conn = makeConn({ rows: PRE_Q11_ROWS });
    expect(await step.probe(conn, t)).toBe(false);
    await step.run({ conn, t });
    const inserts = capRuleInserts(conn);
    expect(inserts.length).toBe(1);
    expect(inserts[0].params).toEqual([
      'keep-in-one-site', 'Keep in one site (standby)', 'db_instance', 'each_standby_cluster', '{}', 'hard', 1,
    ]);
    expect(markerInserts(conn).length).toBe(1);
  });

  it('never-seeded + operator-edited OTHER rows (non-empty, diverged) -> SEEDS the new row + marker (flipped vs the retired byte-match design)', async () => {
    const edited = [...PRE_Q11_ROWS, {
      type: 'keep-apart', group_by: 'custom_group',
    }];
    const conn = makeConn({ rows: edited });
    expect(await step.probe(conn, t)).toBe(false);
    await step.run({ conn, t });
    expect(capRuleInserts(conn).length).toBe(1);
    expect(markerInserts(conn).length).toBe(1);
  });

  it('standby row already present, no marker -> probe satisfied, run is a no-op (no write, no marker backfill)', async () => {
    const conn = makeConn({ rows: [...PRE_Q11_ROWS, STANDBY_ROW] });
    expect(await step.probe(conn, t)).toBe(true);
    await step.run({ conn, t });
    expect(capRuleInserts(conn).length).toBe(0);
    expect(markerInserts(conn).length).toBe(0);
  });

  it('H1 regression pin: marker present after the row was deleted -> probe satisfied, run does NOT re-seed', async () => {
    // The row is gone (operator deleted it deliberately) but the marker
    // survives — a live-row-only probe would read this as "never seeded"
    // and insert it right back every boot. The marker is what must hold.
    const conn = makeConn({ rows: PRE_Q11_ROWS, markerPresent: true });
    expect(await step.probe(conn, t)).toBe(true);
    await step.run({ conn, t });
    expect(capRuleInserts(conn).length).toBe(0);
  });

  it('idempotent re-run: standby row + marker both already present -> no double-insert', async () => {
    const conn = makeConn({ rows: [...PRE_Q11_ROWS, STANDBY_ROW], markerPresent: true });
    expect(await step.probe(conn, t)).toBe(true);
    await step.run({ conn, t });
    expect(capRuleInserts(conn).length).toBe(0);
    expect(markerInserts(conn).length).toBe(0);
  });

  it('remediationSql() returns literal-valued INSERTs (7-row empty-set statement + standby row) plus the marker upsert', () => {
    const sql = step.remediationSql(t);
    expect(Array.isArray(sql)).toBe(true);
    // ONE statement carrying all 7 pre-existing template rows (UNION ALL,
    // guarded once by "the whole set is empty") + 1 standby row (own-identity
    // guarded) + 1 marker upsert.
    expect(sql.length).toBe(3);
    // Distinguish from 'Keep apart (standby)' — the pre-existing template row
    // that ALSO carries group_by='each_standby_cluster' — by type as well.
    const standbyStmt = sql.find((s) => s.includes("'keep-in-one-site'") && s.includes("'each_standby_cluster'") && !s.includes('UNION ALL'));
    expect(standbyStmt).toBeTruthy();
    expect(standbyStmt).toContain("'keep-in-one-site'");
    expect(standbyStmt).toContain("'Keep in one site (standby)'");
    const markerStmt = sql.find((s) => s.includes(`INSERT INTO \`${t('system_settings')}\``));
    expect(markerStmt).toBeTruthy();
    expect(markerStmt).toContain(MARKER_KEY);
    expect(markerStmt).toContain('ON DUPLICATE KEY UPDATE');
    for (const stmt of sql) {
      expect(stmt.trim().endsWith(';')).toBe(true);
    }
  });

  // Regression for the P2 bug: the 7 template-row statements used to be
  // guarded independently by their OWN (type, group_by) identity, which
  // BACKFILLED template rows an operator had deliberately deleted from a
  // customized (non-empty) set — diverging from run(), which only ever adds
  // the standby row to a non-empty set. The fix folds all 7 rows into ONE
  // statement (UNION ALL) guarded ONCE by "the whole global set is empty",
  // matching run()'s empty-set-only semantic with no sequential-skip risk
  // (the guard is evaluated exactly once, not per-row across sequential
  // DBA-run statements).
  it('remediationSql(): the 7-row statement is guarded ONCE by "set is empty", not per-row identity', () => {
    const sql = step.remediationSql(t);
    const rowInserts = sql.filter((s) => s.includes(`INSERT INTO \`${t('cap_rules')}\``));
    // 1 UNION ALL statement (7 non-standby rows) + 1 standby row statement.
    expect(rowInserts.length).toBe(2);

    const sevenRowStmt = rowInserts.find((s) => s.includes('UNION ALL'));
    expect(sevenRowStmt).toBeTruthy();
    // Every non-standby template row's tuple is present in the ONE statement.
    for (const row of DEFAULT_RULE_TEMPLATE.filter((r) => !(r.type === STANDBY_ROW.type && r.group_by === STANDBY_ROW.group_by))) {
      expect(sevenRowStmt).toContain(`'${row.type}'`);
      expect(sevenRowStmt).toContain(`'${row.group_by}'`);
    }
    // The guard must apply to the WHOLE union, not just its last arm: a bare
    // `UNION ALL SELECT ... WHERE NOT EXISTS` tail-guard only binds to the
    // final SELECT, letting the other rows insert unconditionally. The fix
    // wraps the union in a derived table and guards the outer SELECT once.
    expect(sevenRowStmt).toMatch(/SELECT \* FROM \(\s*SELECT[\s\S]*UNION ALL[\s\S]*\) AS seed_rows\s+WHERE NOT EXISTS/);
    // No bare tail-guard form (guard immediately after the last UNION ALL arm
    // with no derived-table close paren in between) should remain.
    expect(sevenRowStmt).not.toMatch(/UNION ALL SELECT[^()]*WHERE NOT EXISTS/);

    // The guard is the whole-set-empty check — no per-row type/group_by
    // condition anywhere in this statement's WHERE clause.
    const guardMatch = sevenRowStmt.match(/\) AS seed_rows\s+(WHERE NOT EXISTS \(SELECT 1 FROM `[^`]+` (WHERE[^)]*)\))/);
    expect(guardMatch, `no NOT EXISTS guard found after derived table close in: ${sevenRowStmt}`).toBeTruthy();
    expect(guardMatch[2]).toBe('WHERE scenario_id IS NULL');

    // The standby row statement keeps its own (type, group_by) identity guard.
    const standbyStmt = rowInserts.find((s) => s !== sevenRowStmt);
    const standbyGuardMatch = standbyStmt.match(/WHERE NOT EXISTS \(SELECT 1 FROM `[^`]+` (WHERE[^)]*)\)/);
    expect(standbyGuardMatch, `no NOT EXISTS guard found in: ${standbyStmt}`).toBeTruthy();
    expect(standbyGuardMatch[1]).toContain('scenario_id IS NULL');
    expect(standbyGuardMatch[1]).toContain(`type = '${STANDBY_ROW.type}'`);
    expect(standbyGuardMatch[1]).toContain(`group_by = '${STANDBY_ROW.group_by}'`);

    // Marker upsert runs last.
    expect(sql[sql.length - 1]).toContain(MARKER_KEY);
  });
});
