/**
 * migration-steps-created-at-backfill.test.js — T11.
 *
 * Unit tests for the `_backfillCreatedAtNotNull` custom-step logic backing the
 * two production registry entries `user_templates_created_at_not_null_backfill`
 * and `flow_recipe_runs_created_at_not_null_backfill`. Stub-based (mirrors
 * migration-executor.test.js's makeConn pattern) — no real DB.
 *
 * Covers:
 *   - table-existence guard: fresh-install no-op (table absent → zero further
 *     queries), mirroring the add-column/drop-column convention
 *   - idempotency: column already NOT NULL → no UPDATE/ALTER issued
 *   - dirty-data-safe backfill: nullable column → UPDATE …SET created_at = NOW()
 *     WHERE created_at IS NULL, THEN ALTER …MODIFY COLUMN …NOT NULL (order
 *     matters — backfilling after the ALTER would already be rejected by the
 *     new constraint)
 */
import { describe, it, expect } from 'vitest';

const { MIGRATION_STEPS } = require('../migration-steps');

const PREFIX = 'mig_';
const t = (name) => `${PREFIX}${name}`;

function findStep(name) {
  const step = MIGRATION_STEPS.find((s) => s.step === name);
  if (!step) throw new Error(`registry step not found: ${name}`);
  return step;
}

/**
 * scripts: Array<[RegExp, response | (sql, params) => any]>
 * Unmatched queries throw so a forgotten branch fails loudly.
 */
function makeConn(scripts) {
  const queries = [];
  return {
    queries,
    query: async function (sql, params) {
      queries.push({ sql, params });
      for (const [matcher, response] of scripts) {
        if (matcher.test(sql)) {
          return typeof response === 'function' ? response(sql, params) : response;
        }
      }
      throw new Error(`Unmatched query in test mock: ${sql.replace(/\s+/g, ' ').slice(0, 120)}`);
    },
  };
}

describe.each([
  ['user_templates_created_at_not_null_backfill', 'mig_user_templates'],
  ['flow_recipe_runs_created_at_not_null_backfill', 'mig_flow_recipe_runs'],
])('%s', (stepName, physicalTable) => {
  it('no-ops on a fresh-install DB where the table does not exist yet', async () => {
    const conn = makeConn([
      [/information_schema\.TABLES/, []],
    ]);
    await findStep(stepName).run({ conn, t });
    expect(conn.queries.length).toBe(1);
    expect(/information_schema\.TABLES/.test(conn.queries[0].sql)).toBe(true);
  });

  it('no-ops when created_at is already NOT NULL (idempotent rerun)', async () => {
    const conn = makeConn([
      [/information_schema\.TABLES/, [{ 1: 1 }]],
      [/information_schema\.COLUMNS/, [{ IS_NULLABLE: 'NO' }]],
    ]);
    await findStep(stepName).run({ conn, t });
    expect(conn.queries.some((q) => /^UPDATE/i.test(q.sql))).toBe(false);
    expect(conn.queries.some((q) => /^ALTER TABLE/i.test(q.sql))).toBe(false);
  });

  it('backfills NULL rows to NOW() THEN modifies the column NOT NULL, in that order', async () => {
    const conn = makeConn([
      [/information_schema\.TABLES/, [{ 1: 1 }]],
      [/information_schema\.COLUMNS/, [{ IS_NULLABLE: 'YES' }]],
      [/^UPDATE/, { affectedRows: 3 }],
      [/^ALTER TABLE/, {}],
    ]);
    await findStep(stepName).run({ conn, t });

    const updateQuery = conn.queries.find((q) => /^UPDATE/i.test(q.sql));
    const alterQuery = conn.queries.find((q) => /^ALTER TABLE/i.test(q.sql));
    expect(updateQuery, 'expected a backfill UPDATE').toBeTruthy();
    expect(alterQuery, 'expected a MODIFY COLUMN ALTER').toBeTruthy();
    expect(updateQuery.sql).toContain(`\`${physicalTable}\``);
    expect(updateQuery.sql).toMatch(/SET `created_at` = NOW\(\) WHERE `created_at` IS NULL/);
    expect(alterQuery.sql).toContain(`\`${physicalTable}\``);
    expect(alterQuery.sql).toMatch(/MODIFY COLUMN `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP/);

    // Order matters: the UPDATE must run before the ALTER, or a legacy NULL
    // row would already violate the new NOT NULL constraint by the time the
    // backfill tries to touch it.
    const updateIdx = conn.queries.indexOf(updateQuery);
    const alterIdx = conn.queries.indexOf(alterQuery);
    expect(updateIdx).toBeLessThan(alterIdx);
  });
});

describe('registry shape (fmb-1329 T11 entries)', () => {
  it('both backfill entries are version 3.2.579, kind custom, severity warning', () => {
    for (const name of [
      'user_templates_created_at_not_null_backfill',
      'flow_recipe_runs_created_at_not_null_backfill',
    ]) {
      const step = findStep(name);
      expect(step.version).toBe('3.2.579');
      expect(step.kind).toBe('custom');
      expect(step.severity).toBe('warning');
      expect(typeof step.run).toBe('function');
    }
  });
});
