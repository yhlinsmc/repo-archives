/**
 * public-docs.js — the customer-facing Public Integration API documentation
 * portal (Scalar reference UI + the raw public-only OpenAPI JSON).
 *
 * Two routes, both PRODUCTION-ENABLED (unlike the dev-only /api/docs stub) and
 * gated to any logged-in human:
 *   GET /api/public-docs              → Scalar reference UI (read-only)
 *   GET /api/public-docs/openapi.json → the public-only OpenAPI document
 *
 * SECURITY — gate model: the portal documents the machine-tier API but is a
 * human-operator surface, so it trusts req.user (populated by the human auth
 * chain in infra/middleware/auth.js) and grants NOTHING off a raw Bearer token.
 * A machine principal (an opaque APISIX token) never populates req.user on this
 * path — the human auth middleware only resolves OIDC sessions and HS256 human
 * JWTs — so a machine token receives the same 401 as an anonymous caller.
 *
 * MOUNT ORDER — must be mounted AFTER the human auth middleware (so req.user is
 * set) but BEFORE the pool-readiness gate and the Keycloak RBAC access-check, so
 * the docs stay reachable without a configured pool and without an allowlist
 * entry. The portal exposes no data beyond the already-public API contract.
 *
 * CSP — served under createDocsHelmet() scoped to this path only. Empirical
 * finding (P4 CSP probe, recorded for CSO): Scalar CANNOT render under the
 * strict default CSP — its bootstrap is an INLINE <script>Scalar.createApiReference(...)</script>
 * that `script-src 'self'` blocks outright, so #app never mounts. The
 * docs-scoped relaxation (script-src adds 'unsafe-inline' + 'unsafe-eval') is
 * required and matches the existing dev /api/docs route. The Scalar bundle is
 * self-hosted (createScalarStaticRouter in app-setup, ungated static JS), and
 * the search / AI-agent / telemetry features that would call api.scalar.com are
 * disabled so the same-origin connect-src produces zero console errors and the
 * portal stays fully self-contained (AIRGAP-safe).
 *
 * WHERE THE SPEC COMES FROM — the reference UI FETCHES the document from
 * PUBLIC_DOCS_SPEC_PATH; it is not embedded in the bootstrap script. Scalar's
 * renderer JSON.stringify()s the whole configuration verbatim into that inline
 * <script>, so an embedded document put ~41KB of author-written markdown inside
 * a script element on a route whose CSP is relaxed to 'unsafe-inline'. Escaping
 * the breakers guarded that; fetching removes the shape. The three things that
 * had to be settled together for the fetch to be safe:
 *
 *   AUTH — the fetch is same-origin and browser `fetch()` defaults to
 *   `credentials: 'same-origin'`, so it carries the session cookie the page
 *   itself was loaded with and lands on the SAME chain (publicDocsLimiter →
 *   requirePortalAuth). No second gate to keep in sync, no token in a URL, and
 *   an anonymous caller gets the same 401 from both routes.
 *
 *   CSP — a same-origin path is already covered by the `connect-src 'self'`
 *   createDocsHelmet() pins, so the policy does not move. The URL is
 *   ROOT-RELATIVE for a second reason as well: Scalar routes document fetches
 *   through `config.proxyUrl` when one is set, and its shouldUseProxy() refuses
 *   to proxy a relative URL — so the document request cannot be re-pointed at a
 *   third-party proxy by a future config edit.
 *
 *   CACHING — see the route below.
 *
 *   FAILURE — a document that is in the first paint cannot fail to arrive; one
 *   that is fetched can. The renderer's own answer to any non-2xx is to title
 *   the page after an internal slug and serve that inside a 200, so the page
 *   carries its own answer instead: a placeholder while the document is in
 *   flight, and a stated cause with a reload when it does not come. See
 *   public-docs-boot.js.
 */
const { getPublicSpec, escapeForInlineScript } = require('../../shared/openapi');
const { createDocsHelmet, getScalarCdnUrl, buildDocsFontOptions } = require('../../shared/security');
const { SCALAR_MOUNT } = require('../app-setup');
const { requireAuth } = require('../../shared/helpers');
const { createPublicDocsLimiter } = require('../limiters');
const { injectDocsBoot } = require('./public-docs-boot');
const { logger: rootLogger } = require('../../shared/lib/logger');

const logger = rootLogger.child({ module: 'public-docs' });

// One definition for the mount and the document URL, because the reference UI
// now has to ask for the document by path: a drifted literal would leave the
// portal fetching a 404 while every route test still passed.
const PUBLIC_DOCS_MOUNT = '/api/public-docs';
const PUBLIC_DOCS_SPEC_PATH = `${PUBLIC_DOCS_MOUNT}/openapi.json`;

/**
 * Middleware adapter around the requireAuth guard-clause helper: 401s (uniform
 * infra envelope) when req.user is absent, otherwise passes through. The portal
 * inspects ONLY req.user — never the Authorization header — so a raw Bearer
 * without a resolved human identity grants nothing.
 * @param {import('express').Request} req
 * @param {import('express').Response} res
 * @param {import('express').NextFunction} next
 */
function requirePortalAuth(req, res, next) {
  if (!requireAuth(req, res)) return; // requireAuth already wrote the 401
  return next();
}

/**
 * Scalar reference config. The api.scalar.com-backed search / agent / telemetry
 * features stay disabled to keep the console clean under the same-origin CSP
 * and to keep the portal AIRGAP-safe.
 *
 * hideTestRequestButton stays TRUE: the portal must never fire a live request
 * from the reader's browser session (spec §7 — the reader is a logged-in human,
 * the API is a machine tier, and a "try it" click would send the human's cookie
 * to a machine-tier route). The generated-snippet affordances are separate and
 * are ON: they only render text.
 */
function buildScalarConfig() {
  // Still escaped although the document itself no longer travels this way:
  // Scalar serialises this ENTIRE object into the inline <script> that
  // bootstraps the page, so the guarantee worth keeping is about the object, not
  // about one field of it — whatever a later edit adds here cannot terminate the
  // script element it lands in.
  return escapeForInlineScript({
    cdn: getScalarCdnUrl(SCALAR_MOUNT),
    // Fetched, not embedded. See the file header for why, and for why this is a
    // root-relative path rather than an absolute URL.
    url: PUBLIC_DOCS_SPEC_PATH,
    ...buildDocsFontOptions(SCALAR_MOUNT),
    hideTestRequestButton: true,
    hideClientButton: false,
    // WHY: `hiddenClients` is deliberately ABSENT, never `false`. Its schema
    // (`apiReferenceConfigurationWithSourceSchema` in @scalar/schemas, the same
    // object the reference bundle validates this config with) declares it as the
    // union `record | string[] | literal true` — a boolean `false` is not a
    // member. Through @scalar/api-reference 1.5x that schema was a zod object and
    // one out-of-union value failed the WHOLE safeParse, emptying the configList;
    // the 1.64 line swapped zod for a lenient per-field coercer that repairs a
    // stray `false` to `{}` rather than discarding the object, so that specific
    // trap is gone. Absence stays the correct encoding regardless: it is what
    // "hide no client" means here, and it keeps the client picker enabled so
    // every generated code sample is offered. Passing `false` would now be
    // silently rewritten, which is a worse thing to depend on than not sending it.
    hideSearch: true,
    telemetry: false,
    agent: { disabled: true },
  });
}

/**
 * Would the INSTALLED renderer degrade this configuration — a blank page, or the
 * fourteen external @font-face declarations switched back on ?
 *
 * The reference bundle runs each source through
 * `apiReferenceConfigurationWithSourceSchema` — now a lenient @scalar/validation
 * COERCER (not a zod schema): it repairs out-of-union or missing fields in place
 * instead of failing the whole object. That leniency gives the
 * degradation TWO independent routes, and a check for only one of them silently
 * ships the other:
 *
 *   1. SOURCE PRESENCE — normalizeConfigurations() drops any coerced source that
 *      carries neither a non-empty `url` nor `content` (its
 *      isConfigWithRequiredSource filter). An emptied configList renders no
 *      document, AND the merged config the page reads then falls back to
 *      `coerce(apiReferenceConfigurationSchema, {})` where `withDefaultFonts`
 *      defaults to TRUE — blank page with the external fonts back on.
 *
 *   2. FONT INVARIANT — the coercer repairs a stray or missing `withDefaultFonts`
 *      to that same schema default TRUE IN PLACE (measured: "no", null, {}, 0,
 *      undefined all become true). The SOURCE survives, so route 1 never fires,
 *      yet the fonts are back on just the same. buildScalarConfig() always sends
 *      `false`, so any value other than `false` surviving coercion is a silent
 *      revert of the exact invariant this portal exists to hold.
 *
 * History worth keeping: through @scalar/api-reference 1.5x the discard was an
 * all-or-nothing zod safeParse — one out-of-union value emptied the whole config
 * and the guard could ride on `success === false`. The 1.64 line replaced zod
 * with the per-field coercer, so a single safeParse no longer expresses either
 * route; both are checked explicitly below. The config schema also moved
 * package: it is imported from `@scalar/schemas/api-reference` now, where the
 * reference bundle reads it (@scalar/types no longer carries it).
 *
 * MAINTENANCE COUPLING: `@scalar/express-api-reference` is pinned to `^0.10.13`,
 * whose `@scalar/client-side-rendering` chain carries `@scalar/types@0.17.1`
 * natively — the same version `@scalar/api-reference ^1.50.0` resolves — so the
 * `@scalar/types` package.json `overrides` entry that used to force convergence
 * across the two chains on the 0.9.x line has been removed. Re-check this
 * coupling (and reintroduce an override if the two chains diverge again) on the
 * next `@scalar/express-api-reference` or `@scalar/api-reference` major bump.
 *
 * Checked here so that failure is a deliberate degradation instead: the JSON
 * pointer below renders no Scalar page at all, and therefore declares nothing.
 * The schema package is require()-able from CommonJS on Node ≥22.12 (no
 * top-level await), so the check needs no async plumbing at boot. Two failure
 * classes, two answers: a packaging fault that makes the schema UNREADABLE gets
 * `null` — the check fails OPEN (an unrunnable check must not degrade a working
 * portal) — whereas a coercer that RUNS and throws on our input gets `true`: the
 * browser calls the same coercer, so the page would throw too and the pointer is
 * the safe answer.
 *
 * @param {Record<string, unknown>} config the object handed to apiReference()
 * @returns {boolean|null} true when the installed renderer would degrade the
 *   portal (blank page or fonts reverted on), false when it keeps the config
 *   intact, or null when the schema could not be read
 */
function rendererRejectsConfig(config) {
  let coerceSource;
  try {
    ({ apiReferenceConfigurationWithSourceSchema: coerceSource } = require('@scalar/schemas/api-reference'));
  } catch {
    return null;
  }
  if (typeof coerceSource !== 'function') return null;
  // Mirror what actually reaches the browser: apiReference() adds its own
  // integration marker and strips `cdn`/`pageTitle` before serialising.
  const forBrowser = { ...config, _integration: 'express' };
  delete forBrowser.cdn;
  delete forBrowser.pageTitle;
  let coerced;
  try {
    coerced = coerceSource(forBrowser);
  } catch {
    // The coercer ran and threw on this input; the browser's
    // normalizeConfigurations calls the same function, so the page would throw
    // too. Degrade to the pointer rather than mount a config the renderer chokes on.
    return true;
  }
  // Route 1: a source the bundle would drop (isConfigWithRequiredSource).
  const rendersNothing = !(coerced?.url?.trim() || coerced?.content);
  // Route 2: the font invariant coerced away to the schema default (true).
  const fontsReverted = coerced?.withDefaultFonts !== false;
  return rendersNothing || fontsReverted;
}

/**
 * Degraded portal: the raw document stays reachable and the UI route says where
 * it is. Shared by both ways the reference UI can be unavailable.
 * @param {import('express').Express} app
 * @param {import('express').RequestHandler} limiter
 */
function mountSpecPointerOnly(app, limiter) {
  app.get(PUBLIC_DOCS_MOUNT, limiter, requirePortalAuth, (_req, res) => res.status(200).json({
    message: `Documentation UI unavailable. Use ${PUBLIC_DOCS_SPEC_PATH} for the raw spec.`,
  }));
}

/**
 * Mount the documentation portal onto the infra app. See file header for the
 * load-bearing mount-order contract.
 * @param {import('express').Express} app
 */
function mountPublicDocs(app) {
  // SECURITY: rate limiter runs BEFORE requirePortalAuth, so an unresolved
  // caller cannot probe either route for free. Shared budget across both, which
  // now costs a reader two hits per page view (the shell, then the document it
  // fetches) instead of one.
  const publicDocsLimiter = createPublicDocsLimiter();

  // Raw spec first so the exact /openapi.json path wins over the catch-all UI
  // handler mounted at the same prefix below.
  app.get(PUBLIC_DOCS_SPEC_PATH, publicDocsLimiter, requirePortalAuth, (_req, res) => {
    // CACHING — DECIDED, not defaulted. `no-cache` keeps the copy but revalidates
    // on every view, and the ETag express computes over the body turns a repeat
    // view into a 304. The cost is a request per view — reload, back-navigation
    // and restored tab included — from the same per-reader budget this route now
    // spends twice per page view, and a 304 does NOT refund it: the limiter
    // counts before the handler runs. A short freshness window would remove
    // those requests, and it was rejected for two reasons:
    //
    //   1. The budget is not the binding constraint. 60/min is 30 page views a
    //      minute for one reader — far above a human reading rate — and the
    //      limiter exists against scripted abuse, which ignores caches entirely.
    //      Spending a request on a reload buys nothing an abuser could not have.
    //   2. Freshness is not what would be traded away — the gate would be. A
    //      response held under max-age is served from the browser cache WITHOUT
    //      asking this origin, so it would keep answering after the session that
    //      earned it has expired or been signed out. Revalidating is what makes
    //      the 401 arrive on the first view after the session ends, which is the
    //      case the page now has an answer for (public-docs-boot.js).
    //
    // `private` keeps it out of shared caches: the document is the same for
    // every reader, but the route is login-gated and an intermediary has no way
    // to re-run that check.
    res.set('Cache-Control', 'private, no-cache');
    res.json(getPublicSpec());
  });

  let apiReference;
  try {
    ({ apiReference } = require('@scalar/express-api-reference'));
  } catch (err) {
    // The Scalar dep is committed, so this is a genuine packaging fault — keep
    // the raw spec reachable and surface a pointer rather than 500 the route.
    logger.error({ err: err.message }, 'Scalar unavailable — public docs UI degraded to a JSON pointer');
    mountSpecPointerOnly(app, publicDocsLimiter);
    return;
  }

  const config = buildScalarConfig();
  if (rendererRejectsConfig(config) === true) {
    logger.error(
      { mount: PUBLIC_DOCS_MOUNT },
      'Scalar config rejected by the installed schema — public docs UI degraded to a JSON pointer '
      + '(the rendered page would show no document and would re-enable the bundle\'s external fonts)',
    );
    mountSpecPointerOnly(app, publicDocsLimiter);
    return;
  }

  const docsHelmet = createDocsHelmet();
  const renderPage = apiReference(config);
  app.use(PUBLIC_DOCS_MOUNT, publicDocsLimiter, requirePortalAuth, docsHelmet, (req, res, next) => {
    // The renderer builds the whole document in one third-party call with no
    // slot for extra markup, so the boot script goes in on the way out. Scoped
    // to this response, and a body that is not the renderer's HTML is passed
    // through untouched.
    const sendOriginal = res.send.bind(res);
    res.send = (body) => sendOriginal(injectDocsBoot(body, PUBLIC_DOCS_SPEC_PATH));
    return renderPage(req, res, next);
  });
}

module.exports = {
  mountPublicDocs,
  requirePortalAuth,
  buildScalarConfig,
  rendererRejectsConfig,
  PUBLIC_DOCS_MOUNT,
  PUBLIC_DOCS_SPEC_PATH,
};
