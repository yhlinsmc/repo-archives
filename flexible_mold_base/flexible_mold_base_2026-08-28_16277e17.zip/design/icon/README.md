# Application icon — sources

The shipped icon is a rounded-square tile carrying a diagonal gradient
(`#2563EB` → `#0891B2`), a white document sheet with knocked-out form rows, and
a white gear overlapping the lower-right corner, separated from the sheet by a
knocked-out halo. It carries no text, no company name and no monogram, so it
survives a white-label export unchanged.

These files are build inputs, not runtime assets, which is why they live here
and not in `public/`: everything under `public/` is copied verbatim into the
built single-page app and served to every browser. The exported artefacts are:

| Shipped file | Built from |
| --- | --- |
| `public/favicon.svg` | `icon-master.svg`, with `width`/`height` removed so it scales to whatever box the browser gives it (`viewBox` retained) |
| `public/favicon.ico` entry 1 — 16×16 | `icon-16.svg` rasterised at 16 |
| `public/favicon.ico` entry 2 — 32×32 | `icon-32.svg` rasterised at 32 |
| `public/favicon.ico` entry 3 — 48×48 | `icon-32.svg` rasterised at 48 |
| `public/favicon-test.ico` entry 1 — 16×16 | `icon-16-test.svg` rasterised at 16 |
| `public/favicon-test.ico` entry 2 — 32×32 | `icon-32-test.svg` rasterised at 32 |
| `public/favicon-test.ico` entry 3 — 48×48 | `icon-32-test.svg` rasterised at 48 |

`icon-16-test.svg` and `icon-32-test.svg` are the same drawings as `icon-16.svg`
and `icon-32.svg` with only the gradient stops swapped, from the production
pair to `TEST_GRADIENT` in `src/platform/lib/icon-palette.ts` (`#6D28D9` →
`#A855F7`). `public/favicon-test.ico` exists because Chrome picks the static
`<link rel="icon" href="/favicon.ico">` in `index.html` over the SVG
`public/favicon-swap.js` adds at runtime, so the zone-test tab icon (fmb-1852)
needs its own zone-correct `.ico`, not just a zone-correct SVG.

`icon-mono.svg` is the same geometry as `icon-master.svg` without the tile and
gradient — a white glyph on transparency, for surfaces that supply their own
tile. Nothing consumes it today; it is kept so that case does not require
redrawing the mark.

## Why the 16px entry is a different drawing

At 16 device pixels the master mark loses legibility: three form rows collapse
into a grey smear and six gear teeth alias into a disc. `icon-16.svg` therefore
drops the middle row (two rows, long over short, still reads as a form) and
reduces the gear to four chunky teeth with a larger centre hole.

So the container carries **two drawings across its three entries**: `icon-16.svg`
at 16, and `icon-32.svg` rasterised twice (at 32 and again, larger, at 48). The
48px entry is the same drawing as the 32px one, not a third.

This is the reason the ICO must be assembled from rasters produced separately
rather than downscaled from one source: a single-source tool would overwrite the
16px drawing with a shrunken master and the difference would disappear silently.
`scripts/export-source/__tests__/ico-entry-diff.mjs` measures that difference —
it decodes the 16px entry and a plain downscale of the 32px one and reports the
mean absolute luminance gap, which the export test requires to stay well above
zero.

## Rebuilding `public/favicon.ico`

Hand-run and rarely needed — deliberately not wired into CI.

1. Rasterise each source at its exact target size to PNG, keeping the alpha
   channel: `icon-16.svg` at 16, `icon-32.svg` at 32, `icon-32.svg` at 48. Any
   renderer works as long as the output PNG's `IHDR` reports exactly the target
   dimensions; the shipped file was produced by drawing the SVG into a canvas of
   that size in headless Chromium and reading back `toDataURL('image/png')`.
2. Assemble the container:

   ```bash
   node design/icon/build-ico.mjs \
     /path/to/icon-16.png /path/to/icon-32.png /path/to/icon-48.png \
     public/favicon.ico
   ```

   The script refuses any PNG whose header does not match its declared entry
   size, and prints a parse of the file it just wrote so the three entries can
   be checked. `file public/favicon.ico` should report three icons.

3. `public/favicon.svg` is `icon-master.svg` with the `width` and `height`
   attributes stripped. Copy it across by hand if the master changes.

The export pipeline asserts the exported `favicon.ico` is byte-identical to
`public/favicon.ico`, so a rebuild has to be committed for an export to pass.

`public/favicon-test.ico` is rebuilt the same way, substituting
`icon-16-test.svg` / `icon-32-test.svg` as the sources in step 1 and
`public/favicon-test.ico` as the output path in step 2.
