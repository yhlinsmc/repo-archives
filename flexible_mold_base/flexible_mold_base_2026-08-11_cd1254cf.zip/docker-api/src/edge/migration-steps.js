const { TABLES, FIELD_KEY_INDEX } = require('../shared/constants');
const { tableExistsInCurrentSchema } = require('./lib/table-exists');

/**
 * migration-steps — declarative schema-migration registry + baseline constant.
 *
 * fmb-1329: a future schema change is three edits — (1) update table-ddls.js,
 * (2) add one entry here, (3) bump PLATFORM_SCHEMA_VERSION. The shared executor
 * (migrations.js `_runMigrationSteps`) handles the table-existence guard,
 * information_schema probe, conditional DDL, error sanitisation, audit, and skip
 * accounting so each entry stays declarative.
 *
 * Entry kinds (executor branch in migrations.js):
 *   add-column   { version, kind: 'add-column', table: TABLES.X, column, ddl, step, severity }
 *                  `ddl` MUST equal the column line in table-ddls.js (Task 6 consistency test).
 *   create-table { version, kind: 'create-table', table: TABLES.Y, step, severity }
 *                  DDL is sourced from the DDL builders by physical table name.
 *   drop-column  { version, kind: 'drop-column', table: TABLES.X, column, step, severity,
 *                  alsoDropIndexes?: string[] }  — for confirmed-dead columns only (spec §4.5).
 *   custom       { version, kind: 'custom', step, severity, run: async (ctx) => {} }
 *                  ctx = { conn, t, TABLES, logger, sanitizeMigrationError }.
 *
 * INVARIANT (Task 6 consistency test): PLATFORM_SCHEMA_VERSION equals the max
 * entry `version`, or BASELINE_SCHEMA_VERSION when the registry is empty. The
 * registry shipped EMPTY after the baseline cleanup (PR1); the first real
 * entries arrived with the destructive batch (PR2, spec §4.6).
 */

// Below this stamp, migrations never run (spec §4.2). A DB stamped lower — or an
// engine-table DB with no stamp at all — is "unsupported": serve degraded, never
// touch the stamp, surface the upgrade path in schema/status.
const BASELINE_SCHEMA_VERSION = '3.2.520';

// The target the executor migrates toward and stamps on full success. Relocated
// here from db.js so registry + version live in one file; db.js re-exports it for
// existing importers.
//
// INVARIANT: this MUST equal the max entry version below (consistency test) AND
// MUST advance whenever a new entry is added — the executor gates the WHOLE run
// on `db_stamp < PLATFORM_SCHEMA_VERSION` (migrations.js), so an entry added
// without bumping this never runs on a database already stamped at the old
// value, which is exactly the population a data backfill must reach.
const PLATFORM_SCHEMA_VERSION = '3.2.729';

// fmb-1329 T11 (closes fmb-0533): user_templates.created_at and
// flow_recipe_runs.created_at were declared nullable (no code path ever wrote
// NULL — an unintentional gap, table-ddls.js now declares both NOT NULL).
//
// Probe/remediation contract (Codex R2, spec §4.3/§4.7 amendment): a custom
// step carries a read-only `probe(conn, tableFn)` ("already satisfied?") plus a
// `remediationSql(tableFn)` builder of DBA-executable statements. Together they
// make the destructive/custom batch visible to the remediation workflow (the
// missing-structure comparison only sees ADDED tables/columns — a NULL→NOT NULL
// change is invisible to it) and let a re-run converge silently after a DBA has
// applied the SQL out-of-band under a CRUD-only operator account.
//
// `_createdAtSatisfied` is that probe AND the guard the executor `run()` reuses:
// true means nothing to do — the table is absent (fresh-install no-op, mirrors
// the add/drop-column convention for the infra-only-first boot pass, spec §4.2),
// the column is absent (pre-add), or the column is already NOT NULL (idempotent
// — a prior run or a DBA-applied MODIFY already aligned it).
async function _createdAtSatisfied(conn, tableFn, table, column) {
  const physical = tableFn(table);
  if (!(await tableExistsInCurrentSchema(conn, physical))) return true;
  const rows = await conn.query(
    `SELECT IS_NULLABLE FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?`,
    [physical, column],
  );
  if (!rows.length) return true;
  return rows[0].IS_NULLABLE !== 'YES';
}

// Dirty-data-safe: a legacy NULL row is backfilled to NOW() (the row's true
// creation instant is unknowable in retrospect, and NOW() is the same value the
// DDL default would have written) BEFORE the MODIFY, so the ALTER never fails on
// an existing NULL. Idempotent via the shared probe.
async function _backfillCreatedAtNotNull(ctx, table, column) {
  const { conn, t } = ctx;
  if (await _createdAtSatisfied(conn, t, table, column)) return;
  const physical = t(table);
  await conn.query(`UPDATE \`${physical}\` SET \`${column}\` = NOW() WHERE \`${column}\` IS NULL`);
  await conn.query(
    `ALTER TABLE \`${physical}\` MODIFY COLUMN \`${column}\` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP`,
  );
}

// The DBA-executable form of the backfill, keyed by the caller's table resolver
// so no physical prefix is ever hardcoded (identifier-via-tables hard rule).
// UPDATE-then-MODIFY, same order + same statement text as `run()` issues at
// boot. Terminated with `;` — the export renders these verbatim.
function _createdAtRemediationSql(tableFn, table, column) {
  const physical = tableFn(table);
  return [
    `UPDATE \`${physical}\` SET \`${column}\` = NOW() WHERE \`${column}\` IS NULL;`,
    `ALTER TABLE \`${physical}\` MODIFY COLUMN \`${column}\` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP;`,
  ];
}

// Assemble a created_at NOT NULL backfill registry entry with the full custom
// contract: run (executor), probe (short-circuit + read-only derive), and
// remediationSql (DBA export).
function _createdAtBackfillEntry({ table, column, step }) {
  return {
    version: '3.2.579',
    kind: 'custom',
    step,
    severity: 'warning',
    run: (ctx) => _backfillCreatedAtNotNull(ctx, table, column),
    probe: (conn, tableFn) => _createdAtSatisfied(conn, tableFn, table, column),
    remediationSql: (tableFn) => _createdAtRemediationSql(tableFn, table, column),
  };
}

// ── 3.2.598: translating the legacy lock/rule pair into a stated mode ──────
//
// "There is no production data, so no compatibility shim" is a decision about
// the CODE MODEL — the runtime must read one shape, never two, and there is no
// dual-read and no inference fallback. It is NOT a decision that existing ROWS
// need no translation, and reading it that way is what left this batch adding
// `value_source` at its default and then dropping `is_locked` with neither
// legacy state carried across. On any database that already holds fields, that
// silently unlocks every locked field and stops every computed field computing,
// with nothing said. zone-test's demo data is exactly such a database.
//
// THE TRANSLATION, in full, and the reason for each row. `is_locked` and
// `compute_rule` were INDEPENDENT before this batch: the pre-mode resolver read
// `blueprintLock = field.is_locked === true` and `computeLock = rule.overridable
// === false` as separate facts, so a row could be both. The new model cannot say
// "both" — `locked` carries no rule and `calculated` carries one — so the row
// that carries both is the one needing a decision:
//
//   is_locked | rule | becomes                          | what is preserved
//   ----------+------+----------------------------------+---------------------
//   off       | none | 'entered'   (the column default) | exact
//   off       | yes  | 'calculated', rule unchanged     | exact — read-only-ness
//                                                         still comes from the
//                                                         rule's `overridable`
//   on        | none | 'locked'                         | exact
//   on        | yes  | 'calculated', rule forced        | BOTH: the value still
//                                                         `overridable: false`     computes AND cannot
//                                                                                  be edited
//
// The last row is the decision. `locked` would have been the other candidate and
// is worse: `locked` may not carry a rule, so choosing it means deleting the
// authored rule to keep the row coherent. `calculated` + `overridable: false` is
// the faithful reading — a value that is computed and cannot be edited is
// precisely what that pair means in the new model — and it destroys nothing.
//
// WHY NEVER 'copied'. It is a presentation distinction inside the compute-backed
// pair; both run the same way. Nothing before this batch could author a mirror
// (`buildMirrorRule` is new), so no legacy row means one, and inferring intent
// from a rule's shape is the inference this column exists to abolish.
//
// WHAT THIS DOES NOT DO. It does not touch a row whose `value_source` is already
// something other than 'entered' — a re-run after an operator has authored modes
// changes nothing, which is what makes it idempotent, and also means it cannot
// repair a database that already booted this version and lost its locks. It does
// not translate `value_scope` (nothing legacy maps to it). And if `JSON_SET`
// cannot rewrite a stored rule it leaves the document as it was: the row stays
// coherent and the forced lock is the thing lost, not the rule.

/** Is the legacy pair still readable, and is any row still awaiting translation? */
async function _legacyValueSourceTranslated(conn, tableFn) {
  const physical = tableFn(TABLES.BLUEPRINT_FIELDS);
  if (!(await tableExistsInCurrentSchema(conn, physical))) return true;
  const cols = await conn.query(
    `SELECT COLUMN_NAME FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?
        AND COLUMN_NAME IN ('is_locked', 'value_source')`,
    [physical],
  );
  const present = new Set(cols.map((r) => String(r.COLUMN_NAME ?? r.column_name)));
  // No legacy column left to read, or no new column to write into (the ADD was
  // warn-skipped for want of privilege). Either way there is nothing to do, and
  // the drop that follows is itself column-existence guarded.
  if (!present.has('is_locked') || !present.has('value_source')) return true;
  const pending = await conn.query(
    `SELECT 1 FROM \`${physical}\`
      WHERE value_source = 'entered'
        AND (is_locked <> 0 OR compute_rule IS NOT NULL)
      LIMIT 1`,
  );
  return pending.length === 0;
}

/** The three UPDATEs, in DBA-executable form. Same text the executor issues. */
function _legacyValueSourceSql(tableFn) {
  const physical = tableFn(TABLES.BLUEPRINT_FIELDS);
  return [
    `UPDATE \`${physical}\` SET value_source = 'calculated',`
      + " compute_rule = COALESCE(JSON_SET(compute_rule, '$.overridable', false), compute_rule)"
      + " WHERE value_source = 'entered' AND is_locked <> 0 AND compute_rule IS NOT NULL;",
    `UPDATE \`${physical}\` SET value_source = 'calculated'`
      + " WHERE value_source = 'entered' AND (is_locked = 0 OR is_locked IS NULL)"
      + ' AND compute_rule IS NOT NULL;',
    `UPDATE \`${physical}\` SET value_source = 'locked'`
      + " WHERE value_source = 'entered' AND is_locked <> 0 AND compute_rule IS NULL;",
  ];
}

async function _translateLegacyValueSource(ctx) {
  const { conn, t: tableFn, logger: log } = ctx;
  if (await _legacyValueSourceTranslated(conn, tableFn)) return;
  // The three WHERE clauses are mutually exclusive, so order is presentation
  // only; the both-case leads because it is the one carrying a decision.
  const counts = [];
  for (const sql of _legacyValueSourceSql(tableFn)) {
    const res = await conn.query(sql);
    counts.push(Number((res && res.affectedRows) || 0));
  }
  const [lockedAndComputed, computed, locked] = counts;
  if (log && typeof log.info === 'function') {
    log.info(
      { lockedAndComputed, computed, locked },
      'schema migration translated legacy is_locked/compute_rule into value_source',
    );
  }
}

// ── 3.2.629: one field key per blueprint ──────────────────────────────────
//
// The write path probes for a clash inside its own transaction, and that probe
// is the guard on EVERY database — including the ones whose operator account
// cannot run an ALTER. This index is the backstop the probe cannot be: two
// writes claiming one key can both pass their probe, and only the index refuses
// the second.
//
// WHY THIS IS A `custom` ENTRY AND NOT A COLUMN ADD. The registry's structural
// kinds add tables and columns; an index is neither, and the missing-structure
// comparison that drives the remediation workflow cannot see one. So this entry
// carries the pair that convention asks for — a read-only `probe` ("is it
// already there") and a `remediationSql` a DBA can run under a CRUD-only
// account — and the probe is what puts the step in schema/status' pending list.
//
// WHY IT SCANS FIRST. A customer database that already holds duplicate pairs
// cannot take this index, and an unconditional ALTER would raise 1062 on every
// boot there. The step therefore counts the duplicates first and refuses itself
// with the registry's existing deliberate-skip code, which the executor accounts
// as a skip: the version stamp is held back, the audit row says `DATA_GUARD_SKIP`
// rather than an error, and the step stays VISIBLE as pending until a DBA
// resolves the duplicates — at which point the next boot creates the index with
// no further intervention. Returning quietly instead would advance the stamp,
// empty the pending list, and leave the index uncreated forever.

/** Is the index already present (or the table absent, on an infra-only boot)? */
async function _fieldKeyIndexSatisfied(conn, tableFn) {
  const physical = tableFn(TABLES.BLUEPRINT_FIELDS);
  if (!(await tableExistsInCurrentSchema(conn, physical))) return true;
  const rows = await conn.query(
    `SELECT 1 FROM information_schema.STATISTICS
      WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND INDEX_NAME = ?
        AND NON_UNIQUE = 0
      LIMIT 1`,
    [physical, FIELD_KEY_INDEX],
  );
  return rows.length > 0;
}

/** The DBA-executable form. Same statement the step issues at boot. */
function _fieldKeyIndexSql(tableFn) {
  const physical = tableFn(TABLES.BLUEPRINT_FIELDS);
  return [
    `ALTER TABLE \`${physical}\` ADD UNIQUE KEY \`${FIELD_KEY_INDEX}\` (blueprint_id, field_key);`,
  ];
}

async function _addFieldKeyUniqueIndex(ctx) {
  const { conn, t: tableFn, logger: log } = ctx;
  if (await _fieldKeyIndexSatisfied(conn, tableFn)) return;
  const physical = tableFn(TABLES.BLUEPRINT_FIELDS);
  // NULL on either side never collides under a UNIQUE index, so those rows are
  // not duplicates and must not hold the index back.
  const rows = await conn.query(
    `SELECT COUNT(*) AS pairs FROM (
       SELECT blueprint_id, field_key FROM \`${physical}\`
        WHERE blueprint_id IS NOT NULL AND field_key IS NOT NULL
        GROUP BY blueprint_id, field_key
       HAVING COUNT(*) > 1
     ) duplicated`,
  );
  const duplicatePairs = Number((rows[0] && rows[0].pairs) || 0);
  if (duplicatePairs > 0) {
    if (log && typeof log.warn === 'function') {
      // The COUNT only — a field key is authored content, and an audit row is
      // not where it belongs.
      log.warn(
        { duplicatePairs, step: 'blueprint_fields_field_key_unique_index' },
        'unique field-key index not created: this database still holds duplicate '
        + '(blueprint_id, field_key) pairs. The write-path probe refuses new ones; '
        + 'a DBA must resolve the existing ones, after which the next boot creates the index.',
      );
    }
    throw Object.assign(
      new Error(`${duplicatePairs} duplicate (blueprint_id, field_key) pairs present`),
      { code: 'DATA_GUARD_SKIP' },
    );
  }
  await conn.query(
    `ALTER TABLE \`${physical}\` ADD UNIQUE KEY \`${FIELD_KEY_INDEX}\` (blueprint_id, field_key)`,
  );
  if (log && typeof log.info === 'function') {
    log.info({ table: physical, index: FIELD_KEY_INDEX }, 'schema migration added unique index');
  }
}

// ── 3.2.718: repin a placed VM's data-centre cache to the host it stands on ──
//
// A placed VM's data centre IS its host's; `cap_vms.site_id` is a cache of that
// answer, and every write path now keeps the cache equal to the derivation
// (children.js deriveVmSiteFromHost + syncVmSiteCache, placement-apply.js). A row
// written BEFORE those paths were made consistent can hold a `site_id` its host
// contradicts — and the two readers of that column disagree on it: the rule
// preview derives the site from the host (`rule-preview.ts` siteOfVm), the
// evaluator reads the raw column (`evaluator.ts`), so a stale cache makes a
// VM-level rule preview one membership and the evaluation another. The write
// side is already closed; this is the one-time repair of the rows that predate
// it, the boot-time form of the "re-save the host's Site" remedy those comments
// name. scenario-health already SURFACES the divergence (scenarios.js
// staleVmSiteRows); this converges it.
//
// PLACED ROWS ONLY. An UNPLACED VM (`hypervisor_id IS NULL`) owns its `site_id`
// (the operator's intended data centre, with no host to derive from), so it is
// left untouched — mirroring deriveVmSiteFromHost, which derives only when a
// host is named. `cap_hypervisors.site_id` is NOT NULL (table-ddls.js), so a
// placed VM always has a host site to copy.
//
// IDEMPOTENT + VERIFIABLE. The probe counts placed VMs whose cache disagrees
// with their host; a re-run after convergence finds zero and short-circuits. No
// DDL — a pure data UPDATE, so a CRUD-only operator account can run the
// remediationSql form out-of-band.
//
// BYTE-FOR-BYTE PARITY WITH THE WRITE PATH (_shared.js syncVmSiteCache), and both
// halves matter. The JOIN carries `h.scenario_id = v.scenario_id` so a legacy VM
// whose hypervisor_id names a FOREIGN scenario's host is not repinned to that
// host's data centre (the write path skips it; so must this). The comparison is
// `BINARY ... <=> BINARY ...`, not a bare `<=>`: `cap_vms.site_id` is CHAR(36)
// under a case-folding collation, so a case-RESPELLED id (the fmb-1581 shape)
// reads as already-equal to a bare `<=>` and is skipped — invisible to probe,
// run AND remediationSql — while the exact-case readers (capacity-scenario-health
// site-id Set, the evaluator) count it as a dangling reference. Without BINARY
// the stamp would advance and mark this migration complete over rows it never
// touched. The single-source shape below keeps the three statements from
// drifting apart on either predicate.
const _VM_SITE_JOIN_ON = 'h.id = v.hypervisor_id AND h.scenario_id = v.scenario_id';
const _STALE_VM_SITE_PREDICATE = 'v.hypervisor_id IS NOT NULL AND NOT (BINARY v.site_id <=> BINARY h.site_id)';

/** True when nothing awaits repair: the tables are absent (fresh install), or no
 *  placed VM's cached `site_id` disagrees with the host it stands on. */
async function _vmSiteCacheAligned(conn, tableFn) {
  const vms = tableFn(TABLES.CAP_VMS);
  const hvs = tableFn(TABLES.CAP_HYPERVISORS);
  if (!(await tableExistsInCurrentSchema(conn, vms))) return true;
  if (!(await tableExistsInCurrentSchema(conn, hvs))) return true;
  const rows = await conn.query(
    `SELECT COUNT(*) AS n FROM \`${vms}\` v`
    + ` JOIN \`${hvs}\` h ON ${_VM_SITE_JOIN_ON}`
    + ` WHERE ${_STALE_VM_SITE_PREDICATE}`,
  );
  return Number(rows[0] ? rows[0].n : 0) === 0;
}

async function _backfillVmSiteCache(ctx) {
  const { conn, t } = ctx;
  if (await _vmSiteCacheAligned(conn, t)) return;
  const vms = t(TABLES.CAP_VMS);
  const hvs = t(TABLES.CAP_HYPERVISORS);
  await conn.query(
    `UPDATE \`${vms}\` v`
    + ` JOIN \`${hvs}\` h ON ${_VM_SITE_JOIN_ON}`
    + ` SET v.site_id = h.site_id`
    + ` WHERE ${_STALE_VM_SITE_PREDICATE}`,
  );
}

/** DBA-executable form, keyed by the caller's table resolver so no physical
 *  prefix is hardcoded (identifier-via-tables). Same statement text as run(). */
function _backfillVmSiteCacheSql(tableFn) {
  const vms = tableFn(TABLES.CAP_VMS);
  const hvs = tableFn(TABLES.CAP_HYPERVISORS);
  return [
    `UPDATE \`${vms}\` v`
    + ` JOIN \`${hvs}\` h ON ${_VM_SITE_JOIN_ON}`
    + ` SET v.site_id = h.site_id`
    + ` WHERE ${_STALE_VM_SITE_PREDICATE};`,
  ];
}

/** @type {ReadonlyArray<object>} */
const MIGRATION_STEPS = Object.freeze([
  // fmb-1329 T8 (spec §4.6): allowed_hosts was never enforced — the global
  // egress allow-list (system_settings.connector_host_allowlist) is the single
  // outbound host control. Confirmed dead: every read/write code path (dto-mapper,
  // api-connectors/io.js + clone.js, flow-recipes/io.js, connectors.js,
  // flow-dispatch.js, FE types) was removed in the same commit as this entry.
  {
    version: '3.2.579',
    kind: 'drop-column',
    table: TABLES.API_CONNECTORS,
    column: 'allowed_hosts',
    step: 'api_connectors_allowed_hosts_drop',
    severity: 'warning',
  },
  {
    version: '3.2.579',
    kind: 'drop-column',
    table: TABLES.FLOW_RECIPE_STEPS,
    column: 'allowed_hosts',
    step: 'flow_recipe_steps_allowed_hosts_drop',
    severity: 'warning',
  },
  // fmb-1329 T9 (spec §4.6, closes fmb-0757): user_id is superseded by owner_id
  // (backfilled on the earlier ownership migration) — confirmed dead after
  // removing the last read/write surface, sync-schema.js's user_templates
  // TABLE_DEFS.cols entry. idx_user_templates_user_draft is dropped first
  // (composite index on the column being dropped).
  {
    version: '3.2.579',
    kind: 'drop-column',
    table: TABLES.USER_TEMPLATES,
    column: 'user_id',
    step: 'user_templates_user_id_drop',
    severity: 'warning',
    alsoDropIndexes: ['idx_user_templates_user_draft'],
  },
  // fmb-1329 T11 (closes fmb-0533): see _createdAtBackfillEntry doc above.
  _createdAtBackfillEntry({
    table: TABLES.USER_TEMPLATES,
    column: 'created_at',
    step: 'user_templates_created_at_not_null_backfill',
  }),
  _createdAtBackfillEntry({
    table: TABLES.FLOW_RECIPE_RUNS,
    column: 'created_at',
    step: 'flow_recipe_runs_created_at_not_null_backfill',
  }),
  // Cell-level override targeting + blueprint-level field policy. All three are
  // purely additive: each column's default (NULL / FALSE) reproduces the
  // behaviour an existing row already has, so there is nothing to backfill and a
  // DB that warn-skips the ALTER (no DDL privilege) degrades to today's semantics
  // instead of misreading data. severity 'warning' encodes exactly that — a skip
  // is degraded, not failed.
  // `ddl` is byte-compared (modulo whitespace) against the column line in
  // table-ddls.js by the consistency test, so the two can never drift.
  {
    version: '3.2.586',
    kind: 'add-column',
    table: TABLES.VARIANT_OVERRIDES,
    column: 'cell_targets',
    ddl: 'cell_targets JSON NULL',
    step: 'variant_overrides_cell_targets_add',
    severity: 'warning',
  },
  // The is_locked add-column entry that shipped here at 3.2.586 is GONE rather
  // than paired with the drop below. A DB that never ran it does not want the
  // column, and adding it only to drop it two entries later would leave a DB
  // whose operator account lacks DDL privilege carrying a column nothing reads.
  // The drop at 3.2.598 is what reconciles a DB that did run it.
  {
    version: '3.2.586',
    kind: 'add-column',
    table: TABLES.BLUEPRINT_FIELDS,
    column: 'compute_rule',
    ddl: 'compute_rule JSON NULL',
    step: 'blueprint_fields_compute_rule_add',
    severity: 'warning',
  },
  // Decision tables (shared multi-condition lookup). Purely additive: a DB that
  // warn-skips the CREATE (no DDL privilege) simply has no decision tables, and
  // every consumer degrades to "none authored" — the CRUD list mount declares
  // tolerateMissingTableOnList and the cascade-delete service probes for the
  // table before touching it. severity 'warning' encodes exactly that: a skip is
  // degraded, not failed.
  {
    version: '3.2.590',
    kind: 'create-table',
    table: TABLES.DECISION_TABLES,
    step: 'decision_tables_create',
    severity: 'warning',
  },
  // Deliberate-blank markers, the third sparse metadata channel beside
  // field_option_selection and computed_field_overrides. Purely additive: NULL
  // reproduces exactly what an existing row means today (nothing recorded as
  // deliberately emptied), so there is nothing to backfill, and a DB that
  // warn-skips the ALTER for want of DDL privilege degrades to the previous
  // behaviour — a cleared field re-fills on reload — instead of failing writes.
  // severity 'warning' encodes that: a skip is degraded, not failed.
  {
    version: '3.2.593',
    kind: 'add-column',
    table: TABLES.USER_TEMPLATES,
    column: 'cleared_auto_fills',
    ddl: 'cleared_auto_fills TEXT NULL DEFAULT NULL',
    step: 'user_templates_cleared_auto_fills_add',
    severity: 'warning',
  },
  // One value source per field. `value_source` states which of the four
  // field-owned modes fills a field instead of leaving it to be read back out
  // of whichever payload column happened to be populated; `value_scope` gives
  // the blueprint level the cell-scoped targeting only variant overrides had.
  //
  // Both are additive. `value_scope`'s NULL default genuinely reproduces what a
  // pre-existing row meant (the whole field) and needs no backfill.
  //
  // `value_source`'s DOES NOT, and the earlier version of this comment said it
  // did — "both defaults reproduce what a pre-existing row means today" is the
  // sentence the missing translation hid behind. 'entered' reproduces only a row
  // that carried neither a compute_rule nor is_locked=1. Every other row lands
  // on a mode that contradicts the payload beside it: the rule stops applying,
  // the lock is released, and the next save of that field is refused. The
  // translation step below is what carries the legacy state across, and it is
  // ordered between these adds and the is_locked drop for that reason.
  //
  // A DB that warn-skips either ALTER for want of DDL privilege degrades rather
  // than misreads: without `value_source` every field reads as 'entered', so a
  // stored compute rule stops applying until the column lands — reversibly,
  // because nothing has been written. severity 'warning' encodes that; the
  // translation carries the same severity so a skipped ALTER and a skipped
  // translation both hold the stamp back and retry next boot.
  {
    version: '3.2.598',
    kind: 'add-column',
    table: TABLES.BLUEPRINT_FIELDS,
    column: 'value_source',
    ddl: "value_source VARCHAR(32) NOT NULL DEFAULT 'entered'",
    step: 'blueprint_fields_value_source_add',
    severity: 'warning',
  },
  {
    version: '3.2.598',
    kind: 'add-column',
    table: TABLES.BLUEPRINT_FIELDS,
    column: 'value_scope',
    ddl: 'value_scope JSON NULL',
    step: 'blueprint_fields_value_scope_add',
    severity: 'warning',
  },
  // Carry the legacy state across BEFORE the boolean is dropped — see the long
  // note above the helpers for the mapping and the one decision it contains.
  // Ordered between the adds and the drop, and that order is load-bearing in
  // both directions: the column it writes into must exist, and the column it
  // reads must not be gone yet. A partial run that stops here has gained the
  // translation and still has the original.
  {
    version: '3.2.598',
    kind: 'custom',
    step: 'blueprint_fields_value_source_translate_legacy',
    severity: 'warning',
    run: _translateLegacyValueSource,
    probe: _legacyValueSourceTranslated,
    remediationSql: _legacyValueSourceSql,
  },
  // is_locked said the same thing as value_source='locked'. Two columns for one
  // fact is a pair that can disagree, and nothing decides which one wins, so the
  // boolean goes. Confirmed dead: every read and write of it — resolver,
  // authoring form, decision-table eligibility, policy grid, DTO mapper,
  // blueprint export/import and its fingerprint — was removed in the same
  // commit as this entry. Ordered AFTER the two adds so a run that gets partway
  // through has gained the replacement before losing the original.
  {
    version: '3.2.598',
    kind: 'drop-column',
    table: TABLES.BLUEPRINT_FIELDS,
    column: 'is_locked',
    step: 'blueprint_fields_is_locked_drop',
    severity: 'warning',
  },
  // What the operator entered, recorded on the run. Purely additive, and
  // NULL genuinely reproduces what an existing run row means: nothing was
  // captured for it, which is true of every run recorded before this column and
  // cannot be reconstructed afterwards — the values were never stored anywhere.
  // So there is nothing to backfill, and no translation of the kind the
  // value_source entry above needed.
  //
  // add-column rather than custom for the same reason: the shape question this
  // batch has to answer is "does the column exist", not "does an existing row
  // disagree with it". A DB that warn-skips the ALTER for want of DDL privilege
  // degrades rather than fails — the run-begin INSERT probes for the column and
  // re-issues without it, so flows keep running and only the capture is missing,
  // reversibly, until the column lands. severity 'warning' encodes exactly that.
  {
    version: '3.2.614',
    kind: 'add-column',
    table: TABLES.FLOW_RECIPE_RUNS,
    column: 'input_snapshot',
    ddl: 'input_snapshot LONGTEXT NULL DEFAULT NULL',
    step: 'flow_recipe_runs_input_snapshot_add',
    severity: 'warning',
  },
  // Delegated access and the activity trail. Both are purely additive: a
  // database that warn-skips either CREATE for want of DDL privilege has no
  // grants and no trail, and every consumer degrades to exactly today's
  // behaviour — the write and dispatch gates probe for the grants table and fall
  // back to plain ownership when it is absent, and the activity writer drops its
  // row rather than failing the action it was recording. Nothing is misread and
  // nothing is lost that was ever stored, so severity is 'warning': a skip is
  // degraded, not failed, and the stamp is held back so the next boot retries.
  {
    version: '3.2.626',
    kind: 'create-table',
    table: TABLES.DELEGATED_GRANTS,
    step: 'delegated_grants_create',
    severity: 'warning',
  },
  {
    version: '3.2.626',
    kind: 'create-table',
    table: TABLES.TEMPLATE_ACTIVITY,
    step: 'template_activity_create',
    severity: 'warning',
  },
  // See the long note above the helpers: the index is the backstop for the
  // write-path clash probe, and the step refuses itself (visibly) on a database
  // that already holds duplicates rather than failing its boot. severity
  // 'warning' encodes that: a skip is degraded — the probe still refuses every
  // NEW duplicate — not failed.
  {
    version: '3.2.629',
    kind: 'custom',
    step: 'blueprint_fields_field_key_unique_index',
    severity: 'warning',
    run: _addFieldKeyUniqueIndex,
    probe: _fieldKeyIndexSatisfied,
    remediationSql: _fieldKeyIndexSql,
  },
  // Per-entity-type hostname patterns (spec B5a). Purely additive: NULL means
  // "inherited / built-in defaults", exactly what an existing settings row means
  // today, so nothing backfills and a DB that warn-skips the ALTER (no DDL
  // privilege) degrades to today's built-in names instead of failing writes.
  // severity 'warning' encodes that a skip is degraded, not failed.
  {
    version: '3.2.696',
    kind: 'add-column',
    table: TABLES.CAP_SETTINGS,
    column: 'name_patterns',
    ddl: 'name_patterns JSON NULL',
    step: 'cap_settings_name_patterns_add',
    severity: 'warning',
  },
  // Repin every placed VM's stale data-centre cache to its host (data backfill,
  // no DDL). severity 'warning' encodes that a skip is degraded — the write side
  // stays consistent, only the legacy rows wait — not failed.
  {
    version: '3.2.719',
    kind: 'custom',
    step: 'cap_vms_site_id_backfill_from_host',
    severity: 'warning',
    run: _backfillVmSiteCache,
    probe: _vmSiteCacheAligned,
    remediationSql: _backfillVmSiteCacheSql,
  },
  // cap-renumber-lock (spec D1/D5): a locked host is never renamed by
  // renumber. Purely additive; DEFAULT 0 reproduces exactly what every
  // existing row means today (nothing was ever excluded from renumber), so
  // there is nothing to backfill. severity 'warning' matches the convention
  // for every other purely-additive column in this registry: a skipped ALTER
  // (no DDL privilege) holds the stamp back and retries next boot instead of
  // failing it outright.
  {
    version: '3.2.729',
    kind: 'add-column',
    table: TABLES.CAP_HYPERVISORS,
    column: 'name_locked',
    ddl: 'name_locked TINYINT(1) NOT NULL DEFAULT 0',
    step: 'cap_hypervisors_name_locked_add',
    severity: 'warning',
  },
  {
    version: '3.2.729',
    kind: 'add-column',
    table: TABLES.CAP_VMS,
    column: 'name_locked',
    ddl: 'name_locked TINYINT(1) NOT NULL DEFAULT 0',
    step: 'cap_vms_name_locked_add',
    severity: 'warning',
  },
]);

module.exports = {
  MIGRATION_STEPS,
  BASELINE_SCHEMA_VERSION,
  PLATFORM_SCHEMA_VERSION,
};
