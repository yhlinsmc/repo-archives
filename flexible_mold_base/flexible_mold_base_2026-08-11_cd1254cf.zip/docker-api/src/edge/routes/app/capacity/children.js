/**
 * @openapi
 * /edge/app/capacity/scenarios/{scenarioId}/{entity}:
 *   get:
 *     tags: [App - Capacity]
 *     summary: List a scenario's child rows (all authenticated).
 *     parameters:
 *       - { name: scenarioId, in: path, required: true, schema: { type: string } }
 *       - { name: entity, in: path, required: true, schema: { type: string, enum: [sites, hypervisors, databases, vms, db_instances, custom_groups, custom_group_members, rules, waivers] } }
 *     responses:
 *       200: { description: Child rows for the scenario }
 *   post:
 *     tags: [App - Capacity]
 *     summary: Create a child row under the scenario (owner+admin).
 *     responses:
 *       201: { description: Created }
 *       403: { description: Not the scenario owner (and not admin) }
 */

/**
 * capacity/children.js — the scenario-scoped child entity mounts
 * (/scenarios/:scenarioId/{sites|hypervisors|databases|vms|db_instances|
 *  custom_groups|custom_group_members|rules|waivers}). The catalogues
 *  (hardware_specs/disk_combos/teams/vm_profiles/field_defs) are GLOBAL config
 *  (/config/*), referenced not copied (reference model). versions is NOT a
 *  generic child mount — it is served bespoke by versions.js.
 *
 * Each mount reuses the generic createCrudRoutes factory (spec §7): read = all
 * authenticated; write = owner+admin resolved by walking scenario_id →
 * cap_scenarios.owner_id (parentOwnership). bindScenarioScope forces a write
 * body's scenario_id to the URL param and scopes the LIST GET to that scenario;
 * scenario_id is immutable so a PUT cannot move a row across scenarios.
 *
 * NOTE: the single-row GET `/:id` is NOT scenario-scoped — the factory fetches
 * strictly by id and ignores the injected query filter, so a direct id read can
 * cross scenarios. That is acceptable: reads are open to all authenticated users
 * (spec §7). Only the list GET is scenario-filtered.
 *
 * cap_versions is NOT here — versions.js owns it bespoke (server-computed
 * snapshots only + clone), so a client cannot forge a snapshot via the generic
 * child POST.
 *
 * Some mounts carry extra middleware:
 *   - waivers: stampAuditColumns (server-owned created_by audit) +
 *     makeObjectSetKeyGuard (object_set_key column-width guard, fmb-0137).
 *   - every FK-bearing mount: makeScenarioFkLockValidator in the factory's
 *     preWriteInTx (each FK-by-convention column must reference a row in the same
 *     scenario / a valid catalogue row; a db_instance's vm_id must point to a
 *     db_host VM) — run LOCKED (FOR UPDATE) inside the write tx, no unlocked
 *     pre-middleware.
 *   - vms: makeVmTypeFlipLockValidator in preWriteInTx (ap_host-flip guard,
 *     locked so it serialises with a racing db_instance INSERT, fmb-0125).
 */
const { createCrudRoutes } = require('../schema');
const { t } = require('../../../db');
const { TABLES } = require('../../../../shared/constants');
const { apiError } = require('../../../../shared/helpers');
const { deriveInstanceSga } = require('../../../../shared/capacity/sga-defaults');
const { enumColumnsFor } = require('../../../lib/schema-manifest');
const {
  bindScenarioScope, stampAuditColumns, childWriteRoleGate,
  makeScenarioFkLockValidator, makeRuleSitePinLockValidator, makeDcRefsCanonicalizer, makeScenarioExistsGuard, makeRowScenarioBinding,
  makeVmTypeFlipLockValidator, makeObjectSetKeyGuard, makeChildDelete, ruleWriteGuard, makeRulePutMergeGuard,
  makeRuleOverrideUniquenessGuard, makeCustomGroupMemberXorGuard, makeOverrideFillGuard,
  rejectReservedMetadataKeys, makeDiskComboLockValidator, composePreWriteInTx,
  makeScenarioRowLock,
  readFormulaConstants, resolveProfileSizing, makeAppendOrderIndexOnCreate,
  syncVmSiteCache, missingRequiredColumnOnCreate,
  SCENARIO_OWNERSHIP, CHILD_MOUNTS, CHILD_FK_VALIDATIONS, CHILD_DELETE_BEHAVIOR,
} = require('./_shared');
const { resolveHypervisorSiteId } = require('../../../../shared/capacity/vm-site');

// EVERY FK-bearing child mount runs its §17.1a reference-integrity check INSIDE
// the factory's write transaction under a FOR UPDATE lock (the preWriteInTx hook
// below). For a CATALOGUE ref this closes the child-write vs config-delete race
// (514-cand #1 / #629): the referenced global row is held from the check through
// the INSERT/UPDATE, so config.js's guarded DELETE cannot commit a dangling
// reference. fmb-0125 extends the SAME in-tx lock to the SCENARIO-mode FKs of
// db_instances / custom_group_members (vm_id / member_* / group_id): those
// referenced rows are deleted via makeChildDelete's own row-lock transaction, so
// locking them here serialises the two paths and closes the equivalent
// scenario-internal race. No unlocked pre-middleware FK validator remains.

// The child segments that pair a profile FK with a disk_combo_id, and so must run
// the disk-combo allow-list check (spec §5.3, item D) on the RESULTING row of a
// write. Maps the segment to its profile FK column; the disk column is always
// `disk_combo_id`. The check runs INSIDE the factory's write tx (preWriteInTx),
// after the §17.1a catalogue-FK lock, so a partial PUT can load + lock the
// existing row and validate the merged pair. No other child table carries both a
// profile and a disk_combo_id column.
const DISK_COMBO_PROFILE_COLUMN = Object.freeze({
  vms: 'sizing_profile_id',
  databases: 'profile_id',
});

/**
 * Per-segment canonical enum allowlists — the generic factory 400s a
 * non-canonical value (e.g. 'AP_HOST') on POST/PUT instead of relying on the DB's
 * case-insensitive ENUM to silently normalize it.
 *
 * DERIVED FROM THE DDL, NOT LISTED. The three lists that used to live here were
 * hand-copied, and what a hand-copied list gets wrong is not the values it names
 * but the columns it OMITS: the rules mount has four ENUM columns and appeared
 * nowhere, so `type`, `level`, `group_by` and `severity` were written with no
 * declared domain at all. That is one mount where a folded spelling is silently
 * normalised ('Soft' becomes 'soft'), an INTEGER is read as a 1-based member
 * index (`level: 1` is 'hypervisor'), and an unstorable value is a driver error
 * that escapes as a 500 with a stack logged per request rather than the stable
 * 400 every other mount gives. Asking `table-ddls.js` closes those by
 * construction and keeps closing them: a column added to any of these tables
 * arrives with its domain already declared.
 *
 * `enumMembersFor` answers `null` for a column that is not an ENUM — including
 * one whose member list it could not fully parse — so a domain is only declared
 * where the DDL genuinely states one. Nullability is the factory's own concern:
 * it reads the same DDL to decide whether a written NULL is itself a violation,
 * so a nullable enumerated column such as `cap_rules.group_by` keeps accepting
 * the null that means "no grouping".
 */
const CHILD_ENUM_COLUMNS = Object.freeze(Object.fromEntries(
  Object.entries(CHILD_MOUNTS)
    .map(([segment, def]) => [segment, enumColumnsFor(def.table) || {}])
    .filter(([, domains]) => Object.keys(domains).length > 0)
    .map(([segment, domains]) => [segment, Object.freeze(domains)]),
));

// Per-segment IMMUTABLE columns beyond the universal `scenario_id` (spec
// §4.3 B5): `sga_gb` is now derived server-side at wizard create time (by
// role, from the database's Primary/Standby SGA) — the DB Instances grid's
// generic PUT must silently drop any inbound edit (never-block: ignored, not
// rejected), matching the FE column's `readOnly` marking.
//
// `cap_vms.site_id` is NOT on this list, and that is a decision rather than an
// omission — see deriveVmSiteFromHost below. The column is server-derived while
// the VM is PLACED and operator-owned while it is not, and this list cannot say
// "sometimes": it would refuse an unplaced VM's intended site along with a
// placed one's, and a PUT that named nothing else would be refused "no valid
// fields to update" rather than ignored. The hook enforces the same rule per
// row instead.
//
// WHAT THE UNPLACED HALF IS NOT IS A GRID FEATURE. No product surface writes
// this column: the KVMs grid marks it readOnly and the serializer never emits
// it on either verb, and before that column existed the grid had no `site_id`
// field at all. A raw API PUT is the only caller that can reach the door, which
// is a smaller thing than a UI depending on it — but it is also not the reason
// the column is off this list. That reason is the create side: `immutableColumns`
// is PUT-only, so a POST would still have needed the derive hook, and marking
// the column immutable would have bought a second mechanism rather than
// replacing one.
const CHILD_IMMUTABLE_COLUMNS = {
  db_instances: ['sga_gb'],
};

// db_instances CREATE: `sga_gb` is server-derived by role (spec §6.3), never
// client-supplied — the SAME rule the wizard applies and the PUT immutable-
// column strip enforces. A generic POST (Grid Add Row) omits it, so the DB
// default 0 would otherwise stick; a direct POST could forge any value. Derive
// it here IN-TX from the database's Primary/Standby SGA + the scenario-effective
// standby default + (primary only) the database profile's SGA cap. When the
// database/profile context is not resolvable (no database_id / a standalone
// instance / no profile), deriveInstanceSga's own fallback chain applies —
// primary → 0, standby → the settings-or-seed default — the same safe result the
// wizard yields for a database with no tuned SGA and no profile.
// Scenario-effective cap_settings: the scenario's OWN override row wins, else
// the seeded GLOBAL default (spec §9 / §2.4). Single-query resolution reused
// verbatim from violations.js `loadSnapshot` / the scenario settings endpoint —
// `scenario_id IS NULL` sorts LAST so a scenario-local row is preferred. Keeps
// the derivation's formula constants + standby default in step with the
// scenario the instance belongs to, not just the global defaults.
async function loadScenarioEffectiveSettings(conn, scenarioId) {
  const rows = await conn.query(
    `SELECT * FROM \`${t(TABLES.CAP_SETTINGS)}\` WHERE scenario_id = ? OR scenario_id IS NULL`
    + ` ORDER BY scenario_id IS NULL LIMIT 1`,
    [scenarioId],
  );
  return rows[0] || null;
}

async function deriveDbInstanceSgaOnCreate(conn, req, data) {
  const role = data.role;
  const databaseId = data.database_id != null ? data.database_id : null;

  let database = null;
  if (databaseId != null) {
    // A HELD LOCK DOES NOT MAKE A PLAIN READ SEE THE ROW IT LOCKS. The §17.1a
    // preWriteInTx validator took this database_id row FOR UPDATE just above
    // (CHILD_FK_VALIDATIONS.db_instances, mode 'scenario'), which stops anyone
    // ELSE changing its SGA from here to commit — but under REPEATABLE READ a
    // NON-locking SELECT still answers from this transaction's read view, opened
    // at its first consistent read (an editor's entitlement + ownership probes,
    // before this hook). A concurrent Primary/Standby SGA edit committing in that
    // window would then be read as the OLD value and derived into this NEW
    // instance's sga_gb permanently — and there is no cascade to repair it,
    // because the row did not exist when that edit ran cascadeDbSgaToInstances.
    // So the read is LOCKING: it re-acquires the row the validator already holds
    // (byte-identical lock set, no new lock-order edge) and, being a locking
    // read, answers from the latest committed version rather than the snapshot.
    const dbRows = await conn.query(
      `SELECT primary_sga_gb, standby_sga_gb, profile_id FROM \`${t(TABLES.CAP_DATABASES)}\` WHERE id = ? LIMIT 1 FOR UPDATE`,
      [databaseId],
    );
    database = dbRows[0] || null;
  }

  // Scenario-effective settings (scenario override, else global): the standby
  // default + the SGA formula constants, resolved for THIS scenario.
  const settings = await loadScenarioEffectiveSettings(conn, data.scenario_id);

  // Primary only: the database profile's SGA cap (DB-class formula), else 0.
  let profile = null;
  if (role !== 'standby' && database && database.profile_id != null) {
    const profRows = await conn.query(
      `SELECT * FROM \`${t(TABLES.CAP_VM_PROFILES)}\` WHERE id = ? LIMIT 1`,
      [database.profile_id],
    );
    const profileRow = profRows[0] || null;
    const sizing = profileRow ? resolveProfileSizing(profileRow, readFormulaConstants(settings)) : null;
    profile = { sgaCapGb: sizing && sizing.sgaCapGb != null ? sizing.sgaCapGb : 0 };
  }

  data.sga_gb = deriveInstanceSga(role, database, settings, profile);
  return data;
}

// databases UPDATE cascade (spec §6 / phase-7 item 6): a db_instance's `sga_gb`
// is server-derived and immutable via the generic PUT (CHILD_IMMUTABLE_COLUMNS),
// so editing a database's Primary/Standby SGA must re-derive the persisted
// `sga_gb` of its EXISTING child instances — otherwise the FE refetch returns
// byte-identical data and the KVMs "SGA Ref" never moves. Runs in the factory's
// postUpdateInTx hook: AFTER the ownership-scoped UPDATE matched a row (an
// unauthorized PUT 404s before this fires) and inside the SAME tx, so the parent
// write and the child re-derive commit atomically. Scoped to the two SGA
// columns and only their `sga_gb` on the touched role. The FE grid re-sends
// every non-readOnly cell on ANY row change (a rename reaches here too), so the
// cascade compares the derived value against the stored one and writes NOTHING
// when unchanged — no UPDATE, no updated_at churn.
async function cascadeDbSgaToInstances(conn, req, data) {
  const touchesPrimary = Object.prototype.hasOwnProperty.call(data, 'primary_sga_gb');
  const touchesStandby = Object.prototype.hasOwnProperty.call(data, 'standby_sga_gb');
  if (!touchesPrimary && !touchesStandby) return;

  const databaseId = req.params.id;
  // The parent UPDATE already applied within THIS tx, so this re-reads the NEW
  // Primary/Standby SGA (plus profile_id + scenario_id for the derivation).
  const dbRows = await conn.query(
    `SELECT primary_sga_gb, standby_sga_gb, profile_id, scenario_id FROM \`${t(TABLES.CAP_DATABASES)}\` WHERE id = ? LIMIT 1`,
    [databaseId],
  );
  const database = dbRows[0] || null;
  if (!database) return;

  // Scenario-effective settings (scenario override, else global) — the standby
  // default + SGA formula constants, exactly as deriveDbInstanceSgaOnCreate.
  const settings = await loadScenarioEffectiveSettings(conn, database.scenario_id);

  // Primary only: the database profile's SGA cap (DB-class formula), else 0 —
  // reused verbatim from the create-time derivation so a re-derive matches what
  // a freshly created instance would have received.
  let profile = null;
  if (touchesPrimary && database.profile_id != null) {
    const profRows = await conn.query(
      `SELECT * FROM \`${t(TABLES.CAP_VM_PROFILES)}\` WHERE id = ? LIMIT 1`,
      [database.profile_id],
    );
    const profileRow = profRows[0] || null;
    const sizing = profileRow ? resolveProfileSizing(profileRow, readFormulaConstants(settings)) : null;
    profile = { sgaCapGb: sizing && sizing.sgaCapGb != null ? sizing.sgaCapGb : 0 };
  }

  // Lock the child instances FOR UPDATE (with their current sga_gb) so a
  // concurrent db_instance INSERT — which derives its own sga_gb from the same
  // database row — serialises with this re-derive rather than racing it, and so
  // the compare-then-write below is consistent within the tx.
  const instances = await conn.query(
    `SELECT role, sga_gb FROM \`${t(TABLES.CAP_DB_INSTANCES)}\` WHERE database_id = ? FOR UPDATE`,
    [databaseId],
  );

  // Re-derive only the role whose SGA column changed: primary_sga_gb → primary
  // instances, standby_sga_gb → standby. All instances of one role derive the
  // SAME value (role + database + settings + profile are constant), so ONE
  // batched UPDATE per touched role suffices — issued only when at least one
  // stored row of that role differs, with `sga_gb <> ?` narrowing the write to
  // the rows that actually change (no needless updated_at churn).
  const rolesToDerive = [];
  if (touchesPrimary) rolesToDerive.push('primary');
  if (touchesStandby) rolesToDerive.push('standby');
  for (const role of rolesToDerive) {
    const newSga = deriveInstanceSga(role, database, settings, profile);
    const needsUpdate = instances.some(
      (inst) => inst.role === role && Number(inst.sga_gb) !== Number(newSga),
    );
    if (!needsUpdate) continue;
    await conn.query(
      `UPDATE \`${t(TABLES.CAP_DB_INSTANCES)}\` SET sga_gb = ? WHERE database_id = ? AND role = ? AND sga_gb <> ?`,
      [newSga, databaseId, role, newSga],
    );
  }
}

// vms CREATE and UPDATE: a placed VM's data centre IS its host's, so whenever
// this write leaves the VM standing on a host, the derived `cap_vms.site_id` is
// written in the SAME statement (spec §5.3; the rule itself lives in
// shared/capacity/vm-site.js, which every reader of the column now asks).
//
// BOTH VERBS THROUGH ONE HOOK, deliberately. `preWriteInTx` runs on POST and on
// PUT, and the two used to be able to disagree: the create stored whatever
// `site_id` the caller sent beside a `hypervisor_id`, and the update wrote
// `hypervisor_id` alone and left the column naming the DC the VM had just left.
// Injecting into `data` before the SET/column list is built makes the cache and
// the placement ONE statement — so the row is never briefly self-contradictory
// and the response body the grid re-renders from already carries the new DC.
//
// IT IS ALSO THE GATE, and it is a per-ROW one, which is why `site_id` is not on
// CHILD_IMMUTABLE_COLUMNS. The question "may this caller set the column" has two
// answers on this mount: for a PLACED VM the host owns it and a hand-set value
// is silently replaced by the derived one (never-block: ignored, not rejected —
// the treatment `sga_gb` established); for an UNPLACED VM the column IS the
// operator's intended site, so the write stands. The row's own `hypervisor_id`
// decides, taken from this write when it carries one and from the stored row
// when it does not — otherwise a PUT of `site_id` alone would slip past by
// simply not mentioning the placement.
//
// THE UNPLACED DOOR HAS NO CALLER IN THE PRODUCT, and saying otherwise would be
// the load-bearing part of this comment being false. The KVMs grid renders the
// column readOnly and `gridRowToPayload` drops it on both verbs; nothing else
// writes `cap_vms.site_id` through this mount. A direct API PUT is the only way
// through, which is a door worth leaving open — an unplaced VM's intended site
// is a real value with no other home — but it is not a door the UI walks
// through today.
//
// An UNPLACE (`hypervisor_id: null`) leaves the column alone on purpose: there
// is no host left to derive from, and what remains is the DC the VM was last in
// — the only statement of where it is meant to go.
//
// Runs AFTER the §17.1a FK validator in the compose order, so `hypervisor_id` is
// already the STORED spelling and its row is already locked FOR UPDATE.
//
// A HELD LOCK DOES NOT MAKE A PLAIN READ SEE THE ROW IT LOCKS, and that is why
// EVERY read below is a locking one. This block used to say the read was
// "consistent within the tx" because the FK validator had locked the row, and
// that is two different guarantees run together. The lock stops anyone ELSE
// changing the host from here to commit; under REPEATABLE READ a non-locking
// SELECT still answers from this transaction's read view, taken at its FIRST
// consistent read. So a host Site change committing in between was read as the
// data centre the host had just LEFT, and the cascade that would have repaired
// it had run against a row this transaction had not written yet. Measured on
// MariaDB 10.11 on BOTH verbs, and the roles do not behave alike: which read
// opens the view is what decides, and `admin` and `editor` — this mount's
// `allowedRoles` — do not take the same reads before the hook. An editor's PUT
// runs the entitlement probe and two ownership reads first (crud-factory.js),
// so its view is already fixed; an administrator's takes none of them and the
// hook's own read opens it. Both interleavings are driven in
// capacity-lock-order-real-db.test.js, per role, asserting the stored value.
//
// WHICH LEAVES ONE ROW TO ASK, NOT TWO. The write that names a host asks the
// HOST — the row the FK validator has already taken FOR UPDATE, so re-reading
// it under that lock acquires nothing and the lock set is byte-identical. The
// partial PUT that names only the data centre asks THIS ROW instead, in the
// same locking read that tells it whether the VM is placed at all: for a placed
// VM the host owns the column, so the value that stands is the one the row
// already holds — whatever the placement move or the host cascade last wrote —
// and holding that row from the read to commit is what makes it current.
//
// IT DOES NOT REACH FOR THE HOST ON THAT BRANCH, deliberately. The host id
// there comes out of `cap_vms`, a row the FK validator never saw, so locking it
// would take `cap_hypervisors` AFTER `cap_vms` — the inversion
// reference-integrity.js's order exists to prevent, and the one that cost this
// mount a deadlock already. Reading it WITHOUT a lock is the staleness above.
// Asking the row itself needs neither.
//
// IT WRITES THE VALUE BACK RATHER THAN DROPPING THE KEY, because a PUT whose
// only key is dropped leaves nothing to update and the factory answers 400 "No
// valid fields to update". The treatment this mount chose is ignore, not
// reject.
//
// WHAT IT THEREFORE DOES NOT DO is repair a row whose cache already contradicts
// its host: it keeps what is stored rather than re-deriving, and the caller's
// value is not taken either. Both refusals are the same rule — for a PLACED VM
// this column is the host's, so the only thing a partial PUT can honestly leave
// standing is what the placement last wrote — and both are IGNORE rather than
// REJECT, the treatment this mount chose.
//
// ROWS ARE IN THAT STATE, and saying they can only predate this mount would be
// false. They were also written BY THIS DERIVE, while it answered from a read
// view instead of the row: a host Site edit committing between the read view
// opening and the derive was enough, which is two ordinary concurrent edits and
// is the interleaving driven in capacity-lock-order-real-db.test.js. That hole
// is closed here, so no new ones appear; the ones already stored are a
// backfill's job, and the stated remedy is a no-op re-save of the host's Site,
// which repins every VM standing on it.
//
// AND NOTHING REACHES THE "the host resolved to no data centre" BRANCH BELOW.
// `cap_hypervisors.site_id` is NOT NULL (table-ddls.js) and the §17.1a
// validator has already refused a `hypervisor_id` naming no in-scenario row, so
// a placed VM always has a data centre to derive; that branch answers a lagging
// schema, not a state a caller can produce. Both premises are pinned in
// capacity-vm-site-real-db.test.js so a nullable column would go red here
// rather than quietly turn the branch live.
async function deriveVmSiteFromHost(conn, req, data, ctx) {
  const namesHost = Object.prototype.hasOwnProperty.call(data, 'hypervisor_id');
  const namesSite = Object.prototype.hasOwnProperty.call(data, 'site_id');
  if (!namesHost && !namesSite) return null;

  if (!namesHost) {
    // A partial PUT that names only the DC. The placement it will leave the row
    // in is the one the row already has, and so is the cache it will leave
    // standing — one locking read answers both, and the lock it takes is the
    // one the UPDATE below needs anyway.
    if (!ctx || !ctx.isUpdate || ctx.id == null) return null;
    const cur = await conn.query(
      `SELECT hypervisor_id, site_id FROM \`${t(TABLES.CAP_VMS)}\` WHERE id = ? FOR UPDATE`,
      [ctx.id],
    );
    // No row (the scoped UPDATE below will answer 404), or an UNPLACED VM whose
    // column IS the operator's intended site: the caller's value stands.
    if (!cur.length || cur[0].hypervisor_id == null) return null;
    data.site_id = cur[0].site_id;
    return null;
  }

  if (data.hypervisor_id == null) return null;
  const rows = await conn.query(
    `SELECT site_id FROM \`${t(TABLES.CAP_HYPERVISORS)}\` WHERE id = ? LIMIT 1 FOR UPDATE`,
    [data.hypervisor_id],
  );
  const siteId = resolveHypervisorSiteId(rows[0]);
  // No row, or a host with no DC of its own: the FK validator that ran just
  // above already refused a hypervisor outside this scenario, so reaching here
  // means a lagging schema or a genuinely site-less host. Deriving nothing is
  // the honest answer; overwriting the cache with NULL would not be.
  if (siteId == null) return null;
  data.site_id = siteId;
  return null;
}

// hypervisors UPDATE cascade: a host moved to another data centre takes the VMs
// standing on it along. The VMs do not move — the DC they are in changes under
// them — and nothing used to notice, so every VM on that host went on naming a
// data centre it was no longer in.
//
// Runs in postUpdateInTx (mirroring the databases→instances SGA cascade): AFTER
// the ownership-scoped UPDATE matched a row, so an unauthorized PUT never
// triggers it, and inside the SAME tx so the host's move and its VMs' cache
// commit or roll back together. `syncVmSiteCache` compares before it writes, so
// a host edit that does not change the DC touches no VM row at all.
//
// LOCK ORDER — WHAT THIS GUARANTEES AND WHAT IT DOES NOT.
//
// It guarantees the order. Running the cascade AFTER the factory's own UPDATE
// means this mount claims `cap_hypervisors` and then `cap_vms`, which is the
// order reference-integrity.js's comparator states and the order every child
// mount already takes: the vms POST and the vms PUT both lock the referenced
// hypervisor through the §17.1a check before touching the vm row. A host edit
// racing any KVM create or KVM edit on the same estate therefore serialises —
// whichever reaches the hypervisor row first, the other simply waits. Pinned in
// capacity-lock-order-real-db.test.js, which asserts on the ENGINE'S ERRNO
// rather than on a status code, because the factory maps a deadlock and a lock
// wait to the same 409.
//
// It NO LONGER cycles with the staged placement Save either — though the fix
// for that lives in the other handler, not here. That handler USED to claim the
// moved `cap_vms` rows first and the hypervisors they move onto second — the
// opposite order — so a host Site edit granted the host row first could meet a
// Save holding one of those VMs and waiting for that same host. It now acquires
// the target hypervisors FOR UPDATE before any `cap_vms` row (its canonical
// lock-order anchor, placement-apply.js), so both writers take the two tables in
// one order and whichever reaches a host row first, the other simply waits.
// Both grant orders, the within-host-reorder variant and the off-host
// non-contending case are driven in capacity-lock-order-real-db.test.js.
//
// It is priced the same on both sides now, too: `placement-apply.js` maps errno
// 1213/1205 to the same retryable 409 WRITE_CONFLICT this factory does through
// writeConflictError, so a Save chosen as the victim is told to retry rather
// than surfacing a bare 500.
//
// Nothing on THIS mount could ever have closed the cycle: there is no order this
// cascade can take that agrees with both the child mounts and a handler that
// disagrees with them, which is exactly why the fix had to be the placement
// Save's lock order.
//
// AN EARLIER ATTEMPT INVERTED THIS MOUNT INSTEAD, claiming the host's VMs in a
// pre-write hook so the order matched the placement Save's. It removed those
// two shapes and created four commoner ones: the mount then took `cap_vms`
// before AND after `cap_hypervisors`, so it inverted against the vms POST and
// the vms PUT as well — an ordinary KVM edit, or a KVM create, refused 409
// whenever any host's Site was being saved on the same estate. Its own
// `SELECT id ... WHERE hypervisor_id = ? FOR UPDATE` also gap-locked the index
// range for a host with NO VMs, so the create case did not even need the host
// to be occupied. Measured on MariaDB 10.11: five deadlocking pairs with it,
// two without.
async function cascadeHypervisorSiteToVms(conn, req, data) {
  if (!Object.prototype.hasOwnProperty.call(data, 'site_id')) return;
  const hypervisorId = req.params.id;
  // The parent UPDATE already applied within THIS tx, so this reads the NEW site
  // — and the scenario from the row rather than from the request, which is the
  // scope every statement below is bound by.
  const rows = await conn.query(
    `SELECT scenario_id FROM \`${t(TABLES.CAP_HYPERVISORS)}\` WHERE id = ? LIMIT 1`,
    [hypervisorId],
  );
  if (!rows.length) return;
  await syncVmSiteCache(conn, rows[0].scenario_id, { hypervisorId });
}

// Chain in-tx CREATE transforms left→right on the SAME write connection: each
// receives the prior's returned `data`. Used to layer the phase-4 append
// order_index assignment on top of db_instances' existing role-derived sga_gb
// transform.
function chainCreateTransforms(...fns) {
  return async (conn, req, data) => {
    let out = data;
    for (const fn of fns) out = await fn(conn, req, out);
    return out;
  };
}

// Per-segment in-tx CREATE transform (schema factory `transformCreateInTx`).
// The reorderable entities (sites / hypervisors / vms / db_instances / databases,
// spec §6) append a grid-added row at the END of the scenario's order
// (order_index = MAX+1). All use the SAME lock-free append (makeAppendOrderIndexOnCreate):
// the scenario-row serialisation that stops two concurrent appends colliding on
// an index comes from makeScenarioRowLock (preWriteInTx, fmb-1685) for the mounts
// that carry it (sites / databases / db_instances) and from the FK-row locks for
// the rest — see makeAppendOrderIndexOnCreate for the deadlock rationale. sites
// used to take its OWN scenario FOR UPDATE inside the transform; once the hook
// landed that became a second, redundant acquisition, so it was collapsed to one.
const CHILD_CREATE_TRANSFORM = {
  db_instances: chainCreateTransforms(
    deriveDbInstanceSgaOnCreate, makeAppendOrderIndexOnCreate(TABLES.CAP_DB_INSTANCES),
  ),
  sites: makeAppendOrderIndexOnCreate(TABLES.CAP_SITES),
  hypervisors: makeAppendOrderIndexOnCreate(TABLES.CAP_HYPERVISORS),
  vms: makeAppendOrderIndexOnCreate(TABLES.CAP_VMS),
  // phase-6 spec §D8: a grid-added Database lands at the END of the scenario's
  // order (order_index = MAX+1), mirroring the other reorderable child entities.
  databases: makeAppendOrderIndexOnCreate(TABLES.CAP_DATABASES),
};

// The child mounts whose rows the renumber apply reads WITHOUT a row lock:
// db_instances + databases feed readHostFunctionRoles (role / {function}
// resolution), sites feeds readSiteNames (the {dc} slug). Their CREATE/UPDATE
// must serialise on the scenario row so apply never computes hostnames from a
// role / placement / function / site change that commits mid-apply. DELETE,
// reorder and placement-apply already lock the scenario row; the generic
// CREATE/UPDATE path did not (renumber.js CONCURRENCY note, fmb-1685).
const SCENARIO_LOCK_ON_WRITE_SEGMENTS = new Set(['sites', 'databases', 'db_instances']);

// Per-segment in-tx post-UPDATE cascade (schema factory `postUpdateInTx`). Only
// databases opts in: a Primary/Standby SGA edit re-derives the persisted
// `sga_gb` of the database's existing child db_instances (phase-7 item 6).
const CHILD_POST_UPDATE_TRANSFORM = {
  databases: cascadeDbSgaToInstances,
  hypervisors: cascadeHypervisorSiteToVms,
};

// Per-segment numeric column guards (schema factory `valueGuards`). A database's
// Primary/Standby SGA is a nullable DOUBLE with no CHECK constraint; the SGA
// cascade above is the first path propagating either value into EXISTING child
// rows, so a negative/NaN/non-numeric write is rejected (400) at the mount
// before it can persist or cascade. `integer` carries the operator's rule that
// SGA is accepted as whole numbers only (fmb-1433) onto the raw-API half of this
// mount — the grid refuses a fractional cell, but nothing forces a caller
// through the grid. Null stays valid (means "unset → derive").
// cap-renumber-lock (spec D1/D5): name_locked is writable on both host
// entities via the generic PATCH/PUT; the boolean guard refuses a non-boolean
// value (400) before it reaches mapRowToDb's lenient 1/0/'true' coercion.
const CHILD_VALUE_GUARDS = {
  databases: {
    primary_sga_gb: { numeric: { min: 0, allowNull: true, integer: true } },
    standby_sga_gb: { numeric: { min: 0, allowNull: true, integer: true } },
  },
  hypervisors: {
    name_locked: { boolean: { allowNull: false } },
  },
  vms: {
    name_locked: { boolean: { allowNull: false } },
  },
};

// Child entities that carry a server-owned `created_by` audit column.
const AUDIT_STAMPED_SEGMENTS = new Set(['waivers']);

/**
 * POST-only pre-middleware: a CREATE that omits a column `table` declares
 * NOT NULL with no default is refused 400 COLUMN_REQUIRED naming the column,
 * instead of reaching the database's own NOT NULL violation (fmb-1549: that
 * fell through the generic catch to a 500 naming no column at all).
 * `missingRequiredColumnOnCreate` derives the required set from `table-ddls.js`
 * for every column type, so a table's column added later is covered by
 * construction rather than needing a second hand-picked entry here.
 *
 * MUST run after every pre-step that FILLS a required column server-side —
 * `bindScenarioScope` (scenario_id), `makeOverrideFillGuard` (rules' type/
 * name/level on an override create) — so this sees the body those steps
 * produce, not the caller's raw one. It is registered after both in the
 * `pre` array below.
 */
function makeRequiredColumnGuard(table) {
  return function requiredColumnGuard(req, res, next) {
    if (req.method !== 'POST') return next();
    const missing = missingRequiredColumnOnCreate(table, Object.keys(req.body || {}), req.body || {});
    if (missing) {
      const e = apiError(missing, 'COLUMN_REQUIRED', 400);
      return res.status(e.status).json(e.body);
    }
    return next();
  };
}

/**
 * Mount every scenario-scoped child router onto the capacity router under
 * `/scenarios/:scenarioId/<segment>`.
 * @param {import('express').Router} capacityRouter
 */
function mountChildren(capacityRouter) {
  for (const [segment, def] of Object.entries(CHILD_MOUNTS)) {
    const pre = [];
    // Role gate FIRST: a write by a non-admin/editor is refused before any of the
    // DB-touching pre-guards below run (reads stay open).
    pre.push(childWriteRoleGate);
    pre.push(bindScenarioScope);
    // Reject a reserved prototype key in a body.metadata payload (no-op when the
    // mount/body carries no metadata) — the raw-API half of the reject-at-the-source
    // invariant io.js buildMetadata enforces for bulk import.
    pre.push(rejectReservedMetadataKeys);
    // rules: POST override rows omit the NOT NULL identity columns — fill them
    // from the referenced global rule BEFORE anything judges the body.
    //
    // THE ORDER IS THE FIX. This ran last, after ruleWriteGuard: the body
    // carried no `type`, so the per-type legality check was skipped entirely,
    // and the fill then supplied a canonical type from the target rule. Both the
    // filled type and the client's own `level` are legal ENUM members, so the
    // database accepted a rule whose type takes only `hypervisor` while its
    // level said `db_instance` — no error, no 500, a landed row the evaluator
    // never matches and that any later PUT resending the type is 400'd for. The
    // validator now sees the body the statement will write.
    if (segment === 'rules') pre.push(makeOverrideFillGuard());
    // Bound a rule write's scope/params (condition count + JSON size) — a
    // never-block engine cannot reject at eval time, so the stored rule is capped.
    if (segment === 'rules') pre.push(ruleWriteGuard);
    if (AUDIT_STAMPED_SEGMENTS.has(segment)) pre.push(stampAuditColumns);
    // POST: refuse cheaply (400 COLUMN_REQUIRED) a create that omits a
    // DDL-required column, before any DB round trip. Placed after every step
    // above that fills a required column server-side (bindScenarioScope,
    // makeOverrideFillGuard) so it judges the body those steps produce.
    pre.push(makeRequiredColumnGuard(def.table));
    // POST: the URL scenario must exist (admin bypasses parentOwnership → guard here).
    pre.push(makeScenarioExistsGuard());
    // PUT: the target row must belong to this scenario (404 on cross-scenario).
    pre.push(makeRowScenarioBinding(def.table));
    // PUT: re-validate a partial rule update's MERGED level/group_by legality —
    // ruleWriteGuard only sees the body, so a `{ level }`-only PUT would bypass
    // the per-type check (reads the stored row → merges → re-checks).
    if (segment === 'rules') pre.push(makeRulePutMergeGuard());
    // POST/PUT: a custom group member references exactly one of member_vm_id /
    // member_instance_id (XOR) — merged with the stored row on a partial PUT.
    if (segment === 'custom_group_members') pre.push(makeCustomGroupMemberXorGuard());
    // waivers: reject an oversized object_set_key before it is silently
    // truncated to the column width (fmb-0137) — corrupting the deterministic
    // waiver-match key.
    if (segment === 'waivers') pre.push(makeObjectSetKeyGuard());
    // PUT: a cap_vms vm_type flip to ap_host with existing DB instances → 409.
    // Runs LOCKED inside the factory write tx (preWriteInTx below), NOT here, so
    // it serialises with a concurrent db_instance INSERT (fmb-0125).
    // Cross-entity reference-integrity checks (§17.1a) likewise run LOCKED in the
    // write tx for EVERY FK-bearing mount (see the preWriteInTx opt below) — no
    // unlocked pre-middleware FK validator is added here.
    // rules: at most one override row per (scenario, overrides_rule_id) — 409.
    if (segment === 'rules') pre.push(makeRuleOverrideUniquenessGuard());
    // DELETE: dependent-aware, transactional (handled fully ahead of the factory).
    pre.push(makeChildDelete(def.table, CHILD_DELETE_BEHAVIOR[segment] || {}));
    capacityRouter.use(
      `/scenarios/:scenarioId/${segment}`,
      ...pre,
      createCrudRoutes(def.table, {
        allowedRoles: ['admin', 'editor'],
        parentOwnership: SCENARIO_OWNERSHIP,
        filterableColumns: def.filterableColumns,
        // A PUT must never reparent a row to another scenario; the factory
        // strips scenario_id from the UPDATE for every role. Segment-specific
        // additions (e.g. db_instances.sga_gb) layer on top.
        immutableColumns: ['scenario_id', ...(CHILD_IMMUTABLE_COLUMNS[segment] ?? [])],
        // Server-derive/assign a column on CREATE in-tx (db_instances.sga_gb by
        // role; sites.order_index append) — see the helpers above.
        ...(CHILD_CREATE_TRANSFORM[segment] ? { transformCreateInTx: CHILD_CREATE_TRANSFORM[segment] } : {}),
        // Cascade a column re-derive on UPDATE in-tx (databases SGA edit →
        // child db_instances.sga_gb) — see cascadeDbSgaToInstances above.
        ...(CHILD_POST_UPDATE_TRANSFORM[segment] ? { postUpdateInTx: CHILD_POST_UPDATE_TRANSFORM[segment] } : {}),
        // Reject a non-canonical enum value (e.g. 'AP_HOST') with a 400.
        ...(CHILD_ENUM_COLUMNS[segment] ? { enumColumns: CHILD_ENUM_COLUMNS[segment] } : {}),
        // Numeric column guards (databases SGA finite ≥ 0) — reject a bad value
        // with a 400 before it persists or cascades.
        ...(CHILD_VALUE_GUARDS[segment] ? { valueGuards: CHILD_VALUE_GUARDS[segment] } : {}),
        // rules: the DB UNIQUE index (scenario_id, overrides_rule_id) is the race
        // backstop for the friendly override pre-check — map its 1062 to 409.
        ...(segment === 'rules'
          ? { mapDuplicateKey: { code: 'CONFLICT', message: 'An override for this rule already exists in this scenario' } }
          : {}),
        // custom_group_members: the DB UNIQUE indexes (group_id, member_vm_id) /
        // (group_id, member_instance_id) backstop a duplicate-member write — map
        // their 1062 to 409 (the member is already in the group).
        ...(segment === 'custom_group_members'
          ? { mapDuplicateKey: { code: 'CONFLICT', message: 'This member is already in the group' } }
          : {}),
        // In-tx pre-write guards, all under a FOR UPDATE lock on THIS write
        // connection (see the CATALOGUE_FK note above):
        //   - §17.1a reference-integrity on every FK-bearing mount (catalogue AND
        //     scenario-mode refs — fmb-0125), so a referenced row is held from the
        //     check through the INSERT/UPDATE.
        //   - vms / databases: the disk-combo allow-list check (spec §5.3) on the
        //     merged resulting row, after the FK lock.
        //   - vms: the ap_host-flip guard, locking the vm row so it serialises with
        //     a concurrent db_instance INSERT (fmb-0125).
        ...(() => {
          const hooks = [];
          // FIRST — serialise the write on the scenario row (before the §17.1a FK
          // locks) for the mounts renumber apply reads unlocked, so apply never
          // renames from a concurrently-committed role/function/placement/site
          // change. Taken first it is the single universally-first lock and adds
          // no deadlock edge — see makeScenarioRowLock / SCENARIO_LOCK_ON_WRITE_SEGMENTS.
          if (SCENARIO_LOCK_ON_WRITE_SEGMENTS.has(segment)) {
            hooks.push(makeScenarioRowLock());
          }
          if (CHILD_FK_VALIDATIONS[segment]) {
            hooks.push(makeScenarioFkLockValidator(CHILD_FK_VALIDATIONS[segment]));
          }
          // rules: validate + FOR UPDATE-lock the pinned site (params.site_id), a
          // reference that lives inside the params JSON blob (not a scalar FK, so
          // absent from CHILD_FK_VALIDATIONS above). Runs AFTER the scalar-FK lock
          // so cap_sites is taken after cap_custom_groups / cap_rules — the
          // canonical table order. Closes the pin-write vs site-delete race and the
          // dangling-pin creation path (site-references.js / fmb-1538).
          if (segment === 'rules') hooks.push(makeRuleSitePinLockValidator());
          if (DISK_COMBO_PROFILE_COLUMN[segment]) {
            hooks.push(makeDiskComboLockValidator(def.table, DISK_COMBO_PROFILE_COLUMN[segment]));
          }
          if (segment === 'vms') hooks.push(makeVmTypeFlipLockValidator());
          // databases: rebind each dc_refs JSON-list entry to the spelling its
          // cap_sites row holds — the list counterpart of the scalar site_id
          // rebind the §17.1a validator above does, so a case-/pad-variant of a
          // real site id is stored as the site's own id and the byte-comparison
          // readers resolve it (site-references.js top note).
          if (segment === 'databases') hooks.push(makeDcRefsCanonicalizer());
          // LAST, so the §17.1a validator above has already canonicalised
          // `hypervisor_id` to the spelling its row holds and locked that row.
          if (segment === 'vms') hooks.push(deriveVmSiteFromHost);
          return hooks.length ? { preWriteInTx: composePreWriteInTx(...hooks) } : {};
        })(),
      }),
    );
  }
}

module.exports = { mountChildren, cascadeDbSgaToInstances };
