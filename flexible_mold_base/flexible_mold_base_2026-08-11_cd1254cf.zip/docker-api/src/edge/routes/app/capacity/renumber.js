/**
 * @openapi
 * /edge/app/capacity/scenarios/{scenarioId}/renumber-preview:
 *   post:
 *     tags: [App - Capacity]
 *     summary: Preview the old→new hostname renumber for a scenario (admin+editor).
 *     description: >
 *       Spec B5 Q18/Q20. Read-only. Recomputes every hypervisor / KVM-host /
 *       AP-VM name from the scenario's EFFECTIVE naming patterns (scenario
 *       override → global → built-in defaults) in current `order_index` display
 *       order, and returns the full old→new list. No writes.
 *     parameters:
 *       - { name: scenarioId, in: path, required: true, schema: { type: string } }
 *     responses:
 *       200: { description: "The old→new plan: [{ id, entityType, oldName, newName, tooLong, duplicate }]" }
 *       403: { description: Not the scenario owner (and not admin), or a plain user }
 *       404: { description: Scenario not found }
 * /edge/app/capacity/scenarios/{scenarioId}/renumber:
 *   post:
 *     tags: [App - Capacity]
 *     summary: Apply the hostname renumber for a scenario in one transaction (admin+editor).
 *     description: >
 *       Spec B5 Q18. Recomputes names server-side (never trusts a client-sent
 *       name), enforces scenario-wide per-entity-type uniqueness, and writes
 *       every changed name in ONE transaction — any duplicate rolls the whole
 *       apply back (409), nothing is written. Drag reorder never renames; this
 *       explicit action is the only path that re-sequences names.
 *     parameters:
 *       - { name: scenarioId, in: path, required: true, schema: { type: string } }
 *     responses:
 *       200: { description: "Applied: { applied, renamed: [{ id, entityType, oldName, newName }] }" }
 *       403: { description: Not the scenario owner (and not admin), or a plain user }
 *       404: { description: Scenario not found }
 *       409: { description: The computed names collide within an entity type — nothing applied }
 */

/**
 * capacity/renumber.js — the explicit Renumber toolbar action (spec B5b). Two
 * POST routes on the scenario: a read-only preview and a transactional apply.
 *
 * Numbering (fork-2, wizard-consistent, computeRenumberPlan in
 * shared/capacity/name-patterns.js): group each entity type by its resolved {dc}
 * slug (a {dc}-free pattern = one scenario-wide group), seq 1..k in order_index
 * order, pad width = max(declared, digits(groupCount)). Hand-edited names are
 * renumbered like any other — that is the point of the action.
 *
 * CONCURRENCY. The PRIMARY protection is scenario-row serialization: apply locks
 * cap_scenarios FOR UPDATE first (resolveScenarioWriteAccess), and every other
 * same-scenario writer takes the same lock first — placement-apply, reorder and
 * the child DELETE always did, and the child CREATE/UPDATE now does too for the
 * mounts apply reads unlocked (db_instances / databases / sites, via
 * makeScenarioRowLock; fmb-1685). Before that, a role-only db_instance UPDATE
 * took NO scenario lock, so it could commit between apply's unlocked
 * readHostFunctionRoles snapshot and its writes and leave apply renaming from
 * stale role/function. The GLOBAL name_patterns row (cap_settings scenario_id IS
 * NULL) has no scenario to lock on, so apply takes lockGlobalConfig — the same
 * lock its writers take — before resolveEffectivePatterns (fmb-1685). The
 * SECONDARY, defence-in-depth guard is per-row lock order: each entity
 * table is locked in ONE unfiltered `ORDER BY id FOR UPDATE` pass per scenario —
 * ascending primary-key order, the same order placement-apply's compareMove
 * takes on the shared cap_vms rows — so even absent the scenario-row lock the
 * per-row acquisition order could not invert. cap_vms carries BOTH kvm_host
 * (db_host) and ap_vm (ap_host) rows; it is locked ONCE unfiltered and split by
 * vm_type in JS AFTER the lock — a per-vm_type filtered scan would take its
 * locks in two id-monotonic-but-interleaved passes, breaking that single
 * ascending order. The display-order sort (order_index, id) that drives seq is
 * applied in JS after the locks are taken in id order.
 */
const express = require('express');
const { pool, t } = require('../../../db');
const { requireAdminOrEditor, apiOk, apiError } = require('../../../../shared/helpers');
const { logger } = require('../../../../shared/lib/logger');
const { TABLES } = require('../../../../shared/constants');
const {
  siteSlug, computeRenumberPlan, firstDuplicateName, duplicateNameFlags, duplicateAllLockedFlags,
  firstOverlengthName, resolveEffectiveNamePatterns, resolveFunctionToken,
} = require('../../../../shared/capacity/name-patterns');
const { resolveScenarioWriteAccess, safeRollback, tableColumnSet, lockGlobalConfig } = require('./_shared');

// The name column is VARCHAR(255) on BOTH cap_hypervisors and cap_vms
// (table-ddls.js). A computed hostname must fit the SMALLER limit (they are equal
// at 255); pinned against a DDL change by the renumber schema-parity test.
const MAX_HOSTNAME_LENGTH = 255;

// The renumberable entity types (spec B5), grouped by TABLE so each table is
// read/locked exactly ONCE (cap_vms carries two entity types, split by vm_type
// after the single lock pass). `vmType` NULL = the whole table is one entity
// type; otherwise it filters that table's rows in JS. `label` is used only in
// the 409 message; `patternKey` selects the entity's pattern from the resolved
// effective set. `roleAware: true` (kvm_host only, cap-pattern-function D2/D7)
// means the pattern key is NOT static — it is resolved PER ROW from that
// host's role (primary/standby) instead.
const RENUMBER_TABLES = [
  {
    table: TABLES.CAP_HYPERVISORS,
    hasVmType: false,
    entities: [{ entityType: 'hypervisor', vmType: null, patternKey: 'hypervisor', label: 'hypervisor' }],
  },
  {
    table: TABLES.CAP_VMS,
    hasVmType: true,
    entities: [
      { entityType: 'kvm_host', vmType: 'db_host', roleAware: true, label: 'KVM host' },
      { entityType: 'ap_vm', vmType: 'ap_host', patternKey: 'ap_vm', label: 'application VM' },
    ],
  },
];

// L3: an entity with neither `roleAware: true` nor a string `patternKey` would
// index `patterns[undefined]` in plansForTable and silently render the literal
// name "undefined-dc-01" for every row of that type instead of failing loudly
// — cheap enough to check once at module load rather than per request. A pure
// function so the invariant itself (not just today's fixed RENUMBER_TABLES
// value) is directly testable.
function assertRenumberEntitiesShape(tableSpecs) {
  for (const tableSpec of tableSpecs) {
    for (const entity of tableSpec.entities) {
      const hasRoleAware = entity.roleAware === true;
      const hasPatternKey = typeof entity.patternKey === 'string' && entity.patternKey.length > 0;
      if (hasRoleAware === hasPatternKey) {
        throw new Error(
          `RENUMBER_TABLES entity "${entity.entityType}" must have exactly one of roleAware:true or a string patternKey`,
        );
      }
    }
  }
}
assertRenumberEntitiesShape(RENUMBER_TABLES);

/** Parse a name_patterns JSON column value: the driver may hand back a parsed
 *  object or the raw JSON string (C3). null/blank/`null` → null (inherited). */
function parseNamePatterns(raw) {
  if (raw === null || raw === undefined) return null;
  if (typeof raw === 'string') {
    const trimmed = raw.trim();
    if (trimmed === '' || trimmed === 'null') return null;
    try { return JSON.parse(trimmed); } catch { return null; }
  }
  if (typeof raw === 'object' && !Array.isArray(raw)) return raw;
  return null;
}

/**
 * Resolve the scenario's EFFECTIVE naming patterns from cap_settings: its own
 * override row (scenario_id = the scenario) wins, else the global row
 * (scenario_id IS NULL), else the built-in defaults — the SAME tier chain the FE
 * placement prefill resolves, via the shared resolveEffectiveNamePatterns.
 */
async function resolveEffectivePatterns(dbHandle, scenarioId) {
  // Degraded-schema guard (C1, READ side): a warn-skipped name_patterns migration
  // (no DDL privilege) leaves the column ABSENT — a direct SELECT of it would 500
  // both preview and apply. Probe on `dbHandle` — the SAME connection the SELECT
  // below runs on (replica-DDL-lag family, mirrors readTableRows' fix below:
  // probing via the writer pool while the SELECT itself runs on a lagging RO
  // replica in preview lets the probe see the column present and the SELECT
  // 500 on it — probe and SELECT must observe the identical schema, which only
  // the same connection guarantees) — and, when the column is missing, resolve
  // to the built-in defaults: with no column there are no stored overrides
  // anywhere to read. An empty/odd probe (no `id`) is treated as "unknown,
  // assume present" and falls through, mirroring dropAbsentColumns' fail-safe.
  const settingsCols = await tableColumnSet(dbHandle, TABLES.CAP_SETTINGS);
  if (settingsCols.has('id') && !settingsCols.has('name_patterns')) {
    return resolveEffectiveNamePatterns(null, null);
  }
  const scenRows = await dbHandle.query(
    `SELECT scenario_id, name_patterns FROM \`${t(TABLES.CAP_SETTINGS)}\` WHERE scenario_id = ?`,
    [scenarioId],
  );
  const globalRows = await dbHandle.query(
    `SELECT scenario_id, name_patterns FROM \`${t(TABLES.CAP_SETTINGS)}\` WHERE scenario_id IS NULL LIMIT 1`,
  );
  const scenarioRow = scenRows.length
    ? { scenario_id: scenRows[0].scenario_id, name_patterns: parseNamePatterns(scenRows[0].name_patterns) }
    : null;
  const globalRow = globalRows.length
    ? { scenario_id: globalRows[0].scenario_id, name_patterns: parseNamePatterns(globalRows[0].name_patterns) }
    : null;
  return resolveEffectiveNamePatterns(scenarioRow, globalRow);
}

/** scenario site-id → site name (for the {dc} slug). One read, no lock — a
 *  concurrent site rename cannot commit mid-apply because the sites mount's
 *  CREATE/UPDATE takes the scenario row FOR UPDATE, which apply holds (fmb-1685). */
async function readSiteNames(dbHandle, scenarioId) {
  const rows = await dbHandle.query(
    `SELECT id, name FROM \`${t(TABLES.CAP_SITES)}\` WHERE scenario_id = ?`,
    [scenarioId],
  );
  const byId = new Map();
  for (const r of rows) byId.set(r.id, r.name);
  return byId;
}

/**
 * db_host VM id → { role, function } (cap-pattern-function spec D7): role is
 * 'primary' iff ≥1 instance placed on that host has the primary role, else
 * 'standby'; function is the function_name of the FIRST database (min
 * cap_databases.order_index, the on-screen display order) among the databases
 * that have ≥1 instance on that host — ties broken by database id for a
 * deterministic result. LEFT JOIN so an instance whose database_id is NULL or
 * dangling (an orphaned instance) still counts toward role, just not toward
 * function. Unlocked read (same tier as readSiteNames — this is generation
 * CONTEXT, not a row being renamed; the entity tables carry the actual lock).
 * Freshness against a concurrent placement/role/function edit does NOT come from
 * a lock here — locking cap_db_instances inside apply would invert against the
 * child writes' cap_vms lock order (deadlock; makeScenarioRowLock note). It comes
 * from those child writes taking the scenario row FOR UPDATE, which apply already
 * holds, so none can commit between this snapshot and apply's writes (fmb-1685).
 * A host absent from the returned map has NO instances at all — D7's "empty
 * host" case, resolved by the caller (role defaults to primary, function
 * falls back via resolveFunctionToken).
 */
async function readHostFunctionRoles(dbHandle, scenarioId) {
  const rows = await dbHandle.query(
    `SELECT di.vm_id AS vmId, di.role AS role, d.function_name AS functionName, d.order_index AS dbOrderIndex, d.id AS dbId
     FROM \`${t(TABLES.CAP_DB_INSTANCES)}\` di
     LEFT JOIN \`${t(TABLES.CAP_DATABASES)}\` d ON di.database_id = d.id
     WHERE di.scenario_id = ?`,
    [scenarioId],
  );
  const byVm = new Map();
  for (const r of rows) {
    let entry = byVm.get(r.vmId);
    if (!entry) {
      entry = { hasPrimary: false, bestOrderIndex: null, bestDbId: null, functionName: null };
      byVm.set(r.vmId, entry);
    }
    if (r.role === 'primary') entry.hasPrimary = true;
    if (r.dbOrderIndex !== null && r.dbOrderIndex !== undefined) {
      const orderIndex = Number(r.dbOrderIndex);
      const dbId = String(r.dbId);
      const better = entry.bestOrderIndex === null
        || orderIndex < entry.bestOrderIndex
        || (orderIndex === entry.bestOrderIndex && dbId < entry.bestDbId);
      if (better) {
        entry.bestOrderIndex = orderIndex;
        entry.bestDbId = dbId;
        entry.functionName = r.functionName;
      }
    }
  }
  const byVmResolved = new Map();
  for (const [vmId, entry] of byVm) {
    byVmResolved.set(vmId, { role: entry.hasPrimary ? 'primary' : 'standby', function: entry.functionName });
  }
  return byVmResolved;
}

/**
 * Read one TABLE's rows (unfiltered — one pass), shaped for computeRenumberPlan.
 * For the APPLY path (`lock`) the scan is a single `ORDER BY id FOR UPDATE`
 * (canonical lock order); display order (order_index, id) is imposed in JS
 * afterward. For PREVIEW the DB orders by (order_index, id) directly (no lock).
 * `vm_type` is carried when the table has it so the caller can split entity types
 * in JS without a second scan.
 */
async function readTableRows(dbHandle, scenarioId, table, hasVmType, siteNames, { lock }) {
  // Degraded-schema guard (READ side, mirrors resolveEffectivePatterns above): a
  // warn-skipped name_locked migration (no DDL privilege) leaves the column
  // ABSENT — naming it in the SELECT unconditionally would 500 every renumber
  // call. Probe on `dbHandle` — the SAME connection the SELECT below runs on
  // (Codex R2: probing via the writer pool while this SELECT runs on a lagging
  // RO replica in preview lets the probe see the column and the SELECT 500 on
  // it — probe and SELECT must observe the identical schema, which only the
  // same connection guarantees) — and drop the column from the SELECT when
  // missing: with no column every host reads as unlocked, degrading to today's
  // unconditional-rename behaviour instead of failing. An empty/odd probe (no
  // `id`) is treated as "unknown, assume present" (dropAbsentColumns' fail-safe).
  const physicalCols = await tableColumnSet(dbHandle, table);
  const hasLockColumn = !physicalCols.has('id') || physicalCols.has('name_locked');
  const lockCol = hasLockColumn ? ', name_locked' : '';
  const cols = hasVmType
    ? `id, name, order_index, site_id, vm_type${lockCol}`
    : `id, name, order_index, site_id${lockCol}`;
  const order = lock ? 'ORDER BY id FOR UPDATE' : 'ORDER BY order_index, id';
  const raw = await dbHandle.query(
    `SELECT ${cols} FROM \`${t(table)}\` WHERE scenario_id = ? ${order}`,
    [scenarioId],
  );
  const rows = raw.map((r) => ({
    id: r.id,
    name: r.name,
    order_index: Number(r.order_index) || 0,
    vm_type: hasVmType ? r.vm_type : null,
    // Unplaced (site_id NULL, or a dangling id not in the scenario's sites) → ''
    // slug → the {dc}-free group (computeRenumberPlan strips {dc} there).
    dcSlug: r.site_id && siteNames.has(r.site_id) ? siteSlug(siteNames.get(r.site_id)) : '',
    // cap-renumber-lock (spec D1/D3): a locked host is excluded from renaming
    // and consumes no seq. Re-read fresh on every call (preview AND apply) so
    // apply never trusts a stale preview's lock state.
    locked: hasLockColumn && (r.name_locked === 1 || r.name_locked === true),
  }));
  if (lock) {
    // Locks were taken in id order above; now impose display order for seq.
    rows.sort((a, b) => (a.order_index - b.order_index) || (a.id < b.id ? -1 : a.id > b.id ? 1 : 0));
  }
  return rows;
}

/**
 * Split a table's rows into its entity types (by vm_type) and compute each
 * type's plan, tagging every plan item with its entityType.
 *
 * `roleAware` entities (kvm_host, cap-pattern-function D2/D7) resolve their
 * pattern PER ROW from `hostFunctionRoles` instead of a single static
 * patternKey: primary and standby hosts form independent renumber groups
 * (independent seq streams, independent patterns), computed separately and
 * then reassembled into the ORIGINAL row order (not primary-then-standby) so
 * the preview/apply response order is unaffected by the split — the same
 * order-preservation computeRenumberPlan itself already guarantees for
 * locked-vs-renumerable rows.
 *
 * H1: the primary group is computed FIRST, then its full plan (locked names
 * unchanged + every generated name) is passed as the standby call's
 * `reservedSeed` — so a same-dc empty primary host (`kvm-{dc}-01` fallback) and
 * a same-dc standby-only host (also `kvm-{dc}-01` under D8 defaults) share ONE
 * collision set instead of each independently claiming seq 1. Deterministic:
 * the primary group is always resolved before the standby group regardless of
 * row order, so the same input always produces the same names.
 *
 * P1b (Codex r1 on H1): the primary call runs FIRST with no seed of its own,
 * so a LOCKED row on the STANDBY side was invisible to it — a locked standby
 * host named `kvm-{dc}-01` and an empty primary host would both resolve to
 * that name and collide. Locked names are now collected from BOTH role groups
 * up front (before either plan runs) and passed as `reservedSeed` to the
 * PRIMARY call too, so every plan call sees every name it must avoid.
 */
function plansForTable(tableSpec, rows, patterns, hostFunctionRoles) {
  return tableSpec.entities.map((entity) => {
    const entityRows = entity.vmType ? rows.filter((r) => r.vm_type === entity.vmType) : rows;
    if (entity.roleAware) {
      const primaryRows = [];
      const standbyRows = [];
      for (const row of entityRows) {
        const info = hostFunctionRoles.get(row.id);
        // D7 "empty host" (no instances at all → absent from the map) uses the
        // primary pattern; a resolved host uses its actual computed role.
        const role = info && info.role === 'standby' ? 'standby' : 'primary';
        const patternKey = role === 'primary' ? 'kvm_host_primary' : 'kvm_host_standby';
        const withFn = { ...row, function: resolveFunctionToken(patternKey, info ? info.function : null) };
        (role === 'primary' ? primaryRows : standbyRows).push(withFn);
      }
      // P1b: locked names from BOTH role groups, collected BEFORE either plan
      // runs — the primary call has no other seed, so without this a locked
      // standby host is invisible to it.
      const lockedNamesBothGroups = entityRows.filter((row) => row.locked).map((row) => row.name);
      const primaryPlan = computeRenumberPlan(primaryRows, patterns.kvm_host_primary, lockedNamesBothGroups);
      // Standby seed = (a) locked names from BOTH groups (redundant with
      // primaryPlan's own locked-primary names, harmless — the set dedups) +
      // (b) the primary plan's generated names.
      const reservedSeed = [
        ...lockedNamesBothGroups,
        ...primaryPlan.map((item) => item.newName),
      ];
      const standbyPlan = computeRenumberPlan(standbyRows, patterns.kvm_host_standby, reservedSeed);
      const planById = new Map([...primaryPlan, ...standbyPlan].map((item) => [item.id, item]));
      const plan = entityRows.map((row) => planById.get(row.id));
      return { entity, table: tableSpec.table, plan };
    }
    // hypervisor / ap_vm: no live per-row function resolution in this PR — a
    // hypervisor's hosted-VM function chain and an AP VM's database link are
    // both out of scope here (AP VMs never own a db instance at all, spec
    // §3.4, so ap_vm's {function} ALWAYS resolves to its fallback regardless;
    // a hypervisor custom pattern using {function} gets the same treatment
    // rather than silently rendering empty).
    const functionValue = resolveFunctionToken(entity.patternKey, null);
    const withFn = entityRows.map((row) => ({ ...row, function: functionValue }));
    const plan = computeRenumberPlan(withFn, patterns[entity.patternKey]);
    return { entity, table: tableSpec.table, plan };
  });
}

const router = express.Router();

// POST preview — read-only. Admin+editor (the toolbar action is canWrite-gated),
// but takes NO lock (a RO handle must not FOR UPDATE).
//
// M1: ONE pool.ro connection is acquired up front and threaded through every
// read below (access check, pattern-resolution probe, site/role reads, row
// SELECTs) — a pool FACADE's `.query()` may hand each call a different
// physical replica, so probing schema on one call and reading rows on another
// (both nominally "pool.ro") could still observe two different replicas, the
// exact replica-DDL-lag shape the dbHandle threading was introduced to close.
// Same invariant apply already holds via its RW transaction connection.
router.post('/scenarios/:scenarioId/renumber-preview', async (req, res) => {
  if (!requireAdminOrEditor(req, res)) return;
  const scenarioId = req.params.scenarioId;
  let conn;
  try {
    conn = await pool.ro.getConnection();
    const access = await resolveScenarioWriteAccess(conn, scenarioId, req.user, { lock: false });
    if (!access.found) {
      const e = apiError('Scenario not found', 'NOT_FOUND', 404);
      return res.status(e.status).json(e.body);
    }
    if (!access.allowed) {
      const e = apiError('Not the scenario owner', 'FORBIDDEN', 403);
      return res.status(e.status).json(e.body);
    }
    const patterns = await resolveEffectivePatterns(conn, scenarioId);
    const siteNames = await readSiteNames(conn, scenarioId);
    const hostFunctionRoles = await readHostFunctionRoles(conn, scenarioId);
    const preview = [];
    for (const tableSpec of RENUMBER_TABLES) {
      const rows = await readTableRows(conn, scenarioId, tableSpec.table, tableSpec.hasVmType, siteNames, { lock: false });
      for (const { entity, plan } of plansForTable(tableSpec, rows, patterns, hostFunctionRoles)) {
        // Same fold, same scope as apply's firstDuplicateName gate (the full
        // per-entity-type newNames list, ALL rows incl. unchanged ones) — every
        // colliding row is flagged (fmb-1649), not just the second occurrence,
        // so the dialog can block Confirm before the user reaches apply's
        // deterministic 409 (same input → same collision, no retry escapes it).
        const dupFlags = duplicateNameFlags(plan.map((p) => p.newName));
        // cap-renumber-lock: a collision where EVERY colliding row is locked
        // cannot be fixed by editing the naming pattern (a locked name never
        // changes, spec D1) — the dialog needs to tell those two remedies apart.
        const lockedDupFlags = duplicateAllLockedFlags(plan.map((p) => ({ name: p.newName, locked: p.locked })));
        plan.forEach((item, idx) => {
          preview.push({
            id: item.id,
            entityType: entity.entityType,
            oldName: item.oldName,
            newName: item.newName,
            // Surface an over-limit name BEFORE apply (Codex R2 P2-2): the dialog
            // flags the row and blocks confirm, so the user shortens the pattern
            // rather than hitting the apply-time 409.
            tooLong: item.newName.length > MAX_HOSTNAME_LENGTH,
            duplicate: dupFlags[idx],
            lockedDuplicate: lockedDupFlags[idx],
            // cap-renumber-lock (spec D1/D6): locked rows render greyed with no
            // rename arrow; newName === oldName always holds for them.
            locked: item.locked,
          });
        });
      }
    }
    res.json(apiOk(preview));
  } catch (err) {
    logger.error({ err, scenarioId }, `Failed to preview capacity renumber for scenario id=${scenarioId}`);
    const e = apiError('Database operation failed', 'INTERNAL_ERROR', 500);
    res.status(e.status).json(e.body);
  } finally {
    if (conn) conn.release();
  }
});

// POST apply — one transaction. Recompute server-side, enforce per-entity-type
// uniqueness, write every CHANGED name, whole rollback on any duplicate.
router.post('/scenarios/:scenarioId/renumber', async (req, res) => {
  if (!requireAdminOrEditor(req, res)) return;
  const scenarioId = req.params.scenarioId;

  let conn;
  try {
    conn = await pool.rw.getConnection();
    await conn.beginTransaction();

    const access = await resolveScenarioWriteAccess(conn, scenarioId, req.user);
    if (!access.found) {
      await safeRollback(conn);
      const e = apiError('Scenario not found', 'NOT_FOUND', 404);
      return res.status(e.status).json(e.body);
    }
    if (!access.allowed) {
      await safeRollback(conn);
      const e = apiError('Not the scenario owner', 'FORBIDDEN', 403);
      return res.status(e.status).json(e.body);
    }

    // fmb-1685: resolveEffectivePatterns reads the GLOBAL cap_settings row
    // (scenario_id IS NULL) that a scenario with no override inherits its
    // name_patterns from. That row is written by the global config writers under
    // lockGlobalConfig, and those writers take NO scenario lock — so unlike the
    // per-scenario override (whose PUT takes cap_scenarios FOR UPDATE, which apply
    // already holds), a concurrent GLOBAL name_patterns edit could commit between
    // this read and apply's writes and leave apply renaming from a stale pattern.
    // Take the SAME lock the global writers take, so the two cannot interleave.
    // Lock ORDER: cap_scenarios (already held) → cap_settings, and no cap_settings
    // writer acquires cap_scenarios after cap_settings (the per-scenario PUT takes
    // cap_scenarios FIRST; the global writer takes neither cap_scenarios nor the
    // entity tables), so this adds no inverting edge.
    await lockGlobalConfig(conn);

    const patterns = await resolveEffectivePatterns(conn, scenarioId);
    const siteNames = await readSiteNames(conn, scenarioId);
    const hostFunctionRoles = await readHostFunctionRoles(conn, scenarioId);

    // Phase 1: lock each TABLE once (ascending id) and compute every entity
    // type's plan. No write yet — the uniqueness gate must clear for ALL types
    // first so a conflict in a later type still rolls the earlier types back.
    const allPlans = [];
    for (const tableSpec of RENUMBER_TABLES) {
      const rows = await readTableRows(conn, scenarioId, tableSpec.table, tableSpec.hasVmType, siteNames, { lock: true });
      for (const planned of plansForTable(tableSpec, rows, patterns, hostFunctionRoles)) {
        const newNames = planned.plan.map((p) => p.newName);
        const dup = firstDuplicateName(newNames);
        if (dup !== null) {
          await safeRollback(conn);
          // cap-renumber-lock: when EVERY row colliding on `dup` is locked, the
          // pattern is not the problem — a locked name never changes (spec D1),
          // so re-running with a different pattern would hit the identical 409.
          // The only remedy is unlocking one of the colliding hosts.
          const lockedDupFlags = duplicateAllLockedFlags(
            planned.plan.map((p) => ({ name: p.newName, locked: p.locked })),
          );
          const dupIdx = newNames.findIndex((n) => String(n).trim().toLowerCase() === String(dup).trim().toLowerCase());
          const message = dupIdx !== -1 && lockedDupFlags[dupIdx]
            ? `Renumber would collide on "${dup}" — every ${planned.entity.label} host with that name is locked, so no naming pattern can change it. Unlock one of the colliding ${planned.entity.label} hosts and retry.`
            : `Renumber would create a duplicate ${planned.entity.label} name "${dup}" — no changes applied. Adjust the ${planned.entity.label} naming pattern and retry.`;
          const e = apiError(message, 'CONFLICT', 409);
          return res.status(e.status).json(e.body);
        }
        // Over-limit guard (Codex R2 P2-2): a long site slug + pattern prefix can
        // compute a name past the VARCHAR(255) column — reject the whole apply
        // (a strict INSERT would 500, a lax one would truncate) on the same
        // rollback-before-any-write path as the duplicate guard.
        const tooLong = firstOverlengthName(newNames, MAX_HOSTNAME_LENGTH);
        if (tooLong !== null) {
          await safeRollback(conn);
          const e = apiError(
            `Renumber would create a ${planned.entity.label} name longer than ${MAX_HOSTNAME_LENGTH} characters ("${tooLong.slice(0, 40)}…") — no changes applied. Shorten the ${planned.entity.label} naming pattern or the site name and retry.`,
            'CONFLICT', 409,
          );
          return res.status(e.status).json(e.body);
        }
        allPlans.push(planned);
      }
    }

    // Phase 2: write only the CHANGED rows (case-sensitive compare so a case-only
    // rename is still applied). Uniqueness already cleared for every type. A
    // locked row's newName === oldName always holds (computeRenumberPlan), but
    // it still gets an EXPLICIT `item.locked` branch below (not just the
    // unchanged-name check that would happen to skip it anyway) so it can be
    // counted into skippedLocked for the response summary (spec D1: apply
    // re-checks lock state fresh, so a row locked between preview and apply is
    // skipped here even if preview showed it as renamed).
    const renamed = [];
    let skippedLocked = 0;
    for (const { entity, table, plan } of allPlans) {
      for (const item of plan) {
        if (item.locked) { skippedLocked += 1; continue; }
        if (item.newName === item.oldName) continue;
        await conn.query(
          `UPDATE \`${t(table)}\` SET name = ? WHERE id = ? AND scenario_id = ?`,
          [item.newName, item.id, scenarioId],
        );
        renamed.push({
          id: item.id, entityType: entity.entityType, oldName: item.oldName, newName: item.newName,
        });
      }
    }

    await conn.commit();
    res.json(apiOk({ applied: renamed.length, renamed, skippedLocked }));
  } catch (err) {
    await safeRollback(conn);
    logger.error({ err, scenarioId }, `Failed to apply capacity renumber for scenario id=${scenarioId}`);
    const e = apiError('Database operation failed', 'INTERNAL_ERROR', 500);
    res.status(e.status).json(e.body);
  } finally {
    if (conn) conn.release();
  }
});

// Test-only (L3): the express Router is a function, so it can carry a named
// property alongside its mount behaviour — mirrors _shared.js's
// _resetColumnSetCache test-hook pattern. Lets a test drive the shape
// assertion against synthetic input without mutating the real RENUMBER_TABLES.
router._assertRenumberEntitiesShape = assertRenumberEntitiesShape;

module.exports = router;
