/**
 * public-read.js — Public Integration API scoped read surface (infra, namespace
 * /api/public/v1). Mounted AFTER public-gate so the machine-tier gate has
 * already resolved the Bearer token via edge (S2S hash lookup) + validated a
 * non-empty scope and set `req.machinePrincipal`. This router only forwards S2S to the edge bespoke
 * projections (infra-talks-to-edge-only: no DB here) carrying the machine
 * principal contract, and maps edge results to the public error model [M4].
 *
 * Endpoints (all reads; scoped + fail-closed at edge §5.1):
 *   GET /blueprints                 list blueprints under granted roots
 *   GET /blueprints/{name-path}     one blueprint's field/section shape (§6)
 *   GET /templates                  list templates under granted roots
 *   GET /templates/{id}             one template detail
 *   GET /runs                       flow-run status/history under granted roots
 *   GET /runs/{id}                  one run's status
 */
const express = require('express');
const { forwardToEdge } = require('../lib/remote-client');
const {
  isPublicErrorCode,
  upstreamErrorCode,
  publicMappingForInternalCode,
} = require('../../shared/lib/public-errors');
const { logger: rootLogger } = require('../../shared/lib/logger');

const logger = rootLogger.child({ module: 'public-read-infra' });
const router = express.Router();

const EDGE_BASE = '/edge/internal/public-read';

// The post-auth machine-tier limiter [H3] is mounted ONCE at the /api/public/v1
// namespace (index-infra), shared with the write router, so reads + writes draw
// from a single per-account budget (plan decision 3) and a request is never
// double-counted while passing through both routers. It is intentionally not
// mounted inside this router anymore.

// Edge statuses whose public `error` code is relayed verbatim. 401 is included
// [M1] so a genuine auth/scope rejection surfaces as invalid_token rather than
// being masked as an outage (edge_unreachable) — the isPublicErrorCode guard
// still prevents any internal code/meta from leaking.
const RELAYABLE_STATUSES = new Set([400, 401, 404, 409]);

/**
 * Relay an edge public-read result to the client under the public error model.
 * - 200: edge already returns a public-shaped `{ data, meta }` body (no internal
 *   meta) → relay verbatim.
 * - 400/401/404/409 carrying a whitelisted public `error` code → relay that code.
 * - anything else (500/502/503/circuit-open/timeout/unknown) → edge_unreachable.
 *   This collapses any internal apiError envelope so meta.db_type/provider can
 *   never leak to an external caller.
 */
function relayPublic(res, result) {
  if (result.status === 200) {
    return res.status(200).json(result.data);
  }
  const code = upstreamErrorCode(result.data);
  // An infra-side refusal (internal envelope) is not an outage. Mapped before
  // the relay test because its code is internal and will never be whitelisted.
  const internal = publicMappingForInternalCode(code);
  if (internal) {
    return res.status(internal.status).json({ error: internal.code });
  }
  if (RELAYABLE_STATUSES.has(result.status) && isPublicErrorCode(code)) {
    return res.status(result.status).json({ error: code });
  }
  return res.status(503).json({ error: 'edge_unreachable' });
}

/** Build the machine-principal forwarding options from the gated request. */
function principalForward(req, edgePath, query) {
  const principal = req.machinePrincipal;
  return {
    method: 'GET',
    path: edgePath,
    // x-forwarded-user-id = sub; edge s2s-verify reconstructs the machine
    // principal from principalType + scope headers (never trusts these blindly).
    user: { id: principal.sub, email: '' },
    principal: { principalType: 'service_account', scope: principal.scope },
    query,
    reqPath: req.originalUrl || req.path,
  };
}

// Only whitelist the pagination params — client-supplied owner_id / actor_id and
// any other filter are dropped here and never reach edge (anti-enumeration).
function pageQuery(req) {
  const q = {};
  if (req.query.limit !== undefined) q.limit = req.query.limit;
  if (req.query.cursor !== undefined) q.cursor = req.query.cursor;
  return q;
}

async function forwardRead(req, res, edgePath, query) {
  // [L3] defensive: the upstream machine-tier gate always sets this, but guard so
  // the router never depends on mount order for its fail-closed behaviour.
  if (!req.machinePrincipal || !req.machinePrincipal.sub) {
    return res.status(401).json({ error: 'invalid_token' });
  }
  try {
    const result = await forwardToEdge(principalForward(req, edgePath, query));
    return relayPublic(res, result);
  } catch (err) {
    // [M3] forwardToEdge builds the URL + S2S headers BEFORE its own try block, so
    // a synchronous throw there would otherwise become an unhandled rejection
    // (Express 4 does not route async errors). Collapse to the public outage code.
    logger.error({ err: err.message }, 'public read forward threw');
    return res.status(503).json({ error: 'edge_unreachable' });
  }
}

/**
 * @openapi
 * /api/public/v1/blueprints:
 *   get:
 *     summary: List blueprints
 *     description: >
 *       Returns blueprints that are, or descend from, one of your token's
 *       granted hierarchy roots. An absent or empty grant returns an empty
 *       list — never "all rows".
 *     tags: [Public API]
 *     security: [{ bearerAuth: [] }, { apiKeyAuth: [] }]
 *     x-codeSamples:
 *       - lang: Shell
 *         label: curl (both auth carriers)
 *         source: |
 *           API_BASE="https://your-app-host"        # the host serving this portal
 *           API_KEY="paste-the-key-shown-once-at-creation"
 *
 *           # Direct path — send the key as a Bearer token:
 *           curl -sS "$API_BASE/api/public/v1/blueprints?limit=50" \
 *             -H "Authorization: Bearer $API_KEY"
 *
 *           # Through an API gateway the same key travels as an api_key header:
 *           curl -sS "$API_BASE/api/public/v1/blueprints?limit=50" \
 *             -H "api_key: $API_KEY"
 *     parameters:
 *       - name: limit
 *         in: query
 *         schema: { type: integer, default: 50, maximum: 200, example: 50 }
 *         description: Page size. Defaults to 50, capped at 200.
 *       - name: cursor
 *         in: query
 *         schema: { type: string, example: "eyJjIjoiMjAyNi0wNy0xMVQxMjowMDowMC4wMDBaIiwiaSI6ImI2YjYifQ" }
 *         description: >
 *           Opaque continuation token, taken verbatim from the previous page's
 *           `meta.next_cursor`. Omit it for the first page; a `null`
 *           `next_cursor` means the page just returned was the last one.
 *           Ordering is stable (`created_at`, then `id`, ascending), so a
 *           concurrent insert cannot shift a row onto a page already read.
 *     responses:
 *       200:
 *         description: Page of blueprints
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 data:
 *                   type: array
 *                   description: The blueprints on this page, oldest first.
 *                   items:
 *                     type: object
 *                     properties:
 *                       id: { type: string, description: "Stable identifier of the hierarchy node.", example: "b6b60000-0000-0000-0000-000000000001" }
 *                       name: { type: string, description: "The node's display name — the last segment of a name-path.", example: "Blueprint X" }
 *                       node_type: { type: string, description: "Hierarchy tier of the node.", example: "blueprint" }
 *                       path:
 *                         type: array
 *                         description: "Ancestor names, root first, truncated at the granted scope boundary. Join with `/` to address the node."
 *                         items: { type: string, description: "One hierarchy name.", example: "Category A" }
 *                       created_at: { type: string, format: date-time, description: "When the node was created (UTC, ISO 8601).", example: "2026-07-11T12:00:00.000Z" }
 *                 meta:
 *                   type: object
 *                   description: Paging state for this response.
 *                   properties:
 *                     next_cursor: { type: string, nullable: true, description: "Pass as `cursor` to fetch the next page. `null` on the last page.", example: null }
 *             example:
 *               data:
 *                 - id: "b6b60000-0000-0000-0000-000000000001"
 *                   name: "Blueprint X"
 *                   node_type: blueprint
 *                   path: ["Category A", "Release 1", "Blueprint X"]
 *                   created_at: "2026-07-11T12:00:00.000Z"
 *               meta: { next_cursor: null }
 *       401:
 *         description: Missing/unknown/deactivated token
 *         content:
 *           application/json:
 *             schema: { $ref: '#/components/schemas/PublicError' }
 *             example: { error: invalid_token }
 *       429:
 *         description: >
 *           Per-account budget exceeded — reads and writes draw on one shared
 *           per-minute budget. This response also carries `Retry-After`, which
 *           must be honoured before retrying. `RateLimit-*` headers appear on
 *           every response, but they describe two different budgets: on an
 *           authenticated response the per-account per-minute one, on an
 *           unauthenticated rejection a separate, longer-windowed budget keyed
 *           by source IP.
 *         content:
 *           application/json:
 *             schema: { $ref: '#/components/schemas/PublicError' }
 *             example: { error: rate_limited }
 */
// ── GET /blueprints ──────────────────────────────────────────────────────────
router.get('/blueprints', (req, res) => forwardRead(req, res, `${EDGE_BASE}/blueprints`, pageQuery(req)));

/**
 * @openapi
 * /api/public/v1/blueprints/{path}:
 *   get:
 *     summary: Get blueprint schema
 *     description: >
 *       The `{path}` segment is a `/`-separated chain of hierarchy **names**
 *       (leaf last), e.g. `Category A/Release 1/Blueprint X`. Matching is
 *       suffix-based, case- and accent-insensitive, and Unicode-normalized —
 *       send just the leaf name, or enough ancestor names to disambiguate.
 *       0 in-scope matches and an out-of-scope match both return the SAME
 *       `404 path_not_found`, on purpose (anti-enumeration); 2+ matches
 *       return `409 path_ambiguous`. Discover addressable names via
 *       `GET /blueprints`.
 *     tags: [Public API]
 *     security: [{ bearerAuth: [] }, { apiKeyAuth: [] }]
 *     x-codeSamples:
 *       - lang: Shell
 *         label: curl (both auth carriers)
 *         source: |
 *           API_BASE="https://your-app-host"        # the host serving this portal
 *           API_KEY="paste-the-key-shown-once-at-creation"
 *
 *           # Percent-encode each name segment; keep the "/" between segments.
 *           # Direct path — send the key as a Bearer token:
 *           curl -sS "$API_BASE/api/public/v1/blueprints/Category%20A/Release%201/Blueprint%20X" \
 *             -H "Authorization: Bearer $API_KEY"
 *
 *           # Through an API gateway the same key travels as an api_key header:
 *           curl -sS "$API_BASE/api/public/v1/blueprints/Category%20A/Release%201/Blueprint%20X" \
 *             -H "api_key: $API_KEY"
 *     parameters:
 *       - name: path
 *         in: path
 *         required: true
 *         schema: { type: string, example: "Category A/Release 1/Blueprint X" }
 *         description: A `/`-separated hierarchy name-path, leaf last. Percent-encode each segment.
 *     responses:
 *       200:
 *         description: The blueprint's field/section shape
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 data:
 *                   type: object
 *                   description: The blueprint and the shape a template built from it will carry.
 *                   properties:
 *                     id: { type: string, description: "Stable identifier of the blueprint node.", example: "b6b60000-0000-0000-0000-000000000001" }
 *                     name: { type: string, description: "The blueprint's display name.", example: "Blueprint X" }
 *                     node_type: { type: string, description: "Hierarchy tier of the node.", example: "blueprint" }
 *                     path:
 *                       type: array
 *                       description: "Ancestor names, root first, truncated at the granted scope boundary."
 *                       items: { type: string, description: "One hierarchy name.", example: "Category A" }
 *                     created_at: { type: string, format: date-time, description: "When the blueprint was created (UTC, ISO 8601).", example: "2026-07-11T12:00:00.000Z" }
 *                     sections:
 *                       type: array
 *                       description: Field groups, in display order. A field's `section` names one of these keys.
 *                       items:
 *                         type: object
 *                         properties:
 *                           key: { type: string, description: "Machine key referenced by a field's `section`.", example: "network" }
 *                           label: { type: string, description: "Human label shown above the group.", example: "Network" }
 *                     fields:
 *                       type: array
 *                       description: Every field of the blueprint, in display order.
 *                       items:
 *                         type: object
 *                         properties:
 *                           key: { type: string, description: "Machine key — this is the key a template payload uses.", example: "hostname" }
 *                           label: { type: string, description: "Human label shown next to the input.", example: "Hostname" }
 *                           type: { type: string, description: "Input type, e.g. text, number, select, checkbox, table.", example: "text" }
 *                           required: { type: boolean, description: "Whether a human must fill the field before the template leaves draft.", example: true }
 *                           section: { type: string, nullable: true, description: "The `sections[].key` this field belongs to, or null when ungrouped.", example: "network" }
 *                           options:
 *                             type: array
 *                             description: Allowed choices for a select-like field; empty for free-entry fields.
 *                             items:
 *                               type: object
 *                               properties:
 *                                 label: { type: string, description: "What the human sees.", example: "Primary" }
 *                                 value: { type: string, description: "What is stored in the payload.", example: "primary" }
 *             example:
 *               data:
 *                 id: "b6b60000-0000-0000-0000-000000000001"
 *                 name: "Blueprint X"
 *                 node_type: blueprint
 *                 path: ["Category A", "Release 1", "Blueprint X"]
 *                 created_at: "2026-07-11T12:00:00.000Z"
 *                 sections:
 *                   - key: "network"
 *                     label: "Network"
 *                 fields:
 *                   - key: "hostname"
 *                     label: "Hostname"
 *                     type: "text"
 *                     required: true
 *                     section: "network"
 *                     options: []
 *       400:
 *         description: Malformed path segment
 *         content:
 *           application/json:
 *             schema: { $ref: '#/components/schemas/PublicError' }
 *             example: { error: validation_failed }
 *       401:
 *         description: Missing/unknown/deactivated token
 *         content:
 *           application/json:
 *             schema: { $ref: '#/components/schemas/PublicError' }
 *             example: { error: invalid_token }
 *       404:
 *         description: No in-scope node matches the name-path (or it does not exist)
 *         content:
 *           application/json:
 *             schema: { $ref: '#/components/schemas/PublicError' }
 *             example: { error: path_not_found }
 *       409:
 *         description: The name-path matches more than one node
 *         content:
 *           application/json:
 *             schema: { $ref: '#/components/schemas/PublicError' }
 *             example: { error: path_ambiguous }
 *       429:
 *         description: >
 *           Per-account budget exceeded — reads and writes draw on one shared
 *           per-minute budget. This response also carries `Retry-After`, which
 *           must be honoured before retrying. `RateLimit-*` headers appear on
 *           every response, but they describe two different budgets: on an
 *           authenticated response the per-account per-minute one, on an
 *           unauthenticated rejection a separate, longer-windowed budget keyed
 *           by source IP.
 *         content:
 *           application/json:
 *             schema: { $ref: '#/components/schemas/PublicError' }
 *             example: { error: rate_limited }
 */
// ── GET /blueprints/{name-path} ──────────────────────────────────────────────
// The tail after /blueprints/ is the hierarchy name-path. [P2] We must NOT use
// the Express-decoded req.params[0] — Express decodes %2F to '/' BEFORE our
// split, so a blueprint name containing a literal '/' (sent as %2F) would be
// mis-split into two segments and become unaddressable. Instead take the RAW,
// still-percent-encoded tail from req.originalUrl (Node/Express keep it
// undecoded there), split on the true '/' delimiter, THEN decodeURIComponent each
// segment — so %2F stays inside its segment. The segments are base64url-encoded
// into a JSON array for the S2S query hop.
const BLUEPRINTS_MARKER = '/blueprints/';
router.get(/^\/blueprints\/(.+)$/, (req, res) => {
  const rawUrl = (req.originalUrl || req.url || '').split('?')[0];
  const idx = rawUrl.indexOf(BLUEPRINTS_MARKER);
  const rawTail = idx >= 0 ? rawUrl.slice(idx + BLUEPRINTS_MARKER.length) : '';
  let segments;
  try {
    segments = rawTail
      .split('/')
      .map((s) => decodeURIComponent(s).trim())
      .filter((s) => s.length > 0);
  } catch {
    // Malformed percent-encoding in the path.
    return res.status(400).json({ error: 'validation_failed' });
  }
  if (segments.length === 0) return res.status(404).json({ error: 'path_not_found' });
  const p = Buffer.from(JSON.stringify(segments), 'utf8').toString('base64url');
  return forwardRead(req, res, `${EDGE_BASE}/blueprint-by-path`, { p });
});

/**
 * @openapi
 * /api/public/v1/templates:
 *   get:
 *     summary: List templates
 *     description: >
 *       Returns templates whose category/release/blueprint/variant hierarchy
 *       node is, or descends from, one of your token's granted roots. An
 *       absent or empty grant returns an empty list. Payload/generated_outputs
 *       are never included in the list projection.
 *     tags: [Public API]
 *     security: [{ bearerAuth: [] }, { apiKeyAuth: [] }]
 *     x-codeSamples:
 *       - lang: Shell
 *         label: curl (both auth carriers)
 *         source: |
 *           API_BASE="https://your-app-host"        # the host serving this portal
 *           API_KEY="paste-the-key-shown-once-at-creation"
 *
 *           # Direct path — send the key as a Bearer token:
 *           curl -sS "$API_BASE/api/public/v1/templates?limit=50" \
 *             -H "Authorization: Bearer $API_KEY"
 *
 *           # Through an API gateway the same key travels as an api_key header:
 *           curl -sS "$API_BASE/api/public/v1/templates?limit=50" \
 *             -H "api_key: $API_KEY"
 *     parameters:
 *       - name: limit
 *         in: query
 *         schema: { type: integer, default: 50, maximum: 200, example: 50 }
 *         description: Page size. Defaults to 50, capped at 200.
 *       - name: cursor
 *         in: query
 *         schema: { type: string, example: "eyJjIjoiMjAyNi0wNy0xMVQxMjowMDowMC4wMDBaIiwiaSI6ImExYTEifQ" }
 *         description: >
 *           Opaque continuation token, taken verbatim from the previous page's
 *           `meta.next_cursor`. Omit it for the first page; a `null`
 *           `next_cursor` means the page just returned was the last one.
 *           Ordering is stable (`created_at`, then `id`, ascending), so a
 *           concurrent insert cannot shift a row onto a page already read.
 *     responses:
 *       200:
 *         description: Page of templates
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 data:
 *                   type: array
 *                   description: The templates on this page, oldest first.
 *                   items:
 *                     type: object
 *                     properties:
 *                       id: { type: string, description: "Template id — the handle for `GET /templates/{id}`.", example: "a1a10000-0000-0000-0000-000000000001" }
 *                       name: { type: string, description: "The template's label.", example: "Template-0001" }
 *                       is_draft: { type: boolean, description: "True until a human completes the template in the web UI.", example: true }
 *                       path:
 *                         type: object
 *                         description: The hierarchy names the template hangs from, truncated at the granted scope boundary — a tier outside the grant is omitted.
 *                         properties:
 *                           category: { type: string, description: "Category name.", example: "Category A" }
 *                           release: { type: string, description: "Release name.", example: "Release 1" }
 *                           blueprint: { type: string, description: "Blueprint name.", example: "Blueprint X" }
 *                           variant: { type: string, description: "Variant name; absent when the template hangs from a blueprint.", example: "Variant S" }
 *                       owner_username: { type: string, nullable: true, description: "Owner's username (never an email). Null when the template is unowned, owned by an integration account, or owned by a locally-authenticated user (who has no Keycloak username).", example: "jsmith" }
 *                       schema_version: { type: string, nullable: true, description: "Version of the blueprint schema the payload was captured against. Null until a human saves the template.", example: "3" }
 *                       created_at: { type: string, format: date-time, description: "When the template was created (UTC, ISO 8601).", example: "2026-07-11T12:00:00.000Z" }
 *                       updated_at: { type: string, format: date-time, description: "When the template was last modified (UTC, ISO 8601).", example: "2026-07-11T12:30:00.000Z" }
 *                 meta:
 *                   type: object
 *                   description: Paging state for this response.
 *                   properties:
 *                     next_cursor: { type: string, nullable: true, description: "Pass as `cursor` to fetch the next page. `null` on the last page.", example: null }
 *             example:
 *               data:
 *                 - id: "a1a10000-0000-0000-0000-000000000001"
 *                   name: "Template-0001"
 *                   is_draft: true
 *                   path: { category: "Category A", release: "Release 1", blueprint: "Blueprint X", variant: "Variant S" }
 *                   owner_username: "jsmith"
 *                   schema_version: "3"
 *                   created_at: "2026-07-11T12:00:00.000Z"
 *                   updated_at: "2026-07-11T12:30:00.000Z"
 *               meta: { next_cursor: null }
 *       401:
 *         description: Missing/unknown/deactivated token
 *         content:
 *           application/json:
 *             schema: { $ref: '#/components/schemas/PublicError' }
 *             example: { error: invalid_token }
 *       429:
 *         description: >
 *           Per-account budget exceeded — reads and writes draw on one shared
 *           per-minute budget. This response also carries `Retry-After`, which
 *           must be honoured before retrying. `RateLimit-*` headers appear on
 *           every response, but they describe two different budgets: on an
 *           authenticated response the per-account per-minute one, on an
 *           unauthenticated rejection a separate, longer-windowed budget keyed
 *           by source IP.
 *         content:
 *           application/json:
 *             schema: { $ref: '#/components/schemas/PublicError' }
 *             example: { error: rate_limited }
 * /api/public/v1/templates/{id}:
 *   get:
 *     summary: Get template
 *     description: >
 *       An id that does not exist, or exists but resolves outside your
 *       granted scope, returns the SAME `404 not_found` (anti-enumeration).
 *       `payload`/`generated_outputs` are deep-masked (`****`) for any
 *       secret-named leaf before being returned.
 *     tags: [Public API]
 *     security: [{ bearerAuth: [] }, { apiKeyAuth: [] }]
 *     x-codeSamples:
 *       - lang: Shell
 *         label: curl (both auth carriers)
 *         source: |
 *           API_BASE="https://your-app-host"        # the host serving this portal
 *           API_KEY="paste-the-key-shown-once-at-creation"
 *           TEMPLATE_ID="a1a10000-0000-0000-0000-000000000001"
 *
 *           # Direct path — send the key as a Bearer token:
 *           curl -sS "$API_BASE/api/public/v1/templates/$TEMPLATE_ID" \
 *             -H "Authorization: Bearer $API_KEY"
 *
 *           # Through an API gateway the same key travels as an api_key header:
 *           curl -sS "$API_BASE/api/public/v1/templates/$TEMPLATE_ID" \
 *             -H "api_key: $API_KEY"
 *     parameters:
 *       - name: id
 *         in: path
 *         required: true
 *         schema: { type: string, format: uuid, example: "a1a10000-0000-0000-0000-000000000001" }
 *         description: The template id returned by the create call or by `GET /templates`.
 *     responses:
 *       200:
 *         description: Template detail
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 data:
 *                   type: object
 *                   description: The template, including the field values a human has entered so far. Same key set as the create response, plus the two payload blobs.
 *                   properties:
 *                     id: { type: string, description: "Template id — the handle for every subsequent call.", example: "a1a10000-0000-0000-0000-000000000001" }
 *                     name: { type: string, description: "The template's label.", example: "Template-0001" }
 *                     is_draft: { type: boolean, description: "True until a human completes the template in the web UI.", example: true }
 *                     path:
 *                       type: object
 *                       description: The hierarchy names the template hangs from, truncated at the granted scope boundary — a tier outside the grant is omitted.
 *                       properties:
 *                         category: { type: string, description: "Category name.", example: "Category A" }
 *                         release: { type: string, description: "Release name.", example: "Release 1" }
 *                         blueprint: { type: string, description: "Blueprint name.", example: "Blueprint X" }
 *                         variant: { type: string, description: "Variant name; absent when the template hangs from a blueprint.", example: "Variant S" }
 *                     owner_username: { type: string, nullable: true, description: "Owner's username (never an email). Null when the template is unowned, owned by an integration account, or owned by a locally-authenticated user (who has no Keycloak username).", example: "jsmith" }
 *                     schema_version: { type: string, nullable: true, description: "Version of the blueprint schema the payload was captured against. Null until a human saves the template.", example: "3" }
 *                     payload:
 *                       type: object
 *                       nullable: true
 *                       description: "Field values keyed by the blueprint's field `key`. Any secret-named leaf is returned as `****`."
 *                     generated_outputs:
 *                       type: object
 *                       nullable: true
 *                       description: "Values produced by the template's transformer, keyed by output name. Secret-named leaves are masked the same way."
 *                     created_at: { type: string, format: date-time, description: "When the template was created (UTC, ISO 8601).", example: "2026-07-11T12:00:00.000Z" }
 *                     updated_at: { type: string, format: date-time, description: "When the template was last modified (UTC, ISO 8601).", example: "2026-07-11T12:30:00.000Z" }
 *             example:
 *               data:
 *                 id: "a1a10000-0000-0000-0000-000000000001"
 *                 name: "Template-0001"
 *                 is_draft: true
 *                 path: { category: "Category A", release: "Release 1", blueprint: "Blueprint X", variant: "Variant S" }
 *                 owner_username: "jsmith"
 *                 schema_version: "3"
 *                 created_at: "2026-07-11T12:00:00.000Z"
 *                 updated_at: "2026-07-11T12:30:00.000Z"
 *                 payload: { hostname: "host-01", api_token: "****" }
 *                 generated_outputs: {}
 *       401:
 *         description: Missing/unknown/deactivated token
 *         content:
 *           application/json:
 *             schema: { $ref: '#/components/schemas/PublicError' }
 *             example: { error: invalid_token }
 *       404:
 *         description: Not found, or exists outside your granted scope
 *         content:
 *           application/json:
 *             schema: { $ref: '#/components/schemas/PublicError' }
 *             example: { error: not_found }
 *       429:
 *         description: >
 *           Per-account budget exceeded — reads and writes draw on one shared
 *           per-minute budget. This response also carries `Retry-After`, which
 *           must be honoured before retrying. `RateLimit-*` headers appear on
 *           every response, but they describe two different budgets: on an
 *           authenticated response the per-account per-minute one, on an
 *           unauthenticated rejection a separate, longer-windowed budget keyed
 *           by source IP.
 *         content:
 *           application/json:
 *             schema: { $ref: '#/components/schemas/PublicError' }
 *             example: { error: rate_limited }
 */
// ── GET /templates + /templates/{id} ─────────────────────────────────────────
router.get('/templates', (req, res) => forwardRead(req, res, `${EDGE_BASE}/templates`, pageQuery(req)));
router.get('/templates/:id', (req, res) =>
  forwardRead(req, res, `${EDGE_BASE}/templates/${encodeURIComponent(req.params.id)}`, {}));

/**
 * @openapi
 * /api/public/v1/runs:
 *   get:
 *     summary: List runs
 *     description: >
 *       Returns runs whose `blueprint_id` is, or descends from, one of your
 *       token's granted roots. A run with a NULL `blueprint_id` is
 *       fail-closed hidden — it is never returned regardless of grant.
 *     tags: [Public API]
 *     security: [{ bearerAuth: [] }, { apiKeyAuth: [] }]
 *     x-codeSamples:
 *       - lang: Shell
 *         label: curl (both auth carriers)
 *         source: |
 *           API_BASE="https://your-app-host"        # the host serving this portal
 *           API_KEY="paste-the-key-shown-once-at-creation"
 *
 *           # Direct path — send the key as a Bearer token:
 *           curl -sS "$API_BASE/api/public/v1/runs?limit=50" \
 *             -H "Authorization: Bearer $API_KEY"
 *
 *           # Through an API gateway the same key travels as an api_key header:
 *           curl -sS "$API_BASE/api/public/v1/runs?limit=50" \
 *             -H "api_key: $API_KEY"
 *     parameters:
 *       - name: limit
 *         in: query
 *         schema: { type: integer, default: 50, maximum: 200, example: 50 }
 *         description: Page size. Defaults to 50, capped at 200.
 *       - name: cursor
 *         in: query
 *         schema: { type: string, example: "eyJjIjoiMjAyNi0wNy0xMVQxMjowMDowMC4wMDBaIiwiaSI6ImMxYzEifQ" }
 *         description: >
 *           Opaque continuation token, taken verbatim from the previous page's
 *           `meta.next_cursor`. Omit it for the first page; a `null`
 *           `next_cursor` means the page just returned was the last one.
 *           Ordering is stable (`created_at`, then `id`, ascending), so a
 *           concurrent insert cannot shift a row onto a page already read.
 *     responses:
 *       200:
 *         description: Page of runs
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 data:
 *                   type: array
 *                   description: The runs on this page, oldest first.
 *                   items:
 *                     type: object
 *                     properties:
 *                       id: { type: string, description: "Run id — the handle for `GET /runs/{id}`.", example: "c1c10000-0000-0000-0000-000000000001" }
 *                       status: { type: string, description: "Lifecycle state of the run, e.g. queued, running, succeeded, failed.", example: "succeeded" }
 *                       mode: { type: string, description: "How the run was started, e.g. manual or automatic.", example: "manual" }
 *                       result_link: { type: string, nullable: true, description: "Link to the result in the system that executed the flow; null until one is recorded.", example: "https://example.test/runs/1" }
 *                       external_flow_id: { type: string, nullable: true, description: "Identifier of the run in the executing system; null when it reports none.", example: "flow-42" }
 *                       blueprint_id: { type: string, nullable: true, description: "Blueprint the run belongs to; null when that blueprint is outside the granted scope.", example: "b6b60000-0000-0000-0000-000000000001" }
 *                       started_at: { type: string, format: date-time, nullable: true, description: "When execution began (UTC, ISO 8601); null while still queued.", example: "2026-07-11T12:00:00.000Z" }
 *                       finished_at: { type: string, format: date-time, nullable: true, description: "When execution ended (UTC, ISO 8601); null while still running.", example: "2026-07-11T12:01:00.000Z" }
 *                       created_at: { type: string, format: date-time, description: "When the run was recorded (UTC, ISO 8601).", example: "2026-07-11T12:00:00.000Z" }
 *                 meta:
 *                   type: object
 *                   description: Paging state for this response.
 *                   properties:
 *                     next_cursor: { type: string, nullable: true, description: "Pass as `cursor` to fetch the next page. `null` on the last page.", example: null }
 *             example:
 *               data:
 *                 - id: "c1c10000-0000-0000-0000-000000000001"
 *                   status: "succeeded"
 *                   mode: "manual"
 *                   result_link: "https://example.test/runs/1"
 *                   external_flow_id: "flow-42"
 *                   blueprint_id: "b6b60000-0000-0000-0000-000000000001"
 *                   started_at: "2026-07-11T12:00:00.000Z"
 *                   finished_at: "2026-07-11T12:01:00.000Z"
 *                   created_at: "2026-07-11T12:00:00.000Z"
 *               meta: { next_cursor: null }
 *       401:
 *         description: Missing/unknown/deactivated token
 *         content:
 *           application/json:
 *             schema: { $ref: '#/components/schemas/PublicError' }
 *             example: { error: invalid_token }
 *       429:
 *         description: >
 *           Per-account budget exceeded — reads and writes draw on one shared
 *           per-minute budget. This response also carries `Retry-After`, which
 *           must be honoured before retrying. `RateLimit-*` headers appear on
 *           every response, but they describe two different budgets: on an
 *           authenticated response the per-account per-minute one, on an
 *           unauthenticated rejection a separate, longer-windowed budget keyed
 *           by source IP.
 *         content:
 *           application/json:
 *             schema: { $ref: '#/components/schemas/PublicError' }
 *             example: { error: rate_limited }
 * /api/public/v1/runs/{id}:
 *   get:
 *     summary: Get run
 *     description: >
 *       An id that does not exist, resolves outside your granted scope, or
 *       carries a NULL `blueprint_id`, all return the SAME `404 not_found`
 *       (anti-enumeration).
 *     tags: [Public API]
 *     security: [{ bearerAuth: [] }, { apiKeyAuth: [] }]
 *     x-codeSamples:
 *       - lang: Shell
 *         label: curl (both auth carriers)
 *         source: |
 *           API_BASE="https://your-app-host"        # the host serving this portal
 *           API_KEY="paste-the-key-shown-once-at-creation"
 *           RUN_ID="c1c10000-0000-0000-0000-000000000001"
 *
 *           # Direct path — send the key as a Bearer token:
 *           curl -sS "$API_BASE/api/public/v1/runs/$RUN_ID" \
 *             -H "Authorization: Bearer $API_KEY"
 *
 *           # Through an API gateway the same key travels as an api_key header:
 *           curl -sS "$API_BASE/api/public/v1/runs/$RUN_ID" \
 *             -H "api_key: $API_KEY"
 *     parameters:
 *       - name: id
 *         in: path
 *         required: true
 *         schema: { type: string, format: uuid, example: "c1c10000-0000-0000-0000-000000000001" }
 *         description: The run id returned by `GET /runs`.
 *     responses:
 *       200:
 *         description: Run status/result
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 data:
 *                   type: object
 *                   description: The run's current state.
 *                   properties:
 *                     id: { type: string, description: "Run id.", example: "c1c10000-0000-0000-0000-000000000001" }
 *                     status: { type: string, description: "Lifecycle state of the run, e.g. queued, running, succeeded, failed.", example: "succeeded" }
 *                     mode: { type: string, description: "How the run was started, e.g. manual or automatic.", example: "manual" }
 *                     result_link: { type: string, nullable: true, description: "Link to the result in the system that executed the flow; null until one is recorded.", example: "https://example.test/runs/1" }
 *                     external_flow_id: { type: string, nullable: true, description: "Identifier of the run in the executing system; null when it reports none.", example: "flow-42" }
 *                     blueprint_id: { type: string, nullable: true, description: "Blueprint the run belongs to; null when that blueprint is outside the granted scope.", example: "b6b60000-0000-0000-0000-000000000001" }
 *                     started_at: { type: string, format: date-time, nullable: true, description: "When execution began (UTC, ISO 8601); null while still queued.", example: "2026-07-11T12:00:00.000Z" }
 *                     finished_at: { type: string, format: date-time, nullable: true, description: "When execution ended (UTC, ISO 8601); null while still running.", example: "2026-07-11T12:01:00.000Z" }
 *                     created_at: { type: string, format: date-time, description: "When the run was recorded (UTC, ISO 8601).", example: "2026-07-11T12:00:00.000Z" }
 *             example:
 *               data:
 *                 id: "c1c10000-0000-0000-0000-000000000001"
 *                 status: "succeeded"
 *                 mode: "manual"
 *                 result_link: "https://example.test/runs/1"
 *                 external_flow_id: "flow-42"
 *                 blueprint_id: "b6b60000-0000-0000-0000-000000000001"
 *                 started_at: "2026-07-11T12:00:00.000Z"
 *                 finished_at: "2026-07-11T12:01:00.000Z"
 *                 created_at: "2026-07-11T12:00:00.000Z"
 *       401:
 *         description: Missing/unknown/deactivated token
 *         content:
 *           application/json:
 *             schema: { $ref: '#/components/schemas/PublicError' }
 *             example: { error: invalid_token }
 *       404:
 *         description: Not found, outside your granted scope, or NULL blueprint_id
 *         content:
 *           application/json:
 *             schema: { $ref: '#/components/schemas/PublicError' }
 *             example: { error: not_found }
 *       429:
 *         description: >
 *           Per-account budget exceeded — reads and writes draw on one shared
 *           per-minute budget. This response also carries `Retry-After`, which
 *           must be honoured before retrying. `RateLimit-*` headers appear on
 *           every response, but they describe two different budgets: on an
 *           authenticated response the per-account per-minute one, on an
 *           unauthenticated rejection a separate, longer-windowed budget keyed
 *           by source IP.
 *         content:
 *           application/json:
 *             schema: { $ref: '#/components/schemas/PublicError' }
 *             example: { error: rate_limited }
 */
// ── GET /runs + /runs/{id} ───────────────────────────────────────────────────
router.get('/runs', (req, res) => forwardRead(req, res, `${EDGE_BASE}/runs`, pageQuery(req)));
router.get('/runs/:id', (req, res) =>
  forwardRead(req, res, `${EDGE_BASE}/runs/${encodeURIComponent(req.params.id)}`, {}));

// Any other /api/public/v1 path past the gate is a public 404 (never the default
// Express HTML body).
router.use((_req, res) => res.status(404).json({ error: 'not_found' }));

// SECURITY [P2/M4]: a malformed percent-encoding in the path (e.g. `%ZZ`) makes
// Express throw a 400 URIError during route param decode — BEFORE any handler
// runs. Without this router-scoped error handler that error would fall through to
// the central infra error middleware and emit the INTERNAL apiError envelope
// (meta.db_type/provider) on a public path. Map every error surfacing on this
// router to the public error model: a client/decoding fault → validation_failed,
// anything else → edge_unreachable. Never the internal envelope.
router.use((err, _req, res, _next) => {
  if (res.headersSent) return;
  const status = err && (err.status || err.statusCode);
  if (err instanceof URIError || status === 400) {
    return res.status(400).json({ error: 'validation_failed' });
  }
  logger.error({ err: err && err.message }, 'public read router error');
  return res.status(503).json({ error: 'edge_unreachable' });
});

module.exports = router;
