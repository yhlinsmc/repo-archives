/**
 * entity-native-field-keys.js — the ONE list of native (non-custom) column
 * keys per `cap_field_defs` `entity_type` (fmb-1582; previously three
 * hand-maintained copies: this file's old inline home in
 * `edge/routes/app/capacity/_shared.js`, the frontend mirror, and — because
 * the mirror was short — a grid that could render two columns under the
 * same key).
 *
 * A custom field's `field_key` becomes an EXTRA grid column sharing the SAME
 * key namespace as these native columns (FE: capacity-field-defs.ts
 * `customFieldDefsToGridFields` merges an `inMetadata` column list alongside
 * the entity's native field list). A colliding key produces two grid columns
 * with the identical `key` — a broken/ambiguous UI (capacity-grid-adapter.ts
 * iterates the field list by array order, so whichever column comes second
 * silently wins the read AND the write for that cell) — so it is rejected
 * at the source instead (Review Gate finding, Codex r1). `metadata` itself
 * is included (the container column a custom value already lives inside)
 * and so is `id` (the row identity) even though neither appears in a
 * rendered field-def list. 'scenario' has NO entry: cap_scenarios carries no
 * `metadata` column at all, so entity_type 'scenario' is rejected outright
 * by the dedicated check in `_shared.js` rather than via a native-key
 * collision list.
 *
 * Every list here is every column `table-ddls.js` declares for that entity's
 * table — EXCEPT `vm`, which also carries `sga_ref`: not a `cap_vms` column,
 * but the KVMs grid's synthetic, client-rendered SGA reference column
 * (`src/fmb/capacity/lib/capacity-sga-ref.ts`, `vmFields()` in
 * capacity-field-defs.ts). Listed here anyway so a custom field_key of
 * "sga_ref" is refused at write time instead of landing as a second column
 * under the one key the derived cell already occupies (fmb-1582). This is
 * the ONE documented deviation — `vm`'s exception list in
 * `docker-api/tests/unit/entity-native-field-keys-ddl-parity.test.js` names
 * it explicitly rather than weakening the comparison, and every other
 * entity's list is asserted there to equal its table's DDL columns exactly
 * (fmb-1582 review wave: this claim was false for `database`, which was
 * missing `primary_sga_gb`/`standby_sga_gb`/`dc_refs` until that gap closed).
 *
 * ISOMORPHIC OBLIGATION: mirrored at
 * `src/fmb/capacity/lib/capacity-field-defs.ts` because the src/** Vite
 * bundle may not import docker-api/**. This file is the reference; the two
 * copies are compared field-for-field by
 * `src/fmb/capacity/lib/__tests__/entity-native-field-keys.parity.test.ts`
 * (vitest's CJS `require` can load this file directly — it declares no
 * dependency, so unlike `_shared.js` there is no DB pool to accidentally
 * pull into a frontend test run). That parity test only proves the two
 * copies agree with EACH OTHER — `entity-native-field-keys-ddl-parity.test.js`
 * is the one that proves this file agrees with the DDL itself.
 */
'use strict';

const ENTITY_NATIVE_FIELD_KEYS = Object.freeze({
  site: Object.freeze(['id', 'scenario_id', 'name', 'topology', 'order_index', 'metadata', 'created_at', 'updated_at']),
  hardware_spec: Object.freeze([
    'id', 'scenario_id', 'name', 'cpu_total', 'mem_total_gb', 'disk_total_gb',
    'cpu_reserved', 'mem_reserved_pct', 'disk_reserved_gb', 'order_index', 'metadata', 'created_at', 'updated_at',
  ]),
  hypervisor: Object.freeze(['id', 'scenario_id', 'site_id', 'spec_id', 'name', 'name_locked', 'order_index', 'metadata', 'created_at', 'updated_at']),
  vm: Object.freeze([
    'id', 'scenario_id', 'vm_type', 'hypervisor_id', 'site_id', 'cpu', 'mem_gb', 'disk_gb',
    'sizing_profile_id', 'disk_combo_id', 'team_id', 'database_id', 'name', 'name_locked', 'order_index', 'metadata', 'created_at', 'updated_at',
    'sga_ref',
  ]),
  db_instance: Object.freeze([
    'id', 'scenario_id', 'vm_id', 'database_id', 'name', 'role', 'sga_gb', 'order_index', 'metadata', 'created_at', 'updated_at',
  ]),
  // The first-class Database entity (config-rewrite §10) gains a metadata column
  // so custom fields may attach to it (spec §8). primary_sga_gb / standby_sga_gb /
  // dc_refs (fmb-1582 review wave) were missing here — real cap_databases columns
  // the Databases grid already renders (databaseFields in capacity-field-defs.ts),
  // so a custom field_key sharing one of those three names was NOT refused.
  database: Object.freeze([
    'id', 'scenario_id', 'function_name', 'topology', 'node_count', 'profile_id',
    'disk_combo_id', 'team_id', 'primary_sga_gb', 'standby_sga_gb', 'dc_refs',
    'description', 'order_index', 'metadata', 'created_at', 'updated_at',
  ]),
});

module.exports = { ENTITY_NATIVE_FIELD_KEYS };
