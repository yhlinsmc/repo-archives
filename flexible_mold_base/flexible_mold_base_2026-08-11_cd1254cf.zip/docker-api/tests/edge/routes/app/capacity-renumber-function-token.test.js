/**
 * capacity-renumber-function-token.test.js — cap-pattern-function (spec D2/D7):
 * renumber resolves the {function} token and the primary/standby pattern split
 * per db_host VM. Same mocked-pool harness as capacity-renumber-lock.test.js,
 * extended with cap_db_instances LEFT JOIN cap_databases (the {function}/role
 * resolution source).
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../../../src/edge/db');

let state;
function freshState() {
  return {
    queries: [],
    began: 0, committed: 0, rolledBack: 0, released: 0,
    scenarioExists: true,
    scenarioOwner: null,
    settingsColumns: ['id', 'scenario_id', 'name_patterns', 'mem_cpu_ratio'],
    entityColumns: ['id', 'name', 'order_index', 'site_id', 'vm_type', 'name_locked'],
    scenarioSettings: null,
    globalPatterns: null,
    sites: [{ id: 's1', name: 'DC' }],
    hypervisors: [],
    vms: [],
    // cap_db_instances rows: { vm_id, role, database_id }.
    dbInstances: [],
    // cap_databases rows: { id, function_name, order_index }.
    databases: [],
  };
}

function sortForSql(rows, sql) {
  const out = [...rows];
  if (/ORDER BY order_index/.test(sql)) {
    out.sort((a, b) => (a.order_index - b.order_index) || (a.id < b.id ? -1 : 1));
  } else if (/ORDER BY id FOR UPDATE/.test(sql)) {
    out.sort((a, b) => (a.id < b.id ? -1 : a.id > b.id ? 1 : 0));
  }
  return out;
}

function makeConn() {
  return {
    async beginTransaction() { state.began += 1; },
    async commit() { state.committed += 1; },
    async rollback() { state.rolledBack += 1; },
    release() { state.released += 1; },
    async query(sql, params = []) {
      state.queries.push({ sql, params });

      if (/information_schema\.COLUMNS/.test(sql)) {
        if (params[0] === 'fmb_cap_settings') return state.settingsColumns.map((name) => ({ name }));
        return state.entityColumns.map((name) => ({ name }));
      }
      if (/SELECT id, owner_id FROM `fmb_cap_scenarios` WHERE id = \?/.test(sql)) {
        return state.scenarioExists ? [{ id: params[0], owner_id: state.scenarioOwner }] : [];
      }
      if (/SELECT scenario_id, name_patterns FROM `fmb_cap_settings` WHERE scenario_id = \?/.test(sql)) {
        return state.scenarioSettings
          ? [{ scenario_id: params[0], name_patterns: state.scenarioSettings.name_patterns }]
          : [];
      }
      if (/SELECT scenario_id, name_patterns FROM `fmb_cap_settings` WHERE scenario_id IS NULL/.test(sql)) {
        return [{ scenario_id: null, name_patterns: state.globalPatterns }];
      }
      if (/SELECT id, name FROM `fmb_cap_sites` WHERE scenario_id = \?/.test(sql)) {
        return state.sites.map((s) => ({ id: s.id, name: s.name }));
      }
      if (/FROM `fmb_cap_hypervisors` WHERE scenario_id = \?/.test(sql)) {
        return sortForSql(state.hypervisors, sql).map((r) => ({ ...r }));
      }
      if (/FROM `fmb_cap_vms` WHERE scenario_id = \?/.test(sql)) {
        return sortForSql(state.vms, sql).map((r) => ({ ...r }));
      }
      // The {function}/role resolution source (Task 2.3): cap_db_instances LEFT
      // JOIN cap_databases. Emulate the LEFT JOIN in JS — an instance with no
      // resolvable database still returns a row (nulls for the joined columns).
      if (/FROM `fmb_cap_db_instances` di/.test(sql) && /LEFT JOIN `fmb_cap_databases` d/.test(sql)) {
        return state.dbInstances.map((inst) => {
          const db = state.databases.find((d) => d.id === inst.database_id) || null;
          return {
            vmId: inst.vm_id,
            role: inst.role,
            functionName: db ? db.function_name : null,
            dbOrderIndex: db ? db.order_index : null,
            dbId: db ? db.id : null,
          };
        });
      }
      if (/^UPDATE `fmb_cap_\w+` SET name = \? WHERE id = \? AND scenario_id = \?/.test(sql)) {
        return { affectedRows: 1 };
      }
      return [];
    },
  };
}

const conn = makeConn();
const poolFacade = {
  getConnection: async () => conn,
  query: (sql, params) => conn.query(sql, params),
};
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: { ro: poolFacade, rw: poolFacade }, t: (n) => `fmb_${n}` },
};

const router = require('../../../../src/edge/routes/app/capacity');
const { _resetColumnSetCache } = require('../../../../src/edge/routes/app/capacity/_shared');
// Same resolved module renumber.js already loaded (via the aggregate router
// above) — the cached export carries the test-only shape-assertion hook.
const renumberRouter = require('../../../../src/edge/routes/app/capacity/renumber');

let currentUser; let server; let baseUrl;
before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { req.user = currentUser; next(); });
  app.use('/capacity', router);
  server = http.createServer(app);
  await new Promise((r) => server.listen(0, r));
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});
after(() => server && server.close());
beforeEach(() => {
  state = freshState();
  currentUser = { id: 'u-admin', role: 'admin' };
  _resetColumnSetCache();
});

function request(method, path, body) {
  return new Promise((resolve, reject) => {
    const payload = body === undefined ? '' : JSON.stringify(body);
    const r = http.request(
      `${baseUrl}${path}`,
      { method, headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) } },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          const raw = Buffer.concat(chunks).toString('utf8');
          let json = null;
          try { json = JSON.parse(raw); } catch { /* noop */ }
          resolve({ status: res.statusCode, json, raw });
        });
      },
    );
    r.on('error', reject);
    if (payload) r.write(payload);
    r.end();
  });
}

const PREVIEW = '/capacity/scenarios/scn-1/renumber-preview';
const APPLY = '/capacity/scenarios/scn-1/renumber';

describe('renumber {function} resolution + role pattern (cap-pattern-function D2/D7)', () => {
  it('a host with instances of two DBs picks the FIRST by display order (order_index), not insertion order', async () => {
    state.vms = [{ id: 'k1', name: 'old-k1', order_index: 0, site_id: 's1', vm_type: 'db_host', name_locked: 0 }];
    state.databases = [
      { id: 'db-crm', function_name: 'crm', order_index: 2 },
      { id: 'db-erp', function_name: 'erp', order_index: 1 },
    ];
    state.dbInstances = [
      { vm_id: 'k1', role: 'primary', database_id: 'db-crm' },
      { vm_id: 'k1', role: 'primary', database_id: 'db-erp' },
    ];
    const res = await request('POST', PREVIEW, {});
    assert.equal(res.status, 200, res.raw);
    const k1 = res.json.data.find((p) => p.id === 'k1');
    assert.equal(k1.newName, 'erp-dc-01'); // erp (order_index 1) wins over crm (order_index 2)
  });

  it('a host with ONLY standby instances uses the standby pattern (kvm-style, unaffected by {function})', async () => {
    state.vms = [{ id: 'k1', name: 'old-k1', order_index: 0, site_id: 's1', vm_type: 'db_host', name_locked: 0 }];
    state.databases = [{ id: 'db-fin', function_name: 'fin', order_index: 0 }];
    state.dbInstances = [{ vm_id: 'k1', role: 'standby', database_id: 'db-fin' }];
    const res = await request('POST', PREVIEW, {});
    const k1 = res.json.data.find((p) => p.id === 'k1');
    assert.equal(k1.newName, 'kvm-dc-01');
  });

  it('a host with at least one primary instance uses the primary pattern, even if it also has a standby', async () => {
    state.vms = [{ id: 'k1', name: 'old-k1', order_index: 0, site_id: 's1', vm_type: 'db_host', name_locked: 0 }];
    state.databases = [{ id: 'db-hrm', function_name: 'hrm', order_index: 0 }];
    state.dbInstances = [
      { vm_id: 'k1', role: 'standby', database_id: 'db-hrm' },
      { vm_id: 'k1', role: 'primary', database_id: 'db-hrm' },
    ];
    const res = await request('POST', PREVIEW, {});
    const k1 = res.json.data.find((p) => p.id === 'k1');
    assert.equal(k1.newName, 'hrm-dc-01');
  });

  it('an empty db_host (no instances at all) uses the primary pattern, {function} falls back to kvm (D7)', async () => {
    state.vms = [{ id: 'k1', name: 'old-k1', order_index: 0, site_id: 's1', vm_type: 'db_host', name_locked: 0 }];
    // No dbInstances rows reference k1.
    const res = await request('POST', PREVIEW, {});
    const k1 = res.json.data.find((p) => p.id === 'k1');
    assert.equal(k1.newName, 'kvm-dc-01');
  });

  it('primary and standby hosts form INDEPENDENT seq streams, reassembled into original display order', async () => {
    state.vms = [
      { id: 'k1', name: 'old-k1', order_index: 0, site_id: 's1', vm_type: 'db_host', name_locked: 0 }, // primary
      { id: 'k2', name: 'old-k2', order_index: 1, site_id: 's1', vm_type: 'db_host', name_locked: 0 }, // standby
      { id: 'k3', name: 'old-k3', order_index: 2, site_id: 's1', vm_type: 'db_host', name_locked: 0 }, // primary (empty, fallback)
    ];
    state.databases = [{ id: 'db-erp', function_name: 'erp', order_index: 0 }];
    state.dbInstances = [
      { vm_id: 'k1', role: 'primary', database_id: 'db-erp' },
      { vm_id: 'k2', role: 'standby', database_id: 'db-erp' },
    ];
    const res = await request('POST', PREVIEW, {});
    assert.equal(res.status, 200, res.raw);
    const byId = Object.fromEntries(res.json.data.map((p) => [p.id, p]));
    assert.equal(byId.k1.newName, 'erp-dc-01'); // primary group, seq 1
    assert.equal(byId.k2.newName, 'kvm-dc-01'); // standby group, its OWN seq 1
    assert.equal(byId.k3.newName, 'kvm-dc-02'); // primary group (empty→fallback), seq 2
    // Original display order preserved in the response (k1, k2, k3 — not
    // primary-group-then-standby-group).
    assert.deepEqual(res.json.data.filter((p) => p.entityType === 'kvm_host').map((p) => p.id), ['k1', 'k2', 'k3']);
  });

  it('an ap_vm host never resolves a real {function} (no db instance can ever be placed on it) — always the fallback', async () => {
    state.vms = [{ id: 'a1', name: 'old-a1', order_index: 0, site_id: null, vm_type: 'ap_host', name_locked: 0 }];
    const res = await request('POST', PREVIEW, {});
    const a1 = res.json.data.find((p) => p.id === 'a1');
    assert.equal(a1.newName, 'ap-01');
  });

  it('apply recomputes {function}/role the same way as preview and writes the resolved names', async () => {
    state.vms = [{ id: 'k1', name: 'old-k1', order_index: 0, site_id: 's1', vm_type: 'db_host', name_locked: 0 }];
    state.databases = [{ id: 'db-erp', function_name: 'erp', order_index: 0 }];
    state.dbInstances = [{ vm_id: 'k1', role: 'primary', database_id: 'db-erp' }];
    const res = await request('POST', APPLY, {});
    assert.equal(res.status, 200, res.raw);
    const renamed = res.json.data.renamed.find((r) => r.id === 'k1');
    assert.equal(renamed.newName, 'erp-dc-01');
  });

  it('H1: an empty (primary-fallback) host and a standby-only host at the SAME dc never collide, deterministic regardless of row order', async () => {
    // Under D8 defaults BOTH groups fall back to the identical literal
    // "kvm-{dc}-{seq:2}" for their first member: the empty primary host has no
    // {function} to resolve (D7 fallback = kvm), and kvm_host_standby is
    // kvm-style regardless of {function}. Two independent computeRenumberPlan
    // calls, each starting its own seq at 1, would both propose "kvm-dc-01".
    state.vms = [
      { id: 'k1', name: 'old-k1', order_index: 0, site_id: 's1', vm_type: 'db_host', name_locked: 0 }, // empty -> primary fallback
      { id: 'k2', name: 'old-k2', order_index: 1, site_id: 's1', vm_type: 'db_host', name_locked: 0 }, // standby-only
    ];
    state.databases = [{ id: 'db-fin', function_name: 'fin', order_index: 0 }];
    state.dbInstances = [{ vm_id: 'k2', role: 'standby', database_id: 'db-fin' }];
    const preview = await request('POST', PREVIEW, {});
    assert.equal(preview.status, 200, preview.raw);
    const byId = Object.fromEntries(preview.json.data.map((p) => [p.id, p]));
    // Primary group is resolved first regardless of row order (deterministic).
    assert.equal(byId.k1.newName, 'kvm-dc-01');
    assert.equal(byId.k2.newName, 'kvm-dc-02');
    assert.equal(byId.k1.duplicate, false);
    assert.equal(byId.k2.duplicate, false);

    const apply = await request('POST', APPLY, {});
    assert.equal(apply.status, 200, apply.raw); // no 409 — apply succeeds, not blocked
    assert.equal(apply.json.data.applied, 2);
  });

  it('P1b (Codex r1): a LOCKED standby host is reserved for the PRIMARY group too, even though primary runs first with no seed', async () => {
    // k2 (standby) holds the locked name the primary group would otherwise
    // fall back to first (kvm-dc-01). k1 (empty -> primary fallback) must skip
    // it, not collide with it.
    state.vms = [
      { id: 'k1', name: 'old-k1', order_index: 0, site_id: 's1', vm_type: 'db_host', name_locked: 0 }, // empty -> primary fallback
      { id: 'k2', name: 'kvm-dc-01', order_index: 1, site_id: 's1', vm_type: 'db_host', name_locked: 1 }, // locked standby
    ];
    state.databases = [{ id: 'db-fin', function_name: 'fin', order_index: 0 }];
    state.dbInstances = [{ vm_id: 'k2', role: 'standby', database_id: 'db-fin' }];
    const preview = await request('POST', PREVIEW, {});
    assert.equal(preview.status, 200, preview.raw);
    const byId = Object.fromEntries(preview.json.data.map((p) => [p.id, p]));
    assert.equal(byId.k1.newName, 'kvm-dc-02'); // skips the locked standby's name
    assert.equal(byId.k2.newName, 'kvm-dc-01'); // locked, unchanged
    assert.equal(byId.k1.duplicate, false);
    assert.equal(byId.k2.duplicate, false);

    const apply = await request('POST', APPLY, {});
    assert.equal(apply.status, 200, apply.raw); // no 409
    assert.equal(apply.json.data.applied, 1); // only k1 renumbers; k2 is locked
  });

  it('P1a (Codex r1): 3 empty primary hosts (kvm-dc-01..03 fallback) push a same-dc standby host to kvm-dc-04, not a duplicate', async () => {
    state.vms = [
      { id: 'k1', name: 'old-k1', order_index: 0, site_id: 's1', vm_type: 'db_host', name_locked: 0 }, // empty -> primary
      { id: 'k2', name: 'old-k2', order_index: 1, site_id: 's1', vm_type: 'db_host', name_locked: 0 }, // empty -> primary
      { id: 'k3', name: 'old-k3', order_index: 2, site_id: 's1', vm_type: 'db_host', name_locked: 0 }, // empty -> primary
      { id: 'k4', name: 'old-k4', order_index: 3, site_id: 's1', vm_type: 'db_host', name_locked: 0 }, // standby
    ];
    state.databases = [{ id: 'db-fin', function_name: 'fin', order_index: 0 }];
    state.dbInstances = [{ vm_id: 'k4', role: 'standby', database_id: 'db-fin' }];
    const preview = await request('POST', PREVIEW, {});
    assert.equal(preview.status, 200, preview.raw);
    const byId = Object.fromEntries(preview.json.data.map((p) => [p.id, p]));
    assert.equal(byId.k1.newName, 'kvm-dc-01');
    assert.equal(byId.k2.newName, 'kvm-dc-02');
    assert.equal(byId.k3.newName, 'kvm-dc-03');
    assert.equal(byId.k4.newName, 'kvm-dc-04'); // standby group's own seq, past the 3 seeded names
    assert.equal(byId.k4.duplicate, false);

    const apply = await request('POST', APPLY, {});
    assert.equal(apply.status, 200, apply.raw); // no 409
    assert.equal(apply.json.data.applied, 4);
  });

  it('an instance whose database_id is dangling/null still counts toward role, just not toward {function}', async () => {
    state.vms = [{ id: 'k1', name: 'old-k1', order_index: 0, site_id: 's1', vm_type: 'db_host', name_locked: 0 }];
    state.dbInstances = [{ vm_id: 'k1', role: 'primary', database_id: null }]; // no matching database row
    const res = await request('POST', PREVIEW, {});
    const k1 = res.json.data.find((p) => p.id === 'k1');
    // Still primary (an instance exists), function falls back since no database resolved.
    assert.equal(k1.newName, 'kvm-dc-01');
  });
});

describe('RENUMBER_TABLES entity shape (L3)', () => {
  it('accepts an entity with roleAware:true and no patternKey', () => {
    assert.doesNotThrow(() => renumberRouter._assertRenumberEntitiesShape([
      { entities: [{ entityType: 'kvm_host', roleAware: true }] },
    ]));
  });
  it('accepts an entity with a string patternKey and no roleAware', () => {
    assert.doesNotThrow(() => renumberRouter._assertRenumberEntitiesShape([
      { entities: [{ entityType: 'ap_vm', patternKey: 'ap_vm' }] },
    ]));
  });
  it('rejects an entity with NEITHER roleAware nor patternKey (the undefined-name hazard)', () => {
    assert.throws(() => renumberRouter._assertRenumberEntitiesShape([
      { entities: [{ entityType: 'future_entity' }] },
    ]), /future_entity/);
  });
  it('rejects an entity with BOTH roleAware:true and a patternKey (ambiguous)', () => {
    assert.throws(() => renumberRouter._assertRenumberEntitiesShape([
      { entities: [{ entityType: 'ambiguous', roleAware: true, patternKey: 'x' }] },
    ]), /ambiguous/);
  });
  it('the real RENUMBER_TABLES already passed this assertion at module load (no throw)', () => {
    // If it hadn't, requiring renumber.js above would already have thrown.
    assert.ok(renumberRouter, 'module loaded');
  });
});
