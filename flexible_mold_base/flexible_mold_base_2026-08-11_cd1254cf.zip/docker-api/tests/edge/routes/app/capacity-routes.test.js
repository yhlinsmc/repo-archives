/**
 * capacity-routes.test.js — Capacity Planner backend route behaviour (PR-A).
 *
 * Covers the spec §7 route split against a mock edge/db:
 *   1. Config (template) write role gating: editor OK, plain user 403, admin OK;
 *      writes force scenario_id = NULL and reads scope to scenario_id IS NULL.
 *   2. Scenario create owner-scoping: editor stamps self, admin stays NULL (shared),
 *      plain user 403.
 *   3. Deep-copy on scenario create: every scenario_id IS NULL template row is
 *      copied into a NEW row (new id + new scenario_id) — template rows are never
 *      mutated, so a later template edit cannot retro-propagate.
 *   4. Scenario-scoped child parentOwnership: owner editor OK, other editor 403,
 *      admin OK; the write's scenario_id is bound to the URL param.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

// ── Mock edge/db BEFORE requiring the capacity router (which pulls schema.js) ──
const dbKey = require.resolve('../../../../src/edge/db');

// A generous column superset so the generic CRUD factory's additive-column gate
// accepts every field the tests POST (the factory intersects body cols ∩ this).
const CAP_COLUMNS = [
  'id', 'scenario_id', 'name', 'note', 'owner_id', 'topology', 'metadata',
  'site_id', 'spec_id', 'hypervisor_id', 'spec_total', 'cpu_total', 'mem_total_gb',
  'disk_total_gb', 'cpu_reserved', 'mem_reserved_pct', 'disk_reserved_gb',
  'vm_type', 'cpu', 'mem_gb', 'disk_gb', 'sizing_profile_id', 'vm_id', 'role',
  'sga_gb', 'type', 'params', 'severity', 'enabled',
  'entity_type', 'field_key', 'label',
  'data_type', 'options', 'mem_cpu_ratio',
  'util_amber_pct', 'util_red_pct', 'overcommit_default_enabled', 'layer_defaults',
  'object_set_key', 'rule_id', 'snapshot', 'created_by', 'created_at', 'updated_at',
  // Config-rewrite columns.
  'disk_combo_id', 'team_id', 'database_id', 'class', 'mode', 'sga_cap_gb',
  'allowed_disk_combos', 'sizes', 'color', 'function_name', 'node_count',
  'profile_id', 'description', 'group_id', 'member_vm_id', 'member_instance_id',
  'level', 'group_by', 'custom_group_id', 'overrides_rule_id', 'filters',
  'required', 'default_value', 'sga_factor', 'sga_divisor', 'sga_subtract',
  'serial', 'bundle_id', 'qty', 'prefill_custom_group',
  // Phase-2 columns (spec §6.1, PR-1 DDL).
  'order_index', 'primary_sga_gb', 'standby_sga_gb', 'dc_refs', 'standby_sga_default_gb',
  // cap-renumber-lock (spec D1): name_locked on cap_hypervisors / cap_vms.
  'name_locked',
].map((c) => ({ COLUMN_NAME: c }));

// Per-test mutable state.
let state;
function freshState() {
  return {
    queries: [],            // { sql, params }
    scenarioOwner: undefined, // owner_id returned by the parentOwnership chain SELECT
    scenarioOwnerRows: null,  // set to [] to simulate "scenario not found"
    templateRows: {},       // fmt: { cap_rules: [rows], ... } for scenario_id IS NULL SELECTs
    updateAffected: 1,
    deleteAffected: 1,
    fkExists: true,         // FK-validation probe: does the referenced row exist in-scenario?
    fkVmType: 'db_host',    // vm_type returned by the FK probe (db_instances.vm_id check)
    settingsGlobalExists: false, // singleton: the atomic INSERT..NOT EXISTS inserts 0 rows when true
    deleteScenarioRows: undefined, // owner FOR UPDATE rows for the cascade delete
    scenarioExists: true,   // makeScenarioExistsGuard: does the URL scenario exist?
    scenarioCanonicalId: '26895068-65f1-405c-8521-2a9e1212353c', // the id cap_scenarios actually holds, read back by that guard
    rowScenario: '26895068-65f1-405c-8521-2a9e1212353c',   // makeRowScenarioBinding: the row's stored scenario_id
    rowBindingRows: undefined, // set [] to simulate the row not existing at all
    vmHasInstances: false,  // makeVmTypeFlipLockValidator: does the VM still own db_instances?
    childRowExists: true,   // makeChildDelete: is the row present in the scenario?
    blockerExists: false,   // makeChildDelete block[] AND the sites sweep's hypervisor group: is the parent still referenced?
    siteRefCounts: undefined, // sites sweep: per-table reference counts (see the handler below); undefined ⇒ derived from blockerExists
    ruleRefsGroup: false,   // custom_groups delete block: does a rule reference the group?
    settingsExists: false,  // PR-B Task 1: does a cap_settings row already exist for the scenario?
    settingsRowNamePatterns: undefined, // fmb-1686: name_patterns value merged onto the static scenario-settings fixture row (surfaces 3/4)
    fieldDefExisting: undefined, // codex-r1/r2: { entity_type, field_key, data_type, options } the PUT-merge check reads for a cap_field_defs row
    fieldDefDuplicateExists: false, // codex-r2: does ANOTHER row already own the (scenario_id, entity_type, field_key) tuple?
    overrideDuplicateExists: false, // R1.11 H1: does an override row already exist for (scenario, overrides_rule_id)?
    ruleExisting: undefined,   // R1.13 Fix 2: { type, level, group_by } the cap_rules PUT-merge check reads
    memberExisting: undefined, // R1.13 Fix 3: { member_vm_id, member_instance_id } the custom_group_members PUT-merge XOR check reads
    overrideTarget: undefined, // R1.14 #1: { type, name, level, group_by } the override-fill guard reads from the target global rule
    insertDuplicateError: false, // R1.14 #3: a cap_rules INSERT trips the UNIQUE (scenario_id, overrides_rule_id) index → errno 1062
    fieldDefInsertDuplicate: false, // fmb-0140: a cap_field_defs INSERT trips the UNIQUE (scenario_id, entity_type, field_key) index → errno 1062
    fieldDefInsertGenericError: false, // fmb-0140: a cap_field_defs INSERT fails with a NON-1062 DB error (must still 500)
    rollbackThrows: false,       // fmb-0200/0222: conn.rollback() itself throws — safeRollback must swallow it, never mask the original outcome
    scenarioRows: undefined,   // PR-E: { sites:[...], hypervisors:[...], ... } for the snapshot/live-clone SELECT * WHERE scenario_id = ? read
    // R2: bundles + local-catalogue + config-delete-guard fixtures.
    bundleRows: undefined,        // GET /config/bundles list rows
    bundleItemRows: undefined,    // bundle-item list rows (ORDER BY order_index)
    bundleById: undefined,        // GET /config/bundles/:id single row
    bundleExists: true,           // item POST parent-check + bundle delete lock
    bundleItemExists: true,       // item PUT belongs-to-bundle check
    bundleItemType: 'DB',         // stored type on the PUT belongs-to probe (merged-class check)
    bundleItemProfileId: null,    // stored profile_id on the PUT belongs-to probe
    bundleItemDiskComboId: null,  // stored disk_combo_id on the PUT belongs-to probe (merged disk-combo check)
    bundleItemTopology: null,     // stored topology on the PUT probe (merged coupling check)
    bundleItemNodeCount: null,    // stored node_count on the PUT probe (merged coupling check)
    bundleItemPrimarySga: null,   // stored primary_sga_gb on the PUT probe (merged DB-only SGA check, P2-4)
    bundleItemStandbySga: null,   // stored standby_sga_gb on the PUT probe (merged DB-only SGA check, P2-4)
    profileClass: 'DB',           // class returned by the item→profile class probe
    nextSerial: 1,                // COALESCE(MAX(serial),0)+1 auto-assign
    configRowExists: true,        // config guarded-delete row lock (scenario_id IS NULL)
    catalogueBlockerExists: false, // findCatalogueReferenceBlocker probe (SELECT 1 AS ref)
    configEmpty: true,             // phase-2 A2: isGlobalConfigEmpty aggregate gate result
    profileAllowedCombos: undefined, // TA.2: allowed_disk_combos JSON returned by the disk-combo check (undefined → profile row absent → accept)
    diskComboExistingRow: undefined, // TA.2: { profile_id, disk_combo_id } the PUT-merge FOR-UPDATE read returns (undefined → no existing row → skip)
    sourceScenarioRow: undefined, // PR-E: rows for `SELECT name, note FROM cap_scenarios WHERE id = ?` (live clone source)
    versionRow: undefined,     // PR-E: rows for a cap_versions read (GET one / version-clone snapshot source)
    versionListRows: undefined, // PR-E: rows for the metadata list SELECT (GET /versions)
    userNames: {},             // PR-E: id → display_name for the created_by enrichment probe
    listRows: undefined,       // phase-2 PR-3: { sites:[...], ... } for the generic children.js LIST GET (schema.js factory, WHERE scenario_id = ? ORDER BY ...) — keyed by table suffix, undefined ⇒ [] (every pre-existing test unaffected)
    dbInstanceDatabaseRow: undefined, // Codex-r1 P1: { primary_sga_gb, standby_sga_gb, profile_id } the db_instances CREATE sga-deriver reads (undefined ⇒ [] ⇒ no database row)
    capSettingsScenarioRow: undefined, // Codex-r2 P1-1: the scenario-EFFECTIVE cap_settings row (scenario override wins) — set to model a local override
    capSettingsGlobalRow: undefined,  // Codex-r1 P1: the global cap_settings row (standby default + formula constants) the sga-deriver falls back to
    cascadeDatabaseRow: undefined,    // phase-7 item 6: the just-updated database row (NEW SGA + profile_id + scenario_id) the SGA cascade re-reads (undefined ⇒ [] ⇒ cascade no-op)
    cascadeInstances: undefined,      // phase-7 item 6: the CURRENT child rows ({ role, sga_gb }) the SGA cascade locks + compares (undefined ⇒ [] ⇒ nothing to update)
    siteOrderIndices: undefined,      // Codex-r1 P2: existing cap_sites order_index values driving the append MAX+1 (undefined ⇒ empty ⇒ first append = 0)
    configOrderIndices: undefined,    // codex-P2: existing GLOBAL cap_<table> order_index values (config.js POST append, scenario_id IS NULL) — keyed by table (e.g. cap_teams); undefined ⇒ empty ⇒ first append = 0
    hostSiteRow: undefined,           // the host's data centre, read by children.js deriveVmSiteFromHost when the write NAMES a host (undefined ⇒ [] ⇒ no host row ⇒ derives nothing)
    vmStoredHostRow: undefined,       // the placement AND cache a partial `{site_id}` PUT will leave the row in (undefined ⇒ [] ⇒ the row is unplaced ⇒ the operator's intended site stands)
    cascadeHostRow: undefined,        // the just-updated host's scenario, read by cascadeHypervisorSiteToVms before it repins that host's KVMs (undefined ⇒ [] ⇒ cascade no-op)
  };
}

function synthRowFromInsert(sql, params) {
  // Parse `INSERT INTO \`fmb_x\` (\`a\`, \`b\`) VALUES (?, ?)` → { a, b } from params.
  const m = sql.match(/\(([^)]*)\)\s*VALUES/i);
  const row = {};
  if (m) {
    const cols = m[1].split(',').map((c) => c.trim().replace(/`/g, ''));
    cols.forEach((c, i) => { row[c] = params[i]; });
  }
  return row;
}

const conn = {
  async beginTransaction() {},
  async commit() {},
  async rollback() { if (state.rollbackThrows) throw new Error('simulated rollback failure'); },
  release() {},
  async query(sql, params = []) {
    state.queries.push({ sql, params });

    if (/information_schema\.COLUMNS/i.test(sql)) return CAP_COLUMNS;
    if (/SELECT DATABASE\(\)/i.test(sql)) return [{ db: 'testdb' }];

    // parentOwnership chain SELECT (single hop into cap_scenarios).
    if (/FROM `fmb_cap_scenarios` j0/.test(sql)) {
      if (state.scenarioOwnerRows !== null) return state.scenarioOwnerRows;
      return [{ owner_id: state.scenarioOwner }];
    }

    // Cascade-delete + child-delete owner probe (SELECT owner_id ... FOR UPDATE).
    if (/SELECT (?:id, )?owner_id FROM `fmb_cap_scenarios` WHERE id = \? FOR UPDATE/.test(sql)) {
      return state.deleteScenarioRows !== undefined
        ? state.deleteScenarioRows
        : [{ id: state.scenarioCanonicalId, owner_id: state.scenarioOwner }];
    }

    // settings.js's own scenario-exists probe (GET), which is a different
    // statement from the child mounts' guard below.
    if (/SELECT 1 AS ok FROM `fmb_cap_scenarios` WHERE id = \?/.test(sql)) {
      return state.scenarioExists ? [{ ok: 1 }] : [];
    }

    // Scenario-exists guard (POST): SELECT id FROM cap_scenarios WHERE id=?.
    // It reads the id BACK now, because the URL segment resolves the scenario
    // under any spelling and the child row has to carry the one the scenario
    // itself holds. The double answers with the canonical id rather than
    // echoing the bound parameter — echoing it would report success for the
    // exact regression this reads back to prevent.
    if (/SELECT id FROM `fmb_cap_scenarios` WHERE id = \?$/.test(sql.trim())) {
      return state.scenarioExists ? [{ id: state.scenarioCanonicalId }] : [];
    }

    // Row-scenario binding (PUT): SELECT scenario_id FROM X WHERE id=? AND
    // scenario_id=?. The scope is part of the PREDICATE now, so the double
    // applies it the way the column would — folding case, and never matching a
    // NULL — instead of returning a row for the route to compare afterwards.
    if (/SELECT scenario_id FROM `fmb_cap_[a-z_]+` WHERE id = \? AND scenario_id = \?/.test(sql)) {
      if (state.rowBindingRows !== undefined) return state.rowBindingRows;
      const stored = state.rowScenario;
      const bound = params[1];
      return stored != null && bound != null
        && String(stored).toLowerCase() === String(bound).toLowerCase()
        ? [{ scenario_id: stored }] : [];
    }

    // vm_type flip guard: SELECT 1 FROM cap_db_instances WHERE vm_id=? AND scenario_id=? LIMIT 1.
    if (/SELECT 1 FROM `fmb_cap_db_instances` WHERE vm_id = \? AND scenario_id = \? LIMIT 1/.test(sql)) {
      return state.vmHasInstances ? [{ probe: 1 }] : [];
    }

    // childDelete blocker probe: SELECT 1 FROM cap_hypervisors WHERE `site_id`|`spec_id`=? ... LIMIT 1.
    if (/SELECT 1 FROM `fmb_cap_hypervisors` WHERE `(?:site_id|spec_id)` = \? AND scenario_id = \? LIMIT 1/.test(sql)) {
      return state.blockerExists ? [{ probe: 1 }] : [];
    }

    // The sites delete/preview reference sweep (site-references.js). It asks the
    // SAME two statements per group — an exact COUNT, then a bounded name list —
    // so the double answers both from one number per table. The tables it can be
    // asked about are read out of SITE_REFERENCE_GROUPS rather than listed here:
    // a group added to that declaration then arrives already answered instead of
    // falling through to `[]` and silently reporting "nothing references this".
    // The scope fragment is either `scenario_id = ?` or, for a globalScope group
    // (rule_site_pin), `(scenario_id IS NULL OR scenario_id = ?)`.
    {
      const scope = '(?:scenario_id = \\? AND |\\(scenario_id IS NULL OR scenario_id = \\?\\) AND )';
      const sweepCount = sql.match(new RegExp(`^SELECT COUNT\\(\\*\\) AS c FROM \`fmb_(cap_[a-z_]+)\` WHERE ${scope}`));
      const sweepNames = sql.match(new RegExp(`^SELECT id, \`[a-z_]+\` AS name FROM \`fmb_(cap_[a-z_]+)\` WHERE ${scope}[\\s\\S]*LIMIT \\?$`));
      const table = (sweepCount && sweepCount[1]) || (sweepNames && sweepNames[1]);
      if (table && SITE_REFERENCE_GROUPS.some((g) => String(g.table) === table)) {
        const fallback = table === 'cap_hypervisors' && state.blockerExists ? 1 : 0;
        const n = state.siteRefCounts && state.siteRefCounts[table] !== undefined
          ? state.siteRefCounts[table] : fallback;
        if (sweepCount) return [{ c: n }];
        return Array.from({ length: n }, (_, i) => ({ id: `${table}-${i}`, name: `${table}-${i}` }));
      }
    }

    // custom_groups childDelete blocker: SELECT 1 FROM cap_rules WHERE `custom_group_id`=? ... LIMIT 1.
    if (/SELECT 1 FROM `fmb_cap_rules` WHERE `custom_group_id` = \? AND scenario_id = \? LIMIT 1/.test(sql)) {
      return state.ruleRefsGroup ? [{ probe: 1 }] : [];
    }

    // childDelete row-in-scenario probe: SELECT id[, `<col>` AS entity_name] FROM
    // X WHERE id=? AND scenario_id=? FOR UPDATE. The optional display column feeds
    // the auto-snapshot label (spec §4); the double echoes the bound id.
    if (/SELECT id(?:, `[a-z_]+` AS entity_name)? FROM `fmb_cap_[a-z_]+` WHERE id = \? AND scenario_id = \? FOR UPDATE/.test(sql)) {
      return state.childRowExists ? [{ id: params[0], entity_name: 'x' }] : [];
    }

    // makeChildDelete will-delete pre-count: the rows a cascade removes, counted
    // before any mutation to decide the auto-snapshot threshold (spec §4). Covers
    // the flat `WHERE \`col\` = ?` form and the sweep-child nested
    // `WHERE \`col\` IN (SELECT id FROM parent …)` form. Defaults to 0 (these unit
    // tests exercise the statements, not the threshold).
    if (/^SELECT COUNT\(\*\) AS c FROM `fmb_cap_[a-z_]+` WHERE `[a-z_]+` (?:= \?|IN \(SELECT id FROM)/.test(sql.trim())) {
      return [{ c: state.willDeleteCount !== undefined ? state.willDeleteCount : 0 }];
    }

    // FK-by-convention validation probe (SELECT <1|vm_type> AS probe ... WHERE id=? AND scenario_id=?).
    if (/AS probe FROM `fmb_cap_[a-z_]+` WHERE id = \? AND scenario_id = \?/.test(sql)) {
      return state.fkExists ? [{ probe: state.fkVmType }] : [];
    }

    // §17.1a reference-integrity probe (SELECT id, scenario_id[, vm_type] FROM X
    // WHERE id = ?). Returns the referenced row's scenario_id so referenceOk can
    // judge scenario/catalogue/global mode. state.fkExists=false → not found →
    // reject; else the row's scenario_id defaults to the bound scenario ('26895068-65f1-405c-8521-2a9e1212353c'
    // → same-scenario passes) unless state.fkScenarioId overrides it (e.g. null
    // = a global catalogue row, or another scenario id to force a cross-scenario
    // reject). vm_type comes from state.fkVmType for the db_host guard.
    if (/SELECT id, scenario_id(?:, vm_type)?, \(scenario_id = \?\) AS same_scenario[\s\S]*FROM `fmb_cap_[a-z_]+` WHERE id = \?/.test(sql)) {
      if (!state.fkExists) return [];
      // (referencing scenario, referenced id) — the scope is bound FIRST now.
      const [referencingScenarioId, id] = params;
      const scenarioId = state.fkScenarioId !== undefined ? state.fkScenarioId : '26895068-65f1-405c-8521-2a9e1212353c';
      // Computed, not scripted: `same_scenario` is the engine's verdict, so a
      // fixture carrying a hand-written one would be asserting on itself. NULL
      // on either side yields NULL (not 0), exactly as `scenario_id = ?` does.
      const same = scenarioId == null || referencingScenarioId == null
        ? null
        : (String(scenarioId).toLowerCase() === String(referencingScenarioId).toLowerCase() ? 1 : 0);
      const row = { id, scenario_id: scenarioId, same_scenario: same };
      if (/vm_type/.test(sql)) row.vm_type = state.fkVmType;
      return [row];
    }

    // A KVM's data centre IS its host's, and children.js derives it from this
    // read (deriveVmSiteFromHost) whenever the write NAMES a host. Left
    // unanswered it fell to the default `[]`, the derivation read "a host with
    // no DC of its own" and returned without writing anything — so every mocked
    // case here exercised the hook's early exit and none of them the rule.
    // Distinct from the §17.1a probe above (that one projects `scenario_id`).
    if (/SELECT site_id FROM `fmb_cap_hypervisors` WHERE id = \? LIMIT 1 FOR UPDATE/.test(sql)) {
      return state.hostSiteRow !== undefined ? state.hostSiteRow : [];
    }
    // The other half of the same rule: a partial PUT naming only `site_id` asks
    // the ROW — the placement it will be left in, and the cache that stands with
    // it — under the lock the UPDATE needs anyway. Matched on the leading column
    // rather than the exact projection: anchoring a double on a full column list
    // is how adding one makes a suite pass by never seeing the statement.
    // Unanswered, this read said "unplaced" for every stored row, so the per-row
    // gate let a placed KVM's DC be hand-set.
    if (/SELECT hypervisor_id[a-z_, ]* FROM `fmb_cap_vms` WHERE id = \? FOR UPDATE/.test(sql)) {
      return state.vmStoredHostRow !== undefined ? state.vmStoredHostRow : [];
    }
    // A host moved to another data centre takes its KVMs along
    // (cascadeHypervisorSiteToVms). This is the scope read the cascade makes
    // before it writes; unanswered, the cascade returned before writing at all.
    if (/SELECT scenario_id FROM `fmb_cap_hypervisors` WHERE id = \? LIMIT 1/.test(sql)) {
      return state.cascadeHostRow !== undefined ? state.cascadeHostRow : [];
    }

    // Codex-r1 P1: db_instances CREATE server-derives sga_gb by role
    // (children.js deriveDbInstanceSgaOnCreate) — the database row (primary/
    // standby SGA + profile_id) and the global settings row (standby default +
    // formula) it reads in-tx. Distinct from the §17.1a FK probe above.
    if (/SELECT primary_sga_gb, standby_sga_gb, profile_id FROM `fmb_cap_databases` WHERE id = \? LIMIT 1/.test(sql)) {
      return state.dbInstanceDatabaseRow !== undefined ? state.dbInstanceDatabaseRow : [];
    }
    // phase-7 item 6: the SGA cascade re-reads the just-updated database row —
    // NEW primary/standby SGA + profile_id + scenario_id. Distinct from the
    // CREATE derivation read above (which omits scenario_id).
    if (/SELECT primary_sga_gb, standby_sga_gb, profile_id, scenario_id FROM `fmb_cap_databases` WHERE id = \? LIMIT 1/.test(sql)) {
      return state.cascadeDatabaseRow !== undefined ? state.cascadeDatabaseRow : [];
    }
    // phase-7 item 6: the SGA cascade locks the child instances (role + current
    // sga_gb) to compare against the re-derived value before writing.
    if (/SELECT role, sga_gb FROM `fmb_cap_db_instances` WHERE database_id = \? FOR UPDATE/.test(sql)) {
      return state.cascadeInstances !== undefined ? state.cascadeInstances : [];
    }
    // Codex-r2 P1-1: scenario-EFFECTIVE settings resolution (scenario override
    // row wins, else global) — SELECT * ... WHERE scenario_id = ? OR scenario_id
    // IS NULL ORDER BY scenario_id IS NULL LIMIT 1. Placed BEFORE the generic
    // `SELECT * FROM cap_settings WHERE scenario_id = ?` branch so it wins.
    if (/SELECT \* FROM `fmb_cap_settings` WHERE scenario_id = \? OR scenario_id IS NULL ORDER BY scenario_id IS NULL LIMIT 1/.test(sql)) {
      if (state.capSettingsScenarioRow !== undefined) return state.capSettingsScenarioRow;
      return state.capSettingsGlobalRow !== undefined ? state.capSettingsGlobalRow : [];
    }
    // Codex-r1 P2: sites CREATE appends order_index = MAX+1 in-tx; the scenario
    // FOR UPDATE lock is taken by makeScenarioRowLock (preWriteInTx, fmb-1685),
    // before the transform's MAX read.
    if (/SELECT id FROM `fmb_cap_scenarios` WHERE id = \? FOR UPDATE/.test(sql)) {
      return [{ id: params[0] }];
    }
    if (/SELECT COALESCE\(MAX\(order_index\), -1\) \+ 1 AS next FROM `fmb_cap_sites` WHERE scenario_id = \?/.test(sql)) {
      const existing = state.siteOrderIndices || [];
      return [{ next: (existing.length ? Math.max(...existing) : -1) + 1 }];
    }

    // codex-P2: global catalogue create appends order_index = MAX+1 (config.js
    // POST, the 4 ORDERABLE_CONFIG_GROUPS, scenario_id IS NULL scope) — distinct
    // from the scenario-scoped sites/bundle-item append queries above (those
    // scope on scenario_id = ?) and the bundles append below (no scope at all,
    // cap_bundles is global-only).
    const globalOrderMax = sql.match(/SELECT COALESCE\(MAX\(order_index\), -1\) \+ 1 AS next FROM `fmb_(cap_[a-z_]+)` WHERE scenario_id IS NULL$/);
    if (globalOrderMax) {
      const existing = (state.configOrderIndices && state.configOrderIndices[globalOrderMax[1]]) || [];
      return [{ next: (existing.length ? Math.max(...existing) : -1) + 1 }];
    }

    // TA.2 disk-combo allow-list: the profile's allowed_disk_combos read (child
    // vms/databases write check). undefined → no profile row → accept (soft).
    if (/SELECT allowed_disk_combos FROM `fmb_cap_vm_profiles` WHERE id = \?/.test(sql)) {
      return state.profileAllowedCombos !== undefined ? [{ allowed_disk_combos: state.profileAllowedCombos }] : [];
    }
    // TA.2 disk-combo allow-list: the PUT-merge existing-row FOR UPDATE read
    // (SELECT <profileCol> AS profile_id, disk_combo_id). undefined → no row → skip.
    if (/SELECT `(?:sizing_profile_id|profile_id)` AS profile_id, disk_combo_id FROM `fmb_cap_(?:vms|databases)` WHERE id = \? AND scenario_id = \? FOR UPDATE/.test(sql)) {
      return state.diskComboExistingRow !== undefined ? [state.diskComboExistingRow] : [];
    }

    // R2 config-layer delete guard: catalogue reference probe (SELECT 1 AS ref
    // FROM cap_Y WHERE <col> = ? LIMIT 1). Distinguished by `1 AS ref` and the
    // absence of a scenario_id predicate. Also serves the local-catalogue delete.
    if (/SELECT 1 AS ref FROM `fmb_cap_[a-z_]+` WHERE `[a-z_]+` = \? LIMIT 1/.test(sql)) {
      return state.catalogueBlockerExists ? [{ ref: 1 }] : [];
    }

    // R2 config guarded-delete row lock (SELECT id FROM cap_X WHERE id = ? AND
    // scenario_id IS NULL FOR UPDATE) — distinct from the child row-in-scenario
    // probe (scenario_id = ?).
    if (/SELECT id FROM `fmb_cap_[a-z_]+` WHERE id = \? AND scenario_id IS NULL FOR UPDATE/.test(sql)) {
      return state.configRowExists ? [{ id: params[0] }] : [];
    }

    // R2 bundles: serial auto-assign.
    if (/SELECT COALESCE\(MAX\(serial\), 0\) \+ 1 AS next FROM `fmb_cap_bundles`/.test(sql)) {
      return [{ next: state.nextSerial }];
    }
    // phase-6 §D3 (1.5b): bundle create appends order_index = MAX+1.
    if (/SELECT COALESCE\(MAX\(order_index\), -1\) \+ 1 AS next FROM `fmb_cap_bundles`/.test(sql)) {
      return [{ next: state.nextBundleOrderIndex ?? 0 }];
    }
    // R2 bundles: list (GET /config/bundles) + per-bundle items list. Phase-6
    // §D3 (1.5b) reordered the read to ORDER BY order_index ASC, serial ASC.
    if (/SELECT \* FROM `fmb_cap_bundles` ORDER BY order_index ASC/.test(sql)) {
      return state.bundleRows || [];
    }
    if (/SELECT \* FROM `fmb_cap_bundle_items` ORDER BY order_index ASC/.test(sql)) {
      return state.bundleItemRows || [];
    }
    if (/SELECT \* FROM `fmb_cap_bundle_items` WHERE bundle_id = \? ORDER BY/.test(sql)) {
      return state.bundleItemRows || [];
    }
    // R2 bundles: GET /config/bundles/:id single row.
    if (/SELECT \* FROM `fmb_cap_bundles` WHERE id = \?/.test(sql)) {
      if (state.bundleById !== undefined) return state.bundleById;
      // Post-write read-back (create/update) synthesizes from the last INSERT.
      const lastInsert = [...state.queries].reverse().find((q) => /^INSERT INTO `fmb_cap_bundles`/.test(q.sql));
      return lastInsert ? [synthRowFromInsert(lastInsert.sql, lastInsert.params)] : [];
    }
    // R2 bundles: parent-exists probe (item POST) + delete lock (SELECT id ...).
    if (/SELECT id FROM `fmb_cap_bundles` WHERE id = \?( FOR UPDATE)?$/.test(sql)) {
      return state.bundleExists ? [{ id: params[0] }] : [];
    }
    // R2 bundles: item belongs-to-bundle probe (item PUT) — reads the stored
    // type/profile_id (merged-class check) + topology/node_count (merged
    // topology/node_count coupling check).
    if (/SELECT id, type, profile_id, disk_combo_id, topology, node_count, primary_sga_gb, standby_sga_gb FROM `fmb_cap_bundle_items` WHERE id = \? AND bundle_id = \?/.test(sql)) {
      return state.bundleItemExists
        ? [{
            id: params[0], type: state.bundleItemType, profile_id: state.bundleItemProfileId,
            disk_combo_id: state.bundleItemDiskComboId, topology: state.bundleItemTopology, node_count: state.bundleItemNodeCount,
            primary_sga_gb: state.bundleItemPrimarySga ?? null, standby_sga_gb: state.bundleItemStandbySga ?? null,
          }]
        : [];
    }
    // R2 bundles: item→profile class probe (SELECT class FROM cap_vm_profiles).
    if (/SELECT class FROM `fmb_cap_vm_profiles` WHERE id = \?/.test(sql)) {
      return state.profileClass !== undefined ? [{ class: state.profileClass }] : [];
    }

    // Phase-2 A2: config-import commit serialization lock on the cap_settings
    // singleton sentinel (SELECT id FROM cap_settings FOR UPDATE, no WHERE).
    if (/SELECT id FROM `fmb_cap_settings` FOR UPDATE/.test(sql)) {
      return [{ id: '57ca51a5-a0f3-432c-8dbd-670d3f5c627d' }];
    }
    // Phase-2 A2: isGlobalConfigEmpty catalogue-count gate (config import). The
    // aggregate now covers the seven no-seed catalogues only; settings + rules
    // seed-divergence are checked by the two SELECTs below.
    if (/AS hardware_specs,[\s\S]*AS bundle_items/.test(sql)) {
      const zero = { hardware_specs: 0, disk_combos: 0, teams: 0, vm_profiles: 0, field_defs: 0, bundles: 0, bundle_items: 0 };
      return [state.configEmpty === false ? { ...zero, hardware_specs: 3 } : zero];
    }
    // isGlobalConfigEmpty settings-seed probe: an empty config carries the pristine
    // seeded singleton; a test may override state.globalSettingsRow to model an edit.
    if (/SELECT mem_cpu_ratio, sga_factor[\s\S]*FROM `fmb_cap_settings` WHERE scenario_id IS NULL/.test(sql)) {
      const pristine = {
        mem_cpu_ratio: 20, sga_factor: 0.982, sga_divisor: 2, sga_subtract: 2, standby_sga_default_gb: 32,
        util_amber_pct: 80, util_red_pct: 90, overcommit_default_enabled: 0, layer_defaults: null,
      };
      return state.globalSettingsRow !== undefined ? state.globalSettingsRow : [pristine];
    }
    // isGlobalConfigEmpty rule-template probe: an empty config carries the untouched
    // DEFAULT_RULE_TEMPLATE; a test may override state.globalRuleRows to model an edit.
    // A named column list, never `SELECT *` — the snapshot/global-layer reads
    // use the star form and are answered further down from state.templateRows.
    const ruleTemplateSel = /SELECT ((?:`?\w+`?\s*,\s*)+`?\w+`?)\s+FROM `fmb_cap_rules` WHERE scenario_id IS NULL/.exec(sql);
    if (ruleTemplateSel) {
      if (state.globalRuleRows !== undefined) return state.globalRuleRows;
      // The projection is read OFF THE STATEMENT rather than restated here. A
      // hand-written column list in a double is a copy of the query it stands
      // in for, and the copy is what goes stale: the gate widened to the
      // columns an operator can actually edit and this fixture would have gone
      // on answering with the old six, reporting "still the untouched
      // template" for rows that no longer are.
      const cols = ruleTemplateSel[1].split(',').map((c) => c.trim().replace(/`/g, ''));
      const json = new Set(['params', 'filters']);
      return DEFAULT_RULE_TEMPLATE.map((r) => Object.fromEntries(cols.map((c) => [
        c, json.has(c) ? JSON.stringify(r[c] ?? {}) : (r[c] ?? null),
      ])));
    }
    // P1-2: isGlobalConfigEmpty scenario-override-of-global-rule probe.
    if (/SELECT 1 AS ref FROM `fmb_cap_rules` WHERE scenario_id IS NOT NULL AND overrides_rule_id IS NOT NULL LIMIT 1/.test(sql)) {
      return state.scenarioOverridesGlobalRule ? [{ ref: 1 }] : [];
    }
    // P1-2: isGlobalConfigEmpty Exception-references-global-rule probe (JOIN).
    if (/FROM `fmb_cap_waivers` w[\s\S]*JOIN `fmb_cap_rules` r[\s\S]*WHERE r.scenario_id IS NULL LIMIT 1/.test(sql)) {
      return state.waiverRefsGlobalRule ? [{ ref: 1 }] : [];
    }

    // Deep-copy source read.
    const nullSel = sql.match(/SELECT \* FROM `fmb_([a-z_]+)` WHERE scenario_id IS NULL/);
    if (nullSel) return state.templateRows[nullSel[1]] || [];

    // fmb-1686 (surface 2): GET /config/:group/:id — WHERE id = ? AND
    // scenario_id IS NULL. Keyed off the SAME state.templateRows fixture as
    // the list route above, filtered to the requested id.
    const nullByIdSel = sql.match(/^SELECT \* FROM `fmb_([a-z_]+)` WHERE id = \? AND scenario_id IS NULL$/);
    if (nullByIdSel) {
      const rows = state.templateRows[nullByIdSel[1]] || [];
      return rows.filter((r) => String(r.id) === String(params[0]));
    }

    // PR-E snapshot / live-clone read: SELECT * FROM cap_<entity> WHERE
    // scenario_id = ? (single-line, no ORDER BY). Keyed by the table suffix,
    // which equals the snapshot document key (sites, hypervisors, …). Gated on
    // state.scenarioRows so every pre-PR-E test is untouched (undefined → skip).
    const scopedSel = sql.match(/^SELECT \* FROM `fmb_cap_([a-z_]+)` WHERE scenario_id = \?\s*$/);
    if (scopedSel && state.scenarioRows !== undefined) {
      return state.scenarioRows[scopedSel[1]] || [];
    }

    // Generic children.js LIST GET (schema.js factory): SELECT * FROM
    // cap_<entity> WHERE `scenario_id` = ? [filters] ORDER BY `<col>` IS NULL,
    // `<col>` <DIR> [LIMIT ?] — the bindScenarioScope-filtered, sortable list
    // route (phase-2 spec §4.3 B1: `?sort=order_index`). Keyed by table
    // suffix; state.listRows undefined ⇒ [] (every pre-existing test that
    // never hits this route is unaffected). The mock SORTS the fixture rows
    // itself (mirroring the real `col IS NULL, col DIR` clause — nulls last,
    // then value order) so a test can actually prove the end-to-end read
    // order, not just that the SQL text mentions the column.
    const genericList = sql.match(/^SELECT \* FROM `fmb_cap_([a-z_]+)` WHERE `scenario_id` = \? ORDER BY `([a-z_]+)` IS NULL, `[a-z_]+` (ASC|DESC)/);
    if (genericList) {
      const [, table, col, dir] = genericList;
      const rows = [...((state.listRows && state.listRows[table]) || [])];
      const mul = dir === 'DESC' ? -1 : 1;
      rows.sort((a, b) => {
        if (a[col] == null && b[col] == null) return 0;
        if (a[col] == null) return 1;
        if (b[col] == null) return -1;
        return a[col] < b[col] ? -mul : a[col] > b[col] ? mul : 0;
      });
      return rows;
    }

    // PR-E live-clone source read: SELECT name, note FROM cap_scenarios WHERE id = ?.
    if (/SELECT name, note FROM `fmb_cap_scenarios` WHERE id = \?/.test(sql)) {
      return state.sourceScenarioRow !== undefined ? state.sourceScenarioRow : [];
    }

    // PR-E version metadata list (GET /versions), ordered — served before the
    // SELECT * id-read branches below.
    if (/FROM `fmb_cap_versions`\s+WHERE scenario_id = \? ORDER BY/.test(sql)) {
      return state.versionListRows !== undefined ? state.versionListRows : [];
    }

    // PR-E created_by → display-name enrichment probe (owner-name-enrichment
    // helper). Returns display_name for the ids present in state.userNames.
    if (/SELECT id, display_name, kc_username FROM `fmb_users` WHERE id IN/.test(sql)) {
      return params
        .filter((id) => state.userNames[id] !== undefined)
        .map((id) => ({ id, display_name: state.userNames[id], kc_username: null }));
    }

    // PR-E version read (GET one: SELECT *; version-clone: SELECT id, name,
    // note, snapshot) — both WHERE id = ? AND scenario_id = ? without FOR UPDATE.
    // The DELETE FOR-UPDATE probe is served by the generic childRowExists branch.
    if (/FROM `fmb_cap_versions` WHERE id = \? AND scenario_id = \?/.test(sql) && !/FOR UPDATE/.test(sql)) {
      return state.versionRow !== undefined ? state.versionRow : [];
    }

    // PR-B Task 1: per-scenario cap_settings singleton — existence probe
    // (PUT's "does a row already exist for this scenario" check).
    if (/SELECT id FROM `fmb_cap_settings` WHERE scenario_id = \?/.test(sql)) {
      return state.settingsExists ? [{ id: 'f044dae7-5285-4361-8adc-7e657994ca56' }] : [];
    }
    // PR-B Task 1: the settings row read, used by BOTH the GET route and PUT's
    // post-write confirm read. A just-executed INSERT (the mint-on-first-write
    // path) wins over `state.settingsExists` so a fresh row is returned even
    // when the test started with no row.
    if (/SELECT \* FROM `fmb_cap_settings` WHERE scenario_id = \?/.test(sql)) {
      const lastInsert = [...state.queries].reverse().find((q) => {
        if (!/^INSERT INTO `fmb_cap_settings`/.test(q.sql)) return false;
        return String(synthRowFromInsert(q.sql, q.params).scenario_id) === String(params[0]);
      });
      if (lastInsert) return [synthRowFromInsert(lastInsert.sql, lastInsert.params)];
      return state.settingsExists
        ? [{
            id: 'f044dae7-5285-4361-8adc-7e657994ca56', scenario_id: params[0], mem_cpu_ratio: 20, sga_mem_factor: 0.8,
            sga_fixed_subtract: 4, util_amber_pct: 80, util_red_pct: 90,
            overcommit_default_enabled: 0, layer_defaults: null,
            // fmb-1686: lets a test model a scenario-override row already carrying
            // a stored name_patterns value (legacy 3-key or 4-key) on this same
            // fixture GET (surface 3) and PUT-echo (surface 4, on an UPDATE of an
            // unrelated field) both read.
            ...(state.settingsRowNamePatterns !== undefined ? { name_patterns: state.settingsRowNamePatterns } : {}),
          }]
        : [];
    }

    // codex-r1/r2: cap_field_defs PUT-merge check — reads the row's CURRENT
    // entity_type/field_key/data_type/options (config.js's scenario_id IS
    // NULL scope, or children.js's scenario_id = ? scope) so a PUT touching
    // only ONE column of either pair is validated against its true final
    // merged state.
    if (/SELECT entity_type, field_key, data_type, options FROM `fmb_cap_field_defs` WHERE id = \?/.test(sql)) {
      return state.fieldDefExisting ? [state.fieldDefExisting] : [];
    }

    // codex-r2: (scenario_id, entity_type, field_key) uniqueness probe —
    // POST's create-time check and PUT-merge's re-check after a key-tuple
    // change, both global (scenario_id IS NULL) and scenario-scoped.
    if (/SELECT 1 FROM `fmb_cap_field_defs` WHERE scenario_id (?:IS NULL|= \?) AND entity_type = \? AND field_key = \?/.test(sql)) {
      return state.fieldDefDuplicateExists ? [{ 1: 1 }] : [];
    }

    // R1.11 H1: rule override-uniqueness probe (at most one override per
    // (scenario, overrides_rule_id)). SELECT 1 FROM cap_rules WHERE scenario_id=?
    // AND overrides_rule_id=? [AND id != ?] LIMIT 1.
    if (/SELECT 1 FROM `fmb_cap_rules` WHERE scenario_id = \? AND overrides_rule_id = \?/.test(sql)) {
      return state.overrideDuplicateExists ? [{ 1: 1 }] : [];
    }

    // R1.14 #1: cap_rules override-fill — reads the referenced GLOBAL rule's
    // type/name/level/group_by so an override POST (which omits those NOT NULL
    // columns) can be filled before INSERT. Declared BEFORE the R1.13 branch
    // below since that one's regex would also match this column list's prefix.
    if (/SELECT type, name, level, group_by FROM `fmb_cap_rules` WHERE id = \? AND scenario_id IS NULL/.test(sql)) {
      return state.overrideTarget ? [state.overrideTarget] : [];
    }

    // R1.13 Fix 2: cap_rules PUT-merge — reads the stored row's type/level/group_by
    // so a partial `{ level }`-only PUT is validated against its merged final state
    // (both the scenario_id = ? scenario mount and the scenario_id IS NULL config
    // mount hit this branch).
    if (/SELECT type, level, group_by FROM `fmb_cap_rules` WHERE id = \?/.test(sql)) {
      return state.ruleExisting ? [state.ruleExisting] : [];
    }

    // R1.13 Fix 3: cap_custom_group_members PUT-merge — reads the stored row's
    // member_vm_id/member_instance_id for the exactly-one-member XOR re-check.
    if (/SELECT member_vm_id, member_instance_id FROM `fmb_cap_custom_group_members` WHERE id = \?/.test(sql)) {
      return state.memberExisting ? [state.memberExisting] : [];
    }

    // Config GET list (ORDER BY created_at) — no rows needed for the write tests.
    if (/SELECT \* FROM `fmb_[a-z_]+` WHERE scenario_id IS NULL ORDER BY/.test(sql)) return [];

    // R1.14 #1/#3: model cap_rules' real DDL constraints the old mock masked —
    // type/name/level are NOT NULL (a missing one is errno 1048, the 500 the
    // override-fill guard prevents), and the UNIQUE (scenario_id, overrides_rule_id)
    // index trips errno 1062 when state.insertDuplicateError is set (the race the
    // factory's mapDuplicateKey maps to 409).
    if (/^INSERT INTO `fmb_cap_rules`/.test(sql)) {
      const row = synthRowFromInsert(sql, params);
      for (const col of ['type', 'name', 'level']) {
        if (row[col] == null) {
          const e = new Error(`Column '${col}' cannot be null`);
          e.errno = 1048; e.code = 'ER_BAD_NULL_ERROR';
          throw e;
        }
      }
      if (state.insertDuplicateError) {
        const e = new Error("Duplicate entry for key 'uq_cap_rules_override'");
        e.errno = 1062; e.code = 'ER_DUP_ENTRY';
        throw e;
      }
      return { affectedRows: 1, insertId: 1 };
    }

    // fmb-0140: a cap_field_defs INSERT trips the UNIQUE (scenario_id,
    // entity_type, field_key) index → errno 1062, which config.js maps to the
    // SAME 400 the app-layer uniqueness pre-check produces.
    if (/^INSERT INTO `fmb_cap_field_defs`/.test(sql) && state.fieldDefInsertDuplicate) {
      const e = new Error("Duplicate entry for key 'uq_cap_field_defs_identity'");
      e.errno = 1062; e.code = 'ER_DUP_ENTRY';
      throw e;
    }
    // A NON-duplicate DB failure on the field_defs INSERT (errno ≠ 1062) — must
    // fall through config.js's 1062-only mapping to the generic 500.
    if (/^INSERT INTO `fmb_cap_field_defs`/.test(sql) && state.fieldDefInsertGenericError) {
      const e = new Error('Table storage is full');
      e.errno = 1030; e.code = 'ER_GET_ERRNO';
      throw e;
    }

    // Codex-r1 P2: capture each appended cap_sites order_index so a SECOND grid-
    // add in the same test sees MAX+1 grow (append determinism across adds).
    if (/^INSERT INTO `fmb_cap_sites`/.test(sql)) {
      const row = synthRowFromInsert(sql, params);
      if (row.order_index != null) {
        (state.siteOrderIndices || (state.siteOrderIndices = [])).push(Number(row.order_index));
      }
      return { affectedRows: 1, insertId: 1 };
    }

    if (/^INSERT INTO/.test(sql)) {
      // Race-safe singleton INSERT ... SELECT ... WHERE NOT EXISTS: inserts 0 rows
      // when a global row already exists.
      if (/WHERE NOT EXISTS/.test(sql)) return { affectedRows: state.settingsGlobalExists ? 0 : 1 };
      return { affectedRows: 1, insertId: 1 };
    }

    if (/^UPDATE/.test(sql)) return { affectedRows: state.updateAffected };
    if (/^DELETE/.test(sql)) return { affectedRows: state.deleteAffected };

    // Post-write re-SELECT by id → synthesize from the last matching INSERT.
    const idSel = sql.match(/SELECT \* FROM `fmb_([a-z_]+)` WHERE id = \?/);
    if (idSel) {
      const table = idSel[1];
      const lastInsert = [...state.queries].reverse()
        .find((q) => new RegExp(`INSERT INTO \`fmb_${table}\``).test(q.sql));
      if (lastInsert) return [synthRowFromInsert(lastInsert.sql, lastInsert.params)];
      return [];
    }

    return [];
  },
};

const poolFacade = {
  getConnection: async () => conn,
  query: (sql, params) => conn.query(sql, params),
};
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: { ro: poolFacade, rw: poolFacade }, t: (n) => `fmb_${n}` },
};

// The sites reference sweep's own declaration, so the query double above answers
// the tables it actually probes rather than a list copied beside it. Required
// AFTER the db stub — the module destructures `t` from it at load.
const { SITE_REFERENCE_GROUPS } = require('../../../../src/edge/routes/app/capacity/site-references');

const schema = require('../../../../src/edge/routes/app/schema');
const router = require('../../../../src/edge/routes/app/capacity');
const { DEFAULT_RULE_TEMPLATE } = require('../../../../src/shared/capacity/rule-types');
const { validateNamePatternsWrite } = require('../../../../src/shared/capacity/name-patterns');

let currentUser; let server; let baseUrl;
before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { req.user = currentUser; next(); });
  app.use('/capacity', router);
  server = http.createServer(app);
  await new Promise((r) => server.listen(0, r));
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});
after(() => server && server.close());
beforeEach(() => {
  state = freshState();
  currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
  schema.__clearColumnSetCache && schema.__clearColumnSetCache();
});

function request(method, path, body) {
  return new Promise((resolve, reject) => {
    const payload = body === undefined ? '' : JSON.stringify(body);
    const r = http.request(
      `${baseUrl}${path}`,
      { method, headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) } },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          const raw = Buffer.concat(chunks).toString('utf8');
          let json = null;
          try { json = JSON.parse(raw); } catch { /* noop */ }
          resolve({ status: res.statusCode, json, raw, headers: res.headers });
        });
      },
    );
    r.on('error', reject);
    if (payload) r.write(payload);
    r.end();
  });
}

const insertsInto = (table) =>
  state.queries.filter((q) => new RegExp(`^INSERT INTO \`fmb_${table}\``).test(q.sql));

// ── 1. Config (template) role gating + scenario_id IS NULL scope ───────────────
describe('capacity config (template) routes', () => {
  it('editor may create a global-template rule; scenario_id is forced NULL', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    const res = await request('POST', '/capacity/config/rules', {
      type: 'max-vms-per-host', name: 'Max 8 VMs', level: 'hypervisor', group_by: 'all_of_type',
      params: { max: 8 }, severity: 'hard', enabled: true,
    });
    assert.equal(res.status, 201, res.raw);
    const ins = insertsInto('cap_rules');
    assert.equal(ins.length, 1);
    // Column list starts with (id, scenario_id, ...); the 2nd param is scenario_id.
    assert.equal(ins[0].params[1], null, 'scenario_id must be forced NULL on a template insert');
  });

  it('plain user may not create a global-template rule (403)', async () => {
    currentUser = { id: '71d6dd0a-d1a0-4028-845a-3aa72fd3a97b', role: 'user' };
    const res = await request('POST', '/capacity/config/rules', { type: 'keep-apart', name: 'x', level: 'db_instance' });
    assert.equal(res.status, 403, res.raw);
    assert.equal(insertsInto('cap_rules').length, 0);
  });

  it('admin may create a global-template setting row', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    const res = await request('POST', '/capacity/config/settings', { mem_cpu_ratio: 20, util_amber_pct: 80 });
    assert.equal(res.status, 201, res.raw);
    assert.equal(insertsInto('cap_settings').length, 1);
  });

  it('config list is scoped to scenario_id IS NULL', async () => {
    currentUser = { id: '71d6dd0a-d1a0-4028-845a-3aa72fd3a97b', role: 'user' };
    const res = await request('GET', '/capacity/config/rules');
    assert.equal(res.status, 200, res.raw);
    const listQ = state.queries.find((q) => /SELECT \* FROM `fmb_cap_rules` WHERE scenario_id IS NULL/.test(q.sql));
    assert.ok(listQ, 'list query must constrain to scenario_id IS NULL');
  });

  it('a plain user cannot update a template row (403)', async () => {
    currentUser = { id: '71d6dd0a-d1a0-4028-845a-3aa72fd3a97b', role: 'user' };
    const res = await request('PUT', '/capacity/config/rules/r1', { name: 'renamed' });
    assert.equal(res.status, 403, res.raw);
  });
});

// ── 2 + 3. Scenario create: owner-scoping + REFERENCE model (no deep-copy) ──────
describe('capacity scenario create (owner-scope + reference model)', () => {
  it('editor create stamps owner_id = actor and COPIES NOTHING (references catalogues)', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    const res = await request('POST', '/capacity/scenarios', { name: 'North Sea Alpha', note: 'demo' });
    assert.equal(res.status, 201, res.raw);

    const scen = insertsInto('cap_scenarios');
    assert.equal(scen.length, 1);
    // INSERT (id, name, owner_id, note): owner_id (params[2]) = the editor.
    assert.equal(scen[0].params[2], '4ec54b37-3f24-4759-8c85-dc37030749b6', 'editor-created scenario must be owner-stamped');

    // Reference model (config-rewrite §2, Model B): create INSERTs ONLY the
    // cap_scenarios row — nothing is copied from any catalogue table. The scenario
    // references the live global catalogues by FK; version freeze is the only copy.
    const nonScenarioInserts = state.queries.filter(
      (q) => /^INSERT INTO `fmb_cap_/.test(q.sql) && !/^INSERT INTO `fmb_cap_scenarios`/.test(q.sql),
    );
    assert.equal(nonScenarioInserts.length, 0, 'scenario create must copy no catalogue rows');
    // And it never rewrites a template row.
    assert.equal(state.queries.some((q) => /^UPDATE/.test(q.sql)), false, 'create must not UPDATE anything');
  });

  it('admin create leaves owner_id NULL (shared)', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    const res = await request('POST', '/capacity/scenarios', { name: 'Shared plan' });
    assert.equal(res.status, 201, res.raw);
    const scen = insertsInto('cap_scenarios');
    assert.equal(scen[0].params[2], null, 'admin-created scenario is shared (owner_id NULL)');
  });

  it('plain user may not create a scenario (403)', async () => {
    currentUser = { id: '71d6dd0a-d1a0-4028-845a-3aa72fd3a97b', role: 'user' };
    const res = await request('POST', '/capacity/scenarios', { name: 'x' });
    assert.equal(res.status, 403, res.raw);
    assert.equal(insertsInto('cap_scenarios').length, 0);
  });

  it('rejects a scenario create with no name (400)', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    const res = await request('POST', '/capacity/scenarios', { note: 'no name' });
    assert.equal(res.status, 400, res.raw);
  });
});

// ── 4. Scenario-scoped child parentOwnership ───────────────────────────────────
describe('capacity scenario-scoped child parentOwnership', () => {
  it('editor who owns the scenario may create a child; scenario_id is bound to the URL', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    state.scenarioOwner = '4ec54b37-3f24-4759-8c85-dc37030749b6'; // chain SELECT resolves the scenario to this editor
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/sites', { name: 'DC-1' });
    // The generic CRUD factory returns 200 on a successful create (the config /
    // scenario bespoke handlers use 201).
    assert.equal(res.status, 200, res.raw);
    const ins = insertsInto('cap_sites');
    assert.equal(ins.length, 1);
    const cols = ins[0].sql.match(/\(([^)]*)\)\s*VALUES/i)[1].split(',').map((c) => c.trim().replace(/`/g, ''));
    const row = {}; cols.forEach((c, i) => { row[c] = ins[0].params[i]; });
    assert.equal(row.scenario_id, '26895068-65f1-405c-8521-2a9e1212353c', 'child scenario_id must be bound to the URL param');
  });

  it('editor who does NOT own the scenario is refused (403)', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    state.scenarioOwner = 'e2d750c1-a8bf-4918-8970-7176a0e55d93';
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/sites', { name: 'DC-1' });
    assert.equal(res.status, 403, res.raw);
    assert.equal(insertsInto('cap_sites').length, 0);
  });

  it('admin may create a child under any scenario (owner bypass)', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.scenarioOwner = 'e2d750c1-a8bf-4918-8970-7176a0e55d93';
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/vms', { name: 'd8de67d9-c84d-4e73-8817-13b2f11c02f7', vm_type: 'ap_host' });
    assert.equal(res.status, 200, res.raw); // factory create → 200
    assert.equal(insertsInto('cap_vms').length, 1);
  });

  it('plain user may not create a scenario child (403)', async () => {
    currentUser = { id: '71d6dd0a-d1a0-4028-845a-3aa72fd3a97b', role: 'user' };
    state.scenarioOwner = '71d6dd0a-d1a0-4028-845a-3aa72fd3a97b';
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/sites', { name: 'DC-1' });
    assert.equal(res.status, 403, res.raw);
  });
});

// ── Review-gate regressions ────────────────────────────────────────────────────
const colsOf = (insert) => {
  const cols = insert.sql.match(/\(([^)]*)\)\s*VALUES/i)[1].split(',').map((c) => c.trim().replace(/`/g, ''));
  const row = {}; cols.forEach((c, i) => { row[c] = insert.params[i]; });
  return row;
};

describe('review-gate: config read-your-writes + empty-body guard', () => {
  it('config create returns the written row (read-back on the write connection)', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    const res = await request('POST', '/capacity/config/rules', {
      type: 'max-vms-per-host', name: 'Max 8 VMs', level: 'hypervisor', group_by: 'all_of_type',
      params: { max: 8 }, severity: 'hard', enabled: true,
    });
    assert.equal(res.status, 201, res.raw);
    assert.ok(res.json.data, 'create must return the written row, not data: undefined');
    assert.equal(res.json.data.type, 'max-vms-per-host');
  });

  it('config update returns the written row', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    await request('POST', '/capacity/config/rules', { type: 'keep-apart', name: 'orig', level: 'db_instance' });
    const res = await request('PUT', '/capacity/config/rules/r1', { name: 'renamed' });
    assert.equal(res.status, 200, res.raw);
    assert.ok(res.json.data, 'update must return the written row');
  });

  it('config create with an empty body → 400 (not a 500 on NOT NULL columns)', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    const res = await request('POST', '/capacity/config/rules', {});
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'BAD_REQUEST');
    assert.equal(insertsInto('cap_rules').length, 0);
  });
});

// codex-P2: a global catalogue create must append at the END of the persisted
// drag order (order_index = prior MAX+1), not default to 0/front — else a row
// added after a reorder lands ahead of every dragged row.
describe('codex-P2: global catalogue create appends order_index at the end', () => {
  it('a teams create appends after the existing global rows (order_index = MAX+1)', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    state.configOrderIndices = { cap_teams: [0, 1, 2] };
    const res = await request('POST', '/capacity/config/teams', { name: 'Payments', color: '#36f' });
    assert.equal(res.status, 201, res.raw);
    const row = colsOf(insertsInto('cap_teams')[0]);
    assert.equal(row.order_index, 3, 'new row must append after the current MAX, not default to 0');
  });

  it('a hardware_specs create on an EMPTY global catalogue starts at order_index 0', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    state.configOrderIndices = { cap_hardware_specs: [] };
    const res = await request('POST', '/capacity/config/hardware_specs', {
      name: 'Standard', cpu_total: 32, mem_total_gb: 256, disk_total_gb: 2000,
    });
    assert.equal(res.status, 201, res.raw);
    const row = colsOf(insertsInto('cap_hardware_specs')[0]);
    assert.equal(row.order_index, 0);
  });

  it('a non-orderable group (rules) create never sets order_index', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    state.configOrderIndices = { cap_rules: [0, 1, 2] }; // must be ignored — rules is not reorderable
    const res = await request('POST', '/capacity/config/rules', {
      type: 'keep-apart', name: 'x', level: 'db_instance',
    });
    assert.equal(res.status, 201, res.raw);
    const row = colsOf(insertsInto('cap_rules')[0]);
    assert.equal(Object.prototype.hasOwnProperty.call(row, 'order_index'), false, 'rules must not gain a server-assigned order_index');
  });
});

describe('review-gate: audit stamping + version immutability', () => {
  it('waiver create ignores a client-supplied created_by and stamps the actor', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    state.scenarioOwner = '4ec54b37-3f24-4759-8c85-dc37030749b6';
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/waivers', {
      rule_id: '90eb8cf2-928b-4835-8608-d2857bb3cfd6', object_set_key: 'a|b', created_by: 'ebf63b0e-0f69-48e6-8294-4a26dd3ab608', created_at: '1999-01-01',
    });
    assert.equal(res.status, 200, res.raw); // factory create → 200
    const row = colsOf(insertsInto('cap_waivers')[0]);
    assert.equal(row.created_by, '4ec54b37-3f24-4759-8c85-dc37030749b6', 'created_by must be server-stamped to the actor');
    assert.notEqual(row.created_by, 'ebf63b0e-0f69-48e6-8294-4a26dd3ab608');
    assert.equal(Object.prototype.hasOwnProperty.call(row, 'created_at'), false, 'client created_at must be stripped');
  });

  it('version create stamps created_by from the actor and ignores a client snapshot', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    state.scenarioOwner = '4ec54b37-3f24-4759-8c85-dc37030749b6';
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/versions', {
      name: '1b4d1b85-ca5b-4f82-8137-9ea5b1f5e30d', snapshot: { rows: ['HACKED'] }, created_by: 'ebf63b0e-0f69-48e6-8294-4a26dd3ab608',
    });
    assert.equal(res.status, 201, res.raw);
    const row = colsOf(insertsInto('cap_versions')[0]);
    assert.equal(row.created_by, '4ec54b37-3f24-4759-8c85-dc37030749b6', 'created_by must be server-stamped, not the client value');
    assert.notEqual(row.created_by, 'ebf63b0e-0f69-48e6-8294-4a26dd3ab608');
    // The snapshot is SERVER-computed — the client body is never persisted.
    assert.equal(typeof row.snapshot, 'string');
    const parsed = JSON.parse(row.snapshot);
    assert.equal(parsed.schema_rev, 1, 'server snapshot carries schema_rev');
    assert.ok(parsed.tables && typeof parsed.tables === 'object', 'server snapshot carries a tables map');
    assert.equal(res.raw.includes('HACKED'), false, 'the client-supplied snapshot must not appear anywhere');
  });

  it('a version PUT carrying the snapshot is refused 400 — the body stays frozen (D7)', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.scenarioOwner = '35001ba8-1475-47d7-8cc5-95adf919682b';
    const res = await request('PUT', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/versions/v1', { name: 'renamed', snapshot: { tables: {} } });
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'BAD_REQUEST');
    assert.match(res.json.error.message, /snapshot/);
    assert.equal(state.queries.some((q) => /^UPDATE `fmb_cap_versions`/.test(q.sql)), false);
  });
});

// ── Codex R1 regressions ───────────────────────────────────────────────────────
describe('codex-r1: scenario-scoped FK validation', () => {
  it('a hypervisor referencing a site outside the scenario is rejected 400', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.fkExists = false; // the FK probe finds no in-scenario site
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/hypervisors', {
      name: '3bb4a2d0-19a4-4ea3-89e7-32226b5c3e2f', site_id: '5273eb20-53a2-469c-8362-e3c7f30d7a2b', spec_id: '8d9a523d-173d-4446-83f5-888b5ce48df4',
    });
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'INVALID_REFERENCE');
    assert.match(res.json.error.message, /site_id/);
    assert.equal(insertsInto('cap_hypervisors').length, 0);
  });

  it('an in-scenario hypervisor FK passes', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.fkExists = true;
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/hypervisors', {
      name: '3bb4a2d0-19a4-4ea3-89e7-32226b5c3e2f', site_id: 'b78a9a94-3dde-45ec-8833-b3ccb7276575', spec_id: '8d9a523d-173d-4446-83f5-888b5ce48df4',
    });
    assert.equal(res.status, 200, res.raw);
    assert.equal(insertsInto('cap_hypervisors').length, 1);
  });

  it('a nullable FK (hypervisor_id) NULL skips the check (unplaced VM allowed)', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.fkExists = false; // would fail IF probed — but a NULL must skip it
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/vms', {
      name: 'd8de67d9-c84d-4e73-8817-13b2f11c02f7', vm_type: 'ap_host', hypervisor_id: null,
    });
    assert.equal(res.status, 200, res.raw);
    assert.equal(insertsInto('cap_vms').length, 1);
  });

  it('a db_instance whose vm_id points to a non-db_host VM is rejected 400', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.fkExists = true;
    state.fkVmType = 'ap_host'; // referenced VM is an ap_host, not a db_host
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/db_instances', {
      name: '7a3d86b4-6403-4159-8ec7-66520730403d', vm_id: '8c3026a4-6226-4a70-8c91-9e3d0771197d', role: 'primary',
    });
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'INVALID_PARENT_TYPE');
    assert.match(res.json.error.message, /db_host/);
    assert.equal(insertsInto('cap_db_instances').length, 0);
  });

  it('a db_instance under a db_host VM passes', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.fkExists = true;
    state.fkVmType = 'db_host';
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/db_instances', {
      name: '7a3d86b4-6403-4159-8ec7-66520730403d', vm_id: '83fa3342-8416-4ee1-8a9f-ccfa6145a0ec', role: 'primary',
    });
    assert.equal(res.status, 200, res.raw);
    assert.equal(insertsInto('cap_db_instances').length, 1);
  });
});

// ── 514-cand #1: child-write vs catalogue-delete race ───────────────────────────
describe('514-cand #1: catalogue-FK child writes lock the referenced row (FOR UPDATE, same tx)', () => {
  it('a hypervisor POST probes its catalogue FK FOR UPDATE, before the INSERT (in-tx hook)', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.fkExists = true;
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/hypervisors', {
      name: '3bb4a2d0-19a4-4ea3-89e7-32226b5c3e2f', site_id: 'b78a9a94-3dde-45ec-8833-b3ccb7276575', spec_id: '8d9a523d-173d-4446-83f5-888b5ce48df4',
    });
    assert.equal(res.status, 200, res.raw);
    // The §17.1a probe now carries FOR UPDATE (checkReferences lock:true) — only
    // reachable via the factory's preWriteInTx hook on the write connection, not the
    // old unlocked pre-middleware. This is what holds the catalogue row from the
    // check through the INSERT so a concurrent config delete cannot dangle the FK.
    const probe = state.queries.find((q) => /SELECT id, scenario_id,[\s\S]*FROM `fmb_cap_hardware_specs` WHERE id = \? FOR UPDATE/.test(q.sql));
    assert.ok(probe, 'the spec_id catalogue FK is probed FOR UPDATE');
    const probeIdx = state.queries.indexOf(probe);
    const insertIdx = state.queries.findIndex((q) => /^INSERT INTO `fmb_cap_hypervisors`/.test(q.sql));
    assert.ok(probeIdx >= 0 && insertIdx >= 0 && probeIdx < insertIdx, 'the locked probe runs before the INSERT on the same connection');
  });

  it('a hypervisor PUT probes a changed catalogue FK FOR UPDATE, before the UPDATE (same in-tx hook, distinct PUT copy)', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.fkExists = true;
    const res = await request('PUT', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/hypervisors/3bb4a2d0-19a4-4ea3-89e7-32226b5c3e2f', { spec_id: '6a9d04a7-a692-4fb6-82ce-c91406f7cc0c' });
    assert.equal(res.status, 200, res.raw);
    // The PUT preWriteInTx path is a separate hand-written copy from POST — prove it
    // ALSO runs the §17.1a probe FOR UPDATE (lock:true) before the UPDATE, on the
    // write connection (guards against a future edit to only one of the two copies).
    const probe = state.queries.find((q) => /SELECT id, scenario_id,[\s\S]*FROM `fmb_cap_hardware_specs` WHERE id = \? FOR UPDATE/.test(q.sql));
    assert.ok(probe, 'the changed spec_id catalogue FK is probed FOR UPDATE on PUT');
    const probeIdx = state.queries.indexOf(probe);
    const updateIdx = state.queries.findIndex((q) => /^UPDATE `fmb_cap_hypervisors`/.test(q.sql));
    assert.ok(probeIdx >= 0 && updateIdx >= 0 && probeIdx < updateIdx, 'the locked probe runs before the UPDATE on the same connection');
  });

  it('a waiver POST locks its rule_id catalogue FK FOR UPDATE', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.fkExists = true;
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/waivers', {
      rule_id: '90eb8cf2-928b-4835-8608-d2857bb3cfd6', object_set_key: 'a|b',
    });
    assert.equal(res.status, 200, res.raw);
    assert.ok(
      state.queries.some((q) => /SELECT id, scenario_id,[\s\S]*FROM `fmb_cap_rules` WHERE id = \? FOR UPDATE/.test(q.sql)),
      'the waiver rule_id catalogue FK is probed FOR UPDATE',
    );
  });

  it('db_instances (scenario-mode FK) now probes its vm_id FOR UPDATE, before the INSERT (fmb-0125)', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.fkExists = true;
    state.fkVmType = 'db_host';
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/db_instances', {
      name: '7a3d86b4-6403-4159-8ec7-66520730403d', vm_id: '83fa3342-8416-4ee1-8a9f-ccfa6145a0ec', role: 'primary',
    });
    assert.equal(res.status, 200, res.raw);
    // fmb-0125 extends the in-tx FOR UPDATE lock to the scenario-mode FKs so a
    // db_instance write serialises with a concurrent VM delete (makeChildDelete
    // locks the same vm row) — no more unlocked pre-middleware read.
    const locked = state.queries.find((q) => /SELECT id, scenario_id, vm_type,[\s\S]*FROM `fmb_cap_vms` WHERE id = \? FOR UPDATE/.test(q.sql));
    assert.ok(locked, 'the vm_id scenario FK is probed FOR UPDATE inside the write tx');
    const probeIdx = state.queries.indexOf(locked);
    const insertIdx = state.queries.findIndex((q) => /^INSERT INTO `fmb_cap_db_instances`/.test(q.sql));
    assert.ok(probeIdx >= 0 && insertIdx >= 0 && probeIdx < insertIdx, 'the locked probe runs before the INSERT on the same connection');
  });

  it('custom_group_members (scenario-mode FK) also probes its member FKs FOR UPDATE (fmb-0125)', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.fkExists = true;
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/custom_group_members', {
      group_id: 'c30b82f6-daee-4dc1-803b-3832d41ed110', member_vm_id: 'd8de67d9-c84d-4e73-8817-13b2f11c02f7',
    });
    assert.equal(res.status, 200, res.raw);
    const locked = state.queries.filter((q) => /SELECT id, scenario_id,[\s\S]*FROM `fmb_cap_(?:custom_groups|vms)` WHERE id = \? FOR UPDATE/.test(q.sql));
    assert.ok(locked.length >= 1, 'the member scenario FKs are probed FOR UPDATE inside the write tx');
  });
});

// ── cap-renumber-lock (spec D1/D5/D6): name_locked writable via host CRUD ──────
describe('cap-renumber-lock: name_locked writable via host CRUD (PUT)', () => {
  it('a hypervisor PUT { name_locked: true } persists (coerced to 1)', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    const res = await request('PUT', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/hypervisors/3bb4a2d0-19a4-4ea3-89e7-32226b5c3e2f', { name_locked: true });
    assert.equal(res.status, 200, res.raw);
    const update = state.queries.find((q) => /^UPDATE `fmb_cap_hypervisors` SET `name_locked` = \?/.test(q.sql));
    assert.ok(update, 'the UPDATE names name_locked');
    assert.equal(update.params[0], 1, 'true coerces to 1');
  });

  it('a vm PUT { name_locked: false } persists (coerced to 0)', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    const res = await request('PUT', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/vms/d8de67d9-c84d-4e73-8817-13b2f11c02f7', { name_locked: false });
    assert.equal(res.status, 200, res.raw);
    const update = state.queries.find((q) => /^UPDATE `fmb_cap_vms` SET `name_locked` = \?/.test(q.sql));
    assert.ok(update, 'the UPDATE names name_locked');
    assert.equal(update.params[0], 0, 'false coerces to 0');
  });

  it('a genuinely non-boolean name_locked value is refused 400, nothing updated (hypervisor)', async () => {
    // 'yes' is outside BOOLEAN_COERCIBLE (dto-mapper.js would otherwise
    // silently coerce it to false) — the guard refuses it rather than let it
    // land as an unlocked host nobody asked to unlock.
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    const res = await request('PUT', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/hypervisors/3bb4a2d0-19a4-4ea3-89e7-32226b5c3e2f', { name_locked: 'yes' });
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'VALUE_GUARD');
    assert.equal(hasQuery(/^UPDATE `fmb_cap_hypervisors`/), false);
  });

  it('a genuinely non-boolean name_locked value is refused 400, nothing updated (vm, number 2)', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    const res = await request('PUT', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/vms/d8de67d9-c84d-4e73-8817-13b2f11c02f7', { name_locked: 2 });
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'VALUE_GUARD');
    assert.equal(hasQuery(/^UPDATE `fmb_cap_vms`/), false);
  });

  it('BOOLEAN_COERCIBLE aliases (1/0/"true"/"false") are accepted like dto-mapper would coerce them', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    const res = await request('PUT', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/hypervisors/3bb4a2d0-19a4-4ea3-89e7-32226b5c3e2f', { name_locked: 1 });
    assert.equal(res.status, 200, res.raw);
    const update = state.queries.find((q) => /^UPDATE `fmb_cap_hypervisors` SET `name_locked` = \?/.test(q.sql));
    assert.equal(update.params[0], 1);
  });

  it('an explicit null is refused 400 (name_locked is NOT NULL)', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    const res = await request('PUT', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/vms/d8de67d9-c84d-4e73-8817-13b2f11c02f7', { name_locked: null });
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'VALUE_GUARD');
  });
});

// ── security M-2: reserved-key guard on the raw child-CRUD metadata write path ──
describe('security M-2: reserved metadata key rejected on the child-CRUD write path', () => {
  it('POST /vms with a reserved metadata key → 400 RESERVED_FIELD_KEY, no DB write', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    // `constructor` survives the JSON round-trip as an OWN enumerable key (unlike a
    // bare __proto__ literal), so this exercises the real parsed-object vector.
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/vms', {
      name: 'vm-x', vm_type: 'ap_host', metadata: { constructor: 'evil' },
    });
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'RESERVED_FIELD_KEY');
    assert.equal(insertsInto('cap_vms').length, 0, 'rejected before any INSERT');
  });

  it('a clean metadata object still writes normally', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.fkExists = true;
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/vms', {
      name: 'vm-ok', vm_type: 'ap_host', metadata: { tier: 'gold' },
    });
    assert.equal(res.status, 200, res.raw);
    assert.equal(insertsInto('cap_vms').length, 1);
  });
});

describe('codex-r1: scenario cascade delete', () => {
  const SCOPED = [
    'cap_waivers', 'cap_custom_group_members', 'cap_custom_groups', 'cap_db_instances',
    'cap_vms', 'cap_databases', 'cap_hypervisors', 'cap_sites', 'cap_versions',
    'cap_rules', 'cap_vm_profiles', 'cap_disk_combos', 'cap_teams',
    'cap_hardware_specs', 'cap_field_defs', 'cap_settings',
  ];

  it('owner delete removes every scoped child table then the scenario, in a tx', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    state.scenarioOwner = '4ec54b37-3f24-4759-8c85-dc37030749b6'; // owner probe resolves to the caller
    const res = await request('DELETE', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c');
    assert.equal(res.status, 200, res.raw);
    for (const table of SCOPED) {
      const del = state.queries.find((q) => new RegExp(`^DELETE FROM \`fmb_${table}\` WHERE scenario_id = \\?`).test(q.sql));
      assert.ok(del, `expected a scoped delete for ${table}`);
      assert.deepEqual(del.params, ['26895068-65f1-405c-8521-2a9e1212353c']);
    }
    const scenDel = state.queries.find((q) => /^DELETE FROM `fmb_cap_scenarios` WHERE id = \?/.test(q.sql));
    assert.ok(scenDel, 'the scenario row itself must be deleted');
  });

  it('a non-owner editor cannot delete another owner’s scenario (403), nothing deleted', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    state.scenarioOwner = 'e2d750c1-a8bf-4918-8970-7176a0e55d93';
    const res = await request('DELETE', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c');
    assert.equal(res.status, 403, res.raw);
    assert.equal(state.queries.some((q) => /^DELETE FROM `fmb_cap_sites`/.test(q.sql)), false);
  });

  it('deleting a missing scenario → 404', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.deleteScenarioRows = []; // scenario not found
    const res = await request('DELETE', '/capacity/scenarios/nope');
    assert.equal(res.status, 404, res.raw);
  });

  it('a plain user cannot delete a scenario (403)', async () => {
    currentUser = { id: '71d6dd0a-d1a0-4028-845a-3aa72fd3a97b', role: 'user' };
    const res = await request('DELETE', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c');
    assert.equal(res.status, 403, res.raw);
  });
});

describe('codex-r1: cap_settings singleton cardinality', () => {
  it('a second global settings POST is rejected 409 (atomic INSERT..NOT EXISTS inserts 0 rows)', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    state.settingsGlobalExists = true; // the race-safe insert affects 0 rows
    const res = await request('POST', '/capacity/config/settings', { mem_cpu_ratio: 20 });
    assert.equal(res.status, 409, res.raw);
    assert.equal(res.json.error.code, 'CONFLICT');
    // The single atomic statement is issued but is a guarded INSERT ... SELECT
    // ... WHERE NOT EXISTS (not a plain VALUES insert) and lands no row.
    const ins = insertsInto('cap_settings');
    assert.equal(ins.length, 1);
    assert.match(ins[0].sql, /WHERE NOT EXISTS/);
  });

  it('the first global settings POST succeeds', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    state.settingsGlobalExists = false;
    const res = await request('POST', '/capacity/config/settings', { mem_cpu_ratio: 20 });
    assert.equal(res.status, 201, res.raw);
    assert.equal(insertsInto('cap_settings').length, 1);
    // The success path is the same single atomic guarded statement.
    assert.match(insertsInto('cap_settings')[0].sql, /WHERE NOT EXISTS/);
  });
});

describe('phase-2 A4: global standby SGA default (cap_settings.standby_sga_default_gb)', () => {
  it('a global settings POST persists standby_sga_default_gb', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    state.settingsGlobalExists = false;
    const res = await request('POST', '/capacity/config/settings', { mem_cpu_ratio: 20, standby_sga_default_gb: 48 });
    assert.equal(res.status, 201, res.raw);
    const ins = insertsInto('cap_settings');
    assert.equal(ins.length, 1);
    assert.match(ins[0].sql, /standby_sga_default_gb/);
    // (id, scenario_id, mem_cpu_ratio, standby_sga_default_gb) — the value reaches the write.
    assert.ok(ins[0].params.includes(48), 'standby_sga_default_gb value must reach the INSERT');
  });

  it('a global settings PUT accepts standby_sga_default_gb', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    state.updateAffected = 1;
    const res = await request('PUT', '/capacity/config/settings/f044dae7-5285-4361-8adc-7e657994ca56', { standby_sga_default_gb: 64 });
    assert.equal(res.status, 200, res.raw);
    const upd = state.queries.filter((q) => /^UPDATE `fmb_cap_settings`/.test(q.sql));
    assert.equal(upd.length, 1);
    assert.match(upd[0].sql, /standby_sga_default_gb/);
  });

  it('a negative standby_sga_default_gb is rejected 400 (never written)', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    const res = await request('POST', '/capacity/config/settings', { standby_sga_default_gb: -1 });
    assert.equal(res.status, 400, res.raw);
    assert.equal(insertsInto('cap_settings').length, 0);
  });

  it('a non-numeric standby_sga_default_gb is rejected 400 (type guard)', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    const res = await request('POST', '/capacity/config/settings', { standby_sga_default_gb: 'lots' });
    assert.equal(res.status, 400, res.raw);
    assert.equal(insertsInto('cap_settings').length, 0);
  });
});

// ── Codex R2 regressions ───────────────────────────────────────────────────────
const hasQuery = (re) => state.queries.some((q) => re.test(q.sql));

describe('codex-r2: row-scenario binding on PUT', () => {
  it('a PUT to a row that belongs to a different scenario → 404 (no update)', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.rowScenario = 'other-scenario'; // the row is not in the scenario the URL names
    const res = await request('PUT', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/sites/b78a9a94-3dde-45ec-8833-b3ccb7276575', { name: 'x' });
    assert.equal(res.status, 404, res.raw);
    assert.equal(hasQuery(/^UPDATE `fmb_cap_sites`/), false);
  });

  it('a PUT to an in-scenario row proceeds', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.rowScenario = '26895068-65f1-405c-8521-2a9e1212353c';
    const res = await request('PUT', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/sites/b78a9a94-3dde-45ec-8833-b3ccb7276575', { name: 'x' });
    assert.equal(res.status, 200, res.raw);
  });
});

describe('codex-r2: dependent-aware child delete', () => {
  it('hypervisor delete unplaces its VMs (hypervisor_id → NULL) then deletes it', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    state.scenarioOwner = '4ec54b37-3f24-4759-8c85-dc37030749b6';
    const res = await request('DELETE', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/hypervisors/3bb4a2d0-19a4-4ea3-89e7-32226b5c3e2f');
    assert.equal(res.status, 200, res.raw);
    assert.ok(hasQuery(/^UPDATE `fmb_cap_vms` SET `hypervisor_id` = NULL WHERE `hypervisor_id` = \? AND scenario_id = \?/), 'VMs must be unplaced');
    assert.ok(hasQuery(/^DELETE FROM `fmb_cap_hypervisors` WHERE id = \? AND scenario_id = \?/), 'hypervisor must be deleted');
  });

  it('site delete unpins the VMs standing in it (site_id → NULL) then deletes it', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    state.scenarioOwner = '4ec54b37-3f24-4759-8c85-dc37030749b6';
    // No BLOCKING reference may be present, or the delete refuses 409 and the
    // unplace never runs — the case would then pass by never reaching the
    // statement it is about. A pinned VM is the one reference that does not
    // block, so the sweep is given one: the unplace has to be reached WITH
    // something to unplace.
    state.blockerExists = false;
    state.siteRefCounts = { cap_vms: 1 };
    const res = await request('DELETE', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/sites/6f2f9a1b-9c1e-4a25-8f0d-2d6d4a1f6c31');
    assert.equal(res.status, 200, res.raw);
    assert.ok(hasQuery(/^UPDATE `fmb_cap_vms` SET `site_id` = NULL WHERE `site_id` = \? AND scenario_id = \?/), 'VMs must be unpinned');
    assert.ok(hasQuery(/^DELETE FROM `fmb_cap_sites` WHERE id = \? AND scenario_id = \?/), 'the site must be deleted');
  });

  it('database delete detaches its db_host VMs but cascades its instances (spec §4)', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    state.scenarioOwner = '4ec54b37-3f24-4759-8c85-dc37030749b6';
    const res = await request('DELETE', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/databases/7a3d86b4-6403-4159-8ec7-66520730403d');
    assert.equal(res.status, 200, res.raw);
    // A db_host VM outlives the database it hosted, so it detaches (NULL)…
    assert.ok(hasQuery(/^UPDATE `fmb_cap_vms` SET `database_id` = NULL WHERE `database_id` = \? AND scenario_id = \?/));
    // …but the instances the wizard created as one unit are cascade-DELETED, not
    // detached (the reversal from the earlier `unplace` disposition).
    assert.ok(hasQuery(/^DELETE FROM `fmb_cap_db_instances` WHERE `database_id` = \? AND scenario_id = \?/));
    assert.equal(hasQuery(/^UPDATE `fmb_cap_db_instances` SET `database_id` = NULL/), false,
      'the instances were detached instead of cascaded');
  });

  it('custom_group delete cascades its cap_custom_group_members first', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    state.scenarioOwner = '4ec54b37-3f24-4759-8c85-dc37030749b6';
    state.ruleRefsGroup = false;
    const res = await request('DELETE', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/custom_groups/c30b82f6-daee-4dc1-803b-3832d41ed110');
    assert.equal(res.status, 200, res.raw);
    assert.ok(hasQuery(/^DELETE FROM `fmb_cap_custom_group_members` WHERE `group_id` = \?/), 'members cascaded');
    assert.ok(hasQuery(/^DELETE FROM `fmb_cap_custom_groups` WHERE id = \?/));
  });

  it('custom_group delete is refused 409 while a rule targets it (Codex r2 P1)', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    state.scenarioOwner = '4ec54b37-3f24-4759-8c85-dc37030749b6';
    state.ruleRefsGroup = true;
    const res = await request('DELETE', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/custom_groups/c30b82f6-daee-4dc1-803b-3832d41ed110');
    assert.equal(res.status, 409, res.raw);
    assert.equal(res.json.error.code, 'CONFLICT');
    assert.match(res.json.error.message, /rule targets it/);
    assert.equal(hasQuery(/^DELETE FROM `fmb_cap_custom_groups` WHERE id = \?/), false, 'no delete while referenced');
    assert.equal(hasQuery(/^DELETE FROM `fmb_cap_custom_group_members`/), false, 'no member cascade while referenced');
  });

  it('vm delete cascades its cap_db_instances first', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    const res = await request('DELETE', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/vms/d8de67d9-c84d-4e73-8817-13b2f11c02f7');
    assert.equal(res.status, 200, res.raw);
    const idxInst = state.queries.findIndex((q) => /^DELETE FROM `fmb_cap_db_instances` WHERE `vm_id` = \?/.test(q.sql));
    const idxVm = state.queries.findIndex((q) => /^DELETE FROM `fmb_cap_vms` WHERE id = \?/.test(q.sql));
    assert.ok(idxInst !== -1, 'db_instances must be deleted');
    assert.ok(idxInst < idxVm, 'children deleted before the VM');
  });

  it('rule delete cascades its cap_waivers first', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    const res = await request('DELETE', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/rules/90eb8cf2-928b-4835-8608-d2857bb3cfd6');
    assert.equal(res.status, 200, res.raw);
    assert.ok(hasQuery(/^DELETE FROM `fmb_cap_waivers` WHERE `rule_id` = \?/), 'waivers cascaded');
    assert.ok(hasQuery(/^DELETE FROM `fmb_cap_rules` WHERE id = \?/));
  });

  it('site delete cascades its hypervisors instead of refusing (spec §4 reversal)', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    // A hypervisor placed at the site (blockerExists drives the sweep's
    // cap_hypervisors count to 1) no longer blocks — it cascades.
    state.blockerExists = true;
    const res = await request('DELETE', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/sites/b78a9a94-3dde-45ec-8833-b3ccb7276575');
    assert.equal(res.status, 200, res.raw);
    // The site's hypervisors are deleted (children-first: their VMs unplace by
    // hypervisor_id via the nested subselect), then the site row goes.
    assert.ok(hasQuery(/^UPDATE `fmb_cap_vms` SET `hypervisor_id` = NULL WHERE `hypervisor_id` IN \(SELECT id FROM `fmb_cap_hypervisors` WHERE `site_id` = \? AND scenario_id = \?\)/),
      'the hypervisors\' VMs must unplace before the hypervisor rows go');
    assert.ok(hasQuery(/^DELETE FROM `fmb_cap_hypervisors` WHERE `site_id` = \? AND scenario_id = \?/), 'hypervisors cascaded');
    assert.ok(hasQuery(/^DELETE FROM `fmb_cap_sites` WHERE id = \? AND scenario_id = \?/), 'the site is deleted');
  });

  it('site delete is refused 409 while a database restricts itself to it', async () => {
    // The third reference kind through the route, not just through the sweep:
    // a JSON restriction list blocks exactly as a placed host does, and the
    // unplace must not run either.
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.blockerExists = false;
    state.siteRefCounts = { cap_databases: 2 };
    const res = await request('DELETE', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/sites/b78a9a94-3dde-45ec-8833-b3ccb7276575');
    assert.equal(res.status, 409, res.raw);
    assert.match(res.json.error.message, /2 databases restricted to this datacenter/);
    assert.equal(hasQuery(/^DELETE FROM `fmb_cap_sites`/), false);
    assert.equal(hasQuery(/^UPDATE `fmb_cap_vms` SET `site_id` = NULL/), false, 'no unplace while blocked');
  });

  // hardware_specs / vm_profiles are now GLOBAL config (deleted via /config, not a
  // scenario child) — a config-layer referential guard is a deferred follow-up.

  it('deleting a child not in the scenario → 404', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.childRowExists = false;
    const res = await request('DELETE', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/sites/nope');
    assert.equal(res.status, 404, res.raw);
    assert.equal(hasQuery(/^DELETE FROM `fmb_cap_sites`/), false);
  });

  it('a non-owner editor cannot delete a child (403)', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    state.scenarioOwner = 'e2d750c1-a8bf-4918-8970-7176a0e55d93';
    const res = await request('DELETE', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/sites/b78a9a94-3dde-45ec-8833-b3ccb7276575');
    assert.equal(res.status, 403, res.raw);
  });
});

describe('codex-r2: vm_type flip + waiver FK', () => {
  it('flipping a VM to ap_host while it has DB instances → 409', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.vmHasInstances = true;
    const res = await request('PUT', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/vms/d8de67d9-c84d-4e73-8817-13b2f11c02f7', { vm_type: 'ap_host' });
    assert.equal(res.status, 409, res.raw);
    assert.equal(res.json.error.code, 'CONFLICT');
    assert.equal(hasQuery(/^UPDATE `fmb_cap_vms`/), false);
  });

  it('flipping a VM to ap_host with no DB instances proceeds', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.vmHasInstances = false;
    const res = await request('PUT', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/vms/d8de67d9-c84d-4e73-8817-13b2f11c02f7', { vm_type: 'ap_host' });
    assert.equal(res.status, 200, res.raw);
  });

  it('a waiver whose rule_id is not in the scenario → 400', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.fkExists = false; // the FK probe finds no in-scenario rule
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/waivers', {
      rule_id: '6c41d7a9-9e8a-4282-8046-7f04517ea7e1', object_set_key: 'a|b',
    });
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'INVALID_REFERENCE');
    assert.match(res.json.error.message, /rule_id/);
  });
});

describe('R1.11 H1: cap_rules FK + override-uniqueness validation', () => {
  it('a rule custom_group_id pointing at another scenario is rejected 400', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.fkExists = true;
    state.fkScenarioId = 'other-scn'; // the custom group belongs to a different scenario
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/rules', {
      type: 'keep-apart', name: 'r', level: 'db_instance', group_by: 'custom_group',
      custom_group_id: 'd68116e3-c55c-4acc-85fd-a4e2875bdc05', severity: 'hard', enabled: true,
    });
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'INVALID_REFERENCE');
    assert.match(res.json.error.message, /custom_group_id/);
    assert.equal(insertsInto('cap_rules').length, 0);
  });

  it('an override row whose overrides_rule_id targets a SCENARIO-local rule is rejected 400', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.fkExists = true;
    state.fkScenarioId = '26895068-65f1-405c-8521-2a9e1212353c'; // a scenario-local rule, not a global template
    // The identity columns are supplied by the caller here, so the create gets
    // as far as the reference check. Omitting them would be refused one step
    // earlier now — the fill finds no GLOBAL target for a scenario-local
    // overrides_rule_id, so nothing fills `type`, and a create may not leave an
    // enumerated NOT NULL column for the engine to choose.
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/rules', {
      overrides_rule_id: '69a6afc5-2408-4913-8b9b-f093975c3497', enabled: false,
      type: 'max-vms-per-host', name: 'x', level: 'hypervisor',
    });
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'INVALID_REFERENCE');
    assert.match(res.json.error.message, /overrides_rule_id/);
    assert.equal(insertsInto('cap_rules').length, 0);
  });

  it('an override row targeting a GLOBAL template rule is accepted', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.fkExists = true;
    state.fkScenarioId = null; // the target rule is a global template row
    state.overrideDuplicateExists = false;
    // R1.14 #1: the override omits the NOT NULL identity columns — the fill guard
    // sources them from the referenced global rule so the INSERT does not 500.
    state.overrideTarget = { type: 'no-oversell', name: 'No oversell', level: 'hypervisor', group_by: 'all_of_type' };
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/rules', {
      overrides_rule_id: '7d368eef-f714-49d4-8925-89dbe7c045fa', enabled: false,
    });
    assert.equal(res.status, 200, res.raw);
    assert.equal(insertsInto('cap_rules').length, 1);
    // The identity columns were filled from the target before the INSERT.
    const ins = colsOf(insertsInto('cap_rules')[0]);
    assert.equal(ins.type, 'no-oversell');
    assert.equal(ins.name, 'No oversell');
    assert.equal(ins.level, 'hypervisor');
    assert.equal(ins.group_by, 'all_of_type');
    assert.equal(ins.overrides_rule_id, '7d368eef-f714-49d4-8925-89dbe7c045fa');
  });

  it('R1.14 #1: an override POST that omits type/name/level is refused, NAMING the reference, when the fill finds no target', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.fkExists = true;
    state.fkScenarioId = null;
    state.overrideDuplicateExists = false;
    state.overrideTarget = undefined; // the fill finds no target → columns stay null → NOT NULL trips
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/rules', {
      overrides_rule_id: '7d368eef-f714-49d4-8925-89dbe7c045fa', enabled: false,
    });
    // It used to reach the INSERT and come back as the mock's NOT NULL
    // violation — a 500 with a driver stack, standing in for what the real
    // column does. `type` is an ENUM, though, and a real column does NOT error
    // on an omission: it stores the first declared member.
    //
    // The create-time requirement then made it a stable 400 — but one naming
    // `type`, a column an override payload is documented never to carry, which
    // sends the operator to the wrong field. The refusal is the REFERENCE: the
    // `overrides_rule_id` names no global rule, and that is the only thing
    // wrong with this request.
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'INVALID_REFERENCE');
    assert.match(res.json.error.message, /overrides_rule_id/);
    assert.equal(insertsInto('cap_rules').length, 0);
  });

  it('a SECOND override for the same (scenario, global rule) is rejected 409', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.fkExists = true;
    state.fkScenarioId = null; // FK passes (global target)
    // The target global rule EXISTS — a duplicate override necessarily has one,
    // and the fill guard refuses a body that needs filling from a target that
    // is not there before any later guard is reached.
    state.overrideTarget = { type: 'no-oversell', name: 'No oversell', level: 'hypervisor', group_by: 'all_of_type' };
    state.overrideDuplicateExists = true; // an override already exists
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/rules', {
      overrides_rule_id: '7d368eef-f714-49d4-8925-89dbe7c045fa', enabled: false,
    });
    assert.equal(res.status, 409, res.raw);
    assert.equal(res.json.error.code, 'CONFLICT');
    assert.equal(insertsInto('cap_rules').length, 0);
  });

  it('R1.14 #3: a duplicate-key override INSERT (race past the pre-check) is mapped to 409, not 500', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.fkExists = true;
    state.fkScenarioId = null;
    state.overrideDuplicateExists = false; // the pre-check passes (the racing insert lands between check and insert)
    state.overrideTarget = { type: 'no-oversell', name: 'No oversell', level: 'hypervisor', group_by: 'all_of_type' };
    state.insertDuplicateError = true; // the UNIQUE (scenario_id, overrides_rule_id) index trips on INSERT
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/rules', {
      overrides_rule_id: '7d368eef-f714-49d4-8925-89dbe7c045fa', enabled: false,
    });
    assert.equal(res.status, 409, res.raw);
    assert.equal(res.json.error.code, 'CONFLICT');
  });

  // PUT (children.js's separate hand-written update path) must run the SAME
  // §17.1a global-row FK check + override-uniqueness guard as POST when it
  // repoints an EXISTING row's overrides_rule_id — a divergent PUT copy would
  // let a scenario-local or already-overridden target slip through on edit
  // even though POST blocks it on create.
  it('PUT repointing overrides_rule_id to a SCENARIO-local rule is rejected 400 (same FK guard as POST)', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.fkExists = true;
    state.fkScenarioId = '26895068-65f1-405c-8521-2a9e1212353c'; // scenario-local target, not a global template
    const res = await request('PUT', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/rules/r1', {
      overrides_rule_id: '69a6afc5-2408-4913-8b9b-f093975c3497',
    });
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'INVALID_REFERENCE');
    assert.match(res.json.error.message, /overrides_rule_id/);
    assert.ok(!state.queries.some((q) => /^UPDATE `fmb_cap_rules`/.test(q.sql)), 'no UPDATE runs when the FK guard rejects');
  });

  it('PUT repointing overrides_rule_id to a GLOBAL template rule passes the FK + uniqueness guards and updates the row', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.fkExists = true;
    state.fkScenarioId = null; // the new target is a global template row
    state.overrideDuplicateExists = false;
    const res = await request('PUT', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/rules/r1', {
      overrides_rule_id: '2f47e1eb-ff85-487c-8c18-47b93594a816',
    });
    assert.equal(res.status, 200, res.raw);
    const fkProbe = state.queries.find((q) => /SELECT id, scenario_id,[\s\S]*FROM `fmb_cap_rules` WHERE id = \? FOR UPDATE/.test(q.sql));
    const dupProbe = state.queries.find((q) => /SELECT 1 FROM `fmb_cap_rules` WHERE scenario_id = \? AND overrides_rule_id = \? AND id != \?/.test(q.sql));
    assert.ok(fkProbe, 'PUT runs the same §17.1a global-row FK probe as POST');
    assert.ok(dupProbe, 'PUT runs the same override-uniqueness probe as POST, excluding its own id');
    const updateIdx = state.queries.findIndex((q) => /^UPDATE `fmb_cap_rules`/.test(q.sql));
    assert.ok(updateIdx >= 0, 'the row is updated once both guards pass');
  });

  it('PUT repointing overrides_rule_id to an already-overridden GLOBAL rule is rejected 409 (same uniqueness guard as POST)', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.fkExists = true;
    state.fkScenarioId = null;
    state.overrideDuplicateExists = true; // another row already overrides this target
    const res = await request('PUT', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/rules/r1', {
      overrides_rule_id: '2f47e1eb-ff85-487c-8c18-47b93594a816',
    });
    assert.equal(res.status, 409, res.raw);
    assert.equal(res.json.error.code, 'CONFLICT');
    assert.ok(!state.queries.some((q) => /^UPDATE `fmb_cap_rules`/.test(q.sql)), 'no UPDATE runs when the uniqueness guard rejects');
  });
});

describe('codex-r2: child create requires the scenario to exist', () => {
  it('a child POST under a non-existent scenario → 404 (even for admin)', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.scenarioExists = false;
    const res = await request('POST', '/capacity/scenarios/nope/sites', { name: 'DC-1' });
    assert.equal(res.status, 404, res.raw);
    assert.equal(insertsInto('cap_sites').length, 0);
  });
});

// C11 T6: GET /capacity/scenarios/:id (scenarios.js, the generic single-row
// route) already 404s a deleted scenario; every child list under the same URL
// silently returned 200 [] instead — `WHERE scenario_id = ?` matches no rows
// whether the scenario is empty or gone, so the two were indistinguishable.
describe('C11 T6: a deleted scenario\'s child LIST GET answers 404, matching the parent', () => {
  it('the list GET 404s (even for a plain authenticated user — reads are open, existence is not)', async () => {
    currentUser = { id: '71d6dd0a-d1a0-4028-845a-3aa72fd3a97b', role: 'user' };
    state.scenarioExists = false;
    const res = await request('GET', '/capacity/scenarios/nope/sites');
    assert.equal(res.status, 404, res.raw);
  });

  it('a real scenario\'s list GET is unaffected — still 200, still scoped by scenario_id', async () => {
    currentUser = { id: '71d6dd0a-d1a0-4028-845a-3aa72fd3a97b', role: 'user' };
    state.scenarioExists = true;
    const res = await request('GET', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/sites');
    assert.equal(res.status, 200, res.raw);
  });

  it('the single-row GET (/:id) is deliberately NOT gated — it reads across scenarios by design', async () => {
    // Per _shared.js's mount comment: the single-row GET fetches strictly by
    // id and ignores the injected scenario filter. Widening the exists-guard
    // to this route would refuse a valid row whenever the URL's scenarioId
    // segment was stale — the opposite of the documented, intentional shape.
    currentUser = { id: '71d6dd0a-d1a0-4028-845a-3aa72fd3a97b', role: 'user' };
    state.scenarioExists = false;
    const res = await request('GET', '/capacity/scenarios/nope/sites/26895068-65f1-405c-8521-2a9e1212353c');
    assert.equal(res.status, 404, res.raw);
    // 404 here comes from the ROW not existing (the mock returns none for an
    // unmatched id), not from the scenario-exists guard — asserted by the
    // query log carrying no scenario-exists SELECT.
    assert.equal(
      state.queries.some((q) => /SELECT id FROM `fmb_cap_scenarios` WHERE id = \?$/.test(q.sql.trim())),
      false,
      'the single-row GET must not run the scenario-exists guard at all',
    );
  });

  // F3 (Review Gate M1): the same guard is shared by local-catalogues.js
  // (children.js's own mount is covered above) — witnessed here on its own
  // mount rather than assumed from the children.js case.
  it('a local-catalogue list GET also 404s a deleted scenario', async () => {
    currentUser = { id: '71d6dd0a-d1a0-4028-845a-3aa72fd3a97b', role: 'user' };
    state.scenarioExists = false;
    const res = await request('GET', '/capacity/scenarios/nope/local-catalogues/teams');
    assert.equal(res.status, 404, res.raw);
  });

  it('a real scenario\'s local-catalogue list GET is unaffected — still 200, still scoped by scenario_id', async () => {
    currentUser = { id: '71d6dd0a-d1a0-4028-845a-3aa72fd3a97b', role: 'user' };
    state.scenarioExists = true;
    const res = await request('GET', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/local-catalogues/teams');
    assert.equal(res.status, 200, res.raw);
  });
});

// ── Review-confirm: case-insensitive flip guard + role-gate-first ──────────────
describe('review-confirm: case-insensitive vm_type flip + role-gate ordering', () => {
  it("a case-variant 'AP_HOST' flip is rejected by the enum allowlist → 400 (before the in-tx flip guard)", async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.vmHasInstances = true;
    // fmb-0125 moved the flip guard INSIDE the factory write tx (locked), so it
    // now runs AFTER the factory's enumColumns validation. A non-canonical
    // 'AP_HOST' is therefore rejected 400 by the enum allowlist first — the value
    // is still refused, just with the more precise enum error. A CANONICAL
    // 'ap_host' flip with instances still yields 409 (covered above).
    const res = await request('PUT', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/vms/d8de67d9-c84d-4e73-8817-13b2f11c02f7', { vm_type: 'AP_HOST' });
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'INVALID_COLUMN_VALUE');
  });

  it("a non-canonical vm_type on create → 400 (enum allowlist)", async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/vms', { name: 'd8de67d9-c84d-4e73-8817-13b2f11c02f7', vm_type: 'AP_HOST' });
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'INVALID_COLUMN_VALUE');
    assert.equal(insertsInto('cap_vms').length, 0);
  });

  // A NULL IS A SPELLING TOO, AND IT IS NOT A HIERARCHY_NODES SPECIAL CASE.
  // `cap_vms.vm_type` is NOT NULL, so a body naming it with a null asks for a
  // value the column cannot store — same class as 'AP_HOST' above, and it now
  // earns the same 400 rather than reaching the statement and coming back as a
  // 500 with a driver stack logged per request. These two are here, on a
  // different mount from the guard the rule was written for, so a later edit
  // that scopes the rule back to one table has something to break.
  //
  // D5 review finding 2 moved WHICH gate answers this on create: the
  // required-column pre-middleware now treats an explicit null identically to
  // omission and runs before the factory's own enum check, so this earns
  // COLUMN_REQUIRED rather than INVALID_COLUMN_VALUE — still 400, still
  // nothing inserted. PUT is unaffected (the pre-middleware is POST-only), so
  // the update case below is untouched.
  it('vm_type null on create → 400, and nothing is inserted', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/vms', { name: 'd8de67d9-c84d-4e73-8817-13b2f11c02f7', vm_type: null });
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'COLUMN_REQUIRED');
    assert.equal(insertsInto('cap_vms').length, 0);
  });

  it('vm_type null on update → 400, and nothing is updated', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.vmHasInstances = false;
    const res = await request('PUT', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/vms/d8de67d9-c84d-4e73-8817-13b2f11c02f7', { vm_type: null });
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'INVALID_COLUMN_VALUE');
    assert.equal(hasQuery(/^UPDATE `fmb_cap_vms`/), false);
  });

  it('a plain user write is refused 403 before any DB query runs', async () => {
    currentUser = { id: '71d6dd0a-d1a0-4028-845a-3aa72fd3a97b', role: 'user' };
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/hypervisors', { name: 'hv', site_id: 'e6a38e92-9bb3-418f-8078-ecb06a1b1b6b', spec_id: 'bee8b12f-a86d-478a-8d5f-0813eaeebf62' });
    assert.equal(res.status, 403, res.raw);
    assert.equal(state.queries.length, 0, 'the role gate must short-circuit before touching the DB');
  });
});

// ── PR-B Task 1: per-scenario cap_settings singleton ────────────────────────
describe('pr-b task 1: scenario settings singleton (GET/PUT, no POST/DELETE)', () => {
  it('GET returns the scenario settings row when one exists', async () => {
    currentUser = { id: '71d6dd0a-d1a0-4028-845a-3aa72fd3a97b', role: 'user' };
    state.settingsExists = true;
    const res = await request('GET', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/settings');
    assert.equal(res.status, 200, res.raw);
    assert.ok(res.json.data, 'GET must return the settings row');
    assert.equal(res.json.data.scenario_id, '26895068-65f1-405c-8521-2a9e1212353c');
  });

  it('GET 404s when the scenario has no settings row yet', async () => {
    currentUser = { id: '71d6dd0a-d1a0-4028-845a-3aa72fd3a97b', role: 'user' };
    state.settingsExists = false;
    const res = await request('GET', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/settings');
    assert.equal(res.status, 404, res.raw);
  });

  it('PUT updates an existing row (owner editor)', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    state.scenarioOwner = '4ec54b37-3f24-4759-8c85-dc37030749b6';
    state.settingsExists = true;
    const res = await request('PUT', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/settings', { mem_cpu_ratio: 25 });
    assert.equal(res.status, 200, res.raw);
    assert.ok(hasQuery(/^UPDATE `fmb_cap_settings` SET `mem_cpu_ratio` = \? WHERE scenario_id = \?/));
    assert.equal(insertsInto('cap_settings').length, 0, 'an existing row must be UPDATEd, never re-INSERTed');
  });

  it('PUT mints the row on first write when the scenario has none yet (race-safe upsert)', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.settingsExists = false;
    const res = await request('PUT', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/settings', { mem_cpu_ratio: 25, util_amber_pct: 80 });
    assert.equal(res.status, 200, res.raw);
    const ins = insertsInto('cap_settings');
    assert.equal(ins.length, 1, 'a missing row must be minted exactly once');
    const row = colsOf(ins[0]);
    assert.equal(row.scenario_id, '26895068-65f1-405c-8521-2a9e1212353c');
    assert.ok(res.json.data, 'PUT must return the minted row');
  });

  it('the scenario row is locked FOR UPDATE before the settings existence check (cardinality guard)', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.settingsExists = false;
    await request('PUT', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/settings', { mem_cpu_ratio: 25 });
    const lockIdx = state.queries.findIndex((q) => /SELECT id, owner_id FROM `fmb_cap_scenarios` WHERE id = \? FOR UPDATE/.test(q.sql));
    const existsIdx = state.queries.findIndex((q) => /SELECT id FROM `fmb_cap_settings` WHERE scenario_id = \?/.test(q.sql));
    assert.ok(lockIdx !== -1 && existsIdx !== -1);
    assert.ok(lockIdx < existsIdx, 'the scenario row must be locked before the cardinality check runs');
  });

  it('PUT on a missing scenario → 404', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.deleteScenarioRows = []; // reuses the shared "SELECT owner_id ... FOR UPDATE" not-found mock
    const res = await request('PUT', '/capacity/scenarios/nope/settings', { mem_cpu_ratio: 25 });
    assert.equal(res.status, 404, res.raw);
  });

  it('a non-owner editor cannot PUT another owner’s scenario settings (403)', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    state.scenarioOwner = 'e2d750c1-a8bf-4918-8970-7176a0e55d93';
    state.settingsExists = true;
    const res = await request('PUT', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/settings', { mem_cpu_ratio: 25 });
    assert.equal(res.status, 403, res.raw);
    assert.equal(state.queries.some((q) => /^UPDATE `fmb_cap_settings`/.test(q.sql)), false);
  });

  it('a plain user PUT is refused 403 before any DB query runs', async () => {
    currentUser = { id: '71d6dd0a-d1a0-4028-845a-3aa72fd3a97b', role: 'user' };
    const res = await request('PUT', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/settings', { mem_cpu_ratio: 25 });
    assert.equal(res.status, 403, res.raw);
    assert.equal(state.queries.length, 0, 'the role gate must short-circuit before touching the DB');
  });

  it('PUT with an empty body → 400 (no writable fields)', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    const res = await request('PUT', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/settings', {});
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'BAD_REQUEST');
  });

  it('there is no POST route for scenario settings (404, not the config mount)', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/settings', { mem_cpu_ratio: 25 });
    assert.equal(res.status, 404, res.raw);
  });

  it('there is no DELETE route for scenario settings (404)', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    const res = await request('DELETE', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/settings');
    assert.equal(res.status, 404, res.raw);
  });
});

// ── Review Gate round 2: lightweight server-side type validation ───────────────
describe('review-gate-2: config.js column-type validation', () => {
  it('a string value for a number column is rejected 400 with the column name', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    const res = await request('POST', '/capacity/config/hardware_specs', {
      name: 'Spec-A', cpu_total: 'sixty-four',
    });
    assert.equal(res.status, 400, res.raw);
    assert.match(res.json.error.message, /cpu_total/);
    assert.equal(insertsInto('cap_hardware_specs').length, 0);
  });

  it('a string value for a boolean column is rejected 400', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    const res = await request('POST', '/capacity/config/field_defs', {
      entity_type: 'vm', field_key: 'x', data_type: 'text', required: 'true',
    });
    assert.equal(res.status, 400, res.raw);
    assert.match(res.json.error.message, /required/);
  });

  it('a string value for a JSON column is rejected 400', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    const res = await request('POST', '/capacity/config/rules', {
      type: 'keep-apart', name: 'x', level: 'db_instance', filters: 'not-an-object',
    });
    assert.equal(res.status, 400, res.raw);
    assert.match(res.json.error.message, /filters/);
  });

  it('a real object value for a number column is rejected 400', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    const res = await request('POST', '/capacity/config/vm_profiles', {
      class: 'AP', name: 'x', mode: 'custom', cpu: { not: 'a number' },
    });
    assert.equal(res.status, 400, res.raw);
    assert.match(res.json.error.message, /cpu/);
  });

  it('layer_defaults as an array (not an object) is rejected 400', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    const res = await request('POST', '/capacity/config/settings', {
      mem_cpu_ratio: 20, layer_defaults: [1, 2, 3],
    });
    assert.equal(res.status, 400, res.raw);
    assert.match(res.json.error.message, /layer_defaults/);
  });

  it('a well-typed body still passes (no false-positive rejection)', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    const res = await request('POST', '/capacity/config/hardware_specs', {
      name: 'Spec-A', cpu_total: 64, mem_total_gb: 1280, disk_total_gb: 10000,
      cpu_reserved: 2, mem_reserved_pct: 10, disk_reserved_gb: 100,
    });
    assert.equal(res.status, 201, res.raw);
  });

  it('a null value is not rejected (present-but-null passes through)', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    const res = await request('POST', '/capacity/config/settings', {
      mem_cpu_ratio: 20, layer_defaults: null,
    });
    assert.equal(res.status, 201, res.raw);
  });
});

describe('review-gate-2: settings.js column-type validation', () => {
  it('a string value for mem_cpu_ratio is rejected 400', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    const res = await request('PUT', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/settings', { mem_cpu_ratio: '20' });
    assert.equal(res.status, 400, res.raw);
    assert.match(res.json.error.message, /mem_cpu_ratio/);
    assert.equal(hasQuery(/^UPDATE `fmb_cap_settings`/), false);
    assert.equal(insertsInto('cap_settings').length, 0);
  });

  it('layer_defaults as an array is rejected 400', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    const res = await request('PUT', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/settings', { layer_defaults: ['x'] });
    assert.equal(res.status, 400, res.raw);
    assert.match(res.json.error.message, /layer_defaults/);
  });

  it('overcommit_default_enabled as a number is rejected 400', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    const res = await request('PUT', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/settings', { overcommit_default_enabled: 1 });
    assert.equal(res.status, 400, res.raw);
    assert.match(res.json.error.message, /overcommit_default_enabled/);
  });
});

describe('review-gate-2: field_defs reserved field_key + NULL_SENTINEL enum option', () => {
  it('field_key "__proto__" is rejected 400 on the global config mount', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    const res = await request('POST', '/capacity/config/field_defs', {
      entity_type: 'vm', field_key: '__proto__', data_type: 'text',
    });
    assert.equal(res.status, 400, res.raw);
    assert.match(res.json.error.message, /reserved/);
    assert.equal(insertsInto('cap_field_defs').length, 0);
  });

  it('field_key "constructor" is rejected 400 on the scenario-scoped mount', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    const res = await request('POST', '/capacity/config/field_defs', {
      entity_type: 'vm', field_key: 'constructor', data_type: 'text',
    });
    assert.equal(res.status, 400, res.raw);
    assert.match(res.json.error.message, /reserved/);
    assert.equal(insertsInto('cap_field_defs').length, 0);
  });

  it('an enum option value of "__unset__" is rejected 400 on the global config mount', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    const res = await request('POST', '/capacity/config/field_defs', {
      entity_type: 'vm', field_key: 'tier', data_type: 'enum', options: ['a', '__unset__'],
    });
    assert.equal(res.status, 400, res.raw);
    assert.match(res.json.error.message, /__unset__/);
  });

  it('an enum option object value of "__unset__" is rejected 400', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    const res = await request('POST', '/capacity/config/field_defs', {
      entity_type: 'vm', field_key: 'tier', data_type: 'enum',
      options: [{ label: 'Unset', value: '__unset__' }],
    });
    assert.equal(res.status, 400, res.raw);
    assert.match(res.json.error.message, /__unset__/);
  });

  it('a legitimate field_key and enum options are accepted', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    const res = await request('POST', '/capacity/config/field_defs', {
      entity_type: 'vm', field_key: 'tier', data_type: 'enum', options: ['a', 'b'],
    });
    assert.equal(res.status, 201, res.raw);
  });

  it('a non-enum field_def with unrelated options-shaped junk is unaffected', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    const res = await request('POST', '/capacity/config/field_defs', {
      entity_type: 'vm', field_key: 'note', data_type: 'text',
    });
    assert.equal(res.status, 201, res.raw);
  });
});

// ── codex-r1: field_defs entity_type 'scenario' block + native-key collision ──
describe('codex-r1: field_defs entity_type "scenario" rejected + native-column key collision', () => {
  it('entity_type "scenario" is rejected 400 on the global config mount (cap_scenarios has no metadata column)', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    const res = await request('POST', '/capacity/config/field_defs', {
      entity_type: 'scenario', field_key: 'note', data_type: 'text',
    });
    assert.equal(res.status, 400, res.raw);
    assert.match(res.json.error.message, /scenario/);
    assert.equal(insertsInto('cap_field_defs').length, 0);
  });

  it('entity_type "scenario" is rejected 400 on the scenario-scoped mount', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    const res = await request('POST', '/capacity/config/field_defs', {
      entity_type: 'scenario', field_key: 'note', data_type: 'text',
    });
    assert.equal(res.status, 400, res.raw);
    assert.match(res.json.error.message, /scenario/);
    assert.equal(insertsInto('cap_field_defs').length, 0);
  });

  it('field_key "cpu" for entity_type "vm" collides with a native column → 400', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    const res = await request('POST', '/capacity/config/field_defs', {
      entity_type: 'vm', field_key: 'cpu', data_type: 'number',
    });
    assert.equal(res.status, 400, res.raw);
    assert.match(res.json.error.message, /conflicts with a native vm column/);
    assert.equal(insertsInto('cap_field_defs').length, 0);
  });

  it('field_key "topology" for entity_type "site" collides with a native column → 400', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    state.scenarioOwner = '4ec54b37-3f24-4759-8c85-dc37030749b6';
    const res = await request('POST', '/capacity/config/field_defs', {
      entity_type: 'site', field_key: 'topology', data_type: 'text',
    });
    assert.equal(res.status, 400, res.raw);
    assert.match(res.json.error.message, /conflicts with a native site column/);
  });

  it('field_key "order_index" for entity_type "site" collides with the new cap_sites column (spec §6.1) → 400', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    const res = await request('POST', '/capacity/config/field_defs', {
      entity_type: 'site', field_key: 'order_index', data_type: 'number',
    });
    assert.equal(res.status, 400, res.raw);
    assert.match(res.json.error.message, /conflicts with a native site column/);
    assert.equal(insertsInto('cap_field_defs').length, 0);
  });

  it('the SAME field_key is fine under a DIFFERENT entity_type that has no such native column', async () => {
    // 'cpu' collides with vm's own native column but is not a native column
    // of 'site' — the collision check is scoped per entity_type, not global.
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    const res = await request('POST', '/capacity/config/field_defs', {
      entity_type: 'site', field_key: 'cpu', data_type: 'number',
    });
    assert.equal(res.status, 201, res.raw);
  });
});

// ── codex-r1: field_defs PUT partial-update merge (enum/options cross-column gap) ──
describe('codex-r1: field_defs PUT partial-update merge validates the TRUE final state', () => {
  it('PUT { data_type: "enum" } alone, relying on the row\'s already-stored options, is rejected when those options carry the sentinel', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.fieldDefExisting = { data_type: 'text', options: JSON.stringify(['a', '__unset__']) };
    const res = await request('PUT', '/capacity/config/field_defs/f1', { data_type: 'enum' });
    assert.equal(res.status, 400, res.raw);
    assert.match(res.json.error.message, /__unset__/);
    assert.equal(state.queries.some((q) => /^UPDATE `fmb_cap_field_defs`/.test(q.sql)), false, 'the row must not be written when the merged state is invalid');
  });

  it('PUT { options: [...] } alone, relying on the row\'s already-stored data_type "enum", is rejected when the NEW options carry the sentinel', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    state.scenarioOwner = '4ec54b37-3f24-4759-8c85-dc37030749b6';
    state.fieldDefExisting = { data_type: 'enum', options: JSON.stringify(['a', 'b']) };
    const res = await request('PUT', '/capacity/config/field_defs/f1', { options: ['a', '__unset__'] });
    assert.equal(res.status, 400, res.raw);
    assert.match(res.json.error.message, /__unset__/);
    assert.equal(state.queries.some((q) => /^UPDATE `fmb_cap_field_defs`/.test(q.sql)), false, 'the row must not be written when the merged state is invalid');
  });

  it('PUT { data_type: "enum" } alone is accepted when the row\'s already-stored options are clean', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.fieldDefExisting = { data_type: 'text', options: JSON.stringify(['a', 'b']) };
    const res = await request('PUT', '/capacity/config/field_defs/f1', { data_type: 'enum' });
    assert.equal(res.status, 200, res.raw);
  });
});

// ── codex-r2 (round 2): field_defs PUT collision-merge — entity_type/field_key ──
describe('codex-r2b: field_defs PUT partial-update merge — entity_type/field_key native-column collision', () => {
  it('PUT { field_key: "cpu" } alone, relying on the row\'s already-stored entity_type "vm", is rejected (native vm column)', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.fieldDefExisting = { entity_type: 'vm', field_key: 'custom_note', data_type: 'text', options: null };
    const res = await request('PUT', '/capacity/config/field_defs/f1', { field_key: 'cpu' });
    assert.equal(res.status, 400, res.raw);
    assert.match(res.json.error.message, /conflicts with a native vm column/);
    assert.equal(state.queries.some((q) => /^UPDATE `fmb_cap_field_defs`/.test(q.sql)), false);
  });

  it('PUT { entity_type: "vm" } alone, relying on the row\'s already-stored field_key "cpu", is rejected (field_key "cpu" is native only on vm)', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    state.scenarioOwner = '4ec54b37-3f24-4759-8c85-dc37030749b6';
    // 'cpu' is NOT a native column of 'site' (its current entity_type) —
    // this row was legitimately created — but switching entity_type to 'vm'
    // makes the SAME field_key collide.
    state.fieldDefExisting = { entity_type: 'site', field_key: 'cpu', data_type: 'number', options: null };
    const res = await request('PUT', '/capacity/config/field_defs/f1', { entity_type: 'vm' });
    assert.equal(res.status, 400, res.raw);
    assert.match(res.json.error.message, /conflicts with a native vm column/);
    assert.equal(state.queries.some((q) => /^UPDATE `fmb_cap_field_defs`/.test(q.sql)), false);
  });

  it('PUT { field_key: "note" } alone is accepted when it does not collide with the row\'s already-stored entity_type', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.fieldDefExisting = { entity_type: 'vm', field_key: 'custom_note', data_type: 'text', options: null };
    const res = await request('PUT', '/capacity/config/field_defs/f1', { field_key: 'note' });
    assert.equal(res.status, 200, res.raw);
  });
});

// ── codex-r2 (round 2): nullable-aware column type validation ──────────────────
describe('codex-r2b: nullable-aware column-type validation (settings/tiers/profiles/config)', () => {
  it('cap_settings.mem_cpu_ratio (NOT NULL) explicit null → 400 with the column name, on the global config mount', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    const res = await request('POST', '/capacity/config/settings', { mem_cpu_ratio: null, util_amber_pct: 80 });
    assert.equal(res.status, 400, res.raw);
    assert.match(res.json.error.message, /mem_cpu_ratio must not be null/);
    assert.equal(insertsInto('cap_settings').length, 0);
  });

  it('cap_settings.util_amber_pct (NOT NULL) explicit null → 400, on the scenario-scoped settings mount', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    state.scenarioOwner = '4ec54b37-3f24-4759-8c85-dc37030749b6';
    const res = await request('PUT', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/settings', { util_amber_pct: null });
    assert.equal(res.status, 400, res.raw);
    assert.match(res.json.error.message, /util_amber_pct must not be null/);
  });

  it('cap_settings.layer_defaults (nullable) explicit null still passes', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    const res = await request('POST', '/capacity/config/settings', { mem_cpu_ratio: 20, layer_defaults: null });
    assert.equal(res.status, 201, res.raw);
  });

  it('cap_hardware_specs.cpu_total (NOT NULL) explicit null → 400', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    const res = await request('PUT', '/capacity/config/hardware_specs/s1', { cpu_total: null });
    assert.equal(res.status, 400, res.raw);
    assert.match(res.json.error.message, /cpu_total must not be null/);
  });

  it('cap_hardware_specs.metadata (nullable) explicit null still passes', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    const res = await request('PUT', '/capacity/config/hardware_specs/s1', { metadata: null });
    assert.equal(res.status, 200, res.raw);
  });

  it('cap_vm_profiles.cpu (NOT NULL) explicit null → 400', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    const res = await request('PUT', '/capacity/config/vm_profiles/p1', { cpu: null });
    assert.equal(res.status, 400, res.raw);
    assert.match(res.json.error.message, /cpu must not be null/);
  });

  it('cap_vm_profiles.mem_gb (nullable — derived in formula mode) explicit null still passes', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    const res = await request('POST', '/capacity/config/vm_profiles', {
      class: 'DB', name: 'p-null-mem', mode: 'formula', cpu: 16, mem_gb: null, sga_cap_gb: null, metadata: null,
    });
    assert.equal(res.status, 201, res.raw);
  });

  it('an OMITTED column (not present in the body at all) is still unaffected by the nullable check', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    const res = await request('PUT', '/capacity/config/hardware_specs/s1', { name: 'M' });
    assert.equal(res.status, 200, res.raw);
  });
});

// ── codex-r2 (round 2): field_defs (scenario_id, entity_type, field_key) uniqueness ──
describe('codex-r2b: field_defs (scenario_id, entity_type, field_key) uniqueness', () => {
  it('POST a field_key already defined for the same entity_type on the global config mount → 400', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.fieldDefDuplicateExists = true;
    const res = await request('POST', '/capacity/config/field_defs', {
      entity_type: 'vm', field_key: 'zone', data_type: 'text',
    });
    assert.equal(res.status, 400, res.raw);
    assert.match(res.json.error.message, /already exists/);
    assert.equal(insertsInto('cap_field_defs').length, 0);
  });

  it('POST a field_key already defined for the same entity_type on the scenario-scoped mount → 400', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    state.scenarioOwner = '4ec54b37-3f24-4759-8c85-dc37030749b6';
    state.fieldDefDuplicateExists = true;
    const res = await request('POST', '/capacity/config/field_defs', {
      entity_type: 'vm', field_key: 'zone', data_type: 'text',
    });
    assert.equal(res.status, 400, res.raw);
    assert.match(res.json.error.message, /already exists/);
    assert.equal(insertsInto('cap_field_defs').length, 0);
  });

  it('POST with no pre-existing duplicate succeeds', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.fieldDefDuplicateExists = false;
    const res = await request('POST', '/capacity/config/field_defs', {
      entity_type: 'vm', field_key: 'unique-key', data_type: 'text',
    });
    assert.equal(res.status, 201, res.raw);
  });

  it('PUT changing field_key to one that collides with ANOTHER row\'s (entity_type, field_key) → 400', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.fieldDefExisting = { entity_type: 'vm', field_key: 'old_key', data_type: 'text', options: null };
    state.fieldDefDuplicateExists = true;
    const res = await request('PUT', '/capacity/config/field_defs/f1', { field_key: 'new_key' });
    assert.equal(res.status, 400, res.raw);
    assert.match(res.json.error.message, /already exists/);
    assert.equal(state.queries.some((q) => /^UPDATE `fmb_cap_field_defs`/.test(q.sql)), false);
  });

  it('PUT that does NOT touch entity_type/field_key does not re-run the uniqueness probe (a cosmetic edit is unaffected)', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.fieldDefExisting = { entity_type: 'vm', field_key: 'old_key', data_type: 'text', options: null };
    // Even though ANOTHER row supposedly already owns SOME tuple, this PUT
    // never touches entity_type/field_key, so the key tuple can't have
    // changed — the probe must not even run, let alone reject.
    state.fieldDefDuplicateExists = true;
    const res = await request('PUT', '/capacity/config/field_defs/f1', { label: 'Renamed label' });
    assert.equal(res.status, 200, res.raw);
  });
});

// ── PR-E: versions (server-computed snapshot) + clone ──────────────────────────
// A realistic scenario-scoped fixture with cross-table FKs and a waiver whose
// object_set_key references two subject ids — exercises the full id-remap path.
// Key order matches SNAPSHOT_TABLES so a byte-compare of the frozen snapshot is
// deterministic.
// Keys in SNAPSHOT_TABLES order; every catalogue ref points at a LOCAL row present
// in this fixture, so the §17.4 closure step adds nothing and the byte-compare holds.
function prEScenarioRows() {
  return {
    hardware_specs: [{ id: '8d9a523d-173d-4446-83f5-888b5ce48df4', scenario_id: '26895068-65f1-405c-8521-2a9e1212353c', name: 'Spec-A', cpu_total: 64, mem_total_gb: 1280, disk_total_gb: 10000, cpu_reserved: 1, mem_reserved_pct: 10, disk_reserved_gb: 100, metadata: null }],
    disk_combos: [{ id: '3f867c4e-5600-4721-880b-391c3752f046', scenario_id: '26895068-65f1-405c-8521-2a9e1212353c', name: 'OS only', sizes: null }],
    teams: [{ id: '53fdf340-67c0-4dbb-88fc-d028a15005b7', scenario_id: '26895068-65f1-405c-8521-2a9e1212353c', name: 'erp', color: '#3355ff' }],
    vm_profiles: [{ id: '45958522-1722-4a83-8fa4-ba92d7d793d8', scenario_id: '26895068-65f1-405c-8521-2a9e1212353c', class: 'DB', name: 'DB-16C', mode: 'formula', cpu: 16, mem_gb: null, sga_cap_gb: null, allowed_disk_combos: null, metadata: null }],
    settings: [{ id: 'f044dae7-5285-4361-8adc-7e657994ca56', scenario_id: '26895068-65f1-405c-8521-2a9e1212353c', mem_cpu_ratio: 20, sga_factor: 0.982, sga_divisor: 2, sga_subtract: 2, util_amber_pct: 80, util_red_pct: 90, overcommit_default_enabled: 0, layer_defaults: null }],
    rules: [{ id: '90eb8cf2-928b-4835-8608-d2857bb3cfd6', scenario_id: '26895068-65f1-405c-8521-2a9e1212353c', overrides_rule_id: null, type: 'keep-apart', name: 'Keep apart', level: 'db_instance', group_by: 'each_primary_cluster', custom_group_id: null, filters: null, params: null, severity: 'hard', enabled: 1 }],
    sites: [{ id: 'b78a9a94-3dde-45ec-8833-b3ccb7276575', scenario_id: '26895068-65f1-405c-8521-2a9e1212353c', name: 'DC-1', topology: 'site', metadata: null }],
    hypervisors: [{ id: '3bb4a2d0-19a4-4ea3-89e7-32226b5c3e2f', scenario_id: '26895068-65f1-405c-8521-2a9e1212353c', site_id: 'b78a9a94-3dde-45ec-8833-b3ccb7276575', spec_id: '8d9a523d-173d-4446-83f5-888b5ce48df4', name: 'HV-1', metadata: null }],
    databases: [{ id: '76d4fe21-b797-46c4-87e1-eddb216234c6', scenario_id: '26895068-65f1-405c-8521-2a9e1212353c', function_name: 'erp', topology: 'primary', node_count: null, profile_id: '45958522-1722-4a83-8fa4-ba92d7d793d8', disk_combo_id: '3f867c4e-5600-4721-880b-391c3752f046', team_id: '53fdf340-67c0-4dbb-88fc-d028a15005b7', description: null, metadata: null }],
    vms: [{ id: 'd8de67d9-c84d-4e73-8817-13b2f11c02f7', scenario_id: '26895068-65f1-405c-8521-2a9e1212353c', vm_type: 'db_host', hypervisor_id: '3bb4a2d0-19a4-4ea3-89e7-32226b5c3e2f', site_id: 'b78a9a94-3dde-45ec-8833-b3ccb7276575', cpu: 16, mem_gb: 320, disk_gb: 1000, sizing_profile_id: '45958522-1722-4a83-8fa4-ba92d7d793d8', disk_combo_id: '3f867c4e-5600-4721-880b-391c3752f046', team_id: '53fdf340-67c0-4dbb-88fc-d028a15005b7', database_id: '76d4fe21-b797-46c4-87e1-eddb216234c6', name: 'VM-1', metadata: null }],
    db_instances: [{ id: '54e9efcd-df46-407b-8eaf-824d49e5a4a1', scenario_id: '26895068-65f1-405c-8521-2a9e1212353c', vm_id: 'd8de67d9-c84d-4e73-8817-13b2f11c02f7', database_id: '76d4fe21-b797-46c4-87e1-eddb216234c6', name: 'erp1', role: 'primary', sga_gb: 40, metadata: null }],
    custom_groups: [{ id: '51f5ff48-8456-4553-802b-d92d7dd1cd4f', scenario_id: '26895068-65f1-405c-8521-2a9e1212353c', name: 'group-a', team_id: '53fdf340-67c0-4dbb-88fc-d028a15005b7' }],
    custom_group_members: [{ id: '2214961c-ff4c-492a-8420-dc3464b348cf', scenario_id: '26895068-65f1-405c-8521-2a9e1212353c', group_id: '51f5ff48-8456-4553-802b-d92d7dd1cd4f', member_vm_id: 'd8de67d9-c84d-4e73-8817-13b2f11c02f7', member_instance_id: null }],
    waivers: [{ id: 'f798690c-a911-4c36-8594-355dd7c1e187', scenario_id: '26895068-65f1-405c-8521-2a9e1212353c', rule_id: '90eb8cf2-928b-4835-8608-d2857bb3cfd6', object_set_key: '3bb4a2d0-19a4-4ea3-89e7-32226b5c3e2f|d8de67d9-c84d-4e73-8817-13b2f11c02f7', note: null, created_by: '4ec54b37-3f24-4759-8c85-dc37030749b6' }],
  };
}
const PRE_SOURCE_IDS = new Set(['26895068-65f1-405c-8521-2a9e1212353c', '8d9a523d-173d-4446-83f5-888b5ce48df4', '3f867c4e-5600-4721-880b-391c3752f046', '53fdf340-67c0-4dbb-88fc-d028a15005b7', '45958522-1722-4a83-8fa4-ba92d7d793d8', 'f044dae7-5285-4361-8adc-7e657994ca56', '90eb8cf2-928b-4835-8608-d2857bb3cfd6', 'b78a9a94-3dde-45ec-8833-b3ccb7276575', '3bb4a2d0-19a4-4ea3-89e7-32226b5c3e2f', '76d4fe21-b797-46c4-87e1-eddb216234c6', 'd8de67d9-c84d-4e73-8817-13b2f11c02f7', '54e9efcd-df46-407b-8eaf-824d49e5a4a1', '51f5ff48-8456-4553-802b-d92d7dd1cd4f', '2214961c-ff4c-492a-8420-dc3464b348cf', 'f798690c-a911-4c36-8594-355dd7c1e187']);

describe('PR-E: save-as-new-version (server-computed snapshot)', () => {
  it('freezes every scenario-scoped table into the snapshot; versions is excluded', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    state.scenarioOwner = '4ec54b37-3f24-4759-8c85-dc37030749b6';
    state.scenarioRows = prEScenarioRows();
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/versions', { name: '1b4d1b85-ca5b-4f82-8137-9ea5b1f5e30d', note: 'first cut' });
    assert.equal(res.status, 201, res.raw);
    const row = colsOf(insertsInto('cap_versions')[0]);
    const doc = JSON.parse(row.snapshot);
    assert.equal(doc.schema_rev, 1);
    const expectedKeys = ['hardware_specs', 'disk_combos', 'teams', 'vm_profiles', 'settings', 'rules', 'sites', 'hypervisors', 'databases', 'vms', 'db_instances', 'custom_groups', 'custom_group_members', 'waivers'];
    assert.deepEqual(Object.keys(doc.tables), expectedKeys, 'all 14 scenario-scoped tables frozen, in order');
    assert.equal(Object.prototype.hasOwnProperty.call(doc.tables, 'versions'), false, 'versions never nests a version');
    assert.equal(doc.tables.vms[0].cpu, 16);
    assert.equal(doc.tables.waivers[0].object_set_key, '3bb4a2d0-19a4-4ea3-89e7-32226b5c3e2f|d8de67d9-c84d-4e73-8817-13b2f11c02f7');
  });

  it('byte-compares the frozen snapshot and proves a later working-copy edit never rewrites it', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.scenarioOwner = null;
    const fixture = prEScenarioRows();
    state.scenarioRows = fixture;
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/versions', { name: 'frozen' });
    assert.equal(res.status, 201, res.raw);
    const frozen = colsOf(insertsInto('cap_versions')[0]).snapshot;
    // Byte-for-byte: the server document is exactly the raw rows under schema_rev 1.
    assert.equal(frozen, JSON.stringify({ schema_rev: 1, tables: fixture }));
    // Edit the working copy (a normal save). The version row must not be touched.
    const edit = await request('PUT', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/vms/d8de67d9-c84d-4e73-8817-13b2f11c02f7', { cpu: 8 });
    assert.equal(edit.status, 200, edit.raw);
    assert.equal(state.queries.some((q) => /^UPDATE `fmb_cap_versions`/.test(q.sql)), false, 'a version is immutable — a normal save never rewrites it');
  });

  it('snapshot stores only raw rows — no derived used/free/utilization keys', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.scenarioOwner = null;
    state.scenarioRows = prEScenarioRows();
    await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/versions', { name: 'raw-only' });
    const frozen = colsOf(insertsInto('cap_versions')[0]).snapshot;
    for (const derived of ['"used"', '"free"', '"utilization"', '"usable"']) {
      assert.equal(frozen.includes(derived), false, `a derived key ${derived} must never be persisted`);
    }
  });

  it('rejects an empty name (400)', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.scenarioOwner = null;
    state.scenarioRows = prEScenarioRows();
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/versions', { name: '   ' });
    assert.equal(res.status, 400, res.raw);
    assert.equal(insertsInto('cap_versions').length, 0);
  });

  it('a non-owner editor cannot create a version (403), nothing frozen', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    state.scenarioOwner = 'e2d750c1-a8bf-4918-8970-7176a0e55d93';
    state.scenarioRows = prEScenarioRows();
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/versions', { name: '1b4d1b85-ca5b-4f82-8137-9ea5b1f5e30d' });
    assert.equal(res.status, 403, res.raw);
    assert.equal(insertsInto('cap_versions').length, 0);
  });

  it('a plain user cannot create a version (403)', async () => {
    currentUser = { id: '71d6dd0a-d1a0-4028-845a-3aa72fd3a97b', role: 'user' };
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/versions', { name: '1b4d1b85-ca5b-4f82-8137-9ea5b1f5e30d' });
    assert.equal(res.status, 403, res.raw);
    assert.equal(insertsInto('cap_versions').length, 0);
  });

  it('creating a version on a missing scenario → 404', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.deleteScenarioRows = []; // owner FOR UPDATE probe finds no scenario
    const res = await request('POST', '/capacity/scenarios/nope/versions', { name: '1b4d1b85-ca5b-4f82-8137-9ea5b1f5e30d' });
    assert.equal(res.status, 404, res.raw);
  });
});

describe('PR-E: version read + delete', () => {
  it('GET one returns the parsed snapshot', async () => {
    currentUser = { id: '71d6dd0a-d1a0-4028-845a-3aa72fd3a97b', role: 'user' };
    state.versionRow = [{ id: '1b4d1b85-ca5b-4f82-8137-9ea5b1f5e30d', scenario_id: '26895068-65f1-405c-8521-2a9e1212353c', name: '1b4d1b85-ca5b-4f82-8137-9ea5b1f5e30d', note: null, snapshot: JSON.stringify({ schema_rev: 1, tables: prEScenarioRows() }), created_at: 't', created_by: '4ec54b37-3f24-4759-8c85-dc37030749b6' }];
    const res = await request('GET', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/versions/v1');
    assert.equal(res.status, 200, res.raw);
    assert.equal(typeof res.json.data.snapshot, 'object', 'snapshot handed to the client parsed');
    assert.equal(res.json.data.snapshot.tables.sites[0].id, 'b78a9a94-3dde-45ec-8833-b3ccb7276575');
  });

  it('GET a version belonging to another scenario → 404', async () => {
    currentUser = { id: '71d6dd0a-d1a0-4028-845a-3aa72fd3a97b', role: 'user' };
    state.versionRow = []; // WHERE id=? AND scenario_id=? finds nothing
    const res = await request('GET', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/versions/foreign');
    assert.equal(res.status, 404, res.raw);
  });

  it('owner deletes a version (200)', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    state.scenarioOwner = '4ec54b37-3f24-4759-8c85-dc37030749b6';
    state.childRowExists = true; // the FOR UPDATE probe finds the version in-scenario
    const res = await request('DELETE', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/versions/v1');
    assert.equal(res.status, 200, res.raw);
    assert.ok(state.queries.some((q) => /^DELETE FROM `fmb_cap_versions` WHERE id = \? AND scenario_id = \?/.test(q.sql)));
  });

  it('a non-owner editor cannot delete a version (403), nothing deleted', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    state.scenarioOwner = 'e2d750c1-a8bf-4918-8970-7176a0e55d93';
    const res = await request('DELETE', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/versions/v1');
    assert.equal(res.status, 403, res.raw);
    assert.equal(state.queries.some((q) => /^DELETE FROM `fmb_cap_versions`/.test(q.sql)), false);
  });

  it('deleting a version absent from the scenario → 404', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.scenarioOwner = null;
    state.childRowExists = false; // the FOR UPDATE probe finds no such version here
    const res = await request('DELETE', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/versions/ghost');
    assert.equal(res.status, 404, res.raw);
    assert.equal(state.queries.some((q) => /^DELETE FROM `fmb_cap_versions`/.test(q.sql)), false);
  });

  it('a plain user cannot delete a version (403)', async () => {
    currentUser = { id: '71d6dd0a-d1a0-4028-845a-3aa72fd3a97b', role: 'user' };
    const res = await request('DELETE', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/versions/v1');
    assert.equal(res.status, 403, res.raw);
  });
});

// Collect the single clone INSERT for a table as a { col: value } row.
const cloneRow = (table) => colsOf(insertsInto(table)[0]);

describe('PR-E: clone scenario (live working state)', () => {
  it('deep-copies every table with NEW ids, remapped FKs, and no source mutation', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    state.scenarioRows = prEScenarioRows();
    state.sourceScenarioRow = [{ name: 'Source', note: 'src note' }];
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/clone', { name: 'Clone A' });
    assert.equal(res.status, 201, res.raw);

    const scen = cloneRow('cap_scenarios');
    assert.equal(scen.owner_id, '4ec54b37-3f24-4759-8c85-dc37030749b6', 'editor clone stamps the actor as owner');
    assert.equal(scen.name, 'Clone A');
    const newScenarioId = scen.id;
    assert.notEqual(newScenarioId, '26895068-65f1-405c-8521-2a9e1212353c');

    // Every child row carries a NEW id + the new scenario_id.
    for (const table of ['cap_hardware_specs', 'cap_disk_combos', 'cap_teams', 'cap_vm_profiles', 'cap_settings', 'cap_rules', 'cap_sites', 'cap_hypervisors', 'cap_databases', 'cap_vms', 'cap_db_instances', 'cap_custom_groups', 'cap_custom_group_members', 'cap_waivers']) {
      const row = cloneRow(table);
      assert.equal(row.scenario_id, newScenarioId, `${table} clone carries the new scenario_id`);
      assert.equal(PRE_SOURCE_IDS.has(row.id), false, `${table} clone mints a NEW id`);
    }

    // FK remap correctness: each FK points at the referenced (local) row's NEW id.
    const site = cloneRow('cap_sites');
    const spec = cloneRow('cap_hardware_specs');
    const combo = cloneRow('cap_disk_combos');
    const team = cloneRow('cap_teams');
    const rule = cloneRow('cap_rules');
    const prof = cloneRow('cap_vm_profiles');
    const hv = cloneRow('cap_hypervisors');
    const dbx = cloneRow('cap_databases');
    const vm = cloneRow('cap_vms');
    const db = cloneRow('cap_db_instances');
    const cg = cloneRow('cap_custom_groups');
    const cgm = cloneRow('cap_custom_group_members');
    const wv = cloneRow('cap_waivers');
    assert.equal(hv.site_id, site.id);
    assert.equal(hv.spec_id, spec.id);
    assert.equal(vm.hypervisor_id, hv.id);
    assert.equal(vm.sizing_profile_id, prof.id);
    assert.equal(vm.disk_combo_id, combo.id);
    assert.equal(vm.team_id, team.id);
    assert.equal(vm.database_id, dbx.id);
    assert.equal(dbx.profile_id, prof.id);
    assert.equal(dbx.team_id, team.id);
    assert.equal(db.vm_id, vm.id);
    assert.equal(db.database_id, dbx.id);
    assert.equal(cgm.group_id, cg.id);
    assert.equal(cgm.member_vm_id, vm.id);
    assert.equal(wv.rule_id, rule.id);
    // object_set_key rebuilt from the remapped subject ids, re-sorted.
    assert.equal(wv.object_set_key, [hv.id, vm.id].sort().join('|'));

    // No FK column and no object_set_key segment references a SOURCE id.
    const fkValues = [hv.site_id, hv.spec_id, vm.hypervisor_id, vm.sizing_profile_id, vm.disk_combo_id, vm.team_id, vm.database_id, dbx.profile_id, db.vm_id, db.database_id, cgm.group_id, cgm.member_vm_id, wv.rule_id, ...wv.object_set_key.split('|')];
    for (const v of fkValues) assert.equal(PRE_SOURCE_IDS.has(v), false, `no clone FK/object_set_key may reference a source id (${v})`);

    // Independence at the SQL level: the source is only READ, never written.
    //
    // BOUND TO THE SOURCE, rather than "any write at all". The clone finishes by
    // deriving the new scenario's own `cap_vms.site_id` cache from the hosts the
    // copied VMs stand on, so a blanket `/^UPDATE /` would now report a write to
    // the CLONE as a mutation of the SOURCE. What this case is about is which
    // rows a write can reach, so that is what it asks: no UPDATE and no DELETE
    // may name the source scenario or any source row id.
    const sourceWrites = state.queries.filter(
      (q) => /^(UPDATE|DELETE) /.test(q.sql)
        && (q.params || []).some((p) => PRE_SOURCE_IDS.has(p)),
    );
    assert.deepEqual(sourceWrites.map((q) => q.sql), [], 'clone never writes to the source');
    // And every write it DOES issue is bound to the clone.
    for (const q of state.queries.filter((w) => /^(UPDATE|DELETE) /.test(w.sql))) {
      assert.ok(
        (q.params || []).includes(newScenarioId),
        `a clone write is not scoped to the new scenario: ${q.sql}`,
      );
    }
  });

  it('remaps a scenario-local vm_profile allowed_disk_combos JSON list to the clone combo ids (513-cand #9)', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    const rows = prEScenarioRows();
    // A scenario-local VM profile whose allow-list points at the scenario-local
    // disk-combo (combo-1). CLONE_FK_COLUMNS has no vm_profiles entry, so without
    // the JSON-list remap this column would carry the SOURCE id into the clone.
    rows.vm_profiles = [{ ...rows.vm_profiles[0], allowed_disk_combos: '["3f867c4e-5600-4721-880b-391c3752f046"]' }];
    state.scenarioRows = rows;
    state.sourceScenarioRow = [{ name: 'Source', note: null }];
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/clone', { name: 'Clone AL' });
    assert.equal(res.status, 201, res.raw);
    const combo = cloneRow('cap_disk_combos');
    const prof = cloneRow('cap_vm_profiles');
    assert.notEqual(combo.id, '3f867c4e-5600-4721-880b-391c3752f046', 'the local disk combo got a new id');
    assert.deepEqual(
      JSON.parse(prof.allowed_disk_combos), [combo.id],
      'the cloned allow-list points at the NEW combo id, not the source 3f867c4e-5600-4721-880b-391c3752f046',
    );
    assert.equal(PRE_SOURCE_IDS.has(JSON.parse(prof.allowed_disk_combos)[0]), false, 'no source id survives in the allow-list');
  });

  it('admin clone leaves owner_id NULL (shared)', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.scenarioRows = prEScenarioRows();
    state.sourceScenarioRow = [{ name: 'Source', note: null }];
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/clone', { name: 'Shared clone' });
    assert.equal(res.status, 201, res.raw);
    assert.equal(cloneRow('cap_scenarios').owner_id, null);
  });

  it('defaults the clone name to "<source> (copy)" when none is given', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.scenarioRows = prEScenarioRows();
    state.sourceScenarioRow = [{ name: 'North Sea', note: null }];
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/clone', {});
    assert.equal(res.status, 201, res.raw);
    assert.equal(cloneRow('cap_scenarios').name, 'North Sea (copy)');
  });

  it('cloning a missing scenario → 404', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.sourceScenarioRow = []; // source not found
    const res = await request('POST', '/capacity/scenarios/nope/clone', { name: 'x' });
    assert.equal(res.status, 404, res.raw);
    assert.equal(insertsInto('cap_scenarios').length, 0);
  });

  it('a plain user cannot clone (403)', async () => {
    currentUser = { id: '71d6dd0a-d1a0-4028-845a-3aa72fd3a97b', role: 'user' };
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/clone', { name: 'x' });
    assert.equal(res.status, 403, res.raw);
    assert.equal(insertsInto('cap_scenarios').length, 0);
  });
});

describe('PR-E: clone from a frozen version', () => {
  it('reproduces the FROZEN snapshot, not the live working state', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    // Live state has drifted (cpu 999); the version froze cpu 16. The clone must
    // reproduce the frozen 16.
    const live = prEScenarioRows();
    live.vms[0].cpu = 999;
    state.scenarioRows = live;
    const frozen = prEScenarioRows(); // cpu 16
    state.versionRow = [{ id: '1b4d1b85-ca5b-4f82-8137-9ea5b1f5e30d', name: 'V1', note: 'vnote', snapshot: JSON.stringify({ schema_rev: 1, tables: frozen }) }];
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/versions/v1/clone', { name: 'Restored' });
    assert.equal(res.status, 201, res.raw);
    assert.equal(cloneRow('cap_vms').cpu, 16, 'clone reproduces the frozen value, not the live one');

    // Full FK remap holds from the frozen rows too.
    const site = cloneRow('cap_sites');
    const hv = cloneRow('cap_hypervisors');
    const vm = cloneRow('cap_vms');
    const wv = cloneRow('cap_waivers');
    assert.equal(hv.site_id, site.id);
    assert.equal(vm.hypervisor_id, hv.id);
    assert.equal(wv.object_set_key, [hv.id, vm.id].sort().join('|'));
    for (const v of [hv.site_id, vm.hypervisor_id, ...wv.object_set_key.split('|')]) {
      assert.equal(PRE_SOURCE_IDS.has(v), false);
    }
  });

  it('editor clone-from-version stamps the actor as owner', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    state.versionRow = [{ id: '1b4d1b85-ca5b-4f82-8137-9ea5b1f5e30d', name: 'V1', note: null, snapshot: JSON.stringify({ schema_rev: 1, tables: prEScenarioRows() }) }];
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/versions/v1/clone', { name: 'From V1' });
    assert.equal(res.status, 201, res.raw);
    assert.equal(cloneRow('cap_scenarios').owner_id, '4ec54b37-3f24-4759-8c85-dc37030749b6');
  });

  it('cloning a version that does not belong to the scenario → 404', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.versionRow = []; // WHERE id=? AND scenario_id=? finds nothing
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/versions/foreign/clone', { name: 'x' });
    assert.equal(res.status, 404, res.raw);
    assert.equal(insertsInto('cap_scenarios').length, 0);
  });

  it('a plain user cannot clone from a version (403)', async () => {
    currentUser = { id: '71d6dd0a-d1a0-4028-845a-3aa72fd3a97b', role: 'user' };
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/versions/v1/clone', { name: 'x' });
    assert.equal(res.status, 403, res.raw);
  });

  it('the bespoke mount owns the version PUT — the generic factory never sees it', async () => {
    // A frozen column comes back as the bespoke whitelist's 400, not as the
    // generic child factory's column-driven update.
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    const res = await request('PUT', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/versions/v1', { created_by: 'e2d750c1-a8bf-4918-8970-7176a0e55d93' });
    assert.equal(res.status, 400, res.raw);
    assert.match(res.json.error.message, /created_by/);
  });
});

// ── PR-E review round 1: size guard, corrupt-snapshot clone, created_by name ───
describe('PR-E review r1: snapshot size guard + corrupt-snapshot clone', () => {
  it('a snapshot exceeding SNAPSHOT_MAX_BYTES → 400 PAYLOAD_TOO_LARGE, rolled back, no INSERT', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.scenarioOwner = null;
    // One row whose stringified size alone blows past the 4 MB cap.
    state.scenarioRows = {
      sites: [{ id: '373bdfd4-8310-4848-81a3-a6a496982b89', scenario_id: '26895068-65f1-405c-8521-2a9e1212353c', name: 'x', metadata: 'A'.repeat(4 * 1024 * 1024 + 100) }],
    };
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/versions', { name: 'too big' });
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'PAYLOAD_TOO_LARGE');
    assert.equal(insertsInto('cap_versions').length, 0, 'nothing is frozen when the snapshot is over the cap');
  });

  it('cloning a version with a corrupt/unparsable snapshot yields an empty scenario, not a 500', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.versionRow = [{ id: '1b4d1b85-ca5b-4f82-8137-9ea5b1f5e30d', name: 'corrupt', note: null, snapshot: '{ this is not valid json' }];
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/versions/v1/clone', { name: 'salvage' });
    assert.equal(res.status, 201, res.raw);
    // The scenario row is created; no child rows (the snapshot could not be parsed).
    assert.equal(insertsInto('cap_scenarios').length, 1);
    for (const table of ['cap_sites', 'cap_hypervisors', 'cap_vms', 'cap_db_instances', 'cap_waivers']) {
      assert.equal(insertsInto(table).length, 0, `no ${table} rows from an unparsable snapshot`);
    }
  });
});

describe('PR-E review r1: version list resolves created_by → display name', () => {
  it('returns created_by_name (display name, never email) and drops the temporary owner_name field', async () => {
    currentUser = { id: '71d6dd0a-d1a0-4028-845a-3aa72fd3a97b', role: 'user' };
    state.versionListRows = [{ id: '1b4d1b85-ca5b-4f82-8137-9ea5b1f5e30d', scenario_id: '26895068-65f1-405c-8521-2a9e1212353c', name: '1b4d1b85-ca5b-4f82-8137-9ea5b1f5e30d', note: null, created_at: 't', created_by: '4ec54b37-3f24-4759-8c85-dc37030749b6' }];
    state.userNames = { '4ec54b37-3f24-4759-8c85-dc37030749b6': 'Editor One' };
    const res = await request('GET', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/versions');
    assert.equal(res.status, 200, res.raw);
    assert.equal(res.json.data[0].created_by_name, 'Editor One');
    assert.equal(Object.prototype.hasOwnProperty.call(res.json.data[0], 'owner_name'), false, 'the enrichment helper output is renamed to created_by_name');
    // The enrichment probe never selects an email column.
    const probe = state.queries.find((q) => /FROM `fmb_users` WHERE id IN/.test(q.sql));
    assert.ok(probe, 'a display-name probe ran');
    assert.equal(/email/i.test(probe.sql), false, 'the name probe must not read email');
  });

  it('a NULL created_by yields created_by_name = null (the FE renders "System")', async () => {
    currentUser = { id: '71d6dd0a-d1a0-4028-845a-3aa72fd3a97b', role: 'user' };
    state.versionListRows = [{ id: '1b4d1b85-ca5b-4f82-8137-9ea5b1f5e30d', scenario_id: '26895068-65f1-405c-8521-2a9e1212353c', name: '1b4d1b85-ca5b-4f82-8137-9ea5b1f5e30d', note: null, created_at: 't', created_by: null }];
    const res = await request('GET', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/versions');
    assert.equal(res.status, 200, res.raw);
    assert.equal(res.json.data[0].created_by_name, null);
  });
});

// ── PR-F T1b: global config export (template layer) ────────────────────────────
describe('PR-F: global config export', () => {
  it('returns a snapshot-shaped doc of the global catalogue layer (all authenticated)', async () => {
    currentUser = { id: '71d6dd0a-d1a0-4028-845a-3aa72fd3a97b', role: 'user' };
    state.templateRows = {
      cap_hardware_specs: [{ id: '0e06856e-f316-4505-8a20-d5cbdc42bd73', scenario_id: null, name: 'Spec-A' }],
      cap_disk_combos: [{ id: 'a3fe8617-ef98-49ca-8a07-5626f88e6d19', scenario_id: null, name: 'OS only' }],
      cap_teams: [{ id: 'e35af9b5-2496-4f34-82da-ea2b2aa90164', scenario_id: null, name: 'erp' }],
      cap_vm_profiles: [{ id: 'ab8def85-ef9d-4f58-8196-43ded162dd74', scenario_id: null, class: 'DB', name: 'DB-16C' }],
      cap_field_defs: [{ id: 'b630a50b-4ef8-45c6-80b9-3eca727bd015', scenario_id: null, entity_type: 'vm', field_key: 'zone', data_type: 'text' }],
      cap_settings: [{ id: '14a01496-1cab-42e8-8418-3fea5ce497d7', scenario_id: null, mem_cpu_ratio: 20 }],
      cap_rules: [{ id: '110095e1-0ac0-43a2-8777-9449936efcdd', scenario_id: null, type: 'keep-apart', name: 'Keep apart' }],
    };
    const res = await request('GET', '/capacity/config/export');
    assert.equal(res.status, 200, res.raw);
    assert.equal(res.json.data.schema_rev, 1);
    // The global catalogue layer, in readConfigTemplateTables order (R5 added the
    // bundles + bundle_items config templates, §17.4 config export).
    assert.deepEqual(Object.keys(res.json.data.tables), ['hardware_specs', 'disk_combos', 'teams', 'vm_profiles', 'field_defs', 'settings', 'rules', 'bundles', 'bundle_items']);
    // No scenario-scoped placement tables leak in (they have no global layer).
    for (const leak of ['sites', 'hypervisors', 'databases', 'vms', 'db_instances', 'waivers']) {
      assert.equal(Object.prototype.hasOwnProperty.call(res.json.data.tables, leak), false, `${leak} must not appear`);
    }
    assert.equal(res.json.data.tables.settings[0].id, '14a01496-1cab-42e8-8418-3fea5ce497d7', 'the global settings singleton is included');
    assert.equal(res.json.data.tables.rules[0].name, 'Keep apart');
    // Every read constrained the template scope (scenario_id IS NULL) — no
    // scenario-scoped read ran during the export.
    const scoped = state.queries.filter((q) => /WHERE scenario_id = \?/.test(q.sql));
    assert.equal(scoped.length, 0, 'a config export never reads a scenario-scoped row');
  });

  it('is unauthenticated-gated (401)', async () => {
    currentUser = undefined;
    const res = await request('GET', '/capacity/config/export');
    assert.equal(res.status, 401, res.raw);
  });

  // Codex r2 P1: a settings row persisted before the kvm_host_primary/standby
  // split still carries the legacy 3-key { hypervisor, kvm_host, ap_vm } shape.
  // Export is a READ and must go through the SAME hydration choke point every
  // other reader uses, or the app rejects its own freshly-exported document on
  // re-import (the exact-4-key guard).
  it('hydrates a stored legacy 3-key name_patterns override to the 4-key split shape', async () => {
    currentUser = { id: '71d6dd0a-d1a0-4028-845a-3aa72fd3a97b', role: 'user' };
    state.templateRows = {
      cap_settings: [{
        id: '14a01496-1cab-42e8-8418-3fea5ce497d7',
        scenario_id: null,
        mem_cpu_ratio: 20,
        name_patterns: { hypervisor: 'hv-{dc}-{seq:2}', kvm_host: 'kvm-{dc}-{seq:2}', ap_vm: 'ap-{seq:2}' },
      }],
    };
    const res = await request('GET', '/capacity/config/export');
    assert.equal(res.status, 200, res.raw);
    const exported = res.json.data.tables.settings[0].name_patterns;
    assert.deepEqual(Object.keys(exported).sort(), ['ap_vm', 'hypervisor', 'kvm_host_primary', 'kvm_host_standby']);
    assert.equal(exported.kvm_host_primary, 'kvm-{dc}-{seq:2}');
    assert.equal(exported.kvm_host_standby, 'kvm-{dc}-{seq:2}');
    // Round-trip: the exported doc must pass the SAME guard config IMPORT applies.
    assert.equal(validateNamePatternsWrite(exported), null, 'the hydrated export must pass validateNamePatternsWrite');
  });

  // An untouched global settings row (no override) stays null — hydration fills
  // a LEGACY STORED override, it never manufactures one for a row that inherits
  // the built-ins.
  it('leaves an untouched (null) name_patterns as null, not a manufactured default set', async () => {
    currentUser = { id: '71d6dd0a-d1a0-4028-845a-3aa72fd3a97b', role: 'user' };
    state.templateRows = {
      cap_settings: [{ id: '14a01496-1cab-42e8-8418-3fea5ce497d7', scenario_id: null, mem_cpu_ratio: 20, name_patterns: null }],
    };
    const res = await request('GET', '/capacity/config/export');
    assert.equal(res.status, 200, res.raw);
    assert.equal(res.json.data.tables.settings[0].name_patterns, null);
  });
});

// ── fmb-1686: name_patterns read-surface hydration, closed at the dto-mapper
// choke point (mapRowFromDb's cap_settings.jsonHydrate). Surfaces 1-4 here;
// surface 5 (scenario export snapshot) is covered in capacity-io.test.js,
// since it shares that file's mock harness (state.scenarioRows).
describe('fmb-1686: name_patterns read-surface hydration (config.js + settings.js)', () => {
  const legacy3Key = { hypervisor: 'hv-{dc}-{seq:2}', kvm_host: 'kvm-{dc}-{seq:2}', ap_vm: 'ap-{seq:2}' };
  const assertHydrated4Key = (patterns) => {
    assert.deepEqual(Object.keys(patterns).sort(), ['ap_vm', 'hypervisor', 'kvm_host_primary', 'kvm_host_standby']);
    assert.equal(patterns.kvm_host_primary, 'kvm-{dc}-{seq:2}');
    assert.equal(patterns.kvm_host_standby, 'kvm-{dc}-{seq:2}');
  };

  it('surface 1 — GET /config/settings hydrates a stored legacy 3-key row to 4-key', async () => {
    currentUser = { id: '71d6dd0a-d1a0-4028-845a-3aa72fd3a97b', role: 'user' };
    state.templateRows = {
      cap_settings: [{ id: '14a01496-1cab-42e8-8418-3fea5ce497d7', scenario_id: null, mem_cpu_ratio: 20, name_patterns: legacy3Key }],
    };
    const res = await request('GET', '/capacity/config/settings');
    assert.equal(res.status, 200, res.raw);
    assertHydrated4Key(res.json.data[0].name_patterns);
  });

  it('surface 2 — GET /config/settings/:id hydrates a stored legacy 3-key row to 4-key', async () => {
    currentUser = { id: '71d6dd0a-d1a0-4028-845a-3aa72fd3a97b', role: 'user' };
    state.templateRows = {
      cap_settings: [{ id: '14a01496-1cab-42e8-8418-3fea5ce497d7', scenario_id: null, mem_cpu_ratio: 20, name_patterns: legacy3Key }],
    };
    const res = await request('GET', '/capacity/config/settings/14a01496-1cab-42e8-8418-3fea5ce497d7');
    assert.equal(res.status, 200, res.raw);
    assertHydrated4Key(res.json.data.name_patterns);
  });

  it('surface 3 — GET /scenarios/:id/settings hydrates a stored legacy 3-key override row to 4-key', async () => {
    currentUser = { id: '71d6dd0a-d1a0-4028-845a-3aa72fd3a97b', role: 'user' };
    state.settingsExists = true;
    state.settingsRowNamePatterns = legacy3Key;
    const res = await request('GET', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/settings');
    assert.equal(res.status, 200, res.raw);
    assertHydrated4Key(res.json.data.name_patterns);
  });

  it('surface 4 — PUT /scenarios/:id/settings response echo hydrates a legacy 3-key row untouched by the write', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    state.scenarioOwner = '4ec54b37-3f24-4759-8c85-dc37030749b6';
    state.settingsExists = true;
    state.settingsRowNamePatterns = legacy3Key;
    // Updates an UNRELATED field — the PUT never touches name_patterns itself,
    // so the post-write confirm read re-reads the row's STORED legacy value.
    const res = await request('PUT', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/settings', { mem_cpu_ratio: 25 });
    assert.equal(res.status, 200, res.raw);
    assertHydrated4Key(res.json.data.name_patterns);
  });

  it('round-trip: GET /config/settings → PUT the SAME hydrated body → 200 (never rejects its own read)', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.templateRows = {
      cap_settings: [{ id: '14a01496-1cab-42e8-8418-3fea5ce497d7', scenario_id: null, mem_cpu_ratio: 20, name_patterns: legacy3Key }],
    };
    const getRes = await request('GET', '/capacity/config/settings/14a01496-1cab-42e8-8418-3fea5ce497d7');
    assert.equal(getRes.status, 200, getRes.raw);
    const putRes = await request('PUT', '/capacity/config/settings/14a01496-1cab-42e8-8418-3fea5ce497d7', {
      name_patterns: getRes.json.data.name_patterns,
    });
    assert.equal(putRes.status, 200, putRes.raw, 'a GET→PUT round-trip of the hydrated 4-key shape must never 400');
  });

  it('round-trip: GET /scenarios/:id/settings → PUT the SAME hydrated body → 200', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    state.scenarioOwner = '4ec54b37-3f24-4759-8c85-dc37030749b6';
    state.settingsExists = true;
    state.settingsRowNamePatterns = legacy3Key;
    const getRes = await request('GET', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/settings');
    assert.equal(getRes.status, 200, getRes.raw);
    const putRes = await request('PUT', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/settings', {
      name_patterns: getRes.json.data.name_patterns,
    });
    assert.equal(putRes.status, 200, putRes.raw, 'a GET→PUT round-trip of the hydrated 4-key shape must never 400');
  });

  it('an already-4-key stored row passes through unchanged on every surface (idempotent)', async () => {
    currentUser = { id: '71d6dd0a-d1a0-4028-845a-3aa72fd3a97b', role: 'user' };
    const already4Key = {
      hypervisor: 'hv-{seq:2}', kvm_host_primary: 'kp-{seq:2}', kvm_host_standby: 'ks-{seq:2}', ap_vm: 'ap-{seq:2}',
    };
    state.settingsExists = true;
    state.settingsRowNamePatterns = already4Key;
    const res = await request('GET', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/settings');
    assert.equal(res.status, 200, res.raw);
    assert.deepEqual(res.json.data.name_patterns, already4Key);
  });

  it('an untouched (null) name_patterns stays null on the scenario settings GET — hydration never manufactures a default set', async () => {
    currentUser = { id: '71d6dd0a-d1a0-4028-845a-3aa72fd3a97b', role: 'user' };
    state.settingsExists = true;
    state.settingsRowNamePatterns = null;
    const res = await request('GET', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/settings');
    assert.equal(res.status, 200, res.raw);
    assert.equal(res.json.data.name_patterns, null);
  });
});

// ── R1.13 Fix 1: clone-from-version never reifies the frozen GLOBAL layer ───────
// A frozen snapshot carries the global rule template + global settings + the
// referenced global catalogue closure (so a version read/export is self-contained).
// A clone reconstitutes ONLY the scenario-local layer and re-references the LIVE
// global layer — the global rows must not become scenario-local copies (that would
// double-apply every global rule and duplicate the catalogue).
describe('R1.13 Fix 1: clone-from-version skips the global layer, keeps live refs', () => {
  it('clones scenario-local rows only; global rules/settings/specs are not reborn as local', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    const frozen = {
      rules: [
        { id: '4c783980-753a-468b-806d-05ecf93ed92d', scenario_id: '26895068-65f1-405c-8521-2a9e1212353c', type: 'keep-apart', name: 'L', level: 'db_instance', group_by: 'each_database', overrides_rule_id: null, custom_group_id: null },
        { id: 'b63948dd-3a90-4d51-8f17-4f943ad201ba', scenario_id: null, type: 'no-oversell', name: 'G', level: 'hypervisor', group_by: 'all_of_type', overrides_rule_id: null, custom_group_id: null },
      ],
      settings: [
        { id: 'b267a6c0-36c3-4d82-8f2f-b87621d0aa93', scenario_id: null, mem_cpu_ratio: 20 },
      ],
      hardware_specs: [
        { id: 'fb9ff0c9-7c07-4ec9-88b1-a643033e81de', scenario_id: null, name: 'G-Spec' }, // a closure-pulled global catalogue row
      ],
      sites: [
        { id: '85c2ea0f-cabd-43a8-8b49-f289754d1bf0', scenario_id: '26895068-65f1-405c-8521-2a9e1212353c', name: 'S', topology: 'site', metadata: null },
      ],
      hypervisors: [
        { id: '51b03d13-a24a-45fb-8474-8f844d98445a', scenario_id: '26895068-65f1-405c-8521-2a9e1212353c', site_id: '85c2ea0f-cabd-43a8-8b49-f289754d1bf0', spec_id: 'fb9ff0c9-7c07-4ec9-88b1-a643033e81de', name: 'HV', metadata: null },
      ],
    };
    state.versionRow = [{ id: '1b4d1b85-ca5b-4f82-8137-9ea5b1f5e30d', name: 'V1', note: null, snapshot: JSON.stringify({ schema_rev: 1, tables: frozen }) }];
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/versions/v1/clone', { name: 'Restored' });
    assert.equal(res.status, 201, res.raw);

    const newScenarioId = cloneRow('cap_scenarios').id;

    // Global-layer rows are NOT reborn as scenario-local rows.
    assert.equal(insertsInto('cap_settings').length, 0, 'the global settings row is not cloned');
    assert.equal(insertsInto('cap_hardware_specs').length, 0, 'the global catalogue spec is not cloned');
    const ruleInserts = insertsInto('cap_rules');
    assert.equal(ruleInserts.length, 1, 'only the scenario-local rule is cloned, not the global template rule');

    // The one cloned rule is the local one (new id, new scenario), never the global.
    const rule = cloneRow('cap_rules');
    assert.equal(rule.scenario_id, newScenarioId);
    assert.equal(PRE_SOURCE_IDS.has(rule.id), false);
    assert.notEqual(rule.id, 'b63948dd-3a90-4d51-8f17-4f943ad201ba');

    // A scenario-local FK pointing at a SKIPPED global row keeps the LIVE global id
    // (idMap fallback); a FK pointing at a cloned LOCAL row is remapped to its new id.
    const site = cloneRow('cap_sites');
    const hv = cloneRow('cap_hypervisors');
    assert.equal(hv.spec_id, 'fb9ff0c9-7c07-4ec9-88b1-a643033e81de', 'FK to a live global spec is preserved, not remapped');
    assert.equal(hv.site_id, site.id, 'FK to a cloned local site is remapped to its new id');
    assert.notEqual(site.id, '85c2ea0f-cabd-43a8-8b49-f289754d1bf0');
  });
});

// ── R1.13 Fix 2: rule PUT re-validates the MERGED level/group_by ────────────────
describe('R1.13 Fix 2: partial rule PUT is validated against its merged type', () => {
  it('scenario rule PUT: a { level } change illegal for the STORED type → 400 INVALID_LEVEL, no update', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.rowScenario = '26895068-65f1-405c-8521-2a9e1212353c';
    state.ruleExisting = { type: 'no-oversell', level: 'hypervisor', group_by: 'all_of_type' };
    const res = await request('PUT', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/rules/90eb8cf2-928b-4835-8608-d2857bb3cfd6', { level: 'db_instance' });
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'INVALID_LEVEL');
    assert.equal(hasQuery(/^UPDATE `fmb_cap_rules`/), false, 'an illegal merged state never reaches the UPDATE');
  });

  it('scenario rule PUT: a { level } change legal for the stored type proceeds (200)', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.rowScenario = '26895068-65f1-405c-8521-2a9e1212353c';
    state.ruleExisting = { type: 'max-instances-per-vm', level: 'vm', group_by: 'all_of_type' };
    const res = await request('PUT', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/rules/90eb8cf2-928b-4835-8608-d2857bb3cfd6', { level: 'vm' });
    assert.equal(res.status, 200, res.raw);
  });

  it('config rule PUT: a { group_by } change illegal for the STORED type → 400 INVALID_GROUP_BY', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.ruleExisting = { type: 'no-oversell', level: 'hypervisor', group_by: 'all_of_type' };
    const res = await request('PUT', '/capacity/config/rules/r1', { group_by: 'each_database' });
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'INVALID_GROUP_BY');
    assert.equal(hasQuery(/^UPDATE `fmb_cap_rules`/), false);
  });
});

// ── R1.13 Fix 3: custom_group_members exactly-one-member XOR ────────────────────
describe('R1.13 Fix 3: custom group member references exactly one entity', () => {
  it('POST with BOTH member ids → 400 INVALID_MEMBER', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.scenarioExists = true;
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/custom_group_members', {
      group_id: '51f5ff48-8456-4553-802b-d92d7dd1cd4f', member_vm_id: 'd8de67d9-c84d-4e73-8817-13b2f11c02f7', member_instance_id: '54e9efcd-df46-407b-8eaf-824d49e5a4a1',
    });
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'INVALID_MEMBER');
    assert.equal(insertsInto('cap_custom_group_members').length, 0);
  });

  it('POST with NEITHER member id → 400 INVALID_MEMBER', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.scenarioExists = true;
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/custom_group_members', { group_id: '51f5ff48-8456-4553-802b-d92d7dd1cd4f' });
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'INVALID_MEMBER');
  });

  it('POST with exactly one member id proceeds to the insert', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.scenarioExists = true;
    state.fkExists = true;
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/custom_group_members', { group_id: '51f5ff48-8456-4553-802b-d92d7dd1cd4f', member_vm_id: 'd8de67d9-c84d-4e73-8817-13b2f11c02f7' });
    assert.notEqual(res.json && res.json.error && res.json.error.code, 'INVALID_MEMBER');
    assert.equal(insertsInto('cap_custom_group_members').length, 1, 'a valid single-member row reaches the factory insert');
  });

  it('PUT adding a second member kind to a row that already has one → 400 INVALID_MEMBER', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.rowScenario = '26895068-65f1-405c-8521-2a9e1212353c';
    state.memberExisting = { member_vm_id: null, member_instance_id: '54e9efcd-df46-407b-8eaf-824d49e5a4a1' };
    const res = await request('PUT', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/custom_group_members/2214961c-ff4c-492a-8420-dc3464b348cf', { member_vm_id: 'd8de67d9-c84d-4e73-8817-13b2f11c02f7' });
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'INVALID_MEMBER');
    assert.equal(hasQuery(/^UPDATE `fmb_cap_custom_group_members`/), false);
  });

  it('PUT clearing the only member (→ neither) → 400 INVALID_MEMBER', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.rowScenario = '26895068-65f1-405c-8521-2a9e1212353c';
    state.memberExisting = { member_vm_id: 'd8de67d9-c84d-4e73-8817-13b2f11c02f7', member_instance_id: null };
    const res = await request('PUT', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/custom_group_members/2214961c-ff4c-492a-8420-dc3464b348cf', { member_vm_id: null });
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'INVALID_MEMBER');
  });

  it('PUT swapping to the other member kind (set one, clear the other) is accepted', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.rowScenario = '26895068-65f1-405c-8521-2a9e1212353c';
    state.fkExists = true;
    state.memberExisting = { member_vm_id: null, member_instance_id: '54e9efcd-df46-407b-8eaf-824d49e5a4a1' };
    const res = await request('PUT', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/custom_group_members/2214961c-ff4c-492a-8420-dc3464b348cf', { member_vm_id: 'd8de67d9-c84d-4e73-8817-13b2f11c02f7', member_instance_id: null });
    assert.equal(res.status, 200, res.raw);
  });

  it('PUT touching neither member column short-circuits (no member-row read, no rejection)', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.rowScenario = '26895068-65f1-405c-8521-2a9e1212353c';
    state.fkExists = true;
    const res = await request('PUT', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/custom_group_members/2214961c-ff4c-492a-8420-dc3464b348cf', { group_id: 'eade9429-fb0b-45cf-8f35-1f9763dd717e' });
    assert.equal(res.status, 200, res.raw);
    assert.equal(hasQuery(/SELECT member_vm_id, member_instance_id FROM `fmb_cap_custom_group_members`/), false, 'the XOR guard does not read the row when neither member column is touched');
  });
});

// ── R2: bundles (global config templates, §7) ──────────────────────────────────
describe('R2 bundles: CRUD + role gating', () => {
  it('GET /config/bundles lists bundles with nested items (all authenticated)', async () => {
    currentUser = { id: '71d6dd0a-d1a0-4028-845a-3aa72fd3a97b', role: 'user' };
    state.bundleRows = [{ id: 'b1', serial: 1, name: 'Core Stack' }];
    state.bundleItemRows = [
      { id: '3fd934e6-73f2-4b9b-873b-4999f3b2b797', bundle_id: 'b1', type: 'DB', qty: 1, function_name: 'erp' },
      { id: '8b91b47e-24d4-44d6-8ea0-48a11ee28671', bundle_id: 'b1', type: 'AP', qty: 2, function_name: 'erp-ap' },
    ];
    const res = await request('GET', '/capacity/config/bundles');
    assert.equal(res.status, 200, res.raw);
    assert.equal(res.json.data.length, 1);
    assert.equal(res.json.data[0].items.length, 2, 'items are nested under their bundle');
  });

  it('editor may create a bundle; serial auto-assigns when omitted', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    state.nextSerial = 7;
    const res = await request('POST', '/capacity/config/bundles', { name: 'New Bundle' });
    assert.equal(res.status, 201, res.raw);
    const ins = insertsInto('cap_bundles');
    assert.equal(ins.length, 1);
    const row = colsOf(ins[0]);
    assert.equal(row.serial, 7, 'serial is server-assigned to COALESCE(MAX)+1 when omitted');
    assert.equal(row.name, 'New Bundle');
  });

  it('auto-serial is allocated under a row lock (FOR UPDATE) to avoid a concurrent-POST collision', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    state.nextSerial = 4;
    const res = await request('POST', '/capacity/config/bundles', { name: 'B' });
    assert.equal(res.status, 201, res.raw);
    assert.ok(
      hasQuery(/SELECT COALESCE\(MAX\(serial\), 0\) \+ 1 AS next FROM `fmb_cap_bundles` FOR UPDATE/),
      'the MAX(serial) allocation probe locks FOR UPDATE',
    );
  });

  it('a client-supplied serial is honored (no auto-assign query)', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    const res = await request('POST', '/capacity/config/bundles', { name: 'B', serial: 3 });
    assert.equal(res.status, 201, res.raw);
    assert.equal(colsOf(insertsInto('cap_bundles')[0]).serial, 3);
    assert.equal(hasQuery(/COALESCE\(MAX\(serial\)/), false, 'no MAX(serial) probe when the client sets serial');
  });

  it('a bundle create with no name → 400', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    const res = await request('POST', '/capacity/config/bundles', {});
    assert.equal(res.status, 400, res.raw);
    assert.equal(insertsInto('cap_bundles').length, 0);
  });

  it('a bundle create with a non-numeric serial → 400 (no insert)', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    const res = await request('POST', '/capacity/config/bundles', { name: 'B', serial: 'oops' });
    assert.equal(res.status, 400, res.raw);
    assert.match(res.json.error.message, /serial/);
    assert.equal(insertsInto('cap_bundles').length, 0);
  });

  it('a bundle PUT cannot blank the name (whitespace-only → 400, no update)', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    const res = await request('PUT', '/capacity/config/bundles/b1', { name: '   ' });
    assert.equal(res.status, 400, res.raw);
    assert.equal(hasQuery(/^UPDATE `fmb_cap_bundles`/), false);
  });

  it('a bundle PUT trims the stored name (parity with create)', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.updateAffected = 1;
    const res = await request('PUT', '/capacity/config/bundles/b1', { name: '  Renamed  ' });
    assert.equal(res.status, 200, res.raw);
    const upd = state.queries.find((q) => /^UPDATE `fmb_cap_bundles`/.test(q.sql));
    assert.ok(upd && upd.params.includes('Renamed'), 'the trimmed name is written');
  });

  it('a plain user may not create a bundle (403)', async () => {
    currentUser = { id: '71d6dd0a-d1a0-4028-845a-3aa72fd3a97b', role: 'user' };
    const res = await request('POST', '/capacity/config/bundles', { name: 'B' });
    assert.equal(res.status, 403, res.raw);
    assert.equal(insertsInto('cap_bundles').length, 0);
  });

  it('DELETE /config/bundles/:id cascades its items before the bundle', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.bundleExists = true;
    const res = await request('DELETE', '/capacity/config/bundles/b1');
    assert.equal(res.status, 200, res.raw);
    const idxItems = state.queries.findIndex((q) => /^DELETE FROM `fmb_cap_bundle_items` WHERE bundle_id = \?/.test(q.sql));
    const idxBundle = state.queries.findIndex((q) => /^DELETE FROM `fmb_cap_bundles` WHERE id = \?/.test(q.sql));
    assert.ok(idxItems !== -1 && idxBundle !== -1);
    assert.ok(idxItems < idxBundle, 'items are deleted before the bundle');
  });

  it('DELETE of a missing bundle → 404', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.bundleExists = false;
    const res = await request('DELETE', '/capacity/config/bundles/nope');
    assert.equal(res.status, 404, res.raw);
    assert.equal(hasQuery(/^DELETE FROM `fmb_cap_bundles`/), false);
  });
});

describe('R2 bundle items: §17.1a global-only FK validation', () => {
  it('an item referencing a GLOBAL profile is accepted', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.bundleExists = true;
    state.fkExists = true;
    state.fkScenarioId = null; // the referenced profile is a global row
    const res = await request('POST', '/capacity/config/bundles/b1/items', {
      type: 'DB', qty: 1, function_name: 'erp', profile_id: 'c094f2cf-5af2-467f-8f08-b5f68839abb3',
    });
    assert.equal(res.status, 201, res.raw);
    assert.equal(insertsInto('cap_bundle_items').length, 1);
  });

  it('an item referencing a SCENARIO-LOCAL profile is rejected 400 (a bundle is global)', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.bundleExists = true;
    state.fkExists = true;
    state.fkScenarioId = '26895068-65f1-405c-8521-2a9e1212353c'; // a scenario-local profile
    const res = await request('POST', '/capacity/config/bundles/b1/items', {
      type: 'DB', qty: 1, profile_id: '0b623a1c-9029-4bc1-88ff-2722ccb94200',
    });
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'INVALID_REFERENCE');
    assert.match(res.json.error.message, /profile_id/);
    assert.equal(insertsInto('cap_bundle_items').length, 0);
  });

  it('an item POST under a missing bundle → 404', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.bundleExists = false;
    const res = await request('POST', '/capacity/config/bundles/nope/items', { type: 'AP', qty: 1 });
    assert.equal(res.status, 404, res.raw);
    assert.equal(insertsInto('cap_bundle_items').length, 0);
  });

  it('the §17.1a FK probe locks the referenced catalogue row FOR UPDATE (no dangling-ref race)', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.bundleExists = true;
    state.fkExists = true;
    state.fkScenarioId = null; // global profile
    state.profileClass = 'DB';
    const res = await request('POST', '/capacity/config/bundles/b1/items', { type: 'DB', qty: 1, profile_id: '891d16b0-b217-4ec0-8a88-78a40c895623' });
    assert.equal(res.status, 201, res.raw);
    assert.ok(
      hasQuery(/SELECT id, scenario_id,[\s\S]*FROM `fmb_cap_vm_profiles` WHERE id = \? FOR UPDATE/),
      'the referenced profile row is locked before the item is admitted',
    );
  });

  it('a DB item referencing an AP-class profile is rejected 400 (POST)', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.bundleExists = true;
    state.fkExists = true;
    state.fkScenarioId = null; // a valid GLOBAL profile…
    state.profileClass = 'AP'; // …but it is an AP profile
    const res = await request('POST', '/capacity/config/bundles/b1/items', { type: 'DB', qty: 1, profile_id: 'efe1550f-eafc-47a4-8ccb-235465c4ac39' });
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'INVALID_REFERENCE');
    assert.match(res.json.error.message, /class/);
    assert.equal(insertsInto('cap_bundle_items').length, 0);
  });

  it('a PUT flipping type to AP while the stored profile stays a DB profile → 400 (merged-class check)', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.bundleItemExists = true;
    state.bundleItemType = 'DB';         // stored type
    state.bundleItemProfileId = 'p-db';  // stored profile (unchanged by this PUT)
    state.profileClass = 'DB';           // it is a DB profile
    const res = await request('PUT', '/capacity/config/bundles/b1/items/i-1', { type: 'AP' });
    assert.equal(res.status, 400, res.raw);
    assert.match(res.json.error.message, /class/);
    assert.equal(hasQuery(/^UPDATE `fmb_cap_bundle_items`/), false, 'no update on a class mismatch');
  });

  it('a PUT changing only qty skips the class check (type/profile untouched)', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.bundleItemExists = true;
    state.bundleItemType = 'DB';
    state.bundleItemProfileId = 'p-db';
    state.updateAffected = 1;
    const res = await request('PUT', '/capacity/config/bundles/b1/items/i-1', { qty: 9 });
    assert.equal(res.status, 200, res.raw);
    assert.equal(hasQuery(/SELECT class FROM `fmb_cap_vm_profiles`/), false, 'no class probe when neither type nor profile_id changes');
  });

  it('an item with a non-canonical type → 400', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.bundleExists = true;
    const res = await request('POST', '/capacity/config/bundles/b1/items', { type: 'db', qty: 1 });
    assert.equal(res.status, 400, res.raw);
    assert.equal(insertsInto('cap_bundle_items').length, 0);
  });

  it('an item with node_count below the RAC minimum → 400 (candidates 514 #4 server mirror)', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.bundleExists = true;
    const res = await request('POST', '/capacity/config/bundles/b1/items', { type: 'DB', qty: 1, topology: 'rac', node_count: 1 });
    assert.equal(res.status, 400, res.raw);
    assert.match(res.json.error.message, /node_count/);
    assert.equal(insertsInto('cap_bundle_items').length, 0);
  });

  it('an item with node_count null (non-RAC topology) is accepted', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.bundleExists = true;
    const res = await request('POST', '/capacity/config/bundles/b1/items', { type: 'DB', qty: 1, function_name: 'erp', topology: 'primary', node_count: null });
    assert.equal(res.status, 201, res.raw);
    assert.equal(insertsInto('cap_bundle_items').length, 1);
  });

  it('an item with node_count above the RAC cap → 400', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.bundleExists = true;
    const res = await request('POST', '/capacity/config/bundles/b1/items', { type: 'DB', qty: 1, topology: 'rac', node_count: 999 });
    assert.equal(res.status, 400, res.raw);
    assert.match(res.json.error.message, /node_count/);
    assert.equal(insertsInto('cap_bundle_items').length, 0);
  });

  it('a non-null node_count on a non-RAC topology → 400', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.bundleExists = true;
    const res = await request('POST', '/capacity/config/bundles/b1/items', { type: 'DB', qty: 1, topology: 'primary', node_count: 3 });
    assert.equal(res.status, 400, res.raw);
    assert.match(res.json.error.message, /RAC/);
    assert.equal(insertsInto('cap_bundle_items').length, 0);
  });

  it('a RAC item POST without node_count → 400 (effective row check)', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.bundleExists = true;
    const res = await request('POST', '/capacity/config/bundles/b1/items', { type: 'DB', qty: 1, function_name: 'erp', topology: 'rac' });
    assert.equal(res.status, 400, res.raw);
    assert.match(res.json.error.message, /node_count/);
    assert.equal(insertsInto('cap_bundle_items').length, 0);
  });

  it('a PUT flipping topology RAC→primary while a node_count stays stored → 400 (merged coupling)', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.bundleItemExists = true;
    state.bundleItemTopology = 'rac';   // stored
    state.bundleItemNodeCount = 4;      // stored
    const res = await request('PUT', '/capacity/config/bundles/b1/items/i-1', { topology: 'primary' });
    assert.equal(res.status, 400, res.raw);
    assert.match(res.json.error.message, /RAC/);
    assert.equal(hasQuery(/^UPDATE `fmb_cap_bundle_items`/), false, 'no update when the merged row is inconsistent');
  });

  it('a PUT clearing node_count when flipping RAC→primary is accepted', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.bundleItemExists = true;
    state.bundleItemTopology = 'rac';
    state.bundleItemNodeCount = 4;
    state.updateAffected = 1;
    const res = await request('PUT', '/capacity/config/bundles/b1/items/i-1', { topology: 'primary', node_count: null });
    assert.equal(res.status, 200, res.raw);
  });

  it('a bundle-item PUT to a row not in the URL bundle → 404', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.bundleItemExists = false;
    const res = await request('PUT', '/capacity/config/bundles/b1/items/i-foreign', { qty: 5 });
    assert.equal(res.status, 404, res.raw);
    assert.equal(hasQuery(/^UPDATE `fmb_cap_bundle_items`/), false);
  });

  // Phase-2 A4: bundle-item SGA defaults (DB-only, nullable).
  it('a DB item POST persists primary_sga_gb / standby_sga_gb', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.bundleExists = true;
    const res = await request('POST', '/capacity/config/bundles/b1/items', {
      type: 'DB', qty: 1, topology: 'primary_standby', primary_sga_gb: 96, standby_sga_gb: 48,
    });
    assert.equal(res.status, 201, res.raw);
    const ins = insertsInto('cap_bundle_items');
    assert.equal(ins.length, 1);
    assert.match(ins[0].sql, /primary_sga_gb/);
    assert.match(ins[0].sql, /standby_sga_gb/);
    assert.ok(ins[0].params.includes(96) && ins[0].params.includes(48));
  });

  it('an AP item carrying an SGA value → 400 (SGA is DB-only)', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.bundleExists = true;
    const res = await request('POST', '/capacity/config/bundles/b1/items', { type: 'AP', qty: 2, primary_sga_gb: 32 });
    assert.equal(res.status, 400, res.raw);
    assert.match(res.json.error.message, /DB items only/);
    assert.equal(insertsInto('cap_bundle_items').length, 0);
  });

  it('a negative bundle-item SGA → 400 (shape guard)', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.bundleExists = true;
    const res = await request('POST', '/capacity/config/bundles/b1/items', { type: 'DB', qty: 1, standby_sga_gb: -8 });
    assert.equal(res.status, 400, res.raw);
    assert.match(res.json.error.message, /standby_sga_gb/);
    assert.equal(insertsInto('cap_bundle_items').length, 0);
  });

  it('a PUT setting an SGA value on a stored-AP item → 400 (merged type is AP)', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.bundleItemExists = true;
    state.bundleItemType = 'AP'; // stored type, unchanged by this PUT
    const res = await request('PUT', '/capacity/config/bundles/b1/items/i-1', { primary_sga_gb: 16 });
    assert.equal(res.status, 400, res.raw);
    assert.match(res.json.error.message, /DB items only/);
    assert.equal(hasQuery(/^UPDATE `fmb_cap_bundle_items`/), false);
  });

  it('P2-4: a PUT flipping a DB item with STORED SGA to AP (without clearing it) → 400 (merged effective)', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.bundleItemExists = true;
    state.bundleItemType = 'DB';        // stored type
    state.bundleItemPrimarySga = 96;    // stored SGA the PUT does not resend
    const res = await request('PUT', '/capacity/config/bundles/b1/items/i-1', { type: 'AP' });
    assert.equal(res.status, 400, res.raw);
    assert.match(res.json.error.message, /DB items only/);
    assert.equal(hasQuery(/^UPDATE `fmb_cap_bundle_items`/), false);
  });

  it('P2-4: a PUT flipping to AP while ALSO clearing both SGA fields succeeds', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.bundleItemExists = true;
    state.bundleItemType = 'DB';
    state.bundleItemPrimarySga = 96;
    state.bundleItemStandbySga = 48;
    const res = await request('PUT', '/capacity/config/bundles/b1/items/i-1', { type: 'AP', primary_sga_gb: null, standby_sga_gb: null });
    assert.equal(res.status, 200, res.raw);
    assert.equal(hasQuery(/^UPDATE `fmb_cap_bundle_items`/), true);
  });
});

// ── Phase-2 A2: gated first-instance config import ─────────────────────────────
describe('phase-2 A2: config import validate/commit gate', () => {
  const payload = (over = {}) => ({
    schema_rev: 1,
    tables: { teams: [{ ref: 't-1', name: 'Payments', color: '#36f' }] },
    ...over,
  });

  it('plain user may not validate the config import (403)', async () => {
    currentUser = { id: '71d6dd0a-d1a0-4028-845a-3aa72fd3a97b', role: 'user' };
    const res = await request('POST', '/capacity/config/import/validate', payload());
    assert.equal(res.status, 403, res.raw);
  });

  it('validate on an empty config reports emptyGate true + a summary', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    state.configEmpty = true;
    const res = await request('POST', '/capacity/config/import/validate', payload());
    assert.equal(res.status, 200, res.raw);
    assert.equal(res.json.data.emptyGate, true);
    assert.equal(res.json.data.ok, true);
    assert.equal(res.json.data.summary.teams, 1);
    // validate NEVER writes.
    assert.equal(insertsInto('cap_teams').length, 0);
  });

  it('validate on a non-empty config reports emptyGate false (still no writes)', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    state.configEmpty = false;
    const res = await request('POST', '/capacity/config/import/validate', payload());
    assert.equal(res.status, 200, res.raw);
    assert.equal(res.json.data.emptyGate, false);
    assert.equal(insertsInto('cap_teams').length, 0);
  });

  it('Fix 1: an EDITED settings row (same catalogues empty) reports emptyGate false', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    state.configEmpty = true; // no catalogue rows
    // The operator raised the standby default off the seed — user work.
    state.globalSettingsRow = [{
      mem_cpu_ratio: 20, sga_factor: 0.982, sga_divisor: 2, sga_subtract: 2, standby_sga_default_gb: 64,
      util_amber_pct: 80, util_red_pct: 90, overcommit_default_enabled: 0, layer_defaults: null,
    }];
    const res = await request('POST', '/capacity/config/import/validate', payload());
    assert.equal(res.status, 200, res.raw);
    assert.equal(res.json.data.emptyGate, false);
  });

  it('Fix 1: an EDITED default rule at the SAME row count reports emptyGate false', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    state.configEmpty = true;
    // Same count as DEFAULT_RULE_TEMPLATE, but the first rule's severity is flipped.
    state.globalRuleRows = DEFAULT_RULE_TEMPLATE.map((r, i) => ({
      type: r.type, name: r.name, level: r.level, group_by: r.group_by,
      params: JSON.stringify(r.params || {}), severity: i === 0 ? 'soft' : r.severity,
    }));
    const res = await request('POST', '/capacity/config/import/validate', payload());
    assert.equal(res.status, 200, res.raw);
    assert.equal(res.json.data.emptyGate, false);
  });

  it('P1-2: a scenario OVERRIDE referencing the global rule template reports emptyGate false', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    state.configEmpty = true;
    state.scenarioOverridesGlobalRule = true;
    const res = await request('POST', '/capacity/config/import/validate', payload());
    assert.equal(res.status, 200, res.raw);
    assert.equal(res.json.data.emptyGate, false);
  });

  it('P1-2: an Exception referencing a global rule reports emptyGate false', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    state.configEmpty = true;
    state.waiverRefsGlobalRule = true;
    const res = await request('POST', '/capacity/config/import/validate', payload());
    assert.equal(res.status, 200, res.raw);
    assert.equal(res.json.data.emptyGate, false);
  });

  it('P1-1: an ordinary global-config write takes the SAME sentinel lock before mutating', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    const res = await request('POST', '/capacity/config/teams', { name: 'Payments', color: '#36f' });
    assert.equal(res.status, 201, res.raw);
    const lockIdx = state.queries.findIndex((q) => /SELECT id FROM `fmb_cap_settings` FOR UPDATE/.test(q.sql));
    const insertIdx = state.queries.findIndex((q) => /^INSERT INTO `fmb_cap_teams`/.test(q.sql));
    assert.ok(lockIdx >= 0, 'the write takes the global-config sentinel lock');
    assert.ok(lockIdx < insertIdx, 'the lock precedes the mutate so it serializes against the import');
  });

  it('P1-1: a bundle create takes the SAME sentinel lock before inserting', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    const res = await request('POST', '/capacity/config/bundles', { name: 'Core' });
    assert.equal(res.status, 201, res.raw);
    const lockIdx = state.queries.findIndex((q) => /SELECT id FROM `fmb_cap_settings` FOR UPDATE/.test(q.sql));
    const insertIdx = state.queries.findIndex((q) => /^INSERT INTO `fmb_cap_bundles`/.test(q.sql));
    assert.ok(lockIdx >= 0 && lockIdx < insertIdx, 'the bundle create serializes against the import');
  });

  it('validate reports an unknown-sheet issue (ok false)', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    const res = await request('POST', '/capacity/config/import/validate', payload({ tables: { evil: [{ x: 1 }] } }));
    assert.equal(res.status, 200, res.raw);
    assert.equal(res.json.data.ok, false);
    assert.ok(res.json.data.issues.some((i) => i.code === 'UNKNOWN_SHEET'));
  });

  it('commit on a NON-empty config returns 409 (server-enforced) and writes nothing', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    state.configEmpty = false;
    const res = await request('POST', '/capacity/config/import/commit', payload());
    assert.equal(res.status, 409, res.raw);
    assert.equal(res.json.error.code, 'CONFLICT');
    assert.match(res.json.error.message, /not empty/);
    assert.equal(insertsInto('cap_teams').length, 0);
  });

  it('commit on an empty config writes the catalogues in one transaction', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    state.configEmpty = true;
    const res = await request('POST', '/capacity/config/import/commit', payload());
    assert.equal(res.status, 200, res.raw);
    assert.equal(res.json.data.ok, true);
    assert.equal(res.json.data.inserted.teams, 1);
    const ins = insertsInto('cap_teams');
    assert.equal(ins.length, 1);
    // scenario_id is forced NULL (global) — never taken from the file.
    assert.ok(ins[0].params.includes(null));
    // The catalogue is cleared (global rows) before re-insert.
    assert.ok(state.queries.some((q) => /^DELETE FROM `fmb_cap_teams` WHERE scenario_id IS NULL/.test(q.sql)));
  });

  // fmb-1433 item 4: a legacy workbook seeds the instance AND says what it
  // changed. The dry run shows it in `issues`; the commit response carries it
  // too, because a caller can reach commit without ever calling validate — and
  // then this response is the only place the operator is told that the number in
  // the file is not the number in the database.
  it('commit reports the derived values it floored on the way in', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    state.configEmpty = true;
    const res = await request('POST', '/capacity/config/import/commit', payload({
      tables: {
        teams: [{ ref: 't-1', name: 'Payments', color: '#36f' }],
        vm_profiles: [{ class: 'DB', name: 'DB-16C', mode: 'custom', cpu: 8, mem_gb: 61.5 }],
      },
    }));
    assert.equal(res.status, 200, res.raw);
    assert.equal(res.json.data.ok, true, 'a legacy workbook still seeds the instance');
    const floored = (res.json.data.notices || []).filter((n) => n.code === 'FLOORED_TO_WHOLE');
    assert.equal(floored.length, 1, JSON.stringify(res.json.data.notices));
    assert.equal(floored[0].column, 'mem_gb');
    assert.match(floored[0].message, /61\.5/);
    const written = insertsInto('cap_vm_profiles')[0];
    const cols = written.sql.match(/\(([^)]*)\)\s*VALUES/i)[1].split(',').map((c) => c.trim().replace(/`/g, ''));
    assert.equal(written.params[cols.indexOf('mem_gb')], 61, 'and the whole number is what was actually inserted');
  });

  it('a legacy workbook carrying a bundle-item SGA seed seeds the instance', async () => {
    // End to end on the path the app's own config export produces (SELECT *, so
    // a table row written before the rule comes back out as 96.5): commit, do not
    // refuse, and say what changed.
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    state.configEmpty = true;
    const res = await request('POST', '/capacity/config/import/commit', payload({
      tables: {
        bundles: [{ ref: 'b1', name: 'Core', serial: 1 }],
        bundle_items: [{ bundle_ref: 'b1', type: 'DB', qty: 1, topology: 'single', primary_sga_gb: 96.5 }],
      },
    }));
    assert.equal(res.status, 200, res.raw);
    assert.equal(res.json.data.ok, true, 'the app must be able to load its own export');
    const floored = (res.json.data.notices || []).filter((n) => n.code === 'FLOORED_TO_WHOLE');
    assert.equal(floored.length, 1, JSON.stringify(res.json.data.notices));
    assert.equal(floored[0].sheet, 'bundle_items');
    const written = insertsInto('cap_bundle_items')[0];
    const cols = written.sql.match(/\(([^)]*)\)\s*VALUES/i)[1].split(',').map((c) => c.trim().replace(/`/g, ''));
    assert.equal(written.params[cols.indexOf('primary_sga_gb')], 96);
  });

  it('the dry run shows the same floored values before anything is written', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    const res = await request('POST', '/capacity/config/import/validate', payload({
      tables: { vm_profiles: [{ class: 'DB', name: 'DB-16C', mode: 'custom', cpu: 8, mem_gb: 61.5 }] },
    }));
    assert.equal(res.status, 200, res.raw);
    assert.equal(res.json.data.ok, true, 'a fraction in a derived column is not a structural error');
    assert.ok(res.json.data.issues.some((i) => i.code === 'FLOORED_TO_WHOLE'), JSON.stringify(res.json.data.issues));
  });

  it('commit on a malformed payload returns 422 and writes nothing', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    state.configEmpty = true;
    const res = await request('POST', '/capacity/config/import/commit', payload({ tables: { hardware_specs: [{ cpu_total: 8 }] } }));
    assert.equal(res.status, 422, res.raw);
    assert.equal(res.json.ok, false);
    assert.equal(insertsInto('cap_hardware_specs').length, 0);
  });

  it('a payload without a tables object → 400', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    const res = await request('POST', '/capacity/config/import/validate', { schema_rev: 1 });
    assert.equal(res.status, 400, res.raw);
  });

  it('commit locks the cap_settings sentinel FOR UPDATE BEFORE evaluating the empty gate (TOCTOU serialization)', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    state.configEmpty = true;
    const res = await request('POST', '/capacity/config/import/commit', payload());
    assert.equal(res.status, 200, res.raw);
    const lockIdx = state.queries.findIndex((q) => /SELECT id FROM `fmb_cap_settings` FOR UPDATE/.test(q.sql));
    const gateIdx = state.queries.findIndex((q) => /AS hardware_specs,[\s\S]*AS bundle_items/.test(q.sql));
    assert.ok(lockIdx >= 0, 'the cap_settings FOR UPDATE lock is taken');
    assert.ok(gateIdx >= 0, 'the empty-gate aggregate is evaluated');
    assert.ok(lockIdx < gateIdx, 'the lock precedes the gate so concurrent commits serialize');
  });

  it('two interleaved commits racing an empty seed: the loser 409s once the winner has seeded', async () => {
    // Model the serialized outcome: the winner commits under the sentinel lock and
    // populates the config; the loser (which was blocked on the lock) then re-reads
    // a now-non-empty config and 409s — never a double-seed.
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    state.configEmpty = true;
    const winner = await request('POST', '/capacity/config/import/commit', payload());
    assert.equal(winner.status, 200, winner.raw);
    // The winner's writes are now visible to the next lock holder.
    state.configEmpty = false;
    const loser = await request('POST', '/capacity/config/import/commit', payload());
    assert.equal(loser.status, 409, loser.raw);
    assert.equal(loser.json.error.code, 'CONFLICT');
  });
});

// ── R2: scenario-local catalogue additions (§2.4) ──────────────────────────────
describe('R2 local catalogues: scenario-scoped writes force scenario_id + owner+admin', () => {
  it('owner editor adds a local disk combo; scenario_id is bound to the URL', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    state.scenarioOwner = '4ec54b37-3f24-4759-8c85-dc37030749b6';
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/local-catalogues/disk_combos', {
      name: 'Local combo', sizes: [512, 1024],
    });
    assert.equal(res.status, 200, res.raw); // factory create → 200
    const ins = insertsInto('cap_disk_combos');
    assert.equal(ins.length, 1);
    assert.equal(colsOf(ins[0]).scenario_id, '26895068-65f1-405c-8521-2a9e1212353c', 'a local addition is stamped to the scenario, never NULL');
  });

  it('a non-owner editor cannot add a local team (403)', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    state.scenarioOwner = 'e2d750c1-a8bf-4918-8970-7176a0e55d93';
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/local-catalogues/teams', { name: 'T', color: '#fff' });
    assert.equal(res.status, 403, res.raw);
    assert.equal(insertsInto('cap_teams').length, 0);
  });

  it('a plain user cannot add a local catalogue row (403)', async () => {
    currentUser = { id: '71d6dd0a-d1a0-4028-845a-3aa72fd3a97b', role: 'user' };
    state.scenarioOwner = '71d6dd0a-d1a0-4028-845a-3aa72fd3a97b';
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/local-catalogues/hardware_specs', { name: 'HW', cpu_total: 128 });
    assert.equal(res.status, 403, res.raw);
    assert.equal(insertsInto('cap_hardware_specs').length, 0);
  });

  it('a local vm_profile with a wrong-typed cpu → 400 (config type guard)', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/local-catalogues/vm_profiles', {
      class: 'DB', name: 'P', mode: 'formula', cpu: 'lots',
    });
    assert.equal(res.status, 400, res.raw);
    assert.equal(insertsInto('cap_vm_profiles').length, 0);
  });

  it('a local vm_profile with a non-canonical class → 400 (enum guard)', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/local-catalogues/vm_profiles', {
      class: 'db', name: 'P', mode: 'formula', cpu: 8,
    });
    assert.equal(res.status, 400, res.raw);
    assert.equal(insertsInto('cap_vm_profiles').length, 0);
  });

  it('a PUT to a local row that belongs to another scenario → 404', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.rowScenario = 'other-scenario';
    const res = await request('PUT', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/local-catalogues/teams/t-1', { name: 'x' });
    assert.equal(res.status, 404, res.raw);
    assert.equal(hasQuery(/^UPDATE `fmb_cap_teams`/), false);
  });

  it('a PUT naming a GLOBAL row (scenario_id NULL) via a literal "null" URL → 404, never matched as scenario "null"', async () => {
    // String(null) === 'null': without the explicit null-guard, a global row
    // reached through /scenarios/null/... would spuriously satisfy the binding.
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.rowScenario = null; // the row is GLOBAL (scenario_id IS NULL)
    const res = await request('PUT', '/capacity/scenarios/null/local-catalogues/teams/t-1', { name: 'x' });
    assert.equal(res.status, 404, res.raw);
    assert.equal(hasQuery(/^UPDATE `fmb_cap_teams`/), false, 'a global row must never be updated through a scenario-bound PUT');
  });

  it('a local catalogue DELETE is refused 409 while a live row references it', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.childRowExists = true;
    state.catalogueBlockerExists = true; // a VM/hypervisor still references it
    const res = await request('DELETE', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/local-catalogues/disk_combos/dc-1');
    assert.equal(res.status, 409, res.raw);
    assert.equal(res.json.error.code, 'CONFLICT');
    assert.equal(hasQuery(/^DELETE FROM `fmb_cap_disk_combos`/), false);
  });

  it('a local catalogue DELETE proceeds when unreferenced', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.childRowExists = true;
    state.catalogueBlockerExists = false;
    const res = await request('DELETE', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/local-catalogues/disk_combos/dc-1');
    assert.equal(res.status, 200, res.raw);
    assert.ok(hasQuery(/^DELETE FROM `fmb_cap_disk_combos` WHERE id = \? AND scenario_id = \?/));
  });

  it('GET lists a scenario’s local rows, scoped to its scenario_id', async () => {
    currentUser = { id: '71d6dd0a-d1a0-4028-845a-3aa72fd3a97b', role: 'user' };
    const res = await request('GET', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/local-catalogues/teams');
    assert.equal(res.status, 200, res.raw);
    const listQ = state.queries.find((q) => /FROM `fmb_cap_teams`/.test(q.sql) && /scenario_id/.test(q.sql));
    assert.ok(listQ, 'the local list is scenario-scoped');
  });
});

// ── R2: config-layer catalogue delete guard (obligation 3) ─────────────────────
describe('R2 config delete guard: a referenced GLOBAL catalogue row is 409, unreferenced deletes', () => {
  it('a global hardware_spec DELETE is refused 409 while a hypervisor references it', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.configRowExists = true;
    state.catalogueBlockerExists = true;
    const res = await request('DELETE', '/capacity/config/hardware_specs/hs-1');
    assert.equal(res.status, 409, res.raw);
    assert.equal(res.json.error.code, 'CONFLICT');
    assert.match(res.json.error.message, /hardware spec/);
    assert.equal(hasQuery(/^DELETE FROM `fmb_cap_hardware_specs`/), false);
  });

  it('a global vm_profile DELETE proceeds when unreferenced', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.configRowExists = true;
    state.catalogueBlockerExists = false;
    const res = await request('DELETE', '/capacity/config/vm_profiles/891d16b0-b217-4ec0-8a88-78a40c895623');
    assert.equal(res.status, 200, res.raw);
    assert.ok(hasQuery(/^DELETE FROM `fmb_cap_vm_profiles` WHERE id = \? AND scenario_id IS NULL/));
  });

  it('a global team DELETE of a missing row → 404 (no reference probe)', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.configRowExists = false;
    const res = await request('DELETE', '/capacity/config/teams/nope');
    assert.equal(res.status, 404, res.raw);
    assert.equal(hasQuery(/SELECT 1 AS ref/), false, 'no reference probe once the row is absent');
  });

  it('a global rule DELETE is refused 409 while a scenario override / Exception references it (candidates 514 #3)', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.configRowExists = true;
    state.catalogueBlockerExists = true;
    const res = await request('DELETE', '/capacity/config/rules/r-1');
    assert.equal(res.status, 409, res.raw);
    assert.equal(res.json.error.code, 'CONFLICT');
    assert.match(res.json.error.message, /rule/);
    assert.equal(hasQuery(/^DELETE FROM `fmb_cap_rules`/), false);
  });

  it('a global rule DELETE proceeds through the guarded tx when unreferenced', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.configRowExists = true;
    state.catalogueBlockerExists = false;
    const res = await request('DELETE', '/capacity/config/rules/r-1');
    assert.equal(res.status, 200, res.raw);
    assert.ok(hasQuery(/SELECT id FROM `fmb_cap_rules` WHERE id = \? AND scenario_id IS NULL FOR UPDATE/));
    assert.ok(hasQuery(/^DELETE FROM `fmb_cap_rules` WHERE id = \? AND scenario_id IS NULL/));
  });

  it('a plain user cannot delete a global catalogue row (403)', async () => {
    currentUser = { id: '71d6dd0a-d1a0-4028-845a-3aa72fd3a97b', role: 'user' };
    const res = await request('DELETE', '/capacity/config/teams/t-1');
    assert.equal(res.status, 403, res.raw);
  });
});

// ── R2: scenario settings effective GET (obligation 4) ─────────────────────────
describe('R2 scenario settings effective GET (fallback to global, never undefined)', () => {
  it('returns the scenario OVERRIDE row (is_override true) when one exists', async () => {
    currentUser = { id: '71d6dd0a-d1a0-4028-845a-3aa72fd3a97b', role: 'user' };
    state.settingsExists = true;
    const res = await request('GET', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/settings');
    assert.equal(res.status, 200, res.raw);
    assert.equal(res.json.data.is_override, true);
    assert.equal(res.json.data.scenario_id, '26895068-65f1-405c-8521-2a9e1212353c');
  });

  it('falls back to the GLOBAL seed row (is_override false) when there is no override', async () => {
    currentUser = { id: '71d6dd0a-d1a0-4028-845a-3aa72fd3a97b', role: 'user' };
    state.settingsExists = false;
    state.templateRows = { cap_settings: [{ id: 'f24e21e4-ac16-43fe-8f71-8d9e988f089e', scenario_id: null, mem_cpu_ratio: 20, util_amber_pct: 80, util_red_pct: 90 }] };
    const res = await request('GET', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/settings');
    assert.equal(res.status, 200, res.raw);
    assert.equal(res.json.data.is_override, false, 'the fallback is flagged not-an-override');
    assert.equal(res.json.data.mem_cpu_ratio, 20);
  });

  it('404s when the scenario id does not exist (a fallback must not mask a bad id)', async () => {
    currentUser = { id: '71d6dd0a-d1a0-4028-845a-3aa72fd3a97b', role: 'user' };
    state.scenarioExists = false;
    const res = await request('GET', '/capacity/scenarios/nope/settings');
    assert.equal(res.status, 404, res.raw);
  });

  it('404s when neither an override nor a global seed row exists (un-seeded DB)', async () => {
    currentUser = { id: '71d6dd0a-d1a0-4028-845a-3aa72fd3a97b', role: 'user' };
    state.settingsExists = false; // no override
    state.templateRows = {};      // no global row either
    const res = await request('GET', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/settings');
    assert.equal(res.status, 404, res.raw);
  });
});

// ── TA.2: disk-combo allow-list on the child vms / databases write paths (§5.3) ─
// The check runs inside the factory's write tx (preWriteInTx) after the §17.1a FK
// lock: a resulting row pairing a profile with a combo outside its allow-list → 400.
describe('TA.2 disk-combo allow-list — child vms / databases writes', () => {
  it('a vms POST with an allowed combo passes', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.fkExists = true;
    state.profileAllowedCombos = ['3f867c4e-5600-4721-880b-391c3752f046', 'combo-2'];
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/vms', {
      name: 'd8de67d9-c84d-4e73-8817-13b2f11c02f7', vm_type: 'db_host', sizing_profile_id: '45958522-1722-4a83-8fa4-ba92d7d793d8', disk_combo_id: '3f867c4e-5600-4721-880b-391c3752f046',
    });
    assert.equal(res.status, 200, res.raw);
    assert.equal(insertsInto('cap_vms').length, 1);
  });

  it('a vms POST with a disallowed combo → 400, no INSERT', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.fkExists = true;
    state.profileAllowedCombos = ['combo-2'];
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/vms', {
      name: 'd8de67d9-c84d-4e73-8817-13b2f11c02f7', vm_type: 'db_host', sizing_profile_id: '45958522-1722-4a83-8fa4-ba92d7d793d8', disk_combo_id: '3f867c4e-5600-4721-880b-391c3752f046',
    });
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'DISK_COMBO_NOT_ALLOWED');
    assert.equal(insertsInto('cap_vms').length, 0);
  });

  it('a databases POST with a disallowed combo → 400, no INSERT (direct create must not bypass)', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.fkExists = true;
    state.profileAllowedCombos = ['combo-ok'];
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/databases', {
      function_name: 'erp', topology: 'single', profile_id: '45958522-1722-4a83-8fa4-ba92d7d793d8', disk_combo_id: '49873ee3-b647-4eb0-8690-4e6a5f192937',
    });
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'DISK_COMBO_NOT_ALLOWED');
    assert.equal(insertsInto('cap_databases').length, 0);
  });

  it('a full vms PUT (both profile + combo) with a disallowed pair → 400, no UPDATE', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.fkExists = true;
    state.profileAllowedCombos = ['combo-ok'];
    const res = await request('PUT', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/vms/d8de67d9-c84d-4e73-8817-13b2f11c02f7', {
      sizing_profile_id: '45958522-1722-4a83-8fa4-ba92d7d793d8', disk_combo_id: '49873ee3-b647-4eb0-8690-4e6a5f192937',
    });
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'DISK_COMBO_NOT_ALLOWED');
    assert.equal(hasQuery(/^UPDATE `fmb_cap_vms`/), false);
  });

  it('a disk-only vms PUT against an incompatible EXISTING profile → 400 (merged pair)', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.fkExists = true;
    // The stored row already carries prof-1; the PUT changes only the combo.
    state.diskComboExistingRow = { profile_id: '45958522-1722-4a83-8fa4-ba92d7d793d8', disk_combo_id: '07a690d9-522e-4771-8151-3148bdc6795d' };
    state.profileAllowedCombos = ['07a690d9-522e-4771-8151-3148bdc6795d']; // combo-bad is NOT allowed
    const res = await request('PUT', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/vms/d8de67d9-c84d-4e73-8817-13b2f11c02f7', { disk_combo_id: '49873ee3-b647-4eb0-8690-4e6a5f192937' });
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'DISK_COMBO_NOT_ALLOWED');
    assert.equal(hasQuery(/^UPDATE `fmb_cap_vms`/), false);
  });

  it('a profile-only vms PUT against an incompatible EXISTING combo → 400 (merged pair)', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.fkExists = true;
    // The stored row already carries combo-x; the PUT changes only the profile.
    state.diskComboExistingRow = { profile_id: '27c6ef23-6d89-4502-8c0b-36bb9714882b', disk_combo_id: 'f0a2bb9e-8de1-404d-8829-dfcfea8c5c4b' };
    state.profileAllowedCombos = ['combo-y']; // combo-x is NOT allowed by the new profile
    const res = await request('PUT', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/vms/d8de67d9-c84d-4e73-8817-13b2f11c02f7', { sizing_profile_id: '4e2e7931-a8f5-4b99-8ce9-7304b6d5cd0c' });
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'DISK_COMBO_NOT_ALLOWED');
    assert.equal(hasQuery(/^UPDATE `fmb_cap_vms`/), false);
  });

  it('a disk-only vms PUT whose merged pair is allowed passes (UPDATE runs)', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.fkExists = true;
    state.diskComboExistingRow = { profile_id: '45958522-1722-4a83-8fa4-ba92d7d793d8', disk_combo_id: '07a690d9-522e-4771-8151-3148bdc6795d' };
    state.profileAllowedCombos = ['07a690d9-522e-4771-8151-3148bdc6795d', '74de4234-1809-4eda-84d6-dfd8d3dd5b2f'];
    const res = await request('PUT', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/vms/d8de67d9-c84d-4e73-8817-13b2f11c02f7', { disk_combo_id: '74de4234-1809-4eda-84d6-dfd8d3dd5b2f' });
    assert.equal(res.status, 200, res.raw);
    assert.ok(hasQuery(/^UPDATE `fmb_cap_vms`/));
  });

  it('a Custom (no-profile) vms write accepts any combo', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.fkExists = true;
    state.profileAllowedCombos = undefined; // no profile row → nothing to enforce
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/vms', {
      name: 'd8de67d9-c84d-4e73-8817-13b2f11c02f7', vm_type: 'ap_host', disk_combo_id: '25b81976-f17b-4831-86b7-56c4151ca3a0',
    });
    assert.equal(res.status, 200, res.raw);
    assert.equal(insertsInto('cap_vms').length, 1);
  });

  it('a profile with no allow-list defined accepts any combo (soft-list parity)', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.fkExists = true;
    state.profileAllowedCombos = null; // allowed_disk_combos IS NULL → unrestricted
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/vms', {
      name: 'd8de67d9-c84d-4e73-8817-13b2f11c02f7', vm_type: 'db_host', sizing_profile_id: '45958522-1722-4a83-8fa4-ba92d7d793d8', disk_combo_id: '3f867c4e-5600-4721-880b-391c3752f046',
    });
    assert.equal(res.status, 200, res.raw);
    assert.equal(insertsInto('cap_vms').length, 1);
  });
});

// ── TA.2: disk-combo allow-list on the DATABASES child write path (§5.3) ────────
// Exercises the databases-specific FOR UPDATE merge branch (profile_id column,
// cap_databases table) — spec §5.3 mandates the matrix "for both the VM and the
// database child routes".
describe('TA.2 disk-combo allow-list — databases child writes (merge branch)', () => {
  it('a databases POST with an allowed pair passes', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.fkExists = true;
    state.profileAllowedCombos = ['3f867c4e-5600-4721-880b-391c3752f046', 'combo-2'];
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/databases', {
      function_name: 'erp', topology: 'single', profile_id: '45958522-1722-4a83-8fa4-ba92d7d793d8', disk_combo_id: '3f867c4e-5600-4721-880b-391c3752f046',
    });
    assert.equal(res.status, 200, res.raw);
    assert.equal(insertsInto('cap_databases').length, 1);
  });

  it('a full databases PUT (both profile + combo) with a disallowed pair → 400, no UPDATE', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.fkExists = true;
    state.profileAllowedCombos = ['combo-ok'];
    const res = await request('PUT', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/databases/7a3d86b4-6403-4159-8ec7-66520730403d', {
      profile_id: '45958522-1722-4a83-8fa4-ba92d7d793d8', disk_combo_id: '49873ee3-b647-4eb0-8690-4e6a5f192937',
    });
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'DISK_COMBO_NOT_ALLOWED');
    assert.equal(hasQuery(/^UPDATE `fmb_cap_databases`/), false);
  });

  it('a disk-only databases PUT against an incompatible EXISTING profile → 400 (merged pair)', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.fkExists = true;
    state.diskComboExistingRow = { profile_id: '45958522-1722-4a83-8fa4-ba92d7d793d8', disk_combo_id: '07a690d9-522e-4771-8151-3148bdc6795d' };
    state.profileAllowedCombos = ['07a690d9-522e-4771-8151-3148bdc6795d'];
    const res = await request('PUT', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/databases/7a3d86b4-6403-4159-8ec7-66520730403d', { disk_combo_id: '49873ee3-b647-4eb0-8690-4e6a5f192937' });
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'DISK_COMBO_NOT_ALLOWED');
    assert.equal(hasQuery(/^UPDATE `fmb_cap_databases`/), false);
  });

  it('a profile-only databases PUT against an incompatible EXISTING combo → 400 (merged pair)', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.fkExists = true;
    state.diskComboExistingRow = { profile_id: '27c6ef23-6d89-4502-8c0b-36bb9714882b', disk_combo_id: 'f0a2bb9e-8de1-404d-8829-dfcfea8c5c4b' };
    state.profileAllowedCombos = ['combo-y'];
    const res = await request('PUT', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/databases/7a3d86b4-6403-4159-8ec7-66520730403d', { profile_id: '4e2e7931-a8f5-4b99-8ce9-7304b6d5cd0c' });
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'DISK_COMBO_NOT_ALLOWED');
    assert.equal(hasQuery(/^UPDATE `fmb_cap_databases`/), false);
  });

  it('a databases PUT whose merged row has no profile (Custom) accepts any combo', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.fkExists = true;
    state.diskComboExistingRow = { profile_id: null, disk_combo_id: 'f0a2bb9e-8de1-404d-8829-dfcfea8c5c4b' };
    const res = await request('PUT', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/databases/7a3d86b4-6403-4159-8ec7-66520730403d', { disk_combo_id: '0eab3eac-cc7d-4341-88a9-4ab7c4728ad2' });
    assert.equal(res.status, 200, res.raw);
    assert.ok(hasQuery(/^UPDATE `fmb_cap_databases`/));
  });

  it('a databases PUT persists primary_sga_gb/standby_sga_gb/dc_refs (spec §4.3 B4, §8 API surface)', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    const res = await request('PUT', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/databases/7a3d86b4-6403-4159-8ec7-66520730403d', {
      primary_sga_gb: 64, standby_sga_gb: 48, dc_refs: ['b78a9a94-3dde-45ec-8833-b3ccb7276575', 'site-2'],
    });
    assert.equal(res.status, 200, res.raw);
    assert.ok(hasQuery(
      /^UPDATE `fmb_cap_databases` SET `primary_sga_gb` = \?, `standby_sga_gb` = \?, `dc_refs` = \? WHERE id = \?/,
    ));
    const update = state.queries.find((q) => /^UPDATE `fmb_cap_databases`/.test(q.sql));
    assert.deepEqual(update.params.slice(0, 3), [64, 48, JSON.stringify(['b78a9a94-3dde-45ec-8833-b3ccb7276575', 'site-2'])]);
  });
});

describe('PUT /scenarios/:id/databases/:id — SGA cascade to child db_instances (phase-7 item 6)', () => {
  it('a primary SGA edit issues ONE per-role batched sga_gb UPDATE for the changed role', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.cascadeDatabaseRow = [{ primary_sga_gb: 96, standby_sga_gb: 48, profile_id: null, scenario_id: '26895068-65f1-405c-8521-2a9e1212353c' }];
    state.cascadeInstances = [{ role: 'primary', sga_gb: 32 }, { role: 'standby', sga_gb: 48 }];
    const res = await request('PUT', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/databases/7a3d86b4-6403-4159-8ec7-66520730403d', { primary_sga_gb: 96 });
    assert.equal(res.status, 200, res.raw);
    const upd = state.queries.find((q) => /^UPDATE `fmb_cap_db_instances` SET sga_gb = \? WHERE database_id = \? AND role = \? AND sga_gb <> \?/.test(q.sql));
    assert.ok(upd, 'a per-role batched sga_gb UPDATE is issued for the changed primary role');
    assert.deepEqual(upd.params, [96, '7a3d86b4-6403-4159-8ec7-66520730403d', 'primary', 96]);
    // standby not in the body → not touched.
    const standbyUpd = state.queries.filter((q) => /^UPDATE `fmb_cap_db_instances`/.test(q.sql) && q.params[2] === 'standby');
    assert.equal(standbyUpd.length, 0, 'the untouched standby role is not rewritten');
  });

  it('a rename PUT that re-sends unchanged SGA issues NO child UPDATE (M1: FE resends every cell)', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.cascadeDatabaseRow = [{ primary_sga_gb: 64, standby_sga_gb: 48, profile_id: null, scenario_id: '26895068-65f1-405c-8521-2a9e1212353c' }];
    state.cascadeInstances = [{ role: 'primary', sga_gb: 64 }, { role: 'standby', sga_gb: 48 }];
    const res = await request('PUT', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/databases/7a3d86b4-6403-4159-8ec7-66520730403d', {
      function_name: 'renamed', primary_sga_gb: 64, standby_sga_gb: 48,
    });
    assert.equal(res.status, 200, res.raw);
    assert.equal(hasQuery(/^UPDATE `fmb_cap_db_instances`/), false, 'no child write when the derived value is unchanged');
  });
});

describe('PUT /scenarios/:id/databases/:id — SGA numeric value guard (phase-7 item 6, M2)', () => {
  it('rejects a negative primary_sga_gb with 400 VALUE_GUARD and no UPDATE', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    const res = await request('PUT', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/databases/7a3d86b4-6403-4159-8ec7-66520730403d', { primary_sga_gb: -5 });
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'VALUE_GUARD');
    assert.equal(hasQuery(/^UPDATE `fmb_cap_databases`/), false);
    assert.equal(hasQuery(/^UPDATE `fmb_cap_db_instances`/), false);
  });

  it('rejects a non-numeric standby_sga_gb with 400 VALUE_GUARD', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    const res = await request('PUT', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/databases/7a3d86b4-6403-4159-8ec7-66520730403d', { standby_sga_gb: 'lots' });
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'VALUE_GUARD');
  });

  it('accepts a null SGA (unset → derive) and does not 400', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    const res = await request('PUT', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/databases/7a3d86b4-6403-4159-8ec7-66520730403d', { primary_sga_gb: null });
    assert.equal(res.status, 200, res.raw);
  });

  // fmb-1433: SGA accepts whole numbers only. The grid refuses a fractional cell,
  // but this mount is reachable without it (raw API), and the value cascades into
  // every child instance's persisted sga_gb — so it is refused here too.
  it('rejects a fractional primary_sga_gb with 400 VALUE_GUARD and no UPDATE', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    const res = await request('PUT', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/databases/7a3d86b4-6403-4159-8ec7-66520730403d', { primary_sga_gb: 96.5 });
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'VALUE_GUARD');
    assert.match(res.json.error.message, /whole number/);
    assert.equal(hasQuery(/^UPDATE `fmb_cap_databases`/), false);
    assert.equal(hasQuery(/^UPDATE `fmb_cap_db_instances`/), false);
  });

  it('rejects a fractional standby_sga_gb with 400 VALUE_GUARD', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    const res = await request('PUT', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/databases/7a3d86b4-6403-4159-8ec7-66520730403d', { standby_sga_gb: 48.25 });
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'VALUE_GUARD');
  });

  it('still accepts a whole SGA', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    const res = await request('PUT', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/databases/7a3d86b4-6403-4159-8ec7-66520730403d', { primary_sga_gb: 96 });
    assert.equal(res.status, 200, res.raw);
  });
});

// fmb-1433: a custom-mode VM profile's hand-set MEM and SGA cap are whole
// numbers only, on the global config mount AND its scenario-local twin (both
// run the same CONFIG_MOUNTS type guard, so both are probed).
describe('fmb-1433: vm_profiles mem_gb / sga_cap_gb accept whole numbers only', () => {
  it('a fractional mem_gb on the GLOBAL config mount → 400, no INSERT', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    const res = await request('POST', '/capacity/config/vm_profiles', {
      class: 'DB', name: 'DB-frac', mode: 'custom', cpu: 8, mem_gb: 61.5,
    });
    assert.equal(res.status, 400, res.raw);
    assert.match(res.json.error.message, /mem_gb must be a whole number/);
    assert.equal(insertsInto('cap_vm_profiles').length, 0);
  });

  it('a fractional sga_cap_gb on the GLOBAL config mount → 400', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    const res = await request('POST', '/capacity/config/vm_profiles', {
      class: 'DB', name: 'DB-frac', mode: 'custom', cpu: 8, sga_cap_gb: 27.9,
    });
    assert.equal(res.status, 400, res.raw);
    assert.match(res.json.error.message, /sga_cap_gb must be a whole number/);
  });

  it('a fractional sga_cap_gb on the SCENARIO-LOCAL mount → 400', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/local-catalogues/vm_profiles', {
      class: 'DB', name: 'DB-frac', mode: 'custom', cpu: 8, sga_cap_gb: 27.9,
    });
    assert.equal(res.status, 400, res.raw);
    assert.match(res.json.error.message, /sga_cap_gb must be a whole number/);
  });

  it('a fractional standby_sga_default_gb on /config/settings → 400', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    const res = await request('POST', '/capacity/config/settings', {
      mem_cpu_ratio: 20, standby_sga_default_gb: 32.5,
    });
    assert.equal(res.status, 400, res.raw);
    assert.match(res.json.error.message, /standby_sga_default_gb must be a whole number/);
  });

  it('a fractional mem_cpu_ratio on /config/settings still passes (a ratio need not be whole)', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    const res = await request('POST', '/capacity/config/settings', {
      mem_cpu_ratio: 20.5, standby_sga_default_gb: 32,
    });
    // The real success status, not "anything but 400" — that would have stayed
    // green on a 500, a 403 or a 404, none of which is this route working.
    assert.equal(res.status, 201, res.raw);
    // The settings singleton is seeded with INSERT ... SELECT ... WHERE NOT
    // EXISTS (no VALUES clause), so colsOf does not apply here.
    const write = insertsInto('cap_settings')[0];
    const cols = write.sql.match(/\(([^)]*)\)\s*SELECT/i)[1].split(',').map((c) => c.trim().replace(/`/g, ''));
    assert.equal(write.params[cols.indexOf('mem_cpu_ratio')], 20.5, 'the decimal is what was stored');
  });

  it('a whole custom profile still saves', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    const res = await request('POST', '/capacity/config/vm_profiles', {
      class: 'DB', name: 'DB-whole', mode: 'custom', cpu: 8, mem_gb: 256, sga_cap_gb: 120,
    });
    assert.equal(res.status, 201, res.raw);
  });
});

// fmb-1433 item 7: clone is a REPLAY, not a write path — it carries rows the app
// already accepted from one scenario to another. It deliberately holds no
// whole-number guard: a scenario holding a pre-rule 96.5 must stay copyable, and
// the number the operator sees is made whole where it is READ, not by rewriting
// their history. These pin both halves of that — the copy succeeds, and it
// copies rather than "corrects".
describe('fmb-1433: cloning a scenario that predates the whole-number rule', () => {
  it('copies a fractional SGA verbatim instead of refusing the clone', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    const rows = prEScenarioRows();
    rows.databases = [{ ...rows.databases[0], primary_sga_gb: 96.5, standby_sga_gb: 48.25 }];
    rows.db_instances = [{ ...rows.db_instances[0], sga_gb: 96.5 }];
    rows.vm_profiles = [{ ...rows.vm_profiles[0], mode: 'custom', mem_gb: 61.5, sga_cap_gb: 27.9 }];
    state.scenarioRows = rows;
    state.sourceScenarioRow = [{ name: 'Legacy', note: null }];

    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/clone', { name: 'Legacy copy' });
    assert.equal(res.status, 201, res.raw);
    const db = cloneRow('cap_databases');
    assert.equal(db.primary_sga_gb, 96.5, 'a replay must not silently rewrite the operator\'s stored history');
    assert.equal(db.standby_sga_gb, 48.25);
    assert.equal(cloneRow('cap_db_instances').sga_gb, 96.5);
    const prof = cloneRow('cap_vm_profiles');
    assert.equal(prof.mem_gb, 61.5);
    assert.equal(prof.sga_cap_gb, 27.9);
  });
});

describe('PUT /scenarios/:id/db_instances/:id — sga_gb is immutable (spec §4.3 B5, never-block)', () => {
  it('a PUT carrying sga_gb alongside another field ignores sga_gb but still applies the rest', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    const res = await request('PUT', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/db_instances/54e9efcd-df46-407b-8eaf-824d49e5a4a1', {
      name: 'renamed', sga_gb: 999,
    });
    assert.equal(res.status, 200, res.raw);
    const update = state.queries.find((q) => /^UPDATE `fmb_cap_db_instances`/.test(q.sql));
    assert.ok(update, 'an UPDATE was issued for the non-immutable field');
    assert.doesNotMatch(update.sql, /`sga_gb`/, 'sga_gb must never appear in the SET clause');
    assert.match(update.sql, /`name`/, 'the non-immutable field still updates');
  });

  it('a PUT carrying ONLY sga_gb has nothing left to update (400, generic no-valid-fields — not a special sga_gb error)', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    const res = await request('PUT', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/db_instances/54e9efcd-df46-407b-8eaf-824d49e5a4a1', { sga_gb: 999 });
    assert.equal(res.status, 400, res.raw);
    assert.equal(hasQuery(/^UPDATE `fmb_cap_db_instances`/), false);
  });
});

// ── TA.2: disk-combo allow-list on BUNDLE-ITEM writes (Codex P2) ────────────────
// A bundle item carries profile_id + disk_combo_id; without this an editor could
// save an item whose pair the wizard's new server-side derivation later rejects at
// every stamp — savable but permanently unusable. Same merged-pair semantics.
describe('TA.2 disk-combo allow-list — bundle-item writes (Codex P2)', () => {
  it('a bundle-item POST with an allowed pair passes', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.bundleExists = true;
    state.fkExists = true;
    state.fkScenarioId = null; // global profile + combo
    state.profileClass = 'DB';
    state.profileAllowedCombos = ['3f867c4e-5600-4721-880b-391c3752f046'];
    const res = await request('POST', '/capacity/config/bundles/b1/items', {
      type: 'DB', qty: 1, profile_id: '891d16b0-b217-4ec0-8a88-78a40c895623', disk_combo_id: '3f867c4e-5600-4721-880b-391c3752f046',
    });
    assert.equal(res.status, 201, res.raw);
    assert.equal(insertsInto('cap_bundle_items').length, 1);
  });

  it('a bundle-item POST with a disallowed pair → 400, no INSERT', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.bundleExists = true;
    state.fkExists = true;
    state.fkScenarioId = null;
    state.profileClass = 'DB';
    state.profileAllowedCombos = ['combo-2'];
    const res = await request('POST', '/capacity/config/bundles/b1/items', {
      type: 'DB', qty: 1, profile_id: '891d16b0-b217-4ec0-8a88-78a40c895623', disk_combo_id: '3f867c4e-5600-4721-880b-391c3752f046',
    });
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'DISK_COMBO_NOT_ALLOWED');
    assert.equal(insertsInto('cap_bundle_items').length, 0);
  });

  it('a disk-only bundle-item PUT against an incompatible STORED profile → 400 (merged pair)', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.bundleItemExists = true;
    state.fkScenarioId = null;
    state.bundleItemType = 'DB';
    state.bundleItemProfileId = 'p-db';
    state.bundleItemDiskComboId = '07a690d9-522e-4771-8151-3148bdc6795d';
    state.profileClass = 'DB';
    state.profileAllowedCombos = ['07a690d9-522e-4771-8151-3148bdc6795d'];
    const res = await request('PUT', '/capacity/config/bundles/b1/items/i-1', { disk_combo_id: '49873ee3-b647-4eb0-8690-4e6a5f192937' });
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'DISK_COMBO_NOT_ALLOWED');
    assert.equal(hasQuery(/^UPDATE `fmb_cap_bundle_items`/), false);
  });

  it('a profile-only bundle-item PUT against an incompatible STORED combo → 400 (merged pair)', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.bundleItemExists = true;
    state.fkScenarioId = null;
    state.bundleItemType = 'DB';
    state.bundleItemProfileId = 'p-old';
    state.bundleItemDiskComboId = 'f0a2bb9e-8de1-404d-8829-dfcfea8c5c4b';
    state.profileClass = 'DB';
    state.profileAllowedCombos = ['combo-y'];
    const res = await request('PUT', '/capacity/config/bundles/b1/items/i-1', { profile_id: '744cb42f-0803-43cd-8f3c-3c570f4d9bc5' });
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'DISK_COMBO_NOT_ALLOWED');
    assert.equal(hasQuery(/^UPDATE `fmb_cap_bundle_items`/), false);
  });

  it('a bundle-item PUT whose merged row has no profile (Custom) accepts any combo', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.bundleItemExists = true;
    state.fkScenarioId = null;
    state.bundleItemType = 'AP';
    state.bundleItemProfileId = null; // no profile stored
    state.bundleItemDiskComboId = 'f0a2bb9e-8de1-404d-8829-dfcfea8c5c4b';
    const res = await request('PUT', '/capacity/config/bundles/b1/items/i-1', { disk_combo_id: '0eab3eac-cc7d-4341-88a9-4ab7c4728ad2' });
    assert.equal(res.status, 200, res.raw);
    assert.ok(hasQuery(/^UPDATE `fmb_cap_bundle_items`/));
  });
});

// ── TA.3: local-catalogues delete-guard parity (§5.1 / spec deferred item) ─────
// A locally-referenced catalogue row must 409, not orphan the reference. The
// disk_combos parity case is covered above; this proves vm_profiles + hardware_specs.
describe('TA.3 local-catalogue delete guard parity', () => {
  it('a local vm_profile DELETE is refused 409 while a VM/database references it', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.childRowExists = true;
    state.catalogueBlockerExists = true;
    const res = await request('DELETE', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/local-catalogues/vm_profiles/891d16b0-b217-4ec0-8a88-78a40c895623');
    assert.equal(res.status, 409, res.raw);
    assert.equal(res.json.error.code, 'CONFLICT');
    assert.match(res.json.error.message, /VM profile/);
    assert.equal(hasQuery(/^DELETE FROM `fmb_cap_vm_profiles`/), false);
  });

  it('a local hardware_spec DELETE is refused 409 while a hypervisor references it', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.childRowExists = true;
    state.catalogueBlockerExists = true;
    const res = await request('DELETE', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/local-catalogues/hardware_specs/hs-1');
    assert.equal(res.status, 409, res.raw);
    assert.match(res.json.error.message, /hardware spec/);
    assert.equal(hasQuery(/^DELETE FROM `fmb_cap_hardware_specs`/), false);
  });

  it('a local vm_profile DELETE proceeds when unreferenced', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.childRowExists = true;
    state.catalogueBlockerExists = false;
    const res = await request('DELETE', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/local-catalogues/vm_profiles/891d16b0-b217-4ec0-8a88-78a40c895623');
    assert.equal(res.status, 200, res.raw);
    assert.ok(hasQuery(/^DELETE FROM `fmb_cap_vm_profiles` WHERE id = \? AND scenario_id = \?/));
  });
});

// ── Phase-2 B1: Sites list honors ?sort=order_index (spec §4.3) ──────────────
describe('GET /scenarios/:id/sites?sort=order_index', () => {
  it('returns sites in the wizard-authored DC order, not created_at', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.listRows = {
      sites: [
        { id: '81fa4770-889e-49f5-8e6a-8a8d57e4b54f', scenario_id: '26895068-65f1-405c-8521-2a9e1212353c', name: 'DC2', order_index: 1, metadata: null, created_at: '2026-01-02 00:00:00', updated_at: '2026-01-02 00:00:00' },
        { id: '5f800e93-38b1-4a03-8bac-066a757a359b', scenario_id: '26895068-65f1-405c-8521-2a9e1212353c', name: 'DC1', order_index: 0, metadata: null, created_at: '2026-01-01 00:00:00', updated_at: '2026-01-01 00:00:00' },
        { id: '6463a034-4b26-4360-87de-33021d0f29d2', scenario_id: '26895068-65f1-405c-8521-2a9e1212353c', name: 'DC3', order_index: 2, metadata: null, created_at: '2026-01-03 00:00:00', updated_at: '2026-01-03 00:00:00' },
      ],
    };
    const res = await request('GET', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/sites?sort=order_index');
    assert.equal(res.status, 200, res.raw);
    assert.deepEqual(res.json.data.map((r) => r.name), ['DC1', 'DC2', 'DC3']);
  });
});

// ── TA.4: every grid-tab write path returns JSON 2xx (no text/html 502 class) ──
// Acceptance 17 route-test half: each tab's write path is a real JSON route, not
// an unmatched path that falls through to an Express text/html 404 (→ infra 502).
const isJsonResponse = (res) => /application\/json/.test(res.headers['content-type'] || '')
  && !/text\/html/.test(res.headers['content-type'] || '');

describe('TA.4 grid-tab write paths — 2xx JSON, no text/html fall-through', () => {
  beforeEach(() => { state.fkExists = true; state.fkVmType = 'db_host'; });

  const childCreates = [
    ['sites', 'cap_sites', { name: 'DC1' }],
    ['hypervisors', 'cap_hypervisors', { name: '3bb4a2d0-19a4-4ea3-89e7-32226b5c3e2f', site_id: 'b78a9a94-3dde-45ec-8833-b3ccb7276575', spec_id: '8d9a523d-173d-4446-83f5-888b5ce48df4' }],
    ['vms', 'cap_vms', { name: 'd8de67d9-c84d-4e73-8817-13b2f11c02f7', vm_type: 'ap_host' }],
    ['db_instances', 'cap_db_instances', { name: '7a3d86b4-6403-4159-8ec7-66520730403d', vm_id: '83fa3342-8416-4ee1-8a9f-ccfa6145a0ec', role: 'primary' }],
    ['databases', 'cap_databases', { function_name: 'erp', topology: 'single' }],
  ];
  for (const [segment, table, body] of childCreates) {
    it(`POST /${segment} persists + returns JSON 2xx`, async () => {
      currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
      const res = await request('POST', `/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/${segment}`, body);
      assert.equal(res.status, 200, res.raw);
      assert.ok(res.json && res.json.data, 'a JSON body is returned');
      assert.ok(isJsonResponse(res), 'Content-Type is application/json, never text/html');
      assert.equal(insertsInto(table).length, 1, 'the write persisted');
    });
  }

  const localCreates = [
    ['hardware_specs', 'cap_hardware_specs', { name: 'HW', cpu_total: 128 }],
    ['vm_profiles', 'cap_vm_profiles', { class: 'DB', name: 'P', mode: 'formula', cpu: 8 }],
  ];
  for (const [catalogue, table, body] of localCreates) {
    it(`POST /local-catalogues/${catalogue} persists + returns JSON 2xx (repointed catalogue-view write)`, async () => {
      currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
      const res = await request('POST', `/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/local-catalogues/${catalogue}`, body);
      assert.equal(res.status, 200, res.raw);
      assert.ok(res.json && res.json.data);
      assert.ok(isJsonResponse(res));
      assert.equal(insertsInto(table).length, 1);
    });
  }

  it('PUT /settings returns JSON 2xx', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.settingsExists = true;
    const res = await request('PUT', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/settings', { mem_cpu_ratio: 25 });
    assert.equal(res.status, 200, res.raw);
    assert.ok(isJsonResponse(res));
  });

  it('the OLD catalogue-view POST path (GET-only /specs) is a text/html 404 — the 502 class the repoint fixes', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/specs', { name: 'HW' });
    assert.equal(res.status, 404, res.raw);
    // Express's default handler returns text/html — exactly what the infra proxy
    // converts to a 502 EDGE_UNEXPECTED_CONTENT_TYPE. The FE fix is to write to
    // /local-catalogues/hardware_specs (asserted JSON above) instead of here.
    assert.ok(!isJsonResponse(res), 'the unmatched write path falls through to text/html (the 502 root cause)');
  });
});

// ── PR-C backend hardening (fmb-0200/0222, 0203, 0137, 0140, 0125) ─────────────
describe('PR-C: scenarios use safeRollback (fmb-0200/0222)', () => {
  it('a rollback that itself throws does NOT mask the original 404 (DELETE not-found)', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.deleteScenarioRows = [];  // scenario not found → early-return rollback path
    state.rollbackThrows = true;    // and rollback() throws
    const res = await request('DELETE', '/capacity/scenarios/nope');
    // safeRollback swallows the rollback failure, so the original 404 is preserved
    // (a bare `await conn.rollback()` would have thrown into the outer catch → 500).
    assert.equal(res.status, 404, res.raw);
    assert.equal(res.json.error.code, 'NOT_FOUND');
  });

  it('a rollback that throws on the forbidden path still returns 403 (not 500)', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    state.scenarioOwner = 'e2d750c1-a8bf-4918-8970-7176a0e55d93'; // editor is not the owner → 403 early-return
    state.rollbackThrows = true;
    const res = await request('DELETE', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c');
    assert.equal(res.status, 403, res.raw);
  });
});

describe('PR-C: clone size cap (fmb-0203)', () => {
  it('rejects an oversized clone with 400 PAYLOAD_TOO_LARGE, before any INSERT', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    state.sourceScenarioRow = [{ name: 'Src', note: null }];
    // A single scenario-scoped row whose serialized payload exceeds SNAPSHOT_MAX_BYTES (4MB).
    state.scenarioRows = { sites: [{ id: '0e06856e-f316-4505-8a20-d5cbdc42bd73', name: 'x'.repeat(5 * 1024 * 1024) }] };
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/clone', { name: 'Too Big' });
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'PAYLOAD_TOO_LARGE');
    assert.equal(insertsInto('cap_scenarios').length, 0, 'the clone is rejected before the scenario INSERT');
  });

  it('allows a normal-sized clone (under the cap)', async () => {
    currentUser = { id: '4ec54b37-3f24-4759-8c85-dc37030749b6', role: 'editor' };
    state.sourceScenarioRow = [{ name: 'Src', note: null }];
    state.scenarioRows = { sites: [{ id: '0e06856e-f316-4505-8a20-d5cbdc42bd73', name: 'small' }] };
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/clone', { name: 'Fine' });
    assert.equal(res.status, 201, res.raw);
    assert.equal(insertsInto('cap_scenarios').length, 1);
  });
});

describe('PR-C: object_set_key length guard (fmb-0137)', () => {
  it('rejects a waiver whose object_set_key exceeds the 512 column width → 400, no INSERT', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.fkExists = true;
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/waivers', {
      rule_id: '90eb8cf2-928b-4835-8608-d2857bb3cfd6', object_set_key: 'x'.repeat(513),
    });
    assert.equal(res.status, 400, res.raw);
    assert.match(res.json.error.message, /object_set_key exceeds 512/);
    assert.equal(insertsInto('cap_waivers').length, 0, 'rejected before any INSERT');
  });

  it('accepts a waiver with an object_set_key at the 512 limit', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.fkExists = true;
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/waivers', {
      rule_id: '90eb8cf2-928b-4835-8608-d2857bb3cfd6', object_set_key: 'x'.repeat(512),
    });
    assert.equal(res.status, 200, res.raw);
    assert.equal(insertsInto('cap_waivers').length, 1);
  });

  it('rejects a PRESENT non-string object_set_key (type-confusion bypass) → 400, no INSERT (SEC-M1)', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.fkExists = true;
    for (const bad of [['a', 'b'], 42, { k: 'v' }]) {
      state.queries = [];
      const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/waivers', {
        rule_id: '90eb8cf2-928b-4835-8608-d2857bb3cfd6', object_set_key: bad,
      });
      assert.equal(res.status, 400, res.raw);
      assert.match(res.json.error.message, /object_set_key must be a string/);
      assert.equal(insertsInto('cap_waivers').length, 0, 'a non-string object_set_key is rejected before any INSERT');
    }
  });
});

describe('PR-C: cap_field_defs DB duplicate mapped to app 400 (fmb-0140)', () => {
  it('a global field_def INSERT that trips the UNIQUE index → 400 with the app-layer message', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.fieldDefDuplicateExists = false; // app-layer pre-check passes → INSERT runs
    state.fieldDefInsertDuplicate = true;  // …and the DB UNIQUE index rejects it (errno 1062)
    const res = await request('POST', '/capacity/config/field_defs', {
      entity_type: 'vm', field_key: 'foo', data_type: 'text',
    });
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'BAD_REQUEST');
    assert.match(res.json.error.message, /field_key "foo" already exists for entity_type "vm"/);
  });

  it('a non-1062 DB error on the field_defs INSERT is NOT mapped — stays a 500', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.fieldDefDuplicateExists = false;      // app-layer pre-check passes → INSERT runs
    state.fieldDefInsertGenericError = true;    // …and the INSERT fails with errno 1030 (not 1062)
    const res = await request('POST', '/capacity/config/field_defs', {
      entity_type: 'vm', field_key: 'bar', data_type: 'text',
    });
    assert.equal(res.status, 500, res.raw);
    assert.equal(res.json.error.code, 'INTERNAL_ERROR');
  });

  it('a clean field_defs INSERT still succeeds (happy path 201)', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.fieldDefDuplicateExists = false;
    const res = await request('POST', '/capacity/config/field_defs', {
      entity_type: 'vm', field_key: 'baz', data_type: 'text',
    });
    assert.equal(res.status, 201, res.raw);
  });
});

describe('PR-C: vm_type flip guard locks the vm row in-tx (fmb-0125)', () => {
  it('a canonical ap_host flip probes the vm row FOR UPDATE inside the write tx', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.vmHasInstances = false; // no instances → flip allowed (200)
    const res = await request('PUT', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/vms/d8de67d9-c84d-4e73-8817-13b2f11c02f7', { vm_type: 'ap_host' });
    assert.equal(res.status, 200, res.raw);
    const lock = state.queries.find((q) => /SELECT id FROM `fmb_cap_vms` WHERE id = \? AND scenario_id = \? FOR UPDATE/.test(q.sql));
    assert.ok(lock, 'the flip guard locks the target vm row FOR UPDATE (serialises with a racing db_instance INSERT)');
    assert.deepEqual(lock.params, ['d8de67d9-c84d-4e73-8817-13b2f11c02f7', '26895068-65f1-405c-8521-2a9e1212353c']);
  });
});

// The vms mount self-locks cap_vms (flip + disk-combo) OUTSIDE reference-integrity.js's
// canonical compareCatalogueTable ordering; it is deadlock-safe ONLY while cap_vms
// sorts after every table in CHILD_FK_VALIDATIONS.vms (so the FK locks are acquired
// before the self-lock, keeping the sequence globally canonical). A future vms FK
// spec pointing at a table that sorts >= cap_vms would silently reintroduce a
// deadlock — this test fails loudly first. (SEC-L1.) NOTE: the databases mount does
// NOT satisfy the analogous own-table-last property — a known pre-existing caveat
// documented at makeDiskComboLockValidator; scoped here to the vms self-lock this
// PR added.
describe('PR-C: vms self-lock ordering invariant (SEC-L1)', () => {
  const { CHILD_FK_VALIDATIONS } = require('../../../../src/edge/routes/app/capacity/_shared');
  const { compareCatalogueTable } = require('../../../../src/edge/routes/app/capacity/reference-integrity');
  const { TABLES } = require('../../../../src/shared/constants');

  it('every table in CHILD_FK_VALIDATIONS.vms sorts before cap_vms (self-lock acquired last)', () => {
    for (const spec of CHILD_FK_VALIDATIONS.vms) {
      assert.ok(
        compareCatalogueTable(spec.table, TABLES.CAP_VMS) < 0,
        `${spec.table} must sort before ${TABLES.CAP_VMS} so the vms flip/disk-combo self-lock stays globally canonical`,
      );
    }
  });
});

// ── Codex r1 P1: generic db_instances CREATE server-derives sga_gb by role ──────
// The PUT immutable-column strip only guarded edits; a generic POST (Grid Add
// Row) omitted sga_gb → DB default 0, and a direct POST could forge any value.
// CREATE now ignores inbound sga_gb and derives it in-tx (spec §6.3).
describe('Codex r1 P1: db_instances CREATE derives sga_gb server-side (never client)', () => {
  const rowOf = () => {
    const ins = insertsInto('cap_db_instances');
    assert.equal(ins.length, 1);
    return synthRowFromInsert(ins[0].sql, ins[0].params);
  };

  it('ignores a client-supplied sga_gb; a primary derives the database primary value', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.fkExists = true; state.fkVmType = 'db_host';
    state.dbInstanceDatabaseRow = [{ primary_sga_gb: 128, standby_sga_gb: 64, profile_id: null }];
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/db_instances', {
      name: '3fd934e6-73f2-4b9b-873b-4999f3b2b797', vm_id: '83fa3342-8416-4ee1-8a9f-ccfa6145a0ec', database_id: '7a3d86b4-6403-4159-8ec7-66520730403d', role: 'primary', sga_gb: 999,
    });
    assert.equal(res.status, 200, res.raw);
    assert.equal(Number(rowOf().sga_gb), 128, 'client 999 ignored; primary → database.primary_sga_gb');
  });

  it('derives the primary sga_gb when the client omits it', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.fkExists = true; state.fkVmType = 'db_host';
    state.dbInstanceDatabaseRow = [{ primary_sga_gb: 96, standby_sga_gb: 48, profile_id: null }];
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/db_instances', {
      name: '3fd934e6-73f2-4b9b-873b-4999f3b2b797', vm_id: '83fa3342-8416-4ee1-8a9f-ccfa6145a0ec', database_id: '7a3d86b4-6403-4159-8ec7-66520730403d', role: 'primary',
    });
    assert.equal(res.status, 200, res.raw);
    assert.equal(Number(rowOf().sga_gb), 96);
  });

  it('a standby derives the database standby value, not the client value', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.fkExists = true; state.fkVmType = 'db_host';
    state.dbInstanceDatabaseRow = [{ primary_sga_gb: 96, standby_sga_gb: 48, profile_id: null }];
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/db_instances', {
      name: '8b91b47e-24d4-44d6-8ea0-48a11ee28671', vm_id: '83fa3342-8416-4ee1-8a9f-ccfa6145a0ec', database_id: '7a3d86b4-6403-4159-8ec7-66520730403d', role: 'standby', sga_gb: 999,
    });
    assert.equal(res.status, 200, res.raw);
    assert.equal(Number(rowOf().sga_gb), 48, 'standby → database.standby_sga_gb, client ignored');
  });

  it('a standby with no database standby value falls back to the settings default', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.fkExists = true; state.fkVmType = 'db_host';
    state.dbInstanceDatabaseRow = [{ primary_sga_gb: null, standby_sga_gb: null, profile_id: null }];
    state.capSettingsGlobalRow = [{
      standby_sga_default_gb: 40, sga_factor: 0.982, sga_divisor: 1, sga_subtract: 0, mem_cpu_ratio: 4,
    }];
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/db_instances', {
      name: 'i3', vm_id: '83fa3342-8416-4ee1-8a9f-ccfa6145a0ec', database_id: '7a3d86b4-6403-4159-8ec7-66520730403d', role: 'standby',
    });
    assert.equal(res.status, 200, res.raw);
    assert.equal(Number(rowOf().sga_gb), 40, 'standby → cap_settings.standby_sga_default_gb');
  });

  it('a standby uses the SCENARIO-LOCAL settings override, not the global default (Codex r2 P1-1)', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.fkExists = true; state.fkVmType = 'db_host';
    state.dbInstanceDatabaseRow = [{ primary_sga_gb: null, standby_sga_gb: null, profile_id: null }];
    // The scenario-effective resolution returns the scenario override row (wins
    // over global); the mock global would give 40, the scenario override 50.
    state.capSettingsGlobalRow = [{ standby_sga_default_gb: 40 }];
    state.capSettingsScenarioRow = [{ standby_sga_default_gb: 50 }];
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/db_instances', {
      name: 'i4', vm_id: '83fa3342-8416-4ee1-8a9f-ccfa6145a0ec', database_id: '7a3d86b4-6403-4159-8ec7-66520730403d', role: 'standby',
    });
    assert.equal(res.status, 200, res.raw);
    assert.equal(Number(rowOf().sga_gb), 50, 'standby derives the scenario-local override (50), not global (40)');
  });
});

// ── Codex r1 P2: generic sites CREATE appends order_index (MAX+1) ────────────────
// A grid-added site used to persist order_index 0 (DB default), colliding with
// the first wizard-authored DC. CREATE now assigns MAX(order_index)+1 within the
// scenario, in-tx, and ignores any client-supplied order_index.
describe('Codex r1 P2: sites CREATE appends order_index (MAX+1), ignoring the client value', () => {
  const orderOf = (i) => {
    const ins = insertsInto('cap_sites');
    return Number(synthRowFromInsert(ins[i].sql, ins[i].params).order_index);
  };

  it('a grid-add after wizard sites 0..2 lands at order_index 3 (client value ignored)', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.siteOrderIndices = [0, 1, 2];
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/sites', { name: 'DC-D', order_index: 99 });
    assert.equal(res.status, 200, res.raw);
    assert.equal(insertsInto('cap_sites').length, 1);
    assert.equal(orderOf(0), 3, 'append MAX(0,1,2)+1 = 3; client 99 dropped');
  });

  it('two successive grid-adds land at 3 then 4', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.siteOrderIndices = [0, 1, 2];
    const r1 = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/sites', { name: 'DC-D' });
    assert.equal(r1.status, 200, r1.raw);
    const r2 = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/sites', { name: 'DC-E' });
    assert.equal(r2.status, 200, r2.raw);
    assert.deepEqual([orderOf(0), orderOf(1)], [3, 4]);
  });

  it('the append MAX+1 is read in-tx under a scenario FOR UPDATE lock, before the INSERT', async () => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.siteOrderIndices = [0];
    const res = await request('POST', '/capacity/scenarios/26895068-65f1-405c-8521-2a9e1212353c/sites', { name: 'DC-B' });
    assert.equal(res.status, 200, res.raw);
    const scenarioLocks = state.queries.filter((q) => /SELECT id FROM `fmb_cap_scenarios` WHERE id = \? FOR UPDATE/.test(q.sql));
    // fmb-1685: the scenario row is locked EXACTLY ONCE — by makeScenarioRowLock.
    // The sites transform used to re-lock it (a second acquisition); collapsed.
    assert.equal(scenarioLocks.length, 1, 'the scenario row is locked once, not twice');
    const lockIdx = state.queries.findIndex((q) => /SELECT id FROM `fmb_cap_scenarios` WHERE id = \? FOR UPDATE/.test(q.sql));
    const maxIdx = state.queries.findIndex((q) => /COALESCE\(MAX\(order_index\), -1\) \+ 1 AS next FROM `fmb_cap_sites`/.test(q.sql));
    const insertIdx = state.queries.findIndex((q) => /^INSERT INTO `fmb_cap_sites`/.test(q.sql));
    assert.ok(lockIdx >= 0 && maxIdx >= 0 && insertIdx >= 0, 'lock + MAX + INSERT all present');
    assert.ok(lockIdx < maxIdx && maxIdx < insertIdx, 'scenario lock → MAX read → INSERT, in order');
  });
});

// ── A KVM's data centre is written by the placement, on both verbs ─────────────
// The mocked layer answered `[]` to every read these hooks make, so the
// derivation's early exit was the only path any of these tests ever took: the
// rule could have been deleted and this file stayed green. One case per verb,
// each asserting the VALUE the statement carries rather than its status code.
describe('D1: cap_vms.site_id is derived from the host on POST and PUT', () => {
  const SCN = '26895068-65f1-405c-8521-2a9e1212353c';
  const HOST = '9d2b6f1c-6f0e-4f2f-9a3a-3f5d4a1b2c3d';
  const HOST_DC = 'c0ffee00-1111-4222-8333-444455556666';
  const OTHER_DC = 'deadbee0-9999-4888-8777-666655554444';
  // The cache a stored row already holds, kept distinct from both of the above
  // so a case can say which of the three a written value came from.
  const STORED_DC = 'facade00-2222-4333-8444-555566667777';
  const VM = 'd8de67d9-c84d-4e73-8817-13b2f11c02f7';
  const updatesTo = (table) =>
    state.queries.filter((q) => new RegExp(`^UPDATE \`fmb_${table}\` SET`).test(q.sql));
  // Values keyed by the column bound them, read off the statement — never by
  // position, which shifts the moment a column joins the SET list.
  const boundColumnsOf = (q) => Object.fromEntries(
    [...q.sql.matchAll(/`?([a-z_]+)`?\s*=\s*\?/g)].map((m, i) => [m[1], q.params[i]]),
  );

  beforeEach(() => {
    currentUser = { id: '35001ba8-1475-47d7-8cc5-95adf919682b', role: 'admin' };
    state.fkExists = true;
    state.hostSiteRow = [{ site_id: HOST_DC }];
  });

  it('CREATE: a KVM placed on a host stores that host\'s data centre, not the one named', async () => {
    const res = await request('POST', `/capacity/scenarios/${SCN}/vms`, {
      name: 'kvm1', vm_type: 'ap_host', hypervisor_id: HOST, site_id: OTHER_DC,
    });
    assert.equal(res.status, 200, res.raw);
    const row = synthRowFromInsert(insertsInto('cap_vms')[0].sql, insertsInto('cap_vms')[0].params);
    assert.equal(row.site_id, HOST_DC, 'the create stored the caller\'s data centre over the host\'s');
  });

  it('CREATE: an unplaced KVM keeps the intended data centre the caller named', async () => {
    const res = await request('POST', `/capacity/scenarios/${SCN}/vms`, {
      name: 'kvm1', vm_type: 'ap_host', site_id: OTHER_DC,
    });
    assert.equal(res.status, 200, res.raw);
    const row = synthRowFromInsert(insertsInto('cap_vms')[0].sql, insertsInto('cap_vms')[0].params);
    assert.equal(row.site_id, OTHER_DC, 'an unplaced KVM lost the only statement of where it is meant to go');
  });

  it('UPDATE: a move to another host rewrites the data centre in the SAME statement', async () => {
    const res = await request('PUT', `/capacity/scenarios/${SCN}/vms/${VM}`, { hypervisor_id: HOST });
    assert.equal(res.status, 200, res.raw);
    const bound = boundColumnsOf(updatesTo('cap_vms')[0]);
    assert.equal(bound.hypervisor_id, HOST);
    assert.equal(bound.site_id, HOST_DC, 'the KVM moved data centres and one statement did not say so');
  });

  it('UPDATE: a PUT naming only the data centre cannot move a PLACED KVM', async () => {
    // The per-row gate: the row's own stored placement decides, so a PUT that
    // simply does not mention the host cannot slip past it.
    //
    // THREE DISTINCT IDS, so the assertion says WHERE the written value came
    // from and not merely that the caller's was refused. The row's cache is
    // deliberately neither the caller's value nor the host's: this branch keeps
    // what the row holds, read under the lock it takes anyway, because reaching
    // for the host here would either read a snapshot (the staleness measured in
    // capacity-lock-order-real-db.test.js) or lock `cap_hypervisors` after
    // `cap_vms` and invert the order.
    state.vmStoredHostRow = [{ hypervisor_id: HOST, site_id: STORED_DC }];
    const res = await request('PUT', `/capacity/scenarios/${SCN}/vms/${VM}`, { site_id: OTHER_DC });
    assert.equal(res.status, 200, res.raw);
    assert.equal(
      boundColumnsOf(updatesTo('cap_vms')[0]).site_id, STORED_DC,
      'a plain PUT pinned a placed KVM to a data centre it was not standing in',
    );
    assert.equal(
      state.queries.filter((q) => /FROM `fmb_cap_hypervisors` WHERE id = \? LIMIT 1/.test(q.sql)).length, 0,
      'the branch read the host anyway — the read it must not make is the one that can answer from a snapshot',
    );
  });

  it('UPDATE: an unplaced KVM\'s intended data centre is still settable', async () => {
    // Closing that door on a placed KVM must not close it on the one case where
    // the column IS the answer. `vmStoredHostRow` stays undefined: no host.
    const res = await request('PUT', `/capacity/scenarios/${SCN}/vms/${VM}`, { site_id: OTHER_DC });
    assert.equal(res.status, 200, res.raw);
    assert.equal(boundColumnsOf(updatesTo('cap_vms')[0]).site_id, OTHER_DC);
  });

  it('a host moved to another data centre repins the KVMs standing on it', async () => {
    state.cascadeHostRow = [{ scenario_id: SCN }];
    const res = await request('PUT', `/capacity/scenarios/${SCN}/hypervisors/3bb4a2d0-19a4-4ea3-89e7-32226b5c3e2f`, { site_id: OTHER_DC });
    assert.equal(res.status, 200, res.raw);
    const cascade = state.queries.filter((q) => /^UPDATE `fmb_cap_vms` v\s+JOIN `fmb_cap_hypervisors` h/.test(q.sql));
    assert.equal(cascade.length, 1, 'the host moved and its KVMs were left in the data centre it has left');
    assert.deepEqual(cascade[0].params, [SCN, '3bb4a2d0-19a4-4ea3-89e7-32226b5c3e2f']);
  });

  it('a host edit that does not touch the data centre repins nothing', async () => {
    state.cascadeHostRow = [{ scenario_id: SCN }];
    const res = await request('PUT', `/capacity/scenarios/${SCN}/hypervisors/3bb4a2d0-19a4-4ea3-89e7-32226b5c3e2f`, { name: 'renamed' });
    assert.equal(res.status, 200, res.raw);
    assert.equal(
      state.queries.filter((q) => /^UPDATE `fmb_cap_vms` v\s+JOIN/.test(q.sql)).length, 0,
      'a rename repinned every KVM on the host',
    );
  });
});

// fmb-1685: the renumber apply reads role/{function}/site data UNLOCKED
// (readHostFunctionRoles → cap_db_instances/cap_databases; readSiteNames →
// cap_sites) while holding cap_scenarios FOR UPDATE. Those child mounts' generic
// CREATE/UPDATE path used to take NO scenario lock (only the FK rows in the
// payload), so a role-only db_instance UPDATE — no FK in the body — could commit
// between apply's snapshot and its writes, leaving apply renaming from stale
// placement. makeScenarioRowLock now serialises every field/verb of these mounts
// on the scenario row. Deterministic proof: the write's query trace must carry a
// cap_scenarios FOR UPDATE, and it must come BEFORE both the row UPDATE and any
// §17.1a FK lock (taken first ⇒ no inverting lock-order edge).
describe('fmb-1685 — child write serialises on the scenario row (renumber read-set)', () => {
  const SID = '26895068-65f1-405c-8521-2a9e1212353c';
  const ROW = 'd8de67d9-c84d-4e73-8817-13b2f11c02f7';
  const SCENARIO_LOCK = /SELECT id FROM `fmb_cap_scenarios` WHERE id = \? FOR UPDATE/;

  function idxOf(re) { return state.queries.findIndex((q) => re.test(q.sql)); }

  it('a role-only db_instance PUT locks the scenario row before the UPDATE', async () => {
    const res = await request('PUT', `/capacity/scenarios/${SID}/db_instances/${ROW}`, { role: 'primary' });
    assert.equal(res.status, 200, res.raw);
    const lockIdx = idxOf(SCENARIO_LOCK);
    const updIdx = idxOf(/^UPDATE `fmb_cap_db_instances`/);
    assert.ok(lockIdx !== -1, 'scenario row must be locked FOR UPDATE');
    assert.ok(updIdx !== -1, 'the db_instance UPDATE must run');
    assert.ok(lockIdx < updIdx, 'the scenario lock must precede the UPDATE');
  });

  it('a function-only database PUT locks the scenario row before the UPDATE', async () => {
    const res = await request('PUT', `/capacity/scenarios/${SID}/databases/${ROW}`, { function_name: 'ERP' });
    assert.equal(res.status, 200, res.raw);
    const lockIdx = idxOf(SCENARIO_LOCK);
    const updIdx = idxOf(/^UPDATE `fmb_cap_databases`/);
    assert.ok(lockIdx !== -1 && updIdx !== -1 && lockIdx < updIdx, 'scenario lock precedes the databases UPDATE');
  });

  it('a name-only site PUT locks the scenario row before the UPDATE', async () => {
    const res = await request('PUT', `/capacity/scenarios/${SID}/sites/${ROW}`, { name: 'DC-2' });
    assert.equal(res.status, 200, res.raw);
    const lockIdx = idxOf(SCENARIO_LOCK);
    const updIdx = idxOf(/^UPDATE `fmb_cap_sites`/);
    assert.ok(lockIdx !== -1 && updIdx !== -1 && lockIdx < updIdx, 'scenario lock precedes the sites UPDATE');
  });

  it('the scenario lock is taken BEFORE the §17.1a FK lock on a db_instance vm_id PUT', async () => {
    const res = await request('PUT', `/capacity/scenarios/${SID}/db_instances/${ROW}`, { vm_id: ROW });
    assert.equal(res.status, 200, res.raw);
    const lockIdx = idxOf(SCENARIO_LOCK);
    const fkIdx = state.queries.findIndex((q) => /FROM `fmb_cap_vms`[\s\S]*FOR UPDATE/.test(q.sql));
    assert.ok(lockIdx !== -1, 'scenario row locked');
    assert.ok(fkIdx !== -1, 'cap_vms FK row locked');
    assert.ok(lockIdx < fkIdx, 'scenario lock precedes the FK lock — the universally-first lock adds no inverting edge');
  });
});
