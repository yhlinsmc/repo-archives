/**
 * capacity-io.test.js — Capacity Planner import/export (config-rewrite §17.4,
 * spec §6).
 *
 * Two layers:
 *   1. buildImportPlan (PURE): structural validation + name/ref → id resolution +
 *      catalogue match-to-global-or-create-scenario-local + two-pass rule→rule
 *      override resolution + Exception object_set_key rebuild + cf: metadata
 *      folding + member XOR — no DB (the existing global catalogues are injected).
 *   2. The io.js routes against a mock edge/db: export projection shape +
 *      not-found; import validate (zero writes) / commit (all-or-nothing
 *      replace-all across the 14 SNAPSHOT tables) / permissions / never-block /
 *      oversize.
 * All fixture data is synthetic (CLAUDE.md §8).
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../../../src/edge/db');

let state;
function freshState() {
  return {
    queries: [],
    scenarioExists: true,        // export existence probe (SELECT 1 AS ok)
    scenarioOwner: undefined,    // owner_id for resolveScenarioWriteAccess
    accessRows: undefined,       // set [] to simulate scenario-not-found on import
    scenarioRows: {},            // export snapshot read: { sites:[...], ... }
    globalRows: {},              // existing global catalogue rows (scenario_id IS NULL)
    vanishGlobals: false,        // simulate a concurrent global-catalogue delete (lock probe finds nothing)
    throwOnInsert: false,        // force an INSERT to throw (safeRollback path)
  };
}

const conn = {
  async beginTransaction() {},
  async commit() {},
  async rollback() {},
  release() {},
  async query(sql, params = []) {
    state.queries.push({ sql, params });

    if (/SELECT 1 AS ok FROM `fmb_cap_scenarios` WHERE id = \?/.test(sql)) {
      return state.scenarioExists ? [{ ok: 1 }] : [];
    }
    if (/SELECT id, owner_id FROM `fmb_cap_scenarios` WHERE id = \? FOR UPDATE/.test(sql)) {
      return state.accessRows !== undefined
        ? state.accessRows
        : [{ id: params[0], owner_id: state.scenarioOwner }];
    }
    // Commit lock probe (io.js lockReferencedGlobals): SELECT id ... WHERE
    // scenario_id IS NULL AND id IN (...) FOR UPDATE. Every requested id is
    // present unless vanishGlobals simulates a concurrent delete.
    if (/SELECT id FROM `fmb_cap_[a-z_]+` WHERE scenario_id IS NULL AND id IN \([^)]*\) FOR UPDATE/.test(sql)) {
      return state.vanishGlobals ? [] : params.map((id) => ({ id }));
    }
    // Existing-global fetch for import match-first resolution (io.js fetchExistingGlobals).
    const globals = sql.match(/FROM `fmb_cap_([a-z_]+)` WHERE scenario_id IS NULL\s*$/);
    if (globals) return state.globalRows[globals[1]] || [];
    // Export snapshot read (buildScenarioSnapshotDoc).
    const scoped = sql.match(/^SELECT \* FROM `fmb_cap_([a-z_]+)` WHERE scenario_id = \?\s*$/);
    if (scoped) return state.scenarioRows[scoped[1]] || [];
    if (/^INSERT INTO/.test(sql)) {
      if (state.throwOnInsert) throw new Error('synthetic insert failure');
      return { affectedRows: 1, insertId: 1 };
    }
    if (/^DELETE/.test(sql)) return { affectedRows: 1 };
    return [];
  },
};

const poolFacade = {
  getConnection: async () => conn,
  query: (sql, params) => conn.query(sql, params),
};
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: { ro: poolFacade, rw: poolFacade }, t: (n) => `fmb_${n}` },
};

const ioRouter = require('../../../../src/edge/routes/app/capacity/io');
const { buildImportPlan, importPayloadTooLarge, SCENARIO_SPECS } = ioRouter;
const { objectSetKey } = require('../../../../src/shared/capacity/evaluator');
const { SNAPSHOT_TABLES } = require('../../../../src/edge/routes/app/capacity/_shared');
const { compareCatalogueTable } = require('../../../../src/edge/routes/app/capacity/reference-integrity');

// ── Lock-order deadlock guard: io.js import commit vs reference-integrity canon ──
// The import commit (lockReferencedGlobals) and every checkReferences(lock:true)
// caller (wizard / bundles / the new children preWriteInTx) MUST acquire per-table
// FOR-UPDATE locks in the SAME order or two concurrent lockers touching the same
// global rows deadlock. Both now share compareCatalogueTable — prove the import
// commit consumes it (not CATALOGUE_KEY_TABLE's raw declaration order).
describe('lockReferencedGlobals: canonical lock order (security M-1 deadlock guard)', () => {
  it('locks catalogue tables in the shared canonical (table-name-sorted) order, not declaration order', async () => {
    const { lockReferencedGlobals, CATALOGUE_KEY_TABLE } = ioRouter;
    const seen = [];
    const lockConn = {
      async query(sql, params) {
        seen.push(sql.match(/FROM `([^`]+)`/)[1]);
        return params.map((id) => ({ id })); // every referenced row present
      },
    };
    // Reference an id in EVERY catalogue table so all are locked in one commit.
    const refIds = {};
    for (const key of Object.keys(CATALOGUE_KEY_TABLE)) refIds[key] = ['x'];
    const vanished = await lockReferencedGlobals(lockConn, refIds);
    assert.equal(vanished, null, 'every referenced global present → no vanished key');

    const physical = (tbl) => `fmb_${tbl}`;
    const canonical = Object.values(CATALOGUE_KEY_TABLE).map(physical).sort(compareCatalogueTable);
    assert.deepEqual(seen, canonical, 'import commit locks in the shared canonical order');
    // The canonical order MUST differ from raw declaration order (three pairs are
    // reversed) — proving the sort is load-bearing, not a no-op.
    const declaration = Object.values(CATALOGUE_KEY_TABLE).map(physical);
    assert.notDeepEqual(seen, declaration, 'canonical order is NOT the declaration order (the bug this guards)');
  });
});

let currentUser; let server; let baseUrl;
before(async () => {
  const app = express();
  app.use(express.json({ limit: '6mb' })); // above the 4 MB import cap so the route's own guard trips first
  app.use((req, _res, next) => { req.user = currentUser; next(); });
  app.use('/capacity', ioRouter);
  server = http.createServer(app);
  await new Promise((r) => server.listen(0, r));
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});
after(() => server && server.close());
beforeEach(() => {
  state = freshState();
  currentUser = { id: 'u-admin', role: 'admin' };
});

function request(method, path, body) {
  return new Promise((resolve, reject) => {
    const payload = body === undefined ? '' : JSON.stringify(body);
    const r = http.request(
      `${baseUrl}${path}`,
      { method, headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) } },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          const raw = Buffer.concat(chunks).toString('utf8');
          let json = null;
          try { json = JSON.parse(raw); } catch { /* noop */ }
          resolve({ status: res.statusCode, json, raw });
        });
      },
    );
    r.on('error', reject);
    if (payload) r.write(payload);
    r.end();
  });
}

const inserts = () => state.queries.filter((q) => /^INSERT INTO/.test(q.sql));
const deletes = () => state.queries.filter((q) => /^DELETE/.test(q.sql));

// Value of a named column in an INSERT query (parses the `(cols) VALUES` list).
function insertColVal(q, col) {
  const cols = q.sql.match(/\(([^)]*)\) VALUES/)[1].split(',').map((c) => c.trim().replace(/`/g, ''));
  const idx = cols.indexOf(col);
  return idx === -1 ? undefined : q.params[idx];
}
const insertsFor = (table) => inserts().filter((q) => new RegExp(`^INSERT INTO \`fmb_${table}\``).test(q.sql));

// A fully-valid, self-referential scenario sheet set that round-trips every
// scenario entity kind (new schema). No existing globals injected → every
// catalogue row is created scenario-local (unmatched).
function validSheets() {
  return {
    hardware_specs: [{ name: 'Spec-A', cpu_total: 64, mem_total_gb: 1280, disk_total_gb: 10000 }],
    disk_combos: [{ name: '2x512', sizes: [512, 512] }],
    teams: [{ name: 'Payments', color: '#3366cc' }],
    vm_profiles: [{ class: 'DB', name: 'DB-Large', mode: 'custom', cpu: 16, mem_gb: 128, sga_cap_gb: 60 }],
    settings: [{ mem_cpu_ratio: 20, sga_factor: 0.982, sga_divisor: 2, sga_subtract: 2, util_amber_pct: 80, util_red_pct: 90, overcommit_default_enabled: false }],
    rules: [{ type: 'keep-apart', name: 'AC', level: 'db_instance', group_by: 'each_primary_cluster', severity: 'hard', enabled: true }],
    sites: [{ name: 'DC-1' }],
    hypervisors: [{ name: 'HV-1', site_name: 'DC-1', spec_name: 'Spec-A' }],
    databases: [{ function_name: 'erp', topology: 'primary_standby', profile_name: 'DB-Large', team_name: 'Payments' }],
    vms: [{ name: 'VM-1', vm_type: 'db_host', hypervisor_name: 'HV-1', profile_name: 'DB-Large', team_name: 'Payments', database_name: 'erp', cpu: 16, mem_gb: 128, disk_gb: 500, 'cf:tier': 'gold' }],
    db_instances: [{ name: 'erp', vm_name: 'VM-1', database_name: 'erp', role: 'primary', sga_gb: 64 }],
    custom_groups: [{ name: 'Critical', team_name: 'Payments' }],
    custom_group_members: [{ group_name: 'Critical', member_vm_name: 'VM-1' }],
    waivers: [{ rule_name: 'AC', object_names: 'HV-1|VM-1', note: 'accepted' }],
  };
}

// ── 1. buildImportPlan — pure validation + resolution ──────────────────────────
describe('buildImportPlan: happy path resolves names → ids', () => {
  it('a fully valid sheet set is ok and resolves every FK by name', () => {
    const plan = buildImportPlan(validSheets(), 'u-ed');
    assert.equal(plan.ok, true, JSON.stringify(plan.errors));
    const hv = plan.plan.hypervisors[0];
    assert.equal(hv.dbRow.site_id, plan.plan.sites[0].id);
    assert.equal(hv.dbRow.spec_id, plan.plan.hardware_specs[0].id);
    const vm = plan.plan.vms[0];
    assert.equal(vm.dbRow.hypervisor_id, plan.plan.hypervisors[0].id);
    assert.equal(vm.dbRow.sizing_profile_id, plan.plan.vm_profiles[0].id);
    assert.equal(vm.dbRow.team_id, plan.plan.teams[0].id);
    assert.equal(vm.dbRow.database_id, plan.plan.databases[0].id);
    assert.equal(plan.plan.db_instances[0].dbRow.vm_id, vm.id);
    assert.equal(plan.plan.custom_group_members[0].dbRow.group_id, plan.plan.custom_groups[0].id);
    assert.equal(plan.plan.custom_group_members[0].dbRow.member_vm_id, vm.id);
  });

  it('folds cf: columns into metadata JSON (null-prototype build)', () => {
    const plan = buildImportPlan(validSheets(), 'u-ed');
    assert.equal(plan.ok, true);
    assert.deepEqual(JSON.parse(plan.plan.vms[0].dbRow.metadata), { tier: 'gold' });
  });

  it('rebuilds the Exception object_set_key from resolved ids exactly as the evaluator does', () => {
    const plan = buildImportPlan(validSheets(), 'u-ed');
    assert.equal(plan.ok, true);
    const hvId = plan.plan.hypervisors[0].id;
    const vmId = plan.plan.vms[0].id;
    const w = plan.plan.waivers[0].dbRow;
    assert.equal(w.object_set_key, objectSetKey([hvId, vmId]));
    assert.equal(w.rule_id, plan.plan.rules[0].id);
    assert.equal(w.created_by, 'u-ed', 'created_by is server-stamped, never from the file');
  });

  it('the plan carries a key for every SNAPSHOT table (delete set == insert set — data-loss regression guard)', () => {
    const plan = buildImportPlan(validSheets(), 'u-ed');
    const planKeys = Object.keys(plan.plan).sort();
    const snapshotKeys = SNAPSHOT_TABLES.map((s) => s.key).sort();
    assert.deepEqual(planKeys, snapshotKeys, 'every scenario-scoped table the DELETE loop clears is re-populatable by the INSERT loop');
    assert.deepEqual(SCENARIO_SPECS.map((s) => s.key).sort(), snapshotKeys, 'SCENARIO_SPECS mirrors SNAPSHOT_TABLES');
  });
});

// ── 2. Catalogue match-to-global vs create scenario-local (§17.4) ──────────────
describe('buildImportPlan: catalogue reference resolves ref-first / name-fallback against existing globals', () => {
  const globals = {
    hardware_specs: [{ id: 'GID-spec', name: 'Spec-A' }],
    vm_profiles: [{ id: 'GID-prof', name: 'DB-Large' }],
    disk_combos: [], teams: [], rules: [], settings: [],
  };

  it('a catalogue row matching an existing global by name is NOT re-inserted; the scenario FK points at the global id', () => {
    const s = {
      hardware_specs: [{ name: 'Spec-A' }],
      sites: [{ name: 'DC' }],
      hypervisors: [{ name: 'HV-1', site_name: 'DC', spec_name: 'Spec-A' }],
    };
    const plan = buildImportPlan(s, 'u', globals);
    assert.equal(plan.ok, true, JSON.stringify(plan.errors));
    assert.equal(plan.plan.hardware_specs.length, 0, 'matched global is not re-created scenario-local');
    assert.equal(plan.plan.hypervisors[0].dbRow.spec_id, 'GID-spec');
  });

  it('an UNMATCHED catalogue row is created scenario-local; the scenario FK points at the minted id', () => {
    const s = {
      hardware_specs: [{ name: 'Spec-NEW' }],
      sites: [{ name: 'DC' }],
      hypervisors: [{ name: 'HV-1', site_name: 'DC', spec_name: 'Spec-NEW' }],
    };
    const plan = buildImportPlan(s, 'u', globals);
    assert.equal(plan.ok, true, JSON.stringify(plan.errors));
    assert.equal(plan.plan.hardware_specs.length, 1, 'unmatched → created scenario-local');
    assert.equal(plan.plan.hardware_specs[0].id, plan.plan.hypervisors[0].dbRow.spec_id);
  });

  it('ref-first wins: a spec_ref pointing at a global id resolves to that global even when a same-named local exists', () => {
    const s = {
      hardware_specs: [{ name: 'Spec-A', ref: 'GID-spec' }],
      hypervisors: [{ name: 'HV-1', site_name: 'DC', spec_ref: 'GID-spec' }],
      sites: [{ name: 'DC' }],
    };
    const plan = buildImportPlan(s, 'u', globals);
    assert.equal(plan.ok, true, JSON.stringify(plan.errors));
    assert.equal(plan.plan.hardware_specs.length, 0);
    assert.equal(plan.plan.hypervisors[0].dbRow.spec_id, 'GID-spec');
  });
});

// ── 2b. Scope marker keeps scenario-local content local (P1) ───────────────────
describe('buildImportPlan: scope marker (§17.4 local vs global)', () => {
  const globals = {
    hardware_specs: [{ id: 'GID', name: 'Spec-A' }],
    vm_profiles: [], disk_combos: [], teams: [], rules: [], settings: [],
  };

  it('a scope=local catalogue row name-colliding with a global stays scenario-local; the referrer points at it', () => {
    const s = {
      hardware_specs: [{ name: 'Spec-A', scope: 'local', ref: 'localspec' }],
      sites: [{ name: 'DC' }],
      hypervisors: [{ name: 'HV', site_name: 'DC', spec_ref: 'localspec' }],
    };
    const plan = buildImportPlan(s, 'u', globals);
    assert.equal(plan.ok, true, JSON.stringify(plan.errors));
    assert.equal(plan.plan.hardware_specs.length, 1, 'the local row is inserted, not dropped');
    assert.equal(plan.plan.hypervisors[0].dbRow.spec_id, plan.plan.hardware_specs[0].id, 'referrer points at the new local id');
    assert.notEqual(plan.plan.hypervisors[0].dbRow.spec_id, 'GID', 'referrer must NOT repoint to the global');
  });

  it('a scope=global row still resolves to the existing global (not re-created)', () => {
    const s = {
      hardware_specs: [{ name: 'Spec-A', scope: 'global' }],
      sites: [{ name: 'DC' }],
      hypervisors: [{ name: 'HV', site_name: 'DC', spec_name: 'Spec-A' }],
    };
    const plan = buildImportPlan(s, 'u', globals);
    assert.equal(plan.ok, true, JSON.stringify(plan.errors));
    assert.equal(plan.plan.hardware_specs.length, 0);
    assert.equal(plan.plan.hypervisors[0].dbRow.spec_id, 'GID');
  });

  it('a scope-less row that name-matches a global is reused but flagged ASSUMED_GLOBAL_SCOPE (notice)', () => {
    const plan = buildImportPlan({ hardware_specs: [{ name: 'Spec-A' }] }, 'u', globals);
    assert.equal(plan.plan.hardware_specs.length, 0, 'assumed global → reused');
    assert.ok(plan.notices.some((n) => n.code === 'ASSUMED_GLOBAL_SCOPE' && n.sheet === 'hardware_specs'));
  });

  it('an empty-string scope cell is treated as absent (ASSUMED_GLOBAL_SCOPE), not INVALID_SCOPE', () => {
    const plan = buildImportPlan({ hardware_specs: [{ name: 'Spec-A', scope: '' }] }, 'u', globals);
    assert.equal(plan.ok, true, JSON.stringify(plan.errors));
    assert.ok(plan.notices.some((n) => n.code === 'ASSUMED_GLOBAL_SCOPE' && n.sheet === 'hardware_specs'));
  });

  it('"Local" (mixed case) and " local " (whitespace) normalize to local — no fallback to global name-matching', () => {
    for (const raw of ['Local', ' local ', 'LOCAL', '  Global  ', 'GLOBAL']) {
      const s = {
        hardware_specs: [{ name: 'Spec-A', scope: raw, ref: 'localspec' }],
        sites: [{ name: 'DC' }],
        hypervisors: [{ name: 'HV', site_name: 'DC', spec_ref: 'localspec' }],
      };
      const plan = buildImportPlan(s, 'u', globals);
      assert.equal(plan.ok, true, `${JSON.stringify(raw)}: ${JSON.stringify(plan.errors)}`);
      const isLocal = raw.trim().toLowerCase() === 'local';
      assert.equal(plan.plan.hardware_specs.length, isLocal ? 1 : 0, `scope=${JSON.stringify(raw)}`);
    }
  });

  it('a malformed scope value on a name-colliding row is a structural error, never a silent repoint to the global', () => {
    const s = {
      hardware_specs: [{ name: 'Spec-A', scope: 'loal', ref: 'localspec' }],
      sites: [{ name: 'DC' }],
      hypervisors: [{ name: 'HV', site_name: 'DC', spec_ref: 'localspec' }],
    };
    const plan = buildImportPlan(s, 'u', globals);
    assert.equal(plan.ok, false);
    assert.ok(plan.errors.some((e) => e.sheet === 'hardware_specs' && e.column === 'scope' && e.code === 'INVALID_SCOPE'));
    // No ASSUMED_GLOBAL_SCOPE notice either — an invalid value is never silently
    // treated as "absent → assumed global"; it is flagged and blocks commit.
    assert.ok(!plan.notices.some((n) => n.code === 'ASSUMED_GLOBAL_SCOPE'));
  });

  it('a malformed scope value on a name-colliding rules row is a structural error and is never name-matched to the global rule', () => {
    const rulesGlobals = { ...globals, rules: [{ id: 'GRULE-1', name: 'No oversell' }] };
    const s = {
      rules: [{ type: 'no-oversell', name: 'No oversell', level: 'hypervisor', group_by: 'all_of_type', scope: 'loal' }],
    };
    const plan = buildImportPlan(s, 'u', rulesGlobals);
    assert.equal(plan.ok, false);
    assert.ok(plan.errors.some((e) => e.sheet === 'rules' && e.column === 'scope' && e.code === 'INVALID_SCOPE'));
    // Excluded from fallback matching: the row is inserted scenario-local under
    // its own minted id, never resolved to the name-colliding global rule.
    assert.equal(plan.plan.rules.length, 1, 'the row is inserted scenario-local, not matched');
    assert.notEqual(plan.plan.rules[0].id, 'GRULE-1');
    assert.ok(!plan.notices.some((n) => n.code === 'ASSUMED_GLOBAL_SCOPE'));
  });

  it('a malformed scope value on a value-equal settings row is a structural error and is never skipped as matching the global', () => {
    const globalSettings = [{ id: 'GS', mem_cpu_ratio: 20, sga_factor: 0.982, sga_divisor: 2, sga_subtract: 2, util_amber_pct: 80, util_red_pct: 90, overcommit_default_enabled: 0, layer_defaults: null }];
    const plan = buildImportPlan(
      { settings: [{ scope: 'loal', mem_cpu_ratio: 20, sga_factor: 0.982, sga_divisor: 2, sga_subtract: 2, util_amber_pct: 80, util_red_pct: 90, overcommit_default_enabled: false }] },
      'u', { settings: globalSettings, hardware_specs: [], vm_profiles: [], disk_combos: [], teams: [], rules: [] },
    );
    assert.equal(plan.ok, false);
    assert.ok(plan.errors.some((e) => e.sheet === 'settings' && e.column === 'scope' && e.code === 'INVALID_SCOPE'));
    // Excluded from the value-equality skip: the row is still built as an
    // override candidate, never silently treated as matching the global.
    assert.equal(plan.plan.settings.length, 1, 'value-equality skip never runs for an invalid scope value');
  });

  it('a scope=local settings row is written as an override even when value-equal to the global', () => {
    const globalSettings = [{ id: 'GS', mem_cpu_ratio: 20, sga_factor: 0.982, sga_divisor: 2, sga_subtract: 2, util_amber_pct: 80, util_red_pct: 90, overcommit_default_enabled: 0, layer_defaults: null }];
    const plan = buildImportPlan(
      { settings: [{ scope: 'local', mem_cpu_ratio: 20, sga_factor: 0.982, sga_divisor: 2, sga_subtract: 2, util_amber_pct: 80, util_red_pct: 90, overcommit_default_enabled: false }] },
      'u', { settings: globalSettings, hardware_specs: [], vm_profiles: [], disk_combos: [], teams: [], rules: [] },
    );
    assert.equal(plan.ok, true, JSON.stringify(plan.errors));
    assert.equal(plan.plan.settings.length, 1, 'scope=local forces an override even at global values');
  });
});

// ── 2c. allowed_disk_combos remap (P2) ─────────────────────────────────────────
describe('buildImportPlan: vm_profiles.allowed_disk_combos remap', () => {
  it('a scenario-local profile allow-list is remapped to the resolved disk-combo ids', () => {
    const s = {
      disk_combos: [{ name: '2x512', scope: 'local', ref: 'dc-ref' }],
      vm_profiles: [{ class: 'DB', name: 'P', scope: 'local', allowed_disk_combos: ['dc-ref'] }],
    };
    const plan = buildImportPlan(s, 'u');
    assert.equal(plan.ok, true, JSON.stringify(plan.errors));
    const dcId = plan.plan.disk_combos[0].id;
    assert.deepEqual(JSON.parse(plan.plan.vm_profiles[0].dbRow.allowed_disk_combos), [dcId]);
  });

  it('remaps to a global-matched disk combo when the allow-list points at one', () => {
    const globals = { disk_combos: [{ id: 'GDC', name: '2x512' }], hardware_specs: [], vm_profiles: [], teams: [], rules: [], settings: [] };
    const s = {
      disk_combos: [{ name: '2x512', scope: 'global', ref: 'gref' }],
      vm_profiles: [{ class: 'DB', name: 'P', scope: 'local', allowed_disk_combos: ['gref'] }],
    };
    const plan = buildImportPlan(s, 'u', globals);
    assert.equal(plan.ok, true, JSON.stringify(plan.errors));
    assert.deepEqual(JSON.parse(plan.plan.vm_profiles[0].dbRow.allowed_disk_combos), ['GDC']);
  });

  it('an allow-list id not present in the import is a readable structural error, not a silent drop', () => {
    const s = { vm_profiles: [{ class: 'DB', name: 'P', scope: 'local', allowed_disk_combos: ['ghost'] }] };
    const plan = buildImportPlan(s, 'u');
    assert.equal(plan.ok, false);
    assert.ok(plan.errors.some((e) => e.column === 'allowed_disk_combos' && e.code === 'UNRESOLVED_REF'));
  });

  it('a matched-GLOBAL profile is not re-created and its allow-list is left untouched', () => {
    const globals = { vm_profiles: [{ id: 'GP', name: 'P' }], disk_combos: [], hardware_specs: [], teams: [], rules: [], settings: [] };
    const s = { vm_profiles: [{ class: 'DB', name: 'P', scope: 'global', allowed_disk_combos: ['whatever'] }] };
    const plan = buildImportPlan(s, 'u', globals);
    assert.equal(plan.ok, true, JSON.stringify(plan.errors));
    assert.equal(plan.plan.vm_profiles.length, 0, 'matched global profile not re-created; its allow-list is irrelevant');
  });
});

// ── 2d. TA.2 disk-combo allow-list on the import commit path (spec §5.3) ────────
// The import commit is a profile+disk-pair write path; it must honor the SAME
// allow-list invariant the wizard / child writes do. Surfaced as a structural
// validation error (report-integrated) so validate/dry-run predicts commit and a
// same-workbook LOCAL profile is covered from the plan.
describe('buildImportPlan: disk-combo allow-list on resulting scenario rows (§5.3)', () => {
  const localAllowSheets = (extra) => ({
    disk_combos: [
      { name: 'OkCombo', scope: 'local', ref: 'ok', sizes: [512] },
      { name: 'BadCombo', scope: 'local', ref: 'bad', sizes: [1024] },
    ],
    vm_profiles: [{ class: 'DB', name: 'P', scope: 'local', mode: 'custom', cpu: 8, mem_gb: 64, sga_cap_gb: 40, allowed_disk_combos: ['ok'] }],
    ...extra,
  });

  it('a vms row pairing a profile with a DISALLOWED combo → DISK_COMBO_NOT_ALLOWED (blocks commit)', () => {
    const plan = buildImportPlan(localAllowSheets({
      vms: [{ name: 'VM-1', vm_type: 'db_host', profile_name: 'P', disk_combo_name: 'BadCombo' }],
    }), 'u');
    assert.equal(plan.ok, false);
    const err = plan.errors.find((e) => e.code === 'DISK_COMBO_NOT_ALLOWED');
    assert.ok(err, JSON.stringify(plan.errors));
    assert.equal(err.sheet, 'vms');
  });

  it('a databases row pairing a profile with a DISALLOWED combo → DISK_COMBO_NOT_ALLOWED', () => {
    const plan = buildImportPlan(localAllowSheets({
      databases: [{ function_name: 'erp', topology: 'single', profile_name: 'P', disk_combo_name: 'BadCombo' }],
    }), 'u');
    assert.equal(plan.ok, false);
    const err = plan.errors.find((e) => e.code === 'DISK_COMBO_NOT_ALLOWED');
    assert.ok(err, JSON.stringify(plan.errors));
    assert.equal(err.sheet, 'databases');
  });

  it('a vms row pairing a profile with an ALLOWED combo passes', () => {
    const plan = buildImportPlan(localAllowSheets({
      vms: [{ name: 'VM-1', vm_type: 'db_host', profile_name: 'P', disk_combo_name: 'OkCombo' }],
    }), 'u');
    assert.equal(plan.ok, true, JSON.stringify(plan.errors));
  });

  it('a Custom (no-profile) vms row carrying any combo passes (no pair)', () => {
    const plan = buildImportPlan(localAllowSheets({
      vms: [{ name: 'VM-1', vm_type: 'ap_host', disk_combo_name: 'BadCombo' }],
    }), 'u');
    assert.equal(plan.ok, true, JSON.stringify(plan.errors));
  });

  it('validates against a MATCHED-GLOBAL profile allow-list too (fetchExistingGlobals path)', () => {
    const globals = {
      vm_profiles: [{ id: 'GP', name: 'GProf', allowed_disk_combos: JSON.stringify(['GDC-ok']) }],
      disk_combos: [{ id: 'GDC-ok', name: 'OkG' }, { id: 'GDC-bad', name: 'BadG' }],
      hardware_specs: [], teams: [], rules: [], settings: [],
    };
    const s = {
      disk_combos: [{ name: 'OkG', scope: 'global', ref: 'GDC-ok' }, { name: 'BadG', scope: 'global', ref: 'GDC-bad' }],
      vm_profiles: [{ name: 'GProf', scope: 'global', ref: 'GP', class: 'DB' }],
      vms: [{ name: 'VM-1', vm_type: 'db_host', profile_name: 'GProf', disk_combo_name: 'BadG' }],
    };
    const plan = buildImportPlan(s, 'u', globals);
    assert.equal(plan.ok, false);
    assert.ok(plan.errors.some((e) => e.code === 'DISK_COMBO_NOT_ALLOWED' && e.sheet === 'vms'), JSON.stringify(plan.errors));
  });
});

// ── 3. Rules: match-to-global, override resolution, strictType ─────────────────
describe('buildImportPlan: rule override resolution (§17.1a global-row target)', () => {
  const globals = {
    hardware_specs: [], vm_profiles: [], disk_combos: [], teams: [], settings: [],
    rules: [{ id: 'GRULE-1', name: 'No oversell' }],
  };

  it('a plain rule matching a global template is NOT re-created; an override row targets its global id', () => {
    const s = {
      rules: [
        { type: 'no-oversell', name: 'No oversell', level: 'hypervisor', group_by: 'all_of_type' },
        { type: 'no-oversell', name: 'My override', level: 'hypervisor', group_by: 'all_of_type', overrides_rule_name: 'No oversell' },
      ],
    };
    const plan = buildImportPlan(s, 'u', globals);
    assert.equal(plan.ok, true, JSON.stringify(plan.errors));
    assert.equal(plan.plan.rules.length, 1, 'only the override row is inserted scenario-local');
    assert.equal(plan.plan.rules[0].dbRow.overrides_rule_id, 'GRULE-1');
  });

  it('an override targeting a NON-global (scenario-local) rule is rejected (§17.1a global-row)', () => {
    const s = {
      rules: [
        { type: 'no-oversell', name: 'Local A', level: 'hypervisor', group_by: 'all_of_type' },
        { type: 'no-oversell', name: 'Ov', level: 'hypervisor', group_by: 'all_of_type', overrides_rule_name: 'Local A' },
      ],
    };
    const plan = buildImportPlan(s, 'u', globals);
    assert.equal(plan.ok, false);
    assert.ok(plan.errors.some((e) => e.code === 'INVALID_REFERENCE' && e.column === 'overrides_rule_name'));
  });

  it('strictType is ON: a rule type outside the six keepers is a structural error', () => {
    const plan = buildImportPlan({ rules: [{ type: 'anti-colocation', name: 'X', level: 'db_instance' }] }, 'u', globals);
    assert.equal(plan.ok, false);
    assert.ok(plan.errors.some((e) => e.sheet === 'rules' && e.code === 'INVALID_ENUM' && e.column === 'type'));
  });

  it('a per-type illegal level is rejected (validateRuleWritePayload, strictType)', () => {
    const plan = buildImportPlan({ rules: [{ type: 'no-oversell', name: 'X', level: 'db_instance', group_by: 'all_of_type' }] }, 'u', globals);
    assert.equal(plan.ok, false);
    assert.ok(plan.errors.some((e) => e.code === 'INVALID_LEVEL'));
  });

  it('two rows overriding the SAME global rule is a structural error (uq_cap_rules_override backstop)', () => {
    const s = {
      rules: [
        { type: 'no-oversell', name: 'No oversell', level: 'hypervisor', group_by: 'all_of_type' },
        { type: 'no-oversell', name: 'Ov A', level: 'hypervisor', group_by: 'all_of_type', overrides_rule_name: 'No oversell' },
        { type: 'no-oversell', name: 'Ov B', level: 'hypervisor', group_by: 'all_of_type', overrides_rule_name: 'No oversell' },
      ],
    };
    const plan = buildImportPlan(s, 'u', globals);
    assert.equal(plan.ok, false);
    assert.ok(plan.errors.some((e) => e.code === 'DUPLICATE_OVERRIDE'));
  });

  it('two overrides targeting DISTINCT global rules are fine', () => {
    const twoGlobals = { ...globals, rules: [{ id: 'G1', name: 'R1' }, { id: 'G2', name: 'R2' }] };
    const s = {
      rules: [
        { type: 'no-oversell', name: 'R1', level: 'hypervisor', group_by: 'all_of_type' },
        { type: 'max-vms-per-host', name: 'R2', level: 'hypervisor', group_by: 'all_of_type' },
        { type: 'no-oversell', name: 'Ov1', level: 'hypervisor', group_by: 'all_of_type', overrides_rule_name: 'R1' },
        { type: 'max-vms-per-host', name: 'Ov2', level: 'hypervisor', group_by: 'all_of_type', overrides_rule_name: 'R2' },
      ],
    };
    const plan = buildImportPlan(s, 'u', twoGlobals);
    assert.equal(plan.ok, true, JSON.stringify(plan.errors));
    assert.equal(plan.plan.rules.length, 2, 'both distinct overrides inserted');
  });
});

describe('buildImportPlan: per-sheet row cap (DoS backstop)', () => {
  it('a sheet over the 10,000-row cap is a structural error, not a 500', () => {
    const rows = Array.from({ length: 10001 }, (_, i) => ({ name: `DC-${i}` }));
    const plan = buildImportPlan({ sites: rows }, 'u');
    assert.equal(plan.ok, false);
    assert.ok(plan.errors.some((e) => e.sheet === 'sites' && e.code === 'TOO_MANY_ROWS'));
  });

  it('a sheet at exactly the cap is accepted', () => {
    const rows = Array.from({ length: 10000 }, (_, i) => ({ name: `DC-${i}` }));
    const plan = buildImportPlan({ sites: rows }, 'u');
    assert.equal(plan.ok, true, JSON.stringify(plan.errors.slice(0, 2)));
  });
});

// ── 4. Structural error cases (never-block: rules are irrelevant here) ─────────
describe('buildImportPlan: structural error cases', () => {
  it('unresolved reference — 0 matches', () => {
    const s = { hypervisors: [{ name: 'HV-1', site_name: 'GHOST', spec_name: 'Spec-A' }], hardware_specs: [{ name: 'Spec-A' }], sites: [] };
    const plan = buildImportPlan(s, 'u-ed');
    assert.equal(plan.ok, false);
    assert.ok(plan.errors.some((e) => e.sheet === 'hypervisors' && e.column === 'site_name' && e.code === 'UNRESOLVED_REF'));
  });

  it('a name referenced ambiguously (≥2 same-named targets, no ref) is an error — the duplicate name itself is NOT', () => {
    const s = {
      sites: [{ name: 'DC' }, { name: 'DC' }],
      hardware_specs: [{ name: 'Spec-A' }],
      hypervisors: [{ name: 'HV-1', site_name: 'DC', spec_name: 'Spec-A' }],
    };
    const plan = buildImportPlan(s, 'u-ed');
    assert.equal(plan.ok, false);
    assert.equal(plan.errors.some((e) => e.code === 'DUPLICATE_NAME'), false);
    assert.ok(plan.errors.some((e) => e.sheet === 'hypervisors' && e.column === 'site_name' && e.code === 'UNRESOLVED_REF' && /2/.test(e.message)));
  });

  it('bad enum value', () => {
    const plan = buildImportPlan({ vms: [{ name: 'V', vm_type: 'bogus' }] }, 'u-ed');
    assert.equal(plan.ok, false);
    assert.ok(plan.errors.some((e) => e.column === 'vm_type' && e.code === 'INVALID_ENUM'));
  });

  it('bad number value', () => {
    const plan = buildImportPlan({ hardware_specs: [{ name: 'S', cpu_total: 'abc' }] }, 'u-ed');
    assert.equal(plan.ok, false);
    assert.ok(plan.errors.some((e) => e.column === 'cpu_total' && e.code === 'INVALID_NUMBER'));
  });

  it('missing required field, reported on the 1-based file row (header = row 1)', () => {
    const plan = buildImportPlan({ sites: [{}] }, 'u-ed');
    assert.equal(plan.ok, false);
    const err = plan.errors.find((e) => e.sheet === 'sites' && e.code === 'MISSING_FIELD' && e.column === 'name');
    assert.ok(err);
    assert.equal(err.row, 2, 'first data row is file row 2');
  });

  it('unknown column is rejected', () => {
    const plan = buildImportPlan({ sites: [{ name: 'X', bogus: 1 }] }, 'u-ed');
    assert.equal(plan.ok, false);
    assert.ok(plan.errors.some((e) => e.column === 'bogus' && e.code === 'UNKNOWN_COLUMN'));
  });

  it('reserved cf: key (prototype-pollution vector) is rejected', () => {
    const plan = buildImportPlan({ sites: [{ name: 'X', 'cf:__proto__': 'evil' }] }, 'u-ed');
    assert.equal(plan.ok, false);
    assert.ok(plan.errors.some((e) => e.code === 'RESERVED_FIELD_KEY'));
    assert.equal({}.evil, undefined, 'Object.prototype was not polluted');
  });

  it('reserved key in an EXPLICIT metadata cell (prototype-pollution vector) is rejected', () => {
    // A crafted metadata cell (string form, as an xlsx cell arrives) whose parsed
    // object carries an own __proto__ key must be a structural error too — the cf:
    // loop already rejected these, the explicit-metadata branch now mirrors it.
    const plan = buildImportPlan({ sites: [{ name: 'X', metadata: '{"__proto__": 1}' }] }, 'u-ed');
    assert.equal(plan.ok, false);
    assert.ok(plan.errors.some((e) => e.code === 'RESERVED_FIELD_KEY'), 'reserved metadata key must be a structural error');
    assert.equal({}.polluted, undefined, 'Object.prototype was not polluted');
  });

  it('a plain metadata cell with ordinary keys still folds through', () => {
    const plan = buildImportPlan({ sites: [{ name: 'X', metadata: '{"region": "eu"}' }] }, 'u-ed');
    assert.equal(plan.ok, true, JSON.stringify(plan.errors));
    assert.deepEqual(JSON.parse(plan.plan.sites[0].dbRow.metadata), { region: 'eu' });
  });

  it('more than one settings OVERRIDE row is rejected (singleton)', () => {
    const plan = buildImportPlan({ settings: [{ mem_cpu_ratio: 1 }, { mem_cpu_ratio: 2 }] }, 'u-ed');
    assert.equal(plan.ok, false);
    assert.ok(plan.errors.some((e) => e.sheet === 'settings' && e.code === 'DUPLICATE'));
  });

  it('a custom group member set to BOTH a vm and an instance is rejected (XOR)', () => {
    const s = {
      custom_groups: [{ name: 'G' }],
      vms: [{ name: 'V', vm_type: 'db_host' }],
      db_instances: [{ name: 'D', role: 'primary', vm_name: 'V' }],
      custom_group_members: [{ group_name: 'G', member_vm_name: 'V', member_instance_name: 'D' }],
    };
    const plan = buildImportPlan(s, 'u-ed');
    assert.equal(plan.ok, false);
    assert.ok(plan.errors.some((e) => e.sheet === 'custom_group_members' && e.code === 'INVALID_MEMBER'));
  });

  it('a custom group member set to NEITHER is rejected (XOR)', () => {
    const s = { custom_groups: [{ name: 'G' }], custom_group_members: [{ group_name: 'G' }] };
    const plan = buildImportPlan(s, 'u-ed');
    assert.equal(plan.ok, false);
    assert.ok(plan.errors.some((e) => e.code === 'INVALID_MEMBER'));
  });

  it('unknown sheet name is rejected', () => {
    const plan = buildImportPlan({ nonsense: [] }, 'u-ed');
    assert.equal(plan.ok, false);
    assert.ok(plan.errors.some((e) => e.code === 'UNKNOWN_SHEET'));
  });

  it('a config-only sheet in a scenario import is an IGNORED notice, not an error', () => {
    const plan = buildImportPlan({ bundles: [{ name: 'B1' }], sites: [{ name: 'DC' }] }, 'u-ed');
    assert.equal(plan.ok, true, JSON.stringify(plan.errors));
    assert.ok(plan.notices.some((n) => n.sheet === 'bundles' && n.code === 'IGNORED_SHEET'));
    assert.equal(plan.errors.some((e) => e.sheet === 'bundles'), false);
  });

  it('a db_instance pointing at an ap_host VM is a type error', () => {
    const s = {
      vms: [{ name: 'AP-1', vm_type: 'ap_host' }],
      db_instances: [{ name: 'DB-1', vm_name: 'AP-1', role: 'primary' }],
    };
    const plan = buildImportPlan(s, 'u-ed');
    assert.equal(plan.ok, false);
    assert.ok(plan.errors.some((e) => e.column === 'vm_name' && e.code === 'INVALID_REF_TYPE'));
  });

  it('per-sheet stats count rows + errors', () => {
    const plan = buildImportPlan({ sites: [{ name: 'A' }, {}] }, 'u-ed');
    assert.equal(plan.stats.perSheet.sites.rows, 2);
    assert.equal(plan.stats.perSheet.sites.errors, 1);
  });
});

// ── 5. Settings match-to-global ────────────────────────────────────────────────
describe('buildImportPlan: settings import writes a scenario override only, never the global singleton', () => {
  const globalSettings = [{
    id: 'GS', mem_cpu_ratio: 20, sga_factor: 0.982, sga_divisor: 2, sga_subtract: 2,
    util_amber_pct: 80, util_red_pct: 90, overcommit_default_enabled: 0, layer_defaults: null,
  }];

  it('a settings row value-equal to the global singleton is skipped (scenario tracks global)', () => {
    const plan = buildImportPlan(
      { settings: [{ mem_cpu_ratio: 20, sga_factor: 0.982, sga_divisor: 2, sga_subtract: 2, util_amber_pct: 80, util_red_pct: 90, overcommit_default_enabled: false }] },
      'u', { settings: globalSettings, hardware_specs: [], vm_profiles: [], disk_combos: [], teams: [], rules: [] },
    );
    assert.equal(plan.ok, true, JSON.stringify(plan.errors));
    assert.equal(plan.plan.settings.length, 0);
  });

  it('a settings row differing from the global singleton is written scenario-local', () => {
    const plan = buildImportPlan(
      { settings: [{ mem_cpu_ratio: 16, sga_factor: 0.982, sga_divisor: 2, sga_subtract: 2, util_amber_pct: 75, util_red_pct: 88, overcommit_default_enabled: true }] },
      'u', { settings: globalSettings, hardware_specs: [], vm_profiles: [], disk_combos: [], teams: [], rules: [] },
    );
    assert.equal(plan.ok, true, JSON.stringify(plan.errors));
    assert.equal(plan.plan.settings.length, 1);
  });

  it('still skipped when the global row carries the column the sheet cannot', () => {
    // The fixture above omits `standby_sga_default_gb`, so both operands read
    // null and the diff agreed for the wrong reason. The DATABASE never hands
    // that row back: the column is `NOT NULL DEFAULT 32`, so the global value
    // is always a number while the imported row's is always `undefined` — and
    // the diff's "a null on one side alone is a difference" rule then answered
    // "not the global row" for every settings row on every scenario. The
    // consequence is silent: the row is written scenario-local, that column
    // falls to the DDL default, and the scenario permanently stops tracking the
    // operator's global setting.
    const storedGlobal = [{ ...globalSettings[0], standby_sga_default_gb: 64 }];
    const plan = buildImportPlan(
      { settings: [{ mem_cpu_ratio: 20, sga_factor: 0.982, sga_divisor: 2, sga_subtract: 2, util_amber_pct: 80, util_red_pct: 90, overcommit_default_enabled: false }] },
      'u', { settings: storedGlobal, hardware_specs: [], vm_profiles: [], disk_combos: [], teams: [], rules: [] },
    );
    assert.equal(plan.ok, true, JSON.stringify(plan.errors));
    assert.equal(
      plan.plan.settings.length, 0,
      'a re-exported global settings row was judged a scenario override because the diff '
      + 'compared a column the scenario sheet cannot carry',
    );
  });
});

// ── 6. Ref-based FK resolution + route round-trip ──────────────────────────────
describe('ref-based FK resolution (duplicate-name round-trip)', () => {
  it('duplicate-name target sheet + refs → resolves to the right row', () => {
    const s = {
      sites: [{ name: 'DC', ref: 's1' }, { name: 'DC', ref: 's2' }],
      hardware_specs: [{ name: 'Spec-A', ref: 'h1' }],
      hypervisors: [{ name: 'HV-1', site_ref: 's2', spec_ref: 'h1' }],
    };
    const plan = buildImportPlan(s, 'u-ed');
    assert.equal(plan.ok, true, JSON.stringify(plan.errors));
    assert.equal(plan.plan.hypervisors[0].dbRow.site_id, plan.plan.sites[1].id, 'resolved to the s2 row, not s1');
    assert.equal(Object.prototype.hasOwnProperty.call(plan.plan.sites[0].dbRow, 'ref'), false);
  });

  it('a duplicate ref within a sheet → DUPLICATE_REF', () => {
    const plan = buildImportPlan({ sites: [{ name: 'A', ref: 'x' }, { name: 'B', ref: 'x' }] }, 'u-ed');
    assert.equal(plan.ok, false);
    assert.ok(plan.errors.some((e) => e.sheet === 'sites' && e.code === 'DUPLICATE_REF'));
  });

  it('an FK with neither name nor ref → MISSING_FIELD (non-nullable FK)', () => {
    const plan = buildImportPlan({ hypervisors: [{ name: 'HV' }] }, 'u-ed');
    assert.equal(plan.ok, false);
    assert.ok(plan.errors.some((e) => e.column === 'site_name' && e.code === 'MISSING_FIELD'));
  });
});

describe('buildImportPlan: rule DoS bounds (import cannot bypass the write-path limits)', () => {
  const bigParams = { blob: 'a'.repeat(8182) };  // serialized 8193 > 8192
  const okParams = { blob: 'a'.repeat(8181) };   // serialized === 8192 → passes
  const conds = (n) => ({ conditions: Array.from({ length: n }, () => ({ field: 'cpu', op: '=', value: 1 })) });

  it('an oversized rule params blob is a structural error', () => {
    const plan = buildImportPlan({ rules: [{ type: 'no-oversell', name: 'R', level: 'hypervisor', group_by: 'all_of_type', params: bigParams }] }, 'u-ed');
    assert.equal(plan.ok, false);
    assert.ok(plan.errors.some((e) => e.sheet === 'rules' && e.code === 'PAYLOAD_TOO_LARGE'));
  });

  it('more than 50 filter conditions is a structural error', () => {
    const plan = buildImportPlan({ rules: [{ type: 'keep-apart', name: 'R', level: 'db_instance', group_by: 'each_primary_cluster', filters: conds(51) }] }, 'u-ed');
    assert.equal(plan.ok, false);
    assert.ok(plan.errors.some((e) => e.sheet === 'rules' && e.code === 'TOO_MANY_CONDITIONS'));
  });

  it('exactly 50 conditions and an exactly-8192-byte params blob pass the bounds', () => {
    assert.equal(JSON.stringify(okParams).length, 8192, 'boundary fixture is exactly at the cap');
    const plan = buildImportPlan({ rules: [{ type: 'keep-apart', name: 'R', level: 'db_instance', group_by: 'each_primary_cluster', filters: conds(50), params: okParams }] }, 'u-ed');
    assert.equal(plan.ok, true, JSON.stringify(plan.errors));
  });
});

describe('importPayloadTooLarge', () => {
  it('small payload is fine; a >4 MB payload trips the cap', () => {
    assert.equal(importPayloadTooLarge(validSheets()), false);
    assert.equal(importPayloadTooLarge({ sites: [{ name: 'x'.repeat(4 * 1024 * 1024 + 50) }] }), true);
  });
});

// ── 7. Export route ────────────────────────────────────────────────────────────
describe('export route', () => {
  it('returns a snapshot-shaped { schema_rev, tables } projection (all authenticated)', async () => {
    currentUser = { id: 'u-user', role: 'user' };
    state.scenarioRows = { sites: [{ id: 'site-1', scenario_id: 'scn-1', name: 'DC-1' }] };
    const res = await request('GET', '/capacity/scenarios/scn-1/export');
    assert.equal(res.status, 200, res.raw);
    assert.equal(res.json.data.schema_rev, 1);
    assert.deepEqual(res.json.data.tables.sites, [{ id: 'site-1', scenario_id: 'scn-1', name: 'DC-1' }]);
    assert.ok(Object.prototype.hasOwnProperty.call(res.json.data.tables, 'waivers'), 'all snapshot tables present');
  });

  it('unauthenticated → 401', async () => {
    currentUser = undefined;
    const res = await request('GET', '/capacity/scenarios/scn-1/export');
    assert.equal(res.status, 401, res.raw);
  });

  it('missing scenario → 404', async () => {
    currentUser = { id: 'u-user', role: 'user' };
    state.scenarioExists = false;
    const res = await request('GET', '/capacity/scenarios/ghost/export');
    assert.equal(res.status, 404, res.raw);
  });
});

// ── fmb-1686 (surface 5): scenario export snapshot hydrates name_patterns ──────
// buildScenarioSnapshotDoc reads via raw conn.query (readScenarioSnapshotTables /
// addGlobalConfigLayer) — it bypasses the dto-mapper choke point entirely, so
// this surface needed its OWN hydration (readScenarioSnapshotTables now calls
// hydrateSettingsNamePatterns; buildScenarioSnapshotDoc re-runs it after
// addGlobalConfigLayer appends the global settings row via its own raw read).
describe('export route — fmb-1686 name_patterns hydration', () => {
  const legacy3Key = { hypervisor: 'hv-{dc}-{seq:2}', kvm_host: 'kvm-{dc}-{seq:2}', ap_vm: 'ap-{seq:2}' };
  const assertHydrated4Key = (patterns) => {
    assert.deepEqual(Object.keys(patterns).sort(), ['ap_vm', 'hypervisor', 'kvm_host_primary', 'kvm_host_standby']);
    assert.equal(patterns.kvm_host_primary, 'kvm-{dc}-{seq:2}');
    assert.equal(patterns.kvm_host_standby, 'kvm-{dc}-{seq:2}');
  };

  it('hydrates a stored legacy 3-key SCENARIO-LOCAL override row to 4-key', async () => {
    currentUser = { id: 'u-user', role: 'user' };
    state.scenarioRows = {
      settings: [{ id: 'set-1', scenario_id: 'scn-1', mem_cpu_ratio: 20, name_patterns: legacy3Key }],
    };
    const res = await request('GET', '/capacity/scenarios/scn-1/export');
    assert.equal(res.status, 200, res.raw);
    assertHydrated4Key(res.json.data.tables.settings[0].name_patterns);
  });

  it('hydrates a stored legacy 3-key GLOBAL settings row pulled in by addGlobalConfigLayer', async () => {
    currentUser = { id: 'u-user', role: 'user' };
    // No scenario-local override — addGlobalConfigLayer pulls the global
    // singleton in via its OWN raw conn.query (a fresh, un-hydrated read).
    state.scenarioRows = { settings: [] };
    state.globalRows = {
      settings: [{ id: 'set-global', scenario_id: null, mem_cpu_ratio: 18, name_patterns: legacy3Key }],
    };
    const res = await request('GET', '/capacity/scenarios/scn-1/export');
    assert.equal(res.status, 200, res.raw);
    assertHydrated4Key(res.json.data.tables.settings[0].name_patterns);
  });

  it('leaves an untouched (null) name_patterns as null, not a manufactured default set', async () => {
    currentUser = { id: 'u-user', role: 'user' };
    state.scenarioRows = {
      settings: [{ id: 'set-1', scenario_id: 'scn-1', mem_cpu_ratio: 20, name_patterns: null }],
    };
    const res = await request('GET', '/capacity/scenarios/scn-1/export');
    assert.equal(res.status, 200, res.raw);
    assert.equal(res.json.data.tables.settings[0].name_patterns, null);
  });

  it('an already-4-key stored row passes through unchanged (idempotent)', async () => {
    currentUser = { id: 'u-user', role: 'user' };
    const already4Key = {
      hypervisor: 'hv-{seq:2}', kvm_host_primary: 'kp-{seq:2}', kvm_host_standby: 'ks-{seq:2}', ap_vm: 'ap-{seq:2}',
    };
    state.scenarioRows = {
      settings: [{ id: 'set-1', scenario_id: 'scn-1', mem_cpu_ratio: 20, name_patterns: { ...already4Key } }],
    };
    const res = await request('GET', '/capacity/scenarios/scn-1/export');
    assert.equal(res.status, 200, res.raw);
    assert.deepEqual(res.json.data.tables.settings[0].name_patterns, already4Key);
  });
});

// ── 7b. order_index round-trip (phase-4 spec §6) ───────────────────────────────
// A workbook carries NO order_index column; ROW POSITION is the carrier. Export
// emits the reorderable sheets in order_index order; import re-seeds order_index
// from row position. Together a drag-reorder survives an export→import round-trip.
describe('order_index round-trip (phase-4 §6)', () => {
  it('export emits the reorderable sheets in order_index order (not DB read order)', async () => {
    currentUser = { id: 'u-user', role: 'user' };
    state.scenarioRows = {
      hypervisors: [
        { id: 'h-b', scenario_id: 'scn-1', name: 'HV-B', order_index: 2 },
        { id: 'h-a', scenario_id: 'scn-1', name: 'HV-A', order_index: 0 },
        { id: 'h-c', scenario_id: 'scn-1', name: 'HV-C', order_index: 1 },
      ],
    };
    const res = await request('GET', '/capacity/scenarios/scn-1/export');
    assert.equal(res.status, 200, res.raw);
    assert.deepEqual(res.json.data.tables.hypervisors.map((r) => r.id), ['h-a', 'h-c', 'h-b']);
  });

  it('import commit re-seeds order_index from row position for reorderable entities only', async () => {
    currentUser = { id: 'u-admin', role: 'admin' };
    const sheets = {
      sites: [{ name: 'DC-1' }, { name: 'DC-2' }, { name: 'DC-3' }],
      hardware_specs: [{ name: 'Spec-A', cpu_total: 8, mem_total_gb: 64, disk_total_gb: 500 }],
      hypervisors: [
        { name: 'HV-1', site_name: 'DC-1', spec_name: 'Spec-A' },
        { name: 'HV-2', site_name: 'DC-2', spec_name: 'Spec-A' },
      ],
      databases: [{ function_name: 'a', topology: 'single' }, { function_name: 'b', topology: 'single' }],
    };
    const res = await request('POST', '/capacity/scenarios/scn-1/import', { mode: 'commit', sheets });
    assert.equal(res.status, 200, res.raw);
    assert.deepEqual(insertsFor('cap_sites').map((q) => insertColVal(q, 'order_index')), [0, 1, 2]);
    assert.deepEqual(insertsFor('cap_hypervisors').map((q) => insertColVal(q, 'order_index')), [0, 1]);
    assert.deepEqual(insertsFor('cap_hardware_specs').map((q) => insertColVal(q, 'order_index')), [0]);
    // databases has no order_index column → the INSERT must never carry one.
    assert.equal(/`order_index`/.test(insertsFor('cap_databases')[0].sql), false);
  });

  it('round-trip: exported order → import row position → re-seeded order_index preserves the drag order', async () => {
    currentUser = { id: 'u-admin', role: 'admin' };
    // 1. Export a scenario whose hypervisors were drag-reordered (2 / 0 / 1).
    state.scenarioRows = {
      sites: [{ id: 's1', scenario_id: 'scn-1', name: 'DC-1', order_index: 0 }],
      hardware_specs: [{ id: 'hs1', scenario_id: 'scn-1', name: 'Spec-A', order_index: 0 }],
      hypervisors: [
        { id: 'h-b', scenario_id: 'scn-1', name: 'HV-B', site_id: 's1', spec_id: 'hs1', order_index: 2 },
        { id: 'h-a', scenario_id: 'scn-1', name: 'HV-A', site_id: 's1', spec_id: 'hs1', order_index: 0 },
        { id: 'h-c', scenario_id: 'scn-1', name: 'HV-C', site_id: 's1', spec_id: 'hs1', order_index: 1 },
      ],
    };
    const exp = await request('GET', '/capacity/scenarios/scn-1/export');
    assert.equal(exp.status, 200, exp.raw);
    const exportedHvNames = exp.json.data.tables.hypervisors.map((r) => r.name);
    assert.deepEqual(exportedHvNames, ['HV-A', 'HV-C', 'HV-B'], 'export orders by order_index');

    // 2. Re-import name-keyed sheets in the EXPORTED row order (row position is
    //    the only order carrier the workbook has).
    state.queries = [];
    const sheets = {
      sites: [{ name: 'DC-1' }],
      hardware_specs: [{ name: 'Spec-A', cpu_total: 8, mem_total_gb: 64, disk_total_gb: 500 }],
      hypervisors: exportedHvNames.map((name) => ({ name, site_name: 'DC-1', spec_name: 'Spec-A' })),
    };
    const imp = await request('POST', '/capacity/scenarios/scn-1/import', { mode: 'commit', sheets });
    assert.equal(imp.status, 200, imp.raw);

    // 3. The re-seeded order_index reproduces the original drag order by name.
    const byName = new Map(insertsFor('cap_hypervisors').map((q) => [insertColVal(q, 'name'), insertColVal(q, 'order_index')]));
    assert.equal(byName.get('HV-A'), 0);
    assert.equal(byName.get('HV-C'), 1);
    assert.equal(byName.get('HV-B'), 2);
  });
});

// ── 7c. name_locked round-trip (cap-renumber-lock, spec D1 Task 1.4) ───────────
// The lock flag must survive export→import — a scenario cloned/migrated via a
// workbook must not silently unlock every host (the DEFAULT 0 an undeclared
// sheet column would otherwise fall to on re-import).
describe('name_locked round-trip (cap-renumber-lock)', () => {
  it('export carries name_locked for both entities', async () => {
    currentUser = { id: 'u-user', role: 'user' };
    state.scenarioRows = {
      hypervisors: [{ id: 'h1', scenario_id: 'scn-1', name: 'HV-LOCKED', name_locked: 1 }],
      vms: [{ id: 'v1', scenario_id: 'scn-1', name: 'VM-LOCKED', vm_type: 'ap_host', name_locked: 1 }],
    };
    const res = await request('GET', '/capacity/scenarios/scn-1/export');
    assert.equal(res.status, 200, res.raw);
    assert.equal(res.json.data.tables.hypervisors[0].name_locked, 1);
    assert.equal(res.json.data.tables.vms[0].name_locked, 1);
  });

  it('export a locked hypervisor + locked VM → import into an empty scenario → both flags survive', async () => {
    currentUser = { id: 'u-admin', role: 'admin' };
    // 1. A scenario carrying one locked hypervisor and one locked (unplaced)
    //    ap_host VM — the two entities Task 1.1/1.3 cover.
    state.scenarioRows = {
      sites: [{ id: 's1', scenario_id: 'scn-1', name: 'DC-1' }],
      hardware_specs: [{ id: 'hs1', scenario_id: 'scn-1', name: 'Spec-A' }],
      hypervisors: [{
        id: 'h1', scenario_id: 'scn-1', name: 'HV-LOCKED', site_id: 's1', spec_id: 'hs1', name_locked: 1,
      }],
      vms: [{
        id: 'v1', scenario_id: 'scn-1', name: 'VM-LOCKED', vm_type: 'ap_host', name_locked: 1,
      }],
    };
    const exp = await request('GET', '/capacity/scenarios/scn-1/export');
    assert.equal(exp.status, 200, exp.raw);
    const expHv = exp.json.data.tables.hypervisors[0];
    const expVm = exp.json.data.tables.vms[0];
    assert.equal(expHv.name_locked, 1);
    assert.equal(expVm.name_locked, 1);

    // 2. Re-import the exported rows, name-keyed, into an empty target scenario.
    state.queries = [];
    const sheets = {
      sites: [{ name: 'DC-1' }],
      hardware_specs: [{ name: 'Spec-A', cpu_total: 8, mem_total_gb: 64, disk_total_gb: 500 }],
      hypervisors: [{
        name: expHv.name, site_name: 'DC-1', spec_name: 'Spec-A', name_locked: !!expHv.name_locked,
      }],
      vms: [{ name: expVm.name, vm_type: expVm.vm_type, name_locked: !!expVm.name_locked }],
    };
    const imp = await request('POST', '/capacity/scenarios/scn-1/import', { mode: 'commit', sheets });
    assert.equal(imp.status, 200, imp.raw);

    // 3. Both flags survived the round-trip as the value the DB write will bind.
    const hvInsert = insertsFor('cap_hypervisors')[0];
    const vmInsert = insertsFor('cap_vms')[0];
    assert.equal(insertColVal(hvInsert, 'name_locked'), 1, 'the locked hypervisor stays locked after import');
    assert.equal(insertColVal(vmInsert, 'name_locked'), 1, 'the locked VM stays locked after import');
  });

  it('a sheet that omits name_locked imports unlocked (DDL default), never a crash', async () => {
    currentUser = { id: 'u-admin', role: 'admin' };
    const sheets = {
      sites: [{ name: 'DC-1' }],
      hardware_specs: [{ name: 'Spec-A', cpu_total: 8, mem_total_gb: 64, disk_total_gb: 500 }],
      hypervisors: [{ name: 'HV-1', site_name: 'DC-1', spec_name: 'Spec-A' }],
    };
    const res = await request('POST', '/capacity/scenarios/scn-1/import', { mode: 'commit', sheets });
    assert.equal(res.status, 200, res.raw);
    assert.equal(insertColVal(insertsFor('cap_hypervisors')[0], 'name_locked'), undefined, 'column absent from the INSERT — DDL default 0 applies');
  });
});

// ── 8. Import route ──────────────────────────────────────────────────────────
describe('import route: validate (zero writes)', () => {
  it('validate returns the report and writes nothing', async () => {
    currentUser = { id: 'u-admin', role: 'admin' };
    const res = await request('POST', '/capacity/scenarios/scn-1/import', { mode: 'validate', sheets: validSheets() });
    assert.equal(res.status, 200, res.raw);
    assert.equal(res.json.ok, true);
    assert.equal(inserts().length, 0, 'validate never inserts');
    assert.equal(deletes().length, 0, 'validate never deletes');
  });

  it('validate reports structural errors without writing', async () => {
    currentUser = { id: 'u-admin', role: 'admin' };
    const res = await request('POST', '/capacity/scenarios/scn-1/import', { mode: 'validate', sheets: { vms: [{ name: 'V', vm_type: 'bogus' }] } });
    assert.equal(res.status, 200, res.raw);
    assert.equal(res.json.ok, false);
    assert.ok(res.json.errors.length > 0);
    assert.equal(inserts().length, 0);
  });

  it('validate surfaces an IGNORED_SHEET notice for a config-only sheet', async () => {
    currentUser = { id: 'u-admin', role: 'admin' };
    const res = await request('POST', '/capacity/scenarios/scn-1/import', { mode: 'validate', sheets: { bundles: [{ name: 'B' }], sites: [{ name: 'DC' }] } });
    assert.equal(res.status, 200, res.raw);
    assert.equal(res.json.ok, true);
    assert.ok(res.json.notices.some((n) => n.code === 'IGNORED_SHEET'));
  });
});

describe('import route: commit (all-or-nothing replace-all)', () => {
  it('a clean commit clears every SNAPSHOT table then inserts every scenario-local row', async () => {
    currentUser = { id: 'u-admin', role: 'admin' };
    const res = await request('POST', '/capacity/scenarios/scn-1/import', { mode: 'commit', sheets: validSheets() });
    assert.equal(res.status, 200, res.raw);
    assert.equal(res.json.ok, true);
    assert.equal(deletes().length, SNAPSHOT_TABLES.length, 'every content table is cleared (cap_versions is NOT touched)');
    // validSheets injects no globals → every catalogue row is unmatched → all 14
    // scenario sheets contribute exactly one insert (settings differs from the
    // absent global → written, so 14 inserts).
    assert.equal(inserts().length, 14, 'one row inserted per scenario sheet');
    assert.equal(state.queries.some((q) => /DELETE FROM `fmb_cap_versions`/.test(q.sql)), false);
    // `ref`/`cf:` never become DB columns.
    assert.equal(state.queries.some((q) => /INSERT INTO `fmb_cap_[a-z_]+`.*`ref`/.test(q.sql)), false);
    assert.equal(state.queries.some((q) => /`cf:tier`/.test(q.sql)), false);
  });

  it('a matched-global catalogue row is NOT re-inserted (reference model)', async () => {
    currentUser = { id: 'u-admin', role: 'admin' };
    state.globalRows = { hardware_specs: [{ id: 'GID', name: 'Spec-A' }] };
    const sheets = {
      hardware_specs: [{ name: 'Spec-A' }],
      sites: [{ name: 'DC' }],
      hypervisors: [{ name: 'HV', site_name: 'DC', spec_name: 'Spec-A' }],
    };
    const res = await request('POST', '/capacity/scenarios/scn-1/import', { mode: 'commit', sheets });
    assert.equal(res.status, 200, res.raw);
    assert.equal(state.queries.some((q) => /INSERT INTO `fmb_cap_hardware_specs`/.test(q.sql)), false, 'the matched global spec is not re-created');
    assert.ok(state.queries.some((q) => /INSERT INTO `fmb_cap_hypervisors`/.test(q.sql) && q.params.includes('GID')), 'the hypervisor FK points at the global id');
  });

  it('aborts 409 (nothing written) when a referenced global vanished mid-import (TOCTOU lock)', async () => {
    currentUser = { id: 'u-admin', role: 'admin' };
    state.globalRows = { hardware_specs: [{ id: 'GID', name: 'Spec-A' }] };
    state.vanishGlobals = true; // the FOR UPDATE lock probe finds it gone
    const sheets = {
      hardware_specs: [{ name: 'Spec-A' }],
      sites: [{ name: 'DC' }],
      hypervisors: [{ name: 'HV', site_name: 'DC', spec_name: 'Spec-A' }],
    };
    const res = await request('POST', '/capacity/scenarios/scn-1/import', { mode: 'commit', sheets });
    assert.equal(res.status, 409, res.raw);
    assert.equal(inserts().length, 0, 'nothing inserted');
    assert.equal(deletes().length, 0, 'nothing deleted — the replace-all never ran');
  });

  it('never-block: a rule-violating placement still commits', async () => {
    currentUser = { id: 'u-admin', role: 'admin' };
    const sheets = validSheets();
    sheets.db_instances.push({ name: 'erp', vm_name: 'VM-1', database_name: 'erp', role: 'standby', sga_gb: 40 });
    const res = await request('POST', '/capacity/scenarios/scn-1/import', { mode: 'commit', sheets });
    assert.equal(res.status, 200, res.raw);
    assert.equal(res.json.ok, true);
  });

  it('a structural error aborts the commit → 422, nothing written', async () => {
    currentUser = { id: 'u-admin', role: 'admin' };
    const sheets = validSheets();
    sheets.vms[0].vm_type = 'bogus';
    const res = await request('POST', '/capacity/scenarios/scn-1/import', { mode: 'commit', sheets });
    assert.equal(res.status, 422, res.raw);
    assert.equal(res.json.ok, false);
    assert.equal(inserts().length, 0, 'nothing inserted on a rejected commit');
    assert.equal(deletes().length, 0, 'nothing deleted on a rejected commit');
  });

  it('an INSERT failure rolls back and 500s (safeRollback path)', async () => {
    currentUser = { id: 'u-admin', role: 'admin' };
    state.throwOnInsert = true;
    const res = await request('POST', '/capacity/scenarios/scn-1/import', { mode: 'commit', sheets: validSheets() });
    assert.equal(res.status, 500, res.raw);
  });
});

describe('import route: permissions + guards', () => {
  it('a plain user is refused (403) before any DB work', async () => {
    currentUser = { id: 'u-user', role: 'user' };
    const res = await request('POST', '/capacity/scenarios/scn-1/import', { mode: 'commit', sheets: validSheets() });
    assert.equal(res.status, 403, res.raw);
    assert.equal(inserts().length, 0);
  });

  it('a non-owner editor is refused (403)', async () => {
    currentUser = { id: 'u-other', role: 'editor' };
    state.scenarioOwner = 'u-ed';
    const res = await request('POST', '/capacity/scenarios/scn-1/import', { mode: 'commit', sheets: validSheets() });
    assert.equal(res.status, 403, res.raw);
    assert.equal(inserts().length, 0);
  });

  it('the owning editor may commit', async () => {
    currentUser = { id: 'u-ed', role: 'editor' };
    state.scenarioOwner = 'u-ed';
    const res = await request('POST', '/capacity/scenarios/scn-1/import', { mode: 'commit', sheets: validSheets() });
    assert.equal(res.status, 200, res.raw);
  });

  it('admin may commit any scenario', async () => {
    currentUser = { id: 'u-admin', role: 'admin' };
    state.scenarioOwner = 'someone-else';
    const res = await request('POST', '/capacity/scenarios/scn-1/import', { mode: 'commit', sheets: validSheets() });
    assert.equal(res.status, 200, res.raw);
  });

  it('a missing scenario → 404', async () => {
    currentUser = { id: 'u-admin', role: 'admin' };
    state.accessRows = [];
    const res = await request('POST', '/capacity/scenarios/ghost/import', { mode: 'commit', sheets: validSheets() });
    assert.equal(res.status, 404, res.raw);
    assert.equal(inserts().length, 0);
  });

  it('an unknown mode → 400', async () => {
    currentUser = { id: 'u-admin', role: 'admin' };
    const res = await request('POST', '/capacity/scenarios/scn-1/import', { mode: 'apply', sheets: {} });
    assert.equal(res.status, 400, res.raw);
  });

  it('a non-object sheets payload → 400', async () => {
    currentUser = { id: 'u-admin', role: 'admin' };
    const res = await request('POST', '/capacity/scenarios/scn-1/import', { mode: 'validate', sheets: [] });
    assert.equal(res.status, 400, res.raw);
  });

  it('an oversize payload → 413 before any DB work', async () => {
    currentUser = { id: 'u-admin', role: 'admin' };
    const sheets = { sites: [{ name: 'x'.repeat(4 * 1024 * 1024 + 50) }] };
    const res = await request('POST', '/capacity/scenarios/scn-1/import', { mode: 'validate', sheets });
    assert.equal(res.status, 413, res.raw);
    assert.equal(res.json.error.code, 'PAYLOAD_TOO_LARGE');
  });
});
