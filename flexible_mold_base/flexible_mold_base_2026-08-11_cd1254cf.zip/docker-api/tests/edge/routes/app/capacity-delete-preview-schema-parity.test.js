/**
 * capacity-delete-preview-schema-parity.test.js — validates every column the
 * delete-impact preview SQL references against the ACTUAL table DDL, WITHOUT a
 * live DB. The node:test mocks stub query results, so a wrong column name (e.g.
 * SELECT `name` from cap_databases, whose display column is `function_name`)
 * stays green in both runners yet 500s in production and fail-closes every
 * scenario delete. This test closes that gap: it parses docker-api/src/table-ddls
 * and asserts the preview's referenced columns exist.
 */
const { describe, it, before } = require('node:test');
const assert = require('node:assert/strict');

// _shared.js destructures { t } from ../../../db at load (never calls it at load
// time); stub the db module so the require is side-effect-free (no pool).
const dbKey = require.resolve('../../../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: {}, t: (n) => n },
};

const { buildEngineTableDDLs } = require('../../../../src/table-ddls');
const {
  SCENARIO_SCOPED_TABLES, SCENARIO_ENTITY_DISPLAY, CONFIG_DELETE_GUARDS, SCENARIO_INTEGRITY_FK_PROBES,
  CHILD_DELETE_BEHAVIOR, DELETE_IMPACT_DISPLAY,
} = require('../../../../src/edge/routes/app/capacity/_shared');

// Parse the engine DDLs (identity `t` → logical table names) into table → column set.
const SQL_TYPES = /^`?([a-z_]+)`?\s+(?:CHAR|VARCHAR|INT|DOUBLE|TIMESTAMP|JSON|TEXT|ENUM|BOOLEAN|TINYINT|BIGINT|DATETIME|DECIMAL|FLOAT|BLOB)\b/i;
let columnsByTable;

before(() => {
  columnsByTable = new Map();
  for (const ddl of buildEngineTableDDLs((n) => n)) {
    const m = ddl.match(/CREATE TABLE IF NOT EXISTS `([^`]+)`/);
    if (!m) continue;
    const table = m[1];
    const cols = new Set();
    for (const rawLine of ddl.split('\n')) {
      const line = rawLine.trim();
      if (!line || line.startsWith('--') || line.startsWith('/*')) continue;
      const cm = line.match(SQL_TYPES);
      if (cm) cols.add(cm[1]);
    }
    columnsByTable.set(table, cols);
  }
});

describe('delete-preview schema parity', () => {
  it('parses a column set for every scenario-scoped table', () => {
    for (const table of SCENARIO_SCOPED_TABLES) {
      const cols = columnsByTable.get(String(table));
      assert.ok(cols && cols.size > 0, `no columns parsed for ${table}`);
    }
  });

  it('every scoped table has scenario_id (the T1 counts loop filters on it)', () => {
    for (const table of SCENARIO_SCOPED_TABLES) {
      assert.ok(columnsByTable.get(String(table)).has('scenario_id'), `${table} is missing scenario_id`);
    }
  });

  it('every named entity has id + its configured display column (function_name for databases)', () => {
    for (const { table, nameCol } of SCENARIO_ENTITY_DISPLAY) {
      const cols = columnsByTable.get(String(table));
      assert.ok(cols.has('id'), `${table} is missing id`);
      assert.ok(cols.has(nameCol), `${table} has no column '${nameCol}' (display-column mismatch would 500 the preview)`);
    }
  });

  it('every scenario-health FK probe references real columns (from.fk, to.id, to.scenario_id)', () => {
    for (const probe of SCENARIO_INTEGRITY_FK_PROBES) {
      const fromCols = columnsByTable.get(String(probe.from));
      const toCols = columnsByTable.get(String(probe.to));
      assert.ok(fromCols && fromCols.has(probe.fk), `${probe.from} has no FK column '${probe.fk}'`);
      assert.ok(toCols && toCols.has('id'), `${probe.to} has no id`);
      // The scope-aware join reads p.scenario_id on the target.
      assert.ok(toCols.has('scenario_id'), `${probe.to} has no scenario_id (needed for the scope join)`);
    }
  });

  it('every T2 catalogue guard reference column exists on its table', () => {
    for (const [group, guard] of Object.entries(CONFIG_DELETE_GUARDS)) {
      for (const ref of guard.refs) {
        const cols = columnsByTable.get(String(ref.table));
        assert.ok(cols, `guard ${group} references unknown table ${ref.table}`);
        assert.ok(cols.has(ref.column), `guard ${group}: ${ref.table} has no column '${ref.column}'`);
      }
    }
  });

  // T3 (per-child preview) + makeChildDelete cascade both interpolate these as
  // identifiers; a wrong one 500s the fail-closed preview AND the delete while
  // every mocked runner stays green.
  it('every DELETE_IMPACT_DISPLAY table has id, scenario_id and its display column', () => {
    for (const [table, { nameCol }] of Object.entries(DELETE_IMPACT_DISPLAY)) {
      const cols = columnsByTable.get(String(table));
      assert.ok(cols, `DELETE_IMPACT_DISPLAY names unknown table ${table}`);
      assert.ok(cols.has('id'), `${table} is missing id`);
      assert.ok(cols.has('scenario_id'), `${table} is missing scenario_id (the zone counts filter on it)`);
      if (nameCol) assert.ok(cols.has(nameCol), `${table} has no display column '${nameCol}' (a 500 for the whole preview)`);
    }
  });

  // A cascade/unplace target with no DELETE_IMPACT_DISPLAY entry falls through
  // displayOf to `{ kind: <raw table name> }`, leaking the physical table name
  // into the preview zone AND collapsing dedupe onto that raw kind. Dormant today
  // (every target is covered), so this pins it before a new cascade re-opens it.
  it('every CHILD_DELETE_BEHAVIOR cascade/unplace/sweep target has a DELETE_IMPACT_DISPLAY entry', () => {
    const targets = new Set();
    for (const behavior of Object.values(CHILD_DELETE_BEHAVIOR)) {
      for (const kind of ['unplace', 'cascade']) {
        for (const ref of behavior[kind] || []) targets.add(String(ref.table));
      }
      for (const g of (behavior.sweep && behavior.sweep.groups) || []) targets.add(String(g.table));
    }
    for (const table of targets) {
      assert.ok(DELETE_IMPACT_DISPLAY[table],
        `${table} is a cascade/unplace/sweep target with no DELETE_IMPACT_DISPLAY entry (the preview would name it by its raw table name)`);
    }
  });

  it('every CHILD_DELETE_BEHAVIOR ref column exists on its referencing table', () => {
    for (const [segment, behavior] of Object.entries(CHILD_DELETE_BEHAVIOR)) {
      // The sweep segments declare their refs in the sweep (covered by the sweep
      // block below); the rest declare block/unplace/cascade per-column here.
      for (const kind of ['block', 'unplace', 'cascade']) {
        for (const ref of behavior[kind] || []) {
          const cols = columnsByTable.get(String(ref.table));
          assert.ok(cols, `${segment}.${kind} references unknown table ${ref.table}`);
          assert.ok(cols.has(ref.column), `${segment}.${kind}: ${ref.table} has no column '${ref.column}'`);
          assert.ok(cols.has('scenario_id'), `${ref.table} is missing scenario_id (the delete scopes on it)`);
        }
      }
    }
  });
});

// ── the stale data-centre cache aggregate ───────────────────────────────────
// Not derivable from CHILD_FK_VALIDATIONS like the probes above: that list says
// a reference must RESOLVE, and both ends of this one resolve perfectly — what
// is wrong is that they disagree. So the statement names its columns literally,
// and a literal column name is exactly what a mocked runner paints green and a
// real schema 500s on.
//
// READ OUT OF THE SOURCE RATHER THAN RESTATED HERE. A hand-copied list of the
// columns the statement references is a second statement that can agree with
// the DDL while the first one does not — which is the failure this file exists
// to catch, reproduced one layer up. Adding a column to the SQL puts it under
// this check automatically.
const fs = require('node:fs');
const path = require('node:path');

const SCENARIOS_SRC = fs.readFileSync(
  path.resolve(__dirname, '../../../../src/edge/routes/app/capacity/scenarios.js'), 'utf8',
);

// Every logical table name the lifted statements below can name. Read off
// TABLES so a renamed constant fails here instead of quietly resolving to
// undefined and skipping the whole check.
const { TABLES } = require('../../../../src/shared/constants');
const TABLE_CONSTANTS = Object.fromEntries(
  Object.entries(TABLES).map(([name, value]) => [`TABLES.${name}`, String(value)]),
);

/** One aggregate statement's text, lifted from the module that issues it. */
function liftStatement(declaration) {
  const start = SCENARIOS_SRC.indexOf(declaration);
  assert.notEqual(start, -1, `scenarios.js no longer declares: ${declaration}`);
  // The SQL's own identifier backticks are ESCAPED in the source, so the
  // literal's closing delimiter is the first backtick NOT preceded by a
  // backslash — scanning for a bare one stops at `\\`${t(...)`.
  const open = SCENARIOS_SRC.indexOf('`', start);
  let close = open + 1;
  while (close < SCENARIOS_SRC.length
    && !(SCENARIOS_SRC[close] === '`' && SCENARIOS_SRC[close - 1] !== '\\')) close += 1;
  return SCENARIOS_SRC.slice(open + 1, close);
}

/** alias → logical table, taken from a statement's own FROM/JOIN clauses. */
function aliasesOf(statement) {
  const map = new Map();
  for (const m of statement.matchAll(/(?:FROM|JOIN)\s+\\`\$\{t\(([A-Z_.]+)\)\}\\`\s+(\w+)/g)) {
    const table = TABLE_CONSTANTS[m[1]];
    assert.ok(table, `the statement reads ${m[1]}, which is not a TABLES constant`);
    map.set(m[2], table);
  }
  return map;
}

/** Assert every aliased column a statement names exists on the table it names
 *  it on. `minRefs` guards the parse itself: a regex that silently stopped
 *  matching would otherwise check nothing and pass. */
function assertColumnParity(statement, aliasTable, minRefs) {
  const refs = [...statement.matchAll(/\b(\w+)\.(\w+)\b/g)]
    .filter(([, alias]) => aliasTable.has(alias))
    .map(([, alias, column]) => ({ table: aliasTable.get(alias), column }));
  assert.ok(refs.length >= minRefs, `only ${refs.length} column references found — the parse has stopped working`);
  for (const { table, column } of refs) {
    assert.ok(
      columnsByTable.get(table).has(column),
      `${table} has no column '${column}' — the list badge would 500 while every mocked test stayed green`,
    );
  }
}

describe('scenario-health stale data-centre aggregate — schema parity', () => {
  const statement = liftStatement('const staleVmSiteRows = await pool.ro.query(');
  const aliasTable = aliasesOf(statement);

  it('reads from both tables under an alias, so the check below has something to check', () => {
    assert.deepEqual([...aliasTable.values()].sort(), ['cap_hypervisors', 'cap_vms']);
  });

  it('every aliased column the statement names exists on the table it names it on', () => {
    assertColumnParity(statement, aliasTable, 6);
  });

  it('the cache column and the host column it is compared against are both nullable-aware', () => {
    // `cap_vms.site_id` is NULL for a KVM whose cache was never written, and the
    // statement must not count that as a disagreement — `<>` answers NULL, but
    // the explicit IS NOT NULL is what makes the intent readable and stops a
    // later rewrite to `<=>` from silently flagging every unwritten cache.
    assert.match(statement, /v\.site_id IS NOT NULL/);
    assert.match(statement, /v\.hypervisor_id IS NOT NULL/);
  });
});

// ── the dangling dc_refs aggregate ──────────────────────────────────────────
// Same reason as the block above and one more: this statement expands a JSON
// list through JSON_TABLE, so a wrong column name is a runtime error on a path
// no mocked runner can reach.
describe('scenario-health dangling dc_refs aggregate — schema parity', () => {
  const statement = liftStatement('const danglingDcRefRows = await pool.ro.query(');
  const aliasTable = aliasesOf(statement);

  it('reads the databases and the sites it checks them against, both under an alias', () => {
    assert.deepEqual([...aliasTable.values()].sort(), ['cap_databases', 'cap_sites']);
  });

  it('every aliased column the statement names exists on the table it names it on', () => {
    assertColumnParity(statement, aliasTable, 4);
  });

  it('narrows the index lookup with an EXACT comparison', () => {
    // `=` alone cannot answer this. Every MariaDB collation is PAD SPACE —
    // utf8mb4_bin included — so `'x ' = 'x'` is TRUE and an entry with a
    // trailing space would read as resolvable while `dcRefs.includes(siteId)`
    // refuses it. JSON string comparison does not pad, so it is what turns the
    // index's superset into the readers' answer. Whether the two agree is
    // measured against a real database over the shared corpus; this only stops
    // the narrowing clause being dropped as redundant.
    assert.match(statement, /JSON_CONTAINS\(JSON_ARRAY\(s\.id\), JSON_QUOTE\(r\.site_ref\)\)/);
  });

  it('does not test the entry for emptiness with a comparison PAD SPACE folds', () => {
    // `r.site_ref <> ''` is FALSE for a whitespace entry, which would drop it as
    // empty while every reader keeps it.
    assert.match(statement, /CHAR_LENGTH\(r\.site_ref\) > 0/);
    assert.equal(/site_ref\s*<>\s*''/.test(statement), false);
  });

  it('extracts each entry into a column WIDER than a site id can be', () => {
    // A width equal to a site id truncates a longer entry back ONTO an id and
    // calls it resolvable. Read out of the DDL rather than compared to 36: the
    // requirement is "wider than the column it is compared against", and a
    // widened `cap_sites.id` must fail here rather than silently re-open this.
    const idWidth = (() => {
      for (const ddl of buildEngineTableDDLs((n) => n)) {
        if (!ddl.includes('CREATE TABLE IF NOT EXISTS `cap_sites`')) continue;
        const m = ddl.match(/\bid\s+CHAR\((\d+)\)/i);
        assert.ok(m, 'cap_sites.id is no longer a CHAR(n) this test can measure');
        return parseInt(m[1], 10);
      }
      return assert.fail('cap_sites has no DDL');
    })();
    const m = statement.match(/site_ref VARCHAR\((\d+)\) PATH/);
    assert.ok(m, 'the JSON_TABLE column is gone or reshaped');
    assert.ok(parseInt(m[1], 10) > idWidth,
      `the entry column is VARCHAR(${m[1]}) against a CHAR(${idWidth}) site id — a longer entry truncates onto one`);
  });

  it('guards the JSON expansion so one unparseable row cannot 500 the list', () => {
    assert.match(statement, /IF\(JSON_VALID\(d\.dc_refs\), d\.dc_refs, JSON_ARRAY\(\)\)/);
  });

  it('counts a repeated entry once and two databases separately', () => {
    // One broken reference written twice is one broken reference; the same
    // absent site named by two databases is two.
    assert.match(statement, /COUNT\(DISTINCT d\.id,/);
  });

  it('does not key that DISTINCT on a value the connection collation folds', () => {
    // `r.site_ref` is a JSON_TABLE column on the connection collation, which
    // folds case AND pads — so a DISTINCT over it counted `[X, x]`, `[X, "X "]`
    // and `[x, X, "X "]` as ONE entry, in the same statement whose other three
    // clauses exist to stop exactly that. JSON_QUOTE neither folds nor pads.
    assert.equal(/COUNT\(DISTINCT d\.id, r\.site_ref\)/.test(statement), false);
    assert.match(statement, /JSON_QUOTE\(r\.site_ref\)/);
  });

  it('treats an element it cannot read as an entry rather than as absent', () => {
    // `PATH '$'` on an object or a nested array yields NULL, indistinguishable
    // from a JSON `null` element — and dropping both made `[{}]` read as "every
    // datacenter". FOR ORDINALITY is what tells them apart.
    assert.match(statement, /pos FOR ORDINALITY/);
    assert.match(statement, /JSON_TYPE\(JSON_EXTRACT\(d\.dc_refs, CONCAT\('\$\[', r\.pos - 1, '\]'\)\)\) IN \('OBJECT', 'ARRAY'\)/);
  });
});

// ── the site delete reference sweep ─────────────────────────────────────────
// The sweep names `id`, a display column and a reference column per group, all
// interpolated as identifiers. A wrong one is an unknown-column error that
// fail-closes both the preview AND the delete — and every double in the mocked
// runner would answer it happily.
describe('site delete reference sweep — schema parity', () => {
  const { SITE_REFERENCE_GROUPS } = require('../../../../src/edge/routes/app/capacity/site-references');

  it('declares the kinds it sweeps — not a claim that these are the only ones', () => {
    assert.deepEqual(
      SITE_REFERENCE_GROUPS.map((g) => g.kind).sort(),
      ['database_dc_ref', 'hypervisor', 'rule_site_pin', 'vm'],
    );
  });

  it('every group names real columns on a real scenario-scoped table', () => {
    for (const group of SITE_REFERENCE_GROUPS) {
      const cols = columnsByTable.get(String(group.table));
      assert.ok(cols, `sweep group ${group.kind} references unknown table ${group.table}`);
      assert.ok(cols.has('id'), `${group.table} has no id`);
      assert.ok(cols.has('scenario_id'), `${group.table} has no scenario_id (the sweep scopes on it)`);
      assert.ok(cols.has(group.column), `${group.table} has no column '${group.column}'`);
      assert.ok(cols.has(group.nameCol), `${group.table} has no display column '${group.nameCol}'`);
    }
  });

  it('every group declares a disposition the delete knows how to act on', () => {
    for (const group of SITE_REFERENCE_GROUPS) {
      assert.ok(['block', 'unplace', 'cascade'].includes(group.disposition),
        `sweep group ${group.kind} declares an unknown disposition '${group.disposition}'`);
    }
  });

  it('no group pairs unplace with a JSON shape (the boot guard would reject it)', () => {
    // `SET col = NULL` clears a scalar; an unplace on a JSON list or a JSON-object
    // field would null the whole column to clear one entry it names. _shared.js
    // throws at import for such a pairing — this pins the same invariant at the
    // declaration so a bad group is caught before boot.
    for (const group of SITE_REFERENCE_GROUPS) {
      assert.ok(!(group.disposition === 'unplace' && (group.jsonList || group.jsonObjectPath)),
        `sweep group ${group.kind} unplaces a JSON reference the NULL statement cannot clear`);
    }
  });
});
