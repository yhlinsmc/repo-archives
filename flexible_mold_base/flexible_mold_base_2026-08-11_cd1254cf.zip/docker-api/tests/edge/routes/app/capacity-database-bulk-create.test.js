/**
 * capacity-database-bulk-create.test.js — the Add-Database wizard's transactional
 * persist endpoint (placement-hub spec §3/§11).
 *
 * Two layers:
 *   1. PURE buildDatabaseBulkPlan — payload validation, topology cardinality
 *      (spec §10.1, single/primary_standby/rac), placement shape (exactly one of
 *      vm_id | new_vm), standby-only-under-primary_standby, bounds.
 *   2. Route behaviour against a mock edge/db — happy-path materialization in ONE
 *      transaction (database + instances + new db_host VMs), all-or-nothing (a
 *      mid-transaction failure rolls back everything), reference-integrity 400,
 *      permission gating (plain user 403, missing scenario 404).
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

// ── Mock edge/db BEFORE requiring the router ──────────────────────────────────
const dbKey = require.resolve('../../../../src/edge/db');

let state;
function freshState() {
  return {
    queries: [],
    began: 0, committed: 0, rolledBack: 0, released: 0,
    // resolveScenarioWriteAccess: SELECT id, owner_id FROM cap_scenarios.
    scenarioFound: true,
    scenarioOwnerId: null, // null = shared (any editor/admin may write)
    // §17.1a reference probe knobs.
    refFound: true,          // does every referenced row exist?
    refForeignScenario: false, // force a scenario-mode ref to a foreign scenario
    vmType: 'db_host',       // vm_type a cap_vms reference probe reports
    // Sizing hydration fixtures.
    profiles: {},            // id → { class, mode, cpu, mem_gb, sga_cap_gb, allowed_disk_combos }
    combos: {},              // id → sizes JSON
    settingsRow: null,
    hypervisorSiteId: 'site-1',
    // A table whose INSERT throws (simulate a mid-transaction DB failure).
    throwOnInsertInto: null,
  };
}

const conn = {
  async beginTransaction() { state.began += 1; },
  async commit() { state.committed += 1; },
  async rollback() { state.rolledBack += 1; },
  release() { state.released += 1; },
  async query(sql, params = []) {
    state.queries.push({ sql, params });

    // resolveScenarioWriteAccess.
    if (/^SELECT id, owner_id FROM `fmb_cap_scenarios` WHERE id = \?/.test(sql)) {
      if (!state.scenarioFound) return [];
      return [{ id: params[0], owner_id: state.scenarioOwnerId }];
    }

    // §17.1a reference-integrity probe (with the FOR-UPDATE lock).
    if (/SELECT id, scenario_id(?:, vm_type)?, \(scenario_id = \?\) AS same_scenario[\s\S]*FROM `fmb_(cap_[a-z_]+)` WHERE id = \?/.test(sql)) {
      if (!state.refFound) return [];
      const table = RegExp.$1;
      const [referencingScenarioId, id] = params;
      // Catalogue tables answer global (scenario_id NULL); scenario-internal
      // tables answer same-scenario unless a foreign-scenario ref is forced.
      const isCatalogue = /vm_profiles|disk_combos|teams|hardware_specs/.test(table);
      const owner = isCatalogue ? null
        : (state.refForeignScenario ? 'other-scenario' : referencingScenarioId);
      const same = owner == null || referencingScenarioId == null
        ? null
        : (String(owner).toLowerCase() === String(referencingScenarioId).toLowerCase() ? 1 : 0);
      const row = { id, scenario_id: owner, same_scenario: same };
      if (/vm_type/.test(sql)) row.vm_type = state.vmType;
      return [row];
    }

    // loadSizingContext: profiles IN (...).
    if (/^SELECT id, class, mode, cpu, mem_gb, sga_cap_gb, allowed_disk_combos FROM `fmb_cap_vm_profiles` WHERE id IN/.test(sql)) {
      return params.filter((id) => state.profiles[id]).map((id) => ({ id, ...state.profiles[id] }));
    }
    // loadSizingContext: disk combos IN (...).
    if (/^SELECT id, sizes FROM `fmb_cap_disk_combos` WHERE id IN/.test(sql)) {
      return params.filter((id) => state.combos[id] != null).map((id) => ({ id, sizes: state.combos[id] }));
    }
    // loadSizingContext: scenario-effective settings.
    if (/FROM `fmb_cap_settings` WHERE scenario_id = \? OR scenario_id IS NULL/.test(sql)) {
      return state.settingsRow ? [state.settingsRow] : [];
    }
    // New-VM site derivation from its host.
    if (/^SELECT site_id FROM `fmb_cap_hypervisors` WHERE id = \? LIMIT 1 FOR UPDATE/.test(sql)) {
      return [{ site_id: state.hypervisorSiteId }];
    }
    // nextOrderIndex.
    if (/COALESCE\(MAX\(order_index\), -1\) \+ 1 AS next/.test(sql)) {
      return [{ next: 0 }];
    }

    const insertMatch = sql.match(/^INSERT INTO `fmb_(cap_[a-z_]+)`/);
    if (insertMatch) {
      if (state.throwOnInsertInto && insertMatch[1] === state.throwOnInsertInto) {
        const e = new Error('simulated insert failure');
        e.errno = 1213;
        throw e;
      }
      return { affectedRows: 1, insertId: 1 };
    }
    return [];
  },
};

const poolFacade = {
  getConnection: async () => conn,
  query: (sql, params) => conn.query(sql, params),
};
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: { ro: poolFacade, rw: poolFacade }, t: (n) => `fmb_${n}` },
};

const bulk = require('../../../../src/edge/routes/app/capacity/database-bulk-create');
const router = require('../../../../src/edge/routes/app/capacity');
const { buildDatabaseBulkPlan } = bulk;

const SCENARIO = '11111111-1111-1111-1111-111111111111';
const HV = '22222222-2222-2222-2222-222222222222';
const EXISTING_VM = '33333333-3333-3333-3333-333333333333';
const PROF_DB = '44444444-4444-4444-4444-444444444444';
const PROF_AP = '55555555-5555-5555-5555-555555555555';
const COMBO_OK = '66666666-6666-6666-6666-666666666666';
const COMBO_BAD = '77777777-7777-7777-7777-777777777777';

// New-VM placement onto a hypervisor (the common step-3 choice). Every FK value
// must be UUID-shaped — the endpoint runs the identifier floor via checkReferences.
const placed = (name, hv = HV) => ({ new_vm: { name, hypervisor_id: hv } });

// Every default payload names a database profile_id — it is REQUIRED (this
// finding: a null/absent profile_id used to persist a zero-sized VM/instance
// chain via a direct POST, bypassing the wizard's client-only gate). Tests that
// exercise the missing-profile 400 override `database` explicitly.
function singlePayload(overrides = {}) {
  return {
    database: { function_name: 'erp', topology: 'single', profile_id: PROF_DB },
    instances: [{ name: 'erp1', role: 'primary', placement: placed('erp-db-1') }],
    ...overrides,
  };
}

function primaryStandbyPayload() {
  return {
    database: { function_name: 'mes', topology: 'primary_standby', profile_id: PROF_DB },
    instances: [
      { name: 'mes1', role: 'primary', placement: placed('mes-db-1') },
      { name: 'mes2', role: 'primary', placement: placed('mes-db-2') },
      { name: 'mes1', role: 'standby', placement: placed('mes-db-3') },
      { name: 'mes2', role: 'standby', placement: placed('mes-db-4') },
    ],
  };
}

function racPayload(nodeCount = 3) {
  const instances = [];
  for (let i = 1; i <= nodeCount; i += 1) {
    instances.push({ name: `rac${i}`, role: 'primary', placement: placed(`rac-db-${i}`) });
  }
  return { database: { function_name: 'rac', topology: 'rac', node_count: nodeCount, profile_id: PROF_DB }, instances };
}

// ── Route harness ─────────────────────────────────────────────────────────────
let currentUser; let server; let baseUrl;
before(async () => {
  const app = express();
  app.use(express.json({ limit: '10mb' }));
  app.use((req, _res, next) => { req.user = currentUser; next(); });
  app.use('/capacity', router);
  server = http.createServer(app);
  await new Promise((r) => server.listen(0, r));
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});
after(() => server && server.close());
beforeEach(() => {
  state = freshState();
  currentUser = { id: 'u-admin', role: 'admin' };
});

function request(method, path, body) {
  return new Promise((resolve, reject) => {
    const payload = body === undefined ? '' : JSON.stringify(body);
    const r = http.request(
      `${baseUrl}${path}`,
      { method, headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) } },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          const raw = Buffer.concat(chunks).toString('utf8');
          let json = null;
          try { json = JSON.parse(raw); } catch { /* noop */ }
          resolve({ status: res.statusCode, json, raw });
        });
      },
    );
    r.on('error', reject);
    if (payload) r.write(payload);
    r.end();
  });
}

const post = (body) => request('POST', `/capacity/scenarios/${SCENARIO}/databases/bulk-create`, body);
const insertsInto = (table) => state.queries.filter((q) => new RegExp(`^INSERT INTO \`fmb_${table}\``).test(q.sql));
const anyEntityInsert = () => state.queries.some((q) => /^INSERT INTO `fmb_cap_/.test(q.sql));

// ── 1. PURE plan validation ───────────────────────────────────────────────────
describe('buildDatabaseBulkPlan — topology cardinality (spec §10.1)', () => {
  it('accepts a well-formed single database', () => {
    const out = buildDatabaseBulkPlan(singlePayload());
    assert.equal(out.ok, true, JSON.stringify(out.errors));
    assert.equal(out.plan.instances.length, 1);
    assert.equal(out.plan.newVms.length, 1);
  });

  it('accepts a full primary_standby cluster (2 primary + 2 standby)', () => {
    const out = buildDatabaseBulkPlan(primaryStandbyPayload());
    assert.equal(out.ok, true, JSON.stringify(out.errors));
    assert.equal(out.plan.instances.length, 4);
  });

  it('accepts a RAC cluster of node_count primary instances', () => {
    const out = buildDatabaseBulkPlan(racPayload(3));
    assert.equal(out.ok, true, JSON.stringify(out.errors));
    assert.equal(out.plan.instances.filter((i) => i.role === 'primary').length, 3);
  });

  it('rejects the wrong instance count for a topology', () => {
    const out = buildDatabaseBulkPlan(singlePayload({
      instances: [
        { name: 'a', role: 'primary', placement: placed('a') },
        { name: 'b', role: 'primary', placement: placed('b') },
      ],
    }));
    assert.equal(out.ok, false);
    assert.ok(out.errors.some((e) => /expected 1 primary/.test(e)), JSON.stringify(out.errors));
  });

  it('rejects a standby under a non-primary_standby topology', () => {
    const out = buildDatabaseBulkPlan(singlePayload({
      instances: [{ name: 'a', role: 'standby', placement: placed('a') }],
    }));
    assert.equal(out.ok, false);
    assert.ok(out.errors.some((e) => /standby instance is only allowed/.test(e)));
  });

  it('rejects a placement that names both vm_id and new_vm', () => {
    const out = buildDatabaseBulkPlan(singlePayload({
      instances: [{ name: 'a', role: 'primary', placement: { vm_id: 'v', new_vm: { name: 'n' } } }],
    }));
    assert.equal(out.ok, false);
    assert.ok(out.errors.some((e) => /exactly one of vm_id or new_vm/.test(e)));
  });

  it('rejects a missing placement (an instance must attach to a db_host VM)', () => {
    const out = buildDatabaseBulkPlan(singlePayload({
      instances: [{ name: 'a', role: 'primary' }],
    }));
    assert.equal(out.ok, false);
    assert.ok(out.errors.some((e) => /placement is required/.test(e)));
  });

  it('413-shapes an oversized instances array', () => {
    const instances = Array.from({ length: 200 }, (_, i) => ({ name: `n${i}`, role: 'primary', placement: placed(`n${i}`) }));
    const out = buildDatabaseBulkPlan(singlePayload({ instances }));
    assert.equal(out.ok, false);
    assert.equal(out.tooLarge, true);
  });

  it('accepts an existing-VM placement (no new VM minted)', () => {
    const out = buildDatabaseBulkPlan(singlePayload({
      instances: [{ name: 'a', role: 'primary', placement: { vm_id: EXISTING_VM } }],
    }));
    assert.equal(out.ok, true, JSON.stringify(out.errors));
    assert.equal(out.plan.newVms.length, 0);
    assert.equal(out.plan.instances[0].placement.existingVmId, EXISTING_VM);
  });

  it('rejects a rac node_count out of range', () => {
    assert.equal(buildDatabaseBulkPlan(racPayload(1)).ok, false);
    assert.equal(buildDatabaseBulkPlan(racPayload(101)).ok, false);
  });

  it('rejects a null database.profile_id (COLUMN_REQUIRED)', () => {
    const out = buildDatabaseBulkPlan(singlePayload({
      database: { function_name: 'erp', topology: 'single', profile_id: null },
    }));
    assert.equal(out.ok, false);
    assert.equal(out.columnRequiredMessage, 'database: profile_id is required');
    assert.ok(out.errors.some((e) => /profile_id is required/.test(e)), JSON.stringify(out.errors));
  });

  it('rejects an absent database.profile_id the same way as an explicit null', () => {
    const out = buildDatabaseBulkPlan(singlePayload({
      database: { function_name: 'erp', topology: 'single' },
    }));
    assert.equal(out.ok, false);
    assert.equal(out.columnRequiredMessage, 'database: profile_id is required');
  });
});

// ── 2. Route behaviour ────────────────────────────────────────────────────────
describe('POST .../databases/bulk-create — one transaction', () => {
  it('materializes a single database + instance + new VM and returns their ids', async () => {
    const res = await post(singlePayload());
    assert.equal(res.status, 201, res.raw);
    const data = res.json.data;
    assert.ok(data.database.id);
    assert.equal(data.instances.length, 1);
    assert.equal(data.vms.length, 1);
    assert.equal(data.instances[0].vm_id, data.vms[0].id, 'instance attaches to the created VM');
    assert.equal(state.committed, 1);
    assert.equal(state.rolledBack, 0);
    assert.equal(insertsInto('cap_databases').length, 1);
    assert.equal(insertsInto('cap_vms').length, 1);
    assert.equal(insertsInto('cap_db_instances').length, 1);
  });

  it('materializes a primary_standby cluster: 1 db + 4 instances + 4 VMs', async () => {
    const res = await post(primaryStandbyPayload());
    assert.equal(res.status, 201, res.raw);
    assert.equal(insertsInto('cap_databases').length, 1);
    assert.equal(insertsInto('cap_vms').length, 4);
    assert.equal(insertsInto('cap_db_instances').length, 4);
    assert.equal(state.committed, 1);
  });

  it('materializes a RAC cluster of 3 nodes', async () => {
    const res = await post(racPayload(3));
    assert.equal(res.status, 201, res.raw);
    assert.equal(insertsInto('cap_db_instances').length, 3);
    assert.equal(insertsInto('cap_vms').length, 3);
  });

  it('400s the wrong instance count and writes nothing', async () => {
    const res = await post(singlePayload({
      instances: [
        { name: 'a', role: 'primary', placement: placed('a') },
        { name: 'b', role: 'primary', placement: placed('b') },
      ],
    }));
    assert.equal(res.status, 400, res.raw);
    assert.equal(anyEntityInsert(), false);
    assert.equal(state.began, 0, 'validation fails before the transaction opens');
  });

  it('rolls back everything on a mid-transaction lock-race failure (409 WRITE_CONFLICT, zero rows committed)', async () => {
    state.throwOnInsertInto = 'cap_db_instances'; // fail on the LAST insert, errno 1213 (deadlock victim)
    const res = await post(singlePayload());
    assert.equal(res.status, 409, res.raw);
    assert.equal(res.json.error.code, 'WRITE_CONFLICT');
    assert.equal(insertsInto('cap_databases').length, 1, 'the failure is genuinely mid-transaction');
    assert.equal(insertsInto('cap_vms').length, 1);
    assert.equal(state.committed, 0, 'nothing is committed');
    assert.equal(state.rolledBack, 1, 'the whole transaction rolls back');
  });

  it('403s a plain (non-editor) user before opening a transaction', async () => {
    currentUser = { id: 'u1', role: 'user' };
    const res = await post(singlePayload());
    assert.equal(res.status, 403, res.raw);
    assert.equal(state.began, 0);
    assert.equal(anyEntityInsert(), false);
  });

  it('404s a missing scenario and writes nothing', async () => {
    state.scenarioFound = false;
    const res = await post(singlePayload());
    assert.equal(res.status, 404, res.raw);
    assert.equal(anyEntityInsert(), false);
    assert.equal(state.rolledBack, 1);
  });

  it('201s an editor who IS the scenario owner', async () => {
    // owner_id byte-identical to the actor → owner.
    currentUser = { id: 'editor-a', role: 'editor' };
    state.scenarioOwnerId = 'editor-a';
    const own = await post(singlePayload());
    assert.equal(own.status, 201, own.raw);
  });

  it('403s an editor who is NOT the scenario owner', async () => {
    // owner_id a different byte string than the actor → not the owner, not shared.
    currentUser = { id: 'editor-a', role: 'editor' };
    state.scenarioOwnerId = 'editor-b';
    const res = await post(singlePayload());
    assert.equal(res.status, 403, res.raw);
    assert.equal(anyEntityInsert(), false);
    assert.equal(state.rolledBack, 1, 'the FOR-UPDATE-locked authz gate rolls back before any insert');
  });

  it('400s a foreign / missing reference and writes nothing', async () => {
    state.refFound = false; // the hypervisor reference does not resolve
    const res = await post(singlePayload());
    assert.equal(res.status, 400, res.raw);
    assert.equal(anyEntityInsert(), false);
    assert.equal(state.rolledBack, 1);
  });

  it('400s a disk combo outside the profile allow-list and writes nothing', async () => {
    state.profiles = { [PROF_DB]: { class: 'DB', mode: 'formula', cpu: 4, mem_gb: 80, sga_cap_gb: 30, allowed_disk_combos: JSON.stringify([COMBO_OK]) } };
    const res = await post(singlePayload({
      database: { function_name: 'erp', topology: 'single', profile_id: PROF_DB, disk_combo_id: COMBO_BAD },
    }));
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'DISK_COMBO_NOT_ALLOWED');
    assert.equal(anyEntityInsert(), false);
  });

  it('400s an AP-class database profile (class coherence)', async () => {
    state.profiles = { [PROF_AP]: { class: 'AP', mode: 'formula', cpu: 4, mem_gb: 80, sga_cap_gb: null, allowed_disk_combos: null } };
    const res = await post(singlePayload({
      database: { function_name: 'erp', topology: 'single', profile_id: PROF_AP },
    }));
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'INVALID_REFERENCE');
    assert.equal(anyEntityInsert(), false);
  });

  it('400s COLUMN_REQUIRED when database.profile_id is null and writes nothing', async () => {
    const res = await post(singlePayload({
      database: { function_name: 'erp', topology: 'single', profile_id: null },
    }));
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'COLUMN_REQUIRED');
    assert.match(res.json.error.message, /profile_id is required/);
    assert.equal(anyEntityInsert(), false);
    assert.equal(state.began, 0, 'validation fails before the transaction opens');
  });

  it('400s COLUMN_REQUIRED when database.profile_id is absent and writes nothing', async () => {
    const res = await post(singlePayload({
      database: { function_name: 'erp', topology: 'single' },
    }));
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'COLUMN_REQUIRED');
    assert.equal(anyEntityInsert(), false);
  });

  it('an absent new_vm.sizing_profile_id inherits database.profile_id and derives non-zero sizing', async () => {
    state.profiles = {
      [PROF_DB]: { class: 'DB', mode: 'formula', cpu: 4, mem_gb: 80, sga_cap_gb: 30, allowed_disk_combos: null },
    };
    const res = await post(singlePayload({
      instances: [{ name: 'erp1', role: 'primary', placement: { new_vm: { name: 'erp-db-1', hypervisor_id: HV } } }],
    }));
    assert.equal(res.status, 201, res.raw);
    const vmInsert = insertsInto('cap_vms')[0];
    const cols = bulk.INSERT_COLUMNS.cap_vms;
    const byCol = Object.fromEntries(cols.map((c, i) => [c, vmInsert.params[i]]));
    assert.equal(byCol.sizing_profile_id, PROF_DB, 'the new VM inherits the database profile_id');
    assert.ok(byCol.cpu > 0, `expected non-zero derived cpu, got ${byCol.cpu}`);
    assert.ok(byCol.mem_gb > 0, `expected non-zero derived mem_gb, got ${byCol.mem_gb}`);
  });

  it('an explicit new_vm.sizing_profile_id is NOT overridden by inheritance and still runs the class check', async () => {
    state.profiles = {
      [PROF_AP]: { class: 'AP', mode: 'formula', cpu: 4, mem_gb: 80, sga_cap_gb: null, allowed_disk_combos: null },
    };
    const res = await post(singlePayload({
      instances: [{
        name: 'erp1',
        role: 'primary',
        placement: { new_vm: { name: 'erp-db-1', hypervisor_id: HV, sizing_profile_id: PROF_AP } },
      }],
    }));
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'INVALID_REFERENCE');
    assert.equal(anyEntityInsert(), false);
  });
});
