/**
 * degraded-schema-optional-column-probe.test.js — structural closure of the
 * degraded-schema family (fmb-1645). Pure static analysis, NO live DB.
 *
 * THE INVARIANT: a warn-skipped `add-column` migration (operator lacks DDL
 * privilege, severity 'warning') leaves the column PHYSICALLY ABSENT. Any SQL
 * that names such a column — read OR write — 500s with ER_BAD_FIELD_ERROR (1054)
 * on that database. Five sites of this family were fixed one review round at a
 * time; this test replaces whack-a-mole with a mechanical assertion: EVERY SQL
 * string naming an optional column must have a degraded-mode probe in scope.
 *
 * The optional-column list is DERIVED from the migration registry (add-column +
 * severity 'warning'), never hand-written — a new warn-severity column is picked
 * up automatically, and a site added for it without a probe fails this test.
 *
 * Recognised probe mechanisms (file-level, matching the brief's granularity):
 *   - tableColumnSet / dropAbsentColumns  — capacity _shared writer-probing helpers
 *   - getActualColumnSet                  — schema helpers' information_schema probe,
 *                                           called by the schema routes
 *   - information_schema (a COLUMNS probe the file runs itself)
 *   - reactive missing-column fallback    — the statement is wrapped in a catch that
 *                                           degrades on ER_BAD_FIELD_ERROR / errno 1054
 *                                           (blueprint compute-rule / serialization libs)
 *   - // probe-exempt: <reason>           — explicit opt-out; the reason is MANDATORY
 *                                           and must NAME the mechanism that handles
 *                                           degradation. Grep-able; currently unused.
 * Mechanism tokens are matched against COMMENT-STRIPPED source, so a token named
 * only in prose does not count as evidence (the pragma is the one exception — it
 * IS a comment by design, and is matched against the raw source).
 *
 * The matcher is deliberately over-inclusive on WHAT it flags (any SQL-looking
 * string naming the column) and coarse on evidence (file-level).
 *
 * KNOWN BLIND SPOTS — this test claims family coverage at FILE granularity, not
 * proof that every statement is guarded:
 *   - File-level evidence, not statement-level. A file that probes SOMEWHERE
 *     passes for ALL its optional-column SQL. A single unprobed statement inside
 *     an otherwise-probing file is NOT caught — the routes-variant-overrides.js
 *     `by-variants` batch read was exactly that (getActualColumnSet in sibling
 *     handlers, none on that one) and it took a human reviewer, not this test.
 *   - Dynamic / split column names. A column list assembled from payload keys
 *     (the capacity settings/config writers), a `SELECT ${column}`, or the name
 *     held in a separate string const outside the SQL-verb span, is invisible to
 *     a literal-name matcher — the same blind spot the census has. Those sites
 *     are covered by dropAbsentColumns / the column-by-column fallback regardless.
 *   - Only `.js` under docker-api/src is scanned; a `.sql` file (none today) is not.
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');

const SRC = path.resolve(__dirname, '../../src');
const { MIGRATION_STEPS } = require('../../src/edge/migration-steps');

// ── optional-column list, derived mechanically from the migration registry ──
function deriveOptionalColumns() {
  const cols = new Set();
  for (const step of MIGRATION_STEPS) {
    if (step && step.kind === 'add-column' && step.severity === 'warning' && step.column) {
      cols.add(String(step.column));
    }
  }
  return cols;
}

// ── comment-safe scanning ────────────────────────────────────────────────────
// A single char-state machine underlies both helpers. Comment-exclusion is the
// point: this codebase's prose comments are full of apostrophes, example SQL, and
// mechanism names, which a raw regex would mis-read.

// Every string / template-literal span found in CODE (comments excluded), each
// with its 1-based start line.
function extractCodeStrings(src) {
  const out = [];
  const n = src.length;
  let i = 0;
  let line = 1;
  const S = { NORMAL: 0, LINE: 1, BLOCK: 2, SINGLE: 3, DOUBLE: 4, TMPL: 5 };
  let state = S.NORMAL;
  let buf = '';
  let startLine = 0;
  while (i < n) {
    const c = src[i];
    const c2 = src[i + 1];
    if (c === '\n') line += 1;
    switch (state) {
      case S.NORMAL:
        if (c === '/' && c2 === '/') { state = S.LINE; i += 2; break; }
        if (c === '/' && c2 === '*') { state = S.BLOCK; i += 2; break; }
        if (c === "'") { state = S.SINGLE; buf = ''; startLine = line; i += 1; break; }
        if (c === '"') { state = S.DOUBLE; buf = ''; startLine = line; i += 1; break; }
        if (c === '`') { state = S.TMPL; buf = ''; startLine = line; i += 1; break; }
        i += 1; break;
      case S.LINE:
        if (c === '\n') state = S.NORMAL;
        i += 1; break;
      case S.BLOCK:
        if (c === '*' && c2 === '/') { state = S.NORMAL; i += 2; break; }
        i += 1; break;
      case S.SINGLE:
        if (c === '\\') { buf += c + (c2 ?? ''); i += 2; break; }
        if (c === "'") { out.push({ text: buf, line: startLine }); state = S.NORMAL; i += 1; break; }
        buf += c; i += 1; break;
      case S.DOUBLE:
        if (c === '\\') { buf += c + (c2 ?? ''); i += 2; break; }
        if (c === '"') { out.push({ text: buf, line: startLine }); state = S.NORMAL; i += 1; break; }
        buf += c; i += 1; break;
      case S.TMPL:
        // Naive to the next unescaped backtick — SQL template literals never carry
        // a nested backtick, so `${t(TABLES.X)}` interpolations are kept as text.
        if (c === '\\') { buf += c + (c2 ?? ''); i += 2; break; }
        if (c === '`') { out.push({ text: buf, line: startLine }); state = S.NORMAL; i += 1; break; }
        buf += c; i += 1; break;
      default: i += 1;
    }
  }
  return out;
}

// The source with comments blanked but strings/templates preserved verbatim, so a
// probe-mechanism token mentioned only in prose is not read as evidence.
function stripComments(src) {
  const n = src.length;
  let i = 0;
  let out = '';
  const S = { NORMAL: 0, LINE: 1, BLOCK: 2, SINGLE: 3, DOUBLE: 4, TMPL: 5 };
  let state = S.NORMAL;
  while (i < n) {
    const c = src[i];
    const c2 = src[i + 1];
    switch (state) {
      case S.NORMAL:
        if (c === '/' && c2 === '/') { state = S.LINE; i += 2; break; }
        if (c === '/' && c2 === '*') { state = S.BLOCK; i += 2; break; }
        if (c === "'") { state = S.SINGLE; out += c; i += 1; break; }
        if (c === '"') { state = S.DOUBLE; out += c; i += 1; break; }
        if (c === '`') { state = S.TMPL; out += c; i += 1; break; }
        out += c; i += 1; break;
      case S.LINE:
        if (c === '\n') { state = S.NORMAL; out += c; }
        i += 1; break;
      case S.BLOCK:
        if (c === '*' && c2 === '/') { state = S.NORMAL; i += 2; break; }
        if (c === '\n') out += c;
        i += 1; break;
      case S.SINGLE:
        out += c;
        if (c === '\\') { out += (c2 ?? ''); i += 2; break; }
        if (c === "'") state = S.NORMAL;
        i += 1; break;
      case S.DOUBLE:
        out += c;
        if (c === '\\') { out += (c2 ?? ''); i += 2; break; }
        if (c === '"') state = S.NORMAL;
        i += 1; break;
      case S.TMPL:
        out += c;
        if (c === '\\') { out += (c2 ?? ''); i += 2; break; }
        if (c === '`') state = S.NORMAL;
        i += 1; break;
      default: i += 1;
    }
  }
  return out;
}

const SQL_RE = /\b(SELECT|INSERT|UPDATE|DELETE)\b/i;

// Every optional-column reference inside an SQL-looking code string in one file.
function scanSource(src, cols) {
  const hits = [];
  for (const s of extractCodeStrings(src)) {
    if (!SQL_RE.test(s.text)) continue;
    for (const col of cols) {
      if (new RegExp(`\\b${col}\\b`, 'i').test(s.text)) hits.push({ col, line: s.line });
    }
  }
  return hits;
}

// Mechanism tokens are checked against comment-stripped code; the pragma is a
// comment by design, so it is checked against the raw source.
const PROBE_CODE_TOKENS = [
  /\btableColumnSet\b/,
  /\bdropAbsentColumns\b/,
  /\bgetActualColumnSet\b/,
  /information_schema/i,
  /\bER_BAD_FIELD_ERROR\b/,
  /errno\s*===?\s*1054/,
];
const PRAGMA_RE = /\/\/\s*probe-exempt:\s*\S/; // reason mandatory
function hasProbeEvidence(src) {
  if (PRAGMA_RE.test(src)) return true;
  const code = stripComments(src);
  return PROBE_CODE_TOKENS.some((re) => re.test(code));
}

// ── file walk ───────────────────────────────────────────────────────────────
const EXCLUDE = new Set([
  path.join(SRC, 'edge/migration-steps.js'), // the registry itself
  path.join(SRC, 'edge/migrations.js'), // the executor's own probes/DDL
  path.join(SRC, 'table-ddls.js'), // the schema authority (column DEFINITIONS)
  path.join(SRC, 'edge/db.js'), // DDL preflight
]);
function walk(dir, out = []) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, e.name);
    if (e.isDirectory()) {
      if (e.name === '__tests__' || e.name === 'node_modules') continue;
      walk(full, out);
    } else if (e.name.endsWith('.js') && !EXCLUDE.has(full)) {
      out.push(full);
    }
  }
  return out;
}

describe('degraded-schema optional-column probe closure (fmb-1645)', () => {
  const cols = deriveOptionalColumns();

  // Instrument check on the DERIVATION, as an EXACT tripwire, not a floor: a
  // silent shrink — a warn add-column dropped from the registry or its severity
  // flipped — is the regression this guards. Update this number DELIBERATELY when
  // the registry gains or loses a warn-severity add-column (and add the new site's
  // probe in the same change). name_patterns is the B5a column this closure exists
  // for; its membership proves the registry parse ran.
  it('derives the exact warn-severity add-column set from the migration registry', () => {
    assert.equal(
      cols.size, 8,
      `expected 8 warn-severity add-columns, got ${cols.size}: ${[...cols].join(', ')}`,
    );
    assert.ok(cols.has('name_patterns'), 'derivation must include name_patterns (fmb B5a)');
    assert.ok(cols.has('name_locked'), 'derivation must include name_locked (cap-renumber-lock)');
  });

  // Instrument check on the MATCHER + RECOGNISER, independent of any real file —
  // the "case proving the instrument works" an absence-shaped assertion needs.
  it('matcher flags an SQL string naming an optional column, and ignores comments', () => {
    assert.equal(scanSource('const q = `SELECT name_patterns FROM x WHERE id = ?`;', cols).length, 1);
    // A column named only in a comment must NOT be flagged (comment exclusion).
    assert.equal(scanSource('// SELECT name_patterns FROM x -- example\nconst q = 1;', cols).length, 0);
    // A non-SQL string naming the column must NOT be flagged.
    assert.equal(scanSource("const label = 'name_patterns column';", cols).length, 0);
  });
  it('probe recogniser accepts each mechanism, in code only, and rejects prose', () => {
    assert.equal(hasProbeEvidence('await dropAbsentColumns(pool.rw, T, c, v);'), true);
    assert.equal(hasProbeEvidence('await tableColumnSet(pool.rw, T);'), true);
    assert.equal(hasProbeEvidence('await getActualColumnSet(conn, phys);'), true);
    assert.equal(hasProbeEvidence("if (err.code === 'ER_BAD_FIELD_ERROR') return null;"), true);
    assert.equal(hasProbeEvidence('if (err.errno === 1054) return null;'), true);
    assert.equal(hasProbeEvidence('// probe-exempt: handled by X'), true);
    // The mechanism named only in PROSE is not evidence.
    assert.equal(hasProbeEvidence('// this used to throw ER_BAD_FIELD_ERROR before\nconst x = 1;'), false);
    assert.equal(hasProbeEvidence('const rows = await conn.query(`SELECT name_patterns FROM x`);'), false);
  });

  // ── the closure assertion ──────────────────────────────────────────────────
  it('every SQL string naming an optional column has a probe in scope', () => {
    const files = walk(SRC);
    // Instrument check: a broken walk() that reached near-zero files would pass the
    // closure vacuously. Coarse floor well under the real corpus (~271 today).
    assert.ok(files.length > 200, `walk() reached only ${files.length} .js files — coverage broken`);

    const unguarded = [];
    const flagged = new Set();
    let flaggedPairs = 0;
    for (const f of files) {
      const src = fs.readFileSync(f, 'utf8');
      const hits = scanSource(src, cols);
      if (!hits.length) continue;
      flagged.add(f);
      flaggedPairs += hits.length;
      if (hasProbeEvidence(src)) continue;
      const rel = path.relative(path.resolve(SRC, '..'), f);
      for (const h of hits) unguarded.push(`${rel}:${h.line} [${h.col}]`);
    }

    // Instrument check: the scan must reach real SQL sites — a zero means the walk
    // or the matcher broke, not that the codebase is clean.
    assert.ok(flaggedPairs > 0, 'scanner reached no optional-column SQL — instrument broken');

    // Sentinel files that MUST stay flagged: if the matcher silently stops seeing
    // these known optional-column sites, it has rotted. Each is flagged-and-guarded.
    for (const sentinel of [
      'capacity/renumber.js',
      'schema/routes-blueprint-fields.js',
      'schema/routes-variant-overrides.js',
    ]) {
      assert.ok(
        [...flagged].some((f) => f.endsWith(sentinel)),
        `sentinel no longer flagged (matcher rot?): ${sentinel}`,
      );
    }

    assert.deepEqual(
      unguarded, [],
      `SQL naming an optional column with no degraded-mode probe in scope:\n  ${unguarded.join('\n  ')}\n`
      + 'Add a probe (dropAbsentColumns / getActualColumnSet / information_schema / catch ER_BAD_FIELD_ERROR) '
      + 'or a "// probe-exempt: <reason>" pragma naming the mechanism that handles the column being absent.',
    );
  });
});
