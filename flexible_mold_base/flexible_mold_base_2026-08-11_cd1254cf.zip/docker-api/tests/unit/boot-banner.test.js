/**
 * boot-banner.test.js — v3.2.51 Q12 / T2 / T5 coverage for the
 * human-pretty multi-line boot banner shared by all three role entry
 * points.
 *
 * Pins the T2 override contract: the URL scheme is derived from
 * `BASE_URL` at boot, not a separate `EXTERNAL_SCHEME` env. Missing or
 * malformed BASE_URL fails fast with a structured ERROR/CAUSE/FIX
 * message so misconfigured pods surface at startup.
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const {
  deriveSchemeFromBaseUrl,
  validateFrontendUrl,
  sanitizeForBanner,
  buildBannerLines,
  printBootBanner,
} = require('../../src/shared/lib/boot-banner');

function makeCollectingLogger() {
  const records = [];
  return {
    records,
    info: (msg) => records.push(msg),
    warn: () => {},
    error: () => {},
  };
}

// v3.2.54 PR-2: every buildBannerLines call needs appName now. Central
// helper so tests stay terse. Callers override via spread when they
// want to exercise the appName-missing path.
const DEFAULT_APP_NAME = 'Flexible Mold Base';

describe('deriveSchemeFromBaseUrl — T2 override', () => {
  it('returns https for https URL', () => {
    assert.equal(deriveSchemeFromBaseUrl('https://api.example.com'), 'https');
  });

  it('returns http for http URL', () => {
    assert.equal(deriveSchemeFromBaseUrl('http://localhost:3200'), 'http');
  });

  it('handles URL with port and path', () => {
    assert.equal(
      deriveSchemeFromBaseUrl('https://zonea-fmb-api.localhost:443/v1/'),
      'https',
    );
  });

  it('throws ERROR/CAUSE/FIX when BASE_URL is empty', () => {
    assert.throws(
      () => deriveSchemeFromBaseUrl(''),
      /ERROR: BASE_URL env not set[\s\S]+CAUSE[\s\S]+FIX/,
    );
  });

  it('throws ERROR/CAUSE/FIX when BASE_URL is undefined', () => {
    assert.throws(
      () => deriveSchemeFromBaseUrl(undefined),
      /ERROR: BASE_URL env not set[\s\S]+CAUSE[\s\S]+FIX/,
    );
  });

  it('throws on malformed URL', () => {
    assert.throws(
      () => deriveSchemeFromBaseUrl('not a url'),
      /ERROR: BASE_URL='not a url' is not a valid URL[\s\S]+CAUSE[\s\S]+FIX/,
    );
  });

  it('throws on non-http scheme (file://)', () => {
    assert.throws(
      () => deriveSchemeFromBaseUrl('file:///etc/passwd'),
      /scheme 'file' is not http\/https/,
    );
  });

  it('throws on non-http scheme (javascript:)', () => {
    assert.throws(
      () => deriveSchemeFromBaseUrl('javascript:alert(1)'),
      /scheme 'javascript' is not http\/https/,
    );
  });
});

describe('buildBannerLines — T5 human-pretty multi-line format', () => {
  const base = {
    role: 'INFRA',
    port: 3200,
    appName: DEFAULT_APP_NAME,
    scheme: 'https',
    externalHost: 'api.example.com',
    podHostname: 'fmb-infra-abc123',
    colour: false, // disable ANSI for deterministic substring match
  };

  it('emits banner header + role + port + internal + external + health + pod', () => {
    const lines = buildBannerLines(base);
    const joined = lines.join('\n');
    assert.match(joined, /Flexible Mold Base/);
    assert.match(joined, /role INFRA/);
    assert.match(joined, /port\s*:\s*3200/);
    assert.match(joined, /internal\s*:\s*http:\/\/0\.0\.0\.0:3200/);
    assert.match(joined, /external\s*:\s*https:\/\/api\.example\.com\/api\/\*/);
    assert.match(joined, /health\s*:\s*http:\/\/0\.0\.0\.0:3200\/health/);
    assert.match(joined, /pod\s*:\s*fmb-infra-abc123/);
  });

  it('v3.2.54 PR-2: appName param required — missing throws', () => {
    assert.throws(
      () => buildBannerLines({ ...base, appName: undefined }),
      /ERROR: buildBannerLines called without appName/,
    );
    assert.throws(
      () => buildBannerLines({ ...base, appName: '' }),
      /ERROR: buildBannerLines called without appName/,
    );
  });

  it('v3.2.54 PR-2: appName renders in banner header — no hardcoded "Flexible Mold Base"', () => {
    const lines = buildBannerLines({ ...base, appName: 'Acme Widgets' });
    const joined = lines.join('\n');
    assert.match(joined, /Acme Widgets/);
    assert.doesNotMatch(joined, /Flexible Mold Base/);
  });

  it("FRONTEND external row shows frontendUrl (v3.2.54 PR-2)", () => {
    const lines = buildBannerLines({
      ...base,
      role: 'FRONTEND',
      port: 3000,
      frontendUrl: 'https://zonea-fmb-web.localhost/',
    });
    const joined = lines.join('\n');
    assert.match(joined, /external\s*:\s*https:\/\/zonea-fmb-web\.localhost\//);
    // Must NOT fall back to the v3.2.52c placeholder string.
    assert.doesNotMatch(joined, /static SPA, no API role/);
    // Must NOT leak the INFRA base.scheme/externalHost through the FRONTEND row.
    assert.doesNotMatch(joined, /api\.example\.com/);
  });

  it("EDGE external row shows 'internal S2S only' (no external URL)", () => {
    const lines = buildBannerLines({ ...base, role: 'EDGE', port: 3201 });
    const joined = lines.join('\n');
    assert.match(joined, /external\s*:\s*internal S2S only/);
    // Must NOT include a bare https://api URL for the edge role
    const externalLine = lines.find((l) => l.startsWith('  external'));
    assert.ok(externalLine);
    assert.doesNotMatch(externalLine, /https?:\/\/[^\s]+$/);
  });

  it('deps summary rows render below the base fields', () => {
    const lines = buildBannerLines({
      ...base,
      depsSummary: ['DB: ready', 'Keycloak: reachable'],
    });
    const joined = lines.join('\n');
    assert.match(joined, /deps\s*:\s*DB: ready/);
    assert.match(joined, /Keycloak: reachable/);
  });

  it('colour=true includes ANSI escape sequences; colour=false strips them', () => {
    const coloured = buildBannerLines({ ...base, colour: true }).join('\n');
    const plain = buildBannerLines({ ...base, colour: false }).join('\n');
    assert.match(coloured, /\u001b\[/);
    assert.doesNotMatch(plain, /\u001b\[/);
  });

  it('banner framing lines are present (top and bottom)', () => {
    const lines = buildBannerLines(base);
    // Top and bottom separator lines begin with the box character.
    const frames = lines.filter((l) => /^═+$/.test(l.trim()));
    assert.ok(frames.length >= 2, 'expected at least top+bottom frame lines');
  });
});

describe('validateFrontendUrl — v3.2.54 PR-2 parallel to BASE_URL guard', () => {
  it('returns origin-with-slash for a well-formed https URL', () => {
    assert.equal(
      validateFrontendUrl('https://zonea-fmb-web.localhost'),
      'https://zonea-fmb-web.localhost/',
    );
  });

  it('accepts http scheme too', () => {
    assert.equal(
      validateFrontendUrl('http://localhost:3000'),
      'http://localhost:3000/',
    );
  });

  it('throws ERROR/CAUSE/FIX on missing value', () => {
    assert.throws(
      () => validateFrontendUrl(undefined),
      /ERROR: FRONTEND_URL env not set[\s\S]+CAUSE[\s\S]+FIX/,
    );
  });

  it('throws on malformed URL', () => {
    assert.throws(
      () => validateFrontendUrl('not a url'),
      /ERROR: FRONTEND_URL='not a url' is not a valid URL[\s\S]+CAUSE[\s\S]+FIX/,
    );
  });

  it('throws on non-http/https scheme (javascript:)', () => {
    assert.throws(
      () => validateFrontendUrl('javascript:alert(1)'),
      /scheme 'javascript' is not http\/https/,
    );
  });
});

describe('sanitizeForBanner — v3.2.54 PR-2 ANSI/C0 strip', () => {
  it('strips ANSI CSI escape codes', () => {
    assert.equal(sanitizeForBanner('hello\x1b[31mworld'), 'hello[31mworld');
  });

  it('strips C0 controls (NUL, BEL, BS, etc.)', () => {
    assert.equal(sanitizeForBanner('a\x00b\x07c\x08d'), 'abcd');
  });

  it('strips DEL and C1', () => {
    assert.equal(sanitizeForBanner('x\x7fy\x9az'), 'xyz');
  });

  it('leaves ordinary characters alone', () => {
    assert.equal(
      sanitizeForBanner('Flexible Mold Base'),
      'Flexible Mold Base',
    );
  });
});

describe('printBootBanner — v3.2.51a role-branch regression pins + v3.2.54 PR-2', () => {
  // Helpers restore env after each case. Tests pin LOG_COLOR=0 so ANSI
  // escapes don't break substring matching. v3.2.54 PR-2: APP_NAME is
  // now required for every role so restore that too.
  function withEnv({ baseUrl, frontendUrl, appName = DEFAULT_APP_NAME }, fn) {
    const prev = {
      BASE_URL: process.env.BASE_URL,
      FRONTEND_URL: process.env.FRONTEND_URL,
      APP_NAME: process.env.APP_NAME,
      LOG_COLOR: process.env.LOG_COLOR,
    };
    if (baseUrl === undefined) delete process.env.BASE_URL;
    else process.env.BASE_URL = baseUrl;
    if (frontendUrl === undefined) delete process.env.FRONTEND_URL;
    else process.env.FRONTEND_URL = frontendUrl;
    if (appName === null) delete process.env.APP_NAME;
    else process.env.APP_NAME = appName;
    process.env.LOG_COLOR = '0';
    try {
      fn();
    } finally {
      for (const [k, v] of Object.entries(prev)) {
        if (v === undefined) delete process.env[k];
        else process.env[k] = v;
      }
    }
  }
  // Legacy shim for existing tests that only cared about BASE_URL.
  function withBaseUrl(value, fn) {
    withEnv({ baseUrl: value }, fn);
  }

  it('EDGE + no BASE_URL → banner emits OK (regression pin for v3.2.51 PR-3)', () => {
    const logger = makeCollectingLogger();
    withBaseUrl(undefined, () => {
      assert.doesNotThrow(() =>
        printBootBanner({ role: 'EDGE', port: 3201, logger, depsSummary: [] }),
      );
    });
    const joined = logger.records.join('\n');
    assert.match(joined, /role EDGE/);
    assert.match(joined, /external\s*:\s*internal S2S only/);
  });

  it('EDGE + garbage BASE_URL → banner still emits OK (never parses it)', () => {
    const logger = makeCollectingLogger();
    withBaseUrl('::this-is-not-a-url::', () => {
      assert.doesNotThrow(() =>
        printBootBanner({ role: 'EDGE', port: 3201, logger, depsSummary: [] }),
      );
    });
    const joined = logger.records.join('\n');
    assert.match(joined, /external\s*:\s*internal S2S only/);
    // Must NOT leak the garbage value anywhere in the banner.
    assert.ok(!joined.includes('::this-is-not-a-url::'));
  });

  it('EDGE + valid BASE_URL → external row STILL shows "internal S2S only"', () => {
    const logger = makeCollectingLogger();
    withBaseUrl('https://should-not-leak.example', () => {
      printBootBanner({ role: 'EDGE', port: 3201, logger, depsSummary: [] });
    });
    const joined = logger.records.join('\n');
    assert.match(joined, /external\s*:\s*internal S2S only/);
    // EDGE row MUST NOT leak the BASE_URL value.
    assert.ok(!joined.includes('should-not-leak.example'));
  });

  it('INFRA + no BASE_URL → throws ERROR/CAUSE/FIX', () => {
    const logger = makeCollectingLogger();
    withBaseUrl(undefined, () => {
      assert.throws(
        () =>
          printBootBanner({ role: 'INFRA', port: 3200, logger, depsSummary: [] }),
        /ERROR: BASE_URL env not set/,
      );
    });
  });

  it('FRONTEND + FRONTEND_URL set → banner emits FRONTEND_URL (v3.2.54 PR-2)', () => {
    const logger = makeCollectingLogger();
    withEnv(
      { frontendUrl: 'https://zonea-fmb-web.localhost' },
      () => {
        assert.doesNotThrow(() =>
          printBootBanner({ role: 'FRONTEND', port: 3000, logger, depsSummary: [] }),
        );
      },
    );
    const joined = logger.records.join('\n');
    assert.match(joined, /role FRONTEND/);
    assert.match(joined, /external\s*:\s*https:\/\/zonea-fmb-web\.localhost\//);
    // v3.2.54 PR-2 replaces the v3.2.52c placeholder.
    assert.doesNotMatch(joined, /static SPA, no API role/);
  });

  it('FRONTEND + missing FRONTEND_URL → throws ERROR/CAUSE/FIX (v3.2.54 PR-2)', () => {
    const logger = makeCollectingLogger();
    withEnv({ frontendUrl: undefined }, () => {
      assert.throws(
        () =>
          printBootBanner({ role: 'FRONTEND', port: 3000, logger, depsSummary: [] }),
        /ERROR: FRONTEND_URL env not set/,
      );
    });
  });

  it('FRONTEND + malformed FRONTEND_URL → throws ERROR/CAUSE/FIX', () => {
    const logger = makeCollectingLogger();
    withEnv({ frontendUrl: '::not-a-url::' }, () => {
      assert.throws(
        () =>
          printBootBanner({ role: 'FRONTEND', port: 3000, logger, depsSummary: [] }),
        /ERROR: FRONTEND_URL=.*is not a valid URL/,
      );
    });
  });

  it('FRONTEND + BASE_URL present but FRONTEND_URL absent → still throws (role-branch separation)', () => {
    // Regression pin: FRONTEND must not fall back to BASE_URL under any
    // circumstances. Each role's "external" URL source is role-specific.
    const logger = makeCollectingLogger();
    withEnv(
      { baseUrl: 'https://api.example.com', frontendUrl: undefined },
      () => {
        assert.throws(
          () =>
            printBootBanner({ role: 'FRONTEND', port: 3000, logger, depsSummary: [] }),
          /ERROR: FRONTEND_URL env not set/,
        );
      },
    );
  });

  it('APP_NAME missing → printBootBanner throws (v3.2.54 PR-2)', () => {
    const logger = makeCollectingLogger();
    withEnv(
      { baseUrl: 'https://api.example.com', appName: null },
      () => {
        assert.throws(
          () =>
            printBootBanner({ role: 'INFRA', port: 3200, logger, depsSummary: [] }),
          /ERROR: APP_NAME env not set/,
        );
      },
    );
  });

  it('APP_NAME with ANSI/control chars → sanitised in banner (no leak to pino)', () => {
    const logger = makeCollectingLogger();
    withEnv(
      { baseUrl: 'https://api.example.com', appName: 'Acme\x1b[31mCorp\x07' },
      () => {
        printBootBanner({ role: 'INFRA', port: 3200, logger, depsSummary: [] });
      },
    );
    const joined = logger.records.join('\n');
    // The \x1b CSI sequence would show as green/bold in colour mode; we
    // pin LOG_COLOR=0 so raw chars would pass through if not sanitised.
    assert.doesNotMatch(joined, /\x1b\[31m/);
    assert.doesNotMatch(joined, /\x07/);
    // Visible letters still rendered.
    assert.match(joined, /Acme\[31mCorp/);
  });

  it('printBootBanner warns when SETTINGS_ENCRYPTION_KEY is blank', () => {
    const warnings = [];
    const logger = {
      records: [],
      info: (msg) => logger.records.push(msg),
      warn: (msg) => warnings.push(msg),
      error: () => {},
    };
    const prev = process.env.SETTINGS_ENCRYPTION_KEY;
    process.env.SETTINGS_ENCRYPTION_KEY = '';
    try {
      withBaseUrl(undefined, () => {
        assert.doesNotThrow(() =>
          printBootBanner({ role: 'EDGE', port: 3201, logger, depsSummary: [] }),
        );
      });
    } finally {
      if (prev === undefined) delete process.env.SETTINGS_ENCRYPTION_KEY;
      else process.env.SETTINGS_ENCRYPTION_KEY = prev;
    }
    assert.ok(warnings.length >= 1, 'expected at least one warn call');
    assert.match(warnings[0], /blank|empty/i);
  });

  it('role case-insensitive: lowercase "edge" == uppercase "EDGE"', () => {
    const logger = makeCollectingLogger();
    withBaseUrl(undefined, () => {
      assert.doesNotThrow(() =>
        printBootBanner({ role: 'edge', port: 3201, logger, depsSummary: [] }),
      );
    });
    const joined = logger.records.join('\n');
    assert.match(joined, /role EDGE/);
  });

  it('depsSummary array mutation-guard: caller array unchanged after 2 calls', () => {
    const logger = makeCollectingLogger();
    const deps = ['DB: ready', 'S2S: configured'];
    const snapshot = [...deps];
    withBaseUrl(undefined, () => {
      printBootBanner({ role: 'EDGE', port: 3201, logger, depsSummary: deps });
      printBootBanner({ role: 'EDGE', port: 3201, logger, depsSummary: deps });
    });
    assert.deepEqual(deps, snapshot, 'printBootBanner must not mutate deps array');
  });

  it('empty role → throws ERROR/CAUSE/FIX (v3.2.51a PR1-review HIGH)', () => {
    const logger = makeCollectingLogger();
    withBaseUrl('https://x.example', () => {
      for (const bad of [undefined, null, '', '   ']) {
        // '   ' is whitespace-only — uppercase of whitespace is still truthy;
        // only the undefined/null/empty cases are guarded. Skip whitespace.
        if (bad === '   ') continue;
        assert.throws(
          () => printBootBanner({ role: bad, port: 1234, logger }),
          /ERROR: printBootBanner called with empty role/,
          `expected throw for role=${JSON.stringify(bad)}`,
        );
      }
    });
  });
});
