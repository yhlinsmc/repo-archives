/**
 * capacity-degraded-column.test.js — C1 (degraded-mode column filter). A
 * warn-skipped add-column migration (no DDL privilege) leaves name_patterns
 * ABSENT; a settings write that names it would 500 EVERY scenario-settings save.
 * dropAbsentColumns probes the physical column set once and drops any write
 * column the DB lacks, so old-schema DBs keep saving the columns they have.
 */
const { describe, it, beforeEach } = require('node:test');
const assert = require('node:assert/strict');

// Stub the edge db module so _shared loads with an identity table-name resolver.
const dbKey = require.resolve('../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: {}, t: (n) => n },
};

const { dropAbsentColumns, tableColumnSet, _resetColumnSetCache } = require('../../src/edge/routes/app/capacity/_shared');
const { TABLES } = require('../../src/shared/constants');

beforeEach(() => _resetColumnSetCache());

describe('dropAbsentColumns', () => {
  it('drops name_patterns when the physical column is absent (degraded mode)', async () => {
    const queryable = { query: async () => [{ name: 'id' }, { name: 'scenario_id' }, { name: 'mem_cpu_ratio' }] };
    const res = await dropAbsentColumns(
      queryable, TABLES.CAP_SETTINGS,
      ['mem_cpu_ratio', 'name_patterns'], [20, { hypervisor: 'h-{seq}' }],
    );
    assert.deepEqual(res.cols, ['mem_cpu_ratio']);
    assert.deepEqual(res.values, [20]);
  });

  it('keeps name_patterns when the column exists (migrated DB)', async () => {
    const queryable = { query: async () => [{ name: 'id' }, { name: 'mem_cpu_ratio' }, { name: 'name_patterns' }] };
    const res = await dropAbsentColumns(
      queryable, TABLES.CAP_SETTINGS,
      ['mem_cpu_ratio', 'name_patterns'], [20, null],
    );
    assert.deepEqual(res.cols, ['mem_cpu_ratio', 'name_patterns']);
    assert.deepEqual(res.values, [20, null]);
  });

  it('an empty probe (permissions / odd DB) never drops a legitimate write', async () => {
    const queryable = { query: async () => [] };
    const res = await dropAbsentColumns(queryable, TABLES.CAP_SETTINGS, ['name_patterns'], [null]);
    assert.deepEqual(res.cols, ['name_patterns']);
    assert.deepEqual(res.values, [null]);
  });

  it('caches the probe (one query per table)', async () => {
    let calls = 0;
    const queryable = { query: async () => { calls += 1; return [{ name: 'mem_cpu_ratio' }]; } };
    await dropAbsentColumns(queryable, TABLES.CAP_SETTINGS, ['mem_cpu_ratio'], [1]);
    await dropAbsentColumns(queryable, TABLES.CAP_SETTINGS, ['mem_cpu_ratio'], [2]);
    assert.equal(calls, 1);
  });
});

// The probe is cached with a 60s TTL, NOT for process lifetime: the fmb-1329
// remediation flow lets a DBA apply a warn-skipped ALTER out-of-band while this
// process runs, and a permanent cache would keep dropping the new column until a
// restart. Time is driven by stubbing Date.now so the window is exercised without
// a real wait.
describe('tableColumnSet cache TTL (fmb-1329 DBA live-remediation)', () => {
  it('re-probes after the TTL so a DBA-applied column is picked up without a restart', async () => {
    const realNow = Date.now;
    let now = 1_000_000;
    Date.now = () => now;
    try {
      let calls = 0;
      const queryable = {
        query: async () => {
          calls += 1;
          // First probe is pre-remediation (name_patterns absent); after the DBA
          // runs the ALTER out-of-band the physical set gains the column.
          return calls === 1
            ? [{ name: 'id' }, { name: 'mem_cpu_ratio' }]
            : [{ name: 'id' }, { name: 'mem_cpu_ratio' }, { name: 'name_patterns' }];
        },
      };
      const before = await dropAbsentColumns(
        queryable, TABLES.CAP_SETTINGS,
        ['mem_cpu_ratio', 'name_patterns'], [20, { hypervisor: 'h-{seq}' }],
      );
      assert.deepEqual(before.cols, ['mem_cpu_ratio']); // dropped pre-remediation
      now += 61_000; // step past the 60s TTL
      const after = await dropAbsentColumns(
        queryable, TABLES.CAP_SETTINGS,
        ['mem_cpu_ratio', 'name_patterns'], [20, { hypervisor: 'h-{seq}' }],
      );
      assert.equal(calls, 2, 'a stale entry must re-probe');
      assert.deepEqual(after.cols, ['mem_cpu_ratio', 'name_patterns']); // now kept
    } finally {
      Date.now = realNow;
    }
  });

  it('does not re-probe within the TTL window (a fresh entry is served from cache)', async () => {
    const realNow = Date.now;
    let now = 2_000_000;
    Date.now = () => now;
    try {
      let calls = 0;
      const queryable = { query: async () => { calls += 1; return [{ name: 'id' }, { name: 'mem_cpu_ratio' }]; } };
      await dropAbsentColumns(queryable, TABLES.CAP_SETTINGS, ['mem_cpu_ratio'], [1]);
      now += 59_000; // still inside the 60s window
      await dropAbsentColumns(queryable, TABLES.CAP_SETTINGS, ['mem_cpu_ratio'], [2]);
      assert.equal(calls, 1, 'a fresh entry must not re-probe');
    } finally {
      Date.now = realNow;
    }
  });

  // A transient empty re-probe (permissions blip) must NOT drop a known set — the
  // old-schema-DB immunity the permanent cache used to give. The stale-but-known
  // set is served and re-probed each later call until a non-empty result lands.
  it('serves the stale-but-known set when a re-probe blips empty, then replaces it on a non-empty probe', async () => {
    const realNow = Date.now;
    let now = 3_000_000;
    Date.now = () => now;
    try {
      let calls = 0;
      let phase = 'full';
      const queryable = {
        query: async () => {
          calls += 1;
          if (phase === 'empty') return []; // transient blip
          if (phase === 'grown') return [{ name: 'id' }, { name: 'mem_cpu_ratio' }, { name: 'name_patterns' }, { name: 'layer_defaults' }];
          return [{ name: 'id' }, { name: 'mem_cpu_ratio' }, { name: 'name_patterns' }];
        },
      };
      // 1) prime with a known non-empty set
      const first = await tableColumnSet(queryable, TABLES.CAP_SETTINGS);
      assert.deepEqual([...first].sort(), ['id', 'mem_cpu_ratio', 'name_patterns']);
      // 2) past TTL, the re-probe returns empty → the stale KNOWN set is served
      now += 61_000;
      phase = 'empty';
      const stale = await tableColumnSet(queryable, TABLES.CAP_SETTINGS);
      assert.equal(calls, 2, 'a stale entry must re-probe');
      assert.deepEqual([...stale].sort(), ['id', 'mem_cpu_ratio', 'name_patterns'], 'a transient empty must not drop the known set');
      // 3) the timestamp was never refreshed by the empty probe, so the next call
      //    re-probes again — this time non-empty — and REPLACES the stale entry
      phase = 'grown';
      const replaced = await tableColumnSet(queryable, TABLES.CAP_SETTINGS);
      assert.equal(calls, 3, 'the stale entry must keep re-probing');
      assert.deepEqual([...replaced].sort(), ['id', 'layer_defaults', 'mem_cpu_ratio', 'name_patterns']);
    } finally {
      Date.now = realNow;
    }
  });

  // The other blip shape: a re-probe that THROWS (transient information_schema
  // failure) must also serve the stale-but-known set, not propagate a 500 onto a
  // write the permanent cache used to serve.
  it('serves the stale-but-known set when a re-probe THROWS, then replaces it on a successful probe', async () => {
    const realNow = Date.now;
    let now = 5_000_000;
    Date.now = () => now;
    try {
      let calls = 0;
      let phase = 'full';
      const queryable = {
        query: async () => {
          calls += 1;
          if (phase === 'throw') throw new Error('information_schema unavailable');
          if (phase === 'grown') return [{ name: 'id' }, { name: 'mem_cpu_ratio' }, { name: 'name_patterns' }];
          return [{ name: 'id' }, { name: 'mem_cpu_ratio' }];
        },
      };
      const first = await tableColumnSet(queryable, TABLES.CAP_SETTINGS);
      assert.deepEqual([...first].sort(), ['id', 'mem_cpu_ratio']);
      now += 61_000; // past the TTL
      phase = 'throw';
      const stale = await tableColumnSet(queryable, TABLES.CAP_SETTINGS);
      assert.equal(calls, 2, 'the stale entry must re-probe');
      assert.deepEqual([...stale].sort(), ['id', 'mem_cpu_ratio'], 'a thrown probe must not surface — serve the known set');
      phase = 'grown';
      const replaced = await tableColumnSet(queryable, TABLES.CAP_SETTINGS);
      assert.equal(calls, 3, 'the stale entry must keep re-probing');
      assert.deepEqual([...replaced].sort(), ['id', 'mem_cpu_ratio', 'name_patterns']);
    } finally {
      Date.now = realNow;
    }
  });

  // The boundary the fallback preserves: with NO prior success there is nothing
  // known, so a first-ever probe error propagates exactly as before the TTL.
  it('propagates a first-ever probe error (no known set to fall back to)', async () => {
    const queryable = { query: async () => { throw new Error('probe boom'); } };
    await assert.rejects(() => tableColumnSet(queryable, TABLES.CAP_SETTINGS), /probe boom/);
  });
});
