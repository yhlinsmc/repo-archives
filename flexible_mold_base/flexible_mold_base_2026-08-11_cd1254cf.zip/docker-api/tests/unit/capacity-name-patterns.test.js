/**
 * capacity-name-patterns.test.js — the server-side hostname-pattern contract
 * (spec B5a): the all-or-nothing write validation, and PARITY of the server
 * DEFAULT_NAME_PATTERNS with the FE single formatter (hostname-pattern.ts). The
 * two defaults must stay byte-identical or a scenario that inherits would resolve
 * different names on the server than the client proposed.
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const {
  DEFAULT_NAME_PATTERNS, validateNamePatternsWrite, validatePattern,
  siteSlug, formatHostname, withBatchSeqWidth, resolveEffectiveNamePatterns,
  computeRenumberPlan, firstDuplicateName, duplicateNameFlags, firstOverlengthName,
  duplicateAllLockedFlags,
} = require('../../src/shared/capacity/name-patterns');

describe('validatePattern — all-or-nothing single pattern', () => {
  it('accepts {dc}/{seq}/{seq:N} patterns', () => {
    assert.equal(validatePattern('hv-{dc}-{seq:2}'), null);
    assert.equal(validatePattern('ap-{seq}'), null);
  });
  it('rejects empty, {nn}, unknown tokens, bad width, unbalanced braces', () => {
    assert.notEqual(validatePattern(''), null);
    assert.notEqual(validatePattern('hv-{dc}-{nn}'), null);
    assert.notEqual(validatePattern('hv-{index}'), null);
    assert.notEqual(validatePattern('hv-{seq:0}'), null);
    assert.notEqual(validatePattern('hv-{seq'), null);
  });
  // FIX-3 (lockstep with the FE): a pattern with no sequence token is rejected.
  it('rejects a pattern with no {seq} token', () => {
    assert.match(validatePattern('hv-{dc}'), /\{seq\}/);
    assert.notEqual(validatePattern('fixed'), null);
  });
  // FIX-1 (lockstep): length + token-count caps against nextSeq ReDoS.
  it('caps length at 64 and token groups at 8', () => {
    const at64 = `${'a'.repeat(64 - '-{seq}'.length)}-{seq}`;
    assert.equal(at64.length, 64);
    assert.equal(validatePattern(at64), null);
    assert.notEqual(validatePattern(`x${at64}`), null);
    assert.equal(validatePattern(`{seq}${'{dc}'.repeat(7)}`), null);
    assert.notEqual(validatePattern(`{seq}${'{dc}'.repeat(8)}`), null);
    assert.notEqual(validatePattern('{seq}'.repeat(300)), null);
  });
});

describe('validateNamePatternsWrite — whole-set write guard', () => {
  it('null/undefined (inherited) is valid', () => {
    assert.equal(validateNamePatternsWrite(null), null);
    assert.equal(validateNamePatternsWrite(undefined), null);
  });
  it('a full valid set is valid', () => {
    assert.equal(validateNamePatternsWrite({ ...DEFAULT_NAME_PATTERNS }), null);
  });
  it('rejects a non-object (array / string)', () => {
    assert.notEqual(validateNamePatternsWrite(['x']), null);
    assert.notEqual(validateNamePatternsWrite('hv-{seq:2}'), null);
  });
  it('one bad entry rejects the WHOLE set, naming the offending key', () => {
    const err = validateNamePatternsWrite({
      hypervisor: 'hv-{seq:2}', kvm_host_primary: 'kvm-{nn}', kvm_host_standby: 'kvm-{seq:2}', ap_vm: 'ap-{seq:2}',
    });
    assert.match(err, /kvm_host_primary/);
  });
  // cap-pattern-function (Task 2.2): the pre-split legacy key set is rejected
  // post-migration — it is neither the exact new key set nor a partial one.
  it('rejects the legacy single kvm_host key set', () => {
    const err = validateNamePatternsWrite({
      hypervisor: DEFAULT_NAME_PATTERNS.hypervisor, kvm_host: 'kvm-{dc}-{seq:2}', ap_vm: DEFAULT_NAME_PATTERNS.ap_vm,
    });
    assert.match(err, /exactly/);
  });
  it('a missing entry is rejected (whole set required)', () => {
    assert.notEqual(validateNamePatternsWrite({ hypervisor: 'hv-{seq:2}' }), null);
  });
  // FIX-6 (lockstep): an extra key would persist verbatim into the JSON column.
  it('rejects a payload with an extra key', () => {
    const err = validateNamePatternsWrite({ ...DEFAULT_NAME_PATTERNS, evil: 'x-{seq}' });
    assert.match(err, /exactly/);
  });
});

// ── B5b renumber primitives (server mirror) ──────────────────────────────────

describe('siteSlug / formatHostname / withBatchSeqWidth (server mirror)', () => {
  it('siteSlug lowercases and strips non-alphanumerics', () => {
    assert.equal(siteSlug('DC-1'), 'dc1');
    assert.equal(siteSlug('Site A 2'), 'sitea2');
    assert.equal(siteSlug(null), '');
  });
  it('formatHostname interpolates {dc}/{seq} and leaves unknown tokens verbatim', () => {
    assert.equal(formatHostname('hv-{dc}-{seq:2}', { dc: 'dc1', seq: 7 }), 'hv-dc1-07');
    assert.equal(formatHostname('ap-{seq:2}', { dc: '', seq: 100 }), 'ap-100');
    assert.equal(formatHostname('x-{zzz}-{seq}', { dc: 'd', seq: 3 }), 'x-{zzz}-3');
  });
  it('withBatchSeqWidth widens seq pad to the batch digit count', () => {
    assert.equal(withBatchSeqWidth('ap-{seq:2}', 100), 'ap-{seq:3}');
    assert.equal(withBatchSeqWidth('ap-{seq:2}', 9), 'ap-{seq:2}');
    assert.equal(withBatchSeqWidth('ap-{seq}', 12), 'ap-{seq:2}');
  });
});

describe('resolveEffectiveNamePatterns (server mirror of the FE tier chain)', () => {
  const OVERRIDE = {
    hypervisor: 'h-{dc}-{seq:2}', kvm_host_primary: 'k-{dc}-{seq:2}', kvm_host_standby: 'ks-{dc}-{seq:2}', ap_vm: 'a-{seq:2}',
  };
  const GLOBAL = {
    hypervisor: 'g-{dc}-{seq:2}', kvm_host_primary: 'gk-{dc}-{seq:2}', kvm_host_standby: 'gks-{dc}-{seq:2}', ap_vm: 'ga-{seq:2}',
  };

  it('a scenario override (own non-null scenario_id) wins over global and defaults', () => {
    const eff = resolveEffectiveNamePatterns(
      { scenario_id: 's1', name_patterns: OVERRIDE },
      { scenario_id: null, name_patterns: GLOBAL },
    );
    assert.deepEqual(eff, OVERRIDE);
  });
  it('a scenario row with NULL name_patterns inherits the global patterns', () => {
    const eff = resolveEffectiveNamePatterns(
      { scenario_id: 's1', name_patterns: null },
      { scenario_id: null, name_patterns: GLOBAL },
    );
    assert.deepEqual(eff, GLOBAL);
  });
  it('no scenario row + no global override falls back to built-in defaults', () => {
    const eff = resolveEffectiveNamePatterns(null, { scenario_id: null, name_patterns: null });
    assert.deepEqual(eff, DEFAULT_NAME_PATTERNS);
  });
});

describe('computeRenumberPlan (fork-2 wizard-consistent numbering)', () => {
  it('groups by {dc} slug; seq 1..k per group in the given order', () => {
    const rows = [
      { id: 'a', name: 'old-a', dcSlug: 'dc1' },
      { id: 'b', name: 'old-b', dcSlug: 'dc1' },
      { id: 'c', name: 'old-c', dcSlug: 'dc2' },
    ];
    const plan = computeRenumberPlan(rows, 'hv-{dc}-{seq:2}');
    assert.deepEqual(plan.map((p) => p.newName), ['hv-dc1-01', 'hv-dc1-02', 'hv-dc2-01']);
    assert.deepEqual(plan.map((p) => p.id), ['a', 'b', 'c']); // display order preserved
    assert.equal(plan[0].oldName, 'old-a');
  });
  it('a {dc}-free pattern is ONE scenario-wide group', () => {
    const rows = ['a', 'b', 'c'].map((id) => ({ id, name: `x-${id}`, dcSlug: 'ignored' }));
    const plan = computeRenumberPlan(rows, 'ap-{seq:2}');
    assert.deepEqual(plan.map((p) => p.newName), ['ap-01', 'ap-02', 'ap-03']);
  });
  it('an UNPLACED entity (empty slug) with a {dc} pattern drops {dc} — no dangling separator', () => {
    const rows = [
      { id: 'a', name: 'old', dcSlug: 'dc1' },
      { id: 'b', name: 'old', dcSlug: '' },
      { id: 'c', name: 'old', dcSlug: '' },
    ];
    const plan = computeRenumberPlan(rows, 'kvm-{dc}-{seq:2}');
    assert.deepEqual(plan.map((p) => p.newName), ['kvm-dc1-01', 'kvm-01', 'kvm-02']);
  });
  it('width grows with group count: a group of 100 renders 3-wide', () => {
    const rows = Array.from({ length: 100 }, (_, i) => ({ id: `r${i}`, name: 'x', dcSlug: '' }));
    const plan = computeRenumberPlan(rows, 'ap-{seq:2}');
    assert.equal(plan[0].newName, 'ap-001');
    assert.equal(plan[99].newName, 'ap-100');
  });
  it('hand-edited names are renumbered like any other (oldName is irrelevant to newName)', () => {
    const rows = [
      { id: 'a', name: 'my-special-host', dcSlug: 'dc1' },
      { id: 'b', name: 'renamed-by-hand', dcSlug: 'dc1' },
    ];
    const plan = computeRenumberPlan(rows, 'hv-{dc}-{seq:2}');
    assert.deepEqual(plan.map((p) => p.newName), ['hv-dc1-01', 'hv-dc1-02']);
  });
  // H1 (cross-role-group collision, renumber.js plansForTable's kvm_host split):
  // `reservedSeed` folds an external name list into the collision set BEFORE
  // generation, same fold as a locked row's own name — the mechanism the
  // renumber route uses to make the primary group's plan off-limits to the
  // independently-computed standby group.
  it('reservedSeed advances the seq past an externally-reserved name, case-insensitively', () => {
    const rows = [{ id: 'a', name: 'old-a', dcSlug: 'dc' }];
    const plan = computeRenumberPlan(rows, 'kvm-{dc}-{seq:2}', ['KVM-DC-01']);
    assert.deepEqual(plan.map((p) => p.newName), ['kvm-dc-02']);
  });
  it('an empty/absent reservedSeed behaves exactly as today (no third param)', () => {
    const rows = [{ id: 'a', name: 'old-a', dcSlug: 'dc' }];
    assert.deepEqual(
      computeRenumberPlan(rows, 'kvm-{dc}-{seq:2}').map((p) => p.newName),
      computeRenumberPlan(rows, 'kvm-{dc}-{seq:2}', []).map((p) => p.newName),
    );
  });
  // P1a (Codex r1): a reservedSeed larger than this group's own row count must
  // not exhaust the retry bound before an unreserved candidate is found — the
  // bound must grow with the seed, not just with rows.length.
  it('a reservedSeed bigger than rows.length still advances to an unreserved name', () => {
    const rows = [{ id: 'a', name: 'old-a', dcSlug: 'dc' }];
    const plan = computeRenumberPlan(
      rows,
      'kvm-{dc}-{seq:2}',
      ['kvm-dc-01', 'kvm-dc-02', 'kvm-dc-03'],
    );
    assert.deepEqual(plan.map((p) => p.newName), ['kvm-dc-04']);
  });
});

describe('firstDuplicateName (apply uniqueness gate)', () => {
  it('returns null when every name is unique', () => {
    assert.equal(firstDuplicateName(['hv-dc1-01', 'hv-dc1-02', 'hv-dc2-01']), null);
  });
  it('detects a case-insensitive duplicate (matching the DB collation)', () => {
    assert.equal(firstDuplicateName(['HV-DC1-01', 'hv-dc1-01']), 'hv-dc1-01');
  });
  it('catches a malformed {seq}-less pattern that renders every name identically', () => {
    // A legacy stored override the lenient formatter would render the same for all
    // rows — the guarantee that a duplicate can never persist regardless of cause.
    const rows = [{ id: 'a', name: 'x', dcSlug: 'dc1' }, { id: 'b', name: 'y', dcSlug: 'dc1' }];
    const plan = computeRenumberPlan(rows, 'kvm-{dc}');
    assert.notEqual(firstDuplicateName(plan.map((p) => p.newName)), null);
  });
});

describe('duplicateNameFlags (fmb-1649 preview gate — marks EVERY colliding row)', () => {
  it('returns all-false when every name is unique', () => {
    assert.deepEqual(duplicateNameFlags(['hv-dc1-01', 'hv-dc1-02', 'hv-dc2-01']), [false, false, false]);
  });
  it('flags a case-insensitive duplicate on BOTH sides (same fold as firstDuplicateName)', () => {
    // Case-differing to prove the fold — String(name).trim().toLowerCase(), the
    // exact fold firstDuplicateName / the DB collation use — not just an exact
    // string match.
    assert.deepEqual(duplicateNameFlags(['HV-DC1-01', 'hv-dc1-01', 'hv-dc2-01']), [true, true, false]);
  });
  it('flags every member of a 3-way collision, not just the second', () => {
    assert.deepEqual(duplicateNameFlags(['kvm-dc1', 'kvm-dc1', 'kvm-dc1']), [true, true, true]);
  });
});

describe('duplicateAllLockedFlags (locked-vs-locked duplicate remedy)', () => {
  it('returns all-false when nothing collides', () => {
    const items = [{ name: 'hv-dc1-01', locked: false }, { name: 'hv-dc1-02', locked: true }];
    assert.deepEqual(duplicateAllLockedFlags(items), [false, false]);
  });
  it('flags false when a collision has at least one renumerable (unlocked) side', () => {
    // A naming-pattern edit can still resolve this: the unlocked side would
    // compute a different name.
    const items = [{ name: 'kvm-dc1-01', locked: true }, { name: 'kvm-dc1-01', locked: false }];
    assert.deepEqual(duplicateAllLockedFlags(items), [false, false]);
  });
  it('flags true when every member of the colliding group is locked', () => {
    // Both names are frozen (spec D1) — no naming-pattern edit can change
    // either one; the only remedy is unlocking one of them.
    const items = [
      { name: 'erp-db', locked: true },
      { name: 'ERP-DB', locked: true }, // case-folded match, same fold as duplicateNameFlags
      { name: 'kvm-dc1-01', locked: false },
    ];
    assert.deepEqual(duplicateAllLockedFlags(items), [true, true, false]);
  });
});

describe('firstOverlengthName (apply length gate)', () => {
  it('returns null when every name is within the limit, and the boundary is inclusive', () => {
    assert.equal(firstOverlengthName(['hv-dc1-01', 'a'.repeat(255)], 255), null);
  });
  it('returns the first name that exceeds the limit', () => {
    assert.equal(firstOverlengthName(['ok', 'b'.repeat(256)], 255), 'b'.repeat(256));
  });
});

describe('parity with the FE single formatter', () => {
  it('server DEFAULT_NAME_PATTERNS matches hostname-pattern.ts DEFAULT_NAME_PATTERNS', () => {
    const feSource = fs.readFileSync(
      path.join(__dirname, '../../../src/fmb/capacity/lib/hostname-pattern.ts'),
      'utf8',
    );
    // Each entity key's quoted default literal appears exactly once in the FE
    // source (the DEFAULT_NAME_PATTERNS object); a value may itself contain `}`
    // (e.g. {seq:2}), so match the whole quoted string, not a brace-bounded block.
    const feFor = (key) => {
      const m = feSource.match(new RegExp(`${key}\\s*:\\s*'([^']+)'`));
      assert.ok(m, `FE default for ${key} not found`);
      return m[1];
    };
    assert.equal(DEFAULT_NAME_PATTERNS.hypervisor, feFor('hypervisor'));
    assert.equal(DEFAULT_NAME_PATTERNS.kvm_host_primary, feFor('kvm_host_primary'));
    assert.equal(DEFAULT_NAME_PATTERNS.kvm_host_standby, feFor('kvm_host_standby'));
    assert.equal(DEFAULT_NAME_PATTERNS.ap_vm, feFor('ap_vm'));
  });
});
