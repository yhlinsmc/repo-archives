/**
 * forward-path-guard.test.js — the upstream path guard inside forwardToEdge.
 *
 * Why these tests exist: infra concatenates the caller's request path onto a
 * mount's edge prefix, and `new URL(path, base)` resolves dot-segments AFTER
 * percent-decoding them. A public mount could therefore walk out of its prefix
 * into /edge/internal/*, whose only gate is the S2S key that infra itself
 * attaches. The assertions below are on the URL actually handed to fetch —
 * a status code alone cannot tell "rejected" from "forwarded somewhere else".
 *
 * The real createForwardingProxy / createRawBodyForwardingProxy / forwardToEdge
 * run here. The factories are wrapped only to record the edgePath literal each
 * mount declares, so the positive rows are driven from the real mount table in
 * src/infra/forwarding.js instead of a hand-written list.
 */
const { test } = require('node:test');
const assert = require('node:assert');
const http = require('node:http');
const express = require('express');
const { makeStubReqLog } = require('../helpers/stub-req-log');

const EDGE_BASE_URL = 'http://api-edge.test:3201';
process.env.EDGE_API_URL = EDGE_BASE_URL;

// ── logger recorder — installed before remote-client is loaded ───────────────
const loggerPath = require.resolve('../../src/shared/lib/logger');
const realLoggerModule = require(loggerPath);
const logLines = [];
const recordingLogger = {
  child: () => recordingLogger,
  trace: () => {},
  debug: () => {},
  info: (...args) => logLines.push({ level: 'info', args }),
  warn: (...args) => logLines.push({ level: 'warn', args }),
  error: (...args) => logLines.push({ level: 'error', args }),
  fatal: (...args) => logLines.push({ level: 'fatal', args }),
};
require.cache[loggerPath].exports = { ...realLoggerModule, logger: recordingLogger };

// ── real remote-client, with the two factories wrapped to record edgePath ────
const clientPath = require.resolve('../../src/infra/lib/remote-client');
const realClient = require(clientPath);
const factoryCalls = [];
// Route modules destructure forwardToEdge at require time, so the seam has to
// exist before any of them load. Null override = the real function.
let forwardOverride = null;
require.cache[clientPath].exports = {
  ...realClient,
  forwardToEdge: (opts) => (forwardOverride ? forwardOverride(opts) : realClient.forwardToEdge(opts)),
  createForwardingProxy(edgePath) {
    const handler = realClient.createForwardingProxy(edgePath);
    handler._edgePath = edgePath;
    handler._kind = 'json';
    factoryCalls.push(edgePath);
    return handler;
  },
  createRawBodyForwardingProxy(edgePath, opts) {
    const handler = realClient.createRawBodyForwardingProxy(edgePath, opts);
    handler._edgePath = edgePath;
    handler._kind = 'raw';
    factoryCalls.push(edgePath);
    return handler;
  },
};

const forwarding = require('../../src/infra/forwarding');
const { forwardToEdge, getCircuitState, _resetCircuitBreaker } = realClient;

// ── fetch stub ──────────────────────────────────────────────────────────────
let fetchCalls = [];

function upstreamResponse(status = 200, body = { success: true, data: {} }) {
  const headers = new Map([['content-type', 'application/json']]);
  return {
    ok: status >= 200 && status < 300,
    status,
    headers: { get: (k) => (headers.has(k.toLowerCase()) ? headers.get(k.toLowerCase()) : null) },
    json: async () => body,
    text: async () => JSON.stringify(body),
  };
}

function installFetch(impl) {
  fetchCalls = [];
  global.fetch = async (url, options) => {
    fetchCalls.push({ url, options });
    if (impl) return impl(url, options);
    return upstreamResponse();
  };
}

function fakeRes() {
  const out = { statusCode: null, body: null, headers: {} };
  const res = {
    setHeader(name, value) { out.headers[String(name).toLowerCase()] = value; },
    status(code) { out.statusCode = code; return res; },
    json(payload) { out.body = payload; return res; },
    send(payload) { out.body = payload; return res; },
  };
  return { res, out };
}

// ── mount table, enumerated from the real forwarding.js ─────────────────────
const allMounts = [];
function collectMounts() {
  const record = (verb) => (mountPath, ...handlers) => {
    const last = handlers[handlers.length - 1];
    allMounts.push({
      verb,
      mountPath,
      handler: last,
      edgePath: last && last._edgePath,
      kind: (last && last._kind) || null,
    });
  };
  const app = {
    use: record('use'),
    get: record('get'),
    post: record('post'),
    put: record('put'),
    delete: record('delete'),
    all: record('all'),
  };
  forwarding.mountAuthForwarding(app);
  forwarding.mountRemainingRoutes(app);
}
collectMounts();

const proxyMounts = allMounts.filter((m) => typeof m.edgePath === 'string');

async function drive(mount, reqPath, overrides = {}) {
  const raw = mount.kind === 'raw';
  const req = {
    method: raw ? 'POST' : 'GET',
    path: reqPath,
    originalUrl: mount.mountPath + (reqPath === '/' ? '' : reqPath),
    headers: raw ? { 'content-type': 'text/yaml' } : {},
    body: raw ? 'a: 1' : undefined,
    query: {},
    user: { id: 'u-1', email: 'u1@example.test' },
    ...overrides,
  };
  const { res, out } = fakeRes();
  await mount.handler(req, res, () => {});
  return out;
}

// Tails that must never reach fetch. Some are collapsed by the URL parser
// itself and fail the prefix check; the rest are dot segments only after
// decoding, or under this parser's tab/LF/CR stripping.
const ATTACK_TAILS = [
  '/../../internal/system/auth-mode',
  '/%2e%2e/%2e%2e/internal/system/auth-mode',
  '/%2E%2E/%2E%2E/internal/system/auth-mode',
  '/%252e%252e/%252e%252e/internal/system/auth-mode',
  // Four levels of encoding: the previous three-round loop decoded a fourth
  // time without checking the result, so this one passed.
  '/%25252e%25252e/%25252e%25252e/internal/system/auth-mode',
  '/foo/../../internal/system/auth-mode',
  '/foo/..',
  '/./foo',
  // This parser drops tab/LF/CR before it looks for dot segments, so these are
  // dot segments to it — the encoded forms arrive as data and were forwarded.
  '/.%09./.%09./internal/system/auth-mode',
  '/.%0a./.%0a./internal/system/auth-mode',
  '/.%0d./.%0d./internal/system/auth-mode',
  // A raw backslash is a path separator to the URL parser for http(s) URLs
  // (measured), so it walks out of the prefix without ever spelling '..' …
  '/..\\..\\internal/system/auth-mode',
  // … and even when it stays inside the mount it is a segment the client added
  // after Express finished routing (see the media-type-gate test below).
  '/alpha\\beta',
];

// Accepted on purpose: they carry a separator only after decoding, which cannot
// leave the mount here. The prefix check is what makes that guarantee, and
// rejecting this shape breaks legitimate identifiers.
const INSIDE_MOUNT_ENCODED_TAILS = [
  '/%2e%2e%2f%2e%2e%2finternal/system/auth-mode',
  '/..%2f..%2finternal/system/auth-mode',
  '/%5c%2e%2e/%5c%2e%2e/internal/system/auth-mode',
];

// { tail sent by the client, upstream path it must produce }. The last four are
// identifiers this API forwarded before the guard existed and must keep
// forwarding: an orphan field key predates the key-shape rule and can contain
// a '/' (encoded as %2F), and a settings key reaches the path unencoded, so a
// '%' in it is malformed encoding rather than an attack.
const POSITIVE_TAILS = [
  ['/', ''],
  ['/alpha', '/alpha'],
  ['/alpha/beta/gamma', '/alpha/beta/gamma'],
  ['/alpha/b%20c', '/alpha/b%20c'],
  ['/123e4567-e89b-12d3-a456-426614174000', '/123e4567-e89b-12d3-a456-426614174000'],
  ['/tmpl-1/a%2Fb', '/tmpl-1/a%2Fb'],
  ['/tmpl-1/a%5Cb', '/tmpl-1/a%5Cb'],
  ['/50%off', '/50%off'],
  ['/100%', '/100%'],
];

test('the mount table enumerates the real forwarding proxies', () => {
  // Floor, not an inventory: catches a recorder that silently captured nothing
  // (the failure mode a hand-listed table hides).
  assert.ok(
    proxyMounts.length >= 20,
    `expected the real mount table, got ${proxyMounts.length} proxy mounts`,
  );
  assert.ok(
    proxyMounts.some((m) => m.mountPath === '/api/app/capacity'),
    'capacity subtree mount must be present',
  );
  assert.ok(
    proxyMounts.some((m) => m.kind === 'raw'),
    'raw-body blueprint-import-yaml mount must be present',
  );
  for (const m of proxyMounts) {
    assert.ok(m.edgePath.startsWith('/edge/'), `${m.mountPath} → ${m.edgePath}`);
  }
});

test('every mount still forwards its own paths byte-identically', async () => {
  for (const mount of proxyMounts) {
    for (const [tail, upstreamTail] of POSITIVE_TAILS) {
      installFetch();
      const out = await drive(mount, tail);
      assert.strictEqual(
        fetchCalls.length, 1,
        `${mount.mountPath}${tail} should reach fetch exactly once`,
      );
      const expected = EDGE_BASE_URL + mount.edgePath + upstreamTail;
      assert.strictEqual(
        fetchCalls[0].url, expected,
        `${mount.mountPath}${tail} upstream URL`,
      );
      assert.strictEqual(out.statusCode, 200, `${mount.mountPath}${tail} status`);
    }
  }
});

test('no mount can walk out of its edge prefix', async () => {
  _resetCircuitBreaker();
  for (const mount of proxyMounts) {
    for (const tail of ATTACK_TAILS) {
      installFetch();
      const out = await drive(mount, tail);
      assert.strictEqual(
        fetchCalls.length, 0,
        `${mount.mountPath}${tail} must not reach fetch (upstream would have been ${fetchCalls[0] && fetchCalls[0].url})`,
      );
      assert.strictEqual(out.statusCode, 400, `${mount.mountPath}${tail} status`);
      assert.strictEqual(out.body.data, null);
      assert.ok(out.body.error && typeof out.body.error.code === 'string');
      // C6: the client payload must not enumerate edge routes.
      const payload = JSON.stringify(out.body);
      assert.ok(!payload.includes('/edge/'), `${mount.mountPath}${tail} leaked an edge path`);
      assert.ok(!payload.includes('internal/system'), `${mount.mountPath}${tail} leaked the target`);
    }
  }
  // A rejected path is a client error, not an edge outage.
  assert.strictEqual(getCircuitState(), 'closed');
});

test('a segment that only decodes to a separator stays inside the mount and forwards', async () => {
  // The rule is deliberate: rejecting these breaks legitimate identifiers, and
  // the prefix check — not the segment rule — is what keeps them in the mount.
  for (const mount of proxyMounts) {
    for (const tail of INSIDE_MOUNT_ENCODED_TAILS) {
      installFetch();
      await drive(mount, tail);
      assert.strictEqual(fetchCalls.length, 1, `${mount.mountPath}${tail} should forward`);
      const { pathname } = new URL(fetchCalls[0].url);
      assert.strictEqual(pathname, mount.edgePath + tail, 'byte-identical upstream path');
      assert.ok(
        pathname === mount.edgePath || pathname.startsWith(`${mount.edgePath}/`),
        `${tail} left the mount prefix`,
      );
    }
  }
});

// The three assertions above (byte-identical, inside the mount prefix) cannot
// fail independently of each other, so a fourth assertion phrased the same way
// ("does not contain /edge/internal/system") checks nothing new. What actually
// keeps these forwarded, decoded-tail paths from reaching /edge/internal/* is
// that Express matches its router regexp on the RAW path and only decodes
// captured params — a percent-encoded traversal tail therefore matches no
// route at all on the edge side. That is a claim about the real edge router,
// not about remote-client, so it is tested by mounting the real router.
test('a forwarded path that stayed inside the mount matches no route on the edge side', async () => {
  const app = express();
  // Two real edge routers, mounted exactly as production wires them
  // (src/index-edge.js), with no fixtures beyond the module's own lazy-init
  // db handle (unused on a 404 path — no route handler ever runs).
  app.use('/edge/platform/users', require('../../src/edge/routes/platform/users'));
  app.use('/edge/app/schema', require('../../src/edge/routes/app/schema'));
  const server = http.createServer(app);
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  const { port } = server.address();

  const request = (path) => new Promise((resolve, reject) => {
    const req = http.request({ host: '127.0.0.1', port, path, method: 'GET' }, (res) => {
      res.resume();
      res.on('end', () => resolve(res.statusCode));
    });
    req.on('error', reject);
    req.end();
  });

  try {
    for (const mountPath of ['/edge/platform/users', '/edge/app/schema']) {
      for (const tail of INSIDE_MOUNT_ENCODED_TAILS) {
        const status = await request(mountPath + tail);
        assert.strictEqual(status, 404, `${mountPath}${tail} matched a route`);
      }
    }
  } finally {
    await new Promise((resolve) => server.close(resolve));
  }
});

test('a raw backslash cannot smuggle a request past a mount-specific gate', async () => {
  const app = express();
  app.use(express.json());
  forwarding.mountRemainingRoutes(app);
  const server = http.createServer(app);
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  const { port } = server.address();

  const post = (path) => new Promise((resolve, reject) => {
    const req = http.request(
      { host: '127.0.0.1', port, path, method: 'POST', headers: { 'content-type': 'application/json' } },
      (res) => {
        let body = '';
        res.on('data', (c) => { body += c; });
        res.on('end', () => resolve({ status: res.statusCode, body }));
      },
    );
    req.on('error', reject);
    req.write('{"a":1}');
    req.end();
  });

  try {
    // The dedicated raw-body mount refuses a JSON content type.
    installFetch();
    const gated = await post('/api/schema/blueprint-import-yaml');
    assert.strictEqual(gated.status, 415);
    assert.strictEqual(fetchCalls.length, 0);

    // Express splits on '/' only, so the backslash variant misses that mount and
    // falls through to the general JSON proxy — the URL parser then restores the
    // separator. Same edge route, none of its gate.
    installFetch();
    const smuggled = await post('/api/schema/blueprint-import-yaml\\x');
    assert.strictEqual(
      fetchCalls.length, 0,
      `reached ${fetchCalls[0] && fetchCalls[0].url} without the media-type gate`,
    );
    assert.strictEqual(smuggled.status, 400);
  } finally {
    await new Promise((resolve) => server.close(resolve));
  }
});

test('a rejection is logged server-side with the offending path', async () => {
  const mount = proxyMounts.find((m) => m.mountPath === '/api/system-settings');
  assert.ok(mount, 'system-settings mount');
  installFetch();
  logLines.length = 0;
  await drive(mount, '/%2e%2e/%2e%2e/internal/system/auth-mode');
  const warned = logLines.filter((l) => l.level === 'warn');
  assert.ok(warned.length >= 1, 'expected a logger.warn for the rejection');
  const serialised = JSON.stringify(warned);
  assert.ok(serialised.includes('%2e%2e'), 'the offending raw path must be in the log binding');
});

test('the raw-body proxy is guarded too, after its media-type check', async () => {
  const mount = proxyMounts.find((m) => m.kind === 'raw');
  installFetch();
  const rejected = await drive(mount, '/%2e%2e/%2e%2e/internal/system/auth-mode');
  assert.strictEqual(fetchCalls.length, 0);
  assert.strictEqual(rejected.statusCode, 400);

  installFetch();
  const wrongType = await drive(mount, '/', { headers: { 'content-type': 'application/json' } });
  assert.strictEqual(fetchCalls.length, 0);
  assert.strictEqual(wrongType.statusCode, 415, 'media-type check still runs');
});

test('a real Express mount hands the undecoded traversal through, and the guard stops it', async () => {
  const app = express();
  app.use('/api/system-settings', realClient.createForwardingProxy('/edge/platform/settings'));
  const server = http.createServer(app);
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  const { port } = server.address();

  const request = (path) => new Promise((resolve, reject) => {
    const req = http.request({ host: '127.0.0.1', port, path, method: 'GET' }, (res) => {
      let body = '';
      res.on('data', (c) => { body += c; });
      res.on('end', () => resolve({ status: res.statusCode, body }));
    });
    req.on('error', reject);
    req.end();
  });

  try {
    installFetch();
    const attacked = await request('/api/system-settings/%2e%2e/%2e%2e/internal/system/auth-mode');
    assert.strictEqual(
      fetchCalls.length, 0,
      `traversal reached fetch: ${fetchCalls[0] && fetchCalls[0].url}`,
    );
    assert.strictEqual(attacked.status, 400);
    assert.ok(!attacked.body.includes('/edge/'), 'no edge path in the client payload');

    installFetch();
    const ok = await request('/api/system-settings/foo/bar');
    assert.strictEqual(fetchCalls.length, 1);
    assert.strictEqual(fetchCalls[0].url, `${EDGE_BASE_URL}/edge/platform/settings/foo/bar`);
    assert.strictEqual(ok.status, 200);
  } finally {
    await new Promise((resolve) => server.close(resolve));
  }
});

test('the PUT-only /api/auth/mode wrapper is guarded', async () => {
  const mount = allMounts.find((m) => m.mountPath === '/api/auth/mode');
  assert.ok(mount, '/api/auth/mode mount');

  installFetch();
  const before = factoryCalls.length;
  const ok = await drive(mount, '/', { method: 'PUT' });
  const edgePath = factoryCalls[before];
  assert.ok(typeof edgePath === 'string' && edgePath.startsWith('/edge/'), 'recorded edgePath');
  assert.strictEqual(fetchCalls.length, 1);
  assert.strictEqual(fetchCalls[0].url, EDGE_BASE_URL + edgePath);
  assert.strictEqual(ok.statusCode, 200);

  installFetch();
  const attacked = await drive(mount, '/%2e%2e/%2e%2e/internal/system/auth-mode', { method: 'PUT' });
  assert.strictEqual(fetchCalls.length, 0);
  assert.strictEqual(attacked.statusCode, 400);
});

test('the /api/auth/:id/is-admin custom handler cannot be walked out of its prefix', async () => {
  const mount = allMounts.find((m) => m.mountPath === '/api/auth/:id/is-admin');
  assert.ok(mount, 'is-admin mount');

  installFetch();
  const { res: okRes, out: okOut } = fakeRes();
  await mount.handler(
    { method: 'GET', params: { id: '42' }, query: {}, headers: {}, user: { id: 'u-1' } },
    okRes,
    (e) => { throw e || new Error('next()'); },
  );
  assert.strictEqual(fetchCalls.length, 1);
  const okPath = new URL(fetchCalls[0].url).pathname;
  assert.ok(okPath.startsWith('/edge/platform/'), okPath);
  assert.ok(okPath.endsWith('/42/is-admin'), okPath);
  assert.strictEqual(okOut.statusCode, 200);

  // Express decodes %2F into a single :id param, so the id can carry separators,
  // and the guard cannot catch that one — with no declared prefix it compares
  // the built path against itself. The id therefore has to arrive at the URL
  // already encoded, and the invariant is that it stays ONE segment.
  // Reachable as: GET /api/auth/x%2fy/is-admin
  for (const id of [
    '../../internal/system/auth-mode',
    'x/y',
    'x\\y',
    'a b',
    '..',
    '%2e%2e',
  ]) {
    installFetch();
    const { res, out } = fakeRes();
    await mount.handler(
      { method: 'GET', params: { id }, query: {}, headers: {}, user: { id: 'u-1' } },
      res,
      (e) => { throw e || new Error('next()'); },
    );
    if (fetchCalls.length === 1) {
      const { pathname } = new URL(fetchCalls[0].url);
      assert.strictEqual(
        pathname, `/edge/platform/auth-password/${encodeURIComponent(id)}/is-admin`,
        `id=${JSON.stringify(id)} must stay one segment`,
      );
      assert.strictEqual(pathname.split("/").length, 6, `id=${JSON.stringify(id)} added a segment`);
      assert.ok(!pathname.includes('/edge/internal/'), `id=${JSON.stringify(id)} reached the internal namespace`);
      assert.strictEqual(out.statusCode, 200);
    } else {
      assert.strictEqual(fetchCalls.length, 0);
      assert.strictEqual(out.statusCode, 400);
    }
  }
});

test('the /api/auth/:id/is-admin custom handler threads req into forwardToEdge (fmb-2105 H2)', async () => {
  const mount = allMounts.find((m) => m.mountPath === '/api/auth/:id/is-admin');
  assert.ok(mount, 'is-admin mount');

  let capturedReq;
  forwardOverride = async (opts) => { capturedReq = opts.req; return { status: 200, data: {}, contentType: 'application/json', headers: {} }; };
  const fakeReq = { method: 'GET', params: { id: '42' }, query: {}, headers: {}, user: { id: 'u-1' } };
  try {
    const { res } = fakeRes();
    await mount.handler(fakeReq, res, (e) => { throw e || new Error('next()'); });
  } finally {
    forwardOverride = null;
  }
  assert.strictEqual(capturedReq, fakeReq, 'is-admin forwardToEdge call must carry the SAME req object');
});

test('forwardToEdge rejects an origin swap', async () => {
  for (const path of ['//evil.example/x', '//evil.example/edge/platform/settings']) {
    installFetch();
    const result = await forwardToEdge({ method: 'GET', path, pathPrefix: '/edge/platform/settings' });
    assert.strictEqual(fetchCalls.length, 0, `${path} must not reach fetch`);
    assert.strictEqual(result.status, 400);

    installFetch();
    const defaulted = await forwardToEdge({ method: 'GET', path });
    assert.strictEqual(fetchCalls.length, 0, `${path} (default prefix) must not reach fetch`);
    assert.strictEqual(defaulted.status, 400);
  }
});

test('the prefix match is on a segment boundary, not a string prefix', async () => {
  installFetch();
  const sibling = await forwardToEdge({
    method: 'GET',
    path: '/edge/platform/settings-evil/x',
    pathPrefix: '/edge/platform/settings',
  });
  assert.strictEqual(fetchCalls.length, 0, 'a sibling prefix must not be treated as inside');
  assert.strictEqual(sibling.status, 400);

  installFetch();
  const exact = await forwardToEdge({
    method: 'GET',
    path: '/edge/platform/settings',
    pathPrefix: '/edge/platform/settings',
  });
  assert.strictEqual(fetchCalls.length, 1);
  assert.strictEqual(fetchCalls[0].url, `${EDGE_BASE_URL}/edge/platform/settings`);
  assert.strictEqual(exact.status, 200);
});

test('an absent pathPrefix defaults to the caller-declared path, never to a permissive one', async () => {
  // Every literal-path caller (13 sites) keeps working…
  for (const path of [
    '/edge/internal/machine-token/resolve',
    '/edge/internal/connectors/prepare',
    '/edge/internal/connectors/result',
    '/edge/internal/flow-steps/prepare',
    '/edge/internal/flow-steps/result',
    '/edge/internal/flow-recipes/run-begin',
    '/edge/internal/flow-recipes/run-finalize',
    '/edge/internal/flow-recipes/reset-flow-link',
    '/edge/internal/public-read/blueprints',
    '/edge/internal/public-read/blueprint-by-path',
    '/edge/internal/public-read/templates',
    '/edge/internal/public-read/templates/abc-123',
    '/edge/internal/public-read/runs',
    '/edge/internal/public-write/templates',
  ]) {
    installFetch();
    const result = await forwardToEdge({ method: 'POST', path, body: { a: 1 } });
    assert.strictEqual(fetchCalls.length, 1, `${path} must forward`);
    assert.strictEqual(fetchCalls[0].url, EDGE_BASE_URL + path);
    assert.strictEqual(result.status, 200);
  }

  // …and a literal path that had user input interpolated into it is rejected
  // the moment normalisation changes it, without the caller opting in.
  for (const path of [
    '/edge/platform/auth-password/../../internal/system/auth-mode/is-admin',
    '/edge/internal/public-read/templates/..',
    '/edge/internal/public-read/templates/%2e%2e/%2e%2e/system/auth-mode',
    // Spells no dot-segment and stays under /edge — only the caller-declared
    // path as the default prefix rejects this one.
    '/edge/internal/public-read/templates/..\\..\\system/auth-mode',
    '/edge/internal/public-read/templates/a b',
  ]) {
    installFetch();
    const result = await forwardToEdge({ method: 'GET', path });
    assert.strictEqual(fetchCalls.length, 0, `${path} must not reach fetch`);
    assert.strictEqual(result.status, 400);
  }

  // An explicitly empty prefix is a rejection, not a wildcard.
  for (const pathPrefix of ['', '/', 'edge', null]) {
    installFetch();
    const result = await forwardToEdge({
      method: 'GET',
      path: '/edge/internal/system/auth-mode',
      pathPrefix,
    });
    if (pathPrefix === null) {
      // `null` is nullish → falls back to the safe default (the path itself).
      assert.strictEqual(fetchCalls.length, 1);
      assert.strictEqual(result.status, 200);
    } else {
      assert.strictEqual(fetchCalls.length, 0, `pathPrefix=${JSON.stringify(pathPrefix)} must not forward`);
      assert.strictEqual(result.status, 400);
    }
  }
});

test('the guard runs before the circuit breaker, so a traversal is never masked as an outage', async () => {
  _resetCircuitBreaker();
  installFetch(async () => { throw new Error('edge down'); });
  for (let i = 0; i < 3; i += 1) {
    await forwardToEdge({ method: 'GET', path: '/edge/platform/settings', pathPrefix: '/edge/platform/settings' });
  }
  assert.strictEqual(getCircuitState(), 'open', 'breaker must be open for this probe');

  installFetch();
  const result = await forwardToEdge({
    method: 'GET',
    path: '/edge/platform/settings/../../internal/system/auth-mode',
    pathPrefix: '/edge/platform/settings',
  });
  assert.strictEqual(fetchCalls.length, 0);
  assert.strictEqual(result.status, 400, 'a traversal must be 400, not the breaker 503');
  assert.notStrictEqual(result.data.error.code, 'EDGE_UNAVAILABLE');
  _resetCircuitBreaker();
});

test('a traversal cannot borrow the setup-path circuit-breaker bypass', async () => {
  _resetCircuitBreaker();
  installFetch();
  const result = await forwardToEdge({
    method: 'POST',
    path: '/edge/platform/setup/../../internal/system/auth-mode',
    pathPrefix: '/edge/platform/settings',
    body: {},
  });
  assert.strictEqual(fetchCalls.length, 0);
  assert.strictEqual(result.status, 400);
});

// ── every literal-path caller, harvested from src/infra rather than listed ──
// A hand-written list of call sites has been wrong every time it was measured
// here, so the corpus is generated: walk src/infra, pull every `path:` argument
// handed to forwardToEdge, resolve the module-level string constants it
// interpolates, and stand in a benign value for anything else.
function harvestLiteralPaths() {
  const fs = require('node:fs');
  const nodePath = require('node:path');
  const root = nodePath.join(__dirname, '..', '..', 'src', 'infra');
  const found = [];

  const walk = (dir) => {
    for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
      const full = nodePath.join(dir, entry.name);
      if (entry.isDirectory()) walk(full);
      else if (entry.name.endsWith('.js')) scan(full);
    }
  };

  const scan = (file) => {
    const source = fs.readFileSync(file, 'utf8');
    const constants = new Map();
    for (const m of source.matchAll(/^const\s+([A-Z0-9_]+)\s*=\s*'([^']*)'/gm)) {
      constants.set(m[1], m[2]);
    }
    for (const line of source.split('\n')) {
      const trimmed = line.trim();
      if (trimmed.startsWith('*') || trimmed.startsWith('//') || trimmed.startsWith('/*')) continue;
      // Every string literal, not only the ones written as `path:` — public-read
      // hands its edge paths to a helper, and a `path:` regex silently missed
      // all six of them.
      for (const m of trimmed.matchAll(/'([^']+)'|`([^`]+)`/g)) {
        let value = m[1] !== undefined ? m[1] : m[2];
        value = value.replace(/\$\{([A-Z0-9_]+)\}/g, (whole, name) =>
          (constants.has(name) ? constants.get(name) : whole));
        // Anything still interpolated is runtime input; a benign value stands in.
        value = value.replace(/\$\{[^}]*\}/g, 'benign-value-1');
        if (!value.startsWith('/edge/')) continue;
        found.push({ file: nodePath.relative(root, file), value });
      }
    }
  };

  walk(root);
  return found;
}

test('every literal-path caller in src/infra still forwards', () => {
  const harvested = harvestLiteralPaths();
  // Floor: the investigator counted 13 call sites outside the two factories.
  assert.ok(harvested.length >= 13, `harvested only ${harvested.length} literal paths`);
  const files = new Set(harvested.map((h) => h.file));
  for (const expected of [
    'forwarding.js',
    'lib/machine-token-verify.js',
    'lib/flow-dispatch-step.js',
    'routes/connector-fetch.js',
    'routes/flow-recipe-run.js',
    'routes/public-read.js',
    'routes/public-write.js',
  ]) {
    assert.ok(files.has(expected), `no literal path harvested from ${expected}`);
  }
  for (const { file, value } of harvested) {
    const verdict = realClient._resolveUpstreamUrl(value, value, EDGE_BASE_URL);
    assert.strictEqual(
      verdict.ok, true,
      `${file}: ${value} rejected (${verdict.reason}) — the guard broke a real caller`,
    );
    assert.strictEqual(verdict.url.pathname, value);
  }
});

test('the public blueprint name-path never becomes part of the upstream path', async () => {
  const publicRead = require('../../src/infra/routes/public-read');
  const app = express();
  app.use((req, _res, next) => { req.log = makeStubReqLog(); next(); }); // TEST-ONLY: production always sets req.log via createRequestId (request-id.js) before any router; this bare app has no such middleware, so a route's req.log.<level>() call would otherwise throw against undefined.
  app.use('/api/public/v1', (req, _res, next) => {
    req.machinePrincipal = { sub: 'svc-1', scope: 'read' };
    next();
  }, publicRead);
  const server = http.createServer(app);
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  const { port } = server.address();

  const request = (path) => new Promise((resolve, reject) => {
    const req = http.request({ host: '127.0.0.1', port, path, method: 'GET' }, (res) => {
      let body = '';
      res.on('data', (c) => { body += c; });
      res.on('end', () => resolve({ status: res.statusCode, body }));
    });
    req.on('error', reject);
    req.end();
  });

  try {
    installFetch();
    const res = await request('/api/public/v1/blueprints/%2e%2e/%2e%2e/internal/system/auth-mode');
    assert.strictEqual(fetchCalls.length, 1, 'the name-path route still forwards');
    const url = new URL(fetchCalls[0].url);
    assert.strictEqual(
      url.pathname, '/edge/internal/public-read/blueprint-by-path',
      'the client-supplied name-path must stay out of the upstream path',
    );
    assert.ok(url.searchParams.get('p'), 'the name-path travels base64url in ?p');
    assert.strictEqual(res.status, 200);
  } finally {
    await new Promise((resolve) => server.close(resolve));
  }
});

test('the public API reports a bad path as a client error, not an outage', async () => {
  // What the EXTERNAL caller receives — the published contract says 503 means
  // "retry", and an integrator with a client-side bug would then retry forever
  // against a per-account budget.
  // Same order as the production pipeline (public-namespace.js): parser, then
  // write, then read — the read router ends in a terminal 404, so a reversed
  // order would answer POSTs itself. Only the Bearer gate is stubbed (it needs a
  // live S2S resolve); the limiter and content-type guard are not in play here.
  const app = express();
  app.use((req, _res, next) => { req.log = makeStubReqLog(); next(); }); // TEST-ONLY: production always sets req.log via createRequestId (request-id.js) before any router; this bare app has no such middleware, so a route's req.log.<level>() call would otherwise throw against undefined.
  app.use('/api/public/v1', (req, _res, next) => {
    req.machinePrincipal = { sub: 'svc-1', scope: 'read write' };
    next();
  });
  app.use('/api/public/v1', express.json({ limit: '1mb' }));
  app.use('/api/public/v1', require('../../src/infra/routes/public-write'));
  app.use('/api/public/v1', require('../../src/infra/routes/public-read'));
  const server = http.createServer(app);
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  const { port } = server.address();

  const call = (path, method = 'GET', body) => new Promise((resolve, reject) => {
    const headers = body ? { 'content-type': 'application/json' } : {};
    const req = http.request({ host: '127.0.0.1', port, path, method, headers }, (res) => {
      let out = '';
      res.on('data', (c) => { out += c; });
      res.on('end', () => resolve({ status: res.statusCode, body: out }));
    });
    req.on('error', reject);
    if (body) req.write(body);
    req.end();
  });

  try {
    installFetch();
    const dotId = await call('/api/public/v1/templates/..');
    assert.strictEqual(fetchCalls.length, 0, 'a dot-segment id must not reach edge');
    assert.strictEqual(dotId.status, 400, 'a bad id is a client error');
    assert.deepStrictEqual(JSON.parse(dotId.body), { error: 'validation_failed' });

    // The write relay takes the same decision, through the same helper. Its own
    // upstream path is a literal, so the rejection is produced by the real guard
    // and handed to the real route.
    installFetch();
    const rejection = await forwardToEdge({
      method: 'POST',
      path: '/edge/internal/public-write/templates/..',
    });
    assert.strictEqual(rejection.status, 400, 'guard produced the envelope under test');
    forwardOverride = async () => rejection;
    try {
      const written = await call('/api/public/v1/templates', 'POST', '{"blueprint_id":"b-1"}');
      assert.strictEqual(written.status, 400, 'the write relay must not report a client error as an outage');
      assert.deepStrictEqual(JSON.parse(written.body), { error: 'validation_failed' });
    } finally {
      forwardOverride = null;
    }

    // An id that is merely encoded is no longer refused at all — it goes back to
    // being edge's 404 to give, as it was before the guard existed.
    installFetch();
    const encodedId = await call('/api/public/v1/templates/foo%2Fbar');
    assert.strictEqual(fetchCalls.length, 1, 'an encoded id must reach edge');
    assert.strictEqual(
      new URL(fetchCalls[0].url).pathname,
      '/edge/internal/public-read/templates/foo%2Fbar',
    );
    assert.strictEqual(encodedId.status, 200);
  } finally {
    await new Promise((resolve) => server.close(resolve));
  }
});

test('a decode chain longer than the cap is refused rather than given up on', async () => {
  // 12 levels of percent-encoding over a single dot. The decode loop is bounded,
  // so it cannot reach the dot segment — "still changing when the budget ran
  // out" has to be a rejection, or the bound becomes the way through.
  const deep = '%25252525252525252525252e';
  installFetch();
  const result = await forwardToEdge({
    method: 'GET',
    path: `/edge/app/schema/${deep}/x`,
    pathPrefix: '/edge/app/schema',
  });
  assert.strictEqual(fetchCalls.length, 0, `reached ${fetchCalls[0] && fetchCalls[0].url}`);
  assert.strictEqual(result.status, 400);

  // The same chain one level shallower resolves to a dot segment within the
  // budget, so it is caught by the dot rule instead — both ends are covered.
  installFetch();
  const shallow = await forwardToEdge({
    method: 'GET',
    path: '/edge/app/schema/%25252e/x',
    pathPrefix: '/edge/app/schema',
  });
  assert.strictEqual(fetchCalls.length, 0);
  assert.strictEqual(shallow.status, 400);
});

test('the shared relay reads a code out of both body shapes', () => {
  const { upstreamErrorCode, publicMappingForInternalCode, isPublicErrorCode } =
    require('../../src/shared/lib/public-errors');

  assert.strictEqual(upstreamErrorCode({ error: 'not_found' }), 'not_found');
  assert.strictEqual(
    upstreamErrorCode({ error: { code: 'INVALID_UPSTREAM_PATH', message: 'Invalid request path.' } }),
    'INVALID_UPSTREAM_PATH',
  );
  assert.strictEqual(upstreamErrorCode({ error: {} }), undefined);
  assert.strictEqual(upstreamErrorCode(null), undefined);
  assert.strictEqual(upstreamErrorCode('a string body'), undefined);

  assert.deepStrictEqual(
    publicMappingForInternalCode('INVALID_UPSTREAM_PATH'),
    { status: 400, code: 'validation_failed' },
  );
  // Widening the read must not widen what may travel outward.
  assert.strictEqual(publicMappingForInternalCode('EDGE_UNAVAILABLE'), undefined);
  assert.strictEqual(publicMappingForInternalCode('DB_ERROR'), undefined);
  assert.strictEqual(publicMappingForInternalCode('constructor'), undefined);
  assert.strictEqual(isPublicErrorCode('INVALID_UPSTREAM_PATH'), false);
});

test('query parameters still travel with an accepted path', async () => {
  installFetch();
  const result = await forwardToEdge({
    method: 'GET',
    path: '/edge/internal/public-read/blueprints',
    query: { limit: 50, cursor: 'abc' },
  });
  assert.strictEqual(fetchCalls.length, 1);
  assert.strictEqual(
    fetchCalls[0].url,
    `${EDGE_BASE_URL}/edge/internal/public-read/blueprints?limit=50&cursor=abc`,
  );
  assert.strictEqual(result.status, 200);
});
