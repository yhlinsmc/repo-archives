'use strict';

/**
 * rate-limit-factory-composes-log-first.test.js — the factory, not the
 * definition, owns logRateLimited (proof-by-construction). A bespoke
 * `handler` a definition supplies must never be the ONLY thing express-rate-
 * limit calls on rejection — the factory always composes: log first, THEN
 * delegate to the caller's handler (or the default response when none was
 * given). This makes "a handler forgot to call logRateLimited" a class that
 * cannot exist, rather than a class the literal-429 lint tries (and fails) to
 * catch via a member-expression status call.
 *
 * Run: node --test docker-api/tests/infra/rate-limit-factory-composes-log-first.test.js
 */
const { test } = require('node:test');
const assert = require('node:assert/strict');
const limiters = require('../../src/infra/limiters');

function makeRes() {
  const res = { locals: {}, statusCode: 200 };
  res.status = (code) => { res.statusCode = code; return res; };
  res.send = () => res;
  res.json = () => res;
  res.redirect = () => res;
  return res;
}

test('a caller-supplied handler that never calls logRateLimited still gets logged — the factory composes it in', () => {
  limiters._internals.rateLimitRegistry.length = 0;
  let customHandlerRan = false;
  limiters.rateLimit({
    _name: 'noLogHandler',
    keyType: 'ip',
    windowMs: 60000,
    max: 1,
    handler: (req, res) => {
      customHandlerRan = true;
      res.status(429).send('a bespoke body that never calls logRateLimited itself');
    },
  });
  const entry = limiters._internals.rateLimitRegistry.find((e) => e.name === 'noLogHandler');
  assert.ok(entry, 'the definition registered');
  const res = makeRes();
  const req = { ip: '203.0.113.9', headers: {}, query: {}, res };
  res.req = req;
  entry.handler(req, res, () => {}, { statusCode: 429, message: 'x', windowMs: 60000, keyGenerator: (r) => `ip:${r.ip}` });
  assert.ok(customHandlerRan, 'the caller-supplied handler still ran — delegation, not a silent replacement');
  assert.deepEqual(
    res.locals.logPolicy,
    { logged: true, kind: 'security' },
    'the factory logged the rejection even though the custom handler itself never called logRateLimited',
  );
});

test('a definition with no handler at all still gets the default response AND is logged', () => {
  limiters._internals.rateLimitRegistry.length = 0;
  limiters.rateLimit({
    _name: 'noHandlerAtAll',
    keyType: 'ip',
    windowMs: 60000,
    max: 1,
    message: { error: 'rate_limited' },
  });
  const entry = limiters._internals.rateLimitRegistry.find((e) => e.name === 'noHandlerAtAll');
  const res = makeRes();
  let sentBody;
  res.send = (b) => { sentBody = b; return res; };
  const req = { ip: '198.51.100.4', headers: {}, query: {}, res };
  res.req = req;
  entry.handler(req, res, () => {}, { statusCode: 429, message: { error: 'rate_limited' }, windowMs: 60000, keyGenerator: (r) => `ip:${r.ip}` });
  assert.equal(res.statusCode, 429);
  assert.deepEqual(sentBody, { error: 'rate_limited' });
  assert.deepEqual(res.locals.logPolicy, { logged: true, kind: 'security' });
});
