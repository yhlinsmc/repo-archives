'use strict';

/**
 * rate-limit-security-logs-once.test.js — the four-path write proven single
 * (spec §5/§6, Gate A). A rejected/failed-auth request must log EXACTLY one
 * line: the stream helper's line, with the request finish line suppressed.
 * Driven through a REAL express app, REAL rate-limit middleware, and a REAL
 * pino sync destination — the count is measured, not reasoned.
 *
 * Run: node --test docker-api/tests/infra/rate-limit-security-logs-once.test.js
 */
// config.js hard-exits at load without JWT_SECRET (local-mode requirement) —
// set before requiring infra/middleware/auth.js, same pattern as
// infra-impersonation-auth.test.js.
process.env.JWT_SECRET = process.env.JWT_SECRET || 'test-secret-rate-limit-logs-once-min32';

const { test } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const path = require('node:path');
const fs = require('node:fs');
const { execFileSync } = require('node:child_process');
const { Writable } = require('node:stream');
const express = require('express');
const pino = require('pino');
const { _internals: loggerInternals } = require('../../src/shared/lib/logger');
const { createRequestLog } = require('../../src/shared/middleware/request-log');
const { logSecurity, logRateLimited } = require('../../src/shared/lib/log-streams');
const limiters = require('../../src/infra/limiters');
const authMiddleware = require('../../src/infra/middleware/auth');
const edgeClient = require('../../src/infra/lib/edge-state-client');

function build() {
  const records = [];
  const sink = new Writable({
    write(chunk, _e, cb) {
      for (const line of chunk.toString().split('\n')) if (line.trim()) records.push(JSON.parse(line));
      cb();
    },
  });
  const base = pino({ ...loggerInternals.loggerOptions, level: 'debug' }, sink);
  let n = 0;
  const app = express();
  app.use((req, res, next) => { req.id = `it${n += 1}`; req.log = base.child({ req_id: req.id }); next(); });
  app.use(createRequestLog());

  const msgLimiter = limiters.rateLimit({
    _name: 'itMsg', keyType: 'ip', windowMs: 60000, max: 1, standardHeaders: true, legacyHeaders: false,
    message: { error: 'rate_limited' },
  });
  app.use('/msg', msgLimiter);
  app.get('/msg', (_req, res) => res.json({ ok: true }));

  // The factory composes logRateLimited BEFORE delegating to this handler —
  // a bespoke handler no longer calls it itself.
  const bespoke = limiters.rateLimit({
    _name: 'itBespoke', keyType: 'ip', windowMs: 60000, max: 1, standardHeaders: true, legacyHeaders: false,
    message: { error: 'rl' },
    handler: (req, res, _n, opts) => {
      res.status(opts.statusCode).json({ error: 'rl' });
    },
  });
  app.use('/bespoke', bespoke);
  app.get('/bespoke', (_req, res) => res.json({ ok: true }));

  app.get('/login-fail', (req, res) => {
    logSecurity(req, { event: 'login_fail', level: 'warn', name: 'alice@example.com', reason: 'invalid_password', terminal: true }, 'login failed');
    res.status(401).json({ error: 'unauthorized' });
  });

  // Same shape as infra/middleware/auth.js's banned-user sites: a MIDDLEWARE
  // running before route dispatch cannot tell whether the route ahead is
  // public or protected, so it notes the fact (deferred) instead of deciding
  // terminality itself. Two downstream routes exercise both outcomes.
  function noteBanned(req, _res, next) {
    logSecurity(req, { event: 'login_blocked', level: 'warn', name: 'bob@example.com', reason: 'account_banned', deferred: true }, 'banned user blocked');
    next();
  }
  // Public route (e.g. the diagnostics tier): the request still succeeds.
  app.get('/public-mode', noteBanned, (_req, res) => res.status(200).json({ mode: 'diagnostics' }));
  // Protected route: req.user never got set, so a generic downstream auth
  // gate 401s — no logSecurity call of its own, exactly like requireAuth.
  app.get('/protected', noteBanned, (_req, res) => res.status(401).json({ error: 'unauthorized' }));

  // Same shape as edge/middleware/s2s-verify.js's key-mismatch site: the
  // 401 IS the request's terminal outcome — terminal:true.
  app.get('/s2s-mismatch', (req, res) => {
    logSecurity(req, { event: 's2s_key_mismatch', level: 'warn', terminal: true }, 'S2S key mismatch');
    res.status(401).json({ error: 'unauthorized' });
  });

  // Same shape as infra/middleware/auth.js's resolveImpersonation success
  // path: NON-terminal — the request still owes its own finish line.
  app.get('/impersonate', (req, res) => {
    logSecurity(req, { event: 'impersonate_start', level: 'info', target_id: 'user-9' }, 'impersonation start');
    res.status(200).json({ ok: true });
  });

  // Same shape as edge/routes/platform/users.js's updateRole: the UPDATE has
  // already committed and this handler responds itself — terminal:true.
  app.post('/role-change', (req, res) => {
    logSecurity(req, { event: 'role_change', level: 'info', target_id: 'user-5', role_from: 'user', role_to: 'editor', terminal: true }, 'role changed');
    res.json({ ok: true });
  });

  app.post('/forbidden', (_req, res) => res.status(403).json({ error: 'forbidden' }));

  const server = http.createServer(app);
  return { records, server };
}

// A real app mounting the REAL infra/middleware/auth.js — proves the design
// fix on the actual site (not a fixture mimicking its shape): a middleware
// cannot know whether the route ahead is public or protected, so it must
// defer rather than decide. `req.oidc` is faked (no live Keycloak session
// exists in this harness) so `authMiddleware` takes its OIDC branch.
function buildAuthApp() {
  const records = [];
  const sink = new Writable({
    write(chunk, _e, cb) {
      for (const line of chunk.toString().split('\n')) if (line.trim()) records.push(JSON.parse(line));
      cb();
    },
  });
  const base = pino({ ...loggerInternals.loggerOptions, level: 'debug' }, sink);
  let n = 0;
  const app = express();
  app.use((req, res, next) => { req.id = `au${n += 1}`; req.log = base.child({ req_id: req.id }); next(); });
  app.use(createRequestLog());
  app.use((req, _res, next) => {
    req.oidc = { isAuthenticated: () => true, user: { sub: 'kc-banned-1' } };
    next();
  });
  app.use(authMiddleware);
  // The public diagnostics tier: never gates on req.user.
  app.get('/api/auth/mode', (_req, res) => res.status(200).json({ mode: 'local' }));
  // A protected route: a generic downstream auth gate, no logSecurity of its own.
  app.get('/api/schema/user_templates', (req, res) => {
    if (!req.user) return res.status(401).json({ error: 'unauthorized' });
    res.status(200).json({ ok: true });
  });
  const server = http.createServer(app);
  return { records, server };
}

function listen(server) {
  return new Promise((resolve) => server.listen(0, '127.0.0.1', () => resolve(server.address().port)));
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

test('a 429 (message-only limiter), a 429 (bespoke handler), a 401 login failure, and a 403 each log exactly one line', async () => {
  limiters._internals.rateLimitRegistry.length = 0;
  const { records, server } = build();
  const port = await listen(server);
  const base = `http://127.0.0.1:${port}`;
  try {
    // Prime each limiter's bucket, then measure only the rejected request.
    await fetch(`${base}/msg`); await sleep(15);
    await fetch(`${base}/bespoke`); await sleep(15);
    records.length = 0;

    const r1 = await fetch(`${base}/msg`); await sleep(15);
    const msgLines = records.slice();
    assert.equal(r1.status, 429);
    assert.equal(msgLines.length, 1, `429 message-only: expected 1 line, got ${JSON.stringify(msgLines)}`);
    assert.equal(msgLines[0].kind, 'security');
    assert.equal(msgLines[0].limiter, 'itMsg');
    assert.equal(msgLines[0].key_type, 'ip');

    records.length = 0;
    const r2 = await fetch(`${base}/bespoke`); await sleep(15);
    const beLines = records.slice();
    assert.equal(r2.status, 429);
    assert.equal(beLines.length, 1, `429 bespoke: expected 1 line, got ${JSON.stringify(beLines)}`);
    assert.equal(beLines[0].limiter, 'itBespoke');

    records.length = 0;
    const r3 = await fetch(`${base}/login-fail`); await sleep(15);
    const loginLines = records.slice();
    assert.equal(r3.status, 401);
    assert.equal(loginLines.length, 1, `401 login failure: expected 1 line, got ${JSON.stringify(loginLines)}`);
    assert.equal(loginLines[0].kind, 'security');
    assert.equal(loginLines[0].event, 'login_fail');
    assert.equal(loginLines[0].name, 'alice', 'attempted username is de-Emailed');
    const s = JSON.stringify(loginLines[0]);
    assert.ok(!s.includes('@example.com'), 'no email in the security line');

    records.length = 0;
    const r4 = await fetch(`${base}/forbidden`, { method: 'POST' }); await sleep(15);
    const forbidLines = records.slice();
    assert.equal(r4.status, 403);
    assert.equal(forbidLines.length, 1, `403: expected 1 finish line, got ${JSON.stringify(forbidLines)}`);
    assert.equal(forbidLines[0].kind, 'security');
    assert.equal(forbidLines[0].level, 'warn');

    // Row (a): a banned user's deferred note reaches a PUBLIC route — the
    // request still succeeds, and the finish line stays `access`, but it
    // must still carry `event` so the block is greppable on a 200.
    records.length = 0;
    const rA = await fetch(`${base}/public-mode`); await sleep(15);
    const publicLines = records.slice();
    assert.equal(rA.status, 200);
    assert.equal(publicLines.length, 1, `banned user, public route: expected 1 line, got ${JSON.stringify(publicLines)}`);
    assert.equal(publicLines[0].kind, 'access');
    assert.equal(publicLines[0].event, 'login_blocked', 'a banned user\'s successful public call is still greppable');
    assert.equal(publicLines[0].reason, undefined, 'a 2xx finish carries only event, not the full note');

    // Row (b): the same deferred note reaches a PROTECTED route — the
    // downstream gate 401s with no logSecurity call of its own, so the note
    // must carry the full event onto the finish line, which becomes security.
    records.length = 0;
    const rB = await fetch(`${base}/protected`); await sleep(15);
    const protectedLines = records.slice();
    assert.equal(rB.status, 401);
    assert.equal(protectedLines.length, 1, `banned user, protected route: expected 1 line, got ${JSON.stringify(protectedLines)}`);
    assert.equal(protectedLines[0].kind, 'security');
    assert.equal(protectedLines[0].event, 'login_blocked');
    assert.equal(protectedLines[0].reason, 'account_banned');
    assert.equal(protectedLines[0].name, 'bob', 'attempted username is de-Emailed');
    assert.equal(protectedLines[0].ip, '127.0.0.1', 'the note\'s ip is not duplicated onto the finish line by a stray key');
    assert.ok(!JSON.stringify(protectedLines[0]).includes('@example.com'), 'no email in the line');

    // Row (c): s2s_key_mismatch is unaffected by this fix batch (the same
    // function that logs it also sends the response) — still exactly one.
    records.length = 0;
    const r6 = await fetch(`${base}/s2s-mismatch`); await sleep(15);
    const mismatchLines = records.slice();
    assert.equal(r6.status, 401);
    assert.equal(mismatchLines.length, 1, `s2s_key_mismatch 401: expected 1 line, got ${JSON.stringify(mismatchLines)}`);
    assert.equal(mismatchLines[0].event, 's2s_key_mismatch');
    assert.equal(mismatchLines[0].ip, '127.0.0.1');

    // A non-terminal impersonate_start line does NOT suppress the request's
    // own finish line — exactly 2 lines (the event + the normal GET/200
    // access-debug finish row), never the target's email.
    records.length = 0;
    const r7 = await fetch(`${base}/impersonate`); await sleep(15);
    const impLines = records.slice();
    assert.equal(r7.status, 200);
    assert.equal(impLines.length, 2, `impersonate_start: expected 2 lines (event + finish), got ${JSON.stringify(impLines)}`);
    const startLine = impLines.find((l) => l.event === 'impersonate_start');
    const finishLine = impLines.find((l) => l.kind === 'access');
    assert.ok(startLine, 'impersonate_start line present');
    assert.equal(startLine.level, 'info');
    assert.equal(startLine.target_id, 'user-9');
    assert.ok(finishLine, 'the request still owes its own finish line');
    assert.equal(finishLine.level, 'debug');

    // role_change: the UPDATE already committed and the handler responds
    // itself — terminal:true, exactly one line, never a plain audit row too.
    records.length = 0;
    const r8 = await fetch(`${base}/role-change`, { method: 'POST' }); await sleep(15);
    const roleLines = records.slice();
    assert.equal(r8.status, 200);
    assert.equal(roleLines.length, 1, `role_change: expected 1 line, got ${JSON.stringify(roleLines)}`);
    assert.equal(roleLines[0].kind, 'security');
    assert.equal(roleLines[0].event, 'role_change');
    assert.equal(roleLines[0].role_from, 'user');
    assert.equal(roleLines[0].role_to, 'editor');
  } finally {
    server.close();
  }
});

test('real infra/middleware/auth.js: a banned user\'s deferred note reaches a public route as one access line and a protected route as one security line', async () => {
  authMiddleware._resetCacheForTests();
  const origResolve = edgeClient.resolveIdentity;
  edgeClient.resolveIdentity = async () => ({ user: null, banned: true, pool_ready: true });
  const { records, server } = buildAuthApp();
  try {
    const port = await listen(server);
    const base = `http://127.0.0.1:${port}`;

    records.length = 0;
    const rPublic = await fetch(`${base}/api/auth/mode`); await sleep(15);
    const publicLines = records.slice();
    assert.equal(rPublic.status, 200);
    assert.equal(publicLines.length, 1, `banned user, public route: expected 1 line, got ${JSON.stringify(publicLines)}`);
    assert.equal(publicLines[0].kind, 'access');
    assert.equal(publicLines[0].event, 'login_blocked');
    assert.equal(publicLines[0].reason, undefined, 'a 2xx finish carries only event');

    records.length = 0;
    const rProtected = await fetch(`${base}/api/schema/user_templates`); await sleep(15);
    const protectedLines = records.slice();
    assert.equal(rProtected.status, 401);
    assert.equal(protectedLines.length, 1, `banned user, protected route: expected 1 line, got ${JSON.stringify(protectedLines)}`);
    assert.equal(protectedLines[0].kind, 'security');
    assert.equal(protectedLines[0].event, 'login_blocked');
    assert.equal(protectedLines[0].reason, 'account_banned');
  } finally {
    server.close();
    edgeClient.resolveIdentity = origResolve;
  }
});

// ── census: every logSecurity site that ends a request is accounted for ──
//
// A site is exactly one of:
//  - terminal:true — raised from the function that itself sends the
//    response; the finish line is suppressed for it.
//  - deferred:true — raised from middleware that cannot yet know the
//    outcome; on KNOWN_DEFERRED below, the finish line folds the note in.
//  - on KNOWN_NON_TERMINAL — a genuine non-terminal companion line by
//    deliberate design, with the reason carried as DATA on the entry (not
//    only a comment) so it travels with an assertion failure.
// A NEW site that is none of these throws this test into failure, forcing a
// decision instead of a silent 2-line leak.
const SRC_ROOT = path.join(__dirname, '..', '..', 'src');
const KNOWN_NON_TERMINAL = new Map([
  ['impersonate_refused', 'the escalation attempt is refused; the admin\'s own request continues normally to its own finish line'],
  ['impersonate_start', 'a per-request info line alongside the request\'s own finish line, not a substitute for it — otherwise invisible at production LOG_LEVEL=info'],
  ['login_ok', 'infra/lib/oidc-fresh-login.js\'s SSO bridge: the OIDC callback\'s own finish line stays, this adds the semantic event alongside it, fire-and-forget'],
]);
const KNOWN_DEFERRED = new Map([
  ['login_blocked', 'a banned-user check runs before route dispatch — the route ahead may be public or protected, so the middleware cannot decide terminality itself'],
]);

function findLogSecuritySites() {
  const out = execFileSync('grep', ['-rn', 'logSecurity(', SRC_ROOT, '--include=*.js'], { encoding: 'utf8' });
  return out
    .split('\n')
    .filter((l) => l.trim() && !l.includes(`${path.sep}log-streams.js:`))
    .map((line) => {
      // grep -rn shape: "<file>:<lineNo>:<content>" — file paths here are
      // always absolute (SRC_ROOT is absolute), so the FIRST two colons are
      // the delimiters; everything after is the (colon-safe-enough) source
      // line, matched the same way the rest of this file's regexes already
      // read it.
      const m = line.match(/^([^:]+):(\d+):/);
      return {
        line,
        file: m ? m[1] : null,
        lineNo: m ? Number(m[2]) : null,
        terminal: /terminal:\s*true/.test(line),
        deferred: /deferred:\s*true/.test(line),
        event: (line.match(/event:\s*'([^']+)'/) || [])[1],
      };
    });
}

// ── proof form: terminal/deferred are checked against the SITE'S OWN
// enclosing function, not just declared on the call ──
//
// "Bounded text scan of the enclosing function" (not a full AST): a single
// forward pass over the file tracks brace depth (string/comment aware, so a
// stray brace inside a WHY-comment's backtick-quoted code sample — the same
// hazard res-only-responder-threads-req.test.js's census hit — can never
// corrupt the count) and classifies every `{` as opening a FUNCTION frame or a
// plain control-flow frame (if/else/for/while/switch/try/catch); the
// innermost FUNCTION frame still open at the call site is "the enclosing
// function" this test reasons about.
function classifyBraceLine(lineText) {
  const t = lineText.trim();
  if (/^(?:export\s+)?(?:default\s+)?(?:async\s+)?function\b/.test(t)) return 'function';
  if (/^(?:module\.exports(?:\.[\w$]+)?\s*=\s*)?(?:async\s*)?\([^)]*\)\s*=>\s*\{?\s*$/.test(t)) return 'function';
  if (/=>\s*\{\s*$/.test(t)) return 'function';
  // Method shorthand (`handler(req, res) {`) — deliberately excludes the
  // control-flow keywords, which share the same textual shape.
  if (/^(?:async\s+)?[\w$]+\s*\([^)]*\)\s*\{\s*$/.test(t) && !/^(?:if|for|while|switch|catch|function)\b/.test(t)) return 'function';
  return 'other';
}

/**
 * Blanks every comment and string-literal body to whitespace, preserving
 * length (and newlines, so line offsets survive) so a caller can regex- or
 * brace-scan the result without either kind of quoted text corrupting the
 * answer — one implementation shared by the brace walk below and the
 * responder/next() proof, instead of the brace walk alone being comment/
 * string aware while the proof regexes ran on the raw text.
 * @returns {string} same length as `source`.
 */
function stripCommentsAndStrings(source) {
  const out = new Array(source.length);
  let i = 0;
  let inStr = null;
  while (i < source.length) {
    const c = source[i];
    const next = source[i + 1];
    if (inStr) {
      if (c === '\\') { out[i] = ' '; out[i + 1] = ' '; i += 2; continue; }
      if (c === inStr) inStr = null;
      out[i] = c === '\n' ? '\n' : ' ';
      i += 1; continue;
    }
    if (c === '/' && next === '/') {
      const end = source.indexOf('\n', i);
      const stop = end === -1 ? source.length : end;
      for (let k = i; k < stop; k += 1) out[k] = ' ';
      i = stop; continue;
    }
    if (c === '/' && next === '*') {
      const end = source.indexOf('*/', i + 2);
      const stop = end === -1 ? source.length : end + 2;
      for (let k = i; k < stop; k += 1) out[k] = source[k] === '\n' ? '\n' : ' ';
      i = stop; continue;
    }
    if (c === "'" || c === '"' || c === '`') { inStr = c; out[i] = ' '; i += 1; continue; }
    out[i] = c;
    i += 1;
  }
  return out.join('');
}

/**
 * @returns {{ start: number, end: number } | null} the char-offset range of
 *   the innermost enclosing function's `{...}` body around `callIndex`, or
 *   null if the file has no function that encloses it (should not happen
 *   for a real route/middleware call site — a null return fails the site
 *   loudly rather than silently skipping it, see the test below).
 */
function findEnclosingFunctionRange(source, callIndex) {
  const stripped = stripCommentsAndStrings(source);
  let i = 0;
  const stack = [];
  let enclosingFrame = null;
  let closeIdx = null;
  while (i < stripped.length) {
    const c = stripped[i];
    if (c === '{') {
      const lineStart = stripped.lastIndexOf('\n', i) + 1;
      let lineEnd = stripped.indexOf('\n', i);
      if (lineEnd === -1) lineEnd = stripped.length;
      stack.push({ kind: classifyBraceLine(stripped.slice(lineStart, lineEnd)), openIdx: i });
      i += 1;
      if (i > callIndex && !enclosingFrame) {
        for (let k = stack.length - 1; k >= 0; k -= 1) {
          if (stack[k].kind === 'function') { enclosingFrame = stack[k]; break; }
        }
      }
      continue;
    }
    if (c === '}') {
      const frame = stack.pop();
      i += 1;
      if (enclosingFrame && frame === enclosingFrame) { closeIdx = i; break; }
      continue;
    }
    i += 1;
  }
  if (!enclosingFrame || closeIdx === null) return null;
  return { start: enclosingFrame.openIdx, end: closeIdx };
}

const RESPONDER_CALL_RE = /\b(?:sendError|apiError)\s*\(|\bres(?:ponse)?\.(?:status|json|send)\s*\(/;
const NEXT_CALL_RE = /\bnext\s*\(/;

/**
 * The proof itself. Returns null when the site's own claim (terminal or
 * deferred) holds against its enclosing function's text, or a description
 * of how it does not.
 */
function siteProofFailure(site) {
  const source = fs.readFileSync(site.file, 'utf8');
  // Same blanking the brace walk uses: a comment or string literal
  // mentioning `res.status(` or `next(` must never satisfy this proof —
  // only code the enclosing function actually executes counts.
  const stripped = stripCommentsAndStrings(source);
  const srcLines = source.split('\n');
  let lineStartIdx = 0;
  for (let k = 0; k < site.lineNo - 1; k += 1) lineStartIdx += srcLines[k].length + 1;
  const callIdx = source.indexOf('logSecurity(', lineStartIdx);
  const range = findEnclosingFunctionRange(source, callIdx);
  if (!range) return `${site.file}:${site.lineNo} — logSecurity call has no enclosing function`;
  const callStmtEnd = source.indexOf(';', callIdx);
  if (site.terminal) {
    const after = stripped.slice(callStmtEnd === -1 ? callIdx : callStmtEnd, range.end);
    if (!RESPONDER_CALL_RE.test(after)) {
      return `${site.file}:${site.lineNo} — terminal:true but its enclosing function never calls a responder after logSecurity`;
    }
  }
  if (site.deferred) {
    const body = stripped.slice(range.start, range.end);
    if (!NEXT_CALL_RE.test(body)) {
      return `${site.file}:${site.lineNo} — deferred:true but its enclosing function never calls next()`;
    }
    if (RESPONDER_CALL_RE.test(body)) {
      return `${site.file}:${site.lineNo} — deferred:true but its enclosing function also responds itself (not deferred to a downstream gate)`;
    }
  }
  return null;
}

test('every logSecurity call site is terminal:true, deferred:true, or on the deliberate non-terminal list', () => {
  const sites = findLogSecuritySites();
  // A new site changes this number — bump it deliberately (like C-4's
  // rateLimit({) count) rather than widening the assertion to `>=`, so an
  // added site that happens to reuse an existing KNOWN_NON_TERMINAL event
  // name cannot slip through unaccounted.
  assert.equal(sites.length, 17, `logSecurity call-site count changed — census: ${JSON.stringify(sites.map((s) => s.line.trim()))}`);
  const unaccounted = sites.filter((s) => !s.terminal && !s.deferred && !KNOWN_NON_TERMINAL.has(s.event));
  assert.deepEqual(
    unaccounted,
    [],
    `a logSecurity site is neither terminal:true, deferred:true, nor on KNOWN_NON_TERMINAL — decide one: ${JSON.stringify(unaccounted)}`,
  );
  const undocumentedDeferred = sites.filter((s) => s.deferred && !KNOWN_DEFERRED.has(s.event));
  assert.deepEqual(
    undocumentedDeferred,
    [],
    `a deferred logSecurity site is not on KNOWN_DEFERRED: ${JSON.stringify(undocumentedDeferred)}`,
  );
});

test('every terminal:true site responds after logging, and every deferred:true site only defers (proof, not a count)', () => {
  const sites = findLogSecuritySites().filter((s) => s.terminal || s.deferred);
  // Floor, not the exact 17: this row only cares about the terminal/deferred
  // subset, but a scan that matched none of them would pass every assertion
  // below vacuously — the same failure shape public-errors.test.js's harvester
  // floor guards against.
  assert.ok(sites.length >= 10, `expected 10+ terminal/deferred logSecurity sites, found ${sites.length}`);
  const failures = sites.map(siteProofFailure).filter(Boolean);
  assert.deepEqual(failures, [], failures.join('\n'));
});

test('the proof form actually fails a site that claims terminal but never responds (RED fixture)', () => {
  const fixtureDir = fs.mkdtempSync(path.join(require('node:os').tmpdir(), 'log-security-proof-fixture-'));
  try {
    const fixtureFile = path.join(fixtureDir, 'fake-middleware.js');
    fs.writeFileSync(
      fixtureFile,
      "function fakeGuard(req, res, next) {\n"
      + "  if (req.blocked) {\n"
      + "    logSecurity(req, { event: 'fake_blocked', level: 'warn', terminal: true }, 'blocked');\n"
      + "    return; // BUG: claims terminal but never responds\n"
      + "  }\n"
      + "  next();\n"
      + "}\n",
    );
    const failure = siteProofFailure({ file: fixtureFile, lineNo: 3, terminal: true, deferred: false });
    assert.ok(failure, 'a terminal:true site with no responder in its enclosing function must fail the proof');
    assert.match(failure, /never calls a responder/);
  } finally {
    fs.rmSync(fixtureDir, { recursive: true, force: true });
  }
});

test('the proof form actually fails a site that claims deferred but responds itself (RED fixture)', () => {
  const fixtureDir = fs.mkdtempSync(path.join(require('node:os').tmpdir(), 'log-security-proof-fixture-'));
  try {
    const fixtureFile = path.join(fixtureDir, 'fake-middleware-2.js');
    fs.writeFileSync(
      fixtureFile,
      "function fakeGuard(req, res, next) {\n"
      + "  if (req.blocked) {\n"
      + "    logSecurity(req, { event: 'fake_blocked', level: 'warn', deferred: true }, 'blocked');\n"
      + "    return res.status(403).json({ error: 'forbidden' }); // BUG: claims deferred but responds itself\n"
      + "  }\n"
      + "  next();\n"
      + "}\n",
    );
    const failure = siteProofFailure({ file: fixtureFile, lineNo: 3, terminal: false, deferred: true });
    assert.ok(failure, 'a deferred:true site that also responds itself must fail the proof');
    assert.match(failure, /also responds itself/);
  } finally {
    fs.rmSync(fixtureDir, { recursive: true, force: true });
  }
});

test('the proof form still fails a terminal site whose only "responder" is a comment (RED fixture)', () => {
  const fixtureDir = fs.mkdtempSync(path.join(require('node:os').tmpdir(), 'log-security-proof-fixture-'));
  try {
    const fixtureFile = path.join(fixtureDir, 'fake-middleware-3.js');
    fs.writeFileSync(
      fixtureFile,
      "function fakeGuard(req, res, next) {\n"
      + "  if (req.blocked) {\n"
      + "    logSecurity(req, { event: 'fake_blocked', level: 'warn', terminal: true }, 'blocked');\n"
      + "    // TODO: should call res.status(403).json({ error: 'forbidden' })\n"
      + "    return;\n"
      + "  }\n"
      + "  next();\n"
      + "}\n",
    );
    const failure = siteProofFailure({ file: fixtureFile, lineNo: 3, terminal: true, deferred: false });
    assert.ok(failure, 'a responder mentioned only in a comment must not satisfy the terminal:true proof');
    assert.match(failure, /never calls a responder/);
  } finally {
    fs.rmSync(fixtureDir, { recursive: true, force: true });
  }
});

test('the proof form still fails a terminal site whose only "responder" is inside a string literal (RED fixture)', () => {
  const fixtureDir = fs.mkdtempSync(path.join(require('node:os').tmpdir(), 'log-security-proof-fixture-'));
  try {
    const fixtureFile = path.join(fixtureDir, 'fake-middleware-4.js');
    fs.writeFileSync(
      fixtureFile,
      "function fakeGuard(req, res, next) {\n"
      + "  if (req.blocked) {\n"
      + "    logSecurity(req, { event: 'fake_blocked', level: 'warn', terminal: true }, 'blocked');\n"
      + "    const note = 'still need to call res.json( ) here';\n"
      + "    return;\n"
      + "  }\n"
      + "  next();\n"
      + "}\n",
    );
    const failure = siteProofFailure({ file: fixtureFile, lineNo: 3, terminal: true, deferred: false });
    assert.ok(failure, 'a responder mentioned only inside a string literal must not satisfy the terminal:true proof');
    assert.match(failure, /never calls a responder/);
  } finally {
    fs.rmSync(fixtureDir, { recursive: true, force: true });
  }
});

test('the proof form passes a deferred site that only mentions a responder in a comment (RED fixture)', () => {
  const fixtureDir = fs.mkdtempSync(path.join(require('node:os').tmpdir(), 'log-security-proof-fixture-'));
  try {
    const fixtureFile = path.join(fixtureDir, 'fake-middleware-5.js');
    fs.writeFileSync(
      fixtureFile,
      "function fakeGuard(req, res, next) {\n"
      + "  if (req.blocked) {\n"
      + "    logSecurity(req, { event: 'fake_blocked', level: 'warn', deferred: true }, 'blocked');\n"
      + "    // a downstream gate might call res.status(401).json(...) later\n"
      + "  }\n"
      + "  next();\n"
      + "}\n",
    );
    const failure = siteProofFailure({ file: fixtureFile, lineNo: 3, terminal: false, deferred: true });
    assert.equal(failure, null, `a responder mentioned only in a comment must not fail the deferred:true proof: ${failure}`);
  } finally {
    fs.rmSync(fixtureDir, { recursive: true, force: true });
  }
});
