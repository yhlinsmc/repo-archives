'use strict';

/**
 * rate-limit-key-reuses-limiter-key.test.js — the 429 log handler must dedup
 * on the SAME key express-rate-limit already computed and attached to
 * `req.rateLimit`, not by re-running a definition's keyGenerator itself.
 * v8's DEFAULT keyGenerator (any definition that supplies none of its own)
 * is `async`, so calling it a second time from the log handler returns a
 * Promise rather than a string — the whole point of resolving through
 * `req.rateLimit.key` instead.
 *
 * Run: node --test docker-api/tests/infra/rate-limit-key-reuses-limiter-key.test.js
 */
const { test } = require('node:test');
const assert = require('node:assert/strict');
const { ipKeyGenerator } = require('express-rate-limit');
const limiters = require('../../src/infra/limiters');

function makeRes() {
  const res = { locals: {}, statusCode: 200 };
  res.status = (code) => { res.statusCode = code; return res; };
  res.send = () => res;
  return res;
}

// A definition with no custom keyGenerator: production wiring leaves this to
// express-rate-limit's async default, which the handler must never re-invoke.
function makeDefinition(name) {
  limiters._internals.rateLimitRegistry.length = 0;
  limiters.rateLimit({ _name: name, keyType: 'ip', windowMs: 60000, max: 1 });
  return limiters._internals.rateLimitRegistry.find((e) => e.name === name);
}

test('two IPv6 addresses in the same /56 dedup on the limiter-computed key: one warn, one debug', () => {
  const entry = makeDefinition('ipv6DedupOne');
  const addrA = '2001:db8:85a3:1234::1';
  const addrB = '2001:db8:85a3:1234:ffff::9999';
  const sharedKey = ipKeyGenerator(addrA);
  assert.equal(ipKeyGenerator(addrB), sharedKey, 'premise: both addresses share a /56');

  // Simulate what express-rate-limit's real middleware does before invoking
  // the handler: attach the resolved key to req.rateLimit, never expose it
  // through a synchronously re-callable keyGenerator.
  const reqA = { ip: addrA, headers: {}, query: {}, rateLimit: { key: sharedKey } };
  const resA = makeRes(); resA.req = reqA; reqA.res = resA;
  const reqB = { ip: addrB, headers: {}, query: {}, rateLimit: { key: sharedKey } };
  const resB = makeRes(); resB.req = reqB; reqB.res = resB;
  const options = { statusCode: 429, message: 'x', windowMs: 60000 };

  entry.handler(reqA, resA, () => {}, options);
  entry.handler(reqB, resB, () => {}, options);

  assert.equal(resA.locals.logPolicy.logged, true, 'first hit logged');
  assert.equal(resB.locals.logPolicy.logged, true, 'second hit logged');
});

test('the raw fallback IP never appears when the limiter key is present, and the handler never calls keyGenerator itself', () => {
  const entry = makeDefinition('ipv6DedupTwo');
  const addr = '2001:db8:85a3:5678::42';
  const sharedKey = ipKeyGenerator(addr);
  let keyGeneratorCalled = false;
  const req = {
    ip: addr,
    headers: {},
    query: {},
    rateLimit: { key: sharedKey },
  };
  const res = makeRes(); res.req = req; req.res = res;
  const options = {
    statusCode: 429,
    message: 'x',
    windowMs: 60000,
    // If the handler still called this, it would prove the bug is back —
    // the fix must never invoke it at all.
    keyGenerator: () => { keyGeneratorCalled = true; return Promise.resolve(addr); },
  };

  entry.handler(req, res, () => {}, options);

  assert.equal(keyGeneratorCalled, false, 'the log handler must read req.rateLimit.key, not re-run keyGenerator');
  assert.equal(res.locals.logPolicy.logged, true);
});
