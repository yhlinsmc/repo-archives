// docker-api/tests/infra/routes/flow-recipe-run-step-entries.test.js
//
// Unit tests for the step_results entry shape produced by POST
// /api/flow-recipes/:id/run (infra server-run orchestrator): step_name +
// failed-step error_body (PR-2 Task 4). Harness mirrors
// tests/unit/flow-recipe-run-route.test.js: mocks injected via require.cache
// before requiring the module under test; each test resets mutable mock state.
//
// Run:
//   cd docker-api && NODE_ENV=test node --test tests/infra/routes/flow-recipe-run-step-entries.test.js
const { test } = require('node:test');
const assert = require('node:assert');
const express = require('express');
const { stubLoggerModule } = require('../../helpers/stub-logger-module');

// ── Mutable mock state — reset per test ──────────────────────────────────────
const edgeCalls = [];
const dispatchCalls = [];
let forwardToEdgeImpl = async () => ({ status: 200, data: { ok: true } });
let dispatchOneStepImpl = async () => ({
  ok: true, status: 200,
  envelope: { upstream_status: 200, body: '{}' },
});

// ── Cache injection (before any require of the module under test) ─────────────
require.cache[require.resolve('../../../src/infra/lib/remote-client')] = {
  exports: {
    forwardToEdge: async (opts) => {
      edgeCalls.push(opts);
      return forwardToEdgeImpl(opts);
    },
    passthroughResponse: (_req, res, result) => {
      res.status(result.status).json(result.data);
    },
  },
};

require.cache[require.resolve('../../../src/infra/lib/flow-dispatch-step')] = {
  exports: {
    dispatchOneStep: async (opts) => {
      dispatchCalls.push(opts);
      return dispatchOneStepImpl(opts);
    },
  },
};

// Derives from the real module so every other export (e.g. captureCallerSrc)
// stays present for sendError.
stubLoggerModule(require.resolve('../../../src/shared/lib/logger'), {
  logger: { child: () => ({ warn: () => {}, error: () => {}, info: () => {} }) },
});

const mountFlowRecipeRun = require('../../../src/infra/routes/flow-recipe-run');

// ── Test helpers ──────────────────────────────────────────────────────────────

function makeApp({ user } = {}) {
  const a = express();
  a.use(express.json());
  if (user) {
    a.use((req, _res, next) => { req.user = user; req.id = 'test-req-id'; next(); });
  }
  mountFlowRecipeRun(a);
  return a;
}

async function post(app, path, body) {
  const server = app.listen(0);
  const port = server.address().port;
  try {
    const res = await fetch(`http://127.0.0.1:${port}${path}`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(body),
    });
    const json = await res.json();
    return { status: res.status, body: json };
  } finally {
    server.close();
  }
}

function runBeginOk(steps) {
  return {
    status: 200,
    data: {
      data: {
        run_id: 'run1',
        steps,
        serialized_payload: '{"a":1}',
      },
    },
  };
}

const RUN_FINALIZE_FAILED = {
  status: 200,
  data: { data: { runId: 'run1', status: 'failed', link: null, externalId: null } },
};

const RUN_FINALIZE_SUCCESS = {
  status: 200,
  data: { data: { runId: 'run1', status: 'success', link: null, externalId: null } },
};

async function runStepEntries({ steps, dispatchImpl, finalize }) {
  edgeCalls.length = 0;
  dispatchCalls.length = 0;
  forwardToEdgeImpl = async (opts) => {
    if (opts.path.endsWith('/run-begin')) return runBeginOk(steps);
    if (opts.path.endsWith('/run-finalize')) return finalize;
    return { status: 200, data: { ok: true } };
  };
  dispatchOneStepImpl = dispatchImpl;

  const app = makeApp({ user: { id: 'u', role: 'user' } });
  await post(app, '/api/flow-recipes/r1/run', { payload: { a: 1 } });

  const finalizeCall = edgeCalls.find((c) => c.path.endsWith('/run-finalize'));
  assert.ok(finalizeCall, 'run-finalize must be called');
  return JSON.parse(finalizeCall.body.step_results);
}

// ── Tests ─────────────────────────────────────────────────────────────────────

test('(a) success entry carries step_name, no error_body key', async () => {
  const parsed = await runStepEntries({
    steps: [{ id: 's1', sequence: 1, name: 'Push data' }],
    dispatchImpl: async () => ({ ok: true, status: 200, envelope: { upstream_status: 200, body: '{}' } }),
    finalize: RUN_FINALIZE_SUCCESS,
  });

  assert.equal(parsed.length, 1);
  assert.deepEqual(parsed[0], { step_id: 's1', step_name: 'Push data', ok: true, upstream_status: 200 });
  assert.ok(!('error_body' in parsed[0]), 'a successful step entry must not carry error_body');
});

// PR-2 review F1: infra never slices a raw upstream body — it relays
// it INTACT up to the transport cap (32768) or replaces it with a placeholder
// that carries none of the upstream bytes. Slicing raw bytes before the edge
// masker sees them is the defect this batch closes (empirically reproduced:
// a body sliced mid-token failed both the masker's JSON and YAML parse and
// stored the truncated-but-still-raw text, secrets included).
test('(b) a body under the transport cap is relayed INTACT, not truncated to the old 8192 storage cap', async () => {
  const body = 'X'.repeat(9000); // over the old 8192 storage cap, well under the 32768 transport cap
  const parsed = await runStepEntries({
    steps: [{ id: 's1', sequence: 1, name: 'Push data' }],
    dispatchImpl: async () => ({ ok: true, status: 200, envelope: { upstream_status: 502, body } }),
    finalize: RUN_FINALIZE_FAILED,
  });

  assert.equal(parsed.length, 1);
  assert.equal(parsed[0].step_id, 's1');
  assert.equal(parsed[0].step_name, 'Push data');
  assert.equal(parsed[0].ok, false);
  assert.equal(parsed[0].upstream_status, 502);
  assert.equal(parsed[0].error_body, body, 'a body under the transport cap must reach edge byte-for-byte, not sliced');
});

test('(c) transport failure entry carries error_body = transport message', async () => {
  const parsed = await runStepEntries({
    steps: [{ id: 's1', sequence: 1, name: 'Push data' }],
    dispatchImpl: async () => ({
      ok: false, status: 502, errorCode: 'CONNECTOR_UNREACHABLE', message: 'Connection refused',
    }),
    finalize: RUN_FINALIZE_FAILED,
  });

  assert.equal(parsed.length, 1);
  assert.equal(parsed[0].step_id, 's1');
  assert.equal(parsed[0].step_name, 'Push data');
  assert.equal(parsed[0].ok, false);
  assert.equal(parsed[0].upstream_status, 502);
  assert.equal(parsed[0].error_body, 'Connection refused');
});

test('(d) a body exactly at the transport cap is relayed intact, whole', async () => {
  const atCapBody = 'Y'.repeat(32768);
  const parsed = await runStepEntries({
    steps: [{ id: 's1', sequence: 1, name: 'Push data' }],
    dispatchImpl: async () => ({ ok: true, status: 200, envelope: { upstream_status: 500, body: atCapBody } }),
    finalize: RUN_FINALIZE_FAILED,
  });

  assert.equal(parsed[0].error_body.length, 32768, 'a body exactly at the transport cap must not be shortened');
  assert.equal(parsed[0].error_body, atCapBody);
});

// PR-2 review round 2 (F1-follow-up): a body over the transport cap
// used to send a placeholder STRING as error_body — which reproduced its own
// bug (a `[`-leading placeholder parses as a YAML flow sequence at the edge
// masker's structured-parse gate). Now it sets error_body_omitted (a char
// count) and sends NO error_body at all, so there is no text for the masker
// to mis-parse in the first place.
test('(F1) a body OVER the transport cap sets error_body_omitted, never error_body', async () => {
  const overCapBody = `{"access_token":"s3cret-token","padding":"${'Z'.repeat(33000)}"}`;
  const parsed = await runStepEntries({
    steps: [{ id: 's1', sequence: 1, name: 'Push data' }],
    dispatchImpl: async () => ({ ok: true, status: 200, envelope: { upstream_status: 500, body: overCapBody } }),
    finalize: RUN_FINALIZE_FAILED,
  });

  assert.ok(!('error_body' in parsed[0]),
    'an over-cap entry must carry no error_body at all — nothing of the raw body, not even a placeholder string');
  assert.equal(parsed[0].error_body_omitted, overCapBody.length);
});

// content_type threads through onto a failed entry only when the step
// round-tripped to a real HTTP response (an envelope with headers).
test('(e) a failed entry with an upstream Content-Type header records content_type verbatim', async () => {
  const parsed = await runStepEntries({
    steps: [{ id: 's1', sequence: 1, name: 'Push data' }],
    dispatchImpl: async () => ({
      ok: true, status: 200,
      envelope: { upstream_status: 500, body: '{"error":"boom"}', headers: { 'content-type': 'application/json; charset=utf-8' } },
    }),
    finalize: RUN_FINALIZE_FAILED,
  });

  assert.equal(parsed[0].content_type, 'application/json; charset=utf-8');
});

test('(f) a failed entry whose envelope carries no headers omits content_type', async () => {
  const parsed = await runStepEntries({
    steps: [{ id: 's1', sequence: 1, name: 'Push data' }],
    dispatchImpl: async () => ({
      ok: true, status: 200,
      envelope: { upstream_status: 500, body: 'boom' }, // no headers key at all
    }),
    finalize: RUN_FINALIZE_FAILED,
  });

  assert.ok(!('content_type' in parsed[0]), 'no headers on the envelope → no fabricated content_type');
});

// Network-error path (dispatchOneStep ok:false) never round-trips to an HTTP
// response, so there is no Content-Type to read — content_type must stay
// absent, never a fabricated/empty value.
test('(g) a transport failure entry (no HTTP response) omits content_type', async () => {
  const parsed = await runStepEntries({
    steps: [{ id: 's1', sequence: 1, name: 'Push data' }],
    dispatchImpl: async () => ({
      ok: false, status: 502, errorCode: 'CONNECTOR_UNREACHABLE', message: 'Connection refused',
    }),
    finalize: RUN_FINALIZE_FAILED,
  });

  assert.ok(!('content_type' in parsed[0]), 'a network-error entry has no HTTP response to read Content-Type from');
});

test('legacy step (no name from recipe lookup) omits step_name, still records error_body', async () => {
  const parsed = await runStepEntries({
    steps: [{ id: 's1', sequence: 1 }], // no `name` field — legacy fallback SELECT variant
    dispatchImpl: async () => ({ ok: true, status: 200, envelope: { upstream_status: 500, body: 'boom' } }),
    finalize: RUN_FINALIZE_FAILED,
  });

  assert.equal(parsed.length, 1);
  assert.ok(!('step_name' in parsed[0]), 'a step without a recorded name must omit step_name, not null/empty it');
  assert.equal(parsed[0].error_body, 'boom');
});

// flow-yaml-dialect PR-Y2 (fmb-2061): the server-orchestrated (no-JS) loop
// never changes the underlying payload value between steps, but two steps can
// still declare DIFFERENT dialects — each dispatch must carry ITS OWN step's
// bytes, not a single value computed once (previously from the recipe's
// retired content_type, then from run-begin's audit-only serialized_payload).
test('two steps with different dialects each dispatch with their OWN content_type/yaml_version', async () => {
  edgeCalls.length = 0;
  dispatchCalls.length = 0;
  forwardToEdgeImpl = async (opts) => {
    if (opts.path.endsWith('/run-begin')) {
      return runBeginOk([
        { id: 's1', sequence: 1, name: 'JSON step', content_type: 'application/json' },
        { id: 's2', sequence: 2, name: 'YAML step', content_type: 'application/yaml', yaml_version: '1.1' },
      ]);
    }
    if (opts.path.endsWith('/run-finalize')) return RUN_FINALIZE_SUCCESS;
    return { status: 200, data: { ok: true } };
  };
  dispatchOneStepImpl = async () => ({ ok: true, status: 200, envelope: { upstream_status: 200, body: '{}' } });

  const app = makeApp({ user: { id: 'u', role: 'user' } });
  await post(app, '/api/flow-recipes/r1/run', { payload: { flag: 'yes' } });

  assert.equal(dispatchCalls.length, 2);
  assert.equal(dispatchCalls[0].inputs.payload, '{"flag":"yes"}', 's1 (JSON) dispatches compact JSON');
  // 1.1 quotes yes/no/on/off — plain JSON (or 1.2's default) would send it unquoted.
  assert.equal(dispatchCalls[1].inputs.payload, 'flag: "yes"\n', 's2 (YAML 1.1) dispatches quoted YAML, not s1\'s JSON');
});
