// docker-api/tests/infra/routes/flow-step-dispatch.test.js
const { test } = require('node:test');
const assert = require('node:assert');
const express = require('express');

const edgeCalls = [];
let prepareReply = null;
require.cache[require.resolve('../../../src/infra/lib/remote-client')] = {
  exports: {
    forwardToEdge: async (opts) => { edgeCalls.push(opts); return opts.path.endsWith('/prepare') ? prepareReply : { status: 200, data: { ok: true } }; },
    passthroughResponse: (_req, res, prep) => res.status(prep.status).json(prep.data),
  },
};
let executeCalls = 0;
require.cache[require.resolve('../../../src/shared/lib/connector-http')] = {
  exports: { executeRequest: async () => { executeCalls += 1; return { upstream_status: 201, headers: {}, body: '{"id":1}', duration_ms: 5 }; } },
};

const mountFlowStepDispatch = require('../../../src/infra/routes/flow-step-dispatch');

function app() {
  const a = express();
  a.use(express.json());
  a.use((req, _res, next) => { req.user = { id: 'u1', role: 'editor' }; next(); });
  mountFlowStepDispatch(a);
  return a;
}
async function post(a, path, body) {
  const server = a.listen(0);
  try {
    const port = server.address().port;
    const res = await fetch(`http://127.0.0.1:${port}${path}`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) });
    const json = await res.json();
    return { status: res.status, json };
  } finally {
    // Closed on the throwing path too. With the close reachable only where
    // nothing threw, a failed assertion leaks this handle, the runner never
    // exits, and the job reports a timeout instead of the assertion that failed.
    server.close();
  }
}

test('the route thread its OWN req into dispatchOneStep, which forwards it to the /prepare hop', async () => {
  // logging epic PR-Z2 (fmb-2108): this route used to call dispatchOneStep
  // without `req` — the sibling call in flow-recipe-run.js already threaded
  // it (spec §6: an S2S failure's `logS2s` warn joins the request's req_id).
  // A missing `req` here meant the /prepare hop's own S2S failure line could
  // never correlate back to this request's finish line.
  edgeCalls.length = 0;
  prepareReply = { status: 200, data: { data: { mode: 'edge', envelope: { upstream_status: 201 } } } };
  await post(app(), '/api/flow-recipe-steps/s1/dispatch', { inputs: { payload: '{}' } });
  const prepareCall = edgeCalls.find((c) => c.path.endsWith('/prepare'));
  assert.ok(prepareCall.req, 'the /prepare forwardToEdge call must carry the route\'s own req object');
  assert.strictEqual(prepareCall.req.method, 'POST');
});

test('edge-origin: passes the envelope straight through', async () => {
  edgeCalls.length = 0;
  prepareReply = { status: 200, data: { data: { mode: 'edge', envelope: { upstream_status: 201 } } } };
  const { status, json } = await post(app(), '/api/flow-recipe-steps/s1/dispatch', { inputs: { payload: '{}' } });
  assert.strictEqual(status, 200);
  assert.strictEqual(json.data.upstream_status, 201);
  assert.match(edgeCalls[0].path, /\/edge\/internal\/flow-steps\/prepare$/);
});

test('infra-origin: executes pinned + reports result', async () => {
  edgeCalls.length = 0;
  prepareReply = { status: 200, data: { data: { mode: 'infra', dispatch_id: 'd1', step_id: 's1', prepared: { method: 'POST', url: 'https://ok.test/x', headers: {}, body: '{}', pinned_ip: '93.184.216.34', family: 4, timeout_ms: 10000, max_bytes: 1000000 } } } };
  const { status } = await post(app(), '/api/flow-recipe-steps/s1/dispatch', { inputs: { payload: '{}' } });
  assert.strictEqual(status, 200);
  assert.ok(edgeCalls.some((c) => c.path.endsWith('/result')), 'should report outcome to /result');
});

test('infra-origin: blocked pinned IP → 422, reports failure to /result', async () => {
  edgeCalls.length = 0;
  prepareReply = { status: 200, data: { data: { mode: 'infra', dispatch_id: 'd1', step_id: 's1', prepared: { method: 'POST', url: 'https://ok.test/x', headers: {}, body: '{}', pinned_ip: '127.0.0.1', family: 4 } } } };
  const { status } = await post(app(), '/api/flow-recipe-steps/s1/dispatch', { inputs: {} });
  assert.strictEqual(status, 422);
  // The block path must still close the audit by reporting failure to /result —
  // never connecting to the pin does not mean skipping the outcome report.
  const resultCall = edgeCalls.find((c) => c.path.endsWith('/result'));
  assert.ok(resultCall, 'block reports failure to /result');
  assert.strictEqual(resultCall.body.success, false);
  assert.strictEqual(resultCall.body.error_code, 'SSRF_BLOCKED');
});

test('non-200 prepare → passthrough the edge status/body (no socket)', async () => {
  edgeCalls.length = 0;
  executeCalls = 0;
  // edge /prepare itself fails (e.g. recipe not approved → 422, or 502) — the
  // infra route must passthrough that response verbatim and NOT execute or report.
  prepareReply = { status: 502, data: { error: { code: 'UPSTREAM', message: 'prepare failed' } } };
  const { status, json } = await post(app(), '/api/flow-recipe-steps/s1/dispatch', { inputs: {} });
  assert.strictEqual(status, 502);
  assert.strictEqual(json.error.code, 'UPSTREAM');
  // Only the prepare call happened — no /result close on a prepare-level failure.
  assert.strictEqual(edgeCalls.length, 1);
  assert.match(edgeCalls[0].path, /\/prepare$/);
  // And no socket was opened — a prepare-level failure must short-circuit before
  // executeRequest (instrumented counter so a future regression is caught).
  assert.strictEqual(executeCalls, 0, 'no outbound socket on a failed prepare');
});
