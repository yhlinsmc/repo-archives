// docker-api/tests/infra/grant-limiter-kind.test.js
const { test } = require('node:test');
const assert = require('node:assert');
const { grantLimiterKind } = require('../../src/infra/limiters');

test('mutations are classified write', () => {
  assert.strictEqual(grantLimiterKind('POST'), 'write');
  assert.strictEqual(grantLimiterKind('PUT'), 'write');
  assert.strictEqual(grantLimiterKind('PATCH'), 'write');
  assert.strictEqual(grantLimiterKind('DELETE'), 'write');
});
test('reads are unlimited (null)', () => {
  assert.strictEqual(grantLimiterKind('GET'), null);
  assert.strictEqual(grantLimiterKind('HEAD'), null);
  assert.strictEqual(grantLimiterKind('OPTIONS'), null);
});
