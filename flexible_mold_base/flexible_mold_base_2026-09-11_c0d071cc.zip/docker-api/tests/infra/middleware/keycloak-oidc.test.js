/**
 * Unit tests for keycloak-oidc.js — _isSafeRedirectUrl logic
 *
 * The function is not exported, so we replicate its logic here for
 * regression testing. If the implementation changes, update this test.
 */
const { describe, it, beforeEach, afterEach } = require('node:test');
const assert = require('node:assert/strict');

// shared/config validates required env at module load — set before requiring
// keycloak-oidc so the real _resolveSsoReturnTo can be tested directly (no
// logic replication, which would let a query-parsing bug hide behind a copy).
process.env.JWT_SECRET = process.env.JWT_SECRET || 'a'.repeat(48);
process.env.S2S_API_KEY = process.env.S2S_API_KEY || 's2s-test';
const { _resolveSsoReturnTo } = require('../../../src/infra/middleware/keycloak-oidc');

// Replicate _isSafeRedirectUrl logic for testing (same algorithm as keycloak-oidc.js)
function isSafeRedirectUrl(url, env = {}) {
  if (!url) return false;
  if (url.startsWith('/') && !url.startsWith('//')) return true;
  try {
    const parsed = new URL(url);
    if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') return false;
    const origins = [
      env.FRONTEND_URL,
      env.BASE_URL,
    ];
    if (env.NODE_ENV !== 'production') {
      origins.push(`http://localhost:${env.PORT || 3200}`);
      origins.push('http://localhost:3000');
    }
    const allowedOrigins = origins
      .filter(Boolean)
      .map(u => { try { return new URL(u).origin; } catch { return null; } })
      .filter(Boolean);
    return allowedOrigins.includes(parsed.origin);
  } catch {
    return false;
  }
}

describe('isSafeRedirectUrl', () => {
  const devEnv = { FRONTEND_URL: 'http://localhost:3000', BASE_URL: 'http://localhost:3200', NODE_ENV: 'development' };
  const prodEnv = { FRONTEND_URL: 'https://app.example.com', BASE_URL: 'https://api.example.com', NODE_ENV: 'production' };

  describe('relative paths', () => {
    it('allows simple relative path', () => {
      assert.strictEqual(isSafeRedirectUrl('/login', devEnv), true);
    });

    it('allows nested relative path', () => {
      assert.strictEqual(isSafeRedirectUrl('/app/dashboard', devEnv), true);
    });

    it('rejects protocol-relative URL (//evil.com)', () => {
      assert.strictEqual(isSafeRedirectUrl('//evil.com', devEnv), false);
    });
  });

  describe('protocol validation', () => {
    it('rejects javascript: protocol', () => {
      assert.strictEqual(isSafeRedirectUrl('javascript:alert(1)', devEnv), false);
    });

    it('rejects data: protocol', () => {
      assert.strictEqual(isSafeRedirectUrl('data:text/html,<h1>pwned</h1>', devEnv), false);
    });

    it('rejects ftp: protocol', () => {
      assert.strictEqual(isSafeRedirectUrl('ftp://evil.com', devEnv), false);
    });
  });

  describe('origin matching', () => {
    it('allows FRONTEND_URL origin', () => {
      assert.strictEqual(isSafeRedirectUrl('https://app.example.com/login', prodEnv), true);
    });

    it('allows BASE_URL origin', () => {
      assert.strictEqual(isSafeRedirectUrl('https://api.example.com/callback', prodEnv), true);
    });

    it('rejects unknown origin', () => {
      assert.strictEqual(isSafeRedirectUrl('https://evil.com/phish', prodEnv), false);
    });

    it('rejects origin with matching hostname but different port', () => {
      assert.strictEqual(isSafeRedirectUrl('https://app.example.com:8443/login', prodEnv), false);
    });
  });

  describe('production vs development', () => {
    it('allows localhost:3000 in development', () => {
      assert.strictEqual(isSafeRedirectUrl('http://localhost:3000/login', devEnv), true);
    });

    it('rejects localhost:3000 in production', () => {
      assert.strictEqual(isSafeRedirectUrl('http://localhost:3000/login', prodEnv), false);
    });

    it('allows localhost:PORT in development', () => {
      const env = { ...devEnv, PORT: '4000' };
      assert.strictEqual(isSafeRedirectUrl('http://localhost:4000/login', env), true);
    });
  });

  describe('edge cases', () => {
    it('rejects null', () => {
      assert.strictEqual(isSafeRedirectUrl(null, devEnv), false);
    });

    it('rejects undefined', () => {
      assert.strictEqual(isSafeRedirectUrl(undefined, devEnv), false);
    });

    it('rejects empty string', () => {
      assert.strictEqual(isSafeRedirectUrl('', devEnv), false);
    });

    it('rejects malformed URL', () => {
      assert.strictEqual(isSafeRedirectUrl('not-a-url', devEnv), false);
    });

    it('handles missing FRONTEND_URL gracefully', () => {
      const env = { NODE_ENV: 'production' };
      assert.strictEqual(isSafeRedirectUrl('https://evil.com', env), false);
    });
  });
});

describe('_resolveSsoReturnTo (post-login deep link)', () => {
  const REAL = {};
  const KEYS = ['FRONTEND_URL', 'BASE_URL', 'NODE_ENV', 'PORT'];
  const FRONTEND = 'http://localhost:3000';
  const req = (return_to) => ({ query: return_to === undefined ? {} : { return_to } });

  beforeEach(() => {
    KEYS.forEach((k) => { REAL[k] = process.env[k]; });
    process.env.FRONTEND_URL = FRONTEND;
    process.env.BASE_URL = 'http://localhost:3200';
    process.env.NODE_ENV = 'development';
  });

  afterEach(() => {
    KEYS.forEach((k) => {
      if (REAL[k] === undefined) delete process.env[k];
      else process.env[k] = REAL[k];
    });
  });

  it('round-trips a legal deep path onto the frontend origin', () => {
    assert.strictEqual(
      _resolveSsoReturnTo(req('/fmb/templates/123?tab=history#row-5')),
      `${FRONTEND}/fmb/templates/123?tab=history#row-5`,
    );
  });

  it('round-trips a simple legal path', () => {
    assert.strictEqual(_resolveSsoReturnTo(req('/data-entry')), `${FRONTEND}/data-entry`);
  });

  it('falls back to FRONTEND_URL for a protocol-relative //evil.example', () => {
    assert.strictEqual(_resolveSsoReturnTo(req('//evil.example')), FRONTEND);
  });

  it('falls back to FRONTEND_URL for an absolute https://evil.example URL', () => {
    assert.strictEqual(_resolveSsoReturnTo(req('https://evil.example/x')), FRONTEND);
  });

  it('falls back to FRONTEND_URL for a backslash-smuggled /\\evil authority', () => {
    assert.strictEqual(_resolveSsoReturnTo(req('/\\evil.example')), FRONTEND);
  });

  it('falls back to FRONTEND_URL for a javascript: scheme', () => {
    assert.strictEqual(_resolveSsoReturnTo(req('javascript:alert(1)')), FRONTEND);
  });

  it('falls back to FRONTEND_URL for an empty string', () => {
    assert.strictEqual(_resolveSsoReturnTo(req('')), FRONTEND);
  });

  it('falls back to FRONTEND_URL for a repeated (array) param', () => {
    assert.strictEqual(_resolveSsoReturnTo(req(['/a', '/b'])), FRONTEND);
  });

  it('returns FRONTEND_URL unchanged when the param is absent', () => {
    assert.strictEqual(_resolveSsoReturnTo(req(undefined)), FRONTEND);
  });

  it('returns a bare relative path when FRONTEND_URL is unset (same-origin build)', () => {
    delete process.env.FRONTEND_URL;
    assert.strictEqual(_resolveSsoReturnTo(req('/data-entry')), '/data-entry');
  });

  it('falls back to / when FRONTEND_URL is unset and the param is rejected', () => {
    delete process.env.FRONTEND_URL;
    assert.strictEqual(_resolveSsoReturnTo(req('//evil.example')), '/');
  });

  it('falls back to FRONTEND_URL for a tab-smuggled /\\t/evil authority', () => {
    assert.strictEqual(_resolveSsoReturnTo(req('/\t/evil.example')), FRONTEND);
  });

  it('falls back to FRONTEND_URL for a CR-smuggled /\\r/evil authority', () => {
    assert.strictEqual(_resolveSsoReturnTo(req('/\r/evil.example')), FRONTEND);
  });

  it('falls back to FRONTEND_URL for an LF-smuggled /\\n/evil authority', () => {
    assert.strictEqual(_resolveSsoReturnTo(req('/\n/evil.example')), FRONTEND);
  });

  it('falls back to FRONTEND_URL for /login', () => {
    assert.strictEqual(_resolveSsoReturnTo(req('/login')), FRONTEND);
  });

  it('falls back to FRONTEND_URL for a /login sub-path', () => {
    assert.strictEqual(_resolveSsoReturnTo(req('/login/foo')), FRONTEND);
  });

  it('accepts /setup — the first-admin wizard needs its own Keycloak completion callback', () => {
    assert.strictEqual(_resolveSsoReturnTo(req('/setup')), `${FRONTEND}/setup`);
  });

  it('accepts a /setup sub-path with query (wizard step + keycloak completion marker)', () => {
    assert.strictEqual(
      _resolveSsoReturnTo(req('/setup?step=5&keycloak=success')),
      `${FRONTEND}/setup?step=5&keycloak=success`
    );
  });

  it('accepts a /setup/ sub-path with query', () => {
    assert.strictEqual(
      _resolveSsoReturnTo(req('/setup/wizard?step=2')),
      `${FRONTEND}/setup/wizard?step=2`
    );
  });

  it('does not reject a path that merely starts with "login" as a segment name (e.g. /logins)', () => {
    assert.strictEqual(_resolveSsoReturnTo(req('/logins')), `${FRONTEND}/logins`);
  });

  it('does not reject a path that merely starts with "setup" as a segment name (e.g. /setup-guide)', () => {
    assert.strictEqual(_resolveSsoReturnTo(req('/setup-guide')), `${FRONTEND}/setup-guide`);
  });

  it('falls back to FRONTEND_URL for /login with a query string bypass attempt', () => {
    assert.strictEqual(_resolveSsoReturnTo(req('/login?notice=x')), FRONTEND);
  });

  it('falls back to FRONTEND_URL for /login with a hash bypass attempt', () => {
    assert.strictEqual(_resolveSsoReturnTo(req('/login#x')), FRONTEND);
  });

  it('round-trips a path at exactly the max length', () => {
    const path = `/${'a'.repeat(1023)}`; // length 1024
    assert.strictEqual(_resolveSsoReturnTo(req(path)), `${FRONTEND}${path}`);
  });

  it('falls back to FRONTEND_URL for a path one char over the max length', () => {
    const path = `/${'a'.repeat(1024)}`; // length 1025
    assert.strictEqual(_resolveSsoReturnTo(req(path)), FRONTEND);
  });
});
