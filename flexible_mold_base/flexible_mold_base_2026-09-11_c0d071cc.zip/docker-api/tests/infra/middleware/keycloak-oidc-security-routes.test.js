'use strict';

/**
 * keycloak-oidc-security-routes.test.js — markOidcSecurityRoutes marks the
 * three express-openid-connect auto-registered routes (login/logout/
 * callback) as `security` for request-log §5. express-openid-connect mounts
 * those handlers itself, so none of them ever carries markSecurity on its
 * own; without this middleware a logout / SSO login / callback would log at
 * `access`/`debug` and be invisible at the default LOG_LEVEL=info.
 */
const { describe, it, before, after } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

// >= 32 chars: config.js hard-fails a shorter JWT_SECRET at load (local
// mode). Set before requiring keycloak-oidc.js, which pulls in shared/config.
process.env.JWT_SECRET = process.env.JWT_SECRET || 'a'.repeat(48);
process.env.S2S_API_KEY = process.env.S2S_API_KEY || 's2s-test';

const { markOidcSecurityRoutes, OIDC_ROUTE_PATHS } = require('../../../src/infra/middleware/keycloak-oidc');

let server;
let baseUrl;

before(async () => {
  const app = express();
  app.use(markOidcSecurityRoutes);
  // Stub handler for every path — echoes what the marker wrote to
  // res.locals so the test can assert on it without a real OIDC stack.
  app.use((req, res) => {
    res.json({ logPolicy: res.locals.logPolicy || null });
  });
  server = http.createServer(app);
  await new Promise((resolve) => server.listen(0, resolve));
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});

after(() => server && server.close());

async function logPolicyFor(path) {
  const res = await fetch(`${baseUrl}${path}`);
  const body = await res.json();
  return body.logPolicy;
}

describe('markOidcSecurityRoutes', () => {
  it('marks the SSO login route as security', async () => {
    assert.equal(await logPolicyFor(OIDC_ROUTE_PATHS.login), 'security');
  });

  it('marks the logout route as security', async () => {
    assert.equal(await logPolicyFor(OIDC_ROUTE_PATHS.logout), 'security');
  });

  it('marks the callback route as security', async () => {
    assert.equal(await logPolicyFor(OIDC_ROUTE_PATHS.callback), 'security');
  });

  it('does NOT mark an unrelated auth route (/api/auth/mode)', async () => {
    assert.equal(await logPolicyFor('/api/auth/mode'), null);
  });
});
