'use strict';

/**
 * rate-limit-all-definitions-emit.test.js — every rate-limiter definition emits
 * a 429 line through logRateLimited, proven by ITERATING the definitions the
 * factory registered, not an enumerated code list (STANDING-BRIEF §5: a
 * hand-list under-counts). Mounts both limiter groups + the create* factories,
 * then for EACH registered definition drives its handler and asserts it ran
 * logRateLimited — observable because logRateLimited's last step marks the
 * request (res.locals.logPolicy), the same mark the finish line reads.
 *
 * Run: node --test docker-api/tests/infra/rate-limit-all-definitions-emit.test.js
 */
const { test } = require('node:test');
const assert = require('node:assert/strict');
const express = require('express');
const pino = require('pino');
const { Writable } = require('node:stream');
const { _internals: loggerInternals } = require('../../src/shared/lib/logger');

const limiters = require('../../src/infra/limiters');

// The full set of definitions this codebase declares. If a definition is added
// or renamed, this assertion is the tripwire — it is compared against what the
// factory actually registered, so a new limiter that forgets to flow through
// the factory (and thus would log nothing) fails here.
const EXPECTED = new Set([
  'setup', 'authLogin', 'password', 'recovery', 'failedResolveIp',
  'publicApi', 'ownerLookupFail', 'publicDocs', 'internalSpec',
  'diagnostics', 'authMode', 'status', 'destructiveOps',
  'connectorFetch', 'connectorWrite', 'auditSearch', 'adminOps',
  'wipePrepare', 'wipeExecute', 'flowDispatch', 'flowWrite',
  'grantWrite', 'claimRelease', 'general',
]);

function quietLogger() {
  const sink = new Writable({ write(_c, _e, cb) { cb(); } });
  return pino({ ...loggerInternals.loggerOptions, level: 'debug' }, sink);
}

function buildRegistry() {
  const app = express();
  limiters.mountPreAuthLimiters(app);
  limiters.mountAuthenticatedLimiters(app);
  // The four create* factories build a limiter each; call them so they register.
  limiters.createPublicApiLimiter();
  limiters.createOwnerLookupFailLimiter();
  limiters.createPublicDocsLimiter();
  limiters.createInternalSpecLimiter();
  return limiters._internals.rateLimitRegistry;
}

test('the factory registered exactly the 24 declared definitions', () => {
  const reg = buildRegistry();
  const names = new Set(reg.map((e) => e.name));
  assert.equal(reg.length, EXPECTED.size, `expected ${EXPECTED.size} definitions, got ${reg.length}: ${[...names].join(',')}`);
  assert.deepEqual([...names].sort(), [...EXPECTED].sort());
});

test('every definition carries a valid key_type hint (ip|user|pub)', () => {
  const reg = buildRegistry();
  for (const e of reg) {
    assert.ok(['ip', 'user', 'pub'].includes(e.keyType), `${e.name} has bad keyType ${e.keyType}`);
  }
});

test('every definition\'s handler runs logRateLimited on a rejection', () => {
  const reg = buildRegistry();
  const log = quietLogger();
  for (const e of reg) {
    const res = { locals: {}, statusCode: 200 };
    const req = { ip: '203.0.113.7', log: log.child({ req_id: 'iter0001' }), res, headers: {}, query: {} };
    res.req = req;
    let sent = false;
    res.status = (code) => { res.statusCode = code; return res; };
    res.json = () => { sent = true; return res; };
    res.send = () => { sent = true; return res; };
    res.redirect = () => { sent = true; return res; };
    const options = {
      statusCode: 429,
      message: { error: 'rate_limited' },
      windowMs: 60000,
      keyGenerator: (r) => `ip:${r.ip}`,
    };
    e.handler(req, res, () => {}, options);
    assert.deepEqual(res.locals.logPolicy, { logged: true, kind: 'security' },
      `${e.name}: handler did not run logRateLimited (no suppression mark)`);
    assert.ok(sent, `${e.name}: handler did not send a response`);
  }
});
