'use strict';

/**
 * flow-import-legacy-dialect-real-db.test.js — a legacy bundle's recipe-level
 * `content_type` must not 500 the whole import (fmb-2061 H1).
 *
 * WHAT THIS FILE IS ABOUT. `flow_recipe_steps.yaml_version` / `yaml_quoting` are
 * `ENUM(...) NOT NULL DEFAULT '1.2'` / `'plain'` (table-ddls.js). Before the fix,
 * `cleanSteps` in io.js normalised an absent/invalid per-step dialect to
 * JavaScript `null`, and the best-effort dialect UPDATE
 * `SET content_type = ?, yaml_version = ?, yaml_quoting = ? WHERE id = ?` sent
 * that null straight into the NOT NULL columns. MariaDB answers that with errno
 * 1048 (`ER_BAD_NULL_ERROR`), which `isBadField` — checking only 1054/
 * `ER_BAD_FIELD_ERROR` — does not catch, so the error rethrows, the outer catch
 * rolls back the whole transaction, and a bundle that imported cleanly before
 * this migration now 500s. This exercises the exact legacy shape: a recipe-level
 * `content_type:'application/yaml'` (pre-PR-Y2 export shape) with a step that
 * carries no dialect fields of its own.
 *
 * WHY THE ASSERTIONS ARE ON STORED VALUES, NOT THE STATUS CODE. A 201 the mock
 * test already gets by asserting `params[0]` alone; the point of a real
 * connection is the two NOT NULL columns actually round-trip through MariaDB's
 * strict mode, which the mock cannot exercise at all.
 *
 * Skips with a stated reason when no database is reachable, and FAILS instead of
 * skipping when REQUIRE_INTEGRATION_DB=1 — a silent skip is the failure mode
 * this whole line of work exists to end.
 */
const {
  test, describe, before, after, beforeEach,
} = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const net = require('node:net');
const http = require('node:http');
const express = require('express');
const mariadb = require('mariadb');

const TEST_PREFIX = 'fild_';
const tbl = (name) => `${TEST_PREFIX}${name}`;

let pool = null;
const lease = () => pool.getConnection();
// Both halves of the real pool object: the import handler leases a connection
// for its write transaction AND the egress check calls `pool.ro.query` directly.
const handle = () => ({ getConnection: lease, query: (sql, params) => pool.query(sql, params) });

const dbKey = require.resolve('../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey,
  filename: dbKey,
  loaded: true,
  exports: {
    pool: { ro: handle(), rw: handle() },
    t: tbl,
    getDynamicPool: async () => ({ ro: handle(), rw: handle() }),
  },
};

const { buildEngineTableDDLs, buildInfraTableDDLs } = require('../../src/table-ddls');
const recipesRouter = require('../../src/edge/routes/app/flow-recipes');

// ── Config auto-detection (same shape as the sibling integration tests) ─────

function parseEnvFile(filePath) {
  try {
    const out = {};
    for (const line of fs.readFileSync(filePath, 'utf-8').split('\n')) {
      const m = line.match(/^\s*([A-Z_][A-Z0-9_]*)\s*=\s*(.*)\s*$/);
      if (!m) continue;
      let value = m[2];
      if ((value.startsWith('"') && value.endsWith('"'))
        || (value.startsWith("'") && value.endsWith("'"))) {
        value = value.slice(1, -1);
      }
      out[m[1]] = value;
    }
    return out;
  } catch {
    return null;
  }
}

function probePort(host, port, timeoutMs = 2000) {
  return new Promise((resolve) => {
    const socket = new net.Socket();
    let done = false;
    const finish = (ok) => {
      if (done) return;
      done = true;
      socket.destroy();
      resolve(ok);
    };
    socket.setTimeout(timeoutMs);
    socket.once('connect', () => finish(true));
    socket.once('timeout', () => finish(false));
    socket.once('error', () => finish(false));
    socket.connect(port, host);
  });
}

async function resolveMariaDbConfig() {
  if (process.env.DB_TEST_HOST && process.env.DB_TEST_ROOT_PASSWORD) {
    return {
      host: process.env.DB_TEST_HOST,
      port: parseInt(process.env.DB_TEST_PORT || '3306', 10),
      user: 'root',
      password: process.env.DB_TEST_ROOT_PASSWORD,
    };
  }
  const env = parseEnvFile(path.resolve(__dirname, '../../../.devcontainer/.env'));
  if (!env || !env.DB_ROOT_PASSWORD) return null;
  const port = parseInt(env.DB_PORT || '3306', 10);
  for (const host of ['127.0.0.1', 'mariadb', 'localhost']) {
    if (await probePort(host, port, 2000)) {
      return { host, port, user: 'root', password: env.DB_ROOT_PASSWORD };
    }
  }
  return null;
}

// ── Fixture ──────────────────────────────────────────────────────────────────

const ADMIN_ID = 'aaaaaaa0-1111-4111-8111-111111111111';

let dbReady = false;
let skipReason = null;
let testDbName = null;
let server = null;
let baseUrl = null;
const currentUser = { id: ADMIN_ID, role: 'admin' };

before(async () => {
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) {
    skipReason = 'no MariaDB reachable via .devcontainer/.env or env vars';
    if (process.env.REQUIRE_INTEGRATION_DB === '1') {
      throw new Error(`REQUIRE_INTEGRATION_DB=1 set but ${skipReason}.`);
    }
    return;
  }
  testDbName = `flow_import_dialect_test_${process.pid}_${Date.now()}`;
  let admin = null;
  try {
    admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`CREATE DATABASE \`${testDbName}\``);
    await admin.query(`USE \`${testDbName}\``);
    // Every table, built from the DDL that creates the real ones — the import
    // route reads system_settings (egress) and hierarchy_nodes (blueprint path)
    // besides the flow_recipe* tables, so a hand-picked subset would silently
    // turn one of those probes into a degrade nobody asked for.
    for (const sql of [...buildInfraTableDDLs(tbl), ...buildEngineTableDDLs(tbl)]) {
      await admin.query(sql);
    }
    await admin.end();
    admin = null;

    pool = mariadb.createPool({
      ...dbConfig, database: testDbName, connectionLimit: 6, connectTimeout: 5000,
    });

    const app = express();
    app.use(express.json());
    app.use((req, _res, next) => { req.user = currentUser; next(); });
    app.use('/edge/app/flow-recipes', recipesRouter);
    server = http.createServer(app);
    await new Promise((r) => server.listen(0, r));
    baseUrl = `http://127.0.0.1:${server.address().port}`;
    dbReady = true;
  } catch (err) {
    skipReason = `setup failed: ${err.message}`;
    if (admin) { try { await admin.end(); } catch { /* best effort */ } }
    if (process.env.REQUIRE_INTEGRATION_DB === '1') throw err;
  }
});

after(async () => {
  if (server) { try { server.close(); } catch { /* best effort */ } }
  if (pool) { try { await pool.end(); } catch { /* best effort */ } }
  if (!testDbName) return;
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) return;
  try {
    const admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`DROP DATABASE IF EXISTS \`${testDbName}\``);
    await admin.end();
  } catch { /* best effort */ }
});

async function call(method, url, body) {
  const res = await fetch(`${baseUrl}${url}`, {
    method,
    headers: { 'content-type': 'application/json' },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const text = await res.text();
  let parsed = null;
  try { parsed = JSON.parse(text); } catch { parsed = { raw: text }; }
  return { status: res.status, body: parsed };
}

const q = (sql, params) => pool.query(sql, params);
const one = async (sql, params) => (await pool.query(sql, params))[0];

const guard = (t) => {
  if (dbReady) return false;
  t.skip(skipReason || 'database not ready');
  return true;
};

beforeEach(async () => {
  if (!dbReady) return;
  for (const name of ['flow_recipe_steps', 'flow_recipes', 'flow_recipe_code_versions', 'users']) {
    await q(`DELETE FROM \`${tbl(name)}\``);
  }
  await q(
    `INSERT INTO \`${tbl('users')}\` (id, email, role, banned) VALUES (?,?,?,0)`,
    [ADMIN_ID, 'admin@test.local', 'admin'],
  );
});

describe('a legacy bundle carrying only a recipe-level content_type imports cleanly', () => {
  test('the step lands with the DDL-default dialect, not NULL, and the import does not 500', async (t) => {
    if (guard(t)) return;
    // The exact pre-PR-Y2 export shape: content_type lived on the recipe, never
    // on a step. Before the fix this 500ed (errno 1048 on yaml_version).
    const res = await call('POST', '/edge/app/flow-recipes/import', {
      recipe: { name: 'legacy bundle', content_type: 'application/yaml' },
      steps: [{ sequence: 0, name: 's1', url: 'https://api.example.com/x', method: 'POST' }],
    });
    assert.equal(res.status, 201, `import must not 500: ${JSON.stringify(res.body)}`);
    const recipeId = res.body.data.id;

    const step = await one(
      `SELECT content_type, yaml_version, yaml_quoting
         FROM \`${tbl('flow_recipe_steps')}\` WHERE recipe_id = ?`,
      [recipeId],
    );
    assert.ok(step, 'the step row must exist — a rollback would leave none');
    assert.equal(step.content_type, 'application/yaml', "inherits the legacy bundle's recipe-level dialect");
    assert.equal(step.yaml_version, '1.2', 'normalises to the DDL default, never NULL');
    assert.equal(step.yaml_quoting, 'plain', 'normalises to the DDL default, never NULL');
  });

  test("a step's own valid dialect wins over the legacy recipe-level fallback and is stored verbatim", async (t) => {
    if (guard(t)) return;
    const res = await call('POST', '/edge/app/flow-recipes/import', {
      recipe: { name: 'legacy bundle 2', content_type: 'application/yaml' },
      steps: [{
        sequence: 0,
        name: 's1',
        url: 'https://api.example.com/x',
        method: 'POST',
        content_type: 'application/yaml',
        yaml_version: '1.1',
        yaml_quoting: 'single',
      }],
    });
    assert.equal(res.status, 201, `import must not 500: ${JSON.stringify(res.body)}`);
    const recipeId = res.body.data.id;

    const step = await one(
      `SELECT content_type, yaml_version, yaml_quoting
         FROM \`${tbl('flow_recipe_steps')}\` WHERE recipe_id = ?`,
      [recipeId],
    );
    assert.equal(step.content_type, 'application/yaml');
    assert.equal(step.yaml_version, '1.1');
    assert.equal(step.yaml_quoting, 'single');
  });

  test('a plain JSON bundle at the DDL default issues no dialect UPDATE and still stores the default', async (t) => {
    if (guard(t)) return;
    const res = await call('POST', '/edge/app/flow-recipes/import', {
      recipe: { name: 'plain json bundle' },
      steps: [{ sequence: 0, name: 's1', url: 'https://api.example.com/x', method: 'POST' }],
    });
    assert.equal(res.status, 201, `import must not 500: ${JSON.stringify(res.body)}`);
    const recipeId = res.body.data.id;

    const step = await one(
      `SELECT content_type, yaml_version, yaml_quoting
         FROM \`${tbl('flow_recipe_steps')}\` WHERE recipe_id = ?`,
      [recipeId],
    );
    assert.equal(step.content_type, 'application/json');
    assert.equal(step.yaml_version, '1.2');
    assert.equal(step.yaml_quoting, 'plain');
  });
});
