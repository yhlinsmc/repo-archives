const { test } = require('node:test');
const assert = require('node:assert');
const { buildUsableProjection, deriveInputSpec, parseOutputKeys } = require('../../src/edge/routes/app/api-connectors/usable');

const ROW = {
  id: 'c1', name: 'Weather', description: 'w', is_active: 1,
  blueprint_id: 'bp1',
  method: 'GET', url: 'https://api.x/weather?city={{city}}&u={{units}}',
  auth_type: 'bearer', auth_config: { token: '****' },
  request_config: {
    headers: { 'X-Trace': '{{trace}}' },
    body: '',
    input_mapping: { field_city: 'city' }, // field_key -> var
  },
  response_config: { outputs: [{ id: 'o1', from: { mode: 'value', path: 'main.temp' }, to: { mode: 'field', field_key: 'field_temp' } }], transformer_id: null },
  dispatch_origin: 'edge',
};

test('deriveInputSpec collects all {{vars}} from url+headers+body and attaches source field', () => {
  const spec = deriveInputSpec(ROW);
  const byVar = Object.fromEntries(spec.map(s => [s.var, s.source_field_key]));
  assert.deepStrictEqual(Object.keys(byVar).sort(), ['city', 'trace', 'units']);
  assert.strictEqual(byVar.city, 'field_city');   // reversed from input_mapping
  assert.strictEqual(byVar.units, null);           // no field maps to it
  assert.strictEqual(byVar.trace, null);
});

test('deriveInputSpec picks up vars in the request body', () => {
  const spec = deriveInputSpec({ ...ROW, request_config: { body: '{"q":"{{query}}"}', input_mapping: {} } });
  assert.ok(spec.some(s => s.var === 'query'));
});

test('deriveInputSpec tolerates a missing input_mapping', () => {
  assert.doesNotThrow(() => deriveInputSpec({ ...ROW, request_config: { body: '' } }));
});

test('buildUsableProjection omits every sensitive field', () => {
  const p = buildUsableProjection(ROW);
  assert.deepStrictEqual(Object.keys(p).sort(),
    ['description', 'group_id', 'group_label', 'group_mode', 'id', 'input_from_step', 'input_spec', 'name', 'response_config', 'sequence', 'source_kind', 'source_select_kind'].sort());
  assert.ok(!('url' in p) && !('auth_type' in p) && !('auth_config' in p));
  assert.ok(!('method' in p) && !('allowed_hosts' in p) && !('dispatch_origin' in p));
  assert.ok(!('source_config' in p), 'the full source_config object must never reach the data-entry projection');
  // ROW carries no source_kind — undefined coalesces to 'http' (D-F5), same
  // as a grandfathered row or a no-DDL fallback SELECT.
  assert.strictEqual(p.source_kind, 'http');
  assert.strictEqual(p.source_select_kind, null);
  // Bundle fields are null when the row has none (ROW has no group_id etc.)
  assert.strictEqual(p.group_id, null);
  assert.strictEqual(p.group_label, null);
  assert.strictEqual(p.group_mode, null);
  assert.strictEqual(p.sequence, null);
  assert.deepStrictEqual(p.response_config, {
    outputs: [{ id: 'o1', from: { mode: 'value', path: 'main.temp' }, to: { mode: 'field', field_key: 'field_temp' } }],
    transformer_id: null,
    transformer_output_keys: null,
  });
});

test('R-C5: buildUsableProjection defaults source_select_kind to \'pick\' for a template mode-one row with no select', () => {
  const p = buildUsableProjection({
    ...ROW,
    source_kind: 'template',
    source_config: { blueprint_id: 'bp1', mode: 'one', parts: ['outputs'] },
  });
  assert.strictEqual(p.source_kind, 'template');
  assert.strictEqual(p.source_select_kind, 'pick');
});

test('buildUsableProjection carries the stored select.kind for a template mode-one row with a select', () => {
  const p = buildUsableProjection({
    ...ROW,
    source_kind: 'template',
    source_config: { blueprint_id: 'bp1', mode: 'one', parts: ['outputs'], select: { kind: 'match', field: 'name', value: 'x' } },
  });
  assert.strictEqual(p.source_select_kind, 'match');
});

// R6-D1: a newly created template connector has no request_config (its
// Request section is hidden entirely) — the match select's own {{var}} must
// still reach the /usable projection, or the fetch UI never asks for it and
// every dispatch 400s MISSING_INPUT.
test('R6-D1: deriveInputSpec derives a var from source_config.select.value for a template match source with empty request_config', () => {
  const spec = deriveInputSpec({
    id: 'c1', name: 'n', description: null, request_config: {},
    source_kind: 'template',
    source_config: { blueprint_id: 'bp1', mode: 'one', parts: ['outputs'], select: { kind: 'match', field: 'name', value: '{{customerId}}' } },
  });
  assert.deepStrictEqual(spec, [{ var: 'customerId', source_field_key: null }]);
});

test('R6-D1: a template PICK source derives nothing from source_config (select.value only exists on match)', () => {
  const spec = deriveInputSpec({
    id: 'c1', name: 'n', description: null, request_config: {},
    source_kind: 'template',
    source_config: { blueprint_id: 'bp1', mode: 'one', parts: ['outputs'], select: { kind: 'pick' } },
  });
  assert.deepStrictEqual(spec, []);
});

test('R6-D1: a static source derives nothing from source_config', () => {
  const spec = deriveInputSpec({
    id: 'c1', name: 'n', description: null, request_config: {},
    source_kind: 'static',
    source_config: { body: '{"a":"{{shouldNotLeak}}"}' },
  });
  assert.deepStrictEqual(spec, []);
});

test('R6-D1: a template LIST source (no select field at all) derives nothing from source_config', () => {
  const spec = deriveInputSpec({
    id: 'c1', name: 'n', description: null, request_config: {},
    source_kind: 'template',
    source_config: { blueprint_id: 'bp1', mode: 'list', parts: ['outputs'] },
  });
  assert.deepStrictEqual(spec, []);
});

test('buildUsableProjection rebuilds outputs field-by-field, dropping unknown keys (non-secret whitelist)', () => {
  const out = buildUsableProjection({
    id: 'c1', name: 'n', description: null,
    url: 'http://h/{{id}}', request_config: {},
    response_config: {
      outputs: [{
        id: 'o1',
        from: {
          mode: 'list',
          path: 'data.networks',
          where: {
            match: 'all',
            conditions: [{ field: 'network_type', op: 'eq', value: { kind: 'literal', value: 'private1' } }],
          },
          // hypothetical extra key on `from` must NOT pass through the rebuild
          secret_leak: 'should-be-dropped',
        },
        to: {
          mode: 'field',
          field_key: 'gateway_ip',
          extract: 'ip_address',
          reduce: 'pick',
          // hypothetical extra key on `to` must NOT pass through the rebuild
          token: 'should-be-dropped',
        },
        // hypothetical extra top-level key must NOT pass through the rebuild
        secret_leak: 'should-be-dropped',
      }],
      transformer_id: null,
    },
  });
  assert.deepStrictEqual(out.response_config.outputs, [{
    id: 'o1',
    from: {
      mode: 'list',
      path: 'data.networks',
      where: {
        match: 'all',
        conditions: [{ field: 'network_type', op: 'eq', value: { kind: 'literal', value: 'private1' } }],
      },
    },
    to: { mode: 'field', field_key: 'gateway_ip', extract: 'ip_address', reduce: 'pick' },
  }]);
  // Field-by-field rebuild means unknown keys at any level are gone.
  const serialized = JSON.stringify(out.response_config.outputs);
  assert.equal(serialized.includes('secret_leak'), false);
  assert.equal(serialized.includes('should-be-dropped'), false);
  assert.equal(serialized.includes('token'), false);
});

test('buildUsableProjection rebuilds filter condition value-refs field-by-field, dropping sibling keys', () => {
  const out = buildUsableProjection({
    id: 'c1', name: 'n', description: null,
    url: 'http://h/{{id}}', request_config: {},
    response_config: {
      outputs: [{
        id: 'o1',
        from: {
          mode: 'list',
          path: 'data.networks',
          where: {
            match: 'all',
            conditions: [
              // literal value-ref carrying extra sibling keys (malformed/imported config)
              { field: 'svc_type', op: 'eq', value: { kind: 'literal', value: 'svc', secret_leak: 'SHOULD_NOT_APPEAR', token: 'xxx' } },
              // field value-ref with extras
              { field: 'owner', op: 'eq', value: { kind: 'field', field_key: 'owner_field', secret_leak: 'x' } },
              // cell value-ref with extras (incl. nested extras under cell)
              { field: 'host', op: 'eq', value: { kind: 'cell', cell: { table_key: 'nodes', column_key: 'hostname', row: 2, secret_leak: 'x' }, token: 'y' } },
              // unknown kind → value drops to null
              { field: 'mystery', op: 'eq', value: { kind: 'wat', payload: 'leak' } },
            ],
          },
        },
        to: { mode: 'field', field_key: 'gateway_ip' },
      }],
      transformer_id: null,
    },
  });
  const conds = out.response_config.outputs[0].from.where.conditions;
  assert.deepStrictEqual(conds[0].value, { kind: 'literal', value: 'svc' });
  assert.deepStrictEqual(conds[1].value, { kind: 'field', field_key: 'owner_field' });
  assert.deepStrictEqual(conds[2].value, { kind: 'cell', cell: { table_key: 'nodes', column_key: 'hostname', row: 2 } });
  assert.strictEqual(conds[3].value, null);
  // field/op are preserved as-is.
  assert.strictEqual(conds[0].field, 'svc_type');
  assert.strictEqual(conds[0].op, 'eq');
  // Field-by-field rebuild means sibling keys under value are gone everywhere.
  const serialized = JSON.stringify(out.response_config.outputs);
  assert.equal(serialized.includes('secret_leak'), false);
  assert.equal(serialized.includes('SHOULD_NOT_APPEAR'), false);
  assert.equal(serialized.includes('token'), false);
  assert.equal(serialized.includes('payload'), false);
});

test('buildUsableProjection carries output cell-sink shape', () => {
  const out = buildUsableProjection({
    id: 'c1', name: 'n', description: null,
    url: 'http://h/{{host}}', request_config: {},
    response_config: { outputs: [{ id: 'o1', from: { mode: 'value', path: 'ip' }, to: { mode: 'cell', table_key: 'nodes', column_key: 'public_ip', row: 0 } }], transformer_id: null },
  });
  assert.deepEqual(out.response_config.outputs, [{ id: 'o1', from: { mode: 'value', path: 'ip' }, to: { mode: 'cell', table_key: 'nodes', column_key: 'public_ip', row: 0 } }]);
});

test('deriveInputSpec attaches source_cell from input_cells', () => {
  const spec = deriveInputSpec({
    url: 'http://h/{{host}}',
    request_config: { input_cells: [{ table_key: 'nodes', column_key: 'hostname', var: 'host' }] },
  });
  assert.deepEqual(spec, [{ var: 'host', source_field_key: null, source_cell: { table_key: 'nodes', column_key: 'hostname' } }]);
});

test('deriveInputSpec carries a positive-integer row on the fixed-cell input', () => {
  const spec = deriveInputSpec({
    url: 'http://h/{{host}}',
    request_config: { input_cells: [{ table_key: 'nodes', column_key: 'hostname', var: 'host', row: 1 }] },
  });
  assert.deepEqual(spec, [{ var: 'host', source_field_key: null, source_cell: { table_key: 'nodes', column_key: 'hostname', row: 1 } }]);
});

test('deriveInputSpec omits row when absent or not a positive integer (per-row binding unchanged)', () => {
  const noRow = deriveInputSpec({
    url: 'http://h/{{host}}',
    request_config: { input_cells: [{ table_key: 'nodes', column_key: 'hostname', var: 'host' }] },
  });
  assert.ok(!('row' in noRow[0].source_cell));
  for (const bad of [0, -1, 1.5, '1', null]) {
    const spec = deriveInputSpec({
      url: 'http://h/{{host}}',
      request_config: { input_cells: [{ table_key: 'nodes', column_key: 'hostname', var: 'host', row: bad }] },
    });
    assert.ok(!('row' in spec[0].source_cell), `row=${bad} must be omitted`);
  }
});

test('buildUsableProjection carries rows-sink match + on_no_match (whitelisted, defaults op:eq)', () => {
  const out = buildUsableProjection({
    id: 'c1', name: 'n', description: null,
    url: 'http://h/{{key}}', request_config: {},
    response_config: {
      outputs: [{
        id: 'o1',
        from: { mode: 'list', path: 'data.rows' },
        to: {
          mode: 'rows',
          table_key: 'nodes',
          columns: [{ column_key: 'ip', from: 'ip_address' }],
          match: { row_column: 'hostname', element_field: 'host', op: 'eq', secret_leak: 'x' },
          on_no_match: 'skip',
          token: 'should-be-dropped',
        },
      }],
      transformer_id: null,
    },
  });
  assert.deepStrictEqual(out.response_config.outputs, [{
    id: 'o1',
    from: { mode: 'list', path: 'data.rows' },
    to: {
      mode: 'rows',
      table_key: 'nodes',
      columns: [{ column_key: 'ip', from: 'ip_address' }],
      match: { keys: [{ row_column: 'hostname', element_field: 'host', op: 'eq' }] },
      on_no_match: 'skip',
    },
  }]);
  const serialized = JSON.stringify(out.response_config.outputs);
  assert.equal(serialized.includes('secret_leak'), false);
  assert.equal(serialized.includes('should-be-dropped'), false);
});

test('buildUsableProjection defaults match.op to eq and omits on_no_match unless skip', () => {
  const out = buildUsableProjection({
    id: 'c1', name: 'n', description: null,
    url: 'http://h/{{key}}', request_config: {},
    response_config: {
      outputs: [{
        id: 'o1',
        from: { mode: 'list', path: 'data.rows' },
        to: {
          mode: 'rows', table_key: 'nodes', columns: [{ column_key: 'ip', from: 'ip' }],
          match: { row_column: 'hostname', element_field: 'host' },
        },
      }],
      transformer_id: null,
    },
  });
  const to = out.response_config.outputs[0].to;
  assert.deepStrictEqual(to.match, { keys: [{ row_column: 'hostname', element_field: 'host', op: 'eq' }] });
  assert.ok(!('on_no_match' in to));
});

test('buildUsableProjection forwards on_no_match create on an eq join (upsert)', () => {
  const out = buildUsableProjection({
    id: 'c1', name: 'n', description: null,
    url: 'http://h/{{key}}', request_config: {},
    response_config: {
      outputs: [{
        id: 'o1',
        from: { mode: 'list', path: 'data.rows' },
        to: {
          mode: 'rows', table_key: 'nodes', columns: [{ column_key: 'ip', from: 'ip' }],
          match: { row_column: 'hostname', element_field: 'host', op: 'eq' },
          on_no_match: 'create',
        },
      }],
      transformer_id: null,
    },
  });
  assert.equal(out.response_config.outputs[0].to.on_no_match, 'create');
});

test('buildUsableProjection drops on_no_match create when the stored op is non-eq', () => {
  const out = buildUsableProjection({
    id: 'c1', name: 'n', description: null,
    url: 'http://h/{{key}}', request_config: {},
    response_config: {
      outputs: [{
        id: 'o1',
        from: { mode: 'list', path: 'data.rows' },
        to: {
          mode: 'rows', table_key: 'nodes', columns: [{ column_key: 'ip', from: 'ip' }],
          // op coerces to eq in the projection, but create requires the STORED op to be eq.
          match: { row_column: 'hostname', element_field: 'host', op: 'contains' },
          on_no_match: 'create',
        },
      }],
      transformer_id: null,
    },
  });
  assert.ok(!('on_no_match' in out.response_config.outputs[0].to));
});

test('buildUsableProjection coerces an unknown match.op to eq', () => {
  const out = buildUsableProjection({
    id: 'c1', name: 'n', description: null,
    url: 'http://h/{{key}}', request_config: {},
    response_config: {
      outputs: [{
        id: 'o1',
        from: { mode: 'list', path: 'data.rows' },
        to: {
          mode: 'rows', table_key: 'nodes', columns: [{ column_key: 'ip', from: 'ip' }],
          match: { row_column: 'hostname', element_field: 'host', op: 'DROP' },
        },
      }],
      transformer_id: null,
    },
  });
  const to = out.response_config.outputs[0].to;
  assert.deepStrictEqual(to.match, { keys: [{ row_column: 'hostname', element_field: 'host', op: 'eq' }] });
});

test('buildUsableProjection drops a malformed match (missing row_column or element_field)', () => {
  for (const badMatch of [
    { element_field: 'host', op: 'eq' },       // missing row_column
    { row_column: 'hostname', op: 'eq' },      // missing element_field
    { row_column: '', element_field: 'host' }, // empty row_column
    { row_column: 'hostname', element_field: '' }, // empty element_field
  ]) {
    const out = buildUsableProjection({
      id: 'c1', name: 'n', description: null,
      url: 'http://h/{{key}}', request_config: {},
      response_config: {
        outputs: [{
          id: 'o1',
          from: { mode: 'list', path: 'data.rows' },
          to: { mode: 'rows', table_key: 'nodes', columns: [{ column_key: 'ip', from: 'ip' }], match: badMatch },
        }],
        transformer_id: null,
      },
    });
    const to = out.response_config.outputs[0].to;
    assert.deepStrictEqual(to, { mode: 'rows', table_key: 'nodes', columns: [{ column_key: 'ip', from: 'ip' }] });
    assert.ok(!('match' in to), `match must be dropped for ${JSON.stringify(badMatch)}`);
  }
});

test('buildUsableProjection: a rows sink with no match is unchanged (no match key)', () => {
  const out = buildUsableProjection({
    id: 'c1', name: 'n', description: null,
    url: 'http://h/{{key}}', request_config: {},
    response_config: {
      outputs: [{
        id: 'o1',
        from: { mode: 'list', path: 'data.rows' },
        to: { mode: 'rows', table_key: 'nodes', columns: [{ column_key: 'ip', from: 'ip' }] },
      }],
      transformer_id: null,
    },
  });
  assert.deepStrictEqual(out.response_config.outputs[0].to, {
    mode: 'rows', table_key: 'nodes', columns: [{ column_key: 'ip', from: 'ip' }],
  });
});

test('parseOutputKeys: JSON string array → string[]; junk → null', () => {
  assert.deepStrictEqual(parseOutputKeys('["a","b"]'), ['a', 'b']);
  assert.deepStrictEqual(parseOutputKeys(['a', 'b']), ['a', 'b']);
  assert.deepStrictEqual(parseOutputKeys(['a', 1, '', 'b']), ['a', 'b']); // non-strings/empties filtered
  assert.strictEqual(parseOutputKeys('[]'), null);          // empty → null (undeclared)
  assert.strictEqual(parseOutputKeys('{"a":1}'), null);     // non-array → null
  assert.strictEqual(parseOutputKeys('not json'), null);    // malformed → null
  assert.strictEqual(parseOutputKeys(null), null);
  assert.strictEqual(parseOutputKeys('null'), null);        // legacy rows that stored the string 'null' degrade to null
});

test('buildUsableProjection: transformer-mode connector carries declared output keys', () => {
  const row = {
    ...ROW,
    response_config: { outputs: [], transformer_id: 'tf1' },
  };
  const keysById = new Map([['tf1', ['qty', 'notes']]]);
  const p = buildUsableProjection(row, keysById);
  assert.deepStrictEqual(p.response_config, {
    outputs: [],
    transformer_id: 'tf1',
    transformer_output_keys: ['qty', 'notes'],
  });
});

test('buildUsableProjection: transformer-mode with no declaration projects null', () => {
  const row = { ...ROW, response_config: { outputs: [], transformer_id: 'tf-unknown' } };
  // Missing from the map (transformer row gone) and absent map both → null.
  assert.strictEqual(buildUsableProjection(row, new Map()).response_config.transformer_output_keys, null);
  assert.strictEqual(buildUsableProjection(row).response_config.transformer_output_keys, null);
});

test('buildUsableProjection: declarative connector always projects transformer_output_keys null', () => {
  const keysById = new Map([['tf1', ['qty']]]);
  const p = buildUsableProjection(ROW, keysById); // ROW has transformer_id: null
  assert.strictEqual(p.response_config.transformer_output_keys, null);
});

// Fix 1 (BE): order_by projection tests.

const rowsOutputWith = (extraTo) => ({
  ...ROW,
  response_config: {
    transformer_id: null,
    outputs: [{
      id: 'o1',
      from: { mode: 'list', path: 'data.nodes' },
      to: {
        mode: 'rows', table_key: 'nodes',
        columns: [{ column_key: 'ip', from: 'ip' }, { column_key: 'name', from: 'hostname' }],
        ...extraTo,
      },
    }],
  },
});

test('buildUsableProjection: order_by with valid surviving columns is projected (Fix 1)', () => {
  const row = rowsOutputWith({ order_by: [{ column: 'ip', dir: 'asc' }, { column: 'name', dir: 'desc' }] });
  const p = buildUsableProjection(row);
  const to = p.response_config.outputs[0].to;
  assert.deepStrictEqual(to.order_by, [{ column: 'ip', dir: 'asc' }, { column: 'name', dir: 'desc' }]);
});

test('buildUsableProjection: stale order_by key (column not in projected columns) is dropped (Fix 1)', () => {
  // 'removed' column is NOT in the columns array, so its sort key must be dropped.
  const row = rowsOutputWith({ order_by: [{ column: 'ip', dir: 'asc' }, { column: 'removed', dir: 'desc' }] });
  const p = buildUsableProjection(row);
  const to = p.response_config.outputs[0].to;
  assert.deepStrictEqual(to.order_by, [{ column: 'ip', dir: 'asc' }]);
});

test('buildUsableProjection: order_by absent when all keys reference non-projected columns', () => {
  const row = rowsOutputWith({ order_by: [{ column: 'ghost', dir: 'asc' }] });
  const p = buildUsableProjection(row);
  const to = p.response_config.outputs[0].to;
  assert.strictEqual(to.order_by, undefined);
});
