'use strict';

/**
 * flow-yaml-dialect-no-alter-db.test.js — the fmb-2061 commander ruling
 * (third fix round) proven against a real scratch MariaDB missing the THREE
 * step dialect columns (content_type/yaml_version/yaml_quoting), which
 * flow-yaml-dialect PR-Y1's ADD COLUMN never reached.
 *
 * THE DEFECT THIS CLOSES. On such a DB, PR-Y2 stopped reading
 * flow_recipes.content_type (the pre-Y1 recipe-level dialect) once the
 * per-step columns existed to replace it — but on a DB where the step
 * columns were never added, an existing YAML recipe silently ran, exported,
 * and imported as JSON, because nothing read the ONE place that still knew
 * it was YAML.
 *
 * THE RULE PROVEN HERE, at every site: when the step dialect columns are
 * absent, flow_recipes.content_type is the dialect of EVERY step of that
 * recipe (yaml_version 1.2 / quoting plain — the pre-Y1 implicit dialect).
 * This can only fire on a DB that never applied Y1's ADD COLUMN, and such a
 * DB cannot have applied YZ's later DROP COLUMN on that same column, so
 * reading it here never conflicts with that migration (asserted by the
 * migrated-path regression test below, which proves the column is NOT read
 * once the step columns exist).
 *
 * Skips with a stated reason when no database is reachable, and fails
 * instead of skipping when REQUIRE_INTEGRATION_DB=1.
 */
const { test, describe, before, after, beforeEach } = require('node:test');
const { makeStubReqLog } = require('../helpers/stub-req-log');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const net = require('node:net');
const http = require('node:http');
const express = require('express');
const mariadb = require('mariadb');

process.env.SETTINGS_ENCRYPTION_KEY = process.env.SETTINGS_ENCRYPTION_KEY
  || 'flow-yaml-dialect-no-alter-db-test-key';

const TEST_PREFIX = 'fyd_';
const tbl = (name) => `${TEST_PREFIX}${name}`;

let pool = null;
const poolFacade = {
  getConnection: () => pool.getConnection(),
  query: (sql, params) => pool.query(sql, params),
};

// The double is DERIVED from the real module, not hand-listed (same discipline
// as parent-guard-no-alter-db.test.js).
const dbKey = require.resolve('../../src/edge/db');
const realDb = require('../../src/edge/db');
const realDbEntry = require.cache[dbKey];
require.cache[dbKey] = {
  ...realDbEntry,
  exports: {
    ...realDb,
    pool: { ro: poolFacade, rw: poolFacade },
    t: tbl,
    getDynamicPool: async () => ({ ro: poolFacade, rw: poolFacade }),
  },
};

const { buildEngineTableDDLs, buildInfraTableDDLs } = require('../../src/table-ddls');
const { TABLES } = require('../../src/shared/constants');
const runBeginRouter = require('../../src/edge/routes/internal/flow-recipes-run');
const stepsRouter = require('../../src/edge/routes/app/flow-recipe-steps');
const recipesRouter = require('../../src/edge/routes/app/flow-recipes');
const { fixtureUserId } = require('../helpers/fixture-ids');

// ── Config auto-detection (same shape as parent-guard-no-alter-db.test.js) ───

function parseEnvFile(filePath) {
  try {
    const raw = fs.readFileSync(filePath, 'utf8');
    const out = {};
    for (const line of raw.split('\n')) {
      const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
      if (m) out[m[1]] = m[2].replace(/^["']|["']$/g, '');
    }
    return out;
  } catch {
    return null;
  }
}

function probePort(host, port, timeoutMs = 2000) {
  return new Promise((resolve) => {
    const socket = new net.Socket();
    let done = false;
    const finish = (ok) => {
      if (done) return;
      done = true;
      socket.destroy();
      resolve(ok);
    };
    socket.setTimeout(timeoutMs);
    socket.once('connect', () => finish(true));
    socket.once('timeout', () => finish(false));
    socket.once('error', () => finish(false));
    socket.connect(port, host);
  });
}

async function resolveMariaDbConfig() {
  if (process.env.DB_TEST_HOST && process.env.DB_TEST_ROOT_PASSWORD) {
    return {
      host: process.env.DB_TEST_HOST,
      port: parseInt(process.env.DB_TEST_PORT || '3306', 10),
      user: 'root',
      password: process.env.DB_TEST_ROOT_PASSWORD,
    };
  }
  const envPath = path.resolve(__dirname, '../../../.devcontainer/.env');
  const env = parseEnvFile(envPath);
  if (!env || !env.DB_ROOT_PASSWORD) return null;
  const port = parseInt(env.DB_PORT || '3306', 10);
  for (const host of ['127.0.0.1', 'mariadb', 'localhost']) {
    if (await probePort(host, port, 2000)) {
      return { host, port, user: 'root', password: env.DB_ROOT_PASSWORD };
    }
  }
  return null;
}

// ── Fixture ───────────────────────────────────────────────────────────────

const ADMIN = { id: fixtureUserId('admin'), role: 'admin' };
const BLUEPRINT = '22222222-2222-4222-8222-222222222222';

const WANTED_TABLES = [
  TABLES.FLOW_RECIPES,
  TABLES.FLOW_RECIPE_STEPS,
  TABLES.FLOW_RECIPE_RUNS,
  TABLES.HIERARCHY_NODES,
  TABLES.SYSTEM_SETTINGS,
];

// The three columns PR-Y1's ADD COLUMN carried and this fixture drops, so this
// database is stuck exactly at the pre-Y1 shape.
const DIALECT_COLUMNS = ['content_type', 'yaml_version', 'yaml_quoting'];

// table-ddls.js no longer declares flow_recipes.content_type (PR-YZ Task Z.0,
// fmb-2062 dropped it wherever the drop's precondition holds) — so a fixture
// built straight from the current DDL can no longer represent this database
// shape at all. A GENUINELY no-ALTER install (never applied the 3.2.972 ADD
// COLUMN) still has this column physically, and always will: Task Z.0's own
// probe refuses to drop it there. This ALTER re-creates that reality on top
// of the (now column-free) fresh-install DDL, same idea as the DROP COLUMN
// three lines below simulating the missing step columns.
const LEGACY_RECIPE_CONTENT_TYPE_DDL = "content_type ENUM('application/json','application/yaml') NOT NULL DEFAULT 'application/json'";

let dbReady = false;
let skipReason = null;
let testDbName = null;
let server = null;
let baseUrl = null;

before(async () => {
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) {
    skipReason = 'no MariaDB reachable via .devcontainer/.env or env vars';
    if (process.env.REQUIRE_INTEGRATION_DB === '1') {
      throw new Error(`REQUIRE_INTEGRATION_DB=1 set but ${skipReason}.`);
    }
    return;
  }
  testDbName = `fyd_noalter_${process.pid}_${Date.now()}`;
  let admin = null;
  try {
    admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`CREATE DATABASE \`${testDbName}\``);
    await admin.query(`USE \`${testDbName}\``);
    const wanted = new Set(WANTED_TABLES.map(tbl));
    const statements = [...buildInfraTableDDLs(tbl), ...buildEngineTableDDLs(tbl)].filter((sql) => {
      const m = sql.match(/CREATE TABLE IF NOT EXISTS `([^`]+)`/);
      return m && wanted.has(m[1]);
    });
    assert.equal(
      statements.length, wanted.size,
      `the DDL list no longer defines all of: ${[...wanted].join(', ')}`,
    );
    for (const sql of statements) await admin.query(sql);
    await admin.query(`ALTER TABLE \`${tbl(TABLES.FLOW_RECIPES)}\` ADD COLUMN ${LEGACY_RECIPE_CONTENT_TYPE_DDL}`);
    for (const col of DIALECT_COLUMNS) {
      await admin.query(`ALTER TABLE \`${tbl(TABLES.FLOW_RECIPE_STEPS)}\` DROP COLUMN \`${col}\``);
    }
    await admin.end();
    admin = null;

    pool = mariadb.createPool({
      ...dbConfig, database: testDbName, connectionLimit: 8, connectTimeout: 5000,
    });
    await pool.query(
      `INSERT INTO \`${tbl(TABLES.HIERARCHY_NODES)}\` (id, name, node_type, owner_id)
       VALUES (?, 'shared-blueprint', 'blueprint', NULL)`,
      [BLUEPRINT],
    );

    const app = express();
    app.use((req, _res, next) => { req.log = makeStubReqLog(); next(); }); // TEST-ONLY: production always sets req.log via createRequestId (request-id.js) before any router; this bare app has no such middleware, so a route's req.log.<level>() call would otherwise throw against undefined.
    app.use(express.json());
    app.use((req, _res, next) => { req.user = ADMIN; next(); });
    app.use('/edge/internal/flow-recipes', runBeginRouter);
    app.use('/edge/app/flow-recipe-steps', stepsRouter);
    app.use('/edge/app/flow-recipes', recipesRouter);
    server = http.createServer(app);
    await new Promise((r) => server.listen(0, r));
    baseUrl = `http://127.0.0.1:${server.address().port}`;
    dbReady = true;
  } catch (err) {
    skipReason = `setup failed: ${err.message}`;
    if (admin) { try { await admin.end(); } catch { /* best effort */ } }
    if (process.env.REQUIRE_INTEGRATION_DB === '1') throw err;
  }
});

after(async () => {
  if (server) { try { server.close(); } catch { /* best effort */ } }
  if (pool) { try { await pool.end(); } catch { /* best effort */ } }
  require.cache[dbKey] = realDbEntry;
  if (!testDbName) return;
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) return;
  try {
    const admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`DROP DATABASE IF EXISTS \`${testDbName}\``);
    await admin.end();
  } catch { /* best effort */ }
});

const guard = (t) => {
  if (!dbReady) { t.skip(skipReason || 'database not ready'); return true; }
  return false;
};

async function call(method, url, body) {
  const res = await fetch(`${baseUrl}${url}`, {
    method,
    headers: { 'content-type': 'application/json' },
    ...(body === undefined ? {} : { body: JSON.stringify(body) }),
  });
  const text = await res.text();
  let parsed = null;
  try { parsed = JSON.parse(text); } catch { parsed = { raw: text }; }
  return { status: res.status, body: parsed };
}

let seq = 0;
const uid = (tag) => `${tag}${String(seq += 1).padStart(4, '0')}-4444-4444-8444-444444444444`;

// Seeds a recipe row directly (bypassing the CRUD write path, which is not
// under test here) — approved + active + bound, so run-begin's gates pass.
async function seedRecipe({ contentType = 'application/yaml' } = {}) {
  const id = uid('aaaa');
  await pool.query(
    `INSERT INTO \`${tbl(TABLES.FLOW_RECIPES)}\`
     (id, name, blueprint_id, owner_id, is_active, status, content_type)
     VALUES (?, 'r', ?, NULL, 1, 'approved', ?)`,
    [id, BLUEPRINT, contentType],
  );
  return id;
}

async function seedStep(recipeId, sequence = 1) {
  const id = uid('bbbb');
  // The three dialect columns do not exist on this schema — the INSERT below
  // names only the columns this fixture actually has.
  await pool.query(
    `INSERT INTO \`${tbl(TABLES.FLOW_RECIPE_STEPS)}\`
     (id, recipe_id, \`sequence\`, name, method, url, auth_type)
     VALUES (?, ?, ?, 'st', 'POST', 'https://upstream.test/v1/step', 'none')`,
    [id, recipeId, sequence],
  );
  return id;
}

const recipeContentType = async (id) => {
  const rows = await pool.query(
    `SELECT content_type FROM \`${tbl(TABLES.FLOW_RECIPES)}\` WHERE id = ?`, [id],
  );
  return rows.length ? rows[0].content_type : undefined;
};

describe('PREMISE: the fixture really lacks the step dialect columns', () => {
  test('a SELECT naming them errors 1054, and the recipe-level column is still there', async (t) => {
    if (guard(t)) return;
    const recipeId = await seedRecipe();
    let errno = null;
    try {
      await pool.query(
        `SELECT content_type FROM \`${tbl(TABLES.FLOW_RECIPE_STEPS)}\` WHERE recipe_id = ?`,
        [recipeId],
      );
    } catch (err) {
      errno = err && err.errno;
    }
    assert.equal(errno, 1054, 'this fixture is not the degraded shape — the step dialect columns are still present');
    assert.equal(await recipeContentType(recipeId), 'application/yaml', 'the legacy recipe-level column must survive the drop');
  });
});

describe('run-begin: the recipe-level content_type is every step\'s dialect', () => {
  test('a YAML recipe still runs YAML on a no-ALTER DB, not JSON', async (t) => {
    if (guard(t)) return;
    const recipeId = await seedRecipe({ contentType: 'application/yaml' });
    await seedStep(recipeId, 1);
    await seedStep(recipeId, 2);
    const res = await call('POST', '/edge/internal/flow-recipes/run-begin', {
      recipe_id: recipeId, payload: { a: 1 },
    });
    assert.equal(res.status, 200, `run-begin failed: ${JSON.stringify(res.body)}`);
    const steps = res.body.data.steps;
    assert.equal(steps.length, 2);
    for (const step of steps) {
      assert.equal(step.content_type, 'application/yaml', 'a step must inherit the recipe\'s YAML dialect');
      assert.equal(step.yaml_version, '1.2');
      assert.equal(step.yaml_quoting, 'plain');
    }
  });

  test('a JSON recipe stays JSON on the same no-ALTER DB (the fallback is not YAML-only)', async (t) => {
    if (guard(t)) return;
    const recipeId = await seedRecipe({ contentType: 'application/json' });
    await seedStep(recipeId, 1);
    const res = await call('POST', '/edge/internal/flow-recipes/run-begin', {
      recipe_id: recipeId, payload: { a: 1 },
    });
    assert.equal(res.status, 200, `run-begin failed: ${JSON.stringify(res.body)}`);
    assert.equal(res.body.data.steps[0].content_type, 'application/json');
  });
});

describe('export: the bundle carries the recipe-level dialect on every step DTO', () => {
  test('exports content_type/yaml_version/yaml_quoting onto every step, recipe DTO stays without it', async (t) => {
    if (guard(t)) return;
    const recipeId = await seedRecipe({ contentType: 'application/yaml' });
    await seedStep(recipeId, 1);
    const res = await call('GET', `/edge/app/flow-recipes/${recipeId}/export`);
    assert.equal(res.status, 200, `export failed: ${JSON.stringify(res.body)}`);
    assert.equal('content_type' in res.body.data.recipe, false, 'the retired recipe-level DTO field stays retired');
    assert.equal(res.body.data.steps.length, 1);
    assert.equal(res.body.data.steps[0].content_type, 'application/yaml');
    assert.equal(res.body.data.steps[0].yaml_version, '1.2');
    assert.equal(res.body.data.steps[0].yaml_quoting, 'plain');
  });
});

describe('import: a uniform bundle persists the legacy column; a mixed one is refused', () => {
  test('a uniform-YAML bundle imports 201 and stamps the legacy recipe-level column', async (t) => {
    if (guard(t)) return;
    const res = await call('POST', '/edge/app/flow-recipes/import', {
      recipe: { name: 'imported yaml', blueprint_id: BLUEPRINT },
      steps: [
        { sequence: 0, name: 's1', url: 'https://upstream.test/a', content_type: 'application/yaml' },
        { sequence: 1, name: 's2', url: 'https://upstream.test/b', content_type: 'application/yaml' },
      ],
    });
    assert.equal(res.status, 201, `import failed: ${JSON.stringify(res.body)}`);
    assert.equal(await recipeContentType(res.body.data.id), 'application/yaml',
      'the legacy recipe-level column must carry the bundle\'s uniform dialect');
  });

  test('a uniform bundle authored at yaml_version 1.1 / yaml_quoting double COLLAPSES to 1.2/plain on this target (documented accept, flow-yaml-dialect PR-YZ Task Z.2c, fmb-2062)', async (t) => {
    if (guard(t)) return;
    // The legacy recipe-level column remembers content_type ONLY — it has no
    // place to carry yaml_version/yaml_quoting. A bundle authored at a
    // non-default dialect therefore lands (and reads back, via run-begin's
    // legacy-tier fallback) at the implicit pre-Y1 dialect (1.2/plain), not
    // the bundle's real one. This is the deliberate degradation the ruling
    // accepts, pinned explicitly so a future change to it is a decision, not
    // an accident.
    const res = await call('POST', '/edge/app/flow-recipes/import', {
      recipe: { name: 'imported yaml 1.1 double', blueprint_id: BLUEPRINT },
      steps: [
        { sequence: 0, name: 's1', url: 'https://upstream.test/a', content_type: 'application/yaml', yaml_version: '1.1', yaml_quoting: 'double' },
        { sequence: 1, name: 's2', url: 'https://upstream.test/b', content_type: 'application/yaml', yaml_version: '1.1', yaml_quoting: 'double' },
      ],
    });
    assert.equal(res.status, 201, `import failed: ${JSON.stringify(res.body)}`);
    const recipeId = res.body.data.id;
    assert.equal(await recipeContentType(recipeId), 'application/yaml',
      'content_type is the one thing the legacy column CAN still carry');

    const runRes = await call('POST', '/edge/internal/flow-recipes/run-begin', {
      recipe_id: recipeId, payload: { a: 1 },
    });
    assert.equal(runRes.status, 200, `run-begin failed: ${JSON.stringify(runRes.body)}`);
    assert.ok(runRes.body.data.steps.length > 0, 'expected at least one step in the run-begin response');
    for (const step of runRes.body.data.steps) {
      assert.equal(step.content_type, 'application/yaml', 'content_type survives the collapse');
      assert.equal(step.yaml_version, '1.2', 'yaml_version COLLAPSED from the authored 1.1 to the implicit default');
      assert.equal(step.yaml_quoting, 'plain', 'yaml_quoting COLLAPSED from the authored double to the implicit default');
    }
  });

  test('a mixed JSON+YAML bundle is refused 409 DIALECT_COLUMNS_UNAVAILABLE, and creates nothing', async (t) => {
    if (guard(t)) return;
    const before = await pool.query(`SELECT COUNT(*) AS n FROM \`${tbl(TABLES.FLOW_RECIPES)}\``);
    const res = await call('POST', '/edge/app/flow-recipes/import', {
      recipe: { name: 'imported mixed', blueprint_id: BLUEPRINT },
      steps: [
        { sequence: 0, name: 's1', url: 'https://upstream.test/a', content_type: 'application/json' },
        { sequence: 1, name: 's2', url: 'https://upstream.test/b', content_type: 'application/yaml' },
      ],
    });
    assert.equal(res.status, 409, `expected 409, got ${res.status}: ${JSON.stringify(res.body)}`);
    assert.equal(res.body.error && res.body.error.code, 'DIALECT_COLUMNS_UNAVAILABLE');
    const after = await pool.query(`SELECT COUNT(*) AS n FROM \`${tbl(TABLES.FLOW_RECIPES)}\``);
    assert.equal(Number(after[0].n), Number(before[0].n), 'a refused import must not create a recipe row');
  });
});

describe('step write (Codex r2 P1 verification): VERIFIED — crud-factory silently strips the absent columns; it is 500 ONLY when nothing else survives the strip', () => {
  test('POST /flow-recipe-steps with content_type in the body (alongside real fields) returns 201, not 500', async (t) => {
    if (guard(t)) return;
    const recipeId = await seedRecipe({ contentType: 'application/yaml' });
    const res = await call('POST', '/edge/app/flow-recipe-steps', {
      recipe_id: recipeId,
      name: 'new step',
      method: 'POST',
      url: 'https://upstream.test/v1/new',
      auth_type: 'none',
      content_type: 'application/yaml',
    });
    assert.notEqual(res.status, 500, `expected a non-500 status, got 500: ${JSON.stringify(res.body)}`);
    assert.ok(res.status === 200 || res.status === 201, `expected 200/201, got ${res.status}: ${JSON.stringify(res.body)}`);
  });

  test('PUT with content_type alongside a real field returns 200; the real field lands, content_type is silently dropped (no error, no persistence)', async (t) => {
    if (guard(t)) return;
    const recipeId = await seedRecipe({ contentType: 'application/yaml' });
    const stepId = await seedStep(recipeId, 1);
    const res = await call('PUT', `/edge/app/flow-recipe-steps/${stepId}`, {
      name: 'renamed', content_type: 'application/yaml', yaml_version: '1.1', yaml_quoting: 'double',
    });
    assert.notEqual(res.status, 500, `expected a non-500 status, got 500: ${JSON.stringify(res.body)}`);
    assert.equal(res.status, 200, `expected 200, got ${res.status}: ${JSON.stringify(res.body)}`);
    const after = await pool.query(
      `SELECT name FROM \`${tbl(TABLES.FLOW_RECIPE_STEPS)}\` WHERE id = ?`, [stepId],
    );
    assert.equal(after[0].name, 'renamed', 'the real field alongside the absent columns must still land');
  });

  // VERIFIED, not assumed (fmb-2061 brief item 4): sharp B's read of
  // gateKeysByColumnSet predicted a silent 200 no-op for EVERY shape. Measured
  // here instead: when EVERY key in the body is one of the three absent
  // dialect columns, gateKeysByColumnSet strips them ALL, crud-factory's
  // write-handler then finds an EMPTY key set and answers 400 "No valid
  // fields to update" — not 500, but not a silent 200 either. This is a
  // pre-existing crud-factory behaviour (empty-write guard), unrelated to the
  // fmb-2061 dialect fix, and out of scope to change here per the dispatch
  // brief ("if it IS a 500, fix at the crud-factory level is out of scope").
  // It is NOT a 500, which is the property the brief asked to verify.
  test('PUT with ONLY the three absent dialect columns returns 400 "No valid fields to update" — NOT 500, NOT a silent 200', async (t) => {
    if (guard(t)) return;
    const recipeId = await seedRecipe({ contentType: 'application/yaml' });
    const stepId = await seedStep(recipeId, 1);
    const before = await pool.query(
      `SELECT name, method, url, auth_type FROM \`${tbl(TABLES.FLOW_RECIPE_STEPS)}\` WHERE id = ?`, [stepId],
    );
    const res = await call('PUT', `/edge/app/flow-recipe-steps/${stepId}`, {
      content_type: 'application/yaml', yaml_version: '1.1', yaml_quoting: 'double',
    });
    assert.notEqual(res.status, 500, `expected a non-500 status, got 500: ${JSON.stringify(res.body)}`);
    assert.equal(res.status, 400, `expected 400 (empty-write guard), got ${res.status}: ${JSON.stringify(res.body)}`);
    assert.equal(res.body.error && res.body.error.code, 'BAD_REQUEST');
    const after = await pool.query(
      `SELECT name, method, url, auth_type FROM \`${tbl(TABLES.FLOW_RECIPE_STEPS)}\` WHERE id = ?`, [stepId],
    );
    assert.deepEqual(after[0], before[0], 'a refused write must leave every present column unchanged');
  });
});

describe('migrated-path regression: the legacy column is NOT read once the step columns exist', () => {
  // A second, freshly-migrated scratch DB — this suite's whole premise is a
  // DB that never got the columns, so proving the opposite needs its own pool.
  let migPool = null;
  let migTestDbName = null;

  before(async (t) => {
    if (!dbReady) { t.skip('no database'); return; }
    const dbConfig = await resolveMariaDbConfig();
    migTestDbName = `fyd_migrated_${process.pid}_${Date.now()}`;
    const admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`CREATE DATABASE \`${migTestDbName}\``);
    await admin.query(`USE \`${migTestDbName}\``);
    const wanted = new Set(WANTED_TABLES.map(tbl));
    const statements = [...buildInfraTableDDLs(tbl), ...buildEngineTableDDLs(tbl)].filter((sql) => {
      const m = sql.match(/CREATE TABLE IF NOT EXISTS `([^`]+)`/);
      return m && wanted.has(m[1]);
    });
    for (const sql of statements) await admin.query(sql);
    // This DB represents the transitional window between PR-Y2 (step columns
    // ADDed) and PR-YZ Task Z.0's drop-column running (which requires every
    // replica confirmed rolled out first) — the recipe column can still be
    // physically present here even though the current DDL no longer declares
    // it for a fresh install. Re-creating it is what makes "never read even
    // though present and disagreeing" a real assertion rather than vacuous.
    await admin.query(`ALTER TABLE \`${tbl(TABLES.FLOW_RECIPES)}\` ADD COLUMN ${LEGACY_RECIPE_CONTENT_TYPE_DDL}`);
    await admin.end();
    migPool = mariadb.createPool({ ...dbConfig, database: migTestDbName, connectionLimit: 4, connectTimeout: 5000 });
  });

  after(async () => {
    if (migPool) { try { await migPool.end(); } catch { /* best effort */ } }
    if (!migTestDbName) return;
    const dbConfig = await resolveMariaDbConfig();
    if (!dbConfig) return;
    try {
      const admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
      await admin.query(`DROP DATABASE IF EXISTS \`${migTestDbName}\``);
      await admin.end();
    } catch { /* best effort */ }
  });

  test('a migrated DB never reads flow_recipes.content_type on run-begin — the step\'s OWN dialect wins even when it disagrees with the (unread) recipe column', async (t) => {
    if (guard(t) || !migPool) { t.skip(skipReason || 'migrated pool not ready'); return; }
    // Swap the live pool facade to point at the MIGRATED database for this one
    // assertion — the recipe column is deliberately set to YAML while the
    // step's own column says JSON, so if the fallback fired here (a
    // regression) the test would see YAML instead.
    const savedQuery = poolFacade.query;
    const savedGetConnection = poolFacade.getConnection;
    poolFacade.query = (sql, params) => migPool.query(sql, params);
    poolFacade.getConnection = () => migPool.getConnection();
    try {
      const recipeId = uid('cccc');
      await migPool.query(
        `INSERT INTO \`${tbl(TABLES.FLOW_RECIPES)}\`
         (id, name, blueprint_id, owner_id, is_active, status, content_type)
         VALUES (?, 'r', ?, NULL, 1, 'approved', 'application/yaml')`,
        [recipeId, BLUEPRINT],
      );
      const stepId = uid('dddd');
      await migPool.query(
        `INSERT INTO \`${tbl(TABLES.FLOW_RECIPE_STEPS)}\`
         (id, recipe_id, \`sequence\`, name, method, url, auth_type, content_type, yaml_version, yaml_quoting)
         VALUES (?, ?, 1, 'st', 'POST', 'https://upstream.test/v1/step', 'none', 'application/json', '1.2', 'plain')`,
        [stepId, recipeId],
      );
      const res = await call('POST', '/edge/internal/flow-recipes/run-begin', {
        recipe_id: recipeId, payload: { a: 1 },
      });
      assert.equal(res.status, 200, `run-begin failed: ${JSON.stringify(res.body)}`);
      assert.equal(res.body.data.steps[0].content_type, 'application/json',
        'the step\'s own dialect must win — the migrated path must not read the recipe column at all');
    } finally {
      poolFacade.query = savedQuery;
      poolFacade.getConnection = savedGetConnection;
    }
  });
});
