'use strict';

/**
 * hierarchy-variant-create-ownership-real-db.test.js — fmb-1993, against a
 * real database, reading the stored rows back.
 *
 * WHY A REAL DATABASE. Every case here is a claim about which row an editor's
 * POST /hierarchy_nodes was allowed to write and what owner_id it landed with
 * — a mocked driver answers whatever the fixture was told to say, which is how
 * this defect (create had NO gate at all) shipped unnoticed.
 *
 * Pattern follows write-core-identity-real-db.test.js: a real Express app
 * mounting the shipped schemaRouter, a real MariaDB database built from the
 * shipped DDL, HTTP calls through `fetch`, assertions on the STORED row —
 * never a status code alone where the row is about data.
 *
 * Skips with a stated reason when no database is reachable, and FAILS instead
 * of skipping when REQUIRE_INTEGRATION_DB=1 — a silent skip is the failure
 * mode this whole line of work exists to end.
 */
const { test, describe, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const net = require('node:net');
const crypto = require('node:crypto');
const http = require('node:http');
const express = require('express');
const mariadb = require('mariadb');

const TEST_PREFIX = 'hvc_';
const tbl = (name) => `${TEST_PREFIX}${name}`;

let pool = null;
const lease = () => pool.getConnection();

const dbKey = require.resolve('../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey,
  filename: dbKey,
  loaded: true,
  exports: {
    pool: { ro: { getConnection: lease }, rw: { getConnection: lease } },
    t: tbl,
    getDynamicPool: async () => ({ ro: { getConnection: lease }, rw: { getConnection: lease } }),
  },
};

const { buildEngineTableDDLs, buildInfraTableDDLs } = require('../../src/table-ddls');
const schemaRouter = require('../../src/edge/routes/app/schema');
const { fixtureUserId } = require('../helpers/fixture-ids');

// ── Config auto-detection (same shape as the sibling integration tests) ──────

function parseEnvFile(filePath) {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    const out = {};
    for (const line of content.split('\n')) {
      const m = line.match(/^\s*([A-Z_][A-Z0-9_]*)\s*=\s*(.*)\s*$/);
      if (!m) continue;
      let value = m[2];
      if ((value.startsWith('"') && value.endsWith('"'))
        || (value.startsWith("'") && value.endsWith("'"))) {
        value = value.slice(1, -1);
      }
      out[m[1]] = value;
    }
    return out;
  } catch {
    return null;
  }
}

function probePort(host, port, timeoutMs = 2000) {
  return new Promise((resolve) => {
    const socket = new net.Socket();
    let done = false;
    const finish = (ok) => {
      if (done) return;
      done = true;
      socket.destroy();
      resolve(ok);
    };
    socket.setTimeout(timeoutMs);
    socket.once('connect', () => finish(true));
    socket.once('timeout', () => finish(false));
    socket.once('error', () => finish(false));
    socket.connect(port, host);
  });
}

async function resolveMariaDbConfig() {
  if (process.env.DB_TEST_HOST && process.env.DB_TEST_ROOT_PASSWORD) {
    return {
      host: process.env.DB_TEST_HOST,
      port: parseInt(process.env.DB_TEST_PORT || '3306', 10),
      user: 'root',
      password: process.env.DB_TEST_ROOT_PASSWORD,
    };
  }
  const envPath = path.resolve(__dirname, '../../../.devcontainer/.env');
  const env = parseEnvFile(envPath);
  if (!env || !env.DB_ROOT_PASSWORD) return null;
  const port = parseInt(env.DB_PORT || '3306', 10);
  for (const host of ['127.0.0.1', 'mariadb', 'localhost']) {
    if (await probePort(host, port, 2000)) {
      return { host, port, user: 'root', password: env.DB_ROOT_PASSWORD };
    }
  }
  return null;
}

// ── Fixture ─────────────────────────────────────────────────────────────────

const ADMIN = { id: fixtureUserId('admin'), role: 'admin' };
const EDITOR = { id: fixtureUserId('editor'), role: 'editor' };
const OTHER_EDITOR = { id: '2af146d0-081f-4869-8a8f-3bf248676df8', role: 'editor' };
const OTHER_EDITOR_NO_GRANT = { id: '4c4c4c4c-6666-4666-8666-000000000006', role: 'editor' };

const BP_EDITOR_OWNED = 'aaaaaaaa-1111-4111-8111-000000000001';
const BP_SHARED = 'bbbbbbbb-2222-4222-8222-000000000002';
const BP_OTHER_OWNED = 'cccccccc-3333-4333-8333-000000000003';
const CATEGORY = 'dddddddd-4444-4444-8444-000000000004';
const CATEGORY_SHARED = 'eeeeeeee-5555-4555-8555-000000000005';

let dbReady = false;
let skipReason = null;
let testDbName = null;
let server = null;
let baseUrl = null;
let currentUser = ADMIN;

before(async () => {
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) {
    skipReason = 'no MariaDB reachable via .devcontainer/.env or env vars';
    if (process.env.REQUIRE_INTEGRATION_DB === '1') {
      throw new Error(`REQUIRE_INTEGRATION_DB=1 set but ${skipReason}.`);
    }
    return;
  }
  testDbName = `hvc_ownership_test_${process.pid}_${Date.now()}`;
  let admin = null;
  try {
    admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`CREATE DATABASE \`${testDbName}\``);
    await admin.query(`USE \`${testDbName}\``);
    for (const sql of [...buildInfraTableDDLs(tbl), ...buildEngineTableDDLs(tbl)]) {
      await admin.query(sql);
    }
    await admin.end();
    admin = null;

    pool = mariadb.createPool({
      ...dbConfig, database: testDbName, connectionLimit: 6, connectTimeout: 5000,
    });

    const app = express();
    app.use(express.json());
    app.use((req, _res, next) => { req.user = currentUser; next(); });
    app.use('/edge/app/schema', schemaRouter);
    server = http.createServer(app);
    await new Promise((r) => server.listen(0, r));
    baseUrl = `http://127.0.0.1:${server.address().port}`;
    dbReady = true;
  } catch (err) {
    skipReason = `setup failed: ${err.message}`;
    if (admin) { try { await admin.end(); } catch { /* best effort */ } }
    if (process.env.REQUIRE_INTEGRATION_DB === '1') throw err;
  }
});

after(async () => {
  if (server) { try { server.close(); } catch { /* best effort */ } }
  if (pool) { try { await pool.end(); } catch { /* best effort */ } }
  if (!testDbName) return;
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) return;
  try {
    const admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`DROP DATABASE IF EXISTS \`${testDbName}\``);
    await admin.end();
  } catch { /* best effort */ }
});

async function call(user, method, url, body) {
  currentUser = user;
  const res = await fetch(`${baseUrl}${url}`, {
    method,
    headers: { 'content-type': 'application/json' },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const text = await res.text();
  let parsed = null;
  try { parsed = JSON.parse(text); } catch { parsed = { raw: text }; }
  return { status: res.status, body: parsed };
}

const one = async (sql, params) => (await pool.query(sql, params))[0];
const countOf = async (sql, params) => Number((await one(sql, params)).n);

const guard = (t) => {
  if (!dbReady) { t.skip(skipReason || 'database not ready'); return true; }
  return false;
};

beforeEach(async () => {
  if (!dbReady) return;
  for (const name of ['delegated_grants', 'hierarchy_nodes', 'feature_audit']) {
    await pool.query(`DELETE FROM \`${tbl(name)}\``);
  }
});

async function seedHierarchy() {
  await pool.query(
    `INSERT INTO \`${tbl('hierarchy_nodes')}\` (id, name, node_type, owner_id) VALUES
     (?, 'CAT', 'category', ?),
     (?, 'BP editor-owned', 'blueprint', ?),
     (?, 'BP shared', 'blueprint', NULL),
     (?, 'BP other-owned', 'blueprint', ?),
     (?, 'CAT shared', 'category', NULL)`,
    [CATEGORY, ADMIN.id, BP_EDITOR_OWNED, EDITOR.id, BP_SHARED, BP_OTHER_OWNED, OTHER_EDITOR.id,
     CATEGORY_SHARED],
  );
}

async function grantBlueprint(blueprintId, granteeId) {
  // id is CHAR(36) — the DDL's default (UUID()) would also do, but binding an
  // explicit value keeps this deterministic like every other fixture row here.
  await pool.query(
    `INSERT INTO \`${tbl('delegated_grants')}\` (id, scope_type, scope_id, grantee_id, granted_by)
     VALUES (?, 'blueprint', ?, ?, ?)`,
    [crypto.randomUUID(), blueprintId, granteeId, ADMIN.id],
  );
}

// ── CREATE: the gate this card adds ─────────────────────────────────────────

describe('editor POST hierarchy_nodes variant — parent-ownership gate (fmb-1993)', () => {
  test('under a blueprint owned by another editor, no grant → 403 PARENT_NOT_OWNED, no row', async (t) => {
    if (guard(t)) return;
    await seedHierarchy();
    const before = await countOf(`SELECT COUNT(*) AS n FROM \`${tbl('hierarchy_nodes')}\` WHERE node_type = 'variant'`);
    const res = await call(EDITOR, 'POST', '/edge/app/schema/hierarchy_nodes', {
      name: 'v1', node_type: 'variant', parent_id: BP_OTHER_OWNED,
    });
    assert.equal(res.status, 403, JSON.stringify(res.body));
    assert.equal(res.body.error.details.reason, 'parent_not_owned');
    assert.equal(
      await countOf(`SELECT COUNT(*) AS n FROM \`${tbl('hierarchy_nodes')}\` WHERE node_type = 'variant'`),
      before, 'a row was created despite the refusal',
    );
  });

  test('with a blueprint-scope grant to the editor → 200, stored owner_id is the BLUEPRINT owner, not the grantee', async (t) => {
    if (guard(t)) return;
    await seedHierarchy();
    await grantBlueprint(BP_OTHER_OWNED, EDITOR.id);
    const res = await call(EDITOR, 'POST', '/edge/app/schema/hierarchy_nodes', {
      name: 'v2', node_type: 'variant', parent_id: BP_OTHER_OWNED,
    });
    assert.equal(res.status, 200, JSON.stringify(res.body));
    const stored = await one(
      `SELECT owner_id FROM \`${tbl('hierarchy_nodes')}\` WHERE id = ?`, [res.body.data.id],
    );
    assert.equal(stored.owner_id, OTHER_EDITOR.id, 'inherit must still win — the grantee is not the stored owner');
  });

  test('grant present but the blueprint is shared (owner_id NULL) — dormant grant, admitted by the shared arm → 200, owner_id NULL', async (t) => {
    if (guard(t)) return;
    await seedHierarchy();
    await grantBlueprint(BP_SHARED, EDITOR.id);
    const res = await call(EDITOR, 'POST', '/edge/app/schema/hierarchy_nodes', {
      name: 'v3', node_type: 'variant', parent_id: BP_SHARED,
    });
    assert.equal(res.status, 200, JSON.stringify(res.body));
    const stored = await one(`SELECT owner_id FROM \`${tbl('hierarchy_nodes')}\` WHERE id = ?`, [res.body.data.id]);
    assert.equal(stored.owner_id, null);
  });

  test('editor owns the blueprint, no grant needed → 200, owner_id = the editor', async (t) => {
    if (guard(t)) return;
    await seedHierarchy();
    const res = await call(EDITOR, 'POST', '/edge/app/schema/hierarchy_nodes', {
      name: 'v4', node_type: 'variant', parent_id: BP_EDITOR_OWNED,
    });
    assert.equal(res.status, 200, JSON.stringify(res.body));
    const stored = await one(`SELECT owner_id FROM \`${tbl('hierarchy_nodes')}\` WHERE id = ?`, [res.body.data.id]);
    assert.equal(stored.owner_id, EDITOR.id);
  });

  test('blueprint shared, no grant at all → 200, owner_id NULL', async (t) => {
    if (guard(t)) return;
    await seedHierarchy();
    const res = await call(EDITOR, 'POST', '/edge/app/schema/hierarchy_nodes', {
      name: 'v5', node_type: 'variant', parent_id: BP_SHARED,
    });
    assert.equal(res.status, 200, JSON.stringify(res.body));
    const stored = await one(`SELECT owner_id FROM \`${tbl('hierarchy_nodes')}\` WHERE id = ?`, [res.body.data.id]);
    assert.equal(stored.owner_id, null);
  });

  test('admin under anyone\'s blueprint → 200, owner_id inherited from that blueprint (admin bypasses the gate, not the inherit)', async (t) => {
    if (guard(t)) return;
    await seedHierarchy();
    const res = await call(ADMIN, 'POST', '/edge/app/schema/hierarchy_nodes', {
      name: 'v6', node_type: 'variant', parent_id: BP_OTHER_OWNED,
    });
    assert.equal(res.status, 200, JSON.stringify(res.body));
    const stored = await one(`SELECT owner_id FROM \`${tbl('hierarchy_nodes')}\` WHERE id = ?`, [res.body.data.id]);
    assert.equal(stored.owner_id, OTHER_EDITOR.id);
  });

  test('parent_id absent → the factory\'s own PARENT_REQUIRED refusal (403, same helper PUT un-binding uses), no row', async (t) => {
    if (guard(t)) return;
    await seedHierarchy();
    const before = await countOf(`SELECT COUNT(*) AS n FROM \`${tbl('hierarchy_nodes')}\``);
    const res = await call(EDITOR, 'POST', '/edge/app/schema/hierarchy_nodes', {
      name: 'v7', node_type: 'variant',
    });
    assert.equal(res.status, 403, JSON.stringify(res.body));
    assert.equal(res.body.error.details.reason, 'parent_required');
    assert.equal(
      await countOf(`SELECT COUNT(*) AS n FROM \`${tbl('hierarchy_nodes')}\``), before,
      'a row was created with no parent named',
    );
  });

  test('parent_id null → same PARENT_REQUIRED refusal, no row', async (t) => {
    if (guard(t)) return;
    await seedHierarchy();
    const before = await countOf(`SELECT COUNT(*) AS n FROM \`${tbl('hierarchy_nodes')}\``);
    const res = await call(EDITOR, 'POST', '/edge/app/schema/hierarchy_nodes', {
      name: 'v8', node_type: 'variant', parent_id: null,
    });
    assert.equal(res.status, 403, JSON.stringify(res.body));
    assert.equal(res.body.error.details.reason, 'parent_required');
    assert.equal(
      await countOf(`SELECT COUNT(*) AS n FROM \`${tbl('hierarchy_nodes')}\``), before,
    );
  });

  test('parent_id names an admin-owned category — refused: the chain now re-asserts node_type=blueprint on the owner read, so a category cannot be a variant parent → 403 parent_not_owned, no row', async (t) => {
    if (guard(t)) return;
    await seedHierarchy();
    const before = await countOf(`SELECT COUNT(*) AS n FROM \`${tbl('hierarchy_nodes')}\``);
    const res = await call(EDITOR, 'POST', '/edge/app/schema/hierarchy_nodes', {
      name: 'v9', node_type: 'variant', parent_id: CATEGORY,
    });
    assert.equal(res.status, 403, JSON.stringify(res.body));
    assert.equal(res.body.error.details.reason, 'parent_not_owned');
    assert.equal(
      await countOf(`SELECT COUNT(*) AS n FROM \`${tbl('hierarchy_nodes')}\``), before,
    );
  });

  // fmb-1993 gate G3: the guard==written repro. A NULL-owner category read as
  // "shared" used to admit the create through checkParentOwnership's owner arm
  // (which had no node_type filter), while inheritOwnerFromParent's
  // blueprint-filtered lookup found nothing and stamped the EDITOR as owner —
  // guard value ("shared") differed from written value (the editor). The chain
  // SELECT now carries `AND node_type='blueprint'`, so a category matches 0 rows
  // and the create is refused before it can diverge. Revert probe: drop
  // parentNodeType from the mount and this flips to 200 with owner_id = the
  // editor (a stored row, not a status code).
  test('parent_id names a NULL-owner category (shared) — refused, NOT admitted-then-stamped-to-the-editor → 403 parent_not_owned, no row', async (t) => {
    if (guard(t)) return;
    await seedHierarchy();
    const before = await countOf(`SELECT COUNT(*) AS n FROM \`${tbl('hierarchy_nodes')}\` WHERE node_type = 'variant'`);
    const res = await call(EDITOR, 'POST', '/edge/app/schema/hierarchy_nodes', {
      name: 'v9b', node_type: 'variant', parent_id: CATEGORY_SHARED,
    });
    assert.equal(res.status, 403, JSON.stringify(res.body));
    assert.equal(res.body.error.details.reason, 'parent_not_owned');
    assert.equal(
      await countOf(`SELECT COUNT(*) AS n FROM \`${tbl('hierarchy_nodes')}\` WHERE node_type = 'variant'`),
      before, 'a variant was created under a category and stamped to the editor',
    );
  });
});

// ── REGRESSION: every node_type and verb the gate must leave untouched ──────

describe('fmb-1993 regression — every arm the new gate must not widen or break', () => {
  test('editor POST a blueprint under a top-tier node — unaffected (whenNodeType scopes the gate to variant only) → 200', async (t) => {
    if (guard(t)) return;
    await seedHierarchy();
    const res = await call(EDITOR, 'POST', '/edge/app/schema/hierarchy_nodes', {
      name: 'new bp', node_type: 'blueprint', parent_id: CATEGORY,
    });
    assert.equal(res.status, 200, JSON.stringify(res.body));
    const stored = await one(`SELECT owner_id FROM \`${tbl('hierarchy_nodes')}\` WHERE id = ?`, [res.body.data.id]);
    assert.equal(stored.owner_id, EDITOR.id, 'a blueprint create must still self-stamp the actor, not inherit');
  });

  test('editor PUT rename of their own blueprint — unaffected → 200, stored name changed', async (t) => {
    if (guard(t)) return;
    await seedHierarchy();
    const res = await call(EDITOR, 'PUT', `/edge/app/schema/hierarchy_nodes/${BP_EDITOR_OWNED}`, {
      name: 'renamed by owner',
    });
    assert.equal(res.status, 200, JSON.stringify(res.body));
    const stored = await one(`SELECT name FROM \`${tbl('hierarchy_nodes')}\` WHERE id = ?`, [BP_EDITOR_OWNED]);
    assert.equal(stored.name, 'renamed by owner');
  });

  test('editor PUT on a blueprint owned by another editor — unaffected: still the pre-existing 404 (existence-leak parity), not a new 403, and the row is untouched', async (t) => {
    if (guard(t)) return;
    await seedHierarchy();
    const res = await call(EDITOR, 'PUT', `/edge/app/schema/hierarchy_nodes/${BP_OTHER_OWNED}`, {
      name: 'hijacked',
    });
    assert.equal(res.status, 404, JSON.stringify(res.body));
    const stored = await one(`SELECT name FROM \`${tbl('hierarchy_nodes')}\` WHERE id = ?`, [BP_OTHER_OWNED]);
    assert.equal(stored.name, 'BP other-owned', 'the refused PUT changed the row');
  });

  test('editor DELETE of their own variant — unaffected (a fully separate custom route, not this diff) → 200', async (t) => {
    if (guard(t)) return;
    await seedHierarchy();
    const created = await call(EDITOR, 'POST', '/edge/app/schema/hierarchy_nodes', {
      name: 'own variant', node_type: 'variant', parent_id: BP_EDITOR_OWNED,
    });
    assert.equal(created.status, 200, JSON.stringify(created.body));
    const res = await call(EDITOR, 'DELETE', `/edge/app/schema/hierarchy_nodes/${created.body.data.id}`);
    assert.equal(res.status, 200, JSON.stringify(res.body));
    assert.equal(
      await countOf(`SELECT COUNT(*) AS n FROM \`${tbl('hierarchy_nodes')}\` WHERE id = ?`, [created.body.data.id]),
      0,
    );
  });

  test('editor DELETE of a blueprint owned by another editor — unaffected: still 403, same message', async (t) => {
    if (guard(t)) return;
    await seedHierarchy();
    const res = await call(EDITOR, 'DELETE', `/edge/app/schema/hierarchy_nodes/${BP_OTHER_OWNED}`);
    assert.equal(res.status, 403, JSON.stringify(res.body));
    assert.equal(res.body.error.message, 'You can only delete a blueprint you own');
    assert.equal(
      await countOf(`SELECT COUNT(*) AS n FROM \`${tbl('hierarchy_nodes')}\` WHERE id = ?`, [BP_OTHER_OWNED]), 1,
    );
  });
});

// ── The row this fix inherits owner_id from is the SAME row the gate reads ──

describe('guard value == written value — the gate reads the same row inherit stamps from', () => {
  // The create case: a create only reaches 200 when checkParentOwnership admits
  // it, and now BOTH its arms require a blueprint parent (owner arm: chain
  // SELECT filters node_type='blueprint'; grant arm: callerHasBlueprintGrant
  // re-asserts it). So a successful create's parent_id necessarily names a
  // blueprint — the identical row inherit's blueprint-filtered lookup reads.
  test('a grant-admitted create under an owned blueprint stores the blueprint owner (the gate and inherit read one row)', async (t) => {
    if (guard(t)) return;
    await seedHierarchy();
    const res = await call(EDITOR, 'POST', '/edge/app/schema/hierarchy_nodes', {
      name: 'v10', node_type: 'variant', parent_id: BP_EDITOR_OWNED,
    });
    assert.equal(res.status, 200, JSON.stringify(res.body));
    const stored = await one(`SELECT owner_id FROM \`${tbl('hierarchy_nodes')}\` WHERE id = ?`, [res.body.data.id]);
    assert.equal(stored.owner_id, EDITOR.id, 'inherit read a different row than the gate admitted through');
  });
});

// ── RENAME + DELETE of a variant under a granted blueprint (fmb-1993 gate G1) ──
//
// The two-path write family: a grantee may CREATE a variant under a granted
// blueprint, but the stored row's owner_id is the (foreign) blueprint owner, so
// the bare owner-scoped PUT/DELETE would 404/403 the very row they were allowed
// to create. buildPutScope's ownerColumn arm is widened for a variant with a
// grant; the custom DELETE route's mayActOnHierarchyNode grows the same grant
// arm. Every case reads the stored row/row-count, never a status code alone.

async function seedForeignVariant() {
  // Admin creates a variant under the other editor's blueprint; it inherits
  // that blueprint's owner (OTHER_EDITOR), exactly as a create by any actor does.
  const created = await call(ADMIN, 'POST', '/edge/app/schema/hierarchy_nodes', {
    name: 'foreign variant', node_type: 'variant', parent_id: BP_OTHER_OWNED,
  });
  assert.equal(created.status, 200, JSON.stringify(created.body));
  return created.body.data.id;
}

describe('fmb-1993 gate G1 — variant rename/delete join the blueprint-grant scope', () => {
  test('grantee PUT rename of a variant under a granted blueprint → 200, the name is stored', async (t) => {
    if (guard(t)) return;
    await seedHierarchy();
    const variantId = await seedForeignVariant();
    await grantBlueprint(BP_OTHER_OWNED, EDITOR.id);
    const res = await call(EDITOR, 'PUT', `/edge/app/schema/hierarchy_nodes/${variantId}`, {
      name: 'renamed by grantee',
    });
    assert.equal(res.status, 200, JSON.stringify(res.body));
    const stored = await one(`SELECT name, owner_id FROM \`${tbl('hierarchy_nodes')}\` WHERE id = ?`, [variantId]);
    assert.equal(stored.name, 'renamed by grantee');
    assert.equal(stored.owner_id, OTHER_EDITOR.id, 'rename must not change the inherited owner');
  });

  test('grantee DELETE of a variant under a granted blueprint → 200, the row is gone', async (t) => {
    if (guard(t)) return;
    await seedHierarchy();
    const variantId = await seedForeignVariant();
    await grantBlueprint(BP_OTHER_OWNED, EDITOR.id);
    const res = await call(EDITOR, 'DELETE', `/edge/app/schema/hierarchy_nodes/${variantId}`);
    assert.equal(res.status, 200, JSON.stringify(res.body));
    assert.equal(
      await countOf(`SELECT COUNT(*) AS n FROM \`${tbl('hierarchy_nodes')}\` WHERE id = ?`, [variantId]), 0,
    );
  });

  test('after the grant is revoked, the same grantee gets PUT 404 and DELETE 403 again, and the row is untouched', async (t) => {
    if (guard(t)) return;
    await seedHierarchy();
    const variantId = await seedForeignVariant();
    // No grant seeded (revoked = absent).
    const put = await call(EDITOR, 'PUT', `/edge/app/schema/hierarchy_nodes/${variantId}`, { name: 'hijacked' });
    assert.equal(put.status, 404, JSON.stringify(put.body));
    const del = await call(EDITOR, 'DELETE', `/edge/app/schema/hierarchy_nodes/${variantId}`);
    assert.equal(del.status, 403, JSON.stringify(del.body));
    assert.equal(del.body.error.message, 'You can only delete a blueprint you own');
    const stored = await one(`SELECT name FROM \`${tbl('hierarchy_nodes')}\` WHERE id = ?`, [variantId]);
    assert.equal(stored.name, 'foreign variant', 'a refused PUT/DELETE changed the row');
  });

  test('a grant does NOT let the grantee rename the BLUEPRINT itself → PUT 404, row untouched', async (t) => {
    if (guard(t)) return;
    await seedHierarchy();
    await grantBlueprint(BP_OTHER_OWNED, EDITOR.id);
    const res = await call(EDITOR, 'PUT', `/edge/app/schema/hierarchy_nodes/${BP_OTHER_OWNED}`, { name: 'hijacked bp' });
    assert.equal(res.status, 404, JSON.stringify(res.body));
    const stored = await one(`SELECT name FROM \`${tbl('hierarchy_nodes')}\` WHERE id = ?`, [BP_OTHER_OWNED]);
    assert.equal(stored.name, 'BP other-owned');
  });

  test('a grant does NOT let the grantee delete the BLUEPRINT itself → DELETE 403, row present', async (t) => {
    if (guard(t)) return;
    await seedHierarchy();
    await grantBlueprint(BP_OTHER_OWNED, EDITOR.id);
    const res = await call(EDITOR, 'DELETE', `/edge/app/schema/hierarchy_nodes/${BP_OTHER_OWNED}`);
    assert.equal(res.status, 403, JSON.stringify(res.body));
    assert.equal(res.body.error.message, 'You can only delete a blueprint you own');
    assert.equal(
      await countOf(`SELECT COUNT(*) AS n FROM \`${tbl('hierarchy_nodes')}\` WHERE id = ?`, [BP_OTHER_OWNED]), 1,
    );
  });

  test('a plain editor with NO grant still gets PUT 404 / DELETE 403 on a foreign variant, row untouched', async (t) => {
    if (guard(t)) return;
    await seedHierarchy();
    const variantId = await seedForeignVariant();
    const put = await call(OTHER_EDITOR_NO_GRANT, 'PUT', `/edge/app/schema/hierarchy_nodes/${variantId}`, { name: 'x' });
    assert.equal(put.status, 404, JSON.stringify(put.body));
    const del = await call(OTHER_EDITOR_NO_GRANT, 'DELETE', `/edge/app/schema/hierarchy_nodes/${variantId}`);
    assert.equal(del.status, 403, JSON.stringify(del.body));
    const stored = await one(`SELECT name FROM \`${tbl('hierarchy_nodes')}\` WHERE id = ?`, [variantId]);
    assert.equal(stored.name, 'foreign variant');
  });

  test('dormant: a variant under a SHARED blueprint (owner NULL) is renamable/deletable by any editor with no grant (shared arm) → 200', async (t) => {
    if (guard(t)) return;
    await seedHierarchy();
    // Admin creates a variant under the shared blueprint → owner_id NULL.
    const created = await call(ADMIN, 'POST', '/edge/app/schema/hierarchy_nodes', {
      name: 'shared variant', node_type: 'variant', parent_id: BP_SHARED,
    });
    assert.equal(created.status, 200, JSON.stringify(created.body));
    const variantId = created.body.data.id;
    const stored0 = await one(`SELECT owner_id FROM \`${tbl('hierarchy_nodes')}\` WHERE id = ?`, [variantId]);
    assert.equal(stored0.owner_id, null, 'a variant under a shared blueprint must be shared');
    const put = await call(EDITOR, 'PUT', `/edge/app/schema/hierarchy_nodes/${variantId}`, { name: 'renamed shared' });
    assert.equal(put.status, 200, JSON.stringify(put.body));
    const stored1 = await one(`SELECT name FROM \`${tbl('hierarchy_nodes')}\` WHERE id = ?`, [variantId]);
    assert.equal(stored1.name, 'renamed shared');
    const del = await call(EDITOR, 'DELETE', `/edge/app/schema/hierarchy_nodes/${variantId}`);
    assert.equal(del.status, 200, JSON.stringify(del.body));
    assert.equal(
      await countOf(`SELECT COUNT(*) AS n FROM \`${tbl('hierarchy_nodes')}\` WHERE id = ?`, [variantId]), 0,
    );
  });
});
