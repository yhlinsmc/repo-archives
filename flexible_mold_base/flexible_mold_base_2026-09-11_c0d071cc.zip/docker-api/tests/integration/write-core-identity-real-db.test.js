'use strict';

/**
 * write-core-identity-real-db.test.js — the shared write core, against a real
 * database, reading the stored rows back.
 *
 * WHY A REAL DATABASE IS THE ONLY INSTRUMENT THAT SETTLES THESE. Every row this
 * file covers is a claim about which rows a statement matched, and a mocked
 * driver answers that question with whatever the fixture was told to say — which
 * is how the previous defects of this family survived review. So each case here
 * asserts a STORED VALUE or a ROW COUNT, never only a status code:
 *
 *   rank 3  — a numeric `recipe_id` used to resolve the parent a guard is decided
 *             about, then bound into an UPDATE that clears approval on every row
 *             the coercion matched.
 *   rank 9  — the decision-output guard reading the BODY's blueprint while the
 *             UPDATE writes the row's stored one.
 *   rank 10 — a numeric `blueprint_id` on a delegated write, where the arm that
 *             refuses a move is a SQL `<=>` that folds string against number.
 *   rank 11 — a numeric parent FK resolving an arbitrary blueprint on create.
 *   rank 16 — the variant owner inherited from a parent resolved the same way.
 *   rank 17 — the linked-blueprint guard answering about a coerced row.
 *   rank 24 — a server-owned column accepted on create because the strip was
 *             written for the update path only.
 *   rank 32 — a value trimmed to be judged and stored untrimmed.
 *   rank 54 — a hook rewriting a guarded column after every gate has run.
 *
 * Skips with a stated reason when no database is reachable, and FAILS instead of
 * skipping when REQUIRE_INTEGRATION_DB=1 — a silent skip is the failure mode this
 * whole line of work exists to end.
 */
const { test, describe, before, after, beforeEach } = require('node:test');
const { makeStubReqLog } = require('../helpers/stub-req-log');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const net = require('node:net');
const http = require('node:http');
const express = require('express');
const mariadb = require('mariadb');

const TEST_PREFIX = 'wci_';
const tbl = (name) => `${TEST_PREFIX}${name}`;

let pool = null;
const lease = () => pool.getConnection();

const dbKey = require.resolve('../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey,
  filename: dbKey,
  loaded: true,
  exports: {
    pool: { ro: { getConnection: lease }, rw: { getConnection: lease } },
    t: tbl,
    getDynamicPool: async () => ({ ro: { getConnection: lease }, rw: { getConnection: lease } }),
  },
};

const { buildEngineTableDDLs, buildInfraTableDDLs } = require('../../src/table-ddls');
const schemaRouter = require('../../src/edge/routes/app/schema');
const { createCrudRoutes } = require('../../src/edge/routes/app/schema');
const stepsRouter = require('../../src/edge/routes/app/flow-recipe-steps');
const { enumMembersFor } = require('../../src/edge/lib/schema-manifest');
const { TABLES } = require('../../src/shared/constants');
const { fixtureUserId } = require('../helpers/fixture-ids');

// ── Config auto-detection (same shape as the sibling integration tests) ──────

function parseEnvFile(filePath) {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    const out = {};
    for (const line of content.split('\n')) {
      const m = line.match(/^\s*([A-Z_][A-Z0-9_]*)\s*=\s*(.*)\s*$/);
      if (!m) continue;
      let value = m[2];
      if ((value.startsWith('"') && value.endsWith('"'))
        || (value.startsWith("'") && value.endsWith("'"))) {
        value = value.slice(1, -1);
      }
      out[m[1]] = value;
    }
    return out;
  } catch {
    return null;
  }
}

function probePort(host, port, timeoutMs = 2000) {
  return new Promise((resolve) => {
    const socket = new net.Socket();
    let done = false;
    const finish = (ok) => {
      if (done) return;
      done = true;
      socket.destroy();
      resolve(ok);
    };
    socket.setTimeout(timeoutMs);
    socket.once('connect', () => finish(true));
    socket.once('timeout', () => finish(false));
    socket.once('error', () => finish(false));
    socket.connect(port, host);
  });
}

async function resolveMariaDbConfig() {
  if (process.env.DB_TEST_HOST && process.env.DB_TEST_ROOT_PASSWORD) {
    return {
      host: process.env.DB_TEST_HOST,
      port: parseInt(process.env.DB_TEST_PORT || '3306', 10),
      user: 'root',
      password: process.env.DB_TEST_ROOT_PASSWORD,
    };
  }
  const envPath = path.resolve(__dirname, '../../../.devcontainer/.env');
  const env = parseEnvFile(envPath);
  if (!env || !env.DB_ROOT_PASSWORD) return null;
  const port = parseInt(env.DB_PORT || '3306', 10);
  for (const host of ['127.0.0.1', 'mariadb', 'localhost']) {
    if (await probePort(host, port, 2000)) {
      return { host, port, user: 'root', password: env.DB_ROOT_PASSWORD };
    }
  }
  return null;
}

// ── Fixture ─────────────────────────────────────────────────────────────────

const ADMIN = { id: fixtureUserId('admin'), role: 'admin' };
const EDITOR = { id: fixtureUserId('editor'), role: 'editor' };
const OTHER_EDITOR = { id: '2af146d0-081f-4869-8a8f-3bf248676df8', role: 'editor' };
const USER = { id: fixtureUserId('user'), role: 'user' };

// Blueprint ids chosen so the numeric coercion measured in
// db-experiments-1500-round2.md D1 really does match them: MariaDB converts a
// CHAR column to a number with leading-digit semantics, so a uuid whose first
// character is `0` or a letter converts to 0 and `WHERE id = 0` matches it.
const BP_LEADING_ZERO = '0f3e1c22-aaaa-bbbb-cccc-000000000003';
const BP_LEADING_LETTER = 'af3e1c22-aaaa-bbbb-cccc-000000000002';
const OTHER_BP = 'bd3e1c22-aaaa-bbbb-cccc-000000000007';

let dbReady = false;
let skipReason = null;
let testDbName = null;
let server = null;
let baseUrl = null;
let currentUser = ADMIN;

before(async () => {
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) {
    skipReason = 'no MariaDB reachable via .devcontainer/.env or env vars';
    if (process.env.REQUIRE_INTEGRATION_DB === '1') {
      throw new Error(`REQUIRE_INTEGRATION_DB=1 set but ${skipReason}.`);
    }
    return;
  }
  testDbName = `write_core_test_${process.pid}_${Date.now()}`;
  let admin = null;
  try {
    admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`CREATE DATABASE \`${testDbName}\``);
    await admin.query(`USE \`${testDbName}\``);
    // Every engine table, built from the DDL that creates the real ones — a
    // hand-picked subset drops a table some guard probes and turns its refusal
    // into a degrade nobody asked for.
    for (const sql of [...buildInfraTableDDLs(tbl), ...buildEngineTableDDLs(tbl)]) {
      await admin.query(sql);
    }
    await admin.end();
    admin = null;

    pool = mariadb.createPool({
      ...dbConfig, database: testDbName, connectionLimit: 6, connectTimeout: 5000,
    });

    const app = express();
    app.use((req, _res, next) => { req.log = makeStubReqLog(); next(); }); // TEST-ONLY: production always sets req.log via createRequestId (request-id.js) before any router; this bare app has no such middleware, so a route's req.log.<level>() call would otherwise throw against undefined.
    app.use(express.json());
    app.use((req, _res, next) => { req.user = currentUser; next(); });
    app.use('/edge/app/schema', schemaRouter);
    app.use('/edge/app/flow-recipe-steps', stepsRouter);
    // A mount of this repository's own factory whose create transform rewrites a
    // guarded column after every gate has run — the shape rank 54 says nothing
    // prevents. It exists only here because no serializer in the tree does it
    // today, and the point is that one cannot start.
    app.use('/edge/test/rewriting-mount', createCrudRoutes('hierarchy_nodes', {
      allowedRoles: ['admin', 'editor'],
      valueGuards: { node_type: { rejectFor: { editor: ['category', 'release'] } } },
      enumColumns: { node_type: enumMembersFor(TABLES.HIERARCHY_NODES, 'node_type') },
      ownerColumn: 'owner_id',
      transformCreateInTx: async (_conn, _req, data) => ({ ...data, node_type: 'category' }),
    }));
    server = http.createServer(app);
    await new Promise((r) => server.listen(0, r));
    baseUrl = `http://127.0.0.1:${server.address().port}`;
    dbReady = true;
  } catch (err) {
    skipReason = `setup failed: ${err.message}`;
    if (admin) { try { await admin.end(); } catch { /* best effort */ } }
    if (process.env.REQUIRE_INTEGRATION_DB === '1') throw err;
  }
});

after(async () => {
  if (server) { try { server.close(); } catch { /* best effort */ } }
  if (pool) { try { await pool.end(); } catch { /* best effort */ } }
  if (!testDbName) return;
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) return;
  try {
    const admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`DROP DATABASE IF EXISTS \`${testDbName}\``);
    await admin.end();
  } catch { /* best effort */ }
});

async function call(user, method, url, body) {
  currentUser = user;
  const res = await fetch(`${baseUrl}${url}`, {
    method,
    headers: { 'content-type': 'application/json' },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const text = await res.text();
  let parsed = null;
  try { parsed = JSON.parse(text); } catch { parsed = { raw: text }; }
  return { status: res.status, body: parsed };
}

const rows = (sql, params) => pool.query(sql, params);
const one = async (sql, params) => (await pool.query(sql, params))[0];
const countOf = async (sql, params) => Number((await one(sql, params)).n);

const guard = (t) => {
  if (!dbReady) { t.skip(skipReason || 'database not ready'); return true; }
  return false;
};

/** Clear every table this file writes to, so each case states its own pre-state. */
beforeEach(async () => {
  if (!dbReady) return;
  for (const name of ['flow_recipe_steps', 'flow_recipes', 'field_options', 'blueprint_fields', 'blueprint_sections',
    'decision_tables', 'user_templates', 'delegated_grants', 'hierarchy_nodes', 'feature_audit',
    'template_activity']) {
    await pool.query(`DELETE FROM \`${tbl(name)}\``);
  }
});

async function seedBlueprints() {
  for (const [id, owner] of [[BP_LEADING_ZERO, EDITOR.id], [BP_LEADING_LETTER, null],
    [OTHER_BP, OTHER_EDITOR.id]]) {
    await pool.query(
      `INSERT INTO \`${tbl('hierarchy_nodes')}\` (id, name, node_type, owner_id) VALUES (?, ?, 'blueprint', ?)`,
      [id, `bp-${id.slice(0, 4)}`, owner],
    );
  }
}

// ── rank 3 — the whole-table approval wipe from one editor POST ──────────────

describe('a numeric parent id on a child create', () => {
  const RECIPES = [
    ['0a1b2c33-1111-4111-8111-000000000001', 'leading digit zero'],
    ['aa1b2c33-1111-4111-8111-000000000002', 'leading letter'],
  ];

  async function seedApprovedRecipes() {
    await seedBlueprints();
    for (const [id, name] of RECIPES) {
      await pool.query(
        `INSERT INTO \`${tbl('flow_recipes')}\`
           (id, name, owner_id, blueprint_id, status, approved_by, approved_at)
         VALUES (?, ?, ?, ?, 'approved', ?, NOW())`,
        [id, name, EDITOR.id, BP_LEADING_ZERO, ADMIN.id],
      );
    }
  }

  test('the premise: these ids are exactly the rows a numeric bind matches', async (t) => {
    if (guard(t)) return;
    // MEASURED HERE, not assumed, and measured through the same driver the
    // server uses: `WHERE id = ?` with a JS number is sent as a NUMERIC bind and
    // the CHAR(36) side is converted with leading-digit semantics. If a future
    // driver or server release stops doing this, this assertion says so — next
    // to the refusal that exists because of it.
    await seedApprovedRecipes();
    const matched = await rows(`SELECT id FROM \`${tbl('flow_recipes')}\` WHERE id = ?`, [0]);
    assert.equal(
      matched.length, RECIPES.length,
      'this database no longer matches a uuid column against a numeric 0',
    );
  });

  test('the premise, second half: which statements this server\'s sql_mode lets through', async (t) => {
    if (guard(t)) return;
    // WHERE THE ENGINE HELPS AND WHERE IT DOES NOT, measured rather than assumed,
    // because it decides what "the floor prevents" actually means here.
    //
    // Under the deployed strict sql_mode the truncation the coercion produces is
    // escalated to an ERROR for an UPDATE (1292) — so the approval wipe this
    // family is named for is refused by the engine and the transaction rolls
    // back. It is NOT escalated for a DELETE: the same predicate deletes every
    // row it matched, with only a warning. And a deployment running a permissive
    // sql_mode gets neither escalation, which is why the mode itself is a
    // deployment fact worth asserting at boot rather than a CI rule.
    //
    // So the floor's value on THIS statement is a stable 400 instead of a 500
    // plus a FOR UPDATE lock taken on every row the coercion matched; on the
    // DELETE-shaped members of the same family it is the difference between a
    // refusal and rows that are gone.
    await seedApprovedRecipes();
    let updateError = null;
    try {
      await pool.query(`UPDATE \`${tbl('flow_recipes')}\` SET status = 'pending' WHERE id = ?`, [0]);
    } catch (err) {
      updateError = err;
    }
    assert.ok(updateError, 'this server no longer refuses the coerced UPDATE — the wipe is live again');
    assert.equal(updateError.errno, 1292);
    assert.equal(
      await countOf(`SELECT COUNT(*) AS n FROM \`${tbl('flow_recipes')}\` WHERE status = 'approved'`),
      2, 'the refused UPDATE still changed rows',
    );

    const deleted = await pool.query(`DELETE FROM \`${tbl('flow_recipes')}\` WHERE id = ?`, [0]);
    assert.equal(
      Number(deleted.affectedRows), 2,
      'a coerced DELETE no longer matches the rows the coercion resolves',
    );
  });

  test('is refused, and every parent recipe keeps its approval', async (t) => {
    if (guard(t)) return;
    await seedApprovedRecipes();
    // THE PRE-STATE, ASSERTED FIRST: a destructive test that never establishes
    // what it is protecting proves nothing when the write is a no-op for an
    // unrelated reason.
    assert.equal(
      await countOf(`SELECT COUNT(*) AS n FROM \`${tbl('flow_recipes')}\` WHERE status = 'approved'`),
      2, 'the fixture did not create the approved recipes',
    );

    const res = await call(EDITOR, 'POST', '/edge/app/flow-recipe-steps/', {
      recipe_id: 0, name: 'step', url: 'https://svc.invalid/x', method: 'GET', step_type: 'api',
    });
    assert.equal(res.status, 400, `expected a refusal, got ${JSON.stringify(res.body)}`);
    assert.equal(res.body.error.code, 'INVALID_ID_FORMAT');

    // THE STORED STATE, not just the status code. On the deployed sql_mode the
    // engine also refuses this particular UPDATE (see the premise case above), so
    // these three assertions are what holds on a deployment whose sql_mode does
    // not — and the status assertion above is what holds on this one. The
    // sibling cases below, where the coerced id reaches an INSERT rather than an
    // UPDATE, go red on the stored row on every sql_mode.
    assert.equal(
      await countOf(`SELECT COUNT(*) AS n FROM \`${tbl('flow_recipes')}\` WHERE status = 'approved'`),
      2, 'a refused create still wiped the approvals',
    );
    assert.equal(
      await countOf(`SELECT COUNT(*) AS n FROM \`${tbl('flow_recipes')}\` WHERE approved_by IS NULL`),
      0, 'a refused create still cleared the approver',
    );
    assert.equal(
      await countOf(`SELECT COUNT(*) AS n FROM \`${tbl('flow_recipe_steps')}\``),
      0, 'the refused create left a step behind',
    );
  });

  test('a legitimate create still lands and still re-pends its own parent', async (t) => {
    if (guard(t)) return;
    // The control: the refusal must not be the feature. A step created under a
    // real recipe id still writes, and the parent's approval is still cleared —
    // which is what the guard the numeric id walked past exists to do.
    await seedApprovedRecipes();
    const res = await call(EDITOR, 'POST', '/edge/app/flow-recipe-steps/', {
      recipe_id: RECIPES[0][0], name: 'step', url: 'https://svc.invalid/x', method: 'GET', step_type: 'api',
    });
    assert.equal(res.status, 200, `a legitimate create was refused: ${JSON.stringify(res.body)}`);
    const stored = await one(
      `SELECT recipe_id FROM \`${tbl('flow_recipe_steps')}\` WHERE name = 'step'`,
    );
    assert.equal(stored.recipe_id, RECIPES[0][0]);
    const parent = await one(
      `SELECT status, approved_by FROM \`${tbl('flow_recipes')}\` WHERE id = ?`, [RECIPES[0][0]],
    );
    assert.equal(parent.status, 'pending', 'the parent recipe was not re-pended');
    assert.equal(parent.approved_by, null);
    const untouched = await one(
      `SELECT status FROM \`${tbl('flow_recipes')}\` WHERE id = ?`, [RECIPES[1][0]],
    );
    assert.equal(untouched.status, 'approved', 'a sibling recipe was re-pended too');
  });
});

// ── ranks 11, 16, 17 — a numeric FK resolving the row a guard judges ─────────

describe('a numeric parent id on the schema mounts', () => {
  test('a blueprint_fields create naming a numeric blueprint stores nothing', async (t) => {
    if (guard(t)) return;
    await seedBlueprints();
    assert.equal(await countOf(`SELECT COUNT(*) AS n FROM \`${tbl('blueprint_fields')}\``), 0);

    const res = await call(EDITOR, 'POST', '/edge/app/schema/blueprint_fields', {
      blueprint_id: 0, field_key: 'city', field_label: 'City', field_type: 'text',
    });
    // The stored state is asserted BEFORE the status code, so that removing the
    // floor turns this case red on a row that exists rather than on a number.
    assert.equal(
      await countOf(`SELECT COUNT(*) AS n FROM \`${tbl('blueprint_fields')}\``), 0,
      'a field was created under whichever blueprint the coercion matched',
    );
    assert.equal(res.status, 400, `expected a refusal, got ${JSON.stringify(res.body)}`);
  });

  test('a variant create naming a numeric parent inherits nobody', async (t) => {
    if (guard(t)) return;
    // The parent lookup resolved an arbitrary blueprint and took ITS owner. The
    // blueprint the coercion reaches here is the SHARED one (owner NULL), so the
    // editor's own node would have landed shared — editable by every editor.
    await seedBlueprints();
    const before = await countOf(`SELECT COUNT(*) AS n FROM \`${tbl('hierarchy_nodes')}\``);

    const res = await call(EDITOR, 'POST', '/edge/app/schema/hierarchy_nodes', {
      name: 'variant', node_type: 'variant', parent_id: 0,
    });
    assert.equal(
      await countOf(`SELECT COUNT(*) AS n FROM \`${tbl('hierarchy_nodes')}\``), before,
      'a node was created from a coerced parent id',
    );
    assert.equal(
      await countOf(`SELECT COUNT(*) AS n FROM \`${tbl('hierarchy_nodes')}\` WHERE node_type = 'variant'`),
      0, 'a variant landed with an inherited owner nobody chose',
    );
    assert.equal(res.status, 400, `expected a refusal, got ${JSON.stringify(res.body)}`);
  });

  test('the linked-blueprint guard is never asked about a coerced row', async (t) => {
    if (guard(t)) return;
    // The stored-row branch of that guard is correct by construction; only the
    // BODY branch was exposed, and it fails in both directions — admitting a
    // write onto a linked parent, and refusing a legitimate one. Neither can be
    // reached now, because the value never becomes a query.
    await seedBlueprints();
    await pool.query(
      `UPDATE \`${tbl('hierarchy_nodes')}\` SET linked_blueprint_id = ? WHERE id = ?`,
      [OTHER_BP, BP_LEADING_LETTER],
    );
    const res = await call(ADMIN, 'POST', '/edge/app/schema/blueprint_sections', {
      blueprint_id: 0, section_key: 'general', display_label: 'General', sort_order: 0,
    });
    assert.equal(
      await countOf(`SELECT COUNT(*) AS n FROM \`${tbl('blueprint_sections')}\``), 0,
      'a section was written under whichever blueprint the coercion matched',
    );
    assert.equal(res.status, 400, `expected a refusal, got ${JSON.stringify(res.body)}`);
    assert.equal(res.body.error.code, 'INVALID_ID_FORMAT');
  });
});

// ── the floor's declared exemption — a CHAR(36) column that is not a row id ──

describe('a hierarchy node bound to a file-based transformer', () => {
  // What `registerTransformer('example', …)` puts in the registry, and what the
  // hierarchy picker sends for a [File] entry: the module's own key, not a row
  // id. The whole file half of that registry is author-chosen short strings.
  const FILE_TRANSFORMER = 'example';

  test('is created carrying the registry key the picker offered', async (t) => {
    if (guard(t)) return;
    const res = await call(ADMIN, 'POST', '/edge/app/schema/hierarchy_nodes', {
      name: 'file-transformer blueprint', node_type: 'blueprint',
      transformer_id: FILE_TRANSFORMER,
    });
    const stored = await one(
      `SELECT transformer_id FROM \`${tbl('hierarchy_nodes')}\` WHERE name = 'file-transformer blueprint'`,
    );
    assert.equal(
      stored && stored.transformer_id, FILE_TRANSFORMER,
      'the file-transformer binding never reached the row',
    );
    assert.equal(res.status, 200, `the create was refused: ${JSON.stringify(res.body)}`);
  });

  test('can still be renamed while the dialog echoes that key back', async (t) => {
    if (guard(t)) return;
    // The worse half. The hierarchy dialog seeds its form from the stored row
    // and emits transformer_id on EVERY save, so a shape check on this column
    // does not merely block the create — it makes every existing node bound to
    // a file transformer permanently uneditable, down to renaming it.
    const created = await call(ADMIN, 'POST', '/edge/app/schema/hierarchy_nodes', {
      name: 'before', node_type: 'blueprint', transformer_id: FILE_TRANSFORMER,
    });
    assert.equal(created.status, 200, JSON.stringify(created.body));
    const id = created.body.data.id;

    const res = await call(ADMIN, 'PUT', `/edge/app/schema/hierarchy_nodes/${id}`, {
      name: 'after', node_type: 'blueprint', description: null, is_active: true,
      transformer_id: FILE_TRANSFORMER, transformer_version: null,
      linked_blueprint_id: null,
    });
    const stored = await one(
      `SELECT name, transformer_id FROM \`${tbl('hierarchy_nodes')}\` WHERE id = ?`, [id],
    );
    assert.equal(stored.name, 'after', 'the rename was refused because of a column it did not change');
    assert.equal(stored.transformer_id, FILE_TRANSFORMER);
    assert.equal(res.status, 200, `the rename was refused: ${JSON.stringify(res.body)}`);
  });

  test('and the exemption is one column, not the mount', async (t) => {
    if (guard(t)) return;
    // The control beside it: declaring transformer_id must not switch the floor
    // off for the mount's real row-id columns.
    await seedBlueprints();
    const before = await countOf(`SELECT COUNT(*) AS n FROM \`${tbl('hierarchy_nodes')}\``);
    const res = await call(ADMIN, 'POST', '/edge/app/schema/hierarchy_nodes', {
      name: 'variant', node_type: 'variant', parent_id: 0,
    });
    assert.equal(
      await countOf(`SELECT COUNT(*) AS n FROM \`${tbl('hierarchy_nodes')}\``), before,
      'a node was created from a coerced parent id',
    );
    assert.equal(res.status, 400, `expected a refusal, got ${JSON.stringify(res.body)}`);
    assert.equal(res.body.error.code, 'INVALID_ID_FORMAT');
  });
});

// ── rank 10 — the delegated write that may not move its own subject ──────────

describe('a delegated write carrying a numeric blueprint id', () => {
  const TEMPLATE_ID = 'c1d2e3f4-1111-4111-8111-00000000000a';

  async function seedDelegatedTemplate() {
    await seedBlueprints();
    await pool.query(
      `INSERT INTO \`${tbl('user_templates')}\` (id, name, owner_id, blueprint_id)
       VALUES (?, 'delegated record', ?, ?)`,
      [TEMPLATE_ID, OTHER_EDITOR.id, BP_LEADING_ZERO],
    );
    await pool.query(
      `INSERT INTO \`${tbl('delegated_grants')}\`
         (id, scope_type, scope_id, grantee_id, granted_by)
       VALUES (UUID(), 'template', ?, ?, ?)`,
      [TEMPLATE_ID, EDITOR.id, OTHER_EDITOR.id],
    );
  }

  test('cannot carry the record out from under the blueprint that delegated it', async (t) => {
    if (guard(t)) return;
    await seedDelegatedTemplate();
    // The arm that refuses a move is a SQL `<=>`, which folds a string against a
    // number: for a blueprint uuid the coercion matches, the engine answered
    // "not moving" and the SET clause stored the caller's literal.
    const res = await call(EDITOR, 'PUT', `/edge/app/schema/user_templates/${TEMPLATE_ID}`, {
      name: 'edited by the grantee', blueprint_id: 0,
    });
    assert.equal(res.status, 400, `expected a refusal, got ${JSON.stringify(res.body)}`);

    const stored = await one(
      `SELECT blueprint_id, name FROM \`${tbl('user_templates')}\` WHERE id = ?`, [TEMPLATE_ID],
    );
    assert.equal(stored.blueprint_id, BP_LEADING_ZERO, 'the record was moved out from under its blueprint');
    assert.equal(stored.name, 'delegated record', 'a refused update still wrote the other columns');
  });

  test('a delegated edit that leaves the blueprint alone still lands', async (t) => {
    if (guard(t)) return;
    // The control: delegation still works. Refusing every delegated write would
    // satisfy the case above and remove the feature.
    await seedDelegatedTemplate();
    const res = await call(EDITOR, 'PUT', `/edge/app/schema/user_templates/${TEMPLATE_ID}`, {
      name: 'edited by the grantee',
    });
    assert.equal(res.status, 200, `a legitimate delegated edit was refused: ${JSON.stringify(res.body)}`);
    const stored = await one(
      `SELECT blueprint_id, name FROM \`${tbl('user_templates')}\` WHERE id = ?`, [TEMPLATE_ID],
    );
    assert.equal(stored.name, 'edited by the grantee');
    assert.equal(stored.blueprint_id, BP_LEADING_ZERO);
  });
});

// ── rank 24 — the strip that ran on one verb ─────────────────────────────────

describe('a column the server owns', () => {
  test('is not accepted from a plain user on create', async (t) => {
    if (guard(t)) return;
    // Measured live before this change: a plain user POSTed a record already
    // carrying a `flow_last_run_id` and a `flow_link` of their choosing and the
    // row stored both, while the PUT of the same two values was stripped.
    // Clearing the run marker turns the OWNER's next dispatch into a create, and
    // a dispatch cannot be taken back.
    await seedBlueprints();
    const res = await call(USER, 'POST', '/edge/app/schema/user_templates', {
      name: 'forged',
      blueprint_id: BP_LEADING_ZERO,
      flow_last_run_id: '11111111-1111-4111-8111-111111111111',
      flow_link: 'https://example.invalid/forged',
    });
    assert.equal(res.status, 200, `the create was refused outright: ${JSON.stringify(res.body)}`);

    const stored = await one(
      `SELECT flow_last_run_id, flow_link, owner_id FROM \`${tbl('user_templates')}\` WHERE name = 'forged'`,
    );
    assert.equal(stored.flow_last_run_id, null, 'a caller chose the record\'s run marker');
    assert.equal(stored.flow_link, null, 'a caller chose the record\'s flow link');
    assert.equal(stored.owner_id, USER.id, 'the create stopped stamping the owner');
  });

  test('is not accepted on update either', async (t) => {
    if (guard(t)) return;
    // The half that already held, kept beside the new one: closing the create
    // path must not be a way of opening the update path.
    await seedBlueprints();
    const created = await call(USER, 'POST', '/edge/app/schema/user_templates', {
      name: 'own record', blueprint_id: BP_LEADING_ZERO,
    });
    assert.equal(created.status, 200, JSON.stringify(created.body));
    const id = created.body.data.id;
    await pool.query(
      `UPDATE \`${tbl('user_templates')}\` SET flow_last_run_id = ? WHERE id = ?`,
      ['22222222-2222-4222-8222-222222222222', id],
    );

    const res = await call(USER, 'PUT', `/edge/app/schema/user_templates/${id}`, {
      name: 'renamed', flow_last_run_id: '33333333-3333-4333-8333-333333333333',
    });
    assert.equal(res.status, 200, JSON.stringify(res.body));
    const stored = await one(
      `SELECT name, flow_last_run_id FROM \`${tbl('user_templates')}\` WHERE id = ?`, [id],
    );
    assert.equal(stored.name, 'renamed', 'the legitimate half of the update was dropped');
    assert.equal(
      stored.flow_last_run_id, '22222222-2222-4222-8222-222222222222',
      'the update rewrote the run marker',
    );
  });
});

// ── rank 32 — trimmed to be judged, stored untrimmed ─────────────────────────

describe('a value a rule trimmed to judge', () => {
  test('is stored trimmed by the generic create', async (t) => {
    if (guard(t)) return;
    await seedBlueprints();
    const field = await call(EDITOR, 'POST', '/edge/app/schema/blueprint_fields', {
      blueprint_id: BP_LEADING_ZERO, field_key: 'city', field_label: 'City', field_type: 'select',
    });
    assert.equal(field.status, 200, JSON.stringify(field.body));

    const res = await call(EDITOR, 'POST', '/edge/app/schema/field_options', {
      field_id: field.body.data.id, option_label: '  Fitting  ', option_value: '  fitting  ',
    });
    assert.equal(res.status, 200, JSON.stringify(res.body));

    const stored = await one(
      `SELECT option_label, option_value, LENGTH(option_value) AS len
         FROM \`${tbl('field_options')}\` WHERE field_id = ?`, [field.body.data.id],
    );
    // LENGTH, not just equality: the collation pads a trailing space away when
    // comparing, so `option_value = 'fitting'` would pass on the untrimmed row
    // too. The bytes are the assertion.
    assert.equal(stored.option_value, 'fitting');
    assert.equal(stored.len, 'fitting'.length, 'the stored value still carries its spaces');
    assert.equal(stored.option_label, 'Fitting');
  });

  test('is stored trimmed by the options replace endpoint too', async (t) => {
    if (guard(t)) return;
    // The mount declares the rule and this endpoint builds its own statements —
    // one column, one answer.
    await seedBlueprints();
    const field = await call(EDITOR, 'POST', '/edge/app/schema/blueprint_fields', {
      blueprint_id: BP_LEADING_ZERO, field_key: 'colour', field_label: 'Colour', field_type: 'checkbox',
    });
    assert.equal(field.status, 200, JSON.stringify(field.body));

    const res = await call(EDITOR, 'POST', '/edge/app/schema/field_options/replace', {
      field_id: field.body.data.id,
      expected: [],
      next: [{ option_label: ' Red ', option_value: ' red ', sort_order: 0 }],
    });
    assert.equal(res.status, 200, JSON.stringify(res.body));
    const stored = await one(
      `SELECT option_value, LENGTH(option_value) AS len FROM \`${tbl('field_options')}\` WHERE field_id = ?`,
      [field.body.data.id],
    );
    assert.equal(stored.option_value, 'red');
    assert.equal(stored.len, 3, 'the stored option value still carries its spaces');
  });

  test('is stored trimmed on a decision table name and inside its document', async (t) => {
    if (guard(t)) return;
    await seedBlueprints();
    const res = await call(EDITOR, 'POST', '/edge/app/schema/decision_tables', {
      blueprint_id: BP_LEADING_ZERO,
      name: '  Part lookup  ',
      doc: {
        conditions: [{ field_key: ' material ' }],
        outputs: [{ field_key: 'part_no' }],
        rows: [{ when: { ' material ': 'steel' }, then: { part_no: 'P-1' } }],
      },
    });
    assert.equal(res.status, 200, JSON.stringify(res.body));
    const stored = await one(
      `SELECT name, LENGTH(name) AS len, doc FROM \`${tbl('decision_tables')}\` WHERE blueprint_id = ?`,
      [BP_LEADING_ZERO],
    );
    assert.equal(stored.name, 'Part lookup');
    assert.equal(stored.len, 'Part lookup'.length, 'the stored name still carries its spaces');
    const doc = typeof stored.doc === 'string' ? JSON.parse(stored.doc) : stored.doc;
    assert.deepEqual(doc.conditions, [{ field_key: 'material' }]);
    assert.deepEqual(doc.rows, [{ when: { material: 'steel' }, then: { part_no: 'P-1' } }]);
  });
});

// ── rank 9 — the hook that resolved a different request than the statement ───

describe('an in-transaction guard on a mount that strips a column', () => {
  test('a reparent onto a blueprint the editor does not own is refused before the write hook ever runs', async (t) => {
    if (guard(t)) return;
    // fmb-1934 PR-1: the factory no longer strips `blueprint_id` from a
    // non-admin PUT and lets the row silently stay put — it judges the
    // requested value against `checkParentOwnership` before anything else in
    // the write runs. The editor owns BP_LEADING_ZERO and not OTHER_BP, so
    // this PUT is refused outright and the transaction never reaches
    // `validateComputeRuleBeforeWrite` (the preWriteInTx hook rank 9 is about),
    // never mind the UPDATE. That closes the rank-9 class one gate earlier for
    // every `parentOwnership.via` column: the hook now only ever sees a value
    // that already IS the row's real destination (unchanged, or a lawfully
    // judged new one), never a body value the statement was going to drop.
    await seedBlueprints();
    const incumbent = await call(EDITOR, 'POST', '/edge/app/schema/decision_tables', {
      blueprint_id: BP_LEADING_ZERO,
      name: 'incumbent',
      doc: {
        conditions: [{ field_key: 'material' }],
        outputs: [{ field_key: 'part_no' }],
        rows: [{ when: { material: 'steel' }, then: { part_no: 'P-1' } }],
      },
    });
    assert.equal(incumbent.status, 200, JSON.stringify(incumbent.body));

    const second = await call(EDITOR, 'POST', '/edge/app/schema/decision_tables', {
      blueprint_id: BP_LEADING_ZERO, name: 'second',
    });
    assert.equal(second.status, 200, JSON.stringify(second.body));
    const secondId = second.body.data.id;

    const res = await call(EDITOR, 'PUT', `/edge/app/schema/decision_tables/${secondId}`, {
      blueprint_id: OTHER_BP,
      doc: {
        conditions: [{ field_key: 'size' }],
        outputs: [{ field_key: 'part_no' }],
        rows: [{ when: { size: 'M' }, then: { part_no: 'P-9' } }],
      },
    });
    // Stored state first, so removing the fix turns this red on the row
    // itself rather than on a status code.
    const stored = await one(
      `SELECT blueprint_id, doc FROM \`${tbl('decision_tables')}\` WHERE id = ?`, [secondId],
    );
    const doc = typeof stored.doc === 'string' ? JSON.parse(stored.doc) : stored.doc;
    assert.deepEqual(doc.outputs, [], 'the refused PUT must not have reached the UPDATE at all');
    assert.equal(stored.blueprint_id, BP_LEADING_ZERO, 'the row stayed on the blueprint the editor owns — the refused reparent did not move it');
    assert.equal(res.status, 403, `the reparent onto an unowned blueprint was admitted: ${JSON.stringify(res.body)}`);
    assert.equal(res.body.error.code, 'FORBIDDEN');
  });

  test('still admits a claim nobody else holds', async (t) => {
    if (guard(t)) return;
    // The control: the guard must refuse a second claim, not every write.
    await seedBlueprints();
    const created = await call(EDITOR, 'POST', '/edge/app/schema/decision_tables', {
      blueprint_id: BP_LEADING_ZERO, name: 'only one',
    });
    assert.equal(created.status, 200, JSON.stringify(created.body));
    const res = await call(EDITOR, 'PUT', `/edge/app/schema/decision_tables/${created.body.data.id}`, {
      doc: {
        conditions: [{ field_key: 'material' }],
        outputs: [{ field_key: 'part_no' }],
        rows: [{ when: { material: 'steel' }, then: { part_no: 'P-1' } }],
      },
    });
    assert.equal(res.status, 200, `a legitimate claim was refused: ${JSON.stringify(res.body)}`);
    const stored = await one(
      `SELECT doc FROM \`${tbl('decision_tables')}\` WHERE id = ?`, [created.body.data.id],
    );
    const doc = typeof stored.doc === 'string' ? JSON.parse(stored.doc) : stored.doc;
    assert.deepEqual(doc.outputs, [{ field_key: 'part_no' }]);
  });
});

// ── rank 54 — a hook rewriting a guarded column after the gates ──────────────

describe('a hook that rewrites a guarded column after every gate has run', () => {
  test('writes no row', async (t) => {
    if (guard(t)) return;
    // No serializer in the tree does this today — every one was audited. The
    // point is that the ordering gave no warning, so nothing PREVENTED the next
    // one; the mount used here exists only in this file, and the assertion is
    // that the database is left with nothing.
    const before = await countOf(`SELECT COUNT(*) AS n FROM \`${tbl('hierarchy_nodes')}\``);
    const res = await call(EDITOR, 'POST', '/edge/test/rewriting-mount/', {
      name: 'escalated', node_type: 'blueprint',
    });
    assert.notEqual(res.status, 200, `the rewritten row was admitted: ${JSON.stringify(res.body)}`);
    assert.equal(
      await countOf(`SELECT COUNT(*) AS n FROM \`${tbl('hierarchy_nodes')}\``), before,
      'a row the guards never judged reached the table',
    );
    assert.equal(
      await countOf(`SELECT COUNT(*) AS n FROM \`${tbl('hierarchy_nodes')}\` WHERE node_type = 'category'`),
      0, 'an editor holds a top-tier node they were refused',
    );
  });

  test('and the same mount without the rewrite still creates the row', async (t) => {
    if (guard(t)) return;
    const res = await call(EDITOR, 'POST', '/edge/app/schema/hierarchy_nodes', {
      name: 'ordinary', node_type: 'blueprint',
    });
    assert.equal(res.status, 200, `an ordinary create was refused: ${JSON.stringify(res.body)}`);
    const stored = await one(
      `SELECT node_type, owner_id FROM \`${tbl('hierarchy_nodes')}\` WHERE name = 'ordinary'`,
    );
    assert.equal(stored.node_type, 'blueprint');
    assert.equal(stored.owner_id, EDITOR.id);
  });
});

// ── the parent a row hangs off is stored the way the parent spells it ────────

describe('a create naming its parent by another spelling', () => {
  const storedParent = async (table, column, id) => {
    const row = await one(
      `SELECT CAST(\`${column}\` AS BINARY) AS v FROM \`${tbl(table)}\` WHERE id = ?`, [id],
    );
    if (!row || row.v == null) return null;
    return Buffer.isBuffer(row.v) ? row.v.toString('utf8') : String(row.v);
  };

  test('the premise: the parent resolves under either spelling', async (t) => {
    if (guard(t)) return;
    // Measured on the predicate every gate on this column uses. It is what makes
    // the write legal, and therefore what makes the stored value reachable.
    await seedBlueprints();
    assert.equal(
      await countOf(
        `SELECT COUNT(*) AS n FROM \`${tbl('hierarchy_nodes')}\` WHERE id = ?`,
        [BP_LEADING_LETTER.toUpperCase()],
      ),
      1, 'this column no longer folds case; the cases below rest on it',
    );
  });

  test('a variant stores the blueprint\'s own id, not the body\'s spelling', async (t) => {
    if (guard(t)) return;
    // The reparent route was fixed to bind the stored id. The CREATE reaches the
    // same column through the same body and was not: `inheritOwnerFromParent`
    // resolves the parent through the engine and correctly takes its owner_id,
    // then `data.parent_id` goes to the INSERT verbatim. The front end reads the
    // column back as `.find(n => n.id === node.parent_id)`, so a spelling no
    // node's id carries drops the whole branch out of the tree.
    await seedBlueprints();

    const res = await call(ADMIN, 'POST', '/edge/app/schema/hierarchy_nodes', {
      name: 'variant-a', node_type: 'variant', parent_id: BP_LEADING_LETTER.toUpperCase(),
    });
    assert.equal(res.status, 200, `the create was refused: ${JSON.stringify(res.body)}`);

    assert.equal(
      await storedParent('hierarchy_nodes', 'parent_id', res.body.data.id), BP_LEADING_LETTER,
      'the variant stored the body\'s spelling of its parent',
    );
  });

  test('and so does a child mount on create', async (t) => {
    if (guard(t)) return;
    // The same column class on a different mount: `blueprint_fields.blueprint_id`
    // names a hierarchy_node, every gate on it resolves in SQL, and the INSERT
    // bound the body's value.
    await seedBlueprints();

    const res = await call(ADMIN, 'POST', '/edge/app/schema/blueprint_fields', {
      blueprint_id: BP_LEADING_LETTER.toUpperCase(),
      field_key: 'city', field_label: 'City', field_type: 'text',
    });
    assert.equal(res.status, 200, `the create was refused: ${JSON.stringify(res.body)}`);

    assert.equal(
      await storedParent('blueprint_fields', 'blueprint_id', res.body.data.id), BP_LEADING_LETTER,
      'the field stored the body\'s spelling of its blueprint',
    );
  });

  test('and on update, which is the verb the last two fixes stopped at', async (t) => {
    if (guard(t)) return;
    await seedBlueprints();
    const created = await call(ADMIN, 'POST', '/edge/app/schema/blueprint_fields', {
      blueprint_id: BP_LEADING_LETTER, field_key: 'city', field_label: 'City', field_type: 'text',
    });
    assert.equal(created.status, 200, `the create was refused: ${JSON.stringify(created.body)}`);

    const moved = await call(ADMIN, 'PUT', `/edge/app/schema/blueprint_fields/${created.body.data.id}`,
      { blueprint_id: OTHER_BP.toUpperCase(), field_label: 'City 2' });
    assert.equal(moved.status, 200, `the update was refused: ${JSON.stringify(moved.body)}`);

    assert.equal(
      await storedParent('blueprint_fields', 'blueprint_id', created.body.data.id), OTHER_BP,
      'the update stored the body\'s spelling of the blueprint it moved the field to',
    );
  });

  test('a parent that names no row is left for the guards to refuse', async (t) => {
    if (guard(t)) return;
    // The rewrite must not become a second opinion about whether a reference is
    // legal: a value nothing resolves is passed through untouched, so the answer
    // the caller gets is still the FK guards' own.
    await seedBlueprints();
    const res = await call(ADMIN, 'POST', '/edge/app/schema/blueprint_fields', {
      blueprint_id: 'ffffffff-dead-4dea-8dea-ffffffffffff',
      field_key: 'city', field_label: 'City', field_type: 'text',
    });
    assert.notEqual(res.status, 500, `the unresolvable parent became a server error: ${JSON.stringify(res.body)}`);
  });
});
