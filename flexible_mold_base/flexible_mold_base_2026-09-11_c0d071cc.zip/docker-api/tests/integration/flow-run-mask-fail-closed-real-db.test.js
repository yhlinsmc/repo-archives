'use strict';

/**
 * flow-run-mask-fail-closed-real-db.test.js — a stored or displayed body never
 * contains a secret value; an opaque body that cannot be re-rendered from
 * masked sources is replaced whole (cards fmb-2074 / fmb-2055).
 *
 * `serializeWrite`'s rendered_payload mask (serializer.js) is the ONE function
 * both writers of this column go through: run-begin's own INSERT (always
 * machine-produced JSON/YAML, so it always parses — the masked-source render
 * IS the post-hoc happy path for that writer) and the generic PUT on this
 * mount (arbitrary text, no masked-source guarantee at all). This suite
 * proves the SECOND writer on a REAL row: a value neither parser can walk
 * must never survive as raw text, on a real column, through a real INSERT and
 * a real SELECT back — a stubbed driver would only prove the fixture answers
 * what it was told to.
 *
 * The second describe block below extends the same proof to output_snapshot
 * and error_summary — the sibling free-text audit columns written at the
 * identical generic-PUT site, which had the identical gap (fix batch 1).
 *
 * Skips with a stated reason when no database is reachable, and fails instead
 * of skipping when REQUIRE_INTEGRATION_DB=1.
 */
const { test, describe, before, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const net = require('node:net');
const mariadb = require('mariadb');

const TEST_PREFIX = 'frmfc_';
const tbl = (name) => `${TEST_PREFIX}${name}`;

const { buildEngineTableDDLs } = require('../../src/table-ddls');
const { TABLES } = require('../../src/shared/constants');

// require.cache is NOT swapped for this suite — serializeWrite/maskSerializedPayload
// take no DB dependency of their own; only the row read/write below touches the pool,
// and it uses this suite's OWN pool directly rather than the app's db module.
const {
  serializeWrite,
  UNPARSEABLE_BODY_PLACEHOLDER,
} = require('../../src/edge/routes/app/flow-recipe-runs/serializer');

// ── Config auto-detection (same shape as the sibling integration tests) ──────
function parseEnvFile(filePath) {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    const out = {};
    for (const line of content.split('\n')) {
      const m = line.match(/^\s*([A-Z_][A-Z0-9_]*)\s*=\s*(.*)\s*$/);
      if (!m) continue;
      let value = m[2];
      if ((value.startsWith('"') && value.endsWith('"'))
        || (value.startsWith("'") && value.endsWith("'"))) value = value.slice(1, -1);
      out[m[1]] = value;
    }
    return out;
  } catch { return null; }
}

function probePort(host, port, timeoutMs = 2000) {
  return new Promise((resolve) => {
    const socket = new net.Socket();
    let done = false;
    const finish = (ok) => { if (done) return; done = true; socket.destroy(); resolve(ok); };
    socket.setTimeout(timeoutMs);
    socket.once('connect', () => finish(true));
    socket.once('timeout', () => finish(false));
    socket.once('error', () => finish(false));
    socket.connect(port, host);
  });
}

async function resolveMariaDbConfig() {
  if (process.env.DB_TEST_HOST && process.env.DB_TEST_ROOT_PASSWORD) {
    return {
      host: process.env.DB_TEST_HOST,
      port: parseInt(process.env.DB_TEST_PORT || '3306', 10),
      user: 'root', password: process.env.DB_TEST_ROOT_PASSWORD,
    };
  }
  const envPath = path.resolve(__dirname, '../../../.devcontainer/.env');
  const env = parseEnvFile(envPath);
  if (!env || !env.DB_ROOT_PASSWORD) return null;
  const port = parseInt(env.DB_PORT || '3306', 10);
  for (const host of ['127.0.0.1', 'mariadb', 'localhost']) {
    if (await probePort(host, port, 2000)) {
      return { host, port, user: 'root', password: env.DB_ROOT_PASSWORD };
    }
  }
  return null;
}

const ACTOR = '22222222-2222-2222-2222-222222222222';
const RECIPE = '33333333-3333-3333-3333-333333333333';
const SECRET = 'SECRETVALUE-frmfc';

let pool = null;
let dbReady = false;
let skipReason = null;
let testDbName = null;

before(async () => {
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) {
    skipReason = 'no MariaDB reachable via .devcontainer/.env or env vars';
    if (process.env.REQUIRE_INTEGRATION_DB === '1') throw new Error(`REQUIRE_INTEGRATION_DB=1 set but ${skipReason}.`);
    return;
  }
  testDbName = `frmfc_test_${process.pid}_${Date.now()}`;
  let admin = null;
  try {
    admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`CREATE DATABASE \`${testDbName}\``);
    await admin.query(`USE \`${testDbName}\``);
    for (const sql of buildEngineTableDDLs(tbl)) await admin.query(sql);
    await admin.end();
    admin = null;

    pool = mariadb.createPool({ ...dbConfig, database: testDbName, connectionLimit: 4, connectTimeout: 5000 });
    dbReady = true;
  } catch (err) {
    skipReason = `setup failed: ${err.message}`;
    if (admin) { try { await admin.end(); } catch { /* best effort */ } }
    if (process.env.REQUIRE_INTEGRATION_DB === '1') throw err;
  }
});

after(async () => {
  if (pool) { try { await pool.end(); } catch { /* best effort */ } }
  if (!testDbName) return;
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) return;
  try {
    const admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`DROP DATABASE IF EXISTS \`${testDbName}\``);
    await admin.end();
  } catch { /* best effort */ }
});

const guard = (t) => { if (!dbReady) { t.skip(skipReason || 'database not ready'); return true; } return false; };

let seq = 0;
async function insertRun(renderedPayloadColumnValue) {
  const id = `aaaaaaaa-0000-0000-0000-${String(seq++).padStart(12, '0')}`;
  await pool.query(
    `INSERT INTO \`${tbl(TABLES.FLOW_RECIPE_RUNS)}\` (id, recipe_id, actor_id, mode, status, rendered_payload) VALUES (?, ?, ?, 'create', 'success', ?)`,
    [id, RECIPE, ACTOR, renderedPayloadColumnValue],
  );
  return id;
}

async function readRenderedPayload(id) {
  const rows = await pool.query(
    `SELECT rendered_payload FROM \`${tbl(TABLES.FLOW_RECIPE_RUNS)}\` WHERE id = ?`, [id],
  );
  return rows[0].rendered_payload;
}

// Generic per-column helpers for the sibling audit columns (output_snapshot,
// error_summary) — same generic-PUT write shape as rendered_payload above,
// against their own real columns.
async function insertRunColumn(column, value) {
  const id = `aaaaaaaa-0001-0000-0000-${String(seq++).padStart(12, '0')}`;
  await pool.query(
    `INSERT INTO \`${tbl(TABLES.FLOW_RECIPE_RUNS)}\` (id, recipe_id, actor_id, mode, status, \`${column}\`) VALUES (?, ?, ?, 'create', 'success', ?)`,
    [id, RECIPE, ACTOR, value],
  );
  return id;
}

async function readRunColumn(column, id) {
  const rows = await pool.query(
    `SELECT \`${column}\` FROM \`${tbl(TABLES.FLOW_RECIPE_RUNS)}\` WHERE id = ?`, [id],
  );
  return rows[0][column];
}

describe('flow_recipe_runs.rendered_payload fail-closed masking on a real database', () => {
  test('B path: a JSON payload with a non-secret field and a secret field — the field survives, only the secret is masked (readability preserved)', async (t) => {
    if (guard(t)) return;
    const masked = await serializeWrite({
      rendered_payload: JSON.stringify({ a: '1', token: SECRET }),
    });
    const id = await insertRun(masked.rendered_payload);
    const stored = await readRenderedPayload(id);
    assert.ok(!stored.includes(SECRET), `secret leaked into a real row: ${stored}`);
    assert.ok(stored.includes('"a":"1"'), `non-secret field lost readability: ${stored}`);
    assert.notEqual(stored, UNPARSEABLE_BODY_PLACEHOLDER, 'a parseable JSON body must not fall to the opaque placeholder');
  });

  test('C path: a form-encoded body through a real run row write — the whole value is replaced, never the raw text', async (t) => {
    if (guard(t)) return;
    const opaque = `a=1&token=${SECRET}`;
    const masked = await serializeWrite({ rendered_payload: opaque });
    const id = await insertRun(masked.rendered_payload);
    const stored = await readRenderedPayload(id);
    assert.ok(!stored.includes(SECRET), `secret leaked into a real row: ${stored}`);
    assert.equal(stored, UNPARSEABLE_BODY_PLACEHOLDER, `expected the fail-closed placeholder, got: ${stored}`);
  });

  test('C path: a URL-encoded variant of the secret in an opaque body is masked the same way', async (t) => {
    if (guard(t)) return;
    const opaque = 'token=SECRET%20VALUE-frmfc';
    const masked = await serializeWrite({ rendered_payload: opaque });
    const id = await insertRun(masked.rendered_payload);
    const stored = await readRenderedPayload(id);
    assert.ok(!stored.includes('SECRET%20VALUE-frmfc'));
    assert.equal(stored, UNPARSEABLE_BODY_PLACEHOLDER);
  });

  test('C path: an XML body through a real run row write is masked the same way', async (t) => {
    if (guard(t)) return;
    const opaque = `<token>${SECRET}</token>`;
    const masked = await serializeWrite({ rendered_payload: opaque });
    const id = await insertRun(masked.rendered_payload);
    const stored = await readRenderedPayload(id);
    assert.ok(!stored.includes(SECRET));
    assert.equal(stored, UNPARSEABLE_BODY_PLACEHOLDER);
  });

  test('C path: broken YAML that contains the secret is masked the same way', async (t) => {
    if (guard(t)) return;
    // Unbalanced flow sequence — yaml.parse throws; JSON.parse throws first.
    const broken = `token: ${SECRET}\n  bad: [1, 2\n`;
    const masked = await serializeWrite({ rendered_payload: broken });
    const id = await insertRun(masked.rendered_payload);
    const stored = await readRenderedPayload(id);
    assert.ok(!stored.includes(SECRET));
    assert.equal(stored, UNPARSEABLE_BODY_PLACEHOLDER);
  });

  test('schema-parity: rendered_payload stays LONGTEXT NULL — no DDL change expected', () => {
    const ddls = buildEngineTableDDLs((n) => n);
    const runsDdl = ddls.find((sql) => new RegExp(`CREATE TABLE IF NOT EXISTS \`${TABLES.FLOW_RECIPE_RUNS}\``).test(sql));
    assert.ok(runsDdl, 'flow_recipe_runs DDL not found');
    assert.match(runsDdl, /rendered_payload\s+LONGTEXT\s+NULL\s+DEFAULT NULL/,
      'rendered_payload column shape changed — this PR must not alter the DDL');
  });

});

// FLOW-MASK fix batch 1 (fmb-2074/2055 follow-up): output_snapshot and
// error_summary are the same generic-PUT write site as rendered_payload
// above and had the identical gap — an opaque body survived verbatim because
// their pre-fix code (JSON.parse-or-leave-verbatim / plain maskDeep on a bare
// string) never fell through to a fail-closed placeholder. One row per
// column, proved on a real INSERT and a real SELECT back.
describe('flow_recipe_runs sibling audit columns fail closed on a real database', () => {
  test('output_snapshot: an opaque body with a secret is replaced whole, not stored verbatim', async (t) => {
    if (guard(t)) return;
    const opaque = `apikey=${SECRET}`;
    const masked = await serializeWrite({ output_snapshot: opaque });
    const id = await insertRunColumn('output_snapshot', masked.output_snapshot);
    const stored = await readRunColumn('output_snapshot', id);
    assert.ok(!stored.includes(SECRET), `secret leaked into a real row: ${stored}`);
    assert.equal(stored, UNPARSEABLE_BODY_PLACEHOLDER, `expected the fail-closed placeholder, got: ${stored}`);
  });

  test('error_summary: an opaque body with a secret is replaced whole, not stored verbatim', async (t) => {
    if (guard(t)) return;
    const opaque = `apikey=${SECRET}`;
    const masked = await serializeWrite({ error_summary: opaque });
    const id = await insertRunColumn('error_summary', masked.error_summary);
    const stored = await readRunColumn('error_summary', id);
    assert.ok(!stored.includes(SECRET), `secret leaked into a real row: ${stored}`);
    assert.equal(stored, UNPARSEABLE_BODY_PLACEHOLDER, `expected the fail-closed placeholder, got: ${stored}`);
  });
});
