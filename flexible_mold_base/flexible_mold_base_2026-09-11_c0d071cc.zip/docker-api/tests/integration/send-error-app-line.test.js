'use strict';

/**
 * send-error-app-line.test.js — C1 integration proof for the logging epic
 * PR-2b fix batch.
 *
 * Boots a REAL Express app (request-id child logger + the real
 * createRequestLog finish handler + the real sendError helper) on an ephemeral
 * port, drives a real catch-path 500 over HTTP, and asserts the invariant the
 * codemod's pass-2 log-merge exists to guarantee:
 *
 *   a >=500 response logs EXACTLY ONE error/app line for its req_id, and that
 *   line carries the ORIGINAL throw's stack — not a synthetic Error minted
 *   inside send-error.js, and not a second (duplicate) error line left behind
 *   by a pre-existing `req.log.error({ err }, ...)` above the sendError call.
 *
 * Zero new npm deps — node core http + native fetch + a captured pino sink.
 */
process.env.NODE_ENV = 'test';

const { test } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const { Writable } = require('node:stream');
const express = require('express');
const pino = require('pino');
const { _internals } = require('../../src/shared/lib/logger');
const { createRequestLog } = require('../../src/shared/middleware/request-log');
const { sendError } = require('../../src/shared/lib/send-error');

function makeCapture() {
  const records = [];
  const sink = new Writable({
    write(chunk, _e, cb) {
      for (const line of chunk.toString().split('\n')) {
        if (line.trim()) records.push(JSON.parse(line));
      }
      cb();
    },
  });
  return { records, base: pino(_internals.loggerOptions, sink) };
}

// A named frame so the captured stack is unmistakably the throw site, not a
// synthetic Error created in the helper (which would never name this function).
function deepDbCall() {
  throw new Error('connection reset by peer');
}

test('C1: a real catch-path 500 logs exactly ONE error/app line for the req_id, carrying the original throw stack (not send-error.js)', async () => {
  const { records, base } = makeCapture();
  const app = express();

  // request-id.js binds req.log to the module logger (not injectable); mint the
  // id + bind req.log to the CAPTURED base here, which is exactly what that
  // middleware does, so both the app line and the finish access line are seen.
  app.use((req, res, next) => {
    req.id = 'itg' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
    req.log = base.child({ req_id: req.id });
    res.setHeader('X-Request-Id', req.id);
    next();
  });
  app.use(createRequestLog({ logger: base }));

  const router = express.Router();
  router.get('/boom', (req, res) => {
    try {
      deepDbCall();
      res.json({ ok: true });
    } catch (err) {
      // The shape the codemod produces: the real caught err threaded in, no
      // separate req.log.error above it.
      sendError(req, res, err, { status: 500, code: 'DB_ERROR', reason: 'Database operation failed' });
    }
  });
  app.use('/edge/app', router);

  const server = http.createServer(app);
  await new Promise((resolve) => server.listen(0, resolve));
  const { port } = server.address();

  let body; let reqId;
  try {
    const resp = await fetch(`http://127.0.0.1:${port}/edge/app/boom`);
    reqId = resp.headers.get('x-request-id');
    assert.equal(resp.status, 500);
    body = await resp.json();
    // let the 'finish' handler (access line) run
    await new Promise((resolve) => setTimeout(resolve, 25));
  } finally {
    await new Promise((resolve) => server.close(resolve));
  }

  // Response body: the apiError envelope, never a stack.
  assert.equal(body.error.code, 'DB_ERROR');
  assert.equal(JSON.stringify(body).includes('stack'), false);

  const mine = records.filter((r) => r.req_id === reqId);
  const appLines = mine.filter((r) => r.kind === 'app');
  const accessLines = mine.filter((r) => r.kind === 'access');

  assert.equal(appLines.length, 1, 'exactly one error/app line for this req_id (no duplicate from a leftover req.log.error)');
  assert.equal(accessLines.length, 1, 'exactly one finish access line for this req_id');

  const appLine = appLines[0];
  assert.equal(appLine.level, 'error');
  assert.equal(appLine.status, 500);
  assert.equal(appLine.code, 'DB_ERROR');
  assert.ok(appLine.err && typeof appLine.err.stack === 'string' && appLine.err.stack.length > 0);
  assert.ok(appLine.err.stack.includes('deepDbCall'),
    'the app line carries the ORIGINAL throw stack (deepDbCall), not a synthetic Error');
  // `src` must name the ROUTE that called sendError (here, this test
  // file's own /boom handler) — not shared/lib/send-error.js, which is
  // what actually calls log[level](...) on the route's behalf.
  assert.equal(appLine.src.startsWith('shared/lib/send-error'), false,
    'src must not name the helper, which would hide the real route on every migrated 5xx');
  assert.ok(appLine.src.includes('integration/send-error-app-line.test.js'),
    'src names the route handler frame (this test\'s /boom handler)');
  // The access finish line never carries a stack; exactly one of the two does.
  assert.equal(accessLines[0].err, undefined, 'the finish access line carries no stack');
  assert.equal(mine.filter((r) => r.err && r.err.stack).length, 1, 'exactly one of the two lines carries a stack');
});

// A named frame for the ROLLBACK failure, distinct from the original throw
// below — the test only passes if the app line's stack names the ORIGINAL
// throw and never this one.
function rollbackThatFails() {
  throw new Error('rollback connection lost');
}

// Drives the shape PR-2b'' (fmb-2098) threads a cause for: the route throws,
// an inner try/catch around the rollback ALSO throws (a different error),
// and the responder sits in the OUTER catch body after the inner try/catch
// has already closed. `runNestedRollbackRoute(cause)` takes the cause
// sendError should carry — `null` reproduces the pre-fix shape (the bug this
// row exists to catch: the app line would then carry a synthetic stack that
// never mentions the real throw site) and `err` is the innermost-enclosing-
// catch parameter pass 3 threads in its place.
async function runNestedRollbackRoute(cause) {
  const { records, base } = makeCapture();
  const app = express();
  app.use((req, res, next) => {
    req.id = 'itg' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
    req.log = base.child({ req_id: req.id });
    res.setHeader('X-Request-Id', req.id);
    next();
  });
  app.use(createRequestLog({ logger: base }));

  const router = express.Router();
  router.get('/boom-rollback', async (req, res) => {
    try {
      deepDbCall();
      res.json({ ok: true });
    } catch (err) {
      try {
        await rollbackThatFails();
      } catch (rbErr) {
        req.log.warn({ err: rbErr }, 'rollback failed');
      }
      sendError(req, res, cause === 'err' ? err : null, { status: 500, code: 'DB_ERROR', reason: 'Database operation failed' });
    }
  });
  app.use('/edge/app', router);

  const server = http.createServer(app);
  await new Promise((resolve) => server.listen(0, resolve));
  const { port } = server.address();

  let reqId;
  try {
    const resp = await fetch(`http://127.0.0.1:${port}/edge/app/boom-rollback`);
    reqId = resp.headers.get('x-request-id');
    assert.equal(resp.status, 500);
    await new Promise((resolve) => setTimeout(resolve, 25));
  } finally {
    await new Promise((resolve) => server.close(resolve));
  }

  return records.filter((r) => r.req_id === reqId);
}

// A bare req.log.warn(...) call with no explicit `kind` also defaults to
// kind:'app' (logger.js: "kind default: `app` unless the call site or a
// child binding set one") — so the rollback warn and the sendError error
// line are BOTH kind:'app'. "Exactly one error app line" therefore means
// exactly one line that is kind:'app' AND level:'error'; the rollback warn
// is distinguished by level, not kind.
function errorAppLines(mine) {
  return mine.filter((r) => r.kind === 'app' && r.level === 'error');
}

// L2 (fmb-2098): this is a CONTRAST/baseline case, not a codemod-regression
// proof — `cause` here is an explicit test parameter (`null`), not something
// the pass-3 codemod ever produces or could regress into, so a null cause
// always synthesizes its own stack regardless of whether the codemod is
// doing its job. Its purpose is to document the pre-fix shape the GREEN
// test below is contrasted against.
test('C1 nested-rollback baseline: a null cause (the pre-fix shape) does NOT carry the original throw stack', async () => {
  const mine = await runNestedRollbackRoute(null);
  const appLines = errorAppLines(mine);
  assert.equal(appLines.length, 1);
  // The synthetic-stack branch names send-error.js's own emitAppLine frame
  // (`new Error(reason || code, { cause })`), never deepDbCall — this is
  // exactly the defect fix batch 3 found: a null cause inside a catch loses
  // the real throw site.
  assert.equal(appLines[0].err.stack.includes('deepDbCall'), false,
    'a null cause synthesizes its own stack — contrast this with the GREEN test below, which asserts the threaded err DOES carry deepDbCall');
});

test('C1 nested-rollback GREEN: the outer catch threads the original err (not the inner rollback error) — one error/app line names deepDbCall, the rollback failure is a separate warn line, req_id shared with the access line', async () => {
  const mine = await runNestedRollbackRoute('err');
  const appLines = errorAppLines(mine);
  const accessLines = mine.filter((r) => r.kind === 'access');
  const warnLines = mine.filter((r) => r.level === 'warn');

  assert.equal(appLines.length, 1, 'exactly one error/app line for this req_id');
  assert.equal(accessLines.length, 1, 'exactly one finish access line for this req_id');
  assert.ok(appLines[0].err.stack.includes('deepDbCall'),
    'the app line stack names the ORIGINAL throw site, not the rollback failure');
  assert.equal(appLines[0].err.stack.includes('rollbackThatFails'), false,
    'the app line stack must not be the inner rollback error');

  assert.equal(warnLines.length, 1, 'the rollback failure is exactly one warn line, not folded into the error line');
  assert.notEqual(warnLines[0].level, 'error', 'the rollback warn is level:warn, not error — it never masquerades as the app error line');
  assert.ok(warnLines[0].err.stack.includes('rollbackThatFails'), 'the warn line carries the rollback error, a DIFFERENT stack than the app line');

  assert.ok(appLines[0].req_id, 'the app line carries a req_id');
  assert.equal(accessLines[0].req_id, appLines[0].req_id, 'the access line shares the app line\'s req_id');
  assert.equal(warnLines[0].req_id, appLines[0].req_id, 'the rollback warn line shares the same req_id too');
});
