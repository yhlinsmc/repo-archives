/**
 * export-import-cascade-roundtrip.test.js
 *
 * Proves the two v3.2.129 cascading-dependent-options columns survive an
 * export → seed-import round-trip:
 *   - blueprint_fields.depends_on_field_key (VARCHAR)
 *   - field_options.valid_parent_values     (TEXT holding a JSON array)
 *
 * Test 1 drives the real export route (GET /api/export/mariadb-sql) against a
 * mock pool and asserts the generated SQL emits both columns, with
 * valid_parent_values re-serialised as a CLEAN JSON string (the dto-mapper
 * registers it as json, so export.js parses-then-reserialises it rather than
 * wrapping the raw driver string verbatim).
 *
 * Test 2 feeds the export's INSERT statements through the real seed-import
 * path (POST /api/setup/seed) against a second mock pool that captures the
 * applied statements, and asserts the values land back byte-equivalent.
 *
 * Test 3 documents the operator-mode behaviour when the target schema is
 * MISSING valid_parent_values: the seed import surfaces a clear per-statement
 * error and rolls the batch back (it does NOT silently corrupt the rest).
 *
 * Harness idiom copied from audit-insert-uses-rw.test.js: inject a mock db
 * module into require.cache before requiring the route, mount on a throwaway
 * express server, drive over real http.
 */
const { describe, it, before, after } = require('node:test');
const { makeStubReqLog } = require('../helpers/stub-req-log');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const { splitSqlStatements } = require('../../src/sql-utils');

const dbKey = require.resolve('../../src/edge/db');

// ── Mock DB module shared by both routes. Each test swaps the connection
// factory by reassigning these spies, so the require.cache entry stays stable
// while the per-test behaviour varies. ──────────────────────────────────────
const PREFIX = 'fmb_';
const DB_NAME = 'testdb';

let roConnFactory; // () => connection used by export (pool.ro)
let rwConnFactory; // () => connection used by seed   (pool.rw)

const poolSpy = {
  ro: { async getConnection() { return roConnFactory(); } },
  rw: { async getConnection() { return rwConnFactory(); } },
};

require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: {
    pool: poolSpy,
    t: (name) => `${PREFIX}${name}`,
    getDbConfig: () => ({ database: DB_NAME, tablePrefix: PREFIX }),
    isPoolReady: () => true,
  },
};

const exportRouter = require('../../src/edge/routes/platform/export');
const registerSeed = require('../../src/edge/routes/platform/setup/seed-data');

// ── Engine-table dump fixtures. Only the two tables under test carry rows;
// the rest report empty so the export loop skips them quickly. ──────────────
const FIELD_OPTIONS_ROW = {
  id: 'opt-1',
  blueprint_field_id: 'bf-1',
  value: 'sedan-trim',
  label: 'Sedan Trim',
  sort_order: 0,
  created_at: '2026-06-01 00:00:00',
  // TEXT column: the driver returns JSON as a raw string, exactly as MariaDB
  // stored it. export.js must parse + re-serialise it to a clean literal.
  valid_parent_values: '["sedan","suv"]',
};

const BLUEPRINT_FIELDS_ROW = {
  id: 'bf-2',
  blueprint_id: 'bp-1',
  field_key: 'trim',
  label: 'Trim',
  field_type: 'select',
  is_required: 0,
  sort_order: 0,
  created_at: '2026-06-01 00:00:00',
  depends_on_field_key: 'series',
};

const COLUMN_META = {
  field_options: [
    { COLUMN_NAME: 'id', DATA_TYPE: 'varchar' },
    { COLUMN_NAME: 'blueprint_field_id', DATA_TYPE: 'varchar' },
    { COLUMN_NAME: 'value', DATA_TYPE: 'varchar' },
    { COLUMN_NAME: 'label', DATA_TYPE: 'varchar' },
    { COLUMN_NAME: 'sort_order', DATA_TYPE: 'int' },
    { COLUMN_NAME: 'created_at', DATA_TYPE: 'timestamp' },
    { COLUMN_NAME: 'valid_parent_values', DATA_TYPE: 'text' },
  ],
  blueprint_fields: [
    { COLUMN_NAME: 'id', DATA_TYPE: 'varchar' },
    { COLUMN_NAME: 'blueprint_id', DATA_TYPE: 'varchar' },
    { COLUMN_NAME: 'field_key', DATA_TYPE: 'varchar' },
    { COLUMN_NAME: 'label', DATA_TYPE: 'varchar' },
    { COLUMN_NAME: 'field_type', DATA_TYPE: 'varchar' },
    { COLUMN_NAME: 'is_required', DATA_TYPE: 'tinyint' },
    { COLUMN_NAME: 'sort_order', DATA_TYPE: 'int' },
    { COLUMN_NAME: 'created_at', DATA_TYPE: 'timestamp' },
    { COLUMN_NAME: 'depends_on_field_key', DATA_TYPE: 'varchar' },
  ],
};

const TABLE_ROWS = {
  field_options: [FIELD_OPTIONS_ROW],
  blueprint_fields: [BLUEPRINT_FIELDS_ROW],
};

/**
 * Connection used by the export route. Distinguishes the `SELECT *` dump from
 * the information_schema column-metadata query by inspecting the SQL.
 */
function makeExportConn() {
  return {
    async query(sql, params) {
      if (/^SELECT \* FROM/.test(sql)) {
        // Physical table name is `${PREFIX}${tableName}`; extract the suffix.
        const m = sql.match(/`([^`]+)`/);
        const physical = m ? m[1] : '';
        const tableName = physical.startsWith(PREFIX) ? physical.slice(PREFIX.length) : physical;
        return TABLE_ROWS[tableName] || [];
      }
      if (/information_schema\.COLUMNS/i.test(sql)) {
        // params = [database, physicalTable]
        const physical = params[1];
        const tableName = physical.startsWith(PREFIX) ? physical.slice(PREFIX.length) : physical;
        return COLUMN_META[tableName] || [];
      }
      return [];
    },
    release() { /* noop */ },
  };
}

let exportServer;
let exportPort;
let seedServer;
let seedPort;

// Per-test capture of statements applied by the seed route, plus a flag that
// makes a target column "missing" to drive Test 3.
let seedCapture;

function makeSeedConn(opts = {}) {
  const missingColumns = new Set(opts.missingColumns || []);
  return {
    txnOpen: false,
    async query(sql) {
      // user-count probe at handler entry (first-run vs admin gate)
      if (/SELECT COUNT\(\*\)/i.test(sql)) return [{ cnt: 0 }];
      // owner-remap col probe / NOT IN subquery never fire for anon importer,
      // but guard just in case the handler evolves.
      if (/INFORMATION_SCHEMA\.COLUMNS/i.test(sql)) return [];

      // Applied INSERT statements: simulate the target schema. The statement
      // splitter keeps leading `-- Table` comment lines attached to the INSERT
      // (it strips transaction wrappers but not comments), exactly as the real
      // driver receives them, so match INSERT unanchored. If the INSERT names a
      // column the target is "missing", raise the MariaDB error a real server
      // would (ER_BAD_FIELD_ERROR / errno 1054).
      if (/INSERT\s+INTO/i.test(sql)) {
        for (const col of missingColumns) {
          if (new RegExp(`\`${col}\``).test(sql)) {
            const err = new Error(`Unknown column '${col}' in 'field list'`);
            err.code = 'ER_BAD_FIELD_ERROR';
            err.errno = 1054;
            throw err;
          }
        }
        seedCapture.applied.push(sql);
        return { affectedRows: 1 };
      }
      return { affectedRows: 0 };
    },
    async beginTransaction() { seedCapture.began = true; },
    async commit() { seedCapture.committed = true; },
    async rollback() { seedCapture.rolledBack = true; },
    release() { /* noop */ },
  };
}

before(async () => {
  // Export server — admin user injected so the route's role gate passes.
  roConnFactory = makeExportConn;
  const exportApp = express();
  exportApp.use((req, _res, next) => { req.log = makeStubReqLog(); next(); }); // TEST-ONLY: production always sets req.log via createRequestId (request-id.js) before any router; this bare app has no such middleware, so a route's req.log.<level>() call would otherwise throw against undefined.
  exportApp.use(express.json());
  exportApp.use((req, _res, next) => { req.user = { id: 'admin-1', role: 'admin' }; next(); });
  exportApp.use('/api/export', exportRouter);
  await new Promise((resolve) => {
    exportServer = exportApp.listen(0, '127.0.0.1', () => {
      exportPort = exportServer.address().port;
      resolve();
    });
  });

  // Seed server — anonymous first-run importer (owner-remap path is skipped,
  // which keeps the round-trip focused on the cascade columns).
  const seedApp = express();
  seedApp.use((req, _res, next) => { req.log = makeStubReqLog(); next(); }); // TEST-ONLY: production always sets req.log via createRequestId (request-id.js) before any router; this bare app has no such middleware, so a route's req.log.<level>() call would otherwise throw against undefined.
  seedApp.use(express.json());
  const seedRouter = express.Router();
  registerSeed(seedRouter);
  seedApp.use('/api/setup', seedRouter);
  await new Promise((resolve) => {
    seedServer = seedApp.listen(0, '127.0.0.1', () => {
      seedPort = seedServer.address().port;
      resolve();
    });
  });
});

after(async () => {
  await new Promise((resolve) => exportServer.close(resolve));
  await new Promise((resolve) => seedServer.close(resolve));
  delete require.cache[dbKey];
});

function getText(port, path_) {
  return new Promise((resolve, reject) => {
    const req = http.request({ host: '127.0.0.1', port, path: path_, method: 'GET' }, (res) => {
      const chunks = [];
      res.on('data', (c) => chunks.push(c));
      res.on('end', () => resolve({ status: res.statusCode, body: Buffer.concat(chunks).toString('utf-8') }));
    });
    req.on('error', reject);
    req.end();
  });
}

function postJson(port, path_, body) {
  return new Promise((resolve, reject) => {
    const payload = JSON.stringify(body);
    const req = http.request(
      {
        host: '127.0.0.1', port, path: path_, method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) },
      },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          const raw = Buffer.concat(chunks).toString('utf-8');
          let json = null;
          try { json = JSON.parse(raw); } catch { /* noop */ }
          resolve({ status: res.statusCode, raw, json });
        });
      },
    );
    req.on('error', reject);
    req.write(payload);
    req.end();
  });
}

/** Pull the single INSERT statement for a given table out of an export dump. */
function extractInsert(sql, tableName) {
  const stmts = splitSqlStatements(sql);
  return stmts.find((s) => new RegExp(`INSERT INTO \`(__PREFIX__|${PREFIX})${tableName}\``).test(s));
}

describe('export emits both cascade columns with clean JSON', () => {
  it('field_options INSERT carries valid_parent_values as a clean JSON literal', async () => {
    const { status, body } = await getText(exportPort, '/api/export/mariadb-sql');
    assert.equal(status, 200);

    const insert = extractInsert(body, 'field_options');
    assert.ok(insert, 'export must contain a field_options INSERT');

    // Column is present in the column list.
    assert.match(insert, /`valid_parent_values`/);

    // Value is a clean JSON string literal — exactly '["sedan","suv"]', not a
    // double-escaped or driver-mangled form. escapeString does not touch the
    // double quotes JSON uses, so the literal embeds them verbatim.
    assert.match(insert, /'\["sedan","suv"\]'/);
    // Defensive: no backslash-escaping leaked in (would signal double-encoding).
    assert.doesNotMatch(insert, /\\"sedan\\"/);
  });

  it('blueprint_fields INSERT carries depends_on_field_key with its value', async () => {
    const { status, body } = await getText(exportPort, '/api/export/mariadb-sql');
    assert.equal(status, 200);

    const insert = extractInsert(body, 'blueprint_fields');
    assert.ok(insert, 'export must contain a blueprint_fields INSERT');
    assert.match(insert, /`depends_on_field_key`/);
    assert.match(insert, /'series'/);
  });
});

describe('round-trip via seed import', () => {
  // Asserted at the IN-PROCESS seed level: the real POST /api/setup/seed
  // handler parses + applies the export's INSERT statements. The mock conn
  // captures the exact SQL the handler hands to the driver, so re-parsing the
  // embedded literal proves the value survives byte-for-byte. We stop short of
  // a real MariaDB write (no DB in unit CI), but everything up to and
  // including the driver-bound SQL is the production code path.
  it('valid_parent_values + depends_on_field_key survive export → seed apply', async () => {
    const { body: dump } = await getText(exportPort, '/api/export/mariadb-sql');

    // Resolve __PREFIX__ the way the seed handler does (it replaces against
    // the configured prefix). We feed the raw dump; the handler resolves it.
    seedCapture = { applied: [], began: false, committed: false, rolledBack: false };
    rwConnFactory = () => makeSeedConn();

    const res = await postJson(seedPort, '/api/setup/seed', { sql: dump });
    assert.equal(res.status, 200, `seed import should succeed: ${res.raw}`);
    assert.equal(seedCapture.committed, true, 'seed txn must commit');
    assert.equal(seedCapture.rolledBack, false, 'seed txn must not roll back');

    const foInsert = seedCapture.applied.find((s) => /field_options/.test(s));
    const bfInsert = seedCapture.applied.find((s) => /blueprint_fields/.test(s));
    assert.ok(foInsert, 'field_options INSERT must reach the driver');
    assert.ok(bfInsert, 'blueprint_fields INSERT must reach the driver');

    // valid_parent_values: pull the embedded literal back out and JSON.parse
    // it — must round-trip to the original array.
    const vpvMatch = foInsert.match(/'(\[[^']*\])'/);
    assert.ok(vpvMatch, 'field_options INSERT must embed a JSON-array literal');
    assert.deepEqual(JSON.parse(vpvMatch[1]), ['sedan', 'suv']);

    // depends_on_field_key: the literal 'series' must survive verbatim.
    assert.match(bfInsert, /'series'/);
  });
});

describe('operator-mode: target schema missing valid_parent_values', () => {
  // Documents the behaviour when the import targets a schema that never got
  // the valid_parent_values ADD COLUMN migration (operator-mode without ALTER).
  // The seed path has NO per-column gate (the v3.2.128 CRUD column gate does
  // not cover seed), so the INSERT naming the missing column raises
  // ER_BAD_FIELD_ERROR (errno 1054). v3.2.151 classifies this schema-drift as
  // an actionable 422 SEED_SCHEMA_MISMATCH naming the mismatch (instead of an
  // opaque 500). The handler still rolls the whole batch back and does NOT
  // silently corrupt the rest of the import. A softer per-statement skip would
  // be a separate enhancement and is tracked as a FOLLOW-UP, not fixed here.
  it('surfaces a 422 SEED_SCHEMA_MISMATCH and rolls back rather than corrupting the batch', async () => {
    const { body: dump } = await getText(exportPort, '/api/export/mariadb-sql');

    seedCapture = { applied: [], began: false, committed: false, rolledBack: false };
    rwConnFactory = () => makeSeedConn({ missingColumns: ['valid_parent_values'] });

    const res = await postJson(seedPort, '/api/setup/seed', { sql: dump });

    assert.equal(res.status, 422, 'schema-behind target surfaces as 422 SEED_SCHEMA_MISMATCH');
    assert.equal(res.json?.error?.code, 'SEED_SCHEMA_MISMATCH');
    assert.equal(res.json?.error?.details?.errno, 1054);
    assert.match(res.json?.error?.details?.db_message || '', /Unknown column 'valid_parent_values'/);
    assert.equal(seedCapture.rolledBack, true, 'batch must roll back on the failing statement');
    assert.equal(seedCapture.committed, false, 'must not commit a partial batch');
  });
});
