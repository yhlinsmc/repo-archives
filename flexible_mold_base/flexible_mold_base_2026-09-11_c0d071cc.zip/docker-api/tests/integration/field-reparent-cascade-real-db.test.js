'use strict';

/**
 * field-reparent-cascade-real-db.test.js — the gate that decides whether the
 * reference cascade runs, measured against the value the statement actually
 * wrote.
 *
 * THE WHOLE HANDLER RUNS HERE, AGAINST A REAL ENGINE, AND THE ASSERTIONS ARE ON
 * STORED ROWS. Its sibling file captures the cascade's statements from a stubbed
 * connection and replays them, which answers "what do these statements do to a
 * database" but cannot answer "did the handler decide to issue them at all" —
 * a stub returns whatever the fixture was told to return, so a gate reading one
 * value while the UPDATE writes another looks identical to a gate reading the
 * right one. That divergence is this path's recurring defect, so the question is
 * put to the database: send the request, then read the rows.
 *
 * The case that produced this file: a body carrying `blueprint_id: null` moved
 * the field out of every blueprint while the gate — reading a value that had the
 * stored id substituted for the null — answered "the blueprint did not change",
 * so the cascade repointed every reference sitting in the blueprint the same
 * write was removing the field from. That body no longer reaches the statement:
 * the destination check refuses a blueprint nobody may write to, and a null
 * names none, so the request is answered 404 before anything is written. The
 * first test below is what holds that closed — the cascade's reparent skip is
 * the second lock on the same door, and if the destination check is ever
 * loosened, this is the assertion that says the skip is load-bearing again.
 *
 * IDENTIFIERS ARE REAL UUIDS THROUGHOUT, and that is not tidiness. The write
 * path refuses a body binding anything else to an identifier column, because
 * MariaDB compares a CHAR column against a non-string in numeric context and
 * matches an arbitrary set of rows. A fixture spelling a blueprint `bp-a` is
 * answered 400 and never reaches the behaviour under test.
 *
 * Skips with a stated reason when no database is reachable, and fails instead of
 * skipping when REQUIRE_INTEGRATION_DB=1.
 */
const { test, describe, before, after, beforeEach } = require('node:test');
const { makeStubReqLog } = require('../helpers/stub-req-log');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const net = require('node:net');
const http = require('node:http');
const express = require('express');
const mariadb = require('mariadb');

const TEST_PREFIX = 'frc_';
const tbl = (name) => `${TEST_PREFIX}${name}`;

let pool = null;
const lease = () => pool.getConnection();

const dbKey = require.resolve('../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey,
  filename: dbKey,
  loaded: true,
  exports: {
    pool: { ro: { getConnection: lease }, rw: { getConnection: lease } },
    t: tbl,
    getDynamicPool: async () => ({ ro: { getConnection: lease }, rw: { getConnection: lease } }),
  },
};

const { buildAllTableDDLs } = require('../../src/table-ddls');
const schemaRouter = require('../../src/edge/routes/app/schema');

// ── Config auto-detection (same shape as the sibling integration tests) ──────

function parseEnvFile(filePath) {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    const out = {};
    for (const line of content.split('\n')) {
      const m = line.match(/^\s*([A-Z_][A-Z0-9_]*)\s*=\s*(.*)\s*$/);
      if (!m) continue;
      let value = m[2];
      if ((value.startsWith('"') && value.endsWith('"'))
        || (value.startsWith("'") && value.endsWith("'"))) {
        value = value.slice(1, -1);
      }
      out[m[1]] = value;
    }
    return out;
  } catch {
    return null;
  }
}

function probePort(host, port, timeoutMs = 2000) {
  return new Promise((resolve) => {
    const socket = new net.Socket();
    let done = false;
    const finish = (ok) => {
      if (done) return;
      done = true;
      socket.destroy();
      resolve(ok);
    };
    socket.setTimeout(timeoutMs);
    socket.once('connect', () => finish(true));
    socket.once('timeout', () => finish(false));
    socket.once('error', () => finish(false));
    socket.connect(port, host);
  });
}

async function resolveMariaDbConfig() {
  if (process.env.DB_TEST_HOST && process.env.DB_TEST_ROOT_PASSWORD) {
    return {
      host: process.env.DB_TEST_HOST,
      port: parseInt(process.env.DB_TEST_PORT || '3306', 10),
      user: 'root',
      password: process.env.DB_TEST_ROOT_PASSWORD,
    };
  }
  const envPath = path.resolve(__dirname, '../../../.devcontainer/.env');
  const env = parseEnvFile(envPath);
  if (!env || !env.DB_ROOT_PASSWORD) return null;
  const port = parseInt(env.DB_PORT || '3306', 10);
  for (const host of ['127.0.0.1', 'mariadb', 'localhost']) {
    if (await probePort(host, port, 2000)) {
      return { host, port, user: 'root', password: env.DB_ROOT_PASSWORD };
    }
  }
  return null;
}

// ── Fixture ─────────────────────────────────────────────────────────────────

const ADMIN = { id: '00000000-0000-4000-8000-00000000ad00', role: 'admin' };
// Hex LETTERS on purpose: the case-folding test below respells this id and needs
// the two spellings to differ byte for byte. An all-digit uuid upper-cases to
// itself, and the probe it is meant to exercise short-circuits on byte equality
// without ever asking the engine — the test would pass while measuring nothing.
const BP = 'a1b2c3d4-e5f6-4a7b-8c9d-0e1f2a3b4c5d';
const OTHER_BP = 'b2c3d4e5-f6a7-4b8c-9d0e-1f2a3b4c5d6e';
const SUBJECT = 'c3d4e5f6-a7b8-4c9d-8e1f-2a3b4c5d6e7f';
const CHILD = 'd4e5f6a7-b8c9-4d0e-9f2a-3b4c5d6e7f80';
const VIS = 'e5f6a7b8-c9d0-4e1f-8a3b-4c5d6e7f8091';
const OLD_KEY = 'city';
const NEW_KEY = 'region';

let dbReady = false;
let skipReason = null;
let testDbName = null;
let server = null;
let baseUrl = null;

before(async () => {
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) {
    skipReason = 'no MariaDB reachable via .devcontainer/.env or env vars';
    if (process.env.REQUIRE_INTEGRATION_DB === '1') {
      throw new Error(`REQUIRE_INTEGRATION_DB=1 set but ${skipReason}.`);
    }
    return;
  }
  testDbName = `field_reparent_test_${process.pid}_${Date.now()}`;
  let admin = null;
  try {
    admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`CREATE DATABASE \`${testDbName}\``);
    await admin.query(`USE \`${testDbName}\``);
    // The repo's own DDLs, whole: the handler probes information_schema for the
    // columns it may name, so a hand-written subset would change which branch
    // runs before any assertion here got a chance to be wrong.
    for (const sql of buildAllTableDDLs(tbl)) await admin.query(sql);
    await admin.end();
    admin = null;

    pool = mariadb.createPool({
      ...dbConfig, database: testDbName, connectionLimit: 4, connectTimeout: 5000,
    });

    const app = express();
    app.use((req, _res, next) => { req.log = makeStubReqLog(); next(); }); // TEST-ONLY: production always sets req.log via createRequestId (request-id.js) before any router; this bare app has no such middleware, so a route's req.log.<level>() call would otherwise throw against undefined.
    app.use(express.json());
    app.use((req, _res, next) => { req.user = ADMIN; next(); });
    app.use('/edge/app/schema', schemaRouter);
    server = http.createServer(app);
    await new Promise((r) => server.listen(0, r));
    baseUrl = `http://127.0.0.1:${server.address().port}`;
    dbReady = true;
  } catch (err) {
    skipReason = `setup failed: ${err.message}`;
    if (admin) { try { await admin.end(); } catch { /* best effort */ } }
    if (process.env.REQUIRE_INTEGRATION_DB === '1') throw err;
  }
});

after(async () => {
  if (server) { try { server.close(); } catch { /* best effort */ } }
  if (pool) { try { await pool.end(); } catch { /* best effort */ } }
  if (!testDbName) return;
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) return;
  try {
    const admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`DROP DATABASE IF EXISTS \`${testDbName}\``);
    await admin.end();
  } catch { /* best effort */ }
});

const guard = (t) => {
  if (!dbReady) { t.skip(skipReason || 'database not ready'); return true; }
  return false;
};

beforeEach(async () => {
  if (!dbReady) return;
  await pool.query(`DELETE FROM \`${tbl('blueprint_fields')}\``);
  await pool.query(`DELETE FROM \`${tbl('hierarchy_nodes')}\``);
  for (const [id, name] of [[BP, 'Blueprint A'], [OTHER_BP, 'Blueprint B']]) {
    await pool.query(
      `INSERT INTO \`${tbl('hierarchy_nodes')}\` (id, name, node_type) VALUES (?, ?, 'blueprint')`,
      [id, name],
    );
  }
  // The subject of the rename, plus the two shapes a sibling names it by: a
  // column holding the key, and a key at a fixed path inside a JSON document.
  const rows = [
    [SUBJECT, BP, OLD_KEY, 'text', null, null],
    [CHILD, BP, 'child', 'select', OLD_KEY, null],
    [VIS, BP, 'warn', 'text', null,
      JSON.stringify({ field_key: OLD_KEY, operator: 'eq', value: 'yes' })],
  ];
  for (const row of rows) {
    await pool.query(
      `INSERT INTO \`${tbl('blueprint_fields')}\`
         (id, blueprint_id, field_key, field_type, depends_on_field_key, visibility_rule)
       VALUES (?, ?, ?, ?, ?, ?)`,
      row,
    );
  }
});

async function putField(id, body) {
  const res = await fetch(`${baseUrl}/edge/app/schema/blueprint_fields/${id}`, {
    method: 'PUT',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
  });
  const text = await res.text();
  let parsed = null;
  try { parsed = JSON.parse(text); } catch { parsed = { raw: text }; }
  return { status: res.status, body: parsed };
}

async function storedFields() {
  const rows = await pool.query(
    `SELECT id, blueprint_id, field_key, depends_on_field_key AS parent,
            CAST(visibility_rule AS CHAR) AS rule
       FROM \`${tbl('blueprint_fields')}\` ORDER BY id`,
  );
  return new Map(rows.map((r) => [r.id, r]));
}

const ruleSubject = (row) => (row.rule == null ? null : JSON.parse(row.rule).field_key);

describe('the reference cascade and the blueprint the write actually leaves the field in', () => {
  test('a body that would move the field out of every blueprint writes nothing at all', async (t) => {
    if (guard(t)) return;
    // `blueprint_id` is nullable, so this body once reached the UPDATE verbatim
    // and moved the field out of every blueprint — while a gate that had the
    // stored id substituted for the null answered "the blueprint did not
    // change", and the cascade then repointed every reference sitting in the
    // blueprint the same write was emptying. Nothing errored and the response
    // was 200.
    //
    // The write path now refuses it earlier and for a reason that is about the
    // DESTINATION rather than about this cascade: the column carries no foreign
    // key, so the blueprint a write puts a row under is checked, and a null
    // names no blueprint any caller may write to. Asserted on the STORED ROWS
    // and not on the status alone, because "refused" and "refused after writing
    // half of it" are the same status code.
    const res = await putField(SUBJECT, { field_key: NEW_KEY, blueprint_id: null });
    assert.equal(res.status, 404, `expected the destination check to refuse: ${JSON.stringify(res.body)}`);

    const after = await storedFields();
    assert.equal(after.get(SUBJECT).blueprint_id, BP, 'the field left its blueprint anyway');
    assert.equal(after.get(SUBJECT).field_key, OLD_KEY, 'the key was renamed by a refused write');
    assert.equal(
      after.get(CHILD).parent, OLD_KEY,
      'a reference in the blueprint the field would have left was repointed at the new key',
    );
    assert.equal(
      ruleSubject(after.get(VIS)), OLD_KEY,
      'a display condition in that blueprint was repointed at the new key',
    );
  });

  test('an ordinary rename in place still takes the references with it', async (t) => {
    if (guard(t)) return;
    // The control the case above must not be bought with: the whole point of
    // the cascade is that this one moves. Refusing to run it at all would
    // satisfy every "did not repoint" assertion in this file.
    const res = await putField(SUBJECT, { field_key: NEW_KEY, blueprint_id: BP });
    assert.equal(res.status, 200, `the rename was refused: ${JSON.stringify(res.body)}`);

    const after = await storedFields();
    assert.equal(after.get(SUBJECT).field_key, NEW_KEY);
    assert.equal(after.get(CHILD).parent, NEW_KEY, 'the dependent picker\'s parent did not follow');
    assert.equal(ruleSubject(after.get(VIS)), NEW_KEY, 'the display condition\'s subject did not follow');
  });

  test('a genuine move to another blueprint leaves the old blueprint\'s references alone', async (t) => {
    if (guard(t)) return;
    const res = await putField(SUBJECT, { field_key: NEW_KEY, blueprint_id: OTHER_BP });
    assert.equal(res.status, 200, `the rename was refused: ${JSON.stringify(res.body)}`);

    const after = await storedFields();
    assert.equal(after.get(SUBJECT).blueprint_id, OTHER_BP);
    assert.equal(after.get(CHILD).parent, OLD_KEY);
    assert.equal(ruleSubject(after.get(VIS)), OLD_KEY);
  });

  test('an id spelled with different capitalisation is the same blueprint, so the references move', async (t) => {
    if (guard(t)) return;
    // `blueprint_id` is CHAR(36) under utf8mb4_general_ci, so this body names
    // the blueprint the field is already in — the database is what decides that,
    // and a JavaScript `!==` disagrees with it. Read as a move, the cascade is
    // skipped on what is an ordinary rename and every reference is stranded.
    const res = await putField(SUBJECT, { field_key: NEW_KEY, blueprint_id: BP.toUpperCase() });
    assert.equal(res.status, 200, `the rename was refused: ${JSON.stringify(res.body)}`);

    const after = await storedFields();
    assert.equal(
      after.get(CHILD).parent, NEW_KEY,
      'the field never left the blueprint, but its references were treated as if it had',
    );
    assert.equal(ruleSubject(after.get(VIS)), NEW_KEY);
    assert.equal(
      after.get(SUBJECT).blueprint_id, BP,
      'the stored id took the body\'s spelling; every JavaScript reader comparing it '
      + 'with the blueprint\'s own id now reads the field as belonging elsewhere',
    );
  });

  test('a null field key is refused by the column and nothing moves', async (t) => {
    if (guard(t)) return;
    // The other nullable-looking value on this path. `field_key` is NOT NULL, so
    // the statement cannot land — what this pins is that the refusal happens
    // before anything else does: no reference statement runs, and the row is
    // exactly as it was. If the column ever becomes nullable, this goes red
    // beside the gate that would then need to read the null.
    const res = await putField(SUBJECT, { field_key: null, field_label: 'Subject' });
    assert.notEqual(res.status, 200, `a null key was accepted: ${JSON.stringify(res.body)}`);

    const after = await storedFields();
    assert.equal(after.get(SUBJECT).field_key, OLD_KEY, 'the field key was written as null');
    assert.equal(after.get(CHILD).parent, OLD_KEY);
    assert.equal(ruleSubject(after.get(VIS)), OLD_KEY);
  });
});
