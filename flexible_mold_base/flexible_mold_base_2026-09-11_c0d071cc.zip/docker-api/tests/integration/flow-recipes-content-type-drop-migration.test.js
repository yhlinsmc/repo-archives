'use strict';

/**
 * flow-recipes-content-type-drop-migration.test.js — the PR-YZ Task Z.0
 * migration step (`flow_recipes_content_type_drop`, fmb-2062) proven against
 * a real scratch MariaDB in each of its schema states, not mocked:
 *
 *   (i)   step dialect columns present + recipe column present, backfill
 *         already caught up (the transitional window between PR-Y2 and this
 *         drop rolling out) — run() actually drops the column; probe()
 *         is satisfied afterwards.
 *   (ii)  step dialect columns ABSENT (a permanently no-ALTER install,
 *         fmb-1329 Q9 / fmb-2061 Y2.6c) — probe() is satisfied WITHOUT
 *         dropping; the recipe column still exists afterwards (Y2.6c's
 *         legacy tier depends on it staying readable forever).
 *   (iii) the recipe column is already absent (a fresh install, or a DB that
 *         already ran this step) — probe() is satisfied; run() is a no-op.
 *   (iv)  step dialect columns present + a YAML recipe whose step(s) still
 *         carry the DDL DEFAULT (the 3.2.972 backfill hasn't caught this
 *         recipe up yet — review batch 1, fmb-2062) — probe() is NOT
 *         satisfied and run() REFUSES (throws) instead of dropping; once the
 *         backfill catches up, run() proceeds.
 *   (v)   mid-tier: only some (not zero, not all three) of the step dialect
 *         columns present — same by-design "keep the column" outcome as (ii).
 *
 * Skips with a stated reason when no database is reachable, and fails
 * instead of skipping when REQUIRE_INTEGRATION_DB=1.
 */
const { test, describe, before, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const net = require('node:net');
const crypto = require('node:crypto');
const mariadb = require('mariadb');

const { buildEngineTableDDLs, buildInfraTableDDLs } = require('../../src/table-ddls');
const { TABLES } = require('../../src/shared/constants');
const { MIGRATION_STEPS } = require('../../src/edge/migration-steps');

const TEST_PREFIX = 'fcd_';
const tbl = (name) => `${TEST_PREFIX}${name}`;

const WANTED_TABLES = [TABLES.FLOW_RECIPES, TABLES.FLOW_RECIPE_STEPS, TABLES.HIERARCHY_NODES];
const LEGACY_RECIPE_CONTENT_TYPE_DDL = "content_type ENUM('application/json','application/yaml') NOT NULL DEFAULT 'application/json'";
const STEP_DIALECT_COLUMNS = ['content_type', 'yaml_version', 'yaml_quoting'];

function parseEnvFile(filePath) {
  try {
    const raw = fs.readFileSync(filePath, 'utf8');
    const out = {};
    for (const line of raw.split('\n')) {
      const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
      if (m) out[m[1]] = m[2].replace(/^["']|["']$/g, '');
    }
    return out;
  } catch {
    return null;
  }
}

function probePort(host, port, timeoutMs = 2000) {
  return new Promise((resolve) => {
    const socket = new net.Socket();
    let done = false;
    const finish = (ok) => {
      if (done) return;
      done = true;
      socket.destroy();
      resolve(ok);
    };
    socket.setTimeout(timeoutMs);
    socket.once('connect', () => finish(true));
    socket.once('timeout', () => finish(false));
    socket.once('error', () => finish(false));
    socket.connect(port, host);
  });
}

async function resolveMariaDbConfig() {
  if (process.env.DB_TEST_HOST && process.env.DB_TEST_ROOT_PASSWORD) {
    return {
      host: process.env.DB_TEST_HOST,
      port: parseInt(process.env.DB_TEST_PORT || '3306', 10),
      user: 'root',
      password: process.env.DB_TEST_ROOT_PASSWORD,
    };
  }
  const envPath = path.resolve(__dirname, '../../../.devcontainer/.env');
  const env = parseEnvFile(envPath);
  if (!env || !env.DB_ROOT_PASSWORD) return null;
  const port = parseInt(env.DB_PORT || '3306', 10);
  for (const host of ['127.0.0.1', 'mariadb', 'localhost']) {
    if (await probePort(host, port, 2000)) {
      return { host, port, user: 'root', password: env.DB_ROOT_PASSWORD };
    }
  }
  return null;
}

const entry = MIGRATION_STEPS.find((s) => s.step === 'flow_recipes_content_type_drop');

let dbReady = false;
let skipReason = null;
let dbConfig = null;

before(async () => {
  dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) {
    skipReason = 'no MariaDB reachable via .devcontainer/.env or env vars';
    if (process.env.REQUIRE_INTEGRATION_DB === '1') {
      throw new Error(`REQUIRE_INTEGRATION_DB=1 set but ${skipReason}.`);
    }
    return;
  }
  dbReady = true;
});

const guard = (t) => {
  if (!dbReady) { t.skip(skipReason || 'database not ready'); return true; }
  return false;
};

/** Creates a scratch DB with flow_recipes/flow_recipe_steps/hierarchy_nodes,
 *  optionally re-adding the legacy recipe column and/or dropping the three
 *  step dialect columns (all of them via withStepColumns:false, or a named
 *  subset via dropOnlyStepColumns for the mid-tier fixture), and returns a
 *  pool + a cleanup function. */
async function makeScratchDb(name, { withRecipeColumn, withStepColumns, dropOnlyStepColumns }) {
  const dbName = `${name}_${process.pid}_${Date.now()}`;
  const admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
  await admin.query(`CREATE DATABASE \`${dbName}\``);
  await admin.query(`USE \`${dbName}\``);
  const wanted = new Set(WANTED_TABLES.map(tbl));
  const statements = [...buildInfraTableDDLs(tbl), ...buildEngineTableDDLs(tbl)].filter((sql) => {
    const m = sql.match(/CREATE TABLE IF NOT EXISTS `([^`]+)`/);
    return m && wanted.has(m[1]);
  });
  assert.equal(statements.length, wanted.size, `the DDL list no longer defines all of: ${[...wanted].join(', ')}`);
  for (const sql of statements) await admin.query(sql);
  if (withRecipeColumn) {
    await admin.query(`ALTER TABLE \`${tbl(TABLES.FLOW_RECIPES)}\` ADD COLUMN ${LEGACY_RECIPE_CONTENT_TYPE_DDL}`);
  }
  if (dropOnlyStepColumns) {
    for (const col of dropOnlyStepColumns) {
      await admin.query(`ALTER TABLE \`${tbl(TABLES.FLOW_RECIPE_STEPS)}\` DROP COLUMN \`${col}\``);
    }
  } else if (!withStepColumns) {
    for (const col of STEP_DIALECT_COLUMNS) {
      await admin.query(`ALTER TABLE \`${tbl(TABLES.FLOW_RECIPE_STEPS)}\` DROP COLUMN \`${col}\``);
    }
  }
  await admin.end();
  const pool = mariadb.createPool({ ...dbConfig, database: dbName, connectionLimit: 4, connectTimeout: 5000 });
  return {
    pool,
    async cleanup() {
      try { await pool.end(); } catch { /* best effort */ }
      const a = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
      try { await a.query(`DROP DATABASE IF EXISTS \`${dbName}\``); } finally { await a.end(); }
    },
  };
}

async function recipeHasContentType(conn) {
  const rows = await conn.query(
    `SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = 'content_type'`,
    [tbl(TABLES.FLOW_RECIPES)],
  );
  return rows.length > 0;
}

describe('flow_recipes_content_type_drop migration step — real-DB probe/run', () => {
  test('registry entry sanity', (t) => {
    if (guard(t)) return;
    assert.ok(entry, 'migration-steps.js no longer declares flow_recipes_content_type_drop');
    assert.equal(entry.kind, 'custom');
  });

  test('(i) step columns present + recipe column present — run drops it, probe becomes satisfied', async (t) => {
    if (guard(t)) return;
    const db = await makeScratchDb(tbl('mig_i'), { withRecipeColumn: true, withStepColumns: true });
    try {
      const conn = await db.pool.getConnection();
      try {
        assert.equal(await recipeHasContentType(conn), true, 'fixture setup failed: recipe column missing before run');
        assert.equal(await entry.probe(conn, tbl), false, 'probe must NOT be satisfied while the column is present and the step columns exist');
        await entry.run({ conn, t: tbl, TABLES, logger: null });
        assert.equal(await recipeHasContentType(conn), false, 'run() did not drop flow_recipes.content_type');
        assert.equal(await entry.probe(conn, tbl), true, 'probe must be satisfied once the column is gone');
        // Idempotent: a second run is a no-op, probe stays satisfied.
        await entry.run({ conn, t: tbl, TABLES, logger: null });
        assert.equal(await entry.probe(conn, tbl), true);
      } finally {
        conn.release();
      }
    } finally {
      await db.cleanup();
    }
  });

  test('(ii) step columns ABSENT (no-ALTER install) — probe satisfied WITHOUT dropping, the recipe column survives', async (t) => {
    if (guard(t)) return;
    const db = await makeScratchDb(tbl('mig_ii'), { withRecipeColumn: true, withStepColumns: false });
    try {
      const conn = await db.pool.getConnection();
      try {
        assert.equal(await recipeHasContentType(conn), true, 'fixture setup failed: recipe column missing before run');
        assert.equal(await entry.probe(conn, tbl), true, 'probe must already report satisfied on a permanently no-ALTER install — nothing to do, not failed');
        await entry.run({ conn, t: tbl, TABLES, logger: null });
        assert.equal(
          await recipeHasContentType(conn), true,
          'run() must NOT drop the column on a no-ALTER install — Y2.6c\'s legacy tier reads it forever',
        );
      } finally {
        conn.release();
      }
    } finally {
      await db.cleanup();
    }
  });

  test('(iii) recipe column already absent — probe satisfied, run is a no-op', async (t) => {
    if (guard(t)) return;
    // A fresh install per the CURRENT table-ddls.js never had the recipe
    // column at all — withRecipeColumn:false reproduces that directly.
    const db = await makeScratchDb(tbl('mig_iii'), { withRecipeColumn: false, withStepColumns: true });
    try {
      const conn = await db.pool.getConnection();
      try {
        assert.equal(await recipeHasContentType(conn), false, 'fixture setup failed: recipe column unexpectedly present');
        assert.equal(await entry.probe(conn, tbl), true, 'probe must be satisfied when the column is already gone');
        await entry.run({ conn, t: tbl, TABLES, logger: null });
        assert.equal(await recipeHasContentType(conn), false, 'run() must stay a no-op when there is nothing to drop');
      } finally {
        conn.release();
      }
    } finally {
      await db.cleanup();
    }
  });

  // Review batch 1 (fmb-2062) HIGH: the drop's probe checked column
  // structure only, never whether <PATCH-Y1>'s data backfill had actually
  // finished — a YAML recipe whose steps were still stuck at the ENUM
  // DEFAULT 'application/json' would have its last recovery source (this
  // very column) dropped out from under it.
  test('(iv) YAML recipe backfill pending — probe not satisfied, run REFUSES (throws) instead of dropping; converges once the backfill catches up', async (t) => {
    if (guard(t)) return;
    const db = await makeScratchDb(tbl('mig_iv'), { withRecipeColumn: true, withStepColumns: true });
    try {
      const conn = await db.pool.getConnection();
      try {
        const recipeId = crypto.randomUUID();
        const stepId = crypto.randomUUID();
        await conn.query(
          `INSERT INTO \`${tbl(TABLES.FLOW_RECIPES)}\` (id, name, content_type) VALUES (?, 'pending-backfill recipe', 'application/yaml')`,
          [recipeId],
        );
        // No content_type override on the step — it stays at the DDL DEFAULT
        // 'application/json', exactly what an interrupted 3.2.972 backfill
        // leaves behind.
        await conn.query(
          `INSERT INTO \`${tbl(TABLES.FLOW_RECIPE_STEPS)}\` (id, recipe_id, name, url) VALUES (?, ?, 'step', 'https://example.test')`,
          [stepId, recipeId],
        );

        assert.equal(
          await entry.probe(conn, tbl), false,
          'probe must not be satisfied while the recipe+step columns are both present (structural-only, unrelated to this case)',
        );
        await assert.rejects(
          () => entry.run({ conn, t: tbl, TABLES, logger: null }),
          /backfill/i,
          'run() must throw (not silently no-op) while a YAML recipe still has a step at the DDL default, so the executor holds the version stamp',
        );
        assert.equal(
          await recipeHasContentType(conn), true,
          'run() must leave the recipe column in place while the backfill is pending',
        );

        // Apply the 3.2.972 backfill directly (its own step, not hand-rolled SQL).
        const backfillEntry = MIGRATION_STEPS.find((s) => s.step === 'flow_recipe_steps_content_type_backfill');
        assert.ok(backfillEntry, 'migration-steps.js no longer declares flow_recipe_steps_content_type_backfill');
        await backfillEntry.run({ conn, t: tbl, TABLES, logger: null });

        await entry.run({ conn, t: tbl, TABLES, logger: null });
        assert.equal(
          await recipeHasContentType(conn), false,
          'run() must drop the column once the backfill has caught up',
        );
      } finally {
        conn.release();
      }
    } finally {
      await db.cleanup();
    }
  });

  // LOW (fmb-2062): the `stepCols.length < 3` branch was only ever exercised
  // at its two extremes (0 or 3 columns) — a mid-tier install (some but not
  // all three columns present) hit the same branch untested.
  test('(v) mid-tier: only two of three step dialect columns present (yaml_quoting dropped) — probe satisfied, column kept, same as all-three-absent', async (t) => {
    if (guard(t)) return;
    const db = await makeScratchDb(tbl('mig_v'), {
      withRecipeColumn: true,
      withStepColumns: true,
      dropOnlyStepColumns: ['yaml_quoting'],
    });
    try {
      const conn = await db.pool.getConnection();
      try {
        assert.equal(await recipeHasContentType(conn), true, 'fixture setup failed: recipe column missing before run');
        assert.equal(
          await entry.probe(conn, tbl), true,
          'probe must be satisfied when even one of the three step dialect columns is missing — same by-design no-ALTER outcome as all three missing',
        );
        await entry.run({ conn, t: tbl, TABLES, logger: null });
        assert.equal(
          await recipeHasContentType(conn), true,
          'run() must not drop the column when the step columns are only partially present',
        );
      } finally {
        conn.release();
      }
    } finally {
      await db.cleanup();
    }
  });
});
