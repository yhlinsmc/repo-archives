'use strict';

/**
 * delegated-grants-predicate-real-db.test.js — the permission predicate, run.
 *
 * WHY THIS EXISTS BESIDE THE MOCKED ENFORCEMENT TEST. That file proves the arm
 * is in the statement and bound to the caller; a stubbed driver cannot evaluate
 * SQL, so a predicate that is well-formed and wrong passes it. This one creates
 * the real tables from the real DDL builder, seeds a fixture, and runs the real
 * `UPDATE … WHERE id = ? AND (owner_id = ? OR <predicate>)` — the same statement
 * the shared update path builds — for every combination that decides who may
 * write: owner, stranger, template grant, blueprint grant, a grant pointing at
 * the wrong tier, a grant whose blueprint was deleted, a template with no
 * blueprint at all, and the same grant after it is revoked.
 *
 * It also holds the TWO implementations of one rule to agreeing with each other.
 * The update path asks the question as a predicate; dispatch asks it as a
 * statement of its own, because it has already read the template. Two spellings
 * of one permission are two things that can drift, so every fixture below is put
 * to both and their answers compared.
 *
 * Creating the tables from `buildEngineTableDDLs` rather than from a local copy
 * is deliberate: it is the only place in the suite where the new DDL is executed
 * by a database, so a syntax error or an index that MariaDB refuses fails here
 * rather than at somebody's boot.
 *
 * Skips with a stated reason when no database is reachable, and fails instead of
 * skipping when REQUIRE_INTEGRATION_DB=1.
 */
const { test, describe, before, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const net = require('node:net');
const mariadb = require('mariadb');

const TEST_PREFIX = 'dgp_';
const tbl = (name) => `${TEST_PREFIX}${name}`;

// The production modules resolve their table names through `t()` at call time.
// Pointing that at the test prefix BEFORE they are required is what lets this
// file exercise the shipped predicate builder rather than a copy of it.
const dbKey = require.resolve('../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey,
  filename: dbKey,
  loaded: true,
  exports: {
    pool: { ro: null, rw: null },
    t: tbl,
    getDynamicPool: async () => ({ ro: null, rw: null }),
  },
};

const { buildEngineTableDDLs } = require('../../src/table-ddls');
const { TABLES } = require('../../src/shared/constants');
const {
  buildTemplateAccessExists, callerHasTemplateAccess, callerHasBlueprintGrant, GRANT_SCOPE_COLUMN,
  grantEligibleRole, _resetGrantsTableCache,
} = require('../../src/edge/lib/delegated-grants');

// ── Config auto-detection (same shape as the sibling integration tests) ──────

function parseEnvFile(filePath) {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    const out = {};
    for (const line of content.split('\n')) {
      const m = line.match(/^\s*([A-Z_][A-Z0-9_]*)\s*=\s*(.*)\s*$/);
      if (!m) continue;
      let value = m[2];
      if ((value.startsWith('"') && value.endsWith('"'))
        || (value.startsWith("'") && value.endsWith("'"))) {
        value = value.slice(1, -1);
      }
      out[m[1]] = value;
    }
    return out;
  } catch {
    return null;
  }
}

function probePort(host, port, timeoutMs = 2000) {
  return new Promise((resolve) => {
    const socket = new net.Socket();
    let done = false;
    const finish = (ok) => {
      if (done) return;
      done = true;
      socket.destroy();
      resolve(ok);
    };
    socket.setTimeout(timeoutMs);
    socket.once('connect', () => finish(true));
    socket.once('timeout', () => finish(false));
    socket.once('error', () => finish(false));
    socket.connect(port, host);
  });
}

async function resolveMariaDbConfig() {
  if (process.env.DB_TEST_HOST && process.env.DB_TEST_ROOT_PASSWORD) {
    return {
      host: process.env.DB_TEST_HOST,
      port: parseInt(process.env.DB_TEST_PORT || '3306', 10),
      user: 'root',
      password: process.env.DB_TEST_ROOT_PASSWORD,
    };
  }
  const envPath = path.resolve(__dirname, '../../../.devcontainer/.env');
  const env = parseEnvFile(envPath);
  if (!env || !env.DB_ROOT_PASSWORD) return null;
  const port = parseInt(env.DB_PORT || '3306', 10);
  for (const host of ['127.0.0.1', 'mariadb', 'localhost']) {
    if (await probePort(host, port, 2000)) {
      return { host, port, user: 'root', password: env.DB_ROOT_PASSWORD };
    }
  }
  return null;
}

// ── Fixture ─────────────────────────────────────────────────────────────────

const OWNER = 'u-owner';
const GRANTEE = 'u-grantee';
const STRANGER = 'u-stranger';
const BP_OWNER = 'u-bp-owner';  // owns BP3 and nothing else
const BP1 = 'bp-1';
const BP2 = 'bp-2';
const BP3 = 'bp-3';             // owned by somebody who owns none of the records
const BP_GONE = 'bp-deleted';
const CATEGORY = 'cat-1';
const CAT2 = 'cat-2';           // a category that a record MIS-NAMES as its blueprint
const CAT_OWNER = 'u-cat-owner';  // owns CAT2 and nothing else
const T1 = 'tpl-1';       // under BP1
const T2 = 'tpl-2';       // under BP2
const T_ORPHAN = 'tpl-3'; // blueprint_id points at a node that no longer exists
const T_NULL = 'tpl-4';   // no blueprint at all
const T_UNDER_BP3 = 'tpl-5';  // owned by OWNER, under somebody else's blueprint
const T_SHARED = 'tpl-6';     // under BP1, owned by NOBODY — the seeded case
const T_UNDER_CAT = 'tpl-7';  // owned by OWNER, blueprint_id naming CAT2

let dbReady = false;
let skipReason = null;
let testDbName = null;
let pool = null;

/** The three tables this fixture needs, taken from the shipped DDL list. */
function ddlFor(...tables) {
  const wanted = new Set(tables.map((n) => tbl(n)));
  return buildEngineTableDDLs(tbl).filter((sql) => {
    const m = sql.match(/CREATE TABLE IF NOT EXISTS `([^`]+)`/);
    return m && wanted.has(m[1]);
  });
}

before(async () => {
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) {
    skipReason = 'no MariaDB reachable via .devcontainer/.env or env vars';
    if (process.env.REQUIRE_INTEGRATION_DB === '1') {
      throw new Error(`REQUIRE_INTEGRATION_DB=1 set but ${skipReason}.`);
    }
    return;
  }
  testDbName = `dg_predicate_test_${process.pid}_${Date.now()}`;
  let admin = null;
  try {
    admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`CREATE DATABASE \`${testDbName}\``);
    await admin.query(`USE \`${testDbName}\``);
    const statements = ddlFor(
      TABLES.HIERARCHY_NODES, TABLES.USER_TEMPLATES, TABLES.DELEGATED_GRANTS,
    );
    assert.equal(statements.length, 3, 'the DDL list no longer defines all three tables');
    for (const sql of statements) await admin.query(sql);

    await admin.query(
      `INSERT INTO \`${tbl('hierarchy_nodes')}\` (id, name, node_type, owner_id) VALUES
       (?, 'BP1', 'blueprint', ?), (?, 'BP2', 'blueprint', ?), (?, 'CAT', 'category', ?),
       (?, 'BP3', 'blueprint', ?), (?, 'CAT2', 'category', ?)`,
      [BP1, OWNER, BP2, OWNER, CATEGORY, OWNER, BP3, BP_OWNER, CAT2, CAT_OWNER],
    );
    await admin.query(
      `INSERT INTO \`${tbl('user_templates')}\` (id, name, blueprint_id, owner_id) VALUES
       (?, 'one', ?, ?), (?, 'two', ?, ?), (?, 'three', ?, ?), (?, 'four', NULL, ?),
       (?, 'five', ?, ?), (?, 'six', ?, NULL), (?, 'seven', ?, ?)`,
      [
        T1, BP1, OWNER, T2, BP2, OWNER, T_ORPHAN, BP_GONE, OWNER, T_NULL, OWNER,
        T_UNDER_BP3, BP3, OWNER, T_SHARED, BP1, T_UNDER_CAT, CAT2, OWNER,
      ],
    );
    await admin.end();
    admin = null;
    pool = mariadb.createPool({
      ...dbConfig, database: testDbName, connectionLimit: 4, connectTimeout: 5000,
    });
    _resetGrantsTableCache();
    dbReady = true;
  } catch (err) {
    skipReason = `setup failed: ${err.message}`;
    if (admin) { try { await admin.end(); } catch { /* best effort */ } }
    if (process.env.REQUIRE_INTEGRATION_DB === '1') throw err;
  }
});

after(async () => {
  if (pool) { try { await pool.end(); } catch { /* best effort */ } }
  if (!testDbName) return;
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) return;
  try {
    const admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`DROP DATABASE IF EXISTS \`${testDbName}\``);
    await admin.end();
  } catch { /* best effort */ }
});

// ── The statement under test ────────────────────────────────────────────────

/**
 * The shared update path's statement, assembled here exactly as the factory
 * assembles it: the ownership check and the delegated arm inside one group.
 */
async function updateAs(conn, callerId, templateId, value) {
  const granted = buildTemplateAccessExists(`\`${tbl('user_templates')}\``);
  const res = await conn.query(
    `UPDATE \`${tbl('user_templates')}\` SET \`name\` = ?`
    + ` WHERE id = ? AND (\`owner_id\` = ? OR ${granted.sql})`,
    [value, templateId, callerId, ...Array(granted.paramCount).fill(callerId)],
  );
  return Number(res.affectedRows || 0);
}

/**
 * The statement as the shared path builds it when the write CARRIES the column
 * a grant's reach is derived from — the delegated arm additionally requiring
 * that the write leaves that column where it is.
 */
async function moveAs(conn, callerId, templateId, toBlueprint) {
  const granted = buildTemplateAccessExists(`\`${tbl('user_templates')}\``);
  const res = await conn.query(
    `UPDATE \`${tbl('user_templates')}\` SET \`${GRANT_SCOPE_COLUMN}\` = ?`
    + ` WHERE id = ? AND (\`owner_id\` = ? OR (${granted.sql} AND \`${GRANT_SCOPE_COLUMN}\` <=> ?))`,
    [
      toBlueprint, templateId, callerId,
      ...Array(granted.paramCount).fill(callerId), toBlueprint,
    ],
  );
  return Number(res.affectedRows || 0);
}

async function grant(conn, scopeType, scopeId, granteeId) {
  await conn.query(
    `INSERT INTO \`${tbl('delegated_grants')}\` (id, scope_type, scope_id, grantee_id, granted_by)
     VALUES (?, ?, ?, ?, ?)`,
    [`g-${scopeType}-${scopeId}-${granteeId}`, scopeType, scopeId, granteeId, OWNER],
  );
}

async function revokeAll(conn) {
  await conn.query(`DELETE FROM \`${tbl('delegated_grants')}\``);
}

/**
 * Both spellings of the one rule, asked about the same subject. `role`
 * defaults to 'editor' — every fixture caller below (GRANTEE, BP_OWNER,
 * STRANGER, CAT_OWNER) is standing in for an editor's write, and `updateAs`'s
 * statement (`buildTemplateAccessExists` with its default `includeGrants`)
 * never gates on role either, so 'editor' is the caller this pair is already
 * measuring. The role-floor tests below pass a role explicitly.
 */
async function bothAnswers(conn, callerId, templateId, role = 'editor') {
  const rows = await conn.query(
    `SELECT blueprint_id, owner_id FROM \`${tbl('user_templates')}\` WHERE id = ?`, [templateId],
  );
  const viaPredicate = await updateAs(conn, callerId, templateId, `edited-${Date.now()}`);
  const viaStatement = await callerHasTemplateAccess(conn, callerId, {
    templateId,
    ownerId: rows[0] ? rows[0].owner_id : null,
    blueprintId: rows[0] ? rows[0].blueprint_id : null,
  }, role);
  return { matched: viaPredicate === 1, granted: viaStatement };
}

/**
 * The statement exactly as the ROUTE assembles it (grantWritePredicate /
 * run-begin's runGate): `includeGrants` is `grantEligibleRole(role)`, not the
 * builder's own default. This is what R-3-P1 actually changed — `updateAs`
 * above still measures the builder's bare default and is unchanged by it.
 */
async function updateAsRole(conn, callerId, templateId, value, role) {
  const granted = buildTemplateAccessExists(`\`${tbl('user_templates')}\``, {
    includeGrants: grantEligibleRole(role),
  });
  const res = await conn.query(
    `UPDATE \`${tbl('user_templates')}\` SET \`name\` = ?`
    + ` WHERE id = ? AND (\`owner_id\` = ? OR ${granted.sql})`,
    [value, templateId, callerId, ...Array(granted.paramCount).fill(callerId)],
  );
  return Number(res.affectedRows || 0);
}

/**
 * R-4-7: the statement with `callerRole` threaded through, exactly as
 * flow-recipes-run.js's runGate / reset-flow-link build it — the blueprint-
 * owner arm floored the same way the grant arms already were. `updateAsRole`
 * above only floors `includeGrants`; this is what tells the owner arm apart.
 */
async function updateAsCallerRole(conn, callerId, templateId, value, role) {
  const granted = buildTemplateAccessExists(`\`${tbl('user_templates')}\``, { callerRole: role });
  const res = await conn.query(
    `UPDATE \`${tbl('user_templates')}\` SET \`name\` = ?`
    + ` WHERE id = ? AND (\`owner_id\` = ? OR ${granted.sql})`,
    [value, templateId, callerId, ...Array(granted.paramCount).fill(callerId)],
  );
  return Number(res.affectedRows || 0);
}

describe('the grant predicate, evaluated by a database', () => {
  const guard = (t) => {
    if (!dbReady) { t.skip(skipReason || 'database not ready'); return true; }
    return false;
  };

  test('an owner matches their own record, with no grant anywhere', async (t) => {
    if (guard(t)) return;
    const conn = await pool.getConnection();
    try {
      await revokeAll(conn);
      assert.equal(await updateAs(conn, OWNER, T1, 'by the owner'), 1);
    } finally { conn.release(); }
  });

  test('a stranger with no grant matches nothing', async (t) => {
    if (guard(t)) return;
    const conn = await pool.getConnection();
    try {
      await revokeAll(conn);
      assert.equal(await updateAs(conn, STRANGER, T1, 'by a stranger'), 0);
    } finally { conn.release(); }
  });

  test('a grant on the record itself reaches that record and no other', async (t) => {
    if (guard(t)) return;
    const conn = await pool.getConnection();
    try {
      await revokeAll(conn);
      await grant(conn, 'template', T1, GRANTEE);
      assert.equal(await updateAs(conn, GRANTEE, T1, 'granted on this one'), 1);
      assert.equal(await updateAs(conn, GRANTEE, T2, 'but not this one'), 0);
    } finally { conn.release(); }
  });

  test('a grant on a blueprint reaches every record under it, and stops there', async (t) => {
    if (guard(t)) return;
    const conn = await pool.getConnection();
    try {
      await revokeAll(conn);
      await grant(conn, 'blueprint', BP1, GRANTEE);
      assert.equal(await updateAs(conn, GRANTEE, T1, 'under the granted blueprint'), 1);
      assert.equal(await updateAs(conn, GRANTEE, T2, 'under another blueprint'), 0);
    } finally { conn.release(); }
  });

  test('a grant naming a category grants nothing', async (t) => {
    if (guard(t)) return;
    // Every tier of the hierarchy carries an id and an owner. Without the
    // node_type check a grant on a category would reach every record beneath
    // it — a grant nobody made.
    const conn = await pool.getConnection();
    try {
      await revokeAll(conn);
      await grant(conn, 'blueprint', CATEGORY, GRANTEE);
      assert.equal(await updateAs(conn, GRANTEE, T1, 'via a category'), 0);
    } finally { conn.release(); }
  });

  test('a grant on a blueprint that no longer exists grants nothing', async (t) => {
    if (guard(t)) return;
    // The record still names the deleted blueprint. EXISTS is false for a
    // reference that does not resolve, so the grant fails closed rather than
    // outliving the subject it was made on — which is also the only place it
    // could have been revoked from.
    const conn = await pool.getConnection();
    try {
      await revokeAll(conn);
      await grant(conn, 'blueprint', BP_GONE, GRANTEE);
      assert.equal(await updateAs(conn, GRANTEE, T_ORPHAN, 'via a deleted blueprint'), 0);
    } finally { conn.release(); }
  });

  test('a record with no blueprint is reached by no blueprint grant', async (t) => {
    if (guard(t)) return;
    const conn = await pool.getConnection();
    try {
      await revokeAll(conn);
      await grant(conn, 'blueprint', BP1, GRANTEE);
      assert.equal(await updateAs(conn, GRANTEE, T_NULL, 'via a null blueprint'), 0);
    } finally { conn.release(); }
  });

  test('no arm reaches a record nobody owns — not the grant on it, not the one on its blueprint', async (t) => {
    if (guard(t)) return;
    // An unowned record is the normal case in a seeded installation. It is
    // readable and copyable by everyone by design, and writing it has always
    // been an administrator's business — the dispatch write-back is the
    // concrete reason. Delegation widened who may work on a record that HAS an
    // owner, and this is the boundary it did not move. Both grant shapes are
    // put to it, including the one that names the record directly.
    const conn = await pool.getConnection();
    try {
      await revokeAll(conn);
      await grant(conn, 'blueprint', BP1, GRANTEE);
      assert.equal(await updateAs(conn, GRANTEE, T_SHARED, 'via a blueprint grant'), 0);
      await revokeAll(conn);
      await grant(conn, 'template', T_SHARED, GRANTEE);
      assert.equal(await updateAs(conn, GRANTEE, T_SHARED, 'via a grant on the record itself'), 0);
      await revokeAll(conn);
      // …and not the blueprint's own owner either.
      assert.equal(await updateAs(conn, OWNER, T_SHARED, 'via owning the blueprint'), 0);
    } finally { conn.release(); }
  });

  test('a blueprint owner reaches every record under that blueprint, with no grant anywhere', async (t) => {
    if (guard(t)) return;
    // The right they hand out is one they have. Without this arm the blueprint
    // owner is the only party who can give away something they can never use.
    const conn = await pool.getConnection();
    try {
      await revokeAll(conn);
      assert.equal(await updateAs(conn, BP_OWNER, T_UNDER_BP3, 'by the blueprint owner'), 1);
      assert.equal(await updateAs(conn, BP_OWNER, T1, 'under a blueprint they do not own'), 0);
      assert.equal(await updateAs(conn, BP_OWNER, T_NULL, 'a record under no blueprint'), 0);
    } finally { conn.release(); }
  });

  test('owning the CATEGORY a record sits beneath reaches nothing', async (t) => {
    if (guard(t)) return;
    // WHAT ACTUALLY STOPS THIS, because it is not the node_type check: the arm
    // joins the record's own `blueprint_id`, and T1's names BP1. The category
    // above it is never a candidate row at all, so the join decides this and
    // node_type is never consulted. The case that DOES turn on node_type is the
    // next test, where a record's blueprint_id names the category itself.
    const conn = await pool.getConnection();
    try {
      await revokeAll(conn);
      await pool.query(
        `UPDATE \`${tbl('hierarchy_nodes')}\` SET owner_id = ? WHERE id = ?`, [STRANGER, CATEGORY],
      );
      assert.equal(await updateAs(conn, STRANGER, T1, 'via owning a category'), 0);
      await pool.query(
        `UPDATE \`${tbl('hierarchy_nodes')}\` SET owner_id = ? WHERE id = ?`, [OWNER, CATEGORY],
      );
    } finally { conn.release(); }
  });

  test('the owner arm requires the node to BE a blueprint, not merely to be named as one', async (t) => {
    if (guard(t)) return;
    // A record whose `blueprint_id` names a node of another tier. Every tier
    // carries an id and an owner, so without `node_type = 'blueprint'` the
    // owner of that node would hold, over this record, the whole right a
    // blueprint owner holds — including handing it out.
    //
    // The node's TYPE is made the only variable: the same caller, the same
    // record, the same join, asked once while the node is a category and once
    // while it is a blueprint. So this cannot go green for the reason the
    // category test above goes green.
    const conn = await pool.getConnection();
    const setType = (type) => pool.query(
      `UPDATE \`${tbl('hierarchy_nodes')}\` SET node_type = ? WHERE id = ?`, [type, CAT2],
    );
    try {
      await revokeAll(conn);
      assert.equal(
        await updateAs(conn, CAT_OWNER, T_UNDER_CAT, 'via owning a category named as a blueprint'), 0,
        'the owner of a CATEGORY reached a record that merely names it',
      );
      const asCategory = await bothAnswers(conn, CAT_OWNER, T_UNDER_CAT);
      assert.equal(asCategory.granted, false, 'the dispatch check reached it');
      assert.equal(asCategory.matched, false);

      await setType('blueprint');
      try {
        const asBlueprint = await bothAnswers(conn, CAT_OWNER, T_UNDER_CAT);
        assert.equal(
          asBlueprint.matched, true,
          'the fixture cannot reach the record even as a blueprint — the case above proves nothing',
        );
        assert.equal(asBlueprint.granted, true);
      } finally {
        await setType('category');
      }
    } finally { conn.release(); }
  });

  test('the arm that needs no grants table is the one that survives without it', async (t) => {
    if (guard(t)) return;
    // What a database whose operator account could not create the grants table
    // gets. The trimmed predicate must not name that table — on those databases
    // naming it fails every record update — and must still carry the blueprint
    // owner.
    const conn = await pool.getConnection();
    try {
      const trimmed = buildTemplateAccessExists(`\`${tbl('user_templates')}\``, { includeGrants: false });
      assert.ok(!trimmed.sql.includes(tbl('delegated_grants')), trimmed.sql);
      const run = async (callerId, templateId) => {
        const res = await conn.query(
          `UPDATE \`${tbl('user_templates')}\` SET \`name\` = ?`
          + ` WHERE id = ? AND (\`owner_id\` = ? OR ${trimmed.sql})`,
          [`edited-${Date.now()}`, templateId, callerId, ...Array(trimmed.paramCount).fill(callerId)],
        );
        return Number(res.affectedRows || 0);
      };
      assert.equal(await run(BP_OWNER, T_UNDER_BP3), 1, 'the blueprint owner lost their reach with the table');
      assert.equal(await run(GRANTEE, T1), 0);
      assert.equal(await run(OWNER, T_SHARED), 0);
    } finally { conn.release(); }
  });

  test('revocation takes effect on the next statement', async (t) => {
    if (guard(t)) return;
    // Nothing is cached between the check and the write because there is no
    // check: the permission IS the write. This is what that buys.
    const conn = await pool.getConnection();
    try {
      await revokeAll(conn);
      await grant(conn, 'template', T1, GRANTEE);
      assert.equal(await updateAs(conn, GRANTEE, T1, 'while granted'), 1);
      await conn.query(
        `DELETE FROM \`${tbl('delegated_grants')}\` WHERE grantee_id = ? AND scope_id = ?`,
        [GRANTEE, T1],
      );
      assert.equal(await updateAs(conn, GRANTEE, T1, 'after revocation'), 0);
    } finally { conn.release(); }
  });

  test('granting the same person the same subject twice is one grant', async (t) => {
    if (guard(t)) return;
    const conn = await pool.getConnection();
    try {
      await revokeAll(conn);
      await grant(conn, 'template', T1, GRANTEE);
      await assert.rejects(
        () => conn.query(
          `INSERT INTO \`${tbl('delegated_grants')}\` (id, scope_type, scope_id, grantee_id)
           VALUES (?, 'template', ?, ?)`,
          ['g-second', T1, GRANTEE],
        ),
        (err) => err.errno === 1062,
        'a duplicate grant was accepted — the unique key is not doing its job',
      );
    } finally { conn.release(); }
  });

  test('the predicate and the dispatch check answer the same question', async (t) => {
    if (guard(t)) return;
    // Two spellings of one rule. If they can disagree, a person may edit a
    // record they cannot dispatch, or the reverse, and nothing would say which
    // is the intended answer.
    const conn = await pool.getConnection();
    try {
      for (const [scopeType, scopeId] of [['template', T1], ['blueprint', BP1], ['blueprint', CATEGORY], ['template', T_SHARED]]) {
        await revokeAll(conn);
        await grant(conn, scopeType, scopeId, GRANTEE);
        for (const templateId of [T1, T2, T_ORPHAN, T_NULL, T_SHARED, T_UNDER_BP3]) {
          const { matched, granted } = await bothAnswers(conn, GRANTEE, templateId);
          assert.equal(
            matched, granted,
            `${scopeType}:${scopeId} → ${templateId}: the update matched ${matched} but the dispatch check said ${granted}`,
          );
        }
      }
      await revokeAll(conn);
      // The arm that needs no grant at all has to agree with itself too.
      for (const templateId of [T1, T2, T_NULL, T_SHARED, T_UNDER_BP3]) {
        const { matched, granted } = await bothAnswers(conn, BP_OWNER, templateId);
        assert.equal(
          matched, granted,
          `blueprint owner → ${templateId}: the update matched ${matched} but the dispatch check said ${granted}`,
        );
      }
      const none = await bothAnswers(conn, STRANGER, T1);
      assert.equal(none.matched, false);
      assert.equal(none.granted, false);
    } finally { conn.release(); }
  });

  // R-3-P1: the floor lives inside the resolver / is threaded into the
  // statement by the route, so a grant row that already exists — created
  // while the grantee was an editor, or before the floor existed — is not
  // honoured once the CURRENT caller is a plain user. Same grant row,
  // measured once per role, on a stored row count wherever the path writes.
  describe('role floor (R-3-P1)', () => {
    test('a plain user\'s EXISTING template grant is refused by the resolver; the same user promoted to editor is allowed', async (t) => {
      if (guard(t)) return;
      const conn = await pool.getConnection();
      try {
        await revokeAll(conn);
        await grant(conn, 'template', T1, GRANTEE);
        const rows = await conn.query(
          `SELECT blueprint_id, owner_id FROM \`${tbl('user_templates')}\` WHERE id = ?`, [T1],
        );
        const subject = { templateId: T1, ownerId: rows[0].owner_id, blueprintId: rows[0].blueprint_id };
        assert.equal(await callerHasTemplateAccess(conn, GRANTEE, subject, 'user'), false);
        assert.equal(await callerHasTemplateAccess(conn, GRANTEE, subject, 'editor'), true);
      } finally { conn.release(); }
    });

    test('a plain user\'s EXISTING template grant does not match the UPDATE statement; the same user promoted to editor matches one row', async (t) => {
      if (guard(t)) return;
      const conn = await pool.getConnection();
      try {
        await revokeAll(conn);
        await grant(conn, 'template', T1, GRANTEE);
        assert.equal(await updateAsRole(conn, GRANTEE, T1, 'as a plain user', 'user'), 0);
        assert.equal(await updateAsRole(conn, GRANTEE, T1, 'as an editor', 'editor'), 1);
      } finally { conn.release(); }
    });

    test('blueprint-scope grant symmetry: a plain user\'s EXISTING blueprint grant is refused, an editor\'s is honoured', async (t) => {
      if (guard(t)) return;
      const conn = await pool.getConnection();
      try {
        await revokeAll(conn);
        await grant(conn, 'blueprint', BP1, GRANTEE);
        assert.equal(await callerHasBlueprintGrant(conn, GRANTEE, BP1, 'user'), false);
        assert.equal(await callerHasBlueprintGrant(conn, GRANTEE, BP1, 'editor'), true);
        assert.equal(await callerHasBlueprintGrant(conn, GRANTEE, BP1, 'admin'), true);
      } finally { conn.release(); }
    });

    // R-4-7: BP_OWNER genuinely owns BP3 in the fixture (created before this
    // floor existed, standing in for an editor demoted after they became a
    // blueprint owner) — the owner_id row itself never changes on a role
    // demotion, only `callerRole` at read time can refuse the reach it
    // conveys.
    test('R-4-7: a blueprint owner\'s reach through the owner arm is refused once callerRole floors it to a plain user; the same owner as editor is unchanged', async (t) => {
      if (guard(t)) return;
      const conn = await pool.getConnection();
      try {
        await revokeAll(conn);
        assert.equal(await updateAsCallerRole(conn, BP_OWNER, T_UNDER_BP3, 'as a demoted owner', 'user'), 0);
        assert.equal(await updateAsCallerRole(conn, BP_OWNER, T_UNDER_BP3, 'as an editor', 'editor'), 1);
      } finally { conn.release(); }
    });
  });
});

describe('a delegated write cannot move the record out of reach', () => {
  const guard = (t) => {
    if (!dbReady) { t.skip(skipReason || 'database not ready'); return true; }
    return false;
  };

  test('a grantee cannot re-file the record under another blueprint', async (t) => {
    if (guard(t)) return;
    // The escalation this closes: the grant reaches the record BECAUSE of its
    // blueprint, so a grantee who could rewrite that column could carry the
    // record out from under the blueprint whose owner delegated it — ending the
    // oversight that made the delegation possible, using the access it gave.
    const conn = await pool.getConnection();
    try {
      await revokeAll(conn);
      await grant(conn, 'blueprint', BP1, GRANTEE);
      assert.equal(await moveAs(conn, GRANTEE, T1, BP2), 0);
      const after = await conn.query(
        `SELECT blueprint_id FROM \`${tbl('user_templates')}\` WHERE id = ?`, [T1],
      );
      assert.equal(after[0].blueprint_id, BP1, 'the record moved');
    } finally { conn.release(); }
  });

  test('a grantee on the record itself cannot either', async (t) => {
    if (guard(t)) return;
    const conn = await pool.getConnection();
    try {
      await revokeAll(conn);
      await grant(conn, 'template', T1, GRANTEE);
      assert.equal(await moveAs(conn, GRANTEE, T1, BP2), 0);
    } finally { conn.release(); }
  });

  test('a grantee writing the same blueprint back is not a move, and proceeds', async (t) => {
    if (guard(t)) return;
    // Every save from the data-entry form carries the record's own blueprint.
    // If that read as a move, delegation would not work at all.
    const conn = await pool.getConnection();
    try {
      await revokeAll(conn);
      await grant(conn, 'blueprint', BP1, GRANTEE);
      assert.equal(await moveAs(conn, GRANTEE, T1, BP1), 1);
    } finally { conn.release(); }
  });

  test('the owner may re-file their own record', async (t) => {
    if (guard(t)) return;
    const conn = await pool.getConnection();
    try {
      await revokeAll(conn);
      assert.equal(await moveAs(conn, OWNER, T1, BP2), 1);
      // Put it back so the fixture is what the other cases expect.
      assert.equal(await moveAs(conn, OWNER, T1, BP1), 1);
    } finally { conn.release(); }
  });
});
