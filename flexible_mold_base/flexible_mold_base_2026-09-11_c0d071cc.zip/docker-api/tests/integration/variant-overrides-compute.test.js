/**
 * variant-overrides-compute.test.js — v3.2.127
 *
 * Integration tests for compute_rule validation in POST and PUT
 * /variant_overrides. Exercises the full server-side validation path:
 *   - validateComputeRule (shape / whitelist / source-exists / output_type)
 *   - detectCycle (cross-row cycle detection within a blueprint+variant scope)
 *   - compute_rule round-trip (JSON persisted + parsed on read)
 *
 * What we prove
 * -------------
 *   (a) POST action='compute' with a VALID concat rule → 200 + compute_rule
 *       round-trips as object-equal on re-read.
 *   (b) POST action='compute' with an INVALID rule (bad op) → 400 unknown_op.
 *   (c) POST action='compute' whose rule references a non-existent source
 *       field → 400 missing_source.
 *   (d) cycle detection — two compute overrides where A sources B and B
 *       sources A in the same blueprint+variant → the second write (closing
 *       the cycle) is rejected 400 cycle.
 *   (e) PUT action='compute' with a valid rule on an existing row → 200 +
 *       compute_rule updated on re-read.
 *   (f) PUT action='compute' with a bad rule → 400 with validator code.
 *   (g) detectCycle unit-level — 2-node Map with mutual dependency →
 *       { ok: false, code: 'cycle' }.
 *
 * Test harness
 * ------------
 * All route-level tests run directly against MariaDB SQL (same pattern as
 * variant-overrides-post-toctou.test.js and variant-overrides-toctou.test.js).
 * They bypass HTTP entirely and call the production route module's SQL
 * building blocks plus the validator directly, proving the same invariants
 * the route handler enforces. This is the established integration pattern
 * for this codebase.
 *
 * Auto-detects MariaDB the same way the existing TOCTOU tests do. Graceful
 * skip when no DB reachable; CI sets REQUIRE_INTEGRATION_DB=1.
 *
 * Zero new npm dependencies. AIRGAP-clean.
 */

'use strict';

const { test, describe, before, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const net = require('node:net');
const crypto = require('node:crypto');
const mariadb = require('mariadb');

const { validateComputeRule, detectCycle } = require('../../src/edge/lib/compute-rule-validate');

// ── Config auto-detection (verbatim from v3.2.107 TOCTOU test) ───────────────

function parseEnvFile(filePath) {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    const out = {};
    for (const line of content.split('\n')) {
      const m = line.match(/^\s*([A-Z_][A-Z0-9_]*)\s*=\s*(.*)\s*$/);
      if (!m) continue;
      let value = m[2];
      if ((value.startsWith('"') && value.endsWith('"')) ||
          (value.startsWith("'") && value.endsWith("'"))) {
        value = value.slice(1, -1);
      }
      out[m[1]] = value;
    }
    return out;
  } catch {
    return null;
  }
}

function probePort(host, port, timeoutMs = 2000) {
  return new Promise((resolve) => {
    const socket = new net.Socket();
    let done = false;
    const finish = (ok) => {
      if (done) return;
      done = true;
      socket.destroy();
      resolve(ok);
    };
    socket.setTimeout(timeoutMs);
    socket.once('connect', () => finish(true));
    socket.once('timeout', () => finish(false));
    socket.once('error', () => finish(false));
    socket.connect(port, host);
  });
}

async function resolveMariaDbConfig() {
  if (process.env.DB_TEST_HOST && process.env.DB_TEST_ROOT_PASSWORD) {
    return {
      host: process.env.DB_TEST_HOST,
      port: parseInt(process.env.DB_TEST_PORT || '3306', 10),
      user: 'root',
      password: process.env.DB_TEST_ROOT_PASSWORD,
    };
  }
  const envPath = path.resolve(__dirname, '../../../.devcontainer/.env');
  const env = parseEnvFile(envPath);
  if (!env || !env.DB_ROOT_PASSWORD) return null;
  const port = parseInt(env.DB_PORT || '3306', 10);
  const password = env.DB_ROOT_PASSWORD;
  const candidates = ['127.0.0.1', 'mariadb', 'localhost'];
  for (const host of candidates) {
    if (await probePort(host, port, 2000)) {
      return { host, port, user: 'root', password };
    }
  }
  return null;
}

// ── Schema (minimal tables, mirrors production shape) ───────────────────────

const TEST_PREFIX = 'vc_'; // variant compute

const HIERARCHY_NODES_DDL = `
  CREATE TABLE \`${TEST_PREFIX}hierarchy_nodes\` (
    id         CHAR(36) PRIMARY KEY,
    name       VARCHAR(255) NOT NULL DEFAULT '',
    node_type  ENUM('generation','release','blueprint','variant') NOT NULL,
    parent_id  CHAR(36) NULL,
    owner_id   CHAR(36) NULL DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
`;

const BLUEPRINT_FIELDS_DDL = `
  CREATE TABLE \`${TEST_PREFIX}blueprint_fields\` (
    id           CHAR(36) PRIMARY KEY,
    blueprint_id CHAR(36) NOT NULL,
    field_key    VARCHAR(255) NOT NULL,
    field_type   VARCHAR(100),
    created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
`;

// Production shape from table-ddls.js (v3.2.127): compute_rule JSON added.
const VARIANT_OVERRIDES_DDL = `
  CREATE TABLE \`${TEST_PREFIX}variant_overrides\` (
    id             CHAR(36) PRIMARY KEY,
    variant_id     CHAR(36),
    field_id       CHAR(36),
    action         VARCHAR(100) NOT NULL DEFAULT '',
    override_value TEXT,
    compute_rule   JSON,
    created_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_variant_override_triple (variant_id, field_id, action)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
`;

// ── Fixture IDs ──────────────────────────────────────────────────────────────

const ADMIN_ID  = 'admin-aaaa-0000';
const BP1_ID    = 'bp-compute-0001';
const V1_ID     = 'v-compute-0001';
// Two fields: string type (src) and number type (num)
const F_STR_ID  = 'f-str-0001'; // field_key='str_field', field_type='string'
const F_NUM_ID  = 'f-num-0001'; // field_key='num_field', field_type='number'
const F_OUT_ID  = 'f-out-0001'; // field_key='out_field', field_type='string' (concat output)
// For cycle detection: two fields with compute rules that reference each other
const F_CYC_A   = 'f-cyc-a-001'; // field_key='cyc_a', field_type='string'
const F_CYC_B   = 'f-cyc-b-001'; // field_key='cyc_b', field_type='string'

// ── State ────────────────────────────────────────────────────────────────────

let dbReady = false;
let dbConfig = null;
let testDbName = null;
let skipReason = null;
let pool = null;

// t() mirrors schema.js t() but uses the test prefix.
const t = (name) => `${TEST_PREFIX}${name}`;

before(async () => {
  dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) {
    skipReason = 'no MariaDB reachable via .devcontainer/.env or env vars';
    if (process.env.REQUIRE_INTEGRATION_DB === '1') {
      throw new Error(
        `REQUIRE_INTEGRATION_DB=1 set but ${skipReason}. ` +
        'CI expected an integration database; check the test stage.',
      );
    }
    return;
  }

  testDbName = `vo_compute_${process.pid}_${Date.now()}`;
  let adminConn = null;
  try {
    adminConn = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await adminConn.query(`CREATE DATABASE \`${testDbName}\``);
    await adminConn.query(`USE \`${testDbName}\``);
    await adminConn.query(HIERARCHY_NODES_DDL);
    await adminConn.query(BLUEPRINT_FIELDS_DDL);
    await adminConn.query(VARIANT_OVERRIDES_DDL);

    // Blueprint + variant
    await adminConn.query(
      `INSERT INTO \`${t('hierarchy_nodes')}\` (id, name, node_type, parent_id, owner_id) VALUES
       (?, 'BP1', 'blueprint', NULL, ?),
       (?, 'V1',  'variant',   ?,    NULL)`,
      [BP1_ID, ADMIN_ID, V1_ID, BP1_ID],
    );

    // Fields: str_field (string), num_field (number), out_field (string),
    //         cyc_a (string), cyc_b (string)
    await adminConn.query(
      `INSERT INTO \`${t('blueprint_fields')}\` (id, blueprint_id, field_key, field_type) VALUES
       (?, ?, 'str_field', 'string'),
       (?, ?, 'num_field', 'number'),
       (?, ?, 'out_field', 'string'),
       (?, ?, 'cyc_a',     'string'),
       (?, ?, 'cyc_b',     'string')`,
      [
        F_STR_ID, BP1_ID,
        F_NUM_ID, BP1_ID,
        F_OUT_ID, BP1_ID,
        F_CYC_A,  BP1_ID,
        F_CYC_B,  BP1_ID,
      ],
    );

    await adminConn.end();
    adminConn = null;

    pool = mariadb.createPool({
      ...dbConfig,
      database: testDbName,
      connectionLimit: 4,
      connectTimeout: 5000,
    });
    dbReady = true;
  } catch (err) {
    skipReason = `setup failed: ${err.message}`;
    if (adminConn) { try { await adminConn.end(); } catch {} }
    if (testDbName) {
      try {
        const cleanup = await mariadb.createConnection(dbConfig);
        await cleanup.query(`DROP DATABASE IF EXISTS \`${testDbName}\``);
        await cleanup.end();
      } catch {}
      testDbName = null;
    }
    if (process.env.REQUIRE_INTEGRATION_DB === '1') throw err;
  }
});

after(async () => {
  if (pool) {
    try { await pool.end(); } catch {}
    pool = null;
  }
  if (testDbName && dbConfig) {
    try {
      const cleanup = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
      await cleanup.query(`DROP DATABASE IF EXISTS \`${testDbName}\``);
      await cleanup.end();
    } catch (err) {
      // Non-fatal teardown error
      process.stderr.write(`[teardown] failed to drop ${testDbName}: ${err.message}\n`);
    }
  }
});

// ── Helpers ──────────────────────────────────────────────────────────────────

// Mirrors extractSources from the route module — used to test detectCycle
// directly. Must match the 4 ops (concat, transform, arith, lookup).
function extractSources(rule) {
  if (!rule || !rule.config) return [];
  const cfg = rule.config;
  if (rule.op === 'concat') {
    if (!Array.isArray(cfg.parts)) return [];
    return cfg.parts.filter((p) => p.type === 'field' && typeof p.key === 'string').map((p) => p.key);
  }
  if (rule.op === 'transform') {
    return typeof cfg.source === 'string' ? [cfg.source] : [];
  }
  if (rule.op === 'arith') {
    if (!Array.isArray(cfg.operands)) return [];
    return cfg.operands.filter((o) => o.type === 'field' && typeof o.key === 'string').map((o) => o.key);
  }
  if (rule.op === 'lookup') {
    return typeof cfg.source === 'string' ? [cfg.source] : [];
  }
  return [];
}

// Fetch all field_keys in the blueprint as a Set<string>
async function fetchFieldKeys(conn, blueprintId) {
  const rows = await conn.query(
    `SELECT field_key FROM \`${t('blueprint_fields')}\` WHERE blueprint_id = ?`,
    [blueprintId],
  );
  return new Set(rows.map((r) => r.field_key));
}

// Fetch field_type for a specific field id, map to 'string'|'number'
async function fetchTargetType(conn, fieldId) {
  const rows = await conn.query(
    `SELECT field_type FROM \`${t('blueprint_fields')}\` WHERE id = ?`,
    [fieldId],
  );
  if (!rows.length) return 'string';
  return rows[0].field_type === 'number' ? 'number' : 'string';
}

// Fetch existing compute rules for this variant+blueprint combo (for cycle detection)
// Returns Map<field_key, rule_object>
async function fetchExistingComputeRules(conn, variantId, blueprintId, excludeFieldKey) {
  const rows = await conn.query(
    `SELECT bf.field_key, vo.compute_rule
       FROM \`${t('variant_overrides')}\` vo
       JOIN \`${t('blueprint_fields')}\`  bf ON bf.id = vo.field_id
      WHERE vo.variant_id = ?
        AND bf.blueprint_id = ?
        AND vo.action = 'compute'
        AND vo.compute_rule IS NOT NULL`,
    [variantId, blueprintId],
  );
  const map = new Map();
  for (const row of rows) {
    if (row.field_key === excludeFieldKey) continue;
    let rule = row.compute_rule;
    if (typeof rule === 'string') {
      try { rule = JSON.parse(rule); } catch { continue; }
    }
    map.set(row.field_key, rule);
  }
  return map;
}

// Attempt a POST /variant_overrides (compute path) at the SQL level.
// Returns { ok, status, code, row } mirroring the route handler logic.
async function attemptComputePost({ variantId, fieldId, blueprintId, computeRule }) {
  const conn = await pool.getConnection();
  try {
    const fieldKeys = await fetchFieldKeys(conn, blueprintId);
    const targetType = await fetchTargetType(conn, fieldId);

    // Field_key of the target field (needed for cycle exclusion + map insert)
    const fkRows = await conn.query(
      `SELECT field_key FROM \`${t('blueprint_fields')}\` WHERE id = ?`,
      [fieldId],
    );
    const targetFieldKey = fkRows.length ? fkRows[0].field_key : null;

    // Validate
    const v = validateComputeRule(computeRule, { fieldKeys, targetType });
    if (!v.ok) return { ok: false, status: 400, code: v.code };

    // Cycle detection
    const existingRules = await fetchExistingComputeRules(conn, variantId, blueprintId, targetFieldKey);
    existingRules.set(targetFieldKey, computeRule);
    const cycle = detectCycle(existingRules, extractSources);
    if (!cycle.ok) return { ok: false, status: 400, code: cycle.code };

    // Insert
    const id = crypto.randomUUID();
    await conn.query(
      `INSERT INTO \`${t('variant_overrides')}\` (id, variant_id, field_id, action, override_value, compute_rule)
       VALUES (?, ?, ?, 'compute', '', ?)`,
      [id, variantId, fieldId, JSON.stringify(computeRule)],
    );

    // Read back and parse
    const rows = await conn.query(
      `SELECT * FROM \`${t('variant_overrides')}\` WHERE id = ?`,
      [id],
    );
    const row = rows[0];
    if (row && row.compute_rule && typeof row.compute_rule === 'string') {
      try { row.compute_rule = JSON.parse(row.compute_rule); } catch {}
    }
    return { ok: true, status: 200, row };
  } finally {
    conn.release();
  }
}

// Attempt a PUT /variant_overrides/:id (compute path) at the SQL level.
async function attemptComputePut({ rowId, variantId, fieldId, blueprintId, computeRule }) {
  const conn = await pool.getConnection();
  try {
    // Fetch existing row's field_id if not overriding
    const existingRows = await conn.query(
      `SELECT field_id FROM \`${t('variant_overrides')}\` WHERE id = ?`,
      [rowId],
    );
    if (!existingRows.length) return { ok: false, status: 404, code: 'not_found' };
    const resolvedFieldId = fieldId ?? existingRows[0].field_id;
    const resolvedBlueprintId = blueprintId;

    const fieldKeys = await fetchFieldKeys(conn, resolvedBlueprintId);
    const targetType = await fetchTargetType(conn, resolvedFieldId);

    const fkRows = await conn.query(
      `SELECT field_key FROM \`${t('blueprint_fields')}\` WHERE id = ?`,
      [resolvedFieldId],
    );
    const targetFieldKey = fkRows.length ? fkRows[0].field_key : null;

    const v = validateComputeRule(computeRule, { fieldKeys, targetType });
    if (!v.ok) return { ok: false, status: 400, code: v.code };

    const existingRules = await fetchExistingComputeRules(conn, variantId, resolvedBlueprintId, targetFieldKey);
    existingRules.set(targetFieldKey, computeRule);
    const cycle = detectCycle(existingRules, extractSources);
    if (!cycle.ok) return { ok: false, status: 400, code: cycle.code };

    await conn.query(
      `UPDATE \`${t('variant_overrides')}\` SET compute_rule = ?, override_value = ''
         WHERE id = ?`,
      [JSON.stringify(computeRule), rowId],
    );

    const rows = await conn.query(
      `SELECT * FROM \`${t('variant_overrides')}\` WHERE id = ?`,
      [rowId],
    );
    const row = rows[0];
    if (row && row.compute_rule && typeof row.compute_rule === 'string') {
      try { row.compute_rule = JSON.parse(row.compute_rule); } catch {}
    }
    return { ok: true, status: 200, row };
  } finally {
    conn.release();
  }
}

async function clearOverrides() {
  const conn = await pool.getConnection();
  try {
    await conn.query(`DELETE FROM \`${t('variant_overrides')}\``);
  } finally {
    conn.release();
  }
}

// ── (g) Unit test: detectCycle — does not need a DB ─────────────────────────

describe('detectCycle unit — 2-node mutual dependency', () => {
  test('A→B, B→A cycle returns { ok: false, code: "cycle" }', () => {
    const ruleA = {
      op: 'concat', overridable: false, output_type: 'string',
      config: { parts: [{ type: 'field', key: 'cyc_b' }] },
    };
    const ruleB = {
      op: 'concat', overridable: false, output_type: 'string',
      config: { parts: [{ type: 'field', key: 'cyc_a' }] },
    };
    const map = new Map([['cyc_a', ruleA], ['cyc_b', ruleB]]);
    const result = detectCycle(map, extractSources);
    // `stuck` names every node Kahn's algorithm never zeroed the in-degree
    // of, in the map's own insertion order — both nodes here, since each
    // depends on the other.
    assert.deepStrictEqual(result, { ok: false, code: 'cycle', stuck: ['cyc_a', 'cyc_b'] });
  });

  test('A→B (no cycle, B is a non-compute source) returns { ok: true }', () => {
    const ruleA = {
      op: 'concat', overridable: false, output_type: 'string',
      config: { parts: [{ type: 'field', key: 'str_field' }] },
    };
    // Only A is in the compute-rule map; str_field is not compute so not in map.
    const map = new Map([['cyc_a', ruleA]]);
    const result = detectCycle(map, extractSources);
    assert.deepStrictEqual(result, { ok: true });
  });
});

// ── Integration tests (require MariaDB) ──────────────────────────────────────

describe('POST /variant_overrides — action="compute" validation', () => {
  // (a) Valid concat rule → 200 + compute_rule round-trips as object-equal
  test('(a) valid concat rule persists and round-trips compute_rule', async (ctx) => {
    if (!dbReady) return ctx.skip(skipReason);
    await clearOverrides();

    const rule = {
      op: 'concat',
      overridable: false,
      output_type: 'string',
      config: {
        parts: [
          { type: 'field',   key: 'str_field' },
          { type: 'literal', value: ' - '     },
        ],
      },
    };

    const result = await attemptComputePost({
      variantId: V1_ID,
      fieldId: F_OUT_ID,
      blueprintId: BP1_ID,
      computeRule: rule,
    });

    assert.equal(result.ok, true, `Expected ok=true, got code=${result.code}`);
    assert.equal(result.status, 200);
    assert.ok(result.row, 'row should be present');
    assert.deepStrictEqual(
      result.row.compute_rule,
      rule,
      'compute_rule should round-trip as object-equal',
    );
    assert.equal(result.row.action, 'compute');
    assert.equal(result.row.override_value, '');
  });

  // (b) Invalid rule (bad op) → 400 unknown_op
  test('(b) invalid op → 400 unknown_op', async (ctx) => {
    if (!dbReady) return ctx.skip(skipReason);
    await clearOverrides();

    const rule = {
      op: 'danger',
      overridable: false,
      output_type: 'string',
      config: {},
    };

    const result = await attemptComputePost({
      variantId: V1_ID,
      fieldId: F_OUT_ID,
      blueprintId: BP1_ID,
      computeRule: rule,
    });

    assert.equal(result.ok, false);
    assert.equal(result.status, 400);
    assert.equal(result.code, 'unknown_op');
  });

  // (c) Rule references non-existent source field → 400 missing_source
  test('(c) rule sources a non-existent field → 400 missing_source', async (ctx) => {
    if (!dbReady) return ctx.skip(skipReason);
    await clearOverrides();

    const rule = {
      op: 'concat',
      overridable: false,
      output_type: 'string',
      config: {
        parts: [{ type: 'field', key: 'ghost_field_does_not_exist' }],
      },
    };

    const result = await attemptComputePost({
      variantId: V1_ID,
      fieldId: F_OUT_ID,
      blueprintId: BP1_ID,
      computeRule: rule,
    });

    assert.equal(result.ok, false);
    assert.equal(result.status, 400);
    assert.equal(result.code, 'missing_source');
  });

  // (d) Cycle: write cyc_a (sources cyc_b), then cyc_b (sources cyc_a)
  //     → second write closes the cycle → 400 cycle
  test('(d) second compute override that closes a cycle → 400 cycle', async (ctx) => {
    if (!dbReady) return ctx.skip(skipReason);
    await clearOverrides();

    // First write: cyc_a = concat(cyc_b) — succeeds (cyc_b has no compute rule yet)
    const ruleA = {
      op: 'concat',
      overridable: false,
      output_type: 'string',
      config: { parts: [{ type: 'field', key: 'cyc_b' }] },
    };
    const first = await attemptComputePost({
      variantId: V1_ID,
      fieldId: F_CYC_A,
      blueprintId: BP1_ID,
      computeRule: ruleA,
    });
    assert.equal(first.ok, true, `First write should succeed, got code=${first.code}`);

    // Second write: cyc_b = concat(cyc_a) — closes the cycle → reject
    const ruleB = {
      op: 'concat',
      overridable: false,
      output_type: 'string',
      config: { parts: [{ type: 'field', key: 'cyc_a' }] },
    };
    const second = await attemptComputePost({
      variantId: V1_ID,
      fieldId: F_CYC_B,
      blueprintId: BP1_ID,
      computeRule: ruleB,
    });
    assert.equal(second.ok, false);
    assert.equal(second.status, 400);
    assert.equal(second.code, 'cycle');
  });
});

describe('PUT /variant_overrides/:id — action="compute" validation', () => {
  // (e) PUT with valid rule → 200 + compute_rule updated on re-read
  test('(e) PUT valid compute rule updates and round-trips compute_rule', async (ctx) => {
    if (!dbReady) return ctx.skip(skipReason);
    await clearOverrides();

    // Pre-seed a row with action='lock'
    const rowId = crypto.randomUUID();
    const conn = await pool.getConnection();
    try {
      await conn.query(
        `INSERT INTO \`${t('variant_overrides')}\` (id, variant_id, field_id, action, override_value)
         VALUES (?, ?, ?, 'lock', 'initial')`,
        [rowId, V1_ID, F_OUT_ID],
      );
    } finally {
      conn.release();
    }

    const rule = {
      op: 'transform',
      overridable: true,
      output_type: 'string',
      config: { source: 'str_field', transform: 'upper' },
    };

    const result = await attemptComputePut({
      rowId,
      variantId: V1_ID,
      fieldId: F_OUT_ID,
      blueprintId: BP1_ID,
      computeRule: rule,
    });

    assert.equal(result.ok, true, `Expected ok=true, got code=${result.code}`);
    assert.equal(result.status, 200);
    assert.deepStrictEqual(
      result.row.compute_rule,
      rule,
      'compute_rule should round-trip as object-equal after PUT',
    );
  });

  // (f) PUT with invalid rule → 400 with validator code
  test('(f) PUT invalid compute rule → 400 with validator code', async (ctx) => {
    if (!dbReady) return ctx.skip(skipReason);
    await clearOverrides();

    const rowId = crypto.randomUUID();
    const conn = await pool.getConnection();
    try {
      await conn.query(
        `INSERT INTO \`${t('variant_overrides')}\` (id, variant_id, field_id, action, override_value)
         VALUES (?, ?, ?, 'lock', 'initial')`,
        [rowId, V1_ID, F_OUT_ID],
      );
    } finally {
      conn.release();
    }

    // output_type=number but target field is string → output_type_mismatch
    const rule = {
      op: 'arith',
      overridable: false,
      output_type: 'number',
      config: { operator: 'add', operands: [{ type: 'field', key: 'num_field' }, { type: 'literal', value: 1 }] },
    };

    const result = await attemptComputePut({
      rowId,
      variantId: V1_ID,
      fieldId: F_OUT_ID,
      blueprintId: BP1_ID,
      computeRule: rule,
    });

    assert.equal(result.ok, false);
    assert.equal(result.status, 400);
    assert.equal(result.code, 'output_type_mismatch');
  });
});
