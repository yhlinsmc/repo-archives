/**
 * field-rename-references-real-db.test.js
 *
 * The field-rename reference cascade, executed by a real MariaDB.
 *
 * WHY THIS EXISTS AS A SEPARATE, DB-BACKED TEST. The two references are not
 * stored the same way: one IS a column, the other is a path inside a JSON
 * document. A column assignment and a JSON_SET are different statements with
 * different failure modes, and a stubbed connection reports `affectedRows` for
 * both whether or not either would touch a row — so which rows each one actually
 * reaches has to be asked of the engine. Three of the properties this cascade
 * depends on are invisible to any mock:
 *
 *   - JSON_SET CREATES a path that is absent, so without the right predicate the
 *     statement would give every field in the blueprint a visibility rule nobody
 *     wrote;
 *   - a JSON function applied to text MariaDB cannot parse answers NULL, which
 *     would replace an unreadable rule with no rule at all;
 *   - whether a reference spelling the key differently is rewritten is a
 *     property of the COMPARISON — of the collation each side of it carries —
 *     and not of the SQL text. The two sites do not answer that the same way,
 *     which is the reason for the collation test below.
 *
 * THE FIXTURE IS THE PRODUCTION COLUMN, NOT A STAND-IN FOR IT. `visibility_rule`
 * is declared exactly as table-ddls.js declares it, `JSON` — which MariaDB
 * expands to `longtext ... COLLATE utf8mb4_bin CHECK (json_valid(...))`. An
 * earlier version of this file used LONGTEXT so it could hold the unparseable
 * row, which also swapped the collation for the table default
 * (utf8mb4_general_ci) and dropped the CHECK. Measured rather than assumed: that
 * substitution changes NO result this file asserts, because the comparison runs
 * on JSON_UNQUOTE's output, which is utf8mb4_bin whatever collation it read from
 * — the collation test below pins exactly that, so the day it stops being true
 * the fixture's fidelity starts mattering and this file says so. The column is
 * declared as production declares it regardless: a fixture that differs from the
 * schema on purpose has to keep proving the difference is immaterial, and that
 * proof is not free. The unparseable row is still here — inserted with
 * `check_constraint_checks` off, which is how a row predating the constraint
 * actually arrives (a restore), and the only way one can exist at all.
 *
 * The statements under test are CAPTURED FROM THE ROUTE rather than written
 * here: a copy in a test file is a second source that drifts, which is the class
 * of defect this whole change is about.
 *
 * Auto-detects a reachable MariaDB and skips cleanly when there is none — and
 * FAILS instead of skipping when REQUIRE_INTEGRATION_DB=1, on both branches that
 * can reach the skip: the one where setup threw and the one where no database
 * could be found at all. The second is the branch that actually fires in the
 * field, and it used to return silently.
 */
const { test, describe, before, after } = require('node:test');
const { makeStubReqLog } = require('../helpers/stub-req-log');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const net = require('node:net');
const http = require('node:http');
const express = require('express');
const mariadb = require('mariadb');

const {
  USER_TEMPLATE_METADATA_COLUMN_NAMES,
} = require('../../src/edge/lib/user-template-metadata');
const {
  BLUEPRINT_FIELD_KEY_REFERENCE_COLUMNS,
} = require('../../src/edge/lib/blueprint-field-key-references');
const { ddlFragmentFor } = require('../../src/edge/lib/schema-manifest');

const TEST_PREFIX = 'fkr_';
const OLD_KEY = 'old_key';
const NEW_KEY = 'new_key';
const BLUEPRINT = 'bp-1';
const OTHER_BLUEPRINT = 'bp-2';
const FIELD_ID = 'f-self';

// ── Config auto-detection (same shape as the sibling integration tests) ──────

function parseEnvFile(filePath) {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    const out = {};
    for (const line of content.split('\n')) {
      const m = line.match(/^\s*([A-Z_][A-Z0-9_]*)\s*=\s*(.*)\s*$/);
      if (!m) continue;
      let value = m[2];
      if ((value.startsWith('"') && value.endsWith('"'))
        || (value.startsWith("'") && value.endsWith("'"))) {
        value = value.slice(1, -1);
      }
      out[m[1]] = value;
    }
    return out;
  } catch {
    return null;
  }
}

function probePort(host, port, timeoutMs) {
  return new Promise((resolve) => {
    const socket = new net.Socket();
    let done = false;
    const finish = (ok) => {
      if (done) return;
      done = true;
      socket.destroy();
      resolve(ok);
    };
    socket.setTimeout(timeoutMs);
    socket.once('connect', () => finish(true));
    socket.once('timeout', () => finish(false));
    socket.once('error', () => finish(false));
    socket.connect(port, host);
  });
}

async function resolveMariaDbConfig() {
  if (process.env.DB_TEST_HOST && process.env.DB_TEST_ROOT_PASSWORD) {
    return {
      host: process.env.DB_TEST_HOST,
      port: parseInt(process.env.DB_TEST_PORT || '3306', 10),
      user: 'root',
      password: process.env.DB_TEST_ROOT_PASSWORD,
    };
  }
  const envPath = path.resolve(__dirname, '../../../.devcontainer/.env');
  const env = parseEnvFile(envPath);
  if (!env || !env.DB_ROOT_PASSWORD) return null;
  const port = parseInt(env.DB_PORT || '3306', 10);
  for (const host of ['127.0.0.1', 'mariadb', 'localhost']) {
    if (await probePort(host, port, 2000)) {
      return { host, port, user: 'root', password: env.DB_ROOT_PASSWORD };
    }
  }
  return null;
}

// ── Capture the statements the route actually issues ─────────────────────────

const TEMPLATE_COLUMNS = ['id', 'blueprint_id', 'payload', ...USER_TEMPLATE_METADATA_COLUMN_NAMES];
const FIELD_COLUMNS = [
  'id', 'blueprint_id', 'field_key', ...BLUEPRINT_FIELD_KEY_REFERENCE_COLUMNS,
];

// Where the stubbed connection puts what it is asked to run. A LET AND NOT A
// CLOSURE PER CALL, and that is load-bearing rather than tidy: the route's own
// module graph (helpers, the db facade, the handler) stays in `require.cache`
// across calls, so a second capture that built a fresh closure would still be
// talking to the FIRST call's array — its own would come back empty and read as
// "the route issued no statement", which is a diagnosis about the harness
// wearing the words of a diagnosis about the route.
let captured = [];

let capturePort = null;
let captureSaved;
let captureServer = null;

async function startCaptureRoute() {
  if (capturePort !== null) return;
  const dbKey = require.resolve('../../src/edge/db');
  const conn = {
    async query(sql, params) {
      if (/^SELECT DATABASE\(\)/i.test(sql)) return [{ db: 'capture' }];
      if (/information_schema\.COLUMNS/i.test(sql)) {
        const table = params && params[0];
        const cols = table === `${TEST_PREFIX}blueprint_fields` ? FIELD_COLUMNS : TEMPLATE_COLUMNS;
        return cols.map((c) => ({ COLUMN_NAME: c }));
      }
      captured.push({ sql, params });
      // The row as it stands before the rename: the handler reads its own old
      // key from here, and the cascade's WHERE is built from that.
      if (/^SELECT id, blueprint_id, field_type, field_key/i.test(sql)) {
        return [{
          id: FIELD_ID, blueprint_id: BLUEPRINT, field_type: 'text', field_key: OLD_KEY,
          depends_on_field_key: null,
        }];
      }
      if (/^SELECT linked_blueprint_id/i.test(sql)) return [];
      // No sibling holds the new key — the collision path has its own coverage
      // in the route tests; here the rename must be allowed to proceed.
      if (/^SELECT id FROM/i.test(sql)) return [];
      if (/^SELECT \* FROM/i.test(sql)) {
        return [{ id: FIELD_ID, blueprint_id: BLUEPRINT, field_key: NEW_KEY, field_type: 'text' }];
      }
      return { affectedRows: 1 };
    },
    release() { /* noop */ },
    async beginTransaction() {},
    async commit() {},
    async rollback() {},
  };
  const poolSpy = {
    rw: { async getConnection() { return conn; } },
    ro: { async getConnection() { return conn; } },
  };
  captureSaved = require.cache[dbKey];
  require.cache[dbKey] = {
    id: dbKey,
    filename: dbKey,
    loaded: true,
    exports: { pool: poolSpy, t: (n) => `${TEST_PREFIX}${n}`, getDynamicPool: async () => poolSpy },
  };
  // Loaded under the stub so the route resolves the stubbed db module.
  delete require.cache[require.resolve('../../src/edge/routes/app/schema')];
  const router = require('../../src/edge/routes/app/schema');

  const app = express();
  app.use((req, _res, next) => { req.log = makeStubReqLog(); next(); }); // TEST-ONLY: production always sets req.log via createRequestId (request-id.js) before any router; this bare app has no such middleware, so a route's req.log.<level>() call would otherwise throw against undefined.
  app.use(express.json());
  app.use((req, _res, next) => { req.user = { id: 'admin-1', role: 'admin' }; next(); });
  app.use('/edge/app/schema', router);
  captureServer = app.listen(0, '127.0.0.1');
  await new Promise((resolve) => captureServer.once('listening', resolve));
  capturePort = captureServer.address().port;
}

function stopCaptureRoute() {
  if (captureServer) captureServer.close();
  captureServer = null;
  capturePort = null;
  const dbKey = require.resolve('../../src/edge/db');
  delete require.cache[require.resolve('../../src/edge/routes/app/schema')];
  if (captureSaved) require.cache[dbKey] = captureSaved; else delete require.cache[dbKey];
}

/**
 * The reference statements ONE PUT issues, for a body the caller chooses.
 *
 * THE BODY IS A PARAMETER BECAUSE THE CASCADE'S SHAPE DEPENDS ON IT. The
 * addressed row is excluded from a site only when the request WROTE that site,
 * so "this field's own reference follows the key" and "it is left exactly as
 * sent" are two different statement sets out of one route. A harness that can
 * only issue one body cannot tell them apart, and would offer whichever it
 * happened to capture as evidence for both.
 */
async function captureReferenceStatements(body = { field_key: NEW_KEY }) {
  await startCaptureRoute();
  captured = [];

  // The PUT, because the PUT is what writes `field_key` — the cascade runs in
  // the same statement boundary so there is no moment where a reference names a
  // key no field holds.
  await new Promise((resolve, reject) => {
    const payload = JSON.stringify(body);
    const req = http.request({
      method: 'PUT',
      host: '127.0.0.1',
      port: capturePort,
      path: `/edge/app/schema/blueprint_fields/${FIELD_ID}`,
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) },
    }, (res) => {
      res.on('data', () => {});
      res.on('end', resolve);
    });
    req.on('error', reject);
    req.write(payload);
    req.end();
  });

  // The handler writes the field's own key in the same transaction, so the
  // reference statements are picked out by WHICH COLUMN THEY ASSIGN: a declared
  // reference column, which the key write never names.
  //
  // A SELECTOR MAY NOT NAME ANYTHING AN ASSERTION BELOW JUDGES, and getting
  // that wrong twice is why it is spelt out. Keyed on `BINARY`, widening the
  // comparison stopped the statement being RECOGNISED and this hook failed with
  // an arity complaint while the case-variant assertions never ran. Keyed on
  // `WHERE blueprint_id = ?` it had the same defect one column over: dropping
  // the blueprint scope — a genuine cross-blueprint corruption — reported "the
  // route issued no statement", cancelling the only assertion anywhere that the
  // cascade is scoped at all. The SET clause is judged by nothing here, so a
  // statement that is wrong in any of those ways is still SEEN, replayed, and
  // fails on the rows it left behind.
  //
  // The one thing it must also exclude is the addressed-row write itself, which
  // names a reference column FIRST in its SET clause whenever the body carries
  // one. That statement is identified by what it IS, not by anything judged
  // here: it assigns `field_key`, and no cascade statement ever does.
  const updates = captured.filter(
    (c) => new RegExp(`^UPDATE \`${TEST_PREFIX}blueprint_fields\``, 'i').test(c.sql)
      && !/`field_key` = \?/.test(c.sql)
      && BLUEPRINT_FIELD_KEY_REFERENCE_COLUMNS.some(
        (col) => new RegExp(`SET \`${col}\` =`).test(c.sql),
      ),
  );
  assert.equal(
    updates.length, BLUEPRINT_FIELD_KEY_REFERENCE_COLUMNS.length,
    'the route did not issue one statement per declared reference site',
  );
  return updates;
}

// ── Fixture ──────────────────────────────────────────────────────────────────

// Both reference columns are declared as table-ddls.js declares them, types and
// all, because the property under test is decided by the column and not by the
// statement: `JSON` is MariaDB's alias for LONGTEXT under utf8mb4_bin, while a
// plain VARCHAR inherits the table's utf8mb4_general_ci. Substituting either one
// changes the answer the comparison gives.
function fieldsDDL() {
  return `CREATE TABLE IF NOT EXISTS \`${TEST_PREFIX}blueprint_fields\` (
    id CHAR(36) PRIMARY KEY,
    blueprint_id CHAR(36),
    field_key VARCHAR(255),
    depends_on_field_key VARCHAR(255) NULL DEFAULT NULL,
    visibility_rule JSON NULL DEFAULT NULL
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`;
}

const CORRUPT_RULE = '{"field_key":"old_key","operator":"eq"';

const ROWS = [
  // id, blueprint, field_key, depends_on_field_key, visibility_rule
  //
  // THE SUBJECT CARRIES THE OLD KEY IN BOTH REFERENCE COLUMNS, and it is the
  // only row here whose answer depends on WHICH BODY was sent. Seeded with nulls
  // it matched neither statement, so every assertion about it passed without any
  // predicate existing — a row the fixture could not see. It has two answers now
  // and they are opposite ones: on a body that renames the key and nothing else
  // this row's references FOLLOW the key, because they are references like any
  // other and would otherwise stop resolving; on a body that also SENDS them
  // they stay exactly as sent, because the UPDATE stored them a moment earlier
  // and the repair may not overrule its own request.
  [FIELD_ID, BLUEPRINT, OLD_KEY, OLD_KEY,
    JSON.stringify({ field_key: OLD_KEY, operator: 'eq', value: 'yes' })],
  ['f-parent-hit', BLUEPRINT, 'child', OLD_KEY, null],
  ['f-parent-other', BLUEPRINT, 'other_child', 'unrelated', null],
  ['f-parent-case', BLUEPRINT, 'case_child', 'OLD_KEY', null],
  ['f-parent-null', BLUEPRINT, 'plain', null, null],
  ['f-rule-hit', BLUEPRINT, 'shown', null,
    JSON.stringify({ field_key: OLD_KEY, operator: 'eq', value: 'yes' })],
  ['f-rule-other', BLUEPRINT, 'shown2', null,
    JSON.stringify({ field_key: 'unrelated', operator: 'in', value: ['a', 'b'] })],
  ['f-rule-case', BLUEPRINT, 'shown3', null,
    JSON.stringify({ field_key: 'OLD_KEY', operator: 'eq', value: 'yes' })],
  ['f-rule-null', BLUEPRINT, 'shown4', null, null],
  ['f-rule-corrupt', BLUEPRINT, 'shown5', null, CORRUPT_RULE],
  // A rule that names no subject at all: JSON_SET would CREATE the path.
  ['f-rule-pathless', BLUEPRINT, 'shown6', null,
    JSON.stringify({ operator: 'eq', value: 'yes' })],
  // Another blueprint holding the same spellings — the cascade is scoped.
  ['f-other-bp-parent', OTHER_BLUEPRINT, 'elsewhere', OLD_KEY, null],
  ['f-other-bp-rule', OTHER_BLUEPRINT, 'elsewhere2', null,
    JSON.stringify({ field_key: OLD_KEY, operator: 'eq', value: 'yes' })],
];

let dbReady = false;
let dbConfig = null;
let testDbName = null;
let skipReason = null;
// The statements a body that renames the key AND NOTHING ELSE produces: the
// addressed row is excluded from no site, so its own references follow the key.
let statements = null;
// And the statements a body that also SENDS both reference columns produces:
// those are values the request wrote, so the cascade must leave them alone. Two
// captures, because the exclusion is decided per site from what the request
// named and one capture can only ever show one of the two answers.
let statementsSendingRefs = null;
let conn = null;

before(async () => {
  dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) {
    skipReason = 'no reachable MariaDB (set DB_TEST_HOST/DB_TEST_ROOT_PASSWORD or run in DevContainer)';
    // THE FLAG HAS TO BE HONOURED ON THIS BRANCH TOO, and this is the branch
    // that actually fires: a checkout without `.devcontainer/.env`, an env file
    // carrying no password, a port probe that fails. Only the `catch` below used
    // to throw, so the run that could not even find a database was the one that
    // reported success — eight assertions, the only ones anywhere here that put
    // JSON_SET to a real engine, vanished into the skipped count and the process
    // still exited 0.
    if (process.env.REQUIRE_INTEGRATION_DB === '1') {
      throw new Error(`REQUIRE_INTEGRATION_DB=1 set but ${skipReason}.`);
    }
    return;
  }
  testDbName = `integ_fkr_${process.pid}_${Date.now()}`;
  try {
    statements = await captureReferenceStatements();
    statementsSendingRefs = await captureReferenceStatements({
      field_key: NEW_KEY,
      depends_on_field_key: OLD_KEY,
      visibility_rule: JSON.stringify({ field_key: OLD_KEY, operator: 'eq', value: 'yes' }),
    });
    stopCaptureRoute();
    const admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`CREATE DATABASE \`${testDbName}\``);
    await admin.end();
    conn = await mariadb.createConnection({ ...dbConfig, database: testDbName, connectTimeout: 5000 });
    await conn.query(fieldsDDL());
    dbReady = true;
  } catch (err) {
    skipReason = `setup failed: ${err.message}`;
    if (process.env.REQUIRE_INTEGRATION_DB === '1') throw err;
  }
});

after(async () => {
  if (conn) { try { await conn.end(); } catch { /* best effort */ } }
  if (testDbName && dbConfig) {
    try {
      const cleanup = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
      await cleanup.query(`DROP DATABASE IF EXISTS \`${testDbName}\``);
      await cleanup.end();
    } catch (err) {
      console.error(`[teardown] failed to drop ${testDbName}: ${err.message}`);
    }
  }
});

async function seedAndRun(replay = statements) {
  await conn.query(`DELETE FROM \`${TEST_PREFIX}blueprint_fields\``);
  // The production column carries a json_valid() CHECK, so the unparseable row
  // cannot be INSERTed while the check is armed — and that is the point: it is
  // not a row anything writes, it is a row that predates the constraint and
  // arrives by restore, which is exactly what turning the check off reproduces.
  await conn.query('SET @@session.check_constraint_checks=OFF');
  try {
    for (const row of ROWS) {
      await conn.query(
        `INSERT INTO \`${TEST_PREFIX}blueprint_fields\` VALUES (?, ?, ?, ?, ?)`,
        row,
      );
    }
  } finally {
    await conn.query('SET @@session.check_constraint_checks=ON');
  }
  for (const statement of replay) {
    await conn.query(statement.sql, statement.params);
  }
  // CAST, because the driver parses a JSON column on the way back and THROWS on
  // the unparseable row — reading it as text is the only way to assert it came
  // through the cascade unchanged.
  const rows = await conn.query(
    `SELECT id, depends_on_field_key AS parent, CAST(visibility_rule AS CHAR) AS rule
       FROM \`${TEST_PREFIX}blueprint_fields\``,
  );
  return new Map(rows.map((r) => [r.id, r]));
}

let after_;

describe('field rename cascade — what the database does with the statements', () => {
  test('the fixture declares each reference column exactly as table-ddls.js does', async () => {
    // WHY AN ASSERTION AND NOT THE PARAGRAPH ABOVE. The header explains that
    // this fixture is deliberately the production declaration; nothing measured
    // that. Reverting `visibility_rule` to LONGTEXT — a column with a different
    // collation and no json_valid CHECK — turns no test in this repository red,
    // so the fidelity the header claims was a statement of intent. Compared as
    // DECLARED rather than through the schema manifest's normaliser, which reads
    // JSON and LONGTEXT as the same type and would accept the substitution this
    // exists to catch. Needs no database, so it runs on every machine.
    const declaredType = (line, column) => String(line)
      .replace(new RegExp(`^\`?${column}\`?`), '')
      .trim()
      .split(/\s+/)[0]
      .toUpperCase();
    const fixtureLines = fieldsDDL().split('\n').map((l) => l.trim().replace(/,$/, ''));
    for (const column of BLUEPRINT_FIELD_KEY_REFERENCE_COLUMNS) {
      const fixtureLine = fixtureLines.find((l) => l.startsWith(`${column} `));
      assert.ok(fixtureLine, `the fixture no longer declares ${column}`);
      const shipped = ddlFragmentFor('blueprint_fields', column);
      assert.ok(shipped, `table-ddls.js no longer declares ${column}`);
      assert.equal(
        declaredType(fixtureLine, column), declaredType(shipped, column),
        `the fixture declares ${column} as something other than the shipped schema does, `
        + 'so what this file measures is a column the product does not have',
      );
    }
  });


  test('the cascading picker\'s parent key moves, and only where it named the old key', async (t) => {
    if (!dbReady) { t.skip(skipReason); return; }
    after_ = await seedAndRun();

    assert.equal(after_.get('f-parent-hit').parent, NEW_KEY, 'the reference did not follow the rename');
    assert.equal(after_.get('f-parent-other').parent, 'unrelated');
    assert.equal(after_.get('f-parent-null').parent, null);
  });

  test('the renamed field\'s own reference FOLLOWS the key when the request did not send it', async (t) => {
    if (!dbReady) { t.skip(skipReason); return; }
    if (!after_) after_ = await seedAndRun();

    // The subject holds its own old key at both sites and this body renames the
    // key and nothing else. Left behind, this row's reference stops resolving —
    // and the two sites do not fail the same way. A missing cascade parent is
    // IGNORED and the select shows every option, which an operator can act on;
    // a missing visibility subject is not ignored — the evaluator reads the
    // absent key as `''`, the condition compares false, and the field joins the
    // hidden set with no key anywhere able to give it a value. Skipping a site
    // nobody asked about hides a field for good.
    assert.equal(
      after_.get(FIELD_ID).parent, NEW_KEY,
      'the addressed row\'s own cascade parent was left naming a key that no longer exists',
    );
    assert.equal(
      JSON.parse(after_.get(FIELD_ID).rule).field_key, NEW_KEY,
      'the addressed row\'s own visibility subject was left dangling, which hides the field',
    );
  });

  test('but it is left exactly as sent when the request DID send it', async (t) => {
    if (!dbReady) { t.skip(skipReason); return; }
    // A different body, so a different statement set: this one names both
    // reference columns, and the UPDATE has already stored what it sent by the
    // time the cascade runs. A repair that rewrote them would replace a value
    // the operator supplied in the same request with one they did not.
    const sent = await seedAndRun(statementsSendingRefs);
    after_ = null;

    assert.equal(
      sent.get(FIELD_ID).parent, OLD_KEY,
      'the cascade overruled the cascade parent this request wrote',
    );
    assert.equal(
      JSON.parse(sent.get(FIELD_ID).rule).field_key, OLD_KEY,
      'the cascade overruled the visibility subject this request wrote',
    );
    // The control: the OTHER rows still move under this body, so "left alone"
    // is about the addressed row and not about the cascade having stopped.
    assert.equal(sent.get('f-parent-hit').parent, NEW_KEY);
    assert.equal(JSON.parse(sent.get('f-rule-hit').rule).field_key, NEW_KEY);
  });

  test('a reference spelled with different capitalisation is left as it was', async (t) => {
    if (!dbReady) { t.skip(skipReason); return; }
    if (!after_) after_ = await seedAndRun();

    // Nothing resolves either of these today — the form looks a key up by exact
    // match — so repointing them at the renamed field would invent a link the
    // designer never made, on fields they never touched. WHAT KEEPS THEM ALONE
    // IS NOT THE SAME ON BOTH SITES; the test below measures which.
    assert.equal(after_.get('f-parent-case').parent, 'OLD_KEY');
    assert.equal(
      JSON.parse(after_.get('f-rule-case').rule).field_key, 'OLD_KEY',
      'a differently-capitalised rule subject was rewritten',
    );
  });

  test('the collation each site compares under is the one BINARY was chosen against', async (t) => {
    if (!dbReady) { t.skip(skipReason); return; }
    if (!after_) after_ = await seedAndRun();

    // The assertion above is true of both sites, but it is EVIDENCE FOR `BINARY`
    // on only ONE of them, and the difference is invisible in the SQL text:
    //
    //   depends_on_field_key  a VARCHAR under the table default
    //                         (utf8mb4_general_ci), so `= ?` alone matches
    //                         'OLD_KEY'. BINARY is what leaves that row alone.
    //   visibility_rule       compared through JSON_UNQUOTE, whose RESULT is
    //                         utf8mb4_bin — measured below to be a property of
    //                         the function and not of the column it read from,
    //                         which is the part that is easy to get wrong.
    //                         BINARY agrees with the engine there rather than
    //                         causing the behaviour.
    //
    // Asked of the engine rather than stated in a comment, because the comment
    // this replaces said the column's collation was case-INsensitive on both
    // sites and used that to explain a result it does not produce.
    const [collations] = await conn.query(
      `SELECT COLLATION(depends_on_field_key) AS parent_coll,
              COLLATION(JSON_UNQUOTE(JSON_EXTRACT(visibility_rule, '$."field_key"'))) AS rule_coll,
              COLLATION(JSON_UNQUOTE(JSON_EXTRACT(
                CONVERT('{"field_key":"OLD_KEY"}' USING utf8mb4) COLLATE utf8mb4_general_ci,
                '$."field_key"'))) AS from_ci_source
         FROM \`${TEST_PREFIX}blueprint_fields\` WHERE id = 'f-rule-hit'`,
    );
    assert.equal(
      collations.parent_coll, 'utf8mb4_general_ci',
      'the column-shaped reference is no longer compared case-insensitively, so BINARY no longer decides anything there',
    );
    assert.equal(
      collations.rule_coll, 'utf8mb4_bin',
      'the document-shaped reference is no longer compared byte for byte, so BINARY is now what decides it',
    );
    assert.equal(
      collations.from_ci_source, 'utf8mb4_bin',
      'JSON_UNQUOTE now carries its source collation out, so the column\'s own declaration decides '
      + 'the document-shaped comparison after all — and this fixture must then match the DDL exactly',
    );
  });

  test('the visibility rule\'s subject moves and the rest of the rule survives', async (t) => {
    if (!dbReady) { t.skip(skipReason); return; }
    if (!after_) after_ = await seedAndRun();

    assert.deepEqual(
      JSON.parse(after_.get('f-rule-hit').rule),
      { field_key: NEW_KEY, operator: 'eq', value: 'yes' },
      'the subject must move without disturbing the operator or the value',
    );
    assert.deepEqual(
      JSON.parse(after_.get('f-rule-other').rule),
      { field_key: 'unrelated', operator: 'in', value: ['a', 'b'] },
    );
  });

  test('a rule that named no subject does not acquire one', async (t) => {
    if (!dbReady) { t.skip(skipReason); return; }
    if (!after_) after_ = await seedAndRun();

    // JSON_SET CREATES an absent path. Without the predicate that requires the
    // old key to be there, every rule in the blueprint would come back naming
    // the renamed field.
    assert.deepEqual(
      JSON.parse(after_.get('f-rule-pathless').rule),
      { operator: 'eq', value: 'yes' },
      'JSON_SET wrote a subject into a rule that had none',
    );
  });

  test('a NULL rule stays NULL and an unparseable one survives verbatim', async (t) => {
    if (!dbReady) { t.skip(skipReason); return; }
    if (!after_) after_ = await seedAndRun();

    assert.equal(after_.get('f-rule-null').rule, null);
    assert.equal(
      after_.get('f-rule-corrupt').rule, CORRUPT_RULE,
      'an unreadable rule must survive the repair rather than becoming NULL',
    );
  });

  test('another blueprint holding the same spellings is not touched', async (t) => {
    if (!dbReady) { t.skip(skipReason); return; }
    if (!after_) after_ = await seedAndRun();

    assert.equal(after_.get('f-other-bp-parent').parent, OLD_KEY);
    assert.equal(JSON.parse(after_.get('f-other-bp-rule').rule).field_key, OLD_KEY);
  });

  test('running the cascade twice changes nothing the second time', async (t) => {
    if (!dbReady) { t.skip(skipReason); return; }
    await seedAndRun();
    const before = await conn.query(
      `SELECT id, depends_on_field_key, CAST(visibility_rule AS CHAR) AS visibility_rule
         FROM \`${TEST_PREFIX}blueprint_fields\` ORDER BY id`,
    );
    for (const statement of statements) {
      await conn.query(statement.sql, statement.params);
    }
    const again = await conn.query(
      `SELECT id, depends_on_field_key, CAST(visibility_rule AS CHAR) AS visibility_rule
         FROM \`${TEST_PREFIX}blueprint_fields\` ORDER BY id`,
    );
    assert.deepEqual(again, before, 'a retried rename must not move anything a second time');
    after_ = null;
  });
});
