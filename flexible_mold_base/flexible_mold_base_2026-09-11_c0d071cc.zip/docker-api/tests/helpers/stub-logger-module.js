'use strict';

/**
 * stub-logger-module.js — install a require.cache double for
 * shared/lib/logger.js that keeps every real export and only overrides the
 * ones a test needs to intercept (usually `logger`). A double built as a
 * bare `{ logger }` object strands any caller that also needs a later export
 * (e.g. send-error.js's `captureCallerSrc`) added after the double was
 * written — see memory: a partial module double is a time bomb.
 *
 * @param {string} loggerKey - require.resolve('.../shared/lib/logger') from
 *   the calling test file (the relative path depth varies per test file
 *   location, so callers resolve it themselves).
 * @param {object} overrides - exports to replace, e.g. { logger: fakeLogger }.
 * @returns {object} the real module's untouched exports, for a test that
 *   wants to read a field (e.g. captureCallerSrc) directly.
 */
function stubLoggerModule(loggerKey, overrides) {
  const real = require(loggerKey);
  require.cache[loggerKey] = {
    id: loggerKey,
    filename: loggerKey,
    loaded: true,
    exports: { ...real, ...overrides },
  };
  return real;
}

module.exports = { stubLoggerModule };
