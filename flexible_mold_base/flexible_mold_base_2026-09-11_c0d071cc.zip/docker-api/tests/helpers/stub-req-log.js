'use strict';

// stub-req-log.js — TEST-ONLY stand-in for `req.log`. Production code calls
// `req.log?.setBindings(...)` (s2s-verify.js, infra/middleware/auth.js) and
// treats `req.log` as a pino child logger (spec §6) everywhere else. `console`
// has neither `.setBindings` nor `.child`, so a test that mounts real
// identity/audit middleware with `req.log = console` throws
// `req.log.setBindings is not a function` the moment that path runs
// (fmb-2091 M1). This stub honours the pino child-logger shape the
// production code assumes, silently, instead of widening the production
// `?.setBindings` check to tolerate a narrower test double.
function makeStubReqLog() {
  const stub = {
    fatal() {},
    error() {},
    warn() {},
    info() {},
    debug() {},
    trace() {},
    setBindings() {},
    child() { return stub; },
  };
  return stub;
}

module.exports = { makeStubReqLog };
