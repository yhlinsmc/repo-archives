'use strict';

/**
 * migration-sys-kind.test.js — migrations.js binds `kind:'sys'` on its
 * module-level child logger (logging epic PR-3, fmb-2105) so all 20 existing
 * `logger.info`/`.warn`/`.error` migration-step call sites carry it without
 * a per-site edit. Proves the exact child-binding shape migrations.js uses
 * against a real pino instance (same pattern as send-error.test.js), and
 * that requiring migrations.js does not itself touch a DB pool.
 */
const { test } = require('node:test');
const assert = require('node:assert/strict');
const { Writable } = require('node:stream');
const pino = require('pino');
const { _internals } = require('../../src/shared/lib/logger');

function makeCapture() {
  const records = [];
  const sink = new Writable({
    write(chunk, _e, cb) {
      for (const line of chunk.toString().split('\n')) {
        if (line.trim()) records.push(JSON.parse(line));
      }
      cb();
    },
  });
  const base = pino(_internals.loggerOptions, sink);
  return { records, base };
}

test('a child logger bound {module:"db", kind:"sys"} emits kind:sys on every level without a per-call kind', () => {
  const { records, base } = makeCapture();
  const migrationLogger = base.child({ module: 'db', kind: 'sys' });
  migrationLogger.info({ table: 't1', column: 'c1' }, 'schema migration added column');
  migrationLogger.warn({ err: new Error('boom'), step: 'x' }, 'schema migration step skipped');
  migrationLogger.error({ err: new Error('boom') }, 'Failed to write platform_schema_version');
  assert.equal(records.length, 3);
  for (const r of records) {
    assert.equal(r.kind, 'sys', `expected kind:sys, got ${JSON.stringify(r)}`);
    assert.equal(r.module, 'db');
  }
  assert.equal(records[0].level, 'info');
  assert.equal(records[1].level, 'warn');
  assert.equal(records[2].level, 'error');
});

test('requiring migrations.js does not touch a DB pool (no throw, no side effect at require time)', () => {
  assert.doesNotThrow(() => require('../../src/edge/migrations.js'));
});

test('migrations.js module logger is bound with kind:sys', () => {
  // Re-require via a fresh module-cache entry pointing logger.js's exported
  // instance at a captured destination is not possible (logger.js freezes
  // its pino instance at require-time) — instead assert the SOURCE carries
  // the binding literally, so a future edit cannot silently drop it without
  // failing this test.
  const src = require('node:fs').readFileSync(
    require.resolve('../../src/edge/migrations.js'),
    'utf8',
  );
  assert.match(src, /rootLogger\.child\(\{\s*module:\s*['"]db['"],\s*kind:\s*['"]sys['"]\s*\}\)/);
});
