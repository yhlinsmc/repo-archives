'use strict';

/**
 * pool-ready-transition-sys-log.test.js — db.js's `notePoolReadyTransition`
 * (logging epic PR-3, fmb-2105, spec §7 sys): pool lost (warn) / recovered
 * (info) logs exactly once per transition; two consecutive observations of
 * the SAME state log nothing (the per-field-gate-can't-see-a-sibling family —
 * here the "sibling" is the previous observation, and the guard is a single
 * shared module-level flag, not a per-call decision).
 */
const { test } = require('node:test');
const assert = require('node:assert/strict');

process.env.JWT_SECRET = process.env.JWT_SECRET || 'a'.repeat(48);
process.env.S2S_API_KEY = process.env.S2S_API_KEY || 's2s-test';

const { _internalsForTest } = require('../../src/edge/db');
const { logger } = require('../../src/shared/lib/logger');

function captureCalls(level) {
  const calls = [];
  const original = logger[level];
  logger[level] = (...args) => { calls.push(args); };
  return { calls, restore: () => { logger[level] = original; } };
}

test('a flip to ready logs one info/kind:sys line; repeating ready logs nothing', () => {
  _internalsForTest._resetPoolReadyObserved();
  const info = captureCalls('info');
  const warn = captureCalls('warn');
  try {
    _internalsForTest.notePoolReadyTransition(true);
    _internalsForTest.notePoolReadyTransition(true);
    _internalsForTest.notePoolReadyTransition(true);
    assert.equal(info.calls.length, 1, `expected exactly one info line, got ${info.calls.length}`);
    assert.equal(warn.calls.length, 0);
    const [binding, msg] = info.calls[0];
    assert.equal(binding.kind, 'sys');
    assert.equal(msg, 'pool recovered');
  } finally {
    info.restore();
    warn.restore();
  }
});

test('a flip to lost logs one warn/kind:sys line; a further flip back to ready logs one more', () => {
  _internalsForTest._resetPoolReadyObserved();
  const info = captureCalls('info');
  const warn = captureCalls('warn');
  try {
    _internalsForTest.notePoolReadyTransition(true); // first observation ever (recovered)
    _internalsForTest.notePoolReadyTransition(false); // lost
    _internalsForTest.notePoolReadyTransition(false); // repeat — silent
    _internalsForTest.notePoolReadyTransition(true); // recovered again
    assert.equal(warn.calls.length, 1, `expected exactly one warn line, got ${warn.calls.length}`);
    assert.equal(info.calls.length, 2, `expected exactly two info lines (2 distinct recover events), got ${info.calls.length}`);
    assert.equal(warn.calls[0][1], 'pool lost');
    assert.equal(warn.calls[0][0].kind, 'sys');
  } finally {
    info.restore();
    warn.restore();
  }
});
