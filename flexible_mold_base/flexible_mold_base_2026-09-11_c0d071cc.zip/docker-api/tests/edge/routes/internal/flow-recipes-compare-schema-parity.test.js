/**
 * flow-recipes-compare-schema-parity.test.js — validates every column the
 * compare-begin route's SELECT statements reference against the ACTUAL
 * table DDLs, WITHOUT a live DB. Mirrors capacity-delete-preview-schema-
 * parity.test.js's extraction pattern (and flow-recipes-remote-refs-schema-
 * parity.test.js's anchored-regex style for this same source file).
 */
const { describe, it, before } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const { buildEngineTableDDLs } = require('../../../../src/table-ddls');
const { TABLES } = require('../../../../src/shared/constants');

// name → physical table name, e.g. 'FLOW_RECIPES' → 'flow_recipes' — the
// route source names tables via `TABLES.X`, the DDL parser (identity t) keys
// columnsByTable by the physical name, so the regex-captured JS constant
// name has to be resolved through TABLES before it can look anything up.
const TABLE_CONSTANTS = Object.fromEntries(
  Object.entries(TABLES).map(([name, value]) => [name, String(value)]),
);

const SQL_TYPES = /^`?([a-z_]+)`?\s+(?:CHAR|VARCHAR|INT|DOUBLE|TIMESTAMP|JSON|TEXT|ENUM|BOOLEAN|TINYINT|BIGINT|DATETIME|DECIMAL|FLOAT|BLOB)\b/i;

let columnsByTable;
before(() => {
  columnsByTable = new Map();
  for (const ddl of buildEngineTableDDLs((n) => n)) {
    const m = ddl.match(/CREATE TABLE IF NOT EXISTS `([^`]+)`/);
    if (!m) continue;
    const table = m[1];
    const cols = new Set();
    for (const rawLine of ddl.split('\n')) {
      const line = rawLine.trim();
      if (!line || line.startsWith('--') || line.startsWith('/*')) continue;
      const cm = line.match(SQL_TYPES);
      if (cm) cols.add(cm[1]);
    }
    columnsByTable.set(table, cols);
  }
});

const SRC = fs.readFileSync(
  path.resolve(__dirname, '../../../../src/edge/routes/internal/flow-recipes-run.js'), 'utf8',
);

/** Every `SELECT <cols> FROM \`${t(TABLES.X)}\`` statement inside the
 *  compare-begin handler (anchored on its own JSDoc so this never picks up
 *  run-begin's or reset-flow-link's statements above/below it). */
function compareBeginSelectColumnLists() {
  const start = SRC.indexOf("router.post('/compare-begin'");
  assert.notEqual(start, -1, 'compare-begin route is gone or renamed');
  const end = SRC.indexOf("router.post('/run-finalize'", start);
  assert.notEqual(end, -1, 'run-finalize route is gone or renamed (end anchor)');
  const body = SRC.slice(start, end);
  const re = /SELECT ([a-z_, ]+) FROM \\`\$\{t\(TABLES\.([A-Z_]+)\)\}\\`/g;
  const lists = [];
  let m;
  while ((m = re.exec(body))) {
    assert.ok(TABLE_CONSTANTS[m[2]], `the statement reads TABLES.${m[2]}, which is not a TABLES constant`);
    lists.push({ table: m[2], physicalTable: TABLE_CONSTANTS[m[2]], columns: m[1].split(',').map((c) => c.trim()).filter(Boolean) });
  }
  return lists;
}

describe('flow-recipes-run.js compare-begin SELECTs — schema parity', () => {
  it('finds the six SELECT variants (recipe wide/narrow, template wide/narrow, steps wide/narrow)', () => {
    const lists = compareBeginSelectColumnLists();
    assert.equal(lists.length, 6, 'expected exactly 6 SELECT statements inside compare-begin');
  });

  it('every selected column exists on the table it is selected from', () => {
    for (const { table, physicalTable, columns } of compareBeginSelectColumnLists()) {
      const cols = columnsByTable.get(physicalTable);
      assert.ok(cols && cols.size > 0, `no columns parsed for ${physicalTable} (TABLES.${table})`);
      for (const col of columns) {
        assert.ok(cols.has(col), `${physicalTable} has no column '${col}' referenced by the compare-begin SELECT`);
      }
    }
  });

  it('the widest recipe SELECT includes compare_spec', () => {
    const lists = compareBeginSelectColumnLists().filter((l) => l.table === 'FLOW_RECIPES');
    assert.equal(lists.length, 2, 'expected a wide + narrow recipe SELECT');
    assert.ok(lists[0].columns.includes('compare_spec'), 'the widest recipe SELECT must include compare_spec');
    assert.ok(!lists[1].columns.includes('compare_spec'), 'the narrow (legacy-fallback) recipe SELECT must NOT include compare_spec');
  });

  it('the widest steps SELECT includes method and step_runs_on (the GET-only guard needs both)', () => {
    const lists = compareBeginSelectColumnLists().filter((l) => l.table === 'FLOW_RECIPE_STEPS');
    assert.equal(lists.length, 2, 'expected a wide + narrow steps SELECT');
    for (const col of ['method', 'step_runs_on']) {
      assert.ok(lists[0].columns.includes(col), `the widest steps SELECT must include ${col}`);
    }
    assert.ok(lists[1].columns.includes('method'), 'the narrow steps SELECT must still include method — it always exists');
  });

  it('the widest template SELECT includes flow_external_id and flow_remote_refs', () => {
    const lists = compareBeginSelectColumnLists().filter((l) => l.table === 'USER_TEMPLATES');
    assert.equal(lists.length, 2, 'expected a wide + narrow template SELECT');
    for (const col of ['flow_external_id', 'flow_remote_refs']) {
      assert.ok(lists[0].columns.includes(col), `the widest template SELECT must include ${col}`);
    }
    assert.ok(!lists[1].columns.includes('flow_remote_refs'), 'the narrow template SELECT must NOT include flow_remote_refs');
  });
});
