/**
 * flow-recipes-remote-refs-schema-parity.test.js — validates every column the
 * remote_refs read/write paths reference (run-begin's template SELECT, the
 * run-finalize cache write-back UPDATE, and the reset-flow-link clear UPDATE)
 * against the ACTUAL user_templates table DDL, WITHOUT a live DB. Mirrors
 * capacity-delete-preview-schema-parity.test.js's extraction pattern.
 */
const { describe, it, before } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const { buildEngineTableDDLs } = require('../../../../src/table-ddls');

let columns;
before(() => {
  for (const ddl of buildEngineTableDDLs((n) => n)) {
    const m = ddl.match(/CREATE TABLE IF NOT EXISTS `([^`]+)`/);
    if (!m || m[1] !== 'user_templates') continue;
    columns = new Set();
    for (const rawLine of ddl.split('\n')) {
      const line = rawLine.trim();
      const cm = line.match(/^`?([a-z_]+)`?\s+(?:CHAR|VARCHAR|INT|DOUBLE|TIMESTAMP|JSON|TEXT|ENUM|BOOLEAN|TINYINT|BIGINT|DATETIME|DECIMAL|FLOAT|BLOB)\b/i);
      if (cm) columns.add(cm[1]);
    }
  }
});

const SRC = fs.readFileSync(
  path.resolve(__dirname, '../../../../src/edge/routes/internal/flow-recipes-run.js'), 'utf8',
);

describe('user_templates schema parity — flow_remote_refs read/write paths', () => {
  it('parsed a non-trivial column set for user_templates (parse-works guard)', () => {
    assert.ok(columns && columns.size > 5, 'no columns parsed for user_templates');
  });

  it('every column the remote_refs paths reference exists on user_templates', () => {
    for (const col of ['flow_external_id', 'flow_link', 'flow_last_run_id', 'flow_remote_refs', 'owner_id', 'blueprint_id']) {
      assert.ok(columns.has(col), `user_templates has no column '${col}'`);
    }
  });

  // fmb-2102 P2: the run INSERT's conditional gate re-asks blueprint parity
  // atomically (both the owner/grant arm and the admin arm); a 0-row match
  // on either arm answers the existence-neutral 403 without re-reading why.
  it('the run-begin insert gate names blueprint_id on both the admin arm and the owner/grant arm', () => {
    const start = SRC.indexOf("router.post('/run-begin'");
    assert.notEqual(start, -1, 'run-begin route is gone or renamed');
    const end = SRC.indexOf("router.post('/compare-begin'", start);
    assert.notEqual(end, -1, 'compare-begin route is gone or renamed (end anchor)');
    const body = SRC.slice(start, end);
    const gateClauses = [...body.matchAll(/WHERE ut\.\\`id\\` = \? AND[^;]*?ut\.\\`blueprint_id\\` = \?/g)];
    assert.equal(gateClauses.length, 2, 'expected exactly one admin-arm and one owner/grant-arm gate naming blueprint_id');
  });

  it('the run-begin template SELECT names flow_external_id and flow_remote_refs (widest tier)', () => {
    const m = SRC.match(/SELECT owner_id, blueprint_id, flow_last_run_id, flow_external_id, flow_remote_refs FROM/);
    assert.ok(m, 'run-begin no longer selects flow_external_id + flow_remote_refs in its widest template-row tier');
  });

  it('the run-finalize cache write-back UPDATE sets flow_remote_refs (widest tier)', () => {
    const m = SRC.match(/SET flow_external_id=\?, flow_link=\?, flow_last_run_id=\?, flow_remote_refs=\? WHERE id=\? AND owner_id IS NOT NULL/);
    assert.ok(m, 'run-finalize cache write-back no longer sets flow_remote_refs in its widest tier');
  });

  it('the reset-flow-link clear UPDATE nulls flow_remote_refs (widest tier)', () => {
    const m = SRC.match(/SET flow_external_id=NULL, flow_link=NULL, flow_last_run_id=NULL, flow_remote_refs=NULL/);
    assert.ok(m, 'reset-flow-link clear no longer nulls flow_remote_refs in its widest tier');
  });
});
