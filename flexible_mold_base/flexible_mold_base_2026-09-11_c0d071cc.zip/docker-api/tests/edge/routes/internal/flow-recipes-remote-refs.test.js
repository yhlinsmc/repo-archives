/**
 * flow-recipes-remote-refs.test.js — fmb-2090 PR-C1 Task C1.4.
 *
 * Covers the flow_remote_refs reserved-key persistence (run-finalize),
 * reset-flow-link clearing it, and run-begin seeding stored_remote_refs /
 * stored_external_id for the update-mode chain seed.
 *
 * Mirrors the flow-recipes-run-finalize.test.js / flow-recipes-run-begin.test.js
 * harness: mocked pool injected via require.cache before router require.
 *
 * Run:
 *   cd docker-api && NODE_ENV=test node --test tests/edge/routes/internal/flow-recipes-remote-refs.test.js
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../../../src/edge/db');

let recipeRow = null;
let runRow = null;
let templateRow = null;
let cacheUpdateCount = 0;
let lastCacheUpdate = null;
let resetUpdateCount = 0;
let lastResetUpdate = null;
let simulateNoRemoteRefsColumn = false; // 1054 on any statement naming flow_remote_refs
let currentUserId = 'u1';
let currentRole = 'admin';
let stepCodeRows = [];

function badField() {
  const e = new Error("Unknown column 'flow_remote_refs' in 'field list'");
  e.errno = 1054;
  e.code = 'ER_BAD_FIELD_ERROR';
  return e;
}

const conn = {
  async query(sql, params) {
    if (/FROM `fmb_flow_recipe_steps`/.test(sql) && /step_type/.test(sql)) {
      return stepCodeRows;
    }
    if (/FROM `fmb_flow_recipes`/.test(sql) && /WHERE id = \?/.test(sql)) {
      return recipeRow ? [recipeRow] : [];
    }
    if (/FROM `fmb_flow_recipe_runs`/.test(sql) && /WHERE id = \?/.test(sql)) {
      return runRow ? [runRow] : [];
    }
    if (/FROM `fmb_user_templates`/.test(sql) && /WHERE id = \?$/.test(sql)) {
      if (simulateNoRemoteRefsColumn && /flow_remote_refs/.test(sql)) throw badField();
      return templateRow ? [templateRow] : [];
    }
    if (/UPDATE `fmb_flow_recipe_runs`/i.test(sql)) {
      return { affectedRows: 1 };
    }
    if (/information_schema\.TABLES/i.test(sql)) {
      return [];
    }
    // user_templates reset-flow-link clear UPDATE — matched BEFORE the finalize
    // cache branch below, since both share the `SET flow_external_id` prefix
    // and only the reset one binds it to the literal NULL.
    if (/UPDATE `fmb_user_templates`/i.test(sql) && /SET flow_external_id=NULL/.test(sql)) {
      if (simulateNoRemoteRefsColumn && /flow_remote_refs/.test(sql)) throw badField();
      resetUpdateCount++;
      lastResetUpdate = { sql, params };
      return { affectedRows: 1 };
    }
    // user_templates cache write-back UPDATE (run-finalize)
    if (/UPDATE `fmb_user_templates`/i.test(sql) && /SET flow_external_id/.test(sql)) {
      if (simulateNoRemoteRefsColumn && /flow_remote_refs/.test(sql)) throw badField();
      cacheUpdateCount++;
      lastCacheUpdate = { sql, params };
      return { affectedRows: 1 };
    }
    return [];
  },
  release() {},
};

require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: {
    pool: {
      ro: { getConnection: async () => conn },
      rw: { getConnection: async () => conn },
    },
    t: (name) => `fmb_${name}`,
  },
};

const router = require('../../../../src/edge/routes/internal/flow-recipes-run');
const { _resetGrantsTableCache } = require('../../../../src/edge/lib/delegated-grants');

let server; let baseUrl;
before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => {
    req.user = { id: currentUserId, role: currentRole };
    next();
  });
  app.use('/edge/internal/flow-recipes', router);
  server = http.createServer(app);
  await new Promise((r) => server.listen(0, r));
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});
after(() => server && server.close());

beforeEach(() => {
  recipeRow = null;
  runRow = null;
  templateRow = null;
  cacheUpdateCount = 0;
  lastCacheUpdate = null;
  resetUpdateCount = 0;
  lastResetUpdate = null;
  simulateNoRemoteRefsColumn = false;
  currentUserId = 'u1';
  currentRole = 'admin';
  stepCodeRows = [];
  _resetGrantsTableCache();
});

function makeRecipe(overrides = {}) {
  return {
    id: 'r1',
    link_extract: JSON.stringify({ path: 'url' }),
    external_id_extract: JSON.stringify({ path: 'id' }),
    ...overrides,
  };
}

function makeRun(overrides = {}) {
  return { id: 'run1', recipe_id: 'r1', template_id: 'tpl1', actor_id: 'u1', ...overrides };
}

async function postFinalize(body) {
  const res = await fetch(`${baseUrl}/edge/internal/flow-recipes/run-finalize`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
  });
  return { status: res.status, body: await res.json() };
}

async function postReset(body) {
  const res = await fetch(`${baseUrl}/edge/internal/flow-recipes/reset-flow-link`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
  });
  return { status: res.status, body: await res.json() };
}

describe('run-finalize persists remote_refs', () => {
  it('finalize persists a plain-object remote_refs to flow_remote_refs', async () => {
    recipeRow = makeRecipe();
    runRow = makeRun();

    const r = await postFinalize({
      run_id: 'run1', recipe_id: 'r1', ok: true, upstream_status: 200,
      body: JSON.stringify({ url: 'https://flow/x', id: 'EXT-1' }),
      remote_refs: { 5: 'task-9' },
    });

    assert.equal(r.status, 200, JSON.stringify(r.body));
    assert.equal(cacheUpdateCount, 1);
    assert.ok(lastCacheUpdate.sql.includes('flow_remote_refs'), 'cache UPDATE must set flow_remote_refs');
    assert.ok(lastCacheUpdate.params.includes(JSON.stringify({ 5: 'task-9' })),
      'flow_remote_refs param must be the JSON-encoded object');
    assert.equal(r.body.data.remote_refs_notice, null);
  });

  it('a dropped remote_refs OMITS the column so the prior cache value is kept, not overwritten with NULL', async () => {
    recipeRow = makeRecipe();
    runRow = makeRun();

    const r = await postFinalize({
      run_id: 'run1', recipe_id: 'r1', ok: true, upstream_status: 200,
      body: JSON.stringify({ url: 'https://flow/x', id: 'EXT-1' }),
      remote_refs: [1, 2, 3],
    });

    assert.equal(r.status, 200);
    assert.equal(r.body.data.status, 'success');
    assert.equal(r.body.data.remote_refs_notice, 'remote_refs_dropped');
    assert.equal(cacheUpdateCount, 1);
    // The column is left out of the SET list entirely — the run kept its
    // external_id/link/last_run_id but did not touch flow_remote_refs, so the
    // prior good cache survives. Before the fix the wide UPDATE bound
    // flow_remote_refs=NULL, clobbering it.
    assert.ok(!lastCacheUpdate.sql.includes('flow_remote_refs'),
      'a dropped remote_refs must be omitted from the cache UPDATE, not written as NULL');
  });

  it('an over-64KB remote_refs is dropped with the same notice', async () => {
    recipeRow = makeRecipe();
    runRow = makeRun();
    const big = { blob: 'x'.repeat(70 * 1024) };

    const r = await postFinalize({
      run_id: 'run1', recipe_id: 'r1', ok: true, upstream_status: 200,
      body: JSON.stringify({ url: 'https://flow/x', id: 'EXT-1' }),
      remote_refs: big,
    });

    assert.equal(r.status, 200);
    assert.equal(r.body.data.status, 'success');
    assert.equal(r.body.data.remote_refs_notice, 'remote_refs_dropped');
  });

  it('a multibyte remote_refs whose .length is under 64K but bytes are over is dropped (byte-sized cap)', async () => {
    recipeRow = makeRecipe();
    runRow = makeRun();
    // 30000 CJK chars: JSON string length ~30012 (< 65536 code units) but ~90KB
    // UTF-8 bytes. A code-unit .length check would wrongly cache it past the
    // column ceiling; the byte check drops it.
    const cjk = { blob: '中'.repeat(30000) };
    assert.ok(JSON.stringify(cjk).length <= 64 * 1024, 'guard: .length must be under the cap for this test to prove the byte fix');
    assert.ok(Buffer.byteLength(JSON.stringify(cjk), 'utf8') > 64 * 1024, 'guard: bytes must exceed the cap');

    const r = await postFinalize({
      run_id: 'run1', recipe_id: 'r1', ok: true, upstream_status: 200,
      body: JSON.stringify({ url: 'https://flow/x', id: 'EXT-1' }),
      remote_refs: cjk,
    });

    assert.equal(r.status, 200);
    assert.equal(r.body.data.remote_refs_notice, 'remote_refs_dropped');
    assert.ok(!lastCacheUpdate.sql.includes('flow_remote_refs'),
      'a byte-oversized remote_refs must be omitted, keeping the prior cache');
  });

  it('a remote_refs the server cannot JSON-encode (deep nesting) is dropped; finalize still reaches its terminal UPDATE', async () => {
    recipeRow = makeRecipe();
    runRow = makeRun();
    // A deeply nested array express.json() can PARSE (V8's array parser is
    // iterative) but the handler's recursive JSON.stringify cannot re-encode
    // (RangeError). The wire bytes are hand-assembled because stringifying this
    // client-side would throw here too; the depth is kept well under the body-
    // size limit while still overflowing stringify's stack. Without the try/catch
    // the RangeError escapes into the finalize handler and 500s an already-
    // finalized run.
    const depth = 30000;
    const deepArray = '['.repeat(depth) + ']'.repeat(depth);
    const upstreamBody = JSON.stringify(JSON.stringify({ url: 'https://flow/x', id: 'EXT-1' }));
    const rawBody = `{"run_id":"run1","recipe_id":"r1","ok":true,"upstream_status":200,"body":${upstreamBody},"remote_refs":{"d":${deepArray}}}`;

    const res = await fetch(`${baseUrl}/edge/internal/flow-recipes/run-finalize`, {
      method: 'POST', headers: { 'content-type': 'application/json' }, body: rawBody,
    });
    const body = await res.json();

    assert.equal(res.status, 200, JSON.stringify(body));
    assert.equal(body.data.status, 'success');
    assert.equal(body.data.remote_refs_notice, 'remote_refs_dropped');
    assert.equal(cacheUpdateCount, 1, 'the finalize must still reach its terminal cache UPDATE');
    assert.ok(!lastCacheUpdate.sql.includes('flow_remote_refs'));
  });

  it('a no-ALTER DB missing flow_remote_refs still finalizes (degrades to the narrower cache UPDATE)', async () => {
    recipeRow = makeRecipe();
    runRow = makeRun();
    simulateNoRemoteRefsColumn = true;

    const r = await postFinalize({
      run_id: 'run1', recipe_id: 'r1', ok: true, upstream_status: 200,
      body: JSON.stringify({ url: 'https://flow/x', id: 'EXT-1' }),
      remote_refs: { 5: 'task-9' },
    });

    assert.equal(r.status, 200, JSON.stringify(r.body));
    assert.equal(r.body.data.status, 'success');
    assert.equal(cacheUpdateCount, 1, 'exactly one (narrower) cache UPDATE must land');
    assert.ok(!lastCacheUpdate.sql.includes('flow_remote_refs'));
  });
});

describe('reset-flow-link nulls remote_refs', () => {
  it('the clear UPDATE includes flow_remote_refs=NULL', async () => {
    const r = await postReset({ template_id: 'tpl1' });
    assert.equal(r.status, 200, JSON.stringify(r.body));
    assert.equal(resetUpdateCount, 1);
    assert.ok(lastResetUpdate.sql.includes('flow_remote_refs=NULL'), 'reset clear must null flow_remote_refs');
  });

  it('a no-ALTER DB missing flow_remote_refs still resets (degrades to the narrower clear)', async () => {
    simulateNoRemoteRefsColumn = true;
    const r = await postReset({ template_id: 'tpl1' });
    assert.equal(r.status, 200, JSON.stringify(r.body));
    assert.equal(resetUpdateCount, 1);
    assert.ok(!lastResetUpdate.sql.includes('flow_remote_refs'));
  });
});

// run-begin's stored_remote_refs / stored_external_id seed is covered in
// flow-recipes-run-begin.test.js, which already carries the fuller
// run-begin mock harness (INSERT gating, step/template tier simulation) —
// adding a second, narrower harness here for the same route risks the two
// silently disagreeing (memory: a hand-rolled test double is a second
// implementation of the rule it is meant to pin).
