/**
 * flow-recipes-compare.test.js
 *
 * Tests for POST /edge/internal/flow-recipes/compare-begin — the read-only
 * compare pass (spec Q19/Q20/Q21). Mirrors the run-begin test harness
 * (flow-recipes-run-begin.test.js): mocked pool injected via require.cache
 * before router require, single live server.
 *
 * Covers:
 *   (a) an update-able template's approved recipe returns only its
 *       compare-only steps and inserts no run row
 *   (b) a compare step whose method is not GET → 400 COMPARE_STEP_NOT_READONLY
 *   (c) a caller with no access to the template → 403 TEMPLATE_FORBIDDEN
 *   (d) the response carries compare_spec, stored_external_id, stored_remote_refs
 *   (e) recipe-state gates (not approved / inactive / unbound) still apply
 *   (f) template_id is required
 */
const { it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../../../src/edge/db');

let recipeRow = null;
let stepsRows = [];
let templateRow = null;
let insertCount = 0;
let currentUserId = 'u1';
let currentRole = 'user';
let grantRows = [];
let grantsTablePresent = false;
let blueprintOwnerId = null;

const conn = {
  async query(sql, params) {
    if (/^\s*INSERT INTO/i.test(sql)) {
      insertCount += 1;
      return { insertId: 'should-not-happen', affectedRows: 1 };
    }
    if (/FROM `fmb_flow_recipes`/.test(sql) && /WHERE id = \?/.test(sql)) {
      return recipeRow ? [recipeRow] : [];
    }
    if (/FROM `fmb_user_templates`/.test(sql)) {
      return templateRow ? [templateRow] : [];
    }
    if (/FROM `fmb_flow_recipe_steps`/.test(sql)) {
      return stepsRows;
    }
    if (/information_schema\.TABLES/i.test(sql)) {
      const [name] = params || [];
      if (String(name).endsWith('delegated_grants')) return grantsTablePresent ? [{ 1: 1 }] : [];
      return [];
    }
    if (/FROM `fmb_delegated_grants`/.test(sql)) {
      return grantRows;
    }
    if (/SELECT 1 AS owned FROM `fmb_hierarchy_nodes`/.test(sql)) {
      const [, callerId] = params || [];
      return blueprintOwnerId && callerId === blueprintOwnerId ? [{ owned: 1 }] : [];
    }
    return [];
  },
  release() {},
};

require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: {
    pool: {
      ro: { getConnection: async () => conn },
      rw: { getConnection: async () => conn },
    },
    t: (name) => `fmb_${name}`,
  },
};

const router = require('../../../../src/edge/routes/internal/flow-recipes-run');
const { _resetGrantsTableCache } = require('../../../../src/edge/lib/delegated-grants');

let server; let baseUrl;
let _prevEncKey;
before(async () => {
  _prevEncKey = process.env.SETTINGS_ENCRYPTION_KEY;
  // compare-begin mints an HMAC compare token, which needs the server secret.
  process.env.SETTINGS_ENCRYPTION_KEY = 'compare-begin-test-key';
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => {
    req.user = { id: currentUserId, role: currentRole };
    next();
  });
  app.use('/edge/internal/flow-recipes', router);
  server = http.createServer(app);
  await new Promise((r) => server.listen(0, r));
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});
after(() => {
  if (_prevEncKey === undefined) delete process.env.SETTINGS_ENCRYPTION_KEY;
  else process.env.SETTINGS_ENCRYPTION_KEY = _prevEncKey;
  return server && server.close();
});

beforeEach(() => {
  recipeRow = null;
  stepsRows = [];
  templateRow = null;
  insertCount = 0;
  currentUserId = 'u1';
  currentRole = 'user';
  grantRows = [];
  grantsTablePresent = false;
  blueprintOwnerId = null;
  _resetGrantsTableCache();
});

function makeRecipe(overrides = {}) {
  return {
    id: 'r1', status: 'approved', is_active: 1, blueprint_id: 'bp1',
    compare_spec: JSON.stringify({ localPath: '$.name', remotePath: '$.data.name' }),
    ...overrides,
  };
}

async function post(body) {
  const res = await fetch(`${baseUrl}/edge/internal/flow-recipes/compare-begin`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
  });
  return { status: res.status, body: await res.json() };
}

// ── (a) returns only compare-only steps, never inserts a run row ───────────

it('returns 200 with only the compare-only steps and inserts no run row', async () => {
  recipeRow = makeRecipe();
  stepsRows = [
    { id: 'sb', sequence: 1, name: 'Both', method: 'POST', step_runs_on: 'both' },
    { id: 'sc', sequence: 2, name: 'Fetch remote', method: 'GET', step_runs_on: 'compare' },
  ];
  templateRow = { owner_id: 'u1', blueprint_id: 'bp1', flow_external_id: 'EXT-1', flow_remote_refs: JSON.stringify({ a: 1 }) };

  const r = await post({ recipe_id: 'r1', payload: { a: 1 }, template_id: 'tpl1' });

  assert.equal(r.status, 200, JSON.stringify(r.body));
  assert.deepEqual(r.body.data.steps.map((s) => s.id), ['sc'],
    'only the compare-only step should be returned');
  assert.equal(r.body.data.steps[0].method, undefined, 'method must not leak into the response step shape');
  assert.equal(r.body.data.mode, 'compare');
  assert.equal(insertCount, 0, 'compare-begin must never insert a run row');
  assert.equal(typeof r.body.data.compare_token, 'string', 'compare-begin returns a compare token for the dispatch pass');
  assert.ok(r.body.data.compare_token.includes('.'), 'compare token is a signed <payload>.<hmac>');
});

// ── (b) a compare step whose method is not GET is refused ──────────────────

it('refuses a compare-only step whose method is not GET with 400 COMPARE_STEP_NOT_READONLY', async () => {
  recipeRow = makeRecipe();
  stepsRows = [
    { id: 'sc', sequence: 1, name: 'Push', method: 'POST', step_runs_on: 'compare' },
  ];
  templateRow = { owner_id: 'u1', blueprint_id: 'bp1' };

  const r = await post({ recipe_id: 'r1', payload: {}, template_id: 'tpl1' });

  assert.equal(r.status, 400);
  assert.equal(r.body.error.code, 'COMPARE_STEP_NOT_READONLY');
  assert.equal(insertCount, 0);
});

// ── (c) no access → 403 ─────────────────────────────────────────────────────

it('returns 403 TEMPLATE_FORBIDDEN when the caller has no access to the template', async () => {
  recipeRow = makeRecipe();
  stepsRows = [{ id: 'sc', sequence: 1, name: 'Fetch', method: 'GET', step_runs_on: 'compare' }];
  templateRow = { owner_id: 'someone-else', blueprint_id: 'bp1' };
  grantsTablePresent = false;

  const r = await post({ recipe_id: 'r1', payload: {}, template_id: 'tpl1' });

  assert.equal(r.status, 403);
  assert.equal(r.body.error.code, 'TEMPLATE_FORBIDDEN');
});

it('admin bypasses the ownership check', async () => {
  recipeRow = makeRecipe();
  stepsRows = [{ id: 'sc', sequence: 1, name: 'Fetch', method: 'GET', step_runs_on: 'compare' }];
  templateRow = { owner_id: 'someone-else', blueprint_id: 'bp1' };
  currentRole = 'admin';

  const r = await post({ recipe_id: 'r1', payload: {}, template_id: 'tpl1' });

  assert.equal(r.status, 200, JSON.stringify(r.body));
});

// ── (c2) blueprint parity: an owned template from a DIFFERENT blueprint ─────

it('refuses a template bound to a different blueprint than the recipe with 409 FLOW_BLUEPRINT_MISMATCH, even for the owner', async () => {
  recipeRow = makeRecipe(); // blueprint_id: 'bp1'
  stepsRows = [{ id: 'sc', sequence: 1, name: 'Fetch', method: 'GET', step_runs_on: 'compare' }];
  templateRow = { owner_id: 'u1', blueprint_id: 'bp2' };

  const r = await post({ recipe_id: 'r1', payload: {}, template_id: 'tpl1' });

  assert.equal(r.status, 409);
  assert.equal(r.body.error.code, 'FLOW_BLUEPRINT_MISMATCH');
  assert.equal(insertCount, 0);
});

it('refuses a blueprint mismatch even for an admin (mismatch is a correctness fault, not an access question)', async () => {
  recipeRow = makeRecipe();
  stepsRows = [{ id: 'sc', sequence: 1, name: 'Fetch', method: 'GET', step_runs_on: 'compare' }];
  templateRow = { owner_id: 'someone-else', blueprint_id: 'bp2' };
  currentRole = 'admin';

  const r = await post({ recipe_id: 'r1', payload: {}, template_id: 'tpl1' });

  assert.equal(r.status, 409);
  assert.equal(r.body.error.code, 'FLOW_BLUEPRINT_MISMATCH');
});

it('refuses a template with blueprint_id: null with 409 FLOW_BLUEPRINT_MISMATCH and the null-case reason (fail-closed, distinct wording)', async () => {
  recipeRow = makeRecipe(); // blueprint_id: 'bp1'
  stepsRows = [{ id: 'sc', sequence: 1, name: 'Fetch', method: 'GET', step_runs_on: 'compare' }];
  templateRow = { owner_id: 'u1', blueprint_id: null };

  const r = await post({ recipe_id: 'r1', payload: {}, template_id: 'tpl1' });

  assert.equal(r.status, 409);
  assert.equal(r.body.error.code, 'FLOW_BLUEPRINT_MISMATCH');
  assert.equal(r.body.error.message, 'Record has no blueprint; recipe is bound to one');
  assert.equal(insertCount, 0, 'no compare-begin write when the record has no blueprint');
});

it('refuses a template with blueprint_id: null with 409 FLOW_BLUEPRINT_MISMATCH and the null-case reason, even for an admin', async () => {
  recipeRow = makeRecipe(); // blueprint_id: 'bp1'
  stepsRows = [{ id: 'sc', sequence: 1, name: 'Fetch', method: 'GET', step_runs_on: 'compare' }];
  templateRow = { owner_id: 'someone-else', blueprint_id: null };
  currentRole = 'admin';

  const r = await post({ recipe_id: 'r1', payload: {}, template_id: 'tpl1' });

  assert.equal(r.status, 409, `expected 409 for a null-blueprint record, admin or not; got ${r.status}`);
  assert.equal(r.body.error.code, 'FLOW_BLUEPRINT_MISMATCH');
  assert.equal(r.body.error.message, 'Record has no blueprint; recipe is bound to one');
  assert.equal(insertCount, 0, 'no compare-begin write when the record has no blueprint, admin or not');
});

// ── (d) response carries compare_spec / stored_external_id / stored_remote_refs ─

it('response carries compare_spec, stored_external_id and stored_remote_refs', async () => {
  recipeRow = makeRecipe({ compare_spec: JSON.stringify({ localPath: '$.x', remotePath: '$.y' }) });
  stepsRows = [{ id: 'sc', sequence: 1, name: 'Fetch', method: 'GET', step_runs_on: 'compare' }];
  templateRow = {
    owner_id: 'u1', blueprint_id: 'bp1',
    flow_external_id: 'EXT-9', flow_remote_refs: JSON.stringify({ taskId: 't-1' }),
  };

  const r = await post({ recipe_id: 'r1', payload: {}, template_id: 'tpl1' });

  assert.equal(r.status, 200, JSON.stringify(r.body));
  assert.deepEqual(r.body.data.compare_spec, { localPath: '$.x', remotePath: '$.y' });
  assert.equal(r.body.data.stored_external_id, 'EXT-9');
  assert.deepEqual(r.body.data.stored_remote_refs, { taskId: 't-1' });
});

it('compare_spec is null when the recipe has none authored', async () => {
  recipeRow = makeRecipe({ compare_spec: null });
  stepsRows = [{ id: 'sc', sequence: 1, name: 'Fetch', method: 'GET', step_runs_on: 'compare' }];
  templateRow = { owner_id: 'u1', blueprint_id: 'bp1' };

  const r = await post({ recipe_id: 'r1', payload: {}, template_id: 'tpl1' });

  assert.equal(r.status, 200, JSON.stringify(r.body));
  assert.equal(r.body.data.compare_spec, null);
  assert.equal(r.body.data.stored_external_id, null);
  assert.equal(r.body.data.stored_remote_refs, null);
});

// ── (e) recipe-state gates still apply ──────────────────────────────────────

it('a not-yet-approved recipe is refused 422 RECIPE_NOT_APPROVED', async () => {
  recipeRow = makeRecipe({ status: 'pending' });
  templateRow = { owner_id: 'u1', blueprint_id: 'bp1' };

  const r = await post({ recipe_id: 'r1', payload: {}, template_id: 'tpl1' });

  assert.equal(r.status, 422);
  assert.equal(r.body.error.code, 'RECIPE_NOT_APPROVED');
});

it('an inactive recipe is refused 409 RECIPE_INACTIVE', async () => {
  recipeRow = makeRecipe({ is_active: 0 });
  templateRow = { owner_id: 'u1', blueprint_id: 'bp1' };

  const r = await post({ recipe_id: 'r1', payload: {}, template_id: 'tpl1' });

  assert.equal(r.status, 409);
  assert.equal(r.body.error.code, 'RECIPE_INACTIVE');
});

it('an unbound recipe is refused 422 RECIPE_UNBOUND', async () => {
  recipeRow = makeRecipe({ blueprint_id: null });
  templateRow = { owner_id: 'u1', blueprint_id: 'bp1' };

  const r = await post({ recipe_id: 'r1', payload: {}, template_id: 'tpl1' });

  assert.equal(r.status, 422);
  assert.equal(r.body.error.code, 'RECIPE_UNBOUND');
});

it('a recipe not found is refused 404', async () => {
  recipeRow = null;

  const r = await post({ recipe_id: 'missing', payload: {}, template_id: 'tpl1' });

  assert.equal(r.status, 404);
  assert.equal(r.body.error.code, 'RECIPE_NOT_FOUND');
});

// ── (f) template_id required ────────────────────────────────────────────────

it('requires template_id', async () => {
  recipeRow = makeRecipe();

  const r = await post({ recipe_id: 'r1', payload: {} });

  assert.equal(r.status, 400);
  assert.equal(r.body.error.code, 'BAD_REQUEST');
});

it('requires recipe_id', async () => {
  const r = await post({ payload: {}, template_id: 'tpl1' });

  assert.equal(r.status, 400);
  assert.equal(r.body.error.code, 'BAD_REQUEST');
});
