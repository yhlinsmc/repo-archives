/**
 * flow-recipes-run-step-select-schema-parity.test.js — validates the columns
 * the run-begin step SELECT (both the full and legacy-fallback variants)
 * references against the ACTUAL flow_recipe_steps table DDL, WITHOUT a live
 * DB. A wrong/renamed column stays green under every mocked node:test yet
 * 500s (or silently falls to the legacy variant) in production. PR-2
 * Task 4 added `name` to both SELECT variants — this test closes the gap
 * that change is exempt from the schema-migration gate (no DDL, existing
 * column) but is NOT exempt from a typo.
 */
const { describe, it, before } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

// flow-recipes-run.js destructures { pool, t } from ../../db at load time —
// stub it so requiring the source text (via readFileSync below we don't even
// require the module) is unnecessary; this file only parses the SQL text.
const { buildEngineTableDDLs } = require('../../../../src/table-ddls');

let columnsByTable;

before(() => {
  columnsByTable = new Map();
  for (const ddl of buildEngineTableDDLs((n) => n)) {
    const m = ddl.match(/CREATE TABLE IF NOT EXISTS `([^`]+)`/);
    if (!m) continue;
    const table = m[1];
    const cols = new Set();
    for (const rawLine of ddl.split('\n')) {
      const line = rawLine.trim();
      if (!line || line.startsWith('--') || line.startsWith('/*')) continue;
      const cm = line.match(/^`?([a-z_]+)`?\s+(?:CHAR|VARCHAR|INT|DOUBLE|TIMESTAMP|JSON|TEXT|ENUM|BOOLEAN|TINYINT|BIGINT|DATETIME|DECIMAL|FLOAT|BLOB)\b/i);
      if (cm) cols.add(cm[1]);
    }
    columnsByTable.set(table, cols);
  }
});

const SRC = fs.readFileSync(
  path.resolve(__dirname, '../../../../src/edge/routes/internal/flow-recipes-run.js'), 'utf8',
);

/**
 * Pull the four `SELECT <cols> FROM \`${t(TABLES.FLOW_RECIPE_STEPS)}\`` statements
 * that back the run-begin step load (identified by the anchoring comment —
 * flow_recipe_steps is also queried elsewhere in this file for an unrelated
 * code-only reload, which this helper must NOT pick up): widest (fmb-2090
 * PR-C1 — adds step_runs_on), full (fmb-2061 P1 — the pre-PR-C1 widest tier,
 * dialect columns without step_runs_on), midTier (step_type/before_code/
 * after_code without the dialect columns), legacy.
 */
function stepSelectColumnLists() {
  const anchor = SRC.indexOf('Load ordered steps.');
  assert.notEqual(anchor, -1, 'the run-begin step-load comment is gone or reworded');
  const window = SRC.slice(anchor, anchor + 1700);
  const re = /SELECT ([a-z_, ]+) FROM \\`\$\{t\(TABLES\.FLOW_RECIPE_STEPS\)\}\\`/g;
  const lists = [];
  let m;
  while ((m = re.exec(window))) {
    lists.push(m[1].split(',').map((c) => c.trim()).filter(Boolean));
  }
  return lists;
}

describe('flow-recipes-run.js run-begin step SELECT — schema parity', () => {
  it('finds the widest, full, midTier, and legacy-fallback SELECT variants', () => {
    const lists = stepSelectColumnLists();
    assert.equal(lists.length, 4, 'expected exactly 4 flow_recipe_steps SELECT statements (widest + full + midTier + legacy fallback)');
  });

  it('every selected column exists on flow_recipe_steps', () => {
    const cols = columnsByTable.get('flow_recipe_steps');
    assert.ok(cols && cols.size > 0, 'no columns parsed for flow_recipe_steps');
    for (const list of stepSelectColumnLists()) {
      for (const col of list) {
        assert.ok(cols.has(col), `flow_recipe_steps has no column '${col}' referenced by the run-begin SELECT`);
      }
    }
  });

  it('the widest variant selects step_runs_on (fmb-2090 PR-C1 — a later additive group than the dialect columns)', () => {
    const lists = stepSelectColumnLists();
    const widest = lists[0];
    assert.ok(widest && widest.includes('step_runs_on'), 'the widest SELECT must include `step_runs_on`');
    for (const col of ['content_type', 'yaml_version', 'yaml_quoting']) {
      assert.ok(widest.includes(col), `the widest SELECT must also include \`${col}\` (it is a superset of the full tier)`);
    }
  });

  it('the full variant carries the dialect columns but not step_runs_on (fmb-2061 P1 tier, degraded from the widest)', () => {
    const lists = stepSelectColumnLists();
    const full = lists[1];
    assert.ok(full, 'expected a full SELECT between the widest and midTier variants');
    for (const col of ['content_type', 'yaml_version', 'yaml_quoting']) {
      assert.ok(full.includes(col), `the full SELECT must include \`${col}\``);
    }
    assert.ok(!full.includes('step_runs_on'), 'the full SELECT must NOT include `step_runs_on` (that is the column group it degrades)');
  });

  it('the full and widest variants select name (fmb-1741 step_name enrichment)', () => {
    const lists = stepSelectColumnLists();
    assert.ok(lists.slice(0, 2).every((list) => list.includes('name')),
      'the widest and full SELECTs must include `name` so infra can record step_name in step_results');
  });

  it('the midTier variant carries step_type/before_code/after_code but none of the dialect columns (fmb-2061 P1)', () => {
    const lists = stepSelectColumnLists();
    const midTier = lists[2];
    assert.ok(midTier, 'expected a midTier SELECT between the full and legacy-fallback variants');
    for (const col of ['step_type', 'before_code', 'after_code']) {
      assert.ok(midTier.includes(col), `the midTier SELECT must include \`${col}\``);
    }
    for (const col of ['content_type', 'yaml_version', 'yaml_quoting', 'step_runs_on']) {
      assert.ok(!midTier.includes(col), `the midTier SELECT must NOT include \`${col}\` (that is the column group it degrades)`);
    }
  });

  it('the legacy-fallback variant also selects name (older schema still has this column since table creation)', () => {
    const lists = stepSelectColumnLists();
    assert.ok(lists[3] && lists[3].includes('name'),
      'the legacy-fallback SELECT must also include `name` — flow_recipe_steps.name is NOT NULL since table creation, not a later migration');
  });
});
