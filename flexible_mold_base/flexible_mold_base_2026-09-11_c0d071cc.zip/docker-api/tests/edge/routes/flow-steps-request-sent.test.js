// docker-api/tests/edge/routes/flow-steps-request-sent.test.js
//
// fmb-2045 (PR-U5): /prepare returns request_sent — the masked request the edge
// actually resolved and sent — as a sibling of the existing envelope/prepared
// shapes, so the Test/chain UI can render server truth instead of reconstructing
// the request on the client. Mirrors the mocking harness in
// tests/edge/routes/internal/flow-steps.test.js (isolated db via require.cache,
// a real express app + fetch, connector-dispatch.executeRequest patched to avoid
// a real socket).
const { test, beforeEach } = require('node:test');
const assert = require('node:assert');
const express = require('express');

// settings-crypto reads SETTINGS_ENCRYPTION_KEY per call; set it before the
// router (and the auth_config decrypt path it exercises) are first required.
process.env.SETTINGS_ENCRYPTION_KEY = 'unit-test-key-do-not-use-in-prod';

const fakeRows = { step: null, recipe: null, blueprint: null, run: null, template: null, nodes: null, owner: null, blueprintNode: null };
const conn = {
  query: async (sql) => {
    if (/FROM `flow_recipe_steps`/.test(sql)) return fakeRows.step ? [fakeRows.step] : [];
    if (/FROM `flow_recipe_runs`/.test(sql)) return fakeRows.run ? [fakeRows.run] : [];
    if (/FROM `flow_recipes`/.test(sql)) return fakeRows.recipe ? [fakeRows.recipe] : [];
    if (/FROM `user_templates`/.test(sql)) return fakeRows.template ? [fakeRows.template] : [];
    if (/FROM `hierarchy_nodes`/.test(sql)) {
      if (/SELECT id, name/.test(sql)) return fakeRows.nodes || [];
      if (/SELECT name FROM/.test(sql)) return fakeRows.blueprintNode ? [fakeRows.blueprintNode] : [];
      return fakeRows.blueprint ? [fakeRows.blueprint] : [];
    }
    if (/FROM `users`/.test(sql)) return fakeRows.owner ? [fakeRows.owner] : [];
    if (/INSERT INTO `feature_audit`/.test(sql)) return { affectedRows: 1 };
    return [];
  },
  release: () => {},
};
require.cache[require.resolve('../../../src/edge/db')] = {
  exports: {
    pool: { rw: { getConnection: async () => conn }, ro: { query: async () => [] } },
    t: (x) => x,
  },
};

const router = require('../../../src/edge/routes/internal/flow-steps');
const { encryptAuthConfig } = require('../../../src/edge/routes/app/flow-recipe-steps/serializer');

function appWith(user) {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { req.user = user; next(); });
  app.use('/edge/internal/flow-steps', router);
  return app;
}
async function post(app, path, body, user) {
  const server = app.listen(0);
  try {
    const port = server.address().port;
    const res = await fetch(`http://127.0.0.1:${port}${path}`, {
      method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body),
    });
    const json = await res.json();
    return { status: res.status, json };
  } finally {
    server.close();
  }
}

beforeEach(() => {
  fakeRows.step = null; fakeRows.recipe = null; fakeRows.blueprint = null;
  fakeRows.run = null; fakeRows.template = null; fakeRows.nodes = null; fakeRows.owner = null;
  fakeRows.blueprintNode = null;
});

test('edge-mode /prepare: data.envelope.request_sent carries the masked resolved request', async () => {
  const connDispatch = require('../../../src/edge/lib/connector-dispatch');
  const origExecute = connDispatch.executeRequest;
  connDispatch.executeRequest = async () => ({ upstream_status: 200, headers: {}, body: '{"ok":true}', duration_ms: 3 });
  try {
    // S-1 (fmb-2045 PR-U5 fix batch 1): a distinctive literal, unique to this
    // test in this file, so a whole-response JSON.stringify().includes()
    // check below cannot pass by accident on a substring some other fixture
    // also happens to contain.
    const REAL_SECRET = 'sk-REAL-EDGE-ROUTE-DISTINCT-7a1d';
    const encAuth = encryptAuthConfig({ token: REAL_SECRET }, 'bearer');
    fakeRows.step = {
      id: 's_edge_rs', recipe_id: 'r_edge_rs', name: 'edge-request-sent',
      method: 'POST', url: 'https://ok.test/edge-rs',
      auth_type: 'bearer',
      auth_config: JSON.stringify(encAuth),
      request_config: '{"body":"{{payload}}"}',
      response_config: '{}',
      input_from_step: null, timeout_ms: null,
      dispatch_origin: 'edge',
    };
    fakeRows.recipe = { is_active: 1, status: 'approved' };

    const { status, json } = await post(
      appWith({ id: 'u1', role: 'editor' }),
      '/edge/internal/flow-steps/prepare',
      { step_id: 's_edge_rs', inputs: { payload: 'hello' }, test: true },
    );

    assert.strictEqual(status, 200, `expected 200, got ${status}: ${JSON.stringify(json)}`);
    assert.strictEqual(json.data.mode, 'edge');
    const rs = json.data.envelope.request_sent;
    assert.ok(rs, 'envelope.request_sent must be present');
    assert.strictEqual(rs.method, 'POST');
    assert.strictEqual(rs.url, 'https://ok.test/edge-rs');
    assert.strictEqual(rs.headers.Authorization, '****', 'the real bearer token must never reach the browser');
    assert.strictEqual(rs.body, 'hello');
    // S-1: the whole HTTP response body — the object actually sent to the
    // browser, not just the field this test happens to name — must not carry
    // the real secret anywhere in it.
    assert.ok(!JSON.stringify(json).includes(REAL_SECRET),
      `the real secret leaked into the response sent to the browser: ${JSON.stringify(json)}`);
  } finally {
    connDispatch.executeRequest = origExecute;
  }
});

// A-1 (fmb-2045 PR-U5 fix batch 1): the URL itself must be masked too — a
// literal secret the connector author typed straight into the stored URL's
// own query string (never templated), so this exercises maskRequestSent's
// layer-2 parse-and-mask without depending on the dispatch-input renaming
// rules a templated var would go through.
test('edge-mode /prepare: data.envelope.request_sent.url masks a literal secret-named query param', async () => {
  const connDispatch = require('../../../src/edge/lib/connector-dispatch');
  const origExecute = connDispatch.executeRequest;
  connDispatch.executeRequest = async () => ({ upstream_status: 200, headers: {}, body: '{"ok":true}', duration_ms: 3 });
  try {
    fakeRows.step = {
      id: 's_edge_url', recipe_id: 'r_edge_url', name: 'edge-request-sent-url',
      method: 'GET', url: 'https://ok.test/edge-rs?api_key=LITERAL-ROUTE-SECRET',
      auth_type: 'none', auth_config: null,
      request_config: '{}', response_config: '{}',
      input_from_step: null, timeout_ms: null,
      dispatch_origin: 'edge',
    };
    fakeRows.recipe = { is_active: 1, status: 'approved' };

    const { status, json } = await post(
      appWith({ id: 'u1', role: 'editor' }),
      '/edge/internal/flow-steps/prepare',
      { step_id: 's_edge_url', inputs: {}, test: true },
    );

    assert.strictEqual(status, 200, `expected 200, got ${status}: ${JSON.stringify(json)}`);
    const rs = json.data.envelope.request_sent;
    assert.ok(!rs.url.includes('LITERAL-ROUTE-SECRET'), `url leaked the literal secret: ${rs.url}`);
  } finally {
    connDispatch.executeRequest = origExecute;
  }
});

// resolveAndPin is not stubbed — an RFC1918 IP literal resolves synchronously
// without DNS (matches the existing infra-mode multipart test in
// tests/edge/routes/internal/flow-steps.test.js).
test('infra-mode /prepare: data.request_sent (masked) sits beside data.prepared (real secret, S2S-only)', async () => {
  // S-1 (fmb-2045 PR-U5 fix batch 1): distinctive literal, unique to this
  // test. NOTE this /prepare response as a WHOLE is the S2S-only channel to
  // infra (data.prepared.headers legitimately carries the real secret here
  // by design) — it is NOT "the object sent to the browser". The
  // browser-bound part is data.request_sent alone; that field, not the whole
  // response, is what the whole-value assertion below checks.
  const REAL_SECRET = 'sk-REAL-INFRA-ROUTE-DISTINCT-3e9b';
  const encAuth = encryptAuthConfig({ token: REAL_SECRET }, 'bearer');
  fakeRows.step = {
    id: 's_infra_rs', recipe_id: 'r_infra_rs', name: 'infra-request-sent',
    method: 'POST', url: 'https://192.168.1.100/api',
    auth_type: 'bearer',
    auth_config: JSON.stringify(encAuth),
    request_config: '{"body":"{{payload}}"}',
    response_config: '{}',
    input_from_step: null, timeout_ms: null,
    dispatch_origin: 'infra',
  };
  fakeRows.recipe = { is_active: 1, status: 'approved', owner_id: 'editor1', blueprint_id: null };

  const { status, json } = await post(
    appWith({ id: 'editor1', role: 'editor' }),
    '/edge/internal/flow-steps/prepare',
    { step_id: 's_infra_rs', inputs: { payload: 'hello' }, test: true },
  );

  assert.strictEqual(status, 200, `expected 200, got ${status}: ${JSON.stringify(json)}`);
  assert.strictEqual(json.data.mode, 'infra');
  // data.request_sent is a SIBLING of data.prepared — not nested inside it.
  assert.ok(json.data.request_sent, 'data.request_sent must be present');
  assert.strictEqual(json.data.request_sent.headers.Authorization, '****');
  assert.strictEqual(json.data.request_sent.body, 'hello');
  // data.prepared.headers still carries the REAL secret (S2S-only channel to infra).
  assert.strictEqual(json.data.prepared.headers.Authorization, `Bearer ${REAL_SECRET}`);
  assert.notStrictEqual(json.data.prepared.headers.Authorization, json.data.request_sent.headers.Authorization);
  // S-1: the whole browser-bound field — not just the header this test
  // happens to name — must not carry the real secret anywhere in it.
  assert.ok(!JSON.stringify(json.data.request_sent).includes(REAL_SECRET),
    `the real secret leaked into data.request_sent: ${JSON.stringify(json.data.request_sent)}`);
});

// A-1 (fmb-2045 PR-U5 fix batch 1): infra mode's data.request_sent.url must be
// masked too — data.prepared.url (S2S-only) keeps the real value.
test('infra-mode /prepare: data.request_sent.url masks a templated secret input; data.prepared.url keeps the real value', async () => {
  fakeRows.step = {
    id: 's_infra_url', recipe_id: 'r_infra_url', name: 'infra-request-sent-url',
    method: 'GET', url: 'https://192.168.1.100/api?access_token={{payload.access_token}}',
    auth_type: 'none', auth_config: null,
    request_config: '{}', response_config: '{}',
    input_from_step: null, timeout_ms: null,
    dispatch_origin: 'infra',
  };
  fakeRows.recipe = { is_active: 1, status: 'approved', owner_id: 'editor1', blueprint_id: null };

  const { status, json } = await post(
    appWith({ id: 'editor1', role: 'editor' }),
    '/edge/internal/flow-steps/prepare',
    { step_id: 's_infra_url', inputs: { access_token: 'sk-REAL-QS' }, test: true },
  );

  assert.strictEqual(status, 200, `expected 200, got ${status}: ${JSON.stringify(json)}`);
  assert.ok(!json.data.request_sent.url.includes('sk-REAL-QS'), `request_sent.url leaked the secret: ${json.data.request_sent.url}`);
  assert.ok(json.data.prepared.url.includes('sk-REAL-QS'), 'prepared.url (S2S-only, real secret) must still carry the real value');
});

// C-1 (Codex round 1, P1): request_sent is a Test/chain-only field — a
// production (non-test) dispatch must not carry the key at all.
test('edge-mode /prepare: a production dispatch (no test flag) has no request_sent key at all', async () => {
  const connDispatch = require('../../../src/edge/lib/connector-dispatch');
  const origExecute = connDispatch.executeRequest;
  connDispatch.executeRequest = async () => ({ upstream_status: 200, headers: {}, body: '{"ok":true}', duration_ms: 3 });
  try {
    fakeRows.step = {
      id: 's_edge_prod', recipe_id: 'r_edge_prod', name: 'edge-production',
      method: 'GET', url: 'https://ok.test/edge-prod',
      auth_type: 'none', auth_config: null,
      request_config: '{}', response_config: '{}',
      input_from_step: null, timeout_ms: null,
      dispatch_origin: 'edge',
    };
    fakeRows.recipe = { is_active: 1, status: 'approved' };

    const { status, json } = await post(
      appWith({ id: 'u1', role: 'editor' }),
      '/edge/internal/flow-steps/prepare',
      { step_id: 's_edge_prod', inputs: {} },
    );

    assert.strictEqual(status, 200, `expected 200, got ${status}: ${JSON.stringify(json)}`);
    assert.strictEqual(json.data.test, false);
    assert.ok(!('request_sent' in json.data.envelope), `production envelope must not carry request_sent at all: ${JSON.stringify(json.data.envelope)}`);
  } finally {
    connDispatch.executeRequest = origExecute;
  }
});

test('infra-mode /prepare: a production dispatch (no test flag) has no request_sent key at all', async () => {
  fakeRows.step = {
    id: 's_infra_prod', recipe_id: 'r_infra_prod', name: 'infra-production',
    method: 'GET', url: 'https://192.168.1.100/api',
    auth_type: 'none', auth_config: null,
    request_config: '{}', response_config: '{}',
    input_from_step: null, timeout_ms: null,
    dispatch_origin: 'infra',
  };
  fakeRows.recipe = { is_active: 1, status: 'approved', owner_id: 'editor1', blueprint_id: null };

  const { status, json } = await post(
    appWith({ id: 'editor1', role: 'editor' }),
    '/edge/internal/flow-steps/prepare',
    { step_id: 's_infra_prod', inputs: {} },
  );

  assert.strictEqual(status, 200, `expected 200, got ${status}: ${JSON.stringify(json)}`);
  assert.strictEqual(json.data.test, false);
  assert.ok(!('request_sent' in json.data), `production infra-mode response must not carry request_sent at all: ${JSON.stringify(json.data)}`);
});

// C-2 (Codex round 1, P1) end-to-end: api_key auth configured under a
// non-secret-shaped header name must not leak through the full /prepare path.
test('edge-mode /prepare: api_key auth with a configured non-secret-shaped header name is masked end-to-end (C-2)', async () => {
  const connDispatch = require('../../../src/edge/lib/connector-dispatch');
  const origExecute = connDispatch.executeRequest;
  connDispatch.executeRequest = async () => ({ upstream_status: 200, headers: {}, body: '{"ok":true}', duration_ms: 3 });
  try {
    const REAL_SECRET = 'sk-REAL-APIKEY-ROUTE-DISTINCT-c2f1';
    const encAuth = encryptAuthConfig({ header: 'X-Subscription', value: REAL_SECRET }, 'api_key');
    fakeRows.step = {
      id: 's_edge_apikey', recipe_id: 'r_edge_apikey', name: 'edge-apikey',
      method: 'GET', url: 'https://ok.test/edge-apikey',
      auth_type: 'api_key',
      auth_config: JSON.stringify(encAuth),
      request_config: '{}', response_config: '{}',
      input_from_step: null, timeout_ms: null,
      dispatch_origin: 'edge',
    };
    fakeRows.recipe = { is_active: 1, status: 'approved' };

    const { status, json } = await post(
      appWith({ id: 'u1', role: 'editor' }),
      '/edge/internal/flow-steps/prepare',
      { step_id: 's_edge_apikey', inputs: {}, test: true },
    );

    assert.strictEqual(status, 200, `expected 200, got ${status}: ${JSON.stringify(json)}`);
    const rs = json.data.envelope.request_sent;
    assert.strictEqual(rs.headers['X-Subscription'], '****', 'a configured non-secret-shaped header name must still be masked');
    assert.ok(!JSON.stringify(json).includes(REAL_SECRET),
      `the real api_key leaked into the response sent to the browser: ${JSON.stringify(json)}`);
  } finally {
    connDispatch.executeRequest = origExecute;
  }
});
