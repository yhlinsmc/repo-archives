/**
 * user-template-row-limit-schema-parity.test.js — the row-limit SELECTs
 * against `table-ddls.js`, the single schema truth, with no live DB.
 */
const { describe, it, before } = require('node:test');
const assert = require('node:assert/strict');

const dbKey = require.resolve('../../../../src/edge/db');
require.cache[dbKey] = { id: dbKey, filename: dbKey, loaded: true, exports: { pool: {}, t: (n) => n } };

const { buildEngineTableDDLs } = require('../../../../src/table-ddls');
const SQL_TYPES = /^`?([a-z_]+)`?\s+(?:CHAR|VARCHAR|INT|DOUBLE|TIMESTAMP|JSON|TEXT|ENUM|BOOLEAN|TINYINT|BIGINT|DATETIME|DECIMAL|FLOAT|BLOB)\b/i;
let columnsByTable;
before(() => {
  columnsByTable = new Map();
  for (const ddl of buildEngineTableDDLs((n) => n)) {
    const m = ddl.match(/CREATE TABLE IF NOT EXISTS `([^`]+)`/);
    if (!m) continue;
    const cols = new Set();
    for (const raw of ddl.split('\n')) {
      const line = raw.trim();
      if (!line || line.startsWith('--')) continue;
      const cm = line.match(SQL_TYPES);
      if (cm) cols.add(cm[1]);
    }
    columnsByTable.set(m[1], cols);
  }
});

describe('user_templates row-limit SELECT — schema parity', () => {
  it('blueprint_fields carries the columns the row-limit query reads', () => {
    const cols = columnsByTable.get('blueprint_fields');
    assert.ok(cols, 'blueprint_fields table not found in table-ddls.js');
    for (const c of ['blueprint_id', 'field_type', 'field_key', 'field_label']) {
      assert.ok(cols.has(c), `blueprint_fields has no column '${c}'`);
    }
  });

  it('user_templates carries the columns the blueprint fallback reads', () => {
    const cols = columnsByTable.get('user_templates');
    assert.ok(cols, 'user_templates table not found in table-ddls.js');
    for (const c of ['id', 'blueprint_id', 'payload']) {
      assert.ok(cols.has(c), `user_templates has no column '${c}'`);
    }
  });
});
