'use strict';

/**
 * template-versions.test.js — access control, the merged timeline, the
 * whitelist PUT, the restore freshness guard, save-as, and the
 * flow-projected-id read-only refusals (fmb-1912 PR-1).
 */
const {
  describe, it, before, after, beforeEach,
} = require('node:test');
const assert = require('node:assert/strict');
const { makeStubReqLog } = require('../../../helpers/stub-req-log');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../../../src/edge/db');

let state;
function freshState() {
  return {
    queries: [],
    committed: false,
    rolledBack: false,
    templateRow: {
      id: TEMPLATE, owner_id: OWNER.id, blueprint_id: 'bp-1', variant_id: null, category_id: 'cat-1', release_id: 'rel-1', schema_version: '1.0', updated_at: '2026-01-01 00:00:00',
      // F8 — the columns the restore guard's content fingerprint is hashed
      // over. A fixed object shared by save-stamp and restore-check within
      // one test, so the fingerprint matches unless a test deliberately
      // mutates one of these fields between the two.
      payload: '{"a":"1"}', generated_outputs: '{}', field_option_selection: null, computed_field_overrides: null, cleared_auto_fills: null,
    },
    grantRows: [],
    grantsTablePresent: true,
    versionsTablePresent: true,
    manualListRows: [],
    manualRow: undefined, // the single-row `WHERE id = ? AND template_id = ?` read; undefined ⇒ not found
    flowListRows: [],
    flowRow: undefined,
    // attachActorNames' users lookup — bounded to the actor_id set already on
    // the rows it enriches (owner-name-enrichment.js's own contract).
    userRows: [],
    flowSnapshotColumnsMissing: false,
    savedVersionRow: undefined,
    insertAffected: 1,
    updateAffected: 1,
    forUpdateExisting: [{ id: 'placeholder' }],
    // Mid-transaction-throw injection: when set, the NEXT query whose SQL
    // matches this pattern throws instead of returning — simulating a DB
    // fault landing between two writes of the SAME transaction, so a route's
    // rollback (not merely its happy path) gets exercised.
    throwOnSql: null,
  };
}

function makeConn() {
  return {
    async beginTransaction() {},
    async commit() { state.committed = true; },
    async rollback() { state.rolledBack = true; },
    release() {},
    async query(sql, params = []) {
      state.queries.push({ sql, params });
      if (state.throwOnSql && state.throwOnSql.test(sql)) {
        throw new Error('injected mid-transaction failure');
      }

      if (/information_schema\.TABLES/i.test(sql)) {
        const [name] = params;
        if (String(name).endsWith('delegated_grants')) return state.grantsTablePresent ? [{ 1: 1 }] : [];
        if (String(name).endsWith('template_versions')) return state.versionsTablePresent ? [{ 1: 1 }] : [];
        return [];
      }
      if (/FROM `fmb_hierarchy_nodes`/.test(sql)) return [];
      if (/FROM `fmb_delegated_grants`/.test(sql)) return state.grantRows;

      // user_templates reads — three distinct column lists, same table.
      if (/FROM `fmb_user_templates` WHERE id = \?/.test(sql)) {
        return state.templateRow ? [state.templateRow] : [];
      }

      // attachActorNames' bounded users lookup (owner-name-enrichment.js).
      if (sql.includes('SELECT id, display_name, kc_username')) return state.userRows;

      // Saved-version-id freshness probe (restore).
      if (/^SELECT id, snapshot FROM `fmb_template_versions` WHERE id = \? AND template_id = \?/.test(sql)) {
        return state.savedVersionRow !== undefined ? state.savedVersionRow : [];
      }
      // The FOR UPDATE existence probe (PUT/DELETE).
      if (/^SELECT id FROM `fmb_template_versions` WHERE id = \? AND template_id = \? FOR UPDATE/.test(sql)) {
        return state.forUpdateExisting;
      }
      // Single full-row read (GET one / restore / save-as).
      if (/^SELECT [\s\S]*snapshot[\s\S]* FROM `fmb_template_versions` WHERE id = \? AND template_id = \?/.test(sql)) {
        return state.manualRow ? [state.manualRow] : [];
      }
      // Re-read after INSERT/UPDATE (list-shaped columns, no snapshot, WHERE id = ? alone).
      if (/^SELECT [\s\S]*FROM `fmb_template_versions` WHERE id = \?\s*$/.test(sql)) {
        return state.manualRow ? [state.manualRow] : [];
      }
      // List read.
      if (/^SELECT [\s\S]*FROM `fmb_template_versions`\s+WHERE template_id = \?/.test(sql)) {
        return state.manualListRows;
      }

      // flow_recipe_runs — single row, extended (incl input_snapshot +
      // output_snapshot) vs the degraded fallback set, vs the list.
      if (/^SELECT id, template_id, blueprint_id, actor_id, status, created_at, input_snapshot, output_snapshot\s+FROM `fmb_flow_recipe_runs` WHERE id = \? AND template_id = \?/.test(sql)) {
        if (state.flowSnapshotColumnsMissing) {
          const err = new Error('Unknown column \'output_snapshot\' in \'field list\'');
          err.code = 'ER_BAD_FIELD_ERROR';
          err.errno = 1054;
          throw err;
        }
        return state.flowRow ? [state.flowRow] : [];
      }
      if (/^SELECT id, template_id, blueprint_id, actor_id, status, created_at\s+FROM `fmb_flow_recipe_runs` WHERE id = \? AND template_id = \?/.test(sql)) {
        return state.flowRow ? [state.flowRow] : [];
      }
      if (/^SELECT [\s\S]*FROM `fmb_flow_recipe_runs` WHERE template_id = \?/.test(sql)) {
        return state.flowListRows;
      }

      if (/^INSERT INTO `fmb_template_versions`/.test(sql)) return { affectedRows: state.insertAffected };
      if (/^INSERT INTO `fmb_user_templates`/.test(sql)) return { affectedRows: state.insertAffected };
      if (/^INSERT INTO `fmb_feature_audit`/.test(sql)) return { affectedRows: 1 };
      if (/^UPDATE `fmb_template_versions`/.test(sql)) return { affectedRows: state.updateAffected };
      if (/^UPDATE `fmb_user_templates`/.test(sql)) return { affectedRows: state.updateAffected };
      if (/^DELETE FROM `fmb_template_versions`/.test(sql)) return { affectedRows: 1 };

      return [];
    },
  };
}

const poolFacade = { async getConnection() { return makeConn(); } };

require.cache[dbKey] = {
  id: dbKey,
  filename: dbKey,
  loaded: true,
  exports: {
    pool: { ro: poolFacade, rw: poolFacade },
    t: (n) => `fmb_${n}`,
    getDynamicPool: async () => ({ ro: poolFacade, rw: poolFacade }),
  },
};

const router = require('../../../../src/edge/routes/app/template-versions');
const { _resetGrantsTableCache } = require('../../../../src/edge/lib/delegated-grants');
const { templateStateFingerprint } = require('../../../../src/edge/lib/template-version-restorable');

const OWNER = { id: '11111111-1111-1111-1111-111111111111', role: 'user' };
const STRANGER = { id: '33333333-3333-3333-3333-333333333333', role: 'user' };
const ADMIN = { id: '44444444-4444-4444-4444-444444444444', role: 'admin' };
const TEMPLATE = 'bbbbbbbb-0000-0000-0000-00000000000b';
const VERSION = 'cccccccc-0000-0000-0000-00000000000c';
const RUN_ID = 'dddddddd-0000-0000-0000-00000000000d';

let currentUser;
let server;
let baseUrl;

before(async () => {
  const app = express();
  app.use((req, _res, next) => { req.log = makeStubReqLog(); next(); }); // TEST-ONLY: production always sets req.log via createRequestId (request-id.js) before any router; this bare app has no such middleware, so a route's req.log.<level>() call would otherwise throw against undefined.
  app.use(express.json({ limit: '10mb' }));
  app.use((req, _res, next) => { if (currentUser) req.user = currentUser; next(); });
  app.use('/edge/app/templates', router);
  server = http.createServer(app);
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});

after(async () => { await new Promise((r) => server.close(r)); });

beforeEach(() => {
  state = freshState();
  currentUser = OWNER;
  _resetGrantsTableCache();
});

async function call(method, path, body) {
  const res = await fetch(`${baseUrl}/edge/app/templates${path}`, {
    method,
    headers: { 'content-type': 'application/json' },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const json = await res.json().catch(() => ({}));
  return { status: res.status, json };
}

const validDoc = { doc_version: 2, entered: { a: '1' }, computed: {}, outputs: {}, fields: {}, optionMeta: {} };

function manualRow(overrides = {}) {
  return {
    id: VERSION,
    template_id: TEMPLATE,
    name: 'Baseline',
    note: null,
    kind: 'manual',
    flow_run_id: null,
    blueprint_id: 'bp-1',
    variant_id: null,
    actor_id: OWNER.id,
    created_at: '2026-02-01 00:00:00',
    snapshot: JSON.stringify(validDoc),
    ...overrides,
  };
}

function flowRunRow(overrides = {}) {
  return {
    id: RUN_ID,
    template_id: TEMPLATE,
    blueprint_id: 'bp-1',
    actor_id: OWNER.id,
    status: 'success',
    created_at: '2026-01-15 00:00:00',
    // No `outputs` key here on purpose — a flow run's generated results were
    // never written into input_snapshot, only into the sibling
    // output_snapshot column below. Any test asserting outputs === { out1:
    // 'flow-out' } only passes if the route actually reads that column.
    input_snapshot: JSON.stringify({ entered: { a: '1' }, computed: {} }),
    output_snapshot: JSON.stringify({ out1: 'flow-out' }),
    ...overrides,
  };
}

// ── Access control (mirrors template-snapshots.js's own coverage) ──────────

describe('who may read and write a record\'s versions', () => {
  it('its owner may list', async () => {
    const res = await call('GET', `/${TEMPLATE}/versions`);
    assert.equal(res.status, 200);
  });

  it('an administrator may list', async () => {
    currentUser = ADMIN;
    const res = await call('GET', `/${TEMPLATE}/versions`);
    assert.equal(res.status, 200);
  });

  it('everyone else is answered as though the record were not there', async () => {
    currentUser = STRANGER;
    const res = await call('GET', `/${TEMPLATE}/versions`);
    assert.equal(res.status, 404);
  });

  it('a record that does not exist is the same answer', async () => {
    state.templateRow = null;
    const res = await call('GET', `/${TEMPLATE}/versions`);
    assert.equal(res.status, 404);
  });

  it('an anonymous caller reaches no statement at all', async () => {
    currentUser = null;
    const res = await call('GET', `/${TEMPLATE}/versions`);
    assert.equal(res.status, 401);
    assert.equal(state.queries.length, 0);
  });

  it('a stranger may not save a version', async () => {
    currentUser = STRANGER;
    const res = await call('POST', `/${TEMPLATE}/versions`, { name: 'x', snapshot: validDoc });
    assert.equal(res.status, 404);
    assert.equal(state.queries.filter((q) => /^INSERT/.test(q.sql)).length, 0);
  });
});

// ── GET / — the merged timeline ─────────────────────────────────────────────

describe('GET / — merged manual + flow timeline', () => {
  it('merges manual and flow rows newest-first with kind badges', async () => {
    state.manualListRows = [manualRow({ created_at: '2026-02-01 00:00:00' })];
    state.flowListRows = [flowRunRow({ created_at: '2026-01-15 00:00:00' })];
    const res = await call('GET', `/${TEMPLATE}/versions`);
    assert.equal(res.status, 200);
    const items = res.json.data.items;
    assert.equal(items.length, 2);
    assert.equal(items[0].kind, 'manual');
    assert.equal(items[0].id, VERSION);
    assert.equal(items[1].kind, 'flow');
    assert.equal(items[1].id, `run:${RUN_ID}`);
    assert.equal(items[1].flow_run_id, RUN_ID);
    // No snapshot body in the list.
    assert.equal(items[0].snapshot, undefined);
    assert.equal(items[1].snapshot, undefined);
  });

  it('resolves actor_name for both sources from ONE bounded users lookup (fmb-1934 PR-6)', async () => {
    state.manualListRows = [manualRow({ created_at: '2026-02-01 00:00:00', actor_id: OWNER.id })];
    state.flowListRows = [flowRunRow({ created_at: '2026-01-15 00:00:00', actor_id: OWNER.id })];
    state.userRows = [{ id: OWNER.id, display_name: 'Ada', kc_username: 'ada' }];
    const res = await call('GET', `/${TEMPLATE}/versions`);
    assert.equal(res.status, 200);
    const usersQueries = state.queries.filter((q) => q.sql.includes('SELECT id, display_name, kc_username'));
    assert.equal(usersQueries.length, 1, 'one actor_id set shared by both sources → one lookup, not two');
    const items = res.json.data.items;
    assert.equal(items[0].actor_name, 'Ada');
    assert.equal(items[1].actor_name, 'Ada');
  });

  it('an actor_id with no matching users row resolves to "Unknown", never a raw id or empty string', async () => {
    state.manualListRows = [manualRow({ actor_id: '99999999-0000-0000-0000-000000000009' })];
    state.userRows = [];
    const res = await call('GET', `/${TEMPLATE}/versions`);
    assert.equal(res.status, 200);
    assert.equal(res.json.data.items[0].actor_name, 'Unknown');
  });

  it('reports unavailable only when the manual table is absent, and still lists flow rows', async () => {
    state.versionsTablePresent = false;
    state.flowListRows = [flowRunRow()];
    const res = await call('GET', `/${TEMPLATE}/versions`);
    assert.equal(res.status, 200);
    assert.equal(res.json.data.unavailable, true);
    assert.equal(res.json.data.items.length, 1);
    assert.equal(res.json.data.items[0].kind, 'flow');
  });

  it('a present table answers unavailable: false with an empty list when nothing was saved', async () => {
    const res = await call('GET', `/${TEMPLATE}/versions`);
    assert.equal(res.status, 200);
    assert.equal(res.json.data.unavailable, false);
    assert.deepEqual(res.json.data.items, []);
  });

  it('breaks a same-second created_at tie on id DESC, deterministically, regardless of array position', async () => {
    const tie = '2026-02-01 00:00:00';
    state.manualListRows = [manualRow({ id: 'aaaaaaaa-0000-0000-0000-00000000000a', created_at: tie })];
    state.flowListRows = [flowRunRow({ id: 'zzzzzzzz-0000-0000-0000-00000000000z', created_at: tie })];
    const res = await call('GET', `/${TEMPLATE}/versions`);
    assert.equal(res.status, 200);
    const ids = res.json.data.items.map((i) => i.id);
    // 'run:zzzzzzzz...' > 'aaaaaaaa...' by string compare, so it sorts first
    // under id DESC even though manualItems is concatenated before flowItems
    // in the merge array — proof the comparator, not array position, decides.
    assert.deepEqual(ids, [`run:zzzzzzzz-0000-0000-0000-00000000000z`, 'aaaaaaaa-0000-0000-0000-00000000000a']);
  });
});

// ── POST / — save a manual version ──────────────────────────────────────────

describe('POST / — save a manual version', () => {
  it('refuses a document whose doc_version is not 2', async () => {
    const res = await call('POST', `/${TEMPLATE}/versions`, { name: 'x', snapshot: { ...validDoc, doc_version: 1 } });
    assert.equal(res.status, 400);
    assert.equal(state.queries.filter((q) => /^INSERT/.test(q.sql)).length, 0);
  });

  it('refuses a document with no doc_version at all', async () => {
    const { doc_version: _dv, ...noVersion } = validDoc;
    const res = await call('POST', `/${TEMPLATE}/versions`, { name: 'x', snapshot: noVersion });
    assert.equal(res.status, 400);
  });

  it('requires a name', async () => {
    const res = await call('POST', `/${TEMPLATE}/versions`, { snapshot: validDoc });
    assert.equal(res.status, 400);
  });

  it('refuses an oversized document', async () => {
    const huge = { ...validDoc, entered: { blob: 'x'.repeat(3 * 1024 * 1024) } };
    const res = await call('POST', `/${TEMPLATE}/versions`, { name: 'x', snapshot: huge });
    assert.equal(res.status, 400);
  });

  it('stamps kind=manual and the actor from the session, never from the body', async () => {
    state.manualRow = manualRow();
    const res = await call('POST', `/${TEMPLATE}/versions`, {
      name: 'Baseline', snapshot: validDoc, actor_id: 'somebody-else',
    });
    assert.equal(res.status, 201, JSON.stringify(res.json));
    assert.equal(res.json.data.kind, 'manual');
    const insert = state.queries.find((q) => /^INSERT INTO `fmb_template_versions`/.test(q.sql));
    assert.match(insert.sql, /'manual', NULL/);
    const actorId = insert.params[insert.params.length - 1];
    assert.equal(actorId, OWNER.id, 'the actor was read from the session, not the body');
  });

  it('never writes flow_recipe_runs', async () => {
    state.manualRow = manualRow();
    await call('POST', `/${TEMPLATE}/versions`, { name: 'x', snapshot: validDoc });
    assert.equal(state.queries.filter((q) => /flow_recipe_runs/i.test(q.sql)).length, 0);
  });

  it('503s with a clear code when the versions table is absent, never a 500', async () => {
    state.versionsTablePresent = false;
    const res = await call('POST', `/${TEMPLATE}/versions`, { name: 'x', snapshot: validDoc });
    assert.equal(res.status, 503);
    assert.equal(res.json.error.code, 'VERSIONS_UNAVAILABLE');
    assert.equal(state.queries.filter((q) => /^INSERT/.test(q.sql)).length, 0);
  });

  // F10 (P2) — a document with no restorable `entered` bucket must not be
  // savable: it would 201 today and then 409 forever on every later
  // restore/save-as attempt, with no way to fix it up.
  it('refuses a doc_version 2 document with no entered map at all — never 201s a snapshot restore/save-as can never read', async () => {
    const res = await call('POST', `/${TEMPLATE}/versions`, { name: 'x', snapshot: { doc_version: 2 } });
    assert.equal(res.status, 400, JSON.stringify(res.json));
    assert.equal(res.json.error.code, 'SNAPSHOT_NOT_RESTORABLE');
    assert.equal(state.queries.filter((q) => /^INSERT/.test(q.sql)).length, 0);
  });

  it('accepts a document whose entered map is present but empty ({}) — extractRestorable treats empty as restorable', async () => {
    state.manualRow = manualRow();
    const res = await call('POST', `/${TEMPLATE}/versions`, {
      name: 'x', snapshot: { doc_version: 2, entered: {} },
    });
    assert.equal(res.status, 201, JSON.stringify(res.json));
    assert.equal(state.queries.filter((q) => /^INSERT INTO `fmb_template_versions`/.test(q.sql)).length, 1);
  });

  // S3 (fmb-1912 PR-4 residual, card fmb-1914 deferred): blueprint_id/
  // variant_id shape validation, mirroring the sibling idiom
  // `routes-hidden-field-disclosure.js` already uses for the same two
  // optional-but-if-present UUID fields.
  it('refuses a non-UUID blueprint_id with 400, never an INSERT', async () => {
    const res = await call('POST', `/${TEMPLATE}/versions`, {
      name: 'x', snapshot: validDoc, blueprint_id: 'not-a-uuid',
    });
    assert.equal(res.status, 400, JSON.stringify(res.json));
    assert.equal(state.queries.filter((q) => /^INSERT/.test(q.sql)).length, 0);
  });

  it('refuses a non-UUID variant_id with 400, never an INSERT', async () => {
    const res = await call('POST', `/${TEMPLATE}/versions`, {
      name: 'x', snapshot: validDoc, variant_id: 'not-a-uuid',
    });
    assert.equal(res.status, 400, JSON.stringify(res.json));
    assert.equal(state.queries.filter((q) => /^INSERT/.test(q.sql)).length, 0);
  });
});

// ── GET /:versionId — one version in full ───────────────────────────────────

describe('GET /:versionId', () => {
  it('reads a manual version including its parsed snapshot', async () => {
    state.manualRow = manualRow();
    state.userRows = [{ id: OWNER.id, display_name: 'Ada', kc_username: 'ada' }];
    const res = await call('GET', `/${TEMPLATE}/versions/${VERSION}`);
    assert.equal(res.status, 200);
    assert.equal(res.json.data.kind, 'manual');
    assert.deepEqual(res.json.data.snapshot, validDoc);
    assert.equal(res.json.data.actor_name, 'Ada');
  });

  it('reads a flow-projected version off flow_recipe_runs', async () => {
    state.flowRow = flowRunRow();
    state.userRows = [{ id: OWNER.id, display_name: 'Ada', kc_username: 'ada' }];
    const res = await call('GET', `/${TEMPLATE}/versions/run:${RUN_ID}`);
    assert.equal(res.status, 200);
    assert.equal(res.json.data.kind, 'flow');
    assert.equal(res.json.data.id, `run:${RUN_ID}`);
    assert.equal(res.json.data.status, 'success');
    assert.equal(res.json.data.actor_name, 'Ada');
  });

  // F6 (P1) — a flow run's generated outputs live in output_snapshot, a
  // sibling column to input_snapshot; the full GET must merge them in.
  it('a flow version\'s full GET carries outputs from output_snapshot, not just input_snapshot', async () => {
    state.flowRow = flowRunRow();
    const res = await call('GET', `/${TEMPLATE}/versions/run:${RUN_ID}`);
    assert.equal(res.status, 200, JSON.stringify(res.json));
    assert.deepEqual(res.json.data.snapshot.outputs, { out1: 'flow-out' });
  });

  it('a malformed version id is 404, not 500', async () => {
    const res = await call('GET', `/${TEMPLATE}/versions/not-a-real-id`);
    assert.equal(res.status, 404);
  });

  it('a run-prefixed id whose suffix is not a UUID is 404', async () => {
    const res = await call('GET', `/${TEMPLATE}/versions/run:not-a-uuid`);
    assert.equal(res.status, 404);
  });
});

// ── PUT /:versionId — two-field whitelist, manual rows only ────────────────

describe('PUT /:versionId', () => {
  it('renames a manual version', async () => {
    state.manualRow = manualRow({ name: 'Renamed' });
    const res = await call('PUT', `/${TEMPLATE}/versions/${VERSION}`, { name: 'Renamed' });
    assert.equal(res.status, 200, JSON.stringify(res.json));
    const update = state.queries.find((q) => /^UPDATE `fmb_template_versions`/.test(q.sql));
    assert.match(update.sql, /name = \?/);
    // S3 (fmb-1912 PR-4 residual): the FOR UPDATE read + UPDATE now run
    // inside an explicit transaction — a successful rename must commit it.
    assert.equal(state.committed, true);
    assert.equal(state.rolledBack, false);
  });

  it('refuses any key besides name/note with 400', async () => {
    state.manualRow = manualRow();
    const res = await call('PUT', `/${TEMPLATE}/versions/${VERSION}`, { snapshot: { hacked: true } });
    assert.equal(res.status, 400);
    assert.equal(state.queries.filter((q) => /^UPDATE/.test(q.sql)).length, 0);
    assert.equal(state.rolledBack, true);
    assert.equal(state.committed, false);
  });

  it('a flow-projected id is refused with FLOW_VERSION_READONLY, no query against template_versions', async () => {
    const res = await call('PUT', `/${TEMPLATE}/versions/run:${RUN_ID}`, { name: 'x' });
    assert.equal(res.status, 400);
    assert.equal(res.json.error.code, 'FLOW_VERSION_READONLY');
    assert.equal(state.queries.filter((q) => /template_versions/.test(q.sql)).length, 0);
    assert.equal(state.rolledBack, true);
  });

  it('a version belonging to another template 404s', async () => {
    state.forUpdateExisting = [];
    const res = await call('PUT', `/${TEMPLATE}/versions/${VERSION}`, { name: 'x' });
    assert.equal(res.status, 404);
    assert.equal(state.rolledBack, true);
    assert.equal(state.committed, false);
  });
});

// ── DELETE /:versionId ──────────────────────────────────────────────────────

describe('DELETE /:versionId', () => {
  it('deletes a manual version scoped to both ids', async () => {
    const res = await call('DELETE', `/${TEMPLATE}/versions/${VERSION}`);
    assert.equal(res.status, 200, JSON.stringify(res.json));
    const del = state.queries.find((q) => /^DELETE FROM `fmb_template_versions`/.test(q.sql));
    assert.deepEqual(del.params, [VERSION, TEMPLATE]);
    // S3 (fmb-1912 PR-4 residual): explicit transaction around the FOR
    // UPDATE read + DELETE — a successful delete must commit it.
    assert.equal(state.committed, true);
    assert.equal(state.rolledBack, false);
  });

  it('a run-projected id returns 400, never a DELETE', async () => {
    const res = await call('DELETE', `/${TEMPLATE}/versions/run:${RUN_ID}`);
    assert.equal(res.status, 400);
    assert.equal(res.json.error.code, 'FLOW_VERSION_READONLY');
    assert.equal(state.queries.filter((q) => /^DELETE/.test(q.sql)).length, 0);
    assert.equal(state.rolledBack, true);
  });

  it('a stranger may not delete', async () => {
    currentUser = STRANGER;
    const res = await call('DELETE', `/${TEMPLATE}/versions/${VERSION}`);
    assert.equal(res.status, 404);
    assert.equal(state.queries.filter((q) => /^DELETE/.test(q.sql)).length, 0);
    assert.equal(state.rolledBack, true);
    assert.equal(state.committed, false);
  });
});

// ── POST /:versionId/restore ────────────────────────────────────────────────

describe('POST /:versionId/restore', () => {
  it('overwrites payload and generated_outputs in one transaction', async () => {
    state.manualRow = manualRow({
      snapshot: JSON.stringify({
        doc_version: 2, entered: { a: '1', b: '2' }, computed: { c: '3' }, outputs: { out1: 'val' },
      }),
    });
    const res = await call('POST', `/${TEMPLATE}/versions/${VERSION}/restore`);
    assert.equal(res.status, 200, JSON.stringify(res.json));
    assert.equal(state.committed, true);
    const update = state.queries.find((q) => /^UPDATE `fmb_user_templates`/.test(q.sql));
    assert.ok(update, 'restore must overwrite user_templates');
    const [payloadJson, outputsJson, id] = update.params;
    assert.deepEqual(JSON.parse(payloadJson), { c: '3', a: '1', b: '2' });
    assert.deepEqual(JSON.parse(outputsJson), { out1: 'val' });
    assert.equal(id, TEMPLATE);
    // The three companion columns the loader reapplies must be reset, or a
    // restore would leave a state that never existed once the loader replays
    // them on top of the restored payload.
    assert.match(update.sql, /field_option_selection\s*=\s*NULL/);
    assert.match(update.sql, /computed_field_overrides\s*=\s*NULL/);
    assert.match(update.sql, /cleared_auto_fills\s*=\s*NULL/);
  });

  it('restores from a flow-projected version too', async () => {
    state.flowRow = flowRunRow();
    const res = await call('POST', `/${TEMPLATE}/versions/run:${RUN_ID}/restore`);
    assert.equal(res.status, 200, JSON.stringify(res.json));
    assert.equal(state.committed, true);
  });

  // F6 (P1) — restoring from a `run:<id>` version must not drop the run's
  // generated outputs: they live in output_snapshot, a column input_snapshot
  // never carries.
  it('restore from a flow version preserves outputs (read from output_snapshot) in the UPDATE params', async () => {
    state.flowRow = flowRunRow();
    const res = await call('POST', `/${TEMPLATE}/versions/run:${RUN_ID}/restore`);
    assert.equal(res.status, 200, JSON.stringify(res.json));
    const update = state.queries.find((q) => /^UPDATE `fmb_user_templates`/.test(q.sql));
    assert.ok(update, 'restore must overwrite user_templates');
    const [, outputsJson] = update.params;
    assert.deepEqual(JSON.parse(outputsJson), { out1: 'flow-out' });
  });

  // F6 (P1) — degraded schema: a database whose SELECT 500s naming
  // input_snapshot/output_snapshot (ER_BAD_FIELD_ERROR) still gets a well-
  // formed answer from the retry, never a 500 — same reactive-fallback
  // contract as GET, tested route-wide here.
  it('restore from a flow version on a degraded schema (columns missing) still works — a handled 409, never a 500', async () => {
    state.flowRow = flowRunRow();
    state.flowSnapshotColumnsMissing = true;
    const res = await call('POST', `/${TEMPLATE}/versions/run:${RUN_ID}/restore`);
    assert.equal(res.status, 409, JSON.stringify(res.json));
    assert.equal(res.json.error.code, 'CONFLICT');
    // Proof the degraded retry actually ran, not that the primary query
    // silently swallowed the error.
    assert.ok(state.queries.some((q) => /^SELECT id, template_id, blueprint_id, actor_id, status, created_at\s+FROM `fmb_flow_recipe_runs`/.test(q.sql)));
  });

  it('returns 409 CONFLICT when the snapshot cannot be read', async () => {
    state.manualRow = manualRow({ snapshot: '{not json' });
    const res = await call('POST', `/${TEMPLATE}/versions/${VERSION}/restore`);
    assert.equal(res.status, 409);
    assert.equal(res.json.error.code, 'CONFLICT');
    assert.equal(state.queries.some((q) => /^UPDATE `fmb_user_templates`/.test(q.sql)), false);
    assert.equal(state.rolledBack, true);
    assert.equal(state.committed, false);
  });

  it('returns 409 CONFLICT for a flow run with no captured input (input_snapshot NULL)', async () => {
    state.flowRow = flowRunRow({ input_snapshot: null });
    const res = await call('POST', `/${TEMPLATE}/versions/run:${RUN_ID}/restore`);
    assert.equal(res.status, 409);
    assert.equal(res.json.error.code, 'CONFLICT');
  });

  it('returns 409 TEMPLATE_CHANGED when the template moved after the saved version\'s freeze-point stamp', async () => {
    state.manualRow = manualRow();
    state.templateRow.updated_at = '2026-03-01 00:00:00'; // written AFTER the save below
    state.savedVersionRow = [{
      id: 'saved-1',
      snapshot: JSON.stringify({ ...validDoc, base_template_updated_at: '2026-02-15T00:00:00Z' }),
    }];
    const res = await call('POST', `/${TEMPLATE}/versions/${VERSION}/restore`, { saved_version_id: 'dddddddd-1111-1111-1111-111111111111' });
    assert.equal(res.status, 409, JSON.stringify(res.json));
    assert.equal(res.json.error.code, 'TEMPLATE_CHANGED');
    assert.equal(state.queries.some((q) => /^UPDATE `fmb_user_templates`/.test(q.sql)), false);
    assert.equal(state.rolledBack, true);
    assert.equal(state.committed, false);
  });

  it('proceeds when the saved version\'s freeze-point fingerprint still matches the template\'s current content', async () => {
    state.manualRow = manualRow();
    state.templateRow.updated_at = '2026-02-01 00:00:00';
    state.savedVersionRow = [{
      id: 'saved-1',
      snapshot: JSON.stringify({
        ...validDoc,
        base_template_updated_at: '2026-02-01T00:00:00Z',
        base_template_fingerprint: templateStateFingerprint(state.templateRow),
      }),
    }];
    const res = await call('POST', `/${TEMPLATE}/versions/${VERSION}/restore`, { saved_version_id: 'dddddddd-1111-1111-1111-111111111111' });
    assert.equal(res.status, 200, JSON.stringify(res.json));
    assert.equal(res.json.data.prior_state_saved, true);
    assert.equal(res.json.data.saved_version_id, 'dddddddd-1111-1111-1111-111111111111');
  });

  it('a saved_version_id from another template is a 404 and nothing is overwritten', async () => {
    state.manualRow = manualRow();
    state.savedVersionRow = [];
    const res = await call('POST', `/${TEMPLATE}/versions/${VERSION}/restore`, { saved_version_id: 'dddddddd-1111-1111-1111-111111111111' });
    assert.equal(res.status, 404);
    assert.equal(state.queries.some((q) => /^UPDATE `fmb_user_templates`/.test(q.sql)), false);
  });

  it('writes one audit row naming the version and whether prior state was saved', async () => {
    state.manualRow = manualRow();
    await call('POST', `/${TEMPLATE}/versions/${VERSION}/restore`);
    const audit = state.queries.find((q) => /^INSERT INTO `fmb_feature_audit`/.test(q.sql));
    assert.ok(audit);
    const meta = JSON.parse(audit.params[3]);
    assert.equal(meta.template_id, TEMPLATE);
    assert.equal(meta.version_id, VERSION);
    assert.equal(meta.prior_state_saved, false);
    assert.equal(audit.params[1], 'template.version.restore');
  });

  it('a stranger may not restore, and nothing is queried against user_templates for a write', async () => {
    currentUser = STRANGER;
    state.manualRow = manualRow();
    const res = await call('POST', `/${TEMPLATE}/versions/${VERSION}/restore`);
    assert.equal(res.status, 404);
    assert.equal(state.queries.some((q) => /^UPDATE `fmb_user_templates`/.test(q.sql)), false);
  });

  // S3 (fmb-1912 PR-4 residual, card fmb-1914 deferred): a fault landing
  // AFTER the UPDATE user_templates write but BEFORE the audit INSERT that
  // follows it in the same transaction must roll back — the UPDATE having
  // already been attempted (not rejected before ever running, the way the
  // 409 cases above are) is exactly what proves this is a MID-transaction
  // failure, not a pre-write validation rejection.
  it('a mid-transaction throw between the UPDATE and the audit INSERT rolls back — the UPDATE never commits', async () => {
    state.manualRow = manualRow();
    state.throwOnSql = /^INSERT INTO `fmb_feature_audit`/;
    const res = await call('POST', `/${TEMPLATE}/versions/${VERSION}/restore`);
    assert.equal(res.status, 500, JSON.stringify(res.json));
    assert.equal(state.committed, false);
    assert.equal(state.rolledBack, true);
    assert.equal(state.queries.some((q) => /^UPDATE `fmb_user_templates`/.test(q.sql)), true);
  });
});

// ── POST /:versionId/save-as ────────────────────────────────────────────────

describe('POST /:versionId/save-as', () => {
  it('creates a new template row and leaves the source untouched', async () => {
    state.manualRow = manualRow({ name: 'Baseline' });
    const res = await call('POST', `/${TEMPLATE}/versions/${VERSION}/save-as`);
    assert.equal(res.status, 201, JSON.stringify(res.json));
    const insert = state.queries.find((q) => /^INSERT INTO `fmb_user_templates`/.test(q.sql));
    assert.ok(insert, 'save-as must INSERT a new template row');
    assert.equal(state.queries.some((q) => /^UPDATE `fmb_user_templates`/.test(q.sql)), false, 'the source row is never updated');
    assert.equal(state.queries.some((q) => /^DELETE/.test(q.sql)), false);
  });

  it('defaults the new name to "<version name> (copy)"', async () => {
    state.manualRow = manualRow({ name: 'Baseline' });
    await call('POST', `/${TEMPLATE}/versions/${VERSION}/save-as`);
    const insert = state.queries.find((q) => /^INSERT INTO `fmb_user_templates`/.test(q.sql));
    const nameIdx = 1; // (id, name, owner_id, ...)
    assert.equal(insert.params[nameIdx], 'Baseline (copy)');
  });

  it('uses a caller-supplied name when given', async () => {
    state.manualRow = manualRow({ name: 'Baseline' });
    await call('POST', `/${TEMPLATE}/versions/${VERSION}/save-as`, { name: 'My Clone' });
    const insert = state.queries.find((q) => /^INSERT INTO `fmb_user_templates`/.test(q.sql));
    assert.equal(insert.params[1], 'My Clone');
  });

  it('clones a flow-projected version too', async () => {
    state.flowRow = flowRunRow();
    const res = await call('POST', `/${TEMPLATE}/versions/run:${RUN_ID}/save-as`);
    assert.equal(res.status, 201, JSON.stringify(res.json));
  });

  // F6 (P1) — save-as from a flow version must copy its outputs too, read
  // from output_snapshot, into the new template's generated_outputs.
  it('save-as from a flow version copies outputs (read from output_snapshot)', async () => {
    state.flowRow = flowRunRow();
    await call('POST', `/${TEMPLATE}/versions/run:${RUN_ID}/save-as`);
    const insert = state.queries.find((q) => /^INSERT INTO `fmb_user_templates`/.test(q.sql));
    assert.ok(insert);
    const generatedOutputsIdx = insert.params.length - 3; // (..., payload, generated_outputs, schema_version, parent_id)
    assert.deepEqual(JSON.parse(insert.params[generatedOutputsIdx]), { out1: 'flow-out' });
  });

  it('refuses to clone when the snapshot cannot be read', async () => {
    state.manualRow = manualRow({ snapshot: '{not json' });
    const res = await call('POST', `/${TEMPLATE}/versions/${VERSION}/save-as`);
    assert.equal(res.status, 409);
    assert.equal(state.queries.some((q) => /^INSERT INTO `fmb_user_templates`/.test(q.sql)), false);
  });

  it('a stranger may not save-as', async () => {
    currentUser = STRANGER;
    state.manualRow = manualRow();
    const res = await call('POST', `/${TEMPLATE}/versions/${VERSION}/save-as`);
    assert.equal(res.status, 404);
    assert.equal(state.queries.some((q) => /^INSERT INTO `fmb_user_templates`/.test(q.sql)), false);
  });

  // S3 (fmb-1912 PR-4 residual, card fmb-1914 deferred): the clone INSERT is
  // save-as's sole write inside the transaction — a fault landing on it
  // (attempted, then failing) must still roll back cleanly rather than
  // half-committing, same contract the restore mid-transaction test above
  // pins for its own two-write sequence.
  it('a mid-transaction throw on the clone INSERT rolls back — nothing commits, the source stays untouched', async () => {
    state.manualRow = manualRow({ name: 'Baseline' });
    state.throwOnSql = /^INSERT INTO `fmb_user_templates`/;
    const res = await call('POST', `/${TEMPLATE}/versions/${VERSION}/save-as`);
    assert.equal(res.status, 500, JSON.stringify(res.json));
    assert.equal(state.committed, false);
    assert.equal(state.rolledBack, true);
    assert.equal(state.queries.some((q) => /^INSERT INTO `fmb_user_templates`/.test(q.sql)), true);
    assert.equal(state.queries.some((q) => /^UPDATE `fmb_user_templates`/.test(q.sql)), false);
  });
});

// ── F6 (P1) — flowSnapshotDocument: outputs assembled from output_snapshot ──

describe('flowSnapshotDocument (unit) — outputs come from output_snapshot', () => {
  const { flowSnapshotDocument } = router.__test__;

  it('merges outputs from output_snapshot into the input_snapshot document', () => {
    const doc = flowSnapshotDocument({
      input_snapshot: JSON.stringify({ entered: { a: '1' }, computed: { c: '2' } }),
      output_snapshot: JSON.stringify({ out1: 'x' }),
    });
    assert.deepEqual(doc, { entered: { a: '1' }, computed: { c: '2' }, outputs: { out1: 'x' } });
  });

  it('degraded case only: outputs default to {} when output_snapshot is null/absent, entered/computed stay intact', () => {
    const doc = flowSnapshotDocument({
      input_snapshot: JSON.stringify({ entered: { a: '1' }, computed: {} }),
      output_snapshot: null,
    });
    assert.deepEqual(doc, { entered: { a: '1' }, computed: {}, outputs: {} });
  });

  it('a non-object parsed input_snapshot is returned unchanged (no outputs key manufactured)', () => {
    assert.equal(flowSnapshotDocument({ input_snapshot: null, output_snapshot: JSON.stringify({ out1: 'x' }) }), null);
  });
});

// ── F7 (P1) — restore's freshness guard is a server-stamped freeze point ───

describe('POST /:versionId/restore — freshness guard is a content fingerprint, not created_at ordering or updated_at equality', () => {
  it('happy path: the saved version\'s fingerprint matches the template\'s current content, restore proceeds', async () => {
    state.manualRow = manualRow();
    state.templateRow.updated_at = '2026-02-01 00:00:00';
    state.savedVersionRow = [{
      id: 'saved-1',
      snapshot: JSON.stringify({
        ...validDoc,
        base_template_updated_at: '2026-02-01T00:00:00Z',
        base_template_fingerprint: templateStateFingerprint(state.templateRow),
      }),
    }];
    const res = await call('POST', `/${TEMPLATE}/versions/${VERSION}/restore`, { saved_version_id: 'dddddddd-1111-1111-1111-111111111111' });
    assert.equal(res.status, 200, JSON.stringify(res.json));
    assert.equal(res.json.data.prior_state_saved, true);
  });

  // F8 (P1) — the discriminating case: `updated_at` is IDENTICAL between the
  // freeze-point stamp and the current row (same second — the OLD
  // timestamp-equality guard would have PASSED this), but the template's
  // payload changed in that same second. Only a content fingerprint can see
  // the intervening write; the old code would have destroyed it.
  it('409 TEMPLATE_CHANGED when payload changed in the SAME second as the freeze-point stamp (updated_at identical)', async () => {
    state.manualRow = manualRow();
    state.templateRow.updated_at = '2026-02-01 00:00:00';
    const frozenFingerprint = templateStateFingerprint(state.templateRow);
    state.savedVersionRow = [{
      id: 'saved-1',
      snapshot: JSON.stringify({
        ...validDoc,
        base_template_updated_at: '2026-02-01T00:00:00Z',
        base_template_fingerprint: frozenFingerprint,
      }),
    }];
    // Same-second write: updated_at unchanged, but payload moved.
    state.templateRow.payload = '{"a":"1","b":"2"}';
    const res = await call('POST', `/${TEMPLATE}/versions/${VERSION}/restore`, { saved_version_id: 'dddddddd-1111-1111-1111-111111111111' });
    assert.equal(res.status, 409, JSON.stringify(res.json));
    assert.equal(res.json.error.code, 'TEMPLATE_CHANGED');
    assert.equal(state.queries.some((q) => /^UPDATE `fmb_user_templates`/.test(q.sql)), false);
    assert.equal(state.rolledBack, true);
    assert.equal(state.committed, false);
  });

  // `created_at` ordering alone can never see this: created_at is AFTER the
  // template's updated_at (an old created_at-ordered guard would have
  // passed it), but the fingerprint the version actually froze against
  // disagrees with the template's current content — proof the template
  // moved again after this version was cut.
  it('409 TEMPLATE_CHANGED when the template\'s fingerprint disagrees, even when created_at ordering would have passed', async () => {
    state.manualRow = manualRow();
    state.templateRow.updated_at = '2026-02-01 00:00:00';
    state.savedVersionRow = [{
      // created_at is AFTER the template's updated_at — an old
      // created_at-ordered check would have PASSED here.
      id: 'saved-1',
      created_at: '2026-02-10 00:00:00',
      // A fingerprint that does not match the CURRENT template row.
      snapshot: JSON.stringify({ ...validDoc, base_template_fingerprint: 'deadbeef'.repeat(8) }),
    }];
    const res = await call('POST', `/${TEMPLATE}/versions/${VERSION}/restore`, { saved_version_id: 'dddddddd-1111-1111-1111-111111111111' });
    assert.equal(res.status, 409, JSON.stringify(res.json));
    assert.equal(res.json.error.code, 'TEMPLATE_CHANGED');
    assert.equal(state.queries.some((q) => /^UPDATE `fmb_user_templates`/.test(q.sql)), false);
    assert.equal(state.rolledBack, true);
    assert.equal(state.committed, false);
  });

  // F8 (P1) — never fall-open: a missing fingerprint stamp refuses exactly
  // like a mismatched one, never like a match.
  it('409 TEMPLATE_CHANGED, never fall-open, when the saved version\'s snapshot carries no fingerprint stamp at all', async () => {
    state.manualRow = manualRow();
    state.templateRow.updated_at = '2026-02-01 00:00:00';
    state.savedVersionRow = [{ id: 'saved-1', snapshot: JSON.stringify(validDoc) }]; // no base_template_fingerprint key
    const res = await call('POST', `/${TEMPLATE}/versions/${VERSION}/restore`, { saved_version_id: 'dddddddd-1111-1111-1111-111111111111' });
    assert.equal(res.status, 409, JSON.stringify(res.json));
    assert.equal(res.json.error.code, 'TEMPLATE_CHANGED');
    assert.equal(state.queries.some((q) => /^UPDATE `fmb_user_templates`/.test(q.sql)), false);
  });

  it('POST /versions stamps base_template_updated_at from the server-read template row, overwriting any client-supplied value', async () => {
    state.templateRow.updated_at = '2026-03-05 00:00:00';
    state.manualRow = manualRow();
    const res = await call('POST', `/${TEMPLATE}/versions`, {
      name: 'x',
      snapshot: { ...validDoc, base_template_updated_at: '1999-01-01T00:00:00Z' },
    });
    assert.equal(res.status, 201, JSON.stringify(res.json));
    const insert = state.queries.find((q) => /^INSERT INTO `fmb_template_versions`/.test(q.sql));
    assert.ok(insert);
    const snapshotIdx = insert.params.length - 2; // (..., snapshot, actor_id)
    const stored = JSON.parse(insert.params[snapshotIdx]);
    assert.equal(stored.base_template_updated_at, '2026-03-05T00:00:00Z');
  });

  // F8 (P1) — the guard DECISION lives on the fingerprint, so it must be
  // server-stamped the same way: computed from the server-read row, and any
  // client-supplied value overwritten rather than trusted.
  it('POST /versions stamps base_template_fingerprint from the server-read template row, overwriting any client-supplied value', async () => {
    state.manualRow = manualRow();
    const res = await call('POST', `/${TEMPLATE}/versions`, {
      name: 'x',
      snapshot: { ...validDoc, base_template_fingerprint: 'client-supplied-lie' },
    });
    assert.equal(res.status, 201, JSON.stringify(res.json));
    const insert = state.queries.find((q) => /^INSERT INTO `fmb_template_versions`/.test(q.sql));
    assert.ok(insert);
    const snapshotIdx = insert.params.length - 2; // (..., snapshot, actor_id)
    const stored = JSON.parse(insert.params[snapshotIdx]);
    assert.equal(stored.base_template_fingerprint, templateStateFingerprint(state.templateRow));
    assert.notEqual(stored.base_template_fingerprint, 'client-supplied-lie');
  });
});

// ── F8 (P1) — templateStateFingerprint (unit): stability + change detection ─

describe('templateStateFingerprint (unit)', () => {
  const baseRow = {
    payload: '{"a":"1"}',
    generated_outputs: '{"out1":"x"}',
    field_option_selection: '{"f1":"opt-a"}',
    computed_field_overrides: '{"c1":"5"}',
    cleared_auto_fills: '["f2"]',
  };

  it('the same row hashes to the same fingerprint', () => {
    assert.equal(templateStateFingerprint({ ...baseRow }), templateStateFingerprint({ ...baseRow }));
  });

  it('each single-column change produces a different hash', () => {
    const base = templateStateFingerprint(baseRow);
    const columns = Object.keys(baseRow);
    for (const col of columns) {
      const changed = templateStateFingerprint({ ...baseRow, [col]: `${baseRow[col]}-changed` });
      assert.notEqual(changed, base, `changing ${col} must change the fingerprint`);
    }
  });

  it('null and empty string are distinct from each other and from shifted content', () => {
    const withNull = templateStateFingerprint({ ...baseRow, cleared_auto_fills: null });
    const withEmpty = templateStateFingerprint({ ...baseRow, cleared_auto_fills: '' });
    // Both normalize to '' internally, so they must be EQUAL to each other...
    assert.equal(withNull, withEmpty);
    // ...but distinct from the baseline (non-empty) value.
    assert.notEqual(withNull, templateStateFingerprint(baseRow));
  });

  it('content shifted across a column boundary does not collide with an equivalent bare newline-join', () => {
    // Without a field-name prefix per part, a plain newline-joined
    // concatenation can collide across a boundary shift: rowA's
    // payload="A\nB", generated_outputs="C" joins to the SAME raw string as
    // rowB's payload="A", generated_outputs="B\nC" ("A\nB\nC\n\n\n" either
    // way). The field-name prefix (p:/o:/f:/c:/a:) must break that collision.
    const empty = { field_option_selection: '', computed_field_overrides: '', cleared_auto_fills: '' };
    const rowA = { payload: 'A\nB', generated_outputs: 'C', ...empty };
    const rowB = { payload: 'A', generated_outputs: 'B\nC', ...empty };
    assert.notEqual(templateStateFingerprint(rowA), templateStateFingerprint(rowB));
  });
});
