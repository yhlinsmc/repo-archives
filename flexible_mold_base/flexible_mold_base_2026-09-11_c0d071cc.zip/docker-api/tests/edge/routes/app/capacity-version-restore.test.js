/**
 * capacity-version-restore.test.js — in-place restore of a capacity scenario
 * from one of its frozen versions (POST /scenarios/:id/versions/:vid/restore).
 *
 * Restore is the only DESTRUCTIVE capacity route: it deletes every
 * scenario-scoped row and replays the chosen snapshot over the SAME scenario.
 * The tests therefore assert the safety envelope, not just the happy path:
 *   - the route NEVER writes a version of its own (D6 moved saving the replaced
 *     state to the caller, as an explicit named create before this call)
 *   - a caller's claim about where the replaced state was saved is verified
 *     against this scenario's own versions before it reaches the audit trail
 *   - every rejection path (unreadable snapshot, schema_rev drift, malformed
 *     rows, an unknown saved-version id) fails BEFORE anything is deleted
 *   - the global config layer, the bundle tables and the version history itself
 *     are never touched
 *   - a mid-flight DB failure rolls back and never commits
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const { makeStubReqLog } = require('../../../helpers/stub-req-log');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

// ── Mock edge/db BEFORE requiring the capacity router ─────────────────────────
const dbKey = require.resolve('../../../../src/edge/db');

const CAP_COLUMNS = ['id', 'scenario_id', 'name', 'note', 'metadata'].map((c) => ({ COLUMN_NAME: c }));

let state;
function freshState() {
  return {
    queries: [],              // { sql, params }
    committed: false,
    rolledBack: false,
    scenarioOwnerRows: undefined, // owner FOR UPDATE probe ([] ⇒ scenario missing)
    versionRow: undefined,        // the target version read ([] ⇒ not found here)
    savedVersionRows: undefined,  // the saved-state pointer probe ([] ⇒ unknown id)
    liveRows: {},                 // scenario-scoped SELECT * WHERE scenario_id = ?
    globalRules: [],              // addGlobalConfigLayer: scenario_id IS NULL rules
    globalSettings: [],           // addGlobalConfigLayer: scenario_id IS NULL settings
    failOnSql: null,              // { pattern, errno } → that query throws
    deleteAffected: 2,
    errorLogCalls: [],             // req.log.error(...) calls, in order
  };
}

const conn = {
  async beginTransaction() {},
  async commit() { state.committed = true; },
  async rollback() { state.rolledBack = true; },
  release() {},
  async query(sql, params = []) {
    state.queries.push({ sql, params });

    if (state.failOnSql && new RegExp(state.failOnSql.pattern).test(sql)) {
      const e = new Error(`simulated failure on: ${sql}`);
      if (state.failOnSql.errno) { e.errno = state.failOnSql.errno; }
      throw e;
    }

    if (/information_schema\.COLUMNS/i.test(sql)) return CAP_COLUMNS;
    if (/SELECT DATABASE\(\)/i.test(sql)) return [{ db: 'testdb' }];

    // resolveScenarioWriteAccess.
    if (/SELECT id, owner_id FROM `fmb_cap_scenarios` WHERE id = \? FOR UPDATE/.test(sql)) {
      return state.scenarioOwnerRows !== undefined
        ? state.scenarioOwnerRows
        : [{ id: params[0], owner_id: null }];
    }
    // The saved-state pointer probe — checked BEFORE the target version read
    // below, which shares the same WHERE clause but a different column list.
    // Its DEFAULT answer is "the named version froze exactly the rows that are
    // live right now", which is what a caller's own save-then-switch sequence
    // produces; a test that wants a STALE pointer sets `state.savedVersionRows`
    // to a snapshot that disagrees with `state.liveRows`.
    if (/^SELECT id, snapshot FROM `fmb_cap_versions` WHERE id = \? AND scenario_id = \?/.test(sql)) {
      if (state.savedVersionRows !== undefined) return state.savedVersionRows;
      return [{
        id: params[0],
        snapshot: JSON.stringify({ schema_rev: SNAPSHOT_SCHEMA_REV, tables: state.liveRows }),
      }];
    }
    // The target version read.
    if (/FROM `fmb_cap_versions` WHERE id = \? AND scenario_id = \?/.test(sql)) {
      return state.versionRow !== undefined ? state.versionRow : [];
    }
    // addCatalogueClosure (global catalogue rows a scenario references).
    if (/SELECT \* FROM `fmb_cap_[a-z_]+` WHERE scenario_id IS NULL AND id IN/.test(sql)) return [];
    // addGlobalConfigLayer.
    if (/SELECT \* FROM `fmb_cap_rules` WHERE scenario_id IS NULL$/.test(sql)) return state.globalRules;
    if (/SELECT \* FROM `fmb_cap_settings` WHERE scenario_id IS NULL$/.test(sql)) return state.globalSettings;
    // The live scenario read. Nothing is frozen here any more (D6) — this now
    // feeds the freshness fingerprint, and only on a switch that names a saved
    // version.
    const scoped = sql.match(/^SELECT \* FROM `fmb_cap_([a-z_]+)` WHERE scenario_id = \?\s*$/);
    if (scoped) return state.liveRows[scoped[1]] || [];

    if (/^INSERT INTO/.test(sql)) return { affectedRows: 1, insertId: 1 };
    if (/^DELETE FROM/.test(sql)) return { affectedRows: state.deleteAffected };
    if (/^UPDATE/.test(sql)) return { affectedRows: 1 };
    return [];
  },
};

const poolFacade = {
  getConnection: async () => conn,
  query: (sql, params) => conn.query(sql, params),
};
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: { ro: poolFacade, rw: poolFacade }, t: (n) => `fmb_${n}` },
};

const router = require('../../../../src/edge/routes/app/capacity');
const { SNAPSHOT_TABLES, SNAPSHOT_SCHEMA_REV } = require('../../../../src/edge/routes/app/capacity/_shared');

let currentUser; let server; let baseUrl;
before(async () => {
  const app = express();
  app.use((req, _res, next) => {
    // TEST-ONLY: production always sets req.log via createRequestId
    // (request-id.js) before any router; this bare app has no such
    // middleware, so a route's req.log.<level>() call would otherwise throw
    // against undefined. The `.error` call is also counted into
    // state.errorLogCalls so a test can assert exactly one app-error line
    // was emitted for a failure, catching a caller that logs its own line
    // AND lets sendError log the same exception again.
    const stub = makeStubReqLog();
    const origError = stub.error.bind(stub);
    stub.error = (...args) => { state.errorLogCalls.push(args); return origError(...args); };
    req.log = stub;
    next();
  });
  app.use(express.json());
  app.use((req, _res, next) => { req.user = currentUser; next(); });
  app.use('/capacity', router);
  server = http.createServer(app);
  await new Promise((r) => server.listen(0, r));
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});
after(() => server && server.close());
beforeEach(() => {
  state = freshState();
  currentUser = { id: 'u-admin', role: 'admin' };
});

function request(method, path, body) {
  return new Promise((resolve, reject) => {
    const payload = body === undefined ? '' : JSON.stringify(body);
    const r = http.request(
      `${baseUrl}${path}`,
      { method, headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) } },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          const raw = Buffer.concat(chunks).toString('utf8');
          let json = null;
          try { json = JSON.parse(raw); } catch { /* noop */ }
          resolve({ status: res.statusCode, json, raw });
        });
      },
    );
    r.on('error', reject);
    if (payload) r.write(payload);
    r.end();
  });
}

const colsOf = (q) => {
  const cols = q.sql.match(/\(([^)]*)\)\s*VALUES/i)[1].split(',').map((c) => c.trim().replace(/`/g, ''));
  const row = {}; cols.forEach((c, i) => { row[c] = q.params[i]; });
  return row;
};
const insertsInto = (table) =>
  state.queries.filter((q) => new RegExp(`^INSERT INTO \`fmb_${table}\` `).test(q.sql));
const deletesFrom = (table) =>
  state.queries.filter((q) => new RegExp(`^DELETE FROM \`fmb_${table}\` `).test(q.sql));
const firstIndex = (re) => state.queries.findIndex((q) => re.test(q.sql));

// ── Fixtures ─────────────────────────────────────────────────────────────────

// The FROZEN state a restore replays. Keys in SNAPSHOT_TABLES order. Rows carry
// created_at/updated_at (the driver returns them) so the tests can prove those
// are NOT replayed as literals. The settings + rules keys additionally carry a
// GLOBAL-layer row (scenario_id null, injected by addGlobalConfigLayer at freeze
// time) which a restore must never reincarnate as a scenario-local row.
function frozenTables() {
  return {
    hardware_specs: [{ id: 'spec-1', scenario_id: 'scn-1', name: 'Spec-A', cpu_total: 64, created_at: '2026-01-01 00:00:00' }],
    disk_combos: [{ id: 'combo-1', scenario_id: 'scn-1', name: 'OS only', sizes: null }],
    teams: [{ id: 'team-1', scenario_id: 'scn-1', name: 'erp', color: '#3355ff' }],
    vm_profiles: [{ id: 'prof-1', scenario_id: 'scn-1', class: 'DB', name: 'DB-16C', allowed_disk_combos: ['combo-1'] }],
    settings: [
      { id: 'set-1', scenario_id: 'scn-1', mem_cpu_ratio: 20 },
      { id: 'set-global', scenario_id: null, mem_cpu_ratio: 18 },
    ],
    rules: [
      { id: 'rule-1', scenario_id: 'scn-1', type: 'keep-apart', name: 'Keep apart', level: 'db_instance' },
      { id: 'rule-global', scenario_id: null, type: 'max-vms-per-host', name: 'Global', level: 'hypervisor' },
    ],
    sites: [{ id: 'site-1', scenario_id: 'scn-1', name: 'DC-1', topology: 'site', metadata: { tier: 1 } }],
    hypervisors: [{ id: 'hv-1', scenario_id: 'scn-1', site_id: 'site-1', spec_id: 'spec-1', name: 'HV-1' }],
    databases: [{ id: 'dbx-1', scenario_id: 'scn-1', function_name: 'erp', profile_id: 'prof-1', team_id: 'team-1' }],
    vms: [{ id: 'vm-1', scenario_id: 'scn-1', vm_type: 'db_host', hypervisor_id: 'hv-1', name: 'VM-1', updated_at: '2026-01-02 00:00:00' }],
    db_instances: [{ id: 'inst-1', scenario_id: 'scn-1', vm_id: 'vm-1', database_id: 'dbx-1', role: 'primary', sga_gb: 40 }],
    custom_groups: [{ id: 'cg-1', scenario_id: 'scn-1', name: 'group-a', team_id: 'team-1' }],
    custom_group_members: [{ id: 'cgm-1', scenario_id: 'scn-1', group_id: 'cg-1', member_vm_id: 'vm-1' }],
    waivers: [{ id: 'wv-1', scenario_id: 'scn-1', rule_id: 'rule-1', object_set_key: 'hv-1|vm-1', created_by: 'u-ed' }],
  };
}

// The CURRENT working state — deliberately different from the frozen one so the
// pre-restore backup can be told apart from the snapshot being restored.
function liveTables() {
  return {
    sites: [{ id: 'site-live', scenario_id: 'scn-1', name: 'DC-LIVE', topology: 'site' }],
    vms: [{ id: 'vm-live', scenario_id: 'scn-1', name: 'VM-LIVE', vm_type: 'ap_host' }],
  };
}

function armRestore(tables = frozenTables()) {
  // Carries `id` because the restore binds the scenario's OWN id, not the URL
  // segment — a scripted row without it would stamp SQL NULL into every
  // re-inserted child row.
  state.scenarioOwnerRows = [{ id: 'scn-1', owner_id: null }];
  state.liveRows = liveTables();
  state.versionRow = [{
    id: 'v1', scenario_id: 'scn-1', name: 'Baseline v1',
    snapshot: JSON.stringify({ schema_rev: SNAPSHOT_SCHEMA_REV, tables }),
  }];
}

const RESTORE_PATH = '/capacity/scenarios/scn-1/versions/v1/restore';

// ── Happy path: round-trip equality + auto-backup ─────────────────────────────

describe('capacity version restore — round-trip', () => {
  it('replays every frozen scenario-local row verbatim (same ids, same scenario)', async () => {
    armRestore();
    const res = await request('POST', RESTORE_PATH);
    assert.equal(res.status, 200, res.raw);
    assert.equal(state.committed, true);

    const frozen = frozenTables();
    for (const { key, table } of SNAPSHOT_TABLES) {
      const expectedRows = (frozen[key] || []).filter((r) => r.scenario_id !== null);
      const written = insertsInto(table).map(colsOf);
      assert.equal(written.length, expectedRows.length, `${table}: wrong number of restored rows`);
      expectedRows.forEach((expected, i) => {
        const actual = written[i];
        // Timestamps are DB-managed on replay (see RESTORE_SKIP_COLUMNS): the
        // frozen document stays the record of the original times.
        const { created_at: _c, updated_at: _u, ...business } = expected;
        const normalized = {};
        for (const [col, val] of Object.entries(business)) {
          normalized[col] = val !== null && typeof val === 'object' ? JSON.stringify(val) : val;
        }
        assert.deepEqual(actual, normalized, `${table}: restored row must equal the frozen row`);
      });
    }
  });

  it('preserves ids so FK-by-convention columns and waiver object_set_key still resolve', async () => {
    armRestore();
    await request('POST', RESTORE_PATH);
    const vm = colsOf(insertsInto('cap_vms')[0]);
    const hv = colsOf(insertsInto('cap_hypervisors')[0]);
    const waiver = colsOf(insertsInto('cap_waivers')[0]);
    assert.equal(vm.id, 'vm-1', 'restore keeps the frozen id (the row it replaces was just deleted)');
    assert.equal(vm.hypervisor_id, hv.id);
    assert.equal(waiver.object_set_key, 'hv-1|vm-1', 'no id remap ⇒ the frozen waiver key still matches');
  });

  it('never replays created_at / updated_at as literals', async () => {
    armRestore();
    await request('POST', RESTORE_PATH);
    const vm = colsOf(insertsInto('cap_vms')[0]);
    const spec = colsOf(insertsInto('cap_hardware_specs')[0]);
    assert.equal(Object.prototype.hasOwnProperty.call(vm, 'updated_at'), false);
    assert.equal(Object.prototype.hasOwnProperty.call(spec, 'created_at'), false);
  });

  it('reports per-table restored counts and whether the replaced state was saved', async () => {
    armRestore();
    const res = await request('POST', RESTORE_PATH);
    assert.equal(res.status, 200, res.raw);
    const data = res.json.data;
    assert.equal(data.scenario_id, 'scn-1');
    assert.equal(data.version_id, 'v1');
    assert.equal(data.prior_state_saved, false, 'no saved_version_id was sent');
    assert.equal(data.saved_version_id, null);
    assert.equal(data.restored_counts.vms, 1);
    assert.equal(data.restored_counts.settings, 1, 'the global settings row is not restored scenario-locally');
  });
});

describe('capacity version restore — the route saves nothing of its own (D6)', () => {
  it('writes NO version row: the state being replaced is the caller\'s to save', async () => {
    armRestore();
    currentUser = { id: 'u-ed', role: 'editor' };
    const res = await request('POST', RESTORE_PATH);
    assert.equal(res.status, 200, res.raw);
    assert.equal(
      insertsInto('cap_versions').length, 0,
      'the automatic `Pre-restore backup <timestamp>` row is gone — nobody asked for it and nobody pruned it',
    );
  });

  it('reads no live rows when the caller kept nothing (the pre-restore freeze is gone)', async () => {
    armRestore();
    await request('POST', RESTORE_PATH);
    const liveReads = state.queries.filter((q) => /^SELECT \* FROM `fmb_cap_[a-z_]+` WHERE scenario_id = \?\s*$/.test(q.sql));
    assert.equal(
      liveReads.length, 0,
      'nothing is frozen here any more, and with no saved version named there is nothing to compare the live state against',
    );
  });

  it('a huge live scenario is no longer a reason to refuse (the size cap moved to the create route)', async () => {
    armRestore();
    state.liveRows = { vms: [{ id: 'vm-live', scenario_id: 'scn-1', name: 'x'.repeat(5 * 1024 * 1024) }] };
    const res = await request('POST', RESTORE_PATH);
    assert.equal(res.status, 200, res.raw);
  });

  it('ignores a client-supplied body apart from saved_version_id', async () => {
    armRestore();
    currentUser = { id: 'u-ed', role: 'editor' };
    const res = await request('POST', RESTORE_PATH, {
      name: 'FORGED', created_by: 'HACKER', snapshot: { tables: { vms: [{ id: 'x' }] } },
    });
    assert.equal(res.status, 200, res.raw);
    assert.equal(insertsInto('cap_versions').length, 0, 'a client body can never conjure a version row');
    const meta = JSON.parse(colsOf(insertsInto('feature_audit')[0]).metadata);
    assert.equal(meta.prior_state_saved, false);
    assert.equal(meta.saved_version_id, null);
  });
});

describe('capacity version restore — the saved-state pointer is verified, not trusted', () => {
  it('records the saved version when it belongs to this scenario', async () => {
    armRestore();
    const res = await request('POST', RESTORE_PATH, { saved_version_id: 'saved-1' });
    assert.equal(res.status, 200, res.raw);
    assert.equal(res.json.data.prior_state_saved, true);
    assert.equal(res.json.data.saved_version_id, 'saved-1');
    const meta = JSON.parse(colsOf(insertsInto('feature_audit')[0]).metadata);
    assert.equal(meta.prior_state_saved, true);
    assert.equal(meta.saved_version_id, 'saved-1');
    // It is looked up against THIS scenario, not taken on the caller's word.
    const probe = state.queries.filter((q) =>
      /^SELECT id, snapshot FROM `fmb_cap_versions` WHERE id = \? AND scenario_id = \?/.test(q.sql));
    assert.equal(probe.length, 1);
    assert.deepEqual(probe[0].params, ['saved-1', 'scn-1']);
  });

  // ── The pointer must describe the state being destroyed, not merely exist ──
  //
  // Save and switch are two round-trips and the client offers a retry from an
  // error dialog, so the operator can sit between them indefinitely. Without
  // this gate a write that landed in the gap was deleted with no copy in any
  // version, while the audit row recorded `prior_state_saved: true`.

  it('refuses the switch when the scenario changed after the named version was cut', async () => {
    armRestore();
    // The saved version froze an empty scenario; the live scenario now holds
    // rows — someone wrote to it after the save committed.
    state.savedVersionRows = [{
      id: 'saved-1',
      snapshot: JSON.stringify({ schema_rev: SNAPSHOT_SCHEMA_REV, tables: {} }),
    }];
    const res = await request('POST', RESTORE_PATH, { saved_version_id: 'saved-1' });
    assert.equal(res.status, 409, res.raw);
    assert.equal(res.json.error.code, 'SCENARIO_CHANGED', 'not the clone-me refusal — a different way out');
    assert.match(res.json.error.message, /changed after it was saved/i);
    assert.equal(state.queries.some((q) => /^DELETE FROM/.test(q.sql)), false, 'the check fires before the delete');
    assert.equal(state.rolledBack, true);
    assert.equal(state.committed, false);
  });

  it('a global-layer edit is not a scenario change (the restore never touches those rows)', async () => {
    armRestore();
    // The saved snapshot carries the global rule + settings rows a freeze folds
    // in, and one of them has been edited since. `deleteScenarioScopedRows`
    // never deletes a `scenario_id IS NULL` row, so this must not read as "the
    // scenario moved" — refusing here would block every switch on a scenario
    // whose global template someone else maintains.
    state.savedVersionRows = [{
      id: 'saved-1',
      snapshot: JSON.stringify({
        schema_rev: SNAPSHOT_SCHEMA_REV,
        tables: {
          ...liveTables(),
          rules: [{ id: 'rule-global', scenario_id: null, name: 'Global', level: 'hypervisor' }],
          settings: [{ id: 'set-global', scenario_id: null, mem_cpu_ratio: 18 }],
        },
      }),
    }];
    const res = await request('POST', RESTORE_PATH, { saved_version_id: 'saved-1' });
    assert.equal(res.status, 200, res.raw);
  });

  // a legacy-stored name_patterns override must not phantom-diff
  // against its hydrated equivalent. The LIVE settings row still carries the
  // pre-split 3-key shape (never resaved since before the kvm_host_primary/
  // standby split); the SAVED version was frozen through the (now-hydrated)
  // buildScenarioSnapshotDoc, so ITS settings row already carries the
  // equivalent 4-key shape. Nothing actually changed — readScenarioSnapshotTables
  // hydrates the live read the SAME way at the read boundary, so the two must
  // fingerprint equal and the switch must proceed, not false-409.
  it('a legacy-stored name_patterns override does not phantom-diff against its hydrated equivalent', async () => {
    armRestore();
    state.liveRows = {
      ...liveTables(),
      settings: [{
        id: 'set-1', scenario_id: 'scn-1', mem_cpu_ratio: 20,
        name_patterns: { hypervisor: 'hv-{dc}-{seq:2}', kvm_host: 'kvm-{dc}-{seq:2}', ap_vm: 'ap-{seq:2}' },
      }],
    };
    state.savedVersionRows = [{
      id: 'saved-1',
      snapshot: JSON.stringify({
        schema_rev: SNAPSHOT_SCHEMA_REV,
        tables: {
          ...liveTables(),
          settings: [{
            id: 'set-1', scenario_id: 'scn-1', mem_cpu_ratio: 20,
            name_patterns: {
              hypervisor: 'hv-{dc}-{seq:2}', kvm_host_primary: 'kvm-{dc}-{seq:2}', kvm_host_standby: 'kvm-{dc}-{seq:2}', ap_vm: 'ap-{seq:2}',
            },
          }],
        },
      }),
    }];
    const res = await request('POST', RESTORE_PATH, { saved_version_id: 'saved-1' });
    assert.equal(res.status, 200, res.raw, 'a legacy-vs-hydrated equivalent row must not read as a scenario change');
  });

  // HIGH: the MISSING direction of the test above. There the
  // SAVED side was already 4-key (frozen through the hydrated builder), so it
  // passed even without normalising the saved side. A snapshot frozen BEFORE the
  // hydration deploy holds the RAW legacy 3-key value, and the live reader now
  // hydrates — so saved(3-key) vs live(4-key) would false-409 unless BOTH sides
  // are normalised at the comparison. Default saved probe = snapshot of the raw
  // liveRows, i.e. the pre-deploy 3-key shape.
  it('a RAW legacy-3-key saved snapshot does not phantom-diff against the hydrated live read', async () => {
    armRestore();
    state.liveRows = {
      ...liveTables(),
      settings: [{
        id: 'set-1', scenario_id: 'scn-1', mem_cpu_ratio: 20,
        name_patterns: { hypervisor: 'hv-{dc}-{seq:2}', kvm_host: 'kvm-{dc}-{seq:2}', ap_vm: 'ap-{seq:2}' },
      }],
    };
    // savedVersionRows left DEFAULT → the saved snapshot is JSON.stringify of the
    // raw liveRows above, i.e. the legacy 3-key shape a pre-deploy freeze holds.
    const res = await request('POST', RESTORE_PATH, { saved_version_id: 'saved-1' });
    assert.equal(res.status, 200, res.raw, 'a raw 3-key saved snapshot must not read as a scenario change');
    assert.notEqual(res.json.error && res.json.error.code, 'SCENARIO_CHANGED');
  });

  it('a saved snapshot whose name_patterns is a JSON STRING (driver-era) does not phantom-diff', async () => {
    armRestore();
    state.liveRows = {
      ...liveTables(),
      settings: [{
        id: 'set-1', scenario_id: 'scn-1', mem_cpu_ratio: 20,
        // Driver era that returned JSON columns as text: the cell is a string on
        // both the live read and inside the frozen snapshot (JSON.stringify keeps
        // it a string). normalizeSettingsForFingerprint must JSON.parse then
        // hydrate both to the same 4-key shape.
        name_patterns: '{"hypervisor":"hv-{dc}","kvm_host":"kvm-{dc}","ap_vm":"ap-{seq}"}',
      }],
    };
    const res = await request('POST', RESTORE_PATH, { saved_version_id: 'saved-1' });
    assert.equal(res.status, 200, res.raw, 'a string-stored name_patterns must not read as a scenario change');
    assert.notEqual(res.json.error && res.json.error.code, 'SCENARIO_CHANGED');
  });

  it('row order and key order are not treated as a change', async () => {
    armRestore();
    state.liveRows = {
      vms: [
        { id: 'vm-a', scenario_id: 'scn-1', name: 'A' },
        { id: 'vm-b', scenario_id: 'scn-1', name: 'B' },
      ],
    };
    state.savedVersionRows = [{
      id: 'saved-1',
      snapshot: JSON.stringify({
        schema_rev: SNAPSHOT_SCHEMA_REV,
        tables: {
          // Reversed rows, reversed keys within a row, and the fourteen table
          // keys the live read always returns are absent — the snapshot reads
          // carry no ORDER BY, so none of that is evidence of a change.
          vms: [
            { name: 'B', scenario_id: 'scn-1', id: 'vm-b' },
            { name: 'A', scenario_id: 'scn-1', id: 'vm-a' },
          ],
        },
      }),
    }];
    const res = await request('POST', RESTORE_PATH, { saved_version_id: 'saved-1' });
    assert.equal(res.status, 200, res.raw);
  });

  it('a saved version whose snapshot cannot be read is refused, not waved through', async () => {
    armRestore();
    state.savedVersionRows = [{ id: 'saved-1', snapshot: 'not json' }];
    const res = await request('POST', RESTORE_PATH, { saved_version_id: 'saved-1' });
    assert.equal(res.status, 409, res.raw);
    assert.equal(res.json.error.code, 'SCENARIO_CHANGED');
    assert.equal(state.queries.some((q) => /^DELETE FROM/.test(q.sql)), false);
  });

  it('reads the live rows only for the freshness check, and only when a save is claimed', async () => {
    armRestore();
    await request('POST', RESTORE_PATH, { saved_version_id: 'saved-1' });
    const liveReads = state.queries.filter((q) => /^SELECT \* FROM `fmb_cap_[a-z_]+` WHERE scenario_id = \?\s*$/.test(q.sql));
    assert.equal(liveReads.length, SNAPSHOT_TABLES.length, 'one read per scenario-scoped table');
    const firstRead = firstIndex(/^SELECT \* FROM `fmb_cap_[a-z_]+` WHERE scenario_id = \?\s*$/);
    const firstDelete = firstIndex(/^DELETE FROM/);
    assert.ok(firstRead < firstDelete, 'the state being destroyed is fingerprinted before it is destroyed');
  });

  it('a saved_version_id from another scenario is a 404 and nothing is deleted', async () => {
    armRestore();
    state.savedVersionRows = [];
    const res = await request('POST', RESTORE_PATH, { saved_version_id: 'not-mine' });
    assert.equal(res.status, 404, res.raw);
    assert.equal(state.queries.some((q) => /^DELETE FROM/.test(q.sql)), false, 'the check fires before the delete');
    assert.equal(state.rolledBack, true);
    assert.equal(state.committed, false);
  });

  it('naming the version being restored as the saved state is a 400', async () => {
    armRestore();
    const res = await request('POST', RESTORE_PATH, { saved_version_id: 'v1' });
    assert.equal(res.status, 400, res.raw);
    assert.equal(state.queries.some((q) => /^DELETE FROM/.test(q.sql)), false);
  });

  it('a non-string saved_version_id is a 400 before any query runs', async () => {
    armRestore();
    const res = await request('POST', RESTORE_PATH, { saved_version_id: { id: 'x' } });
    assert.equal(res.status, 400, res.raw);
    assert.equal(state.queries.length, 0);
  });

  it('an omitted saved_version_id means "not saved", with no probe query', async () => {
    armRestore();
    const res = await request('POST', RESTORE_PATH);
    assert.equal(res.status, 200, res.raw);
    assert.equal(res.json.data.prior_state_saved, false);
  });
});

// ── Blast radius ─────────────────────────────────────────────────────────────

describe('capacity version restore — blast radius', () => {
  it('deletes every scenario-scoped table, child-before-parent, always scoped by scenario_id', async () => {
    armRestore();
    await request('POST', RESTORE_PATH);
    const deletes = state.queries.filter((q) => /^DELETE FROM `fmb_cap_/.test(q.sql));
    assert.equal(deletes.length, SNAPSHOT_TABLES.length);
    for (const d of deletes) {
      assert.match(d.sql, /WHERE scenario_id = \?$/, 'a restore delete is always scenario-scoped');
      assert.deepEqual(d.params, ['scn-1']);
    }
    const order = deletes.map((d) => d.sql.match(/`fmb_(cap_[a-z_]+)`/)[1]);
    const expected = [...SNAPSHOT_TABLES].reverse().map(({ table }) => String(table));
    assert.deepEqual(order, expected, 'children are deleted before their parents');
  });

  it('never deletes version history, global config rows, or bundles', async () => {
    armRestore();
    await request('POST', RESTORE_PATH);
    assert.equal(deletesFrom('cap_versions').length, 0, 'restore must not prune version history');
    assert.equal(deletesFrom('cap_scenarios').length, 0, 'the scenario row itself survives');
    assert.equal(deletesFrom('cap_bundles').length, 0);
    assert.equal(deletesFrom('cap_bundle_items').length, 0);
    assert.equal(
      state.queries.some((q) => /^DELETE FROM/.test(q.sql) && /scenario_id IS NULL/.test(q.sql)),
      false,
      'the global config layer is never touched',
    );
  });

  it('never writes bundles (a restore only replays what the snapshot captured)', async () => {
    armRestore();
    await request('POST', RESTORE_PATH);
    assert.equal(insertsInto('cap_bundles').length, 0);
    assert.equal(insertsInto('cap_bundle_items').length, 0);
  });

  it('does not reincarnate the snapshot global layer as scenario-local rows', async () => {
    armRestore();
    await request('POST', RESTORE_PATH);
    const settings = insertsInto('cap_settings').map(colsOf);
    const rules = insertsInto('cap_rules').map(colsOf);
    assert.deepEqual(settings.map((r) => r.id), ['set-1']);
    assert.deepEqual(rules.map((r) => r.id), ['rule-1']);
    for (const row of [...settings, ...rules]) {
      assert.equal(row.scenario_id, 'scn-1', 'every restored row is bound to the target scenario');
    }
  });

  it('writes one audit entry naming the version, the actor role, and whether the state was kept', async () => {
    armRestore();
    currentUser = { id: 'u-ed', role: 'editor' };
    await request('POST', RESTORE_PATH, { saved_version_id: 'saved-1' });
    const audits = insertsInto('feature_audit');
    assert.equal(audits.length, 1);
    const row = colsOf(audits[0]);
    assert.equal(row.event_type, 'cap_scenario.version.restore', 'the same event shape, with fields added');
    assert.equal(row.user_id, 'u-ed');
    const meta = JSON.parse(row.metadata);
    assert.equal(meta.scenario_id, 'scn-1');
    assert.equal(meta.version_id, 'v1');
    assert.equal(meta.prior_state_saved, true);
    assert.equal(meta.saved_version_id, 'saved-1');
    assert.equal(meta.actor_role, 'editor');
    assert.equal(typeof meta.restored_counts, 'object');
  });

  it('records a switch that kept nothing as exactly that', async () => {
    armRestore();
    await request('POST', RESTORE_PATH);
    const meta = JSON.parse(colsOf(insertsInto('feature_audit')[0]).metadata);
    assert.equal(meta.prior_state_saved, false);
    assert.equal(meta.saved_version_id, null);
  });

  it('records an admin restore under the admin role', async () => {
    armRestore();
    currentUser = { id: 'u-admin', role: 'admin' };
    await request('POST', RESTORE_PATH);
    const meta = JSON.parse(colsOf(insertsInto('feature_audit')[0]).metadata);
    assert.equal(meta.actor_role, 'admin');
  });
});

// ── Role gates ───────────────────────────────────────────────────────────────

describe('capacity version restore — role gates', () => {
  it('a plain user is refused (403) and nothing is read or written', async () => {
    armRestore();
    currentUser = { id: 'u-user', role: 'user' };
    const res = await request('POST', RESTORE_PATH);
    assert.equal(res.status, 403, res.raw);
    assert.equal(state.queries.length, 0);
  });

  it('an editor who does not own the scenario is refused (403); nothing is deleted', async () => {
    armRestore();
    state.scenarioOwnerRows = [{ id: 'scn-1', owner_id: 'someone-else' }];
    currentUser = { id: 'u-ed', role: 'editor' };
    const res = await request('POST', RESTORE_PATH);
    assert.equal(res.status, 403, res.raw);
    assert.equal(state.queries.some((q) => /^DELETE FROM/.test(q.sql)), false);
    assert.equal(state.rolledBack, true);
  });

  it('the owning editor may restore', async () => {
    armRestore();
    state.scenarioOwnerRows = [{ id: 'scn-1', owner_id: 'u-ed' }];
    currentUser = { id: 'u-ed', role: 'editor' };
    const res = await request('POST', RESTORE_PATH);
    assert.equal(res.status, 200, res.raw);
  });

  it('an admin may restore a scenario owned by someone else', async () => {
    armRestore();
    state.scenarioOwnerRows = [{ id: 'scn-1', owner_id: 'someone-else' }];
    currentUser = { id: 'u-admin', role: 'admin' };
    const res = await request('POST', RESTORE_PATH);
    assert.equal(res.status, 200, res.raw);
  });

  it('a missing scenario → 404', async () => {
    armRestore();
    state.scenarioOwnerRows = [];
    const res = await request('POST', RESTORE_PATH);
    assert.equal(res.status, 404, res.raw);
    assert.equal(state.queries.some((q) => /^DELETE FROM/.test(q.sql)), false);
  });

  it('a version belonging to another scenario → 404', async () => {
    armRestore();
    state.versionRow = [];
    const res = await request('POST', RESTORE_PATH);
    assert.equal(res.status, 404, res.raw);
    assert.equal(state.queries.some((q) => /^DELETE FROM/.test(q.sql)), false);
  });
});

// ── Fail-closed guards (every one must fire BEFORE the first delete) ──────────

describe('capacity version restore — fail-closed guards', () => {
  const assertUntouched = (res, status = 409) => {
    assert.equal(res.status, status, res.raw);
    assert.equal(state.queries.some((q) => /^DELETE FROM/.test(q.sql)), false, 'nothing may be deleted');
    assert.equal(insertsInto('cap_versions').length, 0, 'a restore never writes a version row at all');
    assert.equal(state.committed, false);
    assert.equal(state.rolledBack, true);
  };

  it('an older schema_rev is a hard 409 that points at clone-to-new-scenario', async () => {
    armRestore();
    state.versionRow = [{ id: 'v1', scenario_id: 'scn-1', name: 'Old', snapshot: JSON.stringify({ schema_rev: 0, tables: frozenTables() }) }];
    const res = await request('POST', RESTORE_PATH);
    assertUntouched(res);
    assert.equal(res.json.error.code, 'CONFLICT');
    assert.match(res.json.error.message, /schema_rev/);
    assert.match(res.json.error.message, /clone/i, 'the operator needs the alternative spelled out');
  });

  it('a newer schema_rev is refused the same way', async () => {
    armRestore();
    state.versionRow = [{ id: 'v1', scenario_id: 'scn-1', name: 'Future', snapshot: JSON.stringify({ schema_rev: SNAPSHOT_SCHEMA_REV + 1, tables: frozenTables() }) }];
    assertUntouched(await request('POST', RESTORE_PATH));
  });

  it('a snapshot with no schema_rev is refused (an unknown shape is never replayed)', async () => {
    armRestore();
    state.versionRow = [{ id: 'v1', scenario_id: 'scn-1', name: 'Legacy', snapshot: JSON.stringify({ tables: frozenTables() }) }];
    assertUntouched(await request('POST', RESTORE_PATH));
  });

  it('an unparseable snapshot is refused (it must never empty the scenario)', async () => {
    armRestore();
    state.versionRow = [{ id: 'v1', scenario_id: 'scn-1', name: 'Corrupt', snapshot: '{not json' }];
    assertUntouched(await request('POST', RESTORE_PATH));
  });

  it('a snapshot with no tables document is refused', async () => {
    armRestore();
    state.versionRow = [{ id: 'v1', scenario_id: 'scn-1', name: 'Empty', snapshot: JSON.stringify({ schema_rev: SNAPSHOT_SCHEMA_REV }) }];
    assertUntouched(await request('POST', RESTORE_PATH));
  });

  it('a snapshot missing a table key is refused, naming the tables it would erase', async () => {
    // The trap this guards: the DELETE clears every scenario-scoped table while
    // the replay only re-inserts the keys the document carries, so a freeze cut
    // before a table joined the snapshot set would wipe it. schema_rev cannot
    // catch that shape (the table set grew without a rev bump).
    const tables = frozenTables();
    delete tables.databases;
    tables.custom_groups = null;
    armRestore(tables);
    const res = await request('POST', RESTORE_PATH);
    assertUntouched(res);
    assert.equal(res.json.error.code, 'CONFLICT');
    assert.match(res.json.error.message, /databases/);
    assert.match(res.json.error.message, /custom_groups/);
    assert.match(res.json.error.message, /clone/i, 'the operator needs the non-destructive way out');
  });

  it('an EMPTY table key restores (an empty table is not a missing one)', async () => {
    const tables = frozenTables();
    tables.waivers = [];
    tables.custom_group_members = [];
    armRestore(tables);
    const res = await request('POST', RESTORE_PATH);
    assert.equal(res.status, 200, res.raw);
    assert.equal(state.committed, true);
    assert.equal(insertsInto('cap_waivers').length, 0, 'an empty list replays nothing');
    assert.ok(deletesFrom('cap_waivers').length > 0, 'an empty list still clears the live rows');
  });

  it('a scenario-local row with no id is refused', async () => {
    const tables = frozenTables();
    tables.vms = [{ scenario_id: 'scn-1', name: 'no-id' }];
    armRestore(tables);
    assertUntouched(await request('POST', RESTORE_PATH));
  });

  it('a table entry that is not a row list is refused', async () => {
    const tables = frozenTables();
    tables.sites = { id: 'not-a-list' };
    armRestore(tables);
    assertUntouched(await request('POST', RESTORE_PATH));
  });

  it('a row key that is not a plain identifier is refused (no backtick can reach the INSERT)', async () => {
    const tables = frozenTables();
    tables.sites = [{ id: 'site-1', scenario_id: 'scn-1', 'name`, (SELECT 1)) -- ': 'x' }];
    armRestore(tables);
    assertUntouched(await request('POST', RESTORE_PATH));
  });
});

// ── Transactional integrity ──────────────────────────────────────────────────

describe('capacity version restore — transaction', () => {
  it('rolls back and never commits when a replay INSERT fails mid-flight', async () => {
    armRestore();
    state.failOnSql = { pattern: '^INSERT INTO `fmb_cap_vms`' };
    const res = await request('POST', RESTORE_PATH);
    assert.equal(res.status, 500, res.raw);
    assert.equal(state.committed, false);
    assert.equal(state.rolledBack, true);
    // The rows written before the failure are inside the same transaction, so
    // the rollback is what makes the delete-then-insert atomic.
    assert.ok(insertsInto('cap_sites').length > 0, 'the failure happened mid-replay');
  });

  it('rolls back when a delete fails', async () => {
    armRestore();
    state.failOnSql = { pattern: '^DELETE FROM `fmb_cap_waivers`' };
    const res = await request('POST', RESTORE_PATH);
    assert.equal(res.status, 500, res.raw);
    assert.equal(state.committed, false);
    assert.equal(state.rolledBack, true);
  });

  it('maps a duplicate-id replay failure to 409, not a bare 500', async () => {
    armRestore();
    state.failOnSql = { pattern: '^INSERT INTO `fmb_cap_sites`', errno: 1062 };
    const res = await request('POST', RESTORE_PATH);
    assert.equal(res.status, 409, res.raw);
    assert.equal(state.rolledBack, true);
    assert.equal(state.committed, false);
    // The 409 responder never emits its own app-error line, so the branch's
    // own req.log.error call must be the only one.
    assert.equal(state.errorLogCalls.length, 1, 'exactly one error line for the 409 branch');
  });

  it('logs the generic-failure app-error line exactly once, not once from the route and once from sendError', async () => {
    armRestore();
    state.failOnSql = { pattern: '^INSERT INTO `fmb_cap_vms`' };
    const res = await request('POST', RESTORE_PATH);
    assert.equal(res.status, 500, res.raw);
    assert.equal(state.errorLogCalls.length, 1, 'sendError alone should log this failure');
  });

  it('maps a dropped-column replay failure to 409 with the clone alternative', async () => {
    armRestore();
    state.failOnSql = { pattern: '^INSERT INTO `fmb_cap_sites`', errno: 1054 };
    const res = await request('POST', RESTORE_PATH);
    assert.equal(res.status, 409, res.raw);
    assert.match(res.json.error.message, /clone/i);
  });

  it('leaves the version row itself untouched (a version is immutable)', async () => {
    armRestore();
    await request('POST', RESTORE_PATH);
    assert.equal(state.queries.some((q) => /^UPDATE `fmb_cap_versions`/.test(q.sql)), false);
    assert.equal(deletesFrom('cap_versions').length, 0);
  });
});

// ── item 7: restoring a version frozen before the whole-number rule ──
//
// Restore is a REPLAY. A version frozen by an earlier release can hold
// primary_sga_gb = 96.5, and the rule this release adds is enforced where a
// value is TYPED and applied where a value is READ — not by rewriting a frozen
// document. So the round trip has to stay possible: the restore must not refuse
// the snapshot, and must not quietly "correct" the operator's own history
// either. What the operator SEES stays whole because every read floors.
describe('capacity version restore — a snapshot that predates the whole-number rule', () => {
  function legacyTables() {
    const tables = frozenTables();
    tables.databases = [{ ...tables.databases[0], primary_sga_gb: 96.5, standby_sga_gb: 48.25 }];
    tables.db_instances = [{ ...tables.db_instances[0], sga_gb: 96.5 }];
    tables.vm_profiles = [{ ...tables.vm_profiles[0], mode: 'custom', mem_gb: 61.5, sga_cap_gb: 27.9 }];
    return tables;
  }

  it('restores it instead of refusing it, and replays the fractions verbatim', async () => {
    armRestore(legacyTables());
    const res = await request('POST', RESTORE_PATH);
    assert.equal(res.status, 200, res.raw);
    assert.equal(state.committed, true);

    const db = colsOf(insertsInto('cap_databases')[0]);
    assert.equal(db.primary_sga_gb, 96.5, 'a replay carries the frozen number, it does not edit it');
    assert.equal(db.standby_sga_gb, 48.25);
    assert.equal(colsOf(insertsInto('cap_db_instances')[0]).sga_gb, 96.5);
    const prof = colsOf(insertsInto('cap_vm_profiles')[0]);
    assert.equal(prof.mem_gb, 61.5);
    assert.equal(prof.sga_cap_gb, 27.9);
  });

  it('the restored scenario can be restored again — the state it lands in is not a trap', async () => {
    // The second pass reads the SAME frozen document: whatever the first restore
    // wrote, nothing about the round trip degrades or blocks on a repeat.
    armRestore(legacyTables());
    assert.equal((await request('POST', RESTORE_PATH)).status, 200);
    const firstPass = colsOf(insertsInto('cap_databases')[0]);
    state = freshState();
    armRestore(legacyTables());
    assert.equal((await request('POST', RESTORE_PATH)).status, 200);
    assert.deepEqual(colsOf(insertsInto('cap_databases')[0]), firstPass, 'the replay is idempotent');
  });
});
