'use strict';

/**
 * people-assignable-schema-parity.test.js — the two directory SELECTs that
 * gained a column under spec §8.2 (`/people` gains role, `users/assignable`
 * gains kc_username), checked against the ACTUAL DDL, without a live
 * database. The node:test mocks stub query results, so a wrong/renamed
 * column stays green in both runners yet 500s in production — the same gap
 * capacity-delete-preview-schema-parity.test.js closes for a different
 * route family.
 */
const { describe, it, before } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const { buildAllTableDDLs } = require('../../../../src/table-ddls');
const { TABLES } = require('../../../../src/shared/constants');

const SQL_TYPES = /^`?([a-z_]+)`?\s+(?:CHAR|VARCHAR|INT|DOUBLE|TIMESTAMP|JSON|TEXT|ENUM|BOOLEAN|TINYINT|BIGINT|DATETIME|DECIMAL|FLOAT|BLOB)\b/i;

let usersColumns;

before(() => {
  usersColumns = new Set();
  // fmb_users is an INFRA table (auth identity), so buildAllTableDDLs is used
  // rather than buildEngineTableDDLs — same reasoning as
  // users-list-schema-parity.test.js.
  for (const ddl of buildAllTableDDLs((n) => n)) {
    const m = ddl.match(/CREATE TABLE IF NOT EXISTS `([^`]+)`/);
    if (!m || m[1] !== String(TABLES.USERS)) continue;
    for (const rawLine of ddl.split('\n')) {
      const line = rawLine.trim();
      if (!line || line.startsWith('--') || line.startsWith('/*')) continue;
      const cm = line.match(SQL_TYPES);
      if (cm) usersColumns.add(cm[1]);
    }
  }
});

describe('fmb_users — declares every column both directory endpoints read', () => {
  it('parses a non-empty column set for fmb_users', () => {
    assert.ok(usersColumns.size > 0, 'no columns parsed for the users table');
  });

  it('declares id, display_name, kc_username, role, banned', () => {
    for (const col of ['id', 'display_name', 'kc_username', 'role', 'banned']) {
      assert.ok(usersColumns.has(col), `fmb_users has no column '${col}'`);
    }
  });
});

// Read the SELECTs out of the two route sources rather than hand-copying
// them, so a rename in either fails here instead of only against a real
// database.
function selectColumns(sourcePath, statementPattern) {
  const text = fs.readFileSync(path.resolve(__dirname, sourcePath), 'utf8');
  const m = text.match(statementPattern);
  assert.ok(m, `${sourcePath} — the SELECT this test expects is no longer there`);
  return m[1].split(',').map((c) => c.trim());
}

describe('GET /people (delegated-grants.js) — gained role', () => {
  const cols = selectColumns(
    '../../../../src/edge/routes/app/delegated-grants.js',
    /SELECT\s+([\w,\s]+?)\s+FROM\s+\\`\$\{t\(TABLES\.USERS\)\}\\`\s*\n\s*\$\{where\}/,
  );

  it('names id, display_name, kc_username, role', () => {
    assert.deepEqual(cols.sort(), ['display_name', 'id', 'kc_username', 'role']);
  });

  it('every named column exists on fmb_users', () => {
    for (const col of cols) {
      assert.ok(usersColumns.has(col), `/people selects '${col}', which fmb_users does not declare`);
    }
  });
});

describe('GET /assignable (users.js) — gained kc_username', () => {
  const cols = selectColumns(
    '../../../../src/edge/routes/platform/users.js',
    /SELECT\s+([\w,\s]+?)\s+FROM\s+\\`\$\{t\(TABLES\.USERS\)\}\\`\s*\n\s*WHERE banned = 0/,
  );

  it('names id, display_name, role, kc_username', () => {
    assert.deepEqual(cols.sort(), ['display_name', 'id', 'kc_username', 'role']);
  });

  it('every named column exists on fmb_users', () => {
    for (const col of cols) {
      assert.ok(usersColumns.has(col), `/assignable selects '${col}', which fmb_users does not declare`);
    }
  });
});
