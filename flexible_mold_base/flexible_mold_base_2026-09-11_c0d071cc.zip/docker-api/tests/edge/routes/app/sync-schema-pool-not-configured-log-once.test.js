'use strict';

/**
 * sync-schema-pool-not-configured-log-once.test.js — logging epic PR-Z2
 * (fmb-2108): a PoolNotConfiguredError must log EXACTLY ONE error/kind:app
 * line per response, never two. Before this fix, 5 of the 11
 * `maybeHandlePoolNotConfigured` call sites in sync-schema.js carried their
 * own bespoke `req.log.error(...)` line ABOVE the helper check, which fired
 * unconditionally — so a genuine pool-not-configured condition (which the
 * helper's own `sendError(..., { status: 503 })` call already logs, since
 * 503 >= 500) logged twice. The fix moves the bespoke line to AFTER the
 * `maybeHandlePoolNotConfigured` check so it only covers every OTHER cause
 * — the single mechanism is "log after the check, never before", applied
 * uniformly across all 11 sites (the other 6 never had a pre-log to begin
 * with).
 *
 * Real pino child logger as req.log (captured sync destination, same
 * pattern as sync-schema-summary-log.test.js) so the assertion sees the
 * actual serialised record, not a mock's own accounting.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');
const { Writable } = require('node:stream');
const pino = require('pino');
const { _internals } = require('../../../../src/shared/lib/logger');
const { PoolNotConfiguredError } = require('../../../../src/shared/lib/db-errors');

const dbKey = require.resolve('../../../../src/edge/db');
const routeKey = require.resolve('../../../../src/edge/routes/app/sync-schema');

const poolSpy = {};

require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: {
    pool: poolSpy,
    t: (name) => `fmb_${name}`,
    getDbConfigFull: () => ({ tablePrefix: 'fmb_' }),
    getDynamicPool: async () => poolSpy,
  },
};

const router = require('../../../../src/edge/routes/app/sync-schema');

let server;
let port;
let records;
let base;

function makeCaptureLog() {
  const sink = new Writable({
    write(chunk, _e, cb) {
      for (const line of chunk.toString().split('\n')) {
        if (line.trim()) records.push(JSON.parse(line));
      }
      cb();
    },
  });
  return pino(_internals.loggerOptions, sink);
}

before(async () => {
  base = makeCaptureLog();
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { req.user = { id: 'admin', role: 'admin' }; next(); });
  app.use((req, _res, next) => { req.log = base.child({ req_id: 'pnc00001' }); next(); });
  app.use('/edge/app/sync-schema', router);
  await new Promise((resolve) => {
    server = app.listen(0, '127.0.0.1', () => { port = server.address().port; resolve(); });
  });
});

after(async () => {
  await new Promise((resolve) => server.close(resolve));
  delete require.cache[dbKey];
  delete require.cache[routeKey];
});

beforeEach(() => {
  records = [];
  poolSpy.ro = { async getConnection() { throw new PoolNotConfiguredError('test'); } };
  poolSpy.rw = { async getConnection() { throw new PoolNotConfiguredError('test'); } };
});

function getJson(path_) {
  return new Promise((resolve, reject) => {
    const req = http.request(
      { host: '127.0.0.1', port, path: path_, method: 'GET' },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => resolve({ status: res.statusCode, body: Buffer.concat(chunks).toString() }));
      },
    );
    req.on('error', reject);
    req.end();
  });
}

// Minimal valid body per POST site — just enough to pass the route's own
// pre-pool validation (admin auth is already granted by the fixed `req.user`
// middleware above) so the handler actually reaches the pool-connection call
// and hits the mocked PoolNotConfiguredError.
function postJson(path_, body) {
  const payload = JSON.stringify(body);
  return new Promise((resolve, reject) => {
    const req = http.request(
      {
        host: '127.0.0.1', port, path: path_, method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) },
      },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => resolve({ status: res.statusCode, body: Buffer.concat(chunks).toString() }));
      },
    );
    req.on('error', reject);
    req.end(payload);
  });
}

// One row per site that USED TO carry a bespoke pre-log above the
// maybeHandlePoolNotConfigured check (the "5 of 11" this card fixes).
const SITES = [
  { name: 'GET /status', path: '/edge/app/sync-schema/status' },
  { name: 'GET /export-sql', path: '/edge/app/sync-schema/export-sql' },
  { name: 'POST /import-sql', path: '/edge/app/sync-schema/import-sql', body: { sql: 'INSERT INTO x VALUES (1)' } },
  { name: 'POST /truncate-table', path: '/edge/app/sync-schema/truncate-table', body: { table: 'hierarchy_nodes' } },
  { name: 'POST /drop-table', path: '/edge/app/sync-schema/drop-table', body: { table: 'hierarchy_nodes' } },
];

describe('sync-schema PoolNotConfiguredError — exactly one app-error line (fmb-2108)', () => {
  for (const site of SITES) {
    it(`${site.name}: a PoolNotConfiguredError logs exactly one error/kind:app line, not two`, async () => {
      const res = site.body ? await postJson(site.path, site.body) : await getJson(site.path);
      assert.equal(res.status, 503);
      const appErrorLines = records.filter((r) => r.level === 'error' && r.kind === 'app');
      assert.equal(
        appErrorLines.length, 1,
        `expected exactly one error/kind:app line, got ${appErrorLines.length}: ${JSON.stringify(appErrorLines)}`,
      );
      assert.equal(appErrorLines[0].code, 'POOL_NOT_CONFIGURED');
    });
  }
});
