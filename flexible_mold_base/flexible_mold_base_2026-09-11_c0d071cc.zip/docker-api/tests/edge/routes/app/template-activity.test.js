'use strict';

/**
 * template-activity.test.js — the trail: who may see it, what is written into
 * it, and what happens when writing one fails.
 *
 * THE PROPERTY THIS FILE EXISTS FOR, above all the others: a failure to record
 * must never fail the action being recorded. It is asserted by making the trail
 * write throw and then checking that the action still reports success — and by
 * checking the drop is LOGGED, because a swallowed audit failure that leaves no
 * trace is the defect this design set out not to repeat.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../../../src/edge/db');

let queries;
let activityTablePresent;
let grantsTablePresent;
let templateRow;      // the record the trail belongs to, or null
let grantRows;        // what the grant lookup finds
let activityRows;     // what the trail read returns
let peopleRows;       // what the users lookup finds for the actors on those rows
let totalCount;
let activityInsertError;
let activityListError;

function makeConn() {
  return {
    async query(sql, params = []) {
      queries.push({ sql, params });
      if (/information_schema\.TABLES/i.test(sql)) {
        const [name] = params;
        if (String(name).endsWith('template_activity')) return activityTablePresent ? [{ 1: 1 }] : [];
        if (String(name).endsWith('delegated_grants')) return grantsTablePresent ? [{ 1: 1 }] : [];
        return [];
      }
      if (/^INSERT INTO `fmb_template_activity`/.test(sql)) {
        if (activityInsertError) throw activityInsertError;
        return { affectedRows: 1 };
      }
      if (/FROM `fmb_user_templates`/.test(sql)) return templateRow ? [templateRow] : [];
      if (/FROM `fmb_delegated_grants`/.test(sql)) return grantRows;
      if (/COUNT\(\*\) AS cnt/.test(sql)) return [{ cnt: totalCount }];
      if (/FROM `fmb_template_activity`/.test(sql) && /LIMIT/.test(sql)) {
        if (activityListError) throw activityListError;
        return activityRows;
      }
      if (/FROM `fmb_template_activity`/.test(sql)) return activityRows;
      if (/FROM `fmb_users`/.test(sql)) return peopleRows;
      return [];
    },
    release() {},
  };
}

const poolFacade = { async getConnection() { return makeConn(); } };

require.cache[dbKey] = {
  id: dbKey,
  filename: dbKey,
  loaded: true,
  exports: {
    pool: { ro: poolFacade, rw: poolFacade },
    t: (n) => `fmb_${n}`,
    getDynamicPool: async () => ({ ro: poolFacade, rw: poolFacade }),
  },
};

const router = require('../../../../src/edge/routes/app/template-activity');
const {
  recordTemplateActivity, ACTIVITY_ACTIONS, _resetActivityTableCache,
} = require('../../../../src/edge/lib/template-activity');
const { _resetGrantsTableCache } = require('../../../../src/edge/lib/delegated-grants');

const OWNER = { id: '11111111-1111-1111-1111-111111111111', role: 'user' };
const GRANTEE = { id: '22222222-2222-2222-2222-222222222222', role: 'user' };
const STRANGER = { id: '33333333-3333-3333-3333-333333333333', role: 'user' };
const ADMIN = { id: '44444444-4444-4444-4444-444444444444', role: 'admin' };
const TEMPLATE = 'bbbbbbbb-0000-0000-0000-00000000000b';

let currentUser;
let server;
let baseUrl;

before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { if (currentUser) req.user = currentUser; next(); });
  app.use('/edge/app/template-activity', router);
  server = http.createServer(app);
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});

after(async () => { await new Promise((r) => server.close(r)); });

beforeEach(() => {
  queries = [];
  activityTablePresent = true;
  grantsTablePresent = true;
  templateRow = { id: TEMPLATE, owner_id: OWNER.id, blueprint_id: 'bp-1' };
  grantRows = [];
  activityRows = [];
  peopleRows = [];
  totalCount = 0;
  activityListError = null;
  activityInsertError = null;
  currentUser = OWNER;
  _resetActivityTableCache();
  _resetGrantsTableCache();
});

async function call(method, path, body) {
  const res = await fetch(`${baseUrl}/edge/app/template-activity${path}`, {
    method,
    headers: { 'content-type': 'application/json' },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const json = await res.json().catch(() => ({}));
  return { status: res.status, json };
}

const row = (over = {}) => ({
  id: 'a1',
  template_id: TEMPLATE,
  actor_id: GRANTEE.id,
  action: 'content.edited',
  metadata: null,
  created_at: new Date('2026-07-01T09:00:00Z'),
  ...over,
});

describe('who may see a record\'s trail', () => {
  it('its owner may', async () => {
    const res = await call('GET', `/${TEMPLATE}`);
    assert.equal(res.status, 200);
  });

  it('an administrator may', async () => {
    currentUser = ADMIN;
    const res = await call('GET', `/${TEMPLATE}`);
    assert.equal(res.status, 200);
  });

  it('someone the owner delegated to may', async () => {
    // R-3-P1: a grant is honoured only for an editor/admin grantee.
    currentUser = { ...GRANTEE, role: 'editor' };
    grantRows = [{ granted: 1 }];
    const res = await call('GET', `/${TEMPLATE}`);
    assert.equal(res.status, 200);
  });

  it('R-3-P1: the SAME grant row is not honoured once the grantee is a plain user', async () => {
    currentUser = GRANTEE; // role: 'user'
    grantRows = [{ granted: 1 }];
    const res = await call('GET', `/${TEMPLATE}`);
    assert.equal(res.status, 404);
  });

  it('everyone else is answered as though the record were not there', async () => {
    // Narrower than reading the record itself, which every authenticated caller
    // may do. The trail is who has been working on it, which is the owner's
    // business and their delegates'.
    currentUser = STRANGER;
    const res = await call('GET', `/${TEMPLATE}`);
    assert.equal(res.status, 404);
  });

  it('a record that does not exist is the same answer', async () => {
    templateRow = null;
    const res = await call('GET', `/${TEMPLATE}`);
    assert.equal(res.status, 404);
  });

  it('an anonymous caller reaches no statement at all', async () => {
    currentUser = null;
    const res = await call('GET', `/${TEMPLATE}`);
    assert.equal(res.status, 401);
    assert.equal(queries.length, 0);
  });
});

describe('the page it returns', () => {
  it('is bounded even when nobody asked for a page', async () => {
    await call('GET', `/${TEMPLATE}`);
    const read = queries.find((q) => /FROM `fmb_template_activity`/.test(q.sql) && /LIMIT/.test(q.sql));
    assert.ok(read, 'no bounded read was issued');
    assert.deepEqual(read.params, [TEMPLATE, 25, 0]);
  });

  it('counts under the same record filter as the rows', async () => {
    activityRows = [row()];
    totalCount = 3;
    const res = await call('GET', `/${TEMPLATE}`);
    const count = queries.find((q) => /COUNT\(\*\) AS cnt/.test(q.sql));
    assert.deepEqual(count.params, [TEMPLATE]);
    assert.equal(res.json.data.total, 3);
  });

  it('summarises the newest entry on the first page', async () => {
    activityRows = [row({ action: 'flow.dispatched' })];
    totalCount = 5;
    const res = await call('GET', `/${TEMPLATE}`);
    assert.equal(res.json.data.summary.last_action, 'flow.dispatched');
    assert.equal(res.json.data.summary.total, 5);
  });

  it('summarises nothing on a later page, where the newest row in view is not the newest', async () => {
    activityRows = [row()];
    totalCount = 40;
    const res = await call('GET', `/${TEMPLATE}?limit=25&offset=25`);
    assert.equal(res.json.data.summary, null);
  });

  it('refuses a malformed page rather than serving a different one', async () => {
    const res = await call('GET', `/${TEMPLATE}?limit=25&offset=-1`);
    assert.equal(res.status, 400);
  });

  it('says when the account that acted has been deleted, rather than naming it', async () => {
    // The users lookup finds nothing for this id. The shared enrichment's
    // default for that is the WORD "Unknown", which a screen cannot tell from
    // somebody's display name — so the row rendered as an ordinary person with
    // a normal avatar. The row now carries the fact instead.
    activityRows = [row({ actor_id: 'u-deleted' })];
    totalCount = 1;
    const res = await call('GET', `/${TEMPLATE}`);
    const [entry] = res.json.data.rows;
    assert.equal(entry.actor_removed, true);
    assert.equal(entry.actor_name, '', 'a deleted account was given a name to render');
    assert.ok(!JSON.stringify(res.json).includes('Unknown'), 'the placeholder word reached the wire');
  });

  it('does not call a person removed when their account is simply nameless', async () => {
    peopleRows = [{ id: GRANTEE.id, display_name: null, kc_username: null }];
    activityRows = [row()];
    totalCount = 1;
    const res = await call('GET', `/${TEMPLATE}`);
    assert.equal(res.json.data.rows[0].actor_removed, false);
  });

  it('says a trail is NOT RECORDED here, which is not the same as empty', async () => {
    activityTablePresent = false;
    const res = await call('GET', `/${TEMPLATE}`);
    assert.equal(res.status, 200);
    assert.equal(res.json.data.available, false);
    assert.deepEqual(res.json.data.rows, []);
  });
});

describe('when the read fails', () => {
  it('the app-error line carries templateId — logging epic PR-Z2 (fmb-2108): dbError used to drop it', async () => {
    // A dedicated req.log.error({ err, templateId }, ...) sat directly above
    // the old two-step dbError(res) call; the logging epic's req-threaded
    // dbError(req, res, err) shim replaced it but, before PR-Z2, dropped the
    // templateId context that pre-log carried. The shim now takes a fourth
    // `fields` argument threaded into sendError's own `fields` opt.
    const { logger: rootLogger } = require('../../../../src/shared/lib/logger');
    const originalError = rootLogger.error;
    const captured = [];
    rootLogger.error = function capture(...args) {
      captured.push(args);
      return originalError.apply(this, args);
    };
    try {
      activityListError = Object.assign(new Error('connection reset'), { errno: 2013 });
      const res = await call('GET', `/${TEMPLATE}`);
      assert.equal(res.status, 500);
      assert.ok(
        captured.some((args) => args[0] && args[0].templateId === TEMPLATE),
        `no app-error line carried templateId=${TEMPLATE}; captured: ${JSON.stringify(captured.map((a) => a[0]))}`,
      );
    } finally {
      rootLogger.error = originalError;
    }
  });
});

describe('recording that output was produced', () => {
  it('is refused to someone who may not work on the record', async () => {
    // Producing output is not gated — it happens in the browser over data the
    // caller may already read. Appending to somebody's trail is, or the trail
    // would be a surface anyone could write to.
    currentUser = STRANGER;
    const res = await call('POST', `/${TEMPLATE}/generated`, { output_count: 2 });
    assert.equal(res.status, 404);
    assert.equal(queries.filter((q) => /^INSERT INTO `fmb_template_activity`/.test(q.sql)).length, 0);
  });

  it('records a count and nothing else the caller supplied', async () => {
    const res = await call('POST', `/${TEMPLATE}/generated`, {
      output_count: 2, actor_id: 'somebody-else', action: 'flow.dispatched', note: 'free text',
    });
    assert.equal(res.status, 200);
    assert.equal(res.json.data.recorded, true);
    const insert = queries.find((q) => /^INSERT INTO `fmb_template_activity`/.test(q.sql));
    const [, templateId, actorId, action, metadata] = insert.params;
    assert.equal(templateId, TEMPLATE);
    assert.equal(actorId, OWNER.id, 'the actor was read from the body rather than the session');
    assert.equal(action, 'output.generated', 'the caller chose the action');
    assert.deepEqual(JSON.parse(metadata), { output_count: 2 });
  });

  it('drops an out-of-range count rather than storing it', async () => {
    await call('POST', `/${TEMPLATE}/generated`, { output_count: -1 });
    const insert = queries.find((q) => /^INSERT INTO `fmb_template_activity`/.test(q.sql));
    assert.equal(insert.params[4], null);
  });

  it('answers 200 with recorded:false when the row could not be written', async () => {
    // The output is already on the operator's screen. A failure to record it
    // cannot be reported as a failure to produce it.
    activityInsertError = Object.assign(new Error('write failed'), { errno: 1146 });
    const res = await call('POST', `/${TEMPLATE}/generated`, { output_count: 1 });
    assert.equal(res.status, 200);
    assert.equal(res.json.data.recorded, false);
  });
});

describe('the writer itself', () => {
  it('refuses an action outside the closed vocabulary', async () => {
    const conn = makeConn();
    const wrote = await recordTemplateActivity(conn, {
      templateId: TEMPLATE, actorId: OWNER.id, action: 'something.else',
    });
    assert.equal(wrote, false);
    assert.equal(queries.filter((q) => /^INSERT/.test(q.sql)).length, 0);
  });

  it('reports a dropped row rather than raising it — and says so in the log', async () => {
    // "Best effort" means logged, not invisible: a trail with a hole in it has
    // to be something somebody can find out about.
    const warnings = [];
    const { logger: rootLogger } = require('../../../../src/shared/lib/logger');
    const child = rootLogger.child({ module: 'template-activity' });
    const originalWarn = Object.getPrototypeOf(child).warn;
    Object.getPrototypeOf(child).warn = function capture(...args) {
      warnings.push(args);
      return originalWarn.apply(this, args);
    };
    try {
      activityInsertError = Object.assign(new Error('gone'), { errno: 1146 });
      const conn = makeConn();
      const wrote = await recordTemplateActivity(conn, {
        templateId: TEMPLATE,
        actorId: OWNER.id,
        action: ACTIVITY_ACTIONS.CONTENT_EDITED,
      });
      assert.equal(wrote, false, 'the failure was reported as a success');
      assert.ok(
        warnings.some((w) => JSON.stringify(w).includes('template activity row dropped')),
        'a dropped row left no trace in the log',
      );
    } finally {
      Object.getPrototypeOf(child).warn = originalWarn;
    }
  });

  it('writes nothing at all when the table is absent', async () => {
    activityTablePresent = false;
    _resetActivityTableCache();
    const conn = makeConn();
    const wrote = await recordTemplateActivity(conn, {
      templateId: TEMPLATE, actorId: OWNER.id, action: ACTIVITY_ACTIONS.FLOW_DISPATCHED,
    });
    assert.equal(wrote, false);
    assert.equal(queries.filter((q) => /^INSERT/.test(q.sql)).length, 0);
  });
});
