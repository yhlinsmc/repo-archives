/**
 * schema-field-rename-references.test.js — the OTHER fields' references to a
 * renamed key move in the request that renames the key, and nowhere else.
 *
 * A field key is stored, never an id, so a reference to a field is a string that
 * matches its key. Renaming the field and leaving those strings behind does not
 * error anywhere: the cascading picker looks up a parent that is not there and
 * offers nothing, the visibility condition looks up a subject that is not there
 * and never holds. Both read as "the designer configured it that way".
 *
 * WHY THE CASCADE LIVES ON THE PUT AND NOT ON POST /rename. The field editor
 * makes two calls: POST /rename moves the ANSWERS, and PUT /blueprint_fields/:id
 * writes `field_key`. Repointing the references in the first call names a key no
 * field holds until the second one lands — and if the second one never lands and
 * the operator then saves under a third key, the references are stranded on a
 * key nothing can ever match again, because a later repoint matches on the
 * field's STORED key. Moving the cascade into the statement boundary that writes
 * `field_key` removes the window instead of narrowing it, so the tests below
 * assert BOTH halves: the PUT moves them, and POST /rename does not touch
 * `blueprint_fields` at all.
 *
 * Stub-connection tests, so every assertion targets the SQL and the BOUND
 * parameters the route issues. The two references are NOT stored the same way —
 * one is a column, one is a path inside a JSON document — and a mocked UPDATE
 * reports rows moved whichever statement was built, so the statements are read
 * here and executed against a real engine in
 * tests/integration/field-rename-references-real-db.test.js. Which BLUEPRINT the
 * write leaves the field in — the gate the cascade turns on — is settled on a
 * real engine too, in tests/integration/field-reparent-cascade-real-db.test.js:
 * a stub can show the question was asked and never what the answer would be.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');
const { stubLoggerModule } = require('../../../helpers/stub-logger-module');

const dbKey = require.resolve('../../../../src/edge/db');

// The cascade writes rows the response never mentions, so the log line is the
// only place an operator or an incident responder can see that it did — which
// makes what that line SAYS a behaviour, not decoration. Captured before the
// router is loaded, because the route binds its child logger at module load.
// Derives from the real module so every other export (e.g. captureCallerSrc)
// stays present for sendError, which the route's error paths call.
const loggerKey = require.resolve('../../../../src/shared/lib/logger');
const infoCalls = [];
const captureLogger = {
  child() { return captureLogger; },
  info: (obj, msg) => infoCalls.push({ obj, msg }),
  warn() {}, error() {}, debug() {}, trace() {}, fatal() {}, silent() {},
};
stubLoggerModule(loggerKey, { logger: captureLogger });

const {
  USER_TEMPLATE_METADATA_COLUMN_NAMES,
} = require('../../../../src/edge/lib/user-template-metadata');
const {
  BLUEPRINT_FIELD_KEY_REFERENCES,
  BLUEPRINT_FIELD_KEY_REFERENCE_COLUMNS,
  UNREWRITABLE_KEY_REFERENCE_SITES,
} = require('../../../../src/edge/lib/blueprint-field-key-references');

// Hex LETTERS on purpose: a body respelling a blueprint id in another
// capitalisation has to differ from the stored one BYTE FOR BYTE, or the
// identity probe short-circuits without ever being asked. And identifiers are
// real uuids because the write path refuses a body binding anything else to an
// identifier column — a fixture spelling a blueprint `bp-2` is answered 400 and
// never reaches the behaviour under test.
const BLUEPRINT = 'a1b2c3d4-e5f6-4a7b-8c9d-0e1f2a3b4c5d';
const OTHER_BLUEPRINT = 'b2c3d4e5-f6a7-4b8c-9d0e-1f2a3b4c5d6e';

const DATABASE_PROBE = /^SELECT DATABASE\(\)/i;
const COLUMN_PROBE = /SELECT COLUMN_NAME FROM information_schema\.COLUMNS/i;
const COLLATION_PROBE = /CHARACTER_SET_NAME AS cs/i;
const SAME_VALUE_PROBE = /<=>/;
const FIELD_LOOKUP = /^SELECT blueprint_id, field_key FROM `fmb_blueprint_fields`/i;
const OLD_ROW_LOOKUP = /^SELECT id, blueprint_id, field_type, field_key/i;
const LINKED_LOOKUP = /^SELECT linked_blueprint_id FROM/i;
const OWNER_LOOKUP = /^SELECT owner_id FROM `fmb_hierarchy_nodes`/i;
const NODE_ID_LOOKUP = /^SELECT id FROM `fmb_hierarchy_nodes`/i;
// The (blueprint, key) clash probe both write paths run before they can create a
// duplicate. Nothing collides in these fixtures; what happens when something
// does is settled in tests/integration/blueprint-field-write-real-db.test.js.
// Deliberately tolerant of the COMPARISON: left strict, a reformatting of that
// statement throws `Unmatched query` and turns a dozen unrelated tests red for a
// reason none of them states.
const DUPLICATE_LOOKUP = /^SELECT id FROM `fmb_blueprint_fields`[\s\S]*LIMIT 1/i;
const REFRESH_LOOKUP = /^SELECT \* FROM `fmb_blueprint_fields`/i;
const FIELDS_UPDATE = /^UPDATE `fmb_blueprint_fields`/i;

const BASE_TEMPLATE_COLS = [
  'id', 'name', 'blueprint_id', 'payload', 'generated_outputs', 'created_at', 'updated_at',
];
const BASE_FIELD_COLS = ['id', 'blueprint_id', 'field_key', 'field_label', 'field_type'];

// Per-table answers to the physical-column probe, so a database missing a
// reference column can be simulated without also stripping the template
// columns (the two tables migrate independently).
let columnsByTable;
let conn;
let failingColumn;
let failingErrno;
let blueprintOwnerRows;
let storedBlueprintId;
let currentUser;

function makeConn() {
  // ONE ordered log for statements AND transaction verbs. Two arrays cannot
  // answer "did this statement land inside the transaction?", which is the
  // question the rollback behaviour turns on.
  const ops = [];
  return {
    ops,
    get queries() { return ops.filter((o) => o.kind === 'query'); },
    get tx() { return ops.filter((o) => o.kind === 'tx').map((o) => o.verb); },
    async query(sql, params) {
      if (DATABASE_PROBE.test(sql)) return [{ db: 'db_default' }];
      if (COLUMN_PROBE.test(sql)) {
        const table = params && params[0];
        const cols = columnsByTable[table];
        assert.ok(cols, `unexpected column probe for ${table}`);
        return cols.map((c) => ({ COLUMN_NAME: c }));
      }
      // The identity question the write path asks the ENGINE (write-value.js
      // `sameStoredValue`): are these two spellings one stored value? Answered
      // the way the column's collation answers it — case-folded, trailing space
      // padded — so this double cannot disagree with the database about whether
      // a write moved a value. Not pushed onto `ops`: these are the helper's own
      // round trips and no assertion below is about them.
      if (COLLATION_PROBE.test(sql)) return [{ cs: 'utf8mb4', co: 'utf8mb4_general_ci' }];
      if (SAME_VALUE_PROBE.test(sql) && / AS same/.test(sql)) {
        const fold = (v) => String(v).toLowerCase().replace(/\s+$/, '');
        return [{ same: fold((params || [])[0]) === fold((params || [])[1]) ? 1 : 0 }];
      }
      ops.push({ kind: 'query', sql, params });
      if (FIELD_LOOKUP.test(sql)) return [{ blueprint_id: BLUEPRINT, field_key: 'old_key' }];
      if (OLD_ROW_LOOKUP.test(sql)) {
        return [{
          id: 'fld-1', blueprint_id: storedBlueprintId, field_type: 'text', field_key: 'old_key',
          depends_on_field_key: null,
        }];
      }
      if (LINKED_LOOKUP.test(sql)) return [];
      if (OWNER_LOOKUP.test(sql)) return blueprintOwnerRows;
      // Which spelling the destination blueprint's own row carries, so a genuine
      // move binds the STORED one rather than the caller's.
      if (NODE_ID_LOOKUP.test(sql)) return [{ id: (params || [])[0] }];
      if (DUPLICATE_LOOKUP.test(sql)) return [];
      if (REFRESH_LOOKUP.test(sql)) {
        return [{
          id: 'fld-1', blueprint_id: BLUEPRINT, field_key: 'new_key', field_type: 'text',
        }];
      }
      if (/^UPDATE `fmb_field_options`/i.test(sql)) return { affectedRows: 0 };
      if (/^UPDATE `fmb_(user_templates|blueprint_fields)`/i.test(sql)) {
        if (failingColumn && sql.includes(`\`${failingColumn}\``)) {
          // The errno is a parameter now, because WHICH engine failure the
          // cascade raises decides what the operator is told, and only one of
          // them is a server fault.
          throw Object.assign(new Error(failingErrno === 1054 ? 'Unknown column' : 'engine gave up'), {
            errno: failingErrno,
          });
        }
        return { affectedRows: 2 };
      }
      throw new Error(`Unmatched query: ${sql.slice(0, 160)}`);
    },
    release() { /* noop */ },
    async beginTransaction() { ops.push({ kind: 'tx', verb: 'begin' }); },
    async commit() { ops.push({ kind: 'tx', verb: 'commit' }); },
    async rollback() { ops.push({ kind: 'tx', verb: 'rollback' }); },
  };
}

const poolSpy = {
  rw: { async getConnection() { return conn; } },
  ro: { async getConnection() { return conn; } },
};

require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: {
    pool: poolSpy,
    t: (name) => `fmb_${name}`,
    getDynamicPool: async () => poolSpy,
  },
};

const router = require('../../../../src/edge/routes/app/schema');
const { __clearColumnSetCache } = router.__test__;
const { _clearColumnCollationCache } = require('../../../../src/edge/routes/app/schema/write-value');

let server;
let port;

before(async () => {
  const app = express();
  // TEST-ONLY: production always sets req.log via createRequestId
  // (request-id.js) before any router; this bare app has no such
  // middleware. Routed through captureLogger (not console) — the rename
  // route logs its own line via req.log, and infoCalls above is what
  // every assertion in this file reads.
  app.use((req, _res, next) => { req.log = captureLogger; next(); });
  app.use(express.json({ limit: '10mb' }));
  app.use((req, _res, next) => { req.user = currentUser; next(); });
  app.use('/edge/app/schema', router);
  await new Promise((resolve) => {
    server = app.listen(0, '127.0.0.1', () => { port = server.address().port; resolve(); });
  });
});

after(async () => {
  await new Promise((resolve) => server.close(resolve));
  delete require.cache[dbKey];
});

beforeEach(() => {
  columnsByTable = {
    fmb_user_templates: [...BASE_TEMPLATE_COLS, ...USER_TEMPLATE_METADATA_COLUMN_NAMES],
    fmb_blueprint_fields: [...BASE_FIELD_COLS, ...BLUEPRINT_FIELD_KEY_REFERENCE_COLUMNS],
    fmb_field_options: ['id', 'field_id', 'option_value', 'valid_parent_values'],
  };
  failingColumn = null;
  failingErrno = 1054;
  blueprintOwnerRows = [{ owner_id: 'someone-else' }];
  storedBlueprintId = BLUEPRINT;
  currentUser = { id: 'admin-1', role: 'admin' };
  conn = makeConn();
  infoCalls.length = 0;
  __clearColumnSetCache();
  _clearColumnCollationCache();
});

function sendJson(method, path_, body) {
  return new Promise((resolve, reject) => {
    const payload = JSON.stringify(body);
    const req = http.request(
      {
        host: '127.0.0.1', port, path: path_, method,
        headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) },
      },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          const raw = Buffer.concat(chunks).toString('utf-8');
          let json = null;
          try { json = JSON.parse(raw); } catch { /* noop */ }
          resolve({ status: res.statusCode, raw, json });
        });
      },
    );
    req.on('error', reject);
    req.write(payload);
    req.end();
  });
}

const migrate = (body = { old_key: 'old_key', new_key: 'new_key' }) =>
  sendJson('POST', '/edge/app/schema/rename/fld-1', body);
const rename = (body = { field_key: 'new_key' }) =>
  sendJson('PUT', '/edge/app/schema/blueprint_fields/fld-1', body);

const fieldUpdates = () => conn.queries.filter((q) => FIELDS_UPDATE.test(q.sql));
// What makes a statement a reference statement is WHICH COLUMN IT ASSIGNS: a
// declared reference column, which the field's own key write never names.
//
// A SELECTOR MAY NOT NAME ANYTHING AN ASSERTION BELOW JUDGES. Keyed on
// `BINARY`, widening the comparison made the statement invisible and the
// assertion about the comparison passed by never seeing it. Keyed on `WHERE
// blueprint_id = ?` it had the same defect one column over — dropping the
// blueprint scope reported "no UPDATE on depends_on_field_key", which is not
// what went wrong. The SET clause is judged by nothing here.
// The addressed-row write is excluded by what it IS and not by anything judged
// below: it assigns `field_key`, and no cascade statement ever does. Without
// that clause a body naming a reference column AND renaming the key puts a
// reference column first in the SET clause, and the key write is selected as a
// third reference statement where two are declared. Every consequence of that
// is a false red rather than a false green, but a selector on its third
// revision should stop being nearly right.
const assignsReferenceColumn = (sql, columns = BLUEPRINT_FIELD_KEY_REFERENCE_COLUMNS) =>
  !/`field_key` = \?/.test(sql)
  && columns.some((col) => new RegExp(`SET \`${col}\` =`).test(sql));
const referenceUpdates = () => fieldUpdates().filter((q) => assignsReferenceColumn(q.sql));
const updateFor = (column) => referenceUpdates().find((q) => q.sql.includes(`\`${column}\``));

describe('field rename — the references other fields hold to the renamed key', () => {
  it('issues one statement per declared reference site, and no more', async () => {
    // Counted against the declaration rather than against the number 2, so a
    // site added to the declaration and not wired into the route goes red here
    // instead of shipping as a reference nothing moves.
    const res = await rename();
    assert.equal(res.status, 200, res.raw);
    assert.equal(referenceUpdates().length, BLUEPRINT_FIELD_KEY_REFERENCES.length);
    for (const site of BLUEPRINT_FIELD_KEY_REFERENCES) {
      assert.ok(updateFor(site.column), `no UPDATE moves references in ${site.column}`);
    }
  });

  it('moves the cascading picker\'s parent key, scoped to the blueprint', async () => {
    await rename();
    const update = updateFor('depends_on_field_key');
    assert.ok(update, 'no UPDATE on depends_on_field_key');
    assert.deepEqual(update.params, ['new_key', BLUEPRINT, 'old_key']);
    assert.match(update.sql, /WHERE blueprint_id = \?/);
  });

  it('moves the visibility condition\'s subject at the path it actually sits', async () => {
    // The one place this was already recorded wrong: the reference is
    // `visibility_rule.field_key`, and a statement built for any other path
    // matches nothing and reports success.
    await rename();
    const update = updateFor('visibility_rule');
    assert.ok(update, 'no UPDATE on visibility_rule');
    assert.deepEqual(
      update.params,
      ['$."field_key"', 'new_key', BLUEPRINT, '$."field_key"', 'old_key'],
    );
    assert.match(update.sql, /JSON_SET\(`visibility_rule`, \?, \?\)/);
    assert.match(update.sql, /WHERE blueprint_id = \?/);
  });

  it('excludes the addressed row at a site this request wrote', async () => {
    // The UPDATE above the cascade has stored the body's values by the time
    // these run, so a body naming the old key as this field's OWN reference
    // would have that value overwritten by the repair — the operator sends one
    // value and the column ends up holding another. Asserted per site, because
    // the exclusion is decided per site and neither implies the other.
    await rename({
      field_key: 'new_key',
      depends_on_field_key: 'old_key',
      visibility_rule: JSON.stringify({ field_key: 'old_key', operator: 'eq', value: 'y' }),
    });
    for (const site of BLUEPRINT_FIELD_KEY_REFERENCES) {
      const update = updateFor(site.column);
      assert.match(
        update.sql, /AND id <> \?/,
        `${site.column} repoints the addressed row too, overruling what this request wrote`,
      );
      assert.ok(
        update.params.includes('fld-1'),
        `${site.column} excludes some row other than the one being written`,
      );
    }
  });

  it('does NOT exclude it at a site the request said nothing about', async () => {
    // The narrow half of the same rule, and the half that is easy to get
    // backwards. A site the body never named holds no value this request wrote,
    // so the addressed row's own reference there is a reference like any other
    // and has to follow the key. Left behind it stops resolving — and at the
    // visibility site that does not degrade gracefully: the evaluator reads the
    // absent key as `''`, the condition compares false, and the field is hidden
    // with no key anywhere able to give it a value. What the two branches
    // PRODUCE is measured on a real engine in
    // tests/integration/field-rename-references-real-db.test.js.
    await rename();
    for (const site of BLUEPRINT_FIELD_KEY_REFERENCES) {
      const update = updateFor(site.column);
      assert.doesNotMatch(
        update.sql, /id <> \?/,
        `${site.column} skips the addressed row over a value this request never sent, `
        + 'which leaves that row\'s own reference naming a key nothing holds',
      );
      assert.ok(
        !update.params.includes('fld-1'),
        `${site.column} still binds the addressed row's id`,
      );
    }
  });

  it('never binds a null as the excluded row', async () => {
    // `id <> NULL` is UNKNOWN for every row, so a statement carrying it matches
    // NOTHING — a cascade turned silently off rather than narrowed. Spelling the
    // "exclude nobody" case by omitting the clause is what avoids that, and it
    // is the same trap the field-key clash probe documents. Asserted on both
    // bodies, because only one of them takes that branch.
    await rename();
    for (const q of referenceUpdates()) {
      assert.ok(!q.params.includes(null), 'a null reached the exclusion predicate');
    }
  });

  it('leaves a document the engine cannot parse alone', async () => {
    await rename();
    // JSON_REMOVE/JSON_SET against text MariaDB cannot parse answers NULL, which
    // would replace an unreadable rule with no rule at all.
    assert.match(updateFor('visibility_rule').sql, /JSON_VALID\(`visibility_rule`\)/);
  });

  it('matches the old key byte for byte, not under the column\'s collation', async () => {
    // Every reader of these references resolves them with an exact string
    // comparison (a JS map lookup), so a reference spelling the key with
    // different capitalisation already points at nothing. Matching it under the
    // column's case-insensitive collation would not repair that reference — it
    // would invent a link the renderer never had.
    await rename();
    for (const site of BLUEPRINT_FIELD_KEY_REFERENCES) {
      assert.match(
        updateFor(site.column).sql, /= BINARY \?/,
        `${site.column} is matched under the column collation, not byte for byte`,
      );
    }
  });

  it('moves the references in the same statement boundary as the key itself', async () => {
    await rename();
    assert.deepEqual(conn.tx, ['begin', 'commit']);
    // Recorded in ONE ordered log, so this really does fail when a reference
    // statement is moved out of the transaction — with the verbs kept in a
    // separate array the assertion could only restate that both happened.
    const begin = conn.ops.findIndex((o) => o.kind === 'tx' && o.verb === 'begin');
    const commit = conn.ops.findIndex((o) => o.kind === 'tx' && o.verb === 'commit');
    const keyWrite = conn.ops.findIndex(
      (o) => o.kind === 'query' && FIELDS_UPDATE.test(o.sql) && o.sql.includes('`field_key` = ?'),
    );
    assert.ok(keyWrite > begin, 'the field\'s own key is written outside the transaction');
    for (const site of BLUEPRINT_FIELD_KEY_REFERENCES) {
      const at = conn.ops.findIndex(
        (o) => o.kind === 'query' && FIELDS_UPDATE.test(o.sql)
          && assignsReferenceColumn(o.sql, [site.column]),
      );
      assert.ok(at > begin && at < commit, `${site.column} moves outside the transaction`);
    }
  });

  it('rolls back the whole rename when a reference cannot be moved', async () => {
    failingColumn = 'visibility_rule';
    const res = await rename();
    assert.equal(res.status, 500);
    assert.deepEqual(conn.tx, ['begin', 'rollback']);
  });

  // A write the engine gave up on is not a write this server got wrong, and the
  // difference is the whole of what an operator can do next. The cascade is why
  // this handler needs the distinction at all: its JSON predicate is not
  // indexable, so the statement examines every field row of the blueprint and
  // takes next-key locks across that range, where a rename used to lock one row
  // and could not join a deadlock cycle. Answered 500, contention reads as a
  // server fault and nobody retries.
  for (const [errno, what] of [[1213, 'a deadlock the engine broke'], [1205, 'a lock wait that timed out']]) {
    it(`answers 409 WRITE_CONFLICT for ${what}, and rolls back`, async () => {
      failingColumn = 'visibility_rule';
      failingErrno = errno;
      const res = await rename();
      assert.equal(res.status, 409, res.raw);
      assert.equal(res.json.error.code, 'WRITE_CONFLICT');
      assert.deepEqual(conn.tx, ['begin', 'rollback']);
    });
  }

  it('still answers 500 for an engine error that is not contention', async () => {
    // The control. Mapping everything to 409 would tell an operator to retry a
    // request that can never succeed, which is the same unactionable answer in
    // the other direction.
    failingColumn = 'visibility_rule';
    failingErrno = 1054;
    const res = await rename();
    assert.equal(res.status, 500, res.raw);
    assert.notEqual(res.json.error.code, 'WRITE_CONFLICT');
  });

  it('skips a reference column the target database does not have', async () => {
    // depends_on_field_key arrived by an additive ALTER a no-privilege operator
    // database may have warn-skipped. Naming it there would 1054 the rename
    // that used to work.
    columnsByTable.fmb_blueprint_fields = BASE_FIELD_COLS;
    const res = await rename();
    assert.equal(res.status, 200, res.raw);
    assert.deepEqual(referenceUpdates(), []);
  });

  it('touches no reference when the key is not changing', async () => {
    // The field editor PUTs the whole form on every save, so `field_key` is in
    // the body of an ordinary label edit too. A cascade that fired on that would
    // rewrite references on every save.
    const res = await rename({ field_key: 'old_key', field_label: 'Renamed label' });
    assert.equal(res.status, 200, res.raw);
    assert.deepEqual(referenceUpdates(), []);
  });

  it('touches no reference when the field also moves to another blueprint', async () => {
    // The references live in the blueprint the field is LEAVING, and the field
    // will not be there to be referenced. Repointing them at the new key would
    // strand them on a key no field in that blueprint holds — the failure this
    // whole cascade exists to prevent, created by the cascade itself.
    const res = await rename({ field_key: 'new_key', blueprint_id: OTHER_BLUEPRINT });
    assert.equal(res.status, 200, res.raw);
    assert.deepEqual(referenceUpdates(), []);
    const keyWrite = fieldUpdates().find((q) => q.sql.includes('`field_key` = ?'));
    assert.ok(
      keyWrite && keyWrite.params.includes(OTHER_BLUEPRINT),
      'the move was never written, so the skip proves nothing',
    );
  });

  it('touches nothing at all when the body names no blueprint any caller may write to', async () => {
    // `blueprint_id` is nullable, so this body reads as a legal move to no
    // blueprint at all — and the references sit in the blueprint being emptied.
    // The destination check refuses it before any statement runs, because the
    // column carries no foreign key and a null names no blueprint. Asserted as
    // "no statement was issued" rather than on the status alone: refusing and
    // refusing halfway through are the same status code.
    const res = await rename({ field_key: 'new_key', blueprint_id: null });
    assert.equal(res.status, 404, res.raw);
    assert.deepEqual(fieldUpdates(), []);
    assert.deepEqual(conn.tx, ['begin', 'rollback']);
  });

  it('touches no reference when the rename is not written at all', async () => {
    // The gate is the GATED key list and not the body: a column the probe found
    // absent is dropped from the UPDATE, so the field keeps its stored key and
    // a cascade would move every reference to a key its field never took. The
    // probe answering without `field_key` is the only way to reach that branch,
    // which is why it is simulated rather than waited for.
    columnsByTable.fmb_blueprint_fields = [
      'id', 'blueprint_id', 'field_label', 'field_type', ...BLUEPRINT_FIELD_KEY_REFERENCE_COLUMNS,
    ];
    const res = await rename({ field_key: 'new_key', field_label: 'Renamed label' });
    assert.equal(res.status, 200, res.raw);
    assert.deepEqual(referenceUpdates(), []);
    const written = fieldUpdates().find((q) => /SET/.test(q.sql));
    assert.ok(written, 'nothing was written at all');
    assert.doesNotMatch(
      written.sql, /`field_key` = \?/,
      'the column the probe said was absent was named in the UPDATE',
    );
  });

  it('does not clear the per-option tags for a parent change it did not write', async () => {
    // The same shape as the reparent gate, on the other reference column. The
    // tags on `field_options.valid_parent_values` are keyed to the parent's
    // option values, so they are cleared when the parent changes — but a
    // decision that read the BODY while the UPDATE names the gated columns means
    // that on a database which warn-skipped `depends_on_field_key` the field's
    // stored parent cannot change and the tags an operator set are destroyed on
    // every ordinary save. The clear is not recoverable: nothing else records
    // what they were.
    columnsByTable.fmb_blueprint_fields = BASE_FIELD_COLS;
    const res = await rename({ field_label: 'Renamed label', depends_on_field_key: 'other_key' });
    assert.equal(res.status, 200, res.raw);
    assert.deepEqual(
      conn.queries.filter((q) => /^UPDATE `fmb_field_options`/i.test(q.sql)), [],
      'the per-option tags were cleared for a parent this write could not store',
    );
  });

  it('still clears them when the parent change IS written', async () => {
    // The control: the clear exists because a tag read against the wrong parent
    // hides option values in the editor, so a gate that never fires is not a fix.
    const res = await rename({ field_label: 'Renamed label', depends_on_field_key: 'other_key' });
    assert.equal(res.status, 200, res.raw);
    assert.equal(
      conn.queries.some((q) => /^UPDATE `fmb_field_options`/i.test(q.sql)), true,
      'a real parent change no longer resets the tags keyed to the old parent',
    );
  });

  it('touches no reference for an editor who does not own the blueprint', async () => {
    currentUser = { id: 'editor-1', role: 'editor' };
    blueprintOwnerRows = [{ owner_id: 'someone-else' }];
    const res = await rename();
    assert.equal(res.status, 404, res.raw);
    assert.deepEqual(referenceUpdates(), []);
    assert.deepEqual(conn.tx, ['begin', 'rollback']);
  });

  it('moves them for the editor who owns the blueprint', async () => {
    currentUser = { id: 'editor-1', role: 'editor' };
    blueprintOwnerRows = [{ owner_id: 'editor-1' }];
    const res = await rename();
    assert.equal(res.status, 200, res.raw);
    assert.equal(referenceUpdates().length, BLUEPRINT_FIELD_KEY_REFERENCES.length);
  });
});

describe('field rename — the only record that rows other than the addressed one moved', () => {
  const renameLines = () => infoCalls.filter((c) => /^Renamed a field key/.test(c.msg));

  it('says the references moved when they moved, and counts them', async () => {
    const res = await rename();
    assert.equal(res.status, 200, res.raw);
    const [line, ...extra] = renameLines();
    assert.ok(line, 'a rename that repointed references left no record of it');
    assert.deepEqual(extra, [], 'one rename produced more than one record');
    assert.match(line.msg, /repointed the cascade parents and visibility-rule subjects/);
    assert.deepEqual(
      line.obj.repointed,
      { depends_on_field_key: 2, visibility_rule: 2 },
      'the counts are what distinguishes "moved none" from "did not look"',
    );
  });

  it('names the places a key is still spelled that the rename did not follow', async () => {
    // The sentence used to say "the references" were repointed, which is not
    // what happened: a sibling naming this key inside `compute_rule`, inside a
    // decision table or in a connector's mapping keeps the old spelling, and
    // nothing rejects it. This line is the only record an incident responder
    // reads, so an operator who trusts a completeness claim here stops looking
    // in the one place the stale key is.
    await rename();
    const [line] = infoCalls.filter((c) => /^Renamed a field key/.test(c.msg));
    assert.deepEqual(
      line.obj.not_repointed, UNREWRITABLE_KEY_REFERENCE_SITES,
      'the record claims a completeness the cascade does not have',
    );
    assert.ok(line.obj.not_repointed.length > 0, 'an empty exclusion list is a completeness claim');
    assert.match(line.msg, /not_repointed/, 'the field is there but the sentence does not send anyone to it');
  });

  it('does not say they moved when the reparent skip stopped them', async () => {
    // The response carries the edited field alone and the impact preview counts
    // records, not references, so this line is the whole surface an incident
    // responder has. On the skip path a single line gated on the rename alone
    // stated the opposite of what happened, with an empty object as the only
    // tell — indistinguishable at a glance from a cascade that ran and matched
    // nothing.
    const res = await rename({ field_key: 'new_key', blueprint_id: OTHER_BLUEPRINT });
    assert.equal(res.status, 200, res.raw);
    const [line] = renameLines();
    assert.ok(line, 'a rename left no record at all');
    assert.doesNotMatch(
      line.msg, /repointed the cascade parents/,
      'the log says references were repointed on the path where they deliberately were not',
    );
    assert.match(line.msg, /left every reference to it in the blueprint the field left/);
    assert.equal(
      line.obj.new_blueprint_id, OTHER_BLUEPRINT,
      'the record does not say where the field went',
    );
    assert.equal(line.obj.repointed, undefined, 'a count of moved references on a path that moved none');
  });

  it('leaves no record when nothing was renamed', async () => {
    const res = await rename({ field_key: 'old_key', field_label: 'Renamed label' });
    assert.equal(res.status, 200, res.raw);
    assert.deepEqual(renameLines(), []);
  });
});

describe('field rename — POST /rename never repoints a reference', () => {
  it('writes nothing at all to blueprint_fields', async () => {
    // The endpoint that moves the ANSWERS must not move the references: it does
    // not write `field_key`, so every reference it repointed would name a key no
    // field holds until a SECOND request lands, and would be stranded for good
    // if that request failed and the operator then saved under a third key.
    const res = await migrate();
    assert.equal(res.status, 200, res.raw);
    assert.deepEqual(fieldUpdates(), []);
  });

  it('keeps the response contract unchanged', async () => {
    // migrated_count has always meant records whose ANSWERS moved.
    const res = await migrate();
    assert.deepEqual(Object.keys(res.json.data), ['migrated_count']);
    assert.equal(res.json.data.migrated_count, 2);
  });

  it('touches nothing when the key format is refused', async () => {
    const res = await migrate({ old_key: 'old_key', new_key: 'New Key' });
    assert.equal(res.status, 400);
    assert.deepEqual(conn.queries.filter((q) => /^UPDATE /i.test(q.sql)), []);
  });
});
