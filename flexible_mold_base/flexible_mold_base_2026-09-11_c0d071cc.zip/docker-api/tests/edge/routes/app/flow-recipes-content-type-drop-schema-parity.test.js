/**
 * flow-recipes-content-type-drop-schema-parity.test.js — validates the
 * PR-YZ Task Z.0 drop entry (`flow_recipes_content_type_drop`, fmb-2062)
 * against the ACTUAL table DDL, WITHOUT a live DB.
 *
 * WHY THIS EXISTS. The drop is a `kind: 'custom'` entry (not `drop-column`)
 * because its target is conditional on live schema state a structural kind
 * cannot express (Y2.6c's precondition: a permanently no-ALTER install keeps
 * the column by design). That means the mechanical `findDropColumnGaps`
 * check in migration-steps-consistency.test.js — which asserts every
 * `drop-column` entry's column is ALREADY absent from table-ddls.js — never
 * sees this entry. This test is that same assertion, restated for the
 * `custom` shape: table-ddls.js must NOT declare flow_recipes.content_type
 * (the drop's target is genuinely gone from the current DDL), while
 * flow_recipe_steps must still declare its three per-step dialect columns
 * (the replacement this drop presupposes already landed).
 */
const { describe, it, before } = require('node:test');
const assert = require('node:assert/strict');

const { buildEngineTableDDLs } = require('../../../../src/table-ddls');
const { MIGRATION_STEPS } = require('../../../../src/edge/migration-steps');

const SQL_TYPES = /^`?([a-z_]+)`?\s+(?:CHAR|VARCHAR|INT|DOUBLE|TIMESTAMP|JSON|TEXT|ENUM|BOOLEAN|TINYINT|BIGINT|DATETIME|DECIMAL|FLOAT|BLOB)\b/i;
let columnsByTable;

before(() => {
  columnsByTable = new Map();
  for (const ddl of buildEngineTableDDLs((n) => n)) {
    const m = ddl.match(/CREATE TABLE IF NOT EXISTS `([^`]+)`/);
    if (!m) continue;
    const cols = new Set();
    for (const rawLine of ddl.split('\n')) {
      const line = rawLine.trim();
      if (!line || line.startsWith('--') || line.startsWith('/*')) continue;
      const cm = line.match(SQL_TYPES);
      if (cm) cols.add(cm[1]);
    }
    columnsByTable.set(m[1], cols);
  }
});

describe('flow_recipes.content_type drop (PR-YZ Task Z.0) — schema parity', () => {
  const entry = MIGRATION_STEPS.find((s) => s.step === 'flow_recipes_content_type_drop');
  const statements = entry ? entry.remediationSql((n) => n) : [];
  const alterStatement = statements[statements.length - 1] || '';

  it('the registry carries the drop entry with a probe, run and remediationSql', () => {
    assert.ok(entry, 'migration-steps.js no longer declares flow_recipes_content_type_drop');
    assert.equal(entry.kind, 'custom');
    assert.equal(typeof entry.probe, 'function');
    assert.equal(typeof entry.run, 'function');
    assert.equal(typeof entry.remediationSql, 'function');
    assert.equal(entry.severity, 'warning');
  });

  it('version is strictly greater than the 3.2.972 ADD COLUMN it depends on', () => {
    const addEntry = MIGRATION_STEPS.find((s) => s.step === 'flow_recipe_steps_content_type_add');
    assert.ok(addEntry, 'the PR-Y1 add-column entry is gone');
    const [aMaj, aMin, aPatch] = addEntry.version.split('.').map(Number);
    const [dMaj, dMin, dPatch] = entry.version.split('.').map(Number);
    const addTuple = aMaj * 1e6 + aMin * 1e3 + aPatch;
    const dropTuple = dMaj * 1e6 + dMin * 1e3 + dPatch;
    assert.ok(dropTuple > addTuple, `drop version ${entry.version} must be strictly later than add version ${addEntry.version}`);
  });

  it('table-ddls.js no longer declares flow_recipes.content_type — the drop target is genuinely gone', () => {
    const cols = columnsByTable.get('flow_recipes');
    assert.ok(cols, 'flow_recipes table not found in the DDL manifest');
    assert.ok(
      !cols.has('content_type'),
      'flow_recipes still declares content_type — the drop entry has no real DDL counterpart (this PR must delete the DDL column line)',
    );
  });

  it('table-ddls.js still declares the three flow_recipe_steps dialect columns this drop presupposes', () => {
    const cols = columnsByTable.get('flow_recipe_steps');
    assert.ok(cols, 'flow_recipe_steps table not found in the DDL manifest');
    for (const c of ['content_type', 'yaml_version', 'yaml_quoting']) {
      assert.ok(cols.has(c), `flow_recipe_steps has no column '${c}'`);
    }
  });

  it('remediationSql drops exactly flow_recipes.content_type and states the precondition', () => {
    assert.match(alterStatement, /^ALTER TABLE `flow_recipes` DROP COLUMN `content_type`;$/);
    const precondition = statements[0] || '';
    assert.match(precondition, /^--/, 'the first statement must be an SQL comment (the precondition)');
    assert.match(precondition, /content_type\/yaml_version\/yaml_quoting/);
    assert.match(precondition, /permanently without those three columns/);
  });
});
