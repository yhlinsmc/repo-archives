/**
 * flow-recipe-steps-content-type-schema-parity.test.js — the three per-step
 * dialect columns (flow-yaml-dialect PR-Y1/PR-Y2, fmb-2061) exist as ENUM
 * columns on flow_recipe_steps AND are exposed through the DDL-derived enum
 * domain the CRUD factory's write-time 400 gate reads (`enumColumnsFor`) — a
 * mocked write path would hide either a missing column or a member-list typo,
 * this test is the one thing that catches it without a live DB.
 */
const { describe, it, before } = require('node:test');
const assert = require('node:assert/strict');
const { buildEngineTableDDLs } = require('../../../../src/table-ddls');
const { enumColumnsFor } = require('../../../../src/edge/lib/schema-manifest');

let cols;
before(() => {
  const ddl = buildEngineTableDDLs((n) => n).find((d) => /`flow_recipe_steps`/.test(d));
  cols = new Set([...ddl.matchAll(/^\s*`?([a-z_]+)`?\s+ENUM/gim)].map((m) => m[1]));
});

describe('flow_recipe_steps per-step dialect columns exist', () => {
  it('declares content_type / yaml_version / yaml_quoting as ENUM columns', () => {
    for (const c of ['content_type', 'yaml_version', 'yaml_quoting']) assert.ok(cols.has(c), `${c} missing`);
  });
  it('exposes them through the DDL-derived enum domain (so the CRUD 400 gate covers them)', () => {
    const dom = enumColumnsFor('flow_recipe_steps');
    assert.deepEqual(dom.content_type, ['application/json', 'application/yaml']);
    assert.deepEqual(dom.yaml_version, ['1.2', '1.1']);
    assert.deepEqual(dom.yaml_quoting, ['plain', 'double', 'single']);
  });
});
