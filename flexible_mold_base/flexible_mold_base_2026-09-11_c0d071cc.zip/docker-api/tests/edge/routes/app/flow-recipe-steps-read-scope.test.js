// docker-api/tests/edge/routes/app/flow-recipe-steps-read-scope.test.js
const { test } = require('node:test');
const { makeStubReqLog } = require('../../../helpers/stub-req-log');
const assert = require('node:assert');
const express = require('express');

// recipeOwner is returned by the default pool.ro.query path (list probe).
// queryQueue, when non-empty, is consumed in order per call — used by GET /:id
// tests that need two sequential queries (step row, then recipe row).
let recipeOwner = 'u1';
let queryQueue = [];

require.cache[require.resolve('../../../../src/edge/db')] = {
  exports: {
    pool: {
      ro: {
        query: async () => {
          const v = queryQueue.length > 0 ? queryQueue.shift() : [{ owner_id: recipeOwner }];
          if (v instanceof Error) throw v; // simulate a DB error (e.g. errno 1146 table-absent)
          return v;
        },
      },
      rw: { getConnection: async () => ({ query: async () => [], release: () => {} }) },
    },
    t: (x) => x,
  },
};
// Stub the CRUD factory so the test isolates the read-scope middleware.
require.cache[require.resolve('../../../../src/edge/routes/app/schema')] = {
  exports: { createCrudRoutes: () => (req, res) => res.json({ ok: true, reached: 'crud' }) },
};
const router = require('../../../../src/edge/routes/app/flow-recipe-steps');

function app(user) {
  const a = express(); a.use(express.json());
  a.use((req, _res, next) => { req.log = makeStubReqLog(); next(); }); // TEST-ONLY: production always sets req.log via createRequestId (request-id.js) before any router; this bare app has no such middleware, so a route's req.log.<level>() call would otherwise throw against undefined.
  a.use((req, _res, next) => { req.user = user; next(); });
  a.use('/', router);
  return a;
}
async function get(a, path) {
  const server = a.listen(0);
  try {
    const port = server.address().port;
    const res = await fetch(`http://127.0.0.1:${port}${path}`);
    const json = await res.json().catch(() => ({}));
    return { status: res.status, json };
  } finally {
    // Closed on the throwing path too. With the close reachable only where
    // nothing threw, a failed assertion leaks this handle, the runner never
    // exits, and the job reports a timeout instead of the assertion that failed.
    server.close();
  }
}

// LIST path tests
test('non-admin GET without recipe_id → 400', async () => {
  const { status } = await get(app({ id: 'u1', role: 'editor' }), '/');
  assert.strictEqual(status, 400);
});
test('non-admin GET of own recipe steps → reaches CRUD', async () => {
  recipeOwner = 'u1';
  const { json } = await get(app({ id: 'u1', role: 'editor' }), '/?recipe_id=11111111-1111-1111-1111-111111111111');
  assert.strictEqual(json.reached, 'crud');
});
test("non-admin GET of another's recipe steps → 403", async () => {
  recipeOwner = 'someone-else';
  const { status } = await get(app({ id: 'u1', role: 'editor' }), '/?recipe_id=11111111-1111-1111-1111-111111111111');
  assert.strictEqual(status, 403);
});
test('non-admin GET of shared recipe (owner_id NULL) steps → reaches CRUD', async () => {
  // Shared recipes have owner_id NULL — any editor may list their steps.
  recipeOwner = null;
  const { json } = await get(app({ id: 'u1', role: 'editor' }), '/?recipe_id=11111111-1111-1111-1111-111111111111');
  assert.strictEqual(json.reached, 'crud');
});

// Single-id GET /:id tests
test("non-admin GET /:id where step belongs to another's recipe → 403", async () => {
  // First query returns the step row with its recipe_id; second returns the recipe's owner.
  queryQueue = [
    [{ recipe_id: 'aaaa0000-0000-0000-0000-000000000001' }],
    [{ owner_id: 'someone-else' }],
  ];
  const { status } = await get(app({ id: 'u1', role: 'editor' }), '/bbbb0000-0000-0000-0000-000000000002');
  assert.strictEqual(status, 403);
});
test('non-admin GET /:id where step belongs to own recipe → reaches CRUD', async () => {
  queryQueue = [
    [{ recipe_id: 'aaaa0000-0000-0000-0000-000000000001' }],
    [{ owner_id: 'u1' }],
  ];
  const { json } = await get(app({ id: 'u1', role: 'editor' }), '/bbbb0000-0000-0000-0000-000000000002');
  assert.strictEqual(json.reached, 'crud');
});

// Fail-closed: an absent recipes table (errno 1146) must DENY, not fall through
// unscoped — a partially-migrated DB (steps present, recipes dropped) must never
// let a caller list/read another owner's steps.
function errno1146() { const e = new Error("Table 'flow_recipes' doesn't exist"); e.errno = 1146; return e; }

test('LIST path: recipes-table-absent (errno 1146) → 403 fail-closed (not unscoped)', async () => {
  queryQueue = [errno1146()];
  const { status, json } = await get(app({ id: 'u1', role: 'editor' }), '/?recipe_id=11111111-1111-1111-1111-111111111111');
  assert.strictEqual(status, 403);
  assert.strictEqual(json.error.code, 'FORBIDDEN');
});

test('GET /:id path: recipes-table-absent (errno 1146) → 403 fail-closed', async () => {
  // First query (step row) succeeds; the recipe-owner query throws 1146.
  queryQueue = [
    [{ recipe_id: 'aaaa0000-0000-0000-0000-000000000001' }],
    errno1146(),
  ];
  const { status, json } = await get(app({ id: 'u1', role: 'editor' }), '/bbbb0000-0000-0000-0000-000000000002');
  assert.strictEqual(status, 403);
  assert.strictEqual(json.error.code, 'FORBIDDEN');
});

// fmb-2097: pins the body AFTER the bespoke-literal → sendError migration.
// BEFORE this unit the body was the bespoke `{ ok: false, error: { code:
// 'INTERNAL_ERROR' } }` (no `message` field at all); AFTER, sendError
// responds with the shared apiError envelope, now carrying a `message` too —
// NOT byte-identical, a genuine finding, but the caught DB error's own
// message is never included (safe reason string only).
test('LIST path: a non-1146 DB error still → 500, now via the sendError envelope', async () => {
  const e = new Error('connection reset'); e.errno = 2013;
  queryQueue = [e];
  const { status, json } = await get(app({ id: 'u1', role: 'editor' }), '/?recipe_id=11111111-1111-1111-1111-111111111111');
  assert.strictEqual(status, 500);
  assert.strictEqual(json.data, null);
  assert.strictEqual(json.error.code, 'INTERNAL_ERROR');
  assert.strictEqual(json.error.message, 'Recipe read-scope probe failed');
  assert.strictEqual('ok' in json, false, 'the old bespoke ok key is gone');
  assert.strictEqual(JSON.stringify(json).includes('connection reset'), false);
});

test('GET /:id path: steps-table-absent (errno 1146 on the FIRST query) → 403 fail-closed', async () => {
  // The /:id catch wraps both the step-row and recipe-row queries; an absent
  // steps table (1146 on query 1) is also denied rather than passed to CRUD.
  queryQueue = [errno1146()];
  const { status, json } = await get(app({ id: 'u1', role: 'editor' }), '/bbbb0000-0000-0000-0000-000000000002');
  assert.strictEqual(status, 403);
  assert.strictEqual(json.error.code, 'FORBIDDEN');
});

test('GET /:id path: a non-1146 DB error still → 500 (parity with LIST), now via the sendError envelope', async () => {
  const e = new Error('connection reset'); e.errno = 2013;
  queryQueue = [e];
  const { status, json } = await get(app({ id: 'u1', role: 'editor' }), '/bbbb0000-0000-0000-0000-000000000002');
  assert.strictEqual(status, 500);
  assert.strictEqual(json.data, null);
  assert.strictEqual(json.error.code, 'INTERNAL_ERROR');
  assert.strictEqual(json.error.message, 'Recipe read-scope probe failed');
});
