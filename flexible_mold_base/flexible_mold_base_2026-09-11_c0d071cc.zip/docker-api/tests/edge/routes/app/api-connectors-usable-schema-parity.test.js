// api-connectors-usable-schema-parity.test.js — the usable SELECT's widened
// join-subquery columns exist in the real DDL: api_connector_blueprints
// (connector_id, blueprint_id) + api_connectors (id, blueprint_id, is_active).
// Parses table-ddls.js with an identity `t` (logical table names), no live DB —
// a wrong column name stays green in the stubbed node:test route suite yet
// 500s in production.
const { describe, it, before } = require('node:test');
const assert = require('node:assert/strict');

const dbKey = require.resolve('../../../../src/edge/db');
require.cache[dbKey] = { id: dbKey, filename: dbKey, loaded: true, exports: { pool: {}, t: (n) => n } };
const { buildEngineTableDDLs } = require('../../../../src/table-ddls');

const SQL_TYPES = /^`?([a-z_]+)`?\s+(?:CHAR|VARCHAR|INT|DOUBLE|TIMESTAMP|JSON|TEXT|ENUM|BOOLEAN|TINYINT|BIGINT|DATETIME|DECIMAL|FLOAT|BLOB)\b/i;
let cols;
before(() => {
  cols = new Map();
  for (const ddl of buildEngineTableDDLs((n) => n)) {
    const m = ddl.match(/CREATE TABLE IF NOT EXISTS `([^`]+)`/);
    if (!m) continue;
    const set = new Set();
    for (const raw of ddl.split('\n')) {
      const line = raw.trim();
      if (!line || line.startsWith('--') || line.startsWith('/*')) continue;
      const cm = line.match(SQL_TYPES);
      if (cm) set.add(cm[1]);
    }
    cols.set(m[1], set);
  }
});

describe('usable-list SQL parity (bound-via-join widening)', () => {
  it('api_connector_blueprints has connector_id + blueprint_id (the bound-via-join subquery)', () => {
    const c = cols.get('api_connector_blueprints');
    assert.ok(c && c.has('connector_id') && c.has('blueprint_id'));
  });
  it('api_connectors has id, blueprint_id, is_active (the outer widened WHERE)', () => {
    const c = cols.get('api_connectors');
    assert.ok(c && c.has('id') && c.has('blueprint_id') && c.has('is_active'));
  });
  it('api_connectors has source_kind, source_config (the /usable projection, source_select_kind derivation)', () => {
    const c = cols.get('api_connectors');
    assert.ok(c && c.has('source_kind') && c.has('source_config'));
  });
});

describe('bindings write-guard + io.js cross-env carry SQL parity', () => {
  it('api_connectors has request_config, response_config (the write-guard effective-pair load)', () => {
    const c = cols.get('api_connectors');
    assert.ok(c && c.has('request_config') && c.has('response_config'));
  });
  it('blueprint_fields has blueprint_id + field_key (the write-guard completeness loader)', () => {
    const c = cols.get('blueprint_fields');
    assert.ok(c && c.has('blueprint_id') && c.has('field_key'));
  });
  it('transformers has id + output_keys (the write-guard transformer-output-keys resolve)', () => {
    const c = cols.get('transformers');
    assert.ok(c && c.has('id') && c.has('output_keys'));
  });
  it('api_connector_blueprints has id (io.js INSERT column list, alongside connector_id/blueprint_id)', () => {
    const c = cols.get('api_connector_blueprints');
    assert.ok(c && c.has('id'));
  });
  it('hierarchy_nodes has id, parent_id, name (io.js lineage-path resolution for extra bindings)', () => {
    const c = cols.get('hierarchy_nodes');
    assert.ok(c && c.has('id') && c.has('parent_id') && c.has('name'));
  });
});
