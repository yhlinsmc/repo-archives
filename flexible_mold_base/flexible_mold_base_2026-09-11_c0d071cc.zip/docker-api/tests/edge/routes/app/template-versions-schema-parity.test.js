'use strict';

/**
 * template-versions-schema-parity.test.js — the columns the version route
 * (template-versions.js) reads and writes, checked against the ACTUAL table
 * DDL in table-ddls.js, without a live DB. A mocked-query test alone (see
 * template-versions.test.js) stays green even if a column name here drifted
 * from the DDL — this test closes that gap for all five tables the route
 * touches: template_versions, flow_recipe_runs, user_templates, feature_audit
 * (the last is an INFRA table, so the manifest is built from
 * buildAllTableDDLs — buildEngineTableDDLs alone would miss it), and users
 * (fmb-1934 PR-6's actor_name enrichment, attachOwnerNames' own column set).
 */
const { describe, it, before } = require('node:test');
const assert = require('node:assert/strict');

const dbKey = require.resolve('../../../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: {}, t: (n) => n },
};

const { buildAllTableDDLs, ENGINE_TABLE_NAMES } = require('../../../../src/table-ddls');

const SQL_TYPES = /^`?([a-z_]+)`?\s+(?:CHAR|VARCHAR|INT|DOUBLE|TIMESTAMP|JSON|TEXT|ENUM|BOOLEAN|TINYINT|BIGINT|DATETIME|DECIMAL|FLOAT|BLOB|LONGTEXT)\b/i;

let columnsByTable;
let templateVersionsDdl;

before(() => {
  columnsByTable = new Map();
  for (const ddl of buildAllTableDDLs((n) => n)) {
    const m = ddl.match(/CREATE TABLE IF NOT EXISTS `([^`]+)`/);
    if (!m) continue;
    const table = m[1];
    const cols = new Set();
    for (const rawLine of ddl.split('\n')) {
      const line = rawLine.trim();
      if (!line || line.startsWith('--') || line.startsWith('/*')) continue;
      const cm = line.match(SQL_TYPES);
      if (cm) cols.add(cm[1]);
    }
    columnsByTable.set(table, cols);
    if (table === 'template_versions') templateVersionsDdl = ddl;
  }
});

describe('template_versions schema parity', () => {
  it('the table exists in the engine DDL set', () => {
    assert.ok(columnsByTable.has('template_versions'), 'template_versions was not found in buildAllTableDDLs()');
  });

  it('is registered in ENGINE_TABLE_NAMES (export/seed table list)', () => {
    assert.ok(ENGINE_TABLE_NAMES.includes('template_versions'));
  });

  it('has every column the route reads and writes', () => {
    const expected = [
      'id', 'template_id', 'name', 'note', 'kind', 'flow_run_id',
      'blueprint_id', 'variant_id', 'snapshot', 'actor_id', 'created_at',
    ];
    const cols = columnsByTable.get('template_versions');
    for (const col of expected) {
      assert.ok(cols.has(col), `template_versions is missing column '${col}'`);
    }
  });

  it('snapshot is LONGTEXT (unbounded-enough for a full form document)', () => {
    assert.match(templateVersionsDdl, /snapshot\s+LONGTEXT\s+NOT NULL/);
  });

  it('carries the template_id + created_at composite index the timeline sorts on', () => {
    assert.match(templateVersionsDdl, /INDEX idx_template_versions_template_time \(template_id, created_at\)/);
  });
});

// ── the OTHER three tables the route reads/writes: flow_recipe_runs
// (merged-timeline projection + restore/save-as source), user_templates
// (access-control read + restore's destructive UPDATE + save-as' INSERT),
// feature_audit (the restore trail). Each list is the route's OWN column
// set, restated here as a literal check against the parsed DDL — the same
// closing-the-gap reasoning as the block above, extended to every table this
// route names.
describe('template-versions.js — cross-table column parity', () => {
  it('flow_recipe_runs has every column the merged timeline / restore / save-as read', () => {
    const cols = columnsByTable.get('flow_recipe_runs');
    assert.ok(cols, 'flow_recipe_runs missing from the DDL manifest');
    for (const col of ['id', 'template_id', 'blueprint_id', 'actor_id', 'status', 'created_at', 'input_snapshot', 'output_snapshot']) {
      assert.ok(cols.has(col), `flow_recipe_runs is missing column '${col}'`);
    }
  });

  it('user_templates has every column the access check / restore / save-as read or write', () => {
    const cols = columnsByTable.get('user_templates');
    assert.ok(cols, 'user_templates missing from the DDL manifest');
    for (const col of [
      'id', 'owner_id', 'blueprint_id', 'variant_id', 'category_id', 'release_id',
      'schema_version', 'updated_at', 'payload', 'generated_outputs', 'name', 'parent_id', 'created_at',
      // F8 (P1) — the restore freshness guard's content fingerprint columns.
      'field_option_selection', 'computed_field_overrides', 'cleared_auto_fills',
    ]) {
      assert.ok(cols.has(col), `user_templates is missing column '${col}'`);
    }
  });

  it('feature_audit has every column the restore trail writes', () => {
    const cols = columnsByTable.get('feature_audit');
    assert.ok(cols, 'feature_audit missing from the DDL manifest');
    for (const col of ['id', 'event_type', 'user_id', 'metadata']) {
      assert.ok(cols.has(col), `feature_audit is missing column '${col}'`);
    }
  });

  // fmb-1934 PR-6: attachActorNames' attachOwnerNames call reads these three
  // columns off `users`, keyed by template_versions.actor_id /
  // flow_recipe_runs.actor_id — the same shared helper flow-recipe-runs/
  // aggregate.js and capacity/versions.js already use, so this parity check
  // is the one place a rename to any of the three would be caught statically.
  it('users has every column attachOwnerNames reads', () => {
    const cols = columnsByTable.get('users');
    assert.ok(cols, 'users missing from the DDL manifest');
    for (const col of ['id', 'display_name', 'kc_username']) {
      assert.ok(cols.has(col), `users is missing column '${col}'`);
    }
  });
});
