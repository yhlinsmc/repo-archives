// docker-api/tests/edge/routes/app/flow-recipe-steps-runs-on-conflict.test.js
//
// Amendment A2, forward direction: a step-save is rejected only when
// step_runs_on DIVERGES from the parent recipe's own runs_on (a different
// single mode); a step value that matches its recipe's mode, or 'both',
// reaches CRUD normally. Stubs the CRUD factory (as
// flow-recipe-steps-read-scope.test.js does) so this file isolates the new
// middleware from the factory's own write behaviour.
const { test, beforeEach } = require('node:test');
const assert = require('node:assert');
const express = require('express');
const { makeStubReqLog } = require('../../../helpers/stub-req-log');

let queryQueue = [];

require.cache[require.resolve('../../../../src/edge/db')] = {
  exports: {
    pool: {
      ro: {
        query: async () => {
          const v = queryQueue.length > 0 ? queryQueue.shift() : [];
          if (v instanceof Error) throw v;
          return v;
        },
      },
      rw: { getConnection: async () => ({ query: async () => [], release: () => {} }) },
    },
    t: (x) => x,
  },
};
require.cache[require.resolve('../../../../src/edge/routes/app/schema')] = {
  exports: { createCrudRoutes: () => (req, res) => res.json({ ok: true, reached: 'crud' }) },
};
const router = require('../../../../src/edge/routes/app/flow-recipe-steps');

function app(user) {
  const a = express(); a.use(express.json());
  a.use((req, _res, next) => { req.user = user; req.log = makeStubReqLog(); next(); }); // TEST-ONLY: production always sets req.log via createRequestId (request-id.js) before any router; this bare app has no such middleware.
  a.use('/', router);
  return a;
}
async function send(a, method, path, body) {
  const server = a.listen(0);
  try {
    const port = server.address().port;
    const res = await fetch(`http://127.0.0.1:${port}${path}`, {
      method, headers: { 'content-type': 'application/json' }, body: JSON.stringify(body || {}),
    });
    const json = await res.json().catch(() => ({}));
    return { status: res.status, json };
  } finally {
    server.close();
  }
}

const EDITOR = { id: 'u1', role: 'editor' };
const RECIPE_ID = 'aaaa0000-0000-0000-0000-000000000001';
const STEP_ID = 'bbbb0000-0000-0000-0000-000000000002';

// The mock queue is module-level; reset it before every test so a case that
// declares no rows starts empty rather than inheriting a prior test's leftovers.
beforeEach(() => { queryQueue = []; });

test('POST with step_runs_on diverging from the parent recipe mode → 400 FLOW_STEP_MODE_CONFLICT', async () => {
  queryQueue = [[{ runs_on: 'create' }]]; // recipe SELECT
  const { status, json } = await send(app(EDITOR), 'POST', '/', {
    recipe_id: RECIPE_ID, step_runs_on: 'update', name: 'S', url: 'https://x/', method: 'POST',
  });
  assert.strictEqual(status, 400);
  assert.strictEqual(json.error.code, 'FLOW_STEP_MODE_CONFLICT');
});

// Commander ruling (2026-09-10): the amendment blocks DIVERGENCE, not any
// non-'both' value — a step whose own value matches its recipe's single mode
// is redundant, not a conflict. This is the plan's own worked example ("PUT a
// step with runs_on='create' [matching a runs_on='create' recipe] -> 200").
test('POST with step_runs_on equal to the parent recipe mode → 200, reaches CRUD', async () => {
  queryQueue = [[{ runs_on: 'create' }]];
  const { json } = await send(app(EDITOR), 'POST', '/', {
    recipe_id: RECIPE_ID, step_runs_on: 'create', name: 'S', url: 'https://x/', method: 'POST',
  });
  assert.strictEqual(json.reached, 'crud');
});

test('POST with step_runs_on=both always reaches CRUD, regardless of the parent recipe', async () => {
  const { json } = await send(app(EDITOR), 'POST', '/', {
    recipe_id: RECIPE_ID, step_runs_on: 'both', name: 'S', url: 'https://x/', method: 'POST',
  });
  assert.strictEqual(json.reached, 'crud');
});

test('POST with no step_runs_on key at all reaches CRUD without any conflict probe', async () => {
  const { json } = await send(app(EDITOR), 'POST', '/', { recipe_id: RECIPE_ID, name: 'S', url: 'https://x/', method: 'POST' });
  assert.strictEqual(json.reached, 'crud');
  assert.strictEqual(queryQueue.length, 0, 'the probe must not have consumed a queued query');
});

test('PUT /:id resolves the parent via the stored row, not a caller-supplied recipe_id — parent runs_on=update, step diverges → 400', async () => {
  queryQueue = [
    [{ recipe_id: RECIPE_ID }], // step SELECT (own recipe_id)
    [{ runs_on: 'update' }], // recipe SELECT
  ];
  const { status, json } = await send(app(EDITOR), 'PUT', `/${STEP_ID}`, { step_runs_on: 'create' });
  assert.strictEqual(status, 400);
  assert.strictEqual(json.error.code, 'FLOW_STEP_MODE_CONFLICT');
});

test('PUT /:id with step_runs_on equal to the parent recipe value (update) → 200, reaches CRUD', async () => {
  queryQueue = [
    [{ recipe_id: RECIPE_ID }],
    [{ runs_on: 'update' }],
  ];
  const { json } = await send(app(EDITOR), 'PUT', `/${STEP_ID}`, { step_runs_on: 'update' });
  assert.strictEqual(json.reached, 'crud');
});

test('PUT /:id under a both-recipe accepts any per-step value', async () => {
  queryQueue = [
    [{ recipe_id: RECIPE_ID }],
    [{ runs_on: 'both' }],
  ];
  const { json } = await send(app(EDITOR), 'PUT', `/${STEP_ID}`, { step_runs_on: 'create' });
  assert.strictEqual(json.reached, 'crud');
});

// H1: recipe_id is PUT-mutable (crud-factory reparent), and a reparent that
// names NO step_runs_on still moves the stored trigger under a recipe whose
// single mode may differ. The gate must fire on recipe_id alone, resolve the
// stored trigger, and probe the NEW parent.
test('PUT recipe_id-only moving a stored update step under a create recipe → 400 pre-tx (reparent gated)', async () => {
  queryQueue = [
    [{ recipe_id: 'cccc0000-0000-0000-0000-000000000009', step_runs_on: 'update' }], // stored step trigger
    [{ runs_on: 'create' }], // NEW parent recipe
  ];
  const { status, json } = await send(app(EDITOR), 'PUT', `/${STEP_ID}`, {
    recipe_id: 'cccc0000-0000-0000-0000-000000000009',
  });
  assert.strictEqual(status, 400);
  assert.strictEqual(json.error.code, 'FLOW_STEP_MODE_CONFLICT');
});

test('PUT recipe_id-only moving a stored update step under a both recipe → 200, reaches CRUD', async () => {
  queryQueue = [
    [{ recipe_id: 'cccc0000-0000-0000-0000-000000000009', step_runs_on: 'update' }],
    [{ runs_on: 'both' }],
  ];
  const { json } = await send(app(EDITOR), 'PUT', `/${STEP_ID}`, {
    recipe_id: 'cccc0000-0000-0000-0000-000000000009',
  });
  assert.strictEqual(json.reached, 'crud');
});

test('a no-ALTER recipes table (errno 1146) fails closed with 403, not a silent pass-through', async () => {
  queryQueue = [Object.assign(new Error('no such table'), { errno: 1146 })];
  const { status, json } = await send(app(EDITOR), 'POST', '/', {
    recipe_id: RECIPE_ID, step_runs_on: 'update', name: 'S', url: 'https://x/', method: 'POST',
  });
  assert.strictEqual(status, 403);
  assert.strictEqual(json.error.code, 'FORBIDDEN');
});

// WORKAROUND: a version of the gate that acted only on FLOW_STEP_MODE_CONFLICT
// let a recipe row carrying an unrecognised runs_on (a degraded/no-ALTER
// install storing a value outside {create,update,both}) fall through to CRUD
// instead of the friendly 400 — only the in-tx hook's generic 500 stopped it.
test('PUT with a diverging step trigger against a recipe holding an unrecognised runs_on → 400 FLOW_RECIPE_MODE_INVALID', async () => {
  queryQueue = [
    [{ recipe_id: RECIPE_ID }], // step SELECT (own recipe_id)
    [{ runs_on: 'legacy-mode' }], // recipe SELECT — unrecognised value
  ];
  const { status, json } = await send(app(EDITOR), 'PUT', `/${STEP_ID}`, { step_runs_on: 'create' });
  assert.strictEqual(status, 400);
  assert.strictEqual(json.error.code, 'FLOW_RECIPE_MODE_INVALID');
});
