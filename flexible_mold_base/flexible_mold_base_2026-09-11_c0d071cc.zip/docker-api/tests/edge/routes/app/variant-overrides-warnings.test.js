/**
 * variant-overrides-warnings.test.js — POST /variant_overrides and PUT
 * /variant_overrides/:id return 200 + a `warnings` array carrying the
 * override-conflict catalogue text (spec §5: warn-but-allow, never a 4xx).
 * The DB module is stubbed (a real write path, mocked at the connection),
 * matching the harness variant-overrides-by-variants.test.js already uses for
 * this route file.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const { OVERRIDE_CONFLICT_MESSAGES } = require('../../../../src/shared/override-conflicts');

const dbKey = require.resolve('../../../../src/edge/db');

let queries;
let currentUser;
// The (variant, field) coherence + policy row buildVariantOverrideContextSql
// resolves to — coherent by default (same blueprint id on both sides), so
// each test only overrides the policy columns it cares about.
let contextRow;
let oldRow;
let insertResult;
let updateResult;
let finalRow;

function makeConn() {
  return {
    async query(sql, params) {
      queries.push({ sql, params });
      if (/SELECT DATABASE\(\)/i.test(sql)) return [{ db: 'testdb' }];
      // getActualColumnSet probe: empty rows -> colSet stays null (every key
      // passes gateKeysByColumnSet), matching a normal-mode schema.
      if (/information_schema\.COLUMNS/i.test(sql)) return [];
      // buildVariantOverrideContextSql — unique on this aliased output column.
      if (/AS variant_blueprint_id/i.test(sql)) return [contextRow];
      // isBlueprintLinked — never linked in these tests.
      if (/SELECT linked_blueprint_id FROM/i.test(sql)) return [];
      // PUT's linked-blueprint sweep over the touched variant ids.
      if (/SELECT parent_id FROM/i.test(sql) && /node_type = 'variant'/i.test(sql)) {
        return [{ parent_id: contextRow.variant_blueprint_id }];
      }
      if (/^\s*INSERT INTO/i.test(sql)) return insertResult;
      if (/^\s*UPDATE /i.test(sql)) return updateResult;
      if (/^\s*SELECT \*/i.test(sql)) return [finalRow];
      // PUT's old-row read.
      if (/^\s*SELECT id, variant_id, field_id, action/i.test(sql)) return [oldRow];
      return [];
    },
    release() {},
  };
}

require.cache[dbKey] = {
  id: dbKey,
  filename: dbKey,
  loaded: true,
  exports: {
    pool: {
      ro: { getConnection: async () => makeConn() },
      rw: { getConnection: async () => makeConn() },
    },
    t: (n) => `fmb_${n}`,
    getDynamicPool: async () => ({ rw: { getConnection: async () => makeConn() } }),
  },
};

const variantOverrides = require('../../../../src/edge/routes/app/schema/routes-variant-overrides');
const { _columnSetCache } = require('../../../../src/edge/routes/app/schema/helpers');

let server;
let baseUrl;

before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { req.user = currentUser; next(); });
  const router = express.Router();
  variantOverrides.register(router);
  app.use('/api/schema', router);
  server = http.createServer(app);
  await new Promise((resolve) => server.listen(0, resolve));
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});

after(async () => {
  if (server) await new Promise((resolve) => server.close(resolve));
});

beforeEach(() => {
  queries = [];
  // admin bypasses ownership, so a single coherent context row is enough for
  // every case here — only the conflict-relevant columns vary per test.
  currentUser = { id: 'u1', role: 'admin' };
  contextRow = {
    variant_blueprint_id: 'bp1',
    variant_node_type: 'variant',
    field_blueprint_id: 'bp1',
    field_type: 'text',
    is_required: 0,
    field_value_source: 'entered',
    retain_when_hidden: 0,
    blueprint_exists: 'bp1',
    blueprint_owner_id: null,
  };
  oldRow = { id: 'o1', variant_id: 'v1', field_id: 'f1', action: 'lock', cell_targets: null };
  insertResult = { affectedRows: 1 };
  updateResult = { affectedRows: 1 };
  finalRow = { id: 'o1', variant_id: 'v1', field_id: 'f1', action: 'lock', override_value: null, compute_rule: null, cell_targets: null, created_at: '2026-01-01' };
  _columnSetCache.clear();
});

async function post(body) {
  const res = await fetch(`${baseUrl}/api/schema/variant_overrides`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  return { status: res.status, body: await res.json() };
}

async function put(id, body) {
  const res = await fetch(`${baseUrl}/api/schema/variant_overrides/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  return { status: res.status, body: await res.json() };
}

describe('POST /variant_overrides — conflict warnings on 200', () => {
  it('autofill on a calculated field returns 200 with the autofill-over-calculated warning', async () => {
    contextRow.field_value_source = 'calculated';
    const r = await post({ variant_id: 'v1', field_id: 'f1', action: 'autofill', override_value: 'x' });
    assert.equal(r.status, 200);
    assert.deepEqual(r.body.data.warnings, [OVERRIDE_CONFLICT_MESSAGES.autofill_over_calculated]);
  });

  it('autofill on a legacy copied field returns 200 with the same warning', async () => {
    contextRow.field_value_source = 'copied';
    const r = await post({ variant_id: 'v1', field_id: 'f1', action: 'autofill', override_value: 'x' });
    assert.equal(r.status, 200);
    assert.deepEqual(r.body.data.warnings, [OVERRIDE_CONFLICT_MESSAGES.autofill_over_calculated]);
  });

  it('hide on a required field returns 200 with the hide-over-required warning', async () => {
    contextRow.is_required = 1;
    contextRow.retain_when_hidden = 0;
    const r = await post({ variant_id: 'v1', field_id: 'f1', action: 'hide' });
    assert.equal(r.status, 200);
    assert.deepEqual(r.body.data.warnings, [OVERRIDE_CONFLICT_MESSAGES.hide_over_required]);
  });

  it('hide on a required field with retain-when-hidden on returns 200 with no warnings', async () => {
    contextRow.is_required = 1;
    contextRow.retain_when_hidden = 1;
    const r = await post({ variant_id: 'v1', field_id: 'f1', action: 'hide' });
    assert.equal(r.status, 200);
    assert.equal(r.body.data.warnings, undefined);
  });

  it('a clean lock override returns 200 with no warnings key', async () => {
    const r = await post({ variant_id: 'v1', field_id: 'f1', action: 'lock' });
    assert.equal(r.status, 200);
    assert.equal(r.body.data.warnings, undefined);
  });
});

describe('PUT /variant_overrides/:id — conflict warnings on 200', () => {
  it('flipping an existing row to autofill on a calculated field returns 200 with the warning', async () => {
    contextRow.field_value_source = 'calculated';
    const r = await put('o1', { action: 'autofill', override_value: 'x' });
    assert.equal(r.status, 200);
    assert.deepEqual(r.body.data.warnings, [OVERRIDE_CONFLICT_MESSAGES.autofill_over_calculated]);
  });

  it('flipping an existing row to hide on a required field returns 200 with the warning', async () => {
    contextRow.is_required = 1;
    contextRow.retain_when_hidden = 0;
    const r = await put('o1', { action: 'hide' });
    assert.equal(r.status, 200);
    assert.deepEqual(r.body.data.warnings, [OVERRIDE_CONFLICT_MESSAGES.hide_over_required]);
  });

  it('a clean lock update returns 200 with no warnings key', async () => {
    const r = await put('o1', { action: 'lock' });
    assert.equal(r.status, 200);
    assert.equal(r.body.data.warnings, undefined);
  });

  // G-C1: an empty body (after the route strips id/db) has no keys to SET,
  // so the handler takes the no-op branch — the warning is judged on the
  // STORED action, since the body names none.
  it('an empty-body no-op PUT still returns the warning for the stored conflict', async () => {
    oldRow.action = 'hide';
    finalRow.action = 'hide';
    contextRow.is_required = 1;
    contextRow.retain_when_hidden = 0;
    const r = await put('o1', {});
    assert.equal(r.status, 200);
    assert.deepEqual(r.body.data.warnings, [OVERRIDE_CONFLICT_MESSAGES.hide_over_required]);
  });
});
