/**
 * flow-recipe-steps-preset-config-schema-parity.test.js — the Merge-by-key
 * preset column (PR-C3, fmb-2099) exists as a JSON column on flow_recipe_steps
 * AND is registered in the DTO mapper's JSON list for that table, so the CRUD
 * factory parses it on read and stringifies it on write. A mocked write path
 * would hide either a missing column or an unregistered JSON column (a preset
 * stored as "[object Object]" or read back as a raw string); this test closes
 * that gap without a live DB.
 */
const { describe, it, before } = require('node:test');
const assert = require('node:assert/strict');
const { buildEngineTableDDLs } = require('../../../../src/table-ddls');
const { getRegistry } = require('../../../../src/edge/lib/dto-mapper');

let jsonCols;
before(() => {
  const ddl = buildEngineTableDDLs((n) => n).find((d) => /`flow_recipe_steps`/.test(d));
  jsonCols = new Set(
    [...ddl.matchAll(/^\s*`?([a-z_]+)`?\s+JSON\b/gim)].map((m) => m[1]),
  );
});

describe('flow_recipe_steps.preset_config schema parity', () => {
  it('declares preset_config as a JSON column in the DDL', () => {
    assert.ok(jsonCols.has('preset_config'), 'preset_config missing or not a JSON column');
  });

  it('registers preset_config in the DTO mapper JSON list (parse on read / stringify on write)', () => {
    const registry = getRegistry();
    const entry = registry.flow_recipe_steps;
    assert.ok(entry, 'flow_recipe_steps has no DTO registry entry');
    assert.ok(
      Array.isArray(entry.json) && entry.json.includes('preset_config'),
      'preset_config is not in the flow_recipe_steps JSON column registry',
    );
  });

  it('every registered JSON column for the table actually exists in the DDL', () => {
    const registry = getRegistry();
    for (const col of registry.flow_recipe_steps.json) {
      assert.ok(jsonCols.has(col), `${col} is registered as JSON but is not a JSON column in the DDL`);
    }
  });
});
