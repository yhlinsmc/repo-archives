/**
 * flow-recipes-link-extract-kind.test.js — link_extract/external_id_extract
 * union coercion (serializer.js's normalizeExtractSpec) and the link-compose
 * template resolver (flow-extract.js's resolveLinkTemplate), WITHOUT a live
 * DB — pure functions only (spec Q15/Q16: capture-ids + link compose mode).
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');

const { normalizeExtractSpec } = require('../../../../src/edge/routes/app/flow-recipes/serializer');
const { extractFlowResult, resolveLinkTemplate } = require('../../../../src/shared/lib/flow-extract');

describe('normalizeExtractSpec — FlowExtractSpec union coercion', () => {
  it('passes a bare legacy string through unchanged', () => {
    assert.equal(normalizeExtractSpec('$.data.id'), '$.data.id');
  });

  it('passes a legacy untagged { path } object through unchanged', () => {
    assert.deepEqual(normalizeExtractSpec({ path: 'a.b' }), { path: 'a.b' });
  });

  it('accepts the tagged { kind:"path", path } shape', () => {
    assert.deepEqual(normalizeExtractSpec({ kind: 'path', path: 'a.b' }), { kind: 'path', path: 'a.b' });
  });

  it('accepts the tagged { kind:"template", template } shape', () => {
    assert.deepEqual(
      normalizeExtractSpec({ kind: 'template', template: 'wf/{{external_id}}' }),
      { kind: 'template', template: 'wf/{{external_id}}' },
    );
  });

  it('rejects an unrecognized kind, an array, and a path-less object — all coerce to null', () => {
    assert.equal(normalizeExtractSpec({ kind: 'bogus', path: 'a.b' }), null);
    assert.equal(normalizeExtractSpec(['a.b']), null);
    assert.equal(normalizeExtractSpec({}), null);
    assert.equal(normalizeExtractSpec(42), null);
  });

  it('a template spec round-trips read -> write -> read unchanged', () => {
    const stored = { kind: 'template', template: 'https://x/{{external_id}}' };
    const written = normalizeExtractSpec(stored);
    // Simulate the DB round trip: JSON.stringify on write, JSON.parse on read.
    const reread = normalizeExtractSpec(JSON.parse(JSON.stringify(written)));
    assert.deepEqual(reread, stored);
  });

  it('a legacy { path } row still decodes to a path via extractFlowResult', () => {
    const result = extractFlowResult('{"data":{"link":"http://x/1"}}', {
      link_extract: { path: 'data.link' },
    });
    assert.equal(result.link, 'http://x/1');
  });
});

describe('resolveLinkTemplate', () => {
  it('fills {{external_id}} and {{response.<path>}} tokens', () => {
    assert.equal(
      resolveLinkTemplate('wf/{{external_id}}/{{response.workflow.id}}', {
        external_id: '99',
        response: { workflow: { id: 7 } },
        ctx: {},
      }),
      'wf/99/7',
    );
  });

  it('fills {{ctx.<key>}} tokens', () => {
    assert.equal(
      resolveLinkTemplate('{{ctx.tenant}}/x', { external_id: null, response: {}, ctx: { tenant: 'acme' } }),
      'acme/x',
    );
  });

  it('an unknown token resolves to empty string, never throws', () => {
    assert.doesNotThrow(() => resolveLinkTemplate('a/{{nope}}/b', { external_id: null, response: {}, ctx: {} }));
    assert.equal(resolveLinkTemplate('a/{{nope}}/b', { external_id: null, response: {}, ctx: {} }), 'a//b');
  });

  it('blocks a prototype-pollution token the same way pathGet does', () => {
    assert.equal(
      resolveLinkTemplate('{{response.__proto__.polluted}}', { external_id: null, response: {}, ctx: {} }),
      '',
    );
  });

  it('extractFlowResult resolves a stored template-kind link_extract at finalize', () => {
    const result = extractFlowResult('{"workflow":{"id":7}}', {
      link_extract: { kind: 'template', template: 'https://x/{{external_id}}/{{response.workflow.id}}' },
      external_id_extract: null,
    });
    // extractFlowResult has no external_id resolved yet for its OWN link
    // resolution pass in this unit test (no external_id_extract supplied) —
    // {{external_id}} renders empty, {{response.*}} still resolves.
    assert.equal(result.link, 'https://x//7');
  });

  // H3 (PR-C2 contract note): the finalize handler never receives client ctx
  // (server-trust boundary) — extractFlowResult always passes ctx: {}, so a
  // stored {{ctx.*}} token can never actually fill here, on the one real call
  // path that resolves a template kind at run time.
  it('extractFlowResult never fills {{ctx.*}} — no client-trusted ctx source at finalize', () => {
    const result = extractFlowResult('{}', {
      link_extract: { kind: 'template', template: 'https://x/{{ctx.tenant}}' },
      external_id_extract: null,
    });
    assert.equal(result.link, 'https://x/');
  });

  // A step-emit override lands as an unparseable/empty upstream body when the
  // finalize step itself returns no body — the template must still compose
  // instead of going dark just because the body could not be JSON.parse'd.
  it('a template-kind link_extract still composes against an emitted external_id when the body is empty', () => {
    const result = extractFlowResult('', {
      link_extract: { kind: 'template', template: 'https://x/{{external_id}}' },
      external_id_extract: null,
    }, { externalId: 'EMITTED-9' });
    assert.deepEqual(result, { link: 'https://x/EMITTED-9', externalId: null });
  });

  it('a {{response.*}} token in a template spec resolves to empty string when the body is not JSON, never blocking the rest of the template', () => {
    const result = extractFlowResult('Internal Server Error', {
      link_extract: { kind: 'template', template: 'https://x/{{response.a}}/tail' },
      external_id_extract: null,
    });
    assert.deepEqual(result, { link: 'https://x//tail', externalId: null });
  });

  it('a {path} spec on an empty body is unchanged — still null (byte-identical to the pre-fix early return)', () => {
    const result = extractFlowResult('', {
      link_extract: { path: 'url' },
      external_id_extract: { path: 'id' },
    });
    assert.deepEqual(result, { link: null, externalId: null });
  });
});
