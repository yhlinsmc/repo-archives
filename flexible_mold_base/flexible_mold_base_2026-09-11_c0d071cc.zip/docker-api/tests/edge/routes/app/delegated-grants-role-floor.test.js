'use strict';

/**
 * delegated-grants-role-floor.test.js — "may this caller grant on this subject"
 * gains a role floor on the owner arm (spec §7.1): admin always; an owner only
 * when their role is editor or above; a plain-user owner is refused server-side.
 * callerOwnsSubject guards GET/POST/DELETE on /delegated-grants, so the floor is
 * the one server-side authority the FE menu rule cannot be trusted to enforce.
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');

const dbKey = require.resolve('../../../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey,
  filename: dbKey,
  loaded: true,
  exports: {
    pool: { ro: null, rw: null },
    t: (n) => `fmb_${n}`,
    getDynamicPool: async () => ({ ro: null, rw: null }),
  },
};

const { __test__ } = require('../../../../src/edge/routes/app/delegated-grants');
const { callerOwnsSubject } = __test__;

// sameStoredValue short-circuits on identical id strings, so no query runs for
// the owner-match cases below.
const conn = { query: async () => { throw new Error('no query expected'); } };

describe('callerOwnsSubject — grant-authority role floor (spec §7.1)', () => {
  it('admin: true regardless of the floor (both scopes)', async () => {
    assert.equal(await callerOwnsSubject(conn, 'blueprint', { id: 'a', role: 'admin' }, 'ownerX'), true);
    assert.equal(await callerOwnsSubject(conn, 'template', { id: 'a', role: 'admin' }, 'ownerX'), true);
  });
  it('an editor owner: true (both scopes)', async () => {
    assert.equal(await callerOwnsSubject(conn, 'blueprint', { id: 'u1', role: 'editor' }, 'u1'), true);
    assert.equal(await callerOwnsSubject(conn, 'template', { id: 'u1', role: 'editor' }, 'u1'), true);
  });
  it('a plain-user owner: false — cannot grant even on their own subject (both scopes)', async () => {
    assert.equal(await callerOwnsSubject(conn, 'blueprint', { id: 'u1', role: 'user' }, 'u1'), false);
    assert.equal(await callerOwnsSubject(conn, 'template', { id: 'u1', role: 'user' }, 'u1'), false);
  });
  it('the floor is checked before ownership — a plain-user is refused without a query', async () => {
    assert.equal(await callerOwnsSubject(conn, 'blueprint', { id: 'u1', role: 'user' }, 'someoneElse'), false);
  });
});
