/**
 * flow-recipe-steps-content-type-backfill-schema-parity.test.js — validates
 * every column the flow_recipe_steps.content_type backfill migration
 * references against the ACTUAL table DDL, WITHOUT a live DB.
 *
 * The backfill is a boot-time UPDATE that copies a YAML recipe's dialect onto
 * its steps (migration-steps.js `flow_recipe_steps_content_type_backfill`).
 * It names its columns literally, so a wrong column name is an unknown-column
 * error at boot on exactly the databases that carry legacy YAML recipes — and
 * no mocked runner reaches it. This test parses table-ddls.js and asserts the
 * statement's referenced columns exist, reading the REAL statement out of the
 * registry's own `remediationSql` rather than restating a hand-copied column
 * list (a second list can agree with the DDL while the first does not — the
 * failure this guards; same shape as
 * capacity-vm-site-backfill-schema-parity.test.js).
 *
 * ALLOWLIST: flow_recipes.content_type was retired from table-ddls.js by
 * PR-YZ Task Z.0 (fmb-2062) — the drop's own precondition (Y2.6c ruling)
 * requires this backfill to have ALREADY run on any database it drops the
 * column from, so this statement's reference to the now-undeclared column is
 * historically valid, not stale: `KNOWN_LEGACY_COLUMNS` names exactly that
 * one exception so a genuinely wrong column name elsewhere in the statement
 * still fails this test.
 */
const { describe, it, before } = require('node:test');
const assert = require('node:assert/strict');

const { buildEngineTableDDLs } = require('../../../../src/table-ddls');
const { MIGRATION_STEPS } = require('../../../../src/edge/migration-steps');

const SQL_TYPES = /^`?([a-z_]+)`?\s+(?:CHAR|VARCHAR|INT|DOUBLE|TIMESTAMP|JSON|TEXT|ENUM|BOOLEAN|TINYINT|BIGINT|DATETIME|DECIMAL|FLOAT|BLOB)\b/i;
let columnsByTable;

before(() => {
  columnsByTable = new Map();
  for (const ddl of buildEngineTableDDLs((n) => n)) {
    const m = ddl.match(/CREATE TABLE IF NOT EXISTS `([^`]+)`/);
    if (!m) continue;
    const cols = new Set();
    for (const rawLine of ddl.split('\n')) {
      const line = rawLine.trim();
      if (!line || line.startsWith('--') || line.startsWith('/*')) continue;
      const cm = line.match(SQL_TYPES);
      if (cm) cols.add(cm[1]);
    }
    columnsByTable.set(m[1], cols);
  }
});

// See the ALLOWLIST note in the file header — the ONLY column this test
// accepts despite table-ddls.js no longer declaring it.
const KNOWN_LEGACY_COLUMNS = new Set(['flow_recipes.content_type']);

// alias → physical table, taken from the statement's own UPDATE/JOIN clauses.
function aliasesOf(statement) {
  const map = new Map();
  for (const m of statement.matchAll(/(?:UPDATE|JOIN)\s+`([a-z_]+)`\s+(\w+)\b/g)) {
    map.set(m[2], m[1]);
  }
  return map;
}

describe('flow_recipe_steps.content_type backfill — schema parity', () => {
  const entry = MIGRATION_STEPS.find((s) => s.step === 'flow_recipe_steps_content_type_backfill');
  const statements = entry ? entry.remediationSql((n) => n) : [];
  const statement = statements[0] || '';
  const aliasTable = aliasesOf(statement);

  it('the registry still carries the backfill entry', () => {
    assert.ok(entry, 'migration-steps.js no longer declares flow_recipe_steps_content_type_backfill');
    assert.equal(entry.kind, 'custom');
    assert.equal(typeof entry.probe, 'function');
    assert.equal(typeof entry.remediationSql, 'function');
  });

  it('reads flow_recipe_steps and flow_recipes under an alias, so there is something to check', () => {
    assert.deepEqual([...aliasTable.values()].sort(), ['flow_recipe_steps', 'flow_recipes']);
  });

  it('every aliased column the statement names exists on the table it names it on', () => {
    const refs = [...statement.matchAll(/\b(\w+)\.(\w+)\b/g)]
      .filter(([, alias]) => aliasTable.has(alias))
      .map(([, alias, column]) => ({ table: aliasTable.get(alias), column }));
    // Guard the parse itself: s.recipe_id, r.id, s.content_type, r.content_type at least.
    assert.ok(refs.length >= 4, `only ${refs.length} column references found — the parse has stopped working`);
    for (const { table, column } of refs) {
      if (KNOWN_LEGACY_COLUMNS.has(`${table}.${column}`)) continue;
      const cols = columnsByTable.get(table);
      assert.ok(cols, `statement names unknown table ${table}`);
      assert.ok(
        cols.has(column),
        `${table} has no column '${column}' — the backfill would 500 at boot while every mocked test stayed green`,
      );
    }
  });

  it('copies onto a step only when the recipe is YAML and the step still holds the JSON default', () => {
    // The narrow WHERE is what makes the step idempotent (a re-run finds nothing
    // pending) and safe on a JSON recipe (whose steps already hold the matching
    // default and are never touched).
    assert.match(statement, /r\.content_type = 'application\/yaml'/);
    assert.match(statement, /s\.content_type = 'application\/json'/);
    assert.match(statement, /SET s\.content_type = 'application\/yaml'/);
  });

  it('joins steps to their own recipe, not a foreign one', () => {
    assert.match(statement, /s\.recipe_id = r\.id/);
  });
});
