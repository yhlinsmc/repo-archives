/**
 * table-column-compute-rule-audit-schema-parity.test.js — validates the
 * columns the new legacy audit scan (routes-orphans.js,
 * scanTableColumnComputeRuleAudit, fmb-1942) SELECTs from blueprint_fields
 * against the ACTUAL DDL, WITHOUT a live DB. The node:test mocks stub query
 * results, so a mistyped column stays green in both runners and only 500s
 * the audit report in production.
 */
const { describe, it, before } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

// routes-orphans.js destructures a large surface from ./helpers at load;
// stub the db module so the require chain is side-effect-free (no pool).
const dbKey = require.resolve('../../../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: {}, t: (n) => n, getDynamicPool: async () => ({}) },
};

const { buildEngineTableDDLs } = require('../../../../src/table-ddls');

const SQL_TYPES = /^`?([a-z_]+)`?\s+(?:CHAR|VARCHAR|INT|DOUBLE|TIMESTAMP|JSON|TEXT|ENUM|BOOLEAN|TINYINT|BIGINT|DATETIME|DECIMAL|FLOAT|BLOB)\b/i;
let blueprintFieldsCols;

before(() => {
  for (const ddl of buildEngineTableDDLs((n) => n)) {
    if (!ddl.includes('CREATE TABLE IF NOT EXISTS `blueprint_fields`')) continue;
    const cols = new Set();
    for (const rawLine of ddl.split('\n')) {
      const line = rawLine.trim();
      if (!line || line.startsWith('--') || line.startsWith('/*') || line.startsWith('*')) continue;
      const cm = line.match(SQL_TYPES);
      if (cm) cols.add(cm[1]);
    }
    blueprintFieldsCols = cols;
  }
  assert.ok(blueprintFieldsCols && blueprintFieldsCols.size > 0, 'no columns parsed for blueprint_fields');
});

const ORPHANS_SRC = fs.readFileSync(
  path.resolve(__dirname, '../../../../src/edge/routes/app/schema/routes-orphans.js'), 'utf8',
);

describe('table-column compute-rule audit SQL — schema parity', () => {
  it('the audit scan SELECT names only real blueprint_fields columns', () => {
    const m = ORPHANS_SRC.match(
      /SELECT\s+(id, blueprint_id, field_key, field_type, table_config)\s+FROM\s+\\?`\$\{t\(TABLES\.BLUEPRINT_FIELDS\)\}/,
    );
    assert.ok(m, 'the table-column compute-rule audit SELECT is gone or reshaped — update this parser');
    const named = m[1].split(',').map((s) => s.trim());
    assert.ok(named.length >= 5, `only ${named.length} SELECT columns parsed — the parse has stopped working`);
    for (const col of named) {
      assert.ok(blueprintFieldsCols.has(col), `audit SELECT names '${col}', absent from blueprint_fields DDL`);
    }
  });
});
