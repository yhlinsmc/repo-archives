/**
 * variant-overrides-warnings-schema-parity.test.js — the conflict-warning
 * computation in routes-variant-overrides.js reads `is_required`,
 * `value_source` and `retain_when_hidden` off the extended
 * buildVariantOverrideContextSql SELECT, WITHOUT a live DB. Modeled on
 * capacity-delete-preview-schema-parity.test.js: parse table-ddls.js into a
 * column set per table and check every column the SQL references against it,
 * so a renamed or dropped blueprint_fields column 500s the write instead of
 * staying green in a mocked runner.
 */
const { describe, it, before } = require('node:test');
const assert = require('node:assert/strict');

const { buildEngineTableDDLs } = require('../../../../src/table-ddls');
const { TABLES } = require('../../../../src/shared/constants');
const { buildVariantOverrideContextSql } = require('../../../../src/edge/lib/variant-override-helpers');

const SQL_TYPES = /^`?([a-z_]+)`?\s+(?:CHAR|VARCHAR|INT|DOUBLE|TIMESTAMP|JSON|TEXT|ENUM|BOOLEAN|TINYINT|BIGINT|DATETIME|DECIMAL|FLOAT|BLOB)\b/i;
let columnsByTable;

before(() => {
  columnsByTable = new Map();
  for (const ddl of buildEngineTableDDLs((n) => n)) {
    const m = ddl.match(/CREATE TABLE IF NOT EXISTS `([^`]+)`/);
    if (!m) continue;
    const table = m[1];
    const cols = new Set();
    for (const rawLine of ddl.split('\n')) {
      const line = rawLine.trim();
      if (!line || line.startsWith('--') || line.startsWith('/*')) continue;
      const cm = line.match(SQL_TYPES);
      if (cm) cols.add(cm[1]);
    }
    columnsByTable.set(table, cols);
  }
});

describe('variant-override context SQL — schema parity for the conflict-warning read', () => {
  it('parses a column set for blueprint_fields', () => {
    const cols = columnsByTable.get(TABLES.BLUEPRINT_FIELDS);
    assert.ok(cols && cols.size > 0);
  });

  it('the extended context SQL names is_required, value_source and retain_when_hidden on the f alias', () => {
    const sql = buildVariantOverrideContextSql({ t: (n) => n, TABLES });
    assert.match(sql, /f\.is_required/);
    assert.match(sql, /f\.value_source/);
    assert.match(sql, /f\.retain_when_hidden/);
  });

  it('every column the context SQL reads off blueprint_fields exists in table-ddls.js', () => {
    const cols = columnsByTable.get(TABLES.BLUEPRINT_FIELDS);
    for (const col of ['blueprint_id', 'field_type', 'is_required', 'value_source', 'retain_when_hidden']) {
      assert.ok(cols.has(col), `blueprint_fields has no column '${col}' — the conflict-warning read would 500`);
    }
  });
});
