'use strict';

/**
 * schema-field-rename-effective-blueprint-schema-parity.test.js — the columns
 * `resolveEffectiveBlueprintIds` and the rename/impact-preview statements it
 * feeds reference, checked against the DDL, without a database.
 *
 * (fmb-1498) The rename's key-move UPDATE and the impact-preview SELECT scope
 * `user_templates` by an IN-list resolved from `hierarchy_nodes` rather than a
 * `hierarchy_nodes` JOIN inline in the statement (non-sargable against
 * `idx_user_templates_blueprint` — see the module comment in
 * routes-field-ops.js). A misspelled column in either the resolver or the two
 * statements it feeds is an unknown-column 500 no mocked router-test double can
 * see, so this reads the actual source rather than restating its columns by
 * hand — a hand-copied list agrees with the statement right up until the
 * statement is edited.
 */
const { describe, it, before } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const dbKey = require.resolve('../../../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: {}, t: (n) => n },
};

const { buildEngineTableDDLs } = require('../../../../src/table-ddls');
const { TABLES } = require('../../../../src/shared/constants');

const SQL_TYPES = /^`?([a-z_]+)`?\s+(?:CHAR|VARCHAR|INT|DOUBLE|TIMESTAMP|JSON|TEXT|ENUM|BOOLEAN|TINYINT|BIGINT|DATETIME|DECIMAL|FLOAT|BLOB)\b/i;
let columnsByTable;

before(() => {
  columnsByTable = new Map();
  for (const ddl of buildEngineTableDDLs((n) => n)) {
    const m = ddl.match(/CREATE TABLE IF NOT EXISTS `([^`]+)`/);
    if (!m) continue;
    const cols = new Set();
    for (const rawLine of ddl.split('\n')) {
      const line = rawLine.trim();
      if (!line || line.startsWith('--') || line.startsWith('/*')) continue;
      const cm = line.match(SQL_TYPES);
      if (cm) cols.add(cm[1]);
    }
    columnsByTable.set(m[1], cols);
  }
});

const SOURCE = fs.readFileSync(
  path.resolve(__dirname, '../../../../src/edge/routes/app/schema/routes-field-ops.js'),
  'utf-8',
);

/** The body of a named function, read out of the source rather than restated. */
function functionBody(signature, endMarker) {
  const start = SOURCE.indexOf(signature);
  assert.ok(start > 0, `routes-field-ops.js no longer declares: ${signature}`);
  const end = SOURCE.indexOf(endMarker, start);
  assert.ok(end > start, `${signature} no longer ends where this test looks`);
  return SOURCE.slice(start, end);
}

describe('resolveEffectiveBlueprintIds — columns exist', () => {
  const body = functionBody('async function resolveEffectiveBlueprintIds', 'return [...new Set');

  it('reads a real column off hierarchy_nodes', () => {
    const cols = columnsByTable.get(String(TABLES.HIERARCHY_NODES));
    assert.ok(cols && cols.size > 0, 'no columns parsed for hierarchy_nodes');
    const refs = [...body.matchAll(/SELECT ([a-z_]+) FROM/g)].map((m) => m[1]);
    assert.ok(refs.length > 0, 'the parse found no SELECTed column — it has stopped working');
    for (const col of refs) {
      assert.ok(cols.has(col), `hierarchy_nodes has no column '${col}'`);
    }
    // Both predicates the TOCTOU fix's row-lock argument depends on: `id = ?`
    // locks the field's own blueprint row, `linked_blueprint_id = ?` locks
    // every row currently linking to it.
    assert.match(body, /WHERE id = \? OR linked_blueprint_id = \?/, 'no longer filters on id or linked_blueprint_id');
    assert.ok(cols.has('id'), 'hierarchy_nodes has no column \'id\'');
    assert.ok(cols.has('linked_blueprint_id'), 'hierarchy_nodes has no column \'linked_blueprint_id\'');
  });

  it('the locking variant appends a real FOR UPDATE, not a typo\'d one', () => {
    assert.match(body, /\$\{forUpdate \? ' FOR UPDATE' : ''\}/, 'the FOR UPDATE conditional is gone or reshaped');
  });
});

describe('rename UPDATE and impact-preview SELECT — columns exist', () => {
  it('every column named in the rename UPDATE (buildKeyRenameUpdate) exists on user_templates', () => {
    const body = functionBody('function buildKeyRenameUpdate', 'function register');
    const cols = columnsByTable.get(String(TABLES.USER_TEMPLATES));
    assert.match(body, /WHERE blueprint_id IN/, 'no longer scopes by an IN-list — this test targets the wrong shape');
    assert.ok(cols.has('blueprint_id'), 'user_templates has no column \'blueprint_id\'');
  });

  it('every column named in the impact-preview SELECT exists on user_templates', () => {
    const body = functionBody("router.get('/impact/:fieldId'", "router.post('/rename/:fieldId'");
    const cols = columnsByTable.get(String(TABLES.USER_TEMPLATES));
    // The source's own backticks around `${t(...)}` are escaped (`\``, a
    // literal backslash-backtick pair inside the template literal), so the
    // pattern allows an optional backslash before each one.
    const refs = [...body.matchAll(/SELECT ([a-z_]+, [a-z_]+) FROM \\?`\$\{t\(TABLES\.USER_TEMPLATES\)\}\\?`/g)];
    assert.ok(refs.length === 1, 'the impact-preview SELECT is no longer where this test looks for it');
    for (const col of refs[0][1].split(', ')) {
      assert.ok(cols.has(col), `user_templates has no column '${col}'`);
    }
    assert.match(body, /WHERE blueprint_id IN/, 'no longer scopes by an IN-list — this test targets the wrong shape');
    for (const col of ['payload', 'blueprint_id']) {
      assert.ok(cols.has(col), `user_templates has no column '${col}'`);
    }
  });
});
