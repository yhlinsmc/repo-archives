// docker-api/tests/edge/routes/app/flow-run-groups.test.js
//
// The grouped run history: one row per template, what it counts, and the two
// groups that have no template row behind them.
const { test } = require('node:test');
const { makeStubReqLog } = require('../../../helpers/stub-req-log');
const assert = require('node:assert');
const express = require('express');

// Every statement the route issues, in order, so a test can assert on the SQL
// itself — the visibility predicate and the page bounds are properties of the
// statement, not of the stubbed rows.
let issued = [];
let responder = () => [];

require.cache[require.resolve('../../../../src/edge/db')] = {
  exports: {
    pool: {
      ro: {
        getConnection: async () => ({
          query: async (sql, params) => {
            issued.push({ sql, params });
            const out = responder(sql, params);
            if (out instanceof Error) throw out;
            return out;
          },
          release: () => {},
        }),
      },
      rw: { getConnection: async () => ({ query: async () => [], release: () => {} }) },
    },
    t: (x) => x,
  },
};

const { router } = require('../../../../src/edge/routes/app/flow-recipe-runs/aggregate');

function app(user) {
  const a = express();
  a.use((req, _res, next) => { req.log = makeStubReqLog(); next(); }); // TEST-ONLY: production always sets req.log via createRequestId (request-id.js) before any router; this bare app has no such middleware, so a route's req.log.<level>() call would otherwise throw against undefined.
  a.use(express.json());
  a.use((req, _res, next) => { if (user) req.user = user; next(); });
  a.use('/', router);
  return a;
}

async function get(a, path) {
  const server = a.listen(0);
  try {
    const { port } = server.address();
    const res = await fetch(`http://127.0.0.1:${port}${path}`);
    const json = await res.json().catch(() => ({}));
    return { status: res.status, json };
  } finally {
    // Closed on the throwing path too. With the close reachable only where
    // nothing threw, a failed assertion leaks this handle, the runner never
    // exits, and the job reports a timeout instead of the assertion that failed.
    server.close();
  }
}

const ADMIN = { id: 'aaaaaaaa-0000-0000-0000-000000000001', role: 'admin' };
const USER = { id: 'bbbbbbbb-0000-0000-0000-000000000002', role: 'user' };
const TEMPLATE_A = '11111111-1111-1111-1111-111111111111';
const TEMPLATE_GONE = '22222222-2222-2222-2222-222222222222';

/** A stub that answers each statement by what it is asking for. */
function stub({ groups = [], total = 0, users = [] } = {}) {
  return (sql) => {
    // The count statement now shares the windowed base the grouped read uses
    // (so a filtered total can never describe a wider set than the filtered
    // page — see `buildGroupBaseSql`), so it ALSO contains 'ROW_NUMBER()'.
    // The count check must run first or every count query would be answered
    // with the row fixture instead of `{ cnt }`.
    if (sql.includes('COUNT(*) AS cnt')) return [{ cnt: total }];
    if (sql.includes('ROW_NUMBER()')) return groups;
    if (sql.includes('SELECT id, display_name, kc_username')) return users;
    return [];
  };
}

/** A row as the grouped statement returns it: the window pass's own fields plus
 *  the joined template's, which are NULL when the template no longer exists. */
function groupRow(over) {
  return {
    template_id: TEMPLATE_A,
    run_count: 3,
    last_run_at: '2026-07-20 09:30:00',
    last_run_id: 'cccccccc-0000-0000-0000-000000000003',
    last_status: 'success',
    last_actor_id: USER.id,
    template_row_id: TEMPLATE_A,
    template_name: 'Nightly build',
    template_blueprint_id: 'bp',
    template_variant_id: 'var',
    ...over,
  };
}

/** The joined template columns as they arrive for a group with no template row. */
const NO_TEMPLATE_ROW = {
  template_row_id: null,
  template_name: null,
  template_blueprint_id: null,
  template_variant_id: null,
};

test.beforeEach(() => { issued = []; responder = stub(); });

test('a group carries its count, its last run and its template name', async () => {
  responder = stub({
    groups: [groupRow()],
    total: 1,
    users: [{ id: USER.id, display_name: 'Ada', kc_username: 'ada' }],
  });
  const { status, json } = await get(app(ADMIN), '/groups');
  assert.strictEqual(status, 200);
  const [row] = json.data.rows;
  assert.strictEqual(row.template_id, TEMPLATE_A);
  assert.strictEqual(row.template_name, 'Nightly build');
  assert.strictEqual(row.template_exists, true);
  assert.strictEqual(row.run_count, 3);
  assert.strictEqual(row.last_status, 'success');
  assert.strictEqual(row.last_actor_name, 'Ada');
  assert.strictEqual(json.data.total, 1);
});

test('a timestamp reaches the client pinned to UTC, not as the driver spelling', async () => {
  responder = stub({ groups: [groupRow()], total: 1 });
  const { json } = await get(app(ADMIN), '/groups');
  assert.strictEqual(json.data.rows[0].last_run_at, '2026-07-20T09:30:00Z');
});

test('a group whose template was deleted keeps its runs and says the template is gone', async () => {
  responder = stub({
    // The join found no template row for this id.
    groups: [groupRow({ template_id: TEMPLATE_GONE, ...NO_TEMPLATE_ROW })],
    total: 1,
  });
  const { json } = await get(app(ADMIN), '/groups');
  const [row] = json.data.rows;
  assert.strictEqual(row.template_id, TEMPLATE_GONE);
  assert.strictEqual(row.template_exists, false);
  assert.strictEqual(row.template_name, '');
  assert.strictEqual(row.run_count, 3);
});

test('runs recorded with no template are a group, and its id stays null', async () => {
  responder = stub({ groups: [groupRow({ template_id: null, ...NO_TEMPLATE_ROW })], total: 1 });
  const { json } = await get(app(ADMIN), '/groups');
  const [row] = json.data.rows;
  assert.strictEqual(row.template_id, null);
  assert.strictEqual(row.template_exists, false);
  assert.strictEqual(row.template_name, '');
});

test('the grouped read partitions by template and names the newest run of each', async () => {
  responder = stub({ groups: [groupRow()], total: 1 });
  await get(app(ADMIN), '/groups');
  const [{ sql }] = issued;
  assert.match(sql, /PARTITION BY r\.`template_id`/);
  assert.match(sql, /ORDER BY r\.`created_at` DESC, r\.`id` DESC/);
  assert.match(sql, /WHERE g\.`rn` = 1/);
});

test('the page ordering is total, and does not repeat the term it is already sorted by', async () => {
  responder = stub({ groups: [groupRow()], total: 1 });
  await get(app(ADMIN), '/groups');
  assert.match(
    issued[0].sql,
    /ORDER BY g\.`last_run_at` IS NULL, g\.`last_run_at` DESC, g\.`template_id` DESC LIMIT/,
  );
});

test('a nullable ordering puts the rows with nothing to sort on last, in both directions', async () => {
  // A group whose template is gone has no name; an actor whose account is gone
  // has none either. Without this an A-to-Z sort leads with them.
  responder = stub({ groups: [], total: 0 });
  await get(app(ADMIN), '/groups?sort=template_name&order=asc');
  assert.match(issued[0].sql, /ORDER BY ut\.`name` IS NULL, ut\.`name` ASC/);
});

test('the default order is what happened lately', async () => {
  responder = stub({ groups: [], total: 0 });
  const { json } = await get(app(ADMIN), '/groups');
  assert.strictEqual(json.data.sort, 'last_run_at');
  assert.strictEqual(json.data.order, 'desc');
});

test('a requested order is applied and echoed back', async () => {
  responder = stub({ groups: [], total: 0 });
  const { json } = await get(app(ADMIN), '/groups?sort=run_count&order=asc');
  assert.match(issued[0].sql, /ORDER BY g\.`run_count` IS NULL, g\.`run_count` ASC/);
  assert.strictEqual(json.data.sort, 'run_count');
  assert.strictEqual(json.data.order, 'asc');
});

test('a column the list cannot be ordered by falls back to the default order', async () => {
  responder = stub({ groups: [], total: 0 });
  const { json } = await get(app(ADMIN), '/groups?sort=whatever%60--&order=sideways');
  // Nothing the caller sent reaches the statement: the name is looked up, never
  // interpolated.
  assert.ok(!issued[0].sql.includes('whatever'));
  assert.match(issued[0].sql, /ORDER BY g\.`last_run_at` IS NULL, g\.`last_run_at` DESC/);
  assert.strictEqual(json.data.sort, 'last_run_at');
});

test('a repeated sort parameter names nothing, and neither does a prototype key', async () => {
  // A repeated query parameter arrives as an array, and a property lookup would
  // convert it back to the same string; a field that is not a string is not a
  // field. `constructor` and `__proto__` name nothing either.
  responder = stub({ groups: [], total: 0 });
  const { json } = await get(app(ADMIN), '/groups?sort=run_count&sort=run_count');
  assert.strictEqual(json.data.sort, 'last_run_at');
  issued = [];
  const proto = await get(app(ADMIN), '/groups?sort=constructor');
  assert.strictEqual(proto.json.data.sort, 'last_run_at');
  assert.ok(!issued[0].sql.includes('constructor'));
});

test('the template name and the actor can each order the list', async () => {
  responder = stub({ groups: [], total: 0 });
  await get(app(ADMIN), '/groups?sort=template_name&order=asc');
  assert.match(issued[0].sql, /ORDER BY ut\.`name` IS NULL, ut\.`name` ASC/);
  issued = [];
  await get(app(ADMIN), '/groups?sort=last_actor_name&order=asc');
  assert.match(
    issued[0].sql,
    /ORDER BY COALESCE\(u\.`display_name`, u\.`kc_username`\) IS NULL, COALESCE\(u\.`display_name`, u\.`kc_username`\) ASC/,
  );
});

test('the grouped read carries no column nothing reads out of it', async () => {
  // The run's own blueprint was selected in the derived table and never read:
  // the blueprint a first-level entry names is the TEMPLATE's current one, which
  // the join already supplies. A column that travels the whole statement and is
  // dropped at the end is a column a later reader has to prove is dead.
  responder = stub({ groups: [], total: 0 });
  await get(app(ADMIN), '/groups');
  assert.ok(!issued[0].sql.includes('last_blueprint_id'));
  assert.ok(issued[0].sql.includes('ut.`blueprint_id` AS template_blueprint_id'));
});

test('the default page is applied when the caller asks for none', async () => {
  responder = stub({ groups: [], total: 0 });
  const { json } = await get(app(ADMIN), '/groups');
  assert.strictEqual(json.data.limit, 50);
  assert.strictEqual(json.data.offset, 0);
  assert.deepStrictEqual(issued[0].params.slice(-2), [50, 0]);
});

test('a page position is honoured, and the total counts the same predicate', async () => {
  responder = stub({ groups: [], total: 42 });
  const { json } = await get(app(USER), '/groups?limit=2&offset=4');
  assert.deepStrictEqual(issued[0].params.slice(-2), [2, 4]);
  assert.strictEqual(json.data.total, 42);
  const countQuery = issued.find((q) => q.sql.includes('COUNT(*) AS cnt'));
  // Same predicate, same bindings as the row query — which is now none at all.
  // The pairing is what matters: a count built over a different set than the
  // rows tells the reader how much exists beyond what they were shown.
  assert.deepStrictEqual(countQuery.params, []);
});

test('a limit with no position is read as the first page rather than dropped', async () => {
  responder = stub({ groups: [], total: 0 });
  const { json } = await get(app(ADMIN), '/groups?limit=5');
  assert.strictEqual(json.data.limit, 5);
  assert.strictEqual(json.data.offset, 0);
});

test('a malformed page is refused before a connection is taken', async () => {
  const { status, json } = await get(app(ADMIN), '/groups?limit=5&offset=-1');
  assert.strictEqual(status, 400);
  assert.strictEqual(json.error.code, 'INVALID_PAGINATION');
  assert.strictEqual(issued.length, 0);
});

test('a page size above the shared ceiling is refused, not clamped', async () => {
  const { status } = await get(app(ADMIN), '/groups?limit=5000&offset=0');
  assert.strictEqual(status, 400);
});

test('an unauthenticated caller is refused', async () => {
  const { status } = await get(app(null), '/groups');
  assert.strictEqual(status, 401);
  assert.strictEqual(issued.length, 0);
});

test('a database failure is reported as a server error, not as an empty history', async () => {
  responder = () => new Error('boom');
  const { status, json } = await get(app(ADMIN), '/groups');
  assert.strictEqual(status, 500);
  assert.ok(!json.data);
});

// ── Filters ──────────────────────────────────────────────────────────────
//
// Every predicate is checked against the ROW statement AND the COUNT
// statement — the requirement this unit exists for is that a filtered total
// can never describe a wider set than the filtered page.

const TEMPLATE_B = 'dddddddd-0000-0000-0000-000000000004';
const ACTOR_B = 'eeeeeeee-0000-0000-0000-000000000005';

function issuedFor(pattern) {
  return issued.filter((q) => pattern.test(q.sql));
}

test('a text search filters by template name, before pagination', async () => {
  responder = stub({ groups: [], total: 0 });
  await get(app(ADMIN), '/groups?search=Nightly');
  for (const { sql, params } of issuedFor(/`rn`\s*=\s*1/)) {
    assert.match(sql, /ut\.`name` LIKE \? ESCAPE '\|'/);
    assert.ok(params.includes('%Nightly%'), `expected %Nightly% among ${JSON.stringify(params)}`);
  }
});

test('a search term with LIKE wildcards is matched literally, not as a pattern', async () => {
  responder = stub({ groups: [], total: 0 });
  await get(app(ADMIN), `/groups?search=${encodeURIComponent('50%_done')}`);
  const [{ params }] = issuedFor(/`rn`\s*=\s*1/);
  assert.ok(params.includes('%50|%|_done%'));
});

test('the hierarchy filters narrow by the template columns they name', async () => {
  responder = stub({ groups: [], total: 0 });
  await get(app(ADMIN), `/groups?category=${TEMPLATE_A},${TEMPLATE_B}&release=${TEMPLATE_A}&blueprint=${TEMPLATE_A}&variant=${TEMPLATE_A}`);
  const [{ sql, params }] = issuedFor(/`rn`\s*=\s*1/);
  assert.match(sql, /ut\.`category_id` IN \(\?, \?\)/);
  assert.match(sql, /ut\.`release_id` IN \(\?\)/);
  assert.match(sql, /ut\.`blueprint_id` IN \(\?\)/);
  assert.match(sql, /ut\.`variant_id` IN \(\?\)/);
  assert.deepStrictEqual(params.slice(0, 5), [TEMPLATE_A, TEMPLATE_B, TEMPLATE_A, TEMPLATE_A, TEMPLATE_A]);
});

test('an id that is not a UUID is dropped from a hierarchy filter, not sent to the statement', async () => {
  responder = stub({ groups: [], total: 0 });
  await get(app(ADMIN), `/groups?category=${TEMPLATE_A},not-a-uuid`);
  // The count query, not the row query: it binds the same filter params with
  // no trailing page bounds to slice off.
  const [, { sql, params }] = issuedFor(/`rn`\s*=\s*1/);
  assert.match(sql, /ut\.`category_id` IN \(\?\)/);
  assert.deepStrictEqual(params, [TEMPLATE_A]);
});

test('an empty hierarchy selection adds no predicate at all', async () => {
  responder = stub({ groups: [], total: 0 });
  await get(app(ADMIN), '/groups?category=not-a-uuid,also-not');
  const [{ sql }] = issuedFor(/`rn`\s*=\s*1/);
  assert.ok(!sql.includes('category_id'));
});

test('the outcome filter reads the last run\'s own status', async () => {
  responder = stub({ groups: [], total: 0 });
  await get(app(ADMIN), '/groups?outcome=partial');
  const [{ sql, params }] = issuedFor(/`rn`\s*=\s*1/);
  assert.match(sql, /g\.`last_status` = \?/);
  assert.ok(params.includes('partial'));
});

test('an outcome outside the status enum is dropped, the same rule an unknown sort follows', async () => {
  responder = stub({ groups: [], total: 0 });
  await get(app(ADMIN), "/groups?outcome=deleted--");
  const [{ sql }] = issuedFor(/`rn`\s*=\s*1/);
  assert.ok(!sql.includes('last_status` = ?'));
});

test('the run-by filter matches the last run\'s actor', async () => {
  responder = stub({ groups: [], total: 0 });
  await get(app(ADMIN), `/groups?actor=${ACTOR_B}`);
  const [{ sql, params }] = issuedFor(/`rn`\s*=\s*1/);
  assert.match(sql, /g\.`last_actor_id` = \?/);
  assert.ok(params.includes(ACTOR_B));
});

test('an actor that is not a UUID is dropped', async () => {
  responder = stub({ groups: [], total: 0 });
  await get(app(ADMIN), '/groups?actor=not-a-uuid');
  const [{ sql }] = issuedFor(/`rn`\s*=\s*1/);
  assert.ok(!sql.includes('last_actor_id` = ?'));
});

test('a last-run date range bounds the aggregate\'s own timestamp, "to" inclusive of the whole day', async () => {
  responder = stub({ groups: [], total: 0 });
  await get(app(ADMIN), '/groups?from=2026-01-01&to=2026-01-31');
  const [{ sql, params }] = issuedFor(/`rn`\s*=\s*1/);
  assert.match(sql, /g\.`last_run_at` >= \?/);
  assert.match(sql, /g\.`last_run_at` < DATE_ADD\(\?, INTERVAL 1 DAY\)/);
  assert.deepStrictEqual(params.filter((p) => p === '2026-01-01' || p === '2026-01-31'), ['2026-01-01', '2026-01-31']);
});

test('a malformed date is dropped rather than reaching the statement', async () => {
  responder = stub({ groups: [], total: 0 });
  await get(app(ADMIN), '/groups?from=not-a-date');
  const [{ sql, params }] = issuedFor(/`rn`\s*=\s*1/);
  assert.ok(!sql.includes('last_run_at` >='));
  assert.ok(!params.includes('not-a-date'));
});

test('every filter is ANDed, and the row query and the count query bind identically', async () => {
  responder = stub({ groups: [], total: 7 });
  const { json } = await get(
    app(ADMIN),
    `/groups?search=nightly&outcome=success&actor=${ACTOR_B}&category=${TEMPLATE_A}`,
  );
  const rowQuery = issued.find((q) => q.sql.includes('LIMIT ? OFFSET ?'));
  const countQuery = issued.find((q) => q.sql.includes('COUNT(*) AS cnt'));
  // The count's params are the row query's params minus the trailing page bounds
  // — same predicate, same bindings, the pairing the total's correctness rests on.
  assert.deepStrictEqual(countQuery.params, rowQuery.params.slice(0, -2));
  assert.strictEqual(json.data.total, 7);
});

test('a filter narrows the total the same way it narrows the page — offset windows a filtered set, not the whole one', async () => {
  responder = stub({ groups: [], total: 3 });
  const { json } = await get(app(ADMIN), '/groups?outcome=failed&limit=10&offset=2');
  assert.strictEqual(json.data.total, 3);
  const rowQuery = issued.find((q) => q.sql.includes('LIMIT ? OFFSET ?'));
  assert.deepStrictEqual(rowQuery.params.slice(-2), [10, 2]);
});

// ── Facets ───────────────────────────────────────────────────────────────

test('the run-by facet lists the distinct actors this caller may see', async () => {
  responder = (sql) => {
    if (sql.includes('DISTINCT')) return [{ actor_id: USER.id }, { actor_id: ACTOR_B }];
    if (sql.includes('SELECT id, display_name, kc_username')) {
      return [{ id: USER.id, display_name: 'Ada', kc_username: 'ada' }];
    }
    return [];
  };
  const { status, json } = await get(app(ADMIN), '/groups/facets');
  assert.strictEqual(status, 200);
  assert.strictEqual(json.data.actors.length, 2);
  const ada = json.data.actors.find((a) => a.id === USER.id);
  assert.strictEqual(ada.name, 'Ada');
  const unresolved = json.data.actors.find((a) => a.id === ACTOR_B);
  // Same "Unknown" fallback attachActorNames applies everywhere else on this
  // surface — an actor with a run but no resolvable user row is not hidden.
  assert.strictEqual(unresolved.name, 'Unknown');
});

test('an unauthenticated caller is refused the run-by facet too', async () => {
  const { status } = await get(app(null), '/groups/facets');
  assert.strictEqual(status, 401);
});

test('the facet reads the LATEST run\'s actor per template, the same value the run-by filter matches', async () => {
  // Regression: this used to select DISTINCT actor_id over every run, which
  // could offer an actor whose only runs were superseded by someone else's
  // later run on the same template — picking that name then matched zero
  // groups, because no group's last_actor_id is ever that person's id.
  responder = () => [];
  await get(app(ADMIN), '/groups/facets');
  const [{ sql }] = issued;
  assert.match(sql, /SELECT DISTINCT g\.`last_actor_id` AS actor_id/);
  assert.doesNotMatch(sql, /DISTINCT r\.`actor_id`/);
  // Reads the same rn=1 group set the row query and the `actor` filter both
  // read — not every run.
  assert.match(sql, /ROW_NUMBER\(\)/);
  assert.match(sql, /WHERE g\.`rn` = 1/);
});
