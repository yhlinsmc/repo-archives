'use strict';

/**
 * sync-schema-summary-log.test.js — one info/kind:s2s "schema-sync summary"
 * line per POST /edge/app/sync-schema run (logging epic PR-3, fmb-2105,
 * spec §7 s2s), NOT per-table chatter. Real pino child logger as req.log
 * (captured sync destination, same pattern as send-error.test.js) so the
 * assertion sees the actual serialised record.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');
const { Writable } = require('node:stream');
const pino = require('pino');
const { _internals } = require('../../../../src/shared/lib/logger');

const dbKey = require.resolve('../../../../src/edge/db');
const routeKey = require.resolve('../../../../src/edge/routes/app/sync-schema');

function makeSpy() {
  const calls = { rw: 0, queries: [] };
  const spy = {
    rw: {
      async getConnection() {
        calls.rw++;
        return {
          async query(sql, values = []) {
            calls.queries.push({ sql, values });
            return { affectedRows: 1 };
          },
          release() {},
        };
      },
    },
    ro: { async getConnection() { throw new Error('wrong facade'); } },
  };
  return { calls, spy };
}

let poolSpy = {};

require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: {
    pool: poolSpy,
    t: (name) => `fmb_${name}`,
    getDbConfigFull: () => ({ tablePrefix: 'fmb_' }),
    getDynamicPool: async () => poolSpy,
  },
};

const router = require('../../../../src/edge/routes/app/sync-schema');

let server;
let port;
let records;
let base;

function makeCaptureLog() {
  const sink = new Writable({
    write(chunk, _e, cb) {
      for (const line of chunk.toString().split('\n')) {
        if (line.trim()) records.push(JSON.parse(line));
      }
      cb();
    },
  });
  return pino(_internals.loggerOptions, sink);
}

before(async () => {
  const { spy } = makeSpy();
  Object.assign(poolSpy, spy);
  base = makeCaptureLog();
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { req.user = { id: 'admin', role: 'admin' }; next(); });
  app.use((req, _res, next) => { req.log = base.child({ req_id: 'sync0001' }); next(); });
  app.use('/edge/app/sync-schema', router);
  await new Promise((resolve) => {
    server = app.listen(0, '127.0.0.1', () => { port = server.address().port; resolve(); });
  });
});

after(async () => {
  await new Promise((resolve) => server.close(resolve));
  delete require.cache[dbKey];
  delete require.cache[routeKey];
});

beforeEach(() => {
  records = [];
  const { spy } = makeSpy();
  Object.assign(poolSpy, spy);
});

function postJson(path_, body) {
  return new Promise((resolve, reject) => {
    const payload = JSON.stringify(body);
    const req = http.request(
      { host: '127.0.0.1', port, path: path_, method: 'POST', headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) } },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => resolve({ status: res.statusCode }));
      },
    );
    req.on('error', reject);
    req.write(payload);
    req.end();
  });
}

describe('POST /edge/app/sync-schema — summary line (fmb-2105)', () => {
  it('a run touching multiple tables logs exactly one info/kind:s2s summary line, not per-table', async () => {
    const res = await postJson('/edge/app/sync-schema', {
      action: 'data_only',
      tables: {
        blueprint_output_order: [{ id: 'o1', output_key: 'main', sort_order: 1 }],
        user_templates: [{ id: 't1', name: 'x', schema_version: 1 }],
      },
    });
    assert.equal(res.status, 200);
    const summaryLines = records.filter((r) => r.kind === 's2s' && r.msg === 'schema-sync summary');
    assert.equal(summaryLines.length, 1, `expected exactly one summary line, got ${JSON.stringify(summaryLines)}`);
    const r = summaryLines[0];
    assert.equal(r.level, 'info');
    assert.equal(r.tables, 2);
    assert.equal(typeof r.ms, 'number');
    assert.equal(r.req_id, 'sync0001');
  });

  it('a run whose connection acquisition throws still logs exactly one summary line, marked failed', async () => {
    // Simulates the same "throw somewhere inside the try" class the spec
    // calls out (connection acquire / applyDDL / syncData all jump to the
    // same catch) — this is the connection-acquire member of that class.
    poolSpy.rw.getConnection = async () => { throw new Error('connect ETIMEDOUT 10.0.0.1:3306'); };
    const res = await postJson('/edge/app/sync-schema', {
      action: 'data_only',
      tables: { blueprint_output_order: [{ id: 'o1', output_key: 'main', sort_order: 1 }] },
    });
    assert.equal(res.status, 500);
    const summaryLines = records.filter((r) => r.kind === 's2s' && r.msg === 'schema-sync summary');
    assert.equal(summaryLines.length, 1, `expected exactly one summary line, got ${JSON.stringify(summaryLines)}`);
    const r = summaryLines[0];
    assert.equal(r.level, 'info');
    assert.equal(r.outcome, 'failed');
    assert.equal(r.tables, 0);
    assert.equal(typeof r.ms, 'number');
    assert.equal(r.req_id, 'sync0001');
    // the failure reason travels through the same SQL-leak scrub every other
    // logS2s(err) call uses, never the raw driver message verbatim as a
    // separate un-scrubbed field.
    assert.ok(!('rawErr' in r));

    const appErrorLines = records.filter((rec) => rec.kind === 'app' && rec.level === 'error');
    assert.equal(appErrorLines.length, 1, `expected exactly one app error line, got ${JSON.stringify(appErrorLines)}`);
  });
});
