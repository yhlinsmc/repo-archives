/**
 * list-detail-response-parity.test.js — item 11 (B5).
 *
 * Item 11 opens a detail screen to readers who previously only saw the list row.
 * The claim that goes with it is that this exposes no data the API did not
 * already return to the same caller. That is a requirement, not an observation,
 * so it is asserted here rather than reasoned about: as a non-owner editor, the
 * detail response's field set must be a subset of the list response's.
 *
 * WHY a running comparison and not a reading of the code: both paths go through
 * the same CRUD factory today, so the property holds by construction — and that
 * is exactly the kind of fact that stops being true when someone adds a
 * projection, a join or an enrichment to one path. This test fails the moment
 * the two diverge.
 *
 * Reads are not owner-filtered, and this work does not change that.
 */
const { test, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../../../src/edge/db');

const OWNER = 'u-owner';
const INTRUDER = 'u-intruder';

let tables;
function resetWorld() {
  tables = {
    fmb_hierarchy_nodes: [{ id: 'bp-1', owner_id: OWNER }],
    fmb_flow_recipes: [{
      id: 'rec-1',
      owner_id: OWNER,
      blueprint_id: 'bp-1',
      name: 'Nightly push',
      description: 'Sends the record onward',
      is_active: 1,
      status: 'approved',
      review_note: null,
      approved_by: 'u-admin',
      approved_at: '2026-01-01 00:00:00',
      payload_transform_code: 'return input;',
      code_version: 2,
      content_type: 'application/json',
      runs_on: 'both',
      consumed_output_keys: null,
      link_extract: null,
      external_id_extract: null,
      created_at: '2026-01-01 00:00:00',
      updated_at: '2026-01-02 00:00:00',
    }],
    fmb_api_connectors: [{
      id: 'con-1',
      owner_id: OWNER,
      blueprint_id: 'bp-1',
      name: 'Ticket API',
      description: 'Opens a ticket',
      is_active: 1,
      status: 'approved',
      review_note: null,
      method: 'POST',
      url: 'https://example.test/api',
      auth_type: 'bearer',
      auth_config: JSON.stringify({ token: 'super-secret-value' }),
      request_config: null,
      response_config: null,
      dispatch_origin: 'server',
      timeout_ms: null,
      group_id: null,
      group_label: null,
      group_mode: null,
      sequence: null,
      created_at: '2026-01-01 00:00:00',
      updated_at: '2026-01-02 00:00:00',
    }],
  };
}
resetWorld();

const findRow = (name, id) => (tables[name] || []).find((r) => r.id === id) || null;

function makeConn() {
  return {
    async query(sql, params = []) {
      if (/^SELECT DATABASE\(\)/.test(sql)) return [{ db: 'testdb' }];
      if (/information_schema\.COLUMNS/.test(sql)) return [];
      let m = sql.match(/^SELECT \* FROM `([^`]+)` WHERE id = \?/);
      if (m) {
        const row = findRow(m[1], params[0]);
        return row ? [{ ...row }] : [];
      }
      m = sql.match(/^SELECT \* FROM `([^`]+)`/);
      if (m) return (tables[m[1]] || []).map((r) => ({ ...r }));
      if (/FROM `fmb_users`/.test(sql)) return [];
      // Connector "also usable in" enrichment (bindings projection): both reads
      // issue it, so scripting it empty keeps list and detail in agreement.
      if (/FROM `fmb_api_connector_blueprints`/.test(sql)) return [];
      throw new Error(`Unscripted query: ${sql}`);
    },
    release() {},
    async beginTransaction() {},
    async commit() {},
    async rollback() {},
  };
}

const poolSpy = {
  rw: { async getConnection() { return makeConn(); }, query: async () => [] },
  ro: { async getConnection() { return makeConn(); }, query: async () => [] },
};

require.cache[dbKey] = {
  id: dbKey,
  filename: dbKey,
  loaded: true,
  exports: { pool: poolSpy, t: (n) => `fmb_${n}`, getDynamicPool: async () => poolSpy },
};

const recipesRouter = require('../../../../src/edge/routes/app/flow-recipes');
const connectorsRouter = require('../../../../src/edge/routes/app/api-connectors');

async function get(router, user, path) {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { req.user = user; next(); });
  app.use('/', router);
  const server = await new Promise((resolve) => {
    const s = app.listen(0, '127.0.0.1', () => resolve(s));
  });
  const port = server.address().port;
  try {
    return await new Promise((resolve, reject) => {
      const req = http.request({ method: 'GET', host: '127.0.0.1', port, path }, (res) => {
        let raw = '';
        res.on('data', (c) => { raw += c; });
        res.on('end', () => resolve({ status: res.statusCode, body: raw ? JSON.parse(raw) : null }));
      });
      req.on('error', reject);
      req.end();
    });
  } finally {
    await new Promise((resolve) => server.close(resolve));
  }
}

const editor = (id) => ({ id, role: 'editor', email: `${id}@example.test` });

/** The field set of the row the list returns for `id`, and of the detail read. */
async function compare(router, id) {
  const list = await get(router, editor(INTRUDER), '/');
  const detail = await get(router, editor(INTRUDER), `/${id}`);
  assert.equal(list.status, 200, `list read failed: ${JSON.stringify(list.body)}`);
  assert.equal(detail.status, 200, `detail read failed: ${JSON.stringify(detail.body)}`);
  const listRow = (list.body.data || []).find((r) => r.id === id);
  assert.ok(listRow, 'the list does not contain the row under test');
  return { listRow, detailRow: detail.body.data };
}

beforeEach(() => { resetWorld(); });

test('flow recipe: the detail read returns no field the list read does not', async () => {
  const { listRow, detailRow } = await compare(recipesRouter, 'rec-1');
  const extra = Object.keys(detailRow).filter((k) => !(k in listRow));
  assert.deepEqual(extra, [], `detail-only field(s): ${extra.join(', ')}`);
});

test('flow recipe: the two reads agree value for value', async () => {
  // Same fields is not enough — a detail read that returned a fuller version of
  // the same field would disclose just as much.
  const { listRow, detailRow } = await compare(recipesRouter, 'rec-1');
  for (const [key, value] of Object.entries(detailRow)) {
    assert.deepEqual(value, listRow[key], `field "${key}" differs between the list and the detail read`);
  }
});

test('API connector: the detail read returns no field the list read does not', async () => {
  const { listRow, detailRow } = await compare(connectorsRouter, 'con-1');
  const extra = Object.keys(detailRow).filter((k) => !(k in listRow));
  assert.deepEqual(extra, [], `detail-only field(s): ${extra.join(', ')}`);
});

test('API connector: the two reads agree value for value', async () => {
  const { listRow, detailRow } = await compare(connectorsRouter, 'con-1');
  for (const [key, value] of Object.entries(detailRow)) {
    assert.deepEqual(value, listRow[key], `field "${key}" differs between the list and the detail read`);
  }
});

test('API connector: the secret is masked on BOTH reads, for a non-owner and for the owner', async () => {
  // The mask is not owner-dependent — the owner sees it too — so the locked
  // screen shows exactly what the owner's screen shows.
  const stored = JSON.parse(tables.fmb_api_connectors[0].auth_config);
  assert.equal(stored.token, 'super-secret-value', 'fixture no longer carries a secret to mask');

  for (const who of [INTRUDER, OWNER]) {
    const list = await get(connectorsRouter, editor(who), '/');
    const detail = await get(connectorsRouter, editor(who), '/con-1');
    const serialised = JSON.stringify([list.body, detail.body]);
    assert.equal(
      serialised.includes('super-secret-value'),
      false,
      `the stored secret reached a ${who === OWNER ? 'owner' : 'non-owner'} read`,
    );
  }
});
