// api-connectors-bindings-schema-parity.test.js — every column the bindings
// route + enrichment + delete cascade name in SQL must exist in the DDL. Parses
// table-ddls.js with an identity `t` (logical table names) and asserts. A wrong
// column name stays green in the stubbed node:test route suites yet 500s in
// production, so this reads the real DDL, no live DB.
const { describe, it, before } = require('node:test');
const assert = require('node:assert/strict');

const dbKey = require.resolve('../../../../src/edge/db');
require.cache[dbKey] = { id: dbKey, filename: dbKey, loaded: true, exports: { pool: {}, t: (n) => n } };
const { buildEngineTableDDLs } = require('../../../../src/table-ddls');

const SQL_TYPES = /^`?([a-z_]+)`?\s+(?:CHAR|VARCHAR|INT|DOUBLE|TIMESTAMP|JSON|TEXT|ENUM|BOOLEAN|TINYINT|BIGINT|DATETIME|DECIMAL|FLOAT|BLOB)\b/i;
let cols;
before(() => {
  cols = new Map();
  for (const ddl of buildEngineTableDDLs((n) => n)) {
    const m = ddl.match(/CREATE TABLE IF NOT EXISTS `([^`]+)`/);
    if (!m) continue;
    const set = new Set();
    for (const raw of ddl.split('\n')) {
      const line = raw.trim();
      if (!line || line.startsWith('--') || line.startsWith('/*')) continue;
      const cm = line.match(SQL_TYPES);
      if (cm) set.add(cm[1]);
    }
    cols.set(m[1], set);
  }
});

describe('bindings route SQL parity', () => {
  it('join table has connector_id + blueprint_id (INSERT/DELETE/SELECT + cascade keys)', () => {
    const c = cols.get('api_connector_blueprints');
    assert.ok(c && c.has('connector_id') && c.has('blueprint_id'));
  });
  it('blueprint_fields has blueprint_id + field_key (completeness loader)', () => {
    const c = cols.get('blueprint_fields');
    assert.ok(c && c.has('blueprint_id') && c.has('field_key'));
  });
  it('hierarchy_nodes has id + owner_id + node_type (existence + owner read + blueprint-node constraint)', () => {
    const c = cols.get('hierarchy_nodes');
    assert.ok(c && c.has('id') && c.has('owner_id') && c.has('node_type'));
  });
  it('api_connectors has group_id + name + blueprint_id (bundle scoping + home-rebind reconcile)', () => {
    const c = cols.get('api_connectors');
    assert.ok(c && c.has('group_id') && c.has('name') && c.has('blueprint_id'));
  });
  it('transformers has id + output_keys (transformer-output-keys resolve)', () => {
    const c = cols.get('transformers');
    assert.ok(c && c.has('id') && c.has('output_keys'));
  });
});
