// docker-api/tests/edge/routes/app/flow-recipe-steps-runs-on-authz.test.js
//
// The forward runs_on conflict gate must resolve the caller's access to the
// PARENT recipe before it probes that recipe's runs_on. Without the check a
// non-owning editor could POST { recipe_id: <foreign>, step_runs_on } and read
// off the foreign recipe's own mode from the 400-vs-pass outcome. The fix defers
// a caller who cannot read the parent to the CRUD factory (403 on create, 404 on
// update via parentOwnership), so the divergence decision never leaks.
//
// SQL-aware mock so the recipe SELECT + sameStoredValue answers are deterministic.
const { test, beforeEach } = require('node:test');
const assert = require('node:assert');
const express = require('express');

let recipeOwner = 'someone-else';
let recipeRunsOn = 'create';
let sameAnswer = 0;

require.cache[require.resolve('../../../../src/edge/db')] = {
  exports: {
    pool: {
      ro: {
        query: async (sql) => {
          if (/flow_recipe_steps/i.test(sql) && /recipe_id/.test(sql)) {
            // Stored step: a compare+GET api step under the foreign recipe. The
            // mode gate reads only recipe_id from it; the compare guard reads the
            // whole triple (both harmless for the mode-flow tests, load-bearing
            // for the compare-probe disclosure test).
            return [{ recipe_id: 'aaaa0000-0000-0000-0000-000000000001', method: 'GET', step_type: 'api', step_runs_on: 'compare' }];
          }
          if (/flow_recipes/i.test(sql) && /owner_id/.test(sql)) {
            return [{ owner_id: recipeOwner, runs_on: recipeRunsOn }];
          }
          if (/DATABASE\(\)/.test(sql)) return [{ db: 'testdb' }];
          if (/information_schema/i.test(sql)) return [{ cs: 'utf8mb4', co: 'utf8mb4_general_ci' }];
          if (/<=>/.test(sql)) return [{ same: sameAnswer }];
          return [];
        },
      },
      rw: { getConnection: async () => ({ query: async () => [], release: () => {} }) },
    },
    t: (x) => x,
  },
};
require.cache[require.resolve('../../../../src/edge/routes/app/schema')] = {
  exports: { createCrudRoutes: () => (req, res) => res.status(req.method === 'POST' ? 403 : 404).json({ ok: true, reached: 'crud' }) },
};
const router = require('../../../../src/edge/routes/app/flow-recipe-steps');

function app(user) {
  const a = express(); a.use(express.json());
  a.use((req, _res, next) => { req.user = user; next(); });
  a.use('/', router);
  return a;
}
async function send(a, method, path, body) {
  const server = a.listen(0);
  try {
    const port = server.address().port;
    const res = await fetch(`http://127.0.0.1:${port}${path}`, {
      method, headers: { 'content-type': 'application/json' }, body: JSON.stringify(body || {}),
    });
    const json = await res.json().catch(() => ({}));
    return { status: res.status, json };
  } finally {
    server.close();
  }
}

const EDITOR = { id: 'u1', role: 'editor' };
const RECIPE_ID = 'aaaa0000-0000-0000-0000-000000000001';
const STEP_ID = 'bbbb0000-0000-0000-0000-000000000002';

beforeEach(() => { recipeOwner = 'someone-else'; recipeRunsOn = 'create'; sameAnswer = 0; });

test('non-owning editor POST under a foreign recipe defers to CRUD (403), no runs_on disclosure', async () => {
  recipeOwner = 'someone-else'; sameAnswer = 0;
  const { status, json } = await send(app(EDITOR), 'POST', '/', {
    recipe_id: RECIPE_ID, step_runs_on: 'update', name: 'S', url: 'https://x/', method: 'POST',
  });
  assert.strictEqual(json.reached, 'crud', 'must fall through to CRUD, not answer the divergence itself');
  assert.strictEqual(status, 403, 'CRUD create posture for a foreign parent');
  assert.notStrictEqual(json?.error?.code, 'FLOW_STEP_MODE_CONFLICT', 'no runs_on conflict may leak for a foreign recipe');
});

test('non-owning editor PUT (parent resolved from stored step) under a foreign recipe defers to CRUD (404)', async () => {
  recipeOwner = 'someone-else'; sameAnswer = 0;
  const { status, json } = await send(app(EDITOR), 'PUT', `/${STEP_ID}`, { step_runs_on: 'update' });
  assert.strictEqual(json.reached, 'crud');
  assert.strictEqual(status, 404, 'CRUD update posture for a foreign parent');
  assert.notStrictEqual(json?.error?.code, 'FLOW_STEP_MODE_CONFLICT');
});

test('owning editor POST still gets the divergence 400 (legitimate path intact)', async () => {
  recipeOwner = 'u1'; recipeRunsOn = 'create'; // byte-equal owner → access passes, no collation query
  const { status, json } = await send(app(EDITOR), 'POST', '/', {
    recipe_id: RECIPE_ID, step_runs_on: 'update', name: 'S', url: 'https://x/', method: 'POST',
  });
  assert.strictEqual(status, 400);
  assert.strictEqual(json.error.code, 'FLOW_STEP_MODE_CONFLICT');
});

// M5: the compare guard's stored-triple probe distinguishes a compare+api step
// with a 400, so a non-owner probing a FOREIGN step id could read that shape
// off the 400-vs-404 outcome. The probe must resolve the caller's access to the
// step's parent recipe first and defer a non-owner to CRUD (404), never a 400.
test('non-owning editor PUT method-only on a foreign compare step defers to CRUD (404), no compare-shape disclosure', async () => {
  recipeOwner = 'someone-else'; sameAnswer = 0;
  const { status, json } = await send(app(EDITOR), 'PUT', `/${STEP_ID}`, { method: 'POST' });
  assert.strictEqual(status, 404, 'CRUD update posture for a foreign step, not a 400 from the compare probe');
  assert.notStrictEqual(json?.error?.code, 'BAD_REQUEST');
  assert.notStrictEqual(json?.error?.code, 'FLOW_COMPARE_STEP_NOT_GET');
});

test('owning editor PUT method-only on a compare step still gets the compare 400 (legitimate path intact)', async () => {
  recipeOwner = 'u1'; // byte-equal owner → access passes
  const { status, json } = await send(app(EDITOR), 'PUT', `/${STEP_ID}`, { method: 'POST' });
  assert.strictEqual(status, 400);
  assert.match(json.error.message, /compare step must use method GET/);
});
