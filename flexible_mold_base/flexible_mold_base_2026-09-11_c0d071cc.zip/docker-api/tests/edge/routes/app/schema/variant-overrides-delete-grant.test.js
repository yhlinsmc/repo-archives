'use strict';

/**
 * variant-overrides-delete-grant.test.js — the ONE reachable factory write for
 * variant_overrides is DELETE (POST/PUT are shadowed by the custom routes). This
 * file holds its editor predicate: with blueprintGrantScope + a grants table, it
 * widens to "(owns/shared parent) OR (holds a blueprint grant)"; without the
 * grants table it is byte-identical to the owner-only form; and NO other factory
 * table gains the grant join (table-specific, spec §6.4a).
 *
 * A stubbed driver cannot evaluate the EXISTS, so this settles the STATEMENT
 * SHAPE and the status the affectedRows maps to. That the predicate RESOLVES is
 * settled against the real schema in the cross-owner matrix (Task 3.5).
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const express = require('express');
const http = require('node:http');

const dbKey = require.resolve('../../../../../src/edge/db');

let conn;
let grantsPresent;
function makeConn() {
  const queries = [];
  return {
    queries,
    info: { database: 'app_one' },
    async query(sql, params = []) {
      queries.push({ sql, params });
      if (/information_schema\.TABLES/i.test(sql)) {
        const [name] = params;
        return grantsPresent && String(name).endsWith('delegated_grants') ? [{ 1: 1 }] : [];
      }
      if (/^DELETE FROM/i.test(sql)) return { affectedRows: 1 };
      return [];
    },
    release() {},
  };
}

const poolSpy = {
  rw: { async getConnection() { return conn; } },
  ro: { async getConnection() { return conn; } },
};
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: {
    pool: poolSpy,
    t: (name) => `fmb_${name}`,
    getDynamicPool: async () => poolSpy,
  },
};

const router = require('../../../../../src/edge/routes/app/schema');
const { _resetGrantsTableCache } = require('../../../../../src/edge/lib/delegated-grants');

let editorServer, editorPort, adminServer, adminPort;
function makeApp(role, userId) {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { req.user = { id: userId, role }; next(); });
  app.use('/edge/app/schema', router);
  return app;
}

before(async () => {
  await new Promise((r) => { editorServer = makeApp('editor', 'editor-B').listen(0, '127.0.0.1', r); });
  editorPort = editorServer.address().port;
  await new Promise((r) => { adminServer = makeApp('admin', 'admin-1').listen(0, '127.0.0.1', r); });
  adminPort = adminServer.address().port;
});
after(() => { editorServer.close(); adminServer.close(); delete require.cache[dbKey]; });
beforeEach(() => { _resetGrantsTableCache(); });

function del(port, path) {
  return new Promise((resolve, reject) => {
    const r = http.request({ method: 'DELETE', host: '127.0.0.1', port, path }, (res) => {
      let raw = '';
      res.on('data', (c) => { raw += c; });
      res.on('end', () => resolve({ status: res.statusCode, body: raw ? JSON.parse(raw) : null }));
    });
    r.on('error', reject);
    r.end();
  });
}

const lastDelete = () => conn.queries.map((q) => q.sql).reverse().find((s) => /^DELETE FROM/i.test(s));
const deleteParams = () => conn.queries.slice().reverse().find((q) => /^DELETE FROM `fmb_variant_overrides`/i.test(q.sql)).params;

describe('DELETE /variant_overrides/:id — blueprint-grant arm (spec §6.4a)', () => {
  it('with a grants table, the editor DELETE widens to owner-EXISTS OR grant-EXISTS', async () => {
    grantsPresent = true;
    conn = makeConn();
    const res = await del(editorPort, '/edge/app/schema/variant_overrides/vo-1');
    assert.equal(res.status, 200);
    const sql = lastDelete();
    assert.match(sql, /`fmb_delegated_grants`/, 'grant EXISTS is present');
    assert.match(sql, /dg\.`scope_type` = 'blueprint'/);
    assert.match(sql, /g1\.`node_type` = 'blueprint'/, 'terminal hop asserted to be a blueprint');
    assert.match(sql, /\(EXISTS[\s\S]*OR EXISTS[\s\S]*\)/, 'owner OR grant, one parenthesised OR');
    // the id predicate is never dropped
    assert.match(sql, /WHERE id = \?/);
    // caller id bound twice: owner arm + grant arm
    assert.deepEqual(deleteParams(), ['vo-1', 'editor-B', 'editor-B']);
  });

  it('without a grants table, the editor DELETE is the owner-only form (no grant join)', async () => {
    grantsPresent = false;
    conn = makeConn();
    const res = await del(editorPort, '/edge/app/schema/variant_overrides/vo-1');
    assert.equal(res.status, 200);
    const sql = lastDelete();
    assert.doesNotMatch(sql, /`fmb_delegated_grants`/, 'no grant join on a DB without the table');
    assert.deepEqual(deleteParams(), ['vo-1', 'editor-B']);
  });

  it('admin DELETE carries no ownership/grant predicate (bypass unchanged)', async () => {
    grantsPresent = true;
    conn = makeConn();
    const res = await del(adminPort, '/edge/app/schema/variant_overrides/vo-1');
    assert.equal(res.status, 200);
    const sql = lastDelete();
    assert.doesNotMatch(sql, /`fmb_delegated_grants`/);
    assert.doesNotMatch(sql, /EXISTS/);
  });

  it('another factory table (field_options) does NOT gain the grant join', async () => {
    // field_options declares parentOwnership but NOT blueprintGrantScope, so its
    // editor DELETE must stay owner-only — proves the arm is table-specific.
    grantsPresent = true;
    conn = makeConn();
    const res = await del(editorPort, '/edge/app/schema/field_options/fo-1');
    assert.equal(res.status, 200);
    const sql = lastDelete();
    assert.doesNotMatch(sql, /`fmb_delegated_grants`/, 'field_options DELETE unchanged');
    assert.match(sql, /EXISTS/, 'still owner-scoped by the chain EXISTS');
  });
});
