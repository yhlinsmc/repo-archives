'use strict';

/**
 * variant-override-grant.test.js — the pure verdict function that gates a
 * variant-override POST/PUT gains a fourth arm: an editor who is not the owner
 * but holds a blueprint grant is allowed (spec §6.1). The function stays
 * synchronous and pure — the grant boolean is resolved by the caller and passed
 * in — so this settles the verdict, not the resolver (that is the resolver's own
 * test and the real-schema matrix).
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const {
  validateVariantOverrideContext,
} = require('../../../../../src/edge/routes/app/schema/routes-variant-overrides');

const base = {
  variant_node_type: 'variant',
  field_blueprint_id: 'b1',
  blueprint_exists: 1,
  variant_blueprint_id: 'b1',
  blueprint_owner_id: 'ownerA',
};

describe('validateVariantOverrideContext — grant awareness', () => {
  it("an editor with a blueprint grant is allowed on another owner's blueprint", () => {
    assert.equal(validateVariantOverrideContext(base, 'editor', 'editorB', { hasBlueprintGrant: true }), null);
  });
  it("an editor with no grant on another owner's blueprint is 403 not_owner", () => {
    assert.deepEqual(
      validateVariantOverrideContext(base, 'editor', 'editorB', { hasBlueprintGrant: false }),
      { status: 403, error: 'not_owner' },
    );
  });
  it('the owner is still allowed with no grant', () => {
    assert.equal(
      validateVariantOverrideContext({ ...base, blueprint_owner_id: 'editorB' }, 'editor', 'editorB', { hasBlueprintGrant: false }),
      null,
    );
  });
  it('a shared (NULL owner) blueprint stays editor-writable with no grant', () => {
    assert.equal(
      validateVariantOverrideContext({ ...base, blueprint_owner_id: null }, 'editor', 'editorB', { hasBlueprintGrant: false }),
      null,
    );
  });
  it('omitting the options arg is the same as no grant (fail-closed default)', () => {
    assert.deepEqual(
      validateVariantOverrideContext(base, 'editor', 'editorB'),
      { status: 403, error: 'not_owner' },
    );
  });
  it('coherence violation still fires before the grant is consulted', () => {
    assert.deepEqual(
      validateVariantOverrideContext({ ...base, variant_blueprint_id: 'other' }, 'editor', 'editorB', { hasBlueprintGrant: true }),
      { status: 422, error: 'cross_blueprint_coherence_violation' },
    );
  });
});
