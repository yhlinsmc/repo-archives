'use strict';

/**
 * blueprint-grant-matrix.test.js — the cross-owner deny/allow matrix (spec §6.7)
 * run against the REAL schema. For a blueprint owned by user A:
 *   - editor grantee B WITH a blueprint grant: blueprint_fields PUT, variant
 *     override POST + PUT, connector-binding PUT, AND variant_overrides DELETE
 *     (the factory path, §6.4a) → all 200.
 *   - editor B with NO grant: all of the above → 403/404 (the deny premise is
 *     asserted FIRST, so a matrix that passes because everything is allowed is
 *     caught — feedback_destructive_verify_premise_first).
 *   - plain-user B with a grant: still refused by the route role gate
 *     (requireAdminOrEditor, spec §6.4 D-3).
 *   - grantee B attempts delete-blueprint / transfer-ownership: refused
 *     (owner/admin only, spec §6.2).
 *   - admin: 200 everywhere.
 *
 * A mocked driver cannot evaluate the grant EXISTS, so the tables are built from
 * the real DDL and the shipped routes run the shipped statements. Skips with a
 * stated reason when no database is reachable, and FAILS instead of skipping
 * when REQUIRE_INTEGRATION_DB=1 — a silent skip is the failure mode this line of
 * work exists to end.
 */
const { test, describe, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const net = require('node:net');
const http = require('node:http');
const express = require('express');
const mariadb = require('mariadb');

const TEST_PREFIX = 'bgm_';
const tbl = (name) => `${TEST_PREFIX}${name}`;

let pool = null;
const lease = () => pool.getConnection();
// The connectors router's egress + import guards call pool.ro.query / pool.rw
// directly (not only getConnection), so the facade has to answer both. Leases a
// connection per call and releases it — the real pool's query does the same.
const poolQuery = async (sql, params) => {
  const conn = await lease();
  try { return await conn.query(sql, params); } finally { conn.release(); }
};

const dbKey = require.resolve('../../../../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey,
  filename: dbKey,
  loaded: true,
  exports: {
    pool: { ro: { getConnection: lease, query: poolQuery }, rw: { getConnection: lease, query: poolQuery } },
    t: tbl,
    getDynamicPool: async () => ({
      ro: { getConnection: lease, query: poolQuery },
      rw: { getConnection: lease, query: poolQuery },
    }),
  },
};

const { buildEngineTableDDLs, buildInfraTableDDLs } = require('../../../../../src/table-ddls');
const schemaRouter = require('../../../../../src/edge/routes/app/schema');
const connectorsRouter = require('../../../../../src/edge/routes/app/api-connectors');
const delegatedGrantsRouter = require('../../../../../src/edge/routes/app/delegated-grants');
const { _resetGrantsTableCache } = require('../../../../../src/edge/lib/delegated-grants');

// ── Config auto-detection (same shape as the sibling integration tests) ──────
function parseEnvFile(filePath) {
  try {
    const out = {};
    for (const line of fs.readFileSync(filePath, 'utf-8').split('\n')) {
      const m = line.match(/^\s*([A-Z_][A-Z0-9_]*)\s*=\s*(.*)\s*$/);
      if (!m) continue;
      let value = m[2];
      if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) {
        value = value.slice(1, -1);
      }
      out[m[1]] = value;
    }
    return out;
  } catch { return null; }
}
function probePort(host, port, timeoutMs = 2000) {
  return new Promise((resolve) => {
    const socket = new net.Socket();
    let done = false;
    const finish = (ok) => { if (done) return; done = true; socket.destroy(); resolve(ok); };
    socket.setTimeout(timeoutMs);
    socket.once('connect', () => finish(true));
    socket.once('timeout', () => finish(false));
    socket.once('error', () => finish(false));
    socket.connect(port, host);
  });
}
async function resolveMariaDbConfig() {
  if (process.env.DB_TEST_HOST && process.env.DB_TEST_ROOT_PASSWORD) {
    return {
      host: process.env.DB_TEST_HOST,
      port: parseInt(process.env.DB_TEST_PORT || '3306', 10),
      user: 'root', password: process.env.DB_TEST_ROOT_PASSWORD,
    };
  }
  const env = parseEnvFile(path.resolve(__dirname, '../../../../../../.devcontainer/.env'));
  if (!env || !env.DB_ROOT_PASSWORD) return null;
  const port = parseInt(env.DB_PORT || '3306', 10);
  for (const host of ['127.0.0.1', 'mariadb', 'localhost']) {
    if (await probePort(host, port, 2000)) return { host, port, user: 'root', password: env.DB_ROOT_PASSWORD };
  }
  return null;
}

// ── Fixture ids ──────────────────────────────────────────────────────────────
const A = { id: 'aaaaaaaa-1111-4222-8333-000000000001', role: 'editor' };   // subject owner
const B = { id: 'bbbbbbbb-1111-4222-8333-000000000002', role: 'editor' };   // grantee
const ADMIN = { id: 'dddddddd-1111-4222-8333-000000000004', role: 'admin' };
const BP_A = 'a0b0c0d0-1111-4222-8333-0000000000a1';   // owned by A — the grant subject
const BP_B = 'a0b0c0d0-1111-4222-8333-0000000000b1';   // owned by B — connector home
const VARIANT = 'a0b0c0d0-1111-4222-8333-0000000000v1'; // variant under BP_A
const FIELD_PUT = 'f0000000-1111-4222-8333-0000000000f1'; // field under BP_A (PUT/override)
const FIELD_POST = 'f0000000-1111-4222-8333-0000000000f2'; // field under BP_A (POST override)
const OVERRIDE = 'ce000000-1111-4222-8333-0000000000e1'; // override on (VARIANT, FIELD_PUT)
const CONNECTOR = 'c0000000-1111-4222-8333-0000000000c1'; // owned by B, home BP_B
// R-4-8: CONNECTOR's home (BP_B) is owned by B outright, so it can never
// exercise the home-blueprint arm reached only through a grant — B already
// owns that blueprint before any grant exists. These two connectors have
// their HOME on BP_A, which only A owns, so the grant on BP_A is the only
// route to the home-blueprint check for them.
const CONNECTOR_HOME_VIA_GRANT = 'c0000000-1111-4222-8333-0000000000c2'; // owned by B, home BP_A
const CONNECTOR_NOT_OWNED_BY_B = 'c0000000-1111-4222-8333-0000000000c3'; // owned by A, home BP_A
// fmb-1992 fixtures: a blueprint only A owns and B holds NO grant on (a home
// "move" target that must refuse), a user_template owned by A under BP_A (the
// buildTemplateAccessExists dormancy path), and A's connector homed on BP_A
// that admin reassigns to the grantee B (station 3).
const BP_NG = 'a0b0c0d0-1111-4222-8333-0000000000c1';   // owned by A, NEVER granted to B
const TEMPLATE = 'a0b0c0d0-1111-4222-8333-0000000000t1'; // user_template owned by A, home BP_A
const CONNECTOR_A_HOME_BP_A = 'c0000000-1111-4222-8333-0000000000c4'; // owned by A, home BP_A

let dbReady = false;
let skipReason = null;
let testDbName = null;
let server = null;
let baseUrl = null;
let currentUser = ADMIN;

before(async () => {
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) {
    skipReason = 'no MariaDB reachable via .devcontainer/.env or env vars';
    if (process.env.REQUIRE_INTEGRATION_DB === '1') throw new Error(`REQUIRE_INTEGRATION_DB=1 set but ${skipReason}.`);
    return;
  }
  testDbName = `bgm_test_${process.pid}_${Date.now()}`;
  let admin = null;
  try {
    admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`CREATE DATABASE \`${testDbName}\``);
    await admin.query(`USE \`${testDbName}\``);
    for (const sql of [...buildInfraTableDDLs(tbl), ...buildEngineTableDDLs(tbl)]) await admin.query(sql);
    await admin.end();
    admin = null;
    pool = mariadb.createPool({ ...dbConfig, database: testDbName, connectionLimit: 6, connectTimeout: 5000 });
    const app = express();
    app.use(express.json());
    app.use((req, _res, next) => { req.user = currentUser; next(); });
    app.use('/edge/app/schema', schemaRouter);
    app.use('/edge/app/api-connectors', connectorsRouter);
    app.use('/edge/app/delegated-grants', delegatedGrantsRouter);
    server = http.createServer(app);
    await new Promise((r) => server.listen(0, r));
    baseUrl = `http://127.0.0.1:${server.address().port}`;
    dbReady = true;
  } catch (err) {
    skipReason = `setup failed: ${err.message}`;
    if (admin) { try { await admin.end(); } catch { /* best effort */ } }
    if (process.env.REQUIRE_INTEGRATION_DB === '1') throw err;
  }
});

after(async () => {
  if (server) { try { server.close(); } catch { /* best effort */ } }
  if (pool) { try { await pool.end(); } catch { /* best effort */ } }
  if (!testDbName) return;
  const dbConfig = await resolveMariaDbConfig();
  if (!dbConfig) return;
  try {
    const admin = await mariadb.createConnection({ ...dbConfig, connectTimeout: 5000 });
    await admin.query(`DROP DATABASE IF EXISTS \`${testDbName}\``);
    await admin.end();
  } catch { /* best effort */ }
});

async function call(user, method, url, body) {
  currentUser = user;
  const res = await fetch(`${baseUrl}${url}`, {
    method,
    headers: { 'content-type': 'application/json' },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const text = await res.text();
  let parsed = null;
  try { parsed = JSON.parse(text); } catch { parsed = { raw: text }; }
  return { status: res.status, body: parsed };
}

const guard = (t) => {
  if (!dbReady) { t.skip(skipReason || 'database not ready'); return true; }
  return false;
};

const q = (sql, params) => pool.query(sql, params);
const overrideCount = async (id = OVERRIDE) =>
  Number((await q(`SELECT COUNT(*) AS n FROM \`${tbl('variant_overrides')}\` WHERE id = ?`, [id]))[0].n);
const bindingCount = async (connectorId = CONNECTOR) =>
  Number((await q(`SELECT COUNT(*) AS n FROM \`${tbl('api_connector_blueprints')}\` WHERE connector_id = ?`, [connectorId]))[0].n);

async function grantB() {
  await q(
    `INSERT INTO \`${tbl('delegated_grants')}\` (id, scope_type, scope_id, grantee_id, granted_by)
     VALUES (UUID(), 'blueprint', ?, ?, ?)`,
    [BP_A, B.id, A.id],
  );
}

/** Rebuild the whole fixture with NO grant present, before each case. */
beforeEach(async () => {
  if (!dbReady) return;
  _resetGrantsTableCache();
  for (const name of ['delegated_grants', 'api_connector_blueprints', 'api_connectors',
    'user_templates', 'variant_overrides', 'blueprint_fields', 'hierarchy_nodes', 'users']) {
    await q(`DELETE FROM \`${tbl(name)}\``);
  }
  // Real user rows: the owner-transfer route resolves new_owner_id against the
  // users table (resolveCanonicalUserId), so the admin-transfer case needs B to
  // exist as a user.
  for (const [uid, role] of [[A.id, 'editor'], [B.id, 'editor']]) {
    await q(`INSERT INTO \`${tbl('users')}\` (id, email, role) VALUES (?, ?, ?)`, [uid, `${uid}@t.local`, role]);
  }
  // Blueprints: BP_A owned by A (grant subject), BP_B owned by B (connector home).
  await q(`INSERT INTO \`${tbl('hierarchy_nodes')}\` (id, name, node_type, owner_id) VALUES (?, 'bp-A', 'blueprint', ?)`, [BP_A, A.id]);
  await q(`INSERT INTO \`${tbl('hierarchy_nodes')}\` (id, name, node_type, owner_id) VALUES (?, 'bp-B', 'blueprint', ?)`, [BP_B, B.id]);
  // Variant under BP_A.
  await q(`INSERT INTO \`${tbl('hierarchy_nodes')}\` (id, name, node_type, parent_id, owner_id) VALUES (?, 'var', 'variant', ?, ?)`, [VARIANT, BP_A, A.id]);
  // Two fields under BP_A: one carries an existing override (PUT/DELETE), one free (POST).
  for (const [fid, key] of [[FIELD_PUT, 'city'], [FIELD_POST, 'zone']]) {
    await q(`INSERT INTO \`${tbl('blueprint_fields')}\` (id, blueprint_id, field_key, field_label, field_type) VALUES (?, ?, ?, ?, 'text')`, [fid, BP_A, key, key]);
  }
  await q(`INSERT INTO \`${tbl('variant_overrides')}\` (id, variant_id, field_id, action) VALUES (?, ?, ?, 'lock')`, [OVERRIDE, VARIANT, FIELD_PUT]);
  // Connector owned by B, home BP_B (so B manages it; the binding target is BP_A).
  await q(`INSERT INTO \`${tbl('api_connectors')}\` (id, name, url, owner_id, blueprint_id) VALUES (?, 'c', '', ?, ?)`, [CONNECTOR, B.id, BP_B]);
  // R-4-8: home BP_A, owned by A — B can reach it only through a grant.
  await q(`INSERT INTO \`${tbl('api_connectors')}\` (id, name, url, owner_id, blueprint_id) VALUES (?, 'c2', '', ?, ?)`, [CONNECTOR_HOME_VIA_GRANT, B.id, BP_A]);
  await q(`INSERT INTO \`${tbl('api_connectors')}\` (id, name, url, owner_id, blueprint_id) VALUES (?, 'c3', '', ?, ?)`, [CONNECTOR_NOT_OWNED_BY_B, A.id, BP_A]);
  // fmb-1992: BP_NG owned by A, never granted to B (a home "move" that refuses).
  await q(`INSERT INTO \`${tbl('hierarchy_nodes')}\` (id, name, node_type, owner_id) VALUES (?, 'bp-NG', 'blueprint', ?)`, [BP_NG, A.id]);
  // A's connector homed on BP_A — admin reassigns it to grantee B (station 3).
  await q(`INSERT INTO \`${tbl('api_connectors')}\` (id, name, url, owner_id, blueprint_id) VALUES (?, 'c4', '', ?, ?)`, [CONNECTOR_A_HOME_BP_A, A.id, BP_A]);
  // A user_template owned by A, homed on BP_A — the buildTemplateAccessExists
  // blueprint-grant arm's dormancy path (station 8).
  await q(`INSERT INTO \`${tbl('user_templates')}\` (id, name, blueprint_id, owner_id) VALUES (?, 'tpl', ?, ?)`, [TEMPLATE, BP_A, A.id]);
});

// helpers per surface
const putField = (user) => call(user, 'PUT', `/edge/app/schema/blueprint_fields/${FIELD_PUT}`, { field_label: `L${Date.now()}` });
const postOverride = (user) => call(user, 'POST', '/edge/app/schema/variant_overrides', { variant_id: VARIANT, field_id: FIELD_POST, action: 'lock' });
const putOverride = (user) => call(user, 'PUT', `/edge/app/schema/variant_overrides/${OVERRIDE}`, { action: 'lock' });
// FK-change PUT: repoints the OVERRIDE row from FIELD_PUT to FIELD_POST,
// both under BP_A — exercises the dual-EXISTS branch (old-row anti-hijack +
// new-pair post-state), each carrying its own grant arm (fmb-1976 PR-3 G-3B-5).
const putOverrideFkChange = (user) => call(user, 'PUT', `/edge/app/schema/variant_overrides/${OVERRIDE}`, { field_id: FIELD_POST, action: 'lock' });
const delOverride = (user) => call(user, 'DELETE', `/edge/app/schema/variant_overrides/${OVERRIDE}`);
const putBinding = (user) => call(user, 'PUT', `/edge/app/api-connectors/${CONNECTOR}/bindings`, { blueprint_ids: [BP_A] });
// R-4-8: BP_B is B's own blueprint, so targeting it exercises ONLY the home-
// blueprint arm (the connector's home is BP_A) — the target-side authority
// (assertBindingTargets) is already grant-aware and not what these pin.
const putBindingHomeViaGrant = (user) => call(user, 'PUT', `/edge/app/api-connectors/${CONNECTOR_HOME_VIA_GRANT}/bindings`, { blueprint_ids: [BP_B] });
const putBindingNotOwnedByB = (user) => call(user, 'PUT', `/edge/app/api-connectors/${CONNECTOR_NOT_OWNED_BY_B}/bindings`, { blueprint_ids: [BP_B] });
const delBlueprint = (user) => call(user, 'DELETE', `/edge/app/schema/hierarchy_nodes/${BP_A}`);
const transferBlueprint = (user) => call(user, 'PATCH', `/edge/app/schema/hierarchy_nodes/${BP_A}/owner`, { new_owner_id: B.id });

const denied = (s) => s === 403 || s === 404;

describe('blueprint-grant cross-owner matrix (spec §6.7)', () => {
  // ── Deny premise FIRST: editor B with NO grant is refused on every surface. ──
  test('editor B with NO grant: blueprint_fields PUT is denied', async (t) => {
    if (guard(t)) return;
    assert.ok(denied((await putField(B)).status));
  });
  test('editor B with NO grant: variant override POST is denied', async (t) => {
    if (guard(t)) return;
    assert.ok(denied((await postOverride(B)).status));
  });
  test('editor B with NO grant: variant override PUT is denied', async (t) => {
    if (guard(t)) return;
    assert.ok(denied((await putOverride(B)).status));
  });
  test('editor B with NO grant: variant_overrides DELETE is denied and the row survives', async (t) => {
    if (guard(t)) return;
    assert.ok(denied((await delOverride(B)).status));
    assert.equal(await overrideCount(), 1, 'the override row must still exist');
  });
  test('editor B with NO grant: connector-binding PUT is denied and no binding is written', async (t) => {
    if (guard(t)) return;
    assert.equal((await putBinding(B)).status, 403);
    assert.equal(await bindingCount(), 0);
  });

  // ── Allow: editor B WITH a grant is permitted on every §6.1 surface. ─────────
  test('editor B WITH a grant: blueprint_fields PUT → 200', async (t) => {
    if (guard(t)) return;
    await grantB();
    assert.equal((await putField(B)).status, 200);
  });
  test('editor B WITH a grant: variant override POST → 200', async (t) => {
    if (guard(t)) return;
    await grantB();
    assert.equal((await postOverride(B)).status, 200);
  });
  test('editor B WITH a grant: variant override PUT → 200', async (t) => {
    if (guard(t)) return;
    await grantB();
    assert.equal((await putOverride(B)).status, 200);
  });
  test('editor B WITH a grant: variant override PUT with a CHANGED field_id → 200 and the new FK is stored', async (t) => {
    if (guard(t)) return;
    await grantB();
    const res = await putOverrideFkChange(B);
    assert.equal(res.status, 200);
    const row = (await q(`SELECT field_id FROM \`${tbl('variant_overrides')}\` WHERE id = ?`, [OVERRIDE]))[0];
    assert.equal(row.field_id, FIELD_POST, 'the row must carry the NEW field_id after the FK-change PUT');
  });
  test('editor B WITH a grant: variant_overrides DELETE → 200 and the row is gone', async (t) => {
    if (guard(t)) return;
    await grantB();
    assert.equal((await delOverride(B)).status, 200);
    assert.equal(await overrideCount(), 0, 'the grantee DELETE must remove the row');
  });
  test('editor B WITH a grant: connector-binding PUT → 200 and the binding is written', async (t) => {
    if (guard(t)) return;
    await grantB();
    assert.equal((await putBinding(B)).status, 200);
    assert.equal(await bindingCount(), 1);
  });

  // ── R-4-8: the connector-binding PUT's home-blueprint arm, isolated from the
  //    already-grant-aware target-blueprint arm (assertBindingTargets). ────────
  test('R-4-8: editor B with NO grant, owning a connector whose home only A owns: denied with the home-blueprint message', async (t) => {
    if (guard(t)) return;
    const res = await putBindingHomeViaGrant(B);
    assert.equal(res.status, 403);
    assert.equal(res.body.error.message, 'You do not own the home blueprint of this connector.');
    assert.equal(await bindingCount(CONNECTOR_HOME_VIA_GRANT), 0);
  });
  test('R-4-8: editor B WITH a grant on the connector\'s home blueprint → 200 (grantee owns the connector)', async (t) => {
    if (guard(t)) return;
    await grantB();
    assert.equal((await putBindingHomeViaGrant(B)).status, 200);
    assert.equal(await bindingCount(CONNECTOR_HOME_VIA_GRANT), 1);
  });
  test('R-4-8: a grant on the home blueprint does not extend to connector ownership — a grantee who does not own the connector is still refused', async (t) => {
    if (guard(t)) return;
    await grantB();
    const res = await putBindingNotOwnedByB(B);
    assert.equal(res.status, 403);
    assert.equal(res.body.error.message, 'You do not own every connector in this bundle.');
    assert.equal(await bindingCount(CONNECTOR_NOT_OWNED_BY_B), 0);
  });

  // ── §6.2: a grant does NOT reach delete-blueprint or transfer-ownership. ─────
  test('grantee B may NOT delete the blueprint (owner/admin only)', async (t) => {
    if (guard(t)) return;
    await grantB();
    assert.ok(denied((await delBlueprint(B)).status));
    assert.equal(
      Number((await q(`SELECT COUNT(*) AS n FROM \`${tbl('hierarchy_nodes')}\` WHERE id = ?`, [BP_A]))[0].n),
      1, 'the blueprint must survive',
    );
  });
  test('grantee B may NOT transfer ownership (admin only)', async (t) => {
    if (guard(t)) return;
    await grantB();
    assert.ok(denied((await transferBlueprint(B)).status));
    assert.equal(
      (await q(`SELECT owner_id FROM \`${tbl('hierarchy_nodes')}\` WHERE id = ?`, [BP_A]))[0].owner_id,
      A.id, 'ownership must be unchanged',
    );
  });

  // ── §6.4 D-3: a grant is effective only for role ≥ editor. ───────────────────
  test('plain-user B WITH a grant is still refused by the route role gate', async (t) => {
    if (guard(t)) return;
    await grantB();
    const plainB = { id: B.id, role: 'user' };
    assert.equal((await putField(plainB)).status, 403);
    assert.equal((await postOverride(plainB)).status, 403);
    assert.equal((await delOverride(plainB)).status, 403);
    assert.equal((await putBindingHomeViaGrant(plainB)).status, 403);
    assert.equal(await overrideCount(), 1, 'the plain-user DELETE must not have removed the row');
    assert.equal(await bindingCount(CONNECTOR_HOME_VIA_GRANT), 0);
  });

  // ── Admin: 200 everywhere (unchanged). ───────────────────────────────────────
  test('admin: writes, delete and transfer all succeed', async (t) => {
    if (guard(t)) return;
    assert.equal((await putField(ADMIN)).status, 200);
    assert.equal((await postOverride(ADMIN)).status, 200);
    assert.equal((await putBinding(ADMIN)).status, 200);
    assert.equal((await delOverride(ADMIN)).status, 200);
    assert.equal(await overrideCount(), 0);
    assert.equal((await transferBlueprint(ADMIN)).status, 200);
  });
});

// ── fmb-1992: connector HOME blueprint + blueprint_fields create/delete are
//    grant-aware; a blueprint grant on an UNOWNED blueprint is refused/dormant. ─
const postConnector = (user, blueprintId) => call(user, 'POST', '/edge/app/api-connectors', {
  name: `conn-${Date.now()}`, url: 'https://c.test/v1/x', method: 'GET', blueprint_id: blueprintId,
});
const renameConnector = (user, id) => call(user, 'PUT', `/edge/app/api-connectors/${id}`, { name: `r-${Date.now()}` });
const moveConnectorHome = (user, id, blueprintId) => call(user, 'PUT', `/edge/app/api-connectors/${id}`, { blueprint_id: blueprintId });
const deleteConnector = (user, id) => call(user, 'DELETE', `/edge/app/api-connectors/${id}`);
const reassignConnector = (user, id, newOwnerId) => call(user, 'PATCH', `/edge/app/api-connectors/${id}/owner`, { new_owner_id: newOwnerId });
const importConnector = (user, blueprintId) => call(user, 'POST', '/edge/app/api-connectors/import', {
  connector: { name: `imp-${Date.now()}`, url: 'https://imp.test/v1/x', method: 'GET', blueprint_id: blueprintId },
});
const cloneConnector = (user, id) => call(user, 'POST', `/edge/app/api-connectors/${id}/clone`, {});
const sourceCandidatesTest = (user, id) => call(user, 'GET', `/edge/app/api-connectors/${id}/source-candidates?test=1`);
const postField = (user, blueprintId) => call(user, 'POST', '/edge/app/schema/blueprint_fields', {
  blueprint_id: blueprintId, field_key: `k${Date.now()}`, field_label: 'L', field_type: 'text',
});
const deleteField = (user, id) => call(user, 'DELETE', `/edge/app/schema/blueprint_fields/${id}`);
const putTemplate = (user) => call(user, 'PUT', `/edge/app/schema/user_templates/${TEMPLATE}`, { name: `t-${Date.now()}` });
const postGrant = (user, scopeId, granteeId) => call(user, 'POST', '/edge/app/delegated-grants', {
  scope_type: 'blueprint', scope_id: scopeId, grantee_id: granteeId,
});
const connectorHome = async (id) =>
  (await q(`SELECT blueprint_id, owner_id FROM \`${tbl('api_connectors')}\` WHERE id = ?`, [id]))[0];
const shareBlueprint = (id) => q(`UPDATE \`${tbl('hierarchy_nodes')}\` SET owner_id = NULL WHERE id = ?`, [id]);
const reclaimBlueprint = (id, owner) => q(`UPDATE \`${tbl('hierarchy_nodes')}\` SET owner_id = ? WHERE id = ?`, [owner, id]);

describe('fmb-1992 connector HOME blueprint is grant-aware', () => {
  // Row (a): editor B WITH a grant on X owns the full connector lifecycle homed on X.
  test('(a) editor B WITH a grant: POST connector homed on X → 200, rename → 200, DELETE → 200', async (t) => {
    if (guard(t)) return;
    await grantB();
    const created = await postConnector(B, BP_A);
    assert.equal(created.status, 200, JSON.stringify(created.body));
    const id = created.body.data.id;
    assert.equal((await renameConnector(B, id)).status, 200);
    assert.equal((await deleteConnector(B, id)).status, 200);
    assert.equal(Number((await q(`SELECT COUNT(*) AS n FROM \`${tbl('api_connectors')}\` WHERE id = ?`, [id]))[0].n), 0);
  });
  test('(a) editor B WITH a grant: PUT home move to a blueprint they cannot write (BP_NG) → denied', async (t) => {
    if (guard(t)) return;
    await grantB();
    const id = (await postConnector(B, BP_A)).body.data.id;
    assert.ok(denied((await moveConnectorHome(B, id, BP_NG)).status), 'move to a non-granted blueprint must be refused');
    assert.equal((await connectorHome(id)).blueprint_id, BP_A, 'the home must be unchanged');
  });
  // Row (b): editor B WITHOUT a grant cannot create under X.
  test('(b) editor B with NO grant: POST connector homed on X → 403', async (t) => {
    if (guard(t)) return;
    assert.equal((await postConnector(B, BP_A)).status, 403);
  });
  // Row (c): admin reassign to a grantee vs a non-grantee editor.
  test('(c) admin reassigns A\'s connector homed on X to grantee B → 200', async (t) => {
    if (guard(t)) return;
    await grantB();
    const res = await reassignConnector(ADMIN, CONNECTOR_A_HOME_BP_A, B.id);
    assert.equal(res.status, 200);
    assert.equal((await connectorHome(CONNECTOR_A_HOME_BP_A)).owner_id, B.id);
  });
  test('(c) admin reassigns to an editor with no grant and X not shared → 400 with the grant-aware wording', async (t) => {
    if (guard(t)) return;
    // No grant for B; BP_A owned by A (not shared) → B could not manage it.
    const res = await reassignConnector(ADMIN, CONNECTOR_A_HOME_BP_A, B.id);
    assert.equal(res.status, 400);
    assert.match(res.body.error.message, /hold a grant on it/);
    assert.equal((await connectorHome(CONNECTOR_A_HOME_BP_A)).owner_id, A.id, 'ownership must be unchanged');
  });
  // Row (d): after revoking B's grant, B's PUT on their own connector homed on X.
  // OBSERVED STATUS: 404. The editor PUT scope is `(owner_id = B) AND (home
  // owned/shared OR grant on home)`. B still owns the connector row, but with the
  // grant gone and BP_A owned by A (not shared), the home predicate matches no
  // row, so the UPDATE affects 0 rows and the factory reports 404 (existence-leak
  // parity — a scoped-out row is indistinguishable from a missing one), NOT 403.
  test('(d) after the grant is revoked, B\'s PUT on their own connector homed on X → 404 (scoped out, not 403)', async (t) => {
    if (guard(t)) return;
    await grantB();
    const id = (await postConnector(B, BP_A)).body.data.id;
    assert.equal((await renameConnector(B, id)).status, 200, 'with the grant, the owner may edit');
    await q(`DELETE FROM \`${tbl('delegated_grants')}\` WHERE grantee_id = ? AND scope_id = ?`, [B.id, BP_A]);
    _resetGrantsTableCache();
    const res = await renameConnector(B, id);
    assert.equal(res.status, 404, 'revoked grant + non-shared foreign home → scoped out → 404');
  });
  // Row (e): a plain-user grantee is refused by the route role gate.
  test('(e) plain-user B WITH a grant: POST connector homed on X → 403 (role floor)', async (t) => {
    if (guard(t)) return;
    await grantB();
    assert.equal((await postConnector({ id: B.id, role: 'user' }, BP_A)).status, 403);
  });
  // Row (f): import creates a connector homed on X — same rule as create.
  test('(f) editor B WITH a grant: POST /import homed on X → 201', async (t) => {
    if (guard(t)) return;
    await grantB();
    assert.equal((await importConnector(B, BP_A)).status, 201);
  });
  test('(f) editor B with NO grant: POST /import homed on X → 403', async (t) => {
    if (guard(t)) return;
    assert.equal((await importConnector(B, BP_A)).status, 403);
  });
  // Row (g) / station 9: clone.js:141 creates a connector homed on the
  // source's blueprint — the same rule as POST create/import (fmb-1992). The
  // clone route's own credential gate (an editor may only clone a connector
  // they OWN) is unchanged and unrelated: both rows here have B as the
  // connector owner, so only the home-blueprint arm is under test.
  test('(g) editor B WITH a grant: clones their own connector homed on X → 201', async (t) => {
    if (guard(t)) return;
    await grantB();
    const id = (await postConnector(B, BP_A)).body.data.id;
    const res = await cloneConnector(B, id);
    assert.equal(res.status, 201, JSON.stringify(res.body));
    assert.equal((await connectorHome(res.body.data.id)).blueprint_id, BP_A);
  });
  test('(g) after the grant is revoked, B\'s clone of their own connector homed on X → 403 (a pre-check apiError, not a statement-predicate scope-out)', async (t) => {
    if (guard(t)) return;
    await grantB();
    const id = (await postConnector(B, BP_A)).body.data.id;
    await q(`DELETE FROM \`${tbl('delegated_grants')}\` WHERE grantee_id = ? AND scope_id = ?`, [B.id, BP_A]);
    _resetGrantsTableCache();
    const res = await cloneConnector(B, id);
    assert.equal(res.status, 403, 'unlike row (d)\'s PUT (a statement predicate that scopes the row out to a 404), clone reads the blueprint owner in a pre-check and returns apiError 403 the moment bpOwnOrShared is false');
  });
});

describe('fmb-1992 blueprint_fields create/delete under a granted blueprint (station 7)', () => {
  test('editor B WITH a grant: POST field under X → 200, DELETE own-created field → 200', async (t) => {
    if (guard(t)) return;
    await grantB();
    const created = await postField(B, BP_A);
    assert.equal(created.status, 200);
    const id = created.body.data.id;
    assert.equal((await deleteField(B, id)).status, 200);
  });
  test('editor B with NO grant: POST field under X → 403', async (t) => {
    if (guard(t)) return;
    assert.equal((await postField(B, BP_A)).status, 403);
  });
  test('plain-user B WITH a grant: POST field under X → 403 (role floor)', async (t) => {
    if (guard(t)) return;
    await grantB();
    assert.equal((await postField({ id: B.id, role: 'user' }, BP_A)).status, 403);
  });
});

describe('fmb-1992 a blueprint grant needs an OWNED blueprint (station 8)', () => {
  // Write-side: minting a grant on an unowned blueprint is refused.
  test('admin POST grant on an UNOWNED blueprint → 400 UNOWNED_SUBJECT', async (t) => {
    if (guard(t)) return;
    await shareBlueprint(BP_A);
    const res = await postGrant(ADMIN, BP_A, B.id);
    assert.equal(res.status, 400);
    assert.equal(res.body.error.code, 'UNOWNED_SUBJECT');
  });
  test('editor A POST grant on an UNOWNED blueprint → denied (does not own it)', async (t) => {
    if (guard(t)) return;
    await shareBlueprint(BP_A);
    assert.ok(denied((await postGrant(A, BP_A, B.id)).status));
  });
  // Effect-side, observable on the template arm (buildTemplateAccessExists has
  // no "shared blueprint = any editor" arm, unlike the connector/field paths, so
  // it is where an unowned-blueprint grant would have escalated to writing
  // another user's owned template — and where dormancy is observable).
  test('grant on OWNED X → grantee template PUT under X → 200; owner shares X → PUT refused; reclaim → 200 again', async (t) => {
    if (guard(t)) return;
    await grantB();
    assert.equal((await putTemplate(B)).status, 200, 'grant on an owned blueprint admits the template write');
    await shareBlueprint(BP_A);
    _resetGrantsTableCache();
    assert.equal((await putTemplate(B)).status, 404, 'once X is unowned the blueprint grant is dormant');
    await reclaimBlueprint(BP_A, A.id);
    _resetGrantsTableCache();
    assert.equal((await putTemplate(B)).status, 200, 'reclaiming X revives the grant');
  });
});

// ── Station 10 (fmb-1992 follow-up): the manage/test gate's blueprint arm
//    (connector-manage-authority.js, read by /prepare's test:true and by
//    source-candidates' ?test=1) is grant-aware, so a grantee can test-dispatch
//    their own pending connector homed on a granted (non-owned) blueprint
//    before an admin approves it — CONNECTOR_HOME_VIA_GRANT is owned by B,
//    homed on BP_A (owned by A), exactly the row R-4-8 already uses for the
//    binding-authority grant arm. Stamped pending + source_kind='template'
//    (source_config left NULL) so the observable split is the approval gate
//    itself: 422 CONNECTOR_NOT_APPROVED (denied) vs 200 with items:[] (an
//    unconfigured template source returns no candidates, but only once past
//    the gate).
describe('fmb-1992 station 10: the manage/test gate honours a home-blueprint grant', () => {
  test('editor B WITH a grant: ?test=1 on their own PENDING connector homed on X → 200 (bypasses admin approval)', async (t) => {
    if (guard(t)) return;
    await grantB();
    await q(
      `UPDATE \`${tbl('api_connectors')}\` SET status = 'pending', source_kind = 'template' WHERE id = ?`,
      [CONNECTOR_HOME_VIA_GRANT],
    );
    const res = await sourceCandidatesTest(B, CONNECTOR_HOME_VIA_GRANT);
    assert.equal(res.status, 200, JSON.stringify(res.body));
    assert.deepEqual(res.body.data.items, []);
  });
  test('after the grant is revoked, the same request on the same PENDING connector → 422 CONNECTOR_NOT_APPROVED', async (t) => {
    if (guard(t)) return;
    await grantB();
    await q(
      `UPDATE \`${tbl('api_connectors')}\` SET status = 'pending', source_kind = 'template' WHERE id = ?`,
      [CONNECTOR_HOME_VIA_GRANT],
    );
    assert.equal((await sourceCandidatesTest(B, CONNECTOR_HOME_VIA_GRANT)).status, 200, 'with the grant, the bypass applies');
    await q(`DELETE FROM \`${tbl('delegated_grants')}\` WHERE grantee_id = ? AND scope_id = ?`, [B.id, BP_A]);
    _resetGrantsTableCache();
    const res = await sourceCandidatesTest(B, CONNECTOR_HOME_VIA_GRANT);
    assert.equal(res.status, 422);
    assert.equal(res.body.error.code, 'CONNECTOR_NOT_APPROVED');
  });
});
