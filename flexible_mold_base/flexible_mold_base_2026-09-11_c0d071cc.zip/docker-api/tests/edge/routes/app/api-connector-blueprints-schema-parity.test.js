// Parses the engine DDLs (identity `t`) and asserts the join table declares
// exactly the columns the bindings SQL and the cascade sites read —
// a wrong column name stays green under the mocked node:tests yet 500s in
// production, so this pins it against table-ddls.js without a live DB.
const { describe, it, before } = require('node:test');
const assert = require('node:assert/strict');

const dbKey = require.resolve('../../../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: {}, t: (n) => n },
};

const { buildEngineTableDDLs, ENGINE_TABLE_NAMES } = require('../../../../src/table-ddls');
const { TABLES } = require('../../../../src/shared/constants');

const SQL_TYPES = /^`?([a-z_]+)`?\s+(?:CHAR|VARCHAR|INT|DOUBLE|TIMESTAMP|JSON|TEXT|ENUM|BOOLEAN|TINYINT|BIGINT|DATETIME|DECIMAL|FLOAT|BLOB)\b/i;
let columnsByTable;

before(() => {
  columnsByTable = new Map();
  for (const ddl of buildEngineTableDDLs((n) => n)) {
    const m = ddl.match(/CREATE TABLE IF NOT EXISTS `([^`]+)`/);
    if (!m) continue;
    const cols = new Set();
    for (const rawLine of ddl.split('\n')) {
      const line = rawLine.trim();
      if (!line || line.startsWith('--') || line.startsWith('/*')) continue;
      const cm = line.match(SQL_TYPES);
      if (cm) cols.add(cm[1]);
    }
    columnsByTable.set(m[1], cols);
  }
});

describe('api_connector_blueprints schema parity', () => {
  it('TABLES exposes the join-table constant', () => {
    assert.equal(TABLES.API_CONNECTOR_BLUEPRINTS, 'api_connector_blueprints');
  });

  it('the join table name is in ENGINE_TABLE_NAMES', () => {
    assert.ok(ENGINE_TABLE_NAMES.includes('api_connector_blueprints'));
  });

  it('declares exactly id, connector_id, blueprint_id, created_at', () => {
    // identity `t` (see stub above) yields the unprefixed logical name, not
    // the `fmb_`-prefixed physical name — matches the sibling
    // capacity-delete-preview-schema-parity.test.js convention.
    const cols = columnsByTable.get('api_connector_blueprints');
    assert.ok(cols, 'no DDL parsed for api_connector_blueprints');
    for (const c of ['id', 'connector_id', 'blueprint_id', 'created_at']) {
      assert.ok(cols.has(c), `join table is missing ${c}`);
    }
  });
});
