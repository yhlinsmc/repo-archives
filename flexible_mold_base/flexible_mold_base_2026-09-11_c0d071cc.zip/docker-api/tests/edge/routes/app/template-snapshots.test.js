'use strict';

/**
 * template-snapshots.test.js — who may read/delete a record's legacy
 * snapshots, and that the list read is bounded. POST (snapshot creation) is
 * retired (fmb-1934 PR-4) — see template-snapshots-post-gone.test.js.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../../../src/edge/db');

let queries;
let templateRow;      // the record the snapshots belong to, or null
let grantRows;        // what the grant lookup finds
let grantsTablePresent; // whether the grants table probe finds the table
let snapshotsTablePresent; // whether the snapshots table probe finds the table
let snapshotRows;      // what the list read returns
let deleteExisting;    // what the delete's ownership probe finds
let committed;         // S3 (fmb-1912 PR-4 residual): DELETE now runs inside an explicit transaction
let rolledBack;

function makeConn() {
  return {
    async beginTransaction() {},
    async commit() { committed = true; },
    async rollback() { rolledBack = true; },
    async query(sql, params = []) {
      queries.push({ sql, params });
      if (/information_schema\.TABLES/i.test(sql)) {
        const [name] = params;
        if (String(name).endsWith('delegated_grants')) return grantsTablePresent ? [{ 1: 1 }] : [];
        if (String(name).endsWith('template_snapshots')) return snapshotsTablePresent ? [{ 1: 1 }] : [];
        return [];
      }
      if (/^INSERT INTO `fmb_template_snapshots`/.test(sql)) return { affectedRows: 1 };
      if (/^DELETE FROM `fmb_template_snapshots`/.test(sql)) return { affectedRows: 1 };
      if (/FROM `fmb_template_snapshots`.*FOR UPDATE/is.test(sql)) return deleteExisting;
      if (/FROM `fmb_user_templates`/.test(sql)) return templateRow ? [templateRow] : [];
      if (/FROM `fmb_hierarchy_nodes`/.test(sql)) return [];
      if (/FROM `fmb_delegated_grants`/.test(sql)) return grantRows;
      if (/FROM `fmb_template_snapshots`/.test(sql)) return snapshotRows;
      return [];
    },
    release() {},
  };
}

const poolFacade = { async getConnection() { return makeConn(); } };

require.cache[dbKey] = {
  id: dbKey,
  filename: dbKey,
  loaded: true,
  exports: {
    pool: { ro: poolFacade, rw: poolFacade },
    t: (n) => `fmb_${n}`,
    getDynamicPool: async () => ({ ro: poolFacade, rw: poolFacade }),
  },
};

const router = require('../../../../src/edge/routes/app/template-snapshots');
const { _resetGrantsTableCache } = require('../../../../src/edge/lib/delegated-grants');

const OWNER = { id: '11111111-1111-1111-1111-111111111111', role: 'user' };
const GRANTEE = { id: '22222222-2222-2222-2222-222222222222', role: 'user' };
const STRANGER = { id: '33333333-3333-3333-3333-333333333333', role: 'user' };
const ADMIN = { id: '44444444-4444-4444-4444-444444444444', role: 'admin' };
const TEMPLATE = 'bbbbbbbb-0000-0000-0000-00000000000b';
const SNAPSHOT = 'cccccccc-0000-0000-0000-00000000000c';

let currentUser;
let server;
let baseUrl;

before(async () => {
  const app = express();
  // Same limit index-edge.js configures in production (ARCH-5) — the default
  // express.json() 100kb cap would 413 a well-under-MAX_SNAPSHOT_BYTES body
  // before the route's own size check ever runs.
  app.use(express.json({ limit: '10mb' }));
  app.use((req, _res, next) => { if (currentUser) req.user = currentUser; next(); });
  app.use('/edge/app/templates', router);
  server = http.createServer(app);
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});

after(async () => { await new Promise((r) => server.close(r)); });

beforeEach(() => {
  queries = [];
  templateRow = { id: TEMPLATE, owner_id: OWNER.id, blueprint_id: 'bp-1' };
  grantRows = [];
  grantsTablePresent = true;
  snapshotsTablePresent = true;
  snapshotRows = [];
  deleteExisting = [{ id: SNAPSHOT }];
  committed = false;
  rolledBack = false;
  currentUser = OWNER;
  _resetGrantsTableCache();
});

async function call(method, path, body) {
  const res = await fetch(`${baseUrl}/edge/app/templates${path}`, {
    method,
    headers: { 'content-type': 'application/json' },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const json = await res.json().catch(() => ({}));
  return { status: res.status, json };
}

describe('who may read and write a record\'s snapshots', () => {
  it('its owner may list', async () => {
    const res = await call('GET', `/${TEMPLATE}/snapshots`);
    assert.equal(res.status, 200);
  });

  it('an administrator may list', async () => {
    currentUser = ADMIN;
    const res = await call('GET', `/${TEMPLATE}/snapshots`);
    assert.equal(res.status, 200);
  });

  it('someone the owner delegated to may list', async () => {
    // R-3-P1: a grant is honoured only for an editor/admin grantee.
    currentUser = { ...GRANTEE, role: 'editor' };
    grantRows = [{ granted: 1 }];
    const res = await call('GET', `/${TEMPLATE}/snapshots`);
    assert.equal(res.status, 200);
  });

  it('R-3-P1: the SAME grant row is not honoured once the grantee is a plain user', async () => {
    currentUser = GRANTEE; // role: 'user'
    grantRows = [{ granted: 1 }];
    const res = await call('GET', `/${TEMPLATE}/snapshots`);
    assert.equal(res.status, 404);
  });

  it('everyone else is answered as though the record were not there', async () => {
    currentUser = STRANGER;
    const res = await call('GET', `/${TEMPLATE}/snapshots`);
    assert.equal(res.status, 404);
  });

  it('a record that does not exist is the same answer', async () => {
    templateRow = null;
    const res = await call('GET', `/${TEMPLATE}/snapshots`);
    assert.equal(res.status, 404);
  });

  it('an anonymous caller reaches no statement at all', async () => {
    currentUser = null;
    const res = await call('GET', `/${TEMPLATE}/snapshots`);
    assert.equal(res.status, 401);
    assert.equal(queries.length, 0);
  });

  it('an anonymous caller may not delete either', async () => {
    currentUser = null;
    const res = await call('DELETE', `/${TEMPLATE}/snapshots/${SNAPSHOT}`);
    assert.equal(res.status, 401);
    assert.equal(queries.filter((q) => /^DELETE/.test(q.sql)).length, 0);
  });

  it('a stranger may not delete a snapshot', async () => {
    currentUser = STRANGER;
    const res = await call('DELETE', `/${TEMPLATE}/snapshots/${SNAPSHOT}`);
    assert.equal(res.status, 404);
    assert.equal(queries.filter((q) => /^DELETE/.test(q.sql)).length, 0);
  });
});

// fmb-1934 PR-4 (spec §4.2, D8): "saving a snapshot" (POST) is retired — see
// template-snapshots-post-gone.test.js for the 404 pin. GET/DELETE coverage
// stays below, unchanged.

describe('M6 (review r1) — the list is bounded, never unbounded', () => {
  it('binds the default page size when the caller supplies no query at all', async () => {
    const res = await call('GET', `/${TEMPLATE}/snapshots`);
    assert.equal(res.status, 200);
    const select = queries.find((q) => /^\s*SELECT .* FROM `fmb_template_snapshots`/is.test(q.sql) && /LIMIT/i.test(q.sql));
    assert.ok(select, 'the list read must bind a LIMIT');
    assert.deepEqual(select.params, [TEMPLATE, 50, 0]);
  });

  it('respects an explicit limit/offset', async () => {
    const res = await call('GET', `/${TEMPLATE}/snapshots?limit=5&offset=10`);
    assert.equal(res.status, 200);
    const select = queries.find((q) => /^\s*SELECT .* FROM `fmb_template_snapshots`/is.test(q.sql) && /LIMIT/i.test(q.sql));
    assert.deepEqual(select.params, [TEMPLATE, 5, 10]);
  });

  it('rejects a limit above the shared MAX_PAGE_SIZE ceiling rather than silently truncating it', async () => {
    const res = await call('GET', `/${TEMPLATE}/snapshots?limit=999999&offset=0`);
    assert.equal(res.status, 400);
    assert.equal(queries.filter((q) => /^\s*SELECT .* FROM `fmb_template_snapshots`/is.test(q.sql)).length, 0);
  });

  it('rejects a non-numeric limit', async () => {
    const res = await call('GET', `/${TEMPLATE}/snapshots?limit=abc&offset=0`);
    assert.equal(res.status, 400);
  });
});

describe('P2-1 (review r2) — the snapshots table can be absent on a degraded schema', () => {
  it('GET answers 200 with an empty, flagged list rather than 500', async () => {
    snapshotsTablePresent = false;
    const res = await call('GET', `/${TEMPLATE}/snapshots`);
    assert.equal(res.status, 200);
    assert.deepEqual(res.json.data.items, []);
    assert.equal(res.json.data.unavailable, true);
    assert.equal(typeof res.json.data.reason, 'string');
    assert.equal(
      queries.filter((q) => /^\s*SELECT .* FROM `fmb_template_snapshots`\s+WHERE template_id/is.test(q.sql)).length,
      0,
      'the bounded list read is never issued once the table is known absent',
    );
  });

  it('a present table answers unavailable: false, not just an empty list', async () => {
    const res = await call('GET', `/${TEMPLATE}/snapshots`);
    assert.equal(res.status, 200);
    assert.equal(res.json.data.unavailable, false);
    assert.deepEqual(res.json.data.items, []);
  });

  it('DELETE is refused with a non-500 status and a clear code, never a DELETE attempt', async () => {
    // S3 (fmb-1912 PR-4 residual): DELETE is admin-only now — an admin
    // caller is what isolates "the table is absent" from the (separate)
    // authz gate this test does not mean to exercise.
    currentUser = ADMIN;
    snapshotsTablePresent = false;
    const res = await call('DELETE', `/${TEMPLATE}/snapshots/${SNAPSHOT}`);
    assert.notEqual(res.status, 500);
    assert.equal(res.status, 503);
    assert.equal(res.json.error.code, 'SNAPSHOTS_UNAVAILABLE');
    assert.equal(queries.filter((q) => /^DELETE FROM `fmb_template_snapshots`/.test(q.sql)).length, 0);
  });
});

// S3 / fmb-1918 (fmb-1912 PR-4 residual): legacy-snapshot delete is admin
// only (design spec §6 decision 5) — narrower than GET/POST's owner/
// delegate/admin rule. Found by the PR-3 review; the route pre-dated the
// spec line.
describe('deleting a snapshot is admin-only (fmb-1918)', () => {
  it('the owner (non-admin) gets 403, not a silent 200 — the record IS visible to them, so this is not the existence-leak 404', async () => {
    const res = await call('DELETE', `/${TEMPLATE}/snapshots/${SNAPSHOT}`);
    assert.equal(res.status, 403, JSON.stringify(res.json));
    assert.equal(res.json.error.code, 'FORBIDDEN');
    assert.equal(queries.filter((q) => /^DELETE/.test(q.sql)).length, 0);
    assert.equal(rolledBack, true);
    assert.equal(committed, false);
  });

  it('a delegate (non-admin) also gets 403', async () => {
    // R-3-P1: a grant is honoured only for an editor/admin grantee — this
    // case is about the admin-only delete gate a legitimate delegate still
    // hits, not about the role floor, so the delegate here is an editor.
    currentUser = { ...GRANTEE, role: 'editor' };
    grantRows = [{ granted: 1 }];
    const res = await call('DELETE', `/${TEMPLATE}/snapshots/${SNAPSHOT}`);
    assert.equal(res.status, 403, JSON.stringify(res.json));
    assert.equal(res.json.error.code, 'FORBIDDEN');
    assert.equal(queries.filter((q) => /^DELETE/.test(q.sql)).length, 0);
  });

  it('R-3-P1: a plain-user grantee cannot even see the record, so this is the existence-leak 404, not the admin-only 403', async () => {
    currentUser = GRANTEE; // role: 'user'
    grantRows = [{ granted: 1 }];
    const res = await call('DELETE', `/${TEMPLATE}/snapshots/${SNAPSHOT}`);
    assert.equal(res.status, 404, JSON.stringify(res.json));
    assert.equal(queries.filter((q) => /^DELETE/.test(q.sql)).length, 0);
  });

  it('an admin may still delete', async () => {
    currentUser = ADMIN;
    const res = await call('DELETE', `/${TEMPLATE}/snapshots/${SNAPSHOT}`);
    assert.equal(res.status, 200, JSON.stringify(res.json));
    assert.equal(committed, true);
    assert.equal(rolledBack, false);
  });
});

describe('deleting a snapshot', () => {
  it('is scoped to the named template — a snapshot of another template 404s', async () => {
    currentUser = ADMIN;
    deleteExisting = [];
    const res = await call('DELETE', `/${TEMPLATE}/snapshots/${SNAPSHOT}`);
    assert.equal(res.status, 404);
    assert.equal(rolledBack, true);
    assert.equal(committed, false);
  });

  it('deletes the row bound to both ids', async () => {
    currentUser = ADMIN;
    const res = await call('DELETE', `/${TEMPLATE}/snapshots/${SNAPSHOT}`);
    assert.equal(res.status, 200);
    const del = queries.find((q) => /^DELETE FROM `fmb_template_snapshots`/.test(q.sql));
    assert.deepEqual(del.params, [SNAPSHOT, TEMPLATE]);
    assert.equal(committed, true);
  });
});
