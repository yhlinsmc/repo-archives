// docker-api/tests/edge/routes/app/flow-recipe-steps-preset-config-shape.test.js
//
// I3 (JSON-column shape): preset_config on the generic CRUD create/update
// path, via the ONE write primitive (assertStepInvariants,
// flow-step-invariants.js) — no column had shape validation before this PR
// (fmb-2102). Stubs the CRUD factory (as
// flow-recipe-steps-runs-on-conflict.test.js does) so this file isolates the
// new middleware from the factory's own write behaviour, on BOTH entry paths
// (POST create, PUT update).
const { test } = require('node:test');
const assert = require('node:assert');
const express = require('express');
const { makeStubReqLog } = require('../../../helpers/stub-req-log');

require.cache[require.resolve('../../../../src/edge/db')] = {
  exports: {
    pool: {
      ro: { query: async () => [] },
      rw: { getConnection: async () => ({ query: async () => [], release: () => {} }) },
    },
    t: (x) => x,
  },
};
require.cache[require.resolve('../../../../src/edge/routes/app/schema')] = {
  exports: { createCrudRoutes: () => (req, res) => res.json({ ok: true, reached: 'crud' }) },
};
const router = require('../../../../src/edge/routes/app/flow-recipe-steps');

function app(user) {
  const a = express(); a.use(express.json());
  a.use((req, _res, next) => { req.user = user; req.log = makeStubReqLog(); next(); }); // TEST-ONLY: production always sets req.log via createRequestId (request-id.js) before any router; this bare app has no such middleware.
  a.use('/', router);
  return a;
}
async function send(a, method, path, body) {
  const server = a.listen(0);
  try {
    const port = server.address().port;
    const res = await fetch(`http://127.0.0.1:${port}${path}`, {
      method, headers: { 'content-type': 'application/json' }, body: JSON.stringify(body || {}),
    });
    const json = await res.json().catch(() => ({}));
    return { status: res.status, json };
  } finally {
    server.close();
  }
}

const EDITOR = { id: 'u1', role: 'editor' };
const RECIPE_ID = 'aaaa0000-0000-0000-0000-000000000001';
const STEP_ID = 'bbbb0000-0000-0000-0000-000000000002';
const RULE = { itemsPath: 'tasks[*]', matchField: 'name', refsSource: 'remote_refs', writeField: 'id' };

test('POST with a malformed preset_config (rule missing a field) → 400 FLOW_PRESET_CONFIG_INVALID', async () => {
  const { status, json } = await send(app(EDITOR), 'POST', '/', {
    recipe_id: RECIPE_ID, name: 'S', url: 'https://compute.invalid/', method: 'POST', step_type: 'compute',
    preset_config: { kind: 'merge_by_key', rules: [{ itemsPath: 'a', matchField: 'b', refsSource: 'c' }] },
  });
  assert.strictEqual(status, 400);
  assert.strictEqual(json.error.code, 'FLOW_PRESET_CONFIG_INVALID');
});

test('PUT with a malformed preset_config (wrong kind) → 400 FLOW_PRESET_CONFIG_INVALID', async () => {
  const { status, json } = await send(app(EDITOR), 'PUT', `/${STEP_ID}`, {
    preset_config: { kind: 'bogus', rules: [] },
  });
  assert.strictEqual(status, 400);
  assert.strictEqual(json.error.code, 'FLOW_PRESET_CONFIG_INVALID');
});

test('PUT with a malformed preset_config (rule with an extra key) → 400 FLOW_PRESET_CONFIG_INVALID', async () => {
  const { status, json } = await send(app(EDITOR), 'PUT', `/${STEP_ID}`, {
    preset_config: { kind: 'merge_by_key', rules: [{ ...RULE, extra: 'x' }] },
  });
  assert.strictEqual(status, 400);
  assert.strictEqual(json.error.code, 'FLOW_PRESET_CONFIG_INVALID');
});

test('POST with a valid preset_config → 200, reaches CRUD', async () => {
  const { status, json } = await send(app(EDITOR), 'POST', '/', {
    recipe_id: RECIPE_ID, name: 'S', url: 'https://compute.invalid/', method: 'POST', step_type: 'compute',
    preset_config: { kind: 'merge_by_key', rules: [RULE] },
  });
  assert.strictEqual(status, 200);
  assert.strictEqual(json.reached, 'crud');
});

test('PUT with preset_config: null (clearing the slot) → 200, reaches CRUD', async () => {
  const { status, json } = await send(app(EDITOR), 'PUT', `/${STEP_ID}`, { preset_config: null });
  assert.strictEqual(status, 200);
  assert.strictEqual(json.reached, 'crud');
});

test('PUT naming no fields at all reaches CRUD unconditionally', async () => {
  const { status, json } = await send(app(EDITOR), 'PUT', `/${STEP_ID}`, { name: 'renamed' });
  assert.strictEqual(status, 200);
  assert.strictEqual(json.reached, 'crud');
});
