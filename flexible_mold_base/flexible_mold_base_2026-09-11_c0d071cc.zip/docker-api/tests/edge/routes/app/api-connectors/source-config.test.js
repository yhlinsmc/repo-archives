const { it, describe, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const {
  validateSourceConfig, normalizeForSourceKind, probeSourceColumns, SOURCE_KINDS, effectiveSelectKind,
} = require('../../../../../src/edge/routes/app/api-connectors/source-config');
const { STATIC_BODY_MAX_BYTES } = require('../../../../../src/shared/connector-source-limits');

const t = (n) => `fmb_${n}`;
// A conn stub: a blueprint id present in `blueprints`, and field keys present
// in `fieldKeys[blueprintId]`.
function makeConn({ blueprints = new Set(), fieldKeys = {} } = {}) {
  return {
    async query(sql, params) {
      if (/FROM `fmb_hierarchy_nodes` WHERE id = \?/.test(sql)) {
        return blueprints.has(params[0]) ? [{ id: params[0] }] : [];
      }
      if (/FROM `fmb_blueprint_fields`/.test(sql)) {
        const keys = fieldKeys[params[0]] || [];
        return keys.filter((k) => k === params[1]).map((k) => ({ field_key: k }));
      }
      return [];
    },
  };
}

describe('validateSourceConfig', () => {
  it('accepts http with a null source_config', async () => {
    assert.equal(await validateSourceConfig(makeConn(), t, 'http', null), null);
  });

  it('rejects an unknown source_kind', async () => {
    const msg = await validateSourceConfig(makeConn(), t, 'ftp', null);
    assert.match(msg, /source_kind/);
  });

  it('accepts a template one/pick config whose blueprint exists', async () => {
    const conn = makeConn({ blueprints: new Set(['bp1']) });
    const cfg = { blueprint_id: 'bp1', mode: 'one', select: { kind: 'pick' }, parts: ['outputs'] };
    assert.equal(await validateSourceConfig(conn, t, 'template', cfg), null);
  });

  it('rejects a template config whose blueprint does not exist', async () => {
    const cfg = { blueprint_id: 'ghost', mode: 'one', parts: ['outputs'] };
    const msg = await validateSourceConfig(makeConn(), t, 'template', cfg);
    assert.match(msg, /blueprint/i);
  });

  it('rejects a match on a field_key absent from the source blueprint', async () => {
    const conn = makeConn({ blueprints: new Set(['bp1']), fieldKeys: { bp1: ['name'] } });
    const cfg = { blueprint_id: 'bp1', mode: 'one', parts: ['outputs'],
      select: { kind: 'match', field: { field_key: 'missing' }, value: 'x' } };
    const msg = await validateSourceConfig(conn, t, 'template', cfg);
    assert.match(msg, /field_key/);
  });

  it("accepts a match on 'name' without touching blueprint_fields", async () => {
    const conn = makeConn({ blueprints: new Set(['bp1']) });
    const cfg = { blueprint_id: 'bp1', mode: 'one', parts: ['outputs'],
      select: { kind: 'match', field: 'name', value: '{{part}}' } };
    assert.equal(await validateSourceConfig(conn, t, 'template', cfg), null);
  });

  it('rejects an empty parts array', async () => {
    const conn = makeConn({ blueprints: new Set(['bp1']) });
    const cfg = { blueprint_id: 'bp1', mode: 'one', parts: [] };
    assert.match(await validateSourceConfig(conn, t, 'template', cfg), /parts/);
  });

  it('rejects a select on list mode (pick/match only apply to one)', async () => {
    const conn = makeConn({ blueprints: new Set(['bp1']) });
    const cfg = { blueprint_id: 'bp1', mode: 'list', select: { kind: 'pick' }, parts: ['outputs'] };
    assert.match(await validateSourceConfig(conn, t, 'template', cfg), /list/);
  });

  it('accepts static JSON that parses', async () => {
    assert.equal(await validateSourceConfig(makeConn(), t, 'static', { body: '{"a":1}' }), null);
  });

  it('rejects static body that does not parse', async () => {
    assert.match(await validateSourceConfig(makeConn(), t, 'static', { body: '{oops' }), /JSON/);
  });

  it('rejects a static body over the byte cap', async () => {
    const body = JSON.stringify({ a: 'x'.repeat(STATIC_BODY_MAX_BYTES) });
    assert.match(await validateSourceConfig(makeConn(), t, 'static', { body }), /64/);
  });
});

describe('normalizeForSourceKind', () => {
  it('leaves an http body\'s url/method/auth/dispatch untouched, but clears source_config to null (T14-R3)', () => {
    const body = { source_kind: 'http', url: 'https://x.test', method: 'POST', auth_type: 'bearer', dispatch_origin: 'infra' };
    assert.deepEqual(normalizeForSourceKind({ ...body }), { ...body, source_config: null });
  });

  it('forces url/method/auth/dispatch for a template body', () => {
    const out = normalizeForSourceKind({ source_kind: 'template', url: 'https://x.test', method: 'POST', auth_type: 'bearer', dispatch_origin: 'infra' });
    assert.equal(out.url, '');
    assert.equal(out.method, 'GET');
    assert.equal(out.auth_type, 'none');
    assert.equal(out.dispatch_origin, 'edge');
  });

  // R6-D2: a stale http request_config (headers/body still carrying {{var}}
  // tokens from before a kind switch) must not survive on a template/static
  // row — its Request section is hidden, so nothing can clear it but this.
  it('R6-D2: clears request_config to null for a template body carrying a stale http request template', () => {
    const out = normalizeForSourceKind({
      source_kind: 'template',
      request_config: { headers: { Authorization: 'Bearer {{id}}' }, body: '{"q":"{{id}}"}' },
    });
    assert.equal(out.request_config, null);
  });

  it('R6-D2: clears request_config to null for a static body carrying a stale http request template', () => {
    const out = normalizeForSourceKind({
      source_kind: 'static',
      request_config: { headers: { 'X-Trace': '{{id}}' } },
    });
    assert.equal(out.request_config, null);
  });

  it('R6-D2: leaves an http body\'s request_config untouched', () => {
    const rc = { headers: { Authorization: 'Bearer {{id}}' }, body: '{}' };
    const out = normalizeForSourceKind({ source_kind: 'http', request_config: rc });
    assert.deepEqual(out.request_config, rc);
  });

  it('lists every kind so a new one cannot silently skip normalisation', () => {
    assert.deepEqual(SOURCE_KINDS, ['http', 'template', 'static']);
  });
});

describe('probeSourceColumns', () => {
  it('returns true when the LIMIT 0 probe succeeds', async () => {
    const conn = { async query() { return []; } };
    assert.equal(await probeSourceColumns(conn, t), true);
  });

  it('returns false on ER_BAD_FIELD_ERROR/1054 (no-ALTER operator DB)', async () => {
    const conn = { async query() { const e = new Error('boom'); e.code = 'ER_BAD_FIELD_ERROR'; e.errno = 1054; throw e; } };
    assert.equal(await probeSourceColumns(conn, t), false);
  });

  it('rethrows any other query error', async () => {
    const conn = { async query() { throw new Error('connection reset'); } };
    await assert.rejects(() => probeSourceColumns(conn, t), /connection reset/);
  });
});

// D-F5: a no-DDL operator DB warn-skips the ALTER; CONNECTOR_COLS' fallback
// projection then omits source_kind entirely, so a row loaded through it has
// no `source_kind` property at all — reads as `undefined` in JS, never
// `null`. Every caller (index.js Step 7's guard today; the /prepare loader
// later) MUST coalesce that to 'http' itself before calling either function
// below — pin both halves of that contract: normalizeForSourceKind treats
// undefined as "not template/static" (falls through inert, same as 'http'),
// and validateSourceConfig does NOT silently accept a raw undefined kind, so
// a caller that forgets the coalesce fails loudly (400, not a silent pass)
// instead of writing an unvalidated row.
describe('undefined source_kind (no-DDL fallback, D-F5)', () => {
  it('normalizeForSourceKind leaves an undefined-kind body untouched (falls through as http-shaped)', () => {
    const body = { source_kind: undefined, url: 'https://x.test', method: 'POST', auth_type: 'bearer', dispatch_origin: 'infra' };
    assert.deepEqual(normalizeForSourceKind({ ...body }), body);
  });

  it('validateSourceConfig rejects a raw undefined source_kind (the caller must coalesce to \'http\' first)', async () => {
    const msg = await validateSourceConfig(makeConn(), t, undefined, null);
    assert.match(msg, /source_kind/);
  });
});

// R-C5: the one place the omitted-select default ('pick') lives — both
// resolveTemplateSource and the /usable projection call this instead of
// hand-copying the default.
describe('effectiveSelectKind', () => {
  it("defaults to 'pick' for a template mode-one config with no select", () => {
    const cfg = { blueprint_id: 'bp1', mode: 'one', parts: ['outputs'] };
    assert.equal(effectiveSelectKind('template', cfg), 'pick');
  });

  it('returns the stored select.kind for a template mode-one config with a select', () => {
    const cfg = { blueprint_id: 'bp1', mode: 'one', parts: ['outputs'], select: { kind: 'match', field: 'name', value: 'x' } };
    assert.equal(effectiveSelectKind('template', cfg), 'match');
  });

  it("returns null for a template mode-'list' config", () => {
    const cfg = { blueprint_id: 'bp1', mode: 'list', parts: ['outputs'] };
    assert.equal(effectiveSelectKind('template', cfg), null);
  });

  it('returns null for a static source', () => {
    assert.equal(effectiveSelectKind('static', { body: '{}' }), null);
  });

  it('returns null for an http source', () => {
    assert.equal(effectiveSelectKind('http', null), null);
  });

  it('returns null for a malformed source_config (not an object)', () => {
    assert.equal(effectiveSelectKind('template', 'not-an-object'), null);
  });
});
