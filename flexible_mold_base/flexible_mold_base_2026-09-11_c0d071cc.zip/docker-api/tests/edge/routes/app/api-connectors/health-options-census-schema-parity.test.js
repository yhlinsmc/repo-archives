/**
 * health-options-census-schema-parity.test.js — the spec §5.2 census SQL
 * (health.js's blueprint_fields SELECT) reads blueprint_id, field_key,
 * field_type, options_source, table_config; every one checked against the
 * ACTUAL DDL, without a live database — the same contract as
 * delegated-grants-schema-parity.test.js. A mock reading a wrong column name
 * is exactly what this test exists to catch (RULE: 新 SQL 必附 schema-parity test).
 */
const { describe, it, before } = require('node:test');
const assert = require('node:assert/strict');

const { buildEngineTableDDLs } = require('../../../../../src/table-ddls');

let cols;
before(() => {
  cols = new Set();
  for (const ddl of buildEngineTableDDLs((n) => n)) {
    if (!/CREATE TABLE IF NOT EXISTS `blueprint_fields`/.test(ddl)) continue;
    for (const line of ddl.split('\n')) {
      const m = line.trim().match(/^`?([a-z_]+)`?\s+(?:CHAR|VARCHAR|INT|DOUBLE|TIMESTAMP|JSON|TEXT|ENUM|BOOLEAN|TINYINT|BIGINT|DATETIME|DECIMAL|FLOAT|BLOB)\b/i);
      if (m) cols.add(m[1]);
    }
  }
});

describe('health options census — schema parity', () => {
  for (const c of ['blueprint_id', 'field_key', 'field_type', 'options_source', 'table_config']) {
    it(`blueprint_fields has ${c}`, () => assert.ok(cols.has(c), `missing ${c}`));
  }
});
