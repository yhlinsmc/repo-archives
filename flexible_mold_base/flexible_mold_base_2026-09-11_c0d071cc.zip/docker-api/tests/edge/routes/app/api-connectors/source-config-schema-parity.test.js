const { describe, it, before } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { buildEngineTableDDLs } = require('../../../../../src/table-ddls');

const SQL_TYPES = /^`?([a-z_]+)`?\s+(?:CHAR|VARCHAR|INT|DOUBLE|TIMESTAMP|JSON|TEXT|ENUM|BOOLEAN|TINYINT|BIGINT|DATETIME|DECIMAL|FLOAT|BLOB)\b/i;
let columnsByTable;
before(() => {
  columnsByTable = new Map();
  for (const ddl of buildEngineTableDDLs((n) => n)) {
    const m = ddl.match(/CREATE TABLE IF NOT EXISTS `([^`]+)`/);
    if (!m) continue;
    const cols = new Set();
    for (const raw of ddl.split('\n')) {
      const line = raw.trim();
      if (!line || line.startsWith('--')) continue;
      const cm = line.match(SQL_TYPES);
      if (cm) cols.add(cm[1]);
    }
    columnsByTable.set(m[1], cols);
  }
});

const SRC = fs.readFileSync(
  path.resolve(__dirname, '../../../../../src/edge/routes/app/api-connectors/source-config.js'), 'utf8',
);

describe('source-config validator — schema parity', () => {
  it('the new source columns exist on api_connectors', () => {
    const cols = columnsByTable.get('api_connectors');
    assert.ok(cols.has('source_kind'), 'api_connectors is missing source_kind');
    assert.ok(cols.has('source_config'), 'api_connectors is missing source_config');
  });

  it('the blueprint-existence probe reads a real column on hierarchy_nodes, via TABLES.* (not a literal)', () => {
    // The source file is a JS template literal whose SQL backticks are
    // backslash-escaped ("\`") to avoid terminating the outer literal —
    // match that literal backslash, not a bare backtick.
    assert.match(SRC, /FROM \\`\$\{t\(TABLES\.HIERARCHY_NODES\)\}\\` WHERE id = \?/);
    assert.ok(columnsByTable.get('hierarchy_nodes').has('id'));
  });

  it('the field_key probe reads real columns on blueprint_fields, via TABLES.* (not a literal)', () => {
    assert.match(SRC, /FROM \\`\$\{t\(TABLES\.BLUEPRINT_FIELDS\)\}\\` WHERE blueprint_id = \? AND field_key = \?/);
    const cols = columnsByTable.get('blueprint_fields');
    assert.ok(cols.has('blueprint_id') && cols.has('field_key'));
  });
});
