/**
 * health-options-census.test.js — route-level coverage for the health.js
 * blueprint_fields walk that builds optionsReferencedPairs (spec §5.2/§5.3):
 * a scalar field's options_source, and a TABLE field's
 * table_config.columns[].options_source, both count; a NON-table field's
 * table_config.columns must NOT (G-1B-8 — mirrors the FE guard in
 * collect-connector-options-refs.ts, which only walks columns for
 * field_type === 'table').
 */
const { describe, it, before, after } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

describe('GET /health — options census field_type guard (G-1B-8)', () => {
  const dbKey = require.resolve('../../../../../src/edge/db');
  let queryImpl;
  const conn = {
    async query(sql, params) { return queryImpl(sql, params); },
    release() {},
    destroy() {},
  };
  let server; let baseUrl;

  before(async () => {
    require.cache[dbKey] = {
      id: dbKey, filename: dbKey, loaded: true,
      exports: {
        pool: { ro: { getConnection: async () => conn }, rw: { getConnection: async () => conn } },
        t: (n) => `fmb_${n}`,
      },
    };
    delete require.cache[require.resolve('../../../../../src/edge/routes/app/api-connectors/health')];
    const register = require('../../../../../src/edge/routes/app/api-connectors/health');
    const app = express();
    app.use(express.json());
    app.use((req, _res, next) => { req.user = { id: 'admin1', role: 'admin' }; next(); });
    const router = express.Router();
    register(router);
    app.use('/edge/app/api-connectors', router);
    server = http.createServer(app);
    await new Promise((r) => server.listen(0, r));
    baseUrl = `http://127.0.0.1:${server.address().port}`;
  });
  after(() => server && server.close());

  async function get() {
    const res = await fetch(`${baseUrl}/edge/app/api-connectors/health`);
    return { status: res.status, body: await res.json() };
  }

  const optionsOnlyConnector = (id) => ({
    id, blueprint_id: 'bp1', request_config: '{}',
    response_config: JSON.stringify({
      outputs: [{ id: 'o1', from: { mode: 'list', path: 'data' }, to: { mode: 'options', value_path: 'id' } }],
    }),
  });

  it('a TABLE field column referencing the output counts it as healthy', async () => {
    queryImpl = (sql) => {
      if (/FROM `fmb_api_connectors`/.test(sql)) return [optionsOnlyConnector('c-tbl')];
      if (/FROM `fmb_blueprint_fields`/.test(sql)) {
        return [{
          blueprint_id: 'bp1', field_key: 'rows', field_type: 'table',
          table_config: JSON.stringify({
            columns: [{ key: 'vlan', options_source: { type: 'connector', connector_id: 'c-tbl', output_id: 'o1' } }],
          }),
        }];
      }
      return [];
    };
    const r = await get();
    assert.equal(r.status, 200);
    assert.equal(r.body.data.statuses['c-tbl'].status, 'healthy');
  });

  it('a NON-table field with a stale table_config.columns entry does NOT count — the connector stays broken-no-op', async () => {
    queryImpl = (sql) => {
      if (/FROM `fmb_api_connectors`/.test(sql)) return [optionsOnlyConnector('c-stale')];
      if (/FROM `fmb_blueprint_fields`/.test(sql)) {
        return [{
          // field_type is 'select', not 'table' — table_config.columns here is
          // stale leftover (e.g. from a field-type change) and must be ignored.
          blueprint_id: 'bp1', field_key: 'region', field_type: 'select',
          table_config: JSON.stringify({
            columns: [{ key: 'vlan', options_source: { type: 'connector', connector_id: 'c-stale', output_id: 'o1' } }],
          }),
        }];
      }
      return [];
    };
    const r = await get();
    assert.equal(r.status, 200);
    assert.equal(r.body.data.statuses['c-stale'].status, 'broken-no-op');
  });
});
