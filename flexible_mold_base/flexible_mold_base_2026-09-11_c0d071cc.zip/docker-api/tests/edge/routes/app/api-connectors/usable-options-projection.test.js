/**
 * usable-options-projection.test.js — R-1-C1: projectOutput must carry a
 * to.mode:'options' output through /usable, or the FE options-list picker
 * (spec §4.2) and the referenced-options visibility predicate
 * (useFmbConnectors.ts) have nothing to read.
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const { buildUsableProjection } = require('../../../../../src/edge/routes/app/api-connectors/usable');

const ROW = {
  id: 'c1', name: 'C', description: null, blueprint_id: 'bp1',
  request_config: {},
  response_config: { outputs: [
    { id: 'o1', from: { mode: 'list', path: 'items' }, to: { mode: 'options', value_path: 'id', label_path: 'name' } },
  ] },
};

describe('buildUsableProjection — options output', () => {
  it('carries a to.mode:options output through the projection with value_path + label_path', () => {
    const p = buildUsableProjection(ROW, new Map());
    const out = p.response_config.outputs.find((o) => o.id === 'o1');
    assert.ok(out, 'options output survives projection');
    assert.deepStrictEqual(out, {
      id: 'o1',
      from: { mode: 'list', path: 'items' },
      to: { mode: 'options', value_path: 'id', label_path: 'name' },
    });
  });

  it('omits label_path when the stored output has none', () => {
    const row = {
      ...ROW,
      response_config: { outputs: [
        { id: 'o2', from: { mode: 'list', path: '' }, to: { mode: 'options', value_path: 'code' } },
      ] },
    };
    const p = buildUsableProjection(row, new Map());
    const out = p.response_config.outputs.find((o) => o.id === 'o2');
    assert.deepStrictEqual(out.to, { mode: 'options', value_path: 'code' });
    assert.ok(!('label_path' in out.to));
  });
});
