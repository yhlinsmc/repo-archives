/**
 * source-io-health.test.js — PR-5 Task 17: connector health skip for a
 * non-http source, io.js export/import carrying source_kind/source_config,
 * and serializeRead's passthrough of the two columns.
 *
 * Three harnesses, mirroring the existing per-route test files in this repo:
 *   - serializeRead: pure function, no server needed.
 *   - health.js: register(router) mounted directly (tests/unit/connectors-
 *     health-route.test.js pattern), a single queryImpl(sql) mock.
 *   - io.js: register(router) mounted directly, a conn stub keyed by SQL shape
 *     (tests/unit/api-connectors-io.test.js pattern).
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const { serializeRead } = require('../../../../../src/edge/routes/app/api-connectors/serializer');

describe('serializeRead — source columns survive every early-return path', () => {
  it('path A (auth_config == null): source_kind/source_config pass through', () => {
    const out = serializeRead({
      id: 'c', url: 'https://x.test', auth_config: null,
      source_kind: 'template', source_config: { blueprint_id: 'bp1', mode: 'one', parts: ['outputs'] },
    });
    assert.equal(out.source_kind, 'template');
    assert.deepEqual(out.source_config, { blueprint_id: 'bp1', mode: 'one', parts: ['outputs'] });
  });

  it('path B (auth_config not an object — corrupt row): source_kind/source_config pass through', () => {
    const out = serializeRead({
      id: 'c', url: 'https://x.test', auth_config: 'not-json',
      source_kind: 'static', source_config: { body: '{}' },
    });
    assert.equal(out.source_kind, 'static');
    assert.deepEqual(out.source_config, { body: '{}' });
  });

  it('path C (normal auth_config object): source_kind/source_config pass through', () => {
    const out = serializeRead({
      id: 'c', url: 'https://x.test', auth_type: 'none', auth_config: {},
      source_kind: 'http', source_config: null,
    });
    assert.equal(out.source_kind, 'http');
    assert.equal(out.source_config, null);
  });
});

describe('GET /health — every source_kind derives (the n/a short-circuit is gone)', () => {
  const dbKey = require.resolve('../../../../../src/edge/db');
  let queryImpl;
  const conn = {
    async query(sql, params) { return queryImpl(sql, params); },
    release() {},
    destroy() {},
  };
  let server; let baseUrl;

  before(async () => {
    require.cache[dbKey] = {
      id: dbKey, filename: dbKey, loaded: true,
      exports: {
        pool: { ro: { getConnection: async () => conn }, rw: { getConnection: async () => conn } },
        t: (n) => `fmb_${n}`,
      },
    };
    delete require.cache[require.resolve('../../../../../src/edge/routes/app/api-connectors/health')];
    const register = require('../../../../../src/edge/routes/app/api-connectors/health');
    const app = express();
    app.use(express.json());
    app.use((req, _res, next) => { req.user = { id: 'admin1', role: 'admin' }; next(); });
    const router = express.Router();
    register(router);
    app.use('/edge/app/api-connectors', router);
    server = http.createServer(app);
    await new Promise((r) => server.listen(0, r));
    baseUrl = `http://127.0.0.1:${server.address().port}`;
  });
  after(() => server && server.close());

  async function get() {
    const res = await fetch(`${baseUrl}/edge/app/api-connectors/health`);
    return { status: res.status, body: await res.json() };
  }

  it('derives real health for a template connector — a mapped output resolving to a known field is healthy', async () => {
    queryImpl = (sql) => {
      if (/FROM `fmb_api_connectors`/.test(sql)) {
        return [
          {
            id: 'c-tpl', blueprint_id: 'bp1', source_kind: 'template',
            request_config: '{}',
            response_config: JSON.stringify({ outputs: [{ id: 'o1', from: { mode: 'value', path: 'a' }, to: { mode: 'field', field_key: 'notes' } }] }),
          },
        ];
      }
      if (/FROM `fmb_blueprint_fields`/.test(sql)) return [{ blueprint_id: 'bp1', field_key: 'notes' }];
      return [];
    };
    const r = await get();
    assert.equal(r.status, 200);
    assert.deepEqual(r.body.data.statuses['c-tpl'], {
      status: 'healthy', resolved_count: 1, missing_count: 0, missing_keys: [], secret_decryptable: true,
    });
  });

  it('derives real health for a template connector — a mapped output to an unknown field is broken-no-op, not n/a', async () => {
    queryImpl = (sql) => {
      if (/FROM `fmb_api_connectors`/.test(sql)) {
        return [
          {
            id: 'c-tpl', blueprint_id: 'bp1', source_kind: 'template',
            request_config: '{}',
            response_config: JSON.stringify({ outputs: [{ id: 'o1', from: { mode: 'value', path: 'a' }, to: { mode: 'field', field_key: 'ghost' } }] }),
          },
        ];
      }
      if (/FROM `fmb_blueprint_fields`/.test(sql)) return [{ blueprint_id: 'bp1', field_key: 'notes' }];
      return [];
    };
    const r = await get();
    assert.equal(r.status, 200);
    assert.equal(r.body.data.statuses['c-tpl'].status, 'broken-no-op');
  });

  it('reports status "unbound" for a static connector with no blueprint — never n/a', async () => {
    queryImpl = (sql) => {
      if (/FROM `fmb_api_connectors`/.test(sql)) {
        return [{ id: 'c-static', blueprint_id: null, source_kind: 'static', request_config: '{}', response_config: '{}' }];
      }
      return [];
    };
    const r = await get();
    assert.equal(r.status, 200);
    assert.equal(r.body.data.statuses['c-static'].status, 'unbound');
  });

  it('an http connector and a template connector both derive real status side by side', async () => {
    queryImpl = (sql) => {
      if (/FROM `fmb_api_connectors`/.test(sql)) {
        return [
          { id: 'c-http', blueprint_id: 'bp1', source_kind: 'http', request_config: '{}',
            response_config: JSON.stringify({ outputs: [{ id: 'o1', from: { mode: 'value', path: 'a' }, to: { mode: 'field', field_key: 'notes' } }] }) },
          { id: 'c-tpl', blueprint_id: 'bp1', source_kind: 'template', request_config: '{}', response_config: '{}' },
        ];
      }
      if (/FROM `fmb_blueprint_fields`/.test(sql)) return [{ blueprint_id: 'bp1', field_key: 'notes' }];
      return [];
    };
    const r = await get();
    assert.equal(r.status, 200);
    assert.equal(r.body.data.statuses['c-http'].status, 'healthy');
    // c-tpl declares no outputs and references no options list — a real
    // no-op derive, the same as an http connector in the same shape.
    assert.equal(r.body.data.statuses['c-tpl'].status, 'broken-no-op');
  });

  it('source_kind absent from the row (no-DDL SELECT): retries without the column, every row still derives as http (D-F5)', async () => {
    queryImpl = (sql) => {
      if (/FROM `fmb_api_connectors`/.test(sql)) {
        if (/source_kind/.test(sql)) {
          const e = new Error("Unknown column 'source_kind' in 'field list'");
          e.code = 'ER_BAD_FIELD_ERROR'; e.errno = 1054;
          throw e;
        }
        // Fallback projection — no source_kind field at all.
        return [
          { id: 'c-legacy', blueprint_id: 'bp1', request_config: '{}',
            response_config: JSON.stringify({ outputs: [{ id: 'o1', from: { mode: 'value', path: 'a' }, to: { mode: 'field', field_key: 'notes' } }] }) },
        ];
      }
      if (/FROM `fmb_blueprint_fields`/.test(sql)) return [{ blueprint_id: 'bp1', field_key: 'notes' }];
      return [];
    };
    const r = await get();
    assert.equal(r.status, 200, 'a missing source_kind column must not degrade the whole response to an empty map');
    assert.equal(r.body.data.statuses['c-legacy'].status, 'healthy');
  });

  it('a static connector with a referenced options list and no field/cell/rows outputs is healthy (spec §5.3)', async () => {
    queryImpl = (sql) => {
      if (/FROM `fmb_api_connectors`/.test(sql)) {
        return [
          {
            id: 'c-static', blueprint_id: 'bp1', source_kind: 'static',
            request_config: '{}',
            response_config: JSON.stringify({ outputs: [{ id: 'o1', from: { mode: 'value', path: 'a' }, to: { mode: 'options' } }] }),
          },
        ];
      }
      if (/FROM `fmb_blueprint_fields`/.test(sql)) {
        return [{
          blueprint_id: 'bp1', field_key: 'status', field_type: 'select',
          options_source: JSON.stringify({ type: 'connector', connector_id: 'c-static', output_id: 'o1' }),
        }];
      }
      return [];
    };
    const r = await get();
    assert.equal(r.status, 200);
    assert.deepEqual(r.body.data.statuses['c-static'], {
      status: 'healthy', resolved_count: 0, missing_count: 0, missing_keys: [], secret_decryptable: true,
    });
  });

  it('a static connector with an unreferenced options list and no other outputs is broken-no-op', async () => {
    queryImpl = (sql) => {
      if (/FROM `fmb_api_connectors`/.test(sql)) {
        return [
          {
            id: 'c-static', blueprint_id: 'bp1', source_kind: 'static',
            request_config: '{}',
            response_config: JSON.stringify({ outputs: [{ id: 'o1', from: { mode: 'value', path: 'a' }, to: { mode: 'options' } }] }),
          },
        ];
      }
      // A field on the same blueprint exists, but its options_source names a
      // DIFFERENT connector — c-static's own output 'o1' is referenced by nothing.
      if (/FROM `fmb_blueprint_fields`/.test(sql)) {
        return [{
          blueprint_id: 'bp1', field_key: 'status', field_type: 'select',
          options_source: JSON.stringify({ type: 'connector', connector_id: 'c-other', output_id: 'o1' }),
        }];
      }
      return [];
    };
    const r = await get();
    assert.equal(r.status, 200);
    assert.equal(r.body.data.statuses['c-static'].status, 'broken-no-op');
  });
});

describe('io.js export/import — source_kind/source_config', () => {
  const dbKey = require.resolve('../../../../../src/edge/db');
  let state;
  function makeConn() {
    return {
      async query(sql, params) {
        state.queries.push({ sql, params });
        if (/SELECT name, description.*FROM `fmb_api_connectors` WHERE id = \?/s.test(sql)) {
          return state.exportRow ? [state.exportRow] : [];
        }
        if (/SELECT timeout_ms FROM `fmb_api_connectors` WHERE id = \?/.test(sql)) {
          return [];
        }
        if (/SELECT blueprint_id FROM `fmb_api_connector_blueprints` WHERE connector_id = \?/.test(sql)) {
          return [];
        }
        // Tolerant per-connector source-kind/config export probe.
        if (/SELECT source_kind, source_config FROM `fmb_api_connectors` WHERE id = \?/.test(sql)) {
          return state.sourceRow ? [state.sourceRow] : [];
        }
        // Write-guard's columns-exist probe (LIMIT 0).
        if (/SELECT source_kind, source_config FROM `fmb_api_connectors` LIMIT 0/.test(sql)) {
          if (state.noDDL) {
            const e = new Error("Unknown column 'source_kind' in 'field list'");
            e.code = 'ER_BAD_FIELD_ERROR'; e.errno = 1054;
            throw e;
          }
          return [];
        }
        // validateSourceConfig's template blueprint_id existence check.
        if (/SELECT id FROM `fmb_hierarchy_nodes` WHERE id = \? LIMIT 1/.test(sql)) {
          return state.templateBlueprintExists ? [{ id: params[0] }] : [];
        }
        if (/SELECT id, parent_id, name FROM `fmb_hierarchy_nodes`/.test(sql)) {
          return state.nodes || [];
        }
        if (/SELECT 1 FROM `fmb_hierarchy_nodes`/.test(sql)) {
          return state.blueprintExists ? [{ 1: 1 }] : [];
        }
        if (/^INSERT INTO `fmb_api_connectors`/.test(sql.trim())) {
          state.insertSql = sql;
          state.insertParams = params;
          return { affectedRows: 1 };
        }
        if (/UPDATE `fmb_api_connectors` SET source_kind = \?, source_config = \?/.test(sql)) {
          // Retained as a canary: R-G2 folded source_kind/source_config into
          // the core INSERT (one atomic statement) and deleted this follow-up
          // UPDATE — if it ever fires again, the atomicity fix regressed.
          state.sourceUpdateParams = params;
          return { affectedRows: 1 };
        }
        if (/UPDATE `fmb_api_connectors` SET status=/.test(sql)) {
          return { affectedRows: 1 };
        }
        if (/SELECT \* FROM `fmb_api_connectors` WHERE id = \?/.test(sql)) {
          return [{ id: params[0], name: 'imported' }];
        }
        if (/SELECT `value` FROM `fmb_system_settings` WHERE `key` = \?/.test(sql)) {
          return [];
        }
        return [];
      },
      release() {},
    };
  }
  const poolSpy = {
    ro: { async getConnection() { return makeConn(); }, async query(sql, params) { return makeConn().query(sql, params); } },
    rw: { async getConnection() { return makeConn(); }, async query(sql, params) { return makeConn().query(sql, params); } },
  };

  let server; let base; let currentUser;

  before(async () => {
    require.cache[dbKey] = {
      id: dbKey, filename: dbKey, loaded: true,
      exports: { pool: poolSpy, t: (name) => `fmb_${name}` },
    };
    delete require.cache[require.resolve('../../../../../src/edge/routes/app/api-connectors/io')];
    const register = require('../../../../../src/edge/routes/app/api-connectors/io');
    const app = express();
    app.use(express.json());
    app.use((req, _res, next) => { req.user = currentUser; next(); });
    const router = express.Router();
    register(router);
    app.use('/c', router);
    server = http.createServer(app);
    await new Promise((r) => server.listen(0, r));
    base = `http://127.0.0.1:${server.address().port}`;
  });
  after(() => server && server.close());

  beforeEach(() => {
    state = { queries: [], nodes: [], insertParams: null, sourceUpdateParams: null };
    currentUser = { id: 'admin-1', role: 'admin', email: 'a@x' };
  });

  async function req(method, path, body) {
    const res = await fetch(`${base}${path}`, {
      method,
      headers: { 'content-type': 'application/json' },
      body: body ? JSON.stringify(body) : undefined,
    });
    return { status: res.status, json: await res.json() };
  }

  it('export of a template connector carries source_kind + source_config alongside bindings', async () => {
    state.exportRow = {
      name: 'tpl', description: null, is_active: 1,
      blueprint_id: null, method: 'GET', url: '',
      auth_type: 'none', auth_config: null,
      request_config: null, response_config: null,
    };
    state.sourceRow = {
      source_kind: 'template',
      source_config: JSON.stringify({ blueprint_id: 'bp1', mode: 'one', parts: ['outputs'] }),
    };
    const { status, json } = await req('GET', '/c/abc/export');
    assert.equal(status, 200);
    assert.equal(json.data.source_kind, 'template');
    assert.deepEqual(json.data.source_config, { blueprint_id: 'bp1', mode: 'one', parts: ['outputs'] });
    assert.deepEqual(json.data.bindings, [], 'bindings still exported alongside the new columns');
  });

  it('export degrades to source_kind=http/source_config=null when the target lacks the columns (no-ALTER)', async () => {
    state.exportRow = {
      name: 'w', description: null, is_active: 1,
      blueprint_id: null, method: 'GET', url: 'http://svc/x',
      auth_type: 'none', auth_config: null,
      request_config: null, response_config: null,
    };
    state.sourceRow = null; // probe returns no row → default
    const { status, json } = await req('GET', '/c/abc/export');
    assert.equal(status, 200);
    assert.equal(json.data.source_kind, 'http');
    assert.strictEqual(json.data.source_config, null);
  });

  it('import of a template connector whose source blueprint exists → 201, the core INSERT names source_kind/source_config, no separate UPDATE', async () => {
    state.templateBlueprintExists = true;
    const { status, json } = await req('POST', '/c/import', {
      connector: {
        name: 'tpl', source_kind: 'template',
        source_config: { blueprint_id: 'bp1', mode: 'one', parts: ['outputs'] },
      },
    });
    assert.equal(status, 201, `expected 201, got ${status}: ${JSON.stringify(json)}`);
    assert.equal(state.sourceUpdateParams, null, 'R-G2: the follow-up UPDATE is gone — one atomic INSERT now carries the columns');
    assert.match(state.insertSql, /\bsource_kind\b/);
    assert.match(state.insertSql, /\bsource_config\b/);
    const kindIdx = state.insertParams.length - 2;
    const configIdx = state.insertParams.length - 1;
    assert.equal(state.insertParams[kindIdx], 'template');
    assert.deepEqual(JSON.parse(state.insertParams[configIdx]), { blueprint_id: 'bp1', mode: 'one', parts: ['outputs'] });
    // The main INSERT stores the inert http-only columns for a non-http row.
    assert.equal(state.insertParams[6], 'GET', 'method normalised');
    assert.equal(state.insertParams[7], '', 'url normalised to empty');
  });

  it('import of a template connector whose source blueprint is absent → 400 SOURCE_BLUEPRINT_UNKNOWN, no insert', async () => {
    state.templateBlueprintExists = false;
    const { status, json } = await req('POST', '/c/import', {
      connector: {
        name: 'tpl', source_kind: 'template',
        source_config: { blueprint_id: 'ghost-bp', mode: 'one', parts: ['outputs'] },
      },
    });
    assert.equal(status, 400);
    assert.equal(json.error.code, 'SOURCE_BLUEPRINT_UNKNOWN');
    assert.equal(state.insertParams, null, 'an unresolved template source must not INSERT');
  });

  it('import of a template connector with url:\'\' is NOT rejected by the http url guard', async () => {
    state.templateBlueprintExists = true;
    const { status, json } = await req('POST', '/c/import', {
      connector: {
        name: 'tpl', url: '', source_kind: 'template',
        source_config: { blueprint_id: 'bp1', mode: 'one', parts: ['outputs'] },
      },
    });
    assert.equal(status, 201, `a template import with url:'' must not 400 on the url guard, got ${status}: ${JSON.stringify(json)}`);
  });

  it('import of a static connector → 201, no blueprint check required, INSERT names source_kind', async () => {
    const { status, json } = await req('POST', '/c/import', {
      connector: { name: 'static-c', source_kind: 'static', source_config: { body: '{"a":1}' } },
    });
    assert.equal(status, 201, `expected 201, got ${status}: ${JSON.stringify(json)}`);
    assert.equal(state.sourceUpdateParams, null);
    const kindIdx = state.insertParams.length - 2;
    assert.equal(state.insertParams[kindIdx], 'static');
  });

  it('import of a non-http source on a no-DDL target → 409 SOURCE_KIND_UNAVAILABLE, no insert', async () => {
    state.noDDL = true;
    const { status, json } = await req('POST', '/c/import', {
      connector: {
        name: 'tpl', source_kind: 'template',
        source_config: { blueprint_id: 'bp1', mode: 'one', parts: ['outputs'] },
      },
    });
    assert.equal(status, 409);
    assert.equal(json.error.code, 'SOURCE_KIND_UNAVAILABLE');
    assert.equal(state.insertParams, null, 'a no-DDL non-http import must not INSERT');
  });

  it('a plain http import (no source_kind in the payload): no separate UPDATE; the INSERT names source_kind=\'http\' when the probe finds the columns', async () => {
    state.blueprintExists = true;
    const { status } = await req('POST', '/c/import', {
      connector: { name: 'w', url: 'http://svc', blueprint_id: 'bp-1', auth_type: 'none' },
    });
    assert.equal(status, 201);
    assert.equal(state.sourceUpdateParams, null, 'no separate UPDATE, atomic or otherwise');
    assert.match(state.insertSql, /\bsource_kind\b/, 'R-G2: named whenever the probe says the columns exist, regardless of kind');
    const kindIdx = state.insertParams.length - 2;
    const configIdx = state.insertParams.length - 1;
    assert.equal(state.insertParams[kindIdx], 'http');
    assert.strictEqual(state.insertParams[configIdx], null);
  });

  it('a plain http import on a no-DDL target (probe false): INSERT does not name source_kind/source_config, no UPDATE', async () => {
    state.noDDL = true;
    state.blueprintExists = true;
    const { status, json } = await req('POST', '/c/import', {
      connector: { name: 'w', url: 'http://svc', blueprint_id: 'bp-1', auth_type: 'none' },
    });
    assert.equal(status, 201, `expected 201, got ${status}: ${JSON.stringify(json)}`);
    assert.equal(state.sourceUpdateParams, null);
    assert.equal(/\bsource_kind\b/.test(state.insertSql), false, 'no-DDL: the columns physically do not exist, so the INSERT must not name them');
    assert.equal(/\bsource_config\b/.test(state.insertSql), false);
  });
});
