const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const { validateResponseOutputs, validateConnectorCoherence } = require('../../../../../src/edge/routes/app/api-connectors/validate');

const optOut = (over = {}) => ({ id: 'o-opt', from: { mode: 'list', path: 'data.items' }, to: { mode: 'options', value_path: 'id', label_path: 'name', ...over } });
const rowsOut = () => ({ id: 'o-rows', from: { mode: 'list', path: '' }, to: { mode: 'rows', table_key: 'tbl', columns: [{ column_key: 'c', element_field: 'c' }] } });
const fieldOut = () => ({ id: 'o-fld', from: { mode: 'value', path: 'x' }, to: { mode: 'field', field_key: 'f' } });

describe('validateResponseOutputs — options output', () => {
  it('accepts a well-formed options output', () => {
    assert.equal(validateResponseOutputs({ outputs: [optOut()] }), null);
  });
  it('accepts an options output with a blank list path (root array) and no label_path', () => {
    assert.equal(validateResponseOutputs({ outputs: [{ id: 'o', from: { mode: 'list', path: '' }, to: { mode: 'options', value_path: 'id' } }] }), null);
  });
  it('rejects an options output whose from.mode is not list', () => {
    assert.match(validateResponseOutputs({ outputs: [{ id: 'o', from: { mode: 'value', path: 'x' }, to: { mode: 'options', value_path: 'id' } }] }), /options output requires from\.mode 'list'/);
  });
  it('rejects an options output with an empty value_path', () => {
    assert.match(validateResponseOutputs({ outputs: [optOut({ value_path: '' })] }), /options output value_path/);
  });
  it('rejects an options output with a present-but-empty label_path', () => {
    assert.match(validateResponseOutputs({ outputs: [optOut({ label_path: '' })] }), /options output label_path/);
  });
  it('rejects a duplicate output id across outputs[]', () => {
    assert.match(validateResponseOutputs({ outputs: [optOut(), optOut()] }), /output id/i);
  });
});

describe('validateConnectorCoherence — options excluded from fan-out totals', () => {
  it('accepts one rows output + one options output (options is neither fill nor fan-out)', () => {
    assert.equal(validateConnectorCoherence({ input_cells: [] }, { outputs: [rowsOut(), optOut()] }), null);
  });
  it('still rejects one rows output + one field output', () => {
    assert.equal(validateConnectorCoherence({ input_cells: [] }, { outputs: [rowsOut(), fieldOut()] }), 'A fan-out connector can only have Table rows outputs.');
  });
  it('accepts an options-only connector', () => {
    assert.equal(validateConnectorCoherence({ input_cells: [] }, { outputs: [optOut()] }), null);
  });
});

describe('validateResponseOutputs — id uniqueness scoped to options outputs (spec §1.3)', () => {
  it('accepts two non-options outputs sharing the same id (pre-existing, unenforced)', () => {
    const a = { id: 'dup', from: { mode: 'value', path: 'a' }, to: { mode: 'field', field_key: 'f1' } };
    const b = { id: 'dup', from: { mode: 'value', path: 'b' }, to: { mode: 'field', field_key: 'f2' } };
    assert.equal(validateResponseOutputs({ outputs: [a, b] }), null);
  });
  it('rejects two options outputs sharing the same id', () => {
    assert.match(validateResponseOutputs({ outputs: [optOut(), optOut()] }), /output id 'o-opt' is not unique/);
  });
  it('rejects an options output whose id collides with a non-options output id', () => {
    const clash = { id: 'o-opt', from: { mode: 'value', path: 'x' }, to: { mode: 'field', field_key: 'f' } };
    assert.match(validateResponseOutputs({ outputs: [optOut(), clash] }), /output id 'o-opt' is not unique/);
  });
});

describe('validateResponseOutputs — options output rejects from.where (writes nowhere)', () => {
  it('rejects an options output carrying from.where', () => {
    const withWhere = optOut();
    withWhere.from.where = { column: 'status', op: 'eq', value: 'active' };
    assert.match(validateResponseOutputs({ outputs: [withWhere] }), /must not carry from\.where/);
  });
});

describe('validateResponseOutputs — options output paths are trimmed (G-1B-1)', () => {
  it('rejects a whitespace-only value_path', () => {
    assert.match(validateResponseOutputs({ outputs: [optOut({ value_path: '   ' })] }), /options output value_path/);
  });
  it('rejects a whitespace-only label_path', () => {
    assert.match(validateResponseOutputs({ outputs: [optOut({ label_path: '\t\n ' })] }), /options output label_path/);
  });
});

describe('validateResponseOutputs — options output rejects unknown to-keys (G-1B-2)', () => {
  it('rejects a stray key on an options sink', () => {
    const stray = optOut();
    stray.to.field_key = 'leftover';
    assert.match(validateResponseOutputs({ outputs: [stray] }), /options output 'to' has an unknown key 'field_key'/);
  });
  it('accepts an options sink with only mode/value_path/label_path', () => {
    assert.equal(validateResponseOutputs({ outputs: [optOut()] }), null);
  });
});
