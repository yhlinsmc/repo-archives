// docker-api/tests/edge/routes/app/flow-recipes-shape-guard.test.js
//
// I3 (JSON-column shape): compare_spec / link_extract / external_id_extract on the generic CRUD
// create/update path, via the ONE write primitive (assertStepInvariants,
// flow-step-invariants.js) — no column had shape validation before this PR
// (fmb-2102). Stubs the CRUD factory (as flow-recipes-runs-on-conflict.test.js
// does) so this file isolates the new middleware from the factory's own write
// behaviour, on BOTH entry paths (POST create, PUT update).
const { test } = require('node:test');
const assert = require('node:assert');
const express = require('express');

require.cache[require.resolve('../../../../src/edge/db')] = {
  exports: {
    pool: {
      ro: { query: async () => [] },
      rw: { getConnection: async () => ({ query: async () => [], release: () => {} }) },
    },
    t: (x) => x,
  },
};
require.cache[require.resolve('../../../../src/edge/routes/app/schema')] = {
  exports: { createCrudRoutes: () => (req, res) => res.json({ ok: true, reached: 'crud' }) },
};
const router = require('../../../../src/edge/routes/app/flow-recipes');

function app(user) {
  const a = express(); a.use(express.json());
  a.use((req, _res, next) => { req.user = user; next(); });
  a.use('/', router);
  return a;
}
async function send(a, method, path, body) {
  const server = a.listen(0);
  try {
    const port = server.address().port;
    const res = await fetch(`http://127.0.0.1:${port}${path}`, {
      method, headers: { 'content-type': 'application/json' }, body: JSON.stringify(body || {}),
    });
    const json = await res.json().catch(() => ({}));
    return { status: res.status, json };
  } finally {
    server.close();
  }
}

const EDITOR = { id: 'u1', role: 'editor' };
const RECIPE_ID = 'aaaa0000-0000-0000-0000-000000000001';

test('POST with a malformed compare_spec (missing remotePath) → 400 FLOW_COMPARE_SPEC_INVALID', async () => {
  const { status, json } = await send(app(EDITOR), 'POST', '/', {
    name: 'r', blueprint_id: 'bp-1', compare_spec: { localPath: '$.a' },
  });
  assert.strictEqual(status, 400);
  assert.strictEqual(json.error.code, 'FLOW_COMPARE_SPEC_INVALID');
});

test('PUT with a malformed compare_spec (extra key) → 400 FLOW_COMPARE_SPEC_INVALID', async () => {
  const { status, json } = await send(app(EDITOR), 'PUT', `/${RECIPE_ID}`, {
    compare_spec: { localPath: '$.a', remotePath: '$.b', extra: 'x' },
  });
  assert.strictEqual(status, 400);
  assert.strictEqual(json.error.code, 'FLOW_COMPARE_SPEC_INVALID');
});

test('POST with a valid compare_spec → 200, reaches CRUD', async () => {
  const { status, json } = await send(app(EDITOR), 'POST', '/', {
    name: 'r', blueprint_id: 'bp-1', compare_spec: { localPath: '$.a', remotePath: '$.b' },
  });
  assert.strictEqual(status, 200);
  assert.strictEqual(json.reached, 'crud');
});

test('POST with a malformed link_extract (array) → 400 FLOW_LINK_EXTRACT_INVALID', async () => {
  const { status, json } = await send(app(EDITOR), 'POST', '/', {
    name: 'r', blueprint_id: 'bp-1', link_extract: ['nope'],
  });
  assert.strictEqual(status, 400);
  assert.strictEqual(json.error.code, 'FLOW_LINK_EXTRACT_INVALID');
});

test('PUT with a malformed link_extract (unrecognised kind) → 400 FLOW_LINK_EXTRACT_INVALID', async () => {
  const { status, json } = await send(app(EDITOR), 'PUT', `/${RECIPE_ID}`, {
    link_extract: { kind: 'bogus', path: '$.id' },
  });
  assert.strictEqual(status, 400);
  assert.strictEqual(json.error.code, 'FLOW_LINK_EXTRACT_INVALID');
});

test('PUT with a legacy untagged link_extract ({ path }) → 200, reaches CRUD', async () => {
  const { status, json } = await send(app(EDITOR), 'PUT', `/${RECIPE_ID}`, {
    link_extract: { path: '$.id' },
  });
  assert.strictEqual(status, 200);
  assert.strictEqual(json.reached, 'crud');
});

test('PUT with a bare-string link_extract → 200, reaches CRUD', async () => {
  const { status, json } = await send(app(EDITOR), 'PUT', `/${RECIPE_ID}`, {
    link_extract: '$.id',
  });
  assert.strictEqual(status, 200);
  assert.strictEqual(json.reached, 'crud');
});

test('POST with a malformed external_id_extract (pathless object) → 400 FLOW_EXTERNAL_ID_EXTRACT_INVALID', async () => {
  const { status, json } = await send(app(EDITOR), 'POST', '/', {
    name: 'r', blueprint_id: 'bp-1', external_id_extract: { nope: 1 },
  });
  assert.strictEqual(status, 400);
  assert.strictEqual(json.error.code, 'FLOW_EXTERNAL_ID_EXTRACT_INVALID');
});

test('PUT with a malformed external_id_extract (unrecognised kind) → 400 FLOW_EXTERNAL_ID_EXTRACT_INVALID', async () => {
  const { status, json } = await send(app(EDITOR), 'PUT', `/${RECIPE_ID}`, {
    external_id_extract: { kind: 'bogus', path: '$.id' },
  });
  assert.strictEqual(status, 400);
  assert.strictEqual(json.error.code, 'FLOW_EXTERNAL_ID_EXTRACT_INVALID');
});

test('PUT with a bare-string external_id_extract → 200, reaches CRUD', async () => {
  const { status, json } = await send(app(EDITOR), 'PUT', `/${RECIPE_ID}`, {
    external_id_extract: '$.id',
  });
  assert.strictEqual(status, 200);
  assert.strictEqual(json.reached, 'crud');
});

test('PUT naming neither field reaches CRUD unconditionally', async () => {
  const { status, json } = await send(app(EDITOR), 'PUT', `/${RECIPE_ID}`, { name: 'renamed' });
  assert.strictEqual(status, 200);
  assert.strictEqual(json.reached, 'crud');
});
