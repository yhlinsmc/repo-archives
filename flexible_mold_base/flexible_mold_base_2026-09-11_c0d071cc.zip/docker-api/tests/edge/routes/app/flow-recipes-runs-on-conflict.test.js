// docker-api/tests/edge/routes/app/flow-recipes-runs-on-conflict.test.js
//
// Amendment A2, reverse direction: narrowing a recipe's own runs_on away
// from 'both' to X is rejected only while a step's step_runs_on DIVERGES
// from X (a different single mode); a step already 'both' or already equal
// to X does not block the narrow. Stubs the CRUD factory and the named
// sub-routes' own dependencies are untouched — /serialize, /approve,
// /import register on the router before the gate under test, same ordering
// the live router uses.
const { test, beforeEach } = require('node:test');
const assert = require('node:assert');
const express = require('express');

let queryQueue = [];

require.cache[require.resolve('../../../../src/edge/db')] = {
  exports: {
    pool: {
      ro: {
        query: async () => {
          const v = queryQueue.length > 0 ? queryQueue.shift() : [];
          if (v instanceof Error) throw v;
          return v;
        },
      },
      rw: { getConnection: async () => ({ query: async () => [], release: () => {} }) },
    },
    t: (x) => x,
  },
};
require.cache[require.resolve('../../../../src/edge/routes/app/schema')] = {
  exports: { createCrudRoutes: () => (req, res) => res.json({ ok: true, reached: 'crud' }) },
};
const router = require('../../../../src/edge/routes/app/flow-recipes');

function app(user) {
  const a = express(); a.use(express.json());
  a.use((req, _res, next) => { req.user = user; next(); });
  a.use('/', router);
  return a;
}
async function send(a, method, path, body) {
  const server = a.listen(0);
  try {
    const port = server.address().port;
    const res = await fetch(`http://127.0.0.1:${port}${path}`, {
      method, headers: { 'content-type': 'application/json' }, body: JSON.stringify(body || {}),
    });
    const json = await res.json().catch(() => ({}));
    return { status: res.status, json };
  } finally {
    server.close();
  }
}

const ADMIN = { id: 'admin1', role: 'admin' };
const RECIPE_ID = 'aaaa0000-0000-0000-0000-000000000001';

// The mock queue is module-level; reset it before every test so a case that
// declares no rows starts empty rather than inheriting a prior test's leftovers.
beforeEach(() => { queryQueue = []; });

test('PUT recipe runs_on=create while a step diverges (step_runs_on=update) → 400 FLOW_STEP_MODE_CONFLICT naming it', async () => {
  queryQueue = [[
    { id: 's1', name: 'Push', step_runs_on: 'update' },
    { id: 's2', name: 'Notify', step_runs_on: 'both' },
  ]];
  const { status, json } = await send(app(ADMIN), 'PUT', `/${RECIPE_ID}`, { runs_on: 'create' });
  assert.strictEqual(status, 400);
  assert.strictEqual(json.error.code, 'FLOW_STEP_MODE_CONFLICT');
  assert.ok(json.error.message.includes('Push'), 'the offending step name must be named in the message');
});

// H2: a stored step carrying an unrecognised step_runs_on (legacy/corrupt)
// makes the primitive return FLOW_STEP_TRIGGER_INVALID, not MODE_CONFLICT — the
// narrow must still be blocked (any non-null verdict is offending), the message
// naming the offending code per step.
test('PUT recipe runs_on=create while a stored step has an unrecognised step_runs_on → 400, code named per step', async () => {
  queryQueue = [[
    { id: 's1', name: 'Legacy', step_runs_on: 'bogus' },
  ]];
  const { status, json } = await send(app(ADMIN), 'PUT', `/${RECIPE_ID}`, { runs_on: 'create' });
  assert.strictEqual(status, 400);
  assert.ok(json.error.message.includes('Legacy'), 'the offending step name must be named');
  assert.ok(json.error.message.includes('FLOW_STEP_TRIGGER_INVALID'), 'the per-step code must be named');
});

// Commander ruling (2026-09-10): a step whose step_runs_on already MATCHES
// the recipe's new target mode is not a conflict — it is exactly the plan's
// own worked example ("PUT a step with runs_on='create' [matching recipe] ->
// 200"). Only a step pinned to the OTHER single mode blocks the narrow.
test('PUT recipe runs_on=create while a step already matches (step_runs_on=create) → 200, reaches CRUD', async () => {
  queryQueue = [[
    { id: 's1', name: 'Push', step_runs_on: 'create' },
    { id: 's2', name: 'Notify', step_runs_on: 'both' },
  ]];
  const { json } = await send(app(ADMIN), 'PUT', `/${RECIPE_ID}`, { runs_on: 'create' });
  assert.strictEqual(json.reached, 'crud');
});

test('the SAME narrow succeeds once every step is reset to both (no conflict left)', async () => {
  queryQueue = [[
    { id: 's1', name: 'Push', step_runs_on: 'both' },
    { id: 's2', name: 'Notify', step_runs_on: 'both' },
  ]];
  const { json } = await send(app(ADMIN), 'PUT', `/${RECIPE_ID}`, { runs_on: 'create' });
  assert.strictEqual(json.reached, 'crud');
});

test('PUT runs_on=both never probes steps and always reaches CRUD', async () => {
  const { json } = await send(app(ADMIN), 'PUT', `/${RECIPE_ID}`, { runs_on: 'both' });
  assert.strictEqual(json.reached, 'crud');
  assert.strictEqual(queryQueue.length, 0);
});

test('PUT with no runs_on key at all reaches CRUD without any conflict probe', async () => {
  const { json } = await send(app(ADMIN), 'PUT', `/${RECIPE_ID}`, { name: 'renamed' });
  assert.strictEqual(json.reached, 'crud');
  assert.strictEqual(queryQueue.length, 0);
});

test('POST (create) never probes steps — a brand-new recipe has none yet', async () => {
  const { json } = await send(app(ADMIN), 'POST', '/', { runs_on: 'create', name: 'New', blueprint_id: 'bp1' });
  assert.strictEqual(json.reached, 'crud');
  assert.strictEqual(queryQueue.length, 0);
});

test('a no-ALTER steps table missing step_runs_on (errno 1054) degrades to no-conflict', async () => {
  queryQueue = [Object.assign(new Error("Unknown column 'step_runs_on'"), { errno: 1054, code: 'ER_BAD_FIELD_ERROR' })];
  const { json } = await send(app(ADMIN), 'PUT', `/${RECIPE_ID}`, { runs_on: 'create' });
  assert.strictEqual(json.reached, 'crud');
});

test('an absent steps table (errno 1146) degrades to no-conflict', async () => {
  queryQueue = [Object.assign(new Error('no such table'), { errno: 1146 })];
  const { json } = await send(app(ADMIN), 'PUT', `/${RECIPE_ID}`, { runs_on: 'create' });
  assert.strictEqual(json.reached, 'crud');
});
