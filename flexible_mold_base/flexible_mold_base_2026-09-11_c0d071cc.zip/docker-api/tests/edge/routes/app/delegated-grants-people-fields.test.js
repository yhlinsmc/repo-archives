'use strict';

/**
 * delegated-grants-people-fields.test.js — GET /people carries kc_username
 * and role as distinct response fields (spec §8.2), so the shared UserRow
 * can render the same identity shape everywhere it is used. kc_username is
 * domain-stripped through the same stripEmailDomain helper display_name
 * already goes through, so the never-return-email rule holds on the new
 * field too.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../../../src/edge/db');

let peopleRows;

function makeConn() {
  return {
    async query(sql, params = []) {
      if (/information_schema\.TABLES/i.test(sql)) return [{ 1: 1 }];
      if (/FROM `fmb_users`/.test(sql)) return peopleRows;
      return [];
    },
    release() {},
  };
}

const poolFacade = { async getConnection() { return makeConn(); } };

require.cache[dbKey] = {
  id: dbKey,
  filename: dbKey,
  loaded: true,
  exports: {
    pool: { ro: poolFacade, rw: poolFacade },
    t: (n) => `fmb_${n}`,
    getDynamicPool: async () => ({ ro: poolFacade, rw: poolFacade }),
  },
};

const router = require('../../../../src/edge/routes/app/delegated-grants');
const { _resetGrantsTableCache } = require('../../../../src/edge/lib/delegated-grants');

const OWNER = { id: '11111111-1111-1111-1111-111111111111', role: 'editor' };

let currentUser;
let server;
let baseUrl;

before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { if (currentUser) req.user = currentUser; next(); });
  app.use('/edge/app/delegated-grants', router);
  server = http.createServer(app);
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});

after(async () => { await new Promise((r) => server.close(r)); });

beforeEach(() => {
  currentUser = OWNER;
  _resetGrantsTableCache();
});

async function call(method, path) {
  const res = await fetch(`${baseUrl}/edge/app/delegated-grants${path}`, { method });
  return { status: res.status, json: await res.json() };
}

describe('GET /people — kc_username + role', () => {
  it('returns kc_username (domain-stripped) and role as distinct fields', async () => {
    peopleRows = [{
      id: 'ann-1', display_name: 'Ann Owner', kc_username: 'ann@corp.local', role: 'editor',
    }];
    const { status, json } = await call('GET', '/people');
    assert.equal(status, 200);
    assert.deepEqual(json.data.people, [{
      id: 'ann-1', display_name: 'Ann Owner', kc_username: 'ann', role: 'editor',
    }]);
  });

  it('coalesces a missing role to an empty string rather than dropping the field', async () => {
    peopleRows = [{ id: 'p-1', display_name: 'P One', kc_username: 'p1', role: null }];
    const { json } = await call('GET', '/people');
    assert.equal(json.data.people[0].role, '');
  });

  it('coalesces a missing kc_username to an empty string rather than dropping the field', async () => {
    peopleRows = [{ id: 'p-1', display_name: 'P One', kc_username: null, role: 'user' }];
    const { json } = await call('GET', '/people');
    assert.equal(json.data.people[0].kc_username, '');
  });

  it('never puts an address on the wire through the new kc_username field', async () => {
    peopleRows = [{
      id: 'p-1', display_name: 'P One', kc_username: 'p.one@corp.example', role: 'admin',
    }];
    const { json } = await call('GET', '/people');
    assert.equal(json.data.people[0].kc_username, 'p.one');
    assert.ok(!JSON.stringify(json).includes('@'), 'an address reached the picker');
  });
});
