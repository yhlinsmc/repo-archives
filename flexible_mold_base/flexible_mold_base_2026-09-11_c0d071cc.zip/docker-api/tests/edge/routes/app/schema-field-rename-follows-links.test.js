/**
 * schema-field-rename-follows-links.test.js — POST /rename/:fieldId must move
 * the answers of every template governed by the renamed field's blueprint,
 * including a template that reaches it only through a LINK. GET
 * /impact/:fieldId — the preview the rename is issued after reading — must
 * count that same template, or an operator sees a preview that undercounts
 * what the rename it precedes actually touches.
 *
 * The orphan scanner resolves "which blueprint's fields govern this template's
 * payload" through `effectiveBlueprintIdSql` — a template under a blueprint
 * that LINKS to another borrows that blueprint's field list. The rename
 * statement used to scope itself by the raw `blueprint_id` column instead, so
 * a template reached only through a link never had its answer moved: the key
 * stayed old under the rename, then the very next orphan scan reported it as a
 * residual nobody had touched.
 *
 * `effectiveBlueprintIdSql(hn, ut) = ?` fixed the semantics but is not
 * sargable — MariaDB cannot use `idx_user_templates_blueprint` against an
 * expression, so it forced a full scan of `user_templates` (the largest table
 * this rename touches) and held the UPDATE's row locks for the length of that
 * scan. Both statements now resolve `resolveEffectiveBlueprintIds` (a small,
 * indexed lookup against `hierarchy_nodes`) first and scope by
 * `WHERE blueprint_id IN (...)`, an equivalent but sargable predicate — pinned
 * below by asserting the shape AND that both call sites resolve the identical
 * id set, not merely that each independently produces the right row count.
 *
 * The resolver itself has two callers with two different locking needs,
 * pinned below by statement ORDER, not merely by shape: the rename resolves
 * INSIDE its transaction with `FOR UPDATE` (closing the TOCTOU a concurrent
 * unlink could otherwise slip through the window between "read scope" and
 * "write every row in scope"), and the impact preview resolves as a plain
 * read outside any transaction (a preview is not a commitment, so it is not
 * worth serializing every concurrent link edit behind).
 *
 * Stub-connection test, so nothing here is executed by a real engine — the
 * mock resolves each statement's matched templates from its OWN bound `IN
 * (...)` parameters, which is what makes these assertions go red against the
 * pre-fix statement shape instead of merely restating the fix.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const { makeStubReqLog } = require('../../../helpers/stub-req-log');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../../../src/edge/db');

const DATABASE_PROBE = /^SELECT DATABASE\(\)/i;
const COLUMN_PROBE = /SELECT COLUMN_NAME FROM information_schema\.COLUMNS/i;
const FIELD_LOOKUP = /^SELECT blueprint_id, field_key FROM `fmb_blueprint_fields`/i;
const DUPLICATE_LOOKUP = /^SELECT id FROM `fmb_blueprint_fields`[\s\S]*LIMIT 1/i;
const LINKERS_LOOKUP = /^SELECT id FROM `fmb_hierarchy_nodes`\s+WHERE id = \? OR linked_blueprint_id = \?( FOR UPDATE)?/i;
const TEMPLATE_UPDATE = /^UPDATE `fmb_user_templates`/i;
const TEMPLATE_IMPACT_SELECT = /^SELECT id, name FROM `fmb_user_templates`/i;
const IN_LIST_RE = /WHERE blueprint_id IN \(([^)]*)\)/;

const BASE_TEMPLATE_COLS = [
  'id', 'name', 'blueprint_id', 'payload', 'generated_outputs', 'created_at', 'updated_at',
];

// The blueprint the renamed field belongs to, and one that borrows its schema
// through `linked_blueprint_id` — the shape `resolveEffectiveBlueprintIds`
// exists to resolve.
const BP_A = 'bp-a';
const BP_B_LINKED_TO_A = 'bp-b';

// Two synthetic template rows the rename UPDATE and the impact SELECT both
// have to choose between: one sits directly under the renamed field's own
// blueprint, the other reaches it only through BP_B's link.
const TEMPLATES = [
  { id: 'tpl-direct', name: 'direct answer', blueprintId: BP_A },
  { id: 'tpl-linked', name: 'linked answer', blueprintId: BP_B_LINKED_TO_A },
];
// hierarchy_nodes rows whose linked_blueprint_id points AT each key — what
// the real LINKERS_LOOKUP query reads, and the reverse of "which blueprint is
// BP_B linked to".
const LINKERS_OF = { [BP_A]: [BP_B_LINKED_TO_A] };

/**
 * The ids bound into a statement's `WHERE blueprint_id IN (...)`, read from
 * the statement's OWN SQL and params rather than assumed — `offset` is where
 * those ids start in the params array (3 for the rename UPDATE, which binds
 * three JSON-path params before them; 0 for the impact SELECT, which binds
 * them first).
 */
function idsFromInClause(sql, params, offset) {
  const m = sql.match(IN_LIST_RE);
  if (!m) return [];
  const count = m[1].split(',').filter((s) => s.trim()).length;
  return params.slice(offset, offset + count);
}

function matchingTemplates(ids) {
  return TEMPLATES.filter((tpl) => ids.includes(tpl.blueprintId));
}

let targetColumns;
let conn;

function makeConn() {
  // ONE ordered log for statements AND transaction verbs — a separate
  // queries[]/tx[] pair cannot answer "did the locking resolve happen INSIDE
  // the transaction, before the write", which is exactly the property the
  // TOCTOU fix depends on.
  const ops = [];
  return {
    ops,
    get queries() { return ops.filter((o) => o.kind === 'query'); },
    get tx() { return ops.filter((o) => o.kind === 'tx').map((o) => o.verb); },
    async query(sql, params) {
      if (DATABASE_PROBE.test(sql)) return [{ db: 'db_default' }];
      if (COLUMN_PROBE.test(sql)) return targetColumns.map((c) => ({ COLUMN_NAME: c }));
      ops.push({ kind: 'query', sql, params });
      if (FIELD_LOOKUP.test(sql)) return [{ blueprint_id: BP_A, field_key: 'old_key' }];
      if (DUPLICATE_LOOKUP.test(sql)) return [];
      if (LINKERS_LOOKUP.test(sql)) return (LINKERS_OF[params[0]] || []).map((id) => ({ id }));
      if (TEMPLATE_UPDATE.test(sql)) {
        return { affectedRows: matchingTemplates(idsFromInClause(sql, params, 3)).length };
      }
      if (TEMPLATE_IMPACT_SELECT.test(sql)) {
        return matchingTemplates(idsFromInClause(sql, params, 0)).map((tpl) => ({ id: tpl.id, name: tpl.name }));
      }
      throw new Error(`Unmatched query: ${sql.slice(0, 160)}`);
    },
    release() { /* noop */ },
    async beginTransaction() { ops.push({ kind: 'tx', verb: 'begin' }); },
    async commit() { ops.push({ kind: 'tx', verb: 'commit' }); },
    async rollback() { ops.push({ kind: 'tx', verb: 'rollback' }); },
  };
}

const poolSpy = {
  rw: { async getConnection() { return conn; } },
  ro: { async getConnection() { return conn; } },
};

require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: {
    pool: poolSpy,
    t: (name) => `fmb_${name}`,
    getDynamicPool: async () => poolSpy,
  },
};

const router = require('../../../../src/edge/routes/app/schema');
const { __clearColumnSetCache } = router.__test__;

let server;
let port;

before(async () => {
  const app = express();
  app.use((req, _res, next) => { req.log = makeStubReqLog(); next(); }); // TEST-ONLY: production always sets req.log via createRequestId (request-id.js) before any router; this bare app has no such middleware, so a route's req.log.<level>() call would otherwise throw against undefined.
  app.use(express.json({ limit: '10mb' }));
  app.use((req, _res, next) => { req.user = { id: 'admin-1', role: 'admin' }; next(); });
  app.use('/edge/app/schema', router);
  await new Promise((resolve) => {
    server = app.listen(0, '127.0.0.1', () => { port = server.address().port; resolve(); });
  });
});

after(async () => {
  await new Promise((resolve) => server.close(resolve));
  delete require.cache[dbKey];
});

beforeEach(() => {
  // No metadata columns present: this test is about the payload site's
  // blueprint scope, not the metadata cascade another test file already covers.
  targetColumns = BASE_TEMPLATE_COLS;
  conn = makeConn();
  __clearColumnSetCache();
});

function postJson(path_, body) {
  return new Promise((resolve, reject) => {
    const payload = JSON.stringify(body);
    const req = http.request(
      {
        host: '127.0.0.1', port, path: path_, method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) },
      },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          const raw = Buffer.concat(chunks).toString('utf-8');
          let json = null;
          try { json = JSON.parse(raw); } catch { /* noop */ }
          resolve({ status: res.statusCode, raw, json });
        });
      },
    );
    req.on('error', reject);
    req.write(payload);
    req.end();
  });
}

function getJson(path_) {
  return new Promise((resolve, reject) => {
    const req = http.request(
      { host: '127.0.0.1', port, path: path_, method: 'GET' },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          const raw = Buffer.concat(chunks).toString('utf-8');
          let json = null;
          try { json = JSON.parse(raw); } catch { /* noop */ }
          resolve({ status: res.statusCode, raw, json });
        });
      },
    );
    req.on('error', reject);
    req.end();
  });
}

const rename = () => postJson('/edge/app/schema/rename/fld-1', { old_key: 'old_key', new_key: 'new_key' });
const impact = () => getJson('/edge/app/schema/impact/fld-1');

describe('field rename — follows a blueprint link, the way the orphan scanner does', () => {
  it('moves the answer under a template that reaches the field only through a link', async () => {
    const res = await rename();
    assert.equal(res.status, 200, res.raw);
    // The row count a rename that stopped at the raw `blueprint_id = ?` column
    // would report is 1 (tpl-direct only) — this must be 2, or the linked
    // template's answer was left behind under the old key.
    assert.equal(
      res.json.data.migrated_count, 2,
      'the rename did not reach the template that reaches this field only through a blueprint link',
    );
  });

  it('scopes the statement with a sargable IN-list resolved from hierarchy_nodes, covering both blueprints', () => {
    // Guards against a fix that widens the scope some OTHER way (a fresh
    // non-sargable expression, or an IN-list that dropped the link) and
    // quietly drifts from the impact preview or the orphan scanner again.
    return rename().then(() => {
      const update = conn.queries.find((q) => TEMPLATE_UPDATE.test(q.sql));
      assert.ok(update, 'no UPDATE was issued against user_templates');
      assert.match(
        update.sql, /WHERE blueprint_id IN \(\?(?:, ?\?)*\)/,
        'the WHERE clause is not a sargable IN-list — idx_user_templates_blueprint cannot constrain it',
      );
      assert.deepEqual(
        [...idsFromInClause(update.sql, update.params, 3)].sort(),
        [BP_A, BP_B_LINKED_TO_A].sort(),
        'the IN-list does not name both the field\'s own blueprint and the one linking to it',
      );
    });
  });

  it('resolves the scope with a LOCKING (FOR UPDATE) read, inside the transaction, before the write', () => {
    return rename().then((res) => {
      assert.equal(res.status, 200, res.raw);
      const begin = conn.ops.findIndex((o) => o.kind === 'tx' && o.verb === 'begin');
      const commit = conn.ops.findIndex((o) => o.kind === 'tx' && o.verb === 'commit');
      const resolve = conn.ops.findIndex((o) => o.kind === 'query' && LINKERS_LOOKUP.test(o.sql));
      const firstUpdate = conn.ops.findIndex((o) => o.kind === 'query' && TEMPLATE_UPDATE.test(o.sql));
      assert.ok(begin >= 0 && commit >= 0, 'the rename did not run inside a transaction at all');
      assert.ok(
        resolve > begin && resolve < commit,
        'the effective-blueprint resolve happens outside the transaction — the TOCTOU window is open again',
      );
      assert.ok(resolve < firstUpdate, 'the scope is resolved after the write it is supposed to gate');
      assert.match(
        conn.ops[resolve].sql, / FOR UPDATE\s*$/,
        'the rename\'s resolve is not a locking read — a concurrent unlink can race it',
      );
      // Both params are the field's own blueprint: `id = ?` locks that
      // blueprint's own row, `linked_blueprint_id = ?` locks every row
      // currently linking to it — the two predicates the TOCTOU argument
      // depends on both actually running, not just one of them.
      assert.deepEqual(conn.ops[resolve].params, [BP_A, BP_A]);
    });
  });
});

describe('field impact preview — follows a blueprint link, the way the rename it precedes does', () => {
  it('counts a template that reaches the field only through a link', async () => {
    const res = await impact();
    assert.equal(res.status, 200, res.raw);
    // The row count a preview that stopped at the raw `blueprint_id = ?` column
    // would report is 1 (tpl-direct only) — this must be 2, matching what the
    // rename above actually moves, or the operator sees an undercount before
    // choosing to rename.
    assert.equal(
      res.json.data.template_count, 2,
      'the preview did not count the template that reaches this field only through a blueprint link',
    );
    assert.deepEqual(
      [...res.json.data.template_names].sort(),
      ['direct answer', 'linked answer'],
      'the preview names a different set of templates than it counted',
    );
  });

  it('scopes the SELECT with the same IN-list resolution the rename UPDATE uses', () => {
    return impact().then((res) => {
      assert.equal(res.status, 200, res.raw);
      const select = conn.queries.find((q) => TEMPLATE_IMPACT_SELECT.test(q.sql));
      assert.ok(select, 'no SELECT was issued against user_templates');
      assert.match(
        select.sql, /WHERE blueprint_id IN \(\?(?:, ?\?)*\)/,
        'the WHERE clause is not a sargable IN-list — idx_user_templates_blueprint cannot constrain it',
      );
      assert.deepEqual(
        [...idsFromInClause(select.sql, select.params, 0)].sort(),
        [BP_A, BP_B_LINKED_TO_A].sort(),
        'the preview\'s IN-list disagrees with the rename UPDATE\'s — the two no longer answer the identical scope question',
      );
    });
  });

  it('resolves the scope with a PLAIN (non-locking) read, outside any transaction', () => {
    // Deliberately the opposite of the rename's assertion above: a preview an
    // operator reads before deciding whether to rename is not a commitment,
    // so it must not hold a lock across an HTTP response — that would
    // serialize every concurrent link edit behind every open preview tab for
    // no correctness this endpoint needs (see resolveEffectiveBlueprintIds'
    // own comment on the `forUpdate: false` branch).
    return impact().then((res) => {
      assert.equal(res.status, 200, res.raw);
      assert.deepEqual(conn.tx, [], 'the preview opened a transaction — it is supposed to be a plain read');
      const resolve = conn.queries.find((q) => LINKERS_LOOKUP.test(q.sql));
      assert.ok(resolve, 'no effective-blueprint resolve was issued');
      assert.doesNotMatch(
        resolve.sql, / FOR UPDATE\s*$/,
        'the preview\'s resolve takes a lock — it holds row locks across a read nothing downstream depends on',
      );
    });
  });
});
