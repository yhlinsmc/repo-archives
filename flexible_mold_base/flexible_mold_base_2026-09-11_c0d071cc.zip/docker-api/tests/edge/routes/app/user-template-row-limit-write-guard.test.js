/**
 * user-template-row-limit-write-guard.test.js — the write boundary for
 * table-type fields inside a user_templates payload.
 *
 * A table field's rows are assembled in the browser and, until this guard,
 * bounded only by the frontend's own cap — a hand-crafted request could carry
 * any number of rows. This is the server-side half of TABLE_FIELD_MAX_ROWS: a
 * pure classifier tested standalone (no DB), then the same classifier wired
 * into the real router against a stubbed connection, asserting BOTH the
 * refusal AND the absence of a write.
 *
 * THE DB STUB MUST INSTALL BEFORE ANYTHING BELOW REQUIRES `../db`, INCLUDING
 * TRANSITIVELY. `user-template-row-limits.js` destructures `t` from `../db` at
 * module load, once; that binding never changes once the module is cached, so
 * requiring it (even for the pure classifier alone) before the stub is in
 * `require.cache` pins it to the real, unconfigured pool for the rest of this
 * file's run — a `t()` call anywhere in this file then throws
 * POOL_NOT_CONFIGURED, not the SQL question being asked.
 *
 * WHY GUARD READS ARE COUNTED BY QUERY, NOT BY POOL CALL. The guard reads
 * through the SAME `pool.rw` the actual write uses (a replica the RO pool
 * could serve stale is not an acceptable source for a decision that admits
 * or refuses the write — see the doc-block on `assertUserTemplateRowLimits`).
 * That means `pool.rw.getConnection()` is no longer a clean proxy for "did
 * the guard open a connection": the write path calls it too, on every
 * accepted request. `guardQueryCalls` instead counts the guard's own two
 * distinguishing queries (the blueprint_fields lookup and the existing-row
 * lookup) directly, which is what actually varies between an ordinary write
 * and one the R-P3 gate had to inspect further.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

// Pure — no `../db` dependency — so it is safe to require before the stub
// below installs.
const {
  USER_TEMPLATE_METADATA_COLUMN_NAMES,
} = require('../../../../src/edge/lib/user-template-metadata');

const TEMPLATE_COLS = [
  'id', 'name', 'owner_id', 'blueprint_id', 'variant_id', 'payload', 'generated_outputs',
  'is_draft', 'created_at', 'updated_at', ...USER_TEMPLATE_METADATA_COLUMN_NAMES,
];

let conn;
let blueprintFieldsRows;
let storedRow;
// The existing row's blueprint_id an update's fallback lookup resolves to.
// `undefined` (the fixture's default) uses the fixed UUID every existing test
// relies on; a test can set it to `null` to model a row that itself carries
// no blueprint (the column is nullable).
let existingBlueprintId;
// The existing row's `payload` column, as the R-P2 growth-only comparison
// reads it — `undefined` (the fixture's default) models a row with no
// recorded payload (every count treated as growth, the pre-R-P2 behaviour).
let existingPayload;
// Counts the row-limit validator's own two distinguishing queries (the
// blueprint_fields lookup and the existing-row lookup) — see the doc-block
// above on why this, not a pool-level connection count, is what pins R-P3's
// no-read-when-nothing-is-over-the-cap gate now that the guard shares
// `pool.rw` with the write itself.
let guardQueryCalls;

const DATABASE_PROBE = /^SELECT DATABASE\(\)/i;
const COLUMN_PROBE = /SELECT COLUMN_NAME FROM information_schema\.COLUMNS/i;
const SELECT_ROW = /^SELECT \* FROM `fmb_user_templates`/i;
const OWNER_NAMES = /FROM `fmb_users`/i;
const BLUEPRINT_FIELDS_PROBE = /FROM `fmb_blueprint_fields` WHERE blueprint_id = \? AND field_type = \?/i;
const BLUEPRINT_ID_LOOKUP_PROBE = /^SELECT blueprint_id, payload FROM `fmb_user_templates` WHERE id = \?$/i;

function makeConn() {
  const queries = [];
  return {
    queries,
    async query(sql, params) {
      if (DATABASE_PROBE.test(sql)) return [{ db: 'db_default' }];
      if (COLUMN_PROBE.test(sql)) return TEMPLATE_COLS.map((c) => ({ COLUMN_NAME: c }));
      if (BLUEPRINT_FIELDS_PROBE.test(sql)) {
        guardQueryCalls += 1;
        return blueprintFieldsRows;
      }
      if (BLUEPRINT_ID_LOOKUP_PROBE.test(sql)) {
        guardQueryCalls += 1;
        const row = { blueprint_id: existingBlueprintId !== undefined ? existingBlueprintId : 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26' };
        if (existingPayload !== undefined) row.payload = existingPayload;
        return [row];
      }
      queries.push({ sql, params });
      if (OWNER_NAMES.test(sql)) return [];
      if (SELECT_ROW.test(sql)) return [{ id: '3cec1b55-8cd6-4dd2-8026-4cfa1fea1029', name: 'Job 1', ...storedRow }];
      {
        const m = sql.match(/^SELECT id FROM `([^`]+)` WHERE id = \?$/);
        if (m) return params[0] == null ? [] : [{ id: params[0] }];
      }
      if (/^(INSERT|UPDATE)/i.test(sql)) return { affectedRows: 1 };
      throw new Error(`Unmatched query: ${sql.slice(0, 160)}`);
    },
    release() { /* noop */ },
    async beginTransaction() {},
    async commit() {},
    async rollback() {},
  };
}

const poolSpy = {
  rw: { async getConnection() { return conn; } },
  // The row-limit guard no longer reads through RO (see the migration
  // doc-block above); a stray call proves a regression back to a
  // replica-lagged read, not a legitimate path this suite exercises.
  ro: { async getConnection() { throw new Error('unexpected pool.ro.getConnection() — the row-limit guard reads pool.rw'); } },
};

const dbKey = require.resolve('../../../../src/edge/db');
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: {
    pool: poolSpy,
    t: (name) => `fmb_${name}`,
    getDynamicPool: async () => poolSpy,
  },
};

// Safe to require now — the stub is already in `require.cache` under the
// same absolute path every one of these (and their transitive `../db`) will
// resolve to.
const {
  tableFieldOverLimit, anyArrayValueOverLimit, anyValueOverLimit,
} = require('../../../../src/edge/lib/user-template-row-limits');
const { TABLE_FIELD_MAX_ROWS } = require('../../../../src/shared/table-field-limits');

const tableFields = [{ field_key: 'ports', field_label: 'Ports' }];

describe('tableFieldOverLimit', () => {
  it('flags a table field whose row array exceeds the cap, naming its label + count', () => {
    const payload = { ports: JSON.stringify(Array.from({ length: TABLE_FIELD_MAX_ROWS + 1 }, () => ({ p: '1' }))) };
    assert.deepEqual(
      tableFieldOverLimit(payload, tableFields, TABLE_FIELD_MAX_ROWS),
      { label: 'Ports', count: TABLE_FIELD_MAX_ROWS + 1 },
    );
  });

  it('passes a table field exactly at the cap', () => {
    const payload = { ports: JSON.stringify(Array.from({ length: TABLE_FIELD_MAX_ROWS }, () => ({ p: '1' }))) };
    assert.equal(tableFieldOverLimit(payload, tableFields, TABLE_FIELD_MAX_ROWS), null);
  });

  it('ignores a non-table field with a long array (not this validator\'s concern)', () => {
    const payload = { notes: JSON.stringify(Array.from({ length: 999 }, (_, i) => i)) };
    assert.equal(tableFieldOverLimit(payload, tableFields, TABLE_FIELD_MAX_ROWS), null);
  });

  it('ignores a malformed / non-array table value (existing behaviour)', () => {
    assert.equal(tableFieldOverLimit({ ports: 'not json' }, tableFields, TABLE_FIELD_MAX_ROWS), null);
    assert.equal(tableFieldOverLimit({ ports: '{}' }, tableFields, TABLE_FIELD_MAX_ROWS), null);
  });

  // A leading-character pre-scan skips JSON.parse entirely for a string
  // that could never parse to an array — cheap insurance against a
  // hand-crafted request posting a large non-array string just to make
  // this validator do parse work on it.
  it('never parses a long non-array string value, and treats it as out of scope', () => {
    const longString = 'x'.repeat(10_000);
    const originalParse = JSON.parse;
    let parseCalledWithLongString = false;
    JSON.parse = (...args) => {
      if (args[0] === longString) parseCalledWithLongString = true;
      return originalParse(...args);
    };
    try {
      assert.equal(tableFieldOverLimit({ ports: longString }, tableFields, TABLE_FIELD_MAX_ROWS), null);
    } finally {
      JSON.parse = originalParse;
    }
    assert.equal(parseCalledWithLongString, false);
  });

  it('falls back to the field_key when a label is null', () => {
    const payload = { ports: JSON.stringify(Array.from({ length: 501 }, () => ({}))) };
    assert.deepEqual(
      tableFieldOverLimit(payload, [{ field_key: 'ports', field_label: null }], TABLE_FIELD_MAX_ROWS),
      { label: 'ports', count: 501 },
    );
  });

  it('ignores a payload that carries no key for the table field', () => {
    assert.equal(tableFieldOverLimit({}, tableFields, TABLE_FIELD_MAX_ROWS), null);
  });

  // `payload[field_key]` need not be a JSON string — the column is JSON and
  // a caller may post the value already parsed. Counting the string case
  // only let a raw array through unpoliced.
  it('flags a table field whose value is a raw (non-stringified) array', () => {
    const payload = { ports: Array.from({ length: 501 }, () => ({ p: '1' })) };
    assert.deepEqual(
      tableFieldOverLimit(payload, tableFields, TABLE_FIELD_MAX_ROWS),
      { label: 'Ports', count: 501 },
    );
  });

  it('passes a raw array value exactly at the cap', () => {
    const payload = { ports: Array.from({ length: TABLE_FIELD_MAX_ROWS }, () => ({ p: '1' })) };
    assert.equal(tableFieldOverLimit(payload, tableFields, TABLE_FIELD_MAX_ROWS), null);
  });
});

// Without a resolvable blueprint there is no blueprint_fields row to say
// which payload key is a table, so the write path falls back to this —
// every array-shaped value is a candidate.
describe('anyArrayValueOverLimit', () => {
  it('flags the first payload key whose array-shaped value exceeds the cap (string or raw array)', () => {
    const payload = { a: JSON.stringify([1]), b: Array.from({ length: 501 }, () => 1) };
    assert.deepEqual(anyArrayValueOverLimit(payload, TABLE_FIELD_MAX_ROWS), { label: 'b', count: 501 });
  });

  it('passes when every array-shaped value is at or under the cap', () => {
    const payload = { a: Array.from({ length: TABLE_FIELD_MAX_ROWS }, () => 1) };
    assert.equal(anyArrayValueOverLimit(payload, TABLE_FIELD_MAX_ROWS), null);
  });

  it('passes an empty payload', () => {
    assert.equal(anyArrayValueOverLimit({}, TABLE_FIELD_MAX_ROWS), null);
  });

  // M6: the accepted over-reach this fallback carries — a multi-select
  // checkbox column (not a table) whose stored value is a >500-item array
  // reads identically to an over-cap table under this key-blind classifier,
  // so it is refused with a "Table" message it does not deserve. Pinned here
  // as the concrete shape the why-comment above names, not just described.
  it('refuses a non-table (checkbox/multi-select) array over the cap the same way (accepted over-reach)', () => {
    const payload = { dc_refs: Array.from({ length: 501 }, (_, i) => `dc-${i}`) };
    assert.deepEqual(anyArrayValueOverLimit(payload, TABLE_FIELD_MAX_ROWS), { label: 'dc_refs', count: 501 });
  });

  it('growth-only (R-P2): an update resending a stored over-cap value unchanged passes', () => {
    const stored = Array.from({ length: 800 }, (_, i) => i);
    const payload = { anything: stored };
    assert.equal(anyArrayValueOverLimit(payload, TABLE_FIELD_MAX_ROWS, { anything: stored }), null);
  });

  it('growth-only (R-P2): an update growing past the stored count is still refused', () => {
    const stored = Array.from({ length: 800 }, (_, i) => i);
    const payload = { anything: Array.from({ length: 801 }, (_, i) => i) };
    assert.deepEqual(
      anyArrayValueOverLimit(payload, TABLE_FIELD_MAX_ROWS, { anything: stored }),
      { label: 'anything', count: 801 },
    );
  });
});

describe('anyValueOverLimit', () => {
  it('is true when any payload value exceeds the cap', () => {
    const payload = { a: Array.from({ length: 501 }, () => 1) };
    assert.equal(anyValueOverLimit(payload, TABLE_FIELD_MAX_ROWS), true);
  });

  it('is false when every payload value is at or under the cap', () => {
    const payload = { a: Array.from({ length: TABLE_FIELD_MAX_ROWS }, () => 1), b: 'x' };
    assert.equal(anyValueOverLimit(payload, TABLE_FIELD_MAX_ROWS), false);
  });

  it('is false for an empty payload', () => {
    assert.equal(anyValueOverLimit({}, TABLE_FIELD_MAX_ROWS), false);
  });
});

// ─── HTTP-level slice: the real router, a stubbed connection ───

const router = require('../../../../src/edge/routes/app/schema');
const { __clearColumnSetCache } = router.__test__;

let server;
let port;

before(async () => {
  const app = express();
  app.use(express.json({ limit: '10mb' }));
  app.use((req, _res, next) => { req.user = { id: '5b729f1e-5c0b-447c-8144-3210469bc62c', role: 'admin' }; next(); });
  app.use('/edge/app/schema', router);
  await new Promise((resolve) => {
    server = app.listen(0, '127.0.0.1', () => { port = server.address().port; resolve(); });
  });
});

after(async () => {
  await new Promise((resolve) => server.close(resolve));
  delete require.cache[dbKey];
});

beforeEach(() => {
  storedRow = {};
  blueprintFieldsRows = [{ field_key: 'ports', field_label: 'Ports' }];
  existingBlueprintId = undefined;
  existingPayload = undefined;
  guardQueryCalls = 0;
  conn = makeConn();
  __clearColumnSetCache();
});

function send(method, path_, body) {
  return new Promise((resolve, reject) => {
    const payload = body === undefined ? '' : JSON.stringify(body);
    const req = http.request(
      {
        host: '127.0.0.1', port, path: path_, method,
        headers: payload
          ? { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) }
          : {},
      },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          const raw = Buffer.concat(chunks).toString('utf-8');
          let json = null;
          try { json = JSON.parse(raw); } catch { /* noop */ }
          resolve({ status: res.statusCode, raw, json });
        });
      },
    );
    req.on('error', reject);
    req.write(payload);
    req.end();
  });
}

const create = (body) => send('POST', '/edge/app/schema/user_templates', body);
const update = (body) => send('PUT', '/edge/app/schema/user_templates/3cec1b55-8cd6-4dd2-8026-4cfa1fea1029', body);

const writes = () => conn.queries.filter((q) => /^(INSERT|UPDATE)/i.test(q.sql));

describe('user_templates row-limit write guard — refuses', () => {
  it('rejects a 501-row table field with 400 TABLE_ROWS_LIMIT, naming the field label and count', async () => {
    const payload = { ports: JSON.stringify(Array.from({ length: 501 }, () => ({ p: '1' }))) };
    const res = await create({ name: 'T', blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', payload });

    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'TABLE_ROWS_LIMIT');
    assert.match(res.json.error.message, /Table "Ports" has 501 rows; the limit is 500\./);
    assert.deepEqual(writes(), [], 'nothing may be written when a table field is over the cap');
  });

  it('rejects an over-cap table field on update the same way, reading the blueprint from the existing row', async () => {
    const payload = { ports: JSON.stringify(Array.from({ length: 501 }, () => ({ p: '1' }))) };
    const res = await update({ payload });

    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'TABLE_ROWS_LIMIT');
    assert.deepEqual(writes(), []);
  });

  // At the HTTP boundary: a table field posted as a real JSON array (nested
  // under `payload`, not JSON.stringify'd into a string) must be counted the
  // same as the stringified case.
  it('rejects a 501-row table field sent as a raw array, not a stringified one', async () => {
    const payload = { ports: Array.from({ length: 501 }, () => ({ p: '1' })) };
    const res = await create({ name: 'T', blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', payload });

    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'TABLE_ROWS_LIMIT');
    assert.match(res.json.error.message, /Table "Ports" has 501 rows; the limit is 500\./);
    assert.deepEqual(writes(), []);
  });

  // A CREATE with no blueprint_id used to skip the check entirely. Fail
  // closed instead — every array-shaped payload value is a candidate, named
  // by its payload key (no field_label to look up without a blueprint).
  it('fails closed on create when blueprint_id is absent from the body', async () => {
    const payload = { anything: JSON.stringify(Array.from({ length: 501 }, () => ({ x: 1 }))) };
    const res = await create({ name: 'T', payload });

    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'TABLE_ROWS_LIMIT');
    assert.match(res.json.error.message, /Table "anything" has 501 rows; the limit is 500\./);
    assert.deepEqual(writes(), []);
  });

  it('fails closed on create when blueprint_id is explicitly null', async () => {
    const payload = { anything: JSON.stringify(Array.from({ length: 501 }, () => ({ x: 1 }))) };
    const res = await create({ name: 'T', blueprint_id: null, payload });

    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'TABLE_ROWS_LIMIT');
    assert.deepEqual(writes(), []);
  });

  it('fails closed on update when the existing row itself carries a null blueprint_id', async () => {
    existingBlueprintId = null;
    const payload = { anything: JSON.stringify(Array.from({ length: 501 }, () => ({ x: 1 }))) };
    const res = await update({ payload });

    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'TABLE_ROWS_LIMIT');
    assert.deepEqual(writes(), []);
  });
});

describe('user_templates row-limit write guard — accepts', () => {
  it('accepts a table field exactly at the cap', async () => {
    const payload = { ports: JSON.stringify(Array.from({ length: 500 }, () => ({ p: '1' }))) };
    const res = await create({ name: 'T', blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', payload });
    assert.equal(res.status, 200, res.raw);
    assert.ok(writes().some((q) => /^INSERT/i.test(q.sql)));
  });

  it('leaves a non-table field with a long array untouched', async () => {
    const payload = { notes: JSON.stringify(Array.from({ length: 999 }, (_, i) => i)) };
    const res = await create({ name: 'T', blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', payload });
    assert.equal(res.status, 200, res.raw);
  });

  it('accepts a write with no payload at all', async () => {
    const res = await create({ name: 'T', blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26' });
    assert.equal(res.status, 200, res.raw);
  });

  it('accepts a write whose blueprint has no table fields', async () => {
    blueprintFieldsRows = [];
    const payload = { ports: JSON.stringify(Array.from({ length: 999 }, () => ({ p: '1' }))) };
    const res = await create({ name: 'T', blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', payload });
    assert.equal(res.status, 200, res.raw);
  });

  it('accepts a raw-array table field exactly at the cap', async () => {
    const payload = { ports: Array.from({ length: 500 }, () => ({ p: '1' })) };
    const res = await create({ name: 'T', blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', payload });
    assert.equal(res.status, 200, res.raw);
  });

  it('creates fine with no blueprint_id when every payload value is under the cap', async () => {
    const payload = { anything: JSON.stringify([{ x: 1 }]) };
    const res = await create({ name: 'T', payload });
    assert.equal(res.status, 200, res.raw);
  });
});

// I2/R-P3: the validator scans the payload in memory FIRST and only reads
// (through pool.rw — see the migration doc-block above) once something in
// it is over the cap — the overwhelming majority of writes carry nothing
// over 500 rows and must not pay for a DB round trip on every save.
describe('user_templates row-limit write guard — reads only when needed (R-P3)', () => {
  it('never runs a guard query when every payload value is under the cap', async () => {
    const payload = { ports: JSON.stringify(Array.from({ length: 10 }, () => ({ p: '1' }))) };
    const res = await create({ name: 'T', blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', payload });
    assert.equal(res.status, 200, res.raw);
    assert.equal(guardQueryCalls, 0);
  });

  it('never runs a guard query on an update with nothing over the cap', async () => {
    const payload = { ports: JSON.stringify(Array.from({ length: 10 }, () => ({ p: '1' }))) };
    const res = await update({ payload });
    assert.equal(res.status, 200, res.raw);
    assert.equal(guardQueryCalls, 0);
  });

  it('runs the blueprint_fields lookup once a payload value is over the cap, via pool.rw', async () => {
    const payload = { ports: JSON.stringify(Array.from({ length: 501 }, () => ({ p: '1' }))) };
    const res = await create({ name: 'T', blueprint_id: 'a826fe4b-b80b-4cc5-8751-1cbb0b2f7c26', payload });
    assert.equal(res.status, 400, res.raw);
    assert.equal(guardQueryCalls, 1);
  });
});

// R-P2: on UPDATE, a table field is refused only when its count both exceeds
// the cap AND exceeds the count already stored for that field — a table an
// earlier (pre-cap) connector write already grew past 500 must stay
// saveable, resent unchanged or shrunk, without this guard treating its own
// history as a violation. CREATE has no stored row, so every table field is
// still validated in full (covered by the "refuses"/"accepts" blocks above).
describe('user_templates row-limit write guard — update grow-only (R-P2)', () => {
  const rows = (n) => Array.from({ length: n }, () => ({ p: '1' }));

  it('accepts a stored over-cap table field resent unchanged', async () => {
    existingPayload = { ports: JSON.stringify(rows(800)) };
    const payload = { ports: JSON.stringify(rows(800)) };
    const res = await update({ payload });
    assert.equal(res.status, 200, res.raw);
    assert.ok(writes().some((q) => /^UPDATE/i.test(q.sql)));
  });

  it('rejects the same table field grown past its stored count', async () => {
    existingPayload = { ports: JSON.stringify(rows(800)) };
    const payload = { ports: JSON.stringify(rows(801)) };
    const res = await update({ payload });
    assert.equal(res.status, 400, res.raw);
    assert.equal(res.json.error.code, 'TABLE_ROWS_LIMIT');
    assert.deepEqual(writes(), []);
  });

  it('accepts the same table field shrunk below its stored count (still over the cap)', async () => {
    existingPayload = { ports: JSON.stringify(rows(800)) };
    const payload = { ports: JSON.stringify(rows(700)) };
    const res = await update({ payload });
    assert.equal(res.status, 200, res.raw);
  });

  it('a raw-array stored payload is read the same as a stringified one', async () => {
    existingPayload = { ports: rows(800) };
    const payload = { ports: rows(800) };
    const res = await update({ payload });
    assert.equal(res.status, 200, res.raw);
  });
});
