'use strict';

/**
 * delegated-grants-owner-field.test.js — GET / carries the subject's owner
 * identity (Codex r2 R-3-P5), so a caller does not have to re-derive it out
 * of a directory page that can legitimately exclude the real, current owner:
 * `/people` is editor/admin-only (R-3-P2/R-3-P4), and `/assignable`
 * (users.js) excludes a banned account. Both left a screen that resolved
 * ownership from either page stating a wrong "not on this page" placeholder
 * for an owner who was in fact real and current.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../../../src/edge/db');

let subjectOwner;   // owner_id the subject row reports, or undefined for "no such row"
let ownerUserRow;   // the row the users lookup returns for that owner id, or none

function makeConn() {
  return {
    async query(sql, params = []) {
      if (/information_schema\.TABLES/i.test(sql)) return [{ 1: 1 }];
      if (/^SELECT owner_id FROM `fmb_user_templates`/.test(sql)) {
        return subjectOwner === undefined ? [] : [{ owner_id: subjectOwner }];
      }
      // Ordered before the generic `FROM \`fmb_users\`` match below: this is
      // the owner-identity lookup this fix adds, keyed on the id it asks for
      // — unlike the grantee/granter enrichment, which batches by whatever
      // ids the grant rows name.
      if (/^SELECT id, display_name, kc_username, role FROM `fmb_users` WHERE id = \?/.test(sql)) {
        const [id] = params;
        return ownerUserRow && ownerUserRow.id === id ? [ownerUserRow] : [];
      }
      if (/FROM `fmb_delegated_grants`/.test(sql)) return [];
      if (/FROM `fmb_users`/.test(sql)) return [];
      return [];
    },
    release() {},
  };
}

const poolFacade = { async getConnection() { return makeConn(); } };

require.cache[dbKey] = {
  id: dbKey,
  filename: dbKey,
  loaded: true,
  exports: {
    pool: { ro: poolFacade, rw: poolFacade },
    t: (n) => `fmb_${n}`,
    getDynamicPool: async () => ({ ro: poolFacade, rw: poolFacade }),
  },
};

const router = require('../../../../src/edge/routes/app/delegated-grants');
const { _resetGrantsTableCache } = require('../../../../src/edge/lib/delegated-grants');

const ADMIN = { id: '44444444-4444-4444-4444-444444444444', role: 'admin' };
const OWNER_USER = { id: '55555555-5555-5555-5555-555555555555', role: 'user' };
const TEMPLATE = 'bbbbbbbb-0000-0000-0000-00000000000b';

let currentUser;
let server;
let baseUrl;

before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { if (currentUser) req.user = currentUser; next(); });
  app.use('/edge/app/delegated-grants', router);
  server = http.createServer(app);
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});

after(async () => { await new Promise((r) => server.close(r)); });

beforeEach(() => {
  currentUser = ADMIN;
  _resetGrantsTableCache();
});

async function call(path) {
  const res = await fetch(`${baseUrl}/edge/app/delegated-grants${path}`);
  return { status: res.status, json: await res.json() };
}

describe('GET / — owner field (Codex r2 R-3-P5)', () => {
  it('carries a plain-user owner, with role, though that owner would never be a /people row', async () => {
    subjectOwner = OWNER_USER.id;
    ownerUserRow = {
      id: OWNER_USER.id, display_name: 'Uma User', kc_username: 'uma@corp.example', role: 'user',
    };
    const res = await call(`/?scope_type=template&scope_id=${TEMPLATE}`);
    assert.equal(res.status, 200);
    assert.deepEqual(res.json.data.owner, {
      id: OWNER_USER.id, display_name: 'Uma User', kc_username: 'uma', role: 'user',
    });
    assert.equal(res.json.data.owner_id, OWNER_USER.id);
  });

  it('answers null for a subject nobody owns, owner_id null too', async () => {
    subjectOwner = null;
    ownerUserRow = null;
    const res = await call(`/?scope_type=template&scope_id=${TEMPLATE}`);
    assert.equal(res.status, 200);
    assert.equal(res.json.data.owner, null);
    assert.equal(res.json.data.owner_id, null);
  });

  it('answers owner:null but a non-null owner_id when the owner id names no row (a deleted account) — Codex r1 P2', async () => {
    // `owner` alone cannot tell "no owner" from "owner account gone" apart,
    // and a template in the second state still has a delegable owner: the
    // enforcement EXISTS still matches its owner_id column. A caller that
    // read only `owner` would render this subject the same as one nobody
    // ever owned and refuse to offer a grant that the server would accept.
    subjectOwner = OWNER_USER.id;
    ownerUserRow = null;
    const res = await call(`/?scope_type=template&scope_id=${TEMPLATE}`);
    assert.equal(res.status, 200);
    assert.equal(res.json.data.owner, null);
    assert.equal(res.json.data.owner_id, OWNER_USER.id);
  });

  it('never puts an address on the wire through the owner field', async () => {
    subjectOwner = OWNER_USER.id;
    ownerUserRow = {
      id: OWNER_USER.id, display_name: null, kc_username: 'uma@corp.example', role: 'user',
    };
    const res = await call(`/?scope_type=template&scope_id=${TEMPLATE}`);
    assert.equal(res.json.data.owner.display_name, 'uma');
    assert.equal(res.json.data.owner.kc_username, 'uma');
    assert.ok(!JSON.stringify(res.json).includes('@'), 'an address reached the response');
  });
});
