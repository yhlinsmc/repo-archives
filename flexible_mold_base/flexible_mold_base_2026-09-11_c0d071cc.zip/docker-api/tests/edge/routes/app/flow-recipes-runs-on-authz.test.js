// docker-api/tests/edge/routes/app/flow-recipes-runs-on-authz.test.js
//
// The reverse runs_on conflict gate must resolve the caller's access to the
// recipe BEFORE it probes (and names) that recipe's steps. Without the access
// check a non-owning editor PUT /flow-recipes/<foreign id> { runs_on } returned
// a 400 FLOW_STEP_MODE_CONFLICT listing the foreign recipe's diverging step
// NAMES — an ownership-free disclosure. The fix defers a caller who cannot read the
// recipe to the CRUD factory (which answers a foreign id 404), and the step
// probe never runs.
//
// SQL-aware mock: every query the gate + sameStoredValue issue is answered by
// shape, so the step probe can flag if it is ever reached — the ordering proof.
const { test, beforeEach } = require('node:test');
const assert = require('node:assert');
const express = require('express');

let recipeOwner = 'someone-else'; // owner_id the recipe SELECT returns
let sameAnswer = 0;               // the collation <=> answer (1 = same owner)
let stepProbeReached = false;     // set true iff the steps SELECT ever runs

require.cache[require.resolve('../../../../src/edge/db')] = {
  exports: {
    pool: {
      ro: {
        query: async (sql) => {
          if (/flow_recipe_steps/i.test(sql)) {
            // The step probe. Reaching it for a caller who cannot read the recipe
            // is the leak; it returns a divergent step so the OLD (no-access-check)
            // code produces its 400 naming that step.
            stepProbeReached = true;
            return [{ id: 's1', name: 'PushSecretStep', step_runs_on: 'update' }];
          }
          if (/DATABASE\(\)/.test(sql)) return [{ db: 'testdb' }];
          if (/information_schema/i.test(sql)) return [{ cs: 'utf8mb4', co: 'utf8mb4_general_ci' }];
          if (/<=>/.test(sql)) return [{ same: sameAnswer }];
          if (/flow_recipes/i.test(sql) && /owner_id/.test(sql)) return [{ owner_id: recipeOwner }];
          return [];
        },
      },
      rw: { getConnection: async () => ({ query: async () => [], release: () => {} }) },
    },
    t: (x) => x,
  },
};
require.cache[require.resolve('../../../../src/edge/routes/app/schema')] = {
  exports: { createCrudRoutes: () => (req, res) => res.status(404).json({ ok: true, reached: 'crud' }) },
};
const router = require('../../../../src/edge/routes/app/flow-recipes');

function app(user) {
  const a = express(); a.use(express.json());
  a.use((req, _res, next) => { req.user = user; next(); });
  a.use('/', router);
  return a;
}
async function send(a, method, path, body) {
  const server = a.listen(0);
  try {
    const port = server.address().port;
    const res = await fetch(`http://127.0.0.1:${port}${path}`, {
      method, headers: { 'content-type': 'application/json' }, body: JSON.stringify(body || {}),
    });
    const json = await res.json().catch(() => ({}));
    return { status: res.status, json };
  } finally {
    server.close();
  }
}

const EDITOR = { id: 'u1', role: 'editor' };
const RECIPE_ID = 'aaaa0000-0000-0000-0000-000000000001';

beforeEach(() => { recipeOwner = 'someone-else'; sameAnswer = 0; stepProbeReached = false; });

test('non-owning editor PUT of a foreign recipe never reaches the step probe → CRUD 404, no step name', async () => {
  recipeOwner = 'someone-else'; sameAnswer = 0; // the collation says NOT the caller's
  const { status, json } = await send(app(EDITOR), 'PUT', `/${RECIPE_ID}`, { runs_on: 'create' });
  assert.strictEqual(stepProbeReached, false, 'the step probe must not run for a recipe the caller cannot read');
  assert.strictEqual(json.reached, 'crud', 'the request must fall through to the CRUD factory');
  assert.strictEqual(status, 404, 'the CRUD factory answers a foreign id 404 — the gate adds no new disclosure');
  assert.ok(!JSON.stringify(json).includes('PushSecretStep'), 'no step name may leak');
  assert.notStrictEqual(json?.error?.code, 'FLOW_STEP_MODE_CONFLICT');
});

test('owning editor PUT still runs the probe and blocks a divergent step (legitimate path intact)', async () => {
  recipeOwner = 'u1'; // byte-equal to the caller → sameStoredValue short-circuits true, no collation query
  const { status, json } = await send(app(EDITOR), 'PUT', `/${RECIPE_ID}`, { runs_on: 'create' });
  assert.strictEqual(stepProbeReached, true, 'an owner reaches the probe');
  assert.strictEqual(status, 400);
  assert.strictEqual(json.error.code, 'FLOW_STEP_MODE_CONFLICT');
  assert.ok(json.error.message.includes('PushSecretStep'), 'the owner is told which step blocks the narrow');
});

test('a bogus runs_on value is not treated as a conflict — it defers to CRUD enum validation (L1)', async () => {
  recipeOwner = 'u1';
  const { json } = await send(app(EDITOR), 'PUT', `/${RECIPE_ID}`, { runs_on: 'CREATE' }); // wrong case, not a member
  assert.strictEqual(stepProbeReached, false, 'an invalid enum must not run the step probe');
  assert.strictEqual(json.reached, 'crud');
});
