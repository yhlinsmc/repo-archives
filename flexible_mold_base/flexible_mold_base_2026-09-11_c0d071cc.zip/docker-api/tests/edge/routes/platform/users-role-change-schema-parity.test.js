'use strict';

/**
 * users-role-change-schema-parity.test.js — the role-change security line reads
 * the prior role with `SELECT role ... WHERE id = ?` on the users table. A mock
 * would happily return a row for a mistyped column and hide a production 500, so
 * this asserts the referenced columns exist in the ACTUAL DDL, without a live DB.
 */
const { describe, it, before } = require('node:test');
const assert = require('node:assert/strict');
const { TABLES } = require('../../../../src/shared/constants');
const { buildAllTableDDLs } = require('../../../../src/table-ddls');

const SQL_TYPES = /^`?([a-z_]+)`?\s+(?:CHAR|VARCHAR|INT|DOUBLE|TIMESTAMP|JSON|TEXT|ENUM|BOOLEAN|TINYINT|BIGINT|DATETIME|DECIMAL|FLOAT|BLOB)\b/i;
let columnsByTable;

before(() => {
  columnsByTable = new Map();
  for (const ddl of buildAllTableDDLs((n) => n)) {
    const m = ddl.match(/CREATE TABLE IF NOT EXISTS `([^`]+)`/);
    if (!m) continue;
    const cols = new Set();
    for (const rawLine of ddl.split('\n')) {
      const line = rawLine.trim();
      if (!line || line.startsWith('--') || line.startsWith('/*')) continue;
      const cm = line.match(SQL_TYPES);
      if (cm) cols.add(cm[1]);
    }
    columnsByTable.set(m[1], cols);
  }
});

describe('role-change prior-role SELECT schema parity', () => {
  it('users declares the role and id columns the role-change SELECT references', () => {
    const cols = columnsByTable.get(String(TABLES.USERS));
    assert.ok(cols && cols.size > 0, 'no columns parsed for users');
    assert.ok(cols.has('role'), 'users.role missing from DDL');
    assert.ok(cols.has('id'), 'users.id missing from DDL');
  });
});
