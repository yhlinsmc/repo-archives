'use strict';

/**
 * users-update-role-transaction.test.js — updateRole must read the prior
 * role and write the new one inside ONE transaction on the SAME connection,
 * the SELECT locking the row (FOR UPDATE). Without the lock, two concurrent
 * admins each read the pre-change role, and the security line's `role_from`
 * on the second admin's write names a value that was already stale by the
 * time their UPDATE ran.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../../../src/edge/db');

let state;
function makeConn() {
  return {
    async beginTransaction() { state.calls.push('begin'); },
    async commit() { state.calls.push('commit'); },
    async rollback() { state.calls.push('rollback'); },
    release() { state.calls.push('release'); },
    async query(sql, params = []) {
      state.calls.push(sql.includes('SELECT') ? 'select' : 'update');
      state.queries.push({ sql, params });
      if (/SELECT role/.test(sql)) return state.priorRoleRows;
      if (/UPDATE/.test(sql)) {
        if (state.throwOnUpdate) throw new Error('boom');
        return { affectedRows: 1 };
      }
      return [];
    },
  };
}

const poolSpy = { rw: { async getConnection() { return makeConn(); } } };

require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: poolSpy, t: (name) => `fmb_${name}` },
};

const router = require('../../../../src/edge/routes/platform/users');

let server;
let base;

before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { req.user = { id: 'admin1', role: 'admin' }; next(); });
  app.use('/u', router);
  server = http.createServer(app);
  await new Promise((r) => server.listen(0, r));
  base = `http://127.0.0.1:${server.address().port}`;
});

after(() => server && server.close());

beforeEach(() => {
  state = { calls: [], queries: [], priorRoleRows: [{ role: 'user' }], throwOnUpdate: false };
});

async function updateRole(body) {
  const res = await fetch(`${base}/u`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ action: 'updateRole', ...body }),
  });
  return { status: res.status, json: await res.json() };
}

describe('POST / action=updateRole — transaction', () => {
  it('locks the prior-role read with FOR UPDATE and runs SELECT/UPDATE inside one begin/commit', async () => {
    const { status } = await updateRole({ userId: 'u1', role: 'editor' });
    assert.equal(status, 200);
    const select = state.queries.find((q) => /SELECT role/.test(q.sql));
    assert.match(select.sql, /FOR UPDATE/);
    assert.deepEqual(state.calls, ['begin', 'select', 'update', 'commit', 'release']);
  });

  it('rolls back and never commits when the UPDATE throws', async () => {
    state.throwOnUpdate = true;
    const { status } = await updateRole({ userId: 'u1', role: 'editor' });
    assert.equal(status, 500);
    assert.deepEqual(state.calls, ['begin', 'select', 'update', 'rollback', 'release']);
    assert.ok(!state.calls.includes('commit'), 'a throw between the read and the write must never commit');
  });
});
