'use strict';

/**
 * users-assignable-kcusername.test.js — GET /assignable carries kc_username
 * (spec §8.2), domain-stripped through the same helper the delegation person
 * picker uses, so the shared UserRow renders the same identity shape in the
 * transfer-owner picker as it does in the delegated-access dialog. Email is
 * never present — this route withholds it deliberately, and kc_username is
 * a username, not the email.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../../../src/edge/db');

let state;
function makeConn() {
  return {
    async query(sql) {
      state.queries.push({ sql });
      if (/SELECT id, display_name, role, kc_username\s+FROM `fmb_users`/.test(sql)) {
        return state.userRows || [];
      }
      return [];
    },
    release() {},
  };
}

const poolSpy = {
  ro: { async getConnection() { return makeConn(); } },
  rw: { async getConnection() { return makeConn(); } },
};

require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: poolSpy, t: (name) => `fmb_${name}` },
};

const router = require('../../../../src/edge/routes/platform/users');

let server;
let base;
let currentUser;

before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { req.user = currentUser; next(); });
  app.use('/u', router);
  server = http.createServer(app);
  await new Promise((r) => server.listen(0, r));
  base = `http://127.0.0.1:${server.address().port}`;
});

after(() => server && server.close());

beforeEach(() => {
  state = {
    queries: [],
    userRows: [
      {
        id: 'a1', display_name: 'Admin One', role: 'admin', kc_username: 'admin.one@corp.local',
      },
      {
        id: 'e1', display_name: 'Editor One', role: 'editor', kc_username: null,
      },
    ],
  };
  currentUser = { id: 'a1', role: 'admin', email: 'a@x' };
});

async function req(method, path) {
  const res = await fetch(`${base}${path}`, { method });
  return { status: res.status, json: await res.json() };
}

describe('GET /assignable — kc_username', () => {
  it('returns kc_username, domain-stripped, alongside id/display_name/role', async () => {
    const { status, json } = await req('GET', '/u/assignable');
    assert.equal(status, 200);
    assert.deepEqual(json.data, [
      {
        id: 'a1', display_name: 'Admin One', role: 'admin', kc_username: 'admin.one',
      },
      {
        id: 'e1', display_name: 'Editor One', role: 'editor', kc_username: '',
      },
    ]);
  });

  it('never returns an email field, and no value on the wire contains an address', async () => {
    const { json } = await req('GET', '/u/assignable');
    for (const row of json.data) {
      assert.equal('email' in row, false);
    }
    assert.ok(!JSON.stringify(json).includes('@'), 'an address reached the assignable picker');
  });

  // fmb-1976 PR-3 G-3B-6: display_name is a free-text column a LOCAL account
  // can be seeded with an address (the fixture above never drove this — every
  // display_name in it was already a plain name). kc_username IS stripped
  // here (the test above); display_name was returned RAW.
  it('strips an address-shaped display_name the same way kc_username is stripped', async () => {
    state.userRows = [
      { id: 'u1', display_name: 'jdoe@corp.local', role: 'user', kc_username: null },
    ];
    const { status, json } = await req('GET', '/u/assignable');
    assert.equal(status, 200);
    assert.equal(json.data[0].display_name, 'jdoe');
    assert.ok(!JSON.stringify(json).includes('@'), 'an address reached the assignable picker via display_name');
  });

  it('selects kc_username in the SQL', async () => {
    await req('GET', '/u/assignable');
    const q = state.queries.find((x) => /SELECT id, display_name, role/.test(x.sql));
    assert.match(q.sql, /\bkc_username\b/);
  });
});
