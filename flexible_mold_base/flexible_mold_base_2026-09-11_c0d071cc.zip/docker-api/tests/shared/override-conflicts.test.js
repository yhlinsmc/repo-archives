'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const { overrideConflictWarnings, OVERRIDE_CONFLICT_MESSAGES } = require('../../src/shared/override-conflicts');

test('autofill over a calculated field warns', () => {
  assert.deepEqual(
    overrideConflictWarnings({ action: 'autofill', blueprintValueSource: 'calculated', isRequired: false, retainWhenHidden: false }),
    [OVERRIDE_CONFLICT_MESSAGES.autofill_over_calculated],
  );
});
test('hide over a required field without retain warns; with retain it does not', () => {
  assert.deepEqual(
    overrideConflictWarnings({ action: 'hide', blueprintValueSource: 'entered', isRequired: true, retainWhenHidden: false }),
    [OVERRIDE_CONFLICT_MESSAGES.hide_over_required],
  );
  assert.deepEqual(
    overrideConflictWarnings({ action: 'hide', blueprintValueSource: 'entered', isRequired: true, retainWhenHidden: true }),
    [],
  );
});
