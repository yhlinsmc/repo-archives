// docker-api/tests/shared/serialize-options-golden.test.js
//
// Byte-locks serializeStepPayload's output for one JSON case + every YAML
// version x quoting combination, against the shared fixture also read by the
// FE vitest twin (src/fmb/lib/flow/__tests__/serialize-options.golden.test.ts)
// — both runners assert the SAME recorded bytes.
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const { serializeStepPayload } = require('../../src/shared/lib/serialize-options');
const golden = require('../../src/shared/lib/serialize-options.golden.json');

describe('serialize-options golden fixture (BE)', () => {
  for (const c of golden.cases) {
    const label = c.content_type === 'application/json'
      ? 'json'
      : `yaml ${c.yaml_version} ${c.yaml_quoting}`;
    it(`emits the byte-locked output for ${label}`, () => {
      const out = serializeStepPayload(golden.input, {
        content_type: c.content_type, yaml_version: c.yaml_version, yaml_quoting: c.yaml_quoting,
      });
      assert.equal(out, c.expected);
    });
  }
});
