/**
 * parse-json-column.test.js
 *
 * Pins the tolerant JSON-column parse shared/serializers/parse-json-column.js
 * supplies to every reader of a JSON-typed column (driver may hand back an
 * already-parsed object, a raw JSON string, or NULL/absent) — never throws.
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');

const { parseJsonColumn } = require('../../src/shared/serializers/parse-json-column');

describe('parseJsonColumn', () => {
  it('returns null for a null value', () => {
    assert.strictEqual(parseJsonColumn(null), null);
  });

  it('returns null for an undefined value', () => {
    assert.strictEqual(parseJsonColumn(undefined), null);
  });

  it('returns the same object when the driver already parsed it', () => {
    const obj = { a: 1, b: [2, 3] };
    assert.strictEqual(parseJsonColumn(obj), obj);
  });

  it('parses a valid JSON string', () => {
    assert.deepStrictEqual(parseJsonColumn('{"a":1,"b":[2,3]}'), { a: 1, b: [2, 3] });
  });

  it('returns null for an invalid JSON string, never throwing', () => {
    assert.strictEqual(parseJsonColumn('{not json'), null);
  });
});
