// docker-api/tests/shared/serialize-options-equivalence.test.js
//
// Pins that routing the five existing flow serialise call sites through
// serializeStepPayload (Task Y1.5) moves NO bytes: with yaml_version/
// yaml_quoting absent, stepSerializeOptions defaults to 1.2/plain, which is
// byte-identical to the pre-refactor bare `{ lineWidth: 0 }` call.
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const yaml = require('yaml');
const { serializeStepPayload } = require('../../src/shared/lib/serialize-options');

describe('serialize-options reproduces the pre-refactor bytes', () => {
  const samples = [
    { a: 'yes', n: 1, b: true, nested: { x: ['on', 'off'] } },
    {}, { only: 'plain' },
  ];
  for (const s of samples) {
    it(`YAML default dialect == bare { lineWidth: 0 } for ${JSON.stringify(s)}`, () => {
      assert.equal(
        serializeStepPayload(s, { content_type: 'application/yaml' }),
        yaml.stringify(s, { lineWidth: 0 }),
      );
    });
    it(`JSON == JSON.stringify for ${JSON.stringify(s)}`, () => {
      assert.equal(serializeStepPayload(s, { content_type: 'application/json' }), JSON.stringify(s));
    });
  }
});
