// spec 1.5/1.6/1.9: output_id required (no compat branch), filter validated
// by the BE floor in lockstep with the FE strict parser (parse-options-source.ts).
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const { invalidOptionsSourceShape } = require('../../src/shared/options-source-validate');

describe('invalidOptionsSourceShape — output_id + filter', () => {
  it('accepts a connector source with output_id', () => {
    assert.equal(invalidOptionsSourceShape({ type: 'connector', connector_id: 'c', output_id: 'o', input_bindings: {} }), false);
  });
  it('rejects a connector source with no output_id', () => {
    assert.equal(invalidOptionsSourceShape({ type: 'connector', connector_id: 'c', input_bindings: {} }), true);
  });
  it('rejects a connector source with an empty output_id', () => {
    assert.equal(invalidOptionsSourceShape({ type: 'connector', connector_id: 'c', output_id: '', input_bindings: {} }), true);
  });
  it('accepts a valid filter', () => {
    assert.equal(invalidOptionsSourceShape({ type: 'field', source_field_key: 'f', filter: { groups: [{ join: 'and', conditions: [{ target: 'label', op: 'like', pattern: 'x%' }] }] } }), false);
  });
  it('rejects a filter with a bad operator', () => {
    assert.equal(invalidOptionsSourceShape({ type: 'field', source_field_key: 'f', filter: { groups: [{ join: 'and', conditions: [{ target: 'label', op: 'regex', pattern: 'x' }] }] } }), true);
  });
  it('accepts an empty groups array (spec 1.8)', () => {
    assert.equal(invalidOptionsSourceShape({ type: 'field', source_field_key: 'f', filter: { groups: [] } }), false);
  });
  it('accepts an empty-string pattern (spec 1.7)', () => {
    assert.equal(invalidOptionsSourceShape({ type: 'field', source_field_key: 'f', filter: { groups: [{ join: 'or', conditions: [{ target: 'value', op: 'equals', pattern: '' }] }] } }), false);
  });
  it('rejects an invalid join', () => {
    assert.equal(invalidOptionsSourceShape({ type: 'field', source_field_key: 'f', filter: { groups: [{ join: 'xor', conditions: [] }] } }), true);
  });
  it('rejects a filter that is not an object', () => {
    assert.equal(invalidOptionsSourceShape({ type: 'field', source_field_key: 'f', filter: 'nope' }), true);
  });
  it('rejects a filter with an unknown group key', () => {
    assert.equal(invalidOptionsSourceShape({ type: 'field', source_field_key: 'f', filter: { groups: [{ join: 'and', conditions: [], evil: 1 }] } }), true);
  });
  it('rejects a filter condition missing a required key', () => {
    assert.equal(invalidOptionsSourceShape({ type: 'field', source_field_key: 'f', filter: { groups: [{ join: 'and', conditions: [{ target: 'label', op: 'like' }] }] } }), true);
  });
});
