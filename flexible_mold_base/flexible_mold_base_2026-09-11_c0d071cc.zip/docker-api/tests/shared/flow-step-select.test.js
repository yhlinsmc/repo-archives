/**
 * flow-step-select.test.js — full runs_on × mode table for
 * `docker-api/src/shared/lib/flow-step-select.js` (fmb-2090 PR-C1). The
 * FE/BE agreement itself is covered by the twin
 * `src/fmb/lib/flow/__tests__/step-select.parity.test.ts`; this file pins
 * the BE module's own truth table in isolation.
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const { selectStepsForMode, stepRunsInMode } = require('../../src/shared/lib/flow-step-select');

describe('stepRunsInMode — the full runs_on x mode table', () => {
  it('both -> runs in create, update; excluded from compare', () => {
    assert.equal(stepRunsInMode('both', 'create'), true);
    assert.equal(stepRunsInMode('both', 'update'), true);
    assert.equal(stepRunsInMode('both', 'compare'), false);
  });

  it('create -> runs only in create', () => {
    assert.equal(stepRunsInMode('create', 'create'), true);
    assert.equal(stepRunsInMode('create', 'update'), false);
    assert.equal(stepRunsInMode('create', 'compare'), false);
  });

  it('update -> runs only in update', () => {
    assert.equal(stepRunsInMode('update', 'create'), false);
    assert.equal(stepRunsInMode('update', 'update'), true);
    assert.equal(stepRunsInMode('update', 'compare'), false);
  });

  it('compare -> runs only in compare (excluded from create/update, read-only pass policy)', () => {
    assert.equal(stepRunsInMode('compare', 'create'), false);
    assert.equal(stepRunsInMode('compare', 'update'), false);
    assert.equal(stepRunsInMode('compare', 'compare'), true);
  });

  it('null/undefined defaults to both (grandfathered steps)', () => {
    assert.equal(stepRunsInMode(null, 'create'), true);
    assert.equal(stepRunsInMode(undefined, 'update'), true);
    assert.equal(stepRunsInMode(null, 'compare'), false);
  });
});

describe('selectStepsForMode — filters a step array identically to the per-cell table', () => {
  const steps = [
    { id: 'a', runs_on: 'create' },
    { id: 'b', runs_on: 'update' },
    { id: 'c', runs_on: 'both' },
    { id: 'd', runs_on: 'compare' },
    { id: 'e', runs_on: null },
  ];

  it('create mode selects a, c, e', () => {
    assert.deepEqual(selectStepsForMode(steps, 'create').map((s) => s.id), ['a', 'c', 'e']);
  });

  it('update mode selects b, c, e', () => {
    assert.deepEqual(selectStepsForMode(steps, 'update').map((s) => s.id), ['b', 'c', 'e']);
  });

  it('compare mode selects only d', () => {
    assert.deepEqual(selectStepsForMode(steps, 'compare').map((s) => s.id), ['d']);
  });

  it('a non-array input yields an empty array rather than throwing', () => {
    assert.deepEqual(selectStepsForMode(undefined, 'create'), []);
  });
});
