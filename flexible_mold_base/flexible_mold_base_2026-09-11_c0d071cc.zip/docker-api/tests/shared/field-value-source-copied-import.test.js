/**
 * field-value-source-copied-import.test.js — fmb-1964 retired the FE's
 * "Copied from another field" chooser, but the write boundary itself did not
 * change: an import or clone of a pre-1964 export still carries a stored
 * `value_source: 'copied'` payload, and `checkValueSourcePayload` must keep
 * accepting it exactly as before. This pins that the FE-side retirement never
 * became a silent BE-side rejection.
 */
'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const { checkValueSourcePayload } = require('../../src/shared/field-value-source');

test('a legacy copied payload with a one-part mirror rule still passes the write boundary', () => {
  const rule = {
    op: 'concat',
    overridable: false,
    output_type: 'string',
    config: { parts: [{ type: 'field', key: 'src' }], separator: '' },
  };
  const result = checkValueSourcePayload({ value_source: 'copied', compute_rule: rule });
  // null is the pass case for checkValueSourcePayload (see its JSDoc @returns).
  assert.equal(result, null);
});
