// spec 1.9 MUST: FE strict parser (parse-options-source.ts) and this BE
// structural floor decide the SAME accept/reject on the SAME shapes. The
// single source of truth for the case set is the shared JSON fixture (the
// FE vitest mirror consumes the same file — edit cases there only).
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const { invalidOptionsSourceShape } = require('../../src/shared/options-source-validate');
const fixture = require('../../../src/fmb/lib/option-source/__fixtures__/options-source-corpus.json');

describe('options-source floor — corpus parity (BE side)', () => {
  it('fixture case set is non-empty', () => {
    assert.ok(fixture.cases.length > 0);
  });
  for (const tc of fixture.cases) {
    it(`${tc.name} (reject=${tc.reject})`, () => {
      assert.equal(invalidOptionsSourceShape(tc.shape), tc.reject);
    });
  }
});
