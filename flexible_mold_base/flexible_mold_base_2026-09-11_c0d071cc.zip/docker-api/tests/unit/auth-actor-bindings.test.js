'use strict';

/**
 * auth-actor-bindings.test.js — infra auth middleware binds the derived actor
 * onto req.log once req.user (± req.impersonator) settles, on every exit path.
 *
 * edgeClient.resolveIdentity is the ONLY identity source driven here (mocked)
 * — RULE infra-talks-to-edge-only: the actor must come from that S2S response
 * object, never a DB read (this file/`docker-api/src/infra/` imports no DB
 * module at all, so there is no pool path to take).
 */
const { describe, it, beforeEach, afterEach } = require('node:test');
const assert = require('node:assert/strict');
const { signHs256 } = require('../helpers/jwt-hs256');

process.env.JWT_SECRET = process.env.JWT_SECRET || 'test-secret-actor-bindings-min-32chars';

const edgeClient = require('../../src/infra/lib/edge-state-client');
const authMiddleware = require('../../src/infra/middleware/auth');

function fakeReqLog() {
  const calls = [];
  return {
    calls,
    // Full pino level set (fmb-2105 finding: logS2s/sysLog call req.log[level](...)
    // on the EdgeUnreachable branch — a stub implementing only setBindings threw
    // TypeError there, silently swallowed by auth.js's own outer catch, which
    // made this exact "edge unreachable" test pass for the wrong reason).
    fatal() {}, error() {}, warn() {}, info() {}, debug() {}, trace() {},
    setBindings(b) { calls.push(b); },
  };
}

function makeReq(token, extra = {}) {
  return {
    headers: token ? { authorization: `Bearer ${token}` } : {},
    path: '/api/schema/user_templates',
    method: 'GET',
    ip: '127.0.0.1',
    user: null,
    log: fakeReqLog(),
    ...extra,
  };
}

function makeOidcReq(sub, extra = {}) {
  return {
    headers: {},
    path: '/api/schema/user_templates',
    method: 'GET',
    ip: '127.0.0.1',
    user: null,
    log: fakeReqLog(),
    oidc: { isAuthenticated: () => true, user: { sub } },
    ...extra,
  };
}

function makeRes() { return {}; }

describe('infra auth — actor bindings', () => {
  let origResolve;
  beforeEach(() => {
    authMiddleware._resetCacheForTests();
    origResolve = edgeClient.resolveIdentity;
  });
  afterEach(() => { edgeClient.resolveIdentity = origResolve; });

  it('JWT bearer success: setBindings called once with the actor mapped from the edge resolveIdentity response', async () => {
    edgeClient.resolveIdentity = async ({ userId }) => ({
      user: { id: userId, kc_username: 'alice', role: 'user' },
      banned: false,
      pool_ready: true,
    });
    const token = await signHs256({ sub: 'u-1' }, process.env.JWT_SECRET);
    const req = makeReq(token);
    await authMiddleware(req, makeRes(), () => {});
    assert.equal(req.log.calls.length, 1);
    assert.deepEqual(req.log.calls[0].actor, { id: 'u-1', name: 'alice', type: 'user' });
  });

  it('OIDC success: actor bound from the resolved user, not a fresh DB read (edgeClient is the only source)', async () => {
    edgeClient.resolveIdentity = async () => ({
      user: { id: 'u-2', kc_username: 'bob', role: 'user' },
      banned: false,
      pool_ready: true,
    });
    const req = makeOidcReq('kc-2');
    await authMiddleware(req, makeRes(), () => {});
    assert.equal(req.log.calls.length, 1);
    assert.equal(req.log.calls[0].actor.id, 'u-2');
    assert.equal(req.log.calls[0].actor.name, 'bob');
  });

  it('impersonation: actor carries impersonator_id from the real admin', async () => {
    edgeClient.resolveIdentity = async ({ userId, source }) => {
      if (source === 'jwt-bearer' && userId === 'admin-1') {
        return { user: { id: 'admin-1', kc_username: 'admin', role: 'admin' }, banned: false, pool_ready: true };
      }
      return { user: { id: 'user-9', kc_username: 'user9', role: 'user' }, banned: false, pool_ready: true };
    };
    const token = await signHs256({ sub: 'admin-1' }, process.env.JWT_SECRET);
    const req = makeReq(token, { headers: { authorization: `Bearer ${token}`, 'x-impersonate-user-id': 'user-9' } });
    await authMiddleware(req, makeRes(), () => {});
    assert.equal(req.log.calls.length, 1);
    assert.equal(req.log.calls[0].actor.id, 'user-9');
    assert.equal(req.log.calls[0].actor.impersonator_id, 'admin-1');
  });

  it('unauthenticated (no header, no oidc): setBindings is never called (actor is undefined)', async () => {
    const req = makeReq(null);
    await authMiddleware(req, makeRes(), () => {});
    assert.equal(req.log.calls.length, 0);
  });

  it('req.log absent (older test harness): middleware does not throw (optional-chained)', async () => {
    edgeClient.resolveIdentity = async ({ userId }) => ({
      user: { id: userId, kc_username: 'carol', role: 'user' },
      banned: false,
      pool_ready: true,
    });
    const token = await signHs256({ sub: 'u-3' }, process.env.JWT_SECRET);
    const req = makeReq(token);
    delete req.log;
    await assert.doesNotReject(authMiddleware(req, makeRes(), () => {}));
  });

  it('cache-hit path also binds the actor (early "return next()" branch)', async () => {
    let calls = 0;
    edgeClient.resolveIdentity = async ({ userId }) => {
      calls += 1;
      return { user: { id: userId, kc_username: 'dave', role: 'user' }, banned: false, pool_ready: true };
    };
    const token = await signHs256({ sub: 'u-4' }, process.env.JWT_SECRET);
    const req1 = makeReq(token);
    await authMiddleware(req1, makeRes(), () => {});
    const req2 = makeReq(token);
    await authMiddleware(req2, makeRes(), () => {});
    assert.equal(calls, 1, 'second request served from cache');
    assert.equal(req2.log.calls.length, 1);
    assert.equal(req2.log.calls[0].actor.name, 'dave');
  });

  it('edge unreachable: req.user stays null, no actor binding', async () => {
    const { EdgeUnreachable } = edgeClient;
    edgeClient.resolveIdentity = async () => { throw new EdgeUnreachable('down'); };
    const token = await signHs256({ sub: 'u-5' }, process.env.JWT_SECRET);
    const req = makeReq(token);
    await authMiddleware(req, makeRes(), () => {});
    assert.equal(req.user, null);
    assert.equal(req.log.calls.length, 0);
  });
});
