// api-connectors-usable-bindings.test.js — GET /usable includes a connector
// bound to the queried blueprint via the join table, not only its home
// blueprint, and degrades to home-only when
// the join table itself is absent (no-DDL DB) rather than 500ing.
const { it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../src/edge/db');
let queryImpl;
const conn = {
  async query(sql, params) { return queryImpl(sql, params); },
  release() {},
};
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: { ro: { getConnection: async () => conn }, rw: { getConnection: async () => conn } }, t: (n) => `fmb_${n}` },
};

const register = require('../../src/edge/routes/app/api-connectors/usable');

let currentUser;
let server; let baseUrl;
before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { if (currentUser) req.user = currentUser; next(); });
  const router = express.Router();
  register(router);
  app.use('/edge/app/api-connectors', router);
  server = http.createServer(app);
  await new Promise((r) => server.listen(0, r));
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});
after(() => server && server.close());

beforeEach(() => {
  currentUser = { id: 'u1', role: 'user' };
  queryImpl = () => [];
});

async function get(path) {
  const res = await fetch(`${baseUrl}${path}`);
  return { status: res.status, body: await res.json() };
}

it('includes a connector bound to the queried blueprint via the join table, even though its home blueprint differs', async () => {
  queryImpl = (sql, params) => {
    if (/FROM `fmb_api_connectors`/.test(sql) && /is_active = 1/.test(sql)) {
      // Real DB semantics: the widened OR/subquery predicate is queried for
      // blueprint B on both legs (home OR bound-via-join), regardless of the
      // connector's actual home blueprint.
      assert.deepEqual(params, ['B', 'B']);
      return [{
        id: 'bound-conn', name: 'Bound', description: null,
        url: 'http://svc/x', request_config: JSON.stringify({}),
        response_config: JSON.stringify({ outputs: [], transformer_id: null }),
      }];
    }
    return [];
  };
  const r = await get('/edge/app/api-connectors/usable?blueprint_id=B');
  assert.equal(r.status, 200);
  assert.equal(r.body.data.length, 1);
  assert.equal(r.body.data[0].id, 'bound-conn');
});

it('falls back to home-only when the join table is missing (no-DDL DB), never 500', async () => {
  let calls = 0;
  queryImpl = (sql) => {
    if (/FROM `fmb_api_connectors`/.test(sql) && /is_active = 1/.test(sql)) {
      calls += 1;
      if (calls === 1) {
        const e = new Error('no such table: fmb_api_connector_blueprints');
        e.errno = 1146; e.code = 'ER_NO_SUCH_TABLE';
        throw e;
      }
      // The tolerant fallback (home-only) still serves the home-bound connector.
      return [{
        id: 'home-conn', name: 'Home', description: null,
        url: 'http://svc/y', request_config: JSON.stringify({}),
        response_config: JSON.stringify({ outputs: [], transformer_id: null }),
      }];
    }
    return [];
  };
  const r = await get('/edge/app/api-connectors/usable?blueprint_id=B');
  assert.equal(r.status, 200);
  assert.equal(r.body.data.length, 1);
  assert.equal(r.body.data[0].id, 'home-conn');
  assert.equal(calls, 2, 'the widened query must be tried first, then the home-only fallback');
});
