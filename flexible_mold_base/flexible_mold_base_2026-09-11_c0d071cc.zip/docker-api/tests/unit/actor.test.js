'use strict';

/**
 * actor.test.js — pure mapping from a resolved req.user (+ optional
 * impersonator) to the { id, name, type, impersonator_id? } shape that rides
 * on the per-request logger's bindings.
 *
 * name never comes from email: every branch is asserted to carry no `email`
 * key, and the only accepted name sources are kc_username / username.
 */
const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const { toActor, deEmail } = require('../../src/shared/lib/actor');

describe('toActor', () => {
  it('kc_username → name is the bare username, type user', () => {
    const actor = toActor({ id: 'u-1', kc_username: 'alice' });
    assert.deepEqual(actor, { id: 'u-1', name: 'alice', type: 'user' });
    assert.equal('email' in actor, false);
  });

  it('username shaped like an email is de-emailed (defensive @-cut)', () => {
    const actor = toActor({ id: 'u-2', username: 'bob@corp' });
    assert.equal(actor.name, 'bob');
    assert.equal('email' in actor, false);
  });

  it('service_account type maps to "service"', () => {
    const actor = toActor({ id: 'svc1', type: 'service_account', kc_username: 'svc-runner' });
    assert.equal(actor.type, 'service');
  });

  it('non-service-account type (including absent) maps to "user"', () => {
    assert.equal(toActor({ id: 'u-3' }).type, 'user');
    assert.equal(toActor({ id: 'u-4', type: 'human' }).type, 'user');
  });

  it('impersonation adds impersonator_id', () => {
    const actor = toActor({ id: 'target-1', kc_username: 'target' }, { id: 'admin-1' });
    assert.equal(actor.impersonator_id, 'admin-1');
  });

  it('no impersonator argument → no impersonator_id key', () => {
    const actor = toActor({ id: 'u-5', kc_username: 'carol' });
    assert.equal('impersonator_id' in actor, false);
  });

  it('null/undefined user → undefined (unauthenticated, no actor binding)', () => {
    assert.equal(toActor(null), undefined);
    assert.equal(toActor(undefined), undefined);
  });

  it('email-only user (JWT-bearer req.user with no kc_username/username) → name is undefined, never falls back to email', () => {
    const actor = toActor({ id: 'u-6', email: 'a@corp' });
    assert.equal(actor.name, undefined);
    assert.equal('email' in actor, false);
    assert.ok(!JSON.stringify(actor).includes('@'), 'no @ anywhere in the serialised actor');
  });

  it('kc_username wins over username when both present', () => {
    const actor = toActor({ id: 'u-7', kc_username: 'kc-name', username: 'other-name' });
    assert.equal(actor.name, 'kc-name');
  });

  it('every branch: actor never carries an email key', () => {
    const cases = [
      { id: 'a', kc_username: 'x' },
      { id: 'b', username: 'y@z' },
      { id: 'c', type: 'service_account' },
      { id: 'd', email: 'leak@corp' },
    ];
    for (const user of cases) {
      const actor = toActor(user);
      assert.equal('email' in actor, false, JSON.stringify(user));
    }
  });

  it('every branch: actor keys are a subset of {id, name, type, impersonator_id} — a future field is a deliberate change, not a silent widening (redactConfig does not cover actor.*, Decision A)', () => {
    const ALLOWED = new Set(['id', 'name', 'type', 'impersonator_id']);
    const rows = [
      { user: { id: 'a', kc_username: 'x' } },
      { user: { id: 'b', username: 'y@z' } },
      { user: { id: 'c', type: 'service_account' } },
      { user: { id: 'd', email: 'leak@corp' } },
      { user: { id: 'target-1', kc_username: 'target' }, impersonator: { id: 'admin-1' } },
    ];
    for (const { user, impersonator } of rows) {
      const actor = toActor(user, impersonator);
      for (const key of Object.keys(actor)) {
        assert.ok(ALLOWED.has(key), `unexpected actor key "${key}" for ${JSON.stringify({ user, impersonator })}`);
      }
    }
  });
});

describe('deEmail', () => {
  it('cuts at the first @', () => {
    assert.equal(deEmail('bob@corp'), 'bob');
  });
  it('leaves a plain string untouched', () => {
    assert.equal(deEmail('alice'), 'alice');
  });
  it('non-string input → undefined', () => {
    assert.equal(deEmail(undefined), undefined);
    assert.equal(deEmail(null), undefined);
    assert.equal(deEmail(42), undefined);
  });
});
