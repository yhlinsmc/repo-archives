/**
 * api-connectors-source-kind-guard.test.js — the write-path guard
 * (index.js) that normalises the http-only columns and validates
 * source_config before a create/update reaches the CRUD factory.
 *
 * Boots the real api-connectors router against a mocked pool (same
 * transaction-capable shape api-connectors-write-follower-guard.test.js
 * uses), admin role throughout (bypasses the unrelated ownership/reparent
 * guards so the source-kind guard is exercised in isolation).
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../src/edge/db');

const CONNECTOR_ID = '11111111-1111-1111-1111-111111111111';
const ADMIN_ID = '44444444-4444-4444-4444-444444444444';
const BP_ID = 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa';

let captured;
let capturedQueries;
// The row the source-kind guard's own probe SELECT answers with, for a PUT
// that touches only one of source_kind/source_config. `undefined` means the
// key is absent from the row object (a no-DDL fallback SELECT never carries
// it) — distinct from `null`, which is a real stored value.
let storedSourceKind;
let storedSourceConfig;
// When true, the guard's own probe SELECT throws ER_BAD_FIELD_ERROR — the
// no-ALTER operator DB shape where the columns are physically absent.
let simulateMissingSourceCols = false;
// R-G1 priming controls. dbNameOverride isolates the CRUD factory's
// (schema/helpers.js) no-TTL column-set cache to a fresh key per test that
// needs to control what got primed into it — the cache is a real
// module-level singleton shared by every test in this process, so re-using
// 'testdb' would read whatever an EARLIER test already cached. columnSetRows,
// when set, is what the getActualColumnSet's information_schema.COLUMNS probe
// answers with (undefined = existing behaviour: always [] → colSet null →
// keep all keys, unrelated to this priming).
let dbNameOverride = 'testdb';
let columnSetRows;
// Codex r1 P2-B: controls the egress allow-list the mock's system_settings
// answers with. Default undefined → the guard's own default-empty branch
// below returns [] (allow-all), matching every existing test in this file. A
// test that needs a genuinely off-allow-list url sets this to a restrictive
// policy so egressAllowedForUrl actually has something to deny against.
let egressPolicyRows;

function makeConn() {
  return {
    async beginTransaction() {},
    async commit() {},
    async rollback() {},
    async query(sql, params) {
      capturedQueries.push({ sql, params });
      if (/SELECT DATABASE\(\)/.test(sql)) return [{ db: dbNameOverride }];
      if (/information_schema\.COLUMNS/i.test(sql)) {
        return columnSetRows !== undefined
          ? columnSetRows.map((c) => ({ COLUMN_NAME: c }))
          : []; // colSet null → keep all keys
      }
      if (/FROM `fmb_users`/.test(sql)) return [];
      if (/FROM `fmb_system_settings`/.test(sql)) return egressPolicyRows !== undefined ? egressPolicyRows : []; // egress allow-list: allow-all by default
      if (/FROM `fmb_hierarchy_nodes` WHERE id = \?/.test(sql)) {
        return params[0] === BP_ID ? [{ id: BP_ID }] : [];
      }
      // The columns-exist probe (T14-R1): LIMIT 0, no WHERE — distinct from the
      // stored-row probe below, which always carries a `WHERE id = ?`.
      if (/SELECT source_kind, source_config FROM `fmb_api_connectors` LIMIT 0/.test(sql)) {
        if (simulateMissingSourceCols) {
          const e = new Error("Unknown column 'source_kind'"); e.code = 'ER_BAD_FIELD_ERROR'; e.errno = 1054;
          throw e;
        }
        return [];
      }
      if (/SELECT source_kind, source_config FROM `fmb_api_connectors` WHERE id = \?/.test(sql)) {
        if (simulateMissingSourceCols) {
          const e = new Error("Unknown column 'source_kind'"); e.code = 'ER_BAD_FIELD_ERROR'; e.errno = 1054;
          throw e;
        }
        if (params[0] !== CONNECTOR_ID) return [];
        const row = {};
        if (storedSourceKind !== undefined) row.source_kind = storedSourceKind;
        if (storedSourceConfig !== undefined) row.source_config = storedSourceConfig;
        return [row];
      }
      if (/^UPDATE `fmb_api_connectors`/.test(sql.trim())) {
        captured.update = { sql, params };
        return { affectedRows: 1 };
      }
      if (/^INSERT INTO `fmb_api_connectors`/.test(sql.trim())) {
        captured.insert = { sql, params };
        return { affectedRows: 1 };
      }
      if (/SELECT \* FROM `fmb_api_connectors` WHERE id = \?/.test(sql)) {
        return [{
          id: params[0], name: 'c1', is_active: 1,
          auth_type: 'none', auth_config: JSON.stringify({}),
          request_config: null, response_config: null,
          owner_id: 'admin', blueprint_id: BP_ID,
          method: 'GET', url: 'http://svc/x', dispatch_origin: 'infra',
          source_kind: 'http', source_config: null,
          created_at: '2026-01-01 00:00:00', updated_at: '2026-01-01 00:00:00',
        }];
      }
      return [];
    },
    release() {},
  };
}
const poolSpy = {
  ro: { async getConnection() { return makeConn(); }, async query(sql, params) { return makeConn().query(sql, params); } },
  rw: { async getConnection() { return makeConn(); }, async query(sql, params) { return makeConn().query(sql, params); } },
};
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: poolSpy, t: (name) => `fmb_${name}` },
};

const router = require('../../src/edge/routes/app/api-connectors');

let server; let base;
before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => { req.user = { id: ADMIN_ID, role: 'admin' }; next(); });
  app.use('/c', router);
  server = http.createServer(app);
  await new Promise((r) => server.listen(0, r));
  base = `http://127.0.0.1:${server.address().port}`;
});
after(() => server && server.close());
beforeEach(() => {
  captured = {};
  capturedQueries = [];
  storedSourceKind = 'http';
  storedSourceConfig = null;
  simulateMissingSourceCols = false;
  dbNameOverride = 'testdb';
  columnSetRows = undefined;
  egressPolicyRows = undefined;
});

async function put(id, body) {
  const res = await fetch(`${base}/c/${id}`, {
    method: 'PUT', headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
  });
  return { status: res.status, json: await res.json() };
}

async function post(body) {
  const res = await fetch(`${base}/c`, {
    method: 'POST', headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
  });
  return { status: res.status, json: await res.json() };
}

describe('api-connectors source-kind guard (index.js)', () => {
  it('rejects an unknown source_kind, no UPDATE', async () => {
    const { status, json } = await put(CONNECTOR_ID, { source_kind: 'ftp' });
    assert.equal(status, 400);
    assert.match(json.error.message, /source_kind/);
    assert.equal(captured.update, undefined);
  });

  it('T14-R4: no-DDL, PUT with an unknown source_kind → 400 BAD_REQUEST (not 409), no UPDATE', async () => {
    simulateMissingSourceCols = true;
    const { status, json } = await put(CONNECTOR_ID, { source_kind: 'ftp' });
    assert.equal(status, 400, JSON.stringify(json));
    assert.match(json.error.message, /source_kind/);
    assert.equal(captured.update, undefined);
  });

  it('T14-R4: no-DDL, POST with an unknown source_kind → 400 BAD_REQUEST (not 409), no INSERT', async () => {
    simulateMissingSourceCols = true;
    const { status, json } = await post({ name: 'c3', source_kind: 'ftp' });
    assert.equal(status, 400, JSON.stringify(json));
    assert.match(json.error.message, /source_kind/);
    assert.equal(captured.insert, undefined);
  });

  it('normalises url/method/auth/dispatch to inert values on a template PUT before the CRUD write', async () => {
    const { status } = await put(CONNECTOR_ID, {
      source_kind: 'template',
      source_config: { blueprint_id: BP_ID, mode: 'one', select: { kind: 'pick' }, parts: ['outputs'] },
      url: 'https://x.test', method: 'POST', auth_type: 'bearer', dispatch_origin: 'infra',
    });
    assert.equal(status, 200);
    assert.ok(captured.update, 'UPDATE must have been called');
    // The SET clause carries the normalised values, not the caller's http
    // ones — the caller's 'https://x.test' / 'POST' / 'bearer' / 'infra' must
    // not survive into the write.
    assert.match(captured.update.sql, /`url` = \?/);
    assert.match(captured.update.sql, /`method` = \?/);
    assert.match(captured.update.sql, /`auth_type` = \?/);
    assert.match(captured.update.sql, /`dispatch_origin` = \?/);
    assert.equal(captured.update.params.includes('https://x.test'), false);
    assert.equal(captured.update.params.includes('POST'), false);
    assert.equal(captured.update.params.includes('bearer'), false);
    assert.equal(captured.update.params.includes('infra'), false);
    assert.equal(captured.update.params.includes(''), true, 'url normalised to empty string');
    assert.equal(captured.update.params.includes('GET'), true, 'method normalised to GET');
    assert.equal(captured.update.params.includes('none'), true, 'auth_type normalised to none');
    assert.equal(captured.update.params.includes('edge'), true, 'dispatch_origin normalised to edge');
  });

  // R6-D2: a stale http request_config (headers/body still carrying {{var}}
  // tokens from before a kind switch) must never survive a template write —
  // its Request section is hidden in the editor, so nothing else can clear it.
  it('R6-D2: a template PUT carrying a stale http request_config stores it as NULL, not the caller\'s value', async () => {
    const { status } = await put(CONNECTOR_ID, {
      source_kind: 'template',
      source_config: { blueprint_id: BP_ID, mode: 'one', select: { kind: 'pick' }, parts: ['outputs'] },
      request_config: { headers: { Authorization: 'Bearer {{id}}' }, body: '{"q":"{{id}}"}' },
    });
    assert.equal(status, 200);
    assert.ok(captured.update, 'UPDATE must have been called');
    const cols = [...captured.update.sql.matchAll(/`(\w+)` = \?/g)].map((m) => m[1]);
    const idx = cols.indexOf('request_config');
    assert.notEqual(idx, -1, 'request_config must be part of the SET clause');
    assert.equal(captured.update.params[idx], null, 'request_config must be stored NULL, not the caller\'s headers/body');
  });

  it('a PUT touching only source_config reads the STORED source_kind (partial update, D-F5 shape)', async () => {
    storedSourceKind = 'http';
    const { status, json } = await put(CONNECTOR_ID, { source_config: { body: '{"a":1}' } });
    // http ignores source_config entirely — the write must pass, not be judged
    // as an (invalid, since it lacks blueprint_id) template config.
    assert.equal(status, 200, JSON.stringify(json));
    assert.ok(captured.update);
    assert.equal(capturedQueries.some((q) => /SELECT source_kind, source_config FROM `fmb_api_connectors` WHERE id = \?/.test(q.sql)), true);
  });

  it('a PUT touching only source_config, stored source_kind undefined (no-DDL fallback row), still 200 — reads as http (D-F5)', async () => {
    storedSourceKind = undefined; // the row object has no source_kind key at all
    const { status, json } = await put(CONNECTOR_ID, { source_config: { body: '{"a":1}' } });
    assert.equal(status, 200, JSON.stringify(json));
    assert.ok(captured.update);
  });

  it('a PUT touching only source_config on a genuinely no-DDL DB (probe SELECT itself 1054s) degrades to http, not 500', async () => {
    simulateMissingSourceCols = true;
    const { status, json } = await put(CONNECTOR_ID, { source_config: { anything: 'goes, http ignores it' } });
    assert.equal(status, 200, JSON.stringify(json));
    assert.ok(captured.update);
  });

  it('rejects a template PUT whose source_config names an unknown blueprint, no UPDATE', async () => {
    const { status, json } = await put(CONNECTOR_ID, {
      source_kind: 'template',
      source_config: { blueprint_id: 'ghost', mode: 'one', parts: ['outputs'] },
    });
    assert.equal(status, 400);
    assert.match(json.error.message, /blueprint/i);
    assert.equal(captured.update, undefined);
  });

  it('T14-R1: no-DDL, a PUT touching BOTH source_kind and source_config → 409 SOURCE_KIND_UNAVAILABLE, zero UPDATE', async () => {
    simulateMissingSourceCols = true;
    const { status, json } = await put(CONNECTOR_ID, {
      source_kind: 'template',
      source_config: { blueprint_id: BP_ID, mode: 'one', select: { kind: 'pick' }, parts: ['outputs'] },
    });
    assert.equal(status, 409, JSON.stringify(json));
    assert.equal(json.error.code, 'SOURCE_KIND_UNAVAILABLE');
    assert.match(json.error.message, /schema migration/);
    assert.equal(captured.update, undefined, 'no UPDATE — the guard must not reach the CRUD write');
  });

  it('T14-R1: no-DDL, a POST with http-shaped fields plus a non-http source_kind → 409, zero INSERT', async () => {
    simulateMissingSourceCols = true;
    const { status, json } = await post({
      name: 'c2', url: 'http://svc/x', method: 'GET', auth_type: 'none', dispatch_origin: 'infra',
      source_kind: 'static', source_config: { body: '{}' },
    });
    assert.equal(status, 409, JSON.stringify(json));
    assert.equal(json.error.code, 'SOURCE_KIND_UNAVAILABLE');
    assert.equal(captured.insert, undefined, 'no INSERT — the guard must not reach the CRUD write');
  });

  it('T14-R1: no-DDL, a PUT touching only source_kind (partial) → 409, reusing the stored-row probe (no second probe)', async () => {
    simulateMissingSourceCols = true;
    const { status, json } = await put(CONNECTOR_ID, { source_kind: 'static' });
    assert.equal(status, 409, JSON.stringify(json));
    assert.equal(json.error.code, 'SOURCE_KIND_UNAVAILABLE');
    assert.equal(captured.update, undefined);
    // Only the stored-row probe (`WHERE id = ?`) may have run; the separate
    // columns-exist `LIMIT 0` probe must NOT fire a second time for the same
    // question this row load already answered.
    const limit0Hits = capturedQueries.filter((q) => /LIMIT 0/.test(q.sql)).length;
    assert.equal(limit0Hits, 0, 'must reuse the stored-row probe answer, not probe twice');
  });

  it('T14-R2: stored template row, PUT touching only source_config with an unknown blueprint → 400 BAD_REQUEST, no UPDATE', async () => {
    storedSourceKind = 'template';
    storedSourceConfig = JSON.stringify({ blueprint_id: BP_ID, mode: 'one', parts: ['outputs'] });
    const { status, json } = await put(CONNECTOR_ID, {
      source_config: { blueprint_id: 'ghost', mode: 'one', parts: ['outputs'] },
    });
    assert.equal(status, 400, JSON.stringify(json));
    assert.match(json.error.message, /blueprint/i);
    assert.equal(captured.update, undefined);
  });

  it('T14-R2: stored template row, PUT touching only source_config with a valid config → 200, UPDATE carries the inert http columns', async () => {
    storedSourceKind = 'template';
    storedSourceConfig = JSON.stringify({ blueprint_id: BP_ID, mode: 'one', parts: ['outputs'] });
    const { status, json } = await put(CONNECTOR_ID, {
      source_config: { blueprint_id: BP_ID, mode: 'one', select: { kind: 'pick' }, parts: ['outputs'] },
    });
    assert.equal(status, 200, JSON.stringify(json));
    assert.ok(captured.update, 'UPDATE must have been called');
    assert.equal(captured.update.params.includes(''), true, 'url normalised to empty string');
    assert.equal(captured.update.params.includes('GET'), true, 'method normalised to GET');
    assert.equal(captured.update.params.includes('none'), true, 'auth_type normalised to none');
    assert.equal(captured.update.params.includes('edge'), true, 'dispatch_origin normalised to edge');
  });

  it('T14-R3: stored template row, PUT {source_kind:"http"} clears source_config to null in the same UPDATE', async () => {
    storedSourceKind = 'template';
    storedSourceConfig = JSON.stringify({ blueprint_id: BP_ID, mode: 'one', parts: ['outputs'] });
    const { status, json } = await put(CONNECTOR_ID, { source_kind: 'http' });
    assert.equal(status, 200, JSON.stringify(json));
    assert.ok(captured.update, 'UPDATE must have been called');
    const cols = [...captured.update.sql.matchAll(/`(\w+)` = \?/g)].map((m) => m[1]);
    const idx = cols.indexOf('source_config');
    assert.notEqual(idx, -1, 'source_config must be part of the SET clause');
    assert.equal(captured.update.params[idx], null, 'source_config must be cleared to null');
  });
});

// Codex r1 P2-B: the source-kind guard now runs AHEAD of the url-shape guard
// (:94, pre-move) and the egress guard (:114, pre-move) — both are http-only
// checks that must not judge a template/static payload's inert url, and both
// read the `res.locals.resolvedSourceKind` stamp rather than re-deriving the
// kind from the body.
describe('Codex r1 P2-B: source-kind guard runs ahead of the url-shape and egress guards', () => {
  it('(a) full-save template payload with the documented inert url \'\' → 200, UPDATE carries url \'\'', async () => {
    const { status, json } = await put(CONNECTOR_ID, {
      url: '', method: 'GET', auth_type: 'none', source_kind: 'template',
      source_config: { blueprint_id: BP_ID, mode: 'one', parts: ['outputs'] },
    });
    assert.equal(status, 200, JSON.stringify(json));
    assert.ok(captured.update, 'UPDATE must have been called');
    const cols = [...captured.update.sql.matchAll(/`(\w+)` = \?/g)].map((m) => m[1]);
    const idx = cols.indexOf('url');
    assert.notEqual(idx, -1, 'url must be part of the SET clause');
    assert.equal(captured.update.params[idx], '', 'url must be stored empty, not rejected by the http url-shape guard');
  });

  it('(b) a static PUT with no url in the body, under a RESTRICTIVE egress policy → 200, egress skipped, url normalised to \'\'', async () => {
    // Non-empty policy that matches nothing this request could ever carry —
    // without the res.locals skip, the source-kind guard's own normalizer
    // ADDS url:'' to req.body (it always stamps the inert values), which
    // makes the egress guard's own `hasOwnProperty(req.body, 'url')` check
    // true for the FIRST time on this partial PUT and denies on host:''.
    egressPolicyRows = [{ value: JSON.stringify([{ hosts: ['allowed.example.com'], rules: [{ method: 'GET', path: '/**' }] }]) }];
    const { status, json } = await put(CONNECTOR_ID, {
      source_kind: 'static', source_config: { body: '{}' },
    });
    assert.equal(status, 200, JSON.stringify(json));
    assert.ok(captured.update, 'UPDATE must have been called');
    assert.equal(capturedQueries.some((q) => /FROM `fmb_system_settings`/.test(q.sql)), false,
      'the egress allow-list must never be queried for a resolved non-http kind');
    const cols = [...captured.update.sql.matchAll(/`(\w+)` = \?/g)].map((m) => m[1]);
    const idx = cols.indexOf('url');
    assert.equal(captured.update.params[idx], '', 'url must be normalised to empty string');
  });

  it('(c) http body with a malformed url → still 400 from the url-shape guard (unchanged)', async () => {
    const { status, json } = await put(CONNECTOR_ID, { source_kind: 'http', url: 'not-a-url' });
    assert.equal(status, 400, JSON.stringify(json));
    assert.match(json.error.message, /absolute http\(s\) URL/);
    assert.equal(captured.update, undefined);
  });

  it('(d) http body with an off-allow-list url → still the egress 4xx (unchanged)', async () => {
    egressPolicyRows = [{ value: JSON.stringify([{ hosts: ['allowed.example.com'], rules: [{ method: 'GET', path: '/**' }] }]) }];
    const { status, json } = await put(CONNECTOR_ID, { source_kind: 'http', url: 'https://blocked.example.com/x', method: 'GET' });
    assert.equal(status, 422, JSON.stringify(json));
    assert.equal(json.error.code, 'EGRESS_BLOCKED');
    assert.equal(captured.update, undefined);
  });
});

// D-F5 column set: every api_connectors column except source_kind/
// source_config — the pre-migration schema the priming write below caches.
const PRE_MIGRATION_COLUMNS = [
  'id', 'name', 'description', 'is_active', 'owner_id', 'blueprint_id', 'section_key',
  'method', 'url', 'auth_type', 'auth_config', 'request_config', 'response_config',
  'dispatch_origin', 'group_id', 'group_label', 'group_mode', 'sequence', 'timeout_ms',
  'status', 'approved_by', 'approved_at', 'review_note', 'created_at', 'updated_at',
];
const POST_MIGRATION_COLUMNS = [...PRE_MIGRATION_COLUMNS, 'source_kind', 'source_config'];

describe('R-G1: guard live probe vs CRUD factory column-set cache (migrate-live-no-restart)', () => {
  it('a cache primed before a live migration is reconciled by the guard, so a template POST INSERT still names source_kind/source_config', async () => {
    // Fresh (db, table) cache key, isolated from every other test in this
    // file — schema/helpers.js's _columnSetCache is a real module-level
    // singleton with no TTL, so reusing 'testdb' would read whatever an
    // earlier test in this process already cached there.
    dbNameOverride = `primedb_${process.pid}`;
    columnSetRows = PRE_MIGRATION_COLUMNS;

    // Step 1: an ordinary http create — it never touches source_kind/
    // source_config, so the source-kind guard is a no-op and this write
    // reaches the CRUD factory's getActualColumnSet directly, caching the
    // pre-migration set for this (db, table) key.
    const prime = await post({ name: 'prime', url: 'http://svc/prime', method: 'GET', auth_type: 'none', dispatch_origin: 'infra' });
    assert.equal(prime.status, 200, JSON.stringify(prime.json));
    assert.ok(captured.insert, 'priming INSERT must have run');
    assert.equal(/`source_kind`/.test(captured.insert.sql), false,
      'sanity check: the cache was really primed with the pre-migration set (source_kind not in it yet) — not null/"unknown", which would keep every key regardless');

    // Step 2: the migration has since been applied live, no app restart. The
    // guard's own probe (LIMIT 0 SELECT, never cached) reflects that — it
    // succeeds (simulateMissingSourceCols stays false throughout). A live
    // requery of information_schema would now find the full set too
    // (columnSetRows below), but the CRUD factory's cache is no-TTL and,
    // without the fix, would go on answering from the stale step-1 Set.
    columnSetRows = POST_MIGRATION_COLUMNS;
    captured = {};
    const { status, json } = await post({
      name: 'c-template', source_kind: 'template',
      source_config: { blueprint_id: BP_ID, mode: 'one', select: { kind: 'pick' }, parts: ['outputs'] },
    });
    assert.equal(status, 200, JSON.stringify(json));
    assert.ok(captured.insert, 'template INSERT must have run');
    assert.match(captured.insert.sql, /`source_kind`/);
    assert.match(captured.insert.sql, /`source_config`/);
    assert.equal(captured.insert.params.includes('template'), true);
  });
});

