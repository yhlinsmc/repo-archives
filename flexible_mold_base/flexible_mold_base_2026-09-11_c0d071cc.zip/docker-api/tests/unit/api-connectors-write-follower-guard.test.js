/**
 * api-connectors-write-follower-guard.test.js — CRUD write-path follower-
 * column guard (Q9/D2 amendment A4), Codex round-1 P2 fix.
 *
 * The guard in index.js used to fire only when the BODY named
 * `response_config`. A PUT that changes ONLY `blueprint_id` (a rebind) never
 * named it, so it skipped the guard entirely — and the row's STORED
 * response_config could go on targeting a follower column of the NEW
 * blueprint with no check at all. The fix validates the EFFECTIVE post-write
 * pair (blueprint_id, response_config), loading whichever half the body
 * omits from the existing row.
 *
 * Boots the real api-connectors router against a mocked pool (same
 * transaction-capable shape api-connectors-crud-mask.test.js uses), and
 * exercises three angles on ONE stored connector (blueprint_id=BP_A,
 * response_config targets servers::site):
 *   - rebind-only PUT to a blueprint whose OWN servers::site is a follower
 *     column → 400 (the bug this fix closes)
 *   - rebind-only PUT to a blueprint with no follower columns → 200
 *     (the guard must not over-block an ordinary rebind)
 *   - response_config-only PUT (no blueprint_id) still validated against the
 *     STORED blueprint_id → 400 (regression: the pre-existing single-
 *     condition path must keep working)
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../src/edge/db');

// The CRUD factory's own id-format guard requires a canonical UUID for
// blueprint_id (and the row id), independent of the follower guard under
// test — these have to look real or every scenario 400s before reaching it.
const CONNECTOR_ID = '11111111-1111-1111-1111-111111111111';
const BP_A = 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa'; // stored blueprint
const BP_B = 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb'; // rebind target: servers::site IS a follower
const BP_C = 'cccccccc-cccc-cccc-cccc-cccccccccccc'; // rebind target: servers::site is ordinary

const EDITOR_ID = '22222222-2222-2222-2222-222222222222';
const OTHER_EDITOR_ID = '33333333-3333-3333-3333-333333333333';
// A canonical-UUID admin id — POST auto-approval writes `approved_by` from
// req.user.id, which the identifier-floor guard requires in CHAR(36) form.
// The plain string 'admin' previously used here only worked because no
// existing test in this file drove an admin POST.
const ADMIN_ID = '44444444-4444-4444-4444-444444444444';

const STORED_BLUEPRINT_ID = BP_A;
// Targets servers::site — a follower column on BP_B (the "bad" rebind
// target) but an ordinary column on BP_C (the "compatible" rebind target).
const STORED_RESPONSE_CONFIG = JSON.stringify({
  outputs: [{ to: { mode: 'cell', table_key: 'servers', column_key: 'site' } }],
});

// blueprint_id -> blueprint_fields rows `loadFollowerColumnKeys` reads.
const BLUEPRINT_FIELDS = {
  [BP_A]: [{ field_key: 'servers', table_config: JSON.stringify({ columns: [{ key: 'site', linked_source: { field_key: 'sites', column_key: 'name' } }] }) }],
  [BP_B]: [{ field_key: 'servers', table_config: JSON.stringify({ columns: [{ key: 'site', linked_source: { field_key: 'sites', column_key: 'name' } }] }) }],
  [BP_C]: [{ field_key: 'servers', table_config: JSON.stringify({ columns: [{ key: 'site' }] }) }], // ordinary column, no linked_source
};

let captured;
// Per-test controls for the editor reparent matrix below. Unused (left at
// their defaults) by every admin-role test above — admin never reaches the
// crud-factory's ownership judgment, so these two never fire a query.
let role;
let currentParentValue; // readOwnParentValue's answer: the connector's STORED blueprint_id
let chainOwnerRows; // the target blueprint's chain-ownership row(s); undefined → "not found"
// M3 (fmb-1934): every statement issued by ANY connection this request opens
// (the follower guard's own ephemeral `resolveRwPool(req).query(...)` call,
// and the transactional connection the CRUD factory holds for the write) —
// so "did checkParentOwnership's chain SELECT run at all" is answerable
// without caring which connection object asked it.
let capturedQueries;

function makeConn() {
  return {
    async beginTransaction() {},
    async commit() {},
    async rollback() {},
    async query(sql, params) {
      capturedQueries.push({ sql, params });
      if (/SELECT DATABASE\(\)/.test(sql)) return [{ db: 'testdb' }];
      if (/information_schema\.COLUMNS/i.test(sql)) return []; // colSet null → keep all keys
      if (/FROM `fmb_users`/.test(sql)) return []; // owner-name enrichment → none
      // The guard's own effective-pair load — distinct column list from the
      // CRUD factory's `SELECT *` below, so the two never collide. Matches
      // both the fixed query (`blueprint_id, response_config`) and the
      // pre-fix one (`blueprint_id` alone) so a revert probe exercises the
      // real defect (the trigger condition) rather than an unrelated mock
      // mismatch on the query shape.
      if (/SELECT blueprint_id(?:, response_config)? FROM `fmb_api_connectors` WHERE id = \?/.test(sql)) {
        return params[0] === CONNECTOR_ID
          ? [{ blueprint_id: STORED_BLUEPRINT_ID, response_config: STORED_RESPONSE_CONFIG }]
          : [];
      }
      // The reject-on-change judgment's own read of the CURRENT stored
      // parent — distinct alias/shape from the follower guard's load above,
      // so the two arms never collide.
      if (/^SELECT `blueprint_id` AS parent_value FROM `fmb_api_connectors` WHERE id = \?/i.test(sql)) {
        return [{ parent_value: currentParentValue }];
      }
      // The reject-on-change judgment's own entitlement read (editor scope).
      if (/^SELECT id FROM `fmb_api_connectors` WHERE id = \?/i.test(sql.trim())) {
        return [{ id: params[0] }];
      }
      // checkParentOwnership's single-hop chain SELECT against the TARGET
      // blueprint (hierarchy_nodes.owner_id).
      if (/SELECT j0\.`owner_id` AS owner_id\s+FROM `fmb_hierarchy_nodes` j0/i.test(sql)) {
        return chainOwnerRows ?? [];
      }
      if (/SELECT field_key, table_config FROM `fmb_blueprint_fields` WHERE blueprint_id = \? AND field_type = 'table'/.test(sql)) {
        return BLUEPRINT_FIELDS[params[0]] ?? [];
      }
      if (/^UPDATE `fmb_api_connectors`/.test(sql.trim())) {
        captured.update = { sql, params };
        return { affectedRows: 1 };
      }
      if (/^INSERT INTO `fmb_api_connectors`/.test(sql.trim())) {
        captured.insert = { sql, params };
        return { affectedRows: 1 };
      }
      if (/SELECT \* FROM `fmb_api_connectors` WHERE id = \?/.test(sql)) {
        return [{
          id: params[0], name: 'c1', is_active: 1,
          auth_type: 'none', auth_config: JSON.stringify({}),
          request_config: null, response_config: STORED_RESPONSE_CONFIG,
          owner_id: 'admin', blueprint_id: BP_C,
          method: 'GET', url: 'http://svc/x', dispatch_origin: 'infra',
          created_at: '2026-01-01 00:00:00', updated_at: '2026-01-01 00:00:00',
        }];
      }
      return [];
    },
    release() {},
  };
}
const poolSpy = {
  ro: { async getConnection() { return makeConn(); }, async query(sql, params) { return makeConn().query(sql, params); } },
  rw: { async getConnection() { return makeConn(); }, async query(sql, params) { return makeConn().query(sql, params); } },
};
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: poolSpy, t: (name) => `fmb_${name}` },
};

const router = require('../../src/edge/routes/app/api-connectors');

let server; let base;
before(async () => {
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => {
    req.user = role === 'editor' ? { id: EDITOR_ID, role: 'editor' } : { id: ADMIN_ID, role: 'admin' };
    next();
  });
  app.use('/c', router);
  server = http.createServer(app);
  await new Promise((r) => server.listen(0, r));
  base = `http://127.0.0.1:${server.address().port}`;
});
after(() => server && server.close());
beforeEach(() => {
  captured = {};
  capturedQueries = [];
  role = 'admin';
  currentParentValue = STORED_BLUEPRINT_ID;
  chainOwnerRows = undefined;
});

// checkParentOwnership's single-hop chain SELECT — matched the same way the
// mock above answers it.
const chainSelectPattern = /SELECT j0\.`owner_id` AS owner_id\s+FROM `fmb_hierarchy_nodes` j0/i;

async function put(id, body) {
  const res = await fetch(`${base}/c/${id}`, {
    method: 'PUT', headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
  });
  return { status: res.status, json: await res.json() };
}

async function post(body) {
  const res = await fetch(`${base}/c`, {
    method: 'POST', headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
  });
  return { status: res.status, json: await res.json() };
}

describe('api-connectors CRUD PUT — follower-column guard validates the EFFECTIVE pair', () => {
  it('rebind-only PUT to a blueprint whose target column is now a follower → 400', async () => {
    const { status, json } = await put(CONNECTOR_ID, { blueprint_id: BP_B });
    assert.equal(status, 400);
    assert.equal(json.error.code, 'BAD_REQUEST');
    assert.match(json.error.message, /mirrors another table/);
    assert.equal(captured.update, undefined, 'must not have written past the guard');
  });

  it('rebind-only PUT to a blueprint with no follower columns → 200 (not over-blocked)', async () => {
    const { status } = await put(CONNECTOR_ID, { blueprint_id: BP_C });
    assert.equal(status, 200);
    assert.ok(captured.update, 'the compatible rebind must reach the UPDATE');
  });

  it('response_config-only PUT (no blueprint_id) is still validated against the STORED blueprint — regression', async () => {
    const { status, json } = await put(CONNECTOR_ID, {
      response_config: { outputs: [{ to: { mode: 'cell', table_key: 'servers', column_key: 'site' } }] },
    });
    assert.equal(status, 400);
    assert.equal(json.error.code, 'BAD_REQUEST');
    assert.equal(captured.update, undefined);
  });
});

describe('api-connectors CRUD PUT — editor reparent (reject-on-change, fmb-1934 PR-1)', () => {
  it('editor rebinding to a shared blueprint → 200, blueprint_id in SET, ownership probe DID run', async () => {
    role = 'editor';
    currentParentValue = BP_A; // stored — different from the rebind target below
    chainOwnerRows = [{ owner_id: null }]; // BP_C is shared
    const { status, json } = await put(CONNECTOR_ID, { blueprint_id: BP_C });
    assert.equal(status, 200, `expected 200, got ${status}: ${JSON.stringify(json)}`);
    assert.ok(captured.update, 'UPDATE must have been called');
    assert.match(captured.update.sql, /SET .*`blueprint_id` = \?/);
    assert.equal(captured.update.params.includes(BP_C), true);
    // M3: a lawful CHANGE must probe the target's ownership.
    assert.equal(capturedQueries.some((q) => chainSelectPattern.test(q.sql)), true);
  });

  it("editor rebinding to another editor's blueprint → 403, no UPDATE, ownership probe DID run", async () => {
    role = 'editor';
    currentParentValue = BP_A;
    chainOwnerRows = [{ owner_id: OTHER_EDITOR_ID }];
    const { status, json } = await put(CONNECTOR_ID, { blueprint_id: BP_C });
    assert.equal(status, 403, `expected 403, got ${status}: ${JSON.stringify(json)}`);
    assert.equal(json.error.code, 'FORBIDDEN');
    assert.match(json.error.message, /parent row is not owned/i);
    // M1: the discriminator survives to the response body.
    assert.equal(json.error.details && json.error.details.reason, 'parent_not_owned');
    assert.equal(captured.update, undefined, 'must not have written past the guard');
    assert.equal(capturedQueries.some((q) => chainSelectPattern.test(q.sql)), true);
  });

  it('editor PUT that repeats the SAME blueprint_id alongside another change → 200, blueprint_id stays OUT of SET, no ownership probe (H1/M3)', async () => {
    role = 'editor';
    currentParentValue = BP_C; // stored === body — byte-identical, no chain lookup fires
    // A body naming ONLY the unchanged blueprint_id ends up with an empty SET
    // clause and correctly 400s "No valid fields to update" (a pre-existing,
    // unrelated guard) — so this pairs it with a genuine change (name) the
    // same way schema-factory-parent-ownership.test.js's equivalent test
    // pairs its same-value field_id with an option_label change.
    const { status, json } = await put(CONNECTOR_ID, { blueprint_id: BP_C, name: 'renamed' });
    assert.equal(status, 200, `expected 200, got ${status}: ${JSON.stringify(json)}`);
    assert.ok(captured.update, 'UPDATE must have been called');
    assert.match(captured.update.sql, /SET .*`name` = \?/);
    // H1 (fmb-1934 round 1): the unchanged branch must not re-add
    // blueprint_id to the body — writing the caller's spelling back over an
    // unchanged value is exactly the bug this test used to pin as correct.
    assert.doesNotMatch(captured.update.sql, /SET .*`blueprint_id` = \?/);
    // M3: a same-value PUT must not probe ownership of a target parent.
    assert.equal(capturedQueries.some((q) => chainSelectPattern.test(q.sql)), false);
  });

  it('editor PUT that un-binds (blueprint_id: null) → 403 PARENT_REQUIRED, distinct from the ownership refusal, no UPDATE (H2)', async () => {
    role = 'editor';
    currentParentValue = BP_A; // stored — non-null, so this names a real change
    const { status, json } = await put(CONNECTOR_ID, { blueprint_id: null });
    assert.equal(status, 403, `expected 403, got ${status}: ${JSON.stringify(json)}`);
    assert.equal(json.error.code, 'FORBIDDEN');
    // Distinct reason from the ownership refusal (M1's PARENT_NOT_OWNED) —
    // no blueprint was named, so "owned by another user" would be false.
    assert.equal(json.error.details && json.error.details.reason, 'parent_required');
    assert.notEqual(json.error.message, 'Not allowed: parent row is not owned by you and is not shared');
    assert.equal(captured.update, undefined, 'must not have written past the guard');
    // checkParentOwnership(req, conn, null) is never called for this branch —
    // it would answer false unconditionally and produce the WRONG message.
    assert.equal(capturedQueries.some((q) => chainSelectPattern.test(q.sql)), false);
  });

  it('admin PUT that un-binds (blueprint_id: null) → 200 (parentViaProvided never applies to admin)', async () => {
    role = 'admin';
    currentParentValue = BP_A;
    const { status, json } = await put(CONNECTOR_ID, { blueprint_id: null });
    assert.equal(status, 200, `expected 200, got ${status}: ${JSON.stringify(json)}`);
    assert.ok(captured.update, 'UPDATE must have been called');
  });
});

// Codex P2 (fmb-1934): the reject-on-change judgment captures
// `data[parentOwnership.via]` (blueprint_id) into `requestedParentValue` and
// deletes it from `data` before `checkWriteColumns` runs — so the same
// identifier-floor check every other identifier column on this write
// receives never judged it, and a malformed value reached
// `checkParentOwnership`'s chain SELECT unvalidated (a number reaching a
// CHAR(36) comparison is identifier-floor.js's RC-2 shape).
describe('api-connectors CRUD PUT — malformed blueprint_id refused before any ownership probe (Codex P2, fmb-1934)', () => {
  it('blueprint_id = 123 (number) → 400 INVALID_ID_FORMAT, no chain SELECT, no UPDATE', async () => {
    role = 'editor';
    currentParentValue = BP_A;
    const { status, json } = await put(CONNECTOR_ID, { blueprint_id: 123 });
    assert.equal(status, 400, `expected 400, got ${status}: ${JSON.stringify(json)}`);
    assert.equal(json.error.code, 'INVALID_ID_FORMAT');
    assert.equal(captured.update, undefined, 'must not have written past the guard');
    assert.equal(capturedQueries.some((q) => chainSelectPattern.test(q.sql)), false);
  });

  it("blueprint_id = 'not-a-uuid' (malformed string) → 400 INVALID_ID_FORMAT, no chain SELECT, no UPDATE", async () => {
    role = 'editor';
    currentParentValue = BP_A;
    const { status, json } = await put(CONNECTOR_ID, { blueprint_id: 'not-a-uuid' });
    assert.equal(status, 400, `expected 400, got ${status}: ${JSON.stringify(json)}`);
    assert.equal(json.error.code, 'INVALID_ID_FORMAT');
    assert.equal(captured.update, undefined, 'must not have written past the guard');
    assert.equal(capturedQueries.some((q) => chainSelectPattern.test(q.sql)), false);
  });

  it('blueprint_id = {} (object) → 400 INVALID_ID_FORMAT, no chain SELECT, no UPDATE', async () => {
    role = 'editor';
    currentParentValue = BP_A;
    const { status, json } = await put(CONNECTOR_ID, { blueprint_id: {} });
    assert.equal(status, 400, `expected 400, got ${status}: ${JSON.stringify(json)}`);
    assert.equal(json.error.code, 'INVALID_ID_FORMAT');
    assert.equal(captured.update, undefined, 'must not have written past the guard');
    assert.equal(capturedQueries.some((q) => chainSelectPattern.test(q.sql)), false);
  });

  it('a valid foreign (well-formed, another editor\'s) blueprint_id is unaffected — still 403, still no UPDATE', async () => {
    role = 'editor';
    currentParentValue = BP_A;
    chainOwnerRows = [{ owner_id: OTHER_EDITOR_ID }];
    const { status } = await put(CONNECTOR_ID, { blueprint_id: BP_C });
    assert.equal(status, 403);
    assert.equal(captured.update, undefined);
  });

  it('a valid shared (well-formed, owner_id NULL) blueprint_id is unaffected — still 200', async () => {
    role = 'editor';
    currentParentValue = BP_A;
    chainOwnerRows = [{ owner_id: null }];
    const { status } = await put(CONNECTOR_ID, { blueprint_id: BP_C });
    assert.equal(status, 200);
    assert.ok(captured.update);
  });
});

// fmb-1934 PR-1 M2: POST used to reach checkParentOwnership(null), which
// answers `false` unconditionally and produced PARENT_NOT_OWNED — the "owned
// by another user" copy an editor creating a brand-new, unbound connector
// used to see. Both verbs now raise the same PARENT_REQUIRED refusal for a
// null target, through the same `parentRequiredError()` helper.
describe('api-connectors CRUD POST — editor create with no blueprint bound (fmb-1934 PR-1 M2)', () => {
  it('editor POST with a null blueprint_id → 403 PARENT_REQUIRED, no INSERT', async () => {
    role = 'editor';
    const { status, json } = await post({
      name: 'x', url: 'https://svc/x', method: 'GET', auth_type: 'none', blueprint_id: null,
    });
    assert.equal(status, 403, `expected 403, got ${status}: ${JSON.stringify(json)}`);
    assert.equal(json.error.code, 'FORBIDDEN');
    assert.equal(json.error.details && json.error.details.reason, 'parent_required');
    assert.notEqual(json.error.message, 'Not allowed: parent row is not owned by you and is not shared');
    assert.equal(captured.insert, undefined, 'must not have written past the guard');
    // checkParentOwnership(req, conn, null) is never called for this branch —
    // it would answer false unconditionally and produce the WRONG reason.
    assert.equal(capturedQueries.some((q) => chainSelectPattern.test(q.sql)), false);
  });

  it("editor POST targeting another editor's blueprint → 403 PARENT_NOT_OWNED, no INSERT (unchanged)", async () => {
    role = 'editor';
    chainOwnerRows = [{ owner_id: OTHER_EDITOR_ID }];
    const { status, json } = await post({
      name: 'x', url: 'https://svc/x', method: 'GET', auth_type: 'none', blueprint_id: BP_C,
    });
    assert.equal(status, 403, `expected 403, got ${status}: ${JSON.stringify(json)}`);
    assert.equal(json.error.code, 'FORBIDDEN');
    assert.equal(json.error.details && json.error.details.reason, 'parent_not_owned');
    assert.equal(captured.insert, undefined, 'must not have written past the guard');
    assert.equal(capturedQueries.some((q) => chainSelectPattern.test(q.sql)), true);
  });

  it('admin POST with a null blueprint_id → 200 (parentOwnership guard never applies to admin, unchanged)', async () => {
    role = 'admin';
    const { status, json } = await post({
      name: 'x', url: 'https://svc/x', method: 'GET', auth_type: 'none', blueprint_id: null,
    });
    assert.equal(status, 200, `expected 200, got ${status}: ${JSON.stringify(json)}`);
    assert.ok(captured.insert, 'INSERT must have been called');
  });
});
