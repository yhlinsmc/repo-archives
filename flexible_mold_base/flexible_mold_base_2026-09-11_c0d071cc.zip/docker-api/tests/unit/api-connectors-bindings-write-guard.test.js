/**
 * api-connectors-bindings-write-guard.test.js — a connector PUT that changes
 * request_config/response_config so an ALREADY-BOUND extra blueprint would
 * become incomplete is rejected (400 BINDING_FIELD_KEYS_MISSING); the binding
 * itself is never silently dropped. Uses the same shared completeness check
 * (connector-binding-keys.js) the bindings PUT route runs — one guard, no
 * second copy of the loop.
 *
 * Boots the real api-connectors router against a mocked pool, following the
 * same conn-double shape as api-connectors-write-follower-guard.test.js.
 */
const { describe, it, before, after, beforeEach } = require('node:test');
const { makeStubReqLog } = require('../helpers/stub-req-log');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../src/edge/db');

const CONNECTOR_ID = '11111111-1111-1111-1111-111111111111';
const HOME_BLUEPRINT_ID = 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa';
const EXTRA_BLUEPRINT_ID = 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb';
const GROUP_EXTRA_ID = 'cccccccc-cccc-cccc-cccc-cccccccccccc';
const GROUP_ID = '99999999-9999-9999-9999-999999999999';
const ADMIN_ID = '44444444-4444-4444-4444-444444444444';
const EDITOR_ID = '5a5a5a5a-5a5a-5a5a-5a5a-5a5a5a5a5a5a';
const FOREIGN_OWNER_ID = '6b6b6b6b-6b6b-6b6b-6b6b-6b6b6b6b6b6b';

let state;
let role;

function makeConn() {
  // Each connection is tagged so a test can assert two statements ran on the
  // SAME one — the in-tx reconcile must delete on the update transaction's
  // connection, never on a fresh pool connection outside it.
  const connId = ++state.connSeq;
  return {
    async beginTransaction() {},
    async commit() {},
    async rollback() {},
    async query(sql, params) {
      state.queries.push({ sql, params });
      if (/SELECT DATABASE\(\)/.test(sql)) return [{ db: 'testdb' }];
      if (/information_schema\.COLUMNS/i.test(sql)) return [];
      if (/FROM `fmb_users`/.test(sql)) return [];
      // The home-clear guard's read-only extras count.
      if (/SELECT COUNT\(\*\) AS n FROM `fmb_api_connector_blueprints` WHERE connector_id = \?/.test(sql)) {
        if (state.missingJoinTable) {
          const e = new Error('no such table: fmb_api_connector_blueprints');
          e.errno = 1146; e.code = 'ER_NO_SUCH_TABLE';
          throw e;
        }
        return [{ n: (state.extraBlueprintIds || []).length }];
      }
      // The bindings write-guard's own join-rows probe.
      if (/SELECT blueprint_id FROM `fmb_api_connector_blueprints` WHERE connector_id = \?/.test(sql)) {
        if (state.missingJoinTable) {
          const e = new Error('no such table: fmb_api_connector_blueprints');
          e.errno = 1146; e.code = 'ER_NO_SUCH_TABLE';
          throw e;
        }
        return (state.extraBlueprintIds || []).map((id) => ({ blueprint_id: id }));
      }
      // The crud-factory enrichRows batch read (attachConnectorBindings) that
      // now runs on the create/update RESPONSE too, so a write reply carries
      // `bindings` like a GET does.
      if (/SELECT connector_id, blueprint_id FROM `fmb_api_connector_blueprints`\s+WHERE connector_id IN/.test(sql)) {
        return (state.enrichBindings || []).map((id) => ({ connector_id: CONNECTOR_ID, blueprint_id: id }));
      }
      // The bundle-join pre-write guard's stored home + configs load.
      if (/SELECT blueprint_id, request_config, response_config FROM `fmb_api_connectors` WHERE id = \?/.test(sql)) {
        return params[0] === CONNECTOR_ID
          ? [{ blueprint_id: HOME_BLUEPRINT_ID, request_config: state.storedRequestConfig, response_config: state.storedResponseConfig }]
          : [];
      }
      // The bundle-join group-sync's committed-home read (postUpdateInTx, when
      // the PUT did not carry blueprint_id). Single column — distinct from the
      // multi-column reads above.
      if (/SELECT blueprint_id FROM `fmb_api_connectors` WHERE id = \?/.test(sql)) {
        return params[0] === CONNECTOR_ID ? [{ blueprint_id: HOME_BLUEPRINT_ID }] : [];
      }
      // assertBindingTargets' existence + node_type='blueprint' + owner read
      // (the bundle-join guard runs it for THIS connector against the group set).
      // Every queried id is treated as an existing blueprint; owner_id NULL =
      // shared, so authority passes for any role (the admin fixture bypasses it
      // regardless).
      if (/SELECT id, owner_id FROM `fmb_hierarchy_nodes` WHERE id IN/.test(sql)) {
        return params.slice(0, -1).map((id) => ({
          id,
          owner_id: (state.blueprintOwners && state.blueprintOwners.has(id)) ? state.blueprintOwners.get(id) : null,
        }));
      }
      // The bundle's shared extra set: the OTHER members' extras (this row and
      // the home excluded), computed the same way by the pre-write guard and the
      // in-tx group sync. The pre-write guard reads it first; postUpdateInTx
      // reads it again INSIDE the tx — a test can stage a mid-flight change by
      // setting state.groupSetTx, which the second read returns.
      if (/SELECT DISTINCT b\.blueprint_id AS blueprint_id\s+FROM `fmb_api_connector_blueprints` b\s+JOIN `fmb_api_connectors` c/.test(sql)) {
        if (state.missingJoinTable) {
          const e = new Error('no such table: fmb_api_connector_blueprints');
          e.errno = 1146; e.code = 'ER_NO_SUCH_TABLE';
          throw e;
        }
        state.groupSetReads = (state.groupSetReads || 0) + 1;
        const set = (state.groupSetReads >= 2 && state.groupSetTx !== undefined)
          ? state.groupSetTx : (state.groupSet || []);
        return set.map((id) => ({ blueprint_id: id }));
      }
      // The group sync's replace: drop this row's whole set, then re-insert the
      // bundle's. Plain connector_id DELETE — distinct from the home-reconcile
      // DELETE (which also keys on blueprint_id).
      if (/^DELETE FROM `fmb_api_connector_blueprints` WHERE connector_id = \?\s*$/.test(sql.trim())) {
        if (state.missingJoinTable) {
          const e = new Error('no such table: fmb_api_connector_blueprints');
          e.errno = 1146; e.code = 'ER_NO_SUCH_TABLE';
          throw e;
        }
        state.groupSyncDeletes.push(params);
        state.opLog.push({ op: 'groupSyncDelete', connId });
        return { affectedRows: 1 };
      }
      if (/^INSERT INTO `fmb_api_connector_blueprints` \(id, connector_id, blueprint_id\) VALUES \(UUID\(\), \?, \?\)/.test(sql.trim())) {
        if (state.missingJoinTable) {
          const e = new Error('no such table: fmb_api_connector_blueprints');
          e.errno = 1146; e.code = 'ER_NO_SUCH_TABLE';
          throw e;
        }
        state.groupSyncInserts.push(params);
        state.opLog.push({ op: 'groupSyncInsert', connId });
        return { affectedRows: 1 };
      }
      // The follower-column guard's own effective-pair load.
      if (/SELECT blueprint_id, response_config FROM `fmb_api_connectors` WHERE id = \?/.test(sql)) {
        return params[0] === CONNECTOR_ID
          ? [{ blueprint_id: HOME_BLUEPRINT_ID, response_config: state.storedResponseConfig }]
          : [];
      }
      // The bindings write-guard's own effective-pair load.
      if (/SELECT request_config, response_config FROM `fmb_api_connectors` WHERE id = \?/.test(sql)) {
        return params[0] === CONNECTOR_ID
          ? [{ request_config: state.storedRequestConfig, response_config: state.storedResponseConfig }]
          : [];
      }
      if (/SELECT field_key, table_config FROM `fmb_blueprint_fields` WHERE blueprint_id = \? AND field_type = 'table'/.test(sql)) {
        // Per-blueprint follower-column fixture (default: none). Keyed by
        // blueprint id so the home guard and the per-extra guard can differ.
        return (state.followerByBlueprint && state.followerByBlueprint.get(params[0])) || [];
      }
      if (/SELECT blueprint_id, field_key FROM `fmb_blueprint_fields`\s+WHERE blueprint_id IN/.test(sql)) {
        const out = [];
        for (const id of params) for (const k of (state.fieldKeysByBlueprint.get(id) || [])) out.push({ blueprint_id: id, field_key: k });
        return out;
      }
      if (/SELECT output_keys FROM `fmb_transformers` WHERE id = \?/.test(sql)) return [];
      // The in-tx reconcile's delete of the join row equal to the new home
      // (postUpdateInTx, on the update transaction's connection).
      if (/^DELETE FROM `fmb_api_connector_blueprints` WHERE connector_id = \? AND blueprint_id = \?/.test(sql.trim())) {
        if (state.missingJoinTable) {
          const e = new Error('no such table: fmb_api_connector_blueprints');
          e.errno = 1146; e.code = 'ER_NO_SUCH_TABLE';
          throw e;
        }
        state.reconcileDeletes.push(params);
        state.opLog.push({ op: 'reconcileDelete', connId });
        return { affectedRows: 1 };
      }
      // The editor-role delegated-arm entitlement pre-check (locksBeforeUpdate):
      // "does this row's owner_id and its home blueprint's chain owner admit
      // this caller" — an EXISTS form on fmb_hierarchy_nodes j0. Admin PUTs
      // never build this scope at all (delegatedArm is admin-skipped), so only
      // the editor-role scenarios in this file reach it. Honours the same
      // state.updateAffected gate the scoped UPDATE itself uses, so a test that
      // wants "not entitled" sets updateAffected = 0 exactly as it already does
      // for the admin 404 case.
      if (/^SELECT id FROM `fmb_api_connectors` WHERE id = \?/.test(sql.trim())) {
        return state.updateAffected === 0 ? [] : [{ id: params[0] }];
      }
      if (/^UPDATE `fmb_api_connectors`/.test(sql.trim())) {
        state.update = { sql, params };
        state.opLog.push({ op: 'update', connId });
        return { affectedRows: state.updateAffected == null ? 1 : state.updateAffected };
      }
      if (/SELECT \* FROM `fmb_api_connectors` WHERE id = \?/.test(sql)) {
        return [{
          id: params[0], name: 'c1', is_active: 1,
          auth_type: 'none', auth_config: JSON.stringify({}),
          request_config: state.storedRequestConfig, response_config: state.storedResponseConfig,
          owner_id: state.connectorOwnerId || 'admin', blueprint_id: HOME_BLUEPRINT_ID,
          method: 'GET', url: 'http://svc/x', dispatch_origin: 'infra',
          created_at: '2026-01-01 00:00:00', updated_at: '2026-01-01 00:00:00',
        }];
      }
      return [];
    },
    release() {},
  };
}
const poolSpy = {
  ro: { async getConnection() { return makeConn(); }, async query(sql, params) { return makeConn().query(sql, params); } },
  rw: { async getConnection() { return makeConn(); }, async query(sql, params) { return makeConn().query(sql, params); } },
};
require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: { pool: poolSpy, t: (name) => `fmb_${name}` },
};

const router = require('../../src/edge/routes/app/api-connectors');

let server; let base;
before(async () => {
  const app = express();
  app.use((req, _res, next) => { req.log = makeStubReqLog(); next(); }); // TEST-ONLY: production always sets req.log via createRequestId (request-id.js) before any router; this bare app has no such middleware, so a route's req.log.<level>() call would otherwise throw against undefined.
  app.use(express.json());
  app.use((req, _res, next) => {
    req.user = role === 'editor' ? { id: EDITOR_ID, role: 'editor' } : { id: ADMIN_ID, role: 'admin' };
    next();
  });
  app.use('/c', router);
  server = http.createServer(app);
  await new Promise((r) => server.listen(0, r));
  base = `http://127.0.0.1:${server.address().port}`;
});
after(() => server && server.close());

beforeEach(() => {
  role = 'admin';
  state = {
    queries: [],
    connSeq: 0,
    opLog: [],
    update: null,
    updateAffected: 1,
    reconcileDeletes: [],
    groupSyncDeletes: [],
    groupSyncInserts: [],
    groupSet: [],
    groupSetReads: 0,
    groupSetTx: undefined,
    extraBlueprintIds: [],
    enrichBindings: [],
    missingJoinTable: false,
    fieldKeysByBlueprint: new Map(),
    followerByBlueprint: new Map(),
    blueprintOwners: new Map(),
    storedRequestConfig: JSON.stringify({}),
    storedResponseConfig: JSON.stringify({ outputs: [{ id: 'o1', from: { mode: 'value', path: 'a' }, to: { mode: 'field', field_key: 'keyA' } }] }),
  };
});

async function put(body) {
  const res = await fetch(`${base}/c/${CONNECTOR_ID}`, {
    method: 'PUT', headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
  });
  return { status: res.status, json: await res.json() };
}

describe('api-connectors CRUD PUT — bindings completeness re-check', () => {
  it('a response_config save that would break an already-bound extra blueprint is rejected (400), the binding is not silently dropped', async () => {
    state.extraBlueprintIds = [EXTRA_BLUEPRINT_ID];
    state.fieldKeysByBlueprint = new Map([[EXTRA_BLUEPRINT_ID, ['keyA']]]);
    const { status, json } = await put({
      response_config: { outputs: [{ id: 'o1', from: { mode: 'value', path: 'a' }, to: { mode: 'field', field_key: 'keyB' } }] },
    });
    assert.equal(status, 400, `expected 400, got ${status}: ${JSON.stringify(json)}`);
    assert.equal(json.error.code, 'BINDING_FIELD_KEYS_MISSING');
    assert.equal(json.error.details.blueprint_id, EXTRA_BLUEPRINT_ID);
    assert.deepEqual(json.error.details.missing, ['keyB']);
    assert.equal(state.update, null, 'must not have written past the guard');
  });

  it('a response_config save that keeps every bound blueprint complete succeeds (200)', async () => {
    state.extraBlueprintIds = [EXTRA_BLUEPRINT_ID];
    state.fieldKeysByBlueprint = new Map([[EXTRA_BLUEPRINT_ID, ['keyA']]]);
    const { status, json } = await put({
      response_config: { outputs: [{ id: 'o1', from: { mode: 'value', path: 'a' }, to: { mode: 'field', field_key: 'keyA' } }] },
    });
    assert.equal(status, 200, `expected 200, got ${status}: ${JSON.stringify(json)}`);
    assert.ok(state.update, 'the compatible save must reach the UPDATE');
  });

  it('a request_config-only save that would break an already-bound extra blueprint is rejected (400)', async () => {
    state.extraBlueprintIds = [EXTRA_BLUEPRINT_ID];
    state.fieldKeysByBlueprint = new Map([[EXTRA_BLUEPRINT_ID, []]]);
    const { status, json } = await put({
      request_config: { input_mapping: { field_x: 'var1' } },
    });
    assert.equal(status, 400);
    assert.equal(json.error.code, 'BINDING_FIELD_KEYS_MISSING');
    assert.equal(state.update, null);
  });

  it('a connector with no join rows (no extra bindings) is unaffected by this guard (200)', async () => {
    state.extraBlueprintIds = [];
    const { status } = await put({
      response_config: { outputs: [{ id: 'o1', from: { mode: 'value', path: 'a' }, to: { mode: 'field', field_key: 'anything' } }] },
    });
    assert.equal(status, 200);
    assert.ok(state.update);
  });

  it('a name-only save (neither request_config nor response_config touched) never probes bindings, even with extras present', async () => {
    state.extraBlueprintIds = [EXTRA_BLUEPRINT_ID];
    state.fieldKeysByBlueprint = new Map([[EXTRA_BLUEPRINT_ID, []]]); // would fail completeness if checked
    const { status } = await put({ name: 'renamed' });
    assert.equal(status, 200);
    assert.equal(
      state.queries.some((q) => /SELECT blueprint_id FROM `fmb_api_connector_blueprints` WHERE connector_id = \?/.test(q.sql)),
      false,
      'the guard must not probe join rows when neither config half was touched',
    );
  });

  it('a response_config save targeting a follower column of an already-bound extra blueprint is rejected (400 BINDING_FOLLOWER_COLUMN)', async () => {
    state.extraBlueprintIds = [EXTRA_BLUEPRINT_ID];
    state.fieldKeysByBlueprint = new Map([[EXTRA_BLUEPRINT_ID, ['servers']]]); // complete, so the follower check is the sole failure
    // 'servers::site' is a follower (D2 mirror) column on the EXTRA blueprint
    // but not on the home — so the home follower guard passes and only the
    // per-extra write-guard follower check fires.
    state.followerByBlueprint = new Map([[EXTRA_BLUEPRINT_ID, [
      { field_key: 'servers', table_config: JSON.stringify({ columns: [{ key: 'site', linked_source: { field_key: 'sites', column_key: 'name' } }] }) },
    ]]]);
    const { status, json } = await put({
      response_config: { outputs: [{ id: 'o1', from: { mode: 'value', path: 'a' }, to: { mode: 'cell', table_key: 'servers', column_key: 'site' } }] },
    });
    assert.equal(status, 400, `expected 400, got ${status}: ${JSON.stringify(json)}`);
    assert.equal(json.error.code, 'BINDING_FOLLOWER_COLUMN');
    assert.equal(json.error.details.blueprint_id, EXTRA_BLUEPRINT_ID);
    assert.equal(state.update, null, 'must not have written past the guard');
  });

  it('a PUT response carries the connector bindings (enrichment runs on the write reply, not only on GET)', async () => {
    state.enrichBindings = ['bp-y', 'bp-x']; // returned sorted by the enrichment
    const { status, json } = await put({ name: 'renamed' });
    assert.equal(status, 200, `expected 200, got ${status}: ${JSON.stringify(json)}`);
    assert.deepEqual(json.data.bindings, ['bp-x', 'bp-y']);
  });

  it('a PUT response for an unbound connector carries bindings: []', async () => {
    state.enrichBindings = [];
    const { status, json } = await put({ name: 'renamed' });
    assert.equal(status, 200);
    assert.deepEqual(json.data.bindings, []);
  });

  it('a missing join table (no-DDL DB) degrades to "no bindings to re-check", never a 500', async () => {
    state.missingJoinTable = true;
    const { status } = await put({
      response_config: { outputs: [{ id: 'o1', from: { mode: 'value', path: 'a' }, to: { mode: 'field', field_key: 'anything' } }] },
    });
    assert.equal(status, 200, `expected 200, got ${status}`);
    assert.ok(state.update);
  });
});

describe('api-connectors CRUD PUT — home rebind reconciles its extra row inside the update transaction', () => {
  it('a home rebind to an existing extra deletes that connector\'s join row equal to the new home, AFTER the UPDATE, on the tx connection', async () => {
    const NEW_HOME = EXTRA_BLUEPRINT_ID;
    const { status } = await put({ blueprint_id: NEW_HOME });
    assert.equal(status, 200, `expected 200, got ${status}`);
    assert.equal(state.reconcileDeletes.length, 1);
    assert.deepEqual(state.reconcileDeletes[0], [CONNECTOR_ID, NEW_HOME]);
    assert.ok(state.update, 'the CRUD update still runs, then the reconcile');
    // The reconcile is an in-tx post-UPDATE hook: the DELETE must follow the
    // UPDATE and run on the SAME connection the UPDATE ran on.
    const updateOp = state.opLog.find((o) => o.op === 'update');
    const deleteOp = state.opLog.find((o) => o.op === 'reconcileDelete');
    assert.ok(updateOp && deleteOp, 'both the UPDATE and the reconcile DELETE ran');
    assert.ok(
      state.opLog.indexOf(updateOp) < state.opLog.indexOf(deleteOp),
      'the reconcile DELETE must run AFTER the ownership-scoped UPDATE',
    );
    assert.equal(deleteOp.connId, updateOp.connId, 'the reconcile DELETE must run on the update transaction connection');
  });

  it('there is no stored-vs-new compare: a PUT carrying blueprint_id equal to the current home still issues the reconcile DELETE keyed on that value', async () => {
    // After the UPDATE the home IS this value, so a join row equal to it is
    // invalid by the one-home invariant — deleting it is a safe no-op at the DB.
    const { status } = await put({ blueprint_id: HOME_BLUEPRINT_ID });
    assert.equal(status, 200);
    assert.equal(state.reconcileDeletes.length, 1);
    assert.deepEqual(state.reconcileDeletes[0], [CONNECTOR_ID, HOME_BLUEPRINT_ID]);
    assert.ok(state.update);
  });

  it('a PUT that does not carry blueprint_id never reconciles', async () => {
    const { status } = await put({ name: 'renamed' });
    assert.equal(status, 200);
    assert.equal(state.reconcileDeletes.length, 0);
  });

  it('a PUT the ownership-scoped UPDATE refuses (matches no row → 404) issues NO reconcile DELETE', async () => {
    // The exact cross-tenant data-loss shape: a refused update — a non-owner's
    // PUT among them — must delete nothing. The hook runs only after the scoped
    // UPDATE has matched a row.
    state.updateAffected = 0;
    const { status } = await put({ blueprint_id: EXTRA_BLUEPRINT_ID });
    assert.equal(status, 404, `expected 404, got ${status}`);
    assert.equal(state.reconcileDeletes.length, 0, 'a refused update must delete no join row');
  });

  it('a PUT the factory refuses for an invalid enum value (400) issues NO reconcile DELETE and no UPDATE', async () => {
    const { status, json } = await put({ blueprint_id: EXTRA_BLUEPRINT_ID, auth_type: 'Bearer' });
    assert.equal(status, 400, `expected 400, got ${status}: ${JSON.stringify(json)}`);
    assert.equal(state.reconcileDeletes.length, 0, 'a value the enum gate rejects must delete no join row');
    assert.equal(state.update, null, 'the enum gate must refuse before the UPDATE');
  });

  it('a home rebind on a DB missing the join table still commits the update (reconcile degrades to no-op)', async () => {
    state.missingJoinTable = true;
    const { status } = await put({ blueprint_id: EXTRA_BLUEPRINT_ID });
    assert.equal(status, 200, `expected 200, got ${status}`);
    assert.ok(state.update, 'the update must survive a missing join table during reconcile');
  });
});

describe('api-connectors CRUD PUT — clearing the home with extras present is refused', () => {
  it('a PUT setting blueprint_id: null on a connector with extras is refused (400 BINDING_HOME_BLUEPRINT), no UPDATE', async () => {
    state.extraBlueprintIds = [EXTRA_BLUEPRINT_ID];
    const { status, json } = await put({ blueprint_id: null });
    assert.equal(status, 400, `expected 400, got ${status}: ${JSON.stringify(json)}`);
    assert.equal(json.error.code, 'BINDING_HOME_BLUEPRINT');
    assert.equal(json.error.message, 'Remove the other blueprints before clearing the home blueprint.');
    assert.equal(state.update, null, 'the clear must be refused before the UPDATE');
    assert.equal(state.reconcileDeletes.length, 0);
  });

  it('a PUT setting blueprint_id: "" on a connector with extras is refused the same as null (400 BINDING_HOME_BLUEPRINT), no UPDATE', async () => {
    state.extraBlueprintIds = [EXTRA_BLUEPRINT_ID];
    const { status, json } = await put({ blueprint_id: '' });
    assert.equal(status, 400, `expected 400, got ${status}: ${JSON.stringify(json)}`);
    assert.equal(json.error.code, 'BINDING_HOME_BLUEPRINT');
    assert.equal(state.update, null, 'an empty-string clear must be refused before the UPDATE, same as null');
    assert.equal(state.reconcileDeletes.length, 0);
  });

  it('a PUT setting blueprint_id: null on a connector with no extras passes through (200)', async () => {
    state.extraBlueprintIds = [];
    const { status } = await put({ blueprint_id: null });
    assert.equal(status, 200, `expected 200, got ${status}`);
    assert.ok(state.update, 'clearing the home is allowed when nothing else is bound');
  });

  it('a null-home PUT on a DB missing the join table passes through (200)', async () => {
    state.missingJoinTable = true;
    const { status } = await put({ blueprint_id: null });
    assert.equal(status, 200, `expected 200, got ${status}`);
    assert.ok(state.update);
  });
});

describe('api-connectors CRUD PUT — joining a bundle validates then syncs the group set', () => {
  // A valid group PUT must carry group_id + group_mode + sequence (the
  // bundle-field guard rejects group_id alone), so every join body has all three.
  const joinBody = (over = {}) => ({ group_id: GROUP_ID, group_mode: 'aggregation', sequence: 1, ...over });

  it('a join whose group set contains a blueprint this connector would leave incomplete is refused (400 BINDING_FIELD_KEYS_MISSING), no UPDATE, no sync', async () => {
    state.groupSet = [GROUP_EXTRA_ID];
    // storedResponseConfig fills field_key 'keyA'; the group target lacks it.
    state.fieldKeysByBlueprint = new Map([[GROUP_EXTRA_ID, []]]);
    const { status, json } = await put(joinBody());
    assert.equal(status, 400, `expected 400, got ${status}: ${JSON.stringify(json)}`);
    assert.equal(json.error.code, 'BINDING_FIELD_KEYS_MISSING');
    assert.equal(json.error.details.blueprint_id, GROUP_EXTRA_ID);
    assert.equal(state.update, null, 'the join must be refused before the UPDATE');
    assert.equal(state.groupSyncDeletes.length, 0);
    assert.equal(state.groupSyncInserts.length, 0);
  });

  it('a valid join replaces this connector\'s set with the group set AFTER the UPDATE, on the tx connection', async () => {
    state.groupSet = [GROUP_EXTRA_ID];
    state.fieldKeysByBlueprint = new Map([[GROUP_EXTRA_ID, ['keyA']]]); // complete
    const { status } = await put(joinBody());
    assert.equal(status, 200);
    assert.ok(state.update, 'the UPDATE runs');
    assert.equal(state.groupSyncDeletes.length, 1);
    assert.deepEqual(state.groupSyncDeletes[0], [CONNECTOR_ID], 'the whole set is dropped first');
    assert.deepEqual(state.groupSyncInserts, [[CONNECTOR_ID, GROUP_EXTRA_ID]], 'then the group set is inserted');
    const u = state.opLog.find((o) => o.op === 'update');
    const d = state.opLog.find((o) => o.op === 'groupSyncDelete');
    const i = state.opLog.find((o) => o.op === 'groupSyncInsert');
    assert.ok(u && d && i, 'the UPDATE, the replace DELETE and the INSERT all ran');
    assert.ok(state.opLog.indexOf(u) < state.opLog.indexOf(d), 'the sync runs AFTER the ownership-scoped UPDATE');
    assert.ok(state.opLog.indexOf(d) < state.opLog.indexOf(i), 'the DELETE precedes the INSERT');
    assert.equal(d.connId, u.connId, 'the sync DELETE runs on the update transaction connection');
    assert.equal(i.connId, u.connId, 'the sync INSERT runs on the update transaction connection');
  });

  it('joining a group that has no extras clears this connector\'s own rows (empty set → just the DELETE)', async () => {
    state.groupSet = [];
    const { status } = await put(joinBody());
    assert.equal(status, 200);
    assert.ok(state.update);
    assert.equal(state.groupSyncDeletes.length, 1, 'own rows are cleared');
    assert.equal(state.groupSyncInserts.length, 0, 'nothing to insert for an empty group set');
  });

  it('a join the ownership-scoped UPDATE refuses (404) syncs nothing', async () => {
    state.groupSet = [GROUP_EXTRA_ID];
    state.fieldKeysByBlueprint = new Map([[GROUP_EXTRA_ID, ['keyA']]]); // complete → the pre-write guard passes
    state.updateAffected = 0;
    const { status } = await put(joinBody());
    assert.equal(status, 404, `expected 404, got ${status}`);
    assert.equal(state.groupSyncDeletes.length, 0, 'a refused update must sync no rows');
    assert.equal(state.groupSyncInserts.length, 0);
  });

  it('a join on a DB missing the join table still commits the update (guard + sync both degrade to no-op)', async () => {
    state.missingJoinTable = true;
    const { status } = await put(joinBody());
    assert.equal(status, 200, `expected 200, got ${status}`);
    assert.ok(state.update, 'the update survives a missing join table during the join guard + sync');
    assert.equal(state.groupSyncInserts.length, 0);
  });

  it('the group set changing between the read-only guard and the in-tx sync rolls back — nothing is synced', async () => {
    // The guard validates this connector against the group set it read
    // (GROUP_EXTRA_ID); before the in-tx sync another writer widens the group's
    // shared extras. Syncing that later, unvalidated set is the
    // wider-set-than-the-gate-approved defect — so the in-tx re-read detects the
    // drift and throws, rolling the whole update back: no INSERT, no DELETE.
    state.groupSet = [GROUP_EXTRA_ID];
    state.fieldKeysByBlueprint = new Map([[GROUP_EXTRA_ID, ['keyA']]]); // complete → the guard passes
    state.groupSetTx = [GROUP_EXTRA_ID, EXTRA_BLUEPRINT_ID]; // the in-tx read sees a wider set
    const { status } = await put(joinBody());
    assert.equal(status, 500, `expected 500 (the factory does not preserve the thrown status), got ${status}`);
    assert.equal(state.groupSyncInserts.length, 0, 'a drifted group set must sync no rows');
    assert.equal(state.groupSyncDeletes.length, 0, 'the refusal precedes the replace DELETE');
  });

  it('an EDITOR joining a bundle whose shared extra set contains a blueprint owned by a DIFFERENT user is refused (403 FORBIDDEN naming that blueprint), no UPDATE, no join-table write', async () => {
    role = 'editor';
    state.connectorOwnerId = EDITOR_ID; // the editor owns the connector row being edited
    state.groupSet = [GROUP_EXTRA_ID];
    // Complete against storedResponseConfig's 'keyA', so authority is the sole
    // failure — the completeness check must not fire first and mask it.
    state.fieldKeysByBlueprint = new Map([[GROUP_EXTRA_ID, ['keyA']]]);
    state.blueprintOwners = new Map([[GROUP_EXTRA_ID, FOREIGN_OWNER_ID]]);
    const { status, json } = await put(joinBody());
    assert.equal(status, 403, `expected 403, got ${status}: ${JSON.stringify(json)}`);
    assert.equal(json.error.code, 'FORBIDDEN');
    assert.equal(json.error.details.blueprint_id, GROUP_EXTRA_ID);
    assert.equal(state.update, null, 'the join must be refused before the UPDATE');
    assert.equal(state.groupSyncDeletes.length, 0, 'no join-table write on a foreign-owned extra');
    assert.equal(state.groupSyncInserts.length, 0);
  });

  it('an EDITOR joining a bundle whose shared extra set contains a blueprint they own (case-different id, sameStoredId) succeeds (200) and the sync runs', async () => {
    role = 'editor';
    state.connectorOwnerId = EDITOR_ID; // the editor owns the connector row being edited
    state.groupSet = [GROUP_EXTRA_ID];
    state.fieldKeysByBlueprint = new Map([[GROUP_EXTRA_ID, ['keyA']]]); // complete
    state.blueprintOwners = new Map([[GROUP_EXTRA_ID, EDITOR_ID.toUpperCase()]]); // same id, different case
    const { status, json } = await put(joinBody());
    assert.equal(status, 200, `expected 200, got ${status}: ${JSON.stringify(json)}`);
    assert.ok(state.update, 'the UPDATE runs');
    assert.equal(state.groupSyncDeletes.length, 1, 'the whole set is dropped first');
    assert.deepEqual(state.groupSyncInserts, [[CONNECTOR_ID, GROUP_EXTRA_ID]], 'then the group set is inserted');
  });
});
