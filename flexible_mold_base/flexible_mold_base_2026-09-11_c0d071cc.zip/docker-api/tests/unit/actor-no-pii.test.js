'use strict';

/**
 * actor-no-pii.test.js — proves "email never reaches a log line" through the
 * FULL path: a real pino child (the same options the production logger
 * uses, via `_internals.loggerOptions`) + setBindings({actor}) + a served
 * line, not just the pure toActor() unit.
 *
 * Two branches:
 *  1. Defensive @-cut — a name source that happens to be shaped like an
 *     email (spec §12: Keycloak's real username is confirmed NOT an email,
 *     so this is a backstop, not the normal case) is truncated at the `@`.
 *  2. Corrected contract (owner decision, PR-2a dispatch) — when the ONLY
 *     available field is `email` (no kc_username/username), `name` is
 *     undefined. `toActor` never falls back to `email` for the name.
 * Both must never emit an `@` character or an `email` key anywhere in the
 * served record.
 */
const { test } = require('node:test');
const assert = require('node:assert/strict');
const { Writable } = require('node:stream');
const pino = require('pino');
const { _internals } = require('../../src/shared/lib/logger');
const { toActor } = require('../../src/shared/lib/actor');

function captureLine(fn) {
  let captured = '';
  const sink = new Writable({ write(chunk, _e, cb) { captured += chunk.toString(); cb(); } });
  const log = pino(_internals.loggerOptions, sink).child({ req_id: 'abcd1234' });
  fn(log);
  return JSON.parse(captured);
}

test('defensive @-cut: a name source shaped like an email is truncated before it ever reaches setBindings', () => {
  const actor = toActor({ id: 'u-1', kc_username: 'weird@corp' });
  const record = captureLine((log) => {
    log.setBindings({ actor });
    log.info({ kind: 'access' }, 'GET /api/x 200 5ms');
  });
  assert.equal(record.actor.name, 'weird');
  assert.equal('email' in record.actor, false);
  assert.ok(!JSON.stringify(record).includes('@'), 'no @ anywhere in the served record');
});

test('email-only user (no kc_username/username): name is undefined, never falls back to email', () => {
  const actor = toActor({ id: 'u-2', email: 'a@corp' });
  const record = captureLine((log) => {
    log.setBindings({ actor });
    log.info({ kind: 'access' }, 'GET /api/y 200 5ms');
  });
  assert.equal('name' in record.actor, false, 'name key absent (undefined is dropped by JSON serialisation)');
  assert.equal('email' in record.actor, false);
  assert.ok(!JSON.stringify(record).includes('@'), 'no @ anywhere in the served record');
  assert.ok(!JSON.stringify(record).includes('a@corp'), 'the email value itself never appears');
});

test('no actor bound at all (unauthenticated request): no actor key on the record', () => {
  const record = captureLine((log) => {
    log.info({ kind: 'access' }, 'GET /api/z 401 2ms');
  });
  assert.equal('actor' in record, false);
});
