// api-connectors-bindings.test.js — mounts the real bindings route on a bare
// express app with a stub db module, exercising the authority matrix and every
// error code without a live DB. Mock style mirrors api-connectors-approval:
// a single conn double whose query() branches on the SQL text;
// beginTransaction/commit/rollback are no-ops so the transaction the route
// opens is transparent.
const { describe, it, beforeEach, afterEach } = require('node:test');
const { makeStubReqLog } = require('../helpers/stub-req-log');
const assert = require('node:assert/strict');
const http = require('node:http');
const express = require('express');

const dbKey = require.resolve('../../src/edge/db');

// Fixture state the conn double reads.
let connectorRow;          // the target connector row (home blueprint = 'home')
let knownBlueprints;       // Set of existing blueprint ids
let fieldKeysByBlueprint;  // Map<blueprintId, string[]>
let blueprintOwners;       // Map<blueprintId, owner_id|null>
let followerRows;          // rows for the follower-column probe (usually [])
let nodeTypeById;          // Map<nodeId, node_type> — default 'blueprint'
let groupMembers;          // rows for the group-coherence read
let groupExtras;           // join rows for the group-coherence SIBLING extras
let reflectInserts;        // when true, the extras read reflects c1's just-inserted rows
let missingJoinTable;      // when true, the join-table DELETE/INSERT raises errno 1146
let inserted; let deleted;

const conn = {
  async query(sql, params) {
    if (/FROM `fmb_api_connectors` WHERE id = \?/.test(sql) && /SELECT \*/.test(sql)) {
      return connectorRow ? [connectorRow] : [];
    }
    // \s+ (not a literal space) bridges checkBlueprintWriteTarget's multi-line
    // form (the home-blueprint authority check, shared with every other
    // blueprint-subtree write) as well as the older single-line shape.
    if (/SELECT owner_id FROM `fmb_hierarchy_nodes`\s+WHERE id = \?/.test(sql)) {
      const id = params[0];
      if (!knownBlueprints.has(id)) return [];
      // checkBlueprintWriteTarget additionally constrains node_type='blueprint'.
      if (/node_type = 'blueprint'/.test(sql) && (nodeTypeById.get(id) || 'blueprint') !== 'blueprint') return [];
      return [{ owner_id: blueprintOwners.get(id) ?? null }];
    }
    if (/FROM `fmb_delegated_grants`|information_schema\.TABLES/.test(sql)) {
      // No grants-table fixture in this file — every scenario here is decided
      // by ownership alone, matching the pre-grant behaviour this suite pins.
      return [];
    }
    if (/SELECT id, owner_id FROM `fmb_hierarchy_nodes` WHERE id IN/.test(sql)) {
      // The route constrains node_type = 'blueprint' (bound as the last param).
      // Honour it exactly as the DB would: a node that exists but is not a
      // blueprint is excluded, so the route reports it as an unknown blueprint.
      const wantType = /node_type = \?/.test(sql) ? params[params.length - 1] : null;
      const ids = wantType ? params.slice(0, -1) : params;
      return ids
        .filter((id) => knownBlueprints.has(id) && (!wantType || (nodeTypeById.get(id) || 'blueprint') === wantType))
        .map((id) => ({ id, owner_id: blueprintOwners.get(id) ?? null }));
    }
    if (/SELECT blueprint_id, field_key FROM `fmb_blueprint_fields`/.test(sql)) {
      const out = [];
      for (const id of params) for (const k of fieldKeysByBlueprint.get(id) || []) out.push({ blueprint_id: id, field_key: k });
      return out;
    }
    if (/SELECT field_key, table_config FROM `fmb_blueprint_fields`/.test(sql)) return followerRows;
    if (/SELECT output_keys FROM `fmb_transformers` WHERE id = \?/.test(sql)) return [];
    // The group member load (full rows, mapped) and the defensive post-write
    // coherence re-read (id/name/blueprint_id only) both return the member set.
    // Both the member load and the coherence re-read now filter by
    // group_id AND blueprint_id (the home), so honour params[1] when present —
    // a foreign-blueprint sibling sharing the group_id must NOT be returned.
    if (/SELECT \* FROM `fmb_api_connectors` WHERE group_id = \?/.test(sql)
      || /SELECT id, name, blueprint_id FROM `fmb_api_connectors` WHERE group_id = \?/.test(sql)) {
      return params[1] !== undefined ? groupMembers.filter((m) => m.blueprint_id === params[1]) : groupMembers;
    }
    if (/SELECT connector_id, blueprint_id FROM `fmb_api_connector_blueprints`/.test(sql)) {
      // Faithful to a real DB: the group write DELETE+INSERTs every member, so
      // the coherence read that runs after it sees exactly the rows just
      // inserted for all members.
      return reflectInserts ? inserted.map((pr) => ({ connector_id: pr[0], blueprint_id: pr[1] })) : groupExtras;
    }
    if (/DELETE FROM `fmb_api_connector_blueprints`/.test(sql)) {
      if (missingJoinTable) throw Object.assign(new Error("Table 'fmb_api_connector_blueprints' doesn't exist"), { errno: 1146, code: 'ER_NO_SUCH_TABLE' });
      deleted.push(params); return { affectedRows: 1 };
    }
    if (/INSERT INTO `fmb_api_connector_blueprints`/.test(sql)) {
      if (missingJoinTable) throw Object.assign(new Error("Table 'fmb_api_connector_blueprints' doesn't exist"), { errno: 1146, code: 'ER_NO_SUCH_TABLE' });
      inserted.push(params); return { affectedRows: 1 };
    }
    return [];
  },
  async beginTransaction() {}, async commit() {}, async rollback() {}, release() {},
};
// failAcquire lets a test drive a connection-acquire rejection: the route now
// resolves the pool + acquires the connection INSIDE its try, so this must
// surface as a 500, not an unhandled rejection that kills the process.
let failAcquire = false;
const rwFacade = {
  query: (sql, params) => conn.query(sql, params),
  getConnection: async () => { if (failAcquire) throw new Error('pool acquire failed'); return conn; },
};

require.cache[dbKey] = {
  id: dbKey, filename: dbKey, loaded: true,
  exports: {
    pool: { rw: rwFacade, ro: { getConnection: async () => conn } },
    t: (n) => `fmb_${n}`,
  },
};
// resolveRwPool → rwFacade (the request-pool resolver reads the db module).
const rpKey = require.resolve('../../src/edge/routes/app/schema/request-pool');
require.cache[rpKey] = {
  id: rpKey, filename: rpKey, loaded: true,
  exports: { resolveRwPool: async () => rwFacade, resolveRoPool: async () => rwFacade },
};

const register = require('../../src/edge/routes/app/api-connectors/bindings');

function appAs(user) {
  const app = express();
  app.use((req, _res, next) => { req.log = makeStubReqLog(); next(); }); // TEST-ONLY: production always sets req.log via createRequestId (request-id.js) before any router; this bare app has no such middleware, so a route's req.log.<level>() call would otherwise throw against undefined.
  app.use(express.json());
  app.use((req, _res, next) => { req.user = user; next(); });
  const router = express.Router();
  register(router);
  app.use('/api-connectors', router);
  return app;
}
const ADMIN = { id: 'admin1', role: 'admin' };
const OWNER = { id: 'ed1', role: 'editor' };
const OTHER = { id: 'ed2', role: 'editor' };

// Every listener opened here is tracked and swept in afterEach — a raw
// success-path-only close leaves the handle open when a later assertion in
// the same test throws, and the runner hangs on the open handle instead of
// reporting the failure.
const openServers = [];

function put(app, id, body) {
  return new Promise((resolve) => {
    const server = app.listen(0, () => {
      openServers.push(server);
      const { port } = server.address();
      const payload = JSON.stringify(body);
      const req = http.request({ port, path: `/api-connectors/${id}/bindings`, method: 'PUT',
        headers: { 'content-type': 'application/json', 'content-length': Buffer.byteLength(payload) } },
        (res) => { let d = ''; res.on('data', (c) => { d += c; }); res.on('end', () => { server.close(); resolve({ status: res.statusCode, body: JSON.parse(d || '{}') }); }); });
      req.end(payload);
    });
  });
}

afterEach(() => {
  while (openServers.length) {
    const server = openServers.pop();
    if (server.listening) server.close();
  }
});

beforeEach(() => {
  connectorRow = { id: 'c1', owner_id: 'ed1', blueprint_id: 'home', group_id: null,
    request_config: {}, response_config: { outputs: [{ to: { mode: 'field', field_key: 'total' } }] } };
  knownBlueprints = new Set(['home', 'b2', 'b3']);
  nodeTypeById = new Map();
  fieldKeysByBlueprint = new Map([['home', ['total']], ['b2', ['total']], ['b3', []]]);
  blueprintOwners = new Map([['home', 'ed1'], ['b2', null], ['b3', 'ed2']]);
  followerRows = [];
  groupMembers = [];
  groupExtras = [];
  reflectInserts = true;
  missingJoinTable = false;
  failAcquire = false;
  inserted = []; deleted = [];
});

describe('PUT /api-connectors/:id/bindings — authority', () => {
  it('admin may bind any existing blueprint', async () => {
    const r = await put(appAs(ADMIN), 'c1', { blueprint_ids: ['b2'] });
    assert.equal(r.status, 200);
    assert.deepEqual(r.body.data.bindings, ['b2']);
  });

  it('the owning editor may bind a shared blueprint (owner null)', async () => {
    assert.equal((await put(appAs(OWNER), 'c1', { blueprint_ids: ['b2'] })).status, 200);
  });

  it('a non-owning editor is refused (403)', async () => {
    const r = await put(appAs(OTHER), 'c1', { blueprint_ids: ['b2'] });
    assert.equal(r.status, 403);
  });

  it('an editor may not bind a blueprint owned by someone else (403)', async () => {
    // b3 is owned by ed2; OWNER (ed1) owns the connector but not b3.
    fieldKeysByBlueprint.set('b3', ['total']); // make it complete so authority is the sole failure
    const r = await put(appAs(OWNER), 'c1', { blueprint_ids: ['b3'] });
    assert.equal(r.status, 403);
  });

  it('an editor whose home blueprint was reassigned away is refused (403)', async () => {
    // OWNER still owns the connector row, but the home blueprint now belongs to
    // ed2 — the exec-authority CONJUNCTION denies (own connector AND home).
    blueprintOwners.set('home', 'ed2');
    const r = await put(appAs(OWNER), 'c1', { blueprint_ids: ['b2'] });
    assert.equal(r.status, 403);
  });

  it('admin is unaffected by home-blueprint ownership', async () => {
    blueprintOwners.set('home', 'ed2');
    const r = await put(appAs(ADMIN), 'c1', { blueprint_ids: ['b2'] });
    assert.equal(r.status, 200);
  });
});

describe('PUT /api-connectors/:id/bindings — validation', () => {
  it('rejects the home blueprint in the list (BINDING_HOME_BLUEPRINT)', async () => {
    const r = await put(appAs(ADMIN), 'c1', { blueprint_ids: ['home'] });
    assert.equal(r.status, 400);
    assert.equal(r.body.error.code, 'BINDING_HOME_BLUEPRINT');
  });

  it('rejects an unknown blueprint id (BINDING_BLUEPRINT_UNKNOWN)', async () => {
    const r = await put(appAs(ADMIN), 'c1', { blueprint_ids: ['ghost'] });
    assert.equal(r.status, 400);
    assert.equal(r.body.error.code, 'BINDING_BLUEPRINT_UNKNOWN');
  });

  it('rejects a target that exists but is not a blueprint node — a category id (BINDING_BLUEPRINT_UNKNOWN)', async () => {
    // 'cat1' exists in the hierarchy but is a category, not a blueprint; the
    // node_type='blueprint' constraint excludes it, so it is an unknown target.
    knownBlueprints.add('cat1');
    nodeTypeById.set('cat1', 'category');
    const r = await put(appAs(ADMIN), 'c1', { blueprint_ids: ['cat1'] });
    assert.equal(r.status, 400);
    assert.equal(r.body.error.code, 'BINDING_BLUEPRINT_UNKNOWN');
    assert.equal(r.body.error.details.blueprint_id, 'cat1');
  });

  it('rejects a blueprint missing a response-side field_key (BINDING_FIELD_KEYS_MISSING) with details', async () => {
    const r = await put(appAs(ADMIN), 'c1', { blueprint_ids: ['b3'] });
    assert.equal(r.status, 400);
    assert.equal(r.body.error.code, 'BINDING_FIELD_KEYS_MISSING');
    assert.equal(r.body.error.details.blueprint_id, 'b3');
    assert.deepEqual(r.body.error.details.missing, ['total']);
  });

  it('rejects a blueprint missing a request-side field_key (BINDING_FIELD_KEYS_MISSING)', async () => {
    // b2 has the response key 'total' but not the request-side 'qty'
    // (an input_mapping key). Only the set-difference half catches this.
    connectorRow.request_config = { input_mapping: { qty: '{{q}}' } };
    const r = await put(appAs(ADMIN), 'c1', { blueprint_ids: ['b2'] });
    assert.equal(r.status, 400);
    assert.equal(r.body.error.code, 'BINDING_FIELD_KEYS_MISSING');
    assert.equal(r.body.error.details.blueprint_id, 'b2');
    assert.deepEqual(r.body.error.details.missing, ['qty']);
  });

  it('replaces the whole set and returns the sorted extras', async () => {
    const r = await put(appAs(ADMIN), 'c1', { blueprint_ids: ['b2'] });
    assert.equal(r.status, 200);
    assert.deepEqual(r.body.data.bindings, ['b2']);
    assert.equal(deleted.length, 1); // old set cleared first
    assert.equal(inserted.length, 1);
  });

  it('accepts an empty list and clears all extras', async () => {
    const r = await put(appAs(ADMIN), 'c1', { blueprint_ids: [] });
    assert.equal(r.status, 200);
    assert.deepEqual(r.body.data.bindings, []);
    assert.equal(deleted.length, 1);
    assert.equal(inserted.length, 0);
  });

  it('rejects an output targeting a follower column (BINDING_FOLLOWER_COLUMN) with the offending keys', async () => {
    // The connector writes items::price; that column mirrors another table (D2
    // follower), so it is off-limits as a connector target in every blueprint.
    connectorRow.response_config = { outputs: [{ to: { mode: 'cell', table_key: 'items', column_key: 'price' } }] };
    fieldKeysByBlueprint.set('b2', ['items']); // completeness passes so the follower guard is the sole failure
    followerRows = [{ field_key: 'items', table_config: JSON.stringify({ columns: [{ key: 'price', linked_source: { table_key: 'x' } }] }) }];
    const r = await put(appAs(ADMIN), 'c1', { blueprint_ids: ['b2'] });
    assert.equal(r.status, 400);
    assert.equal(r.body.error.code, 'BINDING_FOLLOWER_COLUMN');
    assert.equal(r.body.error.details.blueprint_id, 'b2');
    assert.deepEqual(r.body.error.details.follower_columns, ['items::price']);
  });
});

describe('PUT /api-connectors/:id/bindings — bundle (group) writes', () => {
  // Every member of a bundle shares one home blueprint and one usable-in set,
  // so a PUT on any member replaces the extra set for ALL of them in one
  // transaction. A member row carries the config the completeness check reads.
  const member = (id, extra) => ({
    id, name: id.toUpperCase(), blueprint_id: 'home', group_id: 'g1', owner_id: 'ed1',
    request_config: {}, response_config: { outputs: [{ to: { mode: 'field', field_key: extra || 'total' } }] },
  });

  it('applies the set to every member of the bundle in one transaction', async () => {
    connectorRow.group_id = 'g1';
    groupMembers = [member('c1'), member('c2')];
    const r = await put(appAs(ADMIN), 'c1', { blueprint_ids: ['b2'] });
    assert.equal(r.status, 200);
    assert.deepEqual(r.body.data.bindings, ['b2']);
    assert.deepEqual(r.body.data.group_members, [
      { connector_id: 'c1', bindings: ['b2'] },
      { connector_id: 'c2', bindings: ['b2'] },
    ]);
    // Each member had its old set cleared and the new one inserted.
    assert.equal(deleted.length, 2);
    assert.equal(inserted.length, 2);
  });

  it('a member incomplete for a target names the member and applies nothing', async () => {
    connectorRow.group_id = 'g1';
    // c2 fills a field b2 does not have; c1 is complete against b2.
    groupMembers = [member('c1'), member('c2', 'only_c2')];
    const r = await put(appAs(ADMIN), 'c1', { blueprint_ids: ['b2'] });
    assert.equal(r.status, 400);
    assert.equal(r.body.error.code, 'BINDING_FIELD_KEYS_MISSING');
    assert.equal(r.body.error.details.member_id, 'c2');
    assert.deepEqual(r.body.error.details.missing, ['only_c2']);
    // The refusal is before the transaction — nothing was written.
    assert.equal(deleted.length, 0);
    assert.equal(inserted.length, 0);
  });

  it('an editor who does not own a sibling member is refused (403) naming it', async () => {
    connectorRow.group_id = 'g1';
    const c2 = member('c2'); c2.owner_id = 'ed2'; // owned by another editor
    groupMembers = [member('c1'), c2];
    const r = await put(appAs(OWNER), 'c1', { blueprint_ids: ['b2'] });
    assert.equal(r.status, 403);
    assert.equal(r.body.error.details.member_id, 'c2');
    assert.equal(deleted.length, 0);
  });

  it('the coherent group write depends on the read seeing the just-inserted rows', async () => {
    // Regression guard: with the coherence read NOT reflecting the group write,
    // the members resolve to different sets and the defensive invariant fires
    // (a 500-class refusal). Proves the happy path is not a static-stub artifact.
    reflectInserts = false;
    connectorRow.group_id = 'g1';
    groupMembers = [member('c1'), member('c2')];
    groupExtras = [{ connector_id: 'c2', blueprint_id: 'b3' }]; // stale, divergent view
    const r = await put(appAs(ADMIN), 'c1', { blueprint_ids: ['b2'] });
    assert.equal(r.status, 500);
    assert.equal(r.body.error.code, 'BINDING_GROUP_MISMATCH');
  });
});

describe('PUT /api-connectors/:id/bindings — robustness', () => {
  it('a connection-acquire rejection becomes a 500, not an unhandled rejection', async () => {
    failAcquire = true;
    const r = await put(appAs(ADMIN), 'c1', { blueprint_ids: ['b2'] });
    assert.equal(r.status, 500);
  });

  it('rejects a blueprint_ids list longer than the cap (400)', async () => {
    const many = Array.from({ length: 65 }, (_, i) => `bp${i}`);
    const r = await put(appAs(ADMIN), 'c1', { blueprint_ids: many });
    assert.equal(r.status, 400);
    assert.equal(r.body.error.code, 'BAD_REQUEST');
  });
});

describe('PUT /api-connectors/:id/bindings — missing join table (no-DDL DB)', () => {
  it('a non-empty set on a DB missing the join table returns 409 BINDING_TABLE_MISSING', async () => {
    missingJoinTable = true;
    const r = await put(appAs(ADMIN), 'c1', { blueprint_ids: ['b2'] });
    assert.equal(r.status, 409);
    assert.equal(r.body.error.code, 'BINDING_TABLE_MISSING');
  });

  it('an empty set (a clear) on a DB missing the join table returns 200 with bindings: []', async () => {
    missingJoinTable = true;
    const r = await put(appAs(ADMIN), 'c1', { blueprint_ids: [] });
    assert.equal(r.status, 200);
    assert.deepEqual(r.body.data.bindings, []);
  });
});

describe('PUT /api-connectors/:id/bindings — home blueprint scopes the bundle', () => {
  it('a sibling sharing the group_id on a DIFFERENT blueprint is left untouched', async () => {
    connectorRow.group_id = 'g1';
    // c2 shares g1 but sits on another blueprint (an imported copy) — it must
    // NOT be dragged into this bundle's write.
    const foreign = { id: 'c2', name: 'C2', blueprint_id: 'other', group_id: 'g1', owner_id: 'ed1',
      request_config: {}, response_config: { outputs: [{ to: { mode: 'field', field_key: 'total' } }] } };
    const self = { id: 'c1', name: 'C1', blueprint_id: 'home', group_id: 'g1', owner_id: 'ed1',
      request_config: {}, response_config: { outputs: [{ to: { mode: 'field', field_key: 'total' } }] } };
    groupMembers = [self, foreign];
    const r = await put(appAs(ADMIN), 'c1', { blueprint_ids: ['b2'] });
    assert.equal(r.status, 200);
    // Only c1 (the home member) was written; the foreign-blueprint sibling was not.
    assert.equal(deleted.length, 1);
    assert.deepEqual(deleted[0], ['c1']);
    assert.ok(inserted.every((pr) => pr[0] === 'c1'));
  });
});

describe('PUT /api-connectors/:id/bindings — extras require a home', () => {
  it('a non-empty set on a NULL-home connector is refused (400 BINDING_HOME_BLUEPRINT)', async () => {
    connectorRow.blueprint_id = null;
    const r = await put(appAs(ADMIN), 'c1', { blueprint_ids: ['b2'] });
    assert.equal(r.status, 400);
    assert.equal(r.body.error.code, 'BINDING_HOME_BLUEPRINT');
    assert.equal(deleted.length, 0);
    assert.equal(inserted.length, 0);
  });

  it('an empty set on a NULL-home connector clears and returns 200', async () => {
    connectorRow.blueprint_id = null;
    const r = await put(appAs(ADMIN), 'c1', { blueprint_ids: [] });
    assert.equal(r.status, 200);
    assert.deepEqual(r.body.data.bindings, []);
    assert.equal(deleted.length, 1);
    assert.equal(inserted.length, 0);
  });
});

describe('bindingSignature — order-insensitive coherence key', () => {
  const { bindingSignature } = require('../../src/edge/routes/app/api-connectors/bindings');
  it('is symmetric across which blueprint is the home', () => {
    assert.equal(bindingSignature('X', new Set(['Y'])), bindingSignature('Y', new Set(['X'])));
  });
  it('is independent of extra order', () => {
    assert.equal(bindingSignature('home', ['b2', 'b3']), bindingSignature('home', ['b3', 'b2']));
  });
});
