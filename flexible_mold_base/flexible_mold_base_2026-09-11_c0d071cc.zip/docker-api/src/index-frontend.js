/**
 * index-frontend.js — Static frontend entry point.
 *
 * Role: serve the compiled SPA from dist/ on port 3000 and expose a tiny
 * `GET /config.js` endpoint so the SPA can discover the API origin at
 * runtime (k8s two-VirtualService deployment where FRONTEND_HOST and
 * API_HOST differ).
 *
 * Deliberately minimal: no CORS (same-origin static only), no CSRF guard
 * (no mutating endpoints), no auth middleware, no edge forwarding,
 * no rate limiters, no OIDC. That work stays in API_ROLE=infra.
 *
 * Architecture:
 *   Browser → Istio Gateway → fmb-frontend:3000 (index.html + /config.js + assets)
 *                           → fmb-infra:3200    (API)
 *
 * CSP/XSS contract for /config.js:
 *   - API_BASE is validated in config-schema as absolute http(s) URL or ''
 *   - Response body is `window.__API_BASE__ = ${JSON.stringify(API_BASE)};`
 *     which guarantees proper string escaping even if the URL somehow
 *     contains a `</script>` sequence (JSON.stringify escapes `<` when
 *     wrapped — we also explicitly replace `<` → `\u003c` for defence
 *     in depth).
 *   - Content-Type: application/javascript; charset=utf-8
 *   - Cache-Control: no-store (config must be fresh on reload)
 */
require('dotenv').config();

const path = require('path');
const express = require('express');
const helmet = require('helmet');
const { logger: rootLogger } = require('./shared/lib/logger');
const { logAppError } = require('./shared/lib/send-error');
const { bootLine, sysLog } = require('./shared/lib/log-streams');
const {
  resolveApiBase,
  getAllowlistDiagnostics,
} = require('./shared/lib/resolve-api-base');
const { printBootBanner } = require('./shared/lib/boot-banner');
const { SANDBOX_HTML } = require('./shared/sandbox-document.cjs');
const { createRequestId } = require('./shared/middleware/request-id');
const { createRequestLog } = require('./shared/middleware/request-log');
const { installProcessTraps } = require('./shared/lib/install-process-traps');

const logger = rootLogger.child({ module: 'api-frontend' });

// Process-level safety net: a rejected promise nobody awaited or a throw
// that escaped every try/catch logs one fatal/kind:sys line then exits(1)
// so k8s restarts the pod. Does not touch SIGTERM/SIGINT — those are
// registered below by this same file.
installProcessTraps(logger);

const PORT = Number(process.env.PORT ?? 3000);
// NOTE: `API_BASE` env is rejected by config-schema; new deployments must use
// `API_BASE_ALLOWLIST` (ConfigMap multi-line env) — see ENV_PLACEMENT.md.
const API_BASE = process.env.API_BASE ?? '';
// NOTE: APP_NAME is a boot seed from ConfigMap env; runtime source of truth is
// `system_settings.app_name` (DB row via `useSystemSettings`). The SPA uses
// this seed during the initial paint before the hook resolves — it is NOT the
// final displayed value once settings load.
const APP_NAME = process.env.APP_NAME ?? '';
// ZONE_ENV is a per-zone, user-facing environment label surfaced to the SPA
// via /config.js. It is deliberately separate from NODE_ENV (security/debug
// posture, which is `production` in every zone). Only the exact value `test`
// (case-insensitive) marks a test zone; anything else coerces to `production`
// so a missing/typo'd value can never mis-mark a real production zone.
const ZONE_ENV =
  String(process.env.ZONE_ENV || '').trim().toLowerCase() === 'test'
    ? 'test'
    : 'production';
const DIST_PATH = path.join(__dirname, '..', 'dist');
const IS_PRODUCTION = process.env.NODE_ENV === 'production';

if (process.env.API_BASE !== undefined && process.env.API_BASE !== '') {
  // SECURITY: redact value rather than emit verbatim — a misconfigured API_BASE
  // with `user:pass@host` userinfo would otherwise leak credentials into
  // operator log aggregation pipelines. Operators inspecting pod env can still
  // see the raw value; the log only confirms presence + remediation path.
  // NOTE: config-schema validateConfig() rejects this env via frontendSchema
  // superRefine. This WARN only fires in SKIP_CONFIG_VALIDATION=1 dev paths.
  logger.warn(
    {
      apiBase: '[set — value redacted; inspect pod env for content]',
      remediation:
        'move to API_BASE_ALLOWLIST (multi-line ConfigMap env); see infrastructure/docs/ENV_PLACEMENT.md',
    },
    '[REJECTED in v3.2.51] API_BASE env is no longer accepted. SKIP_CONFIG_VALIDATION=1 kept this pod alive; config-schema will reject on next validated boot.',
  );
}

// NOTE: surface allowlist parse warnings (if any) at boot so operators notice
// a bad ConfigMap line without grepping tail logs later.
const _ALLOWLIST_DIAG = getAllowlistDiagnostics();
if (_ALLOWLIST_DIAG.warnings.length > 0) {
  for (const w of _ALLOWLIST_DIAG.warnings) {
    logger.warn({ module: 'api-base-allowlist' }, `[API_BASE_ALLOWLIST] ${w}`);
  }
  logger.warn(
    { entryCount: _ALLOWLIST_DIAG.entryCount },
    '[API_BASE_ALLOWLIST] parse had warnings — verify env; falling back to usable entries.',
  );
}

// Dev-only escape hatch: when NODE_ENV !== 'production' the SPA may set
// `localStorage.fmb_api_base_override` to redirect API calls to a custom URL
// (e.g. point the prod-baked frontend at a local docker-api). Stripped from
// the response body in production to keep the contract narrow.
//
// SECURITY: strict allowlist regex on the localStorage value before it
// reaches window.__API_BASE__. Even though this snippet ships only when
// NODE_ENV !== 'production', a dev with a malicious browser extension that
// pokes localStorage could otherwise redirect every API call to an
// attacker-controlled origin. The regex accepts only `http(s)://host[:port]`
// (no path, query, fragment, or userinfo) — anything richer is rejected and
// logged in the browser console so the dev sees the rejection instead of
// silently inheriting a default-empty base.
// `fmb_api_base_override` is a stable localStorage key for browser dev-tools
// API base overrides — not a DB table prefix.
// Renaming would silently break existing dev workflows.
const LOCALSTORAGE_OVERRIDE_SNIPPET =
  '\ntry {' +
  ' var __o = localStorage.getItem("fmb_api_base_override");' + // lint-allow: no-hardcoded-prefix localStorage key, not table prefix
  ' if (__o) {' +
  '  if (/^https?:\\/\\/[a-zA-Z0-9.-]+(?::\\d{1,5})?$/.test(__o)) {' +
  '   window.__API_BASE__ = __o;' +
  '  } else {' +
  '   console.warn("[config.js] fmb_api_base_override rejected — must match http(s)://host[:port] (no path/query/userinfo).", __o);' + // lint-allow: no-hardcoded-prefix localStorage key, not table prefix
  '  }' +
  ' }' +
  '} catch (_) {}\n';

const app = express();

app.set('trust proxy', Number(process.env.TRUST_PROXY ?? 1));

// Strict helmet — static assets only, no inline script needed because
// /config.js is a separate external resource.
//
// SECURITY: the main app document forbids eval. Transformer code (the only
// new Function() consumer) runs in a null-origin sandbox iframe served at
// /sandbox.html with its own route-scoped relaxed CSP, so 'unsafe-eval' and
// blob: workers never appear on the app origin. The strict main-doc CSP means
// a separate XSS cannot escalate via eval or a blob: worker. Design + trade-off
// in LEARN.md §76 + docs/superpowers/specs/2026-06-21-csp-drop-unsafe-eval-design.md.
app.use(
  helmet({
    // Origin-Agent-Cluster asks the browser to origin-key the agent cluster.
    // That signal is browser-session-sticky: once an origin is recorded as
    // site-keyed, a later `?1` response conflicts with the record and the
    // console warns until the browser session resets. No ingress layer sets it
    // uniformly here and the isolation benefit is negligible, so no response
    // requests origin-keying.
    originAgentCluster: false,
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'"],
        workerSrc: ["'self'"],
        styleSrc: ["'self'", "'unsafe-inline'"],
        imgSrc: ["'self'", 'data:', 'blob:'],
        fontSrc: ["'self'", 'data:'],
        // Connect to any origin — the API origin is injected at runtime via
        // /config.js and varies per deployment. Tightening to a specific
        // origin here would defeat the purpose of runtime discovery.
        connectSrc: ["'self'", 'https:', 'http:', 'ws:', 'wss:'],
        objectSrc: ["'none'"],
        frameAncestors: ["'none'"],
        baseUri: ["'self'"],
      },
    },
    crossOriginEmbedderPolicy: false,
  }),
);

// req.log per request (before every route, including /health/config.js) so
// a later route's own logging joins the request; mounted before
// express.static (below) so a static-asset fetch is judged by `skip`.
app.use(createRequestId());

// A path "looks like a static asset" when it has a file extension (covers
// dist/ files AND the extension-shaped dynamic routes /config.js,
// /favicon.ico, /sandbox.html — all fetched once per page load like an
// asset) or starts with /assets/ (the Vite-hashed bundle directory, which
// has no further extension check needed). `skip` fully suppresses these —
// unlike edge's S2S auth-probe `debug` downgrade, a missing/stale asset
// (e.g. a client holding a pre-deploy bundle URL) is not an actionable
// signal on this pod, so it is never logged even on a 404.
//
// Every OTHER (non-asset) path gets no skip/debug override: request-log's
// own §5 derivation already yields the frontend's exact policy for a
// GET-only pod with no mutating routes — a 2xx/3xx request lands `access`/
// `debug` (invisible at the default LOG_LEVEL=info), and a >=400 request
// lands `access`/`warn` (or `security`/`warn` for 401/403/429, `access`/
// `error` for 5xx) — visible. That is the "status >= 400 and non-asset"
// policy from spec §8, produced with zero frontend-specific code in
// request-log.js itself.
//
// ACCEPTED FALSE-SKIP: the trailing-dot-segment shape also matches a path
// like `/v1.2` (no real file extension) — the frontend router has no such
// paths (no version-numbered or otherwise dotted non-asset route), so this
// never misclassifies a real request; it is cheaper than requiring the
// tail segment be a known asset extension for a distinction this pod never
// exercises.
const STATIC_ASSET_RE = /\.[a-zA-Z0-9]+$/;
function isStaticAssetPath(assetPath) {
  return STATIC_ASSET_RE.test(assetPath) || assetPath.startsWith('/assets/');
}
app.use(createRequestLog({ skip: isStaticAssetPath }));

// ── Health endpoint for k8s readiness/liveness probes on port 3000 ─────
app.get('/health', (_req, res) => {
  res.json({ api: 'ok', role: 'frontend', port: PORT });
});

// ── /config.js — runtime API origin injection ───────────────────────
// Safely encode the API_BASE so it cannot break out of the JS string
// literal. `JSON.stringify` handles quotes and control chars; the
// explicit `<` replacement protects against `</script>` injection if
// the URL ever contains HTML-significant characters.
//
// Node 12+ (V8 7.2+) already escapes U+2028/U+2029 in JSON.stringify per
// the well-formed JSON.stringify proposal, so the explicit replacements
// below are belt-and-suspenders: they execute but do not change output on
// modern Node. Kept to survive a hypothetical downgrade / alternative
// serialiser rewrite.
function escapeForInlineScript(value) {
  return JSON.stringify(value)
    .replace(/</g, '\\u003c')
    .replace(/\u2028/g, '\\u2028')
    .replace(/\u2029/g, '\\u2029');
}

app.get('/config.js', (req, res) => {
  // Always return a 200 with valid JS — a script-tag fetch that gets HTML 500
  // would surface as a confusing parse error in the browser console rather
  // than a recoverable empty config. Uses host-aware allowlist + dev
  // localStorage escape hatch.
  res.setHeader('Content-Type', 'application/javascript; charset=utf-8');
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('X-Content-Type-Options', 'nosniff');

  let body;
  try {
    // Use req.headers.host (the raw Host header from the TCP connection),
    // NOT req.hostname. With trust proxy=1 Express rewrites req.hostname from
    // X-Forwarded-Host, which is attacker-controllable and would let any
    // crafted Host claim to be e.g. localhost:8130 and pull the API base
    // from the allowlist. The raw Host header cannot be spoofed past the
    // first hop.
    const { base, known } = resolveApiBase(req.headers.host, API_BASE);
    if (!known && req.headers.host) {
      // Truncate logged Host to keep an attacker who can craft long Host
      // headers from poisoning logs (cosmetic only, but cheap mitigation).
      req.log.warn(
        { host: String(req.headers.host).slice(0, 200) },
        '[config.js] unknown Host — fallback to env.API_BASE. Add to resolveApiBase allowlist if this is a local-dev port.',
      );
    }
    body = `window.__API_BASE__ = ${escapeForInlineScript(base)};\n`;
    // NOTE: seed APP_NAME from ConfigMap env so the SPA has a value during
    // initial paint. The `useSystemSettings` hook overrides this with the
    // DB-backed value once it resolves. Uses the same JSON.stringify + `<`
    // escape as API_BASE for injection safety.
    if (APP_NAME) {
      body += `window.__APP_NAME__ = ${escapeForInlineScript(APP_NAME)};\n`;
    }
    body += `window.__ZONE_ENV__ = ${escapeForInlineScript(ZONE_ENV)};\n`;
    if (!IS_PRODUCTION) body += LOCALSTORAGE_OVERRIDE_SNIPPET;
  } catch (err) {
    req.log.error({ err }, '[config.js] handler threw — returning empty fallback so the script tag does not 500');
    body = 'window.__API_BASE__ = ""; /* resolver threw, check logs */\n';
  }

  res.send(body);
});

// ── Transformer sandbox iframe — isolated null-origin runner ─────────
// SECURITY: this is the ONLY path allowed 'unsafe-eval'. The transformer
// sandbox (src/platform/lib/transformer-sandbox.ts) loads this page inside an
// <iframe sandbox="allow-scripts"> (opaque origin, no allow-same-origin), so
// the new Function() it runs cannot reach the app's DOM / cookies / session.
// connect-src 'none' blocks network egress from the iframe + its blob worker;
// frame-ancestors 'self' lets only the app frame it. The main document CSP
// (above) forbids eval — this route override is scoped to /sandbox.html only.
// Must be registered BEFORE express.static so the override wins over the
// global strict CSP. The document body is served from a string baked into JS
// (shared/sandbox-document.cjs), NOT a static .html asset — some downstream
// environments run an HTML-file sanitiser that strips <script> from .html on
// ingest, which would silently break the sandbox. See LEARN §76.
app.get('/sandbox.html', (req, res) => {
  // SECURITY: the eval-relaxed CSP is only safe inside a sandboxed iframe
  // (opaque origin). Refuse to serve it as a top-level document navigation
  // (e.g. window.open('/sandbox.html')), where its script would run at the app
  // origin. Modern browsers send Sec-Fetch-Dest: 'document' for a top-level
  // load (vs 'iframe' for a frame, 'empty' for fetch — neither renders a
  // page). Absent header (older browsers) falls through; the worker-only scope
  // + connect-src 'none' still bound it.
  if (req.headers['sec-fetch-dest'] === 'document') {
    return res.status(403).type('text/plain').send('sandbox.html is only loadable in a sandboxed iframe');
  }
  res.setHeader(
    'Content-Security-Policy',
    "default-src 'none'; script-src 'unsafe-inline' 'unsafe-eval'; worker-src blob:; connect-src 'none'; frame-ancestors 'self'; base-uri 'none'; form-action 'none'",
  );
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Cache-Control', 'no-store');
  res.type('html').send(SANDBOX_HTML);
});

// ── Zone-correct favicon.ico override ────────────────────────────────
// WORKAROUND: Chrome prefers the static <link rel="icon" href="/favicon.ico">
// candidate in index.html over the runtime-added SVG favicon-swap.js writes,
// so the tab icon stayed blue in test zones even though the DOM carried the
// purple SVG. Fixing the picker is not possible from here, so the
// .ico itself must be zone-correct. Must be registered BEFORE express.static
// so this override wins, same as /sandbox.html above.
app.get('/favicon.ico', (req, res, next) => {
  const icoFile = ZONE_ENV === 'test' ? 'favicon-test.ico' : 'favicon.ico';
  // A stale/incomplete dist/ (missing the zone-specific .ico) must degrade to
  // the pre-override behaviour — fall through to express.static then the SPA
  // fallback — never surface sendFile's ENOENT as a 500 mislabeled image/x-icon.
  res.sendFile(
    path.join(DIST_PATH, icoFile),
    { headers: { 'Content-Type': 'image/x-icon', 'X-Content-Type-Options': 'nosniff' } },
    (err) => {
      if (err) next();
    },
  );
});

// ── Static assets + SPA fallback ────────────────────────────────────
app.use(express.static(DIST_PATH, { index: false, fallthrough: true }));

// SPA fallback — any GET that did not match /health, /config.js, or a
// static asset returns index.html so React Router handles the path.
app.get('*', (req, res) => {
  // Do not serve index.html to API-looking paths — if someone mis-configures
  // Istio and API requests land here, return 404 instead of feeding the
  // client an HTML body that will surface as a confusing JSON parse error.
  if (req.path.startsWith('/api/')) {
    return res.status(404).json({
      success: false,
      error: 'API not routed to frontend — check VirtualService destination.',
    });
  }
  res.sendFile(path.join(DIST_PATH, 'index.html'));
});

// Error handler — keep lean; no credentials to leak. Logs through req.log
// when present (joins the request's req_id/actor bindings, spec §6).
app.use((err, req, res, _next) => {
  // Log the app-error line (stack) through the shared log-only helper, then
  // respond with this pod's OWN error body verbatim. The frontend pod uses a
  // { success, error } shape (matching its /api/* 404 above), NOT the
  // edge/infra apiError envelope — the body contract must not change here.
  logAppError(req, err, { status: 500, code: 'INTERNAL_ERROR', reason: 'Internal server error' });
  if (res.headersSent) return;
  res.status(500).json({ success: false, error: 'Internal server error' });
});

// A container runtime can deliver SIGTERM then SIGINT (or duplicate signals)
// during the same shutdown; without this guard a second signal re-enters the
// handler and logs a second "graceful shutdown" sys line for one shutdown.
let _shuttingDown = false;

function gracefulShutdown(signal) {
  if (_shuttingDown) return;
  _shuttingDown = true;
  sysLog(null, { level: 'info', fields: { signal } }, 'graceful shutdown');
  process.exit(0);
}

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

// NOTE: boot banner with scheme derived from BASE_URL. Fail-fast on
// missing/malformed BASE_URL so misconfigured pods surface at startup,
// not at first request. printBootBanner is imported at module-top.

app.listen(PORT, () => {
  try {
    printBootBanner({
      role: 'FRONTEND',
      port: PORT,
      logger,
      depsSummary: [
        `dist: ${DIST_PATH}`,
        `API_BASE: ${API_BASE || '(same-origin relative)'}`,
        `allowlist entries: ${_ALLOWLIST_DIAG.entryCount}`,
      ],
    });
  } catch (err) {
    logger.error(
      { err: err.message },
      'boot banner failed — check APP_NAME / BASE_URL / FRONTEND_URL env',
    );
    throw err;
  }
  // NOTE: boot-phase env snapshot intentionally omitted — noise on healthy
  // boot; fail-phase dump on validateConfig error retains the affordance.
  // Frontend has no auth-mode concept of its own and no DB — role/port/
  // log_level/log_format only.
  bootLine({ role: 'FRONTEND', port: PORT });
});

// Test hook — the skip() predicate governing frontend request-log policy
// (spec §8); no HTTP call or log capture needed to pin it.
module.exports = { _isStaticAssetPath: isStaticAssetPath };
