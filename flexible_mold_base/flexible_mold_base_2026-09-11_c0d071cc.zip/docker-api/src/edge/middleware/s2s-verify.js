/**
 * s2s-verify.js — S2S authentication middleware for API-edge.
 *
 * SECURITY-1 (Critical): This middleware enforces the trust boundary.
 *
 * Order of operations (MUST NOT be reordered):
 *   1. Save X-Forwarded-User-* headers from incoming request
 *   2. STRIP them from req.headers (defense against external injection)
 *   3. Verify X-S2S-Key matches S2S_API_KEY
 *   4. If verified: reconstruct req.user from saved headers
 *   5. If not verified: reject (saved headers are discarded)
 *
 * Why strip BEFORE verify?
 *   If an attacker bypasses S2S (direct access to edge port), they could
 *   inject X-Forwarded-User-Role: admin. Stripping ensures that even if
 *   S2S check is accidentally skipped, injected identity is gone.
 */
const crypto = require('crypto');
const { sendError } = require('../../shared/lib/send-error');
const { logSecurity } = require('../../shared/lib/log-streams');
const { apiError } = require('../../shared/helpers');
const {
  S2S_HEADER,
  getS2sKey,
  IMPERSONATED_HEADER,
  IMPERSONATOR_HEADER,
  PRINCIPAL_TYPE_HEADER,
  SCOPE_HEADER,
} = require('../../shared/middleware/s2s-auth');
const { isNonEmptyScope } = require('../../shared/lib/machine-scope');
const { toActor } = require('../../shared/lib/actor');

const FORWARDED_USER_PREFIX = 'x-forwarded-user-';

// Printable ASCII, no control chars, bounded length — a resolved user id.
// Same intent as request-id.js's inbound guard: an adopted header value must
// not be able to inject newlines/control chars into the log stream.
const IMPERSONATOR_ID_RE = /^[\x21-\x7E]{1,128}$/;

/**
 * True when a raw header name is one of the forwarded-identity headers the S2S
 * boundary owns (must be stripped from external input before verification).
 * @param {string} lowerKey - already-lowercased header name
 */
function isForwardedIdentityHeader(lowerKey) {
  return lowerKey.startsWith(FORWARDED_USER_PREFIX)
    || lowerKey === PRINCIPAL_TYPE_HEADER
    || lowerKey === SCOPE_HEADER
    || lowerKey === IMPERSONATOR_HEADER;
}

/**
 * Strip all forwarded-identity headers from the raw request (X-Forwarded-User-*
 * plus the machine principal-type / scope headers).
 * @param {import('express').Request} req
 */
function stripForwardedUserHeaders(req) {
  for (const key of Object.keys(req.headers)) {
    if (isForwardedIdentityHeader(key.toLowerCase())) {
      delete req.headers[key];
    }
  }
}

// Bind the derived actor onto the per-request child logger once req.user has
// settled (service_account or human branch below). Skipped when req.user
// never resolved — an unauthenticated/refused request carries no actor
// binding, not an empty one.
function bindActor(req) {
  const actor = toActor(req.user, req.impersonator);
  if (actor !== undefined) req.log?.setBindings({ actor });
}

/**
 * Express middleware: S2S verification for API-edge.
 *
 * Exempt: /edge/health (Docker healthcheck needs unauthenticated access)
 */
function s2sVerify(req, res, next) {
  if (req.path === '/edge/health') return next();
  // /edge/openapi.json is intentionally NOT exempt — it is a login-gated
  // operator surface that must run through S2S verification so req.user is
  // populated (a direct, unverified hit gets the standard S2S 401).
  if (req.path.startsWith('/edge/docs')) return next();

  // Step 1: Save forwarded identity headers before stripping
  const savedHeaders = {};
  for (const key of Object.keys(req.headers)) {
    const lower = key.toLowerCase();
    if (isForwardedIdentityHeader(lower)) {
      savedHeaders[lower] = req.headers[key];
    }
  }

  // Step 2: STRIP all forwarded user headers
  stripForwardedUserHeaders(req);

  // Step 3: Verify S2S key
  //
  // NOTE: Each S2S failure mode has a distinct error code so operators and
  // the SPA diagnose-chain panel can tell them apart without inspecting
  // http_status:
  //   S2S_NOT_CONFIGURED — 500 — S2S_API_KEY missing on edge (server bug)
  //   S2S_MISSING_HEADER — 401 — caller forgot the x-s2s-key header
  //   S2S_KEY_MISMATCH   — 401 — caller sent a header but with wrong value
  // Previously S2S_MISSING_KEY was reused for both 500 and 401 and the
  // M4 AuthorizationPolicy bypass looked identical to a forgotten
  // header from the client side.
  const expectedKey = getS2sKey();
  if (!expectedKey) {
    return sendError(req, res, null, { status: 500, code: 'S2S_NOT_CONFIGURED', reason: 'S2S authentication not configured', fields: { log_msg: 'Failed to verify S2S call: S2S_API_KEY not configured on API-edge' } });
  }

  const receivedKey = req.headers[S2S_HEADER];
  if (!receivedKey) {
    return sendError(req, res, null, { status: 401, code: 'S2S_MISSING_HEADER', reason: 'Missing S2S authentication header' });
  }

  // Constant-time comparison to prevent timing attacks
  const expected = Buffer.from(expectedKey, 'utf8');
  const received = Buffer.from(receivedKey, 'utf8');
  if (expected.length !== received.length ||
      !crypto.timingSafeEqual(expected, received)) {
    // This 401 IS the request's terminal outcome — mark it so the finish
    // line's generic 401 security row does not ALSO fire (a second
    // kind:security line for the same rejection). logSecurity binds `ip`
    // itself, so the terminal line is not poorer than the finish line it
    // replaces.
    logSecurity(req, { event: 's2s_key_mismatch', level: 'warn', terminal: true }, 'S2S key mismatch');
    return sendError(req, res, null, { status: 401, code: 'S2S_KEY_MISMATCH', reason: 'Invalid S2S authentication' });
  }

  // Step 4: S2S verified — reconstruct req.user from saved (trusted) headers.
  //
  // Machine principal (service_account): pin a dedicated role that
  // requireAdmin/requireAdminOrEditor can NEVER accept, and fail closed unless
  // a non-empty scope travels with it. A scope-less machine principal is never
  // trusted [H1].
  if (savedHeaders[PRINCIPAL_TYPE_HEADER] === 'service_account') {
    let scope = null;
    const rawScope = savedHeaders[SCOPE_HEADER];
    if (typeof rawScope === 'string' && rawScope.length > 0) {
      try { scope = JSON.parse(rawScope); } catch { scope = null; }
    }
    if (!isNonEmptyScope(scope)) {
      req.user = null;
      bindActor(req);
      return next();
    }
    req.user = {
      id: savedHeaders['x-forwarded-user-id'] || null,
      email: savedHeaders['x-forwarded-user-email'] || '',
      role: 'service_account',
      type: 'service_account',
      scope,
    };
    bindActor(req);
    return next();
  }

  // Human principal (principal-type 'human' or absent — backward compatible).
  const id = savedHeaders['x-forwarded-user-id'];
  if (!id) {
    req.user = null;
  } else {
    req.user = {
      id,
      email: savedHeaders['x-forwarded-user-email'] || '',
      role: savedHeaders['x-forwarded-user-role'] || 'user',
    };
    if (savedHeaders['x-forwarded-user-deptid']) {
      req.user.deptid = savedHeaders['x-forwarded-user-deptid'];
    }
    if (savedHeaders['x-forwarded-user-kc-sub']) {
      req.user.keycloak_sub = savedHeaders['x-forwarded-user-kc-sub'];
    }
    if (savedHeaders['x-forwarded-user-kc-username']) {
      req.user.kc_username = savedHeaders['x-forwarded-user-kc-username'];
    }
    if (savedHeaders[IMPERSONATED_HEADER] === '1') {
      req.user.impersonated = true;
      // Adopt the forwarded admin id ONLY here — after S2S verification and
      // only for a request infra flagged impersonated — and only when it is a
      // well-formed id. A malformed value is dropped rather than adopted, so a
      // hostile header can neither inject the log stream nor forge an admin id.
      const rawImpersonator = savedHeaders[IMPERSONATOR_HEADER];
      if (typeof rawImpersonator === 'string' && IMPERSONATOR_ID_RE.test(rawImpersonator)) {
        req.impersonator = { id: rawImpersonator };
      }
    }
  }

  bindActor(req);
  next();
}

module.exports = { s2sVerify, stripForwardedUserHeaders };
