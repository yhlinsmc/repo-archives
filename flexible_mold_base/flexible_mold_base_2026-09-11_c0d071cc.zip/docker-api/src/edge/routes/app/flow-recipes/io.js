/**
 * io.js — cross-environment export / import for flow_recipes (+ their steps).
 *
 *   GET  /:id/export   export a recipe and all its steps as portable JSON,
 *                      WITHOUT secrets
 *   POST /import       import a recipe + steps from such a payload
 *
 * Mirrors api-connectors/io.js. Secrets never travel: export strips the
 * sensitive step auth_config leaves so the operator re-enters them on the
 * target. The bundle is self-contained — recipe meta + the inline
 * payload_transform_code + every step — so there is no separate transformer
 * entity to also export and UUID-remap. Import binds to a local blueprint only
 * when the payload's blueprint lineage path resolves here; an admin may store
 * an "unbound" recipe (blueprint_id NULL) to re-bind later, but an editor is
 * rejected (403) when no own/shared blueprint resolves — an unbound recipe is
 * unmanageable through the editor CRUD ownership chain.
 *
 * Code-version history (flow_recipe_code_versions) is environment-local audit.
 * The export is version-ignorant: it carries ONLY the current code, never the
 * history chain and never a version id. The import starts a FRESH version chain
 * — the created recipe keeps code_version=1 (the DDL default) and gets a single
 * v1 history row (action 'import'); it never carries the source environment's
 * history and never depends on a version id or a run→version snapshot. The
 * history append is best-effort (mirrors the payload_transform_code write): a
 * no-ALTER DB lacking the table/columns imports without it.
 *
 * No-ALTER tolerance: the export SELECT and the import INSERT name only the
 * columns guaranteed present once the flow feature exists; the additive
 * columns (recipe payload_transform_code + runs_on; step step_type/before_code/
 * after_code) are read via selectFirstOk tier fallback and written via per-group
 * best-effort UPDATEs that tolerate ER_BAD_FIELD_ERROR — the same degrade-don't-fail
 * split flow-recipes-run.js uses.
 */
const { pool, t } = require('../../../db');
const { sendError } = require('../../../../shared/lib/send-error');
const { apiOk, apiError, requireAdminOrEditor, uuidv4 } = require('../../../../shared/helpers');
const { TABLES } = require('../../../../shared/constants');
const { logger: rootLogger } = require('../../../../shared/lib/logger');
const { buildHierarchyPath, findBlueprintIdsByPath } = require('../../../lib/hierarchy-path');
const { mapRowsFromDb } = require('../../../lib/dto-mapper');
const { serializeRead, normalizeExtractSpec, normalizeCompareSpec } = require('./serializer');
const { stripAuthConfigSecrets, stripStraySecretLeaves } = require('../flow-recipe-steps/serializer');
const { declaredAuthTypeOr } = require('../../../lib/auth-config-secrets');
const { egressAllowedForUrl } = require('../../../../shared/lib/egress-policy');
const {
  isStorableHttpUrl, sanitizeUrlForExport, redactRequestConfigHeaders,
  resolveMaskedRequestConfigHeaders,
} = require('../../../../shared/lib/portable-url-redaction');
const { findReservedConsumedKey, RESERVED_KEY } = require('./consumed-keys-guard');
// The ONE primitive that decides both step-write invariants on the effective
// (recipe, step) row — the import path (a raw-SQL create) calls it so a bundle
// cannot slip a compare+POST or a mode-diverging step past the rule the CRUD
// mounts enforce.
const { assertStepInvariants } = require('../../../../shared/lib/flow-step-invariants');

const logger = rootLogger.child({ module: 'flow-recipes:io' });

const EXPORT_VERSION = 1;
const MAX_NAME = 255;
// A recipe is a handful of steps; cap import so a hand-edited bundle cannot drive
// one egress probe (a system_settings SELECT) per step into the thousands.
const MAX_STEPS = 100;
// Mirrors the flow-recipe-steps write-boundary cap (real authored code is a few
// hundred bytes); 32 KB also matches payload_transform_code's ceiling.
const MAX_CODE_BYTES = 32 * 1024;
// A compute step performs no dispatch; the schema stores a non-routable sentinel
// url that is never sent. It must skip the egress allow-list check (the sentinel
// host would otherwise falsely fail an enforced list) — same sentinel the editor
// stores (StepEditorWorkbench.COMPUTE_URL).
const COMPUTE_URL = 'https://compute.invalid/';

const CONTENT_TYPES = new Set(['application/json', 'application/yaml']);
// Per-step body dialect (flow-yaml-dialect PR-Y2) — CONTENT_TYPES above is
// reused for the step-level field too (same domain, same DDL enum members).
const YAML_VERSIONS = new Set(['1.2', '1.1']);
const YAML_QUOTINGS = new Set(['plain', 'double', 'single']);
const RUNS_ON = new Set(['create', 'update', 'both']);
const STEP_TYPES = new Set(['api', 'compute']);
const STEP_METHODS = new Set(['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'HEAD', 'OPTIONS']);

function isBadField(err) {
  return err && (err.errno === 1054 || err.code === 'ER_BAD_FIELD_ERROR');
}

// Ask information_schema directly rather than provoke a 1054 — the import path
// needs the answer BEFORE it decides whether a mixed-dialect bundle can even be
// accepted (Task Y2.6c below), which a try/catch on the write itself cannot give
// without first doing (and having to undo) part of the write.
async function columnExists(conn, table, column) {
  const rows = await conn.query(
    `SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?`,
    [table, column],
  );
  return Array.isArray(rows) && rows.length > 0;
}

// Try each SQL tier in turn; on a no-ALTER DB missing an additive column (errno
// 1054) fall through to the next, narrower tier. Tiers MUST be ordered widest →
// narrowest (newest migration columns dropped first), so each stuck-at-migration-N
// DB lands on the first tier whose columns it actually has. Generalises the
// single-fallback pattern in flow-recipes-run.js to the two independent additive
// groups on flow_recipes (inline payload_transform_code, then chaining runs_on).
//
// A trailing function argument (after the SQL tiers) is treated as onTier and
// invoked with the index of the tier that succeeded — the step-dialect fallback
// below needs to know WHICH tier landed, not just the rows.
async function selectFirstOk(conn, params, ...tiers) {
  const onTier = typeof tiers[tiers.length - 1] === 'function' ? tiers.pop() : null;
  for (let i = 0; i < tiers.length; i += 1) {
    try {
      const rows = await conn.query(tiers[i], params);
      if (onTier) onTier(i);
      return rows;
    } catch (err) {
      if (isBadField(err) && i < tiers.length - 1) continue;
      throw err;
    }
  }
  return [];
}

// [applied → Task Y2.6c] Commander ruling (third fix round): mirrors
// flow-recipes-run.js's loadRecipeContentTypeFallback. Read ONLY when the step
// SELECT above lands on a tier missing the dialect columns — a DB in that state
// predates Y1's ADD COLUMN, and therefore also predates YZ's later DROP COLUMN
// on this same recipe column, so the read never conflicts with that migration.
// The migrated (full-tier) export path never calls this — content_type stays
// zero-read there, as PR-Y2 intended.
async function loadRecipeContentTypeFallback(conn, recipeId) {
  try {
    const rows = await conn.query(
      // lint-allow: schema-parity flow_recipes.content_type is a permanently no-ALTER install's legacy column, retired from table-ddls.js only where the drop's precondition holds
      `SELECT content_type FROM \`${t(TABLES.FLOW_RECIPES)}\` WHERE id = ?`,
      [recipeId],
    );
    return rows.length ? (rows[0].content_type || null) : null;
  } catch (err) {
    if (isBadField(err)) return null;
    throw err;
  }
}

function parseJsonColumn(value) {
  if (value == null) return null;
  if (typeof value === 'object') return value;
  if (typeof value === 'string') {
    try { return JSON.parse(value); } catch { return null; }
  }
  return null;
}


module.exports = function register(router) {
  // GET /:id/export — portable JSON (recipe + steps), secrets stripped.
  router.get('/:id/export', async (req, res) => {
    if (!requireAdminOrEditor(req, res)) return;
    let conn;
    try {
      conn = await pool.ro.getConnection();

      // Two independent additive groups, newest-first: runs_on (chaining) and
      // payload_transform_code (inline-transform). A no-ALTER DB stuck before either
      // migration lacks that column, so peel them in separate tiers — a DB created
      // before the inline-transform migration (which used payload_transformer_id) has
      // neither, and must still export (those fields default to null on import).
      // consumed_output_keys / link_extract / external_id_extract are in the
      // original create, so they stay in every tier. content_type is retired
      // here (flow-yaml-dialect PR-Y2) — every step now carries its own
      // dialect (see the step SELECT below); the recipe column stays in the
      // DDL, zero-read, until PR-YZ's drop-column migration.
      const RECIPE_BASE_COLS = 'name, description, is_active, blueprint_id, consumed_output_keys, link_extract, external_id_extract';
      // compare_spec (compare pass) is a LATER additive group than runs_on
      // (chaining) — a DB can have runs_on without it — so it gets the
      // widest tier, ahead of the one before it; same widest-first pattern
      // as the step SELECT's own additive groups below.
      let recipeTierIndex = 0;
      const recipeRows = await selectFirstOk(
        conn,
        [req.params.id],
        `SELECT ${RECIPE_BASE_COLS}, payload_transform_code, runs_on, compare_spec FROM \`${t(TABLES.FLOW_RECIPES)}\` WHERE id = ?`,
        `SELECT ${RECIPE_BASE_COLS}, payload_transform_code, runs_on FROM \`${t(TABLES.FLOW_RECIPES)}\` WHERE id = ?`,
        `SELECT ${RECIPE_BASE_COLS}, payload_transform_code FROM \`${t(TABLES.FLOW_RECIPES)}\` WHERE id = ?`,
        `SELECT ${RECIPE_BASE_COLS} FROM \`${t(TABLES.FLOW_RECIPES)}\` WHERE id = ?`,
        (i) => { recipeTierIndex = i; },
      );
      if (!recipeRows.length) {
        return sendError(req, res, null, { status: 404, code: 'NOT_FOUND', reason: 'Recipe not found' });
      }
      const row = recipeRows[0];
      // Omit the key entirely (not a guessed default) when the source lacks
      // the column — same posture as step_runs_on/preset_config below: there
      // is no legacy sibling column compare_spec could fall back to.
      const compareSpecColumnAbsent = recipeTierIndex > 0;

      // Carry the blueprint's root→self lineage as a natural key. blueprint_id is
      // environment-local (fresh UUIDs on import), so import re-binds by this name
      // path; blueprint_id stays only as a legacy fallback.
      let blueprintPath = null;
      if (row.blueprint_id) {
        const nodes = await conn.query(
          `SELECT id, parent_id, name FROM \`${t(TABLES.HIERARCHY_NODES)}\``,
        );
        const p = buildHierarchyPath(nodes, row.blueprint_id);
        if (p.length) blueprintPath = p;
      }

      // step_type / before_code / after_code are one additive group; content_type /
      // yaml_version / yaml_quoting (flow-yaml-dialect PR-Y2) are a LATER, separate
      // additive group — a DB can have the former without the latter; step_runs_on
      // (epic 3, 3.2.998) is LATER STILL — a DB can have the dialect columns
      // without it; preset_config is NEWER STILL — a
      // DB can have step_runs_on without it. Each gets its own, widest-first tier
      // ahead of the one before it. auth_config selected so its secret leaf can be
      // stripped; it is the only secret column.
      let stepTierIndex = 0;
      const stepRows = await selectFirstOk(
        conn,
        [req.params.id],
        `SELECT \`sequence\`, name, method, url, auth_type, auth_config,
                request_config, response_config, input_from_step,
                dispatch_origin, timeout_ms,
                step_type, before_code, after_code,
                content_type, yaml_version, yaml_quoting,
                step_runs_on, preset_config
         FROM \`${t(TABLES.FLOW_RECIPE_STEPS)}\` WHERE recipe_id = ? ORDER BY \`sequence\``,
        `SELECT \`sequence\`, name, method, url, auth_type, auth_config,
                request_config, response_config, input_from_step,
                dispatch_origin, timeout_ms,
                step_type, before_code, after_code,
                content_type, yaml_version, yaml_quoting,
                step_runs_on
         FROM \`${t(TABLES.FLOW_RECIPE_STEPS)}\` WHERE recipe_id = ? ORDER BY \`sequence\``,
        `SELECT \`sequence\`, name, method, url, auth_type, auth_config,
                request_config, response_config, input_from_step,
                dispatch_origin, timeout_ms,
                step_type, before_code, after_code,
                content_type, yaml_version, yaml_quoting
         FROM \`${t(TABLES.FLOW_RECIPE_STEPS)}\` WHERE recipe_id = ? ORDER BY \`sequence\``,
        `SELECT \`sequence\`, name, method, url, auth_type, auth_config,
                request_config, response_config, input_from_step,
                dispatch_origin, timeout_ms,
                step_type, before_code, after_code
         FROM \`${t(TABLES.FLOW_RECIPE_STEPS)}\` WHERE recipe_id = ? ORDER BY \`sequence\``,
        `SELECT \`sequence\`, name, method, url, auth_type, auth_config,
                request_config, response_config, input_from_step,
                dispatch_origin, timeout_ms
         FROM \`${t(TABLES.FLOW_RECIPE_STEPS)}\` WHERE recipe_id = ? ORDER BY \`sequence\``,
        (i) => { stepTierIndex = i; },
      );

      // preset_config is absent whenever the tier that landed is not the
      // widest (tier 0) — the column simply isn't selected, so the export
      // omits the key entirely rather than guessing a value (there is no
      // fallback column for a UI-only regeneration aid).
      const presetConfigColumnAbsent = stepTierIndex > 0;

      // step_runs_on is absent whenever the tier that landed is past tier 1 —
      // the column simply isn't selected, so the export omits the
      // key entirely rather than guessing a value (there is no legacy column
      // this one can fall back to, unlike content_type below).
      const stepRunsOnColumnAbsent = stepTierIndex > 1;

      // [applied → Task Y2.6c] Commander ruling (third fix round): a
      // tier past the dialect tier means the dialect columns are absent from
      // EVERY step of this recipe (added in one migration, never just some) —
      // the pre-Y1 implicit rule applies: the recipe's OWN content_type is every
      // step's dialect, at yaml_version 1.2 / quoting plain. Exporting the
      // per-step 'application/json' default here (instead) would silently
      // turn an existing YAML recipe into a JSON bundle on re-import.
      const dialectColumnsAbsent = stepTierIndex > 2;
      const legacyRecipeContentType = dialectColumnsAbsent
        ? await loadRecipeContentTypeFallback(conn, req.params.id)
        : null;

      const steps = stepRows.map((s) => ({
        sequence: s.sequence,
        name: s.name,
        method: s.method,
        url: sanitizeUrlForExport(s.url),
        auth_type: s.auth_type,
        // SECURITY: drop every sensitive auth_config leaf so a portable recipe
        // step never carries a secret (plaintext OR ciphertext). stripStraySecretLeaves
        // first removes any leaf that does not belong to the current auth_type (e.g. a
        // stale `token` ciphertext left after the type changed to 'none'), then
        // stripAuthConfigSecrets removes the sanctioned leaf — together they guarantee
        // no secret survives even for a row that predates the write-path strip.
        auth_config: stripAuthConfigSecrets(
          stripStraySecretLeaves(parseJsonColumn(s.auth_config) || {}, s.auth_type),
          s.auth_type,
        ),
        // SECURITY: blank credential-valued headers (Authorization / api-key) typed
        // literally into request_config.headers — export must carry no secret.
        request_config: redactRequestConfigHeaders(parseJsonColumn(s.request_config)),
        response_config: parseJsonColumn(s.response_config),
        input_from_step: parseJsonColumn(s.input_from_step),
        dispatch_origin: s.dispatch_origin,
        timeout_ms: s.timeout_ms ?? null,
        step_type: s.step_type ?? 'api',
        before_code: s.before_code ?? null,
        after_code: s.after_code ?? null,
        content_type: dialectColumnsAbsent
          ? (legacyRecipeContentType || 'application/json')
          : (s.content_type ?? 'application/json'),
        yaml_version: dialectColumnsAbsent ? '1.2' : (s.yaml_version ?? null),
        yaml_quoting: dialectColumnsAbsent ? 'plain' : (s.yaml_quoting ?? null),
        // Omit the key entirely (not a guessed default) when the source lacks
        // the column — there is no legacy sibling column to fall back to the
        // way content_type has one; import treats an absent key as the DDL
        // default 'both', which is exactly what a grandfathered step means.
        ...(stepRunsOnColumnAbsent ? {} : { step_runs_on: s.step_runs_on ?? 'both' }),
        // preset_config is a UI-only regeneration aid,
        // never the runtime truth (before_code — carried above — is). Omitted
        // entirely (not stamped null) when the source lacks the column, same
        // posture as step_runs_on above; import treats an absent key as "no
        // preset", identical to a present-but-null value.
        ...(presetConfigColumnAbsent ? {} : { preset_config: parseJsonColumn(s.preset_config) }),
      }));

      const exported = {
        export_version: EXPORT_VERSION,
        recipe: {
          name: row.name,
          description: row.description,
          is_active: row.is_active === 1 || row.is_active === true,
          blueprint_id: row.blueprint_id,
          blueprint_path: blueprintPath,
          runs_on: row.runs_on ?? null,
          payload_transform_code: row.payload_transform_code ?? null,
          consumed_output_keys: parseJsonColumn(row.consumed_output_keys),
          link_extract: parseJsonColumn(row.link_extract),
          external_id_extract: parseJsonColumn(row.external_id_extract),
          ...(compareSpecColumnAbsent ? {} : { compare_spec: normalizeCompareSpec(parseJsonColumn(row.compare_spec)) }),
        },
        steps,
        exported_at: new Date().toISOString(),
      };
      res.json(apiOk(exported));
    } catch (err) {
      sendError(req, res, err, { status: 500, code: 'INTERNAL_ERROR', reason: 'Database operation failed', fields: { recipeId: req.params.id } });
    } finally {
      if (conn) conn.release();
    }
  });

  // POST /import — create a recipe (+ steps) from a portable payload.
  router.post('/import', async (req, res) => {
    if (!requireAdminOrEditor(req, res)) return;
    const { recipe, steps: rawSteps } = req.body || {};
    if (!recipe || typeof recipe !== 'object' || !recipe.name) {
      return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: 'Invalid import data: recipe with a name is required' });
    }
    if (typeof recipe.name !== 'string' || recipe.name.length > MAX_NAME) {
      return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: `recipe.name must be a string ≤ ${MAX_NAME} characters` });
    }
    // Reserved-key guard: an imported consumed_output_keys entry equal to
    // "payload" or starting "payload." would collide/double-prefix under the
    // dispatch rename — reject the whole import rather than store an unusable key.
    const reservedConsumedKey = findReservedConsumedKey(recipe.consumed_output_keys);
    if (reservedConsumedKey) {
      return sendError(req, res, null, { status: 400, code: 'RESERVED_OUTPUT_KEY', reason: `consumed_output_keys entry "${reservedConsumedKey}" is reserved: keys equal to "${RESERVED_KEY}" or starting with "${RESERVED_KEY}." collide with the dispatch data vocabulary` });
    }
    const stepsIn = Array.isArray(rawSteps) ? rawSteps : [];
    if (stepsIn.length > MAX_STEPS) {
      return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: `A recipe import cannot exceed ${MAX_STEPS} steps` });
    }
    if (typeof recipe.payload_transform_code === 'string'
        && Buffer.byteLength(recipe.payload_transform_code, 'utf8') > MAX_CODE_BYTES) {
      return sendError(req, res, null, { status: 413, code: 'PAYLOAD_TOO_LARGE', reason: `payload_transform_code exceeds ${MAX_CODE_BYTES} bytes` });
    }

    // ── Normalize + validate each step to the same bar a CRUD step write meets.
    // Enum-ish fields degrade to their default (a hand-edited bundle should not
    // fail wholesale); url is a hard security pin (cannot degrade). The effective
    // step_type drives whether the egress check applies.
    //
    // LEGACY BUNDLE BACK-COMPAT (flow-yaml-dialect PR-Y2): an export from before
    // this PR carries content_type only at the recipe level (never on a step). A
    // step lacking its own declared content_type inherits the recipe's; a NEW
    // bundle (every step already carries content_type from THIS PR's export)
    // never falls through to it.
    const recipeCt = CONTENT_TYPES.has(recipe.content_type) ? recipe.content_type : null;
    const cleanSteps = [];
    for (let i = 0; i < stepsIn.length; i += 1) {
      const s = stepsIn[i] || {};
      const stepType = STEP_TYPES.has(s.step_type) ? s.step_type : 'api';
      let url = typeof s.url === 'string' ? s.url : '';
      if (stepType === 'compute') {
        // A compute step is never dispatched; pin the non-routable sentinel so the
        // NOT-NULL url column is satisfied regardless of the payload.
        url = COMPUTE_URL;
      } else if (!isStorableHttpUrl(url)) {
        return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: `Step ${i + 1} "${typeof s.name === 'string' ? s.name : ''}": url must be an absolute http(s) URL` });
      }
      const method = STEP_METHODS.has(String(s.method).toUpperCase())
        ? String(s.method).toUpperCase() : 'POST';
      // The member list is the step COLUMN's, asked of the DDL — the literal set
      // this replaced was a copy of it. Degrade-to-'none' is kept: a hand-edited
      // bundle imports rather than fails, and an import stores no secret leaf.
      const authType = declaredAuthTypeOr(TABLES.FLOW_RECIPE_STEPS, s.auth_type);
      for (const field of ['before_code', 'after_code']) {
        const v = s[field];
        if (v == null || v === '') continue;
        if (typeof v !== 'string') {
          return sendError(req, res, null, { status: 400, code: 'BAD_REQUEST', reason: `Step ${i + 1}: ${field} must be a string` });
        }
        if (Buffer.byteLength(v, 'utf8') > MAX_CODE_BYTES) {
          return sendError(req, res, null, { status: 413, code: 'PAYLOAD_TOO_LARGE', reason: `Step ${i + 1}: ${field} exceeds ${MAX_CODE_BYTES} bytes` });
        }
      }
      // step_runs_on (epic 3, additive 3.2.998): carried verbatim. An ABSENT key
      // legitimately means 'both' (the DDL default for a grandfathered step); an
      // unknown value is NOT validated or coerced here — the shared invariant
      // primitive below is the single authority and rejects it fail-closed as
      // FLOW_STEP_TRIGGER_INVALID rather than admitting it as the more-permissive
      // 'both'.
      const stepRunsOn = s.step_runs_on != null ? s.step_runs_on : 'both';
      cleanSteps.push({
        sequence: Number.isInteger(s.sequence) ? s.sequence : i,
        name: typeof s.name === 'string' && s.name.length ? s.name.slice(0, MAX_NAME) : `Step ${i + 1}`,
        method,
        url,
        auth_type: authType,
        // The payload carries no secrets (export stripped them); a hand-edited
        // bundle could still inject a stray leaf, so strip stray-type leaves AND the
        // sanctioned leaf before storing — no secret is ever persisted from import.
        auth_config: stripAuthConfigSecrets(
          stripStraySecretLeaves(parseJsonColumn(s.auth_config) || {}, authType),
          authType,
        ),
        request_config: parseJsonColumn(s.request_config),
        response_config: parseJsonColumn(s.response_config),
        input_from_step: parseJsonColumn(s.input_from_step),
        // Task 8 back-compat: a legacy export step carrying `allowed_hosts` is
        // ignored silently (dropped on read) — the column is gone.
        dispatch_origin: ['infra', 'edge'].includes(s.dispatch_origin) ? s.dispatch_origin : 'infra',
        timeout_ms: Number.isInteger(s.timeout_ms) && s.timeout_ms >= 1000 && s.timeout_ms <= 120000 ? s.timeout_ms : null,
        step_type: stepType,
        before_code: typeof s.before_code === 'string' && s.before_code !== '' ? s.before_code : null,
        after_code: typeof s.after_code === 'string' && s.after_code !== '' ? s.after_code : null,
        content_type: CONTENT_TYPES.has(s.content_type) ? s.content_type : (recipeCt ?? 'application/json'),
        // DDL default, never null: the columns are ENUM NOT NULL DEFAULT '1.2'/
        // 'plain' (table-ddls.js). An absent/invalid dialect on a legacy bundle
        // (recipe-level content_type carried the dialect implicitly as 1.2/plain
        // — see the comment above content_type in the DDL) must normalise to
        // that same default, not to null: the best-effort UPDATE below sends
        // these straight into the NOT NULL columns, and MariaDB's strict-mode
        // 1048 (not 1054) is not caught by isBadField, so a null here 500s the
        // whole import (measured on a legacy bundle with recipe-level
        // content_type:'application/yaml' and a step with no dialect).
        yaml_version: YAML_VERSIONS.has(s.yaml_version) ? s.yaml_version : '1.2',
        yaml_quoting: YAML_QUOTINGS.has(s.yaml_quoting) ? s.yaml_quoting : 'plain',
        step_runs_on: stepRunsOn,
        // preset_config's shape is checked below, in the same one-primitive
        // gate as step_runs_on/method (I3) — a malformed value fails the
        // whole import rather than opening undetected as a preset the editor
        // cannot regenerate.
        preset_config: parseJsonColumn(s.preset_config),
      });
    }

    // ── One-primitive invariant gate over the whole bundle, BEFORE any row
    // exists. The import is a raw-SQL create path, so it must meet the same bar
    // the CRUD write does: no committed step may violate I1 (compare⇒GET), I2
    // (a step mode diverging from a non-both recipe mode) or I3 (preset_config /
    // compare_spec / link_extract shape), and an unknown trigger fails closed.
    // A legacy bundle without step_runs_on is 'both' and passes if its method is
    // fine. The whole bundle is rejected on the first violation (a
    // half-imported recipe is broken), naming the offending step.
    // A recognised recipe "Runs for" gates the per-step I2 check; an unknown one
    // must FAIL CLOSED, not coerce to the more-permissive 'both' (which would run
    // every step under a mode the author never chose). Named against the recipe,
    // not a step index — the fault is the recipe field. An absent value stays the
    // DDL default 'both'.
    if (recipe.runs_on != null && !RUNS_ON.has(recipe.runs_on)) {
      return sendError(req, res, null, { status: 400, code: 'FLOW_RECIPE_MODE_INVALID', reason: `recipe "Runs for" value "${recipe.runs_on}" is not a recognised value` });
    }
    const importRecipeRunsOn = recipe.runs_on || 'both';
    // Recipe-level I3 (compare_spec / link_extract / external_id_extract),
    // checked ONCE against the bundle's recipe row — same primitive the CRUD
    // mount gates the same fields with, so a hand-edited bundle cannot carry
    // a shape neither the compare stage nor the link resolver can read.
    const recipeShapeViolation = assertStepInvariants({
      recipe: {
        runs_on: importRecipeRunsOn,
        compare_spec: recipe.compare_spec,
        link_extract: recipe.link_extract,
        external_id_extract: recipe.external_id_extract,
      },
      step: {},
    });
    if (recipeShapeViolation) {
      return sendError(req, res, null, { status: 400, code: recipeShapeViolation.code, reason: recipeShapeViolation.message });
    }
    for (let i = 0; i < cleanSteps.length; i += 1) {
      const cs = cleanSteps[i];
      const violation = assertStepInvariants({
        recipe: { runs_on: importRecipeRunsOn },
        step: { step_runs_on: cs.step_runs_on, method: cs.method, step_type: cs.step_type, preset_config: cs.preset_config },
      });
      if (violation) {
        return sendError(req, res, null, { status: 400, code: violation.code, reason: `Step ${i + 1} "${cs.name}": ${violation.message}` });
      }
    }

    // ── Save-time egress allow-list gate, mirroring the dispatch-time check.
    // An off-list api step fails the WHOLE import (a half-imported recipe is
    // broken); compute steps are skipped (sentinel url, never dispatched).
    // Empty/absent list = allow-all; a corrupt list THROWS → 500 fail-closed.
    try {
      for (let i = 0; i < cleanSteps.length; i += 1) {
        const s = cleanSteps[i];
        if (s.step_type === 'compute') continue;
        const egress = await egressAllowedForUrl(s.url, s.method, (sql, params) => pool.ro.query(sql, params), t);
        if (!egress.ok) {
          return sendError(req, res, null, { status: 422, code: 'EGRESS_BLOCKED', reason: `Step ${i + 1} "${s.name}" targets a URL that is not on the admin egress allow-list; nothing was imported` });
        }
      }
    } catch (err) {
      return sendError(req, res, err, { status: 500, code: 'INTERNAL_ERROR', reason: 'Database operation failed', fields: { name: recipe.name } });
    }

    const recipeId = uuidv4();
    const ownerId = req.user?.id || null;
    let conn;
    try {
      conn = await pool.rw.getConnection();

      // Re-bind by the blueprint's lineage (name path), which survives the
      // fresh-UUID import that breaks a raw id match across environments. A unique
      // path match binds; 0 or >1 matches stay unbound. A payload without a path
      // (legacy export) falls back to the old id-existence check. Validate the
      // payload-supplied path: non-empty array of strings, depth capped well above
      // the 4-tier hierarchy so a crafted huge array can't drive an O(nodes × len) scan.
      const blueprintPath = Array.isArray(recipe.blueprint_path)
        && recipe.blueprint_path.length > 0
        && recipe.blueprint_path.length <= 32
        && recipe.blueprint_path.every((s) => typeof s === 'string')
        ? recipe.blueprint_path : null;
      const wantedBinding = !!blueprintPath || !!recipe.blueprint_id;
      let blueprintId = null;
      if (blueprintPath) {
        const nodes = await conn.query(
          `SELECT id, parent_id, name, node_type FROM \`${t(TABLES.HIERARCHY_NODES)}\``,
        );
        const matches = findBlueprintIdsByPath(nodes, blueprintPath);
        if (matches.length === 1) blueprintId = matches[0];
      } else if (recipe.blueprint_id) {
        const bp = await conn.query(
          `SELECT 1 FROM \`${t(TABLES.HIERARCHY_NODES)}\` WHERE id = ? LIMIT 1`,
          [recipe.blueprint_id],
        );
        if (bp.length) blueprintId = recipe.blueprint_id;
      }

      // An editor must never create a recipe they cannot later manage. CRUD create
      // rejects an editor's null/foreign blueprint (parentOwnership), and an unbound
      // recipe fails the editor PUT/DELETE ownership-chain — so an unbound import
      // would be an orphan only an admin could fix. Reject for editors; admins may
      // keep an unbound recipe.
      if (req.user?.role !== 'admin') {
        let ownOrShared = false;
        if (blueprintId) {
          const own = await conn.query(
            `SELECT owner_id FROM \`${t(TABLES.HIERARCHY_NODES)}\` WHERE id = ?`,
            [blueprintId],
          );
          const bpOwner = own.length ? own[0].owner_id : undefined;
          ownOrShared = bpOwner === null || bpOwner === (req.user?.id || null);
        }
        if (!ownOrShared) {
          return sendError(req, res, null, { status: 403, code: 'FORBIDDEN', reason: 'An editor can only import a recipe bound to a blueprint they own or that is shared' });
        }
      }

      // Degrade malformed recipe metadata to defaults rather than 400 the import.
      // content_type is retired at the recipe level (flow-yaml-dialect PR-Y2);
      // recipeCt (computed earlier, before the DB connection) is the per-step
      // legacy-bundle fallback only — the recipe row itself no longer stores it.
      const runsOn = RUNS_ON.has(recipe.runs_on) ? recipe.runs_on : 'both';
      // Bundle values are already parsed JS (the request body was JSON-decoded), so
      // they are used as-is — NOT re-run through parseJsonColumn, which would JSON.parse
      // a legitimate bare-string extract spec ("$.data.id") and silently null it.
      const consumedKeys = Array.isArray(recipe.consumed_output_keys) ? recipe.consumed_output_keys : null;
      // link_extract / external_id_extract / compare_spec already passed I3
      // above (a malformed value on any of the three 400s before this line
      // runs), so normalizeExtractSpec/normalizeCompareSpec here only
      // canonicalizes an already-accepted value to the exact shape the run
      // path (specToPath/resolveLinkTemplate) and the builder read — a bare
      // string, {path}, {kind:'path',path}, or {kind:'template',template}
      // (serializer.js's normalizeExtractSpec accepts all four).
      const linkExtract = normalizeExtractSpec(recipe.link_extract);
      const externalIdExtract = normalizeExtractSpec(recipe.external_id_extract);
      const compareSpec = normalizeCompareSpec(recipe.compare_spec);
      const payloadCode = typeof recipe.payload_transform_code === 'string' && recipe.payload_transform_code !== ''
        ? recipe.payload_transform_code : null;

      // [applied → Task Y2.6c] Commander ruling (third fix round): a
      // no-ALTER target lacking the step dialect columns cannot remember a
      // per-step dialect at all — the per-step best-effort UPDATE further down
      // simply 1054s and is swallowed, so an existing YAML bundle would
      // silently land (and later run/export) as JSON. The only place such a
      // target CAN remember a dialect at all is the legacy recipe-level
      // content_type column, which stays present exactly when the step
      // columns are absent (same precondition as loadRecipeContentTypeFallback
      // in the export handler above and in flow-recipes-run.js) — and it is
      // ONE value for the WHOLE recipe (the pre-Y1 shape), so it can only
      // faithfully represent a bundle whose steps ALL resolve to the SAME
      // content_type. A JSON+YAML mix would misrepresent the JSON steps as
      // YAML on every later read (run-begin/export apply the recipe's stamped
      // value to EVERY step, not selectively) — that IS the silent
      // format-change this whole fix exists to stop, so it is rejected here,
      // not stamped with a guess, before any row exists.
      const stepDialectColumnsPresent = await columnExists(conn, t(TABLES.FLOW_RECIPE_STEPS), 'content_type');
      let legacyRecipeDialectToStamp = null;
      if (!stepDialectColumnsPresent && cleanSteps.length > 0) {
        const dialects = new Set(cleanSteps.map((s) => s.content_type));
        if (dialects.size > 1) {
          return sendError(req, res, null, { status: 409, code: 'DIALECT_COLUMNS_UNAVAILABLE', reason: 'This target database predates the per-step dialect migration (flow-yaml-dialect) and cannot import a bundle whose steps use different content types; apply the pending migration first' });
        }
        const [uniformDialect] = dialects;
        if (uniformDialect && uniformDialect !== 'application/json') {
          legacyRecipeDialectToStamp = uniformDialect;
          // The legacy recipe-level column remembers content_type only — a
          // uniform bundle authored at yaml_version 1.1 and/or yaml_quoting
          // double/single collapses to the implicit pre-Y1 dialect (1.2/plain)
          // on THIS target, because loadRecipeContentTypeFallback's readers
          // (run-begin, export) can only ever answer 1.2/plain for a recipe
          // whose steps have no dialect columns of their own. Documented
          // accept — the no-ALTER integration test pins the collapse.
          // pathname-only, no payload.
          const nonDefaultYaml = cleanSteps.some((s) => s.yaml_version !== '1.2' || s.yaml_quoting !== 'plain');
          if (nonDefaultYaml && logger && typeof logger.warn === 'function') {
            req.log.warn(
              { recipeId },
              'recipe import id=' + recipeId + ' collapsed yaml_version/yaml_quoting to the DDL default '
              + '(1.2/plain) — target database predates the per-step dialect columns and can only '
              + 'remember content_type at the recipe level',
            );
          }
        }
      }

      await conn.beginTransaction();

      // Core recipe INSERT names only columns present in the ORIGINAL flow_recipes
      // create; payload_transform_code (inline migration) and runs_on (chaining
      // migration) are each stamped via a separate best-effort UPDATE so a no-ALTER
      // DB stuck before either migration still imports (those fields degrade to null
      // / the DDL default).
      await conn.query(
        `INSERT INTO \`${t(TABLES.FLOW_RECIPES)}\`
         (id, name, description, is_active, owner_id, blueprint_id,
          consumed_output_keys, link_extract, external_id_extract)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          recipeId,
          recipe.name,
          recipe.description || null,
          recipe.is_active === false ? 0 : 1,
          ownerId,
          blueprintId,
          consumedKeys != null ? JSON.stringify(consumedKeys) : null,
          linkExtract != null ? JSON.stringify(linkExtract) : null,
          externalIdExtract != null ? JSON.stringify(externalIdExtract) : null,
        ],
      );

      // payload_transform_code best-effort (inline-transform additive): a no-ALTER DB
      // created before that migration lacks the column → degrade to null (recipe not
      // runnable until authored) rather than failing the whole import.
      // COHERENCE: track whether the code actually landed. A null code needs no
      // UPDATE (the row's DDL default is null, which the history seed will record as
      // null); a non-null code only counts as stored if its UPDATE did not 1054.
      let codeStored = payloadCode == null;
      if (payloadCode != null) {
        try {
          await conn.query(
            `UPDATE \`${t(TABLES.FLOW_RECIPES)}\` SET payload_transform_code = ? WHERE id = ?`,
            [payloadCode, recipeId],
          );
          codeStored = true;
        } catch (pcErr) {
          if (!isBadField(pcErr)) throw pcErr;
          // Column absent → the code was NOT stored; leave codeStored false so no
          // history row claims a code the recipe row does not hold.
        }
      }

      // runs_on best-effort (chaining additive): a no-ALTER DB lacking it degrades to
      // the DDL default 'both' (guard inert) rather than failing the import.
      if (runsOn !== 'both') {
        try {
          await conn.query(
            `UPDATE \`${t(TABLES.FLOW_RECIPES)}\` SET runs_on = ? WHERE id = ?`,
            [runsOn, recipeId],
          );
        } catch (roErr) {
          if (!isBadField(roErr)) throw roErr;
        }
      }

      // compare_spec best-effort (compare pass, additive): a no-ALTER target
      // lacking it degrades to the DDL default null — the imported recipe
      // still runs create/update; it just cannot compare before an update
      // until the column exists. Skipped for the common (no compare
      // authored) case — the DDL default is already null.
      if (compareSpec != null) {
        try {
          await conn.query(
            `UPDATE \`${t(TABLES.FLOW_RECIPES)}\` SET compare_spec = ? WHERE id = ?`,
            [JSON.stringify(compareSpec), recipeId],
          );
        } catch (csErr) {
          if (!isBadField(csErr)) throw csErr;
        }
      }

      // [applied → Task Y2.6c] persist the bundle's uniform non-JSON dialect on
      // the LEGACY recipe-level column when the target cannot store it per-step
      // (legacyRecipeDialectToStamp is non-null only in that case — computed,
      // and mixed-dialect bundles already rejected, before this transaction
      // began). The fallback rule elsewhere (run-begin, export) reads this
      // column as "every step's dialect" whenever the step columns are absent,
      // so this keeps a uniform-YAML import legible on a no-ALTER target.
      // Guarded 1054-tolerant for defense-in-depth even though the calling
      // condition already implies the column is present.
      if (legacyRecipeDialectToStamp) {
        try {
          await conn.query(
            // lint-allow: schema-parity flow_recipes.content_type is the no-ALTER install's legacy column; this write only fires when columnExists gated stepDialectColumnsPresent above found the step columns absent
            `UPDATE \`${t(TABLES.FLOW_RECIPES)}\` SET content_type = ? WHERE id = ?`,
            [legacyRecipeDialectToStamp, recipeId],
          );
        } catch (ctErr) {
          if (!isBadField(ctErr)) throw ctErr;
        }
      }

      // SECURITY: an import is a create path, so it must obey the approval
      // lifecycle — without this an editor could import a recipe that lands with
      // NULL status (= grandfathered = runnable), bypassing review. Best-effort so
      // a no-ALTER DB lacking the column degrades to NULL=approved. admin →
      // approved; editor → pending. The run gate is the backstop regardless.
      try {
        if (req.user?.role === 'admin') {
          await conn.query(
            `UPDATE \`${t(TABLES.FLOW_RECIPES)}\` SET status='approved', approved_by=?, approved_at=NOW() WHERE id = ?`,
            [ownerId, recipeId],
          );
        } else {
          await conn.query(
            `UPDATE \`${t(TABLES.FLOW_RECIPES)}\` SET status='pending' WHERE id = ?`,
            [recipeId],
          );
        }
      } catch (stampErr) {
        if (!isBadField(stampErr)) throw stampErr;
      }

      // Start a FRESH code-version chain for the imported recipe: seed a single
      // v1 history row (action 'import') recording the imported code. The recipe
      // row keeps code_version=1 (DDL default). COHERENCE: seed only when the FULL
      // versioning surface is live — the code was actually stored (codeStored) AND
      // the counter column exists on flow_recipes. On a partial-migration target
      // (code stored but counter column absent) later CRUD PUTs degrade unversioned,
      // so a v1 row here would be a stale chain start. Best-effort on the history
      // table itself: a target missing it (1146) imports without version history.
      let counterColumnPresent = false;
      try {
        const cvCol = await conn.query(
          `SELECT 1 FROM information_schema.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?`,
          [t(TABLES.FLOW_RECIPES), 'code_version'],
        );
        counterColumnPresent = Array.isArray(cvCol) && cvCol.length > 0;
      } catch { counterColumnPresent = false; }
      if (codeStored && counterColumnPresent) {
        try {
          await conn.query(
            `INSERT INTO \`${t(TABLES.FLOW_RECIPE_CODE_VERSIONS)}\`
             (id, recipe_id, version, code, action, created_by)
             VALUES (?, ?, 1, ?, 'import', ?)`,
            [uuidv4(), recipeId, payloadCode, ownerId],
          );
        } catch (cvErr) {
          if (!isBadField(cvErr) && cvErr.errno !== 1146 && cvErr.code !== 'ER_NO_SUCH_TABLE') throw cvErr;
        }
      }

      // Steps: new id + new recipe_id, sequence preserved (so input_from_step
      // sequence refs stay valid — no id remap needed). step_type/before_code/
      // after_code stamped via a per-step best-effort UPDATE (additive group).
      for (const s of cleanSteps) {
        const stepId = uuidv4();
        await conn.query(
          `INSERT INTO \`${t(TABLES.FLOW_RECIPE_STEPS)}\`
           (id, recipe_id, \`sequence\`, name, method, url, auth_type, auth_config,
            request_config, response_config, input_from_step,
            dispatch_origin, timeout_ms)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            stepId,
            recipeId,
            s.sequence,
            s.name,
            s.method,
            s.url,
            s.auth_type,
            JSON.stringify(s.auth_config || {}),
            // The mirror lane: a hand-built recipe bundle carries step headers
            // through the same import, so the sentinel is dropped here too
            // rather than becoming the credential the step dispatches with.
            s.request_config != null
              ? JSON.stringify(resolveMaskedRequestConfigHeaders(s.request_config, null))
              : null,
            s.response_config != null ? JSON.stringify(s.response_config) : null,
            s.input_from_step != null ? JSON.stringify(s.input_from_step) : null,
            s.dispatch_origin,
            s.timeout_ms,
          ],
        );
        if (s.step_type !== 'api' || s.before_code != null || s.after_code != null) {
          try {
            await conn.query(
              `UPDATE \`${t(TABLES.FLOW_RECIPE_STEPS)}\`
               SET step_type = ?, before_code = ?, after_code = ? WHERE id = ?`,
              [s.step_type, s.before_code, s.after_code, stepId],
            );
          } catch (codeErr) {
            // A no-ALTER DB lacking the chaining columns cannot store JS/compute
            // steps; the chain is then meaningless, so fail the import rather than
            // silently drop the code (an api-only legacy bundle never enters here).
            if (!isBadField(codeErr)) throw codeErr;
            throw Object.assign(
              new Error('CHAINING_UNSUPPORTED'),
              apiError('This recipe uses per-step code or compute steps, which the target database does not support', 'CHAINING_UNSUPPORTED', 422),
            );
          }
        }
        // content_type / yaml_version / yaml_quoting (flow-yaml-dialect PR-Y2) —
        // a LATER, separate additive group from step_type/before_code/after_code
        // above (a DB can have chaining without having this migration), so it
        // gets its own best-effort UPDATE: unlike chaining, an absent column here
        // is not fatal to the recipe's meaning (it just cannot remember a non-
        // default dialect choice for this step), so a 1054 degrades silently
        // rather than failing the whole import. Skipped entirely when every
        // value is already the DDL default — no write for the common case.
        // (yaml_version/yaml_quoting are normalised to '1.2'/'plain' above and
        // are never null, so the comparison is against the default, not null.)
        if (s.content_type !== 'application/json' || s.yaml_version !== '1.2' || s.yaml_quoting !== 'plain') {
          try {
            await conn.query(
              `UPDATE \`${t(TABLES.FLOW_RECIPE_STEPS)}\`
               SET content_type = ?, yaml_version = ?, yaml_quoting = ? WHERE id = ?`,
              [s.content_type, s.yaml_version, s.yaml_quoting, stepId],
            );
          } catch (dialectErr) {
            if (!isBadField(dialectErr)) throw dialectErr;
          }
        }
        // step_runs_on (epic 3, additive 3.2.998) — the NEWEST of the three
        // additive step groups (later than the dialect group above), so it gets
        // the widest tier and its own best-effort UPDATE. A no-ALTER target
        // lacking it degrades to the DDL default 'both' silently — the same
        // posture flow_recipes.runs_on takes on the recipe row above: the guards
        // this column enforces (compare-must-be-GET, mode-divergence) simply go
        // inert for this step, which is not fatal to what the step dispatches.
        if (s.step_runs_on !== 'both') {
          try {
            await conn.query(
              `UPDATE \`${t(TABLES.FLOW_RECIPE_STEPS)}\` SET step_runs_on = ? WHERE id = ?`,
              [s.step_runs_on, stepId],
            );
          } catch (runsOnErr) {
            if (!isBadField(runsOnErr)) throw runsOnErr;
          }
        }
        // preset_config is NEWER STILL than
        // step_runs_on, so it gets its own best-effort UPDATE. A no-ALTER target
        // lacking it degrades to the DDL default null: the imported step still
        // dispatches correctly (before_code, the runtime truth, is always
        // carried above) — it just opens in the editor as a plain custom-code
        // step instead of a re-editable preset. Skipped for the common
        // (no preset) case — the DDL default is already null.
        if (s.preset_config != null) {
          try {
            await conn.query(
              `UPDATE \`${t(TABLES.FLOW_RECIPE_STEPS)}\` SET preset_config = ? WHERE id = ?`,
              [JSON.stringify(s.preset_config), stepId],
            );
          } catch (presetErr) {
            if (!isBadField(presetErr)) throw presetErr;
          }
        }
      }

      // Read back the row BEFORE committing. If the read-back or response shaping
      // throws, the catch rolls back a still-open transaction — committing first
      // would leave the import permanent while returning 500, so a client retry
      // would create a duplicate. Read-back inside the txn sees its own writes.
      const rows = await conn.query(
        `SELECT * FROM \`${t(TABLES.FLOW_RECIPES)}\` WHERE id = ?`, [recipeId],
      );
      // Shape the row like the CRUD read path (mapRowsFromDb JSON-decodes the JSON
      // columns + coerces is_active → boolean) so the response honours the FlowRecipe
      // contract the frontend hook promises; then strip approval bookkeeping.
      const shaped = serializeRead(mapRowsFromDb('flow_recipes', rows)[0]);

      await conn.commit();

      res.status(201).json(apiOk({
        ...shaped,
        steps_imported: cleanSteps.length,
        unbound: blueprintId === null && wantedBinding,
      }));
    } catch (err) {
      if (conn) {
        try { await conn.rollback(); } catch (rbErr) {
          req.log.warn({ err: rbErr }, 'rollback after recipe import failed');
        }
      }
      // A thrown apiError envelope (e.g. CHAINING_UNSUPPORTED) carries its own
      // status/body; relay it instead of masking as a generic 500.
      if (err && err.status && err.body) {
        // lint-allow: logger-discipline two-step consumes a helper-built apiError-shaped result, not a direct apiError call at this site
        return res.status(err.status).json(err.body);
      }
      sendError(req, res, err, { status: 500, code: 'INTERNAL_ERROR', reason: 'Database operation failed', fields: { name: recipe.name } });
    } finally {
      if (conn) conn.release();
    }
  });
};
