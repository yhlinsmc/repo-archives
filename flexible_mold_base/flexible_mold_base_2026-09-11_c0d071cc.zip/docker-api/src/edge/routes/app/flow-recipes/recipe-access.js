'use strict';

/**
 * recipe-access.js — the ONE answer to "may this caller read this recipe",
 * shared by the step read-scope gate and both runs_on conflict gates.
 *
 * WHY ONE MODULE AND NOT A HELPER PER GATE. Three gates decide the same
 * question — who may see a recipe's children — and a second copy is how a gate
 * widened on one path and stayed strict on another (the recurring defect this
 * repo keeps producing: one gate learns to fold case, the next still uses
 * `===`). A single predicate cannot drift from itself.
 *
 * ASKED OF THE COLUMN, not of JavaScript. `flow_recipes.owner_id` is CHAR(36)
 * under a case-folding collation, and every write-side gate on these mounts asks
 * SQL, so a `===` here would refuse an editor whose stored `owner_id` differs
 * from the id in their token only in spelling — one question answered one way by
 * the half that writes and another by the half that reads. `sameStoredValue`
 * asks the engine.
 *
 * FAIL-CLOSED, which is `sameStoredValue`'s own default: an operand the column
 * cannot be asked about is answered "not the same value", and for a READ gate
 * refusing is the safe end — the alternative hands somebody another owner's
 * recipe.
 */
const { pool, t } = require('../../../db');
const { TABLES } = require('../../../../shared/constants');
const { sameStoredValue } = require('../schema/write-value');

const RECIPE_NOT_YOURS = {
  ok: false,
  error: { code: 'FORBIDDEN', message: 'Not allowed: recipe is not owned by you and is not shared' },
};

async function callerMayReadRecipe(ownerId, req) {
  if (ownerId == null) return true; // shared (owner_id IS NULL) — any editor may read
  return sameStoredValue(pool.ro, t(TABLES.FLOW_RECIPES), 'owner_id', ownerId, req.user?.id);
}

module.exports = { callerMayReadRecipe, RECIPE_NOT_YOURS };
