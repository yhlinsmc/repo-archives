/**
 * flow-recipes/serialize-endpoint.js — serialize-only YAML endpoint.
 *
 * POST /serialize accepts a JSON payload and returns it serialized as YAML
 * inside the standard apiOk envelope: { data: { text }, error: null, meta }.
 *
 * NOTE: zero-dep FE has no YAML lib; this serialize-only endpoint reuses
 * docker-api's yaml dep. JSON serialization stays on the FE; only the YAML
 * transform is delegated here.
 */
const yaml = require('yaml');
const { apiOk, requireAdminOrEditor } = require('../../../../shared/helpers');
const { markReadOnly } = require('../../../../shared/middleware/route-markers');

module.exports = function registerSerialize(router) {
  // SAFETY: body is already parsed by the global express.json({ limit: '10mb' })
  // in index-edge.js (sets req._body = true before reaching this middleware chain),
  // so a local parser here would be silently skipped — omit it to avoid confusion.
  router.post('/serialize', markReadOnly, (req, res) => {
    // SAFETY: the caller (flow-recipes/index.js) already runs a
    // router.use(requireAdminOrEditor...) gate ahead of this registration on
    // the same shared router — this local check is deliberate defense-in-depth
    // redundancy, matching the pattern in api-connectors/*.
    if (!requireAdminOrEditor(req, res)) return;
    const { payload } = req.body ?? {};
    // Accept plain objects or arrays; reject null and all other primitives.
    if (payload === null || payload === undefined || typeof payload !== 'object') {
      return res.status(400).json({ error: 'INVALID_PAYLOAD' });
    }
    let text;
    try {
      text = yaml.stringify(payload, { lineWidth: 0 });
    } catch (_err) {
      return res.status(400).json({ error: 'SERIALIZE_FAILED' });
    }
    return res.json(apiOk({ text }));
  });
};
