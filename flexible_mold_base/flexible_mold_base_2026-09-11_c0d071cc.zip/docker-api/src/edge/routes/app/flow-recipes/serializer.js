/**
 * flow-recipes/serializer.js — field-level read normalization for flow_recipes.
 *
 * serializeRead strips approved_by and approved_at from the row before the API
 * response is sent; only status and review_note (if any) are visible to clients.
 * No secret handling — flow_recipes carries no auth_config.
 *
 * normalizeExtractSpec coerces an untrusted link_extract/external_id_extract
 * value to the shapes the run path (specToPath/resolveLinkTemplate,
 * shared/lib/flow-extract.js) and the builder accept.
 */

/**
 * Drop internal approval bookkeeping so the API response never carries who
 * approved a recipe, or when. Only status and review_note are surfaced.
 * Returns a new row object; leaves non-object input unchanged.
 */
function serializeRead(row) {
  if (!row || typeof row !== 'object') return row;
  // SECURITY: approved_by (the approving admin's user id) and approved_at are
  // internal bookkeeping the client never renders — strip them from every read
  // so an editor cannot learn which admin approved a recipe or when.
  const rest = { ...row };
  delete rest.approved_by;
  delete rest.approved_at;
  return rest;
}

/**
 * Coerce an untrusted link_extract/external_id_extract value to one of the
 * shapes the run path (specToPath/resolveLinkTemplate) and the builder
 * (FlowRecipeBuilder's extractPath/extractKind/extractTemplate) accept: a bare
 * JSONPath string, the legacy untagged `{ path }`, the tagged `{ kind:'path',
 * path }`, or `{ kind:'template', template }`. Anything else (array, object
 * missing a string path/template, an unrecognized kind, a number) → null, so
 * a hand-edited bundle cannot persist a shape that throws when the run path
 * or the builder reads it.
 */
function normalizeExtractSpec(v) {
  if (typeof v === 'string') return v;
  if (v && typeof v === 'object' && !Array.isArray(v)) {
    if (v.kind === 'template' && typeof v.template === 'string') return { kind: 'template', template: v.template };
    if (v.kind === 'path' && typeof v.path === 'string') return { kind: 'path', path: v.path };
    if (v.kind === undefined && typeof v.path === 'string') return { path: v.path };
  }
  return null;
}

/**
 * Coerce an untrusted compare_spec value (spec Q19/Q20) to the one shape the
 * Build modal's compare stage reads (`{ localPath, remotePath }`, both
 * non-empty strings) or null. Same fail-closed posture as
 * normalizeExtractSpec above and the frontend's own parse point
 * (src/fmb/lib/flow/compare-spec.ts, kept a byte-for-byte logic twin): a
 * shape a reader cannot resolve degrades to "nothing to compare" rather than
 * reaching `safePathGet` with an `undefined` path, which would silently read
 * as "found nothing" instead of surfacing the authoring mistake.
 */
function normalizeCompareSpec(v) {
  if (v == null) return null;
  if (typeof v !== 'object' || Array.isArray(v)) return null;
  const localPath = typeof v.localPath === 'string' ? v.localPath.trim() : '';
  const remotePath = typeof v.remotePath === 'string' ? v.remotePath.trim() : '';
  if (!localPath || !remotePath) return null;
  return { localPath, remotePath };
}

module.exports = { serializeRead, normalizeExtractSpec, normalizeCompareSpec };
