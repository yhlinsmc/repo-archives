'use strict';

/**
 * template-versions.js — fmb_template_versions mount.
 *
 * WHY THIS IS NOT A SNAPSHOT. `template-snapshots.js` is an unexecuted,
 * client-side-restored checkpoint; a version is the same freeze but with
 * server-side lifecycle on top (browse, restore-in-place, save-as-new-
 * template) so it can sit on ONE timeline next to flow_recipe_runs rows.
 * GET / merges both sources rather than duplicating flow rows into this
 * table — a flow run already stores input_snapshot/output_snapshot, and
 * the merge is what lets a single list badge `kind: 'manual' | 'flow'`.
 * A flow-projected id is spelled `run:<flow_recipe_runs.id>` so the two id
 * spaces can never collide; every route below recognises and routes on
 * that prefix before touching a table.
 *
 * WHO MAY READ AND WRITE. Same rule as `template-snapshots.js`: the
 * record's owner, anyone they delegated to, and an administrator —
 * `callerMayWriteTemplate` is reused for both reads and writes so this
 * route cannot drift from what "may work on this record" already means
 * everywhere else.
 *
 * RESTORE IS DESTRUCTIVE AND SERVER-SIDE (unlike a snapshot's restore,
 * which is entirely client-side): it overwrites `user_templates.payload`
 * + `generated_outputs` in one transaction, gated by the same
 * save-first/`TEMPLATE_CHANGED` freshness check `capacity/versions.js`'s
 * restore uses for a scenario, scaled down to two columns.
 */
const router = require('express').Router();
const { sendError } = require('../../../shared/lib/send-error');
const { pool, t } = require('../../db');
const {
  apiOk, requireAuth, uuidv4, UUID_RE,
} = require('../../../shared/helpers');
const { TABLES } = require('../../../shared/constants');
const { normalizeTimestamp } = require('../../lib/dto-mapper');
const { callerMayWriteTemplate } = require('../../lib/delegated-grants');
const { tableExistsInCurrentSchema } = require('../../lib/table-exists');
const { isKnownPresent, rememberPresent } = require('../../lib/table-presence-cache');
const { attachOwnerNames } = require('../../lib/owner-name-enrichment');
const { logger: rootLogger } = require('../../../shared/lib/logger');
const {
  parseSnapshot, normalizeDbTimestamp, flowSnapshotDocument, templateStateFingerprint, extractRestorable,
} = require('../../lib/template-version-restorable');

const logger = rootLogger.child({ module: 'template-versions-route' });

// SECURITY: authentication for the whole router, so a route added later
// inherits it rather than having to remember it — same pattern
// template-snapshots.js:49 uses.
router.use((req, res, next) => { if (requireAuth(req, res)) next(); });

const MAX_NAME = 255;
const MAX_NOTE = 10000;
// Same bound and reasoning as template-snapshots.js's MAX_SNAPSHOT_BYTES: the
// document is client-supplied (form state lives client-side by nature — spec
// §7 divergence from capacity's server-computed snapshot) and LONGTEXT has no
// MariaDB-side cap worth relying on.
const MAX_SNAPSHOT_BYTES = 2 * 1024 * 1024;

// A flow-projected version id is this prefix + flow_recipe_runs.id, so the
// two id spaces can never collide (plan §Task 2 GET contract).
const RUN_ID_PREFIX = 'run:';

// Each helper now takes `req` (house order (req, res, ...)) so its 5xx/4xx
// response routes through the one audited responder instead of a bespoke
// two-step apiError+res.status/json.
const dbError = (req, res, err, fields) => sendError(req, res, err, { status: 500, code: 'INTERNAL_ERROR', reason: 'Database operation failed', fields });
const notFound = (req, res, message = 'Not found') => sendError(req, res, null, { status: 404, code: 'NOT_FOUND', reason: message });
const badRequest = (req, res, message, code = 'BAD_REQUEST') => sendError(req, res, null, { status: 400, code, reason: message });
// `TEMPLATE_CHANGED` (the restore freshness guard) is the same status with a
// different code — a shared helper so both call sites always emit the same
// shape rather than two hand-rolled 409s drifting apart.
const conflictError = (req, res, message, code = 'CONFLICT') => sendError(req, res, null, { status: 409, code, reason: message });

/**
 * Which physical row a version id names — a manual `template_versions` row,
 * or a flow-projected `flow_recipe_runs` row — without ever touching a
 * table. Returns `null` for a malformed id (neither a UUID nor `run:<uuid>`)
 * so every caller can 404 on it before issuing a query, exactly as an
 * unrecognised UUID already does elsewhere in this router family.
 */
function parseVersionId(raw) {
  const id = String(raw || '');
  if (UUID_RE.test(id)) return { kind: 'manual', id };
  if (id.startsWith(RUN_ID_PREFIX)) {
    const runId = id.slice(RUN_ID_PREFIX.length);
    if (UUID_RE.test(runId)) return { kind: 'flow', id: runId };
  }
  return null;
}

/**
 * May this caller read and write this record's versions? Reuses
 * `callerMayWriteTemplate` — the SAME rule the template's own write path
 * enforces — rather than restating it (identical reasoning to
 * template-snapshots.js's `callerMaySeeSnapshots`).
 */
async function callerMaySeeVersions(conn, user, templateId) {
  // Fingerprint columns ride along here (no second round trip) so POST
  // /versions can stamp `base_template_fingerprint` from this same read.
  const rows = await conn.query(
    `SELECT id, owner_id, blueprint_id, updated_at,
            payload, generated_outputs, field_option_selection, computed_field_overrides, cleared_auto_fills
       FROM \`${t(TABLES.USER_TEMPLATES)}\` WHERE id = ?`,
    [templateId],
  );
  if (!rows.length) return { found: false, row: null, allowed: false };
  const allowed = await callerMayWriteTemplate(conn, user, rows[0]);
  return { found: true, row: rows[0], allowed };
}

/**
 * Is `template_versions` there to be read or written? The 3.2.890 CREATE is
 * severity 'warning' (an operator account without DDL privilege may never
 * run it), so the table can be legitimately absent while the rest of the app
 * boots and runs fine — same contract `template-snapshots.js`'s
 * `snapshotsTableAvailable` documents, reused here per-database via the
 * shared presence cache.
 */
async function versionsTableAvailable(conn) {
  const physical = t(TABLES.TEMPLATE_VERSIONS);
  if (isKnownPresent(conn, physical)) return true;
  try {
    const present = await tableExistsInCurrentSchema(conn, physical);
    if (present) rememberPresent(conn, physical);
    return present;
  } catch (err) {
    logger.warn({ err }, 'could not probe for the template versions table — versions are reported unavailable');
    return false;
  }
}

const LIST_COLUMNS = 'id, template_id, name, note, kind, flow_run_id, blueprint_id, variant_id, actor_id, created_at';
const FULL_COLUMNS = `${LIST_COLUMNS}, snapshot`;

// parseSnapshot / normalizeDbTimestamp / flowSnapshotDocument / extractRestorable
// / templateStateFingerprint live in ../../lib/template-version-restorable.js.

/** Enriches rows with `actor_name` (never `owner_name` — these rows have no
 *  owner column) via the shared owner-name enrichment helper, keyed on each
 *  row's `actor_id`. Mutates in place and returns the same array; reused by
 *  both the merged-timeline read and the single-version detail read so the
 *  two can never resolve the actor differently. Same rename-the-shared-
 *  helper's-output pattern as flow-recipe-runs/aggregate.js's own
 *  `attachActorNames` — `owner_username` is dropped rather than renamed:
 *  nothing on this surface renders an actor avatar, only the "by <name>"
 *  text `versionRowLabel`'s callers already show. */
async function attachActorNames(conn, rows) {
  await attachOwnerNames(conn, rows, 'actor_id', `\`${t(TABLES.USERS)}\``);
  for (const row of rows) {
    if (!row) continue;
    row.actor_name = row.owner_name ?? null;
    delete row.owner_name;
    delete row.owner_username;
  }
  return rows;
}

/** One manual `template_versions` row → the shared TemplateVersionMeta shape. */
function presentManualRow(row, { withSnapshot } = {}) {
  const out = {
    id: row.id,
    template_id: row.template_id,
    kind: 'manual',
    name: row.name,
    note: row.note ?? null,
    status: null,
    flow_run_id: null,
    blueprint_id: row.blueprint_id ?? null,
    variant_id: row.variant_id ?? null,
    actor_id: row.actor_id ?? null,
    actor_name: row.actor_name ?? null,
    created_at: normalizeTimestamp(row.created_at),
  };
  if (withSnapshot) out.snapshot = parseSnapshot(row.snapshot);
  return out;
}

/** One `flow_recipe_runs` row, projected into the same shape. `variant_id` is
 *  always null: flow_recipe_runs carries no such column (see table-ddls.js). */
function presentFlowRow(row, { withSnapshot } = {}) {
  const out = {
    id: `${RUN_ID_PREFIX}${row.id}`,
    template_id: row.template_id,
    kind: 'flow',
    name: null,
    note: null,
    status: row.status ?? null,
    flow_run_id: row.id,
    blueprint_id: row.blueprint_id ?? null,
    variant_id: null,
    actor_id: row.actor_id ?? null,
    actor_name: row.actor_name ?? null,
    created_at: normalizeTimestamp(row.created_at),
  };
  if (withSnapshot) out.snapshot = flowSnapshotDocument(row);
  return out;
}

// extractRestorable now lives in ../../lib/template-version-restorable.js —
// split out (alongside parseSnapshot/normalizeDbTimestamp/flowSnapshotDocument/
// templateStateFingerprint) to stay under the file-size gate; see that file
// for what it does and why.

/**
 * Reads one version's full document, whichever kind of id it is. Returns
 * `null` when nothing matches — a caller-visible 404, never a throw — and
 * `{ unavailable: true }` when a manual id was asked for on a schema where
 * `template_versions` was never created (which is the same fact as "not
 * found": no manual version could exist there).
 */
async function loadVersionRow(conn, templateId, parsed) {
  if (parsed.kind === 'flow') {
    // input_snapshot/output_snapshot named and dropped together: MariaDB only
    // reports the FIRST missing column on a 1054, so telling which of the two
    // is absent apart would mean parsing its text. Same reactive-fallback
    // shape flow-recipe-runs/aggregate.js's readRunDetail uses — "columns
    // absent" is a database-shape fact, same as them genuinely holding NULL.
    let rows;
    try {
      rows = await conn.query(
        `SELECT id, template_id, blueprint_id, actor_id, status, created_at, input_snapshot, output_snapshot
           FROM \`${t(TABLES.FLOW_RECIPE_RUNS)}\` WHERE id = ? AND template_id = ?`,
        [parsed.id, templateId],
      );
    } catch (err) {
      if (!(err && (err.errno === 1054 || err.code === 'ER_BAD_FIELD_ERROR'))) throw err;
      rows = await conn.query(
        `SELECT id, template_id, blueprint_id, actor_id, status, created_at
           FROM \`${t(TABLES.FLOW_RECIPE_RUNS)}\` WHERE id = ? AND template_id = ?`,
        [parsed.id, templateId],
      );
      rows = rows.map((r) => ({ ...r, input_snapshot: null, output_snapshot: null }));
    }
    if (!rows.length) return null;
    return { kind: 'flow', row: rows[0] };
  }
  if (!(await versionsTableAvailable(conn))) return null;
  const rows = await conn.query(
    `SELECT ${FULL_COLUMNS} FROM \`${t(TABLES.TEMPLATE_VERSIONS)}\` WHERE id = ? AND template_id = ?`,
    [parsed.id, templateId],
  );
  if (!rows.length) return null;
  return { kind: 'manual', row: rows[0] };
}

async function safeRollback(conn) {
  if (!conn) return;
  try { await conn.rollback(); } catch (err) { logger.error({ err }, 'template-versions rollback failed'); }
}

/**
 * @openapi
 * /edge/app/templates/{templateId}/versions:
 *   get:
 *     tags: [App - Template Versions]
 *     summary: The merged version timeline — manual saves + flow runs, newest first (owner/delegate/admin).
 *     responses:
 *       200: { description: "`{ items, unavailable }` — `unavailable` is true only when the manual-save table was never created; flow rows still list" }
 *       404: { description: No such record, or not the caller's to see }
 *   post:
 *     tags: [App - Template Versions]
 *     summary: Save the caller-supplied form state as a new named, manual version (owner/delegate/admin).
 *     description: Never dispatches anything and never writes flow_recipe_runs.
 *     responses:
 *       201: { description: Created version (metadata, no snapshot body) }
 *       400: { description: name/note/snapshot failed validation, or the document is not doc_version 2 }
 *       404: { description: No such record, or not the caller's to write }
 *       503: { description: The versions table has not been created on this schema }
 * /edge/app/templates/{templateId}/versions/{versionId}:
 *   get:
 *     tags: [App - Template Versions]
 *     summary: One version in full, including its parsed snapshot (owner/delegate/admin).
 *     responses:
 *       200: { description: The version row }
 *       404: { description: No such version }
 *   put:
 *     tags: [App - Template Versions]
 *     summary: Rename a manual version or edit its note (owner/delegate/admin). A two-field whitelist.
 *     responses:
 *       200: { description: Updated meta }
 *       400: { description: A non-editable field was supplied, or the id names a flow run (FLOW_VERSION_READONLY) }
 *       404: { description: No such version }
 *   delete:
 *     tags: [App - Template Versions]
 *     summary: Delete a manual version (owner/delegate/admin). Flow-projected ids are refused — flow history lives on the run surfaces.
 *     responses:
 *       200: { description: Deleted }
 *       400: { description: The id names a flow run }
 *       404: { description: No such version }
 * /edge/app/templates/{templateId}/versions/{versionId}/restore:
 *   post:
 *     tags: [App - Template Versions]
 *     summary: Overwrite the template's payload + generated_outputs from this version, in one transaction (owner/delegate/admin).
 *     responses:
 *       200: { description: Restored }
 *       400: { description: saved_version_id is malformed or names the version being restored }
 *       404: { description: No such version, or the named saved version not found }
 *       409: { description: "CONFLICT: the snapshot cannot be read. TEMPLATE_CHANGED: the template moved since the named saved version was cut." }
 * /edge/app/templates/{templateId}/versions/{versionId}/save-as:
 *   post:
 *     tags: [App - Template Versions]
 *     summary: Clone this version's snapshot into a brand-new template (owner/delegate/admin of the SOURCE template).
 *     responses:
 *       201: { description: The new template's meta }
 *       404: { description: No such version }
 *       409: { description: The snapshot cannot be read, so it cannot be cloned }
 */

// GET /:templateId/versions — merged timeline.
router.get('/:templateId/versions', async (req, res) => {
  const templateId = String(req.params.templateId);
  if (!UUID_RE.test(templateId)) return notFound(req, res);
  let conn;
  try {
    conn = await pool.ro.getConnection();
    const access = await callerMaySeeVersions(conn, req.user, templateId);
    if (!access.found || !access.allowed) return notFound(req, res);

    const flowRows = await conn.query(
      `SELECT id, template_id, blueprint_id, actor_id, status, created_at
         FROM \`${t(TABLES.FLOW_RECIPE_RUNS)}\` WHERE template_id = ? ORDER BY created_at DESC, id DESC`,
      [templateId],
    );

    const manualAvailable = await versionsTableAvailable(conn);
    let manualRows = [];
    if (manualAvailable) {
      manualRows = await conn.query(
        `SELECT ${LIST_COLUMNS} FROM \`${t(TABLES.TEMPLATE_VERSIONS)}\`
          WHERE template_id = ? ORDER BY created_at DESC, id DESC`,
        [templateId],
      );
    }
    // ONE enrichment call across both sources — actor_id ids overlapping
    // between a manual save and a flow dispatch resolve to a single query
    // instead of two, and both present*Row functions read the same
    // `row.actor_name` this stamps.
    await attachActorNames(conn, [...flowRows, ...manualRows]);
    const flowItems = flowRows.map((r) => presentFlowRow(r));
    const manualItems = manualRows.map((r) => presentManualRow(r));

    // WHY: TIMESTAMP has 1-second resolution, so same-second rows are common;
    // tie-break on id DESC — a documented, deterministic secondary key that
    // matches the per-source SQL's own ORDER BY — so the merge never falls
    // back to array position (which would always render manual-before-flow).
    const items = [...manualItems, ...flowItems].sort((a, b) => {
      if (a.created_at !== b.created_at) return a.created_at < b.created_at ? 1 : -1;
      if (a.id === b.id) return 0;
      return a.id < b.id ? 1 : -1;
    });
    return res.json(apiOk({ items, unavailable: !manualAvailable }));
  } catch (err) {
    return dbError(req, res, err, { templateId });
  } finally {
    if (conn) conn.release();
  }
});

// POST /:templateId/versions — save a manual version. Never touches flow_recipe_runs.
router.post('/:templateId/versions', async (req, res) => {
  const templateId = String(req.params.templateId);
  if (!UUID_RE.test(templateId)) return notFound(req, res);
  const body = req.body && typeof req.body === 'object' ? req.body : {};

  const name = typeof body.name === 'string' ? body.name.trim() : '';
  if (!name) return badRequest(req, res, 'name is required');
  if (name.length > MAX_NAME) return badRequest(req, res, `name exceeds ${MAX_NAME} characters`);

  const note = body.note ?? null;
  if (note !== null && (typeof note !== 'string' || note.length > MAX_NOTE)) {
    return badRequest(req, res, `note must be a string up to ${MAX_NOTE} characters`);
  }

  // The document is the one thing this route trusts the client for (module
  // doc) — shape-checked, doc_version-gated (only a v2 document, spec §3, may
  // be saved as a version going forward) and size-bounded.
  const snapshotDoc = body.snapshot;
  if (snapshotDoc === undefined || snapshotDoc === null || typeof snapshotDoc !== 'object' || Array.isArray(snapshotDoc)) {
    return badRequest(req, res, 'snapshot must be an object');
  }
  if (snapshotDoc.doc_version !== 2) {
    return badRequest(req, res, 'snapshot.doc_version must be 2');
  }
  // Reject at creation what restore/save-as would reject anyway — the SAME
  // extraction those two consumers run — so a document that can never be
  // restored (e.g. `{doc_version:2}` with no `entered` bucket) never gets a
  // 201 that then 409s forever on every later restore/save-as attempt.
  if (!extractRestorable(snapshotDoc)) {
    return badRequest(req, res, 'snapshot does not carry a restorable entered map', 'SNAPSHOT_NOT_RESTORABLE');
  }
  const serialized = JSON.stringify(snapshotDoc);
  if (Buffer.byteLength(serialized, 'utf8') > MAX_SNAPSHOT_BYTES) {
    return badRequest(req, res, 'snapshot document is too large to save');
  }

  const blueprintId = typeof body.blueprint_id === 'string' && body.blueprint_id ? body.blueprint_id : null;
  if (blueprintId !== null && !UUID_RE.test(blueprintId)) return badRequest(req, res, 'blueprint_id must be a UUID');
  const variantId = typeof body.variant_id === 'string' && body.variant_id ? body.variant_id : null;
  if (variantId !== null && !UUID_RE.test(variantId)) return badRequest(req, res, 'variant_id must be a UUID');

  let conn;
  try {
    conn = await pool.rw.getConnection();
    const access = await callerMaySeeVersions(conn, req.user, templateId);
    if (!access.found || !access.allowed) return notFound(req, res);
    if (!(await versionsTableAvailable(conn))) {
      return sendError(req, res, null, { status: 503, code: 'VERSIONS_UNAVAILABLE', reason: 'Versions are not available on this database schema: the versions table has not been created. '
        + 'An administrator can see the outstanding schema steps under schema status.' });
    }

    const id = uuidv4();
    // SECURITY: the actor is the sole authority on who saved this — a
    // client-supplied actor_id is never trusted. `kind` is always 'manual'
    // here — a client can never mint a 'flow' row through this route.
    const actorId = req.user && req.user.id ? req.user.id : null;
    // FREEZE POINT the TEMPLATE_CHANGED guard reads back at restore: the
    // template as of THIS server-side read, not the instant this row lands.
    // Overwrites any client-supplied key of the same name — the guard is
    // only load-bearing if the stamp cannot be dictated by the caller.
    // `base_template_updated_at` is kept for observability only — the guard
    // DECISION is `base_template_fingerprint`: `updated_at` has only
    // second resolution, so a write landing in the same second as this read
    // would pass a timestamp-equality check while still being silently
    // destroyed by a later restore.
    const storedSnapshot = JSON.stringify({
      ...snapshotDoc,
      base_template_updated_at: normalizeDbTimestamp(access.row.updated_at),
      base_template_fingerprint: templateStateFingerprint(access.row),
    });
    await conn.query(
      `INSERT INTO \`${t(TABLES.TEMPLATE_VERSIONS)}\`
         (id, template_id, name, note, kind, flow_run_id, blueprint_id, variant_id, snapshot, actor_id)
       VALUES (?, ?, ?, ?, 'manual', NULL, ?, ?, ?, ?)`,
      [id, templateId, name, note, blueprintId, variantId, storedSnapshot, actorId],
    );
    const rows = await conn.query(
      `SELECT ${LIST_COLUMNS} FROM \`${t(TABLES.TEMPLATE_VERSIONS)}\` WHERE id = ?`,
      [id],
    );
    if (rows.length) await attachActorNames(conn, rows);
    return res.status(201).json(apiOk(rows.length ? presentManualRow(rows[0]) : {
      id, template_id: templateId, kind: 'manual', name, note, status: null, flow_run_id: null,
      blueprint_id: blueprintId, variant_id: variantId, actor_id: actorId, actor_name: null, created_at: null,
    }));
  } catch (err) {
    return dbError(req, res, err, { templateId });
  } finally {
    if (conn) conn.release();
  }
});

// GET /:templateId/versions/:versionId — one version in full.
router.get('/:templateId/versions/:versionId', async (req, res) => {
  const templateId = String(req.params.templateId);
  if (!UUID_RE.test(templateId)) return notFound(req, res);
  const parsed = parseVersionId(req.params.versionId);
  if (!parsed) return notFound(req, res, 'Version not found');

  let conn;
  try {
    conn = await pool.ro.getConnection();
    const access = await callerMaySeeVersions(conn, req.user, templateId);
    if (!access.found || !access.allowed) return notFound(req, res);

    const loaded = await loadVersionRow(conn, templateId, parsed);
    if (!loaded) return notFound(req, res, 'Version not found');
    await attachActorNames(conn, [loaded.row]);
    const presented = loaded.kind === 'flow'
      ? presentFlowRow(loaded.row, { withSnapshot: true })
      : presentManualRow(loaded.row, { withSnapshot: true });
    return res.json(apiOk(presented));
  } catch (err) {
    return dbError(req, res, err, { templateId });
  } finally {
    if (conn) conn.release();
  }
});

const EDITABLE_VERSION_FIELDS = Object.freeze(['name', 'note']);

// PUT /:templateId/versions/:versionId — rename / edit note. Manual rows only.
// Explicit transaction around the FOR UPDATE read + UPDATE (same idiom
// `transformers/versions.js`'s DELETE-version route uses for its own
// lock-then-write pair) — the FOR UPDATE row lock is only load-bearing
// inside a transaction; on autocommit it releases the instant the SELECT
// itself completes, before the UPDATE that lock exists to serialize against
// ever runs.
router.put('/:templateId/versions/:versionId', async (req, res) => {
  const templateId = String(req.params.templateId);
  if (!UUID_RE.test(templateId)) return notFound(req, res);
  const parsed = parseVersionId(req.params.versionId);
  if (!parsed) return notFound(req, res, 'Version not found');

  let conn;
  try {
    conn = await pool.rw.getConnection();
    await conn.beginTransaction();
    const access = await callerMaySeeVersions(conn, req.user, templateId);
    if (!access.found || !access.allowed) { await safeRollback(conn); return notFound(req, res); }

    if (parsed.kind === 'flow') {
      await safeRollback(conn);
      return sendError(req, res, null, { status: 400, code: 'FLOW_VERSION_READONLY', reason: 'A flow run\'s entry on the timeline cannot be renamed or annotated here — its own history lives on the run surfaces.' });
    }

    const body = req.body && typeof req.body === 'object' && !Array.isArray(req.body) ? req.body : {};
    const rejected = Object.keys(body).filter((k) => !EDITABLE_VERSION_FIELDS.includes(k));
    if (rejected.length) {
      await safeRollback(conn);
      return badRequest(req, res,
        `A version's ${rejected.sort().join(', ')} cannot be changed; only ${EDITABLE_VERSION_FIELDS.join(' and ')} are editable.`,
      );
    }

    const updates = [];
    const params = [];
    if (Object.prototype.hasOwnProperty.call(body, 'name')) {
      const name = typeof body.name === 'string' ? body.name.trim() : '';
      if (!name) { await safeRollback(conn); return badRequest(req, res, 'name is required'); }
      if (name.length > MAX_NAME) { await safeRollback(conn); return badRequest(req, res, `name exceeds ${MAX_NAME} characters`); }
      updates.push('name = ?');
      params.push(name);
    }
    if (Object.prototype.hasOwnProperty.call(body, 'note')) {
      const note = body.note ?? null;
      if (note !== null && (typeof note !== 'string' || note.length > MAX_NOTE)) {
        await safeRollback(conn);
        return badRequest(req, res, `note must be a string up to ${MAX_NOTE} characters`);
      }
      updates.push('note = ?');
      params.push(note);
    }
    if (!updates.length) { await safeRollback(conn); return badRequest(req, res, `Provide ${EDITABLE_VERSION_FIELDS.join(' or ')} to change`); }

    if (!(await versionsTableAvailable(conn))) { await safeRollback(conn); return notFound(req, res, 'Version not found'); }
    const existing = await conn.query(
      `SELECT id FROM \`${t(TABLES.TEMPLATE_VERSIONS)}\` WHERE id = ? AND template_id = ? FOR UPDATE`,
      [parsed.id, templateId],
    );
    if (!existing.length) { await safeRollback(conn); return notFound(req, res, 'Version not found'); }

    await conn.query(
      `UPDATE \`${t(TABLES.TEMPLATE_VERSIONS)}\` SET ${updates.join(', ')} WHERE id = ? AND template_id = ?`,
      [...params, parsed.id, templateId],
    );
    const rows = await conn.query(
      `SELECT ${LIST_COLUMNS} FROM \`${t(TABLES.TEMPLATE_VERSIONS)}\` WHERE id = ?`,
      [parsed.id],
    );
    if (rows.length) await attachActorNames(conn, rows);
    await conn.commit();
    return res.json(apiOk(rows.length ? presentManualRow(rows[0]) : null));
  } catch (err) {
    await safeRollback(conn);
    return dbError(req, res, err, { templateId });
  } finally {
    if (conn) conn.release();
  }
});

// DELETE /:templateId/versions/:versionId — manual rows only. Flow history is
// deleted through the existing run surfaces, not here. Explicit transaction
// around the FOR UPDATE read + DELETE — same reasoning as PUT above.
router.delete('/:templateId/versions/:versionId', async (req, res) => {
  const templateId = String(req.params.templateId);
  if (!UUID_RE.test(templateId)) return notFound(req, res);
  const parsed = parseVersionId(req.params.versionId);
  if (!parsed) return notFound(req, res, 'Version not found');

  let conn;
  try {
    conn = await pool.rw.getConnection();
    await conn.beginTransaction();
    const access = await callerMaySeeVersions(conn, req.user, templateId);
    if (!access.found || !access.allowed) { await safeRollback(conn); return notFound(req, res); }

    if (parsed.kind === 'flow') {
      await safeRollback(conn);
      return sendError(req, res, null, { status: 400, code: 'FLOW_VERSION_READONLY', reason: 'A flow run\'s entry on the timeline cannot be deleted here — delete the run itself from the run history.' });
    }

    if (!(await versionsTableAvailable(conn))) { await safeRollback(conn); return notFound(req, res, 'Version not found'); }
    const existing = await conn.query(
      `SELECT id FROM \`${t(TABLES.TEMPLATE_VERSIONS)}\` WHERE id = ? AND template_id = ? FOR UPDATE`,
      [parsed.id, templateId],
    );
    if (!existing.length) { await safeRollback(conn); return notFound(req, res, 'Version not found'); }

    await conn.query(
      `DELETE FROM \`${t(TABLES.TEMPLATE_VERSIONS)}\` WHERE id = ? AND template_id = ?`,
      [parsed.id, templateId],
    );
    await conn.commit();
    return res.json(apiOk({ id: parsed.id, deleted: true }));
  } catch (err) {
    await safeRollback(conn);
    return dbError(req, res, err, { templateId });
  } finally {
    if (conn) conn.release();
  }
});

const RESTORE_AUDIT_EVENT = 'template.version.restore';

// POST /:templateId/versions/:versionId/restore — destructive, server-side
// (spec §5, unlike a snapshot's client-side restore). Ordering inside one
// transaction: access → resolve the version's document → guard →
// overwrite → audit. Every rejection path fires BEFORE the overwrite.
router.post('/:templateId/versions/:versionId/restore', async (req, res) => {
  const templateId = String(req.params.templateId);
  if (!UUID_RE.test(templateId)) return notFound(req, res);
  const parsed = parseVersionId(req.params.versionId);
  if (!parsed) return notFound(req, res, 'Version not found');

  const rawSavedVersionId = (req.body || {}).saved_version_id;
  if (rawSavedVersionId !== undefined && rawSavedVersionId !== null && typeof rawSavedVersionId !== 'string') {
    return badRequest(req, res, 'saved_version_id must be a version id string');
  }
  const claimedSavedVersionId = typeof rawSavedVersionId === 'string' && rawSavedVersionId ? rawSavedVersionId : null;
  if (claimedSavedVersionId && claimedSavedVersionId === req.params.versionId) {
    return badRequest(req, res, 'saved_version_id cannot be the version being restored');
  }

  let conn;
  try {
    conn = await pool.rw.getConnection();
    await conn.beginTransaction();

    // Fingerprint columns read fresh, inside the transaction + FOR UPDATE,
    // so the guard below sees the CURRENT row, not a pre-lock stale one.
    const templateRows = await conn.query(
      `SELECT id, owner_id, blueprint_id, updated_at,
              payload, generated_outputs, field_option_selection, computed_field_overrides, cleared_auto_fills
         FROM \`${t(TABLES.USER_TEMPLATES)}\` WHERE id = ? FOR UPDATE`,
      [templateId],
    );
    if (!templateRows.length) { await safeRollback(conn); return notFound(req, res); }
    const templateRow = templateRows[0];
    if (!(await callerMayWriteTemplate(conn, req.user, templateRow))) {
      await safeRollback(conn);
      return notFound(req, res);
    }

    const loaded = await loadVersionRow(conn, templateId, parsed);
    if (!loaded) { await safeRollback(conn); return notFound(req, res, 'Version not found'); }
    const rawSnapshot = loaded.kind === 'flow' ? flowSnapshotDocument(loaded.row) : loaded.row.snapshot;
    const restorable = extractRestorable(rawSnapshot);
    if (!restorable) {
      await safeRollback(conn);
      return conflictError(req, res, 'This version\'s snapshot cannot be read, so it cannot be restored. Restore a different version.');
    }

    let savedVersionId = null;
    if (claimedSavedVersionId) {
      if (!UUID_RE.test(claimedSavedVersionId)) { await safeRollback(conn); return badRequest(req, res, 'saved_version_id must be a version id string'); }
      if (!(await versionsTableAvailable(conn))) { await safeRollback(conn); return notFound(req, res, 'Saved version not found'); }
      const savedRows = await conn.query(
        `SELECT id, snapshot FROM \`${t(TABLES.TEMPLATE_VERSIONS)}\` WHERE id = ? AND template_id = ?`,
        [claimedSavedVersionId, templateId],
      );
      if (!savedRows.length) { await safeRollback(conn); return notFound(req, res, 'Saved version not found'); }

      // FREEZE POINT, not arrival order — a write landing between the
      // save-first read and the POST that cut this version would pass a
      // created_at-ordered check and still be silently destroyed. Guard on a
      // CONTENT fingerprint over the exact columns restore overwrites, not
      // `updated_at`: that TIMESTAMP column has only second resolution, so a
      // same-second write is invisible to a timestamp-equality check but
      // still changes what this restore would clobber. Recomputed from the
      // CURRENT row, inside this transaction, before the UPDATE below. A
      // snapshot with no fingerprint refuses the same way — never fall-open.
      const savedDoc = parseSnapshot(savedRows[0].snapshot);
      const baseFingerprint = savedDoc && typeof savedDoc === 'object' && !Array.isArray(savedDoc)
        ? savedDoc.base_template_fingerprint
        : undefined;
      const currentFingerprint = templateStateFingerprint(templateRow);
      if (typeof baseFingerprint !== 'string' || !baseFingerprint || baseFingerprint !== currentFingerprint) {
        await safeRollback(conn);
        return conflictError(req, res,
          'This template changed after it was saved, so restoring now would overwrite work that no version holds. '
          + 'Nothing was changed — save the current state again and retry.',
          'TEMPLATE_CHANGED',
        );
      }
      savedVersionId = claimedSavedVersionId;
    }

    const payload = { ...restorable.computed, ...restorable.entered };
    // WHY: restore must reset every companion column the loader reapplies —
    // a snapshot doc carries none of them, so leaving them in place would let
    // the loader re-derive a state that never existed on top of the restored
    // payload (fmb-input-load.ts applies field_option_selection,
    // computed_field_overrides and cleared_auto_fills after payload load).
    await conn.query(
      `UPDATE \`${t(TABLES.USER_TEMPLATES)}\`
         SET payload = ?, generated_outputs = ?,
             field_option_selection = NULL, computed_field_overrides = NULL, cleared_auto_fills = NULL
       WHERE id = ?`,
      [JSON.stringify(payload), JSON.stringify(restorable.outputs), templateId],
    );

    const actor = req.user || {};
    const safeRole = ['admin', 'editor', 'user'].includes(actor.role) ? actor.role : 'unknown';
    await conn.query(
      `INSERT INTO \`${t(TABLES.FEATURE_AUDIT)}\` (id, event_type, user_id, metadata)
       VALUES (?, ?, ?, ?)`,
      [
        uuidv4(),
        RESTORE_AUDIT_EVENT,
        actor.id || null,
        JSON.stringify({
          template_id: templateId,
          version_id: req.params.versionId,
          prior_state_saved: savedVersionId !== null,
          saved_version_id: savedVersionId,
          actor_role: safeRole,
        }),
      ],
    );

    await conn.commit();
    return res.json(apiOk({
      template_id: templateId,
      version_id: req.params.versionId,
      prior_state_saved: savedVersionId !== null,
      saved_version_id: savedVersionId,
    }));
  } catch (err) {
    await safeRollback(conn);
    return dbError(req, res, err, { templateId });
  } finally {
    if (conn) conn.release();
  }
});

// POST /:templateId/versions/:versionId/save-as — clone into a NEW template.
router.post('/:templateId/versions/:versionId/save-as', async (req, res) => {
  const templateId = String(req.params.templateId);
  if (!UUID_RE.test(templateId)) return notFound(req, res);
  const parsed = parseVersionId(req.params.versionId);
  if (!parsed) return notFound(req, res, 'Version not found');

  const body = req.body && typeof req.body === 'object' ? req.body : {};
  const rawName = typeof body.name === 'string' ? body.name.trim() : '';
  if (rawName.length > MAX_NAME) return badRequest(req, res, `name exceeds ${MAX_NAME} characters`);

  let conn;
  try {
    conn = await pool.rw.getConnection();
    await conn.beginTransaction();

    const sourceRows = await conn.query(
      `SELECT id, owner_id, blueprint_id, variant_id, category_id, release_id, schema_version
         FROM \`${t(TABLES.USER_TEMPLATES)}\` WHERE id = ?`,
      [templateId],
    );
    if (!sourceRows.length) { await safeRollback(conn); return notFound(req, res); }
    const source = sourceRows[0];
    if (!(await callerMayWriteTemplate(conn, req.user, source))) { await safeRollback(conn); return notFound(req, res); }

    const loaded = await loadVersionRow(conn, templateId, parsed);
    if (!loaded) { await safeRollback(conn); return notFound(req, res, 'Version not found'); }
    const rawSnapshot = loaded.kind === 'flow' ? flowSnapshotDocument(loaded.row) : loaded.row.snapshot;
    const restorable = extractRestorable(rawSnapshot);
    if (!restorable) {
      await safeRollback(conn);
      return conflictError(req, res, 'This version\'s snapshot cannot be read, so it cannot be cloned. Clone a different version.');
    }

    const versionName = loaded.kind === 'manual' ? loaded.row.name : 'Flow run';
    const name = (rawName || `${versionName} (copy)`).slice(0, MAX_NAME);
    // Both row shapes carry a frozen blueprint_id; only a manual row carries
    // variant_id (flow_recipe_runs has no such column — table-ddls.js). A
    // clone falls back to the SOURCE template's current hierarchy when the
    // version itself never recorded one.
    const blueprintId = loaded.row.blueprint_id ?? source.blueprint_id ?? null;
    const variantId = (loaded.kind === 'manual' ? loaded.row.variant_id : null) ?? source.variant_id ?? null;

    const newId = uuidv4();
    const actorId = req.user && req.user.id ? req.user.id : null;
    await conn.query(
      `INSERT INTO \`${t(TABLES.USER_TEMPLATES)}\`
         (id, name, owner_id, category_id, release_id, blueprint_id, variant_id,
          payload, generated_outputs, schema_version, parent_id)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        newId, name, actorId, source.category_id ?? null, source.release_id ?? null,
        blueprintId, variantId,
        JSON.stringify({ ...restorable.computed, ...restorable.entered }),
        JSON.stringify(restorable.outputs),
        source.schema_version ?? null,
        templateId,
      ],
    );
    await conn.commit();

    const created = await conn.query(
      `SELECT id, name, owner_id, category_id, release_id, blueprint_id, variant_id,
              payload, generated_outputs, parent_id, schema_version, created_at, updated_at
         FROM \`${t(TABLES.USER_TEMPLATES)}\` WHERE id = ?`,
      [newId],
    );
    return res.status(201).json(apiOk(created.length ? created[0] : { id: newId, name }));
  } catch (err) {
    await safeRollback(conn);
    return dbError(req, res, err, { templateId });
  } finally {
    if (conn) conn.release();
  }
});

module.exports = router;
module.exports.__test__ = {
  parseVersionId, callerMaySeeVersions, versionsTableAvailable, presentManualRow, presentFlowRow,
  extractRestorable, flowSnapshotDocument, normalizeDbTimestamp,
  MAX_SNAPSHOT_BYTES, MAX_NAME, MAX_NOTE, RUN_ID_PREFIX,
};
