'use strict';

/**
 * template-activity.js — the trail of who did what to one record.
 *
 *   GET  /:templateId            one page of the trail, newest first
 *   POST /:templateId/generated  record that output was produced
 *
 * WHO MAY READ IT: the record's owner, anyone they delegated to, and an
 * administrator. Anyone else is answered as though the record did not exist —
 * the same 404 the write path gives, for the same reason.
 *
 * WHAT THE READ GATE ACTUALLY PROTECTS, stated precisely because it is narrower
 * than "who touched this record". Who DISPATCHED a record, and when, is already
 * public: every authenticated caller may read every run, and a run carries its
 * template and its actor. What this gate keeps to the record's own people is the
 * rest of the trail — that somebody CHANGED the answers, that somebody PRODUCED
 * output, and the shape of how often. Reading it as "the trail is private" would
 * be believing a narrowing that the open run history has already undone.
 *
 * WHY PRODUCING OUTPUT IS RECORDED BY THE BROWSER. It has no server endpoint:
 * it runs in the browser, writes nothing, and reads only what the caller may
 * already read, which is why it is not GATED. Recording it therefore has to be
 * told, and this is where. What IS gated is the recording — a caller who may not
 * work on the record cannot append to its trail, or the trail would be a surface
 * anyone could write to. So: generating is open to everyone, and the trail is
 * the owner's record of the people who have access.
 *
 * BOUNDED AND PAGED. This list grows with every save. It is never returned
 * whole, and a request with no page bound gets the first page rather than all of
 * it.
 */
const router = require('express').Router();
const { sendError } = require('../../../shared/lib/send-error');
const { pool, t } = require('../../db');
const {
  apiOk, requireAuth, UUID_RE,
} = require('../../../shared/helpers');
const { TABLES } = require('../../../shared/constants');
const { mapRowsFromDb, normalizeTimestamp } = require('../../lib/dto-mapper');
const { attachOwnerNames } = require('../../lib/owner-name-enrichment');
const { normalizeRows } = require('../../../shared/serializers/normalize-nullable');
const { parsePageRequest } = require('./schema/list-query');
const { callerHasTemplateAccess } = require('../../lib/delegated-grants');
const {
  recordTemplateActivity, activityTableAvailable, ACTIVITY_ACTIONS,
} = require('../../lib/template-activity');
const { logger: rootLogger } = require('../../../shared/lib/logger');

const logger = rootLogger.child({ module: 'template-activity-route' });

// SECURITY: authentication for the whole router, so a route added later
// inherits it rather than having to remember it.
router.use((req, res, next) => { if (requireAuth(req, res)) next(); });

/** The page a caller gets when they ask for no particular page. */
const DEFAULT_PAGE_SIZE = 25;

const dbError = (req, res, err, fields) => sendError(req, res, err, { status: 500, code: 'INTERNAL_ERROR', reason: 'Database operation failed', fields });

const notFound = (req, res) => sendError(req, res, null, { status: 404, code: 'NOT_FOUND', reason: 'Not found' });

/**
 * May this caller see, and add to, this record's trail?
 *
 * Answers with the same rule the write path enforces in SQL — ownership, a
 * grant, ownership of the blueprint, or being an administrator — read here
 * rather than predicated because there is no write to attach a predicate to.
 */
async function callerMaySeeTrail(conn, user, templateId) {
  const rows = await conn.query(
    `SELECT id, owner_id, blueprint_id FROM \`${t(TABLES.USER_TEMPLATES)}\` WHERE id = ?`,
    [templateId],
  );
  if (!rows.length) return false;
  if (user.role === 'admin') return true;
  if (rows[0].owner_id && rows[0].owner_id === user.id) return true;
  return callerHasTemplateAccess(conn, user.id, {
    templateId,
    ownerId: rows[0].owner_id ?? null,
    blueprintId: rows[0].blueprint_id ?? null,
  }, user.role);
}

/** Rename the shared owner enrichment's output to the person it was run for,
 *  and carry the one thing the screen cannot work out for itself: whether the
 *  account that acted still exists. Without it a deleted account renders as an
 *  ordinary person named Unknown, which is a claim about who has been working
 *  on the record. */
async function attachActorNames(conn, rows) {
  await attachOwnerNames(conn, rows, 'actor_id', `\`${t(TABLES.USERS)}\``, { unresolved: null });
  for (const row of rows) {
    if (!row) continue;
    row.actor_removed = row.actor_id != null && row.owner_name == null;
    row.actor_name = row.owner_name ?? '';
    row.actor_username = row.owner_username ?? '';
    delete row.owner_name;
    delete row.owner_username;
  }
  return rows;
}

function resolvePage(query) {
  const q = query || {};
  if (q.offset === undefined && q.limit === undefined) {
    return { paginated: true, limit: DEFAULT_PAGE_SIZE, offset: 0 };
  }
  return parsePageRequest({ ...q, offset: q.offset === undefined ? '0' : q.offset });
}

/**
 * @openapi
 * /api/template-activity/{templateId}:
 *   get:
 *     summary: One page of a record's activity trail
 *     tags: [App - Template Activity]
 *     parameters:
 *       - { name: templateId, in: path, required: true, schema: { type: string } }
 *       - { name: limit, in: query, schema: { type: integer } }
 *       - { name: offset, in: query, schema: { type: integer } }
 *     responses:
 *       200: { description: Trail page }
 *       404: { description: No such record, or not the caller's to see }
 */
router.get('/:templateId', async (req, res) => {
  const templateId = String(req.params.templateId);
  if (!UUID_RE.test(templateId)) return notFound(req, res);
  const page = resolvePage(req.query);
  if (page.error) {
    return sendError(req, res, null, { status: 400, code: page.error.code, reason: page.error.message });
  }

  let conn;
  try {
    conn = await pool.ro.getConnection();
    if (!(await callerMaySeeTrail(conn, req.user, templateId))) return notFound(req, res);
    // A database whose operator account could not create the table has no
    // trail. An empty one is the truth there — every state below distinguishes
    // it from "nothing has happened yet", which is what `available` is for.
    if (!(await activityTableAvailable(conn))) {
      return res.json(apiOk({
        available: false, rows: [], total: 0, limit: page.limit, offset: page.offset, summary: null,
      }));
    }
    const rows = await conn.query(
      `SELECT id, template_id, actor_id, action, metadata, created_at
         FROM \`${t(TABLES.TEMPLATE_ACTIVITY)}\`
        WHERE template_id = ?
        ORDER BY created_at DESC, id DESC
        LIMIT ? OFFSET ?`,
      [templateId, page.limit, page.offset],
    );
    const totalRows = await conn.query(
      `SELECT COUNT(*) AS cnt FROM \`${t(TABLES.TEMPLATE_ACTIVITY)}\` WHERE template_id = ?`,
      [templateId],
    );
    const mapped = mapRowsFromDb(TABLES.TEMPLATE_ACTIVITY, rows);
    await attachActorNames(conn, mapped);

    // The one-line summary the screen puts above the list. Derived from the
    // newest row on the FIRST page only: on any later page the newest row in
    // view is not the newest row there is, and a summary that said otherwise
    // would be wrong in a way nobody could see.
    const newest = page.offset === 0 ? mapped[0] : null;
    const summary = newest
      ? {
        total: Number(totalRows[0].cnt) || 0,
        last_action: newest.action,
        last_actor_name: newest.actor_name || '',
        last_at: normalizeTimestamp(newest.created_at),
      }
      : null;

    return res.json(apiOk({
      available: true,
      rows: normalizeRows(mapped, ['actor_id']),
      total: Number(totalRows[0].cnt) || 0,
      limit: page.limit,
      offset: page.offset,
      summary,
    }));
  } catch (err) {
    return dbError(req, res, err, { templateId });
  } finally {
    if (conn) conn.release();
  }
});

/**
 * @openapi
 * /api/template-activity/{templateId}/generated:
 *   post:
 *     summary: Record that output was produced for a record
 *     tags: [App - Template Activity]
 *     responses:
 *       200: { description: Recorded, or dropped — the caller is told which }
 *       404: { description: No such record, or not the caller's to add to }
 */
router.post('/:templateId/generated', async (req, res) => {
  const templateId = String(req.params.templateId);
  if (!UUID_RE.test(templateId)) return notFound(req, res);

  let conn;
  try {
    conn = await pool.rw.getConnection();
    if (!(await callerMaySeeTrail(conn, req.user, templateId))) return notFound(req, res);
    // The caller states nothing about WHAT was produced beyond a count, and even
    // that is bounded: the outputs themselves are the record's, not the trail's,
    // and a client-supplied document on a durable row is the shape of problem
    // this boundary exists to prevent.
    const rawCount = req.body && req.body.output_count;
    const outputCount = Number.isInteger(rawCount) && rawCount >= 0 && rawCount <= 10_000
      ? rawCount
      : null;
    const recorded = await recordTemplateActivity(conn, {
      templateId,
      actorId: req.user.id,
      action: ACTIVITY_ACTIONS.OUTPUT_GENERATED,
      metadata: outputCount === null ? null : { output_count: outputCount },
    });
    // 200 either way: producing output already happened in the browser and
    // cannot be undone by this answer. `recorded` is what the caller is told, so
    // a client that cares can say the trail is incomplete rather than assume it.
    return res.json(apiOk({ recorded }));
  } catch (err) {
    return dbError(req, res, err, { templateId });
  } finally {
    if (conn) conn.release();
  }
});

module.exports = router;
module.exports.__test__ = { callerMaySeeTrail, DEFAULT_PAGE_SIZE };
