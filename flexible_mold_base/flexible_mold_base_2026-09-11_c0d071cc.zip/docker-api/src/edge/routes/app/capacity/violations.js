/**
 * @openapi
 * /edge/app/capacity/scenarios/{scenarioId}/violations:
 *   get:
 *     tags: [App - Capacity]
 *     summary: Compute the scenario's rule violations (all authenticated, read-only).
 *     parameters:
 *       - { name: scenarioId, in: path, required: true, schema: { type: string } }
 *     responses:
 *       200: { description: "{ violations, summary, rollups } — computed markers, never a gate" }
 *       404: { description: Scenario not found }
 */

/**
 * capacity/violations.js — the read-only violations endpoint.
 *
 * Loads every scenario-scoped row, runs the PURE evaluator (spec §3), and
 * returns the computed markers plus rollups and the hard/soft/waived summary.
 * NEVER-BLOCK (spec §3.1): this is a GET; it computes and reports, it never
 * writes and never rejects. Read is open to all authenticated users (spec §7).
 */
const { pool, t } = require('../../../db');
const { sendError } = require('../../../../shared/lib/send-error');
const { TABLES } = require('../../../../shared/constants');
const { requireAuth, apiOk, apiError } = require('../../../../shared/helpers');
const { mapRowsFromDb } = require('../../../lib/dto-mapper');
const { logger } = require('../../../../shared/lib/logger');
const { evaluate, summarize } = require('../../../../shared/capacity/evaluator');

// Snapshot key → logical table. The keys mirror the evaluator's expected
// collection names (docker-api/src/shared/capacity/evaluator.js). Config-rewrite
// (spec §17.1): cap_sizing_tiers is DROPPED (merged into cap_vm_profiles); the
// first-class Database entity + structural grouping (spec §10-12) add
// cap_databases / cap_custom_groups / cap_custom_group_members so the relational
// rules (keep-apart / spread-across-sites / keep-in-one-site) can resolve their
// structural targets. Every table here is scenario-scoped (WHERE scenario_id = ?).
//
// NOTE (reference model, spec §2): a scenario REFERENCES the global catalogues by
// FK; this scenario-scoped read surfaces only a scenario's LOCAL catalogue rows
// (scenario_id = X). Resolving the referenced GLOBAL rows (scenario_id IS NULL) —
// hardware specs / vm_profiles the hypervisors + db_host VMs point at — is the
// reference-model read concern tracked for the catalogue-wiring slice, not this
// evaluator-collection wiring.
const SNAPSHOT_TABLES = Object.freeze({
  sites: TABLES.CAP_SITES,
  specs: TABLES.CAP_HARDWARE_SPECS,
  hypervisors: TABLES.CAP_HYPERVISORS,
  vms: TABLES.CAP_VMS,
  db_instances: TABLES.CAP_DB_INSTANCES,
  databases: TABLES.CAP_DATABASES,
  custom_groups: TABLES.CAP_CUSTOM_GROUPS,
  custom_group_members: TABLES.CAP_CUSTOM_GROUP_MEMBERS,
  rules: TABLES.CAP_RULES,
  waivers: TABLES.CAP_WAIVERS,
  vm_profiles: TABLES.CAP_VM_PROFILES,
});

// Reference-model catalogue keys in the snapshot: a scenario REFERENCES the
// GLOBAL layer (scenario_id IS NULL) and may add its own LOCAL rows
// (scenario_id = X, spec §2.2). The evaluator needs the rows a scenario actually
// SEES — hardware specs drive usable capacity, vm_profiles drive the SGA cap
// (§3.4), and RULES are the global default template (the 6 seeded rows, all-on)
// a scenario references and locally adjusts via override rows (§13.1a / §13.4).
// These load global-or-same-scenario, matching the §17.1a write validator's
// visibility rule; resolveEffectiveRules then applies each scenario override on
// top of its global template row. The pure entity/structural tables (sites,
// hypervisors, vms, db_instances, databases, custom groups, waivers) stay
// strictly scenario-scoped — waivers and custom groups are scenario-only by
// design (no global layer, spec §11.3), and settings has its own global fallback.
const CATALOGUE_SNAPSHOT_KEYS = new Set(['specs', 'vm_profiles', 'rules']);

async function loadSnapshot(scenarioId) {
  const entries = Object.entries(SNAPSHOT_TABLES);
  // All reads fire in parallel — they are independent single-scenario SELECTs.
  const [scenarioRows, settingsRows, ...collectionRows] = await Promise.all([
    // The scenario's own row (kept for identity / future scenario-scoped needs).
    pool.ro.query(`SELECT * FROM \`${t(TABLES.CAP_SCENARIOS)}\` WHERE id = ?`, [scenarioId]),
    // Settings: the scenario's own override row wins, else the seeded GLOBAL
    // default row (spec §9 / §2.4 — a scenario falls back to global settings).
    // The SGA formula constants (mem_cpu_ratio / sga_factor / …) come from here,
    // so a scenario without an override must still see the global constants.
    pool.ro.query(
      `SELECT * FROM \`${t(TABLES.CAP_SETTINGS)}\` WHERE scenario_id = ? OR scenario_id IS NULL`
      + ` ORDER BY scenario_id IS NULL LIMIT 1`,
      [scenarioId],
    ),
    ...entries.map(([key, table]) => pool.ro.query(
      CATALOGUE_SNAPSHOT_KEYS.has(key)
        ? `SELECT * FROM \`${t(table)}\` WHERE scenario_id IS NULL OR scenario_id = ?`
        : `SELECT * FROM \`${t(table)}\` WHERE scenario_id = ?`,
      [scenarioId],
    )),
  ]);
  const state = {};
  entries.forEach(([key, table], i) => { state[key] = mapRowsFromDb(table, collectionRows[i]); });
  state.scenarios = mapRowsFromDb(TABLES.CAP_SCENARIOS, scenarioRows);
  state.settings = mapRowsFromDb(TABLES.CAP_SETTINGS, settingsRows)[0] || {};
  return state;
}

/**
 * Register GET /scenarios/:scenarioId/violations on the capacity router. Mounted
 * ahead of the /scenarios factory so the two-segment path wins.
 * @param {import('express').Router} capacityRouter
 */
function mountViolations(capacityRouter) {
  capacityRouter.get('/scenarios/:scenarioId/violations', async (req, res) => {
    if (!requireAuth(req, res)) return;
    const scenarioId = req.params.scenarioId;
    try {
      const state = await loadSnapshot(scenarioId);
      if (!state.scenarios.length) {
        return sendError(req, res, null, { status: 404, code: 'NOT_FOUND', reason: 'Not found' });
      }
      const { violations, rollups, budget_exceeded: budgetExceeded } = evaluate(state);
      return res.json(apiOk({
        violations, summary: summarize(violations), rollups, budget_exceeded: budgetExceeded,
      }));
    } catch (err) {
      return sendError(req, res, err, { status: 500, code: 'INTERNAL_ERROR', reason: 'Database operation failed', fields: { scenarioId } });
    }
  });
}

module.exports = { mountViolations, loadSnapshot };
